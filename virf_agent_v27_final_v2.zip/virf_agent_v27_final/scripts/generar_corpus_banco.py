#!/usr/bin/env python3
"""
scripts/generar_corpus_banco.py — corpus RAG con el MATERIAL QUE USA EL BANCO.

    python scripts/generar_corpus_banco.py                     # genera inputs/rag/banco/*.md
    python scripts/generar_corpus_banco.py --reindexar         # … y reconstruye su índice
    python scripts/generar_corpus_banco.py --dueno "Gerencia VIRF" --vigencia 2027-12-31
    python scripts/generar_corpus_banco.py --estandar ruta/Estandar.xlsx

POR QUÉ
───────
El corpus RAG tenía solo literatura EXTERNA (resúmenes de SR 11-7, BCBS, FRTB…)
y el agente evaluaba cada actividad sin el criterio con el que el banco la
evalúa. Este generador convierte en texto indexable, de forma reproducible, el
material de la entidad que ya vive en el proyecto:

  · banco_estandar_validacion.md   el estándar VIRF (ámbito → control →
                                   actividades y Tier en que aplican);
  · banco_procedimiento_validacion.md  el procedimiento de validación vigente
                                   (roles, umbrales, políticas confirmadas);
  · banco_catalogo_controles_datos.md  el repositorio de controles de datos
                                   por dominio (qué se controla, dimensión,
                                   evidencia y referencia);
  · banco_reglas_informe.md        reglas de calificación del informe y glosario.

Las normas y políticas que no viven en el proyecto (resoluciones SBS, políticas
internas, manuales corporativos) se suben aparte a `inputs/rag/banco/` (web:
Evidencia → «RAG · material del banco», rol admin_corpus, con dueño y
vigencia) y entran en el mismo índice.

LÍMITE (regla 1 del corpus): aquí NO va la evidencia de un modelo concreto
(sus manuales, su código, su manual de controles de datos). Eso es lo que se
valida; indexarlo haría que el agente se diera la razón a sí mismo.

Coste 0: sin IA. Idempotente: un documento solo se reescribe si cambia su
contenido (así el índice no se invalida en vano).
"""
from __future__ import annotations

import argparse
import hashlib
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))

DESTINO = RAIZ / "inputs" / "rag" / "banco"

_AVISO = ("> MATERIAL INTERNO DEL BANCO — {tipo}. Origen: `{fuente}` (huella SHA-256 "
          "{huella}). Generado por `scripts/generar_corpus_banco.py`.\n"
          "> Es el CRITERIO DE LA ENTIDAD para validar; no es evidencia del modelo validado.\n")


def _huella(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()[:12] if p.is_file() else "—"


def _escribir(destino: Path, texto: str) -> bool:
    """Escribe solo si cambia. Devuelve True si se escribió."""
    if destino.is_file() and destino.read_text(encoding="utf-8") == texto:
        return False
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text(texto, encoding="utf-8", newline="\n")
    return True


# ── 1. Estándar de validación ─────────────────────────────────────────────

def doc_estandar(xlsx: Path) -> str:
    from web.services.solo_informe_service import parsear_estandar
    est = parsear_estandar(xlsx)
    partes = [f"# Estándar de validación VIRF del banco\n\n"
              + _AVISO.format(tipo="estándar de validación", fuente=xlsx.relative_to(RAIZ).as_posix()
                              if xlsx.is_relative_to(RAIZ) else xlsx.name, huella=_huella(xlsx))
              + "\nEl estándar define, por ámbito, los controles que la validación debe cubrir y "
                "las actividades concretas con las que se evalúa cada control, y en qué Tier de "
                "modelo aplica cada actividad (Tier I es el de mayor criticidad).\n"]
    for amb in est["ambitos"]:
        partes.append(f"\n## Ámbito: {amb}\n")
        ctrls = [c for c in est["controles"] if c["ambito"] == amb]
        vistos: list[str] = []
        for c in ctrls:
            nombre = " — ".join(x for x in (c["control"], c["control_especifico"]) if x)
            if nombre not in vistos:
                vistos.append(nombre)
        for nombre in vistos:
            partes.append(f"\n### Control: {nombre or '(sin nombre)'}\n\n"
                          f"Para el ámbito {amb}, el control «{nombre}» se evalúa con estas "
                          "actividades:\n")
            for c in ctrls:
                if " — ".join(x for x in (c["control"], c["control_especifico"]) if x) != nombre:
                    continue
                tiers = c.get("tiers")
                t = ("aplica a Tier " + ", ".join(tiers)) if tiers else (
                    "no marcada para ningún Tier" if est.get("tiene_tier") else "aplica a todos los Tier")
                partes.append(f"- {c['actividad']} ({t}).")
    return "\n".join(partes) + "\n"


# ── 2. Procedimiento de validación ────────────────────────────────────────

def doc_procedimiento(md: Path) -> str:
    texto = md.read_text(encoding="utf-8")
    # El título propio del documento se conserva debajo del aviso.
    return ("# Procedimiento de validación independiente del banco\n\n"
            + _AVISO.format(tipo="procedimiento de validación vigente",
                            fuente=md.name, huella=_huella(md))
            + "\n" + re.sub(r"^# .*\n", "", texto, count=1))


# ── 3. Catálogo de controles de datos ─────────────────────────────────────

_NOMBRES_DOM = {"var": "Trading / riesgo de mercado (VaR)", "alm": "ALM y modelos conductuales",
                "lar": "Liquidez (LaR, RCL, RFNE)", "shared": "Transversal (BCBS 239)"}


def doc_controles() -> str:
    from modulos.repositorio_controles import cargar_controles
    por_carpeta: dict[str, dict[str, dict]] = {}
    for dom in ("VaR", "ALM", "LaR"):
        ctrls, _av = cargar_controles(dom)
        for c in ctrls:
            por_carpeta.setdefault(c["dominio_carpeta"], {})[c["nombre"]] = c
    carpeta = RAIZ / "inputs" / "repositorio_controles"
    huella = hashlib.sha256("".join(sorted(
        f"{p.relative_to(carpeta).as_posix()}:{_huella(p)}" for p in carpeta.rglob("*.py")
    )).encode()).hexdigest()[:12]
    partes = ["# Catálogo de controles de calidad de datos del banco\n\n"
              + _AVISO.format(tipo="catálogo de controles de datos",
                              fuente="inputs/repositorio_controles/", huella=huella)
              + "\nControles de calidad de datos que la Gerencia de Validación aplica según el "
                "tipo de modelo. Cada control indica qué se comprueba, su dimensión de calidad, "
                "la evidencia que se pide y su referencia normativa.\n"]
    for carp in ("var", "alm", "lar", "shared"):
        ctrls = por_carpeta.get(carp) or {}
        if not ctrls:
            continue
        partes.append(f"\n## Controles de datos — {_NOMBRES_DOM.get(carp, carp)}\n")
        for c in sorted(ctrls.values(), key=lambda x: (x["meta"].get("orden", 99), x["nombre"])):
            m = c["meta"]
            partes.append(f"\n### Control de datos: {c['nombre'].replace('_', ' ')}\n\n"
                          f"{m.get('descripcion', '')}\n\n"
                          f"- Dimensión de calidad: {m.get('dimension', '—')}.\n"
                          f"- Evidencia requerida: {m.get('evidencia', '—')}\n"
                          f"- Referencia: {m.get('referencia', '—')}.")
    return "\n".join(partes) + "\n"


# ── 4. Reglas de calificación del informe y glosario ──────────────────────

def doc_reglas() -> str:
    from modulos import plantilla_bcp, reglas_informe
    fuente = RAIZ / "modulos" / "reglas_informe.py"
    partes = ["# Reglas de calificación de los informes de validación del banco\n\n"
              + _AVISO.format(tipo="reglas de calificación y glosario",
                              fuente="modulos/reglas_informe.py y modulos/plantilla_bcp.py",
                              huella=_huella(fuente)),
              "\n## Niveles de riesgo de una observación\n",
              "De menor a mayor gravedad: " + ", ".join(reglas_informe.RIESGOS) + ". Una "
              "Oportunidad de Mejora no es un incumplimiento: no deja el control como no "
              "cumplido y no lleva responsable ni fecha de subsanación.\n",
              "\n## Calificación global de la gestión del modelo\n",
              "Niveles: " + ", ".join(reglas_informe.NIVELES) + ".\n",
              "- Deficiente: más de 2 observaciones críticas.",
              "- Regular: 1 o 2 críticas; o más de una moderada (más de 3 si al menos una es de "
              "Documentación y otra de Gobierno).",
              "- Aceptable: una moderada (o menos de 3 con la excepción de Documentación y "
              "Gobierno), o 5 o más observaciones bajas o potenciales. «Aceptable» nunca lleva "
              "críticas.",
              "- Satisfactorio: como máximo 4 observaciones bajas o potenciales y ninguna "
              "moderada ni crítica.",
              "\n## Cumplimiento del estándar\n",
              "Un control del estándar se considera no cumplido cuando tiene al menos una "
              "observación de riesgo. Un control que no aplica al modelo se excluye del "
              "cumplimiento con su motivo, y uno que no se pudo revisar se declara como "
              "limitación y tampoco se da por satisfactorio.\n",
              "\n## Glosario\n"]
    for termino, sigla, desc in plantilla_bcp.GLOSARIO_BASE:
        partes.append(f"- **{termino}**{f' ({sigla})' if sigla not in ('—', '') else ''}: {desc}")
    return "\n".join(partes) + "\n"


def generar(estandar: Path, procedimiento: Path, destino: Path = DESTINO) -> dict[str, bool]:
    """Escribe los documentos del corpus del banco. Devuelve {fichero: reescrito}."""
    docs = {
        "banco_estandar_validacion.md": doc_estandar(estandar),
        "banco_procedimiento_validacion.md": doc_procedimiento(procedimiento),
        "banco_catalogo_controles_datos.md": doc_controles(),
        "banco_reglas_informe.md": doc_reglas(),
    }
    readme = destino / "README.md"
    if not readme.is_file():
        _escribir(readme, (
            "# inputs/rag/banco/ — material que usa el banco para validar\n\n"
            "Criterio de la entidad que el agente consulta en TODAS las evaluaciones, además\n"
            "del dominio del modelo: estándar, procedimiento, catálogo de controles, reglas\n"
            "de calificación (los genera `scripts/generar_corpus_banco.py`) y las normas o\n"
            "políticas internas que suba el administrador del corpus (.pdf, .docx, .xlsx,\n"
            ".pptx, .md, .txt), cada una con dueño y vigencia.\n\n"
            "NO va aquí la evidencia de un modelo concreto (sus manuales, su código, su\n"
            "manual de controles de datos): eso es lo que se valida.\n\n"
            "Este README no se indexa.\n"))
    return {nombre: _escribir(destino / nombre, texto) for nombre, texto in docs.items()}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Genera el corpus RAG con el material del banco.")
    ap.add_argument("--estandar", default=str(RAIZ / "inputs" / "Estandares_VIRF.xlsx"))
    ap.add_argument("--procedimiento", default=str(RAIZ / "PROCEDIMIENTO_VALIDACION.md"))
    ap.add_argument("--dueno", default="", help="Registra dueño de las fuentes generadas (con --vigencia)")
    ap.add_argument("--vigencia", default="", help="Vigente hasta AAAA-MM-DD (con --dueno)")
    ap.add_argument("--reindexar", action="store_true", help="Reconstruye el índice del corpus banco")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    res = generar(Path(a.estandar), Path(a.procedimiento))
    for nombre, cambio in res.items():
        print(f"  {'✍️  escrito ' if cambio else '=  sin cambios'}  inputs/rag/banco/{nombre}")
    if bool(a.dueno) != bool(a.vigencia):
        print("  ⚠️  --dueno y --vigencia van juntos; no se registró nada.")
    elif a.dueno:
        from modulos.fuentes_rag import registrar_fuente
        for nombre in res:
            registrar_fuente("banco", DESTINO / nombre, a.dueno, a.vigencia,
                             cargado_por="scripts/generar_corpus_banco.py")
        print(f"  📋 Registradas {len(res)} fuentes con dueño «{a.dueno}» hasta {a.vigencia}.")
    else:
        print("  ℹ️  Sin --dueno/--vigencia: las fuentes quedan «huérfanas» en el inventario "
              "hasta que el equipo les asigne dueño (el agente no inventa dueños).")
    if a.reindexar:
        from src.rag.banco.indexer import BancoIndexer
        BancoIndexer().build_index(force_rebuild=True)     # imprime fragmentos y documentos
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
