"""
scripts/generar_guia_calidad_datos.py — Guía del notebook de calidad de datos.

Genera `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md` desde el PROPIO código para que no
se quede atrás: el catálogo de controles, sus parámetros, las columnas y hojas
del Excel de resultados, los controles por dominio del repositorio, los
endpoints y los parámetros salen de `modulos/controles_ia.py`,
`modulos/aprendizaje_controles.py`, `inputs/repositorio_controles/`, la app
FastAPI y `config/parametros.py`. El texto explicativo vive aquí.

Si se añade un tipo al catálogo o una columna al Excel sin explicarlos aquí, el
script FALLA (así la guía no puede quedar incompleta).

Uso:
    .venv\\Scripts\\python scripts\\generar_guia_calidad_datos.py              # escribe la guía
    .venv\\Scripts\\python scripts\\generar_guia_calidad_datos.py --comprobar  # 1 si está desactualizada

No llama a ninguna IA ni ejecuta notebooks.
"""
from __future__ import annotations

import argparse
import ast
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

DESTINO = RAIZ / "docs" / "GUIA_NOTEBOOK_CALIDAD_DATOS.md"

#: Un ejemplo por tipo del catálogo (dataset, columnas, params). OBLIGATORIO.
EJEMPLOS = {
    "completitud": ("cartera", ["saldo_capital"], {"umbral_pct": 0}),
    "unicidad": ("cartera", ["id_operacion"], {"umbral_pct": 0}),
    "rango": ("cartera", ["tasa_interes"], {"minimo": 0, "maximo": 1, "umbral_pct": 0}),
    "no_negativos": ("cartera", ["plazo_dias"], {"umbral_pct": 0}),
    "dominio": ("cartera", ["segmento"], {"valores": ["Mayorista", "Minorista", "Pyme"]}),
    "tipo_numerico": ("cartera", ["monto_texto"], {"umbral_pct": 0}),
    "fecha_valida": ("cartera", ["fecha_desembolso"], {"desde": "2000-01-01", "hasta": "2026-12-31"}),
    "frescura": ("cartera", ["fecha_corte"], {"max_dias": 31}),
    "volumen_minimo": ("cartera", [], {"min_filas": 1000}),
    "constante": ("cartera", ["moneda"], {}),
    "outliers_iqr": ("cartera", ["saldo_capital"], {"k": 3, "umbral_pct": 1}),
    "consistencia": ("cartera", ["saldo_capital", "monto_desembolsado"], {"operador": "<="}),
    "formato": ("cartera", ["id_operacion"], {"patron": r"OP\d{5}"}),
    "integridad": ("cartera", ["id_cliente"], {"ref_dataset": "clientes", "ref_columna": "id_cliente"}),
    "suma_control": ("cartera", ["saldo_capital"], {"valor_esperado": 15250000.0, "tolerancia_pct": 0.5}),
    "completitud_condicional": ("cartera", ["estado", "fecha_cancelacion"], {"valores": ["CANCELADO"]}),
    "valores_centinela": ("cartera", ["fecha_nacimiento"], {}),
    "longitud": ("clientes", ["dni"], {"minimo": 8, "maximo": 8, "umbral_pct": 0}),
    "espacios_extremos": ("clientes", ["nombre"], {"umbral_pct": 0}),
    "caracteres_invalidos": ("clientes", ["direccion"], {"umbral_pct": 0}),
    "categorias_equivalentes": ("cartera", ["segmento"], {"umbral_pct": 0}),
    "fecha_futura": ("cartera", ["fecha_desembolso"], {"umbral_pct": 0}),
    "consistencia_fechas": ("cartera", ["fecha_desembolso", "fecha_vencimiento"], {"operador": "<="}),
    "proporcion_ceros": ("cartera", ["saldo_capital"], {"umbral_pct": 5}),
    "cardinalidad": ("cartera", ["moneda"], {"minimo": 1, "maximo": 3}),
    "conciliacion_totales": ("cartera", ["saldo_capital"], {"ref_dataset": "contabilidad", "ref_columna": "saldo",
                                                             "tolerancia_pct": 0.5}),
    "conciliacion_conteos": ("cartera", [], {"ref_dataset": "maestro", "tolerancia_pct": 0}),
    "variacion_temporal": ("cartera", ["saldo_capital", "fecha_corte"], {"agregacion": "sum",
                                                                          "max_variacion_pct": 20}),
    "serie_continua": ("pyg", ["fecha"], {"frecuencia": "B", "excluir": ["2026-07-28", "2026-07-29"]}),
    "estabilidad_psi": ("cartera", ["score", "fecha_corte"], {"umbral_psi": 0.25}),
    "valores_repetidos": ("factores", ["precio", "fecha", "id_factor"], {"max_repeticiones": 5, "umbral_pct": 1}),
    "saltos_serie": ("factores", ["precio", "fecha", "id_factor"], {"k": 10, "umbral_pct": 0.5}),
    "monotonia": ("var_reportado", ["var_95", "var_99"], {"sentido": "creciente", "umbral_pct": 0}),
    "monotonia_curva": ("curvas", ["factor_descuento", "tenor", "fecha"], {"sentido": "decreciente", "umbral_pct": 0}),
    "relacion_aritmetica": ("saldos", ["saldo_inicial", "amortizacion", "prepago", "saldo_final"],
                            {"operacion": "resta", "tolerancia_pct": 0.5, "umbral_pct": 0}),
    "diferencia_relativa": ("precios", ["precio_modelo", "precio_ipv"], {"tolerancia_pct": 2, "umbral_pct": 5}),
    "categorias_requeridas": ("escenarios", ["escenario"], {"valores": ["paralelo_arriba", "paralelo_abajo",
                                                                        "empinamiento", "aplanamiento",
                                                                        "cortos_arriba", "cortos_abajo"]}),
    "combinaciones_completas": ("saldos", ["fecha", "segmento"], {"umbral_pct": 0}),
    "minimo_por_grupo": ("factores", ["id_factor"], {"min_filas": 250, "umbral_pct": 0}),
    "suma_por_grupo": ("distribucion_nmd", ["proporcion", "segmento"], {"valor_esperado": 1.0, "tolerancia_pct": 0.5}),
    "conciliacion_por_grupo": ("posiciones", ["saldo", "moneda"], {"ref_dataset": "contabilidad", "ref_columna": "saldo",
                                                                   "ref_claves": ["moneda"], "tolerancia_pct": 0.5}),
    "signo_por_categoria": ("posiciones", ["saldo", "activo_pasivo"], {"positivos": ["ACTIVO"], "negativos": ["PASIVO"]}),
    "banda_coherente": ("posiciones", ["dias_reprecio", "banda"], {"limites": [0, 30, 90, 365, 36500],
                                                                   "etiquetas": ["0-1M", "1-3M", "3-12M", ">1A"]}),
    "fechas_habiles": ("pyg", ["fecha"], {"excluir": ["2026-07-28", "2026-07-29"], "umbral_pct": 0}),
}

#: Qué significa cada columna del Excel de resultados. OBLIGATORIO.
COLUMNAS = {
    "Descripción": "Qué se espera (la lee el pipeline como descripción del control).",
    "% de incumplimiento": "Filas afectadas sobre evaluadas, en %.",
    "Resultado": "OK, FALLA o No evaluable (lo lee el pipeline).",
    "Umbral": "% de incumplimiento tolerado con el que se decidió.",
    "Detalle observación": "Diagnóstico del control (cifras y ejemplos).",
    "Control": "Identificador: Cxx (propuesto), Xxx (tuyo sin programar), Pxx (programado).",
    "Dimensión": "Completitud, Unicidad, Validez, Exactitud, Consistencia, Actualidad…",
    "Control Esperado": "Igual que Descripción (cuadro de 8 columnas del entregable).",
    "% De cumplimiento del data set": "100 − % de incumplimiento.",
    "Diagnóstico": "Igual que Detalle observación (cuadro de 8 columnas).",
    "Decisión": "Cumple, No cumple o No evaluable.",
    "Control o Evidencia requerida": "Qué pedir a la primera línea si no cumple.",
    "Referencia en el entregable": "base.columnas del control.",
    "Dataset": "Base sobre la que se ejecutó.",
    "Columnas": "Columnas que usa el control.",
    "Tipo": "Tipo del catálogo (o personalizado:<función>).",
    "N evaluados": "Filas (o periodos) evaluados.",
    "N afectados": "Filas (o periodos) que fallan.",
    "Criticidad": "ALTA, MEDIA o BAJA.",
    "Justificación del control": "Qué del perfil lo motivó (o «añadido por el validador»).",
    "Origen": "reglas, ia, aprendido, validador o personalizado.",
    "Definición": "JSON con tipo, columnas y parámetros TAL COMO SE EJECUTARON (de aquí aprende el agente).",
    "Tipo de modelo": "Tipo de modelo de la ficha al que pertenece el control de negocio (var, runoff, irrbb…).",
}


def _defecto(nombre: str) -> str:
    """Valor por defecto de un parámetro de config/parametros.py (sin leer el .env)."""
    arbol = ast.parse((RAIZ / "config" / "parametros.py").read_text(encoding="utf-8"))
    for nodo in arbol.body:
        if (isinstance(nodo, ast.Assign) and len(nodo.targets) == 1
                and isinstance(nodo.targets[0], ast.Name) and nodo.targets[0].id == nombre
                and isinstance(nodo.value, ast.Call) and len(nodo.value.args) >= 2):
            v = nodo.value.args[1]
            if isinstance(v, ast.Constant):
                return {True: "1", False: "0"}.get(v.value, str(v.value)) \
                    if isinstance(v.value, bool) else str(v.value)
    return "?"


def _repositorio() -> list[str]:
    from modulos.repositorio_controles import _extraer_meta
    base = RAIZ / "inputs" / "repositorio_controles"
    filas = ["| Carpeta (dominio) | Control | Qué verifica |", "|---|---|---|"]
    for carpeta in sorted(p for p in base.iterdir() if p.is_dir() and not p.name.startswith("_")):
        for f in sorted(carpeta.glob("*.py")):
            if f.name.startswith("_"):
                continue
            meta, _err = _extraer_meta(f.read_text(encoding="utf-8"), f.name)
            desc = " ".join(str((meta or {}).get("descripcion") or "—").split()).replace("|", "\\|")
            filas.append(f"| `{carpeta.name}/` | `{f.stem}` | {desc[:160]} |")
    return filas


def rutas_app(rutas=None, prefijo: str = ""):
    """(ruta, route) de la app, entrando en los routers incluidos (FastAPI ≥ 0.13x los anida)."""
    if rutas is None:
        from web.app import app
        rutas = app.routes
    for r in rutas:
        orig = getattr(r, "original_router", None)
        if orig is not None:
            ctx = getattr(r, "include_context", None)
            yield from rutas_app(orig.routes, prefijo + (getattr(ctx, "prefix", "") or ""))
            continue
        if hasattr(r, "methods") and hasattr(r, "path"):
            yield prefijo + r.path, r


def _endpoints(prefijo: str) -> list[str]:
    filas = ["| Método | Ruta | Qué hace |", "|---|---|---|"]
    vistos = set()
    for ruta, r in sorted(rutas_app(), key=lambda x: x[0]):
        if not ruta.startswith(prefijo):
            continue
        for m in sorted(getattr(r, "methods", None) or []):
            if m in ("HEAD", "OPTIONS") or (m, ruta) in vistos:
                continue
            vistos.add((m, ruta))
            doc = " ".join(((getattr(r, "endpoint", None) and r.endpoint.__doc__) or "").split())
            filas.append(f"| {m} | `{ruta}` | {doc[:150].replace('|', '/') or '—'} |")
    return filas


def _patron_legible(rx: str) -> str:
    """El patrón de columnas de una regla, en palabras («pnl, pyg, perdida…»)."""
    t = rx
    for basura in ("(^|_)", "(_|\\d|$)", "(_|$)", "_?", "\\d", "^", "$"):
        t = t.replace(basura, "")
    t = t.replace("(", "").replace(")", "").replace("|", ", ")
    return ", ".join(x.strip() for x in t.split(",") if x.strip())


def _tipo_modelo() -> list[str]:
    from modulos import controles_ia as ci
    filas = ["| Tipo de modelo | Columnas | Control | Criticidad | Qué verifica · por qué |", "|---|---|---|---|---|"]
    for dom, reglas in ci.REGLAS_TIPO_MODELO.items():
        for r in reglas:
            cols = (f"fecha {_patron_legible(r['pares'][0])} vs. {_patron_legible(r['pares'][1])}"
                    if "pares" in r else _patron_legible(r["columna"]))
            extra = " (+ columna de fecha)" if r.get("con_fecha") else ""
            filas.append(f"| `{dom}` | {cols}{extra} | `{r['tipo']}` {r['params']} | {r['criticidad']} | "
                         f"{r['que']} · {r['por_que']} |".replace("\\", "\\\\"))
    return filas


def _negocio() -> list[str]:
    """Controles de negocio por tipo de modelo (fichas de modulos/tipos_modelo*.py)."""
    from modulos import tipos_modelo as tm
    filas = ["| Tipo de modelo | Familia | Bases lógicas | Controles de negocio | Análisis del repositorio |",
             "|---|---|---|---|---|"]
    from modulos.repositorio_controles import cargar_controles
    for tid, t in tm.TIPOS.items():
        cs, _ = cargar_controles(t["carpeta"])
        repo = [c["nombre"] for c in cs if c["dominio_carpeta"] == t["carpeta"]
                and (not (c["meta"] or {}).get("tipos") or tid in c["meta"]["tipos"])]
        filas.append(f"| **{t['nombre']}** (`{tid}`) | {t['familia']} | "
                     f"{', '.join(b['id'] for b in t['bases'])} | {len(t['controles'])} | "
                     f"{', '.join(f'`{x}`' for x in repo) or '—'} |")
    return filas


def construir() -> str:
    from modulos import controles_ia as ci
    faltan_ej = sorted(set(ci.CATALOGO) - set(EJEMPLOS))
    faltan_col = [c for c in ci.COLUMNAS_SALIDA if c not in COLUMNAS]
    if faltan_ej or faltan_col:
        raise SystemExit("La guía está incompleta: explica en scripts/generar_guia_calidad_datos.py "
                         f"los tipos {faltan_ej} y las columnas {faltan_col}.")
    for t, (_ds, cols, ps) in EJEMPLOS.items():
        if t not in ci.CATALOGO:
            raise SystemExit(f"El ejemplo «{t}» ya no está en el catálogo: quítalo de EJEMPLOS.")
        _p, err = ci.validar_params(t, ps)
        if err:
            raise SystemExit(f"El ejemplo de «{t}» no es válido: {err}")
    ejemplos = []
    for t, (ds, cols, ps) in EJEMPLOS.items():
        ejemplos.append(f"    {{'dataset': '{ds}', 'tipo': '{t}', 'columnas': {cols!r}, 'params': {ps!r},\n"
                        f"     'descripcion': '…', 'criticidad': 'MEDIA'}},")
    L: list[str] = []
    a = L.append
    a("# Guía del notebook de calidad de datos")
    a("")
    a("> Generada desde el código por `scripts/generar_guia_calidad_datos.py`: no la edites a mano "
      "(regénérala). Se sirve también en la web: **Controles de datos → ✨ Diseñar con IA → "
      "¿Cómo prendo el notebook? → Abrir la guía completa**.")
    a("")
    a("## Contenido")
    a("")
    for i, t in enumerate(["Para qué sirve", "Antes de empezar: qué pegar en VIRF", "Generar el notebook",
                           "Cómo prenderlo (ejecutarlo)", "Recorrido del notebook",
                           "Porcentaje de cumplimiento", "Devolverlo y qué revisa el agente",
                           "Controles por tipo de modelo", "Cómo agregarle más controles",
                           "Traer tus controles de otros notebooks", "Cómo sigue aprendiendo el agente",
                           "Problemas comunes", "Referencia"], 1):
        a(f"{i}. {t}")
    a("")
    a("## 1. Para qué sirve")
    a("")
    a("El validador **no sube los datos** (viven en el entorno del banco). Pega en VIRF la salida de "
      "`.info()` y `.describe()` de cada base; con ese **perfil** el agente arma un **notebook "
      "autocontenido** (solo `pandas` y `numpy`) que trae **siempre todos los controles**: los que se "
      "deducen del perfil, los del **tipo de modelo** (VaR no es ALM ni LaR), los aprendidos del "
      "dominio, una **batería completa** sobre todas las columnas y una plantilla lista de cada tipo "
      "del catálogo que necesita un dato del negocio. Al ejecutarlo donde están los datos calcula el "
      "**porcentaje de cumplimiento** y guarda un Excel que se devuelve a VIRF: el mismo agente lo "
      "revisa, entra (si lo decides) en la validación y **enseña** al agente para los próximos modelos.")
    a("")
    a("Principios: la IA solo **propone** (todo control se valida contra el catálogo y el perfil); el "
      "notebook **no llama a ninguna IA** ni envía datos; nada se ejecuta en el servidor; las filas que "
      "fallan se quedan en tu equipo (evidencia local).")
    a("")
    a("## 2. Antes de empezar: qué pegar en VIRF")
    a("")
    a("En tu entorno, para cada base del modelo:")
    a("")
    a("```python")
    a("import pandas as pd")
    a("pd.set_option('display.max_columns', None)      # que no recorte columnas")
    a("df.info()                                        # columnas, tipos y no nulos")
    a("print(df.describe(include='all').to_string())   # estadísticos de TODAS las columnas")
    a("```")
    a("")
    a("En Spark: `df.printSchema()` y `df.describe().show(truncate=False)`. Pega cada salida en su "
      "recuadro (una base por bloque; **+ Agregar otra base** para más). Con *1 · Ver qué entendió el "
      "agente* compruebas columnas, nulos y estadísticos antes de generar.")
    a("")
    a("> El `describe()` redondea a 6 cifras (99999999 sale `1.000000e+08`): el agente lo sabe y, si ve "
      "un mínimo o máximo «redondo», propone un control de **valores centinela** con los dos candidatos.")
    a("")
    a("## 3. Generar el notebook")
    a("")
    a("1. Comprueba el **dominio** y elige el **tipo de modelo** (Configuración → Tipo de modelo: VaR, run-off, "
      "IRRBB, prepago, NMD, LCR…). El tipo decide lo que el notebook sabe del negocio (§8): sin él trae solo "
      "los controles generales del dominio.")
    a("2. **Contexto (opcional):** qué es cada base, llaves, periodo, reglas de negocio conocidas.")
    a("3. Casilla **Incluir los controles que el agente aprendió de este dominio**: suma las lecciones "
      "APROBADAS por un revisor (§11).")
    a("4. **2 · Proponer controles con IA y generar notebook** (reglas + IA, con coste) o **Solo reglas "
      "(sin IA)** (coste 0). La IA solo añade controles que pasan la validación: tipo del catálogo, "
      "columnas que existen, parámetros correctos y ninguna cifra inventada en la justificación.")
    a("5. Revisa el resumen (propuestos · tipo de modelo · batería · cobertura del catálogo) y la tabla, "
      "y descarga el `.ipynb`.")
    a("")
    a(ci.GUIA_PRENDER_MD.replace("## ▶ Cómo prenderlo (ejecutarlo), paso a paso",
                                 "## 4. Cómo prenderlo (ejecutarlo), paso a paso"))
    a("")
    a("## 5. Recorrido del notebook")
    a("")
    a(ci._INDICE_MD.replace("## Índice\n\n", ""))
    a("")
    a("Detalles que conviene saber:")
    a("")
    a("* **Numeración:** `C` propuestos · `M` negocio del tipo de modelo (por roles) · `T` reglas del dominio · "
      "`D` repositorio del dominio · `B` batería completa · `BD` batería dinámica (columnas que no estaban en el "
      "perfil) · `X` tuyos sin programar · `P` programados o traídos · `IA` del experto (validación completa).")
    a("* **Entender el modelo** (al inicio, si elegiste el tipo): qué hace el modelo, qué produce y para qué se "
      "usa, qué bases necesita (y con cuál de las tuyas se enlazó), qué puede fallar en los datos y por qué "
      "importa, las referencias normativas y **qué pedir a la primera línea**.")
    a("* **0 · `BASES` y `ROLES`**: el enlace entre los conceptos de negocio (P&L, saldo, banda, tasa de "
      "salida…) y tus columnas. Corrígelo una vez y todos los controles `M` que lo usan cambian. La sección "
      "**3b** lo comprueba, sugiere columnas para lo que falta (`ENLAZAR_SUGERENCIAS = True` las aplica) y lo "
      "guarda en la hoja *Roles*. Un control sin su columna sale como **Pendiente** (no cuenta en el %).")
    a("* **0 · Configuración** calcula `COLUMNAS_USADAS` (las columnas que tocan los controles, por "
      "base): úsalo para leer solo lo necesario en bases grandes (`usecols`) y en Databricks (`select`).")
    a("* **3 · Comprobación contra el perfil**: si la base que cargas no tiene las filas, columnas, "
      "tipos o nulos del perfil que pegaste, lo avisa y lo deja en la hoja *Perfil_vs_datos*; el agente "
      "lo anota como **limitación** de la revisión.")
    a("* **4b · Batería** solo imprime lo que **no** cumple (`MOSTRAR_BATERIA_COMPLETA = True` para verlo "
      "todo). Re-ejecutar una celda **no duplica** su resultado.")
    a("* **8 · Excel**: hojas " + ", ".join(f"**{h}**" for h in ci.HOJAS_SALIDA) + " (la primera es la "
      "que leen VIRF y el pipeline). *Metadatos* guarda la propuesta, versiones, modo demo, el porcentaje "
      "de cumplimiento y la **huella sha256** de cada base.")
    a("")
    a("## 6. Porcentaje de cumplimiento")
    a("")
    a("| Indicador | Cómo se calcula |")
    a("|---|---|")
    a("| **Porcentaje de cumplimiento** | controles que **cumplen** ÷ controles **evaluados** × 100. Los "
      "«No evaluable» no cuentan a favor ni en contra: van como limitación. |")
    a("| Ponderado por criticidad | igual, pesando ALTA = 3, MEDIA = 2, BAJA = 1. |")
    a("| Cumplimiento medio de los datos | promedio del «% De cumplimiento del data set» de cada control. |")
    a("| Por dimensión, base, origen y criticidad | el mismo cálculo por grupo (hoja *Resumen*). |")
    a("| Cobertura del catálogo | cuántos de los tipos corrieron; los demás son plantillas (hoja *Cobertura*). |")
    a("")
    a("El notebook lo imprime en grande en la sección 7, lo guarda en *Resumen* y *Metadatos*, y VIRF "
      "lo **recalcula** al revisar: si el Excel declara un porcentaje distinto del que sale del cuadro "
      "(se editó después de ejecutar), lo anota como **incoherencia**.")
    a("")
    a("## 7. Devolverlo y qué revisa el agente")
    a("")
    a("En **Controles de datos → ✨ Diseñar con IA → 3 · Revisar resultados**: sube el Excel, elige su "
      "**clasificación** (obligatoria) y marca lo que quieras:")
    a("")
    a("| Casilla | Qué hace |")
    a("|---|---|")
    a("| Redactar las observaciones con IA | La IA redacta riesgo, observación y recomendación por cada "
      "control que no cumple; cada texto se verifica (sin cifras ajenas al cuadro). Sin ella, por reglas. |")
    a("| Usar estos resultados en la validación | Copia el Excel a `calidad_datos/resultadocalidad_de_datos/`"
      " de la sesión: entra en el ámbito *Calidad de datos* del pipeline. |")
    a("| Enseñar al agente | Registra lo ejecutado como **lecciones del dominio** (pendientes de aprobar). |")
    a("")
    a("La revisión determinista (siempre) comprueba: coherencia entre decisión, % y umbral (salvo los "
      "controles del repositorio, que deciden por su propia prueba); controles propuestos que no "
      "aparecen; no evaluables; diferencias contra el perfil; resultados del MODO_DEMO; el porcentaje "
      "declarado contra el recalculado; y los controles programados (su código viaja como texto). Un "
      "Excel del **MODO_DEMO** se puede revisar, pero VIRF **rechaza** usarlo en la validación o en el "
      "aprendizaje.")
    a("")
    a("## 8. Controles por tipo de modelo")
    a("")
    a("No son los mismos controles para un VaR que para un run-off, un IRRBB o un LCR. El **tipo de "
      "modelo** de la ficha (explícito, nunca se deduce) y el **dominio** deciden tres capas, además de la "
      "batería general:")
    a("")
    a("**Capa 0 · Controles de negocio del tipo de modelo (`M…`)**: cada tipo tiene una ficha "
      "(`modulos/tipos_modelo_trading.py`, `tipos_modelo_alm.py`, `tipos_modelo_liquidez.py`) con sus bases "
      "lógicas, los ROLES que las definen, lo que puede fallar y los controles expresados por roles, cada uno "
      "con su **porqué de negocio**. El detalle completo de cada tipo (negocio, bases, riesgos, controles, "
      "preguntas a la primera línea y pasos de experto por etapa) está en `docs/GUIA_TIPOS_DE_MODELO.md`.")
    a("")
    L.extend(_negocio())
    a("")
    a("**Capa 1 · Reglas del tipo de modelo (`T…`)**: controles del catálogo que se activan por la "
      "semántica de las columnas. Viven como datos en `modulos/controles_ia.py → REGLAS_TIPO_MODELO` "
      "(añadir una regla = añadir un diccionario):")
    a("")
    L.extend(_tipo_modelo())
    a("")
    a("**Capa 2 · Repositorio del dominio (`D…`)**: los controles especializados de "
      "`inputs/repositorio_controles/<dominio>/` (Kupiec, Christoffersen, LCR, NSFR, CPR, ΔEVE…), "
      "embebidos en el notebook con sus columnas **enlazadas a tu perfil** (por nombre exacto o por "
      "sinónimos: `campo_pnl` → `pnl`, `pyg`, `resultado`…). Lo que no se pudo enlazar sale marcado y se "
      "edita en `PARAMS_Dxx`. Su decisión es la del propio control («Observado» cuenta como no cumple y "
      "«Revisión manual» como no evaluable). `shared/` no se repite: lo cubre la batería.")
    a("")
    a("## 9. Cómo agregarle más controles")
    a("")
    a("Seis niveles, de menos a más esfuerzo. Empieza siempre por el más bajo que resuelva tu caso.")
    a("")
    a("### Nivel 1 · Ajustar lo propuesto (sin programar)")
    a("")
    a("* **Cambiar un umbral:** en la celda del control (o en la lista `BATERIA`), edita `umbral_pct=` "
      "(o `max_dias=`, `tolerancia_pct=`, `umbral_psi=`…). El Excel guarda el valor usado y, si enseñas "
      "al agente, aprende ese umbral para el dominio.")
    a("* **Quitar un control:** comenta su celda (`Ctrl + /`) o su línea en `BATERIA`. Si era un control "
      "aprendido, cuenta como **descarte**.")
    a("")
    a("### Nivel 2 · Las plantillas de la sección 5 (sin programar)")
    a("")
    a("El notebook trae una plantilla de **cada tipo que no corrió**, con tus columnas. Descoméntala, pon "
      "el dato del negocio y ejecuta. Se numeran `X01`, `X02`… con origen **validador**. Un ejemplo de "
      "cada tipo del catálogo:")
    a("")
    a("```python")
    a("CONTROLES_ADICIONALES = [")
    L.extend(ejemplos)
    a("]")
    a("```")
    a("")
    a("### Nivel 3 · Un control programado por ti")
    a("")
    a("En la sección **6**, una función con el decorador `@mi_control` (ver también §10 para traerla de "
      "otro notebook):")
    a("")
    a("```python")
    a("@mi_control(dataset='cartera', columnas=['saldo_capital', 'monto_desembolsado'],")
    a("            descripcion='El saldo vivo no supera el monto desembolsado',")
    a("            dimension='Consistencia', criticidad='ALTA', params={'umbral_pct': 0.0})")
    a("def saldo_no_supera_desembolso(df, columnas, umbral_pct=0.0, **_):")
    a("    saldo = pd.to_numeric(df[columnas[0]], errors='coerce')")
    a("    desembolso = pd.to_numeric(df[columnas[1]], errors='coerce')")
    a("    return saldo > desembolso      # True = la fila falla")
    a("```")
    a("")
    a("Se numera `P01`… con origen **personalizado** y su código viaja como texto en "
      "*Controles_personalizados*. VIRF **no ejecuta** ese código ni lo copia solo a otros notebooks.")
    a("")
    a("### Nivel 4 · Un tipo nuevo en el catálogo (desarrollador)")
    a("")
    a("Cuando un control programado se repite (aparece en *Candidatos al catálogo*, §11) o es claramente "
      "reutilizable, conviértelo en un tipo del catálogo, en `modulos/controles_ia.py`:")
    a("")
    a("1. **`CATALOGO`**: añade `\"mi_tipo\": {\"dimension\": …, \"params\": {nombre: float|list|str}, "
      "\"descripcion\": …}`.")
    a("2. **`_N_COLUMNAS`**: cuántas columnas usa si no es una (2, `None` = una o más, 0 = ninguna).")
    a("3. **`_LIBRERIA`**: la función `def mi_tipo(df, columnas, <params>, umbral_pct=0.0, **_)`; llama a "
      "`_exigir(df, columnas)` y devuelve `_res(evaluados, afectados, umbral_pct, diagnóstico, mascara)`. "
      "Es código que corre en el equipo del validador: solo `pandas`/`numpy`.")
    a("4. **`validar_params`**: las reglas de sus parámetros (obligatorios, rangos, valores permitidos).")
    a("5. *(Opcional)* **`bateria_completa`** si aplica a cualquier columna sin datos del negocio, o una "
      "regla en **`REGLAS_TIPO_MODELO`** si es propia de un tipo de modelo.")
    a("6. **Test** (como `tests/test_controles_bateria_tipo_modelo.py`): detecta lo que siembras y el "
      "notebook sigue corriendo de punta a punta.")
    a("7. Añade su ejemplo a `EJEMPLOS` en este script y **regenera la guía** (si no, falla a propósito).")
    a("")
    a("### Nivel 5 · Una regla del tipo de modelo (desarrollador)")
    a("")
    a("Un diccionario más en `REGLAS_TIPO_MODELO[\"var\" | \"alm\" | \"lar\"]`: `columna` (patrón del "
      "nombre) o `pares` (dos fechas), `tipo`, `params`, `criticidad`, `que` y `por_que`. La tabla de §8 "
      "se regenera sola.")
    a("")
    a("### Nivel 6 · Un control especializado en el repositorio del dominio")
    a("")
    a("Crea un `.py` en `inputs/repositorio_controles/<dominio>/` con `META` (literal: descripcion, "
      "dimension, evidencia, referencia, orden, params con los `campo_*`) y `def control(df, datasets, "
      "params) -> {pct, decision, diagnostico}`. Entra solo en los notebooks de ese dominio (capa 2, §8) "
      "y en la pestaña **Notebook entregable**. Ver `inputs/repositorio_controles/README.md`. Hoy hay:")
    a("")
    L.extend(_repositorio())
    a("")
    a("## 10. Traer tus controles de otros notebooks")
    a("")
    a("Si ya resolviste controles en otros notebooks (Kaggle, cursos, proyectos anteriores, otras "
      "áreas), no los reescribas. Tres caminos, de más rápido a más permanente:")
    a("")
    a("**A · ¿Ya existe en el catálogo?** Casi todo lo habitual sí. Usa su tipo (plantilla de la sección "
      "5) y te ahorras el código:")
    a("")
    a("| En tu otro notebook | En VIRF (tipo del catálogo) |")
    a("|---|---|")
    for de, en in [
        ("`df.isnull().sum()` · `df[c].isna().mean()`", "`completitud` (la batería ya lo corre en todas)"),
        ("`df.duplicated().sum()` · `df[k].duplicated()`", "`unicidad` (sin columnas = filas idénticas)"),
        ("`df[c].between(a, b)`", "`rango`"),
        ("`(df[c] < 0).sum()`", "`no_negativos`"),
        ("`~df[c].isin(lista)`", "`dominio`"),
        ("`pd.to_numeric(df[c], errors='coerce').isna()`", "`tipo_numerico`"),
        ("`pd.to_datetime(df[c], errors='coerce').isna()`", "`fecha_valida`"),
        ("`df[c].max()` vs. hoy", "`frescura`"),
        ("código IQR con `quantile(.25/.75)`", "`outliers_iqr`"),
        ("`df[a] <= df[b]`", "`consistencia` (fechas: `consistencia_fechas`)"),
        ("`df[c].str.match(regex)`", "`formato`"),
        ("`df[c].str.len()`", "`longitud`"),
        ("`df[c] != df[c].str.strip()`", "`espacios_extremos`"),
        ("`df.merge(ref, how='left', indicator=True)` → `left_only`", "`integridad`"),
        ("`df[c].sum()` vs. total contable", "`suma_control` / `conciliacion_totales`"),
        ("`len(df)` vs. `len(otra)`", "`conciliacion_conteos`"),
        ("`df[c].nunique()`", "`cardinalidad` / `constante`"),
        ("`groupby(periodo)[c].sum().pct_change()`", "`variacion_temporal`"),
        ("función PSI", "`estabilidad_psi`"),
        ("Great Expectations `expect_column_values_to_not_be_null`", "`completitud`"),
        ("GE `expect_column_values_to_be_unique`", "`unicidad`"),
        ("GE `expect_column_values_to_be_between`", "`rango`"),
        ("GE `expect_column_values_to_be_in_set`", "`dominio`"),
        ("GE `expect_column_values_to_match_regex`", "`formato`"),
        ("GE `expect_column_value_lengths_to_be_between`", "`longitud`"),
        ("GE `expect_table_row_count_to_be_between`", "`volumen_minimo`"),
        ("GE `expect_column_pair_values_A_to_be_greater_than_B`", "`consistencia`"),
        ("pandera `nullable=False` · `unique=True`", "`completitud` · `unicidad`"),
        ("pandera `Check.in_range` · `Check.isin` · `Check.str_matches`", "`rango` · `dominio` · `formato`"),
        ("deequ `isComplete` · `isUnique` · `hasPattern` · `isContainedIn` · `hasSize`",
         "`completitud` · `unicidad` · `formato` · `dominio` · `volumen_minimo`"),
    ]:
        a(f"| {de} | {en} |")
    a("")
    a("**B · Pégalo tal cual en la sección 6** con `@mi_control(...)` encima. No hace falta adaptar el "
      "código: el notebook acepta lo que tu función devuelva y le pasa solo los argumentos que acepta.")
    a("")
    a("| Tu función devuelve | Se lee como |")
    a("|---|---|")
    a("| `_res(...)` | tal cual |")
    a("| Serie booleana (`True` = la fila falla) | filas que fallan sobre `len(df)` |")
    a("| DataFrame con las filas que fallan | ídem (por índice) |")
    a("| `int` | número de filas que fallan |")
    a("| `(evaluados, afectados)` | tal cual |")
    a("| `True` / `False` | cumple / no cumple |")
    a("")
    a("```python")
    a("# Pegado de otro notebook: firma solo df y devuelve las filas malas.")
    a("@mi_control(dataset='cartera', descripcion='Operaciones duplicadas por llave y fecha',")
    a("            dimension='Unicidad', criticidad='ALTA')")
    a("def duplicados_otro_notebook(df):")
    a("    return df[df.duplicated(subset=['id_operacion', 'fecha_corte'], keep=False)]")
    a("")
    a("# Si tu función devuelve otra cosa (un dict, un texto…), conviértelo con un adaptador:")
    a("#   desde_mascara(df, mascara) · desde_filas(df, filas) · desde_conteo(evaluados, afectados)")
    a("#   desde_booleano(cumple)")
    a("```")
    a("")
    a("Pasos: 1) copia la celda o función; 2) si era una celda suelta, envuélvela en `def f(df): …` y "
      "haz que devuelva las filas que fallan; 3) ponle `@mi_control(dataset=…, descripcion=…, "
      "dimension=…, criticidad=…)`; 4) ejecuta: sale como `Pxx` en el Excel, con su código.")
    a("")
    a("**C · Un módulo con todos tus controles.** Junta tus funciones en `mis_controles.py` (al lado del "
      "notebook), con una lista `CONTROLES = [{'funcion': f, 'dataset': …, 'descripcion': …, "
      "'dimension': …, 'criticidad': …}, …]`, y en la sección 6: `import mis_controles` y "
      "`MIS_CONTROLES += mis_controles.CONTROLES`. Así lo reutilizas en todos tus modelos.")
    a("")
    a("**Para que quede para todos:** enséñaselo al agente al devolver el Excel (queda como *candidato "
      "al catálogo* con su código) y pide a un desarrollador que lo convierta en tipo del catálogo "
      "(nivel 4), en regla del tipo de modelo (nivel 5) o en control del repositorio (nivel 6).")
    a("")
    a("## 11. Cómo sigue aprendiendo el agente")
    a("")
    a("El agente no se reentrena: **aprende datos, no pesos**. Guarda por dominio lo que los "
      "validadores ejecutaron de verdad y lo vuelve a proponer cuando la base tiene esas columnas.")
    a("")
    a("```")
    a("propuesta ──▶ notebook ──▶ ejecutas, ajustas umbrales, añades X/P ──▶ Excel")
    a("    ▲                                                                   │")
    a("    │                                         «Enseñar al agente»      ▼")
    a("controles «aprendido» ◀── un REVISOR aprueba ◀── lección PENDIENTE (por dominio)")
    a("```")
    a("")
    a("**Qué se aprende:** los controles del catálogo que ejecutaste salvo los que el agente ya propone "
      "solo sin cambios (reglas, tipo de modelo y batería): los de la IA que mantuviste, los "
      "**umbrales que cambiaste** (el aprobado gana la próxima vez), los `X` que añadiste; los "
      "aprendidos que comentaste cuentan como **descarte**.")
    a("")
    a("**Qué NO se aprende**: código (los `P` son *candidatos al catálogo*, como texto, para un "
      "desarrollador); los del repositorio (`D`, ya viven allí); datos (solo definiciones y cifras "
      "agregadas); resultados del MODO_DEMO.")
    a("")
    a("**Aprobación (rol revisor):** cada lección nace **pendiente** y no influye hasta que un revisor "
      "la **aprueba** en *4 · Lo que el agente aprendió de este dominio*, con motivo (queda en la "
      "auditoría). Quien la enseñó **no puede** aprobarla. Al aprobar se congelan sus parámetros; si "
      "después los validadores usan otros, la tabla lo avisa («cambio desde la aprobación») hasta que "
      "se vuelva a decidir.")
    a("")
    a("**Cómo se usa:** al generar un notebook del mismo dominio, cada lección **activa** cuyas columnas "
      "existen en el nuevo perfil (sin importar mayúsculas, tildes ni espacios) entra con origen "
      "**aprendido** y una justificación de quién la aprobó y cuántas veces se ejecutó. Si coincide con "
      "un control de reglas, ganan los parámetros aprobados. A la IA se le pasa como «criterio de la "
      "entidad».")
    a("")
    a("**Olvido:** un revisor puede **negar** una lección; y una lección que se **descarta** más veces de "
      "las que se usa deja de proponerse sola.")
    a("")
    a("**Registro:** `feedback/aprendizaje_controles.jsonl`, solo-anexar y **sellado** (cada evento "
      "lleva el hash del anterior). La web avisa si alguien lo editó a mano. Las lecciones son por "
      "dominio (VaR, ALM, LaR…): no se mezclan.")
    a("")
    a("| Parámetro | Por defecto | Qué hace |")
    a("|---|---|---|")
    a(f"| `CONTROLES_APRENDIDOS` | {_defecto('CONTROLES_APRENDIDOS')} | 0 = no proponer lo aprendido "
      "(se sigue registrando). |")
    a(f"| `CONTROLES_APRENDIDOS_MAX` | {_defecto('CONTROLES_APRENDIDOS_MAX')} | Tope de controles "
      "aprendidos por notebook. |")
    a("")
    a("## 12. Problemas comunes")
    a("")
    a("| Síntoma | Causa y solución |")
    a("|---|---|")
    a("| «no se reconoció ninguna columna» | Pegaste solo una parte del `.info()`: copia la salida completa. |")
    a("| La propuesta no tiene controles de la IA | La IA no devolvió JSON útil o sus controles no pasaron "
      "la validación: mira los avisos de la propuesta (dicen por qué). |")
    a("| No salen controles del tipo de modelo | El dominio del modelo no es VaR, ALM o LaR (o un alias), "
      "o las columnas no se llaman como esperan las reglas: añade los controles desde las plantillas. |")
    a("| Un `Dxx` dice «sin enlazar» | Esa columna del repositorio no está en tu perfil: edita `PARAMS_Dxx`. |")
    a("| Un control aprendido no aparece | No está aprobado, está negado, se descartó más de lo que se "
      "usó, o la base no tiene sus columnas. Revísalo en la sección 4 de la web. |")
    a("| «no puede decidir sobre ella» al aprobar | Eres quien enseñó la lección: la aprueba otro revisor. |")
    a("| El Excel subido «salió del MODO_DEMO» | Pon `MODO_DEMO = False` y ejecuta sobre tus bases. |")
    a("| Incoherencia «declara un X % de cumplimiento» | Se editó el Excel tras ejecutar: vuelve a ejecutar. |")
    a("| Limitación «no coinciden con el perfil» | La base ejecutada no es la perfilada (otro corte, "
      "columnas renombradas). Vuelve a perfilar o explica la diferencia. |")
    a("")
    a("## 13. Referencia")
    a("")
    a("### Catálogo de controles")
    a("")
    a(ci.tabla_catalogo_md())
    a("")
    a("### Columnas del Excel de resultados (hoja *Controles*)")
    a("")
    a("| Columna | Significado |")
    a("|---|---|")
    for c in ci.COLUMNAS_SALIDA:
        a(f"| {c} | {COLUMNAS[c]} |")
    a("")
    a("### Endpoints")
    a("")
    L.extend(_endpoints("/api/motores/ia"))
    a("")
    a("### Archivos")
    a("")
    a("| Archivo | Qué contiene |")
    a("|---|---|")
    a("| `modulos/controles_ia.py` | Perfil, catálogo, reglas, batería, tipo de modelo, IA validada, notebook y revisión. |")
    a("| `modulos/aprendizaje_controles.py` | Lecciones por dominio, aprobación, olvido y registro sellado. |")
    a("| `inputs/repositorio_controles/<dominio>/` | Controles especializados por tipo de modelo. |")
    a("| `web/routers/controles.py` | Endpoints `/api/motores/ia/*`. |")
    a("| `tests/test_controles_ia.py`, `tests/test_aprendizaje_controles.py`, "
      "`tests/test_controles_bateria_tipo_modelo.py` | Pruebas (coste 0; los notebooks se ejecutan de verdad). |")
    return "\n".join(L).rstrip() + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--comprobar", action="store_true",
                    help="no escribe: sale con 1 si la guía no coincide con el código")
    args = ap.parse_args()
    texto = construir()
    if args.comprobar:
        actual = DESTINO.read_text(encoding="utf-8") if DESTINO.is_file() else ""
        if actual != texto:
            print(f"{DESTINO.relative_to(RAIZ)} está desactualizada: python scripts/generar_guia_calidad_datos.py")
            return 1
        print("guía al día")
        return 0
    DESTINO.write_text(texto, encoding="utf-8", newline="\n")
    print(f"escrita {DESTINO.relative_to(RAIZ)} ({len(texto.splitlines())} líneas)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
