"""
scripts/generar_guia_uso.py — Guía de uso de todo el proyecto VIRF.

Genera `GUIA_USO.md` (raíz del proyecto) desde el PROPIO código para que no se
quede atrás: el menú de la web sale de `web/templates/index.html`, las etapas
de la Validación completa de `modulos/validacion_completa.py`, los comandos del
chat de `web/services/chat_service.py`, los roles de `web/services/roles.py`,
los proveedores de IA de `config/ia.py`, las opciones de la línea de comandos
de `agente.py` y los parámetros de `config/parametros.py`. El texto explicativo
vive aquí.

Si aparece una opción nueva en el menú de la web sin explicar aquí, el script
FALLA (la guía no puede quedar incompleta).

Uso:
    .venv\\Scripts\\python scripts\\generar_guia_uso.py              # escribe GUIA_USO.md
    .venv\\Scripts\\python scripts\\generar_guia_uso.py --comprobar  # 1 si está desactualizada

No llama a ninguna IA.
"""
from __future__ import annotations

import argparse
import ast
import re
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
for _p in (RAIZ, RAIZ / "motor"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

DESTINO = RAIZ / "GUIA_USO.md"

#: Qué hace cada opción del menú lateral (id del botón en index.html). OBLIGATORIO.
MENU = {
    "btn-config": "Ficha del modelo (nombre, **código del inventario**, dominio, tier) y del agente "
                  "(proveedor de IA aprobado, VIRF PLUS, prueba de conexión). El dominio decide el "
                  "corpus del RAG y los controles del repositorio.",
    "btn-estandares": "Sube el `Estandares_VIRF.xlsx` del modelo: el agente evalúa cada actividad como "
                      "checklist filtrada por Tier. El estándar de la sesión no pisa el global.",
    "btn-subir": "Sube la evidencia por carpeta (manuales de modelamiento y seguimiento, implementación "
                 "—código o ZIP—, calidad de datos…), cada archivo con su **clasificación**. Todo queda "
                 "en la sesión del modelo.",
    "btn-dominio-rag": "Literatura del dominio y **corpus del banco** (estándar, procedimiento, catálogo de "
                       "controles, reglas del informe) que se consulta en todas las evaluaciones. Índice "
                       "local BM25 + TF-IDF; al añadir un documento se reconstruye.",
    "btn-skills": "Análisis transversales que el agente aplica al validar (coherencia, supuestos, "
                  "síntesis…) y criterios propios. No cambian el puntaje: producen hallazgos.",
    "btn-cuestionamientos": "Patrones que el agente busca en el CÓDIGO del modelo y criterios extra en "
                            "lenguaje natural.",
    "btn-prevuelo": "Revisión de la evidencia ANTES de gastar (coste 0): qué se podrá leer, PDFs "
                    "escaneados, formatos omitidos y ámbitos que quedarían sin evidencia.",
    "btn-validar": "Ejecuta el pipeline (`agente.py`) con la evidencia, el estándar y el tier de la sesión. "
                   "El JSON, el Word y el Markdown quedan en `outputs/` de la SESIÓN y la revisión con el "
                   "agente empieza sola con ese resultado y su documento.",
    "btn-chat": "Conversación por observación: el agente contrasta tu criterio con la evidencia y tú "
                "decides. Al final, revisión de la redacción («conforme» o «reescribe N»). Ver §6.",
    "btn-documentar": "Cuadro de observaciones (Ámbito · Riesgo · Observación · Recomendación · "
                      "Responsable) e informe Word versionado (V1, V2…), con la tabla de validación final "
                      "y, en validación completa, el anexo de etapas, hallazgos e imágenes.",
    "btn-vc-insumos": "Validación completa: manuales, Excels de primera línea y scripts (también .zip). El "
                      "agente los ESTUDIA enteros (una ficha por archivo, en caché) antes de cada notebook.",
    "btn-resultados": "Corridas de la sesión: puntajes, Excel de resultados, documento Word, comparación "
                      "entre corridas y firma del validador.",
    "btn-controles": "Controles de calidad de datos: diseñar con IA desde `.info()`/`.describe()` (notebook "
                     "local, revisión y aprendizaje), catálogo de motores, resultados de la entidad y "
                     "notebook entregable del repositorio por dominio. Ver `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md`.",
}
_ETAPA_BTN = re.compile(r"^btn-etapa-(\d\d)$")


def _menu() -> list[tuple[str, str, str]]:
    """(sección, id, etiqueta) del menú lateral, en orden."""
    s = (RAIZ / "web" / "templates" / "index.html").read_text(encoding="utf-8")
    salida, seccion = [], ""
    patron = re.compile(r'class="nav-eyebrow">([^<]+)<|<button[^>]*class="nav-btn[^"]*"[^>]*id="([^"]+)"[^>]*>(.*?)</button>',
                        re.S)
    for m in patron.finditer(s):
        if m.group(1):
            seccion = m.group(1).strip()
            continue
        lab = re.search(r'nav-btn__label">(.*?)</span>', m.group(3), re.S)
        etiqueta = re.sub(r"<[^>]+>", "", lab.group(1)).replace("&amp;", "&").strip() if lab else m.group(2)
        salida.append((seccion, m.group(2), etiqueta))
    return salida


def _opciones_cli() -> list[tuple[str, str]]:
    arbol = ast.parse((RAIZ / "agente.py").read_text(encoding="utf-8"))
    salida = []
    for n in ast.walk(arbol):
        if (isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "add_argument"
                and n.args and isinstance(n.args[0], ast.Constant) and str(n.args[0].value).startswith("--")):
            ayuda = next((k.value.value for k in n.keywords
                          if k.arg == "help" and isinstance(k.value, ast.Constant)), "")
            salida.append((n.args[0].value, " ".join(str(ayuda).split())))
    return salida


def _parametros() -> list[tuple[str, str, str, str]]:
    """(constante, variable de entorno, por defecto, descripción) de config/parametros.py."""
    src = (RAIZ / "config" / "parametros.py").read_text(encoding="utf-8")
    lineas = src.splitlines()
    arbol = ast.parse(src)
    publicos = set()
    for n in arbol.body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "__all__" for t in n.targets):
            publicos = {e.value for e in n.value.elts if isinstance(e, ast.Constant)}
    salida = []
    for n in arbol.body:
        if not (isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)):
            continue
        nombre, v = n.targets[0].id, n.value
        while (isinstance(v, ast.Call) and isinstance(v.func, ast.Attribute)
               and isinstance(v.func.value, ast.Call) and v.func.attr in ("lower", "strip", "upper")):
            v = v.func.value
        if not isinstance(v, ast.Call) or not v.args or not isinstance(v.args[0], ast.Constant):
            continue
        func = ast.unparse(v.func)
        if func not in ("_booleano", "_entero", "_decimal", "os.getenv", "os.environ.get"):
            continue
        if publicos and nombre not in publicos:
            continue
        defecto = ast.unparse(v.args[1]) if len(v.args) > 1 else ("False" if func == "_booleano" else "")
        defecto = {"True": "1", "False": "0"}.get(defecto, defecto.strip("'\""))
        comentario = []
        i = n.lineno - 2
        while i >= 0 and lineas[i].lstrip().startswith("#"):
            comentario.insert(0, lineas[i].lstrip("# ").strip())
            i -= 1
        desc = " ".join(re.sub(r"[═─=]{2,}", "", c).strip() for c in comentario)
        desc = " ".join(desc.split())
        salida.append((nombre, str(v.args[0].value), defecto or "—", desc[:170]))
    return salida


def _esc(s: str) -> str:
    return " ".join(str(s or "").split()).replace("|", "\\|")


def construir() -> str:
    from config.ia import PROVEEDORES
    from modulos import validacion_completa as vc
    from web.services import chat_service, roles
    menu = _menu()
    faltan = [i for _, i, _ in menu if i not in MENU and not _ETAPA_BTN.match(i)]
    if faltan:
        raise SystemExit(f"Explica en scripts/generar_guia_uso.py (MENU) las opciones nuevas: {faltan}")
    L: list[str] = []
    a = L.append
    a("# Guía de uso de VIRF Agent")
    a("")
    a("> Generada desde el código por `scripts/generar_guia_uso.py`: no la edites a mano (regénérala). "
      "Instalación: `GUIA_INSTALACION.md`. Notebook de calidad de datos: "
      "`docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md`. Detalle técnico: `REFERENCIA_TECNICA.md`.")
    a("")
    a("## Contenido")
    a("")
    for i, t in enumerate(["Qué es y quién lo usa", "Arrancar", "Recorrido por la web",
                           "Validación normal paso a paso", "Validación completa (etapas 00–04)",
                           "Revisión con el agente (chat)", "Solo informe", "Controles de calidad de datos",
                           "Informe, cuadro y resultados", "IA, proveedores y costes",
                           "Línea de comandos", "Dónde queda cada cosa", "Seguridad y gobierno",
                           "Problemas frecuentes", "Parámetros de configuración"], 1):
        a(f"{i}. {t}")
    a("")
    # 1
    a("## 1. Qué es y quién lo usa")
    a("")
    a("VIRF es un **agente validador de modelos de riesgo** (segunda línea). Lee la evidencia del modelo "
      "(manuales, código, datos, Excels de la primera línea), la contrasta con el **estándar de "
      "validación** de la entidad, la literatura del dominio y el corpus del banco, propone una "
      "evaluación por actividad y un informe Word. **El validador decide**: el agente propone, verifica "
      "sus citas y cifras contra la evidencia y nunca cierra nada por su cuenta.")
    a("")
    a("Roles (los asigna el proveedor de identidad, no el registro local):")
    a("")
    a("| Rol | Puede |")
    a("|---|---|")
    por_rol: dict[str, list[str]] = {}
    for permiso, rs in roles.PERMISOS.items():
        for r in rs:
            por_rol.setdefault(r, []).append(permiso)
    for r in sorted(por_rol):
        a(f"| `{r}` | {', '.join(sorted(por_rol[r]))} |")
    a("")
    a("Cada validador trabaja en **sesiones por modelo**: la evidencia, el estándar, los resultados y "
      "el chat de un modelo no se mezclan con los de otro.")
    a("")
    # 2
    a("## 2. Arrancar")
    a("")
    a("Instalación completa (entorno `.venv`, dependencias, `.env` sin secretos, verificación): "
      "`GUIA_INSTALACION.md`. Para arrancar la web:")
    a("")
    a("```powershell")
    a(".venv\\Scripts\\python scripts\\web_prueba.py --puerto 8000     # prueba local, sin SSO")
    a(".venv\\Scripts\\python -m uvicorn web.app:app --port 8000      # corporativa (SSO Entra ID)")
    a("```")
    a("")
    a("Abre `http://localhost:8000`; `http://localhost:8000/api/salud` debe responder "
      "`{\"estado\":\"ok\"}`. La prueba local (`web_prueba.py`) solo funciona fuera de producción y marca "
      "lo firmado como «usuario de prueba». Usa **siempre** el entorno `.venv`.")
    a("")
    a("Primeros pasos en la web: entra, **crea el modelo** (nombre, **código del modelo**, dominio, tier) "
      "y elige la **modalidad** con el botón de la barra superior: *Validación normal* (pipeline + "
      "estándar) o *Validación completa* (cinco etapas interactivas con notebooks).")
    a("")
    # 3
    a("## 3. Recorrido por la web")
    a("")
    seccion_previa = None
    for seccion, ident, etiqueta in menu:
        if seccion != seccion_previa:
            a("")
            a(f"**{seccion}**")
            a("")
            a("| Opción | Para qué sirve |")
            a("|---|---|")
            seccion_previa = seccion
        m = _ETAPA_BTN.match(ident)
        if m:
            e = vc.ETAPAS[m.group(1)]
            frases, texto = e["mision"].split(". "), ""
            for f in frases:                       # frases hasta tener una idea completa
                texto = f"{texto} {f.strip().rstrip('.')}." if texto else f"{f.strip().rstrip('.')}."
                if len(texto) >= 80:
                    break
            desc = f"Etapa {m.group(1)} · `{e['fichero']}`: {texto}"
        else:
            desc = MENU[ident]
        a(f"| {_esc(etiqueta)} | {_esc(desc)} |")
    a("")
    a("En la barra superior: **Solo informe** (§7), **VIRF PLUS** (segunda opinión de Claude, §10) y "
      "**Modalidad** (normal / completa).")
    a("")
    # 4
    a("## 4. Validación normal paso a paso")
    a("")
    a("| Paso | Qué haces | Qué obtienes |")
    a("|---|---|---|")
    a("| 01 Configuración | Revisa la ficha (código, dominio, tier) y el proveedor de IA. | El agente sabe qué "
      "corpus y qué controles usar. |")
    a("| 02 Estándares | Sube el estándar del modelo (o usa el global). | Actividades a evaluar, por Tier. |")
    a("| 03 Evidencia | Sube manuales, código, datos y Excels con su clasificación. | Evidencia de la sesión. |")
    a("| 04 Dominio & RAG | Comprueba el dominio y su literatura; el corpus del banco va siempre. | "
      "Criterio externo y de la entidad. |")
    a("| 05–06 Skills / Cuestionamientos | Marca análisis y patrones; añade criterios propios. | "
      "Hallazgos transversales y sobre el código. |")
    a("| 07 Pre-vuelo | Ejecútalo SIEMPRE antes de gastar. | Qué se leerá y qué ámbitos quedarían sin evidencia. |")
    a("| 08 Validar modelo | Lanza la corrida. | JSON + Word + Markdown en la sesión; empieza la revisión. |")
    a("| 09 Revisión con el agente | Decide cada observación (§6). | Puntaje final validado y textos claros. |")
    a("| 10 Documentar | Genera el cuadro y el informe Word. | Informe versionado (V1, V2…). |")
    a("")
    # 5
    a("## 5. Validación completa (etapas 00–04)")
    a("")
    a("Cinco chats especializados. En cada iteración el agente **entrega un notebook** "
      "(`<etapa>ITERn.ipynb`); lo ejecutas donde están los datos y genera `<etapa>_resultadoITERn.xlsx`; "
      "se lo devuelves con comentarios e imágenes y recibes el ITERn+1, hasta que la etapa cumple. "
      "**Tú cierras cada etapa** (el agente solo lo recomienda).")
    a("")
    a("| Etapa | Fichero | Misión |")
    a("|---|---|---|")
    for c, e in vc.ETAPAS.items():
        a(f"| {c} · {e['nombre']} | `{e['fichero']}` | {_esc(e['mision'])} |")
    a("")
    from modulos.plantillas_etapa import RUTAS as _rutas
    a("**Ruta paso a paso y experto por chat.** Cada etapa tiene un experto (arquitecto de datos en el 00, "
      "especialista en calidad de datos en el 01, modelador senior en el 02, experto en materialidad en el 03 y "
      "en monitoreo en el 04) y una **ruta** de pasos numerados que el notebook recorre en orden, cada uno con "
      "su hoja en el Excel. La pantalla de la etapa muestra la ruta con el estado de cada paso (cubierto · "
      "parcial · pendiente · no aplica) y VIRF lo **verifica** contra el notebook: la etapa no queda «lista» con "
      "pasos pendientes. Pasos por etapa: "
      + "; ".join(f"{c}: {len(p)}" for c, p in _rutas.items()) + ". Detalle en `docs/GUIA_TIPOS_DE_MODELO.md`.")
    a("")
    a("**Tipo de modelo.** Elígelo en la ficha del modelo (VaR, ES/FRTB, run-off, IRRBB, prepago, NMD, LCR, NSFR, "
      "brechas, LaR…): los cinco chats reciben su ficha de negocio y, sin IA, la plantilla de cada etapa replica "
      "(02), cuantifica impactos (03) y hace backtesting (04) según el tipo. **La etapa 01 entrega el mismo "
      "notebook de calidad de datos de la validación normal** (catálogo, batería, controles de negocio, "
      "repositorio, % de cumplimiento), armado con el perfil que dejó el 00 y con las rutas reales.")
    a("")
    a("**Hallazgos de cada etapa (Excel + .md).** En cada iteración el agente reescribe "
      "`<etapa>_HALLAZGOS.xlsx` y `<etapa>_HALLAZGOS.md` con TODOS los hallazgos de la etapa: estado "
      "vigente, iteración en que nacieron, historial (ITER0 nuevo → ITER1 persiste…) y el **Excel de "
      "sustento** de cada uno (el archivo que lo prueba, con hoja y fila si la evidencia las cita). Se "
      "descargan desde la cabecera de la etapa. Si corriges el Excel tras la última iteración, el "
      "consolidado usa tu corrección.")
    a("")
    a("**Al finalizar:** con las cinco etapas cerradas, pulsa **Consolidar hallazgos**. Se LEEN los Excel "
      "y .md de las cinco etapas, se contrastan (un hallazgo en uno y no en el otro, o con otra severidad, "
      "es una inconsistencia que se informa), se copian los Excel de sustento y se genera "
      "`outputs/validacion_completa/_consolidado/HALLAZGOS_VALIDACION_COMPLETA.xlsx` y `.md`. El cuadro "
      "de observaciones y el anexo del informe Word leen esos entregables.")
    a("")
    a("**Después, la validación final (08 → 09 → 10) con TODO lo de las etapas.** En modalidad completa, "
      "**08 · Validar modelo** solo se lanza con las cinco etapas cerradas (si una no aplica, ciérrala con ese "
      "motivo); su pantalla muestra qué se lleva. Al lanzar, el trabajo de cada etapa pasa a la evidencia que el "
      "barrido lee por ámbito:")
    a("")
    a("| Etapa | Va a | Lo usan |")
    a("|---|---|---|")
    ambitos = {"documentacion/modelamiento": "Documentación, Metodología, Calidad de datos, Gobierno, Implementación",
               "documentacion/seguimiento": "Documentación, Metodología", "calidad_datos": "Calidad de datos"}
    for c, e in vc.ETAPAS.items():
        destino = vc.DESTINO_EVIDENCIA[c]
        extra = (f" + `{vc.DESTINO_CONTROLES_DATOS}/{vc.PREFIJO_CONTROLES_DATOS}{e['fichero']}.xlsx`"
                 if c == "01" else "")
        a(f"| {c} · {e['nombre']} | `{destino}/{vc.SUBCARPETA_PUENTE}/`{extra} | {ambitos[destino]} |")
    a("")
    a("Viajan solo los entregables de VIRF (hallazgos `.md` de cada etapa, el Excel de **resultados** de cada "
      "notebook, el consolidado y un `00_LEEME_VALIDACION_COMPLETA.md`), nunca los datos que enviaste a los "
      "chats. El Excel del 01 lo **puntúa** el ámbito «Calidad de datos», como «Usar estos resultados en la "
      "validación» de los controles de datos. Cada lanzamiento reemplaza lo publicado antes. En **09 · Revisión "
      "con el agente**, cada observación llega con los hallazgos de las etapas que tratan su ámbito y la "
      "búsqueda en la evidencia los encuentra; **10 · Documentar** lleva además el anexo de las etapas.")
    a("")
    # 6
    a("## 6. Revisión con el agente (chat)")
    a("")
    a("Tras *Validar modelo*, el agente abre una conversación con cada observación que requiere "
      "aclaración. Reglas del agente: es estricto con la evidencia pero **consecuente** con lo que dices; "
      "verifica que cada cita, archivo y cifra que usa esté en el material (si no, lo avisa y no aprueba); "
      "para dar algo por subsanado exige un **motivo concreto** (un «ok» no basta); y tras "
      f"{chat_service.MAX_REPREGUNTAS} intentos sin claridad deja la observación PENDIENTE. Toda decisión "
      "queda en la auditoría con quién la tomó (tú o el agente).")
    a("")
    a(chat_service.texto_ayuda().replace("**Cómo trabajar con el agente**\n\n", ""))
    a("")
    a("Botones bajo el chat: *Confirmar observación*, *Subsanada…*, *No aplica…*, *Pendiente…*, *Estado*, "
      "*Reabrir…* y *Ayuda*; 📎 para adjuntar evidencia y *Consolidar* para recomputar el puntaje y "
      "guardar el aprendizaje.")
    a("")
    # 7
    a("## 7. Solo informe")
    a("")
    a("Genera el informe **sin ejecutar el pipeline**, a partir de lo que el validador ya revisó:")
    a("")
    a("1. **Datos de la validación**, incluido el **código del modelo** (sale en la portada y la ficha).")
    a("2. **Estándar con holgura**: cada control del estándar puede marcarse *revisado*, *no aplica* (con "
      "motivo) o *limitación*; se añaden actividades propias; los ámbitos sin actividades para el Tier "
      "(p. ej. Gobierno) aparecen con su nota y con sugerencias del estándar de otros tiers.")
    a("3. **Observaciones** con **varios sustentos** cada una y gráfico estructurado (hallazgo, proceso, "
      "comparación, barras, flujo); lo que no consta en el texto se marca «No consta en el texto».")
    a("4. **Especializar con IA** (opcional): adapta el barrido al contexto y propone actividades y "
      "descripciones; nunca pisa lo que escribió el validador ni su holgura.")
    a("5. **Generar informe**: Word con la plantilla de la entidad.")
    a("")
    # 8
    a("## 8. Controles de calidad de datos")
    a("")
    a("Pega `.info()` y `.describe()` de cada base; el agente entrega un **notebook local** que trae "
      "**siempre todos los controles**: los que se deducen del perfil, los del **tipo de modelo** (VaR, "
      "ALM y LaR no llevan los mismos; incluye los del repositorio del dominio: Kupiec, LCR, CPR…), una "
      "batería completa sobre todas las columnas y una plantilla de cada tipo del catálogo que necesita "
      "un dato del negocio. Calcula el **porcentaje de cumplimiento** (global, ponderado y por grupo) y "
      "acepta controles que ya resolviste en otros notebooks sin reescribirlos. Lo devuelves, el agente "
      "lo revisa y, si lo marcas, **aprende** para los próximos modelos del dominio (con aprobación de un "
      "revisor). Todo —cómo prenderlo, cómo añadir y traer controles y cómo aprende— en "
      "`docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md`.")
    a("")
    # 9
    a("## 9. Informe, cuadro y resultados")
    a("")
    a("* **Documentar** genera el cuadro de observaciones (desde los Excels de etapa en validación "
      "completa) y el informe Word versionado. Generar uno no cierra la sesión.")
    a("* El informe incluye la tabla de validación final con las decisiones del chat y, en validación "
      "completa, el anexo de etapas, la tabla de hallazgos (con su Excel de sustento) y las imágenes.")
    a("* **Resultados** guarda cada corrida: puntajes, Excel, documento, comparación y firma. La firma "
      "usa la identidad con la que entraste; no se firma a nombre de otro.")
    a("")
    # 10
    a("## 10. IA, proveedores y costes")
    a("")
    a("| Proveedor | Estado en la entidad |")
    a("|---|---|")
    for p, est in PROVEEDORES.items():
        a(f"| `{p}` | {est} |")
    a("")
    a("* El agente usa el proveedor **aprobado** (GPT en Azure OpenAI). Las claves salen de la fuente de "
      "secretos (Key Vault), nunca del `.env`.")
    a("* **VIRF PLUS** (opcional): suma a Claude como segunda opinión; los dos evalúan por separado y GPT "
      "concilia. Solo se enciende de forma explícita y mientras Claude esté aprobado.")
    a("* Antes de gastar: **Pre-vuelo** (coste 0) y `--dry-run` en los modos que lo admiten (estima tokens "
      "y coste con el modelo que de verdad correría).")
    a("* Los tests son coste 0: la IA se simula.")
    a("")
    # 11
    a("## 11. Línea de comandos")
    a("")
    a("```powershell")
    a(".venv\\Scripts\\python agente.py --titulo \"VaR Histórico\" --tier 2 --dominio-rag VaR --codigo-modelo MR-VAR-014")
    a(".venv\\Scripts\\python agente.py --prevuelo")
    a("```")
    a("")
    a("| Opción | Qué hace |")
    a("|---|---|")
    for op, ayuda in _opciones_cli():
        a(f"| `{op}` | {_esc(ayuda)[:260]} |")
    a("")
    # 12
    a("## 12. Dónde queda cada cosa")
    a("")
    a("| Ruta | Contenido |")
    a("|---|---|")
    a("| `web/data/sesiones/<validador>/<modelo>/inputs/` | Evidencia de la sesión (por carpetas). |")
    a("| `web/data/sesiones/<validador>/<modelo>/outputs/<fecha>/` | JSON, Word y Markdown de cada corrida. |")
    a("| `…/outputs/validacion_completa/<etapa>/` | Notebooks ITERn, revisiones .md y `<etapa>_HALLAZGOS.xlsx/.md`. |")
    a("| `…/outputs/validacion_completa/_consolidado/` | Consolidado final de hallazgos y Excel de sustento. |")
    a("| `…/outputs/controles_ia/` | Propuestas, notebooks y revisiones de controles de datos. |")
    a("| `…/chat_historial.json` | Conversación y decisiones de la revisión con el agente. |")
    a("| `feedback/` | Aprendizaje (feedback de puntajes y lecciones de controles), solo-anexar y sellado. |")
    a("| `audit_logs/` | Registro de emisiones y auditoría. |")
    a("| `inputs/rag/` | Corpus del RAG por dominio y del banco. |")
    a("| `inputs/repositorio_controles/` | Controles especializados por dominio (funciones Python). |")
    a("")
    # 13
    a("## 13. Seguridad y gobierno")
    a("")
    a("* Toda evidencia se sube con **clasificación** (Público, Interno, Restringido).")
    a("* Las claves de IA, en Key Vault; el `.env` solo lleva configuración.")
    a("* La salida al proveedor de IA pasa por un gateway que enmascara datos personales y trata la "
      "evidencia como material no confiable (anti-inyección).")
    a("* Lo que sube el puntaje (subsanar en el chat, aprender controles, aprobar feedback) exige motivo y, "
      "cuando aplica, la aprobación de un **revisor** distinto del autor.")
    a("* Los registros de feedback, aprendizaje y auditoría están sellados por cadena de hashes.")
    a("* El inventario de componentes de IA (`docs/seguridad/GOBIERNO_RIESGO_IA.md`) lo mantiene la entidad.")
    a("")
    # 14
    a("## 14. Problemas frecuentes")
    a("")
    a("| Síntoma | Qué hacer |")
    a("|---|---|")
    a("| La web dice que el proveedor no está autorizado | El proveedor del `.env` no está APROBADO: usa `azure_openai`. |")
    a("| «falta la clave en la fuente de secretos» | Configura el secreto en Key Vault (o, en desarrollo, la variable de entorno del proceso). |")
    a("| Un ámbito puntúa 0 | No tenía evidencia: revisa el Pre-vuelo y sube lo que falta. |")
    a("| El chat no aprueba aunque respondiste | Falta un motivo concreto (qué, dónde o por qué), o una cita no se encontró en la evidencia: lo dice en su mensaje. |")
    a("| «No pude consultar al modelo» en el chat | Fallo técnico (no gasta intentos ni decide): reenvía o decide tú. |")
    a("| El consolidado de la validación completa avisa inconsistencias | El Excel y el .md de una etapa no coinciden: corrige el Excel (manda) o pide otra iteración. |")
    a("| El notebook de controles no prende | Ver `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md` §4 (tabla «Si algo falla»). |")
    a("")
    # 15
    a("## 15. Parámetros de configuración")
    a("")
    a("Se declaran en `config/parametros.py` y se fijan como variables de entorno (o en `.env`, nunca "
      "secretos). Valor por defecto del código:")
    a("")
    a("| Constante | Variable | Por defecto | Qué controla |")
    a("|---|---|---|---|")
    for nombre, var, defecto, desc in _parametros():
        a(f"| `{nombre}` | `{var}` | `{_esc(defecto)[:40]}` | {_esc(desc)} |")
    return "\n".join(L).rstrip() + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--comprobar", action="store_true",
                    help="no escribe: sale con 1 si la guía no coincide con el código")
    args = ap.parse_args()
    texto = construir()
    if args.comprobar:
        actual = DESTINO.read_text(encoding="utf-8") if DESTINO.is_file() else ""
        if actual != texto:
            print("GUIA_USO.md está desactualizada: python scripts/generar_guia_uso.py")
            return 1
        print("guía al día")
        return 0
    DESTINO.write_text(texto, encoding="utf-8", newline="\n")
    print(f"escrita {DESTINO.name} ({len(texto.splitlines())} líneas)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
