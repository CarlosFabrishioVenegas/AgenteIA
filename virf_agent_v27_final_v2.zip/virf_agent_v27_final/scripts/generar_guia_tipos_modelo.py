"""
scripts/generar_guia_tipos_modelo.py — Guía de los TIPOS DE MODELO y de la
RUTA PASO A PASO de la validación completa.

Genera `docs/GUIA_TIPOS_DE_MODELO.md` desde el propio código: las fichas de
negocio (`modulos/tipos_modelo_trading.py`, `tipos_modelo_alm.py`,
`tipos_modelo_liquidez.py`), los roles (`modulos/tipos_modelo.py`), los
análisis del repositorio (`inputs/repositorio_controles/`), los expertos y las
rutas de cada etapa (`modulos/plantillas_etapa.py`) y la librería cuantitativa
(`modulos/libreria_cuant.py`). Un test exige que esté al día.

Uso:
    .venv\\Scripts\\python scripts\\generar_guia_tipos_modelo.py              # escribe la guía
    .venv\\Scripts\\python scripts\\generar_guia_tipos_modelo.py --comprobar  # 1 si está desactualizada

No llama a ninguna IA ni ejecuta notebooks.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

DESTINO = RAIZ / "docs" / "GUIA_TIPOS_DE_MODELO.md"


def _esc(s) -> str:
    return " ".join(str(s or "").split()).replace("|", "\\|")


def construir() -> str:
    from modulos import tipos_modelo as tm
    from modulos.libreria_cuant import FUNCIONES_CUANT
    from modulos.plantillas_etapa import EXPERTOS, RUTAS
    from modulos.repositorio_controles import cargar_controles
    from modulos.validacion_completa import ETAPAS
    L: list[str] = []
    a = L.append
    a("# Guía de tipos de modelo y de la ruta de la validación completa")
    a("")
    a("> Generada desde el código por `scripts/generar_guia_tipos_modelo.py`: no la edites a mano "
      "(regénérala). Para añadir un tipo de modelo, edita su ficha en `modulos/tipos_modelo_<familia>.py`.")
    a("")
    a("## Contenido")
    a("")
    a("1. Qué es el tipo de modelo y dónde se usa")
    a("2. La ruta paso a paso de cada etapa (00–04)")
    a("3. Los tipos de modelo, uno por uno")
    a("4. Roles (conceptos de negocio) y cómo se enlazan")
    a("5. Librería cuantitativa de los notebooks de las etapas")
    a("6. Cómo añadir un tipo de modelo")
    a("")
    a("## 1. Qué es el tipo de modelo y dónde se usa")
    a("")
    a("El **dominio** (VaR · ALM · LaR) dice la familia; el **tipo de modelo** dice qué hace el modelo y, por "
      "tanto, qué hay que revisar: un VaR no se valida como un run-off, ni un prepago como un LCR. Lo elige el "
      "validador en la ficha del modelo (**Nuevo modelo** o **Configuración → Tipo de modelo**; se pueden elegir "
      "varios) y **nunca se deduce** de los datos. Con él:")
    a("")
    a("* el **notebook de calidad de datos** (validación normal y etapa 01) trae *Entender el modelo* (negocio, "
      "bases, qué puede fallar, qué pedir a la primera línea), los **controles de negocio por roles** (`M…`) y "
      "solo los análisis del repositorio de ese tipo;")
    a("* los **5 chats de la validación completa** reciben la ficha del tipo y los pasos de experto de su etapa; "
      "sin IA, la plantilla de cada etapa **replica** (02), **cuantifica** (03) y **hace backtesting** (04) según "
      "el tipo.")
    a("")
    a(f"Hay **{len(tm.TIPOS)} tipos** en tres familias, con **{sum(len(t['controles']) for t in tm.TIPOS.values())} "
      f"controles de negocio** y **{len(tm.ROLES)} roles**.")
    a("")
    a("| Tipo | Familia | Carpeta del repositorio | Bases lógicas | Controles de negocio |")
    a("|---|---|---|---|---|")
    for tid, t in tm.TIPOS.items():
        a(f"| **{_esc(t['nombre'])}** (`{tid}`) | {t['familia']} | `{t['carpeta']}/` | "
          f"{', '.join(b['id'] for b in t['bases'])} | {len(t['controles'])} |")
    a("")
    a("## 2. La ruta paso a paso de cada etapa (00–04)")
    a("")
    a("Cada chat de la validación completa recorre su **ruta**. El agente declara el estado de cada paso "
      "(cubierto · parcial · pendiente · no aplica, con motivo) y **VIRF lo verifica**: un paso «cubierto» cuyo "
      "título «## Paso XX.n» no está en el notebook pasa a «pendiente», y la etapa no puede quedar «lista» con "
      "pasos pendientes. La web muestra la ruta con el estado de la última iteración.")
    a("")
    for c, e in ETAPAS.items():
        a(f"### {c} · {e['nombre']}")
        a("")
        a(f"**Experto:** {EXPERTOS[c]}")
        a("")
        a("| Paso | Qué se hace | Hoja del Excel | Cubierto si |")
        a("|---|---|---|---|")
        for p, ti, q, h, crit in RUTAS[c]:
            a(f"| **{p}** · {_esc(ti)} | {_esc(q)} | {_esc(h)} | {_esc(crit)} |")
        a("")
    a("## 3. Los tipos de modelo, uno por uno")
    a("")
    for tid, t in tm.TIPOS.items():
        a(f"### {t['nombre']} (`{tid}`)")
        a("")
        a(f"*Familia {t['familia']} · repositorio `{t['carpeta']}/`*")
        a("")
        a("**Qué hace el modelo.** " + t["negocio"])
        a("")
        if t.get("salidas"):
            a("**Qué produce:** " + "; ".join(t["salidas"]) + ".")
            a("")
        if t.get("usos"):
            a("**Para qué se usa:** " + "; ".join(t["usos"]) + ".")
            a("")
        a("**Bases lógicas**")
        a("")
        a("| Base | Granularidad | Roles | La definen | Para qué |")
        a("|---|---|---|---|---|")
        for b in t["bases"]:
            a(f"| **{_esc(b['nombre'])}** (`{b['id']}`){' · solo si el archivo se llama así' if b.get('solo_por_nombre') else ''}"
              f" | {_esc(b.get('granularidad'))} | {', '.join(f'`{r}`' for r in b['roles'])} | "
              f"{', '.join(f'`{r}`' for r in b.get('define', []))} | {_esc(b.get('para_que'))} |")
        a("")
        a("**Qué puede fallar en los datos**")
        a("")
        for r in t["riesgos"]:
            a(f"- {r}")
        a("")
        a("**Controles de negocio (notebook de calidad, ids `M…`)**")
        a("")
        a("| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |")
        a("|---|---|---|---|---|")
        for c in t["controles"]:
            roles = ", ".join(c["roles"] + [f"({x})" for x in c.get("opcionales", [])])
            ref = f" → `{c['ref']['base']}`" if c.get("ref") else ""
            a(f"| `{c['base']}` · {roles}{ref} | `{c['tipo']}`{' (plantilla)' if c.get('plantilla') else ''} | "
              f"{_esc(c['que'])} | {_esc(c['por_que'])} | {c['criticidad']} |")
        a("")
        cs, _ = cargar_controles(t["carpeta"])
        repo = [x for x in cs if x["dominio_carpeta"] == t["carpeta"]
                and (not (x["meta"] or {}).get("tipos") or tid in x["meta"]["tipos"])]
        if repo:
            a("**Análisis del repositorio (ids `D…`)**")
            a("")
            for x in repo:
                a(f"- `{t['carpeta']}/{x['archivo']}` — {_esc((x['meta'] or {}).get('descripcion'))}")
            a("")
        a("**Qué pedir a la primera línea**")
        a("")
        for i, p in enumerate(t.get("preguntas", []), 1):
            a(f"{i}. {p}")
        a("")
        a("**Qué mira el experto en cada etapa**")
        a("")
        for c, pasos in t.get("etapas", {}).items():
            a(f"- **{c} · {ETAPAS[c]['nombre']}:** " + " ".join(pasos))
        a("")
        if t.get("metricas"):
            a("**Métricas que se replican (02) y vigilan (04):** " + "; ".join(t["metricas"]) + ".")
            a("")
        if t.get("normativa"):
            a("**Referencias:** " + "; ".join(t["normativa"]) + ".")
            a("")
    a("## 4. Roles (conceptos de negocio) y cómo se enlazan")
    a("")
    a("Un **rol** es el concepto que cumple una columna (P&L, saldo, banda, tasa de salida…). Los controles de "
      "negocio se escriben por roles, no por nombres de columna: VIRF enlaza cada rol con una columna real por su "
      "nombre (patrón) y su tipo de dato, y el notebook lo muestra en `BASES` (base lógica → base de RUTAS) y "
      "`ROLES` (base → rol → columna) para que el validador lo confirme o lo corrija una sola vez. Lo confirmado "
      "en las hojas *Diccionario* (00) o *Roles* (01) manda en las etapas siguientes.")
    a("")
    a("| Rol | Familia de dato | Qué es |")
    a("|---|---|---|")
    for r, m in tm.ROLES.items():
        a(f"| `{r}` | {m['familia']} | {_esc(m['que'])} |")
    a("")
    a("## 5. Librería cuantitativa de los notebooks de las etapas")
    a("")
    a("Los notebooks de las etapas 00–04 traen una celda de soporte con `BASES`, `ROLES`, la carga de las "
      "bases de `RUTAS` en `bases` y esta librería (solo pandas y numpy; la usa también el agente con IA):")
    a("")
    for f in FUNCIONES_CUANT.split(" · "):
        a(f"- `{f.strip()}`")
    a("")
    a("## 6. Cómo añadir un tipo de modelo")
    a("")
    a("1. En `modulos/tipos_modelo_<familia>.py`, añade una entrada a `TIPOS` con `nombre`, `familia`, "
      "`carpeta`, `negocio`, `bases` (con `roles` y `define`), `riesgos`, `controles` (por roles, con `que` y "
      "`por_que`), `preguntas`, `etapas` (00–04) y `metricas`.")
    a("2. Si necesita un concepto nuevo, añade el rol a `ROLES` en `modulos/tipos_modelo.py` (patrón, familia, "
      "qué es).")
    a("3. Si necesita un análisis propio, crea un `.py` en `inputs/repositorio_controles/<carpeta>/` con "
      "`META[\"tipos\"] = [\"<tipo>\"]`.")
    a("4. Si quieres réplica sin IA, añade su bloque en `modulos/plantillas_etapa.py` (`_REPLICA`, `_METRICA`, "
      "`_BACKTEST`).")
    a("5. Regenera esta guía y la del notebook de calidad de datos; `tests/test_tipos_modelo.py` comprueba la "
      "ficha y que sus notebooks corren con datos sintéticos.")
    a("")
    return "\n".join(L) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--comprobar", action="store_true", help="sale con 1 si la guía no está al día")
    args = ap.parse_args()
    texto = construir()
    if args.comprobar:
        actual = DESTINO.read_text(encoding="utf-8") if DESTINO.is_file() else ""
        if actual != texto:
            print(f"{DESTINO.relative_to(RAIZ)} está desactualizada: python scripts/generar_guia_tipos_modelo.py")
            return 1
        print(f"{DESTINO.relative_to(RAIZ)} al día.")
        return 0
    DESTINO.parent.mkdir(parents=True, exist_ok=True)
    DESTINO.write_text(texto, encoding="utf-8", newline="\n")
    print(f"Escrita {DESTINO.relative_to(RAIZ)} ({len(texto.splitlines())} líneas).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
