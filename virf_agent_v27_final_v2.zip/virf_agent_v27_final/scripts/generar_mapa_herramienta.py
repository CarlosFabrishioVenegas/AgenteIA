#!/usr/bin/env python3
"""
scripts/generar_mapa_herramienta.py — Mapa completo de VIRF Agent, generado desde el código.

    .venv\\Scripts\\python scripts/generar_mapa_herramienta.py              # escribe docs/MAPA_HERRAMIENTA.md
    .venv\\Scripts\\python scripts/generar_mapa_herramienta.py --sin-git    # sin historial ni árbol de trabajo
    .venv\\Scripts\\python scripts/generar_mapa_herramienta.py --comprobar  # código 1 si la parte estable quedó vieja

Recorre la herramienta tal como está: el menú de la web, las modalidades y las cinco etapas (experto,
ruta y puente a 08–10), los tipos de modelo, el catálogo de controles de datos, el repositorio por
dominio, la librería cuantitativa, la API con sus mensajes de error, los módulos por capa, la CLI, los
parámetros, los scripts y la documentación; después de la marca «volátil», las pruebas y —con git— el
historial de commits y el trabajo sin commitear. Nada de lo listado se ejecuta: el código se lee con
`ast` y los catálogos se importan. Es la fuente para presentaciones y traspasos: si la herramienta
cambia, se regenera, no se edita a mano. No llama a ninguna IA.
"""
from __future__ import annotations

import argparse
import ast
import importlib.util
import re
import subprocess
import sys
from collections import Counter, defaultdict
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
for _p in (RAIZ, RAIZ / "motor"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

DESTINO = RAIZ / "docs" / "MAPA_HERRAMIENTA.md"
MARCA_VOLATIL = "<!-- volatil: lo que sigue cambia con cada prueba o commit (no lo compara el test) -->"

#: Capas del código (patrones relativos a la raíz) y para qué sirve cada una.
CAPAS = [
    ("Entrada y verificadores", ["agente.py", "validate_project.py", "verificador_virf.py"],
     "La CLI del pipeline y los verificadores del proyecto."),
    ("Motor del pipeline", ["motor/*.py"],
     "Carga de rutas, lectura de evidencias, prompt por ámbito, llamada a la IA y controles de datos."),
    ("Módulos de negocio", ["modulos/*.py"],
     "Validación completa, notebooks, controles, tipos de modelo, informe, salvaguardas, custodia."),
    ("Web · routers", ["web/routers/*.py"], "Endpoints FastAPI (validan la entrada y devuelven JSON o archivos)."),
    ("Web · servicios", ["web/services/*.py"], "Sesiones, chat, informe, pipeline, roles, prompts, Solo Informe."),
    ("Configuración", ["config/*.py"], "Parámetros, proveedores de IA, rutas, identidad, red y dominio."),
    ("RAG léxico", ["src/rag/*.py", "src/rag/*/*.py"], "BM25 + TF-IDF por dominio, sin embeddings."),
    ("Skills del agente", ["skills/*.py", "modulos/skills/*.py"], "Capacidades tipadas del pipeline."),
]

#: Documentos que NO se escriben a mano (y su generador).
GENERADAS = {
    "GUIA_USO.md": "scripts/generar_guia_uso.py",
    "docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md": "scripts/generar_guia_calidad_datos.py",
    "docs/GUIA_TIPOS_DE_MODELO.md": "scripts/generar_guia_tipos_modelo.py",
    "docs/MAPA_HERRAMIENTA.md": "scripts/generar_mapa_herramienta.py",
    "INVENTARIO_ARCHIVOS.md": "scripts/generar_inventario_archivos.py",
    "REFERENCIA_TECNICA.md": "scripts/generar_referencia_tecnica.py",
}

#: Nombre legible de cada área de la API (primer segmento tras /api/).
AREAS_API = {
    "auth": "Entrada y sesión", "modelos": "Modelos y tipos de modelo", "config": "Configuración del modelo y la IA",
    "estandares": "Estándar de validación", "upload": "Evidencia", "evidencia": "Evidencia", "rag": "Dominio y RAG",
    "skills": "Skills", "cuestionamientos": "Cuestionamientos", "prevuelo": "Pre-vuelo", "validar": "08 · Validar",
    "chat": "09 · Revisión con el agente", "informe": "10 · Documentar", "resultados": "Resultados",
    "motores": "Controles de datos", "completa": "Validación completa", "solo-informe": "Solo Informe",
    "automatizaciones": "Cuadro de automatizaciones", "guia": "Guía de progreso", "prompts": "Prompts editables",
    "debug": "Diagnóstico de conexiones", "codigo": "Análisis de código", "entendimiento": "Entendimiento del modelo",
    "feedback": "Aprobación de feedback", "salud": "Salud", "dominios": "Dominios",
}


def _esc(s) -> str:
    return " ".join(str(s if s is not None else "").split()).replace("|", "\\|")


def _corto(s, n: int = 160) -> str:
    t = _esc(s)
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def _primera_frase(s: str, n: int = 220) -> str:
    t = " ".join(str(s or "").split())
    m = re.search(r"^(.+?[.!?])(\s|$)", t)
    return _corto(m.group(1) if m else t, n)


def _cargar(nombre: str):
    spec = importlib.util.spec_from_file_location(nombre, RAIZ / "scripts" / f"{nombre}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _rel(p: Path) -> str:
    return p.relative_to(RAIZ).as_posix()


def _doc1(ruta: Path) -> str:
    """Primera línea útil del docstring del archivo (sin la ruta ni adornos)."""
    try:
        arbol = ast.parse(ruta.read_text(encoding="utf-8", errors="replace"))
    except (SyntaxError, ValueError):
        return ""
    for linea in (ast.get_docstring(arbol) or "").splitlines():
        t = linea.strip().strip("═─=#*").strip()
        t = re.sub(r"^[\w./\\-]+\.py\s*(?:[—–:-]\s*|$)", "", t).strip()
        if t and not re.fullmatch(r"[\w./\\-]+", t):
            return _corto(t, 170)
    return ""


def _archivos(patrones: list[str]) -> list[Path]:
    vistos, salida = set(), []
    for pat in patrones:
        for p in sorted(RAIZ.glob(pat)):
            if p.is_file() and p.name != "__init__.py" and p not in vistos:
                vistos.add(p)
                salida.append(p)
    return salida


# ─── Extractores ────────────────────────────────────────────────────────────

def _rutas(rutas=None, prefijo: str = ""):
    """(ruta, método, route) de la app, entrando en los routers incluidos (FastAPI ≥ 0.13x los anida)."""
    if rutas is None:
        from web.app import app
        rutas = app.routes
    for r in rutas:
        orig = getattr(r, "original_router", None)
        if orig is not None:
            ctx = getattr(r, "include_context", None)
            yield from _rutas(orig.routes, prefijo + (getattr(ctx, "prefix", "") or ""))
            continue
        path = getattr(r, "path", None)
        if path is None:
            continue
        metodos = sorted(m for m in (getattr(r, "methods", None) or []) if m not in ("HEAD", "OPTIONS"))
        for m in metodos or (["WS"] if path.startswith("/ws") else []):
            yield prefijo + path, m, r


def _endpoints() -> list[tuple[str, str, str, str]]:
    """(área, método, ruta, qué hace) únicos y ordenados."""
    vistos, salida = set(), []
    for ruta, metodo, r in _rutas():
        if (metodo, ruta) in vistos or ruta.startswith(("/static", "/docs", "/redoc", "/openapi")):
            continue
        vistos.add((metodo, ruta))
        partes = [x for x in ruta.split("/") if x]
        if partes[:1] == ["api"] and len(partes) > 1:
            area = AREAS_API.get(partes[1], partes[1])
        elif partes[:1] == ["ws"]:
            area = "Tiempo real (WebSocket)"
        else:
            area = "Páginas"
        fn = getattr(r, "endpoint", None)
        doc = (fn and fn.__doc__) or ""
        que = _primera_frase(doc, 150) if doc.strip() else (f"`{fn.__name__}`" if fn else "—")
        salida.append((area, metodo, ruta, que))
    return sorted(salida, key=lambda x: (x[0], x[2], x[1]))


def _texto_ast(n) -> str:
    if isinstance(n, ast.Constant) and isinstance(n.value, str):
        return n.value
    if isinstance(n, ast.JoinedStr):
        return "".join(v.value if isinstance(v, ast.Constant) else "{…}" for v in n.values)
    if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Add):
        return _texto_ast(n.left) + _texto_ast(n.right)
    return "{…}"


class _Errores(ast.NodeVisitor):
    def __init__(self, archivo: str):
        self.archivo, self.funcion, self.filas = archivo, "", []

    def _func(self, nodo):
        previa, self.funcion = self.funcion, nodo.name
        self.generic_visit(nodo)
        self.funcion = previa

    visit_FunctionDef = visit_AsyncFunctionDef = _func

    def visit_Call(self, nodo):
        f = nodo.func
        nombre = f.id if isinstance(f, ast.Name) else (f.attr if isinstance(f, ast.Attribute) else "")
        if nombre == "HTTPException":
            cod = nodo.args[0] if nodo.args else next((k.value for k in nodo.keywords if k.arg == "status_code"), None)
            msg = nodo.args[1] if len(nodo.args) > 1 else next((k.value for k in nodo.keywords if k.arg == "detail"), None)
            if isinstance(cod, ast.Constant) and isinstance(cod.value, int):
                self.filas.append((self.archivo, self.funcion or "—", cod.value,
                                   _texto_ast(msg) if msg is not None else ""))
        self.generic_visit(nodo)


def _errores_web() -> list[tuple[str, str, int, str]]:
    filas = []
    for p in _archivos(["web/routers/*.py", "web/services/*.py"]):
        try:
            arbol = ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        v = _Errores(_rel(p))
        v.visit(arbol)
        filas += v.filas
    unicas = sorted(set(filas), key=lambda x: (x[0], x[2], x[1], x[3]))
    return unicas


def _tests_en(ruta: Path) -> int:
    try:
        arbol = ast.parse(ruta.read_text(encoding="utf-8", errors="replace"))
    except SyntaxError:
        return 0
    return sum(1 for n in ast.walk(arbol)
               if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith("test_"))


def _git(*args: str) -> str:
    try:
        r = subprocess.run(["git", *args], cwd=str(RAIZ), capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=60)
    except (OSError, subprocess.SubprocessError):
        return ""
    return r.stdout if r.returncode == 0 else ""


# ─── Construcción ───────────────────────────────────────────────────────────

def _parte_estable() -> list[str]:
    from modulos import controles_ia as ci
    from modulos import plantillas_etapa as pe
    from modulos import validacion_completa as vc
    from modulos.libreria_cuant import FUNCIONES_CUANT
    from modulos.repositorio_controles import cargar_controles
    from modulos.tipos_modelo import TIPOS

    guia = _cargar("generar_guia_uso")
    menu = guia._menu()
    endpoints = _endpoints()
    errores = _errores_web()
    cli = guia._opciones_cli()
    parametros = guia._parametros()
    carpetas_repo = sorted(d.name for d in (RAIZ / "inputs" / "repositorio_controles").iterdir() if d.is_dir()
                           and not d.name.startswith(("_", ".")))
    # cargar_controles(carpeta) suma también shared/ (y con «shared» lo trae dos veces): cada control,
    # una sola vez y solo en SU carpeta.
    repo = {c: list({x["nombre"]: x for x in cargar_controles(c)[0] if x["dominio_carpeta"] == c}.values())
            for c in carpetas_repo}
    funciones = [f.strip() for f in FUNCIONES_CUANT.split(" · ") if f.strip()]
    capas = [(n, _archivos(pats), que) for n, pats, que in CAPAS]
    scripts = _archivos(["scripts/*.py"])
    docs = _archivos(["*.md", "docs/*.md", "docs/**/*.md", "docs/agente_corporativo/skills/*.md",
                      ".claude/skills/*/SKILL.md", ".claude/skills/*/references/*.md"])
    docs = [d for d in docs if "capturas" not in d.parts]

    o: list[str] = []
    a = o.append
    a("# Mapa completo de VIRF Agent")
    a("")
    a("> Generado por `scripts/generar_mapa_herramienta.py` desde el código: no se edita a mano. Si la "
      "herramienta cambia, `.venv\\Scripts\\python scripts/generar_mapa_herramienta.py`. Es la fuente para "
      "presentaciones, traspasos y soporte; el detalle de uso está en `GUIA_USO.md` y el de cada tipo de "
      "modelo en `docs/GUIA_TIPOS_DE_MODELO.md`.")
    a("")
    a("## Índice")
    a("")
    for i, t in enumerate(["VIRF en cifras", "Qué es y cómo se recorre", "El menú de la web",
                           "Validación normal y validación completa", "Las cinco etapas: experto, ruta y entregable",
                           "Puente a la validación final (08 · 09 · 10)", "Tipos de modelo",
                           "Notebook de calidad de datos: capas y catálogo", "Repositorio de controles por dominio",
                           "Librería cuantitativa de los notebooks", "API de la web", "Mensajes de error de la web",
                           "Código por capa", "Línea de comandos (agente.py)", "Parámetros", "Scripts",
                           "Documentación", "Pruebas (volátil)", "Historial y trabajo sin commitear (volátil)"], 1):
        a(f"{i}. {t}")
    a("")

    # 1. Cifras
    a("## 1. VIRF en cifras")
    a("")
    a("| Qué | Cuántos |")
    a("|---|---|")
    a(f"| Opciones del menú de la web | {len(menu)} |")
    a(f"| Endpoints (método + ruta) | {len(endpoints)} |")
    a(f"| Mensajes de error distintos que devuelve la web | {len(errores)} |")
    for n, archivos, _ in capas:
        a(f"| Archivos en «{n}» | {len(archivos)} |")
    a(f"| Etapas de la validación completa | {len(vc.ETAPAS)} |")
    a(f"| Tipos de modelo (fichas de negocio) | {len(TIPOS)} |")
    a(f"| Controles de negocio en las fichas (`M`) | {sum(len(t['controles']) for t in TIPOS.values())} |")
    a(f"| Tipos de control del catálogo de calidad de datos | {len(ci.CATALOGO)} |")
    a(f"| Análisis del repositorio por dominio (`D`) | {sum(len(v) for v in repo.values())} "
      f"({', '.join(f'{c}: {len(v)}' for c, v in repo.items())}) |")
    a(f"| Funciones de la librería cuantitativa | {len(funciones)} |")
    a(f"| Opciones de la CLI de `agente.py` | {len(cli)} |")
    a(f"| Parámetros de `config/parametros.py` | {len(parametros)} |")
    a(f"| Scripts | {len(scripts)} |")
    a(f"| Documentos Markdown | {len(docs)} |")
    a("")

    # 2. Qué es
    a("## 2. Qué es y cómo se recorre")
    a("")
    a("VIRF es el agente de validación de modelos de riesgo financiero (VaR, ALM, liquidez) de la segunda "
      "línea de defensa. Recibe la evidencia de un modelo, la contrasta contra un estándar de validación por "
      "ámbitos, conversa con el validador para sustentar cada observación y emite un informe Word. Tiene una "
      "web (FastAPI + JavaScript sin framework) y una CLI (`agente.py`); la IA aprobada es Azure OpenAI y el "
      "RAG es léxico (BM25 + TF-IDF). En **validación completa**, cinco etapas con notebooks que el validador "
      "ejecuta donde están los datos preceden al barrido de controles.")
    a("")
    proc = [(i, e) for s, i, e in menu if s.lower().startswith("procedimiento")]
    comp = [(i, e) for s, i, e in menu if "completa" in s.lower()]
    a("```mermaid")
    a("flowchart LR")
    for k, (_, e) in enumerate(proc):
        a(f'  p{k}["{e}"]' + (f" --> p{k + 1}" if k + 1 < len(proc) else ""))
    if comp:
        a('  subgraph completa["Validación completa"]')
        for k, (_, e) in enumerate(comp):
            a(f'    c{k}["{e}"]' + (f" --> c{k + 1}" if k + 1 < len(comp) else ""))
        a("  end")
        destino = next((k for k, (i, _) in enumerate(proc) if i == "btn-validar"), None)
        if destino is not None:
            a(f'  c{len(comp) - 1} -->|"5 etapas cerradas: su trabajo pasa a la evidencia"| p{destino}')
    a("```")
    a("")

    # 3. Menú
    a("## 3. El menú de la web")
    a("")
    a("| Sección | Opción | Qué hace |")
    a("|---|---|---|")
    for s, i, e in menu:
        a(f"| {_esc(s)} | {_esc(e)} (`{i}`) | {_corto(guia.MENU.get(i, ''), 240)} |")
    a("")

    # 4. Modalidades
    a("## 4. Validación normal y validación completa")
    a("")
    a("La modalidad es **explícita** en la ficha del modelo (`modalidad`: `normal` o `completa`); nunca se "
      "deduce.")
    a("")
    a("| | Normal | Completa |")
    a("|---|---|---|")
    a("| Antes del barrido | Estándar, evidencia, dominio y pre-vuelo | Lo mismo + insumos y las cinco etapas "
      "00–04 con notebooks iterados |")
    a("| Barrido de controles (08) | Se lanza con la evidencia subida | Solo con las cinco etapas cerradas; su "
      "trabajo se publica antes en la evidencia por ámbito |")
    a("| Calidad de datos | Notebook de «Controles de datos» (opcional: «Usar en la validación») | El Excel "
      "del notebook del 01 se puntúa en el ámbito «Calidad de datos» |")
    a("| Revisión con el agente (09) | Observaciones del barrido | Lo mismo + los hallazgos de las etapas del "
      "ámbito de cada observación |")
    a("| Documentar (10) | Informe Word | Informe Word + anexo de etapas, hallazgos e imágenes |")
    a("")

    # 5. Etapas
    a("## 5. Las cinco etapas: experto, ruta y entregable")
    a("")
    a("En cada iteración el agente entrega `{etapa}ITERn.ipynb`; el validador lo ejecuta donde están los "
      "datos y devuelve `{etapa}_resultadoITERn.xlsx` con comentarios e imágenes. La ruta se verifica contra "
      "los títulos «## Paso XX.n» del notebook; sin pasos cubiertos no hay veredicto «lista».")
    a("")
    for c, e in vc.ETAPAS.items():
        a(f"### {c} · {e['nombre']}")
        a("")
        a(f"- **Experto:** {_primera_frase(pe.EXPERTOS.get(c, ''), 300)}")
        a(f"- **Misión:** {_primera_frase(e.get('mision', ''), 300)}")
        a(f"- **Tabla que entrega:** {_esc(e.get('tabla', ''))} · usa las etapas previas: "
          f"{', '.join(e.get('previas') or []) or '—'}")
        a(f"- **Va a la evidencia de la validación final:** `{vc.DESTINO_EVIDENCIA[c]}/{vc.SUBCARPETA_PUENTE}/`")
        a("")
        a("| Paso | Qué | Hoja |")
        a("|---|---|---|")
        for p in pe.ruta(c):
            a(f"| {p['paso']} {_esc(p['titulo'])} | {_corto(p.get('que', ''), 150)} | {_esc(p.get('hoja', ''))} |")
        a("")

    # 6. Puente
    a("## 6. Puente a la validación final (08 · 09 · 10)")
    a("")
    a("`POST /api/validar/lanzar` en un modelo de modalidad completa responde 409 si falta cerrar alguna etapa; "
      "con las cinco cerradas llama a `modulos/validacion_completa.py::publicar_en_validacion`, que consolida "
      "los hallazgos y copia **solo entregables de VIRF** (nunca los datos enviados a los chats). Cada "
      "lanzamiento reemplaza lo publicado. La pantalla del 08 lo enseña antes con `GET /api/completa/paquete`.")
    a("")
    a("| Etapa | Carpeta de evidencia | Excel de resultados |")
    a("|---|---|---|")
    for c, e in vc.ETAPAS.items():
        carpeta, excel = vc._destinos(c)
        a(f"| {c} · {e['nombre']} | `{carpeta}/` | `{excel}` |")
    a("")
    a(f"Además: `{vc.DESTINO_EVIDENCIA['00']}/{vc.SUBCARPETA_PUENTE}/{vc.NOMBRE_LEEME}` (qué es cada archivo) y "
      "el consolidado `HALLAZGOS_VALIDACION_COMPLETA.md`. El Excel del 01 lo puntúa el ámbito «Calidad de datos» "
      "(`modulos/motores_entidad.py`). En el chat 09, cada observación recibe los hallazgos de las etapas de "
      "su ámbito:")
    a("")
    a("| Ámbito | Etapas |")
    a("|---|---|")
    for amb, ets in vc.ETAPAS_POR_AMBITO.items():
        a(f"| {amb} | {', '.join(ets)} |")
    a("")

    # 7. Tipos de modelo
    a("## 7. Tipos de modelo")
    a("")
    a("El tipo se elige **explícito** en la ficha del modelo (`tipos_modelo`). Cada ficha trae bases lógicas "
      "con roles de negocio, controles con su porqué, preguntas a la primera línea, pasos de experto por etapa "
      "y métricas. Detalle completo: `docs/GUIA_TIPOS_DE_MODELO.md`.")
    a("")
    a("| Familia | Tipo | Bases lógicas | Controles `M` | Análisis del repositorio (`D`) |")
    a("|---|---|---|---|---|")
    for tid, t in sorted(TIPOS.items(), key=lambda x: (x[1]["familia"], x[0])):
        analisis = sorted(c["nombre"] for c in repo.get(t["carpeta"], [])
                          if not (c["meta"] or {}).get("tipos") or tid in (c["meta"] or {}).get("tipos", []))
        a(f"| {t['familia']} | **{_esc(t['nombre'])}** (`{tid}`) | {', '.join(b['id'] for b in t['bases'])} | "
          f"{len(t['controles'])} | {', '.join(f'`{x}`' for x in analisis) or '—'} |")
    a("")

    # 8. Notebook de calidad
    a("## 8. Notebook de calidad de datos: capas y catálogo")
    a("")
    a("| Capa (prefijo) | Qué es | Dónde vive |")
    a("|---|---|---|")
    for fila in (("C · batería general", "Reglas por el perfil de cada columna (nulos, fechas, negativos, outliers, "
                  "duplicados)", "`modulos/controles_ia.py`"),
                 ("BD · batería dinámica", "Columnas sin perfil y llaves compartidas entre bases (huérfanos, "
                  "duplicados de llave)", "`modulos/controles_ia.py`"),
                 ("M · tipo de modelo", "Controles de negocio de la ficha, por roles (sin columna = «Pendiente»)",
                  "`modulos/tipos_modelo*.py`"),
                 ("D · repositorio del dominio", "Análisis especializados en Python, filtrados por `META['tipos']`",
                  "`inputs/repositorio_controles/<dominio>/`"),
                 ("IA · propuestos", "Sugeridos por la IA y validados contra el catálogo y el perfil",
                  "`modulos/controles_ia.py` (`proponer`)"),
                 ("Aprendidos", "Lecciones aprobadas por un revisor (nunca el autor)", "`modulos/aprendizaje_controles.py`"),
                 ("X / P · del validador", "Sin programar o programados en el notebook (`@mi_control`)",
                  "el propio notebook")):
        a(f"| {fila[0]} | {fila[1]} | {fila[2]} |")
    a("")
    a(f"Catálogo de {len(ci.CATALOGO)} tipos de control (las funciones viajan dentro del notebook):")
    a("")
    a("| Dimensión | Tipo | Columnas | Qué verifica |")
    a("|---|---|---|---|")
    for tipo, m in sorted(ci.CATALOGO.items(), key=lambda x: (x[1]["dimension"], x[0])):
        a(f"| {m['dimension']} | `{tipo}` | {ci.columnas_texto(tipo)} | {_corto(m['descripcion'], 170)} |")
    a("")

    # 9. Repositorio
    a("## 9. Repositorio de controles por dominio")
    a("")
    a("Cada `.py` define `META` (literal, leído con `ast`) y `control(df, datasets, params)`; entra en el "
      "notebook de los tipos que declara en `META['tipos']` (sin `tipos`, en todos los del dominio).")
    a("")
    for carpeta, cs in repo.items():
        a(f"### `{carpeta}/` ({len(cs)})")
        a("")
        a("| Control | Tipos de modelo | Qué verifica |")
        a("|---|---|---|")
        for c in sorted(cs, key=lambda x: x["nombre"]):
            meta = c["meta"] or {}
            a(f"| `{c['nombre']}` | {', '.join(meta.get('tipos') or []) or 'todos'} | "
              f"{_corto(meta.get('descripcion', ''), 170)} |")
        a("")

    # 10. Librería
    a("## 10. Librería cuantitativa de los notebooks")
    a("")
    a("`modulos/libreria_cuant.py` viaja dentro de los notebooks de las etapas 02–04 (solo pandas y numpy; se "
      "valida con `ast.parse`, nunca se ejecuta en el servidor):")
    a("")
    a(", ".join(f"`{f}`" for f in funciones))
    a("")

    # 11. API
    a("## 11. API de la web")
    a("")
    por_area = defaultdict(list)
    for area, metodo, ruta, que in endpoints:
        por_area[area].append((metodo, ruta, que))
    for area in sorted(por_area):
        a(f"### {area}")
        a("")
        a("| Método | Ruta | Qué hace |")
        a("|---|---|---|")
        for metodo, ruta, que in por_area[area]:
            a(f"| {metodo} | `{ruta}` | {que} |")
        a("")

    # 12. Errores
    a("## 12. Mensajes de error de la web")
    a("")
    a("Extraídos de cada `HTTPException` de `web/routers/` y `web/services/` (`{…}` = parte variable). Para "
      "saber qué hacer con cada uno: `docs/GUIA_ERRORES_Y_SOPORTE.md`.")
    a("")
    cuenta = Counter(c for _, _, c, _ in errores)
    a("Por código: " + ", ".join(f"**{c}** {n}" for c, n in sorted(cuenta.items())) + ".")
    a("")
    por_archivo = defaultdict(list)
    for archivo, funcion, codigo, msg in errores:
        por_archivo[archivo].append((codigo, funcion, msg))
    for archivo in sorted(por_archivo):
        a(f"<details><summary><code>{archivo}</code> ({len(por_archivo[archivo])})</summary>")
        a("")
        a("| Código | Función | Mensaje |")
        a("|---|---|---|")
        for codigo, funcion, msg in por_archivo[archivo]:
            a(f"| {codigo} | `{funcion}` | {_corto(msg, 220) or '(sin texto)'} |")
        a("")
        a("</details>")
        a("")

    # 13. Código por capa
    a("## 13. Código por capa")
    a("")
    for n, archivos, que in capas:
        a(f"### {n} ({len(archivos)})")
        a("")
        a(que)
        a("")
        a("| Archivo | Qué hace |")
        a("|---|---|")
        for p in archivos:
            a(f"| `{_rel(p)}` | {_doc1(p) or '—'} |")
        a("")

    # 14. CLI
    a("## 14. Línea de comandos (agente.py)")
    a("")
    a("| Opción | Qué hace |")
    a("|---|---|")
    for flag, ayuda in cli:
        a(f"| `{flag}` | {_corto(ayuda, 200) or '—'} |")
    a("")

    # 15. Parámetros
    a("## 15. Parámetros")
    a("")
    a("Se declaran en `config/parametros.py` (+ `__all__`, `config/__init__.py` y `.env.example`); nunca se lee "
      "el entorno en otro sitio. Detalle de criterio: `GUIA_TRASPASO_CONTEXTO.md` §15.")
    a("")
    a("| Constante | Variable | Por defecto | Qué controla |")
    a("|---|---|---|---|")
    for nombre, var, defecto, desc in parametros:
        a(f"| `{nombre}` | `{var}` | {_esc(defecto)} | {_corto(desc, 160) or '—'} |")
    a("")

    # 16. Scripts
    a("## 16. Scripts")
    a("")
    a("| Script | Qué hace |")
    a("|---|---|")
    for p in scripts:
        a(f"| `{_rel(p)}` | {_doc1(p) or '—'} |")
    a("")

    # 17. Documentación
    a("## 17. Documentación")
    a("")
    a("| Documento | Título | Cómo se mantiene |")
    a("|---|---|---|")
    for d in docs:
        rel = _rel(d)
        titulo = next((l.lstrip("# ").strip() for l in d.read_text(encoding="utf-8", errors="replace").splitlines()
                       if l.startswith("#")), "")
        a(f"| `{rel}` | {_corto(titulo, 110)} | "
          + (f"generado por `{GENERADAS[rel]}`" if rel in GENERADAS else "a mano") + " |")
    a("")
    return o


def _parte_volatil(con_git: bool) -> list[str]:
    o: list[str] = []
    a = o.append
    a("## 18. Pruebas (volátil)")
    a("")
    archivos = _archivos(["tests/*.py", "pruebas/*.py", "pruebas/*/*.py"])
    archivos = [p for p in archivos if p.name.startswith("test_")]
    total = sum(_tests_en(p) for p in archivos)
    a(f"{total} funciones de prueba en {len(archivos)} archivos (las parametrizadas cuentan una vez; el número "
      "exacto lo da `pytest --collect-only -q`). Todas a coste cero: la IA siempre simulada.")
    a("")
    a("<details><summary>Archivos de prueba</summary>")
    a("")
    a("| Archivo | Pruebas | Qué cubre |")
    a("|---|---|---|")
    for p in archivos:
        a(f"| `{_rel(p)}` | {_tests_en(p)} | {_doc1(p) or '—'} |")
    a("")
    a("</details>")
    a("")
    a("## 19. Historial y trabajo sin commitear (volátil)")
    a("")
    if not con_git:
        a("(Omitido: generado con `--sin-git`.)")
        a("")
        return o
    rama = _git("rev-parse", "--abbrev-ref", "HEAD").strip()
    ultimo = _git("log", "-1", "--format=%h · %ad · %s", "--date=short").strip()
    a(f"Rama `{rama or '?'}` · último commit {ultimo or '?'}.")
    a("")
    estado = [l for l in _git("status", "--porcelain").splitlines() if l.strip()]
    tipos = {"M": "modificado", "A": "añadido", "D": "borrado", "R": "renombrado", "?": "nuevo"}
    por_carpeta: dict[str, Counter] = defaultdict(Counter)
    nuevos = defaultdict(list)
    for l in estado:
        cod, ruta = l[:2], l[3:].strip().strip('"')
        clase = tipos.get(cod.strip()[:1] or "M", "modificado")
        carpeta = ruta.split("/")[0] if "/" in ruta else "(raíz)"
        por_carpeta[carpeta][clase] += 1
        nuevos[carpeta].append(f"`{ruta}` ({clase})")
    a(f"**Trabajo sin commitear:** {len(estado)} entradas.")
    a("")
    if estado:
        a("| Carpeta | Modificados | Nuevos | Otros |")
        a("|---|---|---|---|")
        for carpeta in sorted(por_carpeta):
            c = por_carpeta[carpeta]
            otros = sum(v for k, v in c.items() if k not in ("modificado", "nuevo"))
            a(f"| `{carpeta}` | {c['modificado']} | {c['nuevo']} | {otros} |")
        a("")
        a("<details><summary>Lista completa</summary>")
        a("")
        for carpeta in sorted(nuevos):
            a(f"- **{carpeta}**: " + ", ".join(nuevos[carpeta]))
        a("")
        a("</details>")
        a("")
    log = [l.split("\t", 2) for l in _git("log", "--date=short", "--format=%ad%x09%h%x09%s").splitlines() if l]
    a(f"**Historial:** {len(log)} commits.")
    a("")
    por_fecha = defaultdict(list)
    for fecha, h, s in (x for x in log if len(x) == 3):
        por_fecha[fecha].append((h, s))
    a("<details><summary>Commits por fecha</summary>")
    a("")
    for fecha in sorted(por_fecha, reverse=True):
        a(f"- **{fecha}**: " + " · ".join(f"`{h}` {_esc(s)}" for h, s in por_fecha[fecha]))
    a("")
    a("</details>")
    a("")
    return o


def construir(con_git: bool = True) -> str:
    o = _parte_estable()
    o += [MARCA_VOLATIL, ""]
    o += _parte_volatil(con_git)
    return "\n".join(o).rstrip() + "\n"


def parte_estable(texto: str) -> str:
    return texto.split(MARCA_VOLATIL)[0]


def main(argv=None) -> int:
    for flujo in (sys.stdout, sys.stderr):
        try:
            flujo.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description="Mapa completo de VIRF desde el código.")
    ap.add_argument("--sin-git", action="store_true", help="sin historial ni trabajo sin commitear")
    ap.add_argument("--comprobar", action="store_true",
                    help="no escribe: código 1 si la parte estable del mapa quedó desactualizada")
    a = ap.parse_args(argv)
    texto = construir(con_git=not a.sin_git)
    if a.comprobar:
        actual = DESTINO.read_text(encoding="utf-8") if DESTINO.is_file() else ""
        if parte_estable(actual) != parte_estable(texto):
            print(f"{_rel(DESTINO)} desactualizado: python scripts/generar_mapa_herramienta.py")
            return 1
        print(f"{_rel(DESTINO)} al día")
        return 0
    DESTINO.parent.mkdir(parents=True, exist_ok=True)
    DESTINO.write_text(texto, encoding="utf-8", newline="\n")
    print(f"escrito {_rel(DESTINO)} ({texto.count(chr(10))} líneas)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
