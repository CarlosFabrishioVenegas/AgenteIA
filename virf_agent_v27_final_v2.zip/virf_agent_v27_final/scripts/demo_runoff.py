"""
scripts/demo_runoff.py
═══════════════════════════════════════════════════════════════════════════════
DEMO de la validación completa de un modelo de RUN-OFF (supervivencia del saldo)
con datos sintéticos y fallas SEMBRADAS, de punta a punta: 00 → 01 → 02 → 03 → 04.

Coste cero: sin IA (usar_ia=False). Todo queda dentro de la carpeta de salida
(no escribe en feedback/ ni en audit_logs/):

    outputs/<AAAA-MM-DD>/demo_runoff/      (convención de salidas: todo cuelga de la fecha)
      datos/        las 6 bases CSV (historia por cosecha, cuentas, curva, componentes, bandas, contabilidad)
      etapas/       los notebooks .ipynb de cada etapa y su Excel de resultados
      DEMO_RUNOFF.md  qué se sembró y qué encontró cada etapa

Fallas sembradas:
  · MINORISTA: la curva del modelo SUBE a los 24 meses (desgaste negativo) y en 2023-06 la mitad
    del saldo de las cosechas de 2020 migra a otro producto.
  · MAYORISTA: el modelo usa un estable de 45 % (la historia dice 30 %), estable + volátil = 95 %
    y la asignación a bandas suma 95 %.

Uso:  .venv\\Scripts\\python scripts/demo_runoff.py [--salida outputs/<AAAA-MM-DD>/demo_runoff]
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "tests"))

import pandas as pd  # noqa: E402

from _sinteticos_tipos import runoff_bases  # noqa: E402
from modulos import validacion_completa as VC  # noqa: E402

ETAPAS = ("00", "01", "02", "03", "04")


def _con_migracion(sal: pd.DataFrame) -> pd.DataFrame:
    sal = sal.copy()
    m = ((sal["segmento"] == "MINORISTA") & sal["cosecha"].between("2020-01", "2020-12")
         & (pd.to_datetime(sal["fecha"]) >= pd.Timestamp("2023-06-30")))
    sal.loc[m, "saldo"] = (sal.loc[m, "saldo"] * 0.5).round(2)
    return sal


def _tabla(df: pd.DataFrame, cols: list[str], n: int = 40) -> str:
    d = df[[c for c in cols if c in df.columns]].head(n).copy()
    for c in d.columns:
        d[c] = d[c].map(lambda v: f"{v:.4g}" if isinstance(v, float) else str(v)).str.replace("|", "/")
    filas = ["| " + " | ".join(d.columns) + " |", "|" + "---|" * len(d.columns)]
    filas += ["| " + " | ".join(str(v)[:140] for v in r) + " |" for r in d.itertuples(index=False)]
    return "\n".join(filas)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[2])
    from datetime import date
    ap.add_argument("--salida", default=str(RAIZ / "outputs" / date.today().isoformat() / "demo_runoff"))
    a = ap.parse_args()
    raiz = Path(a.salida).resolve()
    shutil.rmtree(raiz, ignore_errors=True)
    datos, trabajo_base = raiz / "datos", raiz / "etapas"
    inputs, outputs = raiz / "_virf" / "inputs", raiz / "_virf" / "outputs"
    datos.mkdir(parents=True)
    trabajo_base.mkdir()

    b = runoff_bases(fallas=True)
    b["saldos_historia"] = _con_migracion(b["saldos_historia"])
    b["contabilidad"] = b["saldos_historia"].groupby("fecha", as_index=False)["saldo"].sum()
    rutas = []
    for k, d in b.items():
        d.to_csv(datos / f"{k}.csv", index=False)
        rutas.append(f"{k} = {datos / (k + '.csv')}")

    hojas = {}
    for codigo in ETAPAS:
        print(f"· Etapa {codigo}: genera el notebook…", flush=True)
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo=codigo, archivos=[], comentario="demo",
                              usar_ia=False, rutas_texto="\n".join(rutas), tipos_modelo=["runoff"], dominio="ALM")
        nombre = f"{VC.ETAPAS[codigo]['fichero']}ITER0.ipynb"
        nb_path = VC.dir_salida(outputs, codigo) / nombre
        trabajo = trabajo_base / f"{codigo}_{VC.ETAPAS[codigo]['fichero']}"
        trabajo.mkdir()
        shutil.copy(nb_path, trabajo / nombre)
        nb = json.loads(nb_path.read_text(encoding="utf-8"))
        codigo_py = "\n\n".join("".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code")
        (trabajo / "_ejecutar.py").write_text(codigo_py, encoding="utf-8")
        print(f"  ejecuta el notebook en {trabajo.name}…", flush=True)
        r = subprocess.run([sys.executable, "_ejecutar.py"], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", cwd=str(trabajo), env={**os.environ, "PYTHONUTF8": "1"}, timeout=900)
        (trabajo / "_ejecutar.py").unlink()
        if r.returncode != 0:
            print(r.stderr[-3000:])
            return 1
        x = trabajo / VC.nombre_resultado(codigo, 0)
        hojas[codigo] = pd.read_excel(x, sheet_name=None)
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo=codigo, archivos=[(x.name, x.read_bytes())],
                              comentario="resultado de la demo", usar_ia=False, tipos_modelo=["runoff"], dominio="ALM")

    md = ["# Demo · validación completa de un modelo de run-off", "",
          "Datos sintéticos (2019-01 a 2024-12, 72 cosechas mensuales por segmento) con fallas sembradas:", "",
          "- **MINORISTA**: la curva del modelo sube a los 24 meses (desgaste negativo) y en 2023-06 la mitad del "
          "saldo de las cosechas de 2020 migra a otro producto.",
          "- **MAYORISTA**: el modelo usa un estable de 45 % (la historia dice 30 %), estable + volátil = 95 % y "
          "las bandas suman 95 %.", "",
          "Cada carpeta de `etapas/` tiene el notebook (`.ipynb`, se abre y se re-ejecuta en Jupyter desde esa "
          "carpeta) y su Excel de resultados. Las bases están en `datos/`.", ""]
    dic = hojas["00"]["Diccionario"]
    md += ["## 00 · Diagnóstico: cada concepto del negocio en su columna", "",
           _tabla(dic[dic["columna"].astype(str) != "—"], ["base_logica", "rol", "concepto", "columna"]), ""]
    ctl = hojas["01"]["Controles"]
    ctl = ctl[ctl["Control"].astype(str).str.match(r"^(M|D)")]
    md += ["## 01 · Control de datos: controles del tipo de modelo (M) y análisis del repositorio (D)", "",
           _tabla(ctl, ["Control", "Descripción", "Decisión", "Diagnóstico"], 60), ""]
    md += ["## 02 · Modelamiento: réplica de la curva, componentes, plazo económico y bandas", "",
           _tabla(hojas["02"]["Replica"], ["paso", "implementador", "replicado", "conclusion"], 60), ""]
    md += ["## 03 · Impactos: cuánto cambia el componente estable al corregir cada hallazgo", "",
           _tabla(hojas["03"]["Impactos"], ["origen", "valor_original", "valor_corregido", "nivel"], 30), ""]
    md += ["## 04 · Seguimiento: backtesting del saldo existente y estabilidad", "",
           _tabla(hojas["04"]["Backtesting"], list(hojas["04"]["Backtesting"].columns)), "",
           _tabla(hojas["04"]["Seguimiento"], ["indicador", "implementador", "replicado", "semaforo", "conclusion"]), ""]
    (raiz / "DEMO_RUNOFF.md").write_text("\n".join(md), encoding="utf-8")
    shutil.rmtree(raiz / "_virf", ignore_errors=True)
    print(f"✅ Demo lista en {raiz}  (resumen: DEMO_RUNOFF.md)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
