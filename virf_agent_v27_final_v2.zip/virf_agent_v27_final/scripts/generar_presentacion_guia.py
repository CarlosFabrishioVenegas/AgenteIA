"""
scripts/generar_presentacion_guia.py — Presentaciones (.pptx) de la herramienta VIRF.

Genera DOS mazos a partir del PROPIO repositorio, para que no se queden atrás cuando cambia el código:

  · `docs/agente_corporativo/GUIA_VIRF_PRESENTACION.pptx` — guía detallada de uso y soporte para
    validadores y para quien mantiene la herramienta (todas las secciones).
  · `docs/agente_corporativo/VIRF_VISION_GENERAL.pptx` — visión general corta para la gerencia
    (qué hace, validación completa, tipos de modelo, calidad de datos, run-off, calificación).

De dónde sale cada cosa:
  · Recorrido por la interfaz: capturas `docs/agente_corporativo/capturas/NN_*.jpg` y la tabla
    PANTALLAS de `scripts/generar_guia_agente.py` (qué es cada pantalla, endpoints, archivos).
  · Menú y pasos (obligatorio / recomendado / opcional): `web/templates/index.html` y
    `web/routers/guia.py`.
  · Cifras, modalidades y capas del notebook de calidad: `docs/MAPA_HERRAMIENTA.md` (generado).
  · Validación completa: `modulos/validacion_completa.py` (etapas, puente al 08, ámbitos del chat)
    y `modulos/plantillas_etapa.py` (experto y ruta de cada etapa).
  · Tipos de modelo y catálogo: `modulos/tipos_modelo*.py` y `modulos/controles_ia.py`.
  · Run-off: curva de los datos sintéticos de `tests/_sinteticos_tipos.py` (los de la demo).
  · Páginas de muestra de los informes Word: PDF de `ejemplos/` (si existen).
  · Regla de calificación: los ejemplos y la escala puntaje → riesgo se CALCULAN con
    `modulos/reglas_informe.py`, no se escriben a mano.
  · Reglas de oro y mapa síntoma → skill: se leen de `docs/agente_corporativo/CONOCIMIENTO_VIRF.md`.

Uso:
    .venv\\Scripts\\python.exe scripts\\generar_presentacion_guia.py
    .venv\\Scripts\\python.exe scripts\\generar_presentacion_guia.py --salida guia.pptx --salida-gerencia vision.pptx

No llama a ninguna IA. Solo necesita python-pptx, Pillow y pypdfium2 (ya en el .venv).
"""
from __future__ import annotations

import argparse
import re
import sys
import tempfile
from datetime import date
from pathlib import Path
from typing import Iterable, Optional

RAIZ = Path(__file__).resolve().parent.parent
for _p in (RAIZ, RAIZ / "scripts", RAIZ / "tests"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from lxml import etree  # noqa: E402
from PIL import Image  # noqa: E402
from pptx import Presentation  # noqa: E402
from pptx.chart.data import CategoryChartData  # noqa: E402
from pptx.dml.color import RGBColor  # noqa: E402
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION  # noqa: E402
from pptx.enum.shapes import MSO_SHAPE  # noqa: E402
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN  # noqa: E402
from pptx.oxml.ns import qn  # noqa: E402
from pptx.util import Emu, Inches, Pt  # noqa: E402

from generar_guia_agente import PANTALLAS  # noqa: E402
from generar_guia_uso import _menu  # noqa: E402
from modulos import controles_ia as CI  # noqa: E402
from modulos import plantillas_etapa as PE  # noqa: E402
from modulos import reglas_informe as R  # noqa: E402
from modulos import validacion_completa as VC  # noqa: E402
from modulos.libreria_cuant import FUNCIONES_CUANT  # noqa: E402
from modulos.tipos_modelo import TIPOS  # noqa: E402

DIR_GUIA = RAIZ / "docs" / "agente_corporativo"
DIR_CAPTURAS = DIR_GUIA / "capturas"
SALIDA = DIR_GUIA / "GUIA_VIRF_PRESENTACION.pptx"
SALIDA_GERENCIA = DIR_GUIA / "VIRF_VISION_GENERAL.pptx"
MAPA = RAIZ / "docs" / "MAPA_HERRAMIENTA.md"
LOGO = RAIZ / "inputs" / "logoempresa" / "Logo-bcp-vector.svg.webp"
EJ_RESULTADOS = RAIZ / "ejemplos" / "Ejemplo_Informe_Resultados_LaR.pdf"
EJ_WEB_CAPTURAS = RAIZ / "ejemplos" / "Ejemplo_Informe_Web_LaR_real_con_capturas.pdf"

# ── Paleta: la de la web (tinta oscura, sello bermellón, mostaza) ───────
TINTA = RGBColor(0x14, 0x17, 0x1F)
TINTA2 = RGBColor(0x1F, 0x23, 0x2E)
PAPEL = RGBColor(0xF6, 0xF2, 0xEB)
BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
SELLO = RGBColor(0xB8, 0x4A, 0x3A)
MOSTAZA = RGBColor(0xD9, 0xA4, 0x41)
VERDE = RGBColor(0x4E, 0x7D, 0x5B)
NARANJA = RGBColor(0xD0, 0x7A, 0x34)
TEXTO = RGBColor(0x23, 0x26, 0x30)
TENUE = RGBColor(0x6B, 0x70, 0x7D)
LINEA = RGBColor(0xDD, 0xD6, 0xCA)
CLARO_TENUE = RGBColor(0xA9, 0xAE, 0xBA)
SELLO_SUAVE = RGBColor(0xF3, 0xE1, 0xDC)
MOSTAZA_SUAVE = RGBColor(0xF6, 0xEB, 0xD3)
VERDE_SUAVE = RGBColor(0xE0, 0xEC, 0xE2)

TITULAR, CUERPO, MONO = "Cambria", "Calibri", "Consolas"
ANCHO, ALTO = Inches(13.333), Inches(7.5)
MARGEN = 0.6

COLOR_NIVEL = {"Deficiente": SELLO, "Regular": NARANJA, "Aceptable": MOSTAZA, "Satisfactorio": VERDE}
COLOR_RIESGO = {"Crítico": SELLO, "Moderado": NARANJA, "Oportunidad de Mejora": MOSTAZA, None: VERDE}

# ── Pasos del procedimiento: menú de la web + tipo de la guía de progreso ──
#: id del botón del menú → id del paso en web/routers/guia.py (cuando no es «btn-<paso>»)
_BOTON_A_PASO = {"btn-subir": "evidencia", "btn-dominio-rag": "dominio", "btn-chat": "chat"}


def pasos_procedimiento() -> list[tuple[str, str, str]]:
    """(número «01»…, etiqueta del menú, tipo: obligatorio | recomendado | opcional), en orden.

    El orden y las etiquetas salen del menú lateral (`web/templates/index.html`); el tipo, de los
    `_paso(...)` de `web/routers/guia.py` (lo no marcado como opcional/recomendado es obligatorio)."""
    guia = (RAIZ / "web" / "routers" / "guia.py").read_text(encoding="utf-8")
    tipos = dict(re.findall(r'_paso\("(\w+)",\s*"(opcional|recomendado)"', guia))
    proc = [(i, e) for s, i, e in _menu() if s.lower().startswith("procedimiento")]
    salida = []
    for k, (boton, etiqueta) in enumerate(proc, 1):
        paso = _BOTON_A_PASO.get(boton, boton.removeprefix("btn-"))
        salida.append((f"{k:02d}", etiqueta, tipos.get(paso, "obligatorio")))
    return salida


PASOS = pasos_procedimiento()
N_PASOS = len(PASOS)
N_OBLIGATORIOS = sum(1 for *_, t in PASOS if t == "obligatorio")
SECCION_PASOS = f"Los {N_PASOS} pasos"


def numero_paso(etiqueta: str) -> Optional[str]:
    """Número del paso cuyo nombre en el menú coincide con `etiqueta` (sin mayúsculas)."""
    for n, e, _ in PASOS:
        if e.lower() == etiqueta.lower():
            return n
    return None


# ── Cómo se usa cada pantalla (complementa la tabla PANTALLAS) ──────────
# clave de captura → (pasos para el usuario, «tenga en cuenta»)
USO = {
    "01_login": (
        ["Abra http://localhost:8000 en el navegador.",
         "En la web corporativa entre con el **SSO del banco** (Entra ID).",
         "En la web de prueba escriba **nombre**, cargo y roles y pulse **Entrar**."],
        "La sesión vive en la memoria del servidor: si se reinicia, vuelva a entrar. "
        "Sus expedientes y archivos siguen guardados en disco."),
    "02_mis_modelos": (
        ["Revise la lista: dominio, tier, estado y última actividad de cada modelo.",
         "Haga clic en una fila (o Tab + **Enter**) para abrir el expediente.",
         "**Nuevo modelo** crea un expediente; **Solo Informe** abre el modo sin pipeline."],
        "Cada validador ve solo sus propios modelos."),
    "03_nuevo_modelo": (
        ["Escriba el nombre del modelo (p. ej. «LaR Depósitos a la Vista»).",
         "Elija el **dominio**: VaR, LaR, ALM o uno personalizado.",
         "Elija el **tipo de modelo** (uno o varios) y la **modalidad**: normal o completa.",
         "Elija el **tier** y pulse **Crear**: se abre el expediente."],
        "El dominio decide qué literatura técnica (RAG) usa el agente y no se puede cambiar "
        "después. Elíjalo con cuidado."),
    "04_dashboard_inicio": (
        ["Lea el recuadro **Siguiente paso**: dice qué falta y lleva directo a ese paso.",
         f"La barra muestra cuántos de los **{N_OBLIGATORIOS} pasos obligatorios** están hechos.",
         f"El menú lateral lleva a los pasos 01–{N_PASOS:02d} y a las consultas."],
        "Un ✓ verde indica paso hecho; «SIGUIENTE» en bermellón marca el próximo obligatorio."),
    "05_configuracion": (
        ["Revise el título del modelo, su código del inventario y su tier.",
         "Compruebe la **modalidad** (normal o completa): la herramienta nunca la deduce.",
         "El proveedor de IA es el **aprobado** por el banco (Azure OpenAI).",
         "Pulse **Verificar conexión**: hace una llamada mínima y confirma la credencial."],
        "Las claves de IA viven en la fuente de secretos (Key Vault), nunca en el .env. "
        "Nunca las pegue en el chat ni en un correo."),
    "06_estandares": (
        ["Suba el **Estandares_VIRF.xlsx** del modelo (Ámbito, Control General, Control "
         "Específico, Actividad).",
         "Revise la vista previa agrupada por ámbito.",
         "Pulse **Confirmar**: ese estándar es la vara de medir de la validación."],
        "Sin estándar confirmado no se puede lanzar la validación."),
    "07_evidencia": (
        ["Suba la documentación en su carpeta: modelamiento, seguimiento, controles de datos.",
         "Suba el **ZIP del código** en Implementación (se descomprime solo).",
         "Si aplica: datasets, resultados de calidad de datos y Excels 00–03 de automatización.",
         "Opcional: pida el **Entendimiento del modelo** a partir del código."],
        "El paso queda hecho con al menos un documento y el código. El código del modelo se "
        "lee, nunca se ejecuta."),
    "08_dominio_rag": (
        ["Compruebe el dominio del modelo.",
         "Revise la literatura técnica disponible para ese dominio.",
         "Si falta, suba papers (PDF) y pulse **Reconstruir índice**."],
        "La literatura es compartida por todos los validadores. La búsqueda es léxica y local "
        "(BM25 + TF-IDF): no usa embeddings ni servicios externos."),
    "09_skills": (
        ["Active los análisis que aporten: coherencia documental, código vs manual, patrones "
         "problemáticos, backtesting, síntesis…",
         "Guarde la selección (vale para esta sesión)."],
        "Paso opcional. Las skills producen hallazgos adicionales; no cambian el puntaje."),
    "10_cuestionamientos": (
        ["Revise los **15 patrones** que el agente busca en el código (data leakage, "
         "imputación por media, look-ahead bias…).",
         "Añada preguntas propias en lenguaje natural.",
         "Guarde: el agente las responde durante la corrida."],
        "Paso opcional, pero recomendable en modelos con código propio."),
    "11_validar": (
        ["En validación completa, revise qué publicará cada etapa y sus hallazgos.",
         "Pulse **Lanzar validación**: firma con su identidad y corre el pipeline.",
         "Siga la consola en vivo; al terminar queda un JSON de resultados.",
         "Revise el resultado en **Consultas › Resultados**."],
        "Cada corrida hace llamadas reales a la IA (coste en la cuenta de Azure). Haga antes "
        "el pre-vuelo."),
    "12_documentar": (
        ["Revise el estado: evidencia, JSON de resultados, chat y corrida.",
         "Si hay Excels de automatización, genere el **cuadro de observaciones**.",
         "Pulse **Generar informe**: crea un Word versionado (V1, V2…).",
         "Descargue el Word y revíselo antes de enviarlo."],
        "Una observación que el chat cerró como APROBADO aparece como subsanada en el informe."),
    "13_resultados": (
        ["Elija la corrida que quiere revisar.",
         "Lea el puntaje global, el semáforo y las políticas aplicadas (§6 críticos, §4.2 veto).",
         "Abra una actividad para ver su evidencia citada y verifique la cita."],
        "Una actividad sin puntaje es «no evaluada» (fallo técnico): se re-ejecuta, no se califica."),
    "14_controles_datos": (
        ["Consulte el catálogo de motores: completitud, duplicados, integridad referencial, "
         "rangos…",
         "Revise los resultados entregados por la entidad.",
         "Descargue el **notebook** ejecutable de controles para el entregable."],
        "Los controles de datos son deterministas: la IA no calcula resultados."),
    "23_etapa_vista": (
        ["Abra la etapa en **Validación completa** (00 a 04) del menú.",
         "Envíe insumos, rutas de datos y comentarios: el agente entrega el notebook.",
         "Ejecútelo donde están los datos y devuelva su Excel: nueva iteración.",
         "Cuando cumpla, pulse **Cerrar etapa** (con motivo si no aplica)."],
        "El agente da su veredicto, pero cerrar la etapa es una decisión del validador."),
    "24_etapa_ruta": (
        ["Despliegue **Ruta de la etapa, paso a paso**.",
         "Cada paso dice qué se hace y en qué hoja del Excel queda.",
         "El check indica que el notebook cubre el paso; el círculo, que es parcial."],
        "Sin pasos cubiertos no hay veredicto «lista»: la ruta se verifica contra el notebook."),
    "25_validar_bloqueado": (
        ["Lea qué etapas faltan por cerrar.",
         "Revise los hallazgos abiertos de cada etapa.",
         "Compruebe a qué carpeta de evidencia irá el trabajo de cada una."],
        "Mientras falte una etapa, lanzar responde 409: nada se publica a medias."),
    "15_chat": (
        ["Inicie la revisión: el agente presenta las observaciones.",
         "El área sustenta cada una; se puede adjuntar evidencia nueva.",
         "El validador decide: **APROBADO**, **NEGADO** o **PENDIENTE**.",
         "Pulse **Consolidar**: recalcula el puntaje y descarga el acta de cierre (Excel)."],
        "La decisión final siempre es del validador; el agente solo propone."),
    "16_guia_ayuda": (
        ["Pulse el botón **?** (abajo a la derecha) en cualquier pantalla.",
         "Vea cada paso con su estado: hecho, siguiente, pendiente u opcional.",
         "Lea qué falta en cada paso y vaya directo a él."],
        "Es la forma más rápida de saber por qué un paso no aparece como hecho."),
    "17_solo_informe": (
        ["Desde **Mis Modelos** pulse **Solo Informe**.",
         "Compruebe el proveedor de IA activo (o «IA no configurada»: todo funciona igual sin IA).",
         "Suba el **Excel del estándar**; si trae columnas TIER, se filtra por el tier elegido.",
         "Opcional: suba los manuales del modelo (PDF, DOCX, TXT, MD) para que la IA cite archivo y página."],
        "No ejecuta el pipeline ni llama a la IA salvo que usted pulse un botón de IA."),
    "18_solo_informe_datos": (
        ["Elija el tipo: **Periódica** o **Por Primera Vez**, y el tier.",
         "Complete modelo, fechas de inicio y de entrega, responsable de la documentación y "
         "revisor (Walter Paiva por defecto).",
         "Escriba contexto y limitaciones; use **Pulir con IA** o **Redactar desde los manuales** si quiere."],
        "Todo se guarda solo como borrador en el servidor: puede cerrar y volver."),
    "19_solo_informe_observacion": (
        ["Elija ámbito, riesgo y la **actividad** del estándar (filtrada por ámbito).",
         "Escriba observación y recomendación; responsable y fecha de subsanación.",
         "Adjunte el sustento: imagen, fragmento de código o texto.",
         "**Añadir observación** y, al final, **Generar informe Word**."],
        "Una Oportunidad de Mejora no lleva responsable ni fecha y no incumple el control."),
}

PREVUELO = (
    "Paso 07 · Pre-vuelo",
    "Revisa la evidencia ANTES de gastar en la validación. No llama a la IA, no puntúa y no "
    "predice hallazgos: responde «con esta evidencia, ¿qué va a poder evaluar el agente?».",
    [("PDF escaneados", "Sin texto extraíble no hay nada que evaluar: se avisa antes de la corrida."),
     ("Formatos que no se leen", "Un .scala o .yaml se omitiría sin aviso: el pre-vuelo lo lista."),
     ("Carpetas vacías", "Un ámbito sin evidencia puntúa 0 = falta crítica. Mejor detectarlo a tiempo."),
     ("Trabajo adelantado", "Las lecturas pasan por la caché (SHA-256): la corrida real las reutiliza.")],
    "POST /api/prevuelo ·modulos/prevuelo.py · web/routers/dominio_prevuelo.py",
)


# ══════════════════════════════════════════════════════════════════════
#  Lectura de contenido del repositorio
# ══════════════════════════════════════════════════════════════════════

def _seccion_md(texto: str, prefijo: str) -> str:
    """Cuerpo de la sección `## {prefijo}…` de un Markdown (hasta la siguiente `## `)."""
    m = re.search(rf"^## {re.escape(prefijo)}.*?$(.*?)(?=^## |\Z)", texto, re.S | re.M)
    return m.group(1) if m else ""


def reglas_de_oro(conocimiento: str) -> list[str]:
    cuerpo = _seccion_md(conocimiento, "8.")
    reglas: list[str] = []
    for linea in cuerpo.splitlines():
        m = re.match(r"^\d+\.\s+(.*)$", linea)
        if m:
            reglas.append(m.group(1).strip())
        elif reglas and linea.startswith(" ") and linea.strip():
            reglas[-1] += " " + linea.strip()  # continuación del punto anterior
    return [re.sub(r"`([^`]*)`", r"\1", r) for r in reglas]


def sintoma_skill(conocimiento: str) -> list[tuple[str, str]]:
    cuerpo = _seccion_md(conocimiento, "11.")
    filas = []
    for linea in cuerpo.splitlines():
        celdas = [c.strip() for c in linea.strip().strip("|").split("|")]
        if len(celdas) == 2 and not set(celdas[0]) <= set("-: ") and celdas[0] != "Síntoma":
            filas.append((celdas[0], celdas[1]))
    return filas


def ejemplos_calificacion() -> list[tuple[str, list[dict], dict]]:
    """Casos típicos calificados con la regla real (`reglas_informe.concluir`)."""
    def obs(riesgo, ambito="Metodología", n=1):
        return [{"riesgo": riesgo, "ambito": ambito}] * n
    casos = [
        ("3 críticas", obs("Crítico", n=3)),
        ("2 críticas", obs("Crítico", n=2)),
        ("2 moderadas (Metodología)", obs("Moderado", n=2)),
        ("2 moderadas (Documentación + Gobierno)", obs("Moderado", "Documentación") + obs("Moderado", "Gobierno")),
        ("1 moderada + 3 bajas", obs("Moderado") + obs("Bajo", n=3)),
        ("5 bajas", obs("Bajo", n=5)),
        ("4 bajas + 6 Oportunidades de Mejora", obs("Bajo", n=4) + obs("Oportunidad de Mejora", n=6)),
    ]
    return [(nombre, o, R.concluir(o)) for nombre, o in casos]


def _escala_puntaje() -> list[tuple[str, Optional[str]]]:
    filas = [(str(p), R.riesgo_desde_puntaje(p)) for p in (0, 1, 2, 3, 4, 5)]
    return filas


def _limpiar(celda: str) -> str:
    return re.sub(r"`([^`]*)`", r"\1", celda.strip())


def tabla_md(texto: str, prefijo: str, n: int = 0) -> list[list[str]]:
    """La `n`-ésima tabla Markdown de la sección `## {prefijo}` (cabecera incluida, sin la fila ---)."""
    tablas, actual = [], []
    for linea in _seccion_md(texto, prefijo).splitlines():
        if linea.startswith("|"):
            celdas = [_limpiar(c) for c in linea.strip().strip("|").split("|")]
            if not all(set(c) <= set("-: ") for c in celdas):
                actual.append(celdas)
        elif actual:
            tablas.append(actual)
            actual = []
    if actual:
        tablas.append(actual)
    return tablas[n] if n < len(tablas) else []


def cifras(mapa: str) -> dict[str, str]:
    """«Qué» → «Cuántos» de `docs/MAPA_HERRAMIENTA.md` §1 (calculado por su generador)."""
    return {q: c for q, c in tabla_md(mapa, "1.")[1:]}


def cifra(cif: dict[str, str], *claves: str) -> tuple[str, str]:
    """(número, detalle) de la primera fila cuyo «Qué» contiene `claves`; «45 (alm: 18…)» → ("45", "alm: 18…")."""
    for q, c in cif.items():
        if all(k.lower() in q.lower() for k in claves):
            m = re.match(r"^(\d+)\s*(?:\((.*)\))?", c)
            return (m.group(1), m.group(2) or "") if m else (c, "")
    raise KeyError(claves)


def archivos_de_codigo(cif: dict[str, str]) -> tuple[int, int]:
    """(archivos, capas) sumando las filas «Archivos en «…»» del mapa."""
    filas = [int(c) for q, c in cif.items() if q.startswith("Archivos en") and c.isdigit()]
    return sum(filas), len(filas)


def tipos_por_familia() -> dict[str, list[tuple[str, str, int]]]:
    """familia → [(clave, nombre corto, nº de controles M)], en el orden del mapa (familia, nombre)."""
    salida: dict[str, list] = {}
    for clave, t in sorted(TIPOS.items(), key=lambda kv: (kv[1]["familia"], kv[1]["nombre"])):
        corto = re.sub(r"\s*\([^)]*\)", "", t["nombre"]).strip()  # sin paréntesis: «(gaps)», «(MCR)»…
        salida.setdefault(t["familia"], []).append((clave, corto, len(t["controles"])))
    return salida


def _docstring(ruta: Path) -> str:
    import ast
    return ast.get_docstring(ast.parse(ruta.read_text(encoding="utf-8"))) or ""


def fallas_demo_runoff() -> list[str]:
    """Las fallas sembradas que declara `scripts/demo_runoff.py` (una por segmento)."""
    doc = _docstring(RAIZ / "scripts" / "demo_runoff.py")
    bloque = doc.split("Fallas sembradas:", 1)[1].split("Uso:", 1)[0]
    return [" ".join(p.split()) for p in bloque.split("·") if p.strip()]


def ciclo_aprendizaje() -> list[str]:
    """Los pasos numerados del «Ciclo» de `modulos/aprendizaje_controles.py`, sin nombres de función."""
    doc = _docstring(RAIZ / "modulos" / "aprendizaje_controles.py")
    bloque = doc.split("Ciclo", 1)[1].split("Qué NO aprende", 1)[0]
    pasos = [" ".join(p.split()) for p in re.split(r"\n\s*\d\.\s+", "\n" + bloque) if p.strip()]
    pasos = [re.sub(r"\s*→\s*`[^`]*`|\s*\(`[^`]*`\)|`([^`]*)`", lambda m: m.group(1) or "", p) for p in pasos]
    pasos = [re.sub(r"^\w+\([^)]*\)\s+devuelve", "La siguiente validación del dominio recibe", p) for p in pasos]
    pasos = [re.sub(r"\s*\([^)]*Paso \d+\)", "", p) for p in pasos]
    return [re.sub(r"\s+([.,;:])", r"\1", p).strip() for p in pasos]


def titulo_md(ruta: Path) -> str:
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        if linea.startswith("# "):
            return linea[2:].strip()
    return ruta.stem


def mejoras_resumen() -> list[list[str]]:
    """Tabla «Resumen: por dónde empezar» de `docs/GUIA_MEJORAS.md` (cabecera incluida)."""
    return tabla_md((RAIZ / "docs" / "GUIA_MEJORAS.md").read_text(encoding="utf-8"), "Resumen")


def skills_corporativas() -> list[str]:
    return sorted(p.stem[:3] for p in (DIR_GUIA / "skills").glob("S[0-9][0-9]_*.md"))


def rango_skills() -> str:
    s = skills_corporativas()
    return f"{s[0]}–{s[-1]}" if s else "—"


#: Grupos de la librería cuantitativa para la diapositiva (los nombres se comprueban contra
#: FUNCIONES_CUANT en las pruebas: si una función se renombra, la prueba lo avisa).
GRUPOS_CUANT = [
    ("Datos por rol", ["col", "tabla", "falta"]),
    ("Contra el implementador", ["comparar", "comparar_pp", "nivel_impacto"]),
    ("VaR y backtesting", ["var_historico", "es_historico", "kupiec", "christoffersen", "semaforo", "pla"]),
    ("Run-off y supervivencia", ["supervivencia_saldo_existente", "curva_runoff", "plazo_economico",
                                 "componentes_runoff", "asignar_bandas", "kaplan_meier"]),
    ("Tasas y balance", ["gap_por_banda", "delta_eve_paralelo", "delta_nii_paralelo", "beta_traspaso",
                         "smm_cpr"]),
    ("Liquidez", ["lcr", "nsfr", "hqla_ajustado", "brechas", "lar_hist", "horizonte_supervivencia"]),
]


def funciones_cuant() -> list[str]:
    return [f.strip().split("(")[0] for f in FUNCIONES_CUANT.split(" · ") if f.strip()]


_AMBITO_BONITO = {"metodologia": "Metodología", "documentacion": "Documentación",
                  "implementacion": "Implementación", "calidad de datos": "Calidad de datos",
                  "gobierno": "Gobierno", "uso e integracion a la gestion": "Uso e integración a la gestión"}


def experto_corto(codigo: str) -> str:
    """«Arquitecto de datos de riesgo (BCBS 239)»: el experto de la etapa hasta los dos puntos."""
    return PE.EXPERTOS[codigo].split(":")[0].strip()


# ══════════════════════════════════════════════════════════════════════
#  Primitivas de dibujo
# ══════════════════════════════════════════════════════════════════════

class Mazo:
    """Presentación 16:9 con secciones, numeración y notas en cada diapositiva."""

    def __init__(self, tmp: Path, pie: str = "VIRF · Guía de la herramienta"):
        self.pie = pie
        self.prs = Presentation()
        self.prs.slide_width, self.prs.slide_height = ANCHO, ALTO
        self._tema()
        self.tmp = tmp
        self.secciones: list[tuple[str, list]] = []
        self.n = 0

    # ── tema: colores y fuentes del documento (para lo que se añada a mano en PowerPoint)
    def _tema(self):
        master = self.prs.slide_masters[0]
        for rel in master.part.rels.values():
            if rel.reltype.endswith("/theme"):
                parte = rel.target_part
                raiz = etree.fromstring(parte.blob)
                ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
                raiz.set("name", "VIRF")
                colores = {"dk1": "14171F", "lt1": "FFFFFF", "dk2": "232630", "lt2": "F6F2EB",
                           "accent1": "B84A3A", "accent2": "D9A441", "accent3": "4E7D5B",
                           "accent4": "D07A34", "accent5": "6B707D", "accent6": "2F4A6D",
                           "hlink": "B84A3A", "folHlink": "6B707D"}
                esquema = raiz.find(".//a:clrScheme", ns)
                esquema.set("name", "VIRF")
                for nombre, hexa in colores.items():
                    nodo = esquema.find(f"a:{nombre}", ns)
                    for h in list(nodo):
                        nodo.remove(h)
                    etree.SubElement(nodo, qn("a:srgbClr")).set("val", hexa)
                for tipo, fuente in (("majorFont", TITULAR), ("minorFont", CUERPO)):
                    raiz.find(f".//a:{tipo}/a:latin", ns).set("typeface", fuente)
                parte._blob = etree.tostring(raiz, xml_declaration=True, encoding="UTF-8",
                                             standalone=True)

    def nueva(self, seccion: str, oscura: bool = False, notas: str = ""):
        if not self.secciones or self.secciones[-1][0] != seccion:
            self.secciones.append((seccion, []))
        s = self.prs.slides.add_slide(self.prs.slide_layouts[6])  # en blanco
        self.secciones[-1][1].append(s)
        self.n += 1
        fondo = s.background.fill
        fondo.solid()
        fondo.fore_color.rgb = TINTA if oscura else PAPEL
        if notas:
            s.notes_slide.notes_text_frame.text = notas
        if self.n > 1:
            self._pie(s, oscura)
        return s

    def _pie(self, s, oscura: bool):
        color = CLARO_TENUE if oscura else TENUE
        texto(s, MARGEN, 7.05, 6, 0.3, self.pie, 10, color)
        texto(s, 13.333 - MARGEN - 1, 7.05, 1, 0.3, str(self.n), 10, color, alinear=PP_ALIGN.RIGHT)

    def guardar(self, ruta: Path):
        self._escribir_secciones()
        ruta.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(ruta)

    def _escribir_secciones(self):
        """Secciones de PowerPoint (p14:sectionLst) para navegar el mazo por temas."""
        p14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
        pres = self.prs.part._element
        ext_lst = pres.find(qn("p:extLst"))
        if ext_lst is None:
            ext_lst = etree.SubElement(pres, qn("p:extLst"))
        ext = etree.SubElement(ext_lst, qn("p:ext"))
        ext.set("uri", "{521415D9-36F7-43E2-AB2F-B90AF26B5E84}")
        lista = etree.SubElement(ext, f"{{{p14}}}sectionLst", nsmap={"p14": p14})
        ids = {s.slide_id for _, ss in self.secciones for s in ss}
        assert len(ids) == len(self.prs.slides)
        for k, (nombre, diapos) in enumerate(self.secciones):
            sec = etree.SubElement(lista, f"{{{p14}}}section")
            sec.set("name", nombre)
            sec.set("id", "{%08X-0000-4000-8000-%012X}" % (k + 1, k + 1))
            lst = etree.SubElement(sec, f"{{{p14}}}sldIdLst")
            for d in diapos:
                etree.SubElement(lst, f"{{{p14}}}sldId").set("id", str(d.slide_id))


def _runs(parrafo, contenido: str, tam: float, color: RGBColor, fuente: str, negrita: bool,
          cursiva: bool = False, color_negrita: Optional[RGBColor] = None):
    """Escribe `contenido` en el párrafo; los tramos entre ** van en negrita."""
    for i, trozo in enumerate(re.split(r"\*\*", contenido)):
        if not trozo:
            continue
        r = parrafo.add_run()
        r.text = trozo
        f = r.font
        f.size, f.name, f.italic = Pt(tam), fuente, cursiva
        f.bold = negrita or bool(i % 2)
        f.color.rgb = (color_negrita or color) if i % 2 else color


def texto(s, x, y, w, h, contenido, tam=14, color=TEXTO, fuente=CUERPO, negrita=False,
          alinear=PP_ALIGN.LEFT, anclaje=MSO_ANCHOR.TOP, cursiva=False, interlineado=None,
          nombre: Optional[str] = None):
    """Caja de texto sin márgenes internos. `contenido` admite saltos de línea («\n»)."""
    caja = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    if nombre:
        caja.name = nombre
    tf = caja.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anclaje
    for k, linea in enumerate(str(contenido).split("\n")):
        p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
        p.alignment = alinear
        if interlineado:
            p.line_spacing = interlineado
        _runs(p, linea, tam, color, fuente, negrita, cursiva)
    return caja


def lista(s, x, y, w, h, items: Iterable[str], tam=14, color=TEXTO, numerada=False,
          color_marca=SELLO, espacio=6, color_negrita: Optional[RGBColor] = None):
    """Lista con viñetas o numerada (viñetas reales de PowerPoint, no caracteres)."""
    caja = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = caja.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    for k, item in enumerate(items):
        p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
        p.space_after = Pt(espacio)
        pPr = p._p.get_or_add_pPr()
        sangria = int(Pt(tam * (1.6 if numerada else 1.1)))
        pPr.set("marL", str(sangria))
        pPr.set("indent", str(-sangria))
        clr = etree.SubElement(pPr, qn("a:buClr"))
        etree.SubElement(clr, qn("a:srgbClr")).set("val", str(color_marca))
        etree.SubElement(pPr, qn("a:buFont")).set("typeface", CUERPO)
        if numerada:
            etree.SubElement(pPr, qn("a:buAutoNum")).set("type", "arabicPeriod")
        else:
            etree.SubElement(pPr, qn("a:buChar")).set("char", "•")
        _runs(p, item, tam, color, CUERPO, False, color_negrita=color_negrita)
    return caja


def rect(s, x, y, w, h, relleno: Optional[RGBColor] = None, borde: Optional[RGBColor] = None,
         redondeado=False, grosor=1.0, nombre: Optional[str] = None):
    forma = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if redondeado else MSO_SHAPE.RECTANGLE,
                               Inches(x), Inches(y), Inches(w), Inches(h))
    if redondeado:
        forma.adjustments[0] = min(0.5, 0.12 / max(min(w, h), 0.01))
    if relleno is None:
        forma.fill.background()
    else:
        forma.fill.solid()
        forma.fill.fore_color.rgb = relleno
    if borde is None:
        forma.line.fill.background()
    else:
        forma.line.color.rgb = borde
        forma.line.width = Pt(grosor)
    forma.shadow.inherit = False
    if nombre:
        forma.name = nombre
    return forma


def circulo(s, x, y, d, relleno, etiqueta="", tam=14, color=BLANCO):
    c = s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(d), Inches(d))
    c.fill.solid()
    c.fill.fore_color.rgb = relleno
    c.line.fill.background()
    c.shadow.inherit = False
    if etiqueta:
        tf = c.text_frame
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        _runs(p, etiqueta, tam, color, CUERPO, True)
    return c


def imagen(s, ruta: Path, x, y, w=None, h=None, marco: Optional[RGBColor] = None, alt=""):
    """Imagen ajustada a la caja (w×h) conservando proporción, centrada; con marco opcional."""
    with Image.open(ruta) as im:
        iw, ih = im.size
    if w and h:
        esc = min(w / iw, h / ih)
        ww, hh = iw * esc, ih * esc
        x, y = x + (w - ww) / 2, y + (h - hh) / 2
    elif w:
        ww, hh = w, w * ih / iw
    else:
        ww, hh = h * iw / ih, h
    if marco is not None:
        rect(s, x - 0.06, y - 0.06, ww + 0.12, hh + 0.12, relleno=marco, redondeado=True)
    pic = s.shapes.add_picture(str(ruta), Inches(x), Inches(y), Inches(ww), Inches(hh))
    if alt:
        pic._element.nvPicPr.cNvPr.set("descr", alt)
    return pic


def encabezado(s, etiqueta: str, titulo: str, oscura=False):
    """Etiqueta en versalitas + título de la diapositiva."""
    texto(s, MARGEN, 0.42, 12, 0.3, etiqueta.upper(), 11, SELLO if not oscura else MOSTAZA,
          negrita=True)
    texto(s, MARGEN, 0.72, 12.1, 0.8, titulo, 28, BLANCO if oscura else TINTA, fuente=TITULAR,
          nombre="Título")


def tarjeta(s, x, y, w, h, titulo, cuerpo, acento=SELLO, fondo=BLANCO, tam=13, numero=None):
    rect(s, x, y, w, h, relleno=fondo, borde=LINEA, redondeado=True, grosor=0.75)
    dx = 0.25
    if numero is not None:
        circulo(s, x + 0.25, y + 0.25, 0.45, acento, str(numero), 14)
        dx = 0.85
    texto(s, x + dx, y + 0.27, w - dx - 0.25, 0.45, titulo, 15, TINTA, negrita=True,
          anclaje=MSO_ANCHOR.MIDDLE if numero is not None else MSO_ANCHOR.TOP)
    texto(s, x + 0.25, y + (0.85 if numero is not None else 0.7), w - 0.5,
          h - (1.0 if numero is not None else 0.85), cuerpo, tam, TEXTO, interlineado=1.08)


def chip(s, x, y, w, etiqueta, relleno, color=BLANCO, tam=11, h=0.32):
    r = rect(s, x, y, w, h, relleno=relleno, redondeado=True)
    tf = r.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    _runs(p, etiqueta, tam, color, CUERPO, True)
    return r


def tabla(s, x, y, w, filas: list[list[str]], anchos: list[float], tam=12, alto_fila=0.36,
          cabecera_color=TINTA):
    t = s.shapes.add_table(len(filas), len(filas[0]), Inches(x), Inches(y), Inches(w),
                           Inches(alto_fila * len(filas))).table
    tblPr = t._tbl.tblPr
    tblPr.set("bandRow", "0")
    tblPr.set("firstRow", "1")
    for j, a in enumerate(anchos):
        t.columns[j].width = Inches(a)
    for i, fila in enumerate(filas):
        t.rows[i].height = Inches(alto_fila)
        for j, valor in enumerate(fila):
            c = t.cell(i, j)
            c.margin_left = c.margin_right = Inches(0.1)
            c.margin_top = c.margin_bottom = Inches(0.04)
            c.vertical_anchor = MSO_ANCHOR.MIDDLE
            c.fill.solid()
            c.fill.fore_color.rgb = cabecera_color if i == 0 else (BLANCO if i % 2 else PAPEL)
            tf = c.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            _runs(p, valor, tam, BLANCO if i == 0 else TEXTO, CUERPO, i == 0)
    return t


def codigo(s, x, y, w, h, lineas: str, tam=12):
    rect(s, x, y, w, h, relleno=TINTA2, redondeado=True)
    texto(s, x + 0.25, y + 0.18, w - 0.5, h - 0.3, lineas, tam, RGBColor(0xE6, 0xE1, 0xD6),
          fuente=MONO, interlineado=1.1)


def nota_tecnica(s, y, contenido, oscura=False):
    texto(s, MARGEN, y, 12.1, 0.3, contenido, 10, CLARO_TENUE if oscura else TENUE, fuente=MONO)


# ══════════════════════════════════════════════════════════════════════
#  Imágenes auxiliares (logo y páginas de los PDF de ejemplo)
# ══════════════════════════════════════════════════════════════════════

def logo_png(tmp: Path) -> Optional[Path]:
    if not LOGO.is_file():
        return None
    destino = tmp / "logo_bcp.png"
    with Image.open(LOGO) as im:
        im.convert("RGBA").save(destino)
    return destino


def pagina_pdf(pdf: Path, numero: int, tmp: Path, escala=1.6) -> Optional[Path]:
    """Página `numero` (1-based) del PDF como PNG; None si no hay PDF o pypdfium2."""
    if not pdf.is_file():
        return None
    try:
        import pypdfium2 as pdfium
    except ImportError:
        return None
    doc = pdfium.PdfDocument(str(pdf))
    try:
        if numero > len(doc):
            return None
        destino = tmp / f"{pdf.stem}_p{numero}.png"
        doc[numero - 1].render(scale=escala).to_pil().save(destino)
        return destino
    finally:
        doc.close()


def captura(clave: str) -> Path:
    return DIR_CAPTURAS / f"{clave}.jpg"


def pantalla(clave: str):
    for fila in PANTALLAS:
        if fila[0] == clave:
            return fila
    raise KeyError(clave)


# ══════════════════════════════════════════════════════════════════════
#  Diapositivas
# ══════════════════════════════════════════════════════════════════════

def d_portada(m: Mazo, logo: Optional[Path], titulo: str = "VIRF · Guía de la herramienta",
              subtitulo: str = "Agente de validación de modelos de riesgo financiero: cómo se usa, "
                               "qué produce y cómo se mantiene.",
              notas: str = ("Presentación de la herramienta VIRF. Objetivo: que cualquier validador "
                            "pueda usarla de principio a fin y que el equipo técnico sepa dónde tocar "
                            "cuando algo deba cambiar.")):
    s = m.nueva("Introducción", oscura=True, notas=notas)
    if logo:
        rect(s, MARGEN, 0.6, 2.3, 0.75, relleno=BLANCO, redondeado=True)
        imagen(s, logo, MARGEN + 0.15, 0.68, w=2.0, h=0.6)
    texto(s, MARGEN, 2.2, 11, 0.4, "GERENCIA DE VALIDACIÓN INTERNA DE RIESGO FINANCIERO", 13,
          MOSTAZA, negrita=True)
    texto(s, MARGEN, 2.7, 11.5, 1.2, titulo, 54, BLANCO, fuente=TITULAR)
    texto(s, MARGEN, 3.95, 10.5, 1.0, subtitulo, 20, CLARO_TENUE)
    rect(s, MARGEN, 5.35, 3.2, 0.04, relleno=SELLO)
    texto(s, MARGEN, 5.55, 9, 0.35, f"Versión de la herramienta: agente v27 · {date.today():%d/%m/%Y}",
          13, CLARO_TENUE)


#: Secciones numeradas de la guía detallada: (nombre de sección, título, subtítulo de la divisoria,
#: descripción corta para la agenda). La agenda y las divisorias salen de aquí.
SECCIONES_GUIA = [
    ("Primeros pasos", "Primeros pasos", "Arrancar, entrar, crear un modelo y leer el expediente.",
     "Arranque, entrada, modelos y expediente"),
    (SECCION_PASOS, f"Los {N_PASOS} pasos de la validación",
     "De la configuración del proveedor de IA al informe Word versionado.",
     "De la configuración al informe"),
    ("Validación completa", "Validación completa",
     "Cinco etapas con notebooks antes del barrido, y el puente a la validación final.",
     "Etapas 00–04, notebooks y puente al 08"),
    ("Tipos y calidad de datos", "Tipos de modelo y calidad de datos",
     "Fichas de negocio por tipo y el notebook de controles por capas.",
     "Fichas, capas, catálogo y aprendizaje"),
    ("Run-off y librería", "Run-off y librería cuantitativa",
     "La supervivencia del saldo y las funciones que viajan en los notebooks.",
     "Supervivencia del saldo y demo"),
    ("Consultas", "Consultas", "Resultados de la corrida, controles de datos y cierre de cada observación.",
     "Resultados, controles de datos y chat"),
    ("Solo Informe", "Solo Informe",
     "El informe oficial a partir del estándar y de observaciones registradas a mano.",
     "El informe sin ejecutar el pipeline"),
    ("El informe Word", "El informe Word", "Una plantilla común para los tres informes.",
     "Estructura común y muestras reales"),
    ("Calificación", "Calificación", "Una regla única, calculada siempre igual.",
     "La regla única y ejemplos resueltos"),
    ("IA y seguridad", "IA y seguridad", "Proveedor, salvaguardas y trazabilidad.",
     "Proveedor aprobado y salvaguardas"),
    ("Mantenimiento", "Mantenimiento, soporte y mejora",
     "Arquitectura, reglas de oro, soporte, agente corporativo, grafo y pruebas.",
     "Soporte, mejoras y agente corporativo"),
]


def d_agenda(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "Recorrido de la sesión: qué es VIRF y sus cifras, el uso paso a paso, la validación "
        "completa con sus etapas, los tipos de modelo y la calidad de datos, el run-off, los "
        "informes y su calificación, la IA y, al final, el soporte y la mejora continua."))
    encabezado(s, "Contenido", "Qué vamos a ver")
    for k, (t, _, _, d) in enumerate(SECCIONES_GUIA):
        col, fila = k % 3, k // 3
        x, y = MARGEN + col * 4.1, 1.7 + fila * 1.3
        rect(s, x, y, 3.85, 1.12, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.22, y + 0.3, 0.52, SELLO if k % 2 == 0 else TINTA, f"{k + 1:02d}", 13)
        texto(s, x + 0.92, y + 0.16, 2.8, 0.4, t, 14, TINTA, negrita=True, anclaje=MSO_ANCHOR.MIDDLE)
        texto(s, x + 0.92, y + 0.6, 2.8, 0.4, d, 11, TENUE)


def d_que_es(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "VIRF recibe la evidencia de un modelo y la contrasta con un estándar de validación. El "
        "resultado es un informe Word con la calificación del modelo. Toda afirmación del informe "
        "debe poder rastrearse a una cita de la evidencia."))
    encabezado(s, "Qué es VIRF", "Evidencia + estándar → informe calificado")
    texto(s, MARGEN, 1.55, 12, 0.7,
          "VIRF es el agente de la segunda línea de defensa que valida modelos de riesgo financiero "
          "(VaR, LaR, ALM…). Lee la evidencia, la compara con el estándar y redacta el informe.",
          16, TEXTO)
    cajas = [
        ("Evidencia", ["Manuales y documentación", "Código del modelo (ZIP)", "Datos y resultados",
                       "Excels de automatización"], TINTA),
        ("Estándar de validación", ["Excel por ámbito", "Control general y específico",
                                    "Actividad a verificar", "Filtrable por tier"], TINTA),
        ("Agente VIRF", ["Lee y cita la evidencia", "Evalúa cada actividad (0–5)",
                         "Literatura técnica (RAG)", "Chat de sustentación"], SELLO),
        ("Informe Word", ["Estructura BCP I–VII", "Calificación del modelo",
                          "Observaciones y sustento", "Anexos de trazabilidad"], VERDE),
    ]
    xs = [MARGEN, MARGEN + 3.15, MARGEN + 6.3, MARGEN + 9.45]
    for (t, items, color), x in zip(cajas, xs):
        y = 2.65
        rect(s, x, y, 2.75, 3.6, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        rect(s, x, y, 2.75, 0.65, relleno=color, redondeado=True)
        rect(s, x, y + 0.4, 2.75, 0.25, relleno=color)
        texto(s, x + 0.2, y + 0.12, 2.4, 0.45, t, 15, BLANCO, negrita=True, anclaje=MSO_ANCHOR.MIDDLE)
        lista(s, x + 0.25, y + 0.9, 2.3, 2.6, items, 13, espacio=8, color_marca=color)
    for x, signo in ((MARGEN + 2.78, "+"), (MARGEN + 5.93, "→"), (MARGEN + 9.08, "→")):
        texto(s, x, 4.1, 0.35, 0.5, signo, 26, SELLO, negrita=True, alinear=PP_ALIGN.CENTER)
    texto(s, MARGEN, 6.45, 12, 0.4, "Regla de oro: toda afirmación del informe debe poder "
          "rastrearse a una cita verificable de la evidencia.", 13, SELLO, cursiva=True)


def d_formas_uso(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "Hay tres formas de uso. La web guiada es la habitual. La línea de comandos la usa la web "
        "por debajo y sirve para automatizar. Solo Informe es para cuando la validación se hizo a "
        "mano y solo se necesita el Word con la plantilla y la regla oficial."))
    encabezado(s, "Formas de uso", "Tres maneras de trabajar con VIRF")
    datos = [
        (f"Web guiada · {N_PASOS} pasos", "La forma habitual. El validador sube la evidencia, "
         "lanza la validación, sustenta en el chat y descarga el informe.",
         "Cuándo: validar un modelo (normal o completa).", "uvicorn web.app:app"),
        ("Línea de comandos", "agente.py ejecuta el pipeline completo y emite el entregable "
         "regulatorio. La web la lanza como subproceso.",
         "Cuándo: automatizar o repetir corridas.", "agente.py --prdc …"),
        ("Solo Informe", "Genera el informe solo con el estándar y las observaciones registradas a "
         "mano. No ejecuta el pipeline; la IA es opcional.",
         "Cuándo: la validación ya se hizo y falta el Word.", "Mis Modelos › Solo Informe"),
    ]
    for k, (t, d, cuando, cmd) in enumerate(datos):
        x = MARGEN + k * 4.1
        rect(s, x, 1.7, 3.85, 4.75, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.3, 2.0, 0.7, [TINTA, TENUE, SELLO][k], str(k + 1), 20)
        texto(s, x + 0.3, 2.9, 3.3, 0.45, t, 19, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.3, 3.45, 3.3, 1.6, d, 14, TEXTO, interlineado=1.1)
        texto(s, x + 0.3, 5.1, 3.3, 0.6, cuando, 13, SELLO, negrita=True)
        texto(s, x + 0.3, 5.85, 3.3, 0.35, cmd, 12, TENUE, fuente=MONO)


def d_vocabulario(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "Vocabulario mínimo para entender las pantallas y el informe. Un control del informe es "
        "cada actividad del estándar."))
    encabezado(s, "Vocabulario", "Los términos que aparecen en toda la herramienta")
    terminos = [
        ("Ámbito", "Gran área evaluada: Documentación, Calidad de Datos, Metodología, "
         "Implementación, Gobierno, Usos."),
        ("Control / Actividad", "Cada fila del estándar. En el informe, cada actividad es un "
         "control del barrido."),
        ("Observación", "Hallazgo con riesgo, recomendación, responsable, fecha y sustento."),
        ("Riesgo", "Crítico, Moderado, Bajo/Potencial u Oportunidad de Mejora (no incumple)."),
        ("Tier", "Nivel de criticidad del modelo; filtra qué actividades del estándar aplican."),
        ("Calificación", "Satisfactorio, Aceptable, Regular o Deficiente: regla única para los "
         "tres informes."),
        ("RAG", "Literatura técnica por dominio, buscada de forma léxica y local."),
        ("Chat de sustentación", "Diálogo con el área: cada observación termina APROBADA, "
         "NEGADA o PENDIENTE."),
    ]
    for k, (t, d) in enumerate(terminos):
        col, fila = k % 2, k // 2
        x, y = MARGEN + col * 6.15, 1.65 + fila * 1.3
        rect(s, x, y, 5.95, 1.15, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        rect(s, x, y + 0.2, 0.08, 0.75, relleno=SELLO if col == 0 else MOSTAZA)
        texto(s, x + 0.3, y + 0.15, 5.4, 0.35, t, 15, TINTA, negrita=True)
        texto(s, x + 0.3, y + 0.5, 5.45, 0.6, d, 13, TEXTO)


def d_divisoria(m: Mazo, seccion: str, numero: int, titulo: str, subtitulo: str):
    s = m.nueva(seccion, oscura=True, notas=f"Sección {numero}: {titulo}. {subtitulo}")
    texto(s, MARGEN, 2.3, 3, 1.2, f"{numero:02d}", 72, SELLO, fuente=TITULAR)
    texto(s, MARGEN, 3.55, 11, 1.0, titulo, 44, BLANCO, fuente=TITULAR)
    texto(s, MARGEN, 4.55, 11, 0.8, subtitulo, 18, CLARO_TENUE)


def d_arranque(m: Mazo):
    s = m.nueva("Primeros pasos", notas=(
        "Antes de abrir la web: entorno virtual del proyecto y la fuente de secretos con la clave "
        "del proveedor aprobado (Azure OpenAI). La web corporativa entra con SSO; la web de prueba "
        "local se arranca con scripts/web_prueba.py. Detalle en GUIA_INSTALACION.md y GUIA_USO.md §2."))
    encabezado(s, "Antes de empezar", "Arrancar la herramienta")
    pasos = [
        ("Entorno del proyecto", "Use siempre el **.venv** del proyecto. El Python del sistema "
         "tiene paquetes que la política prohíbe."),
        ("Claves en la fuente de secretos", "La clave de IA vive en **Key Vault** "
         "(VIRF_FUENTE_SECRETOS); el .env solo lleva configuración, nunca secretos."),
        ("Arrancar el servidor", "Corporativa con SSO (Entra ID) o la web de prueba local, sin "
         "SSO: comandos a la derecha."),
        ("Abrir la web", "Navegador en **http://localhost:8000** y entrar con su código."),
    ]
    for k, (t, d) in enumerate(pasos):
        y = 1.7 + k * 1.2
        circulo(s, MARGEN, y, 0.55, SELLO, str(k + 1), 15)
        texto(s, MARGEN + 0.8, y - 0.02, 5.3, 0.35, t, 16, TINTA, negrita=True)
        texto(s, MARGEN + 0.8, y + 0.36, 5.3, 0.75, d, 13, TEXTO)
    codigo(s, 7.0, 1.7, 5.73, 2.5,
           "# Corporativa (SSO Entra ID)\n"
           ".venv\\Scripts\\python -m uvicorn \\\n"
           "    web.app:app --port 8000\n\n"
           "# Prueba local, sin SSO\n"
           ".venv\\Scripts\\python \\\n"
           "    scripts\\web_prueba.py --puerto 8000", 12)
    rect(s, 7.0, 4.45, 5.73, 1.75, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, 7.25, 4.6, 5.3, 0.35, "Importante", 14, TINTA, negrita=True)
    texto(s, 7.25, 4.97, 5.3, 1.2, "El .env nunca se edita desde el código ni lleva claves. Si una "
          "clave se filtra (por ejemplo, pegada en un chat), hay que revocarla y crear otra.", 13,
          TEXTO)


def d_pantalla(m: Mazo, seccion: str, clave: str, etiqueta: Optional[str] = None):
    """Diapositiva estándar de pantalla: captura a la izquierda, uso a la derecha."""
    _, titulo, que, eps, archivos, skill = pantalla(clave)
    pasos, ojo = USO[clave]
    s = m.nueva(seccion, notas=f"{titulo}. {que} Tenga en cuenta: {ojo}")
    partes = titulo.split(" · ", 1)
    titular = partes[1] if len(partes) == 2 else titulo
    if partes[0].startswith("Paso ") and numero_paso(titular):
        # El número del paso sale del menú vigente (PANTALLAS puede ir con la numeración antigua).
        partes[0] = f"Paso {numero_paso(titular)}"
    encabezado(s, etiqueta or (partes[0] if len(partes) == 2 else seccion),
               titular[:1].upper() + titular[1:])
    imagen(s, captura(clave), MARGEN + 0.06, 1.66, w=7.05, h=5.0, marco=TINTA,
           alt=f"Captura de la pantalla {titulo}")
    x, w = 8.15, 4.6
    texto(s, x, 1.62, w, 1.25, que, 13, TEXTO, interlineado=1.08)
    texto(s, x, 2.95, w, 0.3, "CÓMO SE USA", 11, SELLO, negrita=True)
    alto_pasos = 2.35 if len(pasos) > 3 else 2.0
    lista(s, x, 3.3, w, alto_pasos, pasos, 13, numerada=True, espacio=7)
    y_ojo = 3.3 + alto_pasos + 0.15
    alto_ojo = 0.36 + 0.22 * (len(ojo) // 50 + 1)  # ~50 caracteres por línea a 12 pt (con margen)
    rect(s, x, y_ojo, w, alto_ojo, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, x + 0.2, y_ojo + 0.13, w - 0.4, alto_ojo - 0.2, f"**Tenga en cuenta.** {ojo}", 12,
          TEXTO)
    if eps and eps != "—":
        texto(s, 8.15, 6.8, 4.6, 0.25, f"Skill {skill} · {eps.split(' · ')[0]}", 9, TENUE,
              fuente=MONO)


def d_flujo(m: Mazo):
    obligatorios = [e for _, e, t in PASOS if t == "obligatorio"]
    s = m.nueva(SECCION_PASOS, notas=(
        f"El expediente sigue {N_PASOS} pasos. {N_OBLIGATORIOS} son obligatorios: "
        f"{', '.join(obligatorios).lower()}. Los opcionales y el recomendado no frenan la barra de "
        "progreso, que cuenta solo los obligatorios. Pasos y tipos salen del menú de la web y de "
        "la guía de progreso (web/routers/guia.py)."))
    encabezado(s, "Mapa del procedimiento", f"{N_PASOS} pasos, {N_OBLIGATORIOS} obligatorios")
    color = {"obligatorio": SELLO, "opcional": TENUE, "recomendado": MOSTAZA}
    ancho = (13.333 - 2 * MARGEN) / N_PASOS
    for k, (n, t, tipo) in enumerate(PASOS):
        x = MARGEN + k * ancho
        if k:
            rect(s, x - ancho / 2 + 0.34, 2.36, ancho - 0.68, 0.05, relleno=LINEA)
        circulo(s, x + ancho / 2 - 0.34, 2.03, 0.68, color[tipo], n, 15)
        texto(s, x + 0.03, 2.88, ancho - 0.06, 0.6, t, 11, TINTA, negrita=True, alinear=PP_ALIGN.CENTER)
    leyenda = [("Obligatorio", SELLO), ("Recomendado", MOSTAZA), ("Opcional", TENUE)]
    for k, (t, c) in enumerate(leyenda):
        circulo(s, MARGEN + k * 2.2, 3.72, 0.22, c)
        texto(s, MARGEN + k * 2.2 + 0.32, 3.68, 1.8, 0.3, t, 12, TEXTO)
    n_val, n_rev, n_doc = (numero_paso("Validar modelo"), numero_paso("Revisión con el agente"),
                           numero_paso("Documentar"))
    bloques = [
        ("Preparar (01–04)", "Proveedor de IA, estándar confirmado, evidencia subida y dominio "
         "con su literatura. Sin esto no se puede validar."),
        ("Afinar (05–07)", "Análisis extra, preguntas propias y revisión de la evidencia antes de "
         "gastar en llamadas a la IA."),
        (f"Validar y cerrar ({n_val}–{n_doc})", f"{n_val}: corrida del pipeline · "
         f"{n_rev}: revisión de cada observación con el agente · {n_doc}: informe Word versionado."),
    ]
    for k, (t, d) in enumerate(bloques):
        x = MARGEN + k * 4.1
        rect(s, x, 4.35, 3.85, 2.2, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        texto(s, x + 0.25, 4.55, 3.4, 0.4, t, 16, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.25, 5.05, 3.4, 1.4, d, 13, TEXTO, interlineado=1.08)


def d_prevuelo(m: Mazo):
    titulo, que, puntos, tecnico = PREVUELO
    s = m.nueva(SECCION_PASOS, notas=(
        "El pre-vuelo es recomendado antes de validar: detecta sin coste lo que haría que un "
        "ámbito quede sin evidencia y se califique como falta crítica."))
    encabezado(s, f"Paso {numero_paso('Pre-vuelo')} · Recomendado",
               "Pre-vuelo: revisar la evidencia antes de gastar")
    texto(s, MARGEN, 1.6, 12, 0.8, que, 15, TEXTO)
    for k, (t, d) in enumerate(puntos):
        col, fila = k % 2, k // 2
        tarjeta(s, MARGEN + col * 6.15, 2.6 + fila * 1.95, 5.95, 1.75, t, d,
                acento=SELLO if k < 3 else VERDE, numero=k + 1, tam=13)
    nota_tecnica(s, 6.65, tecnico)


def d_consultas_chat_estados(m: Mazo):
    s = m.nueva("Consultas", notas=(
        "Cada observación del chat termina en uno de tres estados. Al consolidar, el puntaje se "
        "recalcula y el informe web muestra las aprobadas como subsanadas."))
    encabezado(s, "Chat de sustentación", "Cómo se cierra cada observación")
    estados = [
        ("APROBADO", VERDE, VERDE_SUAVE, "El área sustentó la observación con evidencia suficiente.",
         "En el informe aparece como subsanada y deja de restar."),
        ("NEGADO", SELLO, SELLO_SUAVE, "La sustentación no es suficiente o contradice la evidencia.",
         "La observación se mantiene con su riesgo."),
        ("PENDIENTE", MOSTAZA, MOSTAZA_SUAVE, "Falta información; el área debe aportar más evidencia.",
         "Se mantiene abierta hasta una nueva sesión de chat."),
    ]
    for k, (t, c, suave, que, efecto) in enumerate(estados):
        x = MARGEN + k * 4.1
        rect(s, x, 1.75, 3.85, 3.3, relleno=suave, redondeado=True)
        chip(s, x + 0.3, 2.05, 1.7, t, c, tam=12, h=0.4)
        texto(s, x + 0.3, 2.7, 3.3, 1.0, que, 14, TEXTO)
        texto(s, x + 0.3, 3.85, 3.3, 1.0, f"**Efecto:** {efecto}", 13, TEXTO)
    rect(s, MARGEN, 5.35, 12.13, 1.2, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, MARGEN + 0.3, 5.5, 11.5, 1.0,
          "**Consolidar** recalcula el puntaje final con las decisiones del validador y genera el "
          "**acta de cierre** (Excel). El agente propone; la decisión siempre es del validador.",
          14, TEXTO)


def d_movil(m: Mazo):
    s = m.nueva("Consultas", notas=(
        "La web funciona también en pantallas pequeñas: la cabecera se parte, el menú lateral pasa "
        "a una barra horizontal y los formularios usan una sola columna."))
    encabezado(s, "También en el móvil", "La misma herramienta en pantallas pequeñas")
    claves = ["20_movil_mis_modelos", "21_movil_solo_informe", "22_movil_dashboard"]
    for k, clave in enumerate(claves):
        _, titulo, que, *_ = pantalla(clave)
        x = MARGEN + 0.2 + k * 4.15
        imagen(s, captura(clave), x, 1.65, w=1.95, h=4.25, marco=TINTA, alt=titulo)
        texto(s, x + 2.15, 1.75, 1.75, 0.6, titulo.split(" · ")[-1], 15, TINTA, negrita=True)
        texto(s, x + 2.15, 2.4, 1.75, 3.4, que, 12, TEXTO)
    texto(s, MARGEN, 6.25, 12, 0.5, "Accesibilidad: contraste AA en los textos y foco de teclado "
          "visible (anillo mostaza) en toda la web.", 13, SELLO, cursiva=True)


def d_solo_informe_que(m: Mazo):
    s = m.nueva("Solo Informe", notas=(
        "Solo Informe es para cuando la validación ya se hizo a mano y se necesita el Word oficial. "
        "Usa la misma plantilla y la misma regla de calificación que los otros dos informes."))
    encabezado(s, "Solo Informe", "El informe oficial sin ejecutar el pipeline")
    pasos = [
        ("Estándar", "Sube el Excel y, si tiene columnas TIER, se filtra por el tier del modelo."),
        ("Datos", "Tipo de validación, fechas, responsables, contexto y limitaciones."),
        ("Observaciones", "Ámbito, riesgo, actividad, recomendación y sustento."),
        ("Word", "Calificación automática con la regla única y plantilla BCP."),
    ]
    for k, (t, d) in enumerate(pasos):
        x = MARGEN + k * 3.08
        rect(s, x, 1.75, 2.85, 2.5, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.25, 2.0, 0.6, SELLO if k < 3 else VERDE, str(k + 1), 16)
        texto(s, x + 0.25, 2.75, 2.4, 0.4, t, 17, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.25, 3.2, 2.4, 1.0, d, 13, TEXTO)
        if k < 3:
            texto(s, x + 2.83, 2.75, 0.27, 0.4, "→", 18, SELLO, negrita=True, alinear=PP_ALIGN.CENTER)
    comparacion = [
        ["", "Web (9 pasos)", "Solo Informe"],
        ["Ejecuta el pipeline", "Sí (agente.py)", "No"],
        ["Llamadas a la IA", "Sí, en cada corrida", "Solo si pulsa un botón de IA"],
        ["Quién decide las observaciones", "El agente propone, el chat cierra", "El validador las escribe"],
        ["Plantilla y regla de calificación", "Comunes", "Comunes"],
        ["Necesita modelo creado", "Sí", "No (solo el login)"],
    ]
    comparacion[0][1] = f"Web ({N_PASOS} pasos)"
    tabla(s, MARGEN, 4.5, 12.13, comparacion, [4.0, 4.06, 4.07], tam=12, alto_fila=0.34)


def d_solo_informe_reglas(m: Mazo):
    s = m.nueva("Solo Informe", notas=(
        "Reglas propias del registro de observaciones en Solo Informe, confirmadas con el usuario."))
    encabezado(s, "Solo Informe · reglas del registro", "Lo que la herramienta hace por usted")
    reglas = [
        ("Cada actividad es un control", "El barrido del informe recorre todas las actividades "
         "del estándar (p. ej. 32) y concluye control por control."),
        ("Filtro por tier", "Si el Excel trae columnas TIER, solo entran las actividades que "
         "aplican al tier elegido. El tier es obligatorio en ese caso."),
        ("Oportunidad de Mejora", "No incumple el control, no lleva responsable ni fecha y no "
         "cuenta para la calificación global."),
        ("Sustento", "Imagen, fragmento de código o texto. Va debajo de la observación en el "
         "barrido de controles."),
        ("Descripción de lo realizado", "Texto fijo: «Es un barrido completo», igual para todos "
         "los controles."),
        ("Conclusión del control", "Si el control no es adecuado, la conclusión sale en rojo; "
         "si cumple, en texto normal."),
    ]
    for k, (t, d) in enumerate(reglas):
        col, fila = k % 3, k // 3
        tarjeta(s, MARGEN + col * 4.1, 1.7 + fila * 2.5, 3.85, 2.3, t, d, numero=k + 1,
                acento=[SELLO, TINTA, MOSTAZA, VERDE, TENUE, SELLO][k], tam=13)


def d_solo_informe_ia(m: Mazo):
    s = m.nueva("Solo Informe", notas=(
        "Tres ayudas opcionales con IA. Todas usan el proveedor configurado, que en el corporativo "
        "es GPT de Azure. Si no hay IA configurada, los botones lo indican y el resto funciona."))
    encabezado(s, "Solo Informe · asistencia con IA (opcional)", "Tres botones, siempre bajo su control")
    ayudas = [
        ("Pulir con IA", "Corrige redacción, tono y claridad de contexto, limitaciones, "
         "observaciones y recomendaciones. No inventa hechos ni cifras.", "POST /api/solo-informe/ia/pulir"),
        ("Crear gráfico", "Si un sustento o descripción es muy extenso, propone un gráfico. Solo "
         "usa números que ya están en el texto (se comprueba).", "POST /api/solo-informe/ia/grafico"),
        ("Desde los manuales", "Busca en los manuales subidos (búsqueda léxica local) y redacta "
         "citando archivo y página.", "POST /api/solo-informe/ia/manuales"),
    ]
    for k, (t, d, ep) in enumerate(ayudas):
        x = MARGEN + k * 4.1
        rect(s, x, 1.75, 3.85, 3.35, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.3, 2.05, 0.6, [SELLO, MOSTAZA, VERDE][k], "IA", 13)
        texto(s, x + 1.1, 2.12, 2.6, 0.45, t, 17, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.3, 2.85, 3.3, 1.7, d, 13, TEXTO, interlineado=1.08)
        texto(s, x + 0.3, 4.65, 3.3, 0.3, ep, 9, TENUE, fuente=MONO)
    rect(s, MARGEN, 5.35, 12.13, 1.2, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.3, 5.48, 11.5, 1.0,
          "**Proveedor:** el de IA_PROVEEDOR (Azure OpenAI en el corporativo). Se puede forzar otro "
          "solo para Solo Informe con SOLO_INFORME_IA_PROVEEDOR / SOLO_INFORME_DEPLOYMENT. Antes de "
          "enviar texto se enmascaran datos personales y se neutralizan instrucciones incrustadas.",
          13, TEXTO)


def d_informe_estructura(m: Mazo, portada: Optional[Path], indice: Optional[Path]):
    s = m.nueva("El informe Word", notas=(
        "Los tres informes comparten la plantilla de modulos/plantilla_bcp.py: misma portada, "
        "encabezado con logo y numeración «Página | N», pie, índice con hipervínculos y siete "
        "secciones fijas más anexos."))
    encabezado(s, "Estructura común", "Un mismo esqueleto para los tres informes")
    secciones = [
        ("I", "Objetivos", "Qué se evaluó y desde cuándo."),
        ("II", "Alcance", "Ámbitos y controles revisados."),
        ("III", "Cumplimiento de Estándar", "Controles satisfactorios / no cumplidos por ámbito."),
        ("IV", "Información Relevante", "Ficha del documento, contexto, limitaciones, fechas y conclusión."),
        ("V", "Cuadro Resumen", "Todas las observaciones con riesgo y responsable."),
        ("VI", "Glosario", "Término, sigla y descripción."),
        ("VII", "Barrido de Controles", "Cada actividad: descripción, resultado y conclusión."),
        ("A…", "Anexos", "Según el informe: trazabilidad, firma, custodia, escala…"),
    ]
    for k, (n, t, d) in enumerate(secciones):
        y = 1.65 + k * 0.63
        chip(s, MARGEN, y + 0.05, 0.62, n, SELLO if n != "A…" else TENUE, tam=12, h=0.36)
        texto(s, MARGEN + 0.8, y + 0.02, 2.9, 0.4, t, 14, TINTA, negrita=True)
        texto(s, MARGEN + 3.65, y + 0.04, 3.9, 0.5, d, 12, TEXTO)
    for k, (img, alt) in enumerate(((portada, "Portada del informe"), (indice, "Índice del informe"))):
        if img:
            imagen(s, img, 8.35 + k * 2.3, 1.75, w=2.1, h=4.7, marco=LINEA, alt=alt)
    texto(s, 8.35, 6.5, 4.4, 0.3, "Ejemplo real: Informe de Resultados (Solo Informe), modelo LaR",
          10, TENUE, cursiva=True)


def d_informe_paginas(m: Mazo, paginas: list[tuple[Optional[Path], str, str]]):
    s = m.nueva("El informe Word", notas=(
        "Páginas reales del ejemplo generado por Solo Informe. El cumplimiento por ámbito, la ficha "
        "del documento y la conclusión con la calificación salen calculados."))
    encabezado(s, "Muestras reales", "Así se ven las secciones clave")
    validas = [p for p in paginas if p[0]]
    ancho = 12.13 / max(len(validas), 1)
    for k, (img, t, d) in enumerate(validas):
        x = MARGEN + k * ancho
        imagen(s, img, x + 0.1, 1.65, w=ancho - 0.35, h=3.85, marco=LINEA, alt=t)
        texto(s, x + 0.1, 5.65, ancho - 0.35, 0.35, t, 14, TINTA, negrita=True)
        texto(s, x + 0.1, 6.0, ancho - 0.35, 0.8, d, 12, TEXTO)


def d_barrido(m: Mazo, barrido: Optional[Path], capt1: Optional[Path], capt2: Optional[Path]):
    s = m.nueva("El informe Word", notas=(
        "El barrido de controles va en texto corrido, no en tablas. En el informe web, cada "
        "documento citado aporta la captura de su portada, y cada contradicción entre manual y "
        "código lleva la página citada y el fragmento de código como sustento. Solo se captura "
        "cuando la cita es literal."))
    encabezado(s, "Barrido de controles y capturas", "El sustento visible dentro del informe")
    imgs = [(barrido, "VII. Barrido (Solo Informe)", "Actividad, descripción de lo realizado, "
             "resultado y conclusión; en rojo si el control no es adecuado."),
            (capt1, "Portada citada (informe web)", "Pantallazo de la primera página de cada "
             "documento de Documentación."),
            (capt2, "Página y código (informe web)", "Contradicción manual ↔ código: página "
             "citada resaltada y fragmento con números de línea.")]
    validas = [i for i in imgs if i[0]]
    ancho = 12.13 / max(len(validas), 1)
    for k, (img, t, d) in enumerate(validas):
        x = MARGEN + k * ancho
        imagen(s, img, x + 0.1, 1.65, w=ancho - 0.35, h=3.85, marco=LINEA, alt=t)
        texto(s, x + 0.1, 5.65, ancho - 0.35, 0.35, t, 14, TINTA, negrita=True)
        texto(s, x + 0.1, 6.0, ancho - 0.35, 0.8, d, 12, TEXTO)


def d_tres_informes(m: Mazo):
    s = m.nueva("El informe Word", notas=(
        "Qué añade cada informe sobre la estructura común. Los tres se califican con la misma "
        "regla de modulos/reglas_informe.py."))
    encabezado(s, "Tres informes, una plantilla", "Qué añade cada uno")
    filas = [
        ["", "Solo Informe", "Generar informe (web)", "Entregable del pipeline"],
        ["Se genera desde", "Pantalla Solo Informe", f"Paso {numero_paso('Documentar')} · Documentar",
         "agente.py (CLI)"],
        ["Observaciones", "Escritas por el validador", "Puntaje del agente + chat", "Puntaje del agente"],
        ["Sustento", "Imagen, código o texto", "Citas, capturas de portada, página y código", "Citas de evidencia"],
        ["Anexos", "—", "Tabla final, entendimiento, automatizaciones, trazabilidad",
         "Firma, custodia, escala, correcciones, análisis transversales"],
        ["Versionado", "Un Word por generación", "V1, V2… por modelo", "Por corrida"],
        ["Código", "solo_informe_word.py", "informe_web.py", "generador_word.py"],
    ]
    tabla(s, MARGEN, 1.7, 12.13, filas, [2.4, 2.9, 3.4, 3.43], tam=12, alto_fila=0.62)
    texto(s, MARGEN, 6.3, 12, 0.4, "Los tres llaman a modulos/plantilla_bcp.py y se califican con "
          "modulos/reglas_informe.py.", 13, SELLO, cursiva=True)


def d_regla(m: Mazo):
    s = m.nueva("Calificación", notas=(
        "La regla se evalúa de lo más grave a lo menos grave; la primera condición que se cumple "
        "decide el nivel. Las Oportunidades de Mejora no cuentan."))
    encabezado(s, "Regla de calificación", "Cuatro niveles, evaluados de lo más grave a lo menos grave")
    niveles = [
        ("Deficiente", "Más de 2 observaciones críticas."),
        ("Regular", "1 o 2 críticas · o más de 1 moderada · (con al menos una moderada de "
                    "Documentación y una de Gobierno, el umbral sube a 3 o más)."),
        ("Aceptable", "1 moderada (o 2 con la excepción Documentación + Gobierno) · o 5 o más "
                      "bajas/potenciales. Nunca lleva críticas."),
        ("Satisfactorio", "Hasta 4 bajas/potenciales, sin moderadas ni críticas."),
    ]
    for k, (n, d) in enumerate(niveles):
        y = 1.7 + k * 1.05
        chip(s, MARGEN, y + 0.12, 2.3, n, COLOR_NIVEL[n], tam=15, h=0.6)
        rect(s, MARGEN + 2.5, y, 9.63, 0.85, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        texto(s, MARGEN + 2.75, y + 0.1, 9.2, 0.7, d, 14, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
    rect(s, MARGEN, 6.0, 12.13, 0.7, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.3, 6.08, 11.5, 0.55, "**Oportunidades de Mejora:** no cuentan para la "
          "calificación y no dejan el control como incumplido. «Potencial» cuenta junto a «Bajo».",
          13, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)


def d_ejemplos(m: Mazo):
    s = m.nueva("Calificación", notas=(
        "Estos casos no están escritos a mano: el generador de la presentación los calcula con la "
        "función concluir() de la herramienta, así que siempre coinciden con la regla vigente."))
    encabezado(s, "Ejemplos resueltos", "La regla aplicada a casos típicos")
    filas = [["Observaciones del informe", "Calificación", "Motivo (texto que da la herramienta)"]]
    niveles = []
    for nombre, _, res in ejemplos_calificacion():
        filas.append([nombre, res["nivel"], res["motivo"]])
        niveles.append(res["nivel"])
    t = tabla(s, MARGEN, 1.7, 12.13, filas, [3.9, 1.9, 6.33], tam=13, alto_fila=0.58)
    for i, nivel in enumerate(niveles, start=1):
        c = t.cell(i, 1)
        c.fill.solid()
        c.fill.fore_color.rgb = COLOR_NIVEL[nivel]
        for r in c.text_frame.paragraphs[0].runs:
            r.font.color.rgb, r.font.bold = BLANCO, True
    nota_tecnica(s, 6.55, "Calculado con modulos/reglas_informe.py::concluir() al generar esta presentación.")


def d_puntaje(m: Mazo):
    s = m.nueva("Calificación", notas=(
        "En la web y en el pipeline el agente puntúa cada actividad de 0 a 5. Ese puntaje se "
        "traduce a riesgo para aplicar la misma regla que Solo Informe. La falta de evidencia es "
        "falta crítica; una actividad sin puntaje por fallo técnico no se califica y se re-ejecuta."))
    encabezado(s, "Del puntaje del agente al riesgo", "Cómo se califican la web y el pipeline")
    escala = _escala_puntaje()
    ancho = 12.13 / len(escala)
    significado = {"0": "Sin evidencia", "1": "Incumple", "2": "Incumple", "3": "Brechas importantes",
                   "4": "Cumplimiento sustancial", "5": "Cumple"}
    for k, (p, riesgo) in enumerate(escala):
        x = MARGEN + k * ancho
        rect(s, x + 0.05, 1.75, ancho - 0.1, 2.3, relleno=COLOR_RIESGO[riesgo], redondeado=True)
        texto(s, x + 0.05, 1.85, ancho - 0.1, 1.0, p, 48, BLANCO, fuente=TITULAR, negrita=True,
              alinear=PP_ALIGN.CENTER)
        texto(s, x + 0.15, 2.95, ancho - 0.3, 0.9, riesgo or "Sin observación", 14, BLANCO,
              negrita=True, alinear=PP_ALIGN.CENTER)
        texto(s, x + 0.05, 4.2, ancho - 0.1, 0.4, significado[p], 12, TENUE, alinear=PP_ALIGN.CENTER)
    casos = [
        ("Sin evidencia", "Falta crítica (como un 0), aunque no haya puntaje.", SELLO),
        ("Sin puntaje (fallo técnico)", "«No evaluada»: no se califica; hay que re-ejecutar.", TENUE),
        ("APROBADO en el chat", "La observación cuenta como subsanada en el informe web.", VERDE),
    ]
    for k, (t, d, c) in enumerate(casos):
        x = MARGEN + k * 4.1
        rect(s, x, 4.85, 3.85, 1.6, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.25, 5.05, 0.3, c)
        texto(s, x + 0.7, 5.0, 3.0, 0.4, t, 14, TINTA, negrita=True)
        texto(s, x + 0.25, 5.5, 3.4, 0.9, d, 13, TEXTO)
    nota_tecnica(s, 6.6, "Escala calculada con modulos/reglas_informe.py::riesgo_desde_puntaje().")


def d_ia(m: Mazo):
    from config.ia import PROVEEDORES
    s = m.nueva("IA y seguridad", notas=(
        "Todas las funciones de IA pasan por config/ia.py, que tiene una lista cerrada de "
        "proveedores con su estado (decisión del banco). Solo el APROBADO se puede usar; los demás "
        "se rechazan con un error claro. No hay cambio automático de proveedor si uno falla."))
    encabezado(s, "Proveedor de IA", "Una lista cerrada en config/ia.py")
    descripcion = {
        "azure_openai": ("Azure OpenAI (GPT)", "El proveedor del corporativo. La clave sale de la "
                         "fuente de secretos (Key Vault)."),
        "anthropic": ("Claude (Anthropic)", "En espera: el código lo soporta, pero el banco aún no "
                      "lo autoriza. VIRF PLUS depende de él."),
        "openai": ("OpenAI directo", "Retirado: cualquier intento de usarlo se rechaza con "
                   "ProveedorNoAutorizado."),
    }
    color_estado = {"APROBADO": VERDE, "EN_ESPERA": MOSTAZA, "RETIRADO": SELLO}
    for k, (clave, estado) in enumerate(PROVEEDORES.items()):
        t, d = descripcion.get(clave, (clave, ""))
        x = MARGEN + k * 4.1
        rect(s, x, 1.7, 3.85, 2.95, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        texto(s, x + 0.3, 1.95, 3.3, 0.45, t, 17, TINTA, fuente=TITULAR, negrita=True)
        chip(s, x + 0.3, 2.5, 1.6, estado.replace("_", " "), color_estado.get(estado, TENUE), tam=11)
        texto(s, x + 0.3, 3.0, 3.3, 1.1, d, 13, TEXTO, interlineado=1.08)
        texto(s, x + 0.3, 4.2, 3.3, 0.3, clave, 11, TENUE, fuente=MONO)
    usos = [f"Validación (pipeline del paso {numero_paso('Validar modelo')}) y revisión con el agente",
            "Notebooks de las etapas de la validación completa", "Entendimiento del modelo",
            "Solo Informe: pulir, gráfico y manuales"]
    texto(s, MARGEN, 4.95, 6, 0.35, "TODAS ESTAS FUNCIONES USAN EL MISMO PROVEEDOR", 11, SELLO, negrita=True)
    lista(s, MARGEN, 5.35, 6, 1.4, usos, 13, espacio=3)
    rect(s, 7.0, 4.95, 5.73, 1.75, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, 7.25, 5.08, 5.3, 1.55, "**Sin plan B automático.** Si el proveedor falla (401, 503…), "
          "la herramienta lo dice con claridad; no cambia sola a otro proveedor. Un 401 casi siempre "
          "es una clave ausente o vencida en la fuente de secretos.", 13, TEXTO)


def d_salvaguardas(m: Mazo):
    s = m.nueva("IA y seguridad", notas=(
        "Salvaguardas que protegen la evidencia y la trazabilidad del informe."))
    encabezado(s, "Salvaguardas", "Qué protege la evidencia y el informe")
    items = [
        ("Datos personales", "Se enmascaran localmente antes de enviar texto al modelo.",
         "modulos/pii.py"),
        ("Instrucciones incrustadas", "Texto de la evidencia que intente dar órdenes al modelo se "
         "neutraliza.", "modulos/inyeccion.py"),
        ("Citas verificables", "Cada hallazgo cita archivo y pasaje; lo que no se puede rastrear "
         "no entra como hecho.", "Regla de oro 10"),
        ("Capturas exactas", "Solo se captura la página si la cita es literal; nunca una página "
         "«aproximada».", "modulos/capturas.py"),
        ("RAG local", "Búsqueda léxica sin embeddings, sin HuggingFace ni servicios externos.",
         "src/rag/"),
        ("Código del modelo", "Se lee para evaluarlo; nunca se ejecuta lo subido.",
         "web/routers/upload.py"),
    ]
    for k, (t, d, ref) in enumerate(items):
        col, fila = k % 3, k // 3
        x, y = MARGEN + col * 4.1, 1.7 + fila * 2.5
        rect(s, x, y, 3.85, 2.3, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.25, y + 0.25, 0.45, [SELLO, SELLO, VERDE, VERDE, TINTA, TINTA][k], "✓", 14)
        texto(s, x + 0.85, y + 0.3, 2.8, 0.4, t, 15, TINTA, negrita=True)
        texto(s, x + 0.25, y + 0.9, 3.4, 1.0, d, 13, TEXTO)
        texto(s, x + 0.25, y + 1.88, 3.4, 0.3, ref, 10, TENUE, fuente=MONO)


def d_arquitectura(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "Arquitectura en capas. La regla de dependencias es clave: modulos no importa web, porque "
        "el pipeline de línea de comandos no tiene web."))
    encabezado(s, "Arquitectura", "Capas del código y dónde vive cada cosa")
    capas = [
        ("Navegador", "web/static/js/app.js · index.html · styles.css", TENUE),
        ("Endpoints", "web/routers/*.py — validan la entrada, devuelven JSON o archivos", TINTA),
        ("Servicios web", "web/services/*.py — sesión, estándares, chat, informes, Solo Informe", TINTA),
        ("Núcleo", "modulos/*.py — motor IA, plantilla y regla de informes, PII, capturas", SELLO),
        ("Configuración", "config/*.py — parámetros, rutas y ÚNICO lugar que elige proveedor de IA", SELLO),
        ("Pipeline y RAG", "agente.py · motor/Mx_0x_*.py · src/rag/*.py", MOSTAZA),
    ]
    for k, (t, d, c) in enumerate(capas):
        y = 1.65 + k * 0.78
        rect(s, MARGEN, y, 2.6, 0.62, relleno=c, redondeado=True)
        texto(s, MARGEN + 0.2, y, 2.3, 0.62, t, 14, BLANCO, negrita=True, anclaje=MSO_ANCHOR.MIDDLE)
        texto(s, MARGEN + 2.85, y, 5.0, 0.62, d, 12, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
    rect(s, 8.75, 1.65, 3.98, 4.52, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 9.0, 1.85, 3.5, 0.35, "Reglas de dependencia", 15, TINTA, negrita=True)
    lista(s, 9.0, 2.35, 3.5, 3.7, [
        "web/ puede importar modulos/, config/ y src/.",
        "**modulos/ no importa web/**: el pipeline CLI no tiene web.",
        "La calificación solo vive en modulos/reglas_informe.py.",
        "La selección de proveedor de IA solo en config/.",
        "Tests: todos sin coste (IA simulada).",
    ], 13, espacio=8)
    nota_tecnica(s, 6.45, "Sesiones: web/data/sesiones/{código}/{MODELO}/inputs|outputs · "
                 "Solo Informe: web/data/sesiones/{código}/_solo_informe/")


def d_reglas_oro(m: Mazo, reglas: list[str]):
    s = m.nueva("Mantenimiento", notas=(
        "Estas reglas se leen de CONOCIMIENTO_VIRF.md. Cualquier cambio a la herramienta debe "
        "respetarlas; varias están vigiladas por tests."))
    encabezado(s, "Reglas de oro", "Lo que ningún cambio puede romper")
    mitad = (len(reglas) + 1) // 2
    for col, grupo in enumerate((reglas[:mitad], reglas[mitad:])):
        for k, r in enumerate(grupo):
            n = k + 1 + col * mitad
            x, y = MARGEN + col * 6.15, 1.7 + k * 0.98
            circulo(s, x, y + 0.05, 0.5, SELLO if n <= 4 else TINTA, str(n), 13)
            texto(s, x + 0.7, y, 5.25, 0.85, r, 13, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
    nota_tecnica(s, 6.65, "Fuente: docs/agente_corporativo/CONOCIMIENTO_VIRF.md §8")


def d_agente_corporativo(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "El agente corporativo acepta hasta 20 archivos de entrada y devuelve hasta 5. Por eso el "
        "paquete se organiza en un conocimiento corto, una skill por tipo de cambio y la guía PDF "
        "completa para consulta."))
    encabezado(s, "Mejorar la herramienta con el agente corporativo", "Paquete de 20 archivos de entrada / 5 de salida")
    for k, (num, t, d) in enumerate([("20", "archivos de entrada", "como máximo por consulta"),
                                     ("5", "archivos de salida", "actualizados por respuesta")]):
        x = MARGEN + k * 3.0
        texto(s, x, 1.6, 2.8, 1.1, num, 66, SELLO, fuente=TITULAR, negrita=True)
        texto(s, x, 2.75, 2.8, 0.35, t, 15, TINTA, negrita=True)
        texto(s, x, 3.1, 2.8, 0.35, d, 12, TENUE)
    receta = [
        "Suba **CONOCIMIENTO_VIRF.md** (siempre).",
        f"Suba la **skill** del tipo de cambio ({rango_skills()}).",
        "Añada los archivos de código que la skill indica (≤ 18).",
        "Pida el cambio con el síntoma y lo esperado.",
        "Pruebe con el comando «Cómo verificar» de la skill.",
    ]
    texto(s, MARGEN, 3.75, 5.6, 0.35, "RECETA DE CADA CONSULTA", 11, SELLO, negrita=True)
    lista(s, MARGEN, 4.15, 5.7, 2.6, receta, 13, numerada=True, espacio=6)
    paquete = [
        ("00_LEEME.md", "Cómo usar el paquete"),
        ("CONOCIMIENTO_VIRF.md", "Base operativa corta"),
        (f"skills/{rango_skills().replace('–', ' … ')}", "Una receta por tipo de cambio"),
        ("GUIA_…_CORPORATIVO.pdf", "Guía completa para consulta"),
        ("capturas/", f"{len(list(DIR_CAPTURAS.glob('*.jpg')))} pantallas de la interfaz"),
        ("graphify-out/", "Mapa del código (grafo)"),
    ]
    rect(s, 6.9, 1.65, 5.83, 5.1, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 7.15, 1.85, 5.3, 0.35, "docs/agente_corporativo/", 14, TINTA, fuente=MONO, negrita=True)
    for k, (f, d) in enumerate(paquete):
        y = 2.4 + k * 0.7
        rect(s, 7.15, y, 0.08, 0.5, relleno=SELLO if k < 3 else MOSTAZA)
        texto(s, 7.4, y - 0.02, 5.1, 0.3, f, 13, TINTA, fuente=MONO)
        texto(s, 7.4, y + 0.27, 5.1, 0.3, d, 12, TENUE)


def d_sintoma(m: Mazo, filas: list[tuple[str, str]]):
    s = m.nueva("Mantenimiento", notas=(
        "Tabla para elegir la skill según el síntoma. Se lee de CONOCIMIENTO_VIRF.md §11."))
    encabezado(s, "Qué skill usar", "Del síntoma a la receta de cambio")
    datos = [["Síntoma", "Skill"]] + [[a, b] for a, b in filas]
    tabla(s, MARGEN, 1.6, 12.13, datos, [8.13, 4.0], tam=12, alto_fila=min(0.385, 5.15 / len(datos)))


def d_grafo(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "El grafo de graphify se construye sin IA a partir del código. Sirve para elegir qué "
        "archivos subir al agente y para saber qué se rompe al cambiar algo."))
    encabezado(s, "El grafo del código", "Encontrar qué tocar y qué se rompe")
    filas = [
        ["Necesito…", "Comando"],
        ["Dónde vive una función y con qué se conecta", 'graphify explain "concluir()"'],
        ["Qué se rompe si la cambio", 'graphify affected "riesgo_desde_puntaje()"'],
        ["Cómo llega un endpoint a una función", 'graphify path "ia_pulir()" "cliente_dedicado()"'],
        ["Una pregunta en lenguaje natural", 'graphify query "cómo se genera el informe word"'],
        ["Los nodos más conectados (delicados)", "graphify god-nodes --top 15"],
        ["Actualizar tras cambiar el código", "graphify update ."],
    ]
    t = tabla(s, MARGEN, 1.65, 7.6, filas, [3.6, 4.0], tam=12, alto_fila=0.52)
    for i in range(1, len(filas)):
        for r in t.cell(i, 1).text_frame.paragraphs[0].runs:
            r.font.name, r.font.size = MONO, Pt(11)
    rect(s, 8.5, 1.65, 4.23, 5.05, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 8.75, 1.85, 3.8, 0.35, "Receta: elegir ≤ 18 archivos", 15, TINTA, negrita=True)
    lista(s, 8.75, 2.35, 3.8, 2.6, [
        "explain sobre la función del síntoma.",
        "affected sobre ella: candidatos a romperse.",
        "Quedarse con su archivo, los que la llaman y su test.",
        "Si sobran, describir el resto en el mensaje.",
    ], 13, numerada=True, espacio=6)
    texto(s, 8.75, 5.0, 3.8, 1.6, "**Límite:** el grafo no une JavaScript con Python (hablan por "
          "HTTP): busque la URL /api/... de app.js en web/routers/.", 12, TEXTO)
    texto(s, MARGEN, 6.4, 7.6, 0.3, "graphify-out/: GRAPH_REPORT.md (comunidades en español) · "
          "graph.json · graph.html", 10, TENUE, fuente=MONO)


def d_problemas(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "Problemas frecuentes y su solución rápida. Si no se resuelve, usar la skill S01 con el "
        "agente corporativo."))
    encabezado(s, "Problemas frecuentes", "Síntoma → qué hacer")
    filas = [
        ["Síntoma", "Causa probable", "Qué hacer"],
        ["Error 401 al usar la IA", "Clave ausente o vencida en Key Vault", "Renovar el secreto y «Verificar conexión» (S05)"],
        ["409 al lanzar la validación", "Validación completa con etapas abiertas", "Cerrar cada etapa (con motivo si no aplica) (S13)"],
        ["Me saca de la sesión", "Se reinició el servidor", "Volver a entrar; los expedientes siguen en disco"],
        ["El estándar no se lee", "Columnas con otro nombre u hoja distinta", "Revisar Ámbito/Control/Actividad (S06)"],
        ["Un ámbito sale «sin evidencia»", "Carpeta vacía o PDF escaneado", "Hacer el pre-vuelo y subir el documento (S09)"],
        ["No aparece la captura de una cita", "La cita no es literal en el PDF", "Es intencional: no se capturan páginas aproximadas"],
        ["La calificación no es la esperada", "Una OM o «Potencial» mal registrado", "Revisar el riesgo de cada observación (S03)"],
        ["El paso no queda «hecho»", "Falta algo del paso", "Abrir la guía «?»: dice qué falta"],
    ]
    tabla(s, MARGEN, 1.65, 12.13, filas, [3.4, 3.9, 4.83], tam=12, alto_fila=0.54)


def d_pruebas(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "Antes de dar por bueno cualquier cambio, se corre la suite de tests. No cuesta nada: "
        "la IA está simulada."))
    encabezado(s, "Cómo probar un cambio", "Tests sin coste antes de entregar")
    codigo(s, MARGEN, 1.7, 6.6, 2.0,
           "# Suite completa (~8 min, en segundo plano)\n"
           ".venv\\Scripts\\python.exe -m pytest -q\n\n"
           "# Un área concreta\n"
           ".venv\\Scripts\\python.exe -m pytest tests/test_X.py -q", 13)
    areas = [
        ["Área", "Tests"],
        ["Solo Informe", "test_solo_informe*.py"],
        ["Plantilla de informes", "test_plantilla_bcp.py"],
        ["Capturas", "test_capturas.py"],
        ["Reglas regulatorias", "test_regresion.py · test_pendientes_auditoria.py"],
        ["Proveedor de IA", "test_estructura_config.py · test_azure_mocks.py"],
        ["RAG", "test_rag_lexico.py"],
        ["Chat", "test_consolidacion.py · test_acta_cierre.py"],
        ["Guía y presentación", "test_guia_agente.py · test_presentacion_guia.py"],
    ]
    tabla(s, 7.5, 1.7, 5.23, areas, [1.9, 3.33], tam=11, alto_fila=0.5)
    pasos = [("Escribir o ajustar el test del área", SELLO), ("Correr el test del área", TINTA),
             ("Correr la suite completa", TINTA), ("Regenerar guía, presentación y grafo", VERDE)]
    for k, (t, c) in enumerate(pasos):
        y = 4.05 + k * 0.62
        circulo(s, MARGEN, y, 0.42, c, str(k + 1), 12)
        texto(s, MARGEN + 0.6, y + 0.03, 6.0, 0.4, t, 14, TEXTO)


def d_cierre(m: Mazo):
    s = m.nueva("Cierre", oscura=True, notas=(
        "Resumen final y dónde encontrar más información."))
    texto(s, MARGEN, 0.9, 11, 0.4, "EN RESUMEN", 13, MOSTAZA, negrita=True)
    texto(s, MARGEN, 1.35, 12, 1.0, "Evidencia + estándar → informe calificado y trazable", 34,
          BLANCO, fuente=TITULAR)
    puntos = [
        ("Web guiada", f"{N_PASOS} pasos, {N_OBLIGATORIOS} obligatorios; el botón «?» dice qué falta."),
        ("Solo Informe", "El Word oficial sin pipeline; la IA es opcional."),
        ("Una regla", "Misma plantilla y calificación para los tres informes."),
        ("IA con control", "Azure GPT por defecto, salvaguardas y citas verificables."),
    ]
    for k, (t, d) in enumerate(puntos):
        x = MARGEN + k * 3.08
        rect(s, x, 2.85, 2.85, 2.2, relleno=TINTA2, redondeado=True)
        texto(s, x + 0.25, 3.05, 2.4, 0.4, t, 17, MOSTAZA if k % 2 else BLANCO, negrita=True)
        texto(s, x + 0.25, 3.55, 2.4, 1.4, d, 14, CLARO_TENUE)
    texto(s, MARGEN, 5.45, 12, 0.35, "MÁS INFORMACIÓN", 11, MOSTAZA, negrita=True)
    texto(s, MARGEN, 5.8, 12, 0.9,
          "docs/agente_corporativo/GUIA_VIRF_AGENTE_CORPORATIVO.pdf · CONOCIMIENTO_VIRF.md · "
          f"skills/{rango_skills()} · docs/MAPA_HERRAMIENTA.md · docs/GUIA_ERRORES_Y_SOPORTE.md", 13, CLARO_TENUE, fuente=MONO)


# ══════════════════════════════════════════════════════════════════════
#  Diapositivas nuevas (2026-11-24): cifras, validación completa, tipos de
#  modelo, calidad de datos, run-off y soporte
# ══════════════════════════════════════════════════════════════════════

def grafico(s, tipo, x, y, w, h, categorias, series: list[tuple[str, list]], colores: list[RGBColor],
            titulo: str = "", etiquetas=True, formato="0", leyenda=False, nombre=""):
    """Gráfico nativo de PowerPoint con el estilo del mazo (sin rejilla, etiquetas grises)."""
    datos = CategoryChartData()
    datos.categories = categorias
    for n, v in series:
        datos.add_series(n, v)
    gf = s.shapes.add_chart(tipo, Inches(x), Inches(y), Inches(w), Inches(h), datos)
    if nombre:
        gf.name = nombre
    ch = gf.chart
    ch.font.size, ch.font.name = Pt(11), CUERPO
    ch.font.color.rgb = TENUE
    ch.has_title = bool(titulo)
    if titulo:
        ch.chart_title.text_frame.text = titulo
        p = ch.chart_title.text_frame.paragraphs[0]
        p.runs[0].font.size, p.runs[0].font.bold, p.runs[0].font.name = Pt(13), True, CUERPO
        p.runs[0].font.color.rgb = TINTA
    ch.has_legend = leyenda
    if leyenda:
        ch.legend.position = XL_LEGEND_POSITION.BOTTOM
        ch.legend.include_in_layout = False
        ch.legend.font.size = Pt(11)
    va = ch.value_axis
    va.has_major_gridlines = False
    va.format.line.fill.background()
    ca = ch.category_axis
    ca.format.line.color.rgb = LINEA
    ca.tick_labels.font.size = Pt(11)
    va.tick_labels.font.size = Pt(10)
    for k, serie in enumerate(ch.plots[0].series):
        color = colores[k % len(colores)]
        if tipo in (XL_CHART_TYPE.LINE, XL_CHART_TYPE.LINE_MARKERS):
            serie.format.line.color.rgb = color
            serie.format.line.width = Pt(2.5)
            serie.smooth = False
        else:
            serie.format.fill.solid()
            serie.format.fill.fore_color.rgb = color
    if etiquetas and tipo not in (XL_CHART_TYPE.LINE, XL_CHART_TYPE.LINE_MARKERS):
        pl = ch.plots[0]
        pl.has_data_labels = True
        dl = pl.data_labels
        dl.number_format, dl.number_format_is_linked = formato, False
        dl.position = XL_LABEL_POSITION.OUTSIDE_END
        dl.font.size, dl.font.bold = Pt(11), True
        dl.font.color.rgb = TINTA
        pl.gap_width = 60
    return ch


def d_cifras(m: Mazo, cif: dict[str, str], seccion: str = "Introducción"):
    s = m.nueva(seccion, notas=(
        "Todas las cifras salen de docs/MAPA_HERRAMIENTA.md §1, que su generador calcula leyendo el "
        "código (menú, endpoints, fichas, catálogo, repositorio, librería). Si la herramienta cambia, "
        "se regenera el mapa y esta diapositiva lo refleja sola."))
    encabezado(s, "VIRF en cifras", "Lo que la herramienta trae hoy, contado desde el código")
    grandes = [
        (("Opciones del menú",), "opciones del menú de la web"),
        (("Etapas de la validación completa",), "etapas de la validación completa"),
        (("Tipos de modelo",), "tipos de modelo con ficha de negocio"),
        (("Controles de negocio",), "controles de negocio en las fichas (M)"),
        (("Tipos de control del catálogo",), "tipos de control del catálogo de datos"),
        (("Análisis del repositorio",), "análisis del repositorio (D)"),
        (("librería cuantitativa",), "funciones de la librería cuantitativa"),
        (("Endpoints",), "endpoints de la web (método + ruta)"),
    ]
    for k, (claves, etiqueta) in enumerate(grandes):
        col, fila = k % 4, k // 4
        x, y = MARGEN + col * 3.08, 1.65 + fila * 1.85
        num, detalle = cifra(cif, *claves)
        rect(s, x, y, 2.85, 1.65, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        texto(s, x + 0.25, y + 0.12, 2.4, 0.8, num, 40, SELLO if k % 2 == 0 else TINTA,
              fuente=TITULAR, negrita=True)
        texto(s, x + 0.25, y + 0.92, 2.4, 0.35, etiqueta, 12, TEXTO)
        if detalle:
            texto(s, x + 0.25, y + 1.22, 2.45, 0.3, detalle.replace(": ", " ").replace(", ", " · "),
                  11, TENUE)
    n_arch, n_capas = archivos_de_codigo(cif)
    chicas = [(str(n_arch), f"archivos de código en {n_capas} capas"),
              (cifra(cif, "Mensajes de error")[0], "mensajes de error distintos"),
              (cifra(cif, "CLI")[0], "opciones de la CLI"),
              (cifra(cif, "Parámetros")[0], "parámetros de configuración"),
              (cifra(cif, "Scripts")[0], "scripts"),
              (cifra(cif, "Documentos Markdown")[0], "documentos")]
    ancho = 12.13 / len(chicas)
    rect(s, MARGEN, 5.42, 12.13, 1.15, relleno=TINTA2, redondeado=True)
    for k, (num, etiqueta) in enumerate(chicas):
        x = MARGEN + k * ancho
        texto(s, x + 0.2, 5.52, ancho - 0.3, 0.5, num, 24, MOSTAZA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.2, 6.03, ancho - 0.3, 0.45, etiqueta, 11, CLARO_TENUE)
    nota_tecnica(s, 6.68, "Fuente: docs/MAPA_HERRAMIENTA.md §1 (scripts/generar_mapa_herramienta.py)")


def d_modalidad(m: Mazo, filas: list[list[str]], seccion="Validación completa"):
    s = m.nueva(seccion, notas=(
        "La modalidad se elige en la ficha del modelo y nunca se deduce. La normal es el flujo "
        "habitual; la completa añade cinco etapas con notebooks antes del barrido de controles, y "
        "su trabajo llega al 08, al 09 y al 10. Tabla tomada de docs/MAPA_HERRAMIENTA.md §4."))
    encabezado(s, "Dos modalidades", "Validación normal o completa: siempre explícita")
    chip(s, MARGEN, 1.6, 5.2, "modalidad = normal | completa · nunca se deduce", TINTA, tam=12, h=0.42)
    filas = [list(f) for f in filas]
    filas[0][0] = filas[0][0] or "En cada paso"
    t = tabla(s, MARGEN, 2.3, 12.13, filas, [2.9, 4.2, 5.03], tam=13, alto_fila=0.72)
    for i in range(1, len(filas)):
        for r in t.cell(i, 0).text_frame.paragraphs[0].runs:
            r.font.bold = True
    for r in t.cell(0, 2).text_frame.paragraphs[0].runs:
        r.font.color.rgb = MOSTAZA


def d_etapas_resumen(m: Mazo, seccion="Validación completa"):
    s = m.nueva(seccion, notas=(
        "Cinco etapas, cada una con un experto distinto que el agente adopta en su chat. Las "
        "etapas se apoyan en las anteriores. Nombres, expertos y número de pasos salen de "
        "modulos/validacion_completa.py y modulos/plantillas_etapa.py."))
    encabezado(s, "Las cinco etapas", "Un experto distinto en cada etapa, de los datos al seguimiento")
    ancho = (12.13 - 4 * 0.2) / 5
    colores = [TINTA, SELLO, SELLO, NARANJA, VERDE]
    for k, (codigo, e) in enumerate(VC.ETAPAS.items()):
        x = MARGEN + k * (ancho + 0.2)
        rect(s, x, 1.65, ancho, 4.85, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.22, 1.88, 0.62, colores[k % len(colores)], codigo, 15)
        texto(s, x + 0.22, 2.65, ancho - 0.44, 0.75, e["nombre"], 18, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.22, 3.4, ancho - 0.44, 0.3, "EXPERTO", 10, SELLO, negrita=True)
        texto(s, x + 0.22, 3.68, ancho - 0.44, 1.0, experto_corto(codigo), 12, TEXTO)
        texto(s, x + 0.22, 4.72, ancho - 0.44, 0.3, "ENTREGA", 10, SELLO, negrita=True)
        texto(s, x + 0.22, 5.0, ancho - 0.44, 0.5, e["tabla"], 12, TEXTO)
        previas = " · ".join(e["previas"]) or "—"
        texto(s, x + 0.22, 5.62, ancho - 0.44, 0.7,
              f"{len(PE.RUTAS[codigo])} pasos\nusa: {previas}", 11, TENUE)
        if k < 4:
            texto(s, x + ancho - 0.02, 3.95, 0.24, 0.4, "→", 16, SELLO, negrita=True, alinear=PP_ALIGN.CENTER)


def d_etapa(m: Mazo, codigo: str, seccion="Validación completa"):
    e = VC.ETAPAS[codigo]
    ruta = PE.RUTAS[codigo]
    s = m.nueva(seccion, notas=(
        f"Etapa {codigo} · {e['nombre']}. {PE.EXPERTOS[codigo]} La ruta se verifica contra los "
        "títulos «## Paso XX.n» del notebook: sin pasos cubiertos no hay veredicto «lista». "
        "Fuente: modulos/plantillas_etapa.py (EXPERTOS, RUTAS)."))
    lema = e["tabla"] if e["tabla"].lower() != e["nombre"].lower() else experto_corto(codigo)
    encabezado(s, f"Etapa {codigo} · {e['fichero']}", f"{e['nombre']}: {lema[:1].lower()}{lema[1:]}")
    rect(s, MARGEN, 1.65, 4.15, 4.95, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, MARGEN + 0.25, 1.85, 3.7, 0.3, "EL EXPERTO", 10, SELLO, negrita=True)
    texto(s, MARGEN + 0.25, 2.15, 3.7, 3.0, PE.EXPERTOS[codigo], 12, TEXTO, interlineado=1.05)
    texto(s, MARGEN + 0.25, 5.25, 3.7, 0.3, "VA A LA EVIDENCIA DEL 08", 10, SELLO, negrita=True)
    texto(s, MARGEN + 0.25, 5.55, 3.7, 0.9,
          f"{VC.DESTINO_EVIDENCIA[codigo]}/\n{VC.SUBCARPETA_PUENTE}/", 11, TINTA, fuente=MONO)
    filas = [["Paso", "Qué se hace", "Hoja del Excel"]] + [[f"{p} {t}", q, h] for p, t, q, h, _ in ruta]
    alto = min(0.56, 4.95 / len(filas))
    t = tabla(s, 4.95, 1.65, 7.78, filas, [2.2, 3.73, 1.85], tam=11, alto_fila=alto)
    for i in range(1, len(filas)):
        for r in t.cell(i, 0).text_frame.paragraphs[0].runs:
            r.font.bold = True


def d_ciclo(m: Mazo, seccion="Validación completa"):
    s = m.nueva(seccion, notas=(
        "Cada etapa es un chat con su experto. El agente entrega un notebook; el validador lo "
        "ejecuta en su equipo, donde están los datos, y devuelve el Excel de resultados con "
        "comentarios e imágenes. Se itera hasta que la etapa cumple. Cerrar la etapa es una decisión "
        "del validador: el agente solo lo recomienda. Fuente: modulos/validacion_completa.py."))
    encabezado(s, "Cómo avanza una etapa", "Notebook → ejecución local → Excel → nueva iteración")
    f0 = VC.ETAPAS["00"]["fichero"]
    pasos = [
        ("Insumos", "Manuales, Excels de la primera línea y scripts: el agente los estudia enteros."),
        ("Notebook", "El agente entrega el notebook de la iteración con la ruta de la etapa."),
        ("Ejecución local", "El validador lo corre donde están los datos. Los datos no viajan."),
        ("Excel", "El notebook escribe su Excel de resultados; vuelve con comentarios e imágenes."),
        ("Nueva iteración", "El agente revisa y entrega la siguiente, hasta que la etapa cumple."),
    ]
    ancho = (12.13 - 4 * 0.25) / 5
    for k, (t, d) in enumerate(pasos):
        x = MARGEN + k * (ancho + 0.25)
        rect(s, x, 1.65, ancho, 2.0, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.2, 1.85, 0.5, SELLO if k < 4 else VERDE, str(k + 1), 14)
        texto(s, x + 0.82, 1.9, ancho - 0.95, 0.4, t, 14, TINTA, negrita=True, anclaje=MSO_ANCHOR.MIDDLE)
        texto(s, x + 0.2, 2.5, ancho - 0.4, 1.1, d, 12, TEXTO, interlineado=1.05)
        if k < 4:
            texto(s, x + ancho - 0.02, 2.45, 0.29, 0.4, "→", 16, SELLO, negrita=True, alinear=PP_ALIGN.CENTER)
    # Los nombres reales de los archivos (VC.nombre_resultado), en una franja para que no se corten
    rect(s, MARGEN, 3.82, 12.13, 0.5, relleno=TINTA2, redondeado=True)
    texto(s, MARGEN + 0.25, 3.82, 11.7, 0.5,
          f"{f0}ITER0.ipynb  →  {VC.nombre_resultado('00', 0)}  →  {f0}ITER1.ipynb  →  …",
          12, RGBColor(0xE6, 0xE1, 0xD6), fuente=MONO, anclaje=MSO_ANCHOR.MIDDLE)
    # Cierre y consolidado
    rect(s, MARGEN, 4.5, 5.95, 2.1, relleno=VERDE_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.3, 4.65, 5.4, 0.35, "Cierre: lo decide el validador", 15, TINTA, negrita=True)
    lista(s, MARGEN + 0.3, 5.1, 5.4, 1.4, [
        "El agente da su veredicto; **cerrar la etapa** es humano.",
        "Una etapa que no aplica se cierra con **motivo**.",
        "Se puede **reabrir** si aparece algo nuevo.",
    ], 13, espacio=4, color_marca=VERDE)
    rect(s, 6.78, 4.5, 5.95, 2.1, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 7.08, 4.65, 5.4, 0.35, "Consolidado de hallazgos", 15, TINTA, negrita=True)
    texto(s, 7.08, 5.05, 5.4, 0.6, "Cada hallazgo lleva nivel y estado entre iteraciones; todos van "
          "a HALLAZGOS_VALIDACION_COMPLETA.md.", 12, TEXTO)
    colores_nivel = [MOSTAZA, NARANJA, SELLO]
    for k, n in enumerate(VC.NIVELES):
        chip(s, 7.08 + k * 1.8, 5.7, 1.7, n, colores_nivel[k % 3], tam=11)
    for k, e in enumerate(VC.ESTADOS_HALLAZGO):
        chip(s, 7.08 + k * 1.8, 6.12, 1.7, e, TENUE if k < 2 else VERDE, tam=11)


def d_puente(m: Mazo, seccion="Validación completa"):
    s = m.nueva(seccion, notas=(
        "El puente: el 08 responde 409 mientras falte cerrar alguna etapa. Con las cinco cerradas, "
        "publicar_en_validacion copia solo entregables de VIRF a la evidencia, por ámbito, y "
        "consolida los hallazgos; nunca los datos enviados a los chats. Cada lanzamiento reemplaza "
        "lo publicado. El chat 09 recibe los hallazgos de las etapas del ámbito de cada observación "
        "y el informe 10 lleva el anexo. Fuente: modulos/validacion_completa.py."))
    n_val, n_rev, n_doc = (numero_paso("Validar modelo"), numero_paso("Revisión con el agente"),
                           numero_paso("Documentar"))
    encabezado(s, f"Puente a la validación final ({n_val} · {n_rev} · {n_doc})",
               "Con las cinco etapas cerradas, su trabajo pasa a la evidencia")
    rect(s, MARGEN, 1.62, 5.95, 0.85, relleno=SELLO_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.25, 1.62, 5.5, 0.85, f"**{n_val} · Validar** responde **409** mientras falte "
          "cerrar alguna etapa. Antes de lanzar, el panel enseña qué se publicará.", 12, TEXTO,
          anclaje=MSO_ANCHOR.MIDDLE)
    filas = [["Etapa", "Carpeta de evidencia (inputs/)"]]
    for c, destino in VC.DESTINO_EVIDENCIA.items():
        filas.append([f"{c} · {VC.ETAPAS[c]['nombre']}", f"{destino}/{VC.SUBCARPETA_PUENTE}/"])
    t = tabla(s, MARGEN, 2.65, 5.95, filas, [2.15, 3.8], tam=11, alto_fila=0.42)
    for i in range(1, len(filas)):
        for r in t.cell(i, 1).text_frame.paragraphs[0].runs:
            r.font.name, r.font.size = MONO, Pt(10)
    texto(s, MARGEN, 5.3, 5.95, 0.9, f"El Excel del 01 va además a {VC.DESTINO_CONTROLES_DATOS}/ "
          "y se puntúa en el ámbito «Calidad de datos». Solo viaja lo que generó VIRF, nunca los "
          "datos crudos.", 12, TEXTO)
    # 09: hallazgos por ámbito
    x = 6.95
    texto(s, x, 1.62, 5.78, 0.3, f"{n_rev} · REVISIÓN: HALLAZGOS POR ÁMBITO", 11, SELLO, negrita=True)
    for k, (ambito, etapas) in enumerate(VC.ETAPAS_POR_AMBITO.items()):
        y = 2.0 + k * 0.5
        texto(s, x, y, 3.3, 0.4, _AMBITO_BONITO.get(ambito, ambito.capitalize()), 13, TINTA,
              anclaje=MSO_ANCHOR.MIDDLE)
        for j, e in enumerate(etapas):
            chip(s, x + 3.45 + j * 0.78, y + 0.04, 0.68, e, TINTA if j == 0 else TENUE, tam=11)
    y = 2.0 + len(VC.ETAPAS_POR_AMBITO) * 0.5 + 0.2
    rect(s, x, y, 5.78, 6.6 - y, relleno=VERDE_SUAVE, redondeado=True)
    texto(s, x + 0.25, y + 0.12, 5.3, 0.35, f"{n_doc} · Informe Word", 14, TINTA, negrita=True)
    texto(s, x + 0.25, y + 0.5, 5.3, 6.5 - y - 0.5, "Lleva la tabla de validación final y un anexo "
          "con las etapas, sus hallazgos y las imágenes de sustento.", 12, TEXTO)


def d_tipos(m: Mazo, seccion="Tipos y calidad de datos"):
    familias = tipos_por_familia()
    total_m = sum(n for v in familias.values() for *_, n in v)
    s = m.nueva(seccion, notas=(
        f"{len(TIPOS)} fichas de negocio en tres familias. El tipo se elige explícito al crear el "
        "modelo (puede ser más de uno). Cada ficha trae bases lógicas con roles, controles con su "
        "porqué, preguntas a la primera línea, pasos de experto por etapa y métricas. Detalle en "
        "docs/GUIA_TIPOS_DE_MODELO.md. Fuente: modulos/tipos_modelo*.py."))
    encabezado(s, "Tipos de modelo", f"{len(TIPOS)} fichas de negocio · {total_m} controles de negocio (M)")
    texto(s, MARGEN, 1.55, 12.1, 0.5, "Cada ficha: **bases con roles** de negocio, **controles** con su "
          "porqué, **preguntas** a la primera línea, **pasos** de experto por etapa y **métricas**.", 13, TEXTO)
    colores = {"ALM": SELLO, "Liquidez": VERDE, "Trading": TINTA}
    for k, (familia, tipos) in enumerate(familias.items()):
        x = MARGEN + k * 4.1
        chip(s, x, 2.15, 3.85, f"{familia} · {len(tipos)} tipos", colores.get(familia, TENUE), tam=13, h=0.42)
        for j, (_, nombre, n) in enumerate(tipos):
            y = 2.72 + j * 0.56
            rect(s, x, y, 3.85, 0.48, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.5)
            texto(s, x + 0.15, y, 3.05, 0.48, nombre, 11, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
            texto(s, x + 3.15, y, 0.6, 0.48, f"{n} M", 11, colores.get(familia, TENUE), negrita=True,
                  alinear=PP_ALIGN.RIGHT, anclaje=MSO_ANCHOR.MIDDLE)


def d_capas(m: Mazo, filas: list[list[str]], seccion="Tipos y calidad de datos"):
    s = m.nueva(seccion, notas=(
        "El notebook de calidad de datos corre SIEMPRE todos los controles, por capas: la batería "
        "general, la dinámica, los de negocio del tipo de modelo, los análisis del repositorio del "
        "dominio, los propuestos por la IA, los aprendidos y los del propio validador. Termina en un "
        "porcentaje de cumplimiento. Tabla tomada de docs/MAPA_HERRAMIENTA.md §8."))
    encabezado(s, "Notebook de calidad de datos", "Siempre todos los controles, en capas")
    colores = [TINTA, TINTA, SELLO, SELLO, MOSTAZA, VERDE, TENUE]
    paso = min(0.64, 4.55 / max(len(filas) - 1, 1))
    for k, (capa, que, donde) in enumerate(filas[1:]):
        y = 1.62 + k * paso
        rect(s, MARGEN, y, 2.75, paso - 0.1, relleno=colores[k % len(colores)], redondeado=True)
        texto(s, MARGEN + 0.18, y, 2.5, paso - 0.1, capa, 12, BLANCO, negrita=True, anclaje=MSO_ANCHOR.MIDDLE)
        texto(s, MARGEN + 2.95, y, 5.9, paso - 0.1, que, 12, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
        texto(s, 9.6, y, 3.13, paso - 0.1, donde, 10, TENUE, fuente=MONO, anclaje=MSO_ANCHOR.MIDDLE)
    y = 1.62 + (len(filas) - 1) * paso + 0.12
    rect(s, MARGEN, y, 12.13, 6.65 - y, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.3, y, 11.5, 6.65 - y, "**Resultado:** % de cumplimiento = cumplen ÷ evaluados. "
          "Un control sin columna para su rol queda «Pendiente», nunca «Cumple».", 13, TEXTO,
          anclaje=MSO_ANCHOR.MIDDLE)


def d_catalogo(m: Mazo, cif: dict[str, str], seccion="Tipos y calidad de datos"):
    por_dim: dict[str, int] = {}
    for d in CI.CATALOGO.values():
        por_dim[d["dimension"]] = por_dim.get(d["dimension"], 0) + 1
    por_dim = dict(sorted(por_dim.items(), key=lambda kv: -kv[1]))
    total_d, detalle = cifra(cif, "Análisis del repositorio")
    repo = {a.split(":")[0].strip(): int(a.split(":")[1]) for a in detalle.split(",") if ":" in a}
    s = m.nueva(seccion, notas=(
        f"{len(CI.CATALOGO)} tipos de control en el catálogo (modulos/controles_ia.py), agrupados por "
        f"dimensión de calidad BCBS 239, y {total_d} análisis especializados en Python en "
        "inputs/repositorio_controles/<dominio>/. Las funciones viajan dentro del notebook; un "
        "análisis del repositorio entra en los tipos que declara en META['tipos']."))
    encabezado(s, "Catálogo y repositorio",
               f"{len(CI.CATALOGO)} tipos de control y {total_d} análisis por dominio")
    grafico(s, XL_CHART_TYPE.BAR_CLUSTERED, MARGEN, 1.6, 6.3, 4.6, list(por_dim), [("Tipos", list(por_dim.values()))],
            [SELLO], titulo="Tipos de control por dimensión", nombre="Gráfico dimensiones")
    grafico(s, XL_CHART_TYPE.COLUMN_CLUSTERED, 7.15, 1.6, 5.58, 4.6, list(repo), [("Análisis", list(repo.values()))],
            [TINTA], titulo="Análisis del repositorio por carpeta", nombre="Gráfico repositorio")
    texto(s, MARGEN, 6.35, 12.1, 0.4, "Cada análisis del repositorio define META (leído con ast) y "
          "control(df, datasets, params); shared/ vale para todos los dominios.", 12, TENUE, cursiva=True)


def d_aprendizaje(m: Mazo, seccion="Tipos y calidad de datos"):
    pasos = ciclo_aprendizaje()
    s = m.nueva(seccion, notas=(
        "El agente aprende sin reentrenar ningún modelo: guarda por dominio los controles que los "
        "validadores ejecutaron de verdad y los vuelve a proponer cuando la base tiene esas columnas. "
        "Solo con la marca explícita «Enseñar al agente» y con la aprobación de un revisor distinto "
        "del autor. Fuente: modulos/aprendizaje_controles.py."))
    encabezado(s, "Aprendizaje de controles", "El agente aprende solo lo que aprueba un revisor")
    ancho = (12.13 - 3 * 0.25) / 4
    for k, p in enumerate(pasos[:4]):
        x = MARGEN + k * (ancho + 0.25)
        rect(s, x, 1.65, ancho, 2.45, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.22, 1.85, 0.5, [TINTA, MOSTAZA, SELLO, VERDE][k], str(k + 1), 14)
        texto(s, x + 0.22, 2.5, ancho - 0.44, 1.55, p, 12, TEXTO, interlineado=1.05)
    rect(s, MARGEN, 4.4, 5.95, 2.2, relleno=SELLO_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.3, 4.55, 5.4, 0.35, "Qué NO aprende", 15, TINTA, negrita=True)
    lista(s, MARGEN + 0.3, 5.0, 5.4, 1.5, [
        "**Código:** los controles a mano quedan como candidatos al catálogo; nunca se ejecutan solos.",
        "**Datos:** solo definiciones y cifras agregadas.",
        "**Demos:** nada de los datos sintéticos.",
    ], 12, espacio=3)
    rect(s, 6.78, 4.4, 5.95, 2.2, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 7.08, 4.55, 5.4, 0.35, "Olvido y registro sellado", 15, TINTA, negrita=True)
    texto(s, 7.08, 5.0, 5.4, 1.5, "Un revisor puede negar una lección, y la que se descarta más "
          "veces de las que se usa deja de proponerse. El registro es append-only y cada evento "
          "lleva el hash del anterior: una edición a mano se detecta.", 12, TEXTO)


def d_runoff(m: Mazo, seccion="Run-off y librería"):
    from _sinteticos_tipos import runoff_bases
    bases = runoff_bases()
    curva, comp = bases["curva_runoff"], bases["componentes"]
    plazos = [0] + sorted(curva["plazo_meses"].unique().tolist())
    segmentos = list(comp["segmento"])
    series = []
    for seg in segmentos:
        c = curva[curva["segmento"] == seg].sort_values("plazo_meses")
        series.append((seg.capitalize(), [100.0] + [round(float(v), 2) for v in c["supervivencia"]]))
    s = m.nueva(seccion, notas=(
        "El run-off se valida como supervivencia del saldo, no como tasas de estrés. La curva S(t) "
        "dice qué parte del saldo de hoy sigue viva a los t meses. De ella salen el run-off acumulado, "
        "el desgaste de cada mes, la parte estable y la volátil, el plazo económico y la salida por "
        "banda. Las curvas del gráfico son las de los datos sintéticos de la demo (sin fallas)."))
    encabezado(s, "Run-off", "Supervivencia del saldo: cuánto del saldo de hoy sigue vivo")
    ch = grafico(s, XL_CHART_TYPE.LINE, MARGEN, 1.6, 6.6, 4.5, plazos, series, [SELLO, TINTA],
                 titulo="S(t): saldo que sobrevive (%) por mes", etiquetas=False, leyenda=True,
                 nombre="Gráfico supervivencia")
    _saltar_etiquetas(ch, 12)  # eje de meses: una etiqueta por año
    ch.value_axis.maximum_scale, ch.value_axis.minimum_scale = 100, 0
    for k, fila in enumerate(comp.itertuples()):
        x = MARGEN + k * 3.35
        rect(s, x, 6.2, 3.2, 0.5, relleno=[SELLO_SUAVE, LINEA][k % 2], redondeado=True)
        texto(s, x + 0.15, 6.2, 3.0, 0.5, f"**{fila.segmento.capitalize()}:** estable "
              f"{fila.porcion_estable:.0f} % · plazo {fila.plazo_economico:.1f} años".replace(".", ","),
              11, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
    x, w = 7.55, 5.18
    defs = [
        ("S(t)", "Supervivencia: parte del saldo de hoy que sigue a los t meses."),
        ("R = 1 − S", "Run-off acumulado: lo que ya salió."),
        ("d(t) = S(t−1) − S(t)", "Desgaste del mes: nunca negativo."),
        ("Estable · volátil", "Estable = S al horizonte largo; volátil = 1 − estable."),
        ("Plazo económico", "Área bajo S(t), en años: la vida media del saldo."),
        ("Bandas", "Salida por banda = S(desde) − S(hasta); todo el saldo queda asignado."),
    ]
    for k, (t, d) in enumerate(defs):
        y = 1.62 + k * 0.8
        texto(s, x, y, w, 0.3, t, 13, SELLO, fuente=MONO, negrita=True)
        texto(s, x, y + 0.32, w, 0.45, d, 12, TEXTO)


def _saltar_etiquetas(ch, cada: int):
    """Eje de categorías con una etiqueta cada `cada` categorías (meses → años)."""
    cat = ch.category_axis._element
    for tag in ("c:tickLblSkip", "c:tickMarkSkip"):
        el = cat.find(qn(tag))
        if el is None:
            el = etree.SubElement(cat, qn(tag))
        el.set("val", str(cada))
    # tickLblSkip/tickMarkSkip deben ir tras c:lblOffset (orden del esquema): se recolocan al final
    # del bloque de etiquetas para no romper el XML.
    off = cat.find(qn("c:lblOffset"))
    if off is not None:
        for tag in ("c:tickMarkSkip", "c:tickLblSkip"):
            el = cat.find(qn(tag))
            off.addnext(el)


def d_libreria(m: Mazo, seccion="Run-off y librería"):
    funciones = funciones_cuant()
    s = m.nueva(seccion, notas=(
        f"La librería cuantitativa tiene {len(funciones)} funciones y viaja dentro de los notebooks "
        "de las etapas 02 a 04: solo pandas y numpy, se valida con ast.parse y nunca se ejecuta en "
        "el servidor. La demo de run-off recorre las cinco etapas sin IA con fallas sembradas."))
    encabezado(s, "Librería cuantitativa y demo", f"{len(funciones)} funciones que viajan en los notebooks")
    for k, (grupo, nombres) in enumerate(GRUPOS_CUANT):
        y = 1.62 + k * 0.82
        texto(s, MARGEN, y, 6.4, 0.3, grupo, 14, TINTA, negrita=True)
        texto(s, MARGEN, y + 0.33, 6.4, 0.45, " · ".join(nombres), 11, TENUE, fuente=MONO)
    texto(s, MARGEN, 6.6, 6.4, 0.3, "Solo pandas y numpy · se valida con ast.parse · nunca corre en el "
          "servidor", 11, SELLO, cursiva=True)
    x, w = 7.3, 5.43
    texto(s, x, 1.62, w, 0.3, "DEMO DE PUNTA A PUNTA (00 → 04), SIN IA", 11, SELLO, negrita=True)
    codigo(s, x, 2.0, w, 0.8, ".venv\\Scripts\\python scripts\\demo_runoff.py", 12)
    texto(s, x, 3.05, w, 0.3, "Fallas sembradas que las etapas deben encontrar:", 13, TINTA, negrita=True)
    lista(s, x, 3.45, w, 2.6, fallas_demo_runoff(), 13, espacio=8)
    texto(s, x, 6.25, w, 0.5, "Todo queda en outputs/<fecha>/demo_runoff/; no escribe en "
          "feedback/ ni en audit_logs/.", 11, TENUE)


def d_soporte(m: Mazo, seccion="Mantenimiento"):
    docs = [
        (RAIZ / "docs" / "GUIA_ERRORES_Y_SOPORTE.md", "Protocolo en seis pasos, qué significa cada "
         "código de la web y los fallos de los notebooks.", SELLO),
        (RAIZ / "docs" / "GUIA_MEJORAS.md", "Qué mejorar, por qué, dónde y cómo comprobarlo, por "
         "prioridad (P0, P1…).", MOSTAZA),
        (RAIZ / "PROMPT_OTRO_ASISTENTE.md", "Prompts para trabajar VIRF con otro asistente, vea o no "
         "el repositorio.", TINTA),
        (RAIZ / ".claude" / "skills" / "soporte-virf" / "SKILL.md", "Skill de Claude Code: reglas que "
         "no se rompen, triaje síntoma → causa y verificación.", VERDE),
    ]
    s = m.nueva(seccion, notas=(
        "Cuatro piezas de soporte. La guía de errores para cuando algo falla; la de mejoras para "
        "decidir qué hacer después; el prompt para usar otro asistente; y la skill soporte-virf, con "
        "un chequeo de coste cero. Los mensajes exactos de la web están en el mapa §12."))
    encabezado(s, "Soporte y mejora continua", "Dónde mirar cuando algo falla y qué mejorar después")
    for k, (ruta, d, c) in enumerate(docs):
        col, fila = k % 2, k // 2
        x, y = MARGEN + col * 6.15, 1.62 + fila * 1.62
        rect(s, x, y, 5.95, 1.45, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.22, y + 0.22, 0.42, c, "?" if k == 0 else str(k + 1), 13)
        titulo = titulo_md(ruta) if ruta.name != "SKILL.md" else "Skill soporte-virf"
        titulo = re.sub(r"\s*\([^)]*\)", "", titulo).split(":")[0]  # sin «(estado al …)»
        texto(s, x + 0.8, y + 0.15, 4.95, 0.5, titulo, 14, TINTA, negrita=True,
              anclaje=MSO_ANCHOR.MIDDLE)
        texto(s, x + 0.8, y + 0.65, 4.95, 0.45, d, 12, TEXTO)
        texto(s, x + 0.8, y + 1.12, 4.95, 0.25, ruta.relative_to(RAIZ).as_posix(), 9, TENUE, fuente=MONO)
    codigo(s, MARGEN, 4.95, 12.13, 1.7,
           "# Chequeo de coste cero (entorno, finales de línea, guías y validador)\n"
           ".venv\\Scripts\\python .claude/skills/soporte-virf/scripts/chequeo.py\n"
           "# Antes y después de probar la web: huellas de los registros globales\n"
           ".venv\\Scripts\\python .claude/skills/soporte-virf/scripts/chequeo.py --foto | --comparar", 12)


def d_mejoras(m: Mazo, seccion="Mantenimiento"):
    filas = mejoras_resumen()
    s = m.nueva(seccion, notas=(
        "Las mejoras con más prioridad, tal como las ordena docs/GUIA_MEJORAS.md. P0 = antes de "
        "producción o de perder trabajo; P1 = la siguiente tanda. Esfuerzo: S ≤ 1 día, M 2–4 días, "
        "L ≥ 1 semana."))
    encabezado(s, "Qué mejorar después", "Por dónde empezar, según la guía de mejoras")
    filas = filas[:11]
    t = tabla(s, MARGEN, 1.6, 12.13, filas, [0.45, 1.0, 3.55, 6.13, 1.0], tam=11,
              alto_fila=min(0.46, 4.8 / len(filas)))
    for i in range(1, len(filas)):
        c = t.cell(i, 1)
        c.fill.solid()
        c.fill.fore_color.rgb = SELLO if filas[i][1] == "P0" else MOSTAZA
        for r in c.text_frame.paragraphs[0].runs:
            r.font.color.rgb, r.font.bold = BLANCO, True
    nota_tecnica(s, 6.7, "Fuente: docs/GUIA_MEJORAS.md «Resumen: por dónde empezar»")


def d_cierre_gerencia(m: Mazo):
    s = m.nueva("Cierre", oscura=True, notas=(
        "Mensaje final para la gerencia: VIRF ya cubre la validación completa con etapas y "
        "notebooks, conoce el negocio de cada tipo de modelo y mantiene la trazabilidad. Lo que "
        "queda antes de producción está en la guía de mejoras (P0)."))
    texto(s, MARGEN, 0.9, 11, 0.4, "EN RESUMEN", 13, MOSTAZA, negrita=True)
    texto(s, MARGEN, 1.35, 12, 1.0, "Validación más profunda, con la misma trazabilidad", 34, BLANCO,
          fuente=TITULAR)
    puntos = [
        ("Dos modalidades", f"Normal o completa, elegida en la ficha. La completa suma "
         f"{len(VC.ETAPAS)} etapas con notebooks."),
        ("Negocio", f"{len(TIPOS)} tipos de modelo con controles de negocio y pasos de experto."),
        ("Datos", f"{len(CI.CATALOGO)} tipos de control y aprendizaje solo con aprobación."),
        ("Control", "IA aprobada, datos en el equipo del validador y decisión siempre humana."),
    ]
    for k, (t, d) in enumerate(puntos):
        x = MARGEN + k * 3.08
        rect(s, x, 2.85, 2.85, 2.2, relleno=TINTA2, redondeado=True)
        texto(s, x + 0.25, 3.05, 2.4, 0.4, t, 17, MOSTAZA if k % 2 else BLANCO, negrita=True)
        texto(s, x + 0.25, 3.55, 2.4, 1.4, d, 14, CLARO_TENUE)
    p0 = [f[2] for f in mejoras_resumen()[1:] if f[1] == "P0"]
    texto(s, MARGEN, 5.4, 12, 0.35, "ANTES DE PRODUCCIÓN (GUÍA DE MEJORAS, P0)", 11, MOSTAZA, negrita=True)
    texto(s, MARGEN, 5.78, 12.1, 1.0, " · ".join(p0), 13, CLARO_TENUE)


# ══════════════════════════════════════════════════════════════════════
#  Construcción del mazo
# ══════════════════════════════════════════════════════════════════════

def _divisoria(m: Mazo, seccion: str):
    """Divisoria numerada según SECCIONES_GUIA."""
    for k, (nombre, titulo, subtitulo, _) in enumerate(SECCIONES_GUIA, 1):
        if nombre == seccion:
            return d_divisoria(m, nombre, k, titulo, subtitulo)
    raise KeyError(seccion)


def construir(salida: Path = SALIDA) -> Path:
    """Guía detallada de uso y soporte (validadores y mantenimiento)."""
    conocimiento = (DIR_GUIA / "CONOCIMIENTO_VIRF.md").read_text(encoding="utf-8")
    mapa = MAPA.read_text(encoding="utf-8")
    cif = cifras(mapa)
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        m = Mazo(tmp)
        logo = logo_png(tmp)

        d_portada(m, logo)
        d_agenda(m)
        d_que_es(m)
        d_cifras(m, cif)
        d_formas_uso(m)
        d_vocabulario(m)

        _divisoria(m, "Primeros pasos")
        d_arranque(m)
        for clave in ("01_login", "02_mis_modelos", "03_nuevo_modelo", "04_dashboard_inicio",
                      "16_guia_ayuda"):
            d_pantalla(m, "Primeros pasos", clave, etiqueta="Primeros pasos")

        _divisoria(m, SECCION_PASOS)
        d_flujo(m)
        for clave in ("05_configuracion", "06_estandares", "07_evidencia", "08_dominio_rag",
                      "09_skills", "10_cuestionamientos"):
            d_pantalla(m, SECCION_PASOS, clave)
        d_prevuelo(m)
        for clave in ("11_validar", "15_chat", "12_documentar"):
            d_pantalla(m, SECCION_PASOS, clave)

        _divisoria(m, "Validación completa")
        d_modalidad(m, tabla_md(mapa, "4."))
        d_etapas_resumen(m)
        d_ciclo(m)
        d_pantalla(m, "Validación completa", "23_etapa_vista")
        d_pantalla(m, "Validación completa", "24_etapa_ruta")
        for codigo in VC.ETAPAS:
            d_etapa(m, codigo)
        d_puente(m)
        d_pantalla(m, "Validación completa", "25_validar_bloqueado")

        _divisoria(m, "Tipos y calidad de datos")
        d_tipos(m)
        d_capas(m, tabla_md(mapa, "8."))
        d_catalogo(m, cif)
        d_aprendizaje(m)

        _divisoria(m, "Run-off y librería")
        d_runoff(m)
        d_libreria(m)

        _divisoria(m, "Consultas")
        for clave in ("13_resultados", "14_controles_datos"):
            d_pantalla(m, "Consultas", clave)
        d_consultas_chat_estados(m)
        d_movil(m)

        _divisoria(m, "Solo Informe")
        d_solo_informe_que(m)
        for clave in ("17_solo_informe", "18_solo_informe_datos", "19_solo_informe_observacion"):
            d_pantalla(m, "Solo Informe", clave)
        d_solo_informe_reglas(m)
        d_solo_informe_ia(m)

        _divisoria(m, "El informe Word")
        d_informe_estructura(m, pagina_pdf(EJ_RESULTADOS, 1, tmp), pagina_pdf(EJ_RESULTADOS, 2, tmp))
        d_informe_paginas(m, [
            (pagina_pdf(EJ_RESULTADOS, 4, tmp), "III · IV", "Cumplimiento por ámbito y ficha del documento."),
            (pagina_pdf(EJ_RESULTADOS, 5, tmp), "IV.4 Conclusión", "Calificación con su motivo y conteos."),
            (pagina_pdf(EJ_RESULTADOS, 6, tmp), "V · VI", "Cuadro resumen de observaciones y glosario."),
        ])
        d_barrido(m, pagina_pdf(EJ_RESULTADOS, 8, tmp), pagina_pdf(EJ_WEB_CAPTURAS, 32, tmp),
                  pagina_pdf(EJ_WEB_CAPTURAS, 34, tmp))
        d_tres_informes(m)

        _divisoria(m, "Calificación")
        d_regla(m)
        d_ejemplos(m)
        d_puntaje(m)

        _divisoria(m, "IA y seguridad")
        d_ia(m)
        d_salvaguardas(m)

        _divisoria(m, "Mantenimiento")
        d_arquitectura(m)
        d_reglas_oro(m, reglas_de_oro(conocimiento))
        d_soporte(m)
        d_problemas(m)
        d_mejoras(m)
        d_agente_corporativo(m)
        d_sintoma(m, sintoma_skill(conocimiento))
        d_grafo(m)
        d_pruebas(m)

        d_cierre(m)
        m.guardar(salida)
    return salida


def construir_gerencia(salida: Path = SALIDA_GERENCIA) -> Path:
    """Visión general corta para la gerencia: qué hace VIRF y qué trae de nuevo."""
    mapa = MAPA.read_text(encoding="utf-8")
    cif = cifras(mapa)
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        m = Mazo(tmp, pie="VIRF · Visión general")
        d_portada(m, logo_png(tmp), titulo="VIRF · Visión general",
                  subtitulo="Qué hace el agente de validación, qué cubre hoy y con qué controles.",
                  notas=("Visión general de VIRF para la gerencia, unos 15 minutos. El detalle de uso "
                         "y soporte está en la guía de la herramienta (GUIA_VIRF_PRESENTACION.pptx)."))
        d_que_es(m)
        d_cifras(m, cif)
        d_modalidad(m, tabla_md(mapa, "4."), seccion="Validación completa")
        d_etapas_resumen(m)
        d_pantalla(m, "Validación completa", "23_etapa_vista")
        d_puente(m)
        d_tipos(m, seccion="Negocio y datos")
        d_capas(m, tabla_md(mapa, "8."), seccion="Negocio y datos")
        d_runoff(m, seccion="Negocio y datos")
        d_regla(m)
        d_salvaguardas(m)
        d_cierre_gerencia(m)
        m.guardar(salida)
    return salida


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--salida", type=Path, default=SALIDA, help="Ruta de la guía detallada (.pptx).")
    ap.add_argument("--salida-gerencia", type=Path, default=SALIDA_GERENCIA,
                    help="Ruta de la visión general para la gerencia (.pptx).")
    args = ap.parse_args(argv)
    for ruta in (construir(args.salida), construir_gerencia(args.salida_gerencia)):
        print(f"Presentación generada: {ruta}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
