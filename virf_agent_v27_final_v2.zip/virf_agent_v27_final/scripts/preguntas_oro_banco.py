#!/usr/bin/env python3
"""
scripts/preguntas_oro_banco.py — ¿recupera el corpus del BANCO el documento correcto?

    python scripts/preguntas_oro_banco.py            # informe
    python scripts/preguntas_oro_banco.py --strict   # exit 1 si recall@1 < 100 %

Set de preguntas-oro del corpus `inputs/rag/banco/` (material que usa el banco
para validar). Va APARTE de `scripts/preguntas_oro_rag.py` a propósito: aquel
mide los dominios de modelo (LaR, VaR, ALM, shared) y sus umbrales están
calibrados con ese corpus; mezclarlos movería sus métricas sin que cambiara
nada en esos dominios.

Cada pregunta está redactada como la haría un validador (no copiando la frase
del documento) y su `hecho` transcribe el dato que la sostiene, para que un
humano pueda comprobarla sin ejecutar nada.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

RAIZ = Path(__file__).resolve().parent.parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

PREGUNTAS_BANCO: List[Dict] = [
    {"id": "BAN-01", "fuente": "procedimiento",
     "pregunta": "¿Puede firmar la validación quien desarrolló el modelo?",
     "hecho": "Incompatibilidad estricta: quien desarrolló el modelo no puede firmar su validación."},
    {"id": "BAN-02", "fuente": "procedimiento",
     "pregunta": "¿Cuántos años se conservan los informes de validación emitidos?",
     "hecho": "§8 retención: 5 años desde la emisión del informe."},
    {"id": "BAN-03", "fuente": "procedimiento",
     "pregunta": "¿Qué peso tiene el ámbito de metodología en el puntaje global?",
     "hecho": "Metodología 0.30 — SR 11-7 §IV conceptual soundness."},
    {"id": "BAN-04", "fuente": "procedimiento",
     "pregunta": "¿Cuándo un hallazgo se considera crítico de forma automática?",
     "hecho": "§6: crítico si el score del ámbito afectado es ≤ 2."},
    {"id": "BAN-05", "fuente": "estandar",
     "pregunta": "¿En qué tiers se exige revisar la coherencia del manual de implementación "
                 "con el metodológico?",
     "hecho": "Estándar: «Verificar la coherencia del manual de implementación…» aplica a Tier I, III."},
    {"id": "BAN-06", "fuente": "catalogo_controles",
     "pregunta": "¿Qué control de datos detecta un VaR estimado negativo o igual a cero?",
     "hecho": "Control var negativos: el VaR estimado debe ser estrictamente positivo."},
    {"id": "BAN-07", "fuente": "catalogo_controles",
     "pregunta": "¿Qué control de datos aplica al coeficiente de cobertura de liquidez LCR?",
     "hecho": "Controles de liquidez: lcr (cobertura de liquidez)."},
    {"id": "BAN-08", "fuente": "reglas_informe",
     "pregunta": "¿Con cuántas observaciones críticas la gestión del modelo es deficiente?",
     "hecho": "Deficiente: más de 2 observaciones críticas."},
    {"id": "BAN-09", "fuente": "reglas_informe",
     "pregunta": "¿Una oportunidad de mejora necesita responsable y fecha de subsanación?",
     "hecho": "Una Oportunidad de Mejora no lleva responsable ni fecha de subsanación."},
]


def evaluar(buscador=None, top_k: int = 3) -> Dict:
    """Recall@1 y @3 de las preguntas-oro sobre el buscador dado (o el del corpus banco)."""
    if buscador is None:
        from src.rag.buscador_lexico import get_buscador
        buscador = get_buscador("banco")
    filas = []
    for p in PREGUNTAS_BANCO:
        res = buscador.buscar(p["pregunta"], top_k=top_k)
        fuentes = [r["fuente"] for r in res]
        r1 = bool(fuentes) and p["fuente"] in fuentes[0]
        r3 = any(p["fuente"] in f for f in fuentes[:3])
        filas.append({**p, "recuperado": fuentes, "r1": r1, "r3": r3})
    n = len(filas) or 1
    return {"filas": filas, "recall_1": sum(f["r1"] for f in filas) / n,
            "recall_3": sum(f["r3"] for f in filas) / n}


def main(argv: Optional[list] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--strict", action="store_true")
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    r = evaluar()
    for f in r["filas"]:
        marca = "✅" if f["r1"] else ("🟡" if f["r3"] else "❌")
        print(f"  {marca} {f['id']}: {f['pregunta']}\n       → {f['recuperado'][:3]}")
    print(f"\n  recall@1 = {r['recall_1']:.0%} · recall@3 = {r['recall_3']:.0%} "
          f"({len(r['filas'])} preguntas)")
    return 1 if a.strict and r["recall_1"] < 1.0 else 0


if __name__ == "__main__":
    raise SystemExit(main())
