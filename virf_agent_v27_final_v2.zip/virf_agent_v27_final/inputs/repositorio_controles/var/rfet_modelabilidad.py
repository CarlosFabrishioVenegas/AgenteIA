"""Control FRTB: prueba de elegibilidad de factores de riesgo (RFET, «modelabilidad»)."""

META = {
    "descripcion": "Cada factor de riesgo es modelable (RFET): en los últimos 12 meses tiene ≥ 24 observaciones reales sin ningún periodo de 90 días con menos de 4, o ≥ 100 observaciones.",
    "dimension":   "Datos de mercado (FRTB)",
    "evidencia":   "Observaciones reales de precios (transacciones o cotizaciones ejecutables) por factor y fecha.",
    "referencia":  "BCBS d457 (FRTB): risk factor eligibility test (RFET)",
    "orden":       41,
    "tipos":       ["es_frtb"],
    "params": {"dataset": "", "campo_factor": "factor", "campo_fecha": "fecha", "min_obs": 24, "min_obs_90d": 4,
               "obs_alternativa": 100, "minimo_pct_modelables": 100.0},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cfa, cfe = params.get("campo_factor", "factor"), params.get("campo_fecha", "fecha")
    if cfa not in cols or cfe not in cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"faltan '{cfa}' y/o '{cfe}'"}
    f = pd.to_datetime(df[cfe].astype(str), errors="coerce")
    d = pd.DataFrame({"factor": df[cfa].astype(str), "f": f}).dropna().drop_duplicates()
    if d.empty:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin fechas legibles"}
    fin = d["f"].max().normalize()
    ini = fin - pd.Timedelta(days=365)
    d = d[d["f"] > ini]
    inicios = pd.date_range(ini, fin - pd.Timedelta(days=89), freq="D")
    min_obs, min90, alt = (int(params.get("min_obs", 24)), int(params.get("min_obs_90d", 4)),
                           int(params.get("obs_alternativa", 100)))
    no_mod = []
    for fac, g in d.groupby("factor"):
        fechas = np.sort(g["f"].dt.normalize().unique())
        n = len(fechas)
        if n >= alt:
            continue
        ok = n >= min_obs
        if ok and len(inicios):
            ini_ns = inicios.to_numpy()
            fin_ns = (inicios + pd.Timedelta(days=90)).to_numpy()
            cuenta = np.searchsorted(fechas, fin_ns, side="left") - np.searchsorted(fechas, ini_ns, side="left")
            ok = bool((cuenta >= min90).all())
        if not ok:
            no_mod.append(f"{fac} ({n} obs)")
    total = int(d["factor"].nunique())
    if total == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin observaciones en los últimos 12 meses"}
    pct = round(100.0 * (total - len(no_mod)) / total, 2)
    dec = "Cumple" if pct >= float(params.get("minimo_pct_modelables", 100.0)) else "Observado"
    return {"pct": pct, "decision": dec,
            "diagnostico": (f"{total - len(no_mod)} de {total} factores modelables al {fin.date()}"
                            + (f"; no modelables (van a la carga NMRF): {', '.join(no_mod[:6])}" if no_mod else ""))}
