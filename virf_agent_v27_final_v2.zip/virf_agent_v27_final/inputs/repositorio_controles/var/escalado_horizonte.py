"""Control VaR: el VaR a 10 días es coherente con el de 1 día (escalado √10 o cálculo directo documentado)."""

META = {
    "descripcion": "El VaR a 10 días es coherente con el VaR a 1 día: si se escala por la raíz del tiempo, VaR10 ≈ √10 × VaR1 (3,16 veces) en casi todos los días.",
    "dimension":   "Metodología (VaR)",
    "evidencia":   "VaR 1 y 10 días por fecha y el método de escalado declarado en el manual.",
    "referencia":  "Basilea — enmienda de riesgo de mercado (horizonte de 10 días; escalado por √t)",
    "orden":       35,
    "tipos":       ["var"],
    "params": {"dataset": "", "campo_var": "var_99", "campo_var_10d": "var_10d", "tolerancia_pct": 5.0,
               "minimo_pct_dias": 95.0},
}


def control(df, datasets, params):
    import math
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c1, c10 = params.get("campo_var", "var_99"), params.get("campo_var_10d", "var_10d")
    if c1 not in cols or c10 not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan las columnas de VaR 1 día '{c1}' y/o 10 días '{c10}'"}
    v1 = pd.to_numeric(df[c1], errors="coerce").abs()
    v10 = pd.to_numeric(df[c10], errors="coerce").abs()
    ok = v1.notna() & v10.notna() & (v1 > 0)
    if int(ok.sum()) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin pares VaR 1d / 10d"}
    ratio = v10[ok] / v1[ok]
    tol = float(params.get("tolerancia_pct", 5.0)) / 100
    dentro = ((ratio / math.sqrt(10) - 1).abs() <= tol)
    pct = round(100.0 * float(dentro.mean()), 2)
    cumple = pct >= float(params.get("minimo_pct_dias", 95.0))
    return {"pct": pct, "decision": "Cumple" if cumple else "Observado",
            "diagnostico": (f"VaR10/VaR1 mediano {ratio.median():.3f} (√10 = {math.sqrt(10):.3f}); {pct:.1f} % de los días "
                            f"dentro de ±{tol:.0%}" + ("" if cumple else
                                                       "; si el 10 días se calcula directo, documenta el método"))}
