"""Control VaR paramétrico: la matriz de correlaciones es simétrica, con unos en la diagonal y semidefinida positiva."""

META = {
    "descripcion": "La matriz de correlaciones del VaR paramétrico es simétrica, tiene unos en la diagonal y es semidefinida positiva (ningún autovalor negativo).",
    "dimension":   "Metodología (VaR)",
    "evidencia":   "Matriz de correlaciones (o covarianzas) usada en el cálculo, por fecha.",
    "referencia":  "VaR paramétrico (varianza-covarianza): σ²_P = wᵀΣw exige Σ semidefinida positiva",
    "orden":       36,
    "tipos":       ["var"],
    # Formato largo (factor_i, factor_j, valor) o ancho (1.ª columna de texto = filas, numéricas = matriz).
    "params": {"dataset": "", "campo_factor": "factor", "campo_factor_2": "factor_j",
               "campo_correlacion": "correlacion", "campo_fecha": "fecha", "tolerancia": 1e-6},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    if df is None or len(df) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    cols = list(df.columns)
    f1, f2, cv, cf = (params.get("campo_factor", "factor"), params.get("campo_factor_2", "factor_j"),
                      params.get("campo_correlacion", "correlacion"), params.get("campo_fecha", "fecha"))
    d = df
    if cf in cols:                                         # la fecha más reciente
        fechas = pd.to_datetime(d[cf].astype(str), errors="coerce")
        d = d[fechas == fechas.max()]
    if f1 in cols and f2 in cols and cv in cols:
        m = d.pivot_table(index=f1, columns=f2, values=cv, aggfunc="mean")
    else:
        texto = [c for c in d.columns if not pd.api.types.is_numeric_dtype(d[c]) and c != cf]
        nums = [c for c in d.columns if pd.api.types.is_numeric_dtype(d[c])]
        if not texto or len(nums) < 2:
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": "no se reconoce la matriz: usa formato largo (factor_i, factor_j, valor) o ancho"}
        m = d.set_index(texto[0])[nums]
    idx = sorted(set(map(str, m.index)) | set(map(str, m.columns)))
    m.index, m.columns = m.index.map(str), m.columns.map(str)
    m = m.reindex(index=idx, columns=idx)
    a = m.to_numpy(dtype=float)
    falt = int(np.isnan(a).sum())
    a = np.where(np.isnan(a), a.T, a)                      # completa con la simétrica si falta un lado
    tol = float(params.get("tolerancia", 1e-6))
    asim = float(np.nanmax(np.abs(a - a.T))) if a.size else 0.0
    diag = np.diag(a)
    es_corr = bool(np.nanmax(np.abs(a)) <= 1 + tol)
    diag_mal = int(np.sum(np.abs(diag - 1) > 1e-6)) if es_corr else int(np.sum(diag <= 0))
    if np.isnan(a).any():
        return {"pct": None, "decision": "No cumple",
                "diagnostico": f"matriz incompleta: {falt} celdas sin valor y sin su simétrica"}
    autov = np.linalg.eigvalsh((a + a.T) / 2)
    minimo = float(autov.min())
    psd = minimo >= -1e-8 * max(1.0, float(np.abs(autov).max()))
    cumple = psd and asim <= tol and diag_mal == 0
    return {"pct": 100.0 if cumple else 0.0, "decision": "Cumple" if cumple else "No cumple",
            "diagnostico": (f"{len(idx)} factores; autovalor mínimo {minimo:.3e} ({'semidefinida positiva' if psd else 'NO semidefinida positiva'}); "
                            f"asimetría máx. {asim:.2e}; diagonal fuera de {'1' if es_corr else '>0'}: {diag_mal}")}
