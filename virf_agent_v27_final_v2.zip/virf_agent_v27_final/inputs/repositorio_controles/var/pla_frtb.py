"""Control FRTB: prueba de atribución de P&L (PLA) entre HPL y RTPL por mesa."""

META = {
    "descripcion": "Prueba de atribución de P&L (PLA): el P&L teórico del modelo de riesgo (RTPL) se parece al hipotético (HPL) — Spearman > 0,80 y Kolmogorov–Smirnov < 0,09 (zona verde).",
    "dimension":   "Atribución de P&L (FRTB)",
    "evidencia":   "HPL y RTPL diarios por mesa, últimos 250 días.",
    "referencia":  "BCBS d457 (FRTB): PLA — verde Spearman > 0,80 y KS < 0,09; rojo Spearman < 0,70 o KS > 0,12",
    "orden":       40,
    "tipos":       ["es_frtb"],
    "params": {"dataset": "", "campo_pnl_hipotetico": "hpl", "campo_pnl_teorico": "rtpl", "campo_fecha": "fecha",
               "ventana": 250, "spearman_verde": 0.80, "ks_verde": 0.09, "spearman_rojo": 0.70, "ks_rojo": 0.12},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    ch, cr, cf = (params.get("campo_pnl_hipotetico", "hpl"), params.get("campo_pnl_teorico", "rtpl"),
                  params.get("campo_fecha", "fecha"))
    if ch not in cols or cr not in cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"faltan '{ch}' y/o '{cr}'"}
    d = df
    if cf in cols:
        d = d.assign(_f=pd.to_datetime(d[cf].astype(str), errors="coerce")).sort_values("_f")
    h = pd.to_numeric(d[ch], errors="coerce")
    r = pd.to_numeric(d[cr], errors="coerce")
    ok = h.notna() & r.notna()
    h, r = h[ok].tail(int(params.get("ventana", 250))), r[ok].tail(int(params.get("ventana", 250)))
    n = len(h)
    if n < 30:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"solo {n} pares HPL/RTPL"}
    rho = float(np.corrcoef(h.rank(), r.rank())[0, 1])
    a, b = np.sort(h.to_numpy()), np.sort(r.to_numpy())
    todos = np.concatenate([a, b])
    ks = float(np.max(np.abs(np.searchsorted(a, todos, side="right") / len(a)
                             - np.searchsorted(b, todos, side="right") / len(b))))
    if rho > float(params.get("spearman_verde", 0.80)) and ks < float(params.get("ks_verde", 0.09)):
        zona, dec = "VERDE", "Cumple"
    elif rho < float(params.get("spearman_rojo", 0.70)) or ks > float(params.get("ks_rojo", 0.12)):
        zona, dec = "ROJA", "No cumple"
    else:
        zona, dec = "ÁMBAR", "Observado"
    return {"pct": round(100 * max(0.0, rho), 2), "decision": dec,
            "diagnostico": f"{n} días: Spearman {rho:.3f}, KS {ks:.3f} → zona {zona} de la PLA"}
