"""Control VaR: la excepción compara el P&L de t con el VaR de t−1 (no del mismo día)."""

META = {
    "descripcion": "La marca de excepción del backtesting compara el P&L de cada día con el VaR del día ANTERIOR (rezago de un día), no con el del mismo día.",
    "dimension":   "Backtesting (VaR)",
    "evidencia":   "Serie diaria de P&L, VaR y la marca de excepción que se reporta; procedimiento de backtesting.",
    "referencia":  "Basilea — marco de backtesting (VaR del cierre de t contra el P&L de t+1)",
    "orden":       23,
    "tipos":       ["var", "es_frtb"],
    "params": {"dataset": "", "campo_fecha": "fecha", "campo_pnl": "pnl", "campo_var": "var_99",
               "campo_excepcion": "excepcion", "convencion": "perdida_positiva"},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cf, cp, cv, ce = (params.get("campo_fecha", "fecha"), params.get("campo_pnl", "pnl"),
                      params.get("campo_var", "var_99"), params.get("campo_excepcion", "excepcion"))
    if not all(c in cols for c in (cf, cp, cv)):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas de fecha/P&L/VaR ('{cf}', '{cp}', '{cv}')"}
    d = df[[c for c in (cf, cp, cv, ce) if c in cols]].copy()
    d[cf] = pd.to_datetime(d[cf].astype(str), errors="coerce")
    d = d.dropna(subset=[cf]).sort_values(cf)
    pnl = pd.to_numeric(d[cp], errors="coerce")
    var = pd.to_numeric(d[cv], errors="coerce").abs()
    # Misma convención que kupiec/severidad: «perdida_positiva» = la columna ya es la pérdida;
    # «pnl_negativo» = P&L con las pérdidas en negativo.
    perdida = -pnl if str(params.get("convencion", "perdida_positiva")).lower() == "pnl_negativo" else pnl
    exc0 = (perdida > var).astype(int)                 # mismo día (incorrecto)
    exc1 = (perdida > var.shift(1)).astype(int)        # VaR del día anterior (correcto)
    n = int(len(d) - 1)
    if n < 20:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "menos de 20 observaciones"}
    x0, x1 = int(exc0.iloc[1:].sum()), int(exc1.iloc[1:].sum())
    if ce in cols:
        rep = (pd.to_numeric(d[ce], errors="coerce").fillna(0) != 0).astype(int).iloc[1:]
        c0 = float((rep == exc0.iloc[1:]).mean())
        c1 = float((rep == exc1.iloc[1:]).mean())
        if c0 > c1 + 0.005:
            return {"pct": round(100 * c1, 2), "decision": "Observado",
                    "diagnostico": (f"la excepción reportada coincide más con el VaR del MISMO día ({c0:.1%}) que con "
                                    f"el del día anterior ({c1:.1%}): {x0} excepciones sin rezago vs {x1} con rezago")}
        return {"pct": round(100 * c1, 2), "decision": "Cumple",
                "diagnostico": (f"la excepción reportada coincide en un {c1:.1%} con P&L(t) vs VaR(t−1) "
                                f"({x1} excepciones con rezago; {x0} sin rezago)")}
    return {"pct": None, "decision": "Revisión manual",
            "diagnostico": (f"sin marca de excepción reportada: {x1} excepciones con rezago de un día y {x0} sin "
                            "rezago; confirma cuál usa el backtesting oficial")}
