"""Control NSFR: los factores ASF/RSF usados son los de la norma (0 %, 5 %, 10 %, 15 %, 50 %, 65 %, 85 %, 90 %, 95 %, 100 %)."""

META = {
    "descripcion": "Los factores ASF y RSF aplicados son valores de la norma: ASF 0, 50, 90, 95 o 100 %; RSF 0, 5, 10, 15, 50, 65, 85 o 100 %.",
    "dimension":   "Liquidez (NSFR)",
    "evidencia":   "Tabla de rubros con su saldo y factor ASF/RSF aplicado.",
    "referencia":  "BCBS 295 (NSFR, 2014): factores de fondeo estable disponible y requerido",
    "orden":       31,
    "tipos":       ["nsfr"],
    "params": {"dataset": "", "campo_factor_asf": "factor_asf", "campo_factor_rsf": "factor_rsf",
               "asf_validos": [0, 0.5, 0.9, 0.95, 1.0], "rsf_validos": [0, 0.05, 0.10, 0.15, 0.5, 0.65, 0.85, 1.0]},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    pares = [(params.get("campo_factor_asf", "factor_asf"), params.get("asf_validos") or []),
             (params.get("campo_factor_rsf", "factor_rsf"), params.get("rsf_validos") or [])]
    pares = [(c, v) for c, v in pares if c in cols]
    if not pares:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "no hay columnas de factores ASF ni RSF"}
    malos, total, detalle = 0, 0, []
    for c, validos in pares:
        s = pd.to_numeric(df[c], errors="coerce").dropna()
        s = s / (100.0 if s.quantile(0.75) > 1 else 1.0)
        v = np.array([float(x) for x in validos])
        fuera = s[~s.apply(lambda x: bool(np.any(np.abs(v - x) <= 1e-6)))]
        malos += len(fuera)
        total += len(s)
        if len(fuera):
            detalle.append(f"{c}: {len(fuera)} factor(es) no estándar (p. ej. {', '.join(f'{x:.0%}' for x in fuera.unique()[:4])})")
    pct = round(100.0 * (1 - malos / total), 2) if total else None
    return {"pct": pct, "decision": "Cumple" if not malos else "No cumple",
            "diagnostico": "; ".join(detalle) if detalle else f"{total} factores, todos estándar"}
