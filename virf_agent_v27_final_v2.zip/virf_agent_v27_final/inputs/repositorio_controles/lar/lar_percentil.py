"""Control LaR: Liquidity at Risk = percentil de las salidas netas acumuladas en el horizonte."""

META = {
    "descripcion": "El LaR reportado es el percentil de las salidas netas acumuladas en el horizonte (suma móvil de los flujos netos), con la ventana y el nivel del manual.",
    "dimension":   "Liquidez (LaR)",
    "evidencia":   "Serie diaria de flujos netos (o entradas y salidas) y el LaR reportado.",
    "referencia":  "BCBS — principios de gestión del riesgo de liquidez (2008)",
    "orden":       12,
    "tipos":       ["lar"],
    "params": {"dataset": "", "campo_fecha": "fecha", "campo_flujo_neto": "flujo_neto", "campo_entradas": "entradas",
               "campo_salidas": "salidas", "horizonte": 30, "nivel": 0.99, "campo_lar_valor": "lar",
               "tolerancia_pct": 5.0},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cf, cn = params.get("campo_fecha", "fecha"), params.get("campo_flujo_neto", "flujo_neto")
    ce, cs = params.get("campo_entradas", "entradas"), params.get("campo_salidas", "salidas")
    if cf not in cols or not (cn in cols or (ce in cols and cs in cols)):
        return {"pct": None, "decision": "No evaluable", "diagnostico": "faltan la fecha y el flujo neto (o entradas y salidas)"}
    neto = (pd.to_numeric(df[cn], errors="coerce") if cn in cols
            else pd.to_numeric(df[ce], errors="coerce") - pd.to_numeric(df[cs], errors="coerce"))
    d = pd.DataFrame({"f": pd.to_datetime(df[cf].astype(str), errors="coerce"), "n": neto}).dropna()
    serie = d.groupby("f")["n"].sum().sort_index()
    h = int(params.get("horizonte", 30))
    if len(serie) < h + 30:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"solo {len(serie)} días de historia"}
    acum = serie.rolling(h).sum().dropna()
    nivel = float(params.get("nivel", 0.99))
    lar = float(max(0.0, -np.quantile(acum, 1 - nivel)))
    cl = params.get("campo_lar_valor", "lar")
    if cl not in cols:
        return {"pct": None, "decision": "Revisión manual",
                "diagnostico": f"LaR recalculado a {h} días al {nivel:.0%}: {lar:,.0f} ({len(acum)} ventanas)"}
    rep = float(pd.to_numeric(df[cl], errors="coerce").dropna().abs().iloc[-1])
    dif = abs(rep - lar) / lar * 100 if lar else (0.0 if rep == 0 else 100.0)
    ok = dif <= float(params.get("tolerancia_pct", 5.0))
    return {"pct": round(max(0.0, 100 - dif), 2), "decision": "Cumple" if ok else "Observado",
            "diagnostico": f"LaR reportado {rep:,.0f} vs recalculado {lar:,.0f} (diferencia {dif:.1f} %; {len(acum)} ventanas)"}
