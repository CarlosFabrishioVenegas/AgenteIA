"""Control LCR: el ratio reportado aplica el tope de entradas (75 % de las salidas)."""

META = {
    "descripcion": "El LCR reportado es HQLA ÷ (salidas − mín(entradas; 75 % de las salidas)): las entradas no pueden cubrir más del 75 % de las salidas.",
    "dimension":   "Liquidez (LCR)",
    "evidencia":   "HQLA, salidas y entradas ponderadas a 30 días por fecha, y el ratio reportado.",
    "referencia":  "BCBS 238 — tope de entradas del 75 % en el denominador del LCR",
    "orden":       22,
    "tipos":       ["lcr"],
    "params": {"dataset": "", "campo_hqla": "hqla", "campo_salidas": "salidas", "campo_entradas": "entradas",
               "campo_lcr": "lcr", "tope_entradas": 0.75, "tolerancia_pp": 0.5},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    ch, cs, ce, cl = (params.get("campo_hqla", "hqla"), params.get("campo_salidas", "salidas"),
                      params.get("campo_entradas", "entradas"), params.get("campo_lcr", "lcr"))
    if not all(c in cols for c in (ch, cs, ce)):
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"faltan '{ch}', '{cs}' o '{ce}'"}
    hq, sa, en = (pd.to_numeric(df[c], errors="coerce") for c in (ch, cs, ce))
    tope = float(params.get("tope_entradas", 0.75))
    neto = sa - np.minimum(en, tope * sa)
    calc = hq / neto.where(neto > 0)
    topados = int((en > tope * sa).sum())
    if cl not in cols:
        return {"pct": None, "decision": "Revisión manual",
                "diagnostico": (f"LCR recalculado: mínimo {calc.min():.0%}, medio {calc.mean():.0%}; "
                                f"{topados} fecha(s) donde aplica el tope del {tope:.0%}")}
    rep = pd.to_numeric(df[cl], errors="coerce")
    rep = rep / (100.0 if rep.dropna().median() > 20 else 1.0)
    ok = rep.notna() & calc.notna()
    if int(ok.sum()) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin fechas comparables"}
    tol = float(params.get("tolerancia_pp", 0.5)) / 100
    dif = (rep[ok] - calc[ok]).abs()
    sin_tope = hq[ok] / (sa[ok] - en[ok]).where((sa[ok] - en[ok]) > 0)
    malos = int((dif > tol).sum())
    explica = int(((rep[ok] - sin_tope).abs() <= tol)[(dif > tol)].sum())
    pct = round(100.0 * (1 - malos / int(ok.sum())), 2)
    return {"pct": pct, "decision": "Cumple" if not malos else "No cumple",
            "diagnostico": (f"{int(ok.sum())} fechas; {malos} con diferencia > {tol:.1%} entre el LCR reportado y el "
                            f"recalculado" + (f" ({explica} se explican por NO aplicar el tope del {tope:.0%})" if explica else "")
                            + f"; el tope aplica en {topados} fecha(s)")}
