"""Control de estrés de liquidez: la tasa de salida en estrés cubre las caídas históricas de saldo en el horizonte (percentil por segmento)."""

META = {
    "descripcion": "La tasa de salida en estrés de cada segmento es al menos el percentil histórico de las caídas de saldo en el horizonte (p. ej. 30 días al 99 %): r_t = 1 − S(t+h) ÷ S(t).",
    "dimension":   "Liquidez (estrés)",
    "evidencia":   "Serie histórica de saldos por segmento (diaria o mensual) y tabla de tasas de salida en estrés del modelo.",
    "referencia":  "BCBS — principios de gestión del riesgo de liquidez (2008); BCBS 238 (tasas de salida de referencia)",
    "orden":       15,
    "tipos":       ["stress_liquidez"],
    "params": {"dataset": "", "campo_fecha": "fecha", "campo_segmento": "segmento", "campo_saldo": "saldo",
               "horizonte_dias": 30, "percentil": 0.99, "dataset_tasas": "", "campo_segmento_tasas": "segmento",
               "campo_tasa_salida": "tasa_salida"},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cf, cg, cs = (params.get("campo_fecha", "fecha"), params.get("campo_segmento", "segmento"),
                  params.get("campo_saldo", "saldo"))
    if cf not in cols or cs not in cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"faltan '{cf}' y/o '{cs}'"}
    h = int(params.get("horizonte_dias", 30))
    q = float(params.get("percentil", 0.99))
    d = pd.DataFrame({"f": pd.to_datetime(df[cf].astype(str), errors="coerce"),
                      "g": df[cg].astype(str) if cg in cols else "TOTAL",
                      "s": pd.to_numeric(df[cs], errors="coerce")}).dropna()
    d = d.groupby(["g", "f"], as_index=False)["s"].sum().sort_values(["g", "f"])
    hist = {}
    for g, x in d.groupby("g"):
        f = x["f"].to_numpy()
        s = x["s"].to_numpy(dtype=float)
        j = np.searchsorted(f, f + np.timedelta64(h, "D"), side="left")
        ok = (j < len(f)) & (s > 0)
        if ok.sum() < 20:
            continue
        r = 1 - s[j[ok]] / s[ok]                          # positivo = salida
        hist[g] = (float(np.quantile(r, q)), float(r.max()), int(ok.sum()))
    if not hist:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"ningún segmento tiene 20 ventanas de {h} días"}
    texto = "; ".join(f"{g}: p{q * 100:g} {v[0]:.1%} (máx. {v[1]:.1%}, {v[2]} ventanas)" for g, v in list(hist.items())[:6])
    tasas = (datasets or {}).get(params.get("dataset_tasas") or "")
    if tasas is None:
        return {"pct": None, "decision": "Revisión manual",
                "diagnostico": (f"caída histórica de saldo a {h} días — {texto}; pon `dataset_tasas` para contrastarla con "
                                "las tasas del modelo")}
    ct, cts = params.get("campo_tasa_salida", "tasa_salida"), params.get("campo_segmento_tasas", "segmento")
    if ct not in tasas.columns:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"la tabla de tasas no trae '{ct}'"}
    t = pd.to_numeric(tasas[ct], errors="coerce")
    t = t / (100.0 if t.dropna().quantile(0.75) > 1 else 1.0)
    modelo = dict(zip(tasas[cts].astype(str), t)) if cts in tasas.columns else {"TOTAL": float(t.max())}
    bajo, sin_tasa = [], []
    for g, (qq, _mx, _n) in hist.items():
        m = modelo.get(g)
        if m is None or pd.isna(m):
            sin_tasa.append(g)
        elif m + 1e-9 < qq:
            bajo.append(f"{g}: modelo {m:.1%} < histórico {qq:.1%}")
    ev = len(hist) - len(sin_tasa)
    pct = round(100.0 * (ev - len(bajo)) / ev, 2) if ev else None
    dec = "No evaluable" if not ev else ("Cumple" if not bajo else "No cumple")
    return {"pct": pct, "decision": dec,
            "diagnostico": ((f"{len(bajo)} segmento(s) con tasa del modelo por debajo del histórico: " + "; ".join(bajo[:4]))
                            if bajo else f"las tasas del modelo cubren el p{q * 100:g} histórico a {h} días")
            + (f"; sin tasa en el modelo: {', '.join(sin_tasa[:4])}" if sin_tasa else "")}
