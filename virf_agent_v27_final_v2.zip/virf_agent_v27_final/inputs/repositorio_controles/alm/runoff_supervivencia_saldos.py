"""Control de run-off: la curva de supervivencia del saldo se replica con la experiencia histórica (cosechas)."""

META = {
    "descripcion": "La curva de supervivencia del modelo se reproduce con la historia: por cosechas, S(k) = Π (Σ saldo(j) ÷ Σ saldo(j−1)) sobre las cosechas observadas en ambos meses, o el run-off del saldo existente en cada corte (`curva_de`, según el manual); si solo hay saldo total, un ajuste exponencial; la diferencia con la curva del modelo en cada plazo no supera la tolerancia.",
    "dimension":   "Conductual (run-off)",
    "evidencia":   "Saldos por cosecha y mes (o la serie del saldo del producto) y la curva del modelo por plazo.",
    "referencia":  "Método de cosechas (link ratios) para curvas de saldo; Kaplan y Meier (1958)",
    "orden":       13,
    "tipos":       ["runoff", "nmd"],
    # curva_de: "cosecha" (supervivencia desde el origen) o "saldo_existente" (stock de cada corte, sin negocio nuevo).
    "params": {"dataset": "", "curva_de": "cosecha", "campo_segmento": "segmento", "campo_cosecha": "cosecha",
               "campo_edad": "edad",
               "campo_fecha": "fecha", "campo_saldo": "saldo", "dataset_curva": "", "campo_plazo_meses": "plazo_meses",
               "campo_supervivencia": "supervivencia", "plazos": [1, 3, 6, 12, 24, 36, 60], "tolerancia": 0.05},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cg, cc, ce, cf, cs = (params.get("campo_segmento", "segmento"), params.get("campo_cosecha", "cosecha"),
                          params.get("campo_edad", "edad"), params.get("campo_fecha", "fecha"),
                          params.get("campo_saldo", "saldo"))
    if cs not in cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"falta el saldo '{cs}'"}
    curva_de = str(params.get("curva_de") or "cosecha").strip().lower()
    if curva_de not in ("cosecha", "saldo_existente"):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"curva_de «{curva_de}» no válida (cosecha o saldo_existente)"}

    def meses(a, b):                                  # meses entre la cosecha (b) y la observación (a)
        fa = pd.to_datetime(a.astype(str), errors="coerce")
        fb = pd.to_datetime(b.astype(str), errors="coerce")
        return (fa.dt.year - fb.dt.year) * 12 + (fa.dt.month - fb.dt.month)

    d = pd.DataFrame({"g": df[cg].astype(str) if cg in cols else "TOTAL",
                      "s": pd.to_numeric(df[cs], errors="coerce")})
    metodo = ""
    if curva_de == "saldo_existente":
        if cc not in cols or cf not in cols:
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": "el run-off del saldo existente necesita la cosecha y la fecha de observación"}
        fa = pd.to_datetime(df[cf].astype(str), errors="coerce")
        d["c"], d["m"] = df[cc].astype(str), fa.dt.year * 12 + fa.dt.month
        metodo = "saldo existente"
    elif cc in cols and (ce in cols or cf in cols):
        d["c"] = df[cc].astype(str)
        d["k"] = pd.to_numeric(df[ce], errors="coerce") if ce in cols else meses(df[cf], df[cc])
        metodo = "cosechas"
    elif cf in cols:
        d["f"] = pd.to_datetime(df[cf].astype(str), errors="coerce")
        metodo = "exponencial"
    else:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": "faltan la cosecha y su antigüedad (o al menos la fecha) para construir la curva"}
    d = d.dropna()
    curvas = {}
    for g, x in d.groupby("g"):
        if metodo == "saldo existente":
            # Stock de cada corte (cosechas ya vivas): cuánto de su saldo queda m meses después.
            p = x.pivot_table(index="m", columns="c", values="s", aggfunc="sum").sort_index()
            p = p.reindex(range(int(p.index.min()), int(p.index.max()) + 1))
            a = p.to_numpy(dtype=float)
            vivo = np.nan_to_num(a) > 0
            curva = {0.0: 1.0}
            for k in range(1, min(len(a), 121)):
                den = float(np.sum(np.where(vivo[:-k], np.nan_to_num(a[:-k]), 0.0)))
                if int(vivo[:-k].any(axis=1).sum()) < 3 or den <= 0:
                    break
                curva[float(k)] = float(np.sum(np.where(vivo[:-k], np.nan_to_num(a[k:]), 0.0))) / den
            curvas[g] = curva
        elif metodo == "cosechas":
            p = x.pivot_table(index="c", columns="k", values="s", aggfunc="sum").sort_index(axis=1)
            ks = [k for k in p.columns if k >= 0]
            s, curva = 1.0, {0.0: 1.0}
            for j0, j1 in zip(ks, ks[1:]):
                ambos = p[[j0, j1]].dropna()
                ambos = ambos[ambos[j0] > 0]
                if len(ambos) < 2:
                    break
                s *= float(ambos[j1].sum() / ambos[j0].sum())
                curva[float(j1)] = s
            curvas[g] = curva
        else:
            serie = x.groupby(x["f"].dt.to_period("M"))["s"].sum().sort_index()
            if len(serie) < 6 or (serie <= 0).any():
                continue
            t = np.arange(len(serie), dtype=float)
            lam = -np.polyfit(t, np.log(serie.to_numpy()), 1)[0]
            curvas[g] = {float(k): float(np.exp(-lam * k)) for k in range(0, 121)}
    if not curvas:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "no hay historia suficiente para la curva"}
    plazos = [float(p) for p in (params.get("plazos") or [1, 3, 6, 12, 24, 36, 60])]

    def en(curva, m):
        ks = sorted(curva)
        return float(np.interp(m, ks, [curva[k] for k in ks])) if ks and m <= ks[-1] else None

    texto = "; ".join(f"{g}: " + ", ".join(f"S({m:g})={en(c, m):.0%}" for m in plazos if en(c, m) is not None)
                      for g, c in list(curvas.items())[:4])
    sube = [g for g, c in curvas.items() if max(c.values()) > 1.005]
    aviso = (f" · el saldo de las cosechas CRECE en {', '.join(sube[:3])} (aportes): la curva debería medir el "
             "saldo existente sin nuevos aportes" if sube else "")
    crv = (datasets or {}).get(params.get("dataset_curva") or "")
    if crv is None:
        return {"pct": None, "decision": "Revisión manual",
                "diagnostico": (f"curva replicada ({metodo}): {texto}{aviso}. Pon `dataset_curva` para contrastarla "
                                "con la del modelo")}
    cp, csu = params.get("campo_plazo_meses", "plazo_meses"), params.get("campo_supervivencia", "supervivencia")
    if cp not in crv.columns or csu not in crv.columns:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"la curva del modelo no trae '{cp}' / '{csu}'"}
    m = pd.DataFrame({"g": crv[cg].astype(str) if cg in crv.columns else "TOTAL",
                      "t": pd.to_numeric(crv[cp], errors="coerce"), "S": pd.to_numeric(crv[csu], errors="coerce")}).dropna()
    m["S"] = m["S"] / (100.0 if m["S"].quantile(0.75) > 1 else 1.0)
    tol = float(params.get("tolerancia", 0.05))
    difs, comparados = [], 0
    for g, x in m.groupby("g"):
        rep = curvas.get(g) or (curvas.get("TOTAL") if len(curvas) == 1 else None)
        if rep is None:
            continue
        x = x.sort_values("t")
        for p in plazos:
            r = en(rep, p)
            if r is None or p > x["t"].max():
                continue
            comparados += 1
            mo = float(np.interp(p, x["t"], x["S"]))
            if abs(mo - r) > tol:
                difs.append(f"{g} {p:g}m: modelo {mo:.0%} vs histórico {r:.0%}")
    if not comparados:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "los segmentos de la curva no tienen historia"}
    return {"pct": round(100.0 * (comparados - len(difs)) / comparados, 2),
            "decision": "Cumple" if not difs else "Observado",
            "diagnostico": ((f"{len(difs)} de {comparados} plazos fuera de ±{tol:.0%}: " + "; ".join(difs[:5]))
                            if difs else f"la curva del modelo coincide con la histórica en {comparados} plazos ({metodo})")
            + aviso}
