"""Control conductual: curva de supervivencia Kaplan–Meier de las cuentas (con censura) frente a la del modelo."""

META = {
    "descripcion": "La supervivencia observada de las cuentas (Kaplan–Meier, tratando como censuradas las que siguen abiertas) es coherente con la curva del modelo a 12, 24 y 60 meses, segmento a segmento si ambos lo traen (en un run-off de saldos, la de cuentas es un contraste: no tiene por qué coincidir).",
    "dimension":   "Conductual (supervivencia)",
    "evidencia":   "Cuentas con fecha de apertura y de cierre (vacía si siguen abiertas) y la curva del modelo.",
    "referencia":  "Kaplan y Meier (1958); BCBS 368 (supuestos conductuales)",
    "orden":       45,
    "tipos":       ["supervivencia", "nmd", "runoff"],
    "params": {"dataset": "", "campo_fecha_inicio": "fecha_apertura", "campo_fecha_cierre": "fecha_cierre",
               "campo_segmento": "segmento", "fecha_corte": "", "dataset_curva": "", "campo_plazo_meses": "plazo_meses",
               "campo_supervivencia": "supervivencia", "plazos": [12, 24, 60], "tolerancia": 0.05},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    ci_, cc = params.get("campo_fecha_inicio", "fecha_apertura"), params.get("campo_fecha_cierre", "fecha_cierre")
    if ci_ not in cols or cc not in cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"faltan '{ci_}' y/o '{cc}'"}
    cg = params.get("campo_segmento", "segmento")
    ini = pd.to_datetime(df[ci_].astype(str).where(df[ci_].notna()), errors="coerce")
    cie = pd.to_datetime(df[cc].astype(str).where(df[cc].notna()), errors="coerce")
    corte = pd.Timestamp(params["fecha_corte"]) if params.get("fecha_corte") else max(ini.max(), cie.max())
    ok = ini.notna() & (ini <= corte)
    evento = cie.notna() & (cie <= corte)
    fin = cie.where(evento, corte)
    dur = ((fin - ini).dt.days / 30.4375)[ok]
    ev = evento[ok].astype(int)
    if (dur < 0).any():
        return {"pct": None, "decision": "No cumple",
                "diagnostico": f"{int((dur < 0).sum())} cuentas con cierre anterior a la apertura"}
    seg = (df.loc[ok, cg].astype(str) if cg in cols else pd.Series("TOTAL", index=dur.index))

    def km(t, e):
        d = pd.DataFrame({"t": t.round(6), "e": e}).sort_values("t")
        s, curva = 1.0, []
        for x in np.sort(d.loc[d["e"] == 1, "t"].unique()):
            en_riesgo = int((d["t"] >= x).sum())
            if en_riesgo:
                s *= 1 - int(((d["t"] == x) & (d["e"] == 1)).sum()) / en_riesgo
            curva.append((x, s))
        return curva

    def s_en(curva, m):
        v = [x for t, x in curva if t <= m]
        return v[-1] if v else 1.0

    plazos = [float(x) for x in (params.get("plazos") or [12, 24, 60])]
    obs = {g: {m: s_en(km(dur[seg == g], ev[seg == g]), m) for m in plazos} for g in sorted(seg.unique())}
    texto = "; ".join(f"{g}: " + ", ".join(f"S({m:g}m) = {v:.1%}" for m, v in o.items()) for g, o in list(obs.items())[:4])
    n0, cierres = int(len(dur)), int(ev.sum())
    curva_ds = (datasets or {}).get(params.get("dataset_curva") or "")
    if curva_ds is None:
        return {"pct": None, "decision": "Revisión manual",
                "diagnostico": (f"Kaplan–Meier sobre {n0} cuentas ({cierres} cierres, {n0 - cierres} censuradas): "
                                f"{texto}; pon `dataset_curva` para contrastar con el modelo")}
    cp, cs = params.get("campo_plazo_meses", "plazo_meses"), params.get("campo_supervivencia", "supervivencia")
    if cp not in curva_ds.columns or cs not in curva_ds.columns:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"la curva no trae '{cp}' / '{cs}'"}
    cm = pd.DataFrame({"g": curva_ds[cg].astype(str) if cg in curva_ds.columns else "TOTAL",
                       "t": pd.to_numeric(curva_ds[cp], errors="coerce"),
                       "S": pd.to_numeric(curva_ds[cs], errors="coerce")}).dropna()
    cm["S"] = cm["S"] / (100.0 if cm["S"].quantile(0.75) > 1 else 1.0)
    tol = float(params.get("tolerancia", 0.05))
    malos, comparados = [], 0
    for g, o in obs.items():
        x = cm[cm["g"] == g] if g in set(cm["g"]) else (cm if cm["g"].nunique() == 1 else None)
        if x is None or x.empty:
            continue
        x = x.groupby("t")["S"].mean().sort_index()
        for m, v in o.items():
            comparados += 1
            dif = abs(v - float(np.interp(m, x.index, x.values)))
            if dif > tol:
                malos.append(f"{g} {m:g}m: {dif:.1%}")
    if not comparados:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"{texto}; los segmentos de las cuentas no están en la curva del modelo"}
    return {"pct": round(100.0 * (comparados - len(malos)) / comparados, 2),
            "decision": "Cumple" if not malos else "Observado",
            "diagnostico": f"{texto}; diferencias con el modelo fuera de ±{tol:.0%}: {', '.join(malos[:6]) or 'ninguna'}"}
