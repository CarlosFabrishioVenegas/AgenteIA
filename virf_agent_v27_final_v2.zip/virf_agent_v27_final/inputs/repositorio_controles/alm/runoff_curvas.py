"""Control de run-off: la curva del modelo es coherente (S decreciente, R = 1 − S, desgaste ≥ 0 que suma el acumulado)."""

META = {
    "descripcion": "La curva de run-off del modelo es coherente: la supervivencia S(t) empieza en 1 y nunca sube, el run-off acumulado es R(t) = 1 − S(t), el desgaste incremental d(t) = S(t−1) − S(t) no es negativo y suma el acumulado; se informa el componente estable (S al último plazo) y el plazo económico (∫ S(t) dt hasta el último plazo).",
    "dimension":   "Conductual (run-off)",
    "evidencia":   "Curva del modelo por segmento y plazo: supervivencia, run-off acumulado y/o desgaste incremental.",
    "referencia":  "Modelos de supervivencia de saldos (vencimiento conductual); BCBS 368 (supuestos de NMD)",
    "orden":       12,
    "tipos":       ["runoff", "supervivencia", "nmd"],
    "params": {"dataset": "", "campo_segmento": "segmento", "campo_plazo_meses": "plazo_meses",
               "campo_supervivencia": "supervivencia", "campo_runoff_acumulado": "runoff_acumulado",
               "campo_runoff_incremental": "runoff_incremental", "tolerancia": 0.005},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cp = params.get("campo_plazo_meses", "plazo_meses")
    cs, cr, cd = (params.get("campo_supervivencia", "supervivencia"), params.get("campo_runoff_acumulado", "runoff_acumulado"),
                  params.get("campo_runoff_incremental", "runoff_incremental"))
    if cp not in cols or not any(c in cols for c in (cs, cr, cd)):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta el plazo '{cp}' o alguna de '{cs}', '{cr}', '{cd}'"}
    cg = params.get("campo_segmento", "segmento")
    tol = float(params.get("tolerancia", 0.005))

    # Una sola escala para S, R y d (0–1 o %): la de S o R; el desgaste suelto se juzga por su suma.
    num = {k: pd.to_numeric(df[c], errors="coerce") for c, k in ((cs, "S"), (cr, "R"), (cd, "d")) if c in cols}
    if "S" in num or "R" in num:
        ref = num.get("S", num.get("R")).dropna()
        f = 100.0 if (len(ref) and ref.quantile(0.75) > 1) else 1.0
    else:
        dd = num["d"].dropna()
        f = 100.0 if (len(dd) and (dd.max() > 1 or dd.groupby(df[cg] if cg in cols else 0).sum().max() > 1.5)) else 1.0
    d = pd.DataFrame({"g": df[cg].astype(str) if cg in cols else "TOTAL",
                      "t": pd.to_numeric(df[cp], errors="coerce")})
    for k, s in num.items():
        d[k] = (s / f).values
    d = d.dropna(subset=["t"]).sort_values(["g", "t"])
    fallas, resumen, n_seg = [], [], 0
    for g, x in d.groupby("g"):
        n_seg += 1
        if "S" not in x and "R" in x:
            x = x.assign(S=1 - x["R"])
        if "S" not in x and "d" in x:
            x = x.assign(S=1 - x["d"].cumsum())
        s = x["S"].to_numpy(dtype=float)
        t = x["t"].to_numpy(dtype=float)
        if np.nanmax(s) > 1 + tol or np.nanmin(s) < -tol:
            fallas.append(f"{g}: S fuera de [0, 1]")
        if (np.diff(s) > tol).any():
            k = int(np.argmax(np.diff(s) > tol))
            fallas.append(f"{g}: S sube entre {t[k]:g} y {t[k + 1]:g} meses")
        if "R" in x and "S" in x and (np.abs(x["R"].to_numpy() - (1 - s)) > tol).any():
            fallas.append(f"{g}: R ≠ 1 − S")
        if "d" in x:
            dd = x["d"].to_numpy(dtype=float)
            if (dd < -tol).any():
                fallas.append(f"{g}: desgaste incremental negativo")
            s_prev = np.concatenate([[1.0], s[:-1]]) if t[0] > 0 else np.concatenate([[s[0]], s[:-1]])
            if (np.abs(dd - (s_prev - s)) > tol).any():
                fallas.append(f"{g}: d(t) ≠ S(t−1) − S(t)")
        tt, ss = (np.concatenate([[0.0], t]), np.concatenate([[1.0], s])) if t[0] > 0 else (t, s)
        vida = float(np.nansum((ss[1:] + ss[:-1]) / 2.0 * np.diff(tt))) / 12.0      # ∫ S(t) dt (trapecios)
        resumen.append(f"{g}: estable {s[-1]:.0%} a {t[-1]:g} m, plazo económico ≈ {vida:.1f} años")
    if not n_seg:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "curva vacía"}
    malos = len({f.split(':')[0] for f in fallas})
    return {"pct": round(100.0 * (n_seg - malos) / n_seg, 2), "decision": "Cumple" if not fallas else "No cumple",
            "diagnostico": ("; ".join(fallas[:6]) + " · " if fallas else "") + "; ".join(resumen[:4])}
