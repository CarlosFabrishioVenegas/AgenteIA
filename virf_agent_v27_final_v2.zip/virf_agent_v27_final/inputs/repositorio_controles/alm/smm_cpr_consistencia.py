"""Control conductual (prepago): el SMM y el CPR reportados salen de los saldos (SMM = prepago ÷ (saldo inicial − amortización); CPR = 1 − (1 − SMM)^12)."""

META = {
    "descripcion": "El SMM/CPR reportado es el que sale de los saldos: SMM = prepago ÷ (saldo inicial − amortización programada) y CPR = 1 − (1 − SMM)^12.",
    "dimension":   "Conductual (prepago)",
    "evidencia":   "Serie mensual por segmento con saldo inicial, amortización programada, prepago y la tasa reportada.",
    "referencia":  "Convención de mercado SMM/CPR; BCBS 368 (supuestos de prepago)",
    "orden":       12,
    "tipos":       ["prepago"],
    "params": {"dataset": "", "campo_saldo_inicial": "saldo_inicial", "campo_amortizacion": "amortizacion",
               "campo_prepago": "prepago", "campo_cpr": "cpr", "tolerancia_pp": 0.10, "minimo_pct_filas": 98.0},
}


def control(df, datasets, params):
    import numpy as np
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cs, ca, cp, cc = (params.get("campo_saldo_inicial", "saldo_inicial"), params.get("campo_amortizacion", "amortizacion"),
                      params.get("campo_prepago", "prepago"), params.get("campo_cpr", "cpr"))
    if cs not in cols or cp not in cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"faltan '{cs}' y/o '{cp}'"}
    s0 = pd.to_numeric(df[cs], errors="coerce")
    am = pd.to_numeric(df[ca], errors="coerce").fillna(0.0) if ca in cols else 0.0
    pp = pd.to_numeric(df[cp], errors="coerce")
    base = (s0 - am).where(lambda x: x > 0)
    smm = pp / base
    fuera = int(((smm < 0) | (smm > 1)).sum())
    cpr = 1 - (1 - smm.clip(0, 1)) ** 12
    if cc not in cols:
        ok = smm.notna()
        return {"pct": round(100.0 * (1 - fuera / max(int(ok.sum()), 1)), 2),
                "decision": "Revisión manual" if not fuera else "No cumple",
                "diagnostico": (f"sin tasa reportada: SMM medio {smm.mean():.4%}, CPR medio {cpr.mean():.2%}; "
                                f"{fuera} filas con SMM fuera de [0, 1]")}
    rep = pd.to_numeric(df[cc], errors="coerce")
    escala = 100.0 if rep.dropna().quantile(0.75) > 1 else 1.0
    rep = rep / escala
    # La tasa reportada puede ser el SMM mensual o el CPR anual: se compara con el que mejor encaja.
    ok = rep.notna() & smm.notna()
    if int(ok.sum()) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin filas con saldo y tasa"}
    d_cpr = (rep[ok] - cpr[ok]).abs()
    d_smm = (rep[ok] - smm[ok]).abs()
    es_cpr = float(d_cpr.median()) <= float(d_smm.median())
    dif = d_cpr if es_cpr else d_smm
    tol = float(params.get("tolerancia_pp", 0.10)) / 100
    dentro = float((dif <= tol).mean())
    pct = round(100.0 * dentro, 2)
    cumple = pct >= float(params.get("minimo_pct_filas", 98.0)) and not fuera
    return {"pct": pct, "decision": "Cumple" if cumple else "No cumple",
            "diagnostico": (f"la tasa reportada se comporta como {'CPR anual' if es_cpr else 'SMM mensual'}; "
                            f"{pct:.1f} % de filas dentro de ±{tol:.2%} (dif. máx. {float(dif.max()):.4%}); "
                            f"{fuera} filas con SMM fuera de [0, 1]")}
