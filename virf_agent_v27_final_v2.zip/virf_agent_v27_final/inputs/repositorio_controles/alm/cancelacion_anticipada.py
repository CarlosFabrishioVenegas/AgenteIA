"""Control conductual: tasa mensual de cancelación anticipada de depósitos a plazo (y contraste con la del modelo)."""

META = {
    "descripcion": "La tasa mensual de cancelación anticipada observada (saldo cancelado antes del vencimiento ÷ saldo vivo) es coherente con la que usa el modelo.",
    "dimension":   "Conductual (depósitos a plazo)",
    "evidencia":   "Depósitos con fechas de inicio, vencimiento y cierre, y saldo; tasa de cancelación del modelo.",
    "referencia":  "BCBS 368 (riesgo de redención anticipada de depósitos a plazo)",
    "orden":       40,
    "tipos":       ["cancelacion_dpf"],
    "params": {"dataset": "", "campo_fecha_inicio": "fecha_inicio", "campo_fecha_vencimiento": "fecha_vencimiento",
               "campo_fecha_cierre": "fecha_cierre", "campo_saldo": "saldo", "tasa_modelo": None,
               "tolerancia_pp": 0.5},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    ci_, cv, cc, cs = (params.get("campo_fecha_inicio", "fecha_inicio"),
                       params.get("campo_fecha_vencimiento", "fecha_vencimiento"),
                       params.get("campo_fecha_cierre", "fecha_cierre"), params.get("campo_saldo", "saldo"))
    if not all(c in cols for c in (ci_, cv, cc, cs)):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas de fechas de inicio/vencimiento/cierre o saldo"}

    def f(c):
        return pd.to_datetime(df[c].astype(str).where(df[c].notna()), errors="coerce")

    ini, ven, cie = f(ci_), f(cv), f(cc)
    saldo = pd.to_numeric(df[cs], errors="coerce").fillna(0.0)
    if ini.notna().sum() == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin fechas de inicio legibles"}
    meses = pd.period_range(ini.min(), (cie.max() if cie.notna().any() else ven.max()), freq="M")
    tasas = []
    for m in meses:
        inicio_m, fin_m = m.start_time, m.end_time
        vivo = (ini < inicio_m) & ((cie.isna()) | (cie >= inicio_m)) & (ven >= inicio_m)
        base = float(saldo[vivo].sum())
        if base <= 0:
            continue
        cancel = vivo & cie.notna() & (cie >= inicio_m) & (cie <= fin_m) & (cie < ven)
        tasas.append(float(saldo[cancel].sum()) / base)
    if not tasas:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "no hay meses con saldo vivo"}
    s = pd.Series(tasas)
    media, p95 = float(s.mean()), float(s.quantile(0.95))
    modelo = params.get("tasa_modelo")
    if modelo in (None, ""):
        return {"pct": None, "decision": "Revisión manual",
                "diagnostico": (f"{len(s)} meses: cancelación anticipada media {media:.2%} mensual (p95 {p95:.2%}); "
                                "pon `tasa_modelo` para contrastarla con la del modelo")}
    modelo = float(modelo) / (100.0 if float(modelo) > 1 else 1.0)
    tol = float(params.get("tolerancia_pp", 0.5)) / 100
    cumple = abs(media - modelo) <= tol
    return {"pct": round(100.0 * float((abs(s - modelo) <= tol).mean()), 2),
            "decision": "Cumple" if cumple else "Observado",
            "diagnostico": (f"observada media {media:.2%} vs modelo {modelo:.2%} mensual (tolerancia ±{tol:.2%}); "
                            f"p95 {p95:.2%} en {len(s)} meses")}
