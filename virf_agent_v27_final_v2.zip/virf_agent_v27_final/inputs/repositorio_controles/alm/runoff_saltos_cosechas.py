"""Control de run-off: ninguna cosecha se desgasta de forma atípica frente a las demás a la misma edad (migraciones)."""

META = {
    "descripcion": "Por segmento y edad, el link ratio de cada cosecha (saldo(k) ÷ saldo(k−1)) no se aleja más de k desviaciones robustas (y del desvío mínimo) del de las demás cosechas a esa edad; una fecha con varias cosechas atípicas a la vez señala una migración, fusión o reclasificación del producto.",
    "dimension":   "Conductual (run-off)",
    "evidencia":   "Bitácora de migraciones, fusiones de cuentas y reclasificaciones con fecha y monto.",
    "referencia":  "Método de cosechas (link ratios); BCBS 368 (calidad de los datos de los supuestos conductuales)",
    "orden":       14,
    "tipos":       ["runoff"],
    "params": {"dataset": "", "campo_segmento": "segmento", "campo_cosecha": "cosecha", "campo_edad": "edad",
               "campo_fecha": "fecha", "campo_saldo": "saldo", "k": 8.0, "desvio_minimo": 0.05, "min_cosechas": 5,
               "simultaneas": 3, "umbral_pct": 1.0},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cg, cc, ce, cf, cs = (params.get("campo_segmento", "segmento"), params.get("campo_cosecha", "cosecha"),
                          params.get("campo_edad", "edad"), params.get("campo_fecha", "fecha"),
                          params.get("campo_saldo", "saldo"))
    if cc not in cols or cs not in cols or (ce not in cols and cf not in cols):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan la cosecha '{cc}', el saldo '{cs}' o la edad/fecha ('{ce}' / '{cf}')"}
    d = pd.DataFrame({"g": df[cg].astype(str) if cg in cols else "TOTAL", "c": df[cc].astype(str),
                      "s": pd.to_numeric(df[cs], errors="coerce")})
    if cf in cols:
        d["f"] = pd.to_datetime(df[cf].astype(str), errors="coerce")
    if ce in cols:
        d["k"] = pd.to_numeric(df[ce], errors="coerce")
    else:
        fc = pd.to_datetime(df[cc].astype(str), errors="coerce")
        d["k"] = (d["f"].dt.year - fc.dt.year) * 12 + (d["f"].dt.month - fc.dt.month)
    d = d.dropna(subset=["s", "k"])
    agg = {"s": ("s", "sum")}
    if "f" in d:
        agg["f"] = ("f", "max")
    d = d.groupby(["g", "c", "k"], as_index=False).agg(**agg).sort_values(["g", "c", "k"])
    d["s0"] = d.groupby(["g", "c"])["s"].shift()
    d["k0"] = d.groupby(["g", "c"])["k"].shift()
    d = d[(d["k0"] == d["k"] - 1) & (d["s0"] > 0)].copy()
    d["r"] = d["s"] / d["s0"]
    kk, minc = float(params.get("k", 8.0)), int(params.get("min_cosechas", 5))
    dmin, simult = float(params.get("desvio_minimo", 0.05)), int(params.get("simultaneas", 3))
    evaluados, raros = 0, []
    for _clave, x in d.groupby(["g", "k"]):
        if len(x) < minc:
            continue
        med = x["r"].median()
        esc = float((x["r"] - med).abs().median()) * 1.4826
        esc = esc if esc > 0 else float((x["r"] - med).abs().mean()) * 1.2533
        evaluados += len(x)
        if esc > 0:
            dev = (x["r"] - med).abs()
            raros += list(x.index[(dev / esc > kk) & (dev > dmin)])
    if not evaluados:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"ninguna edad tiene {minc} cosechas observadas para comparar"}
    pct_raro = 100.0 * len(raros) / evaluados
    x = d.loc[raros]
    fechas, masivas = "", 0
    if len(x) and "f" in x:
        por_fecha = x.groupby(x["f"].dt.strftime("%Y-%m")).size().sort_values(ascending=False)
        masivas = int((por_fecha >= simult).sum())
        fechas = "; fechas con más cosechas atípicas: " + ", ".join(f"{k} ({v})" for k, v in por_fecha.head(3).items())
    ejemplos = ", ".join(f"{r.g}/{r.c} a {r.k:g} m: ×{r.r:.2f}" for r in x.sort_values("r").head(3).itertuples())
    return {"pct": round(100.0 - pct_raro, 2),
            "decision": "Cumple" if (pct_raro <= float(params.get("umbral_pct", 1.0)) and not masivas) else "Observado",
            "diagnostico": (f"{len(raros)} de {evaluados} link ratios atípicos (más de {kk:g} desviaciones robustas "
                            f"frente a las cosechas de la misma edad)" + (f": {ejemplos}" if ejemplos else "")
                            + fechas + (f" · {masivas} fecha(s) con {simult} o más cosechas atípicas a la vez: "
                                        "explica la migración o reclasificación" if masivas else ""))}
