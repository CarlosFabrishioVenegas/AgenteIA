"""Control conductual (NMD): el núcleo y su vencimiento medio respetan los topes de BCBS 368 por categoría."""

META = {
    "descripcion": "El núcleo estable de los depósitos sin vencimiento y su vencimiento medio no superan los topes de BCBS 368: minorista transaccional 90 % y 5 años; minorista no transaccional 70 % y 4,5 años; mayorista 50 % y 4 años.",
    "dimension":   "Conductual (NMD)",
    "evidencia":   "Parámetros del modelo por segmento (porción estable / núcleo y vencimiento medio del núcleo).",
    "referencia":  "BCBS 368 (IRRBB, 2016), tabla de topes para depósitos sin vencimiento",
    "orden":       25,
    "tipos":       ["nmd", "runoff"],
    # Topes editables. La categoría se reconoce por el texto del segmento.
    "params": {"dataset": "", "campo_segmento": "segmento", "campo_core": "core", "campo_vida_media": "vida_media",
               "topes": {"no_transaccional": [0.70, 4.5], "transaccional": [0.90, 5.0], "mayorista": [0.50, 4.0]}},
}


def control(df, datasets, params):
    import unicodedata
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    cs, cc, cv = (params.get("campo_segmento", "segmento"), params.get("campo_core", "core"),
                  params.get("campo_vida_media", "vida_media"))
    if cs not in cols or cc not in cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": f"faltan '{cs}' y/o '{cc}'"}
    topes = params.get("topes") or {}

    def canon(v):
        t = "".join(c for c in unicodedata.normalize("NFKD", str(v)) if not unicodedata.combining(c)).lower()
        return t.replace("-", "_").replace(" ", "_")

    core = pd.to_numeric(df[cc], errors="coerce")
    core = core / (100.0 if core.dropna().quantile(0.75) > 1 else 1.0)
    vida = pd.to_numeric(df[cv], errors="coerce") if cv in cols else None
    if vida is not None and vida.dropna().quantile(0.75) > 10:
        vida = vida / 12.0                                   # venía en meses
    malos, evaluados, sin_cat = [], 0, []
    for i, seg in df[cs].items():
        cat = canon(seg)
        clave = next((k for k in ("no_transaccional", "transaccional", "mayorista") if k in cat and k in topes), None)
        if clave is None:
            sin_cat.append(str(seg))
            continue
        evaluados += 1
        tope_c, tope_v = float(topes[clave][0]), float(topes[clave][1])
        c = core.get(i)
        v = vida.get(i) if vida is not None else None
        if pd.notna(c) and c > tope_c + 1e-9:
            malos.append(f"{seg}: núcleo {c:.0%} > {tope_c:.0%}")
        if v is not None and pd.notna(v) and v > tope_v + 1e-9:
            malos.append(f"{seg}: vencimiento medio {v:.2f} años > {tope_v:g}")
    if evaluados == 0:
        return {"pct": None, "decision": "Revisión manual",
                "diagnostico": ("ningún segmento se reconoce como minorista transaccional, no transaccional o mayorista; "
                                f"asigna la categoría (p. ej. {', '.join(sin_cat[:3])})")}
    pct = round(100.0 * (evaluados - min(len(malos), evaluados)) / evaluados, 2)
    return {"pct": pct, "decision": "Cumple" if not malos else "No cumple",
            "diagnostico": ((f"{len(malos)} exceso(s) sobre los topes: " + "; ".join(malos[:5])) if malos else
                            f"{evaluados} segmento(s) dentro de los topes de BCBS 368")
            + (f"; sin categoría: {', '.join(sin_cat[:3])}" if sin_cat else "")}
