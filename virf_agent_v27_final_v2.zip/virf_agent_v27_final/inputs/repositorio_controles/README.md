# Repositorio de controles de datos (funciones Python por dominio)

Repositorio **especializado** de controles escritos como **funciones Python**.
Cuando el modelo activo tiene un tipo (dominio), el notebook entregable toma los
controles de la carpeta de ese dominio y produce un `.ipynb` **específico** —no
genérico— para ese modelo.

## Estructura (una carpeta por DOMINIO real)

```
inputs/repositorio_controles/
  var/     TRADING — VaR / ES, backtesting (Kupiec, Christoffersen, semáforo), PLA, RFET…
  alm/     ALM — conductuales (prepago, NMD, run-off: supervivencia y desgaste del saldo,
           cancelación de DPF, Kaplan–Meier) e IRRBB (gap, ΔEVE, ΔNII, SOT)
  lar/     LIQUIDEZ — LCR / RCL, NSFR / RFNE, LaR, estrés y horizonte de supervivencia,
           concentración del fondeo
  shared/  transversales, se añaden a CUALQUIER dominio (los cubre la batería)
```

La lista viva de controles (uno por `.py`, con su descripción) **se genera** del propio
repositorio: por carpeta en `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md` y por tipo de modelo en
`docs/GUIA_TIPOS_DE_MODELO.md` (`scripts/generar_guia_*.py`; un test exige que estén al día).

**Taxonomía de modelos → dominio → carpeta:**

| Familia (padre) | Modelos hijos | Dominio / carpeta |
|---|---|---|
| **Trading** | VaR, ES (FRTB), estrés de mercado, valoración, curvas, contraparte | `var/` |
| **ALM** *(padre)* | prepago (MCP), supervivencia/retiro (MCR), NMD, run-off, cancelación de DPF, FTP, IRRBB | `alm/` |
| **Liquidez** | LaR, RCL (≈ LCR), RFNE (≈ NSFR), brechas, estrés, concentración del fondeo | `lar/` |

> **ALM es el dominio PADRE** de los modelos conductuales (prepago, supervivencia,
> NMD, run-off) y del IRRBB. `conductuales` es el alias antiguo de `alm`. El **tipo
> de modelo** de la ficha decide qué controles entran (`META["tipos"]`) y suma su
> carpeta; `carpeta_de_dominio` tolera mayúsculas y sinónimos (`alm`, `conductuales`,
> `mcp`, `mcr`, `prepago`, `supervivencia`, `rcl`, `lcr`, `rfne`, `nsfr`, `trading`…).

## Contrato de un control

Cada `.py` define un `META` y una función `control`:

```python
META = {
    "descripcion": "qué verifica",       # → 'Control Esperado'
    "dimension":   "Backtesting (VaR)",   # → 'Dimensión'
    "evidencia":   "qué soporte pedir",   # → 'Control o Evidencia requerida'
    "referencia":  "cita a literatura",   # → 'Referencia en el entregable'
    "orden":       20,                    # (opc.) orden en el notebook
    "tipos":       ["var", "es_frtb"],    # (opc.) tipos de modelo a los que aplica (ver
                                          #  docs/GUIA_TIPOS_DE_MODELO.md); sin «tipos», a todos
    "params":      {"campo_var": "var_99"},  # columnas/umbrales editables (campo_<rol> se enlaza
                                             #  con la columna que cumple ese rol de negocio)
}

def control(df, datasets, params):
    # df = dataset principal; datasets = {nombre: DataFrame}; params = META['params']
    return {
        "pct": 99.4,           # % de cumplimiento (o None si no evaluable)
        "decision": "Cumple",  # Cumple | Observado | No cumple | No evaluable | Revisión manual
        "diagnostico": "3 excepciones en 500 obs...",
    }
```

## Qué genera el notebook

Una celda por control que **embebe el código real** del `.py`, lo ejecuta e
imprime:

```
>>>> C01: Backtesting de VaR (Kupiec POF)...
Control   | Resultado      | % cumplimiento  | Diagnóstico
C01       | No cumple      | 94.40%          | 28 excepciones en 500 obs...
```

y una celda final que consolida el **cuadro de 8 columnas**:

`Control · Dimensión · Control Esperado · % De cumplimiento del data set ·
Diagnóstico · Decisión · Control o Evidencia requerida · Referencia en el
entregable`.

## Añadir un control

1. Crea un `.py` en la carpeta del dominio (copia uno existente).
2. Ajusta `META` y la función `control`.
3. Vuelve a **descargar el notebook**: tu control ya aparece como una celda.

> Los `params` (nombres de columna, umbrales) son editables **dentro del
> notebook** también: si tu dataset usa otros nombres, cámbialos ahí y re-ejecuta.
