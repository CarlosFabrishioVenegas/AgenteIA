# Estándar de validación VIRF del banco

> MATERIAL INTERNO DEL BANCO — estándar de validación. Origen: `inputs/Estandares_VIRF.xlsx` (huella SHA-256 43893fef2d3b). Generado por `scripts/generar_corpus_banco.py`.
> Es el CRITERIO DE LA ENTIDAD para validar; no es evidencia del modelo validado.

El estándar define, por ámbito, los controles que la validación debe cubrir y las actividades concretas con las que se evalúa cada control, y en qué Tier de modelo aplica cada actividad (Tier I es el de mayor criticidad).


## Ámbito: Documentación


### Control: Verificar la existencia, suficienica y claridad del Manual Metodologico

Para el ámbito Documentación, el control «Verificar la existencia, suficienica y claridad del Manual Metodologico» se evalúa con estas actividades:

- Verifica la existencia de control de cambios/versiones (aplica a Tier I, II, III, IV).
- Verifica la inclusión del objetivo, usos y usuarios del modelo (aplica a Tier I, II, III, IV).

### Control: Vertificar la existencia, sufiencia y claridad del manual de implementación

Para el ámbito Documentación, el control «Vertificar la existencia, sufiencia y claridad del manual de implementación» se evalúa con estas actividades:

- Verifica la existencia de control de cambios/versiones (aplica a Tier I, II, III, IV).
- Verifica la existencia , suficiencia y claridad de la documentación (aplica a Tier I, III).
- Verificar la coherencia del manual de implementación con el manual métodolocios (aplica a Tier I, III).
- Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos. (aplica a Tier I, III).

### Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento

Para el ámbito Documentación, el control «Verifica la existencia, suficiencia y calridad del informe de seguimiento» se evalúa con estas actividades:

- Verifica la existencia de control de cambios/versiones (aplica a Tier I, III, IV).
- Verificar la existencia, suficiencia y claridad de la documentación (aplica a Tier I, III, IV).
- Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique. (aplica a Tier I, II, III, IV).

## Ámbito: Calidad de datos


### Control: El modelo deberá contar con controles de calidad de datos de primera linea sobre los resultados calculados (outliers, missing, duplicados, entre otros)

Para el ámbito Calidad de datos, el control «El modelo deberá contar con controles de calidad de datos de primera linea sobre los resultados calculados (outliers, missing, duplicados, entre otros)» se evalúa con estas actividades:

- Verificar que no exista suficiencia de controles de calidad de datos (integridad) (aplica a Tier I, II, IV).
- Revisar la existencia de reportes de incidencia, monitorio de calidad de datos (entradas y salidas) (aplica a Tier II, IV).

### Control: Revisión de la integridad y consistencias de los inputs

Para el ámbito Calidad de datos, el control «Revisión de la integridad y consistencias de los inputs» se evalúa con estas actividades:

- Verificar que no exista duplicados sobre los inputs que estén en el alcance de validación (aplica a Tier II, IV).
- Verificar la consistencia de las variables más importantes en el alcance de validación (Missing, outlier) (aplica a Tier II, IV).
- Verificar la integridad sobre los inputs en el alcance de validación (aplica a Tier II, IV).
- Verificar la actualización de los inputs (aplica a Tier I, II, IV).

## Ámbito: Metodología


### Control: Revisión de la justificación de la metodología

Para el ámbito Metodología, el control «Revisión de la justificación de la metodología» se evalúa con estas actividades:

- Existencia de buenas prácticas en el enfoque metodológico (aplica a Tier I, II, III, IV).
- Validar supuestos y consideración más importantes de la técnica utilizada (aplica a Tier I, III, IV).
- Revisión de los lineamiento internacionales o nacionales (aplica a Tier I, III, IV).

### Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación

Para el ámbito Metodología, el control «Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación» se evalúa con estas actividades:

- Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación (aplica a Tier I, III, IV).
- Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique (aplica a Tier I, III, IV).
- Analizar el seguimeinto de la metodología (aplica a Tier I, III, IV).

## Ámbito: Gobierno


### Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero

Para el ámbito Gobierno, el control «Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero» se evalúa con estas actividades:

- Revisar la actualización del tiering del modelo (aplica a Tier I, III, IV).
- revisar que el modelo se encuentre inventariado (aplica a Tier I, III, IV).

## Ámbito: Implementación


### Control: Revisión de Lineamientos de seguridad

Para el ámbito Implementación, el control «Revisión de Lineamientos de seguridad» se evalúa con estas actividades:

- Verifica las fuentes de información empleadas (aplica a Tier I, III, IV).
- Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos (aplica a Tier I, II, III, IV).

### Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)

Para el ámbito Implementación, el control «Pruebas iniciales sobre la implementación de modelo (desarrollo externo)» se evalúa con estas actividades:

- Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros) (aplica a Tier I, II, IV).
- Vericar existencias de correos de comunicación de resultados y su conformidad (aplica a Tier I, II, IV).

## Ámbito: Uso e integración a la gestión


### Control: Revisión de los usos, impactos y usuarios del modelo

Para el ámbito Uso e integración a la gestión, el control «Revisión de los usos, impactos y usuarios del modelo» se evalúa con estas actividades:

- Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo (aplica a Tier I, II, IV).
- Validar que el modelo no se enceuntre en uso antes o durante la validación (aplica a Tier II, III, IV).
- Identificar los usuario del modelo (aplica a Tier II, III, IV).

### Control: Revisión de la integración a la gestión del modelo

Para el ámbito Uso e integración a la gestión, el control «Revisión de la integración a la gestión del modelo» se evalúa con estas actividades:

- Adecuada integración a la gestión del modelo (aplica a Tier II, III, IV).
- Verificar existencias y suficinecia del reporting (aplica a Tier II, III, IV).
