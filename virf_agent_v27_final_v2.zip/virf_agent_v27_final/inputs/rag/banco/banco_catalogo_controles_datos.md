# Catálogo de controles de calidad de datos del banco

> MATERIAL INTERNO DEL BANCO — catálogo de controles de datos. Origen: `inputs/repositorio_controles/` (huella SHA-256 6fc955c4a795). Generado por `scripts/generar_corpus_banco.py`.
> Es el CRITERIO DE LA ENTIDAD para validar; no es evidencia del modelo validado.

Controles de calidad de datos que la Gerencia de Validación aplica según el tipo de modelo. Cada control indica qué se comprueba, su dimensión de calidad, la evidencia que se pide y su referencia normativa.


## Controles de datos — Trading / riesgo de mercado (VaR)


### Control de datos: var negativos

El VaR estimado debe ser estrictamente positivo (un VaR ≤ 0 es un error de cálculo o de signo).

- Dimensión de calidad: Validez (VaR).
- Evidencia requerida: Serie de VaR estimado por fecha.
- Referencia: SR 11-7 — razonabilidad de las salidas del modelo.

### Control de datos: kupiec

Backtesting de VaR (Kupiec POF): la tasa de excepciones debe ser consistente con 1 − nivel de confianza.

- Dimensión de calidad: Backtesting (VaR).
- Evidencia requerida: Serie diaria de P&L y VaR (o una columna 0/1 de excepciones), mín. ~250 obs.
- Referencia: Kupiec (1995); Basilea — backtesting.

### Control de datos: semaforo basilea

El nº de excepciones de backtesting en ~250 días debe situar el modelo en zona VERDE de Basilea (0-4); amarilla (5-9) es observación, roja (>=10) es rechazo.

- Dimensión de calidad: Backtesting (VaR).
- Evidencia requerida: Serie diaria de excepciones (0/1) o el par P&L/VaR, ~250 obs.
- Referencia: Basilea — marco de backtesting (traffic light approach).

### Control de datos: severidad excepciones

Cuando la pérdida supera el VaR, el exceso medio (pérdida−VaR)/VaR no debería ser grande: excesos severos apuntan a colas mal capturadas.

- Dimensión de calidad: Backtesting (VaR).
- Evidencia requerida: Serie diaria de P&L y VaR.
- Referencia: Backtesting basado en magnitud (loss-function / severidad de excepciones).

### Control de datos: alineacion pnl var

La marca de excepción del backtesting compara el P&L de cada día con el VaR del día ANTERIOR (rezago de un día), no con el del mismo día.

- Dimensión de calidad: Backtesting (VaR).
- Evidencia requerida: Serie diaria de P&L, VaR y la marca de excepción que se reporta; procedimiento de backtesting.
- Referencia: Basilea — marco de backtesting (VaR del cierre de t contra el P&L de t+1).

### Control de datos: christoffersen

Independencia de las excepciones (Christoffersen): las excepciones no deben agruparse (clustering) en el tiempo.

- Dimensión de calidad: Backtesting (VaR).
- Evidencia requerida: Serie diaria ORDENADA de excepciones (o P&L y VaR) de la ventana de backtesting.
- Referencia: Christoffersen (1998), Evaluating Interval Forecasts.

### Control de datos: backtesting excedencias

Backtesting por conteo de excedencias: nº de excepciones en la ventana debe caer en zona verde del semáforo de Basilea.

- Dimensión de calidad: Backtesting (VaR).
- Evidencia requerida: Serie diaria de excepciones (o P&L y VaR) de la ventana de 250 días.
- Referencia: Basilea — backtesting traffic light (verde/amarillo/rojo).

### Control de datos: monotonia niveles var

El VaR debe crecer en magnitud con el nivel de confianza: |VaR99| >= |VaR95| >= |VaR90| en cada fecha. Una inversión delata un error de cómputo.

- Dimensión de calidad: Coherencia metodológica (VaR).
- Evidencia requerida: Columnas de VaR a distintos niveles (p. ej. var_99, var_95, var_90).
- Referencia: Propiedad de monotonía del VaR respecto al nivel de confianza.

### Control de datos: escalado horizonte

El VaR a 10 días es coherente con el VaR a 1 día: si se escala por la raíz del tiempo, VaR10 ≈ √10 × VaR1 (3,16 veces) en casi todos los días.

- Dimensión de calidad: Metodología (VaR).
- Evidencia requerida: VaR 1 y 10 días por fecha y el método de escalado declarado en el manual.
- Referencia: Basilea — enmienda de riesgo de mercado (horizonte de 10 días; escalado por √t).

### Control de datos: matriz covarianzas

La matriz de correlaciones del VaR paramétrico es simétrica, tiene unos en la diagonal y es semidefinida positiva (ningún autovalor negativo).

- Dimensión de calidad: Metodología (VaR).
- Evidencia requerida: Matriz de correlaciones (o covarianzas) usada en el cálculo, por fecha.
- Referencia: VaR paramétrico (varianza-covarianza): σ²_P = wᵀΣw exige Σ semidefinida positiva.

### Control de datos: pla frtb

Prueba de atribución de P&L (PLA): el P&L teórico del modelo de riesgo (RTPL) se parece al hipotético (HPL) — Spearman > 0,80 y Kolmogorov–Smirnov < 0,09 (zona verde).

- Dimensión de calidad: Atribución de P&L (FRTB).
- Evidencia requerida: HPL y RTPL diarios por mesa, últimos 250 días.
- Referencia: BCBS d457 (FRTB): PLA — verde Spearman > 0,80 y KS < 0,09; rojo Spearman < 0,70 o KS > 0,12.

### Control de datos: rfet modelabilidad

Cada factor de riesgo es modelable (RFET): en los últimos 12 meses tiene ≥ 24 observaciones reales sin ningún periodo de 90 días con menos de 4, o ≥ 100 observaciones.

- Dimensión de calidad: Datos de mercado (FRTB).
- Evidencia requerida: Observaciones reales de precios (transacciones o cotizaciones ejecutables) por factor y fecha.
- Referencia: BCBS d457 (FRTB): risk factor eligibility test (RFET).

## Controles de datos — ALM y modelos conductuales


### Control de datos: cpr prepago

La tasa de prepago observada (CPR = prepagos / saldo) debe caer dentro de la banda esperada del modelo conductual.

- Dimensión de calidad: Conductual (prepago).
- Evidencia requerida: Serie de prepagos y saldos por periodo.
- Referencia: Modelos de prepago (CPR/SMM); gobernanza de supuestos conductuales.

### Control de datos: gap reprecios

Ninguna banda de reprecio debe presentar un descalce |activos − pasivos| superior al límite sobre el total de activos.

- Dimensión de calidad: Riesgo de tasa (ALM).
- Evidencia requerida: Balance clasificado por banda de reprecio y signo activo/pasivo.
- Referencia: Basilea IRRBB (BCBS d368); SR 11-7.

### Control de datos: runoff curvas

La curva de run-off del modelo es coherente: la supervivencia S(t) empieza en 1 y nunca sube, el run-off acumulado es R(t) = 1 − S(t), el desgaste incremental d(t) = S(t−1) − S(t) no es negativo y suma el acumulado; se informa el componente estable (S al último plazo) y el plazo económico (∫ S(t) dt hasta el último plazo).

- Dimensión de calidad: Conductual (run-off).
- Evidencia requerida: Curva del modelo por segmento y plazo: supervivencia, run-off acumulado y/o desgaste incremental.
- Referencia: Modelos de supervivencia de saldos (vencimiento conductual); BCBS 368 (supuestos de NMD).

### Control de datos: smm cpr consistencia

El SMM/CPR reportado es el que sale de los saldos: SMM = prepago ÷ (saldo inicial − amortización programada) y CPR = 1 − (1 − SMM)^12.

- Dimensión de calidad: Conductual (prepago).
- Evidencia requerida: Serie mensual por segmento con saldo inicial, amortización programada, prepago y la tasa reportada.
- Referencia: Convención de mercado SMM/CPR; BCBS 368 (supuestos de prepago).

### Control de datos: runoff supervivencia saldos

La curva de supervivencia del modelo se reproduce con la historia: por cosechas, S(k) = Π (Σ saldo(j) ÷ Σ saldo(j−1)) sobre las cosechas observadas en ambos meses, o el run-off del saldo existente en cada corte (`curva_de`, según el manual); si solo hay saldo total, un ajuste exponencial; la diferencia con la curva del modelo en cada plazo no supera la tolerancia.

- Dimensión de calidad: Conductual (run-off).
- Evidencia requerida: Saldos por cosecha y mes (o la serie del saldo del producto) y la curva del modelo por plazo.
- Referencia: Método de cosechas (link ratios) para curvas de saldo; Kaplan y Meier (1958).

### Control de datos: runoff saltos cosechas

Por segmento y edad, el link ratio de cada cosecha (saldo(k) ÷ saldo(k−1)) no se aleja más de k desviaciones robustas (y del desvío mínimo) del de las demás cosechas a esa edad; una fecha con varias cosechas atípicas a la vez señala una migración, fusión o reclasificación del producto.

- Dimensión de calidad: Conductual (run-off).
- Evidencia requerida: Bitácora de migraciones, fusiones de cuentas y reclasificaciones con fecha y monto.
- Referencia: Método de cosechas (link ratios); BCBS 368 (calidad de los datos de los supuestos conductuales).

### Control de datos: backtesting prepago

El CPR modelado debe seguir de cerca al observado: el error absoluto medio (MAE) entre ambos no debe superar la tolerancia.

- Dimensión de calidad: Conductual (prepago).
- Evidencia requerida: Serie por periodo de CPR observado y CPR modelado.
- Referencia: Backtesting de modelos conductuales de prepago.

### Control de datos: decaimiento nmd

Los depósitos sin vencimiento (NMD) deben mostrar un núcleo estable: la proporción de saldo que permanece (mín/promedio) por encima del umbral 'core'.

- Dimensión de calidad: Conductual (NMD).
- Evidencia requerida: Serie temporal de saldos de depósitos sin vencimiento.
- Referencia: Modelización de NMD / core deposits; IRRBB (comportamiento de depósitos).

### Control de datos: delta eve

La máxima caída del valor económico (ΔEVE) entre los escenarios de shock no debe exceder el 15% del capital de nivel 1 (outlier IRRBB).

- Dimensión de calidad: Riesgo de tasa (ALM).
- Evidencia requerida: ΔEVE por escenario de shock (±200 pb y los 6 estándar) y capital de nivel 1.
- Referencia: BCBS d368 — IRRBB, prueba de valor atípico (15% de CET1/Tier 1).

### Control de datos: escenarios irrbb completos

El análisis IRRBB debe cubrir los seis escenarios supervisores: paralelo ↑/↓, empinamiento, aplanamiento, tasa corta ↑/↓.

- Dimensión de calidad: IRRBB (ALM).
- Evidencia requerida: Columna de escenario con una fila por shock supervisor.
- Referencia: BCBS 368 — IRRBB, seis escenarios de shock estándar.

### Control de datos: vida media nmd

La vida media asumida para los depósitos sin vencimiento (NMD) debe ser positiva y no superar el tope prudencial (típicamente 5 años).

- Dimensión de calidad: Conductual (NMD).
- Evidencia requerida: Vida media (años) por producto/segmento de NMD, o el perfil de decaimiento del que se deriva.
- Referencia: BCBS 368 — IRRBB, tope de 5 años a la vida media de los NMD.

### Control de datos: sot eve tier1

El peor ΔEVE (en valor absoluto) entre los escenarios de shock no debe superar el 15% del capital de Nivel 1 (prueba del valor atípico supervisor).

- Dimensión de calidad: IRRBB (ALM).
- Evidencia requerida: ΔEVE por escenario de shock y el Tier 1 de referencia.
- Referencia: BCBS 368 — IRRBB, Supervisory Outlier Test (umbral 15% Tier 1).

### Control de datos: nucleo topes bcbs

El núcleo estable de los depósitos sin vencimiento y su vencimiento medio no superan los topes de BCBS 368: minorista transaccional 90 % y 5 años; minorista no transaccional 70 % y 4,5 años; mayorista 50 % y 4 años.

- Dimensión de calidad: Conductual (NMD).
- Evidencia requerida: Parámetros del modelo por segmento (porción estable / núcleo y vencimiento medio del núcleo).
- Referencia: BCBS 368 (IRRBB, 2016), tabla de topes para depósitos sin vencimiento.

### Control de datos: beta deposito

El beta de traspaso (deposit beta = sensibilidad de la tasa del depósito a la tasa de mercado) debe estar en [0,1] y dentro de la banda esperada del modelo.

- Dimensión de calidad: Conductual (pricing de depósitos).
- Evidencia requerida: Beta estimado por producto/segmento de depósito.
- Referencia: Modelos de pass-through de depósitos; gobernanza de supuestos conductuales.

### Control de datos: brecha duracion

La brecha de duración (duración del activo − duración del pasivo) debe mantenerse dentro del límite fijado por el ALCO.

- Dimensión de calidad: IRRBB (ALM).
- Evidencia requerida: Duración (o duración modificada) de activos y pasivos por fecha, o la brecha ya calculada.
- Referencia: Gestión de riesgo de tasa — análisis de duración / duration gap.

### Control de datos: delta nii

La caída del margen financiero (ΔNII) a 12 meses ante el shock de tasa no debe exceder el límite de apetito (% del NII base).

- Dimensión de calidad: Riesgo de tasa (ALM).
- Evidencia requerida: ΔNII por escenario de shock y NII base (proyectado a 12 meses).
- Referencia: BCBS d368 — IRRBB, sensibilidad de ingresos (ΔNII).

### Control de datos: cancelacion anticipada

La tasa mensual de cancelación anticipada observada (saldo cancelado antes del vencimiento ÷ saldo vivo) es coherente con la que usa el modelo.

- Dimensión de calidad: Conductual (depósitos a plazo).
- Evidencia requerida: Depósitos con fechas de inicio, vencimiento y cierre, y saldo; tasa de cancelación del modelo.
- Referencia: BCBS 368 (riesgo de redención anticipada de depósitos a plazo).

### Control de datos: supervivencia km

La supervivencia observada de las cuentas (Kaplan–Meier, tratando como censuradas las que siguen abiertas) es coherente con la curva del modelo a 12, 24 y 60 meses, segmento a segmento si ambos lo traen (en un run-off de saldos, la de cuentas es un contraste: no tiene por qué coincidir).

- Dimensión de calidad: Conductual (supervivencia).
- Evidencia requerida: Cuentas con fecha de apertura y de cierre (vacía si siguen abiertas) y la curva del modelo.
- Referencia: Kaplan y Meier (1958); BCBS 368 (supuestos conductuales).

## Controles de datos — Liquidez (LaR, RCL, RFNE)


### Control de datos: horizonte supervivencia

La posición de liquidez ACUMULADA (entradas − salidas) no debe caer bajo el colchón en ningún bucket.

- Dimensión de calidad: Liquidez (LaR).
- Evidencia requerida: Escalonamiento de flujos por bucket temporal (maturity ladder).
- Referencia: BCBS 238 — survival horizon / maturity ladder.

### Control de datos: lar percentil

El LaR reportado es el percentil de las salidas netas acumuladas en el horizonte (suma móvil de los flujos netos), con la ventana y el nivel del manual.

- Dimensión de calidad: Liquidez (LaR).
- Evidencia requerida: Serie diaria de flujos netos (o entradas y salidas) y el LaR reportado.
- Referencia: BCBS — principios de gestión del riesgo de liquidez (2008).

### Control de datos: runoff tasas

La tasa de salida en estrés de cada segmento es al menos el percentil histórico de las caídas de saldo en el horizonte (p. ej. 30 días al 99 %): r_t = 1 − S(t+h) ÷ S(t).

- Dimensión de calidad: Liquidez (estrés).
- Evidencia requerida: Serie histórica de saldos por segmento (diaria o mensual) y tabla de tasas de salida en estrés del modelo.
- Referencia: BCBS — principios de gestión del riesgo de liquidez (2008); BCBS 238 (tasas de salida de referencia).

### Control de datos: lcr

El LCR (HQLA / salidas netas de 30 días) debe ser >= 100% en todo periodo reportado.

- Dimensión de calidad: Liquidez (LaR).
- Evidencia requerida: HQLA y salidas netas de efectivo a 30 días por fecha (o el LCR ya calculado).
- Referencia: BCBS 238 — Liquidity Coverage Ratio (mínimo 100%).

### Control de datos: hqla composicion

Los activos líquidos de Nivel 2 no pueden superar el 40% del HQLA total, y los de Nivel 2B el 15% (tras haircuts).

- Dimensión de calidad: Liquidez (LaR).
- Evidencia requerida: HQLA desglosado por nivel (1, 2A, 2B) por fecha.
- Referencia: BCBS 238 — composición del HQLA (topes 40% Nivel 2, 15% Nivel 2B).

### Control de datos: lcr tope entradas

El LCR reportado es HQLA ÷ (salidas − mín(entradas; 75 % de las salidas)): las entradas no pueden cubrir más del 75 % de las salidas.

- Dimensión de calidad: Liquidez (LCR).
- Evidencia requerida: HQLA, salidas y entradas ponderadas a 30 días por fecha, y el ratio reportado.
- Referencia: BCBS 238 — tope de entradas del 75 % en el denominador del LCR.

### Control de datos: concentracion fondeo

La financiación no debe depender en exceso de una sola contraparte: la mayor cuota de fondeo por proveedor debe estar por debajo del umbral.

- Dimensión de calidad: Liquidez (LaR).
- Evidencia requerida: Fondeo por contraparte/proveedor (una fila por proveedor, o columna de proveedor + monto).
- Referencia: BCBS 238 — herramientas de seguimiento: concentración de la financiación.

### Control de datos: nsfr

El NSFR (fondeo estable disponible / requerido) debe ser >= 100%.

- Dimensión de calidad: Liquidez (LaR).
- Evidencia requerida: ASF (fondeo estable disponible) y RSF (requerido) por fecha, o el NSFR ya calculado.
- Referencia: BCBS 295 — Net Stable Funding Ratio (mínimo 100%).

### Control de datos: factores nsfr

Los factores ASF y RSF aplicados son valores de la norma: ASF 0, 50, 90, 95 o 100 %; RSF 0, 5, 10, 15, 50, 65, 85 o 100 %.

- Dimensión de calidad: Liquidez (NSFR).
- Evidencia requerida: Tabla de rubros con su saldo y factor ASF/RSF aplicado.
- Referencia: BCBS 295 (NSFR, 2014): factores de fondeo estable disponible y requerido.

### Control de datos: brecha liquidez acumulada

La brecha de liquidez acumulada (entradas−salidas, sumada por banda temporal en orden) no debe caer por debajo de cero dentro del horizonte.

- Dimensión de calidad: Liquidez (LaR).
- Evidencia requerida: Flujos por banda temporal: entradas y salidas (o la brecha neta ya calculada), ordenados por plazo.
- Referencia: Análisis de brechas de liquidez (maturity ladder).

## Controles de datos — Transversal (BCBS 239)


### Control de datos: completitud datos

Ninguna columna del data set debe superar el umbral de valores faltantes (nulos/NaN).

- Dimensión de calidad: Calidad del dato (transversal).
- Evidencia requerida: El data set tal cual se usa en el modelo.
- Referencia: BCBS 239 — completitud e integridad de los datos de riesgo.

### Control de datos: duplicados registros

La proporción de registros duplicados (fila completa, o por clave si se indica) debe estar por debajo del umbral.

- Dimensión de calidad: Calidad del dato (transversal).
- Evidencia requerida: El data set tal cual se usa en el modelo.
- Referencia: BCBS 239 — exactitud e integridad; deduplicación.

### Control de datos: frescura datos

La observación más reciente del data set debe estar dentro de la ventana máxima de antigüedad.

- Dimensión de calidad: Calidad del dato (transversal).
- Evidencia requerida: Data set con una columna de fecha.
- Referencia: BCBS 239 — oportunidad (timeliness) de los datos de riesgo.

### Control de datos: volumen minimo

El data set debe tener al menos el número mínimo de observaciones para sostener el análisis (p. ej. ~250 para backtesting).

- Dimensión de calidad: Calidad del dato (transversal).
- Evidencia requerida: El data set tal cual se usa en el modelo.
- Referencia: Buenas prácticas de validación — suficiencia muestral.

### Control de datos: columnas constantes

Ninguna columna relevante debería tener un único valor constante en todas las filas (indicio de campo mal poblado o congelado).

- Dimensión de calidad: Calidad del dato (transversal).
- Evidencia requerida: El data set tal cual se usa en el modelo.
- Referencia: BCBS 239 — integridad; validación de razonabilidad de campos.
