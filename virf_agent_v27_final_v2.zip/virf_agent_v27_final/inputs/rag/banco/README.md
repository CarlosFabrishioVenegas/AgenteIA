# inputs/rag/banco/ — material que usa el banco para validar

Criterio de la entidad que el agente consulta en TODAS las evaluaciones, además
del dominio del modelo: estándar, procedimiento, catálogo de controles, reglas
de calificación (los genera `scripts/generar_corpus_banco.py`) y las normas o
políticas internas que suba el administrador del corpus (.pdf, .docx, .xlsx,
.pptx, .md, .txt), cada una con dueño y vigencia.

NO va aquí la evidencia de un modelo concreto (sus manuales, su código, su
manual de controles de datos): eso es lo que se valida.

Este README no se indexa.
