# Reglas de calificación de los informes de validación del banco

> MATERIAL INTERNO DEL BANCO — reglas de calificación y glosario. Origen: `modulos/reglas_informe.py y modulos/plantilla_bcp.py` (huella SHA-256 43e20fc1766f). Generado por `scripts/generar_corpus_banco.py`.
> Es el CRITERIO DE LA ENTIDAD para validar; no es evidencia del modelo validado.


## Niveles de riesgo de una observación

De menor a mayor gravedad: Oportunidad de Mejora, Potencial, Bajo, Moderado, Crítico. Una Oportunidad de Mejora no es un incumplimiento: no deja el control como no cumplido y no lleva responsable ni fecha de subsanación.


## Calificación global de la gestión del modelo

Niveles: Satisfactorio, Aceptable, Regular, Deficiente.

- Deficiente: más de 2 observaciones críticas.
- Regular: 1 o 2 críticas; o más de una moderada (más de 3 si al menos una es de Documentación y otra de Gobierno).
- Aceptable: una moderada (o menos de 3 con la excepción de Documentación y Gobierno), o 5 o más observaciones bajas o potenciales. «Aceptable» nunca lleva críticas.
- Satisfactorio: como máximo 4 observaciones bajas o potenciales y ninguna moderada ni crítica.

## Cumplimiento del estándar

Un control del estándar se considera no cumplido cuando tiene al menos una observación de riesgo. Un control que no aplica al modelo se excluye del cumplimiento con su motivo, y uno que no se pudo revisar se declara como limitación y tampoco se da por satisfactorio.


## Glosario

- **Banco de Crédito del Perú** (BCP): Entidad financiera titular del modelo validado.
- **Validación Interna de Riesgo Financiero** (VIRF): Gerencia encargada de la revisión independiente de los modelos de riesgo financiero.
- **Riesgo de modelo**: Posibilidad de pérdidas o decisiones erróneas derivadas de errores en el diseño, la implementación o el uso de un modelo.
- **Estándar de validación**: Conjunto de ámbitos, controles y actividades que la validación debe cubrir.
- **Ámbito**: Dimensión evaluada del modelo: Documentación, Calidad de Datos, Metodología, Implementación, Gobierno y Usos.
- **Control**: Requisito del estándar que agrupa una o más actividades de revisión.
- **Actividad**: Prueba o revisión concreta que se ejecuta para evaluar un control.
- **Observación**: Hallazgo que evidencia un incumplimiento o una debilidad en un control.
- **Oportunidad de Mejora** (OM): Hallazgo que no constituye un incumplimiento pero cuya atención fortalecería la gestión del modelo.
- **Riesgo crítico**: Deficiencia que compromete la fiabilidad del modelo y exige atención inmediata.
- **Riesgo moderado**: Deficiencia relevante que debe subsanarse en el corto plazo.
- **Riesgo bajo**: Deficiencia de impacto acotado sobre los resultados del modelo.
- **Riesgo potencial**: Debilidad que aún no se ha materializado pero podría afectar al modelo.
