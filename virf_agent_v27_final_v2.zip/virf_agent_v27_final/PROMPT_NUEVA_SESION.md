# Prompt para continuar en una sesión nueva (estado al 2026-11-24)

Copia el bloque de abajo y pégalo como primer mensaje de la sesión nueva, abierta en esta misma
carpeta. Complementa a `GUIA_TRASPASO_CONTEXTO.md` (exhaustiva, pero con estado al 2026-11-18): aquí
va lo que cambió desde entonces y cómo retomarlo sin perder nada.

```text
Retomas el proyecto VIRF Agent (validador de modelos de riesgo financiero: web FastAPI + CLI agente.py),
en la carpeta actual. Responde siempre en español y en lenguaje simple. Verifica antes de afirmar que algo
funciona.

ANTES DE NADA
1) Lee GUIA_TRASPASO_CONTEXTO.md (§1-§5 y §16), PROMPT_NUEVA_SESION.md (este archivo, entero) y tu
   memoria del proyecto (MEMORY.md se carga sola si estás en Claude Code en esta carpeta).
2) Mira el estado con `git status` y `git diff --stat`. OJO: rama `docs/firma-sin-validador`, último commit
   b742a5e, `main` local SIN remoto y MUCHO trabajo SIN COMMITEAR (≈117 archivos modificados o nuevos).
   NO hagas checkout, reset, stash, clean ni nada que descarte el árbol de trabajo. Commit solo si te lo pido.
3) Si necesitas el detalle de lo hecho en la sesión anterior, su transcripción está en
   C:\Users\REC TECHNOLOGY\.claude\projects\C--Users-REC-TECHNOLOGY-Desktop-Cursos-Proyectos-Repo-proyectosPersonales-Proyecto-Validador-autonomo-virf-agent-v27-final--1-\50556d88-a9ab-4b6c-afb5-7e2bf84f8ff0.jsonl

REGLAS DURAS (no negociables)
- Usa SIEMPRE .venv (`.venv\Scripts\python`), nunca el Python del sistema (tiene torch/HF/chromadb).
- No toques .env; solo .env.example. Todo parámetro nuevo se declara en config/parametros.py
  (+ __all__, config/__init__.py y .env.example).
- No cambies config/ia.py -> PROVEEDORES (decisión del banco): azure_openai=APROBADO (GPT, el que corre),
  anthropic=EN_ESPERA, openai=RETIRADO. Claves solo desde Key Vault / entorno del proceso.
- Tests a coste 0: la IA siempre simulada. Nunca llames a una IA real sin preguntarme (cuesta dinero).
- Sin detección automática: modos y proveedores con flags/variables explícitas.
- RAG léxico (BM25 + TF-IDF): nada de embeddings, ChromaDB, HuggingFace ni vector stores.
- No lances POSTs a ciegas contra la web en marcha: escriben en rutas globales (feedback/, audit_logs/).
- Sin exec/eval en producción (valida con ast.parse). Los notebooks que genera VIRF corren en el equipo
  del validador, nunca en el servidor.
- No añadas filas a docs/seguridad/GOBIERNO_RIESGO_IA.md: el estado de aprobación lo decido yo.
- Finales de línea: .env.example, config/__init__.py, config/modelos.py, motor/Mx_00 a Mx_03 y
  tests/test_azure_mocks.py son CRLF (motor/Mx_04 es LF); el resto, casi todo LF. Edita con la herramienta Edit (conserva el final de línea) o, si usas un
  script, lee bytes y reescribe con el mismo final. Antes de terminar compara con `git show HEAD:<archivo>`.
- Prefiero flujos reutilizables (generadores) a documentos escritos a mano.

LO QUE YA ESTÁ HECHO (sin commitear) — no lo rehagas
1. Solo Informe: estándar con holgura (revisado / no aplica con motivo / limitación, actividades propias),
   ámbitos sin actividades (p. ej. Gobierno en Tier II) visibles con nota y sugerencias, «Especializar con
   IA» que no pisa lo del validador, varios sustentos por observación, gráfico estructurado
   (modulos/graficos_estructurados.py), código de modelo en portada y ficha, panel «Generar» no fijo.
2. Validar modelo: el pipeline escribe en outputs/ de la SESIÓN (--salida) y la revisión con el agente
   empieza sola con ese resultado y su Word.
3. Agente conversacional (web/services/chat_service.py): prompt «consecuente»; decisiones explícitas
   (confirmar / subsanada: / no aplica: / pendiente:); subsanar exige motivo concreto; verifica citas,
   archivos y CIFRAS; un fallo técnico no decide ni gasta intentos; comandos ayuda / estado /
   reabrir N: motivo (con botones); auditoría por decisión (decidido_por); candado por sesión; historial
   atómico; parámetros CHAT_MAX_TOKENS y CHAT_MAX_CARACTERES.
4. Controles de datos con IA desde .info()/.describe() (modulos/controles_ia.py + web/routers/controles.py):
   catálogo de 30 tipos; el notebook trae SIEMPRE todos los controles: C (reglas/IA/aprendidos),
   T (reglas por TIPO DE MODELO en REGLAS_TIPO_MODELO var/alm/lar), D (controles de
   inputs/repositorio_controles/<dominio>/ embebidos con sus campo_* enlazados al perfil; deciden por su
   propia prueba, umbral None), B (batería completa sobre todas las columnas) y plantillas de cada tipo que
   falta; X (del validador sin programar) y P (programados o traídos de otros notebooks con @mi_control;
   adaptadores a_resultado / llamar_flexible). Porcentaje de cumplimiento (cumplen ÷ evaluados, ponderado
   por criticidad, por grupo) en hojas Resumen y Cobertura; MODO_DEMO; comprobación contra el perfil;
   evidencia local; hojas Controles · Resumen · Cobertura · Perfil_vs_datos · Controles_personalizados ·
   Metadatos. Aprendizaje por dominio (modulos/aprendizaje_controles.py): lecciones pendientes que aprueba
   un revisor (nunca el autor), registro sellado feedback/aprendizaje_controles.jsonl, olvido por descartes.
5. RAG: corpus del banco (inputs/rag/banco/, scripts/generar_corpus_banco.py, RAG_BANCO / RAG_TOP_K_BANCO).
6. Revisión «solo Claude»: motor/Mx_00 usa config/modelos.py -> modelo_declarado / max_tokens_declarado
   (no en config/ia.py: ciclo de imports; no en motor/: test de neutralidad de marcas); Mx_03 deja el tope
   al cliente; --dry-run estima con config.ia.modelo_activo(); el cliente Azure añade «JSON» si falta con
   formato_json; arreglado un NameError en agente._modelo_ia_real.
7. Validación completa: cada etapa entrega <etapa>_HALLAZGOS.xlsx y .md (todos los hallazgos con su Excel de
   sustento; modulos/hallazgos_completa.py). «Consolidar hallazgos» (POST /api/completa/consolidar) LEE esos
   Excel y .md de las 5 etapas, avisa inconsistencias y escribe
   outputs/validacion_completa/_consolidado/HALLAZGOS_VALIDACION_COMPLETA.xlsx/.md; el cuadro y el anexo
   Word leen esos entregables.
8. Guías generadas desde el código (un test exige que estén al día): GUIA_USO.md
   (scripts/generar_guia_uso.py) y docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md
   (scripts/generar_guia_calidad_datos.py; se sirve en /api/motores/ia/guia). Regeneradas también
   INVENTARIO_ARCHIVOS.md, REFERENCIA_TECNICA.md y graphify-out/.
9. TIPO DE MODELO y RUTA PASO A PASO (segunda parte del 2026-11-24):
   - Fichas de negocio de 19 tipos (VaR, ES/FRTB, estrés de mercado, valoración, curvas, contraparte,
     IRRBB, prepago, NMD, cancelación de plazo, supervivencia, FTP, run-off, LCR/RCL, NSFR/RFNE, brechas,
     LaR, estrés de liquidez, concentración): modulos/tipos_modelo.py (ROLES y enlace) +
     tipos_modelo_trading/_alm/_liquidez.py. El tipo se elige EXPLÍCITO en la ficha del modelo
     (`tipos_modelo`; Nuevo modelo y Configuración; GET /api/modelos/tipos).
   - Notebook de calidad «x10»: «Entender el modelo», BASES/ROLES editables (+3b), controles M por roles
     con su porqué (sin columna = Pendiente), 14 tipos nuevos de control (44), batería dinámica (4d:
     columnas sin perfil y llaves compartidas entre bases), hoja Roles; repositorio filtrado por
     META["tipos"] y 13 análisis nuevos (PLA, RFET, matriz PSD, run-off, SMM/CPR, topes NMD, LCR 75 %,
     NSFR, LaR…). Arreglado: _fechas invertía fechas ISO de CSV (pandas 2 + dayfirst).
   - Validación completa: modulos/plantillas_etapa.py (experto y ruta 00–04, plantillas por tipo: réplica
     02, impactos 03 con correcciones automáticas, backtesting 04) + modulos/libreria_cuant.py. El agente
     declara la ruta y normalizar_ruta la verifica (sin pasos cubiertos no hay «lista»). El 01 entrega el
     notebook de calidad rico (perfiles de las hojas perfil_<base> del 00). La web muestra experto y ruta.
     Arreglado: al recargar la página no se pintaba la modalidad completa.
   - Guía nueva generada: docs/GUIA_TIPOS_DE_MODELO.md (scripts/generar_guia_tipos_modelo.py).
     Tests: tests/test_tipos_modelo.py (+ tests/_sinteticos_tipos.py).
10. RUN-OFF = SUPERVIVENCIA DEL SALDO (definición confirmada por mí, 2026-11-24): a qué velocidad se
   retira/vence/agota el saldo de un producto cuyo vencimiento contractual no refleja su comportamiento.
   Desde la experiencia histórica: curva S(t), run-off acumulado R = 1 − S, desgaste incremental
   d = S(t−1) − S(t), componentes estable/volátil, plazo económico (∫S) y asignación a bandas.
   - Ficha `runoff` en tipos_modelo_alm.py (familia ALM, carpeta alm/): bases saldos (por cosecha),
     cuentas, curva, componentes, bandas y contabilidad; 31 controles M (curva que nunca sube, d ≥ 0,
     estable + volátil = 100 %, bandas al 100 % y conciliadas con el balance del corte y los componentes,
     migraciones en el total del segmento).
   - Repositorio alm/: runoff_curvas (coherencia S/R/d), runoff_supervivencia_saldos (réplica por cosechas
     vs la curva del modelo), runoff_saltos_cosechas (link ratio atípico = migración). lar/runoff_tasas
     pasó a ser de «stress_liquidez» (tasas de salida en estrés: NO es el run-off).
   - libreria_cuant: supervivencia_cosechas, supervivencia_saldo_existente, curva_runoff, plazo_economico,
     componentes_runoff, limites_banda, asignar_bandas, curvas_del_modelo, replicar_runoff,
     backtesting_runoff. Plantillas 02/03/04 nuevas; SUPUESTOS["curva_de"] = "cosecha" o
     "saldo_existente" (explícito, según el manual).
   - Catálogo: relacion_aritmetica con `valor` fijo, conciliacion_por_grupo con pareja="base",
     saltos_serie con agregar="suma" y hasta 2 grupos; dataset_<base> de los análisis se enlaza con la
     base que el tipo enlazó.
   - Demo reproducible: scripts/demo_runoff.py → outputs/<fecha>/demo_runoff/ (datos, notebooks 00–04, Excels y
     DEMO_RUNOFF.md), sin IA.
11. VALIDACIÓN COMPLETA → VALIDACIÓN FINAL (08 · 09 · 10), pedido mío: en modalidad completa el barrido
   (08) solo se lanza con las cinco etapas cerradas (409 si no) y con TODO su trabajo:
   validacion_completa.publicar_en_validacion copia solo entregables de VIRF (<etapa>_HALLAZGOS.md, el
   Excel <etapa>_resultadoITERn de cada notebook, el consolidado y 00_LEEME_VALIDACION_COMPLETA.md) a
   documentacion/modelamiento|seguimiento/validacion_completa/ y calidad_datos/validacion_completa/; el
   Excel del 01 va a calidad_datos/resultadocalidad_de_datos/completa_01_ControlDatos.xlsx y el ámbito
   Calidad de datos lo PUNTÚA. Nunca viajan los datos enviados a los chats. El chat 09 recibe los hallazgos
   de las etapas del ámbito de cada observación ({validacion_completa} en el prompt, sincronizado en
   web/data/prompts_base.json); el 10 ya tenía el anexo de etapas. Web: panel en 08 (GET
   /api/completa/paquete) y botón «Ir a 08» al cerrar las cinco.
12. MAPA, SOPORTE Y TRASPASO: docs/MAPA_HERRAMIENTA.md (generado por scripts/generar_mapa_herramienta.py;
   tests/test_mapa_herramienta.py), docs/GUIA_ERRORES_Y_SOPORTE.md, docs/GUIA_MEJORAS.md,
   PROMPT_OTRO_ASISTENTE.md, skills S13/S14 del paquete docs/agente_corporativo/ y la skill de Claude Code
   .claude/skills/soporte-virf/ (con scripts/chequeo.py: entorno, finales de línea, guías, validador,
   tests por área y foto de registros globales). SIGUIENTE (pedido mío): presentaciones de toda la
   herramienta, ampliando scripts/generar_presentacion_guia.py con el mapa como fuente.

ESTADO DE LAS PRUEBAS
- Suite completa: 1977 passed, 2 skipped (tests/ + pruebas/). Única roja conocida (a propósito):
  tests/test_gobierno_ia.py::test_inventario_cubre_cada_llamante_de_ia — faltan en
  docs/seguridad/GOBIERNO_RIESGO_IA.md las filas de estudio_insumos y validacion_completa (las decido yo).
- validate_project.py --strict: 147/147 PASS.
- La suite tarda ~10 min sola (1 h 30 si corre a la vez que otras cosas pesadas): lánzala en segundo plano.
  No hay pytest-timeout ni node instalados.

PENDIENTE (decisiones mías, no las tomes tú)
- Filas del inventario de gobierno de IA: estudio_insumos y validacion_completa, y revisar las filas 5
  (controles de datos con IA) y 9 (Solo informe).
- Dueño y vigencia del corpus del banco: scripts/generar_corpus_banco.py --dueno ... --vigencia ...
- Probar con IA real (cuesta): propuesta de controles con IA, especializar Solo informe, chat, etapas
  (ahora con la ruta paso a paso y la ficha del tipo de modelo en el prompt).
- Que un validador revise las fichas: umbrales, bandas del manual, tasas regulatorias locales (RCL/RFNE)
  y, en run-off, el horizonte del componente estable (60 meses por defecto) y si la curva del modelo es
  de cosechas o del saldo existente (SUPUESTOS["curva_de"]).
- Commit de todo el trabajo (aún nada commiteado).

CÓMO VERIFICAR SIN ROMPER NADA
- Tests rápidos de lo nuevo:
  .venv\Scripts\python -m pytest -q -p no:cacheprovider tests/test_controles_bateria_tipo_modelo.py
    tests/test_aprendizaje_controles.py tests/test_controles_ia.py tests/test_hallazgos_completa.py
    tests/test_chat_controles.py tests/test_proveedor_gpt.py tests/test_guias_generadas.py
    tests/test_tipos_modelo.py tests/test_validacion_completa.py
  (con PYTHONUTF8=1 en el entorno).
- Guías al día: scripts/generar_guia_uso.py --comprobar, scripts/generar_guia_calidad_datos.py --comprobar
  y scripts/generar_guia_tipos_modelo.py --comprobar.
- Web de prueba: .venv\Scripts\python scripts\web_prueba.py --puerto 8010 (usuario libre, sin SSO).
  Antes, copia web/data/validadores.json; al terminar, restáuralo, borra web/data/sesiones/PRUEBA_<tu_usuario>
  y comprueba que audit_logs/registro_emisiones.jsonl y feedback/registro_validadores.json no cambiaron.
  No uses «Enseñar al agente» en la web de prueba (escribe en feedback/aprendizaje_controles.jsonl, global).

PRIMERA TAREA
Confirma que entiendes el estado: resume en 5 líneas qué está hecho, qué está pendiente y qué riesgos ves.
Corre los tests rápidos de arriba y dime el resultado. Luego espera mis instrucciones.
```

## Qué hacer si cambias de computadora

1. Copia la carpeta entera del proyecto (incluye `.venv` o recréalo con `GUIA_INSTALACION.md`).
2. La memoria de Claude Code vive fuera del proyecto, en
   `C:\Users\<usuario>\.claude\projects\<carpeta-del-proyecto>\memory\`: cópiala también si quieres que la
   sesión nueva la cargue sola.
3. Pega el prompt de arriba.
