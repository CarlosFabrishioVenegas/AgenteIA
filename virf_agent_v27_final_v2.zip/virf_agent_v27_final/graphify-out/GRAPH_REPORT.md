# Graph Report - virf_agent_v27_final (1)  (2026-11-24)

## Corpus Check
- 447 files · ~892,849 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 42 file(s) not represented in the graph (top: .csv 9, .ipynb 7, (none) 5)

## Summary
- 8746 nodes · 19954 edges · 441 communities (229 shown, 212 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 782 edges (avg confidence: 0.86)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `b742a5eb`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- .get_conversation_history
- AgentOrchestrator
- app.py
- pipeline_calidad_datos.py
- controles_ia.py
- CorrectionsTracker
- Guía · Generador del PDF del agente corporativo
- Tests · RAG léxico (recuperación)
- llamar_ia_json
- argparse
- BuscadorLexico
- TestEnrutadoRAG
- motor_ia.py
- estandares_service.py
- ReasoningEngine
- get_retriever
- Archivado v28 · Vector store Chroma
- plantilla_bcp.py
- qa_endpoints.py
- Controles · Excel a notebook ejecutable
- Informe Word · Primitivas del entregable
- Archivado · Parches v13 (código muerto)
- Revisión de código · Juez anclado y hallazgos
- RAG · Indexador léxico
- Archivado · Generador Word antiguo (Mx_05)
- get_retriever
- Web · Gestión de modelos (store y rutas)
- Archivado v28 · Herramientas SQL y pandas
- Mx_01_LecturaEvidencias.py
- Seguridad · Cortacircuitos (fusibles)
- analisis_codigo.py
- rag.py
- Informes · Reglas de calificación y cumplimiento
- Automatizaciones · Cuadro de observaciones
- Prevuelo · Chequeo previo de evidencia
- analisis_codigo.py
- configurar_consola
- DocumentCache
- comparar
- test_versionado.py
- Tests · Simulación de Azure (pipeline)
- Archivado v28 · Compresión de contexto
- pathlib
- ClienteAzureOpenAIIA
- ClienteConsensoIA
- generar_presentacion_guia.py
- routers/config.py
- preguntas_oro_rag.py
- estudio_insumos.py
- Custodia · Registro de emisiones
- chat_service.py
- Solo Informe · Estándar, borrador e imágenes
- RevisorCodigo
- test_proveedores_ia.py
- Skills · Calidad de datos
- Skills · Catálogo y clase base
- solicitar_segunda_firma
- sesion_store.py
- abrirControles
- evaluar_abstencion
- Archivado · Config monolítica antigua
- Salvaguardas · Entailment (LLM como juez)
- Tests · RAG como pericia (no evidencia)
- Verificador VIRF · Paquete de verificación
- _codigo_vivo
- get
- enmascarar
- pedirJSON
- Solo Informe · Router y endpoints
- Aislamiento entre clientes (tenant)
- _detalle
- Motor IA · Scores y semáforo
- Archivado · Generador Excel antiguo
- Skills tipadas · Documentación y gobierno
- Feedback · Calidad del proceso y autoría
- graficos_estructurados.py
- test_solo_informe_holgura.py
- Solo Informe · Asistencia con IA
- Tests · Presentación del Word
- Web · Pantalla Solo Informe (frontend)
- Motor · Controles sobre datos (Mx_04)
- ChunkerService
- get_cliente_ia
- SkillCoherencia
- hallazgos_completa.py
- test_antialucinacion_brechas.py
- Citas · Validación determinista
- Tests · Controles de calidad de datos
- diagnostico_azure_virf.py
- modulos/validacion_completa.py
- validate_project.py
- feedback.py
- TestConstruirTabla
- Skills · Cola de acciones pendientes
- Tests · Análisis estático
- web/static/js/app.js
- Frontend · Guía interactiva
- Archivado v28 · Challenger con RAG
- motores_datos.py
- 20261118_antes_rediseno/static/js/app.js
- controles_a_notebook.py
- Análisis estático del código
- _partir_por_definiciones
- leer_resultados
- Informe web · Generador con capturas
- Evidencia · Capturas (pantallazos)
- auth.py
- Archivado · Lector de inputs antiguo
- Fixtures · IFRS9 y VaR de demostración
- motor_ia_v2.py
- json
- SkillSintesis
- leer_estandares_virf
- Tests · Resultados por celda del notebook
- upload.py
- DecisionTrace
- Tests · Informe Word sin puntajes falsos
- modulos/__init__.py
- Informe · Contrato ValidationReport
- pipeline_runner.py
- Archivado v28 · Challenger sin RAG
- test_solo_informe.py
- Chunker estructural
- TestCitasInventadasEnSkills
- Tests · Tope por tolerancia cero
- Tests · PDF real y chunking
- TestParserEstandares
- Tests · Neutralidad de proveedor IA
- Agente · Acotar contexto de skills
- Salvaguardas · Inyección de prompts
- Firma humana · Identidad del validador
- Identidad
- Tests · Conexión Azure y parámetros
- test_aprendizaje_controles.py
- ExplicadorModelo
- Tests · Automatizaciones
- revision_codigo.py
- Seguridad · Nombres de archivo seguros
- VIRFAgent
- Tests · Skills en el entregable
- Exportador Excel
- test_controles_ia.py
- Datos · Perfilado de datasets
- Tests · DOCX de regresión
- Multimodelo · Raíz de evidencia
- Tests · Skills tipadas
- Tests · Reintento ante cuota (429)
- test_owasp_llm.py
- Tests · Auditoría integral 2026-08-07
- hashlib
- Tests · Explicador agnóstico al modelo
- Tests · Cuestionamientos extensibles
- _contexto_modelo
- cablearSoloInforme
- Tests · Subida ZIP (límites)
- columns
- test_auditoria.py
- test_gobierno_codigo.py
- material_no_confiable
- almacenamiento.py
- leer_resultados
- Tests · Score de control ponderado
- test_almacenamiento.py
- Archivado v28 · Lector de código
- TestAuditoriaEntornoCorporativo
- construir_notebook
- test_ejecucion_codigo.py
- Tests · Contrato y estadísticas
- solo_informe_ia.py
- Tests · Umbral antisesgo
- Tests · Lectura íntegra de código e ipynb
- test_revision_sesion.py
- verificacion_cifras.py
- pedirJSON
- test_roles.py
- consolidar_decisiones
- TestExplicadorModelo
- Tests · Políticas del procedimiento 2026
- AST
- test_virf_plus.py
- WorkflowManager
- test_rag_banco.py
- Tests · Reintento de contrato
- Tests · Sin evidencia no es fallo
- Tests · Caché de resúmenes con bloqueo
- Tests · Lectura fallida declarada
- Doble
- Tests · Ninguna llamada externa
- diagnosticar
- PerfilModelo
- estandares.py
- 20261118_antes_rediseno/static/js/guia.js
- Skills · Regulatoria con RAG
- Tests · Historial de feedback
- Tests · Índice RAG sin contaminación
- Tests · Contexto se llena sin abandonar
- escapeHtml
- completa.js
- estado
- evidencia_sesion.py
- generar_informe_md
- cuestionamientos_ext.py
- Acta de cierre (Excel)
- test_aprendizaje_chat.py
- Tests · Fallo de credencial Azure
- openpyxl
- test_validacion_completa.py
- Tests · OCR retirado
- Archivado v28 · Skill detección de fórmulas
- Archivado v28 · Skill metodología
- response_evaluator.py
- Tests · Anexo de correcciones
- Fixtures · Modelo sintético Fraude/AML
- Tests · Un solo parser JSON
- verificar_remoto_git.py
- test_controles_bateria_tipo_modelo.py
- Frontend · Estándares
- test_corrida_fallida.py
- Análisis estático · Contraste doc vs código
- Tests · Sin documentos no hay puntaje
- ShortTermMemory
- TestAuditoriaRespuestaVaciaDeLaAPI
- Tests · Cobertura documental ponderada
- test_verificacion_citas.py
- Tests · Columna de control opcional
- Tests · Filtrado de controles
- perfil_modelo
- Código muerto · Buscador de evidencias
- test_calidad_e2e.py
- ClienteSimulado
- Frontend · Lanzar validación
- arrancar
- generar_corpus_banco.py
- custodia.py
- test_casos_borde.py
- conftest.py
- test_owasp_llm.py
- controles.py
- test_hallazgos_completa.py
- red.py
- TestPipelineCalidadDatos
- Tests · Pipeline de controles
- Tests · Ningún recorte silencioso
- reconstruir_estandar_desde_informes.py
- test_usuario_libre.py
- calcular
- TextChunker
- test_estudio_insumos.py
- Tests · Dos métricas de cobertura
- mostrarVista
- TestAcantiladoDeCoste
- agente.py
- unicodedata
- Control VaR · Kupiec
- Control VaR · Semáforo de Basilea
- test_clasificacion_docx.py
- test_databricks_minimo_dato.py
- _caption
- TestRagLexicoSinEmbeddingsNiHuggingFace
- Control ALM · Backtesting de prepago
- Control ALM · Beta de depósitos
- Control ALM · Brecha de duración
- Control ALM · CPR de prepago
- Control ALM · Decaimiento NMD
- Control ALM · Sensibilidad NII
- Control ALM · Escenarios IRRBB
- Control ALM · Gap de reprecios
- Control ALM · Vida media NMD
- Control LaR · Brecha de liquidez
- Control LaR · Concentración de fondeo
- Control LaR · Horizonte de supervivencia
- Control LaR · Composición HQLA
- Control LaR · LCR
- Control LaR · NSFR
- Control transversal · Columnas constantes
- Control transversal · Frescura
- Control VaR · Excedencias
- Control VaR · Severidad de excepciones
- Control VaR · VaR negativos
- TestAuditoriaEnvMalformadoNoTumbaElArranque
- es_de_entorno_virtual
- test_costes.py
- adjuntos_ole.py
- generar_kit.py
- revisar_resultados
- BuscadorEvidencias
- _leer_cache_cifrada
- pandas
- Tests · Feedback
- abrirChat
- os
- LongTermMemory
- EmbeddingGenerator
- test_identidad.py
- Tests · Fallos de red
- abrirConfiguracion
- construir_args
- arrancar
- ._hallazgos_previos
- reproducir_corrida.py
- .__init__
- _extraer_json
- test_proveedor_gpt.py
- test_revision_validador.py
- RepoReconstructionSkill
- test_guias_generadas.py
- .ejecutar
- hooks
- refrescarCard
- _sombrear_parrafo
- escanear_secretos.py
- solicitar_identidad
- test_rag_desactualizado.py
- siAccionIA
- TestAuditoriaRespuestaVaciaDeLaAPI
- abrirEstandares
- test_plantilla_bcp.py
- SkillSintesis
- TestPipelineCompletoConAzureSimulado
- ui.js
- cablearValidacion
- ValidationClaim
- TestExplicador
- TestAuditoriaNombresDeAmbitoCoherentes
- TestLosDosPipelinesSeComportanIgual
- TestIntegridad
- leer_archivo
- verificar_corpus_rag.py
- word_estilo.py
- sesion_activa
- TestAuditoriaBorrarDelCacheBorraDeVerdad
- ejecutar_motor
- test_endpoint_notebook_controles.py
- sca_pip_audit.json
- .limpiar_cache_resumenes
- DocumentationAuditSkill
- FailureAnalysisSkill
- PaperIntelligenceSkill
- test_invariante_asyncio.py
- comparar_doc_y_codigo
- FeedbackStore
- TestRuidoDePdfminer
- TestCorpusRagSeDeclaraComoResumenSecundario
- TestAuditoriaUnSoloAccesoAlHistorial
- delta_eve.py
- sot_eve_tier1.py
- monotonia_niveles_var.py
- comparar_respuestas
- inicializar_cache
- _Reporte
- TestConfiguracion
- RegulatoryReviewSkill
- exigir_permitido
- formatear
- _SDF
- normalizar_tier
- fabricas
- Cuestionamiento
- prevuelo
- logo_para_word
- _json_laxo
- TestRolAgenteOverride
- test_certificado_corporativo_es_capa_4_y_no_desactiva_tls
- TestAuditoriaCoberturaDeControlNoUsaMaximo
- TestSalidas
- prompt_evaluar_dimension
- _escribir_cache_cifrada
- entorno
- ctx_de_prueba
- TestAuditoriaImportLocalNoEnsombreceAlGlobal
- TestCustodiaHashDelFicheroPorAmbasRamas
- aprobar
- texto_para_prompt
- _render_supuestos

## God Nodes (most connected - your core abstractions)
1. `main()` - 94 edges
2. `escapeHtml()` - 83 edges
3. `pedirJSON()` - 74 edges
4. `pedirJSON()` - 66 edges
5. `escapeHtml()` - 60 edges
6. `get()` - 60 edges
7. `get_cliente_ia()` - 54 edges
8. `IndexadorLexico` - 49 edges
9. `ChunkerService` - 49 edges
10. `enmascarar()` - 46 edges

## Surprising Connections (you probably didn't know these)
- `test_todo_cliente_concreto_pasa_por_el_gateway()` --uses--> `ClienteConsensoIA`  [INFERRED]
  tests/test_gateway_ia.py → config/virf_plus.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/backtesting_prepago.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/beta_deposito.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/brecha_duracion.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/cpr_prepago.py → tests/test_regresion.py

## Import Cycles
- 2-file cycle: `modulos/hallazgos_completa.py -> modulos/validacion_completa.py -> modulos/hallazgos_completa.py`

## Communities (441 total, 212 thin omitted)

### Community 1 - "AgentOrchestrator"
Cohesion: 0.11
Nodes (6): AgentOrchestrator, TaskRouter, TaskType, build_agent(), handle_command(), main()

### Community 2 - "app.py"
Cohesion: 0.04
Nodes (37): raices_retencion(), index(), _purgar_retencion(), _version_assets(), carpeta_entrada(), carpeta_salida(), descargar(), estado() (+29 more)

### Community 3 - "pipeline_calidad_datos.py"
Cohesion: 0.17
Nodes (6): cargar_datasets(), _control_fechas_coherentes(), ejecutar_plan(), escribir_tabla(), main(), _veredicto()

### Community 4 - "controles_ia.py"
Cohesion: 0.09
Nodes (30): bateria_completa(), add(), bateria_tipo_modelo(), _carpeta(), _catalogo_prompt(), _centinelas_de(), _clave(), cobertura() (+22 more)

### Community 6 - "Guía · Generador del PDF del agente corporativo"
Cohesion: 0.06
Nodes (38): a_pdf(), analizar_modulos(), archivos_codigo(), catalogo_tests(), comunidades_del_grafo(), comunidades_por_archivo(), construir(), defaults_en_codigo() (+30 more)

### Community 7 - "Tests · RAG léxico (recuperación)"
Cohesion: 0.05
Nodes (9): _buscador(), _corpus(), _indexador(), TestExpansionDeConsulta, TestIndexadoYPersistencia, TestIntegracionConElMotor, TestRecuperacion, TestRelevanciaAbsoluta (+1 more)

### Community 8 - "llamar_ia_json"
Cohesion: 0.20
Nodes (3): llamar_ia_json(), _crop_to_json(), _validar_contrato()

### Community 9 - "argparse"
Cohesion: 0.04
Nodes (25): construir_stub(), main(), configurar_consola(), consola_soporta_unicode(), _forzar_codepage_utf8_windows(), _reconfigurar(), main(), _construir_pdf() (+17 more)

### Community 10 - "BuscadorLexico"
Cohesion: 0.05
Nodes (19): _anclas(), auditar(), _clasificar(), main(), explicar(), main(), _regla(), BuscadorLexico (+11 more)

### Community 12 - "motor_ia.py"
Cohesion: 0.04
Nodes (38): calibra_puntaje(), cargar_historial_calibracion(), construir_contexto_feedback(), ajustar_puntaje_por_feedback(), analizar_patron_errores(), cargar_historial(), construir_bloque_aprendizaje(), generar_resumen_aprendizaje() (+30 more)

### Community 13 - "estandares_service.py"
Cohesion: 0.20
Nodes (17): _cabeceras_ok(), carpeta(), _columnas_extra(), descartar_pendiente(), _escribir_meta(), escribir_normalizado(), guardar_pendiente(), _leer_meta() (+9 more)

### Community 15 - "get_retriever"
Cohesion: 0.06
Nodes (16): ALMRetriever, BancoRetriever, BaseRetriever, CustomDomainRetriever, _cargar_dominios_custom(), dominios_conocidos(), get_retriever(), get_retriever_banco() (+8 more)

### Community 16 - "Archivado v28 · Vector store Chroma"
Cohesion: 0.06
Nodes (3): Reranker, SemanticSearcher, ChromaManager

### Community 17 - "plantilla_bcp.py"
Cohesion: 0.09
Nodes (35): _alcance(), _bloque_codigo(), _bullet(), _callout(), _cell_left_accent(), _cell_margins(), _cuadro_resumen(), _cumplimiento() (+27 more)

### Community 18 - "qa_endpoints.py"
Cohesion: 0.26
Nodes (23): chk(), Cli, _iter(), J(), main(), reg(), seguro(), skip() (+15 more)

### Community 19 - "Controles · Excel a notebook ejecutable"
Cohesion: 0.06
Nodes (38): exportar_informe_word(), extraer_seccion_docstring(), extraer_variables_globales(), aprobado(), aprobar(), CodigoNoAprobado, ejecutar_aprobado(), hash_codigo() (+30 more)

### Community 20 - "Informe Word · Primitivas del entregable"
Cohesion: 0.08
Nodes (39): _add_ambito_heading(), _add_bullet(), _add_field_block(), _add_hallazgos_cdd(), _add_hallazgos_codigo(), _add_heading(), _add_numbered(), _add_para() (+31 more)

### Community 21 - "Archivado · Parches v13 (código muerto)"
Cohesion: 0.08
Nodes (5): CalculadorScore, create_resultado_control_v13(), DocumentoChunker, ReportadorEvaluacion, ValidadorInputs

### Community 22 - "Revisión de código · Juez anclado y hallazgos"
Cohesion: 0.05
Nodes (3): _aparece(), recategorizar(), TestJuezCodigoAnclado

### Community 23 - "RAG · Indexador léxico"
Cohesion: 0.04
Nodes (11): _huella_corpus_rag(), _buscadores(), evaluar_chunker(), _ndcg(), norm(), verificar_ground_truth(), fuentes_rag(), IndexadorLexico (+3 more)

### Community 24 - "Archivado · Generador Word antiguo (Mx_05)"
Cohesion: 0.12
Nodes (18): _add_run(), _cell_write(), GeneradorWord, generar_word_informe(), _heading(), _hrule(), _make_table(), _paragraph() (+10 more)

### Community 25 - "get_retriever"
Cohesion: 0.06
Nodes (28): borrar_custom(), get_estado(), conexiones(), _leer_parametros(), _muestra_rag(), preview_prompt(), borrar_custom(), add_custom() (+20 more)

### Community 26 - "Web · Gestión de modelos (store y rutas)"
Cohesion: 0.09
Nodes (26): test_codigo_de_modelo_en_la_ficha(), activar_modelo(), borrar_modelo(), crear_modelo(), desactivar(), listar_modelos(), modelo_activo(), NuevoModelo (+18 more)

### Community 27 - "Archivado v28 · Herramientas SQL y pandas"
Cohesion: 0.07
Nodes (7): BaseTool, PandasTool, PlottingTool, RecommendationTool, RetrievalTool, SHAPTool, SQLTool

### Community 28 - "Mx_01_LecturaEvidencias.py"
Cohesion: 0.08
Nodes (23): compilar_textos_de_carpeta(), _decodificar_texto(), detectar_manual_y_script(), _extraer_outputs_celda(), guardar_parametros_ejecucion(), leer_archivo_generico(), _leer_docx(), _leer_excel() (+15 more)

### Community 29 - "Seguridad · Cortacircuitos (fusibles)"
Cohesion: 0.10
Nodes (11): Cortacircuitos, CortacircuitosActivado, _Reloj, test_cap_de_iteraciones_corta_al_cuarto_intento(), test_cap_por_defecto_es_tres(), test_escalar_preserva_los_hallazgos_intermedios(), test_fusible_de_tiempo_corta_pasados_los_diez_segundos(), test_fusible_de_tokens_corta_pasados_los_veinte_mil() (+3 more)

### Community 30 - "analisis_codigo.py"
Cohesion: 0.14
Nodes (15): TestIntegracionCustom, TestPromptService, _armar_prompt(), _ahora(), _cargar_base(), clear_cache_para_tests(), editar_prompt(), _escribir_custom() (+7 more)

### Community 31 - "rag.py"
Cohesion: 0.10
Nodes (20): borrar_dominio(), borrar_paper(), crear_dominio(), _ejecutar_rebuild(), _leer_indice(), listar_dominios(), _modelos_que_usan(), NuevoDominio (+12 more)

### Community 32 - "Informes · Reglas de calificación y cumplimiento"
Cohesion: 0.09
Nodes (17): _barrido(), control_satisfactorio(), cumplimiento(), observaciones_por_control(), resaltar(), clave_ambito(), concluir(), conclusion_control() (+9 more)

### Community 34 - "Automatizaciones · Cuadro de observaciones"
Cohesion: 0.09
Nodes (28): asignar_responsable(), _buscar_columna(), _celda(), construir_prompt(), _cuadro_determinista(), _es_fallo(), _evidencia_verificada(), exportar_excel() (+20 more)

### Community 35 - "Prevuelo · Chequeo previo de evidencia"
Cohesion: 0.13
Nodes (5): _clasificar_fallo(), ejecutar_prevuelo(), Hallazgo, _es_evidencia(), TestPrevueloDeEvidencia

### Community 36 - "analisis_codigo.py"
Cohesion: 0.14
Nodes (16): analizar(), Feedback, feedback(), obtener(), agregar_feedback(), _analizar_generico(), _analizar_ipynb(), _analizar_py() (+8 more)

### Community 38 - "DocumentCache"
Cohesion: 0.10
Nodes (6): DocumentCache, _cache_cifrada_con_una_entrada(), test_cache_de_otra_clave_o_sin_clave_no_tumba_el_arranque(), test_limpiar_cache_cifrada_funciona_sin_clave(), TestAuditoriaCacheNoSeApagaPorHeuristica, TestAuditoriaElCacheNoRecortaLoQueElChunkerDebeCubrir

### Community 39 - "comparar"
Cohesion: 0.06
Nodes (11): CambioActividad, _cargar(), Comparacion, comparar(), _flecha(), formatear(), _indice_actividades(), _num() (+3 more)

### Community 40 - "test_versionado.py"
Cohesion: 0.10
Nodes (11): max_ctx_efectivo(), resolver_ventana(), _a_fecha(), chunk_activo(), filtrar_activos(), marcar_version(), _buscador(), _corpus() (+3 more)

### Community 41 - "Tests · Simulación de Azure (pipeline)"
Cohesion: 0.09
Nodes (8): cliente_azure(), respuesta_azure(), TestClienteAzureConstruyeBienLaPeticion, TestDeteccionAutomaticaDelDeployment, TestModoJsonExigeLaPalabraJson, TestModosDeFalloDeAzure, TestNegociacionDelParametroDeTokens, TestPipeline1ExplicadorYRevisionConAzure

### Community 42 - "Archivado v28 · Compresión de contexto"
Cohesion: 0.10
Nodes (3): ContextCompressor, ContextMemoryCompressor, ConversationSummarizer

### Community 43 - "pathlib"
Cohesion: 0.02
Nodes (22): ContextFilter, ContextPrioritizer, ContextRanker, FormulaDetector, MethodologyChecker, FeedbackAnalyzer, LearningLoop, DecisionType (+14 more)

### Community 44 - "ClienteAzureOpenAIIA"
Cohesion: 0.10
Nodes (7): ClienteAzureOpenAIIA, ClienteOpenAIIA, _detectar_key_en_example(), _envolver_gateway(), _secreto(), test_cliente_azure_rechaza_endpoint_no_permitido(), test_openai_exige_api_key()

### Community 45 - "ClienteConsensoIA"
Cohesion: 0.14
Nodes (8): ClienteConsensoIA, _llamada_independiente(), _mas_conservadora(), _nombre_modelo(), _puntaje_de(), test_virf_plus_bloqueado_mientras_claude_no_este_aprobado(), test_por_defecto_gpt_es_principal_y_arbitro(), test_sin_conclusion_con_un_solo_evaluador()

### Community 46 - "generar_presentacion_guia.py"
Cohesion: 0.07
Nodes (63): captura(), chip(), circulo(), codigo(), construir(), d_agenda(), d_agente_corporativo(), d_arquitectura() (+55 more)

### Community 47 - "routers/config.py"
Cohesion: 0.06
Nodes (34): obtener_secreto(), cargar(), _clave(), _firma(), guardar(), PickleNoFirmado, sec(), _escaner() (+26 more)

### Community 48 - "preguntas_oro_rag.py"
Cohesion: 0.06
Nodes (10): _chunks_del_dominio(), _elegible_r3(), evaluar(), evaluar_adversarias(), _fuentes_del_dominio(), informe(), main(), _metricas() (+2 more)

### Community 49 - "estudio_insumos.py"
Cohesion: 0.12
Nodes (22): borrar(), _bytes(), _cliente_por_defecto(), dir_cache(), dir_comun(), estudiar(), ficha_determinista(), ficha_ia() (+14 more)

### Community 50 - "Custodia · Registro de emisiones"
Cohesion: 0.08
Nodes (7): _añadir_linea(), _firmante(), _indexar_outputs(), leer_registro(), registrar_emision(), verificar_emisiones(), TestRegistroEmisiones

### Community 51 - "chat_service.py"
Cohesion: 0.12
Nodes (30): test_justificacion_concreta(), a_dict(), _agregar(), _ahora(), _aplicar_decision(), archivar(), _auditar(), avisos_comprension() (+22 more)

### Community 52 - "Solo Informe · Estándar, borrador e imágenes"
Cohesion: 0.08
Nodes (30): test_adjunto_endpoint_exige_clasificacion(), test_adjunto_rechaza_extension_tamano_y_id_invalido(), test_cargar_estandar_antiguo_se_rehace_desde_el_xlsx(), test_generar_exige_tier_si_el_estandar_lo_tiene(), TestParser, borrar_estandar(), descargar(), estado() (+22 more)

### Community 53 - "RevisorCodigo"
Cohesion: 0.08
Nodes (4): descubrir_modulos(), RevisorCodigo, TestRevisionCodigo, TestSqlYRSonCodigoDelModelo

### Community 54 - "test_proveedores_ia.py"
Cohesion: 0.13
Nodes (11): verificar_host_ia(), produccion(), test_allowlist_explicita_restringe_a_un_solo_recurso(), test_azure_pasa(), test_desconocido_o_vacio_falla(), test_get_cliente_en_modo_virf_plus_bloqueado(), test_get_cliente_ia_con_proveedor_no_aprobado_falla(), test_host_azure_corporativo_pasa() (+3 more)

### Community 55 - "Skills · Calidad de datos"
Cohesion: 0.12
Nodes (13): DataLeakageResult, DataQualityResult, _ejecutar_en_sandbox(), _evaluar_leakage(), _main(), _outliers_iqr(), run_data_quality_check(), csv_10_outliers_5_duplicados() (+5 more)

### Community 56 - "Skills · Catálogo y clase base"
Cohesion: 0.12
Nodes (7): SkillBase, listar_skills(), obtener_skill(), SkillGobierno, SkillPapers, ejecutar_skills(), resolver_seleccion()

### Community 57 - "solicitar_segunda_firma"
Cohesion: 0.07
Nodes (6): _normalizar_nombre(), requiere_doble_firma(), SegundaFirmaRequerida, solicitar_segunda_firma(), test_segunda_firma_exige_otra_identidad_autenticada(), TestDobleFirma

### Community 58 - "sesion_store.py"
Cohesion: 0.07
Nodes (21): test_sesion_caduca(), test_roles_salen_del_idp_no_del_registro(), validador_actual(), _reconstruye_ctx(), ws_chat(), _login_o_401(), ws_validar(), accion_de() (+13 more)

### Community 59 - "abrirControles"
Cohesion: 0.15
Nodes (20): abrirControles(), cablearTabs(), cargarCatalogoMotores(), cargarMotoresEntidad(), ciaAgregarBase(), ciaCargarAprendizaje(), ciaCargarEstado(), ciaDecidirLeccion() (+12 more)

### Community 60 - "evaluar_abstencion"
Cohesion: 0.07
Nodes (26): evaluar_abstencion(), _scores(), umbral_beta(), aplicar(), _retirar(), test_beta_por_defecto_solo_abstiene_ante_ausencia_total(), test_evidencia_fuerte_no_se_abstiene(), test_retrieval_debil_por_debajo_de_beta_se_abstiene() (+18 more)

### Community 61 - "Archivado · Config monolítica antigua"
Cohesion: 0.08
Nodes (8): ClienteAnthropicIA, ClienteAzureOpenAIIA, ClienteIA, _detectar_key_en_example(), get_cliente_ia(), mostrar_configuracion(), reset_cliente_ia(), _validar_consistencia_modelo()

### Community 62 - "Salvaguardas · Entailment (LLM como juez)"
Cohesion: 0.11
Nodes (15): activo(), _na(), _parsear(), _prompt(), _subcadena_laxa(), verificar(), ClienteFake, test_apagado_por_defecto_devuelve_na() (+7 more)

### Community 64 - "Verificador VIRF · Paquete de verificación"
Cohesion: 0.17
Nodes (16): bloque_A(), bloque_B_C(), bloque_D(), bloque_E(), bloque_F(), bloque_G(), Coleccion, _commit() (+8 more)

### Community 65 - "_codigo_vivo"
Cohesion: 0.10
Nodes (5): _codigo_vivo(), _ficheros_py(), TestAzureEsElProveedorPrioritario, TestMonolitoArchivadoNoSeImporta, TestPruebaDeHumoListaParaCredencial

### Community 66 - "get"
Cohesion: 0.05
Nodes (45): get(), salud(), adjuntar_chat(), consolidar_chat(), estado_chat(), estado_revision(), observaciones(), pendientes() (+37 more)

### Community 67 - "enmascarar"
Cohesion: 0.08
Nodes (39): contiene_pii(), _dni_nie_es_valido(), _dni_pe_verificador_valido(), enmascarar(), _enmascarar_nombres(), _rep_linea(), _rep_nombre(), _es_nombre() (+31 more)

### Community 68 - "pedirJSON"
Cohesion: 0.12
Nodes (28): abrirCuestionamientos(), abrirDominioRag(), abrirResultados(), abrirSkills(), agregarCuestCustom(), agregarSkillCustom(), analizarCodigo(), cablearCrearDominio() (+20 more)

### Community 69 - "Solo Informe · Router y endpoints"
Cohesion: 0.13
Nodes (24): ActividadExtra, Adjunto, ContextoGrafico, DatosInforme, generar(), guardar_borrador(), _ia(), ia_especializar() (+16 more)

### Community 70 - "Aislamiento entre clientes (tenant)"
Cohesion: 0.15
Nodes (13): assert_sin_contaminacion(), ContaminacionModelo, etiquetar_chunk(), filtrar_por_tenant(), pertenece(), porcentaje_contaminacion(), _corpus_mixto(), test_conjunto_mixto_dispara_la_asercion() (+5 more)

### Community 71 - "_detalle"
Cohesion: 0.25
Nodes (5): _bloque_citas(), _detalle(), _etiqueta_pj(), _orden_pj(), _pj()

### Community 72 - "Motor IA · Scores y semáforo"
Cohesion: 0.05
Nodes (20): _codigo_salida_corrida(), main(), _motivo_ambito_sin_score(), _motivo_no_evaluable(), _verificar_credencial(), _evaluar_actividad_thread_safe(), evaluar_ambito_paralelo(), evaluar_todos_ambitos_paralelo() (+12 more)

### Community 73 - "Archivado · Generador Excel antiguo"
Cohesion: 0.17
Nodes (15): _align(), _border_all(), _border_medium(), _color_puntaje_celda(), _color_score(), _crear_hoja_ambito(), _crear_hoja_resumen(), _crear_hoja_tracking() (+7 more)

### Community 74 - "Skills tipadas · Documentación y gobierno"
Cohesion: 0.11
Nodes (9): AlcanceRubro, ResultadoAlcance, SkillTipada, SkillCalidadDatos, SkillDocumentacion, SkillGobierno, SkillImplementacion, SkillMetodologia (+1 more)

### Community 75 - "Feedback · Calidad del proceso y autoría"
Cohesion: 0.09
Nodes (3): identidad_para_feedback(), calidad_proceso(), TestAutoriaFeedback

### Community 76 - "graficos_estructurados.py"
Cohesion: 0.12
Nodes (24): _alto_caja(), _alto_texto(), _apoyo(), _cabecera(), _caja(), _chars_por_linea(), _cifras_inventadas(), dibujar() (+16 more)

### Community 77 - "test_solo_informe_holgura.py"
Cohesion: 0.11
Nodes (27): _datos(), llm(), _png(), test_actividad_adicional_del_validador(), test_ambito_del_extra_casa_con_el_del_estandar(), test_codigo_del_modelo_en_portada_y_fichero(), test_descripcion_propia_reemplaza_al_generico(), test_endpoint_especializar() (+19 more)

### Community 78 - "Solo Informe · Asistencia con IA"
Cohesion: 0.07
Nodes (22): describir_tipos(), test_grafico_usa_la_observacion_completa(), cliente(), llm(), test_azure_por_defecto_y_lo_que_falta(), test_azure_usa_deployment_propio_del_apartado(), test_clave_rechazada_da_mensaje_claro(), test_desde_manuales_sin_manuales() (+14 more)

### Community 79 - "Tests · Presentación del Word"
Cohesion: 0.10
Nodes (3): _partir_por_vallas(), _procedencia_nota(), TestPresentacionWord

### Community 80 - "Web · Pantalla Solo Informe (frontend)"
Cohesion: 0.12
Nodes (40): cablearRevisionControles(), cablearSoloInforme(), entrarASoloInforme(), siAgregarExtra(), siAgregarSustento(), siAmbitoCanonico(), siAmbitosDisponibles(), siClaveAmbito() (+32 more)

### Community 81 - "Motor · Controles sobre datos (Mx_04)"
Cohesion: 0.09
Nodes (12): alertas_criticas(), calcular_riesgo_global(), _catalogo_para_deteccion(), convertir_resultado_data_a_texto(), detectar_cuestionamientos(), ejecutar_control_unicidad(), ejecutar_motor_data_por_fila(), parsear_config_control() (+4 more)

### Community 83 - "get_cliente_ia"
Cohesion: 0.10
Nodes (22): get_cliente_ia(), _azure(), _clave_en_env(), _produccion(), test_azure_a_medias_no_cuenta_como_presente(), test_cambiar_de_claude_a_gpt_cambia_de_proveedor(), test_cambiar_la_clave_reconstruye_el_cliente(), test_con_gpt_y_claude_gana_gpt_y_no_se_enciende_virf_plus() (+14 more)

### Community 84 - "SkillCoherencia"
Cohesion: 0.09
Nodes (3): SkillCoherencia, TestCoherenciaManualVsImplementacion, TestPuntajeNuloNoRompeNada

### Community 85 - "hallazgos_completa.py"
Cohesion: 0.16
Nodes (23): _ahora(), consolidar(), escribir_etapa(), _estado(), hallazgos_etapa(), hallazgos_vigentes(), _hoja(), leer_etapa() (+15 more)

### Community 86 - "test_antialucinacion_brechas.py"
Cohesion: 0.14
Nodes (6): _obs(), TestChat, TestChunker, TestPromptChat, TestPulir, verificar_respuesta()

### Community 87 - "Citas · Validación determinista"
Cohesion: 0.14
Nodes (17): cita_en_texto(), _limpio(), extraer_ids(), id_de_chunk(), _ids_disponibles(), normalizar_cita(), validar_afirmacion(), verificar_afirmaciones() (+9 more)

### Community 89 - "diagnostico_azure_virf.py"
Cohesion: 0.17
Nodes (14): Capa, capa_clave(), capa_endpoint(), capa_env(), capa_python(), capa_red(), capa_tls(), capas_llamada() (+6 more)

### Community 90 - "modulos/validacion_completa.py"
Cohesion: 0.09
Nodes (35): _ahora(), cargar_historial(), _celdas_plantilla(), cerrar_etapa(), _columnas_json(), construir_notebook(), construir_prompt(), contexto_para_cuadro() (+27 more)

### Community 91 - "validate_project.py"
Cohesion: 0.14
Nodes (20): CifradoNoDisponible, _es_ambito_metodologia(), test_paquete_ausente_no_se_reporta(), test_paquete_instalado_pero_roto_se_reporta(), check(), _es_de_entorno_virtual(), main(), seccion() (+12 more)

### Community 92 - "feedback.py"
Cohesion: 0.05
Nodes (34): modo_estadistica_feedback(), _escribir_json_atomico(), _lock_archivo(), aprobar_feedback(), autor_de(), bucle_feedback_consola(), _bucle_feedback_interactivo(), calcular_estadisticas() (+26 more)

### Community 93 - "TestConstruirTabla"
Cohesion: 0.14
Nodes (3): TestChatSeleccion, TestConstruirTabla, TestVeredictoActividad

### Community 94 - "Skills · Cola de acciones pendientes"
Cohesion: 0.15
Nodes (9): AccionPendiente, encolar_accion(), _escribir(), _leer(), listar_pendientes(), ruta_cola_por_defecto(), test_accion_de_impacto_queda_encolada_no_ejecutada(), test_el_modulo_no_expone_ninguna_via_de_ejecucion_directa() (+1 more)

### Community 96 - "web/static/js/app.js"
Cohesion: 0.06
Nodes (60): abrirChat(), abrirDocumentar(), abrirModalPasswd(), adjuntarEvidenciaChat(), AMBITO_PESOS, cablearChat(), cablearDocumentar(), cablearResultados() (+52 more)

### Community 97 - "Frontend · Guía interactiva"
Cohesion: 0.23
Nodes (22): abrirGuia(), AYUDA, barraHtml(), botonQ(), cerrarGuia(), construirGuia(), dashboardVisible(), _e() (+14 more)

### Community 99 - "motores_datos.py"
Cohesion: 0.18
Nodes (12): _base(), _cols(), _estado_por_tasa(), _falta(), _motor_completitud(), _motor_duplicados(), _motor_integridad_referencial(), _motor_missing() (+4 more)

### Community 100 - "20261118_antes_rediseno/static/js/app.js"
Cohesion: 0.08
Nodes (45): abrirControles(), abrirDocumentar(), abrirModalPasswd(), abrirResultados(), AMBITO_PESOS, cablearDocumentar(), cablearResultados(), cablearTabs() (+37 more)

### Community 101 - "controles_a_notebook.py"
Cohesion: 0.06
Nodes (34): analizar_brechas(), _code(), _codigo_control(), construir_notebook_controles(), extraer_controles_del_documento(), _firma(), generar_notebook_controles(), leer_controles_excel() (+26 more)

### Community 102 - "Análisis estático del código"
Cohesion: 0.13
Nodes (9): analizar_arbol(), analizar_modulo(), _codigo_de(), _contrastar_notebook(), _funciones_documentadas_ausentes(), _hechos(), _hechos_notebook(), _identificadores_en_manual() (+1 more)

### Community 106 - "Informe web · Generador con capturas"
Cohesion: 0.06
Nodes (34): citas_en_evidencia(), campo(), _caption(), cita(), _etiqueta_valor(), _p(), _tbl_header_repeat(), _param() (+26 more)

### Community 107 - "Evidencia · Capturas (pantallazos)"
Cohesion: 0.17
Nodes (17): captura_cita(), captura_codigo(), captura_portada(), _clave(), _fuente(), _leer(), _lineas_de(), localizar() (+9 more)

### Community 108 - "auth.py"
Cohesion: 0.09
Nodes (15): EntraIDProvider, IdentidadNoConfigurada, IdentityProvider, obtener_proveedor(), proveedor_activo(), ProveedorLibre, completar_login(), hacer_logout() (+7 more)

### Community 109 - "Archivado · Lector de inputs antiguo"
Cohesion: 0.16
Nodes (12): cargar_todos_los_inputs(), consolidar_contexto(), leer_archivo(), leer_csv(), leer_directorio(), leer_docx(), leer_json(), leer_pdf() (+4 more)

### Community 110 - "Fixtures · IFRS9 y VaR de demostración"
Cohesion: 0.09
Nodes (9): retornos_diarios(), var_cartera(), var_historico(), var_historico(), ajustar_forward_looking(), calcular_ecl(), clasificar_etapa(), var_historico() (+1 more)

### Community 111 - "motor_ia_v2.py"
Cohesion: 0.06
Nodes (12): CalculadorScore, create_resultado_control_v13(), DocumentoChunker, EstadoEvaluacion, ReportadorEvaluacion, ValidadorInputs, create_resultado_control_v13(), evaluar_control() (+4 more)

### Community 112 - "json"
Cohesion: 0.08
Nodes (12): EstadoEvaluacion, _enunciado_control(), evaluaciones_desde_controles(), descargar_acta_cierre(), agregar_personalizado(), borrar_personalizado(), _cuestionamientos_default(), _leer_json_seguro() (+4 more)

### Community 114 - "leer_estandares_virf"
Cohesion: 0.07
Nodes (4): leer_estandares_virf(), _estandar_es_reconstruccion(), TestElInformeDeclaraLaVersionDelEstandar, TestLectura

### Community 116 - "upload.py"
Cohesion: 0.06
Nodes (19): test_formatos_de_tarjeta(), test_upload_rechaza_extension_no_declarada(), arbol_inputs(), borrar_archivo(), _clasificacion_o_error(), _clasificar_estado(), listar_carpeta(), listar_destinos() (+11 more)

### Community 119 - "modulos/__init__.py"
Cohesion: 0.14
Nodes (3): docs(), _pdf(), test_informe_web_inserta_capturas()

### Community 120 - "Informe · Contrato ValidationReport"
Cohesion: 0.17
Nodes (15): desde_dict(), EstadoRequisito, intentar_validar(), validar_reporte(), _reporte_ok(), test_cita_ausente_falla(), test_confianza_fuera_de_rango_falla(), test_desviado_sin_codigo_falla() (+7 more)

### Community 121 - "pipeline_runner.py"
Cohesion: 0.09
Nodes (21): test_fase_no_se_engana_con_la_palabra_ambito(), test_lanzar_sin_evidencia_se_rechaza(), test_modelo_sin_evidencia_no_es_fallo_tecnico(), test_motivo_de_corrida_sin_actividades_evaluadas(), test_motivo_de_traceback_sin_marca(), test_motivo_y_pista_de_clave_rechazada(), cancelar_validacion(), _bombear_stdout() (+13 more)

### Community 123 - "test_solo_informe.py"
Cohesion: 0.09
Nodes (20): cliente(), _datos(), _o(), _png(), test_cumplimiento_por_ambito(), test_ficha_del_documento(), test_flujo_endpoints(), test_generar_sin_estandar_o_con_errores() (+12 more)

### Community 124 - "Chunker estructural"
Cohesion: 0.18
Nodes (11): _es_cerca(), _es_tabla(), segmentar_estructural(), _unidades(), test_bloque_atomico_mayor_que_el_tope_se_emite_entero(), test_ningun_segmento_corta_a_mitad_de_linea(), test_no_parte_la_formula_a_la_mitad(), test_no_parte_la_tabla_a_la_mitad() (+3 more)

### Community 131 - "Salvaguardas · Inyección de prompts"
Cohesion: 0.17
Nodes (12): contiene_inyeccion(), neutralizar(), sanear_salida(), _rep(), _patrones(), test_anular_hallazgos_se_neutraliza(), test_forzar_puntaje_se_neutraliza(), test_ignorar_instrucciones_se_neutraliza() (+4 more)

### Community 133 - "Identidad"
Cohesion: 0.17
Nodes (4): AsercionInvalida, Identidad, ProveedorSimulado, test_simulado_no_existe_fuera_de_tests()

### Community 134 - "Tests · Conexión Azure y parámetros"
Cohesion: 0.13
Nodes (4): _fabricar(), ClienteAzureFalso, _Completions, TestValidarConexionNegociaElParametroDeTokens

### Community 135 - "test_aprendizaje_controles.py"
Cohesion: 0.15
Nodes (18): cliente(), como(), _correr(), _df(), _excel_resultados(), _fila(), _info(), _libreria() (+10 more)

### Community 138 - "Tests · Automatizaciones"
Cohesion: 0.10
Nodes (7): TestCuadroAutomatizaciones, carpeta(), IAFalsa, _libro(), test_cuadro_con_ia_riesgo_desde_impactos(), test_ia_sin_json_falla_con_mensaje(), test_normalizar_riesgo()

### Community 139 - "revision_codigo.py"
Cohesion: 0.11
Nodes (3): HallazgoCodigo, _lenguaje_de(), _numerar_lineas()

### Community 141 - "VIRFAgent"
Cohesion: 0.13
Nodes (4): VIRFAgent, main(), test_flujo_completo(), _rep()

### Community 143 - "Exportador Excel"
Cohesion: 0.19
Nodes (10): a_bytes(), _docx_con(), test_familia_e_icono(), test_fichero_compuesto_con_muchos_flujos(), test_fichero_compuesto_grande_usa_difat(), test_office_moderno_va_nativo_y_el_resto_como_paquete(), test_paquete_ole_legible_y_con_el_archivo_intacto(), _tabla() (+2 more)

### Community 144 - "test_controles_ia.py"
Cohesion: 0.12
Nodes (17): parsear_describe(), _valor(), parsear_info(), _spans_cabecera(), cliente(), _df(), _info(), _perfil() (+9 more)

### Community 145 - "Datos · Perfilado de datasets"
Cohesion: 0.09
Nodes (9): _describir_rango(), documento_perfil(), _intentar_fechas(), perfilar_carpeta(), perfilar_dataframe(), perfilar_datasets(), PerfilColumna, PerfilDataset (+1 more)

### Community 146 - "Tests · DOCX de regresión"
Cohesion: 0.13
Nodes (15): ValidationReport, _agrupar_por_ambito(), _añadir_pie_con_paginacion(), generar_docx_validacion(), _run_campo(), _run_texto(), veredicto_de_ambito(), _reporte_mock() (+7 more)

### Community 147 - "Multimodelo · Raíz de evidencia"
Cohesion: 0.20
Nodes (3): _aplicar_raiz_evidencia(), redirigir_evidencia(), TestMultimodeloRaizDeEvidencia

### Community 148 - "Tests · Skills tipadas"
Cohesion: 0.10
Nodes (8): DeclaracionHerramienta, declaraciones_herramientas(), test_cada_skill_expone_declaracion_de_herramienta_valida(), test_consulta_fuera_de_alcance_dispara_abstencion_o_derivacion(), test_declaraciones_para_tools_es_serializable_json(), test_rubro_se_resuelve_desde_config_no_hardcode(), test_skills_no_operativas_declaran_pendiente_api(), test_una_skill_nunca_opina_del_dominio_de_otra()

### Community 150 - "test_owasp_llm.py"
Cohesion: 0.21
Nodes (12): _clave(), escribir_inventario_csv(), estado_fuente(), _fecha(), fuente_vencida(), FuenteInvalida, inventario(), _leer() (+4 more)

### Community 152 - "hashlib"
Cohesion: 0.19
Nodes (17): _anexar(), candidatos(), _canonico(), clave_leccion(), controles_para(), decidir(), dominio_canonico(), lecciones() (+9 more)

### Community 154 - "Tests · Cuestionamientos extensibles"
Cohesion: 0.11
Nodes (4): leer(), leer_entendimiento(), _leer_json_seguro(), TestCuestionamientosExtensibles

### Community 156 - "cablearSoloInforme"
Cohesion: 0.12
Nodes (33): cablearSoloInforme(), cablearSoloInformeIA(), entrarASoloInforme(), siAccionIA(), siCargarIA(), siClaveAmbito(), siClaveRiesgo(), siControl() (+25 more)

### Community 157 - "Tests · Subida ZIP (límites)"
Cohesion: 0.35
Nodes (9): ctx(), _extraidos(), _subir(), test_demasiadas_entradas_413(), test_tamano_declarado_excesivo_413(), test_zip_bomba_upload_pequeno_expansion_grande(), test_zip_normal_se_extrae(), test_zip_slip_rechazado() (+1 more)

### Community 159 - "test_auditoria.py"
Cohesion: 0.09
Nodes (18): leer(), ruta_log(), verificar(), main(), cliente(), _como(), _entradas(), test_borrar_una_linea_se_detecta() (+10 more)

### Community 160 - "test_gobierno_codigo.py"
Cohesion: 0.10
Nodes (13): invocar(), PermisoTool, _roles_de(), ToolDeshabilitada, ToolNoRegistrada, fb(), fuentes(), test_cargar_fuente_sin_dueno_o_vigencia_falla() (+5 more)

### Community 161 - "material_no_confiable"
Cohesion: 0.09
Nodes (15): llamar_ia(), material_no_confiable(), grabador(), _Grabador, _py_del_repo(), test_automatizaciones_delimita_excels_y_contexto(), test_cada_llamante_delimita_su_material(), test_consenso_sanea_una_vez_y_autoriza_cada_interno() (+7 more)

### Community 162 - "almacenamiento.py"
Cohesion: 0.19
Nodes (13): entorno_almacenamiento(), cifrado_disponible(), cifrar(), clasificacion_de(), ClasificacionInvalida, _clave(), descifrar(), entorno() (+5 more)

### Community 163 - "leer_resultados"
Cohesion: 0.14
Nodes (13): _a_fraccion(), _carpeta(), _columna_cumplimiento(), _escala_de_la_columna(), evaluaciones_desde_motores_entidad(), leer_resultados(), _tasa(), _leer_tabla() (+5 more)

### Community 165 - "test_almacenamiento.py"
Cohesion: 0.13
Nodes (12): dias_retencion(), borrado_seguro(), purgar_vencidos(), cliente(), _subir(), test_borrado_seguro_sobrescribe_antes_de_borrar(), test_retencion_configurable(), test_sin_clave_no_se_escribe_en_claro() (+4 more)

### Community 167 - "TestAuditoriaEntornoCorporativo"
Cohesion: 0.17
Nodes (3): _diagnostico_filtro(), _extraer_categorias(), TestAuditoriaEntornoCorporativo

### Community 168 - "construir_notebook"
Cohesion: 0.12
Nodes (12): _celda_md(), _celda_repositorio(), _code(), columnas_de_tipo(), _columnas_usadas(), construir_notebook(), _fuente_repositorio(), _literal_seguro() (+4 more)

### Community 169 - "test_ejecucion_codigo.py"
Cohesion: 0.09
Nodes (17): cargar_controles(), _extraer_meta(), construir(), _defecto(), _endpoints(), main(), _patron_legible(), _repositorio() (+9 more)

### Community 171 - "solo_informe_ia.py"
Cohesion: 0.07
Nodes (34): TestSoloInforme, test_busqueda_no_repite_bloques_de_plantilla(), test_desde_manuales_cita_fuentes(), test_manual_formato_no_admitido(), test_manual_fragmentos_con_pagina_y_busqueda(), borrar_manual(), manuales(), _adaptar_con_ia() (+26 more)

### Community 174 - "test_revision_sesion.py"
Cohesion: 0.12
Nodes (10): chat(), _ctx(), _datos(), _escribir_corrida(), test_agente_salida_reapunta_outputs(), test_decision_explicita(), test_detecta_el_json_nuevo_en_cualquier_fecha_y_si_se_reescribe(), test_endpoint_documento_de_la_corrida() (+2 more)

### Community 175 - "verificacion_cifras.py"
Cohesion: 0.14
Nodes (7): cifras_ausentes(), es_sentinela(), _formas(), _significativa(), sin_cita_literal(), ventana_relevante(), TestVerificacionCifras

### Community 176 - "pedirJSON"
Cohesion: 0.20
Nodes (25): abrirCuestionamientos(), agregarCuestCustom(), agregarSkillCustom(), borrarDominio(), borrarPaperRag(), cablearCuestionamientos(), cablearRagDominio(), cargarCuestionamientos() (+17 more)

### Community 177 - "test_roles.py"
Cohesion: 0.13
Nodes (12): cliente(), _como(), fb(), _ident(), test_admin_pasa_el_control_de_rol(), test_corpus_compartido_solo_admin(), test_editar_prompts_solo_admin(), test_lanzar_validacion_exige_rol_validador() (+4 more)

### Community 178 - "consolidar_decisiones"
Cohesion: 0.13
Nodes (10): consolidar_decisiones(), _indexar_decisiones(), _norm(), tabla_final(), valor_cumple(), _datos(), _fn(), TestConsolidar (+2 more)

### Community 181 - "AST"
Cohesion: 0.19
Nodes (19): construir(), _esc(), main(), _menu(), _opciones_cli(), _parametros(), _ast(), dependencias() (+11 more)

### Community 182 - "test_virf_plus.py"
Cohesion: 0.13
Nodes (10): _consenso(), Doble, sdk_openai_falso(), test_arbitro_claude_opcional(), test_arbitro_recibe_ambas_opiniones_y_discrepancias(), test_bitacora_registra_cada_conciliacion(), __init__(), test_modo_discrepancia_ahorra_arbitro_y_vale_gpt() (+2 more)

### Community 183 - "WorkflowManager"
Cohesion: 0.07
Nodes (4): WorkflowContext, WorkflowManager, WorkflowMetrics, WorkflowState

### Community 184 - "test_rag_banco.py"
Cohesion: 0.10
Nodes (8): evaluar(), main(), get_buscador(), corpus(), _RetrieverFalso, test_el_corpus_del_repo_esta_al_dia(), test_preguntas_oro_del_banco(), test_reindexado_y_subida_lo_conocen()

### Community 189 - "Doble"
Cohesion: 0.16
Nodes (12): _consenso(), Doble, _espia(), test_arbitro_sano_sigue_decidiendo(), test_cada_proveedor_deja_su_entrada_de_auditoria_y_el_coste_no_se_duplica(), test_el_compuesto_no_factura_tokens_propios(), test_nunca_se_concluye_con_un_solo_evaluador(), test_si_el_arbitro_falla_gana_la_opinion_mas_conservadora() (+4 more)

### Community 191 - "diagnosticar"
Cohesion: 0.31
Nodes (13): diagnosticar(), _estados(), _fabrica(), _ok_json(), test_clave_rechazada_es_capa_5(), test_deployment_inexistente_es_capa_6(), test_endpoint_ajeno_es_capa_2(), test_respuesta_no_json_es_capa_7() (+5 more)

### Community 193 - "estandares.py"
Cohesion: 0.18
Nodes (7): borrar(), confirmar(), descartar_pendiente(), get_detalle(), get_estado(), get_vista_previa(), upload()

### Community 194 - "20261118_antes_rediseno/static/js/guia.js"
Cohesion: 0.23
Nodes (22): abrirGuia(), AYUDA, barraHtml(), botonQ(), cerrarGuia(), construirGuia(), dashboardVisible(), _e() (+14 more)

### Community 199 - "escapeHtml"
Cohesion: 0.17
Nodes (24): borrarDominio(), borrarPaperRag(), cablearCard(), cablearRagDominio(), cargarRagDominios(), clasifSubida(), crearDominio(), escapeHtml() (+16 more)

### Community 200 - "completa.js"
Cohesion: 0.20
Nodes (25): abrirEtapa(), abrirInsumos(), alternarModalidad(), cablearCompleta(), pintarModalidad(), VC, VC_TIPO, vcAgregar() (+17 more)

### Community 201 - "estado"
Cohesion: 0.18
Nodes (8): TestPersistencia, TestTolerante, avisos_para_tier(), confirmar(), estado(), guardar_xlsx(), _normalizar_marca(), vista_previa()

### Community 202 - "evidencia_sesion.py"
Cohesion: 0.18
Nodes (8): _archivos(), bloque_para_prompt(), buscar(), _fragmentar(), fragmentos(), _huella(), _indice_path(), _leer()

### Community 203 - "generar_informe_md"
Cohesion: 0.11
Nodes (13): _cabecera(), _como_leer(), _firma_agente(), generar_informe_md(), _inconsistencias(), _limitaciones(), _metodologia(), _pedidos() (+5 more)

### Community 204 - "cuestionamientos_ext.py"
Cohesion: 0.29
Nodes (4): catalogo_activo(), _leer(), _traducir_personalizado(), _valida_regex()

### Community 205 - "Acta de cierre (Excel)"
Cohesion: 0.23
Nodes (10): acta_cierre_bytes(), _aplica(), construir_libro(), _norm_act(), test_acta_hoja_decisiones_lista_cada_veredicto(), test_acta_marca_decision_en_filas_cambiadas(), test_acta_resumen_puntaje_sube_con_aprobado(), test_acta_tiene_tres_hojas_y_columnas() (+2 more)

### Community 206 - "test_aprendizaje_chat.py"
Cohesion: 0.13
Nodes (14): _corr(), _datos(), feedback_aislado(), test_aprobado_se_guarda_como_correccion(), test_autoaprobacion_bloqueada_por_nombre_si_falta_oid(), test_bloque_aprendizaje_exige_masa_critica(), test_bloque_aprendizaje_ignora_feedback_sin_aprobar(), test_chat_guarda_oid_y_bloquea_autoaprobacion() (+6 more)

### Community 208 - "openpyxl"
Cohesion: 0.14
Nodes (6): actualizar_estandares_con_version(), _crear_xlsx_estandar(), ctx_de_prueba(), TestParseo, _xlsx_con_titulo(), parsear()

### Community 209 - "test_validacion_completa.py"
Cohesion: 0.11
Nodes (10): ClienteFalso, dirs(), _ejecutar_notebook(), _excel_resultado(), test_02_dos_pasadas_contexto_y_notebook_de_la_ia(), test_anexo_del_informe_con_imagenes(), test_endpoints(), test_error_de_sintaxis_se_repara() (+2 more)

### Community 213 - "response_evaluator.py"
Cohesion: 0.10
Nodes (4): ConfidenceScorer, GroundingChecker, HallucinationChecker, ResponseEvaluator

### Community 214 - "Tests · Anexo de correcciones"
Cohesion: 0.06
Nodes (18): cargo_de(), _es_error(), _generar_recomendacion_automatica(), generar_word_informe(), conclusion_extra(), detalle_control(), escala(), guardar_calidad_proceso() (+10 more)

### Community 215 - "Fixtures · Modelo sintético Fraude/AML"
Cohesion: 0.22
Nodes (3): aplicar_reglas(), generar_alertas(), score_anomalia()

### Community 217 - "verificar_remoto_git.py"
Cohesion: 0.10
Nodes (20): repo_corporativo(), _archivos(), _describir(), _limpiar(), main(), host_de(), main(), no_autorizados() (+12 more)

### Community 218 - "test_controles_bateria_tipo_modelo.py"
Cohesion: 0.23
Nodes (12): _alm_df(), _correr(), _info(), _libreria(), _perfil(), test_controles_de_otros_notebooks_se_adaptan_sin_reescribirlos(), test_el_catalogo_crecio_y_cada_tipo_tiene_funcion(), test_la_bateria_cubre_todas_las_columnas_y_la_cobertura_todos_los_tipos() (+4 more)

### Community 219 - "Frontend · Estándares"
Cohesion: 0.28
Nodes (13): abrirEstandares(), aceptarEstandares(), cablearEstandares(), cambiarArchivoEstandares(), estAvisosHtml(), estOrigenHtml(), mostrarErrorEstandares(), pintarEstandaresConfirmado() (+5 more)

### Community 220 - "test_corrida_fallida.py"
Cohesion: 0.13
Nodes (10): _resumen(), _Cliente, test_borrador_markdown_con_todos_los_ambitos_sin_puntaje(), test_borrador_markdown_ordena_los_no_evaluados_al_final(), test_cada_script_compila(), test_clave_rechazada_se_detecta_en_el_arranque_con_su_motivo(), test_codigo_de_salida_de_la_corrida(), test_el_arranque_no_dice_ok_sin_haber_verificado() (+2 more)

### Community 221 - "Análisis estático · Contraste doc vs código"
Cohesion: 0.29
Nodes (3): _contrastar(), _norm(), _numero_en_texto()

### Community 226 - "test_verificacion_citas.py"
Cohesion: 0.09
Nodes (17): _verificar_citas(), verificar_referencia_manual(), TestCitasPipeline, TestComillasSimples, _dudosas(), test_cita_con_elision_se_verifica_tramo_a_tramo(), test_cita_corta_sigue_sin_examinarse(), test_cita_cortada_a_media_frase_y_cerrada_con_punto_se_verifica() (+9 more)

### Community 231 - "test_calidad_e2e.py"
Cohesion: 0.11
Nodes (9): consolidar(), _hash(), _leer(), registrar(), _ruta(), verificar(), ee(), test_oportunidades_de_mejora_no_tocan_el_core() (+1 more)

### Community 233 - "Frontend · Lanzar validación"
Cohesion: 0.44
Nodes (9): actualizarEstadoUI(), cablearValidacion(), cancelarValidacion(), conectarWebSocket(), lanzarValidacion(), pintarLinea(), pintarMotivoCorrida(), pintarPrecondiciones() (+1 more)

### Community 234 - "arrancar"
Cohesion: 0.16
Nodes (18): abrirModalNuevoModelo(), arrancar(), cablearAuth(), cablearDominio(), cablearDropzone(), cargarDominiosEnSelectorModelo(), cargarVirfPlus(), cerrarModalNuevoModelo() (+10 more)

### Community 235 - "generar_corpus_banco.py"
Cohesion: 0.36
Nodes (7): doc_controles(), doc_estandar(), doc_procedimiento(), doc_reglas(), _escribir(), generar(), _huella()

### Community 236 - "custodia.py"
Cohesion: 0.05
Nodes (20): _hash_cadena(), imprimir_cadena(), imprimir_evidencia(), informes_de_modelo(), preservar_si_existe(), _ruta_lock(), sellar(), sellar_y_escribir() (+12 more)

### Community 237 - "test_casos_borde.py"
Cohesion: 0.13
Nodes (15): _cliente_simulado(), ejecutar(), main(), _leer(), test_archivo_enorme_no_revienta_y_declara_tamano(), test_archivo_vacio(), test_codificaciones_raras(), test_excel_corrupto() (+7 more)

### Community 238 - "conftest.py"
Cohesion: 0.15
Nodes (7): _aprendizaje_controles_aislado(), firmar_como(), _firmar(), _registro_emisiones_aislado(), _secretos_de_test(), simular_aprobacion(), _virf_plus_aislado()

### Community 239 - "test_owasp_llm.py"
Cohesion: 0.08
Nodes (12): cliente_dedicado(), ClienteAnthropicIA, ClienteIA, _instanciar(), _enviar(), _Espia, test_abuso_de_tools_bloqueado(), test_afirmacion_sin_respaldo_no_llega_al_informe() (+4 more)

### Community 240 - "controles.py"
Cohesion: 0.09
Nodes (21): perfil_dataset(), catalogo(), _DatasetPegado, _DecisionLeccion, descargar_notebook_controles(), _dir_ia(), _doc_controles_de_sesion(), _entendimiento_del_modelo() (+13 more)

### Community 241 - "test_hallazgos_completa.py"
Cohesion: 0.17
Nodes (9): ClientePorIteracion, dirs(), _dos_iteraciones(), _excel(), test_cada_etapa_entrega_excel_y_md_con_todos_sus_hallazgos(), test_el_consolidado_lee_los_excel_y_md_y_avisa_las_inconsistencias(), test_el_cuadro_y_el_informe_leen_los_entregables(), test_endpoints_de_hallazgos_y_consolidado() (+1 more)

### Community 242 - "red.py"
Cohesion: 0.13
Nodes (8): cliente_http(), con_reintento(), contexto_almacen_sistema(), diagnostico_https(), es_transitorio(), espera_sugerida(), HostNoPermitido, test_almacen_del_sistema_usa_truststore()

### Community 246 - "reconstruir_estandar_desde_informes.py"
Cohesion: 0.19
Nodes (5): escribir(), extraer(), filas(), main(), _norm()

### Community 247 - "test_usuario_libre.py"
Cohesion: 0.17
Nodes (9): _aislar(), cliente_libre(), _entrar(), test_identidad_libre_rechaza_datos_invalidos(), test_login_libre_crea_sesion_marcada(), test_login_libre_queda_en_la_auditoria(), test_login_libre_respeta_roles(), test_sin_declarar_libre_el_endpoint_no_existe() (+1 more)

### Community 248 - "calcular"
Cohesion: 0.27
Nodes (3): TestPresupuestoService, aplicar_env(), calcular()

### Community 251 - "test_estudio_insumos.py"
Cohesion: 0.15
Nodes (6): prioridad(), ClienteEstudio, inputs(), test_fallo_de_ia_deja_ficha_determinista(), test_ia_lee_el_manual_entero_por_partes_y_cachea(), test_texto_para_prompt_prioriza_la_etapa_y_respeta_el_tope()

### Community 253 - "mostrarVista"
Cohesion: 0.18
Nodes (15): abrirDominioRag(), abrirSkills(), analizarCodigo(), cablearCrearDominio(), cablearEntendimiento(), cablearNav(), cargarEntendimiento(), ejecutarPrevuelo() (+7 more)

### Community 255 - "agente.py"
Cohesion: 0.03
Nodes (70): _modelo_ia_real(), _proveedor_ia_real(), _setup_env_si_falta(), evaluar_dimension(), autorizar_proveedor(), _credenciales_completas(), _en_produccion(), generar_mensaje() (+62 more)

### Community 256 - "unicodedata"
Cohesion: 0.13
Nodes (11): test_borrador_antiguo_con_un_solo_sustento_sigue_valiendo(), test_imagen_rechaza_extension_y_id_invalido(), ver_imagen(), normalizar_sustentos(), ruta_imagen(), sustentos_de(), a_plantilla(), _limitaciones() (+3 more)

### Community 259 - "test_clasificacion_docx.py"
Cohesion: 0.14
Nodes (13): clasificacion_informe(), aplicar(), etiqueta_por_defecto(), _pies(), pies_sin_etiqueta(), _guardados_de_docx(), _inf(), test_clasificacion_parametrizable() (+5 more)

### Community 260 - "test_databricks_minimo_dato.py"
Cohesion: 0.18
Nodes (8): cargar_datasets_uc(), LecturaNoMinima, _Spark, test_guia_sin_token_personal_ni_lectura_completa(), test_lectura_minima_empuja_columnas_filtro_y_limite(), test_lecturas_no_minimas_se_rechazan(), test_limite_explicito_se_respeta(), test_ningun_topandas_sin_select_y_filtro_en_el_codigo()

### Community 261 - "_caption"
Cohesion: 0.25
Nodes (6): _adjuntos(), _imagen(), _sustento(), _sustentos_de(), _tamano(), _un_sustento()

### Community 287 - "es_de_entorno_virtual"
Cohesion: 0.06
Nodes (10): es_de_entorno_virtual(), _es_entorno(), _entorno_falso(), test_codigo_del_proyecto_no_se_confunde_con_entorno(), test_entorno_con_nombre_arbitrario_se_reconoce(), test_site_packages_se_reconoce(), TestAuditoriaConsistenciaCruzada, dfs() (+2 more)

### Community 288 - "test_costes.py"
Cohesion: 0.11
Nodes (14): precio_salida_por_mtok(), agregar(), _csv(), generar(), llamadas(), p95(), concordancia(), guardar_resultado() (+6 more)

### Community 290 - "adjuntos_ole.py"
Cohesion: 0.11
Nodes (14): _ansi(), _arbol(), construir(), descripcion(), _entrada(), familia(), fichero_compuesto(), _fuente() (+6 more)

### Community 291 - "generar_kit.py"
Cohesion: 0.23
Nodes (4): excel(), hacer_estandar(), marcas(), pdf_texto()

### Community 304 - "revisar_resultados"
Cohesion: 0.09
Nodes (12): _comentado(), leer_anexos(), leer_tabla_resultados(), revisar_resultados(), _riesgo(), validar_params(), llamar_ia_controles(), test_parametros_de_los_tipos_nuevos_se_validan() (+4 more)

### Community 306 - "_leer_cache_cifrada"
Cohesion: 0.18
Nodes (4): _leer_cache_cifrada(), test_cache_cifrada_en_disco_e_ilegible_sin_clave(), TestCache, escribir()

### Community 307 - "pandas"
Cohesion: 0.13
Nodes (8): cargar_actividades_por_tier(), _limpiar_str(), cargar(), depurar(), aplicar_woe(), calcular_score(), decidir(), ejecutar()

### Community 309 - "abrirChat"
Cohesion: 0.24
Nodes (13): abrirChat(), adjuntarEvidenciaChat(), cablearChat(), cargarListaInformesChat(), conectarChatWS(), consolidarChat(), descargarActaCierre(), enviarChat() (+5 more)

### Community 310 - "os"
Cohesion: 0.04
Nodes (30): identidad_autenticada(), max_tokens_declarado(), modelo_declarado(), precio_entrada_por_mtok(), _booleano(), _decimal(), _num_env(), ruta_log_auditoria() (+22 more)

### Community 313 - "test_identidad.py"
Cohesion: 0.10
Nodes (20): _b64(), _clave(), emitir_asercion(), _unb64(), verificar_asercion(), _clave_firma(), cliente(), _entrar() (+12 more)

### Community 315 - "abrirConfiguracion"
Cohesion: 0.26
Nodes (12): abrirConfiguracion(), abrirModal(), alternarVirfPlus(), cablearConfig(), cerrarModal(), guardarConfig(), guardarVirfPlus(), pintarContextoSidebar() (+4 more)

### Community 316 - "construir_args"
Cohesion: 0.18
Nodes (5): redirigir_estandar(), TestCliFlagEstandares, test_runner_no_pasa_firmante_por_argumentos(), test_runner_pasa_salida_de_la_sesion_y_codigo_de_modelo(), construir_args()

### Community 317 - "arrancar"
Cohesion: 0.12
Nodes (27): abrirConfiguracion(), abrirModal(), abrirModalNuevoModelo(), alternarVirfPlus(), arrancar(), cablearAuth(), cablearConfig(), cablearDominio() (+19 more)

### Community 319 - "reproducir_corrida.py"
Cohesion: 0.12
Nodes (6): armar_sesion(), hijo(), IAFalsa, main(), main(), preparar_entorno()

### Community 322 - "test_proveedor_gpt.py"
Cohesion: 0.25
Nodes (5): _recargar_mx00(), test_dry_run_estima_con_el_modelo_que_corre(), test_modelo_y_tope_son_los_del_proveedor_declarado(), test_mx03_deja_que_el_cliente_ponga_su_tope(), test_respaldo_del_modelo_real_no_revienta()

### Community 323 - "test_revision_validador.py"
Cohesion: 0.31
Nodes (5): ctx(), _sesion(), test_guia_cuenta_el_paso_09(), test_reescribir_reabre_la_conformidad(), test_resumen_y_conformidad()

### Community 325 - "test_guias_generadas.py"
Cohesion: 0.32
Nodes (3): _generador(), test_la_guia_esta_al_dia(), test_un_tipo_sin_explicar_hace_fallar_la_guia()

### Community 327 - "hooks"
Cohesion: 0.20
Nodes (9): always_run, entry, id, language, name, pass_filenames, repos, hooks (+1 more)

### Community 328 - "refrescarCard"
Cohesion: 0.27
Nodes (10): cablearCard(), clasifSubida(), iconoEstado(), logSubida(), refrescarCard(), renderCardHTML(), renderRagDominioHTML(), renderUploadCards() (+2 more)

### Community 330 - "escanear_secretos.py"
Cohesion: 0.40
Nodes (7): _archivos(), escanear_arbol(), escanear_historial(), escanear_texto(), _git(), main(), _recortar()

### Community 331 - "solicitar_identidad"
Cohesion: 0.24
Nodes (8): _firmante_opcional(), _ficha(), IdentidadRequerida, solicitar_identidad(), test_asercion_falsa_en_el_entorno_no_firma(), test_firmante_es_la_identidad_autenticada(), test_no_se_puede_teclear_otro_firmante(), test_sin_sesion_el_pipeline_no_firma()

### Community 335 - "test_rag_desactualizado.py"
Cohesion: 0.36
Nodes (6): _set(), test_indice_ausente_con_papers_es_desactualizado(), test_indice_mas_nuevo_esta_al_dia(), test_readme_y_dotfiles_no_cuentan(), test_source_mas_nuevo_marca_desactualizado(), _esta_desactualizado()

### Community 336 - "siAccionIA"
Cohesion: 0.22
Nodes (11): cablearSoloInformeIA(), siAccionIA(), siCargarIA(), siControl(), siFijarTexto(), siMostrarPropuesta(), siPintarEstadoIA(), siPintarManuales() (+3 more)

### Community 337 - "TestAuditoriaRespuestaVaciaDeLaAPI"
Cohesion: 0.36
Nodes (3): TestAuditoriaRespuestaVaciaDeLaAPI, _BloqueSinTexto, _RespuestaVacia

### Community 338 - "abrirEstandares"
Cohesion: 0.33
Nodes (9): abrirEstandares(), aceptarEstandares(), cablearEstandares(), cambiarArchivoEstandares(), pintarEstandaresConfirmado(), pintarPreviewEstandares(), resetEstandaresUI(), subirEstandares() (+1 more)

### Community 339 - "test_plantilla_bcp.py"
Cohesion: 0.36
Nodes (6): _esqueleto_ok(), _sesion_chat(), test_entregable_pipeline_con_plantilla(), test_informe_web_con_plantilla(), test_plantilla_minima_y_anexos(), _texto()

### Community 342 - "ui.js"
Cohesion: 0.33
Nodes (7): aplicarTema(), botonTema(), contar(), mejorarTabla(), opciones(), textoAcepta(), zona()

### Community 343 - "cablearValidacion"
Cohesion: 0.46
Nodes (8): actualizarEstadoUI(), cablearValidacion(), cancelarValidacion(), conectarWebSocket(), lanzarValidacion(), pintarLinea(), pintarPrecondiciones(), precondicionesValidacion()

### Community 350 - "leer_archivo"
Cohesion: 0.18
Nodes (6): get_cache(), cargar_todos_inputs(), get_cache(), leer_archivo(), leer_carpeta(), leer_repositorio_informes()

### Community 351 - "verificar_corpus_rag.py"
Cohesion: 0.29
Nodes (5): _ficheros_esperados(), main(), _norm(), verificar_dominio(), verificar_informe()

### Community 352 - "word_estilo.py"
Cohesion: 0.08
Nodes (14): add_bloque_codigo(), add_codigo_inline(), add_nota_pie(), aplicar_estilo_documento(), _asegurar_estilos_nota(), _asegurar_parte_footnotes(), _borde(), _FootnotesPart (+6 more)

### Community 353 - "sesion_activa"
Cohesion: 0.08
Nodes (26): _ctx(), _datos(), test_adjuntar_enriquece_evidencia_y_reevalua(), test_adjuntar_sin_texto_falla(), _aprobado(), chat(), _datos(), test_cifra_inventada_degrada_el_aprobado() (+18 more)

### Community 356 - "ejecutar_motor"
Cohesion: 0.25
Nodes (3): ejecutar_motor(), motores_disponibles(), TestMotoresDatos

### Community 357 - "test_endpoint_notebook_controles.py"
Cohesion: 0.25
Nodes (4): _get_notebook(), make_ctx(), test_endpoint_fallback_llm_sin_repositorio(), test_endpoint_repositorio_dominio()

### Community 370 - "comparar_doc_y_codigo"
Cohesion: 0.20
Nodes (5): comparar_doc_y_codigo(), extraer_clases_python(), extraer_funciones_python(), extraer_imports(), extraer_palabras_clave_doc()

### Community 387 - "FeedbackStore"
Cohesion: 0.17
Nodes (3): FeedbackStore, main(), orquestar_pipeline_virf()

### Community 406 - "comparar_respuestas"
Cohesion: 0.22
Nodes (6): _campos_decision(), comparar_respuestas(), _normalizar(), test_puntajes_3_y_3_0_no_son_una_discrepancia(), test_comparar_acuerdo_ignora_redaccion(), test_comparar_detecta_discrepancia_de_puntaje()

### Community 407 - "inicializar_cache"
Cohesion: 0.20
Nodes (3): inicializar_cache(), _reset_cierre_para_tests(), TestAuditoriaCachePersisteEnSalidasTempranas

### Community 411 - "exigir_permitido"
Cohesion: 0.29
Nodes (5): AlmacenamientoNoPermitido, exigir_permitido(), test_restringido_en_entorno_aprobado_pasa(), test_restringido_en_portatil_falla(), test_sin_clasificacion_valida_se_rechaza()

### Community 415 - "fabricas"
Cohesion: 0.29
Nodes (4): fabricas(), _fabrica(), _crear(), _limpio()

### Community 419 - "_json_laxo"
Cohesion: 0.40
Nodes (4): _json_laxo(), _json_laxo(), _normalizar_salida(), _txt()

### Community 422 - "test_certificado_corporativo_es_capa_4_y_no_desactiva_tls"
Cohesion: 0.50
Nodes (4): fabrica(), manejar(), test_certificado_corporativo_es_capa_4_y_no_desactiva_tls(), fabrica()

## Knowledge Gaps
- **212 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `TestParserEstandares` connect `TestParserEstandares` to `leer_estandares_virf`, `Tests · Anexo de correcciones`?**
  _High betweenness centrality (0.021) - this node is a cross-community bridge._
- **Should `.get_conversation_history` be split into smaller, more focused modules?**
  _Cohesion score 0.1111111111111111 - nodes in this community are weakly interconnected._
- **Why does `TestReintentoContrato` connect `Tests · Reintento de contrato` to `Custodia · Registro de emisiones`?**
  _High betweenness centrality (0.020) - this node is a cross-community bridge._
- **Should `AgentOrchestrator` be split into smaller, more focused modules?**
  _Cohesion score 0.10967741935483871 - nodes in this community are weakly interconnected._
- **Why does `ejecutar_prevuelo()` connect `Prevuelo · Chequeo previo de evidencia` to `prevuelo`, `app.py`, `Motor IA · Scores y semáforo`, `Tests · Anexo de correcciones`, `formatear`, `leer_archivo`, `agente.py`?**
  _High betweenness centrality (0.016) - this node is a cross-community bridge._
- **Should `app.py` be split into smaller, more focused modules?**
  _Cohesion score 0.03791208791208791 - nodes in this community are weakly interconnected._
- **Should `controles_ia.py` be split into smaller, more focused modules?**
  _Cohesion score 0.08503401360544217 - nodes in this community are weakly interconnected._