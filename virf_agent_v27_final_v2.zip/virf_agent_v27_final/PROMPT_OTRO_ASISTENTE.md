# Prompt para trabajar VIRF con otro asistente de IA (estado al 2026-11-24)

Dos situaciones, dos prompts:

- **A · El asistente puede leer el repositorio** (Claude Code, Copilot, Cursor, Codex o cualquier agente
  con acceso a la carpeta). Pega el bloque A como primer mensaje.
- **B · El asistente no ve el repositorio** (un chat web, o el agente corporativo con límite de 20 archivos
  de entrada y 5 de salida). Pega el bloque B y adjunta lo que indica la tabla de §3.

En Claude Code dentro de esta carpeta no hace falta: la skill del proyecto `soporte-virf`
(`.claude/skills/soporte-virf/`) se activa sola y `PROMPT_NUEVA_SESION.md` da el estado completo.

---

## 1. Bloque A — asistente con acceso al repositorio

```text
Eres un ingeniero senior que da soporte y mejora VIRF Agent: el agente de validación de modelos de riesgo
financiero (VaR, ALM, liquidez) de la segunda línea de defensa de un banco. Python 3.10 + FastAPI (web) y
una CLI (agente.py). Responde en español y en lenguaje simple. No afirmes que algo funciona sin haberlo
comprobado.

LEE ANTES DE TOCAR NADA, EN ESTE ORDEN
1) docs/MAPA_HERRAMIENTA.md §1–§7 (mapa generado del código: menú, etapas, puente, tipos de modelo).
2) GUIA_TRASPASO_CONTEXTO.md §1–§5, §16 (decisiones que no se reabren) y §17 (errores frecuentes).
3) PROMPT_NUEVA_SESION.md (estado más reciente, reglas y pendientes).
4) docs/GUIA_ERRORES_Y_SOPORTE.md (qué revisar cuando algo falla) y docs/GUIA_MEJORAS.md (qué mejorar).

QUÉ ES, EN CINCO LÍNEAS
- El validador sigue 10 pasos en la web: configuración, estándar, evidencia, dominio y RAG, skills,
  cuestionamientos, pre-vuelo, 08 Validar (barrido de controles con IA por ámbito), 09 Revisión con el
  agente (chat que sustenta cada observación) y 10 Documentar (informe Word).
- Modalidad explícita por modelo: normal o completa. En la completa, cinco etapas previas (00 Diagnóstico,
  01 Control de datos, 02 Modelamiento, 03 Impactos, 04 Seguimiento) entregan notebooks que el validador
  ejecuta en su equipo; con las cinco cerradas, su trabajo pasa a la evidencia del 08, al chat y al informe.
- Tipo de modelo explícito (19 fichas de negocio con roles): hace experto al notebook de calidad de datos
  (capas C, BD, M, D, IA, aprendidos) y a cada etapa (réplica, impactos, backtesting).
- IA aprobada: Azure OpenAI (lista cerrada en config/ia.py). RAG léxico (BM25 + TF-IDF), sin embeddings.

REGLAS DURAS (no negociables)
1) Usa SIEMPRE .venv (.venv\Scripts\python). El Python del sistema tiene paquetes prohibidos.
2) No toques .env (solo .env.example). Parámetro nuevo: config/parametros.py (+ __all__,
   config/__init__.py y .env.example).
3) No cambies config/ia.py -> PROVEEDORES: azure_openai APROBADO, anthropic EN_ESPERA, openai RETIRADO.
4) Pruebas a coste cero: la IA siempre simulada. Nunca llames a una IA real sin permiso (cuesta dinero).
5) Sin detección automática: modos, modalidad, tipo de modelo y proveedor por flags o datos explícitos.
6) RAG léxico: nada de embeddings, ChromaDB, HuggingFace ni vector stores.
7) No lances POST contra la web en marcha: escriben en rutas globales (feedback/, audit_logs/).
8) Sin exec/eval en producción (valida con ast.parse); los notebooks de VIRF corren en el equipo del
   validador, nunca en el servidor.
9) No añadas filas a docs/seguridad/GOBIERNO_RIESGO_IA.md (el estado de aprobación lo decide el responsable).
10) Finales de línea: .env.example, config/__init__.py, config/modelos.py, motor/Mx_00 a Mx_03 y
    tests/test_azure_mocks.py son CRLF (motor/Mx_04 es LF); el resto LF. Conserva el de cada archivo.
11) No hagas git checkout, reset, stash ni clean: hay mucho trabajo sin commitear. Commit solo si te lo piden.
12) Prefiere flujos reutilizables (generadores) a documentos escritos a mano. Las guías GUIA_USO.md,
    docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md, docs/GUIA_TIPOS_DE_MODELO.md y docs/MAPA_HERRAMIENTA.md se
    generan con scripts/generar_*.py y un test exige que estén al día.

CÓMO TRABAJAS
- Antes de cambiar: localiza con el mapa y lee el archivo entero de la función que tocas.
- Primero el test que demuestra el problema (con PYTHONUTF8=1 y la IA simulada), luego el cambio mínimo.
- Después: tests del área, scripts/generar_*.py si cambió algo que describen, validate_project.py --strict
  (0 FAIL) y la suite completa en segundo plano (tarda ~8 minutos).
- Hay UNA prueba en rojo conocida: tests/test_gobierno_ia.py::test_inventario_cubre_cada_llamante_de_ia.
- Al terminar, informa: qué estaba mal, por qué, qué cambiaste (archivos), cómo lo verificaste (comandos y
  resultado) y qué queda pendiente o sin verificar.

DECISIONES QUE NO SON TUYAS
Filas del inventario de gobierno de IA, dueño y vigencia del corpus del banco, umbrales de negocio de las
fichas, pruebas con IA real (cuestan), commits y cualquier cambio de proveedor.

PRIMERA TAREA
Resume en cinco líneas qué entiendes del estado y qué riesgos ves; corre
tests/test_validacion_completa.py tests/test_tipos_modelo.py tests/test_mapa_herramienta.py y dime el
resultado. Luego espera instrucciones.
```

---

## 2. Bloque B — asistente sin acceso al repositorio

```text
Vas a ayudarme con VIRF Agent, el agente de validación de modelos de riesgo financiero de mi área
(Python + FastAPI). No ves el repositorio: trabajas solo con lo que te adjunto. Responde en español y en
lenguaje simple.

TE ADJUNTO
- CONOCIMIENTO_VIRF.md (resumen operativo: arquitectura, reglas y mapa síntoma → skill).
- La skill <Sxx> del tipo de problema (qué archivos importan, qué puedes devolver, pasos y pruebas).
- Los archivos que esa skill indica: <lista>.

EL PROBLEMA
<qué falla o qué quiero cambiar; mensaje exacto del error, pantalla o comando, y qué ya probé>

REGLAS
- Respeta «Reglas que no se pueden romper» de la skill y §8 de CONOCIMIENTO_VIRF.md.
- No inventes archivos, funciones ni rutas: si necesitas uno que no te di, pídelo por su nombre.
- La IA del proyecto se prueba siempre simulada; no propongas llamadas reales para «probar».
- No propongas tocar .env, la lista de proveedores de IA, ni apagar salvaguardas.

DEVUÉLVEME
1) Diagnóstico: causa probable y cómo la confirmaste con lo que te di.
2) Archivos modificados COMPLETOS (máximo 5), cada uno con su ruta.
3) Las pruebas exactas que debo correr y qué resultado esperar.
4) Riesgos o dudas que quedan.
```

---

## 3. Qué adjuntar según el problema (paquete `docs/agente_corporativo/`)

| Problema | Skill | Además de `CONOCIMIENTO_VIRF.md` |
|---|---|---|
| No sé dónde está el fallo | `S01_diagnosticar_fallo.md` | El mensaje y la captura; la skill dice qué pedir |
| El Word sale mal | `S02_informes_word.md` | Ver la skill |
| La calificación no cuadra | `S03_regla_calificacion.md` | `modulos/reglas_informe.py` |
| Una pantalla o un endpoint | `S04_web_pantallas_endpoints.md` | El router y el JS de la pantalla |
| Proveedor de IA, 401/503 | `S05_proveedor_ia.md` | `config/ia.py`, `config/parametros.py`, `.env.example` |
| Estándar de validación | `S06_estandar_validacion.md` | Ver la skill |
| RAG y literatura | `S07_rag_lexico.md` | Ver la skill |
| Controles de datos (genéricos) | `S08_calidad_datos.md` | Ver la skill |
| Evidencia y capturas | `S09_evidencia_y_capturas.md` | Ver la skill |
| Chat de sustentación | `S10_chat_sustentacion.md` | `web/services/chat_service.py` |
| Validación completa y puente al 08/09 | `S13_validacion_completa.md` | Ver la skill |
| Tipos de modelo, notebook por capas, run-off | `S14_tipos_de_modelo_y_notebook.md` | Ver la skill |

Para una visión de conjunto (presentaciones, estudio), adjunta además `docs/MAPA_HERRAMIENTA.md`.

## 4. Lo que nunca pegues en un asistente externo

- `.env`, claves, tokens o cadenas de conexión.
- Datos de clientes o de operaciones reales, y Excels de resultados con datos personales.
- Logs de corridas reales sin revisar (pueden traer fragmentos de evidencia).
- Los registros sellados (`audit_logs/`, `feedback/`).

## 5. Cómo revisar lo que te devuelva

- ¿Toca `.env`, la lista de proveedores, las salvaguardas o `GOBIERNO_RIESGO_IA.md`? Rechazar.
- ¿Las rutas y funciones que cita existen? Búscalas en `docs/MAPA_HERRAMIENTA.md`.
- ¿Conserva los finales de línea del archivo (CRLF en los de la regla 10)?
- Aplica los archivos, corre las pruebas que indicó y `validate_project.py --strict`; si algo falla,
  devuélvele el error completo.
- Si cambió algo que describen las guías o el mapa, regenera con `scripts/generar_*.py`.
