"""
src/rag/banco/indexer.py
========================
Indexador del corpus del BANCO (`inputs/rag/banco/`). Hereda de BaseIndexer.

Qué va aquí: el material que usa la entidad para validar (lo genera
`scripts/generar_corpus_banco.py` desde el estándar, el procedimiento, el
repositorio de controles y las reglas de calificación) y las normas o políticas
internas que suba el administrador del corpus (.pdf, .docx, .xlsx, .pptx, .md).

Qué NO va: la evidencia de un modelo concreto (sus manuales, su código, su
manual de controles de datos). Eso es lo que se valida; indexarlo aquí haría
que el agente se diera la razón a sí mismo (GUIA_CORPUS_RAG.md, regla 1).
"""
from pathlib import Path
from typing import List

from src.rag.base_indexer import BaseIndexer, fuentes_rag


class BancoIndexer(BaseIndexer):
    dominio = "banco"

    def get_source_paths(self) -> List[Path]:
        return fuentes_rag(self.dominio)
