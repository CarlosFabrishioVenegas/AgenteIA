"""
src/rag/banco/retriever.py
==========================
Retriever del corpus del BANCO (`inputs/rag/banco/`): el criterio de la
entidad —estándar, procedimiento, catálogo de controles, reglas de
calificación, normas y políticas internas—. Se consulta en todas las
evaluaciones, además del dominio del modelo.

Uso: BancoRetriever().query_para_prompt(texto, top_k=2)
"""
from src.rag.base_retriever import BaseRetriever


class BancoRetriever(BaseRetriever):
    dominio = "banco"
