# Guía de uso de VIRF Agent

> Generada desde el código por `scripts/generar_guia_uso.py`: no la edites a mano (regénérala). Instalación: `GUIA_INSTALACION.md`. Notebook de calidad de datos: `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md`. Detalle técnico: `REFERENCIA_TECNICA.md`.

## Contenido

1. Qué es y quién lo usa
2. Arrancar
3. Recorrido por la web
4. Validación normal paso a paso
5. Validación completa (etapas 00–04)
6. Revisión con el agente (chat)
7. Solo informe
8. Controles de calidad de datos
9. Informe, cuadro y resultados
10. IA, proveedores y costes
11. Línea de comandos
12. Dónde queda cada cosa
13. Seguridad y gobierno
14. Problemas frecuentes
15. Parámetros de configuración

## 1. Qué es y quién lo usa

VIRF es un **agente validador de modelos de riesgo** (segunda línea). Lee la evidencia del modelo (manuales, código, datos, Excels de la primera línea), la contrasta con el **estándar de validación** de la entidad, la literatura del dominio y el corpus del banco, propone una evaluación por actividad y un informe Word. **El validador decide**: el agente propone, verifica sus citas y cifras contra la evidencia y nunca cierra nada por su cuenta.

Roles (los asigna el proveedor de identidad, no el registro local):

| Rol | Puede |
|---|---|
| `admin_corpus` | diagnostico, editar_prompts, gestionar_corpus, leer |
| `revisor` | aprobar, leer |
| `validador` | feedback_propio, leer, validar |

Cada validador trabaja en **sesiones por modelo**: la evidencia, el estándar, los resultados y el chat de un modelo no se mezclan con los de otro.

## 2. Arrancar

Instalación completa (entorno `.venv`, dependencias, `.env` sin secretos, verificación): `GUIA_INSTALACION.md`. Para arrancar la web:

```powershell
.venv\Scripts\python scripts\web_prueba.py --puerto 8000     # prueba local, sin SSO
.venv\Scripts\python -m uvicorn web.app:app --port 8000      # corporativa (SSO Entra ID)
```

Abre `http://localhost:8000`; `http://localhost:8000/api/salud` debe responder `{"estado":"ok"}`. La prueba local (`web_prueba.py`) solo funciona fuera de producción y marca lo firmado como «usuario de prueba». Usa **siempre** el entorno `.venv`.

Primeros pasos en la web: entra, **crea el modelo** (nombre, **código del modelo**, dominio, tier) y elige la **modalidad** con el botón de la barra superior: *Validación normal* (pipeline + estándar) o *Validación completa* (cinco etapas interactivas con notebooks).

## 3. Recorrido por la web


**Procedimiento**

| Opción | Para qué sirve |
|---|---|
| Configuración | Ficha del modelo (nombre, **código del inventario**, dominio, tier) y del agente (proveedor de IA aprobado, VIRF PLUS, prueba de conexión). El dominio decide el corpus del RAG y los controles del repositorio. |
| Estándares | Sube el `Estandares_VIRF.xlsx` del modelo: el agente evalúa cada actividad como checklist filtrada por Tier. El estándar de la sesión no pisa el global. |
| Evidencia | Sube la evidencia por carpeta (manuales de modelamiento y seguimiento, implementación —código o ZIP—, calidad de datos…), cada archivo con su **clasificación**. Todo queda en la sesión del modelo. |
| Dominio & RAG | Literatura del dominio y **corpus del banco** (estándar, procedimiento, catálogo de controles, reglas del informe) que se consulta en todas las evaluaciones. Índice local BM25 + TF-IDF; al añadir un documento se reconstruye. |
| Skills | Análisis transversales que el agente aplica al validar (coherencia, supuestos, síntesis…) y criterios propios. No cambian el puntaje: producen hallazgos. |
| Cuestionamientos | Patrones que el agente busca en el CÓDIGO del modelo y criterios extra en lenguaje natural. |
| Pre-vuelo | Revisión de la evidencia ANTES de gastar (coste 0): qué se podrá leer, PDFs escaneados, formatos omitidos y ámbitos que quedarían sin evidencia. |
| Validar modelo | Ejecuta el pipeline (`agente.py`) con la evidencia, el estándar y el tier de la sesión. El JSON, el Word y el Markdown quedan en `outputs/` de la SESIÓN y la revisión con el agente empieza sola con ese resultado y su documento. |
| Revisión con el agente | Conversación por observación: el agente contrasta tu criterio con la evidencia y tú decides. Al final, revisión de la redacción («conforme» o «reescribe N»). Ver §6. |
| Documentar | Cuadro de observaciones (Ámbito · Riesgo · Observación · Recomendación · Responsable) e informe Word versionado (V1, V2…), con la tabla de validación final y, en validación completa, el anexo de etapas, hallazgos e imágenes. |

**Validación completa**

| Opción | Para qué sirve |
|---|---|
| Insumos | Validación completa: manuales, Excels de primera línea y scripts (también .zip). El agente los ESTUDIA enteros (una ficha por archivo, en caché) antes de cada notebook. |
| Diagnóstico | Etapa 00 · `00_Diagnostico`: Construye el MAPEO DE LAS BASES DE DATOS del producto: cada base o fuente, qué contiene (granularidad, periodo, llaves, volumen), qué se hace con ella en el proceso y cómo se tiene observada. |
| Control de datos | Etapa 01 · `01_ControlDatos`: Recorre TODO lo que mapeó el 00_Diagnostico y revisa el control de datos de la primera línea. |
| Modelamiento | Etapa 02 · `02_Modelamiento`: REPLICA EL MODELAMIENTO. Es la etapa más importante: tómate el tiempo. Con los manuales metodológicos, el código y los archivos disponibles, el notebook reconstruye paso a paso cómo se construyó el modelo (población, exclusiones, variables, transformaciones, segmentación, estimación, calibración, resultados) citando en markdown la sección del manual de cada paso, y registra una hoja «Replica» con: paso, fuente, resultado del implementador, resultado replicado, diferencia y conclusión. |
| Impactos | Etapa 03 · `03_Impactos`: Cuantifica el IMPACTO en el resultado del modelo de lo que se está revisando: por ejemplo, una falla de datos que se le escapó al control de primera línea (01) o una diferencia en la réplica (02). |
| Seguimiento | Etapa 04 · `04_Seguimiento`: REPLICA EL SEGUIMIENTO del modelo: el notebook recalcula cada indicador de monitoreo (estabilidad, discriminación, calibración, backtesting, alertas) con los manuales y archivos de seguimiento, lo compara con el valor reportado por el implementador y registra una hoja «Seguimiento» con: indicador, umbral, valor del implementador, valor replicado, semáforo y conclusión. |

**Consultas**

| Opción | Para qué sirve |
|---|---|
| Resultados | Corridas de la sesión: puntajes, Excel de resultados, documento Word, comparación entre corridas y firma del validador. |
| Controles de datos | Controles de calidad de datos: diseñar con IA desde `.info()`/`.describe()` (notebook local, revisión y aprendizaje), catálogo de motores, resultados de la entidad y notebook entregable del repositorio por dominio. Ver `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md`. |

En la barra superior: **Solo informe** (§7), **VIRF PLUS** (segunda opinión de Claude, §10) y **Modalidad** (normal / completa).

## 4. Validación normal paso a paso

| Paso | Qué haces | Qué obtienes |
|---|---|---|
| 01 Configuración | Revisa la ficha (código, dominio, tier) y el proveedor de IA. | El agente sabe qué corpus y qué controles usar. |
| 02 Estándares | Sube el estándar del modelo (o usa el global). | Actividades a evaluar, por Tier. |
| 03 Evidencia | Sube manuales, código, datos y Excels con su clasificación. | Evidencia de la sesión. |
| 04 Dominio & RAG | Comprueba el dominio y su literatura; el corpus del banco va siempre. | Criterio externo y de la entidad. |
| 05–06 Skills / Cuestionamientos | Marca análisis y patrones; añade criterios propios. | Hallazgos transversales y sobre el código. |
| 07 Pre-vuelo | Ejecútalo SIEMPRE antes de gastar. | Qué se leerá y qué ámbitos quedarían sin evidencia. |
| 08 Validar modelo | Lanza la corrida. | JSON + Word + Markdown en la sesión; empieza la revisión. |
| 09 Revisión con el agente | Decide cada observación (§6). | Puntaje final validado y textos claros. |
| 10 Documentar | Genera el cuadro y el informe Word. | Informe versionado (V1, V2…). |

## 5. Validación completa (etapas 00–04)

Cinco chats especializados. En cada iteración el agente **entrega un notebook** (`<etapa>ITERn.ipynb`); lo ejecutas donde están los datos y genera `<etapa>_resultadoITERn.xlsx`; se lo devuelves con comentarios e imágenes y recibes el ITERn+1, hasta que la etapa cumple. **Tú cierras cada etapa** (el agente solo lo recomienda).

| Etapa | Fichero | Misión |
|---|---|---|
| 00 · Diagnóstico | `00_Diagnostico` | Construye el MAPEO DE LAS BASES DE DATOS del producto: cada base o fuente, qué contiene (granularidad, periodo, llaves, volumen), qué se hace con ella en el proceso y cómo se tiene observada. El notebook debe perfilar cada base (filas, columnas, tipos, nulos, duplicados de llave, rangos, periodos) y registrar una hoja «Mapeo» con una fila por base. |
| 01 · Control de datos | `01_ControlDatos` | Recorre TODO lo que mapeó el 00_Diagnostico y revisa el control de datos de la primera línea. El notebook debe ejecutar, base por base y variable por variable, los controles que debieron aplicarse (unicidad, nulos, rangos, integridad referencial, conciliación de conteos y montos entre bases y contra contabilidad si hay ruta) y registrar una hoja «Controles» con: elemento, control, resultado, n afectados, % y conclusión. Busca activamente lo que se le escapó a la primera línea. |
| 02 · Modelamiento | `02_Modelamiento` | REPLICA EL MODELAMIENTO. Es la etapa más importante: tómate el tiempo. Con los manuales metodológicos, el código y los archivos disponibles, el notebook reconstruye paso a paso cómo se construyó el modelo (población, exclusiones, variables, transformaciones, segmentación, estimación, calibración, resultados) citando en markdown la sección del manual de cada paso, y registra una hoja «Replica» con: paso, fuente, resultado del implementador, resultado replicado, diferencia y conclusión. Si un paso no se puede replicar con lo disponible, el notebook lo deja indicado y en «pendientes» pides exactamente el insumo que falta. |
| 03 · Impactos | `03_Impactos` | Cuantifica el IMPACTO en el resultado del modelo de lo que se está revisando: por ejemplo, una falla de datos que se le escapó al control de primera línea (01) o una diferencia en la réplica (02). El notebook recalcula el resultado con y sin la falla (usando Excels de implementadores, scripts de seguimiento, etc.) y registra una hoja «Impactos» con: hallazgo de origen, etapa, métrica afectada, valor original, valor corregido, impacto y nivel (Potencial/Bajo, Moderado, Crítico). |
| 04 · Seguimiento | `04_Seguimiento` | REPLICA EL SEGUIMIENTO del modelo: el notebook recalcula cada indicador de monitoreo (estabilidad, discriminación, calibración, backtesting, alertas) con los manuales y archivos de seguimiento, lo compara con el valor reportado por el implementador y registra una hoja «Seguimiento» con: indicador, umbral, valor del implementador, valor replicado, semáforo y conclusión. |

**Ruta paso a paso y experto por chat.** Cada etapa tiene un experto (arquitecto de datos en el 00, especialista en calidad de datos en el 01, modelador senior en el 02, experto en materialidad en el 03 y en monitoreo en el 04) y una **ruta** de pasos numerados que el notebook recorre en orden, cada uno con su hoja en el Excel. La pantalla de la etapa muestra la ruta con el estado de cada paso (cubierto · parcial · pendiente · no aplica) y VIRF lo **verifica** contra el notebook: la etapa no queda «lista» con pasos pendientes. Pasos por etapa: 00: 8; 01: 8; 02: 8; 03: 7; 04: 7. Detalle en `docs/GUIA_TIPOS_DE_MODELO.md`.

**Tipo de modelo.** Elígelo en la ficha del modelo (VaR, ES/FRTB, run-off, IRRBB, prepago, NMD, LCR, NSFR, brechas, LaR…): los cinco chats reciben su ficha de negocio y, sin IA, la plantilla de cada etapa replica (02), cuantifica impactos (03) y hace backtesting (04) según el tipo. **La etapa 01 entrega el mismo notebook de calidad de datos de la validación normal** (catálogo, batería, controles de negocio, repositorio, % de cumplimiento), armado con el perfil que dejó el 00 y con las rutas reales.

**Hallazgos de cada etapa (Excel + .md).** En cada iteración el agente reescribe `<etapa>_HALLAZGOS.xlsx` y `<etapa>_HALLAZGOS.md` con TODOS los hallazgos de la etapa: estado vigente, iteración en que nacieron, historial (ITER0 nuevo → ITER1 persiste…) y el **Excel de sustento** de cada uno (el archivo que lo prueba, con hoja y fila si la evidencia las cita). Se descargan desde la cabecera de la etapa. Si corriges el Excel tras la última iteración, el consolidado usa tu corrección.

**Al finalizar:** con las cinco etapas cerradas, pulsa **Consolidar hallazgos**. Se LEEN los Excel y .md de las cinco etapas, se contrastan (un hallazgo en uno y no en el otro, o con otra severidad, es una inconsistencia que se informa), se copian los Excel de sustento y se genera `outputs/validacion_completa/_consolidado/HALLAZGOS_VALIDACION_COMPLETA.xlsx` y `.md`. El cuadro de observaciones y el anexo del informe Word leen esos entregables.

**Después, la validación final (08 → 09 → 10) con TODO lo de las etapas.** En modalidad completa, **08 · Validar modelo** solo se lanza con las cinco etapas cerradas (si una no aplica, ciérrala con ese motivo); su pantalla muestra qué se lleva. Al lanzar, el trabajo de cada etapa pasa a la evidencia que el barrido lee por ámbito:

| Etapa | Va a | Lo usan |
|---|---|---|
| 00 · Diagnóstico | `documentacion/modelamiento/validacion_completa/` | Documentación, Metodología, Calidad de datos, Gobierno, Implementación |
| 01 · Control de datos | `calidad_datos/validacion_completa/` + `calidad_datos/resultadocalidad_de_datos/completa_01_ControlDatos.xlsx` | Calidad de datos |
| 02 · Modelamiento | `documentacion/modelamiento/validacion_completa/` | Documentación, Metodología, Calidad de datos, Gobierno, Implementación |
| 03 · Impactos | `documentacion/modelamiento/validacion_completa/` | Documentación, Metodología, Calidad de datos, Gobierno, Implementación |
| 04 · Seguimiento | `documentacion/seguimiento/validacion_completa/` | Documentación, Metodología |

Viajan solo los entregables de VIRF (hallazgos `.md` de cada etapa, el Excel de **resultados** de cada notebook, el consolidado y un `00_LEEME_VALIDACION_COMPLETA.md`), nunca los datos que enviaste a los chats. El Excel del 01 lo **puntúa** el ámbito «Calidad de datos», como «Usar estos resultados en la validación» de los controles de datos. Cada lanzamiento reemplaza lo publicado antes. En **09 · Revisión con el agente**, cada observación llega con los hallazgos de las etapas que tratan su ámbito y la búsqueda en la evidencia los encuentra; **10 · Documentar** lleva además el anexo de las etapas.

## 6. Revisión con el agente (chat)

Tras *Validar modelo*, el agente abre una conversación con cada observación que requiere aclaración. Reglas del agente: es estricto con la evidencia pero **consecuente** con lo que dices; verifica que cada cita, archivo y cifra que usa esté en el material (si no, lo avisa y no aprueba); para dar algo por subsanado exige un **motivo concreto** (un «ok» no basta); y tras 3 intentos sin claridad deja la observación PENDIENTE. Toda decisión queda en la auditoría con quién la tomó (tú o el agente).

• Responde con tu criterio sobre la observación en curso: el agente lo contrasta con la evidencia del modelo y decide en consecuencia. Para darla por subsanada te pedirá un motivo concreto (qué, dónde o por qué): un «ok» no basta.
• Decide tú directamente (queda registrado tal cual y en la auditoría):
   – **confirmar** [: nota] → la observación se mantiene (no conformidad confirmada)
   – **subsanada: motivo** → se da por subsanada (sube el puntaje; el motivo va al informe)
   – **no aplica: motivo** → el control no aplica a este modelo
   – **pendiente: motivo** → queda abierta para aclaración manual
• **📎 Adjuntar** un archivo: el agente reevalúa la observación con esa evidencia.
• **estado**: cuántas quedan y cómo se decidió cada una.
• **reabrir N: motivo**: vuelve a abrir una observación ya decidida.
• Al terminar: **conforme**, **reescribe N** o **reescribe N: tu texto**.

Botones bajo el chat: *Confirmar observación*, *Subsanada…*, *No aplica…*, *Pendiente…*, *Estado*, *Reabrir…* y *Ayuda*; 📎 para adjuntar evidencia y *Consolidar* para recomputar el puntaje y guardar el aprendizaje.

## 7. Solo informe

Genera el informe **sin ejecutar el pipeline**, a partir de lo que el validador ya revisó:

1. **Datos de la validación**, incluido el **código del modelo** (sale en la portada y la ficha).
2. **Estándar con holgura**: cada control del estándar puede marcarse *revisado*, *no aplica* (con motivo) o *limitación*; se añaden actividades propias; los ámbitos sin actividades para el Tier (p. ej. Gobierno) aparecen con su nota y con sugerencias del estándar de otros tiers.
3. **Observaciones** con **varios sustentos** cada una y gráfico estructurado (hallazgo, proceso, comparación, barras, flujo); lo que no consta en el texto se marca «No consta en el texto».
4. **Especializar con IA** (opcional): adapta el barrido al contexto y propone actividades y descripciones; nunca pisa lo que escribió el validador ni su holgura.
5. **Generar informe**: Word con la plantilla de la entidad.

## 8. Controles de calidad de datos

Pega `.info()` y `.describe()` de cada base; el agente entrega un **notebook local** que trae **siempre todos los controles**: los que se deducen del perfil, los del **tipo de modelo** (VaR, ALM y LaR no llevan los mismos; incluye los del repositorio del dominio: Kupiec, LCR, CPR…), una batería completa sobre todas las columnas y una plantilla de cada tipo del catálogo que necesita un dato del negocio. Calcula el **porcentaje de cumplimiento** (global, ponderado y por grupo) y acepta controles que ya resolviste en otros notebooks sin reescribirlos. Lo devuelves, el agente lo revisa y, si lo marcas, **aprende** para los próximos modelos del dominio (con aprobación de un revisor). Todo —cómo prenderlo, cómo añadir y traer controles y cómo aprende— en `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md`.

## 9. Informe, cuadro y resultados

* **Documentar** genera el cuadro de observaciones (desde los Excels de etapa en validación completa) y el informe Word versionado. Generar uno no cierra la sesión.
* El informe incluye la tabla de validación final con las decisiones del chat y, en validación completa, el anexo de etapas, la tabla de hallazgos (con su Excel de sustento) y las imágenes.
* **Resultados** guarda cada corrida: puntajes, Excel, documento, comparación y firma. La firma usa la identidad con la que entraste; no se firma a nombre de otro.

## 10. IA, proveedores y costes

| Proveedor | Estado en la entidad |
|---|---|
| `azure_openai` | APROBADO |
| `anthropic` | EN_ESPERA |
| `openai` | RETIRADO |

* El agente usa el proveedor **aprobado** (GPT en Azure OpenAI). Las claves salen de la fuente de secretos (Key Vault), nunca del `.env`.
* **VIRF PLUS** (opcional): suma a Claude como segunda opinión; los dos evalúan por separado y GPT concilia. Solo se enciende de forma explícita y mientras Claude esté aprobado.
* Antes de gastar: **Pre-vuelo** (coste 0) y `--dry-run` en los modos que lo admiten (estima tokens y coste con el modelo que de verdad correría).
* Los tests son coste 0: la IA se simula.

## 11. Línea de comandos

```powershell
.venv\Scripts\python agente.py --titulo "VaR Histórico" --tier 2 --dominio-rag VaR --codigo-modelo MR-VAR-014
.venv\Scripts\python agente.py --prevuelo
```

| Opción | Qué hace |
|---|---|
| `--titulo` | Nombre del modelo |
| `--tier` | Tier del modelo (1, 2, 3, 4) |
| `--excel` | Ruta al Excel de controles (para pipeline Calidad de Datos) |
| `--control` | Usar pipeline por CONTROL (Calidad de Datos) |
| `--prdc` | Modo producción (genera Word) |
| `--estadisticafeedback` | Ver estadísticas de feedback |
| `--limpiar-cache` | Limpiar caché de documentos y salir |
| `--cache-stats` | Ver estadísticas del caché de documentos |
| `--no-cache` | Deshabilitar caché para esta corrida |
| `--convertir-excel` | FASE 1: Ruta a carpeta con .xlsx/.xlsm. Genera .ipynb por libro con VBA, refs externas y auto-validación contra Excel. NO copia al pipeline principal — tú decides qué mover a inputs/implementacion/. |
| `--cuadro-automatizaciones` | Carpeta con los Excels de automatización del producto (00_Diagnostico, 01_ControlDatos, 02_Modelamiento, 03_Impactos opcional). Genera el cuadro de observaciones (Ámbito · Riesgo · Observación · Recomendación · Responsable/Fecha) en .xlsx y .json y sale. Usa l |
| `--sin-ia` | Con --cuadro-automatizaciones: borrador determinista, sin llamadas a la IA. |
| `--virf-plus` | Activa VIRF PLUS en esta corrida: suma a Claude como segunda opinión del agente GPT; ambos evalúan por separado y GPT concilia la conclusión (equivale a VIRF_PLUS=1). |
| `--controles-a-notebook` | Ruta a un DOCUMENTO (.docx/.pdf/.md) que describe controles de calidad de datos. Genera un .ipynb ejecutable y un análisis de brechas contra --excel. |
| `--datasets` | Carpeta con los datasets (.csv/.parquet/.xlsx) para los controles de motor de datos. Default: inputs/calidad_datos/datasets/ |
| `--listar-motores` | Muestra el catálogo de pruebas de calidad de datos disponibles y sale |
| `--dominio-rag` | Corpus RAG a consultar: LaR \| VaR \| conductuales \| shared. DECLÁRALO: sin este flag el dominio se INFIERE del título, y la inferencia es una heurística que puede enrutar al corpus equivocado (un modelo de scoring recibiendo normativa de liquidez). El inform |
| `--skills` | Análisis transversales tras la evaluación. 'all' \| 'rapidas' \| lista separada por comas (ej. coherencia,supuestos,sintesis). NO alteran el score: producen hallazgos, no puntajes. Ver --listar-skills |
| `--listar-skills` | Muestra el catálogo de skills de validación disponibles y sale |
| `--explicar-modelo` | Genera outputs/<fecha>/explicacion_del_modelo_<NOMBRE>.md consolidando las 4 fuentes de inputs/ (metodología, seguimiento, implementación, calidad de datos) |
| `--dry-run` | Para --explicar-modelo: muestra el inventario de evidencia y el coste estimado SIN llamar al modelo |
| `--excluir` | Para --explicar-modelo: nombres de fichero a omitir (p. ej. fixtures de prueba que viven en inputs/) |
| `--solo-coincidentes` | Para --explicar-modelo: usar SOLO los ficheros cuyo nombre contiene el modelo. Úsalo cuando varios modelos comparten las carpetas de inputs/; por defecto se incluye toda la evidencia para no descartar nada en silencio |
| `--raiz-evidencia` | Raíz alternativa que contiene inputs/ (default: la del proyecto). UN MODELO POR RAÍZ: evita que la evidencia de varios modelos se mezcle y que el informe de uno cite documentos de otro. El estándar VIRF, outputs/ y el caché siguen en la raíz del proyecto. Apli |
| `--estandares` | Ruta a un Estandares_VIRF.xlsx alternativo (default: el global del proyecto). Introducido por la web v2.4 para que cada validador aplique su propio catálogo de actividades por sesión, sin sobrescribir el global. Sin este flag no cambia nada: es explícito, no h |
| `--salida` | Carpeta raíz de SALIDA (la que contiene <fecha>/ con el JSON, el Word y el Markdown de la corrida). Por defecto, outputs/ del proyecto. La web la fija en la carpeta outputs/ de la SESIÓN del modelo: así el resultado y el documento de «Validar modelo» quedan en |
| `--codigo-modelo` | Código del modelo en el inventario de modelos (p. ej. MR-VAR-014). Se guarda en el JSON de resultados y sale en la portada y la ficha del informe Word |
| `--sin-llm` | Para --convertir-excel: no usa LLM (solo estructura + fórmulas sin traducir) |
| `--sin-validacion` | Para --convertir-excel: omite la auto-validación notebook vs Excel |
| `--revisar-codigo` | Revisa el código de inputs/implementacion/ (recursivo, .py e .ipynb) contra el manual metodológico: UNA llamada por módulo, hallazgos con fichero:línea. Sus hallazgos se fusionan en el ámbito Implementación. Con --dry-run muestra el inventario y el coste estim |
| `--analizar-codigo` | Análisis ESTÁTICO del código de inputs/implementacion/ (.py e .ipynb): extrae por AST los hechos duros —funciones, valores por defecto, ventanas, métodos, aleatoriedad— y los contrasta contra los manuales. COSTE 0: no llama al modelo y NO ejecuta el código. Ge |
| `--perfilar-datasets` | Añade a la evidencia un perfil del ESQUEMA de los datasets (columnas, tipos, nulos, rangos, duplicados). No vuelca ninguna fila de datos. Permite contrastar las variables reales contra las que declara el manual |
| `--prevuelo` | Revisa la evidencia ANTES de gastar y sale: qué se podrá leer, qué PDFs están escaneados, qué formatos se omiten sin aviso y qué ámbitos quedarán sin evidencia (puntúan 0.0). Coste 0, no llama al modelo. Sale con código 1 si algún ámbito queda sin evidencia |
| `--verificar-cadena` | Verifica la integridad de la cadena de custodia de todos los informes de un modelo y sale |
| `--verificar-evidencia` | Comprueba si los documentos citados por un informe siguen intactos y sale |
| `--verificar-emisiones` | Contrasta el registro append-only de emisiones (audit_logs/registro_emisiones.jsonl) contra los informes presentes en outputs/ y sale. Detecta informes emitidos que YA NO ESTÁN — que --verificar-cadena no puede ver, porque opera sobre los ficheros que existen. |
| `--historial-validaciones` | Lista, por validador, qué modelos ha aprobado y cuándo |
| `--comparar` | Compara las dos últimas corridas del modelo y sale: score por ámbito, actividades que subieron o bajaron, documentos que cambiaron, y si cambió la VARA DE MEDIR (estándar, modelo de IA, versión del agente). Coste 0 |
| `--verificar-conexion-azure` | Prueba de humo del proveedor activo: confirma credenciales, detecta el modelo real del deployment, muestra el perfil de chunking que se aplicará y valida que el parser entiende su JSON |

## 12. Dónde queda cada cosa

| Ruta | Contenido |
|---|---|
| `web/data/sesiones/<validador>/<modelo>/inputs/` | Evidencia de la sesión (por carpetas). |
| `web/data/sesiones/<validador>/<modelo>/outputs/<fecha>/` | JSON, Word y Markdown de cada corrida. |
| `…/outputs/validacion_completa/<etapa>/` | Notebooks ITERn, revisiones .md y `<etapa>_HALLAZGOS.xlsx/.md`. |
| `…/outputs/validacion_completa/_consolidado/` | Consolidado final de hallazgos y Excel de sustento. |
| `…/outputs/controles_ia/` | Propuestas, notebooks y revisiones de controles de datos. |
| `…/chat_historial.json` | Conversación y decisiones de la revisión con el agente. |
| `feedback/` | Aprendizaje (feedback de puntajes y lecciones de controles), solo-anexar y sellado. |
| `audit_logs/` | Registro de emisiones y auditoría. |
| `inputs/rag/` | Corpus del RAG por dominio y del banco. |
| `inputs/repositorio_controles/` | Controles especializados por dominio (funciones Python). |

## 13. Seguridad y gobierno

* Toda evidencia se sube con **clasificación** (Público, Interno, Restringido).
* Las claves de IA, en Key Vault; el `.env` solo lleva configuración.
* La salida al proveedor de IA pasa por un gateway que enmascara datos personales y trata la evidencia como material no confiable (anti-inyección).
* Lo que sube el puntaje (subsanar en el chat, aprender controles, aprobar feedback) exige motivo y, cuando aplica, la aprobación de un **revisor** distinto del autor.
* Los registros de feedback, aprendizaje y auditoría están sellados por cadena de hashes.
* El inventario de componentes de IA (`docs/seguridad/GOBIERNO_RIESGO_IA.md`) lo mantiene la entidad.

## 14. Problemas frecuentes

| Síntoma | Qué hacer |
|---|---|
| La web dice que el proveedor no está autorizado | El proveedor del `.env` no está APROBADO: usa `azure_openai`. |
| «falta la clave en la fuente de secretos» | Configura el secreto en Key Vault (o, en desarrollo, la variable de entorno del proceso). |
| Un ámbito puntúa 0 | No tenía evidencia: revisa el Pre-vuelo y sube lo que falta. |
| El chat no aprueba aunque respondiste | Falta un motivo concreto (qué, dónde o por qué), o una cita no se encontró en la evidencia: lo dice en su mensaje. |
| «No pude consultar al modelo» en el chat | Fallo técnico (no gasta intentos ni decide): reenvía o decide tú. |
| El consolidado de la validación completa avisa inconsistencias | El Excel y el .md de una etapa no coinciden: corrige el Excel (manda) o pide otra iteración. |
| El notebook de controles no prende | Ver `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md` §4 (tabla «Si algo falla»). |

## 15. Parámetros de configuración

Se declaran en `config/parametros.py` y se fijan como variables de entorno (o en `.env`, nunca secretos). Valor por defecto del código:

| Constante | Variable | Por defecto | Qué controla |
|---|---|---|---|
| `IA_PROVEEDOR` | `IA_PROVEEDOR` | `azure_openai` | [POLÍTICA DE PROVEEDOR] Azure OpenAI es el proveedor PRIORITARIO por decisión de la entidad. El DEFAULT vive aquí, en el código, y NO en el .env: si mañana alguien clona |
| `MODO` | `MODO` | `produccion` | [SEG-13] El default en código es PRODUCCIÓN: un despliegue que olvida MODO no queda en modo laxo. Para desarrollo local se declara MODO=debug. |
| `AGENTE_VERSION` | `VIRF_AGENTE_VERSION` | `27.1` | Viaja al JSON de auditoría: debe reflejar la versión REAL del evaluador. Se mantiene en 27.1 deliberadamente — subirla es una decisión del proyecto, no un efecto colatera |
| `TIMEOUT_SEGUNDOS` | `TIMEOUT_SEGUNDOS` | `30` |  |
| `REINTENTOS_API` | `REINTENTOS_API` | `3` |  |
| `MAX_CHARS_DOC` | `MAX_CHARS_DOC` | `15000` |  |
| `MAX_CHARS_CODIGO` | `MAX_CHARS_CODIGO` | `8000` |  |
| `MAX_FILAS_EXCEL` | `MAX_FILAS_EXCEL` | `200` |  |
| `MAX_CTX` | `VIRF_MAX_CTX` | `MAX_CHARS_DOC` | Contexto máximo que se le pasa al modelo por llamada. [UNIFICACIÓN v27.2] agente.py usaba default MAX_CHARS_DOC y chunker.py el literal "15000". Coincidían por casualidad |
| `MAX_DOCS_AMBITO` | `VIRF_MAX_DOCS_AMBITO` | `0` | 0 = sin límite de documentos por ámbito. `minimo=0` es deliberado: 0 es un valor VÁLIDO aquí, no un error de configuración. |
| `ANTHROPIC_MODELO` | `ANTHROPIC_MODELO` | `claude-sonnet-4-6` |  |
| `ANTHROPIC_MAX_TOKENS` | `ANTHROPIC_MAX_TOKENS` | `4096` |  |
| `VALIDAR_CONEXION` | `VIRF_VALIDAR_CONEXION` | `0` | Gasta 1 request de prueba al arrancar. Desactivado por defecto: un fallo de credenciales se manifiesta igual en la primera llamada real. |
| `AZURE_API_VERSION` | `AZURE_OPENAI_API_VERSION` | `2024-10-21` | GA estable. Una versión 'preview' puede cambiar de comportamiento sin aviso, y este sistema exige corridas reproducibles (METODOLOGIA_DEL_AGENTE.md §11.5): dos corridas s |
| `AZURE_MAX_TOKENS` | `AZURE_OPENAI_MAX_TOKENS` | `4096` |  |
| `OPENAI_MODELO` | `OPENAI_MODELO` | `gpt-4.1` | OpenAI directo (api.openai.com), con una sola API key. Lo usa VIRF PLUS como la voz «GPT» cuando la entidad no tiene un deployment de Azure. |
| `OPENAI_MAX_TOKENS` | `OPENAI_MAX_TOKENS` | `4096` |  |
| `VIRF_PLUS_GPT` | `VIRF_PLUS_GPT` | `IA_PROVEEDOR if IA_PROVEEDOR in ('openai` | VIRF PLUS: GPT (agente principal) + Claude como segunda opinión Se ENCIENDE solo con VIRF_PLUS=1 (botón «VIRF PLUS» de la web o .env). No se deduce de qué claves hay conf |
| `VIRF_PLUS_ARBITRO` | `VIRF_PLUS_ARBITRO` | `gpt` |  |
| `VIRF_PLUS_ARBITRAJE` | `VIRF_PLUS_ARBITRAJE` | `siempre` |  |
| `CUADRO_RESP_MODELAMIENTO` | `VIRF_RESP_MODELAMIENTO` | `Equipo de Modelamiento (desarrollador de` | Cuadro de observaciones de las automatizaciones (Excels 00–03) Responsable según DÓNDE cae la observación: si se corrige en el desarrollo del modelo (modelamiento) o en s |
| `CUADRO_RESP_SEGUIMIENTO` | `VIRF_RESP_SEGUIMIENTO` | `Equipo de Seguimiento de Modelos` |  |
| `CUADRO_PLAZO_CRITICO` | `VIRF_PLAZO_CRITICO` | `30` | Días de plazo para levantar la observación, según su riesgo. |
| `CUADRO_PLAZO_MODERADO` | `VIRF_PLAZO_MODERADO` | `90` |  |
| `CUADRO_PLAZO_BAJO` | `VIRF_PLAZO_BAJO` | `180` |  |
| `IMPACTO_UMBRAL_MODERADO` | `VIRF_IMPACTO_UMBRAL_MODERADO` | `0.05` | Umbrales para un impacto NUMÉRICO de 03_Impactos (en fracción: 0.05 = 5%). Un valor > 1 en el Excel se interpreta como porcentaje (7 → 7%). |
| `IMPACTO_UMBRAL_CRITICO` | `VIRF_IMPACTO_UMBRAL_CRITICO` | `0.1` |  |
| `CHUNK_SIZE` | `VIRF_CHUNK_SIZE` | `12000` | Tamaño INICIAL del segmento. El modo adaptativo puede subirlo hasta CHUNK_SIZE_MAX, así que no es el tamaño real en documentos grandes. |
| `CHUNK_OVERLAP` | `VIRF_CHUNK_OVERLAP` | `800` |  |
| `CHUNK_THRESHOLD` | `VIRF_CHUNK_THRESHOLD` | `CHUNK_SIZE` |  |
| `MAX_CHUNKS` | `VIRF_MAX_CHUNKS` | `40` | [COSTE-FIX D2] 40 en vez de 60: medido sobre un PDF real de 305 páginas, 40 segmentos cuestan $1,14 y 60 cuestan $1,45, con idéntica cobertura (100%). ⚠️ NO bajar de ~34 |
| `CHUNK_SIZE_MAX` | `VIRF_CHUNK_SIZE_MAX` | `40000` | Techo del segmento adaptativo. Subirlo permite bajar MAX_CHUNKS sin penalizar. |
| `MAX_NIVELES` | `VIRF_MAX_NIVELES` | `3` | Tope de niveles de consolidación jerárquica (evita bucle si el modelo no comprime lo suficiente). |
| `PRESUPUESTO_DOC` | `VIRF_PRESUPUESTO_DOC` | `int(MAX_CTX * 0.6)` | Presupuesto de chars que los resúmenes de UN documento pueden ocupar en el prompt de evaluación. Fracción de MAX_CTX para que un ámbito con varios documentos largos siga |
| `CHUNK_ENABLED` | `VIRF_CHUNK_ENABLED` | `1` |  |
| `MAX_CTX_SKILLS` | `VIRF_MAX_CTX_SKILLS` | `MAX_CTX * 4` | [AUDIT-FIX] Presupuesto propio para las SKILLS Las skills leen TODA la evidencia de una vez —su pregunta es transversal al modelo, no a un control—, mientras que el pipel |
| `RAG_TOP_K_SKILLS` | `VIRF_RAG_TOP_K_SKILLS` | `8` | Fragmentos RAG para el bloque regulatorio de las skills. Más que en una actividad (RAG_TOP_K) porque aquí la consulta es una sola para todo el análisis, no una por contro |
| `INTENTOS_CONTRATO` | `VIRF_INTENTOS_CONTRATO` | `2` | [AUDIT-FIX] Reintento ante respuesta que no cumple el contrato Intentos TOTALES para obtener una evaluación con el formato pactado. 2 = el original más un reintento. Exis |
| `MAX_ITER` | `VIRF_MAX_ITER` | `3` | [WP-05 · Cortacircuitos / fusibles] Fusibles para bucles de razonamiento y ejecución de skills. Evitan que un bucle agéntico o un reintento se disparen sin techo. Al supe |
| `FUSIBLE_SEG` | `VIRF_FUSIBLE_SEG` | `10` |  |
| `FUSIBLE_TOKENS` | `VIRF_FUSIBLE_TOKENS` | `20000` |  |
| `ABSTENCION_BETA` | `VIRF_ABSTENCION_BETA` | `0.19` | [WP-01 · Abstención activa (β)] Umbral de score léxico por debajo del cual la evidencia recuperada se declara INSUFICIENTE y el agente se ABSTIENE en lugar de responder d |
| `CACHE_ENABLED` | `CACHE_ENABLED` | `1` |  |
| `CACHE_LOCK_TIMEOUT` | `VIRF_CACHE_LOCK_TIMEOUT` | `10` |  |
| `CACHE_LOCK_STALE` | `VIRF_CACHE_LOCK_STALE` | `60` |  |
| `EXCEL_MAX_CELDAS_MUESTRA` | `EXCEL_MAX_CELDAS_MUESTRA` | `500` |  |
| `EXCEL_MAX_FORMULAS_HOJA` | `EXCEL_MAX_FORMULAS_HOJA` | `2000` |  |
| `EXCEL_CHUNK_HOJA_UMBRAL` | `EXCEL_CHUNK_HOJA_UMBRAL` | `80` |  |
| `EXCEL_VALIDACION_TOL` | `EXCEL_VALIDACION_TOL` | `1e-06` |  |
| `EXCEL_NB_TIMEOUT` | `EXCEL_NB_TIMEOUT` | `120` |  |
| `DEBUG_PROMPTS` | `DEBUG_PROMPTS` | `0` |  |
| `MIN_FEEDBACK_ANTISESGO` | `VIRF_MIN_FEEDBACK_ANTISESGO` | `15` | Masa crítica exigida antes de dejar que el feedback histórico altere el criterio del agente (D6-FIX). Gobierna el bloque de calibración del prompt. |
| `MIN_MUESTRAS_AJUSTE` | `VIRF_MIN_MUESTRAS_AJUSTE` | `MIN_FEEDBACK_ANTISESGO` | [AUDIT-FIX] Umbral del ajuste numérico POST-HOC del puntaje. Había dos guardias anti-sesgo descoordinadas y solo una era visible: · bloque del prompt → MIN_FEEDBACK_ANTIS |
| `PROHIBIR_MODELOS_EXTERNOS` | `VIRF_PROHIBIR_MODELOS_EXTERNOS` | `1` | Guardia de política. Ya no gobierna ninguna rama de código —no queda ninguna— pero se conserva porque `validate_project.py` y los tests la usan para verificar que no reap |
| `PII_MASKING` | `VIRF_PII_MASKING` | `1` | Enmascarado de PII en la evidencia Antes de que un extracto de documento salga hacia el proveedor de generación, se sustituyen los datos personales que pueda contener (co |
| `ENTAILMENT_ACTIVO` | `VIRF_ENTAILMENT` | `MODO == 'produccion` | Verificación semántica de citas (entailment / NLI) Cierra el salto «la cita EXISTE» → «la cita SOSTIENE la afirmación»: un juez LLM decide si el fragmento citado IMPLICA |
| `ANTIINYECCION_ACTIVO` | `VIRF_ANTIINYECCION` | `1` | Defensa anti-inyección de instrucciones en la evidencia Neutraliza tramos de la evidencia que parecen instrucciones dirigidas al evaluador («ignora las instrucciones y pu |
| `CA_BUNDLE` | `VIRF_CA_BUNDLE` | `—` | RED CORPORATIVA — proxy e inspección TLS El SDK de OpenAI usa `httpx`, y httpx verifica los certificados contra el bundle de **certifi**, NO contra el almacén de certific |
| `TLS_ALMACEN_SISTEMA` | `VIRF_TLS_ALMACEN_SISTEMA` | `0` | Alternativa a exportar el PEM: verificar contra el almacén de certificados del sistema operativo (en Windows, el mismo que usa el navegador) con `truststore`. Se declara |
| `HTTP_TIMEOUT` | `VIRF_HTTP_TIMEOUT` | `120` | Timeout de la petición HTTP. Un proxy corporativo añade latencia, y el default del SDK puede quedarse corto con prompts grandes. |
| `TLS_INSECURE` | `VIRF_TLS_INSECURE` | `0` | ⚠️ SALIDA DE EMERGENCIA — SOLO PARA DIAGNÓSTICO Desactiva la verificación TLS. Sirve para responder en 10 segundos a «¿es el certificado o es otra cosa?», que de otro mod |
| `RAG_TOP_K` | `RAG_TOP_K` | `6` | RAG [AUDIT-FIX] `.env.example` documentaba RAG_TOP_K=3 y RAG_MIN_SCORE=0.35 desde hacía tiempo, pero NADIE las leía: los valores vivían hardcodeados como defaults en las |
| `RAG_MIN_COBERTURA` | `RAG_MIN_COBERTURA` | `0.15` | ABSOLUTO. Fracción del peso informativo (Σ IDF) de la consulta que el fragmento cubre realmente. Comparable entre consultas: un 0.20 significa lo mismo aquí que en cualqu |
| `RAG_MIN_SCORE` | `RAG_MIN_SCORE` | `0.35` | RELATIVO. Recorta la cola de la lista ya ordenada: «quédate con lo que esté al menos al X% de lo mejor de ESTA consulta». Se conserva con su nombre y su default histórico |
| `RAG_PESO_INFORMATIVO_MINIMO` | `RAG_PESO_INFORMATIVO_MINIMO` | `0.8` | Peso informativo mínimo (Σ IDF) para considerar que una CONSULTA discrimina algo contra el corpus. No filtra: AVISA. Es la pieza que faltaba. Medido en el índice de VaR: |
| `RAG_INDICE_DIR` | `RAG_INDICE_DIR` | `—` | Dónde se persisten los índices. Carpeta DISTINTA de VECTORDB_DIR a propósito: aquella contiene bases ChromaDB con vectores que ya no significan nada, y mezclar los dos fo |
| `RAG_PESO_BM25` | `RAG_PESO_BM25` | `0.7` | Combinación de las dos señales. BM25 manda porque premia la coincidencia EXACTA de terminología (Kupiec, HQLA, NSFR, IFRS 9), que es lo que discrimina en literatura regul |
| `RAG_PESO_TFIDF` | `RAG_PESO_TFIDF` | `0.3` |  |
| `RAG_BM25_K1` | `RAG_BM25_K1` | `1.5` | Parámetros canónicos de BM25 (Robertson; los mismos que trae Elasticsearch). |
| `RAG_BM25_B` | `RAG_BM25_B` | `0.75` |  |
| `RAG_TFIDF_NGRAM_MAX` | `RAG_TFIDF_NGRAM_MAX` | `2` | Bigramas activados: «value at risk» o «riesgo de mercado» solo existen como pareja. Con unigramas puros, «risk» es tan común en este corpus que no discrimina nada. |
| `RAG_TFIDF_MIN_DF` | `RAG_TFIDF_MIN_DF` | `1` | min_df=1: el corpus son decenas o cientos de chunks, no millones. Descartar términos que aparecen en un solo chunk borraría justo los tecnicismos raros que son el motivo |
| `RAG_CHUNK_SIZE` | `RAG_CHUNK_SIZE` | `1200` | Troceado del índice. Más pequeño que el del chunker de evidencia: aquí el chunk es la UNIDAD DE RESPUESTA que se inyecta al prompt, y 1200 caracteres es un párrafo largo |
| `RAG_CHUNK_OVERLAP` | `RAG_CHUNK_OVERLAP` | `200` |  |
| `RAG_CHUNKING_ESTRUCTURAL` | `RAG_CHUNKING_ESTRUCTURAL` | `0` | Chunking ESTRUCTURAL (respeta encabezados; no parte tablas ni fórmulas) como reemplazo OPT-IN del corte por tamaño en el indexador léxico. Default False: la puerta de rec |
| `RAG_STEMMING` | `RAG_STEMMING` | `1` | Stemming conservador (ver `src/rag/indexador_lexico._stem`): hace que «modelos»/«modelo» caigan en el mismo token sin tocar acrónimos. |
| `RAG_LONGITUD_MINIMA_TOKEN` | `RAG_LONGITUD_MINIMA_TOKEN` | `2` | Tokens de 1 carácter no aportan; los de 2 SÍ (PD, LGD, EL, VaR en minúscula). |
| `RAG_TESAURO` | `RAG_TESAURO` | `1` | Expansión de consulta: las dos curas del punto ciego léxico BM25 encuentra por coincidencia de cadena, así que no une «excepciones» con «excedencias» aunque sean sinónimo |
| `RAG_CORREGIR_ERRATAS` | `RAG_CORREGIR_ERRATAS` | `1` |  |
| `RAG_UMBRAL_ERRATA` | `RAG_UMBRAL_ERRATA` | `0.85` |  |
| `RAG_BANCO` | `RAG_BANCO` | `1` | [2026-11-23] CORPUS DEL BANCO (`inputs/rag/banco/`): el material que USA EL BANCO para validar —su estándar, su procedimiento, su catálogo de controles, sus reglas de cal |
| `RAG_TOP_K_BANCO` | `RAG_TOP_K_BANCO` | `2` |  |
| `CONTROLES_APRENDIDOS` | `CONTROLES_APRENDIDOS` | `1` | CONTROLES DE CALIDAD DE DATOS — aprendizaje por dominio Lecciones que los validadores enseñan al devolver el Excel del notebook (modulos/aprendizaje_controles.py). Solo s |
| `CONTROLES_APRENDIDOS_MAX` | `CONTROLES_APRENDIDOS_MAX` | `25` |  |
| `CHAT_MAX_TOKENS` | `CHAT_MAX_TOKENS` | `1500` | AGENTE CONVERSACIONAL (Revisión con el agente) CHAT_MAX_TOKENS: tope de la respuesta del modelo por turno (con 800 se cortaban respuestas con citas y el JSON truncado se |
| `CHAT_MAX_CARACTERES` | `CHAT_MAX_CARACTERES` | `6000` |  |
| `UMBRAL_SIN_SEGUNDA_REVISION` | `VIRF_UMBRAL_SEGUNDA_REVISION` | `3` | Firmas consecutivas del mismo validador sobre el mismo modelo a partir de las cuales se advierte de falta de segunda revisión (SR 11-7 §V, segregación de funciones). No b |
