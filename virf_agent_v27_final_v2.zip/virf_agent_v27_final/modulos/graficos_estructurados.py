"""
modulos/graficos_estructurados.py
═══════════════════════════════════════════════════════════════════════════════
Figuras ESTRUCTURADAS que acompañan a una observación del informe.

Antes el gráfico era un flujo de 2–8 cajas o unas barras: servía para resumir un
texto, no para explicar un hallazgo. Ahora hay cinco tipos, pensados para cómo se
lee una observación de validación:

    hallazgo     Estructura clásica de un hallazgo de auditoría:
                 CRITERIO (lo esperado) ≠ CONDICIÓN (lo encontrado)
                 → CAUSA → EFECTO / RIESGO → RECOMENDACIÓN
    proceso      Proceso por FASES, cada una con sus pasos; la fase o el paso
                 donde está la observación se resalta (observado / crítico).
    comparacion  Dos fuentes frente a frente (p. ej. manual vs. implementación),
                 aspecto por aspecto, con coincide / no coincide.
    barras       Cifras del texto, con línea de referencia (umbral) opcional y
                 las barras que la superan resaltadas.
    flujo        Secuencia simple de pasos (se conserva por compatibilidad).

Dos funciones públicas, sin IA:

    validar_spec(spec, fuente)  → spec saneada y lista de avisos. Rechaza (lanza
                                  `SpecInvalida`) lo incoherente y, sobre todo,
                                  cualquier CIFRA que no esté en el texto fuente:
                                  un número inventado en una figura de un informe
                                  firmado es un dato falso.
    dibujar(spec, destino)      → PNG con matplotlib (backend Agg).

La IA solo PROPONE el JSON (`web/services/solo_informe_ia.grafico`); quién decide
el contenido es este módulo y, al final, el validador que acepta la figura.
"""
from __future__ import annotations

import re
import textwrap
import unicodedata
from pathlib import Path
from typing import Any, Optional

__all__ = ["TIPOS", "SpecInvalida", "validar_spec", "dibujar", "numeros",
           "NO_CONSTA"]

TIPOS = ("hallazgo", "proceso", "comparacion", "barras", "flujo")

#: Lo que se escribe en un campo de «hallazgo» que el texto no sostiene.
NO_CONSTA = "No consta en el texto"

# Paleta del informe (plantilla_bcp): navy, gris claro, tinta.
_AZUL, _AZUL2, _TINTA, _GRIS = "#1F3864", "#2E5A88", "#23262E", "#6E7480"
_FONDO = "#F4F6FA"
_COLOR_RIESGO = {
    "Crítico": "#C0392B", "Moderado": "#D9822B", "Bajo": "#B8A12B",
    "Potencial": "#6A9F3B", "Oportunidad de Mejora": "#2E75B6",
}
_ESTADO = {
    "ok":        ("#E2EFDA", "#548235", "Conforme"),
    "observado": ("#FFF2CC", "#B8832B", "Observado"),
    "critico":   ("#F8D7DA", "#C0392B", "Crítico"),
    "":          ("#E7ECF4", "#1F3864", ""),
}


class SpecInvalida(ValueError):
    """La propuesta de figura no es coherente o inventa datos."""


# ─── Utilidades de texto ────────────────────────────────────────────────────

def numeros(texto: str) -> set[str]:
    """Cifras del texto en forma canónica («99,0» y «99» → «99»; «1,5» → «1.5»)."""
    return {f"{float(n.replace(',', '.')):g}"
            for n in re.findall(r"\d+(?:[.,]\d+)?", texto or "")}


def _txt(v: Any, tope: int) -> str:
    s = " ".join(str(v or "").split())
    return s[:tope].rstrip()


def _sin_tildes(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s or "")
                   if not unicodedata.combining(c)).lower()


_VACIAS = {"para", "como", "sobre", "entre", "desde", "hasta", "este", "esta", "estos",
           "estas", "pero", "porque", "cuando", "donde", "segun", "tiene", "tienen",
           "debe", "deben", "puede", "pueden", "sido", "esta", "estan", "cada", "otro",
           "otra", "otros", "otras", "todo", "toda", "todos", "todas", "mismo", "misma",
           "modelo", "manual", "validacion", "observacion", "control"}


def _palabras(s: str) -> set[str]:
    """Palabras con contenido (≥4 letras), sin tildes y truncadas a 6 letras:
    un «stemming» pobre pero suficiente para que «actualización» y «actualizar»
    cuenten como la misma idea."""
    return {w[:6] for w in re.findall(r"[a-zñ]{4,}", _sin_tildes(s)) if w not in _VACIAS}


def _apoyo(campo: str, fuente_palabras: set[str]) -> float:
    """Fracción de las palabras del campo que aparecen en la fuente."""
    p = _palabras(campo)
    if not p:
        return 1.0
    return len(p & fuente_palabras) / len(p)


def _cifras_inventadas(textos: list[str], fuente: str) -> list[str]:
    presentes = numeros(fuente)
    nuevas: list[str] = []
    for t in textos:
        for n in sorted(numeros(t) - presentes):
            if n not in nuevas:
                nuevas.append(n)
    return nuevas


# ─── Validación ─────────────────────────────────────────────────────────────

#: Umbral de apoyo léxico de un campo de «hallazgo» en el texto fuente. Por
#: debajo, el campo dice cosas que el texto no dice: se sustituye por NO_CONSTA
#: y se avisa. 0.35 tolera la paráfrasis («se desactualizó» ↔ «actualización
#: pendiente») y caza la invención de una causa que nadie escribió.
APOYO_MINIMO = 0.35


def validar_spec(spec: dict, fuente: str, riesgo: str = "") -> tuple[dict, list[str]]:
    """
    Sanea la propuesta de figura. Devuelve (spec, avisos).

    `fuente` es TODO el texto que se le dio a la IA (observación, sustento,
    recomendación, actividad): es la vara para decidir qué cifras y qué ideas
    tienen respaldo. Lanza `SpecInvalida` si la figura no es utilizable o trae
    una cifra que no está en la fuente.
    """
    if not isinstance(spec, dict):
        raise SpecInvalida("la propuesta no es un objeto JSON")
    tipo = str(spec.get("tipo") or "").strip().lower()
    if tipo not in TIPOS:
        raise SpecInvalida(f"tipo de figura desconocido: {tipo or '(vacío)'}")
    titulo = _txt(spec.get("titulo"), 90)
    avisos: list[str] = []
    fuente_pal = _palabras(fuente)
    salida: dict[str, Any] = {"tipo": tipo, "titulo": titulo}
    if riesgo:
        salida["riesgo"] = riesgo

    if tipo == "hallazgo":
        campos = ("criterio", "condicion", "causa", "efecto", "recomendacion")
        vals = {c: _txt(spec.get(c), 240) for c in campos}
        llenos = [c for c in campos if vals[c] and vals[c] != NO_CONSTA]
        if not ({"criterio", "condicion"} <= set(llenos)) or len(llenos) < 3:
            raise SpecInvalida("el hallazgo necesita al menos criterio, condición y un "
                               "tercer elemento (causa, efecto o recomendación)")
        for c in campos:
            if vals[c] and vals[c] != NO_CONSTA and _apoyo(vals[c], fuente_pal) < APOYO_MINIMO:
                avisos.append(f"«{c}» no tiene respaldo en el texto; se muestra como "
                              f"«{NO_CONSTA}».")
                vals[c] = NO_CONSTA
            elif not vals[c]:
                vals[c] = NO_CONSTA
        textos = list(vals.values())
        salida.update(vals)

    elif tipo == "proceso":
        fases = []
        for f in (spec.get("fases") or [])[:5]:
            if not isinstance(f, dict):
                continue
            nombre = _txt(f.get("nombre"), 50)
            pasos = [_txt(p, 110) for p in (f.get("pasos") or [])[:5] if _txt(p, 110)]
            estado = _sin_tildes(str(f.get("estado") or "")).strip()
            estado = {"critico": "critico", "observado": "observado", "ok": "ok",
                      "conforme": "ok"}.get(estado, "")
            if nombre and pasos:
                fases.append({"nombre": nombre, "pasos": pasos, "estado": estado})
        if not 2 <= len(fases) <= 5:
            raise SpecInvalida("el proceso propuesto no tiene entre 2 y 5 fases con pasos")
        textos = [f["nombre"] for f in fases] + [p for f in fases for p in f["pasos"]]
        salida["fases"] = fases

    elif tipo == "comparacion":
        cols = [_txt(c, 40) for c in (spec.get("columnas") or [])[:2]]
        if len(cols) != 2 or not all(cols):
            raise SpecInvalida("la comparación necesita dos columnas con nombre")
        filas = []
        for f in (spec.get("filas") or [])[:8]:
            if not isinstance(f, dict):
                continue
            asp, a, b = _txt(f.get("aspecto"), 60), _txt(f.get("a"), 120), _txt(f.get("b"), 120)
            if asp and (a or b):
                filas.append({"aspecto": asp, "a": a or "—", "b": b or "—",
                              "coincide": bool(f.get("coincide"))})
        if not 2 <= len(filas) <= 8:
            raise SpecInvalida("la comparación propuesta no tiene entre 2 y 8 filas")
        textos = cols + [x for f in filas for x in (f["aspecto"], f["a"], f["b"])]
        salida.update(columnas=cols, filas=filas)

    elif tipo == "barras":
        etiquetas = [_txt(e, 40) for e in spec.get("etiquetas") or []]
        try:
            valores = [float(v) for v in spec.get("valores") or []]
        except (TypeError, ValueError):
            raise SpecInvalida("el gráfico propuesto trae valores no numéricos")
        if not 2 <= len(valores) == len(etiquetas) <= 12:
            raise SpecInvalida("el gráfico de barras propuesto no es coherente")
        ref = spec.get("referencia")
        try:
            ref = None if ref in (None, "") else float(ref)
        except (TypeError, ValueError):
            ref = None
        cifras = [f"{v:g}" for v in valores] + ([f"{ref:g}"] if ref is not None else [])
        presentes = numeros(fuente)
        for s in cifras:
            if s not in presentes:
                raise SpecInvalida(f"el modelo propuso la cifra {s}, que no está en el "
                                   "texto; se descarta el gráfico")
        textos = etiquetas
        salida.update(etiquetas=etiquetas, valores=valores,
                      unidad=_txt(spec.get("unidad"), 20),
                      referencia=ref, referencia_etiqueta=_txt(spec.get("referencia_etiqueta"), 40))

    else:  # flujo
        pasos = [_txt(p, 120) for p in spec.get("pasos") or [] if _txt(p, 120)]
        if not 2 <= len(pasos) <= 8:
            raise SpecInvalida("el esquema propuesto no tiene entre 2 y 8 pasos")
        textos = pasos
        salida["pasos"] = pasos

    nuevas = _cifras_inventadas(textos + [titulo], fuente)
    if nuevas:
        raise SpecInvalida("la figura introduce cifras que no están en el texto ("
                           + ", ".join(nuevas[:5]) + "); se descarta para no inventar datos")
    return salida, avisos


# ─── Dibujo ─────────────────────────────────────────────────────────────────
#
# El lienzo se mide en PULGADAS (ancho fijo `_ANCHO`, alto calculado según el
# texto): cada caja se dimensiona con las líneas que de verdad ocupa su texto,
# así no quedan cajas medio vacías ni texto que se sale. La anchura media de un
# carácter de DejaVu Sans es ~0,58 em; con eso se estima cuántos caben por línea.

_ANCHO = 8.2                 # pulgadas (la figura entra a 14 cm en el Word)
_MARGEN = 0.15
_PAD = 0.10                  # relleno interior de una caja
_BANDA = 0.48                # alto de la banda de título


def _chars_por_linea(ancho_in: float, tam_pt: float) -> int:
    return max(8, int((ancho_in - 2 * _PAD) * 72 / (tam_pt * 0.58)))


def _lineas(texto: str, ancho_in: float, tam_pt: float, max_lineas: int = 12) -> list:
    ls = textwrap.wrap(texto or "", _chars_por_linea(ancho_in, tam_pt)) or [""]
    if len(ls) > max_lineas:
        ls = ls[:max_lineas]
        ls[-1] = ls[-1].rstrip(" .,;") + "…"
    return ls


def _alto_texto(n_lineas: int, tam_pt: float) -> float:
    return n_lineas * tam_pt * 1.32 / 72


def _alto_caja(titulo: str, cuerpo: str, ancho_in: float, tam: float = 8.0,
               max_lineas: int = 12) -> float:
    h = 2 * _PAD
    if titulo:
        h += _alto_texto(1, tam) + 0.05
    if cuerpo:
        h += _alto_texto(len(_lineas(cuerpo, ancho_in, tam, max_lineas)), tam)
    return h


def _caja(ax, x, y_sup, w, h, *, fc, ec, titulo="", cuerpo="", tam=8.0, lw=1.2,
          color_titulo=None, max_lineas=12):
    """Caja con la esquina superior izquierda en (x, y_sup), en pulgadas."""
    from matplotlib.patches import FancyBboxPatch
    ax.add_patch(FancyBboxPatch((x, y_sup - h), w, h,
                                boxstyle="round,pad=0,rounding_size=0.06",
                                fc=fc, ec=ec, lw=lw))
    cy = y_sup - _PAD
    if titulo:
        ax.text(x + _PAD, cy, titulo, fontsize=tam, fontweight="bold",
                color=color_titulo or ec, va="top", ha="left")
        cy -= _alto_texto(1, tam) + 0.05
    if cuerpo:
        ax.text(x + _PAD, cy, "\n".join(_lineas(cuerpo, w, tam, max_lineas)),
                fontsize=tam, color=_TINTA, va="top", ha="left", linespacing=1.32)


def _flecha(ax, x0, y0, x1, y1, color=_AZUL, lw=1.4):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, shrinkA=0, shrinkB=0))


def _lienzo(alto_in: float):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig = plt.figure(figsize=(_ANCHO, alto_in))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, _ANCHO); ax.set_ylim(0, alto_in); ax.axis("off")
    return fig, ax


def _cabecera(ax, spec: dict, alto_in: float) -> float:
    """Banda de título + insignia de riesgo. Devuelve la «y» donde empieza el cuerpo."""
    from matplotlib.patches import Rectangle
    ax.add_patch(Rectangle((0, alto_in - _BANDA), _ANCHO, _BANDA, fc=_AZUL, ec="none"))
    titulo = spec.get("titulo") or "Esquema de la observación"
    ax.text(_MARGEN, alto_in - _BANDA / 2, _lineas(titulo, 6.2, 10.5, 1)[0],
            color="white", fontsize=10.5, fontweight="bold", va="center", ha="left")
    r = spec.get("riesgo")
    if r:
        col = _COLOR_RIESGO.get(r, _AZUL2)
        ax.add_patch(Rectangle((_ANCHO - _MARGEN - 1.55, alto_in - _BANDA + 0.09), 1.55,
                               _BANDA - 0.18, fc=col, ec="white", lw=0.8))
        ax.text(_ANCHO - _MARGEN - 0.775, alto_in - _BANDA / 2, f"Riesgo {r}", color="white",
                fontsize=8, fontweight="bold", va="center", ha="center")
    return alto_in - _BANDA - 0.18


def _figura_hallazgo(spec):
    util = _ANCHO - 2 * _MARGEN
    gap_sup = 0.55
    w_sup = (util - gap_sup) / 2
    gap_inf = 0.32
    w_inf = (util - 2 * gap_inf) / 3
    sup = [("CRITERIO · lo esperado", spec["criterio"], "#EAF0F7", _AZUL),
           ("CONDICIÓN · lo encontrado", spec["condicion"], "#FDEDEC", "#C0392B")]
    col_efecto = _COLOR_RIESGO.get(spec.get("riesgo", ""), "#B8832B")
    inf = [("CAUSA", spec["causa"], "#F4F6FA", _AZUL2),
           ("EFECTO · RIESGO", spec["efecto"], "#FFF2CC", col_efecto),
           ("RECOMENDACIÓN", spec["recomendacion"], "#E2EFDA", "#548235")]
    h_sup = max(_alto_caja(t, c, w_sup) for t, c, *_ in sup)
    h_inf = max(_alto_caja(t, c, w_inf) for t, c, *_ in inf)
    alto = _BANDA + 0.18 + h_sup + 0.50 + h_inf + _MARGEN + 0.05
    fig, ax = _lienzo(alto)
    y = _cabecera(ax, spec, alto)
    for i, (t, c, fc, ec) in enumerate(sup):
        _caja(ax, _MARGEN + i * (w_sup + gap_sup), y, w_sup, h_sup, fc=fc, ec=ec,
              titulo=t, cuerpo=c)
    xm = _MARGEN + w_sup + gap_sup / 2
    ax.text(xm, y - h_sup / 2 + 0.06, "≠", fontsize=22, color="#C0392B", ha="center",
            va="center", fontweight="bold")
    ax.text(xm, y - h_sup / 2 - 0.22, "brecha", fontsize=7.5, color=_GRIS,
            ha="center", va="center")
    y2 = y - h_sup - 0.50
    for i, (t, c, fc, ec) in enumerate(inf):
        x = _MARGEN + i * (w_inf + gap_inf)
        vacio = c == NO_CONSTA
        _caja(ax, x, y2, w_inf, h_inf, fc="#FAFAFA" if vacio else fc,
              ec=_GRIS if vacio else ec, titulo=t, cuerpo=c,
              color_titulo=_GRIS if vacio else ec)
        if i < 2:
            _flecha(ax, x + w_inf + 0.03, y2 - h_inf / 2,
                    x + w_inf + gap_inf - 0.03, y2 - h_inf / 2)
    # La brecha (arriba) explica sus consecuencias (abajo).
    _flecha(ax, xm, y - h_sup - 0.04, xm, y2 + 0.04, color=_GRIS, lw=1.0)
    return fig


def _figura_proceso(spec):
    from matplotlib.patches import Polygon
    fases = spec["fases"]
    n = len(fases)
    gap = 0.22
    util = _ANCHO - 2 * _MARGEN
    w = (util - gap * (n - 1)) / n
    tam = 7.6
    h_paso = max(_alto_caja("", p, w, tam, 6) for f in fases for p in f["pasos"])
    max_pasos = max(len(f["pasos"]) for f in fases)
    h_cab = 0.42
    hay_leyenda = any(f["estado"] in ("observado", "critico") for f in fases)
    alto = (_BANDA + 0.18 + h_cab + 0.12 + max_pasos * (h_paso + 0.10)
            + (0.35 if hay_leyenda else 0) + _MARGEN)
    fig, ax = _lienzo(alto)
    y = _cabecera(ax, spec, alto)
    for i, f in enumerate(fases):
        x = _MARGEN + i * (w + gap)
        fc, ec, _ = _ESTADO.get(f["estado"], _ESTADO[""])
        pico = 0.16
        pts = [(x, y - h_cab), (x + w - pico, y - h_cab), (x + w, y - h_cab / 2),
               (x + w - pico, y), (x, y)]
        ax.add_patch(Polygon(pts, closed=True, fc=ec if f["estado"] else _AZUL, ec="none"))
        ax.text(x + 0.10, y - h_cab / 2, _lineas(f"{i + 1}. {f['nombre']}", w - 0.1, 8, 1)[0],
                color="white", fontsize=8, fontweight="bold", va="center", ha="left")
        yp = y - h_cab - 0.12
        for p in f["pasos"]:
            _caja(ax, x, yp, w, h_paso, fc=fc, ec=ec, cuerpo=p, tam=tam, max_lineas=6)
            yp -= h_paso + 0.10
    if hay_leyenda:
        xl = _MARGEN
        for e in ("observado", "critico"):
            if any(f["estado"] == e for f in fases):
                fc, ec, et = _ESTADO[e]
                _caja(ax, xl, _MARGEN + 0.20, 0.22, 0.16, fc=fc, ec=ec)
                ax.text(xl + 0.30, _MARGEN + 0.12, et, fontsize=7.5, color=_TINTA, va="center")
                xl += 1.4
    return fig


def _figura_comparacion(spec):
    from matplotlib.patches import Rectangle
    filas = spec["filas"]
    util = _ANCHO - 2 * _MARGEN
    anchos = [util * 0.22, util * 0.355, util * 0.355, util * 0.07]
    xs = [_MARGEN]
    for a in anchos[:-1]:
        xs.append(xs[-1] + a)
    tam = 7.6
    altos = []
    for f in filas:
        n = max(len(_lineas(f["aspecto"], anchos[0], tam, 5)),
                len(_lineas(f["a"], anchos[1], tam, 5)),
                len(_lineas(f["b"], anchos[2], tam, 5)))
        altos.append(_alto_texto(n, tam) + 2 * _PAD)
    h_cab = 0.34
    alto = _BANDA + 0.18 + h_cab + sum(altos) + 0.40 + _MARGEN
    fig, ax = _lienzo(alto)
    y = _cabecera(ax, spec, alto)
    for j, cab in enumerate(("Aspecto", spec["columnas"][0], spec["columnas"][1], "")):
        ax.add_patch(Rectangle((xs[j], y - h_cab), anchos[j], h_cab, fc="#E7ECF4",
                               ec="white", lw=1))
        ax.text(xs[j] + _PAD, y - h_cab / 2, cab, fontsize=8, fontweight="bold",
                color=_AZUL, va="center")
    y -= h_cab
    for i, (f, h) in enumerate(zip(filas, altos)):
        fondo = "#FFFFFF" if i % 2 == 0 else _FONDO
        for j in range(4):
            ax.add_patch(Rectangle((xs[j], y - h), anchos[j], h, fc=fondo,
                                   ec="#D5DBE5", lw=0.6))
        ax.text(xs[0] + _PAD, y - _PAD, "\n".join(_lineas(f["aspecto"], anchos[0], tam, 5)),
                fontsize=tam, fontweight="bold", color=_AZUL2, va="top", linespacing=1.32)
        for j, k in ((1, "a"), (2, "b")):
            ax.text(xs[j] + _PAD, y - _PAD, "\n".join(_lineas(f[k], anchos[j], tam, 5)),
                    fontsize=tam, color=_TINTA, va="top", linespacing=1.32)
        ok = f["coincide"]
        ax.text(xs[3] + anchos[3] / 2, y - h / 2, "✓" if ok else "✗", fontsize=13,
                fontweight="bold", color="#548235" if ok else "#C0392B",
                ha="center", va="center")
        y -= h
    n_ko = sum(1 for f in filas if not f["coincide"])
    ax.text(_MARGEN, _MARGEN + 0.05,
            f"{n_ko} de {len(filas)} aspecto(s) no coinciden entre "
            f"«{spec['columnas'][0]}» y «{spec['columnas'][1]}».",
            fontsize=7.5, color=_GRIS, va="bottom")
    return fig


def _figura_barras(spec):
    vals, etqs = spec["valores"], spec["etiquetas"]
    alto = _BANDA + 0.5 + 0.42 * len(vals) + 0.75
    fig, ax_marco = _lienzo(alto)
    _cabecera(ax_marco, spec, alto)
    largo_etq = max(len(e) for e in etqs)
    izq = min(0.34, 0.08 + 0.0085 * min(largo_etq, 30))
    ax = fig.add_axes([izq, 0.55 / alto, 0.90 - izq, (alto - _BANDA - 1.05) / alto])
    ref = spec.get("referencia")
    colores = ["#C0392B" if ref is not None and v > ref else _AZUL for v in vals]
    y = list(range(len(vals)))
    ax.barh(y, vals, color=colores, height=0.58)
    ax.set_yticks(y, ["\n".join(_lineas(e, 2.2, 8, 2)) for e in etqs], fontsize=8)
    ax.invert_yaxis()
    unidad = f" {spec['unidad']}" if spec.get("unidad") else ""
    for i, v in enumerate(vals):
        ax.text(v, i, f"  {v:g}{unidad}", va="center", fontsize=8, color=_TINTA)
    if ref is not None:
        ax.axvline(ref, color="#B8832B", lw=1.4, ls="--")
        etq = spec.get("referencia_etiqueta") or "Referencia"
        ax_marco.text(_ANCHO - _MARGEN, 0.12,
                      f"- - -  {etq}: {ref:g}{unidad}"
                      + ("   ·   en rojo, lo que la supera" if any(v > ref for v in vals) else ""),
                      fontsize=7.5, color="#B8832B", ha="right", va="bottom")
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(axis="x", labelsize=8)
    ax.margins(x=0.20)
    return fig


def _figura_flujo(spec):
    pasos = spec["pasos"]
    n = len(pasos)
    util = _ANCHO - 2 * _MARGEN
    if n <= 5:
        gap = 0.28
        w = (util - gap * (n - 1)) / n
        h = max(_alto_caja(f"Paso {i + 1}", p, w) for i, p in enumerate(pasos))
        alto = _BANDA + 0.18 + h + _MARGEN + 0.1
        fig, ax = _lienzo(alto)
        y = _cabecera(ax, spec, alto)
        for i, p in enumerate(pasos):
            x = _MARGEN + i * (w + gap)
            _caja(ax, x, y, w, h, fc="#EAF0F7" if i % 2 == 0 else _FONDO, ec=_AZUL,
                  titulo=f"Paso {i + 1}", cuerpo=p)
            if i < n - 1:
                _flecha(ax, x + w + 0.03, y - h / 2, x + w + gap - 0.03, y - h / 2)
        return fig
    w = util - 0.55
    hs = [_alto_caja("", p, w, 8, 3) for p in pasos]
    alto = _BANDA + 0.18 + sum(hs) + 0.16 * (n - 1) + _MARGEN + 0.1
    fig, ax = _lienzo(alto)
    y = _cabecera(ax, spec, alto)
    for i, (p, h) in enumerate(zip(pasos, hs)):
        _caja(ax, _MARGEN + 0.55, y, w, h, fc="#EAF0F7", ec=_AZUL, cuerpo=p, max_lineas=3)
        ax.text(_MARGEN + 0.22, y - h / 2, str(i + 1), fontsize=10, fontweight="bold",
                color="white", ha="center", va="center",
                bbox=dict(boxstyle="circle,pad=0.3", fc=_AZUL, ec="none"))
        if i < n - 1:
            _flecha(ax, _MARGEN + 0.22, y - h / 2 - 0.17, _MARGEN + 0.22, y - h - 0.14, lw=1.0)
        y -= h + 0.16
    return fig


def dibujar(spec: dict, destino: Path, *, dpi: int = 160) -> Path:
    """Dibuja la figura de `spec` (ya validada) en `destino` (PNG)."""
    import matplotlib.pyplot as plt
    fig = {"hallazgo": _figura_hallazgo, "proceso": _figura_proceso,
           "comparacion": _figura_comparacion, "barras": _figura_barras,
           "flujo": _figura_flujo}[spec["tipo"]](spec)
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(destino, format="png", facecolor="white", dpi=dpi)
    plt.close(fig)
    return destino


def describir_tipos() -> str:
    """Catálogo de tipos para el prompt (el formato JSON exacto de cada uno)."""
    return (
        '- "hallazgo" (PREFERIDO para una observación): {"tipo":"hallazgo","titulo":"…",'
        '"criterio":"lo que exige el estándar/manual","condicion":"lo que se encontró",'
        '"causa":"por qué ocurre","efecto":"riesgo o consecuencia","recomendacion":"qué hacer"}. '
        f'Si el texto no dice la causa o el efecto, escribe exactamente "{NO_CONSTA}".\n'
        '- "proceso" (si describe un proceso o cálculo por etapas): {"tipo":"proceso","titulo":"…",'
        '"fases":[{"nombre":"…","pasos":["…"],"estado":"ok|observado|critico"}]} con 2 a 5 '
        'fases de 1 a 5 pasos; marca "observado" o "critico" la fase donde está el problema.\n'
        '- "comparacion" (si contrasta dos fuentes, p. ej. manual vs. código): {"tipo":"comparacion",'
        '"titulo":"…","columnas":["Fuente A","Fuente B"],"filas":[{"aspecto":"…","a":"…","b":"…",'
        '"coincide":true}]} con 2 a 8 filas.\n'
        '- "barras" (solo si compara cifras explícitas): {"tipo":"barras","titulo":"…",'
        '"etiquetas":["…"],"valores":[n],"unidad":"…","referencia":n,"referencia_etiqueta":"umbral"} '
        '(referencia opcional; todas las cifras deben aparecer literalmente en el texto).\n'
        '- "flujo" (secuencia simple): {"tipo":"flujo","titulo":"…","pasos":["…"]} con 3 a 7 pasos.'
    )
