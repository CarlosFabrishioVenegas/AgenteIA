"""
modulos/aprendizaje_controles.py
═══════════════════════════════════════════════════════════════════════════════
APRENDIZAJE DE LOS CONTROLES DE CALIDAD DE DATOS (2026-11-24)

Cómo «sigue aprendiendo» el agente sin reentrenar ningún modelo: guarda, por
DOMINIO (VaR, ALM, LaR…), lo que los validadores ejecutaron DE VERDAD en el
notebook de calidad de datos —los controles propuestos que mantuvieron, con los
umbrales que ajustaron, y los que añadieron ellos— y lo vuelve a proponer en la
siguiente validación del mismo dominio cuando la base tiene esas columnas.

Ciclo
  1. El validador devuelve el Excel del notebook y marca «Enseñar al agente»
     (explícito: nunca se aprende por defecto) → `registrar_revision`.
  2. Cada control ejecutado se convierte en una LECCIÓN (dominio + tipo del
     catálogo + columnas normalizadas) que nace PENDIENTE.
  3. Un REVISOR la aprueba o la niega (`decidir`). El autor no decide sobre la
     suya (mismo criterio que el feedback de puntajes, Paso 25).
  4. `controles_para(dominio, perfiles)` devuelve las lecciones APROBADAS cuyas
     columnas existen en el nuevo perfil, con los parámetros que se aprobaron;
     la propuesta las marca con origen «aprendido».

Qué NO aprende (a propósito)
  · Código. Los controles programados a mano se guardan como CANDIDATOS AL
    CATÁLOGO (descripción y código como texto) para que un desarrollador los
    revise; jamás se ejecutan ni se copian solos a otro notebook.
  · Datos. Solo definiciones (tipo, columnas, parámetros) y cifras agregadas.
  · Resultados del MODO_DEMO (datos sintéticos).
  · Controles de las reglas que se ejecutaron sin cambios: ya se proponen solos.

Olvido
  Un revisor puede NEGAR una lección, y una lección que los validadores
  descartan (comentan su celda) más veces de las que la usan deja de
  proponerse sola.

Registro
  `feedback/aprendizaje_controles.jsonl`, append-only y SELLADO: cada evento
  lleva el hash del anterior, así que `verificar()` detecta ediciones a mano.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

__all__ = ["RUTA", "registrar_revision", "lecciones", "decidir", "controles_para",
           "candidatos", "verificar", "resumen", "dominio_canonico", "clave_leccion"]

RAIZ = Path(__file__).resolve().parent.parent
#: Registro del aprendizaje. Los tests lo redirigen a tmp (conftest).
RUTA = RAIZ / "feedback" / "aprendizaje_controles.jsonl"

DECISIONES = ("aprobado", "negado")
_MIN_MOTIVO = 5


# ─── Normalización ────────────────────────────────────────────────────────────

def _norm_col(nombre: Any) -> str:
    s = unicodedata.normalize("NFKD", str(nombre or ""))
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")


def dominio_canonico(dominio: Optional[str]) -> str:
    """El dominio como lo nombra el repositorio de controles (VaR → var, ALM → alm…)."""
    if not str(dominio or "").strip():
        return ""
    try:
        from modulos.repositorio_controles import carpeta_de_dominio
        c = carpeta_de_dominio(dominio)
    except Exception:                                     # noqa: BLE001
        c = None
    return _norm_col(c or dominio)


def clave_leccion(dominio: str, tipo: str, columnas: list) -> str:
    base = f"{dominio_canonico(dominio)}|{tipo}|{','.join(_norm_col(c) for c in columnas or [])}"
    return hashlib.sha256(base.encode("utf-8")).hexdigest()[:12]


# ─── Registro sellado (append-only) ───────────────────────────────────────────

def _canonico(ev: dict) -> bytes:
    return json.dumps({k: v for k, v in ev.items() if k != "_hash"}, ensure_ascii=False,
                      sort_keys=True, default=str).encode("utf-8")


def _leer(ruta: Optional[Path] = None) -> list[dict]:
    ruta = Path(ruta or RUTA)
    if not ruta.is_file():
        return []
    eventos: list[dict] = []
    for linea in ruta.read_text(encoding="utf-8").splitlines():
        if not linea.strip():
            continue
        try:
            ev = json.loads(linea)
        except ValueError:
            eventos.append({"_corrupto": linea[:200]})
            continue
        eventos.append(ev if isinstance(ev, dict) else {"_corrupto": str(ev)[:200]})
    return eventos


def verificar(ruta: Optional[Path] = None) -> dict[str, Any]:
    """¿Alguien editó el registro a mano? {ok, eventos, rotura (índice o None)}."""
    eventos = _leer(ruta)
    prev = ""
    for i, ev in enumerate(eventos):
        if ("_corrupto" in ev or ev.get("_prev", "") != prev
                or ev.get("_hash") != hashlib.sha256(_canonico(ev)).hexdigest()):
            return {"ok": False, "eventos": len(eventos), "rotura": i}
        prev = ev["_hash"]
    return {"ok": True, "eventos": len(eventos), "rotura": None}


def _anexar(nuevos: list[dict], ruta: Optional[Path] = None) -> None:
    ruta = Path(ruta or RUTA)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    from modulos.document_cache import _lock_archivo
    with _lock_archivo(ruta):
        eventos = _leer(ruta)
        prev = eventos[-1].get("_hash", "") if eventos else ""
        with ruta.open("a", encoding="utf-8", newline="\n") as f:
            for ev in nuevos:
                ev = {**ev, "_prev": prev}
                ev["_hash"] = hashlib.sha256(_canonico(ev)).hexdigest()
                f.write(json.dumps(ev, ensure_ascii=False, sort_keys=True, default=str) + "\n")
                prev = ev["_hash"]


# ─── Registrar lo que el validador ejecutó ────────────────────────────────────

def registrar_revision(dominio: str, filas: list[dict], propuesta: Optional[dict] = None,
                       anexos: Optional[dict] = None, *, autor: str = "", modelo: str = "",
                       codigo_modelo: str = "", revision: str = "",
                       ruta: Optional[Path] = None) -> dict[str, Any]:
    """
    Convierte el cuadro que devolvió el validador en lecciones PENDIENTES.

    `filas`: salida de `controles_ia.leer_tabla_resultados` (trae tipo,
    columnas y parámetros tal como se ejecutaron). `propuesta`: la propuesta
    que originó el notebook (para saber qué se descartó y qué cambió).
    """
    from modulos import controles_ia as ci
    dom = dominio_canonico(dominio)
    if not dom:
        raise ValueError("el modelo no tiene dominio: el aprendizaje se guarda por dominio "
                         "(elígelo en Configuración)")
    if (anexos or {}).get("modo_demo"):
        raise ValueError("el Excel salió del MODO_DEMO (datos sintéticos): no se aprende de él")
    props = {c.get("id"): c for c in (propuesta or {}).get("controles") or [] if c.get("id")}
    comun = {"ts": datetime.now().isoformat(timespec="seconds"),
             "autor": autor or "(sin identificar)", "modelo": modelo or "",
             "codigo_modelo": codigo_modelo or "", "revision": revision or "",
             "propuesta": (propuesta or {}).get("id", "")}
    eventos: list[dict] = []
    avisos: list[str] = []
    ejecutados: set[str] = set()
    sin_cambios = 0
    for f in filas:
        cid = str(f.get("control") or "")
        prop = props.get(cid) or {}
        tipo = str(f.get("tipo") or prop.get("tipo") or "")
        origen = str(f.get("origen") or prop.get("origen") or "")
        if cid:
            ejecutados.add(cid)
        if tipo.startswith("personalizado") or origen == "personalizado":
            continue                         # el código va como candidato (anexos)
        if tipo.startswith("dominio:") or origen == "dominio":
            continue                         # ya vive en el repositorio del tipo de modelo
        if tipo not in ci.CATALOGO:
            if tipo:
                avisos.append(f"{cid}: el tipo «{tipo}» no está en el catálogo; no se aprende.")
            continue
        columnas = [str(c) for c in (f.get("columnas") or prop.get("columnas") or [])]
        params, error = ci.validar_params(tipo, f.get("params") or prop.get("params") or {})
        if not error and not ci.columnas_validas(tipo, len(columnas), params):
            error = f"columnas no válidas para {tipo}"
        if error:
            avisos.append(f"{cid}: {error}; no se aprende.")
            continue
        if origen in ("reglas", "batería", "tipo de modelo"):
            params_prop, _ = ci.validar_params(tipo, prop.get("params") or {})
            if params == params_prop:
                sin_cambios += 1             # el agente ya lo propone solo, tal cual
                continue
        eventos.append({
            "evento": "uso", "clave": clave_leccion(dom, tipo, columnas), "dominio": dom,
            "tipo": tipo, "dimension": ci.CATALOGO[tipo]["dimension"],
            "dataset": str(f.get("dataset") or prop.get("dataset") or ""),
            "columnas": columnas, "columnas_norm": [_norm_col(c) for c in columnas],
            "params": params,
            "descripcion": " ".join(str(f.get("descripcion") or prop.get("descripcion") or "").split())[:300],
            "criticidad": (str(f.get("criticidad") or prop.get("criticidad") or "MEDIA").upper()
                           if str(f.get("criticidad") or prop.get("criticidad") or "MEDIA").upper()
                           in ("ALTA", "MEDIA", "BAJA") else "MEDIA"),
            "evidencia": " ".join(str(prop.get("evidencia_requerida") or "").split())[:300],
            "origen": origen or "validador", "decision": str(f.get("decision") or ""),
            "pct_incumplimiento": f.get("pct_incumplimiento"), **comun})
    # Lo aprendido que se propuso y el validador quitó del notebook.
    for cid, c in props.items():
        if cid in ejecutados or c.get("origen") != "aprendido":
            continue
        eventos.append({"evento": "descarte",
                        "clave": c.get("leccion") or clave_leccion(dom, c.get("tipo", ""), c.get("columnas") or []),
                        "dominio": dom, "tipo": c.get("tipo", ""), "columnas": c.get("columnas") or [],
                        **comun})
    # Controles programados: candidatos al catálogo, como TEXTO.
    for p in (anexos or {}).get("personalizados") or []:
        codigo = str(p.get("Código") or "")[:30000]
        eventos.append({
            "evento": "candidato",
            "clave": hashlib.sha256(f"{dom}|{p.get('Función')}|{codigo}".encode("utf-8")).hexdigest()[:12],
            "dominio": dom, "funcion": str(p.get("Función") or "")[:120],
            "descripcion": str(p.get("Descripción") or "")[:300],
            "dimension": str(p.get("Dimensión") or "")[:60],
            "columnas": str(p.get("Columnas") or "")[:300],
            "params": str(p.get("Parámetros") or "")[:1000], "codigo": codigo, **comun})
    if eventos:
        _anexar(eventos, ruta)
    usos = [e for e in eventos if e["evento"] == "uso"]
    return {"dominio": dom, "usos": len(usos),
            "descartes": sum(1 for e in eventos if e["evento"] == "descarte"),
            "candidatos": sum(1 for e in eventos if e["evento"] == "candidato"),
            "sin_cambios": sin_cambios,
            "lecciones": sorted({e["clave"] for e in usos}), "avisos": avisos}


# ─── Estado de las lecciones ──────────────────────────────────────────────────

def _nueva(ev: dict) -> dict[str, Any]:
    return {"id": ev["clave"], "dominio": ev.get("dominio", ""), "tipo": ev.get("tipo", ""),
            "dimension": ev.get("dimension", ""), "columnas": ev.get("columnas") or [],
            "columnas_norm": ev.get("columnas_norm") or [], "descripcion": "", "criticidad": "MEDIA",
            "evidencia": "", "origenes": set(), "params_vigentes": {}, "params_aprobados": None,
            "usos": 0, "no_cumple": 0, "no_evaluable": 0, "descartes": 0, "modelos": set(),
            "autores": set(), "primera": ev.get("ts", ""), "ultima": ev.get("ts", ""),
            "estado": "pendiente", "decision_por": "", "decision_fecha": "", "motivo": ""}


def lecciones(dominio: Optional[str] = None, ruta: Optional[Path] = None) -> list[dict[str, Any]]:
    """Lecciones agregadas (todas, o las de un dominio), pendientes primero."""
    dom = dominio_canonico(dominio) if dominio else None
    out: dict[str, dict] = {}
    for ev in _leer(ruta):
        k, que = ev.get("clave"), ev.get("evento")
        if not k:
            continue
        if que == "uso":
            l = out.setdefault(k, _nueva(ev))
            l.update({"columnas": ev.get("columnas") or l["columnas"],
                      "columnas_norm": ev.get("columnas_norm") or l["columnas_norm"],
                      "descripcion": ev.get("descripcion") or l["descripcion"],
                      "criticidad": ev.get("criticidad") or l["criticidad"],
                      "evidencia": ev.get("evidencia") or l["evidencia"],
                      "params_vigentes": ev.get("params") or {}, "ultima": ev.get("ts", "")})
            l["usos"] += 1
            l["no_cumple"] += ev.get("decision") == "No cumple"
            l["no_evaluable"] += ev.get("decision") == "No evaluable"
            l["origenes"].add(ev.get("origen", ""))
            l["modelos"].add(ev.get("codigo_modelo") or ev.get("modelo") or "")
            l["autores"].add(ev.get("autor", ""))
        elif que == "descarte" and k in out:
            out[k]["descartes"] += 1
        elif que == "decision" and k in out and ev.get("decision") in DECISIONES:
            l = out[k]
            l.update({"estado": ev["decision"], "decision_por": ev.get("quien", ""),
                      "decision_fecha": ev.get("ts", ""), "motivo": ev.get("motivo", ""),
                      "params_aprobados": ev.get("params") if ev["decision"] == "aprobado" else None})
    salida = []
    for l in out.values():
        if dom and l["dominio"] != dom:
            continue
        l["origenes"] = sorted(x for x in l["origenes"] if x)
        l["modelos"] = sorted(x for x in l["modelos"] if x)
        l["autores"] = sorted(x for x in l["autores"] if x)
        l["activa"] = l["estado"] == "aprobado" and l["usos"] > l["descartes"]
        l["cambio_desde_aprobacion"] = (l["params_aprobados"] is not None
                                        and l["params_vigentes"] != l["params_aprobados"])
        salida.append(l)
    orden = {"pendiente": 0, "aprobado": 1, "negado": 2}
    salida.sort(key=lambda l: (orden.get(l["estado"], 3), -l["usos"], l["id"]))
    return salida


def resumen(dominio: Optional[str] = None, ruta: Optional[Path] = None) -> dict[str, int]:
    ls = lecciones(dominio, ruta)
    return {"total": len(ls), "pendientes": sum(1 for l in ls if l["estado"] == "pendiente"),
            "aprobadas": sum(1 for l in ls if l["estado"] == "aprobado"),
            "activas": sum(1 for l in ls if l["activa"]),
            "negadas": sum(1 for l in ls if l["estado"] == "negado")}


def decidir(clave: str, decision: str, *, quien: str, motivo: str,
            ruta: Optional[Path] = None) -> dict[str, Any]:
    """Un REVISOR aprueba o niega una lección. Al aprobar se congelan sus parámetros."""
    if decision not in DECISIONES:
        raise ValueError(f"decisión no válida: {decision!r} (aprobado | negado)")
    motivo = " ".join(str(motivo or "").split())
    if len(motivo) < _MIN_MOTIVO:
        raise ValueError("explica el motivo de la decisión (mínimo 5 caracteres)")
    if not str(quien or "").strip():
        raise PermissionError("decidir sobre una lección exige una identidad")
    actual = next((l for l in lecciones(ruta=ruta) if l["id"] == clave), None)
    if actual is None:
        raise KeyError(f"no existe la lección {clave}")
    if quien in actual["autores"]:
        raise PermissionError("quien enseñó una lección no puede decidir sobre ella")
    _anexar([{"evento": "decision", "clave": clave, "decision": decision, "motivo": motivo[:300],
              "quien": quien, "ts": datetime.now().isoformat(timespec="seconds"),
              "params": actual["params_vigentes"] if decision == "aprobado" else None}], ruta)
    return next(l for l in lecciones(ruta=ruta) if l["id"] == clave)


# ─── Volver a proponer lo aprendido ───────────────────────────────────────────

def controles_para(dominio: str, perfiles: list[dict], *, maximo: int = 25,
                   ruta: Optional[Path] = None) -> tuple[list[dict], list[str]]:
    """
    Controles APRENDIDOS (aprobados y activos) del dominio cuyas columnas
    existen en el perfil, con los parámetros aprobados. (controles, avisos).
    """
    from modulos import controles_ia as ci
    dom = dominio_canonico(dominio)
    if not dom:
        return [], []
    activas = [l for l in lecciones(dom, ruta) if l["activa"]]
    activas.sort(key=lambda l: (-l["no_cumple"], -l["usos"], l["id"]))
    controles: list[dict] = []
    avisos: list[str] = []
    for l in activas:
        if l["tipo"] not in ci.CATALOGO:
            continue
        params, error = ci.validar_params(l["tipo"], l["params_aprobados"] or {})
        if error:
            avisos.append(f"lección {l['id']} ({l['tipo']}): {error}; no se propone.")
            continue
        for p in perfiles:
            por_norm = {_norm_col(c["nombre"]): c["nombre"] for c in p["columnas"]}
            if not all(cn in por_norm for cn in l["columnas_norm"]):
                continue
            if l["tipo"] in ci._CON_REFERENCIA_BASE:
                ref = next((q for q in perfiles if q["nombre"] == params.get("ref_dataset")), None)
                if ref is None or (params.get("ref_columna")
                                   and params["ref_columna"] not in {c["nombre"] for c in ref["columnas"]}):
                    avisos.append(f"lección {l['id']} ({l['tipo']}): la base de referencia "
                                  f"«{params.get('ref_dataset')}» no está en este perfil; no se propone.")
                    continue
            c = ci._control(
                p["nombre"], l["tipo"], [por_norm[cn] for cn in l["columnas_norm"]], dict(params),
                l["descripcion"] or ci.CATALOGO[l["tipo"]]["descripcion"],
                f"Aprendido en el dominio {dom}: aprobado por {l['decision_por']} el "
                f"{(l['decision_fecha'] or '')[:10]}; ejecutado en {l['usos']} validación(es), "
                f"{l['no_cumple']} con incumplimiento.",
                l["criticidad"], l["evidencia"], origen="aprendido")
            c["leccion"] = l["id"]
            controles.append(c)
            if len(controles) >= maximo:
                return controles, avisos
    return controles, avisos


def candidatos(dominio: Optional[str] = None, ruta: Optional[Path] = None) -> list[dict[str, Any]]:
    """Controles programados por validadores: candidatos a entrar en el catálogo."""
    dom = dominio_canonico(dominio) if dominio else None
    vistos: dict[str, dict] = {}
    for ev in _leer(ruta):
        if ev.get("evento") != "candidato" or (dom and ev.get("dominio") != dom):
            continue
        c = vistos.setdefault(ev["clave"], {
            **{k: ev.get(k, "") for k in ("clave", "dominio", "funcion", "descripcion", "dimension",
                                          "columnas", "params", "codigo")},
            "veces": 0, "modelos": set(), "autores": set(), "ultima": ""})
        c["veces"] += 1
        c["modelos"].add(ev.get("codigo_modelo") or ev.get("modelo") or "")
        c["autores"].add(ev.get("autor", ""))
        c["ultima"] = ev.get("ts", "")
    out = sorted(vistos.values(), key=lambda c: (-c["veces"], c["funcion"]))
    for c in out:
        c["modelos"] = sorted(x for x in c["modelos"] if x)
        c["autores"] = sorted(x for x in c["autores"] if x)
    return out
