"""
modulos/controles_ia.py
═══════════════════════════════════════════════════════════════════════════════
CONTROLES DE DATOS ASISTIDOS POR IA a partir de `.info()` y `.describe()`.

El validador no sube los datos (viven en el entorno del banco): pega la salida
de `df.info()` y `df.describe(include="all")` de cada base. Con ese PERFIL —
columnas, tipos, nulos, rangos, únicos— el agente:

  1. propone controles de calidad de datos específicos para esas columnas
     (reglas deterministas + IA opcional; cada control dice qué del perfil lo
     motiva, p. ej. «info(): 985 de 1000 no nulos»);
  2. entrega un NOTEBOOK AUTOCONTENIDO (solo pandas/numpy: no necesita VIRF
     instalado) para ejecutarlo en local, que llena las COLUMNAS DE CUMPLIMIENTO
     (% de cumplimiento, diagnóstico, decisión…) y guarda un Excel;
  3. REVISA ese Excel cuando el validador lo devuelve: coherencia entre lo
     medido y lo decidido, controles que no se ejecutaron, y observaciones
     (riesgo, observación, recomendación). El mismo Excel, guardado en
     `calidad_datos/resultadocalidad_de_datos/`, lo lee el pipeline
     (`modulos/motores_entidad.py`) en el ámbito Calidad de datos.

Principios (los del proyecto):
  · La IA solo PROPONE. Todo control se valida aquí: tipo del catálogo,
    columnas que existen en el perfil, parámetros con el tipo correcto y ninguna
    cifra en la justificación que no esté en el perfil. Lo que no pasa se
    descarta y se dice por qué.
  · Nada se ejecuta en el servidor: el notebook corre donde están los datos; su
    código se valida con `ast.parse`, nunca con `exec`.
  · Dos modos explícitos (`usar_ia`), nunca deducidos.

Las llamadas a la IA pasan por `modulos.notebook_controles.llamar_ia_controles`
(componente nº 5 del inventario de IA: «Proponer controles de calidad de datos»).
"""
from __future__ import annotations

import ast
import io
import json
import re
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Optional

__all__ = [
    "parsear_info", "parsear_describe", "perfil_dataset", "perfil_texto",
    "CATALOGO", "proponer", "proponer_deterministas", "normalizar_propuesta",
    "construir_notebook", "leer_tabla_resultados", "leer_anexos", "revisar_resultados",
    "COLUMNAS_SALIDA", "HOJAS_SALIDA", "GUIA_PRENDER_MD", "tabla_catalogo_md",
    "validar_params", "columnas_de_tipo",
]


def _sin_tildes(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", str(s or ""))
                   if not unicodedata.combining(c)).lower().strip()


def _num(v: Any) -> Optional[float]:
    try:
        f = float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None
    return None if f != f else f                        # NaN → None


# ═════════════════════════════════════════════════════════════════════════════
# 1. LECTURA DE .info() Y .describe()  (determinista, sin IA)
# ═════════════════════════════════════════════════════════════════════════════

_RE_ENTRADAS = re.compile(r"(?:RangeIndex|Int64Index|Index|DatetimeIndex|MultiIndex)\s*:\s*"
                          r"(\d+)\s+entries", re.IGNORECASE)
_RE_FILA_INFO = re.compile(r"^\s*(\d+)\s+(.+?)\s+(\d+)\s+non-null\s+(\S+)\s*$")
_RE_FILA_INFO_VIEJA = re.compile(r"^\s*(\S.*?)\s+(\d+)\s+non-null\s+(\S+)\s*$")
_RE_SPARK = re.compile(r"^\s*\|--\s*([^:]+?)\s*:\s*([A-Za-z_]+)")


def parsear_info(texto: str) -> dict[str, Any]:
    """
    Columnas, tipos y no nulos de la salida de `df.info()` (pandas ≥ 1 y el
    formato antiguo sin «#»). También acepta `df.printSchema()` de Spark (sin
    conteos). Devuelve {filas, columnas: [{nombre, no_nulos, dtype}], formato}.
    """
    t = texto or ""
    filas = None
    m = _RE_ENTRADAS.search(t)
    if m:
        filas = int(m.group(1))
    columnas: list[dict] = []
    formato = "pandas"
    for linea in t.splitlines():
        if linea.strip().startswith(("#", "---", "<class", "Data columns", "dtypes:",
                                     "memory usage", "Columns:")):
            continue
        ms = _RE_SPARK.match(linea)
        if ms:
            formato = "spark"
            columnas.append({"nombre": ms.group(1).strip(), "no_nulos": None,
                             "dtype": ms.group(2).lower()})
            continue
        mi = _RE_FILA_INFO.match(linea) or _RE_FILA_INFO_VIEJA.match(linea)
        if not mi:
            continue
        g = mi.groups()
        nombre, nn, dtype = (g[1], g[2], g[3]) if len(g) == 4 else (g[0], g[1], g[2])
        columnas.append({"nombre": nombre.strip(), "no_nulos": int(nn), "dtype": dtype.lower()})
    return {"filas": filas, "columnas": columnas, "formato": formato}


_STATS = ("count", "unique", "top", "freq", "mean", "std", "min", "25%", "50%", "75%",
          "max", "first", "last", "stddev")


def _spans_cabecera(linea: str) -> list[tuple[str, int, int]]:
    """Nombres de columna de una cabecera de pandas (separados por ≥2 espacios)."""
    linea = linea.rstrip().rstrip("\\").rstrip()
    return [(m.group(0), m.start(), m.end()) for m in re.finditer(r"\S+(?: \S+)*", linea)]


def parsear_describe(texto: str) -> dict[str, dict[str, Any]]:
    """
    Estadísticos por columna de `df.describe()` (pandas, también ancho en
    varios bloques, transpuesto con `.T`, o la tabla `+---+` de Spark
    `describe().show()`). Devuelve {columna: {estadístico: valor}}.
    """
    t = (texto or "").replace("\t", "    ")
    lineas = [l for l in t.splitlines()]
    salida: dict[str, dict[str, Any]] = {}

    def _valor(s: str) -> Any:
        s = s.strip()
        if s in ("", "NaN", "nan", "None", "null", "<NA>"):
            return None
        n = _num(s)
        return n if n is not None else s

    # Spark: |summary| col1| col2|
    tabla = [l for l in lineas if l.strip().startswith("|")]
    if tabla:
        celdas = [[c.strip() for c in l.strip().strip("|").split("|")] for l in tabla]
        cab = celdas[0]
        if cab and cab[0].lower() == "summary":
            for fila in celdas[1:]:
                if len(fila) != len(cab):
                    continue
                stat = fila[0].lower()
                for col, v in zip(cab[1:], fila[1:]):
                    salida.setdefault(col, {})[stat] = _valor(v)
            return salida

    cols: list[tuple[str, int, int]] = []
    transpuesto = False
    for linea in lineas:
        if not linea.strip():
            continue
        primera = linea.strip().split()[0].lower()
        if cols and not transpuesto and primera in _STATS:
            ini = 0
            stat = primera
            for nombre, _a, fin in cols:
                v = linea[ini:fin] if fin <= len(linea) else linea[ini:]
                if ini == 0:                        # el primer tramo lleva la etiqueta
                    v = v.strip()[len(stat):]
                salida.setdefault(nombre, {})[stat] = _valor(v)
                ini = fin
            continue
        if cols and transpuesto:
            # Fila «columna  count  mean …»: el nombre ocupa hasta la primera cifra.
            partes = linea.split()
            nvals = len(cols)
            if len(partes) > nvals:
                nombre = " ".join(partes[:len(partes) - nvals])
                for (stat, *_), v in zip(cols, partes[len(partes) - nvals:]):
                    salida.setdefault(nombre, {})[stat] = _valor(v)
            continue
        # Cabecera de un bloque.
        spans = _spans_cabecera(linea)
        if not spans:
            continue
        nombres = [s[0].lower() for s in spans]
        if sum(1 for n in nombres if n in _STATS) >= 3:
            transpuesto = True
            cols = [(n, a, b) for n, a, b in spans]
        else:
            transpuesto = False
            cols = spans
    return salida


def perfil_dataset(nombre: str, info: str = "", describe: str = "") -> dict[str, Any]:
    """Perfil de una base: filas y, por columna, tipo, nulos y estadísticos."""
    pi = parsear_info(info)
    pd_ = parsear_describe(describe)
    avisos: list[str] = []
    filas = pi["filas"]
    if filas is None:
        conteos = [_num(s.get("count")) for s in pd_.values() if _num(s.get("count")) is not None]
        if conteos:
            filas = int(max(conteos))
            avisos.append("El número de filas se tomó del «count» máximo del describe "
                          "(el .info() no lo trae).")
    columnas: list[dict] = []
    vistos = set()
    for c in pi["columnas"]:
        stats = pd_.get(c["nombre"], {})
        nn = c["no_nulos"]
        nulos = (filas - nn) if (filas is not None and nn is not None) else None
        columnas.append({**c, "nulos": nulos,
                         "pct_nulos": round(100 * nulos / filas, 2) if nulos is not None and filas else None,
                         "stats": stats})
        vistos.add(c["nombre"])
    for col, stats in pd_.items():                  # columnas solo en el describe
        if col not in vistos:
            cnt = _num(stats.get("count"))
            nulos = int(filas - cnt) if (filas is not None and cnt is not None) else None
            columnas.append({"nombre": col, "no_nulos": int(cnt) if cnt is not None else None,
                             "dtype": "numérico" if _num(stats.get("mean")) is not None else "?",
                             "nulos": nulos,
                             "pct_nulos": round(100 * nulos / filas, 2) if nulos is not None and filas else None,
                             "stats": stats})
    if not columnas:
        avisos.append("No se reconoció ninguna columna: pega la salida completa de "
                      "df.info() (y opcionalmente df.describe(include='all')).")
    return {"nombre": nombre, "filas": filas, "columnas": columnas, "avisos": avisos,
            "formato": pi["formato"]}


def perfil_texto(perfiles: list[dict], tope: int = 14000) -> str:
    """Perfil en texto compacto para el prompt (y vara de las cifras)."""
    partes = []
    for p in perfiles:
        partes.append(f"Dataset «{p['nombre']}» — filas: {p['filas'] if p['filas'] is not None else 'N/D'}")
        for c in p["columnas"]:
            s = c.get("stats") or {}
            st = ", ".join(f"{k}={v}" for k, v in s.items() if v is not None)
            partes.append(f"  - {c['nombre']} ({c['dtype']}): no nulos={c['no_nulos']}, "
                          f"nulos={c['nulos']}" + (f"; {st}" if st else ""))
    return "\n".join(partes)[:tope]


# ═════════════════════════════════════════════════════════════════════════════
# 2. CATÁLOGO DE CONTROLES (código autocontenido que va en el notebook)
# ═════════════════════════════════════════════════════════════════════════════

#: tipo → (dimensión, descripción, parámetros admitidos {nombre: tipo})
CATALOGO: dict[str, dict[str, Any]] = {
    "completitud":   {"dimension": "Completitud", "params": {"umbral_pct": float},
                      "descripcion": "Filas con nulos en las columnas (sobre el total)."},
    "unicidad":      {"dimension": "Unicidad", "params": {"umbral_pct": float},
                      "descripcion": "Filas con la llave (columnas) repetida; sin columnas, filas idénticas."},
    "rango":         {"dimension": "Validez", "params": {"minimo": float, "maximo": float, "umbral_pct": float},
                      "descripcion": "Valores fuera de [minimo, maximo]."},
    "no_negativos":  {"dimension": "Validez", "params": {"umbral_pct": float},
                      "descripcion": "Valores negativos donde no corresponden."},
    "dominio":       {"dimension": "Validez", "params": {"valores": list, "umbral_pct": float},
                      "descripcion": "Valores fuera de la lista permitida."},
    "tipo_numerico": {"dimension": "Validez", "params": {"umbral_pct": float},
                      "descripcion": "Valores no convertibles a número."},
    "fecha_valida":  {"dimension": "Validez", "params": {"desde": str, "hasta": str, "umbral_pct": float},
                      "descripcion": "Fechas no legibles o fuera de [desde, hasta]."},
    "frescura":      {"dimension": "Actualidad", "params": {"max_dias": float},
                      "descripcion": "Días entre la fecha más reciente y la de referencia."},
    "volumen_minimo": {"dimension": "Completitud", "params": {"min_filas": float},
                       "descripcion": "La base trae al menos `min_filas` filas."},
    "constante":     {"dimension": "Validez", "params": {},
                      "descripcion": "La columna no es constante (más de un valor distinto)."},
    "outliers_iqr":  {"dimension": "Exactitud", "params": {"k": float, "umbral_pct": float},
                      "descripcion": "Valores fuera de [Q1 − k·IQR, Q3 + k·IQR]."},
    "consistencia":  {"dimension": "Consistencia", "params": {"operador": str, "umbral_pct": float},
                      "descripcion": "Relación entre dos columnas (a <= b, a < b, …)."},
    "formato":       {"dimension": "Validez", "params": {"patron": str, "umbral_pct": float},
                      "descripcion": "Valores que no cumplen la expresión regular."},
    "integridad":    {"dimension": "Consistencia", "params": {"ref_dataset": str, "ref_columna": str,
                                                              "umbral_pct": float},
                      "descripcion": "Valores sin correspondencia en otra base (integridad referencial)."},
    "suma_control":  {"dimension": "Exactitud", "params": {"valor_esperado": float, "tolerancia_pct": float},
                      "descripcion": "La suma de la columna cuadra con un total de control."},
    "completitud_condicional": {"dimension": "Completitud", "params": {"valores": list, "umbral_pct": float},
                                "descripcion": "Si la 1.ª columna tiene valor (o uno de `valores`), la 2.ª "
                                               "no puede estar vacía."},
    "valores_centinela": {"dimension": "Completitud", "params": {"valores": list, "umbral_pct": float},
                          "descripcion": "Valores que disfrazan un nulo (-999, 99999999, 1900-01-01, «N/A»…); "
                                         "sin `valores`, usa la lista habitual."},
    "serie_continua": {"dimension": "Completitud", "params": {"frecuencia": str, "excluir": list,
                                                               "umbral_pct": float},
                       "descripcion": "Periodos que faltan en la serie entre su primera y su última fecha "
                                      "(frecuencia D, B, W, M o Q; `excluir` = feriados)."},
    "estabilidad_psi": {"dimension": "Consistencia", "params": {"umbral_psi": float, "bins": float},
                        "descripcion": "Estabilidad de la 1.ª columna entre el primer y el último periodo "
                                       "de la 2.ª (índice PSI; más de 0,25 = cambio relevante)."},
    "longitud":      {"dimension": "Validez", "params": {"minimo": float, "maximo": float, "umbral_pct": float},
                      "descripcion": "Textos cuya longitud (sin espacios extremos) cae fuera de [minimo, maximo] "
                                     "(DNI 8, RUC 11, códigos de N dígitos…)."},
    "espacios_extremos": {"dimension": "Validez", "params": {"umbral_pct": float},
                          "descripcion": "Textos con espacios al inicio o al final, o con espacios dobles."},
    "caracteres_invalidos": {"dimension": "Validez", "params": {"umbral_pct": float},
                             "descripcion": "Textos con caracteres de control, el carácter de reemplazo «�» o "
                                            "restos de una mala codificación («Ã», «Â»)."},
    "categorias_equivalentes": {"dimension": "Consistencia", "params": {"umbral_pct": float},
                                "descripcion": "Categorías que solo difieren en mayúsculas, tildes o espacios "
                                               "(«Pyme», «PYME», «pyme »): filas que no usan la forma principal."},
    "fecha_futura":  {"dimension": "Validez", "params": {"umbral_pct": float},
                      "descripcion": "Fechas posteriores a la fecha de referencia (FECHA_REFERENCIA o hoy)."},
    "consistencia_fechas": {"dimension": "Consistencia", "params": {"operador": str, "umbral_pct": float},
                            "descripcion": "Relación entre dos columnas de fecha (inicio <= fin, desembolso <= corte…)."},
    "proporcion_ceros": {"dimension": "Completitud", "params": {"umbral_pct": float},
                         "descripcion": "Proporción de ceros exactos (un cero puede disfrazar un dato faltante)."},
    "cardinalidad":  {"dimension": "Validez", "params": {"minimo": float, "maximo": float},
                      "descripcion": "Número de valores distintos dentro de [minimo, maximo] (p. ej. 3 a 5 segmentos)."},
    "conciliacion_totales": {"dimension": "Exactitud", "params": {"ref_dataset": str, "ref_columna": str,
                                                                  "tolerancia_pct": float},
                             "descripcion": "La suma de la columna cuadra con la suma de una columna de otra base "
                                            "(cartera vs contabilidad) dentro de la tolerancia."},
    "conciliacion_conteos": {"dimension": "Completitud", "params": {"ref_dataset": str, "tolerancia_pct": float},
                             "descripcion": "El número de filas cuadra con el de otra base dentro de la tolerancia."},
    "variacion_temporal": {"dimension": "Consistencia", "params": {"agregacion": str, "max_variacion_pct": float,
                                                                   "umbral_pct": float},
                           "descripcion": "Variación entre periodos consecutivos del total (sum, count o mean) de la "
                                          "1.ª columna por la 2.ª (periodo): saltos mayores que max_variacion_pct."},
    # ── Tipos de negocio (2026-11-24): series de mercado, paneles, identidades y bandas ──
    "valores_repetidos": {"dimension": "Actualidad", "params": {"max_repeticiones": float, "umbral_pct": float},
                          "descripcion": "Valores «rancios»: la 1.ª columna repite el mismo valor más de "
                                         "`max_repeticiones` observaciones seguidas, ordenando por la 2.ª (fecha) y "
                                         "por grupo si hay 3.ª (factor, segmento) y 4.ª (p. ej. cosecha)."},
    "saltos_serie": {"dimension": "Exactitud", "params": {"k": float, "umbral_pct": float, "agregar": str},
                     "descripcion": "Saltos entre observaciones consecutivas de la 1.ª columna (orden de la 2.ª, por "
                                    "grupo de la 3.ª y la 4.ª si las hay) de más de `k` desviaciones robustas "
                                    "(mediana y MAD). Con `agregar` = suma, antes se suman las filas de cada grupo y "
                                    "fecha (el saldo total del segmento cuando la base viene por cosecha o cuenta)."},
    "monotonia": {"dimension": "Consistencia", "params": {"sentido": str, "umbral_pct": float},
                  "descripcion": "En cada fila las columnas siguen el orden dado (creciente: 1.ª ≤ 2.ª ≤ …; p. ej. "
                                 "VaR 95 ≤ VaR 99 ≤ ES)."},
    "monotonia_curva": {"dimension": "Consistencia", "params": {"sentido": str, "umbral_pct": float},
                        "descripcion": "La 1.ª columna es monótona al ordenar por la 2.ª (plazo, tenor «1M/1Y» o "
                                       "fecha) dentro de cada grupo de las siguientes (factor de descuento que baja "
                                       "con el plazo, curva de supervivencia que nunca sube)."},
    "relacion_aritmetica": {"dimension": "Exactitud", "params": {"operacion": str, "tolerancia_pct": float,
                                                                 "umbral_pct": float, "valor": float},
                            "descripcion": "La última columna es la suma, resta (1.ª − resto), producto o cociente de "
                                           "las anteriores dentro de la tolerancia (saldo final = inicial − "
                                           "amortización − prepago); con `valor`, la operación de TODAS las columnas "
                                           "da ese valor (estable + volátil = 1)."},
    "diferencia_relativa": {"dimension": "Exactitud", "params": {"tolerancia_pct": float, "umbral_pct": float},
                            "descripcion": "Filas donde la 1.ª y la 2.ª columna difieren más de `tolerancia_pct` % "
                                           "(precio del modelo vs independiente, reportado vs recalculado)."},
    "categorias_requeridas": {"dimension": "Completitud", "params": {"valores": list, "umbral_pct": float},
                              "descripcion": "Todas las categorías de `valores` aparecen en la columna (los seis "
                                             "escenarios IRRBB, todas las bandas, todas las monedas)."},
    "combinaciones_completas": {"dimension": "Completitud", "params": {"umbral_pct": float},
                                "descripcion": "Panel completo: están todas las combinaciones de la 1.ª y la 2.ª "
                                               "columna (fecha × factor, escenario × factor), por grupo de la 3.ª."},
    "minimo_por_grupo": {"dimension": "Completitud", "params": {"min_filas": float, "umbral_pct": float},
                         "descripcion": "Cada grupo de las columnas tiene al menos `min_filas` filas (ventana mínima "
                                        "por factor, historia mínima por segmento)."},
    "suma_por_grupo": {"dimension": "Exactitud", "params": {"valor_esperado": float, "tolerancia_pct": float,
                                                            "umbral_pct": float},
                       "descripcion": "La suma de la 1.ª columna en cada grupo de las siguientes es `valor_esperado` "
                                      "(pesos o proporciones que suman 1 por segmento)."},
    "conciliacion_por_grupo": {"dimension": "Exactitud", "params": {"ref_dataset": str, "ref_columna": str,
                                                                    "ref_claves": list, "tolerancia_pct": float,
                                                                    "umbral_pct": float, "pareja": str},
                               "descripcion": "La suma de la 1.ª columna por las claves (resto de columnas) cuadra con "
                                              "la de otra base por sus claves `ref_claves` (por moneda, por fecha, por "
                                              "operación). Con `pareja=\"base\"` solo se exigen los grupos de esta "
                                              "base (p. ej. el corte de las bandas frente a un balance con historia)."},
    "signo_por_categoria": {"dimension": "Validez", "params": {"positivos": list, "negativos": list,
                                                               "umbral_pct": float},
                            "descripcion": "La 1.ª columna es ≥ 0 en las categorías `positivos` y ≤ 0 en "
                                           "`negativos` de la 2.ª (activos vs pasivos, entradas vs salidas)."},
    "banda_coherente": {"dimension": "Consistencia", "params": {"limites": list, "etiquetas": list,
                                                                "umbral_pct": float},
                        "descripcion": "La banda (2.ª columna) corresponde a los días (1.ª): la banda i va de "
                                       "limites[i] (incluido) a limites[i+1] (excluido)."},
    "fechas_habiles": {"dimension": "Validez", "params": {"excluir": list, "umbral_pct": float},
                       "descripcion": "Fechas en fin de semana o en los feriados de `excluir` (series diarias de "
                                      "mercado)."},
}

_OPERADORES = ("<=", "<", ">=", ">", "==", "!=")
_FRECUENCIAS = ("D", "B", "W", "M", "Q")
_AGREGACIONES = ("sum", "count", "mean")
#: Cuántas columnas usa cada tipo (None = 1 o más).
_N_COLUMNAS = {"completitud": None, "unicidad": None, "consistencia": 2, "volumen_minimo": 0,
               "completitud_condicional": 2, "estabilidad_psi": 2, "consistencia_fechas": 2,
               "variacion_temporal": 2, "conciliacion_conteos": 0, "diferencia_relativa": 2,
               "signo_por_categoria": 2, "banda_coherente": 2}
#: Tipos con un RANGO de columnas (mínimo, máximo; None = sin máximo).
_N_RANGO = {"valores_repetidos": (2, 4), "saltos_serie": (2, 4), "monotonia": (2, None),
            "monotonia_curva": (2, 4), "relacion_aritmetica": (3, None), "combinaciones_completas": (2, 3),
            "minimo_por_grupo": (1, None), "suma_por_grupo": (2, None), "conciliacion_por_grupo": (2, None)}
#: Tipos que reciben la fecha de referencia del notebook (FECHA_REFERENCIA).
_CON_REFERENCIA = ("frescura", "fecha_futura")
#: Tipos que cruzan con otra base (`ref_dataset` debe estar en el perfil).
_CON_REFERENCIA_BASE = ("integridad", "conciliacion_totales", "conciliacion_conteos", "conciliacion_por_grupo")
_SENTIDOS = ("creciente", "decreciente")
_OPERACIONES = ("suma", "resta", "producto", "cociente")


def columnas_de_tipo(tipo: str) -> Optional[int]:
    """Columnas que usa un tipo del catálogo (None = una o más, o un rango; 0 = ninguna).
    Para validar un número concreto usa `columnas_validas`."""
    if tipo in _N_RANGO:
        return None
    return _N_COLUMNAS.get(tipo, 1)


def columnas_validas(tipo: str, n: int, params: Optional[dict] = None) -> bool:
    """¿`n` columnas valen para el tipo? (cociente: exactamente 3)."""
    if tipo == "relacion_aritmetica":
        constante = (params or {}).get("valor") not in (None, "")     # todas las columnas operan contra un valor
        if str((params or {}).get("operacion") or "").lower() == "cociente":
            return n == (2 if constante else 3)
        return n >= (2 if constante else 3)
    if tipo in _N_RANGO:
        lo, hi = _N_RANGO[tipo]
        return n >= lo and (hi is None or n <= hi)
    req = _N_COLUMNAS.get(tipo, 1)
    if req is None:
        return n >= 1 or tipo == "unicidad"
    if req == 0:
        return True                      # no usa columnas: las que traiga se ignoran
    return n == req


def columnas_texto(tipo: str) -> str:
    """Cuántas columnas usa un tipo, en palabras (para la tabla del catálogo)."""
    if tipo in _N_RANGO:
        lo, hi = _N_RANGO[tipo]
        return f"{lo} o más" if hi is None else (f"{lo} o {hi}" if hi == lo + 1 else f"{lo} a {hi}")
    n = _N_COLUMNAS.get(tipo, 1)
    return "1 o más" if n is None else ("ninguna" if n == 0 else str(n))


def validar_params(tipo: str, crudos: Any) -> tuple[dict, str]:
    """
    Parámetros de un control del catálogo con su tipo correcto. Devuelve
    (params, error); `error` vacío si todo es válido. No mira el perfil: eso
    (columnas, base de referencia) lo comprueba quien llama.
    """
    params: dict[str, Any] = {}
    error = ""
    crudos = crudos if isinstance(crudos, dict) else {}
    for k, tipo_p in CATALOGO[tipo]["params"].items():
        v = crudos.get(k)
        if v is None or v == "":
            continue
        try:
            if tipo_p is float:
                params[k] = float(v)
            elif tipo_p is list:
                params[k] = [str(x) for x in (v if isinstance(v, list) else [v])][:200]
            else:
                params[k] = str(v)[:300]
        except (TypeError, ValueError):
            error = f"parámetro {k}={v!r} no válido"
    if tipo == "consistencia" and params.get("operador") not in _OPERADORES:
        error = f"operador «{params.get('operador')}» no válido"
    if tipo == "formato":
        try:
            re.compile(params.get("patron", ""))
        except re.error as exc:
            error = f"expresión regular inválida ({exc})"
    if tipo == "integridad" and not (params.get("ref_dataset") and params.get("ref_columna")):
        error = "falta la base o la columna de referencia"
    if tipo == "dominio" and not params.get("valores"):
        error = "falta la lista de valores permitidos"
    if tipo == "frescura" and "max_dias" not in params:
        error = "falta max_dias"
    if tipo == "suma_control" and "valor_esperado" not in params:
        error = "falta valor_esperado"
    if tipo == "serie_continua":
        frec = str(params.get("frecuencia") or "B").upper()
        if frec not in _FRECUENCIAS:
            error = f"frecuencia «{frec}» no válida (D, B, W, M o Q)"
        params["frecuencia"] = frec
    if tipo == "estabilidad_psi" and params.get("umbral_psi", 0.25) <= 0:
        error = "umbral_psi debe ser positivo"
    if tipo in ("longitud", "cardinalidad") and "minimo" not in params and "maximo" not in params:
        error = "falta minimo o maximo"
    if tipo == "consistencia_fechas" and params.get("operador") not in _OPERADORES:
        error = f"operador «{params.get('operador')}» no válido"
    if tipo == "conciliacion_totales" and not (params.get("ref_dataset") and params.get("ref_columna")):
        error = "falta la base o la columna de referencia"
    if tipo == "conciliacion_conteos" and not params.get("ref_dataset"):
        error = "falta la base de referencia"
    if tipo == "conciliacion_por_grupo" and "pareja" in params:
        params["pareja"] = str(params["pareja"]).strip().lower()
        if params["pareja"] not in ("ambas", "base"):
            error = f"pareja «{params['pareja']}» no válida (ambas o base)"
    if tipo == "variacion_temporal":
        agg = str(params.get("agregacion") or "sum").lower()
        if agg not in _AGREGACIONES:
            error = f"agregacion «{agg}» no válida (sum, count o mean)"
        params["agregacion"] = agg
        if params.get("max_variacion_pct", 0) <= 0:
            error = "falta max_variacion_pct (positivo)"
    if tipo in ("monotonia", "monotonia_curva"):
        sentido = str(params.get("sentido") or ("creciente" if tipo == "monotonia" else "decreciente")).lower()
        if sentido not in _SENTIDOS:
            error = f"sentido «{sentido}» no válido (creciente o decreciente)"
        params["sentido"] = sentido
    if tipo == "valores_repetidos" and params.get("max_repeticiones", 5.0) < 1:
        error = "max_repeticiones debe ser 1 o más"
    if tipo == "saltos_serie" and params.get("k", 10.0) <= 0:
        error = "k debe ser positivo"
    if tipo == "saltos_serie" and "agregar" in params:
        params["agregar"] = str(params["agregar"]).strip().lower()
        if params["agregar"] not in ("", "suma"):
            error = f"agregar «{params['agregar']}» no válido (vacío o suma)"
    if tipo == "relacion_aritmetica":
        op = str(params.get("operacion") or "suma").lower()
        if op not in _OPERACIONES:
            error = f"operacion «{op}» no válida (suma, resta, producto o cociente)"
        params["operacion"] = op
    if tipo == "categorias_requeridas" and not params.get("valores"):
        error = "falta la lista de categorías requeridas"
    if tipo == "suma_por_grupo" and "valor_esperado" not in params:
        error = "falta valor_esperado"
    if tipo == "conciliacion_por_grupo" and not (params.get("ref_dataset") and params.get("ref_columna")):
        error = "falta la base o la columna de referencia"
    if tipo == "signo_por_categoria" and not (params.get("positivos") or params.get("negativos")):
        error = "faltan las categorías positivos y/o negativos"
    if tipo == "banda_coherente":
        try:
            lim = [float(x) for x in params.get("limites") or []]
        except (TypeError, ValueError):
            lim, error = [], "limites debe ser una lista de números"
        et = params.get("etiquetas") or []
        if not error and (len(lim) < 2 or len(lim) != len(et) + 1):
            error = "limites debe tener una posición más que etiquetas (al menos una banda)"
        elif not error and any(b <= a for a, b in zip(lim, lim[1:])):
            error = "limites debe ser creciente"
        if not error:
            params["limites"] = lim
    return params, error

_LIBRERIA = r'''
# ═══ Librería de controles (autocontenida: solo pandas y numpy) ═══
# Cada control devuelve _res(...): filas evaluadas, filas afectadas, % y decisión.
# `mascara` (opcional) marca las filas que fallan; solo alimenta la evidencia
# LOCAL (no viaja en el Excel de resultados).
import operator as _op
import re as _re_lib
import warnings as _warnings

import numpy as np
import pandas as pd


def _res(evaluados, afectados, umbral_pct, diag, mascara=None):
    evaluados, afectados = int(evaluados), int(afectados)
    if evaluados == 0:
        return {"evaluados": 0, "afectados": 0, "pct_incumplimiento": None,
                "pct_cumplimiento": None, "decision": "No evaluable",
                "diagnostico": "Sin filas evaluables. " + diag}
    pct = 100.0 * afectados / evaluados
    r = {"evaluados": evaluados, "afectados": afectados,
         "pct_incumplimiento": round(pct, 4), "pct_cumplimiento": round(100 - pct, 4),
         "decision": "Cumple" if pct <= float(umbral_pct or 0) else "No cumple",
         "diagnostico": diag}
    if mascara is not None:
        r["_mascara"] = mascara
    return r


def _exigir(df, columnas):
    falt = [c for c in columnas if c not in df.columns]
    if falt:
        raise KeyError(f"columnas inexistentes: {falt}")


def completitud(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas)
    m = df[columnas].isna().any(axis=1)
    det = ", ".join(f"{c}: {int(df[c].isna().sum())}" for c in columnas)
    return _res(len(df), int(m.sum()), umbral_pct,
                f"Filas con algún nulo en {columnas}: {int(m.sum())} ({det}).", m)


def unicidad(df, columnas=None, umbral_pct=0.0, **_):
    cols = list(columnas) if columnas else None
    if cols:
        _exigir(df, cols)
    m = df.duplicated(subset=cols, keep=False)
    que = f"la llave {cols}" if cols else "todas las columnas"
    return _res(len(df), int(m.sum()), umbral_pct, f"Filas repetidas en {que}: {int(m.sum())}.", m)


def rango(df, columnas, minimo=None, maximo=None, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = pd.to_numeric(df[columnas[0]], errors="coerce").dropna()
    m = pd.Series(False, index=s.index)
    if minimo is not None:
        m |= s < float(minimo)
    if maximo is not None:
        m |= s > float(maximo)
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} fuera de [{minimo}, {maximo}]: {int(m.sum())} "
                f"(mín. {s.min() if len(s) else 'N/D'}, máx. {s.max() if len(s) else 'N/D'}).", m)


def no_negativos(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = pd.to_numeric(df[columnas[0]], errors="coerce").dropna()
    m = s < 0
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} con valores negativos: {int(m.sum())}.", m)


def dominio(df, columnas, valores=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna().astype(str).str.strip()
    perm = {str(v).strip() for v in valores}
    # Números: 10, «10» y 10.0 son el mismo valor permitido.
    perm_num = {float(v) for v in perm if _re_lib.fullmatch(r"[-+]?\d+(\.\d+)?", v)}
    m = ~s.isin(perm)
    if perm_num:
        m &= ~pd.to_numeric(s, errors="coerce").isin(perm_num)
    ej = ", ".join(sorted(s[m].unique()[:5]))
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} fuera de {sorted(perm)}: {int(m.sum())}"
                + (f" (p. ej. {ej})." if ej else "."), m)


def tipo_numerico(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna()
    m = pd.to_numeric(s, errors="coerce").isna()
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} no convertibles a número: {int(m.sum())}.", m)


def _fechas(s):
    """Serie a fechas: tal cual si ya lo es. Los textos ISO (AAAA-MM-DD, típicos de un
    CSV) se leen como año-mes-día; los demás, día/mes/año (dd/mm/aaaa). Con pandas 2,
    `dayfirst=True` sobre «2025-04-01» daría 4 de enero: por eso se separan."""
    if pd.api.types.is_datetime64_any_dtype(s):
        return s
    with _warnings.catch_warnings():
        _warnings.simplefilter("ignore")
        t = pd.Series(s, copy=False).astype(str).str.strip()
        iso = t.str.match(r"^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}")
        salida = pd.to_datetime(t.where(~iso), errors="coerce", dayfirst=True)
        if iso.any():
            try:
                f_iso = pd.to_datetime(t.where(iso), errors="coerce", format="ISO8601")
            except (TypeError, ValueError):                  # pandas < 2.0
                f_iso = pd.to_datetime(t.where(iso), errors="coerce")
            salida = salida.where(~iso, f_iso)
        return salida


def fecha_valida(df, columnas, desde=None, hasta=None, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna()
    f = _fechas(s)
    m = f.isna()
    if desde:
        m |= f < pd.Timestamp(desde)
    if hasta:
        m |= f > pd.Timestamp(hasta)
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} ilegibles o fuera de [{desde}, {hasta}]: {int(m.sum())}.", m)


def frescura(df, columnas, max_dias=31, referencia=None, **_):
    _exigir(df, columnas[:1])
    f = _fechas(df[columnas[0]]).max()
    ref = pd.Timestamp(referencia) if referencia else pd.Timestamp.today().normalize()
    if pd.isna(f):
        return _res(0, 0, 0, f"{columnas[0]} sin fechas legibles.")
    dias = int((ref - f).days)
    return _res(1, 0 if dias <= float(max_dias) else 1, 0,
                f"Fecha más reciente {f.date()}: {dias} días a {ref.date()} (máx. {max_dias}).")


def volumen_minimo(df, columnas=(), min_filas=1, **_):
    return _res(1, 0 if len(df) >= float(min_filas) else 1, 0,
                f"{len(df)} filas (mínimo esperado {int(float(min_filas))}).")


def constante(df, columnas, **_):
    _exigir(df, columnas[:1])
    n = int(df[columnas[0]].nunique(dropna=True))
    return _res(1, 0 if n > 1 else 1, 0, f"{columnas[0]}: {n} valor(es) distinto(s).")


def outliers_iqr(df, columnas, k=3.0, umbral_pct=1.0, **_):
    _exigir(df, columnas[:1])
    s = pd.to_numeric(df[columnas[0]], errors="coerce").dropna()
    if len(s) < 4:
        return _res(0, 0, umbral_pct, "Menos de 4 valores numéricos.")
    q1, q3 = s.quantile(0.25), s.quantile(0.75)
    iqr, k = q3 - q1, float(k)
    m = (s < q1 - k * iqr) | (s > q3 + k * iqr)
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} fuera de [{q1 - k * iqr:.4g}, {q3 + k * iqr:.4g}]: {int(m.sum())}.", m)


_OPS = {"<=": _op.le, "<": _op.lt, ">=": _op.ge, ">": _op.gt, "==": _op.eq, "!=": _op.ne}


def consistencia(df, columnas, operador="<=", umbral_pct=0.0, **_):
    _exigir(df, columnas[:2])
    a = pd.to_numeric(df[columnas[0]], errors="coerce")
    b = pd.to_numeric(df[columnas[1]], errors="coerce")
    ok = a.notna() & b.notna()
    m = ~_OPS[operador](a[ok], b[ok])
    return _res(int(ok.sum()), int(m.sum()), umbral_pct,
                f"Filas que incumplen {columnas[0]} {operador} {columnas[1]}: {int(m.sum())}.", m)


def formato(df, columnas, patron=".*", umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna().astype(str).str.strip()
    m = ~s.str.fullmatch(patron)
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} sin el formato {patron!r}: {int(m.sum())}.", m)


def integridad(df, columnas, ref_dataset="", ref_columna="", umbral_pct=0.0, datasets=None, **_):
    _exigir(df, columnas[:1])
    ref = (datasets or {}).get(ref_dataset)
    if ref is None:
        raise KeyError(f"no está cargada la base de referencia «{ref_dataset}»")
    validos = set(ref[ref_columna].dropna().astype(str).str.strip())
    s = df[columnas[0]].dropna().astype(str).str.strip()
    m = ~s.isin(validos)
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} sin correspondencia en {ref_dataset}.{ref_columna}: {int(m.sum())}.", m)


def suma_control(df, columnas, valor_esperado=0.0, tolerancia_pct=0.0, **_):
    _exigir(df, columnas[:1])
    total = float(pd.to_numeric(df[columnas[0]], errors="coerce").sum())
    esp = float(valor_esperado)
    dif = abs(total - esp) / abs(esp) * 100 if esp else (0.0 if total == 0 else 100.0)
    return _res(1, 0 if dif <= float(tolerancia_pct) else 1, 0,
                f"Suma de {columnas[0]} = {total:,.2f} vs. {esp:,.2f} esperado (diferencia {dif:.4f} %).")


def completitud_condicional(df, columnas, valores=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:2])
    a, b = columnas[0], columnas[1]
    if valores:
        perm = {str(v).strip().upper() for v in valores}
        cond = df[a].notna() & df[a].astype(str).str.strip().str.upper().isin(perm)
        que = f"{a} en {sorted(perm)}"
    else:
        cond = df[a].notna()
        que = f"{a} informado"
    vacio = df[b].isna() | (df[b].astype(str).str.strip() == "")
    m = cond & vacio
    return _res(int(cond.sum()), int(m.sum()), umbral_pct,
                f"Filas con {que} y {b} vacío: {int(m.sum())} de {int(cond.sum())}.", m)


#: Valores que suelen disfrazar un nulo (se usan si el control no trae `valores`).
CENTINELAS = ["-999999999", "-99999999", "-9999999", "-999999", "-99999", "-9999", "-999",
              "99999", "999999", "9999999", "99999999", "999999999",
              "", "N/A", "NA", "N.A.", "NULL", "NONE", "NAN", "-", "--", "S/D", "SIN DATO",
              "SIN INFORMACION", "1900-01-01", "1899-12-30", "9999-12-31"]


def _es_num(v):
    return bool(_re_lib.fullmatch(r"[-+]?\d+(\.\d+)?", str(v).strip()))


def valores_centinela(df, columnas, valores=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]]
    lista = [str(v) for v in (valores or CENTINELAS)]
    nums = {float(v) for v in lista if _es_num(v)}
    textos = {v.strip().upper() for v in lista if not _es_num(v)}
    presentes = s.notna()
    m = pd.Series(False, index=s.index)
    if nums and not pd.api.types.is_datetime64_any_dtype(s):
        m |= pd.to_numeric(s, errors="coerce").isin(nums)
    if textos:
        m |= presentes & s.astype(str).str.strip().str.upper().isin(textos)
    vc = s[m].astype(str).value_counts().head(5)
    ej = ", ".join(f"{k!r} ({v})" for k, v in vc.items())
    return _res(int(presentes.sum()), int(m.sum()), umbral_pct,
                f"{columnas[0]} con valores que disfrazan un nulo: {int(m.sum())}"
                + (f" — {ej}." if ej else "."), m)


def serie_continua(df, columnas, frecuencia="B", excluir=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    f = _fechas(df[columnas[0]]).dropna()
    if f.empty:
        return _res(0, 0, umbral_pct, f"{columnas[0]} sin fechas legibles.")
    frec = str(frecuencia or "B").upper()
    if frec in ("D", "B"):
        fuera = {pd.Timestamp(x).normalize() for x in (excluir or ()) if str(x).strip()}
        crear = pd.bdate_range if frec == "B" else pd.date_range
        esperadas = [d for d in crear(f.min().normalize(), f.max().normalize()) if d not in fuera]
        presentes = set(f.dt.normalize())
        faltan = [d for d in esperadas if d not in presentes]
        ej = [str(d.date()) for d in faltan[:5]]
    else:
        per = frec if frec in ("W", "M", "Q") else "M"
        esperadas = list(pd.period_range(f.min(), f.max(), freq=per))
        presentes = set(f.dt.to_period(per))
        faltan = [p for p in esperadas if p not in presentes]
        ej = [str(p) for p in faltan[:5]]
    return _res(len(esperadas), len(faltan), umbral_pct,
                f"{columnas[0]}: faltan {len(faltan)} de {len(esperadas)} periodos ({frec}) entre "
                f"{f.min().date()} y {f.max().date()}" + (f" — p. ej. {', '.join(ej)}." if ej else "."))


def estabilidad_psi(df, columnas, umbral_psi=0.25, bins=10, **_):
    _exigir(df, columnas[:2])
    var, per = columnas[0], columnas[1]
    clave = df[per]
    if not pd.api.types.is_numeric_dtype(clave):
        fechas = _fechas(clave)
        if fechas.notna().mean() >= 0.9:
            clave = fechas
    periodos = sorted(clave.dropna().unique())
    if len(periodos) < 2:
        return _res(0, 0, 0, f"{per}: un solo periodo; no hay con qué comparar.")
    ini, fin = periodos[0], periodos[-1]
    a, b = df.loc[clave == ini, var].dropna(), df.loc[clave == fin, var].dropna()
    if len(a) < 10 or len(b) < 10:
        return _res(0, 0, 0, f"Menos de 10 valores de {var} en el primer o en el último periodo.")
    na, nb = pd.to_numeric(a, errors="coerce"), pd.to_numeric(b, errors="coerce")
    if na.notna().mean() >= 0.95 and nb.notna().mean() >= 0.95:
        na, nb = na.dropna(), nb.dropna()
        cortes = np.unique(np.quantile(na, np.linspace(0, 1, int(bins) + 1))).astype(float)
        if len(cortes) >= 3:
            cortes[0], cortes[-1] = -np.inf, np.inf
            pa = np.histogram(na, cortes)[0] / len(na)
            pb = np.histogram(nb, cortes)[0] / len(nb)
        else:
            cats = sorted(set(na) | set(nb))
            pa = np.array([(na == c).mean() for c in cats])
            pb = np.array([(nb == c).mean() for c in cats])
    else:
        sa, sb = a.astype(str), b.astype(str)
        cats = sorted(set(sa) | set(sb))
        pa = sa.value_counts(normalize=True).reindex(cats, fill_value=0).to_numpy()
        pb = sb.value_counts(normalize=True).reindex(cats, fill_value=0).to_numpy()
    pa, pb = np.clip(pa, 1e-6, None), np.clip(pb, 1e-6, None)
    psi = float(np.sum((pb - pa) * np.log(pb / pa)))
    nivel = "estable" if psi < 0.10 else ("vigilar" if psi <= 0.25 else "cambio relevante")
    return _res(1, 0 if psi <= float(umbral_psi) else 1, 0,
                f"PSI de {var} entre {str(ini)[:10]} y {str(fin)[:10]}: {psi:.4f} ({nivel}; "
                f"umbral {float(umbral_psi):g}).")


def longitud(df, columnas, minimo=None, maximo=None, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna().astype(str).str.strip()
    n = s.str.len()
    m = pd.Series(False, index=s.index)
    if minimo is not None:
        m |= n < float(minimo)
    if maximo is not None:
        m |= n > float(maximo)
    ej = ", ".join(repr(v) for v in s[m].head(3))
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} con longitud fuera de [{minimo}, {maximo}]: {int(m.sum())}"
                + (f" (p. ej. {ej})." if ej else "."), m)


def espacios_extremos(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna()
    s = s[s.map(lambda v: isinstance(v, str))].astype(object)
    m = (s != s.str.strip()) | s.str.contains("  ", regex=False)
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} con espacios al inicio/fin o dobles: {int(m.sum())}.", m)


_RE_RAROS = _re_lib.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f�]|Ã.|Â")


def caracteres_invalidos(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna().astype(str)
    m = s.str.contains(_RE_RAROS)
    ej = ", ".join(repr(v[:30]) for v in s[m].head(3))
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]} con caracteres de control o de mala codificación: {int(m.sum())}"
                + (f" (p. ej. {ej})." if ej else "."), m)


def _canon(v):
    import unicodedata as _ud
    t = "".join(c for c in _ud.normalize("NFKD", str(v)) if not _ud.combining(c))
    return " ".join(t.lower().split())


def categorias_equivalentes(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = df[columnas[0]].dropna().astype(str)
    clave = s.map(_canon)
    principal = {}
    for k, grupo in s.groupby(clave):
        principal[k] = grupo.value_counts().index[0]
    m = s != clave.map(principal)
    variantes = sorted({f"{v!r}→{principal[_canon(v)]!r}" for v in s[m].unique()[:4]})
    return _res(len(s), int(m.sum()), umbral_pct,
                f"{columnas[0]}: {int(m.sum())} fila(s) con variantes de la misma categoría"
                + (f" ({', '.join(variantes)})." if variantes else "."), m)


def fecha_futura(df, columnas, referencia=None, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    f = _fechas(df[columnas[0]]).dropna()
    ref = pd.Timestamp(referencia) if referencia else pd.Timestamp.today().normalize()
    m = f > ref
    return _res(len(f), int(m.sum()), umbral_pct,
                f"{columnas[0]} posteriores a {ref.date()}: {int(m.sum())}"
                + (f" (máx. {f.max().date()})." if len(f) else "."), m)


def consistencia_fechas(df, columnas, operador="<=", umbral_pct=0.0, **_):
    _exigir(df, columnas[:2])
    a, b = _fechas(df[columnas[0]]), _fechas(df[columnas[1]])
    ok = a.notna() & b.notna()
    m = ~_OPS[operador](a[ok], b[ok])
    return _res(int(ok.sum()), int(m.sum()), umbral_pct,
                f"Filas que incumplen {columnas[0]} {operador} {columnas[1]}: {int(m.sum())}.", m)


def proporcion_ceros(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    s = pd.to_numeric(df[columnas[0]], errors="coerce").dropna()
    m = s == 0
    return _res(len(s), int(m.sum()), umbral_pct, f"{columnas[0]} con valor 0 exacto: {int(m.sum())}.", m)


def cardinalidad(df, columnas, minimo=None, maximo=None, **_):
    _exigir(df, columnas[:1])
    n = int(df[columnas[0]].nunique(dropna=True))
    fuera = (minimo is not None and n < float(minimo)) or (maximo is not None and n > float(maximo))
    return _res(1, 1 if fuera else 0, 0,
                f"{columnas[0]}: {n} valor(es) distinto(s) (esperado entre {minimo} y {maximo}).")


def conciliacion_totales(df, columnas, ref_dataset="", ref_columna="", tolerancia_pct=0.0,
                         datasets=None, **_):
    _exigir(df, columnas[:1])
    ref = (datasets or {}).get(ref_dataset)
    if ref is None:
        raise KeyError(f"no está cargada la base de referencia «{ref_dataset}»")
    a = float(pd.to_numeric(df[columnas[0]], errors="coerce").sum())
    b = float(pd.to_numeric(ref[ref_columna], errors="coerce").sum())
    dif = abs(a - b) / abs(b) * 100 if b else (0.0 if a == 0 else 100.0)
    return _res(1, 0 if dif <= float(tolerancia_pct) else 1, 0,
                f"Suma de {columnas[0]} = {a:,.2f} vs. {ref_dataset}.{ref_columna} = {b:,.2f} "
                f"(diferencia {dif:.4f} %; tolerancia {float(tolerancia_pct):g} %).")


def conciliacion_conteos(df, columnas=(), ref_dataset="", tolerancia_pct=0.0, datasets=None, **_):
    ref = (datasets or {}).get(ref_dataset)
    if ref is None:
        raise KeyError(f"no está cargada la base de referencia «{ref_dataset}»")
    a, b = len(df), len(ref)
    dif = abs(a - b) / b * 100 if b else (0.0 if a == 0 else 100.0)
    return _res(1, 0 if dif <= float(tolerancia_pct) else 1, 0,
                f"{a:,} filas vs. {b:,} en {ref_dataset} (diferencia {dif:.4f} %; tolerancia "
                f"{float(tolerancia_pct):g} %).")


def variacion_temporal(df, columnas, agregacion="sum", max_variacion_pct=20.0, umbral_pct=0.0, **_):
    _exigir(df, columnas[:2])
    valor, per = columnas[0], columnas[1]
    clave = df[per]
    if not pd.api.types.is_numeric_dtype(clave):
        fechas = _fechas(clave)
        if fechas.notna().mean() >= 0.9:
            clave = fechas
    v = pd.to_numeric(df[valor], errors="coerce") if agregacion != "count" else df[valor]
    serie = getattr(v.groupby(clave), agregacion)().sort_index()
    if len(serie) < 2:
        return _res(0, 0, umbral_pct, f"{per}: menos de dos periodos; no hay variación que medir.")
    cambio = serie.pct_change().iloc[1:] * 100
    m = cambio.abs() > float(max_variacion_pct)
    peores = ", ".join(f"{str(k)[:10]}: {c:+.1f} %" for k, c in cambio[m].head(4).items())
    return _res(len(cambio), int(m.sum()), umbral_pct,
                f"{agregacion}({valor}) por {per}: {int(m.sum())} salto(s) de más de "
                f"{float(max_variacion_pct):g} %" + (f" ({peores})." if peores else "."))


# ═══ Controles de negocio: series de mercado, paneles, identidades y bandas ═══

def _orden_tenor(v):
    """Plazo de un nodo en días: '1M'→30, '3M'→90, '1Y'/'1A'→365, '2W'→14, '10D'→10, '7'→7."""
    s = str(v).strip().upper().replace(" ", "")
    m = _re_lib.fullmatch(r"(\d+(?:[.,]\d+)?)([DWMYA]?)", s)
    if not m:
        return np.nan
    return float(m.group(1).replace(",", ".")) * {"D": 1, "W": 7, "M": 30, "Y": 365, "A": 365, "": 1}[m.group(2)]


def _clave_orden(s):
    """Clave para ordenar: número, fecha o tenor («1M», «1Y»)."""
    if pd.api.types.is_numeric_dtype(s) or pd.api.types.is_datetime64_any_dtype(s):
        return s
    t = s.map(_orden_tenor)
    if t.notna().mean() >= 0.9:
        return t
    return _fechas(s)


def _marco(df, valor, orden, grupos, numerico=True):
    """DataFrame (v, o, g) ordenado por grupo y orden, sin nulos."""
    d = pd.DataFrame({"v": pd.to_numeric(df[valor], errors="coerce") if numerico else df[valor],
                      "o": _clave_orden(df[orden])}, index=df.index)
    if not grupos:
        d["g"] = "_"
    else:
        g = df[grupos[0]].astype(str)
        for c in grupos[1:]:
            g = g + "|" + df[c].astype(str)
        d["g"] = g
    return d.dropna(subset=["v", "o"]).sort_values(["g", "o"], kind="mergesort")


def valores_repetidos(df, columnas, max_repeticiones=5, umbral_pct=0.0, **_):
    _exigir(df, columnas[:3])
    val, orden, grupos = columnas[0], columnas[1], list(columnas[2:4])
    d = _marco(df, val, orden, grupos, numerico=False)
    if d.empty:
        return _res(0, 0, umbral_pct, f"{val}: sin valores ordenables por {orden}.")
    previo = d.groupby("g")["v"].shift()
    tramo = (d["v"] != previo).cumsum()
    pos = d.groupby(tramo).cumcount() + 1
    k = int(float(max_repeticiones))
    m = pos > k
    largos = d.groupby(tramo).size()
    n_tramos, mayor = int((largos > k).sum()), int(largos.max())
    afect_g = d.loc[m, "g"].nunique()
    return _res(len(d), int(m.sum()), umbral_pct,
                f"{val}: {n_tramos} tramo(s) con más de {k} valores iguales seguidos (el más largo: {mayor})"
                + (f" en {afect_g} grupo(s) de {grupos[0]}" if grupos else "") + ".", m)


def saltos_serie(df, columnas, k=10.0, umbral_pct=0.0, agregar="", **_):
    _exigir(df, columnas[:3])
    val, orden, grupos = columnas[0], columnas[1], list(columnas[2:4])
    d = _marco(df, val, orden, grupos)
    filas = d
    if str(agregar or "").lower() == "suma":
        # Varias filas por grupo y fecha (cosechas, cuentas): la serie que importa es el total.
        d = d.groupby(["g", "o"], sort=True)["v"].sum().reset_index()
    dif = d.groupby("g")["v"].diff()
    partes = []
    for _g, x in dif.groupby(d["g"]):
        x = x.dropna()
        if len(x) < 5:
            continue
        med = float(x.median())
        esc = float((x - med).abs().median()) * 1.4826
        # Serie casi perfecta (MAD = 0): la desviación media absoluta no se deja
        # contaminar por el propio salto como la desviación estándar.
        esc = esc if esc > 0 else float((x - med).abs().mean()) * 1.2533
        if esc > 0 and np.isfinite(esc):
            partes.append((x - med).abs() / esc)
    z = pd.concat(partes) if partes else pd.Series(dtype=float)
    m = z > float(k)
    peor = (f"; el mayor: {z.max():.1f} desviaciones en {str(d.loc[z.idxmax(), 'o'])[:10]}"
            if len(z) and m.any() else "")
    mascara = m
    if d is not filas:                      # vuelve a las filas originales de los totales con salto
        malos = set(zip(d.loc[m[m].index, "g"], d.loc[m[m].index, "o"]))
        mascara = pd.Series([(g, o) in malos for g, o in zip(filas["g"], filas["o"])], index=filas.index)
    return _res(len(z), int(m.sum()), umbral_pct,
                f"{val}: {int(m.sum())} salto(s) de más de {float(k):g} desviaciones robustas entre "
                f"observaciones consecutivas{' del total por grupo y fecha' if d is not filas else ''}{peor}.", mascara)


def monotonia(df, columnas, sentido="creciente", umbral_pct=0.0, **_):
    _exigir(df, columnas)
    x = df[list(columnas)].apply(pd.to_numeric, errors="coerce")
    ok = x.notna().all(axis=1)
    d = x[ok].diff(axis=1).iloc[:, 1:]
    m = (d < 0).any(axis=1) if sentido == "creciente" else (d > 0).any(axis=1)
    signo = " ≤ " if sentido == "creciente" else " ≥ "
    return _res(int(ok.sum()), int(m.sum()), umbral_pct,
                f"Filas que incumplen {signo.join(columnas)}: {int(m.sum())}.", m)


def monotonia_curva(df, columnas, sentido="decreciente", umbral_pct=0.0, **_):
    _exigir(df, columnas)
    val, orden, grupos = columnas[0], columnas[1], list(columnas[2:])
    d = _marco(df, val, orden, grupos)
    dif = d.groupby("g")["v"].diff()
    tol = 1e-12 * max(1.0, float(d["v"].abs().max()) if len(d) else 1.0)
    m = (dif > tol) if sentido == "decreciente" else (dif < -tol)
    ev = dif.notna()
    afect_g = d.loc[m, "g"].nunique()
    return _res(int(ev.sum()), int(m[ev].sum()), umbral_pct,
                f"{val} debería ser {sentido} con {orden}: {int(m[ev].sum())} tramo(s) que lo rompen"
                + (f" en {afect_g} grupo(s)" if grupos else "") + ".", m[ev])


def relacion_aritmetica(df, columnas, operacion="suma", tolerancia_pct=0.5, umbral_pct=0.0, valor=None, **_):
    _exigir(df, columnas)
    x = df[list(columnas)].apply(pd.to_numeric, errors="coerce")
    x = x[x.notna().all(axis=1)]
    if valor is not None and str(valor) != "":
        # Todas las columnas operan contra un valor fijo (estable + volátil = 1).
        ops, res, nom, cols_op = x, pd.Series(float(valor), index=x.index), f"{float(valor):g}", list(columnas)
    else:
        ops, res, nom, cols_op = x.iloc[:, :-1], x.iloc[:, -1], columnas[-1], list(columnas[:-1])
    op = str(operacion).lower()
    if op == "suma":
        esp, txt = ops.sum(axis=1), " + ".join(cols_op)
    elif op == "resta":
        esp, txt = ops.iloc[:, 0] - ops.iloc[:, 1:].sum(axis=1), " − ".join(cols_op)
    elif op == "producto":
        esp, txt = ops.prod(axis=1), " × ".join(cols_op)
    else:
        esp, txt = ops.iloc[:, 0] / ops.iloc[:, 1].replace(0, np.nan), " ÷ ".join(cols_op[:2])
    valido = esp.notna()
    tol = (esp.abs() * float(tolerancia_pct) / 100).clip(lower=1e-9)
    m = valido & ((res - esp).abs() > tol)
    return _res(int(valido.sum()), int(m.sum()), umbral_pct,
                f"Filas donde {nom} ≠ {txt} (tolerancia {float(tolerancia_pct):g} %): {int(m.sum())}.",
                m[valido])


def diferencia_relativa(df, columnas, tolerancia_pct=1.0, umbral_pct=0.0, **_):
    _exigir(df, columnas[:2])
    a = pd.to_numeric(df[columnas[0]], errors="coerce")
    b = pd.to_numeric(df[columnas[1]], errors="coerce")
    ok = a.notna() & b.notna()
    a, b = a[ok], b[ok]
    base = b.abs().where(b.abs() > 0, a.abs()).replace(0, np.nan)
    rel = ((a - b).abs() / base * 100).fillna(0.0)
    m = rel > float(tolerancia_pct)
    return _res(len(rel), int(m.sum()), umbral_pct,
                f"{columnas[0]} vs {columnas[1]}: {int(m.sum())} fila(s) con diferencia de más de "
                f"{float(tolerancia_pct):g} %" + (f" (mediana {rel.median():.2f} %, máx. {rel.max():.2f} %)."
                                                  if len(rel) else "."), m)


def _canon_valor(v, banda=False):
    """Valor comparable: números sin «.0»; textos sin tildes ni mayúsculas y sin espacios
    (en categorías tampoco cuentan «_» ni «-»: «Paralelo Abajo» = «paralelo_abajo»)."""
    t = str(v).strip()
    if _re_lib.fullmatch(r"[-+]?\d+(\.\d+)?", t):
        return f"{float(t):g}"
    return _re_lib.sub(r"\s+" if banda else r"[\s_\-]+", "", _canon(t))


def categorias_requeridas(df, columnas, valores=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    presentes = {_canon_valor(v) for v in df[columnas[0]].dropna().astype(str).unique()}
    req = [str(v) for v in valores]
    faltan = [v for v in req if _canon_valor(v) not in presentes]
    return _res(len(req), len(faltan), umbral_pct,
                f"{columnas[0]}: faltan {len(faltan)} de {len(req)} categorías requeridas"
                + (f" ({', '.join(faltan[:8])})." if faltan else "."))


def combinaciones_completas(df, columnas, umbral_pct=0.0, **_):
    _exigir(df, columnas[:3])
    a, b = columnas[0], columnas[1]
    grupo = columnas[2] if len(columnas) > 2 else None
    cols = [c for c in (grupo, a, b) if c]
    d = df[cols].dropna().astype(str).drop_duplicates()
    esperadas, ejemplos = 0, []
    for g, x in (d.groupby(grupo) if grupo else [("", d)]):
        ua, ub = sorted(x[a].unique()), sorted(x[b].unique())
        esperadas += len(ua) * len(ub)
        if len(ejemplos) < 5 and len(ua) * len(ub) <= 200_000:
            hay = set(zip(x[a], x[b]))
            for va in ua:
                for vb in ub:
                    if (va, vb) not in hay:
                        ejemplos.append(f"{(str(g) + '/') if grupo else ''}{va}×{vb}")
                        if len(ejemplos) >= 5:
                            break
                if len(ejemplos) >= 5:
                    break
    if esperadas > 5_000_000:
        return _res(0, 0, umbral_pct, f"{a} × {b}: más de 5 millones de combinaciones; acota la base.")
    faltan = esperadas - len(d)
    return _res(esperadas, faltan, umbral_pct,
                f"{a} × {b}{(' por ' + grupo) if grupo else ''}: faltan {faltan} de {esperadas} combinaciones"
                + (f" (p. ej. {', '.join(ejemplos)})." if ejemplos else "."))


def minimo_por_grupo(df, columnas, min_filas=1, umbral_pct=0.0, **_):
    _exigir(df, columnas)
    n = df.groupby(list(columnas), dropna=True).size()
    m = n < float(min_filas)
    ej = ", ".join(f"{k}: {v}" for k, v in n[m].sort_values().head(5).items())
    return _res(len(n), int(m.sum()), umbral_pct,
                f"Grupos de {', '.join(columnas)} con menos de {int(float(min_filas))} filas: {int(m.sum())} de "
                f"{len(n)}" + (f" (p. ej. {ej})." if ej else "."))


def suma_por_grupo(df, columnas, valor_esperado=1.0, tolerancia_pct=0.5, umbral_pct=0.0, **_):
    _exigir(df, columnas)
    v = pd.to_numeric(df[columnas[0]], errors="coerce")
    s = v.groupby([df[c] for c in columnas[1:]]).sum(min_count=1).dropna()
    esp = float(valor_esperado)
    tol = max(abs(esp) * float(tolerancia_pct) / 100 if esp else float(tolerancia_pct) / 100, 1e-12)
    m = (s - esp).abs() > tol
    ej = ", ".join(f"{k}: {x:.6g}" for k, x in s[m].head(4).items())
    return _res(len(s), int(m.sum()), umbral_pct,
                f"Grupos de {', '.join(columnas[1:])} cuya suma de {columnas[0]} no es {esp:g}: {int(m.sum())} de "
                f"{len(s)}" + (f" (p. ej. {ej})." if ej else "."))


def _clave_grupo(s):
    """Clave comparable entre bases: fechas a AAAA-MM-DD, números sin «.0», textos en mayúsculas."""
    if pd.api.types.is_datetime64_any_dtype(s):
        return s.dt.strftime("%Y-%m-%d")
    if pd.api.types.is_numeric_dtype(s):
        return s.map(lambda v: None if pd.isna(v) else (str(int(v)) if float(v).is_integer() else str(v)))
    t = s.astype(str).str.strip()
    if t.str.fullmatch(r"\d{1,4}[-/]\d{1,2}[-/]\d{1,4}( .*)?").mean() >= 0.95:
        f = _fechas(t)
        if f.notna().mean() >= 0.95:
            return f.dt.strftime("%Y-%m-%d")
    return t.str.upper()


def conciliacion_por_grupo(df, columnas, ref_dataset="", ref_columna="", ref_claves=(), tolerancia_pct=0.5,
                           umbral_pct=0.0, pareja="ambas", datasets=None, **_):
    _exigir(df, columnas)
    ref = (datasets or {}).get(ref_dataset)
    if ref is None:
        raise KeyError(f"no está cargada la base de referencia «{ref_dataset}»")
    claves = list(columnas[1:])
    rclaves = list(ref_claves) if ref_claves else claves
    _exigir(ref, rclaves + [ref_columna])
    a = pd.to_numeric(df[columnas[0]], errors="coerce").groupby([_clave_grupo(df[c]) for c in claves]).sum()
    b = pd.to_numeric(ref[ref_columna], errors="coerce").groupby([_clave_grupo(ref[c]) for c in rclaves]).sum()
    nombres = [f"k{i}" for i in range(len(claves))]
    a.index.names, b.index.names = nombres, nombres
    j = pd.concat([a.rename("a"), b.rename("b")], axis=1)
    if str(pareja).lower() == "base":           # los grupos que solo están en la referencia son otros cortes
        j = j[j["a"].notna()]
    base = j["b"].abs().where(j["b"].abs() > 0, j["a"].abs()).replace(0, np.nan)
    rel = ((j["a"].fillna(0) - j["b"].fillna(0)).abs() / base * 100).fillna(0.0)
    m = (rel > float(tolerancia_pct)) | j["a"].isna() | j["b"].isna()
    ej = ", ".join(f"{k if not isinstance(k, tuple) else '/'.join(map(str, k))}: {r:.2f} %"
                   for k, r in rel[m].sort_values(ascending=False).head(4).items())
    return _res(len(j), int(m.sum()), umbral_pct,
                f"Suma de {columnas[0]} por {', '.join(claves)} vs {ref_dataset}.{ref_columna}: {int(m.sum())} de "
                f"{len(j)} grupo(s) fuera de la tolerancia de {float(tolerancia_pct):g} % o sin pareja"
                + (f" (p. ej. {ej})." if ej else "."))


def signo_por_categoria(df, columnas, positivos=(), negativos=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:2])
    v = pd.to_numeric(df[columnas[0]], errors="coerce")
    cat = df[columnas[1]].astype(str).map(_canon_valor)
    pos, neg = {_canon_valor(x) for x in positivos}, {_canon_valor(x) for x in negativos}
    ev = v.notna() & (cat.isin(pos) | cat.isin(neg))
    m = (cat.isin(pos) & (v < 0)) | (cat.isin(neg) & (v > 0))
    return _res(int(ev.sum()), int((m & ev).sum()), umbral_pct,
                f"{columnas[0]} con signo contrario a su {columnas[1]}: {int((m & ev).sum())} de {int(ev.sum())}.",
                (m & ev)[ev])


def banda_coherente(df, columnas, limites=(), etiquetas=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:2])
    lim, et = [float(x) for x in limites], [str(x) for x in etiquetas]
    if len(lim) != len(et) + 1:
        raise ValueError("limites debe tener una posición más que etiquetas")
    dias = pd.to_numeric(df[columnas[0]], errors="coerce")
    ok = dias.notna() & df[columnas[1]].notna()
    idx = np.searchsorted(np.array(lim), dias[ok].to_numpy(), side="right") - 1
    esperado = pd.Series([_canon_valor(et[i], banda=True) if 0 <= i < len(et) else None for i in idx],
                         index=dias[ok].index)
    real = df.loc[ok, columnas[1]].astype(str).map(lambda x: _canon_valor(x, banda=True))
    m = esperado.isna() | (esperado != real)
    ej = ", ".join(f"{d:g} días en «{b}»" for d, b in zip(dias[ok][m].head(3), df.loc[ok, columnas[1]][m].head(3)))
    return _res(int(ok.sum()), int(m.sum()), umbral_pct,
                f"{columnas[1]} que no corresponde a {columnas[0]}: {int(m.sum())}" + (f" (p. ej. {ej})." if ej else "."),
                m)


def fechas_habiles(df, columnas, excluir=(), umbral_pct=0.0, **_):
    _exigir(df, columnas[:1])
    f = _fechas(df[columnas[0]]).dropna()
    feriados = {pd.Timestamp(x).normalize() for x in (excluir or ()) if str(x).strip()}
    m = (f.dt.dayofweek >= 5) | f.dt.normalize().isin(feriados)
    ej = sorted({str(d.date()) for d in f[m].head(50)})[:5]
    return _res(len(f), int(m.sum()), umbral_pct,
                f"{columnas[0]} en fin de semana o feriado: {int(m.sum())}" + (f" (p. ej. {', '.join(ej)})." if ej else "."),
                m)


# ═══ Adaptadores para controles traídos de OTROS notebooks ═══
# Tu función puede devolver cualquiera de estas formas; `a_resultado` la
# convierte en el resultado estándar (así no hace falta reescribirla):
#   _res(...)                         ya en el formato de VIRF
#   Serie booleana                    True = fila que FALLA (mismo índice que df)
#   DataFrame                         las filas que fallan (un subconjunto de df)
#   int                               cuántas filas fallan (evaluadas = len(df))
#   (evaluados, afectados)            tupla de dos enteros
#   True / False                      el control cumple / no cumple
def desde_mascara(df, mascara, umbral_pct=0.0, diagnostico=""):
    m = pd.Series(mascara, index=df.index).fillna(False).astype(bool) if not isinstance(mascara, pd.Series) \
        else mascara.fillna(False).astype(bool)
    return _res(len(m), int(m.sum()), umbral_pct, diagnostico or f"{int(m.sum())} fila(s) que fallan.", m)


def desde_filas(df, filas_que_fallan, umbral_pct=0.0, diagnostico=""):
    m = pd.Series(df.index.isin(filas_que_fallan.index), index=df.index)
    return _res(len(df), int(m.sum()), umbral_pct, diagnostico or f"{int(m.sum())} fila(s) que fallan.", m)


def desde_conteo(evaluados, afectados, umbral_pct=0.0, diagnostico=""):
    return _res(evaluados, afectados, umbral_pct, diagnostico or f"{int(afectados)} de {int(evaluados)} fallan.")


def desde_booleano(cumple, diagnostico=""):
    return _res(1, 0 if cumple else 1, 0, diagnostico or ("Cumple." if cumple else "No cumple."))


def a_resultado(r, df, umbral_pct=0.0, nombre="control"):
    """Convierte lo que devuelve un control traído de otro notebook al formato de VIRF."""
    if isinstance(r, dict) and "decision" in r:
        return r
    if isinstance(r, (bool, np.bool_)):
        return desde_booleano(bool(r), f"{nombre}: {'cumple' if r else 'no cumple'}.")
    if isinstance(r, pd.DataFrame):
        return desde_filas(df, r, umbral_pct, f"{nombre}: {len(r)} fila(s) que fallan.")
    if isinstance(r, pd.Series) and r.dtype == bool:
        return desde_mascara(df, r, umbral_pct, f"{nombre}: {int(r.sum())} fila(s) que fallan.")
    if isinstance(r, (int, np.integer)):
        return desde_conteo(len(df), int(r), umbral_pct, f"{nombre}: {int(r)} fila(s) que fallan.")
    if isinstance(r, tuple) and len(r) == 2:
        return desde_conteo(int(r[0]), int(r[1]), umbral_pct, f"{nombre}: {int(r[1])} de {int(r[0])} fallan.")
    raise TypeError("el control debe devolver _res(...), una serie booleana (True = falla), un DataFrame "
                    "con las filas que fallan, un entero, una tupla (evaluados, afectados) o True/False")


def llamar_flexible(funcion, df, columnas, datasets, params):
    """Llama a una función traída de otro notebook pasándole SOLO lo que acepta
    (vale `def f(df)`, `def f(df, columnas)`, `def f(df, umbral=…)`…)."""
    import inspect
    ps = inspect.signature(funcion).parameters
    libre = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in ps.values())
    kw = {}
    if "columnas" in ps or libre:
        kw["columnas"] = columnas
    if "datasets" in ps or libre:
        kw["datasets"] = datasets
    for k, v in params.items():
        if k in ps or libre:
            kw[k] = v
    return funcion(df, **kw)


def desde_repositorio(res):
    """Resultado de un control del repositorio por tipo de modelo ({pct, decision,
    diagnostico}) al formato estándar. «Observado» cuenta como no cumple y
    «Revisión manual» como no evaluable."""
    if not isinstance(res, dict):
        return _res(0, 0, 0, "el control no devolvió un diccionario")
    dec = str(res.get("decision") or "No evaluable")
    diag = str(res.get("diagnostico") or "")
    if dec in ("Observado", "Revisión manual"):
        diag = f"{dec}: {diag}"
    if dec == "Cumple":
        r = _res(1, 0, 0, diag)
    elif dec in ("No cumple", "Observado"):
        r = _res(1, 1, 0, diag)
    else:
        return _res(0, 0, 0, diag)
    try:
        pct = float(res.get("pct"))
        r["pct_cumplimiento"], r["pct_incumplimiento"] = round(pct, 4), round(100 - pct, 4)
    except (TypeError, ValueError):
        pass
    return r
'''.strip()


# ═════════════════════════════════════════════════════════════════════════════
# 3. PROPUESTA DETERMINISTA (reglas sobre el perfil, coste 0)
# ═════════════════════════════════════════════════════════════════════════════

_RE_MONTO = re.compile(r"(saldo|monto|importe|exposici|nominal|principal|capital|cuota|"
                       r"desembolso|valor_?(de_)?mercado|provisi)")
_RE_TASA = re.compile(r"(^|_)(tasa|tea|tem|pd|lgd|ccf|ratio|porcentaje|pct|probabilidad|"
                      r"prob)(_|$)")
_RE_PLAZO = re.compile(r"(plazo|dias|meses|edad|antiguedad|vencimiento_dias)")
_RE_FECHA = re.compile(r"(fecha|date|periodo|corte|fec_)")
_RE_LLAVE = re.compile(r"(^id$|^id_|_id$|codigo|^cod_|cuenta|llave|^nro_|numero|contrato|operacion)")


def _es_numerico(c: dict) -> bool:
    d = (c.get("dtype") or "").lower()
    return any(x in d for x in ("int", "float", "double", "decimal", "long", "numér", "numer"))


def _control(dataset: str, tipo: str, columnas: list[str], params: dict, descripcion: str,
             justificacion: str, criticidad: str = "MEDIA", evidencia: str = "",
             origen: str = "determinista") -> dict:
    return {"dataset": dataset, "tipo": tipo, "columnas": columnas, "params": params,
            "dimension": CATALOGO[tipo]["dimension"], "descripcion": descripcion,
            "justificacion": justificacion, "criticidad": criticidad,
            "evidencia_requerida": evidencia or "Si no cumple, sustentar el tratamiento aplicado "
                                                "por la primera línea.",
            "origen": origen}


def _centinelas_de(v: Optional[float]) -> list[str]:
    """
    Centinelas (99999…, -999…) que explican un mínimo o un máximo del describe.
    El describe redondea a 6 cifras (99999999 sale «1.000000e+08»), así que se
    acepta esa diferencia y se proponen los dos candidatos (99999999 y 1e8).
    """
    if v is None:
        return []
    signo, a = (-1 if v < 0 else 1), abs(v)
    for k in (range(3, 10) if signo < 0 else range(5, 10)):
        nueve = 10 ** k - 1
        if a == nueve:
            return [str(signo * nueve)]
        if abs(a - nueve) <= nueve * 1e-6:
            return [str(signo * nueve), str(signo * 10 ** k)]
    return []


#: Textos de relleno que, si son el valor más frecuente («top»), merecen control.
_CENT_TXT = {"N/A", "NA", "N.A.", "NULL", "NONE", "-", "--", "S/D", "SIN DATO", "SIN INFORMACION"}


def _es_dominio_mercado(dominio: str) -> bool:
    try:
        from modulos.repositorio_controles import carpeta_de_dominio
        return carpeta_de_dominio(dominio) == "var"
    except Exception:                                     # noqa: BLE001
        return _sin_tildes(dominio) in ("var", "trading", "mercado")


def proponer_deterministas(perfiles: list[dict], dominio: str = "") -> list[dict]:
    """Controles que se deducen del perfil sin IA (reglas explícitas, trazables)."""
    ctrls: list[dict] = []
    mercado = _es_dominio_mercado(dominio)
    for p in perfiles:
        ds, filas = p["nombre"], p["filas"]
        ctrls.append(_control(ds, "volumen_minimo", [], {"min_filas": 1},
                              f"La base «{ds}» no está vacía.",
                              f"info(): {filas} filas." if filas is not None else "Volumen no informado.",
                              "ALTA"))
        ctrls.append(_control(ds, "unicidad", [], {"umbral_pct": 0.0},
                              f"La base «{ds}» no tiene filas duplicadas.",
                              "Control base de unicidad (BCBS 239, principio de exactitud).", "MEDIA"))
        for c in p["columnas"]:
            n, nc = c["nombre"], _sin_tildes(c["nombre"]).replace(" ", "_")
            st = c.get("stats") or {}
            mn, mx = _num(st.get("min")), _num(st.get("max"))
            if c.get("nulos"):
                ctrls.append(_control(ds, "completitud", [n], {"umbral_pct": 0.0},
                                      f"{n} no tiene valores nulos.",
                                      f"info(): {c['no_nulos']} de {filas} no nulos "
                                      f"({c['pct_nulos']} % nulos).",
                                      "ALTA" if _RE_LLAVE.search(nc) or _RE_MONTO.search(nc) else "MEDIA"))
            elif _RE_LLAVE.search(nc) or _RE_FECHA.search(nc):
                ctrls.append(_control(ds, "completitud", [n], {"umbral_pct": 0.0},
                                      f"{n} (columna clave) no tiene valores nulos.",
                                      f"Columna clave; info(): {c['no_nulos']} no nulos.", "ALTA"))
            uniq, cnt = _num(st.get("unique")), _num(st.get("count"))
            # Llave: única en el perfil, o CASI única (≥ 98 %): eso último suele
            # ser una llave con duplicados, que es justo lo que hay que cazar.
            if (_RE_LLAVE.search(nc) and uniq is not None and cnt
                    and uniq >= 0.98 * cnt):
                freq = _num(st.get("freq"))
                rep = (f"; «{st.get('top')}» aparece {int(freq)} veces"
                       if uniq != cnt and freq else "")
                ctrls.append(_control(ds, "unicidad", [n], {"umbral_pct": 0.0},
                                      f"{n} identifica cada fila (sin repetidos).",
                                      f"describe(): unique={int(uniq)} de count={int(cnt)}{rep}.",
                                      "ALTA"))
            if _RE_MONTO.search(nc):
                if _es_numerico(c):
                    ctrls.append(_control(ds, "no_negativos", [n], {"umbral_pct": 0.0},
                                          f"{n} no tiene valores negativos.",
                                          f"Monto; describe(): min={mn}." if mn is not None
                                          else "Columna de monto.", "ALTA"))
                    ctrls.append(_control(ds, "outliers_iqr", [n], {"k": 3.0, "umbral_pct": 1.0},
                                          f"{n} sin valores atípicos extremos (más del 1 %).",
                                          f"describe(): min={mn}, max={mx}." if mx is not None
                                          else "Columna de monto.", "BAJA"))
                else:
                    ctrls.append(_control(ds, "tipo_numerico", [n], {"umbral_pct": 0.0},
                                          f"{n} contiene solo números.",
                                          f"info(): tipo {c['dtype']} en una columna de monto.", "ALTA"))
            if _RE_TASA.search(nc) and _es_numerico(c) and mx is not None:
                # La escala la dice el grueso de los datos (el percentil 75), no
                # el máximo: una tasa de 1,7 entre tasas de 0,01–0,25 es la
                # anomalía que el control debe cazar, no la escala.
                q75 = _num(st.get("75%"))
                hi = 1.0 if (q75 if q75 is not None else mx) <= 1 else 100.0
                ctrls.append(_control(ds, "rango", [n], {"minimo": 0.0, "maximo": hi, "umbral_pct": 0.0},
                                      f"{n} está entre 0 y {hi:g}.",
                                      f"describe(): min={mn}, 75%={q75}, max={mx}.", "ALTA"))
            if _RE_PLAZO.search(nc) and _es_numerico(c):
                ctrls.append(_control(ds, "no_negativos", [n], {"umbral_pct": 0.0},
                                      f"{n} no tiene valores negativos.",
                                      f"Plazo/edad; describe(): min={mn}." if mn is not None
                                      else "Columna de plazo.", "MEDIA"))
            if _RE_FECHA.search(nc):
                ctrls.append(_control(ds, "fecha_valida", [n], {"umbral_pct": 0.0},
                                      f"{n} contiene fechas válidas.",
                                      f"info(): tipo {c['dtype']}.", "MEDIA"))
                if mercado:
                    ctrls.append(_control(
                        ds, "serie_continua", [n], {"frecuencia": "B", "umbral_pct": 5.0},
                        f"La serie de {n} no tiene huecos (días hábiles).",
                        "Dominio de mercado: el backtesting exige una serie diaria sin huecos. "
                        "Tolerancia del 5 % por feriados: declara `excluir` con los feriados "
                        "para afinarla.", "ALTA"))
            # Nulos disfrazados: un mínimo o máximo «redondo» (-999, 99999999…)
            # o un texto de relleno como valor más frecuente.
            vals = sorted({x for v in (mn, mx) for x in _centinelas_de(v)}, key=float)
            if vals and _es_numerico(c):
                ctrls.append(_control(ds, "valores_centinela", [n], {"valores": vals, "umbral_pct": 0.0},
                                      f"{n} no usa valores que disfrazan un nulo ({', '.join(vals)}).",
                                      f"describe(): min={mn}, max={mx}.",
                                      "ALTA" if _RE_MONTO.search(nc) else "MEDIA"))
            top = st.get("top")
            if isinstance(top, str) and top.strip().upper() in _CENT_TXT:
                ctrls.append(_control(ds, "valores_centinela", [n], {"valores": [top.strip()], "umbral_pct": 0.0},
                                      f"{n} no usa «{top.strip()}» como valor de relleno.",
                                      f"describe(): top={top.strip()}, freq={st.get('freq')}.", "MEDIA"))
            std = _num(st.get("std"))
            if (std == 0) or (uniq == 1):
                ctrls.append(_control(ds, "constante", [n], {},
                                      f"{n} no es constante.",
                                      f"describe(): {'std=0' if std == 0 else 'unique=1'}.", "BAJA"))
    ctrls += _llaves_entre_bases(perfiles)
    return _deduplicar(ctrls)


def _singular(nombre: str) -> str:
    n = re.sub(r"[^a-z0-9]+", "_", _sin_tildes(nombre)).strip("_")
    for suf in ("es", "s"):
        if n.endswith(suf) and len(n) > len(suf) + 2:
            return n[: -len(suf)]
    return n


def base_padre(llave: str, a: str, b: str, distintos_a: Optional[float], distintos_b: Optional[float]) -> tuple[str, str]:
    """(padre, hijo) de una llave compartida: el padre es la base cuyo nombre aparece en la
    llave (clientes ↔ id_cliente); si no se sabe, la que tiene más valores distintos."""
    k = re.sub(r"[^a-z0-9]+", "_", _sin_tildes(llave))
    en_a, en_b = _singular(a) in k, _singular(b) in k
    if en_a != en_b:
        return (a, b) if en_a else (b, a)
    return (a, b) if (distintos_a or 0) >= (distintos_b or 0) else (b, a)


def _llaves_entre_bases(perfiles: list[dict]) -> list[dict]:
    """Llaves compartidas entre bases (id_cliente en clientes y en saldos): la del padre
    no se repite y la del hijo no tiene huérfanos (integridad referencial, BCBS 239)."""
    salida = []
    for i, pa in enumerate(perfiles):
        for pb in perfiles[i + 1:]:
            ca = {c["nombre"]: c for c in pa.get("columnas") or []}
            cb = {c["nombre"]: c for c in pb.get("columnas") or []}
            for k in [x for x in ca if x in cb and _RE_LLAVE.search(_sin_tildes(x).replace(" ", "_"))]:
                ua = _num((ca[k].get("stats") or {}).get("unique"))
                ub = _num((cb[k].get("stats") or {}).get("unique"))
                padre, hijo = base_padre(k, pa["nombre"], pb["nombre"], ua, ub)
                salida.append(_control(padre, "unicidad", [k], {"umbral_pct": 0.0},
                                       f"{k} identifica cada fila de «{padre}» (llave sin duplicados).",
                                       f"Llave compartida con «{hijo}»: en el maestro no puede repetirse.", "ALTA"))
                salida.append(_control(hijo, "integridad", [k], {"ref_dataset": padre, "ref_columna": k,
                                                                  "umbral_pct": 0.0},
                                       f"Todo {k} de «{hijo}» existe en «{padre}» (sin huérfanos).",
                                       "Integridad referencial entre bases: un huérfano es un registro que el modelo "
                                       "usa sin su maestro.", "ALTA"))
    return salida


#: Fechas que pueden ser futuras por naturaleza (vencimientos, proyecciones…).
_RE_FECHA_FUTURA_OK = re.compile(r"(venc|vto|fin|expir|maturity|proyec|proxim|futur|caduc|hasta|limite)")


def _es_fecha(c: dict) -> bool:
    d = (c.get("dtype") or "").lower()
    if any(x in d for x in ("datetime", "date", "timestamp")):
        return True
    return not _es_numerico(c) and bool(_RE_FECHA.search(_sin_tildes(c["nombre"])))


def bateria_completa(perfiles: list[dict], dominio: str = "") -> list[dict]:
    """
    Batería que corre SIEMPRE, sobre TODAS las columnas, con los tipos del
    catálogo que no necesitan conocimiento del negocio. Los que sí lo necesitan
    (listas de valores, patrones, bases de referencia, totales contables…)
    quedan como plantillas listas en el notebook y la hoja «Cobertura» dice
    cuáles faltan. Umbrales prudentes y criticidad BAJA: el validador ajusta.
    """
    ctrls: list[dict] = []
    for p in perfiles:
        ds, filas = p["nombre"], p.get("filas")

        def add(tipo, cols, params, desc, por_que):
            ctrls.append(_control(ds, tipo, cols, params, desc, f"Batería completa: {por_que}",
                                  "BAJA", origen="batería"))
        add("volumen_minimo", [], {"min_filas": 1}, f"La base «{ds}» no está vacía.", "siempre.")
        add("unicidad", [], {"umbral_pct": 0.0}, f"La base «{ds}» no tiene filas duplicadas.", "siempre.")
        for c in p["columnas"]:
            n, st = c["nombre"], c.get("stats") or {}
            add("completitud", [n], {"umbral_pct": 0.0}, f"{n} no tiene valores nulos.",
                f"info(): {c.get('no_nulos')} no nulos de {filas}.")
            add("valores_centinela", [n], {"umbral_pct": 0.0}, f"{n} no usa valores que disfrazan un nulo.",
                "lista habitual de centinelas.")
            if _es_numerico(c):
                add("outliers_iqr", [n], {"k": 3.0, "umbral_pct": 1.0},
                    f"{n} sin valores atípicos extremos (más del 1 %).", "regla IQR con k = 3.")
                mn, mx = _num(st.get("min")), _num(st.get("max"))
                if mn is not None and mx is not None:
                    add("rango", [n], {"minimo": mn, "maximo": mx, "umbral_pct": 0.0},
                        f"{n} dentro del rango del perfil [{mn:g}, {mx:g}].",
                        f"describe(): min={mn:g}, max={mx:g} (detecta que la base cambió).")
                add("proporcion_ceros", [n], {"umbral_pct": 50.0}, f"{n} no es mayoritariamente cero.",
                    "más del 50 % de ceros suele ser un dato faltante.")
                add("constante", [n], {}, f"{n} no es constante.", "una columna constante no informa.")
            elif _es_fecha(c):
                add("fecha_valida", [n], {"umbral_pct": 0.0}, f"{n} contiene fechas legibles.",
                    f"info(): tipo {c.get('dtype')}.")
                if not _RE_FECHA_FUTURA_OK.search(_sin_tildes(n)):
                    add("fecha_futura", [n], {"umbral_pct": 0.0}, f"{n} no tiene fechas futuras.",
                        "una fecha de algo ya ocurrido no puede ser futura.")
            else:
                add("espacios_extremos", [n], {"umbral_pct": 0.0}, f"{n} sin espacios sobrantes.",
                    "texto: espacios al inicio, al final o dobles.")
                add("caracteres_invalidos", [n], {"umbral_pct": 0.0},
                    f"{n} sin caracteres de control ni de mala codificación.", "texto.")
                uniq = _num(st.get("unique"))
                if uniq is not None and uniq <= 200:
                    add("categorias_equivalentes", [n], {"umbral_pct": 0.0},
                        f"{n} sin variantes de una misma categoría.", f"describe(): unique={int(uniq)}.")
                add("constante", [n], {}, f"{n} no es constante.", "una columna constante no informa.")
    return _deduplicar(ctrls)


# ─── Controles por TIPO DE MODELO (no son los mismos en VaR que en ALM o LaR) ──

_PNL = r"(pnl|p_?l|pyg|perdida|ganancia|resultado|retorno|rentab)"
_VAR = r"((^|_)var(_|\d|$)|cvar|expected_shortfall|valor_en_riesgo)"
_CORTE = r"(corte|proceso|reporte|fecha_?dato|fecha_?informacion)"

#: Reglas del tipo de modelo (carpeta del dominio del repositorio). Cada una:
#: `columna` (patrón sobre el nombre normalizado) o `pares` (dos patrones de
#: fecha), `tipo` del catálogo, `params`, `criticidad`, `que` y `por_que`.
#: `numerico`: solo columnas numéricas · `con_fecha`: añade la columna de fecha
#: de la base como 2.ª columna · `escala_p75`: rango 0–1 o 0–100 según el p75.
REGLAS_TIPO_MODELO: dict[str, list[dict]] = {
    "var": [
        {"columna": _PNL, "numerico": True, "tipo": "completitud", "params": {"umbral_pct": 0.0},
         "criticidad": "ALTA", "que": "la serie de P&L no tiene días sin dato",
         "por_que": "el backtesting compara P&L contra VaR día a día: un nulo es una observación perdida."},
        {"columna": _PNL, "numerico": True, "tipo": "outliers_iqr", "params": {"k": 5.0, "umbral_pct": 1.0},
         "criticidad": "MEDIA", "que": "el P&L no tiene saltos más allá de 5·IQR",
         "por_que": "las colas gruesas son normales en P&L; k = 5 caza errores de carga, no la cola."},
        {"columna": _PNL, "numerico": True, "tipo": "constante", "params": {},
         "criticidad": "ALTA", "que": "el P&L no es constante", "por_que": "un P&L plano invalida el backtesting."},
        {"columna": _VAR, "numerico": True, "tipo": "completitud", "params": {"umbral_pct": 0.0},
         "criticidad": "ALTA", "que": "el VaR está informado todos los días",
         "por_que": "sin VaR del día no hay excepción que contar."},
        {"columna": _VAR, "numerico": True, "tipo": "variacion_temporal", "con_fecha": True,
         "params": {"agregacion": "mean", "max_variacion_pct": 50.0, "umbral_pct": 5.0},
         "criticidad": "MEDIA", "que": "el VaR no salta más de un 50 % entre fechas consecutivas",
         "por_que": "un salto así suele ser un cambio de cartera, de parámetro o un error de carga."},
        {"columna": r"(excepcion|exception|breach|hit|violacion)", "tipo": "dominio",
         "params": {"valores": ["0", "1"], "umbral_pct": 0.0}, "criticidad": "ALTA",
         "que": "el indicador de excepción es 0 o 1", "por_que": "Kupiec y Christoffersen cuentan excepciones 0/1."},
    ],
    "alm": [
        {"columna": r"(cpr|prepago|smm)", "numerico": True, "tipo": "rango", "escala_p75": True,
         "params": {"minimo": 0.0, "umbral_pct": 0.0}, "criticidad": "ALTA",
         "que": "la tasa de prepago está entre 0 y 1 (o 0 y 100)", "por_que": "un CPR fuera de rango rompe la curva conductual."},
        {"columna": r"(^|_)beta(_|$)", "numerico": True, "tipo": "rango",
         "params": {"minimo": 0.0, "maximo": 1.0, "umbral_pct": 0.0}, "criticidad": "ALTA",
         "que": "el beta de traspaso está entre 0 y 1", "por_que": "un beta fuera de [0, 1] no tiene sentido económico."},
        {"columna": r"(saldo|balance|capital|principal)", "numerico": True, "tipo": "proporcion_ceros",
         "params": {"umbral_pct": 5.0}, "criticidad": "MEDIA", "que": "pocas posiciones con saldo cero",
         "por_que": "saldos en cero suelen ser operaciones canceladas que siguen en la base del gap."},
        {"columna": r"(banda|bucket|tramo|reprecio|repricing)", "tipo": "completitud", "params": {"umbral_pct": 0.0},
         "criticidad": "ALTA", "que": "toda posición tiene banda de reprecio", "por_que": "sin banda la posición no entra en el gap."},
        {"columna": r"(moneda|divisa|currency)", "tipo": "cardinalidad", "params": {"minimo": 1.0, "maximo": 10.0},
         "criticidad": "BAJA", "que": "pocas monedas distintas", "por_que": "muchas monedas suelen indicar códigos mal cargados."},
        {"columna": r"(delta_?eve|delta_?nii|(^|_)eve(_|$)|(^|_)nii(_|$))", "numerico": True, "tipo": "completitud",
         "params": {"umbral_pct": 0.0}, "criticidad": "ALTA", "que": "las sensibilidades ΔEVE/ΔNII están completas",
         "por_que": "son la base del límite IRRBB."},
        {"pares": (r"(venc|vto|maturity)", _CORTE), "tipo": "consistencia_fechas",
         "params": {"operador": ">=", "umbral_pct": 0.0}, "criticidad": "MEDIA",
         "que": "el vencimiento no es anterior al corte", "por_que": "una posición vencida no debería proyectar flujos (o es cartera vencida: dilo)."},
        {"pares": (r"(desembolso|apertura|origina|inicio|emision)", _CORTE), "tipo": "consistencia_fechas",
         "params": {"operador": "<=", "umbral_pct": 0.0}, "criticidad": "ALTA",
         "que": "la fecha de origen no es posterior al corte", "por_que": "una operación no puede nacer después de la foto."},
    ],
    "lar": [
        {"columna": r"(flujo|entrada|salida|inflow|outflow)", "numerico": True, "tipo": "completitud",
         "params": {"umbral_pct": 0.0}, "criticidad": "ALTA", "que": "los flujos están completos",
         "por_que": "un flujo nulo desplaza la brecha de liquidez."},
        {"columna": r"(entrada|salida|inflow|outflow)", "numerico": True, "tipo": "no_negativos",
         "params": {"umbral_pct": 0.0}, "criticidad": "MEDIA", "que": "entradas y salidas como magnitudes positivas",
         "por_que": "el signo va en la columna, no en el valor: mezclar convenciones invierte la brecha."},
        {"columna": r"(banda|bucket|tramo|horizonte)", "tipo": "completitud", "params": {"umbral_pct": 0.0},
         "criticidad": "ALTA", "que": "todo flujo tiene banda temporal", "por_que": "sin banda no hay brecha acumulada."},
        {"columna": r"(hqla|activo_?liquido|liquidos)", "numerico": True, "tipo": "no_negativos",
         "params": {"umbral_pct": 0.0}, "criticidad": "ALTA", "que": "los activos líquidos no son negativos",
         "por_que": "el HQLA es un stock: un negativo es un error."},
        {"columna": r"(haircut|castigo|descuento)", "numerico": True, "tipo": "rango", "escala_p75": True,
         "params": {"minimo": 0.0, "umbral_pct": 0.0}, "criticidad": "ALTA",
         "que": "el haircut está entre 0 y 1 (o 0 y 100)", "por_que": "un haircut fuera de rango infla o anula el HQLA."},
        {"columna": r"(lcr|nsfr|ratio|cobertura)", "numerico": True, "tipo": "no_negativos",
         "params": {"umbral_pct": 0.0}, "criticidad": "ALTA", "que": "los ratios regulatorios no son negativos",
         "por_que": "un LCR/NSFR negativo es imposible."},
        {"pares": (r"(fecha_?flujo|fecha_?pago|fecha_?cobro)", _CORTE), "tipo": "consistencia_fechas",
         "params": {"operador": ">=", "umbral_pct": 0.0}, "criticidad": "MEDIA",
         "que": "los flujos proyectados no son anteriores al corte", "por_que": "un flujo pasado no es liquidez futura."},
    ],
}


def _carpeta(dominio: str) -> str:
    try:
        from modulos.repositorio_controles import carpeta_de_dominio
        return carpeta_de_dominio(dominio) or ""
    except Exception:                                     # noqa: BLE001
        return _sin_tildes(dominio)


def _nnom(nombre: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", _sin_tildes(nombre)).strip("_")


def bateria_tipo_modelo(perfiles: list[dict], dominio: str = "") -> list[dict]:
    """Controles del catálogo propios del TIPO DE MODELO (VaR, ALM, LaR…), por la
    semántica de las columnas. Origen «tipo de modelo»."""
    carpeta = _carpeta(dominio)
    reglas = REGLAS_TIPO_MODELO.get(carpeta, [])
    ctrls: list[dict] = []
    for p in perfiles:
        cols = p["columnas"]
        fechas = [c for c in cols if _es_fecha(c)]
        fecha_base = next((c["nombre"] for c in fechas if re.search(r"(corte|fecha|periodo|date)", _nnom(c["nombre"]))),
                          fechas[0]["nombre"] if fechas else None)
        for r in reglas:
            por_que = f"Tipo de modelo {carpeta.upper()}: {r['por_que']}"
            if "pares" in r:
                a = next((c["nombre"] for c in fechas if re.search(r["pares"][0], _nnom(c["nombre"]))), None)
                b = next((c["nombre"] for c in fechas if re.search(r["pares"][1], _nnom(c["nombre"]))
                          and c["nombre"] != a), None)
                if a and b:
                    ctrls.append(_control(p["nombre"], r["tipo"], [a, b], dict(r["params"]),
                                          f"{a} {r['params']['operador']} {b}: {r['que']}.", por_que,
                                          r["criticidad"], origen="tipo de modelo"))
                continue
            for c in cols:
                if not re.search(r["columna"], _nnom(c["nombre"])):
                    continue
                if r.get("numerico") and not _es_numerico(c):
                    continue
                columnas = [c["nombre"]]
                if r.get("con_fecha"):
                    if not fecha_base or fecha_base == c["nombre"]:
                        continue
                    columnas.append(fecha_base)
                params = dict(r["params"])
                if r.get("escala_p75"):
                    st = c.get("stats") or {}
                    ref = _num(st.get("75%"))
                    ref = ref if ref is not None else _num(st.get("max"))
                    params["maximo"] = 1.0 if ref is None or ref <= 1 else 100.0
                ctrls.append(_control(p["nombre"], r["tipo"], columnas, params,
                                      f"{c['nombre']}: {r['que']}.", por_que, r["criticidad"],
                                      origen="tipo de modelo"))
    return _deduplicar(ctrls)


#: Sinónimos para enlazar los `campo_*` del repositorio con las columnas del perfil.
_SINONIMOS_CAMPO = {
    "pnl": _PNL, "var": _VAR, "excepcion": r"(excepcion|exception|breach|hit|violacion)",
    "fecha": r"(fecha|date|corte|periodo)", "saldo": r"(saldo|balance|capital|principal)",
    "monto": r"(monto|importe|flujo|saldo)", "escenario": r"(escenario|scenario|shock)",
    "bucket": r"(bucket|banda|tramo)", "banda": r"(banda|bucket|tramo|reprecio)",
    "entradas": r"(entrada|inflow)", "salidas": r"(salida|outflow)", "prepago": r"(prepago|cpr|smm)",
}


def _ligar_campos(params: dict, perfiles: list[dict]) -> tuple[dict, list[str], str]:
    """Enlaza cada `campo_*` con una columna del perfil (nombre exacto, o por
    sinónimos de la clave). Devuelve (params, pendientes, base elegida)."""
    idx = [(p["nombre"], c["nombre"], _nnom(c["nombre"])) for p in perfiles for c in p["columnas"]]
    nuevos, pendientes, votos = dict(params), [], {}
    for k, v in params.items():
        if not k.startswith("campo_") or not str(v or "").strip():
            continue
        hit = next(((ds, col) for ds, col, n in idx if n == _nnom(str(v))), None)
        if hit is None:
            clave = k[len("campo_"):]
            from modulos.tipos_modelo import ROLES as _ROLES_NEGOCIO
            patron = (_SINONIMOS_CAMPO.get(clave)
                      or (_ROLES_NEGOCIO[clave]["patron"] if clave in _ROLES_NEGOCIO else None)
                      or re.escape(_nnom(clave)))
            hit = next(((ds, col) for ds, col, n in idx if re.search(patron, n)), None)
        if hit:
            nuevos[k] = hit[1]
            votos[hit[0]] = votos.get(hit[0], 0) + 1
        else:
            pendientes.append(f"{k}={v!r}")
    base = max(votos, key=votos.get) if votos else (perfiles[0]["nombre"] if perfiles else "")
    if "dataset" in nuevos and not str(nuevos.get("dataset") or "").strip():
        nuevos["dataset"] = base
    return nuevos, pendientes, base


def controles_repositorio(perfiles: list[dict], dominio: str = "",
                          tipos_modelo: Optional[list[str]] = None) -> tuple[list[dict], list[str]]:
    """
    Controles especializados del repositorio del dominio
    (`inputs/repositorio_controles/<dominio>/`: Kupiec, LCR, CPR…), con sus
    columnas enlazadas al perfil. `shared/` no se repite: lo cubre la batería.
    El código se embebe en el notebook al construirlo (nunca se ejecuta aquí).

    Con `tipos_modelo` (elegidos por el validador) se suman las carpetas de esos
    tipos y solo entran los controles cuyo META["tipos"] los incluye (o que no
    declaran tipos): un prepago no recibe el gap de reprecio ni un VaR el LCR.
    """
    carpetas = [c for c in [_carpeta(dominio)] if c]
    if tipos_modelo:
        from modulos.tipos_modelo import carpetas_de_tipos
        carpetas += [c for c in carpetas_de_tipos(tipos_modelo) if c not in carpetas]
    if not carpetas:
        return [], []
    from modulos.repositorio_controles import cargar_controles
    ctrls, avisos = [], []
    for carpeta in carpetas:
        cs, av = cargar_controles(carpeta)
        ctrls += [c for c in cs if c["dominio_carpeta"] == carpeta]
        avisos += [a for a in av if a not in avisos]
    # Con tipo de modelo, un `dataset_<base>` vacío (p. ej. dataset_curva) se enlaza con la base real
    # que el tipo enlazó a esa base lógica (por roles y nombre); se edita en PARAMS_Dxx como el resto.
    bases_tipo: dict[str, str] = {}
    if tipos_modelo:
        from modulos.tipos_modelo import enlazar as _enlazar_tipos
        bases_tipo = {b: ds for b, ds in (_enlazar_tipos(perfiles, tipos_modelo).get("bases") or {}).items() if ds}
    salida = []
    for c in ctrls:
        meta = c["meta"] or {}
        carpeta = c["dominio_carpeta"]
        if tipos_modelo and meta.get("tipos") and not set(meta["tipos"]) & set(tipos_modelo):
            continue
        params, pendientes, base = _ligar_campos(dict(meta.get("params") or {}), perfiles)
        for k in [k for k in params if k.startswith("dataset_") and not str(params[k] or "").strip()]:
            if bases_tipo.get(k[len("dataset_"):]) not in (None, base):
                params[k] = bases_tipo[k[len("dataset_"):]]
        columnas = [v for k, v in params.items() if k.startswith("campo_") and str(v or "").strip()]
        salida.append({"dataset": base, "tipo": f"dominio:{c['nombre']}", "columnas": columnas,
                       "params": params, "dimension": meta.get("dimension") or "Dominio",
                       "descripcion": " ".join(str(meta.get("descripcion") or c["nombre"]).split())[:300],
                       "justificacion": f"Repositorio del tipo de modelo ({carpeta}/{c['archivo']})"
                                        + (f": {meta['referencia']}" if meta.get("referencia") else "."),
                       "criticidad": "ALTA", "evidencia_requerida": str(meta.get("evidencia") or "")[:300],
                       "origen": "dominio", "archivo": c["archivo"], "carpeta": carpeta,
                       "pendientes": pendientes})
    return salida, avisos


def cobertura(controles: list[dict]) -> list[dict]:
    """Por cada tipo del catálogo: cuántos controles lo usan en esta propuesta."""
    salida = []
    for t, m in CATALOGO.items():
        n = sum(1 for c in controles if c.get("tipo") == t)
        salida.append({"tipo": t, "dimension": m["dimension"], "controles": n,
                       "estado": "incluido" if n else "plantilla: necesita parámetros del negocio"})
    return salida


def _clave(c: dict) -> tuple:
    return (c["dataset"], c["tipo"], tuple(c.get("columnas") or ()))


def _deduplicar(ctrls: list[dict]) -> list[dict]:
    vistos, salida = set(), []
    for c in ctrls:
        if _clave(c) in vistos:
            continue
        vistos.add(_clave(c))
        salida.append(c)
    return salida


# ═════════════════════════════════════════════════════════════════════════════
# 4. PROPUESTA CON IA (validada aquí)
# ═════════════════════════════════════════════════════════════════════════════

def _catalogo_prompt() -> str:
    lineas = []
    for t, m in CATALOGO.items():
        ps = ", ".join(f"{k} ({'número' if v is float else 'lista' if v is list else 'texto'})"
                       for k, v in m["params"].items()) or "sin parámetros"
        lineas.append(f"- {t}: {m['descripcion']} Parámetros: {ps}.")
    return "\n".join(lineas)


def prompt_controles(perfiles: list[dict], dominio: str, contexto: str,
                     ya: list[dict]) -> str:
    from modulos.salida_ia import material_no_confiable as _mnc
    resumen_ya = "; ".join(f"{c['dataset']}.{'/'.join(c['columnas']) or '*'}:{c['tipo']}"
                           for c in ya[:60])
    # Lo aprendido (aprobado por un revisor) orienta a la IA sobre lo que la
    # entidad exige en este dominio; ya está en la propuesta, así que no se repite.
    aprendidos = [c for c in ya if c.get("origen") == "aprendido"][:15]
    criterio = ("Criterio aprendido de la entidad (controles que validadores anteriores de este "
                "dominio ejecutaron y un revisor aprobó; ya están incluidos, propón lo que falte "
                "en la misma línea): "
                + "; ".join(f"{c['tipo']} sobre {'/'.join(c['columnas']) or '*'} — {c['descripcion']}"
                            for c in aprendidos) + "\n\n") if aprendidos else ""
    return (
        "Eres especialista en calidad de datos de modelos de riesgo financiero "
        f"(dominio {dominio or 'no indicado'}). No ves los datos: solo su PERFIL (salida de "
        ".info() y .describe()). Propón los controles de calidad de datos ESPECÍFICOS que el "
        "validador debe ejecutar en su entorno, en especial los propios del dominio (series de "
        "P&L y fechas en VaR; flujos, plazos y buckets en LaR; tasas, saldos y plazos "
        "conductuales en ALM) y las relaciones entre columnas (consistencia).\n\n"
        "Usa SOLO estos tipos de control:\n" + _catalogo_prompt() + "\n\n"
        "Reglas: usa SOLO columnas que existen en el perfil del dataset (nombre exacto); "
        "en «justificacion» cita la cifra del perfil que motiva el control (no inventes "
        "cifras); umbral_pct es el % de incumplimiento tolerado (0 = ninguno). "
        f"No repitas estos controles ya propuestos: {resumen_ya or 'ninguno'}.\n\n"
        + criterio +
        'Devuelve SOLO este JSON: {"controles": [{"dataset": "…", "tipo": "…", '
        '"columnas": ["…"], "params": {…}, "descripcion": "control esperado, una frase", '
        '"justificacion": "…", "criticidad": "ALTA|MEDIA|BAJA", "evidencia_requerida": "…"}], '
        '"comentario": "1-2 frases sobre la calidad de datos que sugiere el perfil"}\n\n'
        + _mnc(perfil_texto(perfiles), "perfil_datos")
        + ("\n\nContexto del validador:\n" + _mnc(contexto[:3000], "contexto") if contexto else ""))


def normalizar_propuesta(propuesta: Any, perfiles: list[dict],
                         origen: str = "ia") -> tuple[list[dict], list[str]]:
    """
    Valida los controles que propuso la IA contra el catálogo y el PERFIL.
    Devuelve (controles válidos, avisos de lo descartado).
    """
    avisos: list[str] = []
    if not isinstance(propuesta, dict):
        return [], ["la propuesta de la IA no es un objeto JSON"]
    por_ds = {p["nombre"]: p for p in perfiles}
    cols_de = {p["nombre"]: {c["nombre"]: c for c in p["columnas"]} for p in perfiles}
    fuente_cifras = perfil_texto(perfiles, tope=10 ** 7)
    from modulos.graficos_estructurados import numeros
    cifras_ok = numeros(fuente_cifras)
    validos: list[dict] = []
    for i, c in enumerate((propuesta.get("controles") or [])[:60], start=1):
        if not isinstance(c, dict):
            continue
        tipo = str(c.get("tipo") or "").strip().lower()
        ds = str(c.get("dataset") or "").strip()
        if tipo not in CATALOGO:
            avisos.append(f"control {i}: tipo «{tipo}» no está en el catálogo; se descarta.")
            continue
        if ds not in por_ds:
            # Tolerancia: si solo hay una base, se asume esa.
            if len(por_ds) == 1:
                ds = next(iter(por_ds))
            else:
                avisos.append(f"control {i}: la base «{ds}» no está en el perfil; se descarta.")
                continue
        columnas = []
        malas = []
        for col in c.get("columnas") or []:
            col = str(col).strip()
            if col in cols_de[ds]:
                columnas.append(col)
                continue
            casa = next((k for k in cols_de[ds] if k.lower() == col.lower()), None)
            (columnas.append(casa) if casa else malas.append(col))
        if malas:
            avisos.append(f"control {i} ({tipo}): columnas inexistentes en «{ds}»: "
                          f"{', '.join(malas)}; se descarta.")
            continue
        params, error = validar_params(tipo, c.get("params"))
        if not columnas_validas(tipo, len(columnas), params):
            avisos.append(f"control {i} ({tipo}): necesita {columnas_texto(tipo)} columna(s) y trae "
                          f"{len(columnas)}; se descarta.")
            continue
        if not error and tipo in _CON_REFERENCIA_BASE:
            rds, rcol = params.get("ref_dataset", ""), params.get("ref_columna", "")
            if rds not in cols_de or (rcol and rcol not in cols_de.get(rds, {})):
                error = f"la referencia {rds}{'.' + rcol if rcol else ''} no está en el perfil"
            claves_ref = params.get("ref_claves") or (columnas[1:] if tipo == "conciliacion_por_grupo" else [])
            if not error and any(k not in cols_de.get(rds, {}) for k in claves_ref):
                error = f"las claves {claves_ref} no están en {rds}"
        if error:
            avisos.append(f"control {i} ({tipo}): {error}; se descarta.")
            continue
        just = " ".join(str(c.get("justificacion") or "").split())[:400]
        if numeros(just) - cifras_ok:
            avisos.append(f"control {i} ({tipo}): la justificación cita cifras que no están en "
                          "el perfil; se conserva el control y se marca la justificación.")
            just = "(justificación de la IA no verificable contra el perfil)"
        crit = str(c.get("criticidad") or "MEDIA").upper()
        validos.append(_control(
            ds, tipo, columnas, params,
            " ".join(str(c.get("descripcion") or CATALOGO[tipo]["descripcion"]).split())[:300],
            just, crit if crit in ("ALTA", "MEDIA", "BAJA") else "MEDIA",
            " ".join(str(c.get("evidencia_requerida") or "").split())[:300], origen))
    return validos, avisos


def _sumar_aprendidos(base: list[dict], aprendidos: list[dict]) -> int:
    """
    Añade a `base` los controles aprendidos (ya validados por quien los
    construye). Si coinciden con uno de las reglas (misma base, tipo y
    columnas), GANAN sus parámetros: es el umbral que los validadores fijaron
    y un revisor aprobó. Devuelve cuántos se incorporaron.
    """
    por_clave = {_clave(c): c for c in base}
    n = 0
    for a in aprendidos or []:
        k = _clave(a)
        if k in por_clave:
            c = por_clave[k]
            c["params"] = dict(a.get("params") or {})
            c["origen"] = "aprendido"
            c["leccion"] = a.get("leccion", "")
            c["justificacion"] = f"{c['justificacion']} · {a.get('justificacion', '')}".strip(" ·")
        else:
            base.append(a)
            por_clave[k] = a
        n += 1
    return n


_PESO_CRIT = {"ALTA": 3, "MEDIA": 2, "BAJA": 1}


def _negocio(perfiles: list[dict], tipos: list[str], ya: set) -> tuple[list[dict], list[dict], list[dict], dict]:
    """Controles de las FICHAS de los tipos de modelo elegidos (ids Mnn).
    Devuelve (para ejecutar, plantillas, no aplican, enlace). Un control de
    negocio que ya está propuesto (misma base, tipo y columnas) no se repite:
    su «por qué» de negocio se suma al existente."""
    from modulos import tipos_modelo as tm
    enlace = tm.enlazar(perfiles, tipos)
    ejecutar_, plantillas, omitidos = [], [], []
    return_existentes: dict = {}
    for c in tm.controles_negocio(perfiles, tipos, enlace):
        c["dimension"] = CATALOGO[c["tipo"]]["dimension"]
        if c.get("no_aplica"):
            omitidos.append(c)
            continue
        if c.get("plantilla"):
            plantillas.append(c)
            continue
        if not c["pendientes"]:
            k = (c["dataset"], c["tipo"], tuple(c["columnas"]))
            if k in ya:
                return_existentes[k] = c
                continue
            ya.add(k)
        ejecutar_.append(c)
    enlace["fusionados"] = return_existentes
    return ejecutar_, plantillas, omitidos, enlace


def _fusionar_negocio(controles: list[dict], fusion: dict) -> None:
    for c in controles:
        n = fusion.get(_clave(c))
        if not n:
            continue
        c["justificacion"] = f"{c.get('justificacion', '')} · {n['justificacion']}".strip(" ·")
        if _PESO_CRIT.get(n["criticidad"], 2) > _PESO_CRIT.get(c.get("criticidad", "MEDIA"), 2):
            c["criticidad"] = n["criticidad"]
        c.setdefault("tipo_modelo", n.get("tipo_modelo"))


def proponer(perfiles: list[dict], *, dominio: str = "", contexto: str = "",
             usar_ia: bool, llamar: Optional[Callable[[str, int], str]] = None,
             aprendidos: Optional[list[dict]] = None, bateria: bool = True,
             tipo_modelo: bool = True, tipos_modelo: Optional[list[str]] = None) -> dict[str, Any]:
    """
    Controles para el notebook: los deterministas, los APRENDIDOS del dominio
    (solo los que aprobó un revisor; ver `modulos.aprendizaje_controles`), con
    `usar_ia` los que proponga la IA (validados) y, con `bateria`, la BATERÍA
    COMPLETA que corre siempre sobre todas las columnas (ids Bnnn).

    `tipos_modelo` (explícito, de la ficha del modelo: «var», «runoff», «irrbb»…)
    suma los controles de NEGOCIO de cada tipo (ids Mnn, por roles enlazados a
    las columnas) y filtra el repositorio a los análisis de esos tipos.
    Devuelve {controles, avisos, comentario, origen, aprendidos, bateria, cobertura,
    tipos_modelo, enlace, negocio, plantillas_negocio, omitidos_negocio}.
    """
    tipos_modelo = list(tipos_modelo or [])
    if tipos_modelo:
        from modulos.tipos_modelo import validar_tipos
        tipos_modelo = validar_tipos(tipos_modelo)
    base = proponer_deterministas(perfiles, dominio)
    n_aprendidos = _sumar_aprendidos(base, aprendidos or [])
    avisos: list[str] = []
    comentario = ""
    if usar_ia:
        if llamar is None:
            from modulos.notebook_controles import llamar_ia_controles as llamar
        from modulos.motor_ia import _extraer_json
        crudo = llamar(prompt_controles(perfiles, dominio, contexto, base), 5000)
        try:
            prop = _extraer_json(crudo)
        except Exception as exc:                          # noqa: BLE001
            prop = None
            avisos.append(f"la IA no devolvió JSON utilizable ({exc}); se usan solo los "
                          "controles deterministas.")
        if prop is not None:
            extra, av = normalizar_propuesta(prop, perfiles)
            avisos += av
            comentario = " ".join(str((prop or {}).get("comentario") or "").split())[:600]
            ya = {_clave(c) for c in base}
            base += [c for c in extra if _clave(c) not in ya]
    controles = _deduplicar(base)
    for i, c in enumerate(controles, start=1):
        c["id"] = f"C{i:02d}"
    ya = {_clave(c) for c in controles}
    tipo_m: list[dict] = []
    repo: list[dict] = []
    negocio: list[dict] = []
    plantillas_neg: list[dict] = []
    omitidos_neg: list[dict] = []
    enlace: Optional[dict] = None
    if tipos_modelo:
        # Controles de NEGOCIO de las fichas (VaR ≠ run-off ≠ IRRBB): por roles.
        negocio, plantillas_neg, omitidos_neg, enlace = _negocio(perfiles, tipos_modelo, ya)
        _fusionar_negocio(controles, enlace.pop("fusionados", {}))
        for i, c in enumerate(negocio, start=1):
            c["id"] = f"M{i:02d}"
        avisos += [f"{c['id']} ({c['tipo']}): pendiente de enlazar {', '.join(c['pendientes'])}."
                   for c in negocio if c["pendientes"]][:40]
    if tipo_modelo:
        # Controles del TIPO DE MODELO: no son los mismos en VaR que en ALM o LaR.
        tipo_m = [c for c in bateria_tipo_modelo(perfiles, dominio) if _clave(c) not in ya]
        for i, c in enumerate(tipo_m, start=1):
            c["id"] = f"T{i:03d}"
        ya |= {_clave(c) for c in tipo_m}
        repo, av_repo = controles_repositorio(perfiles, dominio, tipos_modelo)
        for i, c in enumerate(repo, start=1):
            c["id"] = f"D{i:02d}"
        avisos += av_repo + [f"{c['id']} ({c['tipo'][len('dominio:'):]}): enlaza en el notebook "
                             f"{', '.join(c['pendientes'])} (no están en el perfil)." for c in repo if c["pendientes"]]
    extra: list[dict] = []
    if bateria:
        # Lo propuesto (reglas, aprendido, IA, tipo de modelo) manda: la batería
        # solo añade lo que falta, para que el notebook tenga SIEMPRE todos los controles.
        extra = [c for c in bateria_completa(perfiles, dominio) if _clave(c) not in ya]
        for i, c in enumerate(extra, start=1):
            c["id"] = f"B{i:03d}"
    controles += negocio + tipo_m + repo + extra
    return {"controles": controles, "avisos": avisos, "comentario": comentario,
            "origen": ("ia+reglas" if usar_ia else "reglas") + ("+aprendidos" if n_aprendidos else "")
                      + ("+negocio" if negocio else "")
                      + ("+tipo de modelo" if tipo_m or repo else "") + ("+batería" if extra else ""),
            "aprendidos": n_aprendidos, "tipo_modelo": len(tipo_m), "repositorio": len(repo),
            "bateria": len(extra), "cobertura": cobertura(controles),
            "tipos_modelo": tipos_modelo, "enlace": enlace, "negocio": len(negocio),
            "plantillas_negocio": plantillas_neg, "omitidos_negocio": omitidos_neg}


# ═════════════════════════════════════════════════════════════════════════════
# 5. NOTEBOOK AUTOCONTENIDO
# ═════════════════════════════════════════════════════════════════════════════

#: Columnas del Excel de resultados. Las cinco primeras son las que lee el
#: pipeline (`motores_entidad`); las ocho siguientes, el cuadro del entregable.
#: «Origen» y «Definición» (tipo, columnas y parámetros en JSON) permiten que el
#: agente APRENDA de lo que el validador ejecutó (`modulos.aprendizaje_controles`).
COLUMNAS_SALIDA = [
    "Descripción", "% de incumplimiento", "Resultado", "Umbral", "Detalle observación",
    "Control", "Dimensión", "Control Esperado", "% De cumplimiento del data set",
    "Diagnóstico", "Decisión", "Control o Evidencia requerida", "Referencia en el entregable",
    "Dataset", "Columnas", "Tipo", "N evaluados", "N afectados", "Criticidad",
    "Justificación del control", "Origen", "Definición", "Tipo de modelo",
]

#: Hojas del Excel de resultados. La PRIMERA es la que leen el pipeline y la revisión.
#: En la validación completa (etapa 01) se añaden detrás las tablas de la etapa y un «Indice».
HOJAS_SALIDA = ("Controles", "Resumen", "Cobertura", "Roles", "Perfil_vs_datos", "Controles_personalizados",
                "Metadatos")

#: Columnas de la hoja de controles programados por el validador.
COLUMNAS_PERSONALIZADOS = ["Control", "Función", "Descripción", "Dimensión", "Dataset",
                           "Columnas", "Parámetros", "Código"]

#: «Cómo prenderlo»: va dentro del notebook y en la guía (docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md).
GUIA_PRENDER_MD = r"""## ▶ Cómo prenderlo (ejecutarlo), paso a paso

**Requisitos:** Python 3.9 o superior con `pandas`, `numpy` y `openpyxl` (para el Excel).
Opcionales: `matplotlib` (gráfico) y `pyarrow` (archivos `.parquet`). **No** necesitas VIRF
ni internet: el notebook no llama a ninguna IA ni envía datos a ningún sitio.

**Opción A · En tu PC con Jupyter**
1. Guarda este `.ipynb` en una carpeta y abre una terminal ahí.
2. Crea el entorno (solo la primera vez):
   ```
   python -m venv .venv
   .venv\Scripts\activate            (Windows)
   source .venv/bin/activate         (Mac / Linux)
   pip install pandas numpy openpyxl matplotlib jupyterlab
   ```
3. Arranca Jupyter con `jupyter lab` y abre el notebook.
4. En **0 · Configuración** escribe en `RUTAS` la ruta de cada base.
5. Menú **Run → Run All Cells** (o *Kernel → Restart Kernel and Run All Cells*).

**Opción B · En VS Code:** abre el `.ipynb`, elige el intérprete del entorno en
*Select Kernel* (arriba a la derecha) y pulsa **Run All**. Si pide instalar `ipykernel`, acepta.

**Opción C · En Databricks:** *Workspace → Import* el `.ipynb`. En **3 · Carga** usa la
lectura mínima que trae comentada (`select` de las columnas que usan los controles + filtro
del corte + `limit`): nunca leas la tabla completa. Guarda la salida en tu volumen y descárgala.

**¿Quieres probarlo antes de tener los datos?** Pon `MODO_DEMO = True` y ejecuta todo:
genera datos **sintéticos** con la forma del perfil. Sirve para comprobar que el notebook
prende; esos resultados **no** valen para la validación (el Excel lo dice y VIRF no los usa
ni en la validación ni en el aprendizaje).

**Qué genera** (en la carpeta de `SALIDA`):

| Archivo | Qué es | ¿Se devuelve a VIRF? |
|---|---|---|
| `resultado_controles_datos.xlsx` | Cuadro de cumplimiento + comprobación contra el perfil + controles programados + metadatos (huella sha256 de cada base) | **Sí** |
| `resultado_controles_datos.csv` | El mismo cuadro, en CSV | Opcional |
| `resultado_controles_datos_resumen.png` | Gráfico del % de incumplimiento por control | No (es para ti) |
| `evidencia_local_resultado_controles_datos.xlsx` | Muestra de las filas que fallan, una hoja por control | **No**: puede tener datos personales; guárdala como soporte |

**Si algo falla**

| Mensaje | Qué hacer |
|---|---|
| `FileNotFoundError` | Revisa la ruta en `RUTAS` (en Windows: `r"C:\carpeta\archivo.csv"`). |
| `UnicodeDecodeError` | En `OPCIONES_LECTURA`: `{'base': {'encoding': 'latin-1'}}`. |
| Todas las columnas salen pegadas en una | Separador: `{'base': {'sep': ';'}}` en `OPCIONES_LECTURA`. |
| `ModuleNotFoundError: openpyxl` | `pip install openpyxl` (mientras tanto se guarda el CSV). |
| Un control dice «No evaluable — No se pudo ejecutar» | La columna no existe o cambió de nombre: mira **3 · Comprobación contra el perfil**. |
| `MemoryError` o va muy lento | Lee solo lo necesario: `{'base': {'usecols': COLUMNAS_USADAS['base']}}` (en parquet, `columns`). |
"""

_INDICE_MD = """## Índice

· **Entender el modelo**: qué hace, qué bases usa, qué puede fallar en los datos y qué pedir a la primera línea.
0. **Configuración**: rutas de tus bases (lo único obligatorio), opciones y el enlace `BASES` / `ROLES`.
1. **Entorno**: versiones y paquetes opcionales.
2. **Librería y perfil**: funciones de control, adaptadores y lo que pegaste en VIRF (no editar).
3. **Carga y comprobación contra el perfil**: avisa si la base no es la que se perfiló; **3b** enlace de roles.
4. **Controles propuestos**: reglas, IA, aprendidos y los del dominio; una celda por control.
4a. **Controles del tipo de modelo (negocio)**: por roles, con el porqué de negocio (ids `M…`).
4b. **Batería completa**: corre SIEMPRE sobre todas las columnas (solo muestra lo que no cumple).
4c. **Controles del repositorio del tipo de modelo**: los especializados (Kupiec, LCR, CPR, run-off…).
4d. **Batería dinámica**: columnas que no estaban en el perfil (se descubren al cargar).
5. **Tus controles sin programar**: plantillas listas de TODOS los tipos que faltan, con tus columnas.
6. **Tus controles programados o traídos de otros notebooks**: con adaptadores, sin reescribirlos.
7. **Resumen y porcentaje de cumplimiento**: global, ponderado, por dimensión, base y origen; cobertura del catálogo.
8. **Excel de resultados**: lo que devuelves a VIRF (y la evidencia local, que no se sube).
9. **Devolverlo a VIRF y enseñar al agente.**"""

_MD_PROPUESTOS = """## 4 · Controles propuestos

Cada celda ejecuta un control y escribe `>>>> Cxx: …` con su decisión.

* **Cambiar el umbral:** edita `umbral_pct=` (u otro parámetro) en su celda. El Excel lo
  refleja y, si al devolverlo eliges *Enseñar al agente*, el agente aprende ese umbral para
  el dominio.
* **Quitar un control:** comenta su celda (`Ctrl + /`). Al devolver el Excel el agente lo
  registra como **descartado**; un control que se descarta más veces de las que se usa deja
  de proponerse.
* **Re-ejecutar** una celda no duplica su resultado."""

_MD_DEVOLVER = """## 9 · Devolverlo a VIRF y enseñar al agente

1. En VIRF: **Controles de datos → ✨ Diseñar con IA → 3 · Revisar resultados**.
2. Sube el Excel de `SALIDA`, elige su **clasificación** y pulsa **Revisar resultados**. El
   agente revisa la coherencia entre lo medido y lo decidido, los controles que faltan, los
   que no se pudieron evaluar y las diferencias contra el perfil.
3. Marca **«Usar estos resultados en la validación»** para que entren en el ámbito
   *Calidad de datos*.
4. Marca **«Enseñar al agente»** para que registre lo que ejecutaste (los controles que
   mantuviste, los umbrales que cambiaste y los que añadiste en 5 y 6) como **lecciones del
   dominio**. Quedan **pendientes** hasta que un **revisor** las apruebe; desde entonces el
   agente las propone solo en el próximo modelo del mismo dominio que tenga esas columnas.
   El código de la sección 6 **no** se reutiliza solo: viaja como texto para que un
   desarrollador lo revise y, si vale, lo convierta en un tipo del catálogo.
5. **No subas** la evidencia local (`evidencia_local_…xlsx`): contiene filas reales. Guárdala
   como soporte por si te piden el detalle.

> Los resultados de `MODO_DEMO = True` quedan marcados en el Excel: VIRF los revisa, pero no
> los usa en la validación ni en el aprendizaje."""


def _md(texto: str):
    import nbformat as nbf
    return nbf.v4.new_markdown_cell(texto)


def _code(texto: str):
    import nbformat as nbf
    return nbf.v4.new_code_cell(texto)


def _celda_md(texto: Any) -> str:
    return " ".join(str(texto or "").split()).replace("|", "\\|")


def tabla_catalogo_md() -> str:
    """Tabla Markdown del catálogo (la usan el notebook y la guía)."""
    filas = ["| Tipo | Dimensión | Columnas | Parámetros | Qué mide |", "|---|---|---|---|---|"]
    for t, m in CATALOGO.items():
        ps = ", ".join(f"`{k}`" for k in m["params"]) or "—"
        filas.append(f"| `{t}` | {m['dimension']} | {columnas_texto(t)} | {ps} | {_celda_md(m['descripcion'])} |")
    return "\n".join(filas)


def _literal_seguro(obj: Any) -> Any:
    """Algo que `repr` escribe como literal de Python válido (sin nan/inf)."""
    if isinstance(obj, bool) or obj is None or isinstance(obj, (str, int)):
        return obj
    if isinstance(obj, float):
        return obj if obj == obj and obj not in (float("inf"), float("-inf")) else None
    if isinstance(obj, dict):
        return {str(k): _literal_seguro(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_literal_seguro(v) for v in obj]
    return str(obj)


def _perfil_literal(perfiles: list[dict]) -> dict:
    """Lo que el notebook necesita del perfil: comprobar las bases y el modo demo."""
    claves = ("min", "max", "mean", "std", "unique", "top")
    return _literal_seguro({
        p["nombre"]: {"filas": p.get("filas"),
                      "columnas": {c["nombre"]: {"dtype": c.get("dtype"), "no_nulos": c.get("no_nulos"),
                                                 "stats": {k: v for k, v in (c.get("stats") or {}).items()
                                                           if k in claves and v is not None}}
                                   for c in p["columnas"]}}
        for p in perfiles})


def _columnas_usadas(controles: list[dict], perfiles: list[dict]) -> dict[str, list[str]]:
    """Columnas que tocan los controles, por base: para leer solo lo necesario."""
    todas = {p["nombre"]: [c["nombre"] for c in p["columnas"]] for p in perfiles}
    usadas: dict[str, list[str]] = {p["nombre"]: [] for p in perfiles}
    completas: set[str] = set()
    for c in controles:
        lst = usadas.setdefault(c["dataset"], [])
        if c["tipo"] == "unicidad" and not c.get("columnas"):
            completas.add(c["dataset"])            # filas idénticas: hacen falta todas
        for col in c.get("columnas") or []:
            if col not in lst:
                lst.append(col)
        if c["tipo"] == "integridad":
            ps = c.get("params") or {}
            if ps.get("ref_dataset") and ps.get("ref_columna"):
                lr = usadas.setdefault(ps["ref_dataset"], [])
                if ps["ref_columna"] not in lr:
                    lr.append(ps["ref_columna"])
    for ds in completas:
        usadas[ds] = list(todas.get(ds) or usadas.get(ds) or [])
    return usadas


def _columnas_por_clase(perfiles: list[dict]) -> dict[str, Any]:
    """Columnas reales del perfil por clase (para escribir ejemplos con TUS nombres)."""
    nums, fechas, textos = [], [], []
    for p in perfiles:
        for c in p["columnas"]:
            par = (p["nombre"], c["nombre"])
            (nums if _es_numerico(c) else fechas if _es_fecha(c) else textos).append(par)
    base = perfiles[0]["nombre"] if perfiles else "base"
    otra = perfiles[1]["nombre"] if len(perfiles) > 1 else "OTRA_BASE"
    return {"nums": nums, "fechas": fechas, "textos": textos, "base": base, "otra": otra}


def _ejemplo_de_tipo(tipo: str, k: dict) -> dict:
    """Un control de ejemplo del tipo, con columnas reales cuando las hay."""
    def col(lista, i=0, defecto="COLUMNA"):
        return lista[i] if len(lista) > i else (k["base"], defecto)
    n0, n1 = col(k["nums"], 0, "COLUMNA_NUMERICA"), col(k["nums"], 1, "OTRA_COLUMNA_NUMERICA")
    n2 = col(k["nums"], 2, "COLUMNA_RESULTADO")
    f0, f1 = col(k["fechas"], 0, "COLUMNA_FECHA"), col(k["fechas"], 1, "OTRA_COLUMNA_FECHA")
    t0, t1 = col(k["textos"], 0, "COLUMNA_TEXTO"), col(k["textos"], 1, "OTRA_COLUMNA_TEXTO")
    plantillas = {
        "completitud": (t0, [t0[1]], {"umbral_pct": 0}, "sin nulos"),
        "unicidad": (t0, [t0[1]], {"umbral_pct": 0}, "identifica cada fila"),
        "rango": (n0, [n0[1]], {"minimo": 0, "maximo": 1_000_000, "umbral_pct": 0}, "dentro del rango de negocio"),
        "no_negativos": (n0, [n0[1]], {"umbral_pct": 0}, "sin negativos"),
        "dominio": (t0, [t0[1]], {"valores": ["VALOR_1", "VALOR_2"], "umbral_pct": 0}, "solo valores permitidos"),
        "tipo_numerico": (t0, [t0[1]], {"umbral_pct": 0}, "solo números"),
        "fecha_valida": (f0, [f0[1]], {"desde": "2000-01-01", "hasta": "2030-12-31", "umbral_pct": 0}, "fechas válidas"),
        "frescura": (f0, [f0[1]], {"max_dias": 31}, "la fecha más reciente tiene menos de 31 días"),
        "volumen_minimo": ((k["base"], ""), [], {"min_filas": 1000}, "al menos 1 000 filas"),
        "constante": (t0, [t0[1]], {}, "no es constante"),
        "outliers_iqr": (n0, [n0[1]], {"k": 3, "umbral_pct": 1}, "sin atípicos extremos"),
        "consistencia": (n0, [n0[1], n1[1]], {"operador": "<=", "umbral_pct": 0}, "la 1.ª no supera a la 2.ª"),
        "formato": (t0, [t0[1]], {"patron": r"^[A-Z0-9]+$", "umbral_pct": 0}, "cumple el formato"),
        "integridad": (t0, [t0[1]], {"ref_dataset": k["otra"], "ref_columna": t0[1]}, "existe en la otra base"),
        "suma_control": (n0, [n0[1]], {"valor_esperado": 0.0, "tolerancia_pct": 0.5}, "cuadra con el total contable (pon el total)"),
        "completitud_condicional": (t0, [t0[1], t1[1]], {"valores": ["VALOR"], "umbral_pct": 0}, "si la 1.ª tiene valor, la 2.ª también"),
        "valores_centinela": (t0, [t0[1]], {}, "sin nulos disfrazados"),
        "serie_continua": (f0, [f0[1]], {"frecuencia": "M", "umbral_pct": 0}, "no faltan periodos"),
        "estabilidad_psi": (n0, [n0[1], f0[1]], {"umbral_psi": 0.25}, "distribución estable entre periodos"),
        "longitud": (t0, [t0[1]], {"minimo": 8, "maximo": 8, "umbral_pct": 0}, "longitud fija (p. ej. DNI = 8)"),
        "espacios_extremos": (t0, [t0[1]], {"umbral_pct": 0}, "sin espacios sobrantes"),
        "caracteres_invalidos": (t0, [t0[1]], {"umbral_pct": 0}, "sin caracteres raros"),
        "categorias_equivalentes": (t0, [t0[1]], {"umbral_pct": 0}, "sin variantes de una categoría"),
        "fecha_futura": (f0, [f0[1]], {"umbral_pct": 0}, "sin fechas futuras"),
        "consistencia_fechas": (f0, [f0[1], f1[1]], {"operador": "<=", "umbral_pct": 0}, "la 1.ª fecha no es posterior a la 2.ª"),
        "proporcion_ceros": (n0, [n0[1]], {"umbral_pct": 10}, "pocos ceros"),
        "cardinalidad": (t0, [t0[1]], {"minimo": 1, "maximo": 10}, "entre 1 y 10 categorías"),
        "conciliacion_totales": (n0, [n0[1]], {"ref_dataset": k["otra"], "ref_columna": n0[1], "tolerancia_pct": 0.5},
                                 "cuadra con la otra base"),
        "conciliacion_conteos": ((k["base"], ""), [], {"ref_dataset": k["otra"], "tolerancia_pct": 0},
                                 "mismas filas que la otra base"),
        "variacion_temporal": (n0, [n0[1], f0[1]], {"agregacion": "sum", "max_variacion_pct": 20, "umbral_pct": 0},
                               "sin saltos de más del 20 % entre periodos"),
        "valores_repetidos": (n0, [n0[1], f0[1]], {"max_repeticiones": 5, "umbral_pct": 1},
                              "sin valores rancios (repetidos más de 5 veces seguidas); añade el grupo como 3.ª columna"),
        "saltos_serie": (n0, [n0[1], f0[1]], {"k": 10, "umbral_pct": 0.5},
                         "sin saltos de más de 10 desviaciones robustas; añade el grupo como 3.ª columna"),
        "monotonia": (n0, [n0[1], n1[1]], {"sentido": "creciente", "umbral_pct": 0}, "la 1.ª no supera a la 2.ª en cada fila"),
        "monotonia_curva": (n0, [n0[1], f0[1]], {"sentido": "decreciente", "umbral_pct": 0},
                            "baja al avanzar la 2.ª columna (plazo o fecha)"),
        "relacion_aritmetica": (n0, [n0[1], n1[1], n2[1]], {"operacion": "resta", "tolerancia_pct": 0.5, "umbral_pct": 0},
                                "la 3.ª es la 1.ª menos la 2.ª"),
        "diferencia_relativa": (n0, [n0[1], n1[1]], {"tolerancia_pct": 1, "umbral_pct": 0},
                                "la 1.ª y la 2.ª no difieren más del 1 %"),
        "categorias_requeridas": (t0, [t0[1]], {"valores": ["VALOR_1", "VALOR_2"], "umbral_pct": 0},
                                  "están todas las categorías requeridas"),
        "combinaciones_completas": (f0, [f0[1], t0[1]], {"umbral_pct": 0}, "panel completo (todas las combinaciones)"),
        "minimo_por_grupo": (t0, [t0[1]], {"min_filas": 30, "umbral_pct": 0}, "cada grupo con al menos 30 filas"),
        "suma_por_grupo": (n0, [n0[1], t0[1]], {"valor_esperado": 1.0, "tolerancia_pct": 0.5, "umbral_pct": 0},
                           "la suma por grupo es 1"),
        "conciliacion_por_grupo": (n0, [n0[1], t0[1]], {"ref_dataset": k["otra"], "ref_columna": n0[1],
                                                        "ref_claves": [t0[1]], "tolerancia_pct": 0.5, "umbral_pct": 0},
                                   "cuadra con la otra base en cada grupo"),
        "signo_por_categoria": (n0, [n0[1], t0[1]], {"positivos": ["ACTIVO"], "negativos": ["PASIVO"], "umbral_pct": 0},
                                "signo coherente con la categoría"),
        "banda_coherente": (n0, [n0[1], t0[1]], {"limites": [0, 30, 90, 365, 36500],
                                                 "etiquetas": ["0-1M", "1-3M", "3-12M", ">1A"], "umbral_pct": 0},
                            "la banda corresponde a los días (pon las bandas del manual)"),
        "fechas_habiles": (f0, [f0[1]], {"excluir": [], "umbral_pct": 0}, "sin fines de semana ni feriados"),
    }
    (ds, _c), columnas, params, que = plantillas.get(tipo, (t0, [t0[1]], {}, ""))
    return {"dataset": ds, "tipo": tipo, "columnas": columnas, "params": params,
            "descripcion": f"{', '.join(columnas) or ds}: {que}", "criticidad": "MEDIA"}


def plantillas_catalogo(perfiles: list[dict]) -> dict[str, dict]:
    """Un ejemplo listo de CADA tipo del catálogo (con tus columnas cuando las hay)."""
    k = _columnas_por_clase(perfiles)
    return {t: _ejemplo_de_tipo(t, k) for t in CATALOGO}


def _comentado(obj: Any, sangria: str = "    # ") -> str:
    import pprint
    return "\n".join(sangria + linea
                     for linea in pprint.pformat(obj, width=86, sort_dicts=False).splitlines())


def _umbral_txt(tipo: str, params: dict) -> str:
    if "umbral_pct" in params:
        return f"{params['umbral_pct']:g} % de incumplimiento"
    if tipo == "estabilidad_psi":
        return f"PSI ≤ {params.get('umbral_psi', 0.25):g}"
    if tipo == "suma_control":
        return f"diferencia ≤ {params.get('tolerancia_pct', 0.0):g} %"
    if tipo == "frescura":
        return f"≤ {params.get('max_dias', 31):g} días"
    if tipo == "volumen_minimo":
        return f"≥ {params.get('min_filas', 1):g} filas"
    return "sin tolerancia (cumple o no cumple)"


_CODIGO_PERFIL = r'''
import hashlib
import json
import platform
import sys
from datetime import datetime


def _familia(dtype):
    d = str(dtype or "").lower()
    if any(x in d for x in ("datetime", "date", "timestamp")):
        return "fecha"
    if "bool" in d:
        return "bool"
    if any(x in d for x in ("int", "float", "double", "decimal", "long", "numér", "numer")):
        return "num"
    return "texto"


def huella(ruta):
    """sha256 del archivo: prueba qué base exacta se ejecutó."""
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 20), b""):
            h.update(bloque)
    return h.hexdigest()


def leer(ruta, **kw):
    p = Path(ruta)
    ext = p.suffix.lower()
    if ext == ".csv":
        kw.setdefault("sep", None)
        if kw["sep"] is None:
            kw.setdefault("engine", "python")
        return pd.read_csv(p, **kw)
    if ext in (".xlsx", ".xlsm", ".xls"):
        return pd.read_excel(p, **kw)
    if ext == ".parquet":
        return pd.read_parquet(p, **kw)
    if ext == ".sas7bdat":
        return pd.read_sas(p, **kw)
    if ext in (".pkl", ".pickle"):
        return pd.read_pickle(p)
    raise ValueError(f"formato no soportado: {ext}")


def datos_demo(perfil, n_max=500, semilla=7):
    """Datos SINTÉTICOS con la forma del perfil: solo para comprobar que el notebook corre."""
    rng = np.random.default_rng(semilla)
    n = int(min(perfil.get("filas") or 200, n_max))
    datos = {}
    for col, c in (perfil.get("columnas") or {}).items():
        st, fam = c.get("stats") or {}, _familia(c.get("dtype"))
        try:
            if fam == "num":
                lo = float(st["min"]) if st.get("min") is not None else 0.0
                hi = float(st["max"]) if st.get("max") is not None else lo + 100.0
                v = rng.uniform(lo, hi if hi > lo else lo + 1.0, n)
                if "int" in str(c.get("dtype") or ""):
                    v = np.round(v)
            elif fam == "fecha":
                ini = pd.Timestamp(st["min"]) if st.get("min") else pd.Timestamp("2026-01-01")
                fin = pd.Timestamp(st["max"]) if st.get("max") else ini + pd.Timedelta(days=365)
                v = ini + pd.to_timedelta(rng.integers(0, max(int((fin - ini).days), 1) + 1, n), unit="D")
            else:
                k = int(float(st.get("unique") or 5))
                vals = ([str(st["top"])] if st.get("top") else []) + [f"{col}_{i}" for i in range(max(min(k, 50), 1))]
                v = rng.choice(vals, n)
        except Exception:
            v = rng.choice([f"{col}_{i}" for i in range(5)], n)
        s = pd.Series(v)
        if c.get("no_nulos") is not None and perfil.get("filas"):
            p_nulo = 1 - c["no_nulos"] / perfil["filas"]
            if p_nulo > 0:
                s[rng.random(n) < p_nulo] = None
        datos[col] = s
    return pd.DataFrame(datos)
'''.strip()


_CODIGO_CARGA = r'''
datasets, HUELLAS = {}, {}
if MODO_DEMO:
    print("MODO_DEMO: datos SINTÉTICOS con la forma del perfil (no valen para la validación).")
    for nombre in RUTAS:
        datasets[nombre] = datos_demo(PERFIL.get(nombre, {}))
        HUELLAS[nombre] = "demo (datos sintéticos)"
else:
    for nombre, ruta in RUTAS.items():
        datasets[nombre] = leer(ruta, **OPCIONES_LECTURA.get(nombre, {}))
        HUELLAS[nombre] = huella(ruta) if CALCULAR_HUELLA and Path(ruta).is_file() else "—"

# En Databricks (o si ya tienes la base en memoria), carga SOLO lo necesario:
# datasets["NOMBRE"] = (spark.table("esquema.tabla")
#                       .select(*COLUMNAS_USADAS["NOMBRE"])          # solo las columnas de los controles
#                       .where("fecha_corte = '2026-10-31'")         # el corte que validas
#                       .limit(5_000_000)
#                       .toPandas())
# HUELLAS["NOMBRE"] = "spark: esquema.tabla, corte 2026-10-31"

for nombre, df in datasets.items():
    print(f"{nombre}: {df.shape[0]:,} filas x {df.shape[1]} columnas · huella {str(HUELLAS.get(nombre, '—'))[:16]}")

# ── Comprobación contra el perfil que pegaste en VIRF ──
PERFIL_VS_DATOS = []
for nombre, df in datasets.items():
    esperado = PERFIL.get(nombre, {})
    cols_esp = esperado.get("columnas", {})
    filas_esp = esperado.get("filas")
    PERFIL_VS_DATOS.append({
        "Base": nombre, "Columna": "(filas)", "Perfil": filas_esp, "Datos": len(df),
        "Aviso": (f"el perfil decía {filas_esp:,} filas y la base tiene {len(df):,}"
                  if filas_esp is not None and len(df) != filas_esp else ""), "Nota": ""})
    for col in list(cols_esp) + [c for c in df.columns if c not in cols_esp]:
        e = cols_esp.get(col)
        if e is None:
            PERFIL_VS_DATOS.append({"Base": nombre, "Columna": col, "Perfil": "—",
                                    "Datos": str(df[col].dtype), "Aviso": "",
                                    "Nota": "columna que no estaba en el perfil"})
            continue
        if col not in df.columns:
            PERFIL_VS_DATOS.append({"Base": nombre, "Columna": col, "Perfil": e.get("dtype"),
                                    "Datos": "—", "Aviso": "FALTA en la base (estaba en el perfil)",
                                    "Nota": ""})
            continue
        avisos, notas = [], []
        fam_p, fam_d = _familia(e.get("dtype")), _familia(df[col].dtype)
        if fam_p != fam_d:
            if fam_p == "fecha" and fam_d == "texto":
                notas.append("fecha leída como texto (los controles la convierten)")
            else:
                avisos.append(f"tipo {e.get('dtype')} → {df[col].dtype}")
        nn = int(df[col].notna().sum())
        if e.get("no_nulos") is not None and nn != e["no_nulos"]:
            avisos.append(f"no nulos {e['no_nulos']:,} → {nn:,}")
        PERFIL_VS_DATOS.append({"Base": nombre, "Columna": col, "Perfil": e.get("dtype"),
                                "Datos": str(df[col].dtype), "Aviso": "; ".join(avisos),
                                "Nota": "; ".join(notas)})
DIFERENCIAS = [r for r in PERFIL_VS_DATOS if r["Aviso"]]
print(f"\nComprobación contra el perfil: {len(DIFERENCIAS)} diferencia(s).")
for r in DIFERENCIAS[:30]:
    print(f"  ⚠ {r['Base']}.{r['Columna']}: {r['Aviso']}")
if not DIFERENCIAS:
    print("  ✓ Las bases coinciden con el perfil que pegaste en VIRF.")
elif MODO_DEMO:
    print("  (en MODO_DEMO las diferencias son normales: los datos son sintéticos)")

# ── Motor de ejecución ──
RESULTADOS, EVIDENCIAS = [], {}


def ejecutar(meta, funcion, _mostrar=True, **params):
    """Ejecuta un control, imprime su línea y guarda el resultado (y la evidencia local).
    Con `_mostrar=False` (batería) solo imprime lo que no cumple."""
    df = datasets.get(meta["dataset"])
    # Los controles del repositorio deciden por su propia prueba (Kupiec, LCR…):
    # traen "umbral": None y la revisión no los compara contra un %.
    meta = {**meta, "params": {k: v for k, v in params.items() if k != "referencia"},
            "umbral": meta["umbral"] if "umbral" in meta
            else params.get("umbral_pct", params.get("tolerancia_pct", 0.0))}
    try:
        if df is None:
            raise KeyError(f"no está cargada la base {meta['dataset']!r}")
        r = funcion(df, meta["columnas"], datasets=datasets, **params)
    except Exception as e:
        r = {"evaluados": 0, "afectados": 0, "pct_incumplimiento": None,
             "pct_cumplimiento": None, "decision": "No evaluable",
             "diagnostico": f"No se pudo ejecutar: {type(e).__name__}: {e}"}
    mascara = r.pop("_mascara", None)
    if GUARDAR_EVIDENCIA_LOCAL and mascara is not None and r.get("afectados"):
        try:
            EVIDENCIAS[meta["id"]] = df.loc[mascara[mascara.astype(bool)].index[:MUESTRA_EVIDENCIA]]
        except Exception:
            pass
    RESULTADOS[:] = [x for x in RESULTADOS if x["id"] != meta["id"]]   # re-ejecutar no duplica
    RESULTADOS.append({**meta, **r})
    pct = r["pct_cumplimiento"]
    marca = {"Cumple": "✓", "No cumple": "✗"}.get(r["decision"], "·")
    if _mostrar or r["decision"] != "Cumple":
        print(f">>>> {meta['id']}: {meta['descripcion']}")
        print(f"     {marca} {r['decision']:<13} | cumplimiento: {'—' if pct is None else f'{pct:.2f} %'}"
              f" | {str(r['diagnostico'])[:160]}")
    return r


# ── Controles por ROLES (tipo de modelo): resuelven columna con BASES y ROLES ──
def resolver(base, roles):
    """(base real, columnas, error) de una base lógica y sus roles."""
    ds = BASES.get(base)
    if not ds:
        return None, None, f"falta enlazar la base «{NOMBRES_BASE.get(base, base)}» en BASES[{base!r}]"
    if ds not in datasets:
        return ds, None, f"la base {ds!r} (BASES[{base!r}]) no está cargada: añádela a RUTAS"
    cols, faltan = [], []
    for r in roles:
        c = (ROLES.get(ds) or {}).get(r)
        if c and c in datasets[ds].columns:
            cols.append(c)
        else:
            faltan.append(f"«{r}» ({DESC_ROLES.get(r, r)})" + (f": la columna {c!r} no existe" if c else ""))
    if faltan:
        return ds, None, f"sin enlazar en ROLES[{ds!r}]: " + "; ".join(faltan)
    return ds, cols, ""


def pendiente(meta, motivo, **params):
    """Registra un control que no se puede ejecutar todavía (No evaluable, con el motivo)."""
    meta = {**meta, "params": {k: v for k, v in params.items() if k != "referencia"},
            "umbral": params.get("umbral_pct", params.get("tolerancia_pct", 0.0))}
    r = {"evaluados": 0, "afectados": 0, "pct_incumplimiento": None, "pct_cumplimiento": None,
         "decision": "No evaluable", "diagnostico": f"Pendiente: {motivo}."}
    RESULTADOS[:] = [x for x in RESULTADOS if x["id"] != meta["id"]]
    RESULTADOS.append({**meta, **r})
    print(f">>>> {meta['id']}: {meta['descripcion']}")
    print(f"     · Pendiente     | {str(motivo)[:170]}")
    return r


def ejecutar_rol(meta, tipo, base, roles=(), opcionales=(), ref=None, **params):
    """Ejecuta un control del catálogo sobre las columnas que cumplen esos ROLES."""
    ds, cols, error = resolver(base, list(roles))
    if not error:
        for r in opcionales:
            c = (ROLES.get(ds) or {}).get(r)
            if c and c in datasets[ds].columns and c not in cols:
                cols.append(c)
        if len(set(cols)) != len(cols):
            error = "dos roles apuntan a la misma columna: revisa ROLES"
    if not error and ref:
        rbase, rrol, rclaves = ref.get("base"), ref.get("rol"), list(ref.get("claves") or [])
        rds, rcols, rerr = resolver(rbase, ([rrol] if rrol else []) + rclaves)
        if rerr:
            error = "base de referencia: " + rerr
        elif rds == ds:
            error = "la base de referencia es la misma base: el control no aplica"
        else:
            params["ref_dataset"] = rds
            if rrol:
                params["ref_columna"] = rcols[0]
            if rclaves:
                params["ref_claves"] = rcols[1:] if rrol else rcols
    if not error and params.pop("_escala_p75", False):
        # Proporción en 0–1 o en %: fija el máximo del rango (o lo que debe sumar el grupo).
        s = pd.to_numeric(datasets[ds][cols[0]], errors="coerce").dropna()
        params[{"suma_por_grupo": "valor_esperado", "relacion_aritmetica": "valor"}.get(tipo, "maximo")] = \
            1.0 if (len(s) == 0 or float(s.quantile(0.75)) <= 1) else 100.0
    params.pop("_escala_p75", None)
    meta = {**meta, "dataset": ds or f"({base})", "columnas": cols or list(roles)}
    if error:
        return pendiente(meta, error, **params)
    return ejecutar(meta, FUNCIONES[tipo], **params)
'''.strip()


_CODIGO_ROLES = r'''
import re as _re_roles
import unicodedata as _ud_roles


def _norm_col(nombre):
    s = "".join(c for c in _ud_roles.normalize("NFKD", str(nombre)) if not _ud_roles.combining(c)).lower()
    return _re_roles.sub(r"[^a-z0-9]+", "_", s).strip("_")


ROLES_TABLA = []
for _base, _roles in ROLES_DE_BASE.items():
    _ds = BASES.get(_base)
    _df = datasets.get(_ds) if _ds else None
    for _rol in _roles:
        _col = (ROLES.get(_ds) or {}).get(_rol) if _ds else None
        _ok = _df is not None and _col in _df.columns
        _sug = []
        if _df is not None and not _ok:
            _rx = _re_roles.compile(PATRON_ROL.get(_rol, "^$"))
            _sug = [c for c in _df.columns if _rx.search(_norm_col(c))]
            if _sug and ENLAZAR_SUGERENCIAS:
                ROLES.setdefault(_ds, {})[_rol] = _sug[0]
                _col, _ok = _sug[0], True
        ROLES_TABLA.append({"Base lógica": _base, "Qué es": NOMBRES_BASE.get(_base, _base), "Base real": _ds or "—",
                            "Rol": _rol, "Concepto": DESC_ROLES.get(_rol, _rol), "Columna": _col or "—",
                            "Estado": ("enlazado" if _ok else "SIN ENLAZAR") if _ds else "falta la base",
                            "Sugerencias": ", ".join(map(str, _sug[:4]))})
_sin = [r for r in ROLES_TABLA if r["Estado"] != "enlazado"]
print(f"Bases y roles del tipo de modelo ({', '.join(TIPOS_MODELO) or '—'}): "
      f"{len(ROLES_TABLA) - len(_sin)} de {len(ROLES_TABLA)} roles enlazados.")
for r in _sin[:60]:
    print(f"  ⚠ {r['Base lógica']}.{r['Rol']} ({r['Concepto']}): {r['Estado']}"
          + (f" — sugerencias: {r['Sugerencias']}" if r["Sugerencias"] else ""))
if _sin:
    print("Edita BASES y ROLES en la sección 0 (o pon ENLAZAR_SUGERENCIAS = True y revisa) y vuelve a ejecutar.")
'''.strip()


_CODIGO_BATERIA_DINAMICA = r'''
_RE_FECHA_NB = _re_lib.compile(r"(fecha|date|periodo|corte|fec_)")
_RE_FUTURA_OK = _re_lib.compile(r"(venc|vto|fin|expir|maturity|proyec|proxim|futur|caduc|hasta|limite)")
BATERIA_DINAMICA = []
for _nombre, _df in datasets.items():
    _esperado = (PERFIL.get(_nombre) or {}).get("columnas") or {}
    _nuevas = [c for c in _df.columns if c not in _esperado]
    if not _nuevas:
        continue
    if not _esperado:
        BATERIA_DINAMICA += [("volumen_minimo", _nombre, [], {"min_filas": 1}, f"La base «{_nombre}» no está vacía."),
                             ("unicidad", _nombre, [], {"umbral_pct": 0.0},
                              f"La base «{_nombre}» no tiene filas duplicadas.")]
    for _c in _nuevas:
        _s, _fam = _df[_c], _familia(_df[_c].dtype)
        if _fam == "texto" and _RE_FECHA_NB.search(str(_c).lower()):
            _muestra = _s.dropna().head(300)
            if len(_muestra) and _fechas(_muestra).notna().mean() >= 0.9:
                _fam = "fecha"
        BATERIA_DINAMICA.append(("completitud", _nombre, [_c], {"umbral_pct": 0.0}, f"{_c} no tiene valores nulos."))
        BATERIA_DINAMICA.append(("valores_centinela", _nombre, [_c], {"umbral_pct": 0.0},
                                 f"{_c} no usa valores que disfrazan un nulo."))
        if _fam == "num":
            BATERIA_DINAMICA += [("outliers_iqr", _nombre, [_c], {"k": 3.0, "umbral_pct": 1.0},
                                  f"{_c} sin valores atípicos extremos (más del 1 %)."),
                                 ("proporcion_ceros", _nombre, [_c], {"umbral_pct": 50.0},
                                  f"{_c} no es mayoritariamente cero."),
                                 ("constante", _nombre, [_c], {}, f"{_c} no es constante.")]
        elif _fam == "fecha":
            BATERIA_DINAMICA.append(("fecha_valida", _nombre, [_c], {"umbral_pct": 0.0}, f"{_c} contiene fechas legibles."))
            if not _RE_FUTURA_OK.search(str(_c).lower()):
                BATERIA_DINAMICA.append(("fecha_futura", _nombre, [_c], {"umbral_pct": 0.0},
                                         f"{_c} no tiene fechas futuras."))
        elif _fam == "texto":
            BATERIA_DINAMICA += [("espacios_extremos", _nombre, [_c], {"umbral_pct": 0.0}, f"{_c} sin espacios sobrantes."),
                                 ("caracteres_invalidos", _nombre, [_c], {"umbral_pct": 0.0},
                                  f"{_c} sin caracteres de control ni de mala codificación."),
                                 ("constante", _nombre, [_c], {}, f"{_c} no es constante.")]
            if _s.nunique(dropna=True) <= 200:
                BATERIA_DINAMICA.append(("categorias_equivalentes", _nombre, [_c], {"umbral_pct": 0.0},
                                         f"{_c} sin variantes de una misma categoría."))

# Llaves compartidas entre bases que no estaban en el perfil (id_cliente en clientes y en saldos):
# la del maestro no se repite y la del hijo no tiene huérfanos (integridad referencial).
_RE_LLAVE_NB = _re_lib.compile(r"(^id$|^id_|_id$|codigo|^cod_|cuenta|llave|^nro_|numero|contrato|operacion)")


def _nb_norm(x):
    return _re_lib.sub(r"[^a-z0-9]+", "_", _canon(x)).strip("_")


def _nb_singular(x):
    n = _nb_norm(x)
    for _suf in ("es", "s"):
        if n.endswith(_suf) and len(n) > len(_suf) + 2:
            return n[: -len(_suf)]
    return n


_nombres_ds = list(datasets)
for _ia, _a in enumerate(_nombres_ds):
    for _b in _nombres_ds[_ia + 1:]:
        _pa = (PERFIL.get(_a) or {}).get("columnas") or {}
        _pb = (PERFIL.get(_b) or {}).get("columnas") or {}
        for _k in [c for c in datasets[_a].columns if c in set(datasets[_b].columns) and _RE_LLAVE_NB.search(_nb_norm(c))]:
            if _k in _pa and _k in _pb:
                continue                                  # con perfil, ya lo propuso el agente
            _en_a, _en_b = _nb_singular(_a) in _nb_norm(_k), _nb_singular(_b) in _nb_norm(_k)
            if _en_a != _en_b:
                _padre, _hijo = (_a, _b) if _en_a else (_b, _a)
            else:
                _padre, _hijo = ((_a, _b) if datasets[_a][_k].nunique() >= datasets[_b][_k].nunique() else (_b, _a))
            BATERIA_DINAMICA.append(("unicidad", _padre, [_k], {"umbral_pct": 0.0},
                                     f"{_k} identifica cada fila de «{_padre}» (llave sin duplicados).", "ALTA"))
            BATERIA_DINAMICA.append(("integridad", _hijo, [_k], {"ref_dataset": _padre, "ref_columna": _k,
                                                                 "umbral_pct": 0.0},
                                     f"Todo {_k} de «{_hijo}» existe en «{_padre}» (sin huérfanos).", "ALTA"))

for _i, _fila in enumerate(BATERIA_DINAMICA, start=1):
    _tipo, _ds, _cols, _params, _desc = _fila[:5]
    _crit = _fila[5] if len(_fila) > 5 else "BAJA"
    _params = dict(_params)
    if _tipo in CON_REFERENCIA:
        _params.setdefault("referencia", FECHA_REFERENCIA)
    ejecutar({"id": f"BD{_i:03d}", "dataset": _ds, "tipo": _tipo, "columnas": list(_cols),
              "dimension": CATALOGO_TIPOS[_tipo], "descripcion": _desc,
              "justificacion": ("Batería dinámica: llave compartida entre bases (se descubrió al cargar)."
                                if _crit == "ALTA" else
                                "Batería dinámica: columna que no estaba en el perfil (se descubrió al cargar)."),
              "criticidad": _crit,
              "evidencia_requerida": "Si no cumple, sustentar el tratamiento aplicado por la primera línea.",
              "origen": "batería"}, FUNCIONES[_tipo], _mostrar=MOSTRAR_BATERIA_COMPLETA or _crit == "ALTA",
             **_params)
_bd = [r for r in RESULTADOS if str(r["id"]).startswith("BD")]
print(f"Batería dinámica: {len(_bd)} controles sobre columnas que no estaban en el perfil"
      + (f" · {sum(r['decision'] == 'No cumple' for r in _bd)} no cumplen." if _bd else
         " (todas las columnas estaban en el perfil)."))
'''.strip()


_CODIGO_BATERIA = r'''
for c in BATERIA:
    tipo = c["tipo"]
    params = dict(c.get("params") or {})
    if tipo in CON_REFERENCIA:
        params.setdefault("referencia", FECHA_REFERENCIA)
    meta = {"id": c["id"], "dataset": c["dataset"], "tipo": tipo, "columnas": list(c.get("columnas") or []),
            "dimension": CATALOGO_TIPOS[tipo], "descripcion": c["descripcion"],
            "justificacion": c.get("justificacion") or "Batería completa.",
            "criticidad": c.get("criticidad") or "BAJA",
            "evidencia_requerida": "Si no cumple, sustentar el tratamiento aplicado por la primera línea.",
            "origen": "batería"}
    ejecutar(meta, FUNCIONES[tipo], _mostrar=MOSTRAR_BATERIA_COMPLETA, **params)
_bat = [r for r in RESULTADOS if r["origen"] == "batería"]
print(f"\nBatería completa: {len(_bat)} controles · "
      f"{sum(r['decision'] == 'Cumple' for r in _bat)} cumplen · "
      f"{sum(r['decision'] == 'No cumple' for r in _bat)} no cumplen · "
      f"{sum(r['decision'] == 'No evaluable' for r in _bat)} no evaluables"
      + ("" if MOSTRAR_BATERIA_COMPLETA else " (arriba solo lo que no cumple)."))
'''.strip()


_CODIGO_ADICIONALES = r'''
for i, c in enumerate(CONTROLES_ADICIONALES, start=1):
    tipo, cid = str(c.get("tipo") or ""), f"X{i:02d}"
    if tipo not in FUNCIONES:
        print(f">>>> {cid}: el tipo {tipo!r} no está en el catálogo (revisa la tabla); no se ejecuta.")
        continue
    params = dict(c.get("params") or {})
    if tipo in CON_REFERENCIA:
        params.setdefault("referencia", FECHA_REFERENCIA)
    meta = {"id": cid, "dataset": c.get("dataset", ""), "tipo": tipo,
            "columnas": list(c.get("columnas") or []), "dimension": CATALOGO_TIPOS[tipo],
            "descripcion": c.get("descripcion") or f"{tipo} en {', '.join(c.get('columnas') or [])}",
            "justificacion": c.get("justificacion") or "Control añadido por el validador.",
            "criticidad": str(c.get("criticidad") or "MEDIA").upper(),
            "evidencia_requerida": c.get("evidencia") or ("Si no cumple, sustentar el tratamiento "
                                                          "aplicado por la primera línea."),
            "origen": "validador"}
    ejecutar(meta, FUNCIONES[tipo], **params)
if not CONTROLES_ADICIONALES:
    print("Sin controles adicionales (puedes añadirlos en la celda anterior).")
'''.strip()


_CODIGO_PROGRAMADOS_DEF = r'''
import inspect

MIS_CONTROLES = []


def mi_control(dataset, columnas=(), descripcion="", dimension="Validez", criticidad="MEDIA",
               params=None, evidencia=""):
    """Decorador: registra tu función (también una traída de otro notebook) en MIS_CONTROLES."""
    def registrar(funcion):
        MIS_CONTROLES.append({"funcion": funcion, "dataset": dataset, "columnas": list(columnas),
                              "descripcion": descripcion or funcion.__name__, "dimension": dimension,
                              "criticidad": criticidad, "params": dict(params or {}),
                              "evidencia": evidencia})
        return funcion
    return registrar
'''.strip()


_CODIGO_PROGRAMADOS = r'''
CODIGO_PERSONALIZADO = []
for i, c in enumerate(MIS_CONTROLES, start=1):
    f, cid = c.get("funcion"), f"P{i:02d}"
    if not callable(f):
        print(f">>>> {cid}: falta 'funcion' (el nombre de tu función, sin comillas).")
        continue
    params = dict(c.get("params") or {})
    meta = {"id": cid, "dataset": c.get("dataset", ""), "tipo": "personalizado:" + f.__name__,
            "columnas": list(c.get("columnas") or []), "dimension": c.get("dimension") or "Validez",
            "descripcion": c.get("descripcion") or f.__name__,
            "justificacion": c.get("justificacion") or "Control programado por el validador.",
            "criticidad": str(c.get("criticidad") or "MEDIA").upper(),
            "evidencia_requerida": c.get("evidencia") or ("Si no cumple, sustentar el tratamiento "
                                                          "aplicado por la primera línea."),
            "origen": "personalizado"}

    # Adaptador: acepta funciones con otra firma (p. ej. `def f(df)`) y lo que
    # devuelvan (serie booleana, DataFrame de filas que fallan, entero, bool…).
    def _envoltura(df, columnas, datasets=None, _f=f, **p):
        return a_resultado(llamar_flexible(_f, df, columnas, datasets, p), df,
                           p.get("umbral_pct", 0.0), _f.__name__)
    ejecutar(meta, _envoltura, **params)
    try:
        fuente = inspect.getsource(f)
    except (OSError, TypeError):
        fuente = "(código no disponible: define la función en una celda de este notebook)"
    CODIGO_PERSONALIZADO.append({
        "Control": cid, "Función": f.__name__, "Descripción": meta["descripcion"],
        "Dimensión": meta["dimension"], "Dataset": meta["dataset"],
        "Columnas": ", ".join(meta["columnas"]),
        "Parámetros": json.dumps(params, ensure_ascii=False, default=str), "Código": fuente[:30000]})
if not MIS_CONTROLES:
    print("Sin controles programados (es opcional).")
'''.strip()


_CODIGO_RESUMEN = r'''
_PESO = {"ALTA": 3, "MEDIA": 2, "BAJA": 1}


def porcentaje_cumplimiento(filas):
    """(% simple, % ponderado por criticidad) sobre los controles EVALUADOS
    (los «No evaluable» no cuentan a favor ni en contra: van como limitación)."""
    ev = [r for r in filas if r["decision"] in ("Cumple", "No cumple")]
    if not ev:
        return None, None
    simple = 100.0 * sum(r["decision"] == "Cumple" for r in ev) / len(ev)
    peso = sum(_PESO.get(r["criticidad"], 2) for r in ev)
    pond = 100.0 * sum(_PESO.get(r["criticidad"], 2) for r in ev if r["decision"] == "Cumple") / peso
    return round(simple, 2), round(pond, 2)


def _fila_resumen(grupo, filas):
    simple, pond = porcentaje_cumplimiento(filas)
    datos = [r["pct_cumplimiento"] for r in filas if r.get("pct_cumplimiento") is not None]
    return {"Grupo": grupo, "Controles": len(filas),
            "Cumplen": sum(r["decision"] == "Cumple" for r in filas),
            "No cumplen": sum(r["decision"] == "No cumple" for r in filas),
            "No evaluables": sum(r["decision"] == "No evaluable" for r in filas),
            "% de cumplimiento": simple, "% ponderado por criticidad": pond,
            "Cumplimiento medio de los datos (%)": round(sum(datos) / len(datos), 2) if datos else None}


PCT_CUMPLIMIENTO, PCT_PONDERADO = porcentaje_cumplimiento(RESULTADOS)
RESUMEN = [_fila_resumen("GLOBAL", RESULTADOS)]
for _campo, _rotulo in (("dimension", "Dimensión"), ("dataset", "Base"), ("origen", "Origen"),
                        ("criticidad", "Criticidad"), ("tipo_modelo", "Tipo de modelo")):
    for _v in sorted({str(r.get(_campo) or "") for r in RESULTADOS}):
        if _campo == "tipo_modelo" and not _v:
            continue
        RESUMEN.append(_fila_resumen(f"{_rotulo}: {_v}", [r for r in RESULTADOS if str(r.get(_campo) or "") == _v]))

_n_ev = sum(r["decision"] in ("Cumple", "No cumple") for r in RESULTADOS)
_n_ok = sum(r["decision"] == "Cumple" for r in RESULTADOS)
print("═" * 78)
print(f"  PORCENTAJE DE CUMPLIMIENTO: {'—' if PCT_CUMPLIMIENTO is None else f'{PCT_CUMPLIMIENTO:.2f} %'}"
      f"   ({_n_ok} de {_n_ev} controles evaluados cumplen)")
print(f"  Ponderado por criticidad (ALTA 3 · MEDIA 2 · BAJA 1): "
      f"{'—' if PCT_PONDERADO is None else f'{PCT_PONDERADO:.2f} %'}")
print("═" * 78)
try:
    display(pd.DataFrame(RESUMEN))
except NameError:
    print(pd.DataFrame(RESUMEN).to_string(index=False))

# Cobertura del catálogo: qué tipo corrió y cuál falta parametrizar (sección 5).
COBERTURA = []
for _tipo, _dim in CATALOGO_TIPOS.items():
    _rs = [r for r in RESULTADOS if r["tipo"] == _tipo]
    COBERTURA.append({"Tipo": _tipo, "Dimensión": _dim, "Controles": len(_rs),
                      "Cumplen": sum(r["decision"] == "Cumple" for r in _rs),
                      "No cumplen": sum(r["decision"] == "No cumple" for r in _rs),
                      "Estado": "ejecutado" if _rs else "falta parametrizar: tienes la plantilla en la sección 5",
                      "Plantilla": PLANTILLAS.get(_tipo, "")})
_faltan = [c["Tipo"] for c in COBERTURA if not c["Controles"]]
print(f"\nCobertura del catálogo: {len(CATALOGO_TIPOS) - len(_faltan)} de {len(CATALOGO_TIPOS)} tipos ejecutados."
      + (f" Faltan parámetros del negocio para: {', '.join(_faltan)} (plantillas en la sección 5)." if _faltan else ""))

tabla_res = pd.DataFrame([{k: v for k, v in r.items() if not k.startswith("_")} for r in RESULTADOS])
if not tabla_res.empty:
    criticos = tabla_res[(tabla_res["decision"] == "No cumple") & (tabla_res["criticidad"] == "ALTA")]
    if len(criticos):
        print("\nNo cumplen y son de criticidad ALTA (priorízalos):")
        for _, r in criticos.iterrows():
            print(f"  ✗ {r['id']}: {r['descripcion']} — {str(r['diagnostico'])[:140]}")
    sin_evaluar = tabla_res[tabla_res["decision"] == "No evaluable"]
    if len(sin_evaluar):
        print("\nNo se pudieron evaluar (revisa columnas y parámetros):")
        for _, r in sin_evaluar.iterrows():
            print(f"  · {r['id']}: {str(r['diagnostico'])[:140]}")
    if GRAFICO:
        try:
            from matplotlib.figure import Figure
            g = tabla_res[tabla_res["decision"] != "Cumple"].dropna(subset=["pct_incumplimiento"])
            g = g.sort_values("pct_incumplimiento").tail(40)
            if len(g):
                fig = Figure(figsize=(8, max(2.5, 0.32 * len(g))))
                ax = fig.subplots()
                ax.barh(g["id"].astype(str), g["pct_incumplimiento"], color="#C0483B")
                ax.set_xlabel("% de incumplimiento")
                ax.set_title(f"Controles que no cumplen · cumplimiento global "
                             f"{'—' if PCT_CUMPLIMIENTO is None else f'{PCT_CUMPLIMIENTO:.1f} %'}")
                GRAFICO_PNG = SALIDA.with_name(SALIDA.stem + "_resumen.png")
                fig.savefig(GRAFICO_PNG, dpi=120, bbox_inches="tight")
                try:
                    from IPython.display import Image as _Imagen
                    display(_Imagen(filename=str(GRAFICO_PNG)))
                except (ImportError, NameError):
                    print("Gráfico guardado en", GRAFICO_PNG)
        except ImportError:
            print("Para el gráfico instala matplotlib (pip install matplotlib).")
'''.strip()


_CODIGO_EXCEL = r'''
def _resultado(d):
    return {"Cumple": "OK", "No cumple": "FALLA"}.get(d, "No evaluable")


filas = []
for r in RESULTADOS:
    filas.append({
        "Descripción": r["descripcion"],
        "% de incumplimiento": r["pct_incumplimiento"],
        "Resultado": _resultado(r["decision"]),
        "Umbral": r["umbral"],
        "Detalle observación": r["diagnostico"],
        "Control": r["id"],
        "Dimensión": r["dimension"],
        "Control Esperado": r["descripcion"],
        "% De cumplimiento del data set": r["pct_cumplimiento"],
        "Diagnóstico": r["diagnostico"],
        "Decisión": r["decision"],
        "Control o Evidencia requerida": r["evidencia_requerida"],
        "Referencia en el entregable": f"{r['dataset']}.{'/'.join(r['columnas']) or '*'}",
        "Dataset": r["dataset"],
        "Columnas": ", ".join(r["columnas"]),
        "Tipo": r["tipo"],
        "N evaluados": r["evaluados"],
        "N afectados": r["afectados"],
        "Criticidad": r["criticidad"],
        "Justificación del control": r["justificacion"],
        "Origen": r.get("origen", ""),
        "Definición": json.dumps({"tipo": r["tipo"], "columnas": r["columnas"],
                                  "params": r.get("params", {})}, ensure_ascii=False, default=str),
        "Tipo de modelo": r.get("tipo_modelo") or "",
    })
tabla = pd.DataFrame(filas, columns=COLUMNAS)
try:
    display(tabla[["Control", "Dimensión", "Control Esperado",
                   "% De cumplimiento del data set", "Decisión", "Diagnóstico"]])
except NameError:
    print(tabla[["Control", "Decisión", "% De cumplimiento del data set"]].to_string(index=False))

n = {d: int((tabla["Decisión"] == d).sum()) for d in ("Cumple", "No cumple", "No evaluable")}
METADATOS = [
    ("Notebook", f"Controles de calidad de datos · generado el {GENERADO}"),
    ("Propuesta", PROPUESTA_ID), ("Modelo", MODELO), ("Código del modelo", CODIGO_MODELO),
    ("Dominio", DOMINIO), ("Tipos de modelo", ", ".join(TIPOS_MODELO) or "—"),
    ("Roles enlazados", f"{sum(r['Estado'] == 'enlazado' for r in ROLES_TABLA)} de {len(ROLES_TABLA)}"),
    ("Ejecutado el", datetime.now().isoformat(timespec="seconds")),
    ("Modo demo", "SÍ: datos sintéticos, no usar en la validación" if MODO_DEMO else "no"),
    ("Python", platform.python_version()), ("pandas", pd.__version__), ("numpy", np.__version__),
    ("Controles ejecutados", len(tabla)), ("Cumplen", n["Cumple"]),
    ("No cumplen", n["No cumple"]), ("No evaluables", n["No evaluable"]),
    ("Porcentaje de cumplimiento", PCT_CUMPLIMIENTO),
    ("Cumplimiento ponderado por criticidad", PCT_PONDERADO),
    ("Tipos del catálogo ejecutados", f"{len(CATALOGO_TIPOS) - len(_faltan)} de {len(CATALOGO_TIPOS)}"),
    ("Diferencias contra el perfil", len(DIFERENCIAS)),
] + [(f"Base {k}", f"{v.shape[0]:,} filas x {v.shape[1]} columnas · sha256 {HUELLAS.get(k, '—')}")
     for k, v in datasets.items()]
hojas = {
    "Controles": tabla,
    "Resumen": pd.DataFrame(RESUMEN),
    "Cobertura": pd.DataFrame(COBERTURA),
    "Roles": pd.DataFrame(ROLES_TABLA, columns=["Base lógica", "Qué es", "Base real", "Rol", "Concepto",
                                                "Columna", "Estado", "Sugerencias"]),
    "Perfil_vs_datos": pd.DataFrame(PERFIL_VS_DATOS, columns=["Base", "Columna", "Perfil", "Datos", "Aviso", "Nota"]),
    "Controles_personalizados": pd.DataFrame(CODIGO_PERSONALIZADO, columns=COLUMNAS_PERSONALIZADOS),
    "Metadatos": pd.DataFrame(METADATOS, columns=["Campo", "Valor"]),
}
# Validación completa: las tablas que registró la etapa (mapeo, contraste con la
# primera línea, análisis del experto…) van detrás, con un índice.
if _RESULTADOS_ETAPA:
    for _k, (_df_k, _nota) in _RESULTADOS_ETAPA.items():
        hojas[_k] = _df_k
    hojas["Indice"] = pd.DataFrame([{"hoja": k, "filas": len(v), "columnas": v.shape[1],
                                     "nota": (_RESULTADOS_ETAPA.get(k) or (None, ""))[1]} for k, v in hojas.items()])
try:
    with pd.ExcelWriter(SALIDA) as w:
        for nombre_hoja, hoja in hojas.items():
            hoja.astype(object).to_excel(w, index=False, sheet_name=nombre_hoja)
    print("\nGuardado:", SALIDA.resolve())
except ImportError:
    print("\nFalta openpyxl (pip install openpyxl): se guarda solo el CSV.")
tabla.to_csv(SALIDA.with_suffix(".csv"), index=False, encoding="utf-8-sig")
print(DEVOLVER_A)

if GUARDAR_EVIDENCIA_LOCAL and EVIDENCIAS:
    try:
        with pd.ExcelWriter(EVIDENCIA_LOCAL) as w:
            for cid, muestra in EVIDENCIAS.items():
                try:
                    muestra.astype(object).to_excel(w, sheet_name=str(cid)[:31])
                except Exception as e:
                    pd.DataFrame({"aviso": [f"no se pudo guardar la muestra: {e}"]}).to_excel(
                        w, sheet_name=str(cid)[:31], index=False)
        print("Evidencia LOCAL (filas que fallan; NO la subas a VIRF):", EVIDENCIA_LOCAL.resolve())
    except ImportError:
        print("La evidencia local necesita openpyxl.")
'''.strip()


def _fuente_repositorio(c: dict) -> str:
    """Código del control del repositorio (lectura en el servidor; se embebe, no se ejecuta)."""
    from modulos.repositorio_controles import RAIZ_REPO
    ruta = (RAIZ_REPO / str(c.get("carpeta") or "") / Path(str(c.get("archivo") or "")).name).resolve()
    ruta.relative_to(RAIZ_REPO.resolve())                 # nada fuera del repositorio
    return ruta.read_text(encoding="utf-8")


def _celda_repositorio(c: dict, fuente: str) -> str:
    """Celda que embebe el control del repositorio en su propia función (sus
    nombres no chocan con los de otros controles) y lo ejecuta."""
    import textwrap
    cid = c["id"]
    meta_c = _literal_seguro({**{k: c.get(k, "") for k in (
        "id", "dataset", "tipo", "columnas", "dimension", "descripcion", "justificacion",
        "criticidad", "evidencia_requerida", "origen")}, "umbral": None})
    cuerpo = textwrap.indent(fuente.strip("\n"), "    ")
    return (f"# ── {cid} · {c['tipo'][len('dominio:'):]} (repositorio {c.get('carpeta')}/{c.get('archivo')}) ──\n"
            f"def _cargar_{cid}():\n{cuerpo}\n    return META, control\n\n\n"
            f"META_{cid}, control_{cid} = _cargar_{cid}()\n"
            f"# Columnas enlazadas a tu perfil: edítalas si en tu base se llaman distinto.\n"
            f"PARAMS_{cid} = {_literal_seguro(c.get('params') or {})!r}\n"
            f"ejecutar({meta_c!r}, lambda df, columnas, datasets=None, **_: "
            f"desde_repositorio(control_{cid}(df, datasets, PARAMS_{cid})))")


def _bloque_bases_roles(tipos: list[str], enlace: dict) -> str:
    """Código de la sección 0 con TIPOS_MODELO, BASES y ROLES comentados (editables)."""
    from modulos import tipos_modelo as tm
    lineas = [f"TIPOS_MODELO = {tipos!r}"]
    if not tipos:
        lineas += ["BASES = {}", "ROLES = {}", "ENLAZAR_SUGERENCIAS = False"]
        return "\n".join(lineas)
    bases_lista, vistos = [], set()
    for t in tipos:
        for b in tm.TIPOS[t]["bases"]:
            if b["id"] not in vistos:
                vistos.add(b["id"])
                bases_lista.append(b)
    lineas.append("# Base lógica del tipo de modelo → nombre de la base en RUTAS (None = no la tienes o no se enlazó).")
    lineas.append("BASES = {")
    for b in bases_lista:
        ds = (enlace.get("bases") or {}).get(b["id"])
        com = f"{b['nombre']} · {b.get('granularidad', '')}"
        lineas.append(f"    {b['id']!r}: {ds!r},  # {'' if ds else '⚠ '}{com}")
    lineas.append("}")
    # Roles por base real: los de todas las bases lógicas que cayeron en ella.
    por_ds: dict[str, list[str]] = {}
    for b in bases_lista:
        ds = (enlace.get("bases") or {}).get(b["id"])
        if ds:
            lst = por_ds.setdefault(ds, [])
            lst += [r for r in b["roles"] if r not in lst]
    lineas.append("# Por base real: rol → columna. Corrige lo que no esté bien enlazado (None = sin enlazar).")
    lineas.append("ROLES = {")
    for ds, roles in por_ds.items():
        enl = (enlace.get("roles") or {}).get(ds, {})
        lineas.append(f"    {ds!r}: {{")
        for r in roles:
            col = enl.get(r)
            lineas.append(f"        {r!r}: {col!r},  # {'' if col else '⚠ '}{tm.descripcion_rol(r)}")
        lineas.append("    },")
    lineas.append("}")
    faltan = [b for b in bases_lista if not (enlace.get("bases") or {}).get(b["id"])]
    if faltan:
        lineas.append("# Bases sin enlazar: cuando las tengas, ponlas en RUTAS y en BASES y copia su bloque en ROLES:")
        for b in faltan:
            lineas.append(f"#   'NOMBRE_EN_RUTAS': {{{', '.join(repr(r) + ': None' for r in b['roles'])}}},   ← {b['id']}")
    lineas.append("ENLAZAR_SUGERENCIAS = False   # True = usa la 1.ª columna sugerida para cada rol sin enlazar (revísalo)")
    return "\n".join(lineas)


_CODIGO_ETAPA_AYUDAS = r'''
# ── Validación completa: tablas de la etapa que van al Excel (además de los controles) ──
_RESULTADOS_ETAPA = {}
_RESERVADAS = {"Controles", "Resumen", "Cobertura", "Roles", "Perfil_vs_datos", "Controles_personalizados",
               "Metadatos", "Indice"}


def registrar(nombre, tabla, nota=""):
    """Guarda una tabla para el Excel de salida: una hoja por tabla registrada."""
    df = tabla if isinstance(tabla, pd.DataFrame) else pd.DataFrame(tabla)
    nombre = str(nombre)[:31]
    if nombre in _RESERVADAS:
        nombre = ("X_" + nombre)[:31]
    _RESULTADOS_ETAPA[nombre] = (df, nota)
    return df


def perfil(df):
    """Perfil por columna: tipo, nulos, únicos, rango y estadísticos (lo que lee la etapa 01)."""
    filas = []
    for c in df.columns:
        s = df[c]
        num = pd.api.types.is_numeric_dtype(s) and not pd.api.types.is_bool_dtype(s)
        fecha = pd.api.types.is_datetime64_any_dtype(s)
        vc = s.value_counts(dropna=True)
        filas.append({"columna": c, "tipo": str(s.dtype), "n": int(s.notna().sum()), "nulos": int(s.isna().sum()),
                      "pct_nulos": round(100 * s.isna().mean(), 4) if len(s) else 0.0,
                      "unicos": int(s.nunique(dropna=True)),
                      "min": s.min() if (num or fecha) and s.notna().any() else None,
                      "max": s.max() if (num or fecha) and s.notna().any() else None,
                      "media": float(s.mean()) if num and s.notna().any() else None,
                      "desv": float(s.std()) if num and s.notna().sum() > 1 else None,
                      "p25": float(s.quantile(0.25)) if num and s.notna().any() else None,
                      "p50": float(s.quantile(0.50)) if num and s.notna().any() else None,
                      "p75": float(s.quantile(0.75)) if num and s.notna().any() else None,
                      "top": None if num or vc.empty else str(vc.index[0])[:80],
                      "freq": None if num or vc.empty else int(vc.iloc[0])})
    return pd.DataFrame(filas)
'''.strip()

_CODIGO_ETAPA_MAPEO = r'''
# Paso 01.1 · Retomar el mapeo de la etapa 00: una fila por base y el perfil de cada una.
_mapeo = []
for _n, _d in datasets.items():
    _mapeo.append({"base": _n, "ruta": str(RUTAS.get(_n, "")), "filas": len(_d), "columnas": _d.shape[1],
                   "duplicados": int(_d.duplicated().sum()),
                   "pct_nulos_medio": round(100 * float(_d.isna().mean().mean()), 4) if _d.shape[1] else 0.0})
    registrar(f"perfil_{_n}"[:31], perfil(_d), "Perfil por columna (base de la etapa 01)")
registrar("Mapeo", _mapeo, "Una fila por base de RUTAS (retoma el 00_Diagnostico)")
pd.DataFrame(_mapeo)
'''.strip()

_CODIGO_ETAPA_CIERRE = r'''
# Paso 01.5 · Contraste con la primera línea: lo que ella controló y con qué resultado,
# frente a lo que da este notebook (pon en «control_VIRF» el id equivalente: C03, M07, D02…).
CONTROLES_1L = [
    # {"control_1L": "Unicidad del número de cuenta", "base": "saldos", "umbral_1L": 0,
    #  "resultado_1L": "Cumple", "control_VIRF": "C03", "fuente": "Manual de controles §4.2"},
]
# Paso 01.6 · Tratamientos que aplica la primera línea (exclusiones, imputaciones, ajustes) y su sustento.
TRATAMIENTOS = [
    # {"base": "saldos", "tratamiento": "Excluye saldos negativos", "filas": 12, "sustento": "Manual §2.3",
    #  "aprobado_por": "Jefatura de modelos"},
]


def _a_decision(v):
    t = str(v or "").strip().lower()
    return "No cumple" if t.startswith(("no", "falla", "incumple")) else ("Cumple" if t.startswith(("cumple", "ok", "sí", "si"))
                                                                         else "")


_por_id = {r["id"]: r for r in RESULTADOS}
_contraste = []
for _c in CONTROLES_1L:
    _v = _por_id.get(str(_c.get("control_VIRF") or ""))
    _d1, _dv = _a_decision(_c.get("resultado_1L")), (_v or {}).get("decision", "")
    _contraste.append({**_c, "resultado_VIRF": _dv or "—",
                       "diagnostico_VIRF": (_v or {}).get("diagnostico", ""),
                       "coinciden": ("—" if not (_d1 and _dv in ("Cumple", "No cumple")) else ("sí" if _d1 == _dv else "NO"))})
registrar("Contraste_1L", _contraste or [{"aviso": "Completa CONTROLES_1L con los controles que declara la primera línea."}],
          "Paso 01.5")
registrar("Tratamientos", TRATAMIENTOS or [{"aviso": "Declara los tratamientos de la primera línea en TRATAMIENTOS."}],
          "Paso 01.6")

# Paso 01.7 · Fallas que se le escaparon a la primera línea (lo que no cumple, de lo más grave a lo menos).
_PESO_F = {"ALTA": 3, "MEDIA": 2, "BAJA": 1}


def _severidad(r):
    inc = r.get("pct_incumplimiento") or 0.0
    if r["criticidad"] == "ALTA":
        return "Crítico" if inc >= 10 else "Moderado"
    if r["criticidad"] == "BAJA":
        return "Potencial/Bajo"
    return "Moderado" if inc >= 10 else "Potencial/Bajo"


_l1 = {str(c.get("control_VIRF")): c for c in CONTROLES_1L}
_fallas = sorted([r for r in RESULTADOS if r["decision"] == "No cumple"],
                 key=lambda r: (-_PESO_F.get(r["criticidad"], 2), -(r.get("pct_incumplimiento") or 0)))
registrar("Fallas", [{"elemento": f"{r['dataset']}.{'/'.join(map(str, r['columnas'])) or '*'}",
                      "control": r["descripcion"],
                      "primera_linea": (f"{_l1[r['id']].get('control_1L')}: {_l1[r['id']].get('resultado_1L')}"
                                        if r["id"] in _l1 else "sin control declarado"),
                      "falla": r["diagnostico"], "evidencia": f"Controles!{r['id']}",
                      "severidad": _severidad(r), "id": r["id"], "criticidad": r["criticidad"],
                      "pct_incumplimiento": r.get("pct_incumplimiento"), "n_afectados": r.get("afectados"),
                      "origen": r.get("origen", ""), "tipo_modelo": r.get("tipo_modelo") or ""}
                     for r in _fallas] or [{"aviso": "Ningún control evaluado incumple."}], "Paso 01.7")
print(f"Paso 01.7: {len(_fallas)} falla(s); {sum(_severidad(r) == 'Crítico' for r in _fallas)} crítica(s).")
'''.strip()


def construir_notebook(controles: list[dict], perfiles: list[dict],
                       meta: dict[str, Any]) -> tuple[bytes, dict[str, Any]]:
    """
    Notebook ejecutable en local (pandas + numpy). Devuelve (bytes, info).
    `meta`: titulo, dominio, codigo_modelo, comentario, propuesta_id y, si se
    eligieron, tipos_modelo + enlace + plantillas_negocio + omitidos_negocio
    (de `proponer`). Con `etapa` (validación completa, chat 01) el notebook es
    el mismo, con las rutas reales, el Excel de la iteración, los pasos de la
    ruta de la etapa y las celdas del experto.

    Secciones: cómo prenderlo · entender el modelo (negocio) · 0 configuración
    (rutas, BASES y ROLES) · 1 entorno · 2 librería y perfil · 3 carga,
    comprobación contra el perfil y enlace de roles · 4 controles propuestos ·
    4a controles del tipo de modelo · 4b batería completa · 4c repositorio ·
    4d batería dinámica · 4e experto (etapa) · 5 plantillas · 6 programados ·
    7 resumen y % de cumplimiento · 8 Excel · 9 devolverlo.
    """
    import nbformat as nbf
    from modulos import tipos_modelo as tm
    nb = nbf.v4.new_notebook()
    celdas = []
    titulo = meta.get("titulo") or "modelo"
    generado = f"{datetime.now():%Y-%m-%d %H:%M}"
    tipos = [t for t in (meta.get("tipos_modelo") or []) if t in tm.TIPOS]
    enlace = meta.get("enlace") or (tm.enlazar(perfiles, tipos) if tipos else {})
    etapa = meta.get("etapa") or None
    negocio = [c for c in controles if c.get("base") and c.get("origen") == "tipo de modelo"]
    propuestos = [c for c in controles if c.get("origen") not in ("batería", "dominio") and not c.get("base")]
    bateria = [c for c in controles if c.get("origen") == "batería"]
    repo = [c for c in controles if c.get("origen") == "dominio"]
    por_origen: dict[str, int] = {}
    for c in controles:
        por_origen[c.get("origen") or "sin origen"] = por_origen.get(c.get("origen") or "sin origen", 0) + 1
    origenes = " · ".join(f"{k}: {v}" for k, v in sorted(por_origen.items()))
    carpeta = _carpeta(meta.get("dominio") or "")
    nombres_tipos = ", ".join(tm.TIPOS[t]["nombre"] for t in tipos) or "— (elígelo en la ficha del modelo)"
    tabla_meta = ("| | |\n|---|---|\n"
                  f"| Modelo | {_celda_md(titulo)} |\n"
                  f"| Código del modelo | {_celda_md(meta.get('codigo_modelo') or '—')} |\n"
                  f"| Dominio | {_celda_md(meta.get('dominio') or '—')}"
                  + (f" → controles `{carpeta}`" if carpeta else "") + " |\n"
                  f"| Tipo(s) de modelo | {_celda_md(nombres_tipos)} |\n"
                  f"| Controles | {len(controles)} ({origenes or '—'}) |\n"
                  f"| Propuesta | `{_celda_md(meta.get('propuesta_id') or '—')}` |\n"
                  f"| Generado | {generado} por el agente VIRF |\n\n")
    if etapa:
        base_nb = f"{etapa['fichero']}ITER{etapa['iteracion']}"
        celdas.append(_md(
            f"# {base_nb} — Validación completa · Control de datos\n\n"
            f"**Etapa 01 · Control de datos** — {_celda_md(etapa.get('mision'))}\n\n"
            + (f"**Qué cambia en esta iteración:** {_celda_md(etapa['cambios'])}\n\n" if etapa.get("cambios") else "")
            + tabla_meta
            + f"Al terminar genera **`{etapa['salida']}`**: súbelo al chat **{etapa['fichero']}** con tus "
              "comentarios y las capturas que sustenten la revisión. Las filas que fallan se quedan en tu equipo."))
    else:
        celdas.append(_md(
            f"# Controles de calidad de datos — {titulo}"
            + (f" ({meta['codigo_modelo']})" if meta.get("codigo_modelo") else "") + "\n\n" + tabla_meta
            + (f"> **Lectura del agente:** {_celda_md(meta['comentario'])}\n\n" if meta.get("comentario") else "")
            + "Este notebook **no llama a ninguna IA ni envía datos**: corre donde están tus bases y "
            "solo necesita `pandas` y `numpy`. A VIRF vuelve el **Excel de resultados** (cifras "
            "agregadas por control y el **porcentaje de cumplimiento**); las filas que fallan se quedan "
            "en tu equipo."))
    celdas.append(_md(GUIA_PRENDER_MD + (f"\n\n> En la validación completa el Excel se llama **`{etapa['salida']}`** "
                                         f"(no `resultado_controles_datos.xlsx`)." if etapa else "")))
    celdas.append(_md(_INDICE_MD))
    if etapa and etapa.get("ruta"):
        celdas.append(_md(
            "## Ruta de la etapa 01, paso a paso\n\n| Paso | Qué se hace | Dónde |\n|---|---|---|\n"
            + "\n".join(f"| **{p['paso']}** · {_celda_md(p['titulo'])} | {_celda_md(p['que'])} | "
                        f"{_celda_md(p.get('donde', ''))} |" for p in etapa["ruta"])))

    # ── Entender el modelo (negocio) ──
    if tipos:
        partes = ["## Entender el modelo: qué hace, qué datos usa y qué puede fallar\n",
                  "Antes de mirar cifras, entiende el negocio: cada control de la sección **4a** sale de aquí "
                  "y dice **por qué** importa para este tipo de modelo.\n"]
        for t in tipos:
            partes.append(tm.ficha_md(t, enlace))
        pr = tm.preguntas(tipos)
        if pr:
            partes.append("### Qué pedir a la primera línea\n\n" + "\n".join(f"{i}. {p}" for i, p in enumerate(pr, 1)))
        celdas.append(_md("\n".join(partes)))
    else:
        del_dom = [t for t, v in tm.TIPOS.items() if v["carpeta"] == carpeta]
        celdas.append(_md(
            "## Tipo de modelo\n\nNo se eligió el **tipo de modelo** en la ficha del modelo, así que el notebook "
            "trae los controles generales del dominio pero **no** los de negocio de un tipo concreto (qué hace "
            "el modelo, qué bases necesita, qué puede fallar, controles por roles). Elígelo en VIRF "
            "(**Configuración → Tipo de modelo**) y vuelve a generar el notebook."
            + ("\n\nTipos de este dominio: " + ", ".join(f"`{t}` ({tm.TIPOS[t]['nombre']})" for t in del_dom)
               if del_dom else "")))

    # ── 0 · Configuración ──
    if etapa and etapa.get("rutas"):
        rutas = dict(etapa["rutas"])
        for p in perfiles:
            rutas.setdefault(p["nombre"], f"RUTA/A/{p['nombre']}.csv")
    else:
        rutas = {p["nombre"]: f"RUTA/A/{p['nombre']}.csv" for p in perfiles}
    usadas = _columnas_usadas([c for c in controles if c.get("origen") != "dominio" and c.get("dataset")], perfiles)
    for c in repo + negocio:                              # columnas que piden repositorio y negocio
        if not c.get("dataset"):
            continue
        lst = usadas.setdefault(c["dataset"], [])
        for col in c.get("columnas") or []:
            if col not in lst:
                lst.append(col)
    salida = etapa["salida"] if etapa else "resultado_controles_datos.xlsx"
    celdas.append(_md("## 0 · Configuración — edita antes de ejecutar\n\n"
                      "Lo único obligatorio es `RUTAS`. Si elegiste el tipo de modelo, revisa también `BASES` y "
                      "`ROLES`: dicen qué columna cumple cada concepto de negocio (P&L, saldo, banda…)."))
    celdas.append(_code(
        "from pathlib import Path\n"
        "import pandas as pd\n\n"
        "# ── 1) Dónde están tus bases: nombre (el mismo del perfil) -> ruta al archivo ──\n"
        "# Formatos: .csv, .xlsx/.xls, .parquet, .sas7bdat, .pkl.\n"
        f"RUTAS = {json.dumps(rutas, ensure_ascii=False, indent=4)}\n\n"
        "# Columnas que usan los controles, por base (lo calculó el agente). Sirve para leer\n"
        "# solo lo necesario en bases grandes (ver OPCIONES_LECTURA y la carga en Databricks).\n"
        f"COLUMNAS_USADAS = {json.dumps(usadas, ensure_ascii=False)}\n\n"
        "# Opciones de lectura por base (opcional): separador, codificación, hoja, columnas…\n"
        "#   {'cartera': {'sep': ';', 'encoding': 'latin-1'}}   ·   Excel: {'cartera': {'sheet_name': 'Hoja1'}}\n"
        "#   Base grande: {'cartera': {'usecols': COLUMNAS_USADAS['cartera']}}  (en .parquet: 'columns')\n"
        "OPCIONES_LECTURA = {}\n\n"
        "# ── 2) Qué genera ──\n"
        f"SALIDA = Path({salida!r})   # lo que devuelves a VIRF\n"
        "GUARDAR_EVIDENCIA_LOCAL = True   # filas que fallan, en un Excel aparte que NO se sube\n"
        "MUESTRA_EVIDENCIA = 20           # filas por control en esa evidencia\n"
        "GRAFICO = True                   # gráfico resumen (necesita matplotlib)\n"
        "CALCULAR_HUELLA = True           # sha256 de cada archivo: prueba qué base se ejecutó\n"
        "MOSTRAR_BATERIA_COMPLETA = False # True = imprime también los controles de la batería que cumplen\n\n"
        "# ── 3) Parámetros generales ──\n"
        "FECHA_REFERENCIA = None          # frescura y fechas futuras: p. ej. '2026-10-31' (corte); None = hoy\n\n"
        "# ── 4) Prueba en vacío ──\n"
        "# True = datos SINTÉTICOS con la forma del perfil, para comprobar que el notebook\n"
        "# prende antes de tener los datos. Sus resultados NO sirven para la validación.\n"
        "MODO_DEMO = False\n\n"
        "# ── 5) Tipo de modelo: bases lógicas y roles (concepto de negocio → columna) ──\n"
        + _bloque_bases_roles(tipos, enlace) + "\n\n"
        "EVIDENCIA_LOCAL = SALIDA.with_name('evidencia_local_' + SALIDA.stem + '.xlsx')\n"
        + ("DEVOLVER_A = " + repr(f"Súbelo al chat {etapa['fichero']} de la validación completa (con tus "
                                  f"comentarios y capturas) para recibir el ITER{int(etapa['iteracion']) + 1}.")
           if etapa else "DEVOLVER_A = 'Devuelve este Excel a VIRF: Controles de datos → Diseñar con IA → "
                          "Revisar resultados.'")
        + "\n\n" + _CODIGO_ETAPA_AYUDAS))

    # ── 1 · Entorno ──
    celdas.append(_md("## 1 · Entorno\n\nComprueba versiones y paquetes opcionales. Si falta "
                      "alguno, el notebook sigue: solo se pierde lo que ese paquete aporta."))
    celdas.append(_code(
        "import importlib\nimport platform\nimport sys\n\nimport numpy as np\n\n"
        "print(f'Python {platform.python_version()} · pandas {pd.__version__} · numpy {np.__version__}')\n"
        "if sys.version_info < (3, 9):\n"
        "    print('⚠ Se recomienda Python 3.9 o superior.')\n"
        "OPCIONALES = {}\n"
        "for _mod, _para in (('openpyxl', 'guardar el Excel'), ('matplotlib', 'el gráfico'),\n"
        "                    ('pyarrow', 'leer .parquet')):\n"
        "    try:\n"
        "        importlib.import_module(_mod)\n"
        "        OPCIONALES[_mod] = True\n"
        "    except ImportError:\n"
        "        OPCIONALES[_mod] = False\n"
        "        print(f'· Falta {_mod} (para {_para}): pip install {_mod}')\n"
        "if all(OPCIONALES.values()):\n"
        "    print('✓ Todo listo.')"))

    # ── 2 · Librería y perfil ──
    celdas.append(_md("## 2 · Librería de controles y perfil (no editar)\n\n"
                      f"Las {len(CATALOGO)} funciones de control del catálogo, los **adaptadores** para "
                      "controles traídos de otros notebooks, los conceptos de negocio (roles) y lo que pegaste en "
                      "VIRF (`.info()` / `.describe()`), que sirve para comprobar que ejecutas la misma base y para "
                      "el modo demo.\n\n" + tabla_catalogo_md()))
    catalogo_tipos = {t: m["dimension"] for t, m in CATALOGO.items()}
    plantillas = plantillas_catalogo(perfiles)
    roles_usados: dict[str, list[str]] = {}
    nombres_base: dict[str, str] = {}
    for t in tipos:
        for b in tm.TIPOS[t]["bases"]:
            lst = roles_usados.setdefault(b["id"], [])
            lst += [r for r in b["roles"] if r not in lst]
            nombres_base.setdefault(b["id"], b["nombre"])
    todos_roles = sorted({r for rs in roles_usados.values() for r in rs})
    desc_roles = {r: tm.descripcion_rol(r) for r in todos_roles}
    patron_rol = {r: tm.ROLES[r]["patron"] for r in todos_roles}
    celdas.append(_code(
        _LIBRERIA + "\n\n\n" + _CODIGO_PERFIL + "\n\n\n"
        "# Catálogo (tipo -> dimensión), funciones por tipo y plantilla de cada tipo.\n"
        f"CATALOGO_TIPOS = {catalogo_tipos!r}\n"
        "FUNCIONES = {t: globals()[t] for t in CATALOGO_TIPOS}\n"
        f"CON_REFERENCIA = {_CON_REFERENCIA!r}\n"
        f"PLANTILLAS = {_literal_seguro({t: json.dumps(v, ensure_ascii=False) for t, v in plantillas.items()})!r}\n"
        f"COLUMNAS = {json.dumps(COLUMNAS_SALIDA, ensure_ascii=False)}\n"
        f"COLUMNAS_PERSONALIZADOS = {json.dumps(COLUMNAS_PERSONALIZADOS, ensure_ascii=False)}\n\n"
        "# Conceptos de negocio (roles) del tipo de modelo: qué es cada uno y cómo se reconoce.\n"
        f"NOMBRES_BASE = {nombres_base!r}\n"
        f"ROLES_DE_BASE = {roles_usados!r}\n"
        f"DESC_ROLES = {desc_roles!r}\n"
        f"PATRON_ROL = {patron_rol!r}\n\n"
        "# Datos de la propuesta (para los metadatos del Excel).\n"
        f"MODELO = {titulo!r}\n"
        f"CODIGO_MODELO = {str(meta.get('codigo_modelo') or '')!r}\n"
        f"DOMINIO = {str(meta.get('dominio') or '')!r}\n"
        f"PROPUESTA_ID = {str(meta.get('propuesta_id') or '')!r}\n"
        f"GENERADO = {generado!r}\n\n"
        "# Perfil que pegaste en VIRF (columnas, tipos, no nulos y estadísticos).\n"
        f"PERFIL = {_perfil_literal(perfiles)!r}"))

    # ── 3 · Carga ──
    celdas.append(_md("## 3 · Carga de las bases y comprobación contra el perfil\n\n"
                      "Compara lo que cargas con lo que perfilaste: filas, columnas que faltan o "
                      "sobran, tipos y nulos. Una diferencia no detiene nada, pero el agente la "
                      "verá en el Excel y la anotará como limitación."))
    celdas.append(_code(_CODIGO_CARGA))
    celdas.append(_md("### 3b · Bases y roles del tipo de modelo\n\n"
                      "Comprueba que cada concepto de negocio (P&L, saldo, banda, tasa de salida…) tiene su columna. "
                      "Lo que no esté enlazado sale como **Pendiente** en el Excel (no cuenta en el % de "
                      "cumplimiento, pero el revisor lo ve como limitación)."))
    celdas.append(_code(_CODIGO_ROLES))
    if etapa:
        celdas.append(_md("### Paso 01.1 · Retomar el mapeo de la etapa 00\n\n"
                          "Una fila por base de `RUTAS` y el perfil de cada columna (hojas `Mapeo` y `perfil_<base>`)."))
        celdas.append(_code(_CODIGO_ETAPA_MAPEO))

    # ── 4 · Controles propuestos (reglas, IA, aprendidos y tipo de modelo) ──
    celdas.append(_md(("### Paso 01.2 · Batería de calidad (BCBS 239)\n\n" if etapa else "") + _MD_PROPUESTOS))
    for c in propuestos:
        params = dict(c.get("params") or {})
        params.pop("referencia", None)
        meta_c = _literal_seguro({k: c.get(k, "") for k in (
            "id", "dataset", "tipo", "columnas", "dimension", "descripcion", "justificacion",
            "criticidad", "evidencia_requerida", "origen", "tipo_modelo")})
        celdas.append(_md(
            f"### {c['id']} · {c['dimension']} · {_celda_md(c['descripcion'])}\n\n"
            "| | |\n|---|---|\n"
            f"| Base · columnas | `{c['dataset']}` · "
            f"{', '.join(f'`{x}`' for x in c.get('columnas') or []) or 'todas'} |\n"
            f"| Tipo | `{c['tipo']}` — {_celda_md(CATALOGO[c['tipo']]['descripcion'])} |\n"
            f"| Por qué | {_celda_md(c.get('justificacion'))} |\n"
            f"| Umbral tolerado | {_umbral_txt(c['tipo'], params)} |\n"
            f"| Criticidad · origen | {c.get('criticidad', '')} · {c.get('origen', '')} |\n"
            f"| Si no cumple | {_celda_md(c.get('evidencia_requerida'))} |"))
        arg_ref = ", referencia=FECHA_REFERENCIA" if c["tipo"] in _CON_REFERENCIA else ""
        # repr (literal de Python), no JSON: un null/true de JSON compila pero
        # revienta al ejecutar.
        celdas.append(_code(
            f"ejecutar({meta_c!r}, {c['tipo']}"
            + "".join(f", {k}={_literal_seguro(v)!r}" for k, v in params.items()) + arg_ref + ")"))

    # ── 4a · Controles del tipo de modelo (negocio, por roles) ──
    omitidos = meta.get("omitidos_negocio") or []
    celdas.append(_md(
        ("### Pasos 01.3 y 01.4 · Controles del tipo de modelo, integridad y conciliaciones\n\n" if etapa else "")
        + "## 4a · Controles del tipo de modelo (negocio)\n\n"
        + (f"{len(negocio)} controles de las fichas de **{_celda_md(nombres_tipos)}**, expresados por **roles** "
           "(concepto de negocio) y resueltos con `BASES` y `ROLES` de la sección 0: si corriges un enlace ahí, "
           "todos los controles que lo usan cambian solos. Se numeran `M01`, `M02`… Los que no tienen su "
           "columna salen como **Pendiente**."
           if negocio else "Sin tipo de modelo elegido: no hay controles de negocio por roles.")
        + ("\n\n**No aplican aquí** (los dos datos vienen en la misma tabla):\n"
           + "\n".join(f"- {_celda_md(c['descripcion'])} — {_celda_md(c['no_aplica'])}" for c in omitidos)
           if omitidos else "")))
    for c in negocio:
        params = dict(c.get("params") or {})
        if c.get("escala_p75"):
            params.pop("maximo", None)
            params["_escala_p75"] = True
        meta_c = _literal_seguro({**{k: c.get(k, "") for k in (
            "id", "tipo", "dimension", "descripcion", "justificacion", "criticidad", "evidencia_requerida",
            "origen", "tipo_modelo", "base")}})
        enl = (" · ".join(f"{r} → `{c['dataset']}`.`{col}`" for r, col in zip(c["roles"], c["columnas"]))
               if not c.get("pendientes") else "⚠ pendiente: " + "; ".join(c["pendientes"]))
        celdas.append(_md(
            f"### {c['id']} · {c['dimension']} · {_celda_md(c['descripcion'])}\n\n"
            "| | |\n|---|---|\n"
            f"| Tipo de modelo | {_celda_md(tm.TIPOS[c['tipo_modelo']]['nombre'])} |\n"
            f"| Base lógica · roles | `{c['base']}` · {_celda_md(', '.join(c['roles'] + list(c.get('opcionales') or [])))}"
            f" — {_celda_md(enl)} |\n"
            f"| Tipo | `{c['tipo']}` — {_celda_md(CATALOGO[c['tipo']]['descripcion'])} |\n"
            f"| Por qué (negocio) | {_celda_md(c.get('justificacion'))} |\n"
            f"| Umbral tolerado | {_umbral_txt(c['tipo'], params)} |\n"
            f"| Criticidad | {c.get('criticidad', '')} |\n"
            f"| Si no cumple | {_celda_md(c.get('evidencia_requerida'))} |"))
        args = [f"base={c['base']!r}", f"roles={list(c['roles'])!r}"]
        if c.get("opcionales"):
            args.append(f"opcionales={list(c['opcionales'])!r}")
        if c.get("ref"):
            ref = {k: c["ref"].get(k) for k in ("base", "rol", "claves") if c["ref"].get(k)}
            args.append(f"ref={ref!r}")
        args += [f"{k}={_literal_seguro(v)!r}" for k, v in params.items()]
        if c["tipo"] in _CON_REFERENCIA:
            args.append("referencia=FECHA_REFERENCIA")
        celdas.append(_code(f"ejecutar_rol({meta_c!r}, {c['tipo']!r}, " + ", ".join(args) + ")"))

    # ── 4b · Batería completa ──
    celdas.append(_md(
        "## 4b · Batería completa (corre siempre)\n\n"
        f"{len(bateria)} controles sobre **todas** las columnas con los tipos del catálogo que no "
        "necesitan conocimiento del negocio: completitud, nulos disfrazados, atípicos, rango del perfil, "
        "ceros, constantes, fechas legibles y futuras, espacios, caracteres inválidos y categorías "
        "equivalentes. Umbrales prudentes y criticidad **BAJA**: ajústalos en la lista o comenta una "
        "línea para quitar un control. Se numeran `B001`, `B002`… y solo se imprime lo que **no** "
        "cumple (`MOSTRAR_BATERIA_COMPLETA = True` para verlo todo)."))
    filas_bat = []
    for c in bateria:
        d = _literal_seguro({"id": c["id"], "dataset": c["dataset"], "tipo": c["tipo"],
                             "columnas": c.get("columnas") or [], "params": c.get("params") or {},
                             "descripcion": c["descripcion"], "criticidad": c.get("criticidad", "BAJA"),
                             "justificacion": c.get("justificacion", "")})
        filas_bat.append(f"    {d!r},")
    celdas.append(_code("BATERIA = [\n" + "\n".join(filas_bat) + ("\n" if filas_bat else "") + "]"))
    celdas.append(_code(_CODIGO_BATERIA))

    # ── 4c · Repositorio del tipo de modelo ──
    celdas.append(_md(
        "## 4c · Controles del repositorio del tipo de modelo\n\n"
        + (f"Los análisis especializados de **{', '.join(sorted({c.get('carpeta', '') for c in repo})).upper()}** "
           "(`inputs/repositorio_controles/`), con sus columnas **enlazadas a tu perfil**"
           + (" y filtrados a los tipos de modelo elegidos" if tipos else "") + ". "
           "Si una columna no se pudo enlazar, la celda lo dice: edita su `PARAMS_Dxx`. Cada uno "
           "devuelve su decisión (Cumple · Observado · No cumple · No evaluable · Revisión manual); "
           "«Observado» cuenta como no cumple y «Revisión manual» como no evaluable."
           if repo else "El dominio de este modelo no tiene controles propios en el repositorio "
                        "(`inputs/repositorio_controles/`): la batería y las plantillas cubren el catálogo.")))
    n_repo_ok = 0
    for c in repo:
        try:
            fuente = _fuente_repositorio(c)
        except (OSError, ValueError):
            continue
        pend = c.get("pendientes") or []
        celdas.append(_md(
            f"### {c['id']} · {_celda_md(c['dimension'])} · {_celda_md(c['descripcion'])}\n\n"
            f"*Fuente:* `{c.get('carpeta')}/{c.get('archivo')}` · *Base:* `{c['dataset']}` · "
            f"*Columnas enlazadas:* {', '.join(f'`{x}`' for x in c.get('columnas') or []) or '—'}"
            + (f"\n\n> ⚠ Sin enlazar (no están en el perfil): {', '.join(f'`{x}`' for x in pend)}. "
               "Edítalos en `PARAMS_" + c["id"] + "`." if pend else "")))
        celda = _celda_repositorio(c, fuente)
        try:
            ast.parse(celda)
        except SyntaxError:
            continue                                      # se informa en avisos al no aparecer
        celdas.append(_code(celda))
        n_repo_ok += 1

    # ── 4d · Batería dinámica ──
    celdas.append(_md(
        "## 4d · Batería dinámica (columnas que no estaban en el perfil)\n\n"
        "Si una base trae columnas que no estaban en lo que se perfiló (o no hubo perfil), aquí se les aplica "
        "la batería básica al cargarlas (ids `BD001`…). Así ninguna columna queda sin revisar."))
    celdas.append(_code(_CODIGO_BATERIA_DINAMICA))

    # ── 4e · Celdas del experto (validación completa) ──
    if etapa and etapa.get("celdas"):
        celdas.append(_md(
            f"## 4e · Controles y análisis del experto (ITER{etapa['iteracion']})\n\n"
            "Celdas que escribió el agente para este modelo (conciliaciones, contraste con la primera línea, "
            "lo que el catálogo no cubre). Usan `ejecutar(...)` / `ejecutar_rol(...)` (entran en el % de "
            "cumplimiento) o `registrar(nombre, tabla)` (van como hoja del Excel)."))
        for c in etapa["celdas"]:
            celdas.append(_code(c["contenido"]) if c["tipo"] == "code" else _md(c["contenido"]))

    # ── 5 · Plantillas de todos los tipos que faltan (+ las de negocio) ──
    cubiertos = {c["tipo"] for c in controles}
    faltan = [t for t in CATALOGO if t not in cubiertos]
    plant_neg = meta.get("plantillas_negocio") or []
    celdas.append(_md(
        "## 5 · Tus controles sin programar (plantillas de TODOS los tipos que faltan)\n\n"
        "El notebook trae **siempre todos los tipos del catálogo**: los que no corrieron arriba "
        f"({len(faltan)} de {len(CATALOGO)}) necesitan un dato del negocio (lista de valores, patrón, "
        "base de referencia, total contable, par de columnas…). Aquí tienes una plantilla de cada uno "
        "con TUS columnas: descoméntala, pon el dato y ejecuta. Se numeran `X01`, `X02`… y viajan con "
        "origen **validador**; si al devolver el Excel eliges *Enseñar al agente*, se convierten en "
        "lecciones del dominio."
        + (f"\n\n**Del tipo de modelo** ({len(plant_neg)}): controles de negocio que necesitan un dato del manual "
           "(p. ej. las bandas temporales); vienen arriba de la lista con su porqué." if plant_neg else "")
        + "\n\n**Reglas:** `tipo` del catálogo (tabla de la sección 2); `columnas` con el nombre exacto; "
        "`umbral_pct` = % de incumplimiento tolerado (0 = ninguno)."))
    bloques_neg = []
    for c in plant_neg:
        d = {"dataset": c.get("dataset") or f"BASE_{c['base'].upper()}", "tipo": c["tipo"],
             "columnas": c["columnas"] if not c.get("pendientes") else [f"COLUMNA_{r.upper()}" for r in c["roles"]],
             "params": c.get("params") or {}, "descripcion": c["descripcion"], "criticidad": c.get("criticidad", "MEDIA")}
        bloques_neg.append(f"    # [{c['tipo_modelo']}] {c['justificacion'][:150]}\n" + _comentado(d) + ",")
    celdas.append(_code(
        "# Un diccionario por control:\n"
        "#   dataset      nombre de la base (una de RUTAS)\n"
        "#   tipo         uno de los tipos de la tabla de la sección 2\n"
        "#   columnas     lista de columnas (cuántas: ver la tabla)\n"
        "#   params       parámetros del tipo; umbral_pct = % de incumplimiento tolerado\n"
        "#   descripcion  qué se espera, en una frase (sale en el informe)\n"
        "#   criticidad   ALTA | MEDIA | BAJA     ·     evidencia: qué pedir si no cumple (opcional)\n"
        "# Plantillas de los tipos que faltan, con TUS columnas (descomenta, completa y ejecuta):\n"
        "CONTROLES_ADICIONALES = [\n"
        + ("\n".join(bloques_neg) + "\n" if bloques_neg else "")
        + ("\n".join(_comentado(plantillas[t]) + "," for t in faltan) + "\n" if faltan else "")
        + "]"))
    celdas.append(_code(_CODIGO_ADICIONALES))

    # ── 6 · Controles programados o traídos de otros notebooks ──
    nums = [c["nombre"] for p in perfiles[:1] for c in p["columnas"] if _es_numerico(c)][:2]
    ds0 = perfiles[0]["nombre"] if perfiles else "base"
    a, b = (nums + ["columna_a", "columna_b"])[:2]
    celdas.append(_md(
        "## 6 · Tus controles programados (o traídos de otros notebooks)\n\n"
        "Para una regla que el catálogo no cubre —o un control que ya resolviste en otro notebook— "
        "pega la función y regístrala con el decorador `@mi_control(...)`. **No hace falta "
        "reescribirla**: el notebook acepta que devuelva\n\n"
        "| Lo que devuelve tu función | Cómo se lee |\n|---|---|\n"
        "| `_res(...)` | tal cual |\n"
        "| Serie booleana (`True` = la fila falla) | filas que fallan sobre `len(df)` |\n"
        "| DataFrame con las filas que fallan | ídem |\n"
        "| `int` | cuántas filas fallan |\n"
        "| `(evaluados, afectados)` | tal cual |\n"
        "| `True` / `False` | cumple / no cumple |\n\n"
        "y que su firma sea solo `def f(df)` (o con `columnas`, `datasets` o tus parámetros: se le "
        "pasa solo lo que acepta). Se numeran `P01`, `P02`… y su **código viaja como texto** en la hoja "
        "*Controles_personalizados*. VIRF **no ejecuta** ese código: un desarrollador lo revisa y, si "
        "sirve para otros modelos, lo convierte en un tipo del catálogo (ver la guía "
        "*GUIA_NOTEBOOK_CALIDAD_DATOS.md*, «Traer tus controles de otros notebooks»)."))
    celdas.append(_code(_CODIGO_PROGRAMADOS_DEF))
    celdas.append(_code(
        "# ── Ejemplo 1: tu propia función con el contrato de VIRF (descomenta y adapta) ──\n"
        "# @mi_control(dataset=" + repr(ds0) + ", columnas=[" + repr(a) + ", " + repr(b) + "],\n"
        "#             descripcion='El saldo vivo no supera el monto desembolsado',\n"
        "#             dimension='Consistencia', criticidad='ALTA', params={'umbral_pct': 0.0})\n"
        "# def saldo_no_supera_desembolso(df, columnas, umbral_pct=0.0, **_):\n"
        "#     saldo = pd.to_numeric(df[columnas[0]], errors='coerce')\n"
        "#     desembolso = pd.to_numeric(df[columnas[1]], errors='coerce')\n"
        "#     return saldo > desembolso            # serie booleana: True = fila que falla\n"
        "#\n"
        "# ── Ejemplo 2: pegado tal cual de otro notebook (firma df y devuelve filas) ──\n"
        "# @mi_control(dataset=" + repr(ds0) + ", descripcion='Operaciones duplicadas por llave y fecha',\n"
        "#             dimension='Unicidad', criticidad='ALTA')\n"
        "# def duplicados_otro_notebook(df):\n"
        "#     return df[df.duplicated(subset=[" + repr(a) + "], keep=False)]   # DataFrame de filas que fallan\n"
        "#\n"
        "# ── Ejemplo 3: un módulo .py con tus controles, junto a este notebook ──\n"
        "# import mis_controles                     # define funciones y una lista CONTROLES de diccionarios\n"
        "# MIS_CONTROLES += mis_controles.CONTROLES # {'funcion': f, 'dataset': …, 'descripcion': …}"))
    celdas.append(_code(_CODIGO_PROGRAMADOS))

    if etapa:
        celdas.append(_md("### Pasos 01.5, 01.6 y 01.7 · Contraste con la primera línea, tratamientos y fallas\n\n"
                          "Completa `CONTROLES_1L` y `TRATAMIENTOS` con lo que declara la primera línea (manuales, "
                          "Excels de primera línea): el notebook los cruza con lo que acabas de ejecutar y arma la "
                          "hoja **Fallas** (lo que se le escapó), de lo más grave a lo menos."))
        celdas.append(_code(_CODIGO_ETAPA_CIERRE))

    # ── 7 · Resumen · 8 · Excel · 9 · Devolver ──
    celdas.append(_md(("### Paso 01.8 · Porcentaje de cumplimiento y conclusión\n\n" if etapa else "")
                      + "## 7 · Resumen y porcentaje de cumplimiento\n\n"
                      "**Porcentaje de cumplimiento** = controles que cumplen ÷ controles evaluados "
                      "(los «No evaluable» y los «Pendiente» no cuentan a favor ni en contra: van como limitación). "
                      "También ponderado por criticidad (ALTA 3 · MEDIA 2 · BAJA 1), por dimensión, base, "
                      "origen, criticidad y tipo de modelo, la **cobertura del catálogo** y los críticos que no cumplen."))
    celdas.append(_code(_CODIGO_RESUMEN))
    celdas.append(_md("## 8 · Columnas de cumplimiento y Excel de resultados\n\n"
                      "Hojas: **" + "**, **".join(HOJAS_SALIDA) + "** (la primera es la que lee VIRF)"
                      + (", y detrás las de la etapa (Mapeo, perfil_<base>, Contraste_1L, Tratamientos, Fallas…) "
                         "con un **Indice**" if etapa else "")
                      + ". Aparte, la **evidencia local** con las filas que fallan (no se sube)."))
    celdas.append(_code(_CODIGO_EXCEL))
    if etapa:
        celdas.append(_md(
            f"## 9 · Devolverlo al chat {etapa['fichero']}\n\n"
            f"1. Sube **`{etapa['salida']}`** al chat **{etapa['fichero']}** de la validación completa.\n"
            "2. Escribe tus comentarios (qué te sorprendió, qué falla ya conocía la primera línea) y pega las "
            "capturas que sustenten la revisión: quedan como sustento en el anexo del informe.\n"
            f"3. El agente revisa el Excel y te entrega **{etapa['fichero']}ITER{int(etapa['iteracion']) + 1}.ipynb**, "
            "hasta que la etapa cumpla. **Cerrar la etapa** es decisión tuya.\n"
            "4. **No subas** la evidencia local (`evidencia_local_…xlsx`): tiene filas reales."))
    else:
        celdas.append(_md(_MD_DEVOLVER))

    errores = []
    for k, cel in enumerate(celdas):
        if cel.cell_type == "code":
            try:
                ast.parse("\n".join(l for l in cel.source.splitlines() if not l.lstrip().startswith(("%", "!"))))
            except SyntaxError as exc:
                errores.append(f"celda {k}: {exc}")
    if errores:
        raise ValueError("el notebook generado no compila: " + "; ".join(errores))
    nb["cells"] = celdas
    nb["metadata"] = {"kernelspec": {"name": "python3", "display_name": "Python 3"},
                      "language_info": {"name": "python"},
                      "generado_por": "virf_agent controles_ia",
                      "propuesta": meta.get("propuesta_id") or "",
                      "n_controles": len(controles), "tipos_modelo": tipos}
    if etapa:
        nb["metadata"]["virf"] = {"etapa": etapa.get("codigo", "01"), "iteracion": int(etapa["iteracion"]),
                                  "salida": etapa["salida"]}
    buf = io.StringIO()
    nbf.write(nb, buf)
    return buf.getvalue().encode("utf-8"), {"n_controles": len(controles), "bateria": len(bateria),
                                            "repositorio": n_repo_ok, "plantillas": len(faltan),
                                            "negocio": len(negocio), "plantillas_negocio": len(plant_neg)}

# ═════════════════════════════════════════════════════════════════════════════
# 6. REVISIÓN DE LOS RESULTADOS QUE DEVUELVE EL VALIDADOR
# ═════════════════════════════════════════════════════════════════════════════

def _norm_col(s: str) -> str:
    return re.sub(r"[^a-z0-9%]+", "_", _sin_tildes(s)).strip("_")


def leer_tabla_resultados(ruta: Path) -> list[dict[str, Any]]:
    """Filas del Excel/CSV de resultados en un formato común. Nunca ejecuta nada."""
    import pandas as pd
    ruta = Path(ruta)
    if ruta.suffix.lower() == ".csv":
        df = pd.read_csv(ruta, sep=None, engine="python")
    else:
        df = pd.read_excel(ruta)
    cols = {_norm_col(c): c for c in df.columns}

    def col(*nombres):
        for n in nombres:
            if n in cols:
                return cols[n]
        return None
    c_id = col("control")
    c_desc = col("control_esperado", "descripcion")
    c_inc = col("%_de_incumplimiento", "de_incumplimiento", "incumplimiento")
    c_cum = col("%_de_cumplimiento_del_data_set", "de_cumplimiento_del_data_set", "cumplimiento")
    c_dec = col("decision", "resultado")
    c_diag = col("diagnostico", "detalle_observacion", "detalle")
    c_umb = col("umbral")
    c_ori = col("origen")
    c_def = col("definicion")
    c_tipo = col("tipo")
    if not (c_id or c_desc) or not (c_dec or c_inc or c_cum):
        raise ValueError("el archivo no trae las columnas del cuadro de controles (Control / "
                         "Control Esperado y Decisión o % de cumplimiento)")

    def _texto(r, c) -> str:
        return str(r[c]).strip() if c and str(r[c]) not in ("nan", "None") else ""

    filas = []
    for _, r in df.iterrows():
        # «Definición» (JSON con tipo, columnas y parámetros) la escribe el
        # notebook: es lo que permite aprender del control tal como se ejecutó.
        definicion: dict = {}
        if _texto(r, c_def):
            try:
                d = json.loads(_texto(r, c_def))
                definicion = d if isinstance(d, dict) else {}
            except ValueError:
                definicion = {}
        inc = _num(r[c_inc]) if c_inc else None
        cum = _num(r[c_cum]) if c_cum else None
        if inc is None and cum is not None:
            inc = round(100 - cum, 6)
        dec = str(r[c_dec]).strip() if c_dec and str(r[c_dec]) != "nan" else ""
        dn = _sin_tildes(dec)
        decision = ("Cumple" if dn in ("cumple", "ok", "conforme", "pass") else
                    "No cumple" if dn in ("no cumple", "falla", "fail", "no_cumple", "incumple") else
                    "No evaluable" if dec else "")
        filas.append({
            "control": str(r[c_id]).strip() if c_id else "",
            "descripcion": str(r[c_desc]).strip() if c_desc else "",
            "pct_incumplimiento": inc,
            "decision": decision,
            "diagnostico": str(r[c_diag]).strip() if c_diag and str(r[c_diag]) != "nan" else "",
            "umbral": _num(r[c_umb]) if c_umb else None,
            "criticidad": str(r[cols["criticidad"]]).strip().upper() if "criticidad" in cols else "",
            "dataset": str(r[cols["dataset"]]).strip() if "dataset" in cols else "",
            "origen": _texto(r, c_ori),
            "tipo": str(definicion.get("tipo") or _texto(r, c_tipo)),
            "columnas": [str(x) for x in definicion.get("columnas") or []
                         if isinstance(x, (str, int, float))],
            "params": definicion.get("params") if isinstance(definicion.get("params"), dict) else {},
        })
    return filas


def leer_anexos(ruta: Path) -> dict[str, Any]:
    """
    Hojas extra del Excel que produce el notebook: Metadatos (propuesta, modo
    demo, huellas), Perfil_vs_datos y Controles_personalizados. Vacío si es un
    CSV o un cuadro de otra fuente. Nunca ejecuta nada (el código de los
    controles programados se lee como TEXTO).
    """
    out: dict[str, Any] = {"metadatos": {}, "perfil": [], "personalizados": [],
                           "modo_demo": False, "propuesta": ""}
    ruta = Path(ruta)
    if ruta.suffix.lower() not in (".xlsx", ".xlsm"):
        return out
    import pandas as pd
    try:
        hojas = pd.read_excel(ruta, sheet_name=None)
    except Exception:                                     # noqa: BLE001
        return out

    def _limpio(v: Any) -> Any:
        return "" if v is None or str(v) in ("nan", "None", "NaT") else v

    meta = hojas.get("Metadatos")
    if meta is not None and {"Campo", "Valor"} <= set(meta.columns):
        out["metadatos"] = {str(k): str(_limpio(v)) for k, v in zip(meta["Campo"], meta["Valor"])
                            if str(_limpio(k))}
    demo = _sin_tildes(out["metadatos"].get("Modo demo", ""))
    out["modo_demo"] = demo.startswith("si")
    out["propuesta"] = out["metadatos"].get("Propuesta", "")
    pv = hojas.get("Perfil_vs_datos")
    if pv is not None:
        out["perfil"] = [{str(k): _limpio(v) for k, v in r.items()} for r in pv.to_dict("records")][:2000]
    pc = hojas.get("Controles_personalizados")
    if pc is not None:
        out["personalizados"] = [{str(k): str(_limpio(v))[:30000] for k, v in r.items()}
                                 for r in pc.to_dict("records")][:100]
    return out


def _limpio_celda(v: Any) -> Any:
    if v is None or str(v) in ("nan", "NaT", "None", ""):
        return None
    if hasattr(v, "isoformat"):
        return str(v)[:19]
    return v


def perfiles_desde_excel(ruta: Path) -> list[dict[str, Any]]:
    """
    Perfiles (el mismo formato que `perfil_dataset`) desde las hojas
    `perfil_<base>` que escriben los notebooks de la validación completa
    (00_Diagnostico y 01_ControlDatos). Así la etapa 01 arma el notebook de
    calidad de datos sin que el validador pegue `.info()`. Nunca ejecuta nada.
    """
    import pandas as pd
    try:
        hojas = pd.read_excel(Path(ruta), sheet_name=None)
    except Exception:                                     # noqa: BLE001
        return []
    out = []
    for nombre, h in hojas.items():
        if not str(nombre).startswith("perfil_") or "columna" not in h.columns:
            continue
        filas, cols = None, []
        for _, r in h.iterrows():
            n, nul = _num(r.get("n")), _num(r.get("nulos"))
            if filas is None and n is not None and nul is not None:
                filas = int(n + nul)
            stats = {"count": n, "unique": _num(r.get("unicos")), "mean": _num(r.get("media")),
                     "std": _num(r.get("desv")), "min": _limpio_celda(r.get("min")), "25%": _num(r.get("p25")),
                     "50%": _num(r.get("p50")), "75%": _num(r.get("p75")), "max": _limpio_celda(r.get("max")),
                     "top": _limpio_celda(r.get("top")), "freq": _num(r.get("freq"))}
            cols.append({"nombre": str(r["columna"]), "dtype": str(r.get("tipo") or ""),
                         "no_nulos": int(n) if n is not None else None, "nulos": int(nul) if nul is not None else None,
                         "pct_nulos": _num(r.get("pct_nulos")),
                         "stats": {k: v for k, v in stats.items() if v is not None}})
        out.append({"nombre": str(nombre)[len("perfil_"):], "filas": filas, "columnas": cols, "avisos": [],
                    "formato": "excel_perfil"})
    return out


def enlace_desde_excel(ruta: Path) -> dict[str, Any]:
    """
    El enlace base lógica → base real y rol → columna que CONFIRMÓ el validador
    (hoja «Diccionario» del 00 o «Roles» del 01). Solo filas enlazadas.
    """
    import pandas as pd
    try:
        hojas = pd.read_excel(Path(ruta), sheet_name=None)
    except Exception:                                     # noqa: BLE001
        return {}
    for hoja, (c_b, c_ds, c_r, c_c, c_e) in (("Roles", ("Base lógica", "Base real", "Rol", "Columna", "Estado")),
                                              ("Diccionario", ("base_logica", "base_real", "rol", "columna", "estado"))):
        h = hojas.get(hoja)
        if h is None or not {c_b, c_ds, c_r, c_c, c_e} <= set(h.columns):
            continue
        bases: dict[str, str] = {}
        roles: dict[str, dict[str, str]] = {}
        for _, r in h.iterrows():
            if not str(r[c_e]).startswith("enlazado"):
                continue
            b, ds, rol, col = (str(r[x]).strip() for x in (c_b, c_ds, c_r, c_c))
            if not ds or ds in ("—", "nan") or not col or col in ("—", "nan"):
                continue
            bases.setdefault(b, ds)
            roles.setdefault(ds, {})[rol] = col
        if bases:
            return {"bases": bases, "roles": roles, "fuente": f"{Path(ruta).name}!{hoja}"}
    return {}


def _riesgo(crit: str, inc: Optional[float]) -> str:
    inc = inc or 0.0
    if crit == "ALTA":
        return "Crítico" if inc >= 10 else "Moderado"
    if crit == "BAJA":
        return "Bajo" if inc >= 5 else "Potencial"
    return "Moderado" if inc >= 10 else "Bajo"


def revisar_resultados(filas: list[dict], propuesta: Optional[dict] = None, *,
                       usar_ia: bool = False,
                       llamar: Optional[Callable[[str, int], str]] = None,
                       anexos: Optional[dict] = None) -> dict[str, Any]:
    """
    Revisa el cuadro de cumplimiento que devolvió el validador.

    Determinista (siempre): coherencia decisión ↔ % ↔ umbral, controles no
    ejecutados o no evaluables, y una observación por control que no cumple.
    Con `anexos` (hojas extra del Excel del notebook, ver `leer_anexos`):
    resultados del MODO_DEMO, diferencias entre las bases ejecutadas y el
    perfil, y controles programados por el validador.
    Con `usar_ia`, la IA redacta observaciones y un comentario general; cada
    texto se verifica (controles que existen, sin cifras ajenas a la tabla).
    """
    props = {c["id"]: c for c in (propuesta or {}).get("controles") or []}
    incoherencias, limitaciones, observaciones = [], [], []
    for f in filas:
        cid = f["control"] or f["descripcion"][:40]
        crit = f["criticidad"] or (props.get(f["control"]) or {}).get("criticidad", "MEDIA")
        inc, umb, dec = f["pct_incumplimiento"], f["umbral"], f["decision"]
        if dec == "Cumple" and inc is not None and umb is not None and inc > umb + 1e-9:
            incoherencias.append(f"{cid}: «Cumple» con {inc:g} % de incumplimiento sobre un "
                                 f"umbral de {umb:g} %.")
        if dec == "No cumple" and inc is not None and umb is not None and inc <= umb:
            incoherencias.append(f"{cid}: «No cumple» con {inc:g} % de incumplimiento, dentro "
                                 f"del umbral de {umb:g} %.")
        if dec == "No evaluable" or not dec:
            limitaciones.append(f"{cid}: no se pudo evaluar — {f['diagnostico'] or 'sin diagnóstico'}.")
        if dec == "No cumple":
            observaciones.append({
                "control": cid, "riesgo": _riesgo(crit, inc), "origen": "reglas",
                "observacion": (f"El control «{f['descripcion'] or cid}» no se cumple"
                                + (f": {inc:g} % de incumplimiento" if inc is not None else "")
                                + (f" (umbral {umb:g} %)" if umb is not None else "") + ". "
                                + (f["diagnostico"] or "")).strip(),
                "recomendacion": ("Corregir los registros afectados en la fuente y documentar "
                                  "el tratamiento aplicado por la primera línea."),
            })
    ejecutados = {f["control"] for f in filas}
    faltan = [cid for cid in props if cid not in ejecutados]
    if faltan:
        limitaciones.append(f"Controles propuestos que no aparecen en los resultados: "
                            f"{', '.join(faltan)}.")
    anexos = anexos or {}
    if anexos.get("modo_demo"):
        limitaciones.insert(0, "El cuadro salió del MODO_DEMO (datos sintéticos): no prueba nada "
                               "sobre las bases del modelo.")
    dif = [r for r in anexos.get("perfil") or [] if str(r.get("Aviso") or "").strip()]
    if dif:
        limitaciones.append(
            f"Las bases ejecutadas no coinciden con el perfil en {len(dif)} punto(s): "
            + "; ".join(f"{r.get('Base')}.{r.get('Columna')}: {r.get('Aviso')}" for r in dif[:6])
            + ("…" if len(dif) > 6 else "") + ".")
    if anexos.get("personalizados"):
        limitaciones.append(
            f"{len(anexos['personalizados'])} control(es) programado(s) por el validador "
            f"({', '.join(str(p.get('Control', '')) for p in anexos['personalizados'][:8])}): su "
            "código viaja como texto en la hoja Controles_personalizados; revísalo antes de dar "
            "por buenos sus resultados.")
    comentario, avisos = "", []
    if usar_ia and filas:
        if llamar is None:
            from modulos.notebook_controles import llamar_ia_controles as llamar
        from modulos.motor_ia import _extraer_json
        from modulos.salida_ia import material_no_confiable as _mnc
        tabla = "\n".join(
            f"{f['control']} | {f['descripcion']} | incumplimiento={f['pct_incumplimiento']} % | "
            f"umbral={f['umbral']} | {f['decision']} | {f['diagnostico'][:200]}" for f in filas)
        prompt = ("Eres validador de calidad de datos de un banco. Revisa este cuadro de controles "
                  "que ejecutó la primera línea y redacta, para cada control que NO cumple o es "
                  "incoherente, una observación de validación (riesgo Crítico|Moderado|Bajo|Potencial, "
                  "observación y recomendación). Usa SOLO las cifras del cuadro. Devuelve SOLO JSON: "
                  '{"observaciones":[{"control":"C01","riesgo":"…","observacion":"…",'
                  '"recomendacion":"…"}],"comentario":"1-3 frases sobre la calidad de datos"}\n\n'
                  + _mnc(tabla[:12000], "cuadro_controles"))
        try:
            prop = _extraer_json(llamar(prompt, 3000))
        except Exception as exc:                          # noqa: BLE001
            prop = None
            avisos.append(f"la IA no devolvió una revisión utilizable ({exc}); se usa la revisión "
                          "por reglas.")
        if isinstance(prop, dict):
            from modulos.graficos_estructurados import numeros
            cifras = numeros(tabla)
            validos = {f["control"] for f in filas}
            ia_obs = []
            for o in prop.get("observaciones") or []:
                if not isinstance(o, dict) or str(o.get("control")) not in validos:
                    continue
                texto = f"{o.get('observacion', '')} {o.get('recomendacion', '')}"
                if numeros(texto) - cifras:
                    avisos.append(f"{o.get('control')}: la IA citó cifras que no están en el cuadro; "
                                  "se mantiene la observación por reglas.")
                    continue
                try:
                    from modulos.reglas_informe import normalizar_riesgo
                    riesgo = normalizar_riesgo(o.get("riesgo"))
                except ValueError:
                    riesgo = "Moderado"
                ia_obs.append({"control": str(o["control"]), "riesgo": riesgo, "origen": "ia",
                               "observacion": " ".join(str(o.get("observacion") or "").split())[:900],
                               "recomendacion": " ".join(str(o.get("recomendacion") or "").split())[:600]})
            por_ctrl = {o["control"]: o for o in ia_obs}
            observaciones = [por_ctrl.pop(o["control"], o) for o in observaciones] + list(por_ctrl.values())
            c = " ".join(str(prop.get("comentario") or "").split())[:800]
            comentario = c if not (numeros(c) - cifras) else ""
    n = len(filas)
    n_ok = sum(1 for f in filas if f["decision"] == "Cumple")
    n_no = sum(1 for f in filas if f["decision"] == "No cumple")
    # Porcentaje de cumplimiento = cumplen ÷ evaluados (los no evaluables son
    # limitación, no cuentan); ponderado por criticidad ALTA 3 · MEDIA 2 · BAJA 1.
    pct = round(100.0 * n_ok / (n_ok + n_no), 2) if (n_ok + n_no) else None
    peso = {"ALTA": 3, "MEDIA": 2, "BAJA": 1}
    ev = [f for f in filas if f["decision"] in ("Cumple", "No cumple")]
    tot = sum(peso.get(f.get("criticidad") or "MEDIA", 2) for f in ev)
    pond = (round(100.0 * sum(peso.get(f.get("criticidad") or "MEDIA", 2) for f in ev
                              if f["decision"] == "Cumple") / tot, 2) if tot else None)
    declarado = _num((anexos.get("metadatos") or {}).get("Porcentaje de cumplimiento"))
    if declarado is not None and pct is not None and abs(declarado - pct) > 0.01:
        incoherencias.append(f"El Excel declara un {declarado:g} % de cumplimiento y el cuadro da "
                             f"{pct:g} %: se editó el cuadro o los metadatos después de ejecutar.")
    return {"resumen": {"controles": n, "cumplen": n_ok, "no_cumplen": n_no,
                        "no_evaluables": sum(1 for f in filas if f["decision"] not in ("Cumple", "No cumple")),
                        "pct_cumplimiento": pct, "pct_ponderado": pond},
            "observaciones": observaciones, "incoherencias": incoherencias,
            "limitaciones": limitaciones, "comentario": comentario, "avisos": avisos,
            "metadatos": anexos.get("metadatos") or {}}
