"""
modulos/plantillas_etapa.py
═══════════════════════════════════════════════════════════════════════════════
RUTA PASO A PASO y NOTEBOOKS PLANTILLA de la validación completa.

Cada etapa (00 Diagnóstico · 01 Control de datos · 02 Modelamiento · 03
Impactos · 04 Seguimiento) tiene:

  · EXPERTOS[codigo]   quién es el experto que habla en ese chat y qué mira;
  · RUTAS[codigo]      los pasos, en orden, con qué se hace, en qué hoja del
                       Excel queda y cuándo está cubierto;
  · una plantilla      notebook determinista (sin IA) que recorre la ruta con
                       código real: el 00 mapea, el 02 replica según el TIPO
                       DE MODELO (VaR, run-off, IRRBB, prepago, LCR…), el 03
                       cuantifica impactos y el 04 replica el seguimiento.

La etapa 01 usa el notebook de calidad de datos (`modulos.controles_ia`), así
que su plantilla vive allí; aquí solo su ruta.

Todo el código de las plantillas se valida con `ast.parse` en el servidor y se
EJECUTA en el equipo del validador (los tests lo ejecutan sobre datos
sintéticos).
"""
from __future__ import annotations

from typing import Any, Iterable

__all__ = ["EXPERTOS", "RUTAS", "ruta", "celdas_plantilla", "cobertura_plantilla"]


# ═════════════════════════════════════════════════════════════════════════════
# 1. EXPERTOS Y RUTAS
# ═════════════════════════════════════════════════════════════════════════════

EXPERTOS = {
    "00": ("Arquitecto de datos de riesgo (BCBS 239): conoce el linaje de cada base del modelo, de qué sistema "
           "viene, qué identifica una fila, qué periodo cubre y cómo la controla hoy la primera línea. No opina "
           "del modelo todavía: deja un MAPA completo y las brechas que la etapa 01 debe atacar."),
    "01": ("Especialista en calidad de datos de modelos de riesgo: recorre cada base y cada columna con controles "
           "de completitud, unicidad, validez, exactitud, consistencia y actualidad, más los del negocio del tipo de "
           "modelo, y busca activamente lo que se le escapó a la primera línea. Cada falla sale con N afectados, % y "
           "evidencia."),
    "02": ("Modelador cuantitativo senior: replica el modelo paso a paso con el manual y el código (población, "
           "variables, supuestos, estimación, resultado), compara cada cifra con la del implementador y explica cada "
           "diferencia. Es la etapa más importante: no da nada por bueno sin recalcularlo."),
    "03": ("Experto en materialidad: toma cada hallazgo abierto de 01 y 02, lo corrige en los datos y mide cuánto "
           "cambia la métrica del modelo (VaR, ΔEVE, CPR, LCR…) contra límites y umbrales; clasifica el impacto con "
           "un criterio explícito y mira también el efecto conjunto."),
    "04": ("Experto en monitoreo y backtesting: replica cada indicador del manual de seguimiento con los datos del "
           "periodo, lo compara con lo reportado, revisa semáforos, alertas y acciones, y concluye si el modelo "
           "sigue vigente."),
}

#: (paso, título, qué se hace, hoja del Excel donde queda, criterio de «cubierto»)
RUTAS: dict[str, list[tuple[str, str, str, str, str]]] = {
    "00": [
        ("00.1", "Inventario de fuentes", "Cada base de RUTAS con su ruta, formato, tamaño, fecha de modificación y si "
         "se pudo leer.", "Mapeo", "todas las bases leídas o con el error explicado"),
        ("00.2", "Perfil técnico", "Filas, columnas, tipos, nulos, únicos, rangos y estadísticos de cada columna.",
         "perfil_<base>", "una hoja de perfil por base"),
        ("00.3", "Granularidad y llaves", "Qué identifica una fila (llave candidata) y si tiene duplicados.", "Llaves",
         "llave candidata o falta de ella declarada por base"),
        ("00.4", "Cobertura temporal", "Primera y última fecha, frecuencia observada y periodos faltantes.",
         "Cobertura_temporal", "cada columna de fecha con su cobertura"),
        ("00.5", "Relaciones entre bases", "Columnas compartidas, cruces de llaves y huérfanos entre bases.", "Cruces",
         "cruces calculados entre las bases con columnas comunes"),
        ("00.6", "Diccionario de negocio", "Qué columna cumple cada concepto del tipo de modelo (P&L, saldo, banda…) y "
         "qué falta.", "Diccionario", "todos los roles del tipo de modelo enlazados o declarados como faltantes"),
        ("00.7", "Controles de la primera línea", "Qué controles declara la primera línea por base (manuales, Excels).",
         "Controles_1L", "tabla completada por el validador con fuente"),
        ("00.8", "Brechas y plan para la etapa 01", "Bases o columnas críticas que faltan, periodos incompletos, llaves "
         "duplicadas y qué debe controlar la etapa 01.", "Brechas", "brechas listadas con severidad sugerida"),
    ],
    "01": [
        ("01.1", "Retomar el mapeo", "Bases, llaves y roles que dejó el 00; perfil de cada base.", "Mapeo / perfil_<base>",
         "mapeo y perfiles en el Excel"),
        ("01.2", "Batería de calidad (BCBS 239)", "Completitud, unicidad, validez, exactitud, consistencia y actualidad "
         "sobre todas las columnas.", "Controles (C, B, BD)", "batería ejecutada en todas las bases"),
        ("01.3", "Controles del tipo de modelo", "Controles de negocio por roles (M) y análisis del repositorio (D).",
         "Controles (M, D)", "controles del tipo de modelo ejecutados o pendientes explicados"),
        ("01.4", "Integridad y conciliaciones", "Huérfanos entre bases y cuadres de conteos y montos (también contra "
         "contabilidad).", "Controles", "cruces y cuadres ejecutados"),
        ("01.5", "Contraste con la primera línea", "Lo que controló la primera línea, con qué umbral y resultado, contra "
         "lo que da la segunda línea.", "Contraste_1L", "tabla completada y cruzada"),
        ("01.6", "Tratamientos aplicados", "Exclusiones, imputaciones y ajustes de la primera línea y su sustento.",
         "Tratamientos", "tratamientos declarados con sustento"),
        ("01.7", "Fallas que se escaparon", "Lo que no cumple, de lo más grave a lo menos, con N afectados y evidencia.",
         "Fallas", "fallas listadas con severidad"),
        ("01.8", "Porcentaje de cumplimiento y conclusión", "Cumplen ÷ evaluados, ponderado por criticidad, y conclusión "
         "de la etapa.", "Resumen", "porcentaje calculado y conclusión escrita"),
    ],
    "02": [
        ("02.1", "Población y ventana", "Bases, periodos y exclusiones del manual con conteos antes y después.",
         "Poblacion", "población reconstruida con sus exclusiones"),
        ("02.2", "Variables y transformaciones", "Qué columna es cada variable del modelo y cómo se transforma.",
         "Variables", "variables enlazadas a columnas"),
        ("02.3", "Supuestos", "Nivel de confianza, ventana, horizonte, escala y demás supuestos del manual.", "Supuestos",
         "supuestos tomados del manual con su sección"),
        ("02.4", "Estimación y calibración", "Re-estimar los parámetros con el mismo método del manual.",
         "Replica", "parámetros re-estimados"),
        ("02.5", "Resultado replicado vs implementador", "La métrica final recalculada frente a la reportada, con su "
         "diferencia y materialidad.", "Replica", "métrica comparada con tolerancia"),
        ("02.6", "Sensibilidad y benchmark", "Cómo cambia el resultado con otra ventana, nivel o método alternativo.",
         "Sensibilidad", "al menos una sensibilidad o benchmark"),
        ("02.7", "Implementación", "El código del implementador produce lo mismo que la réplica independiente.",
         "Implementacion", "resultado del código del implementador contrastado"),
        ("02.8", "Conclusión y limitaciones", "Pasos que difieren, que no se pudieron replicar y qué insumo falta.",
         "Conclusion", "conclusión y pendientes"),
    ],
    "03": [
        ("03.1", "Hallazgos con impacto potencial", "Los hallazgos abiertos de 01 y 02 que pueden mover el resultado.",
         "Hallazgos_origen", "hallazgos de origen listados"),
        ("03.2", "Métrica afectada", "Qué métrica del modelo mueve cada hallazgo (VaR, ΔEVE, CPR, LCR…).", "Impactos",
         "métrica asignada por hallazgo"),
        ("03.3", "Escenario base", "La métrica recalculada con los datos tal como están.", "Impactos",
         "valor base calculado"),
        ("03.4", "Escenario corregido", "La métrica sin la falla (o con el dato correcto), hallazgo por hallazgo.",
         "Impactos", "corrección aplicada por hallazgo"),
        ("03.5", "Impacto frente a materialidad", "Impacto absoluto y relativo contra umbrales y límites.", "Impactos",
         "impacto cuantificado"),
        ("03.6", "Impacto conjunto", "Todas las correcciones a la vez (los impactos no se suman).", "Impactos",
         "escenario conjunto calculado"),
        ("03.7", "Nivel y criterio", "Potencial/Bajo, Moderado o Crítico con el criterio explícito.", "Impactos",
         "nivel asignado con criterio"),
    ],
    "04": [
        ("04.1", "Inventario de indicadores", "Indicadores del manual de seguimiento con umbral, frecuencia y semáforo.",
         "Indicadores", "indicadores del manual listados"),
        ("04.2", "Recalcular indicadores", "Cada indicador recalculado con los datos del periodo.", "Seguimiento",
         "indicadores recalculados"),
        ("04.3", "Comparar con lo reportado", "Valor replicado frente al del implementador.", "Seguimiento",
         "comparación con tolerancia"),
        ("04.4", "Backtesting", "Prueba del modelo contra lo observado (excepciones, CPR observado, salidas reales…).",
         "Backtesting", "backtesting del tipo de modelo"),
        ("04.5", "Estabilidad", "Estabilidad de poblaciones y variables (PSI) y deriva.", "Estabilidad", "PSI calculado"),
        ("04.6", "Semáforo, alertas y acciones", "Qué alertas se dispararon, si se escalaron y qué acciones hubo.",
         "Alertas", "alertas revisadas"),
        ("04.7", "Conclusión sobre la vigencia", "Si el modelo sigue vigente y qué recomendar.", "Conclusion",
         "conclusión escrita"),
    ],
}


def ruta(codigo: str) -> list[dict[str, str]]:
    return [{"paso": p, "titulo": t, "que": q, "hoja": h, "criterio": c} for p, t, q, h, c in RUTAS[codigo]]


# ═════════════════════════════════════════════════════════════════════════════
# 2. PLANTILLAS (código que se ejecuta en el equipo del validador)
# ═════════════════════════════════════════════════════════════════════════════

def _md(t: str) -> dict:
    return {"tipo": "markdown", "contenido": t}


def _code(t: str) -> dict:
    return {"tipo": "code", "contenido": t.strip("\n")}


def _paso(codigo: str, n: int, extra: str = "") -> dict:
    p, t, q, h, _c = RUTAS[codigo][n - 1]
    return _md(f"## Paso {p} · {t}\n\n{q} → hoja **{h}**." + (f"\n\n{extra}" if extra else ""))


# ── 00 · Diagnóstico ────────────────────────────────────────────────────────

_C00_1 = r'''
import os as _os
inventario = []
for nombre, ruta in RUTAS.items():
    p = Path(ruta)
    fila = {"base": nombre, "ruta": str(ruta), "formato": p.suffix.lower(), "existe": p.is_file(),
            "tamano_mb": round(p.stat().st_size / 1e6, 3) if p.is_file() else None,
            "modificado": (pd.Timestamp(p.stat().st_mtime, unit="s").strftime("%Y-%m-%d %H:%M") if p.is_file() else None),
            "leida": nombre in bases, "error": ERRORES_CARGA.get(nombre, "")}
    df = bases.get(nombre)
    if df is not None:
        fechas = [c for c in df.columns if es_fecha(df[c])]
        fila.update({"filas": len(df), "columnas": df.shape[1], "duplicados": int(df.duplicated().sum()),
                     "pct_nulos_medio": round(100 * float(df.isna().mean().mean()), 4) if df.shape[1] else 0.0,
                     "fecha_min": str(min(a_fecha(df[c]).min() for c in fechas))[:10] if fechas else "",
                     "fecha_max": str(max(a_fecha(df[c]).max() for c in fechas))[:10] if fechas else "",
                     # Lo completas tú (o el agente con IA) leyendo los manuales:
                     "contenido": "", "uso": "", "observado": "", "evidencia": f"{nombre} ({p.name})"})
    inventario.append(fila)
registrar("Mapeo", inventario, "Paso 00.1 · una fila por base")
pd.DataFrame(inventario)
'''

_C00_2 = r'''
for nombre, df in bases.items():
    registrar(f"perfil_{nombre}"[:31], perfil(df), "Paso 00.2 · perfil por columna")
print(f"Perfiles: {len(bases)} base(s).")
'''

_C00_3 = r'''
from itertools import combinations as _comb
LLAVES = []
for nombre, df in bases.items():
    candidatas = [c for c in df.columns if df[c].notna().all() and df[c].nunique() == len(df)]
    llave, dup = (candidatas[:1], 0) if candidatas else ([], None)
    if not candidatas and len(df):
        # Pares de columnas que identifican una fila (prueba las 15 columnas con más valores distintos).
        top = sorted(df.columns, key=lambda c: -df[c].nunique())[:15]
        for a, b in _comb(top, 2):
            if not df.duplicated(subset=[a, b]).any() and df[[a, b]].notna().all().all():
                llave = [a, b]
                break
    if llave:
        dup = int(df.duplicated(subset=llave, keep=False).sum())
    LLAVES.append({"base": nombre, "llave_candidata": " + ".join(map(str, llave)) or "(ninguna de 1 o 2 columnas)",
                   "filas": len(df), "filas_con_llave_repetida": dup,
                   "filas_identicas": int(df.duplicated(keep=False).sum()),
                   "granularidad": "una fila por " + (" × ".join(map(str, llave)) if llave else "¿? (decláralo)")})
registrar("Llaves", LLAVES, "Paso 00.3")
pd.DataFrame(LLAVES)
'''

_C00_4 = r'''
COBERTURA = []
for nombre, df in bases.items():
    for c in [c for c in df.columns if es_fecha(df[c])]:
        f = a_fecha(df[c]).dropna()
        if f.empty:
            continue
        u = pd.Series(sorted(f.dt.normalize().unique()))
        paso = u.diff().dt.days.dropna()
        moda = float(paso.mode().iloc[0]) if len(paso) else None
        frec = ("diaria hábil" if moda in (1.0, 3.0) and (u.dt.dayofweek < 5).all() else "diaria" if moda == 1.0
                else "semanal" if moda == 7.0 else "mensual" if moda and 28 <= moda <= 31 else
                "trimestral" if moda and 89 <= moda <= 92 else "irregular" if moda else "una fecha")
        if frec == "diaria hábil":
            esperadas = pd.bdate_range(u.min(), u.max())
        elif frec == "mensual":
            esperadas = pd.period_range(u.min(), u.max(), freq="M")
            u = pd.Series(u.dt.to_period("M").unique())
        else:
            esperadas = pd.DatetimeIndex(u)
        faltan = [x for x in esperadas if x not in set(u)]
        COBERTURA.append({"base": nombre, "columna": c, "desde": str(f.min())[:10], "hasta": str(f.max())[:10],
                          "fechas_distintas": int(f.dt.normalize().nunique()), "frecuencia": frec,
                          "periodos_faltantes": len(faltan), "ejemplos_faltantes": ", ".join(str(x)[:10] for x in faltan[:5])})
registrar("Cobertura_temporal", COBERTURA or [{"aviso": "ninguna columna de fecha"}], "Paso 00.4")
pd.DataFrame(COBERTURA)
'''

_C00_5 = r'''
CRUCES = []
nombres = list(bases)
for i, a in enumerate(nombres):
    for b in nombres[i + 1:]:
        comunes = [c for c in bases[a].columns if c in set(bases[b].columns)]
        for c in comunes[:20]:
            va, vb = set(bases[a][c].dropna().astype(str)), set(bases[b][c].dropna().astype(str))
            if not va or not vb:
                continue
            CRUCES.append({"base_a": a, "base_b": b, "columna": c, "distintos_a": len(va), "distintos_b": len(vb),
                           "pct_a_en_b": round(100 * len(va & vb) / len(va), 2),
                           "pct_b_en_a": round(100 * len(va & vb) / len(vb), 2),
                           "huerfanos_a": len(va - vb), "huerfanos_b": len(vb - va)})
registrar("Cruces", CRUCES or [{"aviso": "no hay columnas comunes entre bases"}], "Paso 00.5")
pd.DataFrame(CRUCES)
'''

_C00_6 = r'''
DICCIONARIO = []
for base, roles in ROLES_DE_BASE.items():
    ds = BASES.get(base)
    df = bases.get(ds) if ds else None
    for rol in roles:
        enl = (ROLES.get(ds) or {}).get(rol) if ds else None
        sug = []
        if df is not None:
            rx = _re_q.compile(PATRON_ROL.get(rol, "^$"))
            sug = [c for c in df.columns if rx.search(norm_col(c))]
        ok = df is not None and enl in df.columns
        DICCIONARIO.append({"base_logica": base, "que_es": NOMBRES_BASE.get(base, base), "base_real": ds or "—",
                            "rol": rol, "concepto": DESC_ROLES.get(rol, rol),
                            "columna": enl if ok else (sug[0] if sug else "—"),
                            # «sugerido» = la columna que parece cumplir el rol: confírmala en ROLES
                            # (pon «enlazado» si la corriges a mano) y la etapa 01 la usará.
                            "estado": "enlazado" if ok else ("sugerido" if sug else ("SIN ENLAZAR" if ds else "falta la base")),
                            "sugerencias": ", ".join(map(str, sug[:4]))})
registrar("Diccionario", DICCIONARIO or [{"aviso": "sin tipo de modelo elegido: elige el tipo en la ficha del modelo"}],
          "Paso 00.6 · concepto de negocio → columna")
_sin = [d for d in DICCIONARIO if d["estado"] not in ("enlazado", "sugerido")]
print(f"Diccionario: {sum(d['estado'] == 'enlazado' for d in DICCIONARIO)} enlazados, "
      f"{sum(d['estado'] == 'sugerido' for d in DICCIONARIO)} sugeridos y {len(_sin)} sin columna "
      f"de {len(DICCIONARIO)} roles.")
for d in _sin[:40]:
    print(f"  ⚠ {d['base_logica']}.{d['rol']} ({d['concepto']}): {d['estado']}"
          + (f" — sugerencias: {d['sugerencias']}" if d["sugerencias"] else ""))
'''

_C00_7 = r'''
# Completa con lo que declara la primera línea (manuales de controles, Excels de primera línea):
CONTROLES_1L = [
    # {"base": "saldos", "control": "Unicidad del número de cuenta", "umbral": "0 %", "frecuencia": "mensual",
    #  "resultado_reportado": "Cumple", "fuente": "Manual de controles §4.2"},
]
registrar("Controles_1L", CONTROLES_1L or [{"aviso": "Completa CONTROLES_1L con los controles de la primera línea."}],
          "Paso 00.7")
'''

_C00_8 = r'''
BRECHAS = []
for n, e in ERRORES_CARGA.items():
    BRECHAS.append({"brecha": "base que no se pudo leer", "base": n, "detalle": e, "severidad": "Crítico",
                    "accion": "Corregir la ruta o el formato y volver a ejecutar."})
for l in LLAVES:
    if l["filas_con_llave_repetida"]:
        BRECHAS.append({"brecha": "llave con duplicados", "base": l["base"],
                        "detalle": f"{l['filas_con_llave_repetida']} filas con {l['llave_candidata']} repetida",
                        "severidad": "Moderado", "accion": "Confirmar la granularidad con la primera línea (etapa 01)."})
    if l["llave_candidata"].startswith("(ninguna"):
        BRECHAS.append({"brecha": "sin llave identificable", "base": l["base"], "detalle": l["granularidad"],
                        "severidad": "Moderado", "accion": "Declarar qué identifica una fila."})
for c in COBERTURA:
    if c.get("periodos_faltantes"):
        BRECHAS.append({"brecha": "periodos faltantes", "base": c["base"],
                        "detalle": f"{c['columna']}: {c['periodos_faltantes']} periodo(s) ({c['ejemplos_faltantes']})",
                        "severidad": "Moderado", "accion": "Explicar o completar la serie (etapa 01)."})
for nombre, df in bases.items():
    vacias = [c for c in df.columns if df[c].isna().all()]
    if vacias:
        BRECHAS.append({"brecha": "columnas vacías", "base": nombre, "detalle": ", ".join(map(str, vacias[:8])),
                        "severidad": "Potencial/Bajo", "accion": "Confirmar si deben venir informadas."})
_faltan_bases = sorted({d["base_logica"] for d in DICCIONARIO if d["estado"] == "falta la base"})
for b in _faltan_bases:
    BRECHAS.append({"brecha": "base del modelo que no está en RUTAS", "base": b,
                    "detalle": f"{NOMBRES_BASE.get(b, b)}: ninguna base de RUTAS la cubre", "severidad": "Moderado",
                    "accion": "Pídela a la primera línea o declara que el modelo no la usa."})
for d in DICCIONARIO:
    if d["estado"] == "SIN ENLAZAR":
        BRECHAS.append({"brecha": "concepto del modelo sin columna", "base": d["base_real"],
                        "detalle": f"{d['base_logica']}.{d['rol']} ({d['concepto']})", "severidad": "Moderado",
                        "accion": "Enlazar en ROLES o confirmar con la primera línea que no existe."})
registrar("Brechas", BRECHAS or [{"aviso": "sin brechas automáticas"}], "Paso 00.8 · plan para la etapa 01")
print(f"Brechas: {len(BRECHAS)} ({sum(b['severidad'] == 'Crítico' for b in BRECHAS)} críticas).")
'''


def _celdas_00() -> list[dict]:
    return [
        _paso("00", 1), _code(_C00_1), _paso("00", 2), _code(_C00_2), _paso("00", 3), _code(_C00_3),
        _paso("00", 4), _code(_C00_4), _paso("00", 5), _code(_C00_5),
        _paso("00", 6, "Usa los conceptos de negocio del tipo de modelo (sección de soporte: `BASES`, `ROLES`). "
                       "Si un rol no tiene columna, corrige `ROLES` arriba y vuelve a ejecutar."), _code(_C00_6),
        _paso("00", 7), _code(_C00_7), _paso("00", 8), _code(_C00_8),
    ]


# ── 02 · Modelamiento: réplica por tipo de modelo ──────────────────────────

_C02_1 = r'''
# Exclusiones del manual: {"base": …, "condicion": "expresión de pandas (df.query)", "motivo": …, "seccion": …}
EXCLUSIONES = [
    # {"base": "saldos", "condicion": "saldo < 0", "motivo": "saldos negativos", "seccion": "Manual §2.1"},
]
POBLACION = []
for nombre, df in bases.items():
    fechas = [c for c in df.columns if es_fecha(df[c])]
    POBLACION.append({"base": nombre, "paso": "población inicial", "filas": len(df),
                      "desde": str(min(a_fecha(df[c]).min() for c in fechas))[:10] if fechas else "",
                      "hasta": str(max(a_fecha(df[c]).max() for c in fechas))[:10] if fechas else ""})
for e in EXCLUSIONES:
    df = bases.get(e["base"])
    if df is None:
        continue
    try:
        quitar = df.query(e["condicion"])
    except Exception as exc:
        POBLACION.append({"base": e["base"], "paso": f"exclusión: {e['motivo']}", "error": str(exc)})
        continue
    bases[e["base"]] = df.drop(quitar.index)
    POBLACION.append({"base": e["base"], "paso": f"exclusión: {e['motivo']} ({e.get('seccion', '')})",
                      "filas": len(bases[e['base']]), "excluidas": len(quitar)})
registrar("Poblacion", POBLACION, "Paso 02.1")
pd.DataFrame(POBLACION)
'''

_C02_2 = r'''
VARIABLES = [{"base_logica": b, "base_real": BASES.get(b) or "—", "rol": r, "concepto": DESC_ROLES.get(r, r),
              "columna": (ROLES.get(BASES.get(b)) or {}).get(r) or "—"}
             for b, rs in ROLES_DE_BASE.items() for r in rs]
registrar("Variables", VARIABLES or [{"aviso": "sin tipo de modelo elegido"}], "Paso 02.2 · variables del modelo")
pd.DataFrame(VARIABLES)
'''

_C02_3 = r'''
registrar("Supuestos", [{"supuesto": k, "valor": v} for k, v in SUPUESTOS.items()],
          "Paso 02.3 · edita SUPUESTOS con los valores y la sección del manual")
REPLICA, SENSIBILIDAD = [], []
'''

_C02_7 = r'''
# Si tienes el resultado del CÓDIGO del implementador como base (añádela a RUTAS como «resultado_implementador»),
# compara sus columnas numéricas con las de la réplica por las columnas comunes.
IMPLEMENTACION = []
if "resultado_implementador" in bases:
    ri = bases["resultado_implementador"]
    IMPLEMENTACION.append({"aviso": f"resultado del implementador: {len(ri)} filas, columnas {list(ri.columns)[:12]}"})
else:
    IMPLEMENTACION.append({"aviso": "Carga en RUTAS el resultado que produce el código del implementador "
                                    "(nombre «resultado_implementador») para contrastarlo con la réplica."})
registrar("Implementacion", IMPLEMENTACION, "Paso 02.7")
'''

_C02_8 = r'''
_rep = pd.DataFrame(REPLICA)
registrar("Replica", _rep if len(_rep) else [{"paso": "—", "conclusion": "sin réplica"}], "Pasos 02.4–02.5")
registrar("Sensibilidad", SENSIBILIDAD or [{"aviso": "sin sensibilidades"}], "Paso 02.6")
_dif = _rep[_rep["conclusion"].astype(str).str.startswith(("Difiere", "No replicable"))] if len(_rep) else _rep
registrar("Conclusion", [{"pasos_replicados": int(len(_rep) - len(_dif)), "pasos_que_difieren_o_faltan": int(len(_dif)),
                          "detalle": "; ".join(f"{r['paso']}: {r['conclusion']}" for _, r in _dif.iterrows())[:3000]
                          or "todos los pasos replicados coinciden"}], "Paso 02.8")
print(f"Réplica: {len(_rep)} paso(s); {len(_dif)} difieren o no se pudieron replicar.")
'''

#: SUPUESTOS por defecto de cada tipo (el validador los ajusta al manual).
_SUPUESTOS = {
    "var": {"nivel_confianza": 0.99, "ventana_dias": 250, "horizonte_dias": 1, "tolerancia_pct": 1.0,
            "convencion_pnl": "pnl_negativo"},
    "es_frtb": {"nivel_es": 0.975, "ventana_dias": 250, "tolerancia_pct": 2.0},
    "stress_mercado": {"tolerancia_pct": 2.0},
    "valoracion": {"tolerancia_ipv_pct": 2.0},
    "curvas": {"convencion": "continua", "tolerancia_pct": 0.1},
    "contraparte": {"alfa_saccr": 1.4, "tolerancia_pct": 2.0},
    "irrbb": {"choque_paralelo": 0.02, "tasa_base": 0.0, "tier1": None, "tolerancia_pct": 10.0},
    "prepago": {"tolerancia_pp": 0.10},
    "nmd": {"tolerancia_pct": 10.0},
    "cancelacion_dpf": {"tolerancia_pp": 0.5},
    "supervivencia": {"plazos_meses": [12, 24, 60], "tolerancia": 0.05},
    "ftp": {"tolerancia_pb": 5.0},
    # curva_de: "cosecha" (supervivencia desde el origen) o "saldo_existente" (stock de cada corte), según el manual.
    "runoff": {"curva_de": "cosecha", "horizonte_estable_meses": 60, "plazos_meses": [1, 3, 6, 12, 24, 36, 60],
               "tolerancia_pp": 5.0, "tolerancia_pct": 10.0, "meses_backtesting": 12},
    "lcr": {"tope_entradas": 0.75, "tolerancia_pct": 1.0},
    "nsfr": {"tolerancia_pct": 1.0},
    "brechas_liquidez": {},
    "lar": {"horizonte_dias": 30, "nivel": 0.99, "tolerancia_pct": 5.0},
    "stress_liquidez": {},
    "concentracion_fondeo": {"top": [10, 20]},
}

_REPLICA = {
    "var": r'''
niv, ven, tol = SUPUESTOS["nivel_confianza"], int(SUPUESTOS["ventana_dias"]), SUPUESTOS["tolerancia_pct"]
t_var = tabla("var_reportado", ["fecha", "var"], ["cartera"])
t_esc = tabla("escenarios_pnl", ["fecha", "escenario", "pnl"], ["cartera"])
t_pyg = tabla("pyg", ["fecha", "pnl"], ["cartera"])
if t_esc is not None and t_var is not None:
    claves = ["fecha"] + (["cartera"] if "cartera" in t_esc and "cartera" in t_var else [])
    rep = t_esc.groupby(claves)["pnl"].apply(lambda s: var_historico(s, niv)).rename("var_replicado").reset_index()
    m = rep.merge(t_var.assign(var=t_var["var"].abs()), on=claves)
    m["dif_pct"] = (m["var_replicado"] - m["var"]).abs() / m["var"] * 100
    registrar("Replica_VaR_diaria", m, "VaR replicado desde el vector de escenarios")
    if len(m):
        REPLICA.append(comparar("VaR histórico desde el vector de escenarios (último día)", float(m["var"].iloc[-1]),
                                float(m["var_replicado"].iloc[-1]), tol, "escenarios_pnl",
                                nota=f"{(m['dif_pct'] <= tol).mean():.0%} de los días dentro de la tolerancia"))
elif t_pyg is not None and t_var is not None:
    s = t_pyg.dropna(subset=["fecha"]).groupby("fecha")["pnl"].sum().sort_index()
    bench = s.rolling(ven).apply(lambda x: var_historico(x, niv), raw=False).dropna()
    v = t_var.dropna(subset=["fecha"]).groupby("fecha")["var"].sum().abs()
    m = pd.DataFrame({"var_benchmark": bench}).join(v.rename("var"), how="inner")
    registrar("Benchmark_VaR", m.reset_index(), "VaR histórico con el P&L de la cartera (benchmark)")
    if len(m):
        REPLICA.append(comparar("VaR benchmark histórico con el P&L de la cartera (último día)", float(m["var"].iloc[-1]),
                                float(m["var_benchmark"].iloc[-1]), 25.0, "pyg",
                                nota="benchmark, no réplica exacta: tolerancia amplia"))
        REPLICA.append(comparar("VaR paramétrico normal con el P&L (último día)", float(m["var"].iloc[-1]),
                                var_parametrico(s.tail(ven), niv), 25.0, "pyg", nota="benchmark"))
    else:
        REPLICA.append({"paso": "VaR", "conclusion": f"No replicable: menos de {ven} días de P&L con VaR"})
else:
    REPLICA.append({"paso": "VaR", "conclusion": "No replicable: " + "; ".join(
        x for x in (falta("escenarios_pnl", ["fecha", "escenario", "pnl"]), falta("pyg", ["fecha", "pnl"]),
                    falta("var_reportado", ["fecha", "var"])) if x)})
t10 = tabla("var_reportado", ["var", "var_10d"])
if t10 is not None and len(t10.dropna()):
    REPLICA.append(comparar("Escalado a 10 días (VaR10 ÷ VaR1, mediana)", float((t10["var_10d"].abs() / t10["var"].abs()).median()),
                            math.sqrt(10), 2.0, "var_reportado", nota="√10 si el manual escala por la raíz del tiempo"))
if t_pyg is not None:
    s = t_pyg.dropna(subset=["fecha"]).groupby("fecha")["pnl"].sum().sort_index()
    for v_, n_ in ((250, 0.99), (500, 0.99), (250, 0.975)):
        if len(s) >= v_:
            SENSIBILIDAD.append({"metrica": f"VaR histórico P&L, ventana {v_}, nivel {n_:.1%}",
                                 "valor": var_historico(s.tail(v_), n_)})
''',
    "es_frtb": r'''
tol, niv = SUPUESTOS["tolerancia_pct"], SUPUESTOS["nivel_es"]
t_pyg = tabla("pyg", ["fecha", "pnl_hipotetico"], ["pnl_teorico", "cartera"])
t_es = tabla("es_reportado", ["fecha", "es"], ["cartera"])
if t_pyg is not None:
    hpl = t_pyg.sort_values("fecha")["pnl_hipotetico"].tail(int(SUPUESTOS["ventana_dias"]))
    es_b = es_historico(hpl, niv)
    if t_es is not None and len(t_es):
        REPLICA.append(comparar("ES 97,5 % benchmark con el HPL (sin horizontes de liquidez)",
                                float(t_es.sort_values("fecha")["es"].abs().iloc[-1]), es_b, 50.0, "pyg",
                                nota="benchmark: el ES regulatorio escala por horizontes de liquidez"))
    if "pnl_teorico" in t_pyg:
        rho, ks, zona = pla(t_pyg["pnl_hipotetico"], t_pyg["pnl_teorico"])
        REPLICA.append({"paso": "PLA (Spearman / KS)", "fuente": "pyg", "replicado": f"ρ={rho} · KS={ks}",
                        "conclusion": f"zona {zona}"})
else:
    REPLICA.append({"paso": "ES / PLA", "conclusion": "No replicable: " + falta("pyg", ["fecha", "pnl_hipotetico"])})
t_obs = tabla("observaciones", ["fecha", "factor"])
if t_obs is not None and len(t_obs):
    fin = t_obs["fecha"].max()
    cuenta = t_obs[t_obs["fecha"] > fin - pd.Timedelta(days=365)].groupby("factor")["fecha"].nunique()
    REPLICA.append({"paso": "RFET: factores con ≥ 24 observaciones en 12 meses", "fuente": "observaciones",
                    "replicado": f"{int((cuenta >= 24).sum())} de {len(cuenta)}",
                    "conclusion": "revisa también la regla de 4 observaciones cada 90 días (control D del 01)"})
''',
    "stress_mercado": r'''
tol = SUPUESTOS["tolerancia_pct"]
esc = tabla("escenarios", ["escenario", "factor", "retorno"])
pos = tabla("posiciones", ["factor", "sensibilidad"], ["cartera"])
res = tabla("resultados", ["escenario", "pnl"], ["cartera"])
if esc is not None and pos is not None:
    m = pos.merge(esc, on="factor", how="left")
    m["perdida"] = m["sensibilidad"] * m["retorno"]
    rep = m.groupby("escenario")["perdida"].sum()
    registrar("Replica_estres", rep.reset_index(), "Σ sensibilidad × choque por escenario")
    if res is not None:
        r = res.groupby("escenario")["pnl"].sum()
        for e, v in rep.items():
            REPLICA.append(comparar(f"Pérdida del escenario {e}", r.get(e), v, tol, "escenarios × posiciones"))
else:
    REPLICA.append({"paso": "Estrés", "conclusion": "No replicable: " + "; ".join(
        x for x in (falta("escenarios", ["escenario", "factor", "retorno"]), falta("posiciones", ["factor", "sensibilidad"])) if x)})
''',
    "valoracion": r'''
pre = tabla("precios", ["precio_modelo", "precio_independiente"], ["id_operacion", "nivel_jerarquia"])
if pre is not None and len(pre.dropna(subset=["precio_modelo", "precio_independiente"])):
    d = pre.dropna(subset=["precio_modelo", "precio_independiente"]).copy()
    d["dif_pct"] = (d["precio_modelo"] - d["precio_independiente"]).abs() / d["precio_independiente"].abs().replace(0, np.nan) * 100
    fuera = d[d["dif_pct"] > SUPUESTOS["tolerancia_ipv_pct"]]
    registrar("IPV_fuera_tolerancia", fuera, "operaciones con diferencia de IPV fuera de tolerancia")
    REPLICA.append({"paso": "IPV: operaciones fuera de tolerancia", "fuente": "precios",
                    "replicado": f"{len(fuera)} de {len(d)} ({len(fuera) / len(d):.1%})",
                    "conclusion": "Coincide" if not len(fuera) else "Difiere (revisa ajustes de valoración)"})
else:
    REPLICA.append({"paso": "IPV", "conclusion": "No replicable: " + falta("precios", ["precio_modelo", "precio_independiente"])})
''',
    "curvas": r'''
cur = tabla("curvas", ["tenor", "tasa", "factor_descuento"], ["fecha", "factor"])
if cur is not None and len(cur):
    d = cur.copy()
    d["t"] = d["tenor"].map(tenor_anios)
    esc = 100.0 if d["tasa"].abs().quantile(0.75) > 1 else 1.0
    d["df_rep"] = np.exp(-(d["tasa"] / esc) * d["t"])
    d["dif_pct"] = (d["df_rep"] - d["factor_descuento"]).abs() / d["factor_descuento"].abs() * 100
    ok = (d["dif_pct"] <= SUPUESTOS["tolerancia_pct"]).mean()
    registrar("Replica_curvas", d, "factor de descuento reconstruido desde la tasa cero")
    REPLICA.append({"paso": "Factor de descuento desde la tasa cero (e^(−r·t))", "fuente": "curvas",
                    "replicado": f"{ok:.1%} de los nodos dentro de ±{SUPUESTOS['tolerancia_pct']} %",
                    "conclusion": "Coincide" if ok >= 0.99 else "Difiere (revisa convención: continua, anual, base de días)"})
else:
    REPLICA.append({"paso": "Curvas", "conclusion": "No replicable: " + falta("curvas", ["tenor", "tasa", "factor_descuento"])})
''',
    "contraparte": r'''
op = tabla("operaciones", ["netting_set", "valor_mercado"])
co = tabla("colateral", ["netting_set", "colateral"])
ex = tabla("exposiciones", ["netting_set", "ead"])
if op is not None:
    v = op.groupby("netting_set")["valor_mercado"].sum()
    c = co.groupby("netting_set")["colateral"].sum() if co is not None else 0.0
    rc = (v - c).clip(lower=0) if co is not None else v.clip(lower=0)
    registrar("Costo_reposicion", rc.rename("rc").reset_index(), "RC = max(V − C, 0) por conjunto")
    if ex is not None:
        e = ex.groupby("netting_set")["ead"].sum()
        bajo = [k for k in rc.index if k in e.index and e[k] < SUPUESTOS["alfa_saccr"] * rc[k] - 1e-9]
        REPLICA.append({"paso": "EAD ≥ 1,4 × RC por conjunto", "fuente": "operaciones × colateral × exposiciones",
                        "replicado": f"{len(bajo)} conjunto(s) con EAD por debajo de 1,4·RC",
                        "conclusion": "Coincide" if not bajo else "Difiere: " + ", ".join(map(str, bajo[:5]))})
else:
    REPLICA.append({"paso": "Contraparte", "conclusion": "No replicable: " + falta("operaciones", ["netting_set", "valor_mercado"])})
''',
    "irrbb": r'''
pos = tabla("posiciones", ["saldo", "banda"], ["activo_pasivo", "moneda"])
res = tabla("resultados", ["escenario", "eve"], ["moneda", "nii"])
ch = float(SUPUESTOS["choque_paralelo"])
if pos is not None:
    filas = []
    for mon, g in (pos.groupby("moneda") if "moneda" in pos else [("TOTAL", pos)]):
        gap = gap_por_banda(g["saldo"], g["banda"], g["activo_pasivo"] if "activo_pasivo" in g else None)
        filas.append({"moneda": mon, "gap_total": float(gap.sum()),
                      "delta_eve_+": delta_eve_paralelo(gap, ch, SUPUESTOS["tasa_base"]),
                      "delta_eve_-": delta_eve_paralelo(gap, -ch, SUPUESTOS["tasa_base"]),
                      "delta_nii_+": delta_nii_paralelo(gap, ch), "delta_nii_-": delta_nii_paralelo(gap, -ch)})
        registrar(f"Gap_{mon}"[:31], gap.rename("gap").reset_index(), "gap de reprecio por banda")
    rep = pd.DataFrame(filas)
    registrar("Replica_IRRBB", rep, "ΔEVE y ΔNII con choque paralelo (aprox. por punto medio de banda)")
    if res is not None:
        canon = res["escenario"].astype(str).str.lower()
        arriba = res[canon.str.contains("paral") & canon.str.contains("arrib|subid|up|\\+")]
        if len(arriba):
            REPLICA.append(comparar("ΔEVE paralelo al alza (total)", float(arriba["eve"].sum()), float(rep["delta_eve_+"].sum()),
                                    SUPUESTOS["tolerancia_pct"], "posiciones", nota="aproximación por gap y punto medio"))
    if SUPUESTOS.get("tier1"):
        peor = -min(float(rep["delta_eve_+"].sum()), float(rep["delta_eve_-"].sum()), 0.0)
        REPLICA.append({"paso": "SOT: peor ΔEVE ÷ Tier 1", "replicado": peor / float(SUPUESTOS["tier1"]),
                        "conclusion": "por debajo del 15 %" if peor / float(SUPUESTOS["tier1"]) < 0.15 else "SUPERA el 15 %"})
else:
    REPLICA.append({"paso": "Gap / ΔEVE / ΔNII", "conclusion": "No replicable: " + falta("posiciones", ["saldo", "banda"])})
''',
    "prepago": r'''
sal = tabla("saldos", ["saldo_inicial", "prepago"], ["fecha", "segmento", "amortizacion", "cpr"])
mod = tabla("modelo", ["cpr"], ["segmento"])
if sal is not None:
    smm, cpr = smm_cpr(sal["saldo_inicial"], sal["amortizacion"] if "amortizacion" in sal else 0.0, sal["prepago"])
    sal = sal.assign(smm_rep=smm.values, cpr_rep=cpr.values)
    por = sal.groupby("segmento")[["smm_rep", "cpr_rep"]].mean() if "segmento" in sal else sal[["smm_rep", "cpr_rep"]].mean().to_frame("TOTAL").T
    registrar("Replica_CPR", por.reset_index(), "SMM y CPR observados por segmento")
    if "cpr" in sal:
        esc = 100.0 if sal["cpr"].dropna().quantile(0.75) > 1 else 1.0
        REPLICA.append(comparar("CPR reportado vs recalculado (media)", float(sal["cpr"].mean() / esc), float(sal["cpr_rep"].mean()),
                                5.0, "saldos"))
    if mod is not None and "segmento" in mod and "segmento" in sal:
        esc = 100.0 if mod["cpr"].dropna().quantile(0.75) > 1 else 1.0
        for seg, v in mod.groupby("segmento")["cpr"].mean().items():
            if seg in por.index:
                REPLICA.append(comparar(f"CPR del modelo vs observado · {seg}", float(v / esc), float(por.loc[seg, "cpr_rep"]),
                                        10.0, "modelo × saldos"))
else:
    REPLICA.append({"paso": "SMM / CPR", "conclusion": "No replicable: " + falta("saldos", ["saldo_inicial", "prepago"])})
''',
    "nmd": r'''
sal = tabla("saldos", ["fecha", "saldo"], ["segmento", "tasa_pagada", "tasa_mercado"])
mod = tabla("modelo", ["segmento"], ["core", "vida_media", "beta"])
if sal is not None:
    filas = []
    for seg, g in (sal.groupby("segmento") if "segmento" in sal else [("TOTAL", sal)]):
        serie = g.groupby("fecha")["saldo"].sum().sort_index()
        lam, vida, r2 = decaimiento(serie.index, serie.values)
        b = None
        if "tasa_pagada" in g and "tasa_mercado" in g:
            t = g.groupby("fecha")[["tasa_pagada", "tasa_mercado"]].mean().sort_index()
            b = beta_traspaso(t["tasa_pagada"], t["tasa_mercado"])
        filas.append({"segmento": seg, "core_min_sobre_media": float(serie.min() / serie.mean()) if serie.mean() else None,
                      "lambda_anual": lam, "vida_media_anios": vida, "r2": r2, "beta": b})
    rep = pd.DataFrame(filas)
    registrar("Replica_NMD", rep, "núcleo, decaimiento y beta por segmento")
    if mod is not None:
        m = mod.merge(rep, on="segmento", how="inner")
        for _, r in m.iterrows():
            if "core" in m and pd.notna(r.get("core")):
                esc = 100.0 if m["core"].quantile(0.75) > 1 else 1.0
                REPLICA.append(comparar(f"Núcleo · {r['segmento']}", float(r["core"]) / esc, r["core_min_sobre_media"],
                                        SUPUESTOS["tolerancia_pct"], "saldos", nota="núcleo replicado = mínimo ÷ promedio"))
            if "vida_media" in m and pd.notna(r.get("vida_media")):
                REPLICA.append(comparar(f"Vida media · {r['segmento']}", float(r["vida_media"]), r["vida_media_anios"],
                                        SUPUESTOS["tolerancia_pct"], "saldos", nota="vida media replicada ≈ 1/λ (años)"))
        if "beta" in mod:
            for _, r in mod.merge(rep[["segmento", "beta"]].rename(columns={"beta": "beta_rep"}), on="segmento").iterrows():
                REPLICA.append(comparar(f"Beta · {r['segmento']}", r["beta"], r["beta_rep"], SUPUESTOS["tolerancia_pct"],
                                        "saldos", nota="beta replicado = pendiente de Δtasa pagada sobre Δtasa de mercado"))
else:
    REPLICA.append({"paso": "Núcleo / decaimiento / beta", "conclusion": "No replicable: " + falta("saldos", ["fecha", "saldo"])})
''',
    "cancelacion_dpf": r'''
dep = tabla("depositos", ["fecha_inicio", "fecha_vencimiento", "saldo"], ["fecha_cierre", "segmento"])
if dep is not None and "fecha_cierre" in dep:
    meses = pd.period_range(dep["fecha_inicio"].min(), dep["fecha_cierre"].max() if dep["fecha_cierre"].notna().any()
                            else dep["fecha_vencimiento"].max(), freq="M")
    filas = []
    for m in meses:
        i0, i1 = m.start_time, m.end_time
        vivo = (dep["fecha_inicio"] < i0) & (dep["fecha_cierre"].isna() | (dep["fecha_cierre"] >= i0)) & (dep["fecha_vencimiento"] >= i0)
        base = float(dep.loc[vivo, "saldo"].sum())
        if base > 0:
            canc = vivo & dep["fecha_cierre"].between(i0, i1) & (dep["fecha_cierre"] < dep["fecha_vencimiento"])
            filas.append({"mes": str(m), "tasa_cancelacion": float(dep.loc[canc, "saldo"].sum()) / base})
    rep = pd.DataFrame(filas)
    registrar("Replica_cancelacion", rep, "tasa mensual de cancelación anticipada")
    tas = tabla("tasas", ["tasa_salida"])
    if tas is not None and len(rep):
        esc = 100.0 if tas["tasa_salida"].quantile(0.75) > 1 else 1.0
        REPLICA.append(comparar("Tasa de cancelación del modelo vs observada (media)", float(tas["tasa_salida"].mean() / esc),
                                float(rep["tasa_cancelacion"].mean()), 10.0, "depositos"))
else:
    REPLICA.append({"paso": "Cancelación anticipada", "conclusion": "No replicable: " + falta("depositos", ["fecha_inicio", "fecha_vencimiento", "saldo", "fecha_cierre"])})
''',
    "supervivencia": r'''
cu = tabla("cuentas", ["fecha_inicio"], ["fecha_cierre", "segmento"])
crv = tabla("curva", ["plazo_meses", "supervivencia"], ["segmento"])
if cu is not None and "fecha_cierre" in cu:
    corte = max(cu["fecha_inicio"].max(), cu["fecha_cierre"].max())
    ev = cu["fecha_cierre"].notna() & (cu["fecha_cierre"] <= corte)
    dur = (cu["fecha_cierre"].where(ev, corte) - cu["fecha_inicio"]).dt.days / 30.4375
    km = kaplan_meier(dur, ev.astype(int))
    registrar("Kaplan_Meier", km, "supervivencia observada (meses)")
    for m in SUPUESTOS["plazos_meses"]:
        s_obs = float(km.loc[km["t"] <= m, "S"].iloc[-1])
        s_mod = float(np.interp(m, crv.sort_values("plazo_meses")["plazo_meses"], crv.sort_values("plazo_meses")["supervivencia"] /
                                (100.0 if crv["supervivencia"].quantile(0.75) > 1 else 1.0))) if crv is not None else None
        REPLICA.append(comparar(f"S({m} meses) modelo vs Kaplan–Meier", s_mod, s_obs, 100 * SUPUESTOS["tolerancia"], "cuentas"))
else:
    REPLICA.append({"paso": "Kaplan–Meier", "conclusion": "No replicable: " + falta("cuentas", ["fecha_inicio", "fecha_cierre"])})
''',
    "ftp": r'''
op = tabla("operaciones", ["plazo_meses", "tasa_ftp"], ["moneda"])
cv = tabla("curva_ftp", ["tenor", "tasa_ftp"], ["fecha", "moneda"])
if op is not None and cv is not None:
    if "fecha" in cv:
        cv = cv[cv["fecha"] == cv["fecha"].max()]
    cv = cv.assign(meses=cv["tenor"].map(tenor_anios) * 12)
    filas = []
    for mon, g in (op.groupby("moneda") if "moneda" in op and "moneda" in cv else [("TOTAL", op)]):
        c = (cv[cv["moneda"] == mon] if "moneda" in cv and mon != "TOTAL" else cv).sort_values("meses")
        if len(c) < 2:
            continue
        interp = np.interp(g["plazo_meses"], c["meses"], c["tasa_ftp"])
        dif_pb = (g["tasa_ftp"] - interp).abs() * (100 if c["tasa_ftp"].abs().quantile(0.75) > 1 else 10000)
        filas.append({"moneda": mon, "operaciones": len(g), "dif_media_pb": float(dif_pb.mean()),
                      "fuera_tolerancia": int((dif_pb > SUPUESTOS["tolerancia_pb"]).sum())})
    registrar("Replica_FTP", filas or [{"aviso": "sin curva por moneda"}], "FTP asignado vs curva interpolada")
    if not filas:
        REPLICA.append({"paso": "FTP", "conclusion": "No replicable: la curva FTP del último corte tiene menos de "
                                                    "2 nodos por moneda (o la moneda no coincide)"})
    for f in filas:
        REPLICA.append({"paso": f"FTP asignado vs curva · {f['moneda']}", "replicado": f"{f['fuera_tolerancia']} de {f['operaciones']} fuera de ±{SUPUESTOS['tolerancia_pb']} pb",
                        "conclusion": "Coincide" if not f["fuera_tolerancia"] else "Difiere"})
else:
    REPLICA.append({"paso": "FTP", "conclusion": "No replicable: " + "; ".join(
        x for x in (falta("operaciones", ["plazo_meses", "tasa_ftp"]), falta("curva_ftp", ["tenor", "tasa_ftp"])) if x)})
''',
    "runoff": r'''
# SUPUESTOS (del manual): curva_de = "cosecha" (supervivencia desde el origen, link ratios) o "saldo_existente"
# (run-off del stock de cada corte, sin negocio nuevo); horizonte_estable_meses = plazo al que se mide el
# componente estable; tolerancia_pp para S y proporciones; tolerancia_pct para el plazo económico.
sal = tabla("saldos", ["fecha", "saldo"], ["segmento", "cosecha", "edad"])
crv = tabla("curva", ["plazo_meses"], ["segmento", "supervivencia", "runoff_acumulado", "runoff_incremental"])
comp = tabla("componentes", ["segmento"], ["core", "volatil", "vida_media"])
ban = tabla("bandas", ["banda", "proporcion"], ["segmento"])
P, tol_pp = [float(x) for x in SUPUESTOS["plazos_meses"]], float(SUPUESTOS["tolerancia_pp"])
h_est, curva_de = float(SUPUESTOS["horizonte_estable_meses"]), str(SUPUESTOS["curva_de"])


def _de(curvas, seg):
    """Curva del segmento (o la única, si el otro lado no está segmentado)."""
    return curvas.get(seg) if seg in curvas else (next(iter(curvas.values())) if len(curvas) == 1 else None)


# 02.4 · La curva del modelo es coherente: S no sube, R = 1 − S, d = S(t−1) − S(t) ≥ 0.
modelo = curvas_del_modelo(crv) if crv is not None else {}
if crv is None:
    REPLICA.append({"paso": "Curva del modelo", "conclusion": "No replicable: " + falta("curva", ["plazo_meses"])})
for seg, cm in modelo.items():
    g = (crv[crv["segmento"] == seg] if "segmento" in crv else crv).groupby("plazo_meses").mean(numeric_only=True)
    g = g.reindex(cm["t"].to_numpy())
    ref = next((g[c] for c in ("supervivencia", "runoff_acumulado") if c in g and g[c].notna().any()), None)
    if ref is not None:
        f = 100.0 if ref.dropna().quantile(0.75) > 1 else 1.0
    else:
        dd0 = g["runoff_incremental"].dropna()
        f = 100.0 if (len(dd0) and (dd0.max() > 1 or dd0.sum() > 1.5)) else 1.0
    prob = []
    sube = np.diff(cm["S"].to_numpy()) > 0.0005
    if sube.any():
        k = int(np.argmax(sube))
        prob.append(f"S sube entre {cm['t'].iloc[k]:g} y {cm['t'].iloc[k + 1]:g} meses")
    if {"runoff_acumulado", "supervivencia"} <= set(g.columns) and \
            (abs(g["runoff_acumulado"].to_numpy() / f - cm["R"].to_numpy()) > 0.005).any():
        prob.append("R ≠ 1 − S")
    if "runoff_incremental" in g and g["runoff_incremental"].notna().any():
        dd = g["runoff_incremental"].to_numpy() / f
        if (dd < -0.0005).any():
            prob.append("desgaste incremental negativo")
        if (abs(dd - cm["d"].to_numpy()) > 0.005).any():
            prob.append("d(t) ≠ S(t−1) − S(t)")
    REPLICA.append({"paso": f"Curva del modelo coherente (S no sube, R = 1 − S, d = S(t−1) − S(t) ≥ 0) · {seg}",
                    "fuente": "curva", "implementador": None, "replicado": "; ".join(prob) or "coherente",
                    "conclusion": ("Difiere: " + "; ".join(prob)) if prob else "Coincide"})

# 02.5 · Réplica de la curva con la experiencia histórica (cosechas o saldo existente).
curvas, rep = {}, pd.DataFrame(columns=["segmento"])
if sal is None:
    REPLICA.append({"paso": "Curva de supervivencia del saldo", "conclusion": "No replicable: " + falta("saldos", ["fecha", "saldo"])})
else:
    curvas, rep = replicar_runoff(sal, h_est, curva_de)
    if "cosecha" not in sal:
        REPLICA.append({"paso": "Aislar el saldo existente del negocio nuevo", "fuente": "saldos", "implementador": None,
                        "replicado": "sin cosechas",
                        "conclusion": "No replicable: sin cosechas la historia mezcla el negocio nuevo; la curva "
                                      "exponencial del saldo total es solo un benchmark"})
    if not len(rep):
        REPLICA.append({"paso": "Curva de supervivencia del saldo",
                        "conclusion": "No replicable: la historia no alcanza para construir la curva"})
    else:
        registrar("Replica_curva", pd.concat([c.assign(segmento=s) for s, c in curvas.items()], ignore_index=True),
                  f"curva replicada ({rep['metodo'].iloc[0]}): S, R y d por plazo y segmento")
        registrar("Replica_componentes", rep, f"estable = S a {h_est:g} meses (o al último plazo observado), "
                                              "volátil = 1 − estable, plazo económico = ∫ S(t) dt")
        for seg, cm in modelo.items():
            rc = _de(curvas, seg)
            if rc is None:
                REPLICA.append({"paso": f"Curva · {seg}", "conclusion": "No replicable: el segmento no tiene historia"})
                continue
            for p in P:
                if p <= min(float(rc["t"].max()), float(cm["t"].max())):
                    REPLICA.append(comparar_pp(f"S({p:g} meses) modelo vs histórico · {seg}",
                                               float(np.interp(p, cm["t"], cm["S"])),
                                               float(np.interp(p, rc["t"], rc["S"])), tol_pp, "curva × saldos"))

# 02.6 · Componentes estable / volátil y plazo económico.
if comp is not None:
    f_c = 100.0 if ("core" in comp and comp["core"].dropna().quantile(0.75) > 1) else 1.0
    f_v = 100.0 if ("volatil" in comp and comp["volatil"].dropna().quantile(0.75) > 1) else 1.0
    for _, r in comp.iterrows():
        seg = r["segmento"]
        fr = rep[rep["segmento"] == seg] if seg in set(rep["segmento"]) else (rep if len(rep) == 1 else rep.iloc[0:0])
        cm = _de(modelo, seg)
        if "core" in comp and pd.notna(r.get("core")):
            if len(fr):
                REPLICA.append(comparar_pp(f"Componente estable · {seg}", float(r["core"]) / f_c, float(fr["estable"].iloc[0]),
                                           tol_pp, "componentes × saldos",
                                           nota=f"histórico = S a {fr['horizonte_estable_meses'].iloc[0]:g} meses"))
            if "volatil" in comp and pd.notna(r.get("volatil")):
                REPLICA.append(comparar_pp(f"Estable + volátil = 100 % · {seg}", 1.0,
                                           float(r["core"]) / f_c + float(r["volatil"]) / f_v, 0.5, "componentes"))
        if "vida_media" in comp and pd.notna(r.get("vida_media")):
            vm = float(r["vida_media"]) / (12.0 if comp["vida_media"].dropna().quantile(0.75) > 15 else 1.0)
            h_pe = float(cm["t"].max()) if cm is not None else None
            if cm is not None:
                REPLICA.append(comparar(f"Plazo económico vs ∫S de la curva del modelo · {seg}", vm,
                                        plazo_economico(cm["t"], cm["S"]), SUPUESTOS["tolerancia_pct"],
                                        "componentes × curva", nota=f"hasta {h_pe:g} meses"))
            rc = _de(curvas, seg)
            if rc is not None:
                REPLICA.append(comparar(f"Plazo económico vs ∫S de la curva histórica · {seg}", vm,
                                        plazo_economico(rc["t"], rc["S"], h_pe), SUPUESTOS["tolerancia_pct"],
                                        "componentes × saldos",
                                        nota=f"al mismo horizonte ({(h_pe or float(rc['t'].max())):g} meses; más allá "
                                             "de lo observado se prolonga el estable)"))

# Asignación a bandas: suma 100 % y sale de la curva (la del modelo y la histórica).
if ban is not None:
    f_b = 100.0 if ban["proporcion"].dropna().quantile(0.75) > 1 else 1.0
    tabla_b = []
    for seg, g in (ban.groupby("segmento") if "segmento" in ban else [("TOTAL", ban)]):
        mb = g.groupby("banda")["proporcion"].sum() / f_b
        REPLICA.append(comparar_pp(f"Asignación a bandas suma 100 % · {seg}", 1.0, float(mb.sum()), 0.5, "bandas"))
        fila_seg = {b_: {"segmento": seg, "banda": b_, "modelo": float(v)} for b_, v in mb.items()}
        for nombre, c, tol_b in (("curva del modelo", _de(modelo, seg), 0.5), ("curva histórica", _de(curvas, seg), tol_pp)):
            if c is None:
                continue
            asig = asignar_bandas(c["t"], c["S"], list(mb.index)).set_index("banda")["proporcion"]
            comunes = [b_ for b_ in mb.index if b_ in asig.index]
            if not comunes:
                REPLICA.append({"paso": f"Bandas · {seg}", "conclusion": "No replicable: no se reconocen los plazos de las "
                                                                       "bandas (p. ej. «1-3M», «1-2A», «>5A»)"})
                break
            for b_ in comunes:
                fila_seg[b_]["desde_" + nombre.replace(" ", "_")] = float(asig[b_])
            peor = max(comunes, key=lambda b_: abs(mb[b_] - asig[b_]))
            REPLICA.append(comparar_pp(f"Bandas vs la {nombre} · {seg} (peor banda: {peor})", float(mb[peor]),
                                       float(asig[peor]), tol_b, "bandas × " + ("curva" if "modelo" in nombre else "saldos")))
        tabla_b += list(fila_seg.values())
    registrar("Replica_bandas", tabla_b or [{"aviso": "sin bandas"}],
              "proporción del saldo por banda: la del modelo, la que sale de su curva y la que sale de la historia")
''',
    "lcr": r'''
hq = tabla("hqla", ["nivel_hqla", "valor_mercado"], ["fecha", "haircut"])
sa = tabla("salidas", ["saldo", "tasa_salida"], ["fecha"])
en = tabla("entradas", ["saldo", "tasa_entrada"], ["fecha"])
ra = tabla("ratio", ["lcr"], ["fecha"])
if hq is not None and sa is not None:
    def _ult(t):
        return t[t["fecha"] == t["fecha"].max()] if "fecha" in t else t
    h = _ult(hq).copy()
    hc = h["haircut"] / (100.0 if "haircut" in h and h["haircut"].quantile(0.75) > 1 else 1.0) if "haircut" in h else 0.0
    h["post"] = h["valor_mercado"] * (1 - hc)
    niv = h["nivel_hqla"].astype(str).str.upper().str.replace(" ", "")
    n1 = float(h.loc[niv.str.contains("1"), "post"].sum())
    n2b = float(h.loc[niv.str.contains("2B"), "post"].sum())
    n2a = float(h.loc[niv.str.contains("2") & ~niv.str.contains("2B"), "post"].sum())
    hqla_aj = hqla_ajustado(n1, n2a, n2b)
    s_, e_ = _ult(sa), (_ult(en) if en is not None else None)
    esc_s = 100.0 if s_["tasa_salida"].quantile(0.75) > 1 else 1.0
    salidas_p = float((s_["saldo"] * s_["tasa_salida"] / esc_s).sum())
    entradas_p = float((e_["saldo"] * e_["tasa_entrada"] / (100.0 if e_["tasa_entrada"].quantile(0.75) > 1 else 1.0)).sum()) if e_ is not None else 0.0
    ratio = lcr(hqla_aj, salidas_p, entradas_p, SUPUESTOS["tope_entradas"])
    registrar("Replica_LCR", [{"n1": n1, "n2a": n2a, "n2b": n2b, "hqla_ajustado": hqla_aj, "salidas": salidas_p,
                               "entradas": entradas_p, "lcr": ratio}], "LCR con descuentos, topes y tope de entradas")
    if ra is not None and len(ra):
        rep_ = float((ra.sort_values("fecha") if "fecha" in ra else ra)["lcr"].iloc[-1])
        REPLICA.append(comparar("LCR (último corte)", rep_ / (100.0 if rep_ > 20 else 1.0), ratio, SUPUESTOS["tolerancia_pct"], "hqla × salidas × entradas"))
else:
    REPLICA.append({"paso": "LCR", "conclusion": "No replicable: " + "; ".join(
        x for x in (falta("hqla", ["nivel_hqla", "valor_mercado"]), falta("salidas", ["saldo", "tasa_salida"])) if x)})
''',
    "nsfr": r'''
a = tabla("asf", ["saldo", "factor_asf"], ["fecha"])
r = tabla("rsf", ["saldo", "factor_rsf"], ["fecha"])
ra = tabla("ratio", ["nsfr"], ["fecha"])
if a is not None and r is not None:
    a = a[a["fecha"] == a["fecha"].max()] if "fecha" in a else a
    r = r[r["fecha"] == r["fecha"].max()] if "fecha" in r else r
    fa = a["factor_asf"] / (100.0 if a["factor_asf"].quantile(0.75) > 1 else 1.0)
    fr = r["factor_rsf"] / (100.0 if r["factor_rsf"].quantile(0.75) > 1 else 1.0)
    asf_, rsf_, ratio = nsfr(a["saldo"], fa, r["saldo"], fr)
    registrar("Replica_NSFR", [{"asf": asf_, "rsf": rsf_, "nsfr": ratio}], "ASF ÷ RSF")
    if ra is not None and len(ra):
        v = float((ra.sort_values("fecha") if "fecha" in ra else ra)["nsfr"].iloc[-1])
        REPLICA.append(comparar("NSFR (último corte)", v / (100.0 if v > 20 else 1.0), ratio, SUPUESTOS["tolerancia_pct"], "asf × rsf"))
else:
    REPLICA.append({"paso": "NSFR", "conclusion": "No replicable: " + "; ".join(
        x for x in (falta("asf", ["saldo", "factor_asf"]), falta("rsf", ["saldo", "factor_rsf"])) if x)})
''',
    "brechas_liquidez": r'''
fl = tabla("flujos", ["banda"], ["entradas", "salidas", "moneda"])
if fl is not None and ("entradas" in fl or "salidas" in fl):
    for mon, g in (fl.groupby("moneda") if "moneda" in fl else [("TOTAL", fl)]):
        b = brechas(g["entradas"] if "entradas" in g else 0, g["salidas"] if "salidas" in g else 0, g["banda"])
        registrar(f"Brechas_{mon}"[:31], b, "brecha por banda y acumulada")
        neg = b[b["acumulada"] < 0]
        REPLICA.append({"paso": f"Brecha acumulada · {mon}", "fuente": "flujos",
                        "replicado": f"mínima {b['acumulada'].min():,.0f}",
                        "conclusion": ("sin brechas acumuladas negativas" if neg.empty else
                                       f"negativa desde la banda {neg['banda'].iloc[0]}")})
else:
    REPLICA.append({"paso": "Brechas", "conclusion": "No replicable: " + falta("flujos", ["banda", "entradas", "salidas"])})
''',
    "lar": r'''
fl = tabla("flujos", ["fecha"], ["flujo_neto", "entradas", "salidas"])
re_ = tabla("resultado", ["lar_valor"], ["fecha"])
if fl is not None and ("flujo_neto" in fl or ("entradas" in fl and "salidas" in fl)):
    neto = fl["flujo_neto"] if "flujo_neto" in fl else fl["entradas"] - fl["salidas"]
    v = lar_hist(fl["fecha"], neto, SUPUESTOS["horizonte_dias"], SUPUESTOS["nivel"])
    for h_ in (10, 30, 90):
        SENSIBILIDAD.append({"metrica": f"LaR a {h_} días al {SUPUESTOS['nivel']:.0%}", "valor": lar_hist(fl["fecha"], neto, h_, SUPUESTOS["nivel"])})
    if re_ is not None and len(re_):
        REPLICA.append(comparar("LaR (último)", float((re_.sort_values("fecha") if "fecha" in re_ else re_)["lar_valor"].abs().iloc[-1]),
                                v, SUPUESTOS["tolerancia_pct"], "flujos"))
    else:
        REPLICA.append({"paso": "LaR", "replicado": v, "conclusion": "sin LaR reportado para comparar"})
else:
    REPLICA.append({"paso": "LaR", "conclusion": "No replicable: " + falta("flujos", ["fecha", "flujo_neto"])})
''',
    "stress_liquidez": r'''
pr = tabla("proyeccion", ["escenario", "salidas"], ["dias", "entradas", "hqla"])
if pr is not None:
    filas = []
    for esc_, g in pr.groupby("escenario"):
        g = g.sort_values("dias") if "dias" in g else g
        neto = g["salidas"] - (g["entradas"] if "entradas" in g else 0)
        colchon = float(g["hqla"].iloc[0]) if "hqla" in g else None
        filas.append({"escenario": esc_, "dias_proyectados": len(g), "colchon": colchon,
                      "horizonte_supervivencia": horizonte_supervivencia(neto, colchon) if colchon is not None else None})
    registrar("Replica_supervivencia", filas, "primer día en que las salidas netas acumuladas superan el colchón")
    for f in filas:
        REPLICA.append({"paso": f"Horizonte de supervivencia · {f['escenario']}", "replicado": f["horizonte_supervivencia"] or "más allá del horizonte",
                        "conclusion": "compara con el reportado y con el apetito de riesgo"})
else:
    REPLICA.append({"paso": "Supervivencia", "conclusion": "No replicable: " + falta("proyeccion", ["escenario", "salidas"])})
''',
    "concentracion_fondeo": r'''
dp = tabla("depositantes", ["contraparte", "saldo"], ["fecha", "grupo_economico"])
if dp is not None:
    d = dp[dp["fecha"] == dp["fecha"].max()] if "fecha" in dp else dp
    c1 = concentracion(d["saldo"], d["contraparte"], tuple(SUPUESTOS["top"]))
    filas = [{"agrupacion": "depositante", **c1}]
    if "grupo_economico" in d:
        filas.append({"agrupacion": "grupo económico", **concentracion(d["saldo"], d["grupo_economico"].fillna(d["contraparte"]), tuple(SUPUESTOS["top"]))})
    registrar("Replica_concentracion", filas, "top-N y HHI en el último corte")
    for f in filas:
        REPLICA.append({"paso": f"Concentración por {f['agrupacion']}", "replicado": f"top 10 {f.get('top_10', 0):.1f} % · HHI {f.get('hhi', 0):.0f}",
                        "conclusion": "compara con el límite de concentración"})
else:
    REPLICA.append({"paso": "Concentración", "conclusion": "No replicable: " + falta("depositantes", ["contraparte", "saldo"])})
''',
}

# ── 03 · Impactos ───────────────────────────────────────────────────────────

#: Métrica principal por tipo (la que mueve un hallazgo). Devuelve un número.
_METRICA = {
    "var": 'lambda: var_historico(tabla("pyg", ["pnl"])["pnl"].tail(int(SUPUESTOS.get("ventana_dias", 250))), 0.99)',
    "es_frtb": 'lambda: es_historico(tabla("pyg", ["pnl_hipotetico"])["pnl_hipotetico"].tail(250), 0.975)',
    "stress_mercado": 'lambda: float(tabla("resultados", ["pnl"])["pnl"].min())',
    "valoracion": 'lambda: float(tabla("precios", ["precio_modelo"])["precio_modelo"].sum())',
    "curvas": 'lambda: float(tabla("curvas", ["tasa"])["tasa"].mean())',
    "contraparte": 'lambda: float(tabla("exposiciones", ["ead"])["ead"].sum())',
    "irrbb": ('lambda: delta_eve_paralelo(gap_por_banda(tabla("posiciones", ["saldo", "banda"], ["activo_pasivo"])["saldo"], '
              'tabla("posiciones", ["saldo", "banda"])["banda"], tabla("posiciones", ["saldo", "banda"], ["activo_pasivo"]).get("activo_pasivo")), 0.02)'),
    "prepago": ('lambda: float(smm_cpr(tabla("saldos", ["saldo_inicial", "prepago"])["saldo_inicial"], '
                'tabla("saldos", ["saldo_inicial", "prepago"], ["amortizacion"]).get("amortizacion", 0.0), '
                'tabla("saldos", ["saldo_inicial", "prepago"])["prepago"])[1].mean())'),
    "nmd": 'lambda: (lambda t: decaimiento(t["fecha"], t["saldo"])[1])(tabla("saldos", ["fecha", "saldo"]))',
    "cancelacion_dpf": 'lambda: float(tabla("depositos", ["saldo"])["saldo"].sum())',
    "supervivencia": 'lambda: float(len(tabla("cuentas", ["fecha_inicio"])))',
    "ftp": 'lambda: float(tabla("operaciones", ["tasa_ftp"])["tasa_ftp"].mean())',
    # Componente estable replicado, ponderado por el saldo del último corte de cada segmento.
    "runoff": ('lambda: (lambda r: float((r["estable"] * r["saldo_ultimo"]).sum() / r["saldo_ultimo"].sum()) '
               'if len(r) and r["saldo_ultimo"].sum() else None)(replicar_runoff(tabla("saldos", ["fecha", "saldo"], '
               '["segmento", "cosecha", "edad"]), SUPUESTOS.get("horizonte_estable_meses", 60), '
               'SUPUESTOS.get("curva_de", "cosecha"))[1])'),
    "lcr": 'lambda: float(tabla("ratio", ["lcr"])["lcr"].iloc[-1])',
    "nsfr": 'lambda: float(tabla("ratio", ["nsfr"])["nsfr"].iloc[-1])',
    "brechas_liquidez": 'lambda: float(brechas(tabla("flujos", ["banda", "entradas", "salidas"])["entradas"], tabla("flujos", ["banda", "entradas", "salidas"])["salidas"], tabla("flujos", ["banda"])["banda"])["acumulada"].min())',
    "lar": 'lambda: lar_hist(tabla("flujos", ["fecha", "flujo_neto"])["fecha"], tabla("flujos", ["fecha", "flujo_neto"])["flujo_neto"], 30, 0.99)',
    "stress_liquidez": 'lambda: float(tabla("proyeccion", ["salidas"])["salidas"].sum())',
    "concentracion_fondeo": 'lambda: concentracion(tabla("depositantes", ["contraparte", "saldo"])["saldo"], tabla("depositantes", ["contraparte", "saldo"])["contraparte"]).get("top_10")',
}

_C03_AYUDAS = r'''
import copy as _copy


def con_bases(nuevas, funcion):
    """Calcula `funcion()` con otras bases (las corregidas) sin tocar las originales."""
    global bases
    viejas = bases
    bases = nuevas
    try:
        return funcion()
    finally:
        bases = viejas


def copia():
    return {k: v.copy() for k, v in bases.items()}


def quitar_nulos(b, base, rol):
    ds, c = BASES.get(base), (ROLES.get(BASES.get(base)) or {}).get(rol)
    b[ds] = b[ds][b[ds][c].notna()]
    return b


def quitar_duplicados(b, base, roles):
    ds = BASES.get(base)
    cols = [(ROLES.get(ds) or {}).get(r) for r in roles]
    b[ds] = b[ds].drop_duplicates(subset=[c for c in cols if c])
    return b


def excluir(b, base, condicion):
    """Quita las filas que cumplen la condición (texto de pandas: df.query)."""
    ds = BASES.get(base)
    b[ds] = b[ds].drop(b[ds].query(condicion).index)
    return b


def escalar(b, base, rol, factor):
    ds, c = BASES.get(base), (ROLES.get(BASES.get(base)) or {}).get(rol)
    b[ds] = b[ds].assign(**{c: pd.to_numeric(b[ds][c], errors="coerce") * factor})
    return b


# Por base real y columnas (las que salen en el Excel del 01):
def quitar_nulos_col(b, ds, cols):
    b[ds] = b[ds].dropna(subset=[c for c in cols if c in b[ds].columns])
    return b


def quitar_duplicados_cols(b, ds, cols):
    b[ds] = b[ds].drop_duplicates(subset=[c for c in cols if c in b[ds].columns] or None)
    return b


def excluir_si(b, ds, condicion):
    """Quita las filas donde `condicion(df)` (serie booleana) es True."""
    m = pd.Series(condicion(b[ds]), index=b[ds].index).fillna(False).astype(bool)
    b[ds] = b[ds][~m]
    return b


def _saltos_robustos(dif, grupo, k):
    malos = []
    for _g, x in dif.groupby(grupo):
        x = x.dropna()
        if len(x) < 5:
            continue
        med = x.median()
        esc = float((x - med).abs().median()) * 1.4826 or float((x - med).abs().mean()) * 1.2533
        if esc > 0:
            malos += list(x[(x - med).abs() / esc > k].index)
    return malos


def excluir_saltos(b, ds, valor, orden, grupo=None, k=8.0, agregar=""):
    """Sensibilidad: quita las observaciones con un salto de más de k desviaciones robustas, dentro de cada
    grupo (una columna o una lista, p. ej. ["segmento", "cosecha"]). Con agregar="suma" el salto se mide en el
    total por grupo y fecha (p. ej. el saldo del segmento sumando sus cosechas) y se quitan todas las filas de
    esa fecha: así la migración sale de la curva sin tocar el resto de la historia."""
    d = b[ds].copy()
    grupos = [g for g in ([grupo] if isinstance(grupo, str) else list(grupo or [])) if g in d.columns]
    d["_o"] = a_fecha(d[orden]) if not pd.api.types.is_numeric_dtype(d[orden]) else d[orden]
    d["_g"] = d[grupos].astype(str).agg("|".join, axis=1) if grupos else "_"
    d = d.sort_values(["_g", "_o"])
    v = pd.to_numeric(d[valor], errors="coerce")
    if str(agregar or "").lower() == "suma":
        tot = v.groupby([d["_g"], d["_o"]]).sum().rename("_v").reset_index()
        malos_t = _saltos_robustos(tot.groupby("_g")["_v"].diff(), tot["_g"], k)
        claves = set(zip(tot.loc[malos_t, "_g"], tot.loc[malos_t, "_o"]))
        malos = list(d.index[[(g, o) in claves for g, o in zip(d["_g"], d["_o"])]])
    else:
        malos = _saltos_robustos(v.groupby(d["_g"]).diff(), d["_g"], k)
    b[ds] = b[ds].drop(index=[i for i in malos if i in b[ds].index])
    return b
'''

_C03_CALCULO = r'''
IMPACTOS = []


def _medir(f):
    try:
        v = f()
        return float(v) if v is not None else None, ""
    except Exception as exc:
        return None, f"{type(exc).__name__}: {exc}"


for tipo_m, f_metrica in METRICAS.items():
    base_v, err = _medir(f_metrica)
    if err:
        IMPACTOS.append({"origen": "—", "etapa": "—", "metrica": f"{tipo_m}: {NOMBRE_METRICA.get(tipo_m, '')}",
                         "valor_original": None, "valor_corregido": None, "impacto": None, "impacto_pct": None,
                         "nivel": "Sin cuantificar", "sustento": f"no se pudo calcular la métrica base: {err}"})
        continue
    todas = []
    for h in HALLAZGOS:
        corr = CORRECCIONES.get(h["id"])
        if corr is None:
            IMPACTOS.append({"origen": f"{h['id']}: {h['descripcion'][:120]}", "etapa": h.get("etapa", ""),
                             "metrica": NOMBRE_METRICA.get(tipo_m, tipo_m), "valor_original": base_v,
                             "valor_corregido": None, "impacto": None, "impacto_pct": None,
                             "nivel": "Sin cuantificar", "sustento": "escribe su corrección en CORRECCIONES"})
            continue
        todas.append(corr)
        v, err = _medir(lambda: con_bases(corr(copia()), f_metrica))
        imp, rel, nivel = nivel_impacto(base_v, v, MATERIALIDAD["moderado_pct"], MATERIALIDAD["critico_pct"])
        IMPACTOS.append({"origen": f"{h['id']}: {h['descripcion'][:120]}", "etapa": h.get("etapa", ""),
                         "metrica": NOMBRE_METRICA.get(tipo_m, tipo_m), "valor_original": base_v, "valor_corregido": v,
                         "impacto": imp, "impacto_pct": rel, "nivel": nivel if not err else "Sin cuantificar",
                         "sustento": err or f"métrica recalculada sin la falla (criterio: ≥ {MATERIALIDAD['critico_pct']} % "
                                            f"Crítico, ≥ {MATERIALIDAD['moderado_pct']} % Moderado)"})
    if len(todas) > 1:
        def _todas(b):
            for c in todas:
                b = c(b)
            return b
        v, err = _medir(lambda: con_bases(_todas(copia()), f_metrica))
        imp, rel, nivel = nivel_impacto(base_v, v, MATERIALIDAD["moderado_pct"], MATERIALIDAD["critico_pct"])
        IMPACTOS.append({"origen": "CONJUNTO (todas las correcciones)", "etapa": "03", "metrica": NOMBRE_METRICA.get(tipo_m, tipo_m),
                         "valor_original": base_v, "valor_corregido": v, "impacto": imp, "impacto_pct": rel,
                         "nivel": nivel, "sustento": err or "los impactos no se suman: se recalcula con todo corregido"})
registrar("Hallazgos_origen", HALLAZGOS or [{"aviso": "sin hallazgos abiertos de 01 y 02"}], "Paso 03.1")
registrar("Impactos", IMPACTOS or [{"aviso": "sin métricas"}], "Pasos 03.2–03.7")
pd.DataFrame(IMPACTOS)
'''

# ── 04 · Seguimiento ────────────────────────────────────────────────────────

_C04_IND = r'''
# Indicadores del manual de seguimiento (completa con los del manual: umbral verde/rojo y valor reportado).
INDICADORES = [
    # {"indicador": "Excepciones en 250 días", "umbral_verde": 4, "umbral_rojo": 10, "sentido": "menor_mejor",
    #  "implementador": 3, "replicado": None, "fuente": "Manual de seguimiento §3"},
]
'''

_C04_FIN = r'''
def _semaforo(v, verde, rojo, sentido="menor_mejor"):
    try:
        v, verde, rojo = float(v), float(verde), float(rojo)
    except (TypeError, ValueError):
        return "—"
    if sentido == "menor_mejor":
        return "verde" if v <= verde else ("rojo" if v >= rojo else "ámbar")
    return "verde" if v >= verde else ("rojo" if v <= rojo else "ámbar")


for i in INDICADORES:
    i["semaforo_replicado"] = _semaforo(i.get("replicado"), i.get("umbral_verde"), i.get("umbral_rojo"), i.get("sentido", "menor_mejor"))
    i["semaforo_implementador"] = _semaforo(i.get("implementador"), i.get("umbral_verde"), i.get("umbral_rojo"), i.get("sentido", "menor_mejor"))
registrar("Indicadores", INDICADORES or [{"aviso": "Completa INDICADORES con los del manual de seguimiento."}], "Paso 04.1")
SEGUIMIENTO += [{"indicador": i["indicador"], "umbral": f"{i.get('umbral_verde')} / {i.get('umbral_rojo')}",
                 "implementador": i.get("implementador"), "replicado": i.get("replicado"),
                 "semaforo": i["semaforo_replicado"],
                 "conclusion": ("coincide" if i["semaforo_replicado"] == i["semaforo_implementador"] else "SEMÁFORO DISTINTO")}
                for i in INDICADORES]
registrar("Seguimiento", SEGUIMIENTO or [{"aviso": "sin indicadores recalculados"}], "Pasos 04.2–04.3")
registrar("Backtesting", BACKTESTING or [{"aviso": "sin backtesting para este tipo de modelo"}], "Paso 04.4")
# Paso 04.5 · Estabilidad: PSI de cada columna numérica entre el primer y el último periodo de cada base con fecha.
ESTABILIDAD = []
for nombre, df in bases.items():
    fechas = [c for c in df.columns if es_fecha(df[c])]
    if not fechas:
        continue
    f = a_fecha(df[fechas[0]])
    per = f.dt.to_period("M")
    if per.nunique() < 2:
        continue
    ini, fin = per.min(), per.max()
    for c in df.columns:
        if c in fechas or not pd.api.types.is_numeric_dtype(df[c]):
            continue
        v = psi(df.loc[per == ini, c], df.loc[per == fin, c])
        if v is not None:
            ESTABILIDAD.append({"base": nombre, "variable": c, "desde": str(ini), "hasta": str(fin), "psi": round(v, 4),
                                "lectura": "estable" if v < 0.10 else ("vigilar" if v <= 0.25 else "CAMBIO RELEVANTE")})
registrar("Estabilidad", ESTABILIDAD or [{"aviso": "sin bases con dos periodos"}], "Paso 04.5")
# Paso 04.6 · Alertas: completa con las alertas del periodo, su escalamiento y la acción tomada.
ALERTAS = [
    # {"fecha": "2026-09-15", "indicador": "Excepciones", "valor": 6, "escalada_a": "Comité de Riesgos", "accion": "Recalibración"},
]
registrar("Alertas", ALERTAS or [{"aviso": "Declara las alertas del periodo y su gestión."}], "Paso 04.6")
_rojos = [s for s in SEGUIMIENTO if s.get("semaforo") == "rojo"] + [b for b in BACKTESTING if str(b.get("zona", "")).startswith("roja")]
registrar("Conclusion", [{"indicadores_en_rojo": len(_rojos), "variables_inestables": sum(e["lectura"] == "CAMBIO RELEVANTE" for e in ESTABILIDAD),
                          "conclusion": ("el seguimiento muestra alertas en rojo: revisa la vigencia del modelo" if _rojos else
                                         "sin indicadores en rojo en lo recalculado")}], "Paso 04.7")
'''

_BACKTEST = {
    "var": r'''
t_pyg = tabla("pyg", ["fecha", "pnl"], ["cartera"])
t_var = tabla("var_reportado", ["fecha", "var"], ["cartera"])
if t_pyg is not None and t_var is not None:
    claves = ["fecha"] + (["cartera"] if "cartera" in t_pyg and "cartera" in t_var else [])
    m = t_pyg.merge(t_var, on=claves, how="inner").sort_values(claves[::-1])
    for cart, g in (m.groupby("cartera") if "cartera" in m else [("TOTAL", m)]):
        g = g.sort_values("fecha").tail(251)
        exc = excepciones(g["pnl"], g["var"], 1, SUPUESTOS.get("convencion_pnl", "pnl_negativo"))
        x, n = int(exc.sum()), int(len(exc))
        lr, p = kupiec(x, n, 0.99)
        lri, pi = christoffersen(exc)
        BACKTESTING.append({"cartera": cart, "dias": n, "excepciones": x, "kupiec_lr": lr, "kupiec_p": p,
                            "christoffersen_lr": lri, "christoffersen_p": pi, "zona": semaforo(x, n, 0.99)})
        SEGUIMIENTO.append({"indicador": f"Excepciones en {n} días · {cart}", "umbral": "verde 0–4 · rojo ≥ 10 (250 días)",
                            "implementador": None, "replicado": x, "semaforo": semaforo(x, n, 0.99),
                            "conclusion": f"Kupiec p = {p:.3f}" if p is not None else ""})
''',
    "es_frtb": r'''
t_pyg = tabla("pyg", ["fecha", "pnl_hipotetico", "pnl_teorico"], ["cartera"])
if t_pyg is not None:
    for mesa, g in (t_pyg.groupby("cartera") if "cartera" in t_pyg else [("TOTAL", t_pyg)]):
        rho, ks, zona = pla(g.sort_values("fecha")["pnl_hipotetico"].tail(250), g.sort_values("fecha")["pnl_teorico"].tail(250))
        BACKTESTING.append({"cartera": mesa, "prueba": "PLA", "spearman": rho, "ks": ks, "zona": zona})
''',
    "prepago": r'''
sal = tabla("saldos", ["fecha", "saldo_inicial", "prepago"], ["segmento", "amortizacion"])
mod = tabla("modelo", ["cpr"], ["segmento"])
if sal is not None and mod is not None:
    smm, cpr = smm_cpr(sal["saldo_inicial"], sal["amortizacion"] if "amortizacion" in sal else 0.0, sal["prepago"])
    sal = sal.assign(cpr_obs=cpr.values)
    esc = 100.0 if mod["cpr"].quantile(0.75) > 1 else 1.0
    m_seg = mod.groupby("segmento")["cpr"].mean() / esc if "segmento" in mod else None
    for seg, g in (sal.groupby("segmento") if "segmento" in sal else [("TOTAL", sal)]):
        proy = float(m_seg.get(seg)) if m_seg is not None and seg in m_seg.index else float(mod["cpr"].mean() / esc)
        err = g["cpr_obs"] - proy
        BACKTESTING.append({"segmento": seg, "cpr_modelo": proy, "cpr_observado_medio": float(g["cpr_obs"].mean()),
                            "sesgo": float(err.mean()), "error_medio_abs": float(err.abs().mean()),
                            "zona": "verde" if abs(float(err.mean())) <= 0.02 else ("roja" if abs(float(err.mean())) > 0.05 else "ámbar")})
''',
    "runoff": r'''
sal = tabla("saldos", ["fecha", "saldo"], ["segmento", "cosecha", "edad"])
crv = tabla("curva", ["plazo_meses"], ["segmento", "supervivencia", "runoff_acumulado", "runoff_incremental"])
H, curva_de = int(SUPUESTOS.get("meses_backtesting", 12)), str(SUPUESTOS.get("curva_de", "cosecha"))
h_est = SUPUESTOS.get("horizonte_estable_meses", 60)
if sal is not None and crv is not None and "cosecha" not in sal:
    BACKTESTING.append({"segmento": "—", "zona": "—",
                        "aviso": "sin cosechas no se aísla el saldo existente: el realizado mezclaría el negocio nuevo "
                                 "(pide la historia por cosecha)"})
elif sal is not None and crv is not None:
    modelo = curvas_del_modelo(crv)
    # Saldo EXISTENTE hace H meses: realizado mes a mes frente a lo que proyecta la curva del modelo.
    for seg, g in (sal.groupby("segmento") if "segmento" in sal else [("TOTAL", sal)]):
        cm = modelo.get(seg) if seg in modelo else (next(iter(modelo.values())) if len(modelo) == 1 else None)
        if cm is None:
            continue
        bt = backtesting_runoff(g, cm, H, curva_de)
        if not len(bt):
            continue
        sesgo, mae = 100 * float(bt["error"].mean()), 100 * float(bt["error"].abs().mean())
        zona = "verde" if mae <= 2 else ("ámbar" if mae <= 5 else "roja")
        BACKTESTING.append({"segmento": seg, "meses": len(bt), "realizado_final": float(bt["realizado"].iloc[-1]),
                            "proyectado_final": float(bt["proyectado"].iloc[-1]), "sesgo_pp": sesgo,
                            "error_medio_abs_pp": mae, "zona": zona})
        SEGUIMIENTO.append({"indicador": f"Saldo existente a {len(bt)} meses: realizado vs curva · {seg}",
                            "umbral": "error medio ≤ 2 pp verde · > 5 pp rojo",
                            "implementador": float(bt["proyectado"].iloc[-1]), "replicado": float(bt["realizado"].iloc[-1]),
                            "semaforo": zona,
                            "conclusion": f"sesgo {sesgo:+.1f} pp: " + ("sale MÁS saldo del que prevé la curva (optimista)"
                                                                        if sesgo < 0 else
                                                                        "sale MENOS saldo del que prevé la curva (conservadora)")})
    # Estabilidad de la curva: primera mitad de la historia frente a la segunda.
    m_ = mes_indice(sal["fecha"].reset_index(drop=True)).to_numpy()
    mitad = np.nanmin(m_) + (np.nanmax(m_) - np.nanmin(m_)) // 2
    c1, _r1 = replicar_runoff(sal[m_ <= mitad], h_est, curva_de)
    c2, _r2 = replicar_runoff(sal[m_ > mitad], h_est, curva_de)
    for seg in sorted(set(c1) & set(c2)):
        p = min(12.0, float(c1[seg]["t"].max()), float(c2[seg]["t"].max()))
        a, b = float(np.interp(p, c1[seg]["t"], c1[seg]["S"])), float(np.interp(p, c2[seg]["t"], c2[seg]["S"]))
        SEGUIMIENTO.append({"indicador": f"Estabilidad de S({p:g} meses) entre mitades de la historia · {seg}",
                            "umbral": "± 5 pp", "implementador": a, "replicado": b,
                            "semaforo": "verde" if abs(b - a) <= 0.05 else "ámbar",
                            "conclusion": f"{100 * (b - a):+.1f} pp de la primera a la segunda mitad"})
''',
    "lcr": r'''
ra = tabla("ratio", ["fecha", "lcr"], ["limite"])
if ra is not None:
    s = ra.sort_values("fecha")
    v = s["lcr"] / (100.0 if s["lcr"].median() > 20 else 1.0)
    lim = float(s["limite"].iloc[-1]) / (100.0 if s["limite"].median() > 20 else 1.0) if "limite" in s else 1.0
    BACKTESTING.append({"indicador": "LCR diario", "dias": len(v), "minimo": float(v.min()), "dias_bajo_100": int((v < 1).sum()),
                        "dias_bajo_limite_interno": int((v < lim).sum()), "zona": "verde" if (v >= lim).all() else ("roja" if (v < 1).any() else "ámbar")})
''',
    "nsfr": r'''
ra = tabla("ratio", ["fecha", "nsfr"])
if ra is not None:
    v = ra.sort_values("fecha")["nsfr"]
    v = v / (100.0 if v.median() > 20 else 1.0)
    BACKTESTING.append({"indicador": "NSFR", "periodos": len(v), "minimo": float(v.min()), "periodos_bajo_100": int((v < 1).sum()),
                        "zona": "verde" if (v >= 1).all() else "roja"})
''',
    "lar": r'''
fl = tabla("flujos", ["fecha", "flujo_neto"])
re_ = tabla("resultado", ["lar_valor"], ["fecha"])
if fl is not None and re_ is not None:
    acum = fl.groupby("fecha")["flujo_neto"].sum().sort_index().rolling(30).sum().dropna()
    lar_rep = float(re_["lar_valor"].abs().iloc[-1])
    exced = int((-acum > lar_rep).sum())
    BACKTESTING.append({"indicador": "Salidas netas a 30 días vs LaR", "ventanas": len(acum), "excedencias": exced,
                        "zona": "verde" if exced / max(len(acum), 1) <= 0.01 else "ámbar"})
''',
    "concentracion_fondeo": r'''
dp = tabla("depositantes", ["fecha", "contraparte", "saldo"])
if dp is not None:
    for f, g in dp.groupby("fecha"):
        c = concentracion(g["saldo"], g["contraparte"])
        SEGUIMIENTO.append({"indicador": f"Top 10 depositantes · {str(f)[:10]}", "umbral": "límite interno", "implementador": None,
                            "replicado": c.get("top_10"), "semaforo": "—", "conclusion": f"HHI {c.get('hhi', 0):.0f}"})
''',
    "irrbb": r'''
res = tabla("resultados", ["escenario", "eve"], ["fecha_corte", "limite", "moneda"])
if res is not None:
    peor = res.groupby("escenario")["eve"].sum().min()
    SEGUIMIENTO.append({"indicador": "Peor ΔEVE (suma de monedas)", "umbral": "límite interno / SOT 15 % del Tier 1",
                        "implementador": float(peor), "replicado": None, "semaforo": "—",
                        "conclusion": "divide por el Tier 1 (SUPUESTOS) para el SOT"})
''',
}

_NOMBRE_METRICA = {
    "var": "VaR histórico 99 % del P&L (ventana)", "es_frtb": "ES 97,5 % del HPL", "stress_mercado": "peor pérdida de estrés",
    "valoracion": "valor de la cartera a precio de modelo", "curvas": "tasa media de la curva",
    "contraparte": "EAD total", "irrbb": "ΔEVE paralelo +200 pb (aprox.)", "prepago": "CPR medio observado",
    "nmd": "vida media del depósito (años)", "cancelacion_dpf": "saldo de depósitos", "supervivencia": "cuentas",
    "ftp": "FTP medio", "runoff": "componente estable replicado (ponderado por saldo)", "lcr": "LCR último",
    "nsfr": "NSFR último", "brechas_liquidez": "peor brecha acumulada", "lar": "LaR 30 días 99 %",
    "stress_liquidez": "salidas totales del estrés", "concentracion_fondeo": "% del top 10",
}


def correccion_automatica(h: dict) -> str:
    """
    Código de la corrección de un hallazgo del 01 a partir de su DEFINICIÓN
    (tipo de control, base, columnas y parámetros que ejecutó el notebook de
    calidad). '' si el tipo no admite corrección automática (p. ej. una serie
    con huecos necesita el dato que falta, no un filtro).
    """
    t, ds, cols, p = h.get("tipo"), h.get("dataset"), list(h.get("columnas") or []), dict(h.get("params") or {})
    if not t or not ds or ds.startswith("(") or (not cols and t != "unicidad"):
        return ""
    c0 = cols[0] if cols else ""
    num = f"pd.to_numeric(d[{c0!r}], errors='coerce')"
    if t == "completitud":
        return f"lambda b: quitar_nulos_col(b, {ds!r}, {cols!r})"
    if t == "unicidad":
        return f"lambda b: quitar_duplicados_cols(b, {ds!r}, {cols!r})"
    if t == "no_negativos":
        return f"lambda b: excluir_si(b, {ds!r}, lambda d: {num} < 0)"
    if t == "rango":
        cond = " | ".join(x for x in ((f"({num} < {float(p['minimo'])!r})" if p.get("minimo") is not None else ""),
                                      (f"({num} > {float(p['maximo'])!r})" if p.get("maximo") is not None else "")) if x)
        return f"lambda b: excluir_si(b, {ds!r}, lambda d: {cond})" if cond else ""
    if t == "valores_centinela":
        vals = [str(v) for v in (p.get("valores") or [])] or ["-999", "-9999", "99999999", "N/A", "NULL", "1900-01-01"]
        return (f"lambda b: excluir_si(b, {ds!r}, lambda d: d[{c0!r}].astype(str).str.strip().str.upper()"
                f".isin({[v.upper() for v in vals]!r}) | {num}.isin({[float(v) for v in vals if v.lstrip('-').replace('.', '', 1).isdigit()]!r}))")
    if t == "outliers_iqr":
        k = float(p.get("k", 3.0))
        return (f"lambda b: excluir_si(b, {ds!r}, lambda d: ({num} < {num}.quantile(0.25) - {k} * ({num}.quantile(0.75) - "
                f"{num}.quantile(0.25))) | ({num} > {num}.quantile(0.75) + {k} * ({num}.quantile(0.75) - {num}.quantile(0.25))))")
    if t == "fecha_futura":
        return f"lambda b: excluir_si(b, {ds!r}, lambda d: a_fecha(d[{c0!r}]) > pd.Timestamp.today().normalize())"
    if t in ("consistencia", "consistencia_fechas") and len(cols) == 2:
        op = str(p.get("operador") or "<=")
        conv = "a_fecha" if t == "consistencia_fechas" else "pd.to_numeric"
        a = f"{conv}(d[{cols[0]!r}]" + (", errors='coerce')" if conv == "pd.to_numeric" else ")")
        bb = f"{conv}(d[{cols[1]!r}]" + (", errors='coerce')" if conv == "pd.to_numeric" else ")")
        return f"lambda b: excluir_si(b, {ds!r}, lambda d: ~({a} {op} {bb}) & {a}.notna() & {bb}.notna())"
    if t == "integridad" and p.get("ref_dataset") and p.get("ref_columna"):
        return (f"lambda b: excluir_si(b, {ds!r}, lambda d: d[{c0!r}].notna() & ~d[{c0!r}].astype(str).str.strip()"
                f".isin(set(b[{p['ref_dataset']!r}][{p['ref_columna']!r}].dropna().astype(str).str.strip())))")
    if t == "saltos_serie" and len(cols) >= 2:
        grupo = cols[2:4] if len(cols) > 3 else (cols[2] if len(cols) > 2 else None)
        agregar = f", agregar={str(p['agregar'])!r}" if p.get("agregar") else ""
        return (f"lambda b: excluir_saltos(b, {ds!r}, {cols[0]!r}, {cols[1]!r}, "
                f"{grupo!r}, {float(p.get('k', 8.0))!r}{agregar})")
    return ""


def celdas_plantilla(codigo: str, tipos: Iterable[str], hallazgos: list[dict] | None = None) -> list[dict]:
    """Celdas deterministas de la etapa (sin IA) que recorren su ruta con código real."""
    tipos = list(tipos or [])
    if codigo == "00":
        return _celdas_00()
    if codigo == "02":
        sup: dict[str, Any] = {}
        for t in tipos:
            sup.update(_SUPUESTOS.get(t, {}))
        celdas = [_paso("02", 1, "Declara en `EXCLUSIONES` las del manual: se aplican a `bases` y quedan contadas."),
                  _code(_C02_1), _paso("02", 2), _code(_C02_2),
                  _paso("02", 3, "Ajusta `SUPUESTOS` a lo que dice el manual (y anota la sección)."),
                  _code(f"SUPUESTOS = {sup!r}\n" + _C02_3)]
        if not tipos:
            celdas.append(_md("## Pasos 02.4, 02.5 y 02.6 · Réplica\n\nSin tipo de modelo elegido no hay réplica automática: "
                              "elígelo en la ficha del modelo, o escribe aquí la réplica con `comparar(...)`."))
        for t in tipos:
            from modulos.tipos_modelo import TIPOS
            celdas.append(_md(f"## Pasos 02.4, 02.5 y 02.6 · Réplica: {TIPOS[t]['nombre']}\n\n"
                              + "\n".join(f"- {p}" for p in TIPOS[t]["etapas"].get("02", []))))
            celdas.append(_code(_REPLICA.get(t, "REPLICA.append({'paso': '—', 'conclusion': 'sin réplica automática'})")))
        celdas += [_paso("02", 7), _code(_C02_7), _paso("02", 8), _code(_C02_8)]
        return celdas
    if codigo == "03":
        hs = [{"id": h.get("id") or h.get("ID"), "etapa": h.get("etapa", ""),
               "descripcion": str(h.get("descripcion") or h.get("Descripción") or "")[:300],
               "severidad": h.get("severidad") or h.get("Severidad") or ""} for h in (hallazgos or [])]
        metricas = "{" + ", ".join(f"{t!r}: {_METRICA[t]}" for t in tipos if t in _METRICA) + "}"
        nombres = {t: _NOMBRE_METRICA.get(t, t) for t in tipos}
        auto = {str(h.get("id") or h.get("ID")): correccion_automatica(h) for h in (hallazgos or [])}
        lineas = []
        for h in hs[:30]:
            cod = auto.get(str(h["id"]), "")
            if cod:
                lineas.append(f"    {h['id']!r}: {cod},   # automática: {h['descripcion'][:70]}")
            else:
                lineas.append(f"    # {h['id']!r}: lambda b: b,   # escríbela: {h['descripcion'][:80]}")
        ejemplo = "\n".join(lineas)
        return [
            _paso("03", 1, "Vienen de los hallazgos abiertos de las etapas 01 y 02 (puedes añadir o quitar)."),
            _code(f"HALLAZGOS = {hs!r}"),
            _paso("03", 2, "La métrica principal de cada tipo de modelo; edita `METRICAS` si el manual usa otra."),
            _code("SUPUESTOS = " + repr({"ventana_dias": 250,
                                         **{k: v for t in tipos for k, v in _SUPUESTOS.get(t, {}).items()}}) + "\n"
                  f"NOMBRE_METRICA = {nombres!r}\n"
                  f"METRICAS = {metricas}\n"
                  "MATERIALIDAD = {'moderado_pct': 5.0, 'critico_pct': 10.0}   # criterio de nivel (edítalo)"),
            _paso("03", 4, "Por hallazgo, una función que recibe una copia de las bases y devuelve las bases "
                           "CORREGIDAS. Ayudas: `quitar_nulos(b, base, rol)`, `quitar_duplicados(b, base, roles)`, "
                           "`excluir(b, base, 'condición pandas')`, `escalar(b, base, rol, factor)`."),
            _code(_C03_AYUDAS + "\n\nCORRECCIONES = {\n" + (ejemplo + "\n" if ejemplo else "") + "}"),
            _md("## Pasos 03.3, 03.5, 03.6 y 03.7 · Base, corregido, conjunto y nivel\n\nPara cada métrica: el "
                "valor base, el corregido por hallazgo, el conjunto (todas las correcciones a la vez) y el nivel "
                "con el criterio de `MATERIALIDAD`."),
            _code(_C03_CALCULO),
        ]
    if codigo == "04":
        celdas = [_paso("04", 1, "Completa `INDICADORES` con los del manual de seguimiento."), _code(_C04_IND),
                  _md("## Pasos 04.2, 04.3 y 04.4 · Recalcular, comparar y backtesting\n\nLo que se puede recalcular solo "
                      "con los datos del tipo de modelo va aquí; completa `replicado` en `INDICADORES` con lo demás."),
                  _code("SUPUESTOS = " + repr({k: v for t in tipos for k, v in _SUPUESTOS.get(t, {}).items()})
                        + "\nSEGUIMIENTO, BACKTESTING = [], []")]
        for t in tipos:
            if t in _BACKTEST:
                from modulos.tipos_modelo import TIPOS
                celdas.append(_md(f"### Backtesting: {TIPOS[t]['nombre']}\n\n"
                                  + "\n".join(f"- {p}" for p in TIPOS[t]["etapas"].get("04", []))))
                celdas.append(_code(_BACKTEST[t]))
        celdas += [_md("## Pasos 04.5, 04.6 y 04.7 · Estabilidad, alertas y conclusión"), _code(_C04_FIN)]
        return celdas
    return []


def cobertura_plantilla(codigo: str, tipos: Iterable[str]) -> dict[str, str]:
    """Qué pasos de la ruta cubre la plantilla determinista (cubierto | parcial)."""
    tipos = list(tipos or [])
    parcial = {"00": {"00.7"}, "01": {"01.5", "01.6"}, "02": {"02.7"} | ({"02.4", "02.5", "02.6"} if not tipos else set()),
               "03": {"03.4"}, "04": {"04.1", "04.6"} | ({"04.4"} if not any(t in _BACKTEST for t in tipos) else set())}
    return {p: ("parcial" if p in parcial.get(codigo, set()) else "cubierto") for p, *_ in RUTAS[codigo]}
