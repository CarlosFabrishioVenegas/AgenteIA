"""
modulos/hallazgos_completa.py
═══════════════════════════════════════════════════════════════════════════════
HALLAZGOS DE LA VALIDACIÓN COMPLETA (2026-11-24): un Excel y un .md por etapa,
y la lectura final de esos entregables.

POR ETAPA (se reescriben en cada iteración), junto a los notebooks, en
outputs/validacion_completa/<fichero>/:

  <fichero>_HALLAZGOS.xlsx  · «Hallazgos»: una fila por hallazgo con su estado
                              vigente, la iteración en que nació, su historial
                              (ITER0 nuevo → ITER1 persiste → …) y el EXCEL DE
                              SUSTENTO (el archivo que lo prueba, con hoja y fila
                              cuando la evidencia las cita).
                            · la tabla de la etapa (Mapeo, Controles, Réplica…),
                              «Pendientes», «Iteraciones» y «Etapa».
  <fichero>_HALLAZGOS.md    lo mismo, para leer (y para el agente).

AL FINALIZAR (`consolidar`): se LEEN esos Excel y .md de las cinco etapas —no
el JSON interno: el validador puede corregir el Excel después de la última
iteración—, se contrastan entre sí (un hallazgo que esté en uno y no en el
otro, o con otra severidad o estado, es una INCONSISTENCIA que se informa), se
copian los Excel de sustento y se escribe el consolidado en
outputs/validacion_completa/_consolidado/:

  HALLAZGOS_VALIDACION_COMPLETA.xlsx   Resumen · Hallazgos · una hoja por etapa · Inconsistencias
  HALLAZGOS_VALIDACION_COMPLETA.md
  sustento/<fichero>/<excel>           cada Excel que sustenta un hallazgo
  consolidado.json                     lo mismo, para la web y el informe

El cuadro de observaciones y el anexo del informe Word leen lo consolidado.
Nada se ejecuta: los Excel se leen con pandas y los .md como texto.
"""
from __future__ import annotations

import json
import re
import shutil
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

__all__ = ["COLUMNAS_HALLAZGOS", "escribir_etapa", "leer_etapa", "consolidar",
           "ultimo_consolidado", "hallazgos_vigentes", "nombre_excel", "nombre_md",
           "DIR_CONSOLIDADO", "NOMBRE_CONSOLIDADO"]

COLUMNAS_HALLAZGOS = ["Etapa", "ID", "Descripción", "Severidad", "Estado", "Acción",
                      "Evidencia", "Excel de sustento", "Hoja / fila", "Nace en",
                      "Última iteración", "Historial", "Nota"]
NOMBRE_CONSOLIDADO = "HALLAZGOS_VALIDACION_COMPLETA"
DIR_CONSOLIDADO = "_consolidado"
_EXT_TABLA = (".xlsx", ".xlsm", ".xls", ".csv")
_RE_EXCEL = re.compile(r"([^/\\|\[\]!:*?\"<>]+?\.(?:xlsx|xlsm|xls|csv))", re.IGNORECASE)
_RE_HOJA_FILA = re.compile(r"(?:^|/)\s*([^/!\[\]]+?)\s*!\s*([A-Z]{0,3}\d+)")


def _vc():
    from modulos import validacion_completa as vc
    return vc


def _ahora() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _norm(s: Any) -> str:
    s = unicodedata.normalize("NFKD", str(s or ""))
    return "".join(c for c in s if not unicodedata.combining(c)).lower().strip()


def _texto(v: Any) -> str:
    return "" if v is None or str(v) in ("nan", "None", "NaT") else str(v).strip()


def nombre_excel(codigo: str) -> str:
    return f"{_vc().ETAPAS[codigo]['fichero']}_HALLAZGOS.xlsx"


def nombre_md(codigo: str) -> str:
    return f"{_vc().ETAPAS[codigo]['fichero']}_HALLAZGOS.md"


def _hoja(nombre: str) -> str:
    return re.sub(r"[\[\]:*?/\\]", " ", nombre)[:31]


# ─── Excel de sustento ───────────────────────────────────────────────────────

def _tablas_recibidas(inputs: Path, codigo: str, hasta: Optional[int] = None) -> list[Path]:
    """Excels/CSV que el validador envió a la etapa, en orden de iteración."""
    base = _vc().dir_entrada(inputs, codigo)
    if not base.is_dir():
        return []
    salida = []
    iters = sorted((p for p in base.iterdir() if p.is_dir() and re.fullmatch(r"ITER\d+", p.name)),
                   key=lambda p: int(p.name[4:]))
    for d in iters:
        if hasta is not None and int(d.name[4:]) > hasta:
            break
        salida += sorted(p for p in d.iterdir() if p.suffix.lower() in _EXT_TABLA)
    return salida


def _todas_las_tablas(inputs: Path) -> list[Path]:
    raiz = Path(inputs) / "validacion_completa"
    if not raiz.is_dir():
        return []
    return [p for p in raiz.rglob("*") if p.is_file() and p.suffix.lower() in _EXT_TABLA
            and "_vigentes" not in p.parts and DIR_CONSOLIDADO not in p.parts]


def sustento_de(inputs: Path, codigo: str, evidencia: str, ultima: int) -> dict[str, str]:
    """
    El Excel que prueba un hallazgo: el que cite su evidencia («archivo.xlsx/Hoja!12»)
    si está entre lo recibido; si no cita ninguno, el último resultado que el
    validador envió a la etapa hasta esa iteración; si no hay, el resultado que
    debe producir el notebook (pendiente de ejecutar).
    Devuelve {archivo, ruta (relativa a inputs, o ""), hoja_fila, estado}.
    """
    vc = _vc()
    evidencia = _texto(evidencia)
    hf = _RE_HOJA_FILA.search(evidencia)
    hoja_fila = f"{hf.group(1).strip()}!{hf.group(2)}" if hf else ""
    citado = _RE_EXCEL.search(evidencia)
    if citado:
        nombre = Path(citado.group(1).strip()).name
        cand = [p for p in _todas_las_tablas(inputs) if p.name.lower() == nombre.lower()]
        if not cand:
            cand = [p for p in _todas_las_tablas(inputs)
                    if Path(nombre).stem.lower() in p.stem.lower()]
        if cand:
            p = max(cand, key=lambda x: x.stat().st_mtime)
            return {"archivo": p.name, "ruta": p.relative_to(inputs).as_posix(),
                    "hoja_fila": hoja_fila.split("/")[-1], "estado": "citado"}
        return {"archivo": nombre, "ruta": "", "hoja_fila": hoja_fila.split("/")[-1],
                "estado": "no encontrado"}
    recibidas = _tablas_recibidas(inputs, codigo, ultima)
    if recibidas:
        p = recibidas[-1]
        return {"archivo": p.name, "ruta": p.relative_to(inputs).as_posix(),
                "hoja_fila": hoja_fila, "estado": "último resultado recibido"}
    return {"archivo": vc.nombre_resultado(codigo, ultima), "ruta": "", "hoja_fila": hoja_fila,
            "estado": "pendiente: ejecuta el notebook y envía su Excel"}


# ─── Hallazgos de una etapa a lo largo de sus iteraciones ────────────────────

def hallazgos_etapa(inputs: Path, outputs: Path, codigo: str) -> dict[str, Any]:
    """Registro de hallazgos de la etapa (estado vigente + historial) desde sus iteraciones."""
    vc = _vc()
    e = vc.ETAPAS[codigo]
    h = vc.cargar_historial(outputs, codigo)
    registro: dict[str, dict] = {}
    ultimo_r: Optional[dict] = None
    ultima_n = -1
    for it in h["iteraciones"]:
        r = vc._resultado_iteracion(outputs, codigo, it)
        if not r:
            continue
        ultimo_r, ultima_n = r, it["n"]
        for hz in r.get("hallazgos") or []:
            hid = _texto(hz.get("id")) or f"H{len(registro) + 1}"
            reg = registro.setdefault(hid, {"id": hid, "nace": it["n"], "historial": []})
            reg.update({k: _texto(hz.get(k)) for k in ("descripcion", "evidencia", "severidad",
                                                       "estado", "accion")})
            reg["ultima"] = it["n"]
            reg["historial"].append(f"ITER{it['n']} {reg['estado'] or 'nuevo'}")
    filas = []
    for reg in registro.values():
        nota = ""
        if reg["ultima"] < ultima_n and reg["estado"] != "resuelto":
            nota = (f"No aparece en la última iteración (ITER{ultima_n}): confirmar con el "
                    "agente si se resolvió.")
        s = sustento_de(inputs, codigo, reg["evidencia"], reg["ultima"])
        filas.append({
            "Etapa": f"{codigo} · {e['nombre']}", "ID": reg["id"], "Descripción": reg["descripcion"],
            "Severidad": reg["severidad"] or "Moderado", "Estado": reg["estado"] or "nuevo",
            "Acción": reg["accion"], "Evidencia": reg["evidencia"],
            "Excel de sustento": s["archivo"], "Hoja / fila": s["hoja_fila"],
            "Nace en": f"ITER{reg['nace']}", "Última iteración": f"ITER{reg['ultima']}",
            "Historial": " → ".join(reg["historial"]),
            "Nota": "; ".join(x for x in (nota, "" if s["ruta"] or s["estado"].startswith("pend")
                                           else f"Excel de sustento {s['estado']}") if x),
            "_ruta_sustento": s["ruta"], "_estado_sustento": s["estado"]})
    orden = {"Crítico": 0, "Moderado": 1, "Potencial/Bajo": 2}
    filas.sort(key=lambda f: (f["Estado"] == "resuelto", orden.get(f["Severidad"], 3), f["ID"]))
    return {"codigo": codigo, "fichero": e["fichero"], "nombre": e["nombre"], "tabla_nombre": e["tabla"],
            "columnas_tabla": e["columnas"], "filas": filas, "ultimo": ultimo_r or {},
            "ultima_iteracion": ultima_n, "iteraciones": h["iteraciones"], "cierre": h.get("cierre")}


def _md_etapa(d: dict) -> str:
    esc = lambda s: _texto(s).replace("|", "\\|").replace("\n", " ")   # noqa: E731
    filas = d["filas"]
    abiertos = [f for f in filas if f["Estado"] != "resuelto"]
    por_sev = {n: sum(1 for f in abiertos if f["Severidad"] == n)
               for n in ("Crítico", "Moderado", "Potencial/Bajo")}
    ult = d["ultimo"]
    ver = ult.get("veredicto") or {}
    l = [f"# {d['fichero']} · hallazgos de la etapa", "",
         f"- **Etapa:** {d['codigo']} · {d['nombre']}",
         f"- **Iteraciones:** {len(d['iteraciones'])} (última: ITER{d['ultima_iteracion']})",
         f"- **Veredicto del agente en la última iteración:** "
         f"{'lista para validar' if ver.get('estado') == 'lista' else 'requiere otra iteración'}"
         + (f" — {ver['motivo']}" if ver.get("motivo") else ""),
         f"- **Hallazgos:** {len(filas)} · abiertos {len(abiertos)} (Crítico {por_sev['Crítico']}, "
         f"Moderado {por_sev['Moderado']}, Potencial/Bajo {por_sev['Potencial/Bajo']}) · "
         f"resueltos {len(filas) - len(abiertos)}",
         f"- **Generado (UTC):** {_ahora()} · Excel gemelo: `{d['fichero']}_HALLAZGOS.xlsx`", "",
         "## Resumen", "", _texto(ult.get("resumen")) or "—", "",
         "## Hallazgos", ""]
    if filas:
        l += ["| ID | Severidad | Estado | Descripción | Evidencia | Excel de sustento | Historial |",
              "|---|---|---|---|---|---|---|"]
        l += [f"| {esc(f['ID'])} | {esc(f['Severidad'])} | {esc(f['Estado'])} | {esc(f['Descripción'])} | "
              f"{esc(f['Evidencia'])} | {esc(f['Excel de sustento'])}"
              + (f" ({esc(f['Hoja / fila'])})" if f["Hoja / fila"] else "")
              + f" | {esc(f['Historial'])} |" for f in filas]
        l += ["", "## Detalle por hallazgo", ""]
        for f in filas:
            l += [f"### {f['ID']} · {f['Severidad']} · {f['Estado']}", "",
                  f"- **Descripción:** {f['Descripción'] or '—'}",
                  f"- **Evidencia:** {f['Evidencia'] or '—'}",
                  f"- **Excel de sustento:** `{f['Excel de sustento']}`"
                  + (f" · {f['Hoja / fila']}" if f["Hoja / fila"] else ""),
                  f"- **Acción:** {f['Acción'] or '—'}",
                  f"- **Historial:** {f['Historial']} (nace en {f['Nace en']})"]
            if f["Nota"]:
                l.append(f"- **Nota:** {f['Nota']}")
            l.append("")
    else:
        l += ["Sin hallazgos.", ""]
    l += [f"## {d['tabla_nombre']}", ""]
    tabla = ult.get("tabla") or []
    if tabla:
        cols = d["columnas_tabla"]
        l.append("| " + " | ".join(v for _, v in cols) + " |")
        l.append("|" + "---|" * len(cols))
        l += ["| " + " | ".join(esc(f.get(k)) for k, _ in cols) + " |" for f in tabla]
    else:
        l.append("—")
    l += ["", "## Pendientes", ""]
    l += [f"{i}. {p}" for i, p in enumerate(ult.get("pendientes") or [], start=1)] or ["—"]
    return "\n".join(l) + "\n"


def escribir_etapa(inputs: Path, outputs: Path, codigo: str) -> dict[str, Any]:
    """Escribe <fichero>_HALLAZGOS.xlsx y .md con TODOS los hallazgos de la etapa."""
    import pandas as pd
    vc = _vc()
    d = hallazgos_etapa(Path(inputs), Path(outputs), codigo)
    carpeta = vc.dir_salida(outputs, codigo)
    carpeta.mkdir(parents=True, exist_ok=True)
    xlsx, md = carpeta / nombre_excel(codigo), carpeta / nombre_md(codigo)
    ult = d["ultimo"]
    filas = [{k: f[k] for k in COLUMNAS_HALLAZGOS} for f in d["filas"]]
    tabla = pd.DataFrame([{v: _texto(f.get(k)) for k, v in d["columnas_tabla"]} for f in ult.get("tabla") or []],
                         columns=[v for _, v in d["columnas_tabla"]])
    iteraciones = pd.DataFrame([{
        "Iteración": f"ITER{it['n']}", "Fecha (UTC)": it.get("ts", ""), "Modo": it.get("modo", ""),
        "Proveedor": it.get("proveedor", ""),
        "Veredicto": (it.get("veredicto") or {}).get("estado", ""),
        "Abiertos": it.get("abiertos", 0), "Resueltos": it.get("resueltos", 0),
        "Notebook": it.get("ipynb", ""), "Excel que genera": it.get("resultado_esperado", ""),
        "Archivos recibidos": ", ".join(it.get("archivos") or [])} for it in d["iteraciones"]])
    etapa = pd.DataFrame([("Etapa", f"{codigo} · {d['nombre']}"),
                          ("Iteraciones", len(d["iteraciones"])),
                          ("Hallazgos", len(filas)),
                          ("Abiertos", sum(1 for f in filas if f["Estado"] != "resuelto")),
                          ("Generado (UTC)", _ahora()),
                          ("Nota", "Lo lee el consolidado final: corrige aquí (no en el .md) si "
                                   "hace falta, después de la última iteración.")],
                         columns=["Campo", "Valor"])
    with pd.ExcelWriter(xlsx) as w:
        pd.DataFrame(filas, columns=COLUMNAS_HALLAZGOS).to_excel(w, sheet_name="Hallazgos", index=False)
        tabla.to_excel(w, sheet_name=_hoja(d["tabla_nombre"]), index=False)
        pd.DataFrame({"Pendiente": ult.get("pendientes") or []}).to_excel(w, sheet_name="Pendientes", index=False)
        iteraciones.to_excel(w, sheet_name="Iteraciones", index=False)
        etapa.astype(object).to_excel(w, sheet_name="Etapa", index=False)
    md.write_text(_md_etapa(d), encoding="utf-8")
    return {"xlsx": xlsx, "md": md, "hallazgos": len(filas)}


# ─── Lectura de los entregables de una etapa ─────────────────────────────────

_ALIAS_COL = {"etapa": "Etapa", "id": "ID", "descripcion": "Descripción", "severidad": "Severidad",
              "estado": "Estado", "accion": "Acción", "evidencia": "Evidencia",
              "excel de sustento": "Excel de sustento", "hoja / fila": "Hoja / fila",
              "nace en": "Nace en", "ultima iteracion": "Última iteración",
              "historial": "Historial", "nota": "Nota"}


def _severidad(v: str) -> Optional[str]:
    n = _norm(v)
    if n.startswith("crit"):
        return "Crítico"
    if n.startswith("mod"):
        return "Moderado"
    if n.startswith(("pot", "baj")):
        return "Potencial/Bajo"
    return None


def _estado(v: str) -> Optional[str]:
    n = _norm(v)
    return n if n in ("nuevo", "persiste", "resuelto") else None


def _md_tabla_hallazgos(texto: str) -> dict[str, dict[str, str]]:
    """Filas de la tabla «## Hallazgos» del .md: {id: {severidad, estado}}."""
    salida: dict[str, dict[str, str]] = {}
    dentro = False
    for linea in texto.splitlines():
        if linea.startswith("## "):
            dentro = linea.strip() == "## Hallazgos"
            continue
        if not dentro or not linea.startswith("|") or linea.startswith("|---") or linea.startswith("| ID"):
            continue
        celdas = [c.strip() for c in re.split(r"(?<!\\)\|", linea.strip().strip("|"))]
        if len(celdas) >= 3 and celdas[0]:
            salida[celdas[0]] = {"severidad": celdas[1], "estado": celdas[2]}
    return salida


def _md_seccion(texto: str, titulo: str) -> str:
    m = re.search(rf"^## {re.escape(titulo)}\s*$(.*?)(?=^## |\Z)", texto, re.M | re.S)
    return m.group(1).strip() if m else ""


def leer_etapa(inputs: Path, outputs: Path, codigo: str) -> Optional[dict[str, Any]]:
    """
    Lee <fichero>_HALLAZGOS.xlsx (fuente de los campos) y su .md (narrativa) y
    los contrasta. None si la etapa no tiene entregables de hallazgos.
    """
    import pandas as pd
    vc = _vc()
    e = vc.ETAPAS[codigo]
    carpeta = vc.dir_salida(outputs, codigo)
    xlsx, md = carpeta / nombre_excel(codigo), carpeta / nombre_md(codigo)
    if not xlsx.is_file() and not md.is_file():
        return None
    inconsistencias: list[str] = []
    hallazgos: list[dict] = []
    tabla: list[dict] = []
    pendientes: list[str] = []
    if xlsx.is_file():
        try:
            hojas = pd.read_excel(xlsx, sheet_name=None)
        except Exception as exc:                          # noqa: BLE001
            hojas = {}
            inconsistencias.append(f"{xlsx.name}: no se pudo leer ({exc}).")
        df = hojas.get("Hallazgos")
        if df is not None:
            ren = {c: _ALIAS_COL.get(_norm(c), c) for c in df.columns}
            for r in df.rename(columns=ren).to_dict("records"):
                f = {k: _texto(r.get(k)) for k in COLUMNAS_HALLAZGOS}
                if not f["ID"] and not f["Descripción"]:
                    continue
                sev, est = _severidad(f["Severidad"]), _estado(f["Estado"])
                if sev is None:
                    inconsistencias.append(f"{f['ID']}: severidad no reconocida «{f['Severidad']}» "
                                           "en el Excel (se toma Moderado).")
                if est is None:
                    inconsistencias.append(f"{f['ID']}: estado no reconocido «{f['Estado']}» en el "
                                           "Excel (se toma «persiste»).")
                f["Severidad"], f["Estado"] = sev or "Moderado", est or "persiste"
                hallazgos.append(f)
        elif hojas:
            inconsistencias.append(f"{xlsx.name}: falta la hoja «Hallazgos».")
        hoja_tabla = hojas.get(_hoja(e["tabla"]))
        if hoja_tabla is not None:
            tabla = [{k: _texto(v) for k, v in r.items()} for r in hoja_tabla.to_dict("records")]
        hoja_pend = hojas.get("Pendientes")
        if hoja_pend is not None and len(hoja_pend.columns):
            pendientes = [_texto(v) for v in hoja_pend.iloc[:, 0] if _texto(v)]
    else:
        inconsistencias.append(f"Falta {nombre_excel(codigo)} (solo hay .md).")
    resumen = ""
    if md.is_file():
        texto = md.read_text(encoding="utf-8", errors="replace")
        resumen = _md_seccion(texto, "Resumen")
        en_md = _md_tabla_hallazgos(texto)
        en_x = {f["ID"]: f for f in hallazgos}
        for hid in en_x:
            if hid not in en_md:
                inconsistencias.append(f"{hid}: está en el Excel y no en el .md.")
        for hid, m in en_md.items():
            if hid not in en_x:
                inconsistencias.append(f"{hid}: está en el .md y no en el Excel (se usa el Excel).")
                continue
            f = en_x[hid]
            if _severidad(m["severidad"]) and _severidad(m["severidad"]) != f["Severidad"]:
                inconsistencias.append(f"{hid}: severidad «{f['Severidad']}» en el Excel y "
                                       f"«{m['severidad']}» en el .md (se usa el Excel).")
            if _estado(m["estado"]) and _estado(m["estado"]) != f["Estado"]:
                inconsistencias.append(f"{hid}: estado «{f['Estado']}» en el Excel y «{m['estado']}» "
                                       "en el .md (se usa el Excel).")
    else:
        inconsistencias.append(f"Falta {nombre_md(codigo)} (solo hay Excel).")
    # Cada hallazgo abierto debe llevar su Excel de sustento.
    for f in hallazgos:
        if f["Estado"] != "resuelto" and not f["Excel de sustento"]:
            inconsistencias.append(f"{f['ID']}: hallazgo abierto sin Excel de sustento.")
    h = vc.cargar_historial(outputs, codigo)
    return {"codigo": codigo, "fichero": e["fichero"], "nombre": e["nombre"], "hallazgos": hallazgos,
            "tabla": tabla, "pendientes": pendientes, "resumen": resumen,
            "inconsistencias": inconsistencias, "cierre": h.get("cierre"),
            "iteraciones": len(h["iteraciones"]),
            "excel": xlsx.name if xlsx.is_file() else "", "md": md.name if md.is_file() else ""}


def hallazgos_vigentes(inputs: Path, outputs: Path) -> list[dict[str, Any]]:
    """Lectura de las cinco etapas (Excel + .md); genera los que falten de sesiones antiguas."""
    vc = _vc()
    salida = []
    for c in vc.ETAPAS:
        if not vc.cargar_historial(outputs, c)["iteraciones"]:
            continue
        lect = leer_etapa(inputs, outputs, c)
        if lect is None:                                   # sesión anterior a estos entregables
            escribir_etapa(inputs, outputs, c)
            lect = leer_etapa(inputs, outputs, c)
        if lect:
            salida.append(lect)
    return salida


# ─── Consolidado final ───────────────────────────────────────────────────────

def _md_consolidado(etapas: list[dict], resumen: dict, filas: list[dict], incons: list[str]) -> str:
    esc = lambda s: _texto(s).replace("|", "\\|").replace("\n", " ")   # noqa: E731
    l = [f"# Hallazgos de la Validación completa", "",
         f"- **Generado (UTC):** {resumen['generado']}",
         f"- **Etapas cerradas:** {resumen['cerradas']} de {resumen['total']}"
         + (" — **lista para validar**" if resumen["lista_para_validar"] else ""),
         f"- **Hallazgos:** {resumen['hallazgos']} · abiertos {resumen['abiertos']} "
         f"(Crítico {resumen['criticos']}, Moderado {resumen['moderados']}, "
         f"Potencial/Bajo {resumen['bajos']})",
         f"- **Inconsistencias entre Excel y .md:** {len(incons)}", ""]
    if resumen["avisos"]:
        l += ["## Avisos", ""] + [f"- {a}" for a in resumen["avisos"]] + [""]
    l += ["## Por etapa", "", "| Etapa | Estado | Iteraciones | Hallazgos | Abiertos | Críticos abiertos |",
          "|---|---|---|---|---|---|"]
    for e in etapas:
        l.append(f"| {esc(e['etapa'])} | {esc(e['estado'])} | {e['iteraciones']} | {e['hallazgos']} | "
                 f"{e['abiertos']} | {e['criticos']} |")
    for e in etapas:
        l += ["", f"## {e['etapa']}", "", e.get("resumen") or "—", ""]
        propios = [f for f in filas if f["Etapa"].startswith(e["codigo"])]
        if propios:
            l += ["| ID | Severidad | Estado | Descripción | Excel de sustento |", "|---|---|---|---|---|"]
            l += [f"| {esc(f['ID'])} | {esc(f['Severidad'])} | {esc(f['Estado'])} | "
                  f"{esc(f['Descripción'])} | {esc(f['Ruta del sustento'] or f['Excel de sustento'])}"
                  + (f" ({esc(f['Hoja / fila'])})" if f["Hoja / fila"] else "") + " |" for f in propios]
        else:
            l.append("Sin hallazgos.")
    if incons:
        l += ["", "## Inconsistencias", ""] + [f"- {x}" for x in incons]
    return "\n".join(l) + "\n"


def consolidar(inputs: Path, outputs: Path) -> dict[str, Any]:
    """
    Lee los Excel y .md de hallazgos de las cinco etapas, copia los Excel de
    sustento y escribe el consolidado final. Devuelve el resumen (también en
    _consolidado/consolidado.json).
    """
    import pandas as pd
    vc = _vc()
    inputs, outputs = Path(inputs), Path(outputs)
    destino = outputs / "validacion_completa" / DIR_CONSOLIDADO
    if destino.is_dir():
        shutil.rmtree(destino / "sustento", ignore_errors=True)
    destino.mkdir(parents=True, exist_ok=True)
    lecturas = {l["codigo"]: l for l in hallazgos_vigentes(inputs, outputs)}
    etapas, filas, incons, avisos = [], [], [], []
    for c, e in vc.ETAPAS.items():
        h = vc.cargar_historial(outputs, c)
        lect = lecturas.get(c)
        cierre = h.get("cierre")
        estado = (f"Cerrada por {cierre.get('por', '')} (ITER{cierre.get('iter')})" if cierre
                  else ("Abierta" if h["iteraciones"] else "Sin iteraciones"))
        hz = (lect or {}).get("hallazgos") or []
        abiertos = [f for f in hz if f["Estado"] != "resuelto"]
        crit = sum(1 for f in abiertos if f["Severidad"] == "Crítico")
        etapas.append({"codigo": c, "etapa": f"{c} · {e['nombre']}", "estado": estado,
                       "cerrada": bool(cierre), "iteraciones": len(h["iteraciones"]),
                       "hallazgos": len(hz), "abiertos": len(abiertos), "criticos": crit,
                       "resumen": (lect or {}).get("resumen", ""),
                       "excel": (lect or {}).get("excel", ""), "md": (lect or {}).get("md", ""),
                       "inconsistencias": len((lect or {}).get("inconsistencias") or [])})
        if cierre and crit:
            avisos.append(f"{c} · {e['nombre']} está cerrada con {crit} hallazgo(s) Crítico(s) abiertos.")
        incons += [f"{c} · {x}" for x in (lect or {}).get("inconsistencias") or []]
        # Copia de cada Excel de sustento (todo hallazgo lleva su Excel). Manda
        # el nombre que dice el Excel de la etapa (el validador pudo corregirlo);
        # si no está entre lo recibido, se busca por la evidencia.
        tablas = _todas_las_tablas(inputs)
        for f in hz:
            ruta = ""
            nombre = Path(f["Excel de sustento"]).name if f["Excel de sustento"] else ""
            cand = [p for p in tablas if nombre and p.name.lower() == nombre.lower()]
            if cand:
                ruta = max(cand, key=lambda x: x.stat().st_mtime).relative_to(inputs).as_posix()
            elif f["Evidencia"] or nombre:
                ruta = sustento_de(inputs, c, f["Evidencia"],
                                   int(re.sub(r"\D", "", f["Última iteración"]) or 0)).get("ruta", "")
            s = {"ruta": ruta}
            rel = ""
            if s.get("ruta") and (inputs / s["ruta"]).is_file():
                dst = destino / "sustento" / e["fichero"] / Path(s["ruta"]).name
                dst.parent.mkdir(parents=True, exist_ok=True)
                if not dst.exists():
                    shutil.copyfile(inputs / s["ruta"], dst)
                rel = dst.relative_to(destino).as_posix()
            elif f["Estado"] != "resuelto":
                incons.append(f"{c} · {f['ID']}: no se encontró el Excel de sustento "
                              f"«{f['Excel de sustento']}» entre lo recibido.")
            filas.append({**{k: f.get(k, "") for k in COLUMNAS_HALLAZGOS}, "Ruta del sustento": rel})
    todos_abiertos = [f for f in filas if f["Estado"] != "resuelto"]
    resumen = {
        "generado": _ahora(), "total": len(vc.ETAPAS),
        "cerradas": sum(1 for e in etapas if e["cerrada"]),
        "lista_para_validar": all(e["cerrada"] for e in etapas),
        "hallazgos": len(filas), "abiertos": len(todos_abiertos),
        "criticos": sum(1 for f in todos_abiertos if f["Severidad"] == "Crítico"),
        "moderados": sum(1 for f in todos_abiertos if f["Severidad"] == "Moderado"),
        "bajos": sum(1 for f in todos_abiertos if f["Severidad"] == "Potencial/Bajo"),
        "avisos": avisos}
    if not resumen["lista_para_validar"]:
        avisos.insert(0, "Faltan etapas por cerrar: " + ", ".join(
            e["etapa"] for e in etapas if not e["cerrada"]) + ". El consolidado es provisional.")
    cols = COLUMNAS_HALLAZGOS + ["Ruta del sustento"]
    xlsx, md = destino / f"{NOMBRE_CONSOLIDADO}.xlsx", destino / f"{NOMBRE_CONSOLIDADO}.md"
    with pd.ExcelWriter(xlsx) as w:
        pd.DataFrame([{"Etapa": e["etapa"], "Estado": e["estado"], "Iteraciones": e["iteraciones"],
                       "Hallazgos": e["hallazgos"], "Abiertos": e["abiertos"],
                       "Críticos abiertos": e["criticos"], "Inconsistencias": e["inconsistencias"],
                       "Excel de la etapa": e["excel"], ".md de la etapa": e["md"]} for e in etapas]
                     ).to_excel(w, sheet_name="Resumen", index=False)
        pd.DataFrame(filas, columns=cols).to_excel(w, sheet_name="Hallazgos", index=False)
        for e in etapas:
            propias = [f for f in filas if f["Etapa"].startswith(e["codigo"])]
            pd.DataFrame(propias, columns=cols).to_excel(w, sheet_name=_hoja(e["etapa"]), index=False)
        pd.DataFrame({"Inconsistencia": incons or ["Ninguna: los Excel y .md de las etapas coinciden."]}
                     ).to_excel(w, sheet_name="Inconsistencias", index=False)
    md.write_text(_md_consolidado(etapas, resumen, filas, incons), encoding="utf-8")
    datos = {"resumen": resumen, "etapas": etapas, "hallazgos": filas, "inconsistencias": incons,
             "excel": xlsx.name, "md": md.name}
    (destino / "consolidado.json").write_text(json.dumps(datos, ensure_ascii=False, indent=2),
                                              encoding="utf-8")
    return datos


def ultimo_consolidado(outputs: Path) -> Optional[dict[str, Any]]:
    p = Path(outputs) / "validacion_completa" / DIR_CONSOLIDADO / "consolidado.json"
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None
    except (OSError, ValueError):
        return None
