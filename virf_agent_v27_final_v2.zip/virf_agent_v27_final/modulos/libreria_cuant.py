"""
modulos/libreria_cuant.py
═══════════════════════════════════════════════════════════════════════════════
LIBRERÍA CUANTITATIVA que viaja DENTRO de los notebooks de la validación
completa (etapas 02 Modelamiento, 03 Impactos y 04 Seguimiento). Solo pandas y
numpy: corre en el equipo del validador, sin internet ni IA.

Las funciones son las del oficio: VaR / ES histórico y paramétrico, excepciones
con rezago, Kupiec, Christoffersen, semáforo de Basilea, PSI, SMM/CPR, tasas de
salida en estrés, Kaplan–Meier, curvas de run-off del saldo (cosechas y saldo
existente: S, R, d, estable/volátil, plazo económico, bandas y backtesting),
decaimiento y beta de depósitos, gap de reprecio, ΔEVE y
ΔNII ante un choque paralelo, LCR con topes, NSFR, brechas de liquidez, LaR,
horizonte de supervivencia, concentración (top-N, HHI) y PLA (Spearman, KS).

`col()` / `tabla()` leen las bases por ROL (concepto de negocio) con los dict
BASES y ROLES del notebook, así la réplica no depende de cómo se llame cada
columna en el banco.

El texto `LIBRERIA_CUANT` se EMBEBE en el notebook; aquí solo se valida con
`ast.parse` (nunca se ejecuta en el servidor). Los tests lo ejecutan sobre datos
sintéticos.
"""
from __future__ import annotations

__all__ = ["LIBRERIA_CUANT", "FUNCIONES_CUANT"]

LIBRERIA_CUANT = r'''
# ═══ Librería cuantitativa VIRF (pandas + numpy) ═══
import math
import re as _re_q

import numpy as np
import pandas as pd

_Z = {0.90: 1.2816, 0.95: 1.6449, 0.975: 1.9600, 0.99: 2.3263, 0.995: 2.5758, 0.999: 3.0902}


def ppf_normal(p):
    """Inversa de la normal estándar (Acklam). Sin scipy."""
    p = float(p)
    if round(p, 4) in _Z:
        return _Z[round(p, 4)]
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02, 1.383577518672690e+02,
         -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02, 6.680131188771972e+01,
         -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00, -2.549732539343734e+00,
         4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00, 3.754408661907416e+00]
    if p < 0.02425:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
               ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    if p > 1 - 0.02425:
        return -ppf_normal(1 - p)
    q = p - 0.5
    r = q * q
    return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / \
           (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)


def _chi2_1_sf(x):
    """P(χ²₁ > x)."""
    return math.erfc(math.sqrt(max(float(x), 0.0) / 2))


# ── Lectura por ROL ──
def col(base, rol):
    """Serie de la base lógica y el rol, según BASES y ROLES (None si falta)."""
    ds = BASES.get(base)
    df = bases.get(ds) if ds else None
    c = (ROLES.get(ds) or {}).get(rol) if ds else None
    return df[c] if (df is not None and c in df.columns) else None


def tabla(base, roles, opcionales=()):
    """DataFrame con las columnas de esos roles RENOMBRADAS al rol. None si falta un rol obligatorio."""
    ds = BASES.get(base)
    df = bases.get(ds) if ds else None
    if df is None:
        return None
    m = {}
    for r in list(roles) + list(opcionales):
        c = (ROLES.get(ds) or {}).get(r)
        if c in df.columns:
            m[c] = r
        elif r in roles:
            return None
    out = df[list(m)].rename(columns=m)
    for r in out.columns:
        if r.startswith("fecha"):
            out[r] = a_fecha(out[r])
    return out


def falta(base, roles):
    """Texto de lo que falta para leer la base por roles (para la tabla de réplica)."""
    ds = BASES.get(base)
    if not ds:
        return f"falta la base lógica «{base}» en BASES"
    if ds not in bases:
        return f"la base {ds!r} no está cargada"
    sin = [r for r in roles if (ROLES.get(ds) or {}).get(r) not in bases[ds].columns]
    return "sin enlazar: " + ", ".join(sin) if sin else ""


def a_fecha(s):
    """Serie a fechas: ISO (AAAA-MM-DD) como año-mes-día; el resto, día/mes/año."""
    if pd.api.types.is_datetime64_any_dtype(s):
        return s
    import warnings as _w
    with _w.catch_warnings():
        _w.simplefilter("ignore")
        t = pd.Series(s).astype(str).str.strip()
        iso = t.str.match(r"^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}")
        out = pd.to_datetime(t.where(~iso), errors="coerce", dayfirst=True)
        if iso.any():
            out = out.where(~iso, pd.to_datetime(t.where(iso), errors="coerce"))
        return out


def mes_indice(s):
    """Año × 12 + mes − 1 de una fecha o de un periodo «AAAA-MM» / «AAAAMM» (para contar meses entre fechas)."""
    s = pd.Series(s)
    t = s.astype(str).str.strip()
    ym = (pd.Series(False, index=s.index) if pd.api.types.is_datetime64_any_dtype(s)
          else t.str.fullmatch(r"\d{4}[-/.]?\d{1,2}").fillna(False).astype(bool))
    out = pd.Series(np.nan, index=s.index)
    if ym.any():
        p = t[ym].str.extract(r"^(\d{4})[-/.]?(\d{1,2})$").astype(float)
        out[ym] = p[0] * 12 + p[1] - 1
    if (~ym).any():
        f = a_fecha(s[~ym])
        out[~ym] = (f.dt.year * 12 + f.dt.month - 1).astype(float)
    return out


def edad_meses(fecha, cosecha):
    """Antigüedad en meses de la cosecha (mes de origen) en la fecha de observación."""
    return mes_indice(pd.Series(fecha).reset_index(drop=True)) - mes_indice(pd.Series(cosecha).reset_index(drop=True))


_RX_FECHA = _re_q.compile(r"(fecha|date|periodo|corte|fec_|venc|vto|apertura|cierre|desembolso)")


def norm_col(nombre):
    import unicodedata as _u
    s = "".join(c for c in _u.normalize("NFKD", str(nombre)) if not _u.combining(c)).lower()
    return _re_q.sub(r"[^a-z0-9]+", "_", s).strip("_")


def es_fecha(s):
    """¿La columna es una fecha? (tipo fecha, o texto con nombre de fecha que se lee como fecha)."""
    if pd.api.types.is_datetime64_any_dtype(s):
        return True
    if pd.api.types.is_numeric_dtype(s) or not _RX_FECHA.search(norm_col(s.name)):
        return False
    m = s.dropna().head(300)
    return bool(len(m)) and float(a_fecha(m).notna().mean()) >= 0.9


def tenor_anios(x):
    """Plazo de un nodo en años: '1M' → 0,083; '6M' → 0,5; '2Y'/'2A' → 2; '30D' → 0,082; 5 → 5 (años)."""
    if isinstance(x, (int, float, np.integer, np.floating)) and not pd.isna(x):
        return float(x) / 365.25 if float(x) > 60 else float(x)
    t = str(x).strip().upper().replace(" ", "")
    m = _re_q.fullmatch(r"(\d+(?:[.,]\d+)?)([DWMYA]?)", t)
    if not m:
        return np.nan
    n = float(m.group(1).replace(",", "."))
    return n * {"D": 1 / 365.25, "W": 7 / 365.25, "M": 1 / 12, "Y": 1.0, "A": 1.0, "": 1.0}[m.group(2)]


def comparar(paso, implementador, replicado, tolerancia_pct=1.0, fuente="", nota=""):
    """Fila de la hoja de réplica: implementador vs replicado, diferencia y conclusión."""
    fila = {"paso": paso, "fuente": fuente, "implementador": implementador, "replicado": replicado,
            "diferencia": None, "diferencia_pct": None, "conclusion": nota or "Sin valor del implementador"}
    try:
        a, b = float(implementador), float(replicado)
    except (TypeError, ValueError):
        return fila
    fila["diferencia"] = b - a
    fila["diferencia_pct"] = (abs(b - a) / abs(a) * 100) if a else (0.0 if b == 0 else None)
    ok = fila["diferencia_pct"] is not None and fila["diferencia_pct"] <= float(tolerancia_pct)
    fila["conclusion"] = (("Coincide" if ok else "Difiere") + f" (tolerancia {float(tolerancia_pct):g} %)"
                          + (f" · {nota}" if nota else ""))
    return fila


def comparar_pp(paso, implementador, replicado, tolerancia_pp=5.0, fuente="", nota=""):
    """Como `comparar`, para PROPORCIONES (0–1): la diferencia se juzga en puntos porcentuales."""
    fila = comparar(paso, implementador, replicado, 1e9, fuente, nota)
    if fila["diferencia"] is None:
        return fila
    pp = 100.0 * fila["diferencia"]
    fila["diferencia_pp"] = pp
    fila["conclusion"] = (("Coincide" if abs(pp) <= float(tolerancia_pp) else "Difiere")
                          + f" ({pp:+.1f} pp; tolerancia ±{float(tolerancia_pp):g} pp)" + (f" · {nota}" if nota else ""))
    return fila


def nivel_impacto(base, corregido, moderado_pct=5.0, critico_pct=10.0):
    """(impacto absoluto, impacto %, nivel) de pasar del valor base al corregido."""
    try:
        b, c = float(base), float(corregido)
    except (TypeError, ValueError):
        return None, None, "Sin cuantificar"
    rel = abs(c - b) / abs(b) * 100 if b else (0.0 if c == 0 else 100.0)
    nivel = "Crítico" if rel >= critico_pct else ("Moderado" if rel >= moderado_pct else "Potencial/Bajo")
    return c - b, rel, nivel


# ── Mercado ──
def var_historico(pnl, nivel=0.99):
    """VaR (pérdida en positivo) = −percentil (1 − nivel) del P&L."""
    s = pd.to_numeric(pd.Series(pnl), errors="coerce").dropna()
    return float(-np.quantile(s, 1 - nivel)) if len(s) else None


def es_historico(pnl, nivel=0.975):
    """Expected Shortfall (pérdida en positivo): media de la cola más allá del percentil."""
    s = pd.to_numeric(pd.Series(pnl), errors="coerce").dropna()
    if not len(s):
        return None
    q = np.quantile(s, 1 - nivel)
    return float(-s[s <= q].mean())


def var_parametrico(pnl, nivel=0.99):
    """VaR normal: z·σ − μ."""
    s = pd.to_numeric(pd.Series(pnl), errors="coerce").dropna()
    return float(ppf_normal(nivel) * s.std(ddof=1) - s.mean()) if len(s) > 1 else None


def excepciones(pnl, var, rezago=1, convencion="pnl_negativo"):
    """0/1 por día: pérdida de t > VaR de t − rezago. `pnl_negativo`: P&L con pérdidas en negativo."""
    p = pd.to_numeric(pd.Series(pnl), errors="coerce").reset_index(drop=True)
    v = pd.to_numeric(pd.Series(var), errors="coerce").abs().reset_index(drop=True).shift(rezago)
    perdida = -p if convencion == "pnl_negativo" else p
    ok = perdida.notna() & v.notna()
    return (perdida[ok] > v[ok]).astype(int)


def kupiec(x, n, nivel=0.99):
    """Test POF: (LR, p-valor). x excepciones en n días."""
    p = 1 - nivel
    if n <= 0:
        return None, None
    ph = x / n

    def ll(pi):
        if pi <= 0:
            return 0.0 if x == 0 else -math.inf
        if pi >= 1:
            return 0.0 if x == n else -math.inf
        return (n - x) * math.log(1 - pi) + x * math.log(pi)
    lr = 2 * (ll(ph) - ll(p))
    return lr, _chi2_1_sf(lr)


def christoffersen(exc):
    """Independencia de las excepciones: (LR_ind, p-valor)."""
    e = np.asarray(pd.Series(exc).dropna().astype(int))
    if len(e) < 3:
        return None, None
    a, b = e[:-1], e[1:]
    n00, n01 = int(((a == 0) & (b == 0)).sum()), int(((a == 0) & (b == 1)).sum())
    n10, n11 = int(((a == 1) & (b == 0)).sum()), int(((a == 1) & (b == 1)).sum())
    p01 = n01 / (n00 + n01) if (n00 + n01) else 0.0
    p11 = n11 / (n10 + n11) if (n10 + n11) else 0.0
    p = (n01 + n11) / (n00 + n01 + n10 + n11)

    def ll(q, k0, k1):
        return (k0 * math.log(1 - q) if k0 and q < 1 else 0.0) + (k1 * math.log(q) if k1 and q > 0 else 0.0)
    lr = -2 * (ll(p, n00 + n10, n01 + n11) - ll(p01, n00, n01) - ll(p11, n10, n11))
    return lr, _chi2_1_sf(lr)


def binom_cdf(k, n, p):
    return float(sum(math.comb(n, i) * p ** i * (1 - p) ** (n - i) for i in range(0, int(k) + 1)))


def semaforo(x, n=250, nivel=0.99):
    """Zona de Basilea: verde si P(X ≤ x) < 95 %, ámbar si < 99,99 %, roja si no."""
    pr = binom_cdf(x, n, 1 - nivel)
    return "verde" if pr < 0.95 else ("ámbar" if pr < 0.9999 else "roja")


def pla(hpl, rtpl):
    """Prueba de atribución de P&L (FRTB): (Spearman, KS, zona)."""
    d = pd.DataFrame({"h": pd.to_numeric(pd.Series(hpl), errors="coerce").values,
                      "r": pd.to_numeric(pd.Series(rtpl), errors="coerce").values}).dropna()
    if len(d) < 30:
        return None, None, "insuficiente"
    rho = float(np.corrcoef(d["h"].rank(), d["r"].rank())[0, 1])
    a, b = np.sort(d["h"].to_numpy()), np.sort(d["r"].to_numpy())
    t = np.concatenate([a, b])
    ks = float(np.max(np.abs(np.searchsorted(a, t, side="right") / len(a) - np.searchsorted(b, t, side="right") / len(b))))
    zona = "verde" if (rho > 0.80 and ks < 0.09) else ("roja" if (rho < 0.70 or ks > 0.12) else "ámbar")
    return rho, ks, zona


# ── Estabilidad ──
def psi(a, b, bins=10):
    """Population Stability Index entre dos muestras (numéricas o categóricas)."""
    a, b = pd.Series(a).dropna(), pd.Series(b).dropna()
    if len(a) < 10 or len(b) < 10:
        return None
    na, nb = pd.to_numeric(a, errors="coerce"), pd.to_numeric(b, errors="coerce")
    if na.notna().mean() > 0.95 and nb.notna().mean() > 0.95:
        cortes = np.unique(np.quantile(na.dropna(), np.linspace(0, 1, bins + 1)))
        if len(cortes) >= 3:
            cortes[0], cortes[-1] = -np.inf, np.inf
            pa = np.histogram(na.dropna(), cortes)[0] / na.notna().sum()
            pb = np.histogram(nb.dropna(), cortes)[0] / nb.notna().sum()
        else:
            cats = sorted(set(na.dropna()) | set(nb.dropna()))
            pa = np.array([(na == c).mean() for c in cats])
            pb = np.array([(nb == c).mean() for c in cats])
    else:
        cats = sorted(set(a.astype(str)) | set(b.astype(str)))
        pa = a.astype(str).value_counts(normalize=True).reindex(cats, fill_value=0).to_numpy()
        pb = b.astype(str).value_counts(normalize=True).reindex(cats, fill_value=0).to_numpy()
    pa, pb = np.clip(pa, 1e-6, None), np.clip(pb, 1e-6, None)
    return float(np.sum((pb - pa) * np.log(pb / pa)))


# ── ALM y conductuales ──
def smm_cpr(saldo_inicial, amortizacion, prepago):
    """(SMM, CPR) por fila: SMM = prepago ÷ (saldo inicial − amortización); CPR = 1 − (1 − SMM)^12."""
    s0 = pd.to_numeric(pd.Series(saldo_inicial), errors="coerce")
    am = pd.to_numeric(pd.Series(amortizacion), errors="coerce").fillna(0.0)
    pp = pd.to_numeric(pd.Series(prepago), errors="coerce")
    smm = pp / (s0 - am).where(lambda x: x > 0)
    return smm, 1 - (1 - smm.clip(0, 1)) ** 12


def tasas_runoff(fechas, saldos, horizonte_dias=30):
    """r_t = 1 − S(t+h) ÷ S(t) con el primer dato a h días o más (positivo = salida)."""
    d = pd.DataFrame({"f": a_fecha(pd.Series(fechas)).values,
                      "s": pd.to_numeric(pd.Series(saldos), errors="coerce").values}).dropna()
    d = d.groupby("f")["s"].sum().sort_index()
    f, s = d.index.to_numpy(), d.to_numpy(dtype=float)
    j = np.searchsorted(f, f + np.timedelta64(int(horizonte_dias), "D"), side="left")
    ok = (j < len(f)) & (s > 0)
    return pd.Series(1 - s[j[ok]] / s[ok], index=d.index[ok])


def kaplan_meier(duracion, evento):
    """Curva de supervivencia: DataFrame (t, S). `evento` 1 = cerró, 0 = censurada."""
    d = pd.DataFrame({"t": pd.to_numeric(pd.Series(duracion), errors="coerce").values,
                      "e": pd.to_numeric(pd.Series(evento), errors="coerce").fillna(0).astype(int).values}).dropna()
    s, filas = 1.0, [{"t": 0.0, "S": 1.0}]
    for t in np.sort(d.loc[d["e"] == 1, "t"].unique()):
        riesgo = int((d["t"] >= t).sum())
        muertes = int(((d["t"] == t) & (d["e"] == 1)).sum())
        if riesgo:
            s *= 1 - muertes / riesgo
        filas.append({"t": float(t), "S": s})
    return pd.DataFrame(filas)


# ── Run-off: supervivencia y desgaste del saldo ──
def supervivencia_cosechas(cosecha, edad, saldo, min_cosechas=2):
    """Curva del saldo por COSECHAS (link ratios): S(k) = Π_j Σ saldo_c(j) ÷ Σ saldo_c(j−1), sumando solo las
    cosechas observadas en j−1 y en j. DataFrame (t, S, cosechas)."""
    d = pd.DataFrame({"c": pd.Series(cosecha).astype(str).values,
                      "k": pd.to_numeric(pd.Series(edad), errors="coerce").values,
                      "s": pd.to_numeric(pd.Series(saldo), errors="coerce").values}).dropna()
    if d.empty:
        return pd.DataFrame(columns=["t", "S", "cosechas"])
    p = d.pivot_table(index="c", columns="k", values="s", aggfunc="sum").sort_index(axis=1)
    ks = [k for k in p.columns if k >= 0]
    if not ks:
        return pd.DataFrame(columns=["t", "S", "cosechas"])
    s, filas = 1.0, [{"t": float(ks[0]), "S": 1.0, "cosechas": int(p[ks[0]].notna().sum())}]
    for j0, j1 in zip(ks, ks[1:]):
        par = p[[j0, j1]].dropna()
        par = par[par[j0] > 0]
        if len(par) < int(min_cosechas):
            break
        s *= float(par[j1].sum() / par[j0].sum())
        filas.append({"t": float(j1), "S": s, "cosechas": int(len(par))})
    return pd.DataFrame(filas)


def supervivencia_saldo_existente(fecha, cosecha, saldo, plazo_max=60, min_cortes=3):
    """Run-off del SALDO EXISTENTE: en cada corte t0 se toman las cosechas ya vivas (sin el negocio nuevo
    posterior) y se mide cuánto de su saldo queda m meses después; S(m) = Σ_t0 saldo(t0+m) ÷ Σ_t0 saldo(t0).
    DataFrame (t, S, cortes)."""
    d = pd.DataFrame({"f": mes_indice(pd.Series(fecha).reset_index(drop=True)).values,
                      "c": pd.Series(cosecha).astype(str).values,
                      "s": pd.to_numeric(pd.Series(saldo), errors="coerce").values}).dropna()
    if d.empty:
        return pd.DataFrame(columns=["t", "S", "cortes"])
    m_ = d.pivot_table(index="f", columns="c", values="s", aggfunc="sum").sort_index()
    m_ = m_.reindex(np.arange(int(m_.index.min()), int(m_.index.max()) + 1))
    a = m_.to_numpy(dtype=float)
    vivo = np.nan_to_num(a) > 0
    filas = [{"t": 0.0, "S": 1.0, "cortes": int(vivo.any(axis=1).sum())}]
    for m in range(1, int(plazo_max) + 1):
        if m >= len(a):
            break
        den = float(np.sum(np.where(vivo[:-m], np.nan_to_num(a[:-m]), 0.0)))
        num = float(np.sum(np.where(vivo[:-m], np.nan_to_num(a[m:]), 0.0)))
        cortes = int(vivo[:-m].any(axis=1).sum())
        if cortes < int(min_cortes) or den <= 0:
            break
        filas.append({"t": float(m), "S": num / den, "cortes": cortes})
    return pd.DataFrame(filas)


def curva_runoff(t, S):
    """Completa la curva: t (meses), S, run-off acumulado R = 1 − S y desgaste incremental d(t) = S(t−1) − S(t)
    (S(0) = 1 si la curva empieza después de 0). S en 0–1 o en %."""
    d = pd.DataFrame({"t": pd.to_numeric(pd.Series(t), errors="coerce").values,
                      "S": pd.to_numeric(pd.Series(S), errors="coerce").values}).dropna()
    d = d.groupby("t", as_index=False)["S"].mean().sort_values("t").reset_index(drop=True)
    if len(d) and float(d["S"].quantile(0.75)) > 1:
        d["S"] = d["S"] / 100.0
    if d.empty:
        return d.assign(R=pd.Series(dtype=float), d=pd.Series(dtype=float))
    previo = np.concatenate([[1.0 if d["t"].iloc[0] > 0 else d["S"].iloc[0]], d["S"].to_numpy()[:-1]])
    return d.assign(R=1.0 - d["S"], d=previo - d["S"].to_numpy())


def _desde_cero(c):
    tt, ss = c["t"].to_numpy(dtype=float), c["S"].to_numpy(dtype=float)
    if len(tt) and tt[0] > 0:
        tt, ss = np.concatenate([[0.0], tt]), np.concatenate([[1.0], ss])
    return tt, ss


def plazo_economico(t, S, hasta_meses=None):
    """Plazo económico (vida media) en AÑOS: área bajo la curva ∫ S(t) dt (trapecios, desde S(0) = 1) hasta
    `hasta_meses` (por defecto el último plazo). Más allá de la curva se prolonga su último valor (el estable):
    para comparar dos curvas, mídelas al MISMO horizonte."""
    tt, ss = _desde_cero(curva_runoff(t, S))
    if len(tt) < 2:
        return None
    if hasta_meses:
        h = float(hasta_meses)
        if h > tt[-1]:
            tt, ss = np.append(tt, h), np.append(ss, ss[-1])
        else:
            s_h = float(np.interp(h, tt, ss))
            dentro = tt < h
            tt, ss = np.append(tt[dentro], h), np.append(ss[dentro], s_h)
    return float(np.sum((ss[1:] + ss[:-1]) / 2.0 * np.diff(tt))) / 12.0


def componentes_runoff(t, S, horizonte_meses=None):
    """(estable, volátil, horizonte usado): el ESTABLE es la proporción del saldo que sigue al horizonte largo
    (por defecto el último plazo; si el horizonte pasa la curva, se usa su último plazo); el VOLÁTIL, 1 − estable."""
    c = curva_runoff(t, S)
    if c.empty:
        return None, None, None
    h = min(float(horizonte_meses), float(c["t"].max())) if horizonte_meses else float(c["t"].max())
    tt, ss = _desde_cero(c)
    est = float(np.interp(h, tt, ss))
    return est, 1.0 - est, h


def limites_banda(etiqueta):
    """(desde, hasta) en MESES de una banda: «0-1M», «1-3M», «6-12M», «1-2A», «3-5Y», «>10A», «10A+» o «más de 5
    años» (hasta = ∞), «0-30D»; una sola cifra («3M») da (None, 3): empieza donde acaba la banda anterior."""
    t = str(etiqueta).upper().replace(" ", "")
    abierta = t.startswith((">", "MAS", "MÁS", "MAYOR", "+")) or t.endswith("+")
    for a, b in (("AÑOS", "A"), ("ANOS", "A"), ("AÑO", "A"), ("ANO", "A"), ("MESES", "M"), ("MES", "M"),
                 ("DÍAS", "D"), ("DIAS", "D"), ("Y", "A")):
        t = t.replace(a, b)
    nums = [float(x.replace(",", ".")) for x in _re_q.findall(r"(\d+(?:[.,]\d+)?)", t)]
    if not nums:
        return None
    u = t.rstrip("+")[-1:]
    f = {"A": 12.0, "D": 12.0 / 365.25}.get(u, 1.0)
    if abierta:
        return (nums[0] * f, np.inf)
    if len(nums) == 1:
        return (None, nums[0] * f)
    return (nums[0] * f, nums[1] * f)


def asignar_bandas(t, S, etiquetas):
    """Salida esperada por banda: la proporción del saldo de HOY que sale entre el inicio y el fin de cada banda,
    S(desde) − S(hasta); la última banda recibe además lo que sigue vivo al final, así todo el saldo queda
    asignado. DataFrame (banda, desde_meses, hasta_meses, proporcion)."""
    cols = ["banda", "desde_meses", "hasta_meses", "proporcion"]
    tt, ss = _desde_cero(curva_runoff(t, S))
    if not len(tt):
        return pd.DataFrame(columns=cols)

    def s_en(m):
        return 0.0 if not np.isfinite(m) else float(np.interp(m, tt, ss))

    lim = [[e, *limites_banda(e)] for e in dict.fromkeys(str(x) for x in etiquetas) if limites_banda(e)]
    lim.sort(key=lambda x: (x[1] if x[1] is not None else x[2], x[2]))
    previo = 0.0
    for x in lim:
        x[1] = previo if x[1] is None else x[1]
        previo = x[2]
    filas = [{"banda": e, "desde_meses": a, "hasta_meses": b, "proporcion": s_en(a) - s_en(b)} for e, a, b in lim]
    if filas and np.isfinite(filas[-1]["hasta_meses"]):
        filas[-1]["proporcion"] += s_en(filas[-1]["hasta_meses"])
    return pd.DataFrame(filas, columns=cols)


def curvas_del_modelo(crv):
    """Curva del modelo por segmento (t, S, R, d) desde la supervivencia, el run-off acumulado (S = 1 − R) o el
    desgaste incremental (S = 1 − Σ d). `crv`: tabla con plazo_meses y alguna de esas columnas."""
    out = {}
    for seg, g in (crv.groupby("segmento") if "segmento" in crv else [("TOTAL", crv)]):
        g = g.groupby("plazo_meses", as_index=False).mean(numeric_only=True).sort_values("plazo_meses")

        def esc(s):
            return s / (100.0 if s.dropna().quantile(0.75) > 1 else 1.0)

        if "supervivencia" in g and g["supervivencia"].notna().any():
            s = esc(g["supervivencia"])
        elif "runoff_acumulado" in g and g["runoff_acumulado"].notna().any():
            s = 1 - esc(g["runoff_acumulado"])
        elif "runoff_incremental" in g and g["runoff_incremental"].notna().any():
            dd = g["runoff_incremental"]                     # el desgaste suelto se juzga por su suma (≤ 100 %)
            s = 1 - (dd / (100.0 if (dd.max() > 1 or dd.sum() > 1.5) else 1.0)).cumsum()
        else:
            continue
        out[seg] = curva_runoff(g["plazo_meses"], s)
    return out


def replicar_runoff(sal, horizonte_meses=60, curva_de="cosecha", plazo_max=120):
    """Curva de run-off replicada con la experiencia histórica, por segmento. `sal`: tabla de saldos (fecha, saldo
    y, si existen, segmento, cosecha y edad). curva_de = "cosecha" (supervivencia desde el origen, link ratios) o
    "saldo_existente" (run-off del stock de cada corte, sin negocio nuevo). Sin cosechas solo queda el ajuste
    exponencial del saldo total, que mezcla el negocio nuevo: es un benchmark, no una réplica.
    Devuelve (curvas {segmento: DataFrame t, S, R, d}, resumen por segmento)."""
    if "cosecha" in sal and "edad" not in sal and "fecha" in sal:
        sal = sal.assign(edad=edad_meses(sal["fecha"], sal["cosecha"]).values)
    curvas, filas = {}, []
    for seg, g in (sal.groupby("segmento") if "segmento" in sal else [("TOTAL", sal)]):
        if "cosecha" in g and "fecha" in g and curva_de == "saldo_existente":
            k, metodo = supervivencia_saldo_existente(g["fecha"], g["cosecha"], g["saldo"], plazo_max), "saldo existente por corte"
        elif "cosecha" in g and "edad" in g:
            k, metodo = supervivencia_cosechas(g["cosecha"], g["edad"], g["saldo"]), "cosechas (link ratios)"
        else:
            lam = decaimiento(g["fecha"], g["saldo"])[0] if "fecha" in g else None
            if lam is None:
                continue
            tt = np.arange(0, int(plazo_max) + 1, dtype=float)
            k, metodo = pd.DataFrame({"t": tt, "S": np.exp(-lam * tt / 12.0)}), "exponencial del saldo total (benchmark)"
        if len(k) < 2:
            continue
        c = curva_runoff(k["t"], k["S"])
        est, vol, h = componentes_runoff(c["t"], c["S"], horizonte_meses)
        ult = float(g.loc[g["fecha"] == g["fecha"].max(), "saldo"].sum()) if "fecha" in g else float(g["saldo"].sum())
        curvas[seg] = c
        filas.append({"segmento": seg, "metodo": metodo, "plazo_max_meses": float(c["t"].max()),
                      "horizonte_estable_meses": h, "estable": est, "volatil": vol,
                      "plazo_economico_anios": plazo_economico(c["t"], c["S"]),
                      "sube_en_algun_plazo": bool((np.diff(c["S"].to_numpy()) > 0.005).any()), "saldo_ultimo": ult})
    return curvas, pd.DataFrame(filas)


def backtesting_runoff(sal, curva, meses=12, curva_de="cosecha"):
    """Backtesting del saldo EXISTENTE: toma las cosechas vivas en t0 = último mes − `meses` y compara su saldo
    realizado mes a mes con el que proyecta la curva del modelo (por cosecha S(a+m) ÷ S(a) si la curva es de
    cosechas; S(m) si es del saldo existente). DataFrame (mes, realizado, proyectado, error), en proporción de t0."""
    g = pd.DataFrame({"m": mes_indice(pd.Series(sal["fecha"]).reset_index(drop=True)).values,
                      "c": pd.Series(sal["cosecha"]).astype(str).values,
                      "s": pd.to_numeric(pd.Series(sal["saldo"]), errors="coerce").values}).dropna()
    if g.empty:
        return pd.DataFrame(columns=["mes", "realizado", "proyectado", "error"])
    t0 = g["m"].max() - int(meses)
    ini = g[(g["m"] == t0) & (g["s"] > 0)].groupby("c")["s"].sum()
    if ini.empty:
        return pd.DataFrame(columns=["mes", "realizado", "proyectado", "error"])
    base = float(ini.sum())
    tt, ss = _desde_cero(curva)
    edad0 = (t0 - mes_indice(pd.Series(ini.index))).to_numpy(dtype=float)
    s_a = np.interp(edad0, tt, ss)
    filas = []
    for m in range(1, int(meses) + 1):
        real = float(g[(g["m"] == t0 + m) & g["c"].isin(ini.index)]["s"].sum()) / base
        if curva_de == "saldo_existente":
            proy = float(np.interp(m, tt, ss))
        else:
            cond = np.where(s_a > 0, np.interp(edad0 + m, tt, ss) / np.where(s_a > 0, s_a, 1.0), 0.0)
            proy = float(np.sum(ini.to_numpy() * cond) / base)
        filas.append({"mes": m, "realizado": real, "proyectado": proy, "error": real - proy})
    return pd.DataFrame(filas)


def decaimiento(fechas, saldos):
    """Ajuste exponencial S_t = S_0·e^(−λt): (λ anual, vida media ≈ 1/λ en años, R²)."""
    d = pd.DataFrame({"f": a_fecha(pd.Series(fechas)).values,
                      "s": pd.to_numeric(pd.Series(saldos), errors="coerce").values}).dropna()
    d = d[d["s"] > 0].groupby("f")["s"].sum().sort_index()
    if len(d) < 6:
        return None, None, None
    t = (d.index - d.index[0]).days.to_numpy() / 365.25
    y = np.log(d.to_numpy())
    pend, inter = np.polyfit(t, y, 1)
    r2 = 1 - np.sum((y - (pend * t + inter)) ** 2) / max(np.sum((y - y.mean()) ** 2), 1e-12)
    lam = float(-pend)
    return lam, (1 / lam if lam > 0 else None), float(r2)


def beta_traspaso(tasa_pagada, tasa_mercado):
    """Beta = pendiente de Δtasa pagada sobre Δtasa de mercado (MCO)."""
    a = pd.to_numeric(pd.Series(tasa_pagada), errors="coerce").diff()
    b = pd.to_numeric(pd.Series(tasa_mercado), errors="coerce").diff()
    ok = a.notna() & b.notna()
    if ok.sum() < 6 or float(b[ok].var()) == 0:
        return None
    return float(np.cov(a[ok], b[ok])[0, 1] / b[ok].var())


def punto_medio_banda(etiqueta):
    """Punto medio en AÑOS de una banda «0-1M», «1-3M», «1-2A», «5-10Y», «>20A», «0-7D», «91-180D»."""
    t = str(etiqueta).upper().replace(" ", "").replace("AÑOS", "A").replace("ANOS", "A").replace("Y", "A")
    m = _re_q.findall(r"(\d+(?:[.,]\d+)?)", t)
    unidad = "A" if t.endswith("A") else ("M" if t.endswith("M") else ("D" if t.endswith("D") else "M"))
    f = {"A": 1.0, "M": 1 / 12, "D": 1 / 365}[unidad]
    nums = [float(x.replace(",", ".")) for x in m]
    if not nums:
        return None
    if t.startswith(">") or len(nums) == 1:
        return nums[0] * f * (1.25 if t.startswith(">") else 1.0)
    return (nums[0] + nums[1]) / 2 * f


def gap_por_banda(montos, bandas, lado=None, activos=("ACTIVO", "A", "ASSET")):
    """Gap por banda: activos − pasivos (si hay `lado`) o suma de montos con signo."""
    d = pd.DataFrame({"m": pd.to_numeric(pd.Series(montos), errors="coerce").values,
                      "b": pd.Series(bandas).astype(str).values})
    if lado is not None:
        es_act = pd.Series(lado).astype(str).str.strip().str.upper().isin([a.upper() for a in activos]).values
        d["m"] = np.where(es_act, d["m"].abs(), -d["m"].abs())
    g = d.groupby("b")["m"].sum()
    orden = sorted(g.index, key=lambda x: (punto_medio_banda(x) is None, punto_medio_banda(x) or 0))
    return g.reindex(orden)


def delta_eve_paralelo(gap, choque=0.02, tasa_base=0.0):
    """ΔEVE aproximado de un choque paralelo sobre el gap por banda (descuento continuo al punto medio)."""
    filas = []
    for banda, monto in gap.items():
        t = punto_medio_banda(banda)
        if t is None or pd.isna(monto):
            continue
        filas.append(monto * (math.exp(-(tasa_base + choque) * t) - math.exp(-tasa_base * t)))
    return float(sum(filas))


def delta_nii_paralelo(gap, choque=0.02, horizonte=1.0):
    """ΔNII a 12 meses: Σ gap de las bandas < horizonte × choque × (horizonte − punto medio)."""
    total = 0.0
    for banda, monto in gap.items():
        t = punto_medio_banda(banda)
        if t is not None and t < horizonte and pd.notna(monto):
            total += monto * choque * (horizonte - t)
    return float(total)


# ── Liquidez ──
def hqla_ajustado(n1, n2a, n2b):
    """HQLA con los topes de BCBS 238 (Nivel 2B ≤ 15 % y Nivel 2 ≤ 40 %), montos ya con descuento."""
    n1, n2a, n2b = float(n1), float(n2a), float(n2b)
    aj15 = max(n2b - 15 / 85 * (n1 + n2a), n2b - 15 / 60 * n1, 0.0)
    aj40 = max((n2a + n2b - aj15) - 2 / 3 * n1, 0.0)
    return n1 + n2a + n2b - aj15 - aj40


def lcr(hqla, salidas, entradas, tope_entradas=0.75):
    neto = float(salidas) - min(float(entradas), tope_entradas * float(salidas))
    return float(hqla) / neto if neto > 0 else None


def nsfr(asf_saldos, asf_factores, rsf_saldos, rsf_factores):
    asf = float((pd.to_numeric(pd.Series(asf_saldos), errors="coerce") *
                 pd.to_numeric(pd.Series(asf_factores), errors="coerce")).sum())
    rsf = float((pd.to_numeric(pd.Series(rsf_saldos), errors="coerce") *
                 pd.to_numeric(pd.Series(rsf_factores), errors="coerce")).sum())
    return asf, rsf, (asf / rsf if rsf else None)


def brechas(entradas, salidas, bandas):
    """Brecha por banda (entradas − salidas) y acumulada, en el orden de las bandas."""
    d = pd.DataFrame({"e": pd.to_numeric(pd.Series(entradas), errors="coerce").fillna(0).values,
                      "s": pd.to_numeric(pd.Series(salidas), errors="coerce").fillna(0).values,
                      "b": pd.Series(bandas).astype(str).values})
    g = d.groupby("b")[["e", "s"]].sum()
    g = g.reindex(sorted(g.index, key=lambda x: (punto_medio_banda(x) is None, punto_medio_banda(x) or 0)))
    g["brecha"] = g["e"] - g["s"]
    g["acumulada"] = g["brecha"].cumsum()
    return g.reset_index().rename(columns={"b": "banda", "e": "entradas", "s": "salidas"})


def lar_hist(fechas, flujo_neto, horizonte=30, nivel=0.99):
    """LaR = −percentil de la suma móvil a h días de los flujos netos (salida en positivo)."""
    d = pd.DataFrame({"f": a_fecha(pd.Series(fechas)).values,
                      "n": pd.to_numeric(pd.Series(flujo_neto), errors="coerce").values}).dropna()
    acum = d.groupby("f")["n"].sum().sort_index().rolling(int(horizonte)).sum().dropna()
    return float(max(0.0, -np.quantile(acum, 1 - nivel))) if len(acum) else None


def horizonte_supervivencia(salidas_netas_diarias, colchon):
    """Primer día en que las salidas netas acumuladas superan el colchón (None = sobrevive todo el horizonte)."""
    acum = pd.to_numeric(pd.Series(salidas_netas_diarias), errors="coerce").fillna(0).cumsum().to_numpy()
    k = np.where(acum > float(colchon))[0]
    return int(k[0]) + 1 if len(k) else None


def concentracion(montos, contrapartes, top=(10, 20)):
    """% del total de los top-N y HHI (0–10 000)."""
    d = pd.DataFrame({"m": pd.to_numeric(pd.Series(montos), errors="coerce").values,
                      "c": pd.Series(contrapartes).astype(str).values}).dropna()
    g = d.groupby("c")["m"].sum().sort_values(ascending=False)
    total = float(g.sum())
    if total <= 0:
        return {}
    out = {f"top_{n}": float(g.head(n).sum() / total * 100) for n in top}
    out["hhi"] = float(((g / total * 100) ** 2).sum())
    return out
'''.strip()

#: Funciones que ofrece la librería (para el prompt de las etapas y la guía).
FUNCIONES_CUANT = (
    "col(base, rol) · tabla(base, roles, opcionales) · falta(base, roles) · comparar(paso, implementador, "
    "replicado, tolerancia_pct) · comparar_pp(paso, implementador, replicado, tolerancia_pp) · mes_indice(s) · "
    "edad_meses(fecha, cosecha) · nivel_impacto(base, corregido) · var_historico(pnl, nivel) · "
    "es_historico(pnl, nivel) · var_parametrico(pnl, nivel) · excepciones(pnl, var, rezago, convencion) · "
    "kupiec(x, n, nivel) · christoffersen(exc) · semaforo(x, n, nivel) · pla(hpl, rtpl) · psi(a, b) · "
    "smm_cpr(saldo_inicial, amortizacion, prepago) · tasas_runoff(fechas, saldos, horizonte_dias) · "
    "kaplan_meier(duracion, evento) · supervivencia_cosechas(cosecha, edad, saldo) · "
    "supervivencia_saldo_existente(fecha, cosecha, saldo, plazo_max) · curva_runoff(t, S) · plazo_economico(t, S) · "
    "componentes_runoff(t, S, horizonte_meses) · limites_banda(etiqueta) · asignar_bandas(t, S, etiquetas) · "
    "curvas_del_modelo(curva) · replicar_runoff(saldos, horizonte_meses, curva_de) · "
    "backtesting_runoff(saldos, curva, meses, curva_de) · decaimiento(fechas, saldos) · beta_traspaso(tasa_pagada, tasa_mercado) · "
    "punto_medio_banda(etiqueta) · gap_por_banda(montos, bandas, lado) · delta_eve_paralelo(gap, choque) · "
    "delta_nii_paralelo(gap, choque) · hqla_ajustado(n1, n2a, n2b) · lcr(hqla, salidas, entradas) · "
    "nsfr(asf_saldos, asf_factores, rsf_saldos, rsf_factores) · brechas(entradas, salidas, bandas) · "
    "lar_hist(fechas, flujo_neto, horizonte, nivel) · horizonte_supervivencia(salidas_netas, colchon) · "
    "concentracion(montos, contrapartes)")
