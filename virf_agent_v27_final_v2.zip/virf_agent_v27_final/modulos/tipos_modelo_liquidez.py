"""
modulos/tipos_modelo_liquidez.py — fichas de negocio de la familia LIQUIDEZ.
Formato y uso: ver `modulos/tipos_modelo.py`.
"""
from __future__ import annotations


def _c(base, tipo, roles, que, por_que, crit="MEDIA", params=None, opcionales=(), ref=None,
       evidencia="", escala_p75=False, plantilla=False):
    d = {"base": base, "tipo": tipo, "roles": list(roles), "que": que, "por_que": por_que,
         "criticidad": crit, "params": dict(params or {})}
    if opcionales:
        d["opcionales"] = list(opcionales)
    if ref:
        d["ref"] = ref
    if evidencia:
        d["evidencia"] = evidencia
    if escala_p75:
        d["escala_p75"] = True
    if plantilla:
        d["plantilla"] = True
    return d


_CONTABILIDAD = {"id": "contabilidad", "nombre": "Balance contable", "granularidad": "corte × moneda × rubro",
                 "define": ["saldo"], "solo_por_nombre": True,
                 "roles": ["fecha_corte", "fecha", "moneda", "producto", "segmento", "cuenta_contable", "saldo"],
                 "alias": ["contabilidad", "contable", "balance", "gl", "cuadre", "eeff", "bc"],
                 "para_que": "Prueba que lo modelado es todo el balance (y solo el balance)."}

TIPOS = {
    # ─────────────────────────────────────────────────────────────────────────
    "lcr": {
        "nombre": "Ratio de cobertura de liquidez (RCL / LCR)",
        "familia": "Liquidez", "carpeta": "lar",
        "negocio": (
            "Exige activos líquidos de alta calidad (HQLA) suficientes para cubrir las salidas netas de un estrés "
            "de 30 días: LCR = HQLA ÷ (salidas − mín(entradas; 75 % de las salidas)) ≥ 100 %. Los HQLA se dividen "
            "en Nivel 1 (caja, encaje, soberanos: 0 % de descuento), 2A (15 %) y 2B (25–50 %), con topes: el Nivel "
            "2 no puede pasar del 40 % del total y el 2B del 15 %. Cada pasivo tiene una tasa de salida según su "
            "estabilidad (minorista estable 3–5 %, menos estable 10 %, mayorista operativo 25 %, no operativo "
            "40 %, financiero 100 %). La regulación local (RCL) sigue una lógica análoga: verifica sus factores."),
        "salidas": ["LCR / RCL diario por moneda", "HQLA ajustado por topes", "Salidas y entradas ponderadas"],
        "usos": ["Cumplimiento regulatorio diario", "Límites internos y alertas tempranas", "Gestión del colchón de liquidez"],
        "normativa": ["BCBS 238 (LCR, 2013): factores, descuentos y topes",
                      "Regulación local del ratio de cobertura de liquidez (RCL)"],
        "bases": [
            {"id": "hqla", "nombre": "Activos líquidos (HQLA)", "granularidad": "fecha × instrumento",
             "define": ["nivel_hqla", "haircut"],
             "roles": ["fecha", "instrumento", "moneda", "nivel_hqla", "valor_mercado", "haircut", "hqla"],
             "alias": ["hqla", "activos_liquidos", "colchon", "alac"],
             "para_que": "El numerador: qué activos cuentan y con qué descuento."},
            {"id": "salidas", "nombre": "Salidas ponderadas", "granularidad": "fecha × categoría",
             "define": ["tasa_salida"], "roles": ["fecha", "moneda", "categoria", "saldo", "tasa_salida", "salidas"],
             "alias": ["salidas", "outflows", "pasivos"], "para_que": "El denominador: cuánto sale en 30 días."},
            {"id": "entradas", "nombre": "Entradas ponderadas", "granularidad": "fecha × categoría",
             "define": ["tasa_entrada"], "roles": ["fecha", "moneda", "categoria", "saldo", "tasa_entrada", "entradas"],
             "alias": ["entradas", "inflows", "cobros"], "para_que": "Reducen el denominador (con tope del 75 %)."},
            {"id": "ratio", "nombre": "Ratio reportado", "granularidad": "fecha × moneda",
             "define": ["lcr"], "roles": ["fecha", "moneda", "hqla", "salidas", "entradas", "lcr", "limite"],
             "alias": ["ratio", "lcr", "rcl", "reporte"], "para_que": "Lo que se reporta y se replica."},
        ],
        "riesgos": ["Activos sin nivel o con descuento menor al regulatorio.",
                    "Topes del Nivel 2 y 2B no aplicados.", "Entradas sin el tope del 75 %.",
                    "Pasivos con tasa de salida inferior a la de su categoría.",
                    "Activos gravados (en garantía) contados como HQLA.",
                    "Días sin ratio o ratios negativos."],
        "controles": [
            _c("hqla", "completitud", ["nivel_hqla"], "Todo activo líquido tiene nivel (1, 2A, 2B).",
               "el nivel decide el descuento y los topes.", "ALTA", {"umbral_pct": 0.0}),
            _c("hqla", "rango", ["haircut"], "El descuento está entre 0 y 1 (o 0 y 100).", "fuera de rango infla o anula el HQLA.",
               "ALTA", {"minimo": 0.0, "umbral_pct": 0.0}, escala_p75=True),
            _c("hqla", "no_negativos", ["valor_mercado"], "El valor de los activos líquidos no es negativo.",
               "el HQLA es un stock: un valor negativo es un error de carga que reduce el colchón.", "ALTA", {"umbral_pct": 0.0}),
            _c("salidas", "completitud", ["tasa_salida"], "Toda categoría de pasivo tiene tasa de salida.",
               "sin tasa la categoría no sale en el estrés.", "ALTA", {"umbral_pct": 0.0}),
            _c("salidas", "rango", ["tasa_salida"], "Las tasas de salida están entre 0 y 1 (o 0 y 100).",
               "fuera de rango invalida el denominador.", "ALTA", {"minimo": 0.0, "umbral_pct": 0.0}, escala_p75=True),
            _c("salidas", "no_negativos", ["saldo"], "Los saldos de pasivos no son negativos.", "un saldo negativo (signo mezclado) resta salidas y sobrestima el ratio.", "ALTA",
               {"umbral_pct": 0.0}),
            _c("entradas", "rango", ["tasa_entrada"], "Las tasas de entrada están entre 0 y 1 (o 0 y 100).",
               "fuera de rango infla las entradas.", "ALTA", {"minimo": 0.0, "umbral_pct": 0.0}, escala_p75=True),
            _c("ratio", "no_negativos", ["lcr"], "El ratio no es negativo.", "un LCR negativo es imposible.", "ALTA",
               {"umbral_pct": 0.0}),
            _c("ratio", "serie_continua", ["fecha"], "Hay ratio todos los días hábiles.", "el cumplimiento es diario.",
               "ALTA", {"frecuencia": "B", "umbral_pct": 2.0}),
            _c("ratio", "unicidad", ["fecha"], "Un ratio por fecha (y moneda).", "dos ratios el mismo día dejan ambiguo cuál se reportó.",
               "ALTA", {"umbral_pct": 0.0}, opcionales=["moneda"]),
            _c("ratio", "saltos_serie", ["lcr", "fecha"], "El ratio no salta sin explicación.",
               "un salto suele ser un cambio de clasificación o un error de carga.", "MEDIA", {"k": 8.0, "umbral_pct": 1.0},
               opcionales=["moneda"]),
        ],
        "preguntas": ["Clasificación de activos por nivel y su sustento; activos gravados excluidos.",
                      "Tabla de tasas de salida y entrada por categoría y su fuente normativa.",
                      "Cómo se aplican los topes del Nivel 2/2B y de las entradas.", "Límites internos y alertas."],
        "etapas": {
            "00": ["Mapea HQLA por nivel, salidas y entradas por categoría, y el ratio reportado por moneda."],
            "01": ["Niveles y descuentos completos, tasas en rango y por categoría, ratio diario sin huecos."],
            "02": ["Recalcula el HQLA con descuentos y topes (Nivel 2 ≤ 40 %, 2B ≤ 15 %), las salidas y entradas "
                   "ponderadas con el tope del 75 % y el ratio; compáralo con el reportado."],
            "03": ["Impacto en el ratio de reclasificar activos o categorías mal asignadas."],
            "04": ["Ratio diario frente al mínimo y a los límites internos; alertas tempranas y su gestión."],
        },
        "metricas": ["LCR / RCL", "HQLA ajustado", "Salidas netas a 30 días"],
    },
    # ─────────────────────────────────────────────────────────────────────────
    "nsfr": {
        "nombre": "Ratio de financiamiento neto estable (RFNE / NSFR)",
        "familia": "Liquidez", "carpeta": "lar",
        "negocio": (
            "Compara el fondeo estable disponible (ASF: capital y pasivos ponderados por su estabilidad a un año) "
            "con el requerido (RSF: activos ponderados por su liquidez): NSFR = ASF ÷ RSF ≥ 100 %. Los factores "
            "ASF van de 0 % a 100 % (capital 100 %, depósitos minoristas estables 95 %, menos estables 90 %, "
            "mayoristas operativos 50 %); los RSF de 0 % (caja) a 100 % (activos ilíquidos)."),
        "salidas": ["NSFR / RFNE", "ASF y RSF por rubro"],
        "usos": ["Cumplimiento regulatorio", "Estructura de fondeo a mediano plazo"],
        "normativa": ["BCBS 295 (NSFR, 2014)", "Regulación local del ratio de financiamiento estable"],
        "bases": [
            {"id": "asf", "nombre": "Fondeo disponible (ASF)", "granularidad": "fecha × rubro",
             "define": ["factor_asf"], "roles": ["fecha", "categoria", "saldo", "factor_asf"],
             "alias": ["asf", "fondeo_disponible", "pasivos"], "para_que": "Numerador."},
            {"id": "rsf", "nombre": "Fondeo requerido (RSF)", "granularidad": "fecha × rubro",
             "define": ["factor_rsf"], "roles": ["fecha", "categoria", "saldo", "factor_rsf"],
             "alias": ["rsf", "fondeo_requerido", "activos"], "para_que": "Denominador."},
            {"id": "ratio", "nombre": "Ratio reportado", "granularidad": "fecha",
             "define": ["nsfr"], "roles": ["fecha", "nsfr", "limite"], "alias": ["ratio", "nsfr", "rfne"],
             "para_que": "Lo que se reporta."},
            _CONTABILIDAD,
        ],
        "riesgos": ["Factores fuera de [0, 1] o que no son los de la norma.", "Rubros sin factor.",
                    "ASF + RSF que no cuadran con el balance.", "Vencimientos mal asignados (< 6 meses, 6–12, > 1 año)."],
        "controles": [
            _c("asf", "rango", ["factor_asf"], "Los factores ASF están entre 0 y 1 (o 0 y 100).",
               "fuera de rango invalida el numerador.", "ALTA", {"minimo": 0.0, "umbral_pct": 0.0}, escala_p75=True),
            _c("asf", "completitud", ["factor_asf"], "Todo rubro tiene factor ASF.", "sin factor el rubro no cuenta.", "ALTA",
               {"umbral_pct": 0.0}),
            _c("rsf", "rango", ["factor_rsf"], "Los factores RSF están entre 0 y 1 (o 0 y 100).",
               "fuera de rango invalida el denominador.", "ALTA", {"minimo": 0.0, "umbral_pct": 0.0}, escala_p75=True),
            _c("rsf", "completitud", ["factor_rsf"], "Todo rubro tiene factor RSF.", "sin factor el rubro no requiere fondeo.",
               "ALTA", {"umbral_pct": 0.0}),
            _c("asf", "no_negativos", ["saldo"], "Los saldos no son negativos.", "un saldo con el signo cambiado resta fondeo estable disponible.", "ALTA", {"umbral_pct": 0.0}),
            _c("rsf", "no_negativos", ["saldo"], "Los saldos no son negativos.", "un saldo con el signo cambiado resta fondeo requerido y sobrestima el ratio.", "ALTA", {"umbral_pct": 0.0}),
            _c("ratio", "no_negativos", ["nsfr"], "El ratio no es negativo.", "un NSFR negativo es imposible: indica un error en ASF o RSF.", "ALTA", {"umbral_pct": 0.0}),
        ],
        "preguntas": ["Tabla de factores ASF/RSF por rubro y su fuente.", "Criterio de vencimiento residual por rubro.",
                      "Cuadre de la base con el balance."],
        "etapas": {
            "00": ["Mapea rubros con su saldo, vencimiento residual y factor ASF/RSF."],
            "01": ["Factores en rango y de la norma, rubros completos, cuadre con el balance."],
            "02": ["Recalcula ASF = Σ saldo × factor, RSF = Σ saldo × factor y el ratio; compáralo."],
            "03": ["Impacto de los factores o vencimientos mal asignados en el ratio."],
            "04": ["Evolución del ratio frente al mínimo y a los límites."],
        },
        "metricas": ["NSFR / RFNE", "ASF", "RSF"],
    },
    # ─────────────────────────────────────────────────────────────────────────
    "brechas_liquidez": {
        "nombre": "Brechas (gaps) de liquidez contractuales y conductuales",
        "familia": "Liquidez", "carpeta": "lar",
        "negocio": (
            "Reparte las entradas y salidas de efectivo (contractuales y con supuestos conductuales) en bandas "
            "temporales y calcula la brecha por banda y la acumulada. Una brecha acumulada negativa grande en "
            "las bandas cortas es una alerta de liquidez. Las bandas deben cubrir todo el balance y cuadrar con él."),
        "salidas": ["Brecha por banda y moneda", "Brecha acumulada", "Consumo de límites de brecha"],
        "usos": ["Límites de liquidez por banda", "Planificación de fondeo", "Reporte regulatorio de brechas"],
        "normativa": ["BCBS — principios de gestión del riesgo de liquidez (2008)", "Regulación local de liquidez (anexos de brechas)"],
        "bases": [
            {"id": "flujos", "nombre": "Flujos por banda", "granularidad": "corte × banda × moneda × rubro",
             "define": ["entradas", "salidas", "flujo"],
             "roles": ["fecha_corte", "fecha_flujo", "banda", "dias", "moneda", "categoria", "entradas", "salidas", "flujo", "saldo"],
             "alias": ["flujos", "brechas", "gaps", "bandas", "descalce"], "para_que": "La brecha por banda."},
            _CONTABILIDAD,
        ],
        "riesgos": ["Flujos sin banda o con banda que no corresponde a su fecha.", "Signos mezclados entre entradas y salidas.",
                    "Flujos anteriores al corte.", "Balance no cubierto por las bandas."],
        "controles": [
            _c("flujos", "completitud", ["banda"], "Todo flujo tiene banda.", "sin banda no hay brecha acumulada.", "ALTA",
               {"umbral_pct": 0.0}),
            _c("flujos", "no_negativos", ["entradas"], "Las entradas son magnitudes positivas.",
               "el signo va en la columna: mezclar convenciones invierte la brecha.", "MEDIA", {"umbral_pct": 0.0}),
            _c("flujos", "no_negativos", ["salidas"], "Las salidas son magnitudes positivas.",
               "el signo va en la columna: mezclar convenciones invierte la brecha.", "MEDIA", {"umbral_pct": 0.0}),
            _c("flujos", "consistencia_fechas", ["fecha_corte", "fecha_flujo"], "No hay flujos anteriores al corte.",
               "un flujo pasado no es liquidez futura.", "ALTA", {"operador": "<=", "umbral_pct": 0.0}),
            _c("flujos", "combinaciones_completas", ["banda", "moneda"], "Todas las bandas existen en todas las monedas.",
               "una banda vacía puede ser un hueco de carga.", "BAJA", {"umbral_pct": 0.0}),
            _c("flujos", "banda_coherente", ["dias", "banda"], "La banda corresponde a los días al flujo.",
               "completa `limites` y `etiquetas` con las bandas del manual.", "ALTA",
               {"limites": [0, 7, 15, 30, 60, 90, 180, 365, 36500],
                "etiquetas": ["0-7D", "8-15D", "16-30D", "31-60D", "61-90D", "91-180D", "181-365D", ">365D"],
                "umbral_pct": 0.0}, plantilla=True),
            _c("flujos", "conciliacion_totales", ["saldo"], "El saldo repartido en bandas cuadra con el balance.",
               "lo que no está en bandas no tiene brecha.", "ALTA", {"tolerancia_pct": 0.5},
               ref={"base": "contabilidad", "rol": "saldo"}),
        ],
        "preguntas": ["Bandas del manual y regla de asignación (contractual vs conductual).",
                      "Supuestos conductuales usados (NMD, prepago, renovaciones).", "Límites por banda."],
        "etapas": {
            "00": ["Mapea flujos por banda, moneda y rubro, y el balance de referencia."],
            "01": ["Bandas completas y coherentes con la fecha del flujo, signos, cuadre con el balance."],
            "02": ["Recalcula la brecha por banda (entradas − salidas) y la acumulada; compárala con la reportada."],
            "03": ["Impacto en la brecha acumulada de las bandas mal asignadas o del balance no cubierto."],
            "04": ["Brecha acumulada frente a límites y su evolución."],
        },
        "metricas": ["Brecha por banda", "Brecha acumulada"],
    },
    # ─────────────────────────────────────────────────────────────────────────
    "lar": {
        "nombre": "Liquidity at Risk (LaR, VaR de liquidez)",
        "familia": "Liquidez", "carpeta": "lar",
        "negocio": (
            "LaR estima, con la historia de flujos netos diarios, la salida neta acumulada máxima esperada en un "
            "horizonte (p. ej. 30 días) con un nivel de confianza (95–99 %): un «VaR de liquidez». Se compara con "
            "el colchón de activos líquidos para saber si alcanza."),
        "salidas": ["LaR por horizonte y moneda", "Cobertura del colchón"],
        "usos": ["Dimensionar el colchón de liquidez", "Límites internos"],
        "normativa": ["BCBS — principios de gestión del riesgo de liquidez (2008)"],
        "bases": [
            {"id": "flujos", "nombre": "Flujos netos diarios", "granularidad": "fecha × moneda",
             "define": ["flujo_neto", "entradas", "salidas"],
             "roles": ["fecha", "moneda", "categoria", "entradas", "salidas", "flujo_neto"],
             "alias": ["flujos", "flujos_diarios", "caja", "tesoreria"], "para_que": "La distribución de los flujos netos."},
            {"id": "resultado", "nombre": "LaR reportado", "granularidad": "fecha × moneda",
             "define": ["lar_valor"], "roles": ["fecha", "moneda", "lar_valor", "limite"],
             "alias": ["lar", "resultado", "reporte"], "para_que": "Lo que se reporta."},
        ],
        "riesgos": ["Huecos de días (la ventana móvil salta).", "Flujos duplicados por fecha.",
                    "Saltos por operaciones extraordinarias no marcadas.", "Ventana corta sin estrés."],
        "controles": [
            _c("flujos", "serie_continua", ["fecha"], "La serie diaria de flujos no tiene huecos.",
               "la suma móvil del horizonte se rompe con los huecos.", "ALTA", {"frecuencia": "B", "umbral_pct": 2.0}),
            _c("flujos", "completitud", ["flujo_neto"], "El flujo neto está informado todos los días.",
               "un nulo es un día sin salida aparente.", "ALTA", {"umbral_pct": 0.0}),
            _c("flujos", "unicidad", ["fecha"], "Un flujo neto por fecha (y moneda).", "duplicados duplican salidas.",
               "ALTA", {"umbral_pct": 0.0}, opcionales=["moneda", "categoria"]),
            _c("flujos", "saltos_serie", ["flujo_neto", "fecha"], "Sin saltos extraordinarios sin marcar.",
               "una operación extraordinaria domina el percentil.", "MEDIA", {"k": 12.0, "umbral_pct": 0.5},
               opcionales=["moneda"]),
            _c("flujos", "volumen_minimo", [], "La historia tiene al menos 500 días.", "el percentil alto necesita ventana.",
               "MEDIA", {"min_filas": 500.0}),
        ],
        "preguntas": ["Horizonte, nivel de confianza y ventana.", "Tratamiento de operaciones extraordinarias.",
                      "Comparación con el colchón y límites."],
        "etapas": {
            "00": ["Mapea la serie de flujos netos diarios por moneda y el LaR reportado."],
            "01": ["Serie diaria completa, sin duplicados, operaciones extraordinarias marcadas."],
            "02": ["Replica el LaR: suma móvil de los flujos netos a h días y su percentil (pérdida en positivo)."],
            "03": ["Impacto en el LaR de depurar los huecos y las operaciones extraordinarias."],
            "04": ["Salidas realizadas a h días frente al LaR (excedencias)."],
        },
        "metricas": ["LaR a h días", "Excedencias del LaR"],
    },
    # ─────────────────────────────────────────────────────────────────────────
    "stress_liquidez": {
        "nombre": "Estrés de liquidez y horizonte de supervivencia",
        "familia": "Liquidez", "carpeta": "lar",
        "negocio": (
            "Proyecta día a día las salidas y entradas de un escenario de estrés (idiosincrático, sistémico y "
            "combinado) y calcula cuántos días alcanza el colchón de activos líquidos antes de agotarse: el "
            "horizonte de supervivencia. Usa tasas de run-off, de renovación y de descuento de activos."),
        "salidas": ["Horizonte de supervivencia por escenario", "Brecha diaria acumulada vs colchón"],
        "usos": ["Apetito de riesgo de liquidez", "Plan de contingencia", "Límites internos"],
        "normativa": ["BCBS — principios de gestión del riesgo de liquidez (2008)", "Regulación local de estrés de liquidez"],
        "bases": [
            {"id": "proyeccion", "nombre": "Proyección diaria por escenario", "granularidad": "escenario × día",
             "define": ["salidas", "entradas"],
             "roles": ["escenario", "fecha", "dias", "moneda", "entradas", "salidas", "flujo_neto", "hqla"],
             "alias": ["proyeccion", "estres", "stress", "escenarios"], "para_que": "La brecha diaria bajo estrés."},
        ],
        "riesgos": ["Días faltantes en la proyección.", "Escenarios incompletos.", "Signos mezclados.", "Colchón sin descuentos."],
        "controles": [
            _c("proyeccion", "combinaciones_completas", ["escenario", "dias"], "Cada escenario tiene todos los días del horizonte.",
               "un día faltante esconde la salida de ese día.", "ALTA", {"umbral_pct": 0.0}),
            _c("proyeccion", "no_negativos", ["salidas"], "Las salidas son magnitudes positivas.", "mezclar el signo de las salidas invierte la brecha diaria del estrés.",
               "MEDIA", {"umbral_pct": 0.0}),
            _c("proyeccion", "no_negativos", ["hqla"], "El colchón no es negativo.", "el colchón es un stock: si es negativo, el horizonte de supervivencia sale falso.", "ALTA",
               {"umbral_pct": 0.0}),
            _c("proyeccion", "completitud", ["salidas"], "Las salidas están informadas.", "un nulo es un día sin salida.",
               "ALTA", {"umbral_pct": 0.0}),
        ],
        "preguntas": ["Narrativa y severidad de cada escenario.", "Tasas de run-off, renovación y descuento usadas.",
                      "Horizonte mínimo exigido por el apetito de riesgo."],
        "etapas": {
            "00": ["Mapea la proyección diaria por escenario y el colchón."],
            "01": ["Días completos por escenario, signos, colchón con descuentos."],
            "02": ["Replica el horizonte: primer día en que las salidas netas acumuladas superan el colchón."],
            "03": ["Impacto en el horizonte de corregir las tasas de run-off o los días faltantes."],
            "04": ["Horizonte de supervivencia frente al apetito y su evolución."],
        },
        "metricas": ["Horizonte de supervivencia (días)", "Peor escenario"],
    },
    # ─────────────────────────────────────────────────────────────────────────
    "concentracion_fondeo": {
        "nombre": "Concentración de fondeo y principales depositantes",
        "familia": "Liquidez", "carpeta": "lar",
        "negocio": (
            "Mide cuánto del fondeo depende de pocos depositantes o grupos económicos (top 10, top 20, índice de "
            "Herfindahl). La salida de un gran depositante no es estadística: debe tratarse aparte del run-off "
            "minorista. Para medirla bien hay que identificar al mismo cliente bajo distintos códigos y agruparlo "
            "con sus vinculados."),
        "salidas": ["% del fondeo de los 10 / 20 mayores", "Índice de Herfindahl (HHI)"],
        "usos": ["Límites de concentración", "Estrés de liquidez idiosincrático"],
        "normativa": ["BCBS — herramientas de monitoreo de liquidez (concentración de fondeo, 2013)"],
        "bases": [
            {"id": "depositantes", "nombre": "Saldos por depositante", "granularidad": "fecha × depositante",
             "define": ["contraparte"], "roles": ["fecha", "contraparte", "grupo_economico", "segmento", "moneda", "saldo"],
             "alias": ["depositantes", "clientes", "concentracion", "top", "principales"],
             "para_que": "Ranking de depositantes y grupos."},
        ],
        "riesgos": ["El mismo cliente con varios códigos (la concentración sale diluida).",
                    "Grupos económicos sin identificar.", "Saldos negativos o duplicados por fecha."],
        "controles": [
            _c("depositantes", "completitud", ["contraparte"], "Todo saldo tiene depositante identificado.",
               "un saldo anónimo no entra al ranking.", "ALTA", {"umbral_pct": 0.0}),
            _c("depositantes", "unicidad", ["contraparte"], "Un saldo por depositante y fecha (y moneda).",
               "duplicados inflan la concentración.", "ALTA", {"umbral_pct": 0.0}, opcionales=["fecha", "moneda"]),
            _c("depositantes", "no_negativos", ["saldo"], "Los saldos no son negativos.", "un saldo negativo baja la concentración del depositante y esconde el riesgo.", "ALTA",
               {"umbral_pct": 0.0}),
            _c("depositantes", "completitud", ["grupo_economico"], "Los depositantes tienen grupo económico.",
               "sin grupo no se suma a los vinculados.", "MEDIA", {"umbral_pct": 5.0}),
        ],
        "preguntas": ["Identificación única de clientes y grupos económicos.", "Límites de concentración y su seguimiento."],
        "etapas": {
            "00": ["Mapea saldos por depositante, su código único y su grupo económico."],
            "01": ["Depositantes identificados, sin duplicados, grupos asignados."],
            "02": ["Recalcula el % del top 10/20 y el HHI por fecha (agrupando vinculados)."],
            "03": ["Impacto de agrupar códigos del mismo cliente en la concentración."],
            "04": ["Evolución de la concentración frente a límites."],
        },
        "metricas": ["% top 10 / top 20", "HHI"],
    },
}
