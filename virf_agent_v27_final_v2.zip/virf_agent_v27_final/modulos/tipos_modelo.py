"""
modulos/tipos_modelo.py
═══════════════════════════════════════════════════════════════════════════════
CONOCIMIENTO DE NEGOCIO POR TIPO DE MODELO.

El dominio (VaR · ALM · LaR) dice la familia; el TIPO DE MODELO dice qué hace
el modelo y, por tanto, qué hay que revisar: un VaR no se valida como un
run-off, ni un prepago como un LCR. Cada tipo tiene una FICHA (en
`tipos_modelo_trading.py`, `tipos_modelo_alm.py` y `tipos_modelo_liquidez.py`):

  · negocio      qué hace el modelo, para qué se usa y cómo se prueba;
  · bases        las bases lógicas que usa (P&L diario, historia de factores,
                 saldos por segmento…), con los ROLES que las definen;
  · riesgos      qué puede fallar en los datos y por qué importa;
  · controles    controles de datos del catálogo expresados por ROLES (no por
                 nombres de columna): se enlazan con las columnas reales;
  · preguntas    qué pedir a la primera línea;
  · etapas       pasos de experto para cada chat de la validación completa
                 (00 Diagnóstico · 01 Control de datos · 02 Modelamiento ·
                 03 Impactos · 04 Seguimiento);
  · metricas     lo que se replica (02) y se vigila (04).

El tipo de modelo lo ELIGE el validador en la ficha del modelo (nunca se
deduce de los datos). Lo único que se calcula aquí es el ENLACE de los roles
con las columnas del perfil (por nombre y familia de dato), que el notebook
muestra en `BASES` y `ROLES` para que el validador lo confirme o lo corrija.
"""
from __future__ import annotations

import re
import unicodedata
from typing import Any, Iterable, Optional

__all__ = ["ROLES", "TIPOS", "FAMILIAS", "ETAPAS_CODIGOS", "norm", "tipo", "validar_tipos",
           "tipos_de_carpeta", "catalogo_para_ui", "carpetas_de_tipos", "enlazar",
           "controles_negocio", "ficha_md", "texto_para_prompt", "pasos_etapa",
           "preguntas", "descripcion_rol"]

ETAPAS_CODIGOS = ("00", "01", "02", "03", "04")
FAMILIAS = {"Trading": "var", "ALM": "alm", "Liquidez": "lar"}


def norm(nombre: Any) -> str:
    """Nombre de columna normalizado: minúsculas, sin tildes, «_» como separador."""
    s = "".join(c for c in unicodedata.normalize("NFKD", str(nombre or ""))
                if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")


# ═════════════════════════════════════════════════════════════════════════════
# ROLES: el concepto de negocio que cumple una columna
# ═════════════════════════════════════════════════════════════════════════════
#
# patron   expresión regular sobre el nombre normalizado de la columna.
# familia  num | fecha | texto | cualquiera (debe coincidir con el tipo de dato).
# que      descripción para el validador (sale en el notebook y en el prompt).
# equivale roles más específicos que, si están enlazados en la misma base,
#          sirven como este (p. ej. «pnl» es el «pnl_hipotetico» si existe).

ROLES: dict[str, dict[str, Any]] = {
    # ── Fechas ──
    "fecha": {"patron": r"(^|_)(fecha|fec|date|dia|periodo|corte)(_|$)|^fecha|^date",
              "familia": "fecha", "que": "Fecha de la observación (día o periodo)",
              "equivale": ["fecha_corte"]},
    "fecha_corte": {"patron": r"(corte|proceso|reporte|snapshot|as_?of|fecha_?dato|fecha_?info)",
                    "familia": "fecha", "que": "Fecha de corte de la foto (la fecha del dato)"},
    "fecha_inicio": {"patron": r"(desembols|apertura|origina|inicio|emision|contrata|fecha_?valor|"
                               r"trade_?date|fecha_?alta|fecha_?operacion|fecha_?colocacion)",
                     "familia": "fecha", "que": "Fecha de origen (desembolso, apertura, contratación)"},
    "fecha_vencimiento": {"patron": r"(venc|vto|maturity|expira|fecha_?fin_?contrato)",
                          "familia": "fecha", "que": "Fecha de vencimiento contractual"},
    "fecha_reprecio": {"patron": r"(reprec|repricing|reset|revision_?(de_)?tasa|prox_?revision)",
                       "familia": "fecha", "que": "Próxima fecha de reprecio de la tasa"},
    "fecha_cierre": {"patron": r"(cierre|cancela|(^|_)baja|fecha_?fin(_|$)|fecha_?salida|fecha_?retiro|close)",
                     "familia": "fecha", "que": "Fecha de cierre o cancelación"},
    "fecha_flujo": {"patron": r"(fecha_?(flujo|pago|cobro|cupon|liquida)|payment_?date|cash_?flow_?date|settle)",
                    "familia": "fecha", "que": "Fecha en que ocurre el flujo"},
    # ── Montos ──
    "saldo": {"patron": r"(saldo|balance|outstanding|(^|_)stock(_|$)|capital_?vivo|principal_?vivo)",
              "familia": "num", "que": "Saldo (stock) a la fecha", "equivale": ["saldo_final"]},
    "saldo_inicial": {"patron": r"(saldo_?(inicial|inicio|ini|anterior|apertura)|balance_?(start|ini|begin))",
                      "familia": "num", "que": "Saldo al inicio del periodo"},
    "saldo_final": {"patron": r"(saldo_?(final|fin|cierre)|balance_?(end|fin))",
                    "familia": "num", "que": "Saldo al final del periodo"},
    "nominal": {"patron": r"(nominal|nocional|notional|face_?value|monto_?original|monto_?desembolso)",
                "familia": "num", "que": "Nominal o monto original de la operación"},
    "valor_mercado": {"patron": r"(valor_?(de_)?mercado|market_?value|(^|_)mtm(_|$)|valor_?razonable|fair_?value|"
                                r"(^|_)npv(_|$)|(^|_)vpn(_|$))",
                      "familia": "num", "que": "Valor de mercado / razonable de la posición"},
    "flujo": {"patron": r"((^|_)flujo(_|$)|(^|_)flujo_?(total|caja)|cash_?flow|cashflow|(^|_)cf(_|$))",
              "familia": "num", "que": "Flujo de caja (capital + interés)"},
    "entradas": {"patron": r"(entrada|ingreso|inflow|cobro)", "familia": "num",
                 "que": "Entradas de efectivo"},
    "salidas": {"patron": r"(salida|egreso|outflow|retiro)", "familia": "num",
                "que": "Salidas de efectivo"},
    "interes": {"patron": r"(interes|interest|cupon|coupon)", "familia": "num",
                "que": "Interés del flujo o del periodo"},
    "amortizacion": {"patron": r"(amortiza|(^|_)amort(_|$)|cuota_?capital|principal_?pago|repago)",
                     "familia": "num", "que": "Amortización programada de capital"},
    "prepago": {"patron": r"(prepago|prepay|precancel|pago_?anticipado|amortizacion_?anticipada)",
                "familia": "num", "que": "Monto prepagado (pago antes de lo pactado)"},
    "num_cuentas": {"patron": r"((num|nro|n|cant|cantidad)_?(de_)?(cuentas|clientes|operaciones)|(^|_)cuentas(_|$))",
                    "familia": "num", "que": "Número de cuentas, clientes u operaciones"},
    # ── Tasas y factores ──
    "tasa": {"patron": r"(^|_)(tasa|tea|tna|tem|rate|yield|tir)(_|$)", "familia": "num",
             "que": "Tasa de interés de la operación"},
    "tasa_mercado": {"patron": r"(tasa_?(de_)?mercado|interbancari|tasa_?(de_)?referencia|tasa_?politica|"
                               r"benchmark|tasa_?swap|tasa_?libre)",
                     "familia": "num", "que": "Tasa de mercado de referencia"},
    "tasa_pagada": {"patron": r"tasa_?(pagada|pasiva|deposito|cliente|producto)", "familia": "num",
                    "que": "Tasa que paga el banco al depositante"},
    "spread": {"patron": r"(spread|margen|diferencial|sobretasa)", "familia": "num",
               "que": "Spread sobre el índice de referencia"},
    "tasa_ftp": {"patron": r"((^|_)ftp|tasa_?(de_)?transferencia|precio_?(de_)?transferencia|(^|_)tit(_|$))",
                 "familia": "num", "que": "Tasa de transferencia interna (FTP)"},
    "cpr": {"patron": r"(^|_)(cpr|smm|tasa_?(de_)?prepago|prepayment_?rate)(_|$)", "familia": "num",
            "que": "Tasa de prepago (SMM mensual o CPR anual)"},
    "beta": {"patron": r"(^|_)beta(_|$)", "familia": "num",
             "que": "Beta de traspaso de tasas de mercado a la tasa pagada"},
    "tasa_salida": {"patron": r"(tasa_?(de_)?(salida|retiro|run_?off)|run_?off|runoff|factor_?(de_)?salida|"
                              r"outflow_?rate|ponderador_?salida)",
                    "familia": "num", "que": "Tasa de salida (run-off) en el horizonte de estrés"},
    "tasa_entrada": {"patron": r"(tasa_?(de_)?entrada|inflow_?rate|factor_?(de_)?entrada|ponderador_?entrada)",
                     "familia": "num", "que": "Tasa (ponderador) de las entradas"},
    "haircut": {"patron": r"(haircut|castigo|descuento_?(hqla|valor)|recorte|aforo)", "familia": "num",
                "que": "Descuento (haircut) aplicado al activo"},
    "factor_asf": {"patron": r"((^|_)asf|factor_?(de_)?fondeo_?disponible|(^|_)fde(_|$))", "familia": "num",
                   "que": "Factor ASF (fondeo estable disponible)"},
    "factor_rsf": {"patron": r"((^|_)rsf|factor_?(de_)?fondeo_?requerido|(^|_)fdr(_|$))", "familia": "num",
                   "que": "Factor RSF (fondeo estable requerido)"},
    "factor_descuento": {"patron": r"(factor_?(de_)?descuento|discount_?factor|(^|_)df(_|$))", "familia": "num",
                         "que": "Factor de descuento de la curva"},
    "supervivencia": {"patron": r"(supervivencia|survival|sobrevivencia|permanencia|(^|_)s_?t(_|$))",
                      "familia": "num", "que": "Proporción que sobrevive (curva de supervivencia)"},
    # ── Clasificaciones ──
    "moneda": {"patron": r"(^|_)(moneda|divisa|currency|ccy|mon)(_|$)", "familia": "texto",
               "que": "Moneda"},
    "segmento": {"patron": r"(segmento|segment|(^|_)banca(_|$)|tipo_?cliente|tipo_?persona|categoria_?cliente)",
                 "familia": "texto", "que": "Segmento (minorista/mayorista, banca, tipo de cliente)"},
    "producto": {"patron": r"(producto|product|subproducto|tipo_?(de_)?(credito|deposito|cuenta))",
                 "familia": "texto", "que": "Producto"},
    "cartera": {"patron": r"(cartera|portafolio|portfolio|(^|_)libro(_|$)|(^|_)book(_|$)|(^|_)mesa(_|$)|desk)",
                "familia": "texto", "que": "Cartera, libro o mesa"},
    "instrumento": {"patron": r"(instrumento|(^|_)isin(_|$)|cusip|ticker|nemonico|tipo_?operacion)",
                    "familia": "texto", "que": "Instrumento"},
    "banda": {"patron": r"(banda|bucket|tramo|time_?band)", "familia": "cualquiera",
              "que": "Banda temporal (bucket) asignada"},
    "categoria": {"patron": r"(categoria|rubro|concepto|clasificacion|tipo_?(de_)?(flujo|fondeo|pasivo|activo))",
                  "familia": "texto", "que": "Categoría regulatoria o de gestión"},
    "activo_pasivo": {"patron": r"(activo_?pasivo|tipo_?balance|lado_?balance|asset_?liab|naturaleza|clase_?balance)",
                      "familia": "texto", "que": "Activo o pasivo"},
    "tipo_tasa": {"patron": r"(tipo_?(de_)?tasa|fija_?variable|rate_?type|fixed_?float|tipo_?interes)",
                  "familia": "texto", "que": "Tipo de tasa (fija / variable)"},
    "indice_referencia": {"patron": r"((^|_)indice(_|$)|(^|_)index(_|$)|tasa_?ref(_|$)|(^|_)referencia(_|$)|"
                                    r"libor|sofr|euribor)",
                          "familia": "texto", "que": "Índice de referencia de la tasa variable"},
    "nivel_hqla": {"patron": r"((^|_)nivel(_|$)|(^|_)level(_|$)|categoria_?hqla|clase_?hqla|nivel_?hqla|"
                             r"tipo_?activo_?liquido)",
                   "familia": "texto", "que": "Nivel del activo líquido (1, 2A, 2B)"},
    "escenario": {"patron": r"(escenario|scenario|shock_?id|stress_?id)", "familia": "texto",
                  "que": "Escenario"},
    "factor": {"patron": r"((^|_)factor(_|$)|risk_?factor|id_?factor|factor_?(de_)?riesgo|(^|_)curva(_|$)|"
                         r"subyacente)",
               "familia": "texto", "que": "Factor de riesgo (curva, tipo de cambio, precio…)"},
    "tenor": {"patron": r"(tenor|vertice|plazo_?nodo|(^|_)nodo(_|$)|(^|_)term(_|$))", "familia": "cualquiera",
              "que": "Plazo del nodo de la curva (1M, 3M, 1Y…)"},
    "contraparte": {"patron": r"(contraparte|counterparty|depositante|id_?cliente|cod_?cliente|(^|_)cliente(_|$)|"
                              r"(^|_)ruc(_|$))",
                    "familia": "cualquiera", "que": "Contraparte o cliente"},
    "grupo_economico": {"patron": r"(grupo_?economico|(^|_)grupo(_|$)|holding|vinculad)", "familia": "cualquiera",
                        "que": "Grupo económico (clientes vinculados)"},
    "netting_set": {"patron": r"(netting|conjunto_?(de_)?compensacion|acuerdo_?(de_)?compensacion|(^|_)csa(_|$))",
                    "familia": "cualquiera", "que": "Conjunto de compensación (netting set / CSA)"},
    "nivel_jerarquia": {"patron": r"(jerarquia|fair_?value_?level|nivel_?(vr|valor_?razonable|ifrs|niif))",
                        "familia": "cualquiera", "que": "Nivel de jerarquía de valor razonable (1, 2, 3)"},
    "estado": {"patron": r"(^|_)(estado|status|situacion|vigente|activa)(_|$)", "familia": "cualquiera",
               "que": "Estado de la cuenta u operación"},
    "cosecha": {"patron": r"(cosecha|vintage|cohorte|cohort|mes_?(de_)?origen|anio_?origen)",
                "familia": "cualquiera", "que": "Cosecha (mes de origen)"},
    "indicador_cancelacion": {"patron": r"(cancel|precancel|redencion|early_?(redemption|withdrawal)|"
                                        r"retiro_?anticipado)",
                              "familia": "cualquiera", "que": "Marca de cancelación anticipada"},
    "indicador_renovacion": {"patron": r"(renov|rollover|roll_?over)", "familia": "cualquiera",
                             "que": "Marca de renovación al vencimiento"},
    "evento": {"patron": r"(^|_)(evento|event|censura|censored|cerrada|flag_?cierre)(_|$)",
               "familia": "cualquiera", "que": "Marca de evento (1 = cerró, 0 = censurada)"},
    # ── Identificadores ──
    "id_operacion": {"patron": r"((^|_)(id|cod|nro|num)_?(operacion|contrato|posicion|trade|deal|credito|"
                               r"prestamo|cuenta|deposito)(_|$)|^(operacion|contrato|posicion|trade_?id|deal_?id)$|"
                               r"^id$)",
                     "familia": "cualquiera", "que": "Identificador de la operación, cuenta o posición"},
    "cuenta_contable": {"patron": r"(cuenta_?contable|(^|_)gl(_|$)|codigo_?cuenta|cta_?contable|rubro_?contable)",
                        "familia": "cualquiera", "que": "Cuenta contable"},
    # ── Mercado ──
    "pnl": {"patron": r"((^|_)(pnl|p_?l|pyg|pyl|hpl|apl|rtpl)(_|$)|ganancia|perdida|profit|resultado_?diario)",
            "familia": "num", "que": "P&L diario usado en el backtesting",
            "equivale": ["pnl_hipotetico", "pnl_real", "pnl_teorico"]},
    "pnl_real": {"patron": r"((pnl|pyg|p_?l)_?(real|actual|sucio|dirty|contable)|(^|_)apl(_|$))",
                 "familia": "num", "que": "P&L real (con comisiones, intereses y actividad del día)"},
    "pnl_hipotetico": {"patron": r"((pnl|pyg|p_?l)_?(hipotetic|hypothetical|limpio|clean)|(^|_)hpl(_|$))",
                       "familia": "num", "que": "P&L hipotético (cartera congelada al cierre anterior)"},
    "pnl_teorico": {"patron": r"((pnl|pyg|p_?l)_?(teoric|theoretical|riesgo|modelo)|(^|_)rtpl(_|$))",
                    "familia": "num", "que": "P&L teórico del modelo de riesgo (RTPL, FRTB)"},
    "var": {"patron": r"((^|_)var(_|\d|$)|valor_?en_?riesgo|value_?at_?risk)", "familia": "num",
            "que": "VaR reportado", "equivale": ["var_99", "var_95", "var_10d"]},
    "var_95": {"patron": r"((^|_)var_?95|var_?0_?95)", "familia": "num", "que": "VaR al 95 %"},
    "var_99": {"patron": r"((^|_)var_?99|var_?0_?99)", "familia": "num", "que": "VaR al 99 %"},
    "var_10d": {"patron": r"(var_?(10|diez)_?d|var_?10_?dias|var_?regulatorio)", "familia": "num",
                "que": "VaR a 10 días"},
    "es": {"patron": r"((^|_)es_?(97|975|99)|expected_?shortfall|(^|_)cvar(_|$)|perdida_?esperada_?(en_)?cola)",
           "familia": "num", "que": "Expected Shortfall"},
    "stressed_var": {"patron": r"((^|_)svar(_|$)|stress(ed)?_?var|var_?(estres|estresado))", "familia": "num",
                     "que": "VaR estresado"},
    "excepcion": {"patron": r"(excepcion|exception|breach|(^|_)hit(_|$)|violacion|exceso_?var)",
                  "familia": "cualquiera", "que": "Marca de excepción del backtesting (0/1)"},
    "precio": {"patron": r"(precio|price|cotizacion|quote|(^|_)px(_|$)|(^|_)valor(_|$)|(^|_)close(_|$)|"
                         r"(^|_)nivel_?factor(_|$))",
               "familia": "num", "que": "Precio o nivel del factor"},
    "retorno": {"patron": r"(retorno|return|rendimiento_?diario|variacion|(^|_)shock(_|$)|choque|log_?ret)",
                "familia": "num", "que": "Retorno o choque del factor"},
    "sensibilidad": {"patron": r"((^|_)delta(_|$)|dv01|pv01|bpv|sensib|(^|_)vega(_|$)|(^|_)gamma(_|$)|"
                               r"duracion_?modificada)",
                     "familia": "num", "que": "Sensibilidad de la posición al factor"},
    "volatilidad": {"patron": r"((^|_)vol(_|$)|volatilidad|sigma|desv)", "familia": "num",
                    "que": "Volatilidad"},
    "correlacion": {"patron": r"(correl|(^|_)rho(_|$))", "familia": "num", "que": "Correlación"},
    "horizonte": {"patron": r"(horizonte|holding|liquidity_?horizon|(^|_)lh(_|$)|dias_?liquidacion)",
                  "familia": "num", "que": "Horizonte (días)"},
    "precio_modelo": {"patron": r"(precio_?modelo|model_?price|valor_?modelo|(npv|mtm)_?modelo|valor_?teorico)",
                      "familia": "num", "que": "Precio del modelo de valoración"},
    "precio_independiente": {"patron": r"((^|_)ipv(_|$)|independiente|precio_?(proveedor|vendor|externo|"
                                       r"bloomberg|refinitiv)|precio_?referencia)",
                             "familia": "num", "que": "Precio de fuente independiente (IPV)"},
    "strike": {"patron": r"(strike|precio_?(de_)?ejercicio)", "familia": "num", "que": "Precio de ejercicio"},
    "ead": {"patron": r"(^|_)(ead|exposicion|exposure|pfe|epe|eepe)(_|$)", "familia": "num",
            "que": "Exposición (EAD / PFE)"},
    "colateral": {"patron": r"(colateral|collateral|garantia|margen_?(inicial|variacion))", "familia": "num",
                  "que": "Colateral recibido o entregado"},
    "mpor": {"patron": r"(mpor|margin_?period|periodo_?(de_)?margen)", "familia": "num",
             "que": "Periodo de margen de riesgo (días)"},
    "cva": {"patron": r"(^|_)(cva|dva|xva|fva)(_|$)", "familia": "num", "que": "Ajuste de valoración (CVA)"},
    # ── Resultados ALM / Liquidez ──
    "eve": {"patron": r"((^|_)(delta_?)?eve(_|$)|valor_?economico|delta_?ve(_|$))", "familia": "num",
            "que": "ΔEVE (valor económico del patrimonio)"},
    "nii": {"patron": r"((^|_)(delta_?)?nii(_|$)|margen_?financiero|(^|_)mif(_|$)|(^|_)nim(_|$))", "familia": "num",
            "que": "ΔNII (margen financiero a 12 meses)"},
    "core": {"patron": r"((^|_)core(_|$)|nucleo|(?<![a-z])(?<!no_)estable(_|$)|porcion_?estable)", "familia": "num",
             "que": "Porción estable (núcleo) del saldo"},
    "volatil": {"patron": r"(volatil|no_?estable|inestable)", "familia": "num",
                "que": "Porción volátil del saldo (la que tiende a retirarse rápido)"},
    "vida_media": {"patron": r"(vida_?media|average_?life|(^|_)wal(_|$)|plazo_?promedio|plazo_?economico|"
                             r"vencimiento_?economico|duracion_?economica|maduracion_?economica)", "familia": "num",
                   "que": "Vida media / plazo económico (años o meses)"},
    "runoff_acumulado": {"patron": r"((run_?off|runoff|salida|desgaste|retiro)_?acum|acumulad)", "familia": "num",
                         "que": "Run-off acumulado R(t) = 1 − S(t)"},
    "runoff_incremental": {"patron": r"(incremental|marginal|desgaste(?!_?acum)|(run_?off|runoff|salida|retiro)_?"
                                     r"(del_)?periodo|run_?off_?incr)", "familia": "num",
                           "que": "Desgaste incremental del periodo d(t) = S(t−1) − S(t)"},
    "proporcion": {"patron": r"(^|_)(porcentaje|proporcion|pct|peso|participacion|distribucion|asignacion)(_|$)",
                   "familia": "num", "que": "Proporción del saldo asignada (a una banda, a un componente)"},
    "dias": {"patron": r"((^|_)dias(_|$)|days|plazo_?(en_)?dias|dias_?(al_)?(venc|reprecio|vto)|plazo_?residual)",
             "familia": "num", "que": "Días al vencimiento o al reprecio"},
    "plazo_meses": {"patron": r"(plazo_?(en_)?meses|meses_?(al_)?venc|tenor_?meses|(^|_)meses(_|$)|(^|_)mes_?k(_|$))",
                    "familia": "num", "que": "Plazo en meses"},
    "edad": {"patron": r"((^|_)edad(_|$)|antiguedad|seasoning|meses_?(de_)?vida|(^|_)age(_|$))", "familia": "num",
             "que": "Antigüedad (meses desde el origen)"},
    "hqla": {"patron": r"(hqla|activo_?liquido|activos_?liquidos|(^|_)alac(_|$)|stock_?liquido)", "familia": "num",
             "que": "Activos líquidos de alta calidad"},
    "lcr": {"patron": r"(^|_)(lcr|rcl|ratio_?(de_)?cobertura)(_|$)", "familia": "num",
            "que": "Ratio de cobertura de liquidez (LCR / RCL)"},
    "nsfr": {"patron": r"(^|_)(nsfr|rfne|ratio_?(de_)?financiamiento|fondeo_?estable)(_|$)", "familia": "num",
             "que": "Ratio de financiamiento neto estable (NSFR / RFNE)"},
    "brecha": {"patron": r"(brecha|(^|_)gap(_|$)|descalce)", "familia": "num", "que": "Brecha (gap)"},
    "flujo_neto": {"patron": r"(flujo_?neto|net_?cash|salida_?neta|(^|_)neto(_|$))", "familia": "num",
                   "que": "Flujo neto (entradas − salidas)"},
    "lar_valor": {"patron": r"((^|_)lar(_|$)|liquidity_?at_?risk|var_?(de_)?liquidez)", "familia": "num",
                  "que": "Liquidity at Risk reportado"},
    "limite": {"patron": r"((^|_)limite|(^|_)limit(_|$)|(^|_)umbral|(^|_)alerta)", "familia": "num",
               "que": "Límite o umbral de alerta"},
}

for _r, _m in ROLES.items():
    _m["_rx"] = re.compile(_m["patron"])


def descripcion_rol(rol: str) -> str:
    return ROLES.get(rol, {}).get("que", rol)


# ═════════════════════════════════════════════════════════════════════════════
# FICHAS (contenido en tres módulos por familia)
# ═════════════════════════════════════════════════════════════════════════════

def _cargar_tipos() -> dict[str, dict[str, Any]]:
    from modulos.tipos_modelo_alm import TIPOS as _alm
    from modulos.tipos_modelo_liquidez import TIPOS as _liq
    from modulos.tipos_modelo_trading import TIPOS as _trad
    tipos: dict[str, dict[str, Any]] = {}
    for bloque in (_trad, _alm, _liq):
        for k, v in bloque.items():
            if k in tipos:
                raise ValueError(f"tipo de modelo repetido: {k}")
            tipos[k] = v
    return tipos


TIPOS: dict[str, dict[str, Any]] = _cargar_tipos()


def tipo(tid: str) -> dict[str, Any]:
    if tid not in TIPOS:
        raise KeyError(f"tipo de modelo desconocido: {tid!r} (válidos: {', '.join(TIPOS)})")
    return TIPOS[tid]


def validar_tipos(tipos: Optional[Iterable[str]]) -> list[str]:
    """Lista explícita de tipos (sin repetidos, en orden). Lanza ValueError si alguno no existe."""
    salida: list[str] = []
    for t in tipos or []:
        t = str(t or "").strip()
        if not t:
            continue
        if t not in TIPOS:
            raise ValueError(f"tipo de modelo desconocido: {t!r}. Válidos: {', '.join(TIPOS)}")
        if t not in salida:
            salida.append(t)
    return salida


def tipos_de_carpeta(carpeta: str) -> list[str]:
    return [k for k, v in TIPOS.items() if v["carpeta"] == carpeta]


def carpetas_de_tipos(tipos: Iterable[str]) -> list[str]:
    salida: list[str] = []
    for t in tipos or []:
        c = TIPOS[t]["carpeta"]
        if c not in salida:
            salida.append(c)
    return salida


def catalogo_para_ui(dominio: str = "") -> list[dict[str, Any]]:
    """Tipos para el selector de la web: primero los de la familia del dominio."""
    try:
        from modulos.repositorio_controles import carpeta_de_dominio
        carpeta = carpeta_de_dominio(dominio) or ""
    except Exception:                                  # noqa: BLE001
        carpeta = ""
    filas = [{"id": k, "nombre": v["nombre"], "familia": v["familia"], "carpeta": v["carpeta"],
              "del_dominio": v["carpeta"] == carpeta, "resumen": v["negocio"][:240]}
             for k, v in TIPOS.items()]
    filas.sort(key=lambda f: (not f["del_dominio"], list(FAMILIAS).index(f["familia"])))
    return filas


def preguntas(tipos: Iterable[str]) -> list[str]:
    out: list[str] = []
    for t in tipos or []:
        out += [p for p in TIPOS[t].get("preguntas", []) if p not in out]
    return out


# ═════════════════════════════════════════════════════════════════════════════
# ENLACE: bases lógicas → bases reales, roles → columnas
# ═════════════════════════════════════════════════════════════════════════════

def _familia_col(c: dict) -> str:
    d = str(c.get("dtype") or "").lower()
    if any(x in d for x in ("datetime", "date", "timestamp")):
        return "fecha"
    if any(x in d for x in ("int", "float", "double", "decimal", "long", "numér", "numer")):
        return "num"
    if ROLES["fecha"]["_rx"].search(norm(c.get("nombre"))) and "bool" not in d:
        return "fecha"                       # fecha leída como texto (object)
    return "texto"


def _familia_ok(rol: str, fam: str) -> bool:
    f = ROLES[rol]["familia"]
    if f == "cualquiera":
        return True
    if f == "texto":
        return fam in ("texto", "fecha") if rol in ("tenor", "banda") else fam == "texto"
    return f == fam


def _candidatos(rol: str, columnas: list[dict]) -> list[tuple[float, str]]:
    salida = []
    for c in columnas:
        n = norm(c["nombre"])
        fam = _familia_col(c)
        if not _familia_ok(rol, fam):
            continue
        if n == rol:
            salida.append((3.0, c["nombre"]))
        elif ROLES[rol]["_rx"].search(n):
            salida.append((2.0, c["nombre"]))
    return salida


def _enlazar_roles(roles: list[str], columnas: list[dict]) -> dict[str, str]:
    """Rol → columna dentro de UNA base. Los roles se procesan en el orden dado
    (los específicos primero); se evita usar dos veces la misma columna."""
    enl: dict[str, str] = {}
    usadas: set[str] = set()
    pendientes_eq = []
    for r in roles:
        if ROLES[r].get("equivale"):
            pendientes_eq.append(r)
            continue
        cands = sorted(((s - (1.5 if col in usadas else 0.0), col) for s, col in _candidatos(r, columnas)),
                       key=lambda x: -x[0])
        if cands and cands[0][0] > 0:
            enl[r] = cands[0][1]
            usadas.add(cands[0][1])
    for r in pendientes_eq:                  # genéricos: reutilizan su equivalente si existe
        eq = next((enl[e] for e in ROLES[r]["equivale"] if e in enl), None)
        if eq:
            enl[r] = eq
            continue
        cands = sorted(((s - (1.5 if col in usadas else 0.0), col) for s, col in _candidatos(r, columnas)),
                       key=lambda x: -x[0])
        if cands and cands[0][0] > 0:
            enl[r] = cands[0][1]
            usadas.add(cands[0][1])
    return enl


def _alias_ok(base: dict, dataset: str) -> bool:
    n = norm(dataset)
    return any(re.search(rf"(^|_){re.escape(norm(a))}(_|$)", n) for a in base.get("alias", []))


def enlazar(perfiles: list[dict], tipos: Iterable[str]) -> dict[str, Any]:
    """
    Enlace de las bases lógicas y los roles de los tipos de modelo con los
    perfiles (nombre de la base + columnas con su dtype). Devuelve:

        {"bases": {base_id: dataset | None},
         "roles": {dataset: {rol: columna}},
         "detalle": [{tipo, base, nombre, dataset, roles_enlazados, roles_faltan}],
         "nombres_base": {base_id: nombre legible}}

    Una base lógica se enlaza con la base real que mejor cubre sus roles (los
    que la DEFINEN pesan triple; el nombre del archivo suma). Las bases de
    referencia (`solo_por_nombre`, p. ej. contabilidad) solo se enlazan si el
    nombre de la base real lo dice: nunca se compara una base consigo misma.
    """
    tipos = list(tipos or [])
    por_ds = {p["nombre"]: p.get("columnas") or [] for p in perfiles}
    bases: dict[str, Optional[str]] = {}
    nombres: dict[str, str] = {}
    roles_por_ds: dict[str, list[str]] = {}
    detalle = []
    for t in tipos:
        for b in TIPOS[t]["bases"]:
            bid = b["id"]
            if bid in bases and bases[bid]:
                for r in b["roles"]:          # otra ficha reusa la base: suma sus roles
                    if r not in roles_por_ds.setdefault(bases[bid], []):
                        roles_por_ds[bases[bid]].append(r)
                continue
            nombres[bid] = b["nombre"]
            mejor, mejor_s = None, 0.0
            for ds, cols in por_ds.items():
                alias = _alias_ok(b, ds)
                if b.get("solo_por_nombre") and not alias:
                    continue
                enl = _enlazar_roles(b["roles"], cols)
                define = sum(1 for r in b.get("define", []) if r in enl)
                if not define and not alias:
                    continue
                s = 3.0 * define + sum(1 for r in b["roles"] if r in enl) + (3.0 if alias else 0.0)
                if s > mejor_s:
                    mejor, mejor_s = ds, s
            bases[bid] = mejor
            if mejor:
                lst = roles_por_ds.setdefault(mejor, [])
                for r in b["roles"]:
                    if r not in lst:
                        lst.append(r)
    roles = {ds: _enlazar_roles(rs, por_ds.get(ds, [])) for ds, rs in roles_por_ds.items()}
    for t in tipos:
        for b in TIPOS[t]["bases"]:
            ds = bases.get(b["id"])
            enl = roles.get(ds, {}) if ds else {}
            detalle.append({"tipo": t, "base": b["id"], "nombre": b["nombre"], "dataset": ds,
                            "roles_enlazados": {r: enl[r] for r in b["roles"] if r in enl},
                            "roles_faltan": [r for r in b["roles"] if r not in enl]})
    return {"bases": bases, "roles": roles, "detalle": detalle, "nombres_base": nombres}


def _escala(perfiles: list[dict], ds: Optional[str], col: Optional[str]) -> float:
    """1 si la columna es una proporción (p75 ≤ 1), 100 si es un porcentaje."""
    for p in perfiles:
        if p["nombre"] != ds:
            continue
        for c in p.get("columnas") or []:
            if c["nombre"] == col:
                st = c.get("stats") or {}
                for k in ("75%", "max"):
                    try:
                        v = float(st.get(k))
                        return 1.0 if v <= 1 else 100.0
                    except (TypeError, ValueError):
                        continue
    return 1.0


def controles_negocio(perfiles: list[dict], tipos: Iterable[str],
                      enlace: Optional[dict] = None) -> list[dict[str, Any]]:
    """
    Controles de datos de las fichas de los tipos elegidos, con el enlace
    resuelto: cada uno trae `base` (lógica), `roles`, y `dataset`/`columnas`
    reales si se pudieron enlazar (si no, `pendientes` dice qué falta). En el
    notebook corren con `ejecutar_rol`, que vuelve a resolver con `BASES` y
    `ROLES` (lo que el validador corrija ahí manda).
    """
    tipos = list(tipos or [])
    enlace = enlace or enlazar(perfiles, tipos)
    salida = []
    for t in tipos:
        for c in TIPOS[t]["controles"]:
            ds = enlace["bases"].get(c["base"])
            enl = enlace["roles"].get(ds, {}) if ds else {}
            faltan = [r for r in c["roles"] if r not in enl]
            cols = [enl[r] for r in c["roles"] if r in enl]
            cols += [enl[r] for r in c.get("opcionales", []) if r in enl and enl[r] not in cols]
            pend = []
            if not ds:
                pend.append(f"base «{enlace['nombres_base'].get(c['base'], c['base'])}»")
            pend += [f"rol «{r}» ({descripcion_rol(r)})" for r in faltan]
            if len(set(cols)) != len(cols) and not faltan:
                pend.append("dos roles caen en la misma columna")
            params = dict(c.get("params") or {})
            if c.get("escala_p75") and not pend:
                # Proporciones en 0–1 o en %: el máximo de un rango, o lo que debe sumar un grupo.
                params[{"suma_por_grupo": "valor_esperado", "relacion_aritmetica": "valor"}.get(c["tipo"], "maximo")] = \
                    _escala(perfiles, ds, cols[0])
            ref = c.get("ref")
            ref_res = None
            no_aplica = ""
            if ref:
                rds = enlace["bases"].get(ref["base"])
                renl = enlace["roles"].get(rds, {}) if rds else {}
                if not rds:
                    pend.append(f"base de referencia «{enlace['nombres_base'].get(ref['base'], ref['base'])}»")
                elif rds == ds:
                    no_aplica = (f"«{enlace['nombres_base'].get(c['base'], c['base'])}» y «"
                                 f"{enlace['nombres_base'].get(ref['base'], ref['base'])}» vienen en la misma base "
                                 f"({ds}): cada fila ya trae ambos datos")
                elif ref.get("rol") and ref["rol"] not in renl:
                    pend.append(f"rol «{ref['rol']}» en la base de referencia")
                for k in ref.get("claves") or []:
                    if rds and rds != ds and k not in renl:
                        pend.append(f"clave «{k}» en la base de referencia")
                ref_res = {"base": ref["base"], "rol": ref.get("rol"), "claves": list(ref.get("claves") or []),
                           "dataset": rds, "columna": renl.get(ref.get("rol")) if ref.get("rol") else None}
            salida.append({
                "tipo_modelo": t, "base": c["base"], "tipo": c["tipo"], "roles": list(c["roles"]),
                "opcionales": list(c.get("opcionales") or []), "params": params,
                "escala_p75": bool(c.get("escala_p75")),
                "criticidad": c.get("criticidad", "MEDIA"), "descripcion": c["que"],
                "justificacion": f"{TIPOS[t]['nombre']}: {c['por_que']}",
                "evidencia_requerida": c.get("evidencia") or "Si no cumple, sustentar el tratamiento "
                                                               "aplicado por la primera línea.",
                "dataset": ds, "columnas": cols, "pendientes": pend, "ref": ref_res,
                "plantilla": bool(c.get("plantilla")), "no_aplica": no_aplica, "origen": "tipo de modelo"})
    return salida


# ═════════════════════════════════════════════════════════════════════════════
# TEXTOS: notebook (markdown) y prompts de los chats
# ═════════════════════════════════════════════════════════════════════════════

def _lista_md(xs: Iterable[str]) -> str:
    return "\n".join(f"- {x}" for x in xs)


def ficha_md(tid: str, enlace: Optional[dict] = None) -> str:
    """«Entender el negocio» del tipo de modelo, en markdown para el notebook."""
    t = tipo(tid)
    l = [f"### {t['nombre']} · familia {t['familia']}", "", "**Qué hace el modelo.** " + t["negocio"], ""]
    if t.get("salidas"):
        l += ["**Qué produce:**", _lista_md(t["salidas"]), ""]
    if t.get("usos"):
        l += ["**Para qué se usa:**", _lista_md(t["usos"]), ""]
    l += ["**Bases que necesita** (base lógica → base real enlazada):", "",
          "| Base lógica | Granularidad | Para qué | Enlazada con |", "|---|---|---|---|"]
    for b in t["bases"]:
        ds = (enlace or {}).get("bases", {}).get(b["id"]) if enlace else None
        l.append(f"| **{b['nombre']}** (`{b['id']}`) | {b.get('granularidad', '')} | "
                 f"{b.get('para_que', '')} | {('`' + ds + '`') if ds else '⚠ sin enlazar'} |")
    l += ["", "**Qué puede fallar en los datos (y por qué importa):**", _lista_md(t["riesgos"]), ""]
    if t.get("normativa"):
        l += ["**Referencias:**", _lista_md(t["normativa"]), ""]
    return "\n".join(l)


def pasos_etapa(tipos: Iterable[str], codigo: str) -> list[str]:
    out = []
    for t in tipos or []:
        for p in TIPOS[t].get("etapas", {}).get(codigo, []):
            out.append(f"[{TIPOS[t]['nombre'].split(' (')[0]}] {p}")
    return out


def texto_para_prompt(tipos: Iterable[str], codigo: str, tope: int = 9000) -> str:
    """Conocimiento experto del tipo de modelo para el chat de la etapa `codigo`."""
    tipos = list(tipos or [])
    if not tipos:
        return ""
    partes = []
    for tid in tipos:
        t = TIPOS[tid]
        bases = "; ".join(f"{b['id']} = {b['nombre']} ({b.get('granularidad', '')}; roles: "
                          f"{', '.join(b['roles'])})" for b in t["bases"])
        bloque = [f"## {t['nombre']} (familia {t['familia']})",
                  "NEGOCIO: " + t["negocio"],
                  "BASES LÓGICAS: " + bases,
                  "QUÉ PUEDE FALLAR EN LOS DATOS:\n" + _lista_md(t["riesgos"])]
        pasos = t.get("etapas", {}).get(codigo, [])
        if pasos:
            bloque.append(f"PASOS DE EXPERTO PARA ESTA ETAPA ({codigo}):\n" + _lista_md(pasos))
        if codigo in ("02", "03", "04") and t.get("metricas"):
            bloque.append("MÉTRICAS A REPLICAR / VIGILAR: " + "; ".join(t["metricas"]))
        if codigo in ("00", "01"):
            bloque.append("QUÉ PEDIR A LA PRIMERA LÍNEA:\n" + _lista_md(t.get("preguntas", [])[:8]))
        if t.get("normativa"):
            bloque.append("REFERENCIAS: " + "; ".join(t["normativa"][:5]))
        partes.append("\n".join(bloque))
    texto = "\n\n".join(partes)
    return texto if len(texto) <= tope else texto[:tope] + "\n…[ficha truncada]"
