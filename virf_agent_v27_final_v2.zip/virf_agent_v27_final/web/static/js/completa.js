// ── VALIDACIÓN COMPLETA ──────────────────────────────────────────────
//
// Cinco chats especializados (00 Diagnóstico · 01 Control de datos ·
// 02 Modelamiento · 03 Impactos · 04 Seguimiento). En cada iteración el agente
// ENTREGA un notebook ({etapa}ITERn.ipynb) que el validador ejecuta donde están
// los datos; el notebook genera {etapa}_resultadoITERn.xlsx, que vuelve al chat
// con comentarios e imágenes de sustento para la siguiente iteración. El
// validador cierra cada etapa; con las cinco cerradas, el modelo está listo
// para enviarse a validar. La modalidad (normal | completa) es explícita.
// Usa utilidades de app.js: $, $$, pedirJSON, escapeHtml, mostrarVista,
// estado, fmtTs, formatearMensajeChat, VISTA_A_NAV.

const VC = { etapa: "00", datos: null, resumen: null, archivos: [], enviando: false };
const VC_IMG = /\.(png|jpe?g|gif|bmp|webp)$/i;

function vcModalidad() {
    return (estado.modelo && estado.modelo.modalidad) || "normal";
}

function pintarModalidad() {
    const completa = vcModalidad() === "completa";
    const btn = $("#btn-modalidad");
    if (btn) btn.setAttribute("aria-pressed", completa ? "true" : "false");
    const est = $("#modalidad-estado");
    if (est) est.textContent = completa ? "completa" : "normal";
    const nav = $("#nav-completa");
    if (nav) nav.hidden = !completa;
    if (completa) vcCargarResumen();
}

async function alternarModalidad() {
    const nueva = vcModalidad() === "completa" ? "normal" : "completa";
    const msg = nueva === "completa"
        ? "¿Pasar este modelo a VALIDACIÓN COMPLETA?\n\nSe habilitan 5 chats (00–04). En cada uno el agente te entrega un notebook; lo ejecutas, genera un Excel y se lo devuelves con tus comentarios e imágenes hasta que la etapa cumpla."
        : "¿Volver a VALIDACIÓN NORMAL?\n\nLo hecho en las etapas se conserva, pero se ocultan y no se piden automatizaciones.";
    if (!confirm(msg)) return;
    try {
        const r = await pedirJSON("/api/completa/modalidad", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ modalidad: nueva }),
        });
        estado.modelo = r.modelo;
        pintarModalidad();
        if (nueva === "completa") abrirInsumos();      // primer paso: subir manuales, Excels y scripts
        else if (!$("#vista-completa").hidden) mostrarVista("vista-vacia");
    } catch (err) { alert(err.message); }
}

async function vcCargarResumen() {
    try {
        VC.resumen = await pedirJSON("/api/completa/estado");
        for (const e of VC.resumen.etapas) {
            const b = $(`#btn-etapa-${e.codigo}`);
            const lab = b && b.querySelector(".nav-btn__label");
            if (lab) lab.textContent = e.nombre
                + (e.iteraciones ? ` · ITER${e.iteraciones - 1}` : "") + (e.cerrada ? " ✓" : "");
        }
    } catch { /* sin modelo activo */ }
}

async function abrirEtapa(codigo) {
    VC.etapa = codigo;
    VISTA_A_NAV["vista-completa"] = `btn-etapa-${codigo}`;
    mostrarVista("vista-completa");
    VC.archivos = [];
    vcPintarAdjuntos();
    $("#vc-comentario").value = "";
    $("#vc-estado").textContent = "";
    await vcCargarResumen();
    vcPintarPestanas();
    vcCargarConsolidado();
    try {
        VC.datos = await pedirJSON(`/api/completa/etapa/${codigo}`);
        vcPintarEtapa();
        vcCargarInsumos();
    } catch (err) {
        $("#vc-mensajes").innerHTML = `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

function vcPintarPestanas() {
    const r = VC.resumen || { etapas: [], cerradas: 0, total: 5 };
    $("#vc-global").innerHTML = (r.lista_para_validar
        ? `<div class="verificacion is-ok"><strong>Las ${r.total} etapas están cerradas:</strong>
             el modelo está listo para el barrido de controles. Al lanzarlo, los hallazgos, réplicas,
             impactos, seguimiento y los controles de datos del 01 pasan a la evidencia de la validación,
             del chat con el agente y del informe.
             <button type="button" class="btn btn--primary" id="vc-ir-validar">Ir a 08 · Validar modelo →</button></div>`
        : `<div class="tam">Etapas cerradas: <strong>${r.cerradas} de ${r.total}</strong>.
             Cuando las ${r.total} estén cerradas se habilita el barrido de controles (08 · Validar modelo),
             que se lanza con todo lo de las cinco etapas.</div>`)
        + `<div class="vc-consolidado">
             <button type="button" class="btn ${r.lista_para_validar ? "btn--primary" : "btn--ghost"}" id="vc-consolidar">
                 Consolidar hallazgos (lee el Excel y el .md de cada etapa)</button>
             <div id="vc-consolidado-res"></div></div>`;
    $("#vc-consolidar").addEventListener("click", vcConsolidar);
    const irValidar = $("#vc-ir-validar");
    if (irValidar) irValidar.addEventListener("click", () => $("#btn-validar").click());
    vcPintarConsolidado(VC.consolidado);
    $("#vc-etapas").innerHTML = r.etapas.map(e => `
        <button type="button" class="vc-etapa ${e.cerrada ? "is-cerrada" : ""}" role="tab"
                data-etapa="${e.codigo}" aria-selected="${e.codigo === VC.etapa}">
            ${e.codigo} · ${escapeHtml(e.nombre)}<span class="tam">${e.iteraciones ? `ITER${e.iteraciones - 1}` : "—"}</span>
        </button>`).join("");
    for (const b of $$("#vc-etapas .vc-etapa")) {
        b.addEventListener("click", () => abrirEtapa(b.dataset.etapa));
    }
}

// 08 · Validar modelo en modalidad completa: qué trae de las cinco etapas. Con
// alguna abierta, el lanzamiento queda bloqueado (el servidor también lo impide).
async function vcPintarPaqueteValidar() {
    const cont = $("#validar-completa");
    const btn = $("#btn-lanzar-validacion");
    if (!cont) return;
    if (vcModalidad() !== "completa") {
        window.vcBloqueoValidar = false;
        cont.hidden = true;
        cont.innerHTML = "";
        if (btn && !runIdActivo) { btn.disabled = false; btn.title = ""; }
        return;
    }
    let p;
    try {
        p = await pedirJSON("/api/completa/paquete");
    } catch (err) {
        cont.hidden = false;
        cont.className = "verificacion is-error";
        cont.innerHTML = `<strong>No se pudo leer la Validación completa</strong><pre>${escapeHtml(err.message)}</pre>`;
        return;
    }
    window.vcBloqueoValidar = !p.lista;
    if (btn) {
        btn.disabled = !p.lista || (btn.disabled && !!runIdActivo);
        btn.title = p.lista ? "" : "Cierra antes las cinco etapas de la Validación completa";
    }
    const cd = p.controles_datos;
    const filas = p.etapas.map(e => `<tr>
        <td>${e.codigo} · ${escapeHtml(e.nombre)}</td>
        <td>${e.cerrada ? "✓ cerrada" : "<strong>abierta</strong>"}</td>
        <td class="num">${e.abiertos}${e.criticos ? ` (${e.criticos} crítico${e.criticos > 1 ? "s" : ""})` : ""}</td>
        <td>${e.archivos.map(a => `<code>${escapeHtml(a.destino)}</code>`).join("<br>") || "—"}</td></tr>`).join("");
    cont.hidden = false;
    cont.className = "verificacion " + (p.lista ? "is-ok" : "is-warn");
    cont.innerHTML = `<strong>${p.lista
            ? "Validación completa: las cinco etapas están cerradas. El barrido se lanza con todo su trabajo."
            : "Validación completa: falta cerrar " + p.faltan.map(escapeHtml).join(", ") + ". Ciérralas antes de lanzar."}</strong>
        <p class="tam">Al lanzar, lo de cada etapa pasa a la evidencia que leen el barrido (por ámbito), el chat
        con el agente (09) y el informe (10): ${p.hallazgos_abiertos} hallazgo(s) abiertos
        (${p.criticos_abiertos} crítico(s)). ${cd
            ? `Controles de datos del 01: ${cd.controles}${"ok" in cd ? ` (${cd.ok} OK, ${cd.falla} FALLA, ${cd.no_evaluable} no evaluables)` : ""}; los puntúa el ámbito «Calidad de datos».`
            : "Aún no hay Excel de resultados del 01: el ámbito «Calidad de datos» no tendrá los controles de datos de la validación completa."}</p>
        <table class="tabla-ambitos"><thead><tr><th>Etapa</th><th>Estado</th><th>Hallazgos abiertos</th>
            <th>Va a la evidencia</th></tr></thead><tbody>${filas}</tbody></table>
        ${p.publicado ? `<p class="tam">Última vez que se llevó a la validación: ${escapeHtml(fmtTs(p.publicado.fecha))}
            (${p.publicado.archivos.length} archivo(s)).</p>` : ""}`;
}

function vcPintarConsolidado(c) {
    const cont = $("#vc-consolidado-res");
    if (!cont) return;
    if (!c) { cont.innerHTML = ""; return; }
    const s = c.resumen || {};
    const base = "/api/completa/consolidado/descargar/";
    cont.innerHTML = `<div class="verificacion ${s.criticos ? "is-warn" : "is-ok"}">
        <strong>Consolidado ${escapeHtml(fmtTs(s.generado))}</strong> · ${s.hallazgos} hallazgo(s) ·
        ${s.abiertos} abierto(s) (Crítico ${s.criticos}, Moderado ${s.moderados}, Potencial/Bajo ${s.bajos}) ·
        ${(c.inconsistencias || []).length} inconsistencia(s) entre Excel y .md ·
        <a href="${base}${encodeURIComponent(c.excel)}" download>⬇ Excel</a> ·
        <a href="${base}${encodeURIComponent(c.md)}" download>⬇ .md</a></div>
        ${(s.avisos || []).length ? `<ul class="tam">${s.avisos.map(a => `<li>${escapeHtml(a)}</li>`).join("")}</ul>` : ""}
        ${(c.inconsistencias || []).length ? `<details class="config-detalle"><summary>Inconsistencias</summary><ul>${
            c.inconsistencias.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul></details>` : ""}`;
}

async function vcConsolidar() {
    const b = $("#vc-consolidar");
    b.disabled = true;
    try {
        VC.consolidado = await pedirJSON("/api/completa/consolidar", { method: "POST" });
        vcPintarConsolidado(VC.consolidado);
    } catch (err) {
        $("#vc-consolidado-res").innerHTML = `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    } finally {
        b.disabled = false;
    }
}

async function vcCargarConsolidado() {
    try {
        VC.consolidado = (await pedirJSON("/api/completa/consolidado")).consolidado;
        vcPintarConsolidado(VC.consolidado);
    } catch { /* sin modelo activo */ }
}

function vcVeredicto(v) {
    if (!v) return "";
    return v.estado === "lista"
        ? `<span class="vc-ver vc-ver--lista" title="${escapeHtml(v.motivo || "")}">LISTA</span>`
        : `<span class="vc-ver vc-ver--otra" title="${escapeHtml(v.motivo || "")}">OTRA ITERACIÓN</span>`;
}

function vcThumbs(codigo, iter, imagenes) {
    if (!imagenes || !imagenes.length) return "";
    return `<div class="vc-thumbs">${imagenes.map(n => {
        const u = `/api/completa/etapa/${codigo}/imagen/${iter}/${encodeURIComponent(n)}`;
        return `<a href="${u}" target="_blank" rel="noopener" title="${escapeHtml(n)}"><img src="${u}" alt="${escapeHtml(n)}" loading="lazy"></a>`;
    }).join("")}</div>`;
}

function vcPintarEtapa() {
    const d = VC.datos;
    const n = d.iteraciones.length;
    const ult = n ? d.iteraciones[n - 1] : null;
    $("#vc-titulo").textContent = `Validación completa · ${d.fichero}`;
    $("#vc-mision").textContent = d.mision + (d.profundo
        ? " El agente escribe el notebook en dos pasadas (redacción y revisión crítica): tarda más."
        : "");
    const previas = (d.previas || []).map(c => {
        const e = (VC.resumen.etapas || []).find(x => x.codigo === c);
        return e ? `${e.fichero}${e.iteraciones ? ` (ITER${e.iteraciones - 1})` : " (sin iteraciones)"}` : c;
    });
    $("#vc-previas").textContent = previas.length
        ? `Usa como contexto la última iteración de: ${previas.join(" · ")}.` : "";

    // Experto de la etapa y tipo de modelo (explícito, de la ficha del modelo).
    const tipos = d.tipos_modelo || [];
    $("#vc-experto").innerHTML = `<div class="vc-experto__texto"><strong>Quién revisa:</strong> ${escapeHtml(d.experto || "")}</div>`
        + (tipos.length
            ? `<div class="vc-experto__texto"><strong>Tipo de modelo:</strong> ${tipos.map(t => escapeHtml(t.nombre)).join(" · ")}</div>`
            : `<div class="verificacion is-warn">Elige el <strong>tipo de modelo</strong> en Configuración (VaR, run-off,
                 IRRBB, prepago, LCR…): sin él el agente no puede ser experto en el negocio ni replicar el modelo.</div>`);
    // Ruta paso a paso con el estado que dejó la última iteración (verificado por VIRF).
    const ruta = d.ruta || [];
    const icono = { cubierto: "✓", parcial: "◐", pendiente: "○", no_aplica: "—" };
    $("#vc-ruta-resumen").textContent = ruta.length ? `· ${d.pasos_cubiertos || 0} de ${ruta.length} pasos cubiertos` : "";
    $("#vc-ruta-wrap").open = !n;            // abierta al empezar; luego plegada (el resumen dice cuántos van)
    $("#vc-ruta").innerHTML = ruta.length ? `<ol class="vc-ruta__pasos">${ruta.map(p => `
        <li class="vc-paso vc-paso--${escapeHtml(p.estado)}" title="${escapeHtml(p.criterio || "")}">
            <span class="vc-paso__icono" aria-hidden="true">${icono[p.estado] || "○"}</span>
            <strong>${escapeHtml(p.paso)} · ${escapeHtml(p.titulo)}</strong>
            <span class="tam">${escapeHtml(p.que)} → hoja <em>${escapeHtml(p.hoja)}</em></span>
            ${p.nota ? `<span class="tam vc-paso__nota">${escapeHtml(p.nota)}</span>` : ""}
        </li>`).join("")}</ol>`
        + tipos.filter(t => (t.pasos || []).length).map(t => `<div class="vc-ruta__tipo"><strong>Qué mira el experto
            en un ${escapeHtml(t.nombre)}:</strong><ul>${t.pasos.map(p => `<li>${escapeHtml(p)}</li>`).join("")}</ul></div>`).join("")
        : "";
    $("#vc-excel-esperado").textContent = ult ? ult.resultado_esperado : "el Excel que generó el notebook";
    $("#vc-enviar").textContent = `Pedir notebook ITER${n}`;

    // Rutas vigentes
    const rutas = d.rutas || {};
    const nr = Object.keys(rutas).length;
    $("#vc-rutas").value = Object.entries(rutas).map(([k, v]) => `${k} = ${v}`).join("\n");
    $("#vc-rutas").dataset.original = $("#vc-rutas").value;
    $("#vc-rutas-resumen").textContent = nr ? `· ${nr} definida${nr === 1 ? "" : "s"}` : "· ninguna todavía";
    $("#vc-rutas-wrap").open = !nr;

    // Cierre (decisión del validador)
    const c = d.cierre;
    $("#vc-cierre").innerHTML = !n ? "" : c
        ? `<div class="vc-cierre verificacion is-ok"><span><strong>Etapa cerrada</strong> por
             ${escapeHtml(c.por || "")} en ITER${c.iter} · ${escapeHtml(fmtTs(c.ts))}${c.motivo ? ` — ${escapeHtml(c.motivo)}` : ""}</span>
             <button type="button" class="btn btn--ghost" id="vc-reabrir">Reabrir</button></div>`
        : `<div class="vc-cierre"><span class="tam">Veredicto del agente en ITER${ult.n}: ${vcVeredicto(ult.veredicto)}
             ${ult.veredicto && ult.veredicto.motivo ? escapeHtml(ult.veredicto.motivo) : ""}</span>
             <button type="button" class="btn ${ult.veredicto && ult.veredicto.estado === "lista" ? "btn--primary" : "btn--ghost"}"
                     id="vc-cerrar">Cerrar etapa</button></div>`;
    const bc = $("#vc-cerrar"), br = $("#vc-reabrir");
    if (bc) bc.addEventListener("click", () => vcCerrar(false));
    if (br) br.addEventListener("click", () => vcCerrar(true));

    const base = `/api/completa/etapa/${d.codigo}/descargar/`;
    const entregables = d.hallazgos_excel || d.hallazgos_md
        ? `<div class="vc-hallazgos tam"><strong>Hallazgos de la etapa</strong> (todas las iteraciones; cada uno con su Excel de sustento):
             ${d.hallazgos_excel ? `<a href="${base}${encodeURIComponent(d.hallazgos_excel)}" download>⬇ ${escapeHtml(d.hallazgos_excel)}</a>` : ""}
             ${d.hallazgos_md ? ` · <a href="${base}${encodeURIComponent(d.hallazgos_md)}" download>${escapeHtml(d.hallazgos_md)}</a>` : ""}</div>`
        : "";
    $("#vc-iteraciones").innerHTML = entregables + (n ? `<div class="vc-iters">${d.iteraciones.slice().reverse().map(it => `
        <div class="vc-iter">
            <span class="vc-iter__n">${escapeHtml(d.fichero)}ITER${it.n}</span>
            <a href="${base}${encodeURIComponent(it.ipynb)}" download>⬇ .ipynb</a>
            <a href="${base}${encodeURIComponent(it.md)}" download>revisión .md</a>
            ${vcVeredicto(it.veredicto)}
            <span class="tam">${escapeHtml(fmtTs(it.ts))} · ${escapeHtml(it.modo)} ·
                ${it.abiertos} abiertos · ${it.resueltos} resueltos · genera ${escapeHtml(it.resultado_esperado)}</span>
            <span class="vc-iter__res">${escapeHtml(it.resumen || "")}</span>
            <div class="vc-iter__imgs">${vcThumbs(d.codigo, it.n, it.imagenes)}</div>
        </div>`).join("")}</div>`
        : "<em>Sin notebooks todavía. Indica las rutas de datos y las evidencias para recibir el primero.</em>");

    const cont = $("#vc-mensajes");
    cont.innerHTML = "";
    if (!d.mensajes.length) {
        cont.innerHTML = `<div class="chat-msg chat-msg--agente"><div class="chat-msg__meta">🤖 Agente</div>
            Estudio los manuales, Excels de primera línea y scripts que subas en <strong>Insumos</strong>.
            Aquí dame las <strong>rutas de las bases</strong> y tus indicaciones.
            Te entregaré <strong>${escapeHtml(d.fichero)}ITER0.ipynb</strong>: ejecútalo y genera
            <strong>${escapeHtml(d.fichero)}_resultadoITER0.xlsx</strong>. Devuélvemelo con tus comentarios y
            las capturas que sustenten la revisión, y te doy el ITER1, hasta que la etapa cumpla.</div>`
            .replace(/\n\s+/g, " ");            // .chat-msg usa white-space: pre-wrap
    }
    for (const m of d.mensajes) cont.appendChild(vcMensaje(m, base, d.codigo));
    cont.scrollTop = cont.scrollHeight;
}

function vcMensaje(m, base, codigo) {
    const div = document.createElement("div");
    div.className = `chat-msg chat-msg--${m.quien}`;
    const quien = m.quien === "agente" ? "🤖 Agente" : "👤 Validador";
    let extra = "";
    const otros = (m.archivos || []).filter(f => !VC_IMG.test(f));
    if (otros.length) {
        extra += `<div class="chat-msg__entregables">📎 ${otros.map(escapeHtml).join(" · ")}</div>`;
    }
    if (m.imagenes && m.imagenes.length && codigo) extra += vcThumbs(codigo, m.iter, m.imagenes);
    if (m.pendientes && m.pendientes.length) {
        // Sin saltos ni sangría: .chat-msg usa white-space: pre-wrap.
        extra += `<div class="tam" style="margin-top:6px;">Necesito:</div><ol class="chat-msg__pend">`
            + m.pendientes.map(p => `<li>${escapeHtml(p)}</li>`).join("") + `</ol>`;
    }
    if (m.veredicto) extra += `<div style="margin-top:6px;">${vcVeredicto(m.veredicto)}</div>`;
    if (m.entregables && m.entregables.length && base) {
        extra += `<div class="chat-msg__entregables">${m.entregables.map(f =>
            `<a href="${base}${encodeURIComponent(f)}" download>⬇ ${escapeHtml(f)}</a>`).join("")}</div>`;
    }
    const texto = m.texto ? formatearMensajeChat(m.texto) : "<em>(sin comentario)</em>";
    div.innerHTML = `<div class="chat-msg__meta">${quien} · ITER${m.iter} · ${escapeHtml(fmtTs(m.ts))}</div>${texto}${extra}`;
    return div;
}

// ── Insumos comunes (manuales, Excels de primera línea, scripts) ─────
// Se suben UNA vez en la vista «Insumos» y los usan los 5 chats. En cada chat
// solo se muestra cuántos hay estudiados y las rutas que citan los scripts.
const VC_TIPO = { manual: "Manual", script: "Script", excel_primera_linea: "Excel 1ª línea",
                  excel: "Excel", otro: "Otro" };

function vcPintarInsumos(d) {
    // Línea del chat
    const linea = $("#vc-insumos-linea");
    if (linea) {
        linea.innerHTML = d.total
            ? `📚 <strong>${d.estudiados} de ${d.total}</strong> insumos estudiados (manuales, Excels de primera línea y scripts).
               <a href="#" id="vc-ir-insumos">Ver o subir insumos</a>`
            : `<div class="verificacion is-warn">Aún no hay manuales, Excels ni scripts.
               <a href="#" id="vc-ir-insumos">Súbelos en «Insumos»</a> para que el agente los estudie antes de escribir el notebook.</div>`;
        const ir = $("#vc-ir-insumos");
        if (ir) ir.addEventListener("click", ev => { ev.preventDefault(); abrirInsumos(); });
    }
    const rs = d.rutas_encontradas || [];
    const sug = $("#vc-rutas-sugeridas");
    if (sug) {
        sug.innerHTML = rs.length ? `<div class="tam" style="margin:6px 0 2px;">Rutas que citan
            los scripts y manuales (pulsa para añadirlas a las rutas del notebook):</div>`
            + rs.map((r, i) => `<button type="button" class="btn btn--ghost vc-ruta-sug" data-i="${i}">+ ${escapeHtml(r)}</button>`).join("") : "";
        for (const b of $$("#vc-rutas-sugeridas .vc-ruta-sug")) {
            b.addEventListener("click", () => {
                const ta = $("#vc-rutas");
                const r = rs[Number(b.dataset.i)];
                if (!ta.value.split("\n").some(l => l.includes(r))) ta.value = (ta.value.trim() + "\n" + r).trim();
                $("#vc-rutas-wrap").open = true;
                b.disabled = true;
            });
        }
    }
    // Tabla de la vista «Insumos»
    const tabla = $("#vci-tabla");
    if (!tabla) return;
    $("#vci-resumen").textContent = d.total ? `· ${d.estudiados} de ${d.total} estudiados` : "";
    tabla.innerHTML = d.total ? `<table class="tabla-modelos">
        <thead><tr><th>Archivo</th><th>Tipo</th><th>Origen</th><th>Estudio</th><th>Ficha</th><th></th></tr></thead>
        <tbody>${d.insumos.map((x, i) => `<tr>
            <td>${escapeHtml(x.nombre)}</td>
            <td>${escapeHtml(VC_TIPO[x.tipo] || x.tipo || "—")}</td>
            <td>${escapeHtml(x.origen)}</td>
            <td>${x.estudiado ? (x.modo === "ia" ? `IA · ${x.partes || 1} parte${(x.partes || 1) > 1 ? "s" : ""}`
                                                  : "sin IA") : "<em>pendiente</em>"}</td>
            <td>${escapeHtml(x.resumen || "")}</td>
            <td>${x.borrar ? `<button type="button" class="btn-ghost" data-borrar="${i}" aria-label="Borrar ${escapeHtml(x.nombre)}">✕</button>` : ""}</td>
        </tr>`).join("")}</tbody></table>`
        : `<p class="tam">Todavía no hay insumos.</p>`;
    for (const b of tabla.querySelectorAll("[data-borrar]")) {
        b.addEventListener("click", async () => {
            const x = d.insumos[Number(b.dataset.borrar)];
            if (!confirm(`¿Borrar ${x.nombre} de los insumos?`)) return;
            try {
                vcPintarInsumos(await pedirJSON(`/api/completa/insumos/archivo?ruta=${encodeURIComponent(x.borrar)}`,
                                                { method: "DELETE" }));
            } catch (err) { alert(err.message); }
        });
    }
}

async function vcCargarInsumos() {
    try { vcPintarInsumos(await pedirJSON("/api/completa/insumos")); } catch { /* sin modelo */ }
}

async function abrirInsumos() {
    VISTA_A_NAV["vista-vc-insumos"] = "btn-vc-insumos";
    mostrarVista("vista-vc-insumos");
    $("#vci-subida-estado").textContent = "";
    await vcCargarInsumos();
}

async function vcSubirInsumos(lista) {
    const files = [...lista];
    if (!files.length) return;
    const cat = ($("input[name=vci-cat]:checked") || {}).value || "manual";
    const fd = new FormData();
    fd.append("categoria", cat);
    for (const f of files) fd.append("archivos", f);
    $("#vci-subida-estado").textContent = `Subiendo ${files.length} archivo(s)…`;
    try {
        const r = await fetch("/api/completa/insumos/subir", { method: "POST", body: fd });
        const d = await r.json();
        if (!r.ok) throw new Error(d.detail || `Error ${r.status}`);
        vcPintarInsumos(d);
        $("#vci-subida-estado").textContent = `Subidos: ${d.guardados.join(", ")}. Pulsa «Estudiar insumos pendientes» `
            + "(o se estudiarán solos al pedir el siguiente notebook).";
    } catch (err) {
        $("#vci-subida-estado").textContent = err.message;
    }
}

async function vcEstudiar() {
    const ia = $("#vci-usar-ia").checked;
    $("#vci-estudiar").disabled = true;
    $("#vci-estudio-estado").textContent = ia
        ? "Leyendo y estudiando los insumos con IA (los manuales largos van por partes; puede tardar)…"
        : "Estudiando sin IA…";
    try {
        const d = await pedirJSON("/api/completa/insumos/estudiar", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ usar_ia: ia }),
        });
        vcPintarInsumos(d);
        $("#vci-estudio-estado").textContent = `Listo: ${d.estudiados} de ${d.total} estudiados.`;
    } catch (err) {
        $("#vci-estudio-estado").textContent = err.message;
    } finally {
        $("#vci-estudiar").disabled = false;
    }
}

async function vcCerrar(reabrir) {
    let motivo = "";
    if (!reabrir) {
        const ult = VC.datos.iteraciones[VC.datos.iteraciones.length - 1];
        const lista = ult && ult.veredicto && ult.veredicto.estado === "lista";
        const r = prompt((lista ? "" : "⚠ El agente aún pide otra iteración.\n\n")
            + `Cerrar ${VC.datos.fichero} en ITER${ult.n}. Motivo o conclusión (opcional):`, "");
        if (r === null) return;
        motivo = r;
    } else if (!confirm("¿Reabrir la etapa?")) return;
    try {
        await pedirJSON(`/api/completa/etapa/${VC.etapa}/cerrar`, {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ motivo, reabrir }),
        });
        await abrirEtapa(VC.etapa);
    } catch (err) { alert(err.message); }
}

function vcPintarAdjuntos() {
    const cont = $("#vc-adjuntos");
    if (!cont) return;
    cont.innerHTML = VC.archivos.map((f, i) => `<span class="vc-adjunto">${VC_IMG.test(f.name) ? "🖼 " : ""}${escapeHtml(f.name)}
        <button type="button" data-quitar="${i}" aria-label="Quitar ${escapeHtml(f.name)}">✕</button></span>`).join("");
    for (const b of cont.querySelectorAll("[data-quitar]")) {
        b.addEventListener("click", ev => {
            ev.stopPropagation();
            VC.archivos.splice(Number(b.dataset.quitar), 1);
            vcPintarAdjuntos();
        });
    }
}

function vcAgregar(lista) {
    for (const f of lista) {
        if (!VC.archivos.some(x => x.name === f.name)) VC.archivos.push(f);
    }
    vcPintarAdjuntos();
}

async function vcEnviar(ev) {
    ev.preventDefault();
    if (VC.enviando) return;
    const comentario = $("#vc-comentario").value.trim();
    const rutas = $("#vc-rutas").value.trim();
    const rutasCambiaron = rutas !== ($("#vc-rutas").dataset.original || "");
    if (!VC.archivos.length && !comentario && !rutasCambiaron && !(VC.datos && VC.datos.iteraciones.length)) {
        $("#vc-estado").textContent = "Indica las rutas de datos, adjunta evidencias o escribe un comentario.";
        return;
    }
    const fd = new FormData();
    fd.append("comentario", comentario);
    fd.append("usar_ia", $("#vc-usar-ia").checked ? "true" : "false");
    if (rutasCambiaron) fd.append("rutas", rutas);
    for (const f of VC.archivos) fd.append("archivos", f);
    VC.enviando = true;
    $("#vc-enviar").disabled = true;
    const lento = VC.datos && VC.datos.profundo;
    $("#vc-estado").textContent = $("#vc-usar-ia").checked
        ? `El agente estudia los insumos nuevos y escribe el notebook${lento ? " en dos pasadas (puede tardar varios minutos)" : ""}…`
        : "Generando el notebook plantilla…";
    const cont = $("#vc-mensajes");
    const n = VC.datos ? VC.datos.iteraciones.length : 0;
    cont.appendChild(vcMensaje({ quien: "validador", iter: n, ts: new Date().toISOString(),
        texto: comentario, archivos: VC.archivos.map(f => f.name) }, "", null));
    cont.scrollTop = cont.scrollHeight;
    try {
        const r = await fetch(`/api/completa/etapa/${VC.etapa}/iteracion`, { method: "POST", body: fd });
        let d = null;
        try { d = await r.json(); } catch { d = null; }
        if (!r.ok) throw new Error((d && d.detail) || `Error ${r.status}`);
        VC.datos = d;
        VC.archivos = [];
        vcPintarAdjuntos();
        $("#vc-comentario").value = "";
        $("#vc-estado").textContent = `Listo: ${d.iteracion.ipynb}. Ejecútalo y devuélveme ${d.iteracion.resultado_esperado}.`;
        await vcCargarResumen();
        vcPintarPestanas();
        vcPintarEtapa();
        vcCargarInsumos();
    } catch (err) {
        $("#vc-estado").textContent = "";
        const e = document.createElement("div");
        e.className = "verificacion is-error";
        e.textContent = err.message;
        cont.appendChild(e);
        cont.scrollTop = cont.scrollHeight;
    } finally {
        VC.enviando = false;
        $("#vc-enviar").disabled = false;
    }
}

function cablearCompleta() {
    const bm = $("#btn-modalidad");
    if (!bm) return;
    bm.addEventListener("click", alternarModalidad);
    for (const b of $$(".nav-etapa")) b.addEventListener("click", () => abrirEtapa(b.dataset.etapa));
    const drop = $("#vc-drop"), input = $("#vc-archivos");
    drop.addEventListener("click", () => input.click());
    drop.addEventListener("keydown", ev => {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); input.click(); }
    });
    drop.addEventListener("dragover", ev => { ev.preventDefault(); drop.classList.add("is-hover"); });
    drop.addEventListener("dragleave", () => drop.classList.remove("is-hover"));
    drop.addEventListener("drop", ev => {
        ev.preventDefault();
        drop.classList.remove("is-hover");
        vcAgregar(ev.dataTransfer.files);
    });
    // Pegar capturas directamente (Ctrl+V) en el comentario.
    $("#vc-comentario").addEventListener("paste", ev => {
        const imgs = [...(ev.clipboardData ? ev.clipboardData.files : [])].filter(f => f.type.startsWith("image/"));
        if (!imgs.length) return;
        ev.preventDefault();
        const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        vcAgregar(imgs.map((f, i) => new File([f], `captura_${ts}_${i + 1}.png`, { type: f.type })));
    });
    input.addEventListener("change", () => { vcAgregar(input.files); input.value = ""; });
    $("#vc-form").addEventListener("submit", vcEnviar);
    $("#vci-estudiar").addEventListener("click", vcEstudiar);
    $("#btn-vc-insumos").addEventListener("click", abrirInsumos);
    const dz = $("#vci-drop"), fi = $("#vci-archivos");
    dz.addEventListener("click", () => fi.click());
    dz.addEventListener("keydown", ev => {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); fi.click(); }
    });
    dz.addEventListener("dragover", ev => { ev.preventDefault(); dz.classList.add("est-dropzone--hover"); });
    dz.addEventListener("dragleave", () => dz.classList.remove("est-dropzone--hover"));
    dz.addEventListener("drop", ev => {
        ev.preventDefault();
        dz.classList.remove("est-dropzone--hover");
        vcSubirInsumos(ev.dataTransfer.files);
    });
    fi.addEventListener("change", () => { vcSubirInsumos(fi.files); fi.value = ""; });
    $("#vc-comentario").addEventListener("keydown", ev => {
        if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) vcEnviar(ev);
    });
}

window.addEventListener("DOMContentLoaded", cablearCompleta);
