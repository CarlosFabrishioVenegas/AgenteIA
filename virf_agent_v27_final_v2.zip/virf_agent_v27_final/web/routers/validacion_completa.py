"""
VALIDACIÓN COMPLETA: chat por etapa (00–04) sobre las automatizaciones.

- GET    /api/completa/estado                      → modalidad + resumen de etapas
- POST   /api/completa/modalidad                   → «normal» | «completa» (explícito)
- GET    /api/completa/etapa/{codigo}              → misión, iteraciones y mensajes
- POST   /api/completa/etapa/{codigo}/iteracion    → archivos + comentario → ITERn
- GET    /api/completa/insumos                     → manuales, Excels y scripts y su estudio
- POST   /api/completa/insumos/subir               → sube a la carpeta común (categoría explícita)
- DELETE /api/completa/insumos/archivo?ruta=…      → borra un insumo común
- POST   /api/completa/insumos/estudiar            → lee enteros y estudia los pendientes
- POST   /api/completa/etapa/{codigo}/cerrar       → el validador cierra / reabre la etapa
- GET    /api/completa/paquete                     → lo que se llevará al barrido de controles (08)
- GET    /api/completa/etapa/{codigo}/descargar/{f}→ ITERn .ipynb / .md
- GET    /api/completa/etapa/{codigo}/imagen/{n}/{f} → imagen de sustento de ITERn

La lógica vive en `modulos/validacion_completa.py`; aquí solo la sesión, la
subida y las descargas. La «Validación normal» no pasa por aquí.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from ..services import modelos_store
from ..services.roles import requiere
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/completa", tags=["validacion_completa"])


class CambiarModalidad(BaseModel):
    modalidad: str


def _vc():
    from modulos import validacion_completa
    return validacion_completa


def _codigo_valido(codigo: str) -> str:
    if codigo not in _vc().ETAPAS:
        raise HTTPException(404, f"etapa desconocida: {codigo!r}")
    return codigo


def contexto_modelo(ctx: dict) -> str:
    """Ficha + entendimiento del modelo (si ya se generó)."""
    m = ctx["modelo"]
    partes = [f"Modelo: {m.get('nombre', '')} · dominio: {m.get('dominio', '')} · "
              f"tier: {m.get('tier', '')}"]
    ent = ctx["base"] / f"entendimiento_modelo_{m['slug']}.md"
    if ent.is_file():
        partes.append(ent.read_text(encoding="utf-8", errors="ignore")[:6000])
    return "\n\n".join(partes)


@router.get("/estado")
def estado(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    return {"modalidad": ctx["modelo"].get("modalidad", "normal"),
            **_vc().resumen_etapas(ctx["outputs"])}


@router.post("/modalidad")
def cambiar_modalidad(body: CambiarModalidad,
                      ctx: dict = Depends(contexto_sesion),
                      _val: dict = Depends(requiere("validar"))) -> dict[str, Any]:
    try:
        m = modelos_store.actualizar_meta(ctx["validador"]["codigo"], ctx["modelo"]["slug"],
                                          modalidad=body.modalidad)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    if m is None:
        raise HTTPException(404, "el modelo ya no existe")
    return {"modelo": m}


@router.get("/etapa/{codigo}")
def ver_etapa(codigo: str, ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    vc = _vc()
    from modulos.tipos_modelo import TIPOS
    tipos = [t for t in (ctx["modelo"].get("tipos_modelo") or []) if t in TIPOS]
    return {**vc.estado_etapa(ctx["outputs"], _codigo_valido(codigo)),
            "tipos_modelo": [{"id": t, "nombre": TIPOS[t]["nombre"],
                              "pasos": TIPOS[t]["etapas"].get(codigo, [])} for t in tipos]}


@router.post("/etapa/{codigo}/iteracion")
async def iterar(codigo: str,
                 comentario: str = Form(""),
                 usar_ia: bool = Form(True),
                 # None = reutilizar las rutas vigentes de la etapa.
                 rutas: Optional[str] = Form(None),
                 archivos: list[UploadFile] = File(default=[]),
                 ctx: dict = Depends(contexto_sesion),
                 _val: dict = Depends(requiere("validar"))) -> dict[str, Any]:
    vc = _vc()
    _codigo_valido(codigo)
    if ctx["modelo"].get("modalidad") != "completa":
        raise HTTPException(409, "Este modelo está en Validación normal. Cámbialo a "
                                 "Validación completa para usar las etapas 00–04.")
    recibidos: list[tuple[str, bytes]] = []
    for a in archivos or []:
        contenido = await a.read()
        if not contenido:
            continue
        try:
            recibidos.append((vc.nombre_seguro(a.filename or ""), contenido))
        except ValueError as exc:
            raise HTTPException(400, f"{a.filename}: {exc}")
    try:
        # Bloqueante (lee Excels, llama a la IA): fuera del event loop.
        res = await asyncio.to_thread(
            vc.ejecutar_iteracion,
            inputs=ctx["inputs"], outputs=ctx["outputs"], codigo=codigo,
            archivos=recibidos, comentario=comentario, usar_ia=usar_ia, rutas_texto=rutas,
            contexto_modelo=contexto_modelo(ctx), modelo=ctx["modelo"].get("nombre", ""),
            validador=ctx["validador"].get("codigo", ""),
            # Explícitos, de la ficha del modelo: hacen al agente experto en ESTE tipo de modelo.
            tipos_modelo=ctx["modelo"].get("tipos_modelo") or [], dominio=ctx["modelo"].get("dominio", ""),
            codigo_modelo=ctx["modelo"].get("codigo_modelo", ""))
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    except Exception as exc:                                   # noqa: BLE001
        raise HTTPException(502, f"No se pudo completar la iteración: {exc}")
    modelos_store.actualizar_actividad(ctx["validador"]["codigo"], ctx["modelo"]["slug"],
                                       estado="en_progreso")
    return {"iteracion": res["iteracion"], **ver_etapa(codigo, ctx)}


class Estudiar(BaseModel):
    usar_ia: bool = True


def _insumos(ctx: dict, fichas: list | None = None) -> dict[str, Any]:
    from modulos import estudio_insumos as est
    estado = est.fichas_en_cache(ctx["inputs"])
    return {"insumos": estado,
            "estudiados": sum(1 for x in estado if x["estudiado"]),
            "total": len(estado),
            "rutas_encontradas": est.rutas_encontradas(fichas if fichas is not None else
                                                       [x for x in estado if x["estudiado"]])}


@router.get("/insumos")
def ver_insumos(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """Manuales, Excels de primera línea y scripts disponibles, y si ya se estudiaron."""
    return _insumos(ctx)


@router.post("/insumos/subir")
async def subir_insumos(categoria: str = Form(...),
                        archivos: list[UploadFile] = File(...),
                        ctx: dict = Depends(contexto_sesion),
                        _val: dict = Depends(requiere("validar"))) -> dict[str, Any]:
    """Sube manuales, Excels de primera línea o scripts a la carpeta COMÚN de los 5 chats."""
    from modulos import estudio_insumos as est
    recibidos = []
    for a in archivos:
        contenido = await a.read()
        if contenido:
            recibidos.append((a.filename or "", contenido))
    if not recibidos:
        raise HTTPException(400, "no llegó ningún archivo con contenido")
    try:
        guardados = est.subir(ctx["inputs"], categoria, recibidos)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"guardados": guardados, **_insumos(ctx)}


@router.delete("/insumos/archivo")
def borrar_insumo(ruta: str, ctx: dict = Depends(contexto_sesion),
                  _val: dict = Depends(requiere("validar"))) -> dict[str, Any]:
    """Borra un archivo de la carpeta común (no toca la evidencia del paso 03)."""
    from modulos import estudio_insumos as est
    try:
        if not est.borrar(ctx["inputs"], ruta):
            raise HTTPException(404, f"no existe: {ruta}")
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return _insumos(ctx)


@router.post("/insumos/estudiar")
async def estudiar_insumos(body: Estudiar, ctx: dict = Depends(contexto_sesion),
                           _val: dict = Depends(requiere("validar"))) -> dict[str, Any]:
    """Lee ENTEROS y estudia los insumos pendientes (caché por huella)."""
    from modulos import estudio_insumos as est
    try:
        fichas = await asyncio.to_thread(est.estudiar, ctx["inputs"], usar_ia=body.usar_ia)
    except Exception as exc:                                   # noqa: BLE001
        raise HTTPException(502, f"No se pudo estudiar los insumos: {exc}")
    return _insumos(ctx, fichas)


class Cierre(BaseModel):
    motivo: str = ""
    reabrir: bool = False


@router.post("/etapa/{codigo}/cerrar")
def cerrar(codigo: str, body: Cierre, ctx: dict = Depends(contexto_sesion),
           _val: dict = Depends(requiere("validar"))) -> dict[str, Any]:
    """El validador da la etapa por cumplida (o la reabre). Decisión humana."""
    vc = _vc()
    _codigo_valido(codigo)
    try:
        vc.cerrar_etapa(ctx["outputs"], codigo, ctx["validador"].get("codigo", ""),
                        body.motivo, reabrir=body.reabrir)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {**vc.estado_etapa(ctx["outputs"], codigo),
            "resumen": vc.resumen_etapas(ctx["outputs"])}


_TIPOS = {".ipynb": "application/x-ipynb+json", ".md": "text/markdown; charset=utf-8",
          ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
          ".gif": "image/gif", ".bmp": "image/bmp", ".webp": "image/webp"}


def _servir(raiz: Path, rel: str) -> FileResponse:
    raiz = raiz.resolve()
    ruta = (raiz / rel).resolve()
    try:
        ruta.relative_to(raiz)
    except ValueError:
        raise HTTPException(400, "fuera del directorio de la etapa")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {rel}")
    tipo = _TIPOS.get(ruta.suffix.lower())
    if tipo is None:
        raise HTTPException(400, f"tipo no servible: {ruta.suffix}")
    return FileResponse(ruta, filename=ruta.name, media_type=tipo)


@router.get("/etapa/{codigo}/descargar/{fichero}")
def descargar(codigo: str, fichero: str,
              ctx: dict = Depends(contexto_sesion)) -> FileResponse:
    """Notebook ITERn (.ipynb), revisión (.md) o hallazgos de la etapa (_HALLAZGOS.xlsx/.md)."""
    vc = _vc()
    _codigo_valido(codigo)
    nombre = Path(fichero).name
    if nombre != fichero or not (nombre.endswith((".ipynb", ".md"))
                                 or nombre.endswith("_HALLAZGOS.xlsx")):
        raise HTTPException(400, f"nombre inválido: {fichero}")
    return _servir(vc.dir_salida(ctx["outputs"], codigo), nombre)


# ── Consolidado final: lee el Excel y el .md de hallazgos de cada etapa ────

@router.post("/consolidar")
def consolidar(ctx: dict = Depends(contexto_sesion),
               _val: dict = Depends(requiere("validar"))) -> dict[str, Any]:
    """Lee los entregables de hallazgos de las cinco etapas, los contrasta y
    escribe el consolidado (Excel + .md + Excel de sustento de cada hallazgo)."""
    from modulos import hallazgos_completa as hc
    try:
        return hc.consolidar(ctx["inputs"], ctx["outputs"])
    except Exception as exc:                          # noqa: BLE001
        raise HTTPException(500, f"no se pudo consolidar: {exc}")


@router.get("/paquete")
def paquete(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """Lo que la validación completa lleva al barrido de controles (08), sin escribir nada."""
    return {"modalidad": ctx["modelo"].get("modalidad", "normal"),
            **_vc().paquete_para_validacion(ctx["inputs"], ctx["outputs"])}


@router.get("/consolidado")
def consolidado(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    from modulos import hallazgos_completa as hc
    return {"consolidado": hc.ultimo_consolidado(ctx["outputs"])}


@router.get("/consolidado/descargar/{fichero}")
def consolidado_descargar(fichero: str, ctx: dict = Depends(contexto_sesion)) -> FileResponse:
    from modulos import hallazgos_completa as hc
    nombre = Path(fichero).name
    if nombre != fichero or nombre not in (f"{hc.NOMBRE_CONSOLIDADO}.xlsx", f"{hc.NOMBRE_CONSOLIDADO}.md"):
        raise HTTPException(400, f"nombre inválido: {fichero}")
    return _servir(Path(ctx["outputs"]) / "validacion_completa" / hc.DIR_CONSOLIDADO, nombre)


@router.get("/etapa/{codigo}/imagen/{iteracion}/{fichero}")
def imagen(codigo: str, iteracion: int, fichero: str,
           ctx: dict = Depends(contexto_sesion)) -> FileResponse:
    """Imagen de sustento enviada en la iteración."""
    vc = _vc()
    _codigo_valido(codigo)
    nombre = Path(fichero).name
    if nombre != fichero or Path(nombre).suffix.lower() not in vc.EXT_IMAGEN:
        raise HTTPException(400, f"nombre inválido: {fichero}")
    return _servir(vc.dir_entrada(ctx["inputs"], codigo), f"ITER{int(iteracion)}/{nombre}")
