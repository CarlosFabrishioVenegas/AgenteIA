"""
Búsqueda LOCAL (BM25, sin IA ni red) en la evidencia del modelo de la sesión:
manuales, seguimiento, código, usos… Es lo que le faltaba a la revisión con el
agente (paso 09) para ser consecuente con el validador.

Antes, el agente solo veía de cada observación unos 600 caracteres de evidencia
y 800 de código. Cuando el validador respondía «eso está en el manual, sección
4.2», el agente no podía comprobarlo y —con la regla «no inventes»— contestaba
«no consta en la evidencia» y repreguntaba. Ahora, con cada respuesta del
validador, se buscan en la evidencia de la sesión los fragmentos que tratan lo
que dice, y el agente los recibe para confirmarlo o rebatirlo con la cita.

El índice (fragmentos de ~1200 caracteres con su página) se guarda en
`<sesión>/_indice_evidencia_chat.json` y se rehace solo si cambian los ficheros
(huella de nombre, tamaño y fecha). Leer un manual largo cuesta una vez.
"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Optional

TAM_FRAGMENTO = 1200
#: Carpetas de `inputs/` que NO son evidencia del modelo para el chat.
_EXCLUIDAS = {"estandares", "validacion_completa", "automatizaciones", "logoempresa"}
#: Datos crudos: no se indexan (volumen y privacidad); su perfil ya va al pipeline.
_EXCLUIDAS_SUB = ("calidad_datos/datasets",)
_EXT = {".pdf", ".docx", ".pptx", ".txt", ".md", ".py", ".ipynb", ".sql", ".r", ".xlsx",
        ".xlsm", ".csv", ".json"}
_MAX_BYTES = 40 * 1024 * 1024


def _archivos(inputs: Path) -> list[Path]:
    if not inputs.is_dir():
        return []
    salida = []
    for p in sorted(inputs.rglob("*")):
        if not p.is_file() or p.name.startswith((".", "~$")):
            continue
        rel = p.relative_to(inputs).as_posix()
        if rel.split("/", 1)[0] in _EXCLUIDAS or rel.startswith(_EXCLUIDAS_SUB):
            continue
        if p.suffix.lower() not in _EXT:
            continue
        try:
            if p.stat().st_size > _MAX_BYTES:
                continue
        except OSError:
            continue
        salida.append(p)
    return salida


def _huella(inputs: Path, archivos: list[Path]) -> str:
    h = hashlib.sha256()
    for p in archivos:
        try:
            st = p.stat()
            h.update(f"{p.relative_to(inputs).as_posix()}|{st.st_size}|{int(st.st_mtime)}".encode())
        except OSError:
            continue
    return h.hexdigest()[:20]


def _leer(p: Path) -> str:
    """Texto del fichero con los lectores del pipeline (Mx_01). '' si no se puede."""
    try:
        from Mx_01_LecturaEvidencias import leer_archivo      # motor/ está en sys.path
    except ImportError:                                       # pragma: no cover
        try:
            from motor.Mx_01_LecturaEvidencias import leer_archivo
        except ImportError:
            return p.read_text(encoding="utf-8", errors="ignore") if p.suffix in (".txt", ".md", ".py") else ""
    try:
        d = leer_archivo(p) or {}
        return str(d.get("contenido") or "")
    except Exception:                                          # noqa: BLE001
        return ""


def _fragmentar(texto: str, archivo: str) -> list[dict]:
    """Fragmentos por párrafo, con página (los lectores separan páginas con \\f)."""
    frags: list[dict] = []
    for n_pag, pagina in enumerate(texto.split("\f"), start=1):
        actual = ""
        for parrafo in re.split(r"\n\s*\n|\n(?=[A-ZÁÉÍÓÚÑ0-9#])", pagina):
            parrafo = " ".join(parrafo.split())
            if not parrafo:
                continue
            if len(actual) + len(parrafo) > TAM_FRAGMENTO and actual:
                frags.append({"archivo": archivo, "pagina": n_pag, "texto": actual})
                actual = ""
            actual = f"{actual} {parrafo}".strip()
            while len(actual) > 2 * TAM_FRAGMENTO:          # párrafos enormes (código)
                frags.append({"archivo": archivo, "pagina": n_pag, "texto": actual[:TAM_FRAGMENTO]})
                actual = actual[TAM_FRAGMENTO:]
        if actual:
            frags.append({"archivo": archivo, "pagina": n_pag, "texto": actual})
    return frags


def _indice_path(ctx: dict) -> Path:
    return Path(ctx["base"]) / "_indice_evidencia_chat.json"


def fragmentos(ctx: dict) -> list[dict]:
    """Fragmentos de toda la evidencia de la sesión (con caché por huella)."""
    inputs = Path(ctx["inputs"])
    archivos = _archivos(inputs)
    huella = _huella(inputs, archivos)
    ruta = _indice_path(ctx)
    if ruta.is_file():
        try:
            d = json.loads(ruta.read_text(encoding="utf-8"))
            if d.get("huella") == huella:
                return d.get("fragmentos") or []
        except (OSError, ValueError):
            pass
    frags: list[dict] = []
    for p in archivos:
        texto = _leer(p)
        if texto.strip():
            frags += _fragmentar(texto, p.relative_to(inputs).as_posix())
    try:
        ruta.parent.mkdir(parents=True, exist_ok=True)
        ruta.write_text(json.dumps({"huella": huella, "fragmentos": frags}, ensure_ascii=False),
                        encoding="utf-8")
    except OSError:
        pass
    return frags


def buscar(ctx: dict, consulta: str, top_k: int = 4,
           frags: Optional[list[dict]] = None) -> list[dict[str, Any]]:
    """Fragmentos más relevantes para la consulta (BM25Plus, local, deduplicados)."""
    from rank_bm25 import BM25Plus
    from src.rag.indexador_lexico import tokenizar
    frags = fragmentos(ctx) if frags is None else frags
    if not frags:
        return []
    q = tokenizar(consulta or "")
    if not q:
        return []
    corpus = [tokenizar(f["texto"]) or ["_"] for f in frags]
    puntajes = BM25Plus(corpus).get_scores(q)
    qs = set(q)
    # Al menos dos términos de la consulta en el fragmento (o uno si la
    # consulta es muy corta): un solo término común trae ruido.
    minimo = 2 if len(qs) >= 4 else 1
    orden = sorted((i for i in range(len(frags)) if len(qs & set(corpus[i])) >= minimo),
                   key=lambda i: puntajes[i], reverse=True)
    salida, vistos = [], set()
    for i in orden:
        firma = " ".join(corpus[i][:40])
        if firma in vistos:
            continue
        vistos.add(firma)
        salida.append({**frags[i], "score": round(float(puntajes[i]), 3)})
        if len(salida) == top_k:
            break
    return salida


def bloque_para_prompt(resultados: list[dict], tope: int = 900) -> str:
    """Texto para el prompt: cada fragmento con su archivo y página."""
    if not resultados:
        return "  (no se encontraron fragmentos de la evidencia del modelo sobre esto)"
    return "\n".join(f"  [{r['archivo']}, pág. {r['pagina']}] {r['texto'][:tope]}"
                     for r in resultados)
