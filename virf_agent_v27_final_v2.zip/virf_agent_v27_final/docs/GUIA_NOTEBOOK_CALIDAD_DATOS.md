# Guía del notebook de calidad de datos

> Generada desde el código por `scripts/generar_guia_calidad_datos.py`: no la edites a mano (regénérala). Se sirve también en la web: **Controles de datos → ✨ Diseñar con IA → ¿Cómo prendo el notebook? → Abrir la guía completa**.

## Contenido

1. Para qué sirve
2. Antes de empezar: qué pegar en VIRF
3. Generar el notebook
4. Cómo prenderlo (ejecutarlo)
5. Recorrido del notebook
6. Porcentaje de cumplimiento
7. Devolverlo y qué revisa el agente
8. Controles por tipo de modelo
9. Cómo agregarle más controles
10. Traer tus controles de otros notebooks
11. Cómo sigue aprendiendo el agente
12. Problemas comunes
13. Referencia

## 1. Para qué sirve

El validador **no sube los datos** (viven en el entorno del banco). Pega en VIRF la salida de `.info()` y `.describe()` de cada base; con ese **perfil** el agente arma un **notebook autocontenido** (solo `pandas` y `numpy`) que trae **siempre todos los controles**: los que se deducen del perfil, los del **tipo de modelo** (VaR no es ALM ni LaR), los aprendidos del dominio, una **batería completa** sobre todas las columnas y una plantilla lista de cada tipo del catálogo que necesita un dato del negocio. Al ejecutarlo donde están los datos calcula el **porcentaje de cumplimiento** y guarda un Excel que se devuelve a VIRF: el mismo agente lo revisa, entra (si lo decides) en la validación y **enseña** al agente para los próximos modelos.

Principios: la IA solo **propone** (todo control se valida contra el catálogo y el perfil); el notebook **no llama a ninguna IA** ni envía datos; nada se ejecuta en el servidor; las filas que fallan se quedan en tu equipo (evidencia local).

## 2. Antes de empezar: qué pegar en VIRF

En tu entorno, para cada base del modelo:

```python
import pandas as pd
pd.set_option('display.max_columns', None)      # que no recorte columnas
df.info()                                        # columnas, tipos y no nulos
print(df.describe(include='all').to_string())   # estadísticos de TODAS las columnas
```

En Spark: `df.printSchema()` y `df.describe().show(truncate=False)`. Pega cada salida en su recuadro (una base por bloque; **+ Agregar otra base** para más). Con *1 · Ver qué entendió el agente* compruebas columnas, nulos y estadísticos antes de generar.

> El `describe()` redondea a 6 cifras (99999999 sale `1.000000e+08`): el agente lo sabe y, si ve un mínimo o máximo «redondo», propone un control de **valores centinela** con los dos candidatos.

## 3. Generar el notebook

1. Comprueba el **dominio** y elige el **tipo de modelo** (Configuración → Tipo de modelo: VaR, run-off, IRRBB, prepago, NMD, LCR…). El tipo decide lo que el notebook sabe del negocio (§8): sin él trae solo los controles generales del dominio.
2. **Contexto (opcional):** qué es cada base, llaves, periodo, reglas de negocio conocidas.
3. Casilla **Incluir los controles que el agente aprendió de este dominio**: suma las lecciones APROBADAS por un revisor (§11).
4. **2 · Proponer controles con IA y generar notebook** (reglas + IA, con coste) o **Solo reglas (sin IA)** (coste 0). La IA solo añade controles que pasan la validación: tipo del catálogo, columnas que existen, parámetros correctos y ninguna cifra inventada en la justificación.
5. Revisa el resumen (propuestos · tipo de modelo · batería · cobertura del catálogo) y la tabla, y descarga el `.ipynb`.

## 4. Cómo prenderlo (ejecutarlo), paso a paso

**Requisitos:** Python 3.9 o superior con `pandas`, `numpy` y `openpyxl` (para el Excel).
Opcionales: `matplotlib` (gráfico) y `pyarrow` (archivos `.parquet`). **No** necesitas VIRF
ni internet: el notebook no llama a ninguna IA ni envía datos a ningún sitio.

**Opción A · En tu PC con Jupyter**
1. Guarda este `.ipynb` en una carpeta y abre una terminal ahí.
2. Crea el entorno (solo la primera vez):
   ```
   python -m venv .venv
   .venv\Scripts\activate            (Windows)
   source .venv/bin/activate         (Mac / Linux)
   pip install pandas numpy openpyxl matplotlib jupyterlab
   ```
3. Arranca Jupyter con `jupyter lab` y abre el notebook.
4. En **0 · Configuración** escribe en `RUTAS` la ruta de cada base.
5. Menú **Run → Run All Cells** (o *Kernel → Restart Kernel and Run All Cells*).

**Opción B · En VS Code:** abre el `.ipynb`, elige el intérprete del entorno en
*Select Kernel* (arriba a la derecha) y pulsa **Run All**. Si pide instalar `ipykernel`, acepta.

**Opción C · En Databricks:** *Workspace → Import* el `.ipynb`. En **3 · Carga** usa la
lectura mínima que trae comentada (`select` de las columnas que usan los controles + filtro
del corte + `limit`): nunca leas la tabla completa. Guarda la salida en tu volumen y descárgala.

**¿Quieres probarlo antes de tener los datos?** Pon `MODO_DEMO = True` y ejecuta todo:
genera datos **sintéticos** con la forma del perfil. Sirve para comprobar que el notebook
prende; esos resultados **no** valen para la validación (el Excel lo dice y VIRF no los usa
ni en la validación ni en el aprendizaje).

**Qué genera** (en la carpeta de `SALIDA`):

| Archivo | Qué es | ¿Se devuelve a VIRF? |
|---|---|---|
| `resultado_controles_datos.xlsx` | Cuadro de cumplimiento + comprobación contra el perfil + controles programados + metadatos (huella sha256 de cada base) | **Sí** |
| `resultado_controles_datos.csv` | El mismo cuadro, en CSV | Opcional |
| `resultado_controles_datos_resumen.png` | Gráfico del % de incumplimiento por control | No (es para ti) |
| `evidencia_local_resultado_controles_datos.xlsx` | Muestra de las filas que fallan, una hoja por control | **No**: puede tener datos personales; guárdala como soporte |

**Si algo falla**

| Mensaje | Qué hacer |
|---|---|
| `FileNotFoundError` | Revisa la ruta en `RUTAS` (en Windows: `r"C:\carpeta\archivo.csv"`). |
| `UnicodeDecodeError` | En `OPCIONES_LECTURA`: `{'base': {'encoding': 'latin-1'}}`. |
| Todas las columnas salen pegadas en una | Separador: `{'base': {'sep': ';'}}` en `OPCIONES_LECTURA`. |
| `ModuleNotFoundError: openpyxl` | `pip install openpyxl` (mientras tanto se guarda el CSV). |
| Un control dice «No evaluable — No se pudo ejecutar» | La columna no existe o cambió de nombre: mira **3 · Comprobación contra el perfil**. |
| `MemoryError` o va muy lento | Lee solo lo necesario: `{'base': {'usecols': COLUMNAS_USADAS['base']}}` (en parquet, `columns`). |


## 5. Recorrido del notebook

· **Entender el modelo**: qué hace, qué bases usa, qué puede fallar en los datos y qué pedir a la primera línea.
0. **Configuración**: rutas de tus bases (lo único obligatorio), opciones y el enlace `BASES` / `ROLES`.
1. **Entorno**: versiones y paquetes opcionales.
2. **Librería y perfil**: funciones de control, adaptadores y lo que pegaste en VIRF (no editar).
3. **Carga y comprobación contra el perfil**: avisa si la base no es la que se perfiló; **3b** enlace de roles.
4. **Controles propuestos**: reglas, IA, aprendidos y los del dominio; una celda por control.
4a. **Controles del tipo de modelo (negocio)**: por roles, con el porqué de negocio (ids `M…`).
4b. **Batería completa**: corre SIEMPRE sobre todas las columnas (solo muestra lo que no cumple).
4c. **Controles del repositorio del tipo de modelo**: los especializados (Kupiec, LCR, CPR, run-off…).
4d. **Batería dinámica**: columnas que no estaban en el perfil (se descubren al cargar).
5. **Tus controles sin programar**: plantillas listas de TODOS los tipos que faltan, con tus columnas.
6. **Tus controles programados o traídos de otros notebooks**: con adaptadores, sin reescribirlos.
7. **Resumen y porcentaje de cumplimiento**: global, ponderado, por dimensión, base y origen; cobertura del catálogo.
8. **Excel de resultados**: lo que devuelves a VIRF (y la evidencia local, que no se sube).
9. **Devolverlo a VIRF y enseñar al agente.**

Detalles que conviene saber:

* **Numeración:** `C` propuestos · `M` negocio del tipo de modelo (por roles) · `T` reglas del dominio · `D` repositorio del dominio · `B` batería completa · `BD` batería dinámica (columnas que no estaban en el perfil) · `X` tuyos sin programar · `P` programados o traídos · `IA` del experto (validación completa).
* **Entender el modelo** (al inicio, si elegiste el tipo): qué hace el modelo, qué produce y para qué se usa, qué bases necesita (y con cuál de las tuyas se enlazó), qué puede fallar en los datos y por qué importa, las referencias normativas y **qué pedir a la primera línea**.
* **0 · `BASES` y `ROLES`**: el enlace entre los conceptos de negocio (P&L, saldo, banda, tasa de salida…) y tus columnas. Corrígelo una vez y todos los controles `M` que lo usan cambian. La sección **3b** lo comprueba, sugiere columnas para lo que falta (`ENLAZAR_SUGERENCIAS = True` las aplica) y lo guarda en la hoja *Roles*. Un control sin su columna sale como **Pendiente** (no cuenta en el %).
* **0 · Configuración** calcula `COLUMNAS_USADAS` (las columnas que tocan los controles, por base): úsalo para leer solo lo necesario en bases grandes (`usecols`) y en Databricks (`select`).
* **3 · Comprobación contra el perfil**: si la base que cargas no tiene las filas, columnas, tipos o nulos del perfil que pegaste, lo avisa y lo deja en la hoja *Perfil_vs_datos*; el agente lo anota como **limitación** de la revisión.
* **4b · Batería** solo imprime lo que **no** cumple (`MOSTRAR_BATERIA_COMPLETA = True` para verlo todo). Re-ejecutar una celda **no duplica** su resultado.
* **8 · Excel**: hojas **Controles**, **Resumen**, **Cobertura**, **Roles**, **Perfil_vs_datos**, **Controles_personalizados**, **Metadatos** (la primera es la que leen VIRF y el pipeline). *Metadatos* guarda la propuesta, versiones, modo demo, el porcentaje de cumplimiento y la **huella sha256** de cada base.

## 6. Porcentaje de cumplimiento

| Indicador | Cómo se calcula |
|---|---|
| **Porcentaje de cumplimiento** | controles que **cumplen** ÷ controles **evaluados** × 100. Los «No evaluable» no cuentan a favor ni en contra: van como limitación. |
| Ponderado por criticidad | igual, pesando ALTA = 3, MEDIA = 2, BAJA = 1. |
| Cumplimiento medio de los datos | promedio del «% De cumplimiento del data set» de cada control. |
| Por dimensión, base, origen y criticidad | el mismo cálculo por grupo (hoja *Resumen*). |
| Cobertura del catálogo | cuántos de los tipos corrieron; los demás son plantillas (hoja *Cobertura*). |

El notebook lo imprime en grande en la sección 7, lo guarda en *Resumen* y *Metadatos*, y VIRF lo **recalcula** al revisar: si el Excel declara un porcentaje distinto del que sale del cuadro (se editó después de ejecutar), lo anota como **incoherencia**.

## 7. Devolverlo y qué revisa el agente

En **Controles de datos → ✨ Diseñar con IA → 3 · Revisar resultados**: sube el Excel, elige su **clasificación** (obligatoria) y marca lo que quieras:

| Casilla | Qué hace |
|---|---|
| Redactar las observaciones con IA | La IA redacta riesgo, observación y recomendación por cada control que no cumple; cada texto se verifica (sin cifras ajenas al cuadro). Sin ella, por reglas. |
| Usar estos resultados en la validación | Copia el Excel a `calidad_datos/resultadocalidad_de_datos/` de la sesión: entra en el ámbito *Calidad de datos* del pipeline. |
| Enseñar al agente | Registra lo ejecutado como **lecciones del dominio** (pendientes de aprobar). |

La revisión determinista (siempre) comprueba: coherencia entre decisión, % y umbral (salvo los controles del repositorio, que deciden por su propia prueba); controles propuestos que no aparecen; no evaluables; diferencias contra el perfil; resultados del MODO_DEMO; el porcentaje declarado contra el recalculado; y los controles programados (su código viaja como texto). Un Excel del **MODO_DEMO** se puede revisar, pero VIRF **rechaza** usarlo en la validación o en el aprendizaje.

## 8. Controles por tipo de modelo

No son los mismos controles para un VaR que para un run-off, un IRRBB o un LCR. El **tipo de modelo** de la ficha (explícito, nunca se deduce) y el **dominio** deciden tres capas, además de la batería general:

**Capa 0 · Controles de negocio del tipo de modelo (`M…`)**: cada tipo tiene una ficha (`modulos/tipos_modelo_trading.py`, `tipos_modelo_alm.py`, `tipos_modelo_liquidez.py`) con sus bases lógicas, los ROLES que las definen, lo que puede fallar y los controles expresados por roles, cada uno con su **porqué de negocio**. El detalle completo de cada tipo (negocio, bases, riesgos, controles, preguntas a la primera línea y pasos de experto por etapa) está en `docs/GUIA_TIPOS_DE_MODELO.md`.

| Tipo de modelo | Familia | Bases lógicas | Controles de negocio | Análisis del repositorio |
|---|---|---|---|---|
| **VaR de mercado (simulación histórica, paramétrico o Monte Carlo)** (`var`) | Trading | posiciones, factores, pyg, escenarios_pnl, var_reportado, covarianzas, contabilidad | 35 | `var_negativos`, `kupiec`, `semaforo_basilea`, `severidad_excepciones`, `alineacion_pnl_var`, `christoffersen`, `backtesting_excedencias`, `monotonia_niveles_var`, `escalado_horizonte`, `matriz_covarianzas` |
| **Expected Shortfall / FRTB (modelo interno IMA)** (`es_frtb`) | Trading | pyg, es_reportado, observaciones, horizontes | 14 | `var_negativos`, `kupiec`, `semaforo_basilea`, `severidad_excepciones`, `alineacion_pnl_var`, `christoffersen`, `backtesting_excedencias`, `monotonia_niveles_var`, `pla_frtb`, `rfet_modelabilidad` |
| **Pruebas de estrés de mercado (históricas, hipotéticas e inversas)** (`stress_mercado`) | Trading | escenarios, posiciones, resultados | 6 | — |
| **Valoración de instrumentos y derivados (con verificación independiente de precios)** (`valoracion`) | Trading | operaciones, precios | 8 | — |
| **Curvas de tasas y superficies de volatilidad (datos de mercado)** (`curvas`) | Trading | curvas, volatilidades | 8 | — |
| **Riesgo de contraparte (exposición, EAD SA-CCR, CVA)** (`contraparte`) | Trading | operaciones, colateral, exposiciones | 7 | — |
| **ALM · IRRBB: EVE y NII (gap de reprecio)** (`irrbb`) | ALM | posiciones, flujos, escenarios, resultados, contabilidad | 26 | `gap_reprecios`, `delta_eve`, `escenarios_irrbb_completos`, `sot_eve_tier1`, `brecha_duracion`, `delta_nii` |
| **Prepago de créditos (modelo conductual de prepago, MCP)** (`prepago`) | ALM | saldos, operaciones, modelo | 14 | `cpr_prepago`, `smm_cpr_consistencia`, `backtesting_prepago` |
| **Depósitos sin vencimiento (NMD): núcleo, decaimiento y beta** (`nmd`) | ALM | saldos, cuentas, modelo | 16 | `runoff_curvas`, `runoff_supervivencia_saldos`, `decaimiento_nmd`, `vida_media_nmd`, `nucleo_topes_bcbs`, `beta_deposito`, `supervivencia_km` |
| **Cancelación anticipada y renovación de depósitos a plazo** (`cancelacion_dpf`) | ALM | depositos, tasas | 8 | `cancelacion_anticipada` |
| **Supervivencia / retiro de cuentas y saldos (MCR)** (`supervivencia`) | ALM | cuentas, curva | 7 | `runoff_curvas`, `supervivencia_km` |
| **Precios de transferencia de fondos (FTP)** (`ftp`) | ALM | operaciones, curva_ftp | 4 | — |
| **Run-off: supervivencia y desgaste del saldo (vencimiento conductual)** (`runoff`) | ALM | saldos, cuentas, curva, componentes, bandas, contabilidad | 31 | `runoff_curvas`, `runoff_supervivencia_saldos`, `runoff_saltos_cosechas`, `nucleo_topes_bcbs`, `supervivencia_km` |
| **Ratio de cobertura de liquidez (RCL / LCR)** (`lcr`) | Liquidez | hqla, salidas, entradas, ratio | 11 | `horizonte_supervivencia`, `lcr`, `hqla_composicion`, `lcr_tope_entradas` |
| **Ratio de financiamiento neto estable (RFNE / NSFR)** (`nsfr`) | Liquidez | asf, rsf, ratio, contabilidad | 7 | `nsfr`, `factores_nsfr` |
| **Brechas (gaps) de liquidez contractuales y conductuales** (`brechas_liquidez`) | Liquidez | flujos, contabilidad | 7 | `brecha_liquidez_acumulada` |
| **Liquidity at Risk (LaR, VaR de liquidez)** (`lar`) | Liquidez | flujos, resultado | 5 | `lar_percentil` |
| **Estrés de liquidez y horizonte de supervivencia** (`stress_liquidez`) | Liquidez | proyeccion | 4 | `horizonte_supervivencia`, `runoff_tasas`, `hqla_composicion`, `concentracion_fondeo`, `brecha_liquidez_acumulada` |
| **Concentración de fondeo y principales depositantes** (`concentracion_fondeo`) | Liquidez | depositantes | 4 | `concentracion_fondeo` |

**Capa 1 · Reglas del tipo de modelo (`T…`)**: controles del catálogo que se activan por la semántica de las columnas. Viven como datos en `modulos/controles_ia.py → REGLAS_TIPO_MODELO` (añadir una regla = añadir un diccionario):

| Tipo de modelo | Columnas | Control | Criticidad | Qué verifica · por qué |
|---|---|---|---|---|
| `var` | pnl, pl, pyg, perdida, ganancia, resultado, retorno, rentab | `completitud` {'umbral_pct': 0.0} | ALTA | la serie de P&L no tiene días sin dato · el backtesting compara P&L contra VaR día a día: un nulo es una observación perdida. |
| `var` | pnl, pl, pyg, perdida, ganancia, resultado, retorno, rentab | `outliers_iqr` {'k': 5.0, 'umbral_pct': 1.0} | MEDIA | el P&L no tiene saltos más allá de 5·IQR · las colas gruesas son normales en P&L; k = 5 caza errores de carga, no la cola. |
| `var` | pnl, pl, pyg, perdida, ganancia, resultado, retorno, rentab | `constante` {} | ALTA | el P&L no es constante · un P&L plano invalida el backtesting. |
| `var` | var, cvar, expected_shortfall, valor_en_riesgo | `completitud` {'umbral_pct': 0.0} | ALTA | el VaR está informado todos los días · sin VaR del día no hay excepción que contar. |
| `var` | var, cvar, expected_shortfall, valor_en_riesgo (+ columna de fecha) | `variacion_temporal` {'agregacion': 'mean', 'max_variacion_pct': 50.0, 'umbral_pct': 5.0} | MEDIA | el VaR no salta más de un 50 % entre fechas consecutivas · un salto así suele ser un cambio de cartera, de parámetro o un error de carga. |
| `var` | excepcion, exception, breach, hit, violacion | `dominio` {'valores': ['0', '1'], 'umbral_pct': 0.0} | ALTA | el indicador de excepción es 0 o 1 · Kupiec y Christoffersen cuentan excepciones 0/1. |
| `alm` | cpr, prepago, smm | `rango` {'minimo': 0.0, 'umbral_pct': 0.0} | ALTA | la tasa de prepago está entre 0 y 1 (o 0 y 100) · un CPR fuera de rango rompe la curva conductual. |
| `alm` | beta | `rango` {'minimo': 0.0, 'maximo': 1.0, 'umbral_pct': 0.0} | ALTA | el beta de traspaso está entre 0 y 1 · un beta fuera de [0, 1] no tiene sentido económico. |
| `alm` | saldo, balance, capital, principal | `proporcion_ceros` {'umbral_pct': 5.0} | MEDIA | pocas posiciones con saldo cero · saldos en cero suelen ser operaciones canceladas que siguen en la base del gap. |
| `alm` | banda, bucket, tramo, reprecio, repricing | `completitud` {'umbral_pct': 0.0} | ALTA | toda posición tiene banda de reprecio · sin banda la posición no entra en el gap. |
| `alm` | moneda, divisa, currency | `cardinalidad` {'minimo': 1.0, 'maximo': 10.0} | BAJA | pocas monedas distintas · muchas monedas suelen indicar códigos mal cargados. |
| `alm` | deltaeve, deltanii, eve, nii | `completitud` {'umbral_pct': 0.0} | ALTA | las sensibilidades ΔEVE/ΔNII están completas · son la base del límite IRRBB. |
| `alm` | fecha venc, vto, maturity vs. corte, proceso, reporte, fechadato, fechainformacion | `consistencia_fechas` {'operador': '>=', 'umbral_pct': 0.0} | MEDIA | el vencimiento no es anterior al corte · una posición vencida no debería proyectar flujos (o es cartera vencida: dilo). |
| `alm` | fecha desembolso, apertura, origina, inicio, emision vs. corte, proceso, reporte, fechadato, fechainformacion | `consistencia_fechas` {'operador': '<=', 'umbral_pct': 0.0} | ALTA | la fecha de origen no es posterior al corte · una operación no puede nacer después de la foto. |
| `lar` | flujo, entrada, salida, inflow, outflow | `completitud` {'umbral_pct': 0.0} | ALTA | los flujos están completos · un flujo nulo desplaza la brecha de liquidez. |
| `lar` | entrada, salida, inflow, outflow | `no_negativos` {'umbral_pct': 0.0} | MEDIA | entradas y salidas como magnitudes positivas · el signo va en la columna, no en el valor: mezclar convenciones invierte la brecha. |
| `lar` | banda, bucket, tramo, horizonte | `completitud` {'umbral_pct': 0.0} | ALTA | todo flujo tiene banda temporal · sin banda no hay brecha acumulada. |
| `lar` | hqla, activoliquido, liquidos | `no_negativos` {'umbral_pct': 0.0} | ALTA | los activos líquidos no son negativos · el HQLA es un stock: un negativo es un error. |
| `lar` | haircut, castigo, descuento | `rango` {'minimo': 0.0, 'umbral_pct': 0.0} | ALTA | el haircut está entre 0 y 1 (o 0 y 100) · un haircut fuera de rango infla o anula el HQLA. |
| `lar` | lcr, nsfr, ratio, cobertura | `no_negativos` {'umbral_pct': 0.0} | ALTA | los ratios regulatorios no son negativos · un LCR/NSFR negativo es imposible. |
| `lar` | fecha fechaflujo, fechapago, fechacobro vs. corte, proceso, reporte, fechadato, fechainformacion | `consistencia_fechas` {'operador': '>=', 'umbral_pct': 0.0} | MEDIA | los flujos proyectados no son anteriores al corte · un flujo pasado no es liquidez futura. |

**Capa 2 · Repositorio del dominio (`D…`)**: los controles especializados de `inputs/repositorio_controles/<dominio>/` (Kupiec, Christoffersen, LCR, NSFR, CPR, ΔEVE…), embebidos en el notebook con sus columnas **enlazadas a tu perfil** (por nombre exacto o por sinónimos: `campo_pnl` → `pnl`, `pyg`, `resultado`…). Lo que no se pudo enlazar sale marcado y se edita en `PARAMS_Dxx`. Su decisión es la del propio control («Observado» cuenta como no cumple y «Revisión manual» como no evaluable). `shared/` no se repite: lo cubre la batería.

## 9. Cómo agregarle más controles

Seis niveles, de menos a más esfuerzo. Empieza siempre por el más bajo que resuelva tu caso.

### Nivel 1 · Ajustar lo propuesto (sin programar)

* **Cambiar un umbral:** en la celda del control (o en la lista `BATERIA`), edita `umbral_pct=` (o `max_dias=`, `tolerancia_pct=`, `umbral_psi=`…). El Excel guarda el valor usado y, si enseñas al agente, aprende ese umbral para el dominio.
* **Quitar un control:** comenta su celda (`Ctrl + /`) o su línea en `BATERIA`. Si era un control aprendido, cuenta como **descarte**.

### Nivel 2 · Las plantillas de la sección 5 (sin programar)

El notebook trae una plantilla de **cada tipo que no corrió**, con tus columnas. Descoméntala, pon el dato del negocio y ejecuta. Se numeran `X01`, `X02`… con origen **validador**. Un ejemplo de cada tipo del catálogo:

```python
CONTROLES_ADICIONALES = [
    {'dataset': 'cartera', 'tipo': 'completitud', 'columnas': ['saldo_capital'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'unicidad', 'columnas': ['id_operacion'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'rango', 'columnas': ['tasa_interes'], 'params': {'minimo': 0, 'maximo': 1, 'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'no_negativos', 'columnas': ['plazo_dias'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'dominio', 'columnas': ['segmento'], 'params': {'valores': ['Mayorista', 'Minorista', 'Pyme']},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'tipo_numerico', 'columnas': ['monto_texto'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'fecha_valida', 'columnas': ['fecha_desembolso'], 'params': {'desde': '2000-01-01', 'hasta': '2026-12-31'},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'frescura', 'columnas': ['fecha_corte'], 'params': {'max_dias': 31},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'volumen_minimo', 'columnas': [], 'params': {'min_filas': 1000},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'constante', 'columnas': ['moneda'], 'params': {},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'outliers_iqr', 'columnas': ['saldo_capital'], 'params': {'k': 3, 'umbral_pct': 1},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'consistencia', 'columnas': ['saldo_capital', 'monto_desembolsado'], 'params': {'operador': '<='},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'formato', 'columnas': ['id_operacion'], 'params': {'patron': 'OP\\d{5}'},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'integridad', 'columnas': ['id_cliente'], 'params': {'ref_dataset': 'clientes', 'ref_columna': 'id_cliente'},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'suma_control', 'columnas': ['saldo_capital'], 'params': {'valor_esperado': 15250000.0, 'tolerancia_pct': 0.5},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'completitud_condicional', 'columnas': ['estado', 'fecha_cancelacion'], 'params': {'valores': ['CANCELADO']},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'valores_centinela', 'columnas': ['fecha_nacimiento'], 'params': {},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'clientes', 'tipo': 'longitud', 'columnas': ['dni'], 'params': {'minimo': 8, 'maximo': 8, 'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'clientes', 'tipo': 'espacios_extremos', 'columnas': ['nombre'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'clientes', 'tipo': 'caracteres_invalidos', 'columnas': ['direccion'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'categorias_equivalentes', 'columnas': ['segmento'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'fecha_futura', 'columnas': ['fecha_desembolso'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'consistencia_fechas', 'columnas': ['fecha_desembolso', 'fecha_vencimiento'], 'params': {'operador': '<='},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'proporcion_ceros', 'columnas': ['saldo_capital'], 'params': {'umbral_pct': 5},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'cardinalidad', 'columnas': ['moneda'], 'params': {'minimo': 1, 'maximo': 3},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'conciliacion_totales', 'columnas': ['saldo_capital'], 'params': {'ref_dataset': 'contabilidad', 'ref_columna': 'saldo', 'tolerancia_pct': 0.5},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'conciliacion_conteos', 'columnas': [], 'params': {'ref_dataset': 'maestro', 'tolerancia_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'variacion_temporal', 'columnas': ['saldo_capital', 'fecha_corte'], 'params': {'agregacion': 'sum', 'max_variacion_pct': 20},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'pyg', 'tipo': 'serie_continua', 'columnas': ['fecha'], 'params': {'frecuencia': 'B', 'excluir': ['2026-07-28', '2026-07-29']},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'cartera', 'tipo': 'estabilidad_psi', 'columnas': ['score', 'fecha_corte'], 'params': {'umbral_psi': 0.25},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'factores', 'tipo': 'valores_repetidos', 'columnas': ['precio', 'fecha', 'id_factor'], 'params': {'max_repeticiones': 5, 'umbral_pct': 1},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'factores', 'tipo': 'saltos_serie', 'columnas': ['precio', 'fecha', 'id_factor'], 'params': {'k': 10, 'umbral_pct': 0.5},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'var_reportado', 'tipo': 'monotonia', 'columnas': ['var_95', 'var_99'], 'params': {'sentido': 'creciente', 'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'curvas', 'tipo': 'monotonia_curva', 'columnas': ['factor_descuento', 'tenor', 'fecha'], 'params': {'sentido': 'decreciente', 'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'saldos', 'tipo': 'relacion_aritmetica', 'columnas': ['saldo_inicial', 'amortizacion', 'prepago', 'saldo_final'], 'params': {'operacion': 'resta', 'tolerancia_pct': 0.5, 'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'precios', 'tipo': 'diferencia_relativa', 'columnas': ['precio_modelo', 'precio_ipv'], 'params': {'tolerancia_pct': 2, 'umbral_pct': 5},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'escenarios', 'tipo': 'categorias_requeridas', 'columnas': ['escenario'], 'params': {'valores': ['paralelo_arriba', 'paralelo_abajo', 'empinamiento', 'aplanamiento', 'cortos_arriba', 'cortos_abajo']},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'saldos', 'tipo': 'combinaciones_completas', 'columnas': ['fecha', 'segmento'], 'params': {'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'factores', 'tipo': 'minimo_por_grupo', 'columnas': ['id_factor'], 'params': {'min_filas': 250, 'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'distribucion_nmd', 'tipo': 'suma_por_grupo', 'columnas': ['proporcion', 'segmento'], 'params': {'valor_esperado': 1.0, 'tolerancia_pct': 0.5},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'posiciones', 'tipo': 'conciliacion_por_grupo', 'columnas': ['saldo', 'moneda'], 'params': {'ref_dataset': 'contabilidad', 'ref_columna': 'saldo', 'ref_claves': ['moneda'], 'tolerancia_pct': 0.5},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'posiciones', 'tipo': 'signo_por_categoria', 'columnas': ['saldo', 'activo_pasivo'], 'params': {'positivos': ['ACTIVO'], 'negativos': ['PASIVO']},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'posiciones', 'tipo': 'banda_coherente', 'columnas': ['dias_reprecio', 'banda'], 'params': {'limites': [0, 30, 90, 365, 36500], 'etiquetas': ['0-1M', '1-3M', '3-12M', '>1A']},
     'descripcion': '…', 'criticidad': 'MEDIA'},
    {'dataset': 'pyg', 'tipo': 'fechas_habiles', 'columnas': ['fecha'], 'params': {'excluir': ['2026-07-28', '2026-07-29'], 'umbral_pct': 0},
     'descripcion': '…', 'criticidad': 'MEDIA'},
]
```

### Nivel 3 · Un control programado por ti

En la sección **6**, una función con el decorador `@mi_control` (ver también §10 para traerla de otro notebook):

```python
@mi_control(dataset='cartera', columnas=['saldo_capital', 'monto_desembolsado'],
            descripcion='El saldo vivo no supera el monto desembolsado',
            dimension='Consistencia', criticidad='ALTA', params={'umbral_pct': 0.0})
def saldo_no_supera_desembolso(df, columnas, umbral_pct=0.0, **_):
    saldo = pd.to_numeric(df[columnas[0]], errors='coerce')
    desembolso = pd.to_numeric(df[columnas[1]], errors='coerce')
    return saldo > desembolso      # True = la fila falla
```

Se numera `P01`… con origen **personalizado** y su código viaja como texto en *Controles_personalizados*. VIRF **no ejecuta** ese código ni lo copia solo a otros notebooks.

### Nivel 4 · Un tipo nuevo en el catálogo (desarrollador)

Cuando un control programado se repite (aparece en *Candidatos al catálogo*, §11) o es claramente reutilizable, conviértelo en un tipo del catálogo, en `modulos/controles_ia.py`:

1. **`CATALOGO`**: añade `"mi_tipo": {"dimension": …, "params": {nombre: float|list|str}, "descripcion": …}`.
2. **`_N_COLUMNAS`**: cuántas columnas usa si no es una (2, `None` = una o más, 0 = ninguna).
3. **`_LIBRERIA`**: la función `def mi_tipo(df, columnas, <params>, umbral_pct=0.0, **_)`; llama a `_exigir(df, columnas)` y devuelve `_res(evaluados, afectados, umbral_pct, diagnóstico, mascara)`. Es código que corre en el equipo del validador: solo `pandas`/`numpy`.
4. **`validar_params`**: las reglas de sus parámetros (obligatorios, rangos, valores permitidos).
5. *(Opcional)* **`bateria_completa`** si aplica a cualquier columna sin datos del negocio, o una regla en **`REGLAS_TIPO_MODELO`** si es propia de un tipo de modelo.
6. **Test** (como `tests/test_controles_bateria_tipo_modelo.py`): detecta lo que siembras y el notebook sigue corriendo de punta a punta.
7. Añade su ejemplo a `EJEMPLOS` en este script y **regenera la guía** (si no, falla a propósito).

### Nivel 5 · Una regla del tipo de modelo (desarrollador)

Un diccionario más en `REGLAS_TIPO_MODELO["var" | "alm" | "lar"]`: `columna` (patrón del nombre) o `pares` (dos fechas), `tipo`, `params`, `criticidad`, `que` y `por_que`. La tabla de §8 se regenera sola.

### Nivel 6 · Un control especializado en el repositorio del dominio

Crea un `.py` en `inputs/repositorio_controles/<dominio>/` con `META` (literal: descripcion, dimension, evidencia, referencia, orden, params con los `campo_*`) y `def control(df, datasets, params) -> {pct, decision, diagnostico}`. Entra solo en los notebooks de ese dominio (capa 2, §8) y en la pestaña **Notebook entregable**. Ver `inputs/repositorio_controles/README.md`. Hoy hay:

| Carpeta (dominio) | Control | Qué verifica |
|---|---|---|
| `alm/` | `backtesting_prepago` | El CPR modelado debe seguir de cerca al observado: el error absoluto medio (MAE) entre ambos no debe superar la tolerancia. |
| `alm/` | `beta_deposito` | El beta de traspaso (deposit beta = sensibilidad de la tasa del depósito a la tasa de mercado) debe estar en [0,1] y dentro de la banda esperada del modelo. |
| `alm/` | `brecha_duracion` | La brecha de duración (duración del activo − duración del pasivo) debe mantenerse dentro del límite fijado por el ALCO. |
| `alm/` | `cancelacion_anticipada` | La tasa mensual de cancelación anticipada observada (saldo cancelado antes del vencimiento ÷ saldo vivo) es coherente con la que usa el modelo. |
| `alm/` | `cpr_prepago` | La tasa de prepago observada (CPR = prepagos / saldo) debe caer dentro de la banda esperada del modelo conductual. |
| `alm/` | `decaimiento_nmd` | Los depósitos sin vencimiento (NMD) deben mostrar un núcleo estable: la proporción de saldo que permanece (mín/promedio) por encima del umbral 'core'. |
| `alm/` | `delta_eve` | La máxima caída del valor económico (ΔEVE) entre los escenarios de shock no debe exceder el 15% del capital de nivel 1 (outlier IRRBB). |
| `alm/` | `delta_nii` | La caída del margen financiero (ΔNII) a 12 meses ante el shock de tasa no debe exceder el límite de apetito (% del NII base). |
| `alm/` | `escenarios_irrbb_completos` | El análisis IRRBB debe cubrir los seis escenarios supervisores: paralelo ↑/↓, empinamiento, aplanamiento, tasa corta ↑/↓. |
| `alm/` | `gap_reprecios` | Ninguna banda de reprecio debe presentar un descalce \|activos − pasivos\| superior al límite sobre el total de activos. |
| `alm/` | `nucleo_topes_bcbs` | El núcleo estable de los depósitos sin vencimiento y su vencimiento medio no superan los topes de BCBS 368: minorista transaccional 90 % y 5 años; minorista no  |
| `alm/` | `runoff_curvas` | La curva de run-off del modelo es coherente: la supervivencia S(t) empieza en 1 y nunca sube, el run-off acumulado es R(t) = 1 − S(t), el desgaste incremental d |
| `alm/` | `runoff_saltos_cosechas` | Por segmento y edad, el link ratio de cada cosecha (saldo(k) ÷ saldo(k−1)) no se aleja más de k desviaciones robustas (y del desvío mínimo) del de las demás cos |
| `alm/` | `runoff_supervivencia_saldos` | La curva de supervivencia del modelo se reproduce con la historia: por cosechas, S(k) = Π (Σ saldo(j) ÷ Σ saldo(j−1)) sobre las cosechas observadas en ambos mes |
| `alm/` | `smm_cpr_consistencia` | El SMM/CPR reportado es el que sale de los saldos: SMM = prepago ÷ (saldo inicial − amortización programada) y CPR = 1 − (1 − SMM)^12. |
| `alm/` | `sot_eve_tier1` | El peor ΔEVE (en valor absoluto) entre los escenarios de shock no debe superar el 15% del capital de Nivel 1 (prueba del valor atípico supervisor). |
| `alm/` | `supervivencia_km` | La supervivencia observada de las cuentas (Kaplan–Meier, tratando como censuradas las que siguen abiertas) es coherente con la curva del modelo a 12, 24 y 60 me |
| `alm/` | `vida_media_nmd` | La vida media asumida para los depósitos sin vencimiento (NMD) debe ser positiva y no superar el tope prudencial (típicamente 5 años). |
| `lar/` | `brecha_liquidez_acumulada` | La brecha de liquidez acumulada (entradas−salidas, sumada por banda temporal en orden) no debe caer por debajo de cero dentro del horizonte. |
| `lar/` | `concentracion_fondeo` | La financiación no debe depender en exceso de una sola contraparte: la mayor cuota de fondeo por proveedor debe estar por debajo del umbral. |
| `lar/` | `factores_nsfr` | Los factores ASF y RSF aplicados son valores de la norma: ASF 0, 50, 90, 95 o 100 %; RSF 0, 5, 10, 15, 50, 65, 85 o 100 %. |
| `lar/` | `horizonte_supervivencia` | La posición de liquidez ACUMULADA (entradas − salidas) no debe caer bajo el colchón en ningún bucket. |
| `lar/` | `hqla_composicion` | Los activos líquidos de Nivel 2 no pueden superar el 40% del HQLA total, y los de Nivel 2B el 15% (tras haircuts). |
| `lar/` | `lar_percentil` | El LaR reportado es el percentil de las salidas netas acumuladas en el horizonte (suma móvil de los flujos netos), con la ventana y el nivel del manual. |
| `lar/` | `lcr` | El LCR (HQLA / salidas netas de 30 días) debe ser >= 100% en todo periodo reportado. |
| `lar/` | `lcr_tope_entradas` | El LCR reportado es HQLA ÷ (salidas − mín(entradas; 75 % de las salidas)): las entradas no pueden cubrir más del 75 % de las salidas. |
| `lar/` | `nsfr` | El NSFR (fondeo estable disponible / requerido) debe ser >= 100%. |
| `lar/` | `runoff_tasas` | La tasa de salida en estrés de cada segmento es al menos el percentil histórico de las caídas de saldo en el horizonte (p. ej. 30 días al 99 %): r_t = 1 − S(t+h |
| `shared/` | `columnas_constantes` | Ninguna columna relevante debería tener un único valor constante en todas las filas (indicio de campo mal poblado o congelado). |
| `shared/` | `completitud_datos` | Ninguna columna del data set debe superar el umbral de valores faltantes (nulos/NaN). |
| `shared/` | `duplicados_registros` | La proporción de registros duplicados (fila completa, o por clave si se indica) debe estar por debajo del umbral. |
| `shared/` | `frescura_datos` | La observación más reciente del data set debe estar dentro de la ventana máxima de antigüedad. |
| `shared/` | `volumen_minimo` | El data set debe tener al menos el número mínimo de observaciones para sostener el análisis (p. ej. ~250 para backtesting). |
| `var/` | `alineacion_pnl_var` | La marca de excepción del backtesting compara el P&L de cada día con el VaR del día ANTERIOR (rezago de un día), no con el del mismo día. |
| `var/` | `backtesting_excedencias` | Backtesting por conteo de excedencias: nº de excepciones en la ventana debe caer en zona verde del semáforo de Basilea. |
| `var/` | `christoffersen` | Independencia de las excepciones (Christoffersen): las excepciones no deben agruparse (clustering) en el tiempo. |
| `var/` | `escalado_horizonte` | El VaR a 10 días es coherente con el VaR a 1 día: si se escala por la raíz del tiempo, VaR10 ≈ √10 × VaR1 (3,16 veces) en casi todos los días. |
| `var/` | `kupiec` | Backtesting de VaR (Kupiec POF): la tasa de excepciones debe ser consistente con 1 − nivel de confianza. |
| `var/` | `matriz_covarianzas` | La matriz de correlaciones del VaR paramétrico es simétrica, tiene unos en la diagonal y es semidefinida positiva (ningún autovalor negativo). |
| `var/` | `monotonia_niveles_var` | El VaR debe crecer en magnitud con el nivel de confianza: \|VaR99\| >= \|VaR95\| >= \|VaR90\| en cada fecha. Una inversión delata un error de cómputo. |
| `var/` | `pla_frtb` | Prueba de atribución de P&L (PLA): el P&L teórico del modelo de riesgo (RTPL) se parece al hipotético (HPL) — Spearman > 0,80 y Kolmogorov–Smirnov < 0,09 (zona  |
| `var/` | `rfet_modelabilidad` | Cada factor de riesgo es modelable (RFET): en los últimos 12 meses tiene ≥ 24 observaciones reales sin ningún periodo de 90 días con menos de 4, o ≥ 100 observa |
| `var/` | `semaforo_basilea` | El nº de excepciones de backtesting en ~250 días debe situar el modelo en zona VERDE de Basilea (0-4); amarilla (5-9) es observación, roja (>=10) es rechazo. |
| `var/` | `severidad_excepciones` | Cuando la pérdida supera el VaR, el exceso medio (pérdida−VaR)/VaR no debería ser grande: excesos severos apuntan a colas mal capturadas. |
| `var/` | `var_negativos` | El VaR estimado debe ser estrictamente positivo (un VaR ≤ 0 es un error de cálculo o de signo). |

## 10. Traer tus controles de otros notebooks

Si ya resolviste controles en otros notebooks (Kaggle, cursos, proyectos anteriores, otras áreas), no los reescribas. Tres caminos, de más rápido a más permanente:

**A · ¿Ya existe en el catálogo?** Casi todo lo habitual sí. Usa su tipo (plantilla de la sección 5) y te ahorras el código:

| En tu otro notebook | En VIRF (tipo del catálogo) |
|---|---|
| `df.isnull().sum()` · `df[c].isna().mean()` | `completitud` (la batería ya lo corre en todas) |
| `df.duplicated().sum()` · `df[k].duplicated()` | `unicidad` (sin columnas = filas idénticas) |
| `df[c].between(a, b)` | `rango` |
| `(df[c] < 0).sum()` | `no_negativos` |
| `~df[c].isin(lista)` | `dominio` |
| `pd.to_numeric(df[c], errors='coerce').isna()` | `tipo_numerico` |
| `pd.to_datetime(df[c], errors='coerce').isna()` | `fecha_valida` |
| `df[c].max()` vs. hoy | `frescura` |
| código IQR con `quantile(.25/.75)` | `outliers_iqr` |
| `df[a] <= df[b]` | `consistencia` (fechas: `consistencia_fechas`) |
| `df[c].str.match(regex)` | `formato` |
| `df[c].str.len()` | `longitud` |
| `df[c] != df[c].str.strip()` | `espacios_extremos` |
| `df.merge(ref, how='left', indicator=True)` → `left_only` | `integridad` |
| `df[c].sum()` vs. total contable | `suma_control` / `conciliacion_totales` |
| `len(df)` vs. `len(otra)` | `conciliacion_conteos` |
| `df[c].nunique()` | `cardinalidad` / `constante` |
| `groupby(periodo)[c].sum().pct_change()` | `variacion_temporal` |
| función PSI | `estabilidad_psi` |
| Great Expectations `expect_column_values_to_not_be_null` | `completitud` |
| GE `expect_column_values_to_be_unique` | `unicidad` |
| GE `expect_column_values_to_be_between` | `rango` |
| GE `expect_column_values_to_be_in_set` | `dominio` |
| GE `expect_column_values_to_match_regex` | `formato` |
| GE `expect_column_value_lengths_to_be_between` | `longitud` |
| GE `expect_table_row_count_to_be_between` | `volumen_minimo` |
| GE `expect_column_pair_values_A_to_be_greater_than_B` | `consistencia` |
| pandera `nullable=False` · `unique=True` | `completitud` · `unicidad` |
| pandera `Check.in_range` · `Check.isin` · `Check.str_matches` | `rango` · `dominio` · `formato` |
| deequ `isComplete` · `isUnique` · `hasPattern` · `isContainedIn` · `hasSize` | `completitud` · `unicidad` · `formato` · `dominio` · `volumen_minimo` |

**B · Pégalo tal cual en la sección 6** con `@mi_control(...)` encima. No hace falta adaptar el código: el notebook acepta lo que tu función devuelva y le pasa solo los argumentos que acepta.

| Tu función devuelve | Se lee como |
|---|---|
| `_res(...)` | tal cual |
| Serie booleana (`True` = la fila falla) | filas que fallan sobre `len(df)` |
| DataFrame con las filas que fallan | ídem (por índice) |
| `int` | número de filas que fallan |
| `(evaluados, afectados)` | tal cual |
| `True` / `False` | cumple / no cumple |

```python
# Pegado de otro notebook: firma solo df y devuelve las filas malas.
@mi_control(dataset='cartera', descripcion='Operaciones duplicadas por llave y fecha',
            dimension='Unicidad', criticidad='ALTA')
def duplicados_otro_notebook(df):
    return df[df.duplicated(subset=['id_operacion', 'fecha_corte'], keep=False)]

# Si tu función devuelve otra cosa (un dict, un texto…), conviértelo con un adaptador:
#   desde_mascara(df, mascara) · desde_filas(df, filas) · desde_conteo(evaluados, afectados)
#   desde_booleano(cumple)
```

Pasos: 1) copia la celda o función; 2) si era una celda suelta, envuélvela en `def f(df): …` y haz que devuelva las filas que fallan; 3) ponle `@mi_control(dataset=…, descripcion=…, dimension=…, criticidad=…)`; 4) ejecuta: sale como `Pxx` en el Excel, con su código.

**C · Un módulo con todos tus controles.** Junta tus funciones en `mis_controles.py` (al lado del notebook), con una lista `CONTROLES = [{'funcion': f, 'dataset': …, 'descripcion': …, 'dimension': …, 'criticidad': …}, …]`, y en la sección 6: `import mis_controles` y `MIS_CONTROLES += mis_controles.CONTROLES`. Así lo reutilizas en todos tus modelos.

**Para que quede para todos:** enséñaselo al agente al devolver el Excel (queda como *candidato al catálogo* con su código) y pide a un desarrollador que lo convierta en tipo del catálogo (nivel 4), en regla del tipo de modelo (nivel 5) o en control del repositorio (nivel 6).

## 11. Cómo sigue aprendiendo el agente

El agente no se reentrena: **aprende datos, no pesos**. Guarda por dominio lo que los validadores ejecutaron de verdad y lo vuelve a proponer cuando la base tiene esas columnas.

```
propuesta ──▶ notebook ──▶ ejecutas, ajustas umbrales, añades X/P ──▶ Excel
    ▲                                                                   │
    │                                         «Enseñar al agente»      ▼
controles «aprendido» ◀── un REVISOR aprueba ◀── lección PENDIENTE (por dominio)
```

**Qué se aprende:** los controles del catálogo que ejecutaste salvo los que el agente ya propone solo sin cambios (reglas, tipo de modelo y batería): los de la IA que mantuviste, los **umbrales que cambiaste** (el aprobado gana la próxima vez), los `X` que añadiste; los aprendidos que comentaste cuentan como **descarte**.

**Qué NO se aprende**: código (los `P` son *candidatos al catálogo*, como texto, para un desarrollador); los del repositorio (`D`, ya viven allí); datos (solo definiciones y cifras agregadas); resultados del MODO_DEMO.

**Aprobación (rol revisor):** cada lección nace **pendiente** y no influye hasta que un revisor la **aprueba** en *4 · Lo que el agente aprendió de este dominio*, con motivo (queda en la auditoría). Quien la enseñó **no puede** aprobarla. Al aprobar se congelan sus parámetros; si después los validadores usan otros, la tabla lo avisa («cambio desde la aprobación») hasta que se vuelva a decidir.

**Cómo se usa:** al generar un notebook del mismo dominio, cada lección **activa** cuyas columnas existen en el nuevo perfil (sin importar mayúsculas, tildes ni espacios) entra con origen **aprendido** y una justificación de quién la aprobó y cuántas veces se ejecutó. Si coincide con un control de reglas, ganan los parámetros aprobados. A la IA se le pasa como «criterio de la entidad».

**Olvido:** un revisor puede **negar** una lección; y una lección que se **descarta** más veces de las que se usa deja de proponerse sola.

**Registro:** `feedback/aprendizaje_controles.jsonl`, solo-anexar y **sellado** (cada evento lleva el hash del anterior). La web avisa si alguien lo editó a mano. Las lecciones son por dominio (VaR, ALM, LaR…): no se mezclan.

| Parámetro | Por defecto | Qué hace |
|---|---|---|
| `CONTROLES_APRENDIDOS` | 1 | 0 = no proponer lo aprendido (se sigue registrando). |
| `CONTROLES_APRENDIDOS_MAX` | 25 | Tope de controles aprendidos por notebook. |

## 12. Problemas comunes

| Síntoma | Causa y solución |
|---|---|
| «no se reconoció ninguna columna» | Pegaste solo una parte del `.info()`: copia la salida completa. |
| La propuesta no tiene controles de la IA | La IA no devolvió JSON útil o sus controles no pasaron la validación: mira los avisos de la propuesta (dicen por qué). |
| No salen controles del tipo de modelo | El dominio del modelo no es VaR, ALM o LaR (o un alias), o las columnas no se llaman como esperan las reglas: añade los controles desde las plantillas. |
| Un `Dxx` dice «sin enlazar» | Esa columna del repositorio no está en tu perfil: edita `PARAMS_Dxx`. |
| Un control aprendido no aparece | No está aprobado, está negado, se descartó más de lo que se usó, o la base no tiene sus columnas. Revísalo en la sección 4 de la web. |
| «no puede decidir sobre ella» al aprobar | Eres quien enseñó la lección: la aprueba otro revisor. |
| El Excel subido «salió del MODO_DEMO» | Pon `MODO_DEMO = False` y ejecuta sobre tus bases. |
| Incoherencia «declara un X % de cumplimiento» | Se editó el Excel tras ejecutar: vuelve a ejecutar. |
| Limitación «no coinciden con el perfil» | La base ejecutada no es la perfilada (otro corte, columnas renombradas). Vuelve a perfilar o explica la diferencia. |

## 13. Referencia

### Catálogo de controles

| Tipo | Dimensión | Columnas | Parámetros | Qué mide |
|---|---|---|---|---|
| `completitud` | Completitud | 1 o más | `umbral_pct` | Filas con nulos en las columnas (sobre el total). |
| `unicidad` | Unicidad | 1 o más | `umbral_pct` | Filas con la llave (columnas) repetida; sin columnas, filas idénticas. |
| `rango` | Validez | 1 | `minimo`, `maximo`, `umbral_pct` | Valores fuera de [minimo, maximo]. |
| `no_negativos` | Validez | 1 | `umbral_pct` | Valores negativos donde no corresponden. |
| `dominio` | Validez | 1 | `valores`, `umbral_pct` | Valores fuera de la lista permitida. |
| `tipo_numerico` | Validez | 1 | `umbral_pct` | Valores no convertibles a número. |
| `fecha_valida` | Validez | 1 | `desde`, `hasta`, `umbral_pct` | Fechas no legibles o fuera de [desde, hasta]. |
| `frescura` | Actualidad | 1 | `max_dias` | Días entre la fecha más reciente y la de referencia. |
| `volumen_minimo` | Completitud | ninguna | `min_filas` | La base trae al menos `min_filas` filas. |
| `constante` | Validez | 1 | — | La columna no es constante (más de un valor distinto). |
| `outliers_iqr` | Exactitud | 1 | `k`, `umbral_pct` | Valores fuera de [Q1 − k·IQR, Q3 + k·IQR]. |
| `consistencia` | Consistencia | 2 | `operador`, `umbral_pct` | Relación entre dos columnas (a <= b, a < b, …). |
| `formato` | Validez | 1 | `patron`, `umbral_pct` | Valores que no cumplen la expresión regular. |
| `integridad` | Consistencia | 1 | `ref_dataset`, `ref_columna`, `umbral_pct` | Valores sin correspondencia en otra base (integridad referencial). |
| `suma_control` | Exactitud | 1 | `valor_esperado`, `tolerancia_pct` | La suma de la columna cuadra con un total de control. |
| `completitud_condicional` | Completitud | 2 | `valores`, `umbral_pct` | Si la 1.ª columna tiene valor (o uno de `valores`), la 2.ª no puede estar vacía. |
| `valores_centinela` | Completitud | 1 | `valores`, `umbral_pct` | Valores que disfrazan un nulo (-999, 99999999, 1900-01-01, «N/A»…); sin `valores`, usa la lista habitual. |
| `serie_continua` | Completitud | 1 | `frecuencia`, `excluir`, `umbral_pct` | Periodos que faltan en la serie entre su primera y su última fecha (frecuencia D, B, W, M o Q; `excluir` = feriados). |
| `estabilidad_psi` | Consistencia | 2 | `umbral_psi`, `bins` | Estabilidad de la 1.ª columna entre el primer y el último periodo de la 2.ª (índice PSI; más de 0,25 = cambio relevante). |
| `longitud` | Validez | 1 | `minimo`, `maximo`, `umbral_pct` | Textos cuya longitud (sin espacios extremos) cae fuera de [minimo, maximo] (DNI 8, RUC 11, códigos de N dígitos…). |
| `espacios_extremos` | Validez | 1 | `umbral_pct` | Textos con espacios al inicio o al final, o con espacios dobles. |
| `caracteres_invalidos` | Validez | 1 | `umbral_pct` | Textos con caracteres de control, el carácter de reemplazo «�» o restos de una mala codificación («Ã», «Â»). |
| `categorias_equivalentes` | Consistencia | 1 | `umbral_pct` | Categorías que solo difieren en mayúsculas, tildes o espacios («Pyme», «PYME», «pyme »): filas que no usan la forma principal. |
| `fecha_futura` | Validez | 1 | `umbral_pct` | Fechas posteriores a la fecha de referencia (FECHA_REFERENCIA o hoy). |
| `consistencia_fechas` | Consistencia | 2 | `operador`, `umbral_pct` | Relación entre dos columnas de fecha (inicio <= fin, desembolso <= corte…). |
| `proporcion_ceros` | Completitud | 1 | `umbral_pct` | Proporción de ceros exactos (un cero puede disfrazar un dato faltante). |
| `cardinalidad` | Validez | 1 | `minimo`, `maximo` | Número de valores distintos dentro de [minimo, maximo] (p. ej. 3 a 5 segmentos). |
| `conciliacion_totales` | Exactitud | 1 | `ref_dataset`, `ref_columna`, `tolerancia_pct` | La suma de la columna cuadra con la suma de una columna de otra base (cartera vs contabilidad) dentro de la tolerancia. |
| `conciliacion_conteos` | Completitud | ninguna | `ref_dataset`, `tolerancia_pct` | El número de filas cuadra con el de otra base dentro de la tolerancia. |
| `variacion_temporal` | Consistencia | 2 | `agregacion`, `max_variacion_pct`, `umbral_pct` | Variación entre periodos consecutivos del total (sum, count o mean) de la 1.ª columna por la 2.ª (periodo): saltos mayores que max_variacion_pct. |
| `valores_repetidos` | Actualidad | 2 a 4 | `max_repeticiones`, `umbral_pct` | Valores «rancios»: la 1.ª columna repite el mismo valor más de `max_repeticiones` observaciones seguidas, ordenando por la 2.ª (fecha) y por grupo si hay 3.ª (factor, segmento) y 4.ª (p. ej. cosecha). |
| `saltos_serie` | Exactitud | 2 a 4 | `k`, `umbral_pct`, `agregar` | Saltos entre observaciones consecutivas de la 1.ª columna (orden de la 2.ª, por grupo de la 3.ª y la 4.ª si las hay) de más de `k` desviaciones robustas (mediana y MAD). Con `agregar` = suma, antes se suman las filas de cada grupo y fecha (el saldo total del segmento cuando la base viene por cosecha o cuenta). |
| `monotonia` | Consistencia | 2 o más | `sentido`, `umbral_pct` | En cada fila las columnas siguen el orden dado (creciente: 1.ª ≤ 2.ª ≤ …; p. ej. VaR 95 ≤ VaR 99 ≤ ES). |
| `monotonia_curva` | Consistencia | 2 a 4 | `sentido`, `umbral_pct` | La 1.ª columna es monótona al ordenar por la 2.ª (plazo, tenor «1M/1Y» o fecha) dentro de cada grupo de las siguientes (factor de descuento que baja con el plazo, curva de supervivencia que nunca sube). |
| `relacion_aritmetica` | Exactitud | 3 o más | `operacion`, `tolerancia_pct`, `umbral_pct`, `valor` | La última columna es la suma, resta (1.ª − resto), producto o cociente de las anteriores dentro de la tolerancia (saldo final = inicial − amortización − prepago); con `valor`, la operación de TODAS las columnas da ese valor (estable + volátil = 1). |
| `diferencia_relativa` | Exactitud | 2 | `tolerancia_pct`, `umbral_pct` | Filas donde la 1.ª y la 2.ª columna difieren más de `tolerancia_pct` % (precio del modelo vs independiente, reportado vs recalculado). |
| `categorias_requeridas` | Completitud | 1 | `valores`, `umbral_pct` | Todas las categorías de `valores` aparecen en la columna (los seis escenarios IRRBB, todas las bandas, todas las monedas). |
| `combinaciones_completas` | Completitud | 2 o 3 | `umbral_pct` | Panel completo: están todas las combinaciones de la 1.ª y la 2.ª columna (fecha × factor, escenario × factor), por grupo de la 3.ª. |
| `minimo_por_grupo` | Completitud | 1 o más | `min_filas`, `umbral_pct` | Cada grupo de las columnas tiene al menos `min_filas` filas (ventana mínima por factor, historia mínima por segmento). |
| `suma_por_grupo` | Exactitud | 2 o más | `valor_esperado`, `tolerancia_pct`, `umbral_pct` | La suma de la 1.ª columna en cada grupo de las siguientes es `valor_esperado` (pesos o proporciones que suman 1 por segmento). |
| `conciliacion_por_grupo` | Exactitud | 2 o más | `ref_dataset`, `ref_columna`, `ref_claves`, `tolerancia_pct`, `umbral_pct`, `pareja` | La suma de la 1.ª columna por las claves (resto de columnas) cuadra con la de otra base por sus claves `ref_claves` (por moneda, por fecha, por operación). Con `pareja="base"` solo se exigen los grupos de esta base (p. ej. el corte de las bandas frente a un balance con historia). |
| `signo_por_categoria` | Validez | 2 | `positivos`, `negativos`, `umbral_pct` | La 1.ª columna es ≥ 0 en las categorías `positivos` y ≤ 0 en `negativos` de la 2.ª (activos vs pasivos, entradas vs salidas). |
| `banda_coherente` | Consistencia | 2 | `limites`, `etiquetas`, `umbral_pct` | La banda (2.ª columna) corresponde a los días (1.ª): la banda i va de limites[i] (incluido) a limites[i+1] (excluido). |
| `fechas_habiles` | Validez | 1 | `excluir`, `umbral_pct` | Fechas en fin de semana o en los feriados de `excluir` (series diarias de mercado). |

### Columnas del Excel de resultados (hoja *Controles*)

| Columna | Significado |
|---|---|
| Descripción | Qué se espera (la lee el pipeline como descripción del control). |
| % de incumplimiento | Filas afectadas sobre evaluadas, en %. |
| Resultado | OK, FALLA o No evaluable (lo lee el pipeline). |
| Umbral | % de incumplimiento tolerado con el que se decidió. |
| Detalle observación | Diagnóstico del control (cifras y ejemplos). |
| Control | Identificador: Cxx (propuesto), Xxx (tuyo sin programar), Pxx (programado). |
| Dimensión | Completitud, Unicidad, Validez, Exactitud, Consistencia, Actualidad… |
| Control Esperado | Igual que Descripción (cuadro de 8 columnas del entregable). |
| % De cumplimiento del data set | 100 − % de incumplimiento. |
| Diagnóstico | Igual que Detalle observación (cuadro de 8 columnas). |
| Decisión | Cumple, No cumple o No evaluable. |
| Control o Evidencia requerida | Qué pedir a la primera línea si no cumple. |
| Referencia en el entregable | base.columnas del control. |
| Dataset | Base sobre la que se ejecutó. |
| Columnas | Columnas que usa el control. |
| Tipo | Tipo del catálogo (o personalizado:<función>). |
| N evaluados | Filas (o periodos) evaluados. |
| N afectados | Filas (o periodos) que fallan. |
| Criticidad | ALTA, MEDIA o BAJA. |
| Justificación del control | Qué del perfil lo motivó (o «añadido por el validador»). |
| Origen | reglas, ia, aprendido, validador o personalizado. |
| Definición | JSON con tipo, columnas y parámetros TAL COMO SE EJECUTARON (de aquí aprende el agente). |
| Tipo de modelo | Tipo de modelo de la ficha al que pertenece el control de negocio (var, runoff, irrbb…). |

### Endpoints

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/motores/ia/aprendizaje` | Lo que el agente aprendió del dominio del modelo (o de todos con `todos`). |
| POST | `/api/motores/ia/aprendizaje/decidir` | [Paso 25] Solo un revisor decide; quien enseñó la lección no puede. |
| GET | `/api/motores/ia/estado` | Última propuesta y última revisión de la sesión. |
| GET | `/api/motores/ia/guia` | La guía del notebook de calidad de datos (generada desde el código). |
| POST | `/api/motores/ia/notebook` | Propone los controles (reglas, aprendidos e IA opcional) y genera el notebook. |
| GET | `/api/motores/ia/notebook/{ident}` | Descarga el notebook (.ipynb) de una propuesta. |
| POST | `/api/motores/ia/perfil` | Lo que el agente entendió de lo pegado (sin IA). Para revisar antes de generar. |
| POST | `/api/motores/ia/resultados` | El Excel/CSV que produjo el notebook: el agente revisa las columnas de cumplimiento. [SEG-06] Exige clasificación, como toda evidencia. `aprender` (ex |

### Archivos

| Archivo | Qué contiene |
|---|---|
| `modulos/controles_ia.py` | Perfil, catálogo, reglas, batería, tipo de modelo, IA validada, notebook y revisión. |
| `modulos/aprendizaje_controles.py` | Lecciones por dominio, aprobación, olvido y registro sellado. |
| `inputs/repositorio_controles/<dominio>/` | Controles especializados por tipo de modelo. |
| `web/routers/controles.py` | Endpoints `/api/motores/ia/*`. |
| `tests/test_controles_ia.py`, `tests/test_aprendizaje_controles.py`, `tests/test_controles_bateria_tipo_modelo.py` | Pruebas (coste 0; los notebooks se ejecutan de verdad). |
