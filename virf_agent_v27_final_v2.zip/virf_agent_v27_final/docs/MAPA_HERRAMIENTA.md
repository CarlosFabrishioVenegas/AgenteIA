# Mapa completo de VIRF Agent

> Generado por `scripts/generar_mapa_herramienta.py` desde el código: no se edita a mano. Si la herramienta cambia, `.venv\Scripts\python scripts/generar_mapa_herramienta.py`. Es la fuente para presentaciones, traspasos y soporte; el detalle de uso está en `GUIA_USO.md` y el de cada tipo de modelo en `docs/GUIA_TIPOS_DE_MODELO.md`.

## Índice

1. VIRF en cifras
2. Qué es y cómo se recorre
3. El menú de la web
4. Validación normal y validación completa
5. Las cinco etapas: experto, ruta y entregable
6. Puente a la validación final (08 · 09 · 10)
7. Tipos de modelo
8. Notebook de calidad de datos: capas y catálogo
9. Repositorio de controles por dominio
10. Librería cuantitativa de los notebooks
11. API de la web
12. Mensajes de error de la web
13. Código por capa
14. Línea de comandos (agente.py)
15. Parámetros
16. Scripts
17. Documentación
18. Pruebas (volátil)
19. Historial y trabajo sin commitear (volátil)

## 1. VIRF en cifras

| Qué | Cuántos |
|---|---|
| Opciones del menú de la web | 18 |
| Endpoints (método + ruta) | 136 |
| Mensajes de error distintos que devuelve la web | 189 |
| Archivos en «Entrada y verificadores» | 3 |
| Archivos en «Motor del pipeline» | 5 |
| Archivos en «Módulos de negocio» | 74 |
| Archivos en «Web · routers» | 25 |
| Archivos en «Web · servicios» | 21 |
| Archivos en «Configuración» | 10 |
| Archivos en «RAG léxico» | 17 |
| Archivos en «Skills del agente» | 10 |
| Etapas de la validación completa | 5 |
| Tipos de modelo (fichas de negocio) | 19 |
| Controles de negocio en las fichas (`M`) | 222 |
| Tipos de control del catálogo de calidad de datos | 44 |
| Análisis del repositorio por dominio (`D`) | 45 (alm: 18, lar: 10, shared: 5, var: 12) |
| Funciones de la librería cuantitativa | 43 |
| Opciones de la CLI de `agente.py` | 39 |
| Parámetros de `config/parametros.py` | 87 |
| Scripts | 25 |
| Documentos Markdown | 77 |

## 2. Qué es y cómo se recorre

VIRF es el agente de validación de modelos de riesgo financiero (VaR, ALM, liquidez) de la segunda línea de defensa. Recibe la evidencia de un modelo, la contrasta contra un estándar de validación por ámbitos, conversa con el validador para sustentar cada observación y emite un informe Word. Tiene una web (FastAPI + JavaScript sin framework) y una CLI (`agente.py`); la IA aprobada es Azure OpenAI y el RAG es léxico (BM25 + TF-IDF). En **validación completa**, cinco etapas con notebooks que el validador ejecuta donde están los datos preceden al barrido de controles.

```mermaid
flowchart LR
  p0["Configuración"] --> p1
  p1["Estándares"] --> p2
  p2["Evidencia"] --> p3
  p3["Dominio & RAG"] --> p4
  p4["Skills"] --> p5
  p5["Cuestionamientos"] --> p6
  p6["Pre-vuelo"] --> p7
  p7["Validar modelo"] --> p8
  p8["Revisión con el agente"] --> p9
  p9["Documentar"]
  subgraph completa["Validación completa"]
    c0["Insumos"] --> c1
    c1["Diagnóstico"] --> c2
    c2["Control de datos"] --> c3
    c3["Modelamiento"] --> c4
    c4["Impactos"] --> c5
    c5["Seguimiento"]
  end
  c5 -->|"5 etapas cerradas: su trabajo pasa a la evidencia"| p7
```

## 3. El menú de la web

| Sección | Opción | Qué hace |
|---|---|---|
| Procedimiento | Configuración (`btn-config`) | Ficha del modelo (nombre, **código del inventario**, dominio, tier) y del agente (proveedor de IA aprobado, VIRF PLUS, prueba de conexión). El dominio decide el corpus del RAG y los controles del repositorio. |
| Procedimiento | Estándares (`btn-estandares`) | Sube el `Estandares_VIRF.xlsx` del modelo: el agente evalúa cada actividad como checklist filtrada por Tier. El estándar de la sesión no pisa el global. |
| Procedimiento | Evidencia (`btn-subir`) | Sube la evidencia por carpeta (manuales de modelamiento y seguimiento, implementación —código o ZIP—, calidad de datos…), cada archivo con su **clasificación**. Todo queda en la sesión del modelo. |
| Procedimiento | Dominio & RAG (`btn-dominio-rag`) | Literatura del dominio y **corpus del banco** (estándar, procedimiento, catálogo de controles, reglas del informe) que se consulta en todas las evaluaciones. Índice local BM25 + TF-IDF; al añadir un documento se reconstruye. |
| Procedimiento | Skills (`btn-skills`) | Análisis transversales que el agente aplica al validar (coherencia, supuestos, síntesis…) y criterios propios. No cambian el puntaje: producen hallazgos. |
| Procedimiento | Cuestionamientos (`btn-cuestionamientos`) | Patrones que el agente busca en el CÓDIGO del modelo y criterios extra en lenguaje natural. |
| Procedimiento | Pre-vuelo (`btn-prevuelo`) | Revisión de la evidencia ANTES de gastar (coste 0): qué se podrá leer, PDFs escaneados, formatos omitidos y ámbitos que quedarían sin evidencia. |
| Procedimiento | Validar modelo (`btn-validar`) | Ejecuta el pipeline (`agente.py`) con la evidencia, el estándar y el tier de la sesión. El JSON, el Word y el Markdown quedan en `outputs/` de la SESIÓN y la revisión con el agente empieza sola con ese resultado y su documento. |
| Procedimiento | Revisión con el agente (`btn-chat`) | Conversación por observación: el agente contrasta tu criterio con la evidencia y tú decides. Al final, revisión de la redacción («conforme» o «reescribe N»). Ver §6. |
| Procedimiento | Documentar (`btn-documentar`) | Cuadro de observaciones (Ámbito · Riesgo · Observación · Recomendación · Responsable) e informe Word versionado (V1, V2…), con la tabla de validación final y, en validación completa, el anexo de etapas, hallazgos e imágenes. |
| Validación completa | Insumos (`btn-vc-insumos`) | Validación completa: manuales, Excels de primera línea y scripts (también .zip). El agente los ESTUDIA enteros (una ficha por archivo, en caché) antes de cada notebook. |
| Validación completa | Diagnóstico (`btn-etapa-00`) |  |
| Validación completa | Control de datos (`btn-etapa-01`) |  |
| Validación completa | Modelamiento (`btn-etapa-02`) |  |
| Validación completa | Impactos (`btn-etapa-03`) |  |
| Validación completa | Seguimiento (`btn-etapa-04`) |  |
| Consultas | Resultados (`btn-resultados`) | Corridas de la sesión: puntajes, Excel de resultados, documento Word, comparación entre corridas y firma del validador. |
| Consultas | Controles de datos (`btn-controles`) | Controles de calidad de datos: diseñar con IA desde `.info()`/`.describe()` (notebook local, revisión y aprendizaje), catálogo de motores, resultados de la entidad y notebook entregable del repositorio por dominio. Ver `docs/GUIA_NOTEBOOK_… |

## 4. Validación normal y validación completa

La modalidad es **explícita** en la ficha del modelo (`modalidad`: `normal` o `completa`); nunca se deduce.

| | Normal | Completa |
|---|---|---|
| Antes del barrido | Estándar, evidencia, dominio y pre-vuelo | Lo mismo + insumos y las cinco etapas 00–04 con notebooks iterados |
| Barrido de controles (08) | Se lanza con la evidencia subida | Solo con las cinco etapas cerradas; su trabajo se publica antes en la evidencia por ámbito |
| Calidad de datos | Notebook de «Controles de datos» (opcional: «Usar en la validación») | El Excel del notebook del 01 se puntúa en el ámbito «Calidad de datos» |
| Revisión con el agente (09) | Observaciones del barrido | Lo mismo + los hallazgos de las etapas del ámbito de cada observación |
| Documentar (10) | Informe Word | Informe Word + anexo de etapas, hallazgos e imágenes |

## 5. Las cinco etapas: experto, ruta y entregable

En cada iteración el agente entrega `{etapa}ITERn.ipynb`; el validador lo ejecuta donde están los datos y devuelve `{etapa}_resultadoITERn.xlsx` con comentarios e imágenes. La ruta se verifica contra los títulos «## Paso XX.n» del notebook; sin pasos cubiertos no hay veredicto «lista».

### 00 · Diagnóstico

- **Experto:** Arquitecto de datos de riesgo (BCBS 239): conoce el linaje de cada base del modelo, de qué sistema viene, qué identifica una fila, qué periodo cubre y cómo la controla hoy la primera línea.
- **Misión:** Construye el MAPEO DE LAS BASES DE DATOS del producto: cada base o fuente, qué contiene (granularidad, periodo, llaves, volumen), qué se hace con ella en el proceso y cómo se tiene observada.
- **Tabla que entrega:** Mapeo de bases · usa las etapas previas: —
- **Va a la evidencia de la validación final:** `documentacion/modelamiento/validacion_completa/`

| Paso | Qué | Hoja |
|---|---|---|
| 00.1 Inventario de fuentes | Cada base de RUTAS con su ruta, formato, tamaño, fecha de modificación y si se pudo leer. | Mapeo |
| 00.2 Perfil técnico | Filas, columnas, tipos, nulos, únicos, rangos y estadísticos de cada columna. | perfil_<base> |
| 00.3 Granularidad y llaves | Qué identifica una fila (llave candidata) y si tiene duplicados. | Llaves |
| 00.4 Cobertura temporal | Primera y última fecha, frecuencia observada y periodos faltantes. | Cobertura_temporal |
| 00.5 Relaciones entre bases | Columnas compartidas, cruces de llaves y huérfanos entre bases. | Cruces |
| 00.6 Diccionario de negocio | Qué columna cumple cada concepto del tipo de modelo (P&L, saldo, banda…) y qué falta. | Diccionario |
| 00.7 Controles de la primera línea | Qué controles declara la primera línea por base (manuales, Excels). | Controles_1L |
| 00.8 Brechas y plan para la etapa 01 | Bases o columnas críticas que faltan, periodos incompletos, llaves duplicadas y qué debe controlar la etapa 01. | Brechas |

### 01 · Control de datos

- **Experto:** Especialista en calidad de datos de modelos de riesgo: recorre cada base y cada columna con controles de completitud, unicidad, validez, exactitud, consistencia y actualidad, más los del negocio del tipo de modelo, y busca activamente lo que se le escapó a la primera línea.
- **Misión:** Recorre TODO lo que mapeó el 00_Diagnostico y revisa el control de datos de la primera línea.
- **Tabla que entrega:** Revisión del control · usa las etapas previas: 00
- **Va a la evidencia de la validación final:** `calidad_datos/validacion_completa/`

| Paso | Qué | Hoja |
|---|---|---|
| 01.1 Retomar el mapeo | Bases, llaves y roles que dejó el 00; perfil de cada base. | Mapeo / perfil_<base> |
| 01.2 Batería de calidad (BCBS 239) | Completitud, unicidad, validez, exactitud, consistencia y actualidad sobre todas las columnas. | Controles (C, B, BD) |
| 01.3 Controles del tipo de modelo | Controles de negocio por roles (M) y análisis del repositorio (D). | Controles (M, D) |
| 01.4 Integridad y conciliaciones | Huérfanos entre bases y cuadres de conteos y montos (también contra contabilidad). | Controles |
| 01.5 Contraste con la primera línea | Lo que controló la primera línea, con qué umbral y resultado, contra lo que da la segunda línea. | Contraste_1L |
| 01.6 Tratamientos aplicados | Exclusiones, imputaciones y ajustes de la primera línea y su sustento. | Tratamientos |
| 01.7 Fallas que se escaparon | Lo que no cumple, de lo más grave a lo menos, con N afectados y evidencia. | Fallas |
| 01.8 Porcentaje de cumplimiento y conclusión | Cumplen ÷ evaluados, ponderado por criticidad, y conclusión de la etapa. | Resumen |

### 02 · Modelamiento

- **Experto:** Modelador cuantitativo senior: replica el modelo paso a paso con el manual y el código (población, variables, supuestos, estimación, resultado), compara cada cifra con la del implementador y explica cada diferencia.
- **Misión:** REPLICA EL MODELAMIENTO.
- **Tabla que entrega:** Réplica del modelamiento · usa las etapas previas: 00, 01
- **Va a la evidencia de la validación final:** `documentacion/modelamiento/validacion_completa/`

| Paso | Qué | Hoja |
|---|---|---|
| 02.1 Población y ventana | Bases, periodos y exclusiones del manual con conteos antes y después. | Poblacion |
| 02.2 Variables y transformaciones | Qué columna es cada variable del modelo y cómo se transforma. | Variables |
| 02.3 Supuestos | Nivel de confianza, ventana, horizonte, escala y demás supuestos del manual. | Supuestos |
| 02.4 Estimación y calibración | Re-estimar los parámetros con el mismo método del manual. | Replica |
| 02.5 Resultado replicado vs implementador | La métrica final recalculada frente a la reportada, con su diferencia y materialidad. | Replica |
| 02.6 Sensibilidad y benchmark | Cómo cambia el resultado con otra ventana, nivel o método alternativo. | Sensibilidad |
| 02.7 Implementación | El código del implementador produce lo mismo que la réplica independiente. | Implementacion |
| 02.8 Conclusión y limitaciones | Pasos que difieren, que no se pudieron replicar y qué insumo falta. | Conclusion |

### 03 · Impactos

- **Experto:** Experto en materialidad: toma cada hallazgo abierto de 01 y 02, lo corrige en los datos y mide cuánto cambia la métrica del modelo (VaR, ΔEVE, CPR, LCR…) contra límites y umbrales; clasifica el impacto con un criterio explícito y mira también el efecto conjunto.
- **Misión:** Cuantifica el IMPACTO en el resultado del modelo de lo que se está revisando: por ejemplo, una falla de datos que se le escapó al control de primera línea (01) o una diferencia en la réplica (02).
- **Tabla que entrega:** Impactos · usa las etapas previas: 00, 01, 02
- **Va a la evidencia de la validación final:** `documentacion/modelamiento/validacion_completa/`

| Paso | Qué | Hoja |
|---|---|---|
| 03.1 Hallazgos con impacto potencial | Los hallazgos abiertos de 01 y 02 que pueden mover el resultado. | Hallazgos_origen |
| 03.2 Métrica afectada | Qué métrica del modelo mueve cada hallazgo (VaR, ΔEVE, CPR, LCR…). | Impactos |
| 03.3 Escenario base | La métrica recalculada con los datos tal como están. | Impactos |
| 03.4 Escenario corregido | La métrica sin la falla (o con el dato correcto), hallazgo por hallazgo. | Impactos |
| 03.5 Impacto frente a materialidad | Impacto absoluto y relativo contra umbrales y límites. | Impactos |
| 03.6 Impacto conjunto | Todas las correcciones a la vez (los impactos no se suman). | Impactos |
| 03.7 Nivel y criterio | Potencial/Bajo, Moderado o Crítico con el criterio explícito. | Impactos |

### 04 · Seguimiento

- **Experto:** Experto en monitoreo y backtesting: replica cada indicador del manual de seguimiento con los datos del periodo, lo compara con lo reportado, revisa semáforos, alertas y acciones, y concluye si el modelo sigue vigente.
- **Misión:** REPLICA EL SEGUIMIENTO del modelo: el notebook recalcula cada indicador de monitoreo (estabilidad, discriminación, calibración, backtesting, alertas) con los manuales y archivos de seguimiento, lo compara con el valor reportado por el implementador y registra una hoja «Seguimiento» con: indicador,…
- **Tabla que entrega:** Réplica del seguimiento · usa las etapas previas: 02, 03
- **Va a la evidencia de la validación final:** `documentacion/seguimiento/validacion_completa/`

| Paso | Qué | Hoja |
|---|---|---|
| 04.1 Inventario de indicadores | Indicadores del manual de seguimiento con umbral, frecuencia y semáforo. | Indicadores |
| 04.2 Recalcular indicadores | Cada indicador recalculado con los datos del periodo. | Seguimiento |
| 04.3 Comparar con lo reportado | Valor replicado frente al del implementador. | Seguimiento |
| 04.4 Backtesting | Prueba del modelo contra lo observado (excepciones, CPR observado, salidas reales…). | Backtesting |
| 04.5 Estabilidad | Estabilidad de poblaciones y variables (PSI) y deriva. | Estabilidad |
| 04.6 Semáforo, alertas y acciones | Qué alertas se dispararon, si se escalaron y qué acciones hubo. | Alertas |
| 04.7 Conclusión sobre la vigencia | Si el modelo sigue vigente y qué recomendar. | Conclusion |

## 6. Puente a la validación final (08 · 09 · 10)

`POST /api/validar/lanzar` en un modelo de modalidad completa responde 409 si falta cerrar alguna etapa; con las cinco cerradas llama a `modulos/validacion_completa.py::publicar_en_validacion`, que consolida los hallazgos y copia **solo entregables de VIRF** (nunca los datos enviados a los chats). Cada lanzamiento reemplaza lo publicado. La pantalla del 08 lo enseña antes con `GET /api/completa/paquete`.

| Etapa | Carpeta de evidencia | Excel de resultados |
|---|---|---|
| 00 · Diagnóstico | `documentacion/modelamiento/validacion_completa/` | `documentacion/modelamiento/validacion_completa/00_Diagnostico_resultado.xlsx` |
| 01 · Control de datos | `calidad_datos/validacion_completa/` | `calidad_datos/resultadocalidad_de_datos/completa_01_ControlDatos.xlsx` |
| 02 · Modelamiento | `documentacion/modelamiento/validacion_completa/` | `documentacion/modelamiento/validacion_completa/02_Modelamiento_resultado.xlsx` |
| 03 · Impactos | `documentacion/modelamiento/validacion_completa/` | `documentacion/modelamiento/validacion_completa/03_Impactos_resultado.xlsx` |
| 04 · Seguimiento | `documentacion/seguimiento/validacion_completa/` | `documentacion/seguimiento/validacion_completa/04_Seguimiento_resultado.xlsx` |

Además: `documentacion/modelamiento/validacion_completa/00_LEEME_VALIDACION_COMPLETA.md` (qué es cada archivo) y el consolidado `HALLAZGOS_VALIDACION_COMPLETA.md`. El Excel del 01 lo puntúa el ámbito «Calidad de datos» (`modulos/motores_entidad.py`). En el chat 09, cada observación recibe los hallazgos de las etapas de su ámbito:

| Ámbito | Etapas |
|---|---|
| calidad de datos | 01, 00 |
| metodologia | 02, 03, 04 |
| documentacion | 00, 04 |
| implementacion | 02, 01 |
| gobierno | 00 |
| uso e integracion a la gestion | 00 |

## 7. Tipos de modelo

El tipo se elige **explícito** en la ficha del modelo (`tipos_modelo`). Cada ficha trae bases lógicas con roles de negocio, controles con su porqué, preguntas a la primera línea, pasos de experto por etapa y métricas. Detalle completo: `docs/GUIA_TIPOS_DE_MODELO.md`.

| Familia | Tipo | Bases lógicas | Controles `M` | Análisis del repositorio (`D`) |
|---|---|---|---|---|
| ALM | **Cancelación anticipada y renovación de depósitos a plazo** (`cancelacion_dpf`) | depositos, tasas | 8 | `cancelacion_anticipada` |
| ALM | **Precios de transferencia de fondos (FTP)** (`ftp`) | operaciones, curva_ftp | 4 | — |
| ALM | **ALM · IRRBB: EVE y NII (gap de reprecio)** (`irrbb`) | posiciones, flujos, escenarios, resultados, contabilidad | 26 | `brecha_duracion`, `delta_eve`, `delta_nii`, `escenarios_irrbb_completos`, `gap_reprecios`, `sot_eve_tier1` |
| ALM | **Depósitos sin vencimiento (NMD): núcleo, decaimiento y beta** (`nmd`) | saldos, cuentas, modelo | 16 | `beta_deposito`, `decaimiento_nmd`, `nucleo_topes_bcbs`, `runoff_curvas`, `runoff_supervivencia_saldos`, `supervivencia_km`, `vida_media_nmd` |
| ALM | **Prepago de créditos (modelo conductual de prepago, MCP)** (`prepago`) | saldos, operaciones, modelo | 14 | `backtesting_prepago`, `cpr_prepago`, `smm_cpr_consistencia` |
| ALM | **Run-off: supervivencia y desgaste del saldo (vencimiento conductual)** (`runoff`) | saldos, cuentas, curva, componentes, bandas, contabilidad | 31 | `nucleo_topes_bcbs`, `runoff_curvas`, `runoff_saltos_cosechas`, `runoff_supervivencia_saldos`, `supervivencia_km` |
| ALM | **Supervivencia / retiro de cuentas y saldos (MCR)** (`supervivencia`) | cuentas, curva | 7 | `runoff_curvas`, `supervivencia_km` |
| Liquidez | **Brechas (gaps) de liquidez contractuales y conductuales** (`brechas_liquidez`) | flujos, contabilidad | 7 | `brecha_liquidez_acumulada` |
| Liquidez | **Concentración de fondeo y principales depositantes** (`concentracion_fondeo`) | depositantes | 4 | `concentracion_fondeo` |
| Liquidez | **Liquidity at Risk (LaR, VaR de liquidez)** (`lar`) | flujos, resultado | 5 | `lar_percentil` |
| Liquidez | **Ratio de cobertura de liquidez (RCL / LCR)** (`lcr`) | hqla, salidas, entradas, ratio | 11 | `horizonte_supervivencia`, `hqla_composicion`, `lcr`, `lcr_tope_entradas` |
| Liquidez | **Ratio de financiamiento neto estable (RFNE / NSFR)** (`nsfr`) | asf, rsf, ratio, contabilidad | 7 | `factores_nsfr`, `nsfr` |
| Liquidez | **Estrés de liquidez y horizonte de supervivencia** (`stress_liquidez`) | proyeccion | 4 | `brecha_liquidez_acumulada`, `concentracion_fondeo`, `horizonte_supervivencia`, `hqla_composicion`, `runoff_tasas` |
| Trading | **Riesgo de contraparte (exposición, EAD SA-CCR, CVA)** (`contraparte`) | operaciones, colateral, exposiciones | 7 | — |
| Trading | **Curvas de tasas y superficies de volatilidad (datos de mercado)** (`curvas`) | curvas, volatilidades | 8 | — |
| Trading | **Expected Shortfall / FRTB (modelo interno IMA)** (`es_frtb`) | pyg, es_reportado, observaciones, horizontes | 14 | `alineacion_pnl_var`, `backtesting_excedencias`, `christoffersen`, `kupiec`, `monotonia_niveles_var`, `pla_frtb`, `rfet_modelabilidad`, `semaforo_basilea`, `severidad_excepciones`, `var_negativos` |
| Trading | **Pruebas de estrés de mercado (históricas, hipotéticas e inversas)** (`stress_mercado`) | escenarios, posiciones, resultados | 6 | — |
| Trading | **Valoración de instrumentos y derivados (con verificación independiente de precios)** (`valoracion`) | operaciones, precios | 8 | — |
| Trading | **VaR de mercado (simulación histórica, paramétrico o Monte Carlo)** (`var`) | posiciones, factores, pyg, escenarios_pnl, var_reportado, covarianzas, contabilidad | 35 | `alineacion_pnl_var`, `backtesting_excedencias`, `christoffersen`, `escalado_horizonte`, `kupiec`, `matriz_covarianzas`, `monotonia_niveles_var`, `semaforo_basilea`, `severidad_excepciones`, `var_negativos` |

## 8. Notebook de calidad de datos: capas y catálogo

| Capa (prefijo) | Qué es | Dónde vive |
|---|---|---|
| C · batería general | Reglas por el perfil de cada columna (nulos, fechas, negativos, outliers, duplicados) | `modulos/controles_ia.py` |
| BD · batería dinámica | Columnas sin perfil y llaves compartidas entre bases (huérfanos, duplicados de llave) | `modulos/controles_ia.py` |
| M · tipo de modelo | Controles de negocio de la ficha, por roles (sin columna = «Pendiente») | `modulos/tipos_modelo*.py` |
| D · repositorio del dominio | Análisis especializados en Python, filtrados por `META['tipos']` | `inputs/repositorio_controles/<dominio>/` |
| IA · propuestos | Sugeridos por la IA y validados contra el catálogo y el perfil | `modulos/controles_ia.py` (`proponer`) |
| Aprendidos | Lecciones aprobadas por un revisor (nunca el autor) | `modulos/aprendizaje_controles.py` |
| X / P · del validador | Sin programar o programados en el notebook (`@mi_control`) | el propio notebook |

Catálogo de 44 tipos de control (las funciones viajan dentro del notebook):

| Dimensión | Tipo | Columnas | Qué verifica |
|---|---|---|---|
| Actualidad | `frescura` | 1 | Días entre la fecha más reciente y la de referencia. |
| Actualidad | `valores_repetidos` | 2 a 4 | Valores «rancios»: la 1.ª columna repite el mismo valor más de `max_repeticiones` observaciones seguidas, ordenando por la 2.ª (fecha) y por grupo si hay 3.ª (factor, se… |
| Completitud | `categorias_requeridas` | 1 | Todas las categorías de `valores` aparecen en la columna (los seis escenarios IRRBB, todas las bandas, todas las monedas). |
| Completitud | `combinaciones_completas` | 2 o 3 | Panel completo: están todas las combinaciones de la 1.ª y la 2.ª columna (fecha × factor, escenario × factor), por grupo de la 3.ª. |
| Completitud | `completitud` | 1 o más | Filas con nulos en las columnas (sobre el total). |
| Completitud | `completitud_condicional` | 2 | Si la 1.ª columna tiene valor (o uno de `valores`), la 2.ª no puede estar vacía. |
| Completitud | `conciliacion_conteos` | ninguna | El número de filas cuadra con el de otra base dentro de la tolerancia. |
| Completitud | `minimo_por_grupo` | 1 o más | Cada grupo de las columnas tiene al menos `min_filas` filas (ventana mínima por factor, historia mínima por segmento). |
| Completitud | `proporcion_ceros` | 1 | Proporción de ceros exactos (un cero puede disfrazar un dato faltante). |
| Completitud | `serie_continua` | 1 | Periodos que faltan en la serie entre su primera y su última fecha (frecuencia D, B, W, M o Q; `excluir` = feriados). |
| Completitud | `valores_centinela` | 1 | Valores que disfrazan un nulo (-999, 99999999, 1900-01-01, «N/A»…); sin `valores`, usa la lista habitual. |
| Completitud | `volumen_minimo` | ninguna | La base trae al menos `min_filas` filas. |
| Consistencia | `banda_coherente` | 2 | La banda (2.ª columna) corresponde a los días (1.ª): la banda i va de limites[i] (incluido) a limites[i+1] (excluido). |
| Consistencia | `categorias_equivalentes` | 1 | Categorías que solo difieren en mayúsculas, tildes o espacios («Pyme», «PYME», «pyme »): filas que no usan la forma principal. |
| Consistencia | `consistencia` | 2 | Relación entre dos columnas (a <= b, a < b, …). |
| Consistencia | `consistencia_fechas` | 2 | Relación entre dos columnas de fecha (inicio <= fin, desembolso <= corte…). |
| Consistencia | `estabilidad_psi` | 2 | Estabilidad de la 1.ª columna entre el primer y el último periodo de la 2.ª (índice PSI; más de 0,25 = cambio relevante). |
| Consistencia | `integridad` | 1 | Valores sin correspondencia en otra base (integridad referencial). |
| Consistencia | `monotonia` | 2 o más | En cada fila las columnas siguen el orden dado (creciente: 1.ª ≤ 2.ª ≤ …; p. ej. VaR 95 ≤ VaR 99 ≤ ES). |
| Consistencia | `monotonia_curva` | 2 a 4 | La 1.ª columna es monótona al ordenar por la 2.ª (plazo, tenor «1M/1Y» o fecha) dentro de cada grupo de las siguientes (factor de descuento que baja con el plazo, curva… |
| Consistencia | `variacion_temporal` | 2 | Variación entre periodos consecutivos del total (sum, count o mean) de la 1.ª columna por la 2.ª (periodo): saltos mayores que max_variacion_pct. |
| Exactitud | `conciliacion_por_grupo` | 2 o más | La suma de la 1.ª columna por las claves (resto de columnas) cuadra con la de otra base por sus claves `ref_claves` (por moneda, por fecha, por operación). Con `pareja="… |
| Exactitud | `conciliacion_totales` | 1 | La suma de la columna cuadra con la suma de una columna de otra base (cartera vs contabilidad) dentro de la tolerancia. |
| Exactitud | `diferencia_relativa` | 2 | Filas donde la 1.ª y la 2.ª columna difieren más de `tolerancia_pct` % (precio del modelo vs independiente, reportado vs recalculado). |
| Exactitud | `outliers_iqr` | 1 | Valores fuera de [Q1 − k·IQR, Q3 + k·IQR]. |
| Exactitud | `relacion_aritmetica` | 3 o más | La última columna es la suma, resta (1.ª − resto), producto o cociente de las anteriores dentro de la tolerancia (saldo final = inicial − amortización − prepago); con `v… |
| Exactitud | `saltos_serie` | 2 a 4 | Saltos entre observaciones consecutivas de la 1.ª columna (orden de la 2.ª, por grupo de la 3.ª y la 4.ª si las hay) de más de `k` desviaciones robustas (mediana y MAD).… |
| Exactitud | `suma_control` | 1 | La suma de la columna cuadra con un total de control. |
| Exactitud | `suma_por_grupo` | 2 o más | La suma de la 1.ª columna en cada grupo de las siguientes es `valor_esperado` (pesos o proporciones que suman 1 por segmento). |
| Unicidad | `unicidad` | 1 o más | Filas con la llave (columnas) repetida; sin columnas, filas idénticas. |
| Validez | `caracteres_invalidos` | 1 | Textos con caracteres de control, el carácter de reemplazo «�» o restos de una mala codificación («Ã», «Â»). |
| Validez | `cardinalidad` | 1 | Número de valores distintos dentro de [minimo, maximo] (p. ej. 3 a 5 segmentos). |
| Validez | `constante` | 1 | La columna no es constante (más de un valor distinto). |
| Validez | `dominio` | 1 | Valores fuera de la lista permitida. |
| Validez | `espacios_extremos` | 1 | Textos con espacios al inicio o al final, o con espacios dobles. |
| Validez | `fecha_futura` | 1 | Fechas posteriores a la fecha de referencia (FECHA_REFERENCIA o hoy). |
| Validez | `fecha_valida` | 1 | Fechas no legibles o fuera de [desde, hasta]. |
| Validez | `fechas_habiles` | 1 | Fechas en fin de semana o en los feriados de `excluir` (series diarias de mercado). |
| Validez | `formato` | 1 | Valores que no cumplen la expresión regular. |
| Validez | `longitud` | 1 | Textos cuya longitud (sin espacios extremos) cae fuera de [minimo, maximo] (DNI 8, RUC 11, códigos de N dígitos…). |
| Validez | `no_negativos` | 1 | Valores negativos donde no corresponden. |
| Validez | `rango` | 1 | Valores fuera de [minimo, maximo]. |
| Validez | `signo_por_categoria` | 2 | La 1.ª columna es ≥ 0 en las categorías `positivos` y ≤ 0 en `negativos` de la 2.ª (activos vs pasivos, entradas vs salidas). |
| Validez | `tipo_numerico` | 1 | Valores no convertibles a número. |

## 9. Repositorio de controles por dominio

Cada `.py` define `META` (literal, leído con `ast`) y `control(df, datasets, params)`; entra en el notebook de los tipos que declara en `META['tipos']` (sin `tipos`, en todos los del dominio).

### `alm/` (18)

| Control | Tipos de modelo | Qué verifica |
|---|---|---|
| `backtesting_prepago` | prepago | El CPR modelado debe seguir de cerca al observado: el error absoluto medio (MAE) entre ambos no debe superar la tolerancia. |
| `beta_deposito` | nmd | El beta de traspaso (deposit beta = sensibilidad de la tasa del depósito a la tasa de mercado) debe estar en [0,1] y dentro de la banda esperada del modelo. |
| `brecha_duracion` | irrbb | La brecha de duración (duración del activo − duración del pasivo) debe mantenerse dentro del límite fijado por el ALCO. |
| `cancelacion_anticipada` | cancelacion_dpf | La tasa mensual de cancelación anticipada observada (saldo cancelado antes del vencimiento ÷ saldo vivo) es coherente con la que usa el modelo. |
| `cpr_prepago` | prepago | La tasa de prepago observada (CPR = prepagos / saldo) debe caer dentro de la banda esperada del modelo conductual. |
| `decaimiento_nmd` | nmd | Los depósitos sin vencimiento (NMD) deben mostrar un núcleo estable: la proporción de saldo que permanece (mín/promedio) por encima del umbral 'core'. |
| `delta_eve` | irrbb | La máxima caída del valor económico (ΔEVE) entre los escenarios de shock no debe exceder el 15% del capital de nivel 1 (outlier IRRBB). |
| `delta_nii` | irrbb | La caída del margen financiero (ΔNII) a 12 meses ante el shock de tasa no debe exceder el límite de apetito (% del NII base). |
| `escenarios_irrbb_completos` | irrbb | El análisis IRRBB debe cubrir los seis escenarios supervisores: paralelo ↑/↓, empinamiento, aplanamiento, tasa corta ↑/↓. |
| `gap_reprecios` | irrbb | Ninguna banda de reprecio debe presentar un descalce \|activos − pasivos\| superior al límite sobre el total de activos. |
| `nucleo_topes_bcbs` | nmd, runoff | El núcleo estable de los depósitos sin vencimiento y su vencimiento medio no superan los topes de BCBS 368: minorista transaccional 90 % y 5 años; minorista no transacci… |
| `runoff_curvas` | runoff, supervivencia, nmd | La curva de run-off del modelo es coherente: la supervivencia S(t) empieza en 1 y nunca sube, el run-off acumulado es R(t) = 1 − S(t), el desgaste incremental d(t) = S(t… |
| `runoff_saltos_cosechas` | runoff | Por segmento y edad, el link ratio de cada cosecha (saldo(k) ÷ saldo(k−1)) no se aleja más de k desviaciones robustas (y del desvío mínimo) del de las demás cosechas a e… |
| `runoff_supervivencia_saldos` | runoff, nmd | La curva de supervivencia del modelo se reproduce con la historia: por cosechas, S(k) = Π (Σ saldo(j) ÷ Σ saldo(j−1)) sobre las cosechas observadas en ambos meses, o el… |
| `smm_cpr_consistencia` | prepago | El SMM/CPR reportado es el que sale de los saldos: SMM = prepago ÷ (saldo inicial − amortización programada) y CPR = 1 − (1 − SMM)^12. |
| `sot_eve_tier1` | irrbb | El peor ΔEVE (en valor absoluto) entre los escenarios de shock no debe superar el 15% del capital de Nivel 1 (prueba del valor atípico supervisor). |
| `supervivencia_km` | supervivencia, nmd, runoff | La supervivencia observada de las cuentas (Kaplan–Meier, tratando como censuradas las que siguen abiertas) es coherente con la curva del modelo a 12, 24 y 60 meses, segm… |
| `vida_media_nmd` | nmd | La vida media asumida para los depósitos sin vencimiento (NMD) debe ser positiva y no superar el tope prudencial (típicamente 5 años). |

### `lar/` (10)

| Control | Tipos de modelo | Qué verifica |
|---|---|---|
| `brecha_liquidez_acumulada` | brechas_liquidez, stress_liquidez | La brecha de liquidez acumulada (entradas−salidas, sumada por banda temporal en orden) no debe caer por debajo de cero dentro del horizonte. |
| `concentracion_fondeo` | concentracion_fondeo, stress_liquidez | La financiación no debe depender en exceso de una sola contraparte: la mayor cuota de fondeo por proveedor debe estar por debajo del umbral. |
| `factores_nsfr` | nsfr | Los factores ASF y RSF aplicados son valores de la norma: ASF 0, 50, 90, 95 o 100 %; RSF 0, 5, 10, 15, 50, 65, 85 o 100 %. |
| `horizonte_supervivencia` | stress_liquidez, lcr | La posición de liquidez ACUMULADA (entradas − salidas) no debe caer bajo el colchón en ningún bucket. |
| `hqla_composicion` | lcr, stress_liquidez | Los activos líquidos de Nivel 2 no pueden superar el 40% del HQLA total, y los de Nivel 2B el 15% (tras haircuts). |
| `lar_percentil` | lar | El LaR reportado es el percentil de las salidas netas acumuladas en el horizonte (suma móvil de los flujos netos), con la ventana y el nivel del manual. |
| `lcr` | lcr | El LCR (HQLA / salidas netas de 30 días) debe ser >= 100% en todo periodo reportado. |
| `lcr_tope_entradas` | lcr | El LCR reportado es HQLA ÷ (salidas − mín(entradas; 75 % de las salidas)): las entradas no pueden cubrir más del 75 % de las salidas. |
| `nsfr` | nsfr | El NSFR (fondeo estable disponible / requerido) debe ser >= 100%. |
| `runoff_tasas` | stress_liquidez | La tasa de salida en estrés de cada segmento es al menos el percentil histórico de las caídas de saldo en el horizonte (p. ej. 30 días al 99 %): r_t = 1 − S(t+h) ÷ S(t). |

### `shared/` (5)

| Control | Tipos de modelo | Qué verifica |
|---|---|---|
| `columnas_constantes` | todos | Ninguna columna relevante debería tener un único valor constante en todas las filas (indicio de campo mal poblado o congelado). |
| `completitud_datos` | todos | Ninguna columna del data set debe superar el umbral de valores faltantes (nulos/NaN). |
| `duplicados_registros` | todos | La proporción de registros duplicados (fila completa, o por clave si se indica) debe estar por debajo del umbral. |
| `frescura_datos` | todos | La observación más reciente del data set debe estar dentro de la ventana máxima de antigüedad. |
| `volumen_minimo` | todos | El data set debe tener al menos el número mínimo de observaciones para sostener el análisis (p. ej. ~250 para backtesting). |

### `var/` (12)

| Control | Tipos de modelo | Qué verifica |
|---|---|---|
| `alineacion_pnl_var` | var, es_frtb | La marca de excepción del backtesting compara el P&L de cada día con el VaR del día ANTERIOR (rezago de un día), no con el del mismo día. |
| `backtesting_excedencias` | var, es_frtb | Backtesting por conteo de excedencias: nº de excepciones en la ventana debe caer en zona verde del semáforo de Basilea. |
| `christoffersen` | var, es_frtb | Independencia de las excepciones (Christoffersen): las excepciones no deben agruparse (clustering) en el tiempo. |
| `escalado_horizonte` | var | El VaR a 10 días es coherente con el VaR a 1 día: si se escala por la raíz del tiempo, VaR10 ≈ √10 × VaR1 (3,16 veces) en casi todos los días. |
| `kupiec` | var, es_frtb | Backtesting de VaR (Kupiec POF): la tasa de excepciones debe ser consistente con 1 − nivel de confianza. |
| `matriz_covarianzas` | var | La matriz de correlaciones del VaR paramétrico es simétrica, tiene unos en la diagonal y es semidefinida positiva (ningún autovalor negativo). |
| `monotonia_niveles_var` | var, es_frtb | El VaR debe crecer en magnitud con el nivel de confianza: \|VaR99\| >= \|VaR95\| >= \|VaR90\| en cada fecha. Una inversión delata un error de cómputo. |
| `pla_frtb` | es_frtb | Prueba de atribución de P&L (PLA): el P&L teórico del modelo de riesgo (RTPL) se parece al hipotético (HPL) — Spearman > 0,80 y Kolmogorov–Smirnov < 0,09 (zona verde). |
| `rfet_modelabilidad` | es_frtb | Cada factor de riesgo es modelable (RFET): en los últimos 12 meses tiene ≥ 24 observaciones reales sin ningún periodo de 90 días con menos de 4, o ≥ 100 observaciones. |
| `semaforo_basilea` | var, es_frtb | El nº de excepciones de backtesting en ~250 días debe situar el modelo en zona VERDE de Basilea (0-4); amarilla (5-9) es observación, roja (>=10) es rechazo. |
| `severidad_excepciones` | var, es_frtb | Cuando la pérdida supera el VaR, el exceso medio (pérdida−VaR)/VaR no debería ser grande: excesos severos apuntan a colas mal capturadas. |
| `var_negativos` | var, es_frtb | El VaR estimado debe ser estrictamente positivo (un VaR ≤ 0 es un error de cálculo o de signo). |

## 10. Librería cuantitativa de los notebooks

`modulos/libreria_cuant.py` viaja dentro de los notebooks de las etapas 02–04 (solo pandas y numpy; se valida con `ast.parse`, nunca se ejecuta en el servidor):

`col(base, rol)`, `tabla(base, roles, opcionales)`, `falta(base, roles)`, `comparar(paso, implementador, replicado, tolerancia_pct)`, `comparar_pp(paso, implementador, replicado, tolerancia_pp)`, `mes_indice(s)`, `edad_meses(fecha, cosecha)`, `nivel_impacto(base, corregido)`, `var_historico(pnl, nivel)`, `es_historico(pnl, nivel)`, `var_parametrico(pnl, nivel)`, `excepciones(pnl, var, rezago, convencion)`, `kupiec(x, n, nivel)`, `christoffersen(exc)`, `semaforo(x, n, nivel)`, `pla(hpl, rtpl)`, `psi(a, b)`, `smm_cpr(saldo_inicial, amortizacion, prepago)`, `tasas_runoff(fechas, saldos, horizonte_dias)`, `kaplan_meier(duracion, evento)`, `supervivencia_cosechas(cosecha, edad, saldo)`, `supervivencia_saldo_existente(fecha, cosecha, saldo, plazo_max)`, `curva_runoff(t, S)`, `plazo_economico(t, S)`, `componentes_runoff(t, S, horizonte_meses)`, `limites_banda(etiqueta)`, `asignar_bandas(t, S, etiquetas)`, `curvas_del_modelo(curva)`, `replicar_runoff(saldos, horizonte_meses, curva_de)`, `backtesting_runoff(saldos, curva, meses, curva_de)`, `decaimiento(fechas, saldos)`, `beta_traspaso(tasa_pagada, tasa_mercado)`, `punto_medio_banda(etiqueta)`, `gap_por_banda(montos, bandas, lado)`, `delta_eve_paralelo(gap, choque)`, `delta_nii_paralelo(gap, choque)`, `hqla_ajustado(n1, n2a, n2b)`, `lcr(hqla, salidas, entradas)`, `nsfr(asf_saldos, asf_factores, rsf_saldos, rsf_factores)`, `brechas(entradas, salidas, bandas)`, `lar_hist(fechas, flujo_neto, horizonte, nivel)`, `horizonte_supervivencia(salidas_netas, colchon)`, `concentracion(montos, contrapartes)`

## 11. API de la web

### 08 · Validar

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/validar/cancelar/{run_id}` | `cancelar_validacion` |
| GET | `/api/validar/estado` | `estado_actual` |
| POST | `/api/validar/lanzar` | `lanzar_validacion` |
| GET | `/api/validar/log/{run_id}` | Log completo de una corrida de la sesión (outputs/corridas/<run_id>.log). |

### 09 · Revisión con el agente

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/chat/acta.xlsx` | Acta de cierre en Excel (3 hojas: Resumen · Validación · Decisiones) con el PUNTAJE EXACTO final tras las decisiones del chat. |
| POST | `/api/chat/adjuntar` | El validador sube un archivo con evidencia nueva para la observación en curso. |
| POST | `/api/chat/consolidar` | Cierre HITL: recomputa el PUNTAJE EXACTO final con las decisiones del chat y GUARDA cada corrección como feedback (contexto + ajuste automático en fu… |
| GET | `/api/chat/estado` | `estado_chat` |
| POST | `/api/chat/iniciar` | `iniciar_chat` |
| GET | `/api/chat/observaciones` | Resumen enfocado para dashboards, sin arrastrar todos los mensajes. |
| GET | `/api/chat/revision` | ¿Se revisó con el agente (paso 09) antes de documentar? |

### 10 · Documentar

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/informe/consolidado` | `consolidar` |
| GET | `/api/informe/descargar/{fichero}` | `descargar` |
| GET | `/api/informe/estado` | Panorama para el panel «Documentar Todo». |
| GET | `/api/informe/versiones` | `versiones` |

### Análisis de código

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/codigo/aprobar` | `aprobar` |

### Aprobación de feedback

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/feedback/aprobar` | `aprobar` |
| GET | `/api/feedback/pendientes` | `pendientes` |

### Configuración del modelo y la IA

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/config` | Estado del .env + validador logueado (sin secretos). |
| POST | `/api/config/modelo` | Guarda título (etiqueta visible) y tier del MODELO ACTIVO. |
| POST | `/api/config/verificar` | `verificar_conexion` |
| POST | `/api/config/virf_plus` | Botón VIRF PLUS: suma (o quita) a Claude como segunda opinión del agente principal, que es GPT. |

### Controles de datos

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/motores/catalogo` | Las pruebas genéricas de `modulos.motores_datos.REGISTRO_MOTORES`. |
| GET | `/api/motores/entidad` | Lee las tablas de resultados que la entidad deja bajo `inputs/calidad_datos/resultadocalidad_de_datos/` DE LA SESIÓN activa. |
| GET | `/api/motores/ia/aprendizaje` | Lo que el agente aprendió del dominio del modelo (o de todos con `todos`). |
| POST | `/api/motores/ia/aprendizaje/decidir` | [Paso 25] Solo un revisor decide; quien enseñó la lección no puede. |
| GET | `/api/motores/ia/estado` | Última propuesta y última revisión de la sesión. |
| GET | `/api/motores/ia/guia` | La guía del notebook de calidad de datos (generada desde el código). |
| POST | `/api/motores/ia/notebook` | Propone los controles (reglas, aprendidos e IA opcional) y genera el notebook. |
| GET | `/api/motores/ia/notebook/{ident}` | Descarga el notebook (.ipynb) de una propuesta. |
| POST | `/api/motores/ia/perfil` | Lo que el agente entendió de lo pegado (sin IA). |
| POST | `/api/motores/ia/resultados` | El Excel/CSV que produjo el notebook: el agente revisa las columnas de cumplimiento. |
| GET | `/api/motores/notebook` | Genera y devuelve el .ipynb ENTREGABLE de controles de datos (8 columnas). |

### Cuadro de automatizaciones

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/automatizaciones/cuadro` | `generar` |
| GET | `/api/automatizaciones/descargar/{fichero}` | `descargar` |
| GET | `/api/automatizaciones/estado` | `estado` |

### Cuestionamientos

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/cuestionamientos/default` | Los cuestionamientos del catálogo + su flag `activo` (default True). |
| POST | `/api/cuestionamientos/default/{cid}/toggle` | `toggle_default` |
| GET | `/api/cuestionamientos/personalizados` | `listar_personalizados` |
| POST | `/api/cuestionamientos/personalizados` | `agregar_personalizado` |
| DELETE | `/api/cuestionamientos/personalizados/{cid}` | `borrar_personalizado` |

### Diagnóstico de conexiones

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/debug/conexiones` | `conexiones` |

### Dominio y RAG

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/rag/dominios` | Fijos primero, custom después. |
| POST | `/api/rag/dominios/crear` | `crear_dominio` |
| DELETE | `/api/rag/dominios/{dom_id}` | `borrar_dominio` |
| DELETE | `/api/rag/dominios/{dom_id}/paper/{nombre}` | Elimina un libro/manual CONCRETO del corpus `inputs/rag/{dom_id}/` y reindexa, para que el retrieval deje de devolver ese documento. |
| POST | `/api/rag/reconstruir` | Reconstruye el índice del dominio dado. |

### Entendimiento del modelo

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/entendimiento` | `obtener` |
| POST | `/api/entendimiento/analizar` | Analiza el ZIP descomprimido y genera `entendimiento_modelo_{slug}.md`. |
| POST | `/api/entendimiento/feedback` | `feedback` |

### Entrada y sesión

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/auth/actual` | Validador logueado o 401 (la SPA decide si mostrar el login). |
| GET | `/api/auth/callback` | `completar_login` |
| GET | `/api/auth/login` | `iniciar_login` |
| POST | `/api/auth/login-libre` | Usuario libre para PROBAR la web sin Entra ID (web v2). |
| POST | `/api/auth/logout` | `hacer_logout` |
| GET | `/api/auth/modo` | Qué pantalla de login pinta la SPA. |

### Estándar de validación

| Método | Ruta | Qué hace |
|---|---|---|
| DELETE | `/api/estandares` | `borrar` |
| POST | `/api/estandares/confirmar` | Acepta el estándar: si hay uno pendiente, reemplaza al vigente. |
| GET | `/api/estandares/detalle` | `get_detalle` |
| GET | `/api/estandares/estado` | `get_estado` |
| DELETE | `/api/estandares/pendiente` | Descarta la subida sin aceptar; el estándar vigente sigue igual. |
| POST | `/api/estandares/upload` | Sube el .xlsx como PENDIENTE y devuelve su vista previa. |
| GET | `/api/estandares/vista-previa` | Vista previa del estándar que está en la sesión: el pendiente (recién subido, sin aceptar) o el vigente. |

### Guía de progreso

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/guia/progreso` | `progreso` |

### Modelos y tipos de modelo

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/modelos` | `listar_modelos` |
| POST | `/api/modelos` | `crear_modelo` |
| GET | `/api/modelos/activo` | Modelo actualmente seleccionado (o `None`). |
| POST | `/api/modelos/desactivar` | `desactivar` |
| GET | `/api/modelos/tipos` | Catálogo de tipos de modelo (fichas de negocio); primero los de la familia del dominio. |
| DELETE | `/api/modelos/{slug}` | `borrar_modelo` |
| POST | `/api/modelos/{slug}/activar` | Marca el modelo como activo (cookie); el resto del backend lo usa. |

### Pre-vuelo

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/prevuelo` | Coste 0. |

### Prompts editables

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/prompts` | Los prompts efectivos de la sesión (custom si existen, base si no). |
| GET | `/api/prompts/base` | Los prompts por defecto (para el editor cuando aún no hay sesión). |
| POST | `/api/prompts/editar` | `editar` |
| GET | `/api/prompts/presupuesto` | Presupuesto de contexto para la sesión. |
| POST | `/api/prompts/restaurar` | `restaurar` |

### Páginas

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/` | `index` |

### Resultados

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/resultados/actual` | `resultado_de_la_ultima_corrida` |
| GET | `/api/resultados/documento/{fecha}/{fichero}` | Word que produjo una corrida de «Validar modelo» (en outputs/ de la SESIÓN). |
| GET | `/api/resultados/excel` | Descarga la tabla de validación en Excel. |
| GET | `/api/resultados/lista` | Todos los `resultados_*.json` DE LA SESIÓN activa. |
| GET | `/api/resultados/tabla` | Output intermedio: la tabla de validación por actividad (Ámbito \| Control \| Actividad \| Tier \| Resultado \| Evaluación Sustentada \| Fuente revis… |
| GET | `/api/resultados/tabla/{fecha}/{fichero}` | `tabla_por_ruta` |
| GET | `/api/resultados/{fecha}/{fichero}` | `resultado_por_ruta` |

### Salud

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/salud` | `salud` |

### Skills

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/skills` | Skills DE LA SESIÓN activa: defaults (con flag `activo` según el estado guardado) + custom. |
| POST | `/api/skills/custom` | `crear_custom` |
| DELETE | `/api/skills/custom/{skill_id}` | `borrar_custom` |
| GET | `/api/skills/defaults` | Catálogo por defecto SIN estado (para inspección/documentación). |
| POST | `/api/skills/toggle` | `toggle` |

### Solo Informe

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/solo-informe/adjunto` | Excel, Word, PowerPoint, correo (.msg/.eml) o PDF que se incrusta en el Word con su icono. |
| PUT | `/api/solo-informe/borrador` | `guardar_borrador` |
| GET | `/api/solo-informe/descargar/{nombre}` | `descargar` |
| GET | `/api/solo-informe/estado` | `estado` |
| DELETE | `/api/solo-informe/estandar` | `borrar_estandar` |
| POST | `/api/solo-informe/estandar` | `subir_estandar` |
| POST | `/api/solo-informe/generar` | `generar` |
| POST | `/api/solo-informe/ia/especializar` | Propone la «Descripción de lo realizado» de cada control, adaptada al modelo (con IA y los manuales, o con la plantilla sin IA). |
| GET | `/api/solo-informe/ia/estado` | `ia_estado` |
| POST | `/api/solo-informe/ia/grafico` | `ia_grafico` |
| POST | `/api/solo-informe/ia/manuales` | `ia_manuales` |
| POST | `/api/solo-informe/ia/pulir` | `ia_pulir` |
| POST | `/api/solo-informe/imagen` | `subir_imagen` |
| GET | `/api/solo-informe/imagen/{ident}` | `ver_imagen` |
| GET | `/api/solo-informe/manuales` | `manuales` |
| POST | `/api/solo-informe/manuales` | `subir_manual` |
| DELETE | `/api/solo-informe/manuales/{nombre}` | `borrar_manual` |

### Tiempo real (WebSocket)

| Método | Ruta | Qué hace |
|---|---|---|
| WS | `/ws/chat` | Requiere cookies `virf_token` (login) y `virf_modelo` (modelo activo). |
| WS | `/ws/validar/{run_id}` | Emite el stream de eventos del runner identificado por `run_id`. |

### Validación completa

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/completa/consolidado` | `consolidado` |
| GET | `/api/completa/consolidado/descargar/{fichero}` | `consolidado_descargar` |
| POST | `/api/completa/consolidar` | Lee los entregables de hallazgos de las cinco etapas, los contrasta y escribe el consolidado (Excel + .md + Excel de sustento de cada hallazgo). |
| GET | `/api/completa/estado` | `estado` |
| GET | `/api/completa/etapa/{codigo}` | `ver_etapa` |
| POST | `/api/completa/etapa/{codigo}/cerrar` | El validador da la etapa por cumplida (o la reabre). |
| GET | `/api/completa/etapa/{codigo}/descargar/{fichero}` | Notebook ITERn (.ipynb), revisión (.md) o hallazgos de la etapa (_HALLAZGOS.xlsx/.md). |
| GET | `/api/completa/etapa/{codigo}/imagen/{iteracion}/{fichero}` | Imagen de sustento enviada en la iteración. |
| POST | `/api/completa/etapa/{codigo}/iteracion` | `iterar` |
| GET | `/api/completa/insumos` | Manuales, Excels de primera línea y scripts disponibles, y si ya se estudiaron. |
| DELETE | `/api/completa/insumos/archivo` | Borra un archivo de la carpeta común (no toca la evidencia del paso 03). |
| POST | `/api/completa/insumos/estudiar` | Lee ENTEROS y estudia los insumos pendientes (caché por huella). |
| POST | `/api/completa/insumos/subir` | Sube manuales, Excels de primera línea o scripts a la carpeta COMÚN de los 5 chats. |
| POST | `/api/completa/modalidad` | `cambiar_modalidad` |
| GET | `/api/completa/paquete` | Lo que la validación completa lleva al barrido de controles (08), sin escribir nada. |

### cuestionamientos-sesion

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/cuestionamientos-sesion` | `get_estado` |
| POST | `/api/cuestionamientos-sesion/custom` | `crear_custom` |
| DELETE | `/api/cuestionamientos-sesion/custom/{cid}` | `borrar_custom` |
| POST | `/api/cuestionamientos-sesion/toggle` | `toggle` |

### inputs

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/inputs/arbol` | Árbol de `inputs/` DE LA SESIÓN activa. |
| DELETE | `/api/inputs/archivo/{slug}/{fichero}` | Borra un fichero SUBIDO desde este panel. |
| GET | `/api/inputs/carpeta/{slug}` | Ficheros ya subidos a `slug` — para pintar cada card del upload guiado. |
| GET | `/api/inputs/destinos` | Slugs válidos con etiqueta y alcance (sesion\|global). |
| POST | `/api/inputs/upload` | `subir_archivos` |
| POST | `/api/inputs/upload-zip` | Descomprime un ZIP en `destino`. |

### validacion

| Método | Ruta | Qué hace |
|---|---|---|
| POST | `/api/validacion/preview-prompt` | `preview_prompt` |

## 12. Mensajes de error de la web

Extraídos de cada `HTTPException` de `web/routers/` y `web/services/` (`{…}` = parte variable). Para saber qué hacer con cada uno: `docs/GUIA_ERRORES_Y_SOPORTE.md`.

Por código: **400** 97, **401** 8, **403** 11, **404** 42, **409** 9, **413** 3, **422** 1, **500** 6, **502** 6, **503** 5, **504** 1.

<details><summary><code>web/routers/auth.py</code> (10)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `completar_login` | login caducado o state desconocido; vuelve a entrar |
| 401 | `completar_login` | login rechazado: {…} |
| 401 | `validador_actual` | no autenticado |
| 403 | `completar_login` | {…} |
| 403 | `login_libre` | {…} |
| 422 | `login_libre` | {…} |
| 503 | `completar_login` | {…} |
| 503 | `iniciar_login` | {…} |
| 503 | `login_libre` | el usuario libre no está activo (VIRF_IDENTIDAD_PROVEEDOR≠libre) |
| 503 | `login_libre` | {…} |

</details>

<details><summary><code>web/routers/automatizaciones.py</code> (5)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `descargar` | fuera del directorio de salida |
| 400 | `descargar` | nombre inválido: {…} |
| 404 | `descargar` | no existe: {…} |
| 404 | `generar` | {…} |
| 502 | `generar` | No se pudo generar el cuadro: {…} |

</details>

<details><summary><code>web/routers/chat.py</code> (15)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `adjuntar_chat` | archivo demasiado grande (máx 20 MB) |
| 400 | `adjuntar_chat` | archivo vacío |
| 400 | `adjuntar_chat` | no se pudo extraer texto del archivo (¿escaneado o formato no soportado?). Formatos con texto: pdf, docx, pptx, xlsx, csv, md, txt, py, ipynb, json. |
| 400 | `adjuntar_chat` | nombre de archivo inválido |
| 400 | `consolidar_chat` | ruta de resultados fuera de la sesión |
| 400 | `descargar_acta_cierre` | ruta de resultados fuera de la sesión |
| 400 | `iniciar_chat` | el informe {…} no tiene el formato esperado: {…}: {…} |
| 400 | `iniciar_chat` | ruta debe ser 'YYYY-MM-DD/fichero.json' |
| 400 | `iniciar_chat` | ruta fuera de outputs de la sesión |
| 404 | `consolidar_chat` | no existe el JSON de resultados: {…} |
| 404 | `consolidar_chat` | no hay sesión de chat activa |
| 404 | `descargar_acta_cierre` | no existe el JSON de resultados: {…} |
| 404 | `descargar_acta_cierre` | no hay sesión de chat activa |
| 404 | `iniciar_chat` | no existe: {…} |
| 404 | `observaciones` | no hay sesión de chat activa |

</details>

<details><summary><code>web/routers/codigo.py</code> (1)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `aprobar` | {…} |

</details>

<details><summary><code>web/routers/config.py</code> (5)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `set_modelo` | {…} |
| 401 | `_validador_o_401` | sesión de login expirada; vuelve a entrar |
| 404 | `set_modelo` | el modelo activo ya no existe en disco |
| 409 | `set_modelo` | no hay un modelo activo; entra a un modelo antes de guardar |
| 409 | `set_virf_plus` | VIRF PLUS bloqueado hasta aprobación del proveedor: {…} |

</details>

<details><summary><code>web/routers/controles.py</code> (20)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `_perfiles` | la base «{…}» está repetida |
| 400 | `ia_aprendizaje_decidir` | {…} |
| 400 | `ia_notebook` | no se pudo proponer ningún control con ese perfil |
| 400 | `ia_notebook` | no se reconoció ninguna columna: pega la salida completa de df.info() de cada base (y df.describe(include='all')). |
| 400 | `ia_notebook` | {…} |
| 400 | `ia_notebook_descarga` | identificador no válido |
| 400 | `ia_resultados` | archivo vacío o de más de 20 MB |
| 400 | `ia_resultados` | este Excel salió del MODO_DEMO (datos sintéticos): se puede revisar, pero no se usa en la validación ni en el aprendizaje. Ejecuta el notebook con MODO_DEMO = False sobre tus bases. |
| 400 | `ia_resultados` | no se pudo leer el cuadro: {…} |
| 400 | `ia_resultados` | sube el .xlsx (o .csv) que generó el notebook |
| 400 | `ia_resultados` | {…} |
| 403 | `ia_aprendizaje_decidir` | {…} |
| 403 | `ia_resultados` | {…} |
| 404 | `ia_aprendizaje_decidir` | {…} |
| 404 | `ia_guia` | falta la guía: python scripts/generar_guia_calidad_datos.py |
| 404 | `ia_notebook_descarga` | no existe ese notebook |
| 500 | `descargar_notebook_controles` | no se pudo generar el notebook de controles: {…} |
| 500 | `resultados_de_la_entidad` | lector motores_entidad falló: {…} |
| 502 | `ia_notebook` | la IA no pudo proponer controles: {…} |
| 502 | `ia_resultados` | la IA no pudo revisar el cuadro: {…} |

</details>

<details><summary><code>web/routers/cuestionamientos.py</code> (4)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 404 | `borrar_personalizado` | no existe personalizado con id={…} |
| 404 | `toggle_default` | cuestionamiento default desconocido: {…} |
| 409 | `agregar_personalizado` | id={…} choca con uno del catálogo por defecto |
| 409 | `agregar_personalizado` | ya existe un cuestionamiento con id={…} |

</details>

<details><summary><code>web/routers/cuestionamientos_sesion.py</code> (3)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `crear_custom` | {…} |
| 400 | `toggle` | {…} |
| 404 | `borrar_custom` | custom {…} no existe |

</details>

<details><summary><code>web/routers/entendimiento.py</code> (2)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `feedback` | {…} |
| 404 | `obtener` | aún no se ha analizado el código; usa POST /api/entendimiento/analizar |

</details>

<details><summary><code>web/routers/estandares.py</code> (6)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `confirmar` | Excel inválido: {…} |
| 400 | `upload` | Excel inválido: {…} |
| 400 | `upload` | el fichero está vacío |
| 400 | `upload` | solo se acepta .xlsx o .xlsm |
| 404 | `get_detalle` | no hay estándares confirmados en esta sesión |
| 500 | `get_detalle` | no se pudo leer el JSON: {…} |

</details>

<details><summary><code>web/routers/feedback_aprobacion.py</code> (2)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 403 | `aprobar` | {…} |
| 404 | `aprobar` | {…} |

</details>

<details><summary><code>web/routers/informe.py</code> (6)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `consolidar` | ruta debe ser 'YYYY-MM-DD/fichero.json' |
| 400 | `consolidar` | ruta fuera de outputs de la sesión |
| 400 | `descargar` | fuera del directorio de salida |
| 400 | `descargar` | nombre inválido: {…} |
| 404 | `consolidar` | no existe: {…} |
| 404 | `descargar` | no existe: {…} |

</details>

<details><summary><code>web/routers/modelos.py</code> (4)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `crear_modelo` | {…} |
| 401 | `_validador_logueado_o_401` | sesión de login expirada; vuelve a entrar |
| 404 | `activar_modelo` | modelo {…} no existe |
| 404 | `borrar_modelo` | modelo {…} no existe |

</details>

<details><summary><code>web/routers/preview_prompt.py</code> (1)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 500 | `preview_prompt` | no se pudo armar el prompt: {…} |

</details>

<details><summary><code>web/routers/prompts.py</code> (4)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `editar` | {…} |
| 403 | `editar` | {…} |
| 404 | `editar` | {…} |
| 404 | `restaurar` | {…} |

</details>

<details><summary><code>web/routers/rag.py</code> (11)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `borrar_dominio` | '{…}' es un dominio fijo; no se borra |
| 400 | `borrar_paper` | nombre inválido: {…} |
| 400 | `borrar_paper` | ruta fuera del dominio |
| 400 | `crear_dominio` | {…} |
| 400 | `reconstruir` | dominio '{…}' no existe |
| 401 | `_login_o_401` | sesión de login expirada; vuelve a entrar |
| 404 | `borrar_dominio` | {…} |
| 404 | `borrar_paper` | dominio '{…}' no existe |
| 404 | `borrar_paper` | no existe: {…} |
| 409 | `borrar_dominio` | no se puede eliminar '{…}': lo usan {…} modelo(s): {…}{…} |
| 504 | `_ejecutar_rebuild` | reconstrucción excedió 5 min; abortada |

</details>

<details><summary><code>web/routers/resultados.py</code> (13)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `_resolver` | fecha inválida: {…} |
| 400 | `_resolver` | nombre inválido: {…} |
| 400 | `_resolver` | ruta fuera de outputs de la sesión: {…} |
| 400 | `descargar_excel` | ruta debe ser 'YYYY-MM-DD/fichero.json' |
| 400 | `documento_de_la_corrida` | ruta de documento no válida |
| 400 | `documento_de_la_corrida` | ruta fuera de outputs de la sesión |
| 400 | `resultado_de_la_ultima_corrida` | resultado fuera de outputs de la sesión |
| 400 | `tabla_de_la_ultima_corrida` | resultado fuera de outputs de la sesión |
| 404 | `_resolver` | no existe: {…}/{…} |
| 404 | `documento_de_la_corrida` | no existe: {…}/{…} |
| 404 | `resultado_de_la_ultima_corrida` | no hay resultado disponible de una corrida |
| 404 | `tabla_de_la_ultima_corrida` | no hay resultado disponible de una corrida |
| 500 | `_leer_json` | JSON corrupto en {…}: {…} |

</details>

<details><summary><code>web/routers/skills.py</code> (3)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `crear_custom` | {…} |
| 400 | `toggle` | {…} |
| 404 | `borrar_custom` | custom {…} no existe |

</details>

<details><summary><code>web/routers/solo_informe.py</code> (20)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `_ia` | {…} |
| 400 | `descargar` | nombre de fichero no válido |
| 400 | `generar` | sube primero el Estandar_VIRF.xlsx |
| 400 | `generar` | {…} |
| 400 | `ia_especializar` | elige el Tier del modelo antes de especializar |
| 400 | `ia_especializar` | sube primero el Estandar_VIRF.xlsx |
| 400 | `ia_manuales` | elige la actividad relacionada antes de buscar en los manuales |
| 400 | `subir_adjunto` | {…} |
| 400 | `subir_estandar` | Excel inválido: {…} |
| 400 | `subir_estandar` | el fichero está vacío |
| 400 | `subir_estandar` | solo se acepta .xlsx |
| 400 | `subir_imagen` | {…} |
| 400 | `subir_manual` | {…} |
| 401 | `base_solo_informe` | sesión de login expirada; vuelve a entrar |
| 403 | `subir_adjunto` | {…} |
| 404 | `borrar_manual` | manual no encontrado |
| 404 | `descargar` | informe no encontrado |
| 404 | `ver_imagen` | imagen no encontrada |
| 502 | `_ia` | {…} |
| 503 | `_ia` | {…} |

</details>

<details><summary><code>web/routers/upload.py</code> (22)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `_clasificacion_o_error` | {…} |
| 400 | `_nombre_seguro` | nombre de archivo inválido |
| 400 | `borrar_archivo` | nombre inválido: {…} |
| 400 | `borrar_archivo` | ruta fuera del destino |
| 400 | `subir_archivos` | '{…}' es un ZIP; usa /api/inputs/upload-zip |
| 400 | `subir_archivos` | '{…}' solo acepta un .zip; usa /api/inputs/upload-zip |
| 400 | `subir_archivos` | '{…}': formato no admitido en {…} (admitidos: {…}) |
| 400 | `subir_archivos` | una fuente del corpus RAG necesita dueño y vigencia (2135.010.02 §Carga de fuentes) |
| 400 | `subir_archivos` | {…} |
| 400 | `subir_zip` | ZIP vacío |
| 400 | `subir_zip` | archivo no es un ZIP válido |
| 400 | `subir_zip` | el ZIP contiene un nombre con byte nulo |
| 400 | `subir_zip` | el corpus RAG no admite ZIP: sube cada fuente con su dueño y vigencia (Paso 11) |
| 400 | `subir_zip` | entrada escapa del destino: {…} |
| 400 | `subir_zip` | entrada peligrosa en el ZIP: {…} |
| 403 | `_clasificacion_o_error` | {…} |
| 403 | `_nombre_seguro` | '{…}' no puede subirse por esta vía (cambio con proceso, no por upload) |
| 403 | `subir_zip` | el ZIP contiene un archivo prohibido: {…} |
| 404 | `borrar_archivo` | no existe: {…} |
| 413 | `subir_zip` | el ZIP descomprimido ocuparía {…} MiB; máximo {…} MiB |
| 413 | `subir_zip` | el ZIP supera el tamaño descomprimido máximo ({…} MiB) |
| 413 | `subir_zip` | el ZIP tiene {…} archivos; máximo {…} |

</details>

<details><summary><code>web/routers/validacion.py</code> (6)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `log_corrida` | run_id inválido |
| 404 | `cancelar_validacion` | run {…} no está activo |
| 404 | `log_corrida` | no hay log para esa corrida en esta sesión |
| 409 | `lanzar_validacion` | Este modelo no tiene evidencia: no hay ningún documento en «03 · Evidencia». Sube los manuales (documentación), el código (implementación, en .zip) y los datos o resultados de calidad de datos, y vuelve a lanzar. |
| 409 | `lanzar_validacion` | Validación completa: antes del barrido de controles cierra las etapas {…}. La validación se lanza con TODO lo de las cinco etapas (hallazgos, réplicas, impactos, seguimiento y los controles de datos del 01); si una etap… |
| 409 | `lanzar_validacion` | {…} |

</details>

<details><summary><code>web/routers/validacion_completa.py</code> (20)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `_servir` | fuera del directorio de la etapa |
| 400 | `_servir` | tipo no servible: {…} |
| 400 | `borrar_insumo` | {…} |
| 400 | `cambiar_modalidad` | {…} |
| 400 | `cerrar` | {…} |
| 400 | `consolidado_descargar` | nombre inválido: {…} |
| 400 | `descargar` | nombre inválido: {…} |
| 400 | `imagen` | nombre inválido: {…} |
| 400 | `iterar` | {…} |
| 400 | `iterar` | {…}: {…} |
| 400 | `subir_insumos` | no llegó ningún archivo con contenido |
| 400 | `subir_insumos` | {…} |
| 404 | `_codigo_valido` | etapa desconocida: {…} |
| 404 | `_servir` | no existe: {…} |
| 404 | `borrar_insumo` | no existe: {…} |
| 404 | `cambiar_modalidad` | el modelo ya no existe |
| 409 | `iterar` | Este modelo está en Validación normal. Cámbialo a Validación completa para usar las etapas 00–04. |
| 500 | `consolidar` | no se pudo consolidar: {…} |
| 502 | `estudiar_insumos` | No se pudo estudiar los insumos: {…} |
| 502 | `iterar` | No se pudo completar la iteración: {…} |

</details>

<details><summary><code>web/services/contexto_sesion.py</code> (4)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 400 | `contexto_sesion` | modelo {…} no existe |
| 400 | `contexto_sesion` | no hay modelo activo; entra en un modelo desde 'Mis Modelos'. |
| 400 | `resolver_destino` | destino desconocido: {…} |
| 401 | `contexto_sesion` | sesión de login expirada; vuelve a entrar |

</details>

<details><summary><code>web/services/roles.py</code> (2)</summary>

| Código | Función | Mensaje |
|---|---|---|
| 401 | `comprobar` | sesión expirada; vuelve a entrar con tu cuenta corporativa |
| 403 | `comprobar` | tu rol no permite «{…}» (requiere: {…}) |

</details>

## 13. Código por capa

### Entrada y verificadores (3)

La CLI del pipeline y los verificadores del proyecto.

| Archivo | Qué hace |
|---|---|
| `agente.py` | Punto de entrada del agente VIRF |
| `validate_project.py` | Verificación de integridad del proyecto VIRF |
| `verificador_virf.py` | Verificador de Indicadores del VIRF Agent (WP-00). |

### Motor del pipeline (5)

Carga de rutas, lectura de evidencias, prompt por ámbito, llamada a la IA y controles de datos.

| Archivo | Qué hace |
|---|---|
| `motor/Mx_00_CargaRutas.py` | Configuración central del Motor VIRF. |
| `motor/Mx_01_LecturaEvidencias.py` | — |
| `motor/Mx_02_EstructuraPrompt.py` | Construcción de todos los prompts que se envían al modelo de IA activo. |
| `motor/Mx_03_LlamarIA.py` | Capa de comunicación con la API del proveedor de IA activo. |
| `motor/Mx_04_MotorControlesData.py` | Motor de controles de calidad automatizados sobre datos. |

### Módulos de negocio (74)

Validación completa, notebooks, controles, tipos de modelo, informe, salvaguardas, custodia.

| Archivo | Qué hace |
|---|---|
| `modulos/abstencion.py` | Compuerta de abstención activa (WP-01, indicador D3). |
| `modulos/adjuntos_ole.py` | Archivos adjuntos INCRUSTADOS en un Word (python-docx). |
| `modulos/aislamiento.py` | Aislamiento multi-tenant por (tenant, modelo) — WP-02 reducido, indicador D2. |
| `modulos/almacenamiento.py` | modulos/almacenamiento.py [SEG-06] |
| `modulos/analisis_estatico.py` | QUÉ HACE EL CÓDIGO, LEÍDO DEL CÓDIGO — sin ejecutarlo y sin preguntarle al LLM. |
| `modulos/aprendizaje_controles.py` | APRENDIZAJE DE LOS CONTROLES DE CALIDAD DE DATOS (2026-11-24) |
| `modulos/aprobacion_codigo.py` | modulos/aprobacion_codigo.py [SEG-07] |
| `modulos/auditoria.py` | modulos/auditoria.py [SEG-12] |
| `modulos/automatizaciones.py` | Cuadro de observaciones a partir de los Excels de AUTOMATIZACIÓN del producto. |
| `modulos/capturas.py` | Capturas de evidencia para los informes Word («pantallazos»), sin IA. |
| `modulos/chunker.py` | chunker.py [v20] |
| `modulos/chunker_estructural.py` | Chunking ESTRUCTURAL por secciones (WP · GAP-29, guía de errores/loops RAG). |
| `modulos/clasificacion_docx.py` | modulos/clasificacion_docx.py [SEG-10] |
| `modulos/comparador.py` | COMPARACIÓN ENTRE CORRIDAS — qué cambió desde la revisión anterior. |
| `modulos/consola.py` | consola.py [v27.2] |
| `modulos/consolidacion.py` | Cierre HITL: convierte las decisiones del chat en el PUNTAJE EXACTO final. |
| `modulos/control_evaluacion_data.py` | ESTRUCTURAS Y UTILIDADES PARA CONTROL DE EVALUACIÓN DE DATOS |
| `modulos/controles_a_notebook.py` | Documento de controles de datos → Notebook + Brechas |
| `modulos/controles_ia.py` | CONTROLES DE DATOS ASISTIDOS POR IA a partir de `.info()` y `.describe()`. |
| `modulos/cuestionamientos_ext.py` | Catálogo extensible de cuestionamientos metodológicos. |
| `modulos/custodia.py` | CADENA DE CUSTODIA — trazabilidad inmutable de los informes de validación. |
| `modulos/document_cache.py` | Sistema de memoria de documentos para modo pre-producción (MODO_PREPRDC). |
| `modulos/entailment.py` | Verificación SEMÁNTICA de citas (entailment / NLI): ¿el fragmento citado IMPLICA |
| `modulos/esquemas.py` | Contrato de salida TIPADO del validador (WP-09 · GAP-43/GAP-14/GAP-03). |
| `modulos/estudio_insumos.py` | ESTUDIO DE LOS INSUMOS de la Validación completa. |
| `modulos/evaluacion_experta.py` | modulos/evaluacion_experta.py [Paso 65] |
| `modulos/excel_a_notebook.py` | INGENIERÍA INVERSA EXCEL → NOTEBOOK PYTHON |
| `modulos/explicador_modelo.py` | explicador_modelo.py [v27.2] |
| `modulos/exportador_excel.py` | Exporta la tabla de validación a Excel (.xlsx) con las 8 columnas acordadas: |
| `modulos/feedback.py` | Gestión de feedback del validador sobre las evaluaciones del agente. |
| `modulos/feedback_mejorado.py` | Sistema de feedback mejorado que REAPRENDE del usuario: |
| `modulos/fuentes_rag.py` | modulos/fuentes_rag.py [Paso 11 · norma 2135.010.02 §Carga de fuentes] |
| `modulos/fusibles.py` | Cortacircuitos para bucles de razonamiento y ejecución (WP-05, indicador D6). |
| `modulos/generador_estadistica_feedback.py` | Genera un informe Excel de precisión del agente basado en el historial de feedback. |
| `modulos/generador_markdown.py` | Informe de validación en Markdown: el BORRADOR DE TRABAJO del validador. |
| `modulos/generador_word.py` | Genera VIRF_Informe_*.docx — Informe de validación en formato PLANO y legible |
| `modulos/graficos_estructurados.py` | Figuras ESTRUCTURADAS que acompañan a una observación del informe. |
| `modulos/hallazgos_completa.py` | HALLAZGOS DE LA VALIDACIÓN COMPLETA (2026-11-24): un Excel y un .md por etapa, |
| `modulos/huella_informe.py` | PRIMITIVAS DE HUELLA DE UN INFORME — hash canónico y normalización de nombres. |
| `modulos/huella_prompts.py` | TRAZABILIDAD DEL PROMPT — qué se le preguntó exactamente al modelo. |
| `modulos/instrucciones_sesion.py` | Lectura de instrucciones extra (skills + cuestionamientos NL) que la |
| `modulos/inyeccion.py` | Defensa contra INYECCIÓN DE INSTRUCCIONES en la evidencia del modelo validado. |
| `modulos/libreria_cuant.py` | LIBRERÍA CUANTITATIVA que viaja DENTRO de los notebooks de la validación |
| `modulos/motor_ia.py` | Orquestador principal del agente VIRF. |
| `modulos/motor_ia_v2.py` | Orquestador principal del pipeline VIRF por CONTROL. |
| `modulos/motores_datos.py` | Catálogo de pruebas de calidad de datos |
| `modulos/motores_entidad.py` | Lectura de los resultados de los motores de calidad de datos DE LA ENTIDAD. |
| `modulos/notebook_controles.py` | Genera un .ipynb ENTREGABLE de controles de calidad de datos cuyo output es la |
| `modulos/observabilidad.py` | modulos/observabilidad.py [Pasos 54 · 56 · 57] |
| `modulos/override_humano.py` | REPORTE DE HUMAN OVERRIDE — dónde el validador corrigió al agente. |
| `modulos/perfilador_datasets.py` | PERFILADO DE DATASETS — el esquema como evidencia, no los datos. |
| `modulos/pickle_firmado.py` | modulos/pickle_firmado.py [SEG-09 · tratamiento de SAST B301] |
| `modulos/pii.py` | Enmascarado DETERMINISTA de datos personales (PII) en la evidencia, ANTES de que |
| `modulos/plantilla_bcp.py` | Plantilla común de los informes Word de VIRF (estética «Informe de Resultados»). |
| `modulos/plantillas_etapa.py` | RUTA PASO A PASO y NOTEBOOKS PLANTILLA de la validación completa. |
| `modulos/prevuelo.py` | PRE-VUELO DE LA EVIDENCIA — qué se va a poder leer, antes de gastar. |
| `modulos/registro_emisiones.py` | REGISTRO APPEND-ONLY DE EMISIONES — control PREVENTIVO de la cadena de custodia. |
| `modulos/reglas_informe.py` | Reglas puras de calificación de los informes VIRF: conclusión global y estado |
| `modulos/reporte_docx.py` | Reporte `.docx` estructurado desde un ValidationReport (WP-08 estructura · |
| `modulos/repositorio_controles.py` | REPOSITORIO de controles de datos ESCRITOS COMO FUNCIONES PYTHON, organizados |
| `modulos/revision_codigo.py` | REVISIÓN DEL CÓDIGO CONTRA LA DOCUMENTACIÓN — una llamada por módulo. |
| `modulos/salida_ia.py` | Saneado de lo que sale hacia la IA (SEG-05). Módulo HOJA: solo depende de |
| `modulos/salvaguardas_llm.py` | modulos/salvaguardas_llm.py [SEG-16] |
| `modulos/tipos_modelo.py` | CONOCIMIENTO DE NEGOCIO POR TIPO DE MODELO. |
| `modulos/tipos_modelo_alm.py` | fichas de negocio de la familia ALM (riesgo de |
| `modulos/tipos_modelo_liquidez.py` | fichas de negocio de la familia LIQUIDEZ. |
| `modulos/tipos_modelo_trading.py` | fichas de negocio de la familia TRADING |
| `modulos/validacion_completa.py` | VALIDACIÓN COMPLETA: cinco chats especializados (uno por etapa) en los que el |
| `modulos/validador_citas.py` | Validador DETERMINISTA de citas con id de linaje (WP-03/WP-04 · indicador D4). |
| `modulos/validador_humano.py` | FIRMA Y RESPONSABILIDAD DEL VALIDADOR HUMANO — segregación de funciones. |
| `modulos/ventana_contexto.py` | Resolución de la ventana de contexto real del modelo (WP-10 · GAP-40). |
| `modulos/verificacion_cifras.py` | avisos deterministas sobre lo que afirma el modelo. |
| `modulos/versionado.py` | Versionado temporal de chunks/estándares (WP-10 · GAP-23). |
| `modulos/word_estilo.py` | Infraestructura de presentación del informe Word. Reutilizable: aquí vive el |

### Web · routers (25)

Endpoints FastAPI (validan la entrada y devuelven JSON o archivos).

| Archivo | Qué hace |
|---|---|
| `web/routers/auth.py` | Autenticación SSO con Microsoft Entra ID (SEG-02). |
| `web/routers/automatizaciones.py` | Cuadro de observaciones desde los Excels de automatización (00–03). |
| `web/routers/chat.py` | Chat argumentativo por sesión (v2 · fase 7). |
| `web/routers/codigo.py` | Aprobación humana de código generado por IA (SEG-07). |
| `web/routers/config.py` | Configuración del proveedor IA (v2 · fase 2). |
| `web/routers/controles.py` | Controles de calidad de datos (v2 · fase 2). |
| `web/routers/cuestionamientos.py` | Cuestionamientos metodológicos — paso 9/10. |
| `web/routers/cuestionamientos_sesion.py` | Cuestionamientos POR SESIÓN — endpoints (v2 · fase 6). |
| `web/routers/debug_conexiones.py` | Endpoint HTTP para el verificador de conexiones (Mejora 5 · v2.2). |
| `web/routers/dominio_prevuelo.py` | Pre-vuelo sobre la EVIDENCIA de la sesión activa (v2 · fase 2). |
| `web/routers/entendimiento.py` | Endpoints del mapa de entendimiento del modelo (Mejora 4 · v2.2). |
| `web/routers/estandares.py` | Router del paso 02 · Estándares (v2.4). |
| `web/routers/feedback_aprobacion.py` | Aprobación del feedback antes de que afecte a los puntajes (Paso 25). |
| `web/routers/guia.py` | Guía del procedimiento: en qué paso está el expediente. |
| `web/routers/informe.py` | Informe consolidado por sesión (v2 · fase 8). |
| `web/routers/modelos.py` | Modelos del validador logueado + selección del modelo activo (v2 · fase 1). |
| `web/routers/preview_prompt.py` | Visor del prompt del agente, protegido con contraseña (Mejora 2 · v2.2). |
| `web/routers/prompts.py` | Endpoints CRUD de prompts editables por sesión (v2.3). |
| `web/routers/rag.py` | Dominio & RAG: papers al RAG global + reconstrucción + dominios custom. |
| `web/routers/resultados.py` | Lectura de resultados de validación (v2 · fase 2). |
| `web/routers/skills.py` | Endpoints de Skills — capacidades del agente por sesión (v2 · fase 5). |
| `web/routers/solo_informe.py` | Router del apartado «Solo Informe»: genera el Informe de Resultados sin pipeline. |
| `web/routers/upload.py` | Endpoints de subida de evidencia y visualización del árbol de inputs. |
| `web/routers/validacion.py` | Endpoints REST + WebSocket del pipeline de validación (v2 · fase 2). |
| `web/routers/validacion_completa.py` | VALIDACIÓN COMPLETA: chat por etapa (00–04) sobre las automatizaciones. |

### Web · servicios (21)

Sesiones, chat, informe, pipeline, roles, prompts, Solo Informe.

| Archivo | Qué hace |
|---|---|
| `web/services/analisis_codigo.py` | Análisis estructural del ZIP de implementación (Mejora 4 · v2.2). |
| `web/services/auditoria_web.py` | Middleware de auditoría de acciones web (SEG-12). |
| `web/services/chat_service.py` | Chat argumentativo por sesión — v2 · fase 7. |
| `web/services/contexto_sesion.py` | Resolución del contexto de sesión (v2 · fase 2). |
| `web/services/cuestionamientos_sesion.py` | Cuestionamientos POR SESIÓN (v2 · fase 6). |
| `web/services/dominios_custom_store.py` | Dominios RAG personalizados (Mejora 1 · v2.2). |
| `web/services/env_service.py` | Lectura (SOLO lectura) del `.env` del proyecto. |
| `web/services/estandares_service.py` | Estándares de validación por sesión (v2.4). |
| `web/services/evidencia_sesion.py` | Búsqueda LOCAL (BM25, sin IA ni red) en la evidencia del modelo de la sesión: |
| `web/services/informe_web.py` | Generador de informe consolidado por sesión («Generar informe» de la web). |
| `web/services/modelos_store.py` | Modelos por validador — cada uno con su carpeta y su `sesion.json`. |
| `web/services/pipeline_runner.py` | Ejecuta `agente.py --prdc` como subproceso para UNA sesión (v2 · fase 2). |
| `web/services/presupuesto_service.py` | Presupuesto de contexto dinámico por modelo detectado (v2.3). |
| `web/services/prompt_service.py` | Prompts editables por sesión (v2.3). |
| `web/services/roles.py` | Roles y permisos de la web (SEG-08). |
| `web/services/sesion_store.py` | Sesiones de login ligadas a la IDENTIDAD CORPORATIVA (SEG-02). |
| `web/services/skills_store.py` | Skills por sesión (v2 · fase 5). |
| `web/services/solo_informe_ia.py` | Asistencia con IA del apartado «Solo Informe» (opcional). |
| `web/services/solo_informe_reglas.py` | Compatibilidad: las reglas de calificación viven en `modulos.reglas_informe` |
| `web/services/solo_informe_service.py` | Apartado «Solo Informe»: compone el informe de resultados SIN ejecutar el pipeline. |
| `web/services/solo_informe_word.py` | Word del apartado «Solo Informe» (Informe de Resultados). |

### Configuración (10)

Parámetros, proveedores de IA, rutas, identidad, red y dominio.

| Archivo | Qué hace |
|---|---|
| `config/dominio.py` | config/dominio.py [v27.2] |
| `config/ia.py` | config/ia.py [v27.2] |
| `config/identidad.py` | config/identidad.py [SEG-02] |
| `config/modelos.py` | CATÁLOGO DE MODELOS — parámetros óptimos por modelo, no por proveedor. |
| `config/parametros.py` | config/parametros.py [v27.2] |
| `config/red.py` | Capa de RED: proxy, inspección TLS y reintento ante cuota agotada. |
| `config/rutas.py` | config/rutas.py [v27.2] |
| `config/secretos.py` | config/secretos.py [SEG-03] |
| `config/tools.py` | config/tools.py [Paso 15 · Paso 49] |
| `config/virf_plus.py` | VIRF PLUS — el agente principal (GPT) suma a Claude como segunda opinión. |

### RAG léxico (17)

BM25 + TF-IDF por dominio, sin embeddings.

| Archivo | Qué hace |
|---|---|
| `src/rag/base_indexer.py` | Clase base para indexadores de todos los dominios RAG. |
| `src/rag/base_retriever.py` | Clase base para retrievers de todos los dominios RAG. |
| `src/rag/buscador_lexico.py` | Consulta el índice léxico de un dominio y devuelve los top-K chunks. |
| `src/rag/config_rag.py` | Parámetros del RAG LÉXICO (BM25 + TF-IDF). Sin embeddings, sin HuggingFace. |
| `src/rag/custom_retriever.py` | Retriever + indexer para dominios RAG PERSONALIZADOS (Mejora 1 · v2.2). |
| `src/rag/indexador_lexico.py` | Construye y persiste el índice LÉXICO (BM25 + TF-IDF) de un dominio RAG. |
| `src/rag/tesauro.py` | Tesauro de dominio: los sinónimos que la búsqueda léxica no puede adivinar. |
| `src/rag/ALM/indexer.py` | Indexador RAG para el dominio ALM (modelos conductuales: prepago, retiro de |
| `src/rag/ALM/retriever.py` | Retriever RAG para el dominio ALM (modelos conductuales: prepago, supervivencia/ |
| `src/rag/banco/indexer.py` | Indexador del corpus del BANCO (`inputs/rag/banco/`). Hereda de BaseIndexer. |
| `src/rag/banco/retriever.py` | Retriever del corpus del BANCO (`inputs/rag/banco/`): el criterio de la |
| `src/rag/LaR/indexer.py` | Indexador RAG para modelos de Liquidity at Risk (LaR). |
| `src/rag/LaR/retriever.py` | Retriever RAG para modelos de Liquidity at Risk (LaR). |
| `src/rag/shared/indexer.py` | Indexador RAG de conocimiento regulatorio compartido (transversal a todos los dominios). |
| `src/rag/shared/retriever.py` | Retriever de conocimiento regulatorio compartido. |
| `src/rag/VaR/indexer.py` | Indexador RAG para modelos de Value at Risk (VaR). |
| `src/rag/VaR/retriever.py` | Retriever RAG para modelos de Value at Risk (VaR). |

### Skills del agente (10)

Capacidades tipadas del pipeline.

| Archivo | Qué hace |
|---|---|
| `skills/base_tipada.py` | Contrato base tipado de una skill (function calling) |
| `skills/calidad_datos.py` | Skill 2 (Calidad de Datos), determinista, en sandbox |
| `skills/cola_pendiente.py` | Cola PENDIENTE (Human-in-the-loop) |
| `skills/documentacion.py` | Skill 1 (Documentación / Auditoría Documental) |
| `skills/gobierno.py` | Skill 4 (Gobierno / Compliance & Risk Tiering) |
| `skills/implementacion.py` | Skill 5 (Implementación / Auditoría de Código) |
| `skills/metodologia.py` | Skill 3 (Metodología / RAG Metodológico) |
| `skills/uso.py` | Skill 6 (Uso / Análisis de Canales Operativos) |
| `modulos/skills/base.py` | Infraestructura común de las skills de validación. |
| `modulos/skills/catalogo.py` | Las ocho skills de validación. |

## 14. Línea de comandos (agente.py)

| Opción | Qué hace |
|---|---|
| `--titulo` | Nombre del modelo |
| `--tier` | Tier del modelo (1, 2, 3, 4) |
| `--excel` | Ruta al Excel de controles (para pipeline Calidad de Datos) |
| `--control` | Usar pipeline por CONTROL (Calidad de Datos) |
| `--prdc` | Modo producción (genera Word) |
| `--estadisticafeedback` | Ver estadísticas de feedback |
| `--limpiar-cache` | Limpiar caché de documentos y salir |
| `--cache-stats` | Ver estadísticas del caché de documentos |
| `--no-cache` | Deshabilitar caché para esta corrida |
| `--convertir-excel` | FASE 1: Ruta a carpeta con .xlsx/.xlsm. Genera .ipynb por libro con VBA, refs externas y auto-validación contra Excel. NO copia al pipeline principal — tú decides qué mover a inputs/implementacion/. |
| `--cuadro-automatizaciones` | Carpeta con los Excels de automatización del producto (00_Diagnostico, 01_ControlDatos, 02_Modelamiento, 03_Impactos opcional). Genera el cuadro de observaciones (Ámbito · Riesgo · Observación · Reco… |
| `--sin-ia` | Con --cuadro-automatizaciones: borrador determinista, sin llamadas a la IA. |
| `--virf-plus` | Activa VIRF PLUS en esta corrida: suma a Claude como segunda opinión del agente GPT; ambos evalúan por separado y GPT concilia la conclusión (equivale a VIRF_PLUS=1). |
| `--controles-a-notebook` | Ruta a un DOCUMENTO (.docx/.pdf/.md) que describe controles de calidad de datos. Genera un .ipynb ejecutable y un análisis de brechas contra --excel. |
| `--datasets` | Carpeta con los datasets (.csv/.parquet/.xlsx) para los controles de motor de datos. Default: inputs/calidad_datos/datasets/ |
| `--listar-motores` | Muestra el catálogo de pruebas de calidad de datos disponibles y sale |
| `--dominio-rag` | Corpus RAG a consultar: LaR \| VaR \| conductuales \| shared. DECLÁRALO: sin este flag el dominio se INFIERE del título, y la inferencia es una heurística que puede enrutar al corpus equivocado (un m… |
| `--skills` | Análisis transversales tras la evaluación. 'all' \| 'rapidas' \| lista separada por comas (ej. coherencia,supuestos,sintesis). NO alteran el score: producen hallazgos, no puntajes. Ver --listar-skills |
| `--listar-skills` | Muestra el catálogo de skills de validación disponibles y sale |
| `--explicar-modelo` | Genera outputs/<fecha>/explicacion_del_modelo_<NOMBRE>.md consolidando las 4 fuentes de inputs/ (metodología, seguimiento, implementación, calidad de datos) |
| `--dry-run` | Para --explicar-modelo: muestra el inventario de evidencia y el coste estimado SIN llamar al modelo |
| `--excluir` | Para --explicar-modelo: nombres de fichero a omitir (p. ej. fixtures de prueba que viven en inputs/) |
| `--solo-coincidentes` | Para --explicar-modelo: usar SOLO los ficheros cuyo nombre contiene el modelo. Úsalo cuando varios modelos comparten las carpetas de inputs/; por defecto se incluye toda la evidencia para no descarta… |
| `--raiz-evidencia` | Raíz alternativa que contiene inputs/ (default: la del proyecto). UN MODELO POR RAÍZ: evita que la evidencia de varios modelos se mezcle y que el informe de uno cite documentos de otro. El estándar V… |
| `--estandares` | Ruta a un Estandares_VIRF.xlsx alternativo (default: el global del proyecto). Introducido por la web v2.4 para que cada validador aplique su propio catálogo de actividades por sesión, sin sobrescribi… |
| `--salida` | Carpeta raíz de SALIDA (la que contiene <fecha>/ con el JSON, el Word y el Markdown de la corrida). Por defecto, outputs/ del proyecto. La web la fija en la carpeta outputs/ de la SESIÓN del modelo:… |
| `--codigo-modelo` | Código del modelo en el inventario de modelos (p. ej. MR-VAR-014). Se guarda en el JSON de resultados y sale en la portada y la ficha del informe Word |
| `--sin-llm` | Para --convertir-excel: no usa LLM (solo estructura + fórmulas sin traducir) |
| `--sin-validacion` | Para --convertir-excel: omite la auto-validación notebook vs Excel |
| `--revisar-codigo` | Revisa el código de inputs/implementacion/ (recursivo, .py e .ipynb) contra el manual metodológico: UNA llamada por módulo, hallazgos con fichero:línea. Sus hallazgos se fusionan en el ámbito Impleme… |
| `--analizar-codigo` | Análisis ESTÁTICO del código de inputs/implementacion/ (.py e .ipynb): extrae por AST los hechos duros —funciones, valores por defecto, ventanas, métodos, aleatoriedad— y los contrasta contra los man… |
| `--perfilar-datasets` | Añade a la evidencia un perfil del ESQUEMA de los datasets (columnas, tipos, nulos, rangos, duplicados). No vuelca ninguna fila de datos. Permite contrastar las variables reales contra las que declar… |
| `--prevuelo` | Revisa la evidencia ANTES de gastar y sale: qué se podrá leer, qué PDFs están escaneados, qué formatos se omiten sin aviso y qué ámbitos quedarán sin evidencia (puntúan 0.0). Coste 0, no llama al mod… |
| `--verificar-cadena` | Verifica la integridad de la cadena de custodia de todos los informes de un modelo y sale |
| `--verificar-evidencia` | Comprueba si los documentos citados por un informe siguen intactos y sale |
| `--verificar-emisiones` | Contrasta el registro append-only de emisiones (audit_logs/registro_emisiones.jsonl) contra los informes presentes en outputs/ y sale. Detecta informes emitidos que YA NO ESTÁN — que --verificar-cade… |
| `--historial-validaciones` | Lista, por validador, qué modelos ha aprobado y cuándo |
| `--comparar` | Compara las dos últimas corridas del modelo y sale: score por ámbito, actividades que subieron o bajaron, documentos que cambiaron, y si cambió la VARA DE MEDIR (estándar, modelo de IA, versión del a… |
| `--verificar-conexion-azure` | Prueba de humo del proveedor activo: confirma credenciales, detecta el modelo real del deployment, muestra el perfil de chunking que se aplicará y valida que el parser entiende su JSON |

## 15. Parámetros

Se declaran en `config/parametros.py` (+ `__all__`, `config/__init__.py` y `.env.example`); nunca se lee el entorno en otro sitio. Detalle de criterio: `GUIA_TRASPASO_CONTEXTO.md` §15.

| Constante | Variable | Por defecto | Qué controla |
|---|---|---|---|
| `IA_PROVEEDOR` | `IA_PROVEEDOR` | azure_openai | [POLÍTICA DE PROVEEDOR] Azure OpenAI es el proveedor PRIORITARIO por decisión de la entidad. El DEFAULT vive aquí, en el código, y NO en el .env: si mañana alg… |
| `MODO` | `MODO` | produccion | [SEG-13] El default en código es PRODUCCIÓN: un despliegue que olvida MODO no queda en modo laxo. Para desarrollo local se declara MODO=debug. |
| `AGENTE_VERSION` | `VIRF_AGENTE_VERSION` | 27.1 | Viaja al JSON de auditoría: debe reflejar la versión REAL del evaluador. Se mantiene en 27.1 deliberadamente — subirla es una decisión del proyecto, no un efec… |
| `TIMEOUT_SEGUNDOS` | `TIMEOUT_SEGUNDOS` | 30 | — |
| `REINTENTOS_API` | `REINTENTOS_API` | 3 | — |
| `MAX_CHARS_DOC` | `MAX_CHARS_DOC` | 15000 | — |
| `MAX_CHARS_CODIGO` | `MAX_CHARS_CODIGO` | 8000 | — |
| `MAX_FILAS_EXCEL` | `MAX_FILAS_EXCEL` | 200 | — |
| `MAX_CTX` | `VIRF_MAX_CTX` | MAX_CHARS_DOC | Contexto máximo que se le pasa al modelo por llamada. [UNIFICACIÓN v27.2] agente.py usaba default MAX_CHARS_DOC y chunker.py el literal "15000". Coincidían por… |
| `MAX_DOCS_AMBITO` | `VIRF_MAX_DOCS_AMBITO` | 0 | 0 = sin límite de documentos por ámbito. `minimo=0` es deliberado: 0 es un valor VÁLIDO aquí, no un error de configuración. |
| `ANTHROPIC_MODELO` | `ANTHROPIC_MODELO` | claude-sonnet-4-6 | — |
| `ANTHROPIC_MAX_TOKENS` | `ANTHROPIC_MAX_TOKENS` | 4096 | — |
| `VALIDAR_CONEXION` | `VIRF_VALIDAR_CONEXION` | 0 | Gasta 1 request de prueba al arrancar. Desactivado por defecto: un fallo de credenciales se manifiesta igual en la primera llamada real. |
| `AZURE_API_VERSION` | `AZURE_OPENAI_API_VERSION` | 2024-10-21 | GA estable. Una versión 'preview' puede cambiar de comportamiento sin aviso, y este sistema exige corridas reproducibles (METODOLOGIA_DEL_AGENTE.md §11.5): dos… |
| `AZURE_MAX_TOKENS` | `AZURE_OPENAI_MAX_TOKENS` | 4096 | — |
| `OPENAI_MODELO` | `OPENAI_MODELO` | gpt-4.1 | OpenAI directo (api.openai.com), con una sola API key. Lo usa VIRF PLUS como la voz «GPT» cuando la entidad no tiene un deployment de Azure. |
| `OPENAI_MAX_TOKENS` | `OPENAI_MAX_TOKENS` | 4096 | — |
| `VIRF_PLUS_GPT` | `VIRF_PLUS_GPT` | IA_PROVEEDOR if IA_PROVEEDOR in ('openai', 'azure_openai') else 'azure_openai | VIRF PLUS: GPT (agente principal) + Claude como segunda opinión Se ENCIENDE solo con VIRF_PLUS=1 (botón «VIRF PLUS» de la web o .env). No se deduce de qué clav… |
| `VIRF_PLUS_ARBITRO` | `VIRF_PLUS_ARBITRO` | gpt | — |
| `VIRF_PLUS_ARBITRAJE` | `VIRF_PLUS_ARBITRAJE` | siempre | — |
| `CUADRO_RESP_MODELAMIENTO` | `VIRF_RESP_MODELAMIENTO` | Equipo de Modelamiento (desarrollador del modelo) | Cuadro de observaciones de las automatizaciones (Excels 00–03) Responsable según DÓNDE cae la observación: si se corrige en el desarrollo del modelo (modelamie… |
| `CUADRO_RESP_SEGUIMIENTO` | `VIRF_RESP_SEGUIMIENTO` | Equipo de Seguimiento de Modelos | — |
| `CUADRO_PLAZO_CRITICO` | `VIRF_PLAZO_CRITICO` | 30 | Días de plazo para levantar la observación, según su riesgo. |
| `CUADRO_PLAZO_MODERADO` | `VIRF_PLAZO_MODERADO` | 90 | — |
| `CUADRO_PLAZO_BAJO` | `VIRF_PLAZO_BAJO` | 180 | — |
| `IMPACTO_UMBRAL_MODERADO` | `VIRF_IMPACTO_UMBRAL_MODERADO` | 0.05 | Umbrales para un impacto NUMÉRICO de 03_Impactos (en fracción: 0.05 = 5%). Un valor > 1 en el Excel se interpreta como porcentaje (7 → 7%). |
| `IMPACTO_UMBRAL_CRITICO` | `VIRF_IMPACTO_UMBRAL_CRITICO` | 0.1 | — |
| `CHUNK_SIZE` | `VIRF_CHUNK_SIZE` | 12000 | Tamaño INICIAL del segmento. El modo adaptativo puede subirlo hasta CHUNK_SIZE_MAX, así que no es el tamaño real en documentos grandes. |
| `CHUNK_OVERLAP` | `VIRF_CHUNK_OVERLAP` | 800 | — |
| `CHUNK_THRESHOLD` | `VIRF_CHUNK_THRESHOLD` | CHUNK_SIZE | — |
| `MAX_CHUNKS` | `VIRF_MAX_CHUNKS` | 40 | [COSTE-FIX D2] 40 en vez de 60: medido sobre un PDF real de 305 páginas, 40 segmentos cuestan $1,14 y 60 cuestan $1,45, con idéntica cobertura (100%). ⚠️ NO ba… |
| `CHUNK_SIZE_MAX` | `VIRF_CHUNK_SIZE_MAX` | 40000 | Techo del segmento adaptativo. Subirlo permite bajar MAX_CHUNKS sin penalizar. |
| `MAX_NIVELES` | `VIRF_MAX_NIVELES` | 3 | Tope de niveles de consolidación jerárquica (evita bucle si el modelo no comprime lo suficiente). |
| `PRESUPUESTO_DOC` | `VIRF_PRESUPUESTO_DOC` | int(MAX_CTX * 0.6) | Presupuesto de chars que los resúmenes de UN documento pueden ocupar en el prompt de evaluación. Fracción de MAX_CTX para que un ámbito con varios documentos l… |
| `CHUNK_ENABLED` | `VIRF_CHUNK_ENABLED` | 1 | — |
| `MAX_CTX_SKILLS` | `VIRF_MAX_CTX_SKILLS` | MAX_CTX * 4 | [AUDIT-FIX] Presupuesto propio para las SKILLS Las skills leen TODA la evidencia de una vez —su pregunta es transversal al modelo, no a un control—, mientras q… |
| `RAG_TOP_K_SKILLS` | `VIRF_RAG_TOP_K_SKILLS` | 8 | Fragmentos RAG para el bloque regulatorio de las skills. Más que en una actividad (RAG_TOP_K) porque aquí la consulta es una sola para todo el análisis, no una… |
| `INTENTOS_CONTRATO` | `VIRF_INTENTOS_CONTRATO` | 2 | [AUDIT-FIX] Reintento ante respuesta que no cumple el contrato Intentos TOTALES para obtener una evaluación con el formato pactado. 2 = el original más un rein… |
| `MAX_ITER` | `VIRF_MAX_ITER` | 3 | [WP-05 · Cortacircuitos / fusibles] Fusibles para bucles de razonamiento y ejecución de skills. Evitan que un bucle agéntico o un reintento se disparen sin tec… |
| `FUSIBLE_SEG` | `VIRF_FUSIBLE_SEG` | 10 | — |
| `FUSIBLE_TOKENS` | `VIRF_FUSIBLE_TOKENS` | 20000 | — |
| `ABSTENCION_BETA` | `VIRF_ABSTENCION_BETA` | 0.19 | [WP-01 · Abstención activa (β)] Umbral de score léxico por debajo del cual la evidencia recuperada se declara INSUFICIENTE y el agente se ABSTIENE en lugar de… |
| `CACHE_ENABLED` | `CACHE_ENABLED` | 1 | — |
| `CACHE_LOCK_TIMEOUT` | `VIRF_CACHE_LOCK_TIMEOUT` | 10 | — |
| `CACHE_LOCK_STALE` | `VIRF_CACHE_LOCK_STALE` | 60 | — |
| `EXCEL_MAX_CELDAS_MUESTRA` | `EXCEL_MAX_CELDAS_MUESTRA` | 500 | — |
| `EXCEL_MAX_FORMULAS_HOJA` | `EXCEL_MAX_FORMULAS_HOJA` | 2000 | — |
| `EXCEL_CHUNK_HOJA_UMBRAL` | `EXCEL_CHUNK_HOJA_UMBRAL` | 80 | — |
| `EXCEL_VALIDACION_TOL` | `EXCEL_VALIDACION_TOL` | 1e-06 | — |
| `EXCEL_NB_TIMEOUT` | `EXCEL_NB_TIMEOUT` | 120 | — |
| `DEBUG_PROMPTS` | `DEBUG_PROMPTS` | 0 | — |
| `MIN_FEEDBACK_ANTISESGO` | `VIRF_MIN_FEEDBACK_ANTISESGO` | 15 | Masa crítica exigida antes de dejar que el feedback histórico altere el criterio del agente (D6-FIX). Gobierna el bloque de calibración del prompt. |
| `MIN_MUESTRAS_AJUSTE` | `VIRF_MIN_MUESTRAS_AJUSTE` | MIN_FEEDBACK_ANTISESGO | [AUDIT-FIX] Umbral del ajuste numérico POST-HOC del puntaje. Había dos guardias anti-sesgo descoordinadas y solo una era visible: · bloque del prompt → MIN_FEE… |
| `PROHIBIR_MODELOS_EXTERNOS` | `VIRF_PROHIBIR_MODELOS_EXTERNOS` | 1 | Guardia de política. Ya no gobierna ninguna rama de código —no queda ninguna— pero se conserva porque `validate_project.py` y los tests la usan para verificar… |
| `PII_MASKING` | `VIRF_PII_MASKING` | 1 | Enmascarado de PII en la evidencia Antes de que un extracto de documento salga hacia el proveedor de generación, se sustituyen los datos personales que pueda c… |
| `ENTAILMENT_ACTIVO` | `VIRF_ENTAILMENT` | MODO == 'produccion | Verificación semántica de citas (entailment / NLI) Cierra el salto «la cita EXISTE» → «la cita SOSTIENE la afirmación»: un juez LLM decide si el fragmento cita… |
| `ANTIINYECCION_ACTIVO` | `VIRF_ANTIINYECCION` | 1 | Defensa anti-inyección de instrucciones en la evidencia Neutraliza tramos de la evidencia que parecen instrucciones dirigidas al evaluador («ignora las instruc… |
| `CA_BUNDLE` | `VIRF_CA_BUNDLE` | — | RED CORPORATIVA — proxy e inspección TLS El SDK de OpenAI usa `httpx`, y httpx verifica los certificados contra el bundle de **certifi**, NO contra el almacén… |
| `TLS_ALMACEN_SISTEMA` | `VIRF_TLS_ALMACEN_SISTEMA` | 0 | Alternativa a exportar el PEM: verificar contra el almacén de certificados del sistema operativo (en Windows, el mismo que usa el navegador) con `truststore`.… |
| `HTTP_TIMEOUT` | `VIRF_HTTP_TIMEOUT` | 120 | Timeout de la petición HTTP. Un proxy corporativo añade latencia, y el default del SDK puede quedarse corto con prompts grandes. |
| `TLS_INSECURE` | `VIRF_TLS_INSECURE` | 0 | ⚠️ SALIDA DE EMERGENCIA — SOLO PARA DIAGNÓSTICO Desactiva la verificación TLS. Sirve para responder en 10 segundos a «¿es el certificado o es otra cosa?», que… |
| `RAG_TOP_K` | `RAG_TOP_K` | 6 | RAG [AUDIT-FIX] `.env.example` documentaba RAG_TOP_K=3 y RAG_MIN_SCORE=0.35 desde hacía tiempo, pero NADIE las leía: los valores vivían hardcodeados como defau… |
| `RAG_MIN_COBERTURA` | `RAG_MIN_COBERTURA` | 0.15 | ABSOLUTO. Fracción del peso informativo (Σ IDF) de la consulta que el fragmento cubre realmente. Comparable entre consultas: un 0.20 significa lo mismo aquí qu… |
| `RAG_MIN_SCORE` | `RAG_MIN_SCORE` | 0.35 | RELATIVO. Recorta la cola de la lista ya ordenada: «quédate con lo que esté al menos al X% de lo mejor de ESTA consulta». Se conserva con su nombre y su defaul… |
| `RAG_PESO_INFORMATIVO_MINIMO` | `RAG_PESO_INFORMATIVO_MINIMO` | 0.8 | Peso informativo mínimo (Σ IDF) para considerar que una CONSULTA discrimina algo contra el corpus. No filtra: AVISA. Es la pieza que faltaba. Medido en el índi… |
| `RAG_INDICE_DIR` | `RAG_INDICE_DIR` | — | Dónde se persisten los índices. Carpeta DISTINTA de VECTORDB_DIR a propósito: aquella contiene bases ChromaDB con vectores que ya no significan nada, y mezclar… |
| `RAG_PESO_BM25` | `RAG_PESO_BM25` | 0.7 | Combinación de las dos señales. BM25 manda porque premia la coincidencia EXACTA de terminología (Kupiec, HQLA, NSFR, IFRS 9), que es lo que discrimina en liter… |
| `RAG_PESO_TFIDF` | `RAG_PESO_TFIDF` | 0.3 | — |
| `RAG_BM25_K1` | `RAG_BM25_K1` | 1.5 | Parámetros canónicos de BM25 (Robertson; los mismos que trae Elasticsearch). |
| `RAG_BM25_B` | `RAG_BM25_B` | 0.75 | — |
| `RAG_TFIDF_NGRAM_MAX` | `RAG_TFIDF_NGRAM_MAX` | 2 | Bigramas activados: «value at risk» o «riesgo de mercado» solo existen como pareja. Con unigramas puros, «risk» es tan común en este corpus que no discrimina n… |
| `RAG_TFIDF_MIN_DF` | `RAG_TFIDF_MIN_DF` | 1 | min_df=1: el corpus son decenas o cientos de chunks, no millones. Descartar términos que aparecen en un solo chunk borraría justo los tecnicismos raros que son… |
| `RAG_CHUNK_SIZE` | `RAG_CHUNK_SIZE` | 1200 | Troceado del índice. Más pequeño que el del chunker de evidencia: aquí el chunk es la UNIDAD DE RESPUESTA que se inyecta al prompt, y 1200 caracteres es un pár… |
| `RAG_CHUNK_OVERLAP` | `RAG_CHUNK_OVERLAP` | 200 | — |
| `RAG_CHUNKING_ESTRUCTURAL` | `RAG_CHUNKING_ESTRUCTURAL` | 0 | Chunking ESTRUCTURAL (respeta encabezados; no parte tablas ni fórmulas) como reemplazo OPT-IN del corte por tamaño en el indexador léxico. Default False: la pu… |
| `RAG_STEMMING` | `RAG_STEMMING` | 1 | Stemming conservador (ver `src/rag/indexador_lexico._stem`): hace que «modelos»/«modelo» caigan en el mismo token sin tocar acrónimos. |
| `RAG_LONGITUD_MINIMA_TOKEN` | `RAG_LONGITUD_MINIMA_TOKEN` | 2 | Tokens de 1 carácter no aportan; los de 2 SÍ (PD, LGD, EL, VaR en minúscula). |
| `RAG_TESAURO` | `RAG_TESAURO` | 1 | Expansión de consulta: las dos curas del punto ciego léxico BM25 encuentra por coincidencia de cadena, así que no une «excepciones» con «excedencias» aunque se… |
| `RAG_CORREGIR_ERRATAS` | `RAG_CORREGIR_ERRATAS` | 1 | — |
| `RAG_UMBRAL_ERRATA` | `RAG_UMBRAL_ERRATA` | 0.85 | — |
| `RAG_BANCO` | `RAG_BANCO` | 1 | [2026-11-23] CORPUS DEL BANCO (`inputs/rag/banco/`): el material que USA EL BANCO para validar —su estándar, su procedimiento, su catálogo de controles, sus re… |
| `RAG_TOP_K_BANCO` | `RAG_TOP_K_BANCO` | 2 | — |
| `CONTROLES_APRENDIDOS` | `CONTROLES_APRENDIDOS` | 1 | CONTROLES DE CALIDAD DE DATOS — aprendizaje por dominio Lecciones que los validadores enseñan al devolver el Excel del notebook (modulos/aprendizaje_controles.… |
| `CONTROLES_APRENDIDOS_MAX` | `CONTROLES_APRENDIDOS_MAX` | 25 | — |
| `CHAT_MAX_TOKENS` | `CHAT_MAX_TOKENS` | 1500 | AGENTE CONVERSACIONAL (Revisión con el agente) CHAT_MAX_TOKENS: tope de la respuesta del modelo por turno (con 800 se cortaban respuestas con citas y el JSON t… |
| `CHAT_MAX_CARACTERES` | `CHAT_MAX_CARACTERES` | 6000 | — |
| `UMBRAL_SIN_SEGUNDA_REVISION` | `VIRF_UMBRAL_SEGUNDA_REVISION` | 3 | Firmas consecutivas del mismo validador sobre el mismo modelo a partir de las cuales se advierte de falta de segunda revisión (SR 11-7 §V, segregación de funci… |

## 16. Scripts

| Script | Qué hace |
|---|---|
| `scripts/auditar_cobertura_rag.py` | ¿Contra qué actividades del estándar VIRF está CIEGO el corpus de literatura? |
| `scripts/demo_runoff.py` | DEMO de la validación completa de un modelo de RUN-OFF (supervivencia del saldo) |
| `scripts/escanear_secretos.py` | scripts/escanear_secretos.py [SEG-03] |
| `scripts/explicar_rag.py` | Abre el RAG léxico en canal: enseña, paso a paso y con NÚMEROS REALES del índice |
| `scripts/generar_corpus_banco.py` | corpus RAG con el MATERIAL QUE USA EL BANCO. |
| `scripts/generar_corpus_rag.py` | Genera un corpus de LITERATURA DE REFERENCIA en PDF para los cuatro dominios |
| `scripts/generar_guia_agente.py` | Guía de VIRF para el agente corporativo (DOCX y PDF). |
| `scripts/generar_guia_calidad_datos.py` | Guía del notebook de calidad de datos. |
| `scripts/generar_guia_tipos_modelo.py` | Guía de los TIPOS DE MODELO y de la |
| `scripts/generar_guia_uso.py` | Guía de uso de todo el proyecto VIRF. |
| `scripts/generar_inventario_archivos.py` | Inventario de TODOS los archivos del proyecto. |
| `scripts/generar_inventario_fuentes.py` | scripts/generar_inventario_fuentes.py [Paso 11] |
| `scripts/generar_mapa_herramienta.py` | Mapa completo de VIRF Agent, generado desde el código. |
| `scripts/generar_observabilidad.py` | scripts/generar_observabilidad.py [Pasos 56 · 57] |
| `scripts/generar_presentacion_guia.py` | Presentaciones (.pptx) de la herramienta VIRF. |
| `scripts/generar_referencia_tecnica.py` | Referencia técnica EXACTA, leída del código. |
| `scripts/pipeline_calidad_datos.py` | Pipeline de calidad de datos DEL VALIDADOR. Genera la tabla que el agente lee. |
| `scripts/preguntas_oro_banco.py` | ¿recupera el corpus del BANCO el documento correcto? |
| `scripts/preguntas_oro_formula.py` | Golden set DISCRIMINANTE de fórmula/tabla + medición IR léxica (API-free). |
| `scripts/preguntas_oro_rag.py` | Set de preguntas-oro del RAG léxico: ¿recupera el corpus el documento correcto? |
| `scripts/rebuild_rag_databricks.py` | Script de mantenimiento para reconstruir los índices RAG en Databricks. |
| `scripts/reconstruir_estandar_desde_informes.py` | Reconstruye inputs/Estandares_VIRF.xlsx a partir de los informes ya emitidos. |
| `scripts/verificar_corpus_rag.py` | VERIFICADOR DEL CORPUS RAG — ¿el índice contiene lo que dice contener? |
| `scripts/verificar_remoto_git.py` | scripts/verificar_remoto_git.py [SEG-11] |
| `scripts/web_prueba.py` | arranca la web v2 en MODO PRUEBA con «usuario libre». |

## 17. Documentación

| Documento | Título | Cómo se mantiene |
|---|---|---|
| `AUDITORIA_ANTIALUCINACION.md` | Auditoría anti-alucinación — VIRF Agent | a mano |
| `AUDITORIA_ENTORNO_CORPORATIVO.md` | Auditoría — Eliminación de dependencias externas y corrección del pipeline | a mano |
| `DESIGN.md` | DESIGN.md — VIRF Agent · capa visual «Sello institucional» | a mano |
| `FLAGS.md` | `agente.py` — Manual de referencia de flags | a mano |
| `FUNCIONALIDADES.md` | VIRF Agent — Catálogo completo de funcionalidades | a mano |
| `GUIA_CORPUS_RAG.md` | Guía para montar el corpus RAG y medir la calidad de la validación | a mano |
| `GUIA_INSTALACION.md` | Guía de instalación paso a paso — VIRF Agent | a mano |
| `GUIA_LLENAR_INPUTS.md` | Guía práctica: qué poner en `inputs/`, carpeta por carpeta | a mano |
| `GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md` | Guía de migración — Anthropic → Azure OpenAI | a mano |
| `GUIA_MULTIMODELO_Y_RAG.md` | Guía — Validar varios modelos y poblar el RAG | a mano |
| `GUIA_RAG_LEXICO.md` | Guía del RAG léxico de VIRF — cómo funciona, de verdad | a mano |
| `GUIA_TRASPASO_CONTEXTO.md` | Guía de traspaso de contexto — VIRF Agent (edición exhaustiva) | a mano |
| `GUIA_USO.md` | Guía de uso de VIRF Agent | generado por `scripts/generar_guia_uso.py` |
| `HANDOFF_AGENTE.md` | Traspaso para el agente corporativo — VIRF | a mano |
| `INFORME_AUDITORIA_2026-07-29.md` | Auditoría técnica exhaustiva — VIRF Agent v27 | a mano |
| `INVENTARIO_ARCHIVOS.md` | Inventario de archivos — VIRF Agent | generado por `scripts/generar_inventario_archivos.py` |
| `METODOLOGIA_DEL_AGENTE.md` | Metodología del Agente VIRF | a mano |
| `PROCEDIMIENTO_VALIDACION.md` | Procedimiento de Validación Independiente de Modelos | a mano |
| `PROMPT_CONTINUIDAD.md` | Prompt de continuidad — VIRF Agent v27 | a mano |
| `PROMPT_CONTINUIDAD_2026-08-07.md` | Prompt de continuidad — VIRF Agent · 2026-08-07 | a mano |
| `PROMPT_CONTINUIDAD_2026-08-09.md` | Prompt de continuidad — VIRF Agent · 2026-08-09 | a mano |
| `PROMPT_CONTINUIDAD_2026-08-16.md` | PROMPT DE CONTINUIDAD — VIRF Web · fixes pendientes (2026-08-16) | a mano |
| `PROMPT_CONTINUIDAD_2026-08-28.md` | PROMPT DE CONTINUIDAD — VIRF Agent · 2026-08-28 | a mano |
| `PROMPT_NUEVA_SESION.md` | Prompt para continuar en una sesión nueva (estado al 2026-11-24) | a mano |
| `PROMPT_OTRO_ASISTENTE.md` | Prompt para trabajar VIRF con otro asistente de IA (estado al 2026-11-24) | a mano |
| `QUE_HACE_REALMENTE.md` | VIRF Agent — qué hace realmente | a mano |
| `README.md` | VIRF Agent — Validador Autónomo de Modelos Financieros | a mano |
| `REFERENCIA_TECNICA.md` | Referencia técnica — VIRF Agent (generada del código) | generado por `scripts/generar_referencia_tecnica.py` |
| `REMEDIACION_SEG.md` | Remediación SEG · Fases 1 a 4 | a mano |
| `ROADMAP_v28.md` | Roadmap v28 — Qué mejorar y cuánto cuesta | a mano |
| `RUNBOOK.md` | RUNBOOK — Validar un modelo de principio a fin | a mano |
| `SESION_2026-07-31_RAG_Y_SKILLS.md` | Traspaso de sesión — 2026-07-31 · RAG léxico, evaluador crítico y skills | a mano |
| `docs/DESPLIEGUE_DATABRICKS.md` | Poner VIRF en Databricks — guía para tu primera vez en producción | a mano |
| `docs/FLUJO_AGENTE.md` | FLUJO DEL AGENTE — VIRF Agent (extremo a extremo) | a mano |
| `docs/GUIA_ERRORES_Y_SOPORTE.md` | Guía de errores y soporte: qué revisar cuando algo sale mal | a mano |
| `docs/GUIA_MEJORAS.md` | Guía de mejoras de VIRF (estado al 2026-11-24) | a mano |
| `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md` | Guía del notebook de calidad de datos | generado por `scripts/generar_guia_calidad_datos.py` |
| `docs/GUIA_TIPOS_DE_MODELO.md` | Guía de tipos de modelo y de la ruta de la validación completa | generado por `scripts/generar_guia_tipos_modelo.py` |
| `docs/LOGIN_CORPORATIVO_WEB_V3.md` | Login con cuenta corporativa (Entra ID) — pasos para la web v3 | a mano |
| `docs/MAPA_HERRAMIENTA.md` | Mapa completo de VIRF Agent | generado por `scripts/generar_mapa_herramienta.py` |
| `docs/PLAN_MAESTRO_VIRF.md` | PLAN MAESTRO DE ELEVACIÓN — VIRF AGENT | a mano |
| `docs/agente_corporativo/00_LEEME.md` | Paquete para el agente corporativo — cómo usarlo | a mano |
| `docs/agente_corporativo/CONOCIMIENTO_VIRF.md` | Conocimiento VIRF — base operativa para el agente corporativo | a mano |
| `docs/agente_corporativo/skills/S01_diagnosticar_fallo.md` | S01 — Diagnosticar un fallo | a mano |
| `docs/agente_corporativo/skills/S02_informes_word.md` | S02 — Informes Word | a mano |
| `docs/agente_corporativo/skills/S03_regla_calificacion.md` | S03 — Regla de calificación y riesgos | a mano |
| `docs/agente_corporativo/skills/S04_web_pantallas_endpoints.md` | S04 — Web: pantallas y endpoints | a mano |
| `docs/agente_corporativo/skills/S05_proveedor_ia.md` | S05 — Proveedor de IA, credenciales y modelos | a mano |
| `docs/agente_corporativo/skills/S06_estandar_validacion.md` | S06 — Estándar de validación (Excel) | a mano |
| `docs/agente_corporativo/skills/S07_rag_lexico.md` | S07 — RAG léxico y literatura por dominio | a mano |
| `docs/agente_corporativo/skills/S08_calidad_datos.md` | S08 — Calidad de datos, motores y notebook de controles | a mano |
| `docs/agente_corporativo/skills/S09_evidencia_y_capturas.md` | S09 — Evidencia: subida, lectura y capturas | a mano |
| `docs/agente_corporativo/skills/S10_chat_sustentacion.md` | S10 — Chat de sustentación y consolidación | a mano |
| `docs/agente_corporativo/skills/S11_usar_el_grafo.md` | S11 — Usar el grafo para acotar archivos | a mano |
| `docs/agente_corporativo/skills/S12_regenerar_guia_y_grafo.md` | S12 — Regenerar la guía y el grafo | a mano |
| `docs/agente_corporativo/skills/S13_validacion_completa.md` | S13 — Validación completa y puente a la validación final | a mano |
| `docs/agente_corporativo/skills/S14_tipos_de_modelo_y_notebook.md` | S14 — Tipos de modelo, notebook de calidad y repositorio | a mano |
| `docs/evidencia/beta_calibracion_dia2.md` | Calibración de β (abstención activa) — por datos, Día 2 | a mano |
| `docs/evidencia/indicadores_2026-08-28.md` | Paquete de Evidencia — Dia-1 | a mano |
| `docs/evidencia/indicadores_2026-08-28_Dia-2.md` | Paquete de Evidencia — Dia-2 | a mano |
| `docs/evidencia/indicadores_2026-08-28_Golden-1.md` | Paquete de Evidencia — Golden-1 | a mano |
| `docs/evidencia/indicadores_2026-08-31_Skills-1.md` | Paquete de Evidencia — Skills-1 | a mano |
| `docs/evidencia/plan_skills.md` | Plan de Skills (SK-WPs) — reconciliación guía ↔ código + mini-plan | a mano |
| `docs/evidencia/recall_cutover_dia2.md` | Cutover del chunking estructural — evidencia de recall (Día 2) | a mano |
| `docs/evidencia/reconciliacion_dia1.md` | Reconciliación Día 1 — guía ↔ plan | a mano |
| `docs/evidencia/reconciliacion_dia2.md` | Reconciliación Día 2 — guía ↔ plan (REAL) | a mano |
| `docs/evidencia/retrieval_chunking.md` | Retrieval IR (size vs estructural) + decisión de chunking — Golden-1 | a mano |
| `docs/guias/guia-arquitectura-agente-financiero (1).md` | Guía de Arquitectura del Agente VIRF: Validación de Modelos Financieros con RAG Avanzado y Observabilidad | a mano |
| `docs/guias/guia-errores-loops-validacion-rag (1).md` | Guía Avanzada de Ingeniería para Agentes RAG: Diagnóstico de Errores, Verificación del Retrieval y Bucles de… | a mano |
| `docs/guias/guia-integracion-skills-agente (1).md` | Guía de Integración y Conexión de Skills para el Agente de Validación Financiera (VIRF Agent) | a mano |
| `docs/seguridad/GOBIERNO_RIESGO_IA.md` | VIRF · Gobierno de riesgo de modelo IA (SEG-09) — BORRADOR | a mano |
| `.claude/skills/soporte-virf/SKILL.md` | Soporte de VIRF Agent | a mano |
| `.claude/skills/soporte-virf/references/arquitectura.md` | Arquitectura de VIRF para soporte | a mano |
| `.claude/skills/soporte-virf/references/diagnostico.md` | Diagnóstico: método y comandos | a mano |
| `.claude/skills/soporte-virf/references/recetas.md` | Recetas: cómo hacer cada tipo de cambio sin romper nada | a mano |
| `.claude/skills/soporte-virf/references/reglas.md` | Reglas de VIRF: qué, por qué y cómo cumplirlas | a mano |
| `.claude/skills/soporte-virf/references/verificacion.md` | Verificación: cómo demostrar que quedó bien | a mano |

<!-- volatil: lo que sigue cambia con cada prueba o commit (no lo compara el test) -->

## 18. Pruebas (volátil)

1659 funciones de prueba en 87 archivos (las parametrizadas cuentan una vez; el número exacto lo da `pytest --collect-only -q`). Todas a coste cero: la IA siempre simulada.

<details><summary>Archivos de prueba</summary>

| Archivo | Pruebas | Qué cubre |
|---|---|---|
| `tests/test_abstencion.py` | 6 | WP-01 · indicador D3. |
| `tests/test_acta_cierre.py` | 5 | Pruebas del ACTA DE CIERRE en Excel (3 hojas) generada al finalizar el chat. |
| `tests/test_adjuntos_ole.py` | 5 | Archivos incrustados en el Word con su icono |
| `tests/test_aislamiento.py` | 7 | WP-02 reducido · indicador D2. |
| `tests/test_almacenamiento.py` | 15 | SEG-06 · Almacenamiento local. |
| `tests/test_antialucinacion_brechas.py` | 33 | auditoría anti-alucinación (2026-11-18). |
| `tests/test_aprendizaje_chat.py` | 11 | WP-D: el chat guarda correcciones como feedback |
| `tests/test_aprendizaje_controles.py` | 12 | Notebook de calidad de datos enriquecido y aprendizaje por dominio (2026-11-24). |
| `tests/test_arbol_entornos.py` | 3 | Los recorridos del árbol deben reconocer un entorno virtual por `pyvenv.cfg`, |
| `tests/test_auditoria.py` | 9 | SEG-12 · Auditoría de acciones web. |
| `tests/test_automatizaciones.py` | 12 | Cuadro de observaciones desde los Excels 00–03 de automatización. Coste cero. |
| `tests/test_azure_mocks.py` | 72 | Verificación del flujo completo con Azure OpenAI SIMULADO. |
| `tests/test_beta_calibracion.py` | 5 | β de abstención calibrado por datos (Día 2). |
| `tests/test_capturas.py` | 6 | Capturas de evidencia para los informes («pantallazos»). Coste cero: sin IA; |
| `tests/test_chat_adjuntar.py` | 2 | WP-C: adjuntar evidencia en el chat → re-evaluar. |
| `tests/test_chat_controles.py` | 8 | Controles del agente conversacional (2026-11-24). Coste cero: el modelo se |
| `tests/test_chunker_estructural.py` | 7 | chunking estructural (GAP-29). |
| `tests/test_circuit_breakers.py` | 8 | WP-05 · indicador D6. |
| `tests/test_citas_deterministas.py` | 7 | WP-03/WP-04 · indicador D4 (parte determinista). |
| `tests/test_clasificacion_docx.py` | 6 | SEG-10 · Clasificación de informes: ningún Word sale sin la etiqueta |
| `tests/test_consolidacion.py` | 6 | Cierre HITL: el chat produce el puntaje EXACTO final (WP-A). |
| `tests/test_controles_bateria_tipo_modelo.py` | 7 | Notebook de calidad de datos: batería completa, cobertura del catálogo, |
| `tests/test_controles_ia.py` | 12 | Controles de datos asistidos por IA desde `.info()` / `.describe()` (2026-11-23). |
| `tests/test_corrida_fallida.py` | 12 | una corrida que no puede evaluar lo dice. |
| `tests/test_costes.py` | 5 | Pasos 54 · 56 · 57 — coste por llamada en la bitácora y reporte por corrida/usuario. |
| `tests/test_credenciales.py` | 20 | SEG-03 · Credenciales. |
| `tests/test_databricks_minimo_dato.py` | 6 | SEG-14 · Databricks: identidad de servicio y mínimo dato necesario. |
| `tests/test_deteccion_proveedor.py` | 33 | basta con poner la clave (2026-11-11). |
| `tests/test_diagnostico_azure.py` | 11 | Diagnóstico por capas de la conexión con Azure OpenAI (sin red real). |
| `tests/test_documentacion_consistente.py` | 6 | SEG-13 · Una sola verdad entre código, manual y CONOCIMIENTO. |
| `tests/test_docx_regresion.py` | 6 | WP-08 (estructura): reporte .docx desde |
| `tests/test_ejecucion_codigo.py` | 11 | SEG-07 · Ejecución de código. |
| `tests/test_endpoint_notebook_controles.py` | 2 | Prueba del endpoint GET /api/motores/notebook (coste 0: LLM interceptado). |
| `tests/test_entailment.py` | 7 | Verificación semántica de citas (modulos/entailment.py) — SIN API. |
| `tests/test_esquemas.py` | 10 | contrato Pydantic ValidationReport (WP-09). |
| `tests/test_estandares_sesion.py` | 16 | Tests del paso 02 · Estándares de validación por sesión (WEB-V2.4). |
| `tests/test_estructura_config.py` | 22 | Estructura de config/ y preparación para Azure OpenAI. |
| `tests/test_estudio_insumos.py` | 6 | Estudio de insumos (manuales, Excels de primera línea, scripts) para la |
| `tests/test_exportador_excel.py` | 2 | Excel de la tabla de validación (WP-B). Coste 0. |
| `tests/test_fallos_qa_sonnet.py` | 6 | Regresiones de los fallos que encontró el QA con Sonnet (pruebas/kit_qa_sonnet): |
| `tests/test_gateway_ia.py` | 16 | SEG-05 · Punto único de salida a IA. |
| `tests/test_gobierno_codigo.py` | 16 | Brechas «Pasos Generales Agente 2» con código: 3, 11, 15, 20, 25, 43, 49. |
| `tests/test_gobierno_ia.py` | 7 | SEG-09 · Gobierno de riesgo de modelo IA y tratamiento de SAST/SCA. |
| `tests/test_guia_agente.py` | 7 | Guía del agente corporativo (scripts/generar_guia_agente.py + docs/agente_corporativo/). |
| `tests/test_guia_progreso.py` | 5 | Paso 01 de la guía de la web (/api/guia/progreso). |
| `tests/test_guias_generadas.py` | 3 | Las guías de uso se generan desde el código (2026-11-24): si el catálogo de |
| `tests/test_hallazgos_completa.py` | 6 | Validación completa: cada etapa entrega un Excel y un .md con TODOS sus |
| `tests/test_identidad.py` | 23 | SEG-02 · Identidad y firma. |
| `tests/test_informe_tabla_final.py` | 2 | la tabla final se cablea al .docx. Coste 0. |
| `tests/test_invariante_asyncio.py` | 2 | Invariante: ninguna `asyncio.create_task(...)` puede quedar como sentencia suelta. |
| `tests/test_inyeccion.py` | 7 | Defensa anti-inyección de instrucciones (modulos/inyeccion.py): alta precisión, |
| `tests/test_mapa_herramienta.py` | 1 | El mapa completo de la herramienta (docs/MAPA_HERRAMIENTA.md) se GENERA desde el código: si cambia |
| `tests/test_motivo_corrida.py` | 6 | «Validar modelo» terminaba en «error» sin decir por qué y con una fase falsa |
| `tests/test_notebook_controles.py` | 10 | Pruebas API-free del generador de notebook de controles de datos (8 columnas). |
| `tests/test_pendientes_auditoria.py` | 231 | Tests de los pendientes de auditoría externa (SBS / Big4). |
| `tests/test_pii.py` | 24 | Enmascarado PII (modulos/pii.py): alta precisión, 100% local, sin red. |
| `tests/test_plantilla_bcp.py` | 4 | Plantilla común de los tres informes Word (Solo Informe, «Generar informe» de |
| `tests/test_presentacion_guia.py` | 22 | Las presentaciones de VIRF (guía detallada y visión general para |
| `tests/test_prompts_editables.py` | 17 | Tests de la capa de prompts editables por sesión y presupuesto dinámico |
| `tests/test_proveedor_gpt.py` | 4 | El motor no asume Claude (2026-11-24). |
| `tests/test_proveedores_ia.py` | 15 | SEG-01 · Lista cerrada de proveedores de IA (decisión del banco, no reabrir): |
| `tests/test_rag_banco.py` | 10 | RAG con el MATERIAL QUE USA EL BANCO (2026-11-23). Coste cero, sin red. |
| `tests/test_rag_desactualizado.py` | 4 | el panel RAG avisa si el índice quedó obsoleto |
| `tests/test_rag_lexico.py` | 39 | Tests del RAG LÉXICO (BM25 + TF-IDF) que sustituyó al RAG vectorial el |
| `tests/test_recursos_externos.py` | 3 | SEG-15 · Recursos externos: ningún HTML versionado carga nada de la red |
| `tests/test_regresion.py` | 464 | Red de regresión del núcleo VIRF |
| `tests/test_repositorio_corporativo.py` | 6 | SEG-11 · Repositorio de código: ninguna guía ni configuración apunta a nubes de |
| `tests/test_requirements_web_fijados.py` | 1 | web/requirements_web.txt debe fijar versiones exactas (==), como requirements.txt. |
| `tests/test_revision_sesion.py` | 15 | «Validar modelo» → «Revisión con el agente», en la SESIÓN (2026-11-23). |
| `tests/test_revision_validador.py` | 4 | Paso 09 · Revisión con el agente (antes de Documentar). Coste cero (mock). |
| `tests/test_roles.py` | 15 | SEG-08 · Roles y permisos + integridad del feedback. |
| `tests/test_salvaguardas_llm.py` | 11 | SEG-16 · Robustez del LLM: afirmaciones sin respaldo no llegan al informe. |
| `tests/test_solo_informe.py` | 39 | Tests del apartado «Solo Informe» (informe sin pipeline). Coste cero: no hay IA |
| `tests/test_solo_informe_holgura.py` | 22 | «Solo Informe» · lo pedido el 2026-11-23. Coste cero (IA simulada con |
| `tests/test_solo_informe_ia.py` | 21 | Tests de la asistencia con IA de «Solo Informe». Coste cero: el modelo se |
| `tests/test_tabla_validacion.py` | 18 | Veredicto formal por actividad + tabla intermedia + puente al chat. |
| `tests/test_tipos_modelo.py` | 18 | Tipos de modelo (fichas de negocio), notebook de calidad de datos experto en |
| `tests/test_upload_zip.py` | 5 | POST /api/inputs/upload-zip — extracción segura de ZIP (coste 0, carpeta temporal). |
| `tests/test_usuario_libre.py` | 9 | Usuario libre (web v2, modo prueba) — el SSO corporativo queda para la web v3. |
| `tests/test_validacion_completa.py` | 13 | Validación completa: 5 chats (00–04). Cada iteración entrega un notebook |
| `tests/test_validador_entorno_hf.py` | 2 | Guardia de la política «cero HuggingFace / cero ChromaDB» (validate_project.py). |
| `tests/test_verificacion_citas.py` | 12 | una cita literal no se rechaza por su formato. |
| `tests/test_versionado.py` | 13 | WP-10: versionado temporal + ventana de contexto. |
| `tests/test_virf_plus.py` | 12 | VIRF PLUS (GPT principal + Claude como segunda opinión) — coste cero, con dobles. |
| `pruebas/test_calidad_e2e.py` | 9 | Pasos 42 · 60 · 63 · 65 — métricas de calidad, rúbrica sellada y E2E sintético. |
| `pruebas/test_casos_borde.py` | 11 | Paso 64 · Casos borde de la lectura de evidencia (matriz: pruebas/matriz_casos_borde.md). |
| `pruebas/seguridad/test_owasp_llm.py` | 10 | Paso 62 · Suite red-team alineada a OWASP Top 10 para aplicaciones LLM. |

</details>

## 19. Historial y trabajo sin commitear (volátil)

Rama `docs/firma-sin-validador` · último commit b742a5e · 2026-11-18 · feat(solo-informe): estándar tolerante a errores, vista previa y filtro por ámbito.

**Trabajo sin commitear:** 211 entradas.

| Carpeta | Modificados | Nuevos | Otros |
|---|---|---|---|
| `(raíz)` | 4 | 13 | 0 |
| `_respaldo_ui` | 0 | 1 | 0 |
| `audit_logs` | 1 | 0 | 0 |
| `config` | 5 | 0 | 0 |
| `diseno_ui` | 0 | 1 | 0 |
| `docs` | 26 | 11 | 0 |
| `feedback` | 1 | 0 | 0 |
| `graphify-out` | 0 | 1 | 0 |
| `inputs` | 25 | 17 | 0 |
| `modulos` | 11 | 13 | 0 |
| `motor` | 2 | 0 | 0 |
| `pruebas` | 0 | 1 | 0 |
| `scripts` | 3 | 9 | 0 |
| `src` | 2 | 1 | 0 |
| `tests` | 8 | 20 | 0 |
| `web` | 30 | 5 | 0 |

<details><summary>Lista completa</summary>

- **(raíz)**: `.env.example` (modificado), `agente.py` (modificado), `requirements.txt` (modificado), `validate_project.py` (modificado), `AUDITORIA_ANTIALUCINACION.md` (nuevo), `DESIGN.md` (nuevo), `GUIA_INSTALACION.md` (nuevo), `GUIA_TRASPASO_CONTEXTO.md` (nuevo), `GUIA_USO.md` (nuevo), `INVENTARIO_ARCHIVOS.md` (nuevo), `PROMPT_NUEVA_SESION.md` (nuevo), `PROMPT_OTRO_ASISTENTE.md` (nuevo), `REFERENCIA_TECNICA.md` (nuevo), `REMEDIACION_SEG.md` (nuevo), `diagnostico_azure_virf.py` (nuevo), `virf_agent_v27_final_VERSION_FINAL.zip` (nuevo), `virf_agent_v27_final_copia.zip` (nuevo)
- **_respaldo_ui**: `_respaldo_ui/` (nuevo)
- **audit_logs**: `audit_logs/registro_emisiones.jsonl` (modificado)
- **config**: `config/__init__.py` (modificado), `config/ia.py` (modificado), `config/modelos.py` (modificado), `config/parametros.py` (modificado), `config/red.py` (modificado)
- **diseno_ui**: `diseno_ui/` (nuevo)
- **docs**: `docs/agente_corporativo/CONOCIMIENTO_VIRF.md` (modificado), `docs/agente_corporativo/GUIA_VIRF_AGENTE_CORPORATIVO.docx` (modificado), `docs/agente_corporativo/GUIA_VIRF_AGENTE_CORPORATIVO.pdf` (modificado), `docs/agente_corporativo/GUIA_VIRF_PRESENTACION.pptx` (modificado), `docs/agente_corporativo/capturas/01_login.jpg` (modificado), `docs/agente_corporativo/capturas/02_mis_modelos.jpg` (modificado), `docs/agente_corporativo/capturas/03_nuevo_modelo.jpg` (modificado), `docs/agente_corporativo/capturas/04_dashboard_inicio.jpg` (modificado), `docs/agente_corporativo/capturas/05_configuracion.jpg` (modificado), `docs/agente_corporativo/capturas/06_estandares.jpg` (modificado), `docs/agente_corporativo/capturas/07_evidencia.jpg` (modificado), `docs/agente_corporativo/capturas/08_dominio_rag.jpg` (modificado), `docs/agente_corporativo/capturas/09_skills.jpg` (modificado), `docs/agente_corporativo/capturas/10_cuestionamientos.jpg` (modificado), `docs/agente_corporativo/capturas/11_validar.jpg` (modificado), `docs/agente_corporativo/capturas/12_documentar.jpg` (modificado), `docs/agente_corporativo/capturas/13_resultados.jpg` (modificado), `docs/agente_corporativo/capturas/14_controles_datos.jpg` (modificado), `docs/agente_corporativo/capturas/15_chat.jpg` (modificado), `docs/agente_corporativo/capturas/16_guia_ayuda.jpg` (modificado), `docs/agente_corporativo/capturas/17_solo_informe.jpg` (modificado), `docs/agente_corporativo/capturas/18_solo_informe_datos.jpg` (modificado), `docs/agente_corporativo/capturas/19_solo_informe_observacion.jpg` (modificado), `docs/agente_corporativo/capturas/20_movil_mis_modelos.jpg` (modificado), `docs/agente_corporativo/capturas/21_movil_solo_informe.jpg` (modificado), `docs/agente_corporativo/skills/S08_calidad_datos.md` (modificado), `docs/GUIA_ERRORES_Y_SOPORTE.md` (nuevo), `docs/GUIA_MEJORAS.md` (nuevo), `docs/GUIA_NOTEBOOK_CALIDAD_DATOS.md` (nuevo), `docs/GUIA_TIPOS_DE_MODELO.md` (nuevo), `docs/MAPA_HERRAMIENTA.md` (nuevo), `docs/agente_corporativo/VIRF_VISION_GENERAL.pptx` (nuevo), `docs/agente_corporativo/capturas/23_etapa_vista.jpg` (nuevo), `docs/agente_corporativo/capturas/24_etapa_ruta.jpg` (nuevo), `docs/agente_corporativo/capturas/25_validar_bloqueado.jpg` (nuevo), `docs/agente_corporativo/skills/S13_validacion_completa.md` (nuevo), `docs/agente_corporativo/skills/S14_tipos_de_modelo_y_notebook.md` (nuevo)
- **feedback**: `feedback/registro_validadores.json` (modificado)
- **graphify-out**: `graphify-out/` (nuevo)
- **inputs**: `inputs/repositorio_controles/README.md` (modificado), `inputs/repositorio_controles/alm/backtesting_prepago.py` (modificado), `inputs/repositorio_controles/alm/beta_deposito.py` (modificado), `inputs/repositorio_controles/alm/brecha_duracion.py` (modificado), `inputs/repositorio_controles/alm/cpr_prepago.py` (modificado), `inputs/repositorio_controles/alm/decaimiento_nmd.py` (modificado), `inputs/repositorio_controles/alm/delta_eve.py` (modificado), `inputs/repositorio_controles/alm/delta_nii.py` (modificado), `inputs/repositorio_controles/alm/escenarios_irrbb_completos.py` (modificado), `inputs/repositorio_controles/alm/gap_reprecios.py` (modificado), `inputs/repositorio_controles/alm/sot_eve_tier1.py` (modificado), `inputs/repositorio_controles/alm/vida_media_nmd.py` (modificado), `inputs/repositorio_controles/lar/brecha_liquidez_acumulada.py` (modificado), `inputs/repositorio_controles/lar/concentracion_fondeo.py` (modificado), `inputs/repositorio_controles/lar/horizonte_supervivencia.py` (modificado), `inputs/repositorio_controles/lar/hqla_composicion.py` (modificado), `inputs/repositorio_controles/lar/lcr.py` (modificado), `inputs/repositorio_controles/lar/nsfr.py` (modificado), `inputs/repositorio_controles/var/backtesting_excedencias.py` (modificado), `inputs/repositorio_controles/var/christoffersen.py` (modificado), `inputs/repositorio_controles/var/kupiec.py` (modificado), `inputs/repositorio_controles/var/monotonia_niveles_var.py` (modificado), `inputs/repositorio_controles/var/semaforo_basilea.py` (modificado), `inputs/repositorio_controles/var/severidad_excepciones.py` (modificado), `inputs/repositorio_controles/var/var_negativos.py` (modificado), `inputs/rag/banco/` (nuevo), `inputs/repositorio_controles/alm/cancelacion_anticipada.py` (nuevo), `inputs/repositorio_controles/alm/nucleo_topes_bcbs.py` (nuevo), `inputs/repositorio_controles/alm/runoff_curvas.py` (nuevo), `inputs/repositorio_controles/alm/runoff_saltos_cosechas.py` (nuevo), `inputs/repositorio_controles/alm/runoff_supervivencia_saldos.py` (nuevo), `inputs/repositorio_controles/alm/smm_cpr_consistencia.py` (nuevo), `inputs/repositorio_controles/alm/supervivencia_km.py` (nuevo), `inputs/repositorio_controles/lar/factores_nsfr.py` (nuevo), `inputs/repositorio_controles/lar/lar_percentil.py` (nuevo), `inputs/repositorio_controles/lar/lcr_tope_entradas.py` (nuevo), `inputs/repositorio_controles/lar/runoff_tasas.py` (nuevo), `inputs/repositorio_controles/var/alineacion_pnl_var.py` (nuevo), `inputs/repositorio_controles/var/escalado_horizonte.py` (nuevo), `inputs/repositorio_controles/var/matriz_covarianzas.py` (nuevo), `inputs/repositorio_controles/var/pla_frtb.py` (nuevo), `inputs/repositorio_controles/var/rfet_modelabilidad.py` (nuevo)
- **modulos**: `modulos/automatizaciones.py` (modificado), `modulos/chunker.py` (modificado), `modulos/explicador_modelo.py` (modificado), `modulos/fuentes_rag.py` (modificado), `modulos/generador_markdown.py` (modificado), `modulos/generador_word.py` (modificado), `modulos/motor_ia.py` (modificado), `modulos/motores_entidad.py` (modificado), `modulos/notebook_controles.py` (modificado), `modulos/plantilla_bcp.py` (modificado), `modulos/revision_codigo.py` (modificado), `modulos/aprendizaje_controles.py` (nuevo), `modulos/controles_ia.py` (nuevo), `modulos/estudio_insumos.py` (nuevo), `modulos/graficos_estructurados.py` (nuevo), `modulos/hallazgos_completa.py` (nuevo), `modulos/libreria_cuant.py` (nuevo), `modulos/plantillas_etapa.py` (nuevo), `modulos/tipos_modelo.py` (nuevo), `modulos/tipos_modelo_alm.py` (nuevo), `modulos/tipos_modelo_liquidez.py` (nuevo), `modulos/tipos_modelo_trading.py` (nuevo), `modulos/validacion_completa.py` (nuevo), `modulos/verificacion_cifras.py` (nuevo)
- **motor**: `motor/Mx_00_CargaRutas.py` (modificado), `motor/Mx_03_LlamarIA.py` (modificado)
- **pruebas**: `pruebas/kit_qa_sonnet/` (nuevo)
- **scripts**: `scripts/generar_guia_agente.py` (modificado), `scripts/generar_presentacion_guia.py` (modificado), `scripts/rebuild_rag_databricks.py` (modificado), `scripts/demo_runoff.py` (nuevo), `scripts/generar_corpus_banco.py` (nuevo), `scripts/generar_guia_calidad_datos.py` (nuevo), `scripts/generar_guia_tipos_modelo.py` (nuevo), `scripts/generar_guia_uso.py` (nuevo), `scripts/generar_inventario_archivos.py` (nuevo), `scripts/generar_mapa_herramienta.py` (nuevo), `scripts/generar_referencia_tecnica.py` (nuevo), `scripts/preguntas_oro_banco.py` (nuevo)
- **src**: `src/rag/__init__.py` (modificado), `src/rag/config_rag.py` (modificado), `src/rag/banco/` (nuevo)
- **tests**: `tests/conftest.py` (modificado), `tests/test_azure_mocks.py` (modificado), `tests/test_estandares_sesion.py` (modificado), `tests/test_guia_agente.py` (modificado), `tests/test_presentacion_guia.py` (modificado), `tests/test_regresion.py` (modificado), `tests/test_solo_informe.py` (modificado), `tests/test_solo_informe_ia.py` (modificado), `tests/_sinteticos_tipos.py` (nuevo), `tests/test_antialucinacion_brechas.py` (nuevo), `tests/test_aprendizaje_controles.py` (nuevo), `tests/test_chat_controles.py` (nuevo), `tests/test_controles_bateria_tipo_modelo.py` (nuevo), `tests/test_controles_ia.py` (nuevo), `tests/test_diagnostico_azure.py` (nuevo), `tests/test_estudio_insumos.py` (nuevo), `tests/test_fallos_qa_sonnet.py` (nuevo), `tests/test_guias_generadas.py` (nuevo), `tests/test_hallazgos_completa.py` (nuevo), `tests/test_mapa_herramienta.py` (nuevo), `tests/test_motivo_corrida.py` (nuevo), `tests/test_proveedor_gpt.py` (nuevo), `tests/test_rag_banco.py` (nuevo), `tests/test_revision_sesion.py` (nuevo), `tests/test_revision_validador.py` (nuevo), `tests/test_solo_informe_holgura.py` (nuevo), `tests/test_tipos_modelo.py` (nuevo), `tests/test_validacion_completa.py` (nuevo)
- **web**: `web/app.py` (modificado), `web/data/prompts_base.json` (modificado), `web/data/validadores.json` (modificado), `web/routers/automatizaciones.py` (modificado), `web/routers/chat.py` (modificado), `web/routers/config.py` (modificado), `web/routers/controles.py` (modificado), `web/routers/cuestionamientos.py` (modificado), `web/routers/estandares.py` (modificado), `web/routers/guia.py` (modificado), `web/routers/modelos.py` (modificado), `web/routers/resultados.py` (modificado), `web/routers/solo_informe.py` (modificado), `web/routers/upload.py` (modificado), `web/routers/validacion.py` (modificado), `web/services/auditoria_web.py` (modificado), `web/services/chat_service.py` (modificado), `web/services/contexto_sesion.py` (modificado), `web/services/dominios_custom_store.py` (modificado), `web/services/estandares_service.py` (modificado), `web/services/informe_web.py` (modificado), `web/services/modelos_store.py` (modificado), `web/services/pipeline_runner.py` (modificado), `web/services/solo_informe_ia.py` (modificado), `web/services/solo_informe_service.py` (modificado), `web/services/solo_informe_word.py` (modificado), `web/static/css/styles.css` (modificado), `web/static/js/app.js` (modificado), `web/static/js/guia.js` (modificado), `web/templates/index.html` (modificado), `web/routers/validacion_completa.py` (nuevo), `web/services/evidencia_sesion.py` (nuevo), `web/static/css/ui-sello.css` (nuevo), `web/static/js/completa.js` (nuevo), `web/static/js/ui.js` (nuevo)

</details>

**Historial:** 89 commits.

<details><summary>Commits por fecha</summary>

- **2026-11-18**: `b742a5e` feat(solo-informe): estándar tolerante a errores, vista previa y filtro por ámbito
- **2026-11-11**: `c2ce8e0` fix(citas): una cita literal no se rechaza por su formato · `fa3da3b` fix(corrida): una corrida que no puede evaluar se corta y lo dice · `3cf8a05` feat(ia): el proveedor se deduce de la clave presente fuera de producción · `f293389` fix(feedback): el aprendizaje respeta la aprobación y no premia las subsanaciones · `5f05aff` feat(solo-informe): sustento con archivos incrustados en el Word con su icono · `7ac7497` fix(SEG): guía, avisos de IA y caché cifrada coherentes con la remediación
- **2026-11-09**: `7ae58e5` docs: la firma sale de la sesión web; fuera --validador/--cargo · `f03b209` feat(web): usuario libre para probar la web v2; SSO Entra ID pasa a la web v3 · `e687a5e` docs(readme): arranque seguro tras la remediación SEG y las brechas · `5c4ecd7` docs(brechas): pasos 19, 42, 63 y 76 como oportunidades de mejora · `29a3d12` docs(brechas): reporte de cierre generado desde el backlog · `2c41082` fix(brechas D): contraseña ficticia del red-team sin literal escaneable · `d7b85ea` docs(brechas E+F): puesta en marcha, go/no-go y backlog formal · `f06a73f` feat(brechas D): pruebas funcionales, casos borde, red-team OWASP, calidad y E2E · `7a61768` feat(brechas C): coste por llamada en la bitácora y dataset de observabilidad · `861511e` feat(brechas A+B): gobierno documentado y pasos 3, 11, 15, 20, 25, 43 en código · `0bff695` fix(SEG-15): HTML sin cargas externas (Google Fonts retirado)
- **2026-11-06**: `f2bf65d` fix(SEG-09): inventario y cuestionario de riesgo IA; SAST/SCA ejecutados y tratados · `62b9bd4` fix(SEG-16): citas dudosas y NLI negativo invalidan; abstención β cableada · `890dd07` fix(SEG-14): Databricks sin token personal y lecturas de mínimo dato · `6b60617` fix(SEG-07): sin exec sobre código no confiable; META por AST y aprobación humana · `65007fb` fix(SEG-06): clasificación obligatoria, caché cifrada y retención local
- **2026-11-05**: `465ac72` fix(SEG-13): defaults en código y manual con valores reales · `8c604b2` fix(SEG-11): VIRF_REPO_CORPORATIVO leído en config/parametros.py y documentado · `f8d199c` fix(SEG-11): guías y remotos solo hacia el repositorio corporativo · `f23a6e7` fix(SEG-10): etiqueta de clasificación en el pie de todo Word · `aca544f` fix(SEG-12): log de auditoría append-only de acciones web e IA · `04c6e78` fix(SEG-08): roles validador/admin_corpus/revisor y feedback encadenado · `8615a0f` fix(SEG-02): login SSO y firmante derivado de la identidad autenticada · `55ff37f` fix(SEG-03): credenciales fuera de disco y web sin escritura de claves · `657f6cc` fix(SEG-01): lista cerrada de proveedores de IA y VIRF PLUS bloqueado · `7c7899d` fix(SEG-05): gateway único de salida a IA · `8709046` fix(SEG-04): enmascarado PII con base peruana y tokens estables · `253fab6` docs: guía del agente corporativo (PDF, conocimiento, skills) y presentación .pptx
- **2026-11-04**: `cef5ec9` style: web usable en móvil, contraste AA y foco de teclado visible · `029d949` feat: capturas de evidencia en el informe web (portada, página citada y código) · `7622707` feat: plantilla común «Informe de Resultados» para los tres informes Word · `95e9866` docs: nota de traspaso para el agente corporativo (reglas, Solo Informe y grafo) · `be23218` feat: asistencia con IA opcional en «Solo Informe» (pulir, gráficos y manuales) · `f2fbea9` feat: apartado «Solo Informe» que genera el informe Word sin ejecutar el pipeline
- **2026-10-17**: `c5609ab` feat: GPT como agente principal; VIRF PLUS suma a Claude como segunda opinion · `fa661b4` feat: VIRF PLUS (beta), cuadro de observaciones desde Excels 00-03 y guia interactiva en la web
- **2026-09-28**: `1cbd960` test: los recorridos del arbol reconocen entornos virtuales por pyvenv.cfg · `694786c` docs: guia de despliegue de VIRF en Databricks (.md + .pdf) · `1e5fbf5` fix: asyncio sin referencia, ZIP bomb, guardia HF ciego a chromadb, deps web fijadas
- **2026-09-24**: `2a700e1` refactor(dominio): renombra el dominio conductuales -> ALM en todo el sistema (alias legacy) · `de6f641` feat(controles): taxonomia real de dominios + catalogo ampliado (+17 controles) · `ef346c0` feat(controles+web): repositorio de controles por dominio, notebook especializado y soporte web
- **2026-09-09**: `4d701e5` test(rag): actualiza los tests golden y de aislamiento a las semillas del corpus · `915f1d0` feat(seguridad): PII, anti-inyeccion y entailment sobre la evidencia (P1/P2 auditoria RAG)
- **2026-09-08**: `1552493` feat(informe): plantilla editorial consistente para el botón «Generar informe»
- **2026-09-02**: `eb76ee3` feat(datos+rag+hitl): notebook de controles descargable, semillas RAG con borrado por-archivo y acta de cierre en Excel · `8e77811` docs(env): documenta ANTHROPIC_WORKSPACE_ID en .env.example · `77a940d` feat(rag): avisa cuando el índice quedó obsoleto tras subir manuales
- **2026-08-31**: `700bfdf` feat(docx): cablea la tabla FINAL (con decisiones del chat + puntaje exacto) al .docx · `ca416c2` feat(hitl): WP-D — el chat guarda correcciones como aprendizaje (contexto + ajuste automático) · `47fb980` feat(hitl): WP-C — el validador adjunta evidencia en el chat y el agente reevalúa · `22a35a0` feat(hitl+excel): puntaje exacto desde el chat (WP-A) + Excel intermedio/final (WP-B) · `0f25217` fix(cli+tabla): arregla ESTANDARES_PATH y hace la selección del chat 100% por veredicto formal · `135b877` feat(tabla): output intermedio con veredicto formal por actividad + puente al chat, multi-proveedor Claude · `1b81d5e` feat(web-v2): cablea la sesion web al pipeline CLI + politicas de procedimiento · `b50f340` docs: flujo del agente ACTUAL vs OBJETIVO (4 fases, con evidencia) · `caf3beb` Skills-1: fundacion tipada de las 6 skills + Calidad de Datos completa (API-free) · `25db7e0` Respaldo pre-migracion: app web, cuestionamientos, guias y continuidad
- **2026-08-28**: `a4b5d57` Golden-1: set discriminante formula/tabla + IR lexico + decision chunking · `9f6fe57` Cierre Dia 2: verificador + evidencia Dia-2 · `5a7f015` WIP cierre Dia 2: WP-09, WP-08-estructura, cutover chunking (opt-in), beta · `e334298` Calibra beta de abstencion por datos: 0.0 -> 0.19 (punto de separacion) · `eaf6685` Cutover chunking estructural a default (puerta recall@1=1.0) · `02879cb` WP-08 (estructura): .docx con veredictos por ambito, sin-observaciones, pie paginado y referencias · `900f02c` WP-10: Versionado temporal (is_active) + ventana de contexto dinamica · `c58b3bf` WP-09: Contrato Pydantic ValidationReport (adaptador dict->tipado) · `32a75bf` Cierre Día 1: paquete de evidencia (VERDE 7 / AMBAR 1 / ROJO 6 / NA 15) · `0e68d35` WP: Chunking estructural por secciones (opt-in) [GAP-29] · `5b204ac` WP-07 (prep): Sujeto de prueba VaR para inyección de error [D1 NA-diferido] · `6845248` WP-03: Validador determinista de citas con id de linaje [D4-det] · `98e1cc3` WP-02 (reducido): Aislamiento multi-tenant probado (anti-spillover) [D2] · `f0c3822` WP-01: Compuerta de abstención activa (EVIDENCIA INSUFICIENTE, β) [D3] · `ab20920` WP-05: Cortacircuitos (cap iteraciones + fusibles tiempo/tokens) [D6] · `e26d9bf` WP-00: Verificador de Indicadores + plan maestro + reconciliación Día 1
- **2026-08-08**: `f0bffc0` Tope de puntaje 3 cuando la tolerancia declarada es cero
- **2026-08-07**: `068b834` Pipeline de calidad de datos del validador: genera la tabla que el agente lee · `8aabe36` Motores de calidad de datos de la entidad: lectura de resultados · `b0af462` Amplía el set a 24 preguntas y corrige la elegibilidad de recall@3 · `ca306af` Segundo umbral recall@3: se activa solo cuando el corpus crece · `a307ef0` Set de preguntas-oro del RAG (12 preguntas + 4 adversarias) · `5f8893f` Auditoría integral: corrige los 15 hallazgos (F-01..F-15) · `9b18e3f` Estado auditado del proyecto VIRF v27

</details>
