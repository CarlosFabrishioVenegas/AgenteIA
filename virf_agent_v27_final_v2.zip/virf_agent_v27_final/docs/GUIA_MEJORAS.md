# Guía de mejoras de VIRF (estado al 2026-11-24)

> Qué conviene mejorar, por qué, dónde está y cómo comprobar que quedó bien. Cada punto sale de algo
> **verificado** en el código o en las pruebas (se cita el archivo), no de una idea suelta. Actualiza al
> `ROADMAP_v28.md` (agosto) en lo que se solapan. Esfuerzo: **S** ≤ 1 día · **M** 2–4 días · **L** ≥ 1 semana,
> contando tests, guías regeneradas y la suite completa.
>
> Lo que **no** es una mejora (decisiones ya tomadas: proveedor, RAG léxico, sin OCR, modalidad
> explícita…) está en `GUIA_TRASPASO_CONTEXTO.md` §16: no se reabre.

## Resumen: por dónde empezar

| # | Prioridad | Mejora | Por qué | Esfuerzo |
|---|---|---|---|---|
| 1 | P0 | Commitear y respaldar el trabajo | ~170 archivos sin commitear y `main` sin remoto: un fallo del disco lo pierde todo | S |
| 2 | P0 | Clasificar lo que se sube a la validación completa | Las etapas no piden clasificación (el paso 03 sí): datos sin etiqueta que acaban en la evidencia | M |
| 3 | P0 | Filas del inventario de gobierno de IA | Test en rojo; sin ellas no hay aprobación de uso | S (decisión humana) |
| 4 | P0 | Prueba controlada con IA real de lo nuevo | Prompts de etapas, chat con la completa y controles con IA solo se probaron simulados | M |
| 5 | P0 | Revisión experta de las fichas de tipo de modelo | Umbrales, bandas y tasas son razonables pero no los validó el área | M |
| 6 | P1 | Evitar el doble conteo en «Calidad de datos» | El mismo notebook puede llegar por dos caminos y puntuar dos veces | S |
| 7 | P1 | Leer mejor los Excel de resultados en el 08 | 200 filas por hoja y 15 000 caracteres por documento: hojas útiles quedan fuera | M |
| 8 | P1 | Procedencia de los Excel de resultados | Un Excel editado a mano no se distingue de uno generado por el notebook | M |
| 9 | P1 | Rendimiento de los notebooks con bases grandes | Kaplan–Meier y pivotes recorren todo en memoria | M |
| 10 | P1 | Resumen de la validación completa en el cuerpo del informe | Hoy solo va en un anexo | S |

---

## P0 — Antes de producción o de perder trabajo

### 1. Commitear y respaldar el trabajo
- **Qué pasa:** la rama `docs/firma-sin-validador` tiene ~170 entradas sin commitear
  (`docs/MAPA_HERRAMIENTA.md` §19 las lista por carpeta) y `main` es local, sin remoto.
- **Cómo:** commits por área (validación completa y puente; tipos de modelo y notebooks; run-off; chat;
  guías y mapa; skill de soporte), en una rama, y un remoto privado del banco o al menos una copia fechada.
- **Verificar:** `git status` limpio salvo lo ignorado; `git log` con los commits por área; suite verde antes
  de cada commit.

### 2. Clasificar lo que se sube a la validación completa
- **Qué pasa:** `POST /api/completa/etapa/{codigo}/iteracion` y `/api/completa/insumos/subir`
  (`web/routers/validacion_completa.py`) no piden **clasificación** ni la registran
  (`modulos/almacenamiento.py`), a diferencia de `03 · Evidencia` (SEG-06). Con el puente al 08, lo que
  VIRF genera a partir de esos archivos entra en la evidencia de la validación.
- **Cómo:** pedir la clasificación en ambos formularios (`completa.js`), registrarla con
  `registrar_clasificacion`, rechazar «Restringido» donde no esté permitido y propagarla a lo que publica
  `publicar_en_validacion` (la copia hereda la clasificación más alta de sus fuentes).
- **Verificar:** test de endpoint sin clasificación → 400; la copia publicada con la clasificación correcta.

### 3. Filas del inventario de gobierno de IA
- **Qué pasa:** `tests/test_gobierno_ia.py::test_inventario_cubre_cada_llamante_de_ia` está en rojo a
  propósito: faltan `modulos/estudio_insumos.py` y `modulos/validacion_completa.py` en
  `docs/seguridad/GOBIERNO_RIESGO_IA.md`, y conviene revisar las filas de controles con IA y Solo Informe.
- **Cómo:** las escribe el responsable (decide el estado de aprobación); el asistente solo puede preparar el
  borrador del texto descriptivo si se le pide.
- **Verificar:** el test en verde.

### 4. Prueba controlada con IA real de lo nuevo
- **Qué pasa:** todo lo nuevo se probó con la IA simulada (coste cero): prompts de las cinco etapas con la
  ficha del tipo de modelo y la ruta, el bloque `{validacion_completa}` del chat 09, la propuesta de
  controles con IA y la especialización de Solo Informe.
- **Cómo:** un modelo de prueba (p. ej. los datos de `scripts/demo_runoff.py`), presupuesto fijado y
  `--dry-run` antes; una pasada por etapa, un 08 en modalidad completa y diez turnos de chat.
- **Verificar:** que el agente cita los hallazgos de las etapas sin inventar (la verificación de citas no
  degrada aprobados), que las rutas quedan «cubiertas» y el coste real frente al estimado
  (`audit_logs/auditoria_acciones.jsonl`).

### 5. Revisión experta de las fichas de tipo de modelo
- **Qué pasa:** las 19 fichas (`modulos/tipos_modelo_trading.py`, `_alm.py`, `_liquidez.py`) llevan umbrales,
  bandas y referencias razonables, pero no revisados por el área: tasas regulatorias locales de RCL/RFNE,
  bandas del manual, topes BCBS 368 por categoría, y en run-off el horizonte del componente estable
  (60 meses por defecto) y si la curva es de cosechas o del saldo existente (`SUPUESTOS["curva_de"]`).
- **Cómo:** un validador por familia revisa `docs/GUIA_TIPOS_DE_MODELO.md` (generada) y marca cambios; se
  aplican en la ficha y se regenera la guía.
- **Verificar:** `tests/test_tipos_modelo.py` y la guía regenerada.

---

## P1 — Calidad del producto

### 6. Evitar el doble conteo en «Calidad de datos»
- **Qué pasa:** `modulos/motores_entidad.py` puntúa **todas** las tablas de
  `calidad_datos/resultadocalidad_de_datos/`. Si el validador usó «Usar estos resultados en la validación»
  con un notebook y además la completa publica `completa_01_ControlDatos.xlsx`, los mismos controles
  pueden contar dos veces.
- **Cómo:** deduplicar por `Control` (id) y descripción al leer, dejando la fuente más reciente, y declararlo
  en el informe; o avisar en el panel del 08 si hay más de una tabla.
- **Verificar:** test con dos tablas que comparten controles → una sola evaluación por control.

### 7. Leer mejor los Excel de resultados en el 08
- **Qué pasa:** `motor/Mx_01_LecturaEvidencias.py::_leer_excel` lee todas las hojas con 200 filas
  (`MAX_FILAS_EXCEL`) y el documento se corta en `MAX_CHARS_DOC` (15 000). En el Excel del 01 o del 02, las
  primeras hojas (perfiles) pueden consumir el espacio y dejar fuera la réplica o las fallas.
- **Cómo:** un lector específico para los Excel de VIRF que use la hoja «Indice» para priorizar (Replica,
  Fallas, Conclusion, Backtesting antes que perfiles), o que el notebook escriba una hoja «Resumen» primero.
- **Verificar:** test con un Excel de 30 hojas → la hoja de réplica aparece en el texto del ámbito.

### 8. Procedencia de los Excel de resultados
- **Qué pasa:** el Excel que vuelve al chat puede editarse a mano y nada lo distingue del que generó el
  notebook (`leer_anexos` solo mira MODO_DEMO y la propuesta).
- **Cómo:** el notebook escribe en «Metadatos» la huella del propio notebook y de cada base leída (tamaño,
  filas, hash); al recibir, VIRF comprueba que el notebook es el que entregó y avisa si no coincide. No
  bloquea (el validador puede corregir), pero queda registrado.
- **Verificar:** test que altera una celda del Excel → aviso de procedencia.

### 9. Rendimiento de los notebooks con bases grandes
- **Qué pasa:** `inputs/repositorio_controles/alm/supervivencia_km.py` recorre cada tiempo de evento contra
  toda la base (orden N × T); los pivotes por cosecha y `saltos_serie` cargan todo en memoria.
- **Cómo:** Kaplan–Meier vectorizado (`groupby` por tiempo y `cumsum` inverso de los en riesgo), lectura por
  columnas (`usecols`) y por periodo, y un parámetro explícito de muestreo para explorar.
- **Verificar:** mismo resultado que hoy en los tests y un caso sintético de 1 millón de cuentas en segundos.

### 10. Resumen de la validación completa en el cuerpo del informe
- **Qué pasa:** `web/services/informe_web.py::_sustento_completa` lo lleva a un anexo; el cuerpo
  (Información relevante, Cuadro resumen) no dice qué etapas se hicieron ni cuántos hallazgos críticos dejaron.
- **Cómo:** un párrafo y una tabla corta en «IV. Información relevante» con etapas, iteraciones, hallazgos
  abiertos por severidad y la fecha de la publicación al 08 (`publicado.json`).
- **Verificar:** test del informe en modalidad completa.

### 11. Progreso de las etapas en «Mis modelos»
- **Qué pasa:** la lista muestra la modalidad pero no cuántas etapas están cerradas.
- **Cómo:** columna «Etapas 3/5» desde `resumen_etapas` (solo lectura).
- **Verificar:** test del endpoint de modelos y revisión en la web de prueba.

### 12. Run-off: incertidumbre, estacionalidad y estrés
- **Qué pasa:** la réplica (`modulos/libreria_cuant.py::replicar_runoff`) da una curva puntual; no hay banda
  de confianza ni ajuste por estacionalidad (CTS, gratificaciones) ni un estrés del componente estable.
- **Cómo:** bootstrap por cosecha para la banda de S(t); meses marcados como estacionales en `SUPUESTOS`;
  sensibilidad del estable a ±X pp en la etapa 03.
- **Verificar:** tests con la historia sintética (`tests/_sinteticos_tipos.py::runoff_bases`).

---

## P2 — Mantenimiento

### 13. `.gitattributes` para los finales de línea
- **Qué pasa:** no existe; `.env.example`, `config/__init__.py`, `config/modelos.py`, `motor/Mx_00` a `Mx_03`
  y `tests/test_azure_mocks.py` son CRLF (`Mx_04` es LF) y el resto LF. Un editor o un script los convierte
  sin querer, y la regla escrita («motor/*.py») ya inducía a error.
- **Cómo:** declarar `eol=crlf` para esos y `eol=lf` para el resto; renormalizar en un commit aparte.
- **Verificar:** `git ls-files --eol` coherente; ningún diff de solo finales de línea.

### 14. Consolidar la documentación
- **Qué pasa:** hay 65 documentos Markdown (lista en `docs/MAPA_HERRAMIENTA.md` §17), varios superpuestos o
  viejos: cinco `PROMPT_CONTINUIDAD_*.md`, `HANDOFF_AGENTE.md` (04-nov), `QUE_HACE_REALMENTE.md` (agosto),
  `FUNCIONALIDADES.md` (verificado en julio), `ROADMAP_v28.md`.
- **Cómo:** una entrada única (`README.md` → `docs/MAPA_HERRAMIENTA.md`, `GUIA_USO.md`,
  `GUIA_TRASPASO_CONTEXTO.md`, esta guía y la de errores) y el resto a `docs/historico/` con una línea de
  por qué quedó ahí.
- **Verificar:** ningún enlace roto (los tests de documentación) y el mapa regenerado.

### 15. Regenerar el paquete del agente corporativo
- **Qué pasa:** `docs/agente_corporativo/GUIA_VIRF_AGENTE_CORPORATIVO.docx/.pdf` y
  `GUIA_VIRF_PRESENTACION.pptx` son de noviembre temprano: no traen la validación completa ni los tipos de
  modelo (las skills `S13` y `S14` nuevas sí).
- **Cómo:** `scripts/generar_guia_agente.py --pdf` y `scripts/generar_presentacion_guia.py` (este último,
  ampliado con las pantallas nuevas en el trabajo de presentaciones).
- **Verificar:** abrir los archivos generados; la fecha de portada.

### 16. Generadores sintéticos fuera de `tests/`
- **Qué pasa:** `scripts/demo_runoff.py` importa `tests/_sinteticos_tipos.py`: un script de uso depende de
  la carpeta de pruebas.
- **Cómo:** mover los generadores a un módulo (p. ej. `modulos/sinteticos.py`) que importen ambos.
- **Verificar:** tests y la demo siguen corriendo.

### 17. Separar las pruebas lentas
- **Qué pasa:** la suite tarda ~8 minutos (≈ 2 000 pruebas) porque varias ejecutan notebooks reales; no hay
  `pytest-timeout`.
- **Cómo:** marca `@pytest.mark.lento` en las que ejecutan notebooks y un perfil rápido por defecto; un tope
  de tiempo por prueba.
- **Verificar:** perfil rápido en menos de 2 minutos; la suite completa igual que hoy.

### 18. Skill de frontend mal ubicada
- **Qué pasa:** `.claude/skill/frontend_desing/SKILL_frontend.md` no está en la ruta que lee Claude Code
  (`.claude/skills/<nombre>/SKILL.md`) y el nombre tiene una errata.
- **Cómo:** moverla a `.claude/skills/diseno-frontend/SKILL.md` con su frontmatter, si se quiere usar.

### 19. Dependencias
- **Qué pasa:** pandas 2.1 y Python 3.10; el bug de fechas ISO con `dayfirst` ya obligó a un rodeo
  (`_fechas`).
- **Cómo:** plan de actualización con `pip-audit`, pins `==` y la suite completa como red.

---

## Cómo trabajar una mejora (receta)

1. Releer la sección y el archivo citado; confirmar que el problema sigue (a veces ya se arregló).
2. Escribir primero el test que lo demuestra (coste cero, IA simulada).
3. Cambiar lo mínimo, respetando las reglas (`.venv`, sin `.env`, finales de línea, sin detección automática).
4. Regenerar guías y mapa si cambió algo que describen (`scripts/generar_*.py`).
5. Tests del área, `validate_project.py --strict` y la suite completa en segundo plano.
6. Actualizar esta guía: marcar el punto como hecho con la fecha y el commit.
