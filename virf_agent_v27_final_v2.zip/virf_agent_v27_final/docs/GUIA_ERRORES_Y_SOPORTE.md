# Guía de errores y soporte: qué revisar cuando algo sale mal

> Para el validador y para quien da soporte a VIRF. Está ordenada por **dónde** aparece el problema.
> Complementa la tabla «Errores frecuentes» de `GUIA_TRASPASO_CONTEXTO.md` §17 (pipeline, proveedor de IA
> y RAG) y la skill `S01_diagnosticar_fallo.md` del paquete corporativo. La lista **exacta** de mensajes
> que devuelve la web, con su archivo y su función, está en `docs/MAPA_HERRAMIENTA.md` §12 (generada).

## Índice

0. [Protocolo en seis pasos](#0-protocolo-en-seis-pasos)
1. [Entorno y arranque](#1-entorno-y-arranque)
2. [La web: qué significa cada código](#2-la-web-qué-significa-cada-código)
3. [Validación completa (etapas 00–04)](#3-validación-completa-etapas-0004)
4. [Notebook de calidad de datos y repositorio](#4-notebook-de-calidad-de-datos-y-repositorio)
5. [08 · Validar modelo](#5-08--validar-modelo)
6. [09 · Revisión con el agente](#6-09--revisión-con-el-agente)
7. [10 · Documentar](#7-10--documentar)
8. [Pruebas, guías y finales de línea](#8-pruebas-guías-y-finales-de-línea)
9. [Lo que nunca se hace para «arreglar» algo](#9-lo-que-nunca-se-hace-para-arreglar-algo)
10. [Cómo pedir ayuda](#10-cómo-pedir-ayuda)

---

## 0. Protocolo en seis pasos

Sirve para cualquier error, antes de tocar nada:

1. **Copia el mensaje exacto y dónde ocurrió.** Pantalla y paso (01–10), etapa e iteración (ITERn) si es
   la validación completa, o el comando si fue la CLI. «No funciona» no se puede diagnosticar.
2. **Ubica la capa.** Pantalla o código HTTP → web (§2). Celda de un notebook → corre en **tu** equipo,
   no en el servidor (§3–§4). Corrida del 08 → pipeline (§5). Chat → §6. Word → §7. Test en rojo → §8.
3. **Mira el rastro, no la intuición.**

   | Dónde | Rastro |
   |---|---|
   | Web | El detalle del error en pantalla; la consola del navegador (F12); la consola del servidor |
   | 08 · corrida | `web/data/sesiones/<validador>/<modelo>/outputs/corridas/<run_id>.log` (se descarga desde la pantalla) y el motivo y la pista que muestra el 08 |
   | Notebook | El traceback de la celda; la hoja «Indice» del Excel de resultados dice qué tablas se registraron |
   | Chat 09 | `chat_historial.json` de la sesión (mensajes y decisiones con `decidido_por`) |
   | Llamadas a la IA | `audit_logs/auditoria_acciones.jsonl` (coste, tiempo, proveedor) |

4. **Reproduce con coste cero.** Tests del área (§8), `validate_project.py --strict` y, para notebooks,
   `MODO_DEMO = True` o la demo `scripts/demo_runoff.py`. Nunca se prueba llamando a la IA real.
5. **Corrige en la fuente.** El código, la ficha, el Excel de entrada o la configuración. Nunca a mano en
   `outputs/`, `feedback/` ni `audit_logs/`: son evidencia y registros sellados.
6. **Verifica y deja constancia.** Tests en verde, guías regeneradas, finales de línea iguales a `HEAD` y
   una línea de qué causó el error.

---

## 1. Entorno y arranque

| Síntoma | Causa probable | Qué revisar | Solución |
|---|---|---|---|
| `import chromadb`, `torch` u `onnxruntime` revientan; `ModuleNotFoundError` raros | Se usó el Python del sistema | `python -c "import sys; print(sys.prefix)"` | Siempre `.venv\Scripts\python` |
| `UnicodeEncodeError: 'charmap'` al imprimir | Consola en cp1252 | — | `$env:PYTHONUTF8=1` (PowerShell) antes de correr |
| La web no arranca: puerto en uso | Ya hay otra instancia | `netstat -ano \| findstr :8000` | Otro puerto (`scripts/web_prueba.py --puerto 8010`) o cerrar la otra |
| Login 503 | Entra ID sin configurar | Variables de Entra ID | Esperado sin registro: web de prueba con usuario libre (solo fuera de producción) |
| Tras reiniciar el servidor de prueba todos salen al login (401) | Las claves de sesión de la web de prueba son efímeras | — | Volver a entrar; es lo esperado |
| Un cambio de Python no se ve en la web | uvicorn corre sin `--reload` | Hora de arranque del servidor | Reiniciar el servidor |
| Un cambio de JS/CSS no se ve | Caché del navegador (la versión de los assets se calcula al arrancar) | — | Reiniciar el servidor y recargar con Ctrl+F5 |
| `DeploymentNotFound`, `ProveedorNoAutorizado`, error de `max_tokens` | Proveedor o deployment | `config/ia.py`, `AZURE_OPENAI_DEPLOYMENT` | Ver `GUIA_TRASPASO_CONTEXTO.md` §17 (no tocar `PROVEEDORES`) |

---

## 2. La web: qué significa cada código

| Código | Qué significa en VIRF | Qué hacer |
|---|---|---|
| **400** | Entrada inválida: falta la **clasificación** obligatoria de un archivo, formato no admitido, nombre de archivo raro, parámetro mal escrito, Excel de MODO_DEMO enviado a la validación, archivo demasiado grande en las etapas (25 MB) o en el Excel de resultados del notebook (20 MB) | Leer el detalle: casi siempre dice qué campo o archivo corregir |
| **401** | Sesión caducada o sin entrar | Volver a entrar |
| **403** | Tu rol no permite la acción (`validar`, `revisor`, `admin_corpus`) o quieres aprobar tu propia lección | Pedir el rol; otra persona aprueba lo que tú enseñaste |
| **404** | No existe: etapa, archivo, corrida, modelo | Refrescar la pantalla; revisar el nombre |
| **409** | El estado no lo permite (ver abajo) | Hacer el paso que falta |
| **413** | El ZIP del código (03 · Evidencia) descomprimido es demasiado grande o tiene demasiados archivos | Quitar dependencias (`.venv`, `site-packages`) y datos del ZIP |
| **500 / 502 / 503 / 504** | Fallo interno (500), de la IA (502), configuración ausente (503) o tiempo agotado (504) | Consola del servidor y log; con la IA, reintentar y revisar el proveedor |

Los **409** más comunes:

| Mensaje (comienzo) | Qué falta |
|---|---|
| «Este modelo no tiene evidencia…» | Subir manuales, código o datos en **03 · Evidencia** |
| «Validación completa: antes del barrido de controles cierra las etapas…» | Cerrar las etapas que nombra (si una no aplica, cerrarla con ese motivo) |
| «Este modelo está en Validación normal…» | Cambiar la modalidad a completa (botón de modalidad) |
| «ya hay una corrida activa…» | Esperar a que termine o cancelarla |
| «no hay un modelo activo…» | Entrar a un modelo antes de guardar su configuración |
| «VIRF PLUS bloqueado hasta aprobación del proveedor…» | Decisión del banco: Claude sigue en espera |
| «no se puede eliminar '<dominio>': lo usan N modelo(s)…» | Cambiar antes el dominio de esos modelos |
| «ya existe un cuestionamiento con id=…» | Usar otro id |

---

## 3. Validación completa (etapas 00–04)

| Síntoma | Causa probable | Qué revisar | Solución |
|---|---|---|---|
| «Para el primer notebook indica las rutas de datos o envía evidencias» | ITER0 sin rutas ni archivos | El cuadro de rutas de la etapa | Escribir `nombre = ruta` por línea o adjuntar insumos |
| «formato no admitido: …» | Extensión fuera de la lista | El mensaje lista las admitidas | Convertir (p. ej. a `.xlsx` o `.csv`) |
| «… supera 25 MB» | Archivo grande | — | Dividir o enviar la ruta de datos en vez del archivo |
| El notebook falla con `FileNotFoundError` en tu equipo | Las rutas de `RUTAS` (primera celda) no existen en tu máquina | La celda de rutas | Corregir la ruta y re-ejecutar; el notebook corre en tu equipo, no en el servidor |
| Muchos controles «Pendiente» | Rol de negocio sin columna enlazada | Hoja «Roles» y celda 3b (`BASES`/`ROLES`) | Enlazar la columna en `ROLES`; los pendientes no cuentan en el % |
| Fechas al revés | Formato ambiguo (dd/mm vs mm/dd) | La columna en el CSV | ISO (`AAAA-MM-DD`) siempre se lee bien; el resto se lee día/mes/año |
| La etapa no se puede cerrar | «No se puede cerrar una etapa sin iteraciones» | Historial de la etapa | Hacer al menos una iteración |
| El agente nunca dice «lista» | Pasos de la ruta pendientes | La ruta en la cabecera de la etapa | Cubrir los «## Paso XX.n» que faltan o declararlos «no aplica» con motivo |
| El consolidado avisa inconsistencias | El Excel y el .md de hallazgos de una etapa no coinciden | Hoja «Inconsistencias» | Corregir el Excel (manda) u otra iteración |
| El panel del 08 no lleva el Excel de una etapa | El Excel devuelto no se llama `<etapa>_resultadoITERn.xlsx` | El nombre del archivo que enviaste | Enviar el Excel tal como lo genera el notebook (solo esos viajan, nunca los datos) |
| «Calidad de datos» no puntúa los controles del 01 | La primera hoja del Excel no es «Controles» o le faltan columnas | `calidad_datos/resultadocalidad_de_datos/completa_01_ControlDatos.xlsx` tras lanzar | Usar el Excel que genera el notebook del 01 sin reordenar hojas |
| Controles de datos contados dos veces | Además se usó «Usar estos resultados en la validación» con el mismo notebook | `calidad_datos/resultadocalidad_de_datos/` | Dejar una sola tabla de esos resultados |

---

## 4. Notebook de calidad de datos y repositorio

| Síntoma | Causa probable | Solución |
|---|---|---|
| «este Excel salió del MODO_DEMO…» (400) | `MODO_DEMO = True` usa datos sintéticos | Ejecutar con `MODO_DEMO = False` sobre tus bases |
| Muchos «No evaluable» | Columnas que no existen o no se enlazaron | Hoja «Mapeo»/«Roles» y `PARAMS_Dxx` del control |
| Un análisis `D` queda en «Revisión manual» | Le falta la base de contraste (`dataset_curva`, `dataset_tasas`…) | Con tipo de modelo se enlaza solo; si no, completarlo en `PARAMS_Dxx` |
| Un rango o una suma «no cumple» siendo correcto | Escala 0–1 frente a % | Las proporciones se detectan por su p75; si la columna mezcla escalas, normalizarla |
| Saltos «falsos» en un panel por cosechas | El desgaste natural de los primeros meses parece un salto dentro de cada cosecha | `saltos_serie` con `agregar="suma"` (total del segmento) y el análisis `runoff_saltos_cosechas` |
| Conciliación «sin pareja» contra un balance con historia | Se comparan todas las fechas del balance | `conciliacion_por_grupo` con `pareja="base"` |
| Run-off: la curva del modelo difiere de la histórica en todos los plazos | Curva de cosechas comparada con la del saldo existente (o al revés) | Revisar `SUPUESTOS["curva_de"]` antes de concluir |
| Notebook lento o sin memoria con bases grandes | Kaplan–Meier y pivotes por cosecha recorren todo | Filtrar por periodo o muestrear para explorar (mejora pendiente en `docs/GUIA_MEJORAS.md`) |
| Mi control propio no aparece | No está en la carpeta del dominio o su `META["tipos"]` no incluye el tipo del modelo | Revisar carpeta y `META`; volver a descargar el notebook |

---

## 5. 08 · Validar modelo

| Síntoma | Causa probable | Solución |
|---|---|---|
| Termina en error con motivo y pista | Ver el motivo | Leer el log de la corrida y la tabla §17 de la guía de traspaso |
| Un ámbito «sin evidencia» | Falta su carpeta en `inputs/` | Subir evidencia (03) o cerrar las etapas de la completa |
| Cobertura documental baja | Documentos recortados (`MAX_CHARS_DOC`, `MAX_FILAS_EXCEL`) | El log declara «RECORTADO»; resumir o dividir la evidencia |
| Quiero saber cuánto costará | — | `agente.py … --dry-run` (coste cero) |
| El botón «Lanzar» está deshabilitado en modalidad completa | Hay etapas abiertas | El panel del 08 dice cuáles |

---

## 6. 09 · Revisión con el agente

| Síntoma | Causa probable | Solución |
|---|---|---|
| No acepta «ok» o «ya está» | Subsanar sube el puntaje: exige motivo concreto | `subsanada: <qué cambió y dónde>` o adjuntar la evidencia (📎) |
| Un APROBADO pasa a PENDIENTE con «Verificación automática» | El modelo citó algo que no está en la evidencia | Aportar la evidencia o decidir con los comandos |
| No menciona la validación completa | El modelo no es de modalidad completa, o el ámbito del estándar tiene otro nombre | Revisar la modalidad; ámbitos reconocidos en `ETAPAS_POR_AMBITO` |
| «No pude consultar al modelo…» | Fallo técnico de la IA (no decide nada) | Reintentar o decidir con **confirmar**, **subsanada:**, **no aplica:**, **pendiente:** |
| Probar el chat sin gastar | — | `VIRF_MOCK_CHAT=1` en el entorno del servidor |

---

## 7. 10 · Documentar

| Síntoma | Causa probable | Solución |
|---|---|---|
| Falta el anexo de la validación completa | El modelo no está en modalidad completa o no hay iteraciones | Revisar la modalidad y las etapas |
| Faltan imágenes de sustento | No se enviaron en las iteraciones | Enviarlas en la etapa correspondiente |
| Un texto fijo del informe cambió y un test falla | `tests/test_informe_tabla_final.py` fija textos regulatorios | No cambiar esos textos sin decisión de validación |
| La calificación no es la esperada | Regla única en `modulos/reglas_informe.py` | Skill `S03_regla_calificacion.md` |

---

## 8. Pruebas, guías y finales de línea

| Síntoma | Causa | Solución |
|---|---|---|
| `test_inventario_cubre_cada_llamante_de_ia` en rojo | Faltan filas en `docs/seguridad/GOBIERNO_RIESGO_IA.md` | **Conocido**: las filas las decide el responsable; no es un fallo nuevo |
| `test_guias_generadas` o `test_mapa_herramienta` en rojo | Cambió el código y no se regeneró | `scripts/generar_guia_uso.py`, `generar_guia_calidad_datos.py`, `generar_guia_tipos_modelo.py`, `generar_mapa_herramienta.py` |
| `test_rag_banco` en rojo tras tocar el catálogo de controles | Corpus del banco viejo | `scripts/generar_corpus_banco.py --reindexar` (sin dueño ni vigencia: los decide el responsable) |
| La suite tarda mucho | Ejecuta notebooks reales | Tests del área (abajo) y la suite completa en segundo plano |
| Un archivo aparece entero en el diff sin cambios lógicos | Se convirtió CRLF ↔ LF | `.env.example`, `config/__init__.py`, `config/modelos.py`, `motor/Mx_00` a `Mx_03` y `tests/test_azure_mocks.py` son CRLF (`Mx_04` es LF); el resto LF. Restaurar el final de línea de `HEAD` |
| `validate_project.py --strict` con un WARN «fuera del patrón de fecha» | Una carpeta en `outputs/` sin fecha | Todo cuelga de `outputs/AAAA-MM-DD/` |

Tests por área (siempre `PYTHONUTF8=1` y `.venv\Scripts\python -m pytest -q -p no:cacheprovider`):

| Área | Archivos |
|---|---|
| Validación completa y puente al 08 | `tests/test_validacion_completa.py`, `tests/test_hallazgos_completa.py` |
| Tipos de modelo, notebooks, run-off | `tests/test_tipos_modelo.py`, `tests/test_controles_bateria_tipo_modelo.py` |
| Controles de datos y aprendizaje | `tests/test_controles_ia.py`, `tests/test_notebook_controles.py`, `tests/test_aprendizaje_controles.py` |
| Chat 09 | `tests/test_revision_sesion.py`, `tests/test_chat_controles.py`, `tests/test_prompts_editables.py` |
| Guías y mapa | `tests/test_guias_generadas.py`, `tests/test_mapa_herramienta.py` |
| Proyecto entero | `validate_project.py --strict` (0 FAIL) y la suite completa en segundo plano |

---

## 9. Lo que nunca se hace para «arreglar» algo

- Editar `.env` o pegar claves en archivos: las claves van en Key Vault o en el entorno del proceso.
- Cambiar `PROVEEDORES` en `config/ia.py`, apagar salvaguardas (PII, anti-inyección, entailment) o forzar
  un proveedor «por si acaso».
- Borrar o editar `audit_logs/`, `feedback/` o los resultados de una corrida.
- `git reset`, `checkout`, `stash` o `clean` sobre el árbol de trabajo (hay mucho trabajo sin commitear).
- Lanzar POST contra la web en marcha «para ver qué pasa» (escriben en rutas globales).
- Ejecutar los notebooks de VIRF en el servidor, o usar `exec`/`eval` en el código de producción.
- Llamar a la IA real para probar código.
- Añadir filas al inventario de gobierno de IA sin la decisión del responsable.

---

## 10. Cómo pedir ayuda

```
Qué intentaba: <paso, etapa, ITER o comando>
Qué pasó: <mensaje exacto; captura si es pantalla>
Dónde: <modelo, validador, run_id si es el 08>
Rastro: <log de la corrida, traceback de la celda o consola del servidor>
Qué ya probé: <tests corridos, cambios hechos>
```

Para un asistente de IA, usa `PROMPT_OTRO_ASISTENTE.md`; en Claude Code, la skill del proyecto
`soporte-virf` se activa sola al describir el problema.
