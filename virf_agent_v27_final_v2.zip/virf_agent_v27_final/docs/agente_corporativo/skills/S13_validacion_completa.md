---
name: S13-validacion-completa
description: Validación completa (etapas 00 Diagnóstico · 01 Control de datos · 02 Modelamiento · 03 Impactos · 04 Seguimiento), sus notebooks iterados, el cierre de etapas, el consolidado de hallazgos y el puente que lleva todo al 08 Validar, 09 Revisión y 10 Documentar.
---

# S13 — Validación completa y puente a la validación final

## Cuándo usarla
- Una etapa 00–04 no genera su notebook, el notebook falla en el equipo del validador o el Excel de vuelta
  no se lee.
- Una etapa no se puede cerrar, el agente no da la etapa por «lista» o el consolidado avisa inconsistencias.
- El 08 no se deja lanzar en un modelo de modalidad completa, o no lleva el trabajo de alguna etapa.
- El chat 09 no menciona los hallazgos de las etapas, o el informe no trae el anexo.

## Cómo funciona
- **Modalidad explícita** en la ficha del modelo (`normal` | `completa`); nunca se deduce.
- **Cada etapa itera:** el agente entrega `{etapa}ITERn.ipynb` → el validador lo ejecuta **en su equipo**
  (donde están los datos) → devuelve `{etapa}_resultadoITERn.xlsx` con comentarios e imágenes → ITERn+1.
  Lógica: `modulos/validacion_completa.py` (`ejecutar_iteracion`, `cerrar_etapa`, `estado_etapa`).
- **Experto y ruta por etapa:** `modulos/plantillas_etapa.py` (`EXPERTOS`, `RUTAS`, plantillas por tipo de
  modelo: réplica 02, impactos 03 con correcciones automáticas, backtesting 04) + librería
  `modulos/libreria_cuant.py` embebida en el notebook. La ruta se verifica contra los títulos
  «## Paso XX.n» (`normalizar_ruta`); sin pasos cubiertos no hay veredicto «lista».
- **Hallazgos:** cada iteración reescribe `<etapa>_HALLAZGOS.xlsx/.md`; «Consolidar» los lee y escribe
  `<sesión>/outputs/validacion_completa/_consolidado/HALLAZGOS_VALIDACION_COMPLETA.xlsx/.md`
  (`modulos/hallazgos_completa.py`).
- **Puente al 08:** `POST /api/validar/lanzar` (`web/routers/validacion.py`) responde 409 si falta cerrar
  alguna etapa; con las cinco cerradas, `publicar_en_validacion` copia **solo entregables de VIRF** a la
  evidencia por ámbito (`<sesión>/inputs/documentacion/{modelamiento,seguimiento}/validacion_completa/`,
  `<sesión>/inputs/calidad_datos/validacion_completa/`) y el Excel del 01 a
  `<sesión>/inputs/calidad_datos/resultadocalidad_de_datos/completa_01_ControlDatos.xlsx`, que el ámbito
  «Calidad de datos» puntúa. `GET /api/completa/paquete` lo enseña sin escribir.
- **Chat 09:** placeholder `{validacion_completa}` del prompt (`web/services/chat_service.py`, sincronizado
  con `web/data/prompts_base.json`) con los hallazgos de las etapas del ámbito (`ETAPAS_POR_AMBITO`).
- **Web:** `web/routers/validacion_completa.py` (`/api/completa/*`) y `web/static/js/completa.js`.

## Qué subir (máx. 20)
`CONOCIMIENTO_VIRF.md`, esta skill y, según el caso:
- Notebook o iteración: `modulos/validacion_completa.py`, `modulos/plantillas_etapa.py`,
  `web/routers/validacion_completa.py`, `tests/test_validacion_completa.py` y el traceback de la celda.
- Réplica, impactos o backtesting de un tipo: además `modulos/libreria_cuant.py` y la ficha del tipo (S14).
- Hallazgos o consolidado: `modulos/hallazgos_completa.py`, `tests/test_hallazgos_completa.py`, el
  `<etapa>_HALLAZGOS.xlsx` afectado.
- Puente 08/09: `web/routers/validacion.py`, `web/services/chat_service.py`, `web/data/prompts_base.json`,
  `web/static/js/completa.js`, `web/static/js/app.js`.

## Qué puede devolver (máx. 5)
El módulo afectado, su router o JS y su test. Si toca el prompt del chat: `chat_service.py` **y**
`prompts_base.json` en el mismo pedido (deben quedar idénticos).

## Pasos
1. Reproducir con IA simulada: `ejecutar_iteracion(..., usar_ia=False)` en carpetas temporales.
2. Corregir; si cambia lo que viaja al 08, actualizar también el panel del 08 (`vcPintarPaqueteValidar`).
3. Regenerar `GUIA_USO.md` y `docs/MAPA_HERRAMIENTA.md` (describen las etapas y el puente).

## Reglas que no se pueden romper
- Los notebooks corren en el equipo del validador, **nunca** en el servidor; sin `exec`/`eval` en producción
  (la sintaxis se valida con `ast.parse`).
- Al 08 solo viajan entregables de VIRF, nunca los datos que el validador envió a los chats.
- El 08 no se lanza con etapas abiertas; quien cierra una etapa es el validador (el agente recomienda).
- La modalidad y el tipo de modelo son explícitos (sin detección automática).

## Cómo verificar
```
.venv\Scripts\python.exe -m pytest tests/test_validacion_completa.py tests/test_hallazgos_completa.py -q
.venv\Scripts\python.exe -m pytest tests/test_revision_sesion.py tests/test_prompts_editables.py -q
.venv\Scripts\python.exe scripts\generar_mapa_herramienta.py --comprobar
```
