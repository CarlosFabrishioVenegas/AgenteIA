---
name: S14-tipos-de-modelo-y-notebook
description: Tipos de modelo (19 fichas de negocio con roles), el notebook de calidad de datos por capas (C, BD, M, D, IA, aprendidos), el catálogo de 44 tipos de control, el repositorio por dominio con META["tipos"] y el modelo de run-off (supervivencia del saldo).
---

# S14 — Tipos de modelo, notebook de calidad y repositorio

## Cuándo usarla
- Añadir o ajustar un tipo de modelo, un control de negocio o un rol (concepto → columna).
- Un control sale «Pendiente», «No evaluable» o «Revisión manual» en el notebook.
- Un análisis del repositorio no entra en el notebook de un tipo, o entra donde no debe.
- Cambiar la réplica, los impactos o el backtesting de un tipo (con S13).

## Cómo funciona
- **Fichas:** `modulos/tipos_modelo_trading.py`, `_alm.py`, `_liquidez.py` (19 tipos). Cada una: bases
  lógicas con **roles** de negocio, controles `_c(base, tipo, roles, qué, por qué, criticidad, params)`,
  riesgos, preguntas a la primera línea, pasos por etapa y métricas. El tipo se elige explícito en la ficha
  del modelo (`tipos_modelo`).
- **Roles y enlace:** `modulos/tipos_modelo.py` (`ROLES` = concepto → patrón de columna + familia de dato;
  `enlazar`; `controles_negocio`). Sin columna para un rol, el control queda «Pendiente» y no cuenta.
- **Notebook por capas:** C batería general, BD batería dinámica (llaves entre bases), M controles de la
  ficha, D repositorio del dominio, IA propuestos y validados, aprendidos (aprobados por un revisor), X/P del
  validador. Construcción: `modulos/controles_ia.py` (`construir_notebook`, `CATALOGO` de 44 tipos con su
  función, `ejecutar_rol`); endpoints en `web/routers/controles.py`.
- **Repositorio:** `inputs/repositorio_controles/<var|alm|lar|shared>/*.py` con `META` literal (leído con
  `ast`) y `control(df, datasets, params)`. `META["tipos"]` decide en qué tipos entra; los `campo_*` se
  enlazan con columnas y los `dataset_<base>` con la base que enlazó el tipo.
- **Run-off** (ALM): supervivencia del saldo. Curva S(t), R = 1 − S, d = S(t−1) − S(t), estable/volátil,
  plazo económico ∫S y bandas. Repositorio `inputs/repositorio_controles/alm/runoff_curvas.py`,
  `runoff_supervivencia_saldos.py`, `runoff_saltos_cosechas.py`; librería `modulos/libreria_cuant.py`;
  `SUPUESTOS["curva_de"]` explícito
  (`cosecha` | `saldo_existente`). Las tasas de salida en estrés son del tipo `stress_liquidez`.

## Qué subir (máx. 20)
`CONOCIMIENTO_VIRF.md`, esta skill y, según el caso:
- Ficha o rol: el `tipos_modelo_<familia>.py`, `modulos/tipos_modelo.py`, `tests/test_tipos_modelo.py`,
  `tests/_sinteticos_tipos.py`.
- Tipo de control del catálogo: `modulos/controles_ia.py` (catálogo, validación de parámetros y función),
  `tests/test_tipos_modelo.py`, `tests/test_controles_ia.py`.
- Análisis del repositorio: el `.py` del control, `modulos/repositorio_controles.py`, `tests/test_tipos_modelo.py`.
- Un CSV sintético pequeño (sin datos reales).

## Qué puede devolver (máx. 5)
La ficha o el control, su test y, si cambia un tipo del catálogo, `controles_ia.py`. Después hay que
regenerar guías (paso 4): si no cabe en el pedido, partirlo en dos.

## Pasos
1. Control de negocio: una línea `_c(...)` en la ficha con su **por qué** (sin código nuevo).
2. Análisis nuevo: copiar uno del mismo dominio, `META` literal con `tipos` y `params`, y `control(...)`
   determinista que devuelva `{pct, decision, diagnostico}`.
3. Probar con datos sintéticos con fallas sembradas (deben aparecer) y sin fallas (deben cumplir).
4. Regenerar: `generar_guia_tipos_modelo.py`, `generar_guia_calidad_datos.py`, `generar_guia_uso.py`,
   `generar_mapa_herramienta.py`; si cambió el catálogo, `generar_corpus_banco.py --reindexar`.

## Reglas que no se pueden romper
- Los controles son deterministas: la IA no calcula resultados.
- `META` es un literal; el repositorio se lee con `ast`, nunca se ejecuta al listarlo.
- El tipo de modelo es explícito; un rol sin columna queda «Pendiente», no se inventa.
- Sin datos personales reales en tests ni ejemplos.

## Cómo verificar
```
.venv\Scripts\python.exe -m pytest tests/test_tipos_modelo.py tests/test_controles_ia.py tests/test_guias_generadas.py -q
.venv\Scripts\python.exe scripts\demo_runoff.py      # ruta 00→04 de un run-off, sin IA
```
