# Guía de tipos de modelo y de la ruta de la validación completa

> Generada desde el código por `scripts/generar_guia_tipos_modelo.py`: no la edites a mano (regénérala). Para añadir un tipo de modelo, edita su ficha en `modulos/tipos_modelo_<familia>.py`.

## Contenido

1. Qué es el tipo de modelo y dónde se usa
2. La ruta paso a paso de cada etapa (00–04)
3. Los tipos de modelo, uno por uno
4. Roles (conceptos de negocio) y cómo se enlazan
5. Librería cuantitativa de los notebooks de las etapas
6. Cómo añadir un tipo de modelo

## 1. Qué es el tipo de modelo y dónde se usa

El **dominio** (VaR · ALM · LaR) dice la familia; el **tipo de modelo** dice qué hace el modelo y, por tanto, qué hay que revisar: un VaR no se valida como un run-off, ni un prepago como un LCR. Lo elige el validador en la ficha del modelo (**Nuevo modelo** o **Configuración → Tipo de modelo**; se pueden elegir varios) y **nunca se deduce** de los datos. Con él:

* el **notebook de calidad de datos** (validación normal y etapa 01) trae *Entender el modelo* (negocio, bases, qué puede fallar, qué pedir a la primera línea), los **controles de negocio por roles** (`M…`) y solo los análisis del repositorio de ese tipo;
* los **5 chats de la validación completa** reciben la ficha del tipo y los pasos de experto de su etapa; sin IA, la plantilla de cada etapa **replica** (02), **cuantifica** (03) y **hace backtesting** (04) según el tipo.

Hay **19 tipos** en tres familias, con **222 controles de negocio** y **100 roles**.

| Tipo | Familia | Carpeta del repositorio | Bases lógicas | Controles de negocio |
|---|---|---|---|---|
| **VaR de mercado (simulación histórica, paramétrico o Monte Carlo)** (`var`) | Trading | `var/` | posiciones, factores, pyg, escenarios_pnl, var_reportado, covarianzas, contabilidad | 35 |
| **Expected Shortfall / FRTB (modelo interno IMA)** (`es_frtb`) | Trading | `var/` | pyg, es_reportado, observaciones, horizontes | 14 |
| **Pruebas de estrés de mercado (históricas, hipotéticas e inversas)** (`stress_mercado`) | Trading | `var/` | escenarios, posiciones, resultados | 6 |
| **Valoración de instrumentos y derivados (con verificación independiente de precios)** (`valoracion`) | Trading | `var/` | operaciones, precios | 8 |
| **Curvas de tasas y superficies de volatilidad (datos de mercado)** (`curvas`) | Trading | `var/` | curvas, volatilidades | 8 |
| **Riesgo de contraparte (exposición, EAD SA-CCR, CVA)** (`contraparte`) | Trading | `var/` | operaciones, colateral, exposiciones | 7 |
| **ALM · IRRBB: EVE y NII (gap de reprecio)** (`irrbb`) | ALM | `alm/` | posiciones, flujos, escenarios, resultados, contabilidad | 26 |
| **Prepago de créditos (modelo conductual de prepago, MCP)** (`prepago`) | ALM | `alm/` | saldos, operaciones, modelo | 14 |
| **Depósitos sin vencimiento (NMD): núcleo, decaimiento y beta** (`nmd`) | ALM | `alm/` | saldos, cuentas, modelo | 16 |
| **Cancelación anticipada y renovación de depósitos a plazo** (`cancelacion_dpf`) | ALM | `alm/` | depositos, tasas | 8 |
| **Supervivencia / retiro de cuentas y saldos (MCR)** (`supervivencia`) | ALM | `alm/` | cuentas, curva | 7 |
| **Precios de transferencia de fondos (FTP)** (`ftp`) | ALM | `alm/` | operaciones, curva_ftp | 4 |
| **Run-off: supervivencia y desgaste del saldo (vencimiento conductual)** (`runoff`) | ALM | `alm/` | saldos, cuentas, curva, componentes, bandas, contabilidad | 31 |
| **Ratio de cobertura de liquidez (RCL / LCR)** (`lcr`) | Liquidez | `lar/` | hqla, salidas, entradas, ratio | 11 |
| **Ratio de financiamiento neto estable (RFNE / NSFR)** (`nsfr`) | Liquidez | `lar/` | asf, rsf, ratio, contabilidad | 7 |
| **Brechas (gaps) de liquidez contractuales y conductuales** (`brechas_liquidez`) | Liquidez | `lar/` | flujos, contabilidad | 7 |
| **Liquidity at Risk (LaR, VaR de liquidez)** (`lar`) | Liquidez | `lar/` | flujos, resultado | 5 |
| **Estrés de liquidez y horizonte de supervivencia** (`stress_liquidez`) | Liquidez | `lar/` | proyeccion | 4 |
| **Concentración de fondeo y principales depositantes** (`concentracion_fondeo`) | Liquidez | `lar/` | depositantes | 4 |

## 2. La ruta paso a paso de cada etapa (00–04)

Cada chat de la validación completa recorre su **ruta**. El agente declara el estado de cada paso (cubierto · parcial · pendiente · no aplica, con motivo) y **VIRF lo verifica**: un paso «cubierto» cuyo título «## Paso XX.n» no está en el notebook pasa a «pendiente», y la etapa no puede quedar «lista» con pasos pendientes. La web muestra la ruta con el estado de la última iteración.

### 00 · Diagnóstico

**Experto:** Arquitecto de datos de riesgo (BCBS 239): conoce el linaje de cada base del modelo, de qué sistema viene, qué identifica una fila, qué periodo cubre y cómo la controla hoy la primera línea. No opina del modelo todavía: deja un MAPA completo y las brechas que la etapa 01 debe atacar.

| Paso | Qué se hace | Hoja del Excel | Cubierto si |
|---|---|---|---|
| **00.1** · Inventario de fuentes | Cada base de RUTAS con su ruta, formato, tamaño, fecha de modificación y si se pudo leer. | Mapeo | todas las bases leídas o con el error explicado |
| **00.2** · Perfil técnico | Filas, columnas, tipos, nulos, únicos, rangos y estadísticos de cada columna. | perfil_<base> | una hoja de perfil por base |
| **00.3** · Granularidad y llaves | Qué identifica una fila (llave candidata) y si tiene duplicados. | Llaves | llave candidata o falta de ella declarada por base |
| **00.4** · Cobertura temporal | Primera y última fecha, frecuencia observada y periodos faltantes. | Cobertura_temporal | cada columna de fecha con su cobertura |
| **00.5** · Relaciones entre bases | Columnas compartidas, cruces de llaves y huérfanos entre bases. | Cruces | cruces calculados entre las bases con columnas comunes |
| **00.6** · Diccionario de negocio | Qué columna cumple cada concepto del tipo de modelo (P&L, saldo, banda…) y qué falta. | Diccionario | todos los roles del tipo de modelo enlazados o declarados como faltantes |
| **00.7** · Controles de la primera línea | Qué controles declara la primera línea por base (manuales, Excels). | Controles_1L | tabla completada por el validador con fuente |
| **00.8** · Brechas y plan para la etapa 01 | Bases o columnas críticas que faltan, periodos incompletos, llaves duplicadas y qué debe controlar la etapa 01. | Brechas | brechas listadas con severidad sugerida |

### 01 · Control de datos

**Experto:** Especialista en calidad de datos de modelos de riesgo: recorre cada base y cada columna con controles de completitud, unicidad, validez, exactitud, consistencia y actualidad, más los del negocio del tipo de modelo, y busca activamente lo que se le escapó a la primera línea. Cada falla sale con N afectados, % y evidencia.

| Paso | Qué se hace | Hoja del Excel | Cubierto si |
|---|---|---|---|
| **01.1** · Retomar el mapeo | Bases, llaves y roles que dejó el 00; perfil de cada base. | Mapeo / perfil_<base> | mapeo y perfiles en el Excel |
| **01.2** · Batería de calidad (BCBS 239) | Completitud, unicidad, validez, exactitud, consistencia y actualidad sobre todas las columnas. | Controles (C, B, BD) | batería ejecutada en todas las bases |
| **01.3** · Controles del tipo de modelo | Controles de negocio por roles (M) y análisis del repositorio (D). | Controles (M, D) | controles del tipo de modelo ejecutados o pendientes explicados |
| **01.4** · Integridad y conciliaciones | Huérfanos entre bases y cuadres de conteos y montos (también contra contabilidad). | Controles | cruces y cuadres ejecutados |
| **01.5** · Contraste con la primera línea | Lo que controló la primera línea, con qué umbral y resultado, contra lo que da la segunda línea. | Contraste_1L | tabla completada y cruzada |
| **01.6** · Tratamientos aplicados | Exclusiones, imputaciones y ajustes de la primera línea y su sustento. | Tratamientos | tratamientos declarados con sustento |
| **01.7** · Fallas que se escaparon | Lo que no cumple, de lo más grave a lo menos, con N afectados y evidencia. | Fallas | fallas listadas con severidad |
| **01.8** · Porcentaje de cumplimiento y conclusión | Cumplen ÷ evaluados, ponderado por criticidad, y conclusión de la etapa. | Resumen | porcentaje calculado y conclusión escrita |

### 02 · Modelamiento

**Experto:** Modelador cuantitativo senior: replica el modelo paso a paso con el manual y el código (población, variables, supuestos, estimación, resultado), compara cada cifra con la del implementador y explica cada diferencia. Es la etapa más importante: no da nada por bueno sin recalcularlo.

| Paso | Qué se hace | Hoja del Excel | Cubierto si |
|---|---|---|---|
| **02.1** · Población y ventana | Bases, periodos y exclusiones del manual con conteos antes y después. | Poblacion | población reconstruida con sus exclusiones |
| **02.2** · Variables y transformaciones | Qué columna es cada variable del modelo y cómo se transforma. | Variables | variables enlazadas a columnas |
| **02.3** · Supuestos | Nivel de confianza, ventana, horizonte, escala y demás supuestos del manual. | Supuestos | supuestos tomados del manual con su sección |
| **02.4** · Estimación y calibración | Re-estimar los parámetros con el mismo método del manual. | Replica | parámetros re-estimados |
| **02.5** · Resultado replicado vs implementador | La métrica final recalculada frente a la reportada, con su diferencia y materialidad. | Replica | métrica comparada con tolerancia |
| **02.6** · Sensibilidad y benchmark | Cómo cambia el resultado con otra ventana, nivel o método alternativo. | Sensibilidad | al menos una sensibilidad o benchmark |
| **02.7** · Implementación | El código del implementador produce lo mismo que la réplica independiente. | Implementacion | resultado del código del implementador contrastado |
| **02.8** · Conclusión y limitaciones | Pasos que difieren, que no se pudieron replicar y qué insumo falta. | Conclusion | conclusión y pendientes |

### 03 · Impactos

**Experto:** Experto en materialidad: toma cada hallazgo abierto de 01 y 02, lo corrige en los datos y mide cuánto cambia la métrica del modelo (VaR, ΔEVE, CPR, LCR…) contra límites y umbrales; clasifica el impacto con un criterio explícito y mira también el efecto conjunto.

| Paso | Qué se hace | Hoja del Excel | Cubierto si |
|---|---|---|---|
| **03.1** · Hallazgos con impacto potencial | Los hallazgos abiertos de 01 y 02 que pueden mover el resultado. | Hallazgos_origen | hallazgos de origen listados |
| **03.2** · Métrica afectada | Qué métrica del modelo mueve cada hallazgo (VaR, ΔEVE, CPR, LCR…). | Impactos | métrica asignada por hallazgo |
| **03.3** · Escenario base | La métrica recalculada con los datos tal como están. | Impactos | valor base calculado |
| **03.4** · Escenario corregido | La métrica sin la falla (o con el dato correcto), hallazgo por hallazgo. | Impactos | corrección aplicada por hallazgo |
| **03.5** · Impacto frente a materialidad | Impacto absoluto y relativo contra umbrales y límites. | Impactos | impacto cuantificado |
| **03.6** · Impacto conjunto | Todas las correcciones a la vez (los impactos no se suman). | Impactos | escenario conjunto calculado |
| **03.7** · Nivel y criterio | Potencial/Bajo, Moderado o Crítico con el criterio explícito. | Impactos | nivel asignado con criterio |

### 04 · Seguimiento

**Experto:** Experto en monitoreo y backtesting: replica cada indicador del manual de seguimiento con los datos del periodo, lo compara con lo reportado, revisa semáforos, alertas y acciones, y concluye si el modelo sigue vigente.

| Paso | Qué se hace | Hoja del Excel | Cubierto si |
|---|---|---|---|
| **04.1** · Inventario de indicadores | Indicadores del manual de seguimiento con umbral, frecuencia y semáforo. | Indicadores | indicadores del manual listados |
| **04.2** · Recalcular indicadores | Cada indicador recalculado con los datos del periodo. | Seguimiento | indicadores recalculados |
| **04.3** · Comparar con lo reportado | Valor replicado frente al del implementador. | Seguimiento | comparación con tolerancia |
| **04.4** · Backtesting | Prueba del modelo contra lo observado (excepciones, CPR observado, salidas reales…). | Backtesting | backtesting del tipo de modelo |
| **04.5** · Estabilidad | Estabilidad de poblaciones y variables (PSI) y deriva. | Estabilidad | PSI calculado |
| **04.6** · Semáforo, alertas y acciones | Qué alertas se dispararon, si se escalaron y qué acciones hubo. | Alertas | alertas revisadas |
| **04.7** · Conclusión sobre la vigencia | Si el modelo sigue vigente y qué recomendar. | Conclusion | conclusión escrita |

## 3. Los tipos de modelo, uno por uno

### VaR de mercado (simulación histórica, paramétrico o Monte Carlo) (`var`)

*Familia Trading · repositorio `var/`*

**Qué hace el modelo.** El VaR responde a «¿cuánto puedo perder, como máximo, en 1 (o 10) días con un 99 % de confianza si el mercado se mueve como en el pasado?». Se calcula sobre la cartera de negociación (bonos, derivados, divisas, acciones). Simulación histórica: revalúa la cartera de hoy con los movimientos de los últimos N días (250 o 500) y toma el percentil de las pérdidas. Paramétrico: supone una distribución (normal) con volatilidades y correlaciones de los factores. Monte Carlo: simula miles de escenarios con parámetros calibrados. El VaR de 10 días suele escalarse con √10. Se prueba con BACKTESTING: el VaR del cierre de t se compara con el P&L de t+1; si la pérdida lo supera hay una excepción (al 99 % se esperan ~2,5 en 250 días).

**Qué produce:** VaR 1 y 10 días por cartera, mesa y total; VaR estresado (si aplica); Contribución por factor de riesgo; Excepciones diarias del backtesting (0/1).

**Para qué se usa:** Límites de riesgo de mercado por mesa y globales; Capital por riesgo de mercado; Reporte diario a Riesgos y al comité; Apetito de riesgo.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Posiciones de la cartera** (`posiciones`) | corte × posición | `fecha_corte`, `id_operacion`, `cartera`, `instrumento`, `factor`, `moneda`, `nominal`, `valor_mercado`, `sensibilidad` | `nominal`, `valor_mercado`, `sensibilidad` | Qué se revalúa: cada posición se mapea a sus factores de riesgo. |
| **Historia de factores de riesgo** (`factores`) | fecha × factor | `fecha`, `factor`, `tenor`, `precio`, `retorno` | `precio`, `retorno` | Los escenarios: en simulación histórica cada día de la ventana es un escenario. |
| **P&L diario del backtesting** (`pyg`) | fecha × cartera | `fecha`, `cartera`, `pnl_hipotetico`, `pnl_real`, `pnl` | `pnl`, `pnl_hipotetico`, `pnl_real` | Con él se cuentan las excepciones: P&L de t+1 contra VaR de t. |
| **P&L simulado por escenario (vector de simulación)** (`escenarios_pnl`) · solo si el archivo se llama así | fecha × escenario × cartera | `fecha`, `escenario`, `cartera`, `pnl` | `escenario` | El insumo directo del VaR histórico: de este vector sale el percentil. |
| **VaR reportado** (`var_reportado`) | fecha × cartera | `fecha`, `cartera`, `var_99`, `var_95`, `var_10d`, `var`, `es`, `stressed_var`, `excepcion`, `limite` | `var`, `var_99`, `var_95`, `var_10d` | Lo que el modelo produjo y se reportó: se replica y se usa en el backtesting. |
| **Volatilidades y correlaciones (paramétrico)** (`covarianzas`) | fecha × factor (× factor) | `fecha`, `factor`, `volatilidad`, `correlacion` | `volatilidad`, `correlacion` | Solo en el método paramétrico: la matriz debe ser simétrica y semidefinida positiva. |
| **Cuadre contable / front office** (`contabilidad`) · solo si el archivo se llama así | corte × cartera | `fecha_corte`, `cartera`, `valor_mercado`, `saldo`, `cuenta_contable` | `valor_mercado`, `saldo` | Prueba que la cartera de riesgo es la misma que la contable y la de front office. |

**Qué puede fallar en los datos**

- Huecos en las series de P&L o de factores (días hábiles sin dato): el backtesting pierde observaciones y la simulación histórica se queda con menos escenarios.
- Precios «rancios» (el mismo valor varios días por falta de cotización o una carga que no se actualizó): bajan la volatilidad y el VaR.
- Saltos que no son de mercado (errores de carga, unidades % vs puntos básicos, splits): inflan la cola y el VaR.
- P&L «sucio» en el backtesting: con comisiones, devengos, operaciones nuevas del día o ajustes de valoración; debe usarse el P&L hipotético (cartera congelada) y, aparte, el real.
- Desalineación de fechas: VaR de t contra P&L de t (en vez de t+1), feriados de otro mercado, zonas horarias.
- Convención de signo mezclada (VaR positivo como pérdida y P&L negativo como pérdida): invierte las excepciones.
- Mapeo incompleto: posiciones sin factor de riesgo, factores sin historia, proxies no documentados.
- Ventana insuficiente: menos de 250 (o 500) observaciones por factor; periodo estresado que no cubre la crisis elegida.
- Posiciones que no cuadran con contabilidad o front office.
- Matriz de covarianzas no semidefinida positiva o volatilidades nulas (paramétrico).

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `pyg` · pnl | `completitud` | El P&L del backtesting está informado todos los días. | un día sin P&L es una observación perdida: el backtesting cuenta menos excepciones de las que hubo. | ALTA |
| `pyg` · fecha, (cartera) | `unicidad` | Un solo P&L por fecha (y cartera). | un día duplicado se cuenta dos veces: duplica excepciones o las diluye. | ALTA |
| `pyg` · fecha | `serie_continua` | La serie de P&L no tiene huecos de días hábiles. | el backtesting regulatorio usa 250 días hábiles seguidos; todo hueco que no sea feriado debe explicarse (tolerancia 2 %: declara los feriados en `excluir`). | ALTA |
| `pyg` · fecha | `fechas_habiles` | No hay P&L en fines de semana. | un dato en sábado o domingo suele ser una fecha corrida un día: desalinea P&L y VaR. | MEDIA |
| `pyg` · pnl | `constante` | El P&L no es constante. | un P&L plano (ceros o copiado) invalida el backtesting. | ALTA |
| `pyg` · pnl | `proporcion_ceros` | Pocos días con P&L exactamente cero. | en una cartera viva un cero exacto suele ser un dato faltante rellenado. | MEDIA |
| `pyg` · pnl, fecha, (cartera) | `saltos_serie` | El P&L no tiene saltos de más de 12 desviaciones robustas. | las colas gruesas son normales; un salto de 12 MAD suele ser un error de carga, de unidades o una operación nueva metida en el P&L hipotético. | MEDIA |
| `pyg` · pnl_real, pnl_hipotetico | `diferencia_relativa` | El P&L real y el hipotético no difieren de forma sistemática. | diferencias grandes y frecuentes indican comisiones, devengos o actividad intradía en el real: el backtesting debe hacerse con ambos y explicar la brecha. | BAJA |
| `var_reportado` · var | `completitud` | El VaR está informado todos los días. | sin VaR del día no hay excepción que contar ni límite que vigilar. | ALTA |
| `var_reportado` · fecha, (cartera) | `unicidad` | Un solo VaR por fecha (y cartera). | dos VaR el mismo día (re-ejecuciones) dejan ambiguo cuál se reportó. | ALTA |
| `var_reportado` · fecha | `serie_continua` | La serie de VaR no tiene huecos de días hábiles. | cada día sin VaR es un día sin control de límites. | ALTA |
| `var_reportado` · var, fecha, (cartera) | `valores_repetidos` | El VaR no se repite idéntico más de 3 días seguidos. | un VaR copiado del día anterior (proceso caído) no mide el riesgo del día. | MEDIA |
| `var_reportado` · var, fecha, (cartera) | `saltos_serie` | El VaR no salta sin explicación de un día a otro. | un salto suele ser un cambio de cartera, de ventana o de parámetros, o un error de carga: cada uno debe estar documentado. | MEDIA |
| `var_reportado` · var_95, var_99 | `monotonia` | VaR 95 % ≤ VaR 99 % todos los días. | un percentil más alto no puede dar menos pérdida (con pérdidas en positivo). | ALTA |
| `var_reportado` · fecha → `pyg` | `integridad` | Cada fecha con VaR tiene su P&L. | un VaR sin P&L es un día que el backtesting no puede evaluar. | ALTA |
| `pyg` · fecha → `var_reportado` | `integridad` | Cada fecha con P&L tiene su VaR. | un P&L sin VaR del día anterior deja la pérdida sin contraste. | ALTA |
| `factores` · precio | `completitud` | Todos los factores tienen precio en cada fecha registrada. | un precio nulo deja un escenario sin revaluar (o lo rellena alguien sin decirlo). | ALTA |
| `factores` · fecha, factor, (tenor) | `unicidad` | Un solo precio por fecha y factor. | dos precios el mismo día para el mismo factor duplican el escenario. | ALTA |
| `factores` · precio, fecha, factor | `valores_repetidos` | Ningún factor repite su precio más de 5 días hábiles seguidos. | precios rancios: bajan la volatilidad y el VaR sin que el mercado lo diga. | ALTA |
| `factores` · precio, fecha, factor | `saltos_serie` | Ningún factor salta más de 10 desviaciones robustas en un día. | un salto así suele ser un error de carga o de unidades y se convierte en el peor escenario. | ALTA |
| `factores` · factor | `minimo_por_grupo` | Cada factor tiene al menos 250 observaciones. | la simulación histórica necesita la ventana completa por factor (250 o 500 días). | ALTA |
| `factores` · fecha, factor | `combinaciones_completas` | Todos los factores tienen dato en todas las fechas de la ventana. | un factor sin dato en una fecha obliga a rellenarlo (proxy) o a perder el escenario. | ALTA |
| `factores` · fecha | `fechas_habiles` | La historia de factores no trae fines de semana. | fines de semana con dato suelen ser copias del viernes: escenarios artificiales de cero cambio. | MEDIA |
| `factores` · fecha | `frescura` | La historia de factores llega hasta el corte. | si la historia se cortó días antes, el VaR de hoy usa escenarios viejos. | ALTA |
| `posiciones` · factor | `completitud` | Toda posición está mapeada a un factor de riesgo. | una posición sin factor no entra en el VaR: riesgo omitido. | ALTA |
| `posiciones` · factor → `factores` | `integridad` | Los factores de las posiciones tienen historia. | sin historia el factor se aproxima con un proxy (debe estar documentado) o se omite. | ALTA |
| `posiciones` · id_operacion, (fecha_corte) | `unicidad` | Cada posición aparece una sola vez por corte. | una posición duplicada dobla su riesgo. | ALTA |
| `posiciones` · valor_mercado | `completitud` | Todas las posiciones tienen valor de mercado. | sin valor de mercado no hay revaluación ni cuadre con contabilidad. | ALTA |
| `posiciones` · valor_mercado → `contabilidad` | `conciliacion_totales` | El valor de mercado de la cartera de riesgo cuadra con contabilidad / front office. | si la cartera de riesgo no es la contable, el VaR mide otra cosa. | ALTA |
| `escenarios_pnl` · pnl | `completitud` | Todos los escenarios tienen P&L simulado. | un escenario sin P&L cambia el percentil (el VaR se calcula con menos escenarios). | ALTA |
| `escenarios_pnl` · fecha, escenario, (cartera) | `combinaciones_completas` | Cada fecha de cálculo tiene todos los escenarios de la ventana. | si faltan escenarios, el percentil no es el del manual. | ALTA |
| `escenarios_pnl` · fecha, (cartera) | `minimo_por_grupo` | Cada fecha tiene al menos 250 escenarios. | la simulación histórica usa la ventana completa (250 o 500 días). | ALTA |
| `covarianzas` · correlacion | `rango` | Las correlaciones están entre −1 y 1. | una correlación fuera de [−1, 1] es un error de cálculo o de carga. | ALTA |
| `covarianzas` · volatilidad | `no_negativos` | Las volatilidades no son negativas. | una volatilidad negativa no existe. | ALTA |
| `covarianzas` · volatilidad | `proporcion_ceros` | Ningún factor tiene volatilidad cero. | volatilidad cero = factor que no se movió (precio rancio) y no aporta riesgo. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `var/var_negativos.py` — El VaR estimado debe ser estrictamente positivo (un VaR ≤ 0 es un error de cálculo o de signo).
- `var/kupiec.py` — Backtesting de VaR (Kupiec POF): la tasa de excepciones debe ser consistente con 1 − nivel de confianza.
- `var/semaforo_basilea.py` — El nº de excepciones de backtesting en ~250 días debe situar el modelo en zona VERDE de Basilea (0-4); amarilla (5-9) es observación, roja (>=10) es rechazo.
- `var/severidad_excepciones.py` — Cuando la pérdida supera el VaR, el exceso medio (pérdida−VaR)/VaR no debería ser grande: excesos severos apuntan a colas mal capturadas.
- `var/alineacion_pnl_var.py` — La marca de excepción del backtesting compara el P&L de cada día con el VaR del día ANTERIOR (rezago de un día), no con el del mismo día.
- `var/christoffersen.py` — Independencia de las excepciones (Christoffersen): las excepciones no deben agruparse (clustering) en el tiempo.
- `var/backtesting_excedencias.py` — Backtesting por conteo de excedencias: nº de excepciones en la ventana debe caer en zona verde del semáforo de Basilea.
- `var/monotonia_niveles_var.py` — El VaR debe crecer en magnitud con el nivel de confianza: \|VaR99\| >= \|VaR95\| >= \|VaR90\| en cada fecha. Una inversión delata un error de cómputo.
- `var/escalado_horizonte.py` — El VaR a 10 días es coherente con el VaR a 1 día: si se escala por la raíz del tiempo, VaR10 ≈ √10 × VaR1 (3,16 veces) en casi todos los días.
- `var/matriz_covarianzas.py` — La matriz de correlaciones del VaR paramétrico es simétrica, tiene unos en la diagonal y es semidefinida positiva (ningún autovalor negativo).

**Qué pedir a la primera línea**

1. Método (histórico, paramétrico, Monte Carlo), ventana, nivel de confianza y horizonte. ¿Cómo se llega a 10 días?
2. ¿Qué P&L se usa en el backtesting (hipotético, real o ambos) y cómo se construye cada uno?
3. ¿Con qué rezago se compara (VaR de t contra P&L de t+1)? ¿Qué calendario de feriados aplica?
4. ¿Qué factores no tienen historia completa y qué proxies se usan? ¿Quién los aprueba?
5. ¿Cómo se tratan precios rancios, días sin cotización y saltos? ¿Hay limpieza de la historia?
6. ¿Cómo se concilia la cartera de riesgo con front office y contabilidad, y con qué tolerancia?
7. ¿Cuál es el periodo estresado y por qué se eligió?
8. Excepciones de los últimos 250 días por cartera y la explicación de cada una.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea las bases del VaR: posiciones (qué se revalúa), historia de factores (los escenarios), P&L (backtesting) y VaR reportado; si es paramétrico, la matriz de covarianzas. Por base: granularidad (fecha × cartera, fecha × factor), rango de fechas y días hábiles de la ventana (≥ 250 o 500). Identifica qué P&L existe (hipotético, real, teórico) y la convención de signo del VaR y del P&L. Cruza posiciones ↔ factores (¿cada posición tiene factor con historia?) y P&L ↔ VaR (¿mismas fechas y carteras?).
- **01 · Control de datos:** Huecos, duplicados y fines de semana en las series de P&L, VaR y factores. Precios rancios (repetidos) y saltos por factor; ventana mínima por factor. Mapeo completo posiciones → factores y cuadre del valor de mercado con contabilidad. Convención de signo y alineación t / t+1 entre VaR y P&L.
- **02 · Modelamiento:** Replica el VaR: con los escenarios de P&L (o sensibilidades × retornos de los factores) calcula el percentil con la misma ventana e interpolación y compáralo fecha a fecha con el reportado. Si es paramétrico: VaR = z·√(wᵀΣw); comprueba que la matriz es simétrica y semidefinida positiva. Verifica el escalado a 10 días (√10) o el cálculo directo, y el VaR estresado con su periodo. Benchmark: VaR histórico y paramétrico con el P&L de la cartera; explica las diferencias.
- **03 · Impactos:** Recalcula el VaR sin los días o factores con fallas (huecos, rancios, saltos) y con su corrección: cambio en el VaR y en las excepciones. Mide el efecto de alinear mal t/t+1 o de usar P&L real en vez del hipotético (¿cambia la zona del semáforo?). Compara con los límites por mesa: un impacto que cambia el consumo de límite es Moderado o Crítico.
- **04 · Seguimiento:** Backtesting de 250 días por cartera: excepciones, Kupiec (POF), Christoffersen (independencia) y zona del semáforo de Basilea. Severidad de las excepciones (pérdida ÷ VaR) y su explicación documentada. Límites y alertas: consumo, excesos, escalamiento y acciones tomadas. Estabilidad: evolución del VaR, de la ventana y del mapeo de factores.

**Métricas que se replican (02) y vigilan (04):** VaR 99 % a 1 día; VaR a 10 días; VaR estresado; Excepciones en 250 días; Kupiec (LR y p-valor); Christoffersen; Zona del semáforo de Basilea.

**Referencias:** Basilea — marco de backtesting de modelos internos: semáforo verde 0–4, ámbar 5–9, rojo ≥ 10 excepciones en 250 días al 99 %; Kupiec (1995), test de proporción de fallos (POF); Christoffersen (1998), independencia; BCBS 239: exactitud, completitud y oportunidad de los datos de riesgo; SR 11-7 / OCC 2011-12: validación independiente de modelos.

### Expected Shortfall / FRTB (modelo interno IMA) (`es_frtb`)

*Familia Trading · repositorio `var/`*

**Qué hace el modelo.** El Expected Shortfall al 97,5 % es la pérdida MEDIA en el peor 2,5 % de los escenarios: mira toda la cola, no solo un percentil. En FRTB (modelo interno) se calcula por mesa con horizontes de liquidez por factor (10, 20, 40, 60, 120 días) combinados en cascada, calibrado a un periodo de estrés. Cada mesa debe pasar el backtesting (VaR 97,5 % y 99 %) y la prueba de atribución de P&L (PLA): el P&L hipotético (HPL) y el teórico del modelo de riesgo (RTPL) deben parecerse (correlación de Spearman y test de Kolmogorov–Smirnov). Solo los factores «modelables» (con suficientes precios reales, RFET) entran en el ES; el resto va a la carga NMRF.

**Qué produce:** ES 97,5 % por mesa con horizontes de liquidez; Ratio de calibración al periodo de estrés; Zona PLA por mesa; Factores modelables y no modelables (NMRF).

**Para qué se usa:** Capital por riesgo de mercado con modelo interno; Elegibilidad de cada mesa para el modelo interno.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **HPL y RTPL por mesa** (`pyg`) | fecha × mesa | `fecha`, `cartera`, `pnl_hipotetico`, `pnl_teorico`, `pnl_real`, `pnl` | `pnl_hipotetico`, `pnl_teorico` | PLA (HPL vs RTPL) y backtesting por mesa. |
| **ES reportado** (`es_reportado`) | fecha × mesa | `fecha`, `cartera`, `es`, `var_99`, `var`, `stressed_var`, `limite` | `es` | Lo que el modelo produjo: se replica. |
| **Observaciones reales de precios (RFET)** (`observaciones`) | fecha × factor | `fecha`, `factor`, `precio` | `precio` | Decide qué factores son modelables. |
| **Horizonte de liquidez por factor** (`horizontes`) | factor | `factor`, `horizonte`, `categoria` | `horizonte` | Cada factor entra al ES con su horizonte regulatorio. |

**Qué puede fallar en los datos**

- HPL y RTPL desalineados (fechas, mesas o perímetro distinto): la PLA falla por datos, no por el modelo.
- RTPL calculado con factores o precios distintos de los de valoración (front office).
- Observaciones «reales» que en realidad son precios evaluados o copiados: factores no modelables tratados como modelables.
- Horizontes de liquidez no asignados o distintos de los regulatorios (10, 20, 40, 60, 120).
- Periodo de estrés mal elegido o con huecos en los factores reducidos.
- Mesas que cambian de perímetro sin que cambie la serie histórica.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `pyg` · pnl_hipotetico | `completitud` | El HPL está informado todos los días por mesa. | la PLA y el backtesting necesitan el HPL diario completo. | ALTA |
| `pyg` · pnl_teorico | `completitud` | El RTPL está informado todos los días por mesa. | sin RTPL no hay prueba de atribución. | ALTA |
| `pyg` · fecha, (cartera) | `unicidad` | Un solo HPL/RTPL por fecha y mesa. | duplicados distorsionan Spearman y KS. | ALTA |
| `pyg` · fecha | `serie_continua` | La serie de HPL/RTPL no tiene huecos de días hábiles. | la PLA usa 250 días hábiles. | ALTA |
| `pyg` · pnl_teorico, pnl_hipotetico | `diferencia_relativa` | El RTPL no se aleja del HPL en la mayoría de los días. | un RTPL muy distinto del HPL anticipa una PLA en zona ámbar o roja. | MEDIA |
| `es_reportado` · es | `completitud` | El ES está informado todos los días por mesa. | sin ES no hay capital del día. | ALTA |
| `es_reportado` · es | `no_negativos` | El ES se reporta como pérdida positiva. | mezclar convenciones de signo invierte la lectura del capital. | ALTA |
| `es_reportado` · es, fecha, (cartera) | `saltos_serie` | El ES no salta sin explicación. | un salto suele ser un cambio de perímetro, de periodo de estrés o un error de carga. | MEDIA |
| `es_reportado` · var_99, es | `monotonia` | ES ≥ VaR 99 % (con pérdidas en positivo). | el ES 97,5 % suele igualar o superar al VaR 99 %; si queda muy por debajo, revisa el cálculo de la cola. | BAJA |
| `observaciones` · factor | `minimo_por_grupo` | Cada factor tiene al menos 24 observaciones reales. | es el primer requisito del RFET para que el factor sea modelable. | ALTA |
| `observaciones` · fecha, factor | `unicidad` | Una observación por fecha y factor. | contar dos veces la misma observación aprueba el RFET sin cumplirlo. | ALTA |
| `horizontes` · horizonte | `completitud` | Todo factor tiene horizonte de liquidez. | sin horizonte el factor no entra en la cascada del ES. | ALTA |
| `horizontes` · horizonte | `dominio` | Los horizontes son 10, 20, 40, 60 o 120 días. | son los únicos que admite la norma. | ALTA |
| `horizontes` · factor → `observaciones` | `integridad` | Cada factor con horizonte tiene observaciones (RFET). | un factor sin observaciones no puede probar que es modelable. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `var/var_negativos.py` — El VaR estimado debe ser estrictamente positivo (un VaR ≤ 0 es un error de cálculo o de signo).
- `var/kupiec.py` — Backtesting de VaR (Kupiec POF): la tasa de excepciones debe ser consistente con 1 − nivel de confianza.
- `var/semaforo_basilea.py` — El nº de excepciones de backtesting en ~250 días debe situar el modelo en zona VERDE de Basilea (0-4); amarilla (5-9) es observación, roja (>=10) es rechazo.
- `var/severidad_excepciones.py` — Cuando la pérdida supera el VaR, el exceso medio (pérdida−VaR)/VaR no debería ser grande: excesos severos apuntan a colas mal capturadas.
- `var/alineacion_pnl_var.py` — La marca de excepción del backtesting compara el P&L de cada día con el VaR del día ANTERIOR (rezago de un día), no con el del mismo día.
- `var/christoffersen.py` — Independencia de las excepciones (Christoffersen): las excepciones no deben agruparse (clustering) en el tiempo.
- `var/backtesting_excedencias.py` — Backtesting por conteo de excedencias: nº de excepciones en la ventana debe caer en zona verde del semáforo de Basilea.
- `var/monotonia_niveles_var.py` — El VaR debe crecer en magnitud con el nivel de confianza: \|VaR99\| >= \|VaR95\| >= \|VaR90\| en cada fecha. Una inversión delata un error de cómputo.
- `var/pla_frtb.py` — Prueba de atribución de P&L (PLA): el P&L teórico del modelo de riesgo (RTPL) se parece al hipotético (HPL) — Spearman > 0,80 y Kolmogorov–Smirnov < 0,09 (zona verde).
- `var/rfet_modelabilidad.py` — Cada factor de riesgo es modelable (RFET): en los últimos 12 meses tiene ≥ 24 observaciones reales sin ningún periodo de 90 días con menos de 4, o ≥ 100 observaciones.

**Qué pedir a la primera línea**

1. Perímetro de cada mesa y fecha de alta/baja; cómo se construyen HPL y RTPL y con qué precios.
2. Periodo de estrés elegido, factores reducidos y ratio de calibración.
3. Fuente de las observaciones reales del RFET (transacciones, cotizaciones ejecutables) y su auditoría.
4. Asignación de horizontes de liquidez por factor y su aprobación.
5. Resultados de PLA y backtesting por mesa del último año y acciones tomadas.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea por mesa: HPL, RTPL, ES reportado, factores con su horizonte y observaciones del RFET. Fija el periodo de estrés y el conjunto de factores reducidos.
- **01 · Control de datos:** Alineación HPL ↔ RTPL (fechas, mesas, perímetro) y completitud de ambos. Observaciones reales únicas por factor y fecha; horizontes válidos para todos los factores.
- **02 · Modelamiento:** Replica el ES: media de las pérdidas más allá del percentil 97,5 % de los escenarios. Aplica la cascada de horizontes: ES = √(ES_T(P)² + Σ_j (ES_T(P, j)·√((LH_j − LH_{j−1})/T))²), T = 10. Replica el RFET por factor (24 obs/12 meses sin 90 días con menos de 4; o 100 obs).
- **03 · Impactos:** Impacto de reclasificar factores como no modelables (carga NMRF) y de una mesa que sale del IMA por PLA.
- **04 · Seguimiento:** PLA trimestral por mesa: Spearman y KS entre HPL y RTPL y su zona. Backtesting por mesa al 97,5 % y 99 % (excepciones en 250 días).

**Métricas que se replican (02) y vigilan (04):** ES 97,5 % por mesa; Spearman y KS (PLA); Excepciones al 97,5 % y 99 %; % de factores modelables (RFET).

**Referencias:** BCBS d457 (FRTB, 2019): ES 97,5 % con horizontes de liquidez en cascada; PLA: verde si Spearman > 0,80 y KS < 0,09; rojo si Spearman < 0,70 o KS > 0,12 (verifica la versión vigente); RFET: ≥ 24 observaciones reales en 12 meses sin periodo de 90 días con menos de 4, o ≥ 100 observaciones; Backtesting por mesa al 97,5 % y 99 % con 250 días.

### Pruebas de estrés de mercado (históricas, hipotéticas e inversas) (`stress_mercado`)

*Familia Trading · repositorio `var/`*

**Qué hace el modelo.** Aplica choques extremos pero plausibles a los factores de riesgo —históricos (2008, 2013, 2020) o hipotéticos— y mide la pérdida de la cartera. Complementa al VaR porque mira más allá de la ventana y de la normalidad. El estrés inverso busca qué combinación de choques agota el límite o el capital. Cada escenario debe chocar TODOS los factores relevantes con un tamaño y signo justificados.

**Qué produce:** Pérdida por escenario y cartera; Peor escenario; Consumo de límites de estrés.

**Para qué se usa:** Límites de estrés; Apetito de riesgo; Planes de contingencia.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Choques por escenario y factor** (`escenarios`) | escenario × factor | `escenario`, `factor`, `tenor`, `retorno` | `retorno` | Qué se mueve y cuánto en cada escenario. |
| **Posiciones y sensibilidades** (`posiciones`) | posición × factor | `id_operacion`, `cartera`, `factor`, `sensibilidad`, `valor_mercado` | `sensibilidad`, `valor_mercado` | A qué está expuesta la cartera. |
| **Pérdida por escenario** (`resultados`) | escenario × cartera | `escenario`, `cartera`, `pnl`, `limite` | `pnl` | Lo que se reporta y se compara con límites. |

**Qué puede fallar en los datos**

- Escenarios que no chocan todos los factores con exposición (riesgo omitido).
- Choques con signo o unidades inconsistentes (bps vs %, relativo vs absoluto).
- Factores de las posiciones que no existen en la tabla de choques.
- Resultados que no se recalculan cuando cambia la cartera.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `escenarios` · escenario, factor | `combinaciones_completas` | Cada escenario choca todos los factores. | un factor sin choque en un escenario es un riesgo que el estrés no ve. | ALTA |
| `escenarios` · retorno | `completitud` | Todos los choques están informados. | un choque nulo puede ser «sin cambio» o «dato faltante»: debe decirlo. | ALTA |
| `escenarios` · escenario, factor, (tenor) | `unicidad` | Un choque por escenario y factor. | dos choques distintos para el mismo factor dejan ambiguo cuál se aplicó. | ALTA |
| `posiciones` · factor → `escenarios` | `integridad` | Los factores de las posiciones están en la tabla de choques. | una posición cuyo factor no se choca no pierde nada en el estrés. | ALTA |
| `resultados` · escenario, cartera | `combinaciones_completas` | Hay pérdida calculada para cada escenario y cartera. | un hueco deja una cartera sin estrés. | MEDIA |
| `resultados` · pnl | `completitud` | Todas las pérdidas por escenario están informadas. | sin resultado no hay contraste con el límite. | ALTA |

**Qué pedir a la primera línea**

1. Catálogo de escenarios, su narrativa y fecha de aprobación.
2. Cómo se calibran los choques (histórico, juicio experto) y su unidad (bps, %).
3. Cómo se mapean factores sin choque explícito (proxies).
4. Límites de estrés y excesos del último año.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea escenarios × factores, posiciones × sensibilidades y resultados × cartera.
- **01 · Control de datos:** Rejilla escenario × factor completa, choques únicos y factores de las posiciones cubiertos.
- **02 · Modelamiento:** Replica la pérdida: Σ sensibilidad × choque (o revaluación completa) por escenario y cartera. Revisa la plausibilidad y severidad de cada escenario frente a la historia.
- **03 · Impactos:** Impacto de los factores sin choque y de los choques mal escalados en la pérdida del peor escenario.
- **04 · Seguimiento:** Evolución de la pérdida por escenario frente a límites; vigencia de los escenarios.

**Métricas que se replican (02) y vigilan (04):** Pérdida por escenario; Peor escenario; Consumo de límite de estrés.

**Referencias:** BCBS — principios de pruebas de estrés (2018); SR 11-7.

### Valoración de instrumentos y derivados (con verificación independiente de precios) (`valoracion`)

*Familia Trading · repositorio `var/`*

**Qué hace el modelo.** Pone precio a instrumentos sin cotización directa (derivados OTC, bonos ilíquidos) con curvas, volatilidades y modelos (descuento de flujos, Black, Hull–White…). La verificación independiente de precios (IPV) compara el precio del modelo con fuentes externas; las diferencias se ajustan y definen la jerarquía de valor razonable: Nivel 1 cotizado, Nivel 2 con insumos observables, Nivel 3 con insumos no observables.

**Qué produce:** Valor razonable por operación; Diferencias de IPV y ajustes; Jerarquía de valor razonable.

**Para qué se usa:** Estados financieros; P&L diario; Insumo del VaR y de contraparte.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Operaciones** (`operaciones`) | operación | `id_operacion`, `instrumento`, `contraparte`, `moneda`, `nominal`, `strike`, `fecha_inicio`, `fecha_vencimiento` | `nominal`, `strike` | Términos contractuales de lo que se valora. |
| **Precios: modelo vs independiente** (`precios`) | fecha × operación | `fecha`, `id_operacion`, `precio_modelo`, `precio_independiente`, `nivel_jerarquia`, `valor_mercado` | `precio_modelo`, `precio_independiente` | IPV: diferencias entre el precio del modelo y la fuente independiente. |

**Qué puede fallar en los datos**

- Términos contractuales mal cargados (fechas invertidas, nominal o strike negativos).
- IPV con fuentes rancias o no independientes.
- Jerarquía de valor razonable sin asignar o inconsistente con los insumos.
- Operaciones valoradas que no existen en el maestro (o al revés).

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `operaciones` · fecha_inicio, fecha_vencimiento | `consistencia_fechas` | El inicio es anterior al vencimiento. | fechas invertidas generan flujos negativos o nulos. | ALTA |
| `operaciones` · nominal | `no_negativos` | El nominal no es negativo (el signo va en compra/venta). | mezclar el signo en el nominal duplica o anula la posición. | MEDIA |
| `operaciones` · strike | `no_negativos` | El precio de ejercicio no es negativo. | un strike negativo es un error de carga (salvo tasas negativas documentadas). | MEDIA |
| `operaciones` · id_operacion | `unicidad` | Cada operación aparece una vez. | duplicados duplican el valor razonable. | ALTA |
| `precios` · precio_modelo, precio_independiente | `diferencia_relativa` | El precio del modelo y el independiente difieren menos de 2 % en casi todas las operaciones. | diferencias grandes exigen ajuste de valoración o revisión del modelo. | ALTA |
| `precios` · precio_independiente | `completitud` | Hay precio independiente para todas las operaciones. | sin IPV no hay control del precio del modelo. | MEDIA |
| `precios` · nivel_jerarquia | `completitud` | Toda operación tiene nivel de jerarquía (1, 2 o 3). | la jerarquía decide la revelación y la valoración prudente. | ALTA |
| `precios` · id_operacion → `operaciones` | `integridad` | Cada precio corresponde a una operación del maestro. | un precio sin operación (o al revés) es un descuadre del inventario. | ALTA |

**Qué pedir a la primera línea**

1. Modelos de valoración por producto y su aprobación.
2. Fuentes del IPV, frecuencia y tolerancias.
3. Criterio de asignación del nivel de jerarquía.
4. Ajustes de valoración del periodo.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea operaciones, precios del modelo, precios independientes y nivel de jerarquía.
- **01 · Control de datos:** Términos contractuales coherentes; IPV completo; jerarquía asignada; operaciones ↔ precios.
- **02 · Modelamiento:** Revalúa una muestra representativa por producto con un modelo independiente y compara.
- **03 · Impactos:** Impacto en P&L de las diferencias de IPV fuera de tolerancia.
- **04 · Seguimiento:** Evolución de las diferencias de IPV y de los niveles 3.

**Métricas que se replican (02) y vigilan (04):** Diferencia de IPV por producto; % de operaciones fuera de tolerancia; Valor de Nivel 3.

**Referencias:** NIIF 13 (medición del valor razonable); SR 11-7; Basilea — valoración prudente.

### Curvas de tasas y superficies de volatilidad (datos de mercado) (`curvas`)

*Familia Trading · repositorio `var/`*

**Qué hace el modelo.** Construye las curvas cero y de descuento (bootstrapping desde depósitos, FRAs, swaps y bonos) e interpola entre nodos; arma superficies de volatilidad. Son insumo de la valoración, del VaR, del IRRBB y del FTP: un error en la curva se propaga a todo. Con tasas positivas, el factor de descuento baja con el plazo.

**Qué produce:** Curvas cero y de descuento por fecha y moneda; Superficies de volatilidad.

**Para qué se usa:** Valoración; VaR; IRRBB; FTP.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Curvas por fecha y nodo** (`curvas`) | fecha × curva × tenor | `fecha`, `factor`, `tenor`, `moneda`, `tasa`, `factor_descuento` | `tasa`, `factor_descuento` | Tasas y factores de descuento por nodo. |
| **Superficie de volatilidad** (`volatilidades`) | fecha × tenor × strike | `fecha`, `tenor`, `strike`, `volatilidad` | `volatilidad` | Insumo de opciones. |

**Qué puede fallar en los datos**

- Nodos faltantes en algunas fechas (la interpolación los inventa).
- Tasas rancias o saltos por errores de carga.
- Escala mezclada (decimales vs porcentaje).
- Factores de descuento que suben con el plazo sin tasas negativas que lo expliquen.
- Volatilidades nulas o negativas.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `curvas` · fecha, tenor, (factor) | `combinaciones_completas` | Cada fecha tiene todos los nodos de la curva. | un nodo faltante se rellena interpolando sin que nadie lo diga. | ALTA |
| `curvas` · factor_descuento, tenor, (fecha) | `monotonia_curva` | El factor de descuento baja con el plazo. | con tasas positivas, un factor de descuento que sube es un error de curva (o tasas negativas que hay que documentar). | ALTA |
| `curvas` · factor_descuento | `rango` | El factor de descuento está entre 0 y 1,2. | fuera de ese rango no es un factor de descuento razonable. | ALTA |
| `curvas` · tasa, fecha, tenor | `valores_repetidos` | Ningún nodo repite su tasa más de 5 días seguidos. | tasas rancias congelan la curva. | ALTA |
| `curvas` · tasa, fecha, tenor | `saltos_serie` | Ningún nodo salta más de 10 desviaciones robustas. | un salto así suele ser un error de carga o de escala. | ALTA |
| `curvas` · fecha | `frescura` | La curva más reciente es del corte. | valorar con una curva vieja desplaza todo el P&L. | ALTA |
| `volatilidades` · volatilidad | `no_negativos` | Las volatilidades no son negativas. | una volatilidad negativa no existe. | ALTA |
| `volatilidades` · volatilidad | `proporcion_ceros` | Ninguna volatilidad es cero. | volatilidad cero = punto de la superficie sin dato. | MEDIA |

**Qué pedir a la primera línea**

1. Instrumentos de entrada por curva y método de bootstrapping e interpolación.
2. Fuentes de mercado, hora de captura y tratamiento de nodos sin cotización.
3. Convenciones (base de días, capitalización) por curva.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea curvas × nodos × fechas, superficies y sus fuentes.
- **01 · Control de datos:** Nodos completos por fecha, tasas rancias, saltos y escala; factores de descuento coherentes.
- **02 · Modelamiento:** Reconstruye los factores de descuento desde las tasas cero (DF = e^(−r·t) o la convención declarada) e interpola un nodo de control; compara con la curva del implementador.
- **03 · Impactos:** Impacto en valoración de usar la curva corregida en los nodos con fallas.
- **04 · Seguimiento:** Estabilidad de la curva y de las diferencias con fuentes alternativas.

**Métricas que se replican (02) y vigilan (04):** Diferencia de factores de descuento por nodo; Nodos faltantes por fecha.

**Referencias:** NIIF 13; SR 11-7; BCBS 239.

### Riesgo de contraparte (exposición, EAD SA-CCR, CVA) (`contraparte`)

*Familia Trading · repositorio `var/`*

**Qué hace el modelo.** Mide cuánto perdería el banco si la contraparte de un derivado incumple: costo de reposición (valor de mercado positivo neto de colateral) más exposición potencial futura (add-on por clase de activo). En SA-CCR, EAD = 1,4 × (RC + PFE). El CVA es el ajuste de valoración por ese riesgo. Datos críticos: conjuntos de compensación (netting), acuerdos de colateral (umbrales, mínimos de transferencia), valor de mercado por operación y vencimientos.

**Qué produce:** EAD por contraparte y conjunto de compensación; CVA; Exposición potencial futura.

**Para qué se usa:** Capital por contraparte; Límites por contraparte; Ajustes de valoración.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Derivados por contraparte** (`operaciones`) | operación | `id_operacion`, `contraparte`, `netting_set`, `instrumento`, `nominal`, `valor_mercado`, `fecha_vencimiento` | `valor_mercado`, `nominal` | Base del costo de reposición y del add-on. |
| **Colateral por acuerdo** (`colateral`) | acuerdo × fecha | `netting_set`, `fecha`, `colateral`, `mpor` | `colateral` | Reduce la exposición. |
| **Exposición reportada** (`exposiciones`) | contraparte × fecha | `contraparte`, `netting_set`, `fecha`, `ead`, `cva` | `ead` | Lo que se reporta y se replica. |

**Qué puede fallar en los datos**

- Operaciones sin conjunto de compensación (se calculan sin netting o con el equivocado).
- Colateral que no corresponde a ningún acuerdo vigente.
- Exposiciones negativas o nulas.
- Vencimientos pasados en operaciones vivas.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `operaciones` · netting_set | `completitud` | Toda operación tiene conjunto de compensación. | sin netting la exposición se sobrestima (o se compensa con quien no corresponde). | ALTA |
| `operaciones` · valor_mercado | `completitud` | Toda operación tiene valor de mercado. | sin valor de mercado no hay costo de reposición. | ALTA |
| `operaciones` · id_operacion | `unicidad` | Cada operación aparece una vez. | duplicados duplican la exposición. | ALTA |
| `colateral` · netting_set → `operaciones` | `integridad` | El colateral corresponde a acuerdos con operaciones. | colateral huérfano reduce una exposición que no existe. | ALTA |
| `colateral` · mpor | `no_negativos` | El periodo de margen no es negativo. | un MPOR negativo es un error. | MEDIA |
| `exposiciones` · ead | `no_negativos` | La EAD no es negativa. | la exposición es ≥ 0 por definición. | ALTA |
| `exposiciones` · ead | `completitud` | Hay EAD para todas las contrapartes. | una contraparte sin EAD no consume límite. | ALTA |

**Qué pedir a la primera línea**

1. Acuerdos de compensación y de colateral vigentes y su validez legal.
2. Parámetros de SA-CCR (factores de supervisión, MPOR) y su fuente.
3. Metodología del CVA y fuente de los spreads de crédito.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea operaciones × conjunto de compensación × colateral × exposición reportada.
- **01 · Control de datos:** Netting completo, colateral con acuerdo, exposiciones no negativas.
- **02 · Modelamiento:** Replica el costo de reposición por conjunto: max(V − C, 0) y la EAD con 1,4 × (RC + PFE).
- **03 · Impactos:** Impacto en EAD de las operaciones sin netting o con colateral mal asignado.
- **04 · Seguimiento:** Evolución de la EAD frente a límites por contraparte.

**Métricas que se replican (02) y vigilan (04):** Costo de reposición; EAD SA-CCR; CVA.

**Referencias:** BCBS 279 (SA-CCR, 2014); Basilea — marco de CVA (2020); NIIF 13.

### ALM · IRRBB: EVE y NII (gap de reprecio) (`irrbb`)

*Familia ALM · repositorio `alm/`*

**Qué hace el modelo.** Mide el riesgo de tasa de interés del libro bancario: cuánto cambian el valor económico del patrimonio (EVE = valor presente de activos − pasivos) y el margen financiero de los próximos 12 meses (NII) si las tasas se mueven. Cada posición va a una banda temporal según su próxima fecha de reprecio (tasa variable) o sus flujos (tasa fija), con supuestos conductuales (prepago, depósitos sin vencimiento, cancelación de plazo). Basilea pide seis escenarios: paralelo arriba y abajo, empinamiento, aplanamiento, cortos arriba y abajo; el peor ΔEVE frente al capital Tier 1 es la prueba de valores atípicos (SOT, 15 %). El balance para ΔEVE es en run-off (sin nuevo negocio); el ΔNII suele usar balance constante.

**Qué produce:** Gap de reprecio por banda y moneda; ΔEVE por escenario y moneda; ΔNII a 12 meses; SOT: ΔEVE máximo ÷ Tier 1.

**Para qué se usa:** Límites de IRRBB (ΔEVE/patrimonio, ΔNII/margen); Estrategia de coberturas de Tesorería; Reporte regulatorio y al comité ALCO.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Posiciones del libro bancario** (`posiciones`) | corte × operación | `fecha_corte`, `id_operacion`, `producto`, `activo_pasivo`, `moneda`, `saldo`, `tasa`, `tipo_tasa`, `indice_referencia`, `spread`, `fecha_inicio`, `fecha_vencimiento`, `fecha_reprecio`, `dias`, `banda` | `saldo`, `tasa` | Qué está expuesto a tasa: saldo, tasa, reprecio y vencimiento por operación. |
| **Flujos proyectados** (`flujos`) | operación × fecha de flujo | `id_operacion`, `fecha_corte`, `fecha_flujo`, `moneda`, `amortizacion`, `interes`, `flujo`, `banda` | `flujo`, `amortizacion` | Lo que se descuenta para el EVE y se proyecta para el NII. |
| **Choques de tasa por escenario** (`escenarios`) | escenario × moneda × tenor | `escenario`, `moneda`, `tenor`, `retorno` | `retorno` | Los seis escenarios estándar (y los internos). |
| **ΔEVE y ΔNII reportados** (`resultados`) | escenario × moneda | `fecha_corte`, `escenario`, `moneda`, `eve`, `nii`, `limite` | `eve`, `nii` | Lo que se reporta y se compara con límites y con el SOT. |
| **Balance contable** (`contabilidad`) · solo si el archivo se llama así | corte × moneda × rubro | `fecha_corte`, `fecha`, `moneda`, `producto`, `cuenta_contable`, `saldo` | `saldo` | Prueba que lo modelado es todo el balance (y solo el balance). |

**Qué puede fallar en los datos**

- Posiciones a tasa variable sin índice o sin próxima fecha de reprecio: caen en la banda de su vencimiento y el gap se desplaza al largo plazo.
- Reprecio posterior al vencimiento, o vencimientos pasados en cartera viva (cartera vencida sin tratar).
- Banda asignada que no corresponde a los días al reprecio/vencimiento.
- Balance incompleto: lo modelado no cuadra con contabilidad por moneda (faltan productos o fuera de balance).
- Flujos de capital que no suman el saldo de la operación (amortizaciones mal generadas).
- Convención de signo de activos y pasivos mezclada: el gap cambia de signo.
- Supuestos conductuales (NMD, prepago) aplicados sobre saldos distintos de los del balance.
- Faltan escenarios estándar o monedas significativas.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `posiciones` · saldo | `completitud` | Todas las posiciones tienen saldo. | una posición sin saldo no entra en el gap. | ALTA |
| `posiciones` · saldo | `no_negativos` | Los saldos son positivos (el lado va en activo/pasivo). | si el sistema guarda los pasivos en negativo, cambia este control por `signo_por_categoria`. | MEDIA |
| `posiciones` · tasa | `completitud` | Todas las posiciones tienen tasa. | sin tasa no hay flujo de interés ni NII. | ALTA |
| `posiciones` · tasa | `rango` | La tasa está en un rango razonable (0–1 o 0–100 según la escala). | tasas fuera de escala multiplican el NII. | ALTA |
| `posiciones` · moneda | `completitud` | Todas las posiciones tienen moneda. | el IRRBB se mide por moneda: sin ella la posición no tiene curva. | ALTA |
| `posiciones` · tipo_tasa | `completitud` | Todas las posiciones dicen si son a tasa fija o variable. | decide si la banda la marca el reprecio o los flujos. | ALTA |
| `posiciones` · tipo_tasa, indice_referencia | `completitud_condicional` | Las posiciones a tasa variable tienen índice de referencia. | sin índice no se sabe con qué tasa reprecian. | ALTA |
| `posiciones` · tipo_tasa, fecha_reprecio | `completitud_condicional` | Las posiciones a tasa variable tienen próxima fecha de reprecio. | sin reprecio caen en la banda del vencimiento y el gap se desplaza al largo plazo. | ALTA |
| `posiciones` · fecha_inicio, fecha_corte | `consistencia_fechas` | Ninguna operación nace después del corte. | una operación del futuro no está en el balance de hoy. | ALTA |
| `posiciones` · fecha_corte, fecha_vencimiento | `consistencia_fechas` | No hay vencimientos pasados en la cartera viva. | una posición vencida no proyecta flujos (o es cartera vencida y debe tratarse aparte). | MEDIA |
| `posiciones` · fecha_reprecio, fecha_vencimiento | `consistencia_fechas` | El reprecio no es posterior al vencimiento. | una operación no puede repreciar después de vencer. | ALTA |
| `posiciones` · fecha_corte, fecha_reprecio | `consistencia_fechas` | La próxima fecha de reprecio no es anterior al corte. | un reprecio pasado debió actualizarse. | MEDIA |
| `posiciones` · banda | `completitud` | Toda posición tiene banda temporal. | sin banda la posición no entra en el gap. | ALTA |
| `posiciones` · dias, banda | `banda_coherente` (plantilla) | La banda asignada corresponde a los días al reprecio o al vencimiento. | una banda mal asignada mueve el gap; completa `limites` y `etiquetas` con las bandas del manual. | ALTA |
| `posiciones` · id_operacion, (fecha_corte) | `unicidad` | Cada operación aparece una vez por corte. | una operación duplicada se cuenta dos veces en su banda e infla el gap y el ΔEVE. | ALTA |
| `posiciones` · saldo → `contabilidad` | `conciliacion_totales` | El saldo modelado cuadra con el balance contable. | si no cuadra, el ΔEVE y el ΔNII miden otro balance. | ALTA |
| `posiciones` · saldo, moneda → `contabilidad` | `conciliacion_por_grupo` | El saldo cuadra con el balance en cada moneda. | el riesgo se mide por moneda: un cuadre global puede esconder descuadres que se compensan. | ALTA |
| `flujos` · flujo | `completitud` | Todos los flujos proyectados están informados. | un flujo nulo desaparece del valor presente. | ALTA |
| `flujos` · fecha_corte, fecha_flujo | `consistencia_fechas` | No se proyectan flujos anteriores al corte. | un flujo pasado no es riesgo futuro. | ALTA |
| `flujos` · id_operacion → `posiciones` | `integridad` | Cada flujo pertenece a una posición del corte. | flujos huérfanos inflan el EVE. | ALTA |
| `posiciones` · id_operacion → `flujos` | `integridad` | Cada posición tiene sus flujos proyectados. | una posición sin flujos no aporta al EVE. | ALTA |
| `flujos` · amortizacion, id_operacion → `posiciones` | `conciliacion_por_grupo` | La suma de la amortización de capital de cada operación es su saldo. | si los flujos de capital no suman el saldo, el modelo proyecta otra operación. | ALTA |
| `resultados` · eve | `completitud` | Hay ΔEVE para cada escenario y moneda. | un escenario sin resultado no entra en el SOT. | ALTA |
| `resultados` · nii | `completitud` | Hay ΔNII para cada escenario y moneda. | un escenario sin resultado no entra en el límite de margen. | ALTA |
| `resultados` · escenario, moneda | `combinaciones_completas` | Cada escenario tiene resultado en cada moneda. | el SOT se calcula con todas las monedas significativas. | ALTA |
| `escenarios` · escenario, tenor, (moneda) | `combinaciones_completas` | Cada escenario define el choque en todos los nodos. | un nodo sin choque queda con la curva base. | ALTA |

**Análisis del repositorio (ids `D…`)**

- `alm/gap_reprecios.py` — Ninguna banda de reprecio debe presentar un descalce \|activos − pasivos\| superior al límite sobre el total de activos.
- `alm/delta_eve.py` — La máxima caída del valor económico (ΔEVE) entre los escenarios de shock no debe exceder el 15% del capital de nivel 1 (outlier IRRBB).
- `alm/escenarios_irrbb_completos.py` — El análisis IRRBB debe cubrir los seis escenarios supervisores: paralelo ↑/↓, empinamiento, aplanamiento, tasa corta ↑/↓.
- `alm/sot_eve_tier1.py` — El peor ΔEVE (en valor absoluto) entre los escenarios de shock no debe superar el 15% del capital de Nivel 1 (prueba del valor atípico supervisor).
- `alm/brecha_duracion.py` — La brecha de duración (duración del activo − duración del pasivo) debe mantenerse dentro del límite fijado por el ALCO.
- `alm/delta_nii.py` — La caída del margen financiero (ΔNII) a 12 meses ante el shock de tasa no debe exceder el límite de apetito (% del NII base).

**Qué pedir a la primera línea**

1. Reglas de asignación a bandas (reprecio vs vencimiento) y las bandas del manual.
2. Curvas de descuento por moneda y si incluyen spread comercial.
3. Supuestos conductuales aplicados (NMD, prepago, cancelación) y su fuente.
4. Tratamiento de cartera vencida, fuera de balance y posiciones sin vencimiento.
5. Cuadre de la base del IRRBB con el balance por moneda y rubro.
6. Escenarios internos adicionales y tamaño de los choques por moneda.
7. Capital Tier 1 usado en el SOT y límites internos de ΔEVE y ΔNII.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea posiciones, flujos, choques, resultados y balance; por moneda y producto. Identifica qué productos tienen supuestos conductuales y de qué modelo vienen.
- **01 · Control de datos:** Tipo de tasa, índice y reprecio en las variables; fechas coherentes; bandas coherentes con días. Cuadre con el balance (total y por moneda) y flujos de capital que suman el saldo.
- **02 · Modelamiento:** Replica el gap de reprecio por banda y moneda (activos − pasivos). Replica el ΔEVE: descuenta los flujos con la curva base y con cada escenario; ΔEVE = VP(choque) − VP(base). Replica el ΔNII a 12 meses: Σ gap de las bandas < 1 año × choque × (1 − punto medio de la banda). Comprueba el SOT: máximo ΔEVE negativo ÷ Tier 1 frente al 15 %.
- **03 · Impactos:** Impacto en ΔEVE/ΔNII de reasignar bandas mal asignadas, completar reprecios faltantes y cuadrar el balance; ¿cambia el escenario peor o el SOT?
- **04 · Seguimiento:** Evolución de ΔEVE/Tier 1 y ΔNII frente a límites y alertas. Backtesting de supuestos conductuales y del NII proyectado contra el realizado.

**Métricas que se replican (02) y vigilan (04):** Gap de reprecio por banda; ΔEVE por escenario; ΔNII 12 meses; SOT ΔEVE/Tier 1.

**Referencias:** BCBS 368 (IRRBB, 2016): bandas temporales, seis escenarios, SOT ΔEVE/Tier 1 > 15 %; EBA/GL/2022/14 (IRRBB y CSRBB); Supuestos conductuales: NMD, prepago y cancelación.

### Prepago de créditos (modelo conductual de prepago, MCP) (`prepago`)

*Familia ALM · repositorio `alm/`*

**Qué hace el modelo.** Estima qué parte de la cartera de créditos (hipotecarios, consumo, comerciales) se paga antes de lo pactado. SMM = prepago del mes ÷ (saldo al inicio − amortización programada); CPR = 1 − (1 − SMM)^12. Se segmenta por producto, moneda, tipo de tasa, antigüedad (seasoning) e incentivo (tasa del crédito − tasa de mercado), y alimenta los flujos del IRRBB y de liquidez: más prepago acorta la vida de los activos y reduce el margen futuro.

**Qué produce:** SMM y CPR por segmento; Curva de prepago por antigüedad; Flujos con prepago.

**Para qué se usa:** IRRBB (flujos de activos); Brechas de liquidez; Pricing y proyección de margen.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Saldos mensuales por segmento o cosecha** (`saldos`) | mes × segmento (× cosecha) | `fecha`, `segmento`, `producto`, `moneda`, `cosecha`, `saldo_inicial`, `amortizacion`, `prepago`, `saldo_final`, `num_cuentas`, `tasa`, `tasa_mercado`, `cpr` | `prepago`, `saldo_inicial` | De aquí sale el SMM/CPR observado. |
| **Créditos (nivel operación)** (`operaciones`) | crédito | `id_operacion`, `segmento`, `producto`, `moneda`, `fecha_inicio`, `fecha_vencimiento`, `fecha_cierre`, `saldo`, `nominal`, `tasa`, `indicador_cancelacion` | `nominal`, `saldo` | Para reconstruir el prepago desde el detalle. |
| **Tasas de prepago del modelo** (`modelo`) | segmento × plazo | `segmento`, `plazo_meses`, `edad`, `cpr` | `cpr` | Lo que el modelo usa en las proyecciones. |

**Qué puede fallar en los datos**

- Prepagos parciales y totales mezclados con amortización programada o con refinanciaciones.
- Saldo final ≠ saldo inicial − amortización − prepago (desembolsos o castigos mezclados).
- Huecos de meses o segmentos en la serie: el SMM promedio se calcula sobre menos meses.
- Prepagos mayores que el saldo, o negativos (reversiones).
- Refinanciaciones o compras de deuda que aparecen como prepago (o al revés).
- Segmentos que cambian de definición en el tiempo.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `saldos` · prepago | `completitud` | El prepago está informado en cada mes y segmento. | un mes sin dato baja (o sube) el SMM promedio. | ALTA |
| `saldos` · prepago | `no_negativos` | No hay prepagos negativos. | un negativo suele ser una reversión que debe ir aparte. | ALTA |
| `saldos` · prepago, saldo_inicial | `consistencia` | El prepago no supera el saldo al inicio. | no se puede prepagar más de lo que se debe. | ALTA |
| `saldos` · saldo_inicial, amortizacion, prepago, saldo_final | `relacion_aritmetica` | Saldo final = saldo inicial − amortización − prepago. | si no cuadra hay desembolsos, castigos o refinanciaciones mezclados (decláralos o sepáralos). | ALTA |
| `saldos` · cpr | `rango` | El SMM/CPR está entre 0 y 1 (o 0 y 100). | un CPR fuera de rango rompe la curva conductual. | ALTA |
| `saldos` · fecha, segmento | `combinaciones_completas` | Cada segmento tiene dato en todos los meses. | un panel incompleto sesga el SMM por segmento. | ALTA |
| `saldos` · fecha, segmento, (cosecha), (moneda) | `unicidad` | Un registro por mes y segmento (y cosecha). | duplicados duplican el prepago. | ALTA |
| `saldos` · fecha | `serie_continua` | No faltan meses en la serie. | el modelo se calibra con meses consecutivos. | ALTA |
| `saldos` · prepago, fecha, segmento | `saltos_serie` | Sin saltos anómalos de prepago por segmento. | un salto suele ser una refinanciación masiva o una compra de cartera mal clasificada. | MEDIA |
| `operaciones` · fecha_inicio, fecha_cierre | `consistencia_fechas` | La cancelación no es anterior al desembolso. | fechas invertidas generan vidas negativas. | ALTA |
| `operaciones` · fecha_inicio, fecha_vencimiento | `consistencia_fechas` | El desembolso es anterior al vencimiento. | un crédito no puede vencer antes de nacer. | ALTA |
| `operaciones` · id_operacion | `unicidad` | Cada crédito aparece una vez. | duplicados duplican el prepago. | ALTA |
| `modelo` · cpr | `rango` | Las tasas del modelo están entre 0 y 1 (o 0 y 100). | un parámetro fuera de rango invalida la proyección. | ALTA |
| `modelo` · segmento → `saldos` | `integridad` | Cada segmento del modelo tiene historia observada. | un segmento sin historia no se puede calibrar ni hacer backtesting. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `alm/cpr_prepago.py` — La tasa de prepago observada (CPR = prepagos / saldo) debe caer dentro de la banda esperada del modelo conductual.
- `alm/smm_cpr_consistencia.py` — El SMM/CPR reportado es el que sale de los saldos: SMM = prepago ÷ (saldo inicial − amortización programada) y CPR = 1 − (1 − SMM)^12.
- `alm/backtesting_prepago.py` — El CPR modelado debe seguir de cerca al observado: el error absoluto medio (MAE) entre ambos no debe superar la tolerancia.

**Qué pedir a la primera línea**

1. Definición operativa de prepago (parcial, total, refinanciación, compra de deuda).
2. Segmentación y variables explicativas del modelo; ventana de calibración.
3. Cómo se separan desembolsos, castigos y reprogramaciones en la serie.
4. Cómo entra el CPR en las proyecciones del IRRBB y de liquidez.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea la serie mensual por segmento/cosecha (saldo inicial, amortización, prepago, saldo final) y el detalle por crédito si existe.
- **01 · Control de datos:** Identidad del saldo, prepagos ≤ saldo, panel completo y segmentos estables en el tiempo.
- **02 · Modelamiento:** Replica SMM = prepago ÷ (saldo inicial − amortización) y CPR = 1 − (1 − SMM)^12 por segmento y mes. Re-estima el modelo con las mismas variables (incentivo de tasa, antigüedad, estacionalidad) y compara parámetros y CPR ajustado.
- **03 · Impactos:** Impacto de las fallas (meses faltantes, refinanciaciones como prepago) en el CPR y en ΔEVE/flujos.
- **04 · Seguimiento:** Backtesting: CPR proyectado vs observado por segmento (sesgo y error medio absoluto). Estabilidad de la población (PSI) y de los parámetros.

**Métricas que se replican (02) y vigilan (04):** SMM / CPR por segmento; Error del CPR proyectado vs observado.

**Referencias:** BCBS 368 (supuestos conductuales de prepago); EBA/GL/2022/14.

### Depósitos sin vencimiento (NMD): núcleo, decaimiento y beta (`nmd`)

*Familia ALM · repositorio `alm/`*

**Qué hace el modelo.** Ahorros, cuentas corrientes y CTS no tienen vencimiento contractual: el cliente puede retirar en cualquier momento, pero una parte se queda años (núcleo o core). El modelo separa el saldo en porción estable y volátil, estima la curva de decaimiento (cuánto queda tras k meses) y la vida media, y el beta: qué parte de un cambio de las tasas de mercado se traslada a la tasa pagada. Alimenta el IRRBB (en qué bandas reprecia el núcleo) y la liquidez.

**Qué produce:** % núcleo por segmento; Curva de decaimiento; Vida media; Beta de traspaso.

**Para qué se usa:** IRRBB (bandas del núcleo); Liquidez; Pricing de depósitos.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Serie de saldos por segmento** (`saldos`) | fecha × segmento × moneda | `fecha`, `segmento`, `producto`, `moneda`, `saldo`, `num_cuentas`, `tasa_pagada`, `tasa_mercado` | `saldo` | De aquí salen el núcleo, el decaimiento y el beta. |
| **Cuentas (nivel cuenta)** (`cuentas`) | cuenta | `id_operacion`, `segmento`, `moneda`, `fecha_inicio`, `fecha_cierre`, `estado`, `saldo` | `saldo`, `fecha_inicio` | Supervivencia de cuentas y análisis por cliente. |
| **Parámetros del modelo** (`modelo`) | segmento | `segmento`, `core`, `vida_media`, `beta`, `banda` | `core`, `beta`, `vida_media` | Lo que el modelo entrega al IRRBB. |

**Qué puede fallar en los datos**

- Migraciones entre productos, fusiones de cuentas o reclasificaciones que parecen salidas masivas.
- Saldos de cierre de mes inflados por pagos de planilla o CTS (estacionalidad mal tratada).
- Segmentos que cambian de definición; panel fecha × segmento incompleto.
- Ventana que no incluye periodos de estrés de tasas o de liquidez.
- Tasas pagadas que no corresponden al producto (promedios ponderados mal calculados).
- Núcleo o vida media por encima de los topes regulatorios.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `saldos` · saldo | `completitud` | La serie de saldos está completa. | un hueco parece una caída de saldo. | ALTA |
| `saldos` · saldo | `no_negativos` | No hay saldos negativos. | un depósito no es negativo. | ALTA |
| `saldos` · fecha, segmento | `combinaciones_completas` | Cada segmento tiene dato en todas las fechas. | el núcleo se estima por segmento con la serie completa. | ALTA |
| `saldos` · fecha, segmento, (moneda), (producto) | `unicidad` | Un registro por fecha y segmento (y moneda). | duplicados duplican el saldo. | ALTA |
| `saldos` · saldo, fecha, segmento | `saltos_serie` | Sin saltos de saldo anómalos por segmento. | una migración o fusión de cuentas parece un retiro masivo y baja el núcleo: cada salto se explica. | ALTA |
| `saldos` · saldo, fecha, segmento | `valores_repetidos` | El saldo no se repite idéntico varios periodos. | un saldo copiado esconde la volatilidad real. | MEDIA |
| `saldos` · segmento | `minimo_por_grupo` | Cada segmento tiene al menos 36 periodos de historia. | el decaimiento y el beta necesitan una ventana larga que incluya ciclos de tasas. | MEDIA |
| `saldos` · tasa_pagada | `completitud` | La tasa pagada está informada. | sin ella no se estima el beta. | MEDIA |
| `saldos` · num_cuentas | `no_negativos` | El número de cuentas no es negativo. | un conteo negativo es un error de carga. | BAJA |
| `cuentas` · fecha_inicio, fecha_cierre | `consistencia_fechas` | El cierre no es anterior a la apertura. | vidas negativas en la supervivencia. | ALTA |
| `cuentas` · estado, fecha_cierre | `completitud_condicional` | Las cuentas cerradas tienen fecha de cierre. | una cuenta cerrada sin fecha queda como censurada y alarga la vida media. | MEDIA |
| `cuentas` · id_operacion | `unicidad` | Cada cuenta aparece una vez. | duplicados distorsionan la supervivencia. | ALTA |
| `modelo` · beta | `rango` | El beta está entre 0 y 1. | un beta fuera de [0, 1] no tiene sentido económico. | ALTA |
| `modelo` · core | `rango` | El núcleo está entre 0 y 1 (o 0 y 100). | un núcleo fuera de rango es un error. | ALTA |
| `modelo` · vida_media | `no_negativos` | La vida media no es negativa. | una vida media negativa es un error de cálculo que movería el núcleo a bandas imposibles. | ALTA |
| `modelo` · segmento → `saldos` | `integridad` | Cada segmento del modelo tiene historia. | un segmento sin historia no se puede calibrar. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `alm/runoff_curvas.py` — La curva de run-off del modelo es coherente: la supervivencia S(t) empieza en 1 y nunca sube, el run-off acumulado es R(t) = 1 − S(t), el desgaste incremental d(t) = S(t−1) − S(t) no es negativo y suma el acumulado; se informa el componente estable (S al último plazo) y el plazo económico (∫ S(t) dt hasta el último plazo).
- `alm/runoff_supervivencia_saldos.py` — La curva de supervivencia del modelo se reproduce con la historia: por cosechas, S(k) = Π (Σ saldo(j) ÷ Σ saldo(j−1)) sobre las cosechas observadas en ambos meses, o el run-off del saldo existente en cada corte (`curva_de`, según el manual); si solo hay saldo total, un ajuste exponencial; la diferencia con la curva del modelo en cada plazo no supera la tolerancia.
- `alm/decaimiento_nmd.py` — Los depósitos sin vencimiento (NMD) deben mostrar un núcleo estable: la proporción de saldo que permanece (mín/promedio) por encima del umbral 'core'.
- `alm/vida_media_nmd.py` — La vida media asumida para los depósitos sin vencimiento (NMD) debe ser positiva y no superar el tope prudencial (típicamente 5 años).
- `alm/nucleo_topes_bcbs.py` — El núcleo estable de los depósitos sin vencimiento y su vencimiento medio no superan los topes de BCBS 368: minorista transaccional 90 % y 5 años; minorista no transaccional 70 % y 4,5 años; mayorista 50 % y 4 años.
- `alm/beta_deposito.py` — El beta de traspaso (deposit beta = sensibilidad de la tasa del depósito a la tasa de mercado) debe estar en [0,1] y dentro de la banda esperada del modelo.
- `alm/supervivencia_km.py` — La supervivencia observada de las cuentas (Kaplan–Meier, tratando como censuradas las que siguen abiertas) es coherente con la curva del modelo a 12, 24 y 60 meses, segmento a segmento si ambos lo traen (en un run-off de saldos, la de cuentas es un contraste: no tiene por qué coincidir).

**Qué pedir a la primera línea**

1. Segmentación (transaccional/no transaccional, minorista/mayorista) y su criterio.
2. Método del núcleo (mínimo histórico, percentil, tendencia) y ventana.
3. Tratamiento de migraciones, CTS, planillas y estacionalidad.
4. Cómo se reparte el núcleo en bandas de reprecio y su vencimiento máximo.
5. Estimación del beta (variables, rezagos, asimetría al alza y a la baja).

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea la serie de saldos por segmento y moneda, el detalle por cuenta y los parámetros del modelo.
- **01 · Control de datos:** Panel completo, saltos por migraciones, estacionalidad y tasas pagadas por segmento.
- **02 · Modelamiento:** Replica el núcleo (p. ej. mínimo ÷ promedio o percentil de la caída) y la curva de decaimiento (ajuste exponencial: ln(S_t/S_0) = −λ·t; vida media ≈ 1/λ). Replica el beta: regresión de Δtasa pagada sobre Δtasa de mercado. Comprueba los topes de núcleo y vencimiento de BCBS 368 por categoría.
- **03 · Impactos:** Impacto en ΔEVE/ΔNII de corregir los saltos por migraciones y de aplicar los topes.
- **04 · Seguimiento:** Saldos observados vs proyectados por el decaimiento; estabilidad del beta.

**Métricas que se replican (02) y vigilan (04):** % núcleo; Tasa de decaimiento λ y vida media; Beta; Error de proyección del saldo.

**Referencias:** BCBS 368: topes al núcleo — minorista transaccional ≤ 90 % y 5 años; minorista no transaccional ≤ 70 % y 4,5 años; mayorista ≤ 50 % y 4 años; EBA/GL/2022/14.

### Cancelación anticipada y renovación de depósitos a plazo (`cancelacion_dpf`)

*Familia ALM · repositorio `alm/`*

**Qué hace el modelo.** Los depósitos a plazo tienen vencimiento, pero el cliente puede cancelarlos antes (a veces con penalidad) o renovarlos al vencer. El modelo estima la tasa de cancelación anticipada (por plazo, segmento y diferencial de tasas) y la de renovación; ambas cambian los flujos de liquidez y la banda de reprecio en el IRRBB.

**Qué produce:** Tasa mensual de cancelación anticipada; Tasa de renovación; Flujos ajustados.

**Para qué se usa:** Liquidez (salidas antes del vencimiento); IRRBB (reprecio anticipado).

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Depósitos a plazo** (`depositos`) | depósito | `id_operacion`, `segmento`, `moneda`, `fecha_inicio`, `fecha_vencimiento`, `fecha_cierre`, `saldo`, `tasa`, `indicador_cancelacion`, `indicador_renovacion` | `saldo`, `fecha_vencimiento` | Vida contractual vs vida real de cada depósito. |
| **Tasas observadas por mes** (`tasas`) | mes × segmento | `fecha`, `segmento`, `tasa_salida`, `saldo` | `tasa_salida` | La tasa de cancelación que se calibra. |

**Qué puede fallar en los datos**

- Cancelaciones sin fecha, o fechas de cierre posteriores al vencimiento.
- Renovaciones automáticas registradas como depósitos nuevos (se pierde la historia).
- Mezcla de cancelaciones con penalidad y sin penalidad.
- Marca de cancelación con valores no estándar.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `depositos` · fecha_inicio, fecha_vencimiento | `consistencia_fechas` | El inicio es anterior al vencimiento. | un plazo negativo es un error. | ALTA |
| `depositos` · fecha_inicio, fecha_cierre | `consistencia_fechas` | El cierre no es anterior al inicio. | un cierre antes del inicio da vidas negativas y una tasa de cancelación falsa. | ALTA |
| `depositos` · indicador_cancelacion, fecha_cierre | `completitud_condicional` | Los depósitos cancelados tienen fecha de cierre. | sin fecha no se sabe cuándo salió el dinero. | ALTA |
| `depositos` · id_operacion | `unicidad` | Cada depósito aparece una vez. | duplicados duplican salidas. | ALTA |
| `depositos` · saldo | `no_negativos` | Los saldos no son negativos. | un depósito no es negativo. | ALTA |
| `depositos` · tasa | `rango` | La tasa está en un rango razonable. | una tasa fuera de escala (porcentaje leído como decimal) distorsiona el incentivo a cancelar. | MEDIA |
| `tasas` · tasa_salida | `rango` | La tasa de cancelación está entre 0 y 1 (o 0 y 100). | fuera de rango es un error de cálculo. | ALTA |
| `tasas` · fecha, segmento | `combinaciones_completas` | Cada segmento tiene tasa en todos los meses. | huecos sesgan la calibración. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `alm/cancelacion_anticipada.py` — La tasa mensual de cancelación anticipada observada (saldo cancelado antes del vencimiento ÷ saldo vivo) es coherente con la que usa el modelo.

**Qué pedir a la primera línea**

1. Definición de cancelación anticipada y de renovación; penalidades.
2. Cómo se identifican las renovaciones automáticas.
3. Segmentación y variables del modelo.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea depósitos con fechas de inicio, vencimiento y cierre, y las marcas de cancelación/renovación.
- **01 · Control de datos:** Fechas coherentes, cancelados con fecha, renovaciones identificadas, sin duplicados.
- **02 · Modelamiento:** Replica la tasa mensual de cancelación: saldo cancelado antes del vencimiento ÷ saldo vivo; y la tasa de renovación al vencimiento; compáralas con las del modelo.
- **03 · Impactos:** Impacto en flujos de liquidez y en ΔNII de las cancelaciones mal registradas.
- **04 · Seguimiento:** Cancelación observada vs modelada por segmento.

**Métricas que se replican (02) y vigilan (04):** Tasa de cancelación anticipada; Tasa de renovación.

**Referencias:** BCBS 368 (riesgo de redención anticipada de depósitos a plazo); EBA/GL/2022/14.

### Supervivencia / retiro de cuentas y saldos (MCR) (`supervivencia`)

*Familia ALM · repositorio `alm/`*

**Qué hace el modelo.** Modela cuánto tiempo «sobrevive» una cuenta o un saldo desde su apertura (análisis de supervivencia: Kaplan–Meier o riesgos proporcionales). Las cuentas aún abiertas al corte están CENSURADAS: no se sabe cuándo cerrarán y no pueden tratarse como cerradas ni excluirse. La curva resultante (proporción que sigue viva a k meses) alimenta el retiro de depósitos y la vida esperada. Si además se modela el SALDO (run-off acumulado, componentes estable y volátil, plazo económico y asignación a bandas), elige también el tipo «Run-off».

**Qué produce:** Curva de supervivencia por segmento; Vida esperada; Tasa de retiro por plazo.

**Para qué se usa:** Liquidez; IRRBB (vencimiento conductual); Rentabilidad de clientes.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Cuentas con apertura y cierre** (`cuentas`) | cuenta | `id_operacion`, `segmento`, `fecha_inicio`, `fecha_cierre`, `fecha_corte`, `evento`, `estado`, `saldo` | `fecha_inicio` | Duración de cada cuenta y si está censurada. |
| **Curva del modelo** (`curva`) | segmento × plazo | `segmento`, `plazo_meses`, `supervivencia` | `supervivencia` | Lo que el modelo entrega. |

**Qué puede fallar en los datos**

- Cuentas abiertas tratadas como cerradas (o excluidas): la supervivencia baja artificialmente.
- Fechas de cierre anteriores a la apertura o posteriores al corte.
- Reaperturas o migraciones contadas como cierres.
- Curva del modelo que sube en algún plazo.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `cuentas` · fecha_inicio, fecha_cierre | `consistencia_fechas` | El cierre no es anterior a la apertura. | una duración negativa rompe la curva de supervivencia (Kaplan–Meier). | ALTA |
| `cuentas` · fecha_inicio, fecha_corte | `consistencia_fechas` | Ninguna cuenta se abre después del corte. | una cuenta del futuro no tiene historia. | ALTA |
| `cuentas` · fecha_cierre | `fecha_futura` | No hay cierres posteriores a la fecha de referencia. | un cierre futuro es un error o una cuenta censurada mal codificada. | ALTA |
| `cuentas` · id_operacion | `unicidad` | Cada cuenta aparece una vez. | duplicados duplican eventos. | ALTA |
| `cuentas` · estado, fecha_cierre | `completitud_condicional` | Las cuentas cerradas tienen fecha de cierre. | sin fecha la cuenta queda como censurada. | MEDIA |
| `curva` · supervivencia, plazo_meses, (segmento) | `monotonia_curva` | La curva de supervivencia nunca sube. | una proporción que sobrevive no puede aumentar con el plazo. | ALTA |
| `curva` · supervivencia | `rango` | La supervivencia está entre 0 y 1 (o 0 y 100). | fuera de rango es un error. | ALTA |

**Análisis del repositorio (ids `D…`)**

- `alm/runoff_curvas.py` — La curva de run-off del modelo es coherente: la supervivencia S(t) empieza en 1 y nunca sube, el run-off acumulado es R(t) = 1 − S(t), el desgaste incremental d(t) = S(t−1) − S(t) no es negativo y suma el acumulado; se informa el componente estable (S al último plazo) y el plazo económico (∫ S(t) dt hasta el último plazo).
- `alm/supervivencia_km.py` — La supervivencia observada de las cuentas (Kaplan–Meier, tratando como censuradas las que siguen abiertas) es coherente con la curva del modelo a 12, 24 y 60 meses, segmento a segmento si ambos lo traen (en un run-off de saldos, la de cuentas es un contraste: no tiene por qué coincidir).

**Qué pedir a la primera línea**

1. Definición de cierre (y de reapertura).
2. Tratamiento de cuentas censuradas.
3. Método (Kaplan–Meier, Cox, paramétrico) y segmentación.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea cuentas con apertura, cierre, estado y corte; y la curva del modelo por segmento.
- **01 · Control de datos:** Fechas coherentes, censura correcta, cierres con fecha, sin duplicados.
- **02 · Modelamiento:** Replica Kaplan–Meier por segmento (S(t) = Π(1 − d_i/n_i)) y compárala con la curva del modelo.
- **03 · Impactos:** Impacto de tratar bien la censura en la vida esperada y en los flujos.
- **04 · Seguimiento:** Supervivencia observada de nuevas cohortes vs curva del modelo.

**Métricas que se replican (02) y vigilan (04):** S(t) a 12, 24 y 60 meses; Vida esperada.

**Referencias:** Kaplan y Meier (1958); BCBS 368 (supuestos conductuales).

### Precios de transferencia de fondos (FTP) (`ftp`)

*Familia ALM · repositorio `alm/`*

**Qué hace el modelo.** El FTP asigna a cada operación el costo (o beneficio) de los fondos según su plazo, moneda y perfil de reprecio, con una curva de transferencia (tasa base + prima de liquidez y otros ajustes). Separa el margen comercial del riesgo de tasa y liquidez que gestiona Tesorería/ALM; un FTP mal asignado desplaza rentabilidad entre áreas.

**Qué produce:** Tasa FTP por operación; Margen comercial vs margen de transformación.

**Para qué se usa:** Rentabilidad por producto y área; Pricing; Gestión de liquidez interna.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Operaciones con su FTP** (`operaciones`) | operación | `id_operacion`, `producto`, `moneda`, `plazo_meses`, `tasa`, `tasa_ftp`, `fecha_inicio` | `tasa_ftp` | Qué FTP se asignó a cada operación. |
| **Curva FTP** (`curva_ftp`) | fecha × moneda × tenor | `fecha`, `moneda`, `tenor`, `tasa_ftp` | `tasa_ftp` | De dónde sale el FTP. |

**Qué puede fallar en los datos**

- FTP sin asignar o asignado con otro plazo.
- Curva FTP con nodos faltantes o rancios.
- Escala de tasas mezclada.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `operaciones` · tasa_ftp | `completitud` | Toda operación tiene FTP. | sin FTP la rentabilidad queda sin costo de fondos. | ALTA |
| `operaciones` · tasa_ftp | `rango` | El FTP está en un rango razonable. | un FTP fuera de escala traslada margen falso entre las áreas y Tesorería. | ALTA |
| `curva_ftp` · fecha, tenor, (moneda) | `combinaciones_completas` | Cada fecha tiene todos los nodos de la curva FTP. | un nodo faltante se interpola sin control. | MEDIA |
| `curva_ftp` · tasa_ftp, fecha, tenor | `valores_repetidos` | La curva FTP no se queda congelada. | una curva sin actualizar asigna costos viejos. | MEDIA |

**Qué pedir a la primera línea**

1. Construcción de la curva FTP y sus componentes.
2. Regla de asignación por producto (plazo contractual o conductual).

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea operaciones con su FTP y la curva FTP por moneda y tenor.
- **01 · Control de datos:** FTP completo, curva sin huecos ni congelada, escalas coherentes.
- **02 · Modelamiento:** Recalcula el FTP de una muestra interpolando la curva al plazo de cada operación y compáralo.
- **03 · Impactos:** Impacto en margen por producto de los FTP mal asignados.
- **04 · Seguimiento:** Evolución del margen de transformación y de la curva FTP.

**Métricas que se replican (02) y vigilan (04):** Diferencia FTP asignado vs recalculado.

**Referencias:** EBA/GL/2018/02 (sistemas de precios de transferencia, en la guía de IRRBB); BCBS — principios de gestión de liquidez (2008).

### Run-off: supervivencia y desgaste del saldo (vencimiento conductual) (`runoff`)

*Familia ALM · repositorio `alm/`*

**Qué hace el modelo.** El modelo de run-off es un modelo de SUPERVIVENCIA del saldo: estima a qué velocidad se retirará, vencerá o agotará en el tiempo el saldo de un producto financiero cuyo vencimiento contractual no representa su comportamiento real (ahorros, cuentas corrientes, CTS y otros depósitos sin vencimiento; también saldos revolventes como tarjetas o líneas). A partir de la experiencia histórica construye la curva de supervivencia S(t) —qué proporción del saldo sigue a los t meses—, el run-off acumulado R(t) = 1 − S(t) y el desgaste incremental de cada periodo d(t) = S(t−1) − S(t). Con ella separa el componente ESTABLE (el saldo que permanece por un periodo prolongado) del VOLÁTIL (el que tiende a retirarse rápido), calcula el PLAZO ECONÓMICO en el que se espera que el saldo se desgaste (vida media ≈ Σ S(t)·Δt) y distribuye las salidas esperadas en bandas mensuales, trimestrales o anuales. Esas bandas alimentan las brechas de liquidez y el IRRBB (reprecio del componente estable). La curva debe medirse sobre el saldo EXISTENTE (por cosechas o sin nuevo negocio): si se mezcla el dinero nuevo, el crecimiento esconde las salidas.

**Qué produce:** Curva de supervivencia S(t) por producto/segmento; Run-off acumulado R(t) y desgaste incremental d(t); Componentes estable y volátil; Plazo económico (vida media); Asignación del saldo a bandas temporales.

**Para qué se usa:** Brechas de liquidez con vencimientos conductuales; IRRBB: bandas de reprecio del componente estable; Precios de transferencia (FTP) por plazo económico; Planificación de fondeo.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Historia de saldos por producto/segmento (y cosecha)** (`saldos`) | fecha × segmento (× cosecha) | `fecha`, `segmento`, `producto`, `moneda`, `cosecha`, `edad`, `saldo`, `num_cuentas` | `saldo` | La experiencia histórica de la que sale la curva (mejor por cosechas: el saldo de cada cohorte mes a mes). |
| **Cuentas (apertura y cierre)** (`cuentas`) · solo si el archivo se llama así | cuenta | `id_operacion`, `segmento`, `fecha_inicio`, `fecha_cierre`, `estado`, `saldo` | `fecha_inicio` | Supervivencia a nivel cuenta (Kaplan–Meier) para contrastar la de saldos. |
| **Curva de run-off del modelo** (`curva`) | segmento × plazo | `segmento`, `producto`, `plazo_meses`, `supervivencia`, `runoff_acumulado`, `runoff_incremental` | `supervivencia`, `runoff_acumulado`, `runoff_incremental` | Lo que el modelo entrega: S(t), R(t) y d(t) por plazo. |
| **Componentes estable / volátil y plazo económico** (`componentes`) | segmento | `segmento`, `producto`, `core`, `volatil`, `vida_media`, `saldo` | `core`, `volatil`, `vida_media` | El resumen que usan Tesorería, el IRRBB y el FTP. |
| **Asignación del saldo a bandas** (`bandas`) | segmento × banda | `fecha`, `segmento`, `producto`, `moneda`, `banda`, `proporcion`, `saldo` | `proporcion` | Las salidas esperadas por banda mensual, trimestral o anual (insumo de las brechas). |
| **Balance contable** (`contabilidad`) · solo si el archivo se llama así | corte × moneda × rubro | `fecha_corte`, `fecha`, `moneda`, `producto`, `cuenta_contable`, `saldo` | `saldo` | Prueba que lo modelado es todo el balance (y solo el balance). |

**Qué puede fallar en los datos**

- Historia corta o sin periodos de estrés: el componente estable y la cola larga de la curva se extrapolan sin evidencia.
- Saldo nuevo mezclado con el existente: si la curva se mide sobre el saldo total y no por cosechas (o sin nuevo negocio), el crecimiento esconde las salidas y el run-off sale lento.
- Migraciones entre productos, fusiones de cuentas o reclasificaciones que parecen retiros (o entradas).
- Estacionalidad (CTS, gratificaciones, planillas, cierres de mes) leída como comportamiento.
- Cosechas con pocas cuentas o dominadas por grandes depositantes: la curva no representa al producto.
- Curva del modelo que sube en algún plazo, run-off acumulado que baja o desgaste incremental negativo.
- Componentes estable y volátil que no suman el saldo, o plazo económico incoherente con la curva.
- Asignación a bandas que no suma el 100 % del saldo o no cuadra con el balance.
- Cuentas cerradas sin fecha de cierre (o tratadas como vivas): la supervivencia se infla.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `saldos` · saldo | `completitud` | La historia de saldos está completa. | un periodo sin saldo parece un retiro total y acelera la curva. | ALTA |
| `saldos` · saldo | `no_negativos` | No hay saldos negativos. | un saldo negativo de un pasivo es un error de signo que deforma la supervivencia. | ALTA |
| `saldos` · fecha, segmento, (cosecha), (producto), (moneda) | `unicidad` | Un registro por periodo y segmento (y cosecha). | duplicados duplican el saldo de un periodo y la curva parece crecer. | ALTA |
| `saldos` · fecha, segmento | `combinaciones_completas` | Cada segmento tiene saldo en todos los periodos de la historia. | un panel incompleto mezcla segmentos con ventanas distintas en la misma curva. | ALTA |
| `saldos` · fecha | `serie_continua` | No faltan periodos (meses) en la historia. | la curva se encadena periodo a periodo: un hueco rompe el desgaste. | ALTA |
| `saldos` · saldo, fecha, segmento | `saltos_serie` | Sin saltos de saldo por migraciones, fusiones o reclasificaciones. | una migración parece un retiro masivo y acelera la curva; cada salto debe explicarse (se mide sobre el saldo total del segmento; por cosecha lo revisa el análisis de link ratios atípicos). | ALTA |
| `saldos` · saldo, fecha, segmento, (cosecha) | `valores_repetidos` | El saldo no se copia de un periodo a otro. | un saldo copiado esconde el desgaste real. | MEDIA |
| `saldos` · segmento | `minimo_por_grupo` | Cada segmento tiene al menos 36 periodos de historia. | la parte larga de la curva y el componente estable necesitan experiencia histórica larga. | ALTA |
| `saldos` · cosecha | `minimo_por_grupo` | Cada cosecha se observa al menos 12 periodos. | cosechas muy cortas no informan la supervivencia a plazos largos. | MEDIA |
| `saldos` · edad | `no_negativos` | La antigüedad de la cosecha no es negativa. | una edad negativa (observación antes del origen) es un error de la llave de cosecha. | MEDIA |
| `saldos` · saldo, fecha → `contabilidad` | `conciliacion_por_grupo` | Los saldos por segmento suman el total contable del producto en cada fecha. | si no cuadra, la curva se mide sobre otro universo; toda fecha descuadrada se explica. | ALTA |
| `cuentas` · fecha_inicio, fecha_cierre | `consistencia_fechas` | El cierre no es anterior a la apertura. | una duración negativa rompe la supervivencia a nivel cuenta. | ALTA |
| `cuentas` · estado, fecha_cierre | `completitud_condicional` | Las cuentas cerradas tienen fecha de cierre. | una cuenta cerrada sin fecha queda como viva y alarga la curva. | MEDIA |
| `cuentas` · id_operacion | `unicidad` | Cada cuenta aparece una vez. | una cuenta duplicada cuenta dos veces su retiro. | ALTA |
| `curva` · supervivencia | `rango` | La supervivencia está entre 0 y 1 (o 0 y 100). | una proporción del saldo fuera de rango es un error de cálculo o de escala. | ALTA |
| `curva` · supervivencia, plazo_meses, (segmento) | `monotonia_curva` | La curva de supervivencia nunca sube con el plazo. | sin nuevo negocio el saldo que sobrevive solo puede bajar. | ALTA |
| `curva` · runoff_acumulado, plazo_meses, (segmento) | `monotonia_curva` | El run-off acumulado nunca baja con el plazo. | lo que ya salió no vuelve: un acumulado que baja es un error de la curva. | ALTA |
| `curva` · runoff_incremental | `no_negativos` | El desgaste incremental de cada periodo no es negativo. | un desgaste negativo es una entrada disfrazada dentro de la curva de salidas. | ALTA |
| `curva` · runoff_acumulado | `rango` | El run-off acumulado está entre 0 y 1 (o 0 y 100). | un acumulado fuera de rango invalida la asignación a bandas. | ALTA |
| `curva` · plazo_meses, (segmento), (producto) | `unicidad` | Un punto de la curva por plazo (y segmento). | dos valores para el mismo plazo dejan ambigua la curva. | ALTA |
| `curva` · segmento → `saldos` | `integridad` | Cada segmento con curva tiene historia de saldos. | una curva sin historia es juicio experto y debe documentarse como tal. | MEDIA |
| `saldos` · segmento → `curva` | `integridad` | Cada segmento con saldo tiene su curva. | un segmento sin curva queda sin vencimiento conductual en las brechas. | ALTA |
| `componentes` · core | `rango` | El componente estable está entre 0 y 1 (o 0 y 100). | un componente estable fuera de rango es un error de cálculo. | ALTA |
| `componentes` · volatil | `rango` | El componente volátil está entre 0 y 1 (o 0 y 100). | un componente volátil fuera de rango es un error de cálculo. | ALTA |
| `componentes` · vida_media | `no_negativos` | El plazo económico no es negativo. | un plazo económico negativo llevaría el saldo a bandas imposibles. | ALTA |
| `bandas` · banda | `completitud` | Toda asignación tiene banda. | sin banda la salida esperada no entra en la brecha. | ALTA |
| `bandas` · proporcion | `no_negativos` | Las proporciones asignadas no son negativas. | una proporción negativa es una entrada disfrazada en el perfil de salidas. | ALTA |
| `bandas` · proporcion, segmento | `suma_por_grupo` | La asignación a bandas de cada segmento suma el 100 % del saldo. | si no suma 100 %, una parte del saldo queda sin vencimiento conductual (o se cuenta dos veces). | ALTA |
| `bandas` · saldo, fecha → `contabilidad` | `conciliacion_por_grupo` | El saldo asignado a bandas cuadra con el balance contable de ese corte. | lo que no se asigna a bandas no tiene salida esperada en la brecha. | ALTA |
| `bandas` · saldo, segmento → `componentes` | `conciliacion_por_grupo` | El saldo asignado a bandas de cada segmento es el saldo del segmento en los componentes. | si bandas y componentes parten de saldos distintos, la brecha y el IRRBB usan universos distintos. | MEDIA |
| `componentes` · core, volatil | `relacion_aritmetica` | Componente estable + volátil = 100 % del saldo. | si no suman el total, una parte del saldo no tiene comportamiento asignado (o se cuenta dos veces). | ALTA |

**Análisis del repositorio (ids `D…`)**

- `alm/runoff_curvas.py` — La curva de run-off del modelo es coherente: la supervivencia S(t) empieza en 1 y nunca sube, el run-off acumulado es R(t) = 1 − S(t), el desgaste incremental d(t) = S(t−1) − S(t) no es negativo y suma el acumulado; se informa el componente estable (S al último plazo) y el plazo económico (∫ S(t) dt hasta el último plazo).
- `alm/runoff_supervivencia_saldos.py` — La curva de supervivencia del modelo se reproduce con la historia: por cosechas, S(k) = Π (Σ saldo(j) ÷ Σ saldo(j−1)) sobre las cosechas observadas en ambos meses, o el run-off del saldo existente en cada corte (`curva_de`, según el manual); si solo hay saldo total, un ajuste exponencial; la diferencia con la curva del modelo en cada plazo no supera la tolerancia.
- `alm/runoff_saltos_cosechas.py` — Por segmento y edad, el link ratio de cada cosecha (saldo(k) ÷ saldo(k−1)) no se aleja más de k desviaciones robustas (y del desvío mínimo) del de las demás cosechas a esa edad; una fecha con varias cosechas atípicas a la vez señala una migración, fusión o reclasificación del producto.
- `alm/nucleo_topes_bcbs.py` — El núcleo estable de los depósitos sin vencimiento y su vencimiento medio no superan los topes de BCBS 368: minorista transaccional 90 % y 5 años; minorista no transaccional 70 % y 4,5 años; mayorista 50 % y 4 años.
- `alm/supervivencia_km.py` — La supervivencia observada de las cuentas (Kaplan–Meier, tratando como censuradas las que siguen abiertas) es coherente con la curva del modelo a 12, 24 y 60 meses, segmento a segmento si ambos lo traen (en un run-off de saldos, la de cuentas es un contraste: no tiene por qué coincidir).

**Qué pedir a la primera línea**

1. Producto(s) y segmentos modelados, y por qué su vencimiento contractual no representa su comportamiento.
2. Método de la curva: cosechas (link ratios), Kaplan–Meier de saldos o cuentas, ajuste paramétrico (exponencial, Weibull); ventana histórica y frecuencia.
3. Cómo se aísla el saldo existente del nuevo negocio (cosechas, stock al corte sin nuevas aperturas).
4. Definición del componente estable y del volátil (horizonte, umbral, mínimo histórico) y del plazo económico.
5. Bandas de asignación (mensuales, trimestrales, anuales), regla de asignación y horizonte máximo (topes).
6. Tratamiento de migraciones, estacionalidad (CTS, gratificaciones) y grandes depositantes.
7. Uso de la curva: brechas de liquidez, IRRBB (reprecio del componente estable), FTP, contingencia.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea la historia de saldos (frecuencia, ventana, segmentos, cosechas y su antigüedad), la curva del modelo (S, R, d por plazo), los componentes estable/volátil, el plazo económico y la asignación a bandas, y quién los usa (brechas, IRRBB, FTP). Comprueba si la historia permite aislar el saldo existente (cosechas) o solo hay saldo total, y ubica los eventos de la ventana (migraciones, fusiones, crisis).
- **01 · Control de datos:** Panel periodo × segmento (× cosecha) completo, sin saldos copiados y que cuadra con el balance; migraciones buscadas en el total del segmento y cosecha por cosecha (link ratio atípico frente a las demás cosechas de la misma edad). Curva coherente: S decreciente, R creciente, d ≥ 0, R = 1 − S; estable + volátil = 100 %; bandas que suman el 100 % y cuadran con el balance del corte y con los componentes.
- **02 · Modelamiento:** Replica la curva con la experiencia histórica: por cosechas, S(k) = Π_j (Σ saldo_c(j) ÷ Σ saldo_c(j−1)) sobre las cosechas observadas en j−1 y j, o el run-off del saldo existente en cada corte (según `curva_de` en SUPUESTOS: lo que dice el manual); si solo hay saldo total, ajuste exponencial S(t) = e^(−λt) como benchmark (mezcla el negocio nuevo). Deriva R(t) = 1 − S(t), d(t) = S(t−1) − S(t), el componente estable (S al horizonte largo), el volátil (1 − estable) y el plazo económico (∫ S(t) dt, al mismo horizonte en ambas curvas); compáralos con los del modelo. Recalcula la asignación del saldo a bandas, S(desde) − S(hasta), con la curva del modelo y con la histórica, y compárala con la del modelo.
- **03 · Impactos:** Cuantifica cuánto cambian el componente estable, el plazo económico y las salidas por banda (y la brecha acumulada) al corregir las migraciones, quitar el nuevo negocio o usar la ventana completa.
- **04 · Seguimiento:** Backtesting del saldo existente: las cosechas vivas hace 12 meses, mes a mes, frente a lo que proyecta la curva del modelo (sesgo y error medio en pp; negativo = sale más saldo del previsto). Estabilidad de la curva entre la primera y la segunda mitad de la historia, y salidas reales frente a las asignadas a cada banda.

**Métricas que se replican (02) y vigilan (04):** Curva S(t) por plazo; Run-off acumulado e incremental; Componente estable y volátil; Plazo económico (vida media); Asignación del saldo por banda; Error de backtesting por plazo.

**Referencias:** BCBS 368 (IRRBB, 2016): supuestos conductuales de depósitos sin vencimiento, componente estable y topes por categoría; EBA/GL/2022/14 (IRRBB/CSRBB): modelización de NMD; BCBS — principios de gestión del riesgo de liquidez (2008): supuestos conductuales en las brechas; Kaplan y Meier (1958); método de cosechas (link ratios) para curvas de saldo; Regulación local de brechas de liquidez e IRRBB con vencimientos conductuales.

### Ratio de cobertura de liquidez (RCL / LCR) (`lcr`)

*Familia Liquidez · repositorio `lar/`*

**Qué hace el modelo.** Exige activos líquidos de alta calidad (HQLA) suficientes para cubrir las salidas netas de un estrés de 30 días: LCR = HQLA ÷ (salidas − mín(entradas; 75 % de las salidas)) ≥ 100 %. Los HQLA se dividen en Nivel 1 (caja, encaje, soberanos: 0 % de descuento), 2A (15 %) y 2B (25–50 %), con topes: el Nivel 2 no puede pasar del 40 % del total y el 2B del 15 %. Cada pasivo tiene una tasa de salida según su estabilidad (minorista estable 3–5 %, menos estable 10 %, mayorista operativo 25 %, no operativo 40 %, financiero 100 %). La regulación local (RCL) sigue una lógica análoga: verifica sus factores.

**Qué produce:** LCR / RCL diario por moneda; HQLA ajustado por topes; Salidas y entradas ponderadas.

**Para qué se usa:** Cumplimiento regulatorio diario; Límites internos y alertas tempranas; Gestión del colchón de liquidez.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Activos líquidos (HQLA)** (`hqla`) | fecha × instrumento | `fecha`, `instrumento`, `moneda`, `nivel_hqla`, `valor_mercado`, `haircut`, `hqla` | `nivel_hqla`, `haircut` | El numerador: qué activos cuentan y con qué descuento. |
| **Salidas ponderadas** (`salidas`) | fecha × categoría | `fecha`, `moneda`, `categoria`, `saldo`, `tasa_salida`, `salidas` | `tasa_salida` | El denominador: cuánto sale en 30 días. |
| **Entradas ponderadas** (`entradas`) | fecha × categoría | `fecha`, `moneda`, `categoria`, `saldo`, `tasa_entrada`, `entradas` | `tasa_entrada` | Reducen el denominador (con tope del 75 %). |
| **Ratio reportado** (`ratio`) | fecha × moneda | `fecha`, `moneda`, `hqla`, `salidas`, `entradas`, `lcr`, `limite` | `lcr` | Lo que se reporta y se replica. |

**Qué puede fallar en los datos**

- Activos sin nivel o con descuento menor al regulatorio.
- Topes del Nivel 2 y 2B no aplicados.
- Entradas sin el tope del 75 %.
- Pasivos con tasa de salida inferior a la de su categoría.
- Activos gravados (en garantía) contados como HQLA.
- Días sin ratio o ratios negativos.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `hqla` · nivel_hqla | `completitud` | Todo activo líquido tiene nivel (1, 2A, 2B). | el nivel decide el descuento y los topes. | ALTA |
| `hqla` · haircut | `rango` | El descuento está entre 0 y 1 (o 0 y 100). | fuera de rango infla o anula el HQLA. | ALTA |
| `hqla` · valor_mercado | `no_negativos` | El valor de los activos líquidos no es negativo. | el HQLA es un stock: un valor negativo es un error de carga que reduce el colchón. | ALTA |
| `salidas` · tasa_salida | `completitud` | Toda categoría de pasivo tiene tasa de salida. | sin tasa la categoría no sale en el estrés. | ALTA |
| `salidas` · tasa_salida | `rango` | Las tasas de salida están entre 0 y 1 (o 0 y 100). | fuera de rango invalida el denominador. | ALTA |
| `salidas` · saldo | `no_negativos` | Los saldos de pasivos no son negativos. | un saldo negativo (signo mezclado) resta salidas y sobrestima el ratio. | ALTA |
| `entradas` · tasa_entrada | `rango` | Las tasas de entrada están entre 0 y 1 (o 0 y 100). | fuera de rango infla las entradas. | ALTA |
| `ratio` · lcr | `no_negativos` | El ratio no es negativo. | un LCR negativo es imposible. | ALTA |
| `ratio` · fecha | `serie_continua` | Hay ratio todos los días hábiles. | el cumplimiento es diario. | ALTA |
| `ratio` · fecha, (moneda) | `unicidad` | Un ratio por fecha (y moneda). | dos ratios el mismo día dejan ambiguo cuál se reportó. | ALTA |
| `ratio` · lcr, fecha, (moneda) | `saltos_serie` | El ratio no salta sin explicación. | un salto suele ser un cambio de clasificación o un error de carga. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `lar/horizonte_supervivencia.py` — La posición de liquidez ACUMULADA (entradas − salidas) no debe caer bajo el colchón en ningún bucket.
- `lar/lcr.py` — El LCR (HQLA / salidas netas de 30 días) debe ser >= 100% en todo periodo reportado.
- `lar/hqla_composicion.py` — Los activos líquidos de Nivel 2 no pueden superar el 40% del HQLA total, y los de Nivel 2B el 15% (tras haircuts).
- `lar/lcr_tope_entradas.py` — El LCR reportado es HQLA ÷ (salidas − mín(entradas; 75 % de las salidas)): las entradas no pueden cubrir más del 75 % de las salidas.

**Qué pedir a la primera línea**

1. Clasificación de activos por nivel y su sustento; activos gravados excluidos.
2. Tabla de tasas de salida y entrada por categoría y su fuente normativa.
3. Cómo se aplican los topes del Nivel 2/2B y de las entradas.
4. Límites internos y alertas.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea HQLA por nivel, salidas y entradas por categoría, y el ratio reportado por moneda.
- **01 · Control de datos:** Niveles y descuentos completos, tasas en rango y por categoría, ratio diario sin huecos.
- **02 · Modelamiento:** Recalcula el HQLA con descuentos y topes (Nivel 2 ≤ 40 %, 2B ≤ 15 %), las salidas y entradas ponderadas con el tope del 75 % y el ratio; compáralo con el reportado.
- **03 · Impactos:** Impacto en el ratio de reclasificar activos o categorías mal asignadas.
- **04 · Seguimiento:** Ratio diario frente al mínimo y a los límites internos; alertas tempranas y su gestión.

**Métricas que se replican (02) y vigilan (04):** LCR / RCL; HQLA ajustado; Salidas netas a 30 días.

**Referencias:** BCBS 238 (LCR, 2013): factores, descuentos y topes; Regulación local del ratio de cobertura de liquidez (RCL).

### Ratio de financiamiento neto estable (RFNE / NSFR) (`nsfr`)

*Familia Liquidez · repositorio `lar/`*

**Qué hace el modelo.** Compara el fondeo estable disponible (ASF: capital y pasivos ponderados por su estabilidad a un año) con el requerido (RSF: activos ponderados por su liquidez): NSFR = ASF ÷ RSF ≥ 100 %. Los factores ASF van de 0 % a 100 % (capital 100 %, depósitos minoristas estables 95 %, menos estables 90 %, mayoristas operativos 50 %); los RSF de 0 % (caja) a 100 % (activos ilíquidos).

**Qué produce:** NSFR / RFNE; ASF y RSF por rubro.

**Para qué se usa:** Cumplimiento regulatorio; Estructura de fondeo a mediano plazo.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Fondeo disponible (ASF)** (`asf`) | fecha × rubro | `fecha`, `categoria`, `saldo`, `factor_asf` | `factor_asf` | Numerador. |
| **Fondeo requerido (RSF)** (`rsf`) | fecha × rubro | `fecha`, `categoria`, `saldo`, `factor_rsf` | `factor_rsf` | Denominador. |
| **Ratio reportado** (`ratio`) | fecha | `fecha`, `nsfr`, `limite` | `nsfr` | Lo que se reporta. |
| **Balance contable** (`contabilidad`) · solo si el archivo se llama así | corte × moneda × rubro | `fecha_corte`, `fecha`, `moneda`, `producto`, `segmento`, `cuenta_contable`, `saldo` | `saldo` | Prueba que lo modelado es todo el balance (y solo el balance). |

**Qué puede fallar en los datos**

- Factores fuera de [0, 1] o que no son los de la norma.
- Rubros sin factor.
- ASF + RSF que no cuadran con el balance.
- Vencimientos mal asignados (< 6 meses, 6–12, > 1 año).

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `asf` · factor_asf | `rango` | Los factores ASF están entre 0 y 1 (o 0 y 100). | fuera de rango invalida el numerador. | ALTA |
| `asf` · factor_asf | `completitud` | Todo rubro tiene factor ASF. | sin factor el rubro no cuenta. | ALTA |
| `rsf` · factor_rsf | `rango` | Los factores RSF están entre 0 y 1 (o 0 y 100). | fuera de rango invalida el denominador. | ALTA |
| `rsf` · factor_rsf | `completitud` | Todo rubro tiene factor RSF. | sin factor el rubro no requiere fondeo. | ALTA |
| `asf` · saldo | `no_negativos` | Los saldos no son negativos. | un saldo con el signo cambiado resta fondeo estable disponible. | ALTA |
| `rsf` · saldo | `no_negativos` | Los saldos no son negativos. | un saldo con el signo cambiado resta fondeo requerido y sobrestima el ratio. | ALTA |
| `ratio` · nsfr | `no_negativos` | El ratio no es negativo. | un NSFR negativo es imposible: indica un error en ASF o RSF. | ALTA |

**Análisis del repositorio (ids `D…`)**

- `lar/nsfr.py` — El NSFR (fondeo estable disponible / requerido) debe ser >= 100%.
- `lar/factores_nsfr.py` — Los factores ASF y RSF aplicados son valores de la norma: ASF 0, 50, 90, 95 o 100 %; RSF 0, 5, 10, 15, 50, 65, 85 o 100 %.

**Qué pedir a la primera línea**

1. Tabla de factores ASF/RSF por rubro y su fuente.
2. Criterio de vencimiento residual por rubro.
3. Cuadre de la base con el balance.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea rubros con su saldo, vencimiento residual y factor ASF/RSF.
- **01 · Control de datos:** Factores en rango y de la norma, rubros completos, cuadre con el balance.
- **02 · Modelamiento:** Recalcula ASF = Σ saldo × factor, RSF = Σ saldo × factor y el ratio; compáralo.
- **03 · Impactos:** Impacto de los factores o vencimientos mal asignados en el ratio.
- **04 · Seguimiento:** Evolución del ratio frente al mínimo y a los límites.

**Métricas que se replican (02) y vigilan (04):** NSFR / RFNE; ASF; RSF.

**Referencias:** BCBS 295 (NSFR, 2014); Regulación local del ratio de financiamiento estable.

### Brechas (gaps) de liquidez contractuales y conductuales (`brechas_liquidez`)

*Familia Liquidez · repositorio `lar/`*

**Qué hace el modelo.** Reparte las entradas y salidas de efectivo (contractuales y con supuestos conductuales) en bandas temporales y calcula la brecha por banda y la acumulada. Una brecha acumulada negativa grande en las bandas cortas es una alerta de liquidez. Las bandas deben cubrir todo el balance y cuadrar con él.

**Qué produce:** Brecha por banda y moneda; Brecha acumulada; Consumo de límites de brecha.

**Para qué se usa:** Límites de liquidez por banda; Planificación de fondeo; Reporte regulatorio de brechas.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Flujos por banda** (`flujos`) | corte × banda × moneda × rubro | `fecha_corte`, `fecha_flujo`, `banda`, `dias`, `moneda`, `categoria`, `entradas`, `salidas`, `flujo`, `saldo` | `entradas`, `salidas`, `flujo` | La brecha por banda. |
| **Balance contable** (`contabilidad`) · solo si el archivo se llama así | corte × moneda × rubro | `fecha_corte`, `fecha`, `moneda`, `producto`, `segmento`, `cuenta_contable`, `saldo` | `saldo` | Prueba que lo modelado es todo el balance (y solo el balance). |

**Qué puede fallar en los datos**

- Flujos sin banda o con banda que no corresponde a su fecha.
- Signos mezclados entre entradas y salidas.
- Flujos anteriores al corte.
- Balance no cubierto por las bandas.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `flujos` · banda | `completitud` | Todo flujo tiene banda. | sin banda no hay brecha acumulada. | ALTA |
| `flujos` · entradas | `no_negativos` | Las entradas son magnitudes positivas. | el signo va en la columna: mezclar convenciones invierte la brecha. | MEDIA |
| `flujos` · salidas | `no_negativos` | Las salidas son magnitudes positivas. | el signo va en la columna: mezclar convenciones invierte la brecha. | MEDIA |
| `flujos` · fecha_corte, fecha_flujo | `consistencia_fechas` | No hay flujos anteriores al corte. | un flujo pasado no es liquidez futura. | ALTA |
| `flujos` · banda, moneda | `combinaciones_completas` | Todas las bandas existen en todas las monedas. | una banda vacía puede ser un hueco de carga. | BAJA |
| `flujos` · dias, banda | `banda_coherente` (plantilla) | La banda corresponde a los días al flujo. | completa `limites` y `etiquetas` con las bandas del manual. | ALTA |
| `flujos` · saldo → `contabilidad` | `conciliacion_totales` | El saldo repartido en bandas cuadra con el balance. | lo que no está en bandas no tiene brecha. | ALTA |

**Análisis del repositorio (ids `D…`)**

- `lar/brecha_liquidez_acumulada.py` — La brecha de liquidez acumulada (entradas−salidas, sumada por banda temporal en orden) no debe caer por debajo de cero dentro del horizonte.

**Qué pedir a la primera línea**

1. Bandas del manual y regla de asignación (contractual vs conductual).
2. Supuestos conductuales usados (NMD, prepago, renovaciones).
3. Límites por banda.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea flujos por banda, moneda y rubro, y el balance de referencia.
- **01 · Control de datos:** Bandas completas y coherentes con la fecha del flujo, signos, cuadre con el balance.
- **02 · Modelamiento:** Recalcula la brecha por banda (entradas − salidas) y la acumulada; compárala con la reportada.
- **03 · Impactos:** Impacto en la brecha acumulada de las bandas mal asignadas o del balance no cubierto.
- **04 · Seguimiento:** Brecha acumulada frente a límites y su evolución.

**Métricas que se replican (02) y vigilan (04):** Brecha por banda; Brecha acumulada.

**Referencias:** BCBS — principios de gestión del riesgo de liquidez (2008); Regulación local de liquidez (anexos de brechas).

### Liquidity at Risk (LaR, VaR de liquidez) (`lar`)

*Familia Liquidez · repositorio `lar/`*

**Qué hace el modelo.** LaR estima, con la historia de flujos netos diarios, la salida neta acumulada máxima esperada en un horizonte (p. ej. 30 días) con un nivel de confianza (95–99 %): un «VaR de liquidez». Se compara con el colchón de activos líquidos para saber si alcanza.

**Qué produce:** LaR por horizonte y moneda; Cobertura del colchón.

**Para qué se usa:** Dimensionar el colchón de liquidez; Límites internos.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Flujos netos diarios** (`flujos`) | fecha × moneda | `fecha`, `moneda`, `categoria`, `entradas`, `salidas`, `flujo_neto` | `flujo_neto`, `entradas`, `salidas` | La distribución de los flujos netos. |
| **LaR reportado** (`resultado`) | fecha × moneda | `fecha`, `moneda`, `lar_valor`, `limite` | `lar_valor` | Lo que se reporta. |

**Qué puede fallar en los datos**

- Huecos de días (la ventana móvil salta).
- Flujos duplicados por fecha.
- Saltos por operaciones extraordinarias no marcadas.
- Ventana corta sin estrés.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `flujos` · fecha | `serie_continua` | La serie diaria de flujos no tiene huecos. | la suma móvil del horizonte se rompe con los huecos. | ALTA |
| `flujos` · flujo_neto | `completitud` | El flujo neto está informado todos los días. | un nulo es un día sin salida aparente. | ALTA |
| `flujos` · fecha, (moneda), (categoria) | `unicidad` | Un flujo neto por fecha (y moneda). | duplicados duplican salidas. | ALTA |
| `flujos` · flujo_neto, fecha, (moneda) | `saltos_serie` | Sin saltos extraordinarios sin marcar. | una operación extraordinaria domina el percentil. | MEDIA |
| `flujos` ·  | `volumen_minimo` | La historia tiene al menos 500 días. | el percentil alto necesita ventana. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `lar/lar_percentil.py` — El LaR reportado es el percentil de las salidas netas acumuladas en el horizonte (suma móvil de los flujos netos), con la ventana y el nivel del manual.

**Qué pedir a la primera línea**

1. Horizonte, nivel de confianza y ventana.
2. Tratamiento de operaciones extraordinarias.
3. Comparación con el colchón y límites.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea la serie de flujos netos diarios por moneda y el LaR reportado.
- **01 · Control de datos:** Serie diaria completa, sin duplicados, operaciones extraordinarias marcadas.
- **02 · Modelamiento:** Replica el LaR: suma móvil de los flujos netos a h días y su percentil (pérdida en positivo).
- **03 · Impactos:** Impacto en el LaR de depurar los huecos y las operaciones extraordinarias.
- **04 · Seguimiento:** Salidas realizadas a h días frente al LaR (excedencias).

**Métricas que se replican (02) y vigilan (04):** LaR a h días; Excedencias del LaR.

**Referencias:** BCBS — principios de gestión del riesgo de liquidez (2008).

### Estrés de liquidez y horizonte de supervivencia (`stress_liquidez`)

*Familia Liquidez · repositorio `lar/`*

**Qué hace el modelo.** Proyecta día a día las salidas y entradas de un escenario de estrés (idiosincrático, sistémico y combinado) y calcula cuántos días alcanza el colchón de activos líquidos antes de agotarse: el horizonte de supervivencia. Usa tasas de run-off, de renovación y de descuento de activos.

**Qué produce:** Horizonte de supervivencia por escenario; Brecha diaria acumulada vs colchón.

**Para qué se usa:** Apetito de riesgo de liquidez; Plan de contingencia; Límites internos.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Proyección diaria por escenario** (`proyeccion`) | escenario × día | `escenario`, `fecha`, `dias`, `moneda`, `entradas`, `salidas`, `flujo_neto`, `hqla` | `salidas`, `entradas` | La brecha diaria bajo estrés. |

**Qué puede fallar en los datos**

- Días faltantes en la proyección.
- Escenarios incompletos.
- Signos mezclados.
- Colchón sin descuentos.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `proyeccion` · escenario, dias | `combinaciones_completas` | Cada escenario tiene todos los días del horizonte. | un día faltante esconde la salida de ese día. | ALTA |
| `proyeccion` · salidas | `no_negativos` | Las salidas son magnitudes positivas. | mezclar el signo de las salidas invierte la brecha diaria del estrés. | MEDIA |
| `proyeccion` · hqla | `no_negativos` | El colchón no es negativo. | el colchón es un stock: si es negativo, el horizonte de supervivencia sale falso. | ALTA |
| `proyeccion` · salidas | `completitud` | Las salidas están informadas. | un nulo es un día sin salida. | ALTA |

**Análisis del repositorio (ids `D…`)**

- `lar/horizonte_supervivencia.py` — La posición de liquidez ACUMULADA (entradas − salidas) no debe caer bajo el colchón en ningún bucket.
- `lar/runoff_tasas.py` — La tasa de salida en estrés de cada segmento es al menos el percentil histórico de las caídas de saldo en el horizonte (p. ej. 30 días al 99 %): r_t = 1 − S(t+h) ÷ S(t).
- `lar/hqla_composicion.py` — Los activos líquidos de Nivel 2 no pueden superar el 40% del HQLA total, y los de Nivel 2B el 15% (tras haircuts).
- `lar/concentracion_fondeo.py` — La financiación no debe depender en exceso de una sola contraparte: la mayor cuota de fondeo por proveedor debe estar por debajo del umbral.
- `lar/brecha_liquidez_acumulada.py` — La brecha de liquidez acumulada (entradas−salidas, sumada por banda temporal en orden) no debe caer por debajo de cero dentro del horizonte.

**Qué pedir a la primera línea**

1. Narrativa y severidad de cada escenario.
2. Tasas de run-off, renovación y descuento usadas.
3. Horizonte mínimo exigido por el apetito de riesgo.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea la proyección diaria por escenario y el colchón.
- **01 · Control de datos:** Días completos por escenario, signos, colchón con descuentos.
- **02 · Modelamiento:** Replica el horizonte: primer día en que las salidas netas acumuladas superan el colchón.
- **03 · Impactos:** Impacto en el horizonte de corregir las tasas de run-off o los días faltantes.
- **04 · Seguimiento:** Horizonte de supervivencia frente al apetito y su evolución.

**Métricas que se replican (02) y vigilan (04):** Horizonte de supervivencia (días); Peor escenario.

**Referencias:** BCBS — principios de gestión del riesgo de liquidez (2008); Regulación local de estrés de liquidez.

### Concentración de fondeo y principales depositantes (`concentracion_fondeo`)

*Familia Liquidez · repositorio `lar/`*

**Qué hace el modelo.** Mide cuánto del fondeo depende de pocos depositantes o grupos económicos (top 10, top 20, índice de Herfindahl). La salida de un gran depositante no es estadística: debe tratarse aparte del run-off minorista. Para medirla bien hay que identificar al mismo cliente bajo distintos códigos y agruparlo con sus vinculados.

**Qué produce:** % del fondeo de los 10 / 20 mayores; Índice de Herfindahl (HHI).

**Para qué se usa:** Límites de concentración; Estrés de liquidez idiosincrático.

**Bases lógicas**

| Base | Granularidad | Roles | La definen | Para qué |
|---|---|---|---|---|
| **Saldos por depositante** (`depositantes`) | fecha × depositante | `fecha`, `contraparte`, `grupo_economico`, `segmento`, `moneda`, `saldo` | `contraparte` | Ranking de depositantes y grupos. |

**Qué puede fallar en los datos**

- El mismo cliente con varios códigos (la concentración sale diluida).
- Grupos económicos sin identificar.
- Saldos negativos o duplicados por fecha.

**Controles de negocio (notebook de calidad, ids `M…`)**

| Base · roles | Tipo | Qué se espera | Por qué | Criticidad |
|---|---|---|---|---|
| `depositantes` · contraparte | `completitud` | Todo saldo tiene depositante identificado. | un saldo anónimo no entra al ranking. | ALTA |
| `depositantes` · contraparte, (fecha), (moneda) | `unicidad` | Un saldo por depositante y fecha (y moneda). | duplicados inflan la concentración. | ALTA |
| `depositantes` · saldo | `no_negativos` | Los saldos no son negativos. | un saldo negativo baja la concentración del depositante y esconde el riesgo. | ALTA |
| `depositantes` · grupo_economico | `completitud` | Los depositantes tienen grupo económico. | sin grupo no se suma a los vinculados. | MEDIA |

**Análisis del repositorio (ids `D…`)**

- `lar/concentracion_fondeo.py` — La financiación no debe depender en exceso de una sola contraparte: la mayor cuota de fondeo por proveedor debe estar por debajo del umbral.

**Qué pedir a la primera línea**

1. Identificación única de clientes y grupos económicos.
2. Límites de concentración y su seguimiento.

**Qué mira el experto en cada etapa**

- **00 · Diagnóstico:** Mapea saldos por depositante, su código único y su grupo económico.
- **01 · Control de datos:** Depositantes identificados, sin duplicados, grupos asignados.
- **02 · Modelamiento:** Recalcula el % del top 10/20 y el HHI por fecha (agrupando vinculados).
- **03 · Impactos:** Impacto de agrupar códigos del mismo cliente en la concentración.
- **04 · Seguimiento:** Evolución de la concentración frente a límites.

**Métricas que se replican (02) y vigilan (04):** % top 10 / top 20; HHI.

**Referencias:** BCBS — herramientas de monitoreo de liquidez (concentración de fondeo, 2013).

## 4. Roles (conceptos de negocio) y cómo se enlazan

Un **rol** es el concepto que cumple una columna (P&L, saldo, banda, tasa de salida…). Los controles de negocio se escriben por roles, no por nombres de columna: VIRF enlaza cada rol con una columna real por su nombre (patrón) y su tipo de dato, y el notebook lo muestra en `BASES` (base lógica → base de RUTAS) y `ROLES` (base → rol → columna) para que el validador lo confirme o lo corrija una sola vez. Lo confirmado en las hojas *Diccionario* (00) o *Roles* (01) manda en las etapas siguientes.

| Rol | Familia de dato | Qué es |
|---|---|---|
| `fecha` | fecha | Fecha de la observación (día o periodo) |
| `fecha_corte` | fecha | Fecha de corte de la foto (la fecha del dato) |
| `fecha_inicio` | fecha | Fecha de origen (desembolso, apertura, contratación) |
| `fecha_vencimiento` | fecha | Fecha de vencimiento contractual |
| `fecha_reprecio` | fecha | Próxima fecha de reprecio de la tasa |
| `fecha_cierre` | fecha | Fecha de cierre o cancelación |
| `fecha_flujo` | fecha | Fecha en que ocurre el flujo |
| `saldo` | num | Saldo (stock) a la fecha |
| `saldo_inicial` | num | Saldo al inicio del periodo |
| `saldo_final` | num | Saldo al final del periodo |
| `nominal` | num | Nominal o monto original de la operación |
| `valor_mercado` | num | Valor de mercado / razonable de la posición |
| `flujo` | num | Flujo de caja (capital + interés) |
| `entradas` | num | Entradas de efectivo |
| `salidas` | num | Salidas de efectivo |
| `interes` | num | Interés del flujo o del periodo |
| `amortizacion` | num | Amortización programada de capital |
| `prepago` | num | Monto prepagado (pago antes de lo pactado) |
| `num_cuentas` | num | Número de cuentas, clientes u operaciones |
| `tasa` | num | Tasa de interés de la operación |
| `tasa_mercado` | num | Tasa de mercado de referencia |
| `tasa_pagada` | num | Tasa que paga el banco al depositante |
| `spread` | num | Spread sobre el índice de referencia |
| `tasa_ftp` | num | Tasa de transferencia interna (FTP) |
| `cpr` | num | Tasa de prepago (SMM mensual o CPR anual) |
| `beta` | num | Beta de traspaso de tasas de mercado a la tasa pagada |
| `tasa_salida` | num | Tasa de salida (run-off) en el horizonte de estrés |
| `tasa_entrada` | num | Tasa (ponderador) de las entradas |
| `haircut` | num | Descuento (haircut) aplicado al activo |
| `factor_asf` | num | Factor ASF (fondeo estable disponible) |
| `factor_rsf` | num | Factor RSF (fondeo estable requerido) |
| `factor_descuento` | num | Factor de descuento de la curva |
| `supervivencia` | num | Proporción que sobrevive (curva de supervivencia) |
| `moneda` | texto | Moneda |
| `segmento` | texto | Segmento (minorista/mayorista, banca, tipo de cliente) |
| `producto` | texto | Producto |
| `cartera` | texto | Cartera, libro o mesa |
| `instrumento` | texto | Instrumento |
| `banda` | cualquiera | Banda temporal (bucket) asignada |
| `categoria` | texto | Categoría regulatoria o de gestión |
| `activo_pasivo` | texto | Activo o pasivo |
| `tipo_tasa` | texto | Tipo de tasa (fija / variable) |
| `indice_referencia` | texto | Índice de referencia de la tasa variable |
| `nivel_hqla` | texto | Nivel del activo líquido (1, 2A, 2B) |
| `escenario` | texto | Escenario |
| `factor` | texto | Factor de riesgo (curva, tipo de cambio, precio…) |
| `tenor` | cualquiera | Plazo del nodo de la curva (1M, 3M, 1Y…) |
| `contraparte` | cualquiera | Contraparte o cliente |
| `grupo_economico` | cualquiera | Grupo económico (clientes vinculados) |
| `netting_set` | cualquiera | Conjunto de compensación (netting set / CSA) |
| `nivel_jerarquia` | cualquiera | Nivel de jerarquía de valor razonable (1, 2, 3) |
| `estado` | cualquiera | Estado de la cuenta u operación |
| `cosecha` | cualquiera | Cosecha (mes de origen) |
| `indicador_cancelacion` | cualquiera | Marca de cancelación anticipada |
| `indicador_renovacion` | cualquiera | Marca de renovación al vencimiento |
| `evento` | cualquiera | Marca de evento (1 = cerró, 0 = censurada) |
| `id_operacion` | cualquiera | Identificador de la operación, cuenta o posición |
| `cuenta_contable` | cualquiera | Cuenta contable |
| `pnl` | num | P&L diario usado en el backtesting |
| `pnl_real` | num | P&L real (con comisiones, intereses y actividad del día) |
| `pnl_hipotetico` | num | P&L hipotético (cartera congelada al cierre anterior) |
| `pnl_teorico` | num | P&L teórico del modelo de riesgo (RTPL, FRTB) |
| `var` | num | VaR reportado |
| `var_95` | num | VaR al 95 % |
| `var_99` | num | VaR al 99 % |
| `var_10d` | num | VaR a 10 días |
| `es` | num | Expected Shortfall |
| `stressed_var` | num | VaR estresado |
| `excepcion` | cualquiera | Marca de excepción del backtesting (0/1) |
| `precio` | num | Precio o nivel del factor |
| `retorno` | num | Retorno o choque del factor |
| `sensibilidad` | num | Sensibilidad de la posición al factor |
| `volatilidad` | num | Volatilidad |
| `correlacion` | num | Correlación |
| `horizonte` | num | Horizonte (días) |
| `precio_modelo` | num | Precio del modelo de valoración |
| `precio_independiente` | num | Precio de fuente independiente (IPV) |
| `strike` | num | Precio de ejercicio |
| `ead` | num | Exposición (EAD / PFE) |
| `colateral` | num | Colateral recibido o entregado |
| `mpor` | num | Periodo de margen de riesgo (días) |
| `cva` | num | Ajuste de valoración (CVA) |
| `eve` | num | ΔEVE (valor económico del patrimonio) |
| `nii` | num | ΔNII (margen financiero a 12 meses) |
| `core` | num | Porción estable (núcleo) del saldo |
| `volatil` | num | Porción volátil del saldo (la que tiende a retirarse rápido) |
| `vida_media` | num | Vida media / plazo económico (años o meses) |
| `runoff_acumulado` | num | Run-off acumulado R(t) = 1 − S(t) |
| `runoff_incremental` | num | Desgaste incremental del periodo d(t) = S(t−1) − S(t) |
| `proporcion` | num | Proporción del saldo asignada (a una banda, a un componente) |
| `dias` | num | Días al vencimiento o al reprecio |
| `plazo_meses` | num | Plazo en meses |
| `edad` | num | Antigüedad (meses desde el origen) |
| `hqla` | num | Activos líquidos de alta calidad |
| `lcr` | num | Ratio de cobertura de liquidez (LCR / RCL) |
| `nsfr` | num | Ratio de financiamiento neto estable (NSFR / RFNE) |
| `brecha` | num | Brecha (gap) |
| `flujo_neto` | num | Flujo neto (entradas − salidas) |
| `lar_valor` | num | Liquidity at Risk reportado |
| `limite` | num | Límite o umbral de alerta |

## 5. Librería cuantitativa de los notebooks de las etapas

Los notebooks de las etapas 00–04 traen una celda de soporte con `BASES`, `ROLES`, la carga de las bases de `RUTAS` en `bases` y esta librería (solo pandas y numpy; la usa también el agente con IA):

- `col(base, rol)`
- `tabla(base, roles, opcionales)`
- `falta(base, roles)`
- `comparar(paso, implementador, replicado, tolerancia_pct)`
- `comparar_pp(paso, implementador, replicado, tolerancia_pp)`
- `mes_indice(s)`
- `edad_meses(fecha, cosecha)`
- `nivel_impacto(base, corregido)`
- `var_historico(pnl, nivel)`
- `es_historico(pnl, nivel)`
- `var_parametrico(pnl, nivel)`
- `excepciones(pnl, var, rezago, convencion)`
- `kupiec(x, n, nivel)`
- `christoffersen(exc)`
- `semaforo(x, n, nivel)`
- `pla(hpl, rtpl)`
- `psi(a, b)`
- `smm_cpr(saldo_inicial, amortizacion, prepago)`
- `tasas_runoff(fechas, saldos, horizonte_dias)`
- `kaplan_meier(duracion, evento)`
- `supervivencia_cosechas(cosecha, edad, saldo)`
- `supervivencia_saldo_existente(fecha, cosecha, saldo, plazo_max)`
- `curva_runoff(t, S)`
- `plazo_economico(t, S)`
- `componentes_runoff(t, S, horizonte_meses)`
- `limites_banda(etiqueta)`
- `asignar_bandas(t, S, etiquetas)`
- `curvas_del_modelo(curva)`
- `replicar_runoff(saldos, horizonte_meses, curva_de)`
- `backtesting_runoff(saldos, curva, meses, curva_de)`
- `decaimiento(fechas, saldos)`
- `beta_traspaso(tasa_pagada, tasa_mercado)`
- `punto_medio_banda(etiqueta)`
- `gap_por_banda(montos, bandas, lado)`
- `delta_eve_paralelo(gap, choque)`
- `delta_nii_paralelo(gap, choque)`
- `hqla_ajustado(n1, n2a, n2b)`
- `lcr(hqla, salidas, entradas)`
- `nsfr(asf_saldos, asf_factores, rsf_saldos, rsf_factores)`
- `brechas(entradas, salidas, bandas)`
- `lar_hist(fechas, flujo_neto, horizonte, nivel)`
- `horizonte_supervivencia(salidas_netas, colchon)`
- `concentracion(montos, contrapartes)`

## 6. Cómo añadir un tipo de modelo

1. En `modulos/tipos_modelo_<familia>.py`, añade una entrada a `TIPOS` con `nombre`, `familia`, `carpeta`, `negocio`, `bases` (con `roles` y `define`), `riesgos`, `controles` (por roles, con `que` y `por_que`), `preguntas`, `etapas` (00–04) y `metricas`.
2. Si necesita un concepto nuevo, añade el rol a `ROLES` en `modulos/tipos_modelo.py` (patrón, familia, qué es).
3. Si necesita un análisis propio, crea un `.py` en `inputs/repositorio_controles/<carpeta>/` con `META["tipos"] = ["<tipo>"]`.
4. Si quieres réplica sin IA, añade su bloque en `modulos/plantillas_etapa.py` (`_REPLICA`, `_METRICA`, `_BACKTEST`).
5. Regenera esta guía y la del notebook de calidad de datos; `tests/test_tipos_modelo.py` comprueba la ficha y que sus notebooks corren con datos sintéticos.

