"""
Las guías de uso se generan desde el código (2026-11-24): si el catálogo de
controles, las columnas del Excel, el menú de la web, las etapas, los comandos
del chat, la CLI o los parámetros cambian sin regenerarlas, este test falla.

    python scripts/generar_guia_calidad_datos.py
    python scripts/generar_guia_uso.py
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]


def _generador(nombre: str):
    spec = importlib.util.spec_from_file_location(nombre, RAIZ / "scripts" / f"{nombre}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


@pytest.mark.parametrize("nombre", ["generar_guia_calidad_datos", "generar_guia_uso", "generar_guia_tipos_modelo"])
def test_la_guia_esta_al_dia(nombre):
    g = _generador(nombre)
    assert g.DESTINO.is_file(), f"falta {g.DESTINO.name}: python scripts/{nombre}.py"
    assert g.DESTINO.read_text(encoding="utf-8") == g.construir(), (
        f"{g.DESTINO.name} desactualizada: python scripts/{nombre}.py")


def test_la_guia_del_notebook_cubre_lo_pedido():
    texto = (RAIZ / "docs" / "GUIA_NOTEBOOK_CALIDAD_DATOS.md").read_text(encoding="utf-8")
    for clave in ("Cómo prenderlo", "MODO_DEMO", "Cómo agregarle más controles", "Nivel 4",
                  "Cómo sigue aprendiendo el agente", "revisor", "valores_centinela"):
        assert clave in texto, clave


def test_un_tipo_sin_explicar_hace_fallar_la_guia(monkeypatch):
    g = _generador("generar_guia_calidad_datos")
    from modulos import controles_ia as ci
    monkeypatch.setitem(ci.CATALOGO, "tipo_nuevo", {"dimension": "Validez", "params": {},
                                                    "descripcion": "x"})
    with pytest.raises(SystemExit, match="tipo_nuevo"):
        g.construir()
