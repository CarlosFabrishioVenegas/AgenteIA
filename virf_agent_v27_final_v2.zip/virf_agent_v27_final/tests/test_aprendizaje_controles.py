"""
Notebook de calidad de datos enriquecido y aprendizaje por dominio (2026-11-24).

Coste cero: sin IA. El notebook SÍ se ejecuta (en un subproceso, como lo haría
el validador) para comprobar las secciones nuevas: modo demo, controles del
validador sin programar y programados, hojas extra del Excel. El aprendizaje
escribe en un registro temporal (conftest lo redirige).
"""
from __future__ import annotations

import io
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from modulos import aprendizaje_controles as ac
from modulos import controles_ia as ci


def _df(n: int = 300) -> pd.DataFrame:
    rng = np.random.default_rng(11)
    df = pd.DataFrame({
        "id_operacion": [f"OP{i:05d}" for i in range(n)],
        "fecha_corte": pd.to_datetime("2026-10-31"),
        "saldo_capital": rng.normal(15000, 3000, n).round(2),
        "monto_desembolsado": rng.normal(30000, 3000, n).round(2),
        "estado": rng.choice(["VIGENTE", "CANCELADO"], n),
        "fecha_cancelacion": pd.NaT,
    })
    df.loc[df["estado"] == "CANCELADO", "fecha_cancelacion"] = pd.Timestamp("2026-09-30")
    df.loc[[5, 9], "fecha_cancelacion"] = pd.NaT                  # cancelados sin fecha
    df.loc[[5, 9], "estado"] = "CANCELADO"
    df.loc[12, "saldo_capital"] = 99999999                         # nulo disfrazado
    return df


def _info(df) -> str:
    buf = io.StringIO()
    df.info(buf=buf)
    return buf.getvalue()


def _perfil(df, nombre="cartera"):
    return ci.perfil_dataset(nombre, _info(df), df.describe(include="all").to_string())


def _libreria() -> dict:
    ns: dict = {}
    exec(compile(ci._LIBRERIA, "<libreria>", "exec"), ns)       # tests: ejecutar es la prueba
    return ns


def _correr(nb: bytes, tmp_path: Path, rutas: dict, reemplazos=()) -> subprocess.CompletedProcess:
    celdas = json.loads(nb.decode("utf-8"))["cells"]
    codigo = "\n\n".join("".join(c["source"]) for c in celdas if c["cell_type"] == "code")
    for nombre, ruta in rutas.items():
        codigo = codigo.replace(f'"RUTA/A/{nombre}.csv"', repr(str(ruta)))
    salida = tmp_path / "resultado.xlsx"
    codigo = codigo.replace("Path('resultado_controles_datos.xlsx')", f"Path({str(salida)!r})")
    for viejo, nuevo in reemplazos:
        assert viejo in codigo, viejo
        codigo = codigo.replace(viejo, nuevo, 1)
    script = tmp_path / "nb.py"
    script.write_text(codigo, encoding="utf-8")
    return subprocess.run([sys.executable, str(script)], capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=240, cwd=str(tmp_path),
                          env={**os.environ, "PYTHONUTF8": "1"})


# ── 1. Tipos nuevos del catálogo ────────────────────────────────────────────

def test_tipos_nuevos_detectan_lo_sembrado():
    L = _libreria()
    df = _df()
    r = L["valores_centinela"](df, ["saldo_capital"])
    assert r["decision"] == "No cumple" and r["afectados"] == 1 and "_mascara" in r
    r = L["completitud_condicional"](df, ["estado", "fecha_cancelacion"], valores=["CANCELADO"])
    assert r["afectados"] == 2 and r["decision"] == "No cumple"
    fechas = pd.DataFrame({"f": pd.bdate_range("2026-01-01", "2026-03-31")}).drop(index=[3, 4, 10])
    r = L["serie_continua"](fechas, ["f"], frecuencia="B")
    assert r["afectados"] == 3 and "faltan 3" in r["diagnostico"]
    r = L["serie_continua"](fechas, ["f"], frecuencia="B", excluir=["2026-01-06", "2026-01-07", "2026-01-15"])
    assert r["decision"] == "Cumple"
    rng = np.random.default_rng(3)
    psi = pd.DataFrame({"x": np.r_[rng.normal(0, 1, 500), rng.normal(2, 1, 500)],
                        "p": ["2026-01"] * 500 + ["2026-06"] * 500})
    r = L["estabilidad_psi"](psi, ["x", "p"])
    assert r["decision"] == "No cumple" and "cambio relevante" in r["diagnostico"]
    estable = pd.DataFrame({"x": rng.normal(0, 1, 1000), "p": ["a"] * 500 + ["b"] * 500})
    assert L["estabilidad_psi"](estable, ["x", "p"])["decision"] == "Cumple"


def test_parametros_de_los_tipos_nuevos_se_validan():
    assert ci.validar_params("serie_continua", {"frecuencia": "x"})[1]
    assert ci.validar_params("serie_continua", {"frecuencia": "m"})[0]["frecuencia"] == "M"
    assert ci.validar_params("estabilidad_psi", {"umbral_psi": -1})[1]
    assert not ci.validar_params("valores_centinela", {})[1]


def test_reglas_cazan_centinelas_y_piden_serie_en_mercado():
    df = _df()
    ctrls = ci.proponer([_perfil(df)], dominio="VaR", usar_ia=False)["controles"]
    tipos = {(c["tipo"], tuple(c["columnas"])) for c in ctrls}
    assert ("valores_centinela", ("saldo_capital",)) in tipos        # describe(): max=99999999
    assert ("serie_continua", ("fecha_corte",)) in tipos             # dominio de mercado
    otros = ci.proponer([_perfil(df)], dominio="ALM", usar_ia=False)["controles"]
    assert not any(c["tipo"] == "serie_continua" for c in otros)


# ── 2. El notebook enriquecido corre de punta a punta ───────────────────────

def test_notebook_trae_la_guia_y_las_secciones():
    df = _df()
    p = _perfil(df)
    prop = ci.proponer([p], usar_ia=False)
    nb, info = ci.construir_notebook(prop["controles"], [p], {"titulo": "Prueba", "propuesta_id": "20261124_101010"})
    celdas = json.loads(nb.decode("utf-8"))["cells"]
    texto = "\n".join("".join(c["source"]) for c in celdas)
    for clave in ("Cómo prenderlo", "MODO_DEMO", "CONTROLES_ADICIONALES", "MIS_CONTROLES",
                  "Comprobación contra el perfil", "Enseñar al agente", "20261124_101010",
                  "evidencia_local", ".select(*COLUMNAS_USADAS"):
        assert clave in texto, clave
    assert info["plantillas"] >= 3 and info["bateria"] > 0


def test_modo_demo_prende_sin_datos_y_queda_marcado(tmp_path):
    df = _df()
    p = _perfil(df)
    prop = ci.proponer([p], usar_ia=False)
    nb, _ = ci.construir_notebook(prop["controles"], [p], {"titulo": "Prueba", "propuesta_id": "X1"})
    r = _correr(nb, tmp_path, {}, [("MODO_DEMO = False", "MODO_DEMO = True")])
    assert r.returncode == 0, r.stderr[-2000:]
    salida = tmp_path / "resultado.xlsx"
    hojas = pd.read_excel(salida, sheet_name=None)
    assert list(hojas) == list(ci.HOJAS_SALIDA)
    anexos = ci.leer_anexos(salida)
    assert anexos["modo_demo"] and anexos["propuesta"] == "X1"
    rev = ci.revisar_resultados(ci.leer_tabla_resultados(salida), prop, anexos=anexos)
    assert "MODO_DEMO" in rev["limitaciones"][0]


def test_controles_del_validador_y_programados_viajan_en_el_excel(tmp_path):
    df = _df()
    csv = tmp_path / "cartera.csv"
    df.to_csv(csv, index=False)
    p = _perfil(df)
    prop = ci.proponer([p], usar_ia=False)
    nb, _ = ci.construir_notebook(prop["controles"], [p], {"titulo": "Prueba"})
    adicional = ("CONTROLES_ADICIONALES = [\n"
                 "    {'dataset': 'cartera', 'tipo': 'completitud_condicional',\n"
                 "     'columnas': ['estado', 'fecha_cancelacion'], 'params': {'valores': ['CANCELADO']},\n"
                 "     'descripcion': 'Todo cancelado tiene fecha de cancelación', 'criticidad': 'ALTA'},\n")
    programado = ("MIS_CONTROLES = []\n"
                  "def saldo_no_supera_desembolso(df, columnas, datasets=None, umbral_pct=0.0, **_):\n"
                  "    s = pd.to_numeric(df[columnas[0]], errors='coerce')\n"
                  "    d = pd.to_numeric(df[columnas[1]], errors='coerce')\n"
                  "    ok = s.notna() & d.notna()\n"
                  "    m = ok & (s > d)\n"
                  "    return _res(int(ok.sum()), int(m.sum()), umbral_pct, f'{int(m.sum())} filas', m)\n"
                  "MIS_CONTROLES.append({'funcion': saldo_no_supera_desembolso, 'dataset': 'cartera',\n"
                  "    'columnas': ['saldo_capital', 'monto_desembolsado'], 'descripcion': 'Saldo <= desembolso'})\n")
    r = _correr(nb, tmp_path, {"cartera": csv},
                [("CONTROLES_ADICIONALES = [\n", adicional), ("MIS_CONTROLES = []\n", programado)])
    assert r.returncode == 0, r.stderr[-2000:]
    assert "✓ Las bases coinciden con el perfil" in r.stdout
    salida = tmp_path / "resultado.xlsx"
    filas = {f["control"]: f for f in ci.leer_tabla_resultados(salida)}
    x = filas["X01"]
    assert x["origen"] == "validador" and x["decision"] == "No cumple"
    assert x["tipo"] == "completitud_condicional" and x["params"] == {"valores": ["CANCELADO"]}
    assert filas["P01"]["origen"] == "personalizado"
    anexos = ci.leer_anexos(salida)
    assert not anexos["modo_demo"]
    assert "def saldo_no_supera_desembolso" in anexos["personalizados"][0]["Código"]
    evidencia = tmp_path / "evidencia_local_resultado.xlsx"
    assert evidencia.is_file() and "X01" in pd.read_excel(evidencia, sheet_name=None)
    # El pipeline sigue leyendo la primera hoja.
    from modulos.motores_entidad import leer_resultados
    raiz = tmp_path / "raiz"
    (raiz / "calidad_datos" / "resultadocalidad_de_datos").mkdir(parents=True)
    (raiz / "calidad_datos" / "resultadocalidad_de_datos" / "r.xlsx").write_bytes(salida.read_bytes())
    assert len(leer_resultados(raiz)["filas"]) == len(filas)


# ── 3. Ciclo de aprendizaje ─────────────────────────────────────────────────

def _fila(control, tipo, columnas, params, origen, decision="No cumple", dataset="cartera"):
    return {"control": control, "descripcion": f"{tipo} en {columnas}", "pct_incumplimiento": 2.0,
            "decision": decision, "diagnostico": "", "umbral": 0.0, "criticidad": "ALTA",
            "dataset": dataset, "origen": origen, "tipo": tipo, "columnas": columnas, "params": params}


def test_ciclo_ensenar_aprobar_y_volver_a_proponer():
    prop = {"id": "P1", "controles": [
        {"id": "C01", "tipo": "completitud", "columnas": ["saldo_capital"], "params": {"umbral_pct": 0.0},
         "origen": "reglas", "dataset": "cartera"},
        {"id": "C02", "tipo": "no_negativos", "columnas": ["saldo_capital"], "params": {"umbral_pct": 0.0},
         "origen": "reglas", "dataset": "cartera"}]}
    filas = [
        _fila("C01", "completitud", ["saldo_capital"], {"umbral_pct": 1.5}, "reglas"),   # umbral cambiado
        _fila("C02", "no_negativos", ["saldo_capital"], {"umbral_pct": 0.0}, "reglas"),  # sin cambios
        _fila("X01", "completitud_condicional", ["estado", "fecha_cancelacion"],
              {"valores": ["CANCELADO"]}, "validador"),
    ]
    r = ac.registrar_revision("ALM", filas, prop, autor="ana@banco", codigo_modelo="MR-ALM-001")
    assert r["usos"] == 2 and r["sin_cambios"] == 1 and r["dominio"] == "alm"
    assert all(l["estado"] == "pendiente" for l in ac.lecciones("ALM"))
    perfil = _perfil(_df())
    assert ac.controles_para("ALM", [perfil]) == ([], [])          # pendiente: no se propone

    leccion = next(l for l in ac.lecciones("ALM") if l["tipo"] == "completitud_condicional")
    with pytest.raises(PermissionError):
        ac.decidir(leccion["id"], "aprobado", quien="ana@banco", motivo="la enseñé yo")
    with pytest.raises(ValueError):
        ac.decidir(leccion["id"], "aprobado", quien="rev@banco", motivo="ok")
    ac.decidir(leccion["id"], "aprobado", quien="rev@banco", motivo="regla de negocio correcta")
    umbral = next(l for l in ac.lecciones("ALM") if l["tipo"] == "completitud")
    ac.decidir(umbral["id"], "aprobado", quien="rev@banco", motivo="tolerancia acordada con riesgos")

    # Otro modelo del mismo dominio, columnas con otra grafía: se proponen.
    df2 = _df().rename(columns={"estado": "Estado", "fecha_cancelacion": "Fecha Cancelación"})
    p2 = _perfil(df2, "cartera_hipotecaria")
    aprendidos, avisos = ac.controles_para("alm", [p2])
    assert not avisos and {c["tipo"] for c in aprendidos} == {"completitud_condicional", "completitud"}
    cc = next(c for c in aprendidos if c["tipo"] == "completitud_condicional")
    assert cc["columnas"] == ["Estado", "Fecha Cancelación"] and cc["origen"] == "aprendido"
    assert "rev@banco" in cc["justificacion"]
    prop2 = ci.proponer([p2], dominio="ALM", usar_ia=False, aprendidos=aprendidos)
    compl = next(c for c in prop2["controles"]
                 if c["tipo"] == "completitud" and c["columnas"] == ["saldo_capital"])
    assert compl["params"] == {"umbral_pct": 1.5} and compl["origen"] == "aprendido"   # gana lo aprobado
    assert prop2["aprendidos"] == 2 and "aprendidos" in prop2["origen"]
    assert ac.controles_para("VaR", [p2]) == ([], [])               # otro dominio: nada
    assert ac.verificar()["ok"]


def test_lo_que_se_descarta_deja_de_proponerse_y_el_registro_detecta_ediciones():
    filas = [_fila("X01", "rango", ["saldo_capital"], {"minimo": 0, "maximo": 1e6}, "validador")]
    ac.registrar_revision("LaR", filas, None, autor="ana@banco")
    l = ac.lecciones("LaR")[0]
    ac.decidir(l["id"], "aprobado", quien="rev@banco", motivo="rango de negocio")
    perfil = _perfil(_df())
    aprendidos, _ = ac.controles_para("LaR", [perfil])
    assert len(aprendidos) == 1
    prop = {"id": "P2", "controles": [{**aprendidos[0], "id": "C07"}]}
    for _ in range(2):                                                 # dos notebooks sin ejecutarlo
        ac.registrar_revision("LaR", [], prop, autor="luis@banco")
    l = ac.lecciones("LaR")[0]
    assert l["descartes"] == 2 and not l["activa"]
    assert ac.controles_para("LaR", [perfil]) == ([], [])
    # Editar el registro a mano rompe la cadena.
    texto = ac.RUTA.read_text(encoding="utf-8").replace("rango de negocio", "otro motivo")
    ac.RUTA.write_text(texto, encoding="utf-8")
    assert not ac.verificar()["ok"]


def test_no_se_aprende_codigo_ni_demo_ni_sin_dominio():
    anexos = {"personalizados": [{"Control": "P01", "Función": "f", "Código": "def f(): pass"}]}
    r = ac.registrar_revision("VaR", [_fila("P01", "personalizado:f", [], {}, "personalizado")],
                              None, anexos, autor="ana@banco")
    assert r["usos"] == 0 and r["candidatos"] == 1
    assert ac.candidatos("VaR")[0]["codigo"] == "def f(): pass"
    with pytest.raises(ValueError, match="MODO_DEMO"):
        ac.registrar_revision("VaR", [], None, {"modo_demo": True})
    with pytest.raises(ValueError, match="dominio"):
        ac.registrar_revision("", [], None)


# ── 4. Endpoints ────────────────────────────────────────────────────────────

@pytest.fixture
def cliente(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from config.identidad import Identidad
    from web.app import app
    from web.services import sesion_store
    from web.services.contexto_sesion import contexto_sesion
    monkeypatch.setattr(sesion_store, "VALIDADORES", tmp_path / "validadores.json")
    monkeypatch.setattr(sesion_store, "DATA_DIR", tmp_path)
    sesion_store._sesiones.clear()
    base = tmp_path / "sesion"
    ctx = {"clave": "T9/M", "base": base, "inputs": base / "inputs", "outputs": base / "outputs",
           "modelo": {"nombre": "Modelo ALM", "slug": "MODELO_ALM", "dominio": "ALM", "tier": "II",
                      "codigo_modelo": "MR-ALM-001"},
           "validador": {"codigo": "T9", "nombre": "V"}}
    (base / "inputs").mkdir(parents=True)
    app.dependency_overrides[contexto_sesion] = lambda: ctx
    c = TestClient(app, base_url="https://testserver")

    def como(rol):
        ident = Identidad(oid=f"oid-{rol}", upn=f"{rol}@bcp.com.pe", nombre=f"Persona {rol}",
                          codigo={"validador": "T1111", "revisor": "T2222"}.get(rol, "T3333"),
                          roles=(rol,))
        tok, _ = sesion_store.crear_sesion(ident)
        c.cookies.set("virf_token", tok)
    try:
        yield c, ctx, como
    finally:
        app.dependency_overrides.pop(contexto_sesion, None)


def _excel_resultados(tmp_path, demo=False) -> bytes:
    t = pd.DataFrame([{"Control": "X01", "Control Esperado": "Cancelado con fecha",
                       "% De cumplimiento del data set": 99.0, "Decisión": "No cumple", "Umbral": 0,
                       "Diagnóstico": "2 filas", "Origen": "validador",
                       "Definición": json.dumps({"tipo": "completitud_condicional",
                                                 "columnas": ["estado", "fecha_cancelacion"],
                                                 "params": {"valores": ["CANCELADO"]}})}])
    meta = pd.DataFrame([("Modo demo", "SÍ: datos sintéticos" if demo else "no")], columns=["Campo", "Valor"])
    buf = io.BytesIO()
    with pd.ExcelWriter(buf) as w:
        t.to_excel(w, index=False, sheet_name="Controles")
        meta.to_excel(w, index=False, sheet_name="Metadatos")
    return buf.getvalue()


def test_endpoints_ensenar_listar_y_decidir(cliente, tmp_path):
    c, ctx, como = cliente
    como("validador")
    archivo = {"archivo": ("resultado.xlsx", _excel_resultados(tmp_path))}
    r = c.post("/api/motores/ia/resultados?clasificacion=Interno&aprender=true", files=archivo)
    assert r.status_code == 200, r.text
    assert r.json()["aprendizaje"]["usos"] == 1
    lista = c.get("/api/motores/ia/aprendizaje").json()
    assert lista["dominio"] == "alm" and lista["resumen"]["pendientes"] == 1
    lid = lista["lecciones"][0]["id"]
    pedido = {"id": lid, "decision": "aprobado", "motivo": "regla de negocio correcta"}
    assert c.post("/api/motores/ia/aprendizaje/decidir", json=pedido).status_code == 403   # validador
    como("revisor")
    r = c.post("/api/motores/ia/aprendizaje/decidir", json=pedido)
    assert r.status_code == 200, r.text and r.json()["leccion"]["estado"] == "aprobado"
    assert c.get("/api/motores/ia/aprendizaje").json()["resumen"]["activas"] == 1


def test_excel_del_modo_demo_no_entra_en_validacion_ni_en_aprendizaje(cliente, tmp_path):
    c, ctx, como = cliente
    como("validador")
    demo = {"archivo": ("resultado.xlsx", _excel_resultados(tmp_path, demo=True))}
    assert c.post("/api/motores/ia/resultados?clasificacion=Interno&usar_en_validacion=true",
                  files=demo).status_code == 400
    assert c.post("/api/motores/ia/resultados?clasificacion=Interno&aprender=true",
                  files=demo).status_code == 400
    r = c.post("/api/motores/ia/resultados?clasificacion=Interno", files=demo)
    assert r.status_code == 200 and "MODO_DEMO" in r.json()["limitaciones"][0]


def test_la_guia_se_sirve(cliente):
    c, _, como = cliente
    como("validador")
    r = c.get("/api/motores/ia/guia")
    assert r.status_code in (200, 404)
    if r.status_code == 200:
        assert "Cómo prenderlo" in r.text
