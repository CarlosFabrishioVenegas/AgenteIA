"""
El motor no asume Claude (2026-11-24).

Con GPT en Azure (el único proveedor aprobado) el motor rotulaba y limitaba las
llamadas con la configuración de Claude: `Mx_00.MODELO_IA = ANTHROPIC_MODELO` y
`MAX_TOKENS = ANTHROPIC_MAX_TOKENS`, que Mx_03 pasaba a cada llamada de GPT.
"""
from __future__ import annotations

import importlib

import pytest


def _recargar_mx00(monkeypatch, proveedor, **parametros):
    # La resolución por proveedor vive en config/modelos.py (config/ nombra
    # proveedores; el motor no) y lee config.parametros al llamarse.
    import config.parametros as par
    monkeypatch.setattr(par, "IA_PROVEEDOR", proveedor)
    for k, v in parametros.items():
        monkeypatch.setattr(par, k, v)
    import motor.Mx_00_CargaRutas as mx00
    return importlib.reload(mx00)


def test_modelo_y_tope_son_los_del_proveedor_declarado(monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt-4o-virf")
    try:
        mx = _recargar_mx00(monkeypatch, "azure_openai", AZURE_MAX_TOKENS=9000,
                            ANTHROPIC_MAX_TOKENS=4096, ANTHROPIC_MODELO="claude-sonnet-4-6")
        assert mx.MODELO_IA == "gpt-4o-virf" and mx.MAX_TOKENS == 9000
        assert mx.MODELO_CLAUDE == mx.MODELO_IA                 # alias retrocompatible
        mx = _recargar_mx00(monkeypatch, "anthropic", ANTHROPIC_MAX_TOKENS=4096,
                            ANTHROPIC_MODELO="claude-sonnet-4-6")
        assert mx.MODELO_IA == "claude-sonnet-4-6" and mx.MAX_TOKENS == 4096
    finally:
        monkeypatch.undo()
        import motor.Mx_00_CargaRutas as mx00
        importlib.reload(mx00)


def test_mx03_deja_que_el_cliente_ponga_su_tope(monkeypatch):
    import motor.Mx_03_LlamarIA as mx03
    vistos = {}

    class _Cliente:
        max_tokens_default = 9000

        def generar_mensaje(self, prompt, max_tokens=None, instruccion_sistema="", **_):
            vistos["max_tokens"] = max_tokens
            return "{}"
    monkeypatch.setattr(mx03, "_obtener_cliente", lambda: _Cliente())
    mx03._llamar_modelo("hola")
    assert vistos["max_tokens"] is None                         # el cliente usa SU tope
    mx03._llamar_modelo("hola", max_tokens=1200)
    assert vistos["max_tokens"] == 1200


def test_dry_run_estima_con_el_modelo_que_corre(monkeypatch):
    import config.ia as cia
    monkeypatch.setattr(cia, "modelo_activo", lambda: "gpt-4o-2024-11-20")
    from config.modelos import precio_entrada_por_mtok
    from modulos import revision_codigo as rc
    import inspect
    fuente = inspect.getsource(rc)
    assert "modelo_activo()" in fuente
    assert precio_entrada_por_mtok("gpt-4o-2024-11-20") == 2.50


def test_respaldo_del_modelo_real_no_revienta(monkeypatch):
    import agente
    import config.ia as cia

    def _falla():
        raise RuntimeError("sin proveedor")
    monkeypatch.setattr(cia, "modelo_activo", _falla)
    assert agente._modelo_ia_real()                             # antes: NameError
