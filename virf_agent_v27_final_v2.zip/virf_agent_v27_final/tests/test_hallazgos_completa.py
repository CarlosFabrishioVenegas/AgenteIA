"""
Validación completa: cada etapa entrega un Excel y un .md con TODOS sus
hallazgos (cada uno con su Excel de sustento) y el consolidado final LEE esos
Excel y .md (2026-11-24).

Coste cero: cliente IA falso; nada se ejecuta.
"""
from __future__ import annotations

import io
import json

import openpyxl
import pandas as pd
import pytest

from modulos import hallazgos_completa as HC
from modulos import validacion_completa as VC


class ClientePorIteracion:
    """Devuelve, en cada llamada de revisión, los hallazgos de la lista."""

    def __init__(self, rondas):
        self.rondas = list(rondas)

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                        formato_json=False, **_):
        if "ESTUDIAS un" in instruccion_sistema:
            return json.dumps({"tipo": "excel", "resumen": "Ficha.", "pasos": [], "etapas": []})
        hallazgos = self.rondas.pop(0) if self.rondas else []
        return json.dumps({
            "respuesta": "ok", "resumen": f"Resumen con {len(hallazgos)} hallazgo(s).",
            "cambios_notebook": "x",
            "cuaderno": [{"tipo": "code", "contenido": "registrar('Mapeo', [{'base': 'a'}])"}],
            "tabla": [{"base": "CLIENTES", "contenido": "maestro", "uso": "población",
                       "observado": "conteo", "evidencia": "Mapeo!2"}],
            "hallazgos": hallazgos, "pendientes": ["Ruta de contabilidad"],
            "veredicto": {"estado": "otra_iteracion", "motivo": "abiertos"}})


def _excel(titulo="Mapeo") -> bytes:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = titulo
    ws.append(["Base", "Registros", "Resultado"])
    ws.append(["CLIENTES", 1200, "OK"])
    ws.append(["SALDOS", 980, "No cumple"])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


H1 = {"id": "H1", "descripcion": "Conteo de SALDOS distinto al de contabilidad",
      "evidencia": "00_Diagnostico_resultadoITER0.xlsx/Mapeo!3", "severidad": "Moderado",
      "estado": "nuevo", "accion": "Conciliar"}
H2 = {"id": "H2", "descripcion": "Llave duplicada en CLIENTES", "evidencia": "Mapeo!2",
      "severidad": "crítico", "estado": "nuevo", "accion": "Depurar"}


@pytest.fixture
def dirs(tmp_path):
    return tmp_path / "inputs", tmp_path / "outputs"


def _dos_iteraciones(inputs, outputs):
    cli = ClientePorIteracion([[H1], [{**H1, "estado": "persiste"}, H2]])
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[],
                          comentario="primera", usar_ia=True, cliente=cli, rutas_texto="a = a.csv")
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00",
                          archivos=[("00_Diagnostico_resultadoITER0.xlsx", _excel())],
                          comentario="te devuelvo el Excel", usar_ia=True, cliente=cli)


def test_cada_etapa_entrega_excel_y_md_con_todos_sus_hallazgos(dirs):
    inputs, outputs = dirs
    _dos_iteraciones(inputs, outputs)
    d = VC.dir_salida(outputs, "00")
    xlsx, md = d / "00_Diagnostico_HALLAZGOS.xlsx", d / "00_Diagnostico_HALLAZGOS.md"
    assert xlsx.is_file() and md.is_file()
    hojas = pd.read_excel(xlsx, sheet_name=None)
    assert {"Hallazgos", "Mapeo de bases", "Pendientes", "Iteraciones", "Etapa"} <= set(hojas)
    h = {r["ID"]: r for r in hojas["Hallazgos"].to_dict("records")}
    assert set(h) == {"H1", "H2"}
    assert h["H1"]["Historial"] == "ITER0 nuevo → ITER1 persiste" and h["H1"]["Nace en"] == "ITER0"
    # Todo hallazgo lleva su Excel: el citado, o el último resultado recibido.
    assert h["H1"]["Excel de sustento"] == "00_Diagnostico_resultadoITER0.xlsx"
    assert h["H1"]["Hoja / fila"] == "Mapeo!3"
    assert h["H2"]["Excel de sustento"] == "00_Diagnostico_resultadoITER0.xlsx"
    assert h["H2"]["Severidad"] == "Crítico"
    texto = md.read_text(encoding="utf-8")
    assert "| H1 |" in texto and "| H2 |" in texto and "## Detalle por hallazgo" in texto
    est = VC.estado_etapa(outputs, "00")
    assert est["hallazgos_excel"] == xlsx.name and est["hallazgos_md"] == md.name


def test_sin_excel_recibido_el_sustento_queda_pendiente(dirs):
    inputs, outputs = dirs
    cli = ClientePorIteracion([[{**H2, "evidencia": "revisión de la llave"}]])
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="01", archivos=[],
                          comentario="x", usar_ia=True, cliente=cli, rutas_texto="a = a.csv")
    f = pd.read_excel(VC.dir_salida(outputs, "01") / "01_ControlDatos_HALLAZGOS.xlsx",
                      sheet_name="Hallazgos").iloc[0]
    assert f["Excel de sustento"] == "01_ControlDatos_resultadoITER0.xlsx"   # lo que generará el notebook
    c = HC.consolidar(inputs, outputs)
    assert any("no se encontró el Excel de sustento" in x for x in c["inconsistencias"])


def test_el_consolidado_lee_los_excel_y_md_y_avisa_las_inconsistencias(dirs):
    inputs, outputs = dirs
    _dos_iteraciones(inputs, outputs)
    # El validador corrige el Excel de la etapa tras la última iteración.
    xlsx = VC.dir_salida(outputs, "00") / "00_Diagnostico_HALLAZGOS.xlsx"
    hojas = pd.read_excel(xlsx, sheet_name=None)
    df = hojas["Hallazgos"]
    df.loc[df["ID"] == "H1", "Severidad"] = "Crítico"
    with pd.ExcelWriter(xlsx) as w:
        for n, hoja in hojas.items():
            (df if n == "Hallazgos" else hoja).to_excel(w, sheet_name=n, index=False)
    c = HC.consolidar(inputs, outputs)
    assert any("H1: severidad «Crítico» en el Excel y «Moderado» en el .md" in x
               for x in c["inconsistencias"])
    h1 = next(f for f in c["hallazgos"] if f["ID"] == "H1")
    assert h1["Severidad"] == "Crítico"                         # manda el Excel
    assert h1["Ruta del sustento"] == "sustento/00_Diagnostico/00_Diagnostico_resultadoITER0.xlsx"
    destino = outputs / "validacion_completa" / "_consolidado"
    assert (destino / h1["Ruta del sustento"]).is_file()
    assert (destino / "HALLAZGOS_VALIDACION_COMPLETA.xlsx").is_file()
    assert "## 00 · Diagnóstico" in (destino / "HALLAZGOS_VALIDACION_COMPLETA.md").read_text(encoding="utf-8")
    s = c["resumen"]
    assert s["abiertos"] == 2 and s["criticos"] == 2 and not s["lista_para_validar"]
    assert any("Faltan etapas por cerrar" in a for a in s["avisos"])
    assert HC.ultimo_consolidado(outputs)["resumen"]["hallazgos"] == 2


def test_el_cuadro_y_el_informe_leen_los_entregables(dirs):
    from docx import Document
    from web.services import informe_web
    inputs, outputs = dirs
    _dos_iteraciones(inputs, outputs)
    ctx = VC.contexto_para_cuadro(outputs, inputs=inputs)
    assert "H2 (Crítico, nuevo)" in ctx and "Excel de sustento: 00_Diagnostico_resultadoITER0.xlsx" in ctx
    doc = Document()
    informe_web._sustento_completa(doc, {"inputs": inputs, "outputs": outputs})
    celdas = [c.text for t in doc.tables for r in t.rows for c in r.cells]
    assert "H1" in celdas and "H2" in celdas
    assert any("Hallazgos de la Validación completa" in p.text for p in doc.paragraphs)


def test_las_cinco_etapas_cerradas_dan_un_consolidado_listo(dirs):
    inputs, outputs = dirs
    for c in VC.ETAPAS:
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo=c, archivos=[],
                              comentario="x", usar_ia=False, rutas_texto="a = a.csv")
        VC.cerrar_etapa(outputs, c, "T1", "ok")
    r = HC.consolidar(inputs, outputs)
    assert r["resumen"]["lista_para_validar"] and r["resumen"]["cerradas"] == 5
    assert len(r["etapas"]) == 5 and all(e["md"] and e["excel"] for e in r["etapas"])


def test_endpoints_de_hallazgos_y_consolidado(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services import contexto_sesion as CS, modelos_store, sesion_store
    monkeypatch.setattr(CS, "SESIONES_DIR", tmp_path / "sesiones")
    monkeypatch.setenv("VIRF_MOCK_CHAT", "1")
    val = {"codigo": "T0001", "nombre": "Test", "roles": ["validador"]}
    monkeypatch.setattr(sesion_store, "sesion_activa", lambda tok: val if tok else None)
    monkeypatch.setattr(modelos_store, "_base_validador", lambda c: tmp_path / "sesiones" / c)
    monkeypatch.setattr(modelos_store, "_base_modelo", lambda c, s: tmp_path / "sesiones" / c / s)
    m = modelos_store.crear("T0001", "MCR Prueba", "shared", "II")
    c = TestClient(app)
    c.cookies.set("virf_token", "tok")
    c.cookies.set("virf_modelo", m["slug"])
    assert c.post("/api/completa/modalidad", json={"modalidad": "completa"}).status_code == 200
    r = c.post("/api/completa/etapa/00/iteracion", data={"comentario": "hola", "rutas": "a = a.csv"})
    assert r.status_code == 200, r.text
    assert c.get("/api/completa/etapa/00").json()["hallazgos_excel"] == "00_Diagnostico_HALLAZGOS.xlsx"
    assert c.get("/api/completa/etapa/00/descargar/00_Diagnostico_HALLAZGOS.xlsx").status_code == 200
    assert c.get("/api/completa/etapa/00/descargar/otro.xlsx").status_code == 400
    assert c.get("/api/completa/consolidado").json()["consolidado"] is None
    r = c.post("/api/completa/consolidar")
    assert r.status_code == 200, r.text
    assert r.json()["resumen"]["total"] == 5
    assert c.get("/api/completa/consolidado/descargar/HALLAZGOS_VALIDACION_COMPLETA.xlsx").status_code == 200
    assert c.get("/api/completa/consolidado/descargar/consolidado.json").status_code == 400
