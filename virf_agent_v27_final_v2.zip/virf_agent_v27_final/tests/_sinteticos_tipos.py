"""
Datos sintéticos por TIPO DE MODELO, generados desde las fichas de negocio
(modulos/tipos_modelo*.py): una base por base lógica, con una columna por rol
llamada como el rol. Sirven para probar que cada tipo enlaza sus roles y que
sus notebooks corren de punta a punta (coste cero, sin IA).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

_CATS = {
    "moneda": ["PEN", "USD"], "segmento": ["MINORISTA", "MAYORISTA"], "producto": ["AHORRO", "PLAZO"],
    "cartera": ["MESA_A", "MESA_B"], "instrumento": ["BONO", "SWAP"], "banda": ["0-1M", "1-3M", "3-6M", "6-12M", "1-2A"],
    "categoria": ["CAT_1", "CAT_2"], "activo_pasivo": ["ACTIVO", "PASIVO"], "tipo_tasa": ["FIJA", "VARIABLE"],
    "indice_referencia": ["TIBR", "SOFR"], "nivel_hqla": ["1", "2A", "2B"],
    "escenario": ["paralelo_arriba", "paralelo_abajo"], "factor": ["F1", "F2", "F3"],
    "tenor": ["1M", "3M", "6M", "1Y", "2Y"], "nivel_jerarquia": ["1", "2", "3"], "estado": ["ACTIVA", "CERRADA"],
    "cosecha": ["2024-01", "2024-02"], "indicador_cancelacion": ["0", "1"], "indicador_renovacion": ["0", "1"],
    "evento": [0, 1], "excepcion": [0, 0, 0, 1], "grupo_economico": ["G1", "G2", "G3"],
    "cuenta_contable": ["1101", "2101"],
}
_TASAS = {"tasa", "tasa_mercado", "tasa_pagada", "spread", "tasa_ftp", "cpr", "tasa_salida", "tasa_entrada", "haircut",
          "factor_asf", "factor_rsf", "beta", "core", "supervivencia", "factor_descuento", "correlacion", "volatilidad"}
_VAR = {"var_95": 1.6e5, "var_99": 2.3e5, "var": 2.3e5, "var_10d": 7.3e5, "es": 2.4e5, "stressed_var": 4e5}


def base_sintetica(base: dict, n: int = 260, semilla: int = 0) -> pd.DataFrame:
    from modulos.tipos_modelo import ROLES
    rng = np.random.default_rng(semilla)
    fechas = pd.bdate_range("2024-01-01", periods=n)
    d: dict = {}
    for r in base["roles"]:
        fam = ROLES[r]["familia"]
        if fam == "fecha":
            if r in ("fecha_vencimiento", "fecha_reprecio", "fecha_flujo"):
                d[r] = fechas + pd.Timedelta(days=400)
            elif r == "fecha_corte":
                d[r] = pd.Timestamp("2025-06-30")
            elif r == "fecha_inicio":
                d[r] = fechas - pd.Timedelta(days=200)
            elif r == "fecha_cierre":
                d[r] = pd.Series(fechas + pd.Timedelta(days=100)).where(rng.random(n) < 0.3).values
            else:
                d[r] = fechas
        elif r == "id_operacion":
            d[r] = [f"OP{i:05d}" for i in range(n)]
        elif r in ("contraparte", "netting_set"):
            d[r] = [f"{r[:3].upper()}{i % 40:03d}" for i in range(n)]
        elif r in _CATS:
            d[r] = rng.choice(_CATS[r], n)
        elif r == "horizonte":
            d[r] = rng.choice([10, 20, 40, 60, 120, 30], n)
        elif r == "dias":
            d[r] = rng.integers(0, 700, n)
        elif r in ("plazo_meses", "edad"):
            d[r] = np.tile(np.arange(1, 61), n // 60 + 1)[:n]
        elif r in _TASAS:
            d[r] = rng.uniform(-0.5, 0.9, n) if r == "correlacion" else rng.uniform(0.01, 0.2, n)
        elif r in ("pnl", "pnl_real", "pnl_hipotetico", "pnl_teorico", "retorno", "sensibilidad", "flujo_neto",
                   "eve", "nii", "brecha"):
            d[r] = rng.normal(0, 1e5, n)
        elif r in _VAR:
            d[r] = _VAR[r] * rng.uniform(0.95, 1.05, n)
        elif r in ("lcr", "nsfr"):
            d[r] = rng.uniform(1.1, 1.6, n)
        else:
            d[r] = rng.uniform(1e3, 1e6, n).round(2)
    if "saldo_inicial" in d and "prepago" in d:
        d["amortizacion"] = d["saldo_inicial"] * 0.01
        d["prepago"] = (d["saldo_inicial"] - d["amortizacion"]) * rng.uniform(0.002, 0.02, n)
        if "saldo_final" in d:
            d["saldo_final"] = d["saldo_inicial"] - d["amortizacion"] - d["prepago"]
    return pd.DataFrame(d)


def bases_sinteticas(tid: str, n: int = 260) -> dict[str, pd.DataFrame]:
    """Una base por base lógica del tipo, con el nombre de la base lógica (enlaza por alias)."""
    from modulos.tipos_modelo import TIPOS
    return {b["id"]: base_sintetica(b, n, semilla=i) for i, b in enumerate(TIPOS[tid]["bases"])}


# ── Run-off: historia por cosechas con una curva de supervivencia CONOCIDA ──
#: (componente estable, τ en meses) de la curva verdadera S(k) = estable + (1 − estable)·e^(−k/τ).
RUNOFF_VERDAD = {"MINORISTA": (0.55, 8.0), "MAYORISTA": (0.30, 4.0)}
RUNOFF_BANDAS = ["0-1M", "1-3M", "3-6M", "6-12M", "1-2A", "2-3A", "3-5A", "5-10A"]
_LIM_BANDAS = [(0, 1), (1, 3), (3, 6), (6, 12), (12, 24), (24, 36), (36, 60), (60, 120)]


def curva_verdadera(segmento: str, plazos) -> np.ndarray:
    est, tau = RUNOFF_VERDAD[segmento]
    return est + (1 - est) * np.exp(-np.asarray(plazos, dtype=float) / tau)


def runoff_bases(fallas: bool = False, semilla: int = 0, desde: str = "2019-01",
                 hasta: str = "2024-12") -> dict[str, pd.DataFrame]:
    """
    Bases de un modelo de run-off con la experiencia histórica por cosechas
    (saldo_c(k) = B_c · S(k) · ruido) y lo que entrega el modelo: curva S/R/d,
    componentes estable/volátil y plazo económico, y la asignación a bandas.
    Con `fallas=True` se siembran: MINORISTA con S que sube a los 24 meses (y un
    desgaste negativo); MAYORISTA con un estable del modelo de 45 % (el real es
    30 %), estable + volátil = 95 % y bandas que suman 95 %.
    """
    rng = np.random.default_rng(semilla)
    cosechas = pd.period_range(desde, hasta, freq="M")
    ultimo = cosechas[-1]
    filas = []
    for seg in RUNOFF_VERDAD:
        for c in cosechas:
            b0 = rng.uniform(8e5, 1.2e6)
            edades = np.arange((ultimo - c).n + 1)
            s = curva_verdadera(seg, edades) * (1 + rng.normal(0, 0.004, len(edades)))
            for k, v in zip(edades, s):
                filas.append({"fecha": (c + int(k)).to_timestamp(how="end").normalize(), "segmento": seg,
                              "cosecha": str(c), "edad": int(k), "saldo": round(float(b0 * v), 2)})
    saldos = pd.DataFrame(filas)
    corte = saldos["fecha"].max()
    contabilidad = saldos.groupby("fecha", as_index=False)["saldo"].sum()

    plazos = np.arange(1, 121)
    curva, comp, bandas = [], [], []
    for seg in RUNOFF_VERDAD:
        est_m = 0.45 if (fallas and seg == "MAYORISTA") else RUNOFF_VERDAD[seg][0]
        s = est_m + (1 - est_m) * np.exp(-plazos / RUNOFF_VERDAD[seg][1])
        if fallas and seg == "MINORISTA":
            s[23] = s[22] + 0.02                                  # S(24) > S(23)
        previo = np.concatenate([[1.0], s[:-1]])
        for t, v, d in zip(plazos, s, previo - s):
            curva.append({"segmento": seg, "plazo_meses": int(t), "supervivencia": round(100 * v, 4),
                          "runoff_acumulado": round(100 * (1 - v), 4), "runoff_incremental": round(100 * d, 4)})
        saldo_seg = float(saldos.loc[(saldos["fecha"] == corte) & (saldos["segmento"] == seg), "saldo"].sum())
        tt, ss = np.concatenate([[0.0], plazos]), np.concatenate([[1.0], s])
        vida = float(np.sum((ss[1:] + ss[:-1]) / 2 * np.diff(tt))) / 12
        comp.append({"segmento": seg, "porcion_estable": 100 * est_m,
                     "porcion_volatil": 100 * (1 - est_m) - (5.0 if (fallas and seg == "MAYORISTA") else 0.0),
                     "plazo_economico": round(vida, 4), "saldo": saldo_seg})
        def s_en(m):
            return float(np.interp(m, tt, ss))
        props = [s_en(a) - s_en(b) for a, b in _LIM_BANDAS]
        props[-1] += s_en(120)
        if fallas and seg == "MAYORISTA":
            props[-1] -= 0.05
        for banda, p in zip(RUNOFF_BANDAS, props):
            bandas.append({"fecha": corte, "segmento": seg, "banda": banda, "proporcion": round(100 * p, 4),
                           "saldo": round(p * saldo_seg, 2)})
    cuentas = []
    for i in range(1200):
        seg = "MINORISTA" if i % 2 else "MAYORISTA"
        est, tau = RUNOFF_VERDAD[seg]
        ini = pd.Timestamp("2019-01-01") + pd.Timedelta(days=int(rng.integers(0, 2160)))
        vive = rng.random() < est
        fin = None if vive else ini + pd.Timedelta(days=int(rng.exponential(tau) * 30.4375) + 1)
        fin = fin if (fin is not None and fin <= corte) else None
        cuentas.append({"id_cuenta": f"C{i:05d}", "segmento": seg, "fecha_apertura": ini, "fecha_cierre": fin,
                        "estado": "CERRADA" if fin is not None else "ACTIVA", "saldo": round(float(rng.uniform(1e3, 5e4)), 2)})
    return {"saldos_historia": saldos, "cuentas": pd.DataFrame(cuentas), "curva_runoff": pd.DataFrame(curva),
            "componentes": pd.DataFrame(comp), "bandas": pd.DataFrame(bandas), "contabilidad": contabilidad}
