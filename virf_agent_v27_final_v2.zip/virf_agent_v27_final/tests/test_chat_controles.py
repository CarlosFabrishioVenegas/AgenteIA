"""
Controles del agente conversacional (2026-11-24). Coste cero: el modelo se
sustituye por una función que devuelve el JSON que se quiere probar.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from web.services import chat_service as cs


def _datos():
    return {"resultados_por_ambito": {"Metodología": [
        {"actividad": "A1 ventana", "puntaje": 2, "resultado": "No cumple",
         "observacion": "La ventana de estimación es de 500 días y el manual pide 250.",
         "evaluacion_valida": True},
        {"actividad": "A2 backtesting", "puntaje": 1, "resultado": "No evidenciado",
         "observacion": "No consta el backtesting de Kupiec.", "evaluacion_valida": True}]}}


@pytest.fixture
def chat(tmp_path, monkeypatch):
    cs.clear_todo()
    ctx = {"clave": "T9/aa", "base": tmp_path, "validador": {"codigo": "T9"},
           "modelo": {"nombre": "M", "tier": "I", "dominio": "LaR"}}
    cs.iniciar(ctx, _datos(), "r.json")
    estado = {"respuesta": None}
    monkeypatch.setattr(cs, "_invocar_modelo", lambda prompt: estado["respuesta"]())
    return ctx, estado


def _aprobado(texto="De acuerdo, queda subsanado.", hallazgo="Subsanada por el validador."):
    return lambda: {"veredicto": "APROBADO", "respuesta": texto, "hallazgo": hallazgo}


def test_un_ok_no_basta_para_subsanar(chat):
    ctx, estado = chat
    estado["respuesta"] = _aprobado()
    r = cs.responder(ctx, "ok")
    assert r["veredicto"] is None and not r["avanza"]
    s = cs.sesion_activa(ctx)
    assert s.observaciones[0].veredicto == "SIN_TRATAR"
    assert "motivo concreto" in s.mensajes[-1].texto
    r = cs.responder(ctx, "Se corrigió en la versión 3.2 del manual, sección 4.1: ventana de 250 días")
    assert r["veredicto"] == "APROBADO"
    assert cs.sesion_activa(ctx).observaciones[0].decidido_por == "agente"


def test_justificacion_concreta():
    assert not cs.es_justificacion_concreta("Ya está corregido.")
    assert not cs.es_justificacion_concreta("ok")
    assert cs.es_justificacion_concreta("Corregido en la versión 3")
    assert cs.es_justificacion_concreta("El área de riesgos aprobó usar una ventana más larga para "
                                        "capturar el periodo de estrés")


def test_cifra_inventada_degrada_el_aprobado(chat):
    ctx, estado = chat
    estado["respuesta"] = _aprobado("Con tu aclaración, la ventana pasó a 365 días en 2025.")
    r = cs.responder(ctx, "Se corrigió en la versión 3.2 del manual, sección 4.1")
    assert r["veredicto"] == "PENDIENTE"
    assert "cifra que no consta en la evidencia: 365" in cs.sesion_activa(ctx).mensajes[-3].texto \
        or any("365" in m.texto and "Verificación automática" in m.texto
               for m in cs.sesion_activa(ctx).mensajes)


def test_las_cifras_de_la_evidencia_y_del_validador_si_valen(chat):
    ctx, estado = chat
    estado["respuesta"] = _aprobado("Tomo tu aclaración: el manual pide 250 días y la versión 3.2 "
                                    "ya los usa en lugar de 500.")
    r = cs.responder(ctx, "Se corrigió en la versión 3.2 del manual, sección 4.1")
    assert r["veredicto"] == "APROBADO"


def test_un_fallo_del_modelo_no_decide_ni_gasta_intentos(chat):
    ctx, estado = chat

    def _falla():
        raise TimeoutError("sin respuesta del deployment")
    estado["respuesta"] = _falla
    r = cs.responder(ctx, "La ventana se justifica en el acta del comité de mayo")
    assert r["veredicto"] is None and "TimeoutError" in r["error"]
    o = cs.sesion_activa(ctx).observaciones[0]
    assert o.veredicto == "SIN_TRATAR" and o.intentos == 0
    ultimo = cs.sesion_activa(ctx).mensajes[-1]
    assert ultimo.veredicto is None and "vuelve a enviarla" in ultimo.texto


def test_comandos_ayuda_estado_y_reabrir_con_auditoria(chat):
    ctx, estado = chat
    cs.responder(ctx, "ayuda")
    assert "reabrir N: motivo" in cs.sesion_activa(ctx).mensajes[-1].texto
    cs.responder(ctx, "confirmar")                                  # decide el validador
    s = cs.sesion_activa(ctx)
    assert s.observaciones[0].veredicto == "NEGADO" and s.observaciones[0].decidido_por == "validador"
    cs.responder(ctx, "estado")
    texto = cs.sesion_activa(ctx).mensajes[-1].texto
    assert "1 confirmada(s)" in texto and "▶ 2." in texto
    cs.responder(ctx, "reabrir 1")                                  # sin motivo: lo pide
    assert cs.sesion_activa(ctx).observaciones[0].veredicto == "NEGADO"
    cs.responder(ctx, "reabrir 1: llegó el acta que cambia la conclusión")
    s = cs.sesion_activa(ctx)
    assert s.observaciones[0].veredicto == "SIN_TRATAR" and s.actual.id == s.observaciones[0].id
    registro = Path(os.environ["VIRF_AUDITORIA_LOG"]).read_text(encoding="utf-8").splitlines()
    acciones = [json.loads(l) for l in registro if l.strip()]
    decisiones = [a for a in acciones if a.get("accion") == "decision_chat"]
    assert [d["detalle"]["veredicto"] for d in decisiones][-2:] == ["NEGADO", "REABIERTA"]
    assert decisiones[-1]["detalle"]["decidido_por"] == "validador"


def test_mensaje_enorme_no_se_procesa(chat, monkeypatch):
    ctx, estado = chat
    import config
    monkeypatch.setattr(config, "CHAT_MAX_CARACTERES", 300)
    estado["respuesta"] = _aprobado()
    r = cs.responder(ctx, "x" * 301)
    assert r["veredicto"] is None
    s = cs.sesion_activa(ctx)
    assert "adjunta el texto largo" in s.mensajes[-1].texto and s.observaciones[0].intentos == 0


def test_historial_con_campos_desconocidos_se_abre(chat):
    ctx, _ = chat
    p = Path(ctx["base"]) / "chat_historial.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    d["observaciones"][0]["campo_futuro"] = 1
    d["mensajes"][0]["otro"] = "x"
    p.write_text(json.dumps(d), encoding="utf-8")
    cs.clear_todo()
    s = cs.sesion_activa(ctx)
    assert s is not None and len(s.observaciones) == 2
