"""
Notebook de calidad de datos: batería completa, cobertura del catálogo,
controles por TIPO DE MODELO (VaR ≠ ALM ≠ LaR), porcentaje de cumplimiento y
controles traídos de otros notebooks (2026-11-24).

Coste cero: sin IA. Los notebooks se EJECUTAN en un subproceso, como lo haría
el validador en su equipo.
"""
from __future__ import annotations

import io
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from modulos import controles_ia as ci


def _info(df) -> str:
    buf = io.StringIO()
    df.info(buf=buf)
    return buf.getvalue()


def _perfil(df, nombre):
    return ci.perfil_dataset(nombre, _info(df), df.describe(include="all").to_string())


def _libreria() -> dict:
    ns: dict = {}
    exec(compile(ci._LIBRERIA, "<libreria>", "exec"), ns)       # tests: ejecutar es la prueba
    return ns


def _correr(nb: bytes, tmp_path: Path, rutas: dict, reemplazos=()) -> subprocess.CompletedProcess:
    celdas = json.loads(nb.decode("utf-8"))["cells"]
    codigo = "\n\n".join("".join(c["source"]) for c in celdas if c["cell_type"] == "code")
    for nombre, ruta in rutas.items():
        codigo = codigo.replace(f'"RUTA/A/{nombre}.csv"', repr(str(ruta)))
    codigo = codigo.replace("Path('resultado_controles_datos.xlsx')", f"Path({str(tmp_path / 'r.xlsx')!r})")
    for viejo, nuevo in reemplazos:
        assert viejo in codigo, viejo
        codigo = codigo.replace(viejo, nuevo, 1)
    script = tmp_path / "nb.py"
    script.write_text(codigo, encoding="utf-8")
    return subprocess.run([sys.executable, str(script)], capture_output=True, text=True,
                          encoding="utf-8", errors="replace", timeout=300, cwd=str(tmp_path),
                          env={**os.environ, "PYTHONUTF8": "1"})


def _var_df(n=300) -> pd.DataFrame:
    rng = np.random.default_rng(5)
    pnl = rng.normal(0, 100_000, n)
    var99 = np.full(n, 233_000.0) * rng.uniform(0.95, 1.05, n)
    return pd.DataFrame({"fecha": pd.bdate_range("2025-01-01", periods=n), "pnl": pnl.round(2),
                         "var_99": var99.round(2), "excepcion": (-pnl > var99).astype(int)})


def _alm_df(n=200) -> pd.DataFrame:
    rng = np.random.default_rng(9)
    df = pd.DataFrame({
        "id_operacion": [f"OP{i:05d}" for i in range(n)],
        "fecha_corte": pd.Timestamp("2026-10-31"),
        "fecha_desembolso": pd.Timestamp("2024-01-15"),
        "fecha_vencimiento": pd.Timestamp("2029-01-15"),
        "saldo": rng.uniform(1_000, 50_000, n).round(2),
        "beta": rng.uniform(0.2, 0.6, n).round(3),
        "banda_reprecio": rng.choice(["0-1M", "1-3M", "3-6M"], n),
        "moneda": rng.choice(["PEN", "USD"], n),
    })
    df.loc[3, "fecha_desembolso"] = pd.Timestamp("2027-01-01")     # nace después del corte
    df.loc[5, "beta"] = 1.4                                         # fuera de [0, 1]
    df.loc[7, "moneda"] = " usd"                                    # variante + espacios
    return df


# ── 1. Tipos nuevos del catálogo ────────────────────────────────────────────

def test_el_catalogo_crecio_y_cada_tipo_tiene_funcion():
    assert len(ci.CATALOGO) >= 30
    L = _libreria()
    assert all(callable(L.get(t)) for t in ci.CATALOGO)


def test_tipos_nuevos_detectan_lo_sembrado():
    L = _libreria()
    df = pd.DataFrame({"dni": ["12345678", "1234567", "87654321"], "nombre": ["Ana", " Luis", "Eva  Paz"],
                       "seg": ["Pyme", "PYME", "Pyme"], "txt": ["ok", "malo\x07", "cafÃ©"],
                       "monto": [0.0, 0.0, 5.0], "f1": pd.to_datetime(["2026-01-01", "2026-03-01", "2026-02-01"]),
                       "f2": pd.to_datetime(["2026-02-01", "2026-02-01", "2026-03-01"])})
    assert L["longitud"](df, ["dni"], minimo=8, maximo=8)["afectados"] == 1
    assert L["espacios_extremos"](df, ["nombre"])["afectados"] == 2
    assert L["caracteres_invalidos"](df, ["txt"])["afectados"] == 2
    assert L["categorias_equivalentes"](df, ["seg"])["afectados"] == 1
    assert L["proporcion_ceros"](df, ["monto"], umbral_pct=10)["decision"] == "No cumple"
    assert L["cardinalidad"](df, ["seg"], minimo=1, maximo=1)["decision"] == "No cumple"   # 2 distintos
    assert L["consistencia_fechas"](df, ["f1", "f2"], operador="<=")["afectados"] == 1
    assert L["fecha_futura"](df, ["f1"], referencia="2026-02-15")["afectados"] == 1
    otra = pd.DataFrame({"monto": [5.0], "x": [1]})
    assert L["conciliacion_totales"](df, ["monto"], ref_dataset="b", ref_columna="monto",
                                     datasets={"b": otra})["decision"] == "Cumple"
    assert L["conciliacion_conteos"](df, [], ref_dataset="b", datasets={"b": otra})["decision"] == "No cumple"
    serie = pd.DataFrame({"v": [100, 102, 180, 181], "p": ["2026-01", "2026-02", "2026-03", "2026-04"]})
    r = L["variacion_temporal"](serie, ["v", "p"], agregacion="sum", max_variacion_pct=20)
    assert r["afectados"] == 1 and "+76" in r["diagnostico"]


# ── 2. Batería completa y cobertura ─────────────────────────────────────────

def test_la_bateria_cubre_todas_las_columnas_y_la_cobertura_todos_los_tipos():
    df = _alm_df()
    p = _perfil(df, "cartera")
    r = ci.proponer([p], dominio="Scoring", usar_ia=False)        # dominio sin reglas propias
    por_col = {}
    for c in r["controles"]:
        for col in c["columnas"]:
            por_col.setdefault(col, set()).add(c["tipo"])
    for col in df.columns:
        assert {"completitud", "valores_centinela"} <= por_col[col], col
    assert r["bateria"] > 0 and {c["tipo"] for c in r["cobertura"]} == set(ci.CATALOGO)
    nb, info = ci.construir_notebook(r["controles"], [p], {"titulo": "X"})
    faltan = [c["tipo"] for c in r["cobertura"] if not c["controles"]]
    assert info["plantillas"] == len(faltan)
    texto = "\n".join("".join(c["source"]) for c in json.loads(nb.decode("utf-8"))["cells"])
    for t in faltan:                                                 # una plantilla por tipo que falta
        assert f"'tipo': '{t}'" in texto, t


# ── 3. Por tipo de modelo: VaR ≠ ALM ────────────────────────────────────────

def test_var_y_alm_traen_controles_distintos():
    rv = ci.proponer([_perfil(_var_df(), "pyg")], dominio="VaR", usar_ia=False)
    ra = ci.proponer([_perfil(_alm_df(), "cartera")], dominio="ALM", usar_ia=False)
    tv = {(c["tipo"], tuple(c["columnas"])) for c in rv["controles"] if c["origen"] == "tipo de modelo"}
    ta = {(c["tipo"], tuple(c["columnas"])) for c in ra["controles"] if c["origen"] == "tipo de modelo"}
    assert ("variacion_temporal", ("var_99", "fecha")) in tv and ("dominio", ("excepcion",)) in tv
    assert ("consistencia_fechas", ("fecha_desembolso", "fecha_corte")) in ta
    assert ("rango", ("beta",)) in ta
    dv = {c["tipo"] for c in rv["controles"] if c["origen"] == "dominio"}
    da = {c["tipo"] for c in ra["controles"] if c["origen"] == "dominio"}
    assert "dominio:kupiec" in dv and "dominio:kupiec" not in da
    assert any(t.startswith("dominio:") for t in da) and not (dv & da)
    kupiec = next(c for c in rv["controles"] if c["tipo"] == "dominio:kupiec")
    assert kupiec["params"]["campo_pnl"] == "pnl" and kupiec["params"]["campo_var"] == "var_99"


def test_notebook_var_corre_con_el_repositorio_y_da_el_porcentaje(tmp_path):
    df = _var_df()
    csv = tmp_path / "pyg.csv"
    df.to_csv(csv, index=False)
    p = _perfil(df, "pyg")
    prop = ci.proponer([p], dominio="VaR", usar_ia=False)
    nb, info = ci.construir_notebook(prop["controles"], [p], {"titulo": "VaR", "dominio": "VaR"})
    assert info["repositorio"] == prop["repositorio"] > 0
    r = _correr(nb, tmp_path, {"pyg": csv})
    assert r.returncode == 0, r.stderr[-3000:]
    assert "PORCENTAJE DE CUMPLIMIENTO" in r.stdout
    salida = tmp_path / "r.xlsx"
    hojas = pd.read_excel(salida, sheet_name=None)
    assert list(hojas) == list(ci.HOJAS_SALIDA)
    t = hojas["Controles"]
    ids = set(t["Control"])
    assert {c["id"] for c in prop["controles"]} <= ids                # todos corrieron
    kup = t[t["Tipo"] == "dominio:kupiec"].iloc[0]
    assert kup["Decisión"] in ("Cumple", "No cumple")                 # se evaluó de verdad
    glob = hojas["Resumen"].iloc[0]
    assert glob["Grupo"] == "GLOBAL"
    ev = t[t["Decisión"].isin(["Cumple", "No cumple"])]
    esperado = round(100 * (ev["Decisión"] == "Cumple").mean(), 2)
    assert glob["% de cumplimiento"] == pytest.approx(esperado)
    assert set(hojas["Cobertura"]["Tipo"]) == set(ci.CATALOGO)
    filas = ci.leer_tabla_resultados(salida)
    rev = ci.revisar_resultados(filas, prop, anexos=ci.leer_anexos(salida))
    assert rev["resumen"]["pct_cumplimiento"] == pytest.approx(esperado)
    assert not rev["incoherencias"]


def test_un_porcentaje_editado_se_detecta():
    filas = [{"control": "C01", "descripcion": "x", "pct_incumplimiento": 0.0, "decision": "Cumple",
              "diagnostico": "", "umbral": 0.0, "criticidad": "ALTA", "dataset": "b"},
             {"control": "C02", "descripcion": "y", "pct_incumplimiento": 5.0, "decision": "No cumple",
              "diagnostico": "", "umbral": 0.0, "criticidad": "BAJA", "dataset": "b"}]
    rev = ci.revisar_resultados(filas, None, anexos={"metadatos": {"Porcentaje de cumplimiento": "100"}})
    assert rev["resumen"]["pct_cumplimiento"] == 50.0 and rev["resumen"]["pct_ponderado"] == 75.0
    assert any("declara un 100 %" in x for x in rev["incoherencias"])


# ── 4. Controles traídos de otros notebooks ─────────────────────────────────

def test_controles_de_otros_notebooks_se_adaptan_sin_reescribirlos(tmp_path):
    df = _alm_df()
    csv = tmp_path / "cartera.csv"
    df.to_csv(csv, index=False)
    p = _perfil(df, "cartera")
    prop = ci.proponer([p], dominio="ALM", usar_ia=False)
    nb, _ = ci.construir_notebook(prop["controles"], [p], {"titulo": "ALM", "dominio": "ALM"})
    traidos = (
        "\n@mi_control(dataset='cartera', descripcion='filas: saldo alto', dimension='Exactitud')\n"
        "def saldo_alto(df):\n"
        "    return df[pd.to_numeric(df['saldo'], errors='coerce') > 49_000]\n"
        "\n@mi_control(dataset='cartera', descripcion='bool: hay al menos 100 filas')\n"
        "def hay_volumen(df):\n"
        "    return len(df) >= 100\n"
        "\n@mi_control(dataset='cartera', descripcion='int: betas fuera de [0,1]')\n"
        "def betas_malos(df):\n"
        "    return int((pd.to_numeric(df['beta'], errors='coerce') > 1).sum())\n"
        "\n@mi_control(dataset='cartera', columnas=['moneda'], descripcion='mascara: moneda rara',\n"
        "            params={'umbral_pct': 0.0})\n"
        "def moneda_rara(df, columnas):\n"
        "    return ~df[columnas[0]].isin(['PEN', 'USD'])\n")
    r = _correr(nb, tmp_path, {"cartera": csv},
                [("    return registrar\n", "    return registrar\n" + traidos)])
    assert r.returncode == 0, r.stderr[-3000:]
    t = pd.read_excel(tmp_path / "r.xlsx", sheet_name=None)
    c = {row["Control Esperado"]: row for row in t["Controles"].to_dict("records")}
    assert c["bool: hay al menos 100 filas"]["Decisión"] == "Cumple"
    assert c["int: betas fuera de [0,1]"]["N afectados"] == 1
    assert c["mascara: moneda rara"]["N afectados"] == 1
    assert c["filas: saldo alto"]["Origen"] == "personalizado"
    codigo = t["Controles_personalizados"]
    assert "def saldo_alto(df)" in codigo.loc[codigo["Función"] == "saldo_alto", "Código"].iloc[0]
