"""
Tipos de modelo (fichas de negocio), notebook de calidad de datos experto en
el negocio y ruta paso a paso de la validación completa (2026-11-24).

Coste cero: sin IA (o con un cliente falso). Los notebooks se EJECUTAN en un
subproceso, como en el equipo del validador.
"""
from __future__ import annotations

import ast
import io
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from modulos import controles_ia as ci
from modulos import tipos_modelo as tm
from modulos import validacion_completa as VC

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _sinteticos_tipos import (RUNOFF_BANDAS, RUNOFF_VERDAD, bases_sinteticas, curva_verdadera,  # noqa: E402
                               runoff_bases)


def _perfil(df, nombre):
    b = io.StringIO()
    df.info(buf=b)
    return ci.perfil_dataset(nombre, b.getvalue(), df.describe(include="all").to_string())


def _lib() -> dict:
    ns: dict = {}
    exec(compile(ci._LIBRERIA, "<libreria>", "exec"), ns)          # tests: ejecutar es la prueba
    return ns


def _correr_codigo(codigo: str, cwd: Path) -> subprocess.CompletedProcess:
    (cwd / "nb.py").write_text(codigo, encoding="utf-8")
    return subprocess.run([sys.executable, "nb.py"], capture_output=True, text=True, encoding="utf-8",
                          errors="replace", cwd=str(cwd), timeout=600, env={**os.environ, "PYTHONUTF8": "1"})


def _codigo_nb(nb: dict | bytes) -> str:
    d = json.loads(nb.decode("utf-8")) if isinstance(nb, bytes) else nb
    return "\n\n".join("".join(c["source"]) for c in d["cells"] if c["cell_type"] == "code")


# ── 1. Fichas ────────────────────────────────────────────────────────────────

def test_las_fichas_son_completas_y_coherentes():
    assert len(tm.TIPOS) >= 19
    assert {"var", "es_frtb", "irrbb", "prepago", "nmd", "runoff", "lcr", "nsfr", "lar"} <= set(tm.TIPOS)
    for tid, t in tm.TIPOS.items():
        for k in ("nombre", "familia", "carpeta", "negocio", "bases", "riesgos", "controles", "preguntas",
                  "etapas", "metricas"):
            assert t.get(k), (tid, k)
        assert t["familia"] in tm.FAMILIAS and t["carpeta"] == tm.FAMILIAS[t["familia"]]
        assert set(t["etapas"]) == set(tm.ETAPAS_CODIGOS), tid
        bases = {b["id"]: b for b in t["bases"]}
        for b in t["bases"]:
            assert set(b["roles"]) | set(b.get("define", [])) <= set(tm.ROLES), (tid, b["id"])
        for c in t["controles"]:
            assert c["tipo"] in ci.CATALOGO, (tid, c["tipo"])
            assert c["base"] in bases and set(c["roles"] + c.get("opcionales", [])) <= set(bases[c["base"]]["roles"])
            # La base y la columna de referencia de los cruces las resuelve el notebook (BASES / ROLES).
            ref_p = {"ref_dataset": "REF", "ref_columna": "COL"} if c.get("ref") else {}
            params, err = ci.validar_params(c["tipo"], {**c["params"], **ref_p})
            assert not err, (tid, c["que"], err)
            n = len(c["roles"]) + len(c.get("opcionales", []))
            assert ci.columnas_validas(c["tipo"], len(c["roles"]), params) or ci.columnas_validas(c["tipo"], n, params), \
                (tid, c["que"])
            if c.get("ref"):
                rb = bases[c["ref"]["base"]]
                assert (not c["ref"].get("rol")) or c["ref"]["rol"] in rb["roles"]
                assert set(c["ref"].get("claves") or []) <= set(rb["roles"])
            assert len(c["por_que"]) > 20, (tid, c["que"])       # el porqué de negocio no es decorativo


def test_los_roles_reconocen_nombres_tipicos():
    casos = {"pnl_hipotetico": "pnl_hipotetico", "hpl": "pnl_hipotetico", "var_99": "var_99", "var99": "var_99",
             "tasa_salida": "tasa_salida", "runoff": "tasa_salida", "fecha_corte": "fecha_corte",
             "saldo_capital": "saldo", "id_factor": "factor", "banda_reprecio": "banda", "rcl": "lcr",
             "fecha_vencimiento": "fecha_vencimiento", "cpr": "cpr", "beta": "beta", "es_975": "es"}
    for col, rol in casos.items():
        assert tm.ROLES[rol]["_rx"].search(tm.norm(col)), (col, rol)
    assert not tm.ROLES["es"]["_rx"].search("es_vigente")        # «es_…» en español no es Expected Shortfall
    assert not tm.ROLES["var"]["_rx"].search("variacion")


def test_el_enlace_usa_roles_y_nombre_y_nunca_compara_una_base_consigo_misma():
    rng = np.random.default_rng(1)
    f = pd.bdate_range("2025-01-01", periods=300)
    pyg = pd.DataFrame({"fecha": f, "pnl": rng.normal(0, 1, 300), "var_99": 2.3})
    fac = pd.DataFrame({"fecha": np.repeat(f[:100], 2), "id_factor": ["A", "B"] * 100, "precio": 1.0})
    pos = pd.DataFrame({"id_posicion": ["P1"], "factor_riesgo": ["A"], "valor_mercado": [1.0], "nominal": [1.0]})
    perfiles = [_perfil(pyg, "pyg"), _perfil(fac, "factores_mercado"), _perfil(pos, "posiciones")]
    e = tm.enlazar(perfiles, ["var"])
    assert e["bases"]["pyg"] == "pyg" and e["bases"]["var_reportado"] == "pyg"
    assert e["bases"]["factores"] == "factores_mercado" and e["bases"]["posiciones"] == "posiciones"
    assert e["bases"]["contabilidad"] is None                     # solo por nombre: no hay «contabilidad»
    assert e["roles"]["factores_mercado"]["factor"] == "id_factor"
    assert e["roles"]["pyg"]["var"] == "var_99"                  # el genérico reusa su equivalente
    cs = tm.controles_negocio(perfiles, ["var"], e)
    misma = [c for c in cs if c["no_aplica"]]
    assert misma and all(c["tipo"] == "integridad" for c in misma)   # P&L y VaR en la misma tabla: no aplica


# ── 2. Tipos nuevos del catálogo y la regresión de fechas ISO ───────────────

def test_las_fechas_iso_de_un_csv_no_se_invierten():
    L = _lib()
    f = L["_fechas"](pd.Series(["2025-04-01", "2025-01-13", "13/01/2025", "2025-12-31 10:00:00"]))
    assert [x.strftime("%Y-%m-%d") for x in f] == ["2025-04-01", "2025-01-13", "2025-01-13", "2025-12-31"]


def test_los_tipos_de_negocio_del_catalogo_detectan_lo_sembrado():
    L = _lib()
    assert all(callable(L.get(t)) for t in ci.CATALOGO)
    f = pd.bdate_range("2025-01-01", periods=40)
    fac = pd.DataFrame({"fecha": list(f) * 2, "factor": ["A"] * 40 + ["B"] * 40,
                        "precio": list(np.linspace(1, 2, 40)) + [5.0] * 10 + list(np.linspace(5, 6, 30))})
    # B repite 5.0 once veces seguidas (diez + el primer valor de la rampa): 11 − 5 = 6 filas de más.
    assert L["valores_repetidos"](fac, ["precio", "fecha", "factor"], max_repeticiones=5)["afectados"] == 6
    s = fac.copy()
    s.loc[20, "precio"] = 50.0
    assert L["saltos_serie"](s, ["precio", "fecha", "factor"], k=10)["afectados"] >= 1
    v = pd.DataFrame({"var_95": [1, 2, 3], "var_99": [2, 1, 4]})
    assert L["monotonia"](v, ["var_95", "var_99"], sentido="creciente")["afectados"] == 1
    cur = pd.DataFrame({"df": [0.99, 0.97, 0.98, 0.9], "tenor": ["1M", "6M", "1Y", "5Y"]})
    assert L["monotonia_curva"](cur, ["df", "tenor"], sentido="decreciente")["afectados"] == 1
    sal = pd.DataFrame({"s0": [100.0, 100.0], "am": [10.0, 10.0], "pp": [5.0, 5.0], "s1": [85.0, 80.0]})
    assert L["relacion_aritmetica"](sal, ["s0", "am", "pp", "s1"], operacion="resta")["afectados"] == 1
    assert L["diferencia_relativa"](pd.DataFrame({"a": [100, 103], "b": [100, 100]}), ["a", "b"],
                                    tolerancia_pct=2)["afectados"] == 1
    esc = pd.DataFrame({"escenario": ["paralelo_arriba", "Paralelo Abajo"]})
    r = L["categorias_requeridas"](esc, ["escenario"], valores=["paralelo_arriba", "paralelo_abajo", "empinamiento"])
    assert r["afectados"] == 1 and "empinamiento" in r["diagnostico"]
    panel = pd.DataFrame({"fecha": ["d1", "d1", "d2"], "seg": ["A", "B", "A"]})
    assert L["combinaciones_completas"](panel, ["fecha", "seg"])["afectados"] == 1
    assert L["minimo_por_grupo"](fac, ["factor"], min_filas=41)["afectados"] == 2
    pesos = pd.DataFrame({"p": [0.5, 0.5, 0.7, 0.2], "seg": ["A", "A", "B", "B"]})
    assert L["suma_por_grupo"](pesos, ["p", "seg"], valor_esperado=1.0)["afectados"] == 1
    pos = pd.DataFrame({"saldo": [10.0, 20.0, 5.0], "mon": ["PEN", "USD", "PEN"]})
    cont = pd.DataFrame({"total": [15.0, 25.0], "moneda": ["pen", "USD"]})
    r = L["conciliacion_por_grupo"](pos, ["saldo", "mon"], ref_dataset="c", ref_columna="total",
                                    ref_claves=["moneda"], datasets={"c": cont})
    assert r["afectados"] == 1 and "USD" in r["diagnostico"]
    sg = pd.DataFrame({"m": [10, -5, -3], "lado": ["ACTIVO", "ACTIVO", "PASIVO"]})
    assert L["signo_por_categoria"](sg, ["m", "lado"], positivos=["activo"], negativos=["pasivo"])["afectados"] == 1
    bd = pd.DataFrame({"dias": [10, 45, 400], "banda": ["0-1M", "0-1M", ">1A"]})
    assert L["banda_coherente"](bd, ["dias", "banda"], limites=[0, 30, 90, 365, 36500],
                                etiquetas=["0-1M", "1-3M", "3-12M", ">1A"])["afectados"] == 1
    fh = pd.DataFrame({"fecha": ["2025-01-03", "2025-01-04", "2025-01-06"]})
    assert L["fechas_habiles"](fh, ["fecha"], excluir=["2025-01-06"])["afectados"] == 2
    assert L["dominio"](pd.DataFrame({"h": [10, 20.0, 15]}), ["h"], valores=["10", "20"])["afectados"] == 1
    # Run-off: estable + volátil = 1 (valor fijo), un corte frente a un balance con historia y el total por fecha.
    comp = pd.DataFrame({"est": [0.6, 0.45], "vol": [0.4, 0.5]})
    assert L["relacion_aritmetica"](comp, ["est", "vol"], operacion="suma", valor=1.0)["afectados"] == 1
    corte = pd.DataFrame({"saldo": [60.0, 40.0], "fecha": ["2025-06-30"] * 2})
    hist = pd.DataFrame({"saldo": [90.0, 100.0], "fecha": ["2025-05-31", "2025-06-30"]})
    kw = dict(ref_dataset="h", ref_columna="saldo", ref_claves=["fecha"], datasets={"h": hist})
    assert L["conciliacion_por_grupo"](corte, ["saldo", "fecha"], **kw)["afectados"] == 1      # mayo, sin pareja
    assert L["conciliacion_por_grupo"](corte, ["saldo", "fecha"], pareja="base", **kw)["afectados"] == 0
    coh = pd.DataFrame({"fecha": np.repeat(f[:20], 3), "seg": "A", "cos": ["c1", "c2", "c3"] * 20,
                        "saldo": 100.0 + np.repeat(np.arange(20), 3)})
    coh.loc[coh["fecha"] >= f[12], "saldo"] -= 40.0                  # migración: las tres cosechas a la vez
    r = L["saltos_serie"](coh, ["saldo", "fecha", "seg"], k=8, agregar="suma")
    assert r["afectados"] == 1 and int(r["_mascara"].sum()) == 3 and "total por grupo" in r["diagnostico"]


def test_validacion_de_columnas_y_parametros_de_los_tipos_nuevos():
    assert ci.columnas_validas("valores_repetidos", 3) and not ci.columnas_validas("valores_repetidos", 1)
    assert ci.columnas_validas("relacion_aritmetica", 4, {"operacion": "resta"})
    assert not ci.columnas_validas("relacion_aritmetica", 4, {"operacion": "cociente"})
    assert ci.columnas_validas("relacion_aritmetica", 2, {"operacion": "suma", "valor": 1.0})
    assert not ci.columnas_validas("relacion_aritmetica", 2, {"operacion": "suma"})
    assert ci.validar_params("banda_coherente", {"limites": [0, 30], "etiquetas": ["a", "b"]})[1]
    assert not ci.validar_params("banda_coherente", {"limites": [0, 30, 90], "etiquetas": ["a", "b"]})[1]
    assert ci.validar_params("monotonia", {"sentido": "lateral"})[1]
    assert ci.columnas_texto("monotonia") == "2 o más" and ci.columnas_texto("saltos_serie") == "2 a 4"
    ref = {"ref_dataset": "c", "ref_columna": "s"}
    assert ci.validar_params("conciliacion_por_grupo", {**ref, "pareja": "otra"})[1]
    assert ci.validar_params("conciliacion_por_grupo", {**ref, "pareja": "BASE"}) == ({**ref, "pareja": "base"}, "")
    assert ci.validar_params("saltos_serie", {"agregar": "media"})[1]
    assert not ci.validar_params("saltos_serie", {"agregar": "suma"})[1]


# ── 3. Notebook de calidad de datos con tipo de modelo ──────────────────────

def _var_bases():
    rng = np.random.default_rng(1)
    n = 300
    f = pd.bdate_range("2025-01-01", periods=n)
    pnl = rng.normal(0, 1e5, n)
    var = np.full(n, 2.33e5) * rng.uniform(0.95, 1.05, n)
    pyg = pd.DataFrame({"fecha": f, "pnl": pnl.round(2), "var_99": var, "var_95": var * 0.7,
                        "excepcion": (-pnl > var).astype(int)})
    pyg.loc[10, "var_95"] = 3e5                                    # VaR 95 > VaR 99
    fac = pd.DataFrame({"fecha": np.repeat(f[:260], 3), "id_factor": ["USDPEN", "CURVA_PEN_1Y", "BONO10Y"] * 260,
                        "precio": rng.normal(1, 0.01, 780)})
    fac.loc[(fac.id_factor == "USDPEN") & (fac.index < 60), "precio"] = 1.0   # precio rancio
    pos = pd.DataFrame({"id_posicion": ["P1", "P2", "P3"], "factor_riesgo": ["USDPEN", "X", "BONO10Y"],
                        "valor_mercado": [1e6, 2e6, 5e5], "nominal": [1e6, 2e6, 5e5], "moneda": ["PEN", "USD", "PEN"]})
    cont = pd.DataFrame({"cartera": ["T"], "valor_mercado": [3.6e6]})          # descuadre de 2,8 %
    return {"pyg": pyg, "factores_mercado": fac, "posiciones": pos, "contabilidad_fo": cont}


def test_el_notebook_con_tipo_de_modelo_entiende_el_negocio_y_caza_lo_sembrado(tmp_path):
    bases = _var_bases()
    perfiles = [_perfil(d, k) for k, d in bases.items()]
    prop = ci.proponer(perfiles, dominio="VaR", usar_ia=False, tipos_modelo=["var"])
    assert prop["negocio"] >= 25 and prop["tipos_modelo"] == ["var"]
    nb, info = ci.construir_notebook(prop["controles"], perfiles, {
        "titulo": "VaR", "dominio": "VaR", "tipos_modelo": prop["tipos_modelo"], "enlace": prop["enlace"],
        "plantillas_negocio": prop["plantillas_negocio"], "omitidos_negocio": prop["omitidos_negocio"]})
    d = json.loads(nb.decode("utf-8"))
    md = "\n".join("".join(c["source"]) for c in d["cells"] if c["cell_type"] == "markdown")
    assert "Entender el modelo" in md and "Qué pedir a la primera línea" in md and "«rancios»" in md
    codigo = _codigo_nb(nb)
    for k, df in bases.items():
        p = tmp_path / f"{k}.csv"
        df.to_csv(p, index=False)
        codigo = codigo.replace(f'"RUTA/A/{k}.csv"', repr(str(p)))
    codigo = codigo.replace("Path('resultado_controles_datos.xlsx')", f"Path({str(tmp_path / 'r.xlsx')!r})")
    r = _correr_codigo(codigo, tmp_path)
    assert r.returncode == 0, r.stderr[-3000:]
    hojas = pd.read_excel(tmp_path / "r.xlsx", sheet_name=None)
    assert list(hojas) == list(ci.HOJAS_SALIDA)
    t = hojas["Controles"]
    m = t[t["Control"].astype(str).str.startswith("M")]
    def dec(texto):
        return m[m["Control Esperado"].str.contains(texto, regex=False)]["Decisión"].tolist()
    assert dec("VaR 95 % ≤ VaR 99 %") == ["No cumple"]
    assert dec("repite su precio") == ["No cumple"]
    assert dec("factores de las posiciones tienen historia") == ["No cumple"]
    assert dec("cuadra con contabilidad") == ["No cumple"]
    pend = m[m["Diagnóstico"].astype(str).str.startswith("Pendiente")]
    assert len(pend) >= 3 and set(pend["Decisión"]) == {"No evaluable"}
    assert (m["Tipo de modelo"] == "var").all()
    glob = hojas["Resumen"].iloc[0]
    ev = t[t["Decisión"].isin(["Cumple", "No cumple"])]
    assert glob["% de cumplimiento"] == pytest.approx(round(100 * (ev["Decisión"] == "Cumple").mean(), 2))
    roles = hojas["Roles"]
    assert ((roles["Base lógica"] == "factores") & (roles["Rol"] == "factor") & (roles["Columna"] == "id_factor")).any()


def test_el_repositorio_se_filtra_por_tipo_de_modelo():
    p = _perfil(pd.DataFrame({"fecha": pd.date_range("2024-01-31", periods=24, freq="M"), "segmento": "A",
                              "saldo_inicial": 100.0, "amortizacion": 1.0, "prepago": 2.0, "cpr": 0.2}), "saldos")
    pre = {c["tipo"] for c in ci.proponer([p], dominio="ALM", usar_ia=False, tipos_modelo=["prepago"])["controles"]
           if c["origen"] == "dominio"}
    irr = {c["tipo"] for c in ci.proponer([p], dominio="ALM", usar_ia=False, tipos_modelo=["irrbb"])["controles"]
           if c["origen"] == "dominio"}
    assert {"dominio:cpr_prepago", "dominio:smm_cpr_consistencia"} <= pre and "dominio:gap_reprecios" not in pre
    assert "dominio:gap_reprecios" in irr and "dominio:cpr_prepago" not in irr
    sin = {c["tipo"] for c in ci.proponer([p], dominio="ALM", usar_ia=False)["controles"] if c["origen"] == "dominio"}
    assert pre | irr <= sin                                      # sin tipo: todo el dominio, como antes


def _control_repo(carpeta, nombre):
    from modulos.repositorio_controles import cargar_controles
    cs, av = cargar_controles(carpeta)
    assert not av, av
    c = next(x for x in cs if x["nombre"] == nombre)
    ns: dict = {}
    exec(compile(c["fuente"], nombre, "exec"), ns)               # tests: ejecutar es la prueba
    return ns["control"], dict(c["meta"]["params"])


def test_los_analisis_nuevos_del_repositorio_detectan_lo_sembrado():
    rng = np.random.default_rng(3)
    c, p = _control_repo("var", "matriz_covarianzas")
    m = pd.DataFrame([("A", "A", 1), ("A", "B", .9), ("B", "A", .9), ("B", "B", 1), ("A", "C", .9), ("C", "A", .9),
                      ("B", "C", -.9), ("C", "B", -.9), ("C", "C", 1)], columns=["factor", "factor_j", "correlacion"])
    assert c(m, {}, p)["decision"] == "No cumple"
    c, p = _control_repo("var", "pla_frtb")
    h = rng.normal(0, 1, 250)
    assert c(pd.DataFrame({"hpl": h, "rtpl": h + rng.normal(0, .1, 250)}), {}, p)["decision"] == "Cumple"
    assert c(pd.DataFrame({"hpl": h, "rtpl": rng.normal(0, 1, 250)}), {}, p)["decision"] == "No cumple"
    c, p = _control_repo("alm", "nucleo_topes_bcbs")
    r = c(pd.DataFrame({"segmento": ["Minorista no transaccional"], "core": [0.75], "vida_media": [3]}), {}, p)
    assert r["decision"] == "No cumple" and "70%" in r["diagnostico"]
    c, p = _control_repo("lar", "runoff_tasas")
    f = pd.bdate_range("2023-01-01", periods=600)
    sal = pd.DataFrame({"fecha": f, "segmento": "MAYORISTA", "saldo": 1e9 * np.exp(np.cumsum(rng.normal(0, .01, 600)))})
    p["dataset_tasas"] = "tasas"
    r = c(sal, {"tasas": pd.DataFrame({"segmento": ["MAYORISTA"], "tasa_salida": [2.0]})}, p)
    assert r["decision"] == "No cumple" and "por debajo del histórico" in r["diagnostico"]
    c, p = _control_repo("lar", "lcr_tope_entradas")
    lcr = pd.DataFrame({"hqla": [120.0], "salidas": [100.0], "entradas": [90.0], "lcr": [12.0]})   # sin el tope
    r = c(lcr, {}, p)
    assert r["decision"] == "No cumple" and "NO aplicar el tope" in r["diagnostico"]
    c, p = _control_repo("lar", "factores_nsfr")
    assert c(pd.DataFrame({"factor_asf": [1, .8], "factor_rsf": [.05, .5]}), {}, p)["decision"] == "No cumple"


# ── Run-off: modelo de supervivencia del saldo ──────────────────────────────

def _cuant() -> dict:
    from modulos.libreria_cuant import LIBRERIA_CUANT
    ns: dict = {}
    exec(compile(LIBRERIA_CUANT, "<libreria_cuant>", "exec"), ns)      # tests: ejecutar es la prueba
    return ns


def _con_migracion(sal: pd.DataFrame) -> pd.DataFrame:
    """En 2023-06 la mitad del saldo de las cosechas de 2020 de MINORISTA migra a otro producto."""
    sal = sal.copy()
    m = ((sal["segmento"] == "MINORISTA") & sal["cosecha"].between("2020-01", "2020-12")
         & (pd.to_datetime(sal["fecha"]) >= pd.Timestamp("2023-06-30")))
    sal.loc[m, "saldo"] = (sal.loc[m, "saldo"] * 0.5).round(2)
    return sal


def test_el_run_off_replica_la_supervivencia_del_saldo_con_la_experiencia_historica():
    Q = _cuant()
    b = runoff_bases()
    P = [1, 3, 6, 12, 24, 36, 60]
    for seg, g in b["saldos_historia"].groupby("segmento"):
        k = Q["supervivencia_cosechas"](g["cosecha"], g["edad"], g["saldo"])
        assert np.allclose(np.interp(P, k["t"], k["S"]), curva_verdadera(seg, P), atol=0.01), seg
        c = Q["curva_runoff"](k["t"], k["S"])
        assert np.allclose(c["R"], 1 - c["S"]) and abs(c["d"].sum() - c["R"].iloc[-1]) < 1e-9
        est, vol, h = Q["componentes_runoff"](c["t"], c["S"], 60)
        assert abs(est - RUNOFF_VERDAD[seg][0]) < 0.01 and est + vol == pytest.approx(1) and h == 60
        ab = Q["asignar_bandas"](c["t"], c["S"], RUNOFF_BANDAS)
        assert ab["proporcion"].sum() == pytest.approx(1) and list(ab["banda"]) == RUNOFF_BANDAS
        assert Q["plazo_economico"](c["t"], c["S"], 120) > Q["plazo_economico"](c["t"], c["S"])   # el horizonte cuenta
        # El saldo existente ya trae su parte estable: se desgasta más lento que una cosecha nueva.
        e = Q["supervivencia_saldo_existente"](g["fecha"], g["cosecha"], g["saldo"], 24)
        assert np.interp(12, e["t"], e["S"]) > np.interp(12, k["t"], k["S"]) + 0.1
    assert Q["limites_banda"](">10A") == (120.0, np.inf) and Q["limites_banda"]("3M") == (None, 3.0)
    assert Q["limites_banda"]("Más de 5 años") == (60.0, np.inf) and Q["limites_banda"]("1-2A") == (12.0, 24.0)
    assert Q["edad_meses"](pd.Series(pd.to_datetime(["2024-05-31"])), pd.Series(["2024-01"])).tolist() == [4.0]
    # Sin cosechas solo queda el benchmark exponencial: el saldo total mezcla el negocio nuevo.
    tot = b["saldos_historia"].groupby(["fecha", "segmento"], as_index=False)["saldo"].sum()
    assert Q["replicar_runoff"](tot, 60)[1]["metodo"].str.contains("benchmark").all()
    # Backtesting del saldo existente: la curva verdadera acierta; con el estable inflado sale más de lo previsto.
    for fallas in (False, True):
        bb = runoff_bases(fallas=fallas)
        may = bb["saldos_historia"][bb["saldos_historia"]["segmento"] == "MAYORISTA"]
        bt = Q["backtesting_runoff"](may, Q["curvas_del_modelo"](bb["curva_runoff"])["MAYORISTA"], 12)
        assert (bt["error"].abs().mean() < 0.005) if not fallas else (bt["error"].mean() < -0.02)


def test_los_analisis_de_run_off_del_repositorio_detectan_lo_sembrado():
    limpio, malo = runoff_bases(), runoff_bases(fallas=True)
    c, p = _control_repo("alm", "runoff_curvas")
    assert c(limpio["curva_runoff"], limpio, p)["decision"] == "Cumple"
    r = c(malo["curva_runoff"], malo, p)
    assert r["decision"] == "No cumple" and "MINORISTA: S sube" in r["diagnostico"] and "MAYORISTA: S sube" not in r["diagnostico"]
    c, p = _control_repo("alm", "runoff_supervivencia_saldos")
    assert c(limpio["saldos_historia"], limpio, p)["decision"] == "Revisión manual"          # sin la curva del modelo
    p["dataset_curva"] = "curva_runoff"
    assert c(limpio["saldos_historia"], limpio, p)["decision"] == "Cumple"
    r = c(malo["saldos_historia"], malo, p)
    assert r["decision"] == "Observado" and "MAYORISTA 12m" in r["diagnostico"]
    # La curva verdadera es de cosechas: medida como saldo existente (el stock ya trae su estable) no coincide.
    assert c(limpio["saldos_historia"], limpio, dict(p, curva_de="saldo_existente"))["decision"] == "Observado"
    assert c(limpio["saldos_historia"], limpio, dict(p, curva_de="otra"))["decision"] == "No evaluable"
    c, p = _control_repo("alm", "runoff_saltos_cosechas")
    assert c(limpio["saldos_historia"], limpio, p)["decision"] == "Cumple"
    r = c(_con_migracion(limpio["saldos_historia"]), {}, p)
    assert r["decision"] == "Observado" and "2023-06 (12)" in r["diagnostico"]
    c, p = _control_repo("alm", "supervivencia_km")
    p["dataset_curva"] = "curva_runoff"
    r = c(limpio["cuentas"], limpio, p)
    assert "MAYORISTA: S(12m)" in r["diagnostico"] and "MINORISTA: S(12m)" in r["diagnostico"]   # segmento a segmento


# ── 4. Validación completa: ruta, experto y etapas ──────────────────────────

def test_la_ruta_se_verifica_contra_el_notebook():
    r = VC.normalizar_ruta("00", [{"paso": "00.1", "estado": "cubierto"}, {"paso": "00.2", "estado": "cubierto"},
                                  {"paso": "00.7", "estado": "no_aplica", "nota": "no"}],
                           ["## Paso 00.1 · Inventario"])
    est = {p["paso"]: p["estado"] for p in r}
    assert est["00.1"] == "cubierto"
    assert est["00.2"] == "pendiente"                              # dijo «cubierto» sin su sección
    assert est["00.7"] == "pendiente"                              # «no aplica» sin motivo
    assert len(r) == 8


class _Cliente:
    def __init__(self, extra=None):
        self.prompts = []
        self.extra = extra or {}

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None, formato_json=False, **_):
        if "ESTUDIAS un" in instruccion_sistema:
            return json.dumps({"tipo": "manual", "resumen": "ficha", "etapas": ["02"]})
        self.prompts.append((instruccion_sistema, prompt))
        return json.dumps({"respuesta": "ok", "resumen": "r", "cambios_notebook": "c",
                           "cuaderno": [{"tipo": "markdown", "contenido": "## Paso 02.1 · Población"},
                                        {"tipo": "code", "contenido": "registrar('Poblacion', [{'n': 1}])"}],
                           "tabla": [], "hallazgos": [], "pendientes": [],
                           "ruta": [{"paso": "02.1", "estado": "cubierto"}, {"paso": "02.5", "estado": "cubierto"}],
                           "veredicto": {"estado": "lista", "motivo": "m"}, **self.extra})


def test_el_prompt_de_cada_etapa_es_experto_en_el_tipo_de_modelo(tmp_path):
    cli = _Cliente()
    r = VC.ejecutar_iteracion(inputs=tmp_path / "i", outputs=tmp_path / "o", codigo="02", archivos=[],
                              comentario="replica", usar_ia=True, cliente=cli, rutas_texto="saldos = s.csv",
                              tipos_modelo=["prepago"])
    sistema, prompt = cli.prompts[0]
    assert "RUTA PASO A PASO" in sistema
    for clave in ("EXPERTO DE LA ETAPA", "Modelador cuantitativo", "RUTA DE LA ETAPA", "02.5", "Prepago",
                  "SMM", "LIBRERÍA CUANTITATIVA", "smm_cpr("):
        assert clave in prompt, clave
    est = {p["paso"]: p["estado"] for p in r["resultado"]["ruta"]}
    assert est["02.1"] == "cubierto" and est["02.5"] == "pendiente"   # 02.5 sin su sección en el notebook
    assert r["resultado"]["veredicto"]["estado"] == "otra_iteracion"   # «lista» con pasos pendientes, no
    assert "Faltan pasos de la ruta" in r["resultado"]["veredicto"]["motivo"]
    sin_tipo = _Cliente()
    VC.ejecutar_iteracion(inputs=tmp_path / "i2", outputs=tmp_path / "o2", codigo="00", archivos=[], comentario="x",
                          usar_ia=True, cliente=sin_tipo, rutas_texto="a = a.csv")
    assert "TIPO DE MODELO: no elegido" in sin_tipo.prompts[0][1]


def test_la_etapa_01_con_ia_suma_controles_validados_y_celdas_del_experto(tmp_path):
    datos = tmp_path / "datos"
    datos.mkdir()
    pd.DataFrame({"fecha": pd.bdate_range("2024-01-01", periods=30), "segmento": "A", "saldo": 10.0}).to_csv(
        datos / "saldos.csv", index=False)
    inputs, outputs = tmp_path / "inputs", tmp_path / "outputs"
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[], comentario="x", usar_ia=False,
                          rutas_texto=f"saldos = {datos / 'saldos.csv'}", tipos_modelo=["runoff"])
    nb00 = VC.dir_salida(outputs, "00") / "00_DiagnosticoITER0.ipynb"
    trabajo = tmp_path / "t00"
    trabajo.mkdir()
    r = _correr_codigo(_codigo_nb(json.loads(nb00.read_text(encoding="utf-8"))), trabajo)
    assert r.returncode == 0, r.stderr[-2000:]
    x00 = trabajo / "00_Diagnostico_resultadoITER0.xlsx"
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[(x00.name, x00.read_bytes())],
                          comentario="resultado", usar_ia=False, tipos_modelo=["runoff"])
    cli = _Cliente({"controles": [
        {"dataset": "saldos", "tipo": "cardinalidad", "columnas": ["segmento"], "params": {"minimo": 1, "maximo": 5},
         "descripcion": "Pocos segmentos", "justificacion": "segmentación del run-off", "criticidad": "MEDIA"},
        {"dataset": "saldos", "tipo": "no_negativos", "columnas": ["inventada"], "params": {}}],
        "cuaderno": [{"tipo": "markdown", "contenido": "### Conciliación del experto"},
                     {"tipo": "code", "contenido": "registrar('Experto', [{'ok': 1}])"}]})
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="01", archivos=[], comentario="controla",
                          usar_ia=True, cliente=cli, tipos_modelo=["runoff"], dominio="LaR")
    nb01 = json.loads((VC.dir_salida(outputs, "01") / "01_ControlDatosITER0.ipynb").read_text(encoding="utf-8"))
    texto = "\n".join("".join(c["source"]) for c in nb01["cells"])
    assert "'id': 'IA01'" in texto and "inventada" not in texto        # el control de la IA se validó
    assert "registrar('Experto'" in texto and "Batería completa" in texto and "4a · Controles del tipo de modelo" in texto
    assert nb01["metadata"]["virf"]["salida"] == "01_ControlDatos_resultadoITER0.xlsx"
    prompt = cli.prompts[0][1]
    assert "VIRF ARMA EL NOTEBOOK DE CALIDAD DE DATOS" in prompt and "valores_repetidos" in prompt
    assert "PERFIL DE LAS BASES" in prompt and "saldo" in prompt
    trabajo = tmp_path / "t01"
    trabajo.mkdir()
    r = _correr_codigo(_codigo_nb(nb01), trabajo)
    assert r.returncode == 0, r.stderr[-3000:]
    hojas = pd.read_excel(trabajo / "01_ControlDatos_resultadoITER0.xlsx", sheet_name=None)
    assert {"Controles", "Roles", "Mapeo", "Fallas", "Experto", "Indice"} <= set(hojas)
    assert "IA01" in set(hojas["Controles"]["Control"])


def test_todas_las_plantillas_de_todos_los_tipos_compilan(tmp_path):
    for tid in tm.TIPOS:
        for codigo in ("00", "02", "03", "04"):
            celdas = VC._celdas_plantilla(codigo, [tid], [])
            nb = VC.construir_notebook(codigo, 0, {"a": "a.csv"}, celdas, "", [tid], {})
            for c in nb["cells"]:
                if c["cell_type"] == "code":
                    ast.parse("".join(c["source"]))                   # solo se analiza, no se ejecuta
            titulos = VC._pasos_en_notebook(["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "markdown"])
            from modulos.plantillas_etapa import RUTAS
            assert {p for p, *_ in RUTAS[codigo]} <= titulos, (tid, codigo)   # la plantilla recorre TODA la ruta


def test_la_ruta_completa_de_un_run_off_replica_cuantifica_y_hace_backtesting(tmp_path):
    # Historia por cosechas con fallas sembradas: MINORISTA con S que sube a los 24 meses y una migración en
    # 2023-06; MAYORISTA con el estable del modelo inflado (45 % vs 30 %), estable + volátil = 95 % y bandas al 95 %.
    b = runoff_bases(fallas=True)
    b["saldos_historia"] = _con_migracion(b["saldos_historia"])
    b["contabilidad"] = b["saldos_historia"].groupby("fecha", as_index=False)["saldo"].sum()
    datos = tmp_path / "datos"
    datos.mkdir()
    rutas = []
    for k, d in b.items():
        d.to_csv(datos / f"{k}.csv", index=False)
        rutas.append(f"{k} = {datos / (k + '.csv')}")
    inputs, outputs = tmp_path / "inputs", tmp_path / "outputs"
    hojas = {}
    for codigo in ("00", "01", "02", "03", "04"):
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo=codigo, archivos=[], comentario="x",
                              usar_ia=False, rutas_texto="\n".join(rutas), tipos_modelo=["runoff"], dominio="ALM")
        nb = json.loads((VC.dir_salida(outputs, codigo) / f"{VC.ETAPAS[codigo]['fichero']}ITER0.ipynb")
                        .read_text(encoding="utf-8"))
        trabajo = tmp_path / f"t{codigo}"
        trabajo.mkdir()
        r = _correr_codigo(_codigo_nb(nb), trabajo)
        assert r.returncode == 0, (codigo, r.stderr[-3000:])
        x = trabajo / VC.nombre_resultado(codigo, 0)
        hojas[codigo] = pd.read_excel(x, sheet_name=None)
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo=codigo, archivos=[(x.name, x.read_bytes())],
                              comentario="resultado", usar_ia=False, tipos_modelo=["runoff"], dominio="ALM")
    # 00 · entiende el negocio: cada concepto del run-off en su columna.
    dic = hojas["00"]["Diccionario"]
    enl = dict(zip(dic["base_logica"] + "." + dic["rol"], dic["columna"]))
    assert enl["componentes.core"] == "porcion_estable" and enl["componentes.volatil"] == "porcion_volatil"
    assert enl["componentes.vida_media"] == "plazo_economico" and enl["saldos.cosecha"] == "cosecha"
    assert enl["curva.runoff_incremental"] == "runoff_incremental" and enl["bandas.proporcion"] == "proporcion"
    # 01 · caza lo sembrado.
    ctl = hojas["01"]["Controles"]

    def decision(texto):
        fila = ctl[ctl["Descripción"].astype(str).str.contains(texto, regex=False)]
        assert len(fila), texto
        return fila["Decisión"].iloc[0]

    assert decision("Sin saltos de saldo por migraciones") == "No cumple"        # en el total del segmento…
    assert decision("link ratio de cada cosecha") == "No cumple"                 # … y cosecha por cosecha
    assert decision("nunca sube con el plazo") == "No cumple"
    assert decision("desgaste incremental de cada periodo no es negativo") == "No cumple"
    assert decision("suma el 100 % del saldo") == "No cumple"
    assert decision("estable + volátil = 100 %") == "No cumple"
    assert decision("se reproduce con la historia") == "No cumple"               # curva del modelo vs histórica
    assert decision("Un registro por periodo y segmento") == "Cumple"            # la llave incluye la cosecha
    # 02 · replica la curva, los componentes, el plazo económico y las bandas.
    rep = hojas["02"]["Replica"].set_index("paso")["conclusion"].astype(str)
    coh = "Curva del modelo coherente (S no sube, R = 1 − S, d = S(t−1) − S(t) ≥ 0) · "
    assert rep[coh + "MINORISTA"].startswith("Difiere") and rep[coh + "MAYORISTA"] == "Coincide"
    assert rep["S(12 meses) modelo vs histórico · MAYORISTA"].startswith("Difiere")
    assert rep["S(12 meses) modelo vs histórico · MINORISTA"].startswith("Coincide")
    assert rep["Componente estable · MAYORISTA"].startswith("Difiere")
    assert rep["Estable + volátil = 100 % · MAYORISTA"].startswith("Difiere")
    assert rep["Asignación a bandas suma 100 % · MAYORISTA"].startswith("Difiere")
    assert rep["Asignación a bandas suma 100 % · MINORISTA"].startswith("Coincide")
    assert rep["Plazo económico vs ∫S de la curva del modelo · MAYORISTA"].startswith("Coincide")
    assert rep["Plazo económico vs ∫S de la curva histórica · MAYORISTA"].startswith("Difiere")
    assert {"Replica_curva", "Replica_componentes", "Replica_bandas"} <= set(hojas["02"])
    # 03 · quitar la migración cambia el componente estable de forma material.
    imp = hojas["03"]["Impactos"]
    mig = imp[imp["origen"].astype(str).str.contains("migraciones")]
    assert len(mig) and mig["nivel"].iloc[0] == "Crítico"
    assert mig["valor_corregido"].iloc[0] > mig["valor_original"].iloc[0]
    # 04 · backtesting del saldo existente y estabilidad de la curva.
    bt = hojas["04"]["Backtesting"].set_index("segmento")
    assert bt.loc["MAYORISTA", "zona"] in ("ámbar", "roja") and bt.loc["MAYORISTA", "sesgo_pp"] < -2
    assert bt.loc["MINORISTA", "zona"] == "verde"
    assert hojas["04"]["Seguimiento"]["indicador"].str.contains("Estabilidad de S").any()
    est = VC.estado_etapa(outputs, "02")
    assert est["experto"].startswith("Modelador") and len(est["ruta"]) == 8


@pytest.mark.parametrize("tid", ["irrbb", "lcr", "prepago", "nmd"])
def test_la_replica_del_02_corre_para_cada_familia(tmp_path, tid):
    datos = tmp_path / "datos"
    datos.mkdir()
    rutas = []
    for k, d in bases_sinteticas(tid).items():
        d.to_csv(datos / f"{k}.csv", index=False)
        rutas.append(f"{k} = {datos / (k + '.csv')}")
    inputs, outputs = tmp_path / "inputs", tmp_path / "outputs"
    # El flujo real: el 00 perfila las bases y su Excel vuelve al chat (de ahí sale el enlace de roles).
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[], comentario="x",
                          usar_ia=False, rutas_texto="\n".join(rutas), tipos_modelo=[tid])
    nb = json.loads((VC.dir_salida(outputs, "00") / "00_DiagnosticoITER0.ipynb").read_text(encoding="utf-8"))
    (tmp_path / "t00").mkdir()
    r = _correr_codigo(_codigo_nb(nb), tmp_path / "t00")
    assert r.returncode == 0, r.stderr[-3000:]
    x00 = tmp_path / "t00" / "00_Diagnostico_resultadoITER0.xlsx"
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[(x00.name, x00.read_bytes())],
                          comentario="resultado", usar_ia=False, tipos_modelo=[tid])
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="02", archivos=[], comentario="x",
                          usar_ia=False, tipos_modelo=[tid])
    nb = json.loads((VC.dir_salida(outputs, "02") / "02_ModelamientoITER0.ipynb").read_text(encoding="utf-8"))
    r = _correr_codigo(_codigo_nb(nb), tmp_path)
    assert r.returncode == 0, r.stderr[-3000:]
    rep = pd.read_excel(tmp_path / "02_Modelamiento_resultadoITER0.xlsx", sheet_name="Replica")
    assert len(rep) and not rep["conclusion"].astype(str).str.startswith("No replicable").all()


# ── 5. Ficha del modelo y API ───────────────────────────────────────────────

def test_el_tipo_de_modelo_es_explicito_en_la_ficha(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services import modelos_store, sesion_store
    monkeypatch.setattr(modelos_store, "_base_validador", lambda c: tmp_path / c)
    monkeypatch.setattr(modelos_store, "_base_modelo", lambda c, s: tmp_path / c / s)
    m = modelos_store.crear("T9", "Run off depositos", "LaR", "II", tipos_modelo=["runoff", "runoff"])
    assert m["tipos_modelo"] == ["runoff"]
    with pytest.raises(ValueError, match="tipo de modelo desconocido"):
        modelos_store.crear("T9", "Otro", "LaR", "II", tipos_modelo=["adivinado"])
    m = modelos_store.actualizar_meta("T9", m["slug"], tipos_modelo=["runoff", "lcr"])
    assert m["tipos_modelo"] == ["runoff", "lcr"]
    assert modelos_store.actualizar_meta("T9", m["slug"], tier="I")["tipos_modelo"] == ["runoff", "lcr"]
    monkeypatch.setattr(sesion_store, "sesion_activa", lambda tok: {"codigo": "T9", "nombre": "T"} if tok else None)
    c = TestClient(app)
    c.cookies.set("virf_token", "tok")
    tipos = c.get("/api/modelos/tipos", params={"dominio": "LaR"}).json()["tipos"]
    assert tipos[0]["del_dominio"] and tipos[0]["familia"] == "Liquidez"
    assert {t["id"] for t in tipos} == set(tm.TIPOS)
