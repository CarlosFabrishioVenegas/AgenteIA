"""
«Solo Informe» · lo pedido el 2026-11-23. Coste cero (IA simulada con
`_llm_de_prueba`, todo en `tmp_path`).

  1. Holgura del estándar: cada control puede marcarse «No aplica» (sale del
     cumplimiento, con su motivo) o «No revisado (limitación)» (no se da por
     satisfactorio y va a Limitaciones); el validador añade actividades
     adicionales y escribe la descripción propia de cada control.
  2. «Especializar documento»: la «Descripción de lo realizado» deja de ser el
     genérico «Como parte del barrido…» (plantilla sin IA o IA verificada).
  3. Una observación con VARIOS sustentos.
  4. Figuras estructuradas (hallazgo, proceso, comparación) sin cifras ni ideas
     inventadas.
  5. Código del modelo en los datos de la validación, la portada, la ficha y el
     nombre del fichero.
"""
from __future__ import annotations

import io
import json
from pathlib import Path

import pytest
from docx import Document

from modulos import graficos_estructurados as graf
from modulos import plantilla_bcp
from web.services import solo_informe_ia as ia
from web.services import solo_informe_service as svc
from web.services import solo_informe_word

ESTANDAR = {
    "ambitos": ["Documentación", "Gobierno"],
    "tiene_tier": False,
    "controles": [
        {"id": "C001", "ambito": "Documentación", "clave_ambito": "documentacion",
         "control": "Manual metodológico", "control_especifico": "",
         "actividad": "Verifica la existencia de control de cambios/versiones", "tiers": None},
        {"id": "C002", "ambito": "Documentación", "clave_ambito": "documentacion",
         "control": "Manual metodológico", "control_especifico": "",
         "actividad": "Verifica la inclusión del objetivo, usos y usuarios", "tiers": None},
        {"id": "C003", "ambito": "Gobierno", "clave_ambito": "gobierno",
         "control": "Comité", "control_especifico": "",
         "actividad": "Revisar las actas de aprobación del comité", "tiers": None},
    ],
}


def _datos(**extra) -> dict:
    d = {"tipo": "periodica", "nombre_modelo": "VaR Histórico", "codigo_modelo": "MR-VAR-014",
         "fecha_inicio": "2026-10-01", "fecha_entrega": "2026-11-20",
         "contexto": "Modelo de VaR histórico de la cartera de Trading.", "limitaciones": "",
         "observaciones": [], "controles_revision": {}, "controles_extra": []}
    d.update(extra)
    return d


def _texto(doc) -> str:
    partes = [p.text for p in doc.paragraphs]
    partes += [c.text for t in doc.tables for f in t.rows for c in f.cells]
    return "\n".join(partes)


def _png() -> bytes:
    from PIL import Image
    buf = io.BytesIO(); Image.new("RGB", (30, 20), (10, 120, 200)).save(buf, "PNG")
    return buf.getvalue()


# ── 1. Holgura sobre los controles ──────────────────────────────────────

def test_no_aplica_sale_del_cumplimiento_y_exige_motivo():
    d = _datos(controles_revision={"C002": {"estado": "no_aplica", "motivo": ""}})
    errores = svc.validar_datos(d, ESTANDAR)
    assert any("No aplica" in e and "motivo" in e for e in errores)

    d["controles_revision"]["C002"]["motivo"] = "El modelo no tiene usuarios externos."
    assert svc.validar_datos(d, ESTANDAR) == []
    est = svc.estandar_del_informe(ESTANDAR, d)
    filas = {f["ambito"]: f for f in svc.cumplimiento(est, [])}
    assert filas["Documentación"]["total"] == 1 and filas["Documentación"]["no_aplica"] == 1


def test_observacion_sobre_control_no_aplica_se_rechaza():
    d = _datos(controles_revision={"C003": {"estado": "no_aplica", "motivo": "Sin comité."}},
               observaciones=[{"riesgo": "Bajo", "control_id": "C003", "observacion": "x"}])
    assert any("No aplica" in e for e in svc.validar_datos(d, ESTANDAR))


def test_limitacion_no_es_satisfactoria_y_va_a_limitaciones(tmp_path):
    d = _datos(controles_revision={
        "C003": {"estado": "limitacion", "motivo": "No se entregaron las actas de 2025."},
        "C002": {"estado": "no_aplica", "motivo": "Modelo sin usuarios externos."}})
    est = svc.estandar_del_informe(ESTANDAR, d)
    filas = {f["ambito"]: f for f in svc.cumplimiento(est, [])}
    assert filas["Gobierno"]["satisfactorios"] == 0 and filas["Gobierno"]["no_cumplidos"] == 1

    doc = Document(str(solo_informe_word.generar(d, ESTANDAR, tmp_path)))
    txt = _texto(doc)
    assert "No se entregaron las actas de 2025" in txt                 # en Limitaciones
    assert "NO REVISADA (limitación)" in txt
    assert "NO APLICA" in txt and "Modelo sin usuarios externos" in txt
    assert "se excluye del cumplimiento" in txt
    assert "no se pudieron revisar (ver IV.2 Limitaciones)" in txt
    # Cumplimiento: Documentación 1 de 1 (C002 excluido); Gobierno 0 de 1.
    tabla = next(t for t in doc.tables if t.rows[0].cells[0].text == "Ámbito")
    assert [c.text for c in tabla.rows[1].cells] == ["Documentación", "1", "1 (100.0%)", "0 (0.0%)"]
    assert [c.text for c in tabla.rows[2].cells] == ["Gobierno", "1", "0 (0.0%)", "1 (100.0%)"]


def test_actividad_adicional_del_validador(tmp_path):
    d = _datos(controles_extra=[{"id": "X001", "ambito": "Gobierno", "control": "",
                                 "actividad": "Revisar el registro de incidencias del modelo"}],
               observaciones=[{"riesgo": "Moderado", "control_id": "X001",
                               "observacion": "Incidencias sin cerrar", "responsable": "Riesgos",
                               "fecha_subsanacion": "2027-01-31"}])
    assert svc.validar_datos(d, ESTANDAR) == []
    doc = Document(str(solo_informe_word.generar(d, ESTANDAR, tmp_path)))
    txt = _texto(doc)
    assert "Revisar el registro de incidencias del modelo" in txt
    assert "Actividad adicional del validador" in txt               # control por defecto
    assert "1 adicional(es) del validador" in txt                    # en el Alcance
    assert "Incidencias sin cerrar" in txt


def test_descripcion_propia_reemplaza_al_generico(tmp_path):
    d = _datos(controles_revision={"C001": {
        "estado": "revisado", "descripcion": "Se revisó el historial de versiones del manual."}})
    doc = Document(str(solo_informe_word.generar(d, ESTANDAR, tmp_path)))
    parrafos = [p.text for p in doc.paragraphs]
    assert ("Descripción de lo realizado: Se revisó el historial de versiones del manual."
            in parrafos)


def test_ambito_del_extra_casa_con_el_del_estandar():
    d = _datos(controles_extra=[{"id": "X001", "ambito": "gobierno", "actividad": "Otra"}])
    est = svc.con_actividades_extra(ESTANDAR, d)
    assert est["ambitos"] == ["Documentación", "Gobierno"]
    assert est["controles"][-1]["ambito"] == "Gobierno"


# ── 2. Especializar documento ───────────────────────────────────────────

@pytest.fixture
def llm(monkeypatch):
    class _Falso:
        respuestas: list[str] = []
        prompts: list[str] = []

        def __call__(self, prompt, sistema, max_tokens):
            self.prompts.append(prompt)
            return self.respuestas.pop(0) if self.respuestas else "{}"
    f = _Falso(); f.respuestas = []; f.prompts = []
    monkeypatch.setattr(ia, "_llm_de_prueba", f)
    return f


def test_especializar_plantilla_sin_ia(tmp_path):
    ia.guardar_manual(tmp_path, "Manual VaR.txt", b"Control de versiones: mayo 2023.")
    d = _datos(observaciones=[{"riesgo": "Bajo", "control_id": "C001", "observacion": "x"}])
    r = ia.especializar(tmp_path, d, ESTANDAR, usar_ia=False)
    assert r["llamadas"] == 0 and set(r["propuestas"]) == {"C001", "C002", "C003"}
    t = r["propuestas"]["C001"]["texto"]
    assert t.startswith("Se verificó la existencia de control de cambios/versiones")
    assert "VaR Histórico (MR-VAR-014)" in t and "«Manual VaR.txt»" in t
    assert "como parte del barrido" not in t.lower()
    assert "observación registrada" in t


def test_especializar_con_ia_verifica_cada_texto(tmp_path, llm):
    ia.guardar_manual(tmp_path, "manual.txt",
                      "Control de versiones del manual: última versión de mayo de 2023."
                      .encode("utf-8"))
    llm.respuestas = [
        # 1.ª llamada: adaptar el estándar (aquí no propone nada).
        json.dumps({"actividades": [], "no_aplica": []}),
        json.dumps({"descripciones": {
            "C001": "Se revisó la tabla de control de versiones del manual metodológico "
                    "[manual.txt, pág. 1], verificando que registre la versión de 2023.",
            # Cifra inventada (2019): se descarta y se queda la plantilla.
            "C002": "Se revisó la sección de objetivos y usuarios del manual de 2019, "
                    "contrastándola con el criterio del control.",
        }}),
        json.dumps({"descripciones": {
            # Cita a una página que no se consultó: se descarta.
            "C003": "Se revisaron las actas del comité [manual.txt, pág. 7] contra el criterio.",
        }}),
    ]
    r = ia.especializar(tmp_path, _datos(), ESTANDAR, usar_ia=True)
    p = r["propuestas"]
    assert r["llamadas"] == 3                       # adaptar + una por ámbito
    assert p["C001"]["origen"] == "ia" and p["C001"]["fuentes"]
    assert p["C002"]["origen"] == "plantilla" and "2019" in p["C002"]["aviso"]
    assert p["C003"]["origen"] == "plantilla" and "pág. 7" in p["C003"]["aviso"]
    assert 'archivo="manual.txt"' in llm.prompts[1]


# ── 2b. Adaptar el estándar SIN quitar la holgura ───────────────────────

ESTANDAR_TIER = {
    "ambitos": ["Documentación", "Gobierno"], "tiene_tier": True,
    "tiers_presentes": ["I", "II", "III", "IV"],
    "controles": [
        {**ESTANDAR["controles"][0], "tiers": ["I", "II", "III", "IV"]},
        {**ESTANDAR["controles"][1], "tiers": ["I", "II", "III", "IV"]},
        {"id": "C003", "ambito": "Gobierno", "clave_ambito": "gobierno",
         "control": "Verificar nivel de alineamiento del gobierno de modelos",
         "control_especifico": "", "actividad": "Revisar la actualización del tiering del modelo",
         "tiers": ["I", "III", "IV"]},
        {"id": "C004", "ambito": "Gobierno", "clave_ambito": "gobierno",
         "control": "Verificar nivel de alineamiento del gobierno de modelos",
         "control_especifico": "", "actividad": "Revisar que el modelo se encuentre inventariado",
         "tiers": ["I", "III", "IV"]},
    ],
}


def test_gobierno_sin_actividades_para_el_tier_sale_en_el_informe(tmp_path):
    from web.services import solo_informe_service as s
    d = _datos(tier="II")
    est = s.estandar_del_informe(ESTANDAR_TIER, d)
    assert est["ambitos"] == ["Documentación", "Gobierno"]
    assert est["ambitos_sin_actividades"] == ["Gobierno"]
    filas = {f["ambito"]: f for f in s.cumplimiento(est, [])}
    assert filas["Gobierno"]["total"] == 0 and filas["Gobierno"]["pct_ok"] is None
    doc = Document(str(solo_informe_word.generar(d, ESTANDAR_TIER, tmp_path)))
    txt = _texto(doc)
    assert "Gobierno (sin actividades del estándar para este modelo)." in txt
    assert "Para un modelo Tier II, el estándar de validación no exige actividades" in txt
    tabla = next(t for t in doc.tables if t.rows[0].cells[0].text == "Ámbito")
    assert [c.text for c in tabla.rows[2].cells] == ["Gobierno", "0", "—", "—"]


def test_sin_ia_sugiere_las_actividades_de_gobierno_de_otros_tiers(tmp_path):
    r = ia.especializar(tmp_path, _datos(tier="II"), ESTANDAR_TIER, usar_ia=False)
    sug = r["actividades_sugeridas"]
    assert [s["actividad"] for s in sug] == ["Revisar la actualización del tiering del modelo",
                                             "Revisar que el modelo se encuentre inventariado"]
    assert all(s["ambito"] == "Gobierno" and s["origen"] == "estandar" for s in sug)
    assert "Tier I, III, IV" in sug[0]["motivo"] and "sin actividades" in sug[0]["motivo"]
    assert r["sugerencias_estado"] == {}
    # Si el validador ya la agregó como actividad adicional, no se repite.
    d = _datos(tier="II", controles_extra=[{"id": "X001", "ambito": "Gobierno", "control": "",
                                            "actividad": "Revisar que el modelo se encuentre inventariado"}])
    sug2 = ia.especializar(tmp_path, d, ESTANDAR_TIER, usar_ia=False)["actividades_sugeridas"]
    assert [s["actividad"] for s in sug2] == ["Revisar la actualización del tiering del modelo"]


def test_la_ia_adapta_sin_pisar_la_holgura_del_validador(tmp_path, llm):
    d = _datos(tier="II",
               observaciones=[{"riesgo": "Bajo", "control_id": "C001", "observacion": "x"}],
               controles_revision={"C002": {"estado": "revisado",
                                            "descripcion": "Mi descripción propia."}})
    llm.respuestas = [
        json.dumps({
            "actividades": [
                {"ambito": "gobierno", "control": "Aprobación y roles",
                 "actividad": "Verificar que el modelo y sus cambios fueron aprobados por el comité",
                 "motivo": "El procedimiento del banco exige aprobación formal."},
                {"ambito": "Gobierno", "control": "x",
                 "actividad": "Revisar que el modelo se encuentre inventariado",     # ya sugerida
                 "motivo": "repetida"},
                {"ambito": "Gobierno", "control": "x",
                 "actividad": "Verificar que el comité sesionó 873 veces en el año",  # cifra inventada
                 "motivo": "según el acta"},
                {"ambito": "Inventado", "actividad": "Algo fuera del estándar de ámbitos"}],
            "no_aplica": [
                {"id": "C001", "motivo": "El modelo no tiene control de versiones propio documentado."},
                {"id": "C002", "motivo": "El objetivo y usuarios no aplican a este modelo interno."}]}),
        json.dumps({"descripciones": {}}),
    ]
    r = ia.especializar(tmp_path, d, ESTANDAR_TIER, usar_ia=True)
    acts = [s["actividad"] for s in r["actividades_sugeridas"]]
    assert "Verificar que el modelo y sus cambios fueron aprobados por el comité" in acts
    assert acts.count("Revisar que el modelo se encuentre inventariado") == 1
    assert not any("873 veces" in a for a in acts)
    # C001 tiene observaciones: nunca se sugiere «no aplica». C002 sí (es una
    # sugerencia: el estado no cambia hasta que el validador la acepte).
    assert "C001" not in r["sugerencias_estado"] and "C002" in r["sugerencias_estado"]
    assert r["propuestas"]["C002"]["conserva_propia"] is True
    assert "Criterio del banco" in llm.prompts[0]


def test_la_web_no_pisa_descripciones_propias_al_aceptar_todas():
    js = (Path(__file__).resolve().parents[1] / "web" / "static" / "js" / "app.js").read_text(encoding="utf-8")
    bloque = js[js.index('$("#si-esp-aceptar-todas").addEventListener'):][:900]
    assert "if (siRevision(cid).descripcion) { conservadas++; continue; }" in bloque


def test_endpoint_especializar(tmp_path, llm):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.routers.solo_informe import base_solo_informe
    app.dependency_overrides[base_solo_informe] = lambda: tmp_path
    try:
        c = TestClient(app)
        r = c.post("/api/solo-informe/ia/especializar", json={"datos": _datos(), "usar_ia": False})
        assert r.status_code == 400                               # sin estándar
        svc.ruta_json(tmp_path).write_text(json.dumps({**ESTANDAR, "origen": {}}),
                                           encoding="utf-8")
        r = c.post("/api/solo-informe/ia/especializar", json={"datos": _datos(), "usar_ia": False})
        assert r.status_code == 200, r.text
        assert len(r.json()["propuestas"]) == 3
    finally:
        app.dependency_overrides.pop(base_solo_informe, None)


# ── 3. Varios sustentos por observación ─────────────────────────────────

def test_varios_sustentos_en_el_word(tmp_path):
    img = svc.guardar_imagen(tmp_path, "captura.png", _png())
    d = _datos(observaciones=[{
        "riesgo": "Moderado", "control_id": "C001", "observacion": "Manual sin versiones",
        "responsable": "Riesgos", "fecha_subsanacion": "2027-01-31",
        "sustentos": [{"tipo": "imagen", "imagen_id": img, "contenido": "Portada del manual"},
                      {"tipo": "codigo", "contenido": "VERSION = None"},
                      {"tipo": "texto", "contenido": "El área confirmó por correo."},
                      {"tipo": "texto", "contenido": ""}]}])          # vacío: se ignora
    svc.normalizar_sustentos(d["observaciones"])
    assert len(d["observaciones"][0]["sustentos"]) == 3
    assert d["observaciones"][0]["sustento"]["tipo"] == "imagen"      # compat.
    doc = Document(str(solo_informe_word.generar(d, ESTANDAR, tmp_path)))
    txt = _texto(doc)
    assert "Sustento 1 de 3 de la observación 1:" in txt
    assert "Sustento 2 de 3 de la observación 1 (código):" in txt
    assert "Sustento 3 de 3 de la observación 1: El área confirmó por correo." in txt
    assert "VERSION = None" in txt and "Portada del manual" in txt


def test_borrador_antiguo_con_un_solo_sustento_sigue_valiendo():
    o = {"sustento": {"tipo": "texto", "contenido": "Uno"}}
    assert svc.sustentos_de(o) == [{"tipo": "texto", "contenido": "Uno"}]
    assert svc.sustentos_de({"sustento": {"tipo": "", "contenido": ""}}) == []


def test_sustento_vacio_se_reporta():
    d = _datos(observaciones=[{"riesgo": "Bajo", "control_id": "C001", "observacion": "x",
                               "sustentos": [{"tipo": "adjunto", "adjuntos": []}]}])
    assert any("sustento 1 está vacío" in e for e in svc.validar_datos(d, ESTANDAR))


# ── 4. Figuras estructuradas ────────────────────────────────────────────

FUENTE = ("El manual establece una ventana de 250 días y 99% de confianza. El código usa "
          "500 días y 95%. El cambio no fue aprobado por el comité. Esto subestima el VaR. "
          "Se recomienda alinear el código con el manual.")


def test_hallazgo_se_dibuja_y_marca_lo_que_no_consta(tmp_path):
    spec, avisos = graf.validar_spec({
        "tipo": "hallazgo", "titulo": "Ventana distinta",
        "criterio": "El manual establece una ventana de 250 días y 99% de confianza.",
        "condicion": "El código usa 500 días y 95%.",
        "causa": "Rotación del personal de sistemas y falta de presupuesto tecnológico.",
        "efecto": "Subestima el VaR.", "recomendacion": "Alinear el código con el manual."},
        FUENTE, riesgo="Crítico")
    assert spec["causa"] == graf.NO_CONSTA and avisos            # causa inventada
    png = graf.dibujar(spec, tmp_path / "h.png")
    assert png.read_bytes()[:4] == b"\x89PNG"


@pytest.mark.parametrize("spec", [
    {"tipo": "proceso", "titulo": "x", "fases": [
        {"nombre": "Datos", "pasos": ["Ventana de 500 días"], "estado": "observado"},
        {"nombre": "Cálculo", "pasos": ["Percentil"], "estado": "critico"}]},
    {"tipo": "comparacion", "titulo": "x", "columnas": ["Manual", "Código"],
     "filas": [{"aspecto": "Ventana", "a": "250 días", "b": "500 días", "coincide": False},
               {"aspecto": "Confianza", "a": "99%", "b": "95%", "coincide": False}]},
    {"tipo": "barras", "titulo": "Ventana", "etiquetas": ["Manual", "Código"],
     "valores": [250, 500], "referencia": 250},
])
def test_tipos_estructurados(tmp_path, spec):
    s, _ = graf.validar_spec(spec, FUENTE)
    assert graf.dibujar(s, tmp_path / "f.png").stat().st_size > 1000


@pytest.mark.parametrize("spec", [
    {"tipo": "comparacion", "titulo": "x", "columnas": ["Manual", "Código"],
     "filas": [{"aspecto": "Ventana", "a": "300 días", "b": "500 días", "coincide": False},
               {"aspecto": "Confianza", "a": "99%", "b": "95%", "coincide": False}]},
    {"tipo": "barras", "titulo": "x", "etiquetas": ["a", "b"], "valores": [250, 500],
     "referencia": 400},
    {"tipo": "proceso", "titulo": "x", "fases": [{"nombre": "Solo una", "pasos": ["a"]}]},
    {"tipo": "torta", "titulo": "x"},
])
def test_figuras_que_inventan_o_no_cuadran_se_rechazan(spec):
    with pytest.raises(graf.SpecInvalida):
        graf.validar_spec(spec, FUENTE)


def test_grafico_usa_la_observacion_completa(tmp_path, llm):
    llm.respuestas = [json.dumps({
        "tipo": "hallazgo", "titulo": "Ventana distinta",
        "criterio": "El manual establece una ventana de 250 días.",
        "condicion": "El código usa 500 días.", "causa": "El cambio no fue aprobado por el comité.",
        "efecto": "Subestima el VaR.", "recomendacion": "Alinear el código con el manual."})]
    texto = ("El código usa 500 días y el manual establece una ventana de 250 días; el cambio "
             "no fue aprobado por el comité.")
    r = ia.grafico(tmp_path, texto, "observacion",
                   {"recomendacion": "Alinear el código con el manual.",
                    "sustento": "Esto subestima el VaR.", "riesgo": "critico"})
    assert r["spec"]["tipo"] == "hallazgo" and r["spec"]["riesgo"] == "Crítico"
    assert "Recomendación: Alinear el código con el manual." in llm.prompts[0]
    assert (tmp_path / "imagenes" / r["imagen_id"]).is_file()


# ── 5. Código del modelo ─────────────────────────────────────────────────

def test_codigo_del_modelo_en_portada_y_fichero(tmp_path):
    ruta = solo_informe_word.generar(_datos(), ESTANDAR, tmp_path)
    assert ruta.name.startswith("Informe_Resultados_MR-VAR-014_VaR_Historico_")
    txt = _texto(Document(str(ruta)))
    assert "Código del modelo: MR-VAR-014" in txt


def test_plantilla_sin_codigo_muestra_guion(tmp_path):
    inf = {"tipo": "periodica", "nombre_modelo": "M", "fecha_inicio": "2026-10-01",
           "fecha_entrega": "2026-10-20", "ambitos": ["Gobierno"],
           "controles": [{"id": "1", "ambito": "Gobierno", "control": "C", "actividad": "A"}],
           "observaciones": []}
    doc = Document(str(plantilla_bcp.generar(inf, tmp_path / "x.docx")))
    ficha = next(t for t in doc.tables if t.rows[1].cells[0].text == "Título")
    assert ficha.rows[2].cells[0].text == "Código del modelo"
    assert ficha.rows[2].cells[1].text == "—"
