"""
RAG con el MATERIAL QUE USA EL BANCO (2026-11-23). Coste cero, sin red.

  · El generador convierte en corpus el estándar, el procedimiento, el catálogo
    de controles y las reglas de calificación; es reproducible e idempotente y
    NO mete evidencia de un modelo concreto (regla 1 del corpus).
  · El corpus se indexa como los demás (mismo motor léxico) y recupera el
    documento correcto en las preguntas-oro del banco.
  · No contamina los dominios de modelo y no se puede elegir como dominio.
  · El motor de evaluación lo consulta SIEMPRE (con su propio encuadre) y lo
    apaga RAG_BANCO=0.
"""
from __future__ import annotations

from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]


@pytest.fixture
def corpus(tmp_path):
    import scripts.generar_corpus_banco as gen
    destino = tmp_path / "banco"
    res = gen.generar(RAIZ / "inputs" / "Estandares_VIRF.xlsx",
                      RAIZ / "PROCEDIMIENTO_VALIDACION.md", destino)
    return destino, res


def _buscador_sobre(carpeta: Path, tmp_path: Path):
    from src.rag.buscador_lexico import BuscadorLexico
    from src.rag.indexador_lexico import IndexadorLexico
    idx = IndexadorLexico("banco", fuentes=[carpeta])
    idx.ruta = tmp_path / "indice" / "banco.pkl"
    idx.construir(force=True)
    b = BuscadorLexico("banco", autoconstruir=False)
    b._indexador = idx
    return b


def test_genera_los_cuatro_documentos_con_su_origen(corpus):
    destino, res = corpus
    assert set(res) == {"banco_estandar_validacion.md", "banco_procedimiento_validacion.md",
                        "banco_catalogo_controles_datos.md", "banco_reglas_informe.md"}
    for nombre in res:
        texto = (destino / nombre).read_text(encoding="utf-8")
        assert "MATERIAL INTERNO DEL BANCO" in texto and "huella SHA-256" in texto
        assert "no es evidencia del modelo validado" in texto
    est = (destino / "banco_estandar_validacion.md").read_text(encoding="utf-8")
    assert "## Ámbito: Documentación" in est and "aplica a Tier" in est
    assert (destino / "README.md").is_file()


def test_es_idempotente(corpus):
    import scripts.generar_corpus_banco as gen
    destino, _ = corpus
    res = gen.generar(RAIZ / "inputs" / "Estandares_VIRF.xlsx",
                      RAIZ / "PROCEDIMIENTO_VALIDACION.md", destino)
    assert not any(res.values())                     # nada se reescribe


def test_no_mete_evidencia_de_un_modelo(corpus):
    destino, _ = corpus
    todo = "\n".join(p.read_text(encoding="utf-8") for p in destino.glob("banco_*.md"))
    # El manual de controles del modelo LaR (inputs/calidad_datos/) es evidencia
    # de un modelo: no puede acabar en el criterio del banco.
    assert "Manual de Controles de Calidad de Datos — Modelo LaR" not in todo
    assert "data_subset" not in todo


def test_preguntas_oro_del_banco(corpus, tmp_path):
    from scripts.preguntas_oro_banco import evaluar
    destino, _ = corpus
    r = evaluar(_buscador_sobre(destino, tmp_path))
    fallos = [(f["id"], f["recuperado"][:2]) for f in r["filas"] if not f["r1"]]
    assert r["recall_1"] == 1.0, fallos


def test_el_corpus_del_repo_esta_al_dia():
    """El corpus versionado coincide con lo que genera el script (si alguien
    cambia el estándar o el procedimiento, hay que regenerarlo)."""
    import scripts.generar_corpus_banco as gen
    for nombre, texto in (("banco_estandar_validacion.md",
                           gen.doc_estandar(RAIZ / "inputs" / "Estandares_VIRF.xlsx")),
                          ("banco_procedimiento_validacion.md",
                           gen.doc_procedimiento(RAIZ / "PROCEDIMIENTO_VALIDACION.md")),
                          ("banco_catalogo_controles_datos.md", gen.doc_controles()),
                          ("banco_reglas_informe.md", gen.doc_reglas())):
        actual = (RAIZ / "inputs" / "rag" / "banco" / nombre).read_text(encoding="utf-8")
        assert actual == texto, (f"{nombre} desactualizado: ejecuta "
                                 "python scripts/generar_corpus_banco.py --reindexar")


def test_banco_no_es_un_dominio_de_modelo():
    from src import rag
    from web.services import dominios_custom_store as dcs, modelos_store
    assert "banco" not in rag.DOMINIOS_DISPONIBLES
    assert rag.inferir_dominio("Modelo del banco de crédito") != "banco"
    with pytest.raises(ValueError):
        rag.resolver_dominio("x", "banco")             # no se declara como dominio
    with pytest.raises(ValueError):
        modelos_store._valida_dominio("banco")
    assert dcs.existe("banco")
    assert any(d["id"] == "banco" and d["tipo"] == "banco" for d in dcs.listar())
    with pytest.raises(ValueError):
        dcs.borrar("banco")
    from src.rag.banco.retriever import BancoRetriever
    assert isinstance(rag.get_retriever("banco"), BancoRetriever)


def test_reindexado_y_subida_lo_conocen():
    import scripts.rebuild_rag_databricks as rb
    from src.rag import config_rag
    from web.services.contexto_sesion import formatos_destino
    assert "banco" in rb._dominios_conocidos()
    assert type(rb._get_indexer("banco")).__name__ == "BancoIndexer"
    assert "banco" in config_rag.CORPUS_INDEXABLES and "banco" not in config_rag.DOMINIOS
    assert {".docx", ".xlsx", ".pptx"} <= set(formatos_destino("rag_banco"))


class _RetrieverFalso:
    def __init__(self):
        self.consultas = []

    def query_para_prompt(self, texto, top_k=5, min_score=0.3):
        self.consultas.append((texto, top_k))
        return ("## Conocimiento recuperado — dominio: banco\n"
                "### [1] Fuente: banco_procedimiento_validacion.md\n"
                "Incompatibilidad estricta: quien desarrolló el modelo no puede firmar.")


def test_el_motor_consulta_el_criterio_del_banco(monkeypatch):
    from modulos import motor_ia
    falso = _RetrieverFalso()
    monkeypatch.setitem(motor_ia._rag_retriever_cache, "__banco__", falso)
    monkeypatch.setattr(motor_ia, "RAG_BANCO", True)
    bloque = motor_ia._criterio_banco("Verificar la segregación de funciones", "Gobierno", top_k=2)
    assert falso.consultas == [("[Gobierno] Verificar la segregación de funciones", 2)]
    marco = motor_ia._enmarcar_banco(bloque)
    assert "CRITERIO DEL BANCO" in marco and "NO es evidencia del modelo" in marco
    assert "banco_procedimiento_validacion.md" in marco
    assert motor_ia._enmarcar_banco("") == ""
    # Apagado explícito.
    monkeypatch.setattr(motor_ia, "RAG_BANCO", False)
    assert motor_ia._criterio_banco("x", "Gobierno") == ""


def test_evaluar_actividad_inyecta_y_registra_el_criterio_del_banco():
    import inspect
    from modulos import motor_ia
    src = inspect.getsource(motor_ia.evaluar_actividad)
    assert "_criterio_banco(" in src and "_enmarcar_banco(" in src
    assert 'resultado["rag_fuentes_banco"]' in src


def test_parametros_declarados_en_el_sitio_unico():
    import config
    from config import parametros
    assert parametros.RAG_BANCO is True and parametros.RAG_TOP_K_BANCO == 2
    assert {"RAG_BANCO", "RAG_TOP_K_BANCO"} <= set(parametros.__all__)
    assert config.RAG_BANCO is parametros.RAG_BANCO
    ejemplo = (RAIZ / ".env.example").read_text(encoding="utf-8")
    assert "RAG_BANCO=1" in ejemplo and "RAG_TOP_K_BANCO=2" in ejemplo
