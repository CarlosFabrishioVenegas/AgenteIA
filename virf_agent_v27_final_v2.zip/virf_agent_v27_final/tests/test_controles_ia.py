"""
Controles de datos asistidos por IA desde `.info()` / `.describe()` (2026-11-23).

Coste cero: la IA se sustituye por una función `llamar(prompt, max_tokens)`.
El notebook generado SÍ se ejecuta (en un subproceso, como lo haría el
validador en su equipo) para comprobar que llena las columnas de cumplimiento
y que el pipeline (`motores_entidad`) lee el Excel resultante.
"""
from __future__ import annotations

import io
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from modulos import controles_ia as ci

RAIZ = Path(__file__).resolve().parents[1]


def _df() -> pd.DataFrame:
    rng = np.random.default_rng(7)
    n = 400
    df = pd.DataFrame({
        "id_operacion": [f"OP{i:05d}" for i in range(n)],
        "fecha_corte": pd.to_datetime("2026-10-31"),
        "saldo capital": rng.normal(15000, 4000, n).round(2),
        "tasa_interes": rng.uniform(0.01, 0.25, n).round(4),
        "plazo_dias": rng.integers(30, 3600, n),
        "segmento": rng.choice(["Mayorista", "Minorista", "Pyme"], n),
    })
    df.loc[::40, "saldo capital"] = np.nan            # 10 nulos
    df.loc[3, "saldo capital"] = -120.5               # negativo
    df.loc[7, "tasa_interes"] = 1.7                   # fuera de [0, 1]
    df.loc[10, "id_operacion"] = "OP00009"            # llave duplicada
    return df


def _info(df) -> str:
    buf = io.StringIO()
    df.info(buf=buf)
    return buf.getvalue()


# ── 1. Lectura de .info() / .describe() ─────────────────────────────────────

def test_parsea_info_con_columnas_con_espacios():
    p = ci.parsear_info(_info(_df()))
    assert p["filas"] == 400
    cols = {c["nombre"]: c for c in p["columnas"]}
    assert cols["saldo capital"]["no_nulos"] == 390 and cols["saldo capital"]["dtype"] == "float64"
    assert cols["fecha_corte"]["dtype"].startswith("datetime64")


def test_parsea_info_antiguo_y_spark():
    viejo = ("<class 'pandas.core.frame.DataFrame'>\nInt64Index: 50 entries, 0 to 49\n"
             "Data columns (total 2 columns):\nsaldo     48 non-null float64\n"
             "cliente   50 non-null object\n")
    p = ci.parsear_info(viejo)
    assert p["filas"] == 50 and [c["no_nulos"] for c in p["columnas"]] == [48, 50]
    spark = "root\n |-- id: string (nullable = true)\n |-- saldo: double (nullable = true)\n"
    s = ci.parsear_info(spark)
    assert s["formato"] == "spark" and [c["nombre"] for c in s["columnas"]] == ["id", "saldo"]


def test_parsea_describe_ancho_en_bloques_y_transpuesto():
    df = _df()
    with pd.option_context("display.width", 60, "display.max_columns", 50):
        texto = df.describe(include="all").to_string(line_width=60)
    d = ci.parsear_describe(texto)
    assert d["saldo capital"]["min"] == -120.5
    assert d["tasa_interes"]["max"] == 1.7
    assert d["id_operacion"]["unique"] == 399 and d["id_operacion"]["top"] == "OP00009"
    t = ci.parsear_describe(df.describe().T.to_string())
    assert t["plazo_dias"]["count"] == 400


def test_parsea_describe_de_spark():
    texto = ("+-------+------------------+-----+\n|summary|             saldo| tasa|\n"
             "+-------+------------------+-----+\n|  count|               985| 1000|\n"
             "|    min|               0.0| 0.01|\n|    max|            5000.0|  1.7|\n"
             "+-------+------------------+-----+\n")
    d = ci.parsear_describe(texto)
    assert d["saldo"]["count"] == 985 and d["tasa"]["max"] == 1.7


# ── 2. Propuesta (reglas) ───────────────────────────────────────────────────

def _perfil():
    df = _df()
    return ci.perfil_dataset("cartera", _info(df), df.describe(include="all").to_string())


def test_reglas_cazan_las_anomalias_del_perfil():
    ctrls = ci.proponer([_perfil()], dominio="ALM", usar_ia=False)["controles"]
    tipos = {(c["tipo"], tuple(c["columnas"])) for c in ctrls}
    assert ("completitud", ("saldo capital",)) in tipos
    assert ("no_negativos", ("saldo capital",)) in tipos
    assert ("unicidad", ("id_operacion",)) in tipos            # 399 únicos de 400
    rango = next(c for c in ctrls if c["tipo"] == "rango")
    assert rango["params"]["maximo"] == 1.0                     # escala por el p75, no el máximo
    # Propuestos C01…; luego tipo de modelo (T), repositorio del dominio (D) y la
    # batería completa (B), que corre siempre.
    propuestos = [c for c in ctrls if c["origen"] not in ("batería", "tipo de modelo", "dominio")]
    assert all(c["id"] == f"C{i:02d}" for i, c in enumerate(propuestos, start=1))
    assert all(c["id"].startswith("B") for c in ctrls if c["origen"] == "batería")
    assert "info(): 390 de 400 no nulos" in next(
        c["justificacion"] for c in ctrls if c["tipo"] == "completitud" and c["columnas"] == ["saldo capital"])


# ── 3. Propuesta con IA, validada ───────────────────────────────────────────

def test_la_ia_solo_aporta_controles_validos():
    perfil = _perfil()
    respuesta = json.dumps({"comentario": "Saldo con nulos y una tasa atípica.", "controles": [
        {"dataset": "cartera", "tipo": "consistencia", "columnas": ["plazo_dias", "saldo capital"],
         "params": {"operador": "<="}, "descripcion": "x", "justificacion": "describe(): max=3597",
         "criticidad": "BAJA"},
        {"dataset": "cartera", "tipo": "dominio", "columnas": ["segmento"],
         "params": {"valores": ["Mayorista", "Minorista", "Pyme"]}, "descripcion": "Segmentos válidos",
         "justificacion": "describe(): unique=3", "criticidad": "MEDIA"},
        {"dataset": "cartera", "tipo": "rango", "columnas": ["no_existe"], "params": {}},
        {"dataset": "cartera", "tipo": "magia", "columnas": ["segmento"]},
        {"dataset": "cartera", "tipo": "formato", "columnas": ["id_operacion"],
         "params": {"patron": "OP\\d{5}"}, "justificacion": "el 87 % de los códigos"},
        {"dataset": "cartera", "tipo": "consistencia", "columnas": ["plazo_dias", "tasa_interes"],
         "params": {"operador": "=>"}},
    ]})
    prompts = []

    def llamar(prompt, max_tokens):
        prompts.append(prompt)
        return respuesta
    r = ci.proponer([perfil], dominio="ALM", contexto="cartera hipotecaria", usar_ia=True,
                    llamar=llamar)
    tipos = [(c["tipo"], c["origen"]) for c in r["controles"]]
    assert ("dominio", "ia") in tipos and ("consistencia", "ia") in tipos and ("formato", "ia") in tipos
    fmt = next(c for c in r["controles"] if c["tipo"] == "formato")
    assert "no verificable" in fmt["justificacion"]               # «87 %» no está en el perfil
    assert any("no_existe" in a for a in r["avisos"])
    assert any("magia" in a for a in r["avisos"])
    assert any("operador" in a for a in r["avisos"])
    assert "saldo capital" in prompts[0] and "cartera hipotecaria" in prompts[0]
    assert r["comentario"].startswith("Saldo con nulos")


# ── 4. Notebook ejecutable que llena las columnas de cumplimiento ───────────

def test_el_notebook_corre_en_local_y_el_pipeline_lee_su_excel(tmp_path):
    df = _df()
    csv = tmp_path / "cartera.csv"
    df.to_csv(csv, index=False)
    perfil = ci.perfil_dataset("cartera", _info(df), df.describe(include="all").to_string())
    prop = ci.proponer([perfil], usar_ia=False)
    nb, info = ci.construir_notebook(prop["controles"], [perfil], {"titulo": "Prueba"})
    assert info["n_controles"] == len(prop["controles"])
    celdas = json.loads(nb.decode("utf-8"))["cells"]
    codigo = "\n\n".join("".join(c["source"]) for c in celdas if c["cell_type"] == "code")
    assert "import virf" not in codigo.lower() and "from modulos" not in codigo   # autocontenido
    salida = tmp_path / "resultado.xlsx"
    codigo = (codigo.replace('"RUTA/A/cartera.csv"', repr(str(csv)))
              .replace("Path('resultado_controles_datos.xlsx')", f"Path({str(salida)!r})"))
    script = tmp_path / "nb.py"
    script.write_text(codigo, encoding="utf-8")
    r = subprocess.run([sys.executable, str(script)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=180,
                       env={**os.environ, "PYTHONUTF8": "1"})
    assert r.returncode == 0, r.stderr[-1500:]
    tabla = pd.read_excel(salida)
    assert list(tabla.columns) == ci.COLUMNAS_SALIDA
    dec = dict(zip(tabla["Control"], tabla["Decisión"]))
    assert list(dec.values()).count("No cumple") == 4             # las 4 anomalías sembradas

    filas = ci.leer_tabla_resultados(salida)
    rev = ci.revisar_resultados(filas, prop)
    assert rev["resumen"]["no_cumplen"] == 4 and len(rev["observaciones"]) == 4
    assert not rev["incoherencias"]

    from modulos.motores_entidad import leer_resultados
    raiz = tmp_path / "raiz"
    destino = raiz / "calidad_datos" / "resultadocalidad_de_datos"
    destino.mkdir(parents=True)
    (destino / "r.xlsx").write_bytes(salida.read_bytes())
    le = leer_resultados(raiz)
    assert le["ficheros"][0]["columnas"]["descripcion"] == "Descripción"
    assert sum(1 for f in le["filas"] if f["resultado"] == "FALLA") == 4


def test_revision_detecta_incoherencias_y_controles_no_ejecutados(tmp_path):
    t = pd.DataFrame([
        {"Control": "C01", "Control Esperado": "Saldo sin nulos", "% De cumplimiento del data set": 90,
         "Decisión": "Cumple", "Umbral": 0, "Diagnóstico": "10 % nulos"},
        {"Control": "C02", "Control Esperado": "Tasa en rango", "% De cumplimiento del data set": None,
         "Decisión": "No evaluable", "Umbral": 0, "Diagnóstico": "No se pudo ejecutar: KeyError"},
    ])
    ruta = tmp_path / "r.xlsx"
    t.to_excel(ruta, index=False)
    filas = ci.leer_tabla_resultados(ruta)
    assert filas[0]["pct_incumplimiento"] == 10
    rev = ci.revisar_resultados(filas, {"controles": [{"id": "C01"}, {"id": "C02"}, {"id": "C03"}]})
    assert any("C01" in x and "Cumple" in x for x in rev["incoherencias"])
    assert any("C02" in x for x in rev["limitaciones"])
    assert any("C03" in x for x in rev["limitaciones"])


def test_revision_con_ia_no_admite_cifras_ajenas(tmp_path):
    filas = [{"control": "C01", "descripcion": "Saldo sin nulos", "pct_incumplimiento": 2.5,
              "decision": "No cumple", "diagnostico": "10 nulos", "umbral": 0.0,
              "criticidad": "ALTA", "dataset": "cartera"}]
    resp = json.dumps({"comentario": "Calidad aceptable salvo nulos.", "observaciones": [
        {"control": "C01", "riesgo": "Moderado", "observacion": "El saldo tiene 2.5 % de nulos.",
         "recomendacion": "Completar los saldos."},
        {"control": "C09", "riesgo": "Crítico", "observacion": "inventada", "recomendacion": "x"}]})
    rev = ci.revisar_resultados(filas, None, usar_ia=True, llamar=lambda p, m: resp)
    assert [o["origen"] for o in rev["observaciones"]] == ["ia"]
    resp2 = resp.replace("2.5 % de nulos", "35 % de nulos")
    rev2 = ci.revisar_resultados(filas, None, usar_ia=True, llamar=lambda p, m: resp2)
    assert rev2["observaciones"][0]["origen"] == "reglas" and rev2["avisos"]


def test_lector_del_pipeline_entiende_el_cuadro_antiguo_de_8_columnas(tmp_path):
    from modulos.motores_entidad import leer_resultados
    c = tmp_path / "calidad_datos" / "resultadocalidad_de_datos"
    c.mkdir(parents=True)
    pd.DataFrame([{"Control": "C01", "Dimensión": "Completitud", "Control Esperado": "Saldo sin nulos",
                   "% De cumplimiento del data set": 98.0, "Diagnóstico": "20 nulos",
                   "Decisión": "No cumple", "Control o Evidencia requerida": "x",
                   "Referencia en el entregable": ""}]).to_csv(c / "t.csv", index=False)
    f = leer_resultados(tmp_path)["filas"][0]
    assert (f["descripcion"], f["resultado"], f["detalle"]) == ("Saldo sin nulos", "No cumple", "20 nulos")
    assert f["tasa"] == pytest.approx(0.02)


# ── 5. Endpoints ────────────────────────────────────────────────────────────

@pytest.fixture
def cliente(tmp_path):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services.contexto_sesion import contexto_sesion
    base = tmp_path / "sesion"
    ctx = {"clave": "T9/M", "base": base, "inputs": base / "inputs", "outputs": base / "outputs",
           "modelo": {"nombre": "Modelo ALM", "slug": "MODELO_ALM", "dominio": "ALM", "tier": "II",
                      "codigo_modelo": "MR-ALM-001"},
           "validador": {"codigo": "T9", "nombre": "V"}}
    (base / "inputs").mkdir(parents=True)
    app.dependency_overrides[contexto_sesion] = lambda: ctx
    try:
        yield TestClient(app), ctx
    finally:
        app.dependency_overrides.pop(contexto_sesion, None)


def test_endpoints_de_punta_a_punta(cliente, tmp_path):
    c, ctx = cliente
    df = _df()
    pedido = {"datasets": [{"nombre": "cartera", "info": _info(df),
                            "describe": df.describe(include="all").to_string()}],
              "contexto": "", "usar_ia": False}
    r = c.post("/api/motores/ia/perfil", json=pedido)
    assert r.status_code == 200 and r.json()["perfiles"][0]["filas"] == 400
    r = c.post("/api/motores/ia/notebook", json=pedido)
    assert r.status_code == 200, r.text
    j = r.json()
    nb = c.get(j["descarga"])
    assert nb.status_code == 200 and b'"cells"' in nb.content
    assert c.get("/api/motores/ia/notebook/../x").status_code in (400, 404)

    t = pd.DataFrame([{"Control": "C01", "Control Esperado": "x", "% De cumplimiento del data set": 50,
                       "Decisión": "No cumple", "Umbral": 0, "Diagnóstico": "d"}])
    buf = io.BytesIO(); t.to_excel(buf, index=False)
    archivo = {"archivo": ("resultado.xlsx", buf.getvalue())}
    assert c.post("/api/motores/ia/resultados", files=archivo).status_code == 422   # sin clasificación
    r = c.post("/api/motores/ia/resultados?clasificacion=Interno&usar_en_validacion=true",
               files=archivo)
    assert r.status_code == 200, r.text
    rev = r.json()
    assert rev["usado_en_validacion"] and rev["resumen"]["no_cumplen"] == 1
    assert (ctx["inputs"] / rev["destino"]).is_file()
    est = c.get("/api/motores/ia/estado").json()
    assert est["propuesta"]["id"] == j["id"] and est["revision"]["id"] == rev["id"]


def test_la_ia_de_controles_sale_por_el_gateway(monkeypatch):
    import config
    from modulos import notebook_controles

    class _Cliente:
        def generar_mensaje(self, prompt, max_tokens=None, **_):
            return "  {\"ok\": true}  "
    monkeypatch.setattr(config, "get_cliente_ia", lambda: _Cliente())
    assert notebook_controles.llamar_ia_controles("hola") == '{"ok": true}'
