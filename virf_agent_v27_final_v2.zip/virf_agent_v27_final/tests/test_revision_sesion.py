"""
«Validar modelo» → «Revisión con el agente», en la SESIÓN (2026-11-23).

Lo que se corrige y lo que se fija aquí, coste cero (el modelo del chat se
sustituye; nada llama a una IA real):

  1. Ruta: la corrida escribía en outputs/ del PROYECTO y la web buscaba en la
     sesión. Ahora `agente.py --salida <sesión>/outputs` y el runner la pasa.
  2. El resultado (y su Word) entran solos en la revisión con el agente; la
     revisión anterior se archiva, no se pisa.
  3. El agente es consecuente con el validador: sus decisiones explícitas
     (confirmar / subsanada / no aplica / pendiente) se registran tal cual, y
     recibe la evidencia del modelo de la sesión para comprobar lo que dice.
  4. Código del modelo en la ficha del modelo y en la línea de comandos.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]


def _ctx(tmp_path: Path) -> dict:
    base = tmp_path / "sesion"
    (base / "inputs" / "documentacion" / "modelamiento").mkdir(parents=True)
    (base / "outputs").mkdir(parents=True)
    return {"clave": "T9/M", "base": base, "inputs": base / "inputs",
            "outputs": base / "outputs",
            "modelo": {"nombre": "VaR Mercado", "tier": "II", "dominio": "VaR",
                       "slug": "VAR_MERCADO", "codigo_modelo": "MR-VAR-014"},
            "validador": {"codigo": "T9", "nombre": "Validador"}}


def _datos() -> dict:
    return {"modelo": "VaR Mercado", "tier": "II", "score_global": 2.4,
            "resultados_por_ambito": {"Metodología": [
                {"actividad": "Verificar el backtesting del modelo", "puntaje": 2,
                 "resultado": "No cumple", "evaluacion_valida": True,
                 "observacion": "No se evidencia el backtesting de Kupiec."},
                {"actividad": "Verificar la ventana histórica", "puntaje": 3,
                 "resultado": "Parcial", "evaluacion_valida": True,
                 "observacion": "La ventana no está justificada."},
            ]}}


def _escribir_corrida(ctx: dict, fecha: str = "2026-11-23") -> str:
    dia = ctx["outputs"] / fecha
    dia.mkdir(parents=True, exist_ok=True)
    (dia / "resultados_VaR_Mercado_2026-11-23.json").write_text(
        json.dumps(_datos(), ensure_ascii=False), encoding="utf-8")
    (dia / "VIRF_Informe_VaR_Mercado_23112026.docx").write_bytes(b"PK\x03\x04docx")
    return f"outputs/{fecha}/resultados_VaR_Mercado_2026-11-23.json"


# ── 1. La corrida escribe en la sesión ──────────────────────────────────────

def test_runner_pasa_salida_de_la_sesion_y_codigo_de_modelo(tmp_path):
    from web.services.pipeline_runner import construir_args
    base = tmp_path / "sesion"
    args = construir_args(base, "VaR Mercado", "II", "VaR", codigo_modelo="MR-VAR-014")
    assert args[args.index("--salida") + 1] == str(base / "outputs")
    assert args[args.index("--raiz-evidencia") + 1] == str(base)
    assert args[args.index("--codigo-modelo") + 1] == "MR-VAR-014"
    assert "--codigo-modelo" not in construir_args(base, "M", "II", "VaR")


def test_agente_salida_reapunta_outputs(tmp_path):
    """`--salida` es explícito y lo respetan también las verificaciones."""
    destino = tmp_path / "otra" / "outputs"
    env = {**os.environ, "PYTHONUTF8": "1"}
    r = subprocess.run([sys.executable, "agente.py", "--salida", str(destino),
                        "--verificar-cadena", "ModeloInexistente"],
                       cwd=RAIZ, env=env, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=240)
    assert "Salida (override)" in r.stdout, r.stdout[-800:] + r.stderr[-800:]
    assert destino.is_dir()
    assert "No hay informes para este modelo" in r.stdout


def test_agente_guarda_el_codigo_del_modelo():
    src = (RAIZ / "agente.py").read_text(encoding="utf-8")
    assert '"codigo_modelo":            (args.codigo_modelo or "").strip()' in src
    assert "codigo_modelo=(args.codigo_modelo or \"\").strip()" in src


def test_detecta_el_json_nuevo_en_cualquier_fecha_y_si_se_reescribe(tmp_path):
    from web.services import pipeline_runner as pr
    ctx = _ctx(tmp_path)
    previos = pr._snapshot_outputs_hoy(ctx["base"])
    assert pr._detectar_json_nuevo(ctx["base"], previos, "x") is None
    ruta = _escribir_corrida(ctx, "2026-11-22")              # cruzó la medianoche
    assert pr._detectar_json_nuevo(ctx["base"], previos, "x") == ruta
    # Misma ruta reescrita por una corrida nueva el mismo día: también cuenta.
    previos = pr._snapshot_outputs_hoy(ctx["base"])
    time.sleep(0.05)
    p = ctx["base"] / ruta
    p.write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
    os.utime(p, (time.time() + 5, time.time() + 5))
    assert pr._detectar_json_nuevo(ctx["base"], previos, "x") == ruta
    assert pr._docx_de_la_corrida(ctx["base"], ruta) == "2026-11-22/VIRF_Informe_VaR_Mercado_23112026.docx"


# ── 2. El resultado y su documento entran solos en la revisión ──────────────

def test_iniciar_revision_archiva_la_anterior_y_lleva_el_documento(tmp_path, monkeypatch):
    monkeypatch.setenv("VIRF_MOCK_CHAT", "1")
    from web.services import chat_service, pipeline_runner as pr
    chat_service.clear_todo()
    ctx = _ctx(tmp_path)
    viejo = chat_service.iniciar(ctx, _datos(), "2026-11-01/resultados_viejo.json")
    ruta = _escribir_corrida(ctx)

    ok, aviso = pr.iniciar_revision(ctx, ruta)
    assert ok and aviso is None
    s = chat_service.sesion_activa(ctx)
    assert s.id != viejo.id
    assert s.ruta_json == "2026-11-23/resultados_VaR_Mercado_2026-11-23.json"
    assert s.documento == "2026-11-23/VIRF_Informe_VaR_Mercado_23112026.docx"
    assert "VIRF_Informe_VaR_Mercado_23112026.docx" in s.mensajes[0].texto
    assert len(s.observaciones) == 2
    # La revisión anterior no se borró: quedó archivada.
    archivados = list(ctx["base"].glob("chat_historial_*.json"))
    assert len(archivados) == 1
    assert json.loads(archivados[0].read_text(encoding="utf-8"))["id"] == viejo.id


def test_iniciar_revision_con_json_ilegible_avisa(tmp_path):
    from web.services import pipeline_runner as pr
    ctx = _ctx(tmp_path)
    (ctx["outputs"] / "2026-11-23").mkdir()
    (ctx["outputs"] / "2026-11-23" / "resultados_x.json").write_text("{roto", encoding="utf-8")
    ok, aviso = pr.iniciar_revision(ctx, "outputs/2026-11-23/resultados_x.json")
    assert not ok and "no se pudo leer" in aviso


# ── 3. El agente es consecuente con el validador ────────────────────────────

@pytest.fixture
def chat(tmp_path, monkeypatch):
    monkeypatch.delenv("VIRF_MOCK_CHAT", raising=False)
    from web.services import chat_service
    chat_service.clear_todo()
    ctx = _ctx(tmp_path)
    llamadas: list[str] = []

    def _modelo(prompt):
        llamadas.append(prompt)
        return chat._respuesta
    chat._respuesta = {"veredicto": "NINGUNO", "respuesta": "¿Dónde?", "hallazgo": ""}
    monkeypatch.setattr(chat_service, "_invocar_modelo", _modelo)
    chat.llamadas = llamadas
    chat.ctx = ctx
    chat.svc = chat_service
    chat_service.iniciar(ctx, _datos(), "2026-11-23/resultados.json")
    return chat


@pytest.mark.parametrize("texto, esperado", [
    ("confirmar", ("confirmar", "")),
    ("Confirmo la observación: el backtesting nunca se corrió", ("confirmar", "el backtesting nunca se corrió")),
    ("subsanada: el manual v3 §4.2 lo documenta", ("subsanada", "el manual v3 §4.2 lo documenta")),
    ("No aplica - el modelo es Tier III", ("no aplica", "el modelo es Tier III")),
    ("pendiente: falta el acta", ("pendiente", "falta el acta")),
    ("el backtesting está en el manual", None),
    ("no estoy de acuerdo", None),
])
def test_decision_explicita(texto, esperado):
    from web.services.chat_service import decision_explicita
    assert decision_explicita(texto) == esperado


def test_confirmar_cierra_negado_sin_consultar_al_modelo(chat):
    r = chat.svc.responder(chat.ctx, "confirmar")
    assert r["veredicto"] == "NEGADO" and r["avanza"]
    o = chat.svc.sesion_activa(chat.ctx).observaciones[0]
    assert o.veredicto == "NEGADO"
    assert o.hallazgo_final.startswith("No se evidencia el backtesting de Kupiec.")
    assert chat.llamadas == []                       # decisión humana: sin IA


def test_subsanada_exige_motivo_y_luego_aprueba(chat):
    r = chat.svc.responder(chat.ctx, "subsanada")
    assert r["veredicto"] is None and not r["avanza"]
    s = chat.svc.sesion_activa(chat.ctx)
    assert "necesito el motivo" in s.mensajes[-1].texto
    r = chat.svc.responder(chat.ctx, "subsanada: el informe de backtesting 2025 está en el anexo C")
    assert r["veredicto"] == "APROBADO"
    o = s.observaciones[0]
    assert o.hallazgo_final == ("Subsanada según el validador: el informe de backtesting "
                                "2025 está en el anexo C")
    assert chat.llamadas == []


def test_no_aplica_y_pendiente(chat):
    chat.svc.responder(chat.ctx, "no aplica: el modelo no usa backtesting regulatorio")
    chat.svc.responder(chat.ctx, "pendiente: falta el acta del comité de octubre")
    obs = chat.svc.sesion_activa(chat.ctx).observaciones
    assert [o.veredicto for o in obs] == ["APROBADO", "PENDIENTE"]
    assert obs[0].hallazgo_final.startswith("No aplica según el validador:")


def test_el_agente_recibe_la_evidencia_del_modelo_y_puede_citarla(chat):
    manual = chat.ctx["inputs"] / "documentacion" / "modelamiento" / "manual_var.md"
    manual.write_text(
        "# Manual del VaR\n\nSección 4.2 Backtesting\n\n"
        "El backtesting de Kupiec se ejecuta mensualmente con 250 observaciones y "
        "los resultados se reportan al comité de riesgos.\n", encoding="utf-8")
    chat._respuesta = {
        "veredicto": "APROBADO",
        "respuesta": ("Tomo tu aclaración: el manual dice «El backtesting de Kupiec se ejecuta "
                      "mensualmente con 250 observaciones»."),
        "hallazgo": "Subsanada: el manual documenta el backtesting de Kupiec (sección 4.2)."}
    r = chat.svc.responder(chat.ctx, "El backtesting de Kupiec está en el manual, sección 4.2")
    prompt = chat.llamadas[-1]
    assert "manual_var.md" in prompt and "se ejecuta mensualmente" in prompt
    # La cita viene de la evidencia que se le dio: el APROBADO no se degrada.
    assert r["veredicto"] == "APROBADO"
    respuesta_agente = chat.svc.sesion_activa(chat.ctx).mensajes[-2].texto
    assert "Tomo tu aclaración" in respuesta_agente
    assert "Verificación automática" not in respuesta_agente


def test_cita_inventada_sigue_degradando_el_aprobado(chat):
    chat._respuesta = {
        "veredicto": "APROBADO",
        "respuesta": "El manual dice «el backtesting se aprobó en el comité de enero de 2026».",
        "hallazgo": "Subsanada."}
    r = chat.svc.responder(chat.ctx, "Ya está resuelto en el manual")
    assert r["veredicto"] == "PENDIENTE"


def test_el_prompt_pide_ser_consecuente_y_esta_sincronizado():
    from web.services.chat_service import _PROMPT_JUEZ
    assert "SÉ CONSECUENTE" in _PROMPT_JUEZ and "{evidencia_modelo}" in _PROMPT_JUEZ
    base = json.loads((RAIZ / "web" / "data" / "prompts_base.json").read_text(encoding="utf-8"))
    assert "evidencia_modelo" in base["chat_agente"]["placeholders"]


# ── Descarga del documento de la corrida (en la sesión) ─────────────────────

def test_endpoint_documento_de_la_corrida(tmp_path):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services.contexto_sesion import contexto_sesion
    ctx = _ctx(tmp_path)
    _escribir_corrida(ctx)
    app.dependency_overrides[contexto_sesion] = lambda: ctx
    try:
        c = TestClient(app)
        r = c.get("/api/resultados/documento/2026-11-23/VIRF_Informe_VaR_Mercado_23112026.docx")
        assert r.status_code == 200 and r.content.startswith(b"PK")
        assert c.get("/api/resultados/documento/2026-11-23/otro.docx").status_code == 400
        assert c.get("/api/resultados/documento/x/VIRF_Informe_a.docx").status_code == 400
        assert c.get("/api/resultados/documento/2026-11-23/VIRF_Informe_no.docx").status_code == 404
    finally:
        app.dependency_overrides.pop(contexto_sesion, None)


# ── 4. Código del modelo en la ficha ─────────────────────────────────────────

def test_codigo_de_modelo_en_la_ficha(tmp_path, monkeypatch):
    from web.services import modelos_store
    monkeypatch.setattr(modelos_store, "SESIONES_DIR", tmp_path)
    m = modelos_store.crear("T9", "VaR Mercado", "VaR", "II", codigo_modelo="MR-VAR-014")
    assert m["codigo_modelo"] == "MR-VAR-014"
    m = modelos_store.actualizar_meta("T9", m["slug"], codigo_modelo="MR-VAR-015")
    assert modelos_store.cargar("T9", m["slug"])["codigo_modelo"] == "MR-VAR-015"
    # None no lo toca; "" lo borra.
    assert modelos_store.actualizar_meta("T9", m["slug"], tier="I")["codigo_modelo"] == "MR-VAR-015"
    assert modelos_store.actualizar_meta("T9", m["slug"], codigo_modelo="")["codigo_modelo"] == ""
    with pytest.raises(ValueError):
        modelos_store.crear("T9", "Otro", "VaR", "II", codigo_modelo="<script>")
