"""
El mapa completo de la herramienta (docs/MAPA_HERRAMIENTA.md) se GENERA desde el código: si cambia
el menú, una etapa, un tipo de modelo, el catálogo, el repositorio, la API o la documentación sin
regenerarlo, este test falla. Lo volátil (pruebas y git) no se compara.

    python scripts/generar_mapa_herramienta.py
"""
from __future__ import annotations

import importlib.util
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]


def _generador():
    spec = importlib.util.spec_from_file_location("generar_mapa_herramienta",
                                                  RAIZ / "scripts" / "generar_mapa_herramienta.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def test_el_mapa_cubre_toda_la_herramienta_y_esta_al_dia():
    g = _generador()
    texto = g.construir(con_git=False)
    from modulos import controles_ia as ci
    from modulos import validacion_completa as vc
    from modulos.repositorio_controles import cargar_controles
    from modulos.tipos_modelo import TIPOS
    for tid in TIPOS:
        assert f"(`{tid}`)" in texto, tid
    for c, e in vc.ETAPAS.items():
        assert f"### {c} · {e['nombre']}" in texto, c
    for tipo in ci.CATALOGO:
        assert f"`{tipo}`" in texto, tipo
    for carpeta in ("var", "alm", "lar", "shared"):
        for ctrl in cargar_controles(carpeta)[0]:
            assert f"`{ctrl['nombre']}`" in texto, ctrl["nombre"]
    for ruta in ("/api/completa/paquete", "/api/validar/lanzar", "/api/motores/ia/notebook"):
        assert f"`{ruta}`" in texto, ruta
    assert "Validación completa: antes del barrido de controles cierra las etapas" in texto   # errores 409
    assert "(Omitido: generado con `--sin-git`.)" in texto
    assert g.DESTINO.is_file(), "falta docs/MAPA_HERRAMIENTA.md: python scripts/generar_mapa_herramienta.py"
    assert g.parte_estable(g.DESTINO.read_text(encoding="utf-8")) == g.parte_estable(texto), (
        "docs/MAPA_HERRAMIENTA.md desactualizado: python scripts/generar_mapa_herramienta.py")
