"""
VIRF Web — capa web sobre el agente CLI.

El paso 3 introduce la primera dependencia real del agente
(`config.ia.prueba_de_humo`), así que aquí se hace el sys.path.insert
que las capas superiores necesitarán a partir de ahora.
"""
import sys
from pathlib import Path

# [WIN-ENC-FIX] En consolas Windows (cp1252) los print con emoji del núcleo
# (`✅ Cliente IA listo…`, `❌ Error…`) revientan con UnicodeEncodeError, y ese
# crash ENMASCARABA el diagnóstico real en «Verificar conexión» (p. ej. el 400 de
# credenciales aparecía como «'charmap' codec can't encode '✅'»). Forzamos
# UTF-8 en la salida del proceso web. Idempotente; sin efecto donde ya es UTF-8.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass

from fastapi import FastAPI
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

WEB_DIR = Path(__file__).resolve().parent
PROYECTO_DIR = WEB_DIR.parent
# Los módulos del agente hacen imports como `from Mx_00_CargaRutas import …`
# sin prefijo `motor.`. Necesitan la raíz Y la carpeta motor/ en sys.path,
# igual que hace `scripts/rebuild_rag_databricks.py`.
for _p in (PROYECTO_DIR, PROYECTO_DIR / "motor"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from .routers import upload as upload_router  # noqa: E402
from .routers import config as config_router  # noqa: E402
from .routers import dominio_prevuelo as dp_router  # noqa: E402
from .routers import validacion as validacion_router  # noqa: E402
from .routers import resultados as resultados_router  # noqa: E402
from .routers import controles as controles_router  # noqa: E402
from .routers import chat as chat_router  # noqa: E402
from .routers import cuestionamientos as cuest_router  # noqa: E402
from .routers import informe as informe_router  # noqa: E402
from .routers import auth as auth_router  # noqa: E402
from .routers import modelos as modelos_router  # noqa: E402
from .routers import rag as rag_router  # noqa: E402
from .routers import entendimiento as entendimiento_router  # noqa: E402
from .routers import preview_prompt as preview_router  # noqa: E402
from .routers import debug_conexiones as debug_router  # noqa: E402
from .routers import skills as skills_router  # noqa: E402
from .routers import cuestionamientos_sesion as cuest_sesion_router  # noqa: E402
from .routers import prompts as prompts_router  # noqa: E402
from .routers import estandares as estandares_router  # noqa: E402
from .routers import automatizaciones as automatizaciones_router  # noqa: E402
from .routers import guia as guia_router  # noqa: E402
from .routers import solo_informe as solo_informe_router  # noqa: E402
from .routers import codigo as codigo_router  # noqa: E402  [SEG-07]
from .routers import feedback_aprobacion as feedback_aprob_router  # noqa: E402  [Paso 25]

TEMPLATES_DIR = WEB_DIR / "templates"
STATIC_DIR = WEB_DIR / "static"

app = FastAPI(title="VIRF Web", version="2.0")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# [SEG-12] Auditoría: una entrada por acción sensible (quién, qué, cuándo, IP).
from .services.auditoria_web import middleware_auditoria  # noqa: E402
app.middleware("http")(middleware_auditoria)


# [SEG-06] Retención: al arrancar se borran (con sobrescritura) los ficheros
# locales que superan VIRF_RETENCION_DIAS.
def _purgar_retencion() -> None:
    try:
        from config.rutas import raices_retencion
        from modulos.almacenamiento import purgar_vencidos
        from modulos.auditoria import registrar
        borrados = purgar_vencidos(raices_retencion())
        if borrados:
            registrar("purga_retencion", f"{len(borrados)} ficheros", quien="sistema")
    except Exception as exc:                                 # noqa: BLE001
        print(f"⚠️  purga de retención falló: {exc}")


app.router.on_startup.append(_purgar_retencion)
app.include_router(auth_router.router)
app.include_router(codigo_router.router)
app.include_router(feedback_aprob_router.router)
app.include_router(modelos_router.router)
app.include_router(rag_router.router)
app.include_router(entendimiento_router.router)
app.include_router(preview_router.router)
app.include_router(prompts_router.router)
app.include_router(estandares_router.router)
app.include_router(debug_router.router)
app.include_router(skills_router.router)
app.include_router(cuest_sesion_router.router)
app.include_router(upload_router.router)
app.include_router(config_router.router)
app.include_router(dp_router.router)
app.include_router(validacion_router.router)
app.include_router(resultados_router.router)
app.include_router(controles_router.router)
app.include_router(chat_router.router)
app.include_router(cuest_router.router)
app.include_router(informe_router.router)
app.include_router(automatizaciones_router.router)
app.include_router(guia_router.router)
app.include_router(solo_informe_router.router)


def _version_assets() -> str:
    """
    Token de caché derivado del mtime de los estáticos. Cambia en cuanto se
    edita el CSS o el JS, así que el navegador vuelve a descargarlos sin
    necesitar un hard-refresh manual. Sin esto, un fix de front quedaba
    invisible tras un reload normal (caché de disco sirviendo la versión
    vieja) y parecía que el cambio «no había funcionado».
    """
    marcas = []
    for rel in ("css/styles.css", "js/app.js", "js/guia.js"):
        try:
            marcas.append(int((STATIC_DIR / rel).stat().st_mtime))
        except OSError:
            marcas.append(0)
    return str(max(marcas))


@app.get("/", include_in_schema=False)
def index() -> HTMLResponse:
    html = (TEMPLATES_DIR / "index.html").read_text(encoding="utf-8")
    v = _version_assets()
    html = html.replace("/static/css/styles.css", f"/static/css/styles.css?v={v}")
    html = html.replace("/static/js/app.js", f"/static/js/app.js?v={v}")
    html = html.replace("/static/js/guia.js", f"/static/js/guia.js?v={v}")
    return HTMLResponse(html)


@app.get("/api/salud")
def salud() -> dict:
    return {"estado": "ok", "version": "2.0"}
