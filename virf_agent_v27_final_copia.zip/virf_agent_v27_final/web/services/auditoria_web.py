"""
Middleware de auditoría de acciones web (SEG-12).

Cada petición que encaja en `ACCIONES` produce EXACTAMENTE una entrada en el
log de auditoría (modulos/auditoria.py) con quién (identidad de la sesión),
qué (acción + objeto), cuándo, desde dónde (IP) y resultado (código HTTP).
Además fija el contexto de la petición para que las llamadas a IA del gateway
(config/ia.py) queden atribuidas a la misma persona.
"""
from __future__ import annotations

import re
from typing import List, Optional, Tuple

from modulos import auditoria

from . import sesion_store

# (método, patrón de ruta, acción)
ACCIONES: List[Tuple[str, re.Pattern, str]] = [(m, re.compile(p), a) for m, p, a in [
    ("GET",    r"^/api/auth/callback$",                         "login"),
    ("POST",   r"^/api/auth/login-libre$",                      "login_prueba"),
    ("POST",   r"^/api/auth/logout$",                           "logout"),
    ("POST",   r"^/api/inputs/upload(-zip)?$",                  "subida"),
    ("DELETE", r"^/api/inputs/archivo/.+$",                     "borrado_archivo"),
    ("POST",   r"^/api/rag/dominios/crear$",                    "alta_dominio_rag"),
    ("DELETE", r"^/api/rag/dominios/[^/]+$",                    "borrado_dominio_rag"),
    ("DELETE", r"^/api/rag/dominios/[^/]+/paper/.+$",           "borrado_paper_rag"),
    ("POST",   r"^/api/rag/reconstruir$",                       "reindexado_rag"),
    ("POST",   r"^/api/prompts/(editar|restaurar)$",            "cambio_prompt"),
    ("POST",   r"^/api/validar/lanzar$",                        "lanzar_validacion"),
    ("GET",    r"^/api/informe/descargar/.+$",                  "descarga_informe"),
    ("GET",    r"^/api/solo-informe/descargar/.+$",             "descarga_informe"),
    ("GET",    r"^/api/automatizaciones/descargar/.+$",         "descarga_informe"),
    ("GET",    r"^/api/resultados/excel$",                      "descarga_informe"),
    ("POST",   r"^/api/config/virf_plus$",                      "cambio_configuracion"),
]]


def accion_de(metodo: str, ruta: str) -> Optional[str]:
    for m, patron, accion in ACCIONES:
        if m == metodo and patron.match(ruta):
            return accion
    return None


def _token_de_respuesta(response) -> Optional[str]:
    for k, v in response.raw_headers:
        if k.lower() == b"set-cookie" and v.startswith(b"virf_token="):
            return v.split(b";")[0].split(b"=", 1)[1].decode() or None
    return None


def _quien(token: Optional[str]) -> dict:
    s = sesion_store.sesion_activa(token) if token else None
    if not s:
        return {"quien": "(sin sesión)", "oid": ""}
    return {"quien": s.get("upn") or s.get("codigo", ""), "oid": s.get("oid", ""),
            "roles": ",".join(s.get("roles") or [])}


async def middleware_auditoria(request, call_next):
    ip = request.client.host if request.client else ""
    ctx = {**_quien(request.cookies.get("virf_token")), "desde": ip}
    tk = auditoria.contexto_web.set(ctx)
    accion = accion_de(request.method, request.url.path)
    try:
        try:
            respuesta = await call_next(request)
        except Exception:
            if accion:
                auditoria.registrar(accion, request.url.path, resultado="error_500",
                                    quien=ctx["quien"], oid=ctx["oid"], desde=ip)
            raise
        if accion:
            quien = ctx
            if accion in ("login", "login_prueba"):
                quien = {**_quien(_token_de_respuesta(respuesta)), "desde": ip}
            extra = {}
            if quien.get("roles"):
                extra["roles"] = quien["roles"]
            if request.url.query and accion != "login":     # el callback trae el code OIDC
                extra["query"] = str(request.url.query)[:200]
            auditoria.registrar(
                accion, request.url.path,
                resultado="ok" if respuesta.status_code < 400 else f"http_{respuesta.status_code}",
                quien=quien["quien"], oid=quien["oid"], desde=ip, **extra)
        return respuesta
    finally:
        auditoria.contexto_web.reset(tk)
