"""
Lectura (SOLO lectura) del `.env` del proyecto.

[SEG-03] Antes este módulo también ESCRIBÍA el `.env` (función de escritura retirada), y el
Paso 01 de la web lo usaba para guardar claves de IA en texto plano — contra la
regla propia de no editar `.env` desde código y contra la norma 2135.010.02
(credenciales cifradas). Se eliminó la escritura: las credenciales viven en
Azure Key Vault / secret scope (config/secretos.py) y la web solo muestra si
están configuradas. tests/test_credenciales.py falla si vuelve a aparecer.

Contrato:
- `leer_env()` devuelve un `dict[str, str]` con las variables definidas
  (comentarios y líneas vacías se descartan).
"""
from __future__ import annotations

import re
from pathlib import Path

from ..config_web import PROYECTO_DIR

ENV_PATH = PROYECTO_DIR / ".env"

# Coincide con `NOMBRE=valor` (opcional export, sin espacios exóticos).
# El valor puede venir sin comillas, entre comillas dobles o simples.
_LINEA_VAR = re.compile(r"""^\s*(?:export\s+)?
                            (?P<clave>[A-Za-z_][A-Za-z0-9_]*)
                            \s*=\s*
                            (?P<valor>.*)
                            $""", re.VERBOSE)


def _parsear_valor(bruto: str) -> str:
    """
    Quita comillas envolventes y desescapa el interior si la envoltura era
    doble.
    """
    v = bruto.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
        interior = v[1:-1]
        if v[0] == '"':
            interior = interior.replace('\\"', '"').replace("\\\\", "\\")
        return interior
    return v


def leer_env() -> dict[str, str]:
    """Devuelve las variables actualmente definidas en `.env`."""
    if not ENV_PATH.is_file():
        return {}
    salida: dict[str, str] = {}
    for linea in ENV_PATH.read_text(encoding="utf-8").splitlines():
        recortada = linea.strip()
        if not recortada or recortada.startswith("#"):
            continue
        m = _LINEA_VAR.match(linea)
        if m:
            salida[m["clave"]] = _parsear_valor(m["valor"])
    return salida
