"""
Endpoints CRUD de prompts editables por sesión (v2.3).

GET  /api/prompts/base            → los prompts por defecto (sin sesión)
GET  /api/prompts                 → los prompts EFECTIVOS de la sesión (custom o base)
POST /api/prompts/editar          → guarda un override para la sesión (rol admin_corpus)
POST /api/prompts/restaurar       → borra el override, vuelve al default (rol admin_corpus)
GET  /api/prompts/presupuesto     → presupuesto de contexto según modelo detectado
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Cookie, Depends, HTTPException
from pydantic import BaseModel, Field

from ..services import prompt_service, presupuesto_service, sesion_store
from ..services.contexto_sesion import contexto_sesion
from ..services.roles import requiere

router = APIRouter(prefix="/api/prompts", tags=["prompts"])


class BodyEditar(BaseModel):
    prompt_id: str = Field(..., min_length=1)
    contenido: str = Field(..., min_length=1)


class BodyRestaurar(BaseModel):
    prompt_id: str = Field(..., min_length=1)


# [SEG-08] Antes: contraseña compartida «virf2026» en la cabecera
# x-prompt-password. Ahora editar/restaurar exige el rol admin_corpus.


@router.get("/base")
def get_base() -> dict[str, Any]:
    """Los prompts por defecto (para el editor cuando aún no hay sesión)."""
    return {"prompts": prompt_service.prompts_base()}


@router.get("")
def get_efectivos(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """Los prompts efectivos de la sesión (custom si existen, base si no)."""
    return {
        "sesion":  ctx["clave"],
        "prompts": prompt_service.prompts_efectivos(ctx),
    }


@router.post("/editar")
def editar(body: BodyEditar,
            ctx: dict = Depends(contexto_sesion),
            _val: dict = Depends(requiere("editar_prompts"))) -> dict[str, Any]:
    editor = ctx["validador"]["codigo"]
    try:
        entrada = prompt_service.editar_prompt(
            ctx, body.prompt_id, body.contenido, editor)
    except KeyError as exc:
        raise HTTPException(404, str(exc))
    except PermissionError as exc:
        raise HTTPException(403, str(exc))
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "prompt_id": body.prompt_id, "entrada": entrada}


@router.post("/restaurar")
def restaurar(body: BodyRestaurar,
               ctx: dict = Depends(contexto_sesion),
               _val: dict = Depends(requiere("editar_prompts"))) -> dict[str, Any]:
    try:
        entrada = prompt_service.restaurar_prompt(ctx, body.prompt_id)
    except KeyError as exc:
        raise HTTPException(404, str(exc))
    return {"ok": True, "prompt_id": body.prompt_id, "entrada": entrada}


@router.get("/presupuesto")
def presupuesto(virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    """
    Presupuesto de contexto para la sesión. Usa el modelo detectado por
    /api/config/verificar si está persistido, si no el conservador.
    """
    modelo_detectado = None
    val = sesion_store.sesion_activa(virf_token)
    if val is not None:
        modelo_detectado = val.get("modelo_ia_detectado")
    return presupuesto_service.calcular(modelo_detectado)
