"""
Dominio & RAG: papers al RAG global + reconstrucción + dominios custom.

v2 · fase 4 + Mejora 1 (v2.2).

Alcance:
- `inputs/rag/{dominio}/` es GLOBAL — compartido entre validadores.
- Los 4 dominios FIJOS (LaR, VaR, conductuales, shared) no se tocan.
- Los CUSTOM se crean desde el panel Dominio & RAG y se registran en
  `web/data/dominios_custom.json`.
"""
from __future__ import annotations

import asyncio
import pickle
import sys
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Cookie, HTTPException
from pydantic import BaseModel, Field

from ..config_web import PROYECTO_DIR
from ..services import roles as _roles
from ..services import dominios_custom_store as dominios
from ..services import modelos_store, sesion_store

router = APIRouter(prefix="/api/rag", tags=["rag"])

RAG_INPUTS_DIR = PROYECTO_DIR / "inputs" / "rag"
RAG_INDICE_DIR = PROYECTO_DIR / "data" / "rag_lexico"


def _login_o_401(token: str | None) -> dict:
    val = sesion_store.sesion_activa(token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    return val


def _leer_indice(dominio: str) -> dict[str, Any]:
    """Estado del índice sin ejecutar el script — carga el .pkl directamente."""
    pkl = RAG_INDICE_DIR / f"{dominio}.pkl"
    if not pkl.is_file():
        return {"existe": False}
    try:
        from modulos import pickle_firmado        # [SEG-09] solo índices firmados
        idx = pickle_firmado.cargar(pkl)
    except Exception as exc:                     # noqa: BLE001
        return {"existe": True, "error": str(exc)}
    chunks = getattr(idx, "chunks", []) or []
    docs = {c.get("fuente") for c in chunks if isinstance(c, dict)}
    return {
        "existe":         True,
        "n_chunks":       len(chunks),
        "n_docs":         len(docs),
        "construido_en":  str(getattr(idx, "construido_en", "")),
        "version":        getattr(idx, "version", "?"),
    }


def _esta_desactualizado(inputs_dir: Path, pkl: Path) -> bool:
    """
    True si el índice está OBSOLETO respecto al corpus: falta el `.pkl` habiendo
    literatura, o algún fichero indexable es más nuevo que el índice. Cierra el
    footgun de «subí manuales pero olvidé reconstruir»: el retriever NO reindexa
    solo (buscador_lexico solo reconstruye si el índice falta o cambia de versión).
    """
    try:
        from src.rag.config_rag import EXTENSIONES_INDEXABLES, NOMBRES_EXCLUIDOS
    except Exception:                                     # pragma: no cover
        EXTENSIONES_INDEXABLES = {".pdf", ".docx", ".pptx", ".xlsx", ".txt", ".md"}
        NOMBRES_EXCLUIDOS = {"README", "LEEME", "LEEME_PRIMERO"}
    excl = {n.upper() for n in NOMBRES_EXCLUIDOS}
    fuentes: list[Path] = []
    if inputs_dir.is_dir():
        for p in inputs_dir.iterdir():
            if (p.is_file() and not p.name.startswith(".")
                    and p.suffix.lower() in EXTENSIONES_INDEXABLES
                    and p.stem.upper() not in excl):
                fuentes.append(p)
    if not pkl.is_file():
        return bool(fuentes)          # sin índice pero con papers → hay que construir
    pkl_mtime = pkl.stat().st_mtime
    return any(p.stat().st_mtime > pkl_mtime for p in fuentes)


def _papers_en_disco(dominio: str) -> list[dict[str, Any]]:
    d = RAG_INPUTS_DIR / dominio
    if not d.is_dir():
        return []
    salida = []
    for p in sorted(d.iterdir()):
        if p.is_file() and not p.name.startswith("."):
            salida.append({"nombre": p.name, "tam": p.stat().st_size})
    return salida


def _modelos_que_usan(dom_id: str) -> list[str]:
    """
    Lista de "codigo/slug" de modelos que declaran este dominio.
    Se usa para bloquear el borrado.
    """
    usan: list[str] = []
    base = PROYECTO_DIR / "web" / "data" / "sesiones"
    if not base.is_dir():
        return usan
    for cod in base.iterdir():
        if not cod.is_dir():
            continue
        for slug in cod.iterdir():
            m = modelos_store.cargar(cod.name, slug.name)
            if m and m.get("dominio") == dom_id:
                usan.append(f"{cod.name}/{slug.name}")
    return usan


@router.get("/dominios")
def listar_dominios(virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    """Fijos primero, custom después. Cada uno con estado del índice y papers."""
    _roles.comprobar(virf_token, "leer")
    salida = []
    for d in dominios.listar():
        dom_id = d["id"]
        indice = _leer_indice(dom_id)
        indice["desactualizado"] = _esta_desactualizado(
            RAG_INPUTS_DIR / dom_id, RAG_INDICE_DIR / f"{dom_id}.pkl")
        entrada = {**d, "dominio": dom_id,
                    "papers":  _papers_en_disco(dom_id),
                    "indice":  indice}
        salida.append(entrada)
    return {"dominios": salida}


# ── Crear/borrar dominio custom ────────────────────────────────────────

class NuevoDominio(BaseModel):
    nombre:         str = Field(..., min_length=2, max_length=80)
    descripcion:    str = Field("",  max_length=1000)
    palabras_clave: list[str] = Field(default_factory=list)


@router.post("/dominios/crear")
def crear_dominio(body: NuevoDominio,
                   virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    val = _roles.comprobar(virf_token, "gestionar_corpus")
    try:
        entrada = dominios.crear(
            nombre=body.nombre,
            descripcion=body.descripcion,
            palabras_clave=body.palabras_clave,
            creado_por=val["codigo"],
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"dominio": entrada}


@router.delete("/dominios/{dom_id}")
def borrar_dominio(dom_id: str,
                    virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    _roles.comprobar(virf_token, "gestionar_corpus")
    if dom_id in dominios.DOMINIOS_FIJOS:
        raise HTTPException(400, f"'{dom_id}' es un dominio fijo; no se borra")
    usan = _modelos_que_usan(dom_id)
    if usan:
        raise HTTPException(409,
            f"no se puede eliminar '{dom_id}': lo usan {len(usan)} modelo(s): "
            + ", ".join(usan[:5]) + ("…" if len(usan) > 5 else ""))
    try:
        r = dominios.borrar(dom_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc))
    return r


# ── Borrar un libro/manual concreto del corpus ────────────────────────

@router.delete("/dominios/{dom_id}/paper/{nombre}")
async def borrar_paper(dom_id: str, nombre: str,
                       virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    """
    Elimina un libro/manual CONCRETO del corpus `inputs/rag/{dom_id}/` y
    reindexa, para que el retrieval deje de devolver ese documento. Solo
    ficheros directos (no dotfiles) y con validación anti path-traversal.
    """
    _roles.comprobar(virf_token, "gestionar_corpus")
    if not dominios.existe(dom_id):
        raise HTTPException(404, f"dominio '{dom_id}' no existe")
    carpeta = RAG_INPUTS_DIR / dom_id
    safe = Path(nombre).name
    if safe != nombre or safe.startswith("."):
        raise HTTPException(400, f"nombre inválido: {nombre!r}")
    ruta = (carpeta / safe).resolve()
    try:
        ruta.relative_to(carpeta.resolve())
    except ValueError:
        raise HTTPException(400, "ruta fuera del dominio")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {safe}")
    ruta.unlink()
    # Reindexa: borrar el fichero NO basta — el .pkl seguiría sirviéndolo.
    reconstruido = await _ejecutar_rebuild(dom_id, force=True)
    return {"ok": True, "borrado": safe, "dominio": dom_id,
            "reconstruido": reconstruido,
            "dominios": listar_dominios(virf_token)["dominios"]}


# ── Reconstrucción del índice ─────────────────────────────────────────

class Reconstruir(BaseModel):
    dominio: str
    force:   bool = True


async def _ejecutar_rebuild(dom: str, force: bool = True) -> dict[str, Any]:
    """Lanza el script de reindexado como subproceso. Coste 0 (RAG léxico)."""
    args = [sys.executable, "-u", "scripts/rebuild_rag_databricks.py",
            "--dominio", dom]
    if force:
        args.append("--force")
    proc = await asyncio.create_subprocess_exec(
        *args,
        cwd=str(PROYECTO_DIR),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=300)
    except asyncio.TimeoutError:
        try: proc.terminate()
        except ProcessLookupError: pass
        raise HTTPException(504, "reconstrucción excedió 5 min; abortada")
    return {
        "ok":        proc.returncode == 0,
        "exit_code": proc.returncode,
        "salida":    (stdout or b"").decode("utf-8", errors="replace"),
    }


@router.post("/reconstruir")
async def reconstruir(body: Reconstruir,
                       virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    """
    Reconstruye el índice del dominio dado. Acepta cualquier dominio
    conocido (fijo o custom) o `all` para todos los fijos + custom.
    Coste 0 (RAG léxico local).
    """
    _roles.comprobar(virf_token, "gestionar_corpus")
    dom = body.dominio
    if dom != "all" and not dominios.existe(dom):
        raise HTTPException(400, f"dominio '{dom}' no existe")
    r = await _ejecutar_rebuild(dom, body.force)
    return {**r, "dominios": listar_dominios(virf_token)["dominios"]}
