"""
Aprobación humana de código generado por IA (SEG-07).

POST /api/codigo/aprobar  {hash, motivo}  → rol revisor (permiso «aprobar»).
La aprobación queda en el log de auditoría y es lo único que habilita a
`modulos/aprobacion_codigo.ejecutar_aprobado` a correr ese código.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from modulos import aprobacion_codigo

from ..services.roles import requiere

router = APIRouter(prefix="/api/codigo", tags=["codigo"])


class Aprobacion(BaseModel):
    hash: str = Field(..., min_length=64, max_length=64)
    motivo: str = Field(..., min_length=5, max_length=300)


@router.post("/aprobar")
def aprobar(body: Aprobacion, val: dict = Depends(requiere("aprobar"))) -> dict:
    try:
        e = aprobacion_codigo.aprobar(body.hash.lower(), quien=val.get("upn", ""),
                                      oid=val.get("oid", ""), motivo=body.motivo)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "hash": body.hash.lower(), "aprobado_por": e["quien"], "cuando": e["cuando"]}
