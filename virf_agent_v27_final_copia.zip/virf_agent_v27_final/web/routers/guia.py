"""
Guía del procedimiento: en qué paso está el expediente.

- GET /api/guia/progreso → estado de los 9 pasos + el siguiente recomendado

Solo LEE el disco de la sesión (no escribe nada) para que la ayuda de la web
pueda decir «te falta esto» con datos reales y no con una lista fija.
"""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends

from ..services import env_service, estandares_service, informe_web
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/guia", tags=["guia"])

_CLAVE_PROVEEDOR = {
    "anthropic":    "ANTHROPIC_API_KEY",
    "azure_openai": "AZURE_OPENAI_API_KEY",
    "openai":       "OPENAI_API_KEY",
}


def _ficheros(carpeta: Path) -> int:
    if not carpeta.is_dir():
        return 0
    return sum(1 for p in carpeta.rglob("*") if p.is_file() and not p.name.startswith("."))


def _paso(id_: str, estado: str, detalle: str, obligatorio: bool = True) -> dict:
    return {"id": id_, "estado": estado, "detalle": detalle, "obligatorio": obligatorio}


def _estado_config(prov: str) -> tuple[str, str]:
    """Paso 01 hecho solo si el proveedor está APROBADO por el banco y su clave
    existe en la fuente de secretos. [SEG-01/03] Una clave en el .env no cuenta:
    el gateway la rechaza, así que la guía no puede darla por buena."""
    from config.ia import PROVEEDORES
    from config.secretos import SecretoNoDisponible, fuente_secretos, secreto_configurado
    try:
        fuente = fuente_secretos()
    except SecretoNoDisponible:
        return "pendiente", "VIRF_FUENTE_SECRETOS no es válida (keyvault, databricks o entorno)."
    from config.ia import proveedor_autorizado, proveedores_autorizados
    estado = PROVEEDORES.get(prov)
    if not proveedor_autorizado(prov):
        aprobados = ", ".join(proveedores_autorizados())
        return "pendiente", (f"Proveedor {prov}: no autorizado por el banco "
                             f"({estado or 'NO_CATALOGADO'}). Usa {aprobados}.")
    if secreto_configurado(_CLAVE_PROVEEDOR.get(prov, "")):
        return "hecho", f"Proveedor {prov}: credencial disponible en «{fuente}»."
    return "pendiente", (f"Proveedor {prov}: falta {_CLAVE_PROVEEDOR.get(prov)} en la fuente "
                         f"de secretos «{fuente}» (Key Vault en producción).")


@router.get("/progreso")
def progreso(ctx: dict = Depends(contexto_sesion)) -> dict:
    env = env_service.leer_env()
    # El proveedor que usará el agente: fuera de producción se deduce de la
    # clave presente, así que la guía no puede fiarse solo de IA_PROVEEDOR.
    try:
        from config.ia import proveedor_activo
        prov = proveedor_activo()
    except Exception:                                       # noqa: BLE001
        prov = env.get("IA_PROVEEDOR", "azure_openai")
    estado_config, detalle_config = _estado_config(prov)
    inputs, outputs = ctx["inputs"], ctx["outputs"]
    modelo = ctx["modelo"]

    est = estandares_service.estado(ctx)
    n_docs = _ficheros(inputs / "documentacion")
    n_impl = _ficheros(inputs / "implementacion")
    n_total = _ficheros(inputs)
    resultados = (sorted(outputs.rglob("resultados_*.json")) if outputs.is_dir() else [])
    versiones = informe_web.listar_versiones(ctx) if outputs.is_dir() else []

    pasos = [
        _paso("config", estado_config, detalle_config),
        _paso("estandares",
              "hecho" if est.get("confirmado") else ("en_curso" if est.get("subido") else "pendiente"),
              "Estándares confirmados." if est.get("confirmado")
              else "Subido, falta aceptarlo." if est.get("subido")
              else "Aún no has subido el Excel de estándares."),
        _paso("evidencia",
              "hecho" if (n_docs and n_impl) else ("en_curso" if n_total else "pendiente"),
              f"{n_docs} documento(s) y {n_impl} archivo(s) de implementación."
              + ("" if n_impl else " Falta el ZIP de implementación.")),
        _paso("dominio", "hecho" if modelo.get("dominio") else "pendiente",
              f"Dominio: {modelo.get('dominio') or 'sin elegir'}."),
        _paso("skills", "opcional", "Análisis transversales adicionales.", obligatorio=False),
        _paso("cuestionamientos", "opcional", "Preguntas metodológicas propias.", obligatorio=False),
        _paso("prevuelo", "recomendado", "Revisa la evidencia antes de gastar en la validación.",
              obligatorio=False),
        _paso("validar", "hecho" if resultados else "pendiente",
              f"{len(resultados)} corrida(s) con resultados." if resultados
              else "Todavía no hay resultados."),
        _paso("documentar", "hecho" if versiones else "pendiente",
              f"{len(versiones)} versión(es) del informe." if versiones
              else "Aún no se ha generado el informe."),
    ]
    siguiente = next((p["id"] for p in pasos if p["obligatorio"] and p["estado"] != "hecho"), None)
    hechos = sum(1 for p in pasos if p["obligatorio"] and p["estado"] == "hecho")
    total = sum(1 for p in pasos if p["obligatorio"])
    return {"pasos": pasos, "siguiente": siguiente, "hechos": hechos, "total": total}
