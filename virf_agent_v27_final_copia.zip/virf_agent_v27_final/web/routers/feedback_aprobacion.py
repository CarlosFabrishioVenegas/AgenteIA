"""
Aprobación del feedback antes de que afecte a los puntajes (Paso 25).

GET  /api/feedback/pendientes            → rol revisor
POST /api/feedback/aprobar {id, decision, motivo} → rol revisor

La decisión queda como enmienda sellada en la cadena del historial (SEG-08) y
en la auditoría (SEG-12). El autor de un feedback no puede aprobarlo.
"""
from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from modulos import feedback

from ..services.roles import requiere

router = APIRouter(prefix="/api/feedback", tags=["feedback"])


class Decision(BaseModel):
    id: str = Field(..., min_length=4, max_length=80)
    decision: Literal["aprobado", "negado"]
    motivo: str = Field(..., min_length=5, max_length=300)


@router.get("/pendientes")
def pendientes(_val: dict = Depends(requiere("aprobar"))) -> dict:
    regs = [r for r in feedback.cargar_historial()
            if isinstance(r, dict) and r.get("estado_aprobacion", "pendiente") == "pendiente"]
    return {"pendientes": [{k: r.get(k) for k in ("_id", "ambito", "actividad", "puntaje_agente",
                                                  "puntaje_correcto", "comentario", "validador")}
                           for r in regs]}


@router.post("/aprobar")
def aprobar(body: Decision, val: dict = Depends(requiere("aprobar"))) -> dict:
    from modulos import auditoria
    try:
        reg = feedback.aprobar_feedback(body.id, quien=val.get("upn", ""), oid=val.get("oid", ""),
                                        decision=body.decision, motivo=body.motivo)
    except KeyError as exc:
        raise HTTPException(404, str(exc))
    except PermissionError as exc:
        raise HTTPException(403, str(exc))
    auditoria.registrar("decision_feedback", body.id, quien=val.get("upn"), oid=val.get("oid"),
                        decision=body.decision)
    return {"ok": True, "id": body.id, "estado": reg["estado_aprobacion"]}
