"""
Router del apartado «Solo Informe»: genera el Informe de Resultados sin pipeline.

Solo exige login (no modelo activo): el apartado es independiente de las
sesiones de validación. Ningún endpoint llama a la IA.

  GET    /api/solo-informe/estado            → estándar cargado + borrador guardado
  POST   /api/solo-informe/estandar          → sube Estandar_VIRF.xlsx y lo parsea
  DELETE /api/solo-informe/estandar          → quita el estándar
  PUT    /api/solo-informe/borrador          → guarda el formulario (sin generar)
  POST   /api/solo-informe/imagen            → sube una imagen de sustento
  GET    /api/solo-informe/imagen/{id}       → la sirve (vista previa en la web)
  POST   /api/solo-informe/adjunto?clasificacion=…  → Excel/Word/PPT/correo/PDF que
                                                      se incrusta en el Word con su icono
  POST   /api/solo-informe/generar           → genera el .docx
  GET    /api/solo-informe/descargar/{nombre}→ descarga un .docx generado

Asistencia con IA (opcional; proveedor del .env, ver `solo_informe_ia`):
  GET    /api/solo-informe/ia/estado          → proveedor, modelo y credenciales que faltan
  POST   /api/solo-informe/ia/pulir           → propuesta de redacción
  POST   /api/solo-informe/ia/grafico         → esquema/gráfico de un texto largo
  POST   /api/solo-informe/ia/manuales        → contexto o sustento sacado de los manuales
  GET/POST/DELETE /api/solo-informe/manuales  → manuales del modelo (PDF/DOCX/TXT/MD)
"""
from __future__ import annotations

import re
from typing import Any, Optional

from fastapi import APIRouter, Cookie, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ..services import sesion_store
from ..services import solo_informe_reglas as reglas
from ..services import solo_informe_service as svc
from ..services import solo_informe_ia as ia
from ..services import solo_informe_word
from ..services.contexto_sesion import SESIONES_DIR
from ..services.estandares_service import EstandarInvalido

router = APIRouter(prefix="/api/solo-informe", tags=["solo-informe"])


def base_solo_informe(virf_token: Optional[str] = Cookie(default=None)):
    val = sesion_store.sesion_activa(virf_token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    return svc.base_de(SESIONES_DIR, val["codigo"])


class Adjunto(BaseModel):
    id: str                              # devuelto por POST /adjunto
    nombre: str = ""                     # nombre original (etiqueta del icono)


class Sustento(BaseModel):
    tipo: str = ""                       # "", "imagen", "codigo", "texto", "adjunto"
    contenido: str = ""
    imagen_id: str = ""
    adjuntos: list[Adjunto] = Field(default_factory=list)


class Observacion(BaseModel):
    ambito: str = ""
    riesgo: str
    control_id: str
    observacion: str = ""
    recomendacion: str = ""
    responsable: str = ""
    fecha_subsanacion: str = ""
    sustento: Sustento = Field(default_factory=Sustento)
    grafico_id: str = ""                 # figura generada con IA (opcional)


class DatosInforme(BaseModel):
    tipo: str = ""                       # "periodica" | "primera_vez"
    tier: str = ""                       # "I".."IV" (filtra el estándar)
    nombre_modelo: str = ""
    responsable_doc: str = ""            # responsable de la documentación (validador)
    revisado_por: str = ""               # por defecto, solo_informe_word.REVISOR_POR_DEFECTO
    fecha_inicio: str = ""
    fecha_entrega: str = ""
    contexto: str = ""
    limitaciones: str = ""
    observaciones: list[Observacion] = Field(default_factory=list)


@router.get("/estado")
def estado(base=Depends(base_solo_informe)) -> dict[str, Any]:
    return {
        "estandar": svc.cargar_estandar(base),
        "borrador": svc.cargar_borrador(base),
        "catalogos": {"ambitos": list(reglas.AMBITOS), "riesgos": list(reglas.RIESGOS),
                      "tiers": list(svc.TIERS)},
    }


@router.post("/estandar")
async def subir_estandar(archivo: UploadFile = File(...),
                         base=Depends(base_solo_informe)) -> dict[str, Any]:
    if not (archivo.filename or "").lower().endswith(".xlsx"):
        raise HTTPException(400, "solo se acepta .xlsx")
    contenido = await archivo.read()
    if not contenido:
        raise HTTPException(400, "el fichero está vacío")
    try:
        est = svc.guardar_estandar(base, contenido)
    except EstandarInvalido as exc:
        raise HTTPException(400, f"Excel inválido: {exc}")
    return {"status": "ok", "filename": archivo.filename, "estandar": est}


@router.delete("/estandar")
def borrar_estandar(base=Depends(base_solo_informe)) -> dict[str, Any]:
    for p in (svc.ruta_xlsx(base), svc.ruta_json(base)):
        p.unlink(missing_ok=True)
    return {"status": "ok"}


@router.put("/borrador")
def guardar_borrador(datos: DatosInforme, base=Depends(base_solo_informe)) -> dict:
    d = datos.model_dump()
    svc.limpiar_om(d["observaciones"])
    svc.guardar_borrador(base, d)
    return {"status": "ok"}


@router.post("/imagen")
async def subir_imagen(archivo: UploadFile = File(...),
                       base=Depends(base_solo_informe)) -> dict[str, Any]:
    try:
        ident = svc.guardar_imagen(base, archivo.filename or "", await archivo.read())
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"status": "ok", "imagen_id": ident, "nombre": archivo.filename}


@router.post("/adjunto")
async def subir_adjunto(archivo: UploadFile = File(...),
                        clasificacion: str = Query(..., description="Publico | Interno | Restringido"),
                        base=Depends(base_solo_informe),
                        virf_token: Optional[str] = Cookie(default=None)) -> dict[str, Any]:
    """Excel, Word, PowerPoint, correo (.msg/.eml) o PDF que se incrusta en el
    Word con su icono. [SEG-06] Como toda evidencia, exige clasificación y un
    adjunto Restringido no se guarda en este equipo."""
    from modulos import almacenamiento as _alm
    try:
        clase = _alm.exigir_permitido(clasificacion)
    except _alm.ClasificacionInvalida as exc:
        raise HTTPException(400, str(exc))
    except _alm.AlmacenamientoNoPermitido as exc:
        raise HTTPException(403, str(exc))
    try:
        ident = svc.guardar_adjunto(base, archivo.filename or "", await archivo.read())
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    quien = (sesion_store.sesion_activa(virf_token) or {}).get("upn", "")
    _alm.registrar_clasificacion(svc.ruta_adjunto(base, ident), clase, quien)
    return {"status": "ok", "id": ident, "nombre": archivo.filename,
            "clasificacion": clase}


@router.get("/imagen/{ident}")
def ver_imagen(ident: str, base=Depends(base_solo_informe)):
    ruta = svc.ruta_imagen(base, ident)
    if ruta is None:
        raise HTTPException(404, "imagen no encontrada")
    return FileResponse(ruta)


@router.post("/generar")
def generar(datos: DatosInforme, base=Depends(base_solo_informe)) -> dict[str, Any]:
    estandar = svc.cargar_estandar(base)
    if estandar is None:
        raise HTTPException(400, "sube primero el Estandar_VIRF.xlsx")
    d = datos.model_dump()
    svc.limpiar_om(d["observaciones"])
    svc.guardar_borrador(base, d)
    estandar = svc.filtrar_por_tier(estandar, d["tier"])
    errores = svc.validar_datos(d, estandar)
    if errores:
        raise HTTPException(400, " · ".join(errores))
    ruta = solo_informe_word.generar(d, estandar, base)
    return {
        "status": "ok",
        "nombre": ruta.name,
        "url": f"/api/solo-informe/descargar/{ruta.name}",
        "conclusion": reglas.concluir(d["observaciones"]),
        "cumplimiento": svc.cumplimiento(estandar, d["observaciones"]),
    }


_NOMBRE_DOCX_RE = re.compile(r"^Informe_Resultados_[A-Za-z0-9_\-]+\.docx$")


@router.get("/descargar/{nombre}")
def descargar(nombre: str, base=Depends(base_solo_informe)):
    if not _NOMBRE_DOCX_RE.match(nombre):
        raise HTTPException(400, "nombre de fichero no válido")
    ruta = svc.dir_salida(base) / nombre
    if not ruta.is_file():
        raise HTTPException(404, "informe no encontrado")
    return FileResponse(
        ruta, filename=nombre,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


# ── Asistencia con IA ─────────────────────────────────────────────────

class PedidoTexto(BaseModel):
    texto: str = Field("", max_length=ia.MAX_TEXTO)
    campo: str = "observacion"


class PedidoManuales(BaseModel):
    objetivo: str                        # "contexto" | "observacion"
    nombre_modelo: str = ""
    control_id: str = ""
    texto: str = Field("", max_length=ia.MAX_TEXTO)


def _ia(fn, *args, **kwargs):
    """Traduce los errores de la IA a HTTP: 503 sin credenciales, 502 si falla."""
    try:
        return fn(*args, **kwargs)
    except ia.IANoConfigurada as exc:
        raise HTTPException(503, str(exc))
    except ia.IAFallo as exc:
        raise HTTPException(502, str(exc))
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@router.get("/ia/estado")
def ia_estado(base=Depends(base_solo_informe)) -> dict[str, Any]:
    return ia.estado()


@router.post("/ia/pulir")
def ia_pulir(p: PedidoTexto, base=Depends(base_solo_informe)) -> dict[str, Any]:
    return {"texto": _ia(ia.pulir, p.texto, p.campo)}


@router.post("/ia/grafico")
def ia_grafico(p: PedidoTexto, base=Depends(base_solo_informe)) -> dict[str, Any]:
    return _ia(ia.grafico, base, p.texto, p.campo)


@router.post("/ia/manuales")
def ia_manuales(p: PedidoManuales, base=Depends(base_solo_informe)) -> dict[str, Any]:
    actividad = ""
    if p.objetivo == "observacion":
        est = svc.cargar_estandar(base) or {"controles": []}
        c = next((c for c in est["controles"] if c["id"] == p.control_id), None)
        if c is None:
            raise HTTPException(400, "elige la actividad relacionada antes de buscar en los manuales")
        actividad = c["actividad"]
    return _ia(ia.desde_manuales, base, p.objetivo, nombre_modelo=p.nombre_modelo,
               actividad=actividad, texto=p.texto)


@router.get("/manuales")
def manuales(base=Depends(base_solo_informe)) -> dict[str, Any]:
    return {"manuales": ia.listar_manuales(base)}


@router.post("/manuales")
async def subir_manual(archivo: UploadFile = File(...),
                       base=Depends(base_solo_informe)) -> dict[str, Any]:
    try:
        r = ia.guardar_manual(base, archivo.filename or "", await archivo.read())
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"status": "ok", **r, "manuales": ia.listar_manuales(base)}


@router.delete("/manuales/{nombre}")
def borrar_manual(nombre: str, base=Depends(base_solo_informe)) -> dict[str, Any]:
    if not ia.borrar_manual(base, nombre):
        raise HTTPException(404, "manual no encontrado")
    return {"status": "ok", "manuales": ia.listar_manuales(base)}
