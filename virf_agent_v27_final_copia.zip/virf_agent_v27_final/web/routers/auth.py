"""
Autenticación SSO con Microsoft Entra ID (SEG-02).

Antes: login por código + nombre, sin contraseña, con alta al vuelo — cualquiera
podía entrar (y firmar) como cualquiera. Ahora:

  GET  /api/auth/login     → redirige al IdP (OIDC, código de autorización)
  GET  /api/auth/callback  → canjea el código, crea la sesión, cookie httponly
  POST /api/auth/logout
  GET  /api/auth/actual    → validador de la sesión o 401
  GET  /api/auth/modo      → {"proveedor": "entra" | "libre"} (qué login mostrar)
  POST /api/auth/login-libre {nombre, cargo, roles} → SOLO con proveedor «libre»
                           (prueba de la web v2, MODO≠produccion; identidad marcada)

El proveedor se elige en `config/identidad.py` (`VIRF_IDENTIDAD_PROVEEDOR`);
el simulado solo existe en tests.
"""
from __future__ import annotations

import threading
import time
from typing import List

from fastapi import APIRouter, Cookie, HTTPException, Request, Response
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field

from config.identidad import (AsercionInvalida, IdentidadNoConfigurada, ProveedorLibre,
                              obtener_proveedor, proveedor_activo)

from ..services import sesion_store

router = APIRouter(prefix="/api/auth", tags=["auth"])

COOKIE_TOKEN = "virf_token"
_FLUJO_TTL_S = 600

# state → (instante, flujo). En servidor: el navegador solo ve el `state`.
_flujos: dict[str, tuple[float, dict]] = {}
_lock = threading.Lock()


def _purgar() -> None:
    limite = time.time() - _FLUJO_TTL_S
    for k in [k for k, (t, _) in _flujos.items() if t < limite]:
        _flujos.pop(k, None)


@router.get("/login")
def iniciar_login() -> RedirectResponse:
    try:
        url, state, flujo = obtener_proveedor().iniciar()
    except IdentidadNoConfigurada as exc:
        raise HTTPException(503, str(exc))
    with _lock:
        _purgar()
        _flujos[state] = (time.time(), flujo)
    return RedirectResponse(url, status_code=302)


@router.get("/callback")
def completar_login(request: Request) -> RedirectResponse:
    params = dict(request.query_params)
    with _lock:
        _purgar()
        guardado = _flujos.pop(params.get("state", ""), None)
    if guardado is None:
        raise HTTPException(400, "login caducado o state desconocido; vuelve a entrar")
    try:
        identidad = obtener_proveedor().completar(guardado[1], params)
        token, _val = sesion_store.crear_sesion(identidad)
    except (AsercionInvalida, ValueError) as exc:
        raise HTTPException(401, f"login rechazado: {exc}")
    except PermissionError as exc:
        raise HTTPException(403, str(exc))
    except IdentidadNoConfigurada as exc:
        raise HTTPException(503, str(exc))
    resp = RedirectResponse("/", status_code=302)
    _poner_cookie(resp, token)
    return resp


def _poner_cookie(resp: Response, token: str) -> None:
    resp.set_cookie(key=COOKIE_TOKEN, value=token, httponly=True, secure=True,
                    samesite="lax", max_age=int(sesion_store._ttl().total_seconds()))


@router.get("/modo")
def modo_login() -> dict:
    """Qué pantalla de login pinta la SPA. Solo «libre» cambia la vista."""
    return {"proveedor": "libre" if proveedor_activo() == "libre" else "entra"}


class LoginLibre(BaseModel):
    nombre: str = Field(..., min_length=2, max_length=80)
    cargo: str = Field("Validador", max_length=60)
    roles: List[str] = Field(default_factory=lambda: ["validador"], max_length=3)


@router.post("/login-libre")
def login_libre(body: LoginLibre, response: Response) -> dict:
    """Usuario libre para PROBAR la web sin Entra ID (web v2). Fuera del modo
    «libre», o con MODO=produccion, no existe (503)."""
    if proveedor_activo() != "libre":
        raise HTTPException(503, "el usuario libre no está activo (VIRF_IDENTIDAD_PROVEEDOR≠libre)")
    try:
        ProveedorLibre()                                   # rechaza MODO=produccion
        identidad = ProveedorLibre.identidad(body.nombre, body.cargo, body.roles)
        token, val = sesion_store.crear_sesion(identidad)
    except IdentidadNoConfigurada as exc:
        raise HTTPException(503, str(exc))
    except PermissionError as exc:
        raise HTTPException(403, str(exc))
    except ValueError as exc:
        raise HTTPException(422, str(exc))
    _poner_cookie(response, token)
    return {"validador": {k: val[k] for k in ("codigo", "nombre", "cargo", "upn")},
            "roles": list(identidad.roles), "prueba": True}


@router.post("/logout")
def hacer_logout(response: Response,
                 virf_token: str | None = Cookie(default=None)) -> dict:
    sesion_store.logout(virf_token)
    response.delete_cookie(COOKIE_TOKEN)
    # [SEG-06] Al cerrar sesión también se aplica el plazo de retención.
    try:
        from config.rutas import raices_retencion
        from modulos.almacenamiento import purgar_vencidos
        purgar_vencidos(raices_retencion())
    except Exception:                                        # noqa: BLE001
        pass
    return {"ok": True}


@router.get("/actual")
def validador_actual(virf_token: str | None = Cookie(default=None)) -> dict:
    """Validador logueado o 401 (la SPA decide si mostrar el login)."""
    val = sesion_store.sesion_activa(virf_token)
    if val is None:
        raise HTTPException(401, "no autenticado")
    return {"validador": {k: val[k] for k in ("codigo", "nombre", "cargo", "upn")
                          if k in val}}
