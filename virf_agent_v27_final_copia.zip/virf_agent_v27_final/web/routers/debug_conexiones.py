"""
Endpoint HTTP para el verificador de conexiones (Mejora 5 · v2.2).
Misma contraseña que el visor de prompt.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException

from ..services.contexto_sesion import contexto_sesion
from ..verificar_conexiones import verificar
from ..services.roles import requiere

router = APIRouter(prefix="/api/debug", tags=["debug"])


@router.get("/conexiones")
def conexiones(ctx: dict = Depends(contexto_sesion),
                _val: dict = Depends(requiere("diagnostico"))) -> dict:
    d = verificar(ctx["validador"]["codigo"], ctx["modelo"]["slug"])
    # No devolvemos `_reporte` ni `_ctx` (objetos internos).
    return {"bloques": d["bloques"], "resumen": d["resumen"]}
