"""
Endpoints REST + WebSocket del pipeline de validación (v2 · fase 2).

Ahora anclado a la sesión activa: cada modelo gestiona su propio run.
"""
from __future__ import annotations

import asyncio
import json
from typing import Optional

from fastapi import APIRouter, Cookie, Depends, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

from ..services import modelos_store, pipeline_runner, sesion_store
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(tags=["validacion"])


class LanzarValidacion(BaseModel):
    """[SEG-02] Sin campos de firmante: el firmante es la identidad de la
    sesión SSO. Un cuerpo que intente fijar otro firmante se rechaza (422)."""
    model_config = {"extra": "forbid"}


@router.get("/api/validar/estado")
def estado_actual(ctx: dict = Depends(contexto_sesion)) -> dict:
    r = pipeline_runner.run_de_sesion(ctx["clave"])
    if r is None:
        return {"run": None}
    return {
        "run": {
            "run_id":         r.run_id,
            "estado":         r.estado,
            "fase":           r.fase,
            "exit_code":      r.exit_code,
            "iniciado_utc":   r.iniciado_utc,
            "terminado_utc":  r.terminado_utc,
            "resultado_json": r.resultado_json,
            "linea_final":    r.linea_final,
        }
    }


@router.post("/api/validar/lanzar")
async def lanzar_validacion(body: LanzarValidacion,
                             ctx: dict = Depends(contexto_sesion),
                             virf_token: str | None = Cookie(default=None)) -> dict:
    from ..services import roles as _roles
    _roles.comprobar(virf_token, "validar")          # [SEG-08] 401/403
    identidad = sesion_store.identidad_de_sesion(virf_token)
    try:
        run_id = await pipeline_runner.lanzar(ctx, identidad=identidad)
    except ValueError as exc:
        raise HTTPException(409, str(exc))
    modelos_store.actualizar_actividad(
        ctx["validador"]["codigo"], ctx["modelo"]["slug"],
        estado="en_progreso")
    return {"run_id": run_id}


@router.post("/api/validar/cancelar/{run_id}")
async def cancelar_validacion(run_id: str,
                                _ctx: dict = Depends(contexto_sesion)) -> dict:
    ok = await pipeline_runner.cancelar(run_id)
    if not ok:
        raise HTTPException(404, f"run {run_id!r} no está activo")
    return {"ok": True}


@router.websocket("/ws/validar/{run_id}")
async def ws_validar(ws: WebSocket, run_id: str) -> None:
    """
    Emite el stream de eventos del runner identificado por `run_id`.

    Al ser un WebSocket, la autenticación por cookie sigue funcionando
    (el navegador manda cookies en el handshake), pero validar aquí es
    complejo: la aceptación explícita por run_id ya limita el ataque a
    quien conozca el uuid. Aún así, se puede validar el login mínimo.
    """
    await ws.accept()
    r = pipeline_runner.run_por_id(run_id)
    if r is None:
        await ws.send_json({"tipo": "error", "detalle": f"run {run_id} desconocido"})
        await ws.close()
        return

    # Comprobación mínima: cookie de login válida (no exigimos cookie de
    # modelo aquí porque el run_id ya identifica la sesión).
    token = ws.cookies.get("virf_token")
    if sesion_store.sesion_activa(token) is None:
        await ws.send_json({"tipo": "error", "detalle": "no autenticado"})
        await ws.close()
        return

    try:
        while True:
            try:
                evento = await asyncio.wait_for(r.eventos.get(), timeout=30.0)
            except asyncio.TimeoutError:
                await ws.send_json({"tipo": "ping"})
                if r.proceso is not None and r.proceso.returncode is not None:
                    break
                continue
            await ws.send_text(json.dumps(evento, ensure_ascii=False))
            if evento.get("tipo") == "fin":
                break
    except WebSocketDisconnect:
        return
    finally:
        try:
            await ws.close()
        except Exception:
            pass
