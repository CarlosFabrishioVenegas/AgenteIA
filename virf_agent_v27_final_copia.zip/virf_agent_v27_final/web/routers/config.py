"""
Configuración del proveedor IA (v2 · fase 2).

[SEG-03] Este router es de SOLO LECTURA para credenciales: muestra si la
clave está configurada en la fuente de secretos (Key Vault / secret scope),
nunca su valor, y no acepta ni escribe claves. Ningún endpoint escribe `.env`.

En v1 este router también gestionaba «modelo actual» y «tier». En v2
eso vive en `modelos_store` (la ficha del modelo), y este router se
limita a lo del proveedor.
"""
from __future__ import annotations

import os
from typing import Literal

from fastapi import APIRouter, Cookie, HTTPException
from pydantic import BaseModel, Field

from config.secretos import fuente_secretos, secreto_configurado

from ..services import env_service, modelos_store, sesion_store

router = APIRouter(prefix="/api/config", tags=["config"])

COOKIE_MODELO = "virf_modelo"

PROVEEDORES: dict[str, dict[str, list[str]]] = {
    "azure_openai": {
        "obligatorias": [
            "AZURE_OPENAI_API_KEY",
            "AZURE_OPENAI_ENDPOINT",
            "AZURE_OPENAI_DEPLOYMENT",
            "AZURE_OPENAI_API_VERSION",
        ],
        "opcionales": ["AZURE_OPENAI_MAX_TOKENS"],
    },
}
# [SEG-01] Solo Azure OpenAI está APROBADO por el banco; Anthropic
# (EN_ESPERA) y OpenAI (RETIRADO) no se ofrecen en la web.

CLAVES_SECRETAS = {"AZURE_OPENAI_API_KEY"}

# VIRF PLUS: variables que gobierna su propio panel (no el toggle de proveedor).
# GPT es el agente principal; VIRF PLUS añade a Claude como segunda opinión.
VARS_VIRF_PLUS = ("VIRF_PLUS", "VIRF_PLUS_GPT", "VIRF_PLUS_ARBITRO",
                  "VIRF_PLUS_ARBITRAJE", "ANTHROPIC_API_KEY", "ANTHROPIC_MODELO")
PROVEEDORES_GPT = ("azure_openai",)


class ConfigModelo(BaseModel):
    titulo: str = Field(..., min_length=1, max_length=100)
    tier:   str


class ConfigVirfPlus(BaseModel):
    activo:         bool
    arbitro:        Literal["gpt", "anthropic"] = "gpt"
    arbitraje:      Literal["siempre", "discrepancia"] = "siempre"


def _snapshot_env() -> dict:
    env = env_service.leer_env()
    ficha = {"proveedor_activo": _proveedor_activo(env)}
    for prov, catalogo in PROVEEDORES.items():
        ficha[prov] = {}
        for clave in catalogo["obligatorias"] + catalogo["opcionales"]:
            if clave in CLAVES_SECRETAS:
                ficha[prov][clave] = {"seteada": secreto_configurado(clave)}
            else:
                ficha[prov][clave] = {
                    "seteada": bool(env.get(clave)),
                    "valor":   env.get(clave, ""),
                }
    ficha["virf_plus"] = _estado_virf_plus(env)
    try:
        ficha["fuente_secretos"] = fuente_secretos()
    except ValueError:
        ficha["fuente_secretos"] = "inválida"
    return ficha


def _estado_virf_plus(env: dict) -> dict:
    """Estado del panel VIRF PLUS, sin secretos."""
    def _v(clave, defecto=""):
        return env.get(clave, os.environ.get(clave, defecto))
    activo = str(_v("VIRF_PLUS", "0")).strip().lower() in (
        "1", "true", "si", "sí", "yes", "on")
    gpt = _gpt_principal(env)
    try:
        from config.ia import _credenciales_completas
        clave_gpt_ok = _credenciales_completas(gpt)
    except Exception:                                       # noqa: BLE001
        clave_gpt_ok = secreto_configurado("AZURE_OPENAI_API_KEY")
    return {
        "activo":         activo,
        "gpt":            gpt,
        "arbitro":        _v("VIRF_PLUS_ARBITRO", "gpt") or "gpt",
        "arbitraje":      _v("VIRF_PLUS_ARBITRAJE", "siempre") or "siempre",
        "claude_modelo":  _v("ANTHROPIC_MODELO", ""),
        "claude_api_key": {"seteada": secreto_configurado("ANTHROPIC_API_KEY")},
        "gpt_listo":      clave_gpt_ok,
        "listo":          secreto_configurado("ANTHROPIC_API_KEY") and clave_gpt_ok,
    }


def _proveedor_activo(env: dict) -> str:
    """Proveedor que usará el agente (deducido de la clave fuera de producción)."""
    try:
        from config.ia import proveedor_activo
        return proveedor_activo()
    except Exception:                                       # noqa: BLE001
        return env.get("IA_PROVEEDOR", os.environ.get("IA_PROVEEDOR", "azure_openai"))


def _gpt_principal(env: dict) -> str:
    """El GPT de VIRF PLUS es el del agente principal; si el principal no es
    GPT, el GPT que tenga credenciales (Azure por defecto)."""
    prov = _proveedor_activo(env)
    if prov in PROVEEDORES_GPT:
        return prov
    try:
        from config.virf_plus import proveedor_gpt
        return proveedor_gpt()
    except Exception:                                       # noqa: BLE001
        return "azure_openai"


def _validador_o_401(token: str | None) -> dict:
    val = sesion_store.sesion_activa(token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    return val


@router.get("")
def get_config(virf_token: str | None = Cookie(default=None)) -> dict:
    """Estado del .env + validador logueado (sin secretos)."""
    val = _validador_o_401(virf_token)
    return {
        "validador":   val,
        "env":         _snapshot_env(),
        "proveedores": PROVEEDORES,
    }


@router.post("/modelo")
def set_modelo(body: ConfigModelo,
               virf_token: str | None = Cookie(default=None),
               virf_modelo: str | None = Cookie(default=None)) -> dict:
    """
    Guarda título (etiqueta visible) y tier del MODELO ACTIVO. El modelo
    activo se identifica por la cookie `virf_modelo` (su slug). No renombra
    la carpeta: el slug es la identidad. Sin modelo activo devuelve 409 en
    vez del 404 opaco que veía la UI.
    """
    val = _validador_o_401(virf_token)
    if not virf_modelo:
        raise HTTPException(
            409, "no hay un modelo activo; entra a un modelo antes de guardar")
    try:
        m = modelos_store.actualizar_meta(
            val["codigo"], virf_modelo, nombre=body.titulo, tier=body.tier)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    if m is None:
        raise HTTPException(404, "el modelo activo ya no existe en disco")
    return {"modelo": m}


@router.post("/virf_plus")
def set_virf_plus(body: ConfigVirfPlus,
                  virf_token: str | None = Cookie(default=None)) -> dict:
    """
    Botón VIRF PLUS: suma (o quita) a Claude como segunda opinión del agente
    principal, que es GPT.

    [SEG-03] Ya no se persiste en `.env`: el cambio vale para ESTE proceso
    (entorno y caché del cliente IA). Con Claude EN_ESPERA solo puede apagarse.
    """
    _validador_o_401(virf_token)
    # [SEG-01] Encenderlo exige que GPT y Claude estén APROBADOS; hoy no.
    if body.activo:
        from config.ia import estado_efectivo as _estado, proveedor_autorizado as _aut
        bloqueados = [p for p in ("anthropic", _gpt_principal(env_service.leer_env()))
                      if not _aut(p)]
        if bloqueados:
            raise HTTPException(
                409, "VIRF PLUS bloqueado hasta aprobación del proveedor: "
                     + ", ".join(f"{p} ({_estado(p)})" for p in bloqueados))
    gpt = _gpt_principal(env_service.leer_env())
    cambios: dict[str, str] = {
        "VIRF_PLUS":           "1" if body.activo else "0",
        "VIRF_PLUS_GPT":       gpt,
        "VIRF_PLUS_ARBITRO":   body.arbitro,
        "VIRF_PLUS_ARBITRAJE": body.arbitraje,
    }
    os.environ.update(cambios)

    # Los parámetros de VIRF PLUS se leyeron al importar; se refrescan para que
    # el cambio de GPT/árbitro también valga sin reiniciar.
    from config import parametros as _par
    _par.VIRF_PLUS_GPT = gpt
    _par.VIRF_PLUS_ARBITRO = body.arbitro
    _par.VIRF_PLUS_ARBITRAJE = body.arbitraje
    try:
        from config import virf_plus as _vp, ia as _ia
        _vp.VIRF_PLUS_GPT, _vp.VIRF_PLUS_ARBITRO, _vp.VIRF_PLUS_ARBITRAJE = (
            gpt, body.arbitro, body.arbitraje)
        _ia.reset_cliente_ia()
    except Exception:
        pass

    estado = _estado_virf_plus(env_service.leer_env())
    aviso = None
    if body.activo and not estado["listo"]:
        falta = []
        if not estado["gpt_listo"]:
            falta.append("las credenciales del agente principal GPT (sección Proveedor IA)")
        if not estado["claude_api_key"]["seteada"]:
            falta.append("la API key de Claude")
        aviso = "VIRF PLUS está encendido pero falta " + " y ".join(falta) + "."
    return {"ok": True, "virf_plus": estado, "aviso": aviso}


@router.post("/verificar")
def verificar_conexion(virf_token: str | None = Cookie(default=None)) -> dict:
    _validador_o_401(virf_token)
    from config.ia import (prueba_de_humo, metadatos_proveedor, proveedor_activo,
                           proveedor_autorizado, proveedores_autorizados)
    meta = metadatos_proveedor()
    resultado = prueba_de_humo()
    resultado["proveedor_meta"] = {
        "nombre":       meta.get("nombre"),
        "vars_revisar": meta.get("vars_revisar", []),
        "consola":      meta.get("consola"),
        # [SEG-01] Si el proveedor no está aprobado, ninguna variable lo arregla:
        # la web debe decir «cambia de proveedor», no «revisa la clave».
        "autorizado":   proveedor_autorizado(proveedor_activo()),
        "aprobados":    proveedores_autorizados(),
    }
    # Persistimos el modelo detectado en la sesión de login para que
    # /api/prompts/presupuesto y pipeline_runner calculen el presupuesto
    # de contexto real (perfil del catálogo) y no el conservador.
    modelo_ia = (resultado.get("modelo")
                 or resultado.get("modelo_real")
                 or resultado.get("deployment"))
    if modelo_ia:
        sesion_store.set_atributo_sesion(
            virf_token, "modelo_ia_detectado", str(modelo_ia))
        from ..services import presupuesto_service
        resultado["presupuesto_contexto"] = presupuesto_service.calcular(str(modelo_ia))
    return resultado
