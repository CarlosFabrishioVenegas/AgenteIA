# Graph Report - virf_agent_v27_final (1)  (2026-11-04)

## Corpus Check
- 343 files · ~581,990 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 25 file(s) not represented in the graph (top: (none) 5, .xml 5, .csv 5)

## Summary
- 6272 nodes · 13119 edges · 335 communities (173 shown, 162 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 486 edges (avg confidence: 0.87)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `cef5ec9a`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- .get_conversation_history
- generar_notebook_controles
- app.py
- Datos · Pipeline de calidad de datos
- Archivado v28 · Orquestador de flujos
- logging
- generar_guia_agente.py
- Tests · RAG léxico (recuperación)
- motor_ia_v2.py
- RAG · Indexadores por dominio y reconstrucción
- BuscadorLexico
- Agente · Punto de entrada y cliente IA
- Motor IA · Evaluar actividades y ámbitos
- estandares_service.py
- DecisionTrace
- RAG · Recuperador y resolución de dominio
- Archivado v28 · Vector store Chroma
- Informe Word · Estilos y formato
- plantilla_bcp.py
- Controles · Excel a notebook ejecutable
- generador_word.py
- Archivado · Parches v13 (código muerto)
- Revisión de código · Juez anclado y hallazgos
- IndexadorLexico
- Archivado · Generador Word antiguo (Mx_05)
- Web · Verificar conexiones y cuestionamientos
- Web · Gestión de modelos (store y rutas)
- Archivado v28 · Herramientas SQL y pandas
- Motor · Lectura de evidencias (Mx_01)
- Seguridad · Cortacircuitos (fusibles)
- get_prompt
- Web · Rutas RAG y dominios personalizados
- reglas_informe.py
- Solo Informe · Reglas de conclusión
- Automatizaciones · Cuadro de observaciones
- Prevuelo · Chequeo previo de evidencia
- Web · Catálogo de skills
- Utilidades · Consola Unicode y scripts sueltos
- Caché de documentos
- comparar
- test_versionado.py
- Tests · Simulación de Azure (pipeline)
- ContextCompressor
- Archivado v28 · Agente VIRF antiguo
- ia.py
- VIRF PLUS · Consenso entre dos modelos
- Tests · Corpus RAG como resumen secundario
- Web · Configuración y archivo .env
- test_pendientes_auditoria.py
- Web · Subida de archivos y ZIP
- verificar_emisiones
- Web · Chat de validación
- Solo Informe · Estándar, borrador e imágenes
- Revisión de código · Hallazgos
- con_reintento
- Skills · Calidad de datos
- Skills · Catálogo y clase base
- Firma humana · Doble firma
- Web · Login y sesiones de validadores
- Frontend · Pantalla de resultados
- TextChunker
- Archivado · Config monolítica antigua
- Salvaguardas · Entailment (LLM como juez)
- Tests · RAG como pericia (no evidencia)
- Verificador VIRF · Paquete de verificación
- Tests · Estructura de la configuración
- Web · Edición de prompts
- Salvaguardas · Enmascarado de PII
- Frontend · Arranque, login y navegación
- Solo Informe · Router y endpoints
- Aislamiento entre clientes (tenant)
- Informe Markdown
- Motor IA · Scores y semáforo
- Archivado · Generador Excel antiguo
- Skills tipadas · Documentación y gobierno
- calidad_proceso
- Esquemas de datos (contratos)
- Tests · Notebook de controles
- solo_informe_ia.py
- TestPresentacionWord
- Web · Pantalla Solo Informe (frontend)
- Motor · Controles sobre datos (Mx_04)
- Chunker · Troceado de documentos
- Motores de la entidad · Leer resultados
- Skills · Coherencia manual vs implementación
- Abstención y calibración beta
- Explicador del modelo
- Citas · Validación determinista
- Tests · Controles de calidad de datos
- Archivado v28 · Detector de fórmulas y metodología
- Esquemas · Validación de afirmaciones
- validate_project.py
- feedback.py
- Tabla de validación y veredictos
- Skills · Cola de acciones pendientes
- Tests · Análisis estático
- Frontend · Dominios RAG y documentación
- Frontend · Guía interactiva
- Archivado v28 · Challenger con RAG
- motores_datos.py
- Scripts · Reconstruir estándar y verificar corpus
- Tests · Catálogo y detección de modelos
- Análisis estático del código
- Tests · SQL y R como código del modelo
- leer_resultados
- informe_web.py
- capturas.py
- actualizar_estandares_con_version
- Archivado · Lector de inputs antiguo
- Fixtures · IFRS9 y VaR de demostración
- CalculadorScore
- Tests · Revisión de código
- Skills · Síntesis y contrato
- leer_estandares_virf
- Tests · Resultados por celda del notebook
- Web · Rutas de cuestionamientos
- hash_contenido
- Tests · Informe Word sin puntajes falsos
- solo_informe_word.py
- reporte_docx.py
- Web · Descarga de resultados
- Archivado v28 · Challenger sin RAG
- Archivado · Comparativa doc vs código
- Chunker estructural
- Skills · Citas inventadas (challenger, supuestos)
- TestTopePorToleranciaCero
- Tests · PDF real y chunking
- Tests · Parser de estándares
- Tests · Neutralidad de proveedor IA
- Agente · Acotar contexto de skills
- Salvaguardas · Inyección de prompts
- Firma humana · Identidad del validador
- generar
- Tests · Conexión Azure y parámetros
- get_retriever
- Tests · Explicador del modelo
- Web · Rutas del chat
- test_automatizaciones.py
- Tests · Solo Informe (Word y endpoints)
- Seguridad · Nombres de archivo seguros
- generador_estadistica_feedback.py
- Tests · Skills en el entregable
- Exportador Excel
- generar_word_informe
- perfilar_dataframe
- Tests · DOCX de regresión
- Multimodelo · Raíz de evidencia
- Tests · Skills tipadas
- Tests · Reintento ante cuota (429)
- Tests · Red corporativa y TLS
- Tests · Auditoría integral 2026-08-07
- Tests · Caché de resúmenes
- Tests · Explicador agnóstico al modelo
- Tests · Cuestionamientos extensibles
- Frontend · Navegación y vistas
- logo_para_word
- Tests · Subida ZIP (límites)
- columns
- Tests · Borrado del caché
- verificar_cadena
- Tests · Consolidación
- Tests · Preguntas de oro RAG
- es_de_entorno_virtual
- Tests · Score de control ponderado
- sha256_texto
- Archivado v28 · Lector de código
- Tests · Filtro de contenido Azure
- TestSegundoUmbralRecall3
- Controles · Repositorio por dominio
- TestAuditoriaHistorialSucioNoTumbaLasEstadisticas
- Tests · Acantilado de coste
- Tests · Umbral antisesgo
- Tests · Lectura íntegra de código e ipynb
- Frontend · Chat
- fuentes_rag
- virf_agente.py
- Archivado v28 · Demo challenger
- Consolidación de decisiones
- sellar_y_escribir
- Tests · Políticas del procedimiento 2026
- Web · Presupuesto de prompts
- analizar
- prompt_service.py
- typing
- TestReintentoContrato
- Tests · Sin evidencia no es fallo
- Tests · Caché de resúmenes con bloqueo
- Tests · Lectura fallida declarada
- Tests · Custodia bajo concurrencia
- Tests · Ninguna llamada externa
- parametros.py
- Config · Perfil del modelo (contexto)
- orquestar_pipeline_ambitos
- comparador.py
- Skills · Regulatoria con RAG
- Tests · Historial de feedback
- Tests · Índice RAG sin contaminación
- Tests · Contexto se llena sin abandonar
- Frontend · Cuestionamientos y skills
- Tests · Respuestas de Azure OpenAI
- Archivado v28 · Skill consolidador
- Archivado v28 · Skill análisis de fallos
- override_humano.py
- catalogo_activo
- Acta de cierre (Excel)
- Tests · Aprendizaje desde el chat
- Tests · Fallo de credencial Azure
- Chat · Adjuntar evidencia
- TestAuditoriaRagNoIndexaLaEvidenciaQueEvalua
- Tests · OCR retirado
- Archivado v28 · Skill detección de fórmulas
- Archivado v28 · Skill metodología
- build_agent
- resumen_override
- Fixtures · Modelo sintético Fraude/AML
- Tests · Un solo parser JSON
- Motor · Llamada IA con contrato JSON
- EmbeddingGenerator
- Frontend · Estándares
- ReasoningEngine
- Análisis estático · Contraste doc vs código
- Tests · Sin documentos no hay puntaje
- Tests · Pipeline completo con Azure
- Tests · Textos largos sin truncar
- Tests · Cobertura documental ponderada
- Tests · Respuesta vacía del modelo
- Tests · Columna de control opcional
- Tests · Filtrado de controles
- Tests · El resumen final cuadra
- BuscadorEvidencias
- Scripts · Verificación del corpus RAG
- Estándares · Flag --estandares por CLI
- Frontend · Lanzar validación
- WorkflowContext
- Tests · Cierre del caché
- Prevuelo · Hallazgos e informe
- RepoReconstructionSkill
- Tests · Fixtures compartidas (conftest)
- estructura
- Skills · Skill de síntesis
- test_endpoint_notebook_controles.py
- Tests · Nombres de ámbito
- orquestar_pipeline_virf
- Tests · Pipeline de controles
- Tests · Ningún recorte silencioso
- perfilar_carpeta
- Chunker · Caché de resúmenes
- Web · Router de prevuelo
- ChainOfThought
- Tests · Invariante de asyncio
- Tests · Dos métricas de cobertura
- Tests · Ruido de pdfminer
- .__init__
- Tests · Un solo acceso al historial
- Control VaR · Kupiec
- Control VaR · Semáforo de Basilea
- test_plantilla_bcp.py
- DocumentationAuditSkill
- PaperIntelligenceSkill
- Control ALM · Backtesting de prepago
- Control ALM · Beta de depósitos
- Control ALM · Brecha de duración
- Control ALM · CPR de prepago
- Control ALM · Decaimiento NMD
- Control ALM · Sensibilidad NII
- Control ALM · Escenarios IRRBB
- Control ALM · Gap de reprecios
- Control ALM · Vida media NMD
- Control LaR · Brecha de liquidez
- Control LaR · Concentración de fondeo
- Control LaR · Horizonte de supervivencia
- Control LaR · Composición HQLA
- Control LaR · LCR
- Control LaR · NSFR
- Control transversal · Columnas constantes
- Control transversal · Frescura
- Control VaR · Excedencias
- Control VaR · Severidad de excepciones
- Control VaR · VaR negativos
- test_regresion.py
- ClienteOpenAIIA
- Tests · Modelo simulado de Solo Informe
- preguntas_oro_formula.py
- notebook_controles.py
- Código muerto · Prompt de dimensión
- val_sin_huggingface
- implementacion_PD_Retail.py
- TestFeedback
- _Reporte
- normalizar_tier
- val_cumplimiento_regulatorio
- TestAuditoriaFallosDeRedSeDiagnosticanBien
- MethodologyComplianceSkill
- Cuestionamiento
- create_estandares_excel.py
- leer_archivo
- TestRolAgenteOverride
- cita
- tesauro.py
- TestTablaFinal
- test_informe_tabla_final.py
- ctx_de_prueba
- TestCustodiaHashDelFicheroPorAmbasRamas
- _indice_dir_defecto
- TestAuditoriaCacheNoSeApagaPorHeuristica
- _sombrear_parrafo

## God Nodes (most connected - your core abstractions)
1. `main()` - 87 edges
2. `pedirJSON()` - 63 edges
3. `escapeHtml()` - 58 edges
4. `ChunkerService` - 44 edges
5. `IndexadorLexico` - 43 edges
6. `BuscadorLexico` - 39 edges
7. `generar_word_informe()` - 33 edges
8. `_indexador()` - 33 edges
9. `VIRFAgent` - 31 edges
10. `BaseSkill` - 30 edges

## Surprising Connections (you probably didn't know these)
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/backtesting_prepago.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/beta_deposito.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/brecha_duracion.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/cpr_prepago.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/decaimiento_nmd.py → tests/test_regresion.py

## Import Cycles
- None detected.

## Communities (335 total, 162 thin omitted)

### Community 1 - "generar_notebook_controles"
Cohesion: 0.15
Nodes (7): analizar_brechas(), extraer_controles_del_documento(), generar_notebook_controles(), leer_controles_excel(), leer_documento(), _score_par(), _similitud()

### Community 2 - "app.py"
Cohesion: 0.04
Nodes (28): index(), salud(), _version_assets(), validador_actual(), iniciar_chat(), IniciarChat, _reconstruye_ctx(), ws_chat() (+20 more)

### Community 3 - "Datos · Pipeline de calidad de datos"
Cohesion: 0.08
Nodes (7): _control_fechas_coherentes(), ejecutar_plan(), escribir_tabla(), main(), _veredicto(), TestPipelineCalidadDatos, _explota()

### Community 4 - "Archivado v28 · Orquestador de flujos"
Cohesion: 0.06
Nodes (7): AgentOrchestrator, TaskRouter, TaskType, WorkflowManager, WorkflowState, handle_command(), main()

### Community 5 - "logging"
Cohesion: 0.02
Nodes (12): ContextFilter, ContextPrioritizer, ContextRanker, CorrectionsTracker, FeedbackAnalyzer, FeedbackStore, LearningLoop, LongTermMemory (+4 more)

### Community 6 - "generar_guia_agente.py"
Cohesion: 0.09
Nodes (39): a_pdf(), analizar_modulos(), archivos_codigo(), catalogo_tests(), comunidades_del_grafo(), comunidades_por_archivo(), construir(), _dotted() (+31 more)

### Community 7 - "Tests · RAG léxico (recuperación)"
Cohesion: 0.06
Nodes (8): _buscador(), _corpus(), _indexador(), TestExpansionDeConsulta, TestIntegracionConElMotor, TestRecuperacion, TestRelevanciaAbsoluta, TestRendimiento

### Community 8 - "motor_ia_v2.py"
Cohesion: 0.05
Nodes (19): evaluar_dimension(), BuscadorEvidencias, create_resultado_control_v13(), DocumentoChunker, EstadoEvaluacion, ReportadorEvaluacion, ValidadorInputs, create_resultado_control_v13() (+11 more)

### Community 9 - "RAG · Indexadores por dominio y reconstrucción"
Cohesion: 0.14
Nodes (14): _construir_pdf(), generar(), _dominios_conocidos(), _dominios_custom(), _get_indexer(), main(), mostrar_status(), rebuild_dominio() (+6 more)

### Community 10 - "BuscadorLexico"
Cohesion: 0.05
Nodes (20): _anclas(), auditar(), _clasificar(), main(), explicar(), main(), _regla(), BuscadorLexico (+12 more)

### Community 11 - "Agente · Punto de entrada y cliente IA"
Cohesion: 0.06
Nodes (20): _aplicar_raiz_evidencia(), _huella_corpus_rag(), main(), _enunciado_control(), evaluaciones_desde_controles(), imprimir_cadena(), imprimir_evidencia(), cerrar_cache() (+12 more)

### Community 12 - "Motor IA · Evaluar actividades y ámbitos"
Cohesion: 0.07
Nodes (19): ajustar_puntaje_por_feedback(), analizar_patron_errores(), cargar_historial(), construir_bloque_aprendizaje(), generar_resumen_aprendizaje(), obtener_recomendaciones_evaluacion(), registrar_feedback_mejorado(), calcular_score_con_ic() (+11 more)

### Community 13 - "estandares_service.py"
Cohesion: 0.09
Nodes (19): _crear_xlsx_estandar(), ctx_de_prueba(), TestParseo, TestPersistencia, borrar(), confirmar(), get_detalle(), get_estado() (+11 more)

### Community 15 - "RAG · Recuperador y resolución de dominio"
Cohesion: 0.09
Nodes (5): ALMRetriever, BaseRetriever, LaRRetriever, SharedRetriever, VaRRetriever

### Community 16 - "Archivado v28 · Vector store Chroma"
Cohesion: 0.07
Nodes (3): Reranker, SemanticSearcher, ChromaManager

### Community 17 - "Informe Word · Estilos y formato"
Cohesion: 0.06
Nodes (18): _add_ambito_heading(), _add_field_block(), _add_hallazgos_codigo(), _portada_desde_json(), add_bloque_codigo(), add_codigo_inline(), aplicar_estilo_documento(), aplicar_fuente() (+10 more)

### Community 18 - "plantilla_bcp.py"
Cohesion: 0.11
Nodes (33): _alcance(), _bloque_codigo(), _bullet(), _callout(), _caption(), _cell_left_accent(), _cell_margins(), _cuadro_resumen() (+25 more)

### Community 19 - "Controles · Excel a notebook ejecutable"
Cohesion: 0.09
Nodes (22): analizar_libro(), analizar_libro_externo_ligero(), auto_validar(), _code(), construir_grafo_libros(), construir_notebook(), _consultar_llm_traduccion(), _consultar_llm_vba() (+14 more)

### Community 20 - "generador_word.py"
Cohesion: 0.09
Nodes (33): _add_bullet(), _add_heading(), _add_numbered(), _add_para(), _add_result_line(), _alcance_desde_json(), _anexo_correcciones(), _cell_text() (+25 more)

### Community 21 - "Archivado · Parches v13 (código muerto)"
Cohesion: 0.08
Nodes (5): CalculadorScore, create_resultado_control_v13(), DocumentoChunker, ReportadorEvaluacion, ValidadorInputs

### Community 22 - "Revisión de código · Juez anclado y hallazgos"
Cohesion: 0.05
Nodes (3): _aparece(), recategorizar(), TestJuezCodigoAnclado

### Community 23 - "IndexadorLexico"
Cohesion: 0.05
Nodes (5): verificar_ground_truth(), IndexadorLexico, IndiceLexico, TestRagLexicoSinEmbeddingsNiHuggingFace, TestIndexadoYPersistencia

### Community 24 - "Archivado · Generador Word antiguo (Mx_05)"
Cohesion: 0.13
Nodes (18): _add_run(), _cell_write(), GeneradorWord, generar_word_informe(), _heading(), _hrule(), _make_table(), _paragraph() (+10 more)

### Community 25 - "Web · Verificar conexiones y cuestionamientos"
Cohesion: 0.18
Nodes (11): borrar_custom(), get_estado(), add_custom(), _ahora(), _escribir(), _fichero(), get_estado(), get_for_prompt() (+3 more)

### Community 26 - "Web · Gestión de modelos (store y rutas)"
Cohesion: 0.09
Nodes (23): activar_modelo(), borrar_modelo(), crear_modelo(), desactivar(), listar_modelos(), modelo_activo(), NuevoModelo, _validador_logueado_o_401() (+15 more)

### Community 27 - "Archivado v28 · Herramientas SQL y pandas"
Cohesion: 0.07
Nodes (7): BaseTool, PandasTool, PlottingTool, RecommendationTool, RetrievalTool, SHAPTool, SQLTool

### Community 28 - "Motor · Lectura de evidencias (Mx_01)"
Cohesion: 0.07
Nodes (25): cargar_todos_inputs(), compilar_textos_de_carpeta(), detectar_manual_y_script(), _es_evidencia(), _extraer_outputs_celda(), guardar_parametros_ejecucion(), leer_archivo_generico(), leer_carpeta() (+17 more)

### Community 29 - "Seguridad · Cortacircuitos (fusibles)"
Cohesion: 0.10
Nodes (11): Cortacircuitos, CortacircuitosActivado, _Reloj, test_cap_de_iteraciones_corta_al_cuarto_intento(), test_cap_por_defecto_es_tres(), test_escalar_preserva_los_hallazgos_intermedios(), test_fusible_de_tiempo_corta_pasados_los_diez_segundos(), test_fusible_de_tokens_corta_pasados_los_veinte_mil() (+3 more)

### Community 30 - "get_prompt"
Cohesion: 0.21
Nodes (6): TestIntegracionCustom, TestPromptService, _armar_prompt(), clear_cache_para_tests(), get_prompt(), prompts_base()

### Community 31 - "Web · Rutas RAG y dominios personalizados"
Cohesion: 0.11
Nodes (19): _set(), test_indice_ausente_con_papers_es_desactualizado(), test_indice_mas_nuevo_esta_al_dia(), test_readme_y_dotfiles_no_cuentan(), test_source_mas_nuevo_marca_desactualizado(), borrar_dominio(), borrar_paper(), crear_dominio() (+11 more)

### Community 32 - "reglas_informe.py"
Cohesion: 0.09
Nodes (17): _barrido(), control_satisfactorio(), cumplimiento(), observaciones_por_control(), clave_ambito(), concluir(), conclusion_control(), _contar() (+9 more)

### Community 33 - "Solo Informe · Reglas de conclusión"
Cohesion: 0.10
Nodes (11): _o(), test_cumplimiento_por_ambito(), test_periodo_validacion(), test_validar_datos(), TestConcluir, TestControl, generar(), cumplimiento() (+3 more)

### Community 34 - "Automatizaciones · Cuadro de observaciones"
Cohesion: 0.06
Nodes (36): _campos_decision(), _json_laxo(), asignar_responsable(), _buscar_columna(), _celda(), construir_prompt(), _cuadro_determinista(), _es_fallo() (+28 more)

### Community 35 - "Prevuelo · Chequeo previo de evidencia"
Cohesion: 0.17
Nodes (3): _clasificar_fallo(), ejecutar_prevuelo(), TestPrevueloDeEvidencia

### Community 36 - "Web · Catálogo de skills"
Cohesion: 0.10
Nodes (16): borrar_custom(), crear_custom(), get_skills(), listar_defaults(), NuevoCustom, toggle(), ToggleDefault, add_custom() (+8 more)

### Community 37 - "Utilidades · Consola Unicode y scripts sueltos"
Cohesion: 0.09
Nodes (5): configurar_consola(), consola_soporta_unicode(), _forzar_codepage_utf8_windows(), _reconfigurar(), TestConsolaUnicode

### Community 38 - "Caché de documentos"
Cohesion: 0.10
Nodes (3): DocumentCache, inicializar_cache(), TestAuditoriaElCacheNoRecortaLoQueElChunkerDebeCubrir

### Community 39 - "comparar"
Cohesion: 0.17
Nodes (3): _cargar(), comparar(), TestComparacionEntreCorridas

### Community 40 - "test_versionado.py"
Cohesion: 0.09
Nodes (11): max_ctx_efectivo(), resolver_ventana(), _a_fecha(), chunk_activo(), filtrar_activos(), marcar_version(), _buscador(), _corpus() (+3 more)

### Community 41 - "Tests · Simulación de Azure (pipeline)"
Cohesion: 0.09
Nodes (7): cliente_azure(), respuesta_azure(), TestClienteAzureConstruyeBienLaPeticion, TestDeteccionAutomaticaDelDeployment, TestModosDeFalloDeAzure, TestNegociacionDelParametroDeTokens, TestPipeline1ExplicadorYRevisionConAzure

### Community 42 - "ContextCompressor"
Cohesion: 0.10
Nodes (3): ContextCompressor, ContextMemoryCompressor, ConversationSummarizer

### Community 43 - "Archivado v28 · Agente VIRF antiguo"
Cohesion: 0.11
Nodes (3): VIRFAgent, main(), test_flujo_completo()

### Community 44 - "ia.py"
Cohesion: 0.07
Nodes (14): _setup_env_si_falta(), cliente_dedicado(), ClienteAnthropicIA, ClienteIA, get_cliente_ia(), _instanciar(), metadatos_proveedor(), prueba_de_humo() (+6 more)

### Community 45 - "VIRF PLUS · Consenso entre dos modelos"
Cohesion: 0.10
Nodes (15): ClienteConsensoIA, comparar_respuestas(), _nombre_modelo(), _consenso(), Doble, sdk_openai_falso(), test_arbitro_claude_opcional(), test_arbitro_recibe_ambas_opiniones_y_discrepancias() (+7 more)

### Community 47 - "Web · Configuración y archivo .env"
Cohesion: 0.10
Nodes (16): ConfigModelo, ConfigProveedor, ConfigVirfPlus, _estado_virf_plus(), get_config(), _gpt_principal(), set_modelo(), set_proveedor() (+8 more)

### Community 48 - "test_pendientes_auditoria.py"
Cohesion: 0.16
Nodes (9): puntaje_por_tasa(), _chunks_del_dominio(), _elegible_r3(), evaluar(), evaluar_adversarias(), _fuentes_del_dominio(), informe(), main() (+1 more)

### Community 49 - "Web · Subida de archivos y ZIP"
Cohesion: 0.10
Nodes (14): arbol_inputs(), borrar_archivo(), _clasificar_estado(), listar_carpeta(), listar_destinos(), _nombre_seguro(), _serializar_dir(), subir_archivos() (+6 more)

### Community 50 - "verificar_emisiones"
Cohesion: 0.11
Nodes (4): _indexar_outputs(), leer_registro(), verificar_emisiones(), TestRegistroEmisiones

### Community 51 - "Web · Chat de validación"
Cohesion: 0.14
Nodes (18): a_dict(), _agregar(), _ahora(), _cargar_de_disco(), _emitir_pregunta(), _estados_para_sustentar(), _extraer_observaciones(), _fichero() (+10 more)

### Community 52 - "Solo Informe · Estándar, borrador e imágenes"
Cohesion: 0.11
Nodes (24): test_cargar_estandar_antiguo_se_rehace_desde_el_xlsx(), test_generar_exige_tier_si_el_estandar_lo_tiene(), test_imagen_rechaza_extension_y_id_invalido(), TestParser, borrar_estandar(), ver_imagen(), EstandarInvalido, base_de() (+16 more)

### Community 53 - "Revisión de código · Hallazgos"
Cohesion: 0.10
Nodes (5): HallazgoCodigo, _lenguaje_de(), _numerar_lineas(), RevisorCodigo, verificar_referencia_manual()

### Community 54 - "con_reintento"
Cohesion: 0.40
Nodes (3): con_reintento(), es_transitorio(), espera_sugerida()

### Community 55 - "Skills · Calidad de datos"
Cohesion: 0.10
Nodes (15): cargar_actividades_por_tier(), _limpiar_str(), DataLeakageResult, DataQualityResult, _ejecutar_en_sandbox(), _evaluar_leakage(), _main(), _outliers_iqr() (+7 more)

### Community 56 - "Skills · Catálogo y clase base"
Cohesion: 0.08
Nodes (8): _verificar_citas(), ResultadoSkill, SkillBase, listar_skills(), obtener_skill(), SkillGobierno, SkillPapers, ejecutar_skills()

### Community 57 - "Firma humana · Doble firma"
Cohesion: 0.07
Nodes (4): _normalizar_nombre(), requiere_doble_firma(), solicitar_segunda_firma(), TestDobleFirma

### Community 58 - "Web · Login y sesiones de validadores"
Cohesion: 0.13
Nodes (14): hacer_login(), hacer_logout(), Login, _ahora(), alta_validador(), _escribir_validadores(), formato_valido(), _leer_json() (+6 more)

### Community 59 - "Frontend · Pantalla de resultados"
Cohesion: 0.12
Nodes (18): abrirControles(), abrirResultados(), cablearResultados(), cablearTabs(), cargarCatalogoMotores(), cargarInforme(), cargarListaResultados(), cargarMotoresEntidad() (+10 more)

### Community 61 - "Archivado · Config monolítica antigua"
Cohesion: 0.08
Nodes (8): ClienteAnthropicIA, ClienteAzureOpenAIIA, ClienteIA, _detectar_key_en_example(), get_cliente_ia(), mostrar_configuracion(), reset_cliente_ia(), _validar_consistencia_modelo()

### Community 62 - "Salvaguardas · Entailment (LLM como juez)"
Cohesion: 0.11
Nodes (15): activo(), _na(), _parsear(), _prompt(), _subcadena_laxa(), verificar(), ClienteFake, test_apagado_por_defecto_devuelve_na() (+7 more)

### Community 64 - "Verificador VIRF · Paquete de verificación"
Cohesion: 0.17
Nodes (16): bloque_A(), bloque_B_C(), bloque_D(), bloque_E(), bloque_F(), bloque_G(), Coleccion, _commit() (+8 more)

### Community 65 - "Tests · Estructura de la configuración"
Cohesion: 0.10
Nodes (5): _codigo_vivo(), _ficheros_py(), TestAzureEsElProveedorPrioritario, TestMonolitoArchivadoNoSeImporta, TestPruebaDeHumoListaParaCredencial

### Community 66 - "Web · Edición de prompts"
Cohesion: 0.21
Nodes (7): BodyEditar, BodyRestaurar, editar(), get_base(), get_efectivos(), _password_o_403(), restaurar()

### Community 67 - "Salvaguardas · Enmascarado de PII"
Cohesion: 0.11
Nodes (17): contiene_pii(), _dni_nie_valido(), enmascarar(), _iban_valido(), _luhn_valido(), _sub_validado(), _rep(), test_correo_se_enmascara() (+9 more)

### Community 68 - "Frontend · Arranque, login y navegación"
Cohesion: 0.11
Nodes (39): abrirConfiguracion(), abrirModal(), abrirModalNuevoModelo(), alternarVirfPlus(), AMBITO_PESOS, arrancar(), cablearAuth(), cablearConfig() (+31 more)

### Community 69 - "Solo Informe · Router y endpoints"
Cohesion: 0.17
Nodes (17): DatosInforme, descargar(), estado(), guardar_borrador(), _ia(), ia_estado(), ia_grafico(), ia_manuales() (+9 more)

### Community 70 - "Aislamiento entre clientes (tenant)"
Cohesion: 0.15
Nodes (13): assert_sin_contaminacion(), ContaminacionModelo, etiquetar_chunk(), filtrar_por_tenant(), pertenece(), porcentaje_contaminacion(), _corpus_mixto(), test_conjunto_mixto_dispara_la_asercion() (+5 more)

### Community 71 - "Informe Markdown"
Cohesion: 0.10
Nodes (19): _bloque_citas(), _cabecera(), _como_leer(), _detalle(), _etiqueta_pj(), _firma_agente(), generar_informe_md(), _inconsistencias() (+11 more)

### Community 72 - "Motor IA · Scores y semáforo"
Cohesion: 0.10
Nodes (5): calcular_score_ambito(), calcular_score_global(), get_semaforo(), TestAuditoriaSinEvidenciaEsFaltaCriticaNoAusenciaDeDictamen, TestScores

### Community 73 - "Archivado · Generador Excel antiguo"
Cohesion: 0.16
Nodes (15): _align(), _border_all(), _border_medium(), _color_puntaje_celda(), _color_score(), _crear_hoja_ambito(), _crear_hoja_resumen(), _crear_hoja_tracking() (+7 more)

### Community 74 - "Skills tipadas · Documentación y gobierno"
Cohesion: 0.11
Nodes (9): AlcanceRubro, ResultadoAlcance, SkillTipada, SkillCalidadDatos, SkillDocumentacion, SkillGobierno, SkillImplementacion, SkillMetodologia (+1 more)

### Community 75 - "calidad_proceso"
Cohesion: 0.09
Nodes (4): autor_de(), identidad_para_feedback(), calidad_proceso(), TestAutoriaFeedback

### Community 76 - "Esquemas de datos (contratos)"
Cohesion: 0.22
Nodes (14): desde_dict(), intentar_validar(), validar_reporte(), _reporte_ok(), test_cita_ausente_falla(), test_confianza_fuera_de_rango_falla(), test_desviado_sin_codigo_falla(), test_dict_correcto_produce_reporte_valido() (+6 more)

### Community 77 - "Tests · Notebook de controles"
Cohesion: 0.13
Nodes (16): a_ipynb_bytes(), construir_notebook_8cols(), _normalizar_controles(), _ClienteFake, datasets_dir(), _ejecutar_notebook(), _meta(), test_csv_persistido() (+8 more)

### Community 78 - "solo_informe_ia.py"
Cohesion: 0.07
Nodes (42): test_azure_por_defecto_y_lo_que_falta(), test_azure_usa_deployment_propio_del_apartado(), test_busqueda_no_repite_bloques_de_plantilla(), test_clave_rechazada_da_mensaje_claro(), test_desde_manuales_cita_fuentes(), test_desde_manuales_sin_manuales(), test_grafico_barras_con_cifras_del_texto(), test_grafico_flujo() (+34 more)

### Community 80 - "Web · Pantalla Solo Informe (frontend)"
Cohesion: 0.15
Nodes (27): cablearSoloInforme(), cablearSoloInformeIA(), entrarASoloInforme(), siAccionIA(), siCargarIA(), siClaveAmbito(), siClaveRiesgo(), siControl() (+19 more)

### Community 81 - "Motor · Controles sobre datos (Mx_04)"
Cohesion: 0.11
Nodes (10): alertas_criticas(), calcular_riesgo_global(), convertir_resultado_data_a_texto(), ejecutar_control_unicidad(), ejecutar_motor_data_por_fila(), parsear_config_control(), parsear_lista_campos(), resumen_cuestionamientos_consola() (+2 more)

### Community 83 - "Motores de la entidad · Leer resultados"
Cohesion: 0.09
Nodes (14): _a_fraccion(), _escala_de_la_columna(), _leer_tabla(), _mapear_columnas(), _norm(), _numero(), _veredicto(), _normalizar() (+6 more)

### Community 84 - "Skills · Coherencia manual vs implementación"
Cohesion: 0.09
Nodes (3): SkillCoherencia, TestCoherenciaManualVsImplementacion, TestPuntajeNuloNoRompeNada

### Community 85 - "Abstención y calibración beta"
Cohesion: 0.14
Nodes (13): evaluar_abstencion(), _scores(), umbral_beta(), test_beta_por_defecto_solo_abstiene_ante_ausencia_total(), test_evidencia_fuerte_no_se_abstiene(), test_retrieval_debil_por_debajo_de_beta_se_abstiene(), test_scores_no_numericos_se_ignoran(), test_sin_fragmentos_se_abstiene() (+5 more)

### Community 87 - "Citas · Validación determinista"
Cohesion: 0.17
Nodes (14): extraer_ids(), id_de_chunk(), _ids_disponibles(), validar_afirmacion(), verificar_afirmaciones(), verificar_entailment(), _contexto(), test_agregado_alimenta_tasa_para_d4() (+6 more)

### Community 91 - "validate_project.py"
Cohesion: 0.32
Nodes (13): check(), main(), seccion(), val_cobertura_documentos(), val_codigo_muerto(), val_config(), val_dependencias(), val_estandar_y_evidencia() (+5 more)

### Community 92 - "feedback.py"
Cohesion: 0.11
Nodes (11): _escribir_json_atomico(), bucle_feedback_consola(), _bucle_feedback_interactivo(), guardar_historial(), _id_registro(), _leer(), _mostrar_resumen_evaluaciones(), _norm_act() (+3 more)

### Community 93 - "Tabla de validación y veredictos"
Cohesion: 0.12
Nodes (5): _umbral_env(), veredicto_actividad(), TestChatSeleccion, TestConstruirTabla, TestVeredictoActividad

### Community 94 - "Skills · Cola de acciones pendientes"
Cohesion: 0.15
Nodes (8): AccionPendiente, encolar_accion(), _leer(), listar_pendientes(), ruta_cola_por_defecto(), test_accion_de_impacto_queda_encolada_no_ejecutada(), test_el_modulo_no_expone_ninguna_via_de_ejecucion_directa(), test_varias_acciones_se_acumulan()

### Community 96 - "Frontend · Dominios RAG y documentación"
Cohesion: 0.13
Nodes (26): abrirDocumentar(), cablearCard(), cablearDocumentar(), escapeHtml(), fmtTs(), generarCuadro(), generarDocumentacion(), iconoEstado() (+18 more)

### Community 97 - "Frontend · Guía interactiva"
Cohesion: 0.23
Nodes (22): abrirGuia(), AYUDA, barraHtml(), botonQ(), cerrarGuia(), construirGuia(), dashboardVisible(), _e() (+14 more)

### Community 99 - "motores_datos.py"
Cohesion: 0.07
Nodes (22): _base(), cargar_datasets(), _cols(), describir_motores(), ejecutar_motor(), _estado_por_tasa(), _falta(), _motor_completitud() (+14 more)

### Community 100 - "Scripts · Reconstruir estándar y verificar corpus"
Cohesion: 0.22
Nodes (6): escribir(), extraer(), filas(), main(), _norm(), main()

### Community 101 - "Tests · Catálogo y detección de modelos"
Cohesion: 0.11
Nodes (3): ClienteAzureOpenAIIA, perfil_modelo(), TestCatalogoDeModelos

### Community 102 - "Análisis estático del código"
Cohesion: 0.13
Nodes (9): analizar_arbol(), analizar_modulo(), _codigo_de(), _contrastar_notebook(), _funciones_documentadas_ausentes(), _hechos(), _hechos_notebook(), _identificadores_en_manual() (+1 more)

### Community 104 - "Tests · SQL y R como código del modelo"
Cohesion: 0.10
Nodes (3): _partir_por_definiciones(), _sentencia_cerrada(), TestSqlYRSonCodigoDelModelo

### Community 105 - "leer_resultados"
Cohesion: 0.09
Nodes (4): _carpeta(), evaluaciones_desde_motores_entidad(), leer_resultados(), TestMotoresEntidad

### Community 106 - "informe_web.py"
Cohesion: 0.08
Nodes (24): citas_en_evidencia(), campo(), test_informe_docx_usa_el_cuadro_en_resumen_y_anexo(), test_informe_web_inserta_capturas(), leer_md(), a_plantilla(), conclusion_extra(), _captura_cita() (+16 more)

### Community 107 - "capturas.py"
Cohesion: 0.19
Nodes (14): captura_cita(), captura_codigo(), captura_portada(), _clave(), _fuente(), _leer(), _lineas_de(), localizar() (+6 more)

### Community 109 - "Archivado · Lector de inputs antiguo"
Cohesion: 0.15
Nodes (12): cargar_todos_los_inputs(), consolidar_contexto(), leer_archivo(), leer_csv(), leer_directorio(), leer_docx(), leer_json(), leer_pdf() (+4 more)

### Community 110 - "Fixtures · IFRS9 y VaR de demostración"
Cohesion: 0.09
Nodes (9): retornos_diarios(), var_cartera(), var_historico(), var_historico(), ajustar_forward_looking(), calcular_ecl(), clasificar_etapa(), var_historico() (+1 more)

### Community 114 - "leer_estandares_virf"
Cohesion: 0.06
Nodes (5): leer_estandares_virf(), _estandar_es_reconstruccion(), TestConfiguracion, TestElInformeDeclaraLaVersionDelEstandar, TestLectura

### Community 116 - "Web · Rutas de cuestionamientos"
Cohesion: 0.27
Nodes (8): agregar_personalizado(), borrar_personalizado(), _cuestionamientos_default(), _leer_json_seguro(), listar_default(), listar_personalizados(), toggle_default(), ToggleActivo

### Community 117 - "hash_contenido"
Cohesion: 0.17
Nodes (4): verificar_evidencia(), hash_archivo(), hash_contenido(), TestCumplimientoCadenaDeCustodia

### Community 118 - "Tests · Informe Word sin puntajes falsos"
Cohesion: 0.12
Nodes (3): _es_error(), _normalizar_score(), TestAuditoriaInformeWordNoDeformaLosDatos

### Community 119 - "solo_informe_word.py"
Cohesion: 0.10
Nodes (4): periodo_validacion(), docs(), _pdf(), nombre_fichero()

### Community 120 - "reporte_docx.py"
Cohesion: 0.13
Nodes (6): EstadoRequisito, ValidationReport, _agrupar_por_ambito(), _añadir_pie_con_paginacion(), _run_campo(), _run_texto()

### Community 121 - "Web · Descarga de resultados"
Cohesion: 0.11
Nodes (22): descargar_excel(), _leer_json(), listar_resultados(), _outputs(), _payload_tabla(), _resolver(), resultado_de_la_ultima_corrida(), resultado_por_ruta() (+14 more)

### Community 122 - "Archivado v28 · Challenger sin RAG"
Cohesion: 0.19
Nodes (3): ChallengerGenerator, generar_challenger_desde_hallazgos(), test_challenger_directo()

### Community 123 - "Archivado · Comparativa doc vs código"
Cohesion: 0.14
Nodes (8): comparar_doc_y_codigo(), extraer_clases_python(), extraer_funciones_python(), extraer_imports(), extraer_palabras_clave_doc(), extraer_seccion_docstring(), extraer_variables_globales(), generar_instruccion_implementacion_mejorada()

### Community 124 - "Chunker estructural"
Cohesion: 0.18
Nodes (11): _es_cerca(), _es_tabla(), segmentar_estructural(), _unidades(), test_bloque_atomico_mayor_que_el_tope_se_emite_entero(), test_ningun_segmento_corta_a_mitad_de_linea(), test_no_parte_la_formula_a_la_mitad(), test_no_parte_la_tabla_a_la_mitad() (+3 more)

### Community 125 - "Skills · Citas inventadas (challenger, supuestos)"
Cohesion: 0.11
Nodes (4): SkillChallenger, SkillDatos, SkillSupuestos, TestCitasInventadasEnSkills

### Community 131 - "Salvaguardas · Inyección de prompts"
Cohesion: 0.23
Nodes (10): contiene_inyeccion(), neutralizar(), _patrones(), test_anular_hallazgos_se_neutraliza(), test_forzar_puntaje_se_neutraliza(), test_ignorar_instrucciones_se_neutraliza(), test_marca_de_sistema_se_neutraliza(), test_nunca_lanza_y_es_idempotente() (+2 more)

### Community 132 - "Firma humana · Identidad del validador"
Cohesion: 0.17
Nodes (3): _leer(), solicitar_identidad(), TestCumplimientoFirmaValidador

### Community 133 - "generar"
Cohesion: 0.13
Nodes (12): _encabezado_pie(), _estilo_base(), _fld(), generar(), sec(), _hipervinculo(), _indice(), _logo() (+4 more)

### Community 134 - "Tests · Conexión Azure y parámetros"
Cohesion: 0.13
Nodes (4): _fabricar(), ClienteAzureFalso, _Completions, TestValidarConexionNegociaElParametroDeTokens

### Community 135 - "get_retriever"
Cohesion: 0.05
Nodes (17): _enriquecer_con_rag(), _rag_get_retriever(), _rag_resolver_dominio(), _cargar_dominios_custom(), dominios_conocidos(), get_retriever(), inferir_dominio(), resolver_dominio() (+9 more)

### Community 137 - "Web · Rutas del chat"
Cohesion: 0.16
Nodes (5): adjuntar_chat(), consolidar_chat(), descargar_acta_cierre(), estado_chat(), observaciones()

### Community 138 - "test_automatizaciones.py"
Cohesion: 0.12
Nodes (6): carpeta(), IAFalsa, _libro(), test_cuadro_con_ia_riesgo_desde_impactos(), test_ia_sin_json_falla_con_mensaje(), test_normalizar_riesgo()

### Community 139 - "Tests · Solo Informe (Word y endpoints)"
Cohesion: 0.21
Nodes (13): _datos(), _png(), test_ficha_del_documento(), test_flujo_endpoints(), test_generar_sin_estandar_o_con_errores(), test_word_estructura(), test_word_filtra_por_tier(), test_word_om_no_va_en_rojo_ni_lleva_responsable() (+5 more)

### Community 141 - "generador_estadistica_feedback.py"
Cohesion: 0.15
Nodes (10): modo_estadistica_feedback(), calcular_estadisticas(), _registros_utilizables(), _align(), _border(), _color_mae(), _color_pct(), _fill() (+2 more)

### Community 143 - "Exportador Excel"
Cohesion: 0.26
Nodes (7): a_bytes(), _aplica(), construir_libro(), _norm_act(), _tabla(), test_final_incluye_puntaje_validado(), test_xlsx_valido_con_8_columnas_y_aplica()

### Community 144 - "generar_word_informe"
Cohesion: 0.10
Nodes (9): _add_hallazgos_cdd(), _generar_recomendacion_automatica(), generar_word_informe(), conclusion_extra(), detalle_control(), escala(), _procedencia_nota(), linea_independencia() (+1 more)

### Community 145 - "perfilar_dataframe"
Cohesion: 0.13
Nodes (5): _describir_rango(), _intentar_fechas(), perfilar_dataframe(), PerfilColumna, PerfilDataset

### Community 146 - "Tests · DOCX de regresión"
Cohesion: 0.28
Nodes (10): generar_docx_validacion(), veredicto_de_ambito(), _reporte_mock(), test_abstencion_se_declara_en_el_docx(), test_genera_docx_con_veredictos_por_ambito(), test_pie_con_paginacion_tiene_campo_page(), test_seccion_referencias_consolidada(), test_seccion_sin_observaciones() (+2 more)

### Community 148 - "Tests · Skills tipadas"
Cohesion: 0.10
Nodes (8): DeclaracionHerramienta, declaraciones_herramientas(), test_cada_skill_expone_declaracion_de_herramienta_valida(), test_consulta_fuera_de_alcance_dispara_abstencion_o_derivacion(), test_declaraciones_para_tools_es_serializable_json(), test_rubro_se_resuelve_desde_config_no_hardcode(), test_skills_no_operativas_declaran_pendiente_api(), test_una_skill_nunca_opina_del_dominio_de_otra()

### Community 155 - "Frontend · Navegación y vistas"
Cohesion: 0.13
Nodes (20): abrirDominioRag(), abrirModalPasswd(), abrirSkills(), analizarCodigo(), cablearCrearDominio(), cablearEntendimiento(), cablearNav(), cablearVisorPrompt() (+12 more)

### Community 157 - "Tests · Subida ZIP (límites)"
Cohesion: 0.35
Nodes (9): ctx(), _extraidos(), _subir(), test_demasiadas_entradas_413(), test_tamano_declarado_excesivo_413(), test_zip_bomba_upload_pequeno_expansion_grande(), test_zip_normal_se_extrae(), test_zip_slip_rechazado() (+1 more)

### Community 158 - "columns"
Cohesion: 0.14
Nodes (5): control(), control(), control(), control(), columns()

### Community 159 - "Tests · Borrado del caché"
Cohesion: 0.16
Nodes (3): TestAuditoriaBorrarDelCacheBorraDeVerdad, TestCache, escribir()

### Community 160 - "verificar_cadena"
Cohesion: 0.16
Nodes (6): _hash_cadena(), informes_de_modelo(), preservar_si_existe(), sellar(), verificar_cadena(), TestCustodiaVariasCorridasElMismoDia

### Community 161 - "Tests · Consolidación"
Cohesion: 0.42
Nodes (3): _datos(), _fn(), TestConsolidar

### Community 163 - "es_de_entorno_virtual"
Cohesion: 0.07
Nodes (10): es_de_entorno_virtual(), _es_entorno(), _entorno_falso(), test_codigo_del_proyecto_no_se_confunde_con_entorno(), test_entorno_con_nombre_arbitrario_se_reconoce(), test_site_packages_se_reconoce(), TestAuditoriaConsistenciaCruzada, dfs() (+2 more)

### Community 165 - "sha256_texto"
Cohesion: 0.13
Nodes (3): huella_plantilla_prompts(), sha256_texto(), TestTrazabilidadDelPrompt

### Community 167 - "Tests · Filtro de contenido Azure"
Cohesion: 0.17
Nodes (3): _diagnostico_filtro(), _extraer_categorias(), TestAuditoriaEntornoCorporativo

### Community 169 - "Controles · Repositorio por dominio"
Cohesion: 0.18
Nodes (5): generar_controles_desde_entendimiento(), generar_ipynb_controles(), cargar_controles(), carpeta_de_dominio(), _extraer_meta()

### Community 170 - "TestAuditoriaHistorialSucioNoTumbaLasEstadisticas"
Cohesion: 0.13
Nodes (4): _evaluacion_invalida(), _validar_contrato_evaluacion(), TestAuditoriaHistorialSucioNoTumbaLasEstadisticas, TestContrato

### Community 174 - "Frontend · Chat"
Cohesion: 0.24
Nodes (13): abrirChat(), adjuntarEvidenciaChat(), cablearChat(), cargarListaInformesChat(), conectarChatWS(), consolidarChat(), descargarActaCierre(), enviarChat() (+5 more)

### Community 177 - "Archivado v28 · Demo challenger"
Cohesion: 0.23
Nodes (5): ejecutar_escenario(), ejecutar_personalizado(), main(), mostrar_encabezado(), mostrar_menu()

### Community 178 - "Consolidación de decisiones"
Cohesion: 0.29
Nodes (5): consolidar_decisiones(), _indexar_decisiones(), _norm(), tabla_final(), valor_cumple()

### Community 181 - "Web · Presupuesto de prompts"
Cohesion: 0.23
Nodes (4): TestPresupuestoService, _construir_env_hijo(), aplicar_env(), calcular()

### Community 182 - "analizar"
Cohesion: 0.16
Nodes (9): analizar(), Feedback, feedback(), obtener(), agregar_feedback(), generar_entendimiento(), leer_feedbacks(), _mock_entendimiento() (+1 more)

### Community 183 - "prompt_service.py"
Cohesion: 0.28
Nodes (9): _ahora(), _cargar_base(), editar_prompt(), _escribir_custom(), _leer_custom(), _placeholders_en(), prompts_efectivos(), restaurar_prompt() (+1 more)

### Community 184 - "typing"
Cohesion: 0.03
Nodes (22): exportar_informe_word(), agrupar_por_ambito(), EstadoEvaluacion, _normalizar(), _firma(), _norm(), _leer(), _valida_regex() (+14 more)

### Community 191 - "parametros.py"
Cohesion: 0.11
Nodes (9): precio_entrada_por_mtok(), _booleano(), _decimal(), identidad_segundo_validador_entorno(), identidad_validador_entorno(), _num_env(), tiers_doble_firma(), _excluir_dependencias_activo() (+1 more)

### Community 193 - "orquestar_pipeline_ambitos"
Cohesion: 0.19
Nodes (7): _evaluar_actividad_thread_safe(), evaluar_ambito_paralelo(), evaluar_todos_ambitos_paralelo(), _evaluar_un_ambito(), orquestar_pipeline_ambitos(), _rag_inferir_dominio(), inputs_para_dimension()

### Community 194 - "comparador.py"
Cohesion: 0.20
Nodes (6): CambioActividad, Comparacion, _flecha(), formatear(), _indice_actividades(), _num()

### Community 199 - "Frontend · Cuestionamientos y skills"
Cohesion: 0.22
Nodes (19): abrirCuestionamientos(), agregarCuestCustom(), agregarSkillCustom(), borrarDominio(), borrarPaperRag(), cablearCuestionamientos(), cablearRagDominio(), cargarCuestionamientos() (+11 more)

### Community 203 - "override_humano.py"
Cohesion: 0.18
Nodes (7): cargar_historial(), construir_contexto_feedback(), _mismo_modelo(), _orden_sesion(), overrides_de_modelo(), _sesion(), ultimo_ciclo()

### Community 204 - "catalogo_activo"
Cohesion: 0.22
Nodes (4): catalogo_activo(), _traducir_personalizado(), _catalogo_para_deteccion(), detectar_cuestionamientos()

### Community 205 - "Acta de cierre (Excel)"
Cohesion: 0.40
Nodes (7): acta_cierre_bytes(), test_acta_hoja_decisiones_lista_cada_veredicto(), test_acta_marca_decision_en_filas_cambiadas(), test_acta_resumen_puntaje_sube_con_aprobado(), test_acta_tiene_tres_hojas_y_columnas(), test_endpoint_acta_descarga_xlsx(), _wb()

### Community 206 - "Tests · Aprendizaje desde el chat"
Cohesion: 0.29
Nodes (6): _datos(), feedback_aislado(), test_aprobado_se_guarda_como_correccion(), test_idempotente_por_sesion(), test_la_correccion_entra_como_contexto_futuro(), test_pendiente_no_se_aprende()

### Community 208 - "Chat · Adjuntar evidencia"
Cohesion: 0.33
Nodes (7): _ctx(), _datos(), test_adjuntar_enriquece_evidencia_y_reevalua(), test_adjuntar_sin_texto_falla(), _correr(), adjuntar_evidencia(), clear_todo()

### Community 209 - "TestAuditoriaRagNoIndexaLaEvidenciaQueEvalua"
Cohesion: 0.16
Nodes (3): raiz_proyecto(), ruta_indice(), TestAuditoriaRagNoIndexaLaEvidenciaQueEvalua

### Community 213 - "build_agent"
Cohesion: 0.08
Nodes (5): ConfidenceScorer, GroundingChecker, HallucinationChecker, ResponseEvaluator, build_agent()

### Community 214 - "resumen_override"
Cohesion: 0.20
Nodes (3): cargo_de(), resumen_override(), TestCumplimientoAnexoOverride

### Community 215 - "Fixtures · Modelo sintético Fraude/AML"
Cohesion: 0.22
Nodes (3): aplicar_reglas(), generar_alertas(), score_anomalia()

### Community 217 - "Motor · Llamada IA con contrato JSON"
Cohesion: 0.20
Nodes (3): llamar_ia_json(), _crop_to_json(), _validar_contrato()

### Community 219 - "Frontend · Estándares"
Cohesion: 0.33
Nodes (9): abrirEstandares(), aceptarEstandares(), cablearEstandares(), cambiarArchivoEstandares(), pintarEstandaresConfirmado(), pintarPreviewEstandares(), resetEstandaresUI(), subirEstandares() (+1 more)

### Community 221 - "Análisis estático · Contraste doc vs código"
Cohesion: 0.29
Nodes (3): _contrastar(), _norm(), _numero_en_texto()

### Community 226 - "Tests · Respuesta vacía del modelo"
Cohesion: 0.36
Nodes (3): TestAuditoriaRespuestaVaciaDeLaAPI, _BloqueSinTexto, _RespuestaVacia

### Community 231 - "Scripts · Verificación del corpus RAG"
Cohesion: 0.29
Nodes (5): _ficheros_esperados(), main(), _norm(), verificar_dominio(), verificar_informe()

### Community 233 - "Frontend · Lanzar validación"
Cohesion: 0.46
Nodes (8): actualizarEstadoUI(), cablearValidacion(), cancelarValidacion(), conectarWebSocket(), lanzarValidacion(), pintarLinea(), pintarPrecondiciones(), precondicionesValidacion()

### Community 236 - "Prevuelo · Hallazgos e informe"
Cohesion: 0.24
Nodes (3): formatear(), Hallazgo, InformePrevuelo

### Community 239 - "estructura"
Cohesion: 0.29
Nodes (6): _analizar_generico(), _analizar_ipynb(), _analizar_py(), estructura(), guardar_md(), ruta_md()

### Community 241 - "test_endpoint_notebook_controles.py"
Cohesion: 0.23
Nodes (4): _get_notebook(), make_ctx(), test_endpoint_fallback_llm_sin_repositorio(), test_endpoint_repositorio_dominio()

### Community 243 - "orquestar_pipeline_virf"
Cohesion: 0.15
Nodes (4): evaluar_todos_controles(), generar_informe_final(), orquestar_pipeline_virf(), TestLosDosPipelinesSeComportanIgual

### Community 246 - "perfilar_carpeta"
Cohesion: 0.24
Nodes (4): documento_perfil(), perfilar_carpeta(), perfilar_datasets(), TestPerfiladorDatasets

### Community 259 - "test_plantilla_bcp.py"
Cohesion: 0.29
Nodes (7): _esqueleto_ok(), _sesion_chat(), test_entregable_pipeline_con_plantilla(), test_informe_web_con_plantilla(), test_plantilla_minima_y_anexos(), _texto(), Mensaje

### Community 286 - "test_regresion.py"
Cohesion: 0.08
Nodes (6): _entero(), TestAuditoriaCoberturaDeControlNoUsaMaximo, TestAuditoriaEnvMalformadoNoTumbaElArranque, TestAuditoriaImportLocalNoEnsombreceAlGlobal, TestAuditoriaVolcadoDebugNoSeEscapa, TestSalidas

### Community 287 - "ClienteOpenAIIA"
Cohesion: 0.22
Nodes (4): ClienteOpenAIIA, _detectar_key_en_example(), test_openai_exige_api_key(), test_openai_reutiliza_negociacion_de_azure()

### Community 288 - "Tests · Modelo simulado de Solo Informe"
Cohesion: 0.25
Nodes (4): cliente(), cliente(), llm(), base_solo_informe()

### Community 290 - "preguntas_oro_formula.py"
Cohesion: 0.31
Nodes (4): _buscadores(), evaluar_chunker(), _ndcg(), norm()

### Community 291 - "notebook_controles.py"
Cohesion: 0.33
Nodes (5): _code(), _codigo_control(), construir_notebook_controles(), _md(), construir_notebook_repositorio()

### Community 306 - "val_sin_huggingface"
Cohesion: 0.24
Nodes (4): test_paquete_ausente_no_se_reporta(), test_paquete_instalado_pero_roto_se_reporta(), _es_de_entorno_virtual(), val_sin_huggingface()

### Community 307 - "implementacion_PD_Retail.py"
Cohesion: 0.27
Nodes (4): aplicar_woe(), calcular_score(), decidir(), ejecutar()

### Community 313 - "val_cumplimiento_regulatorio"
Cohesion: 0.25
Nodes (4): _es_ambito_metodologia(), IdentidadRequerida, SegundaFirmaRequerida, val_cumplimiento_regulatorio()

### Community 319 - "leer_archivo"
Cohesion: 0.33
Nodes (3): get_cache(), get_cache(), leer_archivo()

## Knowledge Gaps
- **162 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `IndexadorLexico` connect `IndexadorLexico` to `preguntas_oro_formula.py`, `es_de_entorno_virtual`, `Tests · Índice RAG sin contaminación`, `Scripts · Verificación del corpus RAG`, `Tests · RAG léxico (recuperación)`, `RAG · Indexadores por dominio y reconstrucción`, `BuscadorLexico`, `Agente · Punto de entrada y cliente IA`, `Tests · Simulación de Azure (pipeline)`, `test_versionado.py`, `test_pendientes_auditoria.py`, `Chunker · Troceado de documentos`, `._motor`, `typing`, `test_regresion.py`?**
  _High betweenness centrality (0.023) - this node is a cross-community bridge._
- **Are the 8 inferred relationships involving `main()` (e.g. with `diagnostico_https()` and `.generar()`) actually correct?**
  _`main()` has 8 INFERRED edges - model-reasoned connections that need verification._
- **Should `.get_conversation_history` be split into smaller, more focused modules?**
  _Cohesion score 0.10591133004926108 - nodes in this community are weakly interconnected._
- **Why does `columns()` connect `columns` to `Control VaR · Kupiec`, `Control VaR · Semáforo de Basilea`, `Control ALM · Backtesting de prepago`, `Control ALM · Beta de depósitos`, `Control ALM · Brecha de duración`, `Control ALM · CPR de prepago`, `Control ALM · Decaimiento NMD`, `Control ALM · Sensibilidad NII`, `Control ALM · Escenarios IRRBB`, `Control ALM · Gap de reprecios`, `Control ALM · Vida media NMD`, `Control LaR · Brecha de liquidez`, `Control LaR · Concentración de fondeo`, `Control LaR · Horizonte de supervivencia`, `Control LaR · Composición HQLA`, `Control LaR · LCR`, `Control LaR · NSFR`, `Control transversal · Columnas constantes`, `perfilar_dataframe`, `Control transversal · Frescura`, `Control VaR · Excedencias`, `Control VaR · Severidad de excepciones`, `Control VaR · VaR negativos`?**
  _High betweenness centrality (0.022) - this node is a cross-community bridge._
- **Should `app.py` be split into smaller, more focused modules?**
  _Cohesion score 0.040313549832026875 - nodes in this community are weakly interconnected._
- **Why does `leer_resultados()` connect `leer_resultados` to `app.py`, `motores_datos.py`, `Agente · Punto de entrada y cliente IA`, `test_pendientes_auditoria.py`, `Motores de la entidad · Leer resultados`?**
  _High betweenness centrality (0.021) - this node is a cross-community bridge._
- **Should `Datos · Pipeline de calidad de datos` be split into smaller, more focused modules?**
  _Cohesion score 0.07563025210084033 - nodes in this community are weakly interconnected._