# -*- coding: utf-8 -*-
"""
tests/test_deteccion_proveedor.py — basta con poner la clave (2026-11-11).

Fija tres cosas, todas con dobles (coste 0, sin red):

  1. Fuera de producción el proveedor se deduce de la clave presente, y Claude y
     OpenAI directo pueden ejecutarse para pruebas. En producción NADA de esto
     aplica: rige la lista cerrada del banco (tests/test_proveedores_ia.py).
  2. Cambiar la clave reconstruye el cliente solo; un fallo en ejecución NO
     salta a otro proveedor.
  3. VIRF PLUS (los dos a la vez) sigue siendo un flag explícito y no se cae por
     un fallo del árbitro, pero nunca concluye con un solo evaluador.
"""
from __future__ import annotations

import json

import pytest

import config.ia as ia
import config.parametros as par
from config import virf_plus as vp
from config.virf_plus import ClienteConsensoIA, comparar_respuestas

CLAVE = "clave-simulada-" + "k" * 30


class Doble(ia.ClienteIA):
    PROVEEDOR = "azure_openai"

    def __init__(self, nombre="doble", respuesta="ok", falla=False):
        self.modelo = nombre
        self.respuesta = respuesta
        self.falla = falla
        self.llamadas = []

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                        sistema=None, formato_json=False):
        self.llamadas.append(prompt)
        if self.falla:
            raise RuntimeError("503 servicio caído")
        return self.respuesta(prompt) if callable(self.respuesta) else self.respuesta

    def validar_conexion(self):
        return not self.falla


@pytest.fixture(autouse=True)
def _limpio(monkeypatch):
    """Sin credenciales ni preferencias heredadas; caché y avisos a cero."""
    for var in ("AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT", "VIRF_PLUS"):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.setattr(ia, "IA_PROVEEDOR", "azure_openai")
    monkeypatch.setattr(vp, "VIRF_PLUS_GPT", "azure_openai")
    monkeypatch.setattr(ia, "_AVISOS_DETECCION", set())
    monkeypatch.setattr(ia, "_AVISADOS_DESARROLLO", set())
    ia.reset_cliente_ia()
    yield
    ia.reset_cliente_ia()


@pytest.fixture
def fabricas(monkeypatch):
    """Sustituye los tres clientes reales por dobles que recuerdan su proveedor."""
    construidos = []

    def _fabrica(prov):
        def _crear():
            cli = Doble(nombre=f"modelo-{prov}", respuesta=f"respuesta de {prov}")
            cli.proveedor_simulado = prov
            construidos.append(prov)
            return cli
        return _crear
    for prov in ("azure_openai", "openai", "anthropic"):
        monkeypatch.setitem(ia.FABRICAS, prov, _fabrica(prov))
    return construidos


def _azure(monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", CLAVE)
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://recurso.openai.azure.com/")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt-despliegue")


def _produccion(monkeypatch):
    monkeypatch.setattr(par, "MODO", "produccion")


# ── 1. Autorización: desarrollo sí, producción no ────────────────────────────

@pytest.mark.parametrize("prov", ["anthropic", "openai"])
def test_en_desarrollo_claude_y_openai_pueden_ejecutarse(prov):
    assert ia.estado_efectivo(prov) == "SOLO_DESARROLLO"
    ia.autorizar_proveedor(prov)                       # no lanza
    assert prov in ia.proveedores_autorizados()


@pytest.mark.parametrize("prov, estado", [("anthropic", "EN_ESPERA"), ("openai", "RETIRADO")])
def test_en_produccion_la_lista_del_banco_no_cambia(prov, estado, monkeypatch):
    _produccion(monkeypatch)
    assert ia.estado_efectivo(prov) == estado
    assert ia.proveedores_autorizados() == ["azure_openai"]
    with pytest.raises(ia.ProveedorNoAutorizado, match=estado):
        ia.autorizar_proveedor(prov)


@pytest.mark.parametrize("modo", ["", "prod", "PRODUCCION", "staging", "cualquier-cosa"])
def test_un_modo_desconocido_cuenta_como_produccion(modo, monkeypatch):
    """Falla cerrado: solo MODO=debug|desarrollo abre los proveedores en evaluación."""
    monkeypatch.setattr(par, "MODO", modo)
    assert not ia.proveedor_autorizado("anthropic")


def test_un_proveedor_no_catalogado_no_se_abre_nunca():
    assert ia.estado_efectivo("gemini") == "NO_CATALOGADO"
    with pytest.raises(ia.ProveedorNoAutorizado):
        ia.autorizar_proveedor("gemini")


def test_la_lista_cerrada_del_banco_sigue_intacta():
    assert ia.PROVEEDORES == {"azure_openai": "APROBADO", "anthropic": "EN_ESPERA",
                              "openai": "RETIRADO"}


# ── 2. Detección por clave ───────────────────────────────────────────────────

def test_solo_la_clave_de_claude_usa_claude(monkeypatch, fabricas):
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    assert ia.proveedor_activo() == "anthropic"
    assert ia.get_cliente_ia().proveedor_simulado == "anthropic"
    assert fabricas == ["anthropic"]
    assert ia.metadatos_proveedor()["nombre"] == "Anthropic"


def test_solo_la_clave_de_openai_usa_openai(monkeypatch, fabricas):
    monkeypatch.setenv("OPENAI_API_KEY", CLAVE)
    assert ia.proveedor_activo() == "openai"
    assert ia.get_cliente_ia().proveedor_simulado == "openai"


def test_solo_azure_completo_usa_azure(monkeypatch, fabricas):
    _azure(monkeypatch)
    assert ia.proveedor_activo() == "azure_openai"
    assert ia.get_cliente_ia().proveedor_simulado == "azure_openai"


def test_con_gpt_y_claude_gana_gpt_y_no_se_enciende_virf_plus(monkeypatch, fabricas):
    _azure(monkeypatch)
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    assert ia.proveedor_activo() == "azure_openai"
    assert not ia.virf_plus_activo()
    assert ia.get_cliente_ia().proveedor_simulado == "azure_openai"
    assert fabricas == ["azure_openai"], "con dos claves solo se construye el principal"


def test_lo_declarado_manda_si_tiene_clave(monkeypatch, fabricas):
    _azure(monkeypatch)
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    monkeypatch.setattr(ia, "IA_PROVEEDOR", "anthropic")
    assert ia.proveedor_activo() == "anthropic"


def test_declarado_sin_clave_cede_al_que_la_tiene(monkeypatch, fabricas, capsys):
    """El caso que obligaba a tocar IA_PROVEEDOR a mano."""
    monkeypatch.setattr(ia, "IA_PROVEEDOR", "anthropic")
    _azure(monkeypatch)
    assert ia.proveedor_activo() == "azure_openai"
    assert "detectado por la clave presente" in capsys.readouterr().out


def test_azure_a_medias_no_cuenta_como_presente(monkeypatch, fabricas):
    """Clave de Azure sin endpoint ni deployment: no gana a un Claude completo."""
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", CLAVE)
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    assert ia.proveedor_activo() == "anthropic"


@pytest.mark.parametrize("clave", ["", "TU_API_KEY_AQUI", "xxx", "placeholder-123"])
def test_un_placeholder_no_es_una_clave(clave, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", clave)
    assert not ia._credenciales_completas("anthropic")
    assert ia.proveedor_activo() == "azure_openai"     # el declarado, que dirá qué falta


def test_sin_ninguna_clave_el_error_es_del_proveedor_declarado():
    with pytest.raises(ValueError, match="AZURE_OPENAI_API_KEY"):
        ia.get_cliente_ia(forzar_recarga=True)


def test_en_produccion_no_se_deduce_nada(monkeypatch):
    """Con la clave de Claude a mano, producción sigue en Azure y Claude bloqueado."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    _produccion(monkeypatch)
    assert ia.proveedor_activo() == "azure_openai"
    monkeypatch.setattr(ia, "IA_PROVEEDOR", "anthropic")
    assert ia.proveedor_activo() == "anthropic"
    with pytest.raises(ia.ProveedorNoAutorizado, match="EN_ESPERA"):
        ia.get_cliente_ia(forzar_recarga=True)


def _clave_en_env(monkeypatch, tmp_path):
    import config.secretos as sec
    env = tmp_path / ".env"
    env.write_text(f"ANTHROPIC_API_KEY={CLAVE}\n", encoding="utf-8")
    monkeypatch.setattr(sec, "RUTA_ENV", env)
    monkeypatch.setattr(sec, "_AVISADAS_EN_ENV", set())
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)      # lo que hace load_dotenv


def test_en_debug_basta_con_editar_la_clave_del_env(monkeypatch, tmp_path, capsys, fabricas):
    """Sin VIRF_FUENTE_SECRETOS ni IA_PROVEEDOR alineados: solo la clave en el .env."""
    monkeypatch.delenv("VIRF_FUENTE_SECRETOS", raising=False)
    _clave_en_env(monkeypatch, tmp_path)
    assert ia.proveedor_activo() == "anthropic"
    assert ia.get_cliente_ia().proveedor_simulado == "anthropic"
    assert "texto plano" in capsys.readouterr().out


def test_fuera_de_debug_la_clave_del_env_se_avisa_y_no_se_usa(monkeypatch, tmp_path):
    """[SEG-03] En un modo que no es de desarrollo el .env no es fuente de claves."""
    import config.secretos as sec
    monkeypatch.setattr(par, "MODO", "ci")
    _clave_en_env(monkeypatch, tmp_path)
    with pytest.raises(sec.SecretoEnTextoPlano):
        sec.obtener_secreto("ANTHROPIC_API_KEY")
    assert not ia._credenciales_completas("anthropic")


# ── 3. Cambiar la clave, sin reiniciar ni tocar nada más ─────────────────────

def test_cambiar_la_clave_reconstruye_el_cliente(monkeypatch, fabricas):
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    primero = ia.get_cliente_ia()
    assert ia.get_cliente_ia() is primero              # misma clave → caché
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE + "-rotada")
    segundo = ia.get_cliente_ia()
    assert segundo is not primero and fabricas == ["anthropic", "anthropic"]


def test_cambiar_de_claude_a_gpt_cambia_de_proveedor(monkeypatch, fabricas):
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    assert ia.get_cliente_ia().proveedor_simulado == "anthropic"
    monkeypatch.setenv("ANTHROPIC_API_KEY", "")
    monkeypatch.setenv("OPENAI_API_KEY", CLAVE)
    assert ia.get_cliente_ia().proveedor_simulado == "openai"
    assert ia.modelo_activo() == "modelo-openai"


def test_un_fallo_en_ejecucion_no_salta_a_otro_proveedor(monkeypatch):
    """Elegir proveedor al arrancar no es un plan B: si GPT falla con Claude
    también configurado, la llamada falla y Claude no recibe nada."""
    claude = Doble("claude")
    monkeypatch.setitem(ia.FABRICAS, "azure_openai", lambda: Doble("gpt", falla=True))
    monkeypatch.setitem(ia.FABRICAS, "anthropic", lambda: claude)
    _azure(monkeypatch)
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    cli = ia.get_cliente_ia()
    with pytest.raises(RuntimeError, match="503"):
        cli.generar_mensaje(prompt="evalúa")
    assert claude.llamadas == []


# ── 4. VIRF PLUS: los dos a la vez ───────────────────────────────────────────

def _consenso(tmp_path, gpt, claude, **kw):
    return ClienteConsensoIA(claude=claude, gpt=gpt, ruta_log=tmp_path / "log.jsonl", **kw)


def test_virf_plus_arranca_en_desarrollo_con_las_dos_claves(monkeypatch, fabricas):
    _azure(monkeypatch)
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    monkeypatch.setenv("VIRF_PLUS", "1")
    cli = ia.get_cliente_ia()
    assert isinstance(cli, ClienteConsensoIA)
    assert sorted(fabricas) == ["anthropic", "azure_openai"]
    assert ia.get_cliente_ia() is cli


def test_virf_plus_usa_el_gpt_que_tenga_clave(monkeypatch, fabricas):
    """VIRF_PLUS_GPT=azure_openai (defecto) pero solo hay clave de OpenAI."""
    monkeypatch.setenv("OPENAI_API_KEY", CLAVE)
    monkeypatch.setenv("ANTHROPIC_API_KEY", CLAVE)
    assert vp.proveedor_gpt() == "openai"
    monkeypatch.setenv("VIRF_PLUS", "1")
    cli = ia.get_cliente_ia()
    assert cli.gpt.proveedor_simulado == "openai"


def test_virf_plus_con_una_sola_clave_dice_cual_falta(monkeypatch):
    _azure(monkeypatch)
    monkeypatch.setenv("VIRF_PLUS", "1")
    monkeypatch.setitem(ia.FABRICAS, "azure_openai", lambda: Doble("gpt"))
    with pytest.raises(ValueError) as exc:
        ia.get_cliente_ia(forzar_recarga=True)
    msg = str(exc.value)
    assert "DOS evaluadores" in msg and "ANTHROPIC_API_KEY" in msg and "VIRF_PLUS=0" in msg


def test_virf_plus_sigue_bloqueado_en_produccion(monkeypatch, tmp_path):
    _produccion(monkeypatch)
    with pytest.raises(ia.ProveedorNoAutorizado, match="VIRF PLUS bloqueado"):
        _consenso(tmp_path, Doble("gpt"), Doble("claude"))


@pytest.mark.parametrize("kw", [{"arbitro": "gemini"}, {"arbitraje": "aveces"}])
def test_virf_plus_rechaza_configuracion_mal_escrita(kw, tmp_path):
    with pytest.raises(ValueError, match="no es válido"):
        _consenso(tmp_path, Doble("gpt"), Doble("claude"), **kw)


def test_puntajes_3_y_3_0_no_son_una_discrepancia():
    c = comparar_respuestas('{"puntaje": 3}', '{"puntaje": 3.0}')
    assert c["acuerdo"] and c["discrepancias"] == {}
    c = comparar_respuestas('{"puntaje": "4"}', '{"puntaje": 4}')
    assert c["acuerdo"]
    assert not comparar_respuestas('{"puntaje": 3}', '{"puntaje": 2}')["acuerdo"]


def test_si_el_arbitro_falla_gana_la_opinion_mas_conservadora(tmp_path, capsys):
    a = '{"puntaje": 4, "observacion": "sólido"}'
    b = '{"puntaje": 2, "observacion": "falta Kupiec"}'

    def gpt(prompt):
        if "RESPUESTA DEL EVALUADOR A" in prompt:
            raise RuntimeError("429 cuota agotada")
        return a
    cli = _consenso(tmp_path, Doble("gpt", gpt), Doble("claude", b))
    final = cli.generar_mensaje("evalúa", formato_json=True)
    assert json.loads(final)["puntaje"] == 2
    reg = cli.ultimo_consenso
    assert reg["resolucion"] == "conservadora_por_fallo_del_arbitro"
    assert reg["arbitrado"] is False and "429" in reg["error_arbitro"]
    assert cli.resumen()["sin_arbitro_por_fallo"] == 1
    assert "MÁS CONSERVADORA" in capsys.readouterr().out
    en_disco = json.loads((tmp_path / "log.jsonl").read_text(encoding="utf-8").splitlines()[-1])
    assert en_disco["resolucion"] == "conservadora_por_fallo_del_arbitro"


def test_si_el_arbitro_no_devuelve_json_no_rompe_el_contrato(tmp_path):
    a = '{"puntaje": 3, "observacion": "a"}'
    b = '{"puntaje": 3, "observacion": "b"}'

    def gpt(prompt):
        return "Ambos coinciden, me parece bien." if "EVALUADOR A" in prompt else a
    cli = _consenso(tmp_path, Doble("gpt", gpt), Doble("claude", b))
    final = cli.generar_mensaje("evalúa", formato_json=True)
    assert json.loads(final) == json.loads(a)          # empate → agente principal
    assert cli.ultimo_consenso["resolucion"] == "conservadora_por_fallo_del_arbitro"


def test_arbitro_sano_sigue_decidiendo(tmp_path):
    def gpt(prompt):
        return '{"puntaje": 2, "observacion": "conciliado"}' if "EVALUADOR A" in prompt \
            else '{"puntaje": 3}'
    cli = _consenso(tmp_path, Doble("gpt", gpt), Doble("claude", '{"puntaje": 2}'))
    assert json.loads(cli.generar_mensaje("evalúa"))["observacion"] == "conciliado"
    assert cli.ultimo_consenso["resolucion"] == "arbitro"


@pytest.mark.parametrize("falla_gpt, falla_claude", [(True, False), (False, True)])
def test_nunca_se_concluye_con_un_solo_evaluador(falla_gpt, falla_claude, tmp_path):
    cli = _consenso(tmp_path, Doble("gpt", "ok", falla=falla_gpt),
                    Doble("claude", "ok", falla=falla_claude))
    with pytest.raises(RuntimeError, match="un solo evaluador"):
        cli.generar_mensaje("evalúa")


def test_una_respuesta_vacia_no_cuenta_como_opinion(tmp_path):
    cli = _consenso(tmp_path, Doble("gpt", '{"puntaje": 3}'), Doble("claude", "   "))
    with pytest.raises(RuntimeError, match="respuesta vacía de CLAUDE"):
        cli.generar_mensaje("evalúa")


def test_cada_proveedor_deja_su_entrada_de_auditoria_y_el_coste_no_se_duplica(
        tmp_path, monkeypatch):
    eventos = []
    monkeypatch.setattr(ia, "_registrar_llamada",
                        _espia(ia._registrar_llamada, eventos))

    class Claude(Doble):
        PROVEEDOR = "anthropic"

    def gpt(prompt):
        return '{"puntaje": 3}' if "EVALUADOR A" not in prompt else '{"puntaje": 3}'
    cli = _consenso(tmp_path, Doble("gpt", gpt), Claude("claude", '{"puntaje": 2}'))
    cli.generar_mensaje("evalúa")
    proveedores = sorted(e for e in eventos)
    # GPT (opinión) + Claude (opinión) + GPT (árbitro) + el compuesto.
    assert proveedores == ["anthropic", "azure_openai", "azure_openai", "virf_plus"]


def _espia(original, eventos):
    def _registrar(cliente, *a, **kw):
        eventos.append(getattr(cliente, "PROVEEDOR", None))
        return original(cliente, *a, **kw)
    return _registrar


def test_el_compuesto_no_factura_tokens_propios(tmp_path, monkeypatch, caplog):
    import logging
    cli = _consenso(tmp_path, Doble("gpt", '{"puntaje": 3}'), Doble("claude", '{"puntaje": 3}'))
    with caplog.at_level(logging.INFO, logger="virf.auditoria.ia"):
        cli.generar_mensaje("evalúa")
    compuestas = [r.getMessage() for r in caplog.records if "'compuesto': True" in r.getMessage()]
    assert len(compuestas) == 1 and "'coste_usd': 0.0" in compuestas[0]
