# -*- coding: utf-8 -*-
"""
SEG-06 · Almacenamiento local.

  · Sin clasificación no se sube nada; Restringido en el portátil se rechaza.
  · La caché de documentos está cifrada: ilegible sin la clave.
  · Lo Restringido no se captura a PNG.
  · La retención (TTL) borra lo vencido, con sobrescritura.
"""
from __future__ import annotations

import io
import json
import os
import time
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from config.identidad import Identidad
from modulos import almacenamiento as alm


# ── Clasificación ────────────────────────────────────────────────────────────

@pytest.mark.parametrize("valor", [None, "", "secreto", "confidencial"])
def test_sin_clasificacion_valida_se_rechaza(valor):
    with pytest.raises(alm.ClasificacionInvalida):
        alm.exigir_permitido(valor)


def test_restringido_en_portatil_falla(monkeypatch):
    monkeypatch.delenv("VIRF_ENTORNO", raising=False)
    with pytest.raises(alm.AlmacenamientoNoPermitido, match="Databricks"):
        alm.exigir_permitido("Restringido")
    assert alm.exigir_permitido("interno") == "Interno"


@pytest.mark.parametrize("entorno", ["databricks", "repositorio_aprobado"])
def test_restringido_en_entorno_aprobado_pasa(entorno, monkeypatch):
    monkeypatch.setenv("VIRF_ENTORNO", entorno)
    assert alm.exigir_permitido("Restringido") == "Restringido"


@pytest.fixture
def cliente(monkeypatch, tmp_path):
    from web.services import sesion_store
    from web.routers import upload as ru
    from web.app import app
    monkeypatch.setattr(sesion_store, "VALIDADORES", tmp_path / "validadores.json")
    monkeypatch.setattr(sesion_store, "DATA_DIR", tmp_path)
    sesion_store._sesiones.clear()
    tok, _ = sesion_store.crear_sesion(Identidad(oid="o", upn="ana@bcp.com.pe", nombre="Ana",
                                                 codigo="T5443", roles=("validador",)))
    destino = tmp_path / "inputs" / "documentacion"
    monkeypatch.setattr(ru, "resolver_destino", lambda slug, ctx: destino)
    app.dependency_overrides[ru.contexto_sesion] = lambda: {
        "clave": "T5443/m", "inputs": tmp_path / "inputs", "validador": {"upn": "ana@bcp.com.pe"}}
    c = TestClient(app, base_url="https://testserver")
    c.cookies.set("virf_token", tok)
    yield c, destino
    app.dependency_overrides.clear()


def _subir(c, clasif=None):
    url = "/api/inputs/upload?destino=documentacion" + (f"&clasificacion={clasif}" if clasif else "")
    return c.post(url, files={"archivos": ("manual.txt", b"contenido", "text/plain")})


def test_subida_sin_clasificacion_rechazada(cliente):
    c, destino = cliente
    assert _subir(c).status_code == 422
    assert _subir(c, "Inventada").status_code == 400
    assert not (destino / "manual.txt").exists()


def test_subida_restringida_en_portatil_rechazada(cliente):
    c, destino = cliente
    r = _subir(c, "Restringido")
    assert r.status_code == 403
    assert not (destino / "manual.txt").exists()


def test_subida_clasificada_queda_registrada(cliente):
    c, destino = cliente
    assert _subir(c, "Interno").status_code == 200
    assert alm.clasificacion_de(destino / "manual.txt") == "Interno"


def test_zip_sin_clasificacion_rechazado(cliente):
    c, destino = cliente
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("a.py", "x = 1")
    r = c.post("/api/inputs/upload-zip?destino=documentacion",
               files={"archivo": ("c.zip", buf.getvalue(), "application/zip")})
    assert r.status_code == 422


# ── Cifrado de la caché ──────────────────────────────────────────────────────

def test_cache_cifrada_en_disco_e_ilegible_sin_clave(tmp_path, monkeypatch):
    from modulos.document_cache import DocumentCache
    doc = tmp_path / "manual.txt"
    doc.write_text("texto secreto del manual", encoding="utf-8")
    extractor = lambda ruta: ruta.read_text(encoding="utf-8")
    cache = DocumentCache(tmp_path / "cache")
    cache.get(doc, extractor, None)
    cache.persistir()
    ficheros = [p for p in (tmp_path / "cache").rglob("*") if p.is_file()]
    assert ficheros
    for f in ficheros:
        blob = f.read_bytes()
        assert blob.startswith(alm.MAGIA)
        assert b"texto secreto" not in blob
    # Con la clave se lee; con otra clave, no.
    llamadas = []
    otro = DocumentCache(tmp_path / "cache")
    otro.get(doc, lambda r: llamadas.append(1) or "x", None)
    assert llamadas == [], "con la clave correcta la entrada se lee del caché cifrado"
    monkeypatch.setenv("VIRF_CLAVE_CIFRADO_REPOSO", "otra-clave-" + "z" * 40)
    with pytest.raises(alm.CifradoNoDisponible):
        alm.descifrar(ficheros[0].read_bytes())


def _cache_cifrada_con_una_entrada(tmp_path):
    from modulos.document_cache import DocumentCache
    doc = tmp_path / "manual.txt"
    doc.write_text("texto del manual", encoding="utf-8")
    cache = DocumentCache(tmp_path / "cache")
    cache.get(doc, lambda r: r.read_text(encoding="utf-8"), None)
    cache.persistir()
    return doc, tmp_path / "cache" / "document_cache.json"


@pytest.mark.parametrize("clave", ["otra-clave-" + "z" * 40, None])
def test_cache_de_otra_clave_o_sin_clave_no_tumba_el_arranque(tmp_path, monkeypatch, clave):
    """La caché cifrada con la clave efímera de un arranque anterior (o sin clave en
    este proceso) se ignora y se recalcula: antes el pipeline se caía al cargarla."""
    from modulos.document_cache import DocumentCache
    doc, _ = _cache_cifrada_con_una_entrada(tmp_path)
    if clave is None:
        monkeypatch.delenv("VIRF_CLAVE_CIFRADO_REPOSO", raising=False)
    else:
        monkeypatch.setenv("VIRF_CLAVE_CIFRADO_REPOSO", clave)
    nuevo = DocumentCache(tmp_path / "cache")
    assert len(nuevo._data) == 0
    llamadas = []
    nuevo.get(doc, lambda r: llamadas.append(1) or "x", None)
    assert llamadas == [1], "sin poder descifrar, el documento se vuelve a leer"
    nuevo.persistir()                      # no lanza aunque el disco no se pueda leer


def test_limpiar_cache_cifrada_funciona_sin_clave(tmp_path, monkeypatch):
    """`--limpiar-cache` no necesita la clave: vaciar es borrar el fichero."""
    from modulos.document_cache import DocumentCache
    _, fichero = _cache_cifrada_con_una_entrada(tmp_path)
    assert fichero.exists()
    monkeypatch.delenv("VIRF_CLAVE_CIFRADO_REPOSO", raising=False)
    DocumentCache(tmp_path / "cache").limpiar_todo()
    assert not fichero.exists()


def test_sin_clave_no_se_escribe_en_claro(monkeypatch):
    monkeypatch.delenv("VIRF_CLAVE_CIFRADO_REPOSO", raising=False)
    with pytest.raises(alm.CifradoNoDisponible):
        alm.cifrar(b"x")


# ── Capturas ─────────────────────────────────────────────────────────────────

def test_no_se_captura_lo_restringido(tmp_path):
    from modulos import capturas
    doc = tmp_path / "codigo.py"
    doc.write_text("def f():\n    return 1\n", encoding="utf-8")
    alm.registrar_clasificacion(doc, "Restringido")
    assert capturas.captura_codigo("return 1", tmp_path / "png", archivo=doc) is None
    assert capturas.captura_cita(doc, "return 1", tmp_path / "png") is None
    pdf = tmp_path / "m.pdf"; pdf.write_bytes(b"%PDF-1.4")
    alm.registrar_clasificacion(pdf, "Restringido")
    assert capturas.captura_portada(pdf, tmp_path / "png") is None


# ── Retención ────────────────────────────────────────────────────────────────

def test_ttl_borra_lo_vencido_y_conserva_lo_reciente(tmp_path):
    viejo, nuevo = tmp_path / "viejo.txt", tmp_path / "nuevo.txt"
    viejo.write_text("dato antiguo"); nuevo.write_text("dato reciente")
    hace_40_dias = time.time() - 40 * 86400
    os.utime(viejo, (hace_40_dias, hace_40_dias))
    borrados = alm.purgar_vencidos([tmp_path], dias=30)
    assert borrados == [viejo]
    assert not viejo.exists() and nuevo.exists()


def test_retencion_configurable(monkeypatch):
    from config.parametros import dias_retencion
    monkeypatch.setenv("VIRF_RETENCION_DIAS", "7")
    assert dias_retencion() == 7.0


def test_borrado_seguro_sobrescribe_antes_de_borrar(tmp_path, monkeypatch):
    p = tmp_path / "x.bin"; p.write_bytes(b"secreto")
    escrito = {}
    real_unlink = Path.unlink

    def _espiar(self, missing_ok=False):
        escrito["antes"] = self.read_bytes()
        return real_unlink(self, missing_ok=missing_ok)
    monkeypatch.setattr(Path, "unlink", _espiar)
    alm.borrado_seguro(p)
    assert escrito["antes"] == b"\0" * 7 and not p.exists()
