# -*- coding: utf-8 -*-
"""
tests/test_corrida_fallida.py — una corrida que no puede evaluar lo dice.

Reproducido el 2026-11-11 lanzando `agente.py` con una clave rechazada (401):

  1. El arranque imprimía «Verificando API key… ✅ OK» sin llamar al proveedor;
     se hacían 28 llamadas condenadas y el proceso salía con código 0.
  2. El resumen decía «Ningún ámbito tenía evidencia» y «SIN DOCUMENTOS» cuando
     la causa era un fallo técnico del agente (invariante 3: un fallo técnico
     no es falta de evidencia del validado).
  3. El borrador Markdown reventaba al ordenar puntajes nulos.
  4. `scripts/reconstruir_estandar_desde_informes.py` no compilaba.
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]


class _Cliente:
    def __init__(self, ok, motivo=""):
        self._ok, self.ultimo_error_conexion, self.llamadas = ok, motivo, 0

    def validar_conexion(self):
        self.llamadas += 1
        return self._ok


# ── 1. Clave inválida: se corta en el arranque y se sale con error ───────────

def test_la_verificacion_de_arranque_llama_de_verdad_al_proveedor():
    import agente
    cli = _Cliente(True)
    agente._verificar_credencial(cli)
    assert cli.llamadas == 1


def test_clave_rechazada_se_detecta_en_el_arranque_con_su_motivo():
    import agente
    cli = _Cliente(False, "Error code: 401 - invalid x-api-key")
    with pytest.raises(RuntimeError, match="401"):
        agente._verificar_credencial(cli)


def test_el_arranque_no_dice_ok_sin_haber_verificado():
    """El «✅ OK» solo puede imprimirse después de la llamada de verificación."""
    src = (RAIZ / "agente.py").read_text(encoding="utf-8")
    bloque = src[src.index('print("  🔑 Verificando API key..."'):]
    bloque = bloque[:bloque.index("except ValueError")]
    assert "_verificar_credencial(" in bloque
    assert bloque.index("_verificar_credencial(") < bloque.index('print("✅ OK")')


@pytest.mark.parametrize("validas, fallidas, esperado", [
    (0, 28, 1),      # nada evaluado y todo falló: la corrida NO fue un éxito
    (20, 8, 0),      # parcial: hay resultado; los fallos ya se declaran aparte
    (24, 0, 0),
    (0, 0, 0),       # sin evidencia en ningún ámbito: no es un fallo del agente
])
def test_codigo_de_salida_de_la_corrida(validas, fallidas, esperado):
    import agente
    assert agente._codigo_salida_corrida(validas, fallidas) == esperado


# ── 2. Fallo técnico ≠ falta de evidencia ────────────────────────────────────

_FALLO = {"puntaje": None, "evaluacion_valida": False}
_SIN_EV = {"puntaje": None, "sin_evidencia": True}


def test_ambito_caido_por_fallo_tecnico_no_se_rotula_sin_documentos():
    import agente
    etiqueta = agente._motivo_ambito_sin_score([_FALLO, _FALLO])
    assert "FALLO TÉCNICO" in etiqueta and "SIN DOCUMENTOS" not in etiqueta


def test_ambito_sin_evidencia_sigue_siendo_sin_documentos():
    import agente
    assert agente._motivo_ambito_sin_score([_SIN_EV]) == "SIN DOCUMENTOS"
    assert agente._motivo_ambito_sin_score([]) == "SIN DOCUMENTOS"


def test_ambito_con_las_dos_causas_declara_ambas():
    import agente
    etiqueta = agente._motivo_ambito_sin_score([_FALLO, _SIN_EV])
    assert "FALLO TÉCNICO" in etiqueta and "sin evidencia" in etiqueta.lower()


def test_resumen_global_no_culpa_a_la_evidencia_de_un_fallo_tecnico():
    import agente
    texto = " ".join(agente._motivo_no_evaluable(n_sin_evidencia=0, n_fallidas=28))
    assert "FALLO TÉCNICO" in texto and "tenía evidencia" not in texto
    solo_evidencia = " ".join(agente._motivo_no_evaluable(n_sin_evidencia=24, n_fallidas=0))
    assert "Ningún ámbito tenía evidencia" in solo_evidencia


def test_el_resumen_final_usa_esos_motivos():
    src = (RAIZ / "agente.py").read_text(encoding="utf-8")
    assert not re.search(r'print\(f"\s+- \{amb:<35\} SIN DOCUMENTOS"\)', src), \
        "queda un «SIN DOCUMENTOS» fijo que no mira por qué falta el score"


# ── 3. Borrador Markdown con ámbitos sin puntaje ─────────────────────────────

def test_borrador_markdown_con_todos_los_ambitos_sin_puntaje():
    from modulos.generador_markdown import _resumen
    filas = _resumen({"scores_por_ambito": {"Metodología": None, "Gobierno": None}})
    cuerpo = "\n".join(filas)
    assert "Metodología" in cuerpo and "Gobierno" in cuerpo
    assert "No cumple" not in cuerpo, "un ámbito sin evaluar no es un «No cumple»"


def test_borrador_markdown_ordena_los_no_evaluados_al_final():
    from modulos.generador_markdown import _resumen
    filas = [f for f in _resumen({"scores_por_ambito": {
        "A": None, "B": 4.0, "C": 2.0}}) if f.startswith("| ") and "Ámbito" not in f]
    assert [f.split("|")[1].strip() for f in filas] == ["C", "B", "A"]


# ── 4. Todos los scripts compilan ────────────────────────────────────────────

@pytest.mark.parametrize("script", sorted(p.name for p in (RAIZ / "scripts").glob("*.py")))
def test_cada_script_compila(script):
    ruta = RAIZ / "scripts" / script
    fuente = ruta.read_text(encoding="utf-8")
    compile(fuente, str(ruta), "exec")
    # Código delante del docstring deja `__doc__` en None: los scripts que lo
    # usan para su `--help` compilaban y aun así morían al arrancar.
    if "__doc__" in fuente:
        import ast
        assert ast.get_docstring(ast.parse(fuente)), \
            f"{script} usa __doc__ pero su docstring no es la primera sentencia"
