# -*- coding: utf-8 -*-
"""
SEG-09 · Gobierno de riesgo de modelo IA y tratamiento de SAST/SCA.

  · Los índices RAG (pickle) solo se deserializan con firma HMAC válida.
  · No quedan las construcciones que el SAST marcó HIGH/MEDIUM.
  · El inventario de IA cubre todos los módulos que llaman a un LLM.
"""
from __future__ import annotations

import ast
import json
import pickle
from pathlib import Path

import pytest

from modulos import pickle_firmado as pf

RAIZ = Path(__file__).resolve().parent.parent


class _Bomba:
    def __reduce__(self):
        import os
        return (os.system, ("echo pwned > pwned.txt",))


def test_pickle_firmado_ida_y_vuelta(tmp_path):
    pf.guardar({"a": 1}, tmp_path / "i.pkl")
    assert pf.cargar(tmp_path / "i.pkl") == {"a": 1}


def test_pickle_sin_firma_no_se_deserializa(tmp_path):
    p = tmp_path / "malo.pkl"
    p.write_bytes(pickle.dumps(_Bomba()))
    with pytest.raises(pf.PickleNoFirmado):
        pf.cargar(p)
    assert not (tmp_path / "pwned.txt").exists()


def test_pickle_manipulado_tras_firmar_se_rechaza(tmp_path):
    p = tmp_path / "i.pkl"
    pf.guardar({"a": 1}, p)
    p.write_bytes(pickle.dumps(_Bomba()))                    # se reemplaza el contenido
    with pytest.raises(pf.PickleNoFirmado, match="firma inválida"):
        pf.cargar(p)


def test_indice_rag_usa_pickle_firmado():
    src = (RAIZ / "src" / "rag" / "indexador_lexico.py").read_text(encoding="utf-8")
    web = (RAIZ / "web" / "routers" / "rag.py").read_text(encoding="utf-8")
    assert "pickle_firmado.guardar(" in src and "pickle_firmado.cargar(" in src
    assert "pickle_firmado.cargar(" in web


def _llamadas(nombre_attr, modulo_base):
    for base in ("modulos", "motor", "web", "config", "src", "scripts"):
        for p in (RAIZ / base).rglob("*.py"):
            for n in ast.walk(ast.parse(p.read_text(encoding="utf-8", errors="ignore"))):
                if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) \
                        and n.func.attr == nombre_attr \
                        and ast.unparse(n.func.value) == modulo_base:
                    yield f"{p.relative_to(RAIZ)}:{n.lineno}"


def test_sin_hallazgos_sast_altos_o_medios():
    assert list(_llamadas("md5", "hashlib")) == []
    assert list(_llamadas("sha1", "hashlib")) == []
    assert list(_llamadas("load", "pickle")) == []
    assert list(_llamadas("loads", "pickle")) == ["modulos\\pickle_firmado.py:60"] or \
        [x.replace("\\", "/") for x in _llamadas("loads", "pickle")] == ["modulos/pickle_firmado.py:60"]


def test_reportes_sast_y_sca_adjuntos():
    sast = json.loads((RAIZ / "docs/seguridad/sast_bandit.json").read_text(encoding="utf-8"))
    assert not [r for r in sast["results"] if r["issue_severity"] in ("HIGH", "MEDIUM")]
    sca = json.loads((RAIZ / "docs/seguridad/sca_pip_audit.json").read_text(encoding="utf-8"))
    assert sca["dependencies"]


def test_inventario_cubre_cada_llamante_de_ia():
    doc = (RAIZ / "docs/seguridad/GOBIERNO_RIESGO_IA.md").read_text(encoding="utf-8")
    llamantes = set()
    for base in ("modulos", "web", "config", "motor"):
        for p in (RAIZ / base).rglob("*.py"):
            if ".generar_mensaje(" in p.read_text(encoding="utf-8", errors="ignore"):
                llamantes.add(p.stem)
    # El gateway, el orquestador del pipeline y la prueba de conectividad no son
    # componentes de IA propios: están cubiertos por las filas que los usan.
    llamantes -= {"ia", "Mx_03_LlamarIA", "control_evaluacion_data"}
    faltan = sorted(m for m in llamantes if m not in doc)
    assert faltan == [], f"módulos que llaman a la IA sin fila en el inventario: {faltan}"
