"""
tests/test_guia_progreso.py — Paso 01 de la guía de la web (/api/guia/progreso).

[SEG-01/03] La guía solo da el paso 01 por hecho si el proveedor está APROBADO
por el banco y su clave existe en la fuente de secretos. Antes leía el .env en
crudo y marcaba «hecho» con Anthropic (EN_ESPERA) porque había una clave escrita.
Sin coste: no llama a ninguna IA.
"""
from __future__ import annotations

from web.routers.guia import _estado_config


def test_proveedor_no_aprobado_queda_pendiente_aunque_tenga_clave(monkeypatch):
    # El bloqueo del banco rige en producción.
    import config.parametros as par
    monkeypatch.setattr(par, "MODO", "produccion")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-prueba")
    estado, detalle = _estado_config("anthropic")
    assert estado == "pendiente"
    assert "no autorizado por el banco" in detalle and "EN_ESPERA" in detalle
    assert "azure_openai" in detalle


def test_proveedor_aprobado_sin_clave_en_la_fuente_queda_pendiente(monkeypatch):
    monkeypatch.delenv("AZURE_OPENAI_API_KEY", raising=False)
    estado, detalle = _estado_config("azure_openai")
    assert estado == "pendiente"
    assert "AZURE_OPENAI_API_KEY" in detalle and "«entorno»" in detalle


def test_proveedor_aprobado_con_clave_en_la_fuente_queda_hecho(monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "clave-simulada")
    estado, detalle = _estado_config("azure_openai")
    assert estado == "hecho" and "«entorno»" in detalle


def test_fuente_de_secretos_invalida_no_rompe_la_guia(monkeypatch):
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "inventada")
    estado, detalle = _estado_config("azure_openai")
    assert estado == "pendiente" and "VIRF_FUENTE_SECRETOS" in detalle


def test_proveedor_no_catalogado():
    estado, detalle = _estado_config("otro")
    assert estado == "pendiente" and "NO_CATALOGADO" in detalle
