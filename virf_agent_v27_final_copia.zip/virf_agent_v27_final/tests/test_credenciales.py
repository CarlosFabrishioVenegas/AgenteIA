# -*- coding: utf-8 -*-
"""
SEG-03 · Credenciales.

  · Ningún endpoint web acepta una clave y nada en web/ escribe el `.env`.
  · Las claves solo se leen vía config/secretos.py (Key Vault, secret scope o
    entorno de proceso fuera de producción), y una clave escrita en el `.env`
    se RECHAZA.
  · El escaneo de secretos detecta claves y no encuentra ninguna en el repo.
"""
from __future__ import annotations

import ast
import re
import sys
import types
from pathlib import Path

import pytest

import config.secretos as sec

RAIZ = Path(__file__).resolve().parent.parent
_CAMPO_SECRETO = re.compile(
    r"(?i)(api_?key|clave(?:_api)?|token|secret|password|credencial)")

# Pendiente de OTRO hallazgo, declarado aquí para que no quede oculto:
# la contraseña compartida del editor de prompts la elimina SEG-08 (roles).
_PENDIENTE_SEG08 = {"x-prompt-password"}


# ═════════════════════════════════════════════════════════════════════════════
# La web no acepta ni escribe claves
# ═════════════════════════════════════════════════════════════════════════════

def _esquema():
    # El OpenAPI aplana todos los routers incluidos (FastAPI 0.141 los anida en
    # app.routes, así que recorrer app.routes NO ve sus endpoints).
    from web.app import app
    return app.openapi()


def _propiedades(esquema, componentes, vistos=None):
    vistos = vistos if vistos is not None else set()
    if not isinstance(esquema, dict):
        return
    ref = esquema.get("$ref")
    if ref:
        nombre = ref.rsplit("/", 1)[-1]
        if nombre in vistos:
            return
        vistos.add(nombre)
        yield from _propiedades(componentes.get(nombre, {}), componentes, vistos)
        return
    for nombre, sub in (esquema.get("properties") or {}).items():
        yield nombre
        yield from _propiedades(sub, componentes, vistos)
    for clave in ("items", "additionalProperties"):
        yield from _propiedades(esquema.get(clave), componentes, vistos)
    for clave in ("allOf", "anyOf", "oneOf"):
        for sub in esquema.get(clave) or []:
            yield from _propiedades(sub, componentes, vistos)


def test_ningun_endpoint_acepta_una_clave():
    api = _esquema()
    componentes = api.get("components", {}).get("schemas", {})
    infractores, inspeccionados = [], 0
    for ruta, metodos in api["paths"].items():
        for metodo, op in metodos.items():
            for prm in op.get("parameters", []):
                inspeccionados += 1
                if prm.get("name", "").lower() in _PENDIENTE_SEG08:
                    continue
                if _CAMPO_SECRETO.search(prm.get("name", "")) and prm.get("in") != "cookie":
                    infractores.append(f"{metodo.upper()} {ruta}: {prm['name']}")
            cuerpo = op.get("requestBody", {}).get("content", {})
            for media in cuerpo.values():
                for campo in _propiedades(media.get("schema", {}), componentes):
                    inspeccionados += 1
                    if _CAMPO_SECRETO.search(campo):
                        infractores.append(f"{metodo.upper()} {ruta}: {campo}")
    assert inspeccionados > 20, "el test no está viendo los endpoints"
    assert infractores == [], infractores


def test_no_existe_el_endpoint_que_guardaba_credenciales():
    rutas = set(_esquema()["paths"])
    assert "/api/config/virf_plus" in rutas, "el test no está viendo los routers"
    assert "/api/config/proveedor" not in rutas


def test_env_service_es_solo_lectura():
    from web.services import env_service
    assert not hasattr(env_service, "actualizar_env")
    assert hasattr(env_service, "leer_env")


def test_nada_en_web_ni_config_escribe_el_env():
    infractores = []
    for base in ("web", "config"):
        for p in (RAIZ / base).rglob("*.py"):
            texto = p.read_text(encoding="utf-8", errors="ignore")
            if "actualizar_env" in texto:
                infractores.append(f"{p.relative_to(RAIZ)}: actualizar_env")
            arbol = ast.parse(texto)
            for nodo in ast.walk(arbol):
                if isinstance(nodo, ast.Call) and isinstance(nodo.func, ast.Attribute) \
                        and nodo.func.attr in ("write_text", "write_bytes", "touch"):
                    if "ENV_PATH" in ast.unparse(nodo.func.value) \
                            or ".env" in ast.unparse(nodo.func.value):
                        infractores.append(f"{p.relative_to(RAIZ)}:{nodo.lineno}")
    assert infractores == [], infractores


def test_las_claves_solo_se_leen_via_secretos():
    # En config/ia.py ninguna *_API_KEY se lee directamente del entorno.
    src = (RAIZ / "config" / "ia.py").read_text(encoding="utf-8")
    directas = re.findall(r"os\.(?:getenv|environ(?:\.get)?)\(\s*[\"'](\w+_API_KEY)", src)
    assert directas == [], directas


# ═════════════════════════════════════════════════════════════════════════════
# config/secretos.py
# ═════════════════════════════════════════════════════════════════════════════

def test_entorno_rechaza_clave_escrita_en_el_env(tmp_path, monkeypatch):
    # Fuera de los modos de desarrollo declarados (aquí, un CI): se rechaza.
    import config.parametros as par
    monkeypatch.setattr(par, "MODO", "ci")
    env = tmp_path / ".env"
    env.write_text("AZURE_OPENAI_API_KEY=abc123valorplano\n", encoding="utf-8")
    monkeypatch.setattr(sec, "RUTA_ENV", env)
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "abc123valorplano")
    with pytest.raises(sec.SecretoEnTextoPlano, match="ROTACIÓN") as e:
        sec.obtener_secreto("AZURE_OPENAI_API_KEY")
    assert "abc123valorplano" not in str(e.value)
    assert sec.secreto_configurado("AZURE_OPENAI_API_KEY") is False


def test_env_con_clave_vacia_o_comentada_no_bloquea(tmp_path, monkeypatch):
    env = tmp_path / ".env"
    env.write_text("# AZURE_OPENAI_API_KEY=algo\nAZURE_OPENAI_API_KEY=\n", encoding="utf-8")
    monkeypatch.setattr(sec, "RUTA_ENV", env)
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "desde-el-proceso")
    assert sec.obtener_secreto("AZURE_OPENAI_API_KEY") == "desde-el-proceso"


def test_entorno_prohibido_en_produccion(monkeypatch):
    import config.parametros as par
    monkeypatch.setattr(par, "MODO", "produccion")
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "x")
    with pytest.raises(sec.SecretoNoDisponible, match="produccion"):
        sec.obtener_secreto("AZURE_OPENAI_API_KEY")


def test_fuente_invalida_falla(monkeypatch):
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "disco")
    with pytest.raises(sec.SecretoNoDisponible):
        sec.obtener_secreto("AZURE_OPENAI_API_KEY")


@pytest.mark.parametrize("modo", ["produccion", "", "ci", "staging"])
def test_por_defecto_la_fuente_es_keyvault(modo, monkeypatch):
    import config.parametros as par
    monkeypatch.setattr(par, "MODO", modo)
    monkeypatch.delenv("VIRF_FUENTE_SECRETOS", raising=False)
    assert sec.fuente_secretos() == "keyvault"


# ── Excepción de desarrollo: basta con editar la clave del .env ──────────────

@pytest.mark.parametrize("modo", ["debug", "desarrollo", "DEBUG"])
def test_en_desarrollo_la_fuente_por_defecto_es_entorno(modo, monkeypatch):
    import config.parametros as par
    monkeypatch.setattr(par, "MODO", modo)
    monkeypatch.delenv("VIRF_FUENTE_SECRETOS", raising=False)
    assert sec.fuente_secretos() == "entorno"
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "keyvault")     # lo declarado manda
    assert sec.fuente_secretos() == "keyvault"


def test_en_desarrollo_la_clave_del_env_se_acepta_y_se_avisa(tmp_path, monkeypatch, capsys):
    env = tmp_path / ".env"
    env.write_text("ANTHROPIC_API_KEY=abc123valorplano\n", encoding="utf-8")
    monkeypatch.setattr(sec, "RUTA_ENV", env)
    monkeypatch.setattr(sec, "_AVISADAS_EN_ENV", set())
    monkeypatch.setenv("ANTHROPIC_API_KEY", "abc123valorplano")     # lo que hace load_dotenv
    assert sec.obtener_secreto("ANTHROPIC_API_KEY") == "abc123valorplano"
    assert sec.secreto_configurado("ANTHROPIC_API_KEY") is True
    salida = capsys.readouterr().out
    assert "texto plano" in salida and "MODO=debug" in salida
    assert "abc123valorplano" not in salida, "el aviso no puede mostrar la clave"
    assert salida.count("ANTHROPIC_API_KEY leída") == 1, "un aviso por clave, no por lectura"


def test_en_produccion_el_env_nunca_es_origen_de_una_clave(tmp_path, monkeypatch):
    """La excepción no alcanza a producción, ni declarando la fuente `entorno`."""
    import config.parametros as par
    env = tmp_path / ".env"
    env.write_text("AZURE_OPENAI_API_KEY=abc123valorplano\n", encoding="utf-8")
    monkeypatch.setattr(sec, "RUTA_ENV", env)
    monkeypatch.setattr(par, "MODO", "produccion")
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "abc123valorplano")
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "entorno")
    with pytest.raises(sec.SecretoNoDisponible, match="produccion"):
        sec.obtener_secreto("AZURE_OPENAI_API_KEY")
    assert sec.secreto_configurado("AZURE_OPENAI_API_KEY") is False


def test_keyvault_requiere_url(monkeypatch):
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "keyvault")
    monkeypatch.delenv("VIRF_KEYVAULT_URL", raising=False)
    with pytest.raises(sec.SecretoNoDisponible, match="VIRF_KEYVAULT_URL"):
        sec.obtener_secreto("AZURE_OPENAI_API_KEY")


def test_keyvault_con_managed_identity(monkeypatch):
    pedidos = {}

    class _Cred:  # DefaultAzureCredential simulada
        pass

    class _Cliente:
        def __init__(self, vault_url, credential):
            pedidos["url"], pedidos["cred"] = vault_url, credential

        def get_secret(self, nombre):
            pedidos["nombre"] = nombre
            return types.SimpleNamespace(value="valor-del-vault")

    monkeypatch.setitem(sys.modules, "azure", types.ModuleType("azure"))
    monkeypatch.setitem(sys.modules, "azure.identity",
                        types.SimpleNamespace(DefaultAzureCredential=_Cred))
    monkeypatch.setitem(sys.modules, "azure.keyvault", types.ModuleType("azure.keyvault"))
    monkeypatch.setitem(sys.modules, "azure.keyvault.secrets",
                        types.SimpleNamespace(SecretClient=_Cliente))
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "keyvault")
    monkeypatch.setenv("VIRF_KEYVAULT_URL", "https://bcp-virf.vault.azure.net/")
    assert sec.obtener_secreto("AZURE_OPENAI_API_KEY") == "valor-del-vault"
    assert pedidos["nombre"] == "azure-openai-api-key"
    assert isinstance(pedidos["cred"], _Cred)


def test_databricks_secret_scope(monkeypatch):
    vistos = {}

    class _Secrets:
        def get(self, scope, key):
            vistos.update(scope=scope, key=key)
            return "valor-del-scope"

    monkeypatch.setattr(sec, "_dbutils", lambda: types.SimpleNamespace(secrets=_Secrets()))
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "databricks")
    monkeypatch.setenv("VIRF_SECRET_SCOPE", "virf")
    assert sec.obtener_secreto("AZURE_OPENAI_API_KEY") == "valor-del-scope"
    assert vistos == {"scope": "virf", "key": "azure-openai-api-key"}


def test_web_muestra_estado_sin_valor(monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "secreto-que-no-debe-salir")
    from web.routers import config as rconf
    monkeypatch.setattr(rconf.env_service, "leer_env", lambda: {})
    ficha = rconf._snapshot_env()
    assert ficha["azure_openai"]["AZURE_OPENAI_API_KEY"] == {"seteada": True}
    assert "secreto-que-no-debe-salir" not in repr(ficha)
    assert ficha["fuente_secretos"] == "entorno"


# ═════════════════════════════════════════════════════════════════════════════
# Escaneo de secretos
# ═════════════════════════════════════════════════════════════════════════════

def _escaner():
    sys.path.insert(0, str(RAIZ / "scripts"))
    try:
        import escanear_secretos
    finally:
        sys.path.remove(str(RAIZ / "scripts"))
    return escanear_secretos


@pytest.mark.parametrize("linea", [
    "ANTHROPIC_API_KEY=sk-ant-api03-" + "A1b2C3d4" * 8,
    "key = 'sk-proj-" + "Z9y8X7w6" * 6 + "'",
    "token: dapi" + "0123456789abcdef" * 2,
    "AZURE_OPENAI_API_KEY=" + "0123456789abcdef" * 2,
])
def test_escaner_detecta_y_no_imprime_el_valor(linea):
    hallazgos = list(_escaner().escanear_texto(linea, "f.txt"))
    assert hallazgos, linea
    valor = linea.split("=", 1)[-1].split(":", 1)[-1].strip(" '")
    assert all(valor not in h for h in hallazgos)


@pytest.mark.parametrize("linea", [
    "AZURE_OPENAI_API_KEY=",
    "ANTHROPIC_API_KEY=TU_API_KEY_AQUI",
    "api_key = os.getenv('AZURE_OPENAI_API_KEY')",
    "monkeypatch.setenv('AZURE_OPENAI_API_KEY', 'k' * 32)",
])
def test_escaner_ignora_plantillas(linea):
    assert list(_escaner().escanear_texto(linea, "f.txt")) == []


def test_repositorio_sin_secretos():
    assert _escaner().escanear_arbol() == []
