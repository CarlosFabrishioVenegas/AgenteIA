# -*- coding: utf-8 -*-
"""
tests/test_verificacion_citas.py — una cita literal no se rechaza por su formato.

Medido el 2026-11-11 sobre la corrida real de `modelos/VaR_FixtureDrift`: de 74
citas marcadas «no verificadas», 35 solo diferían del manual en marcas de
formato (`**negrita**`, comillas de código) y otras venían con el salto de línea
escrito como `\\n`, dentro de una cita en bloque (`> …`) o con un título `##`.
Con la regla SEG-16 cada una RETIRA la observación entera: 4 de 4 en
Implementación y 5 de 6 en Metodología — justo las del contraste manual↔código.

El verificador tiene que seguir cazando lo inventado. Por eso cada caso de
«ahora pasa» va con su gemelo de «sigue fallando».
"""
from __future__ import annotations

from pathlib import Path

import pytest

from modulos.motor_ia import _verificar_citas

RAIZ = Path(__file__).resolve().parents[1]
FIX = RAIZ / "modelos" / "VaR_FixtureDrift" / "inputs"
MANUAL = (FIX / "documentacion" / "modelamiento" / "manual_VaR_drift.md").read_text(encoding="utf-8")
CODIGO = (FIX / "implementacion" / "calcula_var.py").read_text(encoding="utf-8")
CONTEXTO = f"[manual_VaR_drift.md]\n{MANUAL}\n[calcula_var.py]\n{CODIGO}"


def _dudosas(cita: str) -> list:
    return _verificar_citas(f'manual_VaR_drift.md → "{cita}"', CONTEXTO)


# ── Citas literales que el formato hacía fallar ──────────────────────────────

@pytest.mark.parametrize("cita", [
    # negrita del manual, que el modelo no copia
    "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones.",
    "El nivel de confianza es del 99 % y el horizonte de mantenimiento es de 1 día.",
    # comillas de código del manual
    "El módulo implementa la función backtesting_kupiec(), que contrasta el número de excepciones",
    # cita en bloque (`> …`) partida en dos líneas
    "Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad.",
    # título + salto de línea escrito como \n por el modelo
    "## 2. Especificación del cálculo\\nEl VaR se estima sobre una **ventana de 250 días hábiles**",
    # el modelo SÍ copió la negrita
    "El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un año",
])
def test_cita_literal_con_otro_formato_se_verifica(cita):
    assert _dudosas(cita) == []


def test_cita_con_elision_se_verifica_tramo_a_tramo():
    cita = ("El VaR se estima sobre una ventana de 250 días hábiles [...] "
            "Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución")
    assert _dudosas(cita) == []
    assert _dudosas(cita.replace("[...]", "...")) == []
    assert _dudosas(cita.replace("[...]", "…")) == []


def test_cita_cortada_a_media_frase_y_cerrada_con_punto_se_verifica():
    """La fuente sigue con «, que es la que permite…»; el modelo puso un punto."""
    assert _dudosas("Los rendimientos de los factores de riesgo se calculan como retornos "
                    "logarítmicos, por su propiedad de aditividad temporal.") == []


def test_cita_que_salta_una_frase_intermedia_se_verifica():
    cita = ("El nivel de confianza es del 99 % y el horizonte de mantenimiento es de 1 día. "
            "Los rendimientos de los factores de riesgo se calculan como retornos logarítmicos")
    assert _dudosas(cita) == []


def test_frases_reales_con_una_inventada_en_medio_siguen_marcadas():
    cita = ("El nivel de confianza es del 99 % y el horizonte de mantenimiento es de 1 día. "
            "Este valor fue ratificado por Auditoría Interna. "
            "Los rendimientos de los factores de riesgo se calculan como retornos logarítmicos")
    assert len(_dudosas(cita)) == 1


def test_codigo_citado_saltando_el_docstring_se_verifica():
    evidencia = ("calcula_var.py → ```python\n"
                 "def var_historico(retornos, confianza=0.95, ventana=500):\n"
                 "    muestra = retornos[-ventana:]\n"
                 "    return -np.percentile(muestra, (1 - confianza) * 100)\n```")
    assert _verificar_citas(evidencia, CONTEXTO) == []


# ── Lo inventado se sigue cazando ────────────────────────────────────────────

@pytest.mark.parametrize("cita", [
    # un solo número cambiado: es exactamente lo que no puede colarse
    "El VaR se estima sobre una ventana de 500 días hábiles, equivalente a un año de observaciones.",
    "El nivel de confianza es del 95 % y el horizonte de mantenimiento es de 1 día.",
    # frase que suena al manual y no está
    "El modelo se recalibra trimestralmente con aprobación expresa del Comité de Riesgos.",
    # literatura externa (bloque RAG), no evidencia del modelo
    "El backtesting de Kupiec evalúa si la tasa de excedencias observada es coherente con el nivel",
])
def test_cita_inventada_o_alterada_sigue_marcada(cita):
    assert len(_dudosas(cita)) == 1


def test_elision_con_un_tramo_inventado_sigue_marcada():
    cita = ("El VaR se estima sobre una ventana de 250 días hábiles [...] "
            "y se revisa cada mes por el área de Auditoría Interna del banco")
    assert len(_dudosas(cita)) == 1


def test_codigo_con_una_linea_inventada_sigue_marcado():
    evidencia = ("calcula_var.py → ```python\n"
                 "def var_historico(retornos, confianza=0.99, ventana=250):\n"
                 "    muestra = retornos[-ventana:]\n```")
    assert len(_verificar_citas(evidencia, CONTEXTO)) == 1


def test_cita_corta_sigue_sin_examinarse():
    """Por debajo de 40 caracteres una coincidencia es casual: no se juzga."""
    assert _dudosas("ventana de 250 días") == []


# ── El gemelo del juez de código usa la misma normalización ──────────────────

def test_el_juez_de_codigo_tambien_ignora_el_formato():
    from modulos.revision_codigo import verificar_referencia_manual
    ok = "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año"
    assert verificar_referencia_manual(ok, "code_drift", MANUAL) is True
    falsa = "El VaR se estima sobre una ventana de 500 días hábiles, equivalente a un año"
    assert verificar_referencia_manual(falsa, "code_drift", MANUAL) is False


def test_una_sola_normalizacion_para_todos():
    """El arreglo de las citas con elisión se aplicó a un verificador y no al
    otro. Los tres puntos de comparación literal comparten ahora una función."""
    for modulo in ("modulos/motor_ia.py", "modulos/revision_codigo.py", "modulos/entailment.py"):
        src = (RAIZ / modulo).read_text(encoding="utf-8")
        assert "normalizar_cita" in src, f"{modulo} compara citas con su propia normalización"
