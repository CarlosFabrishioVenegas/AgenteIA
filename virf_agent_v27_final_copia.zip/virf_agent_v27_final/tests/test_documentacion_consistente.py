# -*- coding: utf-8 -*-
"""
SEG-13 · Una sola verdad entre código, manual y CONOCIMIENTO.

  · Defaults EN CÓDIGO: MODO=produccion e IA_PROVEEDOR=azure_openai.
  · La guía generada lee esos valores del código y el número de tests de la
    ejecución real (pytest --collect-only), no de texto fijo.
  · CONOCIMIENTO_VIRF.md y el procedimiento no contradicen al código ni
    llevan conteos de tests escritos a mano.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "scripts"))
import generar_guia_agente as G  # noqa: E402


def test_defaults_en_codigo():
    assert G.defaults_en_codigo() == {"modo": "produccion", "proveedor": "azure_openai"}


def test_defaults_efectivos_sin_variables(tmp_path):
    # Un proceso limpio, sin MODO ni IA_PROVEEDOR ni .env, arranca en producción + Azure.
    env = {k: v for k, v in os.environ.items() if k not in ("MODO", "IA_PROVEEDOR")}
    codigo = ("import dotenv; dotenv.load_dotenv = lambda *a, **k: False\n"
              "import config.parametros as p; print(p.MODO, p.IA_PROVEEDOR)")
    r = subprocess.run([sys.executable, "-c", codigo], cwd=RAIZ, env=env,
                       capture_output=True, text=True)
    assert r.stdout.split() == ["produccion", "azure_openai"], r.stderr[-400:]


def test_manual_generado_muestra_valores_reales(tmp_path, monkeypatch):
    from docx import Document
    monkeypatch.setattr(G, "n_tests_reales", lambda: 4321)
    ruta = G.construir(tmp_path / "guia.docx")
    texto = "\n".join(p.text for p in Document(str(ruta)).paragraphs[:60])
    assert "MODO por defecto: produccion" in texto
    assert "proveedor de IA por defecto: azure_openai" in texto
    assert "tests recogidos por pytest: 4321" in texto


def test_conteo_de_tests_sale_de_la_ejecucion_real():
    n = G.n_tests_reales()
    assert isinstance(n, int) and n > 1000


def test_conocimiento_coincide_con_el_codigo():
    txt = (RAIZ / "docs" / "agente_corporativo" / "CONOCIMIENTO_VIRF.md").read_text(encoding="utf-8")
    assert "`azure_openai`" in txt and "MODO=produccion" in txt
    assert "alternativas `anthropic`" not in txt
    assert not re.search(r"~?\b(835|1\.?200)\s+tests\b", txt)


def test_procedimiento_sin_conteo_fijo():
    txt = (RAIZ / "PROCEDIMIENTO_VALIDACION.md").read_text(encoding="utf-8")
    assert not re.search(r"#\s*\d+\s+tests", txt)
