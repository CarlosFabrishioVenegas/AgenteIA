# -*- coding: utf-8 -*-
"""
SEG-08 · Roles y permisos + integridad del feedback.

  · validador ejecuta y deja feedback propio; admin_corpus gestiona el RAG
    compartido y los prompts; revisor solo lee. Denegar por defecto.
  · Sin contraseña compartida.
  · El historial de feedback es solo-anexar y encadenado por hash: modificar
    una entrada rompe la verificación.
"""
from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from config.identidad import Identidad
from web.services import roles, sesion_store


def _ident(rol):
    return Identidad(oid=f"oid-{rol}", upn=f"{rol}@bcp.com.pe", nombre=f"Persona {rol}",
                     codigo=f"T{abs(hash(rol)) % 9000 + 1000}", roles=(rol,) if rol else ())


@pytest.fixture
def cliente(monkeypatch, tmp_path):
    monkeypatch.setattr(sesion_store, "VALIDADORES", tmp_path / "validadores.json")
    monkeypatch.setattr(sesion_store, "DATA_DIR", tmp_path)
    sesion_store._sesiones.clear()
    from web.app import app
    return TestClient(app, base_url="https://testserver")


def _como(cliente, rol):
    tok, _ = sesion_store.crear_sesion(_ident(rol))
    cliente.cookies.set("virf_token", tok)
    return cliente


# ── Matriz ───────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("rol, permiso, esperado", [
    ("validador", "validar", True), ("validador", "feedback_propio", True),
    ("validador", "gestionar_corpus", False), ("validador", "editar_prompts", False),
    ("admin_corpus", "gestionar_corpus", True), ("admin_corpus", "editar_prompts", True),
    ("admin_corpus", "validar", False),
    ("revisor", "leer", True), ("revisor", "aprobar", True),
    ("revisor", "validar", False), ("revisor", "gestionar_corpus", False),
    ("revisor", "feedback_propio", False),
    ("", "leer", False), ("validador", "permiso_inexistente", False),
])
def test_matriz(rol, permiso, esperado):
    assert roles.puede((rol,) if rol else (), permiso) is esperado


def test_rol_inventado_no_da_permisos():
    assert not roles.puede(("superadmin",), "gestionar_corpus")


# ── Endpoints ────────────────────────────────────────────────────────────────

@pytest.mark.parametrize("metodo, ruta, cuerpo", [
    ("post", "/api/rag/dominios/crear", {"nombre": "Nuevo", "descripcion": "x", "palabras_clave": []}),
    ("delete", "/api/rag/dominios/xyz", None),
    ("delete", "/api/rag/dominios/xyz/paper/a.pdf", None),
    ("post", "/api/rag/reconstruir", {"dominio": "LaR"}),
])
@pytest.mark.parametrize("rol", ["validador", "revisor", ""])
def test_corpus_compartido_solo_admin(cliente, metodo, ruta, cuerpo, rol):
    _como(cliente, rol)
    r = getattr(cliente, metodo)(ruta, **({"json": cuerpo} if cuerpo else {}))
    assert r.status_code == 403, (ruta, rol, r.status_code, r.text)


def test_admin_pasa_el_control_de_rol(cliente):
    _como(cliente, "admin_corpus")
    r = cliente.delete("/api/rag/dominios/LaR")
    assert r.status_code != 403          # puede fallar por otra causa (dominio fijo)


@pytest.mark.parametrize("ruta", ["/api/prompts/editar", "/api/prompts/restaurar"])
@pytest.mark.parametrize("rol", ["validador", "revisor"])
def test_editar_prompts_solo_admin(cliente, ruta, rol, monkeypatch):
    from web.routers import prompts as rp
    from web.app import app
    app.dependency_overrides[rp.contexto_sesion] = lambda: {"clave": "x/y"}
    try:
        _como(cliente, rol)
        r = cliente.post(ruta, json={"prompt_id": "p", "contenido": "c"})
        assert r.status_code == 403
    finally:
        app.dependency_overrides.clear()


def test_sin_contrasena_compartida():
    from pathlib import Path
    raiz = Path(__file__).resolve().parent.parent
    for f in list((raiz / "web").rglob("*.py")) + [raiz / "web/static/js/app.js"]:
        texto = f.read_text(encoding="utf-8", errors="ignore")
        assert "virf2026" not in texto.replace("contraseña compartida «virf2026»", ""), f
        assert "X-Prompt-Password" not in texto, f
    import web.routers.preview_prompt as pv
    assert not hasattr(pv, "CONTRASENA")


def test_subir_al_rag_compartido_exige_admin(cliente):
    from web.routers import upload as ru
    from web.app import app
    app.dependency_overrides[ru.contexto_sesion] = lambda: {"clave": "x/y"}
    try:
        _como(cliente, "validador")
        r = cliente.post("/api/inputs/upload?destino=rag_LaR&clasificacion=Publico",
                         files={"archivos": ("a.pdf", b"%PDF-1.4", "application/pdf")})
        assert r.status_code == 403
    finally:
        app.dependency_overrides.clear()


def test_lanzar_validacion_exige_rol_validador(cliente):
    _como(cliente, "revisor")
    from web.routers import validacion as rv
    from web.app import app
    app.dependency_overrides[rv.contexto_sesion] = lambda: {"clave": "x/y"}
    try:
        assert cliente.post("/api/validar/lanzar", json={}).status_code == 403
    finally:
        app.dependency_overrides.clear()


def test_roles_salen_del_idp_no_del_registro(cliente, tmp_path):
    tok, _ = sesion_store.crear_sesion(_ident("validador"))
    reg = json.loads((tmp_path / "validadores.json").read_text(encoding="utf-8"))
    for v in reg.values():
        v["roles"] = ["admin_corpus"]                 # alguien edita el JSON a mano
    (tmp_path / "validadores.json").write_text(json.dumps(reg), encoding="utf-8")
    tok2, _ = sesion_store.crear_sesion(_ident("validador"))
    assert sesion_store.sesion_activa(tok2)["roles"] == ["validador"]


# ── Feedback encadenado ──────────────────────────────────────────────────────

@pytest.fixture
def fb(tmp_path, monkeypatch):
    import modulos.feedback as fb
    monkeypatch.setattr(fb, "FEEDBACK_PATH", tmp_path / "historial_feedback.json")
    return fb


def test_cadena_valida_tras_guardar(fb):
    fb.guardar_historial([{"ambito": "M", "actividad": f"a{i}", "puntaje_humano": i}
                          for i in range(5)])
    assert fb.verificar_cadena()["ok"] is True
    assert len(fb.cargar_historial_crudo()) == 5


def test_modificar_una_entrada_a_mano_rompe_la_cadena(fb):
    fb.guardar_historial([{"ambito": "M", "actividad": "a", "puntaje_humano": 2},
                          {"ambito": "M", "actividad": "b", "puntaje_humano": 3}])
    crudo = json.loads(fb.FEEDBACK_PATH.read_text(encoding="utf-8"))
    crudo[0]["puntaje_humano"] = 5
    fb.FEEDBACK_PATH.write_text(json.dumps(crudo), encoding="utf-8")
    v = fb.verificar_cadena()
    assert v["ok"] is False and v["roto_en"] == 0


def test_borrar_una_entrada_a_mano_rompe_la_cadena(fb):
    fb.guardar_historial([{"ambito": "M", "actividad": x} for x in "abc"])
    crudo = json.loads(fb.FEEDBACK_PATH.read_text(encoding="utf-8"))
    del crudo[1]
    fb.FEEDBACK_PATH.write_text(json.dumps(crudo), encoding="utf-8")
    assert fb.verificar_cadena()["roto_en"] == 1


def test_editar_crea_una_enmienda_y_no_toca_el_original(fb):
    fb.guardar_historial([{"ambito": "M", "actividad": "a", "puntaje_humano": 2}])
    original = fb.cargar_historial_crudo()[0]
    h = fb.cargar_historial()
    h[0]["puntaje_humano"] = 4
    fb.guardar_historial(h, autor="Ana", motivo="error de tipeo")
    crudo = fb.cargar_historial_crudo()
    assert crudo[0] == original
    assert crudo[1]["_tipo"] == "enmienda" and crudo[1]["_enmienda_de"] == original["_id"]
    assert fb.cargar_historial()[0]["puntaje_humano"] == 4
    assert fb.verificar_cadena()["ok"]
    # Reguardar la vista efectiva no crea más enmiendas.
    fb.guardar_historial(fb.cargar_historial())
    assert len(fb.cargar_historial_crudo()) == 2


def test_baja_es_una_entrada_nueva(fb):
    fb.guardar_historial([{"ambito": "M", "actividad": "a"}, {"ambito": "M", "actividad": "b"}])
    rid = fb.cargar_historial()[0]["_id"]
    fb.dar_de_baja(rid, autor="Ana", motivo="duplicado")
    assert [r["actividad"] for r in fb.cargar_historial()] == ["b"]
    assert len(fb.cargar_historial_crudo()) == 3
    assert fb.verificar_cadena()["ok"]
    fb.guardar_historial([{"ambito": "M", "actividad": "a", "_id": rid}])
    assert [r["actividad"] for r in fb.cargar_historial()] == ["b"]   # no resucita


def test_historial_heredado_sin_sello_se_sella(fb):
    fb.FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)
    fb.FEEDBACK_PATH.write_text(json.dumps([{"ambito": "M", "actividad": "viejo"}]),
                                encoding="utf-8")
    fb.guardar_historial([{"ambito": "M", "actividad": "nuevo"}])
    assert fb.verificar_cadena()["ok"]
    assert [r["actividad"] for r in fb.cargar_historial()] == ["viejo", "nuevo"]
