"""
tests/test_adjuntos_ole.py — Archivos incrustados en el Word con su icono
(modulos/adjuntos_ole.py). Sin coste y sin Microsoft Word: el fichero compuesto
se valida con olefile (lector independiente) y el .docx con python-docx/zip.
La apertura en Word real se comprobó a mano vía COM (ProgID e icono de los 6
tipos y bytes intactos tras «Guardar como»).
"""
from __future__ import annotations

import io
import os
import struct
import zipfile

import olefile
import pytest
from docx import Document
from PIL import Image

from modulos import adjuntos_ole as A


@pytest.mark.parametrize("tam", [0, 10, 4095, 4096, 50_000])
def test_paquete_ole_legible_y_con_el_archivo_intacto(tam):
    datos = os.urandom(tam)
    ole = olefile.OleFileIO(io.BytesIO(A.paquete_ole("Acta comité.msg", datos)))
    assert sorted(ole.listdir()) == [["\x01CompObj"], ["\x01Ole10Native"], ["\x03ObjInfo"]]
    assert ole.root.clsid.upper() == "0003000C-0000-0000-C000-000000000046"
    nativo = ole.openstream("\x01Ole10Native").read()
    assert struct.unpack("<I", nativo[:4])[0] == len(nativo) - 4
    assert nativo.endswith(datos)
    assert b"Acta comit\xe9.msg\x00" in nativo            # etiqueta en ANSI


def test_fichero_compuesto_grande_usa_difat():
    """Más de 109 sectores de FAT (~7 MB) obliga a escribir sectores DIFAT."""
    datos = os.urandom(8_000_000)
    blob = A.fichero_compuesto({"grande": datos})
    assert struct.unpack("<I", blob[0x48:0x4C])[0] >= 1          # n.º de sectores DIFAT
    assert olefile.OleFileIO(io.BytesIO(blob)).openstream("grande").read() == datos


def test_fichero_compuesto_con_muchos_flujos():
    flujos = {f"s{i:0{i % 5 + 1}d}": os.urandom(i * 700) for i in range(1, 12)}
    ole = olefile.OleFileIO(io.BytesIO(A.fichero_compuesto(flujos)))
    assert all(ole.openstream(k).read() == v for k, v in flujos.items())


@pytest.mark.parametrize("nombre, fam", [("a.xlsx", "excel"), ("b.csv", "excel"),
                                         ("c.docx", "word"), ("d.pptx", "powerpoint"),
                                         ("e.msg", "outlook"), ("f.eml", "outlook"),
                                         ("g.pdf", "pdf"), ("h.zzz", "generico")])
def test_familia_e_icono(tmp_path, nombre, fam):
    assert A.familia(nombre) == fam
    png = A.icono_png(nombre * 6, tmp_path / "i.png")          # nombre largo: 2 líneas
    with Image.open(png) as im:
        assert im.size == (A._ANCHO, A._ALTO)


def _docx_con(tmp_path, nombres):
    doc = Document()
    for n in nombres:
        f = tmp_path / n
        f.write_bytes(b"contenido de " + n.encode())
        A.incrustar(doc, doc.add_paragraph(), f, n, tmp_path / "iconos")
    ruta = tmp_path / "x.docx"
    doc.save(ruta)
    return zipfile.ZipFile(ruta)


def test_office_moderno_va_nativo_y_el_resto_como_paquete(tmp_path):
    z = _docx_con(tmp_path, ["Backtesting.xlsx", "Acta.docx", "ALCO.pptx", "Correo.msg", "Manual.pdf"])
    xml = z.read("word/document.xml").decode()
    for progid in ("Excel.Sheet.12", "Word.Document.12", "PowerPoint.Show.12"):
        assert f'ProgID="{progid}"' in xml
    assert xml.count('ProgID="Package"') == 2
    assert xml.count('DrawAspect="Icon"') == 5
    assert xml.count('id="_x0000_t75"') == 1                   # tipo de forma, una sola vez
    emb = sorted(n for n in z.namelist() if n.startswith("word/embeddings/"))
    assert sorted(n.rsplit(".", 1)[1] for n in emb) == ["bin", "bin", "docx", "pptx", "xlsx"]
    assert z.read([n for n in emb if n.endswith(".xlsx")][0]) == b"contenido de Backtesting.xlsx"
    tipos = z.read("[Content_Types].xml").decode()
    assert "spreadsheetml.sheet" in tipos and "officedocument.oleObject" in tipos
    rels = z.read("word/_rels/document.xml.rels").decode()
    assert rels.count("relationships/package") == 3 and rels.count("relationships/oleObject") == 2
    for n in (n for n in emb if n.endswith(".bin")):
        nativo = olefile.OleFileIO(io.BytesIO(z.read(n))).openstream("\x01Ole10Native").read()
        assert nativo.endswith(b"contenido de Correo.msg") or nativo.endswith(b"contenido de Manual.pdf")
