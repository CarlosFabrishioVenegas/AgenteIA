# -*- coding: utf-8 -*-
"""
SEG-11 · Repositorio de código: ninguna guía ni configuración apunta a nubes de
código no autorizadas, y los remotos git solo pueden ser el repositorio
corporativo (Azure DevOps).
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "scripts"))
import verificar_remoto_git as vr  # noqa: E402
sys.path.remove(str(RAIZ / "scripts"))


@pytest.mark.parametrize("url", [
    "https://dev.azure.com/bcp/riesgos/_git/virf",
    "git@ssh.dev.azure.com:v3/bcp/riesgos/virf",
    "https://bcp.visualstudio.com/riesgos/_git/virf",
])
def test_azure_devops_autorizado(url, monkeypatch):
    monkeypatch.delenv("VIRF_REPO_CORPORATIVO", raising=False)
    assert vr.remoto_autorizado(url)


@pytest.mark.parametrize("url", [
    "https://github.com/alguien/virf.git",
    "git@github.com:alguien/virf.git",
    "https://gitlab.com/alguien/virf",
    "https://bitbucket.org/x/virf",
    "https://dev.azure.com.atacante.io/x/_git/virf",
])
def test_nubes_no_autorizadas(url, monkeypatch):
    monkeypatch.delenv("VIRF_REPO_CORPORATIVO", raising=False)
    assert not vr.remoto_autorizado(url)


def test_url_corporativa_fijada_restringe_a_un_repo(monkeypatch):
    monkeypatch.setenv("VIRF_REPO_CORPORATIVO", "https://dev.azure.com/bcp/riesgos/_git/virf")
    assert vr.remoto_autorizado("https://dev.azure.com/bcp/riesgos/_git/virf.git")
    assert not vr.remoto_autorizado("https://dev.azure.com/otra-org/x/_git/virf")


def test_salida_de_git_remote_con_github_falla():
    salida = ("origin\thttps://dev.azure.com/bcp/r/_git/virf (fetch)\n"
              "espejo\tgit@github.com:alguien/virf.git (push)\n")
    assert vr.no_autorizados(salida) == ["git@github.com:alguien/virf.git"]


def test_remotos_actuales_del_repo_autorizados():
    assert vr.no_autorizados() == []


_OPERATIVA = re.compile(
    r"(?i)(git\s+(remote|clone|push)|repositorio|repo\b|remoto|origin).*\b(github|gitlab|bitbucket)\b"
    r"|\b(github|gitlab|bitbucket)\b.*(git\s+(remote|clone|push)|repositorio|repo\b|remoto)")


def test_guias_no_instruyen_subir_a_nubes_no_autorizadas():
    ficheros = [f for f in subprocess.run(
        ["git", "ls-files", "-z", "*.md", "*.txt", "*.yml", "*.yaml", "*.cfg"],
        cwd=RAIZ, capture_output=True, text=True, encoding="utf-8").stdout.split(chr(0)) if f]
    infractores = []
    for rel in ficheros:
        if rel.startswith("archivo/"):
            continue                                   # código archivado, no operativo
        for n, linea in enumerate((RAIZ / rel).read_text(encoding="utf-8", errors="ignore")
                                  .splitlines(), 1):
            if _OPERATIVA.search(linea):
                infractores.append(f"{rel}:{n}")
    assert infractores == [], infractores
