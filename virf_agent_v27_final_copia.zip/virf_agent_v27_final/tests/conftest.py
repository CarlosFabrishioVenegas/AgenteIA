"""
tests/conftest.py
═══════════════════════════════════════════════════════════════════════════════
Aislamiento del estado mutable del proyecto durante los tests.

[AUDIT-FIX PENDIENTE-1 · defecto introducido y corregido en la misma sesión]

Qué pasó
────────
Al añadirse el registro append-only de emisiones, `custodia.sellar_y_escribir()`
pasó a anotar cada informe sellado en `audit_logs/registro_emisiones.jsonl`. Los
tests que ya existían sellaban informes contra `tmp_path` —correctamente
aislados en cuanto a `outputs/`— pero el registro tiene una ruta por DEFECTO que
apunta al proyecto real. Resultado medido tras dos pasadas de la suite:

    $ wc -l audit_logs/registro_emisiones.jsonl
    59        ← 58 de tests, 1 de la única emisión real

El daño no es el fichero sucio: es que el registro de emisiones es EVIDENCIA
REGULATORIA. Un auditor que lo abra ve 58 emisiones de modelos llamados «M» y
«LaR_A» que nunca existieron, y a partir de ahí ninguna línea del fichero
prueba nada. Un control de integridad contaminado es peor que no tenerlo,
porque se presenta como prueba.

Es exactamente el defecto del §3.7 del prompt de continuidad —«tests que
dependen del estado mutable del proyecto»— pero en su versión inversa: aquí el
test no leía el estado real, lo ESCRIBÍA.

Por qué se corrige aquí y no en el código de producción
───────────────────────────────────────────────────────
La tentación es que `registrar_emision()` detecte que corre bajo pytest y no
escriba. Se descarta: sería una heurística silenciosa dentro de un control de
cumplimiento, y el día que la detección fallara —o que alguien ejecutara el
agente desde un proceso que la disparase por accidente— el registro dejaría de
anotar emisiones REALES sin que nada avisara. Un control que se apaga solo bajo
condiciones que nadie declara es justo lo que este proyecto no admite.

La corrección va en el arnés de test, que es donde está el problema: un fixture
`autouse` redirige el registro a `tmp_path` para TODOS los tests, los actuales y
los que se escriban después. Ninguno tiene que acordarse de aislarlo.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))


@pytest.fixture(autouse=True)
def _registro_emisiones_aislado(tmp_path, monkeypatch):
    """
    Redirige el registro de emisiones a `tmp_path` durante cada test.

    `autouse=True` y sin opción de desactivarlo: que un test pueda escribir en
    la evidencia regulatoria del proyecto no es una capacidad que convenga
    ofrecer. Los tests que necesitan inspeccionar el registro le pasan su propia
    ruta a `verificar_emisiones(..., ruta_registro=...)`, que es explícito.
    """
    try:
        from modulos import registro_emisiones
    except ImportError:                                    # pragma: no cover
        return
    monkeypatch.setattr(
        registro_emisiones, "RUTA_REGISTRO",
        tmp_path / "audit_logs_test" / "registro_emisiones.jsonl")


@pytest.fixture(autouse=True)
def _virf_plus_aislado(tmp_path, monkeypatch):
    """
    VIRF PLUS apagado por defecto y su bitácora fuera de `audit_logs/`.

    El botón de la web escribe VIRF_PLUS=1 en el `.env`, que `load_dotenv`
    vuelca al entorno: sin esto, encenderlo para trabajar convertiría cada test
    de un solo proveedor en una doble llamada real. Los tests de VIRF PLUS lo
    encienden explícitamente con `monkeypatch.setenv("VIRF_PLUS", "1")`.
    """
    monkeypatch.delenv("VIRF_PLUS", raising=False)
    monkeypatch.setenv("VIRF_PLUS_LOG", str(tmp_path / "virf_plus_consenso.jsonl"))


@pytest.fixture
def simular_aprobacion(monkeypatch):
    """
    [SEG-01] Simula que el banco APROBÓ proveedores que hoy están bloqueados
    (anthropic EN_ESPERA, openai RETIRADO). Solo para tests que ejercitan la
    mecánica interna de esos clientes o de VIRF PLUS, que se conservan para
    cuando el banco cambie el estado. El bloqueo REAL lo fija
    tests/test_proveedores_ia.py sin esta fixture.
    """
    import config.ia as _cia

    def _aprobar(*proveedores):
        for prov in proveedores:
            monkeypatch.setitem(_cia.PROVEEDORES, prov, "APROBADO")
    return _aprobar


@pytest.fixture(autouse=True)
def _secretos_de_test(tmp_path, monkeypatch):
    """
    [SEG-03] Los tests leen credenciales SIMULADAS del entorno del proceso
    (`VIRF_FUENTE_SECRETOS=entorno`) y nunca miran el `.env` real del equipo:
    la comprobación de «clave en texto plano» apunta a un `.env` vacío temporal.
    """
    import config.secretos as _sec
    monkeypatch.setenv("VIRF_FUENTE_SECRETOS", "entorno")
    # Fuera de producción el proveedor se deduce de la clave presente: una clave
    # real del equipo (entorno o .env cargado) cambiaría qué proveedor usan los
    # tests. Cada test pone las credenciales simuladas que necesita.
    for _var in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "AZURE_OPENAI_API_KEY"):
        monkeypatch.delenv(_var, raising=False)
    # [SEG-06] Clave de cifrado en reposo SIMULADA; entorno = portátil.
    monkeypatch.setenv("VIRF_CLAVE_CIFRADO_REPOSO", "clave-reposo-de-test-" + "y" * 40)
    monkeypatch.delenv("VIRF_ENTORNO", raising=False)
    import modulos.almacenamiento as _alm
    monkeypatch.setattr(_alm, "REGISTRO", tmp_path / "clasificacion_ficheros.json")
    # [SEG-13] El default en código es MODO=produccion; los tests corren, como
    # cualquier desarrollo local, declarando explícitamente MODO=debug.
    import config.parametros as _par
    monkeypatch.setattr(_par, "MODO", "debug")
    # [SEG-16] El NLI (una llamada extra por evaluación) va activo en producción;
    # los tests lo encienden explícitamente cuando lo prueban.
    monkeypatch.setattr(_par, "ENTAILMENT_ACTIVO", False)
    # [SEG-12] El log de auditoría de los tests va a tmp, nunca a audit_logs/.
    monkeypatch.setenv("VIRF_AUDITORIA_LOG", str(tmp_path / "auditoria_test.jsonl"))
    # [SEG-02] Clave de firma de aserciones SIMULADA y ninguna sesión heredada.
    monkeypatch.setenv("VIRF_CLAVE_FIRMA_SESION", "clave-de-test-" + "x" * 40)
    monkeypatch.delenv("VIRF_ASERCION_IDENTIDAD", raising=False)
    monkeypatch.delenv("VIRF_ASERCION_IDENTIDAD_2", raising=False)
    monkeypatch.setattr(_sec, "RUTA_ENV", tmp_path / ".env_inexistente")
    _sec.limpiar_cache()


@pytest.fixture
def firmar_como(monkeypatch):
    """
    [SEG-02] Simula que la web lanzó la corrida con la sesión SSO de una persona:
    pone en el entorno la aserción firmada que emitiría `pipeline_runner`.
    `firmar_como("Ana Pérez", "Validador", segunda=False)`.
    """
    from config.identidad import VAR_ASERCION, VAR_ASERCION_2, Identidad, emitir_asercion

    def _firmar(nombre, cargo="Validador", segunda=False, oid=None):
        ident = Identidad(oid=oid or "oid-" + nombre.lower().replace(" ", "-"),
                          upn=nombre.lower().replace(" ", ".") + "@bcp.com.pe",
                          nombre=nombre, cargo=cargo)
        monkeypatch.setenv(VAR_ASERCION_2 if segunda else VAR_ASERCION, emitir_asercion(ident))
        return ident
    return _firmar
