# -*- coding: utf-8 -*-
"""
SEG-10 · Clasificación de informes: ningún Word sale sin la etiqueta
«Datos elaborados por BCP para uso Interno» en el pie de todas sus secciones.
"""
from __future__ import annotations

import ast
import contextlib
import io
from pathlib import Path

import pytest
from docx import Document
from docx.enum.section import WD_SECTION

from modulos import clasificacion_docx as cd
from modulos import plantilla_bcp as PB

RAIZ = Path(__file__).resolve().parent.parent
ETIQUETA = "Datos elaborados por BCP para uso Interno"


def _inf():
    return {
        "tipo": "primera_vez", "nombre_modelo": "M", "fecha_inicio": "2026-10-01",
        "fecha_entrega": "2026-10-20", "ambitos": ["Gobierno"],
        "controles": [{"id": "1", "ambito": "Gobierno", "control": "C", "actividad": "A"}],
        "observaciones": [],
    }


def test_etiqueta_por_defecto():
    assert cd.etiqueta_por_defecto() == ETIQUETA


def test_plantilla_lleva_la_etiqueta_en_todas_las_secciones(tmp_path):
    ruta = PB.generar(_inf(), tmp_path / "x.docx")
    doc = Document(str(ruta))
    assert len(doc.sections) >= 1
    assert cd.pies_sin_etiqueta(ruta) == []
    assert ETIQUETA in "\n".join(p.text for p in doc.sections[0].footer.paragraphs)


def test_entregable_del_pipeline_lleva_la_etiqueta(tmp_path):
    from modulos.generador_word import generar_word_informe
    with contextlib.redirect_stdout(io.StringIO()):
        ruta = generar_word_informe(
            resumen_ejecutivo="Modelo.", evaluaciones_por_ambito={"Metodología": [
                {"actividad": "X", "puntaje": 3, "concepto": "c", "observacion": "o"}]},
            scores_por_ambito={"Metodología": 3}, score_global=3, titulo_modelo="VaR",
            tier="II", outputs_dir=tmp_path,
            validacion_humana={"validador": "Ana", "cargo": "2LoD"},
            fecha_inicio="2026-10-01", fecha_entrega="2026-10-30")
    assert cd.pies_sin_etiqueta(ruta) == []


def test_documento_con_varias_secciones_y_primera_pagina_distinta(tmp_path):
    doc = Document()
    doc.add_paragraph("uno")
    s2 = doc.add_section(WD_SECTION.NEW_PAGE)
    s2.footer.is_linked_to_previous = False
    s2.different_first_page_header_footer = True
    doc.add_paragraph("dos")
    assert cd.pies_sin_etiqueta(doc) != []
    cd.aplicar(doc)
    cd.aplicar(doc)                                   # idempotente
    p = tmp_path / "multi.docx"; doc.save(p)
    assert cd.pies_sin_etiqueta(p) == []
    textos = [pp.text for pp in Document(str(p)).sections[1].footer.paragraphs]
    assert textos.count(ETIQUETA) == 1


def test_clasificacion_parametrizable(tmp_path, monkeypatch):
    monkeypatch.setenv("VIRF_CLASIFICACION_INFORME", "Datos elaborados por BCP para uso Restringido")
    ruta = PB.generar(_inf(), tmp_path / "r.docx")
    assert cd.pies_sin_etiqueta(ruta, "Datos elaborados por BCP para uso Restringido") == []
    inf = {**_inf(), "clasificacion": "Etiqueta por informe"}
    ruta2 = PB.generar(inf, tmp_path / "r2.docx")
    assert cd.pies_sin_etiqueta(ruta2, "Etiqueta por informe") == []


def _guardados_de_docx():
    """(fichero, función, línea) de cada `doc.save(...)` sobre un Document."""
    for base in ("modulos", "web", "scripts", "motor"):
        for p in (RAIZ / base).rglob("*.py"):
            src = p.read_text(encoding="utf-8", errors="ignore")
            if "docx" not in src:
                continue
            arbol = ast.parse(src)
            for fn in ast.walk(arbol):
                if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                cuerpo = ast.unparse(fn)
                if "Document(" not in cuerpo:
                    continue
                for n in ast.walk(fn):
                    if (isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                            and n.func.attr == "save"
                            and ast.unparse(n.func.value) == "doc"):
                        yield p.relative_to(RAIZ).as_posix(), fn.name, n.lineno, cuerpo


def test_todo_guardado_de_word_aplica_la_clasificacion():
    vistos = list(_guardados_de_docx())
    assert len(vistos) >= 4, "el test no está encontrando los generadores de Word"
    sin = [f"{f}:{l} ({fn})" for f, fn, l, cuerpo in vistos if "_clasificar(" not in cuerpo]
    assert sin == [], sin
