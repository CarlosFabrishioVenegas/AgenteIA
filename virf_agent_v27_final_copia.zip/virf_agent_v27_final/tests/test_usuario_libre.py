# -*- coding: utf-8 -*-
"""
Usuario libre (web v2, modo prueba) — el SSO corporativo queda para la web v3.

  · Solo existe con VIRF_IDENTIDAD_PROVEEDOR=libre declarado y MODO≠produccion.
  · La identidad queda marcada como de prueba (dominio y cargo), nunca pasa
    por una corporativa.
  · Los roles se limitan a la lista cerrada y siguen aplicándose.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import config.identidad as idn
import config.parametros as par

RAIZ = Path(__file__).resolve().parents[1]


@pytest.fixture(autouse=True)
def _aislar(monkeypatch, tmp_path):
    from web.services import sesion_store
    monkeypatch.setenv("VIRF_CLAVE_FIRMA_SESION", "k" * 48)
    monkeypatch.setattr(sesion_store, "VALIDADORES", tmp_path / "validadores.json")
    monkeypatch.setattr(sesion_store, "DATA_DIR", tmp_path)


@pytest.fixture
def cliente_libre(monkeypatch):
    monkeypatch.setenv("VIRF_IDENTIDAD_PROVEEDOR", "libre")
    from web.app import app
    return TestClient(app, base_url="https://testserver")


def _entrar(cliente, nombre="Ana Quispe", roles=("validador",), cargo="Analista"):
    return cliente.post("/api/auth/login-libre",
                        json={"nombre": nombre, "cargo": cargo, "roles": list(roles)})


def test_identidad_libre_va_marcada_como_prueba():
    i = idn.ProveedorLibre.identidad("Ana  Quispe", "Analista", ["revisor", "validador", "root"])
    assert i.upn == "ana.quispe@prueba.local"
    assert i.cargo == "Analista · usuario de prueba (sin SSO)"
    assert i.codigo.startswith("PRUEBA_") and i.oid.startswith("prueba-")
    assert i.roles == ("validador", "revisor")            # «root» descartado


@pytest.mark.parametrize("nombre, roles", [("A", ["validador"]), ("Ana", []), ("Ana", ["root"])])
def test_identidad_libre_rechaza_datos_invalidos(nombre, roles):
    with pytest.raises(ValueError):
        idn.ProveedorLibre.identidad(nombre, "", roles)


def test_usuario_libre_prohibido_en_produccion(monkeypatch, cliente_libre):
    monkeypatch.setattr(par, "MODO", "produccion")
    with pytest.raises(idn.IdentidadNoConfigurada, match="produccion"):
        idn.ProveedorLibre()
    r = _entrar(cliente_libre)
    assert r.status_code == 503 and "virf_token" not in r.cookies


def test_sin_declarar_libre_el_endpoint_no_existe(monkeypatch):
    monkeypatch.delenv("VIRF_IDENTIDAD_PROVEEDOR", raising=False)
    from web.app import app
    c = TestClient(app, base_url="https://testserver")
    assert c.get("/api/auth/modo").json() == {"proveedor": "entra"}
    assert _entrar(c).status_code == 503


def test_login_libre_crea_sesion_marcada(cliente_libre):
    assert cliente_libre.get("/api/auth/modo").json() == {"proveedor": "libre"}
    r = _entrar(cliente_libre)
    assert r.status_code == 200 and r.json()["prueba"] is True
    v = cliente_libre.get("/api/auth/actual").json()["validador"]
    assert v["upn"] == "ana.quispe@prueba.local" and "usuario de prueba" in v["cargo"]


def test_login_libre_respeta_roles(cliente_libre):
    assert _entrar(cliente_libre, roles=["validador"]).status_code == 200
    assert cliente_libre.get("/api/feedback/pendientes").status_code == 403   # requiere revisor
    assert _entrar(cliente_libre, nombre="Luis Gomez", roles=["revisor"]).status_code == 200
    assert cliente_libre.get("/api/feedback/pendientes").status_code == 200


def test_login_libre_queda_en_la_auditoria(cliente_libre):
    from modulos import auditoria
    _entrar(cliente_libre)
    [e] = [e for e in auditoria.leer() if e["accion"] == "login_prueba"]
    assert e["quien"] == "ana.quispe@prueba.local" and e["resultado"].startswith("ok")


def test_el_sso_por_redireccion_no_se_usa_en_modo_libre(cliente_libre):
    assert cliente_libre.get("/api/auth/login", follow_redirects=False).status_code == 503


def test_lanzador_declara_modo_prueba_sin_pisar_claves_dadas():
    sys.path.insert(0, str(RAIZ / "scripts"))
    import web_prueba
    ent = {"MODO": "produccion", "VIRF_CLAVE_CIFRADO_REPOSO": "c" * 40}
    generadas = web_prueba.preparar_entorno(ent)
    assert ent["MODO"] == "debug" and ent["VIRF_IDENTIDAD_PROVEEDOR"] == "libre"
    assert ent["VIRF_FUENTE_SECRETOS"] == "entorno"
    assert ent["VIRF_CLAVE_CIFRADO_REPOSO"] == "c" * 40
    assert generadas == ["VIRF_CLAVE_FIRMA_SESION"] and len(ent["VIRF_CLAVE_FIRMA_SESION"]) >= 32
