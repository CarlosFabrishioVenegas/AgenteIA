# -*- coding: utf-8 -*-
"""
SEG-12 · Auditoría de acciones web.

Cada acción sensible produce EXACTAMENTE una entrada con quién, qué, cuándo,
desde dónde y resultado; el log es solo-anexar y encadenado (editar o borrar
una línea se detecta); las llamadas a IA quedan atribuidas a la persona.
"""
from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from config.identidad import Identidad
from modulos import auditoria
from web.services import sesion_store

ANA = Identidad(oid="oid-ana", upn="ana.quispe@bcp.com.pe", nombre="Ana Quispe",
                codigo="T5443", roles=("validador",))
ADMIN = Identidad(oid="oid-adm", upn="admin@bcp.com.pe", nombre="Admin", codigo="T9000",
                  roles=("admin_corpus",))


@pytest.fixture
def cliente(monkeypatch, tmp_path):
    monkeypatch.setattr(sesion_store, "VALIDADORES", tmp_path / "validadores.json")
    monkeypatch.setattr(sesion_store, "DATA_DIR", tmp_path)
    monkeypatch.setenv("VIRF_IDENTIDAD_PROVEEDOR", "simulado")
    sesion_store._sesiones.clear()
    from web.app import app
    return TestClient(app, base_url="https://testserver")


def _como(cliente, ident):
    tok, _ = sesion_store.crear_sesion(ident)
    cliente.cookies.set("virf_token", tok)


def _entradas(accion=None):
    return [e for e in auditoria.leer() if accion is None or e["accion"] == accion]


# ── Log ──────────────────────────────────────────────────────────────────────

def test_entrada_tiene_quien_que_cuando_donde_resultado():
    e = auditoria.registrar("prueba", "objeto-1", quien="ana@bcp.com.pe", desde="10.0.0.5")
    for campo in ("quien", "accion", "objeto", "cuando", "desde", "resultado", "hash"):
        assert e[campo], campo
    assert e["cuando"].endswith("+00:00")


def test_solo_anexar_y_verificable():
    for i in range(3):
        auditoria.registrar("prueba", i)
    assert auditoria.verificar() == {"ok": True, "n": 3, "roto_en": None}
    p = auditoria.ruta_log()
    lineas = p.read_text(encoding="utf-8").splitlines()
    alterada = json.loads(lineas[1]); alterada["quien"] = "otra persona"
    lineas[1] = json.dumps(alterada)
    p.write_text("\n".join(lineas) + "\n", encoding="utf-8")
    assert auditoria.verificar()["roto_en"] == 1


def test_borrar_una_linea_se_detecta():
    for i in range(3):
        auditoria.registrar("prueba", i)
    p = auditoria.ruta_log()
    lineas = p.read_text(encoding="utf-8").splitlines()
    p.write_text("\n".join([lineas[0], lineas[2]]) + "\n", encoding="utf-8")
    assert auditoria.verificar()["ok"] is False


def test_ningun_endpoint_sirve_ni_edita_el_log(cliente):
    rutas = cliente.app.openapi()["paths"]
    assert not [r for r in rutas if "auditoria" in r]


# ── Cada acción → exactamente una entrada ────────────────────────────────────

def test_login_y_logout(cliente):
    r = cliente.get("/api/auth/login", follow_redirects=False)
    state = r.headers["location"].split("state=")[1]
    cliente.get(f"/api/auth/callback?state={state}&code=secreto-oidc", follow_redirects=False)
    cliente.post("/api/auth/logout")
    login, logout = _entradas("login"), _entradas("logout")
    assert len(login) == 1 and len(logout) == 1
    assert login[0]["quien"] == "ana.quispe@bcp.com.pe" and login[0]["oid"]
    assert logout[0]["quien"] == "ana.quispe@bcp.com.pe"
    assert "secreto-oidc" not in json.dumps(login[0])        # el code OIDC no se guarda


def test_intento_denegado_tambien_queda(cliente):
    _como(cliente, ANA)
    cliente.post("/api/rag/dominios/crear", json={"nombre": "Nuevo", "descripcion": "x", "palabras_clave": []})
    e = _entradas("alta_dominio_rag")
    assert len(e) == 1 and e[0]["resultado"] == "http_403"
    assert e[0]["quien"] == "ana.quispe@bcp.com.pe" and e[0]["desde"]


@pytest.mark.parametrize("metodo, ruta, accion, kw", [
    ("delete", "/api/rag/dominios/xyz", "borrado_dominio_rag", {}),
    ("delete", "/api/rag/dominios/xyz/paper/a.pdf", "borrado_paper_rag", {}),
    ("post", "/api/rag/reconstruir", "reindexado_rag", {"json": {"dominio": "zz"}}),
    ("post", "/api/prompts/editar", "cambio_prompt", {"json": {"prompt_id": "p", "contenido": "c"}}),
    ("post", "/api/inputs/upload?destino=rag_LaR&clasificacion=Publico", "subida",
     {"files": {"archivos": ("a.pdf", b"%PDF", "application/pdf")}}),
    ("delete", "/api/inputs/archivo/rag_LaR/a.pdf", "borrado_archivo", {}),
    ("get", "/api/informe/descargar/x.docx", "descarga_informe", {}),
])
def test_cada_accion_una_entrada(cliente, metodo, ruta, accion, kw):
    _como(cliente, ADMIN)
    getattr(cliente, metodo)(ruta, **kw)
    e = _entradas(accion)
    assert len(e) == 1, (accion, auditoria.leer())
    assert e[0]["quien"] == "admin@bcp.com.pe"
    assert len(auditoria.leer()) == 1                        # y nada más


def test_lectura_normal_no_genera_ruido(cliente):
    _como(cliente, ANA)
    cliente.get("/api/auth/actual")
    cliente.get("/api/rag/dominios")
    assert auditoria.leer() == []


def test_llamada_a_ia_atribuida_a_la_persona(cliente):
    from config.ia import ClienteIA

    class _Falso(ClienteIA):
        PROVEEDOR = "azure_openai"
        def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                            sistema=None, formato_json=False):
            return "ok"
        def validar_conexion(self):
            return True

    tk = auditoria.contexto_web.set({"quien": "ana.quispe@bcp.com.pe", "oid": "oid-ana",
                                     "desde": "10.0.0.7"})
    try:
        _Falso().generar_mensaje(prompt="DNI 45678912")
    finally:
        auditoria.contexto_web.reset(tk)
    e = _entradas("llamada_ia")
    assert len(e) == 1
    assert e[0]["quien"] == "ana.quispe@bcp.com.pe" and e[0]["desde"] == "10.0.0.7"
    assert e[0]["detalle"]["proveedor"] == "azure_openai"
    assert "45678912" not in json.dumps(e[0])
