"""
tests/test_aprendizaje_chat.py — WP-D: el chat guarda correcciones como feedback
(contexto + ajuste automático en futuras corridas). Coste 0; historial aislado.
"""
import pytest


@pytest.fixture()
def feedback_aislado(tmp_path, monkeypatch):
    """Redirige el historial de feedback a un fichero temporal para no tocar el real."""
    import modulos.feedback as fb
    monkeypatch.setattr(fb, "FEEDBACK_PATH", tmp_path / "historial_feedback.json")
    return fb


def _datos():
    return {
        "modelo": "Modelo LaR (prueba)", "tier": "I",
        "agente": {"agente_version": "27.1"},
        "resultados_por_ambito": {"Metodología": [
            {"actividad": "Control de no-negativos", "puntaje": 2, "evaluacion_valida": True},
        ]},
    }


def test_aprobado_se_guarda_como_correccion(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "APROBADO", "hallazgo_final": "El validador aportó el manual v4.3",
            "adjuntos": ["manual_var.pdf"]}]
    r = fb.registrar_aprendizaje_desde_chat(_datos(), obs,
                                            {"validador": "QA", "cargo": "Val"}, sesion_id="s1")
    assert r["nuevos"] == 1
    hist = fb.cargar_historial()
    assert len(hist) == 1
    reg = hist[0]
    assert reg["puntaje_agente"] == 2 and reg["puntaje_correcto"] == 5
    assert reg["diferencia"] == 3
    # Subsanación: es el puntaje FINAL, no un error del agente → no calibra.
    assert reg["calibra"] is False and reg["tipo_correccion"] == "subsanacion"
    assert "manual_var.pdf" in reg["comentario"]
    assert reg["origen"] == "chat_sustentacion"


def test_idempotente_por_sesion(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "APROBADO"}]
    fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    r2 = fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    assert r2["nuevos"] == 0            # no duplica
    assert r2["total"] == 1


def test_pendiente_no_se_aprende(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "PENDIENTE"}]
    r = fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    assert r["nuevos"] == 0


def test_la_correccion_entra_como_contexto_futuro(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "APROBADO", "hallazgo_final": "faltó reconocer el control de no-negativos"}]
    fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    # [Paso 25] Pendiente: todavía no influye.
    assert fb.construir_contexto_feedback("Metodología", "Control de no-negativos") == ""
    rid = fb.cargar_historial()[-1]["_id"]
    fb.aprobar_feedback(rid, quien="revisor@bcp.com.pe", oid="oid-revisor")
    ctx = fb.construir_contexto_feedback("Metodología", "Control de no-negativos")
    assert "HISTORIAL DE FEEDBACK" in ctx
    assert "no-negativos" in ctx
    # Entra como contexto, pero NO como «el agente subestimó».
    assert "SUBSANADA" in ctx and "subestimó" not in ctx


def test_subsanacion_aprobada_no_mueve_puntajes_ni_sesgo(feedback_aislado, monkeypatch):
    """Muchas observaciones cerradas en el chat no pueden volver complaciente al agente."""
    fb = feedback_aislado
    monkeypatch.setenv("VIRF_PUNTAJE_CUMPLE", "5")
    import config.parametros as par
    import modulos.feedback_mejorado as fm
    monkeypatch.setattr(par, "MIN_FEEDBACK_ANTISESGO", 2)
    monkeypatch.setattr(par, "MIN_MUESTRAS_AJUSTE", 2)
    for i in range(4):
        fb.registrar_aprendizaje_desde_chat(
            _datos(), [{"ambito": "Metodología", "actividad": "Control de no-negativos",
                        "veredicto": "APROBADO"}], {}, sesion_id=f"s{i}")
    for r in fb.cargar_historial():
        fb.aprobar_feedback(r["_id"], quien="rev", oid="oid-rev")
    assert len(fb.cargar_historial_aprobado()) == 4
    assert fb.cargar_historial_calibracion() == []
    assert fm.construir_bloque_aprendizaje("Metodología") == ""
    assert fm.ajustar_puntaje_por_feedback(
        "Metodología", "Control de no-negativos", 2.0)[0] == 2.0


def test_negado_confirma_al_agente_y_calibra(feedback_aislado):
    fb = feedback_aislado
    fb.registrar_aprendizaje_desde_chat(
        _datos(), [{"ambito": "Metodología", "actividad": "Control de no-negativos",
                    "veredicto": "NEGADO"}], {}, sesion_id="s1")
    reg = fb.cargar_historial()[0]
    assert reg["diferencia"] == 0 and reg["calibra"] is True


def test_registro_de_chat_antiguo_no_calibra(feedback_aislado):
    """Los registros previos al campo `calibra` guardaron la subsanación como +N."""
    fb = feedback_aislado
    assert fb.calibra_puntaje({"origen": "chat_sustentacion", "diferencia": 3}) is False
    assert fb.calibra_puntaje({"origen": "chat_sustentacion", "diferencia": 0}) is True
    assert fb.calibra_puntaje({"diferencia": -2}) is True      # corrección de consola


def _corr(i, estado=None):
    r = {"ambito": "Metodología", "actividad": f"Actividad {i}", "puntaje_agente": 4,
         "puntaje_correcto": 2, "diferencia": -2, "comentario": "faltan p-valores",
         "timestamp": str(i)}
    if estado:
        r["estado_aprobacion"] = estado
    return r


def test_bloque_aprendizaje_ignora_feedback_sin_aprobar(feedback_aislado, monkeypatch):
    """[Paso 25] Lo pendiente no instruye al agente, por mucho que haya."""
    fb = feedback_aislado
    import config.parametros as par
    import modulos.feedback_mejorado as fm
    monkeypatch.setattr(par, "MIN_FEEDBACK_ANTISESGO", 2)
    fb.guardar_historial([_corr(i) for i in range(5)])
    assert fm.construir_bloque_aprendizaje("Metodología") == ""
    for r in fb.cargar_historial():
        fb.aprobar_feedback(r["_id"], quien="rev", oid="oid-rev")
    assert "SOBRESTIMAR" in fm.construir_bloque_aprendizaje("Metodología")


def test_bloque_aprendizaje_exige_masa_critica(feedback_aislado, monkeypatch):
    """[D6] Un solo feedback aprobado no cambia la instrucción de todo el ámbito."""
    fb = feedback_aislado
    import config.parametros as par
    import modulos.feedback_mejorado as fm
    monkeypatch.setattr(par, "MIN_FEEDBACK_ANTISESGO", 15)
    fb.guardar_historial([_corr(1)])
    fb.aprobar_feedback(fb.cargar_historial()[0]["_id"], quien="rev", oid="oid-rev")
    assert fm.construir_bloque_aprendizaje("Metodología") == ""


def test_chat_guarda_oid_y_bloquea_autoaprobacion(feedback_aislado):
    fb = feedback_aislado
    fb.registrar_aprendizaje_desde_chat(
        _datos(), [{"ambito": "Metodología", "actividad": "Control de no-negativos",
                    "veredicto": "NEGADO"}],
        {"validador": "Ana", "cargo": "Val", "oid": "oid-ana"}, sesion_id="s1")
    reg = fb.cargar_historial()[0]
    assert reg["autor_oid"] == "oid-ana"
    with pytest.raises(PermissionError):
        fb.aprobar_feedback(reg["_id"], quien="ana@banco", oid="oid-ana")


def test_autoaprobacion_bloqueada_por_nombre_si_falta_oid(feedback_aislado):
    fb = feedback_aislado
    fb.guardar_historial([{**_corr(1), "validador": "Ana Ruiz"}])
    rid = fb.cargar_historial()[0]["_id"]
    with pytest.raises(PermissionError):
        fb.aprobar_feedback(rid, quien="ana ruiz", oid="oid-ana")
    fb.aprobar_feedback(rid, quien="Luis", oid="oid-luis")


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
