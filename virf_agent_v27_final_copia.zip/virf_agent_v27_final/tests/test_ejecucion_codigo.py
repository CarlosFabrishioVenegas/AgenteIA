# -*- coding: utf-8 -*-
"""
SEG-07 · Ejecución de código.

  · No existe exec/eval/compile(…, "exec") en el código de producción (AST).
  · META se lee con AST: un control con código malicioso NO se ejecuta.
  · El notebook generado por IA no corre sin aprobación humana registrada;
    aprobado, corre en un subproceso aislado sin secretos.
"""
from __future__ import annotations

import ast
from pathlib import Path

import nbformat as nbf
import pytest
from fastapi.testclient import TestClient

from config.identidad import Identidad
from modulos import aprobacion_codigo as ac
from modulos import repositorio_controles as rc

RAIZ = Path(__file__).resolve().parent.parent
_PROD = ["modulos", "motor", "web", "config", "src", "scripts"]


def _llamadas_peligrosas(p: Path):
    arbol = ast.parse(p.read_text(encoding="utf-8", errors="ignore"))
    for n in ast.walk(arbol):
        if isinstance(n, ast.Call):
            nombre = getattr(n.func, "id", None) or getattr(n.func, "attr", None)
            if nombre in ("exec", "eval"):
                yield n.lineno, nombre
            if nombre == "compile" and len(n.args) >= 3 and \
                    isinstance(n.args[2], ast.Constant) and n.args[2].value in ("exec", "eval"):
                yield n.lineno, "compile"


def test_no_hay_exec_ni_eval_en_produccion():
    infractores = []
    ficheros = [RAIZ / "agente.py"] + [p for d in _PROD for p in (RAIZ / d).rglob("*.py")]
    for p in ficheros:
        if "__pycache__" in p.parts:
            continue
        for linea, nombre in _llamadas_peligrosas(p):
            infractores.append(f"{p.relative_to(RAIZ)}:{linea} {nombre}")
    assert infractores == [], infractores


def test_guia_databricks_sin_exec():
    assert "exec(compile" not in (RAIZ / "docs/DESPLIEGUE_DATABRICKS.md").read_text(encoding="utf-8")


# ── META por AST ─────────────────────────────────────────────────────────────

def test_meta_malicioso_no_se_ejecuta(tmp_path):
    testigo = tmp_path / "pwned.txt"
    codigo = (f"open({str(testigo)!r}, 'w').write('ejecutado')\n"
              "import os\nos.environ['VIRF_PWNED'] = '1'\n"
              "META = {'dimension': 'Exactitud', 'params': {'umbral': 0.9}}\n"
              "def control(df, datasets, params):\n    return {}\n")
    meta, err = rc._extraer_meta(codigo, "malo.py")
    assert err is None and meta["params"]["umbral"] == 0.9
    assert not testigo.exists()
    import os
    assert "VIRF_PWNED" not in os.environ


def test_meta_calculado_se_rechaza():
    codigo = "import os\nMETA = dict(x=os.getcwd())\ndef control(df, d, p):\n    return {}\n"
    meta, err = rc._extraer_meta(codigo, "calc.py")
    assert meta is None and "literal" in err


def test_sin_funcion_control_se_rechaza():
    meta, err = rc._extraer_meta("META = {'a': 1}\n", "x.py")
    assert meta is None and "control" in err


def test_controles_reales_cargan_sin_ejecutar():
    controles, avisos = rc.cargar_controles("VaR")
    assert controles and avisos == []


# ── Notebook de IA: aprobación humana ────────────────────────────────────────

def _nb(codigo):
    nb = nbf.v4.new_notebook()
    nb.cells = [nbf.v4.new_code_cell(codigo)]
    return nb


def test_notebook_de_ia_no_se_ejecuta_sin_aprobacion(tmp_path):
    from modulos.excel_a_notebook import auto_validar
    testigo = tmp_path / "ia_ejecuto.txt"
    nb = _nb(f"open({str(testigo)!r}, 'w').write('x')\nresultado = 42\n")
    rep = auto_validar(nb, {}, {"outputs": [{"variable_python": "resultado"}]})
    assert rep["estado"] == ac.ESTADO_PENDIENTE and rep["ejecutable"] is None
    assert len(rep["hash_codigo"]) == 64
    assert not testigo.exists()
    with pytest.raises(ac.CodigoNoAprobado):
        ac.ejecutar_aprobado("x = 1")


def test_aprobado_se_ejecuta_aislado_y_sin_secretos(monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "no-debe-verse")
    codigo = "import os\nclave = os.environ.get('AZURE_OPENAI_API_KEY', 'ausente')\nresultado = 6 * 7\n"
    ac.aprobar(ac.hash_codigo(codigo), quien="revisor@bcp.com.pe", oid="oid-rev", motivo="revisado")
    r = ac.ejecutar_aprobado(codigo, ["resultado", "clave"])
    assert r["ok"] and r["valores"] == {"resultado": 42, "clave": "ausente"}


def test_aprobar_otro_codigo_no_habilita_este():
    ac.aprobar(ac.hash_codigo("a = 1"), quien="r", oid="o", motivo="revisado")
    with pytest.raises(ac.CodigoNoAprobado):
        ac.ejecutar_aprobado("a = 2")


def test_log_manipulado_invalida_aprobaciones():
    from modulos import auditoria
    codigo = "z = 1"
    ac.aprobar(ac.hash_codigo(codigo), quien="r", oid="o", motivo="revisado")
    assert ac.aprobado(ac.hash_codigo(codigo))
    p = auditoria.ruta_log()
    p.write_text(p.read_text(encoding="utf-8").replace('"quien": "r"', '"quien": "x"'),
                 encoding="utf-8")
    assert not ac.aprobado(ac.hash_codigo(codigo))


@pytest.fixture
def cliente(monkeypatch, tmp_path):
    from web.services import sesion_store
    from web.app import app
    monkeypatch.setattr(sesion_store, "VALIDADORES", tmp_path / "v.json")
    monkeypatch.setattr(sesion_store, "DATA_DIR", tmp_path)
    sesion_store._sesiones.clear()
    return TestClient(app, base_url="https://testserver")


@pytest.mark.parametrize("rol, esperado", [("revisor", 200), ("validador", 403),
                                           ("admin_corpus", 403)])
def test_solo_revisor_aprueba(cliente, rol, esperado):
    from web.services import sesion_store
    tok, _ = sesion_store.crear_sesion(Identidad(oid=f"oid-{rol}", upn=f"{rol}@bcp.com.pe",
                                                 nombre=rol, codigo=f"T{len(rol)}00",
                                                 roles=(rol,)))
    cliente.cookies.set("virf_token", tok)
    r = cliente.post("/api/codigo/aprobar", json={"hash": "a" * 64, "motivo": "revisado ok"})
    assert r.status_code == esperado
    assert ac.aprobado("a" * 64) is (esperado == 200)
