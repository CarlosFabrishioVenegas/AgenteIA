# -*- coding: utf-8 -*-
"""
SEG-14 · Databricks: identidad de servicio y mínimo dato necesario.

  · Ninguna lectura de Unity Catalog trae la tabla completa: columnas
    declaradas + filtro o límite, con tope duro.
  · Ni el código ni la guía usan un token personal (PAT).
  · En el código no hay `toPandas()` sin `select` y sin `where`/`limit`.
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

import pandas as pd
import pytest

from modulos import motores_datos as md

RAIZ = Path(__file__).resolve().parent.parent


class _SDF:
    def __init__(self, log, n=3):
        self.log, self.n = log, n

    def select(self, *cols):
        self.log.append(("select", cols)); return self

    def where(self, cond):
        self.log.append(("where", cond)); return self

    def limit(self, n):
        self.log.append(("limit", n)); return self

    def toPandas(self):
        self.log.append(("toPandas",)); return pd.DataFrame({"a": range(self.n)})


class _Spark:
    def __init__(self):
        self.log = []
        outer = self

        class _R:
            def table(self, t):
                outer.log.append(("table", t)); return _SDF(outer.log)
        self.read = _R()


def test_lectura_minima_empuja_columnas_filtro_y_limite():
    sp = _Spark()
    out = md.cargar_datasets_uc({"p": {"tabla": "riesgo.var.pos", "columnas": ["id", "valor"],
                                       "where": "fecha >= '2027-01-01'"}}, spark=sp)
    assert list(out) == ["p"]
    assert sp.log[:4] == [("table", "riesgo.var.pos"), ("select", ("id", "valor")),
                          ("where", "fecha >= '2027-01-01'"), ("limit", md.MAX_FILAS_UC)]


@pytest.mark.parametrize("spec, motivo", [
    ({"tabla": "t", "where": "x > 0"}, "columnas"),                    # SELECT *
    ({"tabla": "t", "columnas": ["*"], "where": "x > 0"}, "columnas"),
    ({"tabla": "t", "columnas": ["a"]}, "where"),                       # tabla completa
    ({"tabla": "t", "columnas": ["a"], "limite": md.MAX_FILAS_UC + 1}, "limite"),
    ({"columnas": ["a"], "limite": 10}, "tabla"),
])
def test_lecturas_no_minimas_se_rechazan(spec, motivo):
    sp = _Spark()
    with pytest.raises(md.LecturaNoMinima, match=motivo):
        md.cargar_datasets_uc({"p": spec}, spark=sp)
    assert ("toPandas",) not in sp.log


def test_limite_explicito_se_respeta():
    sp = _Spark()
    md.cargar_datasets_uc({"p": {"tabla": "t", "columnas": ["a"], "limite": 500}}, spark=sp)
    assert ("limit", 500) in sp.log and not any(e[0] == "where" for e in sp.log)


def test_ningun_topandas_sin_select_y_filtro_en_el_codigo():
    infractores = []
    for p in list((RAIZ / "modulos").rglob("*.py")) + list((RAIZ / "src").rglob("*.py")) \
            + list((RAIZ / "scripts").rglob("*.py")) + list((RAIZ / "motor").rglob("*.py")):
        src = p.read_text(encoding="utf-8", errors="ignore")
        if "toPandas" not in src:
            continue
        for fn in ast.walk(ast.parse(src)):
            if isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)) and "toPandas" in ast.unparse(fn):
                cuerpo = ast.unparse(fn)
                if ".select(" not in cuerpo or not re.search(r"\.(where|filter|limit)\(", cuerpo):
                    infractores.append(f"{p.relative_to(RAIZ)}:{fn.name}")
    assert infractores == [], infractores


def test_guia_sin_token_personal_ni_lectura_completa():
    g = (RAIZ / "docs" / "DESPLIEGUE_DATABRICKS.md").read_text(encoding="utf-8")
    assert "configure --token" not in g
    assert not re.search(r"read\.table\([^)]*\)\s*\.toPandas\(\)", g)
    assert not re.search(r"sdf\s*=\s*spark\.read\.table\(tabla\)\s*\n(?:.*\n){0,3}?.*toPandas", g)


def test_codigo_no_lee_tokens_de_databricks():
    for base in ("modulos", "config", "web", "motor", "scripts", "src"):
        for p in (RAIZ / base).rglob("*.py"):
            src = p.read_text(encoding="utf-8", errors="ignore")
            assert "DATABRICKS_TOKEN" not in src, p
