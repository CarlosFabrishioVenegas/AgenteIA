# -*- coding: utf-8 -*-
"""
SEG-02 · Identidad y firma.

  · Sin sesión → 401 en la web y el pipeline no firma.
  · El firmante = identidad autenticada (aserción firmada), nunca un nombre
    tecleado; intentar inyectar otro firmante falla.
  · Login SSO por el IdP (simulado SOLO aquí); sin alta al vuelo.
"""
from __future__ import annotations

import time

import pytest
from fastapi.testclient import TestClient

import config.identidad as idn
from config.identidad import Identidad

ANA = Identidad(oid="oid-ana", upn="ana.quispe@bcp.com.pe", nombre="Ana Quispe",
                cargo="Validador de Segunda Línea", codigo="T5443")
LUIS = Identidad(oid="oid-luis", upn="luis.gomez@bcp.com.pe", nombre="Luis Gómez",
                 cargo="Jefe de Validación", codigo="T7001")


@pytest.fixture(autouse=True)
def _clave_firma(monkeypatch, tmp_path):
    monkeypatch.setenv("VIRF_CLAVE_FIRMA_SESION", "k" * 48)
    monkeypatch.delenv(idn.VAR_ASERCION, raising=False)
    monkeypatch.delenv(idn.VAR_ASERCION_2, raising=False)
    from web.services import sesion_store
    monkeypatch.setattr(sesion_store, "VALIDADORES", tmp_path / "validadores.json")
    monkeypatch.setattr(sesion_store, "DATA_DIR", tmp_path)
    sesion_store._sesiones.clear()


# ── Aserción firmada ─────────────────────────────────────────────────────────

def test_asercion_ida_y_vuelta():
    assert idn.verificar_asercion(idn.emitir_asercion(ANA)) == ANA


def test_asercion_manipulada_falla():
    tok = idn.emitir_asercion(ANA)
    cuerpo, firma = tok.split(".")
    import base64, json
    carga = json.loads(base64.urlsafe_b64decode(cuerpo + "=" * (-len(cuerpo) % 4)))
    carga["nombre"] = "Otra Persona"
    falso = base64.urlsafe_b64encode(json.dumps(carga).encode()).decode().rstrip("=")
    with pytest.raises(idn.AsercionInvalida, match="manipulada"):
        idn.verificar_asercion(f"{falso}.{firma}")


def test_asercion_caducada_falla():
    tok = idn.emitir_asercion(ANA, ttl_s=-1)
    with pytest.raises(idn.AsercionInvalida, match="caducada"):
        idn.verificar_asercion(tok)


def test_asercion_con_otra_clave_falla(monkeypatch):
    tok = idn.emitir_asercion(ANA)
    monkeypatch.setenv("VIRF_CLAVE_FIRMA_SESION", "z" * 48)
    with pytest.raises(idn.AsercionInvalida):
        idn.verificar_asercion(tok)


def test_clave_corta_no_vale(monkeypatch):
    monkeypatch.setenv("VIRF_CLAVE_FIRMA_SESION", "corta")
    with pytest.raises(idn.IdentidadNoConfigurada):
        idn.emitir_asercion(ANA)


def test_simulado_no_existe_fuera_de_tests(monkeypatch):
    import sys
    monkeypatch.delitem(sys.modules, "pytest")
    with pytest.raises(idn.IdentidadNoConfigurada):
        idn.ProveedorSimulado()


def test_entra_sin_configuracion_da_error_claro(monkeypatch):
    for v in ("VIRF_ENTRA_TENANT_ID", "VIRF_ENTRA_CLIENT_ID", "VIRF_ENTRA_REDIRECT_URI"):
        monkeypatch.delenv(v, raising=False)
    monkeypatch.delenv("VIRF_IDENTIDAD_PROVEEDOR", raising=False)
    with pytest.raises(idn.IdentidadNoConfigurada, match="equipo de identidad"):
        idn.obtener_proveedor()


# ── Firmante del pipeline ────────────────────────────────────────────────────

def test_sin_sesion_el_pipeline_no_firma():
    from modulos.validador_humano import IdentidadRequerida, solicitar_identidad
    with pytest.raises(IdentidadRequerida, match="AUTENTICADO"):
        solicitar_identidad()


def test_firmante_es_la_identidad_autenticada(monkeypatch):
    from modulos.validador_humano import solicitar_identidad
    monkeypatch.setenv(idn.VAR_ASERCION, idn.emitir_asercion(ANA))
    f = solicitar_identidad()
    assert (f["validador"], f["cargo"], f["upn"]) == (
        "Ana Quispe", "Validador de Segunda Línea", "ana.quispe@bcp.com.pe")


def test_no_se_puede_teclear_otro_firmante(monkeypatch):
    from modulos.validador_humano import IdentidadRequerida, solicitar_identidad
    monkeypatch.setenv("VIRF_VALIDADOR", "Otra Persona")      # vía antigua: ignorada
    monkeypatch.setenv("VIRF_VALIDADOR_CARGO", "Gerente")
    with pytest.raises(IdentidadRequerida):
        solicitar_identidad()
    with pytest.raises(TypeError):
        solicitar_identidad("Otra Persona", "Gerente")         # ya no acepta nombre


def test_asercion_falsa_en_el_entorno_no_firma(monkeypatch):
    from modulos.validador_humano import IdentidadRequerida, solicitar_identidad
    monkeypatch.setenv(idn.VAR_ASERCION, "eyJmYWxzbyI6MX0.deadbeef")
    with pytest.raises(IdentidadRequerida, match="no es válida"):
        solicitar_identidad(obligatorio=False)


def test_feedback_no_acepta_otro_autor(monkeypatch):
    from modulos.feedback import identidad_para_feedback
    monkeypatch.setenv(idn.VAR_ASERCION, idn.emitir_asercion(ANA))
    assert identidad_para_feedback()["validador"] == "Ana Quispe"
    with pytest.raises(PermissionError):
        identidad_para_feedback("Luis Gómez")


def test_segunda_firma_exige_otra_identidad_autenticada(monkeypatch):
    from modulos.validador_humano import SegundaFirmaRequerida, solicitar_segunda_firma
    monkeypatch.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
    primera = {"validador": "Ana Quispe", "oid": "oid-ana"}
    with pytest.raises(SegundaFirmaRequerida, match="autenticada"):
        solicitar_segunda_firma(primera, "1")
    monkeypatch.setenv(idn.VAR_ASERCION_2, idn.emitir_asercion(ANA))
    with pytest.raises(SegundaFirmaRequerida, match="DISTINTA"):
        solicitar_segunda_firma(primera, "1")
    monkeypatch.setenv(idn.VAR_ASERCION_2, idn.emitir_asercion(LUIS))
    assert solicitar_segunda_firma(primera, "1")["validador"] == "Luis Gómez"


def test_cli_no_tiene_flags_de_firmante():
    from pathlib import Path
    src = (Path(__file__).resolve().parent.parent / "agente.py").read_text(encoding="utf-8")
    for flag in ('"--validador"', '"--cargo"', '"--validador-2"', '"--cargo-2"'):
        assert flag not in src


def test_runner_no_pasa_firmante_por_argumentos():
    from pathlib import Path
    from web.services.pipeline_runner import construir_args
    args = construir_args(Path("x"), "Modelo", "II", "LaR")
    assert "--validador" not in args and "--cargo" not in args


# ── Web ──────────────────────────────────────────────────────────────────────

@pytest.fixture
def cliente(monkeypatch):
    monkeypatch.setenv("VIRF_IDENTIDAD_PROVEEDOR", "simulado")
    from web.app import app
    return TestClient(app, base_url="https://testserver")


def _entrar(cliente, identidad=ANA, monkeypatch=None):
    if monkeypatch is not None:
        orig = idn.ProveedorSimulado.__init__
        monkeypatch.setattr(idn.ProveedorSimulado, "__init__",
                            lambda self, i=None: orig(self, identidad))
    r = cliente.get("/api/auth/login", follow_redirects=False)
    assert r.status_code == 302
    state = r.headers["location"].split("state=")[1]
    r = cliente.get(f"/api/auth/callback?state={state}&code=abc", follow_redirects=False)
    assert r.status_code == 302, r.text
    return r


def test_sin_sesion_401(cliente):
    assert cliente.get("/api/auth/actual").status_code == 401
    assert cliente.post("/api/validar/lanzar", json={}).status_code == 401


def test_login_viejo_por_codigo_ya_no_existe(cliente):
    r = cliente.post("/api/auth/login", json={"codigo": "T5443", "nombre": "Cualquiera"})
    assert r.status_code == 405


def test_login_sso_crea_sesion_con_la_identidad(cliente, monkeypatch):
    _entrar(cliente, ANA, monkeypatch)
    v = cliente.get("/api/auth/actual").json()["validador"]
    assert v == {"codigo": "T5443", "nombre": "Ana Quispe",
                 "cargo": "Validador de Segunda Línea", "upn": "ana.quispe@bcp.com.pe"}


def test_callback_con_state_desconocido_falla(cliente):
    r = cliente.get("/api/auth/callback?state=inventado&code=abc", follow_redirects=False)
    assert r.status_code == 400


def test_codigo_de_otra_identidad_se_rechaza(cliente, monkeypatch):
    _entrar(cliente, ANA, monkeypatch)
    impostor = Identidad(oid="oid-otro", upn="otro@bcp.com.pe", nombre="Otro",
                         codigo="T5443")
    cliente.cookies.clear()
    r = cliente.get("/api/auth/login", follow_redirects=False)
    state = r.headers["location"].split("state=")[1]
    monkeypatch.setattr(idn.ProveedorSimulado, "completar", lambda self, f, p: impostor)
    r = cliente.get(f"/api/auth/callback?state={state}&code=x", follow_redirects=False)
    assert r.status_code == 403


def test_lanzar_rechaza_firmante_en_el_cuerpo(cliente, monkeypatch):
    _entrar(cliente, ANA, monkeypatch)
    r = cliente.post("/api/validar/lanzar", json={"validador": "Luis Gómez", "cargo": "X"})
    assert r.status_code != 200   # 400 sin modelo activo; 422 si llega al modelo
    from web.routers.validacion import LanzarValidacion
    from pydantic import ValidationError
    with pytest.raises(ValidationError):
        LanzarValidacion(validador="Luis Gómez", cargo="X")


def test_sesion_caduca(monkeypatch):
    from web.services import sesion_store
    tok, _ = sesion_store.crear_sesion(ANA)
    assert sesion_store.sesion_activa(tok) is not None
    sesion_store._sesiones[tok]["expira_utc"] = "2000-01-01T00:00:00+00:00"
    assert sesion_store.sesion_activa(tok) is None


def test_runner_inyecta_asercion_de_la_sesion(monkeypatch):
    from web.services import sesion_store
    tok, _ = sesion_store.crear_sesion(ANA)
    ident = sesion_store.identidad_de_sesion(tok)
    assert idn.verificar_asercion(idn.emitir_asercion(ident)).oid == "oid-ana"
