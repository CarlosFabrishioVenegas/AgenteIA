# -*- coding: utf-8 -*-
"""
SEG-01 · Lista cerrada de proveedores de IA (decisión del banco, no reabrir):

    azure_openai = APROBADO · anthropic = EN_ESPERA · openai = RETIRADO

Fija que únicamente Azure OpenAI puede ejecutarse; que Anthropic y OpenAI
fallan con error explícito tanto al construirse como al llamar (aunque alguien
instancie la clase saltándose la factoría); que un host que no es el endpoint
corporativo de Azure se rechaza; y que VIRF PLUS no arranca mientras Claude no
esté aprobado.
"""
from __future__ import annotations

import pytest

import config.ia as cia
from config import red

# Se resuelve todo vía `cia.<nombre>` en tiempo de test: hay tests que hacen
# importlib.reload(config.ia) y eso crea clases nuevas.


@pytest.fixture
def produccion(monkeypatch):
    """La lista cerrada del banco rige en PRODUCCIÓN. La suite corre en
    MODO=debug (conftest), donde Claude y OpenAI se permiten para pruebas
    (tests/test_deteccion_proveedor.py), así que el bloqueo se fija aquí."""
    import config.parametros as par
    monkeypatch.setattr(par, "MODO", "produccion")


def test_lista_cerrada_es_la_decision_del_banco():
    assert cia.PROVEEDORES == {"azure_openai": "APROBADO",
                           "anthropic": "EN_ESPERA",
                           "openai": "RETIRADO"}


def test_azure_pasa():
    cia.autorizar_proveedor("azure_openai")


@pytest.mark.parametrize("prov, estado", [("anthropic", "EN_ESPERA"),
                                          ("openai", "RETIRADO")])
def test_no_aprobados_fallan_con_estado_explicito(prov, estado, produccion):
    with pytest.raises(cia.ProveedorNoAutorizado, match=estado):
        cia.autorizar_proveedor(prov)


@pytest.mark.parametrize("prov", [None, "", "gemini", "AZURE_OPENAI ", "local"])
def test_desconocido_o_vacio_falla(prov):
    with pytest.raises(cia.ProveedorNoAutorizado):
        cia.autorizar_proveedor(prov)


@pytest.mark.parametrize("prov", ["anthropic", "openai"])
def test_factoria_no_construye_no_aprobados(prov, monkeypatch, produccion):
    construido = []
    monkeypatch.setitem(cia.FABRICAS, prov, lambda: construido.append(1))
    with pytest.raises(cia.ProveedorNoAutorizado):
        cia._instanciar(prov)
    with pytest.raises(cia.ProveedorNoAutorizado):
        cia.cliente_dedicado(prov)
    assert construido == [], "no debe ni construirse el cliente"


@pytest.mark.parametrize("cls", [cia.ClienteAnthropicIA, cia.ClienteOpenAIIA])
def test_llamada_directa_salteando_la_factoria_falla(cls, produccion):
    # Instancia sin __init__ (sin claves): el gateway bloquea igualmente al llamar.
    cli = cls.__new__(cls)
    with pytest.raises(cia.ProveedorNoAutorizado):
        cli.generar_mensaje(prompt="hola")


def test_get_cliente_ia_con_proveedor_no_aprobado_falla(monkeypatch, produccion):
    monkeypatch.setattr(cia, "IA_PROVEEDOR", "anthropic")
    monkeypatch.delenv("VIRF_PLUS", raising=False)
    cia.reset_cliente_ia()
    with pytest.raises(cia.ProveedorNoAutorizado, match="EN_ESPERA"):
        cia.get_cliente_ia(forzar_recarga=True)
    cia.reset_cliente_ia()


def test_default_en_codigo_es_azure():
    import ast
    from pathlib import Path
    src = Path(cia.__file__).with_name("parametros.py").read_text(encoding="utf-8")
    assert 'os.getenv("IA_PROVEEDOR", "azure_openai")' in src
    ast.parse(src)


# ── Allowlist de hosts ───────────────────────────────────────────────────────

@pytest.mark.parametrize("url", [
    "https://mi-recurso.openai.azure.com/",
    "https://mi-recurso.openai.azure.com/openai/deployments/x",
    "https://mi-recurso.cognitiveservices.azure.com",
])
def test_host_azure_corporativo_pasa(url, monkeypatch):
    monkeypatch.delenv("VIRF_HOSTS_IA_PERMITIDOS", raising=False)
    red.verificar_host_ia(url)


@pytest.mark.parametrize("url", [
    "https://api.anthropic.com/v1/messages",
    "https://api.openai.com/v1",
    "http://mi-recurso.openai.azure.com/",            # sin TLS
    "https://openai.azure.com.atacante.io/",           # sufijo falso
    "https://atacante.io/?h=x.openai.azure.com",
    "",
])
def test_host_no_listado_falla(url, monkeypatch):
    monkeypatch.delenv("VIRF_HOSTS_IA_PERMITIDOS", raising=False)
    with pytest.raises(red.HostNoPermitido):
        red.verificar_host_ia(url)


def test_allowlist_explicita_restringe_a_un_solo_recurso(monkeypatch):
    monkeypatch.setenv("VIRF_HOSTS_IA_PERMITIDOS", "bcp-virf.openai.azure.com")
    red.verificar_host_ia("https://bcp-virf.openai.azure.com/")
    with pytest.raises(red.HostNoPermitido):
        red.verificar_host_ia("https://otro-recurso.openai.azure.com/")


def test_cliente_azure_rechaza_endpoint_no_permitido(monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "k" * 32)
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://api.openai.com/")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt")
    with pytest.raises(red.HostNoPermitido):
        cia.ClienteAzureOpenAIIA()


# ── VIRF PLUS bloqueado ──────────────────────────────────────────────────────

def test_virf_plus_bloqueado_mientras_claude_no_este_aprobado(produccion):
    from config.virf_plus import ClienteConsensoIA
    with pytest.raises(cia.ProveedorNoAutorizado, match="VIRF PLUS bloqueado"):
        ClienteConsensoIA(claude=object(), gpt=object())


def test_get_cliente_en_modo_virf_plus_bloqueado(monkeypatch, produccion):
    monkeypatch.setenv("VIRF_PLUS", "1")
    cia.reset_cliente_ia()
    with pytest.raises(cia.ProveedorNoAutorizado, match="VIRF PLUS bloqueado"):
        cia.get_cliente_ia(forzar_recarga=True)
    cia.reset_cliente_ia()


def test_web_solo_ofrece_el_proveedor_aprobado():
    from web.routers.config import PROVEEDORES as CATALOGO_WEB
    assert set(CATALOGO_WEB) == {"azure_openai"}
