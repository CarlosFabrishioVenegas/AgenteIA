# -*- coding: utf-8 -*-
"""
Brechas «Pasos Generales Agente 2» con código: 3, 11, 15, 20, 25, 43, 49.
Los documentos de gobierno deben coincidir con el código (no pueden derivar).
"""
from __future__ import annotations

import re
from datetime import date, timedelta
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parent.parent
GOB = RAIZ / "gobierno"


def _filas_tabla(md: str, primera_col_regex: str):
    return [l for l in md.splitlines() if re.match(r"^\|\s*" + primera_col_regex, l)]


# ── Paso 3 · perfiles = roles del código ─────────────────────────────────────

def test_perfiles_coinciden_con_roles_del_codigo():
    from web.services.roles import ROLES
    md = (GOB / "perfiles_usuario.md").read_text(encoding="utf-8")
    en_doc = set(re.findall(r"\|\s*`(\w+)`\s*\|", md))
    assert en_doc == set(ROLES), f"doc={en_doc} código={set(ROLES)}"
    assert "Área validada" in md


# ── Paso 15 / 49 · catálogo de tools deny by default ─────────────────────────

def test_catalogo_doc_coincide_con_config():
    from config.tools import CATALOGO
    from skills import SKILLS_TIPADAS
    assert set(CATALOGO) == set(SKILLS_TIPADAS)
    md = (GOB / "catalogo_tools.md").read_text(encoding="utf-8")
    for nombre, ficha in CATALOGO.items():
        fila = next(l for l in md.splitlines() if l.startswith(f"| `{nombre}`"))
        assert fila.rstrip(" |").endswith(ficha["estado"]), fila
    assert [n for n, f in CATALOGO.items() if f["estado"] == "operativa"] == ["run_data_quality_check"]


def test_tool_fuera_de_catalogo_falla():
    from config import tools
    with pytest.raises(tools.ToolNoRegistrada):
        tools.invocar("borrar_todo", ("validador",))


def test_tool_deshabilitada_falla_aunque_tengas_rol():
    from config import tools
    with pytest.raises(tools.ToolDeshabilitada):
        tools.invocar("ingest_operational_channels", ("validador", "admin_corpus", "revisor"))


@pytest.mark.parametrize("roles", [(), ("revisor",), ("admin_corpus",), None])
def test_tool_sin_permiso_falla(roles):
    from config import tools
    with pytest.raises(tools.PermisoTool):
        tools.invocar("run_data_quality_check", roles)


def test_tool_permitida_se_ejecuta_y_audita(monkeypatch):
    from config import tools
    from modulos import auditoria
    from skills import SKILLS_TIPADAS
    monkeypatch.setattr(SKILLS_TIPADAS["run_data_quality_check"], "ejecutar",
                        lambda self, **kw: {"ok": True, **kw})
    assert tools.invocar("run_data_quality_check", ["validador"], quien="ana", x=1) == {"ok": True, "x": 1}
    assert [e["objeto"] for e in auditoria.leer() if e["accion"] == "invocacion_tool"] == \
        ["run_data_quality_check"]


# ── Paso 11 · dueño y vigencia de fuentes ────────────────────────────────────

@pytest.fixture
def fuentes(tmp_path, monkeypatch):
    from modulos import fuentes_rag as fr
    monkeypatch.setattr(fr, "REGISTRO", tmp_path / "registro.json")
    corpus = tmp_path / "rag"; (corpus / "LaR").mkdir(parents=True)
    monkeypatch.setattr(fr, "CORPUS", corpus)
    return fr, corpus


@pytest.mark.parametrize("dueno, vig", [("", "2030-01-01"), ("Riesgos", ""), ("Riesgos", "mañana")])
def test_cargar_fuente_sin_dueno_o_vigencia_falla(fuentes, dueno, vig):
    fr, corpus = fuentes
    f = corpus / "LaR" / "lcr.pdf"; f.write_bytes(b"%PDF")
    with pytest.raises(fr.FuenteInvalida):
        fr.registrar_fuente("LaR", f, dueno, vig)


def test_estados_e_inventario(fuentes):
    fr, corpus = fuentes
    (corpus / "LaR" / "vigente.md").write_text("a"); (corpus / "LaR" / "vencida.md").write_text("b")
    (corpus / "LaR" / "huerfana.md").write_text("c")
    fr.registrar_fuente("LaR", corpus / "LaR" / "vigente.md", "Riesgos", date.today() + timedelta(days=30))
    fr.registrar_fuente("LaR", corpus / "LaR" / "vencida.md", "Riesgos", date.today() - timedelta(days=1))
    estados = {f["fuente"]: f["estado"] for f in fr.inventario()}
    assert estados == {"vigente.md": "vigente", "vencida.md": "vencida", "huerfana.md": "huerfana"}
    huerf = next(f for f in fr.inventario() if f["fuente"] == "huerfana.md")
    assert huerf["dueno"] == "[POR ASIGNAR 👤]"


def test_fuente_vencida_no_se_recupera(fuentes, tmp_path):
    """Búsqueda REAL con un índice léxico: la fuente vencida desaparece."""
    fr, _ = fuentes
    from src.rag.buscador_lexico import BuscadorLexico
    from src.rag.indexador_lexico import IndexadorLexico
    corpus = tmp_path / "corpus_rag"; corpus.mkdir()
    texto = ("Backtesting de VaR. La prueba de Kupiec contrasta la cobertura incondicional "
             "comparando excepciones observadas con las esperadas. ") * 3
    (corpus / "vigente.md").write_text(texto, encoding="utf-8")
    (corpus / "vencida.md").write_text(texto, encoding="utf-8")
    idx = IndexadorLexico("dom_test", fuentes=[corpus])
    idx.ruta = tmp_path / "indice" / "dom_test.pkl"
    idx.construir(force=True)
    b = BuscadorLexico("dom_test", autoconstruir=False)
    b._indexador = idx
    antes = {r["fuente"] for r in b.buscar("prueba de Kupiec backtesting", top_k=10)}
    assert {"vigente.md", "vencida.md"} <= antes
    fr.registrar_fuente("dom_test", corpus / "vigente.md", "Riesgos", "2099-12-31")
    fr.registrar_fuente("dom_test", corpus / "vencida.md", "Riesgos", "2000-01-01")
    despues = {r["fuente"] for r in b.buscar("prueba de Kupiec backtesting", top_k=10)}
    assert "vigente.md" in despues and "vencida.md" not in despues


def test_subida_al_rag_sin_dueno_rechazada():
    src = (RAIZ / "web" / "routers" / "upload.py").read_text(encoding="utf-8")
    assert "necesita dueño y vigencia" in src and "el corpus RAG no admite ZIP" in src


# ── Paso 20 · matriz tarea-modelo ────────────────────────────────────────────

def test_matriz_tarea_modelo_solo_proveedores_aprobados_y_config_real():
    import config.ia as cia
    md = (GOB / "matriz_tarea_modelo.md").read_text(encoding="utf-8")
    filas = [l for l in md.splitlines() if l.startswith("| ") and ".py" in l]
    assert len(filas) >= 8
    for f in filas:
        celdas = [c.strip() for c in f.strip("|").split("|")]
        _tarea, modulo, proveedores, variable, estado = celdas
        assert (RAIZ / modulo).exists(), modulo
        provs = [p.strip() for p in proveedores.split("+")]
        no_aprob = [p for p in provs if cia.PROVEEDORES.get(p) != "APROBADO"]
        assert not no_aprob or estado == "bloqueado", f
        usado = any(variable in p.read_text(encoding="utf-8", errors="ignore")
                    for p in list((RAIZ / "config").glob("*.py")) + list((RAIZ / "web/services").glob("*.py")))
        assert usado, f"variable {variable} no aparece en el código"


# ── Paso 25 · feedback aprobado antes de afectar puntajes ────────────────────

@pytest.fixture
def fb(tmp_path, monkeypatch):
    import modulos.feedback as fb
    monkeypatch.setattr(fb, "FEEDBACK_PATH", tmp_path / "h.json")
    return fb


def test_feedback_nace_pendiente_y_no_ajusta(fb):
    from modulos.feedback_mejorado import ajustar_puntaje_por_feedback
    from config.parametros import MIN_MUESTRAS_AJUSTE
    fb.guardar_historial([{"ambito": "Metodología", "actividad": f"Backtesting {i}",
                           "diferencia": 2.0, "autor_oid": "oid-ana"}
                          for i in range(MIN_MUESTRAS_AJUSTE + 2)])
    assert all(r["estado_aprobacion"] == "pendiente" for r in fb.cargar_historial())
    p, motivo = ajustar_puntaje_por_feedback("Metodología", "Backtesting", 2.0)
    assert p == 2.0 and "Sin feedback" in motivo
    for r in fb.cargar_historial():
        fb.aprobar_feedback(r["_id"], quien="rev@bcp.com.pe", oid="oid-rev")
    p2, _ = ajustar_puntaje_por_feedback("Metodología", "Backtesting", 2.0)
    assert p2 > 2.0
    assert fb.verificar_cadena()["ok"]


def test_autor_no_aprueba_su_feedback(fb):
    fb.guardar_historial([{"ambito": "M", "actividad": "a", "autor_oid": "oid-ana"}])
    rid = fb.cargar_historial()[0]["_id"]
    with pytest.raises(PermissionError):
        fb.aprobar_feedback(rid, quien="ana", oid="oid-ana")


def test_negado_no_ajusta(fb):
    fb.guardar_historial([{"ambito": "M", "actividad": "a"}])
    rid = fb.cargar_historial()[0]["_id"]
    fb.aprobar_feedback(rid, quien="rev", oid="oid-rev", decision="negado")
    assert fb.cargar_historial_aprobado() == []


# ── Paso 43 · estado explícito ───────────────────────────────────────────────

def test_contrato_declara_evidencia_insuficiente():
    from pydantic import ValidationError
    from modulos.esquemas import ValidationReport
    r = ValidationReport(model_id="M", overall_confidence=0.1, abstained=True)
    assert r.estado_evidencia == "EVIDENCIA INSUFICIENTE"
    assert ValidationReport(model_id="M", overall_confidence=0.9).estado_evidencia == "SUFICIENTE"
    with pytest.raises(ValidationError):
        ValidationReport(model_id="M", overall_confidence=0.9,
                         estado_evidencia="EVIDENCIA INSUFICIENTE")


def test_motor_marca_estado_evidencia():
    from modulos import salvaguardas_llm as sv
    r = sv.aplicar({"observacion": "x", "evidencia_encontrada": ""}, rag_scores=[])
    assert r["estado_evidencia"] == "EVIDENCIA INSUFICIENTE"
    r2 = sv.aplicar({"observacion": "x", "evidencia_encontrada": "«y»"}, rag_scores=[0.9])
    assert r2["estado_evidencia"] == "SUFICIENTE"
