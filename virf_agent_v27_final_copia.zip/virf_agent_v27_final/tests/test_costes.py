# -*- coding: utf-8 -*-
"""
Pasos 54 · 56 · 57 — coste por llamada en la bitácora y reporte por corrida/usuario.
"""
from __future__ import annotations

import csv

import pytest

from config.modelos import coste_usd, precio_entrada_por_mtok, precio_salida_por_mtok


@pytest.mark.parametrize("modelo, ent, sal, esperado", [
    ("gpt-4o", 1_000_000, 0, 2.50),
    ("gpt-4o", 0, 1_000_000, 10.00),
    ("gpt-4o-mini-2024-07-18", 2_000_000, 1_000_000, 0.30 + 0.60),
    ("gpt-4.1", 500_000, 250_000, 1.00 + 2.00),
])
def test_coste_es_tokens_por_precio(modelo, ent, sal, esperado):
    assert coste_usd(modelo, ent, sal) == pytest.approx(esperado)


def test_hay_precio_de_salida_distinto_del_de_entrada():
    assert precio_salida_por_mtok("gpt-4o") > precio_entrada_por_mtok("gpt-4o")
    assert precio_salida_por_mtok("modelo-desconocido") > 0


class _Uso:
    prompt_tokens, completion_tokens = 1200, 300


def test_gateway_registra_tokens_latencia_corrida_y_coste(monkeypatch):
    from config.ia import ClienteIA
    from modulos import auditoria

    class _Azure(ClienteIA):
        PROVEEDOR = "azure_openai"
        deployment = "gpt-4o"

        def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                            sistema=None, formato_json=False):
            self.ultimo_uso = {"modelo": "gpt-4o", "entrada": 1200, "salida": 300}
            return "respuesta"

        def validar_conexion(self):
            return True

    monkeypatch.setenv("VIRF_ID_CORRIDA", "run-abc")
    tk = auditoria.contexto_web.set({"quien": "ana@bcp.com.pe", "oid": "o", "desde": "x"})
    try:
        _Azure().generar_mensaje(prompt="hola")
    finally:
        auditoria.contexto_web.reset(tk)
    [e] = [e for e in auditoria.leer() if e["accion"] == "llamada_ia"]
    d = e["detalle"]
    assert (d["corrida"], d["modelo"], d["tokens_entrada"], d["tokens_salida"]) == \
        ("run-abc", "gpt-4o", 1200, 300)
    assert d["tokens_estimados"] is False and d["latencia_ms"] >= 0
    assert d["coste_usd"] == pytest.approx(coste_usd("gpt-4o", 1200, 300))
    assert e["quien"] == "ana@bcp.com.pe"


def test_sin_uso_real_se_estima_y_se_marca():
    from config.ia import ClienteIA
    from modulos import auditoria

    class _SinUso(ClienteIA):
        PROVEEDOR = "azure_openai"

        def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                            sistema=None, formato_json=False):
            return "x" * 240

        def validar_conexion(self):
            return True

    _SinUso().generar_mensaje(prompt="y" * 480)
    d = [e for e in auditoria.leer() if e["accion"] == "llamada_ia"][-1]["detalle"]
    assert d["tokens_estimados"] is True and d["tokens_entrada"] == 200 and d["tokens_salida"] == 100


def test_reporte_por_corrida_y_usuario(tmp_path):
    from modulos.observabilidad import generar
    entradas = [
        {"accion": "llamada_ia", "cuando": "2026-11-09T10:00:00+00:00", "quien": "ana", "resultado": "ok",
         "detalle": {"corrida": "r1", "modelo": "gpt-4o", "tokens_entrada": 100, "tokens_salida": 10,
                     "latencia_ms": 100, "coste_usd": 0.5}},
        {"accion": "llamada_ia", "cuando": "2026-11-09T10:01:00+00:00", "quien": "ana", "resultado": "error:X",
         "detalle": {"corrida": "r1", "modelo": "gpt-4o", "tokens_entrada": 50, "tokens_salida": 0,
                     "latencia_ms": 900, "coste_usd": 0.25}},
        {"accion": "llamada_ia", "cuando": "2026-11-10T09:00:00+00:00", "quien": "luis", "resultado": "ok",
         "detalle": {"corrida": "r2", "modelo": "gpt-4o", "tokens_entrada": 10, "tokens_salida": 1,
                     "latencia_ms": 50, "coste_usd": 1.0}},
        {"accion": "login", "quien": "ana"},
    ]
    res = generar(tmp_path, entradas)
    assert res == {"llamadas": 3, "costes_por_corrida": 2, "costes_por_usuario": 2, "uso_diario": 2}
    corr = {r["corrida"]: r for r in csv.DictReader(open(tmp_path / "costes_por_corrida.csv", encoding="utf-8"))}
    assert float(corr["r1"]["coste_usd"]) == pytest.approx(0.75) and corr["r1"]["errores"] == "1"
    assert corr["r1"]["latencia_p95_ms"] == "900.0"
