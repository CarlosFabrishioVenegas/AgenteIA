# -*- coding: utf-8 -*-
"""
SEG-15 · Recursos externos: ningún HTML versionado carga nada de la red
(fuentes, scripts, hojas de estilo, imágenes). Deben funcionar sin red.

Los namespaces XML (`xmlns="http://www.w3.org/2000/svg"`) no son cargas y se
ignoran; los enlaces <a href> a documentación tampoco cargan nada al abrir.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parent.parent

# Atributos/CSS que provocan una DESCARGA al abrir el documento.
_CARGA = re.compile(
    r"""<(?:link|script|img|iframe|source|video|audio|embed|object)\b[^>]*\b(?:href|src|data)\s*=\s*["']\s*(?:https?:)?//"""
    r"""|@import\s+(?:url\()?\s*["']?\s*(?:https?:)?//"""
    r"""|url\(\s*["']?\s*(?:https?:)?//""", re.I)


def _html_versionados():
    salida = subprocess.run(["git", "ls-files", "-z", "*.html", "*.htm"], cwd=RAIZ,
                            capture_output=True, text=True, encoding="utf-8").stdout
    return [f for f in salida.split(chr(0)) if f and not f.startswith("archivo/")]


def test_hay_html_que_revisar():
    assert "docs/como_aprende_el_agente.html" in _html_versionados()


@pytest.mark.parametrize("rel", _html_versionados())
def test_html_sin_cargas_externas(rel):
    texto = (RAIZ / rel).read_text(encoding="utf-8", errors="ignore")
    hallazgos = [m.group(0)[:80] for m in _CARGA.finditer(texto)]
    assert hallazgos == [], f"{rel}: {hallazgos}"
    assert "fonts.googleapis.com" not in texto and "fonts.gstatic.com" not in texto


def test_detector_reconoce_cargas_y_respeta_namespaces():
    assert _CARGA.search('<link rel="stylesheet" href="https://fonts.googleapis.com/css">')
    assert _CARGA.search('<script src="//cdn.ejemplo.com/x.js"></script>')
    assert _CARGA.search("@import url('https://x.com/a.css');")
    assert not _CARGA.search('<svg xmlns="http://www.w3.org/2000/svg">')
    assert not _CARGA.search('<a href="https://docs.ejemplo.com">doc</a>')
