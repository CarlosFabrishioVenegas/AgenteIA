"""
Tests de la asistencia con IA de «Solo Informe». Coste cero: el modelo se
sustituye por `_llm_de_prueba`, que registra el prompt y devuelve una respuesta
fija. Ninguno llama a Azure ni a Anthropic.

Cubre:
  - Estado del proveedor (Azure por defecto, Anthropic como alternativa) y
    los overrides de deployment/modelo propios del apartado.
  - pulir: PII enmascarada antes de salir; error claro sin credenciales.
  - gráfico: esquema de pasos y barras; rechazo de cifras inventadas.
  - manuales: fragmentación con página, búsqueda BM25 y redacción con fuentes.
  - endpoints y figura del gráfico en el Word.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from docx import Document

from web.services import solo_informe_ia as ia
from web.services import solo_informe_word


@pytest.fixture
def llm(monkeypatch):
    """Modelo simulado: devuelve `respuesta` y guarda los prompts recibidos."""
    class _Falso:
        respuesta = "Texto pulido."
        prompts: list[str] = []

        def __call__(self, prompt, sistema, max_tokens):
            self.prompts.append(prompt)
            return self.respuesta
    f = _Falso()
    f.prompts = []
    monkeypatch.setattr(ia, "_llm_de_prueba", f)
    return f


# ── Proveedor ─────────────────────────────────────────────────────────

def test_azure_por_defecto_y_lo_que_falta(monkeypatch):
    import config.parametros as par
    monkeypatch.setattr(par, "IA_PROVEEDOR", "azure_openai")
    monkeypatch.delenv("SOLO_INFORME_IA_PROVEEDOR", raising=False)
    for v in ("AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT"):
        monkeypatch.delenv(v, raising=False)
    e = ia.estado()
    assert e["proveedor"] == "azure_openai" and not e["disponible"]
    assert e["faltan"] == ["AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT",
                           "AZURE_OPENAI_DEPLOYMENT"]
    with pytest.raises(ia.IANoConfigurada, match="AZURE_OPENAI_API_KEY"):
        ia.pulir("texto", "observacion")


def test_override_de_proveedor_y_modelo(monkeypatch, simular_aprobacion):
    import config.parametros as par
    monkeypatch.setattr(par, "IA_PROVEEDOR", "azure_openai")
    monkeypatch.setenv("SOLO_INFORME_IA_PROVEEDOR", "anthropic")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-prueba")
    monkeypatch.setenv("SOLO_INFORME_MODELO", "claude-haiku-barato")
    simular_aprobacion("anthropic")   # [SEG-01] mecánica del override, no el bloqueo real
    e = ia.estado()
    assert (e["proveedor"], e["modelo"], e["disponible"]) == (
        "anthropic", "claude-haiku-barato", True)


def test_proveedor_no_aprobado_no_esta_disponible_aunque_tenga_clave(monkeypatch):
    """[SEG-01] Anthropic (EN_ESPERA) con clave: no disponible y el mensaje lo
    dice; nada de «pon la clave en el .env»."""
    import config.parametros as par
    monkeypatch.setattr(par, "IA_PROVEEDOR", "anthropic")
    # El bloqueo del banco rige en producción (fuera de ella Claude se permite
    # para pruebas: tests/test_deteccion_proveedor.py).
    monkeypatch.setattr(par, "MODO", "produccion")
    monkeypatch.delenv("SOLO_INFORME_IA_PROVEEDOR", raising=False)
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-prueba")
    e = ia.estado()
    assert (e["disponible"], e["autorizado"], e["estado_banco"]) == (False, False, "EN_ESPERA")
    assert e["aprobados"] == ["azure_openai"]
    with pytest.raises(ia.IANoConfigurada, match="no está autorizado por el banco") as exc:
        ia.pulir("texto", "observacion")
    assert ".env" not in str(exc.value)


def test_mensajes_sin_credenciales_no_mandan_al_env(monkeypatch):
    import config.parametros as par
    monkeypatch.setattr(par, "IA_PROVEEDOR", "azure_openai")
    monkeypatch.delenv("SOLO_INFORME_IA_PROVEEDOR", raising=False)
    for v in ("AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT"):
        monkeypatch.delenv(v, raising=False)
    with pytest.raises(ia.IANoConfigurada, match="fuente de secretos") as exc:
        ia.pulir("texto", "observacion")
    assert ".env" not in str(exc.value)


def test_azure_usa_deployment_propio_del_apartado(monkeypatch):
    """El deployment barato se aplica al cliente de Azure sin llamar a la red."""
    import config.ia as cia
    import config.parametros as par
    monkeypatch.setattr(par, "IA_PROVEEDOR", "azure_openai")
    monkeypatch.delenv("SOLO_INFORME_IA_PROVEEDOR", raising=False)
    for v, val in (("AZURE_OPENAI_API_KEY", "k"), ("AZURE_OPENAI_ENDPOINT", "https://x"),
                   ("AZURE_OPENAI_DEPLOYMENT", "gpt-principal"),
                   ("SOLO_INFORME_DEPLOYMENT", "gpt-mini")):
        monkeypatch.setenv(v, val)
    usado = {}

    class _Azure:
        deployment = "gpt-principal"

        def generar_mensaje(self, prompt, sistema="", max_tokens=None):
            usado["deployment"] = self.deployment
            return "ok"
    monkeypatch.setitem(cia.FABRICAS, "azure_openai", _Azure)
    assert ia.pulir("hola", "observacion") == "ok"
    assert usado["deployment"] == "gpt-mini"


def test_clave_rechazada_da_mensaje_claro(monkeypatch):
    import config.ia as cia
    import config.parametros as par
    # [SEG-01] Con el único proveedor aprobado (Azure OpenAI).
    monkeypatch.setattr(par, "IA_PROVEEDOR", "azure_openai")
    monkeypatch.delenv("SOLO_INFORME_IA_PROVEEDOR", raising=False)
    monkeypatch.setenv("AZURE_OPENAI_API_KEY", "clave-mal")
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://x.openai.azure.com/")
    monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt")

    class _Rechaza:
        def generar_mensaje(self, *a, **k):
            raise RuntimeError("Error code: 401 - invalid x-api-key")
    monkeypatch.setitem(cia.FABRICAS, "azure_openai", _Rechaza)
    with pytest.raises(ia.IANoConfigurada, match="AZURE_OPENAI_API_KEY") as exc:
        ia.pulir("hola", "observacion")
    assert "fuente de secretos" in str(exc.value) and ".env" not in str(exc.value)


# ── Pulir ─────────────────────────────────────────────────────────────

def test_pulir_enmascara_pii_y_marca_el_texto(llm):
    llm.respuesta = '"El manual no registra cambios."'
    r = ia.pulir("el manual no registra cambios, avisar a juan.perez@banco.com", "observacion")
    assert r == "El manual no registra cambios."
    assert "juan.perez@banco.com" not in llm.prompts[0]
    assert "<texto>" in llm.prompts[0]


def test_respuesta_sin_markdown(llm):
    # Respuesta real de Haiku en la prueba con el manual LaR: traía un título «##».
    llm.respuesta = "## Contexto del modelo\n\nEl modelo **LaR** estima la pérdida."
    assert ia.pulir("x", "contexto") == "El modelo LaR estima la pérdida."
    llm.respuesta = "Párrafo de sustento\n\nConforme al manual, el nivel es 99%."
    assert ia.pulir("x", "sustento") == "Conforme al manual, el nivel es 99%."
    # Un texto que empieza con una frase normal no se recorta.
    llm.respuesta = "El manual no justifica el 99%.\n\nSe recomienda documentarlo."
    assert ia.pulir("x", "sustento").startswith("El manual no justifica")


def test_pulir_vacio_falla(llm):
    with pytest.raises(ValueError):
        ia.pulir("   ", "observacion")


# ── Gráfico ───────────────────────────────────────────────────────────

TEXTO_LARGO = ("El proceso de cálculo del VaR toma la serie de pérdidas y ganancias, "
               "aplica la ventana de 500 días, ordena los resultados y extrae el percentil 1. "
               "Antes la ventana era de 250 días y el cambio no fue aprobado por el comité.")


def test_grafico_flujo(llm, tmp_path):
    llm.respuesta = json.dumps({"tipo": "flujo", "titulo": "Cálculo del VaR",
                                "pasos": ["Serie de P&L", "Ventana de 500 días",
                                          "Percentil 1", "Cambio sin aprobación"]})
    r = ia.grafico(tmp_path, TEXTO_LARGO)
    png = tmp_path / "imagenes" / r["imagen_id"]
    assert png.is_file() and png.read_bytes()[:4] == b"\x89PNG"
    assert r["spec"]["tipo"] == "flujo" and len(r["spec"]["pasos"]) == 4


def test_grafico_barras_con_cifras_del_texto(llm, tmp_path):
    llm.respuesta = ("Aquí va:\n```json\n" + json.dumps(
        {"tipo": "barras", "titulo": "Ventana", "etiquetas": ["Antes", "Ahora"],
         "valores": [250, 500], "unidad": "días"}) + "\n```")
    r = ia.grafico(tmp_path, TEXTO_LARGO)
    assert r["spec"]["valores"] == [250.0, 500.0]


def test_grafico_rechaza_cifras_inventadas(llm, tmp_path):
    llm.respuesta = json.dumps({"tipo": "barras", "titulo": "x", "etiquetas": ["a", "b"],
                                "valores": [250, 999]})
    with pytest.raises(ia.IAFallo, match="999"):
        ia.grafico(tmp_path, TEXTO_LARGO)
    assert not list((tmp_path / "imagenes").glob("*.png")) if (tmp_path / "imagenes").exists() else True


def test_grafico_texto_corto_o_json_roto(llm, tmp_path):
    with pytest.raises(ValueError):
        ia.grafico(tmp_path, "corto")
    llm.respuesta = "no es json"
    with pytest.raises(ia.IAFallo):
        ia.grafico(tmp_path, TEXTO_LARGO)


# ── Manuales ──────────────────────────────────────────────────────────

MANUAL = ("Manual metodológico del VaR histórico\n\n"
          "Objetivo: el modelo estima la pérdida máxima a un día con 99% de confianza "
          "para la cartera de Trading.\n\f"
          "Control de versiones: la última actualización del manual es de mayo de 2023.\n\n"
          "La ventana histórica es de 250 días hábiles.")


def test_manual_fragmentos_con_pagina_y_busqueda(tmp_path):
    r = ia.guardar_manual(tmp_path, "Manual VaR.txt", MANUAL.encode("utf-8"))
    assert r["fragmentos"] >= 2
    res = ia.buscar(tmp_path, "control de versiones actualización del manual")
    assert res and res[0]["pagina"] == 2 and "versiones" in res[0]["texto"]
    assert ia.listar_manuales(tmp_path)[0]["nombre"] == "Manual VaR.txt"
    assert ia.borrar_manual(tmp_path, "Manual VaR.txt")
    assert ia.buscar(tmp_path, "versiones") == []


def test_busqueda_no_repite_bloques_de_plantilla(tmp_path):
    bloque = "Manual LaR. El modelo LaR estima la máxima pérdida de liquidez."
    texto = "\f".join([bloque] * 5 + ["Nivel de confianza del 99% justificado por apetito."])
    ia.guardar_manual(tmp_path, "m.txt", texto.encode("utf-8"))
    res = ia.buscar(tmp_path, "modelo LaR pérdida liquidez nivel confianza", top_k=5)
    assert len({r["texto"] for r in res}) == len(res) == 2


def test_manual_formato_no_admitido(tmp_path):
    with pytest.raises(ValueError):
        ia.guardar_manual(tmp_path, "virus.exe", b"MZ")


def test_desde_manuales_cita_fuentes(llm, tmp_path):
    ia.guardar_manual(tmp_path, "manual.txt", MANUAL.encode("utf-8"))
    llm.respuesta = "El manual se actualizó en mayo de 2023 [manual.txt, pág. 2]."
    r = ia.desde_manuales(tmp_path, "observacion",
                          actividad="Verifica la existencia de control de cambios/versiones",
                          texto="no hay control de versiones")
    assert r["texto"].startswith("El manual")
    assert any(f["pagina"] == 2 for f in r["fuentes"])
    assert 'archivo="manual.txt" pagina="2"' in llm.prompts[0]


def test_desde_manuales_sin_manuales(llm, tmp_path):
    with pytest.raises(ValueError, match="manuales"):
        ia.desde_manuales(tmp_path, "contexto", nombre_modelo="VaR")


# ── Endpoints y Word ─────────────────────────────────────────────────

@pytest.fixture
def cliente(tmp_path):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.routers.solo_informe import base_solo_informe
    app.dependency_overrides[base_solo_informe] = lambda: tmp_path
    try:
        yield TestClient(app)
    finally:
        app.dependency_overrides.pop(base_solo_informe, None)


def test_endpoints_ia(cliente, llm, tmp_path):
    assert cliente.get("/api/solo-informe/ia/estado").json()["disponible"] is True
    r = cliente.post("/api/solo-informe/ia/pulir", json={"texto": "hola", "campo": "observacion"})
    assert r.status_code == 200 and r.json()["texto"] == "Texto pulido."

    r = cliente.post("/api/solo-informe/manuales",
                     files={"archivo": ("manual.txt", MANUAL.encode("utf-8"))})
    assert r.status_code == 200 and r.json()["manuales"][0]["fragmentos"] >= 2
    r = cliente.post("/api/solo-informe/ia/manuales",
                     json={"objetivo": "contexto", "nombre_modelo": "VaR"})
    assert r.status_code == 200 and r.json()["fuentes"]
    # Sustento de observación sin actividad elegida → 400 claro.
    r = cliente.post("/api/solo-informe/ia/manuales", json={"objetivo": "observacion"})
    assert r.status_code == 400

    llm.respuesta = json.dumps({"tipo": "flujo", "titulo": "t", "pasos": ["a", "b", "c"]})
    r = cliente.post("/api/solo-informe/ia/grafico", json={"texto": TEXTO_LARGO})
    assert r.status_code == 200
    assert cliente.get(f"/api/solo-informe/imagen/{r.json()['imagen_id']}").status_code == 200
    assert cliente.delete("/api/solo-informe/manuales/manual.txt").status_code == 200


def test_endpoint_sin_credenciales_responde_503(cliente, monkeypatch):
    import config.parametros as par
    monkeypatch.setattr(ia, "_llm_de_prueba", None)
    monkeypatch.setattr(par, "IA_PROVEEDOR", "azure_openai")
    monkeypatch.delenv("SOLO_INFORME_IA_PROVEEDOR", raising=False)
    monkeypatch.delenv("AZURE_OPENAI_API_KEY", raising=False)
    r = cliente.post("/api/solo-informe/ia/pulir", json={"texto": "hola"})
    assert r.status_code == 503 and "AZURE_OPENAI_API_KEY" in r.json()["detail"]


def test_word_incluye_el_grafico(llm, tmp_path):
    llm.respuesta = json.dumps({"tipo": "flujo", "titulo": "t", "pasos": ["a", "b", "c"]})
    g = ia.grafico(tmp_path, TEXTO_LARGO)["imagen_id"]
    est = {"ambitos": ["Gobierno"], "tiene_tier": False, "controles": [
        {"id": "C001", "ambito": "Gobierno", "clave_ambito": "gobierno", "control": "Comité",
         "control_especifico": "", "actividad": "Act", "tiers": None}]}
    datos = {"tipo": "periodica", "nombre_modelo": "M", "fecha_inicio": "2026-01-01",
             "fecha_entrega": "2026-02-01", "observaciones": [
                 {"riesgo": "Bajo", "control_id": "C001", "observacion": "x",
                  "grafico_id": g}]}
    doc = Document(str(solo_informe_word.generar(datos, est, tmp_path)))
    textos = [p.text for p in doc.paragraphs]
    assert "Esquema de apoyo de la observación 1." in textos
