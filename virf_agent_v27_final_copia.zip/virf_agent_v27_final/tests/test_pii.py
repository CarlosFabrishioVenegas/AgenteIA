# -*- coding: utf-8 -*-
"""
Enmascarado PII (modulos/pii.py): alta precisión, 100% local, sin red.

Lo que se fija:
  · SEG-04 — base PERUANA: DNI (8 díg., con/sin verificador, con contexto o con
    verificador válido), RUC (10/15/17/20 + checksum SUNAT), carné de
    extranjería, CCI de 20 dígitos, cuentas con guiones y nombres por contexto
    (encabezados De:/Para:, firmas, tratamiento Sr./Sra., campos de acta).
  · Tokens estables por valor ([DNI_1], [RUC_1]…): mismo dato → mismo token.
  · Set de control: importes, fechas, tasas y códigos de modelo NO se tocan.
  · España (DNI con letra, NIE, IBAN), tarjeta Luhn, correo y teléfono con
    contexto siguen funcionando como complemento.

Todos los números son SINTÉTICOS (construidos para cuadrar el checksum).
"""
import pytest

from modulos.pii import enmascarar, contiene_pii, token


def _tipos(hallazgos):
    return {h["tipo"] for h in hallazgos}


# ═════════════════════════════════════════════════════════════════════════════
# PERÚ — DNI
# ═════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("texto, dato", [
    ("El cliente con DNI 45678912 solicitó el crédito.", "45678912"),
    ("Identificado con D.N.I. N° 45678912, domiciliado en Lima.", "45678912"),
    ("Titular: documento de identidad 70123456.", "70123456"),
    ("DNI: 45678912-4 (con dígito verificador)", "45678912-4"),
    ("dni nro. 10203040-K", "10203040-K"),
])
def test_dni_peruano_con_contexto(texto, dato):
    t, h = enmascarar(texto)
    assert dato not in t
    assert token("DNI", 1) in t
    assert "DNI" in _tipos(h)


def test_dni_peruano_aislado_con_verificador_valido():
    # Sin rótulo: solo la forma 8 dígitos + guion + verificador correcto.
    t, h = enmascarar("Fila 12 | 45678912-4 | aprobado")
    assert "45678912" not in t and token("DNI", 1) in t
    t2, _ = enmascarar("Fila 12 | 70123456-A | aprobado")
    assert "70123456" not in t2


def test_dni_aislado_con_verificador_invalido_no_se_toca():
    t, _ = enmascarar("Referencia 45678912-9 del lote.")
    assert "45678912-9" in t


def test_dni_mismo_valor_mismo_token():
    t, h = enmascarar("DNI 45678912 aparece; luego DNI 45678912 y DNI 70123456.")
    assert t.count(token("DNI", 1)) == 2
    assert token("DNI", 2) in t
    assert {"tipo": "DNI", "n": 3} in h


# ═════════════════════════════════════════════════════════════════════════════
# PERÚ — RUC
# ═════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("ruc", ["20100047218", "10456789124", "20601234565",
                                 "15123456782", "17000000019"])
def test_ruc_valido_sin_contexto(ruc):
    t, h = enmascarar(f"Proveedor {ruc} registrado en el maestro.")
    assert ruc not in t and token("RUC", 1) in t
    assert "RUC" in _tipos(h)


def test_ruc_con_contexto_aunque_falle_checksum():
    t, _ = enmascarar("RUC N° 20100047210 (dígito mal tipeado en el acta)")
    assert "20100047210" not in t and token("RUC", 1) in t


def test_once_digitos_sin_contexto_ni_checksum_no_es_ruc():
    t, _ = enmascarar("Código de operación 20100047210 conciliado.")
    assert "20100047210" in t
    # Prefijo que no es de RUC
    t2, _ = enmascarar("Código 30100047218 conciliado.")
    assert "30100047218" in t2


# ═════════════════════════════════════════════════════════════════════════════
# PERÚ — Carné de extranjería
# ═════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("texto, dato", [
    ("Cliente extranjero con CE 001234567 vigente.", "001234567"),
    ("carné de extranjería N° 000123456789", "000123456789"),
    ("Carnet: A12345678", "A12345678"),
])
def test_carne_extranjeria(texto, dato):
    t, h = enmascarar(texto)
    assert dato not in t and token("CE", 1) in t
    assert "CE" in _tipos(h)


def test_carne_sin_digitos_no_se_toca():
    texto = "Presentó su carné universitario vigente."
    assert enmascarar(texto)[0] == texto


# ═════════════════════════════════════════════════════════════════════════════
# PERÚ — CCI y cuentas
# ═════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("texto, dato", [
    ("Abonar al CCI 00219300123456789012 del proveedor.", "00219300123456789012"),
    ("Interbancaria 002-193-001234567890-12 confirmada.", "002-193-001234567890-12"),
    ("Transferir a 00219300123456789012", "00219300123456789012"),
])
def test_cci_20_digitos(texto, dato):
    t, h = enmascarar(texto)
    assert dato not in t and token("CCI", 1) in t
    assert "CCI" in _tipos(h)


@pytest.mark.parametrize("texto, dato", [
    ("Cuenta de ahorros 191-12345678-0-12 en soles.", "191-12345678-0-12"),
    ("Depósito en 193-1234567-0-55 a nombre del titular.", "193-1234567-0-55"),
    ("Cta. cte. 0011-0123-0200123456 BBVA", "0011-0123-0200123456"),
    ("N° de cuenta: 898 3001234567", "898 3001234567"),
])
def test_cuentas_con_guiones(texto, dato):
    t, h = enmascarar(texto)
    assert dato not in t and token("CUENTA", 1) in t
    assert "CUENTA" in _tipos(h)


# ═════════════════════════════════════════════════════════════════════════════
# NOMBRES por contexto (actas, correos, firmas)
# ═════════════════════════════════════════════════════════════════════════════

def test_encabezado_de_correo():
    texto = ("De: Juan Carlos Pérez Quispe <juan.perez@bcp.com.pe>\n"
             "Para: María Fernanda Gómez de la Torre\n"
             "CC: Luis Alberto Huamán\n"
             "Asunto: Revisión del modelo PD Retail")
    t, h = enmascarar(texto)
    for nombre in ("Juan Carlos Pérez Quispe", "María Fernanda Gómez de la Torre",
                   "Luis Alberto Huamán"):
        assert nombre not in t
    assert "NOMBRE" in _tipos(h) and "CORREO" in _tipos(h)
    assert "Asunto: Revisión del modelo PD Retail" in t


def test_campos_de_acta():
    texto = ("ACTA DE COMITÉ\n"
             "Asistentes: Rosa Mamani Flores, Pedro Sánchez Ruiz y Ana Lucía Chávez\n"
             "Elaborado por: Carlos Villanueva\n"
             "Aprobado por: Gerencia de Riesgos\n")
    t, _ = enmascarar(texto)
    for nombre in ("Rosa Mamani Flores", "Pedro Sánchez Ruiz", "Ana Lucía Chávez",
                   "Carlos Villanueva"):
        assert nombre not in t
    # Un área no es una persona: se conserva.
    assert "Aprobado por: Gerencia de Riesgos" in t


def test_tratamiento_y_firma():
    texto = ("Estimada Sra. Gómez, adjunto el informe que pidió el Dr. Ramírez Soto.\n"
             "Atentamente,\n"
             "Jorge Luis Paredes\n")
    t, h = enmascarar(texto)
    assert "Gómez" not in t and "Ramírez Soto" not in t and "Jorge Luis Paredes" not in t
    assert "Estimada Sra. [NOMBRE_" in t


def test_mismo_nombre_mismo_token():
    t, _ = enmascarar("Elaborado por: Carlos Villanueva\nRevisado por: Carlos Villanueva")
    assert t.count(token("NOMBRE", 1)) == 2
    assert token("NOMBRE", 2) not in t


# ═════════════════════════════════════════════════════════════════════════════
# SET DE CONTROL — falsos positivos que NO deben enmascararse
# ═════════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("texto", [
    "El VaR al 99% fue 1.234.567,89 EUR; la ventana de 250 días con 500 escenarios.",
    "Saldo de cartera S/ 12,345,678.90 al 31/12/2024 con PD de 2.35%.",
    "Corte 2024-03-15; segunda corte 20240315; periodo 202312.",
    "Modelo MOD-PD-2023-01 versión 3.2.1, código interno 10203040506.",
    "La serie tiene 12345678 observaciones y 45678912 registros válidos.",
    "LGD 45.5%, EAD 1500000, umbral 0,05 y horizonte de 12 meses.",
    "Para: el cálculo se usó la muestra de desarrollo 2019-2022.",
    "Se aplicó la prueba de Kupiec con 250 observaciones y nivel 99%.",
    "El tipo de cambio fue 3.7512 y la tasa 12.5% TEA.",
    "Se revisaron 1500 créditos entre el 01-01-2023 y el 31-12-2023.",
])
def test_set_de_control_sin_falsos_positivos(texto):
    t, h = enmascarar(texto)
    assert t == texto, f"Se alteró texto sin PII: {t!r}"
    assert h == []


# ═════════════════════════════════════════════════════════════════════════════
# COMPLEMENTO (España, tarjeta, correo, teléfono) y contrato general
# ═════════════════════════════════════════════════════════════════════════════

def test_correo_se_enmascara():
    t, h = enmascarar("Contacto: ana.perez@banco.com para dudas.")
    assert token("CORREO", 1) in t
    assert "ana.perez@banco.com" not in t
    assert "CORREO" in _tipos(h)


def test_tarjeta_valida_luhn_se_enmascara():
    t, h = enmascarar("Pago con la tarjeta 4111 1111 1111 1111 registrada.")
    assert token("TARJETA", 1) in t
    assert "TARJETA" in _tipos(h)


def test_numero_largo_no_valido_no_se_toca():
    t, h = enmascarar("El identificador interno 1234567812345678 del lote.")
    assert "1234567812345678" in t


def test_iban_valido_se_enmascara_y_uno_falso_no():
    t, h = enmascarar("Cuenta ES91 2100 0418 4502 0005 1332 del cliente.")
    assert token("IBAN", 1) in t
    t2, h2 = enmascarar("Referencia ES00 0000 0000 0000 0000 0000 inventada.")
    assert "[IBAN_" not in t2


def test_dni_espanol_con_letra_sigue_como_complemento():
    t, h = enmascarar("El titular con DNI 12345678Z firmó el acta.")
    assert "12345678Z" not in t
    t2, _ = enmascarar("La serie tiene 12345678 observaciones.")
    assert "12345678" in t2


def test_telefono_solo_con_contexto():
    t, h = enmascarar("Llamar al celular +51 987 654 321 antes de las 18h.")
    assert token("TELEFONO", 1) in t
    assert "TELEFONO" in _tipos(h)
    t2, _ = enmascarar("El lote 600123456 se procesó ayer.")
    assert "[TELEFONO_" not in t2


def test_texto_limpio_pasa_igual():
    texto = "El backtesting de Kupiec se ejecutó sobre datos reales."
    t, h = enmascarar(texto)
    assert t == texto and h == []
    assert contiene_pii(texto) is False


def test_nunca_lanza_con_entradas_raras():
    assert enmascarar("") == ("", [])
    assert enmascarar(None)[0] == ""
    t1, _ = enmascarar("correo a@b.com, DNI 45678912 y Sr. Pérez")
    t2, _ = enmascarar(t1)
    assert t1 == t2
