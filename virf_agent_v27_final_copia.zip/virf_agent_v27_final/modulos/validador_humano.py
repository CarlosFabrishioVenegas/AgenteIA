"""
modulos/validador_humano.py
═══════════════════════════════════════════════════════════════════════════════
FIRMA Y RESPONSABILIDAD DEL VALIDADOR HUMANO — segregación de funciones.

Requisito de cumplimiento. SR 11-7 §V exige que la validación la ejecute
personal con independencia efectiva y que exista un responsable identificable;
EBA/GL/2023/01 §5 exige poder demostrar la segregación entre quien desarrolla,
quien ejecuta y quien aprueba.

La pregunta del auditor que esto responde es directa: **«¿quién firmó esto?»**
Un informe sin responsable humano identificable es un informe que nadie asumió,
y por tanto no acredita validación independiente: acredita que se ejecutó un
programa.

Tres piezas:

  2.1  Identidad obligatoria en `--prdc`. Un informe de producción no puede
       emitirse sin nombre y cargo. Se admite por flag, por entorno o
       interactivamente, pero no se admite su ausencia.

  2.2  Registro acumulado (`feedback/registro_validadores.json`): qué modelo
       validó cada persona y cuándo. Permite demostrar rotación ante el
       regulador y sirve a equipos de 2-5 personas con instalaciones separadas
       sobre el mismo repositorio.

  2.3  Detección de auto-aprobación: si la misma persona firma 3+ informes
       consecutivos del mismo modelo sin que intervenga un segundo validador,
       se advierte. NO se bloquea: en un equipo de dos personas puede ser
       inevitable y bloquearlo impediría trabajar. Un aviso visible en el
       informe deja constancia para que el auditor lo valore.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

_RAIZ = Path(__file__).resolve().parents[1]
REGISTRO_PATH = _RAIZ / "feedback" / "registro_validadores.json"

# [CONFIG-CENTRAL] Los parámetros de negocio viven en config/parametros.py, no
# aquí: una segunda lectura de VIRF_VALIDADOR en este módulo podría divergir de
# la de config sin que nada avisara. Se re-exporta el umbral por comodidad de
# los llamantes, pero la única declaración está en config.
from config.parametros import (
    UMBRAL_SIN_SEGUNDA_REVISION,
    tiers_doble_firma,
)
from config.identidad import (VAR_ASERCION, VAR_ASERCION_2, AsercionInvalida,
                              identidad_autenticada)


class IdentidadRequerida(RuntimeError):
    """Se intentó emitir un informe de producción sin validador identificable."""


class SegundaFirmaRequerida(RuntimeError):
    """
    Se intentó emitir un informe de un tier con doble firma sin segundo
    validador, o con un segundo firmante que es la misma persona que el primero.
    """


# ═════════════════════════════════════════════════════════════════════════════
# 2.1 — Identificación
# ═════════════════════════════════════════════════════════════════════════════

def _ficha(ident) -> Dict[str, str]:
    return {
        "validador": ident.nombre,
        "cargo": ident.cargo,
        "upn": ident.upn,
        "oid": ident.oid,
        "fecha_aprobacion": datetime.now(timezone.utc)
                            .isoformat(timespec="seconds").replace("+00:00", "Z"),
    }


def solicitar_identidad(*, obligatorio: bool = True) -> Dict[str, str]:
    """
    Identidad del validador responsable = la persona AUTENTICADA (SEG-02).

    Sale únicamente de la aserción firmada `VIRF_ASERCION_IDENTIDAD` que emite
    la web a partir de la sesión SSO (config/identidad.py). Ya no existen
    `--validador`, `VIRF_VALIDADOR` ni la pregunta interactiva: con cualquiera
    de ellas se podía firmar a nombre de otra persona.

    Raises:
        IdentidadRequerida: si `obligatorio` y no hay aserción, o si la aserción
            es inválida/caducada (siempre, aunque no sea obligatoria).
    """
    try:
        ident = identidad_autenticada(VAR_ASERCION)
    except AsercionInvalida as exc:
        raise IdentidadRequerida(
            f"La identidad del firmante no es válida ({exc}). Vuelve a lanzar la "
            "validación desde la web con tu sesión corporativa.") from exc
    if ident is None:
        if obligatorio:
            raise IdentidadRequerida(
                "No se puede emitir un informe de producción sin validador "
                "AUTENTICADO.\n\n"
                "  SR 11-7 §V · norma 2135.010.02: el firmante es la identidad\n"
                "  corporativa de quien lanza la validación, no un nombre tecleado.\n\n"
                "  Lanza la validación desde la web (login con Entra ID)."
            )
        return {"validador": "", "cargo": "", "upn": "", "oid": "",
                "fecha_aprobacion": ""}
    return _ficha(ident)


# ═════════════════════════════════════════════════════════════════════════════
# 2.2 — Registro acumulado
# ═════════════════════════════════════════════════════════════════════════════

def _cargar_registro() -> List[Dict]:
    if not REGISTRO_PATH.exists():
        return []
    try:
        datos = json.loads(REGISTRO_PATH.read_text(encoding="utf-8"))
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, OSError):
        # Mismo criterio que el historial de feedback: un fichero corrupto se
        # respalda en vez de descartarse en silencio. Perder el registro de
        # quién validó qué sería perder la evidencia de segregación.
        try:
            sello = datetime.now().strftime("%Y%m%d-%H%M%S")
            REGISTRO_PATH.rename(
                REGISTRO_PATH.with_suffix(f".corrupto-{sello}.json"))
            print(f"  ⚠️  registro_validadores.json ilegible; respaldado como "
                  f".corrupto-{sello}.json")
        except OSError:
            pass
        return []


def registrar_validacion(modelo: str, identidad: Dict, tier: str = "",
                         huella: str = "", score_global=None) -> Dict:
    """
    Añade una firma al registro acumulado, con lock y escritura atómica.

    Se reutilizan los helpers de concurrencia de `document_cache` porque el
    escenario es el mismo que ya rompió el historial de feedback: varios
    validadores del equipo escribiendo sobre el mismo repositorio. Sin lock, la
    firma de uno borra la del otro — y con ella la evidencia de segregación.
    """
    entrada = {
        "modelo": modelo,
        "validador": identidad.get("validador", ""),
        "cargo": identidad.get("cargo", ""),
        "tier": tier,
        "fecha_aprobacion": identidad.get("fecha_aprobacion"),
        "huella_ejecucion": huella,
        "score_global": score_global,
    }
    REGISTRO_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        from modulos.document_cache import _lock_archivo, _escribir_json_atomico
    except ImportError:
        from contextlib import nullcontext

        def _lock_archivo(_p):
            return nullcontext()

        def _escribir_json_atomico(destino, data):
            Path(destino).write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    with _lock_archivo(REGISTRO_PATH):
        # Relectura DENTRO del lock: es lo que evita el lost update.
        registro = _cargar_registro()
        registro.append(entrada)
        _escribir_json_atomico(REGISTRO_PATH, registro)
    return entrada


def historial_por_validador() -> Dict[str, Dict]:
    """Agrupa el registro por validador: cuántos modelos y con qué fechas."""
    resumen: Dict[str, Dict] = {}
    for r in _cargar_registro():
        v = r.get("validador") or "(sin identificar)"
        d = resumen.setdefault(v, {
            "cargo": r.get("cargo", ""),
            "n_aprobaciones": 0,
            "modelos": {},
            "primera": None,
            "ultima": None,
        })
        d["n_aprobaciones"] += 1
        d["cargo"] = r.get("cargo") or d["cargo"]
        modelo = r.get("modelo", "?")
        d["modelos"].setdefault(modelo, []).append(r.get("fecha_aprobacion"))
        fecha = r.get("fecha_aprobacion") or ""
        if fecha:
            d["primera"] = min(d["primera"] or fecha, fecha)
            d["ultima"] = max(d["ultima"] or fecha, fecha)
    return dict(sorted(resumen.items()))


# ═════════════════════════════════════════════════════════════════════════════
# 2.3 — Auto-aprobación sin supervisión
# ═════════════════════════════════════════════════════════════════════════════

def firmas_consecutivas(modelo: str, validador: str) -> int:
    """
    Cuántas firmas consecutivas más recientes del modelo son de este validador.

    Se cuenta desde el final hacia atrás y se para en la primera firma ajena:
    la intervención de un segundo validador reinicia el contador, que es
    exactamente lo que la segregación pretende conseguir.
    """
    del_modelo = [r for r in _cargar_registro() if r.get("modelo") == modelo]
    n = 0
    for r in reversed(del_modelo):
        if (r.get("validador") or "") == validador:
            n += 1
        else:
            break
    return n


def aviso_segunda_revision(modelo: str, validador: str) -> Optional[str]:
    """
    Devuelve el texto del aviso si falta segunda revisión, o None.

    No bloquea (requisito 2.3): en un equipo de dos personas la rotación puede
    ser imposible en un periodo dado, y bloquear impediría trabajar. El aviso
    queda en el informe para que el auditor lo valore con su contexto.

    El recuento incluye la firma en curso, que aún no está en el registro.
    """
    n = firmas_consecutivas(modelo, validador) + 1
    if n >= UMBRAL_SIN_SEGUNDA_REVISION:
        return (f"⚠️ Sin segunda revisión reciente detectada para este modelo: "
                f"{n} informes consecutivos aprobados por el mismo validador "
                f"({validador}). Se recomienda revisión cruzada por un segundo "
                f"validador conforme a segregación de funciones.")
    return None


# ═════════════════════════════════════════════════════════════════════════════
# [PENDIENTE-3] 2.4 — APROBACIÓN DE DOS OJOS (doble firma en tiers exigentes)
#
# Qué había antes y por qué no bastaba
# ────────────────────────────────────
# La segregación se DETECTABA (`aviso_segunda_revision`) y se avisaba en el
# informe, pero un solo validador podía emitir absolutamente todo. Para un
# modelo Tier 1 —la exigencia máxima— un supervisor va a pedir dos firmas, y un
# aviso al pie no es una firma: es la constancia de que no la hubo.
#
# Decisión de diseño: aquí SÍ se bloquea. El razonamiento completo —y por qué
# no contradice el criterio «el aviso no bloquea» de 2.3— está en
# `config/parametros.tiers_doble_firma()`. En resumen: esto tiene remedio
# inmediato (que firme el segundo), es opt-in por configuración, y en Tier 1 un
# aviso ignorable produciría un informe que PARECE aprobado por dos personas.
# ═════════════════════════════════════════════════════════════════════════════

def _normalizar_nombre(nombre: str) -> str:
    """
    Forma canónica de un nombre, para comparar dos firmantes.

    Sin normalizar, «Ana Pérez», «ana perez» y «Ana  Pérez» serían tres personas
    distintas y una sola persona podría firmar las dos casillas escribiendo su
    nombre de dos maneras — que es exactamente lo que el control debe impedir.

    Se pliegan mayúsculas, se colapsan los espacios y se retiran los acentos:
    quien teclea su propio nombre dos veces rara vez lo escribe idéntico, y la
    diferencia habitual es justo una tilde o un espacio de más.
    """
    import unicodedata
    limpio = " ".join(str(nombre or "").split()).casefold()
    return "".join(c for c in unicodedata.normalize("NFKD", limpio)
                   if not unicodedata.combining(c))


def requiere_doble_firma(tier) -> bool:
    """¿Este tier exige dos firmas? Ver `config.parametros.tiers_doble_firma`."""
    return str(tier).strip() in tiers_doble_firma()


def solicitar_segunda_firma(
    identidad_primera: Dict,
    tier,
) -> Optional[Dict]:
    """
    Resuelve y valida la firma del SEGUNDO validador.

    Devuelve None si el tier no exige doble firma. En caso contrario devuelve la
    identidad del segundo firmante, o lanza `SegundaFirmaRequerida`.

    [SEG-02] Misma regla que el primer firmante: sale de una aserción firmada
    (VIRF_ASERCION_IDENTIDAD_2) de OTRA persona autenticada.

    Raises:
        SegundaFirmaRequerida: si falta el segundo firmante o coincide con el
            primero.
    """
    if not requiere_doble_firma(tier):
        return None

    try:
        ident2 = identidad_autenticada(VAR_ASERCION_2)
    except AsercionInvalida as exc:
        raise SegundaFirmaRequerida(f"La segunda firma no es válida ({exc}).") from exc
    if ident2 is None:
        raise SegundaFirmaRequerida(
            f"El Tier {tier} exige aprobación de DOS validadores distintos y "
            f"solo hay una firma.\n\n"
            "  SR 11-7 §V — segregación de funciones (VIRF_DOBLE_FIRMA_TIER).\n"
            "  [SEG-02] La segunda firma debe venir de OTRA persona autenticada\n"
            "  (aserción VIRF_ASERCION_IDENTIDAD_2 emitida por su sesión SSO); ya\n"
            "  no se acepta un nombre tecleado.\n\n"
            "  Si esta política no aplica a tu entidad, quita el tier de\n"
            "  VIRF_DOBLE_FIRMA_TIER en vez de firmar dos veces."
        )
    nombre, cargo = ident2.nombre, ident2.cargo
    if ident2.oid == identidad_primera.get("oid"):
        raise SegundaFirmaRequerida(
            "El segundo validador debe ser una persona DISTINTA de la primera "
            "(misma identidad corporativa).")

    # El segundo firmante debe ser OTRA persona. Sin esta comprobación el
    # control es puramente decorativo: la misma persona rellena las dos
    # casillas y el informe declara una revisión cruzada que no existió.
    if _normalizar_nombre(nombre) == _normalizar_nombre(
            identidad_primera.get("validador", "")):
        raise SegundaFirmaRequerida(
            f"El segundo validador debe ser una persona DISTINTA de la "
            f"primera.\n\n"
            f"  Ambas firmas son de: {identidad_primera.get('validador', '?')}\n\n"
            "  Una doble firma de la misma persona no es aprobación de dos\n"
            "  ojos: es la misma decisión escrita dos veces, y en el informe\n"
            "  declararía una revisión cruzada que no se produjo."
        )

    return {
        "validador": nombre,
        "cargo": cargo,
        "upn": ident2.upn,
        "oid": ident2.oid,
        "fecha_aprobacion": datetime.now(timezone.utc)
                            .isoformat(timespec="seconds").replace("+00:00", "Z"),
        "rol_firma": "segunda aprobación (dos ojos)",
    }


# ═════════════════════════════════════════════════════════════════════════════
# Presentación en consola
# ═════════════════════════════════════════════════════════════════════════════

def imprimir_historial() -> None:
    resumen = historial_por_validador()
    print("\n" + "═" * 74)
    print("  ✍️  HISTORIAL DE VALIDACIONES POR VALIDADOR")
    print("═" * 74)
    if not resumen:
        print("\n  No hay validaciones registradas.")
        print("  El registro se crea al emitir el primer informe con --prdc.\n")
        return
    for validador, d in resumen.items():
        print(f"\n  {validador}   ({d['cargo'] or 'sin cargo'})")
        print(f"     aprobaciones : {d['n_aprobaciones']}")
        print(f"     modelos      : {len(d['modelos'])}")
        print(f"     periodo      : {d['primera']} → {d['ultima']}")
        for modelo, fechas in sorted(d["modelos"].items()):
            print(f"        · {modelo}  ({len(fechas)}×)  última: {max(f for f in fechas if f)}")
    print("\n" + "─" * 74)
    total = sum(d["n_aprobaciones"] for d in resumen.values())
    print(f"  {len(resumen)} validador(es) · {total} aprobación(es) registradas")
    # Señal de segregación: un único validador para todo es un hallazgo.
    if len(resumen) == 1 and total >= UMBRAL_SIN_SEGUNDA_REVISION:
        print("\n  ⚠️  Un solo validador acumula todas las aprobaciones.")
        print("      Un auditor lo señalará como falta de segregación de funciones.")
    print("═" * 74 + "\n")
