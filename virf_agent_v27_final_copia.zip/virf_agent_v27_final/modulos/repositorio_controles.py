"""
modulos/repositorio_controles.py
═════════════════════════════════════════════════════════════════════════════
REPOSITORIO de controles de datos ESCRITOS COMO FUNCIONES PYTHON, organizados
por tipo de modelo. Cuando el modelo activo es de dominio VaR, el notebook toma
los controles de `inputs/repositorio_controles/var/`; si es LaR, de
`.../lar/`; etc. Así el .ipynb entregable es ESPECIALIZADO, no genérico.

Estructura (una carpeta por DOMINIO real de la entidad):

    inputs/repositorio_controles/
      var/     TRADING — modelos de mercado (VaR): kupiec, christoffersen…
      alm/     ALM (dominio padre) — modelos conductuales (prepago MCP,
               supervivencia MCR) e IRRBB/EVE/NII.
      lar/     LIQUIDEZ — LaR, RCL (≈LCR), RFNE (≈NSFR), HQLA…
      shared/  transversales, se añaden a CUALQUIER dominio.

Contrato de un control (un .py en una de esas carpetas):

    META = {
        "descripcion": "qué verifica",        # → col. 'Control Esperado'
        "dimension":   "Backtesting (VaR)",    # → col. 'Dimensión'
        "evidencia":   "qué soporte aportar",  # → col. 'Control o Evidencia requerida'
        "referencia":  "cita a literatura",    # → col. 'Referencia en el entregable'
        "orden":       10,                     # (opc.) orden de presentación
        "params":      {"campo_var": "var_99"},# (opc.) columnas/umbrales editables
    }

    def control(df, datasets, params):
        \"\"\"df = dataset principal; datasets = dict {nombre: DataFrame};
        params = META['params'] (editable). Devuelve dict con:\"\"\"
        return {"pct": 99.4,          # % de cumplimiento (o None si no evaluable)
                "decision": "Cumple",  # Cumple | Observado | No cumple | No evaluable | Revisión manual
                "diagnostico": "..."}  # texto corto para el cuadro

El notebook EMBEBE el código fuente de cada control (el validador lo ve y lo
puede ajustar), lo ejecuta y consolida el cuadro de 8 columnas.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

__all__ = ["cargar_controles", "RAIZ_REPO", "carpeta_de_dominio"]

_ESTE = Path(__file__).resolve()
RAIZ_REPO = _ESTE.parent.parent / "inputs" / "repositorio_controles"

# Alias de dominio → carpeta. Codifica la TAXONOMÍA real de modelos de la entidad
# (tolera mayúsculas y sinónimos que el usuario ponga en Configuración):
#
#   · TRADING  → modelos de mercado (VaR)                         → var/
#   · ALM      → dominio PADRE. De él nacen los modelos            → alm/
#                CONDUCTUALES hijos: prepago (MCP), supervivencia/
#                retiro (MCR), más IRRBB/EVE/NII. El canónico es "alm";
#                "conductuales" se acepta como alias legacy.
#   · LIQUIDEZ → LaR, RCL (cobertura ≈ LCR), RFNE (estable ≈ NSFR) → lar/
_ALIAS = {
    # Trading / riesgo de mercado
    "var": "var", "value at risk": "var", "trading": "var",
    "riesgo de mercado": "var", "mercado": "var",
    # ALM (padre) = modelos conductuales (prepago MCP, supervivencia/retiro MCR,
    # IRRBB). "conductuales" es alias legacy del canónico "alm".
    "alm": "alm", "conductuales": "alm", "conductual": "alm",
    "mcp": "alm", "mcr": "alm", "prepago": "alm", "supervivencia": "alm",
    "retiro": "alm", "nmd": "alm", "irrbb": "alm",
    # Liquidez (LaR, RCL≈LCR, RFNE≈NSFR)
    "lar": "lar", "liquidity at risk": "lar", "liquidez": "lar",
    "rcl": "lar", "lcr": "lar", "rfne": "lar", "nsfr": "lar", "hqla": "lar",
}


def carpeta_de_dominio(dominio: Optional[str]) -> Optional[str]:
    """Normaliza el nombre de dominio al de su carpeta en el repositorio."""
    if not dominio:
        return None
    clave = str(dominio).strip().lower()
    return _ALIAS.get(clave, clave)     # por defecto, la propia etiqueta en minúscula


def _extraer_meta(codigo: str, archivo: str) -> Tuple[Optional[Dict[str, Any]], Optional[str]]:
    """
    Lee META y comprueba que exista `def control(...)` SIN EJECUTAR el fichero
    (SEG-07): `ast.parse` + `ast.literal_eval` del literal asignado a META.
    Antes se hacía `exec(compile(...))`, de modo que cualquier código en el
    módulo (imports, llamadas al sistema) corría al listar el repositorio.

    META debe ser un literal (dict con str/num/bool/None/listas/dicts): algo
    calculado en tiempo de ejecución no se acepta.
    """
    import ast
    try:
        arbol = ast.parse(codigo, filename=archivo)
    except SyntaxError as exc:
        return None, f"no compila: {exc.msg} (línea {exc.lineno})"
    meta = None
    tiene_control = False
    for nodo in arbol.body:
        if isinstance(nodo, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "META" for t in nodo.targets):
            try:
                meta = ast.literal_eval(nodo.value)
            except (ValueError, TypeError, SyntaxError):
                return None, "META debe ser un literal (sin llamadas ni expresiones)"
        elif isinstance(nodo, ast.AnnAssign) and getattr(nodo.target, "id", "") == "META"                 and nodo.value is not None:
            try:
                meta = ast.literal_eval(nodo.value)
            except (ValueError, TypeError, SyntaxError):
                return None, "META debe ser un literal (sin llamadas ni expresiones)"
        elif isinstance(nodo, ast.FunctionDef) and nodo.name == "control":
            tiene_control = True
    if not isinstance(meta, dict):
        return None, "falta el dict META"
    if not tiene_control:
        return None, "falta la función control(df, datasets, params)"
    return meta, None


def cargar_controles(dominio: Optional[str],
                     raiz: Optional[Path] = None) -> Tuple[List[Dict[str, Any]], List[str]]:
    """
    Devuelve (controles, avisos) para el `dominio` + `shared`. Cada control:
        {archivo, nombre, fuente(code), meta, dominio_carpeta}
    Nunca lanza: los ficheros con error se reportan como avisos.
    """
    base = Path(raiz) if raiz else RAIZ_REPO
    controles: List[Dict[str, Any]] = []
    avisos: List[str] = []

    carpetas: List[str] = []
    dc = carpeta_de_dominio(dominio)
    if dc:
        carpetas.append(dc)
    carpetas.append("shared")

    for carpeta in carpetas:
        d = base / carpeta
        if not d.is_dir():
            continue
        for path in sorted(d.glob("*.py")):
            if path.name.startswith("_"):
                continue
            try:
                codigo = path.read_text(encoding="utf-8")
            except OSError as exc:
                avisos.append(f"{carpeta}/{path.name}: no se pudo leer ({exc})")
                continue
            meta, err = _extraer_meta(codigo, path.name)
            if err:
                avisos.append(f"{carpeta}/{path.name}: {err}")
                continue
            controles.append({
                "archivo": path.name,
                "nombre":  path.stem,
                "fuente":  codigo,
                "meta":    meta,
                "dominio_carpeta": carpeta,
            })

    # Orden: por META['orden'] si está, luego por nombre de archivo.
    controles.sort(key=lambda c: (c["meta"].get("orden", 1000), c["archivo"]))
    return controles, avisos
