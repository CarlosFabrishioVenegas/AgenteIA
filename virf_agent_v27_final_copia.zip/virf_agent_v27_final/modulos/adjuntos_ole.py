"""
modulos/adjuntos_ole.py — Archivos adjuntos INCRUSTADOS en un Word (python-docx).

Un sustento puede ser un Excel, un Word, una presentación, un correo (.msg/.eml)
o un PDF. Se incrusta dentro del .docx como objeto OLE que se muestra como ICONO
del tipo de archivo con su nombre debajo; doble clic lo abre en su aplicación.

Dos mecanismos, ambos sin Microsoft Word ni COM (funciona en el servidor, en
Linux o en Databricks):

  · Office moderno (.xlsx, .docx, .pptx): el archivo va tal cual como parte del
    paquete (`word/embeddings/…`) con su ProgID (`Excel.Sheet.12`…). Es lo que
    hace Word al insertar «Objeto › Crear desde archivo».
  · Cualquier otro (.msg, .eml, .pdf, .xls, .doc, .ppt, .csv…): «paquete OLE»
    (ProgID `Package`) dentro de un fichero compuesto (`oleObject.bin`). El
    fichero compuesto (formato CFB, [MS-CFB]) se escribe aquí: no hay librería
    en el entorno que lo escriba (olefile solo lee).

Los iconos los dibuja este módulo (colores de cada familia de aplicaciones y la
inicial del tipo); no se descargan ni se copian los logotipos de Microsoft.
No ejecuta ni abre el contenido de los adjuntos: solo copia sus bytes.
"""
from __future__ import annotations

import math
import struct
import uuid
from pathlib import Path
from typing import Optional

from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.opc.packuri import PackURI
from docx.opc.part import Part
from docx.oxml import parse_xml
from PIL import Image, ImageDraw, ImageFont

# ── Tipos de archivo ──────────────────────────────────────────────────

# familia → (color del distintivo, texto del distintivo, nombre legible)
FAMILIAS = {
    "excel":      ((0x1D, 0x6F, 0x42), "X", "Excel"),
    "word":       ((0x2B, 0x57, 0x9A), "W", "Word"),
    "powerpoint": ((0xC4, 0x3E, 0x1C), "P", "PowerPoint"),
    "outlook":    ((0x0F, 0x6C, 0xBD), "O", "Correo de Outlook"),
    "pdf":        ((0xB3, 0x0B, 0x00), "PDF", "PDF"),
}

# extensión → (familia, ProgID nativo o None, content-type nativo)
_CT = "application/vnd.openxmlformats-officedocument."
EXTENSIONES = {
    ".xlsx": ("excel", "Excel.Sheet.12", _CT + "spreadsheetml.sheet"),
    ".docx": ("word", "Word.Document.12", _CT + "wordprocessingml.document"),
    ".pptx": ("powerpoint", "PowerPoint.Show.12", _CT + "presentationml.presentation"),
    ".xlsm": ("excel", None, None),
    ".xls":  ("excel", None, None),
    ".csv":  ("excel", None, None),
    ".doc":  ("word", None, None),
    ".ppt":  ("powerpoint", None, None),
    ".msg":  ("outlook", None, None),
    ".eml":  ("outlook", None, None),
    ".pdf":  ("pdf", None, None),
}

_RT_PAQUETE = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/package"
_CT_OLE = _CT + "oleObject"
_CLSID_PAQUETE = uuid.UUID("0003000C-0000-0000-C000-000000000046").bytes_le


def familia(nombre: str) -> str:
    return EXTENSIONES.get(Path(nombre).suffix.lower(), ("generico",))[0]


def descripcion(nombre: str) -> str:
    f = familia(nombre)
    return FAMILIAS[f][2] if f in FAMILIAS else Path(nombre).suffix.lstrip(".").upper()


# ── Icono ─────────────────────────────────────────────────────────────

_ESC = 2                       # se dibuja al doble y se reduce: bordes suaves
_ANCHO, _ALTO = 150, 132       # px del icono final (incluye el nombre debajo)


def _fuente(tam: int, negrita: bool = False):
    for nombre in (("arialbd.ttf", "DejaVuSans-Bold.ttf") if negrita
                   else ("arial.ttf", "DejaVuSans.ttf")):
        try:
            return ImageFont.truetype(nombre, tam)
        except OSError:
            continue
    return ImageFont.load_default(size=tam)


def _partir(texto: str, fuente, ancho: int, draw) -> list[str]:
    """Nombre en hasta 2 líneas; la segunda se recorta con «…»."""
    lineas, actual = [], ""
    for ch in texto:
        if draw.textlength(actual + ch, font=fuente) > ancho:
            lineas.append(actual)
            actual = ch
        else:
            actual += ch
    lineas.append(actual)
    if len(lineas) > 2:
        seg = lineas[1]
        while seg and draw.textlength(seg + "…", font=fuente) > ancho:
            seg = seg[:-1]
        lineas = [lineas[0], seg + "…"]
    return lineas


def icono_png(nombre: str, destino: Path) -> Path:
    """Icono del tipo de `nombre` con el nombre del archivo debajo."""
    e = _ESC
    w, h = _ANCHO * e, _ALTO * e
    img = Image.new("RGBA", (w, h), (255, 255, 255, 0))
    d = ImageDraw.Draw(img)
    fam = familia(nombre)
    color, letra, _ = FAMILIAS.get(fam, ((0x6B, 0x70, 0x7D),
                                         Path(nombre).suffix.lstrip(".").upper()[:4] or "?", ""))
    # Hoja con la esquina doblada.
    x0, y0, x1, y1, pliegue = 52 * e, 6 * e, 112 * e, 80 * e, 16 * e
    d.polygon([(x0, y0), (x1 - pliegue, y0), (x1, y0 + pliegue), (x1, y1), (x0, y1)],
              fill=(255, 255, 255, 255), outline=(150, 156, 168, 255), width=2 * e)
    d.polygon([(x1 - pliegue, y0), (x1 - pliegue, y0 + pliegue), (x1, y0 + pliegue)],
              fill=(226, 229, 235, 255), outline=(150, 156, 168, 255), width=e)
    # Motivo de la hoja según la familia.
    claro = tuple(int(c + (255 - c) * 0.55) for c in color) + (255,)
    if fam == "excel":
        for i in range(4):
            for j in range(2):
                d.rectangle([(84 + j * 12) * e, (26 + i * 11) * e,
                             (94 + j * 12) * e, (34 + i * 11) * e], fill=claro)
    elif fam == "outlook":
        sx0, sy0, sx1, sy1 = 74 * e, 34 * e, 106 * e, 58 * e
        d.rectangle([sx0, sy0, sx1, sy1], fill=claro, outline=color + (255,), width=e)
        d.line([(sx0, sy0), ((sx0 + sx1) // 2, (sy0 + sy1) // 2), (sx1, sy0)],
               fill=color + (255,), width=2 * e)
    elif fam == "powerpoint":
        d.pieslice([78 * e, 28 * e, 106 * e, 56 * e], 270, 180, fill=claro)
        d.rectangle([80 * e, 62 * e, 106 * e, 66 * e], fill=claro)
    else:
        for i in range(5):
            d.rectangle([80 * e, (26 + i * 10) * e, 106 * e, (29 + i * 10) * e], fill=claro)
    # Distintivo con la letra.
    bx0, by0, bx1, by1 = 34 * e, 26 * e, 78 * e, 70 * e
    d.rounded_rectangle([bx0, by0, bx1, by1], radius=5 * e, fill=color + (255,))
    f = _fuente((26 if len(letra) == 1 else 14) * e, negrita=True)
    d.text(((bx0 + bx1) / 2, (by0 + by1) / 2), letra, font=f, fill=(255, 255, 255, 255),
           anchor="mm")
    # Nombre del archivo.
    fn = _fuente(11 * e)
    for k, linea in enumerate(_partir(nombre, fn, w - 8 * e, d)):
        d.text((w / 2, (90 + k * 14) * e), linea, font=fn, fill=(35, 38, 48, 255), anchor="ma")
    img = img.resize((_ANCHO, _ALTO), Image.LANCZOS)
    destino.parent.mkdir(parents=True, exist_ok=True)
    img.save(destino)
    return destino


# ── Fichero compuesto (CFB v3, [MS-CFB]) ──────────────────────────────

_SECTOR, _MINI, _CORTE = 512, 64, 4096
_LIBRE, _FIN, _SECT_FAT, _SECT_DIFAT, _SIN = (0xFFFFFFFF, 0xFFFFFFFE, 0xFFFFFFFD,
                                              0xFFFFFFFC, 0xFFFFFFFF)


def _sectores(n_bytes: int, tam: int) -> int:
    return math.ceil(n_bytes / tam) if n_bytes else 0


def _arbol(indices: list[int]) -> tuple[Optional[int], dict]:
    """Árbol rojo-negro equilibrado de las entradas hijas. Devuelve la raíz y
    {índice: (izquierdo, derecho, color)}; el último nivel incompleto va en rojo
    para que todas las ramas tengan la misma cantidad de nodos negros."""
    nodos: dict[int, tuple] = {}
    completo = int(math.log2(len(indices) + 1)) if indices else 0

    def construir(lo: int, hi: int, prof: int) -> Optional[int]:
        if lo > hi:
            return None
        mid = (lo + hi) // 2
        izq, der = construir(lo, mid - 1, prof + 1), construir(mid + 1, hi, prof + 1)
        nodos[indices[mid]] = (izq, der, 0 if prof >= completo else 1)   # 0 rojo, 1 negro
        return indices[mid]
    return construir(0, len(indices) - 1, 0), nodos


def _entrada(nombre: str, tipo: int, color: int, izq, der, hijo, clsid: bytes,
             inicio: int, tam: int) -> bytes:
    n = (nombre + "\0").encode("utf-16-le") if nombre else b""
    return (n.ljust(64, b"\0") + struct.pack("<HBB", len(n), tipo, color)
            + struct.pack("<III", _SIN if izq is None else izq, _SIN if der is None else der,
                          _SIN if hijo is None else hijo)
            + clsid.ljust(16, b"\0") + b"\0" * 4 + b"\0" * 16
            + struct.pack("<IQ", inicio, tam))


def fichero_compuesto(flujos: dict[str, bytes], clsid: bytes = b"") -> bytes:
    """Fichero compuesto con `flujos` (nombre → bytes) bajo la raíz."""
    nombres = sorted(flujos, key=lambda s: (len(s), s.upper()))
    mini = bytearray()
    minifat: list[int] = []
    inicio: dict[str, int] = {}
    grandes: list[str] = []
    for nom in nombres:
        datos = flujos[nom]
        if len(datos) >= _CORTE:
            grandes.append(nom)
            continue
        n = _sectores(len(datos), _MINI)
        if not n:
            inicio[nom] = _FIN
            continue
        primero = len(mini) // _MINI
        mini += datos.ljust(n * _MINI, b"\0")
        minifat += [primero + k + 1 for k in range(n - 1)] + [_FIN]
        inicio[nom] = primero

    # Cadenas de sectores normales: contenedor del mini stream, flujos grandes,
    # mini FAT y directorio (en ese orden); después la FAT y la DIFAT.
    cadenas: list[tuple[str, bytes]] = [("__mini__", bytes(mini))]
    cadenas += [(nom, flujos[nom]) for nom in grandes]
    cadenas.append(("__minifat__", struct.pack(f"<{len(minifat)}I", *minifat)))
    n_entradas = 1 + len(nombres)
    cadenas.append(("__dir__", b"\0" * (_sectores(n_entradas * 128, _SECTOR) * _SECTOR)))
    datos_sect = sum(_sectores(len(b), _SECTOR) for _, b in cadenas)
    n_fat, n_difat = 1, 0
    while datos_sect + n_fat + n_difat > n_fat * 128:
        n_fat += 1
        n_difat = max(0, math.ceil((n_fat - 109) / 127))
    total = datos_sect + n_fat + n_difat

    fat = [_LIBRE] * (n_fat * 128)
    sector, inicios = 0, {}
    for clave, blob in cadenas:
        n = _sectores(len(blob), _SECTOR)
        inicios[clave] = sector if n else _FIN
        for k in range(n):
            fat[sector + k] = sector + k + 1 if k < n - 1 else _FIN
        sector += n
    sect_fat = list(range(sector, sector + n_fat))
    sect_difat = list(range(sector + n_fat, total))
    for s in sect_fat:
        fat[s] = _SECT_FAT
    for s in sect_difat:
        fat[s] = _SECT_DIFAT
    for nom in grandes:
        inicio[nom] = inicios[nom]

    # Directorio.
    raiz_hijo, arbol = _arbol(list(range(1, n_entradas)))
    dir_ = bytearray(_entrada("Root Entry", 5, 1, None, None, raiz_hijo, clsid,
                              inicios["__mini__"], len(mini)))
    for i, nom in enumerate(nombres, start=1):
        izq, der, color = arbol[i]
        dir_ += _entrada(nom, 2, color, izq, der, None, b"", inicio[nom], len(flujos[nom]))
    vacia = _entrada("", 0, 0, None, None, None, b"", 0, 0)
    while len(dir_) % _SECTOR:
        dir_ += vacia
    cadenas[-1] = ("__dir__", bytes(dir_))

    cab = bytearray(b"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1" + b"\0" * 16)
    cab += struct.pack("<HHHHH", 0x003E, 0x0003, 0xFFFE, 9, 6) + b"\0" * 6
    cab += struct.pack("<IIIIIIIII", 0, n_fat, inicios["__dir__"], 0, _CORTE,
                       inicios["__minifat__"], _sectores(len(minifat) * 4, _SECTOR),
                       sect_difat[0] if sect_difat else _FIN, n_difat)
    difat = sect_fat[:109] + [_LIBRE] * (109 - min(109, n_fat))
    cab += struct.pack("<109I", *difat)

    cuerpo = bytearray()
    for _, blob in cadenas:
        n = _sectores(len(blob), _SECTOR)
        cuerpo += blob.ljust(n * _SECTOR, b"\0")
    cuerpo += struct.pack(f"<{len(fat)}I", *fat)
    resto = sect_fat[109:]
    for k, _s in enumerate(sect_difat):
        trozo = resto[k * 127:(k + 1) * 127]
        siguiente = sect_difat[k + 1] if k + 1 < len(sect_difat) else _FIN
        cuerpo += struct.pack("<128I", *(trozo + [_LIBRE] * (127 - len(trozo)) + [siguiente]))
    return bytes(cab) + bytes(cuerpo)


def _ansi(texto: str) -> bytes:
    return texto.encode("cp1252", errors="replace") + b"\0"


def paquete_ole(nombre: str, datos: bytes) -> bytes:
    """`oleObject.bin` de un «paquete OLE» que contiene `datos` como `nombre`."""
    ruta = "C:\\" + nombre
    nativo = (struct.pack("<H", 2) + _ansi(nombre) + _ansi(ruta) + struct.pack("<HH", 0, 3)
              + struct.pack("<I", len(_ansi(ruta))) + _ansi(ruta)
              + struct.pack("<I", len(datos)) + datos)
    ole10 = struct.pack("<I", len(nativo)) + nativo

    def lp(s: str) -> bytes:
        b = _ansi(s)
        return struct.pack("<I", len(b)) + b
    compobj = (struct.pack("<IIi", 0xFFFE0001, 0x00000A03, -1) + _CLSID_PAQUETE
               + lp("OLE Package") + struct.pack("<I", 0) + lp("Package")
               + struct.pack("<IIII", 0x71B239F4, 0, 0, 0))
    return fichero_compuesto({"\x01Ole10Native": ole10, "\x01CompObj": compobj,
                              "\x03ObjInfo": b"\x00\x00\x03\x00\x04\x00"}, _CLSID_PAQUETE)


# ── Inserción en el documento ─────────────────────────────────────────

_NS = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
       'xmlns:v="urn:schemas-microsoft-com:vml" '
       'xmlns:o="urn:schemas-microsoft-com:office:office" '
       'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"')

_TIPO_FORMA = (
    '<v:shapetype id="_x0000_t75" coordsize="21600,21600" o:spt="75" o:preferrelative="t" '
    'path="m@4@5l@4@11@9@11@9@5xe" filled="f" stroked="f"><v:stroke joinstyle="miter"/>'
    '<v:formulas>' + "".join(f'<v:f eqn="{e}"/>' for e in (
        "if lineDrawn pixelLineWidth 0", "sum @0 1 0", "sum 0 0 @1", "prod @2 1 2",
        "prod @3 21600 pixelWidth", "prod @3 21600 pixelHeight", "sum @0 0 1", "prod @6 1 2",
        "prod @7 21600 pixelWidth", "sum @8 21600 0", "prod @7 21600 pixelHeight",
        "sum @10 21600 0")) + '</v:formulas>'
    '<v:path o:extrusionok="f" gradientshapeok="t" o:connecttype="rect"/>'
    '<o:lock v:ext="edit" aspectratio="t"/></v:shapetype>')


def incrustar(doc, parrafo, ruta: Path, nombre: str, carpeta_iconos: Path,
              ancho_pt: float = 81.0) -> None:
    """Añade al `parrafo` el archivo `ruta` incrustado, mostrado como icono con
    `nombre` debajo. `carpeta_iconos`: dónde dejar el PNG del icono."""
    ruta = Path(ruta)
    datos = ruta.read_bytes()
    _fam, progid, ct = EXTENSIONES.get(Path(nombre).suffix.lower(), ("generico", None, None))
    paquete = doc.part.package
    if progid:
        ext = Path(nombre).suffix.lower()
        uri = paquete.next_partname(f"/word/embeddings/Adjunto%d{ext}")
        parte = Part(PackURI(uri), ct, datos, paquete)
        rid_ole = doc.part.relate_to(parte, _RT_PAQUETE)
    else:
        progid = "Package"
        uri = paquete.next_partname("/word/embeddings/oleObject%d.bin")
        parte = Part(PackURI(uri), _CT_OLE, paquete_ole(nombre, datos), paquete)
        rid_ole = doc.part.relate_to(parte, RT.OLE_OBJECT)
    icono = icono_png(nombre, Path(carpeta_iconos) / f"icono_{uuid.uuid4().hex}.png")
    rid_img, _ = doc.part.get_or_add_image(str(icono))

    alto_pt = round(ancho_pt * _ALTO / _ANCHO, 1)
    forma = f"_x0000_i{1025 + (uuid.uuid4().int % 8000)}"
    objeto = f"_{1_000_000_000 + uuid.uuid4().int % 999_999_999}"
    # La definición del tipo de forma va una sola vez por documento.
    primero = not getattr(doc, "_virf_tipo_forma_ole", False)
    doc._virf_tipo_forma_ole = True
    xml = (f'<w:r {_NS}><w:object w:dxaOrig="{int(ancho_pt * 20)}" w:dyaOrig="{int(alto_pt * 20)}">'
           + (_TIPO_FORMA if primero else "")
           + f'<v:shape id="{forma}" type="#_x0000_t75" style="width:{ancho_pt}pt;height:{alto_pt}pt" o:ole="">'
           f'<v:imagedata r:id="{rid_img}" o:title=""/></v:shape>'
           f'<o:OLEObject Type="Embed" ProgID="{progid}" ShapeID="{forma}" DrawAspect="Icon" '
           f'ObjectID="{objeto}" r:id="{rid_ole}"/></w:object></w:r>')
    parrafo._p.append(parse_xml(xml))
