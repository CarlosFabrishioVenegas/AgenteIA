

"""
modulos/generador_word.py
Genera VIRF_Informe_*.docx — Informe de validación en formato PLANO y legible

Estructura simplificada del informe:
  1. Portada (títulos básicos)
  2. Resumen ejecutivo (si aplica)
  3. Listado jerárquico:
     - ÁMBITO
       - Control
         - Actividad 1
           Concepto de actividad: ...
           Resultado de la actividad: ...
           Observaciones: ...
           Oportunidad de mejora: ...
         - Actividad 2
           ...
"""
 
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import re

import logging

from modulos import word_estilo as _WE

logger = logging.getLogger(__name__)
 
try:
    from config import ESCALA_PUNTAJE, SCORE_SEMAFORO, AMBITO_PESOS
except ImportError:
    from Mx_00_CargaRutas import RUTAS
    from config import ESCALA_PUNTAJE, SCORE_SEMAFORO, AMBITO_PESOS
 
 
# ─── Colores corporativos ─────────────────────────────────────────────────────
AZUL_DARK  = RGBColor(0x1F, 0x38, 0x64)
AZUL_MID   = RGBColor(0x2E, 0x75, 0xB6)
GRIS_TEXT  = RGBColor(0x40, 0x40, 0x40)
BLANCO     = RGBColor(0xFF, 0xFF, 0xFF)
NARANJA    = RGBColor(0xFF, 0x66, 0x00)
 
 
# ─── Utilidades de color y escala ─────────────────────────────────────────────
 
def _hex_to_rgb(h: str) -> RGBColor:
    h = h.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
 
 
def _score_color_hex(score) -> str:
    # Espejo de motor_ia.get_semaforo(): None = fallo técnico (gris, sin
    # veredicto); 0.0 = sin evidencia, que la política trata como falta
    # crítica y por tanto va en rojo, no en gris.
    if score is None:
        return "CCCCCC"
    if score <= 0.0:
        return "FF0000"
    # [AUDIT-FIX 2026-08-07] Un score fuera de escala caía al gris de «sin
    # clasificar», que es el color reservado a «no evaluable». Los puntajes se
    # clampan aguas arriba, así que llegar aquí ya indicaría un defecto — pero
    # pintar de gris un 5.01 lo haría pasar por no evaluado. Se satura al tramo
    # extremo, que es lo que el número quiere decir.
    score = max(0.0, min(5.0, float(score)))
    for (lo, hi), info in SCORE_SEMAFORO.items():
        if lo <= score <= hi:
            return info["color"]
    return "CCCCCC"


def _label_semaforo(score) -> str:
    # [AUDIT-FIX] Antes None se rotulaba "SIN EVIDENCIA". Con la política de
    # la entidad son cosas distintas y con responsables opuestos:
    #   None → fallo técnico del agente; no hay dictamen.
    #   0.0  → el validado no aportó evidencia; falta crítica.
    # Además un 0.0 caía en el tramo (0.0, 1.5) y se rotulaba "CRÍTICO" a
    # secas, perdiendo la causa que lo explica.
    if score is None:
        return "NO EVALUABLE — FALLO TÉCNICO"
    if score <= 0.0:
        return "NO EVALUABLE — SIN EVIDENCIA"
    score = max(0.0, min(5.0, float(score)))   # mismo clamp que en el color
    for (lo, hi), info in SCORE_SEMAFORO.items():
        if lo <= score <= hi:
            return info["label"]
    return "SIN CLASIFICAR"
 
 
def _puntaje_label(p) -> str:
    # Los dos casos fuera de la escala 1-5, que tienen responsables distintos:
    #   None → fallo técnico del agente. No hay dictamen; se re-ejecuta.
    #   0    → sin evidencia. Política de la entidad: falta crítica imputable
    #          al validado. Se nombra por su causa, no como "No cumple", para
    #          no atribuirle un incumplimiento que nadie ha comprobado.
    if p is None:
        return "NO EVALUADA — fallo técnico"
    if p == 0:
        return "SIN EVIDENCIA — falta crítica"
    return ESCALA_PUNTAJE.get(p, {}).get("label", str(p))
 
 
def _puntaje_color_hex(p) -> str:
    if p is None:
        return "CCCCCC"          # gris: fallo del agente, no hay veredicto
    if p == 0:
        return "FF0000"          # rojo: la falta de evidencia ES una falta crítica
    return ESCALA_PUNTAJE.get(p, {}).get("color", "CCCCCC")


def _status_resultado(puntaje) -> str:
    """Etiqueta de estado para el campo 'Resultado de la actividad'."""
    if puntaje is None:
        return "NO EVALUADA — FALLO TÉCNICO"
    if puntaje == 0:
        # Sin esta rama el 0 caía en "SIN CLASIFICAR": el campo que el auditor
        # lee para saber el resultado no decía nada, justo en la actividad
        # donde la política dicta una falta crítica.
        return "SIN EVIDENCIA — FALTA CRÍTICA"
    return {
        1: "NO CUMPLE",
        2: "REQUIERE REMEDIACIÓN CRÍTICA",
        3: "CON OBSERVACIONES",
        4: "ACEPTABLE",
        5: "CUMPLE COMPLETAMENTE",
    }.get(puntaje, "SIN CLASIFICAR")
 
 
def _score_o_puntaje(ev: dict):
    """
    Devuelve el score si trae valor, y si no el puntaje.

    [AUDIT-FIX] Antes: `ev.get("score", ev.get("puntaje"))`. El segundo
    argumento de .get() es el valor por DEFECTO: solo se usa cuando la clave
    FALTA. Si "score" viene presente con valor None —que es exactamente lo que
    produce ahora la rama sin-documentos de Mx_03, y lo que devuelve el modelo
    cuando no puede puntuar— la expresión resuelve a None y el puntaje válido
    que sí estaba en el dict se descarta. Mismo fallo que el `.get("puntaje",
    50)` corregido en esta misma auditoría.
    """
    s = ev.get("score")
    return s if s is not None else ev.get("puntaje")


def _normalizar_score(raw) -> Optional[int]:
    """
    Convierte score (0-100) o puntaje (1-5) a la escala de política 0-5.

    El 0 está RESERVADO a la falta de evidencia (política de la entidad: falta
    crítica) y no puede alcanzarse desde una evaluación real, cuya escala
    empieza en 1. `None` significa fallo técnico: no hay puntaje que mostrar.

    [AUDIT-FIX] Tres defectos, todos silenciosos:

    1. `raw is None` → 1. None es lo que produce un FALLO TÉCNICO (timeout,
       PDF ilegible): la actividad aparecía en el informe como "1 — No cumple",
       el PEOR puntaje, acusando al validado de un fallo del agente. Ahora
       devuelve None y el informe la muestra como no evaluada.

       Ojo con no confundir los dos casos: una actividad SIN EVIDENCIA sí
       debe mostrar 0 —es una falta crítica imputable al validado— y por eso
       el clamp inferior es 0 y no 1. Lo que nunca debe ocurrir es que un
       fallo NUESTRO se convierta en un puntaje contra ELLOS.

    2. La heurística «si raw > 5 es escala 0-100» colapsaba el rango (5, 12]:
           5.4 → round(1 + 0.054*4) = 1
           6   → 1
       Un puntaje casi perfecto se convertía en el peor. Ahora ese tramo se
       trata como desbordamiento de la escala 1-5 y se acota a 5.

    3. `round(raw) or 1` usaba `or`, que convierte el 0 legítimo en 1 por ser
       falsy — inofensivo aquí, pero se hace explícito.
    """
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return None
    try:
        raw = float(raw)
    except (TypeError, ValueError):
        return None

    # Tramo ambiguo: por encima de 5 pero muy lejos de una escala 0-100.
    # Un 5.4 o un 6 son casi con seguridad un 1-5 desbordado, no un 0-100.
    if raw > 12:
        return max(1, min(5, round(1 + (raw / 100) * 4)))
    # Clamp inferior 0, no 1: el 0 de «sin evidencia» tiene que sobrevivir
    # hasta el informe. Cualquier otro valor sigue acotado a la escala 1-5.
    return max(0, min(5, round(raw)))


def _es_error(texto: str) -> bool:
    """
    Detecta si el texto ES un mensaje de error técnico (no si lo menciona).

    [AUDIT-FIX] La versión anterior buscaba subcadenas sueltas —"error", "api",
    "n/a", "connection"— en cualquier posición. Como el llamador BORRA el campo
    cuando esto da True (`observ = ""`), cualquier hallazgo legítimo que
    mencionara esas palabras DESAPARECÍA del informe que lee el auditor:

        "El manual documenta la API de extracción desde el core bancario
         y no presenta errores de implementación."     → borrado

    Medido: esa frase daba True por "api" y por "error". Ahora se exige que el
    texto EMPIECE con una firma de error técnico, no que la contenga.
    """
    if not texto:
        return False
    t = str(texto).strip()
    if not t:
        return False

    # Firmas de error al PRINCIPIO del texto: así es como los generan los
    # lectores de Mx_01 y los fallbacks del motor ("[Error ...]", "Traceback...").
    if re.match(r"^\s*[\[\(]?\s*(error|traceback|exception|timeout|"
                r"connection\s*error|unauthorized|http\s*\d{3}|\d{3}\s+"
                r"(error|unauthorized|forbidden))\b", t, re.IGNORECASE):
        return True

    # Marcadores explícitos que el propio proyecto emite.
    firmas = (
        "evaluación no realizada",
        "no se pudo evaluar",
        "[error",
        "lectura-fallida",
        "pdf no legible",
    )
    t_low = t.lower()
    if any(t_low.startswith(f) or f in t_low[:80] for f in firmas):
        return True

    # Un texto que es SOLO un marcador de ausencia.
    return t_low in ("n/a", "na", "no disponible", "-", "--", "sin datos")


def _generar_recomendacion_automatica(actividad: str, puntaje: int, concepto: str = "", observacion: str = "") -> str:
    """
    Genera una recomendación automática según el puntaje y contexto.
    Útil cuando falla la evaluación de la IA.
    """
    recomendaciones_por_puntaje = {
        1: f"Se recomienda verificar inmediatamente la existencia y disponibilidad de documentación para '{actividad}'. Realizar un diagnóstico inicial de lo que se necesita documentar.",
        2: f"Se requiere remediación crítica para '{actividad}'. Priorizar la creación y documentación de los procesos y controles identificados como ausentes.",
        3: f"Se recomienda completar los elementos faltantes para '{actividad}'. Revisar brechas identificadas y establecer plan de acción.",
        4: f"Implementar las mejoras menores sugeridas para '{actividad}'. Validar que los controles estén funcionando adecuadamente.",
        5: f"Mantener el nivel actual de cumplimiento en '{actividad}'. Continuar con el seguimiento periódico de la documentación.",
    }
    return recomendaciones_por_puntaje.get(puntaje, "Revisar y validar el control según los hallazgos identificados.")


# ─── Helpers de formato Word ──────────────────────────────────────────────────
 
def _set_cell_bg(cell, hex_color: str):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color.upper())
    tcPr.append(shd)
 
 
def _set_cell_borders(cell, color: str = "CCCCCC", size: int = 4):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for side in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(size))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color.upper())
        tcBorders.append(el)
    tcPr.append(tcBorders)
 
 
def _cell_text(cell, text: str, bold=False, italic=False,
               color: RGBColor = None, size: int = 9, align: str = "left"):
    para = cell.paragraphs[0]
    para.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                      "center": WD_ALIGN_PARAGRAPH.CENTER,
                      "right": WD_ALIGN_PARAGRAPH.RIGHT}.get(align, WD_ALIGN_PARAGRAPH.LEFT)
    if not para.runs:
        para.add_run("")
    run = para.runs[0]
    run.text = str(text or "")
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    _WE.aplicar_fuente(run)
    run.font.color.rgb = color or GRIS_TEXT
 
 
def _add_heading(doc: Document, text: str, level: int = 1):
    p = doc.add_heading(text, level=level)
    for run in p.runs:
        run.font.color.rgb = AZUL_DARK if level == 1 else AZUL_MID
        _WE.aplicar_fuente(run)
    return p
 
 
def _add_para(doc: Document, text: str, bold=False, italic=False,
              color: RGBColor = None, size: int = 10, align: str = "left"):
    # `left` pasa a significar «prosa», y la prosa va justificada: es un informe
    # regulatorio, no una nota suelta. Se conserva `align="center"` explícito y
    # se añade `align="izquierda"` para lo que NO debe justificarse —cifras,
    # rutas de fichero, cualquier cosa que al estirarse se lea peor.
    p = doc.add_paragraph()
    p.alignment = {"left": WD_ALIGN_PARAGRAPH.JUSTIFY,
                   "izquierda": WD_ALIGN_PARAGRAPH.LEFT,
                   "center": WD_ALIGN_PARAGRAPH.CENTER}.get(align, WD_ALIGN_PARAGRAPH.JUSTIFY)
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    _WE.aplicar_fuente(run)
    run.font.color.rgb = color or GRIS_TEXT
    return p
 
 
def _add_numbered(doc: Document, text: str, size: int = 9):
    p = doc.add_paragraph(style="List Number")
    run = p.add_run(text)
    run.font.size = Pt(size)
    _WE.aplicar_fuente(run)
    run.font.color.rgb = GRIS_TEXT
 
 
def _add_bullet(doc: Document, text: str, size: int = 9):
    p = doc.add_paragraph(style="List Bullet")
    run = p.add_run(text)
    run.font.size = Pt(size)
    _WE.aplicar_fuente(run)
    run.font.color.rgb = GRIS_TEXT
 
 
def _hr(doc: Document, color_hex: str = "2E75B6"):
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color_hex.upper())
    pBdr.append(bottom)
    pPr.append(pBdr)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after  = Pt(4)
 
 
# ─── Helpers para generar contenido jerárquico plano ──────────────────────────

def _add_ambito_heading(doc: Document, ambito: str, puntaje: int):
    """Encabezado de ámbito con línea decorativa inferior."""
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0)
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after  = Pt(2)
    run = p.add_run(f"ÁMBITO: {ambito.upper()}")
    run.font.size = Pt(13)
    run.font.bold = True
    run.font.color.rgb = AZUL_DARK
    _WE.aplicar_fuente(run)
    _hr(doc, "1F3864")



_SEV_COLOR = {"critica": "C00000", "alta": "FF6600",
              "media": "BF8F00", "baja": "808080"}


#: Alias con los que las distintas skills nombran el título de un hallazgo.
#: Cada una usa los términos naturales de su análisis a propósito —el catálogo
#: lo documenta—, así que aquí se buscan en orden en vez de uniformarlos.
_ALIAS_TITULO_SKILL = ("hallazgo", "aspecto", "supuesto", "exigencia",
                       "referencia", "decision_del_modelo", "debilidad")
_ALIAS_SEV_SKILL = ("severidad", "estado", "veredicto", "impacto")


def _seccion_skills(doc: Document, skills: Optional[List[Dict]],
                    con_titulo: bool = True) -> None:
    """
    Análisis transversales en el ENTREGABLE.

    [AUDIT-FIX] Con `--skills all` se pagan hasta 8 llamadas extra al modelo.
    Sus hallazgos llegaban al JSON y al borrador `.md` de trabajo, pero NO al
    Word — `generador_word.py` no tenía una sola mención a `skills`. Es la misma
    pérdida que ya se corrigió en la revisión de código: el trabajo caro se paga
    y se descarta justo antes del documento que se entrega.

    Y el borrador `.md` no lo sustituye: es el papel que el validador lee
    mientras decide, no lo que recibe el auditor.

    Qué se pinta, y por qué en este orden:

      · La TABLA DE EJECUCIÓN primero, incluidas las que fallaron. Una skill que
        no corrió es una limitación del alcance y tiene que constar; omitirla
        haría parecer que el análisis fue completo.
      · La SÍNTESIS antes que el resto, porque es la lectura de conjunto.
      · Las CITAS NO VERIFICADAS de cada skill, si las hay. Ese campo existe
        precisamente para que un hallazgo con cita inventada no pase por bueno,
        y esconderlo en el JSON lo dejaba sin efecto práctico.
    """
    if not skills or not isinstance(skills, list):
        return

    if con_titulo:
        _add_heading(doc, "ANEXO: ANÁLISIS TRANSVERSALES", level=1)
    _add_para(doc,
              "Investigaciones que cruzan varias fuentes y no caben en una "
              "casilla del estándar. NO alteran el score: producen hallazgos, "
              "no puntajes. Se incluyen porque un análisis que no llega al "
              "informe es un análisis que no se hizo.",
              italic=True, size=9)
    doc.add_paragraph()

    # ── Tabla de ejecución ───────────────────────────────────────────────────
    t = doc.add_table(rows=1, cols=4)
    enc = t.rows[0].cells
    for i, h in enumerate(("Análisis", "Estado", "Hallazgos", "Tiempo")):
        _cell_text(enc[i], h, bold=True, color=BLANCO, size=8, align="center")
        _set_cell_bg(enc[i], "1F3864")
        _set_cell_borders(enc[i], "1F3864")
    for r in skills:
        if not isinstance(r, dict):
            continue
        fila = t.add_row().cells
        _ok = bool(r.get("ok"))
        _cell_text(fila[0], str(r.get("titulo") or r.get("nombre") or "?")[:48],
                   size=8)
        _cell_text(fila[1],
                   "Ejecutado" if _ok else f"NO EJECUTADO — {str(r.get('error',''))[:60]}",
                   size=8, color=None if _ok else _hex_to_rgb("C00000"))
        _cell_text(fila[2], str(len(r.get("hallazgos") or [])), size=8,
                   align="center")
        _cell_text(fila[3], f"{r.get('duracion_seg', 0)}s", size=8, align="center")
        for celda in fila:
            _set_cell_borders(celda, "CCCCCC")
    doc.add_paragraph()

    # ── Detalle, con la síntesis primero ─────────────────────────────────────
    orden = sorted((r for r in skills if isinstance(r, dict)),
                   key=lambda r: 0 if r.get("nombre") == "sintesis" else 1)
    for r in orden:
        if not r.get("ok"):
            continue
        _add_heading(doc, str(r.get("titulo") or r.get("nombre") or ""), level=2)
        if str(r.get("resumen") or "").strip():
            _add_para(doc, str(r["resumen"]).strip(), size=9.5)

        for h in r.get("hallazgos") or []:
            if not isinstance(h, dict):
                continue
            titulo = next((str(h[k]) for k in _ALIAS_TITULO_SKILL if h.get(k)), "—")
            sev = next((str(h[k]) for k in _ALIAS_SEV_SKILL if h.get(k)), "")

            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Cm(0.5)
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(1)
            run = p.add_run(f"• {titulo[:220]}")
            run.bold = True
            run.font.size = Pt(9)
            _WE.aplicar_fuente(run)
            run.font.color.rgb = GRIS_TEXT
            if sev:
                rs = p.add_run(f"   [{sev[:28]}]")
                rs.font.size = Pt(8)
                _WE.aplicar_fuente(rs)
                rs.font.color.rgb = NARANJA

            # Cuerpo y citas: se recorre lo que la skill haya devuelto, sin
            # exigir un esquema único. Uniformarlo obligaría a tocar las ocho
            # skills cada vez que una añada un campo.
            for clave, valor in h.items():
                if clave in _ALIAS_TITULO_SKILL or clave in _ALIAS_SEV_SKILL:
                    continue
                if not isinstance(valor, str) or not valor.strip():
                    continue
                es_cita = clave.startswith("cita")
                pc = doc.add_paragraph()
                pc.paragraph_format.left_indent = Cm(0.9)
                pc.paragraph_format.space_after = Pt(1)
                rc = pc.add_run(
                    (f"«{valor.strip()[:400]}»" if es_cita
                     else f"{clave.replace('_', ' ')}: {valor.strip()[:400]}"))
                rc.font.size = Pt(8)
                _WE.aplicar_fuente(rc, _WE.FUENTE_MONO if es_cita else None)
                rc.italic = es_cita
                rc.font.color.rgb = GRIS_TEXT

        # ── Citas que no se pudieron verificar ───────────────────────────────
        _dudosas = r.get("citas_no_verificadas") or []
        if _dudosas:
            doc.add_paragraph()
            _add_para(doc,
                      f"⚠ {len(_dudosas)} cita(s) de este análisis NO se "
                      f"encontraron literalmente en la evidencia. Verificar "
                      f"antes de sostenerlas en el dictamen.",
                      bold=True, color=NARANJA, size=8.5)
            for c in _dudosas[:8]:
                _add_bullet(doc, str(c)[:200], size=8)

    doc.add_page_break()


def _sombrear_parrafo(parrafo, hex_color: str) -> None:
    """
    Fondo de un párrafo. Equivalente a `_set_cell_bg` pero sobre `w:pPr`.

    Se usa para que el fragmento de código se lea como código dentro del Word.
    Envuelto en try porque es puramente estético: si una versión de python-docx
    cambia el XML, el informe debe salir igual —sin fondo— en vez de no salir.
    """
    try:
        pPr = parrafo._p.get_or_add_pPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:color"), "auto")
        shd.set(qn("w:fill"), hex_color.upper())
        pPr.append(shd)
    except Exception:                                      # pragma: no cover
        pass


def _add_hallazgos_codigo(doc: Document, hallazgos: List[Dict],
                          indent: float = 0.5) -> None:
    """
    Pinta cada discrepancia código↔documentación con el FRAGMENTO a la vista.

    [AUDIT-FIX] Por qué existe
    ──────────────────────────
    `--revisar-codigo` localiza el fragmento exacto y explica por qué está mal;
    es la parte cara de la revisión, una llamada al modelo por módulo. Todo eso
    se aplastaba en una línea de texto antes de llegar aquí —cinco hallazgos,
    120 caracteres cada uno, y el código descartado— así que el informe
    ENTREGABLE decía «calcula_var.py:87 [code_drift] Aplica un ajuste que la
    documentación no menciona» y nada más. El fragmento solo sobrevivía en un
    .md aparte que no se entrega.

    Un dictamen sobre código que no transcribe el código no es verificable: el
    lector no puede juzgar si la objeción es correcta, solo creerla. Aquí se
    presenta lo que un validador escribiría a mano:

        · dónde está          → fichero:línea
        · qué dice el código  → el fragmento, transcrito
        · por qué está mal    → la descripción del hallazgo
        · contra qué          → la referencia documental, y si se verificó

    El estado del anclaje se pinta SIEMPRE que la categoría lo exija, también
    cuando falta la referencia: un `code_drift` sin cita es precisamente el
    caso que un revisor humano tiene que comprobar antes de firmar, y ocultarlo
    lo haría pasar por un hallazgo probado.
    """
    if not hallazgos:
        return

    p_hdr = doc.add_paragraph()
    p_hdr.paragraph_format.left_indent = Cm(indent)
    p_hdr.paragraph_format.space_before = Pt(8)
    p_hdr.paragraph_format.space_after = Pt(4)
    r_hdr = p_hdr.add_run("🔬  Discrepancias código ↔ documentación")
    r_hdr.bold = True
    r_hdr.font.size = Pt(9)
    _WE.aplicar_fuente(r_hdr)
    r_hdr.font.color.rgb = AZUL_DARK

    for h in hallazgos:
        sev = str(h.get("severidad", "media")).lower()
        cat = str(h.get("categoria", ""))
        ubic = h.get("fichero", "?")
        if h.get("linea"):
            ubic += f":{h['linea']}"

        # Cabecera del hallazgo: dónde y de qué tipo.
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(indent + 0.3)
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(1)
        r = p.add_run(f"[{sev.upper()}] {ubic}")
        r.bold = True
        r.font.size = Pt(8)
        _WE.aplicar_fuente(r)
        r.font.color.rgb = _hex_to_rgb(_SEV_COLOR.get(sev, "808080"))
        r2 = p.add_run(f"   ·  {cat.replace('_', ' ')}")
        r2.font.size = Pt(8)
        _WE.aplicar_fuente(r2)
        r2.font.color.rgb = GRIS_TEXT

        # El código, transcrito literal y con aspecto de celda: monoespaciada,
        # fondo, borde y NÚMERO DE LÍNEA. Es lo que permite al lector juzgar la
        # objeción en vez de creerla.
        #
        # La numeración arranca en la línea real del hallazgo y esa línea va
        # resaltada. Sin números, un hallazgo que acusa a `calcula_var.py:14`
        # obliga a abrir el fichero y contar a mano para comprobarlo — y lo que
        # cuesta comprobar, no se comprueba.
        if h.get("evidencia_codigo"):
            _cod = str(h["evidencia_codigo"])[:600]
            try:
                _ini = int(h.get("linea") or 1)
            except (TypeError, ValueError):
                _ini = 1
            _WE.add_bloque_codigo(doc, _cod, linea_inicial=_ini,
                                  resaltar=[_ini] if h.get("linea") else None)

        # Por qué está mal.
        if h.get("descripcion"):
            p_desc = doc.add_paragraph()
            p_desc.paragraph_format.left_indent = Cm(indent + 0.6)
            p_desc.paragraph_format.space_after = Pt(2)
            r_desc = p_desc.add_run(str(h["descripcion"])[:800])
            r_desc.font.size = Pt(8.5)
            _WE.aplicar_fuente(r_desc)
            r_desc.font.color.rgb = GRIS_TEXT

        # Contra qué se contrasta, y si esa referencia se pudo acreditar.
        _verif = h.get("referencia_verificada")
        if h.get("referencia_manual"):
            p_ref = doc.add_paragraph()
            p_ref.paragraph_format.left_indent = Cm(indent + 0.6)
            p_ref.paragraph_format.space_after = Pt(2)
            r_ref = p_ref.add_run(
                f"Documentación: «{str(h['referencia_manual'])[:400]}»")
            r_ref.italic = True
            r_ref.font.size = Pt(8)
            _WE.aplicar_fuente(r_ref)
            r_ref.font.color.rgb = GRIS_TEXT
            if _verif is False:
                r_av = p_ref.add_run(
                    "   ⚠ SIN ANCLAR: no se encontró literalmente en la "
                    "documentación; verificar antes de sostenerlo.")
                r_av.bold = True
                r_av.font.size = Pt(8)
                _WE.aplicar_fuente(r_av)
                r_av.font.color.rgb = NARANJA
        elif _verif is False:
            p_ref = doc.add_paragraph()
            p_ref.paragraph_format.left_indent = Cm(indent + 0.6)
            p_ref.paragraph_format.space_after = Pt(2)
            r_av = p_ref.add_run(
                "⚠ SIN ANCLAR: este hallazgo afirma lo que dice la documentación "
                "sin aportar el fragmento que lo acredite. Verificar antes de "
                "incluirlo en el dictamen.")
            r_av.bold = True
            r_av.font.size = Pt(8)
            _WE.aplicar_fuente(r_av)
            r_av.font.color.rgb = NARANJA


_CRIT_COLOR = {"CRITICA": "C00000", "CRÍTICA": "C00000", "ALTA": "FF6600",
               "MODERADA": "BF8F00", "MEDIA": "BF8F00", "BAJA": "808080"}
_CRIT_ORDEN = {"CRITICA": 0, "CRÍTICA": 0, "ALTA": 1, "MODERADA": 2,
               "MEDIA": 2, "BAJA": 3}


def _add_hallazgos_cdd(doc: Document, hallazgos: List[Dict],
                       indent: float = 0.5) -> None:
    """
    Hallazgos de los controles automáticos de calidad de datos.

    [AUDIT-FIX 2026-08-07] Estos hallazgos llegaban al informe como el `repr`
    del diccionario de Python —`{'tipo': 'OBSERVACION', 'texto': "…"}`—
    encadenados con « | » en un párrafo justificado. El origen se corrigió en
    `agente.py`; aquí se pintan como lo que son.

    Se ordenan por criticidad, no por el orden en que los devolvió el modelo:
    en un informe de 16 hallazgos, lo crítico tiene que estar arriba o no se
    lee. Y la criticidad se ROTULA además de colorearse — un informe impreso en
    blanco y negro, o leído por alguien que no distingue el rojo del naranja,
    debe seguir diciendo cuál es grave.
    """
    if not hallazgos:
        return

    p_hdr = doc.add_paragraph()
    p_hdr.paragraph_format.left_indent = Cm(indent)
    p_hdr.paragraph_format.space_before = Pt(8)
    p_hdr.paragraph_format.space_after = Pt(4)
    r_hdr = p_hdr.add_run(f"🔎  Hallazgos del control automático "
                          f"({len(hallazgos)})")
    r_hdr.bold = True
    r_hdr.font.size = Pt(9)
    _WE.aplicar_fuente(r_hdr)
    r_hdr.font.color.rgb = AZUL_DARK

    ordenados = sorted(
        hallazgos,
        key=lambda h: _CRIT_ORDEN.get(
            str(h.get("criticidad") or "").upper(), 9))

    for h in ordenados:
        crit = str(h.get("criticidad") or "SIN CLASIFICAR").upper()
        tipo = str(h.get("tipo") or "").replace("_", " ").title()
        riesgo = str(h.get("riesgo") or "").strip()

        # Cabecera: criticidad + tipo + riesgo.
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(indent + 0.3)
        p.paragraph_format.space_before = Pt(6)
        p.paragraph_format.space_after = Pt(1)
        r = p.add_run(f"[{crit}]")
        r.bold = True
        r.font.size = Pt(8)
        _WE.aplicar_fuente(r)
        r.font.color.rgb = _hex_to_rgb(_CRIT_COLOR.get(crit, "808080"))
        cola = f"  ·  {tipo}" + (f"  ·  riesgo {riesgo.lower()}" if riesgo else "")
        r2 = p.add_run(cola)
        r2.font.size = Pt(8)
        _WE.aplicar_fuente(r2)
        r2.font.color.rgb = GRIS_TEXT

        # Qué se observó.
        if h.get("texto"):
            p_t = doc.add_paragraph()
            p_t.paragraph_format.left_indent = Cm(indent + 0.6)
            p_t.paragraph_format.space_after = Pt(2)
            _WE.justificar(p_t)
            r_t = p_t.add_run(str(h["texto"]).strip())
            r_t.font.size = Pt(8.5)
            _WE.aplicar_fuente(r_t)
            r_t.font.color.rgb = GRIS_TEXT

        # Qué hacer. Es la parte accionable y antes se descartaba entera.
        if h.get("recomendacion"):
            p_r = doc.add_paragraph()
            p_r.paragraph_format.left_indent = Cm(indent + 0.6)
            p_r.paragraph_format.space_after = Pt(2)
            _WE.justificar(p_r)
            r_et = p_r.add_run("Recomendación: ")
            r_et.bold = True
            r_et.font.size = Pt(8)
            _WE.aplicar_fuente(r_et)
            r_et.font.color.rgb = AZUL_MID
            r_rc = p_r.add_run(str(h["recomendacion"]).strip())
            r_rc.font.size = Pt(8)
            _WE.aplicar_fuente(r_rc)
            r_rc.font.color.rgb = GRIS_TEXT


def _partir_por_vallas(texto: str) -> List[tuple]:
    """
    Separa un texto en tramos `(es_codigo, contenido)` según las vallas ```.

    Se apoya en que el modelo entrega el código entre vallas markdown, que es
    lo que hace en la práctica. Si no hay ninguna, devuelve el texto entero
    como prosa: sin vallas no hay forma FIABLE de saber qué es código, y
    adivinarlo por heurística —¿lleva paréntesis?, ¿empieza por `def`?—
    convertiría cualquier frase técnica en un bloque monoespaciado.

    Una valla sin cerrar se trata como código hasta el final: es lo que el
    modelo quiso marcar, y perderlo sería peor que un bloque de más.
    """
    if "```" not in (texto or ""):
        return [(False, texto)]

    tramos: List[tuple] = []
    for i, parte in enumerate((texto or "").split("```")):
        # Los índices impares caen DENTRO de las vallas.
        es_codigo = (i % 2 == 1)
        if es_codigo:
            # La primera línea suele ser el lenguaje (```python): se descarta.
            lineas = parte.split("\n")
            if lineas and lineas[0].strip() and " " not in lineas[0].strip():
                lineas = lineas[1:]
            parte = "\n".join(lineas)
        if parte.strip():
            tramos.append((es_codigo, parte.strip("\n") if es_codigo
                           else parte.strip()))
    return tramos or [(False, texto)]


def _add_field_block(doc: Document, label: str, value: str,
                     indent: float = 0.5, label_color: RGBColor = None):
    """Etiqueta en línea propia (bold) y contenido en el párrafo siguiente."""
    value = str(value).strip() if value else "No aplica"

    p_lbl = doc.add_paragraph()
    p_lbl.paragraph_format.left_indent = Cm(float(indent))
    p_lbl.paragraph_format.space_before = Pt(7)
    p_lbl.paragraph_format.space_after  = Pt(1)
    r = p_lbl.add_run(f"{label}:")
    r.font.size  = Pt(9)
    r.font.bold  = True
    r.font.color.rgb = label_color or AZUL_MID
    _WE.aplicar_fuente(r)

    # [AUDIT-FIX 2026-08-07] El valor puede traer CÓDIGO en vallas markdown
    # (```), sobre todo en «Evidencia encontrada»: el modelo transcribe el
    # fragmento del script que sostiene su afirmación.
    #
    # Antes se volcaba tal cual en un párrafo de prosa. Con la justificación
    # nueva el resultado era ilegible —cada línea de código estirada de margen
    # a margen, con las vallas ``` a la vista— y un fragmento de código que no
    # se puede leer literal deja de servir como evidencia, que es su único
    # cometido. Ahora las vallas se detectan y cada trozo se renderiza como lo
    # que es.
    p_val = None
    for es_codigo, trozo in _partir_por_vallas(value):
        if es_codigo:
            _WE.add_bloque_codigo(doc, trozo, numerar=False)
            continue
        # Un salto de línea DENTRO del run no crea un párrafo: Word lo trata
        # como línea interior y JUSTIFICA la última línea del bloque, que sale
        # estirada de margen a margen con huecos enormes entre palabras. Hay
        # que emitir un párrafo por bloque para que cada uno tenga su última
        # línea de verdad.
        for bloque in re.split(r"\n\s*\n", trozo):
            bloque = bloque.strip()
            if not bloque:
                continue
            p_val = doc.add_paragraph()
            p_val.paragraph_format.left_indent = Cm(float(indent))
            p_val.paragraph_format.space_before = Pt(1)
            p_val.paragraph_format.space_after  = Pt(3)
            _WE.justificar(p_val)
            r2 = p_val.add_run(bloque)
            r2.font.size  = Pt(9)
            r2.font.color.rgb = GRIS_TEXT
            _WE.aplicar_fuente(r2)

    if p_val is None:                 # el valor era SOLO código
        p_val = doc.add_paragraph()
        p_val.paragraph_format.space_after = Pt(1)
    # Se devuelve el párrafo del VALOR (no el de la etiqueta) para poder
    # anclarle la nota al pie de procedencia.
    return p_val


_RE_FUENTE_EVID = re.compile(r"([\w\-. ]+\.(?:md|pdf|docx?|xlsx?|csv|txt|py|ipynb|pptx))",
                             re.IGNORECASE)


def _procedencia_nota(ev: Dict) -> str:
    """
    Compone la nota al pie de procedencia de UNA actividad.

    Solo con lo que consta de verdad en el JSON. Si el corpus RAG no devolvió
    nada, se dice; no se rellena con un nombre plausible. Una nota al pie es
    una afirmación verificable —el auditor va a abrir ese fichero—, así que
    inventarla es peor que no ponerla.

    Sale algo como:
        Contrastado con manual_VaR_FRTB.md, backtesting_VaR_2026Q1.md ·
        Corpus RAG: dominio VaR (declarado), 3 fragmento(s) · Cobertura
        documental 100 %.
    """
    partes: List[str] = []

    # 1. De qué documentos salieron las citas de evidencia.
    evid = str(ev.get("evidencia") or ev.get("evidencia_encontrada") or "")
    fuentes: List[str] = []
    for m in _RE_FUENTE_EVID.findall(evid):
        f = m.strip()
        if f and f not in fuentes:
            fuentes.append(f)
    # Y las de los contrastes entre documentos.
    #
    # Se filtra por extensión a propósito. El modelo no siempre nombra un
    # fichero: escribe «CONTEXTO DISPONIBLE», «contexto disponible» o el título
    # de un bloque del prompt. Una nota que dijera «Contrastado con CONTEXTO
    # DISPONIBLE» manda al auditor a buscar un documento que no existe, y una
    # referencia que no se puede seguir es peor que ninguna.
    for inc in ev.get("inconsistencias") or []:
        if isinstance(inc, dict):
            for k in ("fuente_a", "fuente_b"):
                f = str(inc.get(k) or "").strip()
                if f and _RE_FUENTE_EVID.fullmatch(f) and f not in fuentes:
                    fuentes.append(f)
    if fuentes:
        partes.append("Contrastado con " + ", ".join(fuentes[:6]))

    # 2. Corpus de dominio. La procedencia del dominio importa: un dominio
    #    ADIVINADO por el título no acredita lo mismo que uno declarado.
    dom = str(ev.get("rag_dominio") or "")
    if dom and dom != "no_disponible":
        n = ev.get("rag_chunks") or 0
        proc = {"explicito": "declarado", "inferido": "inferido del título",
                "defecto": "por defecto"}.get(str(ev.get("rag_procedencia")),
                                              str(ev.get("rag_procedencia") or "—"))
        # Las fuentes concretas solo si la corrida las guardó (`rag_fuentes`).
        rf = [str(x) for x in (ev.get("rag_fuentes") or []) if x]
        detalle = f" — {', '.join(rf[:4])}" if rf else ""
        partes.append(f"Corpus RAG: dominio {dom} ({proc}), "
                      f"{n} fragmento(s){detalle}")
    elif dom == "no_disponible":
        partes.append("Sin corpus de dominio disponible en esta corrida")

    # 3. Cuánto del expediente se llegó a leer.
    cob = ev.get("cobertura_documental")
    if isinstance(cob, (int, float)):
        partes.append(f"Cobertura documental {cob:.0f} %")

    return " · ".join(partes)


def _add_result_line(doc: Document, puntaje: int, indent: float = 0.5):
    """Resultado de la actividad con score coloreado y etiqueta de estado."""
    label     = _puntaje_label(puntaje)
    status    = _status_resultado(puntaje)
    color_rgb = _hex_to_rgb(_puntaje_color_hex(puntaje))

    p_lbl = doc.add_paragraph()
    p_lbl.paragraph_format.left_indent = Cm(float(indent))
    p_lbl.paragraph_format.space_before = Pt(7)
    p_lbl.paragraph_format.space_after  = Pt(1)
    r = p_lbl.add_run("Resultado de la actividad:")
    r.font.size  = Pt(9)
    r.font.bold  = True
    r.font.color.rgb = AZUL_MID
    _WE.aplicar_fuente(r)

    p_val = doc.add_paragraph()
    p_val.paragraph_format.left_indent = Cm(float(indent))
    p_val.paragraph_format.space_before = Pt(1)
    p_val.paragraph_format.space_after  = Pt(3)

    # [AUDIT-FIX] puntaje=None ⇒ "—/5", no el literal "None/5".
    _pj = "—" if puntaje is None else puntaje
    r_score = p_val.add_run(f"{_pj}/5 — {label}")
    r_score.font.size  = Pt(9)
    r_score.font.bold  = True
    r_score.font.color.rgb = color_rgb
    _WE.aplicar_fuente(r_score)

    r_sep = p_val.add_run(f"  |  {status}")
    r_sep.font.size   = Pt(9)
    r_sep.font.italic = True
    r_sep.font.color.rgb = AZUL_DARK
    _WE.aplicar_fuente(r_sep)

# ─── Tabla resumen de scores ──────────────────────────────────────────────────
 
def _tabla_scores(doc: Document, scores_por_ambito: Dict[str, float], score_global: float):
    tabla = doc.add_table(rows=1, cols=4)
    tabla.style = "Table Grid"
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
 
    col_w = [Cm(7.5), Cm(2.2), Cm(2.2), Cm(5.1)]
    for i, (h, w) in enumerate(zip(["ÁMBITO", "PESO", "SCORE", "DICTAMEN"], col_w)):
        c = tabla.rows[0].cells[i]
        c.width = w
        _cell_text(c, h, bold=True, color=BLANCO, size=9, align="center")
        _set_cell_bg(c, "1F3864")
        _set_cell_borders(c, "1F3864")
 
    for ambito, score in scores_por_ambito.items():
        peso  = AMBITO_PESOS.get(ambito, 0)
        color = _score_color_hex(score)
        row   = tabla.add_row().cells
        score_txt = f"{score:.2f}" if score is not None else "—"
        for i, (c, v) in enumerate(zip(row, [ambito, f"{peso*100:.0f}%", score_txt, _label_semaforo(score)])):
            c.width = col_w[i]
            _set_cell_borders(c, "CCCCCC")
            if i in (2, 3):
                _cell_text(c, v, bold=True, color=BLANCO, size=9, align="center")
                _set_cell_bg(c, color)
            else:
                _cell_text(c, v, size=9, align="left" if i == 0 else "center")
 
    rg = tabla.add_row().cells
    color_g = _score_color_hex(score_global)
    rg[0].merge(rg[1])
    rg[0].width = col_w[0]
    _cell_text(rg[0], "SCORE GLOBAL PONDERADO", bold=True, color=BLANCO, size=10, align="center")
    _set_cell_bg(rg[0], "1F3864")
    _set_cell_borders(rg[0], "1F3864")
    # [AUDIT-FIX] score_global es None si ningún ámbito tenía evidencia. El
    # informe debe decir "—", no un 0.00 que se lee como dictamen demoledor.
    _score_g_txt = f"{score_global:.2f}" if score_global is not None else "—"
    _cell_text(rg[2], _score_g_txt, bold=True, color=BLANCO, size=12, align="center")
    _set_cell_bg(rg[2], color_g)
    _set_cell_borders(rg[2], color_g)
    _cell_text(rg[3], _label_semaforo(score_global), bold=True, color=BLANCO, size=11, align="center")
    _set_cell_bg(rg[3], color_g)
    _set_cell_borders(rg[3], color_g)
    doc.add_paragraph()
 
 
# ─── Índice de controles por ámbito ──────────────────────────────────────────
 
def _indice_controles_ambito(doc: Document, evaluaciones: List[Dict]):
    """Lista numerada de todos los controles/estándares aplicables en el ámbito."""
    _add_para(doc, "Estándares y controles aplicables:", bold=True, color=AZUL_MID, size=10)
    for ev in evaluaciones:
        control   = ev.get("control", "")
        actividad = ev.get("actividad", "")
        texto = f"{control} — {actividad}" if control else actividad
        _add_numbered(doc, texto)
    doc.add_paragraph()
 
 
# ─── Ficha detallada de un control ───────────────────────────────────────────
 
def _ficha_control(doc: Document, ev: Dict, num: int):
    """
    Ficha de una actividad/control con:
      encabezado (nombre + puntaje) | descripción | evidencia | observación | recomendación | preguntas
    """
    actividad = ev.get("actividad", f"Actividad {num}")
    control   = ev.get("control", "")
    concepto  = ev.get("concepto", "")
    evidencia = ev.get("evidencia") or ev.get("evidencia_encontrada") or ""
    observ    = ev.get("observacion_tecnica") or ev.get("observacion") or ""
    recomend  = ev.get("recomendacion", "")
    preguntas = ev.get("preguntas_faltantes") or ev.get("preguntas_pendientes") or []
 
    puntaje   = _normalizar_score(_score_o_puntaje(ev))
    color_hex = _puntaje_color_hex(puntaje)
    label     = _puntaje_label(puntaje)
 
    # ── MANEJO DE ERRORES: detectar y reemplazar contenido erróneo ─────────
    if _es_error(evidencia):
        evidencia = ""
    if _es_error(observ):
        observ = ""
    if _es_error(concepto):
        concepto = ""
    
    # Si no hay recomendación o es un error, generar una automáticamente
    if not recomend or _es_error(recomend):
        recomend = _generar_recomendacion_automatica(actividad, puntaje, concepto, observ)
    
    # ── Encabezado: nombre a la izquierda | puntaje a la derecha ───────────
    t_enc = doc.add_table(rows=1, cols=2)
    t_enc.style = "Table Grid"
    t_enc.alignment = WD_TABLE_ALIGNMENT.LEFT
 
    c_nom = t_enc.rows[0].cells[0]
    c_nom.width = Cm(14)
    titulo = f"{num}. {actividad}"
    if control:
        titulo = f"{num}. [{control}]  {actividad}"
    _cell_text(c_nom, titulo, bold=True, color=BLANCO, size=9)
    _set_cell_bg(c_nom, "2E75B6")
    _set_cell_borders(c_nom, "2E75B6")
 
    c_punt = t_enc.rows[0].cells[1]
    c_punt.width = Cm(3)
    _pj = "—" if puntaje is None else puntaje
    _cell_text(c_punt, f"{_pj}/5  |  {label}", bold=True, color=BLANCO, size=8, align="center")
    _set_cell_bg(c_punt, color_hex)
    _set_cell_borders(c_punt, color_hex)
 
    # ── [v27.3] Bloques argumentales nuevos ────────────────────────────────
    # Las inconsistencias entre fuentes son el hallazgo de más valor de una
    # validación: lo que un revisor humano tarda semanas en encontrar. Se
    # renderizan con AMBAS citas enfrentadas, porque una contradicción con un
    # solo lado no es verificable por quien firma el informe.
    incons = ev.get("inconsistencias") or []
    if isinstance(incons, list) and incons:
        lineas = []
        _orden = {"alta": 0, "media": 1, "baja": 2}
        for i, inc in enumerate(sorted(
                (x for x in incons if isinstance(x, dict)),
                key=lambda x: _orden.get(str(x.get("severidad", "media")).lower(), 1)), 1):
            sev = str(inc.get("severidad", "media")).upper()
            lineas.append(
                f"[{sev}] {inc.get('contradiccion', '')}\n"
                f"    · {inc.get('fuente_a', '?')} → \"{inc.get('cita_a', '')}\"\n"
                f"    · {inc.get('fuente_b', '?')} → \"{inc.get('cita_b', '')}\""
            )
        texto_incons = "\n\n".join(lineas)
    else:
        texto_incons = ""

    cuestionamiento = ev.get("cuestionamiento_metodologico") or ""
    if _es_error(cuestionamiento):
        cuestionamiento = ""

    # Citas que no se localizaron literalmente en el contexto. Va al informe a
    # propósito: quien firma debe saber qué revisar antes de hacerlo suyo.
    dudosas = ev.get("citas_no_verificadas") or []
    texto_dudosas = ""
    if isinstance(dudosas, list) and dudosas:
        texto_dudosas = (
            "⚠ Las siguientes citas no se localizaron literalmente en la "
            "evidencia leída. Verificar contra el documento original antes de "
            "dar por buena la conclusión:\n"
            + "\n".join(f"    · «{d}»" for d in dudosas)
        )

    # ── Cuerpo: filas etiqueta | contenido ─────────────────────────────────
    filas = [
        ("Descripción del control", concepto),
        ("Evidencia encontrada",    evidencia),
        ("Observación / Hallazgo",  observ),
        ("Inconsistencias detectadas", texto_incons),
        ("Cuestionamiento metodológico", cuestionamiento),
        ("Recomendación",           recomend),  # Siempre incluir recomendación (ya generada si falta)
        ("Verificación de citas",   texto_dudosas),
    ]
    filas = [(e, c) for e, c in filas if c or e == "Recomendación"]  # Mostrar recomendación siempre
 
    if filas:
        t_body = doc.add_table(rows=len(filas), cols=2)
        t_body.style = "Table Grid"
        t_body.alignment = WD_TABLE_ALIGNMENT.LEFT
 
        for r_i, (etiq, contenido) in enumerate(filas):
            row = t_body.rows[r_i].cells
            row[0].width = Cm(4)
            row[1].width = Cm(13)
            _cell_text(row[0], etiq, bold=True, color=AZUL_DARK, size=8)
            _set_cell_bg(row[0], "EBF3FB")
            _set_cell_borders(row[0], "CCCCCC")
            _cell_text(row[1], contenido, size=8)
            _set_cell_borders(row[1], "CCCCCC")
 
    # ── Preguntas pendientes ────────────────────────────────────────────────
    if preguntas:
        p_hdr = doc.add_paragraph()
        p_hdr.paragraph_format.space_before = Pt(4)
        p_hdr.paragraph_format.space_after  = Pt(2)
        r_hdr = p_hdr.add_run("⚠  Preguntas / Requerimientos pendientes:")
        r_hdr.bold = True
        r_hdr.font.size = Pt(8)
        _WE.aplicar_fuente(r_hdr)
        r_hdr.font.color.rgb = NARANJA
        for preg in preguntas:
            _add_bullet(doc, preg, size=8)
 
    # separador entre fichas
    doc.add_paragraph()
 
 
# ─── Sección completa por ámbito ─────────────────────────────────────────────
 
def _seccion_ambito(doc: Document, ambito: str, evaluaciones: List[Dict],
                    score: float, num_sec: int):
    """
    Sección de un ámbito:
      A) Cabecera con score
      B) Índice de estándares aplicables (lista numerada)
      C) Detalle control por control (fichas)
    """
    color_hex = _score_color_hex(score)
 
    # Cabecera del ámbito
    _add_heading(doc, f"{num_sec}. {ambito}", level=2)
 
    # Score del ámbito en tabla de 2 celdas
    t_score = doc.add_table(rows=1, cols=2)
    t_score.style = "Table Grid"
    c_lbl, c_val = t_score.rows[0].cells
    c_lbl.width = Cm(9)
    c_val.width = Cm(8)
    _cell_text(c_lbl, f"Score del ámbito: {score:.2f} / 5.0", bold=True, size=10)
    _set_cell_borders(c_lbl, "CCCCCC")
    _cell_text(c_val, _label_semaforo(score), bold=True, color=BLANCO, size=10, align="center")
    _set_cell_bg(c_val, color_hex)
    _set_cell_borders(c_val, color_hex)
    doc.add_paragraph()
 
    # A) Índice de controles
    _indice_controles_ambito(doc, evaluaciones)
 
    _hr(doc, "2E75B6")
    _add_para(doc, "Resultados por control:", bold=True, color=AZUL_DARK, size=10)
    doc.add_paragraph()
 
    # B) Fichas detalladas
    for i, ev in enumerate(evaluaciones, start=1):
        _ficha_control(doc, ev, num=i)
 
 
# ─── FUNCIONES PARA PROCESAR FORMATO JSON ────────────────────────────────────
 
def _portada_desde_json(doc: Document, portada_data: Dict):
    """Genera la portada basada en los datos JSON."""
    doc.add_paragraph()
    doc.add_paragraph()
 
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(portada_data.get("titulo_informe", "INFORME DE RESULTADOS"))
    r.font.size = Pt(24)
    r.font.bold = True
    r.font.color.rgb = AZUL_DARK
    _WE.aplicar_fuente(r)
 
    doc.add_paragraph()
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tipo_val = portada_data.get("tipo_validacion", "VALIDACIÓN METODOLÓGICA")
    desc_modelo = portada_data.get("descripcion_modelo", "")
    r2 = p2.add_run(f"{tipo_val}\n{desc_modelo}")
    r2.font.size = Pt(14)
    r2.font.color.rgb = AZUL_MID
    _WE.aplicar_fuente(r2)
 
    doc.add_paragraph()
    doc.add_paragraph()
 
    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ger_prin = portada_data.get("gerencia_principal", "")
    ger_sec = portada_data.get("gerencia_secundaria", "")
    entidad = portada_data.get("entidad", "")
    fecha = portada_data.get("fecha", "")
    r3 = p3.add_run(f"{ger_prin}\n{ger_sec}\n\n{entidad}\n\n{fecha}")
    r3.font.size = Pt(11)
    r3.font.color.rgb = GRIS_TEXT
    _WE.aplicar_fuente(r3)
 
    doc.add_page_break()
 
 
def _metadata_desde_json(doc: Document, metadata: Dict):
    """Inserta metadata en el documento."""
    t = doc.add_table(rows=1, cols=2)
    t.style = "Table Grid"
    
    header = t.rows[0].cells
    _cell_text(header[0], "CAMPO", bold=True, color=BLANCO, size=9)
    _set_cell_bg(header[0], "1F3864")
    _cell_text(header[1], "VALOR", bold=True, color=BLANCO, size=9)
    _set_cell_bg(header[1], "1F3864")
 
    for key, value in metadata.items():
        row = t.add_row().cells
        _cell_text(row[0], key.replace("_", " ").title(), bold=True, size=9)
        _set_cell_borders(row[0], "CCCCCC")
        _cell_text(row[1], str(value), size=9)
        _set_cell_borders(row[1], "CCCCCC")
 
    doc.add_paragraph()
 
 
def _resumen_ejecutivo_desde_json(doc: Document, resumen_data: Dict):
    """Inserta el resumen ejecutivo."""
    _add_para(doc, resumen_data.get("texto", ""), size=10, italic=False)
    doc.add_paragraph()
 
 
def _objetivos_desde_json(doc: Document, objetivos_data: Dict):
    """Inserta los objetivos."""
    _add_para(doc, "Objetivo General:", bold=True, color=AZUL_MID, size=10)
    _add_para(doc, objetivos_data.get("objetivo_general", ""), size=9)
    doc.add_paragraph()
 
    _add_para(doc, "Objetivos Específicos:", bold=True, color=AZUL_MID, size=10)
    for obj in objetivos_data.get("objetivos_especificos", []):
        _add_bullet(doc, obj, size=9)
    doc.add_paragraph()
 
 
def _alcance_desde_json(doc: Document, alcance_data: Dict):
    """Inserta el alcance con dimensiones y controles."""
    for dim_info in alcance_data.get("dimensiones", []):
        dimension = dim_info.get("dimension", "")
        controles = dim_info.get("controles", [])
        
        _add_para(doc, dimension, bold=True, color=AZUL_MID, size=10)
        for control in controles:
            _add_bullet(doc, control, size=9)
        doc.add_paragraph()
 
 
def _informacion_relevante_desde_json(doc: Document, info_data: Dict):
    """Inserta información relevante."""
    modelos = info_data.get("modelos", [])
    if modelos:
        _add_para(doc, "Modelos evaluados:", bold=True, color=AZUL_MID, size=10)
        for modelo in modelos:
            txt = f"{modelo.get('nombre_modelo')} (ID: {modelo.get('id_modelo')}) - Tier {modelo.get('tier')} - Estado: {modelo.get('estado')}"
            _add_bullet(doc, txt, size=9)
        doc.add_paragraph()
 
    fechas = info_data.get("fechas_trabajo", {})
    if fechas:
        _add_para(doc, "Fechas de trabajo:", bold=True, color=AZUL_MID, size=10)
        inicio = fechas.get("inicio", "")
        fin = fechas.get("fin", "")
        _add_para(doc, f"Inicio: {inicio} | Fin: {fin}", size=9)
        doc.add_paragraph()
 
    limitaciones = info_data.get("limitaciones", "")
    if limitaciones:
        _add_para(doc, "Limitaciones:", bold=True, color=NARANJA, size=10)
        _add_para(doc, limitaciones, size=9, italic=True)
        doc.add_paragraph()
 
 
def _conclusion_desde_json(doc: Document, conclusion_data: Dict):
    """Inserta la conclusión."""
    texto_base = conclusion_data.get("texto_base", "")
    calificacion = conclusion_data.get("calificacion_final", "")
    comentarios = conclusion_data.get("comentarios", "")
 
    p = doc.add_paragraph()
    r = p.add_run(f"{texto_base} ")
    r.font.size = Pt(10)
    _WE.aplicar_fuente(r)
    r_cal = p.add_run(calificacion)
    r_cal.font.size = Pt(10)
    r_cal.font.bold = True
    r_cal.font.color.rgb = AZUL_DARK
    _WE.aplicar_fuente(r_cal)
    r_fin = p.add_run(".")
    r_fin.font.size = Pt(10)
 
    if comentarios:
        doc.add_paragraph()
        _add_para(doc, comentarios, size=9, italic=True, color=GRIS_TEXT)
 
    doc.add_paragraph()
 
 
def _hallazgos_desde_json(doc: Document, hallazgos_data: Dict):
    """Inserta hallazgos y recomendaciones."""
    # Fortalezas
    fortalezas = hallazgos_data.get("fortalezas", [])
    if fortalezas:
        _add_para(doc, "Fortalezas identificadas:", bold=True, color=_hex_to_rgb("00B050"), size=10)
        for f in fortalezas:
            _add_bullet(doc, f, size=9)
        doc.add_paragraph()
 
    # Controles exitosos
    exitosos = hallazgos_data.get("controles_exitosos", [])
    if exitosos:
        _add_para(doc, "Controles exitosos:", bold=True, color=_hex_to_rgb("00B050"), size=10)
        for c in exitosos:
            _add_bullet(doc, c, size=9)
        doc.add_paragraph()
 
    # Observaciones
    observaciones = hallazgos_data.get("observaciones", [])
    if observaciones:
        _add_para(doc, "Observaciones identificadas:", bold=True, color=NARANJA, size=10)
        for obs in observaciones:
            cod = obs.get("codigo", "")
            cat = obs.get("categoria", "")
            desc = obs.get("descripcion", "")
            imp = obs.get("impacto", "")
            rec = obs.get("recomendacion", "")
            
            txt = f"[{cod}] {cat} ({imp}): {desc}"
            _add_bullet(doc, txt, size=9)
            if rec:
                _add_para(doc, f"  → {rec}", size=8, italic=True, color=GRIS_TEXT)
        doc.add_paragraph()
 
    # Oportunidades de mejora
    mejoras = hallazgos_data.get("oportunidades_mejora", [])
    if mejoras:
        _add_para(doc, "Oportunidades de mejora:", bold=True, color=AZUL_MID, size=10)
        for mejora in mejoras:
            cod = mejora.get("codigo", "")
            desc = mejora.get("descripcion", "")
            txt = f"[{cod}] {desc}" if cod else desc
            _add_bullet(doc, txt, size=9)
        doc.add_paragraph()
 
 
def _tabla_contenido_desde_json(doc: Document, tabla_data: Dict):
    """Inserta la tabla de contenido."""
    estructura = tabla_data.get("estructura", [])
    _add_para(doc, "Estructura del Informe:", bold=True, color=AZUL_MID, size=10)
    for item in estructura:
        _add_numbered(doc, item, size=9)
    doc.add_paragraph()
 
 
def _informe_detallado_desde_json(doc: Document, informe_data: Dict):
    """Inserta el informe detallado con controles."""
    # Descripción del documento
    desc = informe_data.get("descripcion_documento", {})
    if desc:
        _add_para(doc, "Descripción del Documento:", bold=True, color=AZUL_MID, size=10)
        titulo = desc.get("titulo", "")
        responsables = desc.get("responsables", [])
        revisor = desc.get("revisor", "")
        fecha_aprobacion = desc.get("fecha_aprobacion", "")
        
        if titulo:
            _add_para(doc, f"Título: {titulo}", size=9)
        if responsables:
            _add_para(doc, f"Responsables: {', '.join(responsables)}", size=9)
        if revisor:
            _add_para(doc, f"Revisor: {revisor}", size=9)
        if fecha_aprobacion:
            _add_para(doc, f"Fecha de Aprobación: {fecha_aprobacion}", size=9)
        doc.add_paragraph()
 
    # Glosario
    glosario = informe_data.get("glosario", [])
    if glosario:
        _add_para(doc, "Glosario de Términos:", bold=True, color=AZUL_MID, size=10)
        for term_info in glosario:
            termino = term_info.get("termino", "")
            sigla = term_info.get("sigla", "")
            definicion = term_info.get("definicion", "")
            
            if sigla:
                _add_para(doc, f"{termino} ({sigla}): {definicion}", size=9)
            else:
                _add_para(doc, f"{termino}: {definicion}", size=9)
        doc.add_paragraph()
 
    # Controles
    controles = informe_data.get("controles", [])
    if controles:
        _add_para(doc, "Matriz de Controles:", bold=True, color=AZUL_MID, size=10)
        
        t_controles = doc.add_table(rows=1, cols=6)
        t_controles.style = "Table Grid"
        
        headers = ["Dimensión", "Código", "Nombre Control", "Objetivo", "Resultado", "Observación"]
        for i, h in enumerate(headers):
            c = t_controles.rows[0].cells[i]
            _cell_text(c, h, bold=True, color=BLANCO, size=8, align="center")
            _set_cell_bg(c, "1F3864")
            _set_cell_borders(c, "1F3864")
 
        for ctrl in controles:
            row = t_controles.add_row().cells
            row[0].width = Cm(2.0)
            row[1].width = Cm(1.5)
            row[2].width = Cm(2.5)
            row[3].width = Cm(3.0)
            row[4].width = Cm(2.0)
            row[5].width = Cm(3.5)
            
            dimension = ctrl.get("dimension", "")
            codigo = ctrl.get("codigo", "")
            nombre = ctrl.get("nombre_control", "")
            objetivo = ctrl.get("objetivo", "")
            resultado = ctrl.get("resultado", "")
            observacion = ctrl.get("observacion", "") or ctrl.get("detalle_resultado", "")
 
            _cell_text(row[0], dimension, size=8)
            _set_cell_borders(row[0], "CCCCCC")
            _cell_text(row[1], codigo, size=8)
            _set_cell_borders(row[1], "CCCCCC")
            _cell_text(row[2], nombre, size=8)
            _set_cell_borders(row[2], "CCCCCC")
            _cell_text(row[3], objetivo, size=8)
            _set_cell_borders(row[3], "CCCCCC")
            _cell_text(row[4], resultado, size=8, bold=True, color=AZUL_MID)
            _set_cell_borders(row[4], "CCCCCC")
            _cell_text(row[5], observacion, size=8)
            _set_cell_borders(row[5], "CCCCCC")
        
        doc.add_paragraph()
    
    # Estándares aplicables
    estandares = informe_data.get("estandares_aplicables", [])
    if estandares:
        _add_para(doc, "Estándares Aplicables:", bold=True, color=AZUL_MID, size=10)
        for est in estandares:
            _add_bullet(doc, est, size=9)
        doc.add_paragraph()


# ─── FUNCIÓN PRINCIPAL ────────────────────────────────────────────────────────
 
# ═════════════════════════════════════════════════════════════════════════════
# SECCIONES DE CUMPLIMIENTO REGULATORIO
# ═════════════════════════════════════════════════════════════════════════════
# Tres bloques que un auditor externo (SBS / Big4) va a pedir explícitamente:
#   · hoja de firma con responsable humano identificable  (SR 11-7 §V)
#   · metadatos de cadena de custodia                     (trazabilidad inmutable)
#   · anexo de correcciones del validador                 (juicio humano prevalece)
# ═════════════════════════════════════════════════════════════════════════════

def _hoja_firma(doc: Document, validacion: Optional[Dict], custodia: Optional[Dict],
                titulo_modelo: str, tier: str, con_titulo: bool = True) -> None:
    """
    Hoja de aprobación formal: quién firma, con qué cargo y cuándo.

    Un informe sin responsable humano identificable no acredita validación
    independiente — acredita que se ejecutó un programa. Por eso, si el bloque
    llega vacío, NO se omite la sección en silencio: se deja constancia visible
    de que falta la firma. Omitirla haría que el informe pareciera completo.
    """
    if con_titulo:
        _add_heading(doc, "APROBACIÓN Y RESPONSABILIDAD", level=1)

    if not validacion or not validacion.get("validador"):
        _add_para(doc,
                  "⚠️ INFORME SIN FIRMA DE VALIDADOR. Este documento no acredita "
                  "validación independiente conforme a SR 11-7 §V mientras no lo "
                  "suscriba un responsable humano identificable.",
                  bold=True, color=_hex_to_rgb("FF0000"), size=10)
        return

    filas = [
        ("Modelo validado", titulo_modelo),
        ("Tier", f"Tier {tier}"),
        ("Validador responsable", validacion.get("validador", "")),
        ("Cargo / rol", validacion.get("cargo", "")),
        ("Fecha de aprobación (UTC)", validacion.get("fecha_aprobacion", "")),
    ]
    # [PENDIENTE-3] La segunda firma viaja al Word, no solo al JSON: el auditor
    # recibe el Word, y una aprobación de dos ojos que solo consta en un fichero
    # que no se le entrega no acredita nada.
    _segunda = (validacion or {}).get("segunda_firma") or {}
    if _segunda.get("validador"):
        filas += [
            ("Segundo validador (dos ojos)", _segunda.get("validador", "")),
            ("Cargo / rol del segundo validador", _segunda.get("cargo", "")),
            ("Fecha de la segunda aprobación (UTC)",
             _segunda.get("fecha_aprobacion", "")),
        ]
    if custodia:
        filas.append(("Huella del informe (SHA-256)",
                      (custodia.get("hash_este_informe") or "")[:32] + "…"))
        filas.append(("Posición en la cadena de custodia",
                      str(custodia.get("posicion_en_cadena", "—"))))

    t = doc.add_table(rows=0, cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for etiqueta, valor in filas:
        row = t.add_row().cells
        _cell_text(row[0], etiqueta, bold=True, size=9)
        _set_cell_bg(row[0], "F2F2F2")
        _set_cell_borders(row[0], "CCCCCC")
        _cell_text(row[1], str(valor), size=9)
        _set_cell_borders(row[1], "CCCCCC")

    doc.add_paragraph()
    _add_para(doc,
              "El validador identificado asume la responsabilidad del contenido de "
              "este informe. El agente VIRF actúa como herramienta de apoyo: sus "
              "resultados constituyen una propuesta sujeta a revisión humana, no un "
              "dictamen automático.",
              italic=True, size=9)

    aviso = (validacion or {}).get("aviso_segregacion")
    if aviso:
        doc.add_paragraph()
        _add_para(doc, aviso, bold=True, color=NARANJA, size=9)

    doc.add_paragraph()
    if _segunda.get("validador"):
        # Dos líneas de firma, una por persona: una sola línea con dos nombres
        # encima permitiría que la firmara uno solo.
        _add_para(doc, f"Firma ({validacion.get('validador','')}): "
                       "______________________________________", size=10)
        _add_para(doc, f"Firma ({_segunda.get('validador','')}): "
                       "______________________________________", size=10)
        _add_para(doc,
                  f"Este informe corresponde a un modelo Tier {tier}, sujeto a "
                  "aprobación de dos validadores distintos conforme a la "
                  "política de segregación de funciones de la entidad "
                  "(SR 11-7 §V).", italic=True, size=9)
    else:
        _add_para(doc, "Firma: ______________________________________", size=10)
    doc.add_page_break()


def _metadatos_custodia(doc: Document, custodia: Optional[Dict],
                        agente: Optional[Dict], con_titulo: bool = True) -> None:
    """
    Metadatos de trazabilidad: permiten verificar el informe a posteriori.

    Se imprimen en el documento entregable —no solo en el JSON— porque el
    auditor recibe el Word: si los hashes solo viven en el JSON, no puede
    contrastar el documento que tiene en las manos.
    """
    if con_titulo:
        _add_heading(doc, "TRAZABILIDAD Y CADENA DE CUSTODIA", level=1)
    _add_para(doc,
              "Los siguientes identificadores permiten verificar que este informe "
              "no ha sido alterado tras su emisión y sobre qué versión exacta de la "
              "evidencia se emitió.", size=9)
    doc.add_paragraph()

    cust = custodia or {}
    ag = agente or {}
    filas = [
        ("Generado (UTC)", cust.get("generado_utc") or ag.get("generado_utc", "—")),
        ("Hash de este informe", (cust.get("hash_este_informe") or "—")),
        ("Hash del informe anterior", (cust.get("hash_informe_anterior") or "— (primero de la cadena)")),
        ("Sello de cadena", (cust.get("hash_cadena") or "—")),
        ("Posición en la cadena", str(cust.get("posicion_en_cadena", "—"))),
        ("Huella de ejecución", ag.get("huella_completa") or ag.get("huella_ejecucion", "—")),
        ("Versión del agente", ag.get("agente_version", "—")),
        ("Modelo de IA", ag.get("modelo_ia", "—")),
        ("Documentos de evidencia", str(ag.get("n_documentos", "—"))),
        # [AUDIT-FIX] Corpus de referencia consultado y CÓMO se eligió. Un
        # auditor que lea «dominio: LaR» tiene derecho a saber si lo declaró una
        # persona o lo dedujo una heurística del título del modelo.
        ("Corpus de referencia (RAG)",
         f"{ag.get('rag_dominio', '—')}"
         + {"explicito": "  ·  declarado por el validador",
            "inferido": "  ·  INFERIDO del título del modelo",
            "defecto": "  ·  por defecto (el título no identifica dominio)",
            }.get(ag.get("rag_procedencia"), "")),
    ]
    t = doc.add_table(rows=0, cols=2)
    for etiqueta, valor in filas:
        row = t.add_row().cells
        _cell_text(row[0], etiqueta, bold=True, size=8)
        _set_cell_bg(row[0], "F2F2F2")
        _set_cell_borders(row[0], "CCCCCC")
        _cell_text(row[1], str(valor), size=8)
        _set_cell_borders(row[1], "CCCCCC")

    # ── [AUDIT-FIX · PENDIENTE-4] Procedencia del corpus de referencia ───────
    # `inputs/rag/` contiene hoy documentos de apoyo GENERADOS a partir de
    # marcos públicos, no los textos oficiales. La entidad ha decidido operar
    # así por ahora, y esa decisión es defendible SOLO si el informe la declara:
    # lo inadmisible no es usar resúmenes, es que un lector no pueda saber que
    # lo son y tome un umbral de ahí como si fuera la norma.
    #
    # El aviso se emite únicamente cuando el RAG APORTÓ algo a esta corrida. Si
    # no se recuperó nada, advertir sobre un corpus que no se usó sería ruido —
    # y un aviso permanente se vuelve invisible, que es como se pierden los
    # avisos que sí importan.
    if (ag.get("rag_dominio") and ag.get("rag_dominio") != "no_disponible"):
        doc.add_paragraph()
        _add_para(doc, "Procedencia del corpus de referencia", bold=True,
                  color=AZUL_MID, size=10)
        _add_para(doc,
                  "Los fragmentos de literatura técnica y regulatoria empleados "
                  "como contexto de dominio proceden de DOCUMENTOS DE APOYO "
                  "elaborados a partir de marcos públicos, no de los textos "
                  "oficiales. Se utilizan para aportar criterio de dominio a la "
                  "evaluación, NO como fuente normativa.",
                  size=9)
        _add_para(doc,
                  "En consecuencia: ninguna exigencia regulatoria concreta —y en "
                  "particular ningún umbral numérico— debe darse por acreditada "
                  "sobre la base de este corpus sin contrastarla contra la fuente "
                  "primaria. Los puntajes reflejan el juicio del validador sobre "
                  "la evidencia del modelo, no una comprobación de conformidad "
                  "normativa literal.",
                  size=9, bold=True)

    versiones = cust.get("version_evidencia_usada") or {}
    if versiones:
        doc.add_paragraph()
        _add_para(doc, "Versión de la evidencia utilizada", bold=True,
                  color=AZUL_MID, size=10)
        _add_para(doc,
                  "Hash del fichero en el instante de la evaluación. Si el documento "
                  "cambia después, este informe sigue demostrando qué versión lo "
                  "sustentó.", italic=True, size=8)
        tv = doc.add_table(rows=1, cols=3)
        enc = tv.rows[0].cells
        for i, h in enumerate(("Documento", "SHA-256 (fichero)", "Chars")):
            _cell_text(enc[i], h, bold=True, color=BLANCO, size=8, align="center")
            _set_cell_bg(enc[i], "1F3864")
            _set_cell_borders(enc[i], "1F3864")
        for clave, meta in versiones.items():
            row = tv.add_row().cells
            _cell_text(row[0], clave, size=7)
            _cell_text(row[1], (meta.get("sha256_archivo") or "no registrado")[:24] + "…",
                       size=7)
            _cell_text(row[2], str(meta.get("chars", "—")), size=7, align="center")
            for c in row:
                _set_cell_borders(c, "CCCCCC")

    doc.add_paragraph()
    _add_para(doc,
              "Verificación:  python agente.py --verificar-cadena \"<modelo>\"   ·   "
              "python agente.py --verificar-evidencia <informe.json>",
              italic=True, size=8)
    doc.add_page_break()


def _anexo_correcciones(doc: Document, override: Optional[Dict],
                        con_titulo: bool = True) -> None:
    """
    Anexo: Correcciones del Validador — evidencia de que el juicio humano manda.

    La ausencia de correcciones se declara EXPLÍCITAMENTE. Un anexo vacío dejaría
    al auditor deduciendo del silencio si hubo revisión; decirlo convierte el
    hecho en evidencia: hubo revisión y su conclusión fue conforme.
    """
    if con_titulo:
        _add_heading(doc, "ANEXO: CORRECCIONES DEL VALIDADOR", level=1)

    if not override:
        _add_para(doc,
                  "No se dispone de registro de revisión humana para este modelo.",
                  italic=True, size=9)
        doc.add_page_break()
        return

    _add_para(doc,
              "Este anexo documenta los puntos en que el criterio del validador "
              "difirió del resultado propuesto por el agente. Es la evidencia de que "
              "el juicio humano prevalece sobre la sugerencia automática.", size=9)
    doc.add_paragraph()

    if not override.get("hubo_correcciones"):
        _add_para(doc,
                  "El validador no realizó ajustes — el resultado del agente fue "
                  "aceptado en su totalidad.",
                  bold=True, color=AZUL_MID, size=10)
        doc.add_paragraph()
        _add_para(doc,
                  "La ausencia de correcciones no implica ausencia de revisión: "
                  "refleja que el validador examinó la evaluación y la encontró "
                  "conforme.", italic=True, size=9)
        if override.get("n_correcciones_historicas"):
            _add_para(doc,
                      f"Correcciones acumuladas de este modelo en ciclos anteriores: "
                      f"{override['n_correcciones_historicas']}.", size=9)
        doc.add_page_break()
        return

    _add_para(doc,
              f"Correcciones en el último ciclo de revisión"
              + (f" ({override['sesion']})" if override.get("sesion") else "")
              + f": {override['n_correcciones']} de {override['total_actividades']} "
              f"actividades evaluadas ({override['pct_ajustados']} %).",
              bold=True, size=10)
    doc.add_paragraph()

    # [PENDIENTE-2] Séptima columna: quién firma cada corrección. Antes el anexo
    # decía «el validador ajustó 2 puntajes» sin acreditar CUÁL de los 2-5
    # validadores del equipo, y este anexo es precisamente la evidencia de
    # supervisión humana que el auditor viene a ver. Sin autor acredita que
    # alguien tocó el fichero, no que un responsable identificable decidió.
    t = doc.add_table(rows=1, cols=7)
    enc = t.rows[0].cells
    cabeceras = ("Ámbito", "Actividad", "Agente", "Validador", "Dif.",
                 "Justificación del validador", "Corregido por")
    for i, h in enumerate(cabeceras):
        _cell_text(enc[i], h, bold=True, color=BLANCO, size=8, align="center")
        _set_cell_bg(enc[i], "1F3864")
        _set_cell_borders(enc[i], "1F3864")

    for c in override["correcciones"]:
        row = t.add_row().cells
        dif = c.get("diferencia") or 0
        signo = "+" if dif > 0 else ""
        _cell_text(row[0], str(c.get("ambito", ""))[:28], size=8)
        _cell_text(row[1], str(c.get("actividad", ""))[:90], size=8)
        _cell_text(row[2], str(c.get("puntaje_agente", "—")), size=8, align="center")
        _cell_text(row[3], str(c.get("puntaje_validador", "—")), bold=True, size=8,
                   align="center")
        _cell_text(row[4], f"{signo}{dif}", bold=True, size=8, align="center")
        _cell_text(row[5], str(c.get("justificacion", ""))[:400], size=8)
        # `or` y no `.get("autor", "…")`: §3.4 — el segundo argumento de .get
        # no actúa si la clave existe con valor nulo.
        _cell_text(row[6], str(c.get("autor") or "(no registrado)")[:40], size=8)
        for celda in row:
            _set_cell_borders(celda, "CCCCCC")
        # El sentido del ajuste se colorea: al alza en verde, a la baja en rojo.
        _set_cell_bg(row[4], "00B050" if dif > 0 else "FF0000" if dif < 0 else "CCCCCC")
        _cell_text(row[4], f"{signo}{dif}", bold=True, color=BLANCO, size=8,
                   align="center")

    doc.add_paragraph()
    _add_para(doc,
              f"Ajustes al alza: {override['ajustes_al_alza']}   ·   "
              f"Ajustes a la baja: {override['ajustes_a_la_baja']}   ·   "
              f"Acumulado histórico del modelo: "
              f"{override['n_correcciones_historicas']} correcciones.", size=9)

    # Firmantes del ciclo. Dos o más es evidencia POSITIVA de revisión cruzada,
    # y merece decirse: el anexo suele leerse buscando lo que falta.
    _autores = [a for a in (override.get("autores") or [])]
    if _autores:
        _conocidos = [a for a in _autores if a != "(no registrado)"]
        if _conocidos:
            _add_para(doc, "Correcciones firmadas por: " + ", ".join(_conocidos)
                      + ".", size=9)
        if len(_autores) != len(_conocidos):
            # Se declara el límite en vez de dejar el hueco sin explicar (§7).
            _add_para(doc,
                      "Parte de las correcciones de este ciclo son anteriores "
                      "al registro de autoría y constan sin firmante "
                      "identificado.", size=8, italic=True)
    doc.add_page_break()


def generar_word_informe_desde_json(
    formato_data: Dict,
    outputs_dir: Path,
    titulo_modelo: str = None,
) -> Path:
    """
    Genera el informe Word completo basado en el formato JSON estructura.
    
    Args:
        formato_data: Diccionario con la estructura JSON completa
        outputs_dir: Directorio donde guardar el archivo
        titulo_modelo: Título del modelo (opcional, se toma del JSON si no se especifica)
    
    Returns:
        Path: Ruta del archivo generado
    """
 
    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")
    
    if titulo_modelo is None:
        portada = formato_data.get("2_portada", {})
        titulo_modelo = portada.get("descripcion_modelo", "Informe")
    
    nombre = f"VIRF_Informe_{titulo_modelo.replace(' ', '_')}_{fecha_str}.docx"
    ruta = outputs_dir / nombre
 
    doc = Document()
    # Tipografía corporativa, justificación y respaldo declarado.
    _WE.aplicar_estilo_documento(doc)
 
    for section in doc.sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin = Cm(3.0)
        section.right_margin = Cm(2.5)
 
    # 1. PORTADA
    portada_data = formato_data.get("2_portada", {})
    _portada_desde_json(doc, portada_data)
 
    # 2. RESUMEN EJECUTIVO
    _add_heading(doc, "Resumen Ejecutivo", level=1)
    resumen_data = formato_data.get("3_resumen_ejecutivo", {})
    _resumen_ejecutivo_desde_json(doc, resumen_data)
    doc.add_page_break()
 
    # 3. OBJETIVOS
    _add_heading(doc, "Objetivos", level=1)
    objetivos_data = formato_data.get("4_objetivos", {})
    _objetivos_desde_json(doc, objetivos_data)
    doc.add_page_break()
 
    # 4. ALCANCE
    _add_heading(doc, "Alcance", level=1)
    alcance_data = formato_data.get("5_alcance", {})
    _alcance_desde_json(doc, alcance_data)
    doc.add_page_break()
 
    # 5. INFORMACIÓN RELEVANTE
    _add_heading(doc, "Información Relevante", level=1)
    info_data = formato_data.get("6_informacion_relevante", {})
    _informacion_relevante_desde_json(doc, info_data)
    doc.add_page_break()
 
    # 6. CONCLUSIÓN
    _add_heading(doc, "Conclusión", level=1)
    conclusion_data = formato_data.get("7_conclusion", {})
    _conclusion_desde_json(doc, conclusion_data)
    doc.add_page_break()
 
    # 7. HALLAZGOS Y RECOMENDACIONES
    _add_heading(doc, "Hallazgos y Recomendaciones", level=1)
    hallazgos_data = formato_data.get("8_hallazgos_y_recomendaciones", {})
    _hallazgos_desde_json(doc, hallazgos_data)
    doc.add_page_break()
 
    # 8. TABLA DE CONTENIDO
    _add_heading(doc, "Tabla de Contenido", level=1)
    tabla_data = formato_data.get("9_tabla_contenido", {})
    _tabla_contenido_desde_json(doc, tabla_data)
    doc.add_page_break()
 
    # 9. INFORME DETALLADO
    _add_heading(doc, "Informe Detallado", level=1)
    informe_data = formato_data.get("10_informe_detallado", {})
    _informe_detallado_desde_json(doc, informe_data)
 
    # ── Guardar ──────────────────────────────────
    outputs_dir.mkdir(parents=True, exist_ok=True)
    from modulos.clasificacion_docx import aplicar as _clasificar  # [SEG-10]
    _clasificar(doc)
    doc.save(ruta)
    print(f"  ✓ Word generado: {ruta}")
    return ruta


# ─── FUNCIÓN COMPATIBILIDAD ANTERIOR ──────────────────────────────────────────
 
def generar_word_informe(
    resumen_ejecutivo: str,
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito: Dict[str, float],
    score_global: float,
    titulo_modelo: str,
    tier: str,
    outputs_dir: Path,
    validacion_humana: Optional[Dict] = None,
    custodia: Optional[Dict] = None,
    agente_meta: Optional[Dict] = None,
    override: Optional[Dict] = None,
    skills: Optional[List[Dict]] = None,
    politicas_procedimiento: Optional[Dict] = None,
    tipo_validacion: str = "periodica",
    fecha_inicio: Optional[str] = None,
    fecha_entrega: Optional[str] = None,
    revisado_por: str = "",
) -> Path:
    """
    Genera el entregable Word con la plantilla común «Informe de Resultados»
    (`modulos.plantilla_bcp`), la misma de Solo Informe y de la web:

      Portada BCP · Índice · I. Objetivos · II. Alcance · III. Cumplimiento de
      Estándar · IV. Información Relevante · V. Cuadro Resumen · VI. Glosario ·
      VII. Barrido de Controles · Anexos.

    La calificación sale de `modulos.reglas_informe` traduciendo el puntaje del
    agente a riesgo (0–2 Crítico, 3 Moderado, 4 Oportunidad de Mejora). Lo que
    este informe sabe de más —puntaje, evidencia, hallazgos de código y de
    calidad de datos, preguntas pendientes, procedencia de las citas— va en el
    barrido, por actividad. Los bloques de cumplimiento regulatorio van como
    anexos y siguen siendo obligatorios cuando aplica:

      A. Aprobación y responsabilidad   (si falta la firma, se DECLARA)
      B. Trazabilidad y cadena de custodia
      C. Escala de evaluación del agente
      D. Correcciones del validador     (su ausencia también se declara)
      E. Análisis transversales         (solo si se ejecutaron skills)

    Los parámetros de cumplimiento son OPCIONALES por compatibilidad con los
    llamantes existentes; `tipo_validacion` y las fechas, también (por defecto,
    validación periódica entregada hoy).
    """
    from modulos import plantilla_bcp as PB
    from modulos import reglas_informe as reglas

    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")
    nombre = f"VIRF_Informe_{titulo_modelo.replace(' ', '_')}_{fecha_str}.docx"
    ruta = outputs_dir / nombre

    ambitos: List[str] = []
    controles: List[Dict] = []
    observaciones: List[Dict] = []
    for ambito, evals in evaluaciones_por_ambito.items():
        ambitos.append(ambito)
        for ev in evals:
            n = len(controles) + 1
            cid = f"A{n:03d}"
            actividad = ev.get("actividad") or f"Actividad {n}"
            puntaje_act = _normalizar_score(_score_o_puntaje(ev))
            sin_ev = bool(ev.get("sin_evidencia"))
            if sin_ev and puntaje_act is None:
                # Política de la entidad: la falta de evidencia es una FALTA
                # CRÍTICA imputable al validado (0), no un fallo técnico nuestro.
                puntaje_act = 0
            concepto = ev.get("concepto", "")
            observacion = ev.get("observacion_tecnica") or ev.get("observacion") or ""
            recomendacion = ev.get("recomendacion", "")
            if _es_error(concepto):
                concepto = ""
            if _es_error(observacion):
                observacion = ""
            if _es_error(recomendacion):
                recomendacion = ""
            if not observacion:
                if puntaje_act is None:
                    observacion = ""          # no evaluada: la plantilla lo declara
                elif puntaje_act == 0:
                    observacion = ("No se aportó evidencia documental para esta actividad. "
                                   "Conforme a la política de validación, la ausencia de "
                                   "evidencia constituye una FALTA CRÍTICA y puntúa 0.")
                elif puntaje_act <= 2:
                    observacion = ("No cumple con los criterios de validación establecidos "
                                   "para esta actividad.")
                elif puntaje_act == 3:
                    observacion = ("Cumplimiento parcial identificado — existen brechas que "
                                   "requieren atención.")
                else:
                    observacion = "No se identificaron observaciones relevantes."

            riesgo = reglas.riesgo_desde_puntaje(puntaje_act, sin_evidencia=sin_ev)
            controles.append({
                "id": cid, "ambito": ambito, "control": ev.get("control") or "",
                "control_especifico": "", "actividad": actividad,
                "descripcion": concepto or "",
                "no_evaluado": puntaje_act is None,
                "_ev": ev, "_puntaje": puntaje_act, "_observacion": observacion,
            })
            if riesgo:
                if not recomendacion:
                    recomendacion = _generar_recomendacion_automatica(
                        actividad, puntaje_act, concepto, observacion)
                observaciones.append({
                    "control_id": cid, "ambito": ambito, "riesgo": riesgo,
                    "observacion": observacion, "recomendacion": recomendacion,
                    "nota_pie": _procedencia_nota(ev),
                })

    def detalle_control(doc, c, os_):
        ev, pj = c["_ev"], c["_puntaje"]
        _pj = "—" if pj is None else pj
        PB.campo(doc, "Puntaje del agente", f"{_pj}/5 — {_puntaje_label(pj)}")
        if not os_ and c["_observacion"] and not c.get("no_evaluado"):
            p = PB.campo(doc, "Evaluación", c["_observacion"])
            _nota = _procedencia_nota(ev)
            if _nota:
                try:
                    _WE.add_nota_pie(doc, p, _nota)
                except Exception as _e:          # nunca por una nota al pie
                    logger.warning("nota al pie omitida: %s", _e)
        evidencia = ev.get("evidencia") or ev.get("evidencia_encontrada") or ""
        if evidencia and not _es_error(evidencia):
            PB.cita(doc, "Evidencia encontrada", evidencia)
        _quien = ev.get("ejecutado_por")
        if _quien:
            PB.campo(doc, "Ejecutado por",
                     "El VALIDADOR, en su máquina. El agente solo leyó la tabla de "
                     "resultados; no ejecutó el motor." if _quien == "validador" else
                     "El AGENTE, sobre el dataset aportado.")
        _add_hallazgos_codigo(doc, ev.get("hallazgos_codigo") or [], indent=0.6)
        _add_hallazgos_cdd(doc, ev.get("hallazgos_cdd") or [], indent=0.6)
        preguntas = ev.get("preguntas_faltantes") or ev.get("preguntas_pendientes") or []
        if preguntas:
            PB.campo(doc, "Preguntas / requerimientos pendientes")
            for preg in preguntas:
                PB.campo(doc, "·", str(preg), sangria=1.2)

    def contexto(doc):
        PB._p(doc, f"Modelo {titulo_modelo} (Tier {tier}). Se evaluaron "
                   f"{len(evaluaciones_por_ambito)} ámbitos VIRF y {len(controles)} "
                   "actividades del estándar.", size=10.5)
        if resumen_ejecutivo and not resumen_ejecutivo.startswith("[ERROR"):
            for sec in re.split(r"###\s*", resumen_ejecutivo):
                if not sec.strip():
                    continue
                lineas = sec.strip().split("\n")
                tit, cuerpo = lineas[0].strip(), "\n".join(lineas[1:]).strip()
                if tit and cuerpo:
                    PB._p(doc, tit, size=10.5, bold=True, color=PB._AZUL2, align="l",
                          space_after=2)
                    PB._p(doc, cuerpo, size=10.5)
                else:
                    PB._p(doc, sec.strip(), size=10.5)
        n_obs = sum(len(ev.get("preguntas_faltantes") or ev.get("preguntas_pendientes") or [])
                    for evals in evaluaciones_por_ambito.values() for ev in evals)
        if n_obs:
            PB._p(doc, f"Se identificaron {n_obs} preguntas y requerimientos pendientes de "
                       "respuesta por el equipo modelador.", size=10.5)

    n_ne = sum(1 for c in controles if c["no_evaluado"])
    limitaciones = []
    if n_ne:
        limitaciones.append(f"{n_ne} actividad(es) NO EVALUADA(s) por un fallo técnico durante "
                            "la corrida: deben re-ejecutarse antes de emitir dictamen sobre "
                            "ellas.")
    if score_global is None:
        limitaciones.append("No se emite score global del agente: ningún ámbito aportó "
                            "evidencia suficiente para evaluar. La ausencia de dictamen no "
                            "equivale a un dictamen desfavorable.")

    def conclusion_extra(doc):
        PB._p(doc, "Información complementaria del agente (referencial; no sustituye a la "
                   "calificación):", size=9.5, italic=True, color=PB._GRIS, align="l",
              space_after=2)
        PB.campo(doc, "Score global ponderado",
                 f"{score_global:.2f}/5.0 — {_label_semaforo(score_global)}"
                 if score_global is not None else _label_semaforo(None))
        # Misma estética que el resto del informe (no la tabla navy/saturada de
        # `_tabla_scores`, que se conserva para quien la use por separado).
        filas = [[amb, f"{AMBITO_PESOS.get(amb, 0) * 100:.0f}%",
                  f"{sc:.2f}" if sc is not None else "—", _label_semaforo(sc)]
                 for amb, sc in scores_por_ambito.items()]
        filas.append(["Score global ponderado", "",
                      f"{score_global:.2f}" if score_global is not None else "—",
                      _label_semaforo(score_global)])
        t = PB._tabla(doc, ["Ámbito", "Peso", "Score", "Dictamen del agente"], filas,
                      widths_cm=[7.0, 2.2, 2.2, 5.0], aligns=["l", "c", "c", "c"], cap_font=9)
        for celda in t.rows[-1].cells:
            for r in celda.paragraphs[0].runs:
                r.font.bold = True
        PB.no_partir(t)
        doc.add_paragraph().paragraph_format.space_after = Pt(2)
        _pol = politicas_procedimiento or {}
        _veto = _pol.get("veto_por_ambito") or []
        _criticos = _pol.get("criticos_automaticos") or []
        if _criticos:
            PB.campo(doc, "§6 Hallazgo crítico automático (score ≤ 2)",
                     f"{', '.join(_criticos)}. Se eleva al Comité de Riesgos en su siguiente "
                     "sesión, con copia inmediata al dueño del modelo.", seguir=False)
        if _veto:
            PB.campo(doc, "§4.2 Ámbito por debajo del umbral bloqueante (score < 2.5)",
                     f"{', '.join(_veto)}. La política impide la aprobación aunque el score "
                     "global la supere.", seguir=False)
        if _veto or _criticos:
            PB._p(doc, "La decisión formal la firma el validador (§1 del procedimiento); "
                       "este bloque declara lo que no puede pasarse por alto.",
                  size=9, italic=True, color=PB._GRIS, align="l")
        if override is not None:
            from modulos.override_humano import linea_independencia
            PB._p(doc, linea_independencia(override), size=10, bold=True,
                  color=PB._AZUL2, align="l")

    def escala(doc):
        criterios = {
            1: "Evidencia ausente o completamente insuficiente",
            2: "Requiere remediación inmediata — observaciones críticas",
            3: "Brechas importantes pero no bloquean el proceso",
            4: "Cumplimiento sustancial con mejoras recomendadas",
            5: "Evidencia sólida, completa y bien documentada",
        }
        riesgo = {1: "Crítico", 2: "Crítico", 3: "Moderado", 4: "Oportunidad de Mejora",
                  5: "Sin observación"}
        filas = [[str(pj), info["label"], criterios.get(pj, ""), riesgo.get(pj, "")]
                 for pj, info in ESCALA_PUNTAJE.items()]
        t = PB._tabla(doc, ["Puntaje", "Estado", "Criterio", "Riesgo en el informe"], filas,
                      widths_cm=[1.8, 3.6, 7.2, 3.8], aligns=["c", "l", "l", "c"], cap_font=9)
        for fila, (pj, info) in zip(t.rows[1:], ESCALA_PUNTAJE.items()):
            r_ = riesgo.get(pj)
            _set_cell_bg(fila.cells[0], PB.FILL_RIESGO.get(r_, "E2EFDA"))
        PB.no_partir(t)
        PB._caption(doc, "Escala de puntaje del agente y su traducción a riesgo para la "
                         "calificación del informe. 0 = sin evidencia (falta crítica).")

    _val = validacion_humana or {}
    anexos = [
        ("Aprobación y responsabilidad",
         lambda d: _hoja_firma(d, validacion_humana, custodia, titulo_modelo, tier,
                               con_titulo=False)),
        ("Trazabilidad y cadena de custodia",
         lambda d: _metadatos_custodia(d, custodia, agente_meta, con_titulo=False)),
        ("Escala de evaluación del agente", escala),
        ("Correcciones del validador", lambda d: _anexo_correcciones(d, override, con_titulo=False)),
    ]
    if skills and isinstance(skills, list):
        anexos.append(("Análisis transversales",
                       lambda d: _seccion_skills(d, skills, con_titulo=False)))

    informe = {
        "tipo": tipo_validacion if tipo_validacion in ("periodica", "primera_vez") else "periodica",
        "nombre_modelo": titulo_modelo,
        "fecha_inicio": fecha_inicio or now.strftime("%Y-%m-%d"),
        "fecha_entrega": fecha_entrega or now.strftime("%Y-%m-%d"),
        "responsable_doc": str(_val.get("validador") or ""),
        "revisado_por": revisado_por,
        "contexto": contexto,
        "limitaciones": "\n\n".join(limitaciones),
        "ambitos": ambitos,
        "controles": controles,
        "observaciones": observaciones,
        "nota_alcance": f", aplicables a un modelo Tier {tier}" if tier else "",
        "nota_cuadro": ("Cuadro resumen de las observaciones del agente (riesgo derivado del "
                        "puntaje; ver Anexo C)."),
        "subtitulo_portada": "Segunda Línea de Defensa — Validación de Modelos",
        "glosario_extra": [
            ("Puntaje del agente", "—", "Valoración 0–5 de cada actividad; 0 indica ausencia "
                                        "de evidencia (falta crítica)."),
            ("Score global", "—", "Puntaje agregado de la corrida; información complementaria "
                                  "de la calificación."),
            ("Tier", "—", "Nivel de criticidad del modelo que gradúa la exigencia de la "
                          "validación."),
        ],
        "detalle_control": detalle_control,
        "conclusion_extra": conclusion_extra,
        "anexos": anexos,
    }
    outputs_dir.mkdir(parents=True, exist_ok=True)
    PB.generar(informe, ruta)
    print(f"  ✓ Word generado: {ruta}")
    return ruta
