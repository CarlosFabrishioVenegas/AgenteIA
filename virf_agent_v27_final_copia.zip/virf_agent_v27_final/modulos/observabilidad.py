"""
modulos/observabilidad.py  [Pasos 54 · 56 · 57]
═════════════════════════════════════════════════════════════════════════════
Dataset operativo y reporte de costes a partir de la bitácora de auditoría
(SEG-12). Cada llamada a IA ya deja en UNA entrada: quién, corrida, modelo,
tokens de entrada/salida (reales o estimados, marcado), latencia, resultado y
coste estimado.

Salidas (CSV, una fila por clave), para Power BI u hoja de cálculo:
  llamadas.csv            una fila por llamada a IA
  costes_por_corrida.csv  agregado por corrida
  costes_por_usuario.csv  agregado por usuario
  uso_diario.csv          agregado por día (latencia p95, errores, coste)

Los costes son ESTIMACIONES con precios de lista (config/modelos.py), no la
factura de Azure.
"""
from __future__ import annotations

import csv
import math
from collections import defaultdict
from pathlib import Path
from typing import Dict, Iterable, List, Optional

__all__ = ["llamadas", "agregar", "p95", "generar"]

_COLS = ["cuando", "dia", "quien", "corrida", "modelo", "origen", "resultado",
         "tokens_entrada", "tokens_salida", "tokens_estimados", "latencia_ms", "coste_usd"]


def llamadas(entradas: Optional[Iterable[dict]] = None) -> List[dict]:
    if entradas is None:
        from modulos import auditoria
        entradas = auditoria.leer()
    filas = []
    for e in entradas:
        if e.get("accion") != "llamada_ia":
            continue
        d = e.get("detalle") or {}
        filas.append({
            "cuando": e.get("cuando", ""), "dia": (e.get("cuando") or "")[:10],
            "quien": e.get("quien", ""), "corrida": d.get("corrida") or "(sin corrida)",
            "modelo": d.get("modelo", ""), "origen": d.get("origen", ""),
            "resultado": e.get("resultado", ""),
            "tokens_entrada": int(d.get("tokens_entrada") or 0),
            "tokens_salida": int(d.get("tokens_salida") or 0),
            "tokens_estimados": bool(d.get("tokens_estimados")),
            "latencia_ms": d.get("latencia_ms"),
            "coste_usd": float(d.get("coste_usd") or 0.0),
        })
    return filas


def p95(valores: List[float]) -> Optional[float]:
    v = sorted(x for x in valores if x is not None)
    if not v:
        return None
    return float(v[max(0, math.ceil(0.95 * len(v)) - 1)])


def agregar(filas: List[dict], clave: str) -> List[dict]:
    grupos: Dict[str, List[dict]] = defaultdict(list)
    for f in filas:
        grupos[f[clave]].append(f)
    salida = []
    for k, g in sorted(grupos.items()):
        salida.append({
            clave: k, "llamadas": len(g),
            "errores": sum(1 for f in g if not str(f["resultado"]).startswith("ok")),
            "tokens_entrada": sum(f["tokens_entrada"] for f in g),
            "tokens_salida": sum(f["tokens_salida"] for f in g),
            "coste_usd": round(sum(f["coste_usd"] for f in g), 6),
            "latencia_p95_ms": p95([f["latencia_ms"] for f in g]),
            "con_tokens_estimados": sum(1 for f in g if f["tokens_estimados"]),
        })
    return salida


def _csv(ruta: Path, filas: List[dict], cols: List[str]) -> None:
    ruta.parent.mkdir(parents=True, exist_ok=True)
    with open(ruta, "w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(filas)


def generar(destino: Path, entradas: Optional[Iterable[dict]] = None) -> Dict[str, int]:
    filas = llamadas(entradas)
    destino = Path(destino)
    _csv(destino / "llamadas.csv", filas, _COLS)
    res = {"llamadas": len(filas)}
    for nombre, clave in (("costes_por_corrida", "corrida"), ("costes_por_usuario", "quien"),
                          ("uso_diario", "dia")):
        ag = agregar(filas, clave)
        cols = [clave, "llamadas", "errores", "tokens_entrada", "tokens_salida", "coste_usd",
                "latencia_p95_ms", "con_tokens_estimados"]
        _csv(destino / f"{nombre}.csv", ag, cols)
        res[nombre] = len(ag)
    return res
