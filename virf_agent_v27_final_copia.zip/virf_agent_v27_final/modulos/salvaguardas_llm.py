"""
modulos/salvaguardas_llm.py  [SEG-16]
═════════════════════════════════════════════════════════════════════════════
Robustez del LLM (OWASP Top 10 LLM: LLM09 «overreliance», LLM01 inyección):
una afirmación sin respaldo NO llega al informe.

Se aplica a cada evaluación del motor (modulos/motor_ia.py), DESPUÉS de las
verificaciones existentes:

  1. Citas dudosas → INVALIDAN la afirmación. Antes «se declaraban, no
     invalidaban»: la observación se publicaba igual con un aviso.
  2. Verificación semántica (NLI, modulos/entailment.py): si el fragmento NO
     implica la observación, también se invalida.
  3. Abstención β (modulos/abstencion.py): si no hay evidencia citable y el
     mejor fragmento RAG recuperado queda por debajo de β, el agente se
     ABSTIENE y lo dice («EVIDENCIA INSUFICIENTE») en lugar de opinar.

Invalidar no borra: el texto original queda en `observacion_retirada` para el
revisor humano, y `requiere_revision_humana=True`. Lo que no ocurre es que el
informe lo presente como conclusión.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional

__all__ = ["aplicar", "TEXTO_RETIRADA", "TEXTO_ABSTENCION"]

TEXTO_RETIRADA = ("Afirmación retirada por falta de respaldo verificable ({motivo}). "
                  "Requiere revisión humana antes de incluirse en el informe.")
TEXTO_ABSTENCION = "EVIDENCIA INSUFICIENTE — el agente se abstiene: {motivo}"


def _retirar(resultado: Dict[str, Any], motivo: str) -> None:
    if not resultado.get("observacion_retirada"):
        resultado["observacion_retirada"] = resultado.get("observacion") or ""
    resultado.setdefault("motivos_invalidacion", []).append(motivo)
    resultado["afirmacion_invalidada"] = True
    resultado["requiere_revision_humana"] = True
    resultado["observacion"] = TEXTO_RETIRADA.format(
        motivo="; ".join(resultado["motivos_invalidacion"]))


def aplicar(resultado: Dict[str, Any], citas_dudosas: Optional[List[str]] = None,
            rag_scores: Optional[Iterable[Any]] = None) -> Dict[str, Any]:
    """Modifica y devuelve `resultado` según las tres reglas."""
    citas_dudosas = list(citas_dudosas or [])
    resultado.setdefault("afirmacion_invalidada", False)
    resultado.setdefault("requiere_revision_humana", False)

    if citas_dudosas:
        _retirar(resultado, f"{len(citas_dudosas)} cita(s) no encontradas literalmente "
                            "en la evidencia")

    ent = resultado.get("entailment") or {}
    if ent.get("implica") is False:
        _retirar(resultado, "la verificación semántica (NLI) indica que el fragmento "
                            "citado no sostiene la observación")

    from modulos.abstencion import evaluar_abstencion
    hay_evidencia = bool((resultado.get("evidencia_encontrada") or "").strip())
    abst = evaluar_abstencion(list(rag_scores or []))
    resultado["abstencion"] = {k: abst[k] for k in ("abstenido", "score_max", "umbral", "motivo")}
    if not hay_evidencia and abst["abstenido"]:
        resultado["abstenido"] = True
        resultado["requiere_revision_humana"] = True
        if not resultado.get("observacion_retirada"):
            resultado["observacion_retirada"] = resultado.get("observacion") or ""
        resultado["observacion"] = TEXTO_ABSTENCION.format(motivo=abst["motivo"])
    else:
        resultado.setdefault("abstenido", False)
    # [Paso 43] Estado explícito en la salida estructurada.
    from modulos.abstencion import EVIDENCIA_INSUFICIENTE
    resultado["estado_evidencia"] = (EVIDENCIA_INSUFICIENTE if resultado.get("abstenido")
                                     else "SUFICIENTE")
    return resultado
