"""
modulos/feedback.py
Gestión de feedback del validador sobre las evaluaciones del agente.

Flujo:
  1. Al final de cada corrida (--preprdc o --prdc), se lanza un bucle interactivo
     donde el usuario puede registrar correcciones a cualquier actividad evaluada.
  2. El feedback se guarda en feedback/historial_feedback.json
  3. En la siguiente corrida, el motor IA recibe el historial como contexto adicional
     para ajustar sus evaluaciones.
  4. Con --estadisticafeedback se genera un informe de precisión del agente.
"""

import hashlib
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

FEEDBACK_PATH = Path(__file__).parent.parent / "feedback" / "historial_feedback.json"


# ═════════════════════════════════════════════════════════════════════════════
# [AUDIT-FIX PENDIENTE-2] AUTORÍA DE LAS CORRECCIONES
#
# Qué había antes y por qué estaba mal
# ────────────────────────────────────
# El historial guardaba QUÉ se corrigió pero no QUIÉN lo corrigió. El anexo del
# Word decía «el validador ajustó 2 puntajes» sin poder acreditar cuál de los
# 2-5 validadores del equipo fue, y ese anexo es justo la evidencia de que hubo
# supervisión humana: sin autor, acredita que alguien tocó el fichero.
#
# El efecto colateral estaba en `override_humano.calidad_proceso()`, que como no
# tenía el dato atribuía las correcciones «por modelo aprobado» —todas las
# correcciones de un modelo se imputaban a quien firmó su informe— y lo
# declaraba explícitamente como aproximación. Con dos personas alternándose
# sobre el mismo modelo, la señal de «aprueba en bloque sin corregir» podía
# señalar a quien sí revisó.
#
# Retrocompatibilidad
# ───────────────────
# Los registros anteriores no tienen el campo y NO se pueden descartar: son
# meses de calibración que alimentan el ajuste anti-sesgo. Se leen siempre a
# través de `autor_de()`, que los devuelve como SIN_AUTOR. Ausencia declarada,
# nunca un nombre inventado (§7 del prompt de continuidad).
# ═════════════════════════════════════════════════════════════════════════════

#: Autor de los registros previos a PENDIENTE-2. No es un valor de relleno: es
#: la declaración de que ese dato no se capturó cuando se registró la corrección.
SIN_AUTOR = "(no registrado)"


def autor_de(reg: Dict) -> str:
    """
    Autor de una corrección, con los registros antiguos tratados como SIN_AUTOR.

    [§3.4] `reg.get("validador", SIN_AUTOR)` sería INCORRECTO: el segundo
    argumento de `.get` solo actúa si la clave FALTA, no si está presente con
    valor nulo. Un registro con `{"validador": None}` —que es lo que produce una
    corrida sin identidad resuelta— devolvería `None` y reventaría al comparar
    o al pintarlo en el Word. Ese defecto ya se ha producido dos veces en este
    proyecto. Con `or` se cubren los tres casos: ausente, nulo y cadena vacía.
    """
    return (reg.get("validador") or "").strip() or SIN_AUTOR


def cargo_de(reg: Dict) -> str:
    """Cargo del autor de una corrección. Mismo criterio que `autor_de`."""
    return (reg.get("cargo") or "").strip() or SIN_AUTOR


def identidad_para_feedback(nombre: Optional[str] = None,
                            cargo: Optional[str] = None) -> Dict[str, str]:
    """
    Identidad que firma las correcciones de esta sesión.

    Se resuelve con `validador_humano.solicitar_identidad`, que es LA MISMA
    fuente que firma el informe: la identidad AUTENTICADA (SEG-02, aserción de
    la sesión SSO). `nombre`/`cargo` ya no se usan como firmante: si se pasan y no
    coinciden con la identidad autenticada, se rechaza. Usar otra fuente
    permitiría que el informe lo firmara Ana y sus correcciones constaran a
    nombre de Luis.

    `obligatorio=False` a propósito: el bucle de feedback corre en
    PRE-PRODUCCIÓN, donde `--prdc` no ha exigido identidad. Bloquear aquí
    impediría registrar calibración —que es lo que da valor al historial— por no
    haber puesto un flag. Sin identidad se registra SIN_AUTOR, que es peor que
    tenerla pero mucho mejor que perder la corrección.

    `interactivo=False`: preguntar el nombre en medio del bucle de correcciones
    interrumpiría el flujo que el validador está usando. Se toma de flag o
    entorno, o se declara ausente.
    """
    try:
        from modulos.validador_humano import solicitar_identidad
        ident = solicitar_identidad(obligatorio=False)
    except Exception:
        # Nunca puede tumbar el registro de una corrección: el juicio humano es
        # el dato caro de esta función, la atribución es el dato deseable.
        ident = {}
    autenticado = (ident.get("validador") or "").strip()
    if nombre and nombre.strip() and nombre.strip() != autenticado:
        raise PermissionError(
            "no se puede registrar feedback a nombre de otra persona: el autor es "
            "la identidad autenticada")
    return {
        "validador": autenticado or SIN_AUTOR,
        "cargo": (ident.get("cargo") or "").strip() or SIN_AUTOR,
        "oid": ident.get("oid") or "",
    }


# ─── Carga y guardado del JSON ────────────────────────────────────────────────

def _id_registro(reg: Dict) -> str:
    """
    Identidad estable de un registro, para poder fusionar sin duplicar.
    Si no trae `_id`, se deriva de su contenido.
    """
    if reg.get("_id"):
        return str(reg["_id"])
    clave = "|".join(str(reg.get(k, "")) for k in
                     ("timestamp", "ambito", "actividad", "modelo", "tier",
                      "puntaje_agente", "puntaje_humano",
                      # Los registros reales NO traen `timestamp`, `modelo` ni
                      # `puntaje_humano`, sino `fecha`, `titulo_modelo` y
                      # `puntaje_correcto`. Sin estos campos, la misma actividad
                      # corregida en otro modelo u otro día recibía el mismo id
                      # y se guardaba como ENMIENDA de la anterior: una
                      # actividad nunca acumulaba muestras.
                      "fecha", "titulo_modelo", "puntaje_correcto",
                      "sesion_chat", "comentario"))
    return hashlib.sha256(clave.encode("utf-8")).hexdigest()[:16]


# ─── [SEG-08] Cadena de integridad ───────────────────────────────────────────
# El historial es SOLO-ANEXAR. Cada registro lleva `_hash_prev` (hash del
# anterior) y `_hash` = sha256(registro canónico sin `_hash`). Editar un
# registro crea una entrada `_tipo: "enmienda"` que referencia al original;
# borrarlo crea una `_tipo: "baja"`. Nunca se reescribe una entrada existente,
# así que modificar el fichero a mano rompe `verificar_cadena()`.
_GENESIS = "0" * 64
_META = ("_hash", "_hash_prev", "_tipo", "_enmienda_de", "_baja_de",
         "_autor_cambio", "_motivo", "_ts_cambio")


def _canonico(reg: Dict) -> bytes:
    return json.dumps({k: v for k, v in reg.items() if k != "_hash"},
                      sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")


def _sellar(reg: Dict, prev: str) -> Dict:
    reg["_hash_prev"] = prev
    reg["_hash"] = hashlib.sha256(_canonico(reg)).hexdigest()
    return reg


def _contenido(reg: Dict) -> Dict:
    return {k: v for k, v in reg.items() if k not in _META and k != "_id"}


def verificar_cadena(registros: Optional[List[Dict]] = None) -> Dict:
    """Recalcula la cadena. {"ok", "n", "roto_en" (índice o None), "motivo"}."""
    regs = cargar_historial_crudo() if registros is None else registros
    prev = _GENESIS
    for i, r in enumerate(regs):
        if not isinstance(r, dict):
            return {"ok": False, "n": len(regs), "roto_en": i,
                    "motivo": "entrada que no es un registro"}
        if r.get("_hash_prev") != prev:
            return {"ok": False, "n": len(regs), "roto_en": i,
                    "motivo": "enlace con el registro anterior roto (borrado o reordenado)"}
        if hashlib.sha256(_canonico(r)).hexdigest() != r.get("_hash"):
            return {"ok": False, "n": len(regs), "roto_en": i,
                    "motivo": "contenido modificado después de sellarse"}
        prev = r["_hash"]
    return {"ok": True, "n": len(regs), "roto_en": None, "motivo": ""}


def _vigente(crudo: List[Dict]) -> List[Dict]:
    """Vista efectiva: originales con su última enmienda aplicada y sin bajas."""
    orden: List = []
    efectivo: Dict[str, Dict] = {}
    for r in crudo:
        if not isinstance(r, dict):
            # Basura heredada: pasa tal cual para que los consumidores la
            # descarten y AVISEN (no se oculta aquí).
            orden.append(("raw", r))
            continue
        tipo = r.get("_tipo")
        if tipo == "enmienda" and r.get("_enmienda_de") in efectivo:
            efectivo[r["_enmienda_de"]] = {**_contenido(r), "_id": r["_enmienda_de"]}
        elif tipo == "baja":
            efectivo.pop(r.get("_baja_de"), None)
        elif tipo is None:
            rid = r.get("_id") or _id_registro(r)
            efectivo[rid] = {**_contenido(r), "_id": rid}
            orden.append(("id", rid))
    return [v if k == "raw" else efectivo[v] for k, v in orden
            if k == "raw" or v in efectivo]


def cargar_historial_crudo() -> List[Dict]:
    """
    Todas las entradas tal como están en disco (con su sello).

    [AUDIT-FIX] Un JSON corrupto ya no devuelve `[]` en silencio: se preserva
    con sufijo `.corrupto-<ts>` y se avisa por consola.
    """
    if not FEEDBACK_PATH.exists():
        return []
    try:
        with open(FEEDBACK_PATH, encoding="utf-8") as f:
            datos = json.load(f)
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, IOError) as exc:
        respaldo = FEEDBACK_PATH.with_suffix(
            f".corrupto-{datetime.now():%Y%m%d%H%M%S}.json")
        try:
            FEEDBACK_PATH.replace(respaldo)
            aviso = f"se conservó una copia en {respaldo.name}"
        except OSError:
            aviso = "NO se pudo conservar copia"
        print(f"\n  ⚠️  historial_feedback.json ilegible ({exc}); {aviso}.")
        print("     Se continúa con historial vacío: revisa esa copia antes")
        print("     de registrar nuevo feedback si te importa el histórico.\n")
        return []


def cargar_historial() -> List[Dict]:
    """Historial EFECTIVO (enmiendas aplicadas, bajas excluidas). Es lo que
    consume el agente; la auditoría usa `cargar_historial_crudo()`."""
    return _vigente(cargar_historial_crudo())


def guardar_historial(historial: List[Dict], autor: str = "",
                      motivo: str = "") -> None:
    """
    Persiste cambios como ENTRADAS NUEVAS de la cadena (solo-anexar).

    · registro nuevo              → se añade sellado;
    · registro existente igual    → no se toca;
    · registro existente cambiado → se añade una «enmienda» que lo referencia.
    Lo que haya en disco y no venga en `historial` se conserva (fusión entre
    procesos): guardar nunca borra. Para retirar uno: `dar_de_baja()`.

    Lock entre procesos + escritura atómica (tmp + os.replace), como antes.
    """
    from modulos.document_cache import _escribir_json_atomico, _lock_archivo
    FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)

    with _lock_archivo(FEEDBACK_PATH):
        try:
            crudo = []
            if FEEDBACK_PATH.exists():
                with open(FEEDBACK_PATH, encoding="utf-8") as f:
                    crudo = json.load(f)
            crudo = crudo if isinstance(crudo, list) else []
        except (json.JSONDecodeError, OSError):
            crudo = []
        # Sellado inicial de registros heredados sin sello (una sola vez).
        prev = _GENESIS
        for r in crudo:
            if not isinstance(r, dict):
                continue        # basura heredada: verificar_cadena la señalará
            if not r.get("_hash"):
                if r.get("_tipo") is None:
                    r.setdefault("_id", _id_registro(r))
                _sellar(r, prev)
            prev = r["_hash"]
        vig = {r["_id"]: r for r in _vigente(crudo)}
        conocidos = {r.get("_id") for r in crudo
                     if isinstance(r, dict) and r.get("_tipo") is None}

        for reg in historial:
            rid = reg.get("_id") or _id_registro(reg)
            if rid in vig:
                if _contenido(vig[rid]) == _contenido(reg):
                    continue
                nuevo = {**_contenido(reg), "_tipo": "enmienda", "_enmienda_de": rid,
                         "_autor_cambio": autor, "_motivo": motivo,
                         "_ts_cambio": datetime.now().isoformat(timespec="seconds")}
            elif rid in conocidos:
                continue        # dado de baja: guardar no lo resucita
            else:
                nuevo = {**_contenido(reg), "_id": rid}
                # [Paso 25] Nace PENDIENTE: no influye en puntajes hasta aprobarse.
                nuevo.setdefault("estado_aprobacion", "pendiente")
                conocidos.add(rid)
            crudo.append(_sellar(nuevo, prev))
            prev = nuevo["_hash"]
            vig[rid] = {**_contenido(nuevo), "_id": rid}

        _escribir_json_atomico(FEEDBACK_PATH, crudo)


ESTADOS_APROBACION = ("pendiente", "aprobado", "negado")


def cargar_historial_aprobado() -> List[Dict]:
    """[Paso 25] Solo el feedback APROBADO por un revisor influye en puntajes y
    prompts. Lo pendiente o negado se conserva (estadísticas, auditoría) pero
    no se usa para ajustar."""
    return [r for r in cargar_historial()
            if isinstance(r, dict) and r.get("estado_aprobacion") == "aprobado"]


def calibra_puntaje(reg: Dict) -> bool:
    """
    ¿Este registro mide un ERROR DE PUNTAJE del agente?

    Una observación SUBSANADA en el chat de sustentación no lo mide: el agente
    puntuó con la evidencia que tenía y el validado aportó más después. Contarla
    como «el agente subestimó» empuja al agente a ser complaciente con cada
    observación que se cierra. Esos registros sirven de CONTEXTO (qué evidencia
    cerró la brecha), no de calibración.

    Cubre también los registros de chat anteriores a este campo, que guardaron
    la subsanación como diferencia positiva.
    """
    if not isinstance(reg, dict) or reg.get("calibra") is False:
        return False
    if reg.get("origen") == "chat_sustentacion" and "calibra" not in reg:
        try:
            return float(reg.get("diferencia") or 0) == 0
        except (TypeError, ValueError):
            return False
    return True


def cargar_historial_calibracion() -> List[Dict]:
    """Feedback APROBADO que además mide error de puntaje. Es la ÚNICA fuente
    de todo lo que mueve puntajes o instruye un sesgo: ajuste post-hoc, bloque
    anti-sesgo y bloque de aprendizaje."""
    return [r for r in cargar_historial_aprobado() if calibra_puntaje(r)]


def aprobar_feedback(registro_id: str, quien: str, oid: str,
                     decision: str = "aprobado", motivo: str = "") -> Dict:
    """Aprueba o niega un registro. Queda como ENMIENDA sellada en la cadena
    (nunca se edita el original). Quien aprueba no puede ser su autor."""
    if decision not in ("aprobado", "negado"):
        raise ValueError("decisión debe ser 'aprobado' o 'negado'")
    reg = next((r for r in cargar_historial() if isinstance(r, dict)
                and r.get("_id") == registro_id), None)
    if reg is None:
        raise KeyError(f"registro {registro_id!r} no existe o fue dado de baja")
    if oid and reg.get("autor_oid") == oid:
        raise PermissionError("el autor de un feedback no puede aprobarlo")
    # Registros sin `autor_oid` (anteriores a que el chat lo guardara): sin esta
    # comparación por nombre el bloqueo de arriba no puede saltar nunca.
    _autor = autor_de(reg)
    if (not reg.get("autor_oid") and _autor != SIN_AUTOR
            and (quien or "").strip().lower() == _autor.lower()):
        raise PermissionError("el autor de un feedback no puede aprobarlo")
    reg = {**reg, "estado_aprobacion": decision, "aprobado_por": quien,
           "aprobado_oid": oid}
    guardar_historial([reg], autor=quien, motivo=motivo or f"feedback {decision}")
    return reg


def dar_de_baja(registro_id: str, autor: str, motivo: str) -> None:
    """Retira un registro de la vista efectiva añadiendo una entrada «baja»."""
    from modulos.document_cache import _escribir_json_atomico, _lock_archivo
    FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with _lock_archivo(FEEDBACK_PATH):
        crudo = cargar_historial_crudo()
        prev = next((r["_hash"] for r in reversed(crudo)
                     if isinstance(r, dict) and r.get("_hash")), _GENESIS)
        crudo.append(_sellar({"_tipo": "baja", "_baja_de": registro_id,
                              "_autor_cambio": autor, "_motivo": motivo,
                              "_ts_cambio": datetime.now().isoformat(timespec="seconds")},
                             prev))
        _escribir_json_atomico(FEEDBACK_PATH, crudo)


# ─── Bucle interactivo de feedback ───────────────────────────────────────────

def _mostrar_resumen_evaluaciones(evaluaciones_por_ambito: Dict[str, List[Dict]]):
    """Imprime un índice numerado de todas las actividades evaluadas."""
    print("\n" + "═" * 65)
    print("  📝 REGISTRO DE FEEDBACK")
    print("  Puedes corregir cualquier evaluación del agente.")
    print("  Escribe 'fin' cuando termines, 'ver' para ver actividades.")
    print("═" * 65)

    idx = 1
    indice = {}
    for ambito, evals in evaluaciones_por_ambito.items():
        print(f"\n  [{ambito.upper()}]")
        for ev in evals:
            puntaje = ev.get("puntaje", "?")
            actividad = ev.get("actividad", "")[:65]
            print(f"    {idx:>3}. [{puntaje}/5] {actividad}")
            indice[idx] = {"ambito": ambito, "eval": ev}
            idx += 1
    print()
    return indice


class _SinEntradaInteractiva(Exception):
    """[CI-FIX] stdin cerrado o interrumpido: se aborta el feedback sin fallar."""


def _leer(prompt: str = "") -> str:
    """
    [CI-FIX] input() seguro para entornos NO interactivos (cron, CI, nohup,
    docker sin -it, `< /dev/null`).

    Antes: input() lanzaba EOFError, que subía hasta el except genérico de
    agente.py y provocaba sys.exit(1) — el pipeline terminaba con código de
    error PESE A haber completado la evaluación y escrito el JSON.
    Ahora: se convierte en _SinEntradaInteractiva y el bucle sale limpiamente.
    """
    if prompt:
        print(prompt, end="", flush=True)
    try:
        return input().strip()
    except (EOFError, KeyboardInterrupt):
        raise _SinEntradaInteractiva


def bucle_feedback_consola(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    titulo_modelo: str,
    tier: str,
    version: str,
    validador: Optional[str] = None,
    cargo: Optional[str] = None,
) -> List[Dict]:
    """
    Bucle interactivo al final de la ejecución.
    Retorna lista de feedbacks ingresados en esta sesión.

    [CI-FIX] Si stdin no es interactivo, retorna [] sin lanzar excepción,
    permitiendo que el pipeline termine con código de salida 0.

    [PENDIENTE-2] `validador`/`cargo` son los de `--validador`/`--cargo`. Se
    aceptan opcionalmente para no romper a los llamantes existentes; si no
    llegan, `identidad_para_feedback` los busca en el entorno.
    """
    # Detección temprana: si stdin no es un TTY, ni siquiera preguntamos.
    if not sys.stdin or not sys.stdin.isatty():
        print("  ℹ️  stdin no interactivo — registro de feedback omitido.")
        print("     (usa --prdc para suprimir este bloque explícitamente)\n")
        return []

    try:
        return _bucle_feedback_interactivo(
            evaluaciones_por_ambito, titulo_modelo, tier, version,
            validador, cargo
        )
    except _SinEntradaInteractiva:
        print("\n  ℹ️  Entrada interrumpida — feedback no registrado.\n")
        return []


def _bucle_feedback_interactivo(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    titulo_modelo: str,
    tier: str,
    version: str,
    validador: Optional[str] = None,
    cargo: Optional[str] = None,
) -> List[Dict]:
    """Implementación interactiva real (ver bucle_feedback_consola)."""
    historial = cargar_historial()
    # [PENDIENTE-2] Se resuelve UNA vez por sesión, antes del bucle: preguntar o
    # releer el entorno por cada corrección sería ruido, y todas las
    # correcciones de una sesión las hace la misma persona.
    _identidad = identidad_para_feedback(validador, cargo)
    nuevos_feedbacks = []
    indice = _mostrar_resumen_evaluaciones(evaluaciones_por_ambito)

    respuesta = _leer("  ¿Deseas registrar feedback? (s/n): ").lower()
    if respuesta != "s":
        print("  Sin feedback registrado. ✓\n")
        return []

    while True:
        entrada = _leer(
            "\n  Número de actividad a corregir (o 'fin' para terminar, 'ver' para listar): "
        ).lower()

        if entrada == "fin":
            break

        if entrada == "ver":
            indice = _mostrar_resumen_evaluaciones(evaluaciones_por_ambito)
            continue

        try:
            num = int(entrada)
            if num not in indice:
                print(f"  [!] Número {num} no válido. Rango: 1-{max(indice.keys())}")
                continue
        except ValueError:
            print("  [!] Ingresa un número, 'fin' o 'ver'.")
            continue

        item = indice[num]
        ambito    = item["ambito"]
        actividad = item["eval"].get("actividad", "")
        # [AUDIT-FIX · §3.4] Era `.get("puntaje", 0)`, y el respaldo NO actúa
        # cuando la clave existe con valor nulo — que es justo lo que el
        # invariante 2 escribe para una actividad no evaluada. Al calcular
        # `diferencia = puntaje_correcto - puntaje_agente` reventaba con
        # TypeError y se llevaba por delante la sesión de feedback.
        #
        # Misma trampa que rompía las skills (`skills/base.py`), encontrada al
        # revisar TODAS las rutas del patrón, no solo la que falló.
        puntaje_agente = item["eval"].get("puntaje")

        print(f"\n  Ámbito   : {ambito}")
        print(f"  Actividad: {actividad[:80]}")

        if puntaje_agente is None:
            # No se rechaza por capricho: el historial de feedback mide el ERROR
            # DEL AGENTE para calibrarlo. Una actividad que el agente nunca
            # puntuó no tiene error que medir, y registrar una "corrección"
            # sobre un puntaje inexistente contaminaría el ajuste anti-sesgo
            # con una diferencia inventada.
            _motivo = ("no se aportó evidencia" if item["eval"].get("sin_evidencia")
                       else "falló técnicamente")
            print(f"  ⚠️  Esta actividad NO fue evaluada ({_motivo}), así que no")
            print( "      hay puntaje del agente que corregir.")
            print( "      Re-ejecuta la corrida para completarla; si falta")
            print( "      evidencia, apórtala antes de volver a lanzar.")
            continue

        print(f"  Puntaje del agente: {puntaje_agente}/5")

        # Puntaje correcto
        while True:
            try:
                puntaje_correcto = int(_leer("  Puntaje correcto según tu criterio (1-5): "))
                if 1 <= puntaje_correcto <= 5:
                    break
                print("  [!] Ingresa un número entre 1 y 5.")
            except ValueError:
                print("  [!] Número inválido.")

        # Comentario
        comentario = _leer("  ¿Qué debió hacer el agente? (descripción breve): ")
        if not comentario:
            comentario = "Sin comentario adicional."

        feedback_entry = {
            "fecha":           datetime.now().strftime("%d/%m/%Y %H:%M"),
            "titulo_modelo":   titulo_modelo,
            "tier":            tier,
            "version":         version,
            "ambito":          ambito,
            "actividad":       actividad,
            "puntaje_agente":  puntaje_agente,
            "puntaje_correcto": puntaje_correcto,
            "diferencia":      puntaje_correcto - puntaje_agente,
            "comentario":      comentario,
            # [PENDIENTE-2] Quién firma esta corrección. Sin esto, el anexo del
            # Word acredita que alguien tocó el fichero, no que un validador
            # identificable revisó y decidió.
            "validador":       _identidad["validador"],
            "cargo":           _identidad["cargo"],
            "autor_oid":       _identidad.get("oid", ""),     # [Paso 25]
        }

        historial.append(feedback_entry)
        nuevos_feedbacks.append(feedback_entry)
        guardar_historial(historial)

        signo = "+" if feedback_entry["diferencia"] > 0 else ""
        print(f"  ✓ Feedback guardado. Diferencia: {signo}{feedback_entry['diferencia']} puntos")

    if nuevos_feedbacks:
        print(f"\n  ✅ {len(nuevos_feedbacks)} feedback(s) guardados en feedback/historial_feedback.json\n")
    else:
        print("  Sin cambios registrados.\n")

    return nuevos_feedbacks


# ─── Contexto de feedback para el motor IA ───────────────────────────────────

def construir_contexto_feedback(ambito: str, actividad: str) -> str:
    """
    Busca en el historial si hay feedback previo relevante para esta actividad
    y lo formatea como contexto adicional para el motor IA.
    """
    historial = cargar_historial_aprobado()          # [Paso 25] solo aprobado
    if not historial:
        return ""

    relevantes = [
        fb for fb in historial
        if fb.get("ambito", "").lower() == ambito.lower()
        and (
            actividad.lower()[:40] in fb.get("actividad", "").lower()
            or fb.get("actividad", "").lower()[:40] in actividad.lower()
        )
    ]

    if not relevantes:
        # Feedback del mismo ámbito como guía general
        del_ambito = [fb for fb in historial if fb.get("ambito", "").lower() == ambito.lower()][-3:]
        if not del_ambito:
            return ""
        relevantes = del_ambito

    lineas = ["HISTORIAL DE FEEDBACK DEL VALIDADOR (correcciones a evaluaciones anteriores):"]
    for fb in relevantes[-5:]:  # máximo 5 más recientes
        if not calibra_puntaje(fb):
            # Subsanación: NO se presenta como error del agente. Lo útil es qué
            # evidencia cerró la brecha, para saber dónde buscarla la próxima vez.
            lineas.append(
                f"- Actividad: '{fb.get('actividad','')[:60]}' | Observación del "
                f"agente ({fb.get('puntaje_agente')}/5) SUBSANADA después en la "
                f"sustentación con evidencia o aclaración adicional. No fue un "
                f"error de puntaje: no subas el tuyo por esto; comprueba si esa "
                f"evidencia está ahora en el contexto. Detalle: {fb.get('comentario','')}"
            )
            continue
        diff = fb.get("diferencia") or 0
        signo = "sobreestimó" if diff < 0 else "subestimó" if diff > 0 else "coincidió"
        lineas.append(
            f"- Actividad: '{fb.get('actividad','')[:60]}' | "
            f"Agente dio {fb.get('puntaje_agente')}/5, correcto era {fb.get('puntaje_correcto')}/5 "
            f"(el agente {signo} en {abs(diff)} punto(s)). "
            f"Comentario: {fb.get('comentario','')}"
        )
    lineas.append("→ Considera este historial para calibrar tu evaluación actual.")
    return "\n".join(lineas)


# ─── Aprendizaje desde el chat de sustentación (WP-D) ────────────────────────

def _norm_act(s: str) -> str:
    return " ".join(str(s or "").split()).lower()


def _valor_cumple_aprendizaje() -> float:
    """Puntaje que representa 'Cumple' al aprender de un APROBADO. Igual regla que
    modulos.consolidacion.valor_cumple (VIRF_PUNTAJE_CUMPLE, def 5); se inlinea
    para no crear un import circular con motor_ia."""
    import os
    try:
        return max(1.0, min(5.0, float(os.environ.get("VIRF_PUNTAJE_CUMPLE", 5))))
    except (TypeError, ValueError):
        return 5.0


def registrar_aprendizaje_desde_chat(datos: Dict,
                                     observaciones: List[Dict],
                                     identidad: Optional[Dict] = None,
                                     sesion_id: str = "") -> Dict:
    """
    Persiste como FEEDBACK las decisiones cerradas del chat de sustentación, para
    que en futuras corridas el motor las use como CONTEXTO y AJUSTE AUTOMÁTICO del
    puntaje (vía `construir_contexto_feedback` / `ajustar_puntaje_por_feedback`,
    ya cableados en motor_ia).

    Mapeo: APROBADO → subsanación: puntaje_correcto = valor_cumple es el puntaje
    FINAL, pero `calibra=False` (no es un error del agente: entra como contexto,
    no mueve puntajes ni sesgo; ver `calibra_puntaje`);
    NEGADO → confirma el puntaje del agente (diferencia 0, refuerza el criterio).
    PENDIENTE se omite (no es una decisión validada).

    Idempotente por (modelo, ámbito, actividad, sesion_chat): re-consolidar no
    duplica registros. Devuelve {"nuevos": n, "total": N}.
    """
    identidad = identidad or {}
    historial = cargar_historial()

    # Puntaje ORIGINAL del agente por (ámbito, actividad).
    evals: Dict = {}
    for amb, evs in (datos.get("resultados_por_ambito") or {}).items():
        for e in (evs or []):
            evals[(amb, _norm_act(e.get("actividad", "")))] = e

    existentes = {
        (r.get("titulo_modelo"), r.get("ambito"),
         _norm_act(r.get("actividad", "")), r.get("sesion_chat"))
        for r in historial
    }
    val_cumple = _valor_cumple_aprendizaje()
    nuevos = 0
    for o in (observaciones or []):
        v = str(o.get("veredicto") or "").upper()
        if v not in ("APROBADO", "NEGADO"):
            continue
        amb = o.get("ambito", "")
        act = o.get("actividad", "")
        clave = (datos.get("modelo"), amb, _norm_act(act), sesion_id)
        if clave in existentes:
            continue
        e = evals.get((amb, _norm_act(act)), {})
        pa = e.get("puntaje")
        _tenia_puntaje = isinstance(pa, (int, float))
        pa = int(pa) if _tenia_puntaje else 0
        pc = int(round(val_cumple)) if v == "APROBADO" else pa
        com = (o.get("hallazgo_final") or "").strip() or f"Decisión del validador: {v}."
        adj = o.get("adjuntos") or []
        if adj:
            com += f" [Evidencia adjunta: {', '.join(adj)}]"
        historial.append({
            "fecha":            datetime.now().strftime("%d/%m/%Y %H:%M"),
            "titulo_modelo":    datos.get("modelo"),
            "tier":             datos.get("tier"),
            "version":          (datos.get("agente") or {}).get("agente_version"),
            "ambito":           amb,
            "actividad":        act,
            "puntaje_agente":   pa,
            "puntaje_correcto": pc,
            "diferencia":       pc - pa,
            "comentario":       f"[Chat de sustentación] {com}",
            "validador":        identidad.get("validador"),
            "cargo":            identidad.get("cargo"),
            "autor_oid":        identidad.get("oid", ""),      # [Paso 25]
            "origen":           "chat_sustentacion",
            "sesion_chat":      sesion_id,
            # APROBADO = observación subsanada: `puntaje_correcto` es el puntaje
            # FINAL tras la sustentación (lo usa el anexo de overrides), no la
            # medida de un error del agente → no calibra. NEGADO confirma el
            # criterio del agente y sí cuenta como acierto, si había puntaje.
            "tipo_correccion":  "subsanacion" if v == "APROBADO" else "confirmacion",
            "calibra":          v == "NEGADO" and _tenia_puntaje,
        })
        existentes.add(clave)
        nuevos += 1

    if nuevos:
        guardar_historial(historial)
    return {"nuevos": nuevos, "total": len(historial)}


# ─── Estadísticas de precisión ───────────────────────────────────────────────

def _registros_utilizables(historial: List[Dict]) -> List[Dict]:
    """
    [AUDIT-FIX] Filtra los registros con los que SÍ se puede calcular.

    `calcular_estadisticas` accedía a `fb["diferencia"]` directamente y hacía
    `abs()` sin comprobar el tipo. Medido sobre historiales degenerados:

        · falta el campo 'diferencia'   → KeyError
        · 'diferencia' es texto          → TypeError: bad operand type for abs()
        · un elemento no es un dict      → TypeError: string indices must be int

    Cuatro de seis casos tumbaban `--estadisticafeedback` con un traceback,
    mientras `analizar_patron_errores` —del mismo subsistema— los manejaba
    todos sin despeinarse. El historial es editable a mano y lo escriben
    versiones distintas del agente: tiene que tolerar registros viejos o rotos.
    """
    validos = []
    for reg in historial or []:
        if not isinstance(reg, dict):
            continue
        try:
            reg = {**reg, "diferencia": float(reg["diferencia"])}
        except (KeyError, TypeError, ValueError):
            continue
        validos.append(reg)
    return validos


def calcular_estadisticas() -> Dict:
    """Calcula métricas de precisión del agente basadas en el historial de feedback."""
    # Las subsanaciones del chat no miden precisión del agente (`calibra_puntaje`).
    crudo = [r for r in cargar_historial()
             if not isinstance(r, dict) or calibra_puntaje(r)]
    historial = _registros_utilizables(crudo)
    if not historial:
        if crudo:
            return {"error": (
                f"El historial tiene {len(crudo)} registro(s) pero ninguno es "
                f"utilizable (falta 'diferencia' o tiene un tipo inesperado). "
                f"Revisa {FEEDBACK_PATH.name}."
            )}
        return {"error": "No hay historial de feedback registrado."}

    _descartados = len(crudo) - len(historial)
    if _descartados:
        print(f"  ⚠️  {_descartados} registro(s) de feedback ignorados por estar "
              f"malformados (de {len(crudo)}).")

    total = len(historial)
    diferencias = [abs(fb["diferencia"]) for fb in historial]
    diferencias_con_signo = [fb["diferencia"] for fb in historial]

    exactos      = sum(1 for d in diferencias if d == 0)
    diff_1       = sum(1 for d in diferencias if d == 1)
    diff_2_mas   = sum(1 for d in diferencias if d >= 2)
    sobreestima  = sum(1 for d in diferencias_con_signo if d < 0)
    subestima    = sum(1 for d in diferencias_con_signo if d > 0)

    mae = sum(diferencias) / total  # Mean Absolute Error
    sesgo = sum(diferencias_con_signo) / total  # Sesgo promedio (+ = subestima, - = sobreestima)

    # Por ámbito
    ambitos_stats = {}
    for fb in historial:
        amb = fb.get("ambito", "Desconocido")
        if amb not in ambitos_stats:
            ambitos_stats[amb] = {"total": 0, "suma_diff_abs": 0, "suma_diff": 0, "exactos": 0}
        ambitos_stats[amb]["total"] += 1
        ambitos_stats[amb]["suma_diff_abs"] += abs(fb["diferencia"])
        ambitos_stats[amb]["suma_diff"] += fb["diferencia"]
        if fb["diferencia"] == 0:
            ambitos_stats[amb]["exactos"] += 1

    for amb, s in ambitos_stats.items():
        s["mae"]           = round(s["suma_diff_abs"] / s["total"], 3)
        s["sesgo"]         = round(s["suma_diff"] / s["total"], 3)
        s["pct_exactos"]   = round(s["exactos"] / s["total"] * 100, 1)
        s["pct_1_punto"]   = round(sum(1 for fb in historial if fb.get("ambito") == amb and abs(fb["diferencia"]) <= 1) / s["total"] * 100, 1)

    # Por modelo
    modelos_stats = {}
    for fb in historial:
        mod = fb.get("titulo_modelo", "Desconocido")
        if mod not in modelos_stats:
            modelos_stats[mod] = {"total": 0, "suma_diff_abs": 0}
        modelos_stats[mod]["total"] += 1
        modelos_stats[mod]["suma_diff_abs"] += abs(fb["diferencia"])
    for mod, s in modelos_stats.items():
        s["mae"] = round(s["suma_diff_abs"] / s["total"], 3)

    return {
        "total_feedbacks":        total,
        "evaluaciones_exactas":   exactos,
        "pct_exactas":            round(exactos / total * 100, 1),
        "diferencia_1_punto":     diff_1,
        "pct_diff_1":             round(diff_1 / total * 100, 1),
        "diferencia_2_o_mas":     diff_2_mas,
        "pct_diff_2_mas":         round(diff_2_mas / total * 100, 1),
        "pct_dentro_1_punto":     round((exactos + diff_1) / total * 100, 1),
        "mae":                    round(mae, 3),
        "sesgo_promedio":         round(sesgo, 3),
        "sesgo_interpretacion":   "Agente subestima" if sesgo > 0.2 else "Agente sobreestima" if sesgo < -0.2 else "Sin sesgo significativo",
        "n_sobreestimaciones":    sobreestima,
        "n_subestimaciones":      subestima,
        "por_ambito":             ambitos_stats,
        "por_modelo":             modelos_stats,
        "primer_feedback":        historial[0].get("fecha", ""),
        "ultimo_feedback":        historial[-1].get("fecha", ""),
    }
