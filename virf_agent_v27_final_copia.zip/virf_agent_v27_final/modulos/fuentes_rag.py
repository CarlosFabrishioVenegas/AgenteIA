"""
modulos/fuentes_rag.py  [Paso 11 · norma 2135.010.02 §Carga de fuentes]
═════════════════════════════════════════════════════════════════════════════
Dueño y vigencia de cada fuente del corpus RAG compartido.

· Registro versionado en `gobierno/registro_fuentes_rag.json`:
  {"<dominio>/<archivo>": {dueno, vigencia_hasta (AAAA-MM-DD), cargado_por, fecha_carga, sha256}}
· Subir una fuente al RAG sin dueño o sin vigencia se RECHAZA.
· Una fuente VENCIDA no se recupera (el buscador la omite).
· Las fuentes que ya estaban en el corpus sin registro son «huérfanas»: se
  siguen usando pero se listan en el inventario para que el equipo asigne
  dueño (el agente no inventa dueños).
"""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

__all__ = ["registrar_fuente", "estado_fuente", "fuente_vencida", "inventario",
           "escribir_inventario_csv", "FuenteInvalida", "REGISTRO"]

_RAIZ = Path(__file__).resolve().parents[1]
REGISTRO: Path = _RAIZ / "gobierno" / "registro_fuentes_rag.json"
CORPUS: Path = _RAIZ / "inputs" / "rag"
_EXT = {".pdf", ".md", ".txt", ".docx"}
_cache: Dict[str, object] = {"mtime": None, "datos": {}}


class FuenteInvalida(ValueError):
    pass


def _leer() -> Dict[str, dict]:
    try:
        mt = REGISTRO.stat().st_mtime
    except OSError:
        return {}
    if _cache["mtime"] != (REGISTRO, mt):
        try:
            _cache["datos"] = json.loads(REGISTRO.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            _cache["datos"] = {}
        _cache["mtime"] = (REGISTRO, mt)
    return dict(_cache["datos"])


def _clave(dominio: str, nombre: str) -> str:
    return f"{dominio}/{Path(nombre).name}"


def _fecha(valor) -> date:
    try:
        return valor if isinstance(valor, date) else date.fromisoformat(str(valor).strip())
    except ValueError as exc:
        raise FuenteInvalida(f"vigencia inválida {valor!r}: usa AAAA-MM-DD") from exc


def registrar_fuente(dominio: str, fichero: Path, dueno: str, vigencia_hasta,
                     cargado_por: str = "") -> dict:
    if not (dueno or "").strip():
        raise FuenteInvalida("toda fuente del corpus necesita DUEÑO (2135.010.02 §Carga de fuentes)")
    if not str(vigencia_hasta or "").strip():
        raise FuenteInvalida("toda fuente del corpus necesita VIGENCIA (fecha hasta la que es válida)")
    vig = _fecha(vigencia_hasta)
    fichero = Path(fichero)
    sha = hashlib.sha256(fichero.read_bytes()).hexdigest() if fichero.is_file() else ""
    datos = _leer()
    datos[_clave(dominio, fichero.name)] = {
        "dueno": dueno.strip(), "vigencia_hasta": vig.isoformat(),
        "cargado_por": cargado_por, "sha256": sha,
        "fecha_carga": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    }
    REGISTRO.parent.mkdir(parents=True, exist_ok=True)
    REGISTRO.write_text(json.dumps(datos, ensure_ascii=False, indent=2, sort_keys=True),
                        encoding="utf-8")
    return datos[_clave(dominio, fichero.name)]


def estado_fuente(dominio: str, nombre: str, hoy: Optional[date] = None) -> str:
    """vigente | vencida | huerfana"""
    r = _leer().get(_clave(dominio, nombre))
    if not r:
        return "huerfana"
    return "vencida" if _fecha(r["vigencia_hasta"]) < (hoy or date.today()) else "vigente"


def fuente_vencida(dominio: str, nombre: str) -> bool:
    try:
        return estado_fuente(dominio, nombre) == "vencida"
    except FuenteInvalida:
        return True                                   # vigencia ilegible: no se usa


def inventario(corpus: Optional[Path] = None) -> List[dict]:
    base = Path(corpus) if corpus else CORPUS
    reg = _leer()
    filas = []
    for d in sorted(p for p in base.iterdir() if p.is_dir()) if base.is_dir() else []:
        for f in sorted(d.iterdir()):
            if f.suffix.lower() not in _EXT or f.name.lower() == "readme.md":
                continue
            r = reg.get(_clave(d.name, f.name), {})
            filas.append({
                "fuente": f.name, "dominio": d.name,
                "sha256": hashlib.sha256(f.read_bytes()).hexdigest()[:16],
                "fecha_carga": r.get("fecha_carga", ""),
                "dueno": r.get("dueno") or "[POR ASIGNAR 👤]",
                "vigencia_hasta": r.get("vigencia_hasta") or "[POR ASIGNAR 👤]",
                "estado": estado_fuente(d.name, f.name),
            })
    return filas


def escribir_inventario_csv(destino: Path, corpus: Optional[Path] = None) -> List[dict]:
    filas = inventario(corpus)
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    with open(destino, "w", encoding="utf-8", newline="") as f:
        f.write("# Datos elaborados por BCP para uso Interno\n")
        w = csv.DictWriter(f, fieldnames=["fuente", "dominio", "sha256", "fecha_carga",
                                          "dueno", "vigencia_hasta", "estado"])
        w.writeheader()
        w.writerows(filas)
    return filas
