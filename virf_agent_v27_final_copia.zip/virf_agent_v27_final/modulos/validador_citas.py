"""
modulos/validador_citas.py
═════════════════════════════════════════════════════════════════════════════
Validador DETERMINISTA de citas con id de linaje (WP-03/WP-04 · indicador D4).

QUÉ AÑADE
─────────
El motor ya verifica que una cita literal EXISTA en el contexto
(`motor_ia._verificar_citas`). Falta la otra mitad que exige la guía: que cada
afirmación factual venga anclada a un id de LINAJE reconstruible

        [doc_id:pagina:chunk_id]

y que ese `chunk_id` EXISTA de verdad entre los fragmentos recuperados. Sin
esto una cita puede sonar bien, existir literalmente y aun así no ser
localizable en la fuente —el paso previo a "citas alucinadas/decorativas"—.

Esta capa es 100% determinista (regex + pertenencia a un conjunto): no llama al
modelo. La verificación SEMÁNTICA (¿el fragmento IMPLICA la afirmación? — NLI /
entailment) se deja explícitamente diferida al día de API (`verificar_entailment`
devuelve NA-diferido) para no gastar crédito hoy.

FORMATO DEL ID
──────────────
    [doc_id:pagina:chunk_id]
      · doc_id   : identificador del documento (sin ':' ni corchetes)
      · pagina   : número de página, o 's/p' si la fuente no pagina
      · chunk_id : identificador del fragmento dentro del documento

Ejemplos válidos:  [manual_var:12:3]   [acta_comite:s/p:0]
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

__all__ = [
    "normalizar_cita", "cita_en_texto", "RE_ELISION",
    "PATRON_CITA",
    "extraer_ids",
    "id_de_chunk",
    "validar_afirmacion",
    "verificar_afirmaciones",
    "verificar_entailment",
]

# Un segmento del id no puede contener ':', '[' ni ']'.
PATRON_CITA = re.compile(r"\[([^\[\]:]+):([^\[\]:]+):([^\[\]:]+)\]")


# ═════════════════════════════════════════════════════════════════════════════
# Comparación LITERAL de citas — una sola normalización para todos
# ═════════════════════════════════════════════════════════════════════════════
# [2026-11-11] Había tres comparaciones «literales» (motor_ia._verificar_citas,
# revision_codigo.verificar_referencia_manual y entailment._subcadena_laxa),
# cada una con su propia normalización: solo espacios y mayúsculas. Medido en
# la corrida real de modelos/VaR_FixtureDrift: de 74 citas marcadas «no
# verificadas», 35 solo diferían de la fuente en marcas de formato. Y como una
# cita dudosa RETIRA la observación (SEG-16), se perdían las observaciones del
# contraste manual↔código, que son las de más valor.
#
# Qué se iguala —lo que cambia al copiar, no lo que se dice—:
#   · espacios y mayúsculas (los extractores de PDF los desordenan);
#   · marcas Markdown de énfasis y código: * y `;
#   · prefijos de línea de cita en bloque y de título: «> » y «## »;
#   · el salto de línea que el modelo escribe como los dos caracteres \n;
#   · comillas tipográficas.
# Qué NO se toca: letras, cifras, signos y el orden. «250» no casa con «500».

#: Marcas de elisión al citar: «[...]», «[…]», «(...)», «...», «…».
RE_ELISION = re.compile(r"\[\s*(?:\.{2,}|…)\s*\]|\(\s*(?:\.{2,}|…)\s*\)|\.{3,}|…")

_RE_PREFIJO_LINEA = re.compile(r"(?m)^[ \t]*(?:>+|#{1,6})[ \t]*")
_COMILLAS = str.maketrans({"“": '"', "”": '"', "«": '"', "»": '"', "‘": "'", "’": "'"})

#: Un tramo más corto que esto no prueba nada por sí solo.
MIN_CHARS_TRAMO = 8


def normalizar_cita(texto: Any) -> str:
    """Forma canónica de un texto para comparar citas (ver bloque de arriba)."""
    t = str(texto or "")
    t = t.replace("\\r\\n", "\n").replace("\\n", "\n").replace("\\t", " ")
    t = _RE_PREFIJO_LINEA.sub("", t)
    t = t.replace("*", "").replace("`", "").translate(_COMILLAS)
    return " ".join(t.split()).lower()


def cita_en_texto(cita: str, texto_normalizado: str, por_lineas: bool = False) -> bool:
    """
    ¿`cita` aparece literalmente en un texto YA normalizado con `normalizar_cita`?

    1. Entera (sin la puntuación final: quien corta una cita a media frase la
       cierra con un punto donde la fuente sigue con una coma).
    2. Si no, tramo a tramo cuando trae elisiones («A [...] B»): la elisión
       significa «hay texto en medio», no «me lo he inventado». Se exigen
       TODOS los tramos.
    3. Si no, frase a frase: al citar un párrafo a veces se salta una frase
       intermedia sin marcarlo. Se exigen TODAS las frases.
    4. Con `por_lineas=True` (código citado en un bloque), línea a línea: al
       transcribir una función se suele saltar el docstring o un comentario, y
       las líneas dejan de ser contiguas. Se exigen TODAS las líneas.
    Trocear no relaja la prueba: cada trozo sigue teniendo que estar en la
    fuente, con sus mismas palabras y cifras.
    """
    def _limpio(t: str) -> str:
        return normalizar_cita(t).rstrip(" .,;:")

    entera = _limpio(cita)
    if not entera:
        return False
    if entera in texto_normalizado:
        return True
    tramos = [_limpio(t) for t in RE_ELISION.split(str(cita))]
    tramos = [t for t in tramos if len(t) >= MIN_CHARS_TRAMO]
    if len(tramos) > 1 and all(t in texto_normalizado for t in tramos):
        return True
    if not por_lineas:
        # Punto + espacio: no parte «3.81» ni «v4.2».
        frases = [_limpio(f) for t in RE_ELISION.split(str(cita))
                  for f in re.split(r"(?<=[.;])\s+", normalizar_cita(t))]
        frases = [f for f in frases if len(f) >= MIN_CHARS_TRAMO]
        if len(frases) > 1 and all(f in texto_normalizado for f in frases):
            return True
    if por_lineas:
        lineas = [normalizar_cita(l) for l in
                  str(cita).replace("\\n", "\n").splitlines()]
        lineas = [l for l in lineas if len(l) >= MIN_CHARS_TRAMO]
        if len(lineas) > 1 and all(l in texto_normalizado for l in lineas):
            return True
    return False


def extraer_ids(texto: str) -> List[str]:
    """Devuelve los ids de cita `[doc:pagina:chunk]` presentes en el texto."""
    if not texto:
        return []
    return [f"[{d.strip()}:{p.strip()}:{c.strip()}]"
            for d, p, c in PATRON_CITA.findall(texto)]


def id_de_chunk(chunk: Dict[str, Any]) -> Optional[str]:
    """
    Construye el id de linaje de un fragmento recuperado, si trae los campos.

    Acepta las claves ya presentes en el proyecto (`fuente`/`ruta` como doc,
    `pagina`, `chunk`) y tolera ausencias declarándolas ('s/p' para página).
    """
    doc = chunk.get("doc_id") or chunk.get("fuente") or chunk.get("ruta")
    if not doc:
        return None
    pagina = chunk.get("pagina", "s/p")
    chunk_id = chunk.get("chunk_id", chunk.get("chunk"))
    if chunk_id is None:
        return None
    return f"[{doc}:{pagina}:{chunk_id}]"


def _ids_disponibles(contexto: Iterable[Dict[str, Any]]) -> set:
    ids = set()
    for c in contexto or []:
        cid = id_de_chunk(c)
        if cid:
            ids.add(cid)
    return ids


def validar_afirmacion(afirmacion: str,
                       contexto: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Valida UNA afirmación factual contra el contexto recuperado.

    Devuelve un dict con:
        aceptada    : bool  (True solo si trae id bien formado y localizable)
        tiene_cita  : bool
        ids         : lista de ids citados
        ids_validos : ids cuyo chunk existe en el contexto
        ids_invalidos: ids bien formados pero cuyo chunk NO está en el contexto
        motivo      : explicación citable
    """
    disponibles = _ids_disponibles(contexto)
    ids = extraer_ids(afirmacion)

    if not ids:
        return {
            "aceptada": False, "tiene_cita": False, "ids": [],
            "ids_validos": [], "ids_invalidos": [],
            "motivo": "La afirmación no trae id de cita [doc:pagina:chunk].",
        }

    validos = [i for i in ids if i in disponibles]
    invalidos = [i for i in ids if i not in disponibles]
    aceptada = bool(validos) and not invalidos
    if aceptada:
        motivo = "Cita con id localizable en el contexto recuperado."
    elif invalidos:
        motivo = ("Cita con chunk_id inexistente en el contexto recuperado: "
                  + ", ".join(invalidos))
    else:
        motivo = "Cita mal formada."
    return {
        "aceptada": aceptada, "tiene_cita": True, "ids": ids,
        "ids_validos": validos, "ids_invalidos": invalidos, "motivo": motivo,
    }


def verificar_afirmaciones(afirmaciones: Iterable[str],
                           contexto: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Valida una lista de afirmaciones. Resumen agregado para el informe/verificador.

    `tasa_citas_validas` alimenta el indicador D4 (parte determinística).
    """
    ctx = list(contexto or [])
    detalles = [validar_afirmacion(a, ctx) for a in afirmaciones]
    n = len(detalles)
    aceptadas = sum(1 for d in detalles if d["aceptada"])
    return {
        "total": n,
        "aceptadas": aceptadas,
        "rechazadas": n - aceptadas,
        "tasa_citas_validas": (aceptadas / n) if n else 0.0,
        "detalles": detalles,
    }


def verificar_entailment(afirmacion: str, fragmento: str) -> Dict[str, Any]:
    """
    Verificación SEMÁNTICA (NLI/entailment) — DIFERIDA al día de API.

    Deja el punto de integración listo: el día de API se sustituye por una
    llamada al modelo con rúbrica JSON estricta y mitigaciones de sesgo de juez
    (alternar orden, penalizar verbosidad). Hoy no gasta crédito.
    """
    return {
        "implica": None,
        "estado": "NA-diferido",
        "motivo": "verificación NLI/entailment requiere API (fase posterior)",
    }
