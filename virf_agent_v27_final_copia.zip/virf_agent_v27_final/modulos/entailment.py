"""
modulos/entailment.py
═════════════════════════════════════════════════════════════════════════════
Verificación SEMÁNTICA de citas (entailment / NLI): ¿el fragmento citado IMPLICA
la afirmación que se hace sobre él?

QUÉ HUECO CIERRA
────────────────
El motor ya comprueba dos cosas de una cita, ambas DETERMINISTAS:
  · que EXISTA literalmente en el contexto (`motor_ia._verificar_citas`), y
  · que su id de linaje [doc:pág:chunk] sea localizable (`validador_citas`).

Falta la tercera, que es la que un supervisor pregunta al final: que el
fragmento REALMENTE SOSTENGA la conclusión. Una cita puede ser literal, existir
y aun así estar mal usada —el paper habla de otra cartera, la frase dice lo
contrario recortada de contexto—. Eso es «cita decorativa», y ningún checksum lo
detecta: hace falta juicio semántico.

CÓMO
────
Un juez LLM sobre el cliente IA YA CONFIGURADO (`config.get_cliente_ia()`), que
puede ser Anthropic o Azure OpenAI. NO se añade ningún proveedor nuevo, ni
HuggingFace, ni ChromaDB: se reutiliza exactamente el mismo canal que ya evalúa
las actividades.

OPT-IN (VIRF_ENTAILMENT=1)
─────────────────────────
Cuesta una llamada extra por afirmación verificada, así que está APAGADO por
defecto: activarlo es una decisión de coste explícita del operador. Apagado,
`verificar` devuelve el mismo `NA-diferido` de siempre y no toca ni el coste ni
la salida. Esto respeta la política del proyecto de no encender gasto por
heurística — se enciende con un flag, nunca solo.

MITIGACIONES DE SESGO DE JUEZ
─────────────────────────────
  · Rúbrica de TRES veredictos (IMPLICA / NO_IMPLICA / INSUFICIENTE): sin un
    tercer camino, el juez fuerza un sí/no y premia la conclusión con más texto.
  · Se exige la SUBCADENA textual del fragmento que sostiene el veredicto. Anclar
    a evidencia penaliza el «sí» por verbosidad y hace el fallo auditable.
  · `formato_json=True` + parser robusto: el veredicto llega estructurado.
  · Temperatura fija (la del cliente): el mismo par da el mismo veredicto.

Nunca lanza: ante cualquier fallo devuelve un dict con `estado="error"`, porque
una verificación de refuerzo no puede tumbar la evaluación que refuerza.

Uso:
    from modulos.entailment import verificar
    r = verificar(afirmacion="El backtesting usa ventana de 250 días",
                  fragmento="§4.2 … la ventana de observación es de 250 días …")
    #  r["implica"] → True | False | None ;  r["estado"] → "ok" | "NA-diferido" | ...
"""

from __future__ import annotations

from modulos.salida_ia import material_no_confiable as _mnc
import json
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger("virf.entailment")

__all__ = ["verificar", "activo"]

# Longitudes por debajo de las cuales no tiene sentido preguntar: una afirmación
# de tres palabras o un fragmento vacío no dan material para un juicio semántico.
_MIN_AFIRMACION = 15
_MIN_FRAGMENTO = 20


def activo() -> bool:
    """¿Está habilitada la verificación (VIRF_ENTAILMENT=1)?

    La fuente ÚNICA es `config/parametros.py` (invariante CONFIG-CENTRAL): aquí
    NO se lee el entorno directamente, para no crear una segunda declaración del
    flag que pudiera divergir del default oficial.
    """
    try:
        from config.parametros import ENTAILMENT_ACTIVO
        return bool(ENTAILMENT_ACTIVO)
    except Exception:                                     # pragma: no cover
        return False


def _na(motivo: str) -> Dict[str, Any]:
    """Resultado neutro: idéntico en forma al del stub histórico."""
    return {"implica": None, "estado": "NA-diferido", "confianza": None,
            "evidencia": "", "motivo": motivo}


_SISTEMA = (
    "Eres un verificador de entailment (NLI) para un informe de validación de "
    "modelos financieros. Tu único trabajo es decidir si un FRAGMENTO citado "
    "sostiene una AFIRMACIÓN. No evalúas si la afirmación es cierta en el mundo: "
    "solo si ESTE fragmento la implica. Respondes exclusivamente en JSON."
)


def _prompt(afirmacion: str, fragmento: str) -> str:
    return f"""Decide si el FRAGMENTO implica la AFIRMACIÓN.

AFIRMACIÓN:
\"\"\"{afirmacion.strip()}\"\"\"

FRAGMENTO CITADO:
\"\"\"{fragmento.strip()}\"\"\"

RÚBRICA (elige exactamente un veredicto):
  · "IMPLICA"      — el fragmento afirma o implica directamente la afirmación.
  · "NO_IMPLICA"   — el fragmento contradice la afirmación o dice algo distinto.
  · "INSUFICIENTE" — el fragmento no aporta base suficiente para decidir.

REGLAS:
  · Si eliges IMPLICA o NO_IMPLICA, "evidencia" DEBE ser una subcadena LITERAL
    del fragmento (cópiala tal cual). Si no puedes copiar una, el veredicto es
    INSUFICIENTE.
  · No uses conocimiento externo. Cíñete al fragmento.
  · "confianza" es un número entre 0 y 1.

Responde SOLO con este JSON, sin texto alrededor:
{{"veredicto": "IMPLICA|NO_IMPLICA|INSUFICIENTE", "confianza": 0.0, "evidencia": "..."}}"""


def verificar(afirmacion: str, fragmento: str,
              cliente: Optional[Any] = None) -> Dict[str, Any]:
    """
    Verifica si `fragmento` implica `afirmacion`.

    Args:
        afirmacion: la conclusión/observación cuya base se comprueba.
        fragmento:  el texto citado que debería sostenerla.
        cliente:    cliente IA a usar; si es None se toma el ya configurado
                    (`config.get_cliente_ia()`), sin construir nada nuevo.

    Returns:
        dict con:
          implica    : True | False | None (None = insuficiente/apagado/error)
          estado     : "ok" | "NA-diferido" | "error"
          confianza  : float | None
          evidencia  : subcadena del fragmento que sostiene el veredicto
          motivo     : explicación citable
    """
    if not activo():
        return _na("verificación NLI apagada (VIRF_ENTAILMENT=0)")
    if not afirmacion or len(afirmacion.strip()) < _MIN_AFIRMACION:
        return _na("afirmación demasiado corta para un juicio semántico")
    if not fragmento or len(fragmento.strip()) < _MIN_FRAGMENTO:
        return _na("fragmento demasiado corto para un juicio semántico")

    try:
        if cliente is None:
            from config.ia import get_cliente_ia
            cliente = get_cliente_ia()

        crudo = cliente.generar_mensaje(
            prompt=_prompt(_mnc(afirmacion, "afirmacion_ia"),
                           _mnc(fragmento, "fragmento")),
            instruccion_sistema=_SISTEMA,
            max_tokens=300,
            formato_json=True,
        )
    except Exception as exc:
        logger.warning("Entailment: fallo al consultar el juez (%s).", exc)
        return {"implica": None, "estado": "error", "confianza": None,
                "evidencia": "", "motivo": f"error del juez: {exc}"}

    datos = _parsear(crudo)
    if datos is None:
        return {"implica": None, "estado": "error", "confianza": None,
                "evidencia": "", "motivo": "el juez no devolvió JSON utilizable"}

    veredicto = str(datos.get("veredicto", "")).strip().upper()
    evidencia = str(datos.get("evidencia", "") or "")
    try:
        confianza = float(datos.get("confianza"))
    except (TypeError, ValueError):
        confianza = None

    # Ancla dura: si el juez dice IMPLICA/NO_IMPLICA pero su "evidencia" no
    # aparece de verdad en el fragmento, se degrada a INSUFICIENTE. Es la
    # mitigación que impide un «sí» inventado — el mismo principio que la
    # verificación literal de citas, aplicado ahora al juez.
    if veredicto in ("IMPLICA", "NO_IMPLICA"):
        if not _subcadena_laxa(evidencia, fragmento):
            return {"implica": None, "estado": "ok", "confianza": confianza,
                    "evidencia": "",
                    "motivo": ("el juez no ancló su veredicto a una cita real "
                               "del fragmento → tratado como INSUFICIENTE")}

    if veredicto == "IMPLICA":
        return {"implica": True, "estado": "ok", "confianza": confianza,
                "evidencia": evidencia.strip()[:200],
                "motivo": "el fragmento sostiene la afirmación"}
    if veredicto == "NO_IMPLICA":
        return {"implica": False, "estado": "ok", "confianza": confianza,
                "evidencia": evidencia.strip()[:200],
                "motivo": "el fragmento NO sostiene la afirmación (revisar antes de firmar)"}
    return {"implica": None, "estado": "ok", "confianza": confianza,
            "evidencia": "", "motivo": "fragmento insuficiente para decidir"}


def _parsear(texto: str) -> Optional[Dict[str, Any]]:
    """Extrae el JSON del juez. Reutiliza el parser robusto del motor si está a
    mano (tolera markdown fences y prosa alrededor); si no, json.loads directo."""
    if not texto:
        return None
    try:
        from modulos.motor_ia import _extraer_json
        datos = _extraer_json(texto)
        return datos if isinstance(datos, dict) else None
    except Exception:
        pass
    try:
        datos = json.loads(texto)
        return datos if isinstance(datos, dict) else None
    except Exception:
        return None


def _subcadena_laxa(aguja: str, pajar: str) -> bool:
    """¿`aguja` aparece en `pajar`, ignorando espacios y mayúsculas? Los
    extractores de PDF desordenan espacios, así que la comparación se normaliza
    igual que en `_verificar_citas`."""
    if not aguja or len(aguja.strip()) < 6:
        return False
    from modulos.validador_citas import normalizar_cita
    return normalizar_cita(aguja) in normalizar_cita(pajar)
