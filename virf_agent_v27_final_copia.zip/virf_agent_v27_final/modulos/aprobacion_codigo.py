"""
modulos/aprobacion_codigo.py  [SEG-07]
═════════════════════════════════════════════════════════════════════════════
La IA nunca ejecuta su propio código sin aprobación humana registrada.

· Un notebook/código generado por IA queda «pendiente de revisión humana».
· Una persona con permiso «aprobar» (rol revisor) lo aprueba por su HASH
  (POST /api/codigo/aprobar); la aprobación es una entrada del log de auditoría
  (SEG-12), encadenada: si el log se manipula, ninguna aprobación vale.
· Solo el código cuyo hash está aprobado puede ejecutarse, y se ejecuta en un
  SUBPROCESO aislado (`python -I`, carpeta temporal, entorno vacío de secretos,
  tiempo máximo). No hay exec/eval en el proceso del agente.

Para producción, lo recomendado sigue siendo ejecutar los controles desde el
repositorio corporativo con code review y firma, en un job de mínimo privilegio
(docs/DESPLIEGUE_DATABRICKS.md).
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

__all__ = ["hash_codigo", "aprobar", "aprobado", "ejecutar_aprobado",
           "CodigoNoAprobado", "ESTADO_PENDIENTE"]

ESTADO_PENDIENTE = "pendiente de revisión humana"
_ENV_PERMITIDO = ("PATH", "SYSTEMROOT", "WINDIR", "TEMP", "TMP", "HOME", "USERPROFILE",
                  "LANG", "PYTHONIOENCODING")


class CodigoNoAprobado(PermissionError):
    pass


def hash_codigo(codigo: str) -> str:
    return hashlib.sha256((codigo or "").encode("utf-8")).hexdigest()


def aprobar(hash_hex: str, quien: str, oid: str, motivo: str = "") -> Dict:
    """Registra la aprobación (la llama el endpoint, que ya comprobó el rol)."""
    if len(hash_hex or "") != 64 or any(c not in "0123456789abcdef" for c in hash_hex):
        raise ValueError("hash SHA-256 inválido")
    from modulos import auditoria
    return auditoria.registrar("aprobacion_codigo", hash_hex, quien=quien, oid=oid,
                               motivo=motivo[:300])


def aprobado(hash_hex: str) -> bool:
    from modulos import auditoria
    if not auditoria.verificar()["ok"]:
        return False                              # log manipulado: nada vale
    return any(e.get("accion") == "aprobacion_codigo" and e.get("objeto") == hash_hex
               and e.get("resultado") == "ok" and e.get("oid")
               for e in auditoria.leer())


def ejecutar_aprobado(codigo: str, variables: Iterable[str] = (),
                      timeout_s: int = 120) -> Dict[str, Any]:
    """Ejecuta `codigo` SOLO si su hash está aprobado, en un subproceso aislado.
    Devuelve {"ok", "valores": {var: valor}, "mensaje"}."""
    h = hash_codigo(codigo)
    if not aprobado(h):
        raise CodigoNoAprobado(f"código {h[:12]}… {ESTADO_PENDIENTE}: necesita aprobación "
                               "registrada de un revisor antes de ejecutarse")
    vars_ = [v for v in variables if isinstance(v, str) and v.isidentifier()]
    pie = ("\n\nimport json as _j\n_out = {}\n"
           f"for _v in {vars_!r}:\n"
           "    if _v in globals():\n"
           "        _out[_v] = globals()[_v]\n"
           "print('<<<VIRF_SALIDA>>>' + _j.dumps(_out, default=str))\n")
    with tempfile.TemporaryDirectory(prefix="virf_sandbox_") as tmp:
        script = Path(tmp) / "notebook_aprobado.py"
        script.write_text(codigo + pie, encoding="utf-8")
        env = {k: os.environ[k] for k in _ENV_PERMITIDO if k in os.environ}
        try:
            r = subprocess.run([sys.executable, "-I", str(script)], cwd=tmp, env=env,
                               capture_output=True, text=True, encoding="utf-8",
                               errors="replace", timeout=timeout_s)
        except subprocess.TimeoutExpired:
            return {"ok": False, "valores": {}, "mensaje": f"tiempo agotado ({timeout_s}s)"}
    if r.returncode != 0:
        return {"ok": False, "valores": {}, "mensaje": (r.stderr or "").strip()[-300:]}
    marca = r.stdout.rfind("<<<VIRF_SALIDA>>>")
    valores = json.loads(r.stdout[marca + len("<<<VIRF_SALIDA>>>"):]) if marca >= 0 else {}
    return {"ok": True, "valores": valores, "mensaje": "OK"}
