"""
document_cache.py
=================
Sistema de memoria de documentos para modo pre-producción (MODO_PREPRDC).

Propósito
---------
En cada corrida del agente, leer y parsear PDFs, DOCXs y scripts consume tiempo
y en el caso de documentos grandes (PDFs de 50+ páginas) puede tomar varios
segundos por archivo. Si los documentos no cambiaron entre corridas, ese trabajo
es innecesario.

Este módulo implementa un caché persistente en disco:
  - Clave única por archivo: hash SHA-256 del contenido binario.
  - Si el archivo no cambió (mismo hash), se sirve el texto parseado del caché.
  - Si cambió o es nuevo, se parsea normalmente y se actualiza el caché.
  - El caché es exclusivo del modo PREPRDC; en producción se ignora para
    garantizar frescura de datos.

Estructura del caché en disco
------------------------------
  cache/
  ├── document_cache.json     ← índice principal (una entrada por archivo)
  └── .gitkeep

Formato de cada entrada en el JSON:
  {
    "/ruta/absoluta/del/archivo.docx": {
      "hash_sha256":     "abc123...",   ← hash del archivo binario
      "timestamp_fs":    1715000000.0,  ← mtime al momento de cachear
      "timestamp_cache": "2026-05-09T...",
      "nombre":          "archivo.docx",
      "tipo":            "DOCX",
      "contenido":       "texto extraído...",
      "chars_totales":   18400,
      "truncado":        false,
      "hits":            7,             ← cuántas veces se sirvió del caché
      "ultimo_hit":      "2026-05-09T..."
    }
  }

API pública
-----------
  get(path, extractor_fn, max_chars) → dict
  invalidar_archivo(path)
  purgar_huerfanos()
  estadisticas() → dict
  limpiar_todo()
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
import tempfile
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

logger = logging.getLogger("virf.cache")

# ─── Configuración por defecto ────────────────────────────────────────────────
_CACHE_FILENAME = "document_cache.json"
_ENCODING = "utf-8"
_LOCK_SUFFIX = ".lock"
# [CONFIG-CENTRAL v27.2] Desde config/parametros.py, no con os.getenv local.
from config.parametros import (
    CACHE_LOCK_STALE as _LOCK_STALE,       # segundos
    CACHE_LOCK_TIMEOUT as _LOCK_TIMEOUT,   # segundos
)


# ─── [CONCURRENCIA-FIX] Lock de archivo cross-platform ────────────────────────
@contextmanager
def _lock_archivo(destino: Path, timeout: float = _LOCK_TIMEOUT):
    """
    Lock cooperativo entre procesos basado en creación atómica de un fichero.

    Por qué existe:
        Dos ejecuciones simultáneas de `agente.py` sobre el mismo proyecto
        escribían el JSON de caché a la vez. Sin lock, la última en escribir
        pisaba a la otra y, si una se interrumpía a media escritura, el JSON
        quedaba corrupto y el caché entero se perdía en el siguiente arranque.

    Implementación:
        `os.open(..., O_CREAT | O_EXCL)` es atómico tanto en Windows como en
        POSIX, por lo que no requiere fcntl ni msvcrt (que difieren por SO).
        Se limpian locks huérfanos de procesos muertos (> _LOCK_STALE seg).

    Degradación:
        Si no se consigue el lock en `timeout`, se continúa igualmente con un
        WARNING: es preferible una escritura sin lock (protegida además por
        escritura atómica) que bloquear el pipeline de validación.
    """
    lock_path = destino.with_suffix(destino.suffix + _LOCK_SUFFIX)
    adquirido = False
    t0 = time.monotonic()

    # El directorio debe existir ANTES de intentar crear el lock, o os.open
    # falla con ENOENT y caeríamos en la rama "sin lock" en la primera corrida.
    try:
        lock_path.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.warning("No se pudo preparar el directorio de caché (%s).", exc)

    while time.monotonic() - t0 < timeout:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
            adquirido = True
            break
        except FileExistsError:
            # ¿Lock huérfano de un proceso que murió?
            try:
                if time.time() - lock_path.stat().st_mtime > _LOCK_STALE:
                    logger.warning("Lock huérfano detectado, eliminando: %s", lock_path)
                    lock_path.unlink(missing_ok=True)
                    continue
            except OSError:
                pass
            time.sleep(0.02)
        except OSError as exc:
            # ENOENT u otro problema puntual: reintentar tras recrear el directorio
            try:
                lock_path.parent.mkdir(parents=True, exist_ok=True)
            except OSError:
                logger.warning("No se pudo crear lock (%s); se continúa sin él.", exc)
                break
            time.sleep(0.02)

    if not adquirido:
        logger.warning(
            "Timeout (%.1fs) esperando lock de caché. Se escribe sin lock "
            "(la escritura sigue siendo atómica).", timeout
        )

    try:
        yield adquirido
    finally:
        if adquirido:
            try:
                lock_path.unlink(missing_ok=True)
            except OSError:
                pass


def _leer_cache_cifrada(ruta: Path):
    """[SEG-06] Lee la caché cifrada. Un fichero en claro heredado se lee una vez
    (y se reescribe cifrado al guardar). Sin clave → CifradoNoDisponible."""
    from modulos.almacenamiento import MAGIA, descifrar
    blob = Path(ruta).read_bytes()
    if blob.startswith(MAGIA):
        return json.loads(descifrar(blob).decode(_ENCODING))
    return json.loads(blob.decode(_ENCODING))


def _escribir_cache_cifrada(destino: Path, data: dict) -> None:
    """[SEG-06] Escritura atómica del JSON CIFRADO. Nunca escribe en claro."""
    from modulos.almacenamiento import cifrar
    blob = cifrar(json.dumps(data, ensure_ascii=False).encode(_ENCODING))
    destino.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=str(destino.parent), prefix=destino.name + ".",
                                    suffix=".tmp")
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(blob)
            f.flush()
            os.fsync(f.fileno())
        os.replace(str(tmp_path), str(destino))
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise


def _escribir_json_atomico(destino: Path, data: dict) -> None:
    """
    [CONCURRENCIA-FIX] Escribe JSON de forma atómica: fichero temporal en el
    MISMO directorio + os.replace() (atómico en Windows y POSIX).

    Antes: `open(destino, "w")` truncaba el fichero de inmediato. Un Ctrl-C,
    un OOM o un corte de energía a mitad de `json.dump` dejaban un JSON
    truncado e ilegible → se perdía todo el caché acumulado.
    """
    destino.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=str(destino.parent), prefix=destino.name + ".", suffix=".tmp"
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding=_ENCODING) as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())      # garantiza persistencia física antes del swap
        os.replace(str(tmp_path), str(destino))   # ← swap atómico
    except Exception:
        tmp_path.unlink(missing_ok=True)
        raise

# Máximo tamaño de contenido a cachear por archivo (bytes del texto extraído).
# Archivos mayores a este límite se parsean siempre en fresco para no inflar
# el JSON de caché. Valor: 500 KB de texto (más que suficiente para cualquier doc).
_MAX_CONTENT_BYTES_CACHE = 500_000


# ─── Clase principal ──────────────────────────────────────────────────────────

class DocumentCache:
    """
    Caché persistente de documentos parseados.

    Uso típico
    ----------
        cache = DocumentCache(cache_dir="cache/", enabled=True)
        doc = cache.get(
            path=Path("inputs/doc.pdf"),
            extractor_fn=lambda p: _leer_pdf(p),
            max_chars=8000,
        )
        # doc == {"nombre": ..., "tipo": ..., "contenido": ..., ...}
    """

    def __init__(self, cache_dir: str | Path, enabled: bool = True):
        self.enabled   = enabled
        self.cache_dir = Path(cache_dir)
        self._filepath  = self.cache_dir / _CACHE_FILENAME
        self._data: dict = {}          # ruta_str → entrada
        # [AUDIT-FIX] Bajas explícitas de esta sesión. Sin esto, el merge de
        # `persistir()` releía el disco y resucitaba lo borrado.
        self._eliminadas: set = set()
        self._dirty = False            # ¿hay cambios sin persistir?

        # Contadores de sesión (se reinician en cada instancia/corrida)
        self._hits   = 0
        self._misses = 0
        self._errors = 0

        if self.enabled:
            self._cargar()

    # ── Interfaz pública ──────────────────────────────────────────────────────

    def get(
        self,
        path: Path,
        extractor_fn: Callable[[Path], Optional[str]],
        max_chars: Optional[int],
    ) -> Optional[dict]:
        """
        Devuelve el dict parseado para *path*.

        1. Si el caché está deshabilitado → extrae en fresco.
        2. Si hay entrada válida (mismo hash SHA-256) → devuelve del caché.
        3. Si no hay entrada o el hash cambió → extrae, guarda, devuelve.

        Parámetros
        ----------
        path:         ruta al archivo a leer.
        extractor_fn: función que recibe Path y retorna str con el texto.
        max_chars:    límite de caracteres a guardar en contenido.
                      None = sin tope (el chunker cubrirá el documento).

        Retorna
        -------
        dict con claves: nombre, tipo, contenido, chars_totales, truncado
        o None si el archivo no pudo leerse y no hay entrada en caché.
        """
        if not self.enabled:
            return self._extraer_fresco(path, extractor_fn, max_chars)

        ruta_str = str(path.resolve())

        # 1. Calcular hash del archivo actual
        hash_actual = self._hash_archivo(path)
        if hash_actual is None:
            # Archivo no legible → devolver del caché si existe, si no None
            if ruta_str in self._data:
                logger.warning(
                    "⚠ Cache: %s no legible, sirviendo versión cacheada.", path.name
                )
                entrada = self._data[ruta_str]
                self._registrar_hit(ruta_str)
                return self._entrada_a_doc(entrada)
            return None

        # 2. Buscar en caché
        if ruta_str in self._data:
            entrada = self._data[ruta_str]
            if entrada.get("hash_sha256") == hash_actual:
                # ✅ Cache HIT
                self._registrar_hit(ruta_str)
                self._hits += 1
                logger.debug("✅ Cache HIT: %s", path.name)
                return self._entrada_a_doc(entrada)

        # 3. Cache MISS o hash cambiado → extraer fresco
        logger.debug("🔄 Cache MISS: %s (extraer fresco)", path.name)
        self._misses += 1
        doc = self._extraer_fresco(path, extractor_fn, max_chars)
        if doc is not None:
            self._guardar_entrada(ruta_str, hash_actual, path, doc)
        return doc

    def invalidar_archivo(self, path: Path) -> bool:
        """Elimina la entrada de un archivo del caché. Retorna True si existía."""
        ruta_str = str(path.resolve())
        if ruta_str in self._data:
            del self._data[ruta_str]
            self._eliminadas.add(ruta_str)
            self._dirty = True
            logger.info("🗑 Cache: entrada eliminada para %s", path.name)
            return True
        return False

    def purgar_huerfanos(self) -> int:
        """
        Elimina entradas del caché cuyos archivos ya no existen en disco.
        Retorna el número de entradas eliminadas.
        """
        huerfanos = [k for k in self._data if not Path(k).exists()]
        for k in huerfanos:
            del self._data[k]
            self._eliminadas.add(k)
        if huerfanos:
            self._dirty = True
            logger.info("🧹 Cache: %d entradas huérfanas eliminadas.", len(huerfanos))
        return len(huerfanos)

    def persistir(self) -> None:
        """
        Guarda el caché en disco si hubo cambios.

        [CONCURRENCIA-FIX] Tres garantías nuevas:
          1. LOCK entre procesos → dos `agente.py` simultáneos no se pisan.
          2. MERGE con el disco  → si otro proceso añadió entradas mientras
             corríamos, se conservan en vez de sobrescribirlas.
          3. ESCRITURA ATÓMICA   → tmp + os.replace(); una interrupción nunca
             deja el JSON a medio escribir.
        """
        if not self.enabled or not self._dirty:
            return

        from modulos.almacenamiento import CifradoNoDisponible
        try:
            with _lock_archivo(self._filepath):
                # ── Merge: releer el disco por si otro proceso escribió ───────
                datos_finales = dict(self._data)
                try:
                    if self._filepath.exists():
                        en_disco = _leer_cache_cifrada(self._filepath)
                        if isinstance(en_disco, dict):
                            # Las entradas de esta sesión ganan; las ajenas se conservan.
                            fusionado = dict(en_disco)
                            fusionado.update(datos_finales)
                            datos_finales = fusionado
                except (json.JSONDecodeError, OSError, CifradoNoDisponible) as exc:
                    logger.warning(
                        "Caché en disco ilegible (%s). Se reescribe con los datos "
                        "de esta sesión.", exc
                    )

                # ── [AUDIT-FIX] Aplicar las BAJAS deliberadas ────────────────
                # El merge de arriba (añadido por el CONCURRENCIA-FIX) resucitaba
                # todo lo borrado: `limpiar_todo()` y `purgar_huerfanos()` eran
                # no-ops silenciosos. Peor que no borrar: informaban "16 entradas
                # eliminadas" mientras el fichero seguía intacto.
                #
                # Un borrado explícito de esta sesión debe ganarle a lo que haya
                # en disco — que es justo la entrada que se quiso eliminar. Las
                # entradas ajenas que NO se marcaron siguen conservándose, así
                # que la garantía anti-pisotón de procesos concurrentes se mantiene.
                for _k in self._eliminadas:
                    datos_finales.pop(_k, None)

                _escribir_cache_cifrada(self._filepath, datos_finales)
                self._data = datos_finales
                self._eliminadas.clear()

            self._dirty = False
            logger.debug("💾 Cache persistido: %d entradas.", len(self._data))
        except Exception as exc:
            logger.error("❌ Error al persistir caché: %s", exc)

    def estadisticas(self) -> dict:
        """Retorna estadísticas de la sesión actual y del caché acumulado."""
        total_entradas = len(self._data)
        hits_acumulados = sum(e.get("hits", 0) for e in self._data.values())
        archivos_por_tipo: dict = {}
        for e in self._data.values():
            t = e.get("tipo", "?")
            archivos_por_tipo[t] = archivos_por_tipo.get(t, 0) + 1
        return {
            "sesion": {
                "hits":      self._hits,
                "misses":    self._misses,
                "errores":   self._errors,
                "tasa_hit":  round(
                    self._hits / max(self._hits + self._misses, 1) * 100, 1
                ),
            },
            "acumulado": {
                "total_entradas":  total_entradas,
                "hits_historicos": hits_acumulados,
                "por_tipo":        archivos_por_tipo,
            },
            "archivo_cache": str(self._filepath),
        }

    def limpiar_todo(self) -> None:
        """Vacía completamente el caché (disco + memoria).

        [SEG-06] Vaciar no necesita descifrar lo que hay en disco: se escribe un
        caché vacío (cifrado) y, si este proceso no tiene clave de cifrado, se
        borra el fichero. Antes `--limpiar-cache` se caía justo en ese caso."""
        from modulos.almacenamiento import CifradoNoDisponible
        self._data.clear()
        self._eliminadas.clear()
        with _lock_archivo(self._filepath):
            try:
                _escribir_cache_cifrada(self._filepath, {})
            except CifradoNoDisponible:
                self._filepath.unlink(missing_ok=True)
        self._dirty = False
        logger.info("🧹 Cache limpiado completamente.")

    def resumen_sesion(self) -> str:
        """Retorna string legible con el resumen de caché de la sesión."""
        s = self.estadisticas()["sesion"]
        total = s["hits"] + s["misses"]
        if total == 0:
            return "  📦 Caché de documentos: no utilizado esta sesión."
        return (
            f"  📦 Caché de documentos:\n"
            f"     ✅ Servidos del caché : {s['hits']:3d} archivos\n"
            f"     🔄 Re-leídos del disco: {s['misses']:3d} archivos\n"
            f"     ⚡ Tasa de acierto    : {s['tasa_hit']}%\n"
            f"     💾 Total en caché     : {self.estadisticas()['acumulado']['total_entradas']} archivos"
        )

    # ── Métodos internos ──────────────────────────────────────────────────────

    def _cargar(self) -> None:
        """Carga el JSON de caché desde disco."""
        if not self._filepath.exists():
            self._data = {}
            return
        from modulos.almacenamiento import CifradoNoDisponible
        try:
            self._data = _leer_cache_cifrada(self._filepath)
            logger.debug(
                "📂 Cache cargado: %d entradas desde %s",
                len(self._data), self._filepath,
            )
        except CifradoNoDisponible as exc:
            # [SEG-06] Cifrada con otra clave (p. ej. la efímera de un arranque
            # anterior de web_prueba) o sin clave en este proceso: no se puede
            # leer, pero es solo caché → se recalcula en vez de tumbar la corrida.
            logger.warning(
                "⚠ Caché cifrada ilegible con la clave de este proceso (%s). "
                "Se inicia vacía y se recalcula.", exc
            )
            self._data = {}
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning(
                "⚠ Cache corrupto o ilegible (%s). Se inicia vacío.", exc
            )
            self._data = {}

    @staticmethod
    def _hash_archivo(path: Path) -> Optional[str]:
        """SHA-256 del contenido binario del archivo. None si no se puede leer."""
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except OSError:
            return None

    @staticmethod
    def _extraer_fresco(
        path: Path,
        extractor_fn: Callable[[Path], Optional[str]],
        max_chars: Optional[int],
    ) -> Optional[dict]:
        """
        Llama a extractor_fn y construye el dict de documento.

        `max_chars=None` significa SIN TOPE: se guarda el texto íntegro. Lo usa
        Mx_01 cuando el chunking está activo, porque es el ChunkerService —y no
        el lector— quien debe decidir cómo cubrir un documento largo. Sin esta
        opción, el caché servía 15.000 chars declarando `chars_totales` del
        documento entero y la cobertura real caía del 100% al 1.2%.
        """
        try:
            contenido = extractor_fn(path) or ""
            chars_totales = len(contenido)
            # `contenido[:None]` ya devuelve la cadena completa, pero
            # `chars_totales > None` es un TypeError: hay que distinguirlo.
            contenido_truncado = contenido if max_chars is None else contenido[:max_chars]
            return {
                "nombre":        path.name,
                "tipo":          path.suffix.lstrip(".").upper(),
                "contenido":     contenido_truncado,
                "chars_totales": chars_totales,
                "truncado":      False if max_chars is None else chars_totales > max_chars,
            }
        except Exception as exc:
            logger.error("❌ Error extrayendo %s: %s", path.name, exc)
            return None

    def _guardar_entrada(
        self,
        ruta_str: str,
        hash_sha256: str,
        path: Path,
        doc: dict,
    ) -> None:
        """Persiste una entrada nueva o actualizada en el índice."""
        # No cachear contenidos demasiado grandes
        if len(doc.get("contenido", "")) > _MAX_CONTENT_BYTES_CACHE:
            logger.debug(
                "⏭ Cache: %s omitido por tamaño (>%d KB)",
                path.name, _MAX_CONTENT_BYTES_CACHE // 1000,
            )
            return

        try:
            ts = path.stat().st_mtime
        except OSError:
            ts = 0.0

        entrada_existente = self._data.get(ruta_str, {})
        self._data[ruta_str] = {
            "hash_sha256":      hash_sha256,
            "timestamp_fs":     ts,
            "timestamp_cache":  datetime.now(timezone.utc).isoformat(),
            "nombre":           doc["nombre"],
            "tipo":             doc["tipo"],
            "contenido":        doc["contenido"],
            "chars_totales":    doc["chars_totales"],
            "truncado":         doc["truncado"],
            "hits":             entrada_existente.get("hits", 0),  # conservar hits previos
            "ultimo_hit":       entrada_existente.get("ultimo_hit", None),
        }
        self._dirty = True

    def _registrar_hit(self, ruta_str: str) -> None:
        """Incrementa el contador de hits de una entrada."""
        if ruta_str in self._data:
            self._data[ruta_str]["hits"] = self._data[ruta_str].get("hits", 0) + 1
            self._data[ruta_str]["ultimo_hit"] = datetime.now(timezone.utc).isoformat()
            self._dirty = True

    @staticmethod
    def _entrada_a_doc(entrada: dict) -> dict:
        """Convierte una entrada del índice al formato dict de documento."""
        return {
            "nombre":        entrada["nombre"],
            "tipo":          entrada["tipo"],
            "contenido":     entrada["contenido"],
            "chars_totales": entrada["chars_totales"],
            "truncado":      entrada["truncado"],
        }


# ─── Instancia global (singleton por proceso) ─────────────────────────────────

_instancia_global: Optional[DocumentCache] = None


def inicializar_cache(cache_dir: str | Path, enabled: bool = True) -> DocumentCache:
    """
    Inicializa (o reinicializa) la instancia global del caché.
    Llamar una vez al inicio del pipeline, antes de cualquier lectura.

    Parámetros
    ----------
    cache_dir: directorio donde se guarda document_cache.json
    enabled:   False = caché deshabilitado (modo producción)
    """
    global _instancia_global
    _instancia_global = DocumentCache(cache_dir=cache_dir, enabled=enabled)
    return _instancia_global


def get_cache() -> DocumentCache:
    """
    Retorna la instancia global. Si no fue inicializada, crea una deshabilitada
    para no romper el flujo si el caché no fue explícitamente activado.
    """
    global _instancia_global
    if _instancia_global is None:
        logger.warning(
            "⚠ DocumentCache: get_cache() llamado sin inicializar. "
            "Usando caché deshabilitado."
        )
        _instancia_global = DocumentCache(cache_dir="data/cache", enabled=False)
    return _instancia_global


_ya_cerrado = False


def cerrar_cache() -> None:
    """
    Persiste el caché e imprime el resumen de sesión.

    [AUDIT-FIX] Idempotente. Antes se llamaba solo desde el `finally` de
    agente.py, pero ese try/finally arranca DESPUÉS de los ocho `return`
    tempranos de main() (--explicar-modelo, --convertir-excel,
    --controles-a-notebook, --cache-stats, --listar-motores…). Resultado
    medido: una corrida de --explicar-modelo leía 5 documentos nuevos y
    persistía CERO — el caché se quedaba en 6 entradas y la siguiente corrida
    volvía a extraerlos (35 s en el PDF de 305 págs).

    Ahora agente.py lo registra además con atexit, que sí cubre los returns
    tempranos y los sys.exit(). El guardia evita que la doble llamada imprima
    el resumen de sesión dos veces.
    """
    global _instancia_global, _ya_cerrado
    if _ya_cerrado:
        return
    if _instancia_global is not None and _instancia_global.enabled:
        _ya_cerrado = True
        _instancia_global.persistir()
        print(_instancia_global.resumen_sesion())


def _reset_cierre_para_tests() -> None:
    """Permite que los tests ejerciten cerrar_cache() más de una vez."""
    global _ya_cerrado
    _ya_cerrado = False
