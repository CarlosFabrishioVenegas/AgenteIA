"""
modulos/automatizaciones.py
═══════════════════════════════════════════════════════════════════════════════
Cuadro de observaciones a partir de los Excels de AUTOMATIZACIÓN del producto.

Entrada: una carpeta con los libros de cada etapa, identificados por su
PREFIJO (convención explícita del equipo, no adivinación por contenido):

    00_Diagnostico.xlsx    diagnóstico del producto / población
    01_ControlDatos.xlsx   controles de calidad de los datos
    02_Modelamiento.xlsx   resultados del desarrollo / recalibración
    03_Impactos.xlsx       impacto cuantificado (OPCIONAL)

Salida: el cuadro de observaciones de validación, una fila por observación:

    Ámbito · Riesgo · Observación · Recomendación · Responsable / Fecha

Reglas de cada columna
----------------------
· Ámbito     Documentación | Control de datos | Metodología | Gobierno |
             Implementación | Usos y reportería.  Implementación se revisa
             SIEMPRE de forma explícita (consistencia entre etapas).
· Riesgo     Potencial/Bajo | Moderado | Crítico.  Si hay 03_Impactos y la
             observación se vincula a una de sus filas, el riesgo SALE DEL
             EXCEL (determinista). Sin 03_Impactos —o sin vínculo— el riesgo
             se estima y queda marcado como «estimado» en `riesgo_fuente`.
· Responsable/Fecha  según dónde se levanta la observación: «modelamiento»
             (desarrollo del modelo) o «seguimiento» (operación/monitoreo).
             La fecha es la de corte + el plazo del nivel de riesgo.

Dos modos, elegidos por el LLAMANTE (`usar_ia`), nunca por heurística:
· usar_ia=True   la IA configurada redacta las observaciones a partir de los
                 resultados (con VIRF PLUS, Claude y GPT las concilian).
· usar_ia=False  borrador determinista, coste cero: una observación por hoja
                 con controles fallidos, con redacción plantilla.
"""

from __future__ import annotations

from modulos.salida_ia import material_no_confiable as _mnc
import json
import re
import unicodedata
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from config.parametros import (
    CUADRO_PLAZO_BAJO,
    CUADRO_PLAZO_CRITICO,
    CUADRO_PLAZO_MODERADO,
    CUADRO_RESP_MODELAMIENTO,
    CUADRO_RESP_SEGUIMIENTO,
    IMPACTO_UMBRAL_CRITICO,
    IMPACTO_UMBRAL_MODERADO,
)

__all__ = [
    "ETAPAS", "AMBITOS", "NIVELES_RIESGO",
    "localizar_excels", "leer_libro", "leer_carpeta",
    "generar_cuadro", "exportar_excel", "asignar_responsable",
]

ETAPAS = {
    "00": "Diagnóstico",
    "01": "Control de datos",
    "02": "Modelamiento",
    "03": "Impactos",
}

AMBITOS = ("Documentación", "Control de datos", "Metodología", "Gobierno",
           "Implementación", "Usos y reportería")

NIVELES_RIESGO = ("Potencial/Bajo", "Moderado", "Crítico")
_ORDEN_RIESGO = {n: i for i, n in enumerate(NIVELES_RIESGO)}

ORIGENES = ("modelamiento", "seguimiento")

# Si la IA no clasifica el origen, se deduce del ámbito: lo que se corrige al
# desarrollar el modelo vs. lo que se corrige al operarlo y monitorearlo.
_ORIGEN_POR_AMBITO = {
    "Documentación": "modelamiento",
    "Control de datos": "modelamiento",
    "Metodología": "modelamiento",
    "Gobierno": "seguimiento",
    "Implementación": "seguimiento",
    "Usos y reportería": "seguimiento",
}

# Ámbito por defecto de cada etapa en el borrador determinista.
_AMBITO_POR_ETAPA = {
    "00": "Implementación",
    "01": "Control de datos",
    "02": "Metodología",
    "03": "Usos y reportería",
}

_MAX_FILAS_HALLAZGO = 60     # filas fallidas por hoja que viajan al prompt
_MAX_FILAS_MUESTRA = 300     # filas conformes guardadas por hoja (03 las usa todas)
_MAX_CHARS_PROMPT = 30_000


# ─── Normalización ──────────────────────────────────────────────────────────

def _plano(texto: Any) -> str:
    """minúsculas, sin tildes, espacios colapsados."""
    t = unicodedata.normalize("NFKD", str(texto or ""))
    t = "".join(c for c in t if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", t).strip().lower()


def normalizar_ambito(valor: Any) -> Optional[str]:
    v = _plano(valor)
    if not v:
        return None
    for amb in AMBITOS:
        if _plano(amb) == v:
            return amb
    if "document" in v:
        return "Documentación"
    if "dato" in v or "calidad" in v:
        return "Control de datos"
    if "metodolog" in v or "modelamiento" in v:
        return "Metodología"
    if "gobier" in v or "gobernanza" in v:
        return "Gobierno"
    if "implement" in v:
        return "Implementación"
    if "uso" in v or "report" in v:
        return "Usos y reportería"
    return None


def normalizar_riesgo(valor: Any) -> Optional[str]:
    """Texto o número de impacto → nivel del cuadro. None si no se reconoce."""
    if valor is None or valor == "":
        return None
    if isinstance(valor, (int, float)) and not isinstance(valor, bool):
        x = abs(float(valor))
        if x > 1:                      # 7 → 7 %
            x = x / 100.0
        if x >= IMPACTO_UMBRAL_CRITICO:
            return "Crítico"
        if x >= IMPACTO_UMBRAL_MODERADO:
            return "Moderado"
        return "Potencial/Bajo"
    v = _plano(valor)
    if any(k in v for k in ("critic", "alto", "severo", "grave", "rojo", "high")):
        return "Crítico"
    if any(k in v for k in ("moderad", "medio", "media", "amarill", "medium")):
        return "Moderado"
    if any(k in v for k in ("bajo", "baja", "potencial", "leve", "menor",
                            "verde", "low")):
        return "Potencial/Bajo"
    if re.fullmatch(r"-?\d+(?:[.,]\d+)?\s*%?", v):
        num = float(v.rstrip("%").strip().replace(",", "."))
        return normalizar_riesgo(num / 100.0 if "%" in v else num)
    return None


# ─── Lectura de los libros ──────────────────────────────────────────────────

_PREFIJO = re.compile(r"^(0[0-3])[\s_\-.]")
_EXT = {".xlsx", ".xlsm"}

_COLS_ESTADO = ("estado", "resultado", "status", "semaforo", "check",
                "validacion", "cumple", "flag", "conclusion", "alerta", "ok")
_COLS_DESCRIPCION = ("descripcion", "control", "prueba", "regla", "validacion",
                     "variable", "indicador", "metrica", "detalle", "concepto",
                     "nombre", "item")
_COLS_NIVEL = ("nivel", "riesgo", "criticidad", "severidad", "semaforo")
_COLS_IMPACTO = ("impacto", "riesgo", "severidad", "criticidad", "nivel",
                 "materialidad", "variacion")

_VALORES_FALLO = {
    "no cumple", "incumple", "incumplimiento", "ko", "nok", "no ok", "falla",
    "fallo", "fail", "failed", "error", "alerta", "alert", "rojo", "red",
    "observado", "observacion", "rechazado", "no pasa", "no conforme",
    "desviacion", "critico", "warning", "amarillo",
}
# «no»/«false»/0 solo cuentan como fallo en columnas tipo booleano.
_VALORES_FALLO_BOOL = {"no", "false", "falso", "0", "n"}
_COLS_BOOL = ("cumple", "ok", "pasa", "check", "flag", "valido")


@dataclass
class HojaLeida:
    nombre: str
    encabezados: list = field(default_factory=list)
    n_filas: int = 0
    columna_estado: Optional[str] = None
    columna_descripcion: Optional[str] = None
    columna_impacto: Optional[str] = None
    hallazgos: list = field(default_factory=list)     # filas fallidas
    muestra: list = field(default_factory=list)       # filas de muestra
    fila_encabezado: int = 1


@dataclass
class LibroLeido:
    codigo: str
    etapa: str
    archivo: str
    hojas: list = field(default_factory=list)
    error: Optional[str] = None

    @property
    def n_hallazgos(self) -> int:
        return sum(len(h.hallazgos) for h in self.hojas)


def localizar_excels(carpeta: Path) -> dict:
    """{'00': Path, ...} por prefijo de etapa. Ignora temporales de Excel (~$)."""
    encontrados: dict = {}
    carpeta = Path(carpeta)
    if not carpeta.is_dir():
        return encontrados
    for p in sorted(carpeta.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in _EXT or p.name.startswith("~$"):
            continue
        m = _PREFIJO.match(p.name)
        if m and m.group(1) not in encontrados:
            encontrados[m.group(1)] = p
    return encontrados


def _buscar_columna(encabezados: list, claves: tuple) -> Optional[str]:
    for clave in claves:
        for h in encabezados:
            if clave in _plano(h):
                return h
    return None


def _es_fallo(valor: Any, columna: str) -> bool:
    if valor is None or valor == "":
        return False
    if isinstance(valor, bool):
        return valor is False and any(c in _plano(columna) for c in _COLS_BOOL)
    v = _plano(valor)
    if v in _VALORES_FALLO or any(v.startswith(f) for f in ("no cumple", "incumpl", "falla")):
        return True
    if v in _VALORES_FALLO_BOOL and any(c in _plano(columna) for c in _COLS_BOOL):
        return True
    return False


def _celda(v: Any) -> Any:
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float):
        return round(v, 6)
    return v


def _leer_hoja(ws) -> Optional[HojaLeida]:
    filas = []
    for fila in ws.iter_rows(values_only=True):
        filas.append(list(fila))
        if len(filas) > 20_000:
            break
    if not filas:
        return None

    # Encabezado: primera fila (de las 15 primeras) con ≥2 textos no vacíos.
    idx_enc = None
    for i, fila in enumerate(filas[:15]):
        textos = [c for c in fila if isinstance(c, str) and c.strip()]
        if len(textos) >= 2:
            idx_enc = i
            break
    if idx_enc is None:
        return None

    enc = []
    for j, c in enumerate(filas[idx_enc]):
        nombre = str(c).strip() if c not in (None, "") else f"col_{j + 1}"
        while nombre in enc:
            nombre += "_"
        enc.append(nombre)

    h = HojaLeida(nombre=ws.title, encabezados=[e for e in enc if not e.startswith("col_")],
                  fila_encabezado=idx_enc + 1)
    h.columna_estado = _buscar_columna(enc, _COLS_ESTADO)
    h.columna_descripcion = _buscar_columna(
        [e for e in enc if e != h.columna_estado], _COLS_DESCRIPCION)
    h.columna_impacto = _buscar_columna(enc, _COLS_IMPACTO)

    for k, fila in enumerate(filas[idx_enc + 1:], start=idx_enc + 2):
        if all(c in (None, "") for c in fila):
            continue
        registro = {enc[j]: _celda(v) for j, v in enumerate(fila)
                    if j < len(enc) and v not in (None, "")}
        if not registro:
            continue
        registro["_fila"] = k
        h.n_filas += 1
        if h.columna_estado and _es_fallo(registro.get(h.columna_estado), h.columna_estado):
            if len(h.hallazgos) < _MAX_FILAS_HALLAZGO:
                h.hallazgos.append(registro)
        elif len(h.muestra) < _MAX_FILAS_MUESTRA:
            h.muestra.append(registro)
    return h


def leer_libro(ruta: Path, codigo: str) -> LibroLeido:
    from openpyxl import load_workbook

    libro = LibroLeido(codigo=codigo, etapa=ETAPAS.get(codigo, codigo),
                       archivo=Path(ruta).name)
    try:
        wb = load_workbook(ruta, data_only=True, read_only=True)
    except Exception as exc:
        libro.error = f"{type(exc).__name__}: {exc}"
        return libro
    try:
        for ws in wb.worksheets:
            h = _leer_hoja(ws)
            if h is not None and h.n_filas:
                libro.hojas.append(h)
    finally:
        wb.close()
    return libro


def leer_carpeta(carpeta: Path) -> dict:
    return {c: leer_libro(p, c) for c, p in sorted(localizar_excels(carpeta).items())}


# ─── Impactos (03) ──────────────────────────────────────────────────────────

def tabla_impactos(libro03: Optional[LibroLeido]) -> dict:
    """
    {ref: {nivel, valor, descripcion}} con ref = «Hoja!fila». Solo filas cuyo
    impacto se pudo traducir a un nivel del cuadro.
    """
    tabla: dict = {}
    if libro03 is None:
        return tabla
    for h in libro03.hojas:
        # Primero el nivel CUALITATIVO que haya fijado el equipo (Alto/Moderado…);
        # el número de impacto solo si no hay columna de nivel.
        cols = ([e for e in h.encabezados if any(k in _plano(e) for k in _COLS_NIVEL)]
                + [e for e in h.encabezados if any(k in _plano(e) for k in _COLS_IMPACTO)])
        if not cols:
            continue
        for reg in sorted(h.hallazgos + h.muestra, key=lambda r: r["_fila"]):
            nivel, col = None, None
            for col in cols:
                nivel = normalizar_riesgo(reg.get(col))
                if nivel:
                    break
            if nivel is None:
                continue
            ref = f"{h.nombre}!{reg['_fila']}"
            tabla[ref] = {
                "nivel": nivel,
                "valor": reg.get(col),
                "descripcion": str(reg.get(h.columna_descripcion, "") or "")[:200],
            }
    return tabla


def _resolver_ref(ref: Any, tabla: dict) -> Optional[str]:
    """Acepta «Hoja!12», «03_Impactos/Hoja!12» o «hoja ! 12»."""
    if not ref:
        return None
    r = str(ref).split("/")[-1].strip()
    if r in tabla:
        return r
    m = re.match(r"(.+?)\s*!\s*(?:fila\s*)?(\d+)$", r, re.IGNORECASE)
    if not m:
        return None
    hoja, fila = _plano(m.group(1)), m.group(2)
    for k in tabla:
        kh, kf = k.rsplit("!", 1)
        if _plano(kh) == hoja and kf == fila:
            return k
    return None


# ─── Responsable / fecha ────────────────────────────────────────────────────

def asignar_responsable(origen: str, riesgo: str,
                        fecha_base: Optional[date] = None) -> dict:
    origen = origen if origen in ORIGENES else "modelamiento"
    fecha_base = fecha_base or date.today()
    plazo = {"Crítico": CUADRO_PLAZO_CRITICO,
             "Moderado": CUADRO_PLAZO_MODERADO}.get(riesgo, CUADRO_PLAZO_BAJO)
    responsable = (CUADRO_RESP_SEGUIMIENTO if origen == "seguimiento"
                   else CUADRO_RESP_MODELAMIENTO)
    fecha = fecha_base + timedelta(days=plazo)
    return {"origen": origen, "responsable": responsable,
            "fecha_compromiso": fecha.strftime("%d/%m/%Y"), "plazo_dias": plazo,
            "responsable_fecha": f"{responsable} — {fecha.strftime('%d/%m/%Y')}"}


# ─── Prompt para la IA ──────────────────────────────────────────────────────

def _fmt_registro(reg: dict, max_chars: int = 400) -> str:
    partes = [f"{k}={v}" for k, v in reg.items() if k != "_fila"]
    return f"  fila {reg.get('_fila')}: " + "; ".join(partes)[:max_chars]


def resumen_libros(libros: dict, max_chars: int = _MAX_CHARS_PROMPT) -> str:
    bloques = []
    for codigo, lib in libros.items():
        cab = f"### {lib.archivo}  (etapa {codigo} · {lib.etapa})"
        if lib.error:
            bloques.append(f"{cab}\n  ⚠ No se pudo leer: {lib.error}")
            continue
        partes = [cab]
        for h in lib.hojas:
            partes.append(
                f"- Hoja «{h.nombre}»: {h.n_filas} filas · columnas: "
                f"{', '.join(map(str, h.encabezados[:25]))}"
                + (f" · columna de resultado: «{h.columna_estado}»" if h.columna_estado else "")
                + (f" · columna de impacto: «{h.columna_impacto}»" if h.columna_impacto else ""))
            if h.hallazgos:
                partes.append(f"  RESULTADOS NO CONFORMES ({len(h.hallazgos)}):")
                partes += [_fmt_registro(r) for r in h.hallazgos]
            if h.muestra:
                # Las filas conformes también cuentan: dan la población, los
                # umbrales y las cifras con las que se explica el producto.
                # 03_Impactos va entero: sus filas son las que el riesgo cita.
                tope = len(h.muestra) if codigo == "03" else (6 if h.hallazgos else 15)
                partes.append("  Filas conformes (contexto):" if h.hallazgos
                              else "  Muestra de filas:")
                partes += [_fmt_registro(r) for r in h.muestra[:tope]]
        bloques.append("\n".join(partes))
    texto = "\n\n".join(bloques)
    if len(texto) > max_chars:
        texto = texto[:max_chars] + "\n…[resumen truncado por tamaño]"
    return texto


_INSTRUCCION = """\
Eres un validador senior de modelos de riesgo (segunda línea). Recibes los
RESULTADOS de las automatizaciones de un producto/modelo, organizadas por etapa
(00 Diagnóstico, 01 Control de datos, 02 Modelamiento, 03 Impactos). Debes
emitir el CUADRO DE OBSERVACIONES de validación.

CÓMO REDACTAR (el wording es lo más importante del entregable):
· OBSERVACIÓN — en registro formal de informe de validación, tercera persona,
  en este orden: (1) qué hace el producto/modelo y qué pretende esa etapa de la
  automatización, para que un lector que no conoce el modelo lo entienda;
  (2) qué se verificó y qué resultado se obtuvo, con las cifras, variables,
  hojas y filas del Excel; (3) por qué importa: la consecuencia concreta para
  el modelo, sus estimaciones o sus usuarios. Sin adjetivos vagos («algunos»,
  «ciertos», «podría mejorarse») y sin especular más allá de la evidencia.
· RECOMENDACIÓN — acción concreta y verificable para LEVANTAR la observación:
  qué debe hacerse, sobre qué variable/proceso/documento, y con qué evidencia
  se dará por levantada («Para levantar la observación se deberá evidenciar…»).

ÁMBITOS (usa exactamente uno): Documentación, Control de datos, Metodología,
Gobierno, Implementación, Usos y reportería.
IMPLEMENTACIÓN es prioritaria: revisa SIEMPRE si la automatización replica lo
que el modelo dice hacer y si las etapas son consistentes entre sí (poblaciones
o conteos que cambian entre 00 y 01 sin explicación, parámetros del 02 que no
coinciden con los diagnosticados, impactos del 03 que no cuadran con 02).
Si no hay hallazgo de implementación con respaldo, no lo inventes.

RIESGO: Potencial/Bajo, Moderado o Crítico. Si la observación se relaciona con
una fila de 03_Impactos, indícala en "impacto_ref" como «Hoja!fila»: el riesgo
final se tomará de ese Excel. Si no hay vínculo, estima el riesgo por la
materialidad del hallazgo.

ORIGEN: "modelamiento" si se corrige en el desarrollo del modelo (datos de
desarrollo, metodología, documentación técnica); "seguimiento" si se corrige en
su operación o monitoreo (implementación productiva, gobierno, uso, reportes).

Agrupa filas del mismo problema en UNA observación. Cita la evidencia como
«archivo/Hoja!fila». Responde SOLO con este JSON:
{"observaciones": [{"ambito": "...", "titulo": "...", "observacion": "...",
  "recomendacion": "...", "riesgo_estimado": "Potencial/Bajo|Moderado|Crítico",
  "impacto_ref": "Hoja!fila o null", "origen": "modelamiento|seguimiento",
  "evidencia": ["archivo/Hoja!fila", "..."]}]}
"""


def construir_prompt(libros: dict, contexto_modelo: str = "") -> str:
    faltan = [f"{c}_{ETAPAS[c]}" for c in ETAPAS if c not in libros]
    partes = []
    if contexto_modelo:
        partes.append("CONTEXTO DEL PRODUCTO / MODELO:\n"
                      + _mnc(contexto_modelo.strip()[:4000], "contexto_modelo"))
    partes.append("RESULTADOS DE LAS AUTOMATIZACIONES:\n"
                  + _mnc(resumen_libros(libros), "excels_automatizacion"))
    if faltan:
        partes.append("ETAPAS SIN EXCEL: " + ", ".join(faltan)
                      + ". Si la ausencia es relevante (p. ej. falta el control de "
                        "datos), puede ser en sí una observación.")
    partes.append("Emite el cuadro en JSON.")
    return "\n\n".join(partes)


# ─── Construcción del cuadro ────────────────────────────────────────────────

def _json_laxo(texto: str) -> Any:
    from config.virf_plus import _json_laxo as _jl
    return _jl(texto)


def _cuadro_determinista(libros: dict) -> list:
    """Una observación por hoja con resultados no conformes. Coste cero."""
    obs = []
    for codigo, lib in libros.items():
        if codigo == "03":
            continue
        for h in lib.hojas:
            if not h.hallazgos:
                continue
            desc_col = h.columna_descripcion
            items = []
            for r in h.hallazgos[:8]:
                d = r.get(desc_col) if desc_col else None
                items.append(f"«{d}» (fila {r['_fila']}: {r.get(h.columna_estado)})"
                             if d else f"fila {r['_fila']} ({r.get(h.columna_estado)})")
            resto = len(h.hallazgos) - len(items)
            lista = "; ".join(items) + (f"; y {resto} más" if resto > 0 else "")
            n_tot = h.n_filas
            obs.append({
                "ambito": _AMBITO_POR_ETAPA.get(codigo, "Metodología"),
                "titulo": f"Resultados no conformes en {lib.etapa} — hoja «{h.nombre}»",
                "observacion": (
                    f"En la etapa de {lib.etapa.lower()} de la automatización del "
                    f"producto ({lib.archivo}, hoja «{h.nombre}»), {len(h.hallazgos)} de "
                    f"{n_tot} verificaciones registran un resultado no conforme en la "
                    f"columna «{h.columna_estado}»: {lista}. Mientras estos resultados "
                    f"no se expliquen o corrijan, las salidas de esta etapa no pueden "
                    f"considerarse confiables para las etapas siguientes del proceso."),
                "recomendacion": (
                    f"Analizar la causa de cada resultado no conforme de la hoja "
                    f"«{h.nombre}», corregirla en la automatización o justificar "
                    f"técnicamente su aceptación, y volver a ejecutar la etapa. Para "
                    f"levantar la observación se deberá evidenciar la nueva ejecución "
                    f"con todos los controles conformes o su justificación aprobada."),
                "riesgo_estimado": "Moderado" if len(h.hallazgos) > 1 else "Potencial/Bajo",
                "impacto_ref": None,
                "origen": None,
                "evidencia": [f"{lib.archivo}/{h.nombre}!{r['_fila']}"
                              for r in h.hallazgos[:8]],
                "borrador": True,
            })
    return obs


def _hojas_conocidas(libros: dict) -> set:
    return {(_plano(lib.archivo), _plano(h.nombre))
            for lib in libros.values() for h in lib.hojas} | {
            ("", _plano(h.nombre)) for lib in libros.values() for h in lib.hojas}


def _evidencia_verificada(evidencias: list, libros: dict) -> bool:
    """¿Cada cita apunta a un libro/hoja que realmente se leyó?"""
    if not evidencias:
        return False
    conocidas = _hojas_conocidas(libros)
    for ev in evidencias:
        m = re.match(r"(?:(.+?)/)?(.+?)!\s*\d+", str(ev).strip())
        if not m:
            return False
        archivo, hoja = _plano(m.group(1) or ""), _plano(m.group(2))
        if (archivo, hoja) not in conocidas and ("", hoja) not in conocidas:
            return False
    return True


def _normalizar(obs: dict, impactos: dict, hay_impactos: bool,
                libros: dict, fecha_base: date) -> dict:
    ambito = normalizar_ambito(obs.get("ambito")) or "Metodología"
    ref = _resolver_ref(obs.get("impacto_ref"), impactos)
    if ref:
        riesgo, fuente = impactos[ref]["nivel"], f"03_Impactos ({ref})"
    else:
        riesgo = normalizar_riesgo(obs.get("riesgo_estimado")) or "Moderado"
        fuente = ("estimado (sin vínculo a 03_Impactos)" if hay_impactos
                  else "estimado (no se aportó 03_Impactos)")
    origen = str(obs.get("origen") or "").strip().lower()
    if origen not in ORIGENES:
        origen = _ORIGEN_POR_AMBITO[ambito]
    evid = [str(e) for e in (obs.get("evidencia") or []) if e]
    fila = {
        "ambito": ambito,
        "riesgo": riesgo,
        "riesgo_fuente": fuente,
        "titulo": str(obs.get("titulo") or "").strip(),
        "observacion": str(obs.get("observacion") or "").strip(),
        "recomendacion": str(obs.get("recomendacion") or "").strip(),
        "evidencia": evid,
        "evidencia_verificada": _evidencia_verificada(evid, libros),
        "borrador": bool(obs.get("borrador")),
    }
    fila.update(asignar_responsable(origen, riesgo, fecha_base))
    return fila


def generar_cuadro(carpeta: Path, *, usar_ia: bool, cliente=None,
                   contexto_modelo: str = "",
                   fecha_base: Optional[date] = None) -> dict:
    """
    Lee los Excels de `carpeta` y devuelve el cuadro:
      {filas, libros, faltan, modo, proveedor, generado}
    """
    fecha_base = fecha_base or date.today()
    libros = leer_carpeta(Path(carpeta))
    if not libros:
        raise FileNotFoundError(
            f"No hay Excels de automatización en {carpeta}. Se esperan libros con "
            f"prefijo de etapa: 00_Diagnostico.xlsx, 01_ControlDatos.xlsx, "
            f"02_Modelamiento.xlsx y, opcional, 03_Impactos.xlsx.")
    impactos = tabla_impactos(libros.get("03"))
    hay_impactos = "03" in libros

    proveedor = "determinista"
    if usar_ia:
        if cliente is None:
            from config.ia import get_cliente_ia, virf_plus_activo
            cliente = get_cliente_ia()
            proveedor = "virf_plus" if virf_plus_activo() else type(cliente).__name__
        else:
            proveedor = type(cliente).__name__
        crudo = cliente.generar_mensaje(
            prompt=construir_prompt(libros, contexto_modelo),
            instruccion_sistema=_INSTRUCCION, max_tokens=8000, formato_json=True)
        datos = _json_laxo(crudo)
        if isinstance(datos, list):
            datos = {"observaciones": datos}
        if not isinstance(datos, dict) or not isinstance(datos.get("observaciones"), list):
            raise ValueError(
                "La IA no devolvió el JSON del cuadro ({\"observaciones\": [...]}). "
                f"Inicio de la respuesta: {str(crudo)[:300]!r}")
        brutas = [o for o in datos["observaciones"] if isinstance(o, dict)]
    else:
        brutas = _cuadro_determinista(libros)

    filas = [_normalizar(o, impactos, hay_impactos, libros, fecha_base) for o in brutas]
    filas = [f for f in filas if f["observacion"]]
    # Más grave primero; a igual riesgo, Implementación delante.
    filas.sort(key=lambda f: (-_ORDEN_RIESGO[f["riesgo"]],
                              0 if f["ambito"] == "Implementación" else 1,
                              AMBITOS.index(f["ambito"])))
    for i, f in enumerate(filas, start=1):
        f["n"] = i

    return {
        "filas": filas,
        "modo": "ia" if usar_ia else "determinista",
        "proveedor": proveedor,
        "generado": datetime.now().isoformat(timespec="seconds"),
        "fecha_base": fecha_base.isoformat(),
        "faltan": [f"{c}_{ETAPAS[c]}" for c in ETAPAS if c not in libros],
        "riesgo_desde_impactos": hay_impactos,
        "libros": {c: {"archivo": l.archivo, "etapa": l.etapa, "error": l.error,
                       "hojas": [{"nombre": h.nombre, "filas": h.n_filas,
                                  "no_conformes": len(h.hallazgos),
                                  "columna_estado": h.columna_estado,
                                  "columna_impacto": h.columna_impacto}
                                 for h in l.hojas]}
                   for c, l in libros.items()},
    }


# ─── Exportación ────────────────────────────────────────────────────────────

COLUMNAS_CUADRO = ("N°", "Ámbito", "Riesgo", "Observación", "Recomendación",
                   "Responsable / Fecha")
_COLOR_RIESGO = {"Crítico": "F5C6C0", "Moderado": "F6E3B4", "Potencial/Bajo": "D9EAD3"}


def exportar_excel(cuadro: dict, ruta: Path) -> Path:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Cuadro de observaciones"
    fino = Side(style="thin", color="A0A4AE")
    borde = Border(left=fino, right=fino, top=fino, bottom=fino)
    ws.append(COLUMNAS_CUADRO)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3864")
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = borde
    for f in cuadro["filas"]:
        obs = (f"{f['titulo']}\n\n" if f.get("titulo") else "") + f["observacion"]
        if f.get("evidencia"):
            obs += "\n\nEvidencia: " + "; ".join(f["evidencia"])
        riesgo = f["riesgo"] + ("" if f["riesgo_fuente"].startswith("03_") else "\n(estimado)")
        ws.append([f["n"], f["ambito"], riesgo, obs, f["recomendacion"],
                   f"{f['responsable']}\n{f['fecha_compromiso']}"])
        for c in ws[ws.max_row]:
            c.alignment = Alignment(vertical="top", wrap_text=True)
            c.border = borde
        ws.cell(ws.max_row, 3).fill = PatternFill(
            "solid", fgColor=_COLOR_RIESGO.get(f["riesgo"], "FFFFFF"))
    for col, ancho in zip("ABCDEF", (5, 18, 14, 80, 60, 28)):
        ws.column_dimensions[col].width = ancho
    ws.freeze_panes = "A2"

    meta = wb.create_sheet("Fuentes")
    meta.append(["Etapa", "Archivo", "Hoja", "Filas", "No conformes",
                 "Columna de resultado", "Columna de impacto"])
    for c in meta[1]:
        c.font = Font(bold=True)
    for cod, lib in cuadro["libros"].items():
        for h in lib["hojas"] or [{}]:
            meta.append([f"{cod} · {lib['etapa']}", lib["archivo"], h.get("nombre"),
                         h.get("filas"), h.get("no_conformes"),
                         h.get("columna_estado"), h.get("columna_impacto")])
    meta.append([])
    meta.append(["Modo", cuadro["modo"], "Proveedor", cuadro["proveedor"]])
    meta.append(["Etapas sin Excel", ", ".join(cuadro["faltan"]) or "—"])

    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    wb.save(ruta)
    return ruta


def guardar(cuadro: dict, carpeta_salida: Path, prefijo: str = "cuadro_observaciones") -> dict:
    """Escribe JSON + XLSX con sello de tiempo. Devuelve las rutas."""
    sello = datetime.now().strftime("%Y%m%d_%H%M%S")
    carpeta_salida = Path(carpeta_salida)
    carpeta_salida.mkdir(parents=True, exist_ok=True)
    rj = carpeta_salida / f"{prefijo}_{sello}.json"
    rx = carpeta_salida / f"{prefijo}_{sello}.xlsx"
    rj.write_text(json.dumps(cuadro, ensure_ascii=False, indent=2, default=str),
                  encoding="utf-8")
    exportar_excel(cuadro, rx)
    return {"json": rj, "xlsx": rx}
