"""
modulos/salida_ia.py
═════════════════════════════════════════════════════════════════════════════
Saneado de lo que sale hacia la IA (SEG-05). Módulo HOJA: solo depende de
`modulos.pii` y `modulos.inyeccion`, para que cualquier módulo pueda delimitar
su material no confiable sin crear ciclos de import con `config.ia`.

El gateway (`config/ia.py`) aplica `sanear_salida` a todo prompt; los llamantes
envuelven evidencia, código, VBA, Excels y respuestas previas con
`material_no_confiable`.
"""
from __future__ import annotations

import re as _re

from modulos.inyeccion import neutralizar
from modulos.pii import enmascarar

__all__ = ["MARCA_INI_MATERIAL", "MARCA_FIN_MATERIAL", "material_no_confiable",
           "sanear_salida"]

MARCA_INI_MATERIAL = "<<<MATERIAL_NO_CONFIABLE origen={origen}>>>"
MARCA_FIN_MATERIAL = "<<<FIN_MATERIAL_NO_CONFIABLE>>>"
_RE_BLOQUE_MATERIAL = _re.compile(
    r"(<<<MATERIAL_NO_CONFIABLE origen=[^>\n]*>>>\n)(.*?)(\n<<<FIN_MATERIAL_NO_CONFIABLE>>>)",
    _re.S)
_RE_MARCAS = _re.compile(r"<<<\s*/?\s*(?:FIN_)?MATERIAL_NO_CONFIABLE[^>]*>>>")


def material_no_confiable(texto, origen: str = "evidencia") -> str:
    """
    Delimita material que NO es instrucción del sistema (evidencia, código del
    modelo, VBA, notebooks, Excels, respuestas previas de la IA, mensajes del
    usuario) para que el gateway lo neutralice antes de salir.

    Se enmascara PII y se neutraliza aquí mismo (así el texto ya va limpio
    aunque el llamante lo reutilice), y se eliminan marcas falsificadas que el
    material traiga para «cerrar» el bloque antes de tiempo.
    """
    t = "" if texto is None else str(texto)
    t = _RE_MARCAS.sub("", t)
    t, _ = enmascarar(t)
    t, _ = neutralizar(t)
    origen = _re.sub(r"[^\w\-.]", "_", str(origen or "evidencia"))[:40]
    return f"{MARCA_INI_MATERIAL.format(origen=origen)}\n{t}\n{MARCA_FIN_MATERIAL}"


def sanear_salida(texto):
    """(a)+(b): PII en todo el texto; inyección solo dentro de los bloques."""
    if not isinstance(texto, str) or not texto:
        return texto, [], []
    texto, pii = enmascarar(texto)
    iny: list = []

    def _rep(m):
        limpio, h = neutralizar(m.group(2))
        iny.extend(h)
        return m.group(1) + limpio + m.group(3)

    texto = _RE_BLOQUE_MATERIAL.sub(_rep, texto)
    return texto, pii, iny
