"""
excel_a_notebook.py
═══════════════════════════════════════════════════════════════════════════════

INGENIERÍA INVERSA EXCEL → NOTEBOOK PYTHON

Objetivo:
    Dado una carpeta con libros de Excel (posiblemente con VBA y referencias
    cruzadas entre libros), producir un .ipynb ejecutable por libro que
    replique el proceso en Python, con secciones estándar:
        1. INPUTS               (carga de datos crudos)
        2. CALIDAD DE DATOS     (validaciones básicas sobre inputs)
        3. MOTOR DE TRATAMIENTO (fórmulas Excel traducidas a Python)
        4. OUTPUTS              (resultados)
        5. VBA (si existe)      (macros VBA traducidas a Python)
        Anexo A: dependencias cross-hoja detectadas
        Anexo B: tabla completa de fórmulas
        Anexo C: REVISIÓN MANUAL REQUERIDA (fórmulas peligrosas)
        Anexo D: RESULTADO DE AUTO-VALIDACIÓN (notebook vs Excel evaluado)

Capacidades:
    ✓ Sin techos en muestreo (configurables por env)
    ✓ Chunking por hoja para libros grandes
    ✓ Extracción de VBA con olevba
    ✓ Grafo topológico entre libros con refs externas [libro.xlsx]Hoja!A1
    ✓ Auto-validación notebook vs Excel evaluado (data_only + fallback formulas)
    ✓ Detector de fórmulas peligrosas (INDIRECT, OFFSET, arrays, LAMBDA...)
    ✓ Verificación de orden topológico de variables Python

Uso CLI:
    python agente.py --convertir-excel inputs/excel_procesos
"""

from __future__ import annotations

from modulos.salida_ia import material_no_confiable as _mnc
import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import nbformat as nbf
from openpyxl import load_workbook


# ─── Constantes configurables por env ─────────────────────────────────────────

EXTENSIONES_EXCEL = {".xlsx", ".xlsm"}
# [CONFIG-CENTRAL v27.2] Valores desde config/parametros.py (única fuente de
# verdad). Se conservan los nombres locales históricos como alias.
from config.parametros import (
    EXCEL_CHUNK_HOJA_UMBRAL as CHUNK_HOJA_THRESHOLD,
    EXCEL_MAX_CELDAS_MUESTRA as MAX_CELDAS_MUESTRA,
    EXCEL_MAX_FORMULAS_HOJA as MAX_FORMULAS_POR_HOJA,
    EXCEL_NB_TIMEOUT as NBCLIENT_TIMEOUT,
    EXCEL_VALIDACION_TOL as VALIDACION_TOLERANCIA,
)

# ─── Regex de detección ───────────────────────────────────────────────────────

_REF_CROSS_HOJA = re.compile(
    r"(?:'([^']+)'|([A-Za-z_][\w\.]*))!"
    r"\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?"
)
# Refs a libros externos: acepta '[libro.xlsx]Hoja'!X o [libro.xlsx]Hoja!X,
# donde X puede ser una celda (A1), rango (A1:B10), rango de columnas (A:B),
# rango de filas (1:10) o cualquier combinación.
_REF_LIBRO_EXTERNO = re.compile(
    r"(?:'\[([^\]]+\.(?:xlsx|xlsm|xls))\]([^'!]+)'"    # '[libro.xlsx]Hoja con espacios'
    r"|\[([^\]]+\.(?:xlsx|xlsm|xls))\]([A-Za-z_][\w]*))"  # [libro.xlsx]Hoja
    r"!(?:\$?[A-Z]+\$?\d*(?::\$?[A-Z]*\$?\d*)?)"       # !A1, !A:B, !A1:B10, !1:10
)

# Funciones Excel que consideramos "peligrosas" — el LLM puede traducir mal
FORMULAS_PELIGROSAS = {
    "INDIRECT":  "referencia dinámica por string; no seguible estáticamente",
    "OFFSET":    "referencia relativa dinámica; puede cambiar en runtime",
    "LAMBDA":    "función definida en la celda; fuera de alcance",
    "LET":       "asignación local; el LLM puede errar el scoping",
    "FILTER":    "array dinámico moderno",
    "UNIQUE":    "array dinámico moderno",
    "SORT":      "array dinámico moderno",
    "SORTBY":    "array dinámico moderno",
    "SEQUENCE":  "array dinámico moderno",
    "TEXTSPLIT": "array dinámico moderno",
    "CHOOSECOLS": "array dinámico moderno",
    "CHOOSEROWS": "array dinámico moderno",
    "TAKE":      "array dinámico moderno",
    "DROP":      "array dinámico moderno",
}
_PATRON_MATRIZ = re.compile(r"^\{=.+\}$")  # fórmula matricial CSE


# ═════════════════════════════════════════════════════════════════════════════
# 1. ANÁLISIS ESTÁTICO DEL LIBRO
# ═════════════════════════════════════════════════════════════════════════════

def analizar_libro(path: Path) -> Dict[str, Any]:
    """
    Recorre un libro y produce:
      - hojas, dimensiones, encabezados, muestra
      - todas las fórmulas por hoja (sin techo estricto, solo un tope de sanidad)
      - dependencias cross-hoja (dentro del libro)
      - referencias a libros externos
      - inventario de fórmulas peligrosas
      - valores cacheados por Excel (data_only=True) para auto-validación
    """
    wb_f = load_workbook(path, data_only=False)         # con fórmulas
    try:
        wb_v = load_workbook(path, data_only=True)      # con valores cacheados
    except Exception:
        wb_v = None

    resultado: Dict[str, Any] = {
        "archivo":                path.name,
        "ruta":                   str(path.resolve()),
        "hojas":                  wb_f.sheetnames,
        "por_hoja":               {},
        "dependencias_cross_hoja": [],
        "refs_libros_externos":   [],
        "formulas_peligrosas":    [],
        "valores_cacheados":      {},   # (hoja, celda) → valor Excel evaluado
        "rangos_con_nombre":      {},   # nombre → destino
        "tablas_estructuradas":   [],
        "tiene_vba":              path.suffix.lower() == ".xlsm",
    }

    # Rangos con nombre a nivel de workbook
    try:
        for nombre in wb_f.defined_names:
            dest = wb_f.defined_names[nombre].value if hasattr(wb_f.defined_names, "__getitem__") else None
            resultado["rangos_con_nombre"][nombre] = str(dest) if dest else ""
    except Exception:
        pass

    for hoja in wb_f.sheetnames:
        ws = wb_f[hoja]
        max_row, max_col = ws.max_row, ws.max_column

        # Encabezados (primera fila)
        encabezados = [
            str(ws.cell(1, c).value) if ws.cell(1, c).value is not None else ""
            for c in range(1, min(max_col, 30) + 1)
        ] if max_row >= 1 else []

        # Muestra ampliada de valores
        muestra: List[List[Any]] = []
        for r in range(1, min(max_row, 10) + 1):
            fila = [ws.cell(r, c).value for c in range(1, min(max_col, 15) + 1)]
            muestra.append(fila)

        # Fórmulas — sin techo pequeño, solo tope de sanidad
        formulas: List[Dict[str, Any]] = []
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and v.startswith("="):
                    formulas.append({"celda": cell.coordinate, "formula": v})
                    # dependencias cross-hoja
                    for m in _REF_CROSS_HOJA.finditer(v):
                        hoja_ref = m.group(1) or m.group(2)
                        if hoja_ref and hoja_ref != hoja and hoja_ref in wb_f.sheetnames:
                            resultado["dependencias_cross_hoja"].append({
                                "desde_hoja": hoja, "celda": cell.coordinate,
                                "hacia_hoja": hoja_ref, "formula": v,
                            })
                    # referencias a libros externos
                    for m in _REF_LIBRO_EXTERNO.finditer(v):
                        libro = m.group(1) or m.group(3)
                        hoja_ref = m.group(2) or m.group(4)
                        resultado["refs_libros_externos"].append({
                            "desde_hoja": hoja, "celda": cell.coordinate,
                            "hacia_libro": libro, "hacia_hoja": hoja_ref,
                            "formula": v,
                        })
                    # fórmulas peligrosas
                    v_upper = v.upper()
                    for fn, razon in FORMULAS_PELIGROSAS.items():
                        if re.search(rf"\b{fn}\s*\(", v_upper):
                            resultado["formulas_peligrosas"].append({
                                "hoja": hoja, "celda": cell.coordinate,
                                "funcion": fn, "razon": razon, "formula": v,
                            })
                    if _PATRON_MATRIZ.match(v):
                        resultado["formulas_peligrosas"].append({
                            "hoja": hoja, "celda": cell.coordinate,
                            "funcion": "ARRAY_CSE", "razon": "Fórmula matricial CSE {=...}",
                            "formula": v,
                        })
                    # tablas estructuradas Tabla[Columna]
                    for m in re.finditer(r"([A-Za-z_][\w]*)\[([^\]]+)\]", v):
                        if m.group(1) not in ("SUM", "IF", "COUNT"):
                            resultado["tablas_estructuradas"].append({
                                "hoja": hoja, "celda": cell.coordinate,
                                "tabla": m.group(1), "columna": m.group(2),
                            })
                if len(formulas) >= MAX_FORMULAS_POR_HOJA:
                    break
            if len(formulas) >= MAX_FORMULAS_POR_HOJA:
                break

        # Valores cacheados por Excel (para auto-validación)
        cacheados_hoja: Dict[str, Any] = {}
        if wb_v is not None:
            try:
                ws_v = wb_v[hoja]
                for f in formulas:
                    val = ws_v[f["celda"]].value
                    if val is not None:
                        cacheados_hoja[f["celda"]] = val
            except Exception:
                pass
        if cacheados_hoja:
            resultado["valores_cacheados"][hoja] = cacheados_hoja

        resultado["por_hoja"][hoja] = {
            "filas":       max_row,
            "columnas":    max_col,
            "encabezados": encabezados,
            "muestra_valores": muestra[:MAX_CELDAS_MUESTRA],
            "n_formulas":  len(formulas),
            "formulas":    formulas,
        }

    return resultado


# ═════════════════════════════════════════════════════════════════════════════
# 1b. ANÁLISIS LIGERO DE LIBROS EXTERNOS REFERENCIADOS
# ═════════════════════════════════════════════════════════════════════════════

def _slug_libro(nombre_archivo: str) -> str:
    """`parametros.xlsx` → `parametros`. Slug legal como variable Python."""
    stem = Path(nombre_archivo).stem
    return re.sub(r"[^a-zA-Z0-9_]", "_", stem).lower()


def _slug_hoja(nombre_hoja: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", nombre_hoja).lower()


def analizar_libro_externo_ligero(path: Path) -> Dict[str, Any]:
    """
    Análisis mínimo de un libro externo: solo hojas, encabezados y una muestra
    de 5 filas. Suficiente para que el LLM sepa cómo consultarlo sin inundar
    el prompt.
    """
    if not path.exists():
        return {"archivo": path.name, "existe": False}
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
    except Exception as e:
        return {"archivo": path.name, "existe": True, "error": str(e)}

    por_hoja = {}
    for hoja in wb.sheetnames:
        try:
            ws = wb[hoja]
            encabezados = []
            muestra = []
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i == 0:
                    encabezados = [str(c) if c is not None else "" for c in row[:20]]
                elif i <= 5:
                    muestra.append(list(row[:20]))
                else:
                    break
            por_hoja[hoja] = {
                "encabezados":       encabezados,
                "muestra":           muestra,
                "nombre_variable":   f"df_{_slug_libro(path.name)}_{_slug_hoja(hoja)}",
            }
        except Exception:
            continue
    wb.close()
    return {"archivo": path.name, "existe": True, "por_hoja": por_hoja}


def resolver_libros_externos(
    analisis: Dict[str, Any],
    carpeta_base: Path,
) -> Dict[str, Any]:
    """
    Para cada ref externa detectada, verifica si el libro está en la carpeta.
    Devuelve dict: {nombre_libro: {analisis_ligero, disponible: True/False}}.
    """
    libros_unicos = {r["hacia_libro"].lower() for r in analisis["refs_libros_externos"]}
    resuelto = {}
    for nombre in sorted(libros_unicos):
        # matching case-insensitive
        candidatos = [
            p for p in carpeta_base.iterdir()
            if p.suffix.lower() in EXTENSIONES_EXCEL and p.name.lower() == nombre
        ]
        if candidatos:
            ligero = analizar_libro_externo_ligero(candidatos[0])
            ligero["disponible"] = True
            ligero["ruta"] = str(candidatos[0].resolve())
            resuelto[nombre] = ligero
        else:
            resuelto[nombre] = {"archivo": nombre, "existe": False, "disponible": False}
    return resuelto


# ═════════════════════════════════════════════════════════════════════════════
# 2. EXTRACCIÓN DE VBA
# ═════════════════════════════════════════════════════════════════════════════

def extraer_vba(path: Path) -> Dict[str, Any]:
    """
    Extrae módulos VBA de un .xlsm con olevba.
    Retorna {"modulos": [{"nombre": ..., "codigo": ..., "handlers_evento": [...]}]}
    o {"modulos": []} si no hay VBA / falla la extracción.
    """
    if path.suffix.lower() != ".xlsm":
        return {"modulos": [], "sin_vba": True}

    try:
        from oletools.olevba import VBA_Parser
    except ImportError:
        return {"modulos": [], "error": "oletools no instalado"}

    try:
        vba = VBA_Parser(str(path))
    except Exception as e:
        return {"modulos": [], "error": f"error abriendo VBA: {e}"}

    if not vba.detect_vba_macros():
        vba.close()
        return {"modulos": [], "sin_macros": True}

    modulos = []
    try:
        for (_fname, _stream, vba_filename, vba_code) in vba.extract_macros():
            if not vba_code or not vba_code.strip():
                continue
            handlers = re.findall(
                r"(?:Private|Public)?\s*Sub\s+(Workbook_\w+|Worksheet_\w+|Auto_\w+)",
                vba_code, flags=re.IGNORECASE,
            )
            modulos.append({
                "nombre":         vba_filename,
                "codigo":         vba_code[:20000],
                "handlers_evento": list(set(handlers)),
                "n_lineas":       vba_code.count("\n"),
            })
    except Exception as e:
        vba.close()
        return {"modulos": modulos, "error": f"error extrayendo: {e}"}

    vba.close()
    return {"modulos": modulos}


# ═════════════════════════════════════════════════════════════════════════════
# 3. GRAFO DE DEPENDENCIAS ENTRE LIBROS (orden topológico)
# ═════════════════════════════════════════════════════════════════════════════

def construir_grafo_libros(carpeta: Path) -> List[Path]:
    """
    Escanea todos los .xlsx/.xlsm de la carpeta, detecta refs [otro.xlsx],
    y devuelve el orden topológico (los libros sin dependencias primero).
    Ciclos: warn y ordenar alfabéticamente los ciclos.
    """
    libros = sorted(
        p for p in carpeta.iterdir()
        if p.suffix.lower() in EXTENSIONES_EXCEL and not p.name.startswith("~$")
    )
    nombre_a_path = {p.name.lower(): p for p in libros}

    # Grafo: libro → set(libros de los que depende)
    grafo: Dict[str, Set[str]] = {p.name.lower(): set() for p in libros}
    for p in libros:
        try:
            wb = load_workbook(p, data_only=False, read_only=True)
        except Exception:
            continue
        for hoja in wb.sheetnames:
            try:
                ws = wb[hoja]
                for row in ws.iter_rows(values_only=True):
                    for v in row:
                        if isinstance(v, str) and v.startswith("="):
                            for m in _REF_LIBRO_EXTERNO.finditer(v):
                                libro_ref = (m.group(1) or m.group(3) or "").lower()
                                if libro_ref in nombre_a_path and libro_ref != p.name.lower():
                                    grafo[p.name.lower()].add(libro_ref)
            except Exception:
                continue
        wb.close()

    # Topológico Kahn
    orden: List[str] = []
    sin_entradas = [n for n, deps in grafo.items() if not deps]
    grafo_mut = {n: set(d) for n, d in grafo.items()}
    while sin_entradas:
        n = sin_entradas.pop(0)
        orden.append(n)
        for otro, deps in grafo_mut.items():
            if n in deps:
                deps.discard(n)
                if not deps and otro not in orden and otro not in sin_entradas:
                    sin_entradas.append(otro)

    # Restos (ciclos)
    restantes = [n for n in grafo_mut if n not in orden]
    if restantes:
        print(f"  ⚠️  Detectados ciclos entre libros: {restantes} — se procesan al final")
        orden.extend(sorted(restantes))

    return [nombre_a_path[n] for n in orden if n in nombre_a_path]


# ═════════════════════════════════════════════════════════════════════════════
# 4. PROMPT AMPLIADO Y LLAMADA AL LLM
# ═════════════════════════════════════════════════════════════════════════════

_PROMPT_TRADUCTOR = """Eres un ingeniero de datos experto en migrar procesos Excel a Python.

Se te entrega el análisis estático de UN libro de Excel. Debes producir un JSON
estricto (sin markdown, sin explicaciones fuera del JSON):

{{
  "resumen_proceso": "1-3 frases describiendo qué calcula el libro",
  "inputs": [
    {{"hoja": "...", "descripcion": "...", "columnas_clave": ["c1"],
      "codigo_carga": "df_x = pd.read_excel(RUTA_EXCEL, sheet_name='...')"}}
  ],
  "controles_calidad": [
    {{"nombre": "...", "hoja": "...", "columna": "...",
      "codigo_python": "assert df_x['col'].notna().all()"}}
  ],
  "motor_calculo": [
    {{"paso": 1, "descripcion": "...", "formula_excel": "...",
      "codigo_python": "var = ...",
      "variables_declaradas": ["var"],
      "variables_usadas": ["var_previo"]}}
  ],
  "outputs": [
    {{"nombre": "...", "hoja_original": "...", "celda_original": "B5",
      "variable_python": "consolidado_mercado",
      "codigo_python": "print('consolidado_mercado =', consolidado_mercado)"}}
  ]
}}

REGLAS DE TRADUCCIÓN:

Aritmética y funciones básicas:
- AVERAGE(rango)      → df['col'].mean()
- SUM(rango)          → df['col'].sum()
- COUNTA(rango)       → df['col'].notna().sum()
- COUNT(rango)        → df['col'].count()
- MAX/MIN(rango)      → df['col'].max()/.min()
- SQRT(x)             → np.sqrt(x)
- x^n                 → x ** n
- ROUND(x, n)         → round(x, n)

Lógica:
- IF(cond, a, b)      → np.where(cond, a, b)   (para series) o (a if cond else b)
- IFERROR(x, y)       → x if no explota, else y — usa try/except o pd.NA
- AND/OR              → & / |  (dentro de np.where)

Búsquedas (frecuentes en libros de negocio):
- VLOOKUP(k, tabla, col, FALSE)  → df_tabla.set_index(col_key).loc[k, col_target]
    o mejor con merge: df_left.merge(df_right, on='clave', how='left')
- VLOOKUP con TRUE (aprox)       → MARCAR COMO REVISION MANUAL
- INDEX(rango, fila, col)        → df.iloc[fila-1, col-1]
- INDEX/MATCH combinado          → df.set_index('col_key').loc[valor]
- XLOOKUP                        → merge o loc con manejo de defaults

Agregaciones condicionales:
- SUMIFS(sum, rng1, cri1, ...)    → df[cond1 & cond2]['sum'].sum()
- COUNTIFS(rng1, cri1, ...)       → ((df[c1]==v1) & (df[c2]==v2)).sum()
- AVERAGEIFS(...)                 → df[cond]['col'].mean()

Referencias:
- Hoja!A1 (celda escalar)         → df_hoja.iloc[0, 0]  (si header=None)
- Hoja!$A$45 en hoja con encabezados → cargar con header=None y usar iloc[44, 0]
- Rango con nombre 'MiRango'      → si te lo doy en rangos_con_nombre, resuélvelo;
                                      si no, MARCAR COMO REVISION MANUAL
- Tabla1[Columna]                 → df_tabla1['Columna'] (si tabla estructurada)

LIBROS EXTERNOS PRECARGADOS:
Si el bloque `libros_externos_resueltos` está presente en los datos, cada libro
externo ya está cargado ANTES de tu código como DataFrames con el nombre
`df_<libro_sin_extension>_<hoja>` (ambos en snake_case). Ejemplos:
  - `parametros.xlsx` hoja `tarifas`  → variable `df_parametros_tarifas`
  - `Data_2026.XLSX` hoja `Ventas Q1` → variable `df_data_2026_ventas_q1`

Cuando veas en las fórmulas Excel una ref como `'[parametros.xlsx]tarifas'!A:B`,
NO cargues el libro de nuevo. Usa directamente la variable precargada.

Ejemplo de VLOOKUP externo — VLOOKUP("Retail", '[parametros.xlsx]tarifas'!A:B, 2, FALSE):
  - Con lookup exacto (FALSE): `df_parametros_tarifas.set_index('segmento').loc['Retail', 'tasa']`
  - Como merge:               `df_op.merge(df_parametros_tarifas, on='segmento', how='left')`

Si `libros_externos_resueltos` marca un libro con `disponible: False`, NO
inventes cargas — marca ese paso como `# REVISION MANUAL: libro externo no encontrado`.

RESTRICCIONES:
- `controles_calidad` SOLO puede usar variables df_* (inputs). NO variables del motor.
- Los controles DEBEN ser triviales y verificables: notna, dtype, len>0, columnas
  existen. NUNCA inventes valores permitidos (ej: NO uses .isin(['Retail','SME'])
  a menos que esa lista esté LITERALMENTE en la muestra_valores del análisis).
  Si dudas, omite el control.
- `motor_calculo` DEBE estar ordenado topológicamente: si el paso N usa una
  variable, algún paso <N debe declararla. Rellena `variables_declaradas` y
  `variables_usadas` fielmente para que un verificador externo lo compruebe.
- `outputs.variable_python` debe existir en algún `variables_declaradas` previo.
- Para acceder a Hoja!A45 SIN encabezado propio, primero carga la hoja con
  `df_x_raw = pd.read_excel(RUTA_EXCEL, sheet_name='X', header=None)`
  y luego `factor = df_x_raw.iloc[44, 0]`.
- Si una fórmula usa INDIRECT, OFFSET, LAMBDA, LET, FILTER, UNIQUE, SORT o
  arrays matriciales {{=...}}, incluye igual el paso pero con `codigo_python`
  comentado: `# REVISION MANUAL: <razon>` y una implementación aproximada.

Datos del libro:
```json
{analisis_json}
```

Devuelve SOLO el JSON."""


def _consultar_llm_traduccion(analisis: Dict[str, Any]) -> Dict[str, Any]:
    """Pide al modelo la traducción. Fallback a plan mínimo si falla."""
    from config import get_cliente_ia

    # Compactar el análisis para el prompt (quitar valores_cacheados que no
    # sirven al traductor y ocuparían mucho contexto)
    analisis_prompt = {k: v for k, v in analisis.items() if k != "valores_cacheados"}

    prompt = _PROMPT_TRADUCTOR.format(
        analisis_json=_mnc(json.dumps(analisis_prompt, ensure_ascii=False, indent=2,
                                      default=str), "libro_excel")
    )
    try:
        cliente = get_cliente_ia()
        respuesta = cliente.generar_mensaje(prompt=prompt, max_tokens=8000)
    except Exception as e:
        return {"_fallback": True, "_error": str(e)}

    texto = respuesta.strip()
    if texto.startswith("```"):
        texto = re.sub(r"^```(?:json)?\n?", "", texto)
        texto = re.sub(r"\n?```$", "", texto)
    try:
        return json.loads(texto)
    except json.JSONDecodeError as e:
        return {"_fallback": True, "_error": f"JSON inválido: {e}", "_raw": texto[:1500]}


def _consultar_llm_vba(vba_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Pide al modelo la traducción de los módulos VBA a Python."""
    if not vba_data.get("modulos"):
        return []
    from config import get_cliente_ia

    prompt = (
        "Traduce el siguiente código VBA a Python (pandas/numpy). Devuelve un "
        "JSON: [{\"modulo\":\"...\",\"resumen\":\"...\",\"codigo_python\":\"...\","
        "\"advertencias\":[\"...\"]}, ...]. Los handlers de evento "
        "(Workbook_Open, Worksheet_Change) marca como 'no traducible directamente'.\n\n"
        "VBA:\n```vb\n"
        + _mnc("\n\n' ── módulo ─\n".join(
            f"' {m['nombre']}\n{m['codigo']}" for m in vba_data["modulos"]
        ), "vba")
        + "\n```\n\nDevuelve SOLO el JSON."
    )
    try:
        cliente = get_cliente_ia()
        respuesta = cliente.generar_mensaje(prompt=prompt, max_tokens=6000)
        texto = respuesta.strip()
        if texto.startswith("```"):
            texto = re.sub(r"^```(?:json)?\n?", "", texto)
            texto = re.sub(r"\n?```$", "", texto)
        return json.loads(texto)
    except Exception as e:
        return [{"modulo": "TODOS", "resumen": "traducción VBA falló", "codigo_python": "",
                 "advertencias": [f"error LLM: {e}"]}]


# ═════════════════════════════════════════════════════════════════════════════
# 5. VERIFICADOR DE ORDEN TOPOLÓGICO
# ═════════════════════════════════════════════════════════════════════════════

def verificar_orden_topologico(
    plan: Dict[str, Any],
    variables_precargadas: Optional[Set[str]] = None,
) -> List[str]:
    """
    Comprueba que en el motor_calculo cada paso solo use variables ya
    declaradas por pasos anteriores. Devuelve lista de errores (vacía = OK).
    `variables_precargadas` incluye las de libros externos precargados
    (df_<libro>_<hoja>) que existen ANTES del código del LLM.
    """
    errores = []
    declaradas: Set[str] = set(variables_precargadas or set())
    # Precargar las variables de inputs
    for entrada in plan.get("inputs", []):
        codigo = entrada.get("codigo_carga", "")
        for m in re.finditer(r"^\s*(\w+)\s*=", codigo, re.MULTILINE):
            declaradas.add(m.group(1))

    for paso in plan.get("motor_calculo", []):
        usadas = set(paso.get("variables_usadas", []))
        no_declaradas = usadas - declaradas - {"pd", "np", "RUTA_EXCEL", "Path"}
        if no_declaradas:
            errores.append(
                f"Paso {paso.get('paso')}: usa variables no declaradas: {no_declaradas}"
            )
        for v in paso.get("variables_declaradas", []):
            declaradas.add(v)

    for out in plan.get("outputs", []):
        v = out.get("variable_python")
        if v and v not in declaradas:
            errores.append(f"Output '{out.get('nombre')}': variable '{v}' no declarada")

    return errores


# ═════════════════════════════════════════════════════════════════════════════
# 6. CONSTRUCCIÓN DEL NOTEBOOK
# ═════════════════════════════════════════════════════════════════════════════

def _md(t: str) -> nbf.NotebookNode: return nbf.v4.new_markdown_cell(t)
def _code(c: str) -> nbf.NotebookNode: return nbf.v4.new_code_cell(c)


def construir_notebook(
    analisis: Dict[str, Any],
    plan: Dict[str, Any],
    vba_trad: List[Dict[str, Any]],
    ruta_excel: Path,
    errores_orden: List[str],
) -> nbf.NotebookNode:
    nb = nbf.v4.new_notebook()
    celdas: List[nbf.NotebookNode] = []

    # ── Aviso al inicio si hay errores estructurales ────────────────────────
    if errores_orden:
        celdas.append(_md(
            "> ## ⚠️ NOTEBOOK CON ADVERTENCIAS DE ORDEN\n\n"
            "> El verificador detectó problemas de orden topológico en el plan del LLM:\n\n"
            + "\n".join(f"> - {e}" for e in errores_orden)
            + "\n\n> **Revisar antes de usar como fuente de verdad.**"
        ))

    # ── Header ──────────────────────────────────────────────────────────────
    celdas.append(_md(
        f"# Réplica Python del proceso Excel\n\n"
        f"**Archivo origen:** `{ruta_excel.name}`  \n"
        f"**Generado:** {datetime.now():%Y-%m-%d %H:%M}  \n"
        f"**Hojas detectadas:** {', '.join(analisis['hojas'])}  \n"
        f"**VBA:** {'sí' if analisis['tiene_vba'] else 'no'}  \n"
        f"**Refs a libros externos:** {len(analisis['refs_libros_externos'])}  \n"
        f"**Fórmulas peligrosas detectadas:** {len(analisis['formulas_peligrosas'])}\n\n"
        f"---\n\n## Resumen del proceso\n\n"
        f"{plan.get('resumen_proceso', '(sin resumen)')}\n"
    ))

    # ── Imports ─────────────────────────────────────────────────────────────
    celdas.append(_md("## 0. Imports y configuración"))
    celdas.append(_code(
        "import pandas as pd\nimport numpy as np\nfrom pathlib import Path\n\n"
        f"RUTA_EXCEL = Path(r'{ruta_excel.resolve()}')\n"
        "assert RUTA_EXCEL.exists(), f'No existe: {RUTA_EXCEL}'"
    ))

    # ── 1. INPUTS ───────────────────────────────────────────────────────────
    celdas.append(_md("## 1. Inputs — carga de datos crudos"))

    # 1a. Precarga de libros externos referenciados (antes de los inputs del LLM)
    libros_ext = analisis.get("libros_externos_resueltos", {}) or {}
    disponibles = {n: d for n, d in libros_ext.items() if d.get("disponible")}
    no_disp     = {n: d for n, d in libros_ext.items() if not d.get("disponible")}
    if disponibles:
        celdas.append(_md(
            "### 1.a Libros externos referenciados (precargados automáticamente)\n\n"
            "Estos libros están en la misma carpeta del origen y se cargan aquí "
            "para que las fórmulas cross-libro puedan resolverse:"
        ))
        for nombre, data in disponibles.items():
            ruta_ext = data.get("ruta", "")
            hojas_ext = list(data.get("por_hoja", {}).keys())
            celdas.append(_md(
                f"**`{nombre}`** — hojas: {hojas_ext}"
            ))
            codigo_carga = [f"RUTA_{_slug_libro(nombre).upper()} = Path(r'{ruta_ext}')"]
            for hoja, info in data.get("por_hoja", {}).items():
                var = info["nombre_variable"]
                codigo_carga.append(
                    f"{var} = pd.read_excel(RUTA_{_slug_libro(nombre).upper()}, "
                    f"sheet_name={hoja!r})"
                )
            celdas.append(_code("\n".join(codigo_carga)))
    if no_disp:
        celdas.append(_md(
            "### 1.b ⚠️ Libros externos NO encontrados\n\n"
            + "\n".join(f"- `{n}` — el proceso original lo referencia pero "
                        "no está en la carpeta. Los pasos que dependan de él "
                        "quedarán marcados en el motor."
                        for n in no_disp)
        ))

    # 1c. Inputs del propio libro (los que identificó el LLM)
    if plan.get("inputs"):
        for entrada in plan["inputs"]:
            hoja = entrada.get("hoja", "?")
            desc = entrada.get("descripcion", "")
            codigo = entrada.get("codigo_carga", "")
            celdas.append(_md(f"### Hoja `{hoja}`\n\n{desc}"))
            if codigo:
                celdas.append(_code(codigo))
    else:
        celdas.append(_md("_El LLM no identificó inputs del libro principal._"))

    # ── 2. CALIDAD DE DATOS ─────────────────────────────────────────────────
    celdas.append(_md("## 2. Calidad de datos (solo inputs crudos)"))
    if plan.get("controles_calidad"):
        for ctrl in plan["controles_calidad"]:
            celdas.append(_md(
                f"**{ctrl.get('nombre','control')}** — hoja `{ctrl.get('hoja','?')}` "
                f"col `{ctrl.get('columna','?')}`"
            ))
            celdas.append(_code(ctrl.get("codigo_python", "# TODO")))
    else:
        celdas.append(_md("_Sin controles propuestos._"))

    # ── 3. MOTOR DE TRATAMIENTO ─────────────────────────────────────────────
    celdas.append(_md("## 3. Motor de tratamiento"))
    for paso in plan.get("motor_calculo", []):
        f_xl = paso.get("formula_excel", "")
        md_txt = f"### Paso {paso.get('paso','?')} — {paso.get('descripcion','')}"
        if f_xl:
            md_txt += f"\n\n> Fórmula original Excel: `{f_xl}`"
        celdas.append(_md(md_txt))
        celdas.append(_code(paso.get("codigo_python", "# TODO")))

    # ── 4. OUTPUTS ──────────────────────────────────────────────────────────
    celdas.append(_md("## 4. Outputs — resultados"))
    for out in plan.get("outputs", []):
        celdas.append(_md(
            f"### `{out.get('nombre','?')}`\n\n"
            f"> Origen Excel: hoja **{out.get('hoja_original','?')}**, "
            f"celda **{out.get('celda_original','?')}**"
        ))
        celdas.append(_code(out.get("codigo_python", "# TODO")))

    # ── 5. VBA ──────────────────────────────────────────────────────────────
    if vba_trad:
        celdas.append(_md("## 5. VBA traducido a Python"))
        for mod in vba_trad:
            celdas.append(_md(
                f"### Módulo `{mod.get('modulo','?')}`\n\n"
                f"{mod.get('resumen','')}\n\n"
                + ("**Advertencias:**\n" + "\n".join(f"- {a}" for a in mod.get("advertencias", []))
                   if mod.get("advertencias") else "")
            ))
            if mod.get("codigo_python"):
                celdas.append(_code(mod["codigo_python"]))

    # ── Anexo A: dependencias cross-hoja ────────────────────────────────────
    if analisis["dependencias_cross_hoja"]:
        celdas.append(_md("## Anexo A — Dependencias cross-hoja"))
        lineas = [
            f"- `{d['desde_hoja']}!{d['celda']}` → `{d['hacia_hoja']}` — `{d['formula']}`"
            for d in analisis["dependencias_cross_hoja"][:100]
        ]
        if len(analisis["dependencias_cross_hoja"]) > 100:
            lineas.append(f"- _(...{len(analisis['dependencias_cross_hoja'])-100} más)_")
        celdas.append(_md("\n".join(lineas)))

    # ── Anexo B: todas las fórmulas ─────────────────────────────────────────
    tabla = ["## Anexo B — Todas las fórmulas del libro\n",
             "| Hoja | Celda | Fórmula |", "|------|-------|---------|"]
    total_f = 0
    for hoja, info in analisis["por_hoja"].items():
        for f in info["formulas"]:
            fmt = f["formula"].replace("|", r"\|")
            tabla.append(f"| {hoja} | {f['celda']} | `{fmt}` |")
            total_f += 1
    tabla.insert(1, f"_Total: {total_f} fórmulas_\n")
    celdas.append(_md("\n".join(tabla)))

    # ── Anexo C: REVISIÓN MANUAL REQUERIDA ──────────────────────────────────
    if analisis["formulas_peligrosas"] or analisis["refs_libros_externos"] \
            or analisis["tablas_estructuradas"]:
        celdas.append(_md("## Anexo C — ⚠️ REVISIÓN MANUAL REQUERIDA"))
        secciones = []
        if analisis["formulas_peligrosas"]:
            secciones.append(
                "### Fórmulas potencialmente no traducidas correctamente\n"
                + "\n".join(
                    f"- `{p['hoja']}!{p['celda']}` — **{p['funcion']}**: {p['razon']}  \n"
                    f"  fórmula: `{p['formula']}`"
                    for p in analisis["formulas_peligrosas"][:50]
                )
            )
        if analisis["refs_libros_externos"]:
            secciones.append(
                "### Referencias a libros externos\n"
                + "\n".join(
                    f"- `{r['desde_hoja']}!{r['celda']}` → `[{r['hacia_libro']}]{r['hacia_hoja']}`"
                    for r in analisis["refs_libros_externos"][:50]
                )
                + "\n\n_Los libros externos NO se cargaron automáticamente. Verificar que estén "
                  "disponibles en la misma carpeta y añadir su carga manualmente si es necesario._"
            )
        if analisis["tablas_estructuradas"]:
            secciones.append(
                "### Tablas estructuradas detectadas\n"
                + "\n".join(
                    f"- `{t['hoja']}!{t['celda']}` — tabla `{t['tabla']}[{t['columna']}]`"
                    for t in analisis["tablas_estructuradas"][:30]
                )
            )
        celdas.append(_md("\n\n".join(secciones)))

    if plan.get("_fallback"):
        celdas.append(_md(
            "> ## ⚠️ MODO FALLBACK\n\n"
            "> El LLM no estuvo disponible. Este notebook solo tiene estructura + "
            "fórmulas Excel sin traducir. Revisa cada celda manualmente."
        ))

    nb["cells"] = celdas
    nb["metadata"] = {
        "kernelspec":       {"name": "python3", "display_name": "Python 3"},
        "generado_por":     "virf_agent excel_a_notebook",
        "archivo_origen":   ruta_excel.name,
        "errores_orden":    errores_orden,
    }
    return nb


# ═════════════════════════════════════════════════════════════════════════════
# 7. AUTO-VALIDACIÓN NOTEBOOK vs EXCEL
# ═════════════════════════════════════════════════════════════════════════════

def _valores_esperados_excel(analisis: Dict[str, Any]) -> Dict[str, Any]:
    """
    Prefiere valores cacheados por Excel; si no hay, intenta evaluar con
    la librería `formulas` (Python puro).
    Retorna {(hoja, celda): valor}
    """
    esperados: Dict[Tuple[str, str], Any] = {}

    # 1) Cacheados por Excel
    for hoja, celdas in analisis.get("valores_cacheados", {}).items():
        for celda, val in celdas.items():
            esperados[(hoja, celda)] = val

    # 2) Si faltan fórmulas por evaluar, intentar con `formulas`
    total_formulas = sum(info["n_formulas"] for info in analisis["por_hoja"].values())
    if len(esperados) < total_formulas:
        try:
            import formulas as _f
            xl_model = _f.ExcelModel().loads(analisis["ruta"]).finish()
            resultados = xl_model.calculate()
            # Mapa case-insensitive de hoja: NOMBRE_MAYUS → nombre_real
            hojas_map = {h.upper(): h for h in analisis["hojas"]}
            # Claves en formato "'[archivo.xlsx]HOJA'!A1" o similar
            patron = re.compile(r"\[[^\]]+\]([^'!]+)'?!([A-Z]+\d+)")
            for k, v in resultados.items():
                m = patron.search(k)
                if not m:
                    continue
                hoja_bruta = m.group(1).strip().strip("'").upper()
                celda = m.group(2)
                hoja_real = hojas_map.get(hoja_bruta)
                if not hoja_real:
                    continue
                try:
                    val = v.value if hasattr(v, "value") else v
                    # 'formulas' devuelve matrices [[valor]] (list/tuple o ndarray)
                    import numpy as _np
                    while True:
                        if isinstance(val, (list, tuple)) and len(val) == 1:
                            val = val[0]
                        elif isinstance(val, _np.ndarray) and val.size == 1:
                            val = val.item()
                        elif isinstance(val, _np.ndarray) and val.shape and val.shape[0] == 1:
                            val = val[0]
                        else:
                            break
                    # Normalizar numpy scalars a Python nativos
                    if hasattr(val, "item") and not isinstance(val, str):
                        try:
                            val = val.item()
                        except Exception:
                            pass
                    if val is None:
                        continue
                    esperados.setdefault((hoja_real, celda), val)
                except Exception:
                    pass
        except Exception as _e:
            print(f"     ⚠️  librería 'formulas' no evaluó ({type(_e).__name__}: {str(_e)[:60]})")

    return esperados


def _codigo_notebook(nb: nbf.NotebookNode) -> str:
    return chr(10).join(c.source for c in nb.cells if c.cell_type == "code")


def _ejecutar_notebook(nb: nbf.NotebookNode, variables=()) -> Tuple[Optional[bool], Optional[Dict[str, Any]], str]:
    """
    [SEG-07] Ya NO se ejecuta automáticamente el notebook que redacta la IA.

    Antes: `exec(compile(codigo))` en el proceso del agente, sin sandbox, con
    acceso a disco, red y credenciales. Ahora:
      · si el hash del código NO tiene aprobación humana registrada → no se
        ejecuta y se devuelve (None, None, «pendiente de revisión humana»);
      · si la tiene → se ejecuta en un subproceso aislado
        (modulos/aprobacion_codigo.ejecutar_aprobado).
    Retorna (ok|None, valores, mensaje).
    """
    from modulos.aprobacion_codigo import (ESTADO_PENDIENTE, aprobado, ejecutar_aprobado,
                                           hash_codigo)
    codigo = _codigo_notebook(nb)
    h = hash_codigo(codigo)
    if not aprobado(h):
        return None, None, f"{ESTADO_PENDIENTE} (hash {h})"
    r = ejecutar_aprobado(codigo, variables)
    return r["ok"], (r["valores"] if r["ok"] else None), r["mensaje"]


def auto_validar(
    nb: nbf.NotebookNode,
    analisis: Dict[str, Any],
    plan: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Ejecuta el notebook, compara cada output declarado con el valor
    equivalente en Excel. Retorna reporte con match/no-match.
    """
    from modulos.aprobacion_codigo import ESTADO_PENDIENTE, hash_codigo
    reporte = {"ejecutable": False, "outputs": [], "mensaje": "",
               "hash_codigo": hash_codigo(_codigo_notebook(nb))}
    variables = [o.get("variable_python") for o in plan.get("outputs", [])]
    ok, ns, msg = _ejecutar_notebook(nb, variables)
    reporte["ejecutable"] = ok
    reporte["mensaje"] = msg
    if ok is None:
        reporte["estado"] = ESTADO_PENDIENTE
        return reporte
    if not ok:
        return reporte

    esperados = _valores_esperados_excel(analisis)
    for out in plan.get("outputs", []):
        var = out.get("variable_python")
        hoja = out.get("hoja_original")
        celda = out.get("celda_original")
        if not (var and var in ns and hoja and celda):
            continue
        actual = ns[var]
        esperado = esperados.get((hoja, celda))
        try:
            if esperado is None:
                match = None
                diff = None
            elif isinstance(actual, (int, float)) and isinstance(esperado, (int, float)):
                diff = float(actual) - float(esperado)
                match = abs(diff) <= max(VALIDACION_TOLERANCIA, abs(esperado) * VALIDACION_TOLERANCIA)
            else:
                match = str(actual) == str(esperado)
                diff = None
        except Exception:
            match = False; diff = None
        reporte["outputs"].append({
            "nombre":   out.get("nombre"),
            "variable": var,
            "hoja":     hoja,
            "celda":    celda,
            "python":   _serializable(actual),
            "excel":    _serializable(esperado),
            "diff":     diff,
            "match":    match,
        })

    n_match  = sum(1 for o in reporte["outputs"] if o["match"] is True)
    n_diff   = sum(1 for o in reporte["outputs"] if o["match"] is False)
    n_sinver = sum(1 for o in reporte["outputs"] if o["match"] is None)
    reporte["resumen"] = {
        "total": len(reporte["outputs"]),
        "match": n_match, "no_match": n_diff, "sin_verificar": n_sinver,
    }
    return reporte


def _serializable(v):
    try:
        json.dumps(v); return v
    except Exception:
        return str(v)[:100]


def inyectar_reporte_validacion(nb: nbf.NotebookNode, reporte: Dict[str, Any]) -> None:
    """Añade un anexo D con el reporte de auto-validación y una alerta arriba."""
    resumen = reporte.get("resumen", {})
    total = resumen.get("total", 0)
    match = resumen.get("match", 0)
    no_match = resumen.get("no_match", 0)

    if not reporte["ejecutable"]:
        alerta = _md(
            "> # 🔴 NOTEBOOK NO EJECUTABLE\n\n"
            f"> Falló al ejecutar: `{reporte['mensaje']}`\n\n"
            "> **NO usar como fuente de verdad. Revisar y corregir manualmente.**"
        )
    elif no_match > 0:
        alerta = _md(
            f"> # 🔴 NO USAR — {no_match}/{total} outputs NO coinciden con Excel\n\n"
            "> Ver Anexo D para el detalle de discrepancias."
        )
    elif match == total and total > 0:
        alerta = _md(
            f"> # ✅ VERIFICADO — {match}/{total} outputs coinciden con Excel\n\n"
            "> El notebook es fiel al proceso Excel dentro de tolerancia."
        )
    else:
        alerta = _md(
            f"> # ⚠️ VERIFICACIÓN PARCIAL — {match}/{total} coinciden, "
            f"{total - match - no_match} no verificables\n\n"
            "> Ver Anexo D para detalles."
        )

    # Anexo D
    tabla = ["## Anexo D — Auto-validación notebook vs Excel\n",
             f"**Ejecutable:** {reporte['ejecutable']}  \n"
             f"**Mensaje:** {reporte['mensaje']}  \n"
             f"**Tolerancia relativa:** {VALIDACION_TOLERANCIA}\n\n",
             "| Nombre | Var | Hoja!Celda | Python | Excel | Diff | Match |",
             "|--------|-----|------------|--------|-------|------|-------|"]
    for o in reporte.get("outputs", []):
        status = "✅" if o["match"] is True else ("❌" if o["match"] is False else "⚪")
        tabla.append(
            f"| {o['nombre']} | `{o['variable']}` | {o['hoja']}!{o['celda']} | "
            f"{o['python']} | {o['excel']} | {o['diff']} | {status} |"
        )
    anexo_d = _md("\n".join(tabla))

    nb["cells"].insert(0, alerta)
    nb["cells"].append(anexo_d)


# ═════════════════════════════════════════════════════════════════════════════
# 8. ORQUESTADOR
# ═════════════════════════════════════════════════════════════════════════════

def generar_notebook_de_archivo(
    ruta_excel: Path,
    carpeta_salida: Path,
    usar_llm: bool = True,
    auto_validar_out: bool = True,
) -> Tuple[Path, Dict[str, Any]]:
    print(f"\n  📖 Analizando {ruta_excel.name}...")
    analisis = analizar_libro(ruta_excel)
    n_form = sum(h["n_formulas"] for h in analisis["por_hoja"].values())
    print(f"     hojas={len(analisis['hojas'])}, fórmulas={n_form}, "
          f"deps cross-hoja={len(analisis['dependencias_cross_hoja'])}, "
          f"refs libros externos={len(analisis['refs_libros_externos'])}, "
          f"fórmulas peligrosas={len(analisis['formulas_peligrosas'])}")

    # Resolver libros externos en la misma carpeta
    analisis["libros_externos_resueltos"] = resolver_libros_externos(
        analisis, ruta_excel.parent,
    )
    disponibles = [n for n, d in analisis["libros_externos_resueltos"].items() if d.get("disponible")]
    no_encontrados = [n for n, d in analisis["libros_externos_resueltos"].items() if not d.get("disponible")]
    if disponibles:
        print(f"  🔗 Libros externos cargados: {disponibles}")
    if no_encontrados:
        print(f"  ⚠️  Libros externos NO encontrados: {no_encontrados}")

    vba_data = extraer_vba(ruta_excel)
    if vba_data.get("modulos"):
        print(f"  📄 VBA detectado: {len(vba_data['modulos'])} módulo(s)")

    plan: Dict[str, Any]
    vba_trad: List[Dict[str, Any]] = []
    if usar_llm:
        print("  🤖 Traduciendo fórmulas con LLM...")
        plan = _consultar_llm_traduccion(analisis)
        if plan.get("_fallback"):
            print(f"     ⚠️  LLM falló ({plan.get('_error','?')[:80]}), usando fallback mínimo")
            plan = _plan_fallback(analisis)
        if vba_data.get("modulos"):
            print("  🤖 Traduciendo VBA con LLM...")
            vba_trad = _consultar_llm_vba(vba_data)
    else:
        plan = _plan_fallback(analisis)

    # Verificación de orden topológico — incluye las variables precargadas
    # por libros externos (df_<libro>_<hoja>) para no marcarlas como no declaradas
    vars_precargadas: Set[str] = set()
    for _n, data in analisis.get("libros_externos_resueltos", {}).items():
        if data.get("disponible"):
            for _h, info in data.get("por_hoja", {}).items():
                vars_precargadas.add(info["nombre_variable"])
    errores_orden = verificar_orden_topologico(plan, variables_precargadas=vars_precargadas)
    if errores_orden:
        print(f"  ⚠️  Verificador topológico: {len(errores_orden)} error(es)")

    nb = construir_notebook(analisis, plan, vba_trad, ruta_excel, errores_orden)

    # Auto-validación
    reporte_val: Dict[str, Any] = {"ejecutable": False, "mensaje": "no ejecutado", "outputs": []}
    if auto_validar_out:
        print("  🧪 Auto-validando notebook vs Excel...")
        reporte_val = auto_validar(nb, analisis, plan)
        r = reporte_val.get("resumen", {})
        if reporte_val.get("estado"):
            print(f"     ⏸  {reporte_val['estado']}: un revisor debe aprobar el hash "
                  f"{reporte_val['hash_codigo'][:16]}… antes de ejecutarlo (SEG-07).")
        elif reporte_val["ejecutable"]:
            print(f"     ejecutable: SÍ  |  match: {r.get('match',0)}/{r.get('total',0)}  |  "
                  f"no match: {r.get('no_match',0)}  |  sin verificar: {r.get('sin_verificar',0)}")
        else:
            print(f"     ejecutable: NO  |  {reporte_val['mensaje'][:80]}")
        inyectar_reporte_validacion(nb, reporte_val)

    carpeta_salida.mkdir(parents=True, exist_ok=True)
    out_path = carpeta_salida / f"notebook_{ruta_excel.stem}.ipynb"
    with open(out_path, "w", encoding="utf-8") as f:
        nbf.write(nb, f)
    # Reporte JSON adyacente
    reporte_path = carpeta_salida / f"reporte_validacion_{ruta_excel.stem}.json"
    with open(reporte_path, "w", encoding="utf-8") as f:
        json.dump({
            "archivo":         ruta_excel.name,
            "generado":        datetime.now().isoformat(),
            "errores_orden":   errores_orden,
            "auto_validacion": reporte_val,
            "analisis_resumen": {
                "hojas":              len(analisis["hojas"]),
                "n_formulas":         n_form,
                "deps_cross_hoja":    len(analisis["dependencias_cross_hoja"]),
                "refs_libros_ext":    len(analisis["refs_libros_externos"]),
                "formulas_peligrosas": len(analisis["formulas_peligrosas"]),
                "tiene_vba":          analisis["tiene_vba"],
            },
        }, f, indent=2, ensure_ascii=False, default=str)
    print(f"  ✅ Notebook: {out_path.name}")
    print(f"  📋 Reporte: {reporte_path.name}")

    return out_path, reporte_val


def _plan_fallback(analisis: Dict[str, Any]) -> Dict[str, Any]:
    inputs = []
    for hoja, info in analisis["por_hoja"].items():
        if info["n_formulas"] == 0 and info["filas"] > 1:
            var = f"df_{re.sub(r'[^a-zA-Z0-9_]','_',hoja).lower()}"
            inputs.append({
                "hoja": hoja, "descripcion": f"Datos crudos de '{hoja}'",
                "columnas_clave": info["encabezados"][:5],
                "codigo_carga": f"{var} = pd.read_excel(RUTA_EXCEL, sheet_name={hoja!r})",
            })
    return {
        "resumen_proceso": "Fallback: LLM no disponible.",
        "inputs": inputs, "controles_calidad": [],
        "motor_calculo": [
            {"paso": i, "descripcion": f"TODO {f['celda']}",
             "formula_excel": f["formula"],
             "codigo_python": f"# TODO traducir: {f['formula']}",
             "variables_declaradas": [], "variables_usadas": []}
            for i, (hoja, info) in enumerate(analisis["por_hoja"].items(), 1)
            for f in info["formulas"]
        ],
        "outputs": [], "_fallback": True,
    }


def generar_notebook_de_carpeta(
    carpeta_excels: Path,
    carpeta_salida: Path,
    usar_llm: bool = True,
    auto_validar: bool = True,
) -> List[Path]:
    carpeta_excels = Path(carpeta_excels)
    if not carpeta_excels.exists():
        raise FileNotFoundError(f"Carpeta no encontrada: {carpeta_excels}")

    print(f"\n{'═' * 70}")
    print(f"  📊 EXCEL → NOTEBOOK")
    print(f"  Carpeta: {carpeta_excels}")
    print(f"  Salida:  {carpeta_salida}")
    print(f"{'═' * 70}")

    # Orden topológico entre libros (para procesar dependencias externas antes)
    print("\n  🔗 Construyendo grafo de dependencias entre libros...")
    libros = construir_grafo_libros(carpeta_excels)
    if not libros:
        print(f"  ⚠️  No hay archivos Excel en {carpeta_excels}")
        return []
    print(f"     orden de procesamiento: {[p.name for p in libros]}")

    generados = []
    todos_reportes = []
    for xl in libros:
        try:
            out, reporte = generar_notebook_de_archivo(
                xl, carpeta_salida,
                usar_llm=usar_llm, auto_validar_out=auto_validar,
            )
            generados.append(out)
            todos_reportes.append({"archivo": xl.name, "reporte": reporte})
        except Exception as e:
            print(f"  ❌ Error con {xl.name}: {e}")

    # Reporte consolidado
    print(f"\n{'═' * 70}")
    print(f"  ✅ {len(generados)}/{len(libros)} notebooks generados")
    if auto_validar:
        n_ok  = sum(1 for r in todos_reportes if r["reporte"].get("ejecutable")
                    and r["reporte"].get("resumen", {}).get("no_match", 0) == 0
                    and r["reporte"].get("resumen", {}).get("total", 0) > 0)
        n_fail = len(todos_reportes) - n_ok
        print(f"  🧪 Validación: {n_ok} verificados / {n_fail} requieren revisión")
    print(f"{'═' * 70}\n")

    return generados
