"""
motores_datos.py — Catálogo de pruebas de calidad de datos
═══════════════════════════════════════════════════════════════════════════════

QUÉ ES
    El "motor de data": el conjunto de pruebas automáticas que VIRF sabe
    ejecutar sobre un dataset para validar su calidad.

POR QUÉ EXISTE
    Antes solo había UNA prueba implementada ('unicidad') escrita a mano dentro
    de Mx_04, sin forma de saber qué pruebas existían ni de añadir nuevas sin
    tocar el orquestador. Este módulo:

      1. Centraliza TODAS las pruebas en un REGISTRO auto-descriptivo.
      2. Permite listar qué pruebas hay  →  `python -m modulos.motores_datos`
      3. Devuelve siempre el mismo contrato de salida, sea cual sea la prueba.
      4. Genera el código pandas equivalente de cada prueba, para poder
         volcarlo a un notebook reproducible.

CONTRATO DE SALIDA (idéntico para toda prueba)
    {
      "control_id":   str,
      "tipo_motor":   str,
      "estado":       "OK" | "ADVERTENCIA" | "ALERTA" | "ERROR",
      "n_total":      int,      # filas evaluadas
      "n_hallazgos":  int,      # filas/grupos que incumplen
      "tasa_error":   float,    # n_hallazgos / n_total  (0.0-1.0)
      "umbral":       float,
      "detalle":      str,      # resumen legible
      "muestra":      list,     # hasta 10 ejemplos del incumplimiento
      "codigo_pandas":str,      # equivalente reproducible de la prueba
      "error":        str|None,
    }

AÑADIR UNA PRUEBA NUEVA
    1. Escribe `def _motor_<nombre>(df, cfg) -> dict`
    2. Regístrala en REGISTRO_MOTORES con su metadata.
    Nada más: el orquestador la descubre sola.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

try:
    import pandas as pd
    import numpy as np
except ImportError:  # pragma: no cover
    pd = None
    np = None


# ═════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═════════════════════════════════════════════════════════════════════════════

def _cols(valor: Any) -> List[str]:
    """'Cuenta, FechaApertura' → ['Cuenta', 'FechaApertura']"""
    if valor is None:
        return []
    if isinstance(valor, (list, tuple)):
        return [str(c).strip() for c in valor if str(c).strip()]
    txt = str(valor).strip()
    if not txt or txt.lower() in ("nan", "none"):
        return []
    return [c.strip() for c in txt.split(",") if c.strip()]


def _estado_por_tasa(tasa: float, umbral: float, n_hallazgos: int = 0) -> str:
    """
    Traduce el resultado de una prueba a estado, RESPETANDO el umbral que el
    usuario configuró en ControlesData.xlsx.

    Interpretación del UMBRAL (columna del Excel):
      - umbral >= 1   → CONTEO absoluto de hallazgos tolerados.
                        Ej: UMBRAL=1 en unicidad = "tolero como máximo 1 grupo
                        con más de un valor".
      - 0 < umbral < 1→ PROPORCIÓN tolerada. Ej: 0.01 = hasta 1% de error.
      - umbral == 0   → tolerancia cero: cualquier hallazgo es incumplimiento.

    Escala de severidad relativa al umbral (no absoluta): lo que importa es
    CUÁNTO se excede lo tolerado, no la tasa bruta. Así un 9% de error en un
    control con UMBRAL=0.10 sale OK, y un 2% con UMBRAL=0 sale ALERTA.
    """
    if n_hallazgos <= 0 and tasa <= 0:
        return "OK"

    # Umbral como conteo absoluto
    if umbral is not None and umbral >= 1:
        if n_hallazgos <= umbral:
            return "OK"
        exceso = n_hallazgos / max(umbral, 1)
        if exceso <= 2:
            return "ADVERTENCIA"
        return "ALERTA" if exceso <= 10 else "ERROR"

    # Umbral como proporción
    umbral_prop = float(umbral or 0.0)
    if tasa <= umbral_prop:
        return "OK"
    if umbral_prop <= 0:
        # Tolerancia cero: severidad por magnitud del incumplimiento
        if tasa <= 0.005:
            return "ADVERTENCIA"
        return "ALERTA" if tasa <= 0.05 else "ERROR"

    exceso = tasa / umbral_prop
    if exceso <= 2:
        return "ADVERTENCIA"
    return "ALERTA" if exceso <= 10 else "ERROR"


def _base(control_id: str, tipo: str, umbral: float) -> Dict[str, Any]:
    return {
        "control_id": control_id, "tipo_motor": tipo,
        "estado": "OK", "n_total": 0, "n_hallazgos": 0,
        "tasa_error": 0.0, "umbral": umbral,
        "detalle": "", "muestra": [], "codigo_pandas": "", "error": None,
    }


def _falta(cfg: Dict[str, Any], *campos: str) -> Optional[str]:
    for c in campos:
        if not cfg.get(c):
            return f"Falta '{c.upper()}' en la configuración del control"
    return None


# ═════════════════════════════════════════════════════════════════════════════
# MOTORES
# ═════════════════════════════════════════════════════════════════════════════

def _motor_unicidad(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Un valor de CAMPO_OBJETIVO por cada combinación de GROUP_COLS."""
    r = _base(cfg["control_id"], "unicidad", cfg.get("umbral", 1.0))
    err = _falta(cfg, "group_cols", "campo_objetivo")
    if err:
        r.update(estado="ERROR", error=err); return r

    grupos, campo = _cols(cfg["group_cols"]), cfg["campo_objetivo"]
    faltan = [c for c in grupos + [campo] if c not in df.columns]
    if faltan:
        r.update(estado="ERROR", error=f"Columnas ausentes en el dataset: {faltan}")
        return r

    conteo = df.groupby(grupos, dropna=False)[campo].nunique()
    violan = conteo[conteo > 1]
    r["n_total"] = int(len(conteo))
    r["n_hallazgos"] = int(len(violan))
    r["tasa_error"] = round(len(violan) / len(conteo), 6) if len(conteo) else 0.0
    r["estado"] = _estado_por_tasa(r["tasa_error"], r["umbral"], r["n_hallazgos"])
    r["detalle"] = (
        f"{len(violan)} de {len(conteo)} grupos {grupos} tienen más de un "
        f"valor distinto de '{campo}'."
    )
    r["muestra"] = [
        {"grupo": str(k), "n_valores_distintos": int(v)}
        for k, v in violan.head(10).items()
    ]
    r["codigo_pandas"] = (
        f"conteo = df.groupby({grupos!r}, dropna=False)['{campo}'].nunique()\n"
        f"violaciones = conteo[conteo > 1]\n"
        f"print(f'{{len(violaciones)}} de {{len(conteo)}} grupos con '\n"
        f"      f'más de un valor de {campo}')"
    )
    return r


def _motor_duplicados(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Filas duplicadas según GROUP_COLS (o la fila completa si no se indica)."""
    r = _base(cfg["control_id"], "duplicados", cfg.get("umbral", 0.0))
    claves = _cols(cfg.get("group_cols")) or list(df.columns)
    faltan = [c for c in claves if c not in df.columns]
    if faltan:
        r.update(estado="ERROR", error=f"Columnas ausentes: {faltan}"); return r

    dup_mask = df.duplicated(subset=claves, keep=False)
    r["n_total"] = int(len(df))
    r["n_hallazgos"] = int(dup_mask.sum())
    r["tasa_error"] = round(dup_mask.sum() / len(df), 6) if len(df) else 0.0
    r["estado"] = _estado_por_tasa(r["tasa_error"], r["umbral"], r["n_hallazgos"])
    r["detalle"] = f"{int(dup_mask.sum())} filas duplicadas por {claves}."
    r["muestra"] = df[dup_mask].head(10).astype(str).to_dict("records")
    r["codigo_pandas"] = (
        f"dup = df.duplicated(subset={claves!r}, keep=False)\n"
        f"print(f'{{dup.sum()}} filas duplicadas de {{len(df)}}')\n"
        f"df[dup].head(10)"
    )
    return r


def _motor_missing(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Valores nulos en CAMPO_OBJETIVO (o en todo el dataset)."""
    r = _base(cfg["control_id"], "missing", cfg.get("umbral", 0.0))
    campos = _cols(cfg.get("campo_objetivo")) or list(df.columns)
    faltan = [c for c in campos if c not in df.columns]
    if faltan:
        r.update(estado="ERROR", error=f"Columnas ausentes: {faltan}"); return r

    total = len(df) * len(campos)
    n_nulos = int(df[campos].isna().sum().sum())
    r["n_total"] = total
    r["n_hallazgos"] = n_nulos
    r["tasa_error"] = round(n_nulos / total, 6) if total else 0.0
    r["estado"] = _estado_por_tasa(r["tasa_error"], r["umbral"], r["n_hallazgos"])
    por_col = df[campos].isna().sum()
    r["detalle"] = f"{n_nulos} valores nulos sobre {total} celdas evaluadas."
    r["muestra"] = [
        {"columna": c, "n_nulos": int(n), "pct": round(100 * n / len(df), 3)}
        for c, n in por_col[por_col > 0].head(10).items()
    ]
    r["codigo_pandas"] = (
        f"nulos = df[{campos!r}].isna().sum()\n"
        f"print(nulos[nulos > 0])\n"
        f"print(f'Tasa global: {{df[{campos!r}].isna().sum().sum() / (len(df)*{len(campos)}):.4%}}')"
    )
    return r


def _motor_outliers(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Outliers en CAMPO_OBJETIVO por IQR robusto (no Z-score).

    Se usa IQR y no Z-score deliberadamente: el Z-score asume normalidad y es
    sensible a los propios outliers — precisamente la crítica que VIRF hace en
    CUESTIONAMIENTOS_METODOLOGICOS['outliers_zscore'].
    """
    r = _base(cfg["control_id"], "outliers", cfg.get("umbral", 0.01))
    err = _falta(cfg, "campo_objetivo")
    if err:
        r.update(estado="ERROR", error=err); return r

    campo = cfg["campo_objetivo"]
    if campo not in df.columns:
        r.update(estado="ERROR", error=f"Columna ausente: {campo}"); return r

    serie = pd.to_numeric(df[campo], errors="coerce").dropna()
    if serie.empty:
        r.update(estado="ERROR", error=f"'{campo}' no tiene valores numéricos")
        return r

    q1, q3 = serie.quantile(0.25), serie.quantile(0.75)
    iqr = q3 - q1
    lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    fuera = serie[(serie < lo) | (serie > hi)]

    r["n_total"] = int(len(serie))
    r["n_hallazgos"] = int(len(fuera))
    r["tasa_error"] = round(len(fuera) / len(serie), 6) if len(serie) else 0.0
    r["estado"] = _estado_por_tasa(r["tasa_error"], r["umbral"], r["n_hallazgos"])
    r["detalle"] = (
        f"{len(fuera)} de {len(serie)} valores de '{campo}' fuera del rango IQR "
        f"[{lo:.4g}, {hi:.4g}]."
    )
    r["muestra"] = [{"valor": float(v)} for v in fuera.head(10)]
    r["codigo_pandas"] = (
        f"s = pd.to_numeric(df['{campo}'], errors='coerce').dropna()\n"
        f"q1, q3 = s.quantile(0.25), s.quantile(0.75); iqr = q3 - q1\n"
        f"lo, hi = q1 - 1.5*iqr, q3 + 1.5*iqr\n"
        f"fuera = s[(s < lo) | (s > hi)]\n"
        f"print(f'{{len(fuera)}} outliers IQR de {{len(s)}} — rango [{{lo:.4g}}, {{hi:.4g}}]')"
    )
    return r


def _motor_rango(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """CAMPO_OBJETIVO dentro de [MIN, MAX] declarados en la config."""
    r = _base(cfg["control_id"], "rango", cfg.get("umbral", 0.0))
    err = _falta(cfg, "campo_objetivo")
    if err:
        r.update(estado="ERROR", error=err); return r

    campo = cfg["campo_objetivo"]
    if campo not in df.columns:
        r.update(estado="ERROR", error=f"Columna ausente: {campo}"); return r

    vmin, vmax = cfg.get("min"), cfg.get("max")
    if vmin is None and vmax is None:
        r.update(estado="ERROR", error="Define MIN y/o MAX para el control de rango")
        return r

    serie = pd.to_numeric(df[campo], errors="coerce")
    cond = pd.Series(False, index=serie.index)
    if vmin is not None:
        cond |= serie < float(vmin)
    if vmax is not None:
        cond |= serie > float(vmax)
    cond &= serie.notna()

    r["n_total"] = int(serie.notna().sum())
    r["n_hallazgos"] = int(cond.sum())
    r["tasa_error"] = round(cond.sum() / max(r["n_total"], 1), 6)
    r["estado"] = _estado_por_tasa(r["tasa_error"], r["umbral"], r["n_hallazgos"])
    r["detalle"] = f"{int(cond.sum())} valores de '{campo}' fuera de [{vmin}, {vmax}]."
    r["muestra"] = [{"valor": str(v)} for v in serie[cond].head(10)]
    r["codigo_pandas"] = (
        f"s = pd.to_numeric(df['{campo}'], errors='coerce')\n"
        f"fuera = s[(s < {vmin}) | (s > {vmax})]\n"
        f"print(f'{{len(fuera)}} valores fuera de rango')"
    )
    return r


def _motor_integridad_referencial(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    CAMPO_OBJETIVO de este dataset debe existir en el dataset de referencia.
    Config extra: DATASET_REF, CAMPO_REF
    """
    r = _base(cfg["control_id"], "integridad_referencial", cfg.get("umbral", 0.0))
    err = _falta(cfg, "campo_objetivo")
    if err:
        r.update(estado="ERROR", error=err); return r

    df_ref = cfg.get("_df_ref")
    if df_ref is None:
        r.update(estado="ERROR",
                 error="No se cargó DATASET_REF para la integridad referencial")
        return r

    campo = cfg["campo_objetivo"]
    campo_ref = cfg.get("campo_ref") or campo
    if campo not in df.columns:
        r.update(estado="ERROR", error=f"Columna ausente: {campo}"); return r
    if campo_ref not in df_ref.columns:
        r.update(estado="ERROR", error=f"Columna ausente en referencia: {campo_ref}")
        return r

    validos = set(df_ref[campo_ref].dropna().astype(str))
    serie = df[campo].dropna().astype(str)
    huerfanos = serie[~serie.isin(validos)]

    r["n_total"] = int(len(serie))
    r["n_hallazgos"] = int(len(huerfanos))
    r["tasa_error"] = round(len(huerfanos) / len(serie), 6) if len(serie) else 0.0
    r["estado"] = _estado_por_tasa(r["tasa_error"], r["umbral"], r["n_hallazgos"])
    r["detalle"] = (
        f"{len(huerfanos)} de {len(serie)} valores de '{campo}' no existen en "
        f"la referencia '{campo_ref}'."
    )
    r["muestra"] = [{"valor_huerfano": v} for v in huerfanos.head(10)]
    r["codigo_pandas"] = (
        f"validos = set(df_ref['{campo_ref}'].dropna().astype(str))\n"
        f"s = df['{campo}'].dropna().astype(str)\n"
        f"huerfanos = s[~s.isin(validos)]\n"
        f"print(f'{{len(huerfanos)}} valores huérfanos')"
    )
    return r


def _motor_tipo_dato(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    CAMPO_OBJETIVO debe ser convertible al TIPO_ESPERADO (numerico|fecha|texto).

    Acepta VARIAS columnas separadas por coma: los documentos suelen enunciar
    el control en plural ("FechaApertura y FechaVencimiento deben ser fechas
    válidas") y el extractor las devuelve juntas.
    """
    r = _base(cfg["control_id"], "tipo_dato", cfg.get("umbral", 0.0))
    err = _falta(cfg, "campo_objetivo")
    if err:
        r.update(estado="ERROR", error=err); return r

    campos = _cols(cfg["campo_objetivo"])
    faltan = [c for c in campos if c not in df.columns]
    if faltan:
        r.update(estado="ERROR", error=f"Columnas ausentes: {faltan}"); return r

    esperado = str(cfg.get("tipo_esperado") or "numerico").lower()

    def _convertir(serie):
        if esperado in ("numerico", "numeric", "float", "int", "entero", "decimal"):
            return pd.to_numeric(serie, errors="coerce")
        if esperado in ("fecha", "date", "datetime", "timestamp"):
            return pd.to_datetime(serie, errors="coerce", format="mixed")
        return serie.astype(str)

    total = n_inv = 0
    muestra: List[Dict[str, Any]] = []
    por_columna: List[str] = []
    for campo in campos:
        serie = df[campo].dropna()
        if serie.empty:
            por_columna.append(f"{campo}: sin datos")
            continue
        try:
            conv = _convertir(serie)
        except Exception:
            conv = pd.Series([pd.NaT] * len(serie), index=serie.index)
        invalidos = conv.isna() & serie.notna()
        total += len(serie)
        n_inv += int(invalidos.sum())
        por_columna.append(f"{campo}: {int(invalidos.sum())}/{len(serie)}")
        for v in serie[invalidos].head(5):
            muestra.append({"columna": campo, "valor": str(v)})

    r["n_total"] = total
    r["n_hallazgos"] = n_inv
    r["tasa_error"] = round(n_inv / total, 6) if total else 0.0
    r["estado"] = _estado_por_tasa(r["tasa_error"], r["umbral"], r["n_hallazgos"])
    r["detalle"] = (
        f"{n_inv} de {total} valores no son convertibles a {esperado} "
        f"({'; '.join(por_columna)})."
    )
    r["muestra"] = muestra[:10]
    r["codigo_pandas"] = (
        f"for campo in {campos!r}:\n"
        f"    conv = pd.to_datetime(df[campo], errors='coerce')  # o pd.to_numeric\n"
        f"    invalidos = conv.isna() & df[campo].notna()\n"
        f"    print(f'{{campo}}: {{invalidos.sum()}} valores no convertibles a {esperado}')"
    )
    return r


def _motor_completitud(df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """El dataset debe tener al menos MIN_FILAS y todas las columnas de COLUMNAS_REQ."""
    r = _base(cfg["control_id"], "completitud", cfg.get("umbral", 0.0))
    min_filas = int(cfg.get("min_filas") or 1)
    requeridas = _cols(cfg.get("columnas_req"))

    faltantes = [c for c in requeridas if c not in df.columns]
    filas_ok = len(df) >= min_filas
    n_problemas = len(faltantes) + (0 if filas_ok else 1)

    r["n_total"] = len(requeridas) + 1
    r["n_hallazgos"] = n_problemas
    r["tasa_error"] = round(n_problemas / r["n_total"], 6) if r["n_total"] else 0.0
    r["estado"] = "OK" if n_problemas == 0 else ("ERROR" if faltantes else "ALERTA")
    r["detalle"] = (
        f"Filas: {len(df)} (mínimo {min_filas}) → {'OK' if filas_ok else 'INSUFICIENTE'}. "
        f"Columnas faltantes: {faltantes or 'ninguna'}."
    )
    r["muestra"] = [{"columna_faltante": c} for c in faltantes[:10]]
    r["codigo_pandas"] = (
        f"requeridas = {requeridas!r}\n"
        f"faltantes = [c for c in requeridas if c not in df.columns]\n"
        f"print(f'Filas: {{len(df)}} | Columnas faltantes: {{faltantes}}')"
    )
    return r


# ═════════════════════════════════════════════════════════════════════════════
# REGISTRO AUTO-DESCRIPTIVO
# ═════════════════════════════════════════════════════════════════════════════

REGISTRO_MOTORES: Dict[str, Dict[str, Any]] = {
    "unicidad": {
        "fn": _motor_unicidad,
        "descripcion": "Verifica que exista UN solo valor del campo objetivo por grupo.",
        "requiere": ["GROUP_COLS", "CAMPO_OBJETIVO"],
        "opcional": ["UMBRAL"],
        "ejemplo": "Un solo Cliente por Cuenta",
    },
    "duplicados": {
        "fn": _motor_duplicados,
        "descripcion": "Detecta filas duplicadas según las columnas clave.",
        "requiere": [],
        "opcional": ["GROUP_COLS", "UMBRAL"],
        "ejemplo": "No debe haber dos registros idénticos de Cuenta+Fecha",
    },
    "missing": {
        "fn": _motor_missing,
        "descripcion": "Cuantifica valores nulos en las columnas indicadas.",
        "requiere": [],
        "opcional": ["CAMPO_OBJETIVO", "UMBRAL"],
        "ejemplo": "Menos del 1% de nulos en 'monto'",
    },
    "outliers": {
        "fn": _motor_outliers,
        "descripcion": "Detecta valores atípicos por IQR robusto (no Z-score).",
        "requiere": ["CAMPO_OBJETIVO"],
        "opcional": ["UMBRAL"],
        "ejemplo": "Outliers de 'Tasa' fuera de 1.5·IQR",
    },
    "rango": {
        "fn": _motor_rango,
        "descripcion": "Valida que los valores caigan dentro de [MIN, MAX].",
        "requiere": ["CAMPO_OBJETIVO", "MIN y/o MAX"],
        "opcional": ["UMBRAL"],
        "ejemplo": "Tasa entre 0 y 1",
    },
    "integridad_referencial": {
        "fn": _motor_integridad_referencial,
        "descripcion": "Los valores deben existir en un dataset de referencia.",
        "requiere": ["CAMPO_OBJETIVO", "DATASET_REF"],
        "opcional": ["CAMPO_REF", "UMBRAL"],
        "ejemplo": "Todo id_cliente de operaciones existe en maestro_clientes",
    },
    "tipo_dato": {
        "fn": _motor_tipo_dato,
        "descripcion": "Valida que la columna sea convertible al tipo esperado.",
        "requiere": ["CAMPO_OBJETIVO"],
        "opcional": ["TIPO_ESPERADO", "UMBRAL"],
        "ejemplo": "'FechaApertura' debe ser fecha válida",
    },
    "completitud": {
        "fn": _motor_completitud,
        "descripcion": "El dataset tiene las columnas requeridas y filas suficientes.",
        "requiere": [],
        "opcional": ["COLUMNAS_REQ", "MIN_FILAS"],
        "ejemplo": "El extracto debe traer al menos 1000 filas",
    },
}


def motores_disponibles() -> List[str]:
    """Nombres de las pruebas registradas."""
    return sorted(REGISTRO_MOTORES)


def describir_motores() -> str:
    """Texto legible del catálogo — se inyecta en los prompts del LLM."""
    lineas = []
    for nombre in motores_disponibles():
        m = REGISTRO_MOTORES[nombre]
        lineas.append(
            f"- {nombre}: {m['descripcion']}\n"
            f"    requiere: {', '.join(m['requiere']) or '—'}\n"
            f"    opcional: {', '.join(m['opcional']) or '—'}\n"
            f"    ejemplo : {m['ejemplo']}"
        )
    return "\n".join(lineas)


def ejecutar_motor(tipo: str, df, cfg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ejecuta la prueba `tipo` sobre `df` con la configuración `cfg`.
    Nunca lanza excepción: los fallos se devuelven como estado='ERROR'.
    """
    tipo_norm = str(tipo or "").strip().lower()
    entrada = REGISTRO_MOTORES.get(tipo_norm)
    if entrada is None:
        r = _base(cfg.get("control_id", "?"), tipo_norm, cfg.get("umbral", 0.0))
        r.update(
            estado="ERROR",
            error=(f"Motor '{tipo}' no implementado. "
                   f"Disponibles: {', '.join(motores_disponibles())}"),
        )
        return r
    if df is None:
        r = _base(cfg.get("control_id", "?"), tipo_norm, cfg.get("umbral", 0.0))
        r.update(estado="ERROR",
                 error=f"Dataset '{cfg.get('dataset','?')}' no disponible")
        return r
    try:
        return entrada["fn"](df, cfg)
    except Exception as exc:  # nunca romper el pipeline por un control
        r = _base(cfg.get("control_id", "?"), tipo_norm, cfg.get("umbral", 0.0))
        r.update(estado="ERROR", error=f"{type(exc).__name__}: {exc}")
        return r


# ═════════════════════════════════════════════════════════════════════════════
# CARGA DE DATASETS
# ═════════════════════════════════════════════════════════════════════════════

EXTENSIONES_DATASET = {".csv", ".parquet", ".xlsx", ".xlsm"}


def cargar_datasets(carpeta) -> Dict[str, Any]:
    """
    Carga todos los datasets de una carpeta en un dict {nombre: DataFrame}.

    Por qué existe:
        El Excel de controles referencia DATASET por nombre (ej. 'data_subset'),
        pero NADA en el proyecto cargaba esos datos: `datasets_dict` llegaba
        siempre como None y los controles con USA_MOTOR_DATA=1 no se ejecutaban.

    Convención: el nombre del dataset es el del archivo sin extensión.
        inputs/calidad_datos/datasets/data_subset.csv → 'data_subset'
    """
    from pathlib import Path
    carpeta = Path(carpeta)
    datasets: Dict[str, Any] = {}
    if not carpeta.exists():
        return datasets

    for p in sorted(carpeta.iterdir()):
        if p.suffix.lower() not in EXTENSIONES_DATASET or p.name.startswith("~$"):
            continue
        try:
            if p.suffix.lower() == ".csv":
                df = pd.read_csv(p)
            elif p.suffix.lower() == ".parquet":
                df = pd.read_parquet(p)
            else:
                df = pd.read_excel(p)
            datasets[p.stem] = df
        except Exception as exc:
            print(f"  ⚠ No se pudo cargar dataset '{p.name}': {exc}")
    return datasets


# ═════════════════════════════════════════════════════════════════════════════
# CLI: python -m modulos.motores_datos
# ═════════════════════════════════════════════════════════════════════════════

# ═════════════════════════════════════════════════════════════════════════════
# [SEG-14] Lectura de Unity Catalog con MÍNIMO DATO NECESARIO
# ═════════════════════════════════════════════════════════════════════════════
# Norma 4180.223.08 · 2135.010.02 §Transmisión. Antes la guía proponía
# `spark.read.table(t).toPandas()`: traer la tabla COMPLETA (todas las columnas
# y filas) al driver. Ahora toda lectura declara las columnas que necesita y un
# filtro de filas o un límite explícito, con un tope duro de filas.
#
# Autenticación: dentro de Databricks, la identidad del job/cluster (service
# principal). Nunca un token personal: esta función no acepta ni lee tokens.

MAX_FILAS_UC = 2_000_000


class LecturaNoMinima(ValueError):
    """Lectura de Unity Catalog sin columnas o sin filtro/límite."""


def cargar_datasets_uc(mapa: Dict[str, Dict[str, Any]], *, spark=None) -> Dict[str, Any]:
    """
    Lee datasets de tablas Unity Catalog y devuelve {nombre: pandas.DataFrame}.

        mapa = {
          "principal": {"tabla": "riesgo.var.posiciones_2027",
                        "columnas": ["id_posicion", "fecha", "valor"],
                        "where": "fecha >= '2027-01-01'"},
          "pnl":       {"tabla": "riesgo.var.pnl_diario",
                        "columnas": ["fecha", "pnl"], "limite": 50_000},
        }

    Reglas (LecturaNoMinima si se incumplen):
      · `columnas` obligatoria y no vacía (nada de SELECT *);
      · `where` y/o `limite` obligatorio (nada de tabla completa);
      · `limite` ≤ MAX_FILAS_UC; si solo hay `where`, se aplica MAX_FILAS_UC y se
        avisa si la lectura lo alcanza (resultado truncado).
    """
    if spark is None:
        from pyspark.sql import SparkSession            # type: ignore
        spark = SparkSession.builder.getOrCreate()
    out: Dict[str, Any] = {}
    for nombre, spec in mapa.items():
        if not isinstance(spec, dict) or not spec.get("tabla"):
            raise LecturaNoMinima(f"{nombre}: falta 'tabla'")
        columnas = [c for c in (spec.get("columnas") or []) if str(c).strip() and c != "*"]
        if not columnas:
            raise LecturaNoMinima(
                f"{nombre}: declara las 'columnas' que necesita el control (sin SELECT *)")
        where, limite = spec.get("where"), spec.get("limite")
        if not where and not limite:
            raise LecturaNoMinima(
                f"{nombre}: indica 'where' (ventana/segmento) o 'limite'; no se lee la tabla completa")
        if limite is not None and (int(limite) <= 0 or int(limite) > MAX_FILAS_UC):
            raise LecturaNoMinima(f"{nombre}: 'limite' debe estar entre 1 y {MAX_FILAS_UC:,}")
        tope = int(limite) if limite else MAX_FILAS_UC
        sdf = spark.read.table(spec["tabla"]).select(*columnas)
        if where:
            sdf = sdf.where(where)
        pdf = sdf.limit(tope).toPandas()
        if not limite and len(pdf) >= MAX_FILAS_UC:
            print(f"  ⚠️  {nombre}: lectura truncada a {MAX_FILAS_UC:,} filas; "
                  "acota el 'where' o agrega en Spark antes de traer a memoria.")
        out[nombre] = pdf
    return out


if __name__ == "__main__":
    import sys
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print("═" * 74)
    print("  🔧 MOTOR DE DATA — PRUEBAS DE CALIDAD DISPONIBLES")
    print("═" * 74)
    print(f"\n  Total: {len(REGISTRO_MOTORES)} pruebas\n")
    print(describir_motores())
    print("\n" + "═" * 74)
    print("  Uso en ControlesData.xlsx:")
    print("    USA_MOTOR_DATA=1  +  TIPO_MOTOR=<nombre>  +  columnas requeridas")
    print("═" * 74)
