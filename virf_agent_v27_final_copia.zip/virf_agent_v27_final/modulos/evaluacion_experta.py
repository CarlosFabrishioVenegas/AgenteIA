"""
modulos/evaluacion_experta.py  [Paso 65]
═════════════════════════════════════════════════════════════════════════════
Evaluación humana por expertos con rúbrica 0-1-2 (pruebas/rubrica_experta.md).

Cada evaluación se SELLA en un fichero solo-anexar con hash encadenado (mismo
criterio que el feedback, SEG-08): editar o borrar una evaluación rompe
`verificar()`. El experto es la identidad autenticada (SEG-02); el agente solo
consolida, no evalúa.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from statistics import mean
from typing import Dict, Optional

CRITERIOS = ("exactitud", "soporte_evidencia", "completitud", "claridad")
_GENESIS = "0" * 64
_RAIZ = Path(__file__).resolve().parents[1]
RUTA: Optional[Path] = None


def _ruta() -> Path:
    return Path(RUTA) if RUTA else _RAIZ / "audit_logs" / "evaluacion_experta.jsonl"


def _leer() -> list:
    p = _ruta()
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()] \
        if p.exists() else []


def _hash(reg: dict) -> str:
    return hashlib.sha256(json.dumps({k: v for k, v in reg.items() if k != "hash"},
                                     sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def registrar(caso_id: str, experto_upn: str, experto_oid: str,
              puntajes: Dict[str, int], comentario: str = "") -> dict:
    faltan = [c for c in CRITERIOS if c not in puntajes]
    if faltan:
        raise ValueError(f"faltan criterios: {faltan}")
    if any(puntajes[c] not in (0, 1, 2) for c in CRITERIOS):
        raise ValueError("cada criterio se puntúa 0, 1 o 2")
    if not experto_oid:
        raise PermissionError("la evaluación la firma una identidad autenticada")
    previos = _leer()
    reg = {"cuando": datetime.now(timezone.utc).isoformat(timespec="seconds"),
           "caso_id": caso_id, "experto": experto_upn, "oid": experto_oid,
           "puntajes": {c: int(puntajes[c]) for c in CRITERIOS}, "comentario": comentario[:500],
           "hash_prev": previos[-1]["hash"] if previos else _GENESIS}
    reg["hash"] = _hash(reg)
    p = _ruta(); p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(reg, ensure_ascii=False) + "\n")
    return reg


def verificar() -> dict:
    prev = _GENESIS
    regs = _leer()
    for i, r in enumerate(regs):
        if r.get("hash_prev") != prev or _hash(r) != r.get("hash"):
            return {"ok": False, "n": len(regs), "roto_en": i}
        prev = r["hash"]
    return {"ok": True, "n": len(regs), "roto_en": None}


def consolidar() -> dict:
    if not verificar()["ok"]:
        raise ValueError("el registro de evaluaciones fue alterado: no se consolida")
    regs = _leer()
    return {"n_evaluaciones": len(regs),
            "n_casos": len({r["caso_id"] for r in regs}),
            "media_por_criterio": {c: round(mean(r["puntajes"][c] for r in regs), 3) if regs else None
                                   for c in CRITERIOS}}
