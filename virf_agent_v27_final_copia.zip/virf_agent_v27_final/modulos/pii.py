"""
modulos/pii.py
═════════════════════════════════════════════════════════════════════════════
Enmascarado DETERMINISTA de datos personales (PII) en la evidencia, ANTES de que
un extracto salga hacia el proveedor de generación.

POR QUÉ EXISTE
──────────────
El corpus RAG (literatura regulatoria) es público, pero la EVIDENCIA DEL MODELO
que se valida —manuales internos, data sets de cartera, actas, correos— puede
arrastrar datos personales: el DNI de un cliente en una muestra, el RUC de una
persona natural, una cuenta CCI en una hoja de prueba, el nombre de quien firmó
un acta. Enmascararlo aquí es la capa que impide esa fuga sin depender de que el
documento venga limpio (Ley 29733 · norma 2135.010.02 §Gobierno, de-identificación).

BASE PERUANA, ESPAÑA COMO COMPLEMENTO (SEG-04)
─────────────────────────────────────────────
La primera versión usaba patrones de España (DNI con letra, NIE, IBAN): un DNI
peruano de 8 dígitos pasaba sin tocar. Ahora la base es Perú:

  · DNI      8 dígitos. Con contexto («DNI», «D.N.I.», «documento de
             identidad») se enmascara siempre, con o sin dígito verificador.
             Sin contexto, solo con la forma «12345678-K» y verificador válido
             (algoritmo RENIEC, pesos 3-2-7-6-5-4-3-2).
  · RUC      11 dígitos que empiezan por 10/15/17/20. Con contexto «RUC», basta
             el prefijo; sin contexto, además debe cuadrar el dígito de control
             SUNAT (pesos 5-4-3-2-7-6-5-4-3-2, mod 11).
  · CE       Carné de extranjería: 9-12 alfanuméricos con al menos un dígito,
             solo detrás de «CE» / «carné (de extranjería)».
  · CCI      20 dígitos (contiguos o en la forma 3-3-12-2).
  · CUENTA   Cuentas con guiones: forma BCP 3-8-1-2 en cualquier parte; otras
             formas solo detrás de «cuenta» / «cta.» / «N° de cuenta».
  · NOMBRE   Por CONTEXTO, no por diccionario: tras tratamiento (Sr./Sra./Dr./
             Ing./Lic.…), en encabezados de correo («De:», «Para:», «CC:») y en
             campos de acta/firma («Elaborado por:», «Asistentes:», «Firma:»,
             «Atentamente,» + línea siguiente).
             LÍMITE DOCUMENTADO: no hay NER aprobado por el banco; un nombre
             suelto en medio de una frase («…según indicó Juan Pérez…») NO se
             detecta. Si se aprueba un NER local, debe enchufarse en
             `_enmascarar_nombres` sin cambiar el contrato.

España (DNI con letra, NIE, IBAN), tarjetas (Luhn), correos y teléfonos con
contexto se mantienen como complemento.

PRINCIPIOS DE DISEÑO
────────────────────
1. 100% LOCAL Y DETERMINISTA. Solo `re` y aritmética de checksum. Sin modelos,
   sin red. El mismo texto produce siempre el mismo resultado.

2. ALTA PRECISIÓN ANTES QUE ALTA COBERTURA. Un documento financiero está LLENO
   de números que NO son PII (importes, tasas, fechas, códigos de modelo).
   Enmascarar de más CORROMPE la evidencia. Por eso todo número sin contexto
   explícito debe pasar un checksum o una forma inequívoca.

3. TOKENS ESTABLES. Cada valor distinto recibe un token numerado por tipo
   (`[DNI_1]`, `[RUC_1]`, `[NOMBRE_2]`…). El mismo valor repetido en el texto
   recibe el MISMO token, de modo que el texto sigue siendo analizable («el
   cliente [DNI_1] aparece en dos filas») sin revelar el dato. El mapeo valor→
   token NO se guarda ni se devuelve: no es reversible.

4. CONSISTENCIA CON LA VERIFICACIÓN DE CITAS. El motor enmascara el `contexto`
   UNA vez, y a partir de ahí el prompt Y la verificación literal de citas usan
   el mismo texto enmascarado.

Devuelve SIEMPRE (texto, hallazgos). Nunca lanza.

Uso:
    from modulos.pii import enmascarar
    limpio, hallazgos = enmascarar(texto_evidencia)
    #  hallazgos → [{"tipo": "DNI", "n": 2}, {"tipo": "CORREO", "n": 1}]
"""

from __future__ import annotations

import logging
import re
from typing import Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("virf.pii")

__all__ = ["enmascarar", "contiene_pii", "PLACEHOLDERS", "token"]

# Prefijo del token por tipo de hallazgo. El token final es `[<PREFIJO>_<n>]`.
PLACEHOLDERS = {
    # Perú (base)
    "DNI":      "DNI",
    "RUC":      "RUC",
    "CE":       "CE",
    "CCI":      "CCI",
    "CUENTA":   "CUENTA",
    "NOMBRE":   "NOMBRE",
    # Comunes
    "CORREO":   "CORREO",
    "CREDENCIAL": "CREDENCIAL",   # [Paso 62] claves/tokens en la evidencia
    "TARJETA":  "TARJETA",
    "TELEFONO": "TELEFONO",
    # España (complemento)
    "IBAN":     "IBAN",
    "DOCID":    "DOC_ID",
}


def token(tipo: str, n: int = 1) -> str:
    """Token estable que sustituye al dato: `token("DNI", 1)` → `[DNI_1]`."""
    return f"[{PLACEHOLDERS[tipo]}_{n}]"


class _Tokens:
    """Asigna a cada valor distinto un número por tipo, estable dentro de una
    llamada a `enmascarar`. Cuenta también las ocurrencias para los hallazgos."""

    def __init__(self, texto: str = "") -> None:
        self._mapa: Dict[str, Dict[str, int]] = {}
        self.ocurrencias: Dict[str, int] = {}
        # Si el texto YA trae tokens (p. ej. el gateway re-enmascara un prompt
        # que contiene evidencia enmascarada antes), la numeración nueva sigue
        # tras el mayor existente: un mismo token nunca designa dos valores.
        self._base: Dict[str, int] = {}
        for tipo, prefijo in PLACEHOLDERS.items():
            nums = [int(n) for n in re.findall(
                r"\[" + re.escape(prefijo) + r"_(\d+)\]", texto or "")]
            if nums:
                self._base[tipo] = max(nums)

    def de(self, tipo: str, valor: str) -> str:
        clave = re.sub(r"[\s.\-]", "", valor).upper()
        por_tipo = self._mapa.setdefault(tipo, {})
        if clave not in por_tipo:
            por_tipo[clave] = self._base.get(tipo, 0) + len(por_tipo) + 1
        self.ocurrencias[tipo] = self.ocurrencias.get(tipo, 0) + 1
        return token(tipo, por_tipo[clave])


# ═════════════════════════════════════════════════════════════════════════════
# CHECKSUMS
# ═════════════════════════════════════════════════════════════════════════════

def _luhn_valido(digitos: str) -> bool:
    """Algoritmo de Luhn (tarjetas de pago)."""
    if not digitos.isdigit():
        return False
    total, alt = 0, False
    for d in reversed(digitos):
        n = ord(d) - 48
        if alt:
            n *= 2
            if n > 9:
                n -= 9
        total += n
        alt = not alt
    return total % 10 == 0


_IBAN_VALORES = {c: str(i) for i, c in enumerate(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ", start=10)}


def _iban_valido(iban: str) -> bool:
    """Validación mod-97 (ISO 13616)."""
    iban = iban.replace(" ", "").replace("-", "").upper()
    if len(iban) < 15 or len(iban) > 34:
        return False
    if not (iban[:2].isalpha() and iban[2:4].isdigit()):
        return False
    reordenado = iban[4:] + iban[:4]
    convertido = "".join(_IBAN_VALORES.get(c, c) for c in reordenado)
    if not convertido.isdigit():
        return False
    return int(convertido) % 97 == 1


_DNI_ES_LETRAS = "TRWAGMYFPDXBNJZSQVHLCKE"


def _dni_nie_es_valido(texto: str) -> bool:
    """DNI español (8 dígitos + letra) o NIE (X/Y/Z + 7 dígitos + letra)."""
    t = texto.upper().replace("-", "").replace(" ", "")
    m = re.fullmatch(r"([XYZ]?)(\d{7,8})([A-Z])", t)
    if not m:
        return False
    prefijo, numero, letra = m.groups()
    if prefijo:
        if len(numero) != 7:
            return False
        numero = str("XYZ".index(prefijo)) + numero
    elif len(numero) != 8:
        return False
    return _DNI_ES_LETRAS[int(numero) % 23] == letra


def _dni_pe_verificador_valido(numero: str, verificador: str) -> bool:
    """Dígito/letra verificador del DNI peruano (RENIEC): pesos 3-2-7-6-5-4-3-2,
    clave = 11 − (suma mod 11), y la clave indexa una tabla numérica y otra
    alfabética (el carné puede llevar cualquiera de las dos)."""
    if len(numero) != 8 or not numero.isdigit() or len(verificador) != 1:
        return False
    pesos = (3, 2, 7, 6, 5, 4, 3, 2)
    suma = sum(int(d) * p for d, p in zip(numero, pesos))
    clave = 11 - (suma % 11)
    i = 0 if clave == 11 else clave
    return verificador.upper() in ("67890112345"[i], "KABCDEFGHIJ"[i])


_RUC_PREFIJOS = ("10", "15", "17", "20")


def _ruc_valido(ruc: str) -> bool:
    """RUC SUNAT: 11 dígitos, prefijo de tipo de contribuyente y dígito de
    control (pesos 5-4-3-2-7-6-5-4-3-2; r = 11 − suma mod 11; 10→0, 11→1)."""
    if len(ruc) != 11 or not ruc.isdigit() or ruc[:2] not in _RUC_PREFIJOS:
        return False
    pesos = (5, 4, 3, 2, 7, 6, 5, 4, 3, 2)
    r = 11 - (sum(int(d) * p for d, p in zip(ruc[:10], pesos)) % 11)
    r = {10: 0, 11: 1}.get(r, r)
    return int(ruc[10]) == r


# ═════════════════════════════════════════════════════════════════════════════
# PATRONES
# ═════════════════════════════════════════════════════════════════════════════
# Un número «suelto» no debe estar pegado a otros dígitos ni ser parte de un
# decimal/millar («1.234», «0,05»).
_NO_NUM_ANTES = r"(?<![\d.,/\-])"
_NO_NUM_DESPUES = r"(?![\d]|[.,/]\d)"

# Rótulo opcional de número: «N°», «Nº», «No.», «nro.», «número», «#».
_NUM_ROTULO = r"(?:(?:N[°ºo]|nro|n[uú]m(?:ero)?)\.?\s*)?[:#\-]?\s*"

# [Paso 62 · OWASP LLM06] Credenciales dentro de la evidencia (un .env, un
# notebook con la clave pegada). No son PII, pero no pueden salir hacia el LLM.
_RE_CREDENCIAL = re.compile(
    r"sk-ant-[A-Za-z0-9_\-]{20,}"
    r"|\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_\-]{32,}"
    r"|\bdapi[0-9a-f]{32}\b"
    r"|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")
# Valor asignado a un nombre de clave: se enmascara SOLO el valor.
_RE_CREDENCIAL_CTX = re.compile(
    r"(?i)\b(?:[A-Z_]*API_?KEY|[A-Z_]*SECRET|[A-Z_]*TOKEN|PASSWORD|PASSWD|CONTRASE[ÑN]A|CLIENT_SECRET)\b"
    r"[\"']?\s*[:=]\s*[\"']?([A-Za-z0-9_\-+/=.]{16,})")

_RE_CORREO = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")

# ── Perú ──────────────────────────────────────────────────────────────────────
# DNI con contexto: el rótulo se conserva, se enmascara el número (+verificador).
_RE_DNI_PE_CTX = re.compile(
    r"(?i)\b(?:D\.?\s?N\.?\s?I\.?|documento\s+(?:nacional\s+)?de\s+identidad"
    r"|doc\.?\s*(?:de\s+)?ident(?:idad)?\.?)\s*" + _NUM_ROTULO +
    r"(\d{8}(?:\s?-\s?[0-9A-Ka-k])?)" + _NO_NUM_DESPUES + r"\b")

# DNI aislado: solo con verificador separado por guion y checksum válido.
_RE_DNI_PE_VERIF = re.compile(
    _NO_NUM_ANTES + r"\b(\d{8})-([0-9A-Ka-k])\b(?![\w\-])")

_RE_RUC_CTX = re.compile(
    r"(?i)\bR\.?\s?U\.?\s?C\.?\s*" + _NUM_ROTULO +
    r"((?:10|15|17|20)\d{9})" + _NO_NUM_DESPUES + r"\b")
_RE_RUC_SUELTO = re.compile(
    _NO_NUM_ANTES + r"\b((?:10|15|17|20)\d{9})\b" + _NO_NUM_DESPUES)

# CE: «CE» en mayúsculas (case-sensitive, «ce» no es rótulo) o «carné/carnet
# (de extranjería)» en cualquier caja. El número lleva al menos un dígito.
_RE_CE = re.compile(
    r"(?:\bC\.?E\.?|(?i:\bcarn[eé]t?(?:\s+de\s+extranjer[ií]a)?))"
    r"\s*(?i:" + _NUM_ROTULO + r")"
    r"(?=[A-Za-z]*\d)([A-Za-z0-9]{9,12})\b")

# CCI: 20 dígitos contiguos o en la forma 3-3-12-2 (espacio o guion).
_RE_CCI = re.compile(
    _NO_NUM_ANTES + r"\b(\d{20}|\d{3}[ \-]\d{3}[ \-]\d{12}[ \-]\d{2})\b"
    + _NO_NUM_DESPUES)

# Cuenta BCP (3-8-1-2) en cualquier parte: forma inequívoca.
_RE_CUENTA_BCP = re.compile(
    _NO_NUM_ANTES + r"\b(\d{3}-\d{7,8}-\d-\d{2})\b" + _NO_NUM_DESPUES)
# Otras cuentas con guiones o espacios: solo con rótulo de cuenta, y el número
# debe sumar entre 10 y 20 dígitos (descarta fechas y códigos cortos).
_RE_CUENTA_CTX = re.compile(
    r"(?i)\b(?:cuenta(?:\s+(?:de\s+)?(?:ahorros?|corriente|sueldo|n[°º]))?|cta\.?"
    r"(?:\s+(?:cte|ahorros?)\.?)?)\s*" + _NUM_ROTULO +
    r"(\d[\d\- ]{8,26}\d)" + _NO_NUM_DESPUES)

# ── Complemento: España, tarjeta, teléfono ───────────────────────────────────
_RE_IBAN = re.compile(r"\b[A-Z]{2}\d{2}(?:[ -]?[A-Z0-9]){11,30}\b")
_RE_TARJETA = re.compile(r"\b(?:\d[ -]?){13,19}\b")
_RE_DNI_ES = re.compile(r"\b[XYZ]?\d{7,8}[ -]?[A-Za-z]\b")
_RE_TEL_ETIQUETA = re.compile(
    r"(?i)\b(?:tel(?:[eé]fono|f)?|m[oó]vil|celular|cel|fax|whats?app|phone)\b"
    r"\s*[:.\-]?\s*(\+?\d[\d ().\-]{7,}\d)")
_RE_TEL_INTL = re.compile(
    r"(?<![\d.])\+\d{1,3}[ .\-]?(?:\d[ .\-]?){7,12}\d\b")

# ── Nombres por contexto ──────────────────────────────────────────────────────
_MAY = "A-ZÁÉÍÓÚÑÜ"
_MIN = "a-záéíóúñü"
_PALABRA = rf"[{_MAY}][{_MIN}]+(?:-[{_MAY}][{_MIN}]+)?"
_PARTICULA = r"(?:de\s+la\s+|de\s+los\s+|del\s+|de\s+)"
# Nombre completo: 2-5 palabras capitalizadas (permite «de», «del», «de la»).
_NOMBRE = rf"{_PALABRA}(?:[ \t]+{_PARTICULA}?{_PALABRA}){{1,4}}"
# Tras tratamiento basta un apellido («Sr. Pérez»).
_NOMBRE_TRAT = rf"{_PALABRA}(?:[ \t]+{_PARTICULA}?{_PALABRA}){{0,4}}"

_RE_TRATAMIENTO = re.compile(
    rf"\b(?:Sr|Sra|Srta|Dr|Dra|Lic|Ing|Mg|Mtro|Mtra|Econ|Abg)\.[ \t]+({_NOMBRE_TRAT})")

_ROTULOS_NOMBRE = (
    r"De|Para|CC|Cc|CCO|Cco|From|To|Remitente|Destinatarios?|"
    r"Firmado\s+por|Firma|Elaborado\s+por|Preparado\s+por|Revisado\s+por|"
    r"Aprobado\s+por|Validado\s+por|Responsable|Validador(?:a)?|"
    r"Asistentes|Participantes|Presentes|Nombres?(?:\s+y\s+apellidos)?|"
    r"Apellidos\s+y\s+nombres|Titular|Cliente")
_RE_LINEA_ROTULO = re.compile(
    rf"(?m)^([ \t]*(?:[-*•][ \t]*)?(?:{_ROTULOS_NOMBRE})[ \t]*:[ \t]*)(.+)$")
_RE_DESPEDIDA = re.compile(
    r"(?mi)^([ \t]*(?:atentamente|saludos(?:\s+cordiales)?|cordialmente)[ \t]*,?[ \t]*\r?\n[ \t]*)"
    rf"({_NOMBRE})[ \t]*$")
_RE_NOMBRE = re.compile(_NOMBRE)

# Palabras capitalizadas que NO son nombres de persona: si aparecen en el
# candidato, se descarta (evita enmascarar «Para: Gerencia de Riesgos»).
_NO_NOMBRE = frozenset(w.lower() for w in """
    Gerencia Gerente Área Area Equipo Comité Comite Banco Riesgo Riesgos Modelo
    Modelos Validación Validacion Unidad División Division Departamento Dirección
    Direccion Todos Todas Jefe Jefa Jefatura Auditoría Auditoria Cumplimiento
    Crédito Credito Créditos Mercado Mercados Operacional Tesorería Tesoreria
    Finanzas Contabilidad Tecnología Tecnologia Sistemas Seguridad Información
    Informacion Datos Analítica Analitica Comercial Negocio Negocios Retail
    Mayorista Banca Corporativa Corporativo Superintendencia Directorio Lima Perú
    Peru Asunto Anexo Anexos Acta Reunión Reunion Informe Documento Fecha Hora
    Lunes Martes Miércoles Jueves Viernes Sábado Domingo Enero Febrero Marzo Abril
    Mayo Junio Julio Agosto Septiembre Setiembre Octubre Noviembre Diciembre
    Estimado Estimada Estimados Hola Buenos Buenas Gracias Cliente Clientes
""".split())


def _es_nombre(candidato: str) -> bool:
    palabras = [w for w in re.split(r"[\s\-]+", candidato)
                if w and w.lower() not in ("de", "del", "la", "los")]
    return bool(palabras) and not any(w.lower() in _NO_NOMBRE for w in palabras)


# ═════════════════════════════════════════════════════════════════════════════
# SUSTITUCIÓN
# ═════════════════════════════════════════════════════════════════════════════

def _sub_grupo(patron: re.Pattern, texto: str, tipo: str, tk: _Tokens,
               validar: Optional[Callable[[re.Match], bool]] = None,
               grupo: int = 1) -> str:
    """Sustituye SOLO el grupo `grupo` de cada coincidencia (el rótulo queda)."""
    def _rep(m: re.Match) -> str:
        if validar is not None and not validar(m):
            return m.group(0)
        ini = m.start(grupo) - m.start(0)
        fin = m.end(grupo) - m.start(0)
        crudo = m.group(0)
        return crudo[:ini] + tk.de(tipo, m.group(grupo)) + crudo[fin:]
    return patron.sub(_rep, texto)


def _enmascarar_nombres(texto: str, tk: _Tokens) -> str:
    """Nombres por contexto (tratamiento, encabezados, campos de acta, firma)."""
    def _rep_nombre(m: re.Match) -> str:
        return tk.de("NOMBRE", m.group(0)) if _es_nombre(m.group(0)) else m.group(0)

    def _rep_linea(m: re.Match) -> str:
        return m.group(1) + _RE_NOMBRE.sub(_rep_nombre, m.group(2))

    texto = _RE_LINEA_ROTULO.sub(_rep_linea, texto)
    texto = _sub_grupo(_RE_DESPEDIDA, texto, "NOMBRE", tk,
                       validar=lambda m: _es_nombre(m.group(2)), grupo=2)
    texto = _sub_grupo(_RE_TRATAMIENTO, texto, "NOMBRE", tk,
                       validar=lambda m: _es_nombre(m.group(1)))
    return texto


def enmascarar(texto: str) -> Tuple[str, List[Dict[str, int]]]:
    """
    Enmascara PII en `texto` y devuelve (texto_enmascarado, hallazgos).

    Orden: correo → identificadores peruanos con contexto (DNI, RUC, CE,
    cuentas) → formas inequívocas sin contexto (CCI, cuenta BCP, RUC con
    checksum, DNI con verificador) → complemento (IBAN, tarjeta, DNI/NIE
    español) → teléfonos → nombres. Lo largo y lo rotulado va antes para que un
    número ya sustituido no vuelva a evaluarse con un patrón más laxo.

    Nunca lanza: ante cualquier error devuelve el texto ORIGINAL con aviso.
    """
    if not texto or not isinstance(texto, str):
        return texto or "", []

    original = texto
    try:
        tk = _Tokens(texto)

        texto = _RE_CREDENCIAL.sub(lambda m: tk.de("CREDENCIAL", m.group(0)), texto)
        texto = _sub_grupo(_RE_CREDENCIAL_CTX, texto, "CREDENCIAL", tk)
        texto = _RE_CORREO.sub(lambda m: tk.de("CORREO", m.group(0)), texto)

        # Perú con contexto
        texto = _sub_grupo(_RE_DNI_PE_CTX, texto, "DNI", tk)
        texto = _sub_grupo(_RE_RUC_CTX, texto, "RUC", tk)
        texto = _sub_grupo(_RE_CE, texto, "CE", tk)
        texto = _sub_grupo(_RE_CCI, texto, "CCI", tk)
        texto = _sub_grupo(_RE_CUENTA_BCP, texto, "CUENTA", tk)
        texto = _sub_grupo(
            _RE_CUENTA_CTX, texto, "CUENTA", tk,
            validar=lambda m: 10 <= len(re.sub(r"\D", "", m.group(1))) <= 20)

        # Perú sin contexto (checksum obligatorio)
        texto = _sub_grupo(_RE_RUC_SUELTO, texto, "RUC", tk,
                           validar=lambda m: _ruc_valido(m.group(1)))
        texto = _RE_DNI_PE_VERIF.sub(
            lambda m: (tk.de("DNI", m.group(0))
                       if _dni_pe_verificador_valido(m.group(1), m.group(2))
                       else m.group(0)), texto)

        # Complemento
        texto = _RE_IBAN.sub(
            lambda m: tk.de("IBAN", m.group(0)) if _iban_valido(m.group(0)) else m.group(0),
            texto)
        texto = _RE_TARJETA.sub(
            lambda m: (tk.de("TARJETA", m.group(0))
                       if _luhn_valido(re.sub(r"\D", "", m.group(0))) else m.group(0)),
            texto)
        texto = _RE_DNI_ES.sub(
            lambda m: tk.de("DOCID", m.group(0)) if _dni_nie_es_valido(m.group(0)) else m.group(0),
            texto)

        texto = _sub_grupo(_RE_TEL_ETIQUETA, texto, "TELEFONO", tk)
        texto = _RE_TEL_INTL.sub(lambda m: tk.de("TELEFONO", m.group(0)), texto)

        texto = _enmascarar_nombres(texto, tk)

        hallazgos = [{"tipo": t, "n": c} for t, c in tk.ocurrencias.items()]
        if hallazgos:
            logger.info("PII enmascarada: %s",
                        ", ".join(f"{h['tipo']}×{h['n']}" for h in hallazgos))
        return texto, hallazgos

    except Exception as exc:                              # pragma: no cover
        logger.warning("Enmascarado PII falló (%s); se deja el texto original.", exc)
        return original, []


def contiene_pii(texto: str) -> bool:
    """¿Hay al menos un dato personal detectable?"""
    _, hallazgos = enmascarar(texto)
    return bool(hallazgos)
