"""
modulos/clasificacion_docx.py  [SEG-10]
═════════════════════════════════════════════════════════════════════════════
Etiqueta de clasificación en el pie de TODO Word que genera VIRF.

Ningún informe sale sin ella: cada generador llama a `aplicar(doc)` justo
antes de `doc.save(...)` (lo comprueba tests/test_clasificacion_docx.py). La
etiqueta se pone en el pie de cada sección —y en los pies de primera página y
de páginas pares cuando el documento los usa—, para que ninguna página quede
sin marcar.

La etiqueta por defecto es la de la norma interna («Datos elaborados por BCP
para uso Interno»); se parametriza con VIRF_CLASIFICACION_INFORME
(config/parametros.py) o por informe con `aplicar(doc, etiqueta=...)`.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional, Union

__all__ = ["aplicar", "pies_sin_etiqueta", "etiqueta_por_defecto"]


def etiqueta_por_defecto() -> str:
    from config.parametros import clasificacion_informe
    return clasificacion_informe()


def _pies(doc) -> Iterable:
    pares = bool(doc.settings.odd_and_even_pages_header_footer)
    for sec in doc.sections:
        yield sec.footer
        if sec.different_first_page_header_footer:
            yield sec.first_page_footer
        if pares:
            yield sec.even_page_footer


def aplicar(doc, etiqueta: Optional[str] = None):
    """Añade `etiqueta` a cada pie que no la tenga. Idempotente."""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt, RGBColor

    etiqueta = (etiqueta or etiqueta_por_defecto()).strip()
    for pie in _pies(doc):
        if etiqueta in "\n".join(p.text for p in pie.paragraphs):
            continue
        p = pie.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(etiqueta)
        r.font.size = Pt(8)
        r.font.bold = True
        r.font.color.rgb = RGBColor(0x59, 0x59, 0x59)
    return doc


def pies_sin_etiqueta(doc_o_ruta: Union[str, Path, object],
                      etiqueta: Optional[str] = None) -> list:
    """Índices de sección cuyo pie NO lleva la etiqueta (vacío = todo bien)."""
    from docx import Document
    doc = Document(str(doc_o_ruta)) if isinstance(doc_o_ruta, (str, Path)) else doc_o_ruta
    etiqueta = (etiqueta or etiqueta_por_defecto()).strip()
    faltan = []
    for i, sec in enumerate(doc.sections):
        pies = [sec.footer]
        if sec.different_first_page_header_footer:
            pies.append(sec.first_page_footer)
        if doc.settings.odd_and_even_pages_header_footer:
            pies.append(sec.even_page_footer)
        if any(etiqueta not in "\n".join(p.text for p in pie.paragraphs) for pie in pies):
            faltan.append(i)
    return faltan
