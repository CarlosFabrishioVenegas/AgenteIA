"""
modulos/pickle_firmado.py  [SEG-09 · tratamiento de SAST B301]
═════════════════════════════════════════════════════════════════════════════
`pickle.load` de un fichero manipulado ejecuta código arbitrario. Los índices
RAG se guardan como pickle; para que solo se carguen los que escribió el propio
agente, cada `.pkl` lleva un `.pkl.sig` con HMAC-SHA256 (clave
VIRF_CLAVE_CIFRADO_REPOSO de Key Vault). Sin firma válida no se deserializa: el
índice se trata como ausente y se reconstruye desde el corpus.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import pickle
from pathlib import Path
from typing import Any

__all__ = ["guardar", "cargar", "PickleNoFirmado"]


class PickleNoFirmado(ValueError):
    pass


def _clave() -> bytes:
    from config.secretos import obtener_secreto
    try:
        k = obtener_secreto("VIRF_CLAVE_CIFRADO_REPOSO")
    except Exception as exc:                                # noqa: BLE001
        raise PickleNoFirmado("sin clave para firmar/verificar el índice") from exc
    return hashlib.sha256(b"virf-pickle|" + k.encode()).digest()


def _firma(datos: bytes) -> str:
    return hmac.new(_clave(), datos, hashlib.sha256).hexdigest()


def guardar(obj: Any, ruta: Path) -> None:
    """Escritura atómica del pickle + su firma."""
    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    datos = pickle.dumps(obj, protocol=pickle.HIGHEST_PROTOCOL)
    firma = _firma(datos)
    tmp = ruta.with_suffix(ruta.suffix + ".tmp")
    tmp.write_bytes(datos)
    os.replace(tmp, ruta)
    Path(str(ruta) + ".sig").write_text(firma, encoding="ascii")


def cargar(ruta: Path) -> Any:
    """Deserializa SOLO si la firma cuadra; si no, PickleNoFirmado."""
    ruta = Path(ruta)
    datos = ruta.read_bytes()
    sig = Path(str(ruta) + ".sig")
    if not sig.is_file():
        raise PickleNoFirmado(f"{ruta.name} sin firma: no se deserializa")
    if not hmac.compare_digest(sig.read_text(encoding="ascii").strip(), _firma(datos)):
        raise PickleNoFirmado(f"{ruta.name} con firma inválida (¿manipulado?)")
    return pickle.loads(datos)  # nosec B301 — contenido autenticado por HMAC
