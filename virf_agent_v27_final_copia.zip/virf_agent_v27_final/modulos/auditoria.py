"""
modulos/auditoria.py  [SEG-12]
═════════════════════════════════════════════════════════════════════════════
Registro de auditoría de acciones: QUIÉN (identidad SSO), QUÉ (acción +
objeto), CUÁNDO (UTC), DESDE DÓNDE (IP/host) y RESULTADO. Norma 2135.010.02
§Aseguramiento (registros de auditoría).

· Formato JSON lines, SOLO-ANEXAR: se abre en modo «a», nunca se reescribe, y
  cada línea lleva `hash_prev` + `hash` encadenados, de modo que borrar o editar
  una línea es detectable con `verificar()`.
· Ningún endpoint web lo edita ni lo sirve.
· Destino: `VIRF_AUDITORIA_LOG` (por defecto audit_logs/auditoria_acciones.jsonl).
  En producción el destino lo aprueba el banco (SIEM / almacenamiento WORM): el
  fichero local es el mínimo, y en Windows el «solo anexar» lo garantiza la ACL
  que ponga plataforma, no este código.
· Sin contenido sensible: se registran metadatos, nunca prompts, evidencia ni
  credenciales.

Contrato:
    registrar(accion, objeto="", resultado="ok", quien=None, desde="", **detalle)
"""
from __future__ import annotations

import contextvars
import hashlib
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

__all__ = ["registrar", "verificar", "ruta_log", "contexto_web", "leer"]

_RAIZ = Path(__file__).resolve().parents[1]
_GENESIS = "0" * 64
_lock = threading.Lock()

# Quién/desde dónde de la petición web en curso (lo fija el middleware).
contexto_web: "contextvars.ContextVar[Optional[Dict[str, str]]]" = \
    contextvars.ContextVar("virf_auditoria_ctx", default=None)


def ruta_log() -> Path:
    from config.parametros import ruta_log_auditoria
    return ruta_log_auditoria()


def _ultimo_hash(p: Path) -> str:
    if not p.exists():
        return _GENESIS
    ultimo = ""
    with open(p, "rb") as f:
        try:
            f.seek(-4096, os.SEEK_END)
        except OSError:
            f.seek(0)
        for linea in f.read().splitlines():
            if linea.strip():
                ultimo = linea
    try:
        return json.loads(ultimo)["hash"] if ultimo else _GENESIS
    except (ValueError, KeyError):
        return "corrupto"


def _quien_por_defecto() -> Dict[str, str]:
    ctx = contexto_web.get()
    if ctx:
        return ctx
    # Pipeline lanzado por la web: la identidad viene en la aserción firmada.
    try:
        from config.identidad import identidad_autenticada
        ident = identidad_autenticada()
        if ident is not None:
            return {"quien": ident.upn, "oid": ident.oid, "desde": "pipeline"}
    except Exception:                                       # noqa: BLE001
        pass
    return {"quien": "(sin identidad)", "oid": "", "desde": "local"}


def registrar(accion: str, objeto: Any = "", resultado: str = "ok",
              quien: Optional[str] = None, desde: str = "", oid: Optional[str] = None,
              **detalle) -> Dict:
    """Añade UNA entrada. Nunca lanza (la auditoría no tumba la operación),
    pero si no puede escribir lo dice en stderr."""
    base = _quien_por_defecto()
    entrada = {
        "cuando": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "quien": quien or base.get("quien", ""),
        "oid": oid if oid is not None else base.get("oid", ""),
        "desde": desde or base.get("desde", ""),
        "accion": accion,
        "objeto": str(objeto)[:300],
        "resultado": resultado,
    }
    if detalle:
        entrada["detalle"] = {k: v for k, v in detalle.items()
                              if k not in ("accion", "objeto", "resultado")}
    p = ruta_log()
    try:
        with _lock:
            p.parent.mkdir(parents=True, exist_ok=True)
            entrada["hash_prev"] = _ultimo_hash(p)
            entrada["hash"] = hashlib.sha256(json.dumps(
                entrada, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()
            with open(p, "a", encoding="utf-8") as f:
                f.write(json.dumps(entrada, ensure_ascii=False, default=str) + "\n")
    except OSError as exc:
        import sys
        print(f"⚠️  auditoría: no se pudo escribir ({exc})", file=sys.stderr)
    return entrada


def leer() -> list:
    p = ruta_log()
    if not p.exists():
        return []
    return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


def verificar() -> Dict:
    prev = _GENESIS
    regs = leer()
    for i, r in enumerate(regs):
        h = r.pop("hash", None)
        if r.get("hash_prev") != prev or hashlib.sha256(json.dumps(
                r, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest() != h:
            return {"ok": False, "n": len(regs), "roto_en": i}
        prev = h
    return {"ok": True, "n": len(regs), "roto_en": None}
