"""
modulos/almacenamiento.py  [SEG-06]
═════════════════════════════════════════════════════════════════════════════
Almacenamiento local de evidencia: clasificación, cifrado en reposo, retención
y borrado seguro. Norma 4180.223.02 §Uso aceptable · 2135.010.02 §Almacenamiento.

CLASIFICACIÓN (obligatoria al subir)
    Publico · Interno · Restringido. Sin clasificación, la subida se rechaza.
    Restringido SOLO se guarda en un entorno aprobado, declarado
    EXPLÍCITAMENTE con VIRF_ENTORNO=databricks | repositorio_aprobado (no se
    adivina). En el portátil (VIRF_ENTORNO=laptop, el defecto) se rechaza.
    La clasificación de cada fichero queda en un registro central
    (data/clasificacion_ficheros.json), no junto a la evidencia.

CIFRADO EN REPOSO
    Fernet (AES-128-CBC + HMAC-SHA256, `cryptography`) con la clave
    `VIRF_CLAVE_CIFRADO_REPOSO` de Key Vault (config/secretos.py). Sin clave no
    se escribe nada en claro: quien llama debe degradar a memoria.

RETENCIÓN
    VIRF_RETENCION_DIAS (30 por defecto). `purgar_vencidos()` borra con
    sobrescritura los ficheros más antiguos que el plazo; se ejecuta al arrancar
    la web y al cerrar sesión.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import time
from pathlib import Path
from typing import Iterable, List, Optional

__all__ = ["CLASIFICACIONES", "ClasificacionInvalida", "AlmacenamientoNoPermitido",
           "CifradoNoDisponible", "normalizar_clasificacion", "exigir_permitido",
           "registrar_clasificacion", "clasificacion_de", "es_restringido",
           "cifrar", "descifrar", "cifrado_disponible", "borrado_seguro",
           "purgar_vencidos", "MAGIA"]

CLASIFICACIONES = ("Publico", "Interno", "Restringido")
_ENTORNOS_RESTRINGIDO = ("databricks", "repositorio_aprobado")
# Ruta del registro central (None = data/clasificacion_ficheros.json).
REGISTRO: Optional[Path] = None
MAGIA = b"VIRFENC1\n"


class ClasificacionInvalida(ValueError):
    pass


class AlmacenamientoNoPermitido(PermissionError):
    pass


class CifradoNoDisponible(RuntimeError):
    pass


# ── Clasificación ────────────────────────────────────────────────────────────

def normalizar_clasificacion(valor: Optional[str]) -> str:
    v = (valor or "").strip().lower().replace("ú", "u")
    for c in CLASIFICACIONES:
        if v == c.lower():
            return c
    raise ClasificacionInvalida(
        "Clasificación obligatoria: " + " / ".join(CLASIFICACIONES) + f" (recibido: {valor!r}).")


def entorno() -> str:
    from config.parametros import entorno_almacenamiento
    return entorno_almacenamiento()


def exigir_permitido(clasificacion: str) -> str:
    """Normaliza y comprueba que esa clasificación puede guardarse AQUÍ."""
    c = normalizar_clasificacion(clasificacion)
    if c == "Restringido" and entorno() not in _ENTORNOS_RESTRINGIDO:
        raise AlmacenamientoNoPermitido(
            "Información RESTRINGIDA: solo puede guardarse en Databricks o en un "
            "repositorio aprobado por el banco, no en este equipo "
            f"(VIRF_ENTORNO={entorno()}).")
    return c


def _registro() -> Path:
    from config.rutas import BASE_DIR
    return Path(REGISTRO) if REGISTRO else BASE_DIR / "data" / "clasificacion_ficheros.json"


def _clave(fichero: Path) -> str:
    return str(Path(fichero).resolve()).lower()


def registrar_clasificacion(fichero: Path, clasificacion: str, quien: str = "") -> None:
    """Guarda la clasificación en un registro CENTRAL (fuera de las carpetas de
    evidencia, para que ningún lector la confunda con un documento)."""
    reg = _registro()
    try:
        datos = json.loads(reg.read_text(encoding="utf-8")) if reg.exists() else {}
    except (OSError, ValueError):
        datos = {}
    datos[_clave(fichero)] = {"clasificacion": clasificacion, "quien": quien,
                              "fecha": time.strftime("%Y-%m-%dT%H:%M:%S")}
    reg.parent.mkdir(parents=True, exist_ok=True)
    reg.write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")


def clasificacion_de(fichero: Path) -> Optional[str]:
    try:
        return json.loads(_registro().read_text(encoding="utf-8")).get(
            _clave(fichero), {}).get("clasificacion")
    except (OSError, ValueError, AttributeError):
        return None


def es_restringido(fichero: Path) -> bool:
    return clasificacion_de(fichero) == "Restringido"


# ── Cifrado en reposo ────────────────────────────────────────────────────────

def _fernet():
    from cryptography.fernet import Fernet
    from config.secretos import obtener_secreto
    try:
        secreto = obtener_secreto("VIRF_CLAVE_CIFRADO_REPOSO")
    except Exception as exc:                               # noqa: BLE001
        raise CifradoNoDisponible(f"sin clave de cifrado en reposo ({type(exc).__name__})") from exc
    if len(secreto) < 32:
        raise CifradoNoDisponible("VIRF_CLAVE_CIFRADO_REPOSO debe tener ≥32 caracteres")
    return Fernet(base64.urlsafe_b64encode(hashlib.sha256(secreto.encode()).digest()))


def cifrado_disponible() -> bool:
    try:
        _fernet()
        return True
    except CifradoNoDisponible:
        return False


def cifrar(datos: bytes) -> bytes:
    return MAGIA + _fernet().encrypt(datos)


def descifrar(blob: bytes) -> bytes:
    if not blob.startswith(MAGIA):
        raise CifradoNoDisponible("el fichero no está cifrado con el formato VIRF")
    from cryptography.fernet import InvalidToken
    try:
        return _fernet().decrypt(blob[len(MAGIA):])
    except InvalidToken as exc:
        raise CifradoNoDisponible("clave de cifrado incorrecta o fichero alterado") from exc


# ── Retención y borrado seguro ───────────────────────────────────────────────

def borrado_seguro(p: Path) -> None:
    """Sobrescribe con ceros y borra. (En SSD/copy-on-write la sobrescritura no
    garantiza el borrado físico: por eso lo Restringido no se guarda aquí.)"""
    p = Path(p)
    try:
        n = p.stat().st_size
        with open(p, "r+b") as f:
            f.write(b"\0" * n)
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass
    p.unlink(missing_ok=True)


def purgar_vencidos(raices: Iterable[Path], dias: Optional[float] = None,
                    ahora: Optional[float] = None) -> List[Path]:
    """Borra (con sobrescritura) los ficheros cuya última modificación supera el
    plazo de retención. Devuelve los borrados."""
    if dias is None:
        from config.parametros import dias_retencion
        dias = dias_retencion()
    limite = (ahora or time.time()) - float(dias) * 86400
    borrados: List[Path] = []
    for raiz in raices:
        raiz = Path(raiz)
        if not raiz.is_dir():
            continue
        for p in raiz.rglob("*"):
            if p.is_file() and p.stat().st_mtime < limite:
                borrado_seguro(p)
                borrados.append(p)
    return borrados
