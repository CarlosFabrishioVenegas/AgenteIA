"""
chunker.py  [v20]
=================
Servicio de chunking inteligente para documentos largos.

PROBLEMA QUE RESUELVE (v18 → v20)
-----------------------------------
En v18/v19, `_chunked_summary()` vivía dentro de `Mx_01_LecturaEvidencias.py`
(capa de infraestructura de lectura) y llamaba internamente a `get_cliente_ia()`
(capa de IA). Esto violaba el principio de separación de capas:
  - Si la API fallaba durante la lectura, el error era capturado silenciosamente
  - No había control de rate limiting desde un punto centralizado
  - No se podía mostrar progreso al usuario ("segmento 7/11")
  - El pre-flight de API key no protegía el chunking

DISEÑO v20
----------
  - `ChunkerService` recibe el cliente IA ya inicializado (inyección de dependencia)
  - `Mx_01_LecturaEvidencias.leer_archivo()` devuelve texto crudo sin llamadas IA
  - `agente.py` instancia `ChunkerService(cliente)` y llama `procesar_lote()` 
    justo después de leer todos los archivos
  - Un único punto de control para rate limiting, MAX_CHUNKS y progreso

API pública
-----------
  ChunkerService(cliente_ia, chunk_size, chunk_overlap, chunk_threshold, max_chunks)
  .procesar_doc(doc_dict) → doc_dict enriquecido con cobertura_pct, fue_resumido…
  .procesar_lote(docs)    → list de docs procesados
"""

from __future__ import annotations

from modulos.salida_ia import material_no_confiable as _mnc
import hashlib
import json
import logging
import math
import os
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger("virf.chunker")

# ── Parámetros ───────────────────────────────────────────────────────────────
# [CONFIG-CENTRAL v27.2] Los valores ya NO se leen aquí con os.getenv: vienen de
# config/parametros.py, única fuente de verdad del proyecto. Antes este bloque
# duplicaba VIRF_CHUNK_SIZE / _OVERLAP / _THRESHOLD con Mx_01, y VIRF_MAX_CTX
# con agente.py usando un default distinto ("15000" literal aquí frente a
# MAX_CHARS_DOC allí): coincidían por casualidad y dejaban de hacerlo en cuanto
# se tocaba MAX_CHARS_DOC, con el chunker calculando su presupuesto contra un
# valor obsoleto.
#
# Se conservan los nombres privados históricos como alias porque `validate_project.py`
# y los tests de regresión los importan directamente.
from config.parametros import (
    CHUNK_OVERLAP as _CHUNK_OVERLAP,
    CHUNK_SIZE as _CHUNK_SIZE,
    CHUNK_SIZE_MAX as _MAX_CHUNK_SIZE_ADAPTATIVO,
    CHUNK_THRESHOLD as _CHUNK_THRESHOLD,
    MAX_CHUNKS as _MAX_CHUNKS,
    MAX_NIVELES as _MAX_NIVELES_CONSOLIDACION,
    PRESUPUESTO_DOC as _PRESUPUESTO_CONTEXTO,
)

# [COSTE-FIX] Fichero donde se cachean los resúmenes de chunking.
# Convive con document_cache.json (que guarda el texto crudo).
_CACHE_RESUMENES = "chunk_summaries_cache.json"

# Prompt de extracción orientado a auditoría financiera
_PROMPT_EXTRACCION = """\
Eres un extractor de información para auditoría de modelos financieros.
Documento: '{nombre}' (tipo: {tipo}) — Segmento {i}/{n}

Extrae TODA la información relevante para validación de modelos:
  • Metodología y supuestos del modelo
  • Tests estadísticos (Kupiec, Christoffersen, López, etc.)
  • Calidad de datos (missing values, outliers, fuentes)
  • Gobierno (actas, aprobaciones, tiering, inventario)
  • Implementación (coherencia manual vs código)
  • Seguimiento y backtesting
  • Cualquier cifra, fecha, p-value o conclusión relevante

NO omitas información cuantitativa. Sé exhaustivo y denso.

SEGMENTO:
{chunk}

Responde en español con un resumen estructurado.\
"""

# [COBERTURA-FIX] Prompt de nivel 2 para el modo jerárquico: consolida varios
# resúmenes de segmentos contiguos sin perder información cuantitativa.
_PROMPT_CONSOLIDACION = """\
Eres un consolidador de información para auditoría de modelos financieros.
Documento: '{nombre}' — Bloque {i}/{n}

A continuación hay varios resúmenes de segmentos CONSECUTIVOS del mismo
documento. Consolídalos en un único resumen coherente.

REGLAS:
  • NO pierdas ninguna cifra, fecha, p-value, test estadístico ni conclusión.
  • Elimina solo la redundancia entre segmentos solapados.
  • Mantén el orden narrativo del documento original.
  • Si dos segmentos se contradicen, señálalo explícitamente.

RESÚMENES A CONSOLIDAR:
{resumenes}

Responde en español con un resumen estructurado y denso.\
"""


class ChunkerService:
    """
    Servicio de chunking inteligente con inyección de cliente IA.

    Parámetros
    ----------
    cliente_ia:       instancia de ClienteIA ya inicializada (de config.py)
    chunk_size:       chars por segmento (default: VIRF_CHUNK_SIZE)
    chunk_overlap:    solapamiento entre segmentos (default: VIRF_CHUNK_OVERLAP)
    chunk_threshold:  documentos más cortos no se chunkean (default: VIRF_CHUNK_THRESHOLD)
    max_chunks:       máximo de chunks por documento (default: VIRF_MAX_CHUNKS)
    """

    def __init__(
        self,
        cliente_ia,
        chunk_size:      int = _CHUNK_SIZE,
        chunk_overlap:   int = _CHUNK_OVERLAP,
        chunk_threshold: int = _CHUNK_THRESHOLD,
        max_chunks:      int = _MAX_CHUNKS,
        cache_dir=None,          # [COSTE-FIX] carpeta del caché de resúmenes
    ):
        self.cliente        = cliente_ia
        self.chunk_size     = chunk_size
        self.chunk_overlap  = chunk_overlap
        self.chunk_threshold = chunk_threshold
        self.max_chunks     = max_chunks
        self.cache_dir      = cache_dir
        self._cache_hits    = 0

        # Contadores de sesión
        self._docs_chunkeados  = 0
        self._docs_directos    = 0
        self._docs_truncados   = 0
        self._chunks_totales   = 0

    # ── Interfaz pública ──────────────────────────────────────────────────────

    # ── [COSTE-FIX] Caché de resúmenes de chunking ───────────────────────────
    # Medido en la auditoría D2: resumir un manual de 305 páginas cuesta
    # ~$0.90 USD (63 llamadas, 438k tokens de entrada). Ese gasto se repetía
    # ÍNTEGRO en cada corrida aunque el documento no hubiera cambiado, porque
    # `document_cache` solo guarda el texto CRUDO extraído, no los resúmenes.
    #
    # La clave combina el hash del texto con la configuración del chunker: si
    # cambia el documento O cambia cómo se segmenta, se recalcula.

    def _clave_cache(self, texto: str) -> str:
        firma = (
            f"{self.chunk_size}|{self.chunk_overlap}|{self.chunk_threshold}|"
            f"{self.max_chunks}|{_PRESUPUESTO_CONTEXTO}|{_MAX_NIVELES_CONSOLIDACION}"
        )
        h = hashlib.sha256()
        h.update(texto.encode("utf-8", errors="ignore"))
        h.update(b"||")
        h.update(firma.encode())
        return h.hexdigest()

    def _leer_cache(self, clave: str) -> Optional[Dict]:
        if not self.cache_dir:
            return None
        f = Path(self.cache_dir) / _CACHE_RESUMENES
        if not f.exists():
            return None
        try:
            return json.loads(f.read_text(encoding="utf-8")).get(clave)
        except (json.JSONDecodeError, OSError):
            return None

    @staticmethod
    def limpiar_cache_resumenes(cache_dir) -> int:
        """
        Vacía el caché de RESÚMENES de chunking. Devuelve las entradas borradas.

        [AUDIT-FIX] `--limpiar-cache` solo vaciaba `document_cache.json` y este
        fichero quedaba intacto. No es un detalle: aquí viven los resúmenes
        DERIVADOS, y una entrada mala sobrevive a la limpieza del caché de
        documentos que la originó.

        Encontrado con las dos entradas del mismo manual conviviendo:
            cobertura=1.2%   n_chunks=2   modo=directo      ← envenenada
            cobertura=100.0% n_chunks=40  modo=jerarquico   ← correcta
        Cuál se sirve depende de la clave, que incluye la configuración del
        chunker. La recomendación «ejecuta --limpiar-cache antes de la primera
        validación real» era por tanto insatisfacible: el comando no alcanzaba
        el fichero que había que limpiar.
        """
        if not cache_dir:
            return 0
        f = Path(cache_dir) / _CACHE_RESUMENES
        if not f.exists():
            return 0
        try:
            n = len(json.loads(f.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, OSError):
            n = 0
        # Los helpers de concurrencia viven en document_cache y se importan
        # localmente, igual que en `_guardar_cache`.
        try:
            from modulos.document_cache import _lock_archivo, _escribir_json_atomico
        except ImportError:
            from contextlib import nullcontext

            def _lock_archivo(_p):                        # noqa: E306
                return nullcontext()

            def _escribir_json_atomico(destino, data):    # noqa: E306
                destino.write_text(json.dumps(data, ensure_ascii=False),
                                   encoding="utf-8")

        # Bajo el mismo lock que usa la escritura, para no pisar a un proceso
        # que esté persistiendo resúmenes en este momento.
        with _lock_archivo(f):
            _escribir_json_atomico(f, {})
        return n

    def _guardar_cache(self, clave: str, datos: Dict) -> None:
        """
        Persiste un resumen en el caché de chunking.

        [AUDIT-FIX] La escritura era atómica pero NO estaba bajo lock, así que
        el ciclo leer-modificar-escribir de dos procesos se pisaba: el último en
        escribir descartaba lo que el otro había añadido. Medido con 4 procesos
        simultáneos: se perdía el 75% de los resúmenes (6 de 24).

        Eso no es solo una caché fría — cada resumen perdido hay que volver a
        pagarlo al modelo ($1,14 para el PDF de 305 páginas). Se reutiliza el
        lock entre procesos de document_cache, igual que en feedback.py.
        """
        if not self.cache_dir:
            return
        d = Path(self.cache_dir)
        d.mkdir(parents=True, exist_ok=True)
        f = d / _CACHE_RESUMENES

        try:
            from modulos.document_cache import _lock_archivo
        except ImportError:                       # sin lock, mejor que perderlo
            from contextlib import nullcontext
            _lock_archivo = lambda _p: nullcontext()   # noqa: E731

        try:
            with _lock_archivo(f):
                # Relectura DENTRO del lock: es lo que evita el lost update.
                try:
                    actual = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
                    if not isinstance(actual, dict):
                        actual = {}
                except (json.JSONDecodeError, OSError):
                    actual = {}
                actual[clave] = datos

                # Escritura atómica: tmp + replace (mismo criterio que document_cache)
                tmp = f.with_suffix(".json.tmp")
                try:
                    tmp.write_text(json.dumps(actual, ensure_ascii=False, indent=1),
                                   encoding="utf-8")
                    os.replace(str(tmp), str(f))
                except OSError as exc:
                    logger.warning("No se pudo guardar el caché de resúmenes: %s", exc)
                    tmp.unlink(missing_ok=True)
        except Exception as exc:
            # Nunca tumbar el chunking por un problema de caché.
            logger.warning("Caché de resúmenes no disponible: %s", exc)

    def procesar_doc(self, doc: Dict) -> Dict:
        """
        Procesa un dict de documento devuelto por `leer_archivo()`.

        Si el contenido supera `chunk_threshold`, lo divide en segmentos,
        llama a la IA para resumir cada uno y consolida el resultado.

        El doc original NO se muta; se devuelve una copia enriquecida.

        Campos añadidos al dict:
          cobertura_pct (float):  0-100, porcentaje del texto original leído
          fue_resumido  (bool):   True si se usó IA para resumir
          n_chunks      (int):    segmentos procesados
          fue_truncado_fc (bool): True si chunking falló y se truncó como fallback
        """
        doc = dict(doc)  # copia para no mutar el original
        texto  = doc.get("contenido", "") or ""
        nombre = doc.get("nombre", "documento")
        tipo   = doc.get("tipo",   "DOC")
        chars  = doc.get("chars_totales", len(texto))

        # Documentos cortos → ruta directa, sin overhead
        if chars <= self.chunk_threshold:
            doc["cobertura_pct"]   = 100.0
            doc["fue_resumido"]    = False
            doc["n_chunks"]        = 1
            doc["fue_truncado_fc"] = False
            self._docs_directos += 1
            return doc

        # ── [COSTE-FIX] ¿Ya resumimos este documento con esta configuración? ──
        _clave = self._clave_cache(texto)
        _guardado = self._leer_cache(_clave)
        if _guardado:
            self._cache_hits += 1
            doc.update(_guardado)
            print(
                f"    ⚡ '{nombre}': resúmenes servidos del caché "
                f"({_guardado.get('n_chunks', '?')} segmentos, "
                f"{_guardado.get('cobertura_pct', '?')}% cobertura) — 0 llamadas al LLM"
            )
            return doc

        # ── Calcular segmentos ────────────────────────────────────────────────
        chunks = self._dividir_en_chunks(texto)
        n_chunks_real = len(chunks)
        modo_cobertura = "directo"
        jerarquico = False

        # ── [COBERTURA-FIX] Documentos que exceden el límite de segmentos ─────
        # ANTES: `chunks = chunks[:self.max_chunks]` → se quedaba con la PRIMERA
        #        parte del documento y descartaba el resto. Para un manual de
        #        300 páginas eso significaba perder la mitad final (backtesting,
        #        validación de supuestos, conclusiones) con solo un warning.
        # AHORA: dos estrategias que preservan el 100% del texto:
        #        1. ADAPTATIVO  — se recalcula el tamaño de segmento para que
        #           todo el documento quepa en `max_chunks` llamadas.
        #        2. JERÁRQUICO  — si el segmento adaptativo resultaría demasiado
        #           grande para el modelo, se resume en dos niveles:
        #           N segmentos → N resúmenes → resúmenes agrupados y re-resumidos.
        if n_chunks_real > self.max_chunks:
            paso_necesario = math.ceil(len(texto) / self.max_chunks)
            size_adaptativo = paso_necesario + self.chunk_overlap

            if size_adaptativo <= _MAX_CHUNK_SIZE_ADAPTATIVO:
                modo_cobertura = "adaptativo"
                chunks = self._dividir_en_chunks(texto, chunk_size=size_adaptativo)
                logger.info(
                    "Chunker adaptativo: '%s' %d→%d segmentos (size %d→%d) — cobertura 100%%",
                    nombre, n_chunks_real, len(chunks), self.chunk_size, size_adaptativo,
                )
                print(
                    f"\n  📐 CHUNKING ADAPTATIVO: '{nombre}' ({chars:,} chars)\n"
                    f"     {n_chunks_real} segmentos de {self.chunk_size:,} excedían el límite "
                    f"({self.max_chunks}).\n"
                    f"     Ajustado a {len(chunks)} segmentos de {size_adaptativo:,} chars "
                    f"→ cobertura 100%.\n"
                )
            else:
                # Documento tan grande que ni agrandando el segmento cabe:
                # se procesan TODOS los segmentos y se resumen en dos niveles.
                modo_cobertura = "jerarquico"
                jerarquico = True

                # ── [COSTE-FIX D2] Guarda anti-acantilado ─────────────────
                # Este `else` NO es una degradación suave: es un salto de
                # coste. Medido sobre el PDF de 305 páginas (1.302.266 chars):
                #     MAX_CHUNKS=40 → adaptativo, 43 llamadas, $1,14
                #     MAX_CHUNKS=30 → jerárquico, 120 llamadas, $2,27  (+99%)
                # Bajar MAX_CHUNKS para "ahorrar" acaba costando el DOBLE,
                # porque aquí se procesan los n_chunks_real segmentos de
                # chunk_size en vez de los max_chunks segmentos adaptativos.
                #
                # Antes esto solo emitía un logger.info neutro y el usuario
                # no tenía forma de saber que había cruzado el acantilado.
                # Ahora se dice explícitamente cuál es el mínimo que lo evita.
                min_chunks_adaptativo = math.ceil(
                    len(texto) / max(_MAX_CHUNK_SIZE_ADAPTATIVO - self.chunk_overlap, 1)
                )
                logger.warning(
                    "Chunker jerárquico por tope de segmento: '%s' procesará %d "
                    "segmentos en vez de %d (coste ~%.1fx). Para volver al modo "
                    "adaptativo: VIRF_MAX_CHUNKS>=%d o VIRF_CHUNK_SIZE_MAX>=%d.",
                    nombre, n_chunks_real, self.max_chunks,
                    n_chunks_real / max(self.max_chunks, 1),
                    min_chunks_adaptativo, size_adaptativo,
                )
                print(
                    f"\n  🏗️  CHUNKING JERÁRQUICO: '{nombre}' ({chars:,} chars)\n"
                    f"     {n_chunks_real} segmentos — se resumirán en 2 niveles "
                    f"para cubrir el 100% del documento.\n"
                    f"\n  ⚠️  AVISO DE COSTE: el segmento adaptativo necesario "
                    f"({size_adaptativo:,} chars) supera el tope "
                    f"VIRF_CHUNK_SIZE_MAX ({_MAX_CHUNK_SIZE_ADAPTATIVO:,}).\n"
                    f"     Se procesarán {n_chunks_real} segmentos en vez de "
                    f"{self.max_chunks}: ~{n_chunks_real / max(self.max_chunks, 1):.1f}x "
                    f"más llamadas IA.\n"
                    f"     La cobertura sigue siendo del 100%, pero es MÁS CARO "
                    f"que subir el límite.\n"
                    f"     Para evitarlo: VIRF_MAX_CHUNKS>={min_chunks_adaptativo} "
                    f"o VIRF_CHUNK_SIZE_MAX>={size_adaptativo:,}.\n"
                )

        n_proc = len(chunks)

        # Intentar resumir con IA
        try:
            resumenes: List[str] = []
            for i, chunk in enumerate(chunks, 1):
                print(
                    f"    📄 Chunking '{nombre}': segmento {i}/{n_proc}...",
                    end="\r", flush=True,
                )
                prompt = _PROMPT_EXTRACCION.format(
                    nombre=nombre, tipo=tipo, i=i, n=n_proc,
                    chunk=_mnc(chunk, "documento"),
                )
                resumen = self.cliente.generar_mensaje(
                    prompt=prompt,
                    max_tokens=1500,
                )
                resumenes.append(f"[Segmento {i}/{n_proc}]\n{resumen}")

            # ── [PRESUPUESTO-FIX] Nivel 2 por TAMAÑO DEL RESULTADO ────────────
            # Detectado en la auditoría: un manual de 327k chars producía 30
            # resúmenes que sumaban 118.332 chars, muy por encima de
            # VIRF_MAX_CTX (15.000). El prompt los recortaba con contexto[:MAX_CTX]
            # → volvíamos a truncar, ahora en la capa del prompt.
            #
            # El modo jerárquico se disparaba solo por el tamaño de ENTRADA.
            # Ahora también por el tamaño de SALIDA: si los resúmenes no caben
            # en el presupuesto de contexto, se consolidan en un segundo nivel
            # (resúmenes de resúmenes) hasta que quepan, SIN descartar ninguno.
            chars_resumenes = sum(len(r) for r in resumenes)

            if chars_resumenes > _PRESUPUESTO_CONTEXTO and len(resumenes) > 1:
                jerarquico = True
                modo_cobertura = "jerarquico"
                print(
                    f"\n  🏗️  CONSOLIDACIÓN JERÁRQUICA: '{nombre}' — "
                    f"{len(resumenes)} resúmenes suman {chars_resumenes:,} chars "
                    f"(presupuesto {_PRESUPUESTO_CONTEXTO:,}).\n"
                    f"     Se consolidan por niveles SIN descartar ninguno.\n"
                )

                # Consolidación ITERATIVA hasta que el conjunto quepa.
                # Error de la versión anterior: n_bloques se calculaba desde el
                # tamaño de ENTRADA (ceil(chars/presupuesto)), lo que generaba
                # MÁS bloques en vez de menos y no reducía nada.
                # Ahora se calcula desde el tamaño de SALIDA que se quiere.
                nivel = 0
                while (sum(len(r) for r in resumenes) > _PRESUPUESTO_CONTEXTO
                       and len(resumenes) > 1
                       and nivel < _MAX_NIVELES_CONSOLIDACION):
                    nivel += 1
                    tokens_bloque = 700                    # ~2.800 chars por bloque
                    chars_bloque = tokens_bloque * 4
                    n_bloques = max(1, _PRESUPUESTO_CONTEXTO // chars_bloque)
                    n_bloques = min(n_bloques, len(resumenes) - 1)
                    tam_grupo = math.ceil(len(resumenes) / n_bloques)

                    consolidados: List[str] = []
                    for idx, ini in enumerate(range(0, len(resumenes), tam_grupo), start=1):
                        bloque = resumenes[ini:ini + tam_grupo]
                        print(
                            f"    🏗️  Nivel {nivel} · bloque {idx}/{n_bloques} "
                            f"({len(bloque)} resúmenes)...",
                            end="\r", flush=True,
                        )
                        prompt_l2 = _PROMPT_CONSOLIDACION.format(
                            nombre=nombre, i=idx, n=n_bloques,
                            resumenes=_mnc("\n\n".join(bloque), "resumenes_ia"),
                        )
                        consolidados.append(
                            f"[Bloque {idx}/{n_bloques} — segmentos "
                            f"{ini + 1}-{min(ini + tam_grupo, len(resumenes))}]\n"
                            + self.cliente.generar_mensaje(
                                prompt=prompt_l2, max_tokens=tokens_bloque)
                        )
                    print(
                        f"    ✅ Nivel {nivel}: {len(resumenes)} → {len(consolidados)} "
                        f"bloques ({sum(len(c) for c in consolidados):,} chars)          "
                    )
                    resumenes = consolidados

                # ── [D1-FIX] Pasada final forzada ────────────────────────────
                # Detectado al probar con un PDF REAL de 305 páginas (1,3 M chars):
                # tras los 3 niveles los resúmenes seguían en 19.817 chars frente
                # a un presupuesto de 9.000, y el prompt acababa recortándolos.
                # Los tests sintéticos no lo detectaron porque su cliente
                # simulado devolvía resúmenes de tamaño fijo.
                #
                # Si al agotar los niveles aún no cabe, se hace UNA consolidación
                # final de todos los bloques en uno solo, con max_tokens acotado
                # al presupuesto. Preferimos un resumen global más comprimido
                # que un recorte ciego que descarta el final del documento.
                restante = sum(len(r) for r in resumenes)
                if restante > _PRESUPUESTO_CONTEXTO and len(resumenes) > 1:
                    print(
                        f"    🎯 Pasada final: {len(resumenes)} bloques "
                        f"({restante:,} chars) → 1 resumen global…",
                        end="\r", flush=True,
                    )
                    prompt_final = _PROMPT_CONSOLIDACION.format(
                        nombre=nombre, i=1, n=1,
                        resumenes=_mnc("\n\n".join(resumenes), "resumenes_ia"),
                    )
                    resumenes = [
                        "[Resumen global del documento — consolidación final]\n"
                        + self.cliente.generar_mensaje(
                            prompt=prompt_final,
                            # ~4 chars por token, con margen del 10%
                            max_tokens=max(500, int(_PRESUPUESTO_CONTEXTO * 0.9 / 4)),
                        )
                    ]
                    print(
                        f"    ✅ Pasada final: 1 resumen global "
                        f"({len(resumenes[0]):,} chars)                    "
                    )

                final = sum(len(r) for r in resumenes)
                if final > _PRESUPUESTO_CONTEXTO:
                    logger.warning(
                        "'%s': tras %d nivel(es) + pasada final, los resúmenes "
                        "suman %d chars (presupuesto %d). El modelo no comprimió "
                        "lo suficiente; el prompt recortará el excedente.",
                        nombre, nivel, final, _PRESUPUESTO_CONTEXTO,
                    )

            # ── [TRUNCADO-FIX] Cobertura contra el tamaño REAL del archivo ────
            # `chars` es chars_totales que reporta Mx_01 (tamaño en disco).
            # `len(texto)` es lo que este servicio recibió. Si alguien truncó
            # aguas arriba, ambos difieren y la cobertura debe reflejarlo:
            # antes se calculaba solo sobre lo recibido y salía 100% aunque
            # se hubiera perdido el 95% del documento.
            chars_recibidos = len(texto)
            chars_reales = max(chars, chars_recibidos)   # chars_totales de Mx_01

            cubiertos_del_recibido = min(
                n_proc * (self.chunk_size if modo_cobertura == "directo"
                          else math.ceil(chars_recibidos / max(n_proc, 1))),
                chars_recibidos,
            )
            cobertura = round(cubiertos_del_recibido / chars_reales * 100, 1) if chars_reales else 0.0
            cobertura = min(cobertura, 100.0)

            if chars_reales > chars_recibidos:
                logger.warning(
                    "'%s': se recibieron %d de %d chars (truncado aguas arriba) "
                    "→ cobertura real %.1f%%",
                    nombre, chars_recibidos, chars_reales, cobertura,
                )

            etiqueta_modo = {
                "directo":    "segmentado",
                "adaptativo": "segmentado adaptativo",
                "jerarquico": "resumen jerárquico en 2 niveles",
            }[modo_cobertura]

            contenido_final = (
                f"📘 DOCUMENTO LARGO — '{nombre}' ({chars:,} chars totales)\n"
                f"Procesado por {etiqueta_modo}: {n_proc} segmentos. "
                f"COBERTURA DEL DOCUMENTO: {cobertura}%.\n\n"
                + "\n\n".join(resumenes)
            )
            print(
                f"    ✅ '{nombre}': {n_proc} segmentos [{modo_cobertura}] "
                f"— cobertura {cobertura}%          "
            )

            doc["contenido"]       = contenido_final
            doc["cobertura_pct"]   = cobertura
            doc["fue_resumido"]    = True
            doc["n_chunks"]        = n_proc
            doc["modo_cobertura"]  = modo_cobertura
            doc["fue_truncado_fc"] = False

            # [COSTE-FIX] Persistir para no repetir el gasto en la próxima corrida
            self._guardar_cache(_clave, {
                "contenido":       contenido_final,
                "cobertura_pct":   cobertura,
                "fue_resumido":    True,
                "n_chunks":        n_proc,
                "modo_cobertura":  modo_cobertura,
                "fue_truncado_fc": False,
            })

            self._docs_chunkeados += 1
            self._chunks_totales  += n_proc
            return doc

        except Exception as exc:
            # Fallback: truncar con aviso visible
            logger.error("❌ Chunker: error procesando '%s': %s", nombre, exc)
            leido   = min(chars, self.chunk_size * 2)
            pct     = round(leido / chars * 100, 1)
            tipo_err = "RATE LIMIT" if "rate" in str(exc).lower() else \
                       "AUTH ERROR" if "401" in str(exc) else "ERROR API"
            aviso = (
                f"\n\n⚠️ DOCUMENTO TRUNCADO ({tipo_err}) — '{nombre}': "
                f"{chars:,} chars totales, se leyeron {leido:,} ({pct}%). "
                f"Para cobertura completa verificar API key o aumentar VIRF_MAX_CHUNKS."
            )
            doc["contenido"]       = texto[:leido] + aviso
            doc["cobertura_pct"]   = pct
            doc["fue_resumido"]    = False
            doc["n_chunks"]        = n_proc
            doc["fue_truncado_fc"] = True

            self._docs_truncados += 1
            return doc

    def procesar_lote(
        self,
        docs: List[Dict],
        verbose: bool = True,
    ) -> List[Dict]:
        """
        Procesa una lista de documentos, aplicando chunking donde sea necesario.

        Solo procesa documentos con `chars_totales > chunk_threshold`.
        Los demás pasan sin modificación (salvo añadir los campos de cobertura).

        Parámetros
        ----------
        docs:    lista de dicts de documentos (output de leer_archivo)
        verbose: imprimir resumen al finalizar

        Retorna
        -------
        Lista de docs con campos cobertura_pct, fue_resumido, n_chunks añadidos.
        """
        resultado: List[Dict] = []
        docs_largos = [d for d in docs if d and (d.get("chars_totales", 0) > self.chunk_threshold)]
        docs_cortos = [d for d in docs if d and (d.get("chars_totales", 0) <= self.chunk_threshold)]

        if docs_largos and verbose:
            print(
                f"\n  📚 Chunking: {len(docs_largos)} documento(s) largo(s) "
                f"de {len(docs)} total. Procesando...\n"
            )

        for doc in docs_largos:
            resultado.append(self.procesar_doc(doc))

        # Documentos cortos: pasar con campos de cobertura por consistencia
        for doc in docs_cortos:
            if doc:
                doc = dict(doc)
                doc.setdefault("cobertura_pct",   100.0)
                doc.setdefault("fue_resumido",     False)
                doc.setdefault("n_chunks",         1)
                doc.setdefault("fue_truncado_fc",  False)
                resultado.append(doc)

        if verbose and (docs_largos or docs_cortos):
            print(self.resumen_sesion())

        return resultado

    def resumen_sesion(self) -> str:
        """Retorna string legible con estadísticas de la sesión de chunking."""
        if self._docs_chunkeados + self._docs_truncados == 0:
            return "  📚 Chunker: sin documentos largos esta sesión."
        return (
            f"  📚 Chunker:\n"
            f"     ✅ Resumidos con IA : {self._docs_chunkeados} docs "
            f"({self._chunks_totales} segmentos totales)\n"
            f"     ⚠️  Truncados (error): {self._docs_truncados} docs\n"
            f"     ⚡ Sin chunking      : {self._docs_directos} docs (cortos)"
        )

    # ── Métodos internos ──────────────────────────────────────────────────────

    def _dividir_en_chunks(
        self,
        texto: str,
        chunk_size: Optional[int] = None,
    ) -> List[str]:
        """
        Divide texto en segmentos solapados.

        [COBERTURA-FIX] `chunk_size` es ahora parametrizable para permitir el
        modo adaptativo: cuando un documento requiere más segmentos de los
        permitidos, se recalcula el tamaño en vez de descartar el excedente.
        """
        size = chunk_size or self.chunk_size
        paso = max(size - self.chunk_overlap, 1)   # evita bucle infinito
        chunks: List[str] = []
        inicio = 0
        while inicio < len(texto):
            fin = min(inicio + size, len(texto))
            chunks.append(texto[inicio:fin])
            if fin == len(texto):
                break
            inicio += paso
        return chunks
