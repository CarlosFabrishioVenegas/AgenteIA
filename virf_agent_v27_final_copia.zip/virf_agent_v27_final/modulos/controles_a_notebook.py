"""
controles_a_notebook.py — Documento de controles de datos → Notebook + Brechas
═══════════════════════════════════════════════════════════════════════════════

EL PROBLEMA QUE RESUELVE

    En una validación de Calidad de Datos suele haber DOS fuentes que describen
    los controles, y casi nunca coinciden:

      A) ControlesData.xlsx     — los controles que el validador VA A EJECUTAR
                                  (estructurados, ejecutables)

      B) Un documento en prosa  — los controles que el modelador DICE que aplica
         (manual de calidad       (Word/PDF/Markdown, no ejecutable)
          de datos, DDM, etc.)

    Hasta ahora VIRF solo leía (A). Los controles descritos en (B) quedaban
    sin contrastar: si el manual prometía un control de integridad referencial
    que nadie ejecutaba, nadie lo detectaba.

LO QUE HACE ESTE MÓDULO

    1. Lee el documento (B) y, con el LLM, EXTRAE los controles descritos en
       prosa y los convierte a la misma estructura que (A).
    2. Genera un .ipynb EJECUTABLE que implementa esos controles en pandas,
       usando el catálogo real de `motores_datos`.
    3. Cruza (A) contra (B) y produce un ANÁLISIS DE BRECHAS:

         ✅ EN AMBOS      → documentado y ejecutado
         📄 SOLO EN DOC   → prometido pero NO ejecutado   ← hallazgo de validación
         ⚙️  SOLO EN EXCEL → ejecutado pero NO documentado ← hallazgo de gobierno

USO
    python agente.py --controles-a-notebook inputs/calidad_datos/manual_controles.docx \
                     --excel inputs/calidad_datos/ControlesData.xlsx
"""

from __future__ import annotations

from modulos.salida_ia import material_no_confiable as _mnc
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import nbformat as nbf

from modulos.motores_datos import (
    REGISTRO_MOTORES, describir_motores, motores_disponibles,
)

# ═════════════════════════════════════════════════════════════════════════════
# 1. LECTURA DEL DOCUMENTO
# ═════════════════════════════════════════════════════════════════════════════

def leer_documento(path: Path) -> str:
    """Extrae texto plano de .docx, .pdf, .md o .txt."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"No existe el documento: {path}")

    ext = path.suffix.lower()

    if ext in (".md", ".txt"):
        return path.read_text(encoding="utf-8", errors="ignore")

    if ext == ".docx":
        try:
            import docx
        except ImportError:
            raise ImportError("pip install python-docx")
        d = docx.Document(str(path))
        partes = [p.text for p in d.paragraphs if p.text.strip()]
        # Las tablas suelen contener el catálogo de controles: no perderlas
        for t in d.tables:
            for fila in t.rows:
                celdas = [c.text.strip() for c in fila.cells]
                if any(celdas):
                    partes.append(" | ".join(celdas))
        return "\n".join(partes)

    if ext == ".pdf":
        try:
            from pdfminer.high_level import extract_text
            return extract_text(str(path)) or ""
        except Exception:
            pass
        try:
            import PyPDF2
            with open(path, "rb") as f:
                return "\n".join(pg.extract_text() or "" for pg in PyPDF2.PdfReader(f).pages)
        except Exception as exc:
            raise RuntimeError(f"No se pudo leer el PDF: {exc}")

    raise ValueError(f"Extensión no soportada: {ext} (usa .docx, .pdf, .md o .txt)")


# ═════════════════════════════════════════════════════════════════════════════
# 2. EXTRACCIÓN DE CONTROLES CON EL LLM
# ═════════════════════════════════════════════════════════════════════════════

_PROMPT_EXTRACCION = """Eres un especialista en validación de Calidad de Datos bancaria.

Se te entrega el texto de un documento que describe los controles de calidad de
datos que una entidad declara aplicar sobre su modelo.

TAREA
Identifica CADA control de calidad de datos descrito y conviértelo a formato
estructurado y ejecutable.

MOTORES DISPONIBLES (usa EXACTAMENTE uno de estos nombres en "tipo_motor"):
{catalogo}

Si un control descrito NO encaja en ningún motor disponible, usa
"tipo_motor": "narrativo" y explica en "nota" por qué no es automatizable.

Devuelve SOLO este JSON (sin markdown, sin texto alrededor):

{{
  "resumen_documento": "2-3 frases sobre qué cubre el documento",
  "controles": [
    {{
      "id_sugerido":    "DOC_01",
      "descripcion":    "texto del control tal como lo describe el documento",
      "cita_documento": "fragmento literal del documento donde aparece (máx 200 chars)",
      "tipo_motor":     "unicidad|duplicados|missing|outliers|rango|integridad_referencial|tipo_dato|completitud|narrativo",
      "dataset":        "nombre del dataset si se menciona, si no ''",
      "group_cols":     "columnas de agrupación separadas por coma, o ''",
      "campo_objetivo": "columna sobre la que aplica, o ''",
      "umbral":         0.0,
      "criticidad":     "ALTA|MEDIA|BAJA",
      "nota":           "aclaración si aplica, o ''",

      "min":            null,
      "max":            null,
      "tipo_esperado":  "",
      "dataset_ref":    "",
      "campo_ref":      "",
      "columnas_req":   "",
      "min_filas":      null
    }}
  ]
}}

REGLAS
- Extrae SOLO controles que el documento describa de verdad. NO inventes
  controles "que deberían existir": eso se analiza después como brecha.
- `cita_documento` debe ser texto LITERAL del documento, para trazabilidad.
- Si el documento menciona un umbral o tolerancia, refléjalo en `umbral`
  (proporción: 1% → 0.01). Si no lo menciona, deja 0.0.
- `criticidad` según el impacto que el propio documento le atribuya; si no
  lo dice, infiérela: integridad/unicidad de claves = ALTA.

PARÁMETROS ESPECÍFICOS — rellénalos SOLO cuando el motor los necesite:
- tipo_motor "rango"                  → `min` y `max` numéricos.
      Ej: "la Tasa debe estar entre 0 y 1"  → min: 0, max: 1
- tipo_motor "tipo_dato"              → `tipo_esperado`: "fecha"|"numerico"|"texto"
      Ej: "FechaApertura debe ser fecha válida" → tipo_esperado: "fecha"
- tipo_motor "integridad_referencial" → `dataset_ref` (dataset donde deben
      existir los valores) y `campo_ref` (columna en ese dataset).
      Ej: "todo Cliente debe existir en maestro_clientes"
          → dataset_ref: "maestro_clientes", campo_ref: "Cliente"
- tipo_motor "completitud"            → `columnas_req` (separadas por coma) y
      `min_filas` (entero).
      Ej: "al menos 1000 registros con las columnas A, B, C"
          → min_filas: 1000, columnas_req: "A, B, C"

Si el documento NO especifica alguno de estos parámetros, déjalo en null/"" —
NO inventes valores. El notebook marcará un TODO para que lo complete un humano.

DOCUMENTO:
```
{texto}
```

Devuelve SOLO el JSON."""


def extraer_controles_del_documento(texto: str, max_chars: int = 30000) -> Dict[str, Any]:
    """Usa el LLM para convertir la prosa del documento en controles estructurados."""
    from config import get_cliente_ia

    prompt = _PROMPT_EXTRACCION.format(
        catalogo=describir_motores(),
        texto=_mnc(texto[:max_chars], "documento_controles"),
    )
    try:
        cliente = get_cliente_ia()
        respuesta = cliente.generar_mensaje(prompt=prompt, max_tokens=8000)
    except Exception as exc:
        return {"_error": str(exc), "controles": [], "resumen_documento": ""}

    crudo = respuesta.strip()
    crudo = re.sub(r"^\s*```(?:json)?\s*", "", crudo)
    crudo = re.sub(r"\s*```\s*$", "", crudo).strip()
    try:
        return json.loads(crudo)
    except json.JSONDecodeError:
        # Extraer el primer objeto balanceado
        i = crudo.find("{")
        if i != -1:
            prof, en_str, esc = 0, False, False
            for j in range(i, len(crudo)):
                ch = crudo[j]
                if esc:
                    esc = False; continue
                if ch == "\\":
                    esc = True; continue
                if ch == '"':
                    en_str = not en_str; continue
                if en_str:
                    continue
                if ch == "{":
                    prof += 1
                elif ch == "}":
                    prof -= 1
                    if prof == 0:
                        try:
                            return json.loads(crudo[i:j + 1])
                        except json.JSONDecodeError:
                            break
        return {"_error": "El LLM no devolvió JSON válido",
                "_raw": crudo[:1000], "controles": [], "resumen_documento": ""}


# ═════════════════════════════════════════════════════════════════════════════
# 3. LECTURA DE ControlesData.xlsx
# ═════════════════════════════════════════════════════════════════════════════

def leer_controles_excel(path: Path) -> List[Dict[str, Any]]:
    """Lee la hoja 'Controles' y normaliza cada fila."""
    import pandas as pd
    path = Path(path)
    if not path.exists():
        return []

    hojas = pd.ExcelFile(path).sheet_names
    hoja = "Controles" if "Controles" in hojas else hojas[0]
    df = pd.read_excel(path, sheet_name=hoja)

    def _s(v) -> str:
        if v is None:
            return ""
        t = str(v).strip()
        return "" if t.lower() in ("nan", "none", "nat") else t

    controles = []
    for _, row in df.iterrows():
        cid = _s(row.get("ID_CONTROL"))
        if not cid:
            continue
        usa_motor = _s(row.get("USA_MOTOR_DATA")) in ("1", "1.0", "True", "true", "SI", "sí")
        try:
            umbral = float(row.get("UMBRAL")) if _s(row.get("UMBRAL")) else 0.0
        except (TypeError, ValueError):
            umbral = 0.0
        controles.append({
            "id_control":     cid,
            "descripcion":    _s(row.get("PROMPT_CONTROL")),
            "usa_motor":      usa_motor,
            "tipo_motor":     _s(row.get("TIPO_MOTOR")).lower() or ("narrativo" if not usa_motor else ""),
            "dataset":        _s(row.get("DATASET")),
            "group_cols":     _s(row.get("GROUP_COLS")),
            "campo_objetivo": _s(row.get("CAMPO_OBJETIVO")),
            "umbral":         umbral,
            "accion":         _s(row.get("ACCION")),
            "activo":         _s(row.get("ACTIVO")) in ("1", "1.0", "True", "true", ""),
            "comentario":     _s(row.get("COMENTARIO")),
        })
    return controles


# ═════════════════════════════════════════════════════════════════════════════
# 4. ANÁLISIS DE BRECHAS
# ═════════════════════════════════════════════════════════════════════════════

_PALABRAS_VACIAS = {
    "de", "la", "el", "los", "las", "en", "que", "y", "o", "del", "por", "para",
    "con", "un", "una", "se", "su", "sus", "al", "lo", "es", "sobre", "the", "of",
    "valida", "validar", "verificar", "verifica", "revisar", "revisión", "control",
}


def _firma(texto: str, tipo: str = "", campo: str = "", grupo: str = "") -> set:
    """Conjunto de tokens significativos para comparar controles heurísticamente."""
    base = f"{tipo} {campo} {grupo} {texto}".lower()
    toks = re.findall(r"[a-záéíóúñ_]{3,}", base)
    return {t for t in toks if t not in _PALABRAS_VACIAS}


def _similitud(a: set, b: set) -> float:
    """Jaccard entre dos firmas."""
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def _norm(txt: str) -> str:
    """Normaliza un nombre de columna para comparar (minúsculas, sin espacios)."""
    return re.sub(r"[^a-z0-9]", "", str(txt or "").lower())


def _score_par(cd: Dict[str, Any], ce: Dict[str, Any]) -> float:
    """
    Puntúa el parecido entre un control del documento y uno del Excel.

    Ponderación (la señal ESTRUCTURAL manda sobre la léxica):
        campo_objetivo coincide  → +0.45   ← señal más fuerte
        group_cols coinciden     → +0.25
        tipo_motor coincide      → +0.20
        solapamiento léxico      → hasta +0.30

    Por qué: un control se identifica por QUÉ campo valida y CÓMO lo agrupa,
    no por cómo está redactado. Con puntuación solo léxica, "unicidad Cliente
    por Cuenta" se emparejaba con "unicidad de Tasa por Cuenta" — mismo texto
    casi entero, campo distinto: un falso positivo que oculta una brecha real.
    """
    score = 0.0

    campo_d, campo_e = _norm(cd.get("campo_objetivo")), _norm(ce.get("campo_objetivo"))
    if campo_d and campo_e:
        if campo_d == campo_e:
            score += 0.45
        else:
            score -= 0.30          # campos distintos → penalización explícita

    grupos_d = {_norm(g) for g in (cd.get("group_cols") or "").split(",") if g.strip()}
    grupos_e = {_norm(g) for g in (ce.get("group_cols") or "").split(",") if g.strip()}
    if grupos_d and grupos_e:
        score += 0.25 * (len(grupos_d & grupos_e) / len(grupos_d | grupos_e))

    tipo_d, tipo_e = (cd.get("tipo_motor") or "").lower(), (ce.get("tipo_motor") or "").lower()
    if tipo_d and tipo_e:
        if tipo_d == tipo_e:
            score += 0.20 if tipo_d != "narrativo" else 0.10
        else:
            # Distinta prueba sobre el mismo campo NO es el mismo control:
            # "rango de Tasa" y "unicidad de Tasa" validan cosas diferentes.
            # Sin esta penalización, el campo compartido bastaba para emparejarlos
            # y una brecha real quedaba oculta.
            score -= 0.40

    fd = _firma(cd.get("descripcion", ""))
    fe = _firma(ce.get("descripcion", ""))
    score += 0.30 * _similitud(fd, fe)

    return score


def analizar_brechas(
    controles_doc: List[Dict[str, Any]],
    controles_excel: List[Dict[str, Any]],
    umbral_similitud: float = 0.35,
) -> Dict[str, Any]:
    """
    Cruza los controles del documento con los del Excel.

    Emparejamiento GLOBAL (no voraz): se calculan todos los pares posibles, se
    ordenan por puntuación descendente y se asignan de mayor a menor. Así el
    mejor par absoluto se decide primero, en vez de que el primer control del
    documento "reserve" un control del Excel que encajaba mejor con otro.

    Deliberadamente CONSERVADOR: ante la duda no empareja, para que el control
    aparezca como brecha y lo revise un humano. Es preferible un falso "no
    documentado" que ocultar un control prometido y nunca ejecutado.
    """
    # 1) Todos los pares con su puntuación
    pares = []
    for i, cd in enumerate(controles_doc):
        for j, ce in enumerate(controles_excel):
            s = _score_par(cd, ce)
            if s >= umbral_similitud:
                pares.append((s, i, j))
    pares.sort(key=lambda t: -t[0])

    # 2) Asignación global: el mejor par disponible gana
    doc_usados: set = set()
    excel_usados: set = set()
    emparejados: List[Dict[str, Any]] = []
    for s, i, j in pares:
        if i in doc_usados or j in excel_usados:
            continue
        doc_usados.add(i)
        excel_usados.add(j)
        emparejados.append({
            "doc": controles_doc[i],
            "excel": controles_excel[j],
            "similitud": round(s, 3),
        })

    solo_doc = [c for i, c in enumerate(controles_doc) if i not in doc_usados]
    solo_excel = [c for j, c in enumerate(controles_excel) if j not in excel_usados]
    usados_excel = {controles_excel[j]["id_control"] for j in excel_usados}

    total = len(controles_doc) + len(solo_excel)
    cobertura = round(len(emparejados) / len(controles_doc), 3) if controles_doc else 0.0

    return {
        "en_ambos": emparejados,
        "solo_documento": solo_doc,
        "solo_excel": solo_excel,
        "metricas": {
            "n_doc": len(controles_doc),
            "n_excel": len(controles_excel),
            "n_en_ambos": len(emparejados),
            "n_solo_doc": len(solo_doc),
            "n_solo_excel": len(solo_excel),
            "cobertura_documento": cobertura,
            "total_controles_unicos": total,
        },
    }


# ═════════════════════════════════════════════════════════════════════════════
# 5. GENERACIÓN DEL NOTEBOOK
# ═════════════════════════════════════════════════════════════════════════════

def _md(t: str) -> nbf.NotebookNode: return nbf.v4.new_markdown_cell(t)
def _code(c: str) -> nbf.NotebookNode: return nbf.v4.new_code_cell(c)


def _codigo_control(ctrl: Dict[str, Any], var_df: str = "df") -> str:
    """
    Genera el código pandas de un control usando el catálogo de motores.

    Incluye los parámetros ESPECÍFICOS de cada motor. Sin ellos, los motores
    `rango` (necesita MIN/MAX), `tipo_dato` (TIPO_ESPERADO),
    `integridad_referencial` (dataset de referencia) y `completitud`
    (COLUMNAS_REQ/MIN_FILAS) fallaban con "Falta ... en la configuración".
    """
    tipo = (ctrl.get("tipo_motor") or "narrativo").lower()
    campo = ctrl.get("campo_objetivo") or ""
    grupos = [g.strip() for g in (ctrl.get("group_cols") or "").split(",") if g.strip()]
    umbral = ctrl.get("umbral", 0.0)
    cid = ctrl.get("id_sugerido") or ctrl.get("id_control") or "CTRL"

    if tipo == "narrativo" or tipo not in REGISTRO_MOTORES:
        return (
            f"# {cid} — CONTROL NARRATIVO (no automatizable)\n"
            f"# {ctrl.get('descripcion','')[:200]}\n"
            f"# Requiere revisión documental por el validador.\n"
            f"resultados['{cid}'] = {{'tipo_motor': 'narrativo',\n"
            f"                        'estado': 'REVISION_MANUAL',\n"
            f"                        'detalle': {ctrl.get('descripcion','')[:120]!r}}}\n"
            f"print(f\"[REVISION_MANUAL] {cid}: requiere revisión documental\")"
        )

    # ── Parámetros comunes ───────────────────────────────────────────────────
    lineas_cfg = [
        f"    'control_id': {cid!r},",
        f"    'tipo_motor': {tipo!r},",
        f"    'group_cols': {grupos!r},",
        f"    'campo_objetivo': {campo!r},",
        f"    'umbral': {umbral},",
    ]

    # ── Parámetros específicos por motor ─────────────────────────────────────
    extra_previo = ""
    if tipo == "rango":
        vmin = ctrl.get("min", ctrl.get("valor_min"))
        vmax = ctrl.get("max", ctrl.get("valor_max"))
        lineas_cfg.append(f"    'min': {vmin!r},")
        lineas_cfg.append(f"    'max': {vmax!r},")
        if vmin is None and vmax is None:
            extra_previo = (
                f"# ⚠️ TODO: el documento no especificó MIN/MAX para este control.\n"
                f"#    Edita cfg['min'] y cfg['max'] antes de ejecutar.\n"
            )

    elif tipo == "tipo_dato":
        lineas_cfg.append(f"    'tipo_esperado': {ctrl.get('tipo_esperado', 'fecha')!r},")

    elif tipo == "completitud":
        cols_req = [c.strip() for c in str(ctrl.get("columnas_req", "")).split(",") if c.strip()]
        lineas_cfg.append(f"    'columnas_req': {cols_req!r},")
        lineas_cfg.append(f"    'min_filas': {int(ctrl.get('min_filas') or 1)},")

    elif tipo == "integridad_referencial":
        ds_ref = ctrl.get("dataset_ref") or ctrl.get("dataset_referencia") or ""
        campo_ref = ctrl.get("campo_ref") or campo
        lineas_cfg.append(f"    'campo_ref': {campo_ref!r},")
        lineas_cfg.append(f"    '_df_ref': datasets.get({ds_ref!r}),")
        extra_previo = (
            f"# Dataset de referencia: {ds_ref or '(no especificado en el documento)'}\n"
            f"if datasets.get({ds_ref!r}) is None:\n"
            f"    print(f\"⚠️  Dataset de referencia {ds_ref!r} no encontrado en {{DATASETS_DIR}}\")\n"
        )

    cfg_txt = "cfg = {\n" + "\n".join(lineas_cfg) + "\n}"
    return (
        f"# {cid} — {tipo}\n"
        f"{extra_previo}"
        f"{cfg_txt}\n"
        f"r = ejecutar_motor({tipo!r}, {var_df}, cfg)\n"
        f"resultados[{cid!r}] = r\n"
        f"print(f\"[{{r['estado']}}] {cid}: {{r['detalle'] or r['error']}}\")"
    )


def construir_notebook_controles(
    plan_doc: Dict[str, Any],
    brechas: Dict[str, Any],
    ruta_doc: Path,
    ruta_excel: Optional[Path],
    carpeta_datasets: Path,
    carpeta_salida: Optional[Path] = None,   # [SALIDAS-FIX] destino de resultados
) -> nbf.NotebookNode:
    nb = nbf.v4.new_notebook()
    c: List[nbf.NotebookNode] = []
    m = brechas["metricas"]
    # [SALIDAS-FIX] Destino de los resultados dentro de outputs/YYYY-MM-DD/.
    # Sin carpeta_salida se cae a outputs/<fecha>/controles/ — NUNCA al CWD,
    # que era el comportamiento anterior y dejaba el JSON en la raíz del repo.
    if carpeta_salida is None:
        carpeta_salida = (
            Path(__file__).parent.parent / "outputs"
            / datetime.now().strftime("%Y-%m-%d") / "controles"
        )
    _destino_resultados = Path(carpeta_salida) / "resultados_controles.json"

    # ── Cabecera con el veredicto de brechas ────────────────────────────────
    if m["n_solo_doc"] > 0:
        cabecera = (
            f"> # ⚠️ {m['n_solo_doc']} control(es) DOCUMENTADO(S) PERO NO EJECUTADO(S)\n\n"
            f"> El manual describe controles que no están en `ControlesData.xlsx`.\n"
            f"> Ver §4 Análisis de brechas."
        )
    else:
        cabecera = "> # ✅ Todos los controles del documento tienen contrapartida ejecutable"
    c.append(_md(cabecera))

    c.append(_md(
        f"# Controles de Calidad de Datos — réplica ejecutable\n\n"
        f"**Documento origen:** `{ruta_doc.name}`  \n"
        f"**Excel de controles:** `{ruta_excel.name if ruta_excel else '(no provisto)'}`  \n"
        f"**Generado:** {datetime.now():%Y-%m-%d %H:%M}\n\n"
        f"---\n\n"
        f"## Resumen del documento\n\n{plan_doc.get('resumen_documento','(sin resumen)')}\n\n"
        f"## Cobertura\n\n"
        f"| Métrica | Valor |\n|---|---:|\n"
        f"| Controles descritos en el documento | {m['n_doc']} |\n"
        f"| Controles definidos en el Excel | {m['n_excel']} |\n"
        f"| Documentados **y** ejecutados | {m['n_en_ambos']} |\n"
        f"| 📄 Solo en documento (no ejecutados) | **{m['n_solo_doc']}** |\n"
        f"| ⚙️ Solo en Excel (no documentados) | **{m['n_solo_excel']}** |\n"
        f"| Cobertura del documento | {m['cobertura_documento']:.0%} |\n"
    ))

    # ── Setup ───────────────────────────────────────────────────────────────
    c.append(_md("## 0. Configuración"))
    c.append(_code(
        "import sys, json\n"
        "from pathlib import Path\n"
        "import pandas as pd\n"
        "import numpy as np\n\n"
        f"PROYECTO = Path(r'{Path.cwd()}')\n"
        "if str(PROYECTO) not in sys.path:\n"
        "    sys.path.insert(0, str(PROYECTO))\n\n"
        "from modulos.motores_datos import ejecutar_motor, cargar_datasets, describir_motores\n\n"
        "resultados = {}\n"
        "print('Motores disponibles:')\n"
        "print(describir_motores())"
    ))

    # ── 1. Carga de datos ───────────────────────────────────────────────────
    c.append(_md(
        "## 1. Inputs — carga de datasets\n\n"
        f"Los datasets se leen de `{carpeta_datasets}`. "
        "El nombre de cada dataset es el del archivo sin extensión."
    ))
    c.append(_code(
        f"DATASETS_DIR = Path(r'{carpeta_datasets}')\n"
        "datasets = cargar_datasets(DATASETS_DIR)\n"
        "print(f'{len(datasets)} dataset(s) cargado(s): {list(datasets)}')\n"
        "for nombre, d in datasets.items():\n"
        "    print(f'  {nombre}: {d.shape[0]:,} filas x {d.shape[1]} columnas')"
    ))

    datasets_usados = sorted({
        cd.get("dataset", "") for cd in plan_doc.get("controles", []) if cd.get("dataset")
    })
    principal = datasets_usados[0] if datasets_usados else "data_subset"
    c.append(_code(
        f"# Dataset principal referenciado por los controles\n"
        f"NOMBRE_DATASET = {principal!r}\n"
        f"df = datasets.get(NOMBRE_DATASET)\n"
        f"if df is None:\n"
        f"    print(f'⚠️  No se encontró el dataset {{NOMBRE_DATASET!r}}.')\n"
        f"    print(f'    Coloca el archivo en {{DATASETS_DIR}} y re-ejecuta.')\n"
        f"else:\n"
        f"    display(df.head())"
    ))

    # ── 2. Perfilado ────────────────────────────────────────────────────────
    c.append(_md("## 2. Calidad de datos — perfilado general"))
    c.append(_code(
        "if df is not None:\n"
        "    perfil = pd.DataFrame({\n"
        "        'tipo':     df.dtypes.astype(str),\n"
        "        'n_nulos':  df.isna().sum(),\n"
        "        'pct_nulos': (df.isna().mean() * 100).round(2),\n"
        "        'n_unicos': df.nunique(),\n"
        "    })\n"
        "    display(perfil)\n"
        "    print(f'Filas: {len(df):,} | Duplicados exactos: {df.duplicated().sum():,}')"
    ))

    # ── 3. Controles del documento ──────────────────────────────────────────
    c.append(_md(
        "## 3. Motor de tratamiento — controles descritos en el documento\n\n"
        "Cada control se ejecuta con el motor correspondiente del catálogo."
    ))
    for ctrl in plan_doc.get("controles", []):
        cid = ctrl.get("id_sugerido", "CTRL")
        c.append(_md(
            f"### {cid} — {ctrl.get('tipo_motor','?')} "
            f"({ctrl.get('criticidad','?')})\n\n"
            f"{ctrl.get('descripcion','')}\n\n"
            f"> **Cita del documento:** _{ctrl.get('cita_documento','—')}_"
            + (f"\n>\n> **Nota:** {ctrl['nota']}" if ctrl.get("nota") else "")
        ))
        c.append(_code(_codigo_control(ctrl)))

    # ── 4. Brechas ──────────────────────────────────────────────────────────
    c.append(_md("## 4. Análisis de brechas — documento vs. Excel de controles"))

    if brechas["en_ambos"]:
        filas = ["### ✅ Documentados y ejecutados\n",
                 "| Control (doc) | Control (Excel) | Motor | Similitud |",
                 "|---|---|---|---:|"]
        for e in brechas["en_ambos"]:
            filas.append(
                f"| {e['doc'].get('id_sugerido','?')}: {e['doc'].get('descripcion','')[:45]} "
                f"| {e['excel']['id_control']} "
                f"| {e['excel'].get('tipo_motor','—')} | {e['similitud']:.2f} |"
            )
        c.append(_md("\n".join(filas)))

    if brechas["solo_documento"]:
        filas = [
            "### 📄 SOLO en el documento — prometidos pero NO ejecutados\n",
            "> **Hallazgo de validación.** El manual declara estos controles pero "
            "no existen en `ControlesData.xlsx`, por lo que nadie los está ejecutando.\n",
            "| ID | Control | Motor sugerido | Criticidad |",
            "|---|---|---|---|",
        ]
        for cd in brechas["solo_documento"]:
            filas.append(
                f"| {cd.get('id_sugerido','?')} | {cd.get('descripcion','')[:60]} "
                f"| {cd.get('tipo_motor','—')} | {cd.get('criticidad','—')} |"
            )
        c.append(_md("\n".join(filas)))

    if brechas["solo_excel"]:
        filas = [
            "### ⚙️ SOLO en el Excel — ejecutados pero NO documentados\n",
            "> **Hallazgo de gobierno.** Se ejecutan controles que el manual no "
            "describe: el documento no refleja el proceso real.\n",
            "| ID | Control | Motor |",
            "|---|---|---|",
        ]
        for ce in brechas["solo_excel"]:
            filas.append(
                f"| {ce['id_control']} | {ce.get('descripcion','')[:60]} "
                f"| {ce.get('tipo_motor','—')} |"
            )
        c.append(_md("\n".join(filas)))

    # ── 5. Outputs ──────────────────────────────────────────────────────────
    c.append(_md("## 5. Outputs — consolidado de resultados"))
    c.append(_code(
        "if resultados:\n"
        "    resumen = pd.DataFrame([\n"
        "        {'control': k,\n"
        "         'tipo': v.get('tipo_motor', v.get('tipo', '—')),\n"
        "         'estado': v.get('estado', '—'),\n"
        "         'hallazgos': v.get('n_hallazgos', 0),\n"
        "         'tasa_error': v.get('tasa_error', 0),\n"
        "         'detalle': str(v.get('detalle', v.get('error', '')))[:70]}\n"
        "        for k, v in resultados.items()\n"
        "    ])\n"
        "    display(resumen)\n"
        "    print()\n"
        "    print(resumen['estado'].value_counts().to_string())\n"
        "else:\n"
        "    print('Sin resultados: revisa que el dataset se haya cargado.')"
    ))
    # [SALIDAS-FIX] Antes: Path('resultados_controles.json') → se escribía en el
    # CWD de quien ejecutara el notebook (normalmente la raíz del proyecto),
    # fuera de la convención outputs/YYYY-MM-DD/. Ahora la ruta se fija en
    # generación, apuntando a la misma carpeta del notebook.
    c.append(_code(
        "# Persistir para trazabilidad — respeta la convención outputs/YYYY-MM-DD/\n"
        f"SALIDA_RESULTADOS = Path(r'{_destino_resultados}')\n"
        "SALIDA_RESULTADOS.parent.mkdir(parents=True, exist_ok=True)\n"
        "SALIDA_RESULTADOS.write_text(\n"
        "    json.dumps(resultados, indent=2, ensure_ascii=False, default=str),\n"
        "    encoding='utf-8')\n"
        "print(f'Resultados guardados en {SALIDA_RESULTADOS}')"
    ))

    if plan_doc.get("_error"):
        c.append(_md(
            f"> ## ⚠️ Extracción parcial\n\n"
            f"> El LLM no pudo estructurar todo el documento: `{plan_doc['_error']}`\n\n"
            f"> Revisa el documento manualmente."
        ))

    nb["cells"] = c
    nb["metadata"] = {
        "kernelspec": {"name": "python3", "display_name": "Python 3"},
        "generado_por": "virf_agent controles_a_notebook",
        "documento_origen": ruta_doc.name,
        "metricas_brechas": m,
    }
    return nb


# ═════════════════════════════════════════════════════════════════════════════
# 6. ORQUESTADOR
# ═════════════════════════════════════════════════════════════════════════════

def generar_notebook_controles(
    ruta_documento: Path,
    ruta_excel: Optional[Path],
    carpeta_salida: Path,
    carpeta_datasets: Optional[Path] = None,
    usar_llm: bool = True,
) -> Tuple[Path, Dict[str, Any]]:
    """Pipeline completo: documento → controles → notebook + brechas."""
    ruta_documento = Path(ruta_documento)
    carpeta_salida = Path(carpeta_salida)
    carpeta_datasets = Path(carpeta_datasets or (ruta_documento.parent / "datasets"))

    print(f"\n{'═' * 70}")
    print("  📋 CONTROLES DE DATOS → NOTEBOOK")
    print(f"  Documento: {ruta_documento.name}")
    print(f"  Excel    : {ruta_excel.name if ruta_excel else '(no provisto)'}")
    print(f"{'═' * 70}\n")

    print("  📖 Leyendo documento...")
    texto = leer_documento(ruta_documento)
    print(f"     {len(texto):,} chars extraídos")

    if usar_llm:
        print("  🤖 Extrayendo controles descritos (LLM)...")
        plan = extraer_controles_del_documento(texto)
        if plan.get("_error"):
            print(f"     ⚠️  {plan['_error'][:100]}")
    else:
        plan = {"resumen_documento": "(sin LLM)", "controles": []}
    print(f"     {len(plan.get('controles', []))} control(es) identificado(s)")

    controles_excel = leer_controles_excel(ruta_excel) if ruta_excel else []
    print(f"  📊 Excel: {len(controles_excel)} control(es)")

    print("  🔍 Analizando brechas...")
    brechas = analizar_brechas(plan.get("controles", []), controles_excel)
    m = brechas["metricas"]
    print(f"     ✅ en ambos      : {m['n_en_ambos']}")
    print(f"     📄 solo documento: {m['n_solo_doc']}  ← prometidos, NO ejecutados")
    print(f"     ⚙️  solo Excel    : {m['n_solo_excel']}  ← ejecutados, NO documentados")

    nb = construir_notebook_controles(plan, brechas, ruta_documento,
                                      ruta_excel, carpeta_datasets,
                                      carpeta_salida=carpeta_salida)

    carpeta_salida.mkdir(parents=True, exist_ok=True)
    out = carpeta_salida / f"controles_{ruta_documento.stem}.ipynb"
    with open(out, "w", encoding="utf-8") as f:
        nbf.write(nb, f)

    rep = carpeta_salida / f"brechas_{ruta_documento.stem}.json"
    with open(rep, "w", encoding="utf-8") as f:
        json.dump({
            "documento": ruta_documento.name,
            "excel": ruta_excel.name if ruta_excel else None,
            "generado": datetime.now().isoformat(timespec="seconds"),
            "resumen_documento": plan.get("resumen_documento", ""),
            "metricas": m,
            "solo_documento": brechas["solo_documento"],
            "solo_excel": brechas["solo_excel"],
            "en_ambos": [
                {"doc_id": e["doc"].get("id_sugerido"),
                 "excel_id": e["excel"]["id_control"],
                 "similitud": e["similitud"]}
                for e in brechas["en_ambos"]
            ],
        }, f, indent=2, ensure_ascii=False, default=str)

    print(f"\n  ✅ Notebook: {out.name}")
    print(f"  📋 Brechas : {rep.name}")
    print(f"{'═' * 70}\n")
    return out, brechas
