"""
Capturas de evidencia para los informes Word («pantallazos»), sin IA.

El agente cita texto («Manual.pdf → "λ = 0.94"», contradicciones manual ↔
código). Este módulo convierte esas citas en IMÁGENES que el lector puede
contrastar con su propio documento:

  · captura_portada(pdf)                 → la primera página del documento.
  · captura_cita(documento, cita)        → la página del PDF donde aparece la
                                           cita, con el fragmento resaltado; en
                                           .md/.txt/.docx, el pasaje como
                                           «página» de texto resaltada.
  · captura_codigo(fragmento, archivo)   → el código en estilo editor, con
                                           números de línea y las líneas del
                                           fragmento resaltadas (si se encuentra
                                           el fichero, con contexto alrededor).

Todo es determinista (pypdfium2 + Pillow) y se cachea por contenido en la
carpeta que indique el llamante, así que regenerar un informe no repite el
trabajo. Si algo no se puede capturar se devuelve None: un informe sin captura
es aceptable; un informe que falla por una captura, no.
"""
from __future__ import annotations

import hashlib
import logging
import re
import textwrap
import unicodedata
from pathlib import Path
from typing import Iterable, Optional

logger = logging.getLogger("virf.capturas")

EXT_DOC = (".pdf", ".md", ".txt", ".docx")
EXT_CODIGO = (".py", ".r", ".sql", ".sas", ".ipynb", ".js", ".java", ".scala", ".m", ".jl")
_EXCLUIR = ("rag", "repositorio_controles", "__pycache__", ".git", "logoempresa")

# Estética de las capturas de código (tema claro, como el bloque de código del Word).
_FONDO, _MARGEN_NUM, _TINTA = (250, 250, 251), (240, 241, 244), (36, 41, 47)
_NUM, _RESALTE, _BORDE = (140, 149, 159), (255, 241, 168), (208, 215, 222)
_RESALTE_PDF = (255, 214, 0, 90)


# ── Utilidades ────────────────────────────────────────────────────────

def _norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s or "")
    s = "".join(c for c in s if not unicodedata.combining(c)).lower()
    return re.sub(r"\s+", " ", s).strip()


def _tokens(s: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]{3,}", _norm(s))}


def _clave(*partes) -> str:
    return hashlib.sha256("\x1f".join(map(str, partes)).encode("utf-8")).hexdigest()[:20]


def localizar(nombre: str, raices: Iterable[Path]) -> Optional[Path]:
    """Primer fichero con ese nombre (sin distinguir mayúsculas) bajo las raíces."""
    if not nombre:
        return None
    limpio = Path(str(nombre).strip().strip("\"'")).name
    # El nombre puede venir con palabras delante («y seguimiento.md»): se prueba
    # el nombre completo y luego sin cada palabra inicial.
    palabras = limpio.split(" ")
    objetivos = [" ".join(palabras[i:]).lower() for i in range(len(palabras))]
    raices = [Path(r) for r in raices if Path(r).is_dir()]
    for objetivo in objetivos:
        for raiz in raices:
            for p in raiz.rglob("*"):
                if p.is_file() and p.name.lower() == objetivo and not any(
                        x in _EXCLUIR
                        for x in (q.lower() for q in p.relative_to(raiz).parts[:-1])):
                    return p
    return None


# Conectores que el agente pone entre dos citas («… y seguimiento.md → …»).
_RE_CONECTOR = re.compile(r"^(?:(?:y|e|o|and|en|de|del|la|el|ver|segun|según)\s+)+",
                          re.IGNORECASE)
_RE_EVIDENCIA = re.compile(r"([\w\-. ()]+\.(?:pdf|md|txt|docx))\s*→\s*[\"'«“]([^\"'»”]{8,})",
                           re.IGNORECASE)


def citas_en_evidencia(texto: str) -> list[tuple[str, str]]:
    """«Archivo.pdf → "cita"» → [(archivo, cita)], en el orden del texto."""
    return [(_RE_CONECTOR.sub("", m.group(1).strip()), m.group(2).strip())
            for m in _RE_EVIDENCIA.finditer(texto or "")]


def _fuente(size: int, mono: bool = True):
    from PIL import ImageFont
    nombres = (("consola.ttf", "Consolas.ttf", "DejaVuSansMono.ttf", "cour.ttf") if mono
               else ("segoeui.ttf", "arial.ttf", "DejaVuSans.ttf"))
    for n in nombres:
        try:
            return ImageFont.truetype(n, size)
        except OSError:
            continue
    return ImageFont.load_default()


# ── PDF ───────────────────────────────────────────────────────────────

# Texto normalizado por página, extraído UNA vez por documento (un manual de 300
# páginas tarda segundos en leerse; un informe cita el mismo manual decenas de veces).
_TEXTOS_PDF: dict[tuple[str, float], list[str]] = {}


def _textos_pdf(ruta: Path, pdf) -> list[str]:
    clave = (str(ruta), ruta.stat().st_mtime)
    if clave not in _TEXTOS_PDF:
        _TEXTOS_PDF[clave] = [_norm(pdf[i].get_textpage().get_text_range())
                              for i in range(len(pdf))]
    return _TEXTOS_PDF[clave]


def _pagina_de(ruta: Path, pdf, cita: str) -> tuple[Optional[int], list, bool]:
    """
    (índice de página, rectángulos de la cita, exacta). Primero busca la cita
    literal (completa, su primera frase o sus primeros 60 caracteres) en el
    texto de cada página; solo en esa página se piden los rectángulos para
    resaltarla. Si el PDF no la trae literal (fórmulas, guiones partidos), elige
    la página con más palabras en común y lo marca como NO exacta.
    """
    textos = _textos_pdf(ruta, pdf)
    candidatos = [cita.strip()]
    if len(cita) > 60:
        candidatos.append(cita.strip()[:60])
    # Cada tramo de la cita por separado («Versión: Manual LaR v4.2» → «Manual
    # LaR v4.2»): el agente a veces junta una etiqueta y el texto que la sigue.
    candidatos += sorted((t.strip() for t in re.split(r"[.;:\n]", cita) if len(t.strip()) >= 12),
                         key=len, reverse=True)
    for c in candidatos:
        nc = _norm(c)
        if len(nc) < 6:
            continue
        for i, t in enumerate(textos):
            if nc in t:
                tp = pdf[i].get_textpage()
                occ = tp.search(c, match_case=False).get_next()
                rects = ([tp.get_rect(k) for k in range(tp.count_rects(*occ))]
                         if occ else [])
                return i, rects, True
    objetivo = _tokens(cita)
    if not objetivo:
        return None, [], False
    mejor, mejor_score = None, 0.0
    for i, t in enumerate(textos):
        score = len(objetivo & set(re.findall(r"[a-z0-9]{3,}", t))) / len(objetivo)
        if score > mejor_score:
            mejor, mejor_score = i, score
    return (mejor, [], False) if mejor_score >= 0.6 else (None, [], False)


def _render_pdf(ruta: Path, indice: int, destino: Path, rects: list,
                escala: float = 1.6) -> Path:
    import pypdfium2 as pdfium
    from PIL import Image, ImageDraw
    pdf = pdfium.PdfDocument(str(ruta))
    try:
        pagina = pdf[indice]
        alto = pagina.get_height()
        img = pagina.render(scale=escala).to_pil().convert("RGBA")
    finally:
        pdf.close()
    if rects:
        capa = Image.new("RGBA", img.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(capa)
        for (izq, abajo, der, arriba) in rects:
            d.rectangle([izq * escala - 2, (alto - arriba) * escala - 2,
                         der * escala + 2, (alto - abajo) * escala + 2], fill=_RESALTE_PDF)
        img = Image.alpha_composite(img, capa)
    img = img.convert("RGB")
    # Marco fino para que la página se distinga del blanco del informe.
    ImageDraw.Draw(img).rectangle([0, 0, img.width - 1, img.height - 1], outline=_BORDE, width=2)
    destino.parent.mkdir(parents=True, exist_ok=True)
    img.save(destino, "PNG", optimize=True)
    return destino


def captura_portada(pdf_ruta: Path, carpeta: Path) -> Optional[Path]:
    """Primera página del PDF. None si no es un PDF legible."""
    pdf_ruta = Path(pdf_ruta)
    if _restringido(pdf_ruta):
        return None
    if pdf_ruta.suffix.lower() != ".pdf" or not pdf_ruta.is_file():
        return None
    destino = Path(carpeta) / f"portada_{_clave(pdf_ruta.name, pdf_ruta.stat().st_size)}.png"
    if destino.is_file():
        return destino
    try:
        return _render_pdf(pdf_ruta, 0, destino, [], escala=1.2)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("sin portada de %s: %s", pdf_ruta.name, exc)
        return None


# ── Texto (md/txt/docx) y código ─────────────────────────────────────

def _leer(ruta: Path) -> str:
    if ruta.suffix.lower() == ".docx":
        try:
            import docx
            return "\n".join(p.text for p in docx.Document(str(ruta)).paragraphs)
        except Exception:                             # noqa: BLE001
            return ""
    if ruta.suffix.lower() == ".ipynb":
        try:
            import json
            nb = json.loads(ruta.read_text(encoding="utf-8", errors="ignore"))
            return "\n".join("".join(c.get("source") or []) for c in nb.get("cells", [])
                             if c.get("cell_type") == "code")
        except Exception:                             # noqa: BLE001
            return ""
    return ruta.read_text(encoding="utf-8", errors="ignore")


def _lineas_de(lineas: list[str], cita: str) -> list[int]:
    """Índices de las líneas que contienen la cita (exacta o por solape)."""
    nc = _norm(cita)
    if not nc:
        return []
    texto = [_norm(l) for l in lineas]
    # Exacta en una línea o en una ventana de hasta 6 líneas consecutivas.
    for ancho in range(1, 7):
        for i in range(len(texto) - ancho + 1):
            if nc[:80] in " ".join(texto[i:i + ancho]):
                return list(range(i, i + ancho))
    objetivo = _tokens(cita)
    if not objetivo:
        return []
    puntos = [(len(objetivo & _tokens(l)) / len(objetivo), i) for i, l in enumerate(lineas)]
    puntos.sort(reverse=True)
    if puntos and puntos[0][0] >= 0.5:
        return sorted(i for s, i in puntos[:3] if s >= 0.5 * puntos[0][0])
    return []


def _render_lineas(lineas: list[str], primera: int, resaltar: set[int], titulo: str,
                   destino: Path, mono: bool = True) -> Path:
    from PIL import Image, ImageDraw
    f = _fuente(19, mono=mono)
    ft = _fuente(17, mono=False)
    ancho_txt = 96 if mono else 92
    filas: list[tuple[Optional[int], str, bool]] = []
    for k, l in enumerate(lineas):
        n = primera + k
        trozos = textwrap.wrap(l.expandtabs(4), ancho_txt, replace_whitespace=False,
                               drop_whitespace=False) or [""]
        for j, t in enumerate(trozos):
            filas.append((n if j == 0 else None, t, k in resaltar))
    alto_fila, margen_num, pad = 27, 70, 14
    alto_tit = 40
    w = margen_num + pad * 2 + int(f.getlength("M") * ancho_txt) if hasattr(f, "getlength") else 1400
    h = alto_tit + pad + alto_fila * len(filas) + pad
    img = Image.new("RGB", (w, h), _FONDO)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, w, alto_tit], fill=(231, 236, 244))
    d.text((pad, 10), titulo, font=ft, fill=(31, 56, 100))
    d.rectangle([0, alto_tit, margen_num, h], fill=_MARGEN_NUM)
    y = alto_tit + pad
    for n, t, res in filas:
        if res:
            d.rectangle([margen_num, y - 2, w, y + alto_fila - 4], fill=_RESALTE)
        if n is not None:
            d.text((8, y), f"{n:>4}", font=f, fill=_NUM)
        d.text((margen_num + pad, y), t, font=f, fill=_TINTA)
        y += alto_fila
    d.rectangle([0, 0, w - 1, h - 1], outline=_BORDE, width=2)
    destino.parent.mkdir(parents=True, exist_ok=True)
    img.save(destino, "PNG", optimize=True)
    return destino


def _restringido(ruta) -> bool:
    """[SEG-06] Lo clasificado Restringido nunca se renderiza a PNG."""
    try:
        from modulos.almacenamiento import es_restringido
        return ruta is not None and es_restringido(Path(ruta))
    except Exception:                                       # noqa: BLE001
        return True                                         # ante la duda, no capturar


def captura_codigo(fragmento: str, carpeta: Path, archivo: Optional[Path] = None,
                   nombre: str = "", contexto: int = 6) -> Optional[Path]:
    """
    Código en estilo editor. Con `archivo` existente, se busca el fragmento y se
    muestran ±`contexto` líneas alrededor con números reales; si no, se dibuja
    el fragmento tal cual.
    """
    if _restringido(archivo):
        return None
    if not (fragmento or "").strip():
        return None
    etiqueta = nombre or (Path(archivo).name if archivo else "código")
    lineas, primera, resaltar = fragmento.splitlines(), 1, set(range(len(fragmento.splitlines())))
    if archivo and Path(archivo).is_file():
        todas = _leer(Path(archivo)).splitlines()
        pos = _lineas_de(todas, fragmento)
        if pos:
            ini = max(0, pos[0] - contexto)
            fin = min(len(todas), pos[-1] + contexto + 1)
            lineas, primera = todas[ini:fin], ini + 1
            resaltar = {p - ini for p in pos}
            etiqueta = f"{Path(archivo).name} · líneas {pos[0] + 1}–{pos[-1] + 1}"
    lineas = lineas[:40]
    destino = Path(carpeta) / f"codigo_{_clave(etiqueta, fragmento)}.png"
    if destino.is_file():
        return destino
    try:
        return _render_lineas(lineas, primera, resaltar, etiqueta, destino)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("sin captura de código: %s", exc)
        return None


def captura_cita(documento: Path, cita: str, carpeta: Path,
                 solo_exacta: bool = True) -> Optional[tuple[Path, str]]:
    """
    Captura del documento donde aparece la cita. Devuelve (png, descripción)
    —p. ej. «Manual.pdf · página 12»— o None si no se encuentra.

    En un PDF, por defecto solo se captura la página donde la cita aparece
    LITERAL (y se resalta). La ubicación por palabras en común es poco fiable en
    manuales que repiten párrafos de plantilla: una captura de la página
    equivocada se presentaría como sustento sin serlo. `solo_exacta=False` la
    permite, rotulada como aproximada.
    """
    if _restringido(documento):
        return None
    documento = Path(documento)
    if not documento.is_file() or not (cita or "").strip():
        return None
    ext = documento.suffix.lower()
    try:
        if ext == ".pdf":
            import pypdfium2 as pdfium
            pdf = pdfium.PdfDocument(str(documento))
            try:
                idx, rects, exacta = _pagina_de(documento, pdf, cita)
            finally:
                pdf.close()
            if idx is None or (solo_exacta and not exacta):
                return None
            destino = Path(carpeta) / f"pagina_{_clave(documento.name, idx, cita)}.png"
            if not destino.is_file():
                _render_pdf(documento, idx, destino, rects)
            return destino, (f"{documento.name} · página {idx + 1}"
                             + ("" if exacta else " (ubicación aproximada: la cita no "
                                                  "figura literal en el PDF)"))
        if ext in EXT_CODIGO:
            png = captura_codigo(cita, carpeta, archivo=documento)
            return (png, documento.name) if png else None
        todas = _leer(documento).splitlines()
        pos = _lineas_de(todas, cita)
        if not pos:
            return None
        ini, fin = max(0, pos[0] - 5), min(len(todas), pos[-1] + 6)
        destino = Path(carpeta) / f"texto_{_clave(documento.name, cita)}.png"
        etiqueta = f"{documento.name} · líneas {pos[0] + 1}–{pos[-1] + 1}"
        if not destino.is_file():
            _render_lineas(todas[ini:fin], ini + 1, {p - ini for p in pos}, etiqueta,
                           destino, mono=False)
        return destino, etiqueta
    except Exception as exc:                          # noqa: BLE001
        logger.warning("sin captura de %s: %s", documento.name, exc)
        return None
