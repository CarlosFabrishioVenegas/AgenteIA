# VIRF · Gobierno de riesgo de modelo IA (SEG-09) — BORRADOR

> Norma 4205.410.06 · 2135.010.02 §Aseguramiento (ciclo de vida).
> Borrador preparado a partir del código del repositorio (2026-11-06). Los campos 👤 los completa
> el dueño del modelo con Riesgo No Financiero y Ciberseguridad; **no** están inventados.

## 1. Inventario de IA generativa / agéntica

| # | Componente | Propósito | Tipo | Proveedor / modelo | Estado del proveedor | Datos que procesa | Controles | Dueño |
|---|---|---|---|---|---|---|---|---|
| 1 | Evaluación de actividades (`modulos/motor_ia.py`) | Puntuar y redactar observaciones de validación de modelos de riesgo | LLM generativo, salida estructurada JSON | Azure OpenAI (deployment corporativo) | APROBADO | Evidencia del modelo validado (manuales, código, datasets resumidos), literatura RAG | Gateway único (PII, inyección, allowlist, auditoría); citas verificadas; NLI; abstención β; firma humana | 👤 |
| 2 | Resumen de documentos largos (`modulos/chunker.py`) | Extraer/condensar documentos que no caben en contexto | LLM generativo | Azure OpenAI | APROBADO | Evidencia del modelo | Gateway; material delimitado | 👤 |
| 3 | Revisión de código (`modulos/revision_codigo.py`) | Hallazgos sobre el código del modelo validado | LLM generativo | Azure OpenAI | APROBADO | Código fuente del modelo, manual | Gateway; números de línea verificados | 👤 |
| 4 | Excel/VBA → notebook (`modulos/excel_a_notebook.py`) | Traducir fórmulas/VBA a Python | LLM generativo de **código** | Azure OpenAI | APROBADO | Libros Excel, VBA | Gateway; **sin ejecución automática**: aprobación humana por hash (SEG-07) | 👤 |
| 5 | Controles desde documento/entendimiento (`controles_a_notebook`, `notebook_controles`) | Proponer controles de calidad de datos | LLM generativo | Azure OpenAI | APROBADO | Documentos de controles, entendimiento del modelo | Gateway; revisión humana de parámetros | 👤 |
| 6 | Explicador del modelo (`modulos/explicador_modelo.py`) | Documento pedagógico del modelo | LLM generativo | Azure OpenAI | APROBADO | Inventario y evidencia | Gateway | 👤 |
| 7 | Chat de observaciones (`web/services/chat_service.py`) | Diálogo validador ↔ agente por observación | LLM conversacional | Azure OpenAI | APROBADO | Observación, evidencia, historial | Gateway; feedback encadenado | 👤 |
| 8 | Juez NLI (`modulos/entailment.py`) | Verificar que la cita sostiene la afirmación | LLM-as-judge | Azure OpenAI | APROBADO | Afirmación + fragmento | Gateway; activo en producción | 👤 |
| 9 | Solo Informe · asistencia (`web/services/solo_informe_ia.py`) | Pulir textos, gráficos | LLM generativo | Azure OpenAI | APROBADO | Texto del validador | Gateway; texto saneado | 👤 |
| 9b | Cuadro de automatizaciones (`modulos/automatizaciones.py`) | Observaciones a partir de los Excels 00–03 de automatización | LLM generativo, JSON | Azure OpenAI | APROBADO | Resultados de los Excels, contexto del modelo | Gateway; material delimitado; modo determinista sin IA disponible | 👤 |
| 10 | VIRF PLUS (`config/virf_plus.py`) | Segunda opinión GPT + Claude con árbitro | Multi-LLM | Azure OpenAI + Anthropic | **BLOQUEADO** (Anthropic EN_ESPERA) | — | No arranca hasta aprobación | 👤 |
| 11 | RAG léxico (`src/rag/`) | Recuperar literatura regulatoria | Recuperación BM25 + TF-IDF (no generativa, local) | — | n/a | Corpus público | Índices firmados (HMAC); sin embeddings ni red | 👤 |

Proveedores: `azure_openai` APROBADO · `anthropic` EN_ESPERA · `openai` RETIRADO (lista cerrada en `config/ia.py`).

## 2. Cuestionario de riesgo de modelo IA (borrador)

**2.1 Identificación**
- Nombre: VIRF Agent v27 — Validación Independiente de Riesgo Financiero asistida por IA.
- Dueño del modelo / responsable funcional: 👤 · Área usuaria: Gerencia de Validación Interna de Riesgo Financiero (según la portada del manual) 👤 confirmar.
- Tier / criticidad propuesta: 👤.

**2.2 Propósito y uso**
- Apoyar a validadores de 2.ª línea: lee la evidencia de un modelo de riesgo, propone puntajes y observaciones por actividad y genera el informe Word.
- **No decide**: todo informe de producción lo firma una persona autenticada (SSO, SEG-02); doble firma configurable por tier.
- Usos no permitidos: emitir dictámenes sin firma humana; procesar información Restringida fuera de Databricks/repositorio aprobado (SEG-06).

**2.3 Datos**
- Entradas: manuales, código, datasets (esquema y perfiles), actas/correos del modelo validado; literatura regulatoria pública.
- Datos personales: posibles (DNI, RUC, CE, CCI, nombres). Se enmascaran localmente antes de salir (SEG-04) con tokens estables; límite: nombres sin contexto no se detectan.
- Clasificación obligatoria al subir; Restringido no se guarda en el portátil; caché cifrada; retención 30 días (SEG-06).
- Residencia/transferencia: Azure OpenAI corporativo (endpoint en allowlist) 👤 confirmar región y términos de no-retención/no-entrenamiento.

**2.4 Controles implementados (evidencia: commits `fix(SEG-XX)` y tests)**
- Gateway único de salida a IA (SEG-05), lista cerrada de proveedores (SEG-01), credenciales en Key Vault/secret scope (SEG-03).
- Identidad SSO y firmante autenticado (SEG-02); roles y permisos, feedback con hash encadenado (SEG-08); auditoría solo-anexar (SEG-12).
- Clasificación en todo Word (SEG-10); repositorio corporativo (SEG-11).
- Sin ejecución de código no confiable; código de IA solo tras aprobación humana (SEG-07).
- Lecturas de Databricks de mínimo dato, sin token personal (SEG-14).
- Robustez LLM: inyección neutralizada, citas verificadas que invalidan, NLI, abstención β (SEG-16).

**2.5 Desempeño y limitaciones conocidas**
- Calibración de β documentada en `docs/evidencia/beta_calibracion_dia2.md`.
- Limitaciones: inyección por patrones (no semántica); NLI depende del mismo proveedor; nombres sin contexto; borrado por sobrescritura no garantiza borrado físico en SSD.
- Métricas de desempeño del agente frente a validadores humanos: 👤 (definir set de oro y umbrales).

**2.6 Supervisión humana y monitoreo**
- Firma humana obligatoria; afirmaciones sin respaldo retiradas para revisión; feedback del validador versionado.
- Monitoreo en producción (deriva, tasa de abstención, tasa de citas inválidas): 👤 definir indicadores y frecuencia.

**2.7 Terceros y contratos**
- Azure OpenAI vía suscripción corporativa: 👤 número de contrato / evaluación de proveedor.

## 3. Pruebas de seguridad

### 3.1 SAST — bandit 1.8.6 (ejecutado 2026-11-06, `docs/seguridad/sast_bandit.json`)
Alcance: `agente.py config modulos motor web src scripts` (~40 000 líneas; sin tests ni archivo).

| Severidad | Antes | Después | Tratamiento |
|---|---|---|---|
| HIGH | 2 (B324 sha1/md5) | 0 | Eran identificadores no criptográficos; cambiados a SHA-256 |
| MEDIUM | 2 (B301 pickle.load) | 0 | Índices RAG solo se deserializan con firma HMAC válida (`modulos/pickle_firmado.py`) |
| LOW | 57 | 58 | Mayoría `try/except: pass` deliberados (degradación controlada), `subprocess` sin shell con rutas internas, `random` para jitter de reintentos; B105/B106 son falsos positivos (nombre de cookie, `token_pattern`). Aceptados; revisar en el code review |

### 3.2 SCA — pip-audit 2.9.0 (ejecutado 2026-11-06, `docs/seguridad/sca_pip_audit.json`)
120 paquetes resueltos de `requirements.txt` + `web/requirements_web.txt`; **46 vulnerabilidades en 6 paquetes**:

| Paquete | Versión | Vulns | Versión con corrección | Tratamiento propuesto |
|---|---|---|---|---|
| pillow | 12.3.0 | 39 | 13.0.0 | Actualizar (versión mayor): re-ejecutar suite y capturas |
| tornado | 6.5.10 | 3 | 6.6 | Actualizar (dependencia transitiva) |
| requests | 2.32.5 | 1 | 2.33.0 | Actualizar |
| scikit-learn | 1.4.2 | 1 | 1.5.0 | Actualizar; verificar RAG TF-IDF |
| PyPDF2 | 3.0.1 | 1 | 3.9.0 (reportado) | Migrar a `pypdf` (PyPDF2 está deprecado) |
| pytest | 8.4.2 | 1 | 9.0.3 | Actualizar (solo desarrollo) |

**No se actualizaron en este cambio**: requieren reinstalar dependencias y pasar la suite completa con las versiones nuevas; queda como tarea propia.

### 3.3 DAST y pentest — 👤
Los ejecuta el equipo autorizado de Ciberseguridad (no el agente). Alcance sugerido: web FastAPI (login SSO, subidas, endpoints de rol), salida a Azure OpenAI, caché/outputs locales.

## 4. Pendientes 👤
1. Abrir el flujo con Riesgo No Financiero y Ciberseguridad con este borrador.
2. Completar dueño, tier, métricas de desempeño, monitoreo y contrato del proveedor.
3. Agendar DAST y pentest.
4. Aprobar la actualización de las 6 dependencias vulnerables.
