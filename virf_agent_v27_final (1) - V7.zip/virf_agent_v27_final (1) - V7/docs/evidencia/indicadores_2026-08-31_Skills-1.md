# Paquete de Evidencia — Skills-1

- **Proyecto:** VIRF Agent
- **Fecha:** 2026-08-31
- **Commit:** `25db7e0`
- **Resumen:** 🟢 12 · 🟡 4 · 🔴 2 · ⚪ 11

| ID | Indicador | Valor | Umbral | Estado | Evidencia |
|----|-----------|-------|--------|--------|-----------|
| A1 | Fases E2E implementadas | 0/11 completas (7 parciales) | informativo | 🔴 ROJO | PLAN §4.1; Mx_01_LecturaEvidencias.py:72-91,170-179; motor_ia.py:402-444 |
| A2 | Checklist técnico cumplido | 1/12 completos (pto12 versionado=1; pto3 salida tipada parcial=1) | informativo | 🟡 AMBAR | PLAN §3.2 (GAP-12..GAP-23); WP-10 modulos/versionado.py; WP-09 modulos/esquemas.py (salida tipada, extracción aún free-parse) |
| A3 | Skills operativas (declaradas+test) | declaradas 6/6; operativas+test 1/6 (Calidad de Datos) | informativo | 🟡 AMBAR | skills/ (base_tipada.py + 6 skills); tests/skills/; docs/evidencia/plan_skills.md |
| A4 | Antipatrones neutralizados con prueba | 3/11 | informativo | 🔴 ROJO | test_regresion.py:395; test_pendientes_auditoria.py:2022; tests/skills/test_cola_pendiente.py (exceso de agencia) |
| B1 | Recall@10 (doc, golden fórmula/tabla) | 1.000 | >=0.85 | 🟢 VERDE | scripts/preguntas_oro_formula.py; docs/evidencia/retrieval_metrics.json |
| B2 | Precision@5 (chunk, golden fórmula/tabla) | 0.520 | >=0.85 | 🟡 AMBAR | techo ~0.6 por tamaño de corpus; ver docs/evidencia/retrieval_chunking.md |
| B3 | nDCG@10 (golden fórmula/tabla) | 0.946 | informativo | 🟢 VERDE | scripts/preguntas_oro_formula.py |
| B4 | Tamaño Golden Dataset | 49 discriminantes | >=30 preguntas | 🟢 VERDE | 25 (fórmula/tabla) + 24 (preguntas_oro_rag) |
| C1 | Faithfulness/Groundedness | NA | >=0.85 | ⚪ NA | API para fase posterior (faithfulness/relevancy requieren corrida real) |
| C2 | Answer Relevancy | NA | >=0.80 | ⚪ NA | API para fase posterior (faithfulness/relevancy requieren corrida real) |
| C3 | Citation Precision/Recall | NA | >=0.80 | ⚪ NA | API para fase posterior (faithfulness/relevancy requieren corrida real) |
| D1 | Inyección error matemático→DESVIADO | NA-diferido (fixture listo) | PASA | ⚪ NA | E2E requiere API; fixture presente |
| D2 | Contaminación model_id | 0% | 0% | 🟢 VERDE | pytest '*spillover*' PASSED |
| D3 | Abstención activa | PASA | PASA | 🟢 VERDE | pytest '*abstencion*' PASSED |
| D4 | Citas verificadas (determinístico; NLI diferido) | det=PASA (NLI diferido) | det=PASA; NLI>=0.80 diferido | 🟢 VERDE | pytest '*cita_determinista*' PASSED (parte NLI/entailment = NA-diferido, API) |
| D5 | Resistencia a IPI | NA-diferido | PASA | ⚪ NA | E2E requiere API; separación datos/instrucción en Mx_02:249-267 |
| D6 | Circuit breakers | cap+fusibles configurados (INTENTOS_CONTRATO=2) | SÍ+valores | 🟢 VERDE | config/parametros.py: MAX_ITER + FUSIBLE_SEG + FUSIBLE_TOKENS presentes |
| D7 | Linaje reconstruible E2E | NA | PASA | ⚪ NA | test '*linaje*' aún no existe en la suite |
| E1 | pytest passed/failed/skipped | 989 passed / 0 failed / 1 skipped | 0 failed | 🟢 VERDE | docs/evidencia/pytest_*.xml (JUnit) |
| E2 | Cobertura de tests | NA | >=60% núcleo | ⚪ NA | pytest-cov ausente en requirements.txt; no se añade sin autorización |
| E3 | Linter errores/warnings | NA | informativo | ⚪ NA | linter ausente en requirements.txt |
| E4 | Arranque FastAPI (verificación) | OK | OK | 🟢 VERDE | python -c 'import web.app' → returncode 0 |
| E5 | Dependencias nuevas introducidas | 0 | mínimas y justificadas | 🟢 VERDE | requirements.txt sin cambios respecto al baseline |
| F1 | .docx genera sin error (pipeline real) | NA-diferido | SÍ | ⚪ NA | generación E2E desde el pipeline requiere API; estructura probada por WP-08 (reporte_docx.py) desde mock [pytest '*docx_regresion*' PASSED] |
| F2 | Veredictos por ámbito presentes | SÍ | SÍ | 🟢 VERDE | APROBADO/PENDIENTE/NO APROBADO en reporte_docx.py + test docx_regresion |
| F3 | Secciones obligatorias (n/4) | 4/4 (sin_obs=1, pie_pag=1, refs=1, concl_ámbito=1) | 4/4 | 🟢 VERDE | inspección de reporte_docx.py / word_estilo.py + test docx_regresion |
| G1 | WPs completados | 5/7 | informativo | 🟡 AMBAR | wps_estado del propio paquete |
| G2 | Brechas Gap Matrix cerradas | ver wps_estado | informativo | ⚪ NA | se consolida al cierre del día |
| G3 | Archivos modificados en el hito | [".env.example", ".gitignore", "MANUAL_TECNICO_VIRF.pdf", "PROMPT_CONTINUIDAD_2026-08-09.md", "PROMPT_CONTINUIDAD_2026-08-16.md", "PROMPT_CONTINUIDAD_2026-08-28.md", "config/__init__.py", "config/cuestionamientos_activos.json", "config/cuestionamientos_personalizados.json", "config/parametros.py", "docs/PLAN_MAESTRO_VIRF.md", "docs/evidencia/beta_calibracion_dia2.md", "docs/evidencia/indicadores_2026-08-28.json", "docs/evidencia/indicadores_2026-08-28.md", "docs/evidencia/indicadores_2026-08-28_Dia-2.json", "docs/evidencia/indicadores_2026-08-28_Dia-2.md", "docs/evidencia/indicadores_2026-08-28_Golden-1.json", "docs/evidencia/indicadores_2026-08-28_Golden-1.md", "docs/evidencia/pytest_dia2.log", "docs/evidencia/pytest_dia2.xml", "docs/evidencia/pytest_golden.log", "docs/evidencia/pytest_golden.xml", "docs/evidencia/recall_cutover_dia2.md", "docs/evidencia/reconciliacion_dia1.md", "docs/evidencia/reconciliacion_dia2.md", "docs/evidencia/retrieval_chunking.md", "docs/evidencia/retrieval_metrics.json", "docs/evidencia/wps_dia1.json", "docs/evidencia/wps_dia2.json", "docs/guias/guia-arquitectura-agente-financiero (1).md", "docs/guias/guia-errores-loops-validacion-rag (1).md", "docs/guias/guia-integracion-skills-agente (1).md", "modulos/abstencion.py", "modulos/aislamiento.py", "modulos/chunker_estructural.py", "modulos/cuestionamientos_ext.py", "modulos/esquemas.py", "modulos/fusibles.py", "modulos/instrucciones_sesion.py", "modulos/reporte_docx.py", "modulos/validador_citas.py", "modulos/ventana_contexto.py", "modulos/versionado.py", "scripts/preguntas_oro_formula.py", "src/rag/buscador_lexico.py", "src/rag/config_rag.py", "src/rag/custom_retriever.py", "src/rag/indexador_lexico.py", "tests/fixtures/var_injection/manual_var_demo.md", "tests/fixtures/var_injection/modelo_var_demo.py", "tests/fixtures/var_injection/modelo_var_roto.py", "tests/test_abstencion.py", "tests/test_aislamiento.py", "tests/test_beta_calibracion.py", "tests/test_chunker_estructural.py", "tests/test_circuit_breakers.py", "tests/test_citas_deterministas.py", "tests/test_docx_regresion.py", "tests/test_esquemas.py", "tests/test_estandares_sesion.py", "tests/test_prompts_editables.py", "tests/test_versionado.py", "verificador_virf.py", "web/README_WEB.md", "web/__init__.py", "web/app.py", "web/config_web.py", "web/data/dominios_custom.json", "web/data/prompts_base.json", "web/data/validadores.json", "web/requirements_web.txt", "web/routers/__init__.py", "web/routers/auth.py", "web/routers/chat.py", "web/routers/config.py", "web/routers/controles.py", "web/routers/cuestionamientos.py", "web/routers/cuestionamientos_sesion.py", "web/routers/debug_conexiones.py", "web/routers/dominio_prevuelo.py", "web/routers/entendimiento.py", "web/routers/estandares.py", "web/routers/informe.py", "web/routers/modelos.py", "web/routers/preview_prompt.py", "web/routers/prompts.py", "web/routers/rag.py", "web/routers/resultados.py", "web/routers/skills.py", "web/routers/upload.py", "web/routers/validacion.py", "web/services/__init__.py", "web/services/analisis_codigo.py", "web/services/chat_service.py", "web/services/contexto_sesion.py", "web/services/cuestionamientos_sesion.py", "web/services/dominios_custom_store.py", "web/services/env_service.py", "web/services/estado_sesion.py", "web/services/estandares_service.py", "web/services/informe_web.py", "web/services/modelos_store.py", "web/services/pipeline_runner.py", "web/services/presupuesto_service.py", "web/services/prompt_service.py", "web/services/sesion_store.py", "web/services/skills_store.py", "web/static/css/styles.css", "web/static/js/app.js", "web/templates/index.html", "web/verificar_conexiones.py"] | lista | ⚪ NA | git diff --name-only f0bffc0 HEAD |

## WPs

- **SK-00 contrato base tipado**: HECHO → indicadores A3
- **SK-01 declarar 6 skills**: HECHO → indicadores A3
- **SK-02 Calidad de Datos determinista+sandbox**: HECHO → indicadores A3
- **SK-03 cola PENDIENTE (HITL)**: HECHO → indicadores A4
- **SK-04 arnes pytest por skill**: HECHO → indicadores E1
- **SK-05 Coordinador ReAct+function calling**: PENDIENTE → indicadores A3
- **SK-06..10 otras 5 skills a fondo**: PENDIENTE → indicadores A3

## Regresiones

- (ninguna)

## Bloqueos

- Indicadores B/C (IR/RAGAS), D1 (inyección E2E), D5 (IPI E2E) y F1 (.docx real) requieren API: quedan NA-diferidos hasta encender crédito. Mecanismos y fixtures ya cableados y probados con mocks.
