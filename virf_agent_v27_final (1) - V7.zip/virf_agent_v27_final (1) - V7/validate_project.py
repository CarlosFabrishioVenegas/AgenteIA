#!/usr/bin/env python3
"""
validate_project.py — Verificación de integridad del proyecto VIRF
═══════════════════════════════════════════════════════════════════════════════

Ejecuta comprobaciones estáticas SIN llamar a la API (coste 0) para confirmar
que el proyecto está correctamente configurado antes de una corrida real.

Uso:
    python validate_project.py            # informe completo
    python validate_project.py --strict   # exit code 1 si hay algún FAIL

Comprueba:
    1.  Estructura de carpetas y archivos obligatorios
    2.  Seguridad: que no haya claves reales en .env.example / .gitignore
    3.  Consistencia de parámetros entre config.py y Mx_00
    4.  Pesos de ámbito: suman 1.00 y coinciden con AMBITO_A_INPUTS y el Excel
    5.  Dependencias instaladas vs. requirements.txt
    6.  Estándar VIRF: legible y con actividades por tier
    7.  Evidencia disponible por ámbito (avisa de ámbitos vacíos)
    8.  Patrones metodológicos: regex válidos
    9.  Integridad del caché (JSON legible)
    10. Salud de módulos: que todos los imports críticos resuelvan
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import re
import sys
from pathlib import Path

BASE = Path(__file__).parent
sys.path.insert(0, str(BASE))
sys.path.insert(0, str(BASE / "motor"))

# [CONSOLA-FIX] Antes aquí había un parche a medias:
#     if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")
# Solo cubría stdout, sin errors="replace" y sin tocar el codepage de Windows.
# Por eso este validador sobrevivía y `agente.py` moría con UnicodeEncodeError
# en la misma consola. Se unifica en un único punto de control.
from modulos.consola import configurar_consola

configurar_consola()

# ─── Utilidades de reporte ────────────────────────────────────────────────────
_RES = {"PASS": 0, "WARN": 0, "FAIL": 0}
_ICONO = {"PASS": "✅", "WARN": "⚠️ ", "FAIL": "❌"}


_CACHE_ENTORNO: dict = {}


def _es_de_entorno_virtual(ruta: Path) -> bool:
    """
    ¿`ruta` vive dentro de un entorno virtual (se llame como se llame) o de un
    `site-packages`? Se reconoce por `pyvenv.cfg`, que `python -m venv` deja en
    la raíz de todo entorno. Filtrar solo por los nombres `venv`/`.venv` hacía
    que un entorno llamado distinto (`env/`, un respaldo `.venv_respaldo/`) se
    escanease como código propio y diese falsos positivos.
    """
    if "site-packages" in ruta.parts:
        return True
    for carpeta in ruta.parents:
        if carpeta == BASE:
            break
        if carpeta not in _CACHE_ENTORNO:
            _CACHE_ENTORNO[carpeta] = (carpeta / "pyvenv.cfg").is_file()
        if _CACHE_ENTORNO[carpeta]:
            return True
    return False


def check(nombre: str, estado: str, detalle: str = "") -> None:
    _RES[estado] += 1
    linea = f"  {_ICONO[estado]} {nombre}"
    if detalle:
        linea += f"\n       {detalle}"
    print(linea)


def seccion(titulo: str) -> None:
    print(f"\n{'─' * 74}\n  {titulo}\n{'─' * 74}")


# ═════════════════════════════════════════════════════════════════════════════
# 1. ESTRUCTURA
# ═════════════════════════════════════════════════════════════════════════════
def val_estructura() -> None:
    seccion("1. ESTRUCTURA DEL PROYECTO")

    # [CONFIG-CENTRAL v27.2] `config.py` ya no existe: la configuración es el
    # paquete `config/`. No pueden coexistir — Python resuelve los paquetes
    # antes que los módulos, así que un config.py reaparecido quedaría
    # inalcanzable en silencio mientras todo el proyecto cree estar leyéndolo.
    obligatorios = [
        "agente.py", "requirements.txt",
        "config/__init__.py", "config/parametros.py", "config/rutas.py",
        "config/dominio.py", "config/ia.py",
        "modulos/consola.py",
        "motor/Mx_00_CargaRutas.py", "motor/Mx_01_LecturaEvidencias.py",
        "motor/Mx_02_EstructuraPrompt.py", "motor/Mx_03_LlamarIA.py",
        "modulos/motor_ia.py", "modulos/generador_word.py",
        "modulos/document_cache.py", "modulos/feedback.py",
        "inputs/Estandares_VIRF.xlsx",
    ]
    for rel in obligatorios:
        p = BASE / rel
        check(f"existe {rel}", "PASS" if p.exists() else "FAIL",
              "" if p.exists() else "archivo obligatorio ausente")

    _config_py = BASE / "config.py"
    check("config.py no coexiste con el paquete config/",
          "PASS" if not _config_py.exists() else "FAIL",
          "" if not _config_py.exists() else
          "config.py ha reaparecido: el paquete config/ lo ensombrece y quedaría "
          "MUERTO sin previo aviso. Mover su contenido a config/ y borrarlo.")

    carpetas = [
        "inputs/documentacion/modelamiento", "inputs/documentacion/seguimiento",
        "inputs/calidad_datos", "inputs/implementacion", "inputs/papers", "inputs/usos",
        "outputs", "data",
    ]
    for rel in carpetas:
        p = BASE / rel
        if not p.exists():
            check(f"carpeta {rel}", "WARN", "no existe — se creará al ejecutar")
        else:
            check(f"carpeta {rel}", "PASS")


# ═════════════════════════════════════════════════════════════════════════════
# 2. SEGURIDAD
# ═════════════════════════════════════════════════════════════════════════════
def val_seguridad() -> None:
    seccion("2. SEGURIDAD DE CREDENCIALES")

    ejemplo = BASE / ".env.example"
    if ejemplo.exists():
        txt = ejemplo.read_text(encoding="utf-8", errors="ignore")
        # Busca algo con pinta de clave real (prefijo + longitud)
        reales = re.findall(r"(sk-ant-[A-Za-z0-9_\-]{30,})", txt)
        if reales:
            check(".env.example SIN claves reales", "FAIL",
                  f"¡{len(reales)} clave(s) con formato real detectada(s)! "
                  "REVOCARLAS y sustituir por TU_API_KEY_AQUI")
        else:
            check(".env.example sin claves reales", "PASS")
    else:
        check(".env.example presente", "WARN", "no existe")

    gi = BASE / ".gitignore"
    if gi.exists():
        txt = gi.read_text(encoding="utf-8", errors="ignore")
        ok = any(l.strip() == ".env" for l in txt.splitlines())
        check(".gitignore protege .env", "PASS" if ok else "FAIL",
              "" if ok else "añadir la línea '.env' al .gitignore")

        # [AUDITORÍA 2026-07-28] .claude/settings.local.json guarda el
        # historial de comandos aprobados TAL CUAL se escribieron. Un comando
        # lanzado con la clave en línea queda persistido ahí en claro; durante
        # esta auditoría se encontró una (falsa) por ese mecanismo.
        _lineas = {l.strip() for l in txt.splitlines()}
        _ok_claude = ".claude/settings.local.json" in _lineas or ".claude/" in _lineas
        check(".gitignore protege .claude/settings.local.json",
              "PASS" if _ok_claude else "FAIL",
              "" if _ok_claude else
              "ese fichero registra cada comando aprobado; una clave pasada en "
              "línea queda ahí en claro")

        # Nada de lo que se genera en cada corrida debe poder commitearse.
        for _gen in ("outputs/", "data/cache/", "data/rag_lexico/"):
            check(f".gitignore protege {_gen}",
                  "PASS" if _gen in _lineas else "FAIL")
    else:
        check(".gitignore existe", "FAIL", "crear .gitignore con '.env'")

    # ── Ningún secreto real fuera de .env ───────────────────────────────────
    # .env sí puede contenerla (está ignorada); cualquier OTRO fichero del árbol
    # con una clave de formato real es una fuga.
    _fugas = []
    _re_clave = re.compile(r"sk-ant-[A-Za-z0-9_\-]{25,}")
    for _f in BASE.rglob("*"):
        if not _f.is_file():
            continue
        if (any(p in _f.parts for p in ("venv", ".venv", "__pycache__", ".git", "archivo"))
                or _es_de_entorno_virtual(_f)):
            continue
        if _f.name == ".env" or _f.suffix.lower() in (
                ".pyc", ".docx", ".xlsx", ".xlsm", ".pdf", ".png", ".jpg", ".parquet"):
            continue
        try:
            _t = _f.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for _m in _re_clave.finditer(_t):
            # Los marcadores evidentes no son fugas.
            if any(x in _m.group(0).upper() for x in ("TEST", "INVALID", "EJEMPLO", "TU_API")):
                continue
            _fugas.append(f"{_f.relative_to(BASE)}")
    check("ninguna clave con formato real fuera de .env",
          "PASS" if not _fugas else "FAIL",
          "" if not _fugas else f"{len(_fugas)} fichero(s): {sorted(set(_fugas))[:3]}")

    env = BASE / ".env"
    if env.exists():
        txt = env.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r"ANTHROPIC_API_KEY\s*=\s*(\S+)", txt)
        if not m:
            check(".env tiene ANTHROPIC_API_KEY", "WARN", "no encontrada")
        elif m.group(1) in ("TU_API_KEY_AQUI", "") or "TU_API" in m.group(1):
            check(".env con clave configurada", "WARN",
                  "contiene placeholder — editar antes de ejecutar")
        else:
            # ¿Es la misma que .env.example? → fuga
            if ejemplo.exists() and m.group(1) in ejemplo.read_text(encoding="utf-8", errors="ignore"):
                check(".env con clave propia", "FAIL",
                      "la clave de .env aparece también en .env.example (expuesta)")
            else:
                check(".env con clave propia", "PASS")
    else:
        check(".env existe", "WARN", "se creará desde .env.example al ejecutar")


# ═════════════════════════════════════════════════════════════════════════════
# 3-4. CONFIGURACIÓN Y PESOS
# ═════════════════════════════════════════════════════════════════════════════
def val_config() -> None:
    seccion("3. CONSISTENCIA DE CONFIGURACIÓN")
    try:
        import config
        import Mx_00_CargaRutas as mx00
    except Exception as e:
        check("importar config.py y Mx_00", "FAIL", f"{type(e).__name__}: {e}")
        return

    for attr in ("MAX_CHARS_DOC", "MAX_CHARS_CODIGO", "MAX_FILAS_EXCEL"):
        a, b = getattr(config, attr, None), getattr(mx00, attr, None)
        check(f"{attr} coherente (config={a}, Mx_00={b})",
              "PASS" if a == b else "FAIL",
              "" if a == b else "valores divergentes entre módulos")

    modelo_cfg = os.getenv("ANTHROPIC_MODELO", "")
    check(f"MODELO_IA = {mx00.MODELO_IA}",
          "PASS" if (not modelo_cfg or modelo_cfg == mx00.MODELO_IA) else "WARN")

    check(f"AGENTE_VERSION = {mx00.AGENTE_VERSION}",
          "PASS" if mx00.AGENTE_VERSION and mx00.AGENTE_VERSION != "20" else "WARN",
          "" if mx00.AGENTE_VERSION != "20" else "versión desactualizada respecto al proyecto")

    seccion("4. PESOS Y ÁMBITOS")
    suma = sum(config.AMBITO_PESOS.values())
    check(f"AMBITO_PESOS suma {suma:.4f}",
          "PASS" if abs(suma - 1.0) < 1e-6 else "FAIL",
          "" if abs(suma - 1.0) < 1e-6 else "los pesos deben sumar exactamente 1.00")

    k_pesos = set(config.AMBITO_PESOS)
    k_inputs = set(mx00.AMBITO_A_INPUTS)
    if k_pesos == k_inputs:
        check("AMBITO_PESOS ≡ AMBITO_A_INPUTS", "PASS")
    else:
        check("AMBITO_PESOS ≡ AMBITO_A_INPUTS", "FAIL",
              f"solo en PESOS: {k_pesos - k_inputs} | solo en INPUTS: {k_inputs - k_pesos}")

    # Contraste con el Excel real
    try:
        from modulos.motor_ia import leer_estandares_virf
        amb_excel = set(leer_estandares_virf("1"))
        faltan = amb_excel - k_pesos
        sobran = k_pesos - amb_excel
        if not faltan and not sobran:
            check("ámbitos del Excel ≡ AMBITO_PESOS", "PASS")
        else:
            check("ámbitos del Excel ≡ AMBITO_PESOS", "FAIL",
                  f"en Excel no en PESOS: {faltan} | en PESOS no en Excel: {sobran}")
    except Exception as e:
        check("leer ámbitos del Excel", "WARN", f"{type(e).__name__}: {e}")


# ═════════════════════════════════════════════════════════════════════════════
# 5. DEPENDENCIAS
# ═════════════════════════════════════════════════════════════════════════════
def val_dependencias() -> None:
    seccion("5. DEPENDENCIAS")
    criticas = {
        "anthropic": "LLM", "pandas": "datos", "numpy": "datos",
        "openpyxl": "Excel", "dotenv": "config", "docx": "Word",
        "nbformat": "notebooks",
    }
    # [POLÍTICA 2026-07-30] `pytesseract` (OCR) y `sentence_transformers`
    # (embeddings locales) salieron de esta lista: son modelos externos y la
    # entidad solo admite Azure OpenAI. Ya no se comprueban como opcionales
    # porque su AUSENCIA es ahora lo esperado — listarlos sugeriría instalarlos.
    #
    # [ARQUITECTURA 2026-07-31] `chromadb` salió por el mismo motivo, pero por
    # la puerta de atrás: no es un modelo externo, es un paquete que ARRASTRA
    # uno (chromadb → tokenizers → huggingface-hub). Su sustituto, el RAG
    # léxico, depende de `rank_bm25` — Python puro sobre numpy.
    opcionales = {
        "rank_bm25": "RAG léxico (BM25)", "sklearn": "RAG léxico (TF-IDF)",
        "pdfminer": "PDF", "PyPDF2": "PDF fallback",
        "pptx": "PowerPoint", "oletools": "VBA", "formulas": "Excel eval",
        "openai": "Azure OpenAI", "requests": "HTTP",
    }
    for mod, para in criticas.items():
        try:
            importlib.import_module(mod)
            check(f"{mod} ({para})", "PASS")
        except ImportError:
            check(f"{mod} ({para})", "FAIL", "pip install -r requirements.txt")

    for mod, para in opcionales.items():
        try:
            importlib.import_module(mod)
            check(f"{mod} ({para})", "PASS")
        except ImportError:
            check(f"{mod} ({para})", "WARN", "opcional — funcionalidad degradada")

    val_sin_huggingface()


# ═════════════════════════════════════════════════════════════════════════════
# 5-bis. POLÍTICA: CERO HUGGINGFACE
# ═════════════════════════════════════════════════════════════════════════════
# Paquetes que descargan o ejecutan modelos ajenos a Azure OpenAI, o que los
# arrastran. `tokenizers` y `huggingface-hub` están en la lista aunque nadie los
# importe a mano: son justo la vía por la que la política se incumplía sin que
# nadie lo viera, colgando de `chromadb` en requirements.txt.
_PAQUETES_HF = [
    "transformers", "sentence_transformers", "datasets", "tokenizers",
    "huggingface_hub", "chromadb",
]

# Símbolos cuya presencia en el código fuente delata una vuelta atrás.
# `chromadb` no está aquí: las notas de arquitectura lo mencionan a propósito
# para explicar por qué se fue, y prohibir la palabra obligaría a borrar la
# explicación. Lo que se prohíbe es IMPORTARLO, que es lo que comprueba la
# expresión de abajo.
_SIMBOLOS_HF = [
    r"^\s*(?:from|import)\s+(?:transformers|sentence_transformers|datasets"
    r"|tokenizers|huggingface_hub|chromadb)\b",
    r"\bAutoModel\w*\b", r"\bAutoTokenizer\b",
    r"https?://(?:\w+\.)?huggingface\.co",
]


def val_sin_huggingface() -> None:
    """
    Verifica las dos mitades de la restricción «cero HuggingFace».

    Se comprueban por separado porque fallan por separado, y durante meses el
    proyecto pasó la primera y suspendió la segunda:

      a) CÓDIGO: que ningún fichero importe HF ni apunte a huggingface.co.
      b) DEPENDENCIAS: que requirements.txt no declare ningún paquete que
         arrastre HF, ni directa ni transitivamente.

    El caso (b) no se detecta leyendo el código: `chromadb` no menciona
    HuggingFace por ninguna parte, simplemente depende de `tokenizers`, que
    depende de `huggingface-hub`. Por eso aquí se mira el requirements.
    """
    seccion("5-bis. POLÍTICA: CERO HUGGINGFACE")

    # ── (a) Código fuente ────────────────────────────────────────────────────
    patrones = [re.compile(p, re.MULTILINE) for p in _SIMBOLOS_HF]
    infractores: list[str] = []
    for py in BASE.rglob("*.py"):
        partes = set(py.parts)
        # `archivo/` es el agente v28 aparcado y no se instala ni se ejecuta;
        # `.venv`/`site-packages` son dependencias de terceros, no código nuestro.
        if (partes & {"archivo", ".venv", "venv", "site-packages", "__pycache__"}
                or _es_de_entorno_virtual(py)):
            continue
        try:
            texto = py.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for patron in patrones:
            if patron.search(texto):
                infractores.append(f"{py.relative_to(BASE)} ({patron.pattern[:32]})")
                break
    if infractores:
        check("código sin imports de HuggingFace", "FAIL",
              "; ".join(infractores[:5]))
    else:
        check("código sin imports de HuggingFace", "PASS")

    # ── (b) Dependencias declaradas ──────────────────────────────────────────
    req = BASE / "requirements.txt"
    if req.exists():
        declarados = []
        for linea in req.read_text(encoding="utf-8", errors="ignore").splitlines():
            linea = linea.split("#")[0].strip()   # los comentarios explican el porqué
            if not linea:
                continue
            # `maxsplit` por nombre: pasarlo posicional está deprecado desde 3.13.
            nombre = re.split(r"[<>=!\[ ]", linea, maxsplit=1)[0].strip().lower().replace("-", "_")
            if nombre in _PAQUETES_HF:
                declarados.append(nombre)
        if declarados:
            check("requirements.txt sin paquetes HuggingFace", "FAIL",
                  f"declarados: {', '.join(declarados)}")
        else:
            check("requirements.txt sin paquetes HuggingFace", "PASS")
    else:
        check("requirements.txt sin paquetes HuggingFace", "WARN", "no existe")

    # ── (c) Entorno instalado — informativo ──────────────────────────────────
    # WARN y no FAIL a propósito: que `transformers` esté en el intérprete puede
    # ser un resto de otro proyecto del mismo entorno, y no es algo que este
    # repositorio pueda arreglar. Lo que este repositorio controla es lo que
    # DECLARA y lo que IMPORTA, y eso son (a) y (b).
    # [FIX 2026-09-28] Se detecta PRESENCIA con `find_spec`, no importabilidad.
    # Antes se hacía `import_module` dentro de un `except: pass`, y eso confundía
    # "no se puede importar" con "no está instalado": medido en este entorno,
    # `import chromadb` lanzaba `ValueError: onnxruntime ... not installed` en el
    # contexto del validador, así que chromadb —INSTALADO— salía como limpio. El
    # guardia de la política «cero HuggingFace / cero ChromaDB» tenía un punto
    # ciego justo en el paquete que motivó la política. `find_spec` además no
    # ejecuta el paquete: sin efectos secundarios ni el coste de cargar torch.
    import importlib.util as _iu
    presentes = []
    for mod in _PAQUETES_HF:
        try:
            if _iu.find_spec(mod) is not None:
                presentes.append(mod)
        except (ImportError, ValueError):
            pass
    if presentes:
        check("entorno limpio de HuggingFace", "WARN",
              f"instalados pero no usados: {', '.join(presentes)} — "
              f"`pip uninstall {' '.join(presentes)}` si el entorno es solo de VIRF")
    else:
        check("entorno limpio de HuggingFace", "PASS")


# ═════════════════════════════════════════════════════════════════════════════
# 6-7. ESTÁNDAR Y EVIDENCIA
# ═════════════════════════════════════════════════════════════════════════════
#: Mínimo de actividades que debe traer el estándar para considerarlo bien
#: cargado. El Excel de referencia tiene 32; por debajo de 20 la carga está
#: rota, no incompleta.
_MIN_ACTIVIDADES_ESTANDAR = 20


def val_estandar_y_evidencia() -> None:
    seccion("6. ESTÁNDAR VIRF")
    try:
        from modulos.motor_ia import leer_estandares_virf
        # [AUDIT-FIX 2026-08-07] Antes se informaba «Tier N: 32 actividades»
        # para los cuatro tiers y la condición era `n > 0`. Dos problemas:
        #
        #  · 32 es el total de FILAS del Excel, no el alcance del tier. El
        #    alcance real lo marca `requerida` —24/19/23/29—, que es lo que
        #    `agente.py` evalúa. La puerta informaba de un número que no se
        #    usa en ninguna corrida.
        #  · Con `n > 0`, una carga PARCIAL del Excel (columna renombrada,
        #    filas perdidas) pasaba en verde con 3 actividades de 32.
        _requeridas = {}
        for tier in ("1", "2", "3", "4"):
            try:
                r = leer_estandares_virf(tier)
                n = sum(len(v) for v in r.values())
                nreq = sum(1 for v in r.values() for a in v
                           if a.get("requerida", True))
                _requeridas[tier] = nreq
                _ok = n >= _MIN_ACTIVIDADES_ESTANDAR and nreq > 0
                check(f"Tier {tier}: {len(r)} ámbitos, {nreq} de {n} actividades exigidas",
                      "PASS" if _ok else "FAIL",
                      "" if _ok else
                      f"carga sospechosa: {n} actividades en el Excel "
                      f"(mínimo esperado {_MIN_ACTIVIDADES_ESTANDAR}), "
                      f"{nreq} exigidas para este tier")
            except Exception as e:
                check(f"Tier {tier}", "FAIL", f"{type(e).__name__}: {e}")

        # El tier tiene que CAMBIAR algo. Si los cuatro exigen lo mismo, o el
        # Excel perdió las columnas TIER o el filtro dejó de aplicarse — y en
        # ambos casos un modelo Tier 4 se estaría validando como un Tier 1.
        _distintos = len(set(_requeridas.values()))
        check("el tier cambia el alcance evaluado",
              "PASS" if _distintos > 1 else "FAIL",
              "" if _distintos > 1 else
              f"los 4 tiers exigen lo mismo ({_requeridas}): el filtro por "
              f"tier no está aplicándose")
    except Exception as e:
        check("cargar estándares", "FAIL", f"{type(e).__name__}: {e}")
        return

    seccion("7. EVIDENCIA DISPONIBLE (D3-FIX)")
    try:
        from modulos.motor_ia import cargar_todos_inputs, inputs_para_dimension
        import config
        todos = cargar_todos_inputs()
        vacios = []
        for amb in config.AMBITO_PESOS:
            docs = inputs_para_dimension(todos, amb)
            chars = sum(len(d.get("contenido", "")) for d in docs)
            if not docs or chars == 0:
                vacios.append(amb)
                check(f"{amb}", "WARN", "SIN evidencia → será rechazado por D3-FIX")
            else:
                check(f"{amb}: {len(docs)} doc(s), {chars:,} chars", "PASS")
        if vacios:
            print(f"\n       ⚠️  {len(vacios)} ámbito(s) sin evidencia. El score global")
            print(f"          se calculará solo sobre los ámbitos con documentos.")
    except Exception as e:
        check("cargar inputs", "FAIL", f"{type(e).__name__}: {e}")


# ═════════════════════════════════════════════════════════════════════════════
# 8-10. PATRONES, CACHÉ Y MÓDULOS
# ═════════════════════════════════════════════════════════════════════════════
def val_patrones_cache_modulos() -> None:
    seccion("8. PATRONES METODOLÓGICOS")
    try:
        import Mx_00_CargaRutas as mx00
        pats = mx00.CUESTIONAMIENTOS_METODOLOGICOS
        check(f"{len(pats)} patrones definidos", "PASS" if len(pats) >= 10 else "WARN",
              "" if len(pats) >= 10 else "cobertura escasa para modelos de riesgo")
        invalidos = []
        for k, v in pats.items():
            for p in v.get("detectar", []):
                try:
                    re.compile(p.lower())
                except re.error:
                    invalidos.append(f"{k}:{p}")
        if invalidos:
            check("regex válidos", "WARN",
                  f"{len(invalidos)} usan fallback literal: {invalidos[:3]}")
        else:
            check("todos los regex compilan", "PASS")
        # cobertura clave para LaR/VaR
        claves = set(pats)
        for req in ("sin_estacionariedad", "sin_backtesting_lar", "sin_test_normalidad"):
            check(f"cubre '{req}'", "PASS" if req in claves else "WARN")
    except Exception as e:
        check("cargar patrones", "FAIL", f"{type(e).__name__}: {e}")

    seccion("9. CACHÉ")
    try:
        import Mx_00_CargaRutas as mx00
        cdir = Path(mx00.CACHE_DIR)
        cfile = cdir / "document_cache.json"
        check(f"CACHE_DIR = {cdir}", "PASS")
        if cfile.exists():
            try:
                d = json.loads(cfile.read_text(encoding="utf-8"))
                check(f"caché legible ({len(d)} entradas)", "PASS")
            except json.JSONDecodeError as e:
                check("caché legible", "FAIL",
                      f"JSON corrupto ({e}) — borrar con: python agente.py --limpiar-cache")
        else:
            check("caché aún no creado", "PASS", "se generará en la primera corrida")
        locks = list(cdir.glob("*.lock")) if cdir.exists() else []
        check("sin locks huérfanos", "PASS" if not locks else "WARN",
              "" if not locks else f"{len(locks)} lock(s): {[p.name for p in locks]}")
    except Exception as e:
        check("verificar caché", "WARN", f"{type(e).__name__}: {e}")

    seccion("10. SALUD DE MÓDULOS")
    modulos = [
        "config", "modulos.motor_ia", "modulos.motor_ia_v2",
        "modulos.generador_word", "modulos.document_cache", "modulos.chunker",
        "modulos.feedback", "modulos.feedback_mejorado", "modulos.excel_a_notebook",
        "modulos.controles_a_notebook", "modulos.motores_datos",
        "modulos.control_evaluacion_data",
    ]
    for m in modulos:
        try:
            importlib.import_module(m)
            check(f"import {m}", "PASS")
        except Exception as e:
            check(f"import {m}", "FAIL", f"{type(e).__name__}: {e}")


# ═════════════════════════════════════════════════════════════════════════════
# 11. COBERTURA DE DOCUMENTOS GRANDES  [auditoría 2026-07-26]
# ═════════════════════════════════════════════════════════════════════════════
def val_cobertura_documentos() -> None:
    seccion("11. COBERTURA DE DOCUMENTOS GRANDES")
    try:
        from modulos.chunker import (
            ChunkerService, _MAX_CHUNKS, _CHUNK_SIZE, _CHUNK_OVERLAP,
            _MAX_CHUNK_SIZE_ADAPTATIVO,
        )
    except Exception as e:
        check("importar chunker", "FAIL", f"{type(e).__name__}: {e}")
        return

    # [COSTE-FIX D2] Este cálculo estaba obsoleto: usaba _CHUNK_SIZE, que es
    # solo el tamaño INICIAL. Desde el modo adaptativo (D1), un documento que
    # no cabe en _MAX_CHUNKS segmentos no se trunca — se agrandan los segmentos
    # hasta _MAX_CHUNK_SIZE_ADAPTATIVO. El techo real de la pasada adaptativa
    # es por tanto _MAX_CHUNKS × _MAX_CHUNK_SIZE_ADAPTATIVO, no × _CHUNK_SIZE.
    # Con el cálculo viejo, bajar VIRF_MAX_CHUNKS de 60 a 40 (que es MÁS BARATO
    # e igual de exhaustivo) disparaba un WARN pidiendo subirlo otra vez.
    cobertura_adaptativa = _MAX_CHUNKS * (_MAX_CHUNK_SIZE_ADAPTATIVO - _CHUNK_OVERLAP)
    paginas = cobertura_adaptativa // 2000
    check(f"cobertura sin jerarquía: {cobertura_adaptativa:,} chars (~{paginas} págs)",
          "PASS" if paginas >= 300 else "WARN",
          "" if paginas >= 300 else
          f"Por encima entra el modo jerárquico (100% cobertura, pero más caro). "
          f"Para 300 págs sin jerarquía: VIRF_MAX_CHUNKS≥"
          f"{600000 // (_MAX_CHUNK_SIZE_ADAPTATIVO - _CHUNK_OVERLAP) + 1}")

    # [COSTE-FIX D2] Guarda anti-acantilado, a nivel de configuración.
    # Si _MAX_CHUNKS es tan bajo que un manual de 300 págs (~600k chars) ya no
    # cabe en el modo adaptativo, el chunker cae al jerárquico puro y el coste
    # SUBE (medido: 30 segmentos → $2,27 vs 40 segmentos → $1,14).
    _min_adaptativo = 600_000 // (_MAX_CHUNK_SIZE_ADAPTATIVO - _CHUNK_OVERLAP) + 1
    check(f"VIRF_MAX_CHUNKS={_MAX_CHUNKS} por encima del acantilado de coste "
          f"(mínimo {_min_adaptativo})",
          "PASS" if _MAX_CHUNKS >= _min_adaptativo else "WARN",
          "" if _MAX_CHUNKS >= _min_adaptativo else
          f"Con {_MAX_CHUNKS} un manual de 300 págs cae al modo jerárquico puro: "
          f"MÁS llamadas IA que con un límite mayor. Subir VIRF_MAX_CHUNKS a "
          f"{_min_adaptativo}+ o VIRF_CHUNK_SIZE_MAX.")

    # El chunker NO debe truncar: verificar con cliente simulado
    class _ClienteMudo:
        def generar_mensaje(self, prompt, max_tokens=None, **kw):
            return "resumen"

    # El chunker imprime progreso por segmento: se silencia durante la prueba
    import contextlib as _ctx
    import io as _io

    fallos = []
    detalle_modos = []
    for pags in (300, 500, 1000):
        texto = ("Metodologia LaR backtesting Kupiec p=0.021. " * (pags * 50))[:pags * 2000]
        try:
            ch = ChunkerService(cliente_ia=_ClienteMudo())
            with _ctx.redirect_stdout(_io.StringIO()):
                r = ch.procesar_doc({
                    "nombre": f"test_{pags}p.pdf", "tipo": "PDF",
                    "contenido": texto, "chars_totales": len(texto),
                })
            cob = r.get("cobertura_pct", 0)
            detalle_modos.append(
                f"{pags}p→{r.get('n_chunks')} seg [{r.get('modo_cobertura','directo')}] {cob}%"
            )
            if cob < 99.9:
                fallos.append(f"{pags} págs → {cob}%")
        except Exception as e:
            fallos.append(f"{pags} págs → {type(e).__name__}: {e}")

    if detalle_modos:
        print(f"       {' | '.join(detalle_modos)}")

    check("sin truncación silenciosa en 300/500/1000 págs",
          "PASS" if not fallos else "FAIL",
          "" if not fallos else f"cobertura insuficiente: {fallos}")

    # La cobertura real debe propagarse hasta el prompt
    try:
        import inspect
        from modulos.motor_ia import evaluar_actividad, evaluar_ambito_completo
        ok_act = "cobertura_docs" in inspect.signature(evaluar_actividad).parameters
        ok_amb = "cobertura_docs" in inspect.signature(evaluar_ambito_completo).parameters
        ok_ag = "cobertura_docs  = cobertura_ambito" in (BASE / "agente.py").read_text(
            encoding="utf-8", errors="ignore")
        todo = ok_act and ok_amb and ok_ag
        check("cobertura real propagada agente→motor→prompt",
              "PASS" if todo else "FAIL",
              "" if todo else
              f"evaluar_actividad={ok_act} evaluar_ambito={ok_amb} agente={ok_ag}")
    except Exception as e:
        check("propagación de cobertura", "FAIL", f"{type(e).__name__}: {e}")


# ═════════════════════════════════════════════════════════════════════════════
# 12. CONVENCIÓN DE SALIDAS  [auditoría 2026-07-26]
# ═════════════════════════════════════════════════════════════════════════════
def val_salidas() -> None:
    seccion("12. CONVENCIÓN DE SALIDAS (outputs/YYYY-MM-DD/)")

    # Nada generado debe quedar suelto en la raíz
    basura = [
        p.name for p in BASE.iterdir()
        if p.is_file() and p.suffix in (".json", ".docx", ".xlsx")
        and p.name not in ("analisis_ast.json",)
        and not p.name.startswith(".")
    ]
    check("raíz sin artefactos generados", "PASS" if not basura else "WARN",
          "" if not basura else f"mover a outputs/: {basura}")

    # El notebook de controles debe escribir dentro de outputs/.
    # Se inspecciona el CÓDIGO, no los comentarios: un comentario que cite el
    # patrón antiguo (para documentar el fix) no debe hacer fallar la prueba.
    try:
        ruta_cn = BASE / "modulos" / "controles_a_notebook.py"
        lineas_codigo = [
            l for l in ruta_cn.read_text(encoding="utf-8", errors="ignore").splitlines()
            if not l.lstrip().startswith("#")
        ]
        codigo = "\n".join(lineas_codigo)
        malo = "Path('resultados_controles.json')" in codigo \
            or 'Path("resultados_controles.json")' in codigo
        usa_salida = "_destino_resultados" in codigo
        check("notebook de controles escribe en outputs/",
              "FAIL" if malo else ("PASS" if usa_salida else "WARN"),
              "ruta relativa al CWD detectada en código" if malo
              else ("" if usa_salida else "no se encontró el destino explícito"))
    except Exception as e:
        check("revisar controles_a_notebook", "WARN", str(e))

    # Estructura de outputs: TODO debe colgar de outputs/YYYY-MM-DD/
    out = BASE / "outputs"
    if not out.exists():
        check("outputs/ existe", "WARN", "se creará en la primera corrida")
        return

    import re as _re
    patron_fecha = _re.compile(r"^\d{4}-\d{2}-\d{2}$")
    fechas  = [d for d in out.iterdir() if d.is_dir() and patron_fecha.match(d.name)]
    otras   = [d.name for d in out.iterdir() if d.is_dir() and not patron_fecha.match(d.name)]
    sueltos = [f.name for f in out.iterdir() if f.is_file()]

    check(f"outputs/ con {len(fechas)} carpeta(s) YYYY-MM-DD", "PASS")
    check("sin archivos sueltos en outputs/", "PASS" if not sueltos else "WARN",
          "" if not sueltos else f"{len(sueltos)} archivo(s) sin carpeta de fecha: {sueltos[:3]}")
    check("sin carpetas fuera del patrón de fecha", "PASS" if not otras else "WARN",
          "" if not otras else f"{otras}")


# ═════════════════════════════════════════════════════════════════════════════
# 13. CÓDIGO MUERTO  [auditoría 2026-07-26]
# ═════════════════════════════════════════════════════════════════════════════
def val_codigo_muerto() -> None:
    seccion("13. CÓDIGO MUERTO ARCHIVADO")
    archivados = [
        "v13_fixes.py", "generador_excel.py", "generador_template.py",
        "lector_inputs.py", "Mx_05_GeneradorWord.py",
        "Mx_05_ComparativaDocCodigo.py",
    ]
    vivos = []
    for nombre in archivados:
        for carpeta in ("modulos", "motor", "."):
            if (BASE / carpeta / nombre).exists():
                vivos.append(f"{carpeta}/{nombre}")
    check("archivos muertos retirados del árbol activo",
          "PASS" if not vivos else "WARN",
          "" if not vivos else f"aún presentes: {vivos}")

    arch = BASE / "archivo" / "codigo_muerto_2026-07-26"
    if arch.exists():
        check(f"respaldo en archivo/ ({len(list(arch.glob('*.py')))} archivos)", "PASS")
    else:
        check("respaldo de código muerto", "WARN", "no se encontró la carpeta de respaldo")


# ═════════════════════════════════════════════════════════════════════════════
# 14. INVARIANTES DE LA AUDITORÍA EXHAUSTIVA  [2026-07-28]
# ═════════════════════════════════════════════════════════════════════════════
def val_invariantes_auditoria() -> None:
    """
    Guarda los invariantes que la auditoría exhaustiva estableció.

    POR QUÉ ESTE BLOQUE EXISTE
    --------------------------
    La auditoría corrigió 26 defectos, y NINGUNO de sus invariantes estaba
    cubierto por este validador: los 13 bloques anteriores comprueban
    estructura, configuración y dependencias, pero no el COMPORTAMIENTO que se
    demostró frágil. Están en la suite de pytest, sí — pero este validador es
    la puerta de coste cero que se corre ANTES de gastar en una corrida real,
    y el defecto más caro (dictaminar sobre el vacío) no cuesta nada verificar.

    El patrón dominante de la auditoría —AUSENCIA DE EVIDENCIA presentada como
    RESULTADO NEGATIVO— reapareció en seis sitios distintos. Estos checks son
    su red de seguridad.
    """
    seccion("14. INVARIANTES DE LA AUDITORÍA")

    # ── El defecto crítico: sin evidencia NO es un dictamen desfavorable ─────
    try:
        from modulos.motor_ia import calcular_score_global, get_semaforo
        import config as _cfg
        # ── POLÍTICA DE LA ENTIDAD ───────────────────────────────────────
        # Sin evidencia (0.0) = falta crítica imputable al validado: penaliza
        # con su peso íntegro. Fallo técnico (None) = no imputable: se excluye.
        # Los dos invariantes se comprueban por separado porque confundirlos
        # produce, en una dirección, un dictamen adverso infundado y, en la
        # otra, que no aportar documentación salga gratis.
        _sin_evidencia = calcular_score_global({a: 0.0 for a in _cfg.AMBITO_PESOS})
        check("sin evidencia el score global es 0.0 (falta crítica)",
              "PASS" if _sin_evidencia == 0.0 else "FAIL",
              "" if _sin_evidencia == 0.0
              else f"devuelve {_sin_evidencia!r}: no aportar documentación "
                   f"estaría saliendo gratis")

        _todo_roto = calcular_score_global({a: None for a in _cfg.AMBITO_PESOS})
        check("si todo falló técnicamente no se emite dictamen",
              "PASS" if _todo_roto is None else "FAIL",
              "" if _todo_roto is None
              else f"devuelve {_todo_roto!r}: un fallo del agente se imputaría "
                   f"al modelo validado")

        _l_sin_ev = get_semaforo(0.0).get("label", "").upper()
        _l_tecnico = get_semaforo(None).get("label", "").upper()
        check("el semáforo nombra la causa de cada no-evaluación",
              "PASS" if ("SIN EVIDENCIA" in _l_sin_ev and _l_sin_ev != _l_tecnico)
              else "FAIL",
              "" if ("SIN EVIDENCIA" in _l_sin_ev and _l_sin_ev != _l_tecnico)
              else f"'{_l_sin_ev}' vs '{_l_tecnico}': el lector no puede saber si "
                   f"faltó documentación o si se cayó la herramienta")

        # Un ámbito sin evidencia SÍ debe arrastrar; uno con fallo técnico no.
        _pesos = _cfg.AMBITO_PESOS
        _primero = next(iter(_pesos))
        _con_falta = {a: 3.0 for a in _pesos}; _con_falta[_primero] = 0.0
        _con_fallo = {a: 3.0 for a in _pesos}; _con_fallo[_primero] = None
        check("la falta de evidencia arrastra el score; el fallo técnico no",
              "PASS" if calcular_score_global(_con_falta) < calcular_score_global(_con_fallo)
              else "FAIL",
              "" if calcular_score_global(_con_falta) < calcular_score_global(_con_fallo)
              else "los pesos se renormalizan también cuando falta evidencia: "
                   "el ámbito sin documentar no penaliza")
    except Exception as e:
        check("invariantes de score global", "FAIL", f"{type(e).__name__}: {e}")

    # ── Una actividad no evaluada no es «No cumple» ──────────────────────────
    try:
        from modulos.generador_word import _normalizar_score, _puntaje_label, _es_error
        check("fallo técnico ≠ peor puntaje en el informe",
              "PASS" if _normalizar_score(None) is None else "FAIL",
              "" if _normalizar_score(None) is None
              else "puntaje=None se convierte en 1 ('No cumple') en el Word: "
                   "un fallo del agente acusaría al validado")
        check("la actividad sin evidencia mantiene su 0 en el informe",
              "PASS" if _normalizar_score(0) == 0 else "FAIL",
              "" if _normalizar_score(0) == 0
              else f"el 0 se eleva a {_normalizar_score(0)!r}: la falta crítica "
                   f"se presenta como una nota de la escala normal")

        check("un puntaje casi perfecto no colapsa a 1",
              "PASS" if _normalizar_score(5.4) == 5 else "FAIL",
              "" if _normalizar_score(5.4) == 5
              else f"5.4 → {_normalizar_score(5.4)}: el tramo (5,12] se hunde")

        _legitimo = ("El manual documenta la API de extracción y no presenta "
                     "errores de implementación.")
        check("no se borran hallazgos que mencionan 'API'/'error'",
              "PASS" if not _es_error(_legitimo) else "FAIL",
              "" if not _es_error(_legitimo)
              else "hallazgos legítimos desaparecen del informe Word")
    except Exception as e:
        check("invariantes del informe Word", "FAIL", f"{type(e).__name__}: {e}")

    # ── El score del control cuenta TODOS los hallazgos ──────────────────────
    try:
        from modulos.control_evaluacion_data import CalculadorScore
        _muchas = [{"criticidad": "MODERADA"} for _ in range(50)]
        _s = CalculadorScore.calcular_score_cumplimiento(_muchas, 50)
        check("50 hallazgos moderados ≠ cumplimiento pleno",
              "PASS" if _s < 5.0 else "FAIL",
              "" if _s < 5.0 else f"score {_s}: solo se cuentan los CRITICA")
    except Exception as e:
        check("invariante del score de control", "FAIL", f"{type(e).__name__}: {e}")

    # ── Durabilidad de los datos no regenerables ─────────────────────────────
    _fb = (BASE / "modulos" / "feedback.py").read_text(encoding="utf-8")
    _fb_ok = "_escribir_json_atomico" in _fb and "_lock_archivo" in _fb
    check("historial de feedback con lock + escritura atómica",
          "PASS" if _fb_ok else "FAIL",
          "" if _fb_ok else "sin esto se pierde el 77% de los registros con "
                            "procesos concurrentes y se corrompe con kill -9")

    _ch = (BASE / "modulos" / "chunker.py").read_text(encoding="utf-8")
    check("caché de resúmenes bajo lock",
          "PASS" if "_lock_archivo" in _ch else "FAIL",
          "" if "_lock_archivo" in _ch
          else "lost update: cada resumen perdido se vuelve a pagar al modelo")

    _ag = (BASE / "agente.py").read_text(encoding="utf-8")
    check("caché persistido también en salidas tempranas (atexit)",
          "PASS" if "atexit.register(cerrar_cache)" in _ag else "FAIL",
          "" if "atexit.register(cerrar_cache)" in _ag
          else "los modos que retornan antes del try/finally tiran lo leído")

    # ── Rutas de salida saneadas ─────────────────────────────────────────────
    try:
        from config.rutas import nombre_seguro
        _malo = nombre_seguro("../../../evil")
        _ok = "/" not in _malo and "\\" not in _malo and ".." not in _malo
        check("nombres de salida saneados (path traversal)",
              "PASS" if _ok else "FAIL",
              "" if _ok else f"'../../../evil' → '{_malo}'")
    except Exception as e:
        check("saneo de nombres de salida", "FAIL", f"{type(e).__name__}: {e}")

    # ── Configuración centralizada y coherente ──────────────────────────────
    try:
        from config.parametros import MIN_FEEDBACK_ANTISESGO, MIN_MUESTRAS_AJUSTE
        _coh = MIN_MUESTRAS_AJUSTE >= MIN_FEEDBACK_ANTISESGO
        check("umbrales anti-sesgo coherentes entre sí",
              "PASS" if _coh else "WARN",
              "" if _coh else f"el ajuste numérico ({MIN_MUESTRAS_AJUSTE}) es más "
                              f"laxo que el bloque del prompt ({MIN_FEEDBACK_ANTISESGO})")
    except Exception as e:
        check("umbrales anti-sesgo", "FAIL", f"{type(e).__name__}: {e}")

    # ── Lecturas fallidas marcadas ──────────────────────────────────────────
    _mx01 = (BASE / "motor" / "Mx_01_LecturaEvidencias.py").read_text(encoding="utf-8")
    _sin_marcar = re.findall(r'return f"\[Error [^"]*"',
                             "\n".join(l for l in _mx01.splitlines()
                                       if not l.lstrip().startswith("#")))
    check("todos los lectores marcan sus fallos de lectura",
          "PASS" if not _sin_marcar else "FAIL",
          "" if not _sin_marcar
          else f"{len(_sin_marcar)} lector(es) devuelven su error como evidencia "
               f"con cobertura 100%")

    # ── Imports locales que ensombrecen a los de módulo ─────────────────────
    # Un `import X` dentro de una función marca X como local de TODA la
    # función. Si otra rama usa X sin haber pasado por ese import, revienta con
    # "referenced before assignment". Así estuvo muerto el pipeline principal.
    import ast
    _sombras = []
    _objetivo = [BASE / "agente.py"]
    for _carpeta in ("modulos", "motor", "config"):
        _objetivo += sorted((BASE / _carpeta).glob("*.py"))
    for _f in _objetivo:
        if not _f.exists():
            continue
        try:
            _arbol = ast.parse(_f.read_text(encoding="utf-8"))
        except SyntaxError:
            continue
        _glob = {a.asname or a.name.split(".")[0]
                 for n in _arbol.body if isinstance(n, (ast.Import, ast.ImportFrom))
                 for a in n.names}
        for _fn in ast.walk(_arbol):
            if not isinstance(_fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for _n in ast.walk(_fn):
                if isinstance(_n, (ast.Import, ast.ImportFrom)):
                    for _a in _n.names:
                        _nom = _a.asname or _a.name.split(".")[0]
                        if _nom in _glob:
                            _sombras.append(f"{_f.name}:{_n.lineno} '{_nom}' en {_fn.name}()")
    check("ningún import local ensombrece uno de módulo",
          "PASS" if not _sombras else "FAIL",
          "" if not _sombras else "; ".join(_sombras[:3]))

    # ── El pipeline principal resuelve sus nombres ──────────────────────────
    _ag = ast.parse((BASE / "agente.py").read_text(encoding="utf-8"))
    _main = next((n for n in ast.walk(_ag)
                  if isinstance(n, ast.FunctionDef) and n.name == "main"), None)
    _loc = set() if _main is None else {
        a.asname or a.name.split(".")[0]
        for n in ast.walk(_main) if isinstance(n, (ast.Import, ast.ImportFrom))
        for a in n.names}
    # ── El caché no recorta lo que el chunker debe cubrir ───────────────────
    # El TRUNCADO-FIX se había aplicado solo a la lectura directa. La rama del
    # caché seguía pidiendo max_chars=15.000, así que la MISMA orden daba
    # cobertura 100% sin caché y 1.2% con caché — y el caché está activo casi
    # siempre. El informe se emitía sobre el 1,2% del manual.
    _mx01_txt = "\n".join(
        l for l in (BASE / "motor" / "Mx_01_LecturaEvidencias.py")
        .read_text(encoding="utf-8").splitlines()
        if not l.lstrip().startswith("#"))
    _ok_cache = ("_max_cache = None if _chunk_on else max_c" in _mx01_txt
                 and "max_chars=_max_cache" in _mx01_txt)
    check("el caché entrega el documento íntegro al chunker",
          "PASS" if _ok_cache else "FAIL",
          "" if _ok_cache else
          "la rama del caché impone su propio tope: el chunker recibirá el "
          "documento recortado y la cobertura real caerá sin avisar")

    # Ninguna entrada puede declarar más caracteres de los que guarda.
    _cache_json = BASE / "data" / "cache" / "document_cache.json"
    if _cache_json.exists():
        try:
            _dc = json.loads(_cache_json.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            _dc = {}
        _mentirosas = [
            k for k, v in _dc.items()
            if isinstance(v, dict)
            and v.get("chars_totales", 0) > len(v.get("contenido", ""))
            and not v.get("truncado")
        ]
        check("ninguna entrada del caché declara más de lo que guarda",
              "PASS" if not _mentirosas else "FAIL",
              "" if not _mentirosas else
              f"{len(_mentirosas)} entrada(s) servirían una cobertura falsa; "
              f"ejecutar --limpiar-cache")

    check("main() no reimporta ChunkerService (rompería el pipeline)",
          "PASS" if "ChunkerService" not in _loc else "FAIL",
          "" if "ChunkerService" not in _loc
          else "import local en main(): la ruta --titulo/--tier morirá al instanciarlo")


# ═════════════════════════════════════════════════════════════════════════════
# 15. CONTROLES DE CUMPLIMIENTO REGULATORIO
# ═════════════════════════════════════════════════════════════════════════════
def val_cumplimiento_regulatorio() -> None:
    """
    Verifica que los controles que un auditor externo va a exigir existen.

    Se comprueba a coste cero para que el propio auditor pueda ejecutarlo:
    demostrar que los controles están implementados es parte de la evidencia.
    """
    seccion("15. CUMPLIMIENTO REGULATORIO (SR 11-7 · EBA/GL/2023/01)")

    # ── Función 1: cadena de custodia ────────────────────────────────────────
    try:
        from modulos.custodia import (
            hash_contenido, sellar, verificar_cadena, verificar_evidencia,
        )
        _a = {"modelo": "X", "score_global": 3.0}
        _b = {"score_global": 3.0, "modelo": "X"}
        check("el hash del informe es determinista",
              "PASS" if hash_contenido(_a) == hash_contenido(_b) else "FAIL",
              "" if hash_contenido(_a) == hash_contenido(_b)
              else "depende del orden de las claves: la verificación sería inútil")

        _h = hash_contenido(_a)
        _a["custodia"] = {"hash_este_informe": _h, "hash_cadena": "x"}
        check("el hash no es circular (excluye su propio campo)",
              "PASS" if hash_contenido(_a) == _h else "FAIL")
    except Exception as e:
        check("módulo de cadena de custodia", "FAIL", f"{type(e).__name__}: {e}")

    # ── Función 2: firma del validador ───────────────────────────────────────
    try:
        from modulos.validador_humano import (
            solicitar_identidad, IdentidadRequerida, aviso_segunda_revision,
            UMBRAL_SIN_SEGUNDA_REVISION,
        )
        _falla = False
        try:
            solicitar_identidad(interactivo=False)
        except IdentidadRequerida:
            _falla = True
        except Exception:
            pass
        # Solo es concluyente si el entorno no trae ya una identidad.
        from config.parametros import VALIDADOR_NOMBRE as _vn, VALIDADOR_CARGO as _vc
        if _vn and _vc:
            check("identidad del validador exigible", "PASS",
                  "identidad presente en el entorno; regla no evaluable aquí")
        else:
            check("un informe sin validador no puede emitirse",
                  "PASS" if _falla else "FAIL",
                  "" if _falla else
                  "solicitar_identidad() no exige nombre y cargo: se podrían "
                  "emitir informes de producción sin responsable humano")

        check(f"umbral de segunda revisión definido ({UMBRAL_SIN_SEGUNDA_REVISION})",
              "PASS" if UMBRAL_SIN_SEGUNDA_REVISION >= 2 else "FAIL")
    except Exception as e:
        check("módulo de firma del validador", "FAIL", f"{type(e).__name__}: {e}")

    # ── Función 3: override humano ───────────────────────────────────────────
    try:
        from modulos.override_humano import resumen_override, linea_independencia
        _sin = resumen_override("NoExiste", 10, [])
        check("la ausencia de correcciones se declara explícitamente",
              "PASS" if "totalidad" in linea_independencia(_sin) else "FAIL",
              "" if "totalidad" in linea_independencia(_sin)
              else "un anexo vacío deja al auditor deduciendo si hubo revisión")

        _muchas = [{"titulo_modelo": "M", "fecha": "01/07/2026 10:00",
                    "puntaje_agente": 1, "puntaje_correcto": 5,
                    "ambito": "A", "actividad": f"a{i}", "diferencia": 4}
                   for i in range(20)]
        _pct = resumen_override("M", 5, _muchas)["pct_ajustados"]
        check("el % de ajustes nunca supera 100",
              "PASS" if _pct <= 100 else "FAIL",
              "" if _pct <= 100 else
              f"devuelve {_pct}%: una cifra imposible en un informe regulatorio "
              f"destruye la credibilidad del resto del documento")
    except Exception as e:
        check("módulo de override humano", "FAIL", f"{type(e).__name__}: {e}")

    # ── La señal interna NO puede filtrarse al informe del regulador ─────────
    _gw = (BASE / "modulos" / "generador_word.py").read_text(encoding="utf-8")
    check("la señal interna de calidad no llega al informe entregable",
          "PASS" if "calidad_proceso" not in _gw else "FAIL",
          "" if "calidad_proceso" not in _gw else
          "el % de ajustes del validador se está pintando en el Word: allí es "
          "una acusación implícita a quien firma")

    # ── El prompt conserva su cuestionamiento por ámbito ─────────────────────
    # Las preguntas guía y la instrucción específica se leen con
    # `.get(ambito, ...)`: si el Excel del estándar renombra un ámbito, el
    # prompt pierde su cuestionamiento SIN AVISAR y las actividades se evalúan
    # con las instrucciones genéricas. Como el estándar es un fichero editable
    # por el Responsable de Validación, la desconexión es plausible.
    try:
        from modulos.motor_ia import (
            INSTRUCCIONES_DIMENSION as _INSTR,
            PREGUNTAS_METODOLOGICAS as _PREG,
            _es_ambito_metodologia as _es_met,
            leer_estandares_virf as _leer_est,
        )
        _amb_excel = set()
        for _t in ("1", "2", "3", "4"):
            try:
                _amb_excel |= set((_leer_est(_t) or {}).keys())
            except Exception:
                pass

        if not _amb_excel:
            check("ámbitos del estándar legibles", "WARN",
                  "no se pudo leer Estandares_VIRF.xlsx; comprobación omitida")
        else:
            _sin_preg = sorted(a for a in _amb_excel if a not in _PREG)
            _sin_instr = sorted(a for a in _amb_excel if a not in _INSTR)
            check("cada ámbito del estándar tiene preguntas guía",
                  "PASS" if not _sin_preg else "FAIL",
                  "" if not _sin_preg else
                  f"{_sin_preg} evaluarían sin cuestionamiento y nada lo avisaría")
            check("cada ámbito del estándar tiene instrucción específica",
                  "PASS" if not _sin_instr else "FAIL",
                  "" if not _sin_instr else
                  f"{_sin_instr} recibirían solo las instrucciones genéricas")
            # El ámbito de mayor peso (0.30) es el único que recibe el
            # cuestionamiento metodológico: si deja de reconocerse, lo pierde.
            _hay_met = any(_es_met(a) for a in _amb_excel)
            check("el ámbito de Metodología se reconoce para su cuestionamiento",
                  "PASS" if _hay_met else "FAIL",
                  "" if _hay_met else
                  f"ninguno de {sorted(_amb_excel)} se reconoce como Metodología: "
                  f"el ámbito de mayor peso perdería su bloque de profundidad")
    except Exception as e:
        check("conexión prompt ↔ ámbitos del estándar", "FAIL",
              f"{type(e).__name__}: {e}")

    # ── Función 4: registro append-only de emisiones [PENDIENTE-1] ───────────
    # La cadena de custodia es DETECTIVA: verifica los informes que existen.
    # Estos checks cubren el control PREVENTIVO que detecta los que faltan.
    try:
        import ast as _ast

        _re_src = (BASE / "modulos" / "registro_emisiones.py").read_text(
            encoding="utf-8")

        # 1. El registro no puede reescribirse. Se comprueba por AST y no por
        #    texto (§3.8): la cadena `"w"` aparece en los comentarios que
        #    explican por qué NO se usa, y una búsqueda textual daría PASS
        #    aunque el código hiciera lo contrario de lo que documenta.
        _reescribe = []
        for _n in _ast.walk(_ast.parse(_re_src)):
            if not isinstance(_n, _ast.Call):
                continue
            _fn = getattr(_n.func, "id", None) or getattr(_n.func, "attr", None)
            if _fn in ("write_text", "_escribir_json_atomico"):
                _reescribe.append(f"{_fn}() línea {_n.lineno}")
            elif _fn == "open":
                _modos = [a.value for a in _n.args[1:2]
                          if isinstance(a, _ast.Constant)]
                _modos += [k.value.value for k in _n.keywords
                           if k.arg == "mode" and isinstance(k.value, _ast.Constant)]
                for _m in _modos:
                    if "a" not in str(_m) and "r" not in str(_m):
                        _reescribe.append(f"open(..., {_m!r}) línea {_n.lineno}")
        check("el registro de emisiones es append-only",
              "PASS" if not _reescribe else "FAIL",
              "" if not _reescribe else
              "el registro se reescribe (" + "; ".join(_reescribe) + "): una "
              "emisión pasada puede borrarse y la ausencia volvería a ser "
              "invisible")

        # 2. El registro debe vivir FUERA de outputs/. Si viviera dentro, el
        #    mismo borrado que elimina los informes eliminaría la prueba de que
        #    existieron, y el control sería tan frágil como el que sustituye.
        from modulos.registro_emisiones import RUTA_REGISTRO as _RR
        from config.rutas import OUTPUTS_DIR as _OD
        _fuera = Path(_OD).resolve() not in Path(_RR).resolve().parents
        check("el registro de emisiones vive fuera de outputs/",
              "PASS" if _fuera else "FAIL",
              "" if _fuera else
              f"{_RR} está dentro de {_OD}: se borra junto con su objeto")

        # 3. El registro se anota en el ÚNICO punto por el que pasan los
        #    informes sellados. `sellar_y_escribir()` tiene dos ramas —con lock
        #    y degradada— y dos llamantes —agente.py y motor_ia_v2.py—. El §3.1
        #    del prompt de continuidad documenta cinco defectos con esa forma
        #    exacta: se corrige un camino y se olvida el que se ejecuta.
        _cu_src = (BASE / "modulos" / "custodia.py").read_text(encoding="utf-8")
        _fn_sye = next((n for n in _ast.walk(_ast.parse(_cu_src))
                        if isinstance(n, _ast.FunctionDef)
                        and n.name == "sellar_y_escribir"), None)
        if _fn_sye is None:
            check("sellar_y_escribir() registra la emisión", "FAIL",
                  "la función ya no existe")
        else:
            _rets = [n for n in _ast.walk(_fn_sye) if isinstance(n, _ast.Return)]
            _llam = [(getattr(n.func, "id", None) or getattr(n.func, "attr", None))
                     for n in _ast.walk(_fn_sye) if isinstance(n, _ast.Call)]
            check("toda emisión sellada queda anotada en el registro",
                  "PASS" if ("registrar_emision" in _llam and len(_rets) == 1)
                  else "FAIL",
                  "" if ("registrar_emision" in _llam and len(_rets) == 1) else
                  ("sellar_y_escribir() no llama a registrar_emision()"
                   if "registrar_emision" not in _llam else
                   f"{len(_rets)} `return` en sellar_y_escribir(): una rama "
                   f"puede emitir sin dejar constancia"))
    except Exception as e:
        check("módulo de registro de emisiones", "FAIL", f"{type(e).__name__}: {e}")

    # ── Función 5: aprobación de dos ojos [PENDIENTE-3] ─────────────────────
    try:
        from modulos.validador_humano import (
            SegundaFirmaRequerida, requiere_doble_firma, solicitar_segunda_firma,
        )
        _prim = {"validador": "Ana Pérez", "cargo": "Validador"}
        _antes = os.environ.get("VIRF_DOBLE_FIRMA_TIER")
        os.environ["VIRF_DOBLE_FIRMA_TIER"] = "1"
        try:
            # El segundo firmante debe ser OTRA persona, comparando normalizado.
            # Sin esto el control es decorativo: la misma persona rellena las
            # dos casillas y el informe declara una revisión cruzada inexistente.
            _rechaza = False
            try:
                solicitar_segunda_firma(_prim, "1", "  ana  perez ", "Jefe",
                                        interactivo=False)
            except SegundaFirmaRequerida:
                _rechaza = True
            check("la doble firma rechaza al mismo validador dos veces",
                  "PASS" if _rechaza else "FAIL",
                  "" if _rechaza else
                  "una persona puede firmar las dos casillas: el informe "
                  "declararía una aprobación de dos ojos que no existió")

            # Vía no interactiva: sin ella, habilitar el control apagaría toda
            # corrida automatizada y el equipo lo desactivaría al día siguiente.
            os.environ["VIRF_VALIDADOR_2"] = "Luis Gómez"
            os.environ["VIRF_VALIDADOR_2_CARGO"] = "Jefe de Validación"
            _seg = solicitar_segunda_firma(_prim, "1", None, None,
                                           interactivo=False)
            check("la doble firma tiene vía no interactiva",
                  "PASS" if (_seg or {}).get("validador") == "Luis Gómez" else "FAIL",
                  "" if _seg else
                  "ninguna corrida automatizada podría emitir en un tier con "
                  "doble firma")
        finally:
            os.environ.pop("VIRF_VALIDADOR_2", None)
            os.environ.pop("VIRF_VALIDADOR_2_CARGO", None)
            if _antes is None:
                os.environ.pop("VIRF_DOBLE_FIRMA_TIER", None)
            else:
                os.environ["VIRF_DOBLE_FIRMA_TIER"] = _antes

        # Desactivado por defecto: activarlo solo rompería toda emisión Tier 1
        # automatizada, y un control que rompe el pipeline sin aviso se acaba
        # desactivando. Es la entidad quien declara la política.
        check("la doble firma está desactivada mientras la entidad no la declare",
              "PASS" if not requiere_doble_firma("1")
                        or os.environ.get("VIRF_DOBLE_FIRMA_TIER") else "FAIL")
    except Exception as e:
        check("módulo de aprobación de dos ojos", "FAIL", f"{type(e).__name__}: {e}")

    # ── Función 6: una skill que incumple el contrato NO se reporta como
    #    ejecutada con 0 hallazgos [auditoría 2026-08-07] ────────────────────
    #
    # Es el invariante §3.2 aplicado a las skills: si el modelo no responde
    # conforme al contrato, se declara el fallo. Un «0 hallazgos» silencioso es
    # indistinguible de un análisis limpio, y el validador no puede saber que
    # esa skill nunca llegó a analizarse.
    #
    # Se comprueba EJECUTANDO la skill con el modelo interceptado: coste 0, sin
    # API. Comprobar el literal del código no serviría — el defecto se puede
    # reescribir de otra forma y el control seguiría en verde.
    try:
        import json as _json
        import logging as _logging
        from modulos import motor_ia as _M
        from modulos.skills.catalogo import SkillSintesis as _SkSint

        _orig_llamar = _M._llamar_modelo
        _ctx = "Manual con contenido suficiente para el prompt. " * 30
        # La skill avisa por el logger de cada fallo — que es justo lo que
        # estamos provocando. Se silencia para no imprimir tres «falló» que
        # parecerían errores en una corrida verde.
        _log_skills = _logging.getLogger("modulos.skills.base")
        _nivel_previo = _log_skills.level
        _log_skills.setLevel(_logging.CRITICAL)
        try:
            def _correr(_payload):
                _M._llamar_modelo = (
                    lambda *a, _r=_json.dumps(_payload, ensure_ascii=False), **k: _r)
                return _SkSint(_ctx, "M", [], "", resultados_previos=[]).ejecutar()

            # Incumplimientos: clave ausente, clave nula, y prosa en vez de lista.
            _malos = [
                {"hallazgos": [{"titulo": "A"}], "resumen": "ok"},
                {"prioridades": None, "resumen": "ok"},
                {"prioridades": "tres asuntos críticos", "resumen": "ok"},
            ]
            _colados = [p for p in _malos if _correr(p).get("ok")]
            check("una skill que incumple el contrato se declara, no calla",
                  "PASS" if not _colados else "FAIL",
                  "" if not _colados else
                  f"{len(_colados)}/3 respuestas incumplidoras se reportaron como "
                  f"skill ejecutada con 0 hallazgos: el informe no distingue "
                  f"«no encontró nada» de «no llegó a analizarse»")

            # Y el control que impide pasarse de frenada: «analicé y no hay
            # nada» es un resultado legítimo y NO puede marcarse como fallo.
            _vacio = _correr({"prioridades": [], "resumen": "nada que reportar"})
            check("una skill sin hallazgos sigue siendo una skill correcta",
                  "PASS" if _vacio.get("ok") and not _vacio.get("hallazgos")
                  else "FAIL",
                  "" if _vacio.get("ok") else
                  "una lista vacía legítima se marca como fallo: el aviso se "
                  "vuelve ruido y el equipo aprende a ignorarlo")
        finally:
            _M._llamar_modelo = _orig_llamar
            _log_skills.setLevel(_nivel_previo)
    except Exception as e:
        check("contrato de las skills", "FAIL", f"{type(e).__name__}: {e}")

    # ── Los flags de auditoría existen ──────────────────────────────────────
    _ag = (BASE / "agente.py").read_text(encoding="utf-8")
    for _flag in ("--verificar-cadena", "--verificar-evidencia",
                  "--verificar-emisiones", "--validador-2", "--cargo-2",
                  "--historial-validaciones", "--validador", "--cargo"):
        check(f"flag {_flag} disponible",
              "PASS" if f'"{_flag}"' in _ag else "FAIL")


# ═════════════════════════════════════════════════════════════════════════════
def main() -> int:
    ap = argparse.ArgumentParser(description="Validador de integridad del proyecto VIRF")
    ap.add_argument("--strict", action="store_true",
                    help="exit code 1 si hay algún FAIL")
    args = ap.parse_args()

    print("═" * 74)
    print("  🔍 VALIDACIÓN DE INTEGRIDAD — VIRF AGENT")
    print(f"  Proyecto: {BASE}")
    print("═" * 74)

    val_estructura()
    val_seguridad()
    val_config()
    val_dependencias()
    val_estandar_y_evidencia()
    val_patrones_cache_modulos()
    val_cobertura_documentos()   # [auditoría 2026-07-26]
    val_salidas()                # [auditoría 2026-07-26]
    val_codigo_muerto()          # [auditoría 2026-07-26]
    val_invariantes_auditoria()  # [auditoría exhaustiva 2026-07-28]
    val_cumplimiento_regulatorio()  # [cumplimiento 2026-07-29]

    total = sum(_RES.values())
    print("\n" + "═" * 74)
    print("  RESUMEN")
    print("═" * 74)
    print(f"  ✅ PASS : {_RES['PASS']:>3} / {total}")
    print(f"  ⚠️  WARN : {_RES['WARN']:>3} / {total}")
    print(f"  ❌ FAIL : {_RES['FAIL']:>3} / {total}")

    if _RES["FAIL"]:
        print("\n  🔴 Hay comprobaciones en FAIL. Corrígelas antes de emitir dictámenes.")
    elif _RES["WARN"]:
        print("\n  🟡 Sin errores críticos. Revisa los WARN (suelen ser evidencia ausente).")
    else:
        print("\n  🟢 Proyecto íntegro. Listo para ejecutar.")
    print("═" * 74 + "\n")

    return 1 if (args.strict and _RES["FAIL"]) else 0


if __name__ == "__main__":
    sys.exit(main())
