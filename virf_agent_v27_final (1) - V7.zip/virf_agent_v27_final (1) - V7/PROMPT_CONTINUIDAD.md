# Prompt de continuidad — VIRF Agent v27

**Cómo usar este documento.** Pégalo completo como primer mensaje a la IA que
vaya a continuar el trabajo. Contiene el contexto mínimo del proyecto, los
invariantes que no puede romper, las trampas concretas de este código y el
encargo pendiente. Está escrito para que no haga falta explicarle nada más.

---

## Rol

> Actúas como **Ingeniero de Software Senior especializado en sistemas de
> auditoría regulatoria**. Trabajas sobre VIRF Agent v27, un agente de
> validación independiente de modelos financieros usado por un equipo de 2-5
> validadores en una entidad supervisada.
>
> Regla de oro de este proyecto: **no marques nada como correcto sin haber
> leído el código real o ejecutado el caso real.** Un informe de validación
> equivocado tiene consecuencias regulatorias, así que aquí un falso «✅ OK»
> cuesta más que un fallo declarado.

---

## 1. Qué es el proyecto

VIRF valida modelos financieros (LaR, VaR, scoring, IFRS9, conductuales)
comparando la **evidencia documental** que aporta el dueño del modelo contra un
**estándar de validación** (`inputs/Estandares_VIRF.xlsx`) organizado en 6
ámbitos y 4 tiers de exigencia.

**No valida matemáticas: valida que la metodología esté documentada, justificada
y coherente con la evidencia.** El agente produce un borrador trazable que un
validador humano corrige y firma.

| Ámbito | Peso | Anclaje |
|---|---:|---|
| Metodología | 0.30 | SR 11-7 §IV — conceptual soundness |
| Calidad de datos | 0.20 | BCBS 239 principios 3-5 |
| Documentación | 0.15 | EBA/GL/2023/01 §6.3 |
| Implementación | 0.15 | SR 11-7 §IV — outcome analysis |
| Gobierno | 0.12 | EBA/GL/2023/01 §5 |
| Uso e integración | 0.08 | SR 11-7 §IV — ongoing monitoring |

**Estado:** 55 ficheros `.py`, 24.433 líneas, 356 tests, 131 checks de
integridad. Ambas puertas en verde.

**Documentación existente — LÉELA ANTES DE TOCAR NADA:**

| Documento | Contenido |
|---|---|
| `METODOLOGIA_DEL_AGENTE.md` | Cómo piensa el agente, fase por fase, con los 6 invariantes |
| `INFORME_AUDITORIA_2026-07-29.md` | Auditoría de 7 fases: 41 defectos, patrones dominantes |
| `GUIA_MULTIMODELO_Y_RAG.md` | Validar varios modelos · poblar y verificar el RAG |
| `README.md` | Instalación, flags, costes medidos del chunking |

---

## 2. Los invariantes que NO puedes romper

Están protegidos por tests y por `validate_project.py`. Si un cambio tuyo hace
fallar uno, el cambio está mal — no el test.

**1. No se evalúa sobre el vacío.** Sin evidencia no se llama al modelo.
Preguntar a un LLM sobre un documento que no existe produce una alucinación con
formato de dictamen.

**2. No se inventa un puntaje.** Si el modelo no responde conforme al contrato
JSON, la actividad queda sin puntaje y se reporta como fallo técnico. Nunca se
rellena con un valor por defecto.

**3. Ausencia de evidencia y fallo técnico son cosas distintas, con
responsables opuestos.**

| Causa | Responsable | Score | Semáforo |
|---|---|---|---|
| **Sin evidencia** — no se aportó documentación | El validado | **0.0**, con su peso íntegro | «NO EVALUABLE — SIN EVIDENCIA», rojo |
| **Fallo técnico** — timeout, PDF ilegible, JSON roto | El agente | `None`, excluido, renormaliza | «NO EVALUABLE — FALLO TÉCNICO», gris |

> Política de la entidad: la falta de evidencia **es** una falta crítica y debe
> arrastrar el score. Lo inadmisible es (a) que un fallo nuestro se impute al
> validado y (b) que el informe no distinga una causa de la otra.
>
> La escala de puntuación es 1-5, así que **score 0.0 ⟺ sin evidencia** de forma
> inequívoca. Si alguna vez cambias la escala, este invariante se rompe.

**4. La cobertura declarada es la cobertura real.** Ningún documento se recorta
en silencio. Si solo se leyó el 30 %, el informe dice 30 %. La cobertura es lo
que el auditor lee como exhaustividad: inflarla produce confianza injustificada.

**5. Toda corrida es reproducible.** Huella SHA-256 de configuración y de cada
documento, versión del agente y del modelo, sello UTC.

**6. El informe evalúa el modelo que dice evaluar.** Un árbol de evidencia = un
modelo. La huella documental (`agente.documentos_huella`) es la prueba.

---

## 3. Trampas concretas de ESTE código

Cada una costó horas de diagnóstico. No las redescubras.

### 3.1. El patrón que más veces ha fallado: **arreglo aplicado a medias**

Ha ocurrido **cinco veces**. Siempre igual: una función tiene dos caminos, se
corrige uno, y el olvidado es el que se ejecuta por defecto.

| Caso | Rama corregida | Rama olvidada | Consecuencia |
|---|---|---|---|
| TRUNCADO-FIX | lectura directa | **del caché** | informes emitidos sobre el 1,2 % del manual |
| Custodia | lectura fresca | **del caché** | evidencia `NO VERIFICABLE` en casi todos los informes |
| Historial (lectura) | `feedback.py` | **`feedback_mejorado.py`** | corrupción leída como vacío; ajuste anti-sesgo desactivado en silencio |
| Historial (escritura) | `feedback.py` | **`feedback_mejorado.py`** | `open(...,"w")` sin lock podía truncar el historial de todo el equipo |
| Lectores de evidencia | 6 de 11 | **5 restantes** | errores de lectura entrados como evidencia con cobertura 100 % |

> **Regla operativa: cuando corrijas algo, busca TODAS las rutas que lo
> atraviesan, empezando por la del caché — que es la que se toma siempre y la
> que siempre se olvida.**

### 3.2. `Mx_00_CargaRutas` vive DOS VECES en `sys.modules`

```python
import Mx_00_CargaRutas          # motor/ está en sys.path
import motor.Mx_00_CargaRutas    # cualificado por paquete
# → dos objetos de módulo distintos, con dos dicts RUTAS distintos
```

`agente.py` importa por una vía y `Mx_01` por la otra. Mutar «el» `RUTAS`
actualiza una copia mientras el lector consulta la otra. **Fallo silencioso**:
la consola anunciaba `Evidencia: modelos/VaR_FRTB` mientras leía la del
proyecto, y se emitió un informe titulado «VaR Mercado FRTB» cuya huella
contenía `Manual_Metodologico_LaR_completo.pdf`.

Aplica igual a `document_cache` (documentado en un comentario de `Mx_01`).

### 3.3. Un import dentro de una función lo hace local a TODA la función

```python
def main():
    if rama_poco_frecuente:
        from modulos.chunker import ChunkerService   # ← marca el nombre LOCAL
    ...
    _chunker = ChunkerService(...)   # UnboundLocalError si no se tomó la rama
```

Esto dejó **el pipeline principal muerto al 100 %**, y el mensaje culpaba al
chunker en vez al import. Hay un test que detecta la clase de fallo en todo
`agente.py`, `modulos/`, `motor/` y `config/`.

### 3.4. `.get(clave, respaldo)` no hace lo que parece

El segundo argumento solo actúa si la clave **falta**, no si existe con valor
nulo. `ev.get("score", ev.get("puntaje"))` devuelve `None` cuando `score` está
presente y vale `None`, descartando un puntaje válido. Ha fallado dos veces
(`.get("puntaje", 50)` y la anterior).

### 3.5. Ordenar una cadena de hashes por fecha es incorrecto

El sello tiene precisión de **segundos**; tres corridas seguidas caen en el
mismo segundo y el orden queda arbitrario → los tres eslabones se reportan
ROTOS sin que nadie los haya tocado. El orden **ya está en los enlaces**: cada
informe declara el hash de su predecesor. Se reconstruye siguiéndolos.

### 3.6. Comprueba la procedencia, no el volumen

Un recuento de caracteres plausible no acredita que se leyera la evidencia
correcta. **Solo `agente.documentos_huella` responde qué se leyó.** Ya me
equivoqué afirmando un aislamiento «verificado» mirando el número de caracteres.

### 3.7. Tests que dependen del estado mutable del proyecto

Varios tests leían `feedback/historial_feedback.json` real. Uno se llamaba
«con historial vacío» y fallaba en cuanto alguien registraba una corrección.
**Aísla siempre con `tmp_path` + `monkeypatch`.**

### 3.8. Al escribir tests, no coincidas con tus propios comentarios

Me pasó **cuatro veces**: el test buscaba un literal que aparecía en el
comentario explicativo del propio fix. Filtra las líneas de comentario o, mejor,
**usa AST** en vez de coincidencia de texto.

---

## 4. Cómo trabajar

### Puertas obligatorias — ambas deben quedar en verde

```bash
python validate_project.py --strict     # 131 checks, coste 0, exit 1 si falla
python -m pytest -q                     # 356 tests (~4 min)
```

Un fallo en `--strict` es **bloqueante**: cuesta cero y cubre invariantes que
costaron dinero descubrir.

### Antes de la primera corrida real

```bash
python agente.py --limpiar-cache        # limpia AMBOS cachés (documentos y resúmenes)
```

### Corrida de validación

```bash
python agente.py --titulo "VaR Mercado FRTB" --tier 1 \
                 --raiz-evidencia modelos/VaR_FRTB --prdc \
                 --validador "Nombre Apellido" --cargo "Validador de Segunda Línea"
```

`--prdc` **rechaza la emisión sin validador identificado** (SR 11-7 §V).
Un modelo por raíz de evidencia: sin `--raiz-evidencia` se lee todo `inputs/`.

### Verificación de cumplimiento (no consume API)

```bash
python agente.py --verificar-cadena "VaR Mercado FRTB"
python agente.py --verificar-evidencia outputs/<fecha>/resultados_<modelo>_<fecha>.json
python agente.py --historial-validaciones
```

### Cada corrección que hagas debe llevar

1. Un comentario `[AUDIT-FIX]` que explique **qué hacía antes, por qué estaba
   mal y cómo se midió** — no solo qué hace ahora. El estado sin la historia se
   erosiona en el primer refactor.
2. Un test que **falle si el defecto vuelve**. Verifícalo reintroduciendo el bug
   a propósito y comprobando que el test lo detecta.
3. Si el invariante se puede comprobar sin API, un check en
   `validate_project.py`.

---

## 5. ENCARGO PENDIENTE

Cinco huecos para que el sistema resista una auditoría externa (SBS / Big4).
En orden de gravedad. **No son mejoras de rendimiento: son requisitos que un
auditor va a exigir ver.**

### PENDIENTE 1 — La cadena de custodia es detectiva, no preventiva ⬛ crítico

**Problema.** `verificar_cadena` detecta si un informe fue *editado*, pero nada
impide **borrar** `outputs/` entero. Sin ficheros no hay cadena que verificar, y
el sistema no distingue «se borró la evidencia» de «nunca se validó». Un auditor
lo señalará de inmediato.

**Qué implementar.** Un registro *append-only* del hash de cada informe emitido,
**fuera de `outputs/`** (p. ej. `audit_logs/registro_emisiones.jsonl`), con una
línea por emisión: `{timestamp, modelo, hash_informe, hash_cadena, validador}`.
Y un comando `--verificar-emisiones` que compare ese registro contra los
informes presentes y reporte **ausencias**, no solo alteraciones.

**Criterios de aceptación.**
- Borrar un informe de `outputs/` se detecta como AUSENTE, no como inexistente.
- El registro nunca se reescribe: solo se añaden líneas (`"a"`, no `"w"`).
- Escritura con lock entre procesos y atómica — ver `modulos/document_cache.py`
  (`_lock_archivo`, `_escribir_json_atomico`); el equipo tiene 2-5 personas.
- Test que borre un informe y confirme la detección.

> Ojo: `outputs/` está en `.gitignore`. Decide y documenta si el registro debe
> versionarse (yo diría que sí: es la evidencia de que los informes existieron).

### PENDIENTE 2 — Nadie firma las correcciones del feedback ⬛ alto

**Problema.** `feedback/historial_feedback.json` guarda **qué** se corrigió pero
**no quién**. El anexo del Word dice «el validador ajustó 2 puntajes» sin poder
acreditar cuál. En un equipo de 2-5 personas eso rompe la atribución, y el anexo
es justo la evidencia de supervisión humana. La función
`override_humano.calidad_proceso()` atribuye correcciones «por modelo aprobado»
y documenta explícitamente que es una aproximación.

**Qué implementar.** Añadir `validador` y `cargo` a cada registro de feedback,
tomados de la misma fuente que la firma del informe
(`modulos/validador_humano.solicitar_identidad`). Retrocompatibilidad
obligatoria: los registros antiguos no tienen el campo y **no se pueden
descartar** — son meses de calibración. Trátalos como `validador: "(no
registrado)"`.

**Criterios de aceptación.**
- El anexo del Word muestra quién hizo cada corrección.
- `calidad_proceso()` deja de aproximar por modelo y elimina su nota de
  atribución aproximada.
- Los registros previos siguen contando para el ajuste anti-sesgo.
- Test con historial mixto (con y sin autor).

### PENDIENTE 3 — No hay aprobación de dos ojos ⬛ alto

**Problema.** La segregación se **detecta** (`aviso_segunda_revision`) y se
avisa en el informe, pero un solo validador puede emitir todo. Para modelos
**Tier 1** un supervisor razonablemente exigirá dos firmas.

**Qué implementar.** Un modo de doble firma configurable — sugerencia:
`VIRF_DOBLE_FIRMA_TIER=1` — que en los tiers indicados exija un segundo
validador distinto del primero antes de emitir el Word.

**Decisión de diseño que debes razonar y documentar:** ¿bloquea o avisa? El
criterio vigente en este proyecto es que **el aviso no bloquea**, porque en un
equipo de dos personas la rotación puede ser imposible y bloquear impediría
trabajar. Para la doble firma en Tier 1 quizá sí deba bloquear. Justifícalo en
el código.

**Criterios de aceptación.**
- El segundo firmante debe ser **distinto** del primero (compara normalizando).
- Ambas firmas viajan al JSON y al Word.
- Vía no interactiva disponible, o ninguna corrida automatizada podrá emitir.
- Test: mismo nombre dos veces → rechazado.

### PENDIENTE 4 — El corpus RAG son resúmenes secundarios ⬛ medio

**Problema.** `inputs/rag/<dominio>/` contiene 8 PDF generados por
`scripts/generar_corpus_rag.py` a partir de marcos públicos. **No son los textos
oficiales.** Cada PDF lo declara en portada, pie y dentro de su texto indexable,
pero si un fragmento inexacto sustenta una conclusión regulatoria, el problema
es de quien firma.

Los umbrales numéricos (recortes del LCR, sublímites de Nivel 2B, plazos de
repreciación de NMD) se dejaron **deliberadamente sin cifra**, remitiendo al
texto oficial: han cambiado con las revisiones y difieren por transposición.

**Qué hacer.** Sustituir por los PDF oficiales (BCBS 238/239/295/457, SR 11-7,
EBA/GL, TRIM Guide) y reindexar:

```python
from src.rag.VaR.indexer import VaRIndexer
VaRIndexer().build_index(force_rebuild=True)
```

**Verifica después** que cada dominio recupera **solo lo suyo** (hubo
contaminación cruzada: los cuatro índices llenos del mismo manual) y que
`rag_chunks > 0` en el JSON de una corrida real — que el índice exista no
prueba que aporte.

### PENDIENTE 5 — Falta el manual de procedimiento ⬛ medio

**Problema.** El código implementa controles; **el procedimiento que los
gobierna no existe como documento.** Un auditor pide el documento que dice
*quién* valida, *cada cuánto*, *con qué criterios de aceptación* y *cómo se
escala un hallazgo crítico*.

**Qué producir.** `PROCEDIMIENTO_VALIDACION.md` con, como mínimo: roles y
segregación; periodicidad por tier; criterios de aceptación y rechazo (¿qué
score obliga a no aprobar?); escalado de hallazgos críticos; tratamiento de la
falta de evidencia; retención de informes; y quién puede modificar
`Estandares_VIRF.xlsx` y con qué aprobación.

**Esto no es trabajo de código.** Necesitarás preguntar al usuario por las
políticas reales de la entidad. **No las inventes**: un procedimiento
fabricado que no refleje la práctica real es peor que su ausencia, porque el
auditor comprobará si se cumple.

---

## 6. Cómo entregar

Al terminar cada pendiente:

1. Ambas puertas en verde, con el número de checks y tests.
2. Los tests nuevos, y **la prueba de que detectan el defecto** (reintrodúcelo y
   muestra que falla).
3. Una corrida real que demuestre la función, con la **huella documental**
   verificada — no un recuento de caracteres.
4. Lo que **no** hiciste y por qué, si algo quedó fuera.

Si encuentras un defecto que no estaba en el encargo, repórtalo con: fichero,
cómo lo reprodujiste, corrección y test. Si el defecto lo introdujiste tú,
dilo — en este proyecto **cuatro de los últimos seis defectos los introdujo
quien los estaba arreglando**, y ocultarlo habría dejado la corrección a medias.

---

## 7. Aviso final

Este proyecto tiene una asimetría deliberada que gobierna todo el diseño:

> **Prefiere siempre declarar una ausencia antes que rellenar un hueco.**

Un validador que se inventa una evidencia produce mucho más daño que uno que
dice «no lo encontré». Si en algún momento dudas entre hacer que el sistema
parezca más completo o que declare su límite, **declara el límite**.
