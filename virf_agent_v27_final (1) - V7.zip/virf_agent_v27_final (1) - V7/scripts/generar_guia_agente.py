"""
scripts/generar_guia_agente.py — Guía de VIRF para el agente corporativo (DOCX y PDF).

Genera `docs/agente_corporativo/GUIA_VIRF_AGENTE_CORPORATIVO.docx` (y `.pdf` con `--pdf`) a
partir del PROPIO repositorio, para que la guía no se quede atrás cuando cambia el código:

  · Texto explicativo: `docs/agente_corporativo/00_LEEME.md`, `CONOCIMIENTO_VIRF.md`,
    `skills/*.md` y `docs/FLUJO_AGENTE.md` (se escriben a mano, en Markdown).
  · Recorrido por la interfaz: capturas de `docs/agente_corporativo/capturas/NN_*.jpg` con su
    explicación (tabla PANTALLAS de este script).
  · Muestras de los informes Word: páginas de los PDF de `ejemplos/` (si existen).
  · Referencia generada del código: ficha por módulo (propósito, funciones, quién lo importa,
    tests que lo cubren, comunidades del grafo), catálogo de endpoints (desde la app FastAPI),
    catálogo de tests, variables de entorno, comunidades y nodos centrales del grafo.

Uso:
    .venv\\Scripts\\python.exe scripts\\generar_guia_agente.py           # solo .docx
    .venv\\Scripts\\python.exe scripts\\generar_guia_agente.py --pdf     # .docx + .pdf (Word)

`--pdf` es un flag explícito (no se detecta Word por heurística): convierte con Microsoft Word
vía PowerShell/COM. En una máquina sin Word, convertir el .docx con LibreOffice.
No llama a ninguna IA.
"""
from __future__ import annotations

import argparse
import ast
import collections
import json
import re
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

RAIZ = Path(__file__).resolve().parent.parent
for _p in (RAIZ, RAIZ / "motor"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from docx import Document  # noqa: E402
from docx.enum.text import WD_ALIGN_PARAGRAPH  # noqa: E402
from docx.oxml import OxmlElement  # noqa: E402
from docx.oxml.ns import qn  # noqa: E402
from docx.shared import Cm, Pt, RGBColor  # noqa: E402

from modulos import plantilla_bcp as PB  # noqa: E402

DIR_GUIA = RAIZ / "docs" / "agente_corporativo"
NOMBRE = "GUIA_VIRF_AGENTE_CORPORATIVO"

# Código vivo que se documenta (lo archivado y el código muerto quedan fuera).
CARPETAS_CODIGO = ("agente.py", "config", "motor", "modulos", "src", "web", "skills", "scripts")
_EXCLUIR = ("archivo", "codigo_muerto", "__pycache__", ".venv", "graphify-out", "data")

# ── Recorrido por la interfaz: qué es cada captura ──────────────────────
# (archivo, título, para qué sirve, endpoints, archivos implicados, si falla → skill)
PANTALLAS = [
    ("01_login", "Entrada (login)",
     "El validador entra con su código (T + 3–7 dígitos) y su nombre. Si el código no existe se "
     "registra al vuelo. La sesión vive en memoria del servidor: al reiniciarlo hay que volver a entrar.",
     "POST /api/auth/login · GET /api/auth/actual · POST /api/auth/logout",
     "web/routers/auth.py · web/services/sesion_store.py · web/static/js/app.js (submitLogin)", "S04"),
    ("02_mis_modelos", "Mis Modelos",
     "Lista los modelos del validador con dominio, tier, estado y última actividad. Una fila abre el "
     "expediente del modelo (también con Enter). Desde aquí se entra a «Solo Informe».",
     "GET /api/modelos · POST /api/modelos/{slug}/activar",
     "web/routers/modelos.py · web/services/modelos_store.py · app.js (pintarListaModelos)", "S04"),
    ("03_nuevo_modelo", "Nuevo modelo",
     "Crea un expediente: nombre, dominio (VaR, LaR, ALM o un dominio personalizado) y tier. El dominio "
     "decide qué literatura (RAG) se usa y no se cambia después.",
     "POST /api/modelos · GET /api/rag/dominios",
     "web/routers/modelos.py · web/services/modelos_store.py · web/services/dominios_custom_store.py", "S04"),
    ("04_dashboard_inicio", "Expediente: portada y guía de pasos",
     "Muestra en qué paso está la validación (9 pasos, 6 obligatorios), el siguiente paso y una barra "
     "de progreso. El menú lateral lleva a cada paso y a las consultas.",
     "GET /api/guia/progreso", "web/routers/guia.py · web/static/js/guia.js", "S04"),
    ("05_configuracion", "Paso 01 · Configuración",
     "Título y tier del modelo, proveedor de IA (Azure OpenAI, OpenAI o Claude) y VIRF PLUS. «Verificar "
     "conexión» hace una llamada mínima. Las claves se guardan en el .env del proyecto.",
     "GET/POST /api/config · POST /api/config/verificar",
     "web/routers/config.py · web/services/env_service.py · config/ia.py · config/parametros.py", "S05"),
    ("06_estandares", "Paso 02 · Estándares",
     "Se sube el Estandares_VIRF.xlsx del modelo; se ve una vista previa por ámbito y se confirma. El "
     "estándar confirmado se pasa al pipeline con --estandares.",
     "POST /api/estandares/upload · POST /api/estandares/confirmar · GET /api/estandares/estado",
     "web/routers/estandares.py · web/services/estandares_service.py", "S06"),
    ("07_evidencia", "Paso 03 · Evidencia",
     "Carpetas por tipo de evidencia: documentación (modelamiento, seguimiento, controles de datos), "
     "datasets, resultados de calidad de datos, implementación (ZIP del código), usos, Excels de "
     "automatización. Tras subir el código se puede pedir el «Entendimiento del modelo».",
     "GET /api/inputs/arbol · POST /api/inputs/upload · POST /api/inputs/upload-zip · /api/entendimiento/*",
     "web/routers/upload.py · web/services/contexto_sesion.py · web/services/analisis_codigo.py", "S09"),
    ("08_dominio_rag", "Paso 04 · Dominio y literatura",
     "Muestra el dominio del modelo y la literatura técnica por dominio (compartida por todos los "
     "validadores). Se pueden subir papers y reconstruir el índice léxico (BM25 + TF-IDF, local).",
     "GET /api/rag/dominios · POST /api/rag/upload · POST /api/rag/rebuild",
     "web/routers/rag.py · src/rag/* · web/services/dominios_custom_store.py", "S07"),
    ("09_skills", "Paso 05 · Skills (capacidades)",
     "Análisis adicionales (coherencia documental, código vs manual, patrones problemáticos, "
     "backtesting, síntesis…). Producen hallazgos, no cambian el puntaje. Configuración por sesión.",
     "GET/POST /api/skills", "web/routers/skills.py · web/services/skills_store.py · modulos/skills/", "S04"),
    ("10_cuestionamientos", "Paso 06 · Cuestionamientos metodológicos",
     "15 patrones que el agente busca en el código del modelo (data leakage, imputación por media, "
     "look-ahead bias…) más preguntas propias del validador en lenguaje natural.",
     "GET/POST /api/cuestionamientos* ",
     "web/routers/cuestionamientos.py · cuestionamientos_sesion.py · modulos/cuestionamientos_ext.py", "S04"),
    ("11_validar", "Paso 08 · Validar modelo",
     "Lanza el pipeline (agente.py --prdc) como subproceso y muestra su consola en vivo. Exige nombre y "
     "cargo del validador firmante (doble firma opcional). Al terminar deja un JSON de resultados.",
     "POST /api/validar/lanzar · GET /api/validar/estado · WS /ws/validar/{run_id}",
     "web/routers/validacion.py · web/services/pipeline_runner.py · agente.py · modulos/motor_ia.py", "S01"),
    ("12_documentar", "Paso 09 · Documentar",
     "Estado de la validación (evidencia, JSON, chat, corrida), cuadro de observaciones de los Excels de "
     "automatización y botón para generar el informe Word versionado (V1, V2…).",
     "GET /api/informe/estado · POST /api/informe/consolidado · POST /api/automatizaciones/cuadro",
     "web/routers/informe.py · web/services/informe_web.py · modulos/plantilla_bcp.py · modulos/capturas.py", "S02"),
    ("13_resultados", "Consulta · Resultados",
     "Lectura de una corrida: puntaje global y semáforo, políticas aplicadas (§6 críticos, §4.2 veto), "
     "tabla de validación intermedia y el detalle por actividad con la evidencia citada.",
     "GET /api/resultados/actual · GET /api/resultados/lista",
     "web/routers/resultados.py · modulos/tabla_validacion (datos del JSON)", "S01"),
    ("14_controles_datos", "Consulta · Controles de datos",
     "Catálogo de motores de calidad de datos, resultados de la entidad y el notebook ejecutable de "
     "controles para el entregable.",
     "GET /api/motores/* · GET /api/motores/notebook",
     "web/routers/controles.py · modulos/motores_datos.py · modulos/notebook_controles.py", "S08"),
    ("15_chat", "Consulta · Chat de validación",
     "El área sustenta las observaciones; el agente propone y el validador cierra cada una como "
     "APROBADO, NEGADO o PENDIENTE. Se puede adjuntar evidencia nueva. Al consolidar se recalcula el "
     "puntaje final y se descarga el acta de cierre.",
     "POST /api/chat/iniciar · WS /ws/chat · POST /api/chat/consolidar · GET /api/chat/acta.xlsx",
     "web/routers/chat.py · web/services/chat_service.py · modulos/consolidacion.py", "S10"),
    ("16_guia_ayuda", "Guía de ayuda (botón «?»)",
     "Panel lateral con los pasos, su estado (hecho, siguiente, pendiente, opcional) y qué hace falta "
     "en cada uno.", "GET /api/guia/progreso", "web/static/js/guia.js · web/routers/guia.py", "S04"),
    ("17_solo_informe", "Solo Informe · estándar, IA y manuales",
     "Genera el Informe de Resultados SIN ejecutar el pipeline. Muestra el proveedor de IA activo, el "
     "estándar cargado (filtrable por Tier) y los manuales del modelo para que la IA cite archivo y página.",
     "GET /api/solo-informe/estado · POST /api/solo-informe/estandar · /api/solo-informe/manuales",
     "web/routers/solo_informe.py · web/services/solo_informe_service.py · solo_informe_ia.py", "S02"),
    ("18_solo_informe_datos", "Solo Informe · datos de la validación",
     "Tipo (periódica o primera vez), tier, nombre del modelo, fechas, responsable de la documentación, "
     "revisor, contexto y limitaciones; cada texto con «Pulir con IA» y «Redactar desde los manuales».",
     "PUT /api/solo-informe/borrador · POST /api/solo-informe/ia/pulir · /ia/manuales",
     "web/static/js/app.js (bloque Solo Informe) · web/services/solo_informe_ia.py", "S02"),
    ("19_solo_informe_observacion", "Solo Informe · registrar observación",
     "Ámbito, riesgo, actividad del estándar, observación, recomendación, responsable/fecha (no para "
     "Oportunidad de Mejora) y sustento (imagen, código o texto). La IA puede crear un gráfico de textos "
     "largos. «Generar informe Word» aplica la regla de calificación.",
     "POST /api/solo-informe/imagen · /ia/grafico · POST /api/solo-informe/generar",
     "web/services/solo_informe_word.py · modulos/reglas_informe.py · modulos/plantilla_bcp.py", "S03"),
    ("20_movil_mis_modelos", "Móvil · Mis Modelos",
     "A 375 px la cabecera se parte en líneas, la tabla muestra modelo, dominio y estado, y el foco de "
     "teclado se ve como un anillo mostaza.", "—", "web/static/css/styles.css (@media max-width: 760px)", "S04"),
    ("21_movil_solo_informe", "Móvil · Solo Informe",
     "Formulario en una sola columna; las tablas anchas se desplazan dentro de su recuadro.",
     "—", "web/static/css/styles.css", "S04"),
    ("22_movil_dashboard", "Móvil · Expediente",
     "El menú lateral pasa a barra horizontal desplazable; el contenido usa todo el ancho.",
     "—", "web/static/css/styles.css", "S04"),
]


# ══════════════════════════════════════════════════════════════════════
#  Extracción de información del repositorio
# ══════════════════════════════════════════════════════════════════════

def archivos_codigo() -> list[Path]:
    salida = []
    for c in CARPETAS_CODIGO:
        p = RAIZ / c
        for f in ([p] if p.is_file() else sorted(p.rglob("*.py")) if p.is_dir() else []):
            rel = f.relative_to(RAIZ).parts
            if any(x.startswith(e) for x in rel for e in _EXCLUIR) or f.name == "__init__.py":
                continue
            salida.append(f)
    return salida


def _rel(p: Path) -> str:
    return p.relative_to(RAIZ).as_posix()


def _dotted(p: Path) -> str:
    return ".".join(p.relative_to(RAIZ).with_suffix("").parts)


def proposito(docstring: str, ruta: Path) -> str:
    """Primer párrafo con contenido real (salta líneas que solo repiten el nombre del archivo)."""
    parrafos, actual = [], []
    for linea in (docstring or "").splitlines():
        l = linea.strip()
        if not l or set(l) <= set("═─=-—·"):
            if actual:
                parrafos.append(" ".join(actual)); actual = []
            continue
        if ruta.name in l and len(l) < len(ruta.as_posix()) + 25 and not actual:
            continue
        actual.append(l)
    if actual:
        parrafos.append(" ".join(actual))
    return parrafos[0] if parrafos else ""


def _primera_linea(doc: Optional[str]) -> str:
    for l in (doc or "").splitlines():
        if l.strip():
            return l.strip()
    return ""


def _imports(arbol: ast.AST, modulo: str) -> set[str]:
    """Módulos importados (dotted), resolviendo imports relativos."""
    paquete = modulo.rsplit(".", 1)[0] if "." in modulo else ""
    out = set()
    for n in ast.walk(arbol):
        if isinstance(n, ast.Import):
            out |= {a.name for a in n.names}
        elif isinstance(n, ast.ImportFrom):
            base = n.module or ""
            if n.level:
                partes = paquete.split(".") if paquete else []
                partes = partes[: len(partes) - (n.level - 1)] if n.level > 1 else partes
                base = ".".join([*partes, base] if base else partes)
            out.add(base)
            out |= {f"{base}.{a.name}" for a in n.names}
    return out


def analizar_modulos() -> list[dict]:
    archivos = archivos_codigo()
    tests = sorted((RAIZ / "tests").glob("test_*.py"))
    fichas = []
    imports_por_archivo: dict[str, set[str]] = {}
    for f in archivos + tests:
        try:
            arbol = ast.parse(f.read_text(encoding="utf-8", errors="ignore"))
        except SyntaxError:
            continue
        imports_por_archivo[_rel(f)] = _imports(arbol, _dotted(f))
    comunidades = comunidades_por_archivo()
    for f in archivos:
        texto = f.read_text(encoding="utf-8", errors="ignore")
        try:
            arbol = ast.parse(texto)
        except SyntaxError:
            continue
        dotted = _dotted(f)
        alias = {dotted, f.stem} if f.parent.name == "motor" else {dotted}
        funciones, clases = [], []
        for n in arbol.body:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and not n.name.startswith("__"):
                funciones.append((n.name, n.lineno, _primera_linea(ast.get_docstring(n)),
                                  not n.name.startswith("_")))
            elif isinstance(n, ast.ClassDef):
                metodos = [m.name for m in n.body
                           if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef))
                           and not m.name.startswith("_")]
                clases.append((n.name, n.lineno, _primera_linea(ast.get_docstring(n)), metodos))
        usuarios = sorted(k for k, v in imports_por_archivo.items()
                          if k != _rel(f) and not k.startswith("tests/") and v & alias)
        cubren = sorted(k for k, v in imports_por_archivo.items()
                        if k.startswith("tests/") and v & alias)
        fichas.append({
            "ruta": _rel(f), "lineas": len(texto.splitlines()),
            "proposito": proposito(ast.get_docstring(arbol) or "", f),
            "funciones": funciones, "clases": clases,
            "usado_por": usuarios, "tests": cubren,
            "comunidades": comunidades.get(_rel(f), []),
        })
    return fichas


def comunidades_por_archivo() -> dict[str, list[str]]:
    g = RAIZ / "graphify-out" / "graph.json"
    if not g.is_file():
        return {}
    datos = json.loads(g.read_text(encoding="utf-8"))
    c: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    for n in datos.get("nodes", []):
        sf = (n.get("source_file") or "").replace("\\", "/")
        if sf and n.get("community_name"):
            c[sf][n["community_name"]] += 1
    return {k: [nom for nom, _ in v.most_common(4)] for k, v in c.items()}


def comunidades_del_grafo() -> list[dict]:
    g = RAIZ / "graphify-out" / "graph.json"
    if not g.is_file():
        return []
    datos = json.loads(g.read_text(encoding="utf-8"))
    por_c: dict = collections.defaultdict(lambda: {"nombre": "", "nodos": 0,
                                                   "archivos": collections.Counter()})
    for n in datos.get("nodes", []):
        cid = n.get("community")
        if cid is None:
            continue
        e = por_c[cid]
        e["nombre"] = n.get("community_name") or e["nombre"]
        e["nodos"] += 1
        sf = (n.get("source_file") or "").replace("\\", "/")
        if sf:
            e["archivos"][sf] += 1
    filas = []
    for cid, e in sorted(por_c.items(), key=lambda kv: -kv[1]["nodos"]):
        vivos = [a for a, _ in e["archivos"].most_common(6)
                 if not a.startswith(("archivo/",)) and "codigo_muerto" not in a]
        filas.append({"id": cid, "nombre": e["nombre"], "nodos": e["nodos"],
                      "archivos": vivos[:3], "archivado": not vivos})
    return filas


def nodos_centrales(n: int = 25) -> list[tuple[str, str, int]]:
    g = RAIZ / "graphify-out" / "graph.json"
    if not g.is_file():
        return []
    datos = json.loads(g.read_text(encoding="utf-8"))
    grado = collections.Counter()
    for l in datos.get("links", []):
        grado[l.get("source")] += 1; grado[l.get("target")] += 1
    info = {nd["id"]: nd for nd in datos.get("nodes", [])}
    salida = []
    for nid, gr in grado.most_common(400):
        nd = info.get(nid) or {}
        sf = (nd.get("source_file") or "")
        if not sf or sf.startswith("archivo/") or "codigo_muerto" in sf or nd.get("label", "").endswith(".py"):
            continue
        salida.append((nd.get("label", nid), sf, gr))
        if len(salida) == n:
            break
    return salida


def endpoints() -> list[dict]:
    """Rutas reales de la app FastAPI (importarla no arranca el servidor)."""
    from web.app import app

    def planas(rutas, prefijo=""):
        """FastAPI reciente anida cada `include_router` en un `_IncludedRouter` con el
        router original dentro: se recorre recursivamente."""
        for r in rutas:
            orig = getattr(r, "original_router", None)
            if orig is not None:
                yield from planas(orig.routes, prefijo)
                continue
            yield r

    filas = []
    for r in planas(app.routes):
        ep = getattr(r, "endpoint", None)
        if ep is None or not getattr(r, "path", "").startswith(("/api", "/ws", "/")):
            continue
        metodos = sorted(getattr(r, "methods", None) or (["WS"] if "websocket" in type(r).__name__.lower() else []))
        mod = getattr(ep, "__module__", "")
        if not mod.startswith("web"):
            continue
        filas.append({"metodos": ",".join(m for m in metodos if m != "HEAD") or "WS",
                      "ruta": r.path, "funcion": ep.__name__,
                      "archivo": mod.replace(".", "/") + ".py",
                      "doc": _primera_linea(ep.__doc__)})
    return sorted(filas, key=lambda f: (f["archivo"], f["ruta"]))


def catalogo_tests() -> list[dict]:
    filas = []
    for f in sorted((RAIZ / "tests").glob("test_*.py")):
        texto = f.read_text(encoding="utf-8", errors="ignore")
        try:
            arbol = ast.parse(texto)
        except SyntaxError:
            continue
        nombres = []
        for n in ast.walk(arbol):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith("test_"):
                nombres.append(n.name)
        filas.append({"archivo": _rel(f), "proposito": proposito(ast.get_docstring(arbol) or "", f),
                      "n": len(nombres), "nombres": nombres})
    return filas


_RE_ENV = re.compile(r"""os\.(?:getenv|environ\.get)\(\s*["']([A-Z][A-Z0-9_]+)["']|os\.environ\[\s*["']([A-Z][A-Z0-9_]+)["']\s*\]""")


def variables_entorno() -> list[dict]:
    usos: dict[str, set[str]] = collections.defaultdict(set)
    for f in archivos_codigo():
        for m in _RE_ENV.finditer(f.read_text(encoding="utf-8", errors="ignore")):
            usos[m.group(1) or m.group(2)].add(_rel(f))
    desc: dict[str, str] = {}
    ej = RAIZ / ".env.example"
    if ej.is_file():
        comentario: list[str] = []
        for linea in ej.read_text(encoding="utf-8", errors="ignore").splitlines():
            l = linea.strip()
            m = re.match(r"^#?\s*([A-Z][A-Z0-9_]+)\s*=", l)
            if m:
                var = m.group(1)
                coment_linea = l.split("#", 2)[-1].strip() if l.count("#") >= (2 if l.startswith("#") else 1) else ""
                desc.setdefault(var, coment_linea or " ".join(comentario[-2:]))
                comentario = []
            elif l.startswith("#"):
                t = l.lstrip("#").strip()
                if t and not set(t) <= set("─═-"):
                    comentario.append(t)
            else:
                comentario = []
    return [{"var": v, "archivos": sorted(a), "desc": desc.get(v, "")}
            for v, a in sorted(usos.items())]


# ══════════════════════════════════════════════════════════════════════
#  Markdown → Word (subconjunto: títulos, párrafos, listas, tablas,
#  bloques de código, citas, negrita y código en línea)
# ══════════════════════════════════════════════════════════════════════

_RE_INLINE = re.compile(r"(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\))")


def _inline(p, texto: str, size: float = 10.5, color=None, bold_all: bool = False):
    for trozo in _RE_INLINE.split(texto):
        if not trozo:
            continue
        if trozo.startswith("**") and trozo.endswith("**"):
            PB._run(p, trozo[2:-2].replace("`", ""), size=size, bold=True, color=color)
        elif trozo.startswith("`") and trozo.endswith("`"):
            PB._run(p, trozo[1:-1], size=size - 1, mono=True, color=PB._AZUL2)
        elif trozo.startswith("["):
            m = re.match(r"\[([^\]]+)\]\(([^)]+)\)", trozo)
            PB._run(p, f"{m.group(1)} ({m.group(2)})", size=size, color=color, bold=bold_all)
        else:
            PB._run(p, trozo, size=size, color=color, bold=bold_all)


class Escritor:
    """Envoltorio del documento: títulos numerados con marcador, md, imágenes."""

    def __init__(self, doc):
        self.doc = doc
        self.marcas = PB.Marcadores()
        self.n_bm = 0

    def titulo(self, texto: str, nivel: int = 1):
        self.n_bm += 1
        PB.titulo(self.doc, self.marcas, texto, nivel, f"g{self.n_bm}")

    def p(self, texto: str, **kw):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_after = Pt(kw.pop("space_after", 6))
        p.paragraph_format.line_spacing = 1.25
        p.alignment = PB._ALIGN.get(kw.pop("align", "j"))
        _inline(p, texto, size=kw.pop("size", 10.5), color=kw.pop("color", None))
        return p

    def salto(self):
        PB._salto_pagina(self.doc)

    def imagen(self, ruta: Path, ancho_cm: float = 16.0, pie: str = ""):
        if PB._imagen(self.doc, ruta, ancho_cm) and pie:
            PB._caption(self.doc, pie)

    def tabla(self, headers, filas, anchos, aligns=None, font=8.5):
        t = PB._tabla(self.doc, headers, filas, anchos, aligns or ["l"] * len(headers), cap_font=font)
        PB.no_partir(t, entera=False)
        return t

    def markdown(self, md: str, nivel_base: int = 1):
        lineas = md.splitlines()
        i = 0
        if lineas and lineas[0].strip() == "---":            # frontmatter de skill
            fin = next((k for k in range(1, len(lineas)) if lineas[k].strip() == "---"), 0)
            meta = [l.split(":", 1) for l in lineas[1:fin] if ":" in l]
            if meta:
                self.tabla(["Campo", "Valor"], [[k.strip(), v.strip()] for k, v in meta],
                           [3.5, 12.9], font=9)
            i = fin + 1
        parrafo: list[str] = []

        def volcar():
            if parrafo:
                self.p(" ".join(s.strip() for s in parrafo)); parrafo.clear()

        while i < len(lineas):
            l = lineas[i]
            s = l.strip()
            if s.startswith("```"):
                volcar()
                bloque = []
                i += 1
                while i < len(lineas) and not lineas[i].strip().startswith("```"):
                    bloque.append(lineas[i]); i += 1
                PB._bloque_codigo(self.doc, "\n".join(bloque))
            elif re.match(r"^#{1,4}\s", s):
                volcar()
                n = len(s) - len(s.lstrip("#"))
                self.titulo(s.lstrip("#").strip(), min(nivel_base + n - 1, 3))
            elif s.startswith("|") and i + 1 < len(lineas) and re.match(r"^\|[\s:\-|]+\|$", lineas[i + 1].strip()):
                volcar()
                cab = [c.strip() for c in s.strip("|").split("|")]
                filas = []
                i += 2
                while i < len(lineas) and lineas[i].strip().startswith("|"):
                    filas.append([re.sub(r"\*\*|`", "", c.strip())
                                  for c in lineas[i].strip().strip("|").split("|")])
                    i += 1
                anchos = [16.4 / len(cab)] * len(cab)
                if len(cab) == 2:
                    anchos = [5.5, 10.9]
                elif len(cab) == 3:
                    anchos = [4.5, 7.0, 4.9]
                self.tabla(cab, [f + [""] * (len(cab) - len(f)) for f in filas], anchos)
                continue
            elif re.match(r"^([-*]|\d+\.)\s", s):
                volcar()
                ordenada = bool(re.match(r"^\d+\.", s))
                sangria = (len(l) - len(l.lstrip())) // 2
                texto = re.sub(r"^([-*]|\d+\.)\s+", "", s)
                # Continuación del ítem: línea sangrada (≥2 espacios) que no abre otro ítem.
                while i + 1 < len(lineas) and lineas[i + 1].startswith("  ") and lineas[i + 1].strip() \
                        and not re.match(r"^\s*([-*]|\d+\.)\s", lineas[i + 1]) \
                        and not lineas[i + 1].strip().startswith(("```", "|")):
                    i += 1; texto += " " + lineas[i].strip()
                estilo = ("List Number" if ordenada else "List Bullet") + (" 2" if sangria else "")
                try:
                    p = self.doc.add_paragraph(style=estilo)
                except KeyError:
                    p = self.doc.add_paragraph(style="List Bullet")
                p.paragraph_format.space_after = Pt(2)
                _inline(p, texto, size=10)
            elif s.startswith(">"):
                volcar()
                texto = s.lstrip("> ").strip()
                while i + 1 < len(lineas) and lineas[i + 1].strip().startswith(">"):
                    i += 1; texto += " " + lineas[i].strip().lstrip("> ").strip()
                PB.cita(self.doc, "", re.sub(r"\*\*|`", "", texto), sangria=0.3)
            elif not s or set(s) <= set("-—"):
                volcar()
            else:
                parrafo.append(s)
            i += 1
        volcar()


# ══════════════════════════════════════════════════════════════════════
#  Secciones del documento
# ══════════════════════════════════════════════════════════════════════

def _toc(doc):
    p = doc.add_paragraph()
    r = p.add_run()
    for tipo, texto in (("begin", None), (None, 'TOC \\o "1-2" \\h \\z \\u'), ("separate", None)):
        if tipo:
            el = OxmlElement("w:fldChar"); el.set(qn("w:fldCharType"), tipo); r._r.append(el)
        else:
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = texto
            r._r.append(it)
    t = OxmlElement("w:t"); t.text = "Índice: ábrelo en Word para actualizarlo (se actualiza solo)."
    r._r.append(t)
    el = OxmlElement("w:fldChar"); el.set(qn("w:fldCharType"), "end"); r._r.append(el)
    upd = OxmlElement("w:updateFields"); upd.set(qn("w:val"), "true")
    doc.settings.element.append(upd)


def _portada(doc, n_modulos: int, n_endpoints: int, n_tests: int):
    for txt in ("Gerencia de Administración de Riesgo de Modelo",
                "Gerencia de Validación Interna de Riesgo Financiero", "Banco de Crédito"):
        PB._p(doc, txt, size=12, bold=True, color=PB._AZUL, align="c", space_after=2)
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(36); p.paragraph_format.space_after = Pt(30)
    buf = PB._logo(None)
    if buf is not None:
        p.add_run().add_picture(buf, width=Cm(5.5))
    PB._p(doc, "VIRF — Guía técnica para el agente corporativo", size=24, bold=True,
          color=PB._AZUL, align="c", space_after=6)
    PB._p(doc, "Qué hace cada parte, cómo se usa, qué archivo tocar si algo falla y cómo pedir el "
               "cambio con un límite de 20 archivos de entrada y 5 de salida.", size=12,
          color=PB._AZUL2, align="c", space_after=14)
    PB._linea_horizontal(doc, PB._SELLO)
    PB._p(doc, f"Generada el {PB.fecha_larga(datetime.now().strftime('%Y-%m-%d'))} desde el código: "
               f"{n_modulos} módulos, {n_endpoints} endpoints y {n_tests} archivos de test.",
          size=10, italic=True, color=PB._GRIS, align="c")
    PB._salto_pagina(doc)


def _seccion_interfaz(e: Escritor):
    e.titulo("Parte 3 · Recorrido por la interfaz", 1)
    e.p("Cada pantalla de la web con su propósito, los endpoints que usa, los archivos que la "
        "implementan y la skill que aplica si falla. Las capturas son de la versión actual "
        "(escritorio a 1183 px y móvil a 375 px).")
    capturas = DIR_GUIA / "capturas"
    for k, (nombre, titulo, que, eps, archivos, skill) in enumerate(PANTALLAS):
        ruta = next(iter(sorted(capturas.glob(f"{nombre}.*"))), None)
        if k:
            e.salto()
        e.titulo(titulo, 2)
        if ruta:
            ancho = 7.5 if "movil" in nombre else 16.0
            e.imagen(ruta, ancho, f"Captura: {titulo}")
        PB.campo(e.doc, "Para qué sirve", que)
        PB.campo(e.doc, "Endpoints", eps)
        PB.campo(e.doc, "Archivos", archivos)
        PB.campo(e.doc, "Si falla", f"skill {skill} (ver Parte 6)", seguir=False)


def _seccion_informes(e: Escritor):
    e.titulo("Parte 5 · Los informes Word por dentro", 1)
    e.p("Los tres informes (Solo Informe, «Generar informe» de la web y el entregable del pipeline) "
        "usan la plantilla común `modulos/plantilla_bcp.py`. Estas son páginas reales de los "
        "ejemplos de `ejemplos/` (generados sin IA).")
    import pypdfium2 as pdfium
    tmp = Path(tempfile.mkdtemp(prefix="guia_virf_"))
    muestras = [
        ("Ejemplo_Informe_Resultados_LaR.pdf", "Solo Informe", ["Informe de Resultados", "Ficha del documento",
                                                                 "VII. Barrido de Controles"]),
        ("Ejemplo_Informe_Pipeline_LaR.pdf", "Entregable del pipeline", ["IV.4 Conclusión", "Anexo A.",
                                                                         "Anexo C."]),
        ("Ejemplo_Informe_Web_LaR_real_con_capturas.pdf", "«Generar informe» con capturas (corrida real)",
         ["Portada del documento revisado", "Sustento A", "Sustento B"]),
    ]
    primero = True
    for archivo, titulo, buscar in muestras:
        pdf = RAIZ / "ejemplos" / archivo
        if not pdf.is_file():
            continue
        if not primero:
            e.salto()
        primero = False
        e.titulo(titulo, 2)
        d = pdfium.PdfDocument(str(pdf))
        try:
            vistos = set()
            for clave in buscar:
                idx = next((i for i in range(len(d)) if i not in vistos
                            and clave in d[i].get_textpage().get_text_range()), None)
                if idx is None:
                    continue
                vistos.add(idx)
                png = tmp / f"{pdf.stem}_{idx}.png"
                d[idx].render(scale=1.3).to_pil().save(png)
                e.imagen(png, 11.5, f"{archivo} · página {idx + 1} («{clave}»)")
        finally:
            d.close()


def _ficha_modulo(e: Escritor, f: dict):
    e.titulo(f["ruta"], 2)
    PB.campo(e.doc, "Propósito", f["proposito"] or "(sin docstring de módulo)")
    PB.campo(e.doc, "Tamaño", f"{f['lineas']} líneas")
    if f["comunidades"]:
        PB.campo(e.doc, "Comunidades del grafo", " · ".join(f["comunidades"]))
    PB.campo(e.doc, "Lo usan", ", ".join(f["usado_por"][:12]) + (" …" if len(f["usado_por"]) > 12 else "")
             if f["usado_por"] else "nadie lo importa directamente (punto de entrada, script o carga dinámica)")
    PB.campo(e.doc, "Tests que lo importan", ", ".join(Path(t).name for t in f["tests"])
             if f["tests"] else "ninguno lo importa directamente (puede cubrirse vía otro módulo)",
             seguir=bool(f["funciones"] or f["clases"]))
    filas = []
    for nombre, linea, doc, publica in f["funciones"]:
        filas.append([f"{nombre}()", str(linea), "pública" if publica else "interna", doc[:150]])
    for nombre, linea, doc, metodos in f["clases"]:
        extra = f" Métodos: {', '.join(metodos[:8])}" if metodos else ""
        filas.append([f"class {nombre}", str(linea), "clase", (doc[:120] + extra)[:180]])
    if filas:
        e.tabla(["Nombre", "Línea", "Tipo", "Qué hace"], filas[:60], [4.6, 1.3, 1.6, 8.9],
                ["l", "c", "c", "l"], font=8)
        if len(filas) > 60:
            e.p(f"(+{len(filas) - 60} elementos más; ver el archivo)", size=8.5, color=PB._GRIS)


def _seccion_modulos(e: Escritor, fichas: list[dict]):
    e.salto()
    e.titulo("Parte 7 · Catálogo de módulos (generado del código)", 1)
    e.p("Una ficha por archivo de código vivo: propósito (del docstring), tamaño, comunidades del "
        "grafo, quién lo importa, qué tests lo cubren y sus funciones y clases con la línea donde "
        "empiezan. Sirve para decidir qué archivos subir al agente (ver S11).")
    grupos = collections.OrderedDict()
    for f in fichas:
        grupos.setdefault(f["ruta"].split("/")[0] if "/" in f["ruta"] else "raíz", []).append(f)
    for grupo, lista in grupos.items():
        e.salto()
        e.titulo(f"Carpeta {grupo}/" if grupo != "raíz" else "Archivos de la raíz", 1)
        e.tabla(["Archivo", "Líneas", "Propósito"],
                [[f["ruta"], f["lineas"], f["proposito"][:140]] for f in lista],
                [5.8, 1.4, 9.2], ["l", "c", "l"], font=8)
        for f in lista:
            e.salto()
            _ficha_modulo(e, f)


def _seccion_endpoints(e: Escritor, eps: list[dict]):
    e.salto()
    e.titulo("Parte 8 · Catálogo de endpoints de la web", 1)
    e.p("Leído de la aplicación FastAPI real (`web.app`). La pantalla llama a estas rutas desde "
        "`web/static/js/app.js`; para saber qué archivo tocar, busca la ruta aquí.")
    por_archivo = collections.OrderedDict()
    for f in eps:
        por_archivo.setdefault(f["archivo"], []).append(f)
    for archivo, lista in por_archivo.items():
        e.titulo(archivo, 2)
        e.tabla(["Método", "Ruta", "Función", "Descripción"],
                [[f["metodos"], f["ruta"], f["funcion"], f["doc"][:110]] for f in lista],
                [1.6, 5.4, 3.4, 6.0], ["c", "l", "l", "l"], font=8)


def _seccion_tests(e: Escritor, tests: list[dict]):
    e.salto()
    e.titulo("Parte 9 · Catálogo de tests", 1)
    e.p("Todos los tests corren sin coste (IA simulada) con "
        "`.venv\\Scripts\\python.exe -m pytest -q`. Tras un cambio, corre al menos el archivo del área.")
    e.tabla(["Archivo", "Tests", "Qué protege"],
            [[Path(t["archivo"]).name, t["n"], t["proposito"][:150]] for t in tests],
            [5.0, 1.3, 10.1], ["l", "c", "l"], font=8)
    for t in tests:
        if not t["nombres"]:
            continue
        e.titulo(Path(t["archivo"]).name, 3)      # nivel 3: fuera del índice
        e.p(t["proposito"] or "", size=9.5, color=PB._GRIS)
        nombres = t["nombres"]
        e.p(" · ".join(n.replace("test_", "") for n in nombres[:120]) + (" …" if len(nombres) > 120 else ""),
            size=8.5)


def _seccion_variables(e: Escritor, vars_: list[dict]):
    e.salto()
    e.titulo("Parte 10 · Variables de entorno", 1)
    e.p("Variables leídas por el código (en `.env`, que NO se sube al agente; la plantilla con "
        "comentarios está en `.env.example`). La descripción sale del comentario de `.env.example` "
        "cuando lo hay.")
    e.tabla(["Variable", "Se lee en", "Descripción"],
            [[v["var"], ", ".join(Path(a).name for a in v["archivos"][:4]), v["desc"][:160]] for v in vars_],
            [5.0, 4.4, 7.0], ["l", "l", "l"], font=8)


def _seccion_grafo(e: Escritor):
    e.salto()
    e.titulo("Parte 11 · El grafo del código", 1)
    e.p("Cómo usarlo está en la skill S11 (Parte 6). Aquí, la referencia generada del grafo "
        "actual: los nodos más conectados y todas las comunidades con sus archivos principales.")
    centrales = nodos_centrales()
    if centrales:
        e.titulo("Nodos centrales (cambiarlos afecta a mucho)", 2)
        e.tabla(["Nodo", "Archivo", "Conexiones"], [[a, b, c] for a, b, c in centrales],
                [5.5, 9.0, 1.9], ["l", "l", "c"], font=8)
    comunidades = comunidades_del_grafo()
    if comunidades:
        e.salto()
        e.titulo("Comunidades del grafo", 2)
        e.p("Cada comunidad agrupa funciones y clases muy conectadas entre sí. Las marcadas como "
            "archivadas corresponden a código retirado (`archivo/`, `codigo_muerto_*`).")
        e.tabla(["#", "Comunidad", "Nodos", "Archivos principales"],
                [[c["id"], c["nombre"] + (" (archivado)" if c["archivado"] else ""), c["nodos"],
                  ", ".join(c["archivos"])] for c in comunidades],
                [1.0, 6.2, 1.4, 7.8], ["c", "l", "c", "l"], font=7.5)


def _seccion_matriz_fallos(e: Escritor):
    """Tablas «Errores frecuentes» de todas las skills, juntas."""
    e.salto()
    e.titulo("Parte 12 · Matriz de fallos frecuentes", 1)
    e.p("Reúne las tablas «Errores frecuentes» de todas las skills: síntoma, causa y arreglo.")
    filas = []
    for md in sorted((DIR_GUIA / "skills").glob("S*.md")):
        texto = md.read_text(encoding="utf-8")
        bloque = texto.split("## Errores frecuentes", 1)
        if len(bloque) < 2:
            continue
        for l in bloque[1].splitlines()[2:]:
            if not l.strip().startswith("|"):
                if l.strip():
                    break
                continue
            celdas = [re.sub(r"\*\*|`", "", c.strip()) for c in l.strip().strip("|").split("|")]
            if len(celdas) >= 3 and not set(celdas[0]) <= set("-: "):
                filas.append([md.stem.split("_")[0], *celdas[:3]])
    e.tabla(["Skill", "Síntoma / error", "Causa", "Arreglo"], filas, [1.3, 5.0, 5.0, 5.1],
            ["c", "l", "l", "l"], font=8)


# ══════════════════════════════════════════════════════════════════════
#  API
# ══════════════════════════════════════════════════════════════════════

def construir(destino: Path) -> Path:
    fichas = analizar_modulos()
    eps = endpoints()
    tests = catalogo_tests()
    vars_ = variables_entorno()

    doc = Document()
    PB._estilo_base(doc)
    for s in doc.sections:
        s.top_margin = Cm(2.6); s.bottom_margin = Cm(2.3)
        s.left_margin = Cm(2.3); s.right_margin = Cm(2.3); s.header_distance = Cm(1.0)
    PB._encabezado_pie(doc, lambda: PB._logo(None), "Guía para el agente corporativo")
    _portada(doc, len(fichas), len(eps), len(tests))
    e = Escritor(doc)

    h = doc.add_paragraph(); PB._run(h, "Índice", size=16, bold=True, color=PB._AZUL)
    _toc(doc)
    e.salto()

    e.titulo("Parte 1 · Cómo usar esta guía y el paquete", 1)
    e.markdown((DIR_GUIA / "00_LEEME.md").read_text(encoding="utf-8"), nivel_base=2)
    e.salto()
    e.titulo("Parte 2 · Conocimiento VIRF", 1)
    e.markdown((DIR_GUIA / "CONOCIMIENTO_VIRF.md").read_text(encoding="utf-8"), nivel_base=2)
    e.salto()
    _seccion_interfaz(e)
    flujo = RAIZ / "docs" / "FLUJO_AGENTE.md"
    if flujo.is_file():
        e.salto()
        e.titulo("Parte 4 · Flujo de una validación, extremo a extremo", 1)
        e.markdown(flujo.read_text(encoding="utf-8"), nivel_base=2)
    e.salto()
    _seccion_informes(e)
    e.salto()
    e.titulo("Parte 6 · Skills de cambio", 1)
    e.p("Una skill por tipo de cambio. Cada una dice qué subir (máx. 20 archivos), qué puede "
        "devolver el agente (máx. 5), los pasos, las reglas que no se pueden romper, cómo verificar "
        "y los errores frecuentes.")
    for k, md in enumerate(sorted((DIR_GUIA / "skills").glob("S*.md"))):
        if k:
            e.salto()
        e.markdown(md.read_text(encoding="utf-8"), nivel_base=2)
    _seccion_modulos(e, fichas)
    _seccion_endpoints(e, eps)
    _seccion_tests(e, tests)
    _seccion_variables(e, vars_)
    _seccion_grafo(e)
    _seccion_matriz_fallos(e)

    destino.parent.mkdir(parents=True, exist_ok=True)
    doc.save(destino)
    return destino


def a_pdf(docx: Path) -> Path:
    """Convierte con Microsoft Word (COM vía PowerShell) actualizando índice y campos."""
    pdf = docx.with_suffix(".pdf")
    ps = (
        "$w = New-Object -ComObject Word.Application; $w.Visible = $false; $w.DisplayAlerts = 0; "
        f"try {{ $d = $w.Documents.Open('{docx}', $false, $true); [void]$d.Fields.Update(); "
        "foreach ($t in $d.TablesOfContents) { [void]$t.Update() }; "
        f"$d.ExportAsFixedFormat('{pdf}', 17); $n = $d.ComputeStatistics(2); $d.Close($false); "
        "Write-Output $n } finally { $w.Quit() }"
    )
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True)
    if r.returncode != 0 or not pdf.is_file():
        raise RuntimeError(f"No se pudo convertir a PDF con Word: {r.stderr.strip()[:400]}")
    print(f"  PDF: {pdf} ({r.stdout.strip()} páginas)")
    return pdf


def main(argv: Optional[Iterable[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--salida", default=str(DIR_GUIA), help="Carpeta de salida")
    ap.add_argument("--pdf", action="store_true", help="Además, exportar a PDF con Microsoft Word")
    args = ap.parse_args(list(argv) if argv is not None else None)
    docx = construir(Path(args.salida) / f"{NOMBRE}.docx")
    print(f"  DOCX: {docx}")
    if args.pdf:
        a_pdf(docx)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
