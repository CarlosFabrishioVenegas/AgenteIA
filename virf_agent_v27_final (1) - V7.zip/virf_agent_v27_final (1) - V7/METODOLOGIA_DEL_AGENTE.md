# Metodología del Agente VIRF

**Qué es este documento.** Una explicación completa de *cómo piensa* el agente: qué hace con
un documento desde que lo lee hasta que emite un dictamen, por qué cada decisión está donde
está, y qué garantías ofrece —y cuáles no— a quien firma el informe.

Está escrito para tres lectores a la vez:

- **el validador** que va a usar el agente y necesita saber qué puede defender ante el regulador;
- **el auditor interno** que revisa el informe y necesita saber en qué confiar;
- **el ingeniero** que va a modificar el código y necesita saber qué invariantes no puede romper.

Cada afirmación remite al fichero y función que la implementa. Versión del agente: **27.1**.

---

## Índice

1. [Qué problema resuelve](#1-qué-problema-resuelve)
2. [El marco conceptual: 6 ámbitos y sus pesos](#2-el-marco-conceptual-6-ámbitos-y-sus-pesos)
3. [Anatomía de una corrida](#3-anatomía-de-una-corrida)
4. [Fase A — Lectura de evidencia](#4-fase-a--lectura-de-evidencia)
5. [Fase B — Chunking: cómo caben 300 páginas en un prompt](#5-fase-b--chunking-cómo-caben-300-páginas-en-un-prompt)
6. [Fase C — Evaluación actividad por actividad](#6-fase-c--evaluación-actividad-por-actividad)
7. [Fase D — Controles de calidad de datos](#7-fase-d--controles-de-calidad-de-datos)
8. [Fase E — Agregación y dictamen](#8-fase-e--agregación-y-dictamen)
9. [Fase F — Entregables y trazabilidad](#9-fase-f--entregables-y-trazabilidad)
10. [El bucle de aprendizaje](#10-el-bucle-de-aprendizaje)
11. [Los seis invariantes que definen al agente](#11-los-seis-invariantes-que-definen-al-agente)
12. [Modos de operación](#12-modos-de-operación)
13. [Qué NO hace el agente](#13-qué-no-hace-el-agente)
14. [Glosario](#14-glosario)

---

## 1. Qué problema resuelve

La validación independiente de modelos es un ejercicio documental antes que matemático. El
validador recibe un manual metodológico de 300 páginas, unos scripts, unos informes de
seguimiento y una base de datos, y tiene que responder a preguntas del tipo *«¿está
documentado el proceso de backtesting?»*, *«¿se justificó la elección de la distribución?»*,
*«¿hay evidencia de que el modelo se usa realmente en la gestión?»*.

El cuello de botella no es la dificultad conceptual: es el **volumen y la trazabilidad**.
Leer 300 páginas buscando 21 evidencias concretas, dejar constancia de dónde estaba cada
una, y hacerlo de forma que otra persona pueda reproducir el juicio.

El agente automatiza esa lectura estructurada. **No sustituye el criterio del validador**:
produce un borrador trazable que el validador corrige, y aprende de esas correcciones
(§10).

### La consecuencia de diseño más importante

Un validador que se inventa una evidencia produce un daño mucho mayor que uno que dice «no
lo encontré». Por eso el agente está construido alrededor de una asimetría deliberada:

> **Prefiere siempre declarar una ausencia antes que rellenar un hueco.**

Esta idea aparece una y otra vez en las páginas siguientes. Es el eje del diseño.

---

## 2. El marco conceptual: 6 ámbitos y sus pesos

Toda validación se organiza en seis ámbitos. No son una taxonomía inventada: cada peso está
anclado a un estándar regulatorio concreto.

| Ámbito | Peso | Anclaje normativo |
|---|---:|---|
| **Metodología** | 0.30 | SR 11-7 §IV — *conceptual soundness* |
| **Calidad de datos** | 0.20 | BCBS 239, principios 3–5 |
| **Documentación** | 0.15 | EBA/GL/2023/01 §6.3 |
| **Implementación** | 0.15 | SR 11-7 §IV — *outcome analysis* |
| **Gobierno** | 0.12 | EBA/GL/2023/01 §5 — inventario y *tiering* |
| **Uso e integración a la gestión** | 0.08 | SR 11-7 §IV — *ongoing monitoring* |
| | **1.00** | |

📁 `config/dominio.py` → `AMBITO_PESOS`, `AMBITO_PESOS_REFS`

**Por qué importa el anclaje.** Un peso arbitrario es indefendible ante un regulador que
pregunta «¿por qué Metodología vale el triple que Uso?». La respuesta está en el código:
porque SR 11-7 sitúa la solidez conceptual como el componente central de la validación.
`validate_project.py` comprueba que los pesos sumen 1.00 y que coincidan con el Excel del
estándar; si alguien los cambia sin actualizar la justificación, el validador lo detecta.

### De dónde sale la evidencia de cada ámbito

Cada ámbito se alimenta de carpetas concretas de `inputs/`:

| Ámbito | Carpetas |
|---|---|
| Documentación | `doc_modelamiento`, `doc_seguimiento`, `papers` |
| Calidad de datos | `calidad_datos`, `doc_modelamiento` |
| Metodología | `doc_modelamiento`, `papers`, `doc_seguimiento` |
| Gobierno | `doc_modelamiento`, `implementacion` |
| Implementación | `implementacion`, `doc_modelamiento` |
| Uso e integración | `usos`, `implementacion` |

📁 `motor/Mx_00_CargaRutas.py` → `AMBITO_A_INPUTS`

Un mismo documento puede alimentar varios ámbitos. El manual metodológico, por ejemplo,
aparece en cinco de los seis: es normal que la misma fuente responda preguntas distintas.

### Tiers

El estándar VIRF define cuatro niveles de exigencia (I a IV) según la criticidad del modelo.
Un Tier I exige más actividades que un Tier IV. El flag `--tier` selecciona la columna
correspondiente del Excel de estándares.

📁 `motor/Mx_01_LecturaEvidencias.py` → `leer_estandares_virf()`

> ⚠️ **Un tier inexistente se rechaza antes de gastar.** Si se pasa `--tier 9`, el agente
> aborta. Antes no lo hacía: buscaba una columna `TIER_9` que no existe, **desactivaba el
> filtro** y evaluaba las 21 actividades en lugar de las 11 del tier, facturando la corrida
> completa y rotulando el informe «Tier: 9».

---

## 3. Anatomía de una corrida

```
python agente.py --titulo "Modelo LaR Cartera Corporativa v3" --tier 1 --prdc
```

```
┌─ A. LECTURA ──────────────────────────────────────────────────────────┐
│  PDF/DOCX/XLSX/PY/MD → texto plano                                    │
│  Caché por SHA-256 del fichero                                        │
│  Marca de lectura fallida en los 11 lectores                          │
└───────────────────────────────┬───────────────────────────────────────┘
                                ▼
┌─ B. CHUNKING ─────────────────────────────────────────────────────────┐
│  ¿Cabe en el prompt? → pasa tal cual                                  │
│  ¿No cabe?           → segmenta, resume cada segmento, consolida      │
│  Declara SIEMPRE la cobertura real alcanzada                          │
└───────────────────────────────┬───────────────────────────────────────┘
                                ▼
┌─ C. EVALUACIÓN ───────────────────────────────────────────────────────┐
│  Para cada ámbito, para cada actividad requerida del tier:            │
│    prompt = actividad + evidencia + memoria + RAG + feedback          │
│    → JSON validado contra contrato                                    │
│    → puntaje 1-5, evidencia citada, hallazgos, recomendación          │
└───────────────────────────────┬───────────────────────────────────────┘
                                ▼
┌─ D. CONTROLES DE DATOS ───────────────────────────────────────────────┐
│  ControlesData.xlsx → motores ejecutables sobre los datasets reales   │
│  Se integran en el ámbito «Calidad de datos»                          │
└───────────────────────────────┬───────────────────────────────────────┘
                                ▼
┌─ E. AGREGACIÓN ───────────────────────────────────────────────────────┐
│  Promedio por ámbito → score global ponderado → semáforo              │
│  Separando SIEMPRE «sin evidencia» de «fallo técnico»                 │
└───────────────────────────────┬───────────────────────────────────────┘
                                ▼
┌─ F. ENTREGABLES ──────────────────────────────────────────────────────┐
│  JSON auditable (con huella reproducible) + informe Word              │
└───────────────────────────────────────────────────────────────────────┘
                                ▼
                     G. BUCLE DE FEEDBACK (pre-producción)
```

📁 `agente.py` → `main()`, pasos numerados 1 a 10

---

## 4. Fase A — Lectura de evidencia

### Formatos soportados

**16 extensiones** (`LECTORES_EXT`):

| Grupo | Extensiones |
|---|---|
| Documentos | `.pdf` (con OCR de respaldo) · `.docx` `.doc` · `.pptx` `.ppt` |
| Hojas de cálculo | `.xlsx` `.xls` `.xlsm` |
| **Código** | `.py` · `.ipynb` · `.sql` · `.R` |
| Texto plano | `.md` `.txt` `.csv` `.json` |

Las cuatro marcadas como **código** (`EXTENSIONES_CODIGO`) son además las que
alimentan la revisión módulo a módulo contra el manual (`--revisar-codigo`), y
se leen **íntegras**: el tope `MAX_CHARS_CODIGO` solo se aplica si el chunking
está desactivado.

> ⚠️ Lo que **no** está en esa lista se omite **sin aviso**: `leer_archivo()`
> devuelve `None` y el fichero desaparece de la evidencia. Es el defecto que
> tuvieron `.ipynb` y `.sql` hasta el 30/07/2026 — el prompt del ámbito
> Implementación pedía contrastar contra «los scripts (.py, .ipynb)» mientras
> el lector nunca entregaba los notebooks. Si tu modelo usa `.scala`, `.yaml`,
> `.do` o `.sas`, hay que registrarlos antes de validarlo.

📁 `motor/Mx_01_LecturaEvidencias.py` → `LECTORES_EXT`, `EXTENSIONES_CODIGO`

### La cadena de respaldo del PDF

Un PDF puede ser digital o escaneado. El agente intenta **dos** vías, ambas digitales:

1. **pdfminer** — PDFs digitales, extracción fiel.
2. **PyPDF2** — respaldo digital.

**No hay OCR.** Había un tercer intento con `pytesseract` + `pdf2image`, retirado el
30/07/2026 por política: la entidad no admite ejecutar modelos ajenos a Azure OpenAI, y
Tesseract es un motor de reconocimiento con sus propios modelos de lenguaje.

Si las dos vías digitales devuelven vacío —el caso de un acta firmada y digitalizada—, el
documento **no se puede leer**, y eso se declara: marca de lectura fallida, `cobertura 0 %`,
`lectura_fallida=True`. Es un **fallo técnico del agente**, no una falta del validado
(invariante 3). El mensaje dice al operador qué hacer: aportar el documento en digital, o
convertirlo con la herramienta de OCR aprobada por la entidad **antes** de dejarlo en
`inputs/`.

### La marca de lectura fallida

Éste es un punto donde la asimetría de §1 se hace explícita en el código.

Un lector que falla devuelve un mensaje de error. El problema es que ese mensaje **es texto**,
y sin más cuidado entra al pipeline como si fuera evidencia:

```
Contenido del documento: "[Error OCR en manual.pdf: unable to get page count]"
Cobertura: 100 %          ← el evaluador cree tener el documento entero
```

Un PDF corrupto se convertía así en «evidencia con cobertura completa». Los lectores
prefijan sus errores con un centinela (`⛔LECTURA-FALLIDA⛔`) que `leer_archivo()`
detecta para poner la cobertura a 0 y marcar `lectura_fallida=True`.

📁 `motor/Mx_01_LecturaEvidencias.py` → `_MARCA_LECTURA_FALLIDA`

**Lección transferible:** cuando una función puede devolver *un resultado* o *una explicación
de por qué no hay resultado*, y ambos son del mismo tipo, el consumidor no puede
distinguirlos. Hace falta una marca fuera de banda.

### Recortes declarados

Un Excel de 10.000 filas no cabe entero. El lector toma las primeras
`MAX_FILAS_EXCEL` (**200** por defecto) y **lo declara en el propio texto**:

```
[⚠️ RECORTADO: se muestran las primeras 200 de 10.000 filas (2%).
 Las conclusiones sobre el conjunto completo NO son verificables con esta
 muestra. Subir MAX_FILAS_EXCEL para incluir más.]
```

El evaluador lee ese aviso y sabe que no puede afirmar nada sobre el total. Antes el recorte
era silencioso y el documento salía con `truncado=False`.

### El caché

Las lecturas se cachean indexadas por **SHA-256 del fichero**. Si el documento cambia, cambia
la clave y se relee: la frescura está garantizada por construcción, no por una política de
invalidación.

📁 `modulos/document_cache.py`

> ⚠️ **El caché no recorta lo que el chunker debe cubrir.** Con el chunking activo, el caché
> guarda el texto **íntegro** (`max_chars=None`). Durante un tiempo pidió 15.000 caracteres
> mientras declaraba el tamaño completo del documento, y la misma corrida daba cobertura
> 100 % sin caché y **1,2 % con caché**. Todo el trabajo de chunking era inútil porque el
> documento nunca le llegaba entero.

---

## 5. Fase B — Chunking: cómo caben 300 páginas en un prompt

### El problema

Un manual metodológico real ronda **1.300.000 caracteres**. El presupuesto de contexto por
prompt es de **15.000**. Hay que reducir ~87 veces sin perder lo que importa.

La solución ingenua —cortar los primeros 15.000 caracteres— produce un informe basado en el
índice y la introducción. La solución del agente es **resumir por segmentos preservando
cobertura**.

### Los tres modos

**1. Directo.** Si el documento cabe (`< CHUNK_THRESHOLD`, 12.000 chars), pasa tal cual.
Cobertura 100 %, coste 0.

**2. Adaptativo.** Si no cabe, se segmenta. Con segmentos de 12.000 chars, un manual de 1,3 M
necesitaría 117 segmentos = 117 llamadas al modelo. El tope es 40. En vez de **descartar** los
77 restantes —que es lo que haría un truncado—, el agente **agranda el segmento**:

```
📐 CHUNKING ADAPTATIVO: 'Manual_Metodologico_LaR_completo.pdf' (1.302.266 chars)
   117 segmentos de 12.000 excedían el límite (40).
   Ajustado a 40 segmentos de 33.357 chars → cobertura 100 %.
```

40 × 33.357 = 1.334.280 ≥ 1.302.266. **Cobertura completa con el presupuesto disponible.**

**3. Jerárquico.** Los 40 resúmenes suman más de lo que cabe en el prompt (143.483 chars
frente a un presupuesto de 9.000). Se consolidan por niveles —resúmenes de resúmenes— hasta
entrar, **sin descartar ninguno**:

```
🏗️ CONSOLIDACIÓN JERÁRQUICA: 40 resúmenes suman 143.483 chars (presupuesto 9.000).
   Nivel 1 · bloque 1/3 (14 resúmenes)...
   ✅ Nivel 1: 40 → 3 bloques (6.069 chars)
   ✅ 40 segmentos [jerárquico] — cobertura 100,0 %
```

📁 `modulos/chunker.py` → `ChunkerService`

### Parámetros y su efecto en el coste

| Parámetro | Valor | Efecto |
|---|---:|---|
| `VIRF_CHUNK_SIZE` | 12.000 | Tamaño inicial del segmento |
| `VIRF_CHUNK_THRESHOLD` | 12.000 | A partir de aquí se segmenta |
| `VIRF_MAX_CHUNKS` | 40 | Tope de llamadas por documento |
| `VIRF_CHUNK_SIZE_MAX` | 40.000 | Tope del segmento adaptativo |
| `VIRF_PRESUPUESTO_DOC` | 9.000 | Chars de resumen final por documento |
| `VIRF_MAX_NIVELES` | 3 | Niveles de consolidación jerárquica |

⚠️ **`VIRF_MAX_CHUNKS` no debe bajarse de 34.** Por debajo, el modo adaptativo no alcanza y
cae al jerárquico puro, que **cuesta más**: medido, 40 chunks → 1,14 USD frente a 30 chunks →
2,27 USD, con la misma cobertura. Reducir el tope para «ahorrar» duplica la factura.

### El caché de resúmenes

Resumir un manual de 305 páginas cuesta ~0,90 USD. Sin caché, se repetiría íntegro en cada
corrida aunque el documento no hubiera cambiado. La clave del caché combina el hash del texto
**con la configuración del chunker**: si cambia el documento *o* cambia cómo se segmenta, se
recalcula. Un resumen producido con otros parámetros no se reutiliza jamás.

### La cobertura se declara siempre

Todo documento procesado lleva un `cobertura_pct` real, que viaja al prompt como dato
numérico. El evaluador ve literalmente:

```
📄 [Documentación] 4/4 doc(s) en contexto — 9.454 chars — cobertura documental 100,0 %
```

Y si la cobertura es parcial, también:

```
⚠ 'Manual_Metodologico_LaR_completo.pdf': cobertura 1,2 % (directo, 1.302.266 chars)
```

**Nunca se afirma una cobertura que no se alcanzó.** Hubo tres cálculos de cobertura
distintos en el proyecto —media simple, métrica cruzada y máximo— y los tres inflaban la
cifra. Ninguno producía un error: sólo un número más halagador. Hoy se distinguen
explícitamente dos magnitudes que antes se confundían:

- **cobertura documental** — cuánto del fichero se llegó a leer;
- **cobertura de contexto** — cuánto del material disponible cupo en el prompt.

---

## 6. Fase C — Evaluación actividad por actividad

Ésta es la fase donde el agente emite juicio. Se ejecuta una llamada al modelo **por
actividad**, no por ámbito ni por documento: el grano fino es lo que permite citar evidencia
concreta y que un fallo aislado no contamine el resto.

📁 `modulos/motor_ia.py` → `evaluar_actividad()`, `evaluar_ambito_completo()`

### Qué entra en el prompt

| Bloque | Origen | Para qué |
|---|---|---|
| **Actividad** | Excel del estándar VIRF | Qué hay que verificar |
| **Evidencia** | Documentos del ámbito, ya chunkeados | Sobre qué se juzga |
| **Cobertura declarada** | Chunker (dato numérico) | Que el modelo sepa cuánto está viendo |
| **Memoria intra-ámbito** | Hallazgos de actividades previas del mismo ámbito | Coherencia interna |
| **Memoria inter-ámbito** | Hallazgos globales acumulados | Que Gobierno sepa lo visto en Metodología |
| **Contexto RAG** | Índice vectorial del dominio | Conocimiento experto de LaR/VaR/conductuales |
| **Feedback histórico** | Correcciones previas del validador | Calibración anti-sesgo |

### El contrato de salida

El modelo debe responder un JSON con estructura fija. Un `_validar_contrato()` lo comprueba
antes de aceptarlo. Campos principales:

```
puntaje              1-5 (o ausente si no hay evidencia)
evidencia_encontrada cita textual localizable en el documento
observacion          juicio del evaluador
recomendacion        acción concreta
concepto             qué exige la actividad
cobertura_contexto   0.0-1.0, fracción del contexto disponible usada
rag_dominio          dominio consultado (o "no_disponible")
rag_chunks           nº de fragmentos RAG inyectados
```

**Si el JSON no cumple el contrato, no se inventa un puntaje**: la actividad se marca como
fallo técnico y queda fuera del score. Antes, un fallback rellenaba los huecos con valores
por defecto y el informe presentaba como evaluación algo que nunca se evaluó.

### La escala

| Puntaje | Significado |
|---:|---|
| 5 | Cumple plenamente |
| 4 | Cumple con observaciones menores |
| 3 | Cumple parcialmente |
| 2 | Cumple parcialmente — observaciones críticas |
| 1 | No cumple |

📁 `config/dominio.py` → `ESCALA_PUNTAJE`

**La escala empieza en 1.** Esto no es un detalle cosmético: es lo que permite reservar el
**0 para la ausencia de evidencia** de forma inequívoca (§8).

### El RAG por dominio

El agente mantiene índices vectoriales separados por dominio financiero: `LaR`, `VaR`,
`conductuales` y `shared`. Ante la actividad *«¿se realizaron pruebas de Kupiec?»*, el
retriever del dominio aporta fragmentos de literatura técnica que ayudan al modelo a
reconocer si lo que ve en el manual es efectivamente un backtesting de Kupiec.

📁 `src/rag/` → `BaseRetriever.query_para_prompt()`

El dominio se infiere del título del modelo; lo que no encaje en los tres especializados cae
a `shared` (regulación transversal) y **funciona igual**, solo sin conocimiento
especializado.

#### Literatura de referencia, nunca la evidencia evaluada

El RAG lee de `inputs/rag/<dominio>/`, **no** de las carpetas de evidencia. La distinción es
constitutiva, no organizativa:

| | Va en | Se usa para |
|---|---|---|
| Evidencia del modelo | `inputs/` o `--raiz-evidencia` | Emitir el dictamen |
| Literatura de dominio | `inputs/rag/<dominio>/` | Reconocer conceptos técnicos |

Los indexadores leían de las carpetas de evidencia, y eso producía **razonamiento circular**:
ante «¿el manual documenta el backtesting?», el RAG recuperaba fragmentos *del propio manual*
y los inyectaba bajo el epígrafe «Conocimiento recuperado». El agente se daba la razón a sí
mismo con la fuente que estaba juzgando. Como además los cuatro dominios apuntaban a las
mismas carpetas, los tres índices especializados quedaban llenos del mismo contenido:
consultando el de VaR sobre backtesting FRTB, los tres primeros resultados eran del manual de
un modelo de liquidez con similitud 0.88.

Por eso el RAG **no sigue a `--raiz-evidencia`**: la literatura de dominio es compartida por
familia de modelos, no propia de uno.

#### Degradación acotada, y su riesgo

Si no hay índice, `query()` devuelve lista vacía y la evaluación continúa sin contexto RAG.
Es deliberado —el RAG es un refuerzo, no un requisito— pero tiene un riesgo que conviene
nombrar: **un índice ausente, mal ubicado o contaminado hace que el RAG *parezca* activo sin
aportar nada útil.** Han ocurrido las tres variantes:

- el indexador escribía fuera del proyecto por un `.parent` de más (ruta unificada en
  `config.VECTORDB_DIR`);
- indexaba sus propios mensajes de error como conocimiento experto, porque el lector de
  respaldo devolvía `"[No se pudo leer: X]"` como contenido;
- descartaba documentos enteros cuando dos fragmentos tenían texto idéntico, por colisión de
  identificadores derivados solo del texto.

Los tres están corregidos y guardados por tests. La lección operativa es que **la existencia
del índice no prueba que el RAG aporte**: eso se comprueba en el JSON de la corrida, en los
campos `rag_dominio` y `rag_chunks` de cada evaluación.

#### Estado actual y verificación

Corpus generado por `scripts/generar_corpus_rag.py` a partir de marcos regulatorios
públicos: `shared` 19 fragmentos (SR 11-7, BCBS 239, validación interna UE), `VaR` 14 (FRTB
BCBS 457, Kupiec/Christoffersen), `LaR` 11 (LCR BCBS 238, NSFR BCBS 295), `conductuales` 7
(IRRBB, NMD, prepago).

Son **resúmenes secundarios, no los textos oficiales**, y lo declaran en su portada, en el pie
de cada página y dentro de su texto indexable: si un fragmento llega al prompt, el modelo lee
la advertencia junto al contenido. Deben sustituirse por las fuentes oficiales antes de emitir
un dictamen que se presente a un supervisor.

Medido en la validación del modelo de ejemplo `VaR Mercado FRTB` (tier 1): **15 de 15
actividades recibieron 3 fragmentos** del dominio `VaR`, y la terminología del corpus apareció
en las observaciones — FRTB 18 veces, Christoffersen 16, Kupiec 15, Expected Shortfall 5,
zona verde 5, PLAT 3, NMRF 1. En la corrida previa con los índices vacíos, `rag_chunks` era 0
en todas.

### D3-FIX: no evaluar sobre el vacío

Si un ámbito no tiene ningún documento, **no se llama al modelo**. No tiene sentido preguntar
a un LLM si un manual documenta el backtesting cuando no hay manual: la respuesta sería una
alucinación educada.

La actividad se marca `sin_evidencia=True`, lo que en la fase de agregación se traduce en la
consecuencia que dicta la política de la entidad (§8).

---

## 7. Fase D — Controles de calidad de datos

Los ámbitos anteriores evalúan **documentos**. Este evalúa **datos**: ejecuta pruebas reales
sobre los datasets del modelo.

📁 `modulos/motores_datos.py`, `motor/Mx_04_MotorControlesData.py`

`inputs/calidad_datos/ControlesData.xlsx` describe cada control; si lleva `USA_MOTOR_DATA=1`
y un `TIPO_MOTOR`, el agente ejecuta la prueba correspondiente sobre el dataset y obtiene un
resultado **medido, no opinado**: unicidad de clave, nulos por columna, rangos, integridad
referencial, duplicados.

`python agente.py --listar-motores` muestra el catálogo disponible.

Los resultados se integran en el ámbito **Calidad de datos** y pesan en su score junto a las
actividades documentales. Por eso el resumen final declara el desglose:

```
• Actividades totales: 15 del estándar + 4 control(es) CDD integrado(s) = 19 evaluaciones
```

> Sin ese desglose, el informe llegó a decir «evaluadas OK: 19» sobre «totales: 15» — más
> evaluadas que existentes. El score era correcto; el contador no cuadraba, y un auditor que
> compara dos cifras contradictorias pierde la confianza en todo lo demás.

### De documento a notebook ejecutable

Un flujo complementario: `--controles-a-notebook` toma un documento que *describe* controles
de calidad y genera un notebook que los *ejecuta*, más un análisis de brechas:

```
✅ en ambos      : 2
📄 solo documento: 9  ← prometidos, NO ejecutados
⚙️ solo Excel    : 2  ← ejecutados, NO documentados
```

Esa tabla es en sí misma un hallazgo de validación: la distancia entre lo que la entidad dice
que controla y lo que efectivamente ejecuta.

---

## 8. Fase E — Agregación y dictamen

Aquí se decide qué nota sale en el informe. Es la parte con más matiz del agente.

### Las dos causas por las que puede no haber nota

Una actividad puede quedarse sin puntaje por dos razones **con responsables opuestos**, y
confundirlas produce dictámenes indefendibles:

| Causa | Responsable | Tratamiento |
|---|---|---|
| **Sin evidencia** — no se aportó documentación | El **validado** | **0.0**, falta crítica, penaliza con su peso íntegro |
| **Fallo técnico** — timeout, PDF ilegible, JSON roto | El **agente** | Excluido del score, se renormalizan los pesos, se reporta aparte |

📁 `modulos/motor_ia.py` → `calcular_score_ambito()`, `calcular_score_global()`

**Por qué la falta de evidencia puntúa 0.0.** Es política de la entidad: el validado tenía la
obligación de aportar documentación y no lo hizo. Eso *es* un hallazgo, y de los graves. Si
se excluyera del promedio —renormalizando los pesos—, no aportar documentación saldría
gratis. Medido sobre una corrida real: Gobierno (peso 0.12) sin evidencia daba **3.02**
excluido frente a **2.66** contando su 0.0.

**Por qué el fallo técnico no puntúa.** Si nuestra API da timeout y eso se convierte en un
0.0, el informe condena un modelo por un fallo nuestro. Es indefendible ante el regulador. El
bloque de integridad los cuenta aparte y recomienda re-ejecutar antes de dictaminar.

**Ante la duda, no se acusa.** Si una evaluación llega marcada con ambas causas, prevalece la
no imputable al validado.

### La propiedad que hace todo esto robusto

> La escala de puntuación es **1–5**. Por tanto un promedio de actividades realmente
> evaluadas **nunca puede dar 0.0**. Eso convierte el 0.0 en un valor inequívoco:
> **score 0.0 ⟺ sin evidencia**.

Gracias a esa propiedad el semáforo puede rotular la causa sin necesidad de recibir ningún
parámetro extra. Hay un test que fija la invariante por si algún día se cambia la escala.

### El semáforo

| Score | Etiqueta | Color |
|---|---|---|
| 4.5 – 5.0 | SATISFACTORIO | verde |
| 3.5 – 4.5 | ACEPTABLE | verde claro |
| 2.5 – 3.5 | CON OBSERVACIONES | ámbar |
| 1.5 – 2.5 | DEFICIENTE | naranja |
| 0.0 – 1.5 | CRÍTICO | rojo |
| **= 0.0** | **NO EVALUABLE — SIN EVIDENCIA** | **rojo** |
| **None** | **NO EVALUABLE — FALLO TÉCNICO** | **gris** |

Las dos últimas filas son la clave: **se nombra la causa, pero la falta de evidencia conserva
la severidad crítica**. No se disfraza de «pendiente» ni se confunde con un fallo de la
herramienta.

### El score de cumplimiento de controles

Para los controles de datos, los hallazgos no críticos **también penalizan**, con topes:

```
pena_moderadas = min(1.5, 0.30 × nº moderadas)
pena_menores   = min(0.5, 0.05 × nº menores)
```

Antes sólo contaban los críticos, de modo que **50 hallazgos moderados daban cumplimiento
pleno**. Los topes evitan el extremo contrario: que una acumulación de nimiedades hunda un
control sustancialmente correcto.

📁 `modulos/control_evaluacion_data.py` → `calcular_score_cumplimiento()`

---

## 9. Fase F — Entregables y trazabilidad

### El JSON auditable

Contiene todas las evaluaciones y, crucialmente, una **huella reproducible**:

```json
"agente": {
  "agente_version": "27.1",
  "modelo_ia": "claude-haiku-4-5-20251001",
  "pesos_ambito": { ... },
  "huella_ejecucion": "c31e426a0310",
  "huella_completa": "c31e426a03109cef0220c097...",
  "documentos_huella": {
    "doc_modelamiento/Manual_Metodologico_LaR_completo.pdf": {
      "sha256": "b0aea667167e", "chars": 6026
    }
  },
  "n_documentos": 8,
  "generado_utc": "2026-07-29T08:37:14Z"
}
```

**Qué permite.** Ante la pregunta *«¿con qué documentos exactamente se produjo este
dictamen?»*, la respuesta está en el propio informe, con hash por documento. Si alguien
sustituye un manual y re-ejecuta, la huella cambia y la diferencia es demostrable.

📁 `agente.py` → sección `[TRAZA-FIX]`

### El informe Word

Se genera sólo en modo `--prdc`. Estructura jerárquica: ámbito → control → actividad, con
concepto, resultado, observaciones y oportunidad de mejora.

Tres cuidados que no son obvios:

**No deforma los puntajes.** La conversión de escalas colapsaba el rango (5, 12] hacia 1: un
5.4 se convertía en el peor puntaje por una heurística de «si es mayor que 5 debe ser escala
0-100».

**No borra hallazgos legítimos.** Un filtro de mensajes de error buscaba subcadenas sueltas
—«error», «api»— en cualquier posición, y el llamante borraba el campo. Un hallazgo real como
*«El manual documenta la API de extracción y no presenta errores de implementación»*
desaparecía del informe. Hoy se exige que el texto **empiece** con una firma de error.

**No filtra rutas de la máquina.** Los informes son lo que sale de la organización: no
contienen rutas absolutas que revelen usuario ni estructura de carpetas. Hay un test que lo
comprueba sobre todos los `.docx` generados.

📁 `modulos/generador_word.py`

---

## 10. El bucle de aprendizaje

En pre-producción, al terminar la corrida el agente pregunta al validador si está de acuerdo
con cada puntaje. Las correcciones se guardan y alimentan las corridas siguientes por dos
vías:

1. **Contexto en el prompt** — se le muestran al modelo las correcciones previas en
   actividades similares.
2. **Ajuste numérico directo** — si hay suficiente masa crítica de correcciones concordantes,
   se ajusta el puntaje.

📁 `modulos/feedback.py`, `modulos/feedback_mejorado.py`

### Los umbrales anti-sesgo

| Parámetro | Valor | Qué gobierna |
|---|---:|---|
| `VIRF_MIN_FEEDBACK_ANTISESGO` | 15 | Correcciones para el bloque del prompt |
| `VIRF_MIN_MUESTRAS_AJUSTE` | 15 | Correcciones para el ajuste numérico |

**Por qué existen.** Sin umbral, tres opiniones mueven un puntaje entero: medido, con 3
muestras de diferencia +2, un puntaje 2.0 pasaba a 2.8, que redondea a 3. Un punto entero
sobre una escala de 5 basado en tres correcciones.

**Por qué son iguales.** El ajuste numérico es la intervención **más directa** sobre el
dictamen, y tenía el guardia **más débil**: quien subiera el umbral del prompt creyendo
endurecer el sistema seguía teniendo el ajuste disparándose con 3 muestras. Hoy el segundo
hereda el primero por defecto.

### Durabilidad del historial

El historial de feedback es memoria acumulada del validador: perderlo significa perder meses
de calibración. Se escribe con **lock entre procesos**, **escritura atómica** (fichero
temporal + `os.replace` + `fsync`) y **fusión** con lo que haya en disco.

Verificado con procesos concurrentes reales: antes, **77 % de pérdida y 6 de 6 ficheros
corruptos**; después, **80 de 80 registros y 0 corruptos**.

Si el fichero llega corrupto, se respalda como `.corrupto-<timestamp>.json` en lugar de
devolver una lista vacía en silencio.

---

## 11. Los seis invariantes que definen al agente

Si hubiera que resumir la metodología en seis reglas que **no se pueden romper**, serían
éstas. **Los seis están protegidos por tests de regresión**; los invariantes 1, 4 y 5 tienen
además checks de coste cero en `validate_project.py`, que los verifica sin llamar a la API.

### 1. No se evalúa sobre el vacío

Sin evidencia no se llama al modelo. Preguntar a un LLM sobre un documento que no existe
produce una alucinación con formato de dictamen.

### 2. No se inventa un puntaje

Si el modelo no responde conforme al contrato, la actividad queda sin puntaje y se reporta
como fallo técnico. Nunca se rellena con un valor por defecto.

### 3. La ausencia y el fallo no se confunden

«No aportaste documentación» (0.0, falta crítica del validado) y «se cayó la herramienta»
(excluido, fallo del agente) son cosas distintas, con responsables opuestos, y el informe las
nombra por separado.

### 4. La cobertura declarada es la cobertura real

Ningún documento se recorta en silencio. Si sólo se leyó el 30 %, el informe dice 30 %. La
cobertura es lo que el auditor lee como exhaustividad: inflarla es la forma más eficaz de
producir confianza injustificada.

### 5. Toda corrida es reproducible

Huella SHA-256 de la configuración, de cada documento, **de la lógica de prompts**, del
estándar aplicado, versión del agente y del modelo, y sello temporal UTC. Un dictamen que no
se puede reproducir no es auditable.

El auditor puede formular tres preguntas sobre un puntaje, y el informe responde a las tres:

| Pregunta | Campo del JSON |
|---|---|
| ¿sobre qué evidencia? | `agente.documentos_huella` — SHA-256 por fichero |
| ¿con qué criterio? | `agente.estandar` — SHA-256 del Excel y conteo por tier |
| **¿y qué le preguntasteis al modelo?** | `agente.prompts` + `prompt_sha256` por evaluación |

La tercera se añadió el 30/07/2026. Antes, dos corridas con la misma evidencia y el mismo
estándar podían dar puntajes distintos porque alguien reescribió una instrucción de ámbito, y
nada en el informe lo delataba.

Se guarda el **hash, nunca el texto**: un prompt de evaluación contiene la evidencia íntegra
del modelo, y volcarlo convertiría el informe en una copia del expediente. Para ver el prompt
completo existe `DEBUG_PROMPTS=1`, que lo vuelca a `outputs/<fecha>/debug_prompts/` — eso es
depuración, no auditoría.

### 6. El informe evalúa el modelo que dice evaluar

Un árbol de evidencia = un modelo. El informe no puede citar como evidencia documentos de
otro modelo, y la huella documental es la prueba: enumera cada fichero usado con su SHA-256.

Este invariante se añadió después de violarse de la forma más engañosa posible. Una versión de
`--raiz-evidencia` anunciaba en consola `📂 Evidencia: modelos/VaR_FRTB` mientras leía la
evidencia del proyecto, y emitió un informe completo titulado «VaR Mercado FRTB» cuya huella
contenía `Manual_Metodologico_LaR_completo.pdf`. La causa era que `Mx_00_CargaRutas` existe
dos veces en `sys.modules` —importado a secas y cualificado por paquete—, cada copia con su
propio dict de rutas: se mutaba una y el lector consultaba la otra.

De ahí la regla operativa que debe aplicar cualquiera que use el agente con varios modelos:
**comprueba la procedencia, no el volumen.** Un recuento de caracteres plausible no acredita
nada; solo `documentos_huella` responde qué se leyó.

---

## 12. Modos de operación

### Flags principales

**Evaluación**

| Flag | Qué hace | Consume API |
|---|---|:---:|
| `--titulo` + `--tier` | Pipeline completo de validación | ✅ |
| `--prdc` | Modo producción: Word + firma obligatoria | ✅ |
| `--control` + `--excel` | Pipeline por controles de calidad de datos | ✅ |
| `--revisar-codigo` | Contrasta el código contra el manual, **una llamada por módulo** | ✅ |
| `--perfilar-datasets` | Añade el ESQUEMA de los datasets a la evidencia | ❌ |
| `--raiz-evidencia RUTA` | Árbol de evidencia alternativo — **un modelo por raíz** | — |
| `--datasets RUTA` | Carpeta de datasets | — |
| `--no-cache` | Desactiva el caché en esta corrida | — |

**Documentación automática**

| Flag | Qué hace | Consume API |
|---|---|:---:|
| `--explicar-modelo NOMBRE` | Documento pedagógico del modelo validado | ✅ |
| `--excluir F1,F2` · `--solo-coincidentes` | Filtran la evidencia del explicador | — |
| `--convertir-excel CARPETA` | Excel → notebook ejecutable | ✅ |
| `--controles-a-notebook DOC` | Documento de controles → notebook + brechas | ✅ |
| `--sin-llm` · `--sin-validacion` | Modo estructural sin IA / sin auto-validación | ❌ |

**Cumplimiento regulatorio** — todos coste 0 salvo la firma

| Flag | Qué hace | Consume API |
|---|---|:---:|
| `--validador` + `--cargo` | Identidad del responsable. **Obligatorios con `--prdc`** | — |
| `--verificar-cadena MODELO` | Integridad de la cadena de custodia · **exit 1 si está rota** | ❌ |
| `--verificar-evidencia JSON` | ¿Siguen intactos los documentos citados? · **exit 1 si no** | ❌ |
| `--historial-validaciones` | Quién firmó qué y cuándo | ❌ |

**Diagnóstico y caché** — todos coste 0

| Flag | Qué hace | Consume API |
|---|---|:---:|
| `--dry-run` | Inventario y coste estimado, sin llamar al modelo | ❌ |
| `--estadisticafeedback` | Estadísticas del historial de correcciones | ❌ |
| `--cache-stats` · `--limpiar-cache` | Estado / vaciado del caché | ❌ |
| `--listar-motores` | Catálogo de pruebas de calidad de datos | ❌ |
| `--verificar-conexion-azure` | Prueba de humo del proveedor activo | ✅ (1 req.) |

> **28 flags en total.** Ficha por flag, precedencia de modos, matriz de
> compatibilidad y códigos de salida en **`FLAGS.md`**. El procedimiento
> operativo paso a paso, en **`RUNBOOK.md`**.

### Validar varios modelos

El pipeline lee **todo** el árbol de evidencia sin filtrar por modelo: `--titulo` solo rotula
el informe e infiere el dominio RAG. Con la evidencia de varios modelos en el mismo árbol, el
manual de uno puntúa como evidencia de otro.

```bash
python agente.py --titulo "VaR Mercado FRTB" --tier 1                  --raiz-evidencia modelos/VaR_FRTB --prdc
```

Se redirigen las seis carpetas de evidencia. **No** se mueven el estándar VIRF —es la vara de
medir común, y que cada carpeta trajera la suya permitiría validar dos modelos contra
criterios distintos sin que nadie lo notara—, ni `outputs/`, ni el caché.

Detalle completo en `GUIA_MULTIMODELO_Y_RAG.md`.

### Pre-producción vs producción

**Pre-producción** (por defecto) es el modo de trabajo: activa el bucle de feedback, no genera
Word. **Producción** (`--prdc`) emite el entregable.

El caché de documentos está activo en **ambos** modos. La frescura la garantiza el hash
SHA-256, no el modo de ejecución; para desactivarlo existe el flag explícito `--no-cache`.

### Verificación previa de coste cero

```
python validate_project.py --strict
```

**131 comprobaciones** sin llamar a la API: estructura, credenciales, consistencia de
configuración, pesos, dependencias, integridad del caché, cumplimiento regulatorio y los
invariantes de §11. **Un fallo
aquí debe tratarse como bloqueante**: cuesta cero y cubre defectos que costaron mucho
descubrir.

---

## 13. Qué NO hace el agente

Un documento metodológico honesto tiene que declarar sus límites. Los siguientes no son
defectos: son fronteras de diseño.

**No sustituye al validador.** Produce un borrador trazable. La firma, el criterio y la
responsabilidad son humanos. El bucle de feedback existe precisamente porque se espera que el
validador corrija.

**No verifica la corrección matemática del modelo.** Verifica que la metodología esté
documentada, justificada y sea coherente con la evidencia. Que un VaR esté bien calculado es
una pregunta distinta, que requiere replicar el cálculo sobre los datos.

**No lee lo que no se le da.** Si la evidencia relevante está en un correo, en la cabeza de
alguien o en un repositorio al que no apunta `inputs/`, el agente la reportará como ausente.
Y eso, por política, puntúa 0.0.

**No lee formatos que no tiene registrados, y los omite sin avisar.** Un fichero cuya
extensión no esté en `LECTORES_EXT` desaparece de la evidencia en silencio: `leer_archivo()`
devuelve `None` y nadie lo reporta. Hoy quedan fuera `.scala`, `.yaml`, `.do` y `.sas`, entre
otros. Es la única frontera de este documento que **no** se declara en el informe, y por eso
se nombra aquí: si tu modelo vive parcialmente en uno de esos formatos, la cobertura que el
informe declara será real para lo que leyó, pero el conjunto evaluado será menor de lo que
crees. Regístralos antes de validar.

**No razona entre módulos al revisar el código.** `--revisar-codigo` evalúa cada fichero en su
propia llamada, con el manual como contexto fijo. Es lo que permite que cada módulo entre
íntegro, pero significa que una incoherencia *entre* dos ficheros —`main.py` llama a `lar()`
con argumentos que no cuadran con los que define `libs/calculo.py`— puede escapársele: ninguna
llamada ve los dos a la vez.

**No garantiza que el modelo no alucine dentro de la evidencia aportada.** Los invariantes
impiden evaluar sobre el vacío e inventar puntajes, pero si el documento existe y el modelo
lo interpreta mal, el error pasa. Por eso cada evaluación exige **cita textual localizable**:
el validador puede verificarla.

**Su cobertura documental depende del presupuesto de chunking.** Con la configuración por
defecto, un manual de 1,3 M de caracteres alcanza el 100 % de cobertura. Un documento
sustancialmente mayor podría no lograrlo — y en ese caso el informe lo declarará.

---

## 14. Glosario

| Término | Significado |
|---|---|
| **Ámbito** | Una de las seis dimensiones de validación (§2) |
| **Actividad** | Verificación concreta del estándar VIRF; unidad mínima de evaluación |
| **Tier** | Nivel de exigencia (I–IV) según criticidad del modelo |
| **Cobertura documental** | Fracción del fichero que se llegó a leer |
| **Cobertura de contexto** | Fracción del material disponible que cupo en el prompt |
| **Chunking** | Segmentar y resumir un documento largo preservando cobertura |
| **Consolidación jerárquica** | Resumir resúmenes por niveles para entrar en presupuesto |
| **Huella de ejecución** | SHA-256 de configuración + documentos; identifica la corrida |
| **Masa crítica** | Nº mínimo de correcciones para que el feedback influya |
| **CDD** | Controles de calidad de datos ejecutables sobre datasets reales |
| **RAG** | Recuperación de conocimiento experto por dominio financiero |
| **Sin evidencia** | El validado no aportó documentación → 0.0, falta crítica |
| **Fallo técnico** | El agente no pudo evaluar → excluido del score |

---

## Referencias del código

| Concepto | Fichero |
|---|---|
| Orquestación general | `agente.py` → `main()` |
| Configuración central | `config/` (`parametros`, `rutas`, `dominio`, `ia`) |
| Lectura de evidencia | `motor/Mx_01_LecturaEvidencias.py` |
| Construcción de prompts | `motor/Mx_02_EstructuraPrompt.py` |
| Llamada al modelo y contrato | `motor/Mx_03_LlamarIA.py` |
| Motores de calidad de datos | `motor/Mx_04_MotorControlesData.py`, `modulos/motores_datos.py` |
| Evaluación y agregación | `modulos/motor_ia.py`, `modulos/motor_ia_v2.py` |
| Chunking | `modulos/chunker.py` |
| Caché de documentos | `modulos/document_cache.py` |
| Informe Word | `modulos/generador_word.py` |
| Feedback y anti-sesgo | `modulos/feedback.py`, `modulos/feedback_mejorado.py` |
| RAG por dominio | `src/rag/` |
| Verificación de integridad | `validate_project.py` |
| Revisión de código vs documentación | `modulos/revision_codigo.py` |
| Perfilado de datasets | `modulos/perfilador_datasets.py` |
| Cadena de custodia | `modulos/custodia.py` |
| Firma del validador | `modulos/validador_humano.py`, `modulos/override_humano.py` |
| Catálogo de modelos IA | `config/modelos.py` |
| Regresión | `tests/test_regresion.py`, `tests/test_azure_mocks.py`, `tests/test_estructura_config.py` |

---

*Documento generado el 29 de julio de 2026 · actualizado el 30 de julio de 2026 · Agente VIRF v27.1*
*Metodología verificada contra el código, no contra la documentación previa.*
*Estado: `validate_project.py --strict` **131/131** · `pytest` **473 passed**.*

**Documentos hermanos**

| Documento | Contenido |
|---|---|
| `RUNBOOK.md` | **El flujo operativo en 6 pasos con los criterios de parada** |
| `FLAGS.md` | Manual de la CLI: ficha por flag, precedencia, códigos de salida |
| `FUNCIONALIDADES.md` | Catálogo funcional completo |
| `INFORME_AUDITORIA_2026-07-29.md` | Auditoría exhaustiva de 7 fases y veredicto de producción |
| `GUIA_MULTIMODELO_Y_RAG.md` | Validar varios modelos · poblar y verificar el RAG |
| `scripts/generar_corpus_rag.py` | Generador del corpus de literatura de referencia |
