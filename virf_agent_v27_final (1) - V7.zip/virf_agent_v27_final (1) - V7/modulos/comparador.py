"""
modulos/comparador.py
═══════════════════════════════════════════════════════════════════════════════
COMPARACIÓN ENTRE CORRIDAS — qué cambió desde la revisión anterior.

LA PREGUNTA QUE RESPONDE
────────────────────────
Un validador que revisa el mismo modelo cada trimestre necesita explicar por qué
el puntaje pasó de 3,2 a 4,0. Hasta ahora eso exigía abrir los dos informes y
cotejarlos a mano, actividad por actividad.

Y hay una pregunta peor, que a mano casi no se puede responder:

    ¿el modelo MEJORÓ, o cambió el CRITERIO con el que se le mide?

Las dos producen exactamente la misma subida de nota. Distinguirlas es la razón
por la que el informe guarda `agente.estandar` con el SHA-256 del Excel de
estándares y el conteo de actividades por tier. Ese dato se guardaba desde hacía
tiempo y NADIE lo leía: este módulo es lo que lo convierte en útil.

QUÉ COMPARA
───────────
  · score global y por ámbito
  · actividad por actividad: subidas, bajadas, nuevas y desaparecidas
  · la evidencia: qué documentos cambiaron de hash, cuáles se añadieron o se
    retiraron
  · la vara de medir: si cambió el estándar, el modelo de IA o la versión del
    agente — los tres alteran el resultado sin que el modelo haya cambiado

DE DÓNDE SACA LAS CORRIDAS
──────────────────────────
De la cadena de custodia (`custodia.informes_de_modelo`), que las ordena
SIGUIENDO LOS ENLACES y no por fecha de fichero. Comparar «los dos últimos» es
por tanto comparar dos eslabones consecutivos, no dos ficheros que casualmente
tengan fechas próximas.

No llama al modelo: es aritmética sobre dos JSON.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("virf.comparador")

__all__ = ["Comparacion", "comparar", "formatear"]

# Diferencia de score por debajo de la cual no se reporta un ámbito como
# cambiado. Evita ruido por redondeo cuando se recalcula la media.
_UMBRAL_CAMBIO = 0.005


@dataclass
class CambioActividad:
    ambito: str
    actividad: str
    antes: Optional[float]
    ahora: Optional[float]
    observacion_ahora: str = ""

    @property
    def delta(self) -> Optional[float]:
        if self.antes is None or self.ahora is None:
            return None
        return self.ahora - self.antes


@dataclass
class Comparacion:
    modelo: str
    ruta_antes: Path
    ruta_ahora: Path
    fecha_antes: str = ""
    fecha_ahora: str = ""
    eslabon_antes: Optional[int] = None
    eslabon_ahora: Optional[int] = None

    score_antes: Optional[float] = None
    score_ahora: Optional[float] = None
    ambitos: Dict[str, Tuple[Optional[float], Optional[float]]] = field(default_factory=dict)

    subieron: List[CambioActividad] = field(default_factory=list)
    bajaron: List[CambioActividad] = field(default_factory=list)
    nuevas: List[CambioActividad] = field(default_factory=list)
    desaparecidas: List[CambioActividad] = field(default_factory=list)

    docs_modificados: List[str] = field(default_factory=list)
    docs_nuevos: List[str] = field(default_factory=list)
    docs_retirados: List[str] = field(default_factory=list)

    # Cambios en la VARA DE MEDIR: alteran el resultado sin que el modelo cambie
    cambio_estandar: Dict = field(default_factory=dict)
    cambio_motor: Dict = field(default_factory=dict)
    cambio_prompts: Dict = field(default_factory=dict)

    @property
    def delta_score(self) -> Optional[float]:
        if self.score_antes is None or self.score_ahora is None:
            return None
        return self.score_ahora - self.score_antes

    @property
    def vara_cambiada(self) -> bool:
        """True si cambió algo que altera la medición, no el modelo."""
        return bool(self.cambio_estandar or self.cambio_motor
                    or self.cambio_prompts)

    def a_dict(self) -> Dict:
        return {
            "modelo": self.modelo,
            "desde": {"fichero": self.ruta_antes.name, "fecha": self.fecha_antes,
                      "eslabon": self.eslabon_antes, "score": self.score_antes},
            "hasta": {"fichero": self.ruta_ahora.name, "fecha": self.fecha_ahora,
                      "eslabon": self.eslabon_ahora, "score": self.score_ahora},
            "delta_score": self.delta_score,
            "ambitos": {k: {"antes": v[0], "ahora": v[1]}
                        for k, v in self.ambitos.items()},
            "actividades": {
                "subieron": len(self.subieron), "bajaron": len(self.bajaron),
                "nuevas": len(self.nuevas),
                "desaparecidas": len(self.desaparecidas),
            },
            "evidencia": {
                "modificados": self.docs_modificados,
                "nuevos": self.docs_nuevos,
                "retirados": self.docs_retirados,
            },
            "cambio_estandar": self.cambio_estandar,
            "cambio_motor": self.cambio_motor,
            "cambio_prompts": self.cambio_prompts,
            "vara_cambiada": self.vara_cambiada,
        }


def _cargar(ruta: Path) -> Dict:
    return json.loads(Path(ruta).read_text(encoding="utf-8"))


def _indice_actividades(datos: Dict) -> Dict[Tuple[str, str], Dict]:
    """
    Actividades indexadas por (ámbito, texto de la actividad).

    El texto es la clave natural: no hay id estable en el estándar, y el ámbito
    solo no basta porque tiene varias actividades. Si el estándar reescribe el
    enunciado de una actividad, aquí aparecerá como una desaparecida y una nueva
    — que es exactamente lo que ha pasado, y conviene verlo.
    """
    idx = {}
    for ambito, evals in (datos.get("resultados_por_ambito") or {}).items():
        for ev in evals or []:
            clave = (ambito, str(ev.get("actividad", ""))[:200])
            idx[clave] = ev
    return idx


def comparar(outputs_dir, modelo: str,
             ruta_antes: Optional[Path] = None,
             ruta_ahora: Optional[Path] = None) -> Comparacion:
    """
    Compara dos corridas del mismo modelo. Por defecto, las dos últimas de la
    cadena de custodia.

    Lanza `ValueError` si no hay al menos dos informes: comparar exige dos
    puntos, y decirlo es más útil que devolver una comparación vacía.
    """
    from modulos.custodia import informes_de_modelo

    if ruta_antes is None or ruta_ahora is None:
        informes = informes_de_modelo(outputs_dir, modelo)
        if len(informes) < 2:
            raise ValueError(
                f"Se necesitan al menos 2 informes de '{modelo}' para comparar; "
                f"hay {len(informes)}.\n"
                f"   Ejecuta una validación más y vuelve a intentarlo."
            )
        ruta_antes, ruta_ahora = informes[-2], informes[-1]

    antes, ahora = _cargar(ruta_antes), _cargar(ruta_ahora)
    c = Comparacion(modelo=modelo, ruta_antes=Path(ruta_antes),
                    ruta_ahora=Path(ruta_ahora))

    c.fecha_antes = str(antes.get("fecha", ""))
    c.fecha_ahora = str(ahora.get("fecha", ""))
    c.eslabon_antes = (antes.get("custodia") or {}).get("posicion_en_cadena")
    c.eslabon_ahora = (ahora.get("custodia") or {}).get("posicion_en_cadena")
    c.score_antes = antes.get("score_global")
    c.score_ahora = ahora.get("score_global")

    # ── Ámbitos ──────────────────────────────────────────────────────────────
    sa = antes.get("scores_por_ambito") or {}
    sh = ahora.get("scores_por_ambito") or {}
    for ambito in sorted(set(sa) | set(sh)):
        va, vh = sa.get(ambito), sh.get(ambito)
        if va is None and vh is None:
            continue
        if va is None or vh is None or abs(vh - va) >= _UMBRAL_CAMBIO:
            c.ambitos[ambito] = (va, vh)

    # ── Actividad por actividad ──────────────────────────────────────────────
    ia_, ih = _indice_actividades(antes), _indice_actividades(ahora)
    for clave in sorted(set(ia_) | set(ih)):
        ambito, actividad = clave
        ev_a, ev_h = ia_.get(clave), ih.get(clave)
        pa = ev_a.get("puntaje") if ev_a else None
        ph = ev_h.get("puntaje") if ev_h else None
        obs = str((ev_h or {}).get("observacion", ""))[:160]
        cambio = CambioActividad(ambito, actividad, pa, ph, obs)

        if ev_a is None:
            c.nuevas.append(cambio)
        elif ev_h is None:
            c.desaparecidas.append(cambio)
        elif pa is not None and ph is not None and ph != pa:
            (c.subieron if ph > pa else c.bajaron).append(cambio)

    # ── Evidencia: qué documentos cambiaron ──────────────────────────────────
    ha = (antes.get("agente") or {}).get("documentos_huella") or {}
    hh = (ahora.get("agente") or {}).get("documentos_huella") or {}
    for doc in sorted(set(ha) | set(hh)):
        if doc not in ha:
            c.docs_nuevos.append(doc)
        elif doc not in hh:
            c.docs_retirados.append(doc)
        elif ha[doc].get("sha256") != hh[doc].get("sha256"):
            c.docs_modificados.append(doc)

    # ── La vara de medir ─────────────────────────────────────────────────────
    # Esto es lo que distingue «el modelo mejoró» de «cambió el criterio».
    ea = (antes.get("agente") or {}).get("estandar") or {}
    eh = (ahora.get("agente") or {}).get("estandar") or {}
    if ea and eh and ea.get("sha256") != eh.get("sha256"):
        c.cambio_estandar = {
            "sha256_antes": (ea.get("sha256") or "")[:12],
            "sha256_ahora": (eh.get("sha256") or "")[:12],
            "actividades_antes": ea.get("n_actividades"),
            "actividades_ahora": eh.get("n_actividades"),
            "requeridas_antes": ea.get("n_requeridas_en_este_tier"),
            "requeridas_ahora": eh.get("n_requeridas_en_este_tier"),
        }

    aa, ah = antes.get("agente") or {}, ahora.get("agente") or {}
    for campo in ("modelo_ia", "proveedor_ia", "agente_version"):
        if aa.get(campo) != ah.get(campo):
            c.cambio_motor[campo] = {"antes": aa.get(campo), "ahora": ah.get(campo)}

    # [BLOQUE 4] El prompt también es vara de medir: reescribir una instrucción
    # de ámbito cambia el puntaje con la misma evidencia y el mismo estándar.
    # Se compara al nivel más fino disponible para poder señalar QUÉ cambió —
    # el rol del agente o las instrucciones por ámbito— y no solo que algo lo hizo.
    pa, ph = aa.get("prompts") or {}, ah.get("prompts") or {}
    if pa and ph and pa.get("plantilla") != ph.get("plantilla"):
        detalle = {"plantilla_antes": pa.get("plantilla"),
                   "plantilla_ahora": ph.get("plantilla")}
        for parte, etiqueta in (("rol_agente", "rol del agente"),
                                ("instrucciones_ambito", "instrucciones por ámbito")):
            if pa.get(parte) != ph.get(parte):
                detalle[parte] = etiqueta
        c.cambio_prompts = detalle

    return c


def _flecha(delta: Optional[float]) -> str:
    if delta is None:
        return "  "
    if delta > 0:
        return "↑"
    if delta < 0:
        return "↓"
    return "="


def _num(v: Optional[float]) -> str:
    return "  n/d" if v is None else f"{v:5.2f}"


def formatear(c: Comparacion, max_filas: int = 10) -> str:
    sep = "═" * 74
    L = ["", sep, f"  📊 COMPARACIÓN DE CORRIDAS — {c.modelo}", sep, ""]
    L.append(f"  Desde : eslabón #{c.eslabon_antes}  {c.fecha_antes}  "
             f"({c.ruta_antes.name})")
    L.append(f"  Hasta : eslabón #{c.eslabon_ahora}  {c.fecha_ahora}  "
             f"({c.ruta_ahora.name})")

    # ── Aviso de vara cambiada: va ARRIBA, antes que los números ────────────
    # Si cambió el criterio, cualquier lectura de los deltas de abajo es
    # engañosa. Ponerlo al final sería enterrar la advertencia.
    if c.vara_cambiada:
        L += ["", "  " + "─" * 70,
              "  ⚠️  LA VARA DE MEDIR CAMBIÓ ENTRE ESTAS DOS CORRIDAS",
              "     Las diferencias de abajo NO son solo del modelo."]
        if c.cambio_estandar:
            ce = c.cambio_estandar
            L.append(f"     · Estándar VIRF: {ce['sha256_antes']} → "
                     f"{ce['sha256_ahora']}")
            if ce.get("actividades_antes") != ce.get("actividades_ahora"):
                L.append(f"       actividades: {ce['actividades_antes']} → "
                         f"{ce['actividades_ahora']}")
            if ce.get("requeridas_antes") != ce.get("requeridas_ahora"):
                L.append(f"       requeridas en el tier: "
                         f"{ce['requeridas_antes']} → {ce['requeridas_ahora']}")
        for campo, v in c.cambio_motor.items():
            L.append(f"     · {campo}: {v['antes']} → {v['ahora']}")
        if c.cambio_prompts:
            cp = c.cambio_prompts
            L.append(f"     · Lógica de PROMPTS: {cp.get('plantilla_antes')} → "
                     f"{cp.get('plantilla_ahora')}")
            for parte in ("rol_agente", "instrucciones_ambito"):
                if parte in cp:
                    L.append(f"       cambió: {cp[parte]}")
        L.append("  " + "─" * 70)

    # ── Score ────────────────────────────────────────────────────────────────
    d = c.delta_score
    signo = f"{d:+.2f}" if d is not None else "n/d"
    L += ["", f"  SCORE GLOBAL   {_num(c.score_antes)} → {_num(c.score_ahora)}"
              f"   {signo}  {_flecha(d)}"]

    if c.ambitos:
        L.append("")
        for ambito, (va, vh) in c.ambitos.items():
            dd = None if (va is None or vh is None) else vh - va
            L.append(f"    {ambito:<34} {_num(va)} → {_num(vh)}  {_flecha(dd)}")
    else:
        L.append("    (ningún ámbito cambió de puntaje)")

    # ── Actividades ──────────────────────────────────────────────────────────
    def bloque(titulo, items, mostrar_delta=True):
        if not items:
            return []
        out = ["", f"  {titulo} ({len(items)}):"]
        for ch in items[:max_filas]:
            if mostrar_delta and ch.delta is not None:
                marca = f"{ch.antes:.0f}→{ch.ahora:.0f}"
            else:
                marca = f"{ch.ahora if ch.ahora is not None else '—'}"
            out.append(f"    [{marca}] {ch.ambito} · {ch.actividad[:58]}")
        if len(items) > max_filas:
            out.append(f"    … y {len(items) - max_filas} más")
        return out

    L += bloque("✅ MEJORARON", c.subieron)
    L += bloque("🔻 EMPEORARON", c.bajaron)
    L += bloque("🆕 ACTIVIDADES NUEVAS", c.nuevas, mostrar_delta=False)
    L += bloque("➖ YA NO SE EVALÚAN", c.desaparecidas, mostrar_delta=False)

    if c.nuevas or c.desaparecidas:
        L += ["", "     Actividades que aparecen o desaparecen suelen venir de un",
              "     cambio de tier o de una reescritura del estándar, no del modelo."]

    # ── Evidencia ────────────────────────────────────────────────────────────
    if c.docs_modificados or c.docs_nuevos or c.docs_retirados:
        L += ["", "  📄 EVIDENCIA:"]
        for doc in c.docs_modificados[:max_filas]:
            L.append(f"    ~ modificado  {doc}")
        for doc in c.docs_nuevos[:max_filas]:
            L.append(f"    + añadido     {doc}")
        for doc in c.docs_retirados[:max_filas]:
            L.append(f"    - retirado    {doc}")
        if c.docs_modificados:
            L.append("     Un documento modificado explica un cambio de puntaje "
                     "legítimamente.")
    else:
        L += ["", "  📄 EVIDENCIA: sin cambios — los mismos documentos y los "
                  "mismos hashes."]
        if c.delta_score and abs(c.delta_score) >= _UMBRAL_CAMBIO and \
                not c.vara_cambiada:
            L += ["",
                  "  ⚠️  El score cambió con la MISMA evidencia y la MISMA vara.",
                  "     Es variabilidad del modelo de lenguaje entre corridas.",
                  "     Revísalo antes de atribuir la diferencia al modelo validado."]

    L += ["", sep, ""]
    return "\n".join(L)
