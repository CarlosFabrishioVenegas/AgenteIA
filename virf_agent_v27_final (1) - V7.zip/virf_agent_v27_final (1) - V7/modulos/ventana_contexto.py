"""
modulos/ventana_contexto.py
═════════════════════════════════════════════════════════════════════════════
Resolución de la ventana de contexto real del modelo (WP-10 · GAP-40).

POR QUÉ
───────
`config/parametros.py:162` fija `MAX_CTX = _entero("VIRF_MAX_CTX", 15000)`: un
fallback FIJO de 15.000 que no consulta qué modelo hay detrás. Un gpt-4o tiene
128K de contexto y un gpt-4 clásico 8K — usar 15.000 para ambos desperdicia el
primero y **trunca en silencio** el segundo, justo el antipatrón que la guía
prohíbe (anti "Lost in the Middle" / anti-hardcode).

El proyecto YA tiene la detección dinámica: `config/modelos.py::perfil_modelo`
mapea el modelo a su ventana real (`.max_ctx`, en caracteres). Lo que faltaba
era CONSULTARLA en vez del literal. Este módulo cierra ese hueco.

QUÉ HACE
────────
`resolver_ventana()` decide el presupuesto de contexto en este orden, y SIEMPRE
declara de dónde salió (nunca un default silencioso):

  1. `VIRF_MAX_CTX` puesto explícitamente en el entorno → se respeta (override
     de operador declarado).                                     fuente="env"
  2. Nombre del deployment (`AZURE_OPENAI_DEPLOYMENT`) → `perfil_modelo` por
     coincidencia de substring → ventana real del catálogo.      fuente="catalogo"
  3. Modelo no catalogado → perfil conservador de `config/modelos.py`, con
     aviso explícito (no 15.000 a ciegas).                       fuente="fallback"

LÍMITE HONESTO (gap declarado): sin API solo se conoce el NOMBRE del deployment,
no el modelo exacto que sirve (`gpt-4o-2024-11-20`). La resolución por substring
del nombre es lo determinable sin gastar crédito; la confirmación contra el
servidor (`config/ia.py::detectar_modelo_deployment`) es trabajo del día de API.
Se marca `confirmado_por_api=False` para no fingir una certeza que no se tiene.

Sin API.
"""
from __future__ import annotations

import os
from typing import Any, Dict, Optional

from config.modelos import perfil_modelo, PERFIL_CONSERVADOR

__all__ = ["resolver_ventana", "max_ctx_efectivo"]


def resolver_ventana(deployment: Optional[str] = None,
                     env: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Resuelve el presupuesto de contexto (en caracteres) del modelo configurado.

    Args:
        deployment: nombre del deployment. Si None, se lee de
                    `AZURE_OPENAI_DEPLOYMENT`.
        env:        mapa de entorno a consultar (default: os.environ). Inyectable
                    para pruebas deterministas.

    Returns:
        dict con: max_ctx (int, chars), contexto_tokens (int), modelo (str),
        fuente ("env"|"catalogo"|"fallback"), confirmado_por_api (bool),
        nota (str).
    """
    entorno = env if env is not None else os.environ

    # 1. Override explícito del operador. Solo si está REALMENTE puesto en el
    #    entorno; el default de parametros.py no cuenta como "explícito".
    crudo = entorno.get("VIRF_MAX_CTX")
    if crudo is not None and str(crudo).strip() != "":
        try:
            valor = int(str(crudo).strip())
            if valor > 0:
                return {
                    "max_ctx": valor,
                    "contexto_tokens": None,
                    "modelo": deployment or entorno.get("AZURE_OPENAI_DEPLOYMENT", ""),
                    "fuente": "env",
                    "confirmado_por_api": False,
                    "nota": "VIRF_MAX_CTX fijado explícitamente por el operador.",
                }
        except (ValueError, TypeError):
            pass  # valor ilegible → se cae a la detección por catálogo

    # 2. Detección por nombre de deployment contra el catálogo real.
    nombre = deployment if deployment is not None else entorno.get(
        "AZURE_OPENAI_DEPLOYMENT", "")
    perfil = perfil_modelo(nombre, verbose=False) if nombre else PERFIL_CONSERVADOR

    es_fallback = perfil.nombre == PERFIL_CONSERVADOR.nombre
    return {
        "max_ctx": perfil.max_ctx,
        "contexto_tokens": perfil.contexto_tokens,
        "modelo": perfil.nombre,
        "fuente": "fallback" if es_fallback else "catalogo",
        "confirmado_por_api": False,
        "nota": (perfil.nota or
                 ("Deployment no catalogado: perfil conservador. Añádelo a "
                  "config/modelos.py para su ventana real." if es_fallback
                  else "Ventana resuelta del catálogo por nombre de deployment "
                       "(sin confirmar contra la API).")),
    }


def max_ctx_efectivo(deployment: Optional[str] = None,
                     env: Optional[Dict[str, str]] = None) -> int:
    """Atajo: solo el presupuesto de contexto en caracteres."""
    return int(resolver_ventana(deployment, env)["max_ctx"])
