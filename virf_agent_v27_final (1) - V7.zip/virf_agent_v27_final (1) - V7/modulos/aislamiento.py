"""
modulos/aislamiento.py
═════════════════════════════════════════════════════════════════════════════
Aislamiento multi-tenant por (tenant, modelo) — WP-02 reducido, indicador D2.

CONTEXTO
────────
El aislamiento estructural ya existe: cada validación vive en su carpeta
`web/data/sesiones/<TENANT>/<MODELO>/`, así que la evidencia de un modelo no se
mezcla con la de otro en disco. Lo que faltaba no era el particionado, sino la
PRUEBA de que ningún fragmento ajeno se cuela en la recuperación —el antipatrón
de "contaminación entre modelos (spillover)" de la guía—.

Este módulo aporta esa garantía como código verificable y reutilizable:
etiqueta cada fragmento con su dueño, filtra por el tenant/modelo activo, y
—defensa en profundidad— ASEVERA que en el conjunto recuperado no queda nada
ajeno. La aserción convierte un spillover silencioso en un fallo ruidoso.

Es determinista y no llama a la API: opera sobre los dicts de fragmentos.

CLAVES DE ETIQUETA
──────────────────
    chunk["tenant"]  → código del validador/entidad dueño de la evidencia
    chunk["modelo"]  → identificador del modelo bajo validación

Un fragmento SIN etiqueta se considera AJENO cuando se está filtrando por un
tenant/modelo concreto: preferimos descartar de más (y declararlo) a dejar
pasar un fragmento cuyo dueño no consta. "No sé de quién es" nunca es "es tuyo".
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

__all__ = [
    "ContaminacionModelo",
    "etiquetar_chunk",
    "pertenece",
    "filtrar_por_tenant",
    "porcentaje_contaminacion",
    "assert_sin_contaminacion",
]


class ContaminacionModelo(Exception):
    """Se lanza cuando un conjunto recuperado contiene fragmentos ajenos."""

    def __init__(self, ajenos: int, total: int, tenant: Optional[str],
                 modelo: Optional[str]):
        pct = (ajenos / total * 100.0) if total else 0.0
        super().__init__(
            f"spillover: {ajenos}/{total} fragmentos ({pct:.1f}%) no pertenecen "
            f"a tenant={tenant!r} modelo={modelo!r}")
        self.ajenos = ajenos
        self.total = total
        self.porcentaje = pct


def etiquetar_chunk(chunk: Dict[str, Any], tenant: str,
                    modelo: str) -> Dict[str, Any]:
    """Devuelve una copia del fragmento con su dueño anotado (no muta el original)."""
    etiquetado = dict(chunk)
    etiquetado["tenant"] = tenant
    etiquetado["modelo"] = modelo
    return etiquetado


def pertenece(chunk: Dict[str, Any], tenant: Optional[str],
              modelo: Optional[str]) -> bool:
    """
    ¿El fragmento pertenece al (tenant, modelo) activo?

    Si un criterio es None, no se exige por ese eje. Un fragmento sin la clave
    correspondiente NO pertenece cuando ese eje sí se exige (política estricta:
    la ausencia de dueño no acredita pertenencia).
    """
    if tenant is not None and chunk.get("tenant") != tenant:
        return False
    if modelo is not None and chunk.get("modelo") != modelo:
        return False
    return True


def filtrar_por_tenant(chunks: Sequence[Dict[str, Any]], tenant: Optional[str],
                       modelo: Optional[str] = None) -> List[Dict[str, Any]]:
    """Conserva solo los fragmentos del (tenant, modelo) activo."""
    return [c for c in chunks if pertenece(c, tenant, modelo)]


def porcentaje_contaminacion(chunks: Sequence[Dict[str, Any]],
                             tenant: Optional[str],
                             modelo: Optional[str] = None) -> float:
    """Porcentaje de fragmentos AJENOS al (tenant, modelo) activo. 0.0 = limpio."""
    total = len(chunks)
    if total == 0:
        return 0.0
    ajenos = sum(1 for c in chunks if not pertenece(c, tenant, modelo))
    return ajenos / total * 100.0


def assert_sin_contaminacion(chunks: Sequence[Dict[str, Any]],
                             tenant: Optional[str],
                             modelo: Optional[str] = None) -> None:
    """
    Verifica que NINGÚN fragmento del conjunto es ajeno. Lanza si lo hay.

    Se usa como defensa en profundidad DESPUÉS de filtrar: si el filtro fuera
    correcto nunca dispara; si algún día se rompe, el fallo es inmediato y
    visible en vez de un dictamen contaminado en silencio.
    """
    total = len(chunks)
    if total == 0:
        return
    ajenos = sum(1 for c in chunks if not pertenece(c, tenant, modelo))
    if ajenos:
        raise ContaminacionModelo(ajenos, total, tenant, modelo)
