"""
consola.py  [v27.2]
===================
Salida de consola a prueba de codificación.

PROBLEMA QUE RESUELVE
---------------------
El proyecto imprime emoji en 19 módulos (`📐 CHUNKING ADAPTATIVO`, `✅`, `⚠️`,
`🏗️`…). En una consola Windows con codepage cp1252 —el default en español—
`print()` no revienta al *escribir*, revienta al *codificar*:

    UnicodeEncodeError: 'charmap' codec can't encode character '\\U0001f4d0'

Detectado en la auditoría D2 (2026-07-27): `agente.py` abortaba a mitad del
chunking de un PDF de 305 páginas, tras ~35 s de extracción y varias llamadas
IA ya pagadas. El fallo NO lo veían los tests porque pytest captura stdout en
un buffer UTF-8, ni `validate_project.py` porque no imprime emoji en el camino
crítico. Solo aparecía en una corrida interactiva real.

POR QUÉ NO SE ARREGLA QUITANDO LOS EMOJI
----------------------------------------
Son 19 ficheros y cientos de `print`. Cualquier módulo nuevo volvería a
introducir el fallo. El punto único de control es el flujo de salida, no cada
llamada a `print`.

ESTRATEGIA (tres capas, de mejor a peor caso)
---------------------------------------------
  1. Poner la consola de Windows en UTF-8 (codepage 65001) → los emoji se ven.
  2. Reconfigurar sys.stdout/sys.stderr a UTF-8 con `errors="replace"`.
  3. Si nada de lo anterior es posible, `errors="replace"` garantiza que un
     carácter no representable salga como '?' en vez de abortar el proceso.

La regla es: **la codificación nunca puede tumbar una corrida**. Es preferible
un '?' en el log que perder 35 s de extracción y llamadas IA ya facturadas.

Uso
---
    from modulos.consola import configurar_consola
    configurar_consola()          # idempotente; llamar al inicio del entrypoint
"""

from __future__ import annotations

import io
import sys

__all__ = ["configurar_consola", "consola_soporta_unicode"]

_YA_CONFIGURADA = False


def _forzar_codepage_utf8_windows() -> bool:
    """
    Pone la consola de Windows en UTF-8 (codepage 65001) para que los emoji se
    rendericen de verdad, en vez de degradarse a '?'.

    Devuelve True si se pudo aplicar. No es imprescindible: si falla, las capas
    siguientes evitan igualmente el crash.
    """
    if sys.platform != "win32":
        return False
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        # 65001 = CP_UTF8. Se cambia salida y entrada por coherencia.
        ok_out = bool(kernel32.SetConsoleOutputCP(65001))
        kernel32.SetConsoleCP(65001)
        return ok_out
    except Exception:
        # Sin consola adjunta (servicio, pipe, CI) o ctypes no disponible.
        return False


def _reconfigurar(flujo_nombre: str) -> None:
    """
    Deja `sys.<flujo_nombre>` escribiendo UTF-8 y, sobre todo, con
    `errors="replace"` para que un carácter no representable NUNCA aborte.
    """
    flujo = getattr(sys, flujo_nombre, None)
    if flujo is None:                      # pythonw / stdout suprimido
        return

    # NOTA: cada paso captura `Exception` a propósito, no una lista concreta.
    # sys.stdout puede haber sido sustituido por un objeto arbitrario (IDEs,
    # frameworks de logging, capturadores de test) cuyo __getattr__ lance
    # cualquier cosa. Un test con un flujo hostil destapó que acotar a
    # (AttributeError, ValueError, OSError) dejaba escapar un RuntimeError y
    # tumbaba el arranque — exactamente el fallo que este módulo debe evitar.

    # Camino normal (Python 3.7+): el propio TextIOWrapper se reconfigura.
    try:
        flujo.reconfigure(encoding="utf-8", errors="replace")
        return
    except Exception:
        pass

    # El flujo no es reconfigurable (pytest capture, redirect_stdout, IDEs que
    # sustituyen sys.stdout). Se intenta re-envolver el buffer binario.
    try:
        buffer = getattr(flujo, "buffer", None)
        if buffer is not None:
            setattr(sys, flujo_nombre, io.TextIOWrapper(
                buffer, encoding="utf-8", errors="replace", line_buffering=True,
            ))
            return
    except Exception:
        pass

    # Último recurso: al menos relajar el manejo de errores conservando el
    # encoding actual. Si tampoco se puede, se deja como está: este módulo
    # jamás debe ser el que rompa el arranque.
    try:
        flujo.reconfigure(errors="replace")
    except Exception:
        pass


def configurar_consola() -> None:
    """
    Prepara stdout/stderr para imprimir emoji sin riesgo de UnicodeEncodeError.

    Idempotente y silenciosa: es un bootstrap, no debe emitir ruido ni fallar.
    Llamar lo antes posible en cada entrypoint, ANTES del primer print.
    """
    global _YA_CONFIGURADA
    if _YA_CONFIGURADA:
        return
    _YA_CONFIGURADA = True

    # Red de seguridad final: ni siquiera un fallo inesperado aquí dentro puede
    # impedir que el agente arranque.
    try:
        _forzar_codepage_utf8_windows()
        for nombre in ("stdout", "stderr"):
            _reconfigurar(nombre)
    except Exception:
        pass


def consola_soporta_unicode() -> bool:
    """
    ¿Puede la salida actual representar emoji sin sustituirlos?

    Pensado para que un módulo elija entre '✅' y 'OK' si algún día se quiere
    una salida ASCII pura. No se usa en el camino crítico: tras
    `configurar_consola()` imprimir emoji ya es seguro en cualquier caso.
    """
    encoding = getattr(sys.stdout, "encoding", None) or "ascii"
    try:
        "✅📐🏗️".encode(encoding)
        return True
    except (UnicodeEncodeError, LookupError):
        return False
