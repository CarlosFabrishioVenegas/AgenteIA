"""
Lectura de instrucciones extra (skills + cuestionamientos NL) que la
web deja en la raíz de la sesión (v2 · cableado al motor).

Contrato:
- La web escribe `skills.json` y `cuestionamientos.json` en la raíz de
  la sesión (misma carpeta que contiene `inputs/` y `outputs/`).
- Cuando el agente se lanza con `--raiz-evidencia <sesion.base>`, este
  módulo lee esos ficheros y devuelve una LISTA de strings lista para
  inyectar al prompt de `evaluar_actividad`.
- Si los ficheros no existen (validación desde la CLI clásica, no
  desde la web), devuelve `[]` — el pipeline funciona como siempre.

Formato de los ficheros — el mismo que persisten los stores de la web:

    skills.json:
      {
        "defaults_desactivados": [...],
        "defaults_activados":    [...],
        "custom": [{"id": "custom_001", "descripcion": "...", ...}]
      }

    cuestionamientos.json:
      {
        "defaults_desactivados": [...],
        "custom": [{"id": "cuest_custom_001", "descripcion": "...", ...}]
      }

Este módulo NO reimplementa la lógica de activación de defaults — solo
lee los CUSTOM NL. Los defaults ya se resuelven en otro sitio (skills
default se ejecutan como capacidades del pipeline; los cuestionamientos
default son regex y se aplican en Mx_04 vía `cuestionamientos_ext`).
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional


def _leer_json_seguro(p: Path) -> Optional[dict]:
    if not p.is_file():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return d if isinstance(d, dict) else None


def leer(raiz_sesion: Path) -> List[str]:
    """
    Devuelve las instrucciones NL de la sesión, en el orden en el que
    deben aparecer en el prompt (primero skills, después cuestionamientos).
    """
    raiz = Path(raiz_sesion)
    salida: List[str] = []

    sk = _leer_json_seguro(raiz / "skills.json")
    if sk is not None:
        for c in (sk.get("custom") or []):
            desc = (c.get("descripcion") or "").strip()
            if desc:
                salida.append(f"INSTRUCCIÓN ADICIONAL DEL VALIDADOR: {desc}")

    cu = _leer_json_seguro(raiz / "cuestionamientos.json")
    if cu is not None:
        for c in (cu.get("custom") or []):
            desc = (c.get("descripcion") or "").strip()
            if desc:
                salida.append(f"CUESTIONAMIENTO ADICIONAL DEL VALIDADOR: {desc}")

    return salida


def leer_entendimiento(raiz_sesion: Path) -> Optional[str]:
    """
    Mejora 4 · v2.2 — Devuelve el contenido del entendimiento del
    modelo (Markdown) generado por el análisis del ZIP, junto con las
    correcciones del validador si las hay. `None` si aún no se ha
    analizado el código.
    """
    raiz = Path(raiz_sesion)
    md_files = list(raiz.glob("entendimiento_modelo_*.md"))
    if not md_files:
        return None
    try:
        md = md_files[0].read_text(encoding="utf-8")
    except OSError:
        return None
    # Añade correcciones del validador al final para que el modelo las
    # trate como "verdad más reciente" sobre el modelo.
    fb_path = raiz / "feedback_entendimiento.json"
    if fb_path.is_file():
        try:
            fbs = json.loads(fb_path.read_text(encoding="utf-8"))
            if isinstance(fbs, list) and fbs:
                md += "\n\n## Correcciones del validador\n"
                for f in fbs:
                    ts = (f.get("timestamp") or "")[:19]
                    md += f"- ({ts}) {f.get('comentario','').strip()}\n"
        except (OSError, json.JSONDecodeError):
            pass
    return md
