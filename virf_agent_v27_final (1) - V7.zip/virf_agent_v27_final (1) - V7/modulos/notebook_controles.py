"""
modulos/notebook_controles.py
═════════════════════════════════════════════════════════════════════════════
Genera un .ipynb ENTREGABLE de controles de calidad de datos cuyo output es la
tabla de 8 columnas que pide el validador:

    Control (C01..) | Dimensión | Control Esperado | % De cumplimiento del data set
    | Diagnóstico | Decisión | Control o Evidencia requerida | Referencia en el entregable

El notebook lleva las RUTAS al inicio (editar y ejecutar), corre cada control con
el catálogo `modulos.motores_datos` (mismos motores del pipeline, coste 0, pandas)
y consolida la tabla. Las columnas de CÓMPUTO (%, Diagnóstico, Decisión) salen de
ejecutar el motor; las de METADATO (Dimensión, Control Esperado, Evidencia,
Referencia) salen de la definición del control.

DOS fuentes de los controles:
  1. Un DOCUMENTO de controles subido por el validador (material complementario)
     → se extraen con el LLM (`controles_a_notebook.extraer_controles_del_documento`).
  2. Si no hay documento → el agente los PROPONE desde el entendimiento del modelo
     (`generar_controles_desde_entendimiento`).
"""
from __future__ import annotations

import io
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import nbformat as nbf

# Reutiliza la maquinaria existente (extracción por LLM + código pandas por control).
from modulos.controles_a_notebook import (
    _md, _code, _codigo_control,
    extraer_controles_del_documento, leer_documento,
)

__all__ = [
    "construir_notebook_8cols", "a_ipynb_bytes",
    "generar_controles_desde_entendimiento", "generar_ipynb_controles",
    "DIMENSION_POR_MOTOR",
]

# tipo_motor → Dimensión de calidad de datos (nomenclatura estándar).
DIMENSION_POR_MOTOR = {
    "unicidad":               "Unicidad",
    "duplicados":             "Unicidad",
    "missing":                "Completitud",
    "completitud":            "Completitud",
    "outliers":               "Exactitud",
    "rango":                  "Validez",
    "tipo_dato":              "Validez",
    "integridad_referencial": "Consistencia",
    "narrativo":              "Documental",
}

# estado del motor → Decisión de la tabla.
# OJO: 'ERROR' en los motores es AMBIGUO — puede ser (a) un incumplimiento grave
# (el control corrió, tasa_error alta) o (b) que el control NO se pudo ejecutar
# (falta configuración: r['error'] tiene mensaje). Se distinguen por r['error']:
# si está poblado -> 'No evaluable'; si no -> el mapa de abajo (ERROR = No cumple).
DECISION_POR_ESTADO = {
    "OK":              "Cumple",
    "ADVERTENCIA":     "Observado",
    "ALERTA":          "No cumple",
    "ERROR":           "No cumple",
    "REVISION_MANUAL": "Revisión manual",
    "N/A":             "No evaluable",
}


def _normalizar_controles(controles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Renumera a C01.. y adjunta Dimensión / Control Esperado / Evidencia /
    Referencia a partir de lo extraído. No inventa valores que no estén."""
    out: List[Dict[str, Any]] = []
    for i, c in enumerate(controles or [], start=1):
        cid = f"C{i:02d}"
        tipo = (c.get("tipo_motor") or "narrativo").lower()
        desc = (c.get("descripcion") or "").strip()
        umbral = c.get("umbral") or 0.0
        esperado = desc
        # El umbral se interpreta como en los motores: >=1 => conteo absoluto de
        # hallazgos tolerados; 0<u<1 => proporción; 0 => tolerancia cero.
        try:
            u = float(umbral)
        except (TypeError, ValueError):
            u = 0.0
        if u >= 1:
            esperado += f"  (tolera ≤ {int(u)} hallazgo{'s' if int(u) != 1 else ''})"
        elif u > 0:
            esperado += f"  (tolerancia ≤ {u:.2%})"
        d = dict(c)
        d["id_sugerido"] = cid                       # lo usa _codigo_control
        d["_dimension"] = DIMENSION_POR_MOTOR.get(tipo, "Documental")
        d["_control_esperado"] = esperado or "(sin descripción)"
        d["_evidencia_requerida"] = (c.get("nota") or "").strip() or (
            "Aportar evidencia/soporte del control si no cumple.")
        d["_referencia"] = (c.get("cita_documento") or "").strip()
        out.append(d)
    return out


def construir_notebook_8cols(controles: List[Dict[str, Any]],
                             meta: Dict[str, Any]) -> nbf.NotebookNode:
    """
    Arma el notebook. `meta` admite: titulo, fuente, resumen, proyecto_dir,
    datasets_dir, salida_dir.
    """
    ctrls = _normalizar_controles(controles)
    proyecto = str(meta.get("proyecto_dir") or Path.cwd())
    datasets_dir = str(meta.get("datasets_dir")
                       or (Path(proyecto) / "inputs" / "calidad_datos" / "datasets"))
    salida_dir = str(meta.get("salida_dir")
                     or (Path(proyecto) / "outputs"
                         / datetime.now().strftime("%Y-%m-%d") / "controles"))

    nb = nbf.v4.new_notebook()
    c: List[nbf.NotebookNode] = []

    c.append(_md(
        f"# Controles de Calidad de Datos — entregable ejecutable\n\n"
        f"**Fuente de los controles:** {meta.get('fuente', '—')}  \n"
        f"**Generado:** {datetime.now():%Y-%m-%d %H:%M}  \n"
        f"**Controles:** {len(ctrls)}\n\n"
        f"{meta.get('resumen','')}\n\n"
        f"> Ejecuta las celdas en orden. **Edita primero las RUTAS** de abajo. "
        f"La última celda entrega la tabla de control con 8 columnas."
    ))

    # ── RUTAS (al inicio, como pediste) ─────────────────────────────────────
    c.append(_md("## 0. RUTAS — edita aquí antes de ejecutar"))
    c.append(_code(
        "import sys, json\n"
        "from pathlib import Path\n"
        "import pandas as pd, numpy as np\n\n"
        f"PROYECTO     = Path(r'{proyecto}')\n"
        f"DATASETS_DIR = Path(r'{datasets_dir}')   # carpeta con .csv/.parquet/.xlsx\n"
        f"SALIDA_DIR   = Path(r'{salida_dir}')      # dónde se guarda la tabla\n\n"
        "if str(PROYECTO) not in sys.path:\n"
        "    sys.path.insert(0, str(PROYECTO))\n"
        "from modulos.motores_datos import ejecutar_motor, cargar_datasets\n"
        "resultados = {}\n"
        "print('Rutas:', DATASETS_DIR)"
    ))

    # ── Carga de datasets ───────────────────────────────────────────────────
    c.append(_md("## 1. Carga de datasets"))
    c.append(_code(
        "datasets = cargar_datasets(DATASETS_DIR)\n"
        "print(f'{len(datasets)} dataset(s): {list(datasets)}')\n"
        "for n, d in datasets.items():\n"
        "    print(f'  {n}: {d.shape[0]:,} x {d.shape[1]}')"
    ))
    _usa = sorted({c.get("dataset", "") for c in ctrls if c.get("dataset")})
    principal = _usa[0] if _usa else ""
    c.append(_code(
        f"NOMBRE_DATASET = {principal!r}   # dataset principal; edítalo si aplica\n"
        "df = datasets.get(NOMBRE_DATASET) if NOMBRE_DATASET else (\n"
        "     next(iter(datasets.values())) if datasets else None)\n"
        "if df is None:\n"
        "    print('No hay dataset cargado. Coloca archivos en DATASETS_DIR y re-ejecuta.')\n"
        "else:\n"
        "    display(df.head())"
    ))

    # ── Metadatos de los controles (para las columnas no calculadas) ────────
    c.append(_md("## 2. Definición de los controles"))
    meta_dict = {
        cc["id_sugerido"]: {
            "dimension":  cc["_dimension"],
            "esperado":   cc["_control_esperado"],
            "evidencia":  cc["_evidencia_requerida"],
            "referencia": cc["_referencia"],
        } for cc in ctrls
    }
    c.append(_code("META_CONTROLES = " + repr(meta_dict)))

    # ── Ejecución de cada control (reusa el generador de código del proyecto) ─
    c.append(_md("## 3. Ejecución de los controles"))
    for cc in ctrls:
        c.append(_code(_codigo_control(cc)))

    # ── Tabla final de 8 columnas ───────────────────────────────────────────
    c.append(_md("## 4. Entregable — tabla de control (8 columnas)"))
    c.append(_code(
        "DECISION = " + repr(DECISION_POR_ESTADO) + "\n"
        "COLS = ['Control','Dimensión','Control Esperado',\n"
        "        '% De cumplimiento del data set','Diagnóstico','Decisión',\n"
        "        'Control o Evidencia requerida','Referencia en el entregable']\n"
        "filas = []\n"
        "for cid, mv in META_CONTROLES.items():\n"
        "    r = resultados.get(cid, {})\n"
        "    estado = r.get('estado','N/A')\n"
        "    err = r.get('error')   # poblado => el control NO se pudo ejecutar\n"
        "    te = r.get('tasa_error')\n"
        "    if err:\n"
        "        pct, decision, diag = None, 'No evaluable', err\n"
        "    else:\n"
        "        pct = round(100*(1-te), 2) if isinstance(te,(int,float)) else None\n"
        "        decision = DECISION.get(estado, 'No evaluable')\n"
        "        diag = r.get('detalle') or ''\n"
        "    filas.append({\n"
        "        'Control': cid,\n"
        "        'Dimensión': mv['dimension'],\n"
        "        'Control Esperado': mv['esperado'],\n"
        "        '% De cumplimiento del data set': pct,\n"
        "        'Diagnóstico': str(diag)[:300],\n"
        "        'Decisión': decision,\n"
        "        'Control o Evidencia requerida': mv['evidencia'],\n"
        "        'Referencia en el entregable': mv['referencia'],\n"
        "    })\n"
        "tabla_control = pd.DataFrame(filas, columns=COLS)\n"
        "display(tabla_control)\n"
        "SALIDA_DIR.mkdir(parents=True, exist_ok=True)\n"
        "tabla_control.to_csv(SALIDA_DIR/'tabla_control_datos.csv', index=False, encoding='utf-8-sig')\n"
        "print('Guardado en', SALIDA_DIR/'tabla_control_datos.csv')"
    ))

    nb["cells"] = c
    nb["metadata"] = {
        "kernelspec": {"name": "python3", "display_name": "Python 3"},
        "language_info": {"name": "python"},
        "generado_por": "virf_agent notebook_controles",
        "fuente_controles": meta.get("fuente", ""),
        "n_controles": len(ctrls),
    }
    return nb


def a_ipynb_bytes(nb: nbf.NotebookNode) -> bytes:
    buf = io.StringIO()
    nbf.write(nb, buf)
    return buf.getvalue().encode("utf-8")


# ═════════════════════════════════════════════════════════════════════════════
# NOTEBOOK DESDE EL REPOSITORIO DE CONTROLES (funciones Python por dominio)
# ═════════════════════════════════════════════════════════════════════════════

# Celda de utilidades: define `filas`, el formato del cuadro por celda y los
# helpers que cada control usa. Se emite UNA vez, al inicio.
_SETUP_REPO = r'''
# Utilidades del entregable — NO editar salvo que sepas lo que haces.
import pandas as pd, numpy as np

COLS = ['Control','Dimensión','Control Esperado',
        '% De cumplimiento del data set','Diagnóstico','Decisión',
        'Control o Evidencia requerida','Referencia en el entregable']
filas = []

def _principal(datasets, nombre=""):
    """Dataset principal: el nombrado en params, o el primero disponible."""
    if nombre and nombre in datasets:
        return datasets[nombre]
    return next(iter(datasets.values())) if datasets else None

def _fmt_pct(v):
    return "—" if v is None else f"{float(v):.2f}%"

def _ejecutar(meta, fn, datasets):
    params = dict(meta.get("params", {}))
    df = _principal(datasets, params.get("dataset", ""))
    try:
        res = fn(df, datasets, params)
        if not isinstance(res, dict):
            res = {"pct": None, "decision": "No evaluable", "diagnostico": "el control no devolvió dict"}
    except Exception as e:
        res = {"pct": None, "decision": "No evaluable", "diagnostico": f"error al ejecutar: {e}"}
    return res

def _registrar(cid, meta, res):
    filas.append({
        'Control': cid,
        'Dimensión': meta.get("dimension", ""),
        'Control Esperado': meta.get("descripcion", ""),
        '% De cumplimiento del data set': res.get("pct"),
        'Diagnóstico': str(res.get("diagnostico", ""))[:300],
        'Decisión': res.get("decision", "No evaluable"),
        'Control o Evidencia requerida': meta.get("evidencia", ""),
        'Referencia en el entregable': meta.get("referencia", ""),
    })

def _reporte_celda(cid, meta, res):
    """Imprime el bloque estándar de cada control."""
    print(f">>>> {cid}: {meta.get('descripcion','')}")
    print(f"{'Control':<10}| {'Resultado':<15}| {'% cumplimiento':<15}| Diagnóstico")
    print(f"{cid:<10}| {res.get('decision','—'):<15}| {_fmt_pct(res.get('pct')):<15}| "
          f"{str(res.get('diagnostico',''))[:100]}")
'''.strip()


def construir_notebook_repositorio(controles, meta):
    """
    Notebook cuyos controles son FUNCIONES PYTHON del repositorio (una celda por
    control: embebe su fuente, la ejecuta e imprime el cuadro estándar). Cierra
    con la tabla consolidada de 8 columnas.

    `controles`: lista de dicts de `repositorio_controles.cargar_controles`.
    """
    proyecto = str(meta.get("proyecto_dir") or Path.cwd())
    datasets_dir = str(meta.get("datasets_dir")
                       or (Path(proyecto) / "inputs" / "calidad_datos" / "datasets"))
    salida_dir = str(meta.get("salida_dir")
                     or (Path(proyecto) / "outputs"
                         / datetime.now().strftime("%Y-%m-%d") / "controles"))
    dominio = meta.get("dominio", "—")

    nb = nbf.v4.new_notebook()
    c = []

    c.append(_md(
        f"# Controles de datos — {dominio} · entregable ejecutable\n\n"
        f"**Repositorio:** `inputs/repositorio_controles/{str(dominio).lower()}/`  \n"
        f"**Controles:** {len(controles)}  ·  **Generado:** {datetime.now():%Y-%m-%d %H:%M}\n\n"
        f"> Controles ESPECIALIZADOS del dominio, embebidos como código. Edita las "
        f"**RUTAS** y los `params` de cada control si el nombre de columna difiere. "
        f"La última celda entrega el cuadro de 8 columnas."
    ))

    # RUTAS + carga de datasets
    c.append(_md("## 0. RUTAS — edita antes de ejecutar"))
    c.append(_code(
        "import sys\nfrom pathlib import Path\n"
        f"PROYECTO     = Path(r'{proyecto}')\n"
        f"DATASETS_DIR = Path(r'{datasets_dir}')\n"
        f"SALIDA_DIR   = Path(r'{salida_dir}')\n"
        "if str(PROYECTO) not in sys.path:\n    sys.path.insert(0, str(PROYECTO))\n"
        "from modulos.motores_datos import cargar_datasets\n"
        "datasets = cargar_datasets(DATASETS_DIR)\n"
        "print(f'{len(datasets)} dataset(s):', list(datasets))"
    ))

    # Utilidades del entregable
    c.append(_md("## 1. Utilidades del cuadro"))
    c.append(_code(_SETUP_REPO))

    # Una celda por control (código real embebido)
    c.append(_md("## 2. Controles del dominio"))
    for i, ctrl in enumerate(controles, start=1):
        cid = f"C{i:02d}"
        nombre = ctrl.get("nombre", cid)
        fuente = ctrl.get("fuente", "").rstrip()
        c.append(_md(f"### {cid} — `{nombre}`"))
        c.append(_code(
            f"# ═══ {cid} · {nombre} — control del repositorio ({dominio}) ═══\n"
            f"{fuente}\n\n"
            f"_res = _ejecutar(META, control, datasets)\n"
            f"_registrar({cid!r}, META, _res)\n"
            f"_reporte_celda({cid!r}, META, _res)"
        ))

    # Cuadro final
    c.append(_md("## 3. Entregable — cuadro de control (8 columnas)"))
    c.append(_code(
        "tabla_control = pd.DataFrame(filas, columns=COLS)\n"
        "pd.set_option('display.max_colwidth', 40)\n"
        "print(tabla_control.to_string(index=False))\n"
        "try:\n"
        "    display(tabla_control)   # vista rica si es Jupyter\n"
        "except NameError:\n"
        "    pass\n"
        "SALIDA_DIR.mkdir(parents=True, exist_ok=True)\n"
        "tabla_control.to_csv(SALIDA_DIR/'tabla_control_datos.csv', index=False, encoding='utf-8-sig')\n"
        "print('\\nGuardado en', SALIDA_DIR/'tabla_control_datos.csv')"
    ))

    nb["cells"] = c
    nb["metadata"] = {
        "kernelspec": {"name": "python3", "display_name": "Python 3"},
        "language_info": {"name": "python"},
        "generado_por": "virf_agent repositorio_controles",
        "dominio": dominio,
        "n_controles": len(controles),
    }
    return nb


# ── Fuente 2: el agente propone controles desde el entendimiento del modelo ──

_PROMPT_DESDE_ENTENDIMIENTO = """Eres un especialista en validación de Calidad de Datos bancaria.

No hay un documento de controles. A partir del ENTENDIMIENTO del modelo (abajo),
PROPÓN los controles de calidad de datos razonables que deberían aplicarse a sus
datasets de entrada, para que un validador los ejecute.

MOTORES DISPONIBLES (usa EXACTAMENTE uno en "tipo_motor"):
{catalogo}

Devuelve SOLO este JSON (sin markdown):
{{
  "resumen_documento": "1-2 frases: qué controles propones y por qué",
  "controles": [
    {{"id_sugerido":"C01","descripcion":"...","cita_documento":"(propuesto por el agente)",
      "tipo_motor":"unicidad|duplicados|missing|outliers|rango|integridad_referencial|tipo_dato|completitud|narrativo",
      "dataset":"","group_cols":"","campo_objetivo":"","umbral":0.0,"criticidad":"ALTA|MEDIA|BAJA","nota":"",
      "min":null,"max":null,"tipo_esperado":"","dataset_ref":"","campo_ref":"","columnas_req":"","min_filas":null}}
  ]
}}

REGLAS: propón controles PLAUSIBLES y trazables al entendimiento; marca en "nota"
cuando un parámetro (columna, umbral) deba confirmarlo el validador. No inventes
nombres de columnas si no aparecen en el entendimiento (déjalos "" con una nota).

ENTENDIMIENTO DEL MODELO:
```
{texto}
```
Devuelve SOLO el JSON."""


def generar_controles_desde_entendimiento(entendimiento: str,
                                          max_chars: int = 20000) -> Dict[str, Any]:
    """El agente propone controles cuando no hay documento. Usa el LLM."""
    from config import get_cliente_ia
    from modulos.controles_a_notebook import describir_motores
    import json, re
    prompt = _PROMPT_DESDE_ENTENDIMIENTO.format(
        catalogo=describir_motores(), texto=(entendimiento or "")[:max_chars])
    try:
        crudo = get_cliente_ia().generar_mensaje(prompt=prompt, max_tokens=6000).strip()
    except Exception as exc:
        return {"_error": str(exc), "controles": [], "resumen_documento": ""}
    crudo = re.sub(r"^\s*```(?:json)?\s*", "", crudo)
    crudo = re.sub(r"\s*```\s*$", "", crudo).strip()
    try:
        return json.loads(crudo)
    except json.JSONDecodeError:
        i = crudo.find("{")
        if i != -1:
            prof = 0
            for j in range(i, len(crudo)):
                if crudo[j] == "{":
                    prof += 1
                elif crudo[j] == "}":
                    prof -= 1
                    if prof == 0:
                        try:
                            return json.loads(crudo[i:j + 1])
                        except json.JSONDecodeError:
                            break
        return {"_error": "el LLM no devolvió JSON válido", "controles": [],
                "resumen_documento": ""}


def generar_ipynb_controles(
    ruta_documento: Optional[Path],
    entendimiento: Optional[str],
    meta: Dict[str, Any],
) -> Tuple[bytes, Dict[str, Any]]:
    """
    Orquestador. PRIORIDAD 1: repositorio de controles Python del dominio
    (`inputs/repositorio_controles/<dominio>/`) → notebook ESPECIALIZADO. Si el
    dominio no tiene controles en el repo, cae al flujo previo (documento subido
    → catálogo YAML → propuesta LLM). Devuelve (bytes del .ipynb, info).
    """
    # ── PRIORIDAD 1: repositorio de controles Python por dominio ─────────────
    # La ruta de repositorio se activa cuando el dominio tiene controles PROPIOS
    # (su carpeta), no solo los transversales de `shared/`. Si un dominio no
    # curado (p. ej. uno nuevo) solo heredaría los shared, se prefiere el flujo de
    # abajo (documento/LLM) para derivar controles a su medida — y los shared se
    # incorporan igualmente porque `cargar_controles` los añade a todos.
    try:
        from modulos.repositorio_controles import cargar_controles, carpeta_de_dominio
        repo_ctrls, repo_avisos = cargar_controles(meta.get("dominio"))
        _dc = carpeta_de_dominio(meta.get("dominio"))
        _tiene_propios = bool(_dc) and any(
            c.get("dominio_carpeta") == _dc for c in repo_ctrls)
    except Exception as exc:                          # noqa: BLE001
        repo_ctrls, repo_avisos, _tiene_propios = [], [f"repositorio no cargado: {exc}"], False

    if _tiene_propios:
        nb = construir_notebook_repositorio(repo_ctrls, meta)
        return a_ipynb_bytes(nb), {
            "n_controles": len(repo_ctrls),
            "fuente": (f"repositorio de controles Python — dominio "
                       f"{meta.get('dominio') or '—'} ({len(repo_ctrls)})"),
            "modo": "repositorio",
            "controles": [c["nombre"] for c in repo_ctrls],
            "avisos": repo_avisos,
            "error": None,
        }

    # ── Fallback: flujo anterior (documento / catálogo YAML / LLM) ───────────
    if ruta_documento and Path(ruta_documento).is_file():
        texto = leer_documento(Path(ruta_documento))
        plan = extraer_controles_del_documento(texto)
        fuente = f"documento subido: {Path(ruta_documento).name}"
    else:
        plan = generar_controles_desde_entendimiento(entendimiento or "")
        fuente = "propuesto por el agente (sin documento; desde el entendimiento del modelo)"

    controles = plan.get("controles") or []
    if not controles:
        # LLM sin resultado / sin API: notebook útil con un control-plantilla.
        controles = [{
            "descripcion": ("PLANTILLA — no se pudieron derivar controles "
                            "automáticamente. Edita este notebook: define tus "
                            "controles y sus parámetros."),
            "tipo_motor": "narrativo",
            "nota": ("Sube un manual de controles a "
                     "documentacion/controles_datos/ o edita las celdas."),
            "cita_documento": "",
        }]
        if plan.get("_error"):
            fuente += f"  [aviso: {plan['_error']}]"
    meta = {**meta, "fuente": fuente,
            "resumen": plan.get("resumen_documento", "")}
    nb = construir_notebook_8cols(controles, meta)
    return a_ipynb_bytes(nb), {
        "n_controles": len(controles),
        "fuente": fuente,
        "error": plan.get("_error"),
    }
