"""
modulos/word_estilo.py
Infraestructura de presentación del informe Word. Reutilizable: aquí vive el
CÓMO se ve el documento, no QUÉ dice. `generador_word.py` decide el contenido.

Cinco piezas, todas pedidas por el validador:

  1. Tipografía corporativa (`Flexo`), configurable y con detección declarada.
  2. Texto justificado.
  3. Bloques de código con aspecto de celda: monoespaciada, fondo, borde y
     numeración de línea.
  4. Notas al pie REALES de Word, para declarar la procedencia sin partir la
     lectura del párrafo.
  5. Portada con el logo de la entidad.

Sobre las notas al pie: `python-docx` 1.2 no las soporta. Se construye la parte
OPC `word/footnotes.xml` a mano —content-type, relación y XML—, que es lo que
Word espera encontrar. Ver `_asegurar_parte_footnotes`.
"""

from __future__ import annotations

import logging
import os
from io import BytesIO
from pathlib import Path
from typing import List, Optional

from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.opc.packuri import PackURI
from docx.opc.part import Part
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

logger = logging.getLogger(__name__)


# ═════════════════════════════════════════════════════════════════════════════
# 1. TIPOGRAFÍA
# ═════════════════════════════════════════════════════════════════════════════
#
# `Flexo` es la tipografía corporativa. NO se distribuye con el proyecto: es una
# fuente comercial con licencia, y empaquetarla aquí sería redistribuirla sin
# derecho. El documento la PIDE por nombre —que es lo que hace que se vea bien
# en cualquier equipo donde esté instalada— y si falta se declara en consola.
#
# Word no tiene listas de respaldo como CSS: sustituye por su cuenta y sin
# criterio. Por eso se escribe `w:altName` en la tabla de fuentes, que es la vía
# que sí respeta para elegir el reemplazo.

from config import WORD_FUENTE, WORD_FUENTE_MONO, WORD_FUENTE_RESPALDO

FUENTE_TEXTO = WORD_FUENTE
FUENTE_MONO = WORD_FUENTE_MONO
FUENTE_RESPALDO = WORD_FUENTE_RESPALDO

# Nombre de la familia que se pide realmente. Se resuelve una vez por proceso.
_FUENTE_EFECTIVA: Optional[str] = None


def fuentes_instaladas() -> set:
    """Familias tipográficas visibles para el sistema. Vacío si no se puede."""
    nombres = set()
    try:                                    # Windows: el registro es la verdad
        import winreg
        clave = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts")
        i = 0
        while True:
            try:
                nombre, _valor, _tipo = winreg.EnumValue(clave, i)
            except OSError:
                break
            # "Flexo Bold (TrueType)" → "flexo bold"
            nombres.add(nombre.split("(")[0].strip().lower())
            i += 1
    except Exception:
        pass
    try:                                    # multiplataforma, si hay matplotlib
        from matplotlib import font_manager
        for f in font_manager.fontManager.ttflist:
            nombres.add(f.name.lower())
    except Exception:
        pass
    return nombres


def resolver_fuente(verbose: bool = True) -> str:
    """
    Decide con qué familia se escribe el documento, y lo DECLARA.

    Se pide `Flexo`. Si no está instalada en la máquina que genera el informe no
    se sustituye a la fuerza —en el equipo del validador o del auditor puede
    estarlo, y el .docx se vería como debe—, pero se avisa: un informe que sale
    con otra letra sin decir nada es exactamente la clase de silencio que este
    proyecto evita.
    """
    global _FUENTE_EFECTIVA
    if _FUENTE_EFECTIVA is not None:
        return _FUENTE_EFECTIVA

    pedida = FUENTE_TEXTO
    instaladas = fuentes_instaladas()
    hay = any(f == pedida.lower() or f.startswith(pedida.lower() + " ")
              for f in instaladas)

    if not hay and instaladas and verbose:
        print(f"    ⚠️  Tipografía «{pedida}» no instalada en este equipo.")
        print(f"       El .docx la pide igualmente: se verá correcta en cualquier")
        print(f"       equipo que la tenga. Donde falte, Word sustituirá por")
        print(f"       «{FUENTE_RESPALDO}» (declarado en la tabla de fuentes).")
        print(f"       Para cambiarla:  set VIRF_FUENTE=<nombre exacto>")

    _FUENTE_EFECTIVA = pedida
    return pedida


def aplicar_fuente(run, nombre: Optional[str] = None) -> None:
    """
    Fija la familia en las CUATRO ranuras que usa Word.

    `run.font.name` solo escribe `w:ascii` y `w:hAnsi`. Sin `w:cs` y
    `w:eastAsia`, los símbolos del informe —flechas, semáforos, comillas
    tipográficas— caen en la fuente por defecto y el párrafo sale con dos
    letras distintas.
    """
    nombre = nombre or resolver_fuente()
    run.font.name = nombre
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for ranura in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(ranura), nombre)


def registrar_respaldo_fuente(doc) -> None:
    """
    Declara en `fontTable.xml` por qué fuente sustituir si `Flexo` no está.

    Sin esto Word elige el reemplazo por su cuenta y suele caer en una serifa
    que desmonta el diseño. Con `w:altName` la degradación es la que decidimos.
    """
    # Dos trampas encadenadas, las dos silenciosas:
    #
    #  1. La tabla de fuentes cuelga de la PARTE DOCUMENTO, no del paquete.
    #  2. python-docx la carga como `Part` GENÉRICA: guarda bytes crudos, sin
    #     XML parseado, así que no tiene `.element`. Hay que parsear el blob y
    #     devolverlo.
    #
    # Mientras esto falló, el .docx salía sin declarar nada y Word sustituía
    # Flexo por una serifa de su elección — que es justo lo que se quería
    # evitar. Verificado ahora mirando el `fontTable.xml` del fichero generado.
    try:
        tabla = doc.part.part_related_by(RT.FONT_TABLE)
    except Exception as exc:
        logger.warning("fontTable.xml no localizada (%s): Word elegirá la "
                       "sustitución tipográfica por su cuenta.", exc)
        return

    from lxml import etree
    try:
        raiz = etree.fromstring(tabla.blob)
    except Exception as exc:
        logger.warning("fontTable.xml ilegible (%s): sin respaldo declarado.", exc)
        return

    for f in raiz.findall(qn("w:font")):
        if f.get(qn("w:name")) == FUENTE_TEXTO:
            return                                   # ya declarada
    nodo = etree.SubElement(raiz, qn("w:font"))
    nodo.set(qn("w:name"), FUENTE_TEXTO)
    alt = etree.SubElement(nodo, qn("w:altName"))
    alt.set(qn("w:val"), FUENTE_RESPALDO)
    familia = etree.SubElement(nodo, qn("w:family"))
    familia.set(qn("w:val"), "swiss")
    pitch = etree.SubElement(nodo, qn("w:pitch"))
    pitch.set(qn("w:val"), "variable")

    tabla._blob = etree.tostring(raiz, xml_declaration=True,
                                 encoding="UTF-8", standalone=True)


def aplicar_estilo_documento(doc, justificar: bool = True) -> None:
    """
    Fija la tipografía y la justificación en el estilo `Normal`.

    Hacerlo en el estilo y no párrafo a párrafo importa: cualquier texto que
    algún día se añada sin pasar por los helpers hereda el aspecto correcto en
    vez de salir en Calibri y alineado a la izquierda.
    """
    fuente = resolver_fuente()
    normal = doc.styles["Normal"]
    normal.font.name = fuente
    normal.font.size = Pt(10)
    rpr = normal.element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for ranura in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(ranura), fuente)

    if justificar:
        ppr = normal.element.get_or_add_pPr()
        jc = ppr.find(qn("w:jc"))
        if jc is None:
            jc = OxmlElement("w:jc")
            ppr.append(jc)
        jc.set(qn("w:val"), "both")
        # Partición de palabras: sin ella, justificar abre "ríos" de espacio en
        # blanco en las columnas estrechas de las tablas.
        #
        # Va añadido al final de settings.xml. En rigor `CT_Settings` es una
        # secuencia ordenada y lo correcto sería insertarlo en su posición;
        # comprobado que Word lo abre igualmente (documento mínimo, Word de
        # escritorio). Si algún día un consumidor más estricto lo rechaza, esta
        # es la línea a mover, no a borrar.
        if doc.settings.element.find(qn("w:autoHyphenation")) is None:
            doc.settings.element.append(
                _nodo("w:autoHyphenation", {"w:val": "true"}))

    registrar_respaldo_fuente(doc)


def _nodo(tag: str, attrs: Optional[dict] = None):
    el = OxmlElement(tag)
    for k, v in (attrs or {}).items():
        el.set(qn(k), v)
    return el


# ═════════════════════════════════════════════════════════════════════════════
# 2. JUSTIFICACIÓN
# ═════════════════════════════════════════════════════════════════════════════

def justificar(parrafo) -> None:
    """
    Justifica un párrafo de prosa.

    NO se aplica a código, tablas de cifras ni pies de figura: justificar una
    línea de código la deformaría, y es justo lo que hay que poder leer literal.
    """
    parrafo.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY


# ═════════════════════════════════════════════════════════════════════════════
# 3. BLOQUES DE CÓDIGO
# ═════════════════════════════════════════════════════════════════════════════

COD_FONDO = "F6F8FA"       # gris muy claro, como una celda de notebook
COD_BORDE = "D0D7DE"
COD_TEXTO = RGBColor(0x24, 0x29, 0x2F)
COD_NUMERO = RGBColor(0x8C, 0x95, 0x9F)


def _sombrear(parrafo, hex_color: str) -> None:
    ppr = parrafo._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    ppr.append(shd)


def _borde(parrafo, lados: str, color: str = COD_BORDE, size: int = 6) -> None:
    """`lados`: cualquier combinación de t/b/l/r."""
    ppr = parrafo._p.get_or_add_pPr()
    bordes = ppr.find(qn("w:pBdr"))
    if bordes is None:
        bordes = OxmlElement("w:pBdr")
        ppr.append(bordes)
    mapa = {"t": "top", "b": "bottom", "l": "left", "r": "right"}
    for c in lados:
        el = OxmlElement(f"w:{mapa[c]}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(size))
        el.set(qn("w:space"), "4")
        el.set(qn("w:color"), color)
        bordes.append(el)


def add_bloque_codigo(doc, codigo: str, *, numerar: bool = True,
                      linea_inicial: int = 1, size: int = 8,
                      resaltar: Optional[List[int]] = None) -> None:
    """
    Inserta código con aspecto de celda: monoespaciado, fondo, borde y números.

    Por qué numerar: los hallazgos del juez de código salen con `fichero:línea`.
    Si el bloque del informe no lleva números, el auditor no puede saltar a la
    línea acusada y tiene que contarlas a mano.

    `resaltar` marca líneas concretas (las que motivan el hallazgo) con un
    fondo distinto, para que se vean sin leer todo el bloque.

    NUNCA se justifica ni se parte una línea: el código se cita literal o no
    sirve como evidencia.
    """
    resaltar = set(resaltar or [])
    lineas = codigo.rstrip("\n").split("\n")
    ancho = len(str(linea_inicial + len(lineas) - 1))

    for i, linea in enumerate(lineas):
        n = linea_inicial + i
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
        pf = p.paragraph_format
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
        pf.left_indent = Pt(12)
        pf.right_indent = Pt(6)
        # Interlineado exacto: si Word lo calcula, el bloque "respira" distinto
        # en cada línea y deja de parecer una celda de código.
        pf.line_spacing = Pt(size + 3)

        _sombrear(p, "FFF3C4" if n in resaltar else COD_FONDO)
        lados = ("t" if i == 0 else "") + ("b" if i == len(lineas) - 1 else "") + "lr"
        _borde(p, lados)

        if numerar:
            rn = p.add_run(str(n).rjust(ancho) + "  ")
            rn.font.size = Pt(size)
            rn.font.color.rgb = COD_NUMERO
            aplicar_fuente(rn, FUENTE_MONO)

        # Los tabuladores se expanden: Word los colapsa y descuadra la sangría,
        # que en código es información.
        rc = p.add_run(linea.replace("\t", "    ") or " ")
        rc.font.size = Pt(size)
        rc.font.color.rgb = COD_TEXTO
        aplicar_fuente(rc, FUENTE_MONO)


def add_codigo_inline(parrafo, texto: str, size: int = 8):
    """Un fragmento monoespaciado dentro de una frase, con fondo tenue."""
    r = parrafo.add_run(texto)
    r.font.size = Pt(size)
    r.font.color.rgb = COD_TEXTO
    aplicar_fuente(r, FUENTE_MONO)
    rpr = r._element.get_or_add_rPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), COD_FONDO)
    rpr.append(shd)
    return r


# ═════════════════════════════════════════════════════════════════════════════
# 4. NOTAS AL PIE REALES
# ═════════════════════════════════════════════════════════════════════════════
#
# python-docx no las implementa. Se crea la parte `word/footnotes.xml`, se
# relaciona con el documento y se insertan las referencias.
#
# Word exige dos notas especiales antes que ninguna real:
#   id=-1  separator            — la rayita sobre las notas
#   id=0   continuationSeparator — la de una nota que sigue en la página siguiente
# Sin ellas el documento abre con aviso de contenido ilegible.

CT_FOOTNOTES = ("application/vnd.openxmlformats-officedocument"
                ".wordprocessingml.footnotes+xml")
RT_FOOTNOTES = ("http://schemas.openxmlformats.org/officeDocument/2006"
                "/relationships/footnotes")

_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

_FOOTNOTES_BASE = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:footnotes xmlns:w="{_W}">
  <w:footnote w:type="separator" w:id="-1">
    <w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>
      <w:r><w:separator/></w:r></w:p>
  </w:footnote>
  <w:footnote w:type="continuationSeparator" w:id="0">
    <w:p><w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr>
      <w:r><w:continuationSeparator/></w:r></w:p>
  </w:footnote>
</w:footnotes>"""


class _FootnotesPart(Part):
    """Parte OPC mínima que envuelve el XML de notas al pie."""

    def __init__(self, partname, content_type, element, package):
        self._element = element
        super().__init__(partname, content_type, b"", package)

    @property
    def element(self):
        return self._element

    @property
    def blob(self):
        from lxml import etree
        return etree.tostring(self._element, xml_declaration=True,
                              encoding="UTF-8", standalone=True)


def _asegurar_parte_footnotes(doc):
    """Devuelve el elemento `<w:footnotes>`, creándolo la primera vez."""
    parte_doc = doc.part
    for rel in parte_doc.rels.values():
        if rel.reltype == RT_FOOTNOTES:
            return rel.target_part.element

    from lxml import etree
    element = etree.fromstring(_FOOTNOTES_BASE.encode("utf-8"))
    parte = _FootnotesPart(PackURI("/word/footnotes.xml"), CT_FOOTNOTES,
                           element, parte_doc.package)
    parte_doc.relate_to(parte, RT_FOOTNOTES)
    _asegurar_estilos_nota(doc)
    return element


def _asegurar_estilos_nota(doc) -> None:
    """Crea los estilos que Word espera para las notas, si no existen."""
    from docx.enum.style import WD_STYLE_TYPE
    estilos = doc.styles
    nombres = {s.name for s in estilos}

    if "Footnote Text" not in nombres:
        st = estilos.add_style("Footnote Text", WD_STYLE_TYPE.PARAGRAPH)
        st.font.size = Pt(8)
        st.font.name = resolver_fuente()
        st.font.color.rgb = RGBColor(0x44, 0x44, 0x44)
    if "Footnote Reference" not in nombres:
        st = estilos.add_style("Footnote Reference", WD_STYLE_TYPE.CHARACTER)
        st.font.superscript = True
        st.font.size = Pt(7)


def add_nota_pie(doc, parrafo, texto: str) -> int:
    """
    Ancla una nota al pie al final de `parrafo` y devuelve su número.

    Para qué sirve aquí: declarar la procedencia —de qué documento salió una
    cita, contra qué corpus se contrastó— sin meter la referencia en mitad de
    la frase. El párrafo se lee de corrido y el dato queda comprobable, que es
    justo lo que un auditor necesita.
    """
    raiz = _asegurar_parte_footnotes(doc)
    from lxml import etree

    usados = [int(f.get(qn("w:id"))) for f in raiz.findall(qn("w:footnote"))]
    nuevo = max([n for n in usados if n > 0] + [0]) + 1

    nota = etree.SubElement(raiz, qn("w:footnote"))
    nota.set(qn("w:id"), str(nuevo))
    p = etree.SubElement(nota, qn("w:p"))
    ppr = etree.SubElement(p, qn("w:pPr"))
    pstyle = etree.SubElement(ppr, qn("w:pStyle"))
    pstyle.set(qn("w:val"), "FootnoteText")

    # La marca numérica dentro de la propia nota.
    r_marca = etree.SubElement(p, qn("w:r"))
    rpr_m = etree.SubElement(r_marca, qn("w:rPr"))
    rstyle_m = etree.SubElement(rpr_m, qn("w:rStyle"))
    rstyle_m.set(qn("w:val"), "FootnoteReference")
    etree.SubElement(r_marca, qn("w:footnoteRef"))

    r_txt = etree.SubElement(p, qn("w:r"))
    rpr_t = etree.SubElement(r_txt, qn("w:rPr"))
    rfonts = etree.SubElement(rpr_t, qn("w:rFonts"))
    for ranura in ("w:ascii", "w:hAnsi", "w:cs"):
        rfonts.set(qn(ranura), resolver_fuente())
    sz = etree.SubElement(rpr_t, qn("w:sz"))
    sz.set(qn("w:val"), "16")                     # 8 pt = 16 medios puntos
    t = etree.SubElement(r_txt, qn("w:t"))
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    t.text = " " + texto

    # Y la referencia volada en el cuerpo del informe.
    run = parrafo.add_run()
    rpr = run._element.get_or_add_rPr()
    rstyle = OxmlElement("w:rStyle")
    rstyle.set(qn("w:val"), "FootnoteReference")
    rpr.append(rstyle)
    ref = OxmlElement("w:footnoteReference")
    ref.set(qn("w:id"), str(nuevo))
    run._element.append(ref)
    return nuevo


# ═════════════════════════════════════════════════════════════════════════════
# 5. LOGO DE LA ENTIDAD
# ═════════════════════════════════════════════════════════════════════════════

from config import WORD_DIR_LOGO

DIR_LOGO = WORD_DIR_LOGO
_EXT_LOGO = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif")

# Raíz del proyecto = padre de `modulos/`. Anclarla aquí evita que el logo
# aparezca o no según desde qué carpeta se lance el agente.
_RAIZ_PROYECTO = Path(__file__).resolve().parent.parent


def localizar_logo(raiz: Optional[Path] = None) -> Optional[Path]:
    """
    Primer fichero de imagen en `inputs/logoempresa/`. None si no hay.

    Se prueba la raíz indicada, la del proyecto y el directorio actual, en ese
    orden: el agente se lanza indistintamente desde la raíz o desde `motor/`.
    """
    candidatas = [Path(raiz) / DIR_LOGO] if raiz else []
    candidatas += [_RAIZ_PROYECTO / DIR_LOGO, Path(DIR_LOGO)]
    for base in candidatas:
        if not base.is_dir():
            continue
        for p in sorted(base.iterdir()):
            if p.suffix.lower() in _EXT_LOGO:
                return p
    return None


def logo_para_word(ruta: Path) -> Optional[BytesIO]:
    """
    Devuelve el logo en un formato que Word admita.

    Word no abre `.webp` —el fichero de la entidad lo es—, así que se convierte
    a PNG en memoria conservando la transparencia. En memoria y no en disco a
    propósito: un PNG derivado junto al original acabaría commiteado y nadie
    sabría cuál manda.
    """
    try:
        from PIL import Image
    except ImportError:
        logger.warning("Pillow no disponible: el logo no se insertará.")
        return None
    try:
        im = Image.open(ruta)
        if im.mode not in ("RGBA", "RGB"):
            im = im.convert("RGBA")
        buf = BytesIO()
        im.save(buf, format="PNG")
        buf.seek(0)
        return buf
    except Exception as exc:
        logger.warning("No se pudo preparar el logo %s: %s", ruta, exc)
        return None
