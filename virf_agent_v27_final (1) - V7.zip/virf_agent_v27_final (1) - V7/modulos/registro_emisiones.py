"""
modulos/registro_emisiones.py
═══════════════════════════════════════════════════════════════════════════════
REGISTRO APPEND-ONLY DE EMISIONES — control PREVENTIVO de la cadena de custodia.

[AUDIT-FIX PENDIENTE-1]

Qué había antes y por qué estaba mal
────────────────────────────────────
`modulos/custodia.py` implementa un control **detectivo**: `verificar_cadena()`
recalcula los hashes de los informes que encuentra en `outputs/` y detecta si
alguno fue *editado* después de emitirse.

El hueco es que **opera sobre los ficheros que existen**. Medido sobre el
proyecto real:

    $ python agente.py --verificar-cadena "LaR"      →  3 eslabones, íntegra
    $ rm -rf outputs/                                 (o Ctrl-A, Supr)
    $ python agente.py --verificar-cadena "LaR"      →  "No hay informes
                                                          para este modelo."

Es decir: borrar la evidencia no rompía nada — la hacía **desaparecer**. El
sistema no distinguía «se emitieron tres informes y alguien los borró» de
«este modelo nunca se validó», y ambos casos se presentaban al auditor con el
mismo mensaje tranquilizador. Un control de integridad que se puede desactivar
borrando su objeto no es un control de integridad.

Cómo se corrige
───────────────
Un registro **append-only fuera de `outputs/`** con una línea por emisión. El
registro es la lista de lo que DEBIÓ emitirse; `outputs/` es lo que hay. La
diferencia entre ambos es exactamente lo que antes era invisible:

    registro tiene la línea  +  el fichero está   →  PRESENTE
    registro tiene la línea  +  el fichero NO está →  AUSENTE   ← el hueco
    registro tiene la línea  +  el fichero cambió  →  ALTERADO

Por qué JSONL y no JSON
───────────────────────
Un JSON array obliga a releer, mutar y reescribir el fichero entero en cada
emisión: el propio formato exige un `open(..., "w")`, que es la operación que
un registro append-only no puede permitirse. Con una línea por emisión, añadir
es `open(..., "a")` y nada de lo ya escrito se toca. La propiedad la fijan un
test (`test_registro_nunca_abre_en_modo_escritura`) y un check de
`validate_project.py`, que comprueban por AST —no por texto, §3.8— que este
módulo no abre su registro en modo escritura.

Por qué se resuelve por HASH y no por ruta
──────────────────────────────────────────
`custodia.preservar_si_existe()` RENOMBRA el informe del día cuando se re-ejecuta
el mismo modelo la misma fecha (`resultados_X_2026-08-03.json` →
`resultados_X_2026-08-03__a1b2c3d4e5f6.json`). Una verificación que comparara
rutas reportaría AUSENTE el primer informe de cada día con dos corridas — un
falso positivo en el caso MÁS habitual del proyecto, y de la misma familia que
el falso «cadena ROTA» que documenta `custodia.informes_de_modelo()`.

Se indexa `outputs/` por hash de contenido, así que un informe archivado bajo
otro nombre se localiza igual. La ruta registrada se conserva y se reporta como
información («archivado como …»), no como criterio.

Sobre el versionado en git
──────────────────────────
`outputs/` y `audit_logs/` estaban ambos en `.gitignore`. Este fichero se
EXCEPTÚA explícitamente (ver `.gitignore`) y debe versionarse: es la prueba de
que los informes existieron, y guardarla en el mismo sitio no versionado que
aquello que vigila la haría tan borrable como su objeto. No contiene contenido
de los informes —solo hashes, nombre de modelo y firmante—, así que versionarlo
no filtra juicios de validación.
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from config.rutas import AUDIT_LOGS_DIR
# De `huella_informe` y NO de `custodia`: custodia importa este módulo para
# anotar cada emisión al sellar, así que importarla de vuelta cerraría un ciclo.
# Ver la cabecera de `modulos/huella_informe.py`.
from modulos.huella_informe import hash_contenido, slug

#: Registro por defecto. Fuera de `outputs/` a propósito: si viviera dentro,
#: el mismo `rm -rf outputs/` que borra los informes borraría la prueba de que
#: existieron, y el control volvería a ser tan frágil como el que sustituye.
RUTA_REGISTRO = Path(AUDIT_LOGS_DIR) / "registro_emisiones.jsonl"

#: Valor para las emisiones sin firmante (corridas de trabajo, pre-producción).
#: Ausencia declarada, no hueco: ver §7 del prompt de continuidad.
SIN_FIRMANTE = "(no registrado)"

_CLAVE_CUSTODIA = "custodia"


# ═════════════════════════════════════════════════════════════════════════════
# Escritura — append-only
# ═════════════════════════════════════════════════════════════════════════════

def _añadir_linea(ruta: Path, entrada: Dict) -> None:
    """
    Añade UNA línea al registro, con lock entre procesos y persistencia física.

    Se reutiliza `_lock_archivo` de `document_cache` por el mismo motivo que
    `validador_humano.registrar_validacion`: el equipo es de 2-5 personas sobre
    el mismo repositorio y dos emisiones simultáneas son normales en un cierre.

    NO se usa `_escribir_json_atomico`: ese helper escribe el fichero COMPLETO
    vía `os.replace`, que es justo lo que un registro append-only no puede
    hacer. La atomicidad aquí la dan tres cosas distintas:

      · el lock, que serializa a los escritores entre sí;
      · `O_APPEND`, que hace que el desplazamiento se calcule en el momento de
        escribir y no antes (dos escritores nunca se pisan el offset);
      · `fsync`, que garantiza que la línea está en disco antes de soltar el
        lock — sin él, un corte justo después de emitir dejaría el informe en
        `outputs/` sin su línea en el registro, que es el escenario inverso al
        que se quiere detectar y produciría un falso NO REGISTRADO.

    La línea se serializa entera en memoria y se escribe de una sola llamada:
    una escritura parcial dejaría una línea rota que `leer_registro()` tendría
    que descartar.
    """
    ruta.parent.mkdir(parents=True, exist_ok=True)
    linea = json.dumps(entrada, ensure_ascii=False, sort_keys=True,
                       default=str) + "\n"
    try:
        from modulos.document_cache import _lock_archivo
    except ImportError:                                    # pragma: no cover
        from contextlib import nullcontext

        def _lock_archivo(_p):
            return nullcontext()

    with _lock_archivo(ruta):
        # "a" y nunca "w": el invariante entero del módulo cabe en esta letra.
        with open(ruta, "a", encoding="utf-8") as f:
            f.write(linea)
            f.flush()
            os.fsync(f.fileno())


def _firmante(datos: Dict) -> Dict[str, str]:
    """
    Extrae validador y cargo del propio informe.

    Se lee del payload y no de un parámetro nuevo porque `sellar_y_escribir()`
    tiene DOS llamantes —`agente.py` (pipeline completo) y
    `motor_ia_v2.py` (corridas de trabajo con `--control`)— y añadir un
    argumento obligaría a tocar ambos. El §3.1 del prompt de continuidad
    documenta cinco defectos consecutivos con exactamente esa forma: se corrige
    un camino y se olvida el otro. Leer del payload no tiene camino que olvidar.
    """
    vh = datos.get("validacion_humana") or {}
    return {
        "validador": (vh.get("validador") or "").strip() or SIN_FIRMANTE,
        "cargo": (vh.get("cargo") or "").strip() or SIN_FIRMANTE,
    }


def registrar_emision(datos: Dict, ruta_json, modelo: str,
                      ruta_registro: Optional[Path] = None) -> Optional[Dict]:
    """
    Anota en el registro que un informe SELLADO se ha emitido.

    Se llama desde `custodia.sellar_y_escribir()`, que es el único punto por el
    que pasan todos los informes sellados del proyecto. Devuelve la entrada
    escrita, o None si el informe no traía sello (nada que registrar).

    El fallo al registrar NO puede tumbar la emisión —el informe ya está en
    disco y es la fuente de verdad—, pero tampoco puede pasar inadvertido: se
    avisa por consola, porque un informe emitido sin línea en el registro
    aparecerá después como NO REGISTRADO y alguien tendrá que explicarlo.
    """
    cust = datos.get(_CLAVE_CUSTODIA) or {}
    hash_informe = cust.get("hash_este_informe")
    if not hash_informe:
        return None

    ruta_json = Path(ruta_json)
    entrada = {
        "timestamp": cust.get("generado_utc") or (
            datetime.now(timezone.utc).isoformat(timespec="seconds")
            .replace("+00:00", "Z")),
        "modelo": modelo,
        "archivo": ruta_json.name,
        "ruta": str(ruta_json),
        "hash_informe": hash_informe,
        "hash_cadena": cust.get("hash_cadena"),
        "posicion_en_cadena": cust.get("posicion_en_cadena"),
        "tipo_corrida": cust.get("tipo_corrida"),
        **_firmante(datos),
    }
    _añadir_linea(Path(ruta_registro) if ruta_registro else RUTA_REGISTRO,
                  entrada)
    return entrada


# ═════════════════════════════════════════════════════════════════════════════
# Lectura
# ═════════════════════════════════════════════════════════════════════════════

def leer_registro(ruta_registro: Optional[Path] = None) -> List[Dict]:
    """
    Devuelve las entradas del registro, en orden de escritura.

    Una línea ilegible NO descarta el fichero: se conserva como entrada
    `_ilegible` para que la verificación la reporte. Descartarla en silencio
    convertiría una corrupción del registro en una ausencia invisible, que es
    el defecto que este módulo existe para cerrar.
    """
    ruta = Path(ruta_registro) if ruta_registro else RUTA_REGISTRO
    if not ruta.exists():
        return []
    entradas: List[Dict] = []
    try:
        texto = ruta.read_text(encoding="utf-8")
    except OSError:
        return []
    for n, linea in enumerate(texto.splitlines(), 1):
        linea = linea.strip()
        if not linea:
            continue
        try:
            d = json.loads(linea)
            if isinstance(d, dict):
                entradas.append(d)
            else:
                entradas.append({"_ilegible": True, "_linea": n})
        except json.JSONDecodeError:
            entradas.append({"_ilegible": True, "_linea": n})
    return entradas


def _indexar_outputs(outputs_dir) -> Dict[str, Path]:
    """
    Índice `hash de contenido → fichero` de todos los informes en `outputs/`.

    Se recalcula el hash del CONTENIDO en vez de leer el declarado: si alguien
    editó el informe Y su campo `hash_este_informe` para que cuadrasen entre
    sí, el contenido ya no es el que se emitió y el hash registrado —que está
    fuera de `outputs/`— no coincidirá. Ahí está el valor de guardarlo aparte.
    """
    base = Path(outputs_dir)
    idx: Dict[str, Path] = {}
    if not base.exists():
        return idx
    for f in sorted(base.rglob("resultados_*.json")):
        try:
            datos = json.loads(f.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if not isinstance(datos, dict):
            continue
        idx.setdefault(hash_contenido(datos), f)
    return idx


#: Alias local: la normalización de nombres de modelo debe ser LA MISMA que usa
#: `custodia.informes_de_modelo()`, o un modelo se filtraría en una y no en la
#: otra y las ausencias saldrían mal contadas.
_slug = slug


def verificar_emisiones(outputs_dir, modelo: Optional[str] = None,
                        ruta_registro: Optional[Path] = None) -> Dict:
    """
    Contrasta el registro de emisiones contra los informes presentes.

    Reporta cuatro estados, y el que justifica el módulo es el segundo:

      · PRESENTE      — el informe registrado está y su contenido es el emitido
      · AUSENTE       — se emitió y YA NO ESTÁ en `outputs/`
      · ALTERADO      — está en su ruta, pero su contenido no es el registrado
      · NO REGISTRADO — hay un informe en `outputs/` sin línea en el registro

    Sobre NO REGISTRADO: cuenta como aviso, no como fallo de integridad. Los
    informes emitidos antes de que existiera este registro no tienen línea y no
    se les puede exigir; marcarlos como violación llenaría de rojo la primera
    ejecución y enseñaría al equipo a ignorar el resultado. Se listan aparte
    para que el auditor los vea y decida.
    """
    entradas = [e for e in leer_registro(ruta_registro) if not e.get("_ilegible")]
    ilegibles = [e for e in leer_registro(ruta_registro) if e.get("_ilegible")]
    if modelo:
        objetivo = _slug(modelo)
        entradas = [e for e in entradas if _slug(e.get("modelo", "")) == objetivo]

    idx = _indexar_outputs(outputs_dir)
    registrados = set()

    res = {
        "modelo": modelo,
        "registro": str(Path(ruta_registro) if ruta_registro else RUTA_REGISTRO),
        "n_registradas": len(entradas),
        "integra": True,
        "emisiones": [],
        "no_registrados": [],
        "lineas_ilegibles": len(ilegibles),
    }

    for e in entradas:
        h = e.get("hash_informe")
        fila = {
            "timestamp": e.get("timestamp"),
            "modelo": e.get("modelo"),
            "archivo": e.get("archivo"),
            "validador": e.get("validador") or SIN_FIRMANTE,
            "tipo_corrida": e.get("tipo_corrida"),
            "hash": (h or "")[:16],
        }
        encontrado = idx.get(h) if h else None
        if encontrado is not None:
            registrados.add(encontrado)
            fila["estado"] = "PRESENTE"
            if encontrado.name != e.get("archivo"):
                # No es un problema: `preservar_si_existe()` archiva el informe
                # del día bajo su hash cuando se re-ejecuta. Se informa para que
                # el auditor pueda seguir el rastro del renombrado.
                fila["detalle"] = f"archivado como {encontrado.name}"
        else:
            ruta_reg = e.get("ruta")
            if ruta_reg and Path(ruta_reg).exists():
                fila["estado"] = "ALTERADO"
                fila["detalle"] = ("el fichero está en su ruta pero su contenido "
                                   "ya no es el que se emitió")
            else:
                fila["estado"] = "AUSENTE"
                fila["detalle"] = (
                    f"se emitió el {e.get('timestamp')} y ya no está en outputs/ "
                    f"({e.get('archivo')})")
            res["integra"] = False
        res["emisiones"].append(fila)

    if ilegibles:
        res["integra"] = False

    # Informes presentes sin línea en el registro.
    for h, f in idx.items():
        if f in registrados:
            continue
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if modelo and _slug(d.get("modelo", "")) != _slug(modelo):
            continue
        res["no_registrados"].append({
            "archivo": f.name,
            "modelo": d.get("modelo"),
            "hash": h[:16],
        })

    return res


# ═════════════════════════════════════════════════════════════════════════════
# Presentación en consola
# ═════════════════════════════════════════════════════════════════════════════

def imprimir_emisiones(res: Dict) -> None:
    print("\n" + "═" * 74)
    print("  📒 REGISTRO DE EMISIONES — ¿falta algún informe que se emitió?"
          + (f"\n     modelo: {res['modelo']}" if res.get("modelo") else ""))
    print("═" * 74)
    print(f"\n  Registro : {res['registro']}")
    print(f"  Emisiones registradas: {res['n_registradas']}\n")

    if not res["n_registradas"]:
        print("  No hay emisiones registradas para este criterio.")
        print("  El registro se crea al emitir el primer informe sellado.\n")
    for e in res["emisiones"]:
        icono = {"PRESENTE": "✅", "AUSENTE": "❌", "ALTERADO": "❌"}.get(
            e["estado"], "•")
        print(f"  {icono} {e['estado']:<9} {e['archivo']}")
        print(f"       emitido: {e['timestamp']}  ·  firma: {e['validador']}"
              + (f"  ·  {e['tipo_corrida']}" if e.get("tipo_corrida") else ""))
        if e.get("detalle"):
            print(f"       {e['detalle']}")

    if res["lineas_ilegibles"]:
        print(f"\n  ⚠️  {res['lineas_ilegibles']} línea(s) del registro ilegibles: "
              f"el propio registro fue manipulado o truncado.")

    if res["no_registrados"]:
        print(f"\n  ⚠️  {len(res['no_registrados'])} informe(s) en outputs/ sin "
              f"línea en el registro:")
        for n in res["no_registrados"]:
            print(f"       · {n['archivo']}  ({n['modelo']})")
        print("     Si son anteriores a la puesta en marcha del registro, es lo")
        print("     esperado. Si no, alguien escribió un informe fuera del")
        print("     pipeline y debe justificarse.")

    print("\n" + "─" * 74)
    if res["integra"]:
        print("  ✅ Todos los informes emitidos siguen presentes e intactos.")
    else:
        _aus = sum(1 for e in res["emisiones"] if e["estado"] == "AUSENTE")
        _alt = sum(1 for e in res["emisiones"] if e["estado"] == "ALTERADO")
        if _aus:
            print(f"  ❌ {_aus} informe(s) EMITIDOS Y DESAPARECIDOS de outputs/.")
            print("     Esto no es 'nunca se validó': consta que se emitieron.")
            print("     Recuperar del respaldo o justificar la baja por escrito.")
        if _alt:
            print(f"  ❌ {_alt} informe(s) presentes pero con el contenido cambiado.")
        if res["lineas_ilegibles"]:
            print("  ❌ El registro de emisiones está dañado.")
    print("═" * 74 + "\n")
