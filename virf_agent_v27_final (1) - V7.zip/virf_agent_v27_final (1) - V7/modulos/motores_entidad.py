"""
modulos/motores_entidad.py
Lectura de los resultados de los motores de calidad de datos DE LA ENTIDAD.

QUÉ ES
──────
El validador escribe sus propios motores de calidad de datos, los ejecuta **en
su máquina** y deja la tabla de resultados en

    inputs/calidad_datos/resultadocalidad_de_datos/

Este módulo la LEE. Nada más. Convierte cada fila en una evaluación del ámbito
«Calidad de datos», con su puntaje y su observación, igual que cualquier otra
actividad del estándar.

SOLO LECTURA — Y ES EL PUNTO, NO UNA LIMITACIÓN
───────────────────────────────────────────────
El agente **no ejecuta** estos motores y no debe hacerlo nunca. Es la misma
decisión que gobierna `--analizar-codigo` (§7.7 de QUE_HACE_REALMENTE.md), y
aquí pesa aún más:

  · Quien corre el motor es quien responde de él. Si lo ejecutara el agente,
    el validador estaría firmando un resultado que no produjo.
  · El código correría con los permisos del validador, en la máquina que
    guarda `audit_logs/`, `outputs/` y `feedback/`. Un motor podría alterar la
    evidencia de su propia validación.
  · Un resultado que el agente no puede reproducir por sí solo es
    precisamente lo que hay que declarar, no lo que hay que simular.

Hay un test que lo hace cumplir: falla si este módulo introduce `exec`, `eval`,
`subprocess`, `importlib` o cualquier forma de ejecutar código. Los ficheros
`.py` que haya en esa carpeta se IGNORAN: son el motor, no su resultado.

QUÉ ESPERA ENCONTRAR
────────────────────
Un DataFrame exportado a `.csv`, `.xlsx` o `.parquet`. Los nombres de columna
se reconocen con tolerancia —mayúsculas, acentos y variantes— porque exigir un
encabezado exacto convierte un cambio cosmético en un fallo:

    descripción           qué comprueba el motor
    % de incumplimiento   magnitud del fallo
    resultado             el veredicto del motor (OK / FALLA / …)
    umbral                la tolerancia declarada        ← opcional
    detalle observación   qué se observó, en prosa

`umbral` es opcional pero cambia el dictamen: un FALLA sobre **tolerancia
cero** topa el puntaje en 3 en vez de 4, porque ahí la magnitud no atenúa el
hecho de haber superado una tolerancia que la entidad fijó en ninguno. Sin esa
columna no se supone tolerancia cero —se aplica el tope general y se declara
que no consta—, porque endurecer el puntaje sobre un dato ausente acusaría al
validado por una omisión de formato.

PRECEDENCIA SOBRE LOS MOTORES INTERNOS
──────────────────────────────────────
VIRF tiene sus propios motores (`modulos/motores_datos.py`) que SÍ ejecuta
sobre `inputs/calidad_datos/datasets/`. Los dos conviven, pero **la
calificación la gobiernan los de la entidad**: cuando hay resultados propios,
los del agente pasan a ser informativos y se declaran como tales. Un auditor
tiene que poder ver quién corrió cada prueba.
"""

from __future__ import annotations

import logging
import re
import unicodedata
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

__all__ = [
    "SUBCARPETA", "leer_resultados", "evaluaciones_desde_motores_entidad",
    "puntaje_por_tasa",
]

#: Dónde vive la tabla. Relativa a `inputs/calidad_datos/`.
SUBCARPETA = "resultadocalidad_de_datos"

#: Formatos tabulares admitidos. Los `.py` NO están y no deben estarlo: en esa
#: carpeta un `.py` es el motor, y el motor no se ejecuta.
EXTENSIONES = (".csv", ".xlsx", ".xlsm", ".parquet")


# ═════════════════════════════════════════════════════════════════════════════
# NORMALIZACIÓN DE COLUMNAS
# ═════════════════════════════════════════════════════════════════════════════

def _norm(texto: Any) -> str:
    """minúsculas, sin acentos, sin signos: para comparar encabezados."""
    s = unicodedata.normalize("NFKD", str(texto or ""))
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")


#: Variantes reconocidas por campo. El primer patrón que case, gana.
_ALIAS = {
    "descripcion": ("descripcion", "descripciones", "control", "prueba",
                    "regla", "nombre", "motor", "check", "validacion"),
    "porcentaje":  ("de_incumplimiento", "incumplimiento", "pct", "porcentaje",
                    "tasa_error", "tasa", "error_rate", "ratio"),
    "resultado":   ("resultado", "estado", "veredicto", "cumple", "status",
                    "conclusion"),
    # La TOLERANCIA que declaró el validador. Va DESPUÉS de `porcentaje` a
    # propósito: aquélla ya reclamó su columna, así que «umbral» no puede
    # robársela — si se intercambiaran, la tasa medida y la tolerancia se
    # cruzarían y el puntaje saldría al revés. Es opcional.
    "umbral":      ("umbral", "tolerancia", "threshold", "limite", "limit"),
    "detalle":     ("detalle", "observacion", "observaciones", "comentario",
                    "hallazgo", "nota"),
}


def _mapear_columnas(columnas: List[str]) -> Dict[str, Optional[str]]:
    """
    Empareja los encabezados reales con los cuatro campos que se esperan.

    Se recorre por especificidad: primero coincidencia exacta del alias, luego
    que el alias esté contenido. Sin esto, «detalle_observacion» podría caer en
    `descripcion` solo porque contiene «cion».
    """
    normal = {c: _norm(c) for c in columnas}
    fuera: Dict[str, Optional[str]] = {k: None for k in _ALIAS}
    usadas = set()

    for campo, alias in _ALIAS.items():
        for exacto in (True, False):
            for col, n in normal.items():
                if col in usadas:
                    continue
                if any(n == a if exacto else a in n for a in alias):
                    fuera[campo] = col
                    usadas.add(col)
                    break
            if fuera[campo]:
                break
    return fuera


def _a_fraccion(valor: Any, escala_es_porcentaje: bool) -> Optional[float]:
    """
    Convierte «12,5 %», «12.5» o 0.125 a fracción 0-1. None si no es un número.

    La ambigüedad real: ¿0.5 es «medio por ciento» o «la mitad»? No se adivina
    fila a fila — se decide por COLUMNA en `_escala_de_la_columna`, mirando el
    máximo, y la decisión se declara en el informe.
    """
    if valor is None:
        return None
    s = str(valor).strip().replace("%", "").replace(",", ".")
    if not s or s.lower() in ("nan", "none", "-", "n/a", "na"):
        return None
    try:
        n = float(s)
    except ValueError:
        return None
    if n < 0:
        return None
    return n / 100.0 if escala_es_porcentaje else n


def _numero(valor: Any) -> Optional[float]:
    """Un número o None. Tolera «0,05», «5 %» y celdas vacías."""
    if valor is None:
        return None
    s = str(valor).strip().replace("%", "").replace(",", ".")
    if not s or s.lower() in ("nan", "none", "-", "n/a", "na"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def _escala_de_la_columna(nombre: str, valores: List[Any]) -> bool:
    """
    ¿La columna viene en porcentaje (0-100) o en fracción (0-1)?

    True = porcentaje.

    La ambigüedad es real y cara: leer «0.32» como 32 % en vez de 0,32 %
    multiplica el incumplimiento por cien y puede tumbar un dictamen. Por eso
    NO se adivina mientras haya información:

      1. **El encabezado manda.** Si dice «%» o «porcentaje», son porcentajes;
         si dice «tasa», «ratio» o «fracción», son fracciones. Es el dato que
         el propio validador escribió, y vale más que cualquier heurística.
      2. Solo si el nombre no aclara nada se mira el MÁXIMO de la columna —por
         columna, nunca por celda, o el mismo control tendría dos escalas—: un
         valor > 1 solo puede ser un porcentaje.
      3. Si tampoco eso decide (todo ≤ 1 y nombre mudo), se asume FRACCIÓN, que
         es la lectura que NO exagera el incumplimiento. Inventar un 32 % donde
         hay un 0,32 % acusaría al validado de algo que no consta.

    En los casos 2 y 3 la decisión se declara en el informe.
    """
    n = _norm(nombre)
    if "porcentaje" in n or "pct" in n or "%" in str(nombre):
        return True
    if "tasa" in n or "ratio" in n or "fraccion" in n:
        return False

    nums = []
    for v in valores:
        s = str(v).strip().replace("%", "").replace(",", ".")
        try:
            nums.append(float(s))
        except (ValueError, TypeError):
            continue
    return bool(nums) and max(nums) > 1.0


# ═════════════════════════════════════════════════════════════════════════════
# LECTURA
# ═════════════════════════════════════════════════════════════════════════════

def _carpeta(raiz_inputs: Path) -> Path:
    return Path(raiz_inputs) / "calidad_datos" / SUBCARPETA


def _leer_tabla(ruta: Path) -> List[Dict[str, Any]]:
    """Lee un fichero tabular a lista de dicts. `[]` si no se puede."""
    try:
        import pandas as pd
    except ImportError:
        logger.warning("pandas no disponible: no se leen los motores de la "
                       "entidad.")
        return []
    try:
        if ruta.suffix.lower() == ".csv":
            df = pd.read_csv(ruta, sep=None, engine="python")
        elif ruta.suffix.lower() == ".parquet":
            df = pd.read_parquet(ruta)
        else:
            df = pd.read_excel(ruta)
    except Exception as exc:
        logger.warning("no se pudo leer %s: %s", ruta.name, exc)
        return []
    return df.to_dict("records")


def leer_resultados(raiz_inputs: Path) -> Dict[str, Any]:
    """
    Lee todas las tablas de la carpeta. NUNCA lanza y NUNCA ejecuta nada.

    Devuelve `{"filas": [...], "ficheros": [...], "avisos": [...]}`. Una
    carpeta ausente no es un error: significa que la entidad no aporta motores
    propios, y eso se declara, no se rellena.
    """
    carpeta = _carpeta(raiz_inputs)
    salida: Dict[str, Any] = {"filas": [], "ficheros": [], "avisos": [],
                              "carpeta": str(carpeta)}
    if not carpeta.is_dir():
        return salida

    for ruta in sorted(carpeta.iterdir()):
        if not ruta.is_file():
            continue
        if ruta.suffix.lower() not in EXTENSIONES:
            # Un `.py` aquí es el MOTOR, no su resultado. Se ignora a
            # propósito y se dice, para que nadie crea que se ejecutó.
            if ruta.suffix.lower() == ".py":
                salida["avisos"].append(
                    f"{ruta.name}: es código, no un resultado. NO se ejecuta "
                    f"ni se lee; el agente solo consume tablas.")
            continue

        registros = _leer_tabla(ruta)
        if not registros:
            salida["avisos"].append(f"{ruta.name}: sin filas legibles.")
            continue

        cols = list(registros[0].keys())
        mapa = _mapear_columnas(cols)
        if not mapa["descripcion"] and not mapa["detalle"]:
            salida["avisos"].append(
                f"{ruta.name}: no se reconoce ninguna columna de descripción "
                f"ni de observación (encabezados: {', '.join(map(str, cols))[:120]}). "
                f"Se omite: sin saber qué comprueba cada fila, no se puede "
                f"evaluar.")
            continue
        if not mapa["porcentaje"] and not mapa["resultado"]:
            salida["avisos"].append(
                f"{ruta.name}: sin columna de % de incumplimiento ni de "
                f"resultado. Las filas se leerán SIN puntaje.")

        col_pct = mapa["porcentaje"]
        es_pct = (_escala_de_la_columna(col_pct, [r.get(col_pct) for r in registros])
                  if col_pct else True)

        for i, reg in enumerate(registros, 1):
            salida["filas"].append({
                "fichero":     ruta.name,
                "fila":        i,
                "descripcion": str(reg.get(mapa["descripcion"]) or "").strip(),
                "resultado":   str(reg.get(mapa["resultado"]) or "").strip(),
                "detalle":     str(reg.get(mapa["detalle"]) or "").strip(),
                "tasa":        _a_fraccion(reg.get(col_pct), es_pct) if col_pct else None,
                "escala_porcentaje": es_pct,
                # CRUDO, sin convertir de escala: solo interesa distinguir el 0
                # —tolerancia cero— del resto, y una conversión mal aplicada
                # convertiría un 0,05 en un 0.
                "umbral":      _numero(reg.get(mapa["umbral"])) if mapa["umbral"] else None,
            })
        salida["ficheros"].append({
            "nombre": ruta.name, "filas": len(registros),
            "columnas": mapa, "escala_porcentaje": es_pct,
        })
    return salida


# ═════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN
# ═════════════════════════════════════════════════════════════════════════════

#: Veredictos que el motor puede escribir en la columna `resultado`.
_OK = {"ok", "cumple", "conforme", "pass", "passed", "aprobado", "si", "true",
       "sin_hallazgos", "sin hallazgos", "correcto"}
#: A partir de esta tasa, declarar CUMPLIMIENTO exige justificación. Es el
#: mismo 10 % que ya separa «no cumple» (1) de «observaciones críticas» (2) en
#: `puntaje_por_tasa`: se reutiliza el corte del proyecto, no se inventa otro.
_TASA_INCOHERENTE = 0.10

_FALLA = {"falla", "no cumple", "no_cumple", "incumple", "fail", "failed",
          "error", "ko", "rechazado", "no", "false", "critico", "alerta"}


def puntaje_por_tasa(tasa: Optional[float]) -> Optional[int]:
    """
    Traduce una tasa de incumplimiento (0-1) al puntaje 1-5 del estándar.

    Es la calibración que YA usaba el proyecto para los controles de calidad de
    datos —introducida como [D7-FIX]— y se recupera aquí en vez de inventar una
    escala nueva:

        0 %          → 5   cumple plenamente
        < 0,5 %      → 4   observaciones menores
        < 2 %        → 3   cumple parcialmente
        < 10 %       → 2   observaciones críticas
        ≥ 10 %       → 1   no cumple

    `None` si no hay tasa: no se inventa un puntaje.
    """
    if tasa is None:
        return None
    if tasa <= 0:
        return 5
    if tasa < 0.005:
        return 4
    if tasa < 0.02:
        return 3
    if tasa < 0.10:
        return 2
    return 1


def _veredicto(texto: str) -> Optional[bool]:
    """True = OK, False = falla, None = no se reconoce."""
    n = _norm(texto).replace("_", " ")
    if not n:
        return None
    if n in {_norm(x).replace("_", " ") for x in _OK}:
        return True
    if n in {_norm(x).replace("_", " ") for x in _FALLA}:
        return False
    return None


def evaluaciones_desde_motores_entidad(raiz_inputs: Path) -> List[Dict]:
    """
    Convierte la tabla de la entidad en evaluaciones del ámbito Calidad de datos.

    Cada fila es una actividad con su puntaje. Reglas, en este orden:

      1. Si hay tasa de incumplimiento, manda la tasa: es el dato medido.
      2. Si no hay tasa pero sí veredicto, se usa el veredicto — 5 si cumple,
         y si falla queda SIN puntaje, porque «falla» no dice cuánto y
         asignarle un 1 sería inventarse la severidad.
      3. Sin ninguno de los dos, la fila entra como observación sin puntaje.

    El puntaje del validado nunca se rellena por defecto: es el invariante §3.2.
    """
    datos = leer_resultados(raiz_inputs)
    evals: List[Dict] = []

    for f in datos["filas"]:
        desc = f["descripcion"] or f["detalle"][:80] or f"{f['fichero']}:{f['fila']}"
        ok = _veredicto(f["resultado"])
        tasa = f["tasa"]
        umbral = f.get("umbral")

        if tasa is not None:
            puntaje = puntaje_por_tasa(tasa)
            motivo = f"{tasa * 100:.2f} % de incumplimiento medido por el motor."

            # El VEREDICTO de la entidad manda sobre la tasa cuando se
            # contradicen, porque la calificación la gobiernan sus controles y
            # su motor puede estar viendo algo que el porcentaje no resume.
            #
            # Un motor que concluye FALLA no puede acabar en «5 — cumple
            # plenamente» solo porque su tasa sea baja: eso sería el agente
            # sobrescribiendo el juicio de quien corrió la prueba.
            if ok is False and puntaje == 5:
                puntaje = None
                motivo += (" El motor concluye INCUMPLIMIENTO pese a medir "
                           "0 %: la tasa no explica el fallo, así que no se "
                           "asigna puntaje en vez de contradecir al motor.")
            elif ok is False and puntaje is not None:
                # Tope según la TOLERANCIA que declaró el validador.
                # Política confirmada el 2026-08-08.
                #
                # Un incumplimiento sobre tolerancia CERO no admite el mismo
                # tratamiento que uno sobre un umbral holgado: la entidad
                # decidió que ahí no cabe ni un caso, así que la magnitud no
                # atenúa el hecho de haberla superado. Medido sobre los datos
                # reales: cuatro controles en FALLA con tasas de 0,08-0,5 %
                # puntuaban 4 y el ámbito salía en 4,38; con el tope, 3,88.
                #
                # Sin columna de umbral el tope se queda en 4 y se declara: NO
                # se supone tolerancia cero, porque endurecer el puntaje sobre
                # un dato que no consta acusaría al validado por una omisión
                # de formato.
                if umbral is not None and umbral == 0:
                    tope, nota_tope = 3, (
                        " Tolerancia CERO declarada: el tope del puntaje baja "
                        "a 3 — sobre tolerancia cero, la magnitud no atenúa "
                        "haberla superado.")
                elif umbral is None:
                    tope, nota_tope = 4, (
                        " La tabla no declara el umbral, así que no consta si "
                        "la tolerancia era cero: se aplica el tope general "
                        "de 4. Añade una columna «Umbral» para afinarlo.")
                else:
                    tope, nota_tope = 4, ""
                if puntaje > tope:
                    puntaje = tope
                motivo += nota_tope
        elif ok is True:
            puntaje, motivo = 5, "El motor reporta cumplimiento."
        elif ok is False:
            puntaje = None
            motivo = ("El motor reporta incumplimiento pero no cuantifica su "
                      "magnitud: no se asigna puntaje para no inventar la "
                      "severidad.")
        else:
            puntaje = None
            motivo = ("Sin porcentaje de incumplimiento ni veredicto "
                      "reconocible: se registra como observación.")

        # Coherencia entre lo medido y lo dictaminado. Solo se avisa del caso
        # ESTRIDENTE: conformidad declarada sobre un incumplimiento masivo.
        #
        # No se avisa de que una tasa pequeña salga OK —un 0,32 % con un umbral
        # interno del 0,5 % es exactamente lo correcto— porque entonces el aviso
        # saltaría en casi todas las filas y el equipo dejaría de leerlo. El
        # umbral de la entidad es suyo y el agente no lo conoce; lo único que
        # no admite explicación razonable es dar por conforme un 10 % o más.
        discrepancia = ""
        if tasa is not None and ok is True and tasa >= _TASA_INCOHERENTE:
            discrepancia = (f" ⚠️ El motor concluye CUMPLIMIENTO con un "
                            f"{tasa * 100:.1f} % de incumplimiento medido. "
                            f"Verificar qué umbral se aplicó: con esa magnitud "
                            f"la conformidad requiere justificación explícita.")

        observacion = " ".join(x for x in (f["detalle"], motivo, discrepancia) if x)

        ev = {
            "puntaje":              puntaje,
            "concepto":             desc,
            "observacion":          observacion,
            "evidencia_encontrada": "",
            "preguntas_pendientes": [],
            "recomendacion":        "",
            "actividad":            f"[Motor de la entidad] {desc[:90]}",
            "control":              "Motores de calidad de datos de la entidad",
            # Procedencia: la ejecutó el VALIDADOR, no el agente. Es lo que un
            # auditor necesita para juzgar la independencia del resultado.
            "ejecutado_por":        "validador",
            "origen_motor":         f["fichero"],
            "tasa_incumplimiento":  tasa,
            "resultado_motor":      f["resultado"] or None,
            "umbral_declarado":     umbral,
        }
        if puntaje is None:
            ev["evaluacion_valida"] = False
            ev["error_evaluacion"] = motivo
        evals.append(ev)

    return evals
