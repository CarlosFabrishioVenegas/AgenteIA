"""
modulos/feedback_mejorado.py
════════════════════════════════════════════════════════════════════════════════

Sistema de feedback mejorado que REAPRENDE del usuario:
  • Detecta patrones de error (sobrestima vs subestima)
  • Ajusta prompts dinámicamente
  • Calibra scores basado en feedback acumulado
  • Aprende qué criterios buscar en cada ámbito

════════════════════════════════════════════════════════════════════════════════
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from statistics import mean, stdev

def cargar_historial() -> List[Dict]:
    """
    Carga el historial de feedback delegando en `modulos.feedback`.

    [AUDIT-FIX] Aquí había una SEGUNDA implementación, con su propio
    FEEDBACK_PATH, y no era equivalente: devolvía `[]` EN SILENCIO ante un JSON
    corrupto. Ese es precisamente el defecto que se corrigió en
    `feedback.cargar_historial()`, que respalda el fichero dañado como
    `.corrupto-<ts>.json` y avisa por consola. El arreglo se aplicó a una copia
    y no a la otra.

    Y la copia sin arreglar era la peligrosa: de ella comen
    `analizar_patron_errores()` y `ajustar_puntaje_por_feedback()`, es decir las
    funciones que MODIFICAN puntajes. Un historial corrupto se leía como vacío,
    el ajuste anti-sesgo se desactivaba sin avisar y meses de calibración
    humana dejaban de influir en el dictamen en silencio.

    Import diferido para no crear un ciclo entre los dos módulos de feedback.
    """
    from modulos.feedback import cargar_historial as _cargar
    return _cargar()


def analizar_patron_errores(ambito: str) -> Dict:
    """
    Analiza patrones de error del agente en un ámbito específico.
    
    Returns:
        {
            "tendencia": "sobrestima" | "subestima" | "equilibrado",
            "error_promedio": float,  # MAE (Mean Absolute Error)
            "severidad": "alta" | "media" | "baja",
            "ejemplos": [{"actividad": str, "error": int, "feedback": str}],
            "criterios_aprendidos": [str],  # Qué debe buscar
        }
    """
    historial = cargar_historial()
    
    # Filtrar feedback del ámbito
    feedback_ambito = [fb for fb in historial 
                      if fb.get("ambito", "").lower() == ambito.lower()]
    
    if not feedback_ambito:
        return {
            "tendencia": "equilibrado",
            "error_promedio": 0,
            "severidad": "baja",
            "ejemplos": [],
            "criterios_aprendidos": [],
        }
    
    # Calcular errores (positivo = subestima, negativo = sobrestima)
    errores = [fb.get("diferencia", 0) for fb in feedback_ambito]
    error_promedio = mean(errores) if errores else 0
    error_abs_promedio = mean([abs(e) for e in errores])
    
    # Detectar tendencia
    if error_promedio > 1:
        tendencia = "subestima"  # Agente da puntajes bajos
    elif error_promedio < -1:
        tendencia = "sobrestima"  # Agente da puntajes altos
    else:
        tendencia = "equilibrado"
    
    # Severidad
    if error_abs_promedio > 2:
        severidad = "alta"
    elif error_abs_promedio > 1:
        severidad = "media"
    else:
        severidad = "baja"
    
    # Extraer criterios de los comentarios
    criterios = []
    for fb in feedback_ambito[-10:]:  # Últimos 10
        comentario = fb.get("comentario", "").lower()
        if comentario:
            # Buscar patrones comunes (QUÉ ve el usuario que el agente no ve)
            palabras_clave = [
                "bien", "excelente", "bueno",  # Calidad
                "existe", "tiene", "documentado",  # Existencia
                "coherente", "consistente",  # Coherencia
                "alineado", "cumple",  # Cumplimiento
                "automatizado", "implementado",  # Implementación
            ]
            for palabra in palabras_clave:
                if palabra in comentario and palabra not in criterios:
                    criterios.append(palabra)
    
    # Ejemplos de error
    ejemplos = sorted(
        [
            {
                "actividad": fb.get("actividad", "")[:60],
                "error": fb.get("diferencia", 0),
                "feedback": fb.get("comentario", "")[:80],
            }
            for fb in feedback_ambito
        ],
        key=lambda x: abs(x["error"]),
        reverse=True
    )[:3]  # Top 3 errores
    
    return {
        "tendencia": tendencia,
        "error_promedio": round(error_promedio, 2),
        "error_abs_promedio": round(error_abs_promedio, 2),
        "severidad": severidad,
        "ejemplos": ejemplos,
        "criterios_aprendidos": criterios[:5],  # Top 5 criterios
    }


def construir_bloque_aprendizaje(ambito: str) -> str:
    """
    Construye un bloque de instrucción dinámico basado en errores anteriores.
    
    Este bloque se INSERTA EN EL PROMPT para que el agente se corrija.
    """
    patron = analizar_patron_errores(ambito)
    
    if patron["severidad"] == "baja":
        return ""  # Sin necesidad de corrección
    
    lineas = [""]
    lineas.append("⚠️  ADVERTENCIA POR APRENDIZAJE PREVIO:")
    
    # Advertencia según tendencia
    if patron["tendencia"] == "subestima":
        lineas.append(
            f"  En evaluaciones anteriores, tendiste a SUBESTIMAR este ámbito en "
            f"promedio {abs(patron['error_promedio'])} punto(s)."
        )
        lineas.append(
            "  SÉ MÁS GENEROSO en tu evaluación. Busca reconocer cuando sí se cumple"
        )
        lineas.append("  los requisitos, aunque sea parcialmente.")
    
    elif patron["tendencia"] == "sobrestima":
        lineas.append(
            f"  En evaluaciones anteriores, tendiste a SOBRESTIMAR este ámbito en "
            f"promedio {abs(patron['error_promedio'])} punto(s)."
        )
        lineas.append(
            "  SÉ MÁS CRÍTICO en tu evaluación. Verifica que realmente se cumplan"
        )
        lineas.append("  todos los requisitos, no solo parcialmente.")
    
    # Criterios aprendidos
    if patron["criterios_aprendidos"]:
        lineas.append(
            f"\n  Criterios clave a buscar: {', '.join(patron['criterios_aprendidos'])}"
        )
    
    # Ejemplos de error
    if patron["ejemplos"]:
        lineas.append("\n  Ejemplos previos de corrección:")
        for ej in patron["ejemplos"]:
            signo = "+" if ej["error"] > 0 else ""
            lineas.append(
                f"    • '{ej['actividad']}' (error: {signo}{ej['error']}) → {ej['feedback']}"
            )
    
    lineas.append("")
    return "\n".join(lineas)


def ajustar_puntaje_por_feedback(
    ambito: str,
    actividad: str,
    puntaje_inicial: float,
) -> Tuple[float, str]:
    """
    Ajusta el puntaje basado en feedback histórico similar.

    [FIX-BIAS] Añade guardia de mínimo de muestras (n≥3) antes de aplicar
    ajuste, evitando overfitting a 1-2 casos. El ajuste es conservador (×0.4)
    y está limitado a ±1 punto para no distorsionar el score original.
    
    Retorna:
        (puntaje_ajustado, explicacion)
    """
    historial = cargar_historial()
    
    # Buscar feedback similar en el mismo ámbito
    feedback_similar = [
        fb for fb in historial
        if (fb.get("ambito", "").lower() == ambito.lower() and
            actividad.lower()[:30] in fb.get("actividad", "").lower())
    ]
    
    if not feedback_similar:
        return puntaje_inicial, "Sin feedback previo similar"

    # [AUDIT-FIX] El umbral era `MIN_MUESTRAS = 3` HARDCODEADO aquí, mientras
    # el bloque anti-sesgo del prompt usaba VIRF_MIN_FEEDBACK_ANTISESGO (15).
    # Dos guardias descoordinadas, y la más débil gobernaba la intervención más
    # directa: medido, 3 muestras con diferencia +2 subían un puntaje de 2.0 a
    # 2.8 → round → 3. Un punto entero sobre una escala de 5, y el knob
    # documentado no lo controlaba.
    from config.parametros import MIN_MUESTRAS_AJUSTE as MIN_MUESTRAS
    if len(feedback_similar) < MIN_MUESTRAS:
        return puntaje_inicial, f"Feedback insuficiente ({len(feedback_similar)}/{MIN_MUESTRAS} muestras mínimas)"
    
    # Calcular ajuste promedio — conservador (×0.4) y acotado (±1 punto)
    ajustes = [fb.get("diferencia", 0) for fb in feedback_similar]
    ajuste_promedio = mean(ajustes)
    ajuste_aplicado = max(-1.0, min(1.0, ajuste_promedio * 0.4))  # [FIX-BIAS] cota ±1
    
    puntaje_ajustado = max(1, min(5, puntaje_inicial + ajuste_aplicado))
    
    explicacion = (
        f"Ajustado por {len(feedback_similar)} muestras de feedback: "
        f"{puntaje_inicial:.1f} → {puntaje_ajustado:.1f} "
        f"(ajuste={ajuste_aplicado:+.2f} sobre MAE={ajuste_promedio:+.2f})"
    )
    
    return puntaje_ajustado, explicacion


def obtener_recomendaciones_evaluacion(ambito: str) -> str:
    """
    Retorna recomendaciones específicas basadas en errores previos.
    """
    patron = analizar_patron_errores(ambito)
    
    recomendaciones = []
    
    if patron["tendencia"] == "subestima":
        recomendaciones = [
            "✓ Reconoce implementaciones parciales como válidas (no exijas perfección)",
            "✓ Si hay evidencia de buena fe o esfuerzo, dale puntos",
            "✓ Busca lo POSITIVO, no solo lo que falta",
        ]
    elif patron["tendencia"] == "sobrestima":
        recomendaciones = [
            "✓ Verifica COMPLETAMENTE antes de dar puntaje alto",
            "✓ Busca omisiones o deficiencias",
            "✓ Sé más exigente en criterios",
        ]
    else:
        recomendaciones = [
            "✓ Mantén criterios consistentes",
            "✓ Busca equilibrio entre ser justo y exigente",
        ]
    
    return "\n".join([f"  {rec}" for rec in recomendaciones])


def generar_resumen_aprendizaje() -> str:
    """
    Genera un resumen de qué ha aprendido el sistema del feedback.
    """
    historial = cargar_historial()
    
    if not historial:
        return "Sin feedback registrado aún"
    
    # Agrupar por ámbito
    por_ambito = {}
    for fb in historial:
        amb = fb.get("ambito", "Sin ámbito")
        if amb not in por_ambito:
            por_ambito[amb] = []
        por_ambito[amb].append(fb)
    
    lineas = ["📊 RESUMEN DE APRENDIZAJE DEL AGENTE\n"]
    
    for ambito, feedbacks in por_ambito.items():
        patron = analizar_patron_errores(ambito)
        
        lineas.append(f"[{ambito}]")
        lineas.append(f"  Feedback registrado: {len(feedbacks)}")
        lineas.append(f"  Tendencia: {patron['tendencia'].upper()}")
        lineas.append(f"  Error promedio: {patron['error_promedio']:+.2f} puntos")
        
        if patron["criterios_aprendidos"]:
            lineas.append(f"  Criterios clave: {', '.join(patron['criterios_aprendidos'])}")
        
        lineas.append("")
    
    return "\n".join(lineas)


def registrar_feedback_mejorado(
    ambito: str,
    actividad: str,
    puntaje_agente: int,
    puntaje_correcto: int,
    comentario: str,
    titulo_modelo: str,
    tier: str,
    validador: "Optional[str]" = None,
    cargo: "Optional[str]" = None,
) -> bool:
    """
    Registra feedback Y lo analiza para extraer lecciones.
    """
    historial = cargar_historial()

    # ── [AUDIT-FIX PENDIENTE-2] Autoría de la corrección ─────────────────────
    # CUARTA vez que este módulo es la rama olvidada de un arreglo aplicado a
    # medias: lectura del historial, escritura del historial, y ahora la
    # autoría. El §3.1 del prompt de continuidad lista las tres anteriores.
    #
    # Por eso NO se duplica la lógica: se importa el mismo helper que usa
    # `feedback.py`. Una segunda implementación de «quién firma» podría divergir
    # —distinto orden de precedencia, distinto valor de relleno— y el historial
    # acabaría con dos convenciones de autor que `calidad_proceso()` contaría
    # como personas distintas.
    from modulos.feedback import identidad_para_feedback as _identidad_fb
    _ident = _identidad_fb(validador, cargo)

    entrada = {
        "fecha": datetime.now().strftime("%d/%m/%Y %H:%M"),
        "titulo_modelo": titulo_modelo,
        "tier": tier,
        "ambito": ambito,
        "actividad": actividad,
        "puntaje_agente": puntaje_agente,
        "puntaje_correcto": puntaje_correcto,
        "diferencia": puntaje_correcto - puntaje_agente,
        "comentario": comentario,
        "validador": _ident["validador"],
        "cargo": _ident["cargo"],
    }
    
    historial.append(entrada)

    # ── [AUDIT-FIX] Guardar delegando en feedback.guardar_historial() ────────
    # Aquí había una escritura propia: `open(FEEDBACK_PATH, "w")` + json.dump.
    # Tercera instancia del mismo arreglo aplicado a medias. Esa escritura NO
    # tenía ninguna de las tres garantías que sí tiene `feedback`:
    #
    #   · sin LOCK entre procesos → dos validadores del equipo escribiendo a la
    #     vez se pisan; medido en el módulo original: 77 % de pérdida.
    #   · sin escritura ATÓMICA  → un Ctrl-C a mitad deja el JSON truncado y el
    #     historial entero se pierde en el siguiente arranque.
    #   · sin FUSIÓN con el disco → sobrescribe lo que otro proceso añadió.
    #
    # Y el `"w"` es lo más grave: truncaba el fichero de inmediato, de modo que
    # esta ruta podía destruir meses de calibración humana registrada por otros.
    from modulos.feedback import guardar_historial as _guardar
    _guardar(historial)
    
    # Analizar patrón
    patron = analizar_patron_errores(ambito)
    
    # Mostrar insight
    print(f"\n  📚 Insight: {patron['tendencia'].upper()}")
    if patron['criterios_aprendidos']:
        print(f"  Criterios: {', '.join(patron['criterios_aprendidos'])}")
    
    return True
