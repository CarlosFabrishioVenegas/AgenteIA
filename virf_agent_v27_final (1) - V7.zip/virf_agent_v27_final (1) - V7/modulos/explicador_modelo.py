"""
explicador_modelo.py  [v27.2]
═════════════════════════════════════════════════════════════════════════════
Genera `explicacion_del_modelo_<MODELO>.md`: un documento que permite a un
lector —humano o a otro modelo de IA— entender un modelo cuantitativo de
riesgo SIN leer el código fuente.

QUÉ RESUELVE
------------
La explicación de un modelo vive repartida en cuatro sitios que nadie lee
juntos: el manual metodológico, el informe de seguimiento, la documentación de
implementación y el perfil/controles de datos. Este servicio los consolida en
un único documento con estructura fija de 9 secciones.

Está pensado como FLUJO AUTOMÁTICO REUTILIZABLE: no sabe nada de LaR ni de
ningún modelo concreto. Recibe un nombre de modelo, localiza su evidencia en
las cuatro fuentes y produce el documento. Para documentar otro modelo basta
con dejar su evidencia en `inputs/` y ejecutar el mismo comando con otro
nombre.

CÓMO EVITA INVENTAR
-------------------
Un documento de este tipo es peligroso si rellena huecos: parece riguroso y no
lo es. Tres defensas:

  1. INVENTARIO PREVIO. Antes de llamar al modelo se construye un inventario
     de qué fuente aportó qué ficheros. El inventario se escribe DENTRO del
     documento, así que el lector siempre sabe sobre qué evidencia se apoya.
  2. FUENTES VACÍAS EXPLÍCITAS. Si una de las cuatro fuentes no aporta nada,
     no se disimula: se marca en el inventario y el prompt obliga a declarar
     "⚠️ Sin evidencia en fuentes" en las secciones afectadas.
  3. DISCREPANCIAS SIN RECONCILIAR. Si el manual dice una cosa y la
     implementación otra, el prompt exige señalarlo en vez de elegir una.

COSTE
-----
Reutiliza `ChunkerService` con su caché de resúmenes, así que un manual largo
se resume una vez y las regeneraciones posteriores del documento no vuelven a
pagarlo. `--dry-run` produce el inventario y la estimación de coste sin gastar
un solo token.
"""

from __future__ import annotations

import datetime as _dt
import logging
import re
from pathlib import Path
from typing import Dict, List, Optional, Sequence

logger = logging.getLogger("virf.explicador")

__all__ = ["ExplicadorModelo", "FUENTES"]


# ── Las cuatro fuentes, con el papel que juega cada una ───────────────────────
# El orden importa: es el orden en que se presentan al modelo y refleja la
# secuencia natural (qué hace → cómo se vigila → cómo se ejecuta → con qué datos).
FUENTES: Dict[str, Dict[str, str]] = {
    "metodologia": {
        "ruta": "inputs/documentacion/modelamiento",
        "titulo": "Manual metodológico",
        "aporta": "problema que resuelve, supuestos, fórmulas, marco teórico y "
                  "referencias normativas",
    },
    "seguimiento": {
        "ruta": "inputs/documentacion/seguimiento",
        "titulo": "Manual e informes de seguimiento",
        "aporta": "backtesting, tests estadísticos, umbrales de alerta, "
                  "periodicidad de revisión y escalamiento",
    },
    "implementacion": {
        "ruta": "inputs/implementacion",
        "titulo": "Implementación",
        "aporta": "código o arquitectura real: funciones, stack, orquestación "
                  "y controles de ejecución",
    },
    "calidad_datos": {
        "ruta": "inputs/calidad_datos",
        "titulo": "Motor de datos y controles de calidad",
        "aporta": "fuentes de datos, controles que se ejecutan, tolerancias y "
                  "transformaciones previas al modelo",
    },
}


# ── Catálogo de supuestos a vigilar ──────────────────────────────────────────
#
# POR QUÉ EXISTE
# --------------
# Antes de este catálogo, la única instrucción sobre supuestos frágiles era una
# línea del prompt ("marca lo que te parezca cuestionable"). Funcionaba con LaR
# porque su manual declara sus propios supuestos (normalidad, correlación=1),
# así que al modelo le bastaba con leerlos. Pero eso no es cobertura: es suerte.
# En un scorecard nadie escribe "asumo estabilidad poblacional" — el supuesto es
# tácito, y lo que no está escrito no se detecta improvisando.
#
# CÓMO ES AGNÓSTICO AL MODELO
# ---------------------------
# El catálogo NO clasifica el modelo ni decide su familia con heurísticas de
# palabras clave (eso fallaría con un híbrido, o con un manual que no use el
# vocabulario esperado). Se entrega ENTERO al modelo junto con la evidencia, y
# se le exige aplicar solo las familias cuyo disparador esté realmente presente
# y callar sobre las demás. La decisión la toma quien lee la evidencia.
#
# CÓMO SE EXTIENDE
# ----------------
# Añadir una familia nueva es añadir una entrada a este diccionario. La lógica
# de `generar()` no se toca: recorre lo que haya.
_SUPUESTOS_VIGILADOS: Dict[str, Dict[str, object]] = {
    "series_temporales": {
        "disparador": "el modelo estima sobre series de tiempo, volatilidades, "
                      "retornos o cualquier magnitud indexada por fecha",
        "vigilar": [
            "Estacionariedad: ¿se contrastó (ADF, KPSS) o se asume sin más?",
            "Autocorrelación de residuos: ¿se testeó (Ljung-Box, Durbin-Watson)?",
            "Heterocedasticidad: ¿se justifica el estimador de volatilidad usado?",
            "Normalidad de residuos: ¿se contrastó (Jarque-Bera, Shapiro) o se "
            "asume? ¿Se reporta curtosis/asimetría?",
            "Ventana de estimación: ¿se justifica su longitud y su vigencia?",
        ],
    },
    "clasificacion_scoring": {
        "disparador": "el modelo asigna un puntaje, una probabilidad o una clase "
                      "(scorecards, regresión logística, árboles, ML supervisado)",
        "vigilar": [
            "Balance de clases: ¿se documenta la proporción de eventos y cómo se "
            "trató el desbalance?",
            "Estabilidad poblacional: ¿se monitorea PSI/CSI entre desarrollo y "
            "población actual? ¿Con qué umbral?",
            "Multicolinealidad entre variables: ¿se midió (VIF, correlaciones)?",
            "Punto de corte: ¿está justificado por criterio de negocio o costes "
            "de error, o es arbitrario?",
            "Poder discriminante: ¿se reporta y se vigila su degradación "
            "(AUC/ROC, KS, Gini)?",
            "Separación train/validación/test: ¿es temporal o aleatoria? ¿Hay "
            "fuga de información (leakage)?",
        ],
    },
    "perdida_esperada": {
        "disparador": "el modelo estima componentes de pérdida esperada o "
                      "provisiones (PD, LGD, EAD, staging, IFRS 9, CECL)",
        "vigilar": [
            "Calibración: ¿la PD observada se contrasta contra la estimada y con "
            "qué periodicidad?",
            "Forward-looking: ¿qué escenarios macro se usan, con qué "
            "ponderaciones, quién los aprueba y cada cuánto se actualizan?",
            "Segmentación de cartera: ¿se justifica y se valida su homogeneidad?",
            "Criterios de transferencia entre etapas: ¿son cuantitativos y "
            "trazables o discrecionales?",
            "Profundidad del histórico: ¿cubre al menos un ciclo económico "
            "completo?",
            "Curación de LGD: ¿se trata el sesgo de recuperaciones incompletas?",
        ],
    },
    "deteccion_anomalias": {
        "disparador": "el modelo detecta eventos raros o sospechosos (fraude, "
                      "AML, anomalías, reglas de alerta)",
        "vigilar": [
            "Tasa de falsos positivos: ¿está medida y documentada? ¿Con qué "
            "coste operativo asociado?",
            "Falsos negativos: ¿cómo se estiman si no hay etiqueta del fraude no "
            "detectado?",
            "Umbral de alerta: ¿se justifica su nivel o es heredado sin revisar?",
            "Desbalance extremo de clases: ¿cómo se entrena y se evalúa "
            "(precision/recall, no accuracy)?",
            "Deriva del comportamiento adversario: ¿con qué frecuencia se "
            "recalibran las reglas?",
            "Etiquetado: ¿de dónde sale la verdad de campo y con qué rezago?",
        ],
    },
    "optimizacion_simulacion": {
        "disparador": "el modelo simula escenarios o resuelve una optimización "
                      "(Montecarlo, stress testing, ALM)",
        "vigilar": [
            "Número de simulaciones: ¿se justifica por convergencia del "
            "estimador?",
            "Semilla y reproducibilidad: ¿se fija y se registra?",
            "Distribuciones de entrada: ¿se ajustan a datos o se postulan?",
            "Dependencia entre factores: ¿se modela (cópulas, correlaciones) o se "
            "asume independencia?",
        ],
    },
    "datos_comun_a_todos": {
        "disparador": "SIEMPRE — cualquier modelo que consuma datos",
        "vigilar": [
            "Missing values: ¿qué método de imputación y por qué? ¿Se clasificó "
            "el patrón (MCAR/MAR/MNAR) o se imputó sin diagnosticar?",
            "Outliers: ¿se eliminan, se winsorizan o se conservan? ¿Con qué "
            "criterio documentado?",
            "Representatividad de la muestra: ¿el período de desarrollo cubre "
            "condiciones distintas a las actuales?",
            "Frescura de los datos: ¿hay rezagos y cómo afectan al resultado?",
            "Trazabilidad: ¿se puede reconstruir qué datos produjeron un "
            "resultado concreto?",
        ],
    },
}


def _render_supuestos() -> str:
    """Vuelca el catálogo al prompt en un formato compacto y legible."""
    bloques = []
    for nombre, familia in _SUPUESTOS_VIGILADOS.items():
        puntos = "\n".join(f"    · {v}" for v in familia["vigilar"])
        bloques.append(
            f"  [{nombre}] Aplica si: {familia['disparador']}.\n{puntos}"
        )
    return "\n".join(bloques)


_PROMPT = """\
Eres un Explicador Técnico-Pedagógico Senior especializado en traducir modelos
cuantitativos de riesgo financiero a lenguaje que entienda TANTO un auditor
técnico COMO alguien de negocio, sin perder rigor.

Escribe un documento Markdown que permita comprender el modelo '{modelo}'
COMPLETO sin leer el código fuente.

═══ REGLA DE ORO — PEDAGOGÍA SIN PERDER RIGOR ═══
Para cada concepto técnico (fórmula, transformación de datos, decisión
metodológica) cubre las cuatro capas:
  1. QUÉ hace, en una frase que entienda alguien de negocio.
  2. CÓMO lo hace técnicamente, citando la fórmula o el fragmento real.
  3. POR QUÉ se hizo así. Si las fuentes no lo justifican, escribe
     exactamente: "⚠️ Sin justificación documentada".
  4. EJEMPLO NUMÉRICO simple cuando aplique, construido con las MAGNITUDES
     Y UNIDADES DEL PROPIO MODELO que estás documentando (una probabilidad,
     un puntaje, un importe, una tasa…), nunca con las de otro dominio.

═══ REGLAS DE HONESTIDAD (las más importantes) ═══
· Cita SIEMPRE el fichero del que sale cada afirmación.
· Si el manual dice una cosa y la implementación hace otra, SEÑALA la
  discrepancia. No la reconcilies en silencio ni elijas una versión.
· Si algo no está en las fuentes, escribe "⚠️ Sin evidencia en fuentes".
  NUNCA lo completes con conocimiento general del dominio.
· Si detectas un supuesto frágil o una práctica cuestionable aunque las
  fuentes no la marquen como tal (p. ej. imputación por la media sin
  justificar), márcala como "⚠️ Punto a cuestionar".
· No inventes nombres de funciones, ficheros, cifras ni fechas.

═══ SUPUESTOS A VIGILAR ═══
Los modelos rara vez declaran sus supuestos tácitos: un scorecard no escribe
"asumo estabilidad poblacional", pero lo asume. Revisa el catálogo siguiente y
aplica ÚNICAMENTE las familias cuyo disparador esté REALMENTE presente en la
evidencia que se te ha dado.

Reglas de uso, en orden de importancia:
· NO fuerces familias que no correspondan al modelo. Si no es un clasificador,
  no menciones PSI ni balance de clases. Aplicar un supuesto ajeno es un error
  tan grave como omitir uno propio.
· Si las fuentes SÍ tratan un punto, no lo marques: descríbelo y di dónde.
· Si el punto aplica al modelo y las fuentes NO lo tratan, márcalo como
  "⚠️ Punto a cuestionar" en la sección 7 y conviértelo en pregunta concreta
  en la sección 9.
· El catálogo es un mínimo, no un techo: si detectas un supuesto frágil que no
  está aquí, señálalo igual.

{supuestos}

═══ FORMATO (importante para poder ensamblar el documento) ═══
· Usa `##` ÚNICAMENTE para las nueve secciones numeradas, y con su número
  exacto: `## 4. El modelo — función por función`.
· Cualquier subdivisión dentro de una sección va con `###`, nunca con `##`.
· Sé denso: prioriza cubrir TODAS las secciones que se te piden antes que
  agotar el espacio en la primera. Si te quedas sin margen, resume, pero no
  dejes ninguna sección sin escribir.

═══ INVENTARIO DE EVIDENCIA DISPONIBLE ═══
Estas son las ÚNICAS fuentes que puedes usar. Lo que no esté aquí, no existe:

{inventario}

═══ QUÉ TE TOCA ESCRIBIR AHORA ═══
{bloque}

═══ EVIDENCIA ═══
{evidencia}

Responde ÚNICAMENTE con las secciones Markdown que se te han pedido, sin
preámbulo ni comentarios finales.
"""


# El documento se genera POR BLOQUES, no de una sola llamada.
#
# Con las 9 secciones en un único prompt, el modelo agota `max_tokens` a mitad
# de la sección 4 y el documento sale truncado a media frase — verificado en la
# primera ejecución real. Trocearlo acota la salida de cada llamada y hace que
# el flujo aguante modelos con mucha más evidencia que LaR.
_BLOQUES: List[Dict[str, str]] = [
    {
        "clave": "1-3",
        "rotulo": "secciones 1 a 3 (resumen, metodología, datos)",
        "spec": """\
Escribe el título de nivel 1 `# Explicación del Modelo: {modelo}` y a
continuación EXACTAMENTE estas tres secciones:

## 1. Resumen en una página
Qué es, qué problema de negocio resuelve, quién lo usa y para qué decisión.
Debe poder leerlo un gerente sin conocimiento técnico y entenderlo completo.

## 2. Marco metodológico
Supuestos (cita textual de máximo 15 palabras donde aplique, resto
parafraseado), fórmulas clave explicadas paso a paso, y referencias normativas
si las fuentes las mencionan (Basel III, SR 11-7, BCBS 239, IFRS 9…).

## 3. El motor de datos — de dónde vienen los números
Fuentes de entrada; CADA control de calidad explicado (qué verifica, qué
tolerancia tiene, qué pasa si falla, con qué frecuencia corre); y las
transformaciones que sufren los datos antes de llegar al modelo.

No escribas las secciones 4 a 9: las cubre otra pasada.""",
    },
    {
        "clave": "4-5",
        "rotulo": "secciones 4 y 5 (funciones y flujo end-to-end)",
        "spec": """\
Escribe EXACTAMENTE estas dos secciones, sin repetir el título del documento
ni las secciones 1 a 3 (ya están escritas):

## 4. El modelo — función por función
Para cada función o componente descrito en la fuente de implementación: dónde
vive, qué hace, qué recibe y qué entrega, fragmento real citado, y cómo
encadena con el paso anterior y siguiente.
⚠️ Si la fuente de implementación NO contiene código sino solo arquitectura,
dilo abiertamente en la primera línea de la sección y describe los componentes
que sí estén documentados. NO inventes funciones ni ficheros.

## 5. Flujo completo — de principio a fin
Diagrama ASCII desde el dato crudo hasta el resultado final, indicando en cada
paso qué componente lo ejecuta.""",
    },
    {
        "clave": "6-9",
        "rotulo": "secciones 6 a 9 (seguimiento, limitaciones, glosario, preguntas)",
        "spec": """\
Escribe EXACTAMENTE estas cuatro secciones, sin repetir el título del documento
ni las secciones anteriores (ya están escritas):

## 6. Seguimiento y monitoreo en producción
Qué se revisa periódicamente (backtesting, tests, umbrales) y qué ocurre si el
modelo empieza a fallar (procedimiento de escalamiento si está documentado).

## 7. Limitaciones y supuestos frágiles
Lo que las fuentes reconocen como limitación, MÁS lo que tú detectes como
frágil aunque no esté documentado. Separa ambos grupos en dos subsecciones
claramente rotuladas.

## 8. Glosario
Cada término técnico del dominio usado en el documento, definido en una línea
simple que entienda alguien de negocio.

## 9. Preguntas abiertas
Todo lo que NO se puede responder con las fuentes disponibles, redactado como
preguntas concretas y accionables para el validador humano. Incluye aquí las
discrepancias que hayas detectado entre fuentes.""",
    },
]


class ExplicadorModelo:
    """
    Genera la explicación consolidada de un modelo a partir de las 4 fuentes.

    Parámetros
    ----------
    cliente_ia : cliente ya inicializado (config.get_cliente_ia())
    base_dir   : raíz del proyecto
    chunker    : ChunkerService opcional; si se pasa, los documentos largos se
                 resumen (y se cachean) en vez de truncarse.
    """

    def __init__(self, cliente_ia, base_dir: Path, chunker=None,
                 excluir: Sequence[str] = (), solo_coincidentes: bool = False):
        self.cliente = cliente_ia
        self.base_dir = Path(base_dir)
        self.chunker = chunker
        # Nombres de fichero a omitir (p. ej. fixtures de test que viven en inputs/)
        self.excluir = {e.lower() for e in excluir}
        self.solo_coincidentes = solo_coincidentes

    # ── Inventario ───────────────────────────────────────────────────────────

    def inventariar(self, modelo: str) -> Dict[str, Dict]:
        """
        Localiza la evidencia de `modelo` en cada una de las 4 fuentes.

        POR DEFECTO SE INCLUYE TODO LO QUE HAYA EN CADA FUENTE, marcando qué
        ficheros llevan además el nombre del modelo.

        La alternativa —quedarse solo con los ficheros cuyo nombre contiene el
        modelo— parece más precisa y es peor: en la evidencia real de LaR,
        `perfil_datos_LaR.md` coincide por nombre y `manual_controles_datos.md`
        no, así que el filtro descartaba en silencio el documento que describe
        TODOS los controles de calidad. Un documento al que le falta la mitad
        de la sección 3 sin avisar es más dañino que uno que incluye material
        de más: lo primero no se ve, lo segundo sí.

        Cuando varios modelos compartan las carpetas, `solo_coincidentes=True`
        (flag `--solo-coincidentes`) restringe por nombre de forma explícita.
        """
        token = modelo.lower()
        inventario: Dict[str, Dict] = {}

        for clave, meta in FUENTES.items():
            carpeta = self.base_dir / meta["ruta"]
            todos = sorted(
                p for p in carpeta.rglob("*")
                if p.is_file() and p.name.lower() not in self.excluir
            ) if carpeta.exists() else []

            coincidentes = [p for p in todos if token in p.name.lower()]
            ficheros = coincidentes if (self.solo_coincidentes and coincidentes) else todos

            inventario[clave] = {
                **meta,
                "carpeta": carpeta,
                "existe": carpeta.exists(),
                "ficheros": ficheros,
                "coincidentes": coincidentes,
                "omitidos": [p for p in todos if p not in ficheros],
                "chars": 0,          # se rellena al leer
            }
        return inventario

    # ── Lectura de evidencia ─────────────────────────────────────────────────

    def _leer(self, inventario: Dict[str, Dict]) -> Dict[str, List[Dict]]:
        """Lee y (si hace falta) resume los ficheros de cada fuente."""
        import sys
        ruta_motor = str(self.base_dir / "motor")
        if ruta_motor not in sys.path:
            sys.path.insert(0, ruta_motor)
        from Mx_01_LecturaEvidencias import leer_archivo

        docs_por_fuente: Dict[str, List[Dict]] = {}
        for clave, info in inventario.items():
            docs: List[Dict] = []
            for p in info["ficheros"]:
                try:
                    d = leer_archivo(p)
                except Exception as exc:                # pragma: no cover
                    logger.warning("No se pudo leer %s: %s", p, exc)
                    continue
                if d:
                    docs.append(d)

            if docs and self.chunker is not None:
                docs = self.chunker.procesar_lote(docs, verbose=False)

            info["chars"] = sum(len(d.get("contenido", "")) for d in docs)
            docs_por_fuente[clave] = docs
        return docs_por_fuente

    # ── Render ───────────────────────────────────────────────────────────────

    @staticmethod
    def _render_inventario(inventario: Dict[str, Dict]) -> str:
        lineas = []
        for info in inventario.values():
            if not info["existe"]:
                lineas.append(
                    f"- {info['titulo']} ({info['ruta']}): "
                    f"⚠️ LA CARPETA NO EXISTE — sin evidencia."
                )
                continue
            if not info["ficheros"]:
                lineas.append(
                    f"- {info['titulo']} ({info['ruta']}): "
                    f"⚠️ VACÍA — sin evidencia. Aporta normalmente: {info['aporta']}."
                )
                continue
            nombres = ", ".join(p.name for p in info["ficheros"])
            nota = ""
            if info["omitidos"]:
                nota = (f"  (omitidos por filtro explícito: "
                        f"{', '.join(p.name for p in info['omitidos'])})")
            lineas.append(f"- {info['titulo']} ({info['ruta']}): {nombres}{nota}")
        return "\n".join(lineas)

    @staticmethod
    def _render_evidencia(inventario: Dict[str, Dict],
                          docs_por_fuente: Dict[str, List[Dict]]) -> str:
        bloques = []
        for clave, info in inventario.items():
            docs = docs_por_fuente.get(clave, [])
            if not docs:
                bloques.append(
                    f"### FUENTE: {info['titulo']}\n"
                    f"⚠️ SIN EVIDENCIA DISPONIBLE. No inventes su contenido: "
                    f"declara el vacío en las secciones que dependan de ella."
                )
                continue
            partes = [f"### FUENTE: {info['titulo']}"]
            for d in docs:
                cobertura = d.get("cobertura_pct", 100.0)
                aviso = "" if cobertura >= 99.9 else \
                    f" [⚠️ cobertura {cobertura}% — resumen parcial]"
                partes.append(
                    f"\n--- fichero: {d.get('nombre','?')}{aviso} ---\n"
                    f"{d.get('contenido','')}"
                )
            bloques.append("\n".join(partes))
        return "\n\n".join(bloques)

    def _cabecera(self, modelo: str, inventario: Dict[str, Dict]) -> str:
        """Trazabilidad: sobre qué evidencia exacta se generó el documento."""
        filas = []
        for info in inventario.values():
            if not info["existe"]:
                estado, detalle = "❌ no existe", "—"
            elif not info["ficheros"]:
                estado, detalle = "⚠️ vacía", "—"
            else:
                estado = "✅ con evidencia"
                detalle = ", ".join(f"`{p.name}`" for p in info["ficheros"])
            filas.append(
                f"| {info['titulo']} | `{info['ruta']}` | {estado} | "
                f"{detalle} | {info['chars']:,} |"
            )
        sin_ev = [i["titulo"] for i in inventario.values() if not i["ficheros"]]
        aviso = ""
        if sin_ev:
            aviso = (
                f"\n> ⚠️ **Fuentes sin evidencia:** {', '.join(sin_ev)}. "
                f"Las secciones que dependen de ellas están marcadas como "
                f"«Sin evidencia en fuentes» y **no** se completaron con "
                f"conocimiento general.\n"
            )
        return (
            f"<!-- Generado por agente.py --explicar-modelo {modelo} -->\n"
            f"<!-- {_dt.datetime.now():%Y-%m-%d %H:%M} — no editar a mano: "
            f"se regenera desde inputs/ -->\n\n"
            f"> **Trazabilidad.** Documento generado automáticamente a partir de "
            f"la evidencia en `inputs/`. Cada afirmación debe poder rastrearse a "
            f"uno de estos ficheros.\n\n"
            f"| Fuente | Ruta | Estado | Ficheros | Chars |\n"
            f"|---|---|---|---|---:|\n" + "\n".join(filas) + "\n" + aviso +
            "\n---\n\n"
        )

    # ── API pública ──────────────────────────────────────────────────────────

    # Las 9 secciones que el documento debe tener sí o sí.
    _SECCIONES = tuple(range(1, 10))

    @classmethod
    def verificar(cls, documento: str) -> List[str]:
        """
        Comprueba que el documento salió entero. Devuelve la lista de problemas.

        Existe porque los dos primeros intentos reales salieron TRUNCADOS a
        media frase al agotar `max_tokens`, y sin esta comprobación el fichero
        se escribía igual: un documento a medias que parece completo es peor
        que un error, porque nadie lo revisa.
        """
        problemas: List[str] = []

        presentes = {
            int(m.group(1))
            for m in re.finditer(r"^##\s*(\d)\.", documento, re.MULTILINE)
        }
        faltan = [n for n in cls._SECCIONES if n not in presentes]
        if faltan:
            problemas.append(
                "faltan las secciones " + ", ".join(str(n) for n in faltan)
            )

        # Un cierre a media frase delata truncamiento por max_tokens.
        cola = documento.rstrip()
        if cola and cola[-1] not in ".:)|`-*_":
            problemas.append(f"el documento acaba a media frase: …{cola[-60:]!r}")

        return problemas

    def generar(self, modelo: str, outputs_dir: Path,
                dry_run: bool = False,
                max_tokens: int = 16000) -> Optional[Path]:
        """
        Genera el documento y devuelve su ruta (None en dry-run).

        `dry_run=True` hace todo el trabajo salvo la llamada al modelo: sirve
        para ver qué evidencia se consumiría y cuánto costaría.
        """
        inventario = self.inventariar(modelo)
        docs = self._leer(inventario)

        con_evidencia = [i for i in inventario.values() if i["ficheros"]]
        if not con_evidencia:
            raise ValueError(
                f"No hay ninguna evidencia para '{modelo}' en las 4 fuentes. "
                f"Revisa que los ficheros estén en inputs/ y que el nombre del "
                f"modelo coincida."
            )

        inventario_txt = self._render_inventario(inventario)
        evidencia_txt = self._render_evidencia(inventario, docs)

        prompts = {
            b["clave"]: _PROMPT.format(
                modelo=modelo,
                inventario=inventario_txt,
                evidencia=evidencia_txt,
                supuestos=_render_supuestos(),
                bloque=b["spec"].format(modelo=modelo),
            )
            for b in _BLOQUES
        }

        print(self._resumen_inventario(modelo, inventario, prompts))

        if dry_run:
            print("  🔎 dry-run: no se llamó al modelo. Nada que pagar.\n")
            return None

        # Si un bloque falla (saldo agotado, rate limit, corte de red) NO se
        # descarta lo ya generado: se guarda lo que haya con un aviso visible.
        # Cada bloque es dinero ya gastado; tirarlo y devolver un traceback
        # obliga a pagarlo otra vez desde cero.
        partes: List[str] = []
        fallo: Optional[str] = None
        for i, bloque in enumerate(_BLOQUES, 1):
            print(f"  🧠 Redactando {bloque['rotulo']} "
                  f"({i}/{len(_BLOQUES)})…", flush=True)
            try:
                texto = self.cliente.generar_mensaje(
                    prompt=prompts[bloque["clave"]],
                    sistema="Eres un explicador técnico-pedagógico de modelos de "
                            "riesgo financiero. Rigor absoluto: nunca inventas "
                            "evidencia; si algo no está en las fuentes, lo declaras.",
                    max_tokens=max_tokens,
                )
            except Exception as exc:
                fallo = f"{bloque['rotulo']}: {exc}"
                logger.error("Explicador: falló el bloque %s — %s",
                             bloque["clave"], exc)
                partes.append(
                    f"> ⚠️ **DOCUMENTO INCOMPLETO.** No se pudieron generar las "
                    f"{bloque['rotulo']} ni las posteriores.\n>\n"
                    f"> Causa: `{exc}`\n>\n"
                    f"> Lo anterior sí es válido. Relanza el mismo comando para "
                    f"completarlo."
                )
                break
            partes.append(texto.strip())

        cuerpo = "\n\n".join(partes)
        # [AUDIT-FIX] `modelo` viene de la línea de comandos y se interpolaba
        # tal cual: `--explicar-modelo "../../../evil"` escribía FUERA de
        # outputs/, y un nombre con `/` apuntaba a un subdirectorio inexistente
        # (FileNotFoundError tras haber pagado ya las llamadas al modelo).
        from config.rutas import nombre_seguro
        destino = Path(outputs_dir) / f"explicacion_del_modelo_{nombre_seguro(modelo)}.md"
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_text(self._cabecera(modelo, inventario) + cuerpo + "\n",
                           encoding="utf-8")

        if fallo:
            print(f"  ⚠️  Documento PARCIAL guardado en: {destino}")
            print(f"     Se interrumpió en → {fallo}")
            print(f"     Los {len(partes) - 1} bloque(s) previos sí se "
                  f"escribieron; relanza para completarlo.")
            return destino

        problemas = self.verificar(cuerpo)
        if problemas:
            print(f"  ⚠️  Documento generado CON PROBLEMAS: {destino}")
            for p in problemas:
                print(f"     · {p}")
            print("     Súbele max_tokens o reduce la evidencia de entrada.")
        else:
            n = len(cuerpo.splitlines())
            print(f"  ✅ Documento completo ({n:,} líneas, 9/9 secciones): {destino}")
        return destino

    # ── Presentación ─────────────────────────────────────────────────────────

    @staticmethod
    def _resumen_inventario(modelo: str, inventario: Dict[str, Dict],
                            prompts: Dict[str, str]) -> str:
        chars = sum(len(p) for p in prompts.values())
        # [GENERICO 2026-07-30] La relación chars/token y el precio estaban
        # incrustados aquí: `chars / 2.5` y `tokens / 1e6 * 1.0` rotulado como
        # «(Haiku 4.5)». Con Azure configurado, el `--dry-run` seguía estimando
        # al precio de un modelo de otro proveedor y lo declaraba con su nombre,
        # así que el operador decidía gastar sobre una cifra que no era la suya.
        # Ambos valores viven ahora en config/modelos.py, junto al catálogo.
        from config.modelos import CHARS_POR_TOKEN_ES, precio_entrada_por_mtok
        try:
            from motor.Mx_00_CargaRutas import MODELO_IA as _modelo_activo
        except ImportError:                                # pragma: no cover
            _modelo_activo = None
        tokens = chars / CHARS_POR_TOKEN_ES
        _precio = precio_entrada_por_mtok(_modelo_activo)
        lineas = [
            "",
            "═" * 66,
            f"  EXPLICADOR DE MODELO — {modelo}",
            "═" * 66,
        ]
        for info in inventario.values():
            if not info["existe"]:
                estado = "❌ carpeta inexistente"
            elif not info["ficheros"]:
                estado = "⚠️  sin evidencia"
            else:
                marca = (f", {len(info['coincidentes'])} por nombre"
                         if info["coincidentes"] else "")
                estado = (f"✅ {len(info['ficheros'])} fichero(s), "
                          f"{info['chars']:,} chars{marca}")
            lineas.append(f"  {info['titulo']:<38} {estado}")
        lineas += [
            "  " + "─" * 62,
            f"  {len(prompts)} llamadas (una por bloque de secciones)",
            f"  Entrada total: {chars:,} chars ≈ {tokens:,.0f} tokens",
            f"  Coste estimado entrada: ${tokens / 1_000_000 * _precio:.4f} "
            f"({_modelo_activo or 'modelo desconocido'} · ${_precio:.2f}/Mtok)",
            "═" * 66,
        ]
        return "\n".join(lineas)
