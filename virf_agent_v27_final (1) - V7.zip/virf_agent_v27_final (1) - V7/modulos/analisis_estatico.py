"""
modulos/analisis_estatico.py
═══════════════════════════════════════════════════════════════════════════════
QUÉ HACE EL CÓDIGO, LEÍDO DEL CÓDIGO — sin ejecutarlo y sin preguntarle al LLM.

QUÉ RESUELVE
────────────
`--revisar-codigo` le pide a un modelo que compare código y manual. Es potente,
pero su respuesta es un juicio: puede acertar, equivocarse de categoría, o citar
algo que no está. Por eso se le exige anclar sus afirmaciones.

Este módulo hace lo contrario: extrae del AST los HECHOS DUROS —qué funciones se
definen, con qué valores por defecto, qué ventanas se recortan, qué métodos
estadísticos se invocan— y los contrasta contra el texto de la documentación.
No hay juicio, no hay llamada a la API, no hay azar: dos ejecuciones sobre el
mismo fichero dan exactamente el mismo resultado.

    `--revisar-codigo`      →  «un validador experto opina sobre este código»
    `--analizar-codigo`     →  «esto es literalmente lo que el código declara»

Los dos se complementan. El estático encuentra lo comprobable; el LLM encuentra
lo que requiere criterio. Y el estático sirve además para calibrar al LLM: si
afirma que existe una función que el AST no ve, alguien se equivoca.

POR QUÉ NO SE EJECUTA EL CÓDIGO
───────────────────────────────
Se evaluó y se descartó. Ejecutar daría comportamiento real —que la función
corra, qué devuelve con datos conocidos—, pero el código de
`inputs/implementacion/` lo aporta EL VALIDADO: la parte con incentivo en el
resultado. Correría con los permisos del validador, en la máquina que guarda
`audit_logs/`, `outputs/` y `feedback/`, de modo que un script podría alterar la
evidencia de su propia validación. Y rompería el invariante 5: una corrida que
ejecuta código deja de ser reproducible por sí sola.

El proyecto ya tiene un `exec()` sin sandbox en `excel_a_notebook.py`, sobre
código que genera el PROPIO agente, y su comentario de auditoría deja el
aislamiento real como decisión pendiente. Extender la ejecución al código ajeno
sería ampliar esa superficie antes de haberla cerrado.

LÍMITES DE LO QUE EL AST PUEDE VER — se declaran, no se disimulan
─────────────────────────────────────────────────────────────────
  · Un valor calculado (`ventana = N_ANIOS * 250`) no es una constante: se
    reporta como no determinable, no se adivina.
  · El código dinámico (`getattr`, `eval`, construcción de nombres) es opaco.
  · Un `.ipynb` se analiza celda a celda; si una celda no compila, se declara.
  · Que un número aparezca en el manual no prueba que se refiera a ESE
    parámetro. Por eso los hallazgos numéricos son `media`, nunca `critica`:
    señalan dónde mirar, no dictaminan.
"""

from __future__ import annotations

import ast
import json
import logging
import re
import unicodedata
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("virf.analisis_estatico")

__all__ = [
    "analizar_modulo", "analizar_arbol", "informe_markdown",
    "CATEGORIAS_ESTATICAS",
]

#: Categorías de hallazgo. Cerradas, como en `revision_codigo`: si cada fichero
#: nombrara lo mismo de otra forma, consolidar 30 módulos sería imposible.
CATEGORIAS_ESTATICAS = {
    "funcion_documentada_ausente":
        "El manual nombra una función que ningún script define",
    "funcion_no_documentada":
        "El script define una función pública que el manual no nombra",
    "parametro_no_documentado":
        "Un valor por defecto del código no aparece en la documentación",
    "ventana_no_documentada":
        "Una ventana/recorte del código no aparece en la documentación",
    "metodo_no_documentado":
        "Se usa un método estadístico que el manual no menciona",
    "reproducibilidad":
        "Hay aleatoriedad sin semilla fijada",
    "no_determinable":
        "El AST no puede resolver el valor; requiere revisión humana",
    # ── Hechos de EJECUCIÓN de un notebook ───────────────────────────────────
    # No salen del AST sino de los metadatos que el propio `.ipynb` guarda. No
    # hay que ejecutar nada: los resultados ya están ahí, escritos por quien lo
    # corrió. Son tan deterministas como los anteriores.
    "notebook_sin_ejecutar":
        "Celdas de código que nunca se ejecutaron",
    "notebook_con_excepcion":
        "Una celda quedó con una excepción sin resolver",
    "orden_ejecucion_roto":
        "Las celdas se ejecutaron en un orden distinto al del documento",
}

#: Métodos cuyo uso define la metodología de un modelo de riesgo. No es una
#: lista exhaustiva de estadística: son los que, si aparecen en el código y no
#: en el manual, indican que el manual no describe lo que se calcula.
_METODOS_RELEVANTES = {
    "percentile": "percentil empírico",
    "quantile": "cuantil",
    "std": "desviación típica",
    "var": "varianza",
    "cov": "covarianza",
    "corr": "correlación",
    "log": "logaritmo (retornos logarítmicos)",
    "exp": "exponencial",
    "mean": "media",
    "median": "mediana",
    "ewm": "media móvil exponencial (EWMA)",
    "rolling": "ventana móvil",
    "cholesky": "descomposición de Cholesky",
    "norm": "distribución normal",
    "t": "distribución t de Student",
}

#: Funciones que introducen azar. Sin semilla, dos corridas dan resultados
#: distintos y el backtesting deja de ser comparable.
_FUENTES_ALEATORIAS = {"random", "rand", "randn", "normal", "choice",
                       "shuffle", "permutation", "sample", "uniform"}

#: Números que aparecen en cualquier código y no dicen nada del modelo.
_NUMEROS_TRIVIALES = {0, 1, 2, -1, 100, 0.0, 1.0, 0.5}


def _norm(texto: str) -> str:
    """Minúsculas sin acentos, espacios colapsados."""
    sin = "".join(c for c in unicodedata.normalize("NFKD", str(texto or ""))
                  if not unicodedata.combining(c))
    return " ".join(sin.lower().split())


def _numero_en_texto(valor, texto_norm: str) -> bool:
    """
    ¿Este número aparece en la documentación?

    Se compara la representación «humana» del número, no la de Python: un
    `0.99` en el código se escribe «99%» en un manual, y un `500` puede venir
    con separador de miles. Sin estas formas, un parámetro correctamente
    documentado se reportaría como ausente y el aviso sería ruido.
    """
    formas = set()
    try:
        f = float(valor)
    except (TypeError, ValueError):
        return False

    if f == int(f):
        n = int(f)
        formas |= {str(n), f"{n:,}".replace(",", "."), f"{n:,}"}
    else:
        formas.add(str(f).rstrip("0").rstrip("."))
    # Fracciones que se documentan como porcentaje: 0.99 → «99», 0.975 → «97,5»
    if 0 < f < 1:
        pct = f * 100
        formas.add(str(int(pct)) if pct == int(pct) else str(pct))
        formas.add(str(pct).replace(".", ","))
    return any(re.search(rf"(?<!\d){re.escape(x)}(?!\d)", texto_norm)
               for x in formas if x)


def _identificadores_en_manual(manual: str) -> set:
    """
    Nombres que el manual invoca como función: `backtesting_kupiec()`.

    Se exige el paréntesis a propósito. Sin él, cualquier palabra del manual
    que coincidiera con un nombre de variable produciría un falso hallazgo.
    """
    return set(re.findall(r"\b([a-zA-Z_][a-zA-Z0-9_]{2,})\s*\(\s*\)", manual or ""))


# ═════════════════════════════════════════════════════════════════════════════
# Extracción de hechos
# ═════════════════════════════════════════════════════════════════════════════

def _codigo_de(ruta: Path) -> Tuple[str, List[str], Optional[dict]]:
    """
    Fuente analizable de un `.py` o `.ipynb`.

    Devuelve `(codigo, avisos, nb)`, donde `nb` es el JSON del notebook o None
    para un `.py`. Se devuelve el notebook ya parseado para que
    `_hechos_notebook` no tenga que releer y volver a parsear el fichero: en un
    notebook grande eso es duplicar el trabajo caro.

    Las celdas que no compilan se OMITEN y se declaran: analizar media celda
    produciría hechos falsos, y callarlo dejaría al lector creyendo que se
    revisó entera.
    """
    avisos: List[str] = []
    if ruta.suffix.lower() == ".ipynb":
        try:
            nb = json.loads(ruta.read_text(encoding="utf-8", errors="replace"))
        except (json.JSONDecodeError, OSError) as exc:
            return "", [f"notebook ilegible: {exc}"], None
        trozos = []
        for i, celda in enumerate(nb.get("cells") or [], 1):
            if celda.get("cell_type") != "code":
                continue
            src = celda.get("source") or []
            fuente = "".join(src) if isinstance(src, list) else str(src)
            try:
                ast.parse(fuente)
            except SyntaxError:
                avisos.append(f"celda {i} no compila; NO se analizó")
                continue
            trozos.append(fuente)
        return "\n\n".join(trozos), avisos, nb
    try:
        return ruta.read_text(encoding="utf-8", errors="replace"), avisos, None
    except OSError as exc:
        return "", [f"ilegible: {exc}"], None


def _hechos_notebook(nb: dict) -> Dict[str, Any]:
    """
    Hechos de EJECUCIÓN que el notebook guarda de sí mismo.

    No hay que ejecutar nada: cuando alguien corre un notebook y lo guarda, el
    fichero conserva `execution_count` por celda y los `outputs` producidos. En
    una validación eso ES evidencia — de que el código corrió, en qué orden y
    con qué resultado— y está disponible a coste cero.

    Tres hechos, los tres deterministas:

      · `sin_ejecutar`  — celdas con `execution_count` nulo.
      · `excepciones`   — celdas cuyo output guardado es un traceback.
      · `orden`         — los `execution_count` de las celdas ejecutadas, en el
        orden en que aparecen en el documento. Si no son crecientes, el
        notebook se ejecutó salteado y su estado NO corresponde a ninguna
        corrida de arriba abajo.
    """
    total = ejecutadas = 0
    sin_ejecutar: List[int] = []
    excepciones: List[Dict] = []
    orden: List[Tuple[int, int]] = []      # (nº de celda, execution_count)

    for i, celda in enumerate(nb.get("cells") or [], 1):
        if celda.get("cell_type") != "code":
            continue
        # Una celda vacía no es una celda sin ejecutar: no hay nada que correr,
        # y contarla produciría un hallazgo por un hueco en blanco.
        src = celda.get("source") or []
        if not ("".join(src) if isinstance(src, list) else str(src)).strip():
            continue
        total += 1
        ec = celda.get("execution_count")
        if isinstance(ec, int):
            ejecutadas += 1
            orden.append((i, ec))
        else:
            sin_ejecutar.append(i)
        for out in celda.get("outputs") or []:
            if out.get("output_type") == "error":
                excepciones.append({
                    "celda": i,
                    "tipo": out.get("ename", "Error"),
                    "mensaje": str(out.get("evalue", ""))[:200],
                })

    # ¿Los contadores crecen en el orden del documento?
    monotono = all(orden[k][1] < orden[k + 1][1] for k in range(len(orden) - 1))

    return {
        "n_celdas_codigo": total,
        "n_ejecutadas": ejecutadas,
        "sin_ejecutar": sin_ejecutar,
        "excepciones": excepciones,
        "orden_monotono": monotono,
        "orden": orden,
    }


def _contrastar_notebook(nbh: Dict[str, Any], fichero: str) -> List[Dict]:
    """Convierte los hechos de ejecución en hallazgos."""
    hall: List[Dict] = []

    def _add(cat, sev, linea, elem, desc):
        hall.append({"fichero": fichero, "linea": linea, "categoria": cat,
                     "severidad": sev, "elemento": elem, "descripcion": desc,
                     "valor": None})

    total, sin_ej = nbh["n_celdas_codigo"], nbh["sin_ejecutar"]

    if total and len(sin_ej) == total:
        # Ninguna celda corrió: el notebook no acredita NADA. Es distinto de
        # tener alguna celda exploratoria sin ejecutar.
        _add("notebook_sin_ejecutar", "alta", None,
             f"{total} celdas, ninguna ejecutada",
             "Ninguna celda de código de este notebook se ha ejecutado. El "
             "fichero no acredita que el cálculo se haya corrido nunca: es "
             "código entregado, no evidencia de ejecución.")
    elif sin_ej:
        _add("notebook_sin_ejecutar", "media", sin_ej[0],
             f"celdas {', '.join(str(c) for c in sin_ej[:10])}"
             + ("…" if len(sin_ej) > 10 else ""),
             f"{len(sin_ej)} de {total} celdas de código no se ejecutaron. Los "
             f"resultados del notebook no incluyen lo que esas celdas "
             f"producirían.")

    for e in nbh["excepciones"]:
        _add("notebook_con_excepcion", "alta", e["celda"],
             f"celda {e['celda']}: {e['tipo']}",
             f"La celda {e['celda']} quedó guardada con una excepción sin "
             f"resolver: {e['tipo']}: {e['mensaje']}. Un traceback en un "
             f"notebook entregado como evidencia es un hallazgo por sí solo.")

    if not nbh["orden_monotono"]:
        secuencia = ", ".join(f"celda {c}→#{n}" for c, n in nbh["orden"][:8])
        _add("orden_ejecucion_roto", "alta", None, "orden de ejecución",
             f"Las celdas se ejecutaron en un orden distinto al del documento "
             f"({secuencia}…). El estado que muestra el notebook NO corresponde "
             f"a ninguna ejecución de arriba abajo: reejecutarlo desde cero "
             f"puede dar resultados distintos, y los que muestra pueden depender "
             f"de variables que ya no existirían. Rompe la reproducibilidad.")

    return hall


def _hechos(arbol: ast.AST) -> Dict[str, Any]:
    """Extrae del AST todo lo que se puede afirmar sin ejecutar."""
    funciones: List[Dict] = []
    ventanas: List[Dict] = []
    metodos: Dict[str, int] = {}
    aleatorio: List[Dict] = []
    semilla = False
    no_determinables: List[Dict] = []

    for n in ast.walk(arbol):
        # ── Funciones y sus valores por defecto ──────────────────────────────
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            defaults: Dict[str, Any] = {}
            args = n.args.args[len(n.args.args) - len(n.args.defaults):] \
                if n.args.defaults else []
            for a, d in zip(args, n.args.defaults):
                if isinstance(d, ast.Constant) and isinstance(d.value, (int, float)):
                    defaults[a.arg] = d.value
                elif not isinstance(d, ast.Constant):
                    # Un default calculado no es una constante: se declara.
                    no_determinables.append({
                        "linea": n.lineno,
                        "que": f"valor por defecto de `{a.arg}` en {n.name}()",
                    })
            funciones.append({
                "nombre": n.name, "linea": n.lineno,
                "publica": not n.name.startswith("_"),
                "defaults": defaults,
                "args": [a.arg for a in n.args.args],
            })

        # ── Recortes literales: retornos[-500:] ──────────────────────────────
        if isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Slice):
            lo = n.slice.lower
            if (isinstance(lo, ast.UnaryOp) and isinstance(lo.op, ast.USub)
                    and isinstance(lo.operand, ast.Constant)
                    and isinstance(lo.operand.value, int)):
                ventanas.append({"linea": n.lineno, "n": lo.operand.value})
            elif lo is not None and not isinstance(lo, ast.Constant):
                no_determinables.append({
                    "linea": n.lineno,
                    "que": "tamaño de una ventana calculado en tiempo de ejecución",
                })

        # ── Métodos estadísticos y aleatoriedad ──────────────────────────────
        if isinstance(n, ast.Call):
            nombre = getattr(n.func, "attr", None) or getattr(n.func, "id", None)
            if nombre in _METODOS_RELEVANTES:
                metodos[nombre] = metodos.get(nombre, 0) + 1
            if nombre in _FUENTES_ALEATORIAS:
                aleatorio.append({"linea": n.lineno, "fuente": nombre})
            if nombre in ("seed", "default_rng", "set_seed"):
                semilla = True

    return {
        "funciones": funciones,
        "ventanas": ventanas,
        "metodos": metodos,
        "aleatorio": aleatorio,
        "semilla_fijada": semilla,
        "no_determinables": no_determinables,
    }


# ═════════════════════════════════════════════════════════════════════════════
# Contraste contra la documentación
# ═════════════════════════════════════════════════════════════════════════════

def _contrastar(hechos: Dict[str, Any], manual: str, fichero: str) -> List[Dict]:
    """
    Convierte hechos en hallazgos comparándolos con el texto de los manuales.

    Criterio de severidad, y es deliberado:

      · `alta`  solo cuando el hecho es INEQUÍVOCO — el manual nombra una
        función con paréntesis y ningún script la define. Ahí no hay
        interpretación posible.
      · `media` para los numéricos. Que un número no aparezca en el manual es
        un indicio fuerte, pero que aparezca NO prueba que se refiera a ese
        parámetro. Señalan dónde mirar; no dictaminan.

    Inflar la severidad de lo que es un indicio convertiría el informe en ruido
    y enseñaría al validador a ignorarlo — que es como se pierden los hallazgos
    que sí importan.
    """
    man_norm = _norm(manual)
    hall: List[Dict] = []

    def _add(cat, sev, linea, elem, desc, valor=None):
        hall.append({
            "fichero": fichero, "linea": linea, "categoria": cat,
            "severidad": sev, "elemento": elem, "descripcion": desc,
            "valor": valor,
        })

    # ── Funciones ────────────────────────────────────────────────────────────
    definidas = {f["nombre"] for f in hechos["funciones"]}
    for f in hechos["funciones"]:
        if f["publica"] and _norm(f["nombre"]) not in man_norm:
            _add("funcion_no_documentada", "media", f["linea"], f["nombre"],
                 f"El script define `{f['nombre']}()` y el nombre no aparece en "
                 f"la documentación. Puede ser un auxiliar interno o una pieza "
                 f"del cálculo que nadie documentó.")

    # ── Parámetros por defecto ───────────────────────────────────────────────
    for f in hechos["funciones"]:
        for param, valor in f["defaults"].items():
            if valor in _NUMEROS_TRIVIALES:
                continue
            if not _numero_en_texto(valor, man_norm):
                _add("parametro_no_documentado", "media", f["linea"],
                     f"{f['nombre']}({param}={valor})",
                     f"El código usa `{param}={valor}` por defecto y ese valor "
                     f"no aparece en la documentación. Si el manual declara otro "
                     f"valor para este parámetro, es una discrepancia efectiva: "
                     f"quien llame a la función sin indicarlo obtendrá {valor}.",
                     valor=valor)

    # ── Ventanas ─────────────────────────────────────────────────────────────
    for v in hechos["ventanas"]:
        if not _numero_en_texto(v["n"], man_norm):
            _add("ventana_no_documentada", "media", v["linea"],
                 f"ventana de {v['n']}",
                 f"El código recorta las últimas {v['n']} observaciones y ese "
                 f"número no aparece en la documentación.", valor=v["n"])

    # ── Métodos ──────────────────────────────────────────────────────────────
    for m, veces in sorted(hechos["metodos"].items()):
        if _norm(m) not in man_norm and _norm(_METODOS_RELEVANTES[m]) not in man_norm:
            _add("metodo_no_documentado", "media", None, m,
                 f"El código invoca `{m}()` ({_METODOS_RELEVANTES[m]}) "
                 f"{veces} vez/veces y la documentación no lo menciona.")

    # ── Reproducibilidad ─────────────────────────────────────────────────────
    if hechos["aleatorio"] and not hechos["semilla_fijada"]:
        fuentes = ", ".join(sorted({a["fuente"] for a in hechos["aleatorio"]}))
        _add("reproducibilidad", "alta", hechos["aleatorio"][0]["linea"],
             fuentes,
             f"Se usa aleatoriedad ({fuentes}) sin fijar semilla. Dos "
             f"ejecuciones producen resultados distintos, y el backtesting "
             f"deja de ser comparable entre periodos.")

    # ── Lo que el AST no puede resolver ──────────────────────────────────────
    for nd in hechos["no_determinables"]:
        _add("no_determinable", "baja", nd["linea"], nd["que"],
             f"No se pudo determinar sin ejecutar: {nd['que']}. "
             f"Requiere revisión humana.")

    return hall


def _funciones_documentadas_ausentes(manual: str, definidas_global: set
                                     ) -> List[Dict]:
    """
    Funciones que el manual invoca y que NINGÚN script define.

    Se calcula sobre el árbol COMPLETO, no por fichero: decir que falta una
    función mirando un solo módulo sería falso en cuanto estuviera en otro. Es
    el mismo error que cometería un revisor leyendo un fichero aislado.

    Severidad `alta`: aquí no hay interpretación. O está definida o no.
    """
    hall = []
    for nombre in sorted(_identificadores_en_manual(manual)):
        if nombre in definidas_global:
            continue
        if nombre in {"print", "len", "sum", "int", "float", "str", "dict",
                      "list", "range", "abs", "min", "max", "round"}:
            continue
        hall.append({
            "fichero": "(todo el árbol)", "linea": None,
            "categoria": "funcion_documentada_ausente", "severidad": "alta",
            "elemento": nombre, "valor": None,
            "descripcion": (
                f"La documentación invoca `{nombre}()` y ningún script del "
                f"árbol de implementación la define. O el código no está "
                f"completo, o la documentación describe algo que no se "
                f"implementó."),
        })
    return hall


# ═════════════════════════════════════════════════════════════════════════════
# API pública
# ═════════════════════════════════════════════════════════════════════════════

def analizar_modulo(ruta, manual: str = "", nombre_relativo: Optional[str] = None
                    ) -> Dict[str, Any]:
    """Analiza UN fichero. Nunca lanza: un fallo se declara en el resultado."""
    ruta = Path(ruta)
    nombre = nombre_relativo or ruta.name
    codigo, avisos, nb = _codigo_de(ruta)

    # Los hechos de EJECUCIÓN se extraen aunque el código no compile: un
    # notebook con celdas rotas sigue diciendo si se ejecutó, en qué orden y
    # con qué excepciones. Perder eso porque una celda tenga un error de
    # sintaxis sería descartar la evidencia más directa que hay.
    nb_hechos = _hechos_notebook(nb) if nb else {}
    nb_hall = _contrastar_notebook(nb_hechos, nombre) if nb_hechos else []

    if not codigo.strip():
        return {"fichero": nombre, "analisis_valido": False,
                "error": "; ".join(avisos) or "sin código analizable",
                "hechos": {"notebook": nb_hechos} if nb_hechos else {},
                "hallazgos": nb_hall, "avisos": avisos}
    try:
        arbol = ast.parse(codigo)
    except SyntaxError as exc:
        return {"fichero": nombre, "analisis_valido": False,
                "error": f"no compila: {exc}",
                "hechos": {"notebook": nb_hechos} if nb_hechos else {},
                "hallazgos": nb_hall, "avisos": avisos}

    hechos = _hechos(arbol)
    if nb_hechos:
        hechos["notebook"] = nb_hechos
    return {
        "fichero": nombre, "analisis_valido": True, "error": None,
        "hechos": hechos, "avisos": avisos,
        "hallazgos": _contrastar(hechos, manual, nombre) + nb_hall,
    }


def analizar_arbol(modulos: List[Path], manual: str = "", raiz=None,
                   verbose: bool = True) -> Dict[str, Any]:
    """Analiza todos los módulos y consolida. Coste 0: no llama a ninguna API."""
    raiz = Path(raiz) if raiz else None
    resultados = []
    for m in modulos:
        rel = (str(m.relative_to(raiz))
               if raiz and raiz in Path(m).parents else Path(m).name)
        res = analizar_modulo(m, manual, nombre_relativo=rel)
        if verbose:
            estado = (f"{len(res['hallazgos'])} hallazgo(s)"
                      if res["analisis_valido"] else f"✗ {res['error'][:50]}")
            print(f"    · {rel}: {estado}")
        resultados.append(res)

    definidas_global = {f["nombre"] for r in resultados
                        for f in (r["hechos"].get("funciones") or [])}
    globales = _funciones_documentadas_ausentes(manual, definidas_global)

    todos = [h for r in resultados for h in r["hallazgos"]] + globales
    por_cat: Dict[str, int] = {}
    for h in todos:
        por_cat[h["categoria"]] = por_cat.get(h["categoria"], 0) + 1

    n_ok = sum(1 for r in resultados if r["analisis_valido"])
    return {
        "n_modulos": len(resultados),
        "n_modulos_analizados_ok": n_ok,
        "n_modulos_con_fallo": len(resultados) - n_ok,
        "manual_disponible": bool(manual and manual.strip()),
        "n_hallazgos": len(todos),
        "por_categoria": por_cat,
        "por_severidad": {s: sum(1 for h in todos if h["severidad"] == s)
                          for s in ("alta", "media", "baja")},
        "hallazgos": sorted(
            todos, key=lambda h: ({"alta": 0, "media": 1, "baja": 2}
                                  .get(h["severidad"], 9),
                                  h["fichero"], h["linea"] or 0)),
        "hallazgos_globales": globales,
        "modulos": resultados,
        # Sin manual no hay contraste posible: los hechos siguen siendo
        # válidos, pero no significan nada frente a la documentación.
        "analisis_confiable": (len(resultados) - n_ok) == 0 and len(resultados) > 0,
    }


# ═════════════════════════════════════════════════════════════════════════════
# Log por script
# ═════════════════════════════════════════════════════════════════════════════

_ICONO = {"alta": "🟠", "media": "🟡", "baja": "⚪"}


def informe_markdown(cons: Dict[str, Any], modelo: str = "") -> str:
    """
    Log legible: qué declara cada script y qué no cuadra con la documentación.

    Se imprimen los HECHOS aunque no produzcan hallazgos. Un fichero «sin
    hallazgos» no dice lo mismo que un fichero del que se sabe qué funciones
    define, con qué parámetros y qué métodos usa: lo segundo es verificable
    por un humano en diez segundos, lo primero hay que creérselo.
    """
    from datetime import datetime

    lin = [
        f"# Análisis estático del código — {modelo or 'modelo'}",
        "",
        f"Generado por `modulos/analisis_estatico.py` el "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M')}. "
        f"**Coste 0** — no se llamó a ningún modelo y NO se ejecutó el código.",
        "",
        "## Resumen",
        "",
        f"- Módulos analizados: **{cons['n_modulos_analizados_ok']}/{cons['n_modulos']}**",
        f"- Hallazgos: **{cons['n_hallazgos']}** "
        f"(alta {cons['por_severidad'].get('alta', 0)}, "
        f"media {cons['por_severidad'].get('media', 0)}, "
        f"baja {cons['por_severidad'].get('baja', 0)})",
        f"- Análisis confiable: **{cons['analisis_confiable']}**",
        "",
    ]
    if not cons["manual_disponible"]:
        lin += ["> ⚠️ **Sin documentación disponible.** Los hechos extraídos son "
                "válidos, pero no hay nada contra lo que contrastarlos: los "
                "hallazgos de este informe estarían vacíos por falta de manual, "
                "no por ausencia de discrepancias.", ""]

    lin += ["> **Cómo leer las severidades.** `alta` = hecho inequívoco (una "
            "función documentada que no existe). `media` = indicio: que un "
            "número no aparezca en el manual es señal fuerte, pero que aparezca "
            "no prueba que se refiera a ese parámetro. Señalan dónde mirar.", ""]

    if cons["hallazgos_globales"]:
        lin += ["## Documentado pero no implementado", ""]
        for h in cons["hallazgos_globales"]:
            lin += [f"- 🟠 **`{h['elemento']}()`** — {h['descripcion']}"]
        lin.append("")

    lin += ["## Por fichero", ""]
    for r in cons["modulos"]:
        lin += [f"### `{r['fichero']}`", ""]
        if not r["analisis_valido"]:
            lin += [f"> ❌ No analizado: {r['error']}", ""]
            continue
        for a in r.get("avisos") or []:
            lin += [f"> ⚠️ {a}", ""]

        he = r["hechos"]
        # Los hechos, siempre. Es lo que hace el log verificable a mano.
        if he.get("funciones"):
            lin += ["**Define:**", ""]
            for f in he["funciones"]:
                firma = ", ".join(
                    f"{a}={f['defaults'][a]}" if a in f["defaults"] else a
                    for a in f["args"])
                lin.append(f"- `{f['nombre']}({firma})` — línea {f['linea']}")
            lin.append("")
        if he.get("ventanas"):
            lin += ["**Ventanas literales:** "
                    + ", ".join(f"{v['n']} (línea {v['linea']})"
                                for v in he["ventanas"]), ""]
        if he.get("metodos"):
            lin += ["**Métodos:** "
                    + ", ".join(f"`{m}()`×{n}" for m, n in
                                sorted(he["metodos"].items())), ""]
        if he.get("aleatorio"):
            lin += [f"**Aleatoriedad:** sí · semilla fijada: "
                    f"{'sí' if he.get('semilla_fijada') else '**NO**'}", ""]

        # Hechos de ejecución del notebook: se imprimen SIEMPRE que sea un
        # `.ipynb`, haya hallazgos o no. «12 de 12 ejecutadas, orden correcto»
        # es información que el validador quiere ver afirmada, no deducida del
        # silencio.
        nbh = he.get("notebook")
        if nbh:
            lin += [
                f"**Ejecución:** {nbh['n_ejecutadas']}/{nbh['n_celdas_codigo']} "
                f"celdas ejecutadas · orden "
                f"{'correcto' if nbh['orden_monotono'] else '**ALTERADO**'}"
                + (f" · **{len(nbh['excepciones'])} excepción(es)**"
                   if nbh["excepciones"] else ""),
                "",
            ]

        if not r["hallazgos"]:
            lin += ["_Sin discrepancias detectables con la documentación._", ""]
            continue
        lin += ["**Hallazgos:**", ""]
        for h in r["hallazgos"]:
            ubic = f" (línea {h['linea']})" if h["linea"] else ""
            lin += [f"- {_ICONO.get(h['severidad'], '·')} "
                    f"`{h['categoria']}`{ubic} — **{h['elemento']}**",
                    f"  {h['descripcion']}"]
        lin.append("")

    lin += ["---", "",
            "## Qué NO puede ver este análisis", "",
            "- Valores calculados en tiempo de ejecución (se marcan "
            "`no_determinable`).",
            "- Código dinámico: `getattr`, `eval`, nombres construidos.",
            "- **Si el cálculo es CORRECTO.** Esto comprueba que el código "
            "declare lo que el manual dice, no que la matemática esté bien.",
            "- Que un número aparezca en el manual no prueba que se refiera a "
            "ese parámetro.", ""]
    return "\n".join(lin)
