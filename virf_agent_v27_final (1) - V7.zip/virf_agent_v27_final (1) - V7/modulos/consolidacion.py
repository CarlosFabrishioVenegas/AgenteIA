"""
modulos/consolidacion.py
═════════════════════════════════════════════════════════════════════════════
Cierre HITL: convierte las decisiones del chat en el PUNTAJE EXACTO final.

El score inicial del agente NO se toca —es la vara comparable entre corridas y va
sellado en la cadena de custodia—. El puntaje validado por el humano se recomputa
aparte (`score_final`) a partir de lo que se cerró en el chat de sustentación.

REGLA ACORDADA (estado final por ítem, escala 1–5)
──────────────────────────────────────────────────
  · APROBADO  → el ítem queda 'Cumple'; puntaje_final = `valor_cumple()` (5 por
               defecto, configurable con VIRF_PUNTAJE_CUMPLE).
  · NEGADO    → no conformidad CONFIRMADA; mantiene su puntaje (sigue 'No cumple').
  · PENDIENTE → queda ABIERTO; mantiene su puntaje.
  · (sin decisión) → igual que estaba.

Así el `score_final` solo puede SUBIR respecto al inicial (vía subsanaciones
APROBADAS); una no conformidad confirmada no infla el puntaje.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional, Tuple

from modulos.motor_ia import calcular_score_ambito, calcular_score_global

__all__ = ["valor_cumple", "consolidar_decisiones", "tabla_final"]

# Estados de cierre del chat (espejo de web/services/chat_service.py VEREDICTOS).
_APROBADO = "APROBADO"
_NEGADO = "NEGADO"
_PENDIENTE = "PENDIENTE"
_CIERRES = (_APROBADO, _NEGADO, _PENDIENTE)


def valor_cumple() -> float:
    """Puntaje 1–5 que representa un ítem subsanado (APROBADO) en el recomputo.
    Configurable por el operador (VIRF_PUNTAJE_CUMPLE); por defecto 5.0."""
    try:
        v = float(os.environ.get("VIRF_PUNTAJE_CUMPLE", 5))
    except (TypeError, ValueError):
        v = 5.0
    return max(1.0, min(5.0, v))


def _norm(s: str) -> str:
    return " ".join(str(s or "").split()).lower()


def _indexar_decisiones(observaciones: List[Dict[str, Any]]) -> Dict[Tuple[str, str], Dict[str, Any]]:
    """(ámbito, actividad normalizada) → observación cerrada del chat."""
    dec: Dict[Tuple[str, str], Dict[str, Any]] = {}
    for o in observaciones or []:
        v = str(o.get("veredicto") or "").upper()
        if v in _CIERRES:
            dec[(o.get("ambito", ""), _norm(o.get("actividad", "")))] = o
    return dec


def consolidar_decisiones(datos: Dict[str, Any],
                          observaciones: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Aplica las decisiones cerradas del chat y devuelve el estado FINAL validado,
    sin mutar los resultados originales (se opera sobre copias).

    Args:
        datos:         JSON de resultados (con `resultados_por_ambito`).
        observaciones: lista de observaciones del chat (cada una con `ambito`,
                       `actividad`, `veredicto`, `hallazgo_final`).

    Returns:
        dict con `score_final_global`, `scores_final_por_ambito`, `resumen_final`
        y la lista de `decisiones` aplicadas (para el informe/Excel final).
    """
    dec = _indexar_decisiones(observaciones)
    val_cumple = valor_cumple()

    scores_final: Dict[str, Optional[float]] = {}
    n_cumple = n_nocumple = n_pend = 0

    for ambito, evs in (datos.get("resultados_por_ambito") or {}).items():
        evs_final: List[Dict[str, Any]] = []
        for e in (evs or []):
            d = dec.get((ambito, _norm(e.get("actividad", ""))))
            e2 = dict(e)   # copia: el eval original (score inicial) queda intacto
            if d is not None:
                v = str(d.get("veredicto")).upper()
                if v == _APROBADO:
                    e2["puntaje"] = val_cumple
                    e2["sin_evidencia"] = False
                    e2["resultado_final"] = "Cumple"
                    n_cumple += 1
                elif v == _NEGADO:
                    e2["resultado_final"] = "No cumple"
                    n_nocumple += 1        # mantiene puntaje
                elif v == _PENDIENTE:
                    e2["resultado_final"] = "Pendiente"
                    n_pend += 1            # mantiene puntaje
            evs_final.append(e2)
        scores_final[ambito] = calcular_score_ambito(evs_final)

    return {
        "score_final_global":      calcular_score_global(scores_final),
        "scores_final_por_ambito": scores_final,
        "resumen_final": {
            "cumple_subsanado":     n_cumple,
            "no_cumple_confirmado": n_nocumple,
            "pendiente":            n_pend,
            "decisiones":           len(dec),
            "valor_cumple":         val_cumple,
        },
        "decisiones": [
            {
                "ambito":    o.get("ambito", ""),
                "actividad": o.get("actividad", ""),
                "veredicto": str(o.get("veredicto") or "").upper(),
                "hallazgo":  o.get("hallazgo_final", ""),
            }
            for o in (observaciones or [])
            if str(o.get("veredicto") or "").upper() in _CIERRES
        ],
    }


# Mapeo veredicto del chat → estado final para la tabla/Excel final.
_VEREDICTO_A_ESTADO = {_APROBADO: "Cumple", _NEGADO: "No cumple", _PENDIENTE: "Pendiente"}


def tabla_final(datos: Dict[str, Any],
                observaciones: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Toma la tabla intermedia (`datos['tabla_validacion']`) y le aplica las
    decisiones cerradas del chat, devolviendo las filas del Excel FINAL. La fila
    conserva sus 8 columnas; solo se actualiza `resultado` cuando hubo decisión, y
    se anexa el `hallazgo` del chat al sustento.
    """
    dec = _indexar_decisiones(observaciones)
    filas: List[Dict[str, Any]] = []
    for fila in (datos.get("tabla_validacion") or []):
        f = dict(fila)
        d = dec.get((f.get("ambito", ""), _norm(f.get("actividad", ""))))
        if d is not None:
            v = str(d.get("veredicto")).upper()
            f["resultado"] = _VEREDICTO_A_ESTADO.get(v, f.get("resultado"))
            hall = (d.get("hallazgo_final") or "").strip()
            if hall:
                base = (f.get("evaluacion_sustentada") or "").strip()
                f["evaluacion_sustentada"] = (
                    f"{base}\n\n[Decisión validador — {v}] {hall}" if base
                    else f"[Decisión validador — {v}] {hall}")
            f["decidido_en_chat"] = True
        else:
            f["decidido_en_chat"] = False
        filas.append(f)
    return filas
