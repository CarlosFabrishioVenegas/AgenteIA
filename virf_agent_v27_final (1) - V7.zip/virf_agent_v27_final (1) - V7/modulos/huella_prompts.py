"""
modulos/huella_prompts.py
═══════════════════════════════════════════════════════════════════════════════
TRAZABILIDAD DEL PROMPT — qué se le preguntó exactamente al modelo.

LA PREGUNTA QUE RESPONDE
────────────────────────
Un auditor puede formular tres preguntas sobre un puntaje. El informe ya
respondía a dos:

    «¿sobre qué evidencia?»      → agente.documentos_huella (SHA-256 por fichero)
    «¿con qué criterio?»         → agente.estandar (SHA-256 del Excel)
    «¿y qué le preguntasteis?»   → ← ESTA no tenía respuesta

La huella de ejecución cubría configuración, documentos y estándar, pero **no
el texto del prompt**. Dos corridas con la misma evidencia y el mismo estándar
podían dar puntajes distintos porque alguien reescribió una instrucción del
ámbito, y nada en el informe lo delataba.

QUÉ SE GUARDA, Y QUÉ NO
───────────────────────
Se guarda el **SHA-256**, nunca el texto. Un prompt de evaluación contiene la
evidencia ÍNTEGRA del modelo —el manual entero, el código— y volcarlo al JSON
lo convertiría en una copia del expediente, con el tamaño y el problema de
confidencialidad que eso implica.

Dos niveles, porque responden a preguntas distintas:

  · `plantilla`  — hash de la LÓGICA que construye los prompts: el rol del
    agente, las instrucciones por ámbito y el código que los ensambla. Cambia
    cuando alguien reescribe un prompt. Es parte de la VARA DE MEDIR.

  · `prompt_sha256` por evaluación — hash del texto EXACTO que se envió para
    esa actividad. Responde «¿qué se preguntó para obtener este 3?».

Para ver el prompt completo existe `DEBUG_PROMPTS=1`, que lo vuelca a
`outputs/<fecha>/debug_prompts/`. Eso es depuración, no auditoría: el hash es
lo que viaja en el informe entregable.
"""

from __future__ import annotations

import hashlib
import logging
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger("virf.huella_prompts")

__all__ = ["sha256_texto", "huella_plantilla_prompts", "FICHEROS_PROMPT"]

# Ficheros cuyo contenido DETERMINA la forma de los prompts. Si cambia
# cualquiera, el modelo recibe una pregunta distinta aunque la evidencia sea la
# misma — y eso debe constar en el informe.
FICHEROS_PROMPT = (
    "motor/Mx_02_EstructuraPrompt.py",   # ensamblado de los prompts
    "motor/Mx_00_CargaRutas.py",         # ROL_AGENTE e INSTRUCCIONES_DIMENSION
)

_cache: Optional[Dict] = None


def sha256_texto(texto: str) -> str:
    """SHA-256 hexadecimal de un texto UTF-8."""
    return hashlib.sha256((texto or "").encode("utf-8")).hexdigest()


def huella_plantilla_prompts(forzar: bool = False) -> Dict:
    """
    Huella de la LÓGICA de construcción de prompts.

    Se calcula una vez por proceso: son varias lecturas de disco y el resultado
    no cambia a mitad de corrida.

    Se hashean por separado el rol del agente y las instrucciones por ámbito
    —además de los ficheros— porque son los dos textos que un validador toca
    cuando quiere afinar el criterio, y conviene poder señalar cuál cambió sin
    tener que diferenciar el fichero entero.
    """
    global _cache
    if _cache is not None and not forzar:
        return _cache

    from config.rutas import BASE_DIR

    ficheros: Dict[str, Optional[str]] = {}
    for rel in FICHEROS_PROMPT:
        ruta = Path(BASE_DIR) / rel
        try:
            ficheros[rel] = sha256_texto(ruta.read_text(encoding="utf-8"))[:12]
        except OSError as exc:
            logger.warning("No se pudo hashear '%s': %s", rel, exc)
            ficheros[rel] = None

    rol = instrucciones = None
    try:
        from motor.Mx_00_CargaRutas import INSTRUCCIONES_DIMENSION, ROL_AGENTE
        rol = sha256_texto(ROL_AGENTE)[:12]
        # `sorted` para que el orden de inserción del dict no altere el hash:
        # sin eso, dos corridas idénticas podrían dar huellas distintas.
        instrucciones = sha256_texto("\n".join(
            f"{k}:{v}" for k, v in sorted(INSTRUCCIONES_DIMENSION.items())))[:12]
    except ImportError as exc:                            # pragma: no cover
        logger.warning("No se pudo hashear el rol/instrucciones: %s", exc)

    conjunto = sha256_texto("|".join(
        [str(ficheros.get(f)) for f in FICHEROS_PROMPT] + [str(rol), str(instrucciones)]
    ))

    _cache = {
        "plantilla": conjunto[:12],
        "plantilla_completa": conjunto,
        "rol_agente": rol,
        "instrucciones_ambito": instrucciones,
        "ficheros": ficheros,
    }
    return _cache
