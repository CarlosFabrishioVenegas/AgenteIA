"""
modulos/abstencion.py
═════════════════════════════════════════════════════════════════════════════
Compuerta de abstención activa (WP-01, indicador D3).

QUÉ RESUELVE
────────────
La guía prohíbe el "conocimiento paramétrico sin RAG" y la "falsa aceptación
sin evidencia". Cuando el retrieval léxico devuelve fragmentos DÉBILES (o
ninguno), responder de memoria es exactamente el antipatrón: el agente debe
ABSTENERSE con una etiqueta explícita —"EVIDENCIA INSUFICIENTE"— en vez de
inventar una respuesta sin respaldo citable.

Esta decisión es DETERMINISTA y no llama al modelo: se toma sobre los scores
léxicos que ya produjo el buscador. Por eso es testeable sin API.

CONTRATO
────────
    evaluar_abstencion(scores, umbral=None) -> dict con:
        abstenido : bool
        etiqueta  : "EVIDENCIA INSUFICIENTE" si abstenido, si no None
        score_max : mejor score léxico observado (0.0 si no hubo fragmentos)
        umbral    : β aplicado
        n_chunks  : cuántos fragmentos se consideraron
        motivo    : explicación citable para el informe

REGLA
─────
  · Sin fragmentos            → abstención (no hay nada que citar).
  · score_max < β             → abstención (la evidencia es demasiado débil).
  · en otro caso              → hay evidencia suficiente para intentar responder.

β por defecto = 0.19 (config.ABSTENCION_BETA), CALIBRADO por datos en el Día 2:
punto de separación entre la evidencia ausente (cobertura 0.0) y las preguntas
respondibles (cobertura mínima 0.379) sobre el set de oro. Abstiene ante
evidencia nula o marginal sin castigar una respondible real. Configurable por el
operador (VIRF_ABSTENCION_BETA); ver docs/evidencia/beta_calibracion_dia2.md.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, Optional

__all__ = ["EVIDENCIA_INSUFICIENTE", "umbral_beta", "evaluar_abstencion"]

# Etiqueta canónica. Un único punto de verdad para que el informe, los tests y
# el pipeline usen exactamente la misma cadena.
EVIDENCIA_INSUFICIENTE = "EVIDENCIA INSUFICIENTE"


def umbral_beta() -> float:
    """β configurado en el proyecto (import perezoso para no acoplar)."""
    try:
        from config import parametros as p
        return float(p.ABSTENCION_BETA)
    except Exception:
        return 0.0


def _scores(scores: Iterable[Any]) -> list[float]:
    limpios: list[float] = []
    for s in scores or []:
        try:
            limpios.append(float(s))
        except (TypeError, ValueError):
            continue
    return limpios


def evaluar_abstencion(scores: Iterable[Any],
                       umbral: Optional[float] = None) -> Dict[str, Any]:
    """
    Decide si abstenerse a partir de los scores léxicos recuperados.

    Args:
        scores: iterable de scores léxicos de los fragmentos recuperados.
        umbral: β a aplicar; si None, se toma de la configuración.
    """
    beta = umbral_beta() if umbral is None else float(umbral)
    vals = _scores(scores)
    n = len(vals)
    score_max = max(vals) if vals else 0.0

    if n == 0:
        abstenido = True
        motivo = "No se recuperó ningún fragmento: no hay evidencia que citar."
    elif score_max < beta:
        abstenido = True
        motivo = (f"El mejor fragmento recuperado (score {score_max:.4f}) queda "
                  f"por debajo del umbral β={beta:.4f}: la evidencia es "
                  f"demasiado débil para sostener una respuesta citable.")
    else:
        abstenido = False
        motivo = (f"Evidencia suficiente: score máximo {score_max:.4f} ≥ "
                  f"β={beta:.4f} sobre {n} fragmento(s).")

    return {
        "abstenido": abstenido,
        "etiqueta": EVIDENCIA_INSUFICIENTE if abstenido else None,
        "score_max": score_max,
        "umbral": beta,
        "n_chunks": n,
        "motivo": motivo,
    }
