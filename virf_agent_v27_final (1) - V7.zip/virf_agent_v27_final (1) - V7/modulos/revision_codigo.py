"""
modulos/revision_codigo.py
═══════════════════════════════════════════════════════════════════════════════
REVISIÓN DEL CÓDIGO CONTRA LA DOCUMENTACIÓN — una llamada por módulo.

QUÉ RESUELVE
────────────
El ámbito «Implementación» del estándar VIRF pide contrastar el código contra
el manual: qué funciones documentadas existen de verdad, qué hay en el código
que nadie documentó, y qué se cambió sin actualizar la documentación (*code
drift*). La instrucción que se inyecta al modelo lo pide literalmente
(`Mx_00.INSTRUCCIONES_DIMENSION["Implementación"]`).

Pero el pipeline por ámbito no puede cumplirlo con un modelo real:

  · Todo el ámbito comparte un presupuesto de `VIRF_MAX_CTX` (15.000 chars por
    defecto) que además debe alojar el manual metodológico. Un modelo con sus
    propias librerías en `libs/` son fácilmente 200.000 chars: no caben, y lo
    que entra desplaza al manual contra el que había que contrastar.
  · Una sola respuesta JSON tiene que cubrir el árbol entero, así que los
    hallazgos salen genéricos («faltaría documentar algunas funciones») en vez
    de accionables («`libs/calculo.py:87` define `_ajuste_cf()`, que no aparece
    en el manual»).

DISEÑO: UN MÓDULO, UNA LLAMADA
──────────────────────────────
Cada fichero `.py`/`.ipynb` se revisa en su propia llamada, con el manual
metodológico como contexto FIJO. Consecuencias:

  · Cada módulo entra ÍNTEGRO. No compite por presupuesto con sus hermanos.
  · Los hallazgos se atribuyen a `fichero:línea`, porque el módulo se numera
    antes de enviarlo (`_numerar_lineas`) — un LLM no cuenta líneas fiablemente,
    hay que dárselas escritas.
  · El coste es proporcional al número de módulos y se conoce ANTES de gastar
    (`inventario()`), no después.

POR QUÉ EL INVENTARIO ES OBLIGATORIO
────────────────────────────────────
Este flujo multiplica las llamadas por el número de ficheros. Si el árbol que
se copió a `inputs/implementacion/` arrastra un `.venv/` o un `site-packages/`,
son miles de módulos y miles de llamadas. El proyecto NO excluye esas carpetas
por decisión explícita del operador, así que la defensa no puede ser un filtro
oculto: es declarar el coste y exigir confirmación. `--dry-run` muestra el
inventario sin gastar un token.

Quien quiera el filtro puede activarlo con `VIRF_EXCLUIR_DEPENDENCIAS=1`; viene
DESACTIVADO para no descartar código en silencio.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("virf.revision_codigo")

__all__ = [
    "RevisorCodigo", "HallazgoCodigo",
    "descubrir_modulos", "inventario",
    "CATEGORIAS_HALLAZGO", "PATRONES_DEPENDENCIAS",
]

# ─────────────────────────────────────────────────────────────────────────────
# Catálogo de hallazgos
# ─────────────────────────────────────────────────────────────────────────────
# Cerrado a propósito: si el modelo pudiera inventar categorías, consolidar los
# resultados de 30 módulos sería imposible (cada uno nombraría lo mismo de otra
# forma). El prompt exige usar exactamente estas claves.
CATEGORIAS_HALLAZGO = {
    "no_documentado":     "Existe en el código y el manual no lo declara",
    "documentado_ausente": "El manual lo declara y no existe en el código",
    "code_drift":         "Existe en ambos pero no coinciden (fórmula, parámetro, umbral)",
    "supuesto_tacito":    "El código asume algo que el manual no declara ni justifica",
    "riesgo_tecnico":     "Defecto que afecta al resultado del modelo",
}

# ─────────────────────────────────────────────────────────────────────────────
# [AUDIT-FIX] Anclaje del veredicto en los manuales
# ─────────────────────────────────────────────────────────────────────────────
# Categorías cuyo hallazgo AFIRMA lo que la documentación dice. En ellas la
# `referencia_manual` no es un adorno: es la prueba. Se exige y SE VERIFICA
# literalmente contra el texto de los manuales.
#
# Antes, el prompt pedía la referencia («si afirmas que el manual dice algo,
# cita el fragmento») y nadie la comprobaba. Pedir una cita sin verificarla es
# el peor de los dos mundos: parece verificable —lleva comillas y número de
# sección— así que nadie la contrasta, y si es inventada acusa al modelo
# validado de una discrepancia que no existe. Es el mismo razonamiento que
# `motor_ia._verificar_citas`, que sí verificaba, aplicado a la ruta de código
# que se había quedado fuera.
#
# Las otras tres categorías afirman una AUSENCIA en el manual
# (`no_documentado`, `supuesto_tacito`) o hablan solo del código
# (`riesgo_tecnico`). Exigirles una cita sería incoherente: no se puede citar
# un fragmento que demuestre que algo NO está.
CATEGORIAS_QUE_AFIRMAN_EL_MANUAL = frozenset({
    "documentado_ausente", "code_drift",
})

# Longitud mínima de una referencia para que su coincidencia sea concluyente.
# Mismo criterio que `_verificar_citas` (40 chars): por debajo, encontrarla en
# un manual largo puede ser casualidad y el «verificada» sería falso.
# Un «§4.2» no es una cita del contenido: es un puntero, y no prueba nada.
MIN_CHARS_REFERENCIA = 40

#: Marcas de elisión al citar: «[...]», «[…]», «(...)», «…». Separan tramos que
#: se verifican por separado. Ver `verificar_referencia_manual`.
_RE_ELISION = re.compile(r"\[\s*(?:\.{2,}|…)\s*\]|\(\s*(?:\.{2,}|…)\s*\)|\.{3,}|…")

# Severidades admitidas, de mayor a menor. Orden significativo: se usa para
# ordenar el informe consolidado.
SEVERIDADES = ("critica", "alta", "media", "baja")


#: Longitud mínima del nombre de un elemento para buscarlo sin falsos
#: positivos. Un `x` o un `df` aparecen en cualquier texto por casualidad.
MIN_CHARS_ELEMENTO = 4


def _aparece(nombre: str, texto: str) -> bool:
    """¿El identificador aparece en el texto, como palabra completa?"""
    if not nombre or not texto:
        return False
    return re.search(rf"\b{re.escape(nombre)}\b", texto) is not None


def recategorizar(categoria: str, elemento: str, codigo: str,
                  manual: str) -> Tuple[str, Optional[str]]:
    """
    Corrige la categoría cuando CONTRADICE los hechos. Devuelve `(cat, motivo)`.

    [AUDIT-FIX] Por qué
    ───────────────────
    La categoría la elige el modelo y en la corrida contra
    `modelos/VaR_FixtureDrift` se equivocó tres veces. Una de esas
    equivocaciones es peligrosa y no solo estética: etiquetar como
    `no_documentado` —«existe en el código y el manual no lo declara»— algo que
    en realidad afirma lo contrario hace que el hallazgo ESCAPE al anclaje,
    porque esa categoría no exige citar el manual. Una afirmación sobre la
    documentación entra entonces al informe sin verificar.

    Cómo se corrige sin adivinar
    ────────────────────────────
    NO se interpreta la prosa de la descripción: eso sería una heurística
    frágil, y este proyecto ya rechaza adivinar por coincidencia de palabras.
    Se comprueba lo que CADA CATEGORÍA AFIRMA, que son hechos verificables:

        `no_documentado`      afirma: el manual NO lo declara
        `documentado_ausente` afirma: el código NO lo tiene

    Si el elemento aparece en el manual, la primera afirmación es falsa. Si
    aparece en el código, la segunda lo es. Se busca por palabra completa sobre
    el texto real de ambos.

    Solo se corrige cuando la evidencia es INEQUÍVOCA. Cuando el elemento está
    en los dos sitios, o en ninguno, no se toca: la categoría podría ser
    correcta y sustituirla por otra adivinada sería cambiar un error por otro.

    Y nunca se corrige en silencio: el llamante guarda la categoría original en
    `categoria_declarada`, de modo que un auditor puede ver qué dijo el modelo y
    qué corrigió el agente. Corregir sin dejar rastro sería la clase de arreglo
    que este proyecto no admite.
    """
    elemento = (elemento or "").strip()
    if len(elemento) < MIN_CHARS_ELEMENTO:
        return categoria, None

    en_codigo = _aparece(elemento, codigo or "")
    en_manual = _aparece(elemento, manual or "")

    if categoria == "no_documentado" and en_manual:
        # Su premisa —«el manual no lo declara»— es falsa.
        nueva = "code_drift" if en_codigo else "documentado_ausente"
        return nueva, (f"declarada `no_documentado`, pero «{elemento}» SÍ "
                       f"aparece en la documentación")

    if categoria == "documentado_ausente" and en_codigo:
        # Su premisa —«no existe en el código»— es falsa.
        return "code_drift", (f"declarada `documentado_ausente`, pero "
                              f"«{elemento}» SÍ existe en el código")

    return categoria, None


def verificar_referencia_manual(referencia: str, categoria: str,
                                manual: str) -> Optional[bool]:
    """
    ¿La referencia al manual existe DE VERDAD en los manuales?

    Devuelve:
        None  — la categoría no afirma contenido del manual: no aplica.
        True  — el fragmento aparece literalmente en los manuales.
        False — se afirma que el manual dice algo y no se puede acreditar:
                referencia vacía, demasiado corta para ser concluyente, o
                ausente del texto.

    La comparación normaliza espacios y mayúsculas por la misma razón que
    `motor_ia._verificar_citas`: los extractores de PDF desordenan los espacios
    («ventana  de   250  días») y el modelo los recompone al citar. Sin
    normalizar, una cita correcta se marcaría como falsa y el aviso se volvería
    ruido que el equipo aprendería a ignorar.

    Un False NO invalida el hallazgo —puede ser real y estar mal citado— sino
    que lo marca para que el validador humano lo compruebe antes de firmar.
    Descartarlo en silencio perdería hallazgos verdaderos; darlo por bueno
    permitiría acusar al modelo validado sin prueba. Se declara, que es la
    política del proyecto ante toda duda.
    """
    ref = " ".join(str(referencia or "").split())
    exige = categoria in CATEGORIAS_QUE_AFIRMAN_EL_MANUAL

    if not ref:
        # Sin referencia: es un problema solo si la categoría la exigía.
        return False if exige else None

    # [AUDIT-FIX 2ª pasada] TODA referencia aportada se verifica, exija la
    # categoría o no. Detectado en la primera corrida real: un hallazgo
    # `supuesto_tacito` —categoría que NO exige anclaje— citó por su cuenta
    # «nivel de confianza 99%», y esa cita viajó al Word sin sello. Resultó
    # ser correcta, pero el informe no lo decía: el lector veía
    # «Documentación: …» sin saber si alguien lo había comprobado.
    #
    # La distinción por categoría sigue viva y sigue siendo necesaria, pero
    # gobierna otra cosa: si la AUSENCIA de referencia es un defecto. Que el
    # modelo cite de más es bueno; que su cita no se compruebe, no.
    # [AUDIT-FIX 3ª pasada] CITAS COSIDAS. Detectado en la corrida contra
    # `modelos/VaR_FixtureDrift`: el modelo elidió el texto intermedio con
    # `[...]`, práctica normal al citar:
    #
    #   «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a
    #    un año de observaciones. [...] Ambos parámetros son fijos: no se
    #    admite su m»
    #
    # Las DOS mitades están literalmente en el manual y la afirmación era
    # cierta, pero la comparación de la cadena completa fallaba y el hallazgo
    # salía SIN ANCLAR. Un falso positivo sobre una cita bien formada es el
    # peor resultado posible aquí: enseña al equipo a ignorar el aviso, y
    # entonces las citas realmente inventadas pasan con él.
    #
    # Se verifica cada tramo por separado: la elisión significa «hay texto en
    # medio», no «me lo he inventado». Siguen exigiéndose TODOS los tramos y el
    # mínimo de longitud sobre el total, así que trocear no relaja la prueba.
    tramos = [t.strip() for t in _RE_ELISION.split(ref) if t.strip()]
    if not tramos or sum(len(t) for t in tramos) < MIN_CHARS_REFERENCIA or not manual:
        # Demasiado corta para ser concluyente. Si la categoría no exigía
        # anclaje, no se acusa: simplemente no se pudo verificar.
        return False if exige else None

    plano = " ".join(str(manual).split()).lower()
    return all(t.lower() in plano for t in tramos)

# Carpetas de dependencias de terceros. NO se excluyen por defecto: el operador
# pidió explícitamente que solo se excluyera `.env`. Se activan con
# VIRF_EXCLUIR_DEPENDENCIAS=1.
PATRONES_DEPENDENCIAS = frozenset({
    "site-packages", ".venv", "venv", "env", "node_modules", "vendor",
    ".tox", ".eggs", "dist-info",
})

# [CONFIG-CENTRAL] Los tres parámetros de este módulo se declaran en
# config/parametros.py, no aquí. Una primera versión los leía con `os.getenv`
# en este fichero y el test `TestConfigCentral` lo rechazó, con razón: el
# proyecto ya pagó tener VIRF_MAX_CTX declarado en dos sitios con defaults
# distintos. Se conservan los nombres locales como alias, igual que hacen
# chunker.py y Mx_01, para no obligar a quien importe a conocer la ruta.
from config.parametros import (
    MAX_CHARS_MANUAL_REVISION as MAX_CHARS_MANUAL_CONTEXTO,
    MAX_CHARS_MODULO as MAX_CHARS_MODULO_POR_LLAMADA,
)


@dataclass
class HallazgoCodigo:
    """Un hallazgo atribuido a un punto concreto del código."""
    fichero: str
    linea: Optional[int]
    categoria: str
    severidad: str
    elemento: str          # función, clase o bloque afectado
    descripcion: str
    evidencia_codigo: str = ""
    referencia_manual: str = ""
    #: None = la categoría no afirma contenido del manual; True/False = la
    #: referencia se contrastó contra el texto de los manuales.
    referencia_verificada: Optional[bool] = None
    #: Categoría tal como la devolvió el modelo, antes de corregirla. Se guarda
    #: SIEMPRE: corregir sin dejar rastro impediría a un auditor distinguir lo
    #: que dictaminó el modelo de lo que ajustó el agente.
    categoria_declarada: str = ""
    #: Por qué se corrigió, o None si la categoría del modelo se respetó.
    motivo_recategorizacion: Optional[str] = None

    def a_dict(self) -> Dict[str, Any]:
        return {
            "fichero": self.fichero,
            "linea": self.linea,
            "categoria": self.categoria,
            "severidad": self.severidad,
            "elemento": self.elemento,
            "descripcion": self.descripcion,
            "evidencia_codigo": self.evidencia_codigo,
            "referencia_manual": self.referencia_manual,
            # [AUDIT-FIX] Viaja al JSON sellado: es lo que permite a un auditor
            # separar «el manual dice esto, comprobado» de «el agente afirma
            # que el manual dice esto». Sin el campo, ambas cosas se leen igual.
            "referencia_verificada": self.referencia_verificada,
            "categoria_declarada": self.categoria_declarada,
            "motivo_recategorizacion": self.motivo_recategorizacion,
        }

    @property
    def ubicacion(self) -> str:
        return f"{self.fichero}:{self.linea}" if self.linea else self.fichero


# ─────────────────────────────────────────────────────────────────────────────
# Descubrimiento e inventario
# ─────────────────────────────────────────────────────────────────────────────

def _excluir_dependencias_activo() -> bool:
    """
    Lee el flag EN RUNTIME, no al importar.

    La constante `config.parametros.EXCLUIR_DEPENDENCIAS` se fija al importar el
    módulo, lo que basta para una corrida normal pero impide que un test cambie
    el entorno después. Se delega en la misma función de parseo del paquete de
    configuración para que «1/true/sí» signifiquen lo mismo aquí que en el resto
    del proyecto — reimplementar el parseo booleano es cómo divergen dos
    lecturas del mismo flag.
    """
    from config.parametros import _booleano
    return _booleano("VIRF_EXCLUIR_DEPENDENCIAS", False)


def descubrir_modulos(raiz, extensiones=None) -> List[Path]:
    """
    Módulos de código bajo `raiz`, recursivo.

    Reutiliza `Mx_01._es_evidencia()` como criterio de exclusión para no tener
    un segundo catálogo de qué se ignora: esa función ya descarta `__pycache__`,
    `.git`, `.ipynb_checkpoints`, `datasets/`, los temporales de Office (`~$`) y
    todo fichero oculto — incluido `.env`, que es lo único que el operador pidió
    excluir explícitamente.
    """
    raiz = Path(raiz)
    if not raiz.is_dir():
        return []

    if extensiones is None:
        try:
            from motor.Mx_01_LecturaEvidencias import EXTENSIONES_CODIGO
            extensiones = set(EXTENSIONES_CODIGO)
        except ImportError:
            extensiones = {".py", ".ipynb"}

    try:
        from motor.Mx_01_LecturaEvidencias import _es_evidencia
    except ImportError:                                   # pragma: no cover
        def _es_evidencia(p):                             # noqa: E306
            return not p.name.startswith((".", "~$"))

    encontrados: List[Path] = []
    excluir_deps = _excluir_dependencias_activo()

    for path in sorted(raiz.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in extensiones:
            continue
        if not _es_evidencia(path):
            continue
        if excluir_deps:
            partes = {p.lower() for p in path.parts}
            if partes & PATRONES_DEPENDENCIAS:
                continue
        encontrados.append(path)
    return encontrados


def inventario(modulos: List[Path], raiz=None,
               chars_manual: int = 0) -> Dict[str, Any]:
    """
    Inventario con coste estimado. NO llama al modelo.

    El coste se calcula sobre lo que realmente se va a enviar: el código de cada
    módulo MÁS el manual repetido en cada llamada. Omitir el manual daría una
    cifra optimista justo en el factor que más pesa cuando hay muchos módulos.
    """
    from config.modelos import CHARS_POR_TOKEN_ES, precio_entrada_por_mtok

    raiz = Path(raiz) if raiz else None
    detalle = []
    chars_codigo = 0
    n_llamadas = 0

    for m in modulos:
        try:
            chars = len(m.read_text(encoding="utf-8", errors="replace"))
        except OSError as exc:
            logger.warning("No se pudo medir '%s': %s", m, exc)
            chars = 0
        # Un módulo por encima del tope se parte en varias llamadas.
        llamadas = max(1, -(-chars // MAX_CHARS_MODULO_POR_LLAMADA)) if chars else 1
        chars_codigo += chars
        n_llamadas += llamadas
        detalle.append({
            "fichero": str(m.relative_to(raiz)) if raiz and raiz in m.parents else m.name,
            "chars": chars,
            "llamadas": llamadas,
            "tipo": m.suffix.lstrip(".").upper(),
        })

    manual_efectivo = min(chars_manual, MAX_CHARS_MANUAL_CONTEXTO)
    chars_totales = chars_codigo + manual_efectivo * n_llamadas
    tokens = chars_totales / CHARS_POR_TOKEN_ES

    try:
        from motor.Mx_00_CargaRutas import MODELO_IA as _modelo
    except ImportError:                                   # pragma: no cover
        _modelo = None
    precio = precio_entrada_por_mtok(_modelo)

    return {
        "n_modulos": len(modulos),
        "n_llamadas": n_llamadas,
        "chars_codigo": chars_codigo,
        "chars_manual_por_llamada": manual_efectivo,
        "chars_totales_entrada": int(chars_totales),
        "tokens_estimados": int(tokens),
        "modelo": _modelo or "(desconocido)",
        "precio_entrada_usd_mtok": precio,
        "coste_estimado_usd": round(tokens / 1_000_000 * precio, 4),
        "detalle": sorted(detalle, key=lambda d: -d["chars"]),
        "dependencias_excluidas": _excluir_dependencias_activo(),
    }


def formatear_inventario(inv: Dict[str, Any], max_filas: int = 25) -> str:
    """Inventario legible para consola. Se imprime SIEMPRE antes de gastar."""
    sep = "═" * 74
    lin = [
        "", sep,
        "  🔍 INVENTARIO DE REVISIÓN DE CÓDIGO",
        sep,
        f"  Módulos encontrados : {inv['n_modulos']}",
        f"  Llamadas al modelo  : {inv['n_llamadas']}",
        f"  Código              : {inv['chars_codigo']:,} chars",
        f"  Manual por llamada  : {inv['chars_manual_por_llamada']:,} chars "
        f"(× {inv['n_llamadas']} llamadas)",
        f"  Entrada total       : {inv['chars_totales_entrada']:,} chars "
        f"≈ {inv['tokens_estimados']:,} tokens",
        f"  Modelo              : {inv['modelo']} "
        f"(${inv['precio_entrada_usd_mtok']:.2f}/Mtok entrada)",
        f"  COSTE ESTIMADO      : ~${inv['coste_estimado_usd']:.4f}",
    ]
    if not inv["dependencias_excluidas"]:
        lin.append("  ⚠️  Filtro de dependencias DESACTIVADO: si el árbol incluye")
        lin.append("      .venv/ o site-packages/, sus módulos también se revisarán.")
        lin.append("      Actívalo con VIRF_EXCLUIR_DEPENDENCIAS=1")
    lin += ["  " + "─" * 70, "  Módulos (mayor primero):"]
    for d in inv["detalle"][:max_filas]:
        lin.append(f"    {d['fichero']:<48} {d['chars']:>9,} chars"
                   + (f"  [{d['llamadas']} llamadas]" if d["llamadas"] > 1 else ""))
    if len(inv["detalle"]) > max_filas:
        lin.append(f"    ... y {len(inv['detalle']) - max_filas} módulo(s) más")
    lin += [sep, ""]
    return "\n".join(lin)


# ─────────────────────────────────────────────────────────────────────────────
# Preparación del código para el prompt
# ─────────────────────────────────────────────────────────────────────────────

def _numerar_lineas(texto: str, desde: int = 1) -> str:
    """
    Prefija cada línea con su número.

    Sin esto los hallazgos no son accionables: un LLM no cuenta líneas de forma
    fiable y devuelve números inventados que apuntan a código que no es el
    citado. Dárselas escritas convierte la cita en verificable.
    """
    lineas = texto.splitlines()
    ancho = len(str(desde + len(lineas)))
    return "\n".join(f"{i:>{ancho}} | {l}"
                     for i, l in enumerate(lineas, start=desde))


# Fronteras de definición por lenguaje. Cortar aquí —y no por ventanas de
# caracteres— evita partir una función por la mitad: media función revisada
# contra el manual produce hallazgos FALSOS («no valida la entrada» cuando la
# validación se quedó en el otro bloque).
FRONTERAS_POR_LENGUAJE = {
    # Definiciones de nivel superior, sin indentar.
    "python": re.compile(r"^(?:def |class |@|async def )"),
    # R declara funciones por asignación: `estimar <- function(x)`. También se
    # admite `=` porque hay bases de código que lo usan.
    "r":      re.compile(r"^\s*[\w.]+\s*(?:<-|=)\s*function\s*\("),
    # SQL no tiene funciones de nivel superior en el mismo sentido: la unidad
    # natural es la sentencia. Se corta en las que empiezan un objeto o una
    # consulta, que es lo que un validador contrasta contra el manual.
    "sql":    re.compile(
        r"^\s*(?:CREATE|INSERT|UPDATE|DELETE|MERGE|WITH|SELECT|DROP|ALTER|"
        r"TRUNCATE|GRANT)\b", re.IGNORECASE),
}

# Lenguajes en los que una frontera SOLO es válida si la sentencia anterior ya
# terminó. En SQL, `SELECT` es token de frontera y también aparece DENTRO de
# `CREATE TABLE x AS SELECT …`: sin esta guarda, el corte partía esa sentencia
# en dos y cada mitad se revisaba por separado — media consulta contrastada
# contra el manual produce el mismo hallazgo falso que media función.
_EXIGEN_TERMINADOR = {"sql": ";"}


def _sentencia_cerrada(acumulado: List[str], terminador: str) -> bool:
    """True si el texto acumulado termina en el terminador de sentencia."""
    texto = "".join(acumulado).rstrip()
    # Se ignoran los comentarios de línea finales: `; -- carga inicial` cierra.
    while texto.endswith(("*/",)) or "--" in texto.split("\n")[-1]:
        lineas = texto.split("\n")
        if "--" in lineas[-1]:
            lineas[-1] = lineas[-1].split("--")[0]
        texto = "\n".join(lineas).rstrip()
        if not texto or not ("--" in texto.split("\n")[-1]):
            break
    return texto.endswith(terminador)


def _lenguaje_de(ruta) -> str:
    """
    Lenguaje del fichero a partir de su extensión.

    Se delega en el catálogo de `Mx_01` para no tener un segundo mapa: si
    mañana se añade una extensión allí y aquí no, el fichero se revisaría
    etiquetado como Python y troceado con fronteras que no son las suyas.
    """
    try:
        from motor.Mx_01_LecturaEvidencias import LENGUAJE_POR_EXT
    except ImportError:                                   # pragma: no cover
        LENGUAJE_POR_EXT = {".py": "python", ".ipynb": "python",
                            ".sql": "sql", ".r": "r"}
    return LENGUAJE_POR_EXT.get(Path(ruta).suffix.lower(), "python")


def _partir_por_definiciones(texto: str, max_chars: int,
                             lenguaje: str = "python") -> List[tuple]:
    """
    Parte un módulo grande en bloques que empiezan en una frontera de definición.

    Devuelve [(linea_inicial, texto_bloque), …].

    `lenguaje` decide dónde está esa frontera (ver FRONTERAS_POR_LENGUAJE). Con
    el default de Python aplicado a un script de R, NINGUNA línea casaría y el
    fichero entero caería al reparto por ventanas: funcionaría, pero cortando
    funciones por la mitad, que es justo lo que este corte existe para evitar.
    """
    lineas = texto.splitlines(keepends=True)
    if len(texto) <= max_chars:
        return [(1, texto)]

    frontera = FRONTERAS_POR_LENGUAJE.get(
        lenguaje, FRONTERAS_POR_LENGUAJE["python"])
    bloques: List[tuple] = []
    actual: List[str] = []
    linea_inicio = 1
    chars = 0

    terminador = _EXIGEN_TERMINADOR.get(lenguaje)

    for idx, linea in enumerate(lineas, start=1):
        es_frontera = bool(frontera.match(linea))
        # En SQL, una frontera a mitad de sentencia no es frontera.
        if es_frontera and terminador and actual:
            es_frontera = _sentencia_cerrada(actual, terminador)
        if actual and es_frontera and chars + len(linea) > max_chars:
            bloques.append((linea_inicio, "".join(actual)))
            actual, chars, linea_inicio = [], 0, idx
        actual.append(linea)
        chars += len(linea)

    if actual:
        bloques.append((linea_inicio, "".join(actual)))

    # Si el fichero no tiene definiciones de nivel superior (un script plano),
    # no hay frontera donde cortar: se cae a ventanas de líneas.
    #
    # El corte se hace acumulando CARACTERES, no un número fijo de líneas. Una
    # primera versión usaba `paso = max_chars // 80` asumiendo 80 chars por
    # línea: con un script de líneas cortas (`x = 1`) partía 18.000 chars en 49
    # bloques de ~370 chars, es decir 49 llamadas donde bastaban 4. El ancho de
    # línea es un dato del fichero, no una constante que se pueda suponer.
    if len(bloques) == 1 and len(texto) > max_chars:
        bloques = []
        actual, chars, linea_inicio = [], 0, 1
        for idx, linea in enumerate(lineas, start=1):
            if actual and chars + len(linea) > max_chars:
                bloques.append((linea_inicio, "".join(actual)))
                actual, chars, linea_inicio = [], 0, idx
            actual.append(linea)
            chars += len(linea)
        if actual:
            bloques.append((linea_inicio, "".join(actual)))
    return bloques


# ─────────────────────────────────────────────────────────────────────────────
# El revisor
# ─────────────────────────────────────────────────────────────────────────────

_PROMPT_REVISION = """\
Eres un validador de modelos de riesgo (segunda línea de defensa) revisando el
CÓDIGO de un modelo cuantitativo contra su DOCUMENTACIÓN.

Tu veredicto sobre el código NO es una opinión técnica: es un dictamen que debe
poder ANCLARSE en la documentación. Un hallazgo que no puedas sostener con lo
que dicen los manuales no es un hallazgo de validación — es una preferencia
tuya sobre cómo se escribe código, y eso no va en este informe.

## Documentación del modelo
Cada documento viene rotulado con su rol. Úsalo: el manual METODOLÓGICO declara
qué debe hacer el modelo, y el de SEGUIMIENTO qué se ha observado al ejecutarlo
(backtesting, excepciones, recalibraciones). Una discrepancia entre el código y
lo que el seguimiento dice haber medido vale tanto como una contra el manual.

{manual}

## Módulo bajo revisión: {fichero}{nota_bloque}
Lenguaje: {lenguaje}
```{lenguaje}
{codigo}
```

## Tu tarea

Contrasta ESTE módulo contra la documentación de arriba y devuelve hallazgos.

REGLAS QUE NO PUEDES INCUMPLIR:

1. Cita SIEMPRE el número de línea que aparece a la izquierda del código. No
   inventes números: si no puedes ubicar algo, pon `null`.
2. Si la documentación NO menciona el área que cubre este módulo, dilo con la
   categoría `no_documentado`. No supongas que "estará documentado en otra
   parte".
3. ANCLAJE OBLIGATORIO EN LA DOCUMENTACIÓN. Si tu hallazgo AFIRMA lo que la
   documentación dice —categorías `documentado_ausente` y `code_drift`—, tienes
   que copiar en `referencia_manual` un fragmento LITERAL de los documentos de
   arriba, de al menos 40 caracteres, que lo demuestre.

   Ese fragmento SE VERIFICA automáticamente contra el texto de los manuales. Si
   no aparece literalmente, el hallazgo se marca como NO ANCLADO en el informe y
   un humano tendrá que comprobarlo antes de firmar. No parafrasees, no cites
   solo «§4.2»: copia el texto tal cual está.

   Si no encuentras un fragmento que sostenga la afirmación, NO uses esas dos
   categorías. Reconsidera: probablemente lo que has visto es `no_documentado`
   (está en el código y el manual no lo trata) o `supuesto_tacito`.

   Para `no_documentado`, `supuesto_tacito` y `riesgo_tecnico` deja
   `referencia_manual` vacío: afirman una AUSENCIA en la documentación, y una
   ausencia no se puede citar.
4. Si el módulo es coherente con la documentación, devuelve `hallazgos: []`.
   Un módulo correcto es un resultado válido — no fuerces hallazgos.
5. Solo estas categorías: {categorias}
6. Solo estas severidades: {severidades}

Devuelve EXCLUSIVAMENTE un objeto JSON con esta forma:

{{
  "resumen_modulo": "qué hace este módulo, en dos frases",
  "elementos_definidos": ["nombre_funcion_o_clase", "..."],
  "hallazgos": [
    {{
      "linea": 87,
      "categoria": "no_documentado",
      "severidad": "alta",
      "elemento": "_ajuste_cornish_fisher",
      "descripcion": "Aplica un ajuste de Cornish-Fisher que la documentación no menciona.",
      "evidencia_codigo": "z + (z**2 - 1) * skew / 6",
      "referencia_manual": ""
    }}
  ]
}}
"""


class RevisorCodigo:
    """
    Revisa el código de un modelo contra su documentación, módulo a módulo.

    El cliente IA se inyecta ya inicializado, igual que en `ChunkerService`: así
    el pre-flight de credencial protege esta fase y el rate limiting queda en un
    único punto.
    """

    def __init__(self, cliente_ia, max_chars_modulo: Optional[int] = None,
                 max_chars_manual: Optional[int] = None):
        self.cliente = cliente_ia
        self.max_chars_modulo = max_chars_modulo or MAX_CHARS_MODULO_POR_LLAMADA
        self.max_chars_manual = max_chars_manual or MAX_CHARS_MANUAL_CONTEXTO
        self._llamadas = 0
        self._fallos: List[Dict] = []

    # ── una llamada ─────────────────────────────────────────────────────────
    def revisar_bloque(self, fichero: str, codigo_numerado: str, manual: str,
                       nota_bloque: str = "",
                       lenguaje: str = "python") -> Dict[str, Any]:
        prompt = _PROMPT_REVISION.format(
            manual=manual or "⚠️ SIN DOCUMENTACIÓN METODOLÓGICA DISPONIBLE.",
            fichero=fichero,
            nota_bloque=nota_bloque,
            lenguaje=lenguaje,
            codigo=codigo_numerado,
            categorias=", ".join(f"`{k}`" for k in CATEGORIAS_HALLAZGO),
            severidades=", ".join(f"`{s}`" for s in SEVERIDADES),
        )
        self._llamadas += 1
        respuesta = self.cliente.generar_mensaje(
            prompt=prompt,
            instruccion_sistema=(
                "Validador de modelos de riesgo. Respondes SOLO con JSON válido. "
                "No inventas contenido documental ni números de línea."
            ),
        )
        res = self._parsear(respuesta, fichero)
        # [BLOQUE 4] Estos hallazgos también producen puntaje y pesan en el
        # score del ámbito Implementación: deben poder responder «¿qué prompt
        # produjo esto?» igual que las actividades del estándar.
        from modulos.huella_prompts import sha256_texto
        res["prompt_sha256"] = sha256_texto(prompt)[:12]
        res["prompt_chars"] = len(prompt)
        return res

    @staticmethod
    def _parsear(respuesta: str, fichero: str) -> Dict[str, Any]:
        """
        Parsea la respuesta reutilizando el ÚNICO extractor JSON del proyecto.

        `motor_ia._extraer_json` cuenta llaves siendo consciente de strings y
        escapes. El proyecto ya pagó tener dos parsers —uno débil basado en
        `find`/`rfind` que fusionaba dos objetos seguidos en JSON inválido— y
        hay un test (`TestAuditoriaUnSoloParserJSON`) que impide reintroducirlo.
        """
        from modulos.motor_ia import _extraer_json
        try:
            return _extraer_json(respuesta)
        except json.JSONDecodeError as exc:
            logger.warning("JSON no parseable en '%s': %s", fichero, exc)
            return {
                "resumen_modulo": "",
                "elementos_definidos": [],
                "hallazgos": [],
                "_error_parseo": str(exc),
                "_raw": (respuesta or "")[:500],
            }

    # ── un módulo (puede ser varias llamadas) ───────────────────────────────
    def revisar_modulo(self, ruta: Path, manual: str,
                       nombre_relativo: Optional[str] = None) -> Dict[str, Any]:
        nombre = nombre_relativo or ruta.name
        try:
            from motor.Mx_01_LecturaEvidencias import LECTORES_EXT
            lector = LECTORES_EXT.get(ruta.suffix.lower())
            texto = lector(ruta) if lector else ruta.read_text(
                encoding="utf-8", errors="replace")
        except Exception as exc:                          # noqa: BLE001
            logger.error("No se pudo leer '%s': %s", nombre, exc)
            self._fallos.append({"fichero": nombre, "error": str(exc)})
            return {"fichero": nombre, "error": str(exc),
                    "hallazgos": [], "revision_valida": False}

        # El lenguaje decide DÓNDE se corta el fichero y con qué etiqueta viaja
        # al prompt. Un script de R troceado con las fronteras de Python cortaría
        # funciones por la mitad, y presentarlo como ```python invita al modelo a
        # "corregir" sintaxis que no está rota.
        lenguaje = _lenguaje_de(ruta)

        bloques = _partir_por_definiciones(texto, self.max_chars_modulo, lenguaje)
        hallazgos: List[Dict] = []
        elementos: List[str] = []
        resumenes: List[str] = []
        hashes_prompt: List[str] = []
        valida = True

        for i, (linea_ini, bloque) in enumerate(bloques, start=1):
            nota = (f" (bloque {i}/{len(bloques)}, desde la línea {linea_ini})"
                    if len(bloques) > 1 else "")
            numerado = _numerar_lineas(bloque, desde=linea_ini)
            try:
                res = self.revisar_bloque(nombre, numerado, manual, nota,
                                          lenguaje=lenguaje)
            except Exception as exc:                      # noqa: BLE001
                # Un fallo técnico NO se convierte en "módulo sin hallazgos":
                # se marca, igual que hace el pipeline con las actividades.
                logger.error("Fallo revisando '%s' bloque %d: %s", nombre, i, exc)
                self._fallos.append({"fichero": nombre, "bloque": i,
                                     "error": str(exc)})
                valida = False
                continue

            if res.get("_error_parseo"):
                valida = False
            if res.get("prompt_sha256"):
                hashes_prompt.append(res["prompt_sha256"])
            resumenes.append(str(res.get("resumen_modulo", "")).strip())
            elementos.extend(str(e) for e in (res.get("elementos_definidos") or []))
            for h in (res.get("hallazgos") or []):
                hallazgos.append(
                    self._normalizar_hallazgo(h, nombre, manual, texto))

        return {
            "fichero": nombre,
            "lenguaje": lenguaje,
            # Un módulo troceado hace varias llamadas: se listan todas.
            "prompt_sha256": hashes_prompt,
            "chars": len(texto),
            "n_bloques": len(bloques),
            "resumen_modulo": " ".join(r for r in resumenes if r)[:600],
            "elementos_definidos": sorted(set(elementos)),
            "hallazgos": hallazgos,
            "revision_valida": valida,
        }

    @staticmethod
    def _normalizar_hallazgo(bruto: Dict, fichero: str,
                             manual: str = "",
                             codigo: str = "") -> Dict[str, Any]:
        """
        Normaliza un hallazgo del modelo al contrato interno.

        Categorías y severidades fuera del catálogo se reetiquetan en vez de
        descartarse: un hallazgo real con la etiqueta mal puesta sigue siendo un
        hallazgo, y perderlo por un problema de vocabulario sería peor que
        clasificarlo como genérico.
        """
        cat = str(bruto.get("categoria", "")).strip().lower()
        if cat not in CATEGORIAS_HALLAZGO:
            cat = "riesgo_tecnico"
        sev = str(bruto.get("severidad", "")).strip().lower()
        if sev not in SEVERIDADES:
            sev = "media"
        _elem = str(bruto.get("elemento", ""))[:120]
        # [AUDIT-FIX] La categoría se corrige ANTES de verificar la cita.
        # El orden importa: una `no_documentado` mal puesta que en realidad
        # afirma lo que dice el manual pasa a `documentado_ausente`, y ESA sí
        # exige anclaje. Verificar primero la dejaría escapar igual que antes.
        _cat_declarada = cat
        cat, _motivo_recat = recategorizar(cat, _elem, codigo, manual)
        _ref = str(bruto.get("referencia_manual", ""))[:300]
        linea = bruto.get("linea")
        try:
            linea = int(linea) if linea is not None else None
        except (TypeError, ValueError):
            linea = None
        return HallazgoCodigo(
            fichero=fichero,
            linea=linea,
            categoria=cat,
            severidad=sev,
            elemento=_elem,
            descripcion=str(bruto.get("descripcion", ""))[:800],
            evidencia_codigo=str(bruto.get("evidencia_codigo", ""))[:300],
            referencia_manual=_ref,
            # [AUDIT-FIX] La referencia se COMPRUEBA contra el texto real de
            # los manuales, no se acepta por venir escrita. Pedir una cita
            # sin verificarla es el peor de los dos mundos: parece
            # verificable, así que nadie la contrasta.
            referencia_verificada=verificar_referencia_manual(_ref, cat, manual),
            categoria_declarada=_cat_declarada,
            motivo_recategorizacion=_motivo_recat,
        ).a_dict()

    # ── el árbol completo ───────────────────────────────────────────────────
    def revisar(self, modulos: List[Path], manual: str,
                raiz=None, verbose: bool = True) -> Dict[str, Any]:
        raiz = Path(raiz) if raiz else None
        manual_recortado = (manual or "")[:self.max_chars_manual]
        if manual and len(manual) > self.max_chars_manual:
            logger.info("Manual recortado a %d de %d chars para la revisión.",
                        self.max_chars_manual, len(manual))

        resultados = []
        for i, m in enumerate(modulos, start=1):
            rel = (str(m.relative_to(raiz))
                   if raiz and raiz in m.parents else m.name)
            if verbose:
                print(f"    [{i}/{len(modulos)}] revisando {rel} …", flush=True)
            res = self.revisar_modulo(m, manual_recortado, nombre_relativo=rel)
            if verbose:
                n = len(res.get("hallazgos", []))
                estado = "✗ fallo" if not res.get("revision_valida") else f"{n} hallazgo(s)"
                print(f"         → {estado}")
            resultados.append(res)

        return self.consolidar(resultados, manual_disponible=bool(manual))

    def consolidar(self, resultados: List[Dict],
                   manual_disponible: bool = True) -> Dict[str, Any]:
        """Agrega los resultados por módulo en un informe único."""
        todos: List[Dict] = []
        for r in resultados:
            todos.extend(r.get("hallazgos", []))

        por_categoria: Dict[str, List[Dict]] = {k: [] for k in CATEGORIAS_HALLAZGO}
        for h in todos:
            por_categoria.setdefault(h["categoria"], []).append(h)

        por_severidad = {s: sum(1 for h in todos if h["severidad"] == s)
                         for s in SEVERIDADES}

        n_validos = sum(1 for r in resultados if r.get("revision_valida"))
        n_fallidos = len(resultados) - n_validos

        # [AUDIT-FIX] Anclaje en los manuales. `n_anclados` son los hallazgos
        # que AFIRMAN algo del manual y lo acreditan con un fragmento que existe
        # de verdad; `n_sin_anclar`, los que lo afirman sin poder acreditarlo.
        #
        # La cifra va al informe porque es la que responde a la pregunta del
        # auditor: «¿esta discrepancia está probada, o el agente dice que el
        # manual dice algo?». Un hallazgo sin anclar puede ser cierto, pero no
        # es presentable sin que una persona lo compruebe.
        _afirman = [h for h in todos
                    if h.get("referencia_verificada") is not None]
        n_anclados = sum(1 for h in _afirman if h["referencia_verificada"])
        n_sin_anclar = len(_afirman) - n_anclados
        # Categorías que el modelo puso mal y el agente corrigió contra los
        # hechos. Se cuenta porque una cifra alta dice algo del modelo, no
        # del modelo validado: es señal de calibración del juez.
        n_recat = sum(1 for h in todos if h.get("motivo_recategorizacion"))

        return {
            "n_modulos": len(resultados),
            "n_modulos_revisados_ok": n_validos,
            "n_modulos_con_fallo": n_fallidos,
            "n_llamadas": self._llamadas,
            "manual_disponible": manual_disponible,
            "n_hallazgos": len(todos),
            "n_hallazgos_anclados_al_manual": n_anclados,
            "n_hallazgos_sin_anclar": n_sin_anclar,
            "n_categorias_corregidas": n_recat,
            "por_severidad": por_severidad,
            "por_categoria": {k: len(v) for k, v in por_categoria.items()},
            "hallazgos": sorted(
                todos,
                key=lambda h: (SEVERIDADES.index(h["severidad"])
                               if h["severidad"] in SEVERIDADES else 99,
                               h["fichero"], h["linea"] or 0),
            ),
            "modulos": resultados,
            "fallos_tecnicos": self._fallos,
            # Misma semántica que en el pipeline: si algún módulo falló
            # técnicamente, la revisión está incompleta y no debe sostener un
            # dictamen. No se disimula con "0 hallazgos".
            "revision_confiable": n_fallidos == 0 and len(resultados) > 0,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Informe legible
# ─────────────────────────────────────────────────────────────────────────────

_ICONO_SEV = {"critica": "🔴", "alta": "🟠", "media": "🟡", "baja": "⚪"}


def informe_markdown(cons: Dict[str, Any], modelo: str = "") -> str:
    """Informe Markdown del resultado consolidado."""
    from datetime import datetime

    lin = [
        f"# Revisión de código contra documentación — {modelo or 'modelo'}",
        "",
        f"Generado por `modulos/revision_codigo.py` el "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M')}.",
        "",
        "## Resumen",
        "",
        f"- Módulos revisados: **{cons['n_modulos_revisados_ok']}/{cons['n_modulos']}**",
        f"- Llamadas al modelo: {cons['n_llamadas']}",
        f"- Hallazgos: **{cons['n_hallazgos']}**",
        f"- Anclados en la documentación: "
        f"**{cons.get('n_hallazgos_anclados_al_manual', 0)}** "
        f"(sin anclar: {cons.get('n_hallazgos_sin_anclar', 0)})",
        f"- Revisión confiable: **{cons['revision_confiable']}**",
    ]
    if cons.get("n_categorias_corregidas"):
        lin += ["", f"> ℹ️ {cons['n_categorias_corregidas']} categoría(s) "
                    f"corregidas: el modelo las etiquetó de forma que "
                    f"contradecía los hechos (elemento presente o ausente del "
                    f"código o del manual). La categoría original se conserva "
                    f"en el JSON como `categoria_declarada`."]
    if cons.get("n_hallazgos_sin_anclar"):
        lin += ["", f"> ⚠️ **{cons['n_hallazgos_sin_anclar']} hallazgo(s) afirman "
                    f"lo que dice la documentación sin poder acreditarlo** con un "
                    f"fragmento literal. Pueden ser ciertos, pero acusan al modelo "
                    f"validado de una discrepancia sin la prueba delante: "
                    f"compruébalos contra el manual antes de firmar. Van marcados "
                    f"como `SIN ANCLAR` más abajo."]
    if not cons["manual_disponible"]:
        lin += ["", "> ⚠️ **No había documentación metodológica.** Los hallazgos "
                    "describen el código, pero NO son un contraste: sin manual no "
                    "hay nada contra lo que comparar."]
    if cons["n_modulos_con_fallo"]:
        lin += ["", f"> ⚠️ **{cons['n_modulos_con_fallo']} módulo(s) no se "
                    f"revisaron por fallo técnico.** La revisión está incompleta; "
                    f"re-ejecuta antes de emitir dictamen."]

    lin += ["", "### Por severidad", ""]
    for s in SEVERIDADES:
        lin.append(f"- {_ICONO_SEV[s]} {s}: {cons['por_severidad'].get(s, 0)}")

    lin += ["", "### Por categoría", ""]
    for k, desc in CATEGORIAS_HALLAZGO.items():
        lin.append(f"- `{k}` ({desc}): {cons['por_categoria'].get(k, 0)}")

    lin += ["", "## Hallazgos", ""]
    if not cons["hallazgos"]:
        lin.append("Ninguno. El código revisado es coherente con la documentación.")
    for h in cons["hallazgos"]:
        ubic = f"{h['fichero']}:{h['linea']}" if h["linea"] else h["fichero"]
        lin += [
            f"### {_ICONO_SEV.get(h['severidad'], '·')} `{ubic}` — {h['elemento'] or '—'}",
            "",
            f"**Categoría:** `{h['categoria']}` · **Severidad:** {h['severidad']}",
            "",
            h["descripcion"],
        ]
        if h["evidencia_codigo"]:
            lin += ["", "```python", h["evidencia_codigo"], "```"]
        # [AUDIT-FIX] El estado del anclaje se pinta SIEMPRE que la categoría lo
        # exija, también —y sobre todo— cuando no hay referencia. Mostrar solo
        # las referencias presentes ocultaba justo el caso peligroso: un
        # `code_drift` sin cita se leía como un hallazgo más.
        _verif = h.get("referencia_verificada")
        if h["referencia_manual"]:
            _sello = {True: "✅ verificada en la documentación",
                      False: "⚠️ SIN ANCLAR — no se encontró literalmente",
                      None: ""}.get(_verif, "")
            lin += ["", f"> Documentación: {h['referencia_manual']}"]
            if _sello:
                lin += [f"> {_sello}"]
        elif _verif is False:
            lin += ["", "> ⚠️ **SIN ANCLAR** — este hallazgo afirma lo que dice la "
                        "documentación pero no aporta ningún fragmento que lo "
                        "acredite. Compruébalo antes de incluirlo en el informe."]
        lin.append("")

    lin += ["## Inventario de módulos", "",
            "| Módulo | Chars | Hallazgos | Revisión |", "|---|---:|---:|---|"]
    for m in sorted(cons["modulos"], key=lambda x: x.get("fichero", "")):
        ok = "✅" if m.get("revision_valida") else "❌ fallo"
        lin.append(f"| `{m.get('fichero','?')}` | {m.get('chars',0):,} | "
                   f"{len(m.get('hallazgos', []))} | {ok} |")
    return "\n".join(lin) + "\n"
