"""
modulos/skills/
═════════════════════════════════════════════════════════════════════════════
Skills de validación: análisis transversales sobre la evidencia.

El pipeline principal recorre el estándar VIRF actividad por actividad y
produce EL DICTAMEN. Las skills investigan preguntas que no caben en una
casilla del estándar y producen HALLAZGOS.

    Pipeline  →  ¿cumple cada control?       → puntajes  (el dictamen)
    Skills    →  ¿qué se nos está escapando?  → hallazgos (el análisis)

Las skills NO puntúan y NO alteran el score. Si lo hicieran, dos corridas con
distinta selección de skills dejarían de ser comparables, y la comparabilidad
entre corridas es lo que permite seguir la evolución de un modelo en el tiempo.

Uso:
    from modulos.skills import ejecutar_skills, listar_skills

    resultados = ejecutar_skills(
        ["coherencia", "supuestos", "sintesis"],
        contexto=texto_evidencia,
        titulo_modelo="Modelo VaR",
        evaluaciones=evaluaciones_del_pipeline,
    )
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

from modulos.skills.base import ResultadoSkill, SkillBase
from modulos.skills.catalogo import SKILLS, listar_skills, obtener_skill

logger = logging.getLogger("virf.skills")

__all__ = [
    "SkillBase", "ResultadoSkill", "SKILLS",
    "listar_skills", "obtener_skill", "ejecutar_skills", "resolver_seleccion",
]

# La síntesis consume la salida de las demás, así que siempre va al final.
_ULTIMA = "sintesis"


def resolver_seleccion(seleccion: str) -> List[str]:
    """
    Traduce el valor de `--skills` a una lista de nombres válidos y ordenados.

    Acepta:
        "all"                       → todas
        "coherencia,supuestos"      → esas dos
        "rapidas"                   → solo las de coste bajo

    Lanza ValueError si algún nombre no existe: fallar aquí es mejor que
    ejecutar seis skills y descubrir al final que la séptima estaba mal escrita.
    """
    bruto = (seleccion or "").strip().lower()
    if not bruto:
        return []

    if bruto == "all":
        nombres = list(SKILLS)
    elif bruto == "rapidas":
        nombres = [n for n, c in SKILLS.items() if c.coste_estimado == "bajo"]
    else:
        nombres = [n.strip() for n in bruto.split(",") if n.strip()]
        desconocidas = [n for n in nombres if n not in SKILLS]
        if desconocidas:
            raise ValueError(
                f"skill(s) desconocida(s): {', '.join(desconocidas)}. "
                f"Disponibles: {', '.join(SKILLS)}")

    # Sin duplicados, preservando el orden de aparición.
    vistos, orden = set(), []
    for n in nombres:
        if n not in vistos:
            vistos.add(n)
            orden.append(n)

    # `sintesis` al final, siempre.
    if _ULTIMA in orden:
        orden = [n for n in orden if n != _ULTIMA] + [_ULTIMA]
    return orden


def ejecutar_skills(
    nombres: List[str],
    contexto: str,
    titulo_modelo: str,
    evaluaciones: Optional[List[Dict]] = None,
    bloque_rag: str = "",
) -> List[ResultadoSkill]:
    """
    Ejecuta las skills indicadas, en orden, y devuelve sus resultados.

    NUNCA lanza. Cada skill captura sus propios errores y los declara en el
    resultado; ésta captura además cualquier fallo al instanciarla. El dictamen
    ya está calculado cuando esto corre: un análisis que falla debe restar
    información, no invalidar la corrida.
    """
    resultados: List[ResultadoSkill] = []

    for nombre in nombres:
        try:
            clase = obtener_skill(nombre)
        except ValueError as exc:
            logger.warning("%s", exc)
            continue

        print(f"    🔎 {clase.titulo}…", flush=True)
        try:
            if nombre == _ULTIMA:
                # La síntesis necesita ver lo que produjeron las demás.
                skill = clase(contexto, titulo_modelo, evaluaciones, bloque_rag,
                              resultados_previos=resultados)
            else:
                skill = clase(contexto, titulo_modelo, evaluaciones, bloque_rag)
            res = skill.ejecutar()
        except Exception as exc:                          # pragma: no cover
            res = ResultadoSkill(
                nombre=nombre, titulo=getattr(clase, "titulo", nombre),
                ok=False, hallazgos=[], resumen="",
                error=f"{type(exc).__name__}: {exc}",
                duracion_seg=0.0, citas_no_verificadas=[], prompt_sha256="")

        n = len(res.get("hallazgos") or [])
        if res.get("ok"):
            aviso = ""
            if res.get("citas_no_verificadas"):
                aviso = f"  ⚠️ {len(res['citas_no_verificadas'])} cita(s) sin verificar"
            print(f"       ✓ {n} hallazgo(s) en {res['duracion_seg']}s{aviso}")
        else:
            print(f"       ✗ falló: {res.get('error')}")
        resultados.append(res)

    return resultados
