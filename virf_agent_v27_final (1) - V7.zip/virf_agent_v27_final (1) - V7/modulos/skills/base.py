"""
modulos/skills/base.py
═════════════════════════════════════════════════════════════════════════════
Infraestructura común de las skills de validación.

QUÉ ES UNA SKILL Y QUÉ NO
─────────────────────────
El pipeline principal evalúa el estándar VIRF actividad por actividad: recorre
una lista cerrada de controles y puntúa cada uno. Es exhaustivo y comparable
entre corridas, y por eso es el que produce el dictamen.

Una SKILL hace lo contrario: un análisis TRANSVERSAL y profundo sobre una
pregunta que no cabe en una casilla del estándar. «¿El código implementa lo que
el manual dice?» no es una actividad — es una investigación que cruza dos
fuentes y produce hallazgos, no puntajes.

    Pipeline  →  ¿cumple cada control?      → puntajes (el dictamen)
    Skills    →  ¿qué se nos está escapando? → hallazgos (el análisis)

Por eso las skills NO puntúan. Alimentan al validador humano y al informe, y
dejan el dictamen donde estaba. Un análisis que además moviera el score haría
imposible comparar dos corridas con distinta selección de skills.

POR QUÉ ESTE FRAMEWORK Y NO EL DE `agent/` v28
──────────────────────────────────────────────
El subsistema `agent/` (aparcado el 2026-07-26) trae 17 skills mucho más
ambiciosas. No se reactiva tal cual por tres motivos, y este módulo los resuelve:

  1. Vive fuera del pipeline: sus hallazgos no entran en la cadena de custodia
     ni en el JSON sellado. Aquí sí.
  2. Lleva un mes sin ejecutarse contra un proyecto que cambió debajo (se fue
     ChromaDB, se fue `config/embeddings.py`, cambió el contrato de evaluación).
  3. 12.090 líneas es demasiado para retomar de golpe.

Estas skills son deliberadamente MÁS PEQUEÑAS: una pregunta, un prompt, un JSON
verificado. Lo que se gana es que se ejecutan de verdad, en cada corrida, y son
auditables.

CONTRATO DE UNA SKILL
─────────────────────
Cada skill declara `nombre`, `titulo`, `descripcion`, `ambitos_relevantes` y
`coste_estimado`, e implementa `construir_prompt()`. La base se encarga de:
llamar al modelo, parsear el JSON, verificar que las citas existan de verdad,
y degradar sin romper la corrida si algo falla.

    Una skill que falla NO tumba la validación. Es análisis adicional: si no
    sale, el dictamen sigue siendo válido y se declara qué no se pudo ejecutar.
"""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

logger = logging.getLogger("virf.skills")

__all__ = ["SkillBase", "ResultadoSkill"]


class ResultadoSkill(dict):
    """
    Lo que devuelve una skill. Es un dict para que viaje al JSON sin conversión.

    Claves fijas: nombre, titulo, ok, hallazgos, resumen, error, duracion_seg,
    citas_no_verificadas, prompt_sha256.
    """


class SkillBase(ABC):
    """
    Base de todas las skills. Subclasificar e implementar `construir_prompt`.

    Atributos que la subclase DEBE definir:
        nombre              identificador corto para `--skills`
        titulo              cómo aparece en el informe
        descripcion         qué investiga (sale en `--listar-skills`)
        ambitos_relevantes  ámbitos cuyos hallazgos le sirven de entrada
        coste_estimado      "bajo" | "medio" | "alto" — llamadas y tokens
    """

    nombre: str = "base"
    titulo: str = "Skill base"
    descripcion: str = ""
    ambitos_relevantes: List[str] = []
    coste_estimado: str = "medio"

    # Clave del JSON que contiene la lista de hallazgos. Se sobreescribe cuando
    # la skill devuelve otra cosa (p. ej. el challenger devuelve `hipotesis`).
    clave_hallazgos: str = "hallazgos"

    def __init__(self, contexto: str, titulo_modelo: str,
                 evaluaciones: Optional[List[Dict]] = None,
                 bloque_rag: str = ""):
        """
        Args:
            contexto:      la evidencia leída (el mismo texto que vio el pipeline)
            titulo_modelo: nombre del modelo bajo validación
            evaluaciones:  hallazgos ya producidos por el pipeline, para que la
                           skill no repita lo que ya se sabe
            bloque_rag:    literatura regulatoria recuperada, si aplica
        """
        self.contexto = contexto or ""
        self.titulo_modelo = titulo_modelo or "sin título"
        self.evaluaciones = evaluaciones or []
        self.bloque_rag = bloque_rag or ""

    # ── A implementar por cada skill ─────────────────────────────────────────

    @abstractmethod
    def construir_prompt(self) -> str:
        """Devuelve el prompt completo. La base añade las reglas comunes."""

    # ── Utilidades para las subclases ────────────────────────────────────────

    def _hallazgos_previos(self, limite: int = 12) -> str:
        """
        Resumen de lo que el pipeline ya encontró.

        Se inyecta para que la skill APORTE en vez de repetir. Sin esto, la
        primera mitad de cada respuesta es una reformulación de los puntajes que
        el validador ya tiene delante.
        """
        if not self.evaluaciones:
            return "(el pipeline no aportó hallazgos previos)"

        # [AUDIT-FIX · §3.4] Aquí había `key=lambda e: e.get("puntaje", 5)`, y
        # reventaba en producción:
        #
        #     TypeError: '<' not supported between instances of 'NoneType' and 'int'
        #
        # El respaldo de `.get` solo actúa si la clave FALTA, no si está
        # presente con valor nulo. Y el invariante 2 del proyecto produce
        # exactamente eso: una actividad con fallo técnico o sin evidencia se
        # guarda con `"puntaje": None` —la clave existe— para no inventar un
        # valor. Es decir, el propio invariante que protege el dictamen era el
        # que rompía las skills.
        #
        # Consecuencia medida en la corrida real del 2026-08-06: CINCO de las
        # ocho skills murieron en cuanto una sola actividad quedó sin puntuar.
        # Como una skill que falla no tumba la corrida —por diseño—, el fallo
        # se veía como «análisis no ejecutado» y no como el defecto que era.
        # En la práctica, las skills que leen hallazgos previos no funcionaban
        # en ninguna corrida que tuviera un fallo técnico.
        #
        # Tercera y cuarta aparición de esta trampa en el proyecto (§3.4 del
        # prompt de continuidad ya documentaba dos).
        def _orden(e):
            p = e.get("puntaje")
            # Las puntuadas primero y de peor a mejor —son los hallazgos que la
            # skill no debe repetir—; las no evaluadas al final, porque no
            # aportan un hallazgo, solo declaran una ausencia.
            return (1, 0) if p is None else (0, p)

        filas = []
        for ev in sorted(self.evaluaciones, key=_orden)[:limite]:
            p = ev.get("puntaje")
            if p is None:
                # Se dice POR QUÉ no hay puntaje. Un «[None/5]» invitaría al
                # modelo a tratarlo como un cero, que es justo la confusión
                # entre «no evaluable» e «incumple» que el invariante 3 evita.
                marca = ("sin evidencia" if ev.get("sin_evidencia")
                         else "no evaluada — fallo técnico")
                filas.append(
                    f"  · [{marca}] {ev.get('ambito', '')} — "
                    f"{str(ev.get('actividad', ''))[:70]}"
                )
                continue
            filas.append(
                f"  · [{p}/5] {ev.get('ambito', '')} — "
                f"{str(ev.get('actividad', ''))[:70]}: "
                f"{str(ev.get('observacion', ''))[:110]}"
            )
        return "\n".join(filas)

    def _reglas_comunes(self) -> str:
        """
        Reglas que rigen para todas las skills. Definidas UNA vez.

        Repetirlas en cada skill garantizaría que se separen: ocho copias de una
        instrucción son ocho oportunidades de que una se quede vieja.
        """
        return """
REGLAS QUE RIGEN PARA TODO LO QUE DEVUELVAS

1. CITA LITERAL. Toda afirmación sobre la evidencia va acompañada del texto
   exacto, en el formato:  fichero → "texto copiado tal cual"
   Si es código, transcríbelo dentro de ``` ```. NO inventes números de línea:
   el contexto no los trae.

2. PROHIBIDO FABRICAR. Copia solo texto que esté LITERALMENTE arriba. Si no
   encuentras nada que citar, devuelve la lista vacía. Un hallazgo inventado
   desacredita el informe entero y expone a quien lo firma.

3. NO REPITAS EL PIPELINE. Los hallazgos previos ya están en el informe. Tu
   valor está en lo que ellos NO vieron: cruces entre fuentes, supuestos no
   verificados, justificaciones ausentes.

4. AUSENCIA DE EVIDENCIA ≠ INCUMPLIMIENTO. Si algo no aparece en el contexto,
   dilo como limitación de alcance, no como deficiencia del modelo.

5. RESPONDE ÚNICAMENTE CON EL JSON PEDIDO. Sin markdown alrededor, sin texto
   antes ni después."""

    # ── Ejecución ────────────────────────────────────────────────────────────

    def ejecutar(self) -> ResultadoSkill:
        """
        Ejecuta la skill. NUNCA lanza: un fallo se declara en el resultado.

        Es deliberado. Las skills son análisis adicional sobre un dictamen que ya
        existe y ya está sellado. Que una falle debe restar información, no
        invalidar la corrida.
        """
        t0 = time.perf_counter()
        base = ResultadoSkill(
            nombre=self.nombre, titulo=self.titulo, ok=False,
            hallazgos=[], resumen="", error=None,
            duracion_seg=0.0, citas_no_verificadas=[], prompt_sha256="",
        )

        try:
            prompt = self.construir_prompt() + "\n" + self._reglas_comunes()

            from modulos.huella_prompts import sha256_texto
            base["prompt_sha256"] = sha256_texto(prompt)[:16]

            from modulos.motor_ia import _extraer_json, _llamar_modelo, _verificar_citas

            crudo = _llamar_modelo(prompt)
            datos = _extraer_json(crudo)
            if not isinstance(datos, dict):
                raise ValueError(f"la respuesta no es un objeto JSON "
                                 f"(es {type(datos).__name__})")

            # [AUDIT-FIX 2026-08-07] Antes: `hallazgos = datos.get(clave)` y, si
            # no era lista, `hallazgos = []` en silencio. Es decir: una respuesta
            # que INCUMPLE el contrato —clave ausente, `null`, o prosa en vez de
            # lista— se reportaba como `ok=True` con 0 hallazgos, exactamente
            # igual que un análisis limpio que no encontró nada.
            #
            # Por qué estaba mal: invierte el invariante que gobierna el sistema
            # (§3.2 — «no se inventa un puntaje»; el pipeline principal declara
            # FALLO TÉCNICO en el mismo caso). Un «0 hallazgos» silencioso es
            # rellenar un hueco: el validador lee «esta skill no encontró nada»
            # cuando lo cierto es «esta skill no llegó a analizarse».
            #
            # Cómo se midió: sonda con cuatro respuestas sobre la skill de
            # síntesis. Las tres incumplidoras —clave equivocada, `{}`, y prosa
            # en lugar de lista— daban las tres `ok=True, hallazgos=0`,
            # indistinguibles del caso correcto con lista vacía.
            #
            # Nótese que `.get(clave)` NO basta para distinguir «ausente» de
            # «presente con valor nulo» (la trampa §3.9, aquí por quinta vez):
            # hace falta el centinela.
            _AUSENTE = object()
            hallazgos = datos.get(self.clave_hallazgos, _AUSENTE)
            if hallazgos is _AUSENTE:
                raise ValueError(
                    f"la respuesta no trae la clave '{self.clave_hallazgos}' "
                    f"que exige el contrato de esta skill "
                    f"(claves recibidas: {', '.join(sorted(datos)) or 'ninguna'})")
            # Un objeto suelto en lugar de una lista de uno es una desviación
            # inocua y frecuente: se tolera, no es un incumplimiento.
            if isinstance(hallazgos, dict):
                hallazgos = [hallazgos]
            if not isinstance(hallazgos, list):
                raise ValueError(
                    f"'{self.clave_hallazgos}' debía ser una lista y llegó "
                    f"{type(hallazgos).__name__}")

            base["hallazgos"] = [h for h in hallazgos if isinstance(h, dict)]
            base["resumen"] = str(datos.get("resumen") or "").strip()
            base["extra"] = {k: v for k, v in datos.items()
                             if k not in (self.clave_hallazgos, "resumen")}

            # Las citas se verifican contra el MISMO contexto que vio la skill.
            # Es la única defensa contra un hallazgo inventado que suene bien.
            base["citas_no_verificadas"] = _verificar_citas(
                self._texto_citable(base["hallazgos"]), self.contexto)
            if base["citas_no_verificadas"]:
                logger.warning("[skill:%s] %d cita(s) sin coincidencia literal.",
                               self.nombre, len(base["citas_no_verificadas"]))

            base["ok"] = True

        except Exception as exc:
            base["error"] = f"{type(exc).__name__}: {exc}"
            logger.warning("[skill:%s] falló: %s", self.nombre, base["error"])

        base["duracion_seg"] = round(time.perf_counter() - t0, 2)
        return base

    @staticmethod
    def _texto_citable(hallazgos: List[Dict]) -> str:
        """
        Junta todo lo que parezca una cita para poder verificarlo de una vez.

        Se recorre cualquier clave que empiece por `cita` porque las skills usan
        nombres distintos —`cita`, `cita_manual`, `cita_codigo`— y centralizar la
        verificación vale más que uniformar los nombres: cada skill nombra sus
        campos como le resulta natural leerlos en el informe.
        """
        partes = []
        for h in hallazgos:
            for k, v in h.items():
                if k.startswith("cita") and isinstance(v, str) and v.strip():
                    partes.append(f'"{v}"')
        return "\n".join(partes)
