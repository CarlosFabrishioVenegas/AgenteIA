"""
modulos/skills/catalogo.py
═════════════════════════════════════════════════════════════════════════════
Las ocho skills de validación.

CRITERIO DE SELECCIÓN
─────────────────────
El subsistema `agent/` aparcado trae 17. Aquí hay 8, elegidas por una regla:
**cada una responde una pregunta que el pipeline por actividades NO puede
responder**, porque exige cruzar fuentes o razonar sobre el conjunto.

    coherencia   ¿el código hace lo que el manual dice?
    supuestos    ¿se verificaron los supuestos del método?
    papers       ¿la bibliografía citada sostiene lo implementado?
    challenger   ¿qué habría hecho un equipo independiente?
    regulatorio  ¿qué exige la norma que aquí no está?
    gobierno     ¿quién aprueba, quién revisa, quién puede tocarlo?
    datos        ¿los datos que alimentan el modelo están controlados?
    sintesis     de todo lo anterior, ¿qué es lo verdaderamente grave?

Las siete primeras son independientes entre sí. `sintesis` es distinta: consume
la salida de las demás, así que se ejecuta SIEMPRE la última.

ORDEN DE COSTE
──────────────
    bajo   → 1 llamada, prompt corto
    medio  → 1 llamada, prompt largo (todo el contexto)
    alto   → 1 llamada con salida extensa (challenger genera código)
"""

from __future__ import annotations

from typing import Dict, List, Type

from modulos.skills.base import SkillBase

__all__ = ["SKILLS", "obtener_skill", "listar_skills"]


# ═════════════════════════════════════════════════════════════════════════════
# 1. COHERENCIA DOCUMENTO ↔ CÓDIGO
# ═════════════════════════════════════════════════════════════════════════════
class SkillCoherencia(SkillBase):
    """
    El hallazgo más valioso de una validación y el más caro de obtener a mano.

    Un manual que dice «ventana de 250 días» y un `calcula_var.py` con
    `retornos[-500:]` invalida la comparabilidad del backtesting — y ningún
    control del estándar lo pregunta, porque el estándar pregunta si existe
    documentación y si existe implementación, no si dicen lo mismo.
    """

    nombre = "coherencia"
    titulo = "Coherencia documentación ↔ implementación"
    descripcion = ("Contrasta lo que el manual describe con lo que el código "
                   "hace: parámetros, fórmulas, ventanas, criterios de exclusión.")
    ambitos_relevantes = ["Metodología", "Implementación", "Documentación"]
    coste_estimado = "medio"
    clave_hallazgos = "discrepancias"

    def construir_prompt(self) -> str:
        return f"""Eres validador de segunda línea. Tu única tarea aquí es
CONTRASTAR LA DOCUMENTACIÓN CONTRA EL CÓDIGO del modelo «{self.titulo_modelo}».

No evalúas si la documentación es buena ni si el código es limpio. Buscas una
cosa: DÓNDE DICEN COSAS DISTINTAS.

Qué comparar, en este orden de importancia:
  1. PARÁMETROS NUMÉRICOS — ventanas, niveles de confianza, horizontes,
     umbrales, factores, semillas. Es donde más discrepancias hay y donde más
     duelen: cambian el resultado sin cambiar el discurso.
  2. FÓRMULAS — ¿el cálculo implementado es el descrito? Percentil vs
     paramétrico, log-retornos vs aritméticos, ponderado vs simple.
  3. TRATAMIENTO DE DATOS — exclusiones, imputación de faltantes, outliers,
     calendario de días hábiles.
  4. ORDEN Y CONDICIONES — ¿se aplican los pasos como el manual describe?

CÓMO IDENTIFICAR CADA LADO
Cada documento del contexto viene rotulado con su ROL entre corchetes:

    === manual_VaR.md  [MANUAL METODOLÓGICO — lo que el modelo DICE que hace] ===
    === calcula_var.py [IMPLEMENTACIÓN (código) — lo que el modelo HACE de verdad] ===

Usa el rótulo, no el nombre del fichero, para saber de qué lado está cada
documento. Confundir los lados invierte el hallazgo —«el código dice 250 y el
manual 500» cuando es al revés— y eso en un informe es un error de bulto.

El contraste que importa es MANUAL METODOLÓGICO ↔ IMPLEMENTACIÓN. Los demás
roles son apoyo: SEGUIMIENTO sirve para ver si el backtesting se ejecutó sobre
lo que realmente hace el código, y USO Y GESTIÓN para saber qué versión se
aprobó en comité.

Si NINGÚN documento viene rotulado como IMPLEMENTACIÓN, dilo en `resumen` y
devuelve la lista vacía. No especules sobre código que no has visto: sin código
no hay contraste posible, y eso es una limitación de alcance, no un hallazgo.

Si un documento aparece marcado como [PARCIAL: N%], está recortado: lo que no
encuentres en él puede estar en la parte que no recibiste. Decláralo como
limitación, nunca como discrepancia.

CONTEXTO (cada documento rotulado con su rol):
{self.contexto}

HALLAZGOS QUE EL PIPELINE YA REGISTRÓ (no los repitas):
{self._hallazgos_previos()}

Responde con este JSON:
{{
  "resumen": "<qué comparaste y qué encontraste, 2-3 oraciones. Si no había código, dilo aquí.>",
  "discrepancias": [
    {{"aspecto": "<qué parámetro o fórmula>",
      "fuente_doc": "<fichero del documento>",
      "cita_doc": "<texto literal del documento>",
      "fuente_codigo": "<fichero de código>",
      "cita_codigo": "<código literal>",
      "impacto": "<qué consecuencia tiene la diferencia sobre el resultado del modelo>",
      "severidad": "<alta|media|baja>"}}
  ]
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# 2. SUPUESTOS ESTADÍSTICOS
# ═════════════════════════════════════════════════════════════════════════════
class SkillSupuestos(SkillBase):
    """
    Todo método tiene supuestos. Casi ninguna documentación los verifica.

    Es el hallazgo clásico de una validación de VaR: se asume normalidad de los
    retornos y nadie corrió un test. El modelo funciona hasta que deja de
    hacerlo, justo cuando más importa.
    """

    nombre = "supuestos"
    titulo = "Supuestos del método y su verificación"
    descripcion = ("Identifica los supuestos estadísticos del método y comprueba "
                   "si se verificaron empíricamente o solo se asumieron.")
    ambitos_relevantes = ["Metodología", "Calidad de datos"]
    coste_estimado = "medio"
    clave_hallazgos = "supuestos"

    def construir_prompt(self) -> str:
        return f"""Eres validador de segunda línea evaluando los SUPUESTOS del
modelo «{self.titulo_modelo}».

Todo método cuantitativo descansa sobre supuestos. La pregunta no es si existen
—siempre existen— sino si alguien los COMPROBÓ o simplemente se asumieron.

Supuestos a rastrear según el tipo de modelo (aplica los que correspondan):
  · ESTACIONARIEDAD de las series (ADF, KPSS, Phillips-Perron)
  · NORMALIDAD de los retornos (Jarque-Bera, Shapiro-Wilk, Q-Q)
  · INDEPENDENCIA / ausencia de autocorrelación (Ljung-Box, Durbin-Watson)
  · HOMOCEDASTICIDAD vs heterocedasticidad (ARCH, White, Breusch-Pagan)
  · ESTABILIDAD de parámetros en el tiempo (Chow, CUSUM, rolling)
  · REPRESENTATIVIDAD de la muestra respecto de la cartera actual
  · LINEALIDAD, si el método la presupone

Para cada uno, clasifica en:
  VERIFICADO   — hay test ejecutado y resultado citable
  DECLARADO    — se menciona el supuesto pero no se comprueba
  IMPLÍCITO    — el método lo exige y la documentación ni lo nombra ← lo más grave
  NO_APLICA    — el método no lo requiere

El caso IMPLÍCITO es el que aporta valor: un supuesto que nadie sabe que está
asumiendo no se puede vigilar.

CONTEXTO:
{self.contexto}

HALLAZGOS PREVIOS:
{self._hallazgos_previos()}

Responde con este JSON:
{{
  "resumen": "<qué método detectaste y el estado general de sus supuestos>",
  "supuestos": [
    {{"supuesto": "<nombre>",
      "exigido_por": "<qué parte del método lo requiere>",
      "estado": "<VERIFICADO|DECLARADO|IMPLICITO|NO_APLICA>",
      "cita": "<texto literal que lo respalda, o cadena vacía si no hay>",
      "riesgo_si_falla": "<qué pasa con el modelo si el supuesto no se cumple>",
      "test_recomendado": "<test concreto y sobre qué datos>"}}
  ]
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# 3. INTELIGENCIA BIBLIOGRÁFICA
# ═════════════════════════════════════════════════════════════════════════════
class SkillPapers(SkillBase):
    """
    Una cita no es una justificación.

    Es habitual citar un paper que trata un caso distinto —otra clase de activo,
    otro horizonte, otra profundidad de mercado— y presentarlo como respaldo. La
    cita da apariencia de rigor sin aportarlo.
    """

    nombre = "papers"
    titulo = "¿La bibliografía sostiene lo implementado?"
    descripcion = ("Comprueba si los papers y referencias citados respaldan "
                   "realmente la metodología aplicada, o solo la decoran.")
    ambitos_relevantes = ["Metodología", "Documentación"]
    coste_estimado = "medio"
    clave_hallazgos = "referencias"

    def construir_prompt(self) -> str:
        return f"""Eres validador de segunda línea revisando la BIBLIOGRAFÍA del
modelo «{self.titulo_modelo}».

Una referencia citada no es una justificación. Comprueba, para cada una:

  1. ¿El manual afirma que el paper dice algo? ¿Lo dice de verdad, según el
     texto disponible?
  2. ¿El paper cubre ESTE caso? Un método validado para renta variable líquida
     no se traslada solo a un bono ilíquido ni a una cartera con opcionalidad.
  3. ¿Se cita la versión vigente? Un marco regulatorio derogado no respalda nada.
  4. ¿Hay literatura RELEVANTE que brilla por su ausencia? Si se implementa
     backtesting sin citar a Kupiec o Christoffersen, falta el fundamento.
  5. ¿Se cita para justificar la elección, o solo para describir el método?

Trabaja solo con lo que esté en el contexto. Si un paper se cita pero su texto
no está disponible, dilo: es una limitación del alcance, no un incumplimiento.

CONTEXTO:
{self.contexto}

{self.bloque_rag}

Responde con este JSON:
{{
  "resumen": "<estado general del respaldo bibliográfico>",
  "referencias": [
    {{"referencia": "<cita tal como aparece>",
      "se_usa_para": "<qué afirmación del manual pretende respaldar>",
      "cita_manual": "<texto literal del manual que la invoca>",
      "veredicto": "<SOSTIENE|PARCIAL|NO_SOSTIENE|NO_VERIFICABLE>",
      "motivo": "<por qué. Si es NO_VERIFICABLE, di qué haría falta para comprobarlo>"}}
  ],
  "ausencias": ["<literatura que debería estar citada y no está, con el motivo>"]
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# 4. CHALLENGER
# ═════════════════════════════════════════════════════════════════════════════
class SkillChallenger(SkillBase):
    """
    Qué habría hecho un equipo independiente con los mismos datos.

    Es la skill que más se acerca a lo que exige SR 11-7 §V («effective
    challenge»): no basta con revisar lo hecho, hay que contrastar con la
    alternativa que no se eligió.

    Genera además un script ejecutable. Un hallazgo que se puede correr contra
    los datos reales deja de ser una opinión.
    """

    nombre = "challenger"
    titulo = "Análisis challenger — la alternativa no elegida"
    descripcion = ("Genera hipótesis alternativas, identifica debilidades "
                   "metodológicas y produce un script de contraste ejecutable.")
    ambitos_relevantes = ["Metodología", "Implementación"]
    coste_estimado = "alto"
    clave_hallazgos = "hipotesis"

    def construir_prompt(self) -> str:
        return f"""Eres el equipo de validación INDEPENDIENTE del modelo
«{self.titulo_modelo}». No revisas el trabajo del modelador: haces el tuyo y lo
comparas. Es lo que SR 11-7 llama *effective challenge*.

Tres entregas:

A. HIPÓTESIS ALTERNATIVAS. Para cada decisión metodológica relevante, ¿qué otra
   opción era razonable? ¿Bajo qué condiciones daría un resultado MATERIALMENTE
   distinto? No listes alternativas de manual: di cuándo importaría el cambio.

B. DEBILIDADES. Dónde el modelo es frágil: escenarios donde falla, condiciones
   de mercado no cubiertas, dependencia de un supuesto que nadie vigila.

C. SCRIPT DE CONTRASTE. Código Python EJECUTABLE que demuestre tus hallazgos
   sobre los datos del modelo. Requisitos:
     · solo `pandas`, `numpy`, `scipy`, `statsmodels` — nada más
     · rutas relativas a `inputs/calidad_datos/datasets/`
     · que IMPRIMA resultados interpretables, no que devuelva objetos
     · comentado, para que el modelador entienda qué se le está contrastando
     · si no sabes qué datos hay, escribe el script con supuestos EXPLÍCITOS
       al principio, en un bloque de constantes que se pueda ajustar

CONTEXTO:
{self.contexto}

HALLAZGOS PREVIOS:
{self._hallazgos_previos()}

Responde con este JSON:
{{
  "resumen": "<tu lectura independiente del modelo, 3-4 oraciones>",
  "hipotesis": [
    {{"decision_del_modelo": "<qué eligió>",
      "cita": "<texto literal donde consta la elección>",
      "alternativa": "<qué otra opción era razonable>",
      "cuando_importa": "<en qué condiciones daría un resultado distinto>",
      "como_contrastarlo": "<prueba concreta para decidir cuál es mejor>"}}
  ],
  "debilidades": [
    {{"debilidad": "<cuál>", "escenario": "<cuándo se manifiesta>",
      "severidad": "<alta|media|baja>"}}
  ],
  "script_contraste": "<código Python completo, ejecutable>"
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# 5. CONTRASTE REGULATORIO
# ═════════════════════════════════════════════════════════════════════════════
class SkillRegulatorio(SkillBase):
    """
    Qué exige la norma que aquí no está.

    Es la única skill que depende del RAG: sin literatura recuperada juzga de
    memoria, y una exigencia regulatoria citada de memoria no es citable en un
    informe. Por eso lo declara cuando el bloque llega vacío.
    """

    nombre = "regulatorio"
    titulo = "Contraste contra el marco regulatorio"
    descripcion = ("Compara lo documentado contra las exigencias del marco "
                   "aplicable (SR 11-7, EBA, BCBS) usando la literatura del RAG.")
    ambitos_relevantes = ["Gobierno", "Documentación", "Metodología"]
    coste_estimado = "medio"
    clave_hallazgos = "brechas"

    def construir_prompt(self) -> str:
        aviso = ""
        if not self.bloque_rag.strip():
            aviso = ("\n⚠️ NO se recuperó literatura regulatoria para esta consulta. "
                     "Señálalo en `resumen` y sé explícito sobre qué exigencias "
                     "estás citando de memoria: sin la fuente delante, no son "
                     "citables en un informe entregable.\n")

        return f"""Eres validador de segunda línea contrastando el modelo
«{self.titulo_modelo}» contra el MARCO REGULATORIO aplicable.
{aviso}
Trabaja de la exigencia hacia la evidencia, no al revés: recorre lo que la norma
pide y comprueba si está. Ese orden encuentra ausencias; el inverso solo confirma
lo que ya hay.

Marcos de referencia: SR 11-7 (gestión de riesgo de modelo), EBA/GL/2023/01,
BCBS 239 (agregación de datos), y el específico del tipo de modelo (FRTB/BCBS
457 para mercado, BCBS 238/295 para liquidez, IRRBB para conductuales).

Para cada exigencia relevante: ¿está cubierta, parcialmente, o ausente?

CONTEXTO:
{self.contexto}

LITERATURA REGULATORIA RECUPERADA:
{self.bloque_rag or "(ninguna)"}

Responde con este JSON:
{{
  "resumen": "<grado de alineamiento y si pudiste apoyarte en literatura recuperada>",
  "brechas": [
    {{"exigencia": "<qué pide la norma>",
      "fuente_normativa": "<marco y artículo/sección, si consta en la literatura>",
      "estado": "<CUBIERTA|PARCIAL|AUSENTE>",
      "cita_evidencia": "<texto literal del modelo que la cubre, o cadena vacía>",
      "brecha": "<qué falta exactamente>",
      "severidad": "<alta|media|baja>"}}
  ]
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# 6. GOBIERNO
# ═════════════════════════════════════════════════════════════════════════════
class SkillGobierno(SkillBase):
    """
    Quién aprueba, quién revisa, quién puede tocarlo.

    Existe porque `Gobierno` no tiene carpeta propia en `inputs/`: se evalúa a
    partir del manual y de la documentación de implementación. Una skill
    dedicada rastrea la evidencia de gobierno allí donde esté, sin depender de
    que alguien la haya guardado en el sitio correcto.
    """

    nombre = "gobierno"
    titulo = "Gobierno, roles y segregación de funciones"
    descripcion = ("Rastrea aprobaciones, roles, segregación de funciones y "
                   "control de accesos en toda la evidencia disponible.")
    ambitos_relevantes = ["Gobierno", "Implementación"]
    coste_estimado = "bajo"
    clave_hallazgos = "hallazgos"

    def construir_prompt(self) -> str:
        return f"""Eres validador de segunda línea evaluando el GOBIERNO del
modelo «{self.titulo_modelo}».

El gobierno rara vez vive en un documento propio: está repartido en firmas del
manual, actas citadas de pasada, menciones de responsables. Rastréalo en TODA la
evidencia.

Qué buscar:
  · APROBACIÓN — ¿quién aprobó el modelo, en qué órgano, con qué fecha?
  · ROLES — desarrollador, validador, aprobador, usuario. ¿Están identificados?
  · SEGREGACIÓN — ¿quien desarrolla es distinto de quien valida? Si coinciden,
    es un hallazgo de primer orden.
  · CONTROL DE CAMBIOS — ¿quién puede modificar el modelo y con qué autorización?
  · ACCESOS — ¿quién puede ejecutarlo y tocar sus parámetros en producción?
  · PERIODICIDAD DE REVISIÓN — ¿cada cuánto se revisa y quién lo vigila?
  · ESCALADO — ¿qué pasa cuando el modelo falla o se degrada?

Un rol MENCIONADO no es un rol ASIGNADO: «el área de riesgos revisa» sin nombre,
fecha ni evidencia de la revisión es una declaración de intenciones.

CONTEXTO:
{self.contexto}

Responde con este JSON:
{{
  "resumen": "<madurez del gobierno según la evidencia>",
  "hallazgos": [
    {{"aspecto": "<aprobación|roles|segregación|cambios|accesos|revisión|escalado>",
      "estado": "<DOCUMENTADO|MENCIONADO|AUSENTE>",
      "cita": "<texto literal, o cadena vacía>",
      "riesgo": "<qué expone esta situación>",
      "severidad": "<alta|media|baja>"}}
  ]
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# 7. CALIDAD DE DATOS
# ═════════════════════════════════════════════════════════════════════════════
class SkillDatos(SkillBase):
    """
    Un modelo no es mejor que los datos que lo alimentan.

    Complementa al motor de controles (`Mx_04`), que ejecuta pruebas sobre los
    datasets: esta skill evalúa el MARCO de control —si existe, si se ejecuta,
    si alguien mira el resultado— que es lo que exige BCBS 239.
    """

    nombre = "datos"
    titulo = "Marco de control de datos"
    descripcion = ("Evalúa el linaje, los controles de calidad y su ejecución "
                   "efectiva sobre los datos que alimentan el modelo.")
    ambitos_relevantes = ["Calidad de datos", "Implementación"]
    coste_estimado = "bajo"
    clave_hallazgos = "hallazgos"

    def construir_prompt(self) -> str:
        return f"""Eres validador de segunda línea evaluando el MARCO DE CONTROL
DE DATOS del modelo «{self.titulo_modelo}».

No evalúas los datos: evalúas si alguien los controla. Es la distinción de
BCBS 239 — un control definido y nunca ejecutado no controla nada.

Qué buscar:
  · LINAJE — ¿de qué sistema sale cada dato y qué transformaciones sufre?
  · DICCIONARIO — ¿está definido qué significa cada campo?
  · CONTROLES DEFINIDOS — nulos, duplicados, rangos, integridad referencial
  · EVIDENCIA DE EJECUCIÓN — ¿hay logs, fechas, resultados? ← lo decisivo
  · TRATAMIENTO DE EXCEPCIONES — cuando un control falla, ¿qué pasa?
  · CONCILIACIÓN — ¿cuadran las cifras con el sistema origen?
  · PERIODICIDAD — ¿con qué frecuencia se refrescan y se revisan?

Distingue siempre CONTROL DEFINIDO de CONTROL EJECUTADO. Es la diferencia entre
un procedimiento y una práctica.

CONTEXTO:
{self.contexto}

HALLAZGOS PREVIOS:
{self._hallazgos_previos()}

Responde con este JSON:
{{
  "resumen": "<madurez del marco de control de datos>",
  "hallazgos": [
    {{"aspecto": "<linaje|diccionario|controles|ejecución|excepciones|conciliación|periodicidad>",
      "estado": "<EVIDENCIADO|DEFINIDO_SIN_EJECUTAR|AUSENTE>",
      "cita": "<texto literal, o cadena vacía>",
      "impacto": "<qué riesgo introduce en el resultado del modelo>",
      "severidad": "<alta|media|baja>"}}
  ]
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# 8. SÍNTESIS
# ═════════════════════════════════════════════════════════════════════════════
class SkillSintesis(SkillBase):
    """
    De todo lo anterior, ¿qué es lo verdaderamente grave?

    Siete skills producen decenas de hallazgos, y una lista larga esconde lo
    importante tan bien como una lista vacía. Ésta prioriza, agrupa lo que es el
    mismo problema visto desde ángulos distintos, y señala las contradicciones
    entre skills — que son señal de que alguna se equivocó.

    Se ejecuta SIEMPRE la última: consume la salida de las demás.
    """

    nombre = "sintesis"
    titulo = "Síntesis y priorización de hallazgos"
    descripcion = ("Consolida los hallazgos de las demás skills, los prioriza "
                   "y detecta contradicciones entre ellos. Se ejecuta al final.")
    ambitos_relevantes = []
    coste_estimado = "bajo"
    clave_hallazgos = "prioridades"

    def __init__(self, *args, resultados_previos=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.resultados_previos = resultados_previos or []

    def _resumen_skills(self) -> str:
        if not self.resultados_previos:
            return "(no se ejecutó ninguna otra skill)"
        partes = []
        for r in self.resultados_previos:
            if not r.get("ok"):
                partes.append(f"### {r.get('titulo')}: FALLÓ ({r.get('error')})")
                continue
            partes.append(f"### {r.get('titulo')}\n{r.get('resumen', '')}")
            for h in r.get("hallazgos", [])[:10]:
                desc = (h.get("contradiccion") or h.get("brecha")
                        or h.get("impacto") or h.get("riesgo")
                        or h.get("motivo") or h.get("debilidad") or "")
                etiqueta = (h.get("aspecto") or h.get("supuesto")
                            or h.get("exigencia") or h.get("referencia")
                            or h.get("decision_del_modelo") or "")
                sev = h.get("severidad") or h.get("estado") or ""
                partes.append(f"  · [{sev}] {etiqueta}: {str(desc)[:150]}")
        return "\n".join(partes)

    def construir_prompt(self) -> str:
        return f"""Eres el validador senior que firma el informe del modelo
«{self.titulo_modelo}». Varios analistas te han entregado sus hallazgos. Tu
trabajo NO es sumarlos: es decidir qué importa.

Tres tareas:

A. PRIORIZAR. Ordena por RIESGO REAL, no por cuántas veces se menciona algo.
   Un hallazgo aislado que invalida el backtesting pesa más que cinco
   observaciones de formato. Justifica cada prioridad.

B. AGRUPAR. Varios analistas pueden estar viendo el MISMO problema desde
   ángulos distintos —una ventana temporal mal documentada aparece como
   discrepancia de código, como supuesto no verificado y como brecha
   regulatoria—. Únelos: son un hallazgo, no tres.

C. DETECTAR CONTRADICCIONES entre analistas. Si uno afirma que algo está
   documentado y otro que falta, uno de los dos se equivoca y hay que decirlo:
   un informe que se contradice a sí mismo no se sostiene ante un supervisor.

HALLAZGOS DE LAS DEMÁS SKILLS:
{self._resumen_skills()}

EVALUACIÓN DEL PIPELINE:
{self._hallazgos_previos(limite=15)}

Responde con este JSON:
{{
  "resumen": "<tu dictamen de conjunto en 4-5 oraciones: qué está en juego>",
  "prioridades": [
    {{"orden": <entero, 1 es lo más grave>,
      "hallazgo": "<enunciado consolidado>",
      "origen": ["<skills o ámbitos que lo detectaron>"],
      "por_que_importa": "<consecuencia concreta sobre el uso del modelo>",
      "accion": "<qué debe hacer el modelador, en concreto>",
      "bloquea_aprobacion": <true|false>}}
  ],
  "contradicciones": [
    {{"entre": ["<skill A>", "<skill B>"], "sobre": "<qué>",
      "detalle": "<en qué discrepan y cuál parece correcta>"}}
  ]
}}"""


# ═════════════════════════════════════════════════════════════════════════════
# REGISTRO
# ═════════════════════════════════════════════════════════════════════════════
# `sintesis` va la última a propósito: consume la salida de las demás. El
# ejecutor respeta este orden.
SKILLS: Dict[str, Type[SkillBase]] = {
    c.nombre: c for c in (
        SkillCoherencia,
        SkillSupuestos,
        SkillPapers,
        SkillChallenger,
        SkillRegulatorio,
        SkillGobierno,
        SkillDatos,
        SkillSintesis,
    )
}


def obtener_skill(nombre: str) -> Type[SkillBase]:
    """Clase de la skill por nombre. Lanza ValueError con las opciones válidas."""
    if nombre not in SKILLS:
        raise ValueError(
            f"skill '{nombre}' no existe. Disponibles: {', '.join(SKILLS)}")
    return SKILLS[nombre]


def listar_skills() -> List[Dict[str, str]]:
    """Catálogo para `--listar-skills`."""
    return [
        {"nombre": c.nombre, "titulo": c.titulo,
         "descripcion": c.descripcion, "coste": c.coste_estimado,
         "ambitos": ", ".join(c.ambitos_relevantes) or "todos"}
        for c in SKILLS.values()
    ]
