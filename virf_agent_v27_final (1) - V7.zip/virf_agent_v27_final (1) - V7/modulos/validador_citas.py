"""
modulos/validador_citas.py
═════════════════════════════════════════════════════════════════════════════
Validador DETERMINISTA de citas con id de linaje (WP-03/WP-04 · indicador D4).

QUÉ AÑADE
─────────
El motor ya verifica que una cita literal EXISTA en el contexto
(`motor_ia._verificar_citas`). Falta la otra mitad que exige la guía: que cada
afirmación factual venga anclada a un id de LINAJE reconstruible

        [doc_id:pagina:chunk_id]

y que ese `chunk_id` EXISTA de verdad entre los fragmentos recuperados. Sin
esto una cita puede sonar bien, existir literalmente y aun así no ser
localizable en la fuente —el paso previo a "citas alucinadas/decorativas"—.

Esta capa es 100% determinista (regex + pertenencia a un conjunto): no llama al
modelo. La verificación SEMÁNTICA (¿el fragmento IMPLICA la afirmación? — NLI /
entailment) se deja explícitamente diferida al día de API (`verificar_entailment`
devuelve NA-diferido) para no gastar crédito hoy.

FORMATO DEL ID
──────────────
    [doc_id:pagina:chunk_id]
      · doc_id   : identificador del documento (sin ':' ni corchetes)
      · pagina   : número de página, o 's/p' si la fuente no pagina
      · chunk_id : identificador del fragmento dentro del documento

Ejemplos válidos:  [manual_var:12:3]   [acta_comite:s/p:0]
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

__all__ = [
    "PATRON_CITA",
    "extraer_ids",
    "id_de_chunk",
    "validar_afirmacion",
    "verificar_afirmaciones",
    "verificar_entailment",
]

# Un segmento del id no puede contener ':', '[' ni ']'.
PATRON_CITA = re.compile(r"\[([^\[\]:]+):([^\[\]:]+):([^\[\]:]+)\]")


def extraer_ids(texto: str) -> List[str]:
    """Devuelve los ids de cita `[doc:pagina:chunk]` presentes en el texto."""
    if not texto:
        return []
    return [f"[{d.strip()}:{p.strip()}:{c.strip()}]"
            for d, p, c in PATRON_CITA.findall(texto)]


def id_de_chunk(chunk: Dict[str, Any]) -> Optional[str]:
    """
    Construye el id de linaje de un fragmento recuperado, si trae los campos.

    Acepta las claves ya presentes en el proyecto (`fuente`/`ruta` como doc,
    `pagina`, `chunk`) y tolera ausencias declarándolas ('s/p' para página).
    """
    doc = chunk.get("doc_id") or chunk.get("fuente") or chunk.get("ruta")
    if not doc:
        return None
    pagina = chunk.get("pagina", "s/p")
    chunk_id = chunk.get("chunk_id", chunk.get("chunk"))
    if chunk_id is None:
        return None
    return f"[{doc}:{pagina}:{chunk_id}]"


def _ids_disponibles(contexto: Iterable[Dict[str, Any]]) -> set:
    ids = set()
    for c in contexto or []:
        cid = id_de_chunk(c)
        if cid:
            ids.add(cid)
    return ids


def validar_afirmacion(afirmacion: str,
                       contexto: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Valida UNA afirmación factual contra el contexto recuperado.

    Devuelve un dict con:
        aceptada    : bool  (True solo si trae id bien formado y localizable)
        tiene_cita  : bool
        ids         : lista de ids citados
        ids_validos : ids cuyo chunk existe en el contexto
        ids_invalidos: ids bien formados pero cuyo chunk NO está en el contexto
        motivo      : explicación citable
    """
    disponibles = _ids_disponibles(contexto)
    ids = extraer_ids(afirmacion)

    if not ids:
        return {
            "aceptada": False, "tiene_cita": False, "ids": [],
            "ids_validos": [], "ids_invalidos": [],
            "motivo": "La afirmación no trae id de cita [doc:pagina:chunk].",
        }

    validos = [i for i in ids if i in disponibles]
    invalidos = [i for i in ids if i not in disponibles]
    aceptada = bool(validos) and not invalidos
    if aceptada:
        motivo = "Cita con id localizable en el contexto recuperado."
    elif invalidos:
        motivo = ("Cita con chunk_id inexistente en el contexto recuperado: "
                  + ", ".join(invalidos))
    else:
        motivo = "Cita mal formada."
    return {
        "aceptada": aceptada, "tiene_cita": True, "ids": ids,
        "ids_validos": validos, "ids_invalidos": invalidos, "motivo": motivo,
    }


def verificar_afirmaciones(afirmaciones: Iterable[str],
                           contexto: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Valida una lista de afirmaciones. Resumen agregado para el informe/verificador.

    `tasa_citas_validas` alimenta el indicador D4 (parte determinística).
    """
    ctx = list(contexto or [])
    detalles = [validar_afirmacion(a, ctx) for a in afirmaciones]
    n = len(detalles)
    aceptadas = sum(1 for d in detalles if d["aceptada"])
    return {
        "total": n,
        "aceptadas": aceptadas,
        "rechazadas": n - aceptadas,
        "tasa_citas_validas": (aceptadas / n) if n else 0.0,
        "detalles": detalles,
    }


def verificar_entailment(afirmacion: str, fragmento: str) -> Dict[str, Any]:
    """
    Verificación SEMÁNTICA (NLI/entailment) — DIFERIDA al día de API.

    Deja el punto de integración listo: el día de API se sustituye por una
    llamada al modelo con rúbrica JSON estricta y mitigaciones de sesgo de juez
    (alternar orden, penalizar verbosidad). Hoy no gasta crédito.
    """
    return {
        "implica": None,
        "estado": "NA-diferido",
        "motivo": "verificación NLI/entailment requiere API (fase posterior)",
    }
