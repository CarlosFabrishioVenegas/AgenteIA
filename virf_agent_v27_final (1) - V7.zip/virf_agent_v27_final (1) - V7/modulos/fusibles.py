"""
modulos/fusibles.py
═════════════════════════════════════════════════════════════════════════════
Cortacircuitos para bucles de razonamiento y ejecución (WP-05, indicador D6).

POR QUÉ
───────
La guía de errores/loops exige controles contra bucles infinitos en las
transiciones críticas: un CAP de iteraciones (2–3) y FUSIBLES por tiempo
(~10 s) y por tokens (~20.000). Al superar cualquiera, no se sigue: se corta y
se ESCALA a revisión humana (HITL) con los hallazgos intermedios —nunca se
descartan—.

DISEÑO
──────
El reloj se INYECTA (`reloj: Callable[[], float]`). Así el comportamiento es
determinista y testeable sin dormir ni llamar a la API: el test pasa una lista
de instantes. En producción el reloj por defecto es `time.monotonic`.

El cortacircuitos NO llama al modelo ni conoce el pipeline: solo cuenta. Quien
lo usa le informa de cada iteración y de los tokens consumidos, y consulta si
puede continuar. Esto lo hace reutilizable por el motor y por las skills sin
acoplarlos.

USO TÍPICO
──────────
    cc = Cortacircuitos.desde_config()
    cc.iniciar()
    while sigo:
        cc.nueva_iteracion()          # corta si supera MAX_ITER o el tiempo
        salida = paso_de_razonamiento()
        cc.sumar_tokens(salida.tokens)  # corta si supera FUSIBLE_TOKENS
    ...
    # si algo corta:
    except CortacircuitosActivado as fallo:
        escalado = cc.escalar(hallazgos_parciales)   # dict para la cola HITL
"""
from __future__ import annotations

import time
from typing import Any, Callable, Dict, List, Optional

__all__ = ["Cortacircuitos", "CortacircuitosActivado"]


class CortacircuitosActivado(Exception):
    """Se lanza cuando un fusible se dispara. Lleva el motivo estructurado."""

    def __init__(self, motivo: str, detalle: Dict[str, Any]):
        super().__init__(motivo)
        self.motivo = motivo
        self.detalle = detalle


class Cortacircuitos:
    """
    Controla cap de iteraciones + fusibles de tiempo y tokens.

    Args:
        max_iter:      cap de iteraciones (>=1).
        fusible_seg:   tope de tiempo de pared en segundos.
        fusible_tokens: tope de tokens acumulados.
        reloj:         callable sin argumentos que devuelve segundos monótonos.
                       Se inyecta para poder testear sin dormir.
    """

    def __init__(self, max_iter: int, fusible_seg: float, fusible_tokens: int,
                 reloj: Optional[Callable[[], float]] = None):
        if max_iter < 1:
            raise ValueError("max_iter debe ser >= 1")
        self.max_iter = int(max_iter)
        self.fusible_seg = float(fusible_seg)
        self.fusible_tokens = int(fusible_tokens)
        self._reloj = reloj or time.monotonic
        self.iteraciones = 0
        self.tokens = 0
        self._t0: Optional[float] = None

    # ── Construcción desde la configuración del proyecto ─────────────────────
    @classmethod
    def desde_config(cls, reloj: Optional[Callable[[], float]] = None) -> "Cortacircuitos":
        """Instancia con los valores de `config.parametros` (import perezoso)."""
        from config import parametros as p
        return cls(p.MAX_ITER, p.FUSIBLE_SEG, p.FUSIBLE_TOKENS, reloj=reloj)

    # ── Ciclo de vida ────────────────────────────────────────────────────────
    def iniciar(self) -> None:
        """Marca el inicio del cronómetro. Idempotente hasta `reiniciar`."""
        if self._t0 is None:
            self._t0 = self._reloj()

    def reiniciar(self) -> None:
        self.iteraciones = 0
        self.tokens = 0
        self._t0 = None

    @property
    def segundos_transcurridos(self) -> float:
        if self._t0 is None:
            return 0.0
        return max(0.0, self._reloj() - self._t0)

    # ── Puntos de control ────────────────────────────────────────────────────
    def nueva_iteracion(self) -> int:
        """
        Registra una iteración y verifica cap + tiempo ANTES de dejar seguir.

        Devuelve el número de iteración en curso. Lanza `CortacircuitosActivado`
        si al entrar en esta iteración se supera el cap o el fusible de tiempo.
        """
        self.iniciar()
        self.iteraciones += 1
        if self.iteraciones > self.max_iter:
            raise CortacircuitosActivado(
                f"cap de iteraciones superado ({self.iteraciones} > {self.max_iter})",
                self._estado("cap_iteraciones"))
        self._verificar_tiempo()
        return self.iteraciones

    def sumar_tokens(self, n: int) -> int:
        """Acumula tokens y verifica el fusible. Devuelve el total acumulado."""
        if n < 0:
            raise ValueError("los tokens no pueden ser negativos")
        self.tokens += int(n)
        if self.tokens > self.fusible_tokens:
            raise CortacircuitosActivado(
                f"fusible de tokens superado ({self.tokens} > {self.fusible_tokens})",
                self._estado("fusible_tokens"))
        return self.tokens

    def verificar(self) -> None:
        """Chequeo explícito de tiempo (p. ej. entre pasos largos)."""
        self._verificar_tiempo()

    def _verificar_tiempo(self) -> None:
        if self._t0 is None:
            return
        transcurrido = self.segundos_transcurridos
        if transcurrido > self.fusible_seg:
            raise CortacircuitosActivado(
                f"fusible de tiempo superado ({transcurrido:.1f}s > {self.fusible_seg:.1f}s)",
                self._estado("fusible_tiempo"))

    # ── Escalado a HITL ──────────────────────────────────────────────────────
    def escalar(self, hallazgos_parciales: Optional[List[Any]] = None,
                motivo: str = "") -> Dict[str, Any]:
        """
        Construye el registro de escalado a revisión humana con lo acumulado.

        Los hallazgos intermedios NUNCA se descartan: viajan al validador para
        que decida con lo que hubo hasta el corte.
        """
        est = self._estado("escalado")
        est["escalado_a_hitl"] = True
        est["motivo"] = motivo or "cortacircuitos activado"
        est["hallazgos_intermedios"] = list(hallazgos_parciales or [])
        return est

    def _estado(self, disparador: str) -> Dict[str, Any]:
        return {
            "disparador": disparador,
            "iteraciones": self.iteraciones,
            "max_iter": self.max_iter,
            "segundos": round(self.segundos_transcurridos, 3),
            "fusible_seg": self.fusible_seg,
            "tokens": self.tokens,
            "fusible_tokens": self.fusible_tokens,
        }
