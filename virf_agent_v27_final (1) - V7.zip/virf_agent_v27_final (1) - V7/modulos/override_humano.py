"""
modulos/override_humano.py
═══════════════════════════════════════════════════════════════════════════════
REPORTE DE HUMAN OVERRIDE — dónde el validador corrigió al agente.

Requisito de cumplimiento, y probablemente el más importante de los tres para
un auditor externo. Lo que quiere confirmar no es que el agente funcione: es
que **el juicio humano prevalece sobre la sugerencia automática** y que el
sistema no es una caja negra que se aprueba sola.

Un anexo con las correcciones del validador —qué puntuó el agente, qué corrigió
la persona y por qué— es evidencia directa de supervisión activa. Y su ausencia
declarada («no hubo correcciones, el resultado se aceptó íntegro») también es
información relevante: le dice al auditor que hubo revisión y su conclusión fue
conforme, en vez de dejarle deducirlo del silencio.

Nota sobre el alcance temporal
──────────────────────────────
El bucle de feedback corre en PRE-PRODUCCIÓN y el informe Word se emite en
PRODUCCIÓN (`--prdc`). Nunca coinciden en la misma corrida, así que «las
correcciones de esta corrida» no existe como tal en el flujo real. El ciclo de
trabajo es:

    1. corrida pre-prod  → el agente evalúa → el validador corrige
    2. corrida --prdc    → el agente reevalúa (ya con el feedback) → se emite

Por eso el anexo reporta las correcciones del **último ciclo de revisión** de
ese modelo (la sesión de feedback más reciente, agrupada por fecha), y declara
además el acumulado histórico. Es la lectura que responde a la pregunta real
del auditor: «¿revisó una persona este modelo, y qué cambió?».
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Dict, List, Optional, Tuple


def _mismo_modelo(reg: Dict, modelo: str) -> bool:
    return (reg.get("titulo_modelo") or "").strip().lower() == (modelo or "").strip().lower()


def overrides_de_modelo(modelo: str, historial: Optional[List[Dict]] = None
                        ) -> List[Dict]:
    """Todas las correcciones registradas para un modelo, en orden de registro."""
    if historial is None:
        from modulos.feedback import cargar_historial
        historial = cargar_historial()
    return [r for r in (historial or [])
            if isinstance(r, dict) and _mismo_modelo(r, modelo)
            and r.get("puntaje_agente") is not None
            and r.get("puntaje_correcto") is not None]


def _sesion(reg: Dict) -> str:
    """
    Agrupador de sesión de revisión: la FECHA (día) del registro.

    El historial guarda `fecha` como 'dd/mm/aaaa HH:MM'. Se agrupa por día
    porque una sesión de revisión de un validador ocurre en una sentada; usar la
    hora exacta fragmentaría la misma sesión en varias.
    """
    return (reg.get("fecha") or "")[:10]


def _orden_sesion(sesion: str) -> Tuple[int, int, int]:
    """
    Clave de orden cronológico a partir de 'dd/mm/aaaa'.

    [FIX] La primera versión tomaba «la última sesión en orden de aparición»
    asumiendo que el historial es append-only y por tanto cronológico. No lo es:
    `feedback.guardar_historial()` FUSIONA con lo que haya en disco y deduplica
    por id, así que el orden de la lista no garantiza el orden temporal. Con dos
    validadores escribiendo sobre el mismo repositorio, el anexo podía reportar
    como «último ciclo» una sesión de hace un mes.
    """
    partes = (sesion or "").split("/")
    if len(partes) == 3:
        try:
            return (int(partes[2]), int(partes[1]), int(partes[0]))
        except ValueError:
            pass
    return (0, 0, 0)   # sin fecha parseable → al principio, nunca «la última»


def ultimo_ciclo(modelo: str, historial: Optional[List[Dict]] = None) -> List[Dict]:
    """Correcciones de la sesión de revisión más reciente de ese modelo."""
    todas = overrides_de_modelo(modelo, historial)
    if not todas:
        return []
    sesiones: "OrderedDict[str, List[Dict]]" = OrderedDict()
    for r in todas:
        sesiones.setdefault(_sesion(r), []).append(r)
    # Cronológico por fecha, con el orden de aparición como desempate para
    # sesiones del mismo día o sin fecha parseable.
    claves = sorted(sesiones, key=lambda s: (_orden_sesion(s), list(sesiones).index(s)))
    return sesiones[claves[-1]]


def resumen_override(modelo: str, total_actividades: int,
                     historial: Optional[List[Dict]] = None) -> Dict:
    """
    Datos del anexo y de la métrica de independencia.

    `pct_ajustados` = correcciones del último ciclo / actividades evaluadas.
    Se acota a 100: si un validador corrigió la misma actividad dos veces en la
    misma sesión, el cociente podría pasar de 1 y un «112 % de ajustes» en un
    informe regulatorio destruiría la credibilidad del resto del documento.
    """
    ciclo = ultimo_ciclo(modelo, historial)
    todas = overrides_de_modelo(modelo, historial)

    from modulos.feedback import autor_de, cargo_de

    correcciones = [{
        "ambito": r.get("ambito", ""),
        "actividad": r.get("actividad", ""),
        "puntaje_agente": r.get("puntaje_agente"),
        "puntaje_validador": r.get("puntaje_correcto"),
        "diferencia": r.get("diferencia",
                            (r.get("puntaje_correcto") or 0) - (r.get("puntaje_agente") or 0)),
        "justificacion": r.get("comentario") or "Sin comentario adicional.",
        "fecha": r.get("fecha", ""),
        # [PENDIENTE-2] Quién hizo ESTA corrección. Va al anexo del Word: sin
        # ello el anexo dice «el validador ajustó 2 puntajes» sin acreditar cuál.
        "autor": autor_de(r),
        "cargo_autor": cargo_de(r),
    } for r in ciclo]

    n = len(correcciones)
    pct = 0.0
    if total_actividades and total_actividades > 0:
        pct = round(min(100.0, n / total_actividades * 100), 1)

    al_alza = sum(1 for c in correcciones if (c["diferencia"] or 0) > 0)
    a_la_baja = sum(1 for c in correcciones if (c["diferencia"] or 0) < 0)

    return {
        "modelo": modelo,
        "hubo_correcciones": n > 0,
        "n_correcciones": n,
        "n_correcciones_historicas": len(todas),
        "total_actividades": total_actividades,
        "pct_ajustados": pct,
        "correcciones": correcciones,
        "ajustes_al_alza": al_alza,
        "ajustes_a_la_baja": a_la_baja,
        "sesion": _sesion(ciclo[0]) if ciclo else None,
        # [PENDIENTE-2] Quiénes firman las correcciones de este ciclo. Que sean
        # DOS o más es evidencia positiva de revisión cruzada; que la lista
        # contenga "(no registrado)" declara que parte del ciclo es anterior al
        # registro de autoría, en vez de dejar el hueco sin explicar.
        "autores": sorted({c["autor"] for c in correcciones}),
    }


def linea_independencia(res: Dict) -> str:
    """Línea para el resumen ejecutivo del informe (cara al regulador)."""
    if not res["hubo_correcciones"]:
        return ("% de puntajes ajustados por el validador: 0 % — el validador "
                "revisó la evaluación y aceptó el resultado del agente en su "
                "totalidad.")
    return (f"% de puntajes ajustados por el validador: {res['pct_ajustados']} % "
            f"({res['n_correcciones']} de {res['total_actividades']} actividades; "
            f"{res['ajustes_al_alza']} al alza, {res['ajustes_a_la_baja']} a la baja).")


# ═════════════════════════════════════════════════════════════════════════════
# 3.2 — Señal INTERNA de calidad del proceso (NO va al informe del regulador)
# ═════════════════════════════════════════════════════════════════════════════

def calidad_proceso(validador: str, historial: Optional[List[Dict]] = None,
                    registro_validador: Optional[List[Dict]] = None) -> Dict:
    """
    Señal interna: ¿este validador está revisando a fondo o aprobando en bloque?

    Un 0 % de ajustes sostenido a lo largo de muchas corridas puede significar
    que el agente acierta siempre, o que nadie está mirando. La diferencia
    importa para la calidad del proceso, pero es una métrica de gestión interna
    y **no debe aparecer en el informe que se entrega al regulador**: allí sería
    una acusación implícita al propio validador que firma.

    Se escribe en un fichero aparte, no en el JSON del informe ni en el Word.
    """
    if historial is None:
        from modulos.feedback import cargar_historial
        historial = cargar_historial()
    if registro_validador is None:
        from modulos.validador_humano import _cargar_registro
        registro_validador = _cargar_registro()

    from modulos.feedback import SIN_AUTOR, autor_de

    aprobaciones = [r for r in (registro_validador or [])
                    if (r.get("validador") or "") == validador]
    modelos_aprobados = {r.get("modelo") for r in aprobaciones}
    correcciones = [r for r in (historial or []) if isinstance(r, dict)]

    # ── [AUDIT-FIX PENDIENTE-2] Atribución REAL, ya no por modelo ────────────
    # Antes: `suyas = correcciones de los modelos que esta persona aprobó`. El
    # historial no guardaba autor, así que se imputaban a quien firmó el
    # informe TODAS las correcciones del modelo, vinieran de quien vinieran.
    # Con 2-5 validadores alternándose sobre el mismo modelo eso invierte la
    # señal: quien revisa a fondo hereda las correcciones del otro, y quien
    # aprueba en bloque aparece con correcciones que no hizo. La función misma
    # declaraba la aproximación en el campo `atribucion`.
    #
    # Ahora cada corrección lleva su firmante, así que se cuentan las suyas de
    # verdad. `autor_de()` normaliza los registros previos a SIN_AUTOR.
    suyas = [r for r in correcciones if autor_de(r) == validador]

    # Los registros anteriores a PENDIENTE-2 no tienen autor y NO se les puede
    # asignar uno: se cuentan aparte. Se conservan —son meses de calibración—
    # pero no se imputan a nadie, porque inventar el autor es exactamente lo
    # que esta corrección elimina.
    sin_autor = [r for r in correcciones if autor_de(r) == SIN_AUTOR]

    n_aprob = len(aprobaciones)
    señales = []
    if n_aprob >= 3 and not suyas:
        # El aviso se emite igual, pero si hay correcciones sin autor la señal
        # no es concluyente: alguna podría ser suya. Se dice, en vez de
        # presentar como hallazgo lo que es una laguna del dato histórico.
        _sufijo = ""
        if sin_autor:
            _sufijo = (f" (no concluyente: {len(sin_autor)} correcciones del "
                       f"historial son anteriores al registro de autoría y "
                       f"podrían ser suyas)")
        señales.append(
            f"{n_aprob} aprobaciones sin ninguna corrección registrada. "
            f"Verificar que la revisión sea efectiva y no una aprobación en "
            f"bloque.{_sufijo}")
    if len(modelos_aprobados) == 1 and n_aprob >= 3:
        señales.append(
            f"Todas las aprobaciones concentradas en un único modelo "
            f"({next(iter(modelos_aprobados), '?')}): sin rotación.")

    return {
        "validador": validador,
        "n_aprobaciones": n_aprob,
        "n_modelos": len(modelos_aprobados),
        "n_correcciones_atribuidas": len(suyas),
        "n_correcciones_sin_autor": len(sin_autor),
        "atribucion": "por firma de la corrección (el historial registra el "
                      "autor de cada una)",
        "señales": señales,
        "uso": "INTERNO — calidad del proceso. NO incluir en el informe "
               "entregado al regulador.",
    }


def guardar_calidad_proceso(datos: Dict, outputs_dir) -> "Optional[object]":
    """Persiste el reporte interno junto a las salidas, en fichero separado."""
    import json
    from pathlib import Path
    if not datos.get("validador"):
        return None
    destino = Path(outputs_dir) / "calidad_proceso_interno.json"
    try:
        previo = json.loads(destino.read_text(encoding="utf-8")) if destino.exists() else []
        if not isinstance(previo, list):
            previo = []
    except (json.JSONDecodeError, OSError):
        previo = []
    previo.append(datos)
    try:
        destino.write_text(json.dumps(previo, ensure_ascii=False, indent=2),
                           encoding="utf-8")
        return destino
    except OSError:
        return None
