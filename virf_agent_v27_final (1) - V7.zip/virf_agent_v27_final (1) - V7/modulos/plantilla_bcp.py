"""
Plantilla común de los informes Word de VIRF (estética «Informe de Resultados»).

La usan los TRES informes —Solo Informe, «Generar informe» de la web y el
entregable del pipeline— para que compartan estructura y aspecto:

    Portada BCP → Índice → I. Objetivos → II. Alcance → III. Cumplimiento de
    Estándar → IV. Información Relevante (ficha del documento, contexto,
    limitaciones, fechas, conclusión) → V. Cuadro Resumen de Observaciones →
    VI. Glosario → VII. Barrido de Controles → Anexos A, B, C…

Encabezado «Página | N» + logo en todas las páginas; pie «VALIDACIÓN INTERNA
DE RIESGO FINANCIERO · Informe Final». La calificación sale SIEMPRE de
`modulos.reglas_informe.concluir`.

Cada informe aporta sus datos ya normalizados (ver `generar`) y, si tiene más
conocimiento que mostrar, ganchos: detalle extra por control, contenido extra
tras la conclusión y anexos. Así el informe del pipeline puede ser mucho más
rico que Solo Informe sin dejar de parecerse.

Vive en `modulos/` porque el entregable del pipeline no puede importar `web/`.
"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

from modulos import reglas_informe as reglas
# Por el módulo, no por nombre: así quien sustituye `word_estilo.localizar_logo`
# (p. ej. un test que fuerza la ausencia de logo) afecta también a la plantilla.
from modulos import word_estilo as _WE

# ══════════════════════════════════════════════════════════════════════
#  Sistema de estilo editorial (antes en web/services/informe_web.py)
# ══════════════════════════════════════════════════════════════════════

_FONT = "Flexo"                         # tipografía obligatoria (fallback: sans del sistema)
_FONT_MONO = "Consolas"

_AZUL = RGBColor(0x1F, 0x38, 0x64)      # títulos / acento primario
_AZUL2 = RGBColor(0x2E, 0x5A, 0x88)     # subtítulos / etiquetas
_GRIS = RGBColor(0x6E, 0x74, 0x80)      # metadatos / secundario
_TINTA = RGBColor(0x23, 0x26, 0x2E)     # cuerpo
_SELLO = RGBColor(0xB4, 0x4B, 0x3E)     # acento VIRF (uso muy puntual)

# Anchura útil A4 con márgenes de 2.3 cm.
_ANCHO_UTIL_CM = 16.4

_HEADER_FILL = "E7ECF4"                 # encabezado de tabla: navy sutil

_ALIGN = {"l": WD_ALIGN_PARAGRAPH.LEFT, "r": WD_ALIGN_PARAGRAPH.RIGHT,
          "c": WD_ALIGN_PARAGRAPH.CENTER, "j": WD_ALIGN_PARAGRAPH.JUSTIFY}


def _set_cell_bg(cell, hex_rgb: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_rgb)
    tc_pr.append(shd)


def _cell_left_accent(cell, hex_rgb: str, size: int = 18) -> None:
    """Barra de color en el borde izquierdo de la celda (acento de callout)."""
    tc_pr = cell._tc.get_or_add_tcPr()
    borders = OxmlElement("w:tcBorders")
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single"); left.set(qn("w:sz"), str(size))
    left.set(qn("w:space"), "0"); left.set(qn("w:color"), hex_rgb)
    borders.append(left)
    tc_pr.append(borders)


def _cell_margins(cell, top=60, bottom=60, left=110, right=110) -> None:
    """Padding interno de una celda (en twips: 20 = 1 pt aprox.)."""
    tc_pr = cell._tc.get_or_add_tcPr()
    m = OxmlElement("w:tcMar")
    for lado, val in (("top", top), ("bottom", bottom), ("start", left), ("end", right)):
        el = OxmlElement(f"w:{lado}")
        el.set(qn("w:w"), str(val)); el.set(qn("w:type"), "dxa")
        m.append(el)
    tc_pr.append(m)


def _run(p, texto, *, size=11, bold=False, italic=False, color=None, mono=False):
    r = p.add_run(texto)
    r.font.name = _FONT_MONO if mono else _FONT
    r.font.size = Pt(size)
    r.font.bold = bold
    r.font.italic = italic
    if color is not None:
        r.font.color.rgb = color
    return r


def _p(doc, texto, *, size=11, italic=False, bold=False, color=None,
       align="j", space_after=6, space_before=0):
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_after = Pt(space_after); pf.space_before = Pt(space_before)
    pf.line_spacing = 1.3
    p.alignment = _ALIGN.get(align, WD_ALIGN_PARAGRAPH.JUSTIFY)
    _run(p, texto, size=size, italic=italic, bold=bold, color=color)
    return p


def _etiqueta_valor(doc, etiqueta, valor, *, size=10):
    """Línea «Etiqueta: valor», etiqueta en color, cuerpo justificado."""
    if valor is None or str(valor).strip() == "":
        return
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.space_after = Pt(4); pf.line_spacing = 1.25
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    _run(p, f"{etiqueta}: ", size=size, bold=True, color=_AZUL2)
    _run(p, str(valor), size=size, color=_TINTA)


def _caption(doc, texto):
    """Pie de tabla/figura: pequeño, gris, centrado."""
    _p(doc, texto, size=8.5, italic=True, color=_GRIS, align="c",
       space_after=8, space_before=2)


def _forzar_ancho(tabla, widths_cm) -> None:
    """Fija el ancho de columnas (cm) en TODAS las filas y desactiva autofit."""
    tabla.autofit = False
    tabla.allow_autofit = False
    tblPr = tabla._tbl.tblPr
    tblW = tblPr.find(qn("w:tblW"))
    if tblW is None:
        tblW = OxmlElement("w:tblW"); tblPr.append(tblW)
    tblW.set(qn("w:type"), "dxa")
    tblW.set(qn("w:w"), str(int(sum(widths_cm) * 567)))
    for fila in tabla.rows:
        for i, celda in enumerate(fila.cells):
            if i < len(widths_cm):
                celda.width = Cm(widths_cm[i])


def _tbl_header_repeat():
    """Repite la fila de encabezado si la tabla se parte entre páginas."""
    el = OxmlElement("w:tblHeader"); el.set(qn("w:val"), "true")
    return el


def _tabla(doc, headers, filas, widths_cm, aligns, *, cap_font=9,
           header_fill=_HEADER_FILL):
    """
    Tabla editorial: encabezado sólido y sutil, columnas proporcionales,
    alineación por columna ('l'/'r'/'c'), centrada como bloque.
    Devuelve la tabla (por si hay que colorear celdas puntuales).
    """
    tabla = doc.add_table(rows=1, cols=len(headers))
    tabla.style = "Table Grid"
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        celda = tabla.rows[0].cells[i]
        _set_cell_bg(celda, header_fill); _cell_margins(celda)
        par = celda.paragraphs[0]
        par.alignment = _ALIGN.get(aligns[i], WD_ALIGN_PARAGRAPH.LEFT)
        _run(par, str(h), size=cap_font, bold=True, color=_AZUL)
    for fila in filas:
        celdas = tabla.add_row().cells
        for i, val in enumerate(fila):
            _cell_margins(celdas[i])
            par = celdas[i].paragraphs[0]
            par.paragraph_format.line_spacing = 1.2
            par.alignment = _ALIGN.get(aligns[i], WD_ALIGN_PARAGRAPH.LEFT)
            _run(par, "" if val is None else str(val), size=cap_font)
    _forzar_ancho(tabla, widths_cm)
    tabla.rows[0]._tr.get_or_add_trPr().append(_tbl_header_repeat())
    return tabla


def _callout(doc, titulo, cuerpo, *, accent_hex: str, fill_hex: str,
             cuerpo_italic=False):
    tabla = doc.add_table(rows=1, cols=1)
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
    _forzar_ancho(tabla, [_ANCHO_UTIL_CM])
    celda = tabla.rows[0].cells[0]
    _set_cell_bg(celda, fill_hex)
    _cell_left_accent(celda, accent_hex)
    _cell_margins(celda, top=80, bottom=80, left=160, right=140)
    p = celda.paragraphs[0]; p.paragraph_format.space_after = Pt(2)
    if titulo:
        _run(p, titulo, size=9.5, bold=True, color=RGBColor.from_string(accent_hex))
    if cuerpo:
        p2 = celda.add_paragraph(); p2.paragraph_format.line_spacing = 1.25
        p2.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        _run(p2, cuerpo, size=10, italic=cuerpo_italic, color=_TINTA)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _bloque_codigo(doc, codigo: str, archivo: str = ""):
    if archivo:
        _p(doc, f"📄 {archivo}", size=8, italic=True, color=_GRIS, align="l", space_after=1)
    tabla = doc.add_table(rows=1, cols=1)
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
    _forzar_ancho(tabla, [_ANCHO_UTIL_CM])
    celda = tabla.rows[0].cells[0]
    _set_cell_bg(celda, "F2F2F5"); _cell_margins(celda)
    _run(celda.paragraphs[0], codigo, size=9, mono=True)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def _linea_horizontal(doc, color: RGBColor, grosor: int = 12):
    p = doc.add_paragraph()
    bdr = OxmlElement("w:pBdr"); bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single"); bottom.set(qn("w:sz"), str(grosor))
    bottom.set(qn("w:space"), "1"); bottom.set(qn("w:color"), str(color))
    bdr.append(bottom); p._p.get_or_add_pPr().append(bdr)


def _salto_pagina(doc):
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)


def _estilo_base(doc):
    """Fuente Flexo, interlineado, control de viudas y estilos de título."""
    normal = doc.styles["Normal"]
    normal.font.name = _FONT
    normal.font.size = Pt(11)
    normal.font.color.rgb = _TINTA
    pf = normal.paragraph_format
    pf.line_spacing = 1.3
    pf.space_after = Pt(6)
    pPr = normal.element.get_or_add_pPr()
    if pPr.find(qn("w:widowControl")) is None:
        wc = OxmlElement("w:widowControl"); wc.set(qn("w:val"), "1"); pPr.append(wc)
    for lvl, size in ((1, 19), (2, 14.5), (3, 12.5)):
        try:
            st = doc.styles[f"Heading {lvl}"]
            st.font.name = _FONT; st.font.bold = True
            st.font.size = Pt(size)
            st.font.color.rgb = _AZUL if lvl == 1 else _AZUL2
            st.paragraph_format.keep_with_next = True
        except KeyError:
            pass


# ══════════════════════════════════════════════════════════════════════
#  Piezas de la plantilla «Informe de Resultados»
# ══════════════════════════════════════════════════════════════════════

_MESES = ("enero", "febrero", "marzo", "abril", "mayo", "junio", "julio",
          "agosto", "septiembre", "octubre", "noviembre", "diciembre")

FILL_RIESGO = {
    "Crítico": "F4CCCC", "Moderado": "FCE4D6", "Bajo": "FFF2CC",
    "Potencial": "E2EFDA", "Oportunidad de Mejora": "DDEBF7",
}
_FILL_ALERTA, _ACENTO_ALERTA = "F8D7DA", "C0392B"
_FILL_OK, _ACENTO_OK = "E2EFDA", "548235"
_FILL_AVISO, _ACENTO_AVISO = "FFF2CC", "B8832B"
_FILL_CITA, _ACENTO_CITA = "EAF0F7", "1F3864"

_ROMANOS = ("I", "II", "III", "IV", "V", "VI", "VII")
_LETRAS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

REVISOR_POR_DEFECTO = "Walter Paiva"

DESCRIPCION_POR_DEFECTO = (
    "Como parte del barrido completo del estándar, se ejecutó la actividad sobre la "
    "evidencia proporcionada por los responsables del modelo, contrastándola con los "
    "criterios del control.")

GLOSARIO_BASE = (
    ("Banco de Crédito del Perú", "BCP", "Entidad financiera titular del modelo validado."),
    ("Validación Interna de Riesgo Financiero", "VIRF",
     "Gerencia encargada de la revisión independiente de los modelos de riesgo financiero."),
    ("Riesgo de modelo", "—",
     "Posibilidad de pérdidas o decisiones erróneas derivadas de errores en el diseño, "
     "la implementación o el uso de un modelo."),
    ("Estándar de validación", "—",
     "Conjunto de ámbitos, controles y actividades que la validación debe cubrir."),
    ("Ámbito", "—",
     "Dimensión evaluada del modelo: Documentación, Calidad de Datos, Metodología, "
     "Implementación, Gobierno y Usos."),
    ("Control", "—", "Requisito del estándar que agrupa una o más actividades de revisión."),
    ("Actividad", "—", "Prueba o revisión concreta que se ejecuta para evaluar un control."),
    ("Observación", "—", "Hallazgo que evidencia un incumplimiento o una debilidad en un control."),
    ("Oportunidad de Mejora", "OM",
     "Hallazgo que no constituye un incumplimiento pero cuya atención fortalecería la gestión del modelo."),
    ("Riesgo crítico", "—",
     "Deficiencia que compromete la fiabilidad del modelo y exige atención inmediata."),
    ("Riesgo moderado", "—", "Deficiencia relevante que debe subsanarse en el corto plazo."),
    ("Riesgo bajo", "—", "Deficiencia de impacto acotado sobre los resultados del modelo."),
    ("Riesgo potencial", "—",
     "Debilidad que aún no se ha materializado pero podría afectar al modelo."),
)


def fecha_larga(iso: Any) -> str:
    try:
        d = datetime.strptime(str(iso)[:10], "%Y-%m-%d")
    except ValueError:
        return str(iso or "—")
    return f"{d.day} de {_MESES[d.month - 1]} de {d.year}"


def periodo_validacion(inicio: Any, entrega: Any) -> str:
    """«octubre de 2026» si inicio y entrega caen en el mismo mes; si no,
    «entre septiembre y noviembre de 2026» (o con los dos años si cambian)."""
    try:
        a = datetime.strptime(str(inicio)[:10], "%Y-%m-%d")
        b = datetime.strptime(str(entrega)[:10], "%Y-%m-%d")
    except ValueError:
        return fecha_larga(entrega).split(" de ", 1)[-1]
    if (a.year, a.month) == (b.year, b.month):
        return f"{_MESES[a.month - 1]} de {a.year}"
    if a.year == b.year:
        return f"entre {_MESES[a.month - 1]} y {_MESES[b.month - 1]} de {a.year}"
    return (f"entre {_MESES[a.month - 1]} de {a.year} y "
            f"{_MESES[b.month - 1]} de {b.year}")


def _parrafos(doc, texto: str, vacio: str) -> None:
    trozos = [t.strip() for t in re.split(r"\n\s*\n", texto or "") if t.strip()]
    if not trozos:
        _p(doc, vacio, size=10.5, italic=True, color=_GRIS)
    for t in trozos:
        _p(doc, t, size=10.5)


def _texto_o_gancho(doc, valor, vacio: str) -> None:
    if callable(valor):
        valor(doc)
    else:
        _parrafos(doc, valor or "", vacio)


def _bullet(doc, texto: str, *, nivel: int = 1, negrita: str = ""):
    p = doc.add_paragraph(style="List Bullet" if nivel == 1 else "List Bullet 2")
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.line_spacing = 1.25
    if negrita:
        _run(p, negrita, size=10.5, bold=True, color=_AZUL2)
    _run(p, texto, size=10.5, color=_TINTA)
    return p


def no_partir(tabla, entera: bool = True) -> None:
    """Filas indivisibles; con `entera`, además cada fila pegada a la siguiente
    (Word solo parte la tabla si no cabe en una página entera)."""
    filas = tabla.rows
    for i, fila in enumerate(filas):
        fila._tr.get_or_add_trPr().append(OxmlElement("w:cantSplit"))
        if entera and i < len(filas) - 1:
            for celda in fila.cells:
                for p in celda.paragraphs:
                    p.paragraph_format.keep_with_next = True


# Elementos de <w:pPr> que, según el esquema OOXML, van DESPUÉS de pBdr/shd.
# Word rechaza el documento («contenido ilegible») si el orden no se respeta,
# así que el borde y el sombreado se insertan antes del primero que exista.
_PPR_TRAS_SHD = ("w:tabs", "w:suppressAutoHyphens", "w:kinsoku", "w:wordWrap",
                 "w:overflowPunct", "w:topLinePunct", "w:autoSpaceDE", "w:autoSpaceDN",
                 "w:bidi", "w:adjustRightInd", "w:snapToGrid", "w:spacing", "w:ind",
                 "w:contextualSpacing", "w:mirrorIndents", "w:suppressOverlap", "w:jc",
                 "w:textDirection", "w:textAlignment", "w:textboxTightWrap",
                 "w:outlineLvl", "w:divId", "w:cnfStyle", "w:rPr", "w:sectPr",
                 "w:pPrChange")


def resaltar(parrafo, fill: str, acento: str) -> None:
    """Fondo y barra izquierda a nivel de PÁRRAFO (sin tabla)."""
    ppr = parrafo._p.get_or_add_pPr()
    bdr = OxmlElement("w:pBdr")
    izq = OxmlElement("w:left")
    for k, v in (("w:val", "single"), ("w:sz", "24"), ("w:space", "6"), ("w:color", acento)):
        izq.set(qn(k), v)
    bdr.append(izq)
    shd = OxmlElement("w:shd")
    for k, v in (("w:val", "clear"), ("w:color", "auto"), ("w:fill", fill)):
        shd.set(qn(k), v)
    ancla = next((el for el in ppr if el.tag in {qn(t) for t in _PPR_TRAS_SHD}), None)
    for el in (bdr, shd):
        if ancla is None:
            ppr.append(el)
        else:
            ancla.addprevious(el)


def campo(doc, etiqueta: str, texto: str = "", *, sangria: float = 0.6,
          seguir: bool = True):
    """Línea «Etiqueta: texto» del barrido (texto plano estructurado)."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.left_indent = Cm(sangria); pf.space_after = Pt(3); pf.line_spacing = 1.25
    pf.keep_with_next = seguir
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    _run(p, f"{etiqueta}: ", size=10, bold=True, color=_AZUL2)
    if texto:
        _run(p, str(texto), size=10, color=_TINTA)
    return p


def cita(doc, titulo: str, texto: str, *, aviso: bool = False, sangria: float = 0.6):
    """Cita o aviso destacado en PÁRRAFO sombreado (sin tabla), para el barrido."""
    p = doc.add_paragraph()
    pf = p.paragraph_format
    pf.left_indent = Cm(sangria); pf.space_after = Pt(4); pf.line_spacing = 1.25
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    acento = _ACENTO_AVISO if aviso else _ACENTO_CITA
    if titulo:
        _run(p, f"{titulo}: ", size=9.5, bold=True, color=RGBColor.from_string(acento))
    _run(p, str(texto), size=9.5, italic=not aviso, color=_TINTA)
    resaltar(p, _FILL_AVISO if aviso else _FILL_CITA, acento)
    return p


# ── Marcadores + índice con hipervínculos ────────────────────────────

class Marcadores:
    def __init__(self):
        self.n = 0

    def envolver(self, parrafo, nombre: str) -> None:
        self.n += 1
        ini = OxmlElement("w:bookmarkStart")
        ini.set(qn("w:id"), str(self.n)); ini.set(qn("w:name"), nombre)
        fin = OxmlElement("w:bookmarkEnd"); fin.set(qn("w:id"), str(self.n))
        parrafo._p.insert(1 if parrafo._p.pPr is not None else 0, ini)
        parrafo._p.append(fin)


def titulo(doc, marcas: Marcadores, texto: str, nivel: int, bm: str) -> None:
    h = doc.add_heading(level=nivel)
    h.alignment = WD_ALIGN_PARAGRAPH.LEFT
    pf = h.paragraph_format
    pf.keep_with_next = True
    pf.space_before = Pt(16 if nivel == 1 else 10)
    pf.space_after = Pt(8 if nivel == 1 else 5)
    _run(h, texto, size={1: 16, 2: 13}.get(nivel, 12), bold=True,
         color=_AZUL if nivel == 1 else _AZUL2)
    marcas.envolver(h, bm)


def _fld(run, tipo: str):
    el = OxmlElement("w:fldChar"); el.set(qn("w:fldCharType"), tipo)
    run._r.append(el)


def _hipervinculo(parrafo, texto: str, ancla: str, size: float):
    hl = OxmlElement("w:hyperlink")
    hl.set(qn("w:anchor"), ancla); hl.set(qn("w:history"), "1")
    r = OxmlElement("w:r"); rpr = OxmlElement("w:rPr")
    color = OxmlElement("w:color"); color.set(qn("w:val"), "1F3864")
    sz = OxmlElement("w:sz"); sz.set(qn("w:val"), str(int(size * 2)))
    rpr.append(color); rpr.append(sz); r.append(rpr)
    t = OxmlElement("w:t"); t.text = texto; t.set(qn("xml:space"), "preserve")
    r.append(t); hl.append(r)
    parrafo._p.append(hl)


def _indice(doc, entradas: list[tuple[str, int, str]]) -> None:
    """
    Campo TOC real (Word lo regenera con números de página al abrir: se activa
    `updateFields`) cuyo resultado precargado ya son hipervínculos a los
    marcadores de cada título, así el índice funciona aunque no se actualice.
    """
    for i, (texto, nivel, bm) in enumerate(entradas):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(3)
        p.paragraph_format.left_indent = Cm(0 if nivel == 1 else 0.8)
        if i == 0:
            r = p.add_run(); _fld(r, "begin")
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve")
            it.text = r'TOC \o "1-2" \h \z \u'; r._r.append(it)
            _fld(r, "separate")
        _hipervinculo(p, texto, bm, 11 if nivel == 1 else 10)
        if i == len(entradas) - 1:
            _fld(p.add_run(), "end")
    upd = OxmlElement("w:updateFields"); upd.set(qn("w:val"), "true")
    doc.settings.element.append(upd)


# ── Encabezado, pie y portada ────────────────────────────────────────

def _logo(raiz: Optional[Path]):
    ruta = _WE.localizar_logo(raiz)
    return _WE.logo_para_word(ruta) if ruta else None


def _encabezado_pie(doc, logo_fn: Callable, pie_derecho: str) -> None:
    sec = doc.sections[0]
    # Encabezado: «Página | N» a la izquierda y el logo a la derecha.
    hp = sec.header.paragraphs[0]
    hp.style = doc.styles["Normal"]
    hp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    hp.paragraph_format.tab_stops.add_tab_stop(Cm(_ANCHO_UTIL_CM), WD_TAB_ALIGNMENT.RIGHT)
    _run(hp, "Página | ", size=9, color=_GRIS)
    r = _run(hp, "", size=9, bold=True, color=_AZUL)
    _fld(r, "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    r._r.append(it)
    _fld(r, "separate")
    t = OxmlElement("w:t"); t.text = "1"; r._r.append(t)
    _fld(r, "end")
    _run(hp, "\t", size=9)
    buf = logo_fn()
    if buf is not None:
        hp.add_run().add_picture(buf, height=Cm(1.0))
    else:
        _run(hp, "[Logo BCP]", size=8, color=_GRIS)

    fp = sec.footer.paragraphs[0]
    fp.style = doc.styles["Normal"]
    fp.paragraph_format.tab_stops.add_tab_stop(Cm(_ANCHO_UTIL_CM), WD_TAB_ALIGNMENT.RIGHT)
    _run(fp, "VALIDACIÓN INTERNA DE RIESGO FINANCIERO", size=8, bold=True, color=_GRIS)
    _run(fp, "\t", size=8)
    _run(fp, pie_derecho, size=8, italic=True, color=_GRIS)


def _es_periodica(inf: dict) -> bool:
    return inf.get("tipo", "periodica") == "periodica"


def _portada(doc, inf: dict, logo_fn: Callable) -> None:
    for txt in ("Gerencia de Administración de Riesgo de Modelo",
                "Gerencia de Validación Interna de Riesgo Financiero",
                "Banco de Crédito"):
        _p(doc, txt, size=12, bold=True, color=_AZUL, align="c", space_after=2)

    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(40); p.paragraph_format.space_after = Pt(40)
    buf = logo_fn()
    if buf is not None:
        p.add_run().add_picture(buf, width=Cm(6.0))
    else:
        _run(p, "[Logo BCP: coloca el archivo en inputs/logoempresa/]", size=10,
             italic=True, color=_GRIS)

    _p(doc, inf.get("titulo_portada") or "Informe de Resultados", size=26, bold=True,
       color=_AZUL, align="c", space_after=6)
    tipo = "Validación Periódica" if _es_periodica(inf) else "Validación por Primera Vez"
    _p(doc, tipo, size=16, color=_AZUL2, align="c", space_after=14)
    _linea_horizontal(doc, _SELLO)
    pref = "Validación periódica" if _es_periodica(inf) else "Validación por primera vez"
    _p(doc, f"{pref} de {inf['nombre_modelo']}", size=14, bold=True, color=_TINTA,
       align="c", space_before=10, space_after=6)
    _p(doc, fecha_larga(inf.get("fecha_entrega")), size=12, color=_GRIS, align="c")
    if inf.get("subtitulo_portada"):
        _p(doc, inf["subtitulo_portada"], size=10, italic=True, color=_GRIS, align="c")
    _salto_pagina(doc)


# ── Secciones I–VII ──────────────────────────────────────────────────

def _objetivos(doc, inf):
    desde = "desde la última validación" if _es_periodica(inf) else "en su primera validación"
    _p(doc, f"Evaluar la gestión del modelo {inf['nombre_modelo']} {desde}, en los "
            "ámbitos de documentación, calidad de datos, metodología, implementación, "
            "gobierno y usos, conforme al estándar de validación vigente.", size=10.5)


def _alcance(doc, inf):
    _p(doc, "La validación comprendió un barrido completo de los siguientes ámbitos y "
            f"controles del estándar de validación{inf.get('nota_alcance') or ''}:", size=10.5)
    for amb in inf["ambitos"]:
        ctrls = [c for c in inf["controles"] if c["ambito"] == amb]
        _bullet(doc, f" ({len(ctrls)} actividad(es)).", negrita=amb)
        vistos: list[str] = []
        for c in ctrls:
            nombre = c.get("control") or c["actividad"]
            if nombre not in vistos:
                vistos.append(nombre)
        for nombre in vistos:
            _bullet(doc, nombre, nivel=2)


def observaciones_por_control(observaciones: Iterable[dict]) -> dict[str, list[dict]]:
    d: dict[str, list[dict]] = {}
    for o in observaciones:
        d.setdefault(o.get("control_id") or "", []).append(o)
    return d


def control_satisfactorio(control: dict, obs: list[dict]) -> bool:
    """Un control no evaluado (fallo técnico) no puede darse por satisfactorio."""
    return not control.get("no_evaluado") and reglas.control_cumple(obs)


def cumplimiento(inf: dict) -> list[dict]:
    """Fila por ámbito: total, satisfactorios y no cumplidos (con %)."""
    por_ctrl = observaciones_por_control(inf["observaciones"])
    filas = []
    for amb in inf["ambitos"]:
        ctrls = [c for c in inf["controles"] if c["ambito"] == amb]
        total = len(ctrls)
        ok = sum(1 for c in ctrls if control_satisfactorio(c, por_ctrl.get(c["id"], [])))
        no_ok = total - ok
        filas.append({
            "ambito": amb, "total": total, "satisfactorios": ok, "no_cumplidos": no_ok,
            "pct_ok": round(100 * ok / total, 1) if total else 0.0,
            "pct_no": round(100 * no_ok / total, 1) if total else 0.0,
        })
    return filas


def _cumplimiento(doc, inf):
    filas = cumplimiento(inf)
    tot = sum(f["total"] for f in filas)
    ok = sum(f["satisfactorios"] for f in filas)
    no = tot - ok
    datos_tabla = [[f["ambito"], f["total"], f"{f['satisfactorios']} ({f['pct_ok']:.1f}%)",
                    f"{f['no_cumplidos']} ({f['pct_no']:.1f}%)"] for f in filas]
    datos_tabla.append(["Total", tot,
                        f"{ok} ({100 * ok / tot if tot else 0:.1f}%)",
                        f"{no} ({100 * no / tot if tot else 0:.1f}%)"])
    t = _tabla(doc, ["Ámbito", "Total de Controles", "Controles Satisfactorios (%)",
                     "Controles no cumplidos (%)"],
               datos_tabla, widths_cm=[5.2, 3.2, 4.0, 4.0], aligns=["l", "c", "c", "c"],
               cap_font=9.5)
    no_partir(t)
    for celda in t.rows[-1].cells:
        for r in celda.paragraphs[0].runs:
            r.font.bold = True
    nota = ("Cumplimiento del estándar por ámbito. Un control se considera no cumplido "
            "cuando tiene al menos una observación de riesgo")
    n_ne = sum(1 for c in inf["controles"] if c.get("no_evaluado"))
    if n_ne:
        nota += f"; los {n_ne} no evaluados por fallo técnico tampoco se dan por satisfactorios"
    _caption(doc, nota + ".")


def _ficha_documento(doc, inf):
    """Cuadro de control del documento al inicio de «Información Relevante».
    La fecha de aprobación es la de entrega (la misma que figura en las fechas
    de la validación), para que no puedan divergir."""
    primera = not _es_periodica(inf)
    tipo = "Validación por Primera Vez" if primera else "Validación Periódica"
    periodo = periodo_validacion(inf.get("fecha_inicio"), inf.get("fecha_entrega"))
    filas = [
        ["Título", f"{tipo} {inf['nombre_modelo']}"],
        ["Descripción del documento",
         f"El presente documento resume el análisis de la "
         f"{'validación por primera vez' if primera else 'validación periódica'} "
         f"realizada {'' if periodo.startswith('entre ') else 'en '}{periodo}."],
        ["Responsable de la documentación", (inf.get("responsable_doc") or "").strip() or "—"],
        ["Revisado por", (inf.get("revisado_por") or "").strip() or REVISOR_POR_DEFECTO],
        ["Fecha de aprobación", fecha_larga(inf.get("fecha_entrega"))],
    ]
    t = _tabla(doc, ["Campo", "Detalle"], filas, widths_cm=[5.2, _ANCHO_UTIL_CM - 5.2],
               aligns=["l", "l"], cap_font=10)
    for fila in t.rows[1:]:
        for r in fila.cells[0].paragraphs[0].runs:
            r.font.bold = True; r.font.color.rgb = _AZUL2
    no_partir(t)
    _caption(doc, "Ficha del documento.")


def _info_relevante(doc, marcas, inf, conclusion, n):
    _ficha_documento(doc, inf)
    titulo(doc, marcas, f"{n}.1 Contexto del modelo y antecedentes", 2, "sec_iv_1")
    _texto_o_gancho(doc, inf.get("contexto"), "No se registró contexto del modelo.")
    titulo(doc, marcas, f"{n}.2 Limitaciones", 2, "sec_iv_2")
    _texto_o_gancho(doc, inf.get("limitaciones"),
                    "No se identificaron limitaciones durante la validación.")
    titulo(doc, marcas, f"{n}.3 Fechas de la validación", 2, "sec_iv_3")
    _tabla(doc, ["Hito", "Fecha"],
           [["Inicio de la validación", fecha_larga(inf.get("fecha_inicio"))],
            ["Entrega del informe", fecha_larga(inf.get("fecha_entrega"))]],
           widths_cm=[8.2, 8.2], aligns=["l", "l"], cap_font=10)
    doc.add_paragraph()
    titulo(doc, marcas, f"{n}.4 Conclusión", 2, "sec_iv_4")
    nivel = conclusion["nivel"]
    alerta = nivel in ("Regular", "Deficiente")
    tabla = doc.add_table(rows=1, cols=1)
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
    _forzar_ancho(tabla, [_ANCHO_UTIL_CM])
    no_partir(tabla)
    celda = tabla.rows[0].cells[0]
    _set_cell_bg(celda, _FILL_ALERTA if alerta else _FILL_OK)
    _cell_left_accent(celda, _ACENTO_ALERTA if alerta else _ACENTO_OK, size=24)
    _cell_margins(celda, top=100, bottom=100, left=180, right=160)
    p = celda.paragraphs[0]
    _run(p, f"Calificación: {nivel.upper()}", size=13, bold=True,
         color=RGBColor.from_string(_ACENTO_ALERTA if alerta else _ACENTO_OK))
    p2 = celda.add_paragraph(); p2.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    _run(p2, reglas.texto_conclusion(nivel, inf["nombre_modelo"]) + " ", size=10.5)
    _run(p2, f"Motivo: {conclusion['motivo']}", size=10.5, italic=True)
    c = conclusion["conteos"]
    p3 = celda.add_paragraph()
    _run(p3, f"Críticas: {c['criticas']} · Moderadas: {c['moderadas']} · "
             f"Bajas/potenciales: {c['bajas_potenciales']} · Oportunidades de mejora: {c['om']}",
         size=9, color=_GRIS)
    n_ne = sum(1 for x in inf["controles"] if x.get("no_evaluado"))
    if n_ne:
        p4 = celda.add_paragraph()
        _run(p4, f"⚠ {n_ne} actividad(es) no evaluada(s) por un fallo técnico: deben "
                 "re-ejecutarse antes de emitir dictamen sobre ellas.", size=9.5, bold=True,
             color=RGBColor.from_string(_ACENTO_AVISO))
    if callable(inf.get("conclusion_extra")):
        doc.add_paragraph().paragraph_format.space_after = Pt(2)
        inf["conclusion_extra"](doc)


def _cuadro_resumen(doc, inf, ctrl_por_id):
    obs = inf["observaciones"]
    if not obs:
        _p(doc, "No se registraron observaciones en la validación.", size=10.5,
           italic=True, color=_GRIS)
        return
    filas = []
    for i, o in enumerate(obs, start=1):
        c = ctrl_por_id.get(o.get("control_id"), {})
        resp = " · ".join(x for x in ((o.get("responsable") or "").strip(),
                                      fecha_larga(o["fecha_subsanacion"])
                                      if o.get("fecha_subsanacion") else "") if x)
        filas.append([i, c.get("ambito", o.get("ambito", "")),
                      reglas.normalizar_riesgo(o["riesgo"]), c.get("actividad", o.get("actividad", "")),
                      o.get("observacion", ""), o.get("recomendacion", ""), resp or "—"])
    t = _tabla(doc, ["N°", "Ámbito", "Riesgo", "Actividad", "Observación",
                     "Recomendación", "Responsable / Fecha"],
               filas, widths_cm=[0.7, 2.3, 2.2, 2.6, 3.4, 2.9, 2.3],
               aligns=["c", "l", "c", "l", "l", "l", "l"], cap_font=8)
    for fila, o in zip(t.rows[1:], obs):
        _set_cell_bg(fila.cells[2], FILL_RIESGO[reglas.normalizar_riesgo(o["riesgo"])])
    no_partir(t, entera=False)
    _caption(doc, inf.get("nota_cuadro") or "Cuadro resumen de las observaciones registradas.")


def _glosario(doc, inf):
    filas = [list(g) for g in GLOSARIO_BASE]
    ya = {f[0].lower() for f in filas}
    filas += [list(g) for g in inf.get("glosario_extra") or () if g[0].lower() not in ya]
    t = _tabla(doc, ["Término", "Sigla", "Descripción"], filas,
               widths_cm=[4.4, 1.8, 10.2], aligns=["l", "c", "l"], cap_font=9)
    no_partir(t, entera=False)


def _imagen(doc, ruta: Optional[Path], ancho_cm: float) -> bool:
    if not ruta or not Path(ruta).is_file():
        return False
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True
    try:
        p.add_run().add_picture(str(ruta), width=Cm(ancho_cm))
    except Exception:                                 # noqa: BLE001
        _run(p, "(no se pudo insertar la imagen)", size=9, italic=True, color=_GRIS)
    return True


def _sustento(doc, o, num):
    s = o.get("sustento") or {}
    tipo = s.get("tipo") or ""
    if tipo == "imagen":
        _p(doc, f"Sustento de la observación {num}:", size=9, italic=True,
           color=_GRIS, align="l", space_after=2)
        _imagen(doc, s.get("imagen_ruta"), 13)
        if s.get("contenido"):
            _caption(doc, s["contenido"])
    elif tipo == "codigo" and s.get("contenido"):
        _p(doc, f"Sustento de la observación {num} (código):", size=9, italic=True,
           color=_GRIS, align="l", space_after=2)
        _bloque_codigo(doc, s["contenido"])
    elif tipo == "texto" and s.get("contenido"):
        _p(doc, f"Sustento de la observación {num}: {s['contenido']}", size=9.5,
           italic=True, color=_TINTA)
    if _imagen(doc, o.get("grafico_ruta"), 14):
        _caption(doc, f"Esquema de apoyo de la observación {num}.")


def _barrido(doc, marcas, inf, n, num_obs):
    """
    Barrido de TODO el estándar en texto estructurado (sin tablas): por ámbito,
    cada control con su título numerado y las líneas Actividad, Descripción de
    lo realizado, Resultados y Conclusión. La conclusión de un control no
    adecuado lleva fondo rojizo de alerta.
    """
    por_ctrl = observaciones_por_control(inf["observaciones"])
    detalle = inf.get("detalle_control")
    for j, amb in enumerate(inf["ambitos"], start=1):
        titulo(doc, marcas, f"{n}.{j} {amb}", 2, f"sec_vii_{j}")
        ctrls = [c for c in inf["controles"] if c["ambito"] == amb]
        for k, c in enumerate(ctrls, start=1):
            os_ = por_ctrl.get(c["id"], [])
            ctrl = c.get("control") or "Control sin nombre"
            if c.get("control_especifico"):
                ctrl += f" — {c['control_especifico']}"

            h = doc.add_paragraph()
            h.paragraph_format.keep_with_next = True
            h.paragraph_format.space_before = Pt(10)
            h.paragraph_format.space_after = Pt(4)
            _run(h, f"{n}.{j}.{k}  ", size=10.5, bold=True, color=_AZUL)
            _run(h, ctrl, size=10.5, bold=True, color=_AZUL)

            campo(doc, "Actividad", c["actividad"])
            campo(doc, "Descripción de lo realizado",
                  c.get("descripcion") or DESCRIPCION_POR_DEFECTO)

            p = campo(doc, "Resultados")
            if c.get("no_evaluado"):
                _run(p, "NO EVALUADA (fallo técnico durante la corrida)", size=10,
                     bold=True, color=RGBColor.from_string(_ACENTO_AVISO))
            elif not os_:
                _run(p, "Aceptable", size=10, bold=True, color=RGBColor.from_string(_ACENTO_OK))
                if c.get("nota_resultado"):
                    _run(p, f" — {c['nota_resultado']}", size=10, italic=True, color=_GRIS)
            else:
                _run(p, f"Nivel de riesgo {reglas.riesgo_maximo(os_)}", size=10, bold=True)
                for o in os_:
                    q = campo(doc, f"Observación {num_obs[id(o)]} "
                                   f"({reglas.normalizar_riesgo(o['riesgo'])})",
                              o.get("observacion", ""), sangria=1.2)
                    q.runs[0].font.color.rgb = _TINTA
                    if o.get("nota_pie"):
                        try:
                            from modulos.word_estilo import add_nota_pie
                            add_nota_pie(doc, q, o["nota_pie"])
                        except Exception:        # noqa: BLE001 — nunca por una nota al pie
                            pass
                    if o.get("recomendacion"):
                        campo(doc, "Oportunidad de mejora", o["recomendacion"], sangria=1.2)

            if callable(detalle):
                detalle(doc, c, os_)

            if c.get("no_evaluado"):
                p = campo(doc, "Conclusión", seguir=False)
                _run(p, "Este control no pudo evaluarse por un fallo técnico; debe "
                        "re-ejecutarse la validación antes de emitir dictamen sobre él.",
                     size=10, bold=True, color=RGBColor.from_string(_ACENTO_AVISO))
                resaltar(p, _FILL_AVISO, _ACENTO_AVISO)
            else:
                cumple = reglas.control_cumple(os_)
                p = campo(doc, "Conclusión", seguir=False)
                _run(p, reglas.conclusion_control(os_), size=10, bold=not cumple,
                     color=RGBColor.from_string(_ACENTO_ALERTA) if not cumple else _TINTA)
                if not cumple:
                    resaltar(p, _FILL_ALERTA, _ACENTO_ALERTA)
            p.paragraph_format.space_after = Pt(8)

            for o in os_:
                _sustento(doc, o, num_obs[id(o)])


# ══════════════════════════════════════════════════════════════════════
#  API pública
# ══════════════════════════════════════════════════════════════════════

def _quitar_salto_final(doc) -> None:
    """Quita un salto de página vacío al final de un anexo: la plantilla ya abre
    cada anexo en página nueva, y dos saltos seguidos dejan una hoja en blanco."""
    body = doc.element.body
    hijos = [el for el in body if el.tag != qn("w:sectPr")]
    if not hijos or hijos[-1].tag != qn("w:p"):
        return
    ult = hijos[-1]
    textos = "".join(t.text or "" for t in ult.iter(qn("w:t")))
    saltos = [b for b in ult.iter(qn("w:br")) if b.get(qn("w:type")) == "page"]
    if saltos and not textos.strip():
        body.remove(ult)


SECCIONES = ("Objetivos", "Alcance", "Cumplimiento de Estándar", "Información Relevante",
             "Cuadro Resumen de Observaciones", "Glosario", "Barrido de Controles")


def generar(inf: dict[str, Any], ruta: Path, *, raiz_logo: Optional[Path] = None) -> Path:
    """
    Escribe el informe en `ruta`. `inf` (normalizado por cada informe):

      tipo                "periodica" | "primera_vez"
      nombre_modelo, fecha_inicio, fecha_entrega (AAAA-MM-DD)
      responsable_doc, revisado_por
      contexto, limitaciones      texto o función(doc) que pinta el contenido
      ambitos             [nombre…] en orden
      controles           [{id, ambito, control, control_especifico, actividad,
                            descripcion?, no_evaluado?, nota_resultado?}]
      observaciones       [{control_id, ambito, riesgo, observacion, recomendacion,
                            responsable?, fecha_subsanacion?, nota_pie?,
                            sustento?{tipo, contenido, imagen_ruta}, grafico_ruta?}]
    Opcionales: titulo_portada, subtitulo_portada, pie_derecho, nota_alcance,
    nota_cuadro, glosario_extra [(término, sigla, descripción)],
    detalle_control(doc, control, observaciones), conclusion_extra(doc),
    anexos [(título, función(doc))].

    Devuelve la ruta. La calificación sale de `reglas_informe.concluir`.
    """
    obs = list(inf.get("observaciones") or [])
    inf = {**inf, "observaciones": obs}
    ctrl_por_id = {c["id"]: c for c in inf["controles"]}
    for o in obs:
        c = ctrl_por_id.get(o.get("control_id"))
        if c:
            # El ámbito que manda es el del control (para la excepción Doc+Gob).
            o["ambito"] = c["ambito"]
    conclusion = reglas.concluir(obs)
    num_obs = {id(o): i for i, o in enumerate(obs, start=1)}
    anexos = list(inf.get("anexos") or [])

    doc = Document()
    _estilo_base(doc)
    for s in doc.sections:
        s.top_margin = Cm(2.6); s.bottom_margin = Cm(2.3)
        s.left_margin = Cm(2.3); s.right_margin = Cm(2.3)
        s.header_distance = Cm(1.0)

    logo_fn = lambda: _logo(raiz_logo)              # noqa: E731
    _encabezado_pie(doc, logo_fn, inf.get("pie_derecho") or "Informe Final")
    _portada(doc, inf, logo_fn)

    entradas: list[tuple[str, int, str]] = []
    for i, s in enumerate(SECCIONES):
        entradas.append((f"{_ROMANOS[i]}. {s}", 1, f"sec_{_ROMANOS[i].lower()}"))
        if s == "Información Relevante":
            entradas += [(f"{_ROMANOS[i]}.{k} {t}", 2, f"sec_iv_{k}") for k, t in
                         enumerate(("Contexto del modelo y antecedentes", "Limitaciones",
                                    "Fechas de la validación", "Conclusión"), start=1)]
        if s == "Barrido de Controles":
            entradas += [(f"{_ROMANOS[i]}.{j} {a}", 2, f"sec_vii_{j}")
                         for j, a in enumerate(inf["ambitos"], start=1)]
    entradas += [(f"Anexo {_LETRAS[i]}. {t}", 1, f"anexo_{_LETRAS[i].lower()}")
                 for i, (t, _f) in enumerate(anexos)]

    marcas = Marcadores()
    h = doc.add_paragraph()
    _run(h, "Índice", size=16, bold=True, color=_AZUL)
    _indice(doc, entradas)
    _salto_pagina(doc)

    def sec(i):
        titulo(doc, marcas, f"{_ROMANOS[i]}. {SECCIONES[i]}", 1, f"sec_{_ROMANOS[i].lower()}")

    sec(0); _objetivos(doc, inf)
    sec(1); _alcance(doc, inf)
    sec(2); _cumplimiento(doc, inf)
    sec(3); _info_relevante(doc, marcas, inf, conclusion, "IV")
    _salto_pagina(doc)
    sec(4); _cuadro_resumen(doc, inf, ctrl_por_id)
    sec(5); _glosario(doc, inf)
    _salto_pagina(doc)
    sec(6); _barrido(doc, marcas, inf, "VII", num_obs)

    for i, (t, fn) in enumerate(anexos):
        _salto_pagina(doc)
        titulo(doc, marcas, f"Anexo {_LETRAS[i]}. {t}", 1, f"anexo_{_LETRAS[i].lower()}")
        fn(doc)
        _quitar_salto_final(doc)

    ruta = Path(ruta)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    doc.save(ruta)
    return ruta
