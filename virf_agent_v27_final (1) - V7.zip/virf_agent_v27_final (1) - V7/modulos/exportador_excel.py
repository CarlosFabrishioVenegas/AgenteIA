"""
modulos/exportador_excel.py
═════════════════════════════════════════════════════════════════════════════
Exporta la tabla de validación a Excel (.xlsx) con las 8 columnas acordadas:

    Ámbito | Control | Actividad | Aplica o No | Resultado | Sustento |
    Evidencia | Plan de acción

Se usa en dos momentos:
  · INTERMEDIO — antes/durante el chat (estado inicial, para trabajar).
  · FINAL      — al cerrar el chat (con las decisiones y el puntaje exacto).

Determinista y sin API. Reutiliza openpyxl (ya en requirements.txt).
"""
from __future__ import annotations

import io
from typing import Any, Dict, List, Optional

_COLUMNAS = [
    ("ambito",                "Ámbito",          18),
    ("control",               "Control",         26),
    ("actividad",             "Actividad",       46),
    ("__aplica",              "Aplica o No",     11),
    ("resultado",             "Resultado",       15),
    ("evaluacion_sustentada", "Sustento",        50),
    ("fuente_revisada",       "Evidencia",       40),
    ("accion_requerida",      "Plan de acción",  40),
]

# Colores de relleno por Resultado (ARGB, sin '#').
_COLOR = {
    "Cumple":         "C6EFCE",
    "Parcial":        "FFEB9C",
    "No cumple":      "FFC7CE",
    "No evidenciado": "FCE4D6",
    "No aplicable":   "E7E6E6",
    "Pendiente":      "D9E1F2",
}


def _aplica(fila: Dict[str, Any]) -> str:
    return "No" if str(fila.get("resultado", "")) == "No aplicable" else "Sí"


def construir_libro(tabla: List[Dict[str, Any]], meta: Dict[str, Any]):
    """
    Devuelve un `openpyxl.Workbook` con la tabla y una cabecera de contexto.

    meta admite: modelo, tier, fecha, tipo ('intermedio'|'final'),
    score_global (inicial), score_final (opcional), semaforo (label).
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Validación"

    negrita = Font(bold=True)
    cab_fill = PatternFill("solid", fgColor="1F3864")
    cab_font = Font(bold=True, color="FFFFFF")
    wrap = Alignment(wrap_text=True, vertical="top")
    borde = Border(*(Side(style="thin", color="BFBFBF"),) * 4)

    tipo = str(meta.get("tipo", "intermedio")).upper()
    ws["A1"] = f"TABLA DE VALIDACIÓN — {tipo}"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Modelo: {meta.get('modelo','—')}   ·   Tier: {meta.get('tier','—')}" \
               f"   ·   Fecha: {meta.get('fecha','—')}"
    _si = meta.get("score_global")
    _sf = meta.get("score_final")
    linea = f"Puntaje agente: {_si if _si is not None else '—'}"
    if _sf is not None:
        linea += f"   ·   PUNTAJE FINAL (validado): {round(_sf, 2)}"
    if meta.get("semaforo"):
        linea += f"   ·   {meta['semaforo']}"
    ws["A3"] = linea
    ws["A3"].font = negrita

    fila_cab = 5
    for c, (_, titulo, ancho) in enumerate(_COLUMNAS, start=1):
        cel = ws.cell(row=fila_cab, column=c, value=titulo)
        cel.font = cab_font
        cel.fill = cab_fill
        cel.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        ws.column_dimensions[cel.column_letter].width = ancho

    r = fila_cab + 1
    for fila in (tabla or []):
        for c, (clave, _, _) in enumerate(_COLUMNAS, start=1):
            val = _aplica(fila) if clave == "__aplica" else fila.get(clave, "")
            cel = ws.cell(row=r, column=c, value=val)
            cel.alignment = wrap
            cel.border = borde
            if clave == "resultado":
                color = _COLOR.get(str(val))
                if color:
                    cel.fill = PatternFill("solid", fgColor=color)
                cel.font = negrita
        r += 1

    ws.freeze_panes = ws.cell(row=fila_cab + 1, column=1)
    ws.auto_filter.ref = f"A{fila_cab}:H{max(r - 1, fila_cab)}"
    return wb


def a_bytes(tabla: List[Dict[str, Any]], meta: Dict[str, Any]) -> bytes:
    """Serializa el libro a bytes (para servirlo por HTTP)."""
    wb = construir_libro(tabla, meta)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ═════════════════════════════════════════════════════════════════════════════
# ACTA DE CIERRE — libro de 3 hojas al terminar el chat de sustentación
# ═════════════════════════════════════════════════════════════════════════════

_COLOR_VEREDICTO = {"APROBADO": "C6EFCE", "NEGADO": "FFC7CE", "PENDIENTE": "D9E1F2"}


def _norm_act(s: Any) -> str:
    return " ".join(str(s or "").split()).lower()


def acta_cierre_bytes(datos: Dict[str, Any],
                      observaciones: List[Dict[str, Any]],
                      meta: Dict[str, Any]) -> bytes:
    """
    Acta de cierre en .xlsx (3 hojas) generada al finalizar el chat:
      1. Resumen — puntaje inicial→final validado, por ámbito, decisiones y sello.
      2. Validación — la tabla final de 8 columnas + 'Decisión del chat', con las
         filas que cambiaron por el chat resaltadas.
      3. Decisiones — auditoría HITL: una fila por decisión cerrada en el chat.
    Determinista y sin API. Reutiliza `consolidar_decisiones`/`tabla_final`.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from modulos.consolidacion import consolidar_decisiones, tabla_final

    con = consolidar_decisiones(datos, observaciones)
    filas = tabla_final(datos, observaciones)
    dec_por_act = {(_norm_act(d.get("ambito")), _norm_act(d.get("actividad"))):
                   str(d.get("veredicto") or "").upper()
                   for d in con.get("decisiones", [])}

    negrita = Font(bold=True)
    cab_fill = PatternFill("solid", fgColor="1F3864")
    cab_font = Font(bold=True, color="FFFFFF")
    wrap = Alignment(wrap_text=True, vertical="top")
    borde = Border(*(Side(style="thin", color="BFBFBF"),) * 4)
    resalte = PatternFill("solid", fgColor="FFF2CC")   # fila cambiada por el chat

    wb = Workbook()

    # ── Hoja 1 · Resumen ────────────────────────────────────────────────────
    ws = wb.active
    ws.title = "Resumen"
    ws.column_dimensions["A"].width = 30
    for col in "BCD":
        ws.column_dimensions[col].width = 16
    si = datos.get("score_global")
    sf = con.get("score_final_global")
    delta = (round(sf - si, 2) if isinstance(sf, (int, float))
             and isinstance(si, (int, float)) else None)
    rf = con.get("resumen_final") or {}
    cust = datos.get("custodia") or {}
    hash_ = cust.get("hash") or cust.get("hash_sha256") or cust.get("sello") or "—"
    eslabon = cust.get("eslabon") or cust.get("n") or cust.get("indice") or "—"

    ws["A1"] = "ACTA DE CIERRE DE VALIDACIÓN"
    ws["A1"].font = Font(bold=True, size=15)
    ws["A2"] = (f"Modelo: {meta.get('modelo','—')}   ·   Tier: {meta.get('tier','—')}"
                f"   ·   Dominio: {meta.get('dominio','—')}   ·   "
                f"Fecha: {meta.get('fecha','—')}")
    ws["A3"] = (f"Validador: {meta.get('validador','—')}"
                + (f" ({meta['cargo']})" if meta.get("cargo") else ""))
    ws["A4"] = f"Cadena de custodia: eslabón {eslabon} · hash {hash_}"
    ws["A4"].font = Font(size=9, italic=True, color="808080")

    ws["A6"] = "PUNTAJE (escala 1–5)"
    ws["A6"].font = negrita
    ws["A7"] = "Inicial (agente)"
    ws["B7"] = round(si, 2) if isinstance(si, (int, float)) else "—"
    ws["A8"] = "Final (validado)"
    ws["B8"] = round(sf, 2) if isinstance(sf, (int, float)) else "—"
    ws["B8"].font = Font(bold=True, size=13)
    ws["A9"] = "Variación (Δ)"
    ws["B9"] = (f"+{delta}" if isinstance(delta, (int, float)) and delta >= 0
                else delta if delta is not None else "—")
    sem = meta.get("semaforo")
    sem_label = sem.get("label") if isinstance(sem, dict) else sem
    if sem_label:
        ws["A10"] = "Semáforo"; ws["B10"] = str(sem_label)

    ws["A12"] = "PUNTAJE POR ÁMBITO"
    ws["A12"].font = negrita
    enc = ["Ámbito", "Inicial", "Final", "Δ"]
    for c, t in enumerate(enc, start=1):
        cel = ws.cell(row=13, column=c, value=t)
        cel.font = cab_font; cel.fill = cab_fill
        cel.alignment = Alignment(horizontal="center")
    ini_amb = datos.get("scores_por_ambito") or {}
    fin_amb = con.get("scores_final_por_ambito") or {}
    r = 14
    for amb in fin_amb:
        vi = ini_amb.get(amb); vfp = fin_amb.get(amb)
        d = (round(vfp - vi, 2) if isinstance(vfp, (int, float))
             and isinstance(vi, (int, float)) else None)
        ws.cell(row=r, column=1, value=amb).border = borde
        ws.cell(row=r, column=2, value=round(vi, 2) if isinstance(vi, (int, float)) else "—")
        ws.cell(row=r, column=3, value=round(vfp, 2) if isinstance(vfp, (int, float)) else "—")
        ws.cell(row=r, column=4, value=(f"+{d}" if isinstance(d, (int, float)) and d > 0
                                        else d if d is not None else "—"))
        r += 1

    ws.cell(row=r + 1, column=1,
            value=(f"Decisiones del chat: {rf.get('cumple_subsanado',0)} subsanada(s) · "
                   f"{rf.get('no_cumple_confirmado',0)} confirmada(s) · "
                   f"{rf.get('pendiente',0)} pendiente(s)  (de {rf.get('decisiones',0)}).")
            ).font = negrita

    # ── Hoja 2 · Validación (tabla final + Decisión del chat) ────────────────
    wv = wb.create_sheet("Validación")
    cols = list(_COLUMNAS) + [("__decision", "Decisión del chat", 16)]
    for c, (_, titulo, ancho) in enumerate(cols, start=1):
        cel = wv.cell(row=1, column=c, value=titulo)
        cel.font = cab_font; cel.fill = cab_fill
        cel.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
        wv.column_dimensions[cel.column_letter].width = ancho
    rr = 2
    for fila in filas:
        cambiada = bool(fila.get("decidido_en_chat"))
        ver = dec_por_act.get((_norm_act(fila.get("ambito")),
                               _norm_act(fila.get("actividad"))), "")
        for c, (clave, _, _) in enumerate(cols, start=1):
            if clave == "__aplica":
                val = _aplica(fila)
            elif clave == "__decision":
                val = ver or "—"
            else:
                val = fila.get(clave, "")
            cel = wv.cell(row=rr, column=c, value=val)
            cel.alignment = wrap; cel.border = borde
            if cambiada:
                cel.fill = resalte
            if clave == "resultado":
                color = _COLOR.get(str(val))
                if color:
                    cel.fill = PatternFill("solid", fgColor=color)
                cel.font = negrita
            if clave == "__decision" and ver:
                color = _COLOR_VEREDICTO.get(ver)
                if color:
                    cel.fill = PatternFill("solid", fgColor=color)
                cel.font = negrita
        rr += 1
    wv.freeze_panes = wv.cell(row=2, column=1)
    wv.auto_filter.ref = f"A1:I{max(rr - 1, 1)}"

    # ── Hoja 3 · Decisiones (auditoría HITL) ────────────────────────────────
    wd = wb.create_sheet("Decisiones")
    for c, (t, ancho) in enumerate(
            [("Ámbito", 20), ("Actividad", 48), ("Veredicto", 14),
             ("Hallazgo / Sustento del validador", 70)], start=1):
        cel = wd.cell(row=1, column=c, value=t)
        cel.font = cab_font; cel.fill = cab_fill
        cel.alignment = Alignment(horizontal="center")
        wd.column_dimensions[cel.column_letter].width = ancho
    rr = 2
    for d in con.get("decisiones", []):
        ver = str(d.get("veredicto") or "").upper()
        wd.cell(row=rr, column=1, value=d.get("ambito", "")).border = borde
        wd.cell(row=rr, column=2, value=d.get("actividad", "")).alignment = wrap
        cv = wd.cell(row=rr, column=3, value=ver)
        cv.font = negrita
        color = _COLOR_VEREDICTO.get(ver)
        if color:
            cv.fill = PatternFill("solid", fgColor=color)
        cel = wd.cell(row=rr, column=4, value=d.get("hallazgo", ""))
        cel.alignment = wrap
        rr += 1
    if rr == 2:
        wd.cell(row=2, column=1, value="(sin decisiones cerradas en el chat)")

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
