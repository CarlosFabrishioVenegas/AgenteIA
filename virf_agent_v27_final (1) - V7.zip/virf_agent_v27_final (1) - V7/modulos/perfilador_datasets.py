"""
modulos/perfilador_datasets.py
═══════════════════════════════════════════════════════════════════════════════
PERFILADO DE DATASETS — el esquema como evidencia, no los datos.

QUÉ RESUELVE
────────────
`inputs/**/datasets/` está excluido de la evidencia documental a propósito
(`Mx_01.CARPETAS_NO_EVIDENCIA`), y por una razón medida: un solo `.csv` se
comía los 15.000 chars de `MAX_CHARS_DOC` y expulsaba del contexto al manual
metodológico. Volcar datos crudos al prompt no es leer evidencia, es
desplazarla.

Pero de ahí no se sigue que el dataset no importe. Lo que un validador necesita
contrastar contra el manual no son las filas: es el ESQUEMA.

    «El manual dice que el modelo consume 17 variables, entre ellas
     `plazo_residual`. ¿Existe esa columna? ¿De qué tipo? ¿Cuántos nulos
     tiene? ¿El rango de fechas cubre la ventana de estimación declarada?»

Eso cabe en unos cientos de caracteres por dataset y es exactamente lo que
permite detectar las tres incoherencias que un modelo mal documentado esconde:

  1. Columnas que el código consume y el manual no declara.
  2. Variables que el manual promete y el dataset no tiene.
  3. Supuestos de calidad que el perfil desmiente (el manual dice «sin
     valores faltantes» y la columna tiene 12% de nulos).

QUÉ NO HACE
───────────
No ejecuta pruebas de calidad ni emite dictamen: eso es el motor de datos
(`modulos/motores_datos.py`, 8 pruebas con umbral y tasa de error). El
perfilador solo DESCRIBE, para que el LLM pueda contrastar contra la
documentación. Son capas distintas y deliberadamente separadas: una calcula,
la otra da contexto.

No vuelca ninguna fila. Los valores concretos que sí aparecen son mínimos,
máximos y las categorías de columnas de baja cardinalidad — metadatos de
esquema, no registros. Ver `PerfilDataset.a_texto()`.

CÓMO SE USA
───────────
    from modulos.perfilador_datasets import perfilar_carpeta, perfilar_datasets

    # Desde una carpeta (carga y perfila)
    texto = perfilar_carpeta("inputs/calidad_datos/datasets")

    # Con DataFrames ya cargados (no vuelve a leer disco)
    texto = perfilar_datasets(datasets_dict)

El texto resultante se inyecta como un documento sintético de evidencia, así
que viaja por el mismo camino que el resto: chunking, presupuesto de contexto y
huella de trazabilidad.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("virf.perfilador")

__all__ = [
    "PerfilColumna", "PerfilDataset",
    "perfilar_dataframe", "perfilar_datasets", "perfilar_carpeta",
    "NOMBRE_DOCUMENTO_PERFIL",
]

# Nombre del documento sintético que se inyecta en la evidencia. Se declara aquí
# para que los tests y el pipeline lo referencien por constante y no por literal
# repetido: un cambio de nombre en dos sitios es un desajuste esperando ocurrir.
NOMBRE_DOCUMENTO_PERFIL = "PERFIL_DATASETS.md"

# Cardinalidad por debajo de la cual se listan las categorías. Por encima, solo
# se declara cuántas hay. El corte existe porque una columna con 40.000 valores
# distintos (un id de cliente) no aporta nada listada y sí destruye el contexto.
_MAX_CATEGORIAS_LISTADAS = 12

# Tope de caracteres del bloque completo. Es una red de seguridad, no el
# mecanismo principal: el perfil de 20 datasets ronda los 8.000 chars. Si se
# excede, se corta declarándolo — nunca en silencio.
_MAX_CHARS_PERFIL = 30_000


@dataclass
class PerfilColumna:
    """Descripción de una columna. Sin datos, solo esquema y estadística."""
    nombre: str
    dtype: str
    n_nulos: int
    pct_nulos: float
    n_unicos: int
    es_constante: bool = False
    todo_nulo: bool = False
    minimo: Optional[str] = None
    maximo: Optional[str] = None
    categorias: List[str] = field(default_factory=list)

    def a_linea(self) -> str:
        partes = [f"  · {self.nombre} ({self.dtype})"]
        partes.append(f"nulos {self.pct_nulos:.1f}%")
        partes.append(f"únicos {self.n_unicos:,}")
        if self.minimo is not None or self.maximo is not None:
            partes.append(f"rango [{self.minimo} … {self.maximo}]")
        if self.categorias:
            partes.append("valores: " + ", ".join(self.categorias))
        linea = " | ".join(partes)
        # Los avisos van al final y en texto explícito: son lo que el modelo
        # debe contrastar contra el manual, no adornos.
        if self.todo_nulo:
            linea += "\n      ⚠️ COLUMNA ÍNTEGRAMENTE NULA"
        elif self.es_constante:
            linea += "\n      ⚠️ COLUMNA CONSTANTE (un único valor en todas las filas)"
        return linea


@dataclass
class PerfilDataset:
    """Descripción de un dataset completo."""
    nombre: str
    n_filas: int
    n_columnas: int
    columnas: List[PerfilColumna] = field(default_factory=list)
    n_filas_duplicadas: int = 0
    error: Optional[str] = None

    def a_texto(self) -> str:
        if self.error:
            return f"### {self.nombre}\n\n⚠️ No se pudo perfilar: {self.error}\n"

        cab = (f"### {self.nombre}\n\n"
               f"{self.n_filas:,} filas × {self.n_columnas} columnas")
        if self.n_filas_duplicadas:
            pct = (self.n_filas_duplicadas / self.n_filas * 100) if self.n_filas else 0.0
            cab += (f"\n\n⚠️ {self.n_filas_duplicadas:,} fila(s) duplicada(s) "
                    f"({pct:.1f}%) — contrastar contra la política de unicidad "
                    f"declarada en el manual.")
        cuerpo = "\n".join(c.a_linea() for c in self.columnas)
        return f"{cab}\n\nColumnas:\n{cuerpo}\n"


def _describir_rango(serie) -> tuple:
    """
    Mínimo y máximo como texto, o (None, None) si la columna no los admite.

    Se envuelve en try/except porque una columna `object` con tipos mezclados
    —lo normal en un CSV real— hace estallar `.min()` con TypeError. Un dataset
    sucio no puede tumbar el perfilado: precisamente en ese caso es cuando más
    falta hace verlo.
    """
    import pandas as pd

    try:
        if pd.api.types.is_numeric_dtype(serie) or \
           pd.api.types.is_datetime64_any_dtype(serie):
            lo, hi = serie.min(), serie.max()
            if pd.isna(lo) or pd.isna(hi):
                return None, None
            if pd.api.types.is_datetime64_any_dtype(serie):
                return str(lo)[:19], str(hi)[:19]
            return f"{lo:,.4g}", f"{hi:,.4g}"
    except (TypeError, ValueError) as exc:
        logger.debug("rango no calculable en '%s': %s", serie.name, exc)
    return None, None


def _intentar_fechas(serie) -> Optional[tuple]:
    """
    Si una columna `object` contiene fechas, devuelve su rango.

    Por qué se intenta: en un CSV las fechas llegan como texto, y el rango
    temporal es justo lo que hay que contrastar contra la ventana de estimación
    del manual. Sin esto, la columna más relevante del dataset se describiría
    como 'object' y nada más.
    """
    import pandas as pd

    muestra = serie.dropna().astype(str).head(200)
    if muestra.empty:
        return None
    try:
        conv = pd.to_datetime(muestra, errors="coerce", format="mixed")
    except (ValueError, TypeError):
        return None
    # Se exige que la mayoría parseé: con 3 fechas sueltas entre 200 códigos de
    # producto, interpretar la columna como temporal sería inventar.
    if conv.notna().mean() < 0.8:
        return None
    try:
        completo = pd.to_datetime(serie, errors="coerce", format="mixed")
        lo, hi = completo.min(), completo.max()
        if pd.isna(lo) or pd.isna(hi):
            return None
        return str(lo)[:19], str(hi)[:19]
    except (ValueError, TypeError):
        return None


def perfilar_dataframe(nombre: str, df) -> PerfilDataset:
    """Perfila un DataFrame ya cargado. No lee disco, no llama al LLM."""
    import pandas as pd

    try:
        n_filas = int(len(df))
        perfil = PerfilDataset(
            nombre=nombre,
            n_filas=n_filas,
            n_columnas=int(df.shape[1]),
        )
        try:
            perfil.n_filas_duplicadas = int(df.duplicated().sum())
        except (TypeError, ValueError):
            # Columnas no hasheables (listas, dicts): duplicated() falla.
            perfil.n_filas_duplicadas = 0

        for col in df.columns:
            serie = df[col]
            n_nulos = int(serie.isna().sum())
            pct = (n_nulos / n_filas * 100) if n_filas else 0.0
            try:
                n_unicos = int(serie.nunique(dropna=True))
            except (TypeError, ValueError):
                n_unicos = -1

            pc = PerfilColumna(
                nombre=str(col),
                dtype=str(serie.dtype),
                n_nulos=n_nulos,
                pct_nulos=round(pct, 2),
                n_unicos=n_unicos,
                todo_nulo=(n_nulos == n_filas and n_filas > 0),
                es_constante=(n_unicos == 1 and n_filas > 1),
            )

            pc.minimo, pc.maximo = _describir_rango(serie)
            if pc.minimo is None and serie.dtype == object:
                rango_fecha = _intentar_fechas(serie)
                if rango_fecha:
                    pc.minimo, pc.maximo = rango_fecha
                    pc.dtype = "object (fechas detectadas)"

            # Categorías solo si son pocas: es metadato de esquema, no muestra
            # de datos. Con 40.000 ids distintos no se lista ninguno.
            if 0 < n_unicos <= _MAX_CATEGORIAS_LISTADAS and \
               not pd.api.types.is_numeric_dtype(serie):
                try:
                    pc.categorias = [str(v)[:40] for v in
                                     serie.dropna().unique()[:_MAX_CATEGORIAS_LISTADAS]]
                except (TypeError, ValueError):
                    pc.categorias = []

            perfil.columnas.append(pc)
        return perfil
    except Exception as exc:                       # noqa: BLE001
        # Un dataset ilegible se DECLARA como tal. Devolver un perfil vacío sin
        # decirlo dejaría al modelo creyendo que el dataset no tiene columnas.
        logger.warning("No se pudo perfilar '%s': %s", nombre, exc)
        return PerfilDataset(nombre=nombre, n_filas=0, n_columnas=0,
                             error=f"{type(exc).__name__}: {exc}")


def perfilar_datasets(datasets: Dict[str, Any]) -> str:
    """
    Perfila un dict {nombre: DataFrame} y devuelve el bloque Markdown.

    Recibe los DataFrames ya cargados —inyección de dependencia, igual que
    `ChunkerService` recibe el cliente IA— para que el pipeline por control, que
    ya los tiene en memoria, no vuelva a leer disco.
    """
    if not datasets:
        return ""

    perfiles = [perfilar_dataframe(n, df) for n, df in sorted(datasets.items())]

    cabecera = (
        "# Perfil de los datasets del modelo\n\n"
        "Documento generado automáticamente por `modulos/perfilador_datasets.py`.\n"
        "Describe el ESQUEMA de cada dataset, no su contenido: no incluye "
        "ninguna fila de datos.\n\n"
        "**Para qué sirve en la validación.** Contrastar contra la "
        "documentación: ¿las variables que el manual declara existen con ese "
        "nombre y tipo? ¿el rango de fechas cubre la ventana de estimación "
        "documentada? ¿los supuestos de calidad (ausencia de nulos, unicidad) "
        "se sostienen en el perfil real?\n\n"
        f"Datasets perfilados: {len(perfiles)}\n\n"
        "---\n"
    )
    texto = cabecera + "\n".join(p.a_texto() for p in perfiles)

    if len(texto) > _MAX_CHARS_PERFIL:
        texto = (texto[:_MAX_CHARS_PERFIL]
                 + f"\n\n⚠️ [Perfil recortado a {_MAX_CHARS_PERFIL:,} chars. "
                   f"Hay más datasets sin describir.]\n")
    return texto


def perfilar_carpeta(carpeta) -> str:
    """
    Carga los datasets de una carpeta y devuelve su perfil.

    Reutiliza `motores_datos.cargar_datasets()`, que es la ÚNICA vía de carga de
    datasets del proyecto. Una segunda implementación aquí divergiría en qué
    extensiones acepta y en cómo trata los ficheros temporales de Excel (`~$`).
    """
    carpeta = Path(carpeta)
    if not carpeta.is_dir():
        return ""
    from modulos.motores_datos import cargar_datasets
    return perfilar_datasets(cargar_datasets(carpeta))


def documento_perfil(carpeta) -> Optional[Dict[str, Any]]:
    """
    Devuelve el perfil envuelto como documento de evidencia, o None si no hay
    datasets.

    El dict imita el contrato de `Mx_01.leer_archivo()` para que el perfil viaje
    por el mismo camino que cualquier otro documento: chunking, presupuesto de
    contexto y cobertura. `ruta`/`sha256_archivo` van a None a propósito — es un
    documento derivado, no un fichero en disco, y la cadena de custodia no debe
    afirmar que puede re-hashearlo.
    """
    texto = perfilar_carpeta(carpeta)
    if not texto:
        return None
    return {
        "nombre":          NOMBRE_DOCUMENTO_PERFIL,
        "tipo":            "PERFIL",
        "contenido":       texto,
        "chars_totales":   len(texto),
        "truncado":        False,
        "cobertura_pct":   100.0,
        "lectura_fallida": False,
        "fue_resumido":    False,
        "n_chunks":        1,
        "fue_truncado_fc": False,
        "ruta":            None,
        "sha256_archivo":  None,
        "es_derivado":     True,
    }
