"""
Reglas puras de calificación de los informes VIRF: conclusión global y estado
por control. Las usan los TRES informes Word (Solo Informe, «Generar informe»
de la web y el entregable del pipeline), para que una misma situación reciba
siempre la misma calificación.

Sin E/S, sin IA, sin dependencias de FastAPI: todo lo que decide el veredicto
del informe vive aquí para que se pueda testear con listas de diccionarios.

Regla de negocio tal como la dictó el usuario
─────────────────────────────────────────────
  · Deficiente   → más de 2 críticas.
  · Regular      → hasta 2 críticas y más de una moderada
                   (más de 3 si 1 es de Documentación y 1 de Gobierno).
  · Aceptable    → 1 moderada (o menos de 3 si 1 es de Documentación y 1 de
                   Gobierno), o menos de 5 bajas/potenciales.
  · Satisfactorio→ como máximo 4 bajas/potenciales.

La regla es ambigua y se solapa. Cómo se resolvió cada caso (A1…A6) está en
`concluir()` y se devuelve en `supuestos` para que quede a la vista. Lo que no
se pudo decidir con seguridad se marca como «PENDIENTE DE CONFIRMAR» y se
consultó al usuario.
"""
from __future__ import annotations

import unicodedata
from typing import Any, Iterable

# ── Catálogos ─────────────────────────────────────────────────────────

# Ámbitos del formulario (orden de presentación). La clave canónica sirve para
# casar el desplegable con el texto del estándar, que no siempre coincide
# («Usos» ↔ «Uso e integración a la gestión», «Calidad de Datos» ↔ «Calidad de datos»).
AMBITOS = ("Documentación", "Calidad de Datos", "Metodología",
           "Implementación", "Gobierno", "Usos")

_CLAVES_AMBITO = (
    ("documentacion", "documentacion"),
    ("calidad", "calidad"),
    ("metodolog", "metodologia"),
    ("implementac", "implementacion"),
    ("gobierno", "gobierno"),
    ("uso", "usos"),
)

# Riesgos de menor a mayor gravedad. «Potencial» se trata como el nivel más leve
# de riesgo porque la regla lo agrupa con «bajas» («bajas/potenciales»).
RIESGOS = ("Oportunidad de Mejora", "Potencial", "Bajo", "Moderado", "Crítico")
_GRAVEDAD = {r: i for i, r in enumerate(RIESGOS)}

NIVELES = ("Satisfactorio", "Aceptable", "Regular", "Deficiente")

# [A6 · confirmado por el usuario] Una Oportunidad de Mejora no es un
# incumplimiento: no deja el control como «no cumplido», su conclusión no va en
# rojo y no lleva responsable ni fecha límite (ver `es_om`).
OM_INCUMPLE = False


def _sin_tildes(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s or "")
                   if not unicodedata.combining(c)).lower().strip()


def clave_ambito(texto: str) -> str:
    """Clave canónica de un ámbito (desplegable o estándar). '' si no casa."""
    t = _sin_tildes(texto)
    for patron, clave in _CLAVES_AMBITO:
        if t.startswith(patron) or f" {patron}" in f" {t}":
            return clave
    return t


def normalizar_riesgo(texto: Any) -> str:
    """Devuelve el riesgo del catálogo que corresponde a `texto` (tolerante a tildes)."""
    t = _sin_tildes(str(texto or ""))
    for r in RIESGOS:
        if _sin_tildes(r) == t:
            return r
    if t.startswith("oportunidad"):
        return "Oportunidad de Mejora"
    raise ValueError(f"riesgo desconocido: {texto!r}. Válidos: {list(RIESGOS)}")


# ── Estado por control ───────────────────────────────────────────────

def riesgo_maximo(observaciones: Iterable[dict]) -> str | None:
    """Riesgo más grave entre las observaciones de un control. None si no hay."""
    riesgos = [normalizar_riesgo(o.get("riesgo")) for o in observaciones]
    if not riesgos:
        return None
    return max(riesgos, key=lambda r: _GRAVEDAD[r])


def es_om(observacion: dict) -> bool:
    return normalizar_riesgo(observacion.get("riesgo")) == "Oportunidad de Mejora"


def control_cumple(observaciones: Iterable[dict]) -> bool:
    obs = list(observaciones)
    if not obs:
        return True
    if not OM_INCUMPLE and all(
            normalizar_riesgo(o.get("riesgo")) == "Oportunidad de Mejora" for o in obs):
        return True
    return False


_FRASE_RIESGO = {
    "Oportunidad de Mejora": "adecuado, con oportunidades de mejora",
    "Potencial":             "con riesgo potencial",
    "Bajo":                  "con riesgo bajo",
    "Moderado":              "con riesgo moderado",
    "Crítico":               "con riesgo crítico",
}


def conclusion_control(observaciones: Iterable[dict]) -> str:
    """Frase de conclusión del barrido de controles."""
    r = riesgo_maximo(observaciones)
    estado = "adecuado" if r is None else _FRASE_RIESGO[r]
    return ("A partir de la revisión realizada sobre este control, este ha "
            f"resultado {estado}.")


# ── Conclusión global ────────────────────────────────────────────────

def _contar(observaciones: list[dict]) -> dict[str, Any]:
    c = {"criticas": 0, "moderadas": 0, "bajas_potenciales": 0, "om": 0,
         "moderadas_por_ambito": {}}
    for o in observaciones:
        r = normalizar_riesgo(o.get("riesgo"))
        if r == "Crítico":
            c["criticas"] += 1
        elif r == "Moderado":
            c["moderadas"] += 1
            k = clave_ambito(o.get("ambito", ""))
            c["moderadas_por_ambito"][k] = c["moderadas_por_ambito"].get(k, 0) + 1
        elif r in ("Bajo", "Potencial"):
            c["bajas_potenciales"] += 1
        else:
            c["om"] += 1
    return c


def concluir(observaciones: Iterable[dict]) -> dict[str, Any]:
    """
    Conclusión global del informe a partir de las observaciones registradas.

    Devuelve {nivel, motivo, conteos, supuestos}. Orden de evaluación: de lo más
    grave a lo menos grave; la primera regla que dispara gana. Eso resuelve los
    solapamientos («Aceptable: menos de 5 bajas» vs «Satisfactorio: como máximo
    4 bajas» describen el mismo conjunto) a favor del nivel MÁS GRAVE aplicable,
    salvo donde se indica lo contrario.
    """
    obs = list(observaciones)
    c = _contar(obs)
    C, M, B = c["criticas"], c["moderadas"], c["bajas_potenciales"]
    por_amb = c["moderadas_por_ambito"]
    # «1 es de Documentación y 1 de Gobierno»: entre las moderadas hay al menos
    # una de cada uno de esos dos ámbitos.
    excepcion_doc_gob = por_amb.get("documentacion", 0) >= 1 and por_amb.get("gobierno", 0) >= 1

    supuestos = [
        "A1: 1 o 2 críticas bastan para «Regular» aunque no haya moderadas; "
        "«Aceptable» nunca lleva críticas (confirmado por el usuario).",
        "A2: con la excepción Documentación+Gobierno, 3 moderadas caen en el hueco "
        "entre «más de 3» (Regular) y «menos de 3» (Aceptable); se resuelve como "
        "Regular por prudencia.",
        "A3: «Aceptable por menos de 5 bajas» y «Satisfactorio por máximo 4 bajas» "
        "son el mismo conjunto; se interpreta que hasta 4 bajas/potenciales sin "
        "moderadas es Satisfactorio y 5 o más es Aceptable.",
        "A4: «Potencial» cuenta junto a «Bajo» (la regla dice «bajas/potenciales»).",
        "A5: las Oportunidades de Mejora no cuentan para la conclusión global.",
    ]

    if C > 2:
        nivel, motivo = "Deficiente", f"{C} observaciones críticas (más de 2)."
    elif C >= 1:
        nivel, motivo = "Regular", f"{C} observación(es) crítica(s) (hasta 2)."
    elif excepcion_doc_gob and M >= 3:
        nivel = "Regular"
        motivo = (f"{M} moderadas, con al menos una de Documentación y una de "
                  "Gobierno (umbral ampliado: 3 o más).")
    elif not excepcion_doc_gob and M > 1:
        nivel, motivo = "Regular", f"{M} observaciones moderadas (más de una)."
    elif M >= 1:
        nivel = "Aceptable"
        motivo = (f"{M} moderada(s) con una de Documentación y una de Gobierno "
                  "(menos de 3)." if excepcion_doc_gob else "1 observación moderada.")
    elif B >= 5:
        nivel, motivo = "Aceptable", f"{B} observaciones bajas/potenciales (5 o más)."
    else:
        nivel = "Satisfactorio"
        motivo = (f"{B} observación(es) baja(s)/potencial(es) (como máximo 4)."
                  if B else "Sin observaciones de riesgo.")

    return {
        "nivel":     nivel,
        "motivo":    motivo,
        "conteos":   {k: v for k, v in c.items() if k != "moderadas_por_ambito"},
        "supuestos": supuestos,
    }


# ── Puntaje del agente → riesgo ──────────────────────────────────────
#
# Los informes del pipeline y de la web parten de un puntaje 1–5 por actividad
# (0 = sin evidencia). Para calificarlos con la MISMA regla que Solo Informe se
# traduce a riesgo así:
#   · 0–2 → Crítico   (§6 del procedimiento: score ≤ 2 es hallazgo crítico
#                      automático; 0 = ausencia de evidencia, falta crítica)
#   · 3   → Moderado  («brechas importantes»)
#   · 4   → Oportunidad de Mejora («cumplimiento sustancial con mejoras»)
#   · 5   → sin observación
#   · None (no evaluada por fallo técnico) → sin riesgo: no es un incumplimiento
#     y se declara aparte para que se re-ejecute.

def riesgo_desde_puntaje(puntaje: Any, sin_evidencia: bool = False) -> str | None:
    if sin_evidencia:
        return "Crítico"
    if puntaje is None:
        return None
    try:
        p = float(puntaje)
    except (TypeError, ValueError):
        return None
    if p <= 2:
        return "Crítico"
    if p < 4:
        return "Moderado"
    if p < 5:
        return "Oportunidad de Mejora"
    return None


def texto_conclusion(nivel: str, nombre_modelo: str) -> str:
    """Párrafo de conclusión para la sección IV."""
    return (f"Como resultado de la validación, la gestión del modelo {nombre_modelo} "
            f"se califica como «{nivel}».")
