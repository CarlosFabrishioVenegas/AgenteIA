"""
modulos/esquemas.py
═════════════════════════════════════════════════════════════════════════════
Contrato de salida TIPADO del validador (WP-09 · GAP-43/GAP-14/GAP-03).

POR QUÉ
───────
Hoy la salida viaja como `dict` (`ResultadoSkill(dict)`, `base.py:62`) y el JSON
sellado se arma a mano. Un dict no valida nada: un `status` inventado o una cita
ausente pasan sin protesta y llegan al informe. La guía de skills exige un
contrato Pydantic estricto con exactamente estos campos
(`guia-integracion-skills-agente (1).md:176-189`):

    ValidationClaim(requirement_id, status ∈ {IMPLEMENTADO, PARCIAL, OMITIDO,
                    DESVIADO}, evidence_text[página], code_evidence[línea],
                    justification)
    ValidationReport(model_id, overall_confidence, findings[], abstained,
                     unresolved_conflicts)

QUÉ HACE
────────
Define esos dos modelos y un ADAPTADOR `dict -> ValidationReport` que valida en
el BORDE del reporte, sin tocar la interfaz interna `ResultadoSkill(dict)`
(compatibilidad hacia atrás). Un dict correcto produce un `ValidationReport`
válido; uno malformado (status fuera del enum, cita ausente, confianza fuera de
[0,1]) LEVANTA `ValidationError`.

Determinista y sin API. Pydantic v2 ya es dependencia del proyecto (FastAPI);
no se añade ninguna.
"""
from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    ValidationError,
    field_validator,
    model_validator,
)

__all__ = [
    "EstadoRequisito",
    "ValidationClaim",
    "ValidationReport",
    "desde_dict",
    "validar_reporte",
    "intentar_validar",
    "ValidationError",
]


class EstadoRequisito(str, Enum):
    """Clasificación tri-state extendida de cada requisito (guía §7 checklist)."""

    IMPLEMENTADO = "IMPLEMENTADO"
    PARCIAL = "PARCIAL"
    OMITIDO = "OMITIDO"
    DESVIADO = "DESVIADO"


class ValidationClaim(BaseModel):
    """
    Un hallazgo atómico de validación: un requisito documental contrastado
    contra el código. Cada afirmación fáctica de cumplimiento, discrepancia u
    omisión DEBE citar su evidencia (guía: cero conocimiento paramétrico).
    """

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    requirement_id: str = Field(min_length=1,
                                description="ID del requisito documental validado.")
    ambito: Optional[str] = Field(
        default=None,
        description="Ámbito de validación al que pertenece el hallazgo "
                    "(VaR/ALM/LaR…). Opcional: agrupa los "
                    "veredictos por ámbito en el informe.")
    status: EstadoRequisito = Field(
        description="IMPLEMENTADO | PARCIAL | OMITIDO | DESVIADO.")
    evidence_text: str = Field(
        description="Cita exacta del documento que sustenta el requisito "
                    "(con página). Vacía solo se admite para OMITIDO.")
    code_evidence: str = Field(
        default="",
        description="Línea y fragmento de código donde se implementa "
                    "(vacío legítimo si el requisito está OMITIDO).")
    justification: str = Field(min_length=1,
                               description="Explicación técnica del match o desvío.")

    @field_validator("requirement_id", "justification")
    @classmethod
    def _no_en_blanco(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("no puede estar en blanco")
        return v

    @model_validator(mode="after")
    def _coherencia_evidencia(self) -> "ValidationClaim":
        """
        Reglas de la guía sobre la evidencia:
          · Un veredicto de cumplimiento o desvío NO puede carecer de cita del
            documento (antipatrón "juicio sin evidencia explícita").
          · Un DESVIADO/PARCIAL debe mostrar ambos lados (documento y código):
            afirmar un desvío exige señalar la línea que se desvía.
          · OMITIDO es la única excepción a la cita de código: el requisito no
            está en el código, precisamente.
        """
        estado = self.status if isinstance(self.status, str) else self.status.value
        if estado != EstadoRequisito.OMITIDO.value:
            if not self.evidence_text or not self.evidence_text.strip():
                raise ValueError(
                    f"status={estado} exige evidence_text (cita del documento)")
        if estado in (EstadoRequisito.DESVIADO.value, EstadoRequisito.PARCIAL.value):
            if not self.code_evidence or not self.code_evidence.strip():
                raise ValueError(
                    f"status={estado} exige code_evidence (línea de código)")
        return self


class ValidationReport(BaseModel):
    """
    Reporte de validación completo. Es el objeto que el borde del pipeline
    valida antes de emitir el `.docx`/JSON: si no valida, no se emite.
    """

    model_config = ConfigDict(extra="forbid")

    model_id: str = Field(min_length=1)
    overall_confidence: float = Field(
        ge=0.0, le=1.0,
        description="Confianza agregada derivada de la groundedness (0.0–1.0).")
    findings: List[ValidationClaim] = Field(default_factory=list)
    abstained: bool = Field(
        default=False,
        description="True si la evidencia fue insuficiente para concluir.")
    unresolved_conflicts: List[str] = Field(
        default_factory=list,
        description="Conflictos entre fuentes que quedaron sin resolver.")

    @field_validator("model_id")
    @classmethod
    def _model_id_no_en_blanco(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("model_id no puede estar en blanco")
        return v


# ── Adaptador dict → Pydantic (borde del reporte) ────────────────────────────

def desde_dict(datos: Dict[str, Any]) -> ValidationReport:
    """
    Construye un `ValidationReport` a partir del dict sellado del pipeline.

    Acepta tanto la forma nativa (`findings`) como sinónimos tolerados del
    código existente (`hallazgos`) para no obligar a renombrar aguas arriba.
    Levanta `ValidationError` si el contenido no cumple el contrato.
    """
    if not isinstance(datos, dict):
        raise TypeError("desde_dict espera un dict")
    d = dict(datos)  # copia superficial; no mutar la entrada
    if "findings" not in d and "hallazgos" in d:
        d["findings"] = d.pop("hallazgos")
    return ValidationReport.model_validate(d)


def validar_reporte(datos: Dict[str, Any]) -> ValidationReport:
    """Alias explícito: valida y devuelve, o levanta `ValidationError`."""
    return desde_dict(datos)


def intentar_validar(datos: Dict[str, Any]):
    """
    Modo *warn-first* (plan WP-09): devuelve `(reporte|None, errores:list[str])`
    sin levantar. Útil para registrar la desviación sin tumbar la corrida
    mientras el contrato se estabiliza.
    """
    try:
        return desde_dict(datos), []
    except (ValidationError, TypeError) as exc:
        return None, [str(exc)]
