"""
modulos/generador_markdown.py
═════════════════════════════════════════════════════════════════════════════
Informe de validación en Markdown: el BORRADOR DE TRABAJO del validador.

POR QUÉ EXISTE, SI YA HAY UN WORD
─────────────────────────────────
Son dos documentos con dos destinatarios y dos momentos:

  · El **Word** es el ENTREGABLE. Va al comité, al supervisor, al expediente.
    Está maquetado, es conciso y no muestra la cocina.

  · Este **Markdown** es el BORRADOR. Lo lee el validador humano mientras
    redacta y decide. Por eso incluye lo que el Word omite: el razonamiento
    completo, las citas enfrentadas, los avisos de verificación, las preguntas
    al modelador y —sobre todo— **lo que el agente NO pudo evaluar**.

El agente no firma nada: produce un dictamen fundamentado que una persona
revisa, corrige y hace suyo. Este fichero existe para que esa revisión sea
posible sin abrir el JSON.

QUÉ LO HACE ÚTIL PARA REDACTAR
──────────────────────────────
  1. Es texto plano: se copia y pega directamente al informe final.
  2. Está ordenado por SEVERIDAD, no por número de control: lo que hay que
     mirar primero está arriba.
  3. Separa el hallazgo (lo que el agente vio) de la conclusión (lo que el
     validador decide). Los bloques `> ✍️` marcan dónde te toca escribir a ti.
  4. Declara sus propias limitaciones. Un informe que no dice qué se quedó
     fuera no es defendible ante un supervisor.

Uso:
    from modulos.generador_markdown import generar_informe_md
    generar_informe_md(datos_json, ruta_salida)
"""

from __future__ import annotations

import datetime as _dt
from pathlib import Path
from typing import Any, Dict, List, Optional

__all__ = ["generar_informe_md"]


# ── Escalas ──────────────────────────────────────────────────────────────────
_LABEL = {
    1: "No cumple",
    2: "Cumple parcialmente — observaciones críticas",
    3: "Cumple parcialmente",
    4: "Cumple con observaciones menores",
    5: "Cumple plenamente",
}
_SEMAFORO = {1: "🔴", 2: "🟠", 3: "🟡", 4: "🟢", 5: "🟢"}
_ORDEN_SEV = {"alta": 0, "media": 1, "baja": 2}


def _pj(ev: Dict) -> Optional[int]:
    """
    Puntaje 1-5, `0` si no se aportó evidencia, `None` si NO se pudo evaluar.

    [AUDIT-FIX 2026-08-07] Antes devolvía **1** ante `puntaje=None`, que es
    exactamente lo que produce un FALLO TÉCNICO (timeout, JSON roto, cuota de
    API agotada). El borrador mostraba entonces:

        #### 🔴 [1/5] Backtesting de Kupiec      ← avería NUESTRA
        #### 🔴 [1/5] Documentación del modelo   ← incumplimiento del validado

    indistinguibles. Es el invariante §3.3 invertido: se acusaba al validado
    del peor incumplimiento posible por una avería del agente. Y la petición
    «re-ejecutar y verificar la cuota de la API» se le enviaba a él en la lista
    de información a solicitar.

    `generador_word._normalizar_score` ya corregía esto desde hace tiempo; la
    corrección nunca se migró aquí, y el `.md` es lo que el validador lee
    mientras decide.
    """
    if ev.get("evaluacion_valida") is False or ev.get("puntaje") is None:
        return None
    if ev.get("sin_evidencia"):
        return 0
    try:
        return max(1, min(5, int(float(ev.get("puntaje", 1)))))
    except (TypeError, ValueError):
        return None


#: Orden de gravedad para listar. `None` (fallo técnico) va al final: no es un
#: hallazgo del validado, así que no debe encabezar la lista de lo más grave.
def _orden_pj(ev: Dict) -> tuple:
    p = _pj(ev)
    return (1, 0) if p is None else (0, p)


def _etiqueta_pj(p: Optional[int]) -> str:
    """Cómo se rotula el puntaje en el encabezado de una actividad."""
    if p is None:
        return "NO EVALUADA — fallo técnico"
    if p == 0:
        return "0/5 — SIN EVIDENCIA"
    return f"{p}/5"


def _txt(v: Any) -> str:
    return str(v).strip() if v is not None else ""


def _firma_agente(d: Dict) -> str:
    """
    Versión y motor, legibles.

    `datos["agente"]` NO es una cadena: es el bloque de metadatos completo
    —versión, modelo IA, pesos de ámbito, huellas—. Interpolarlo tal cual
    volcaba el dict entero en la cabecera del informe.
    """
    a = d.get("agente")
    if isinstance(a, dict):
        partes = [str(a.get("agente_version", "")).strip()]
        if a.get("modelo_ia"):
            partes.append(f"· {a['modelo_ia']}")
        return " ".join(p for p in partes if p) or "—"
    return _txt(a) or "—"


def _semaforo_txt(d: Dict) -> str:
    """
    Etiqueta del semáforo. También llega como dict `{label, color}`, no como
    cadena — mismo caso que `agente`.
    """
    s = d.get("semaforo")
    if isinstance(s, dict):
        return _txt(s.get("label")) or "—"
    return _txt(s) or "—"


def _bloque_citas(evidencia: str) -> str:
    """
    Reindenta la evidencia como cita de Markdown.

    Se preservan los bloques ``` ``` que trae el modelo al transcribir código:
    son justamente lo que hace verificable el hallazgo, y meterlos dentro de un
    `>` los rompería visualmente.
    """
    if not evidencia:
        return "_Sin evidencia citada._"
    if "```" in evidencia:
        return evidencia
    return "\n".join(f"> {l}" if l.strip() else ">" for l in evidencia.splitlines())


# ═════════════════════════════════════════════════════════════════════════════
# SECCIONES
# ═════════════════════════════════════════════════════════════════════════════

def _cabecera(d: Dict) -> List[str]:
    integ = d.get("integridad") or {}
    cust = d.get("custodia") or {}
    fiable = integ.get("dictamen_confiable")

    out = [
        f"# Informe de validación — {d.get('modelo', 'sin título')}",
        "",
        "> **BORRADOR DE TRABAJO.** Este documento lo genera el agente VIRF para",
        "> que el validador humano lo revise, corrija y redacte el informe final.",
        "> **No es el entregable** y no sustituye el criterio de quien firma.",
        "",
        "| | |",
        "|---|---|",
        f"| Modelo | {d.get('modelo', '—')} |",
        f"| Tier | {d.get('tier', '—')} |",
        f"| Fecha | {d.get('fecha', '—')} |",
        f"| Agente | {_firma_agente(d)} |",
        f"| Score global | **{d.get('score_global', '—')}** — {_semaforo_txt(d)} |",
        f"| Posición en cadena de custodia | {cust.get('posicion_en_cadena', '—')} |",
        f"| Hash del informe | `{str(cust.get('hash_este_informe', '—'))[:32]}` |",
        "",
    ]

    if fiable is False:
        out += [
            "> 🔴 **DICTAMEN NO CONFIABLE.** El agente no pudo evaluar una parte",
            "> suficiente del estándar. Revisa la sección de limitaciones antes de",
            "> usar cualquier cifra de este documento.",
            "",
        ]
    return out


def _como_leer(d: Dict) -> List[str]:
    """
    Cómo interpretar este documento. Va antes que cualquier cifra.

    Sin esto, un lector toma el score global como una nota y se salta el resto.
    El score es un resumen con pérdida: útil para priorizar, inútil para
    concluir. Lo que sostiene un dictamen son las citas, no el número.
    """
    return [
        "## 0. Cómo leer este documento", "",
        "**El score no es la conclusión.** Es un resumen con pérdida de información,",
        "útil para priorizar por dónde empezar e inútil para concluir nada. Lo que",
        "sostiene un dictamen son las citas y el razonamiento, no el número.",
        "",
        "### La escala, y qué exige cada nivel",
        "",
        "| | Significa | Para darlo hace falta |",
        "|---|---|---|",
        "| **1** | No cumple | Ausencia total de evidencia sobre el tema |",
        "| **2** | Brechas críticas | Se menciona, pero no se ejecuta o falta lo esencial |",
        "| **3** | Brechas no críticas | Implementado **y ejecutado**, con huecos menores |",
        "| **4** | Observaciones menores | Además, la elección está **justificada** |",
        "| **5** | Cumple plenamente | Además, supuestos verificados y límites declarados |",
        "",
        "El eje no es «cuánto se habla del tema», es **cuánto está demostrado**. El 5",
        "es poco frecuente por diseño: exige poder defenderlo ante un supervisor con",
        "las citas en la mano.",
        "",
        "### Las cinco trampas que el agente busca",
        "",
        "Cosas que aparentan cumplimiento y no lo son. Si vas a discutir un puntaje,",
        "empieza por comprobar cuál de estas aplica:",
        "",
        "| Trampa | Ejemplo |",
        "|---|---|",
        "| Documentado ≠ correcto | Manual impecable que describe una decisión equivocada |",
        "| Existe ≠ se ejecuta | Script de backtesting que nadie corrió |",
        "| Se menciona ≠ se justifica | «Se aplica la metodología X» sin decir por qué X |",
        "| Se cita ≠ lo sostiene | Un paper que no dice lo que el manual afirma |",
        "| Se calcula ≠ se usa | Métrica que no llega a ningún comité |",
        "",
        "### Dos cosas que NO son lo mismo",
        "",
        "- **Ausencia de evidencia** — el agente no lo encontró en lo que pudo leer.",
        "  Es una limitación del alcance, y se declara como tal.",
        "- **Incumplimiento** — la evidencia está y muestra una deficiencia.",
        "",
        "Confundirlas es el error más caro al redactar: acusa al modelador de algo",
        "que quizá sí documentó, solo que en una página que no cupo en el contexto.",
        "Revisa siempre la **cobertura documental** antes de convertir un puntaje",
        "bajo en un hallazgo.",
        "",
        "### Qué te toca a ti",
        "",
        "Los bloques **✍️** marcan dónde el documento espera tu criterio. El agente",
        "propone; el validador dispone y firma. Ninguna cifra de aquí es definitiva",
        "hasta que la revisas.",
        "",
    ]


def _politicas(d: Dict) -> List[str]:
    """
    Aviso de políticas §4.2 y §6 aplicadas al informe.

    Solo aparece cuando hay algo que decir: si el resultado no marca ni veto
    por ámbito ni críticos automáticos, se omite entero. Un aviso que salta
    cuando no debe es tan dañino como uno que no salta (§3.32 del corolario
    del prompt de continuidad, y ese fue el motivo del clamp de semáforo
    F-15). El texto declara que la decisión formal la firma el validador.
    """
    pol = d.get("politicas_procedimiento") or {}
    if not pol:
        return []
    veto = pol.get("veto_por_ambito") or []
    criticos = pol.get("criticos_automaticos") or []
    if not veto and not criticos:
        return []
    out = ["## 0-bis. Políticas del procedimiento aplicadas", "",
           "El agente ha detectado condiciones que `PROCEDIMIENTO_VALIDACION.md`",
           "trata como automáticas. **La decisión formal la firma el validador**",
           "(§1 del procedimiento); esto solo declara lo que no puede pasarse por",
           "alto.", ""]
    if criticos:
        out += [
            "### §6 — Hallazgos críticos automáticos",
            "",
            "Ámbitos con score ≤ 2, marcados como críticos sin depender del juicio:",
            "",
        ]
        out += [f"- **{a}** — score {d.get('scores_por_ambito', {}).get(a, '—')}"
                for a in criticos]
        out += ["",
                "Un hallazgo crítico se eleva al Comité de Riesgos en su siguiente",
                "sesión, con copia inmediata al dueño del modelo (§6).", ""]
    if veto:
        out += [
            "### §4.2 — Ámbito por debajo del umbral bloqueante",
            "",
            "Ámbitos con score < 2.5. La política **impide la aprobación aunque el",
            "score global la supere**:",
            "",
        ]
        out += [f"- **{a}** — score {d.get('scores_por_ambito', {}).get(a, '—')}"
                for a in veto]
        out += [""]
    return out


def _resumen(d: Dict) -> List[str]:
    scores = d.get("scores_por_ambito") or {}
    if not scores:
        return []

    # Pesos reales del ámbito, si viajan en el JSON: sin ellos no se puede saber
    # qué ámbito mueve de verdad el score global.
    agente = d.get("agente") or {}
    pesos = agente.get("pesos_ambito") if isinstance(agente, dict) else None

    out = ["## 1. Resumen por ámbito", "",
           "Ordenados **de peor a mejor**: por ahí se empieza.", "",
           "| Ámbito | Score | Peso | Aporta al global | Lectura |",
           "|---|---:|---:|---:|---|"]

    for amb, sc in sorted(scores.items(), key=lambda kv: kv[1]):
        try:
            val = float(sc)
            n = int(round(val))
        except (TypeError, ValueError):
            val, n = 1.0, 1
        peso = (pesos or {}).get(amb)
        if peso:
            txt_peso = f"{float(peso):.0%}"
            aporta = f"{val * float(peso):.2f}"
        else:
            txt_peso = aporta = "—"
        out.append(f"| {amb} | {sc} | {txt_peso} | {aporta} | "
                   f"{_SEMAFORO.get(n, '')} {_LABEL.get(n, '')} |")

    out += [
        "",
        "> ✍️ **Te toca:** el ámbito con peor score no siempre es el más urgente —",
        "> mira la columna «aporta al global». Un 2 en Metodología (peso 30 %) pesa",
        "> casi cuatro veces más que un 2 en Uso e integración (8 %).",
        "",
    ]
    return out


def _inconsistencias(d: Dict) -> List[str]:
    """
    Todas las contradicciones del informe, juntas y ordenadas por severidad.

    Van ANTES que el detalle por ámbito a propósito: es el hallazgo de más valor
    de una validación —lo que un revisor humano tarda semanas en encontrar— y
    enterrarlo dentro de la ficha del control nº 23 sería desperdiciarlo.
    """
    todas = []
    for amb, evs in (d.get("resultados_por_ambito") or {}).items():
        for ev in evs or []:
            for inc in ev.get("inconsistencias") or []:
                if isinstance(inc, dict):
                    todas.append((amb, ev.get("actividad", "—"), inc))

    if not todas:
        return [
            "## 2. Inconsistencias entre fuentes", "",
            "_El agente no detectó contradicciones entre la documentación, el código",
            "y los informes de seguimiento._",
            "",
            "> ✍️ **Ojo:** «no detectadas» no es «no existen». La búsqueda se limita",
            "> a la evidencia que cupo en el contexto — revisa la cobertura al final.",
            "",
        ]

    todas.sort(key=lambda t: _ORDEN_SEV.get(
        str(t[2].get("severidad", "media")).lower(), 1))

    out = [
        "## 2. Inconsistencias entre fuentes", "",
        f"**{len(todas)} contradicción(es)** entre lo documentado y lo implementado.",
        "Cada una trae las dos citas enfrentadas para que puedas verificarla en el",
        "documento original.",
        "",
    ]
    for i, (amb, act, inc) in enumerate(todas, 1):
        sev = str(inc.get("severidad", "media")).lower()
        out += [
            f"### 2.{i} [{sev.upper()}] {inc.get('contradiccion', '')}",
            "",
            f"*Ámbito: {amb} · Actividad: {act}*",
            "",
            f"**{inc.get('fuente_a', '?')}** dice:",
            f"> {inc.get('cita_a', '')}",
            "",
            f"**{inc.get('fuente_b', '?')}** dice:",
            f"> {inc.get('cita_b', '')}",
            "",
            "> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un",
            "> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.",
            "",
        ]
    return out


def _metodologia(d: Dict) -> List[str]:
    """Cuestionamientos sobre la elección metodológica, agrupados."""
    bloques = []
    for amb, evs in (d.get("resultados_por_ambito") or {}).items():
        for ev in evs or []:
            c = _txt(ev.get("cuestionamiento_metodologico"))
            if c:
                bloques.append((ev.get("actividad", "—"), c))

    # La sección se emite SIEMPRE, aunque esté vacía. La numeración tiene que ser
    # estable entre corridas: si alguien cita «§5» en un correo, esa referencia
    # no puede apuntar a otra cosa en el informe siguiente solo porque esta vez
    # no hubo cuestionamientos.
    if not bloques:
        return [
            "## 3. Cuestionamiento metodológico", "",
            "_Sin cuestionamientos registrados en esta corrida._",
            "",
            "> ✍️ **Ojo:** solo se genera en actividades del ámbito Metodología, y",
            "> únicamente si el agente encontró en qué apoyarse. Un vacío aquí puede",
            "> significar que la justificación es sólida — o que no había material",
            "> suficiente para juzgarla. Comprueba la cobertura de ese ámbito antes",
            "> de concluir lo primero.",
            "",
        ]

    out = [
        "## 3. Cuestionamiento metodológico", "",
        "Un modelo puede documentar impecablemente una elección equivocada. Esto",
        "no evalúa si la metodología está descrita, sino si está **justificada**.",
        "",
    ]
    for act, c in bloques:
        out += [f"### {act}", "", c, ""]
    out += [
        "> ✍️ **Te toca:** contrasta esto con tu criterio experto. El agente puede",
        "> cuestionar sin conocer restricciones de negocio que sí justifican la",
        "> elección — si es el caso, déjalo escrito en el informe final.",
        "",
    ]
    return out


def _skills(d: Dict) -> List[str]:
    """
    Hallazgos de los análisis transversales.

    Van con su propia numeración y ANTES del detalle por actividad, porque
    responden a preguntas distintas: el detalle dice si cada control se cumple;
    esto dice qué se nos estaba escapando.

    La síntesis se saca del bloque y se coloca la primera: es el resumen que
    ordena todo lo demás.
    """
    res = d.get("skills") or []
    if not isinstance(res, list) or not res:
        return []

    out = ["## 3-bis. Análisis transversales (skills)", "",
           "Investigaciones que cruzan fuentes y no caben en una casilla del",
           "estándar. **No alteran el score**: producen hallazgos, no puntajes.",
           ""]

    # Tabla de control: qué se ejecutó y qué falló. Una skill que no corrió es
    # una limitación del alcance y tiene que constar.
    out += ["| Skill | Estado | Hallazgos | Tiempo |", "|---|---|---:|---:|"]
    for r in res:
        estado = "✅" if r.get("ok") else f"❌ {str(r.get('error', ''))[:40]}"
        out.append(f"| {r.get('titulo', r.get('nombre', '?'))} | {estado} | "
                   f"{len(r.get('hallazgos') or [])} | {r.get('duracion_seg', 0)}s |")
    out.append("")

    # La síntesis primero: es la lectura de conjunto.
    orden = sorted(res, key=lambda r: 0 if r.get("nombre") == "sintesis" else 1)

    for r in orden:
        if not r.get("ok"):
            continue
        out += [f"### {r.get('titulo', '')}", ""]
        if _txt(r.get("resumen")):
            out += [_txt(r["resumen"]), ""]

        for h in r.get("hallazgos") or []:
            if not isinstance(h, dict):
                continue
            # Las skills nombran sus campos distinto a propósito —cada una usa
            # los términos naturales de su análisis—, así que aquí se busca el
            # título y el cuerpo entre varios alias en vez de uniformarlos.
            titulo = next((h[k] for k in (
                "hallazgo", "aspecto", "supuesto", "exigencia", "referencia",
                "decision_del_modelo", "debilidad") if h.get(k)), "—")
            sev = h.get("severidad") or h.get("estado") or h.get("veredicto") or ""
            out.append(f"- **{titulo}**" + (f" · `{sev}`" if sev else ""))

            for k in ("impacto", "riesgo", "brecha", "motivo", "por_que_importa",
                      "riesgo_si_falla", "cuando_importa", "alternativa",
                      "accion", "test_recomendado", "como_contrastarlo"):
                if _txt(h.get(k)):
                    out.append(f"  - _{k.replace('_', ' ')}:_ {_txt(h[k])}")

            for k, v in h.items():
                if k.startswith("cita") and _txt(v):
                    out.append(f"  - `{k}` → «{_txt(v)[:300]}»")
        out.append("")

        # El challenger devuelve además un script ejecutable.
        script = (r.get("extra") or {}).get("script_contraste")
        if _txt(script):
            out += ["**Script de contraste generado:**", "", "```python",
                    _txt(script), "```", "",
                    "> ✍️ **Revísalo antes de ejecutarlo.** Lo escribió un modelo",
                    "> de lenguaje: comprueba las rutas, los supuestos del bloque",
                    "> de constantes y que las columnas existan en tus datos.", ""]

        if r.get("citas_no_verificadas"):
            out += ["> ⚠️ Citas sin coincidencia literal en la evidencia:"] + \
                   [f"> - «{c}»" for c in r["citas_no_verificadas"]] + [""]

    out += ["> ✍️ **Te toca:** estos hallazgos NO están puntuados. Decide cuáles",
            "> pasan al informe final y con qué gravedad.", ""]
    return out


def _pedidos(d: Dict) -> List[str]:
    """
    Todas las preguntas al modelador, juntas y sin repetir.

    Es el segundo entregable real de una validación: la lista de lo que hay que
    pedir. Repartida por fichas de control obliga a recorrer treinta secciones
    para armar un correo; aquí sale lista para enviar.
    """
    vistos, filas = set(), []
    for amb, evs in (d.get("resultados_por_ambito") or {}).items():
        for ev in evs or []:
            # [AUDIT-FIX 2026-08-07] Las preguntas de una actividad que falló
            # TÉCNICAMENTE son nuestras («re-ejecutar la evaluación y verificar
            # la cuota de la API»), no del modelador. Se enviaban en la lista
            # que el validador «manda tal cual», pidiéndole al validado que
            # resolviera una avería de nuestro agente.
            if _pj(ev) is None:
                continue
            for q in ev.get("preguntas_pendientes") or []:
                q = _txt(q)
                clave = q.lower()[:70]
                if q and clave not in vistos:
                    vistos.add(clave)
                    filas.append((amb, _pj(ev), q))
    if not filas:
        return []

    filas.sort(key=lambda t: t[1])          # lo más grave primero
    out = [
        "## 4. Información a solicitar al modelador", "",
        f"**{len(filas)} petición(es)**, sin duplicados y ordenadas por gravedad del",
        "control que las origina. Esta lista se envía tal cual.",
        "",
        "| # | Ámbito | Score | Petición |",
        "|---:|---|---:|---|",
    ]
    for i, (amb, p, q) in enumerate(filas, 1):
        out.append(f"| {i} | {amb} | {p}/5 | {q} |")
    out += [
        "",
        "> ✍️ **Te toca:** depura antes de enviar. Algunas se responderán con un",
        "> documento que ya existe y no llegó a `inputs/` — ésas no son hallazgos,",
        "> son evidencia que faltó aportar.",
        "",
    ]
    return out


def _detalle(d: Dict) -> List[str]:
    out = ["## 5. Detalle por ámbito", ""]
    scores = d.get("scores_por_ambito") or {}

    for amb, evs in (d.get("resultados_por_ambito") or {}).items():
        evs = [e for e in (evs or []) if isinstance(e, dict)]
        if not evs:
            continue
        out += [f"### {amb}  ·  score {scores.get(amb, '—')}", ""]

        # De peor a mejor: lo que hay que arreglar, primero. Los fallos
        # técnicos van al final —no son incumplimientos del validado—.
        for ev in sorted(evs, key=_orden_pj):
            p = _pj(ev)
            act = ev.get("actividad", "—")
            out += [
                f"#### {'⚪' if p is None else _SEMAFORO.get(p, '')} "
                f"[{_etiqueta_pj(p)}] {act}",
                "",
            ]
            if p is None:
                out += [f"> No se pudo evaluar: {_txt(ev.get('error_evaluacion')) or 'fallo técnico'}. "
                        "Queda **sin puntaje** y excluida del score; no cuenta "
                        "como incumplimiento del modelo validado.", ""]
            if ev.get("control"):
                out += [f"*Control: {ev['control']}*", ""]
            if _txt(ev.get("concepto")):
                out += [f"**Qué evalúa.** {_txt(ev['concepto'])}", ""]
            if _txt(ev.get("observacion")):
                out += ["**Hallazgo.**", "", _txt(ev["observacion"]), ""]

            ev_txt = _txt(ev.get("evidencia_encontrada"))
            out += ["**Evidencia citada.**", "", _bloque_citas(ev_txt), ""]

            dudosas = ev.get("citas_no_verificadas") or []
            if dudosas:
                out += [
                    "> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**",
                    "> Verifícalas contra el documento original antes de darlas por buenas:",
                ] + [f"> - «{x}»" for x in dudosas] + [""]

            preg = ev.get("preguntas_pendientes") or []
            if isinstance(preg, list) and preg:
                out += ["**Preguntas al modelador.**", ""]
                out += [f"- [ ] {q}" for q in preg]
                out += [""]

            if _txt(ev.get("recomendacion")):
                out += [f"**Recomendación.** {_txt(ev['recomendacion'])}", ""]

            # Trazabilidad: de dónde salió este puntaje.
            cd = ev.get("cobertura_documental")
            traza = []
            if cd is not None:
                traza.append(f"cobertura documental {cd}%")
            if ev.get("rag_dominio"):
                traza.append(f"RAG {ev['rag_dominio']} ({ev.get('rag_chunks', 0)} frag.)")
            if _txt(ev.get("ajuste_sesgo")) and "N/A" not in _txt(ev.get("ajuste_sesgo")):
                traza.append(f"ajuste sesgo: {_txt(ev['ajuste_sesgo'])}")
            if ev.get("prompt_sha256"):
                traza.append(f"prompt `{str(ev['prompt_sha256'])[:12]}`")
            if traza:
                out += [f"<sub>{' · '.join(traza)}</sub>", ""]

            out += ["> ✍️ _Conclusión del validador:_", ">", "---", ""]
    return out


def _limitaciones(d: Dict) -> List[str]:
    """
    Qué NO se pudo evaluar. La sección que hace defendible el informe.

    Un dictamen que no declara su alcance no resiste una revisión supervisora:
    no se puede distinguir «esto está bien» de «esto no se miró».
    """
    integ = d.get("integridad") or {}
    out = ["## 6. Limitaciones del alcance", "",
           "**Esta sección es obligatoria en el informe final.** Un dictamen que no",
           "declara qué quedó fuera no permite distinguir «esto está bien» de «esto",
           "no se miró».", "",
           "| Concepto | Valor |", "|---|---:|",
           f"| Actividades evaluadas correctamente | {integ.get('actividades_evaluadas_ok', '—')} |",
           f"| Actividades sin evidencia | {integ.get('actividades_sin_evidencia', '—')} |",
           f"| Actividades con fallo técnico | {integ.get('actividades_con_fallo_tecnico', '—')} |",
           ""]

    fallos = integ.get("detalle_fallos") or []
    if fallos:
        out += ["**Fallos técnicos** (limitación del agente, NO deficiencia del modelo validado):", ""]
        out += [f"- {f}" for f in fallos]
        out += [""]

    # Ámbitos donde se leyó poco: el puntaje puede reflejar lectura parcial.
    parciales = []
    for amb, evs in (d.get("resultados_por_ambito") or {}).items():
        for ev in evs or []:
            cd = ev.get("cobertura_documental")
            try:
                if cd is not None and float(cd) < 80:
                    parciales.append((amb, ev.get("actividad", "—"), cd))
            except (TypeError, ValueError):
                pass
    if parciales:
        out += ["**Cobertura documental parcial** — el puntaje puede reflejar que no",
                "se leyó todo el documento, no una deficiencia real:", ""]
        out += [f"- {a} · {act} — {c}%" for a, act, c in parciales[:15]]
        out += [""]

    dudosas_total = sum(
        len(ev.get("citas_no_verificadas") or [])
        for evs in (d.get("resultados_por_ambito") or {}).values()
        for ev in evs or []
    )
    if dudosas_total:
        out += [f"**{dudosas_total} cita(s) sin verificar literalmente.** Marcadas en",
                "el detalle. Revísalas antes de firmar.", ""]

    out += ["> ✍️ **Te toca:** traslada esta sección al informe final tal cual.",
            "> Es lo que un supervisor busca primero.", ""]
    return out


def _pie(d: Dict) -> List[str]:
    return [
        "---", "",
        f"<sub>Generado por VIRF {_firma_agente(d)} el "
        f"{_dt.datetime.now():%Y-%m-%d %H:%M}. Documento de trabajo interno; el "
        f"entregable es el informe Word. El agente no firma: firma el validador.</sub>",
        "",
    ]


# ═════════════════════════════════════════════════════════════════════════════
# ENTRADA PÚBLICA
# ═════════════════════════════════════════════════════════════════════════════

def generar_informe_md(datos: Dict, destino) -> Path:
    """
    Escribe el informe Markdown a partir del JSON de resultados.

    Args:
        datos:   el dict completo del JSON de la corrida.
        destino: ruta del `.md` a escribir.

    Returns:
        La ruta escrita.
    """
    partes: List[str] = []
    partes += _cabecera(datos)
    partes += _politicas(datos)
    partes += _como_leer(datos)
    partes += _resumen(datos)
    partes += _inconsistencias(datos)
    partes += _metodologia(datos)
    partes += _skills(datos)
    partes += _pedidos(datos)
    partes += _detalle(datos)
    partes += _limitaciones(datos)
    partes += _pie(datos)

    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    destino.write_text("\n".join(partes), encoding="utf-8")
    return destino
