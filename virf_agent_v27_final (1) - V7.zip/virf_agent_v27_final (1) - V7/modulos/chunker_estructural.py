"""
modulos/chunker_estructural.py
═════════════════════════════════════════════════════════════════════════════
Chunking ESTRUCTURAL por secciones (WP · GAP-29, guía de errores/loops RAG).

POR QUÉ
───────
El chunking naive por tamaño fijo (1200/200) parte tablas y fórmulas por la
mitad: un fragmento acaba con "VaR = -percentil(retornos," y el siguiente
empieza con "0.99)", y ninguno de los dos es citable ni recuperable con sentido.
La guía exige chunking ESTRUCTURAL o contextual: respetar encabezados, y no
cortar nunca una tabla o una fórmula en medio.

QUÉ HACE
────────
Segmenta un texto (markdown u OOXML aplanado) respetando estas fronteras:
  · Los ENCABEZADOS (`#`, `##`, …) abren una sección nueva.
  · Las TABLAS (líneas con `|`) son bloques ATÓMICOS: no se parten entre filas.
  · Los bloques cercados por ``` (código/fórmulas) son ATÓMICOS.
  · Solo se corta en fronteras de línea/párrafo, nunca a mitad de línea.

Un bloque atómico que por sí solo excede el tamaño máximo se emite entero (mejor
un fragmento grande pero íntegro que una tabla partida). PRESERVA las erratas del
documento fuente: no normaliza ni corrige el contenido.

Es determinista y no llama a la API. Diseñado como reemplazo OPT-IN del corte por
tamaño: el cambio de default en el corpus RAG se hace tras revalidar la puerta
de recall (preguntas_oro_rag), no aquí.
"""
from __future__ import annotations

import re
from typing import List, Optional

__all__ = ["segmentar_estructural"]

_RE_ENCABEZADO = re.compile(r"^\s{0,3}#{1,6}\s")


def _es_tabla(linea: str) -> bool:
    return "|" in linea


def _es_cerca(linea: str) -> bool:
    return linea.lstrip().startswith("```")


def _unidades(texto: str) -> List[tuple]:
    """
    Descompone el texto en unidades tipadas, respetando bloques atómicos.

    Cada unidad es (tipo, texto) con tipo ∈ {encabezado, atomico, parrafo, blanco}.
    """
    lineas = texto.split("\n")
    n = len(lineas)
    unidades: List[tuple] = []
    i = 0
    while i < n:
        linea = lineas[i]

        # Bloque cercado ``` … ``` (fórmulas/código): atómico.
        if _es_cerca(linea):
            bloque = [linea]
            i += 1
            while i < n:
                bloque.append(lineas[i])
                cerrado = _es_cerca(lineas[i])
                i += 1
                if cerrado:
                    break
            unidades.append(("atomico", "\n".join(bloque)))
            continue

        # Encabezado: abre sección.
        if _RE_ENCABEZADO.match(linea):
            unidades.append(("encabezado", linea))
            i += 1
            continue

        # Tabla: run contiguo de líneas con '|', atómico.
        if _es_tabla(linea):
            bloque = [linea]
            i += 1
            while i < n and _es_tabla(lineas[i]):
                bloque.append(lineas[i])
                i += 1
            unidades.append(("atomico", "\n".join(bloque)))
            continue

        # Línea en blanco: separa párrafos.
        if linea.strip() == "":
            unidades.append(("blanco", ""))
            i += 1
            continue

        # Párrafo: run contiguo de líneas normales.
        bloque = [linea]
        i += 1
        while (i < n and lineas[i].strip() != ""
               and not _RE_ENCABEZADO.match(lineas[i])
               and not _es_tabla(lineas[i]) and not _es_cerca(lineas[i])):
            bloque.append(lineas[i])
            i += 1
        unidades.append(("parrafo", "\n".join(bloque)))
    return unidades


def segmentar_estructural(texto: str, size_max: Optional[int] = None) -> List[str]:
    """
    Divide `texto` en segmentos estructurales de a lo sumo `size_max` caracteres.

    Args:
        texto:    documento en markdown/texto plano.
        size_max: tope de caracteres por segmento. Si None, usa CHUNK_SIZE.

    Reglas:
        · Cada encabezado abre un segmento nuevo.
        · Tablas y bloques cercados nunca se parten; si uno excede `size_max`,
          se emite entero como su propio segmento.
        · Nunca se corta a mitad de línea.
    """
    if not texto or not texto.strip():
        return []
    if size_max is None:
        try:
            from config import parametros
            size_max = int(parametros.CHUNK_SIZE)
        except Exception:
            size_max = 1200
    size_max = max(1, int(size_max))

    unidades = _unidades(texto)
    segmentos: List[str] = []
    actual: List[str] = []
    longitud = 0

    def _flush():
        nonlocal actual, longitud
        if actual:
            texto_seg = "\n".join(actual).strip("\n")
            if texto_seg.strip():
                segmentos.append(texto_seg)
        actual = []
        longitud = 0

    for tipo, txt in unidades:
        if tipo == "blanco":
            if actual:
                actual.append("")          # conserva la separación de párrafos
            continue

        if tipo == "encabezado":
            if longitud > 0:
                _flush()                    # el encabezado abre sección nueva
            actual.append(txt)
            longitud += len(txt) + 1
            continue

        # atomico | parrafo
        if longitud > 0 and longitud + len(txt) + 1 > size_max:
            _flush()
        actual.append(txt)
        longitud += len(txt) + 1
        if longitud > size_max:
            # Unidad que por sí sola desborda: se emite íntegra (no se parte).
            _flush()

    _flush()
    return segmentos
