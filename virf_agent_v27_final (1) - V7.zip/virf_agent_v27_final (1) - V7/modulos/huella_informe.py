"""
modulos/huella_informe.py
═══════════════════════════════════════════════════════════════════════════════
PRIMITIVAS DE HUELLA DE UN INFORME — hash canónico y normalización de nombres.

[AUDIT-FIX PENDIENTE-1]

Por qué existe este módulo
──────────────────────────
Estas dos funciones vivían en `modulos/custodia.py`, que era su sitio natural
mientras custodia fuese la única que las usaba. Al añadirse el registro
append-only de emisiones (`modulos/registro_emisiones.py`) apareció un ciclo:

    custodia  →  registro_emisiones   (para anotar cada emisión al sellar)
    registro_emisiones  →  custodia   (para recalcular el hash al verificar)

El ciclo lo detectó `test_no_hay_ciclos_de_import`, y no es una formalidad: los
dos módulos se importan dentro de funciones, así que el ciclo no reventaba al
arrancar —habría sido lo preferible— sino que dejaba el orden de inicialización
dependiendo de quién importara primero. Es la misma clase de fallo silencioso
que §3.2 del prompt de continuidad documenta para `Mx_00_CargaRutas`, donde dos
copias del mismo módulo en `sys.modules` hicieron que un informe titulado «VaR
Mercado FRTB» llevara dentro la huella del manual de LaR.

La dependencia se invierte extrayendo lo COMPARTIDO a un módulo que no depende
de ninguno de los dos:

    custodia            →  huella_informe
    registro_emisiones  →  huella_informe
    custodia            →  registro_emisiones      (sin vuelta)

`custodia` sigue re-exportando `hash_contenido` y `hash_archivo`, que es su API
pública histórica: hay tests y código que importan desde allí, y moverlas sin
más habría sido un cambio incompatible sin ninguna ganancia.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Dict, Optional

#: Campos que NO entran en el hash de contenido: lo derivan o serían circulares.
_EXCLUIDOS_DEL_HASH = ("hash_este_informe", "hash_cadena")

_CLAVE_CUSTODIA = "custodia"


def _sin_campos_derivados(datos: Dict) -> Dict:
    """Copia del informe sin los campos que derivan del propio hash."""
    copia = dict(datos)
    custodia = dict(copia.get(_CLAVE_CUSTODIA) or {})
    for k in _EXCLUIDOS_DEL_HASH:
        custodia.pop(k, None)
    if custodia:
        copia[_CLAVE_CUSTODIA] = custodia
    else:
        copia.pop(_CLAVE_CUSTODIA, None)
    return copia


def hash_contenido(datos: Dict) -> str:
    """
    SHA-256 canónico del contenido de un informe.

    Determinista: `sort_keys=True` garantiza que el orden de inserción de las
    claves no altere el hash. Sin eso, dos corridas con datos idénticos podrían
    dar hashes distintos y la verificación sería inútil.
    """
    fuente = json.dumps(
        _sin_campos_derivados(datos),
        sort_keys=True, ensure_ascii=False, default=str, separators=(",", ":"),
    )
    return hashlib.sha256(fuente.encode("utf-8")).hexdigest()


def hash_archivo(ruta) -> Optional[str]:
    """SHA-256 del contenido binario. None si no se puede leer."""
    try:
        h = hashlib.sha256()
        with open(ruta, "rb") as f:
            for bloque in iter(lambda: f.read(65536), b""):
                h.update(bloque)
        return h.hexdigest()
    except OSError:
        return None


def slug(texto: str) -> str:
    """Normaliza un nombre de modelo para compararlo entre ficheros."""
    return re.sub(r"[^a-z0-9]", "", str(texto or "").lower())
