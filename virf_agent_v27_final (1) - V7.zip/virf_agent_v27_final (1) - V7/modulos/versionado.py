"""
modulos/versionado.py
═════════════════════════════════════════════════════════════════════════════
Versionado temporal de chunks/estándares (WP-10 · GAP-23).

POR QUÉ
───────
La guía advierte del antipatrón "Creer que el RAG soluciona la obsolescencia
temporal": dejar manuales derogados en el índice hace que el agente valide
código de 2026 contra normas de 2018
(`guia-integracion-skills-agente (1).md:299-300`). La corrección es que cada
chunk lleve `effective_date`, `expiration_date` e `is_active`, y que la
recuperación aplique un **pre-filtro duro** que descarte lo inactivo antes de
rankear (`guia-arquitectura-agente-financiero (1).md:50`, checklist 12).

QUÉ HACE
────────
Funciones puras y deterministas para decidir si un chunk está vigente y para
filtrar una lista de chunks. **Aditivo y compatible hacia atrás:** un chunk que
no declara metadatos de versión se considera ACTIVO (el corpus actual no los
tiene, y no debe cambiar de comportamiento). Solo se descarta lo que está
marcado explícitamente como inactivo o fuera de su ventana temporal.

Sin API.
"""
from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Optional

__all__ = ["chunk_activo", "filtrar_activos", "marcar_version"]


def _a_fecha(valor: Any) -> Optional[date]:
    """Parsea una fecha ISO (YYYY-MM-DD) de forma tolerante. None si no aplica."""
    if valor is None or valor == "":
        return None
    if isinstance(valor, date):
        return valor
    try:
        return date.fromisoformat(str(valor)[:10])
    except (ValueError, TypeError):
        # Una fecha ilegible no debe tumbar la recuperación: se ignora el campo
        # (se prefiere incluir de más y avisar, a perder cobertura en silencio).
        return None


def chunk_activo(chunk: Dict[str, Any], en_fecha: Optional[date] = None) -> bool:
    """
    ¿Este chunk está vigente?

    Reglas (un chunk sin metadatos de versión SIEMPRE está activo):
      · `is_active` == False (explícito)          → inactivo.
      · `en_fecha` < `effective_date`             → aún no vigente.
      · `en_fecha` >= `expiration_date`           → derogado.

    Si `en_fecha` es None, solo se evalúa el flag `is_active` (útil en la
    recuperación, donde no queremos acoplar el ranking a la fecha del reloj).
    """
    if not isinstance(chunk, dict):
        return True
    activo = chunk.get("is_active", True)
    if activo is False:
        return False
    if en_fecha is not None:
        eff = _a_fecha(chunk.get("effective_date"))
        exp = _a_fecha(chunk.get("expiration_date"))
        if eff is not None and en_fecha < eff:
            return False
        if exp is not None and en_fecha >= exp:
            return False
    return True


def filtrar_activos(chunks: List[Dict[str, Any]],
                    en_fecha: Optional[date] = None) -> List[Dict[str, Any]]:
    """Pre-filtro duro: devuelve solo los chunks vigentes, preservando el orden."""
    return [c for c in chunks if chunk_activo(c, en_fecha)]


def marcar_version(chunk: Dict[str, Any], *, is_active: bool = True,
                   effective_date: Optional[str] = None,
                   expiration_date: Optional[str] = None,
                   supersedes: Optional[str] = None) -> Dict[str, Any]:
    """
    Estampa metadatos de versión sobre un chunk (aditivo; no toca su texto).
    Utilidad para la ingesta y para construir fixtures de prueba.
    """
    c = dict(chunk)
    c["is_active"] = bool(is_active)
    if effective_date is not None:
        c["effective_date"] = effective_date
    if expiration_date is not None:
        c["expiration_date"] = expiration_date
    if supersedes is not None:
        c["supersedes"] = supersedes
    return c
