"""
modulos/reporte_docx.py
═════════════════════════════════════════════════════════════════════════════
Reporte `.docx` estructurado desde un ValidationReport (WP-08 estructura ·
GAP-44/45/46/47/48).

POR QUÉ
───────
El `.docx` del pipeline (`modulos/generador_word.py`, 2.280 LOC) emite un
semáforo global pero le faltan cuatro piezas que la guía y el estándar exigen:
veredictos por ámbito (APROBADO/PENDIENTE/NO APROBADO), la declaración explícita
"sin observaciones", un pie con paginación y una sección de referencias
consolidada.

QUÉ HACE (y qué NO)
───────────────────
Este módulo construye esas cuatro secciones a partir del contrato tipado
`ValidationReport` (WP-09), de forma AISLADA y determinista — NO toca el
generador de 2.280 LOC (cero riesgo de regresión sobre el artefacto primario).
Es el bloque de construcción probado con python-docx desde un reporte mock; el
cableado al pipeline real (indicador F1, generación E2E) es trabajo del día de
API. Es el mismo patrón opt-in que se usó con el chunker estructural en el Día 1.

Sin API.
"""
from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Dict, List, Optional, Union

from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from modulos.esquemas import EstadoRequisito, ValidationReport

__all__ = ["generar_docx_validacion", "veredicto_de_ambito",
           "APROBADO", "PENDIENTE", "NO_APROBADO", "SIN_OBSERVACIONES"]

APROBADO = "APROBADO"
PENDIENTE = "PENDIENTE"
NO_APROBADO = "NO APROBADO"
SIN_OBSERVACIONES = "Sin observaciones."

_AMBITO_SIN_ETIQUETA = "General"


def veredicto_de_ambito(estados: List[str]) -> str:
    """
    Deriva el veredicto de un ámbito a partir de los `status` de sus hallazgos.

    Regla (conservadora, alineada con "el sistema prefiere no aprobar a la
    ligera"):
      · sin hallazgos                         → APROBADO (sin observaciones).
      · algún OMITIDO o DESVIADO              → NO APROBADO.
      · algún PARCIAL (y ningún desvío/omisión) → PENDIENTE.
      · todos IMPLEMENTADO                    → APROBADO.
    """
    if not estados:
        return APROBADO
    norm = {e.value if isinstance(e, EstadoRequisito) else str(e) for e in estados}
    if norm & {EstadoRequisito.OMITIDO.value, EstadoRequisito.DESVIADO.value}:
        return NO_APROBADO
    if EstadoRequisito.PARCIAL.value in norm:
        return PENDIENTE
    return APROBADO


def _agrupar_por_ambito(reporte: ValidationReport) -> "OrderedDict[str, list]":
    grupos: "OrderedDict[str, list]" = OrderedDict()
    for hallazgo in reporte.findings:
        clave = (hallazgo.ambito or _AMBITO_SIN_ETIQUETA).strip() or _AMBITO_SIN_ETIQUETA
        grupos.setdefault(clave, []).append(hallazgo)
    return grupos


def _añadir_pie_con_paginacion(documento: Document) -> None:
    """
    Inserta en el pie de cada sección un campo dinámico "Página X de Y".

    python-docx no expone campos de página, así que se construye el OOXML del
    campo `PAGE` y `NUMPAGES` a mano (secuencia fldChar begin/instrText/end).
    """
    for seccion in documento.sections:
        parrafo = seccion.footer.paragraphs[0] if seccion.footer.paragraphs \
            else seccion.footer.add_paragraph()
        parrafo.text = ""
        _run_texto(parrafo, "Página ")
        _run_campo(parrafo, "PAGE")
        _run_texto(parrafo, " de ")
        _run_campo(parrafo, "NUMPAGES")


def _run_texto(parrafo, texto: str) -> None:
    run = parrafo.add_run()
    el = OxmlElement("w:t")
    el.set(qn("xml:space"), "preserve")
    el.text = texto
    run._r.append(el)


def _run_campo(parrafo, instruccion: str) -> None:
    """Añade un campo de Word (fldChar begin → instrText → fldChar end)."""
    run = parrafo.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = f" {instruccion} "
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.append(begin)
    run._r.append(instr)
    run._r.append(end)


def generar_docx_validacion(
    reporte: ValidationReport,
    ruta: Union[str, Path],
    *,
    titulo: Optional[str] = None,
) -> Path:
    """
    Genera el `.docx` de validación con las cuatro secciones obligatorias.

    Args:
        reporte: el `ValidationReport` tipado (WP-09).
        ruta:    destino del `.docx`.
        titulo:  título del documento (default: derivado del model_id).

    Returns:
        `Path` del fichero escrito.
    """
    doc = Document()

    doc.add_heading(titulo or f"Informe de validación — {reporte.model_id}", level=0)

    # ── Encabezado / resumen ────────────────────────────────────────────────
    p = doc.add_paragraph()
    p.add_run("Modelo: ").bold = True
    p.add_run(reporte.model_id)
    p = doc.add_paragraph()
    p.add_run("Confianza agregada: ").bold = True
    p.add_run(f"{reporte.overall_confidence:.2f}")
    if reporte.abstained:
        p = doc.add_paragraph()
        p.add_run("EVIDENCIA INSUFICIENTE").bold = True
        p.add_run(" — el validador se abstuvo de emitir veredicto.")

    # ── SECCIÓN 1+2: veredictos por ámbito (con "sin observaciones") ────────
    doc.add_heading("Veredictos por ámbito", level=1)
    grupos = _agrupar_por_ambito(reporte)
    if not grupos:
        # Un reporte sin hallazgos igual declara su ámbito general.
        grupos = OrderedDict({_AMBITO_SIN_ETIQUETA: []})

    referencias: "OrderedDict[str, None]" = OrderedDict()
    for ambito, hallazgos in grupos.items():
        veredicto = veredicto_de_ambito([h.status for h in hallazgos])
        doc.add_heading(f"{ambito}: {veredicto}", level=2)

        if not hallazgos:
            doc.add_paragraph(SIN_OBSERVACIONES)
            continue

        for h in hallazgos:
            pr = doc.add_paragraph(style="List Bullet")
            estado = h.status.value if isinstance(h.status, EstadoRequisito) else h.status
            pr.add_run(f"[{estado}] {h.requirement_id}: ").bold = True
            pr.add_run(h.justification)
            if h.evidence_text:
                doc.add_paragraph(f"Evidencia documental: {h.evidence_text}",
                                  style="Intense Quote")
                referencias[h.evidence_text] = None
            if h.code_evidence:
                referencias[h.code_evidence] = None

    # ── SECCIÓN 3: referencias consolidadas ─────────────────────────────────
    doc.add_heading("Referencias", level=1)
    if referencias:
        for i, ref in enumerate(referencias, start=1):
            doc.add_paragraph(f"[{i}] {ref}")
    else:
        doc.add_paragraph("No se registraron referencias documentales.")

    # ── SECCIÓN 4: pie con paginación ───────────────────────────────────────
    _añadir_pie_con_paginacion(doc)

    destino = Path(ruta)
    destino.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(destino))
    return destino
