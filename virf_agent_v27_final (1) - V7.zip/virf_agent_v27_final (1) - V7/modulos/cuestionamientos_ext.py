"""
Catálogo extensible de cuestionamientos metodológicos.

`Mx_04_MotorControlesData` importaba directamente
`CUESTIONAMIENTOS_METODOLOGICOS` de `Mx_00` — 15 patrones fijos. La UI
web permite ahora al operador añadir cuestionamientos propios (paso 9)
y activar/desactivar los de fábrica. Este módulo hace la mezcla:

- lee `config/cuestionamientos_activos.json` (opcional) para saber qué
  entradas del catálogo por defecto se aplican;
- lee `config/cuestionamientos_personalizados.json` (opcional) con los
  que añade la entidad, valida su estructura y los suma al catálogo;
- devuelve un dict con la MISMA forma que ``CUESTIONAMIENTOS_METODOLOGICOS``
  para que Mx_04 pueda seguir iterándolo sin cambiar su lógica.

Filosofía: silencios NO. Si un personalizado tiene tipo raro o regex
inválido, se descarta y se anota en `.avisos` — no se agrega a medias.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

_BASE_DIR = Path(__file__).resolve().parent.parent

# El módulo `motor/` usa imports sin prefijo (`from Mx_00_CargaRutas ...`).
# Este paquete puede importarse desde la web (raíz en sys.path) o desde el
# agente (motor/ ya en sys.path). Cubrimos ambos casos.
_MOTOR_DIR = _BASE_DIR / "motor"
if str(_MOTOR_DIR) not in sys.path:
    sys.path.insert(0, str(_MOTOR_DIR))
from Mx_00_CargaRutas import CUESTIONAMIENTOS_METODOLOGICOS  # noqa: E402

CONFIG_DIR = _BASE_DIR / "config"
ACT_PATH   = CONFIG_DIR / "cuestionamientos_activos.json"
PERS_PATH  = CONFIG_DIR / "cuestionamientos_personalizados.json"

_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,60}$")


def _leer(p: Path, default):
    if not p.is_file():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _valida_regex(patron: str) -> bool:
    try:
        re.compile(patron)
        return True
    except re.error:
        return False


def _traducir_personalizado(entrada: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    """
    Convierte un dict del formato del router web al formato interno
    del catálogo. Lanza ValueError si algo no cumple el contrato.
    """
    cid = str(entrada.get("id", "")).strip()
    if not _ID_RE.match(cid):
        raise ValueError(f"id inválido: {cid!r}")
    tipo = str(entrada.get("tipo", "")).strip().lower()
    if tipo not in ("presencia", "ausencia"):
        raise ValueError(f"{cid}: tipo debe ser 'presencia' o 'ausencia'")
    patron = str(entrada.get("patron", "")).strip()
    if not patron:
        raise ValueError(f"{cid}: patrón vacío")
    if not _valida_regex(patron):
        raise ValueError(f"{cid}: regex no compila")
    mensaje = str(entrada.get("mensaje", "")).strip() or f"({cid})"
    severidad = str(entrada.get("severidad", "MEDIA")).strip().upper()
    if severidad not in ("ALTA", "MEDIA", "BAJA"):
        raise ValueError(f"{cid}: severidad debe ser ALTA|MEDIA|BAJA")
    return cid, {
        "detectar":          [patron],
        "detectar_ausencia": (tipo == "ausencia"),
        "contexto":          mensaje,
        "critica":           mensaje + f"  [severidad: {severidad}]",
        "origen":            "personalizado",
        "severidad":         severidad,
    }


def catalogo_activo() -> Tuple[Dict[str, Dict[str, Any]], List[str]]:
    """
    Devuelve `(catalogo, avisos)`.

    - `catalogo`: dict `{id: dict con misma forma que CUESTIONAMIENTOS_METODOLOGICOS}`.
      Incluye los del catálogo por defecto que estén activos + los
      personalizados válidos.
    - `avisos`: lista de strings con problemas detectados al leer los
      ficheros (mala regex, id duplicado, tipo raro). Se devuelven para
      que el llamante los emita — no callar.
    """
    activos_map = _leer(ACT_PATH, {})
    if not isinstance(activos_map, dict):
        activos_map = {}
    personalizados = _leer(PERS_PATH, [])
    if not isinstance(personalizados, list):
        personalizados = []

    catalogo: Dict[str, Dict[str, Any]] = {}
    avisos: List[str] = []

    # 1) Defaults, filtrados por activos.
    for cid, info in CUESTIONAMIENTOS_METODOLOGICOS.items():
        if activos_map.get(cid, True):
            catalogo[cid] = {**info, "origen": "default"}

    # 2) Personalizados.
    for i, bruto in enumerate(personalizados):
        try:
            cid, info = _traducir_personalizado(bruto if isinstance(bruto, dict) else {})
        except ValueError as exc:
            avisos.append(f"personalizado #{i}: {exc}")
            continue
        if cid in catalogo:
            # Choque con default: se ignora el personalizado y se avisa.
            # (El router web ya rechaza colisiones al añadir, pero el
            # fichero puede editarse a mano — validamos aquí también.)
            avisos.append(
                f"personalizado {cid!r} colisiona con default y se ignora")
            continue
        catalogo[cid] = info

    return catalogo, avisos
