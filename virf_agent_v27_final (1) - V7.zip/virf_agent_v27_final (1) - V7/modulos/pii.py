"""
modulos/pii.py
═════════════════════════════════════════════════════════════════════════════
Enmascarado DETERMINISTA de datos personales (PII) en la evidencia, ANTES de que
un extracto salga hacia el proveedor de generación.

POR QUÉ EXISTE
──────────────
El corpus RAG (literatura regulatoria) es público, pero la EVIDENCIA DEL MODELO
que se valida —manuales internos, data sets de mercado, logs— puede arrastrar
datos personales: el correo de quien firmó un acta, un IBAN en una hoja de
prueba, un DNI en una muestra de cartera. Ese texto se inyecta hoy tal cual en
el prompt del validador y viaja al proveedor. Enmascararlo aquí es la única capa
que impide esa fuga sin depender de que el documento venga limpio.

PRINCIPIOS DE DISEÑO
────────────────────
1. 100% LOCAL Y DETERMINISTA. Solo `re` y aritmética de checksum. Sin modelos,
   sin red, sin HuggingFace, sin ChromaDB. El mismo texto produce siempre el
   mismo resultado — condición para que un dictamen sea reproducible.

2. ALTA PRECISIÓN ANTES QUE ALTA COBERTURA. Un documento financiero está LLENO
   de números que NO son PII (importes, tasas, umbrales, códigos de control).
   Enmascarar de más CORROMPE la evidencia y puede cambiar un dictamen, que es
   peor que dejar pasar un dato. Por eso cada patrón numérico se valida por
   checksum (Luhn para tarjeta, mod-97 para IBAN, letra de control para DNI/NIE):
   la probabilidad de que una cifra cualquiera pase el checksum por azar es
   ínfima. Los teléfonos, que no tienen checksum, solo se enmascaran cuando el
   texto los ANUNCIA como tales («tel.», «móvil», «+34…») — nunca una cifra suelta.

3. CONSISTENCIA CON LA VERIFICACIÓN DE CITAS. El motor enmascara el `contexto`
   UNA vez, y a partir de ahí el prompt Y la verificación literal de citas usan
   el mismo texto enmascarado. Así una cita del modelo sobre un fragmento con
   `[TARJETA]` sigue casando: no se introduce una discrepancia artificial.

Devuelve SIEMPRE (texto, hallazgos). Nunca lanza: un fallo del enmascarador no
puede tumbar una validación — como mucho, se registra y se deja pasar el texto
original (con aviso), porque abortar sería peor que el riesgo que mitiga.

Uso:
    from modulos.pii import enmascarar
    limpio, hallazgos = enmascarar(texto_evidencia)
    #  hallazgos → [{"tipo": "CORREO", "n": 2}, {"tipo": "TARJETA", "n": 1}]
"""

from __future__ import annotations

import logging
import re
from typing import Dict, List, Tuple

logger = logging.getLogger("virf.pii")

__all__ = ["enmascarar", "contiene_pii", "PLACEHOLDERS"]

# Etiqueta de reemplazo por tipo. Se eligen tokens que NO aparecen en texto
# normal y que un lector del informe entiende sin leyenda.
PLACEHOLDERS = {
    "CORREO":   "[CORREO]",
    "IBAN":     "[IBAN]",
    "TARJETA":  "[TARJETA]",
    "DOCID":    "[DOC_ID]",     # DNI / NIE español
    "TELEFONO": "[TELEFONO]",
}


# ═════════════════════════════════════════════════════════════════════════════
# CHECKSUMS — lo que separa un dato real de una cifra cualquiera
# ═════════════════════════════════════════════════════════════════════════════

def _luhn_valido(digitos: str) -> bool:
    """Algoritmo de Luhn (tarjetas de pago). Rechaza la inmensa mayoría de las
    cadenas de dígitos que no son un número de tarjeta."""
    if not digitos.isdigit():
        return False
    total, alt = 0, False
    for d in reversed(digitos):
        n = ord(d) - 48
        if alt:
            n *= 2
            if n > 9:
                n -= 9
        total += n
        alt = not alt
    return total % 10 == 0


_IBAN_VALORES = {c: str(i) for i, c in enumerate(
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ", start=10)}


def _iban_valido(iban: str) -> bool:
    """Validación mod-97 (ISO 13616): mueve los 4 primeros caracteres al final,
    convierte letras a números y comprueba que el entero resultante ≡ 1 (mod 97)."""
    iban = iban.replace(" ", "").upper()
    if len(iban) < 15 or len(iban) > 34:
        return False
    if not (iban[:2].isalpha() and iban[2:4].isdigit()):
        return False
    reordenado = iban[4:] + iban[:4]
    convertido = "".join(_IBAN_VALORES.get(c, c) for c in reordenado)
    if not convertido.isdigit():
        return False
    return int(convertido) % 97 == 1


_DNI_LETRAS = "TRWAGMYFPDXBNJZSQVHLCKE"


def _dni_nie_valido(texto: str) -> bool:
    """DNI (8 dígitos + letra) o NIE (X/Y/Z + 7 dígitos + letra) con letra de
    control correcta. El checksum es lo que evita enmascarar «12345678» a secas."""
    t = texto.upper().replace("-", "").replace(" ", "")
    m = re.fullmatch(r"([XYZ]?)(\d{7,8})([A-Z])", t)
    if not m:
        return False
    prefijo, numero, letra = m.groups()
    if prefijo:                       # NIE: X→0, Y→1, Z→2
        if len(numero) != 7:
            return False
        numero = str("XYZ".index(prefijo)) + numero
    elif len(numero) != 8:
        return False
    return _DNI_LETRAS[int(numero) % 23] == letra


# ═════════════════════════════════════════════════════════════════════════════
# PATRONES
# ═════════════════════════════════════════════════════════════════════════════
# Correo: patrón estándar conservador. El `\b` evita comerse parte de una URL.
_RE_CORREO = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")

# IBAN: 2 letras de país + 2 dígitos + 11-30 alfanuméricos, con separadores
# simples opcionales entre caracteres. La forma exacta la valida el mod-97; el
# patrón solo acota candidatos, así que se deja permisivo a propósito.
_RE_IBAN = re.compile(
    r"\b[A-Z]{2}\d{2}(?:[ -]?[A-Z0-9]){11,30}\b")

# Tarjeta: 13-19 dígitos con espacios o guiones opcionales. Se valida Luhn.
_RE_TARJETA = re.compile(
    r"\b(?:\d[ -]?){13,19}\b")

# DNI/NIE: se captura ancho y se valida la letra de control (descarta cifras).
_RE_DNI = re.compile(
    r"\b[XYZ]?\d{7,8}[ -]?[A-Za-z]\b")

# Teléfono CON CONTEXTO: solo si el propio texto lo anuncia. Nunca una cifra
# suelta —en un documento financiero, eso sería un importe—. Dos disparadores:
#   · una etiqueta previa: tel/telf/teléfono/móvil/celular/cel/fax/whatsapp/phone
#   · un prefijo internacional explícito «+NN »
_RE_TEL_ETIQUETA = re.compile(
    r"(?i)\b(?:tel(?:[eé]fono|f)?|m[oó]vil|celular|cel|fax|whats?app|phone)\b"
    r"\s*[:.\-]?\s*(\+?\d[\d ().\-]{7,}\d)")
_RE_TEL_INTL = re.compile(
    r"(?<![\d.])\+\d{1,3}[ .\-]?(?:\d[ .\-]?){7,12}\d\b")


def _sub_validado(patron: re.Pattern, texto: str, etiqueta: str,
                  validar) -> Tuple[str, int]:
    """Sustituye las coincidencias de `patron` que pasen `validar` por su
    placeholder. Cuenta cuántas se enmascararon. `validar` recibe la cadena de
    la coincidencia (solo dígitos ya extraídos donde corresponda)."""
    n = 0
    ph = PLACEHOLDERS[etiqueta]

    def _rep(m: re.Match) -> str:
        nonlocal n
        crudo = m.group(0)
        if validar(crudo):
            n += 1
            return ph
        return crudo

    return patron.sub(_rep, texto), n


def enmascarar(texto: str) -> Tuple[str, List[Dict[str, int]]]:
    """
    Enmascara PII en `texto` y devuelve (texto_enmascarado, hallazgos).

    El orden importa: correo e IBAN primero (llevan letras y no colisionan con
    los patrones numéricos), luego tarjeta y DNI (validados por checksum), y por
    último los teléfonos con contexto. Así una cifra ya enmascarada no vuelve a
    tocarse y no se solapan reemplazos.

    Nunca lanza: ante cualquier error devuelve el texto ORIGINAL con un aviso en
    el log — enmascarar es una salvaguarda, y una salvaguarda que rompe la
    corrida sería peor que el riesgo que mitiga.
    """
    if not texto or not isinstance(texto, str):
        return texto or "", []

    try:
        conteo: Dict[str, int] = {}

        texto, n = _sub_validado(_RE_CORREO, texto, "CORREO", lambda s: True)
        if n:
            conteo["CORREO"] = n

        texto, n = _sub_validado(_RE_IBAN, texto, "IBAN", _iban_valido)
        if n:
            conteo["IBAN"] = n

        # Tarjeta: se valida Luhn SOBRE LOS DÍGITOS (quitando separadores).
        texto, n = _sub_validado(
            _RE_TARJETA, texto, "TARJETA",
            lambda s: _luhn_valido(re.sub(r"\D", "", s)))
        if n:
            conteo["TARJETA"] = n

        texto, n = _sub_validado(_RE_DNI, texto, "DOCID", _dni_nie_valido)
        if n:
            conteo["DOCID"] = n

        # Teléfonos: dos pasadas. La etiquetada reemplaza SOLO el grupo del
        # número (no la palabra «tel.»), así que se maneja aparte.
        ph_tel = PLACEHOLDERS["TELEFONO"]
        n_tel = 0

        def _rep_tel_etq(m: re.Match) -> str:
            nonlocal n_tel
            n_tel += 1
            return m.group(0)[: m.start(1) - m.start(0)] + ph_tel

        texto = _RE_TEL_ETIQUETA.sub(_rep_tel_etq, texto)

        def _rep_tel_intl(m: re.Match) -> str:
            nonlocal n_tel
            n_tel += 1
            return ph_tel

        texto = _RE_TEL_INTL.sub(_rep_tel_intl, texto)
        if n_tel:
            conteo["TELEFONO"] = n_tel

        hallazgos = [{"tipo": t, "n": c} for t, c in conteo.items()]
        if hallazgos:
            logger.info("PII enmascarada: %s",
                        ", ".join(f"{h['tipo']}×{h['n']}" for h in hallazgos))
        return texto, hallazgos

    except Exception as exc:                              # pragma: no cover
        logger.warning("Enmascarado PII falló (%s); se deja el texto original.", exc)
        return texto, []


def contiene_pii(texto: str) -> bool:
    """¿Hay al menos un dato personal detectable? Útil para tests y avisos."""
    _, hallazgos = enmascarar(texto)
    return bool(hallazgos)
