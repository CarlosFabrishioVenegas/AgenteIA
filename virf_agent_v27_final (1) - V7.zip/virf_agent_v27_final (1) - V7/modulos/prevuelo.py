"""
modulos/prevuelo.py
═══════════════════════════════════════════════════════════════════════════════
PRE-VUELO DE LA EVIDENCIA — qué se va a poder leer, antes de gastar.

QUÉ RESUELVE
────────────
Hasta ahora, los problemas de la evidencia se descubrían A MITAD DE CORRIDA,
con la extracción y varias llamadas ya pagadas:

  · un PDF escaneado — ilegible desde que se retiró el OCR por política —
    aparecía como `lectura_fallida` cuando el ámbito ya se estaba evaluando;
  · un `.scala` o un `.yaml` se omitía SIN AVISO: `leer_archivo()` devuelve
    None y el fichero desaparece de la evidencia sin que nadie lo cuente;
  · una carpeta vacía producía un ámbito «sin evidencia» que la política
    puntúa 0.0 — una falta crítica atribuida al validado cuando en realidad
    faltaba un documento que nadie echó en falta a tiempo.

Los tres son baratos de detectar y caros de descubrir tarde. Este módulo los
detecta ANTES, sin llamar al modelo.

POR QUÉ LA LECTURA NO ES TRABAJO PERDIDO
────────────────────────────────────────
El pre-vuelo lee los documentos de verdad —es la única forma de saber si un PDF
tiene texto extraíble— pero lo hace a través de `leer_archivo()`, que pasa por
el caché indexado por SHA-256. La corrida real que venga después reutiliza esas
lecturas: el pre-vuelo ADELANTA trabajo, no lo duplica.

QUÉ NO HACE
───────────
No llama al modelo, no puntúa y no predice hallazgos. Responde a una sola
pregunta: «con esta evidencia, ¿qué va a poder evaluar el agente y qué no?».
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

logger = logging.getLogger("virf.prevuelo")

__all__ = ["Hallazgo", "InformePrevuelo", "ejecutar_prevuelo", "formatear"]

# Extensiones que NO son evidencia y cuya omisión es correcta: no se reportan
# como problema para no llenar el informe de ruido.
_RUIDO = {".pyc", ".pyo", ".lock", ".tmp", ".bak", ".log", ".DS_Store",
          ".gitkeep", ".gitignore"}


@dataclass
class Hallazgo:
    """Un fichero que no va a llegar al evaluador, y por qué."""
    ruta: Path
    carpeta: str
    motivo: str          # 'escaneado' | 'sin_lector' | 'lectura_fallida'
    detalle: str = ""

    @property
    def nombre(self) -> str:
        return self.ruta.name


@dataclass
class InformePrevuelo:
    legibles: List[Dict] = field(default_factory=list)
    escaneados: List[Hallazgo] = field(default_factory=list)
    sin_lector: List[Hallazgo] = field(default_factory=list)
    fallidos: List[Hallazgo] = field(default_factory=list)
    carpetas_vacias: List[str] = field(default_factory=list)
    carpetas_inexistentes: List[str] = field(default_factory=list)
    ambitos_sin_evidencia: List[str] = field(default_factory=list)
    # Ámbitos que SÍ se evaluarán, pero cuya carpeta PRINCIPAL está vacía:
    # (ámbito, carpeta_que_falta). Ver `_ambitos_parciales`.
    ambitos_parciales: List[tuple] = field(default_factory=list)
    chars_por_carpeta: Dict[str, int] = field(default_factory=dict)

    @property
    def chars_totales(self) -> int:
        return sum(self.chars_por_carpeta.values())

    @property
    def n_problemas(self) -> int:
        return (len(self.escaneados) + len(self.sin_lector) + len(self.fallidos)
                + len(self.ambitos_sin_evidencia))

    @property
    def hay_bloqueantes(self) -> bool:
        """
        Un ámbito sin evidencia es BLOQUEANTE: puntúa 0.0 y esa nota va al
        informe como falta crítica del validado. Los ficheros ilegibles son
        graves pero el resto del ámbito puede sostener la evaluación.
        """
        return bool(self.ambitos_sin_evidencia)

    def a_dict(self) -> Dict:
        return {
            "n_legibles": len(self.legibles),
            "chars_totales": self.chars_totales,
            "escaneados": [h.nombre for h in self.escaneados],
            "sin_lector": [h.nombre for h in self.sin_lector],
            "lectura_fallida": [h.nombre for h in self.fallidos],
            "carpetas_vacias": self.carpetas_vacias,
            "carpetas_inexistentes": self.carpetas_inexistentes,
            "ambitos_sin_evidencia": self.ambitos_sin_evidencia,
            "chars_por_carpeta": self.chars_por_carpeta,
            "hay_bloqueantes": self.hay_bloqueantes,
        }


def _clasificar_fallo(contenido: str, ruta: Path) -> tuple:
    """Distingue un PDF escaneado de otro fallo de lectura."""
    txt = (contenido or "").upper()
    if "SIN TEXTO EXTRAÍBLE" in txt or "ESCANEADO" in txt:
        return ("escaneado",
                "PDF sin texto extraíble (imagen). El OCR se retiró por "
                "política de modelos externos.")
    return ("lectura_fallida", (contenido or "").strip()[:120])


def ejecutar_prevuelo(rutas_inputs: Optional[Dict[str, Path]] = None,
                      ambito_a_inputs: Optional[Dict[str, List[str]]] = None
                      ) -> InformePrevuelo:
    """
    Recorre las carpetas de evidencia y clasifica cada fichero.

    `rutas_inputs` y `ambito_a_inputs` se inyectan para poder probar sin tocar
    la configuración global, y porque `RUTAS["inputs"]` viene ya reapuntado si
    se usó `--raiz-evidencia`: el pre-vuelo debe inspeccionar el árbol del
    modelo correcto, no el del proyecto.
    """
    from motor.Mx_01_LecturaEvidencias import (
        LECTORES_EXT, _MARCA_LECTURA_FALLIDA, _es_evidencia, leer_archivo,
    )

    if rutas_inputs is None:
        from motor.Mx_00_CargaRutas import RUTAS
        rutas_inputs = RUTAS["inputs"]
    if ambito_a_inputs is None:
        from motor.Mx_00_CargaRutas import AMBITO_A_INPUTS
        ambito_a_inputs = AMBITO_A_INPUTS

    inf = InformePrevuelo()
    con_contenido: Dict[str, bool] = {}

    for carpeta, ruta in sorted(rutas_inputs.items()):
        ruta = Path(ruta)
        con_contenido[carpeta] = False
        inf.chars_por_carpeta[carpeta] = 0

        if not ruta.is_dir():
            inf.carpetas_inexistentes.append(carpeta)
            continue

        ficheros = [p for p in sorted(ruta.rglob("*"))
                    if p.is_file() and _es_evidencia(p)
                    and p.suffix.lower() not in _RUIDO]
        if not ficheros:
            inf.carpetas_vacias.append(carpeta)
            continue

        for p in ficheros:
            ext = p.suffix.lower()
            if ext not in LECTORES_EXT:
                # El caso que más duele: hoy desaparece sin dejar rastro.
                inf.sin_lector.append(Hallazgo(
                    p, carpeta, "sin_lector",
                    f"extensión '{ext or '(ninguna)'}' no registrada en "
                    f"LECTORES_EXT — el fichero se omite SIN AVISO"))
                continue

            try:
                doc = leer_archivo(p)
            except Exception as exc:                      # noqa: BLE001
                inf.fallidos.append(Hallazgo(p, carpeta, "lectura_fallida",
                                             str(exc)[:120]))
                continue

            if doc is None:
                inf.sin_lector.append(Hallazgo(
                    p, carpeta, "sin_lector", "leer_archivo() devolvió None"))
                continue

            if doc.get("lectura_fallida") or _MARCA_LECTURA_FALLIDA in \
                    (doc.get("contenido") or ""):
                motivo, detalle = _clasificar_fallo(doc.get("contenido", ""), p)
                destino = inf.escaneados if motivo == "escaneado" else inf.fallidos
                destino.append(Hallazgo(p, carpeta, motivo, detalle))
                continue

            chars = int(doc.get("chars_totales", 0) or 0)
            inf.chars_por_carpeta[carpeta] += chars
            inf.legibles.append({"nombre": p.name, "carpeta": carpeta,
                                 "chars": chars, "tipo": doc.get("tipo", "?")})
            con_contenido[carpeta] = True

    # Un ámbito sin NINGUNA carpeta con contenido legible puntuará 0.0 (D3-FIX).
    # Es la consecuencia más cara y la que hay que ver antes de gastar.
    #
    # Y un caso intermedio que conviene no pasar por alto: el ámbito TIENE
    # evidencia, pero su carpeta PRINCIPAL está vacía. El orden de
    # `AMBITO_A_INPUTS` no es casual — la primera es la fuente propia del
    # ámbito, las siguientes son apoyo. «Calidad de datos» con `calidad_datos`
    # vacía se evaluaría solo desde el manual metodológico: técnicamente hay
    # evidencia, pero no la que ese ámbito debe examinar. Se avisa sin bloquear,
    # porque puede ser legítimo y la decisión es del validador.
    for ambito, carpetas in ambito_a_inputs.items():
        if not any(con_contenido.get(c) for c in carpetas):
            inf.ambitos_sin_evidencia.append(ambito)
        elif carpetas and not con_contenido.get(carpetas[0]):
            inf.ambitos_parciales.append((ambito, carpetas[0]))

    return inf


def formatear(inf: InformePrevuelo, max_filas: int = 12) -> str:
    """Informe legible para consola."""
    sep = "═" * 74
    L = ["", sep, "  🔍 PRE-VUELO DE LA EVIDENCIA — coste 0, sin llamar al modelo", sep]

    L.append(f"\n  ✅ LEGIBLES: {len(inf.legibles)} fichero(s) · "
             f"{inf.chars_totales:,} chars")
    for carpeta, chars in sorted(inf.chars_por_carpeta.items(),
                                 key=lambda x: -x[1]):
        if chars:
            n = sum(1 for d in inf.legibles if d["carpeta"] == carpeta)
            L.append(f"       {carpeta:<20} {n:>3} fichero(s)  {chars:>10,} chars")

    if inf.escaneados:
        L.append(f"\n  ⛔ NO SE PUEDEN LEER — PDF escaneado ({len(inf.escaneados)}):")
        for h in inf.escaneados[:max_filas]:
            L.append(f"       {h.carpeta}/{h.nombre}")
        L.append("       → Apórtalos en digital, o conviértelos a texto con la")
        L.append("         herramienta de OCR aprobada por tu entidad.")

    if inf.sin_lector:
        L.append(f"\n  ⚠️  SE OMITEN SIN AVISO — formato no registrado "
                 f"({len(inf.sin_lector)}):")
        for h in inf.sin_lector[:max_filas]:
            L.append(f"       {h.carpeta}/{h.nombre}   {h.detalle.split('—')[0].strip()}")
        L.append("       → Hoy desaparecen de la evidencia sin dejar rastro.")
        L.append("         Regístralos en LECTORES_EXT o conviértelos.")

    if inf.fallidos:
        L.append(f"\n  ❌ LECTURA FALLIDA ({len(inf.fallidos)}):")
        for h in inf.fallidos[:max_filas]:
            L.append(f"       {h.carpeta}/{h.nombre}: {h.detalle}")

    if inf.carpetas_inexistentes:
        L.append(f"\n  📂 CARPETAS QUE NO EXISTEN: "
                 f"{', '.join(inf.carpetas_inexistentes)}")
    if inf.carpetas_vacias:
        L.append(f"  📂 CARPETAS VACÍAS: {', '.join(inf.carpetas_vacias)}")

    if inf.ambitos_sin_evidencia:
        L += ["", "  " + "─" * 70,
              f"  🔴 BLOQUEANTE — {len(inf.ambitos_sin_evidencia)} ámbito(s) "
              f"SIN evidencia:"]
        for a in inf.ambitos_sin_evidencia:
            L.append(f"       · {a}")
        L += ["",
              "     Estos ámbitos NO se evaluarán (D3-FIX: el agente no evalúa",
              "     sobre el vacío) y su score será `null`. Si además faltan en",
              "     el estándar del tier, el informe los declara como falta de",
              "     evidencia — atribuida al VALIDADO.",
              "",
              "     Consigue esa documentación antes de emitir un dictamen."]
    else:
        L += ["", f"  ✅ Los {len(inf.chars_por_carpeta) and 6} ámbitos tienen "
                  f"evidencia: ninguno puntuará 0.0 por ausencia."]

    if inf.ambitos_parciales:
        L += ["", "  ⚠️  EVIDENCIA PARCIAL — el ámbito se evaluará, pero su "
                  "carpeta principal está vacía:"]
        for ambito, carpeta in inf.ambitos_parciales:
            L.append(f"       · {ambito:<32} falta  inputs/{carpeta}/")
        L += ["     Se evaluará con las carpetas de apoyo. Es legítimo si esa",
              "     documentación no aplica, pero revísalo: un ámbito juzgado",
              "     sin su fuente propia da un puntaje débil de sostener."]

    L += ["", sep]
    if inf.n_problemas == 0:
        L.append("  ✅ Evidencia completa y legible. Puedes lanzar la corrida.")
    else:
        L.append(f"  Resumen: {inf.n_problemas} problema(s) detectado(s) "
                 f"ANTES de gastar un token.")
    L += [sep, ""]
    return "\n".join(L)
