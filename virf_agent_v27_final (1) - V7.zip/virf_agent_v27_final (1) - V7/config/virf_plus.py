"""
config/virf_plus.py
═════════════════════════════════════════════════════════════════════════════
VIRF PLUS — el agente principal (GPT) suma a Claude como segunda opinión.

Por qué un CLIENTE y no un cambio en cada módulo
------------------------------------------------
Todo el sistema (controles del pipeline, chat de sustentación, entailment,
generador de notebooks, informe) habla con la IA a través de un único
`config.get_cliente_ia().generar_mensaje(...)`. `ClienteConsensoIA` cumple esa
misma interfaz, así que encender VIRF PLUS adapta TODOS los consumidores a la
vez sin tocar sus prompts ni sus parsers.

Cómo llega a una conclusión
---------------------------
  1. La MISMA tarea (sistema + prompt + evidencia) va a GPT y a Claude en
     paralelo. Ninguno ve la respuesta del otro: dos opiniones independientes.
  2. Se comparan los campos de decisión (puntaje, resultado, veredicto,
     cumple…) cuando la respuesta es JSON.
  3. Un árbitro (GPT, el agente principal, por defecto) recibe la tarea original y las dos
     respuestas y redacta UNA respuesta final en el formato exacto que pedía
     la tarea. Regla de prudencia: si la evidencia no zanja un desacuerdo de
     puntaje o resultado, gana la lectura más conservadora.
  4. Cada conciliación queda en `audit_logs/virf_plus_consenso.jsonl` con las
     dos opiniones, las discrepancias y la conclusión, para que el validador
     humano pueda ver dónde discreparon los modelos antes de firmar.

Sin fallback silencioso: si uno de los dos modelos falla, la llamada falla.
Una «conclusión conjunta» con un solo evaluador sería mentir en el informe.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .ia import ClienteIA, ClienteAnthropicIA, FABRICAS
from .parametros import VIRF_PLUS_ARBITRAJE, VIRF_PLUS_ARBITRO, VIRF_PLUS_GPT
from .rutas import BASE_DIR

__all__ = ["ClienteConsensoIA", "comparar_respuestas", "INSTRUCCION_ARBITRO"]

# Campos que deciden el dictamen. Si difieren entre los dos modelos hay una
# discrepancia de fondo, no de redacción.
CAMPOS_DECISION = (
    "puntaje", "score", "calificacion", "resultado", "veredicto", "dictamen",
    "cumple", "implica", "estado", "nivel_riesgo", "riesgo", "severidad",
)

INSTRUCCION_ARBITRO = """\
MODO VIRF PLUS — CONCILIACIÓN DE DOS EVALUADORES

Dos evaluadores independientes (A = GPT, agente principal; B = Claude, segunda
opinión) resolvieron la misma tarea sobre la misma evidencia sin ver la
respuesta del otro. Tu trabajo es emitir la
CONCLUSIÓN ÚNICA que firmaría un validador senior:

1. Contrasta ambas respuestas contra la evidencia de la TAREA ORIGINAL. Un
   hallazgo solo se conserva si la evidencia lo sostiene; descarta lo que
   cualquiera de los dos haya afirmado sin respaldo.
2. Donde coinciden, fusiona su redacción en la explicación más clara y
   completa: describe el producto/modelo y el proceso con precisión técnica.
3. Donde discrepan en puntaje, resultado o veredicto, decide por la evidencia.
   Si la evidencia no lo zanja, adopta la lectura MÁS CONSERVADORA (menor
   puntaje, resultado menos favorable): en validación, la duda no favorece al
   modelo validado.
4. No inventes evidencia, citas ni cifras que no estén en la tarea original.
5. Devuelve la respuesta en EXACTAMENTE el formato que pide la tarea original
   (mismas claves si es JSON, sin claves nuevas, sin markdown ni texto fuera
   del JSON). No menciones a «evaluador A/B» en el texto final salvo que el
   formato tenga un campo para ello.
"""

_LOCK_LOG = threading.Lock()
_MAX_HISTORIAL = 200


# ─── Comparación ────────────────────────────────────────────────────────────

def _json_laxo(texto: str) -> Optional[Any]:
    """Primer objeto/lista JSON del texto (tolera fences y prosa). None si no hay."""
    if not texto:
        return None
    limpio = re.sub(r"^\s*```(?:json)?\s*", "", texto.strip())
    limpio = re.sub(r"\s*```\s*$", "", limpio).strip()
    try:
        return json.loads(limpio)
    except (json.JSONDecodeError, ValueError):
        pass
    inicio = limpio.find("{")
    if inicio == -1:
        return None
    prof = 0
    for i in range(inicio, len(limpio)):
        if limpio[i] == "{":
            prof += 1
        elif limpio[i] == "}":
            prof -= 1
            if prof == 0:
                try:
                    return json.loads(limpio[inicio:i + 1])
                except (json.JSONDecodeError, ValueError):
                    return None
    return None


def _campos_decision(obj: Any, prefijo: str = "") -> dict:
    """Aplana los campos de decisión de un JSON (incluidos los anidados)."""
    salida: dict = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            ruta = f"{prefijo}{k}"
            if str(k).lower() in CAMPOS_DECISION and not isinstance(v, (dict, list)):
                salida[ruta] = v
            elif isinstance(v, (dict, list)):
                salida.update(_campos_decision(v, ruta + "."))
    elif isinstance(obj, list):
        for i, v in enumerate(obj[:50]):
            salida.update(_campos_decision(v, f"{prefijo}{i}."))
    return salida


def _normalizar(v: Any) -> str:
    return re.sub(r"\s+", " ", str(v)).strip().lower()


def comparar_respuestas(a: str, b: str) -> dict:
    """
    Compara dos respuestas. Devuelve:
      json         ambas parsean como JSON
      coinciden    campos de decisión iguales en ambas
      discrepancias {campo: [valor_A, valor_B]}
      acuerdo      True si no hay discrepancia de fondo
    """
    ja, jb = _json_laxo(a), _json_laxo(b)
    if ja is None or jb is None:
        igual = _normalizar(a) == _normalizar(b)
        return {"json": False, "coinciden": [], "discrepancias": {},
                "acuerdo": igual}
    ca, cb = _campos_decision(ja), _campos_decision(jb)
    coinciden, discrepancias = [], {}
    for campo in sorted(set(ca) | set(cb)):
        va, vb = ca.get(campo), cb.get(campo)
        if _normalizar(va) == _normalizar(vb):
            coinciden.append(campo)
        else:
            discrepancias[campo] = [va, vb]
    return {"json": True, "coinciden": coinciden,
            "discrepancias": discrepancias, "acuerdo": not discrepancias}


# ─── Cliente ────────────────────────────────────────────────────────────────

def _nombre_modelo(cliente) -> str:
    return str(getattr(cliente, "_modelo_real", None)
               or getattr(cliente, "modelo", None)
               or getattr(cliente, "deployment", None)
               or type(cliente).__name__)


class ClienteConsensoIA(ClienteIA):
    """Cliente IA que consulta a Claude y a GPT y concilia sus respuestas."""

    def __init__(self, claude: Optional[ClienteIA] = None,
                 gpt: Optional[ClienteIA] = None,
                 arbitro: Optional[str] = None,
                 arbitraje: Optional[str] = None,
                 ruta_log: Optional[Path] = None):
        proveedor_gpt = VIRF_PLUS_GPT
        if gpt is None and proveedor_gpt not in ("openai", "azure_openai"):
            raise ValueError(
                f"❌ VIRF_PLUS_GPT='{proveedor_gpt}' no es válido. "
                f"Usa 'openai' (API key de OpenAI) o 'azure_openai'.")
        # Errores de configuración (clave vacía, placeholder) salen con el
        # mensaje del propio proveedor, que dice qué variable falta.
        self.claude = claude if claude is not None else ClienteAnthropicIA()
        self.gpt = gpt if gpt is not None else FABRICAS[proveedor_gpt]()
        self.arbitro = (arbitro or VIRF_PLUS_ARBITRO or "gpt").lower()
        self.arbitraje = (arbitraje or VIRF_PLUS_ARBITRAJE or "siempre").lower()
        self.ruta_log = Path(ruta_log) if ruta_log else (
            Path(os.getenv("VIRF_PLUS_LOG", "")) if os.getenv("VIRF_PLUS_LOG")
            else BASE_DIR / "audit_logs" / "virf_plus_consenso.jsonl")
        self.ultimo_consenso: dict = {}
        self.historial: list = []

    # Perfil de contexto: el del modelo GPT, que suele ser la ventana más
    # estrecha de los dos. Un prompt que cabe en GPT cabe en Claude.
    @property
    def modelo(self) -> str:
        return _nombre_modelo(self.gpt)

    @property
    def descripcion(self) -> str:
        return (f"GPT {_nombre_modelo(self.gpt)} + Claude {_nombre_modelo(self.claude)}"
                f" · árbitro={self.arbitro} · arbitraje={self.arbitraje}")

    def _cliente_arbitro(self) -> ClienteIA:
        return self.gpt if self.arbitro in ("gpt", "openai", "azure_openai") else self.claude

    # ── Interfaz ClienteIA ──────────────────────────────────────────────────

    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        kw = dict(prompt=prompt, instruccion_sistema=instruccion_sistema,
                  max_tokens=max_tokens, sistema=sistema, formato_json=formato_json)

        respuestas, errores = {}, {}
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="virf_plus") as ex:
            futuros = {"gpt": ex.submit(self.gpt.generar_mensaje, **kw),
                       "claude": ex.submit(self.claude.generar_mensaje, **kw)}
            for nombre, fut in futuros.items():
                try:
                    respuestas[nombre] = fut.result()
                except Exception as exc:  # se reporta abajo, con el otro
                    errores[nombre] = f"{type(exc).__name__}: {exc}"
        if errores:
            raise RuntimeError(
                "❌ VIRF PLUS no pudo obtener las dos opiniones — "
                + " | ".join(f"{k.upper()}: {v}" for k, v in errores.items())
                + ". No se emite una conclusión conjunta con un solo evaluador; "
                  "corrige la credencial indicada o apaga VIRF PLUS.")

        # A = agente principal (GPT): si coinciden y no se arbitra, vale la suya.
        a, b = respuestas["gpt"], respuestas["claude"]
        comp = comparar_respuestas(a, b)

        if self.arbitraje == "discrepancia" and comp["acuerdo"]:
            final, arbitrado = a, False
        else:
            final = self._arbitrar(prompt, sistema or instruccion_sistema,
                                   a, b, comp, max_tokens, formato_json)
            arbitrado = True

        self._registrar(prompt, a, b, final, comp, arbitrado)
        return final

    def _arbitrar(self, prompt, sistema_original, a, b, comp,
                  max_tokens, formato_json) -> str:
        if comp["discrepancias"]:
            disc = "\n".join(f"  · {campo}: A={va!r}  ·  B={vb!r}"
                             for campo, (va, vb) in comp["discrepancias"].items())
        elif comp["json"]:
            disc = "  · Ninguna en los campos de decisión: concilia la redacción."
        else:
            disc = "  · Respuestas en texto libre: compáralas tú."

        prompt_arbitro = (
            "=== TAREA ORIGINAL (con su evidencia) ===\n"
            f"{prompt}\n\n"
            f"=== RESPUESTA DEL EVALUADOR A (GPT · {_nombre_modelo(self.gpt)}) ===\n"
            f"{a}\n\n"
            f"=== RESPUESTA DEL EVALUADOR B (Claude · {_nombre_modelo(self.claude)}) ===\n"
            f"{b}\n\n"
            "=== DISCREPANCIAS DETECTADAS EN CAMPOS DE DECISIÓN ===\n"
            f"{disc}\n\n"
            "=== TU TAREA ===\n"
            "Emite la respuesta FINAL conciliada, en el formato exacto que pide "
            "la tarea original.")
        sistema = ((sistema_original or "Eres un auditor experto.").strip()
                   + "\n\n" + INSTRUCCION_ARBITRO)
        try:
            return self._cliente_arbitro().generar_mensaje(
                prompt=prompt_arbitro, sistema=sistema,
                max_tokens=max_tokens, formato_json=formato_json)
        except Exception as exc:
            raise RuntimeError(
                f"❌ VIRF PLUS: el árbitro ({self.arbitro}) falló al conciliar — "
                f"{type(exc).__name__}: {exc}") from exc

    def _registrar(self, prompt, a, b, final, comp, arbitrado) -> None:
        registro = {
            "ts": datetime.now().isoformat(timespec="seconds"),
            "prompt_sha": hashlib.sha256(prompt.encode("utf-8", "ignore")).hexdigest()[:16],
            "modelos": {"gpt": _nombre_modelo(self.gpt),
                        "claude": _nombre_modelo(self.claude),
                        "arbitro": self.arbitro},
            "acuerdo": comp["acuerdo"],
            "discrepancias": comp["discrepancias"],
            "coinciden": comp["coinciden"],
            "arbitrado": arbitrado,
            "respuesta_gpt": a[:4000],
            "respuesta_claude": b[:4000],
            "conclusion": final[:4000],
        }
        self.ultimo_consenso = registro
        self.historial.append(registro)
        del self.historial[:-_MAX_HISTORIAL]
        try:
            self.ruta_log.parent.mkdir(parents=True, exist_ok=True)
            with _LOCK_LOG, self.ruta_log.open("a", encoding="utf-8") as f:
                f.write(json.dumps(registro, ensure_ascii=False, default=str) + "\n")
        except OSError as exc:
            # La bitácora es trazabilidad, no un requisito para evaluar.
            print(f"  ⚠️  VIRF PLUS: no se pudo escribir {self.ruta_log}: {exc}")

    def resumen(self) -> dict:
        """Totales de la sesión: cuántas llamadas, cuántas con discrepancia."""
        n = len(self.historial)
        con_disc = sum(1 for r in self.historial if not r["acuerdo"])
        return {"llamadas": n, "con_discrepancia": con_disc,
                "acuerdo_pct": round(100 * (n - con_disc) / n, 1) if n else None,
                "modelos": self.descripcion}

    def validar_conexion(self) -> bool:
        fallos = []
        for nombre, cli in (("Claude", self.claude), ("GPT", self.gpt)):
            if not cli.validar_conexion():
                fallos.append(f"{nombre}: {getattr(cli, 'ultimo_error_conexion', '')}")
        self.ultimo_error_conexion = " | ".join(fallos)
        return not fallos
