"""
config/rutas.py  [v27.2]
═════════════════════════════════════════════════════════════════════════════
Rutas del proyecto. Única fuente de verdad de dónde vive cada cosa.

⚠️ BASE_DIR se calcula con `parents[1]`, no con `.parent`: este fichero está
en config/, un nivel por debajo de la raíz. Cuando la configuración vivía en
config.py (en la raíz) bastaba `Path(__file__).parent`; al mover el módulo a un
paquete, ese cálculo habría apuntado a config/ y TODAS las rutas del proyecto
(inputs, outputs, caché, estándares) habrían quedado desplazadas un nivel.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

__all__ = [
    "BASE_DIR", "ESTANDARES_PATH", "OUTPUTS_DIR", "AUDIT_LOGS_DIR",
    "REPOSITORIO_INFORMES", "CACHE_DIR", "INPUTS",
    "nombre_seguro",
]


# Nombres reservados por Windows: un fichero llamado así falla aunque la ruta
# sea válida. No dependen de la extensión (CON.md también falla).
_RESERVADOS_WINDOWS = {
    "CON", "PRN", "AUX", "NUL",
    *{f"COM{i}" for i in range(1, 10)},
    *{f"LPT{i}" for i in range(1, 10)},
}


def nombre_seguro(bruto: str, defecto: str = "sin_nombre", max_len: int = 80) -> str:
    """
    Convierte un texto suministrado por el usuario en un nombre de fichero seguro.

    [AUDIT-FIX] `--titulo` y `--explicar-modelo` se interpolaban tal cual en la
    ruta de salida:

        outputs/<fecha>/resultados_{titulo}_{fecha}.json
        outputs/<fecha>/explicacion_del_modelo_{modelo}.md

    Verificado: `--explicar-modelo "../../../evil"` escribía FUERA de outputs/.
    Y un nombre con `/` apuntaba a un subdirectorio inexistente, fallando con
    FileNotFoundError tras haber pagado ya las llamadas al modelo.

    Qué hace, en orden:
      · se queda solo con el ÚLTIMO componente (mata `../` y `a/b/c`)
      · sustituye los caracteres ilegales en Windows  <>:"/\\|?*  y los de control
      · colapsa espacios y puntos al inicio/fin (Windows los recorta en silencio)
      · esquiva los nombres reservados del sistema
      · acota la longitud para no superar el límite de ruta
    """
    texto = str(bruto or "").strip()

    # Solo el último componente: elimina cualquier intento de travesía.
    texto = re.split(r"[\\/]", texto)[-1]

    # Caracteres prohibidos en Windows + control.
    texto = re.sub(r'[<>:"|?*\x00-\x1f]', "_", texto)

    # `..` no aporta nada como nombre y confunde.
    texto = texto.replace("..", "_")

    # Windows recorta espacios/puntos finales sin avisar: hacerlo explícito.
    texto = texto.strip(" .")

    texto = texto[:max_len].strip(" .")

    # Si tras el saneo no queda nada informativo (solo guiones bajos, guiones o
    # puntuación residual), es preferible el nombre por defecto a un fichero
    # llamado "_": el usuario no sabría a qué corrida corresponde.
    if not texto or not re.search(r"[0-9A-Za-zÁÉÍÓÚÜÑáéíóúüñ]", texto):
        return defecto
    if texto.upper() in _RESERVADOS_WINDOWS:
        return f"{texto}_"
    return texto

# config/rutas.py → config/ → raíz del proyecto
BASE_DIR = Path(__file__).resolve().parents[1]

ESTANDARES_PATH = BASE_DIR / "inputs" / "Estandares_VIRF.xlsx"
OUTPUTS_DIR = BASE_DIR / "outputs"
AUDIT_LOGS_DIR = BASE_DIR / "audit_logs"
REPOSITORIO_INFORMES = BASE_DIR / "repositorio_informes"

# Configurable por entorno (Mx_00 ya lo permitía; se conserva el mismo nombre).
CACHE_DIR = Path(os.getenv("CACHE_DIR", str(BASE_DIR / "data" / "cache")))
# [ARQUITECTURA 2026-07-31] Aquí vivía `VECTORDB_DIR` (y su `RAG_VECTORDB_DIR`).
# Se elimina: no queda base vectorial que ubicar. El RAG dejó de usar embeddings
# —el recurso Azure tiene un único deployment, de chat— y ChromaDB salió del
# proyecto porque arrastraba huggingface-hub por dependencia transitiva.
#
# La ruta del índice léxico que lo sustituye es `src/rag/config_rag.INDICE_DIR`
# (variable `RAG_INDICE_DIR`), y vive allí y no aquí porque `src/rag` debe poder
# usarse fuera del árbol del agente. Es una carpeta DISTINTA de `data/vectordb/`
# a propósito: si un índice ChromaDB antiguo compartiera ruta con los .pkl
# nuevos, sería cuestión de tiempo que uno pasara por el otro.
#
# `data/vectordb/` puede borrarse a mano; sigue en .gitignore por si queda de
# corridas anteriores.

INPUTS = {
    "doc_modelamiento": BASE_DIR / "inputs" / "documentacion" / "modelamiento",
    "doc_seguimiento": BASE_DIR / "inputs" / "documentacion" / "seguimiento",
    "papers": BASE_DIR / "inputs" / "papers",
    "calidad_datos": BASE_DIR / "inputs" / "calidad_datos",
    "implementacion": BASE_DIR / "inputs" / "implementacion",
    "usos": BASE_DIR / "inputs" / "usos",
    "repositorio": BASE_DIR / "repositorio_informes",
}
