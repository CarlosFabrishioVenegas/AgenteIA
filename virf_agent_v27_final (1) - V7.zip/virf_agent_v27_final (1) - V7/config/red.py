"""
config/red.py
═════════════════════════════════════════════════════════════════════════════
Capa de RED: proxy, inspección TLS y reintento ante cuota agotada.

[ARQUITECTURA 2026-07-30] Esto vivía en `config/ia.py`. Se extrajo al añadir los
embeddings por Azure, que necesitaban la capa de red sin poder importar
`config/ia.py`: se habría cerrado un ciclo, porque `config/ia.py` importa
`_extraer_json` de `modulos/motor_ia.py` — una inversión de capas (config es la
capa MÁS BAJA y no debería depender del negocio) que el ciclo dejó a la vista.

[2026-07-31] Los embeddings ya no existen: el RAG pasó a ser léxico (BM25 +
TF-IDF, sin red) y `config/embeddings.py` se eliminó. La extracción se mantiene
porque el ciclo que la motivó sigue ahí en potencia, y porque `config/red.py`
como capa aislada es lo correcto con independencia de quién la use.

Este módulo no importa nada del proyecto salvo `config.parametros`, así que
puede ser dependencia de cualquiera sin crear ciclos.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

__all__ = ["cliente_http", "con_reintento", "es_transitorio",
           "espera_sugerida", "diagnostico_https"]


# ═════════════════════════════════════════════════════════════════════════════
# RED CORPORATIVA — proxy e inspección TLS
# ═════════════════════════════════════════════════════════════════════════════
# [HTTPS-FIX 2026-07-30] Los SDK de ambos proveedores usan `httpx`, que verifica
# los certificados contra el bundle de **certifi**, NO contra el almacén de
# certificados de Windows.
#
# En una entidad con inspección TLS —el proxy descifra y vuelve a cifrar el
# tráfico firmando con una CA propia— eso produce el síntoma más desconcertante
# de toda la migración: **el endpoint abre en el navegador y el agente no
# conecta**. El navegador confía en la CA corporativa porque está en el almacén
# de Windows; Python no la ve.
#
# `HTTPS_PROXY` / `HTTP_PROXY` / `NO_PROXY` los respeta httpx solo. La CA no:
# hay que apuntarla explícitamente, y para eso hace falta construir el cliente
# HTTP nosotros y pasárselo al SDK.

def cliente_http():
    """
    Cliente `httpx` configurado para la red corporativa, o None si no hace falta.

    Devolver None es deliberado: sin configuración especial se deja que el SDK
    construya el suyo, que es el camino probado por el proveedor. Solo se
    interviene cuando hay algo que declarar.
    """
    from .parametros import CA_BUNDLE, HTTP_TIMEOUT, TLS_INSECURE

    if not CA_BUNDLE and not TLS_INSECURE and HTTP_TIMEOUT == 120:
        return None                     # nada que configurar: SDK por defecto

    try:
        import httpx
    except ImportError:                                   # pragma: no cover
        return None

    verify = True
    if TLS_INSECURE:
        # Grita, y sigue gritando en cada corrida. Una desactivación de TLS que
        # se olvida encendida es una fuga de credenciales y de la evidencia
        # íntegra del modelo por un canal interceptable.
        print("\n" + "!" * 74)
        print("  ⚠️  VERIFICACIÓN TLS DESACTIVADA (VIRF_TLS_INSECURE=1)")
        print("  El tráfico —credencial y evidencia del modelo— es interceptable.")
        print("  Úsalo SOLO para diagnosticar. NUNCA en una corrida real.")
        print("!" * 74 + "\n")
        verify = False
    elif CA_BUNDLE:
        ruta = Path(CA_BUNDLE)
        if not ruta.is_file():
            raise ValueError(
                f"❌ VIRF_CA_BUNDLE apunta a un fichero que no existe:\n"
                f"   {ruta}\n\n"
                f"   Debe ser el certificado de la CA corporativa en formato PEM.\n"
                f"   Pídeselo a IT: «el certificado raíz de la CA que usa el proxy\n"
                f"   para la inspección TLS, en formato .pem o .crt»."
            )
        # [HTTPS-FIX] `verify=<str>` está DEPRECADO en httpx 0.28 y dejará de
        # funcionar. Se construye el contexto SSL explícitamente, que además
        # permite diagnosticar un PEM corrupto aquí —con un mensaje útil— en vez
        # de fallar en la primera llamada como si fuera un problema de red.
        import ssl
        try:
            contexto = ssl.create_default_context(cafile=str(ruta))
        except ssl.SSLError as exc:
            raise ValueError(
                f"❌ VIRF_CA_BUNDLE no es un certificado PEM válido:\n"
                f"   {ruta}\n"
                f"   Detalle: {exc}\n\n"
                f"   Si IT te lo dio en formato DER/.cer binario, conviértelo:\n"
                f"   openssl x509 -inform DER -in ca.cer -out ca.pem"
            ) from exc
        verify = contexto
        print(f"  🔐 CA corporativa: {ruta.name}")

    return httpx.Client(verify=verify, timeout=float(HTTP_TIMEOUT))


def diagnostico_https(endpoint: str = "") -> str:
    """
    Explica un fallo de TLS/proxy en términos accionables.

    Se llama desde el manejador de errores: un `CERTIFICATE_VERIFY_FAILED` crudo
    no le dice al operador que el problema es el proxy de su propia empresa.
    """
    import os as _os
    from .parametros import CA_BUNDLE, TLS_INSECURE

    lineas = ["", "  🔍 DIAGNÓSTICO DE CONEXIÓN HTTPS", "  " + "─" * 60]
    proxy = _os.getenv("HTTPS_PROXY") or _os.getenv("HTTP_PROXY") or ""
    lineas.append(f"  Proxy detectado     : {proxy or '(ninguno)'}")
    lineas.append(f"  NO_PROXY            : {_os.getenv('NO_PROXY', '(vacío)')}")
    lineas.append(f"  CA corporativa      : {CA_BUNDLE or '(no configurada)'}")
    lineas.append(f"  Verificación TLS    : {'DESACTIVADA ⚠️' if TLS_INSECURE else 'activa'}")
    try:
        import certifi
        lineas.append(f"  Bundle por defecto  : certifi ({certifi.where()})")
    except ImportError:                                   # pragma: no cover
        pass
    lineas += [
        "  " + "─" * 60,
        "  Si el endpoint ABRE EN EL NAVEGADOR pero aquí falla, es la CA:",
        "  Python no lee el almacén de certificados de Windows.",
        "",
        "    1. Pide a IT el certificado raíz de la CA del proxy (.pem/.crt)",
        "    2. VIRF_CA_BUNDLE=C:\\ruta\\ca-corporativa.pem   en tu .env",
        "    3. python agente.py --verificar-conexion-azure",
        "",
        "  Para confirmar en 10 s que el problema ES el certificado:",
        "    VIRF_TLS_INSECURE=1 python agente.py --verificar-conexion-azure",
        "    (si así conecta, era la CA — vuelve a 0 y configura el bundle)",
        "",
    ]
    return "\n".join(lineas)


# ═════════════════════════════════════════════════════════════════════════════
# REINTENTO ANTE LÍMITE DE CUOTA
# ═════════════════════════════════════════════════════════════════════════════
# [AZURE 2026-07-30] La cuota de Azure es POR DEPLOYMENT (TPM/RPM) y la fija
# quien despliega, no la organización. El chunker hace hasta 40 llamadas
# seguidas para un manual grande, así que el 429 no es un caso excepcional: es
# lo esperable con un deployment de TPM modesto.
#
# Sin esto, ese 429 abortaba la corrida a mitad del chunking —con la extracción
# y las llamadas previas ya pagadas— y la actividad quedaba como fallo técnico.
#
# `REINTENTOS_API` estaba declarado en config/parametros.py desde hacía tiempo y
# NO LO LEÍA NADIE: un mando de configuración conectado a nada, que es peor que
# no ofrecerlo porque promete un control que no existe. Es el mismo defecto que
# el proyecto ya corrigió con RAG_TOP_K.
#
# ⚠️ Esto NO es un fallback entre proveedores —la política lo prohíbe—: es
# reintentar contra el MISMO proveedor, que es exactamente lo que la propia API
# pide al enviar `Retry-After`.
_ERRORES_TRANSITORIOS = ("429", "503", "rate limit", "too many requests",
                         "temporarily unavailable", "server_error")


def es_transitorio(exc: Exception) -> bool:
    texto = str(exc).lower()
    return any(marca in texto for marca in _ERRORES_TRANSITORIOS)


def espera_sugerida(exc: Exception, intento: int) -> float:
    """
    Segundos a esperar. Prefiere el `Retry-After` del servidor.

    El jitter aleatorio evita que varias corridas simultáneas reintenten en el
    mismo instante y vuelvan a saturar la cuota — el problema del rebaño.
    """
    import random
    for attr in ("retry_after", "retry_after_ms"):
        valor = getattr(exc, attr, None)
        if valor:
            try:
                seg = float(valor)
                return seg / 1000.0 if attr.endswith("_ms") else seg
            except (TypeError, ValueError):
                pass
    resp = getattr(exc, "response", None)
    cabeceras = getattr(resp, "headers", None) or {}
    try:
        if "retry-after" in {k.lower() for k in cabeceras}:
            for k, v in cabeceras.items():
                if k.lower() == "retry-after":
                    return float(v)
    except (TypeError, ValueError):
        pass
    return min(2 ** intento + random.random(), 60.0)


def con_reintento(fn, intentos: Optional[int] = None):
    """Ejecuta `fn`, reintentando ante errores transitorios de cuota."""
    import time
    from .parametros import REINTENTOS_API
    total = intentos if intentos is not None else REINTENTOS_API
    total = max(1, int(total))
    ultimo = None
    for i in range(total):
        try:
            return fn()
        except Exception as exc:                      # noqa: BLE001
            ultimo = exc
            if not es_transitorio(exc) or i == total - 1:
                raise
            espera = espera_sugerida(exc, i)
            print(f"  ⏳ Cuota del proveedor agotada ({type(exc).__name__}): "
                  f"reintento {i + 1}/{total - 1} en {espera:.1f}s")
            time.sleep(espera)
    raise ultimo                                       # pragma: no cover


