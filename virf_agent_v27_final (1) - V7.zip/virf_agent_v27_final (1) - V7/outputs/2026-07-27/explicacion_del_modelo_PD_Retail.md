<!-- Generado por agente.py --explicar-modelo PD_Retail -->
<!-- 2026-07-27 16:59 — no editar a mano: se regenera desde inputs/ -->

> **Trazabilidad.** Documento generado automáticamente a partir de la evidencia en `inputs/`. Cada afirmación debe poder rastrearse a uno de estos ficheros.

| Fuente | Ruta | Estado | Ficheros | Chars |
|---|---|---|---|---:|
| Manual metodológico | `inputs/documentacion/modelamiento` | ✅ con evidencia | `manual_metodologico_PD_Retail.md` | 1,411 |
| Manual e informes de seguimiento | `inputs/documentacion/seguimiento` | ✅ con evidencia | `informe_seguimiento_PD_Retail_2026H1.md` | 671 |
| Implementación | `inputs/implementacion` | ✅ con evidencia | `implementacion_PD_Retail.py` | 1,344 |
| Motor de datos y controles de calidad | `inputs/calidad_datos` | ✅ con evidencia | `perfil_datos_PD_Retail.md`, `solicitudes_muestra.csv` | 1,120 |

---

# Explicación del Modelo: PD_Retail

## 1. Resumen en una página

### Qué es
El modelo **PD_Retail** es un scorecard de probabilidad de incumplimiento que estima la likelihood de que un cliente de banca personas entre en mora mayor a 90 días dentro de 12 meses desde la fecha de originación de su crédito. (Manual metodológico, §1)

### Problema de negocio que resuelve
En el proceso de originación de créditos de consumo, la institución debe decidir en segundos si aprobar o rechazar una solicitud, minimizando riesgo de pérdida. Una decisión binaria (aprobar/rechazar) requiere un criterio cuantitativo y consistente. PD_Retail proporciona ese criterio: un puntaje entre 0 y 1000 que expresa riesgo, y una regla mecánica de decisión (Score ≥ 580 = APROBAR; Score < 580 = RECHAZAR).

### Quién lo usa y para qué decisión
- **Usuario primario**: Área de originación (decisión automatizada de solicitudes).  
- **Usuario secundario**: Gerencia de Riesgo Retail (supervisión, seguimiento de poder discriminante, recalibraciones periódicas).  
- **Decisión**: Aprobar o rechazar una solicitud de crédito de consumo en el acto.  
- **Métrica de éxito**: Que el score refleje fielmente el riesgo real del cliente, de modo que clientes con score alto incumplan menos que clientes con score bajo.

### Entrada y salida
**Entrada**: Datos del cliente en el momento de la solicitud (edad, ingreso declarado, antigüedad laboral, historial crediticio en central de riesgo, número de entidades con deuda).  
**Salida**: Score en puntos (0–1000), probabilidad estimada de incumplimiento (PD, 0–1), y decisión binaria (APROBAR/RECHAZAR).

### Contexto normativo
El modelo es parte del marco de gestión de riesgo de crédito de la institución. Fue aprobado por Comité de Modelos el 2025-11-20 y tiene una vigencia operativa de 24 meses entre recalibraciones. (Informe seguimiento, §6)

---

## 2. Marco metodológico

### Arquitectura conceptual: Scorecard con regresión logística y Weight of Evidence

El modelo utiliza **regresión logística binaria** sobre variables transformadas mediante **Weight of Evidence (WOE)**. Esta arquitectura es estándar en riesgo crediticio retail porque:

1. Transforma variables heterogéneas (continuas, categóricas, discretas) a una escala común (WOE) interpretable como "poder discriminante per variable".  
2. Produce una probabilidad calibrada (PD) entre 0 y 1 que respeta axiomas de probabilidad.  
3. Permite auditoría y ajuste manual de coeficientes sin reentrenamiento (capacidad reglamentaria importante).

### Fórmula central

Según el Manual metodológico (§2), el modelo calcula:

$$\text{logit}(\text{PD}) = \beta_0 + \sum_i \beta_i \cdot \text{WOE}_i(x_i)$$

donde:
- $\beta_0$ es el intercepto (calibración del nivel base de riesgo).  
- $\beta_i$ es el coeficiente de la variable $i$ (impacto relativo en el logit).  
- $\text{WOE}_i(x_i)$ es el Weight of Evidence del valor observado $x_i$ en la variable $i$.

La **probabilidad estimada de incumplimiento** es:

$$\text{PD} = \frac{1}{1 + e^{-\text{logit}(\text{PD})}}$$

### Transformación WOE: Qué, cómo, por qué

**QUÉ hace en términos de negocio:**  
Convierte cada valor de una variable original (edad, ingreso, situación en central de riesgo) en un número que expresa cuánto diferencia ese valor el riesgo respecto a la población media.

**CÓMO técnicamente:**  
Se calcula así:

$$\text{WOE} = \ln\left(\frac{\% \text{ eventos en bin}}{\% \text{ no-eventos en bin}}\right)$$

donde:
- "Eventos" = clientes que incumplieron (incumplio_90d = 1).  
- "No-eventos" = clientes que no incumplieron (incumplio_90d = 0).  
- Cada variable continua o discreta se divide en **bins** (rangos) definidos en desarrollo.  
- Cada variable categórica usa sus categorías originales como bins.

**Ejemplo numérico** (de solicitudes_muestra.csv):  
Supongamos que en la muestra de desarrollo (84,500 solicitudes, 4.2% eventos = ~3,549 incumplimientos):
- Bin "Ingreso 2000–3000": 2,400 solicitudes, 84 eventos, 2,316 no-eventos.  
  - % eventos en bin = 84 / 3,549 ≈ 2.37%.  
  - % no-eventos en bin = 2,316 / 81,451 ≈ 2.84%.  
  - WOE = ln(2.37% / 2.84%) = ln(0.835) ≈ **−0.18**.

Un WOE negativo indica que ese rango de ingreso tiene **menor riesgo** que la media.

**POR QUÉ:**  
El WOE es simétrico (positivo para riesgo alto, negativo para riesgo bajo), log-normal (evita asimetrías extremas) y separable: cada bin contribuye independientemente, facilitando auditoría y ajuste manual. (Manual metodológico, §2 justifica el enfoque como "regresion logistica con variables transformadas mediante WOE".)

### Selección de variables: Information Value (IV)

**Criterio documentado** (Manual metodológico, §2):  
Se retienen únicamente variables con **IV entre 0.02 y 0.5**. El IV de una variable se calcula como:

$$\text{IV} = \sum_{\text{bins}} (\% \text{ eventos} - \% \text{ no-eventos}) \times \text{WOE}$$

donde la suma corre sobre todos los bins de la variable.

**Interpretación:**
- IV < 0.02: poder discriminante negligible, excluir.  
- 0.02 ≤ IV ≤ 0.5: rango óptimo, retener.  
- IV > 0.5: overfitting o multicolinealidad probable, excluir.

**Variables retenidas** (Manual metodológico, §3):

| Variable | IV | Interpretación |
|---|---|---|
| Peor situación 12m en central de riesgo | 0.42 | Altamente discriminante |
| Antigüedad laboral | 0.31 | Discriminante |
| Ingreso mensual declarado | 0.24 | Discriminante moderado |
| Número de entidades con deuda vigente | 0.18 | Débilmente discriminante |
| Edad del titular | 0.06 | Muy débil, límite de retención |

**⚠️ Punto a cuestionar**: El manual no documenta cómo se decidió incluir la variable "Edad" (IV = 0.06, cercana al piso de 0.02). ¿Fue requisito regulatorio, lógica de negocio o criterio ad-hoc? No está justificado en las fuentes.

### Transformación de logit a score en puntos

**QUÉ:** Convierte el logit (número entre −∞ y +∞) a un puntaje entre 0 y 1000, más interpretable para las áreas de negocio. (Implementacion_PD_Retail.py, función `calcular_score`.)

**CÓMO:**

$$\text{Score} = \text{Offset} + \text{Factor} \times \ln(\text{odds})$$

donde:

$$\text{odds} = \frac{1 - \text{PD}}{\text{PD}}$$

y según Manual metodológico §2:
- **Factor** = 20 / ln(2) ≈ **28.8539** (implementación confirma este valor).  
- **Offset** = **600** puntos (calibrado a odds 50:1).

**Interpretación del offset:**  
Cuando PD = 1/51 ≈ 1.96% (odds = 50:1), el score es exactamente 600 puntos. Este es el punto de referencia de la escala.

**Ejemplo numérico:**  
Si el logit calculado es 0:
- PD = 1 / (1 + e^0) = 0.5.  
- odds = (1 − 0.5) / 0.5 = 1.0.  
- ln(1.0) = 0.  
- Score = 600 + 28.8539 × 0 = **600 puntos**.

Si logit = 0.5:
- PD = 1 / (1 + e^−0.5) ≈ 0.622.  
- odds ≈ 0.608.  
- ln(0.608) ≈ −0.500.  
- Score = 600 + 28.8539 × (−0.500) ≈ **585.6 puntos**.

Un logit positivo (más riesgo) lleva a un PD más alto, odds más bajo, y score más bajo.

**POR QUÉ este formato:**  
El factor 20/ln(2) es convención de banca retail: cada 20 puntos de score representa un cambio de 2:1 en la razón de odds. Facilita comunicación con comercial. (Manual metodológico, §2.)

### Punto de corte: Decisión automatizada

**Criterio documentado** (Manual metodológico, §4):  
Se aprueban solicitudes con **Score ≥ 580 puntos**; se rechazan automáticamente aquellas con Score < 580.

**QUÉ:** Transforma un score continuo en una decisión binaria.

**CÓMO:** Comparación simple: if score ≥ 580 then "APROBAR" else "RECHAZAR". (Implementacion_PD_Retail.py, función `decidir`.)

**⚠️ Punto a cuestionar:** El manual no justifica por qué 580 en particular. ¿Se derivó de:
- Análisis de costes de error (coste de falso negativo vs. falso positivo)?  
- Restricción de tasa de aprobación objetivo (p. ej., "aprobar 70% de solicitudes")?  
- Calibración a métricas de negocio (margen esperado)?

Sin esta justificación, el corte es **heredado o arbitrario**, no basado en criterio explícito. Esto es un riesgo operacional: si circunstancias cambian (p. ej., durante una crisis crediticia), no hay método documentado para reoptimizarlo.

### Marco normativo y aprobación

El modelo está alineado con:
- **Regresión logística binaria**: estándar en IFRS 9 para estimación de PD (aunque las fuentes no lo citan explícitamente).  
- **Aprobación:** Comité de Modelos, 2025-11-20. (Informe seguimiento, §6.)  
- **Recalibraciones:** Previstas cada 24 meses. Próxima: 2027-11. (Manual metodológico, §6.)

⚠️ **Sin evidencia en fuentes:** No hay referencia a normativas específicas como SR 11-7 (Federal Reserve guidance on model risk), Basel III Pillar 1, o BCBS 239 (Principles on Sound Practices of Liquidity Risk). El modelo asume conformidad pero no la documenta.

---

## 3. El motor de datos — de dónde vienen los números

### Fuentes de datos

El modelo consume datos de tres fuentes (Perfil de Datos, §1):

| Fuente | Propósito | Frecuencia | Responsable (inferido) |
|---|---|---|---|
| **Core de originación (Oracle)** | Solicitud, decisión final, dato de supervisión (incumplio_90d) | Cada solicitud | Área de Operaciones |
| **Central de riesgo externa** | Situación crediticia del cliente (categoría "peor_situacion_12m") | Actualización mensual | Equipo de Inteligencia de Negocios |
| **Declaración del cliente** | Ingreso mensual y antigüedad laboral auto-reportados | En originación | El propio cliente (en formulario) |

**Temporalidad:**  
- **Ventana de desarrollo:** Originaciones entre 2023-01 y 2024-06. (Manual metodológico, §5.)  
- **Tamaño:** 84,500 solicitudes. (Manual metodológico, §5.)  
- **Tasa de eventos:** 4.2% incumplieron a 90+ días. (Perfil de Datos, §2.)

### Calidad de datos: Controles y tolerancias

El Perfil de Datos (§3) documenta cuatro chequeos ejecutados diariamente (inferred: pre-ejecución del modelo batch).

#### Control 1: Missing en ingreso declarado

**QUÉ verifica:**  
Proporción de solicitudes sin valor en el campo "ingreso_mensual".

**Resultado:**  
**ADVERTENCIA**. Tasa: **6.1%**. (Perfil de Datos, §3.)

**Tolerancia:**  
No explícita. Una tasa del 6.1% de missing se clasifica como "ADVERTENCIA" (no OK, pero no alerta bloqueante).

**Qué pasa si falla:**  
⚠️ **Sin especificación en fuentes.** El procedimiento de imputación se describe abajo, pero no hay regla "si missing > X%, detener ejecución" documentada.

**Frecuencia de control:**  
⚠️ **Sin especificación en fuentes.** Se infiere ejecución diaria (batch diario, Implementacion_PD_Retail.py preamble), pero no hay SLA explícito.

**Método de tratamiento:**  
Se imputa con **la media del segmento**. (Perfil de Datos, §2.)

**Cómo técnicamente:**  
```python
df = df.fillna(df.mean(numeric_only=True))  # Implementacion, función ejecutar
```

Para cada variable numérica con missing, se reemplaza el valor faltante por la media de esa variable en la muestra del día.

**Ejemplo numérico:**  
Muestra de solicitudes_muestra.csv (S000006 tiene ingreso_mensual = NaN, otros 9 tienen valores 1450–8900):
- Media de ingreso (excluidos NaN) = (4200 + 2100 + 8900 + 1450 + 6300 + 3100 + 5200 + 2750 + 7100) / 9 ≈ 4,788.9.  
- S000006 recibe ingreso_mensual = 4,788.9.

**POR QUÉ imputación por la media:**  
⚠️ **Sin justificación documentada.** La media es el estimador BLUE bajo supuestos MCAR (Missing Completely At Random), pero:
- ¿Se contrastó que el patrón es MCAR, MAR o MNAR?  
- ¿Se consideraron alternativas (mediana, imputación múltiple, modelo predictivo)?  
- ¿Se documentó el sesgo introducido?

Estas preguntas quedan sin respuesta. Esto es un riesgo: si los missing no son MCAR (p. ej., clientes de ingreso bajo omiten reportar), la media sobrestima el ingreso verdadero, sesgando al scorecard hacia menor riesgo.

#### Control 2: Missing en antigüedad laboral

**QUÉ verifica:**  
Proporción de solicitudes sin valor en "antiguedad_laboral_meses".

**Resultado:**  
**ADVERTENCIA**. Tasa: **4.8%**.

**Tolerancia, tratamiento, frecuencia:**  
Igual que ingreso: sin especificación de umbral, imputación por media del segmento (inferred), ejecución diaria.

#### Control 3: Duplicados por solicitud

**QUÉ verifica:**  
¿Existen dos registros con identical solicitud_id?

**Resultado:**  
**OK**. Tasa: **0%**.

**Tolerancia:**  
Implícita: tolerancia 0 (no se aceptan duplicados).

**Qué pasa si falla:**  
⚠️ **Sin especificación en fuentes.** Se infiere rechazo de la corrida, pero no está documentado.

**Frecuencia:**  
Diaria (inferred).

#### Control 4: Categorías no mapeadas en central de riesgo

**QUÉ verifica:**  
¿Existen valores en la variable "peor_situacion_12m" que no están en el diccionario de bins de desarrollo?

**Resultado:**  
**ALERTA**. Tasa: **2.3%**. (Perfil de Datos, §3.)

**Tolerancia:**  
No explícita. Una tasa del 2.3% se clasifica como "ALERTA" (más grave que "ADVERTENCIA", pero aún así la corrida continúa).

**Qué pasa si ocurre:**  
Se asignan al bin **"sin información"** (Perfil de Datos, §2). Este bin tiene un WOE predefinido (calibrado en desarrollo); las solicitudes nuevas con categorías no mapeadas reciben ese WOE.

**Cómo técnicamente:**  
```python
df[var + "_woe"] = pd.cut(df[var], bins=bins["cortes"],
                          labels=bins["woe"]).astype(float)
```
(Implementacion, función `aplicar_woe`.) Si un valor cae fuera de los bins definidos, `pd.cut` lo asigna a NaN, que luego se imputa (presumiblemente al WOE del bin "sin información" o a la media de WOE).

⚠️ **Punto a cuestionar:** El código usa `pd.cut` sin especificar `right=False` o `right=True`, ni cómo se tratan los NaN tras binning. El comportamiento exacto de asignación al bin "sin información" no está en el código visible.

**POR QUÉ ocurre:**  
Según Informe seguimiento, §4.3: "La variable 'Peor situacion 12m' perdio poder predictivo tras el cambio de reporte de la central de riesgo en 2025-09." El cambio introdujo nuevas categorías que no estaban en el binning de desarrollo (2023-01 a 2024-06). Este es un ejemplo de **deriva poblacional**: la distribución de datos en producción divergió de la del desarrollo.

**Frecuencia:**  
Diaria (inferred).

### Transformaciones de datos antes del modelo

El flujo es (Implementacion_PD_Retail.py, función `ejecutar`):

1. **Lectura:** `pd.read_csv(ruta_solicitudes)` — carga el archivo de solicitudes del día.

2. **Imputación de missing:**  
   ```python
   df = df.fillna(df.mean(numeric_only=True))
   ```
   Reemplaza NaN en variables numéricas por su media (ver Control 1 arriba).

3. **Binning y transformación WOE:**  
   ```python
   df = aplicar_woe(df, mapa_woe)
   ```
   Para cada variable en el scorecard:
   - Asigna el valor a un bin (usando límites definidos en desarrollo).  
   - Reemplaza el valor original por el WOE del bin.
   
   **Ejemplo:** Si antiguedad_laboral_meses = 72:
   - Bin asignado (del mapa_woe de desarrollo): "60–120 meses".  
   - WOE de ese bin: +0.15 (ejemplo).  
   - df["antiguedad_laboral_meses_woe"] = 0.15.

4. **Cálculo del logit y score:**  
   ```python
   df = calcular_score(df, coeficientes)
   ```
   - Combina WOE con coeficientes: logit = β₀ + Σᵢ βᵢ × WOEᵢ.  
   - Transforma a PD: PD = 1 / (1 + e^−logit).  
   - Transforma a score: Score = 600 + 28.8539 × ln(odds).  
   - Almacena: df["score"] y df["pd"].

5. **Regla de decisión:**  
   ```python
   df = decidir(df, corte=580)
   ```
   - if df["score"] >= 580: "APROBAR" else "RECHAZAR".
   - Almacena: df["decision"].

6. **Salida:** Dataframe con columnas originales + score + pd + decision.

### Representatividad, frescura y trazabilidad de datos

**Representatividad de la muestra de desarrollo:**  
La muestra cubre originaciones entre enero 2023 y junio 2024 (18 meses). Esto incluye:
- Ciclo de crecimiento post-pandemia (2023).  
- Ciclo de volatilidad macroeconómica (2024 H1).

⚠️ **Punto a cuestionar:** ¿Cubre un ciclo crediticio completo? Un ciclo típico es 5–7 años. 18 meses no es suficiente para capturar una crisis severa. Si ocurre una recesión profunda post-2024-06, el modelo puede subestimar riesgo. No hay evidencia de stress testing o análisis de sensibilidad a ciclos extremos en las fuentes.

**Frescura de datos en producción:**  
- **Datos de originación** (edad, ingreso, antigüedad): actualizados en tiempo real (cada solicitud).  
- **Datos de central de riesgo**: actualizados mensualmente, con rezago de ~1 mes respecto a la transacción del cliente. ⚠️ **Sin especificación en fuentes** del rezago exacto.
- **Decisión de supervisión** (incumplio_90d): observada 12 meses + 90 días después de originación. Rezago: ~15 meses.

⚠️ **Punto a cuestionar:** Mientras se espera 15 meses para saber si una solicitud incumplió, el modelo sigue prediciendo en producción. ¿Con qué frecuencia se revalida el modelo contra datos observados reales? Las fuentes no lo especifican. Es estándar hacerlo mensual o trimestral, pero aquí no está documentado.

**Trazabilidad:**  
```python
# Implementacion: outputs
df.to_csv("resultados_" + timestamp + ".csv")
```
Se infiere que cada corrida batch genera un archivo con timestamp, permitiendo auditoría. Pero el código no está completo; no hay especificación de qué columnas se guardan, dónde, o cómo se vincula un resultado a una solicitud específica meses después. ⚠️ **Sin evidencia en fuentes**.

### Resumen de riesgos de calidad de datos

| Riesgo | Severidad | Evidencia |
|---|---|---|
| Imputación por media sin diagnóstico MCAR/MAR/MNAR | Media | Perfil Datos §2; falta justificación |
| Nuevas categorías en central de riesgo (2025-09) sin recalibracion | Alta | Informe seguimiento §4.3; derivó en deterioro discriminante |
| Ausencia de umbral de detención para tasas de missing | Media | Perfil Datos no especifica SLA |
| Falta de validación periódica contra incumplio_90d observado | Alta | ⚠️ Sin evidencia en fuentes |
| Muestra de desarrollo no cubre ciclos económicos extremos | Media | Manual metodológico §5; 18 meses es corto |

## 4. El modelo — función por función

La implementación contenida en `implementacion_PD_Retail.py` consta de cuatro funciones encadenadas. No hay arquitectura de microservicios ni componentes externos documentados; se trata de un flujo batch linear.

### `aplicar_woe(df, mapa_woe)`

**Qué hace (negocio):**  
Transforma cada variable continua o categórica de la solicitud en un número (Weight of Evidence) que mide qué tan discriminante es ese valor para predecir incumplimiento.

**Cómo lo hace técnicamente:**  
Toma un diccionario `mapa_woe` donde cada variable tiene asociados:
- `"cortes"`: los límites del binning (p. ej. `[0, 12, 24, 60, 300]` para antiguedad laboral en meses).
- `"woe"`: los valores WOE etiquetados para cada bin (p. ej. `[0.45, 0.12, -0.08, -0.25]`).

La función ejecuta:
```python
df[var + "_woe"] = pd.cut(df[var], bins=bins["cortes"],
                          labels=bins["woe"]).astype(float)
```

Agrupa cada valor de `var` en su bin correspondiente y asigna directamente el WOE precalculado. Retorna el DataFrame con nuevas columnas `{var}_woe`.

**Por qué se hizo así:**  
El manual metodológico (sección 2) especifica que el scorecard usa **Weight of Evidence (WOE)** como transformación de variables, derivada de regresión logística. El WOE se calcula en desarrollo sobre los datos históricos 2023–2024 y se congela en `mapa_woe` para aplicar sin reentrenamiento. Esto garantiza estabilidad y reproducibilidad en producción.

**Ejemplo numérico:**  
Solicitud S000001 (antiguedad_laboral_meses = 48):
- `mapa_woe["antiguedad_laboral"]["cortes"]` = `[0, 12, 24, 60, 300]`
- `mapa_woe["antiguedad_laboral"]["woe"]` = `[0.45, 0.12, -0.08, -0.25]`
- 48 cae en el bin `[24, 60)` → WOE asignado: `-0.08`
- Nueva columna: `antiguedad_laboral_woe = -0.08`

---

### `calcular_score(df, coeficientes, offset=600.0, factor=28.8539)`

**Qué hace (negocio):**  
Suma el aporte de cada variable transformada según su poder predictivo, lo convierte en una probabilidad de incumplimiento y finalmente lo expresa como un puntaje (número entre 300 y 900) que es fácil de comunicar a los originadores.

**Cómo lo hace técnicamente:**  
Implementa la fórmula documentada en el manual (sección 2):

1. **Cálculo del logit:**
```python
logit = coeficientes["intercepto"]
for var, beta in coeficientes["betas"].items():
    logit += beta * df[var + "_woe"]
```
Suma el intercepto (β₀) con todos los términos β_i × WOE_i. Ejemplo con dos variables:
```
logit = -0.15 + (0.85 × antiguedad_laboral_woe) + (1.20 × ingreso_mensual_woe)
```

2. **Conversión logit → probabilidad:**
```python
pd_estimada = 1.0 / (1.0 + np.exp(-logit))
```
Aplica la función logística: PD = 1 / (1 + e^(-logit))

3. **Cálculo de odds y escalado a puntos:**
```python
odds = (1 - pd_estimada) / pd_estimada
df["score"] = offset + factor * np.log(odds)
```
Convierte PD en odds (p. ej. PD = 0.04 → odds = 24), toma logaritmo y lo escala.  
`Factor = 28.8539` coincide con el manual (Factor = 20 / ln(2) ≈ 28.854).  
`Offset = 600` calibra la escala: odds 50:1 → Score 600 (manual sección 2).

4. **Salida:**
```python
df["pd"] = pd_estimada
```

**Por qué se hizo así:**  
La regresión logística es el modelo documentado. El WOE normaliza variables heterogéneas en una escala común. La transformación a puntos es estándar en banca retail para que los decisores humanos usen un número familiar (p. ej. "aprobar si Score ≥ 580") en lugar de probabilidades brutas.

**Ejemplo numérico:**  
Solicitud S000001 tras `aplicar_woe()`:
- `antiguedad_laboral_woe = -0.08`
- `ingreso_mensual_woe = 0.15`
- `peor_situacion_12m_woe = -0.05`
- `entidades_con_deuda_woe = 0.22`

Coeficientes (asumidos):
```
intercepto = -0.15
betas = {
  "antiguedad_laboral": 0.85,
  "ingreso_mensual": 1.20,
  "peor_situacion_12m": 0.65,
  "entidades_con_deuda": 0.40
}
```

Cálculo:
```
logit = -0.15 + (0.85 × -0.08) + (1.20 × 0.15) + (0.65 × -0.05) + (0.40 × 0.22)
      = -0.15 - 0.068 + 0.18 - 0.0325 + 0.088
      = 0.0365

pd_estimada = 1 / (1 + e^(-0.0365)) = 1 / (1 + 0.9642) = 0.509

odds = (1 - 0.509) / 0.509 = 0.491 / 0.509 ≈ 0.965

score = 600 + 28.8539 × ln(0.965)
      = 600 + 28.8539 × (-0.0356)
      = 600 - 1.03
      ≈ 598.97 ≈ 599
```

Salida: `score = 599`, `pd = 0.509` (50.9% de probabilidad de mora en 12 meses).

---

### `decidir(df, corte=580)`

**Qué hace (negocio):**  
Aplica la regla de negocio: compara el score contra el umbral aprobado y emite una decisión binaria (APROBAR o RECHAZAR).

**Cómo lo hace técnicamente:**
```python
df["decision"] = np.where(df["score"] >= corte, "APROBAR", "RECHAZAR")
```

Si `score ≥ 580` → "APROBAR"; en caso contrario → "RECHAZAR".

**Por qué se hizo así:**  
El manual metodológico (sección 4) establece que "Se aprueban solicitudes con Score >= 580". Este punto de corte es explícitamente una decisión de negocio (governance), no derivada estadísticamente en la fuente disponible.

⚠️ **Punto a cuestionar:** El manual no documenta la justificación de por qué 580 específicamente. ¿Se eligió por criterio de costes de error (falsos positivos vs. falsos negativos), por tasas de aprobación objetivo, o por precedente? El informe de seguimiento (sección 2) reporta que la tasa de aprobación subió de 61% a 73% sin cambio en el corte, lo que sugiere una deriva poblacional. Ver sección 7.

**Ejemplo numérico:**  
- Solicitud S000001: `score = 599` → `decision = "APROBAR"`
- Solicitud S000004 (teórica, score hipotético 575): `decision = "RECHAZAR"`

---

### `ejecutar(ruta_solicitudes, mapa_woe, coeficientes)`

**Qué hace (negocio):**  
Orquesta toda la línea de producción: lee las solicitudes del día, las preprocesa, las puntúa y emite decisiones. Es el punto de entrada del batch diario.

**Cómo lo hace técnicamente:**
```python
def ejecutar(ruta_solicitudes, mapa_woe, coeficientes):
    df = pd.read_csv(ruta_solicitudes)                    # Carga
    df = df.fillna(df.mean(numeric_only=True))            # Imputación
    df = aplicar_woe(df, mapa_woe)                        # Transformación
    df = calcular_score(df, coeficientes)                 # Scoring
    return decidir(df)                                    # Decisión
```

**Imputación de missing values:**  
La llamada `df.fillna(df.mean(numeric_only=True))` reemplaza cada valor faltante en columnas numéricas con la media de esa columna.

El perfil de datos (fichero `perfil_datos_PD_Retail.md`) reporta:
- Missing en ingreso declarado: 6.1%
- Missing en antiguedad laboral: 4.8%
- Observación: "El 6.1% de missing en ingreso se imputa con la media del segmento."

⚠️ **Discrepancia:** La fuente de implementación imputa con media global (`df.mean()`), no con "media del segmento". Si el segmento hace referencia a subgrupos (p. ej. por edad, sector laboral), la implementación no lo hace.

⚠️ **Punto a cuestionar:** No se documenta el clasificación del patrón de missing (MCAR/MAR/MNAR, Falta Completamente al Azar / Falta al Azar / Falta No al Azar). Imputar por la media es una opción simple pero sesgada si el missing depende de factores no observables.

**Por qué se hizo así:**  
La simplificación por media es computacionalmente eficiente y reproducible. Sin embargo, no hay justificación teórica en las fuentes.

**Ejemplo con datos reales:**  
Solicitud S000006 (edad=39, ingreso_mensual=NaN, antiguedad_laboral=72, ...):
- Media de ingreso (calculada sobre S000001, S000002, S000003, ..., excluyendo S000006):
  `(4200 + 2100 + 8900 + 1450 + 6300 + 3100 + 5200 + 2750 + 7100) / 9 ≈ 4678`
- Resultado: S000006 recibe `ingreso_mensual = 4678` (media muestral).
- Continúa con las demás funciones normalmente.

---

**Encadenamiento:**  
1. `ejecutar()` → lee CSV
2. `ejecutar()` → imputa media
3. `aplicar_woe()` → mapea a WOE según binning congelado
4. `calcular_score()` → regresión logística + escalado a puntos [300–900]
5. `decidir()` → binario APROBAR/RECHAZAR
6. Retorna DataFrame con columnas: `score`, `pd`, `decision`

---

## 5. Flujo completo — de principio a fin

```
┌─────────────────────────────────────────────────────────────────────┐
│                    FLUJO PD_RETAIL END-TO-END                       │
└─────────────────────────────────────────────────────────────────────┘

FUENTE DE DATOS
───────────────
  ├─ Oracle (core de originación)
  │  └─→ solicitud_id, edad, ingreso_mensual, antiguedad_laboral_meses,
  │      peor_situacion_12m, entidades_con_deuda
  │
  ├─ Central de Riesgo Externa
  │  └─→ peor_situacion_12m (actualizado mensualmente)
  │
  └─ Declaración del cliente
     └─→ ingreso_mensual, antiguedad_laboral_meses


                            LOTE DIARIO CSV
                                  │
                                  ▼
┌─────────────────────────────────────────────────────┐
│  [ejecutar()]  Leo CSV                              │
│  → pd.read_csv(ruta_solicitudes)                    │
│  Salida: DataFrame con filas = solicitudes          │
└─────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────┐
│  [ejecutar()]  Imputo missing                       │
│  → df.fillna(df.mean(numeric_only=True))            │
│  Método: Media global por columna                   │
│  Afectadas: ingreso (6.1%), antiguedad (4.8%)       │
│  Salida: DataFrame sin NaN en numéricas             │
└─────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────┐
│  [aplicar_woe()]  Transformo variables              │
│  → pd.cut() + mapeo WOE precongelado                │
│                                                      │
│  Ejemplo para antiguedad_laboral:                   │
│    Valor original: 48 meses                         │
│    Bin: [24, 60)   → WOE: -0.08                     │
│    Nueva columna: antiguedad_laboral_woe = -0.08    │
│                                                      │
│  Se repite para:                                    │
│    - Antiguedad laboral (IV = 0.31)                 │
│    - Ingreso mensual (IV = 0.24)                    │
│    - Peor situacion 12m (IV = 0.42)                 │
│    - Num. entidades con deuda (IV = 0.18)           │
│    - Edad (IV = 0.06)                               │
│                                                      │
│  Salida: DataFrame + 5 columnas nuevas *_woe        │
└─────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────┐
│  [calcular_score()]  Regresión logística             │
│                                                      │
│  1. Logit = β₀ + Σᵢ βᵢ × WOEᵢ                       │
│     Ejemplo:                                         │
│     = -0.15                                          │
│       + (0.85 × -0.08)  [antiguedad]                │
│       + (1.20 × 0.15)   [ingreso]                   │
│       + (0.65 × -0.05)  [situacion]                 │
│       + (0.40 × 0.22)   [entidades]                 │
│     = 0.0365                                         │
│                                                      │
│  2. PD = 1 / (1 + e^(-logit))                       │
│     = 1 / (1 + e^(-0.0365))                         │
│     = 0.509  [50.9% de probabilidad]                │
│                                                      │
│  3. Odds = (1 - PD) / PD = 0.491 / 0.509 ≈ 0.965   │
│                                                      │
│  4. Score = Offset + Factor × ln(Odds)              │
│     = 600 + 28.8539 × ln(0.965)                     │
│     = 600 + 28.8539 × (-0.0356)                     │
│     ≈ 599                                            │
│                                                      │
│  Salida: 2 columnas nuevas                          │
│    - score: [300–900] escala lineal                 │
│    - pd: [0–1] probabilidad bruta                   │
└─────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────┐
│  [decidir()] Regla de decisión binaria              │
│  → if score >= 580: decision = "APROBAR"            │
│     else: decision = "RECHAZAR"                     │
│                                                      │
│  Ejemplo:                                            │
│    score = 599 ≥ 580  →  APROBAR                    │
│    score = 575 < 580  →  RECHAZAR                   │
│                                                      │
│  Salida: 1 columna nueva                            │
│    - decision: {"APROBAR", "RECHAZAR"}              │
└─────────────────────────────────────────────────────┘
                                  │
                                  ▼
           RESULTADO FINAL
        ┌──────────────────┐
        │  CSV de salida   │
        │  por solicitud:  │
        │                  │
        │ solicitud_id     │
        │ score       [599]│
        │ pd          [0.509]
        │ decision [APROBAR]│
        │                  │
        │ (84.5K registros)│
        └──────────────────┘
                 │
                 ▼
        ┌──────────────────┐
        │ Sistema Core de  │
        │ Originación      │
        │ (Oracle)         │
        │ → Desembolso     │
        │ → Seguimiento    │
        └──────────────────┘

┌─────────────────────────────────────────────────────┐
│  MONITOREO POST-DECISIÓN (H1 2026)                  │
│                                                      │
│  Después de 12 meses:                               │
│    Tasa de incumplimiento (mora > 90d) = 4.2%       │
│    (del perfil de datos)                            │
│                                                      │
│  Métricas de poder discriminante:                   │
│    Gini:  0.52 (desarrollo) → 0.41 (actual) ⚠️      │
│    KS:    0.38 (desarrollo) → 0.29 (actual) ⚠️      │
│    AUC:   0.76 (desarrollo) → 0.71 (actual) ⚠️      │
│                                                      │
│  Diagnóstico:                                        │
│    - Deterioro de discriminación (últimos 3 trim.)  │
│    - Tasa de aprobación: 61% → 73% (sin corte Δ)   │
│    - Variable "peor_situacion_12m" perdió poder     │
│      tras cambio de reporte central en 2025-09      │
│                                                      │
│  Acción:                                             │
│    → Recalibración programada para 2026-09          │
└─────────────────────────────────────────────────────┘
```

**Notas al flujo:**

1. **Fuentes de datos:** Tres sistemas independientes (Oracle, Central de Riesgo, Cliente). La latencia y frecuencia de actualización de la Central (mensual) pueden afectar la antigüedad de `peor_situacion_12m` en el score diario.

2. **Punto crítico: Imputación:**  
   Media global para 6–7% de registros puede suavizar varianza natural. En solicitud S000006, si asignar ingresos por media hace que el score suba artificialmente, la decisión es sesgada.

3. **Punto crítico: Binning congelado:**  
   El `mapa_woe` se calibra una sola vez en 2023–2024 (muestra de 84.5K). Cambios poblacionales (informe reporta aumento de aprobaciones sin cambio de corte) pueden hacer que los bins no sean representativos en 2026.

4. **Monitoreo:**  
   Se ejecuta trimestral. Degradación de Gini (0.52 → 0.41) sugiere que las variables ya no discriminan bien. La causa documentada es el cambio de reporte de Central en 2025-09.

5. **Ciclo de vida:**  
   - Aprobación: Ejecuta función `decidir()` → APROBAR/RECHAZAR
   - Desembolso: 12 meses de observación
   - Etiquetado: `incumplio_90d` (verdad de campo)
   - Recalibración: Si KS o Gini caen fuera de umbral (próx. 2026-09)

## 6. Seguimiento y monitoreo en producción

### 6.1 ¿Qué se revisa periódicamente?

El modelo PD_Retail se monitorea a través de un conjunto de métricas de discriminación que se comparan contra umbrales predefinidos.

**Métricas monitoreadas** (informe_seguimiento_PD_Retail_2026H1.md):
- **Gini**: mide la capacidad del modelo de separar clientes que incumplen de los que pagan. Umbral: ≥ 0.45.
- **KS (Kolmogórov-Smirnov)**: cuantifica la máxima distancia entre las distribuciones acumuladas de clientes sanos y en incumplimiento. Umbral: ≥ 0.30.
- **AUC (Área bajo la curva ROC)**: probabilidad de que el modelo clasifique correctamente un par aleatorio (incumplidor vs. sano). Umbral: ≥ 0.72.

**QUÉ ocurre en la práctica:**  
En el período H1 2026, todas las métricas cayeron respecto al desarrollo:
- Gini: 0.52 → 0.41 (por debajo del umbral)
- KS: 0.38 → 0.29 (por encima del umbral, pero en tendencia decreciente)
- AUC: 0.76 → 0.71 (por debajo del umbral)

Este deterioro es caracterizado como "sostenido durante los últimos 3 trimestres" (informe_seguimiento_PD_Retail_2026H1.md), señal de degradación gradual del poder discriminante.

**Otros puntos monitoreados** (informe_seguimiento_PD_Retail_2026H1.md):
- **Tasa de aprobación**: subió de 61% a 73% sin cambio en el punto de corte (≥ 580). Esto sugiere un desplazamiento en la distribución de la población hacia scores más altos, posiblemente por cambios en el mix de solicitantes o en el ambiente macroeconómico.
- **Estabilidad de variables individuales**: la variable "Peor situación 12m en central de riesgo" perdió poder predictivo tras un cambio en el reporte de la central externa en 2025-09.

⚠️ **Sin evidencia en fuentes**: no se especifica con qué periodicidad se ejecutan estos cálculos (¿mensual, trimestral?), ni existe un procedimiento documentado de backtesting de PD observada vs. estimada.

### 6.2 Procedimiento de escalamiento y remediación

**Escalamiento programado:**
- Recalibración del scorecard prevista para 2026-09 (manual_metodologico_PD_Retail.md: "Recalibracion prevista cada 24 meses" desde aprobación el 2025-11-20).
- Análisis de la variable de central de riesgo asignado al Equipo de Modelos (informe_seguimiento_PD_Retail_2026H1.md).

⚠️ **Sin evidencia en fuentes**: 
- No hay procedimiento documentado de escalamiento inmediato si una métrica cae por debajo del umbral antes de la recalibración programada.
- No se especifica qué acciones se toman si Gini cae por debajo de 0.45 (como ocurrió en H1 2026) o si AUC cae por debajo de 0.72.
- No hay criterio documentado para pausar el modelo o restringir su uso a segmentos de menor riesgo.
- No se menciona quién tiene autoridad para desencadenar una recalibración urgente fuera del ciclo de 24 meses.

---

## 7. Limitaciones y supuestos frágiles

### 7.1 Limitaciones explícitamente documentadas en las fuentes

**Ninguna limitación es formalmente reconocida en los documentos disponibles.** El manual metodológico no contiene una sección de limitaciones, ni el informe de seguimiento cuantifica explícitamente el riesgo de decisiones basadas en un modelo cuyo Gini ya está por debajo del umbral.

### 7.2 Supuestos frágiles detectados en la evidencia (aunque no formalmente llamados "limitaciones")

#### **A. Imputación de missing values sin diagnóstico de mecanismo**

**QUÉ:** El 6.1% de missings en "ingreso mensual declarado" y el 4.8% en "antiguedad laboral" se rellenan con la media del segmento (perfil_datos_PD_Retail.md).

**CÓMO:** `df.fillna(df.mean(numeric_only=True))` (implementacion_PD_Retail.py, función `ejecutar`).

**POR QUÉ:** ⚠️ Sin justificación documentada. No hay análisis del patrón de missingness (¿es MCAR, MAR o MNAR?).

**Fragilidad:** Si el missing depende de la variable predicida (ej. clientes con bajo ingreso tienden a no declararlo), la imputación por la media sesga el modelo hacia el centro y degrada la discriminación. La tasa de incumplimiento en clientes con ingreso imputado vs. observado probablemente difiere, pero no se mide.

⚠️ **Punto a cuestionar:** ¿Se comparó la distribución de PD entre registros con ingreso observado vs. imputado?

---

#### **B. Estabilidad poblacional no monitoreada**

**QUÉ:** El modelo se entrena en originaciones 2023-01 a 2024-06. En H1 2026 se aplica a una población cuya composición ha cambiado (tasa de aprobación sube de 61% a 73% sin cambio en el corte).

**CÓMO:** No hay procedimiento documentado de PSI (Population Stability Index) ni CSI (Characteristic Stability Index).

**POR QUÉ:** ⚠️ Sin evidencia en fuentes.

**Fragilidad:** El scorecard asume que la relación entre WOE y PD se mantiene estable. Si la población deja de tener la misma composición (edad, ingreso, antigüedad laboral promedio cambian), el poder discriminante se degrada incluso si los coeficientes permanecen fijos. Esto es exactamente lo que el informe sugiere que está ocurriendo (deterioro de métricas + cambio en tasa de aprobación).

⚠️ **Punto a cuestionar:** ¿Se verificó si la distribución de edades, ingresos y situación crediticia en la población H1 2026 sigue siendo la misma que en 2023-2024?

---

#### **C. Cambios externos en fuentes de datos sin protección en el modelo**

**QUÉ:** La variable "Peor situación 12m en central de riesgo" perdió poder predictivo tras un cambio en el reporte de la central externa en 2025-09 (informe_seguimiento_PD_Retail_2026H1.md).

**CÓMO:** No hay controles automáticos documentados para detectar cambios en la semántica o cobertura de datos externos.

**POR QUÉ:** ⚠️ Sin evidencia en fuentes.

**Fragilidad:** El modelo depende de que la central de riesgo reporte categorías consistentes (NORMAL, CPP, DEFICIENTE, DUDOSO). Si el proveedor externo cambia de metodología o cobertura sin aviso, los bins WOE pierden validez inmediatamente. En este caso, IV de 0.42 se convierte en predictivamente inútil. No hay evidencia de que el scorecard se rehaya o se retire a tiempo.

⚠️ **Punto a cuestionar:** ¿Cuál fue el cambio exacto en la central de riesgo en 2025-09 y cuándo se detectó que afectaba el poder predictivo?

---

#### **D. Punto de corte (580) no justificado por criterios de negocio documentados**

**QUÉ:** Las solicitudes se aprueban si Score ≥ 580 y se rechazan si Score < 580 (manual_metodologico_PD_Retail.md).

**CÓMO:** El Offset se calibra para que odds 50:1 correspondan a 600 puntos. El corte está 20 puntos por debajo.

**POR QUÉ:** ⚠️ Sin justificación documentada. No hay análisis de costes de falsos positivos (rechazo incorrecto → pérdida de cliente) vs. falsos negativos (aprobación incorrecta → eventual incumplimiento).

**Fragilidad:** El corte podría ser matemáticamente correcto (calibración de odds) pero ineficiente económicamente. Si el coste de rechazar un buen cliente es mayor que el de aprobar uno malo, el punto de corte óptimo sería más bajo (score más permisivo). El modelo fuerza un corte único que no diferencia por rentabilidad, edad de cliente, LTV u otros factores de negocio.

⚠️ **Punto a cuestionar:** ¿Existe un análisis de matriz de costes (cost-benefit) que justifique el corte en 580?

---

#### **E. Variables categóricas con categorías no mapeadas asignadas ad-hoc**

**QUÉ:** El 2.3% de registros tienen categorías de "Peor situación 12m" que no están en el diccionario del modelo (perfil_datos_PD_Retail.md).

**CÓMO:** Se asignan al bin "sin información" (perfil_datos_PD_Retail.md, sección "Chequeos").

**POR QUÉ:** ⚠️ Sin justificación documentada. No se explica qué WOE tiene el bin de "sin información" ni si fue entrenado en desarrollo o es un relleno post-hoc.

**Fragilidad:** Si el 2.3% de la población está en un bin no visto en desarrollo, el modelo extrapola. Si "sin información" tiene WOE = 0 (neutral), estos clientes son incorrectamente asimilados a la "probabilidad base". Si tiene otro valor, es un parámetro no justificado.

⚠️ **Punto a cuestionar:** ¿Cuál es el WOE asignado al bin "sin información" y cómo fue estimado?

---

#### **F. Horizonte de desempeño fijo de 12 meses en una cartera dinámicamente originada**

**QUÉ:** El modelo se entrena prediendo incumplimiento en los 12 meses post-originación (manual_metodologico_PD_Retail.md). Pero las originaciones son continuas (batch diario de solicitudes).

**CÓMO:** No hay documentación de cómo se calibra la PD para clientes originados hace 3 meses (si sólo faltan 9 para el horizonte) vs. hace 11 meses (si falta 1).

**POR QUÉ:** ⚠️ Sin evidencia en fuentes.

**Fragilidad:** La PD = 0.042 (tasa de incumplimiento en desarrollo) es un número agregado para todo el período 12 meses post-originación. Cuando se aplica el scorecard a un cliente nuevo hoy, el modelo predice su PD a 12 meses, pero no se documenta si es:
- PD a 12 meses desde hoy (forward-looking),
- PD a 12 meses desde su originación (que ya pasó parcialmente),
- Algo intermedio calibrado por edad del préstamo.

Sin claridad, hay riesgo de sobre/sub-provisión según la edad del stock crediticio.

⚠️ **Punto a cuestionar:** ¿La PD predicha es independiente de cuántos meses hace que se originó el préstamo?

---

#### **G. Ninguna variable forward-looking o macroeconómica**

**QUÉ:** Las cinco variables del scorecard son todas características del cliente en el momento de originación (antigüedad laboral, ingreso declarado, situación crediticia histórica). Ninguna incorpora ciclo económico, tasa de desempleo, inflación o expectativas futuras.

**CÓMO:** No hay documentación de escenarios macro o ponderaciones entre los mismos.

**POR QUÉ:** ⚠️ Sin evidencia en fuentes.

**Fragilidad:** El modelo fue entrenado en 2023-2024, un período de relativa estabilidad macroeconómica post-pandemia. Si la economía entra en recesión (desempleo sube, inflación alta), la tasa de incumplimiento esperada de un cliente con score 600 hoy será mayor que cuando se entrenó el modelo. El scorecard no tiene mecanismo para ajustar PD por estado del ciclo. La degradación observada en H1 2026 (Gini 0.52 → 0.41) podría estar parcialmente explicada por cambios macroeconómicos no capturados.

⚠️ **Punto a cuestionar:** ¿Se correlacionó el deterioro de métricas (H1 2026) con indicadores macroeconómicos (desempleo, inflación, tasas de interés)?

---

#### **H. Multicolinealidad no documentada**

**QUÉ:** El scorecard usa 5 variables: antigüedad laboral, ingreso, situación de riesgo en central, número de entidades con deuda, edad.

**CÓMO:** No hay reporte de correlaciones pairwise, VIF (Variance Inflation Factor), ni análisis de redundancia entre variables.

**POR QUÉ:** ⚠️ Sin evidencia en fuentes.

**Fragilidad:** Es probable que "antigüedad laboral" e "ingreso" estén correlacionados (mayor antigüedad → mayor ingreso esperado). También "número de entidades con deuda" y "peor situación 12m" pueden ser colineales (más deuda → más probabilidad de tener un atraso). Si hay multicolinealidad, los coeficientes beta son inestables: cambios pequeños en los datos de entrenamiento producen cambios grandes en los pesos. Esto acelera la degradación del modelo cuando la población cambia.

⚠️ **Punto a cuestionar:** ¿Se midió la correlación pairwise y el VIF entre variables en desarrollo?

---

#### **I. Muestra de desarrollo pequeña para la complejidad esperada en producción**

**QUÉ:** La muestra de desarrollo es de 84,500 solicitudes (manual_metodologico_PD_Retail.md) de un período de 18 meses (2023-01 a 2024-06).

**CÓMO:** No hay documento que analice el tamaño de muestra por bin, poder estadístico, o margen de error esperado en los coeficientes beta.

**POR QUÉ:** ⚠️ Sin evidencia en fuentes.

**Fragilidad:** Con 84,500 solicitudes y una tasa de incumplimiento del 4.2%, hay ~3,550 eventos (incumplidores) en desarrollo. Distribuidos entre 5 variables con múltiples bins (ej. antigüedad laboral probablemente tiene 4-6 bins), algunos bins tendrán menos de 30-50 eventos. La estimación de WOE en bins pequeños es inestable. Cuando la población cambia (H1 2026) y algunos bins se vacían o se expanden, los WOE pre-estimados pierden validez rápidamente.

⚠️ **Punto a cuestionar:** ¿Cuál es el número mínimo de eventos por bin en el scorecard de desarrollo y hay alguno por debajo de 30?

---

#### **J. Sin documento de validación cruzada o test independiente**

**QUÉ:** No hay evidencia de que el scorecard se haya validado en un conjunto de datos temporalmente separado del desarrollo.

**CÓMO:** El informe de seguimiento compara "Desarrollo" vs. "Actual", pero "Actual" es la población en producción (H1 2026), no un test set apartado antes del lanzamiento.

**POR QUÉ:** ⚠️ Sin evidencia en fuentes.

**Fragilidad:** Sin un test set independiente captado antes del lanzamiento, no se puede separar:
- Degradación por overfitting (el modelo memorizó ruido en 2023-2024),
- Degradación por cambio estructural genuino de la población (shift macroeconómico, cambios en originación).

El informe asume que toda la caída en métricas es culpa de factores externos (cambio en central de riesgo, tasa de aprobación más alta). Pero si el modelo estaba ya degradado en un test set held-out, eso habría sido detectado antes del lanzamiento.

⚠️ **Punto a cuestionar:** ¿Existe un test set apartado en desarrollo, anterior al lanzamiento, contra el cual se validó el scorecard?

---

## 8. Glosario

| Término | Definición (nivel negocio) |
|---|---|
| **AUC (Área bajo la curva ROC)** | Probabilidad de que el modelo clasifique correctamente un par aleatorio de cliente que incumple vs. cliente que paga. Rango: 0 a 1. 0.5 = azar; 1.0 = perfecto. |
| **Backtesting** | Prueba que compara las predicciones del modelo con lo que realmente sucedió, para detectar si el modelo sigue siendo preciso. |
| **Beta (coeficiente)** | Peso numérico que multiplica cada variable en la fórmula del modelo. Indica cuánto importa esa variable en la predicción final. |
| **Bin (intervalo)** | Rango de valores en el que se agrupa una variable continua para simplificar el análisis. Ej: ingresos de $2000-$3000 en un bin. |
| **Central de riesgo** | Base de datos externa que registra el historial crediticio de personas (atrasos, saldos, número de créditos). |
| **CPP (Cartera con Problemas Potenciales)** | Categoría de clasificación de deuda en la central de riesgo: cliente con atraso de 30-60 días. |
| **Discriminación** | Capacidad del modelo de separar clientes que van a incumplir de los que van a pagar. |
| **Forward-looking** | Que incorpora información sobre el futuro esperado (p. ej. escenarios económicos), no sólo datos históricos. |
| **Gini** | Medida de desigualdad que en scoring indica cuánto mejor es el modelo que una asignación aleatoria. Rango: 0 a 1. ≥0.45 se considera aceptable. |
| **Information Value (IV)** | Métrica que mide cuánta información sobre incumplimiento aporta una variable. Rango: 0 (nada) a ∞ (infinito). Se retienen variables con IV entre 0.02 y 0.5. |
| **Incumplimiento (default)** | Cuando el cliente entra en mora mayor a 90 días, es decir, deja de pagar por más de 3 meses consecutivos. |
| **KS (Kolmogórov-Smirnov)** | Medida de distancia máxima entre la distribución de clientes buenos y malos según el score. Rango: 0 a 1. ≥0.30 es aceptable. |
| **Logit** | Transformación matemática de una probabilidad a una escala que va de -∞ a +∞, útil para modelos lineales. |
| **Mora > 90 días** | Atraso en el pago mayor a 90 días. En regulación, se considera incumplimiento grave. |
| **Offset** | Valor base del score que se suma a la transformación del modelo para centrar la escala. En PD_Retail, offset=600 puntos. |
| **Odds** | Razón entre la probabilidad de incumplimiento y la de no incumplimiento. Ej: odds 50:1 = 1 incumplidor por 50 que pagan. |
| **PD (Probability of Default)** | Probabilidad estimada de que el cliente incumpla dentro del horizonte de predicción (12 meses en este modelo). Rango: 0 a 1 (o 0% a 100%). |
| **Punto de corte** | Score umbral que determina la decisión (aprobar si Score ≥ corte, rechazar si < corte). En PD_Retail, corte = 580. |
| **Regresión logística** | Técnica estadística que estima la probabilidad de un evento binario (sí/no) en función de variables predictivas. |
| **ROC (Receiver Operating Characteristic)** | Gráfico que muestra el trade-off entre verdaderos positivos y falsos positivos conforme cambia el punto de corte. |
| **Score** | Puntuación numérica que el modelo asigna a cada cliente. Rango en PD_Retail: típicamente 300-800 puntos. Mayor score = menor riesgo (menor PD). |
| **Scorecard** | Conjunto de variables, fórmulas y puntos de corte que el modelo usa para tomar decisiones automatizadas de riesgo. |
| **Test set** | Conjunto de datos apartado antes de entrenar el modelo, usado únicamente para validar su precisión en datos "nuevos". |
| **WOE (Weight of Evidence)** | Transformación de cada variable que cuantifica cuánta "evidencia" de incumplimiento vs. pago contiene. Se usa para linealizar la relación con el logit. |

---

## 9. Preguntas abiertas

### 9.1 Discrepancias entre fuentes

**Pregunta 1: ¿Cuál es exactamente el mecanismo de escala del score?**

En `implementacion_PD_Retail.py`, la fórmula es:
```
score = offset + factor * ln(odds)
```
con `offset=600.0` y `factor=28.8539`.

El manual dice `Factor = 20/ln(2) ≈ 28.8539` ✓ coincide.

Pero el manual dice "Offset calibrado a 600 puntos para odds 50:1". Si odds=50:1, entonces ln(odds)=ln(50)≈3.912, luego score = 600 + 28.8539 × 3.912 ≈ 712.8, NO 600.

**¿Cuál es la calibración correcta? ¿El offset 600 corresponde a odds diferentes? ¿O hay un error en una de las dos fuentes?**

---

**Pregunta 2: Discrepancia en documentación de recalibración.**

El manual dice "Recalibracion prevista cada 24 meses" desde aprobación el 2025-11-20, lo que ubicaría la siguiente recalibración en 2027-11.

El informe H1 2026 dice "Revision del scorecard programada para 2026-09" (solo 10 meses después de la aprobación).

**¿Cuál es el ciclo real de recalibración? ¿Cambió entre la aprobación y el reporte de seguimiento?**

---

### 9.2 Vacíos críticos de información

**Pregunta 3: ¿Qué es exactamente el "cambio en el reporte de la central de riesgo en 2025-09"?**

El informe señala que "la variable 'Peor situación 12m' perdió poder predictivo tras el cambio de reporte de la central de riesgo en 2025-09", pero no especifica:
- ¿Cambió la semántica de las categorías (NORMAL/CPP/DEFICIENTE/DUDOSO)?
- ¿Cambió la cobertura (menos clientes reportados)?
- ¿Cambió la metodología del proveedor (diferentes criterios para asignar categorías)?
- ¿Cuándo exactamente se detectó esta pérdida de poder y por qué tomó tanto tiempo?

**Necesario para trazabilidad: ¿Existe un documento del proveedor de la central describiendo el cambio?**

---

**Pregunta 4: ¿Cuáles son los WOE exactos de cada bin?**

El manual lista las variables y sus IV, pero no expone los bins reales, los WOE, ni los coeficientes beta. Sin esto:
- No se puede auditar si la transformación es correcta.
- No se puede detectar si un bin tiene WOE inusualmente alto/bajo (señal de overfitting o error de datos).
- No se puede reproducir manualmente un score.

**Necesario: ¿Dónde se custodian la tabla de bins y los WOE?**

---

**Pregunta 5: ¿Cuál es la tasa de incumplimiento observada en producción (H1 2026)?**

El informe reporta métricas de discriminación (Gini, KS, AUC) pero no reporta la **tasa de incumplimiento observada** en H1 2026 vs. la estimada por el modelo. Si el modelo predice una PD promedio de, digamos, 4.5%, y la observada es 7%, eso es un severo problema de calibración.

**Necesario: ¿Cuál es la incumplimiento observada vs. estimada en H1 2026?**

---

**Pregunta 6: ¿Hay procedimiento documentado para detener el modelo si falla?**

El informe nota que Gini cayó a 0.41, por debajo del umbral de 0.45. No hay evidencia de que esto haya activado un procedimiento de escalamiento. La única acción documentada es una "revisión programada para 2026-09", es decir, 6-9 meses después de que el umbral fue violado.

**¿Existe un procedimiento de pausar o restringir el uso del modelo si Gini cae < 0.45, AUC cae < 0.72, o KS cae < 0.30? ¿Quién tiene autoridad?**

---

**Pregunta 7: ¿Se validó el modelo en un test set independiente antes del lanzamiento?**

No hay evidencia de validación cruzada (k-fold), partición train/validation/test, o análisis de estabilidad de coeficientes. Esto es un hallazgo sorprendente para un modelo en producción desde 2025-11.

**¿Existe un reporte de validación del scorecard en datos separados temporalmente del desarrollo?**

---

**Pregunta 8: ¿Cómo se calibran las PD por edad del préstamo?**

El horizonte de predicción es 12 meses. Un préstamo originado hace 3 meses tiene 9 meses de horizonte remanente. Un préstamo originado hace 11 meses tiene 1 mes. El modelo predice lo mismo para ambos (PD del scorecard), lo que es incorrecto.

**¿Se ajusta la PD estimada del scorecard por edad del préstamo, o se aplica tal como está?**

---

**Pregunta 9: ¿Qué sucede con el 2.3% de registros con categorías no mapeadas en central de riesgo?**

Se asignan a un bin "sin información", pero:
- ¿Cuál es el WOE de ese bin?
- ¿Fue estimado en desarrollo (cuántos registros había en desarrollo?) o es un relleno post-hoc?
- ¿Hay un patrón: qué tipo de solicitudes caen en "sin información"?

**Necesario para validación: ¿Cuál es el WOE del bin "sin información" y su origen?**

---

**Pregunta 10: ¿Se monitoreó la tasa de falsos positivos (rechazos incorrectos)?**

El scorecard rechaza solicitudes con Score < 580. Algunos de estos clientes, si hubieran sido aceptados, habrían pagado sin incumplir (falsos positivos de riesgo). Este coste operativo (pérdida de clientes buenos) nunca es cuantificado.

**¿Se mide la tasa de falsos positivos y se compara con el coste de incumplimientos evitados?**

---

**Pregunta 11: ¿La tasa de aprobación del 73% (H1 2026) es consistente con criterios de negocio?**

Subió de 61% sin cambio en el corte. Esto podría ser:
- Cambio en el mix de solicitantes (menos clientes de alto riesgo solicitan).
- Cambio en la economía (mejora crediticia poblacional).
- Sesgo en la asignación de puntos por cambios en fuentes de datos.

**¿Se analizó la causa de la suba de tasa de aprobación? ¿Hay análisis de composición de la población (edad, ingreso, antigüedad)?**

---

**Pregunta 12: ¿Se realizó análisis de sensibilidad en los coeficientes del modelo?**

Si un coeficiente beta es muy inestable (error estándar alto), cambios pequeños en los datos de entrenamiento producen grandes cambios en las decisiones. Esto predice que cuando la población cambia (como en H1 2026), el modelo se degradará rápidamente.

**¿Se reportó el error estándar o intervalo de confianza de cada coeficiente beta?**

---

**Pregunta 13: ¿Existe protocolo de comunicación a clientes rechazados?**

El punto de corte automático en 580 genera rechazos inmediatos sin intervención humana. Algunos clientes quedarán a pocos puntos del corte. ¿Hay procedimiento de apelación, rescoring o revisión manual?

**¿Existe un protocolo documentado de apelación para solicitudes rechazadas automáticamente por el scorecard?**

---

**Pregunta 14: ¿Se han identificado factores forward-looking para próximas iteraciones?**

El modelo actual no incorpora variables macroeconómicas. El ciclo económico afecta claramente el desempeño (cf. H1 2026 vs. desarrollo 2023-2024).

**¿Existe un backlog de mejoras que incluya variables forward-looking (desempleo, inflación, índice de confianza del consumidor, curve yield)?**

---

**Pregunta 15: ¿Cuál es la política de archivo y trazabilidad de decisiones?**

Para auditoría, hay que poder recuperar: score, PD estimada, variables de entrada, y decisión de cada solicitud. ¿Se guardan? ¿Con qué retención?

**¿Existe un repositorio auditável de todas las decisiones (solicitud_id, score, PD, decisión) con retención documentada?**
