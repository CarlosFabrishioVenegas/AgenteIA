# Informe de validación — VaR Mercado FRTB

> **BORRADOR DE TRABAJO.** Este documento lo genera el agente VIRF para
> que el validador humano lo revise, corrija y redacte el informe final.
> **No es el entregable** y no sustituye el criterio de quien firma.

| | |
|---|---|
| Modelo | VaR Mercado FRTB |
| Tier | 4 |
| Fecha | 2026-08-03 |
| Agente | 27.1 · claude-haiku-4-5-20251001 |
| Score global | **2.87** — CON OBSERVACIONES |
| Posición en cadena de custodia | 2 |
| Hash del informe | `5e4ce0db0b575180d02861fa5ab64c4d` |

## 0. Cómo leer este documento

**El score no es la conclusión.** Es un resumen con pérdida de información,
útil para priorizar por dónde empezar e inútil para concluir nada. Lo que
sostiene un dictamen son las citas y el razonamiento, no el número.

### La escala, y qué exige cada nivel

| | Significa | Para darlo hace falta |
|---|---|---|
| **1** | No cumple | Ausencia total de evidencia sobre el tema |
| **2** | Brechas críticas | Se menciona, pero no se ejecuta o falta lo esencial |
| **3** | Brechas no críticas | Implementado **y ejecutado**, con huecos menores |
| **4** | Observaciones menores | Además, la elección está **justificada** |
| **5** | Cumple plenamente | Además, supuestos verificados y límites declarados |

El eje no es «cuánto se habla del tema», es **cuánto está demostrado**. El 5
es poco frecuente por diseño: exige poder defenderlo ante un supervisor con
las citas en la mano.

### Las cinco trampas que el agente busca

Cosas que aparentan cumplimiento y no lo son. Si vas a discutir un puntaje,
empieza por comprobar cuál de estas aplica:

| Trampa | Ejemplo |
|---|---|
| Documentado ≠ correcto | Manual impecable que describe una decisión equivocada |
| Existe ≠ se ejecuta | Script de backtesting que nadie corrió |
| Se menciona ≠ se justifica | «Se aplica la metodología X» sin decir por qué X |
| Se cita ≠ lo sostiene | Un paper que no dice lo que el manual afirma |
| Se calcula ≠ se usa | Métrica que no llega a ningún comité |

### Dos cosas que NO son lo mismo

- **Ausencia de evidencia** — el agente no lo encontró en lo que pudo leer.
  Es una limitación del alcance, y se declara como tal.
- **Incumplimiento** — la evidencia está y muestra una deficiencia.

Confundirlas es el error más caro al redactar: acusa al modelador de algo
que quizá sí documentó, solo que en una página que no cupo en el contexto.
Revisa siempre la **cobertura documental** antes de convertir un puntaje
bajo en un hallazgo.

### Qué te toca a ti

Los bloques **✍️** marcan dónde el documento espera tu criterio. El agente
propone; el validador dispone y firma. Ninguna cifra de aquí es definitiva
hasta que la revisas.

## 1. Resumen por ámbito

Ordenados **de peor a mejor**: por ahí se empieza.

| Ámbito | Score | Peso | Aporta al global | Lectura |
|---|---:|---:|---:|---|
| Uso e integración a la gestión | 2.0 | 8% | 0.16 | 🟠 Cumple parcialmente — observaciones críticas |
| Implementación | 2.4 | 15% | 0.36 | 🟠 Cumple parcialmente — observaciones críticas |
| Metodología | 2.83 | 30% | 0.85 | 🟡 Cumple parcialmente |
| Gobierno | 3.0 | 12% | 0.36 | 🟡 Cumple parcialmente |
| Calidad de datos | 3.2 | 20% | 0.64 | 🟡 Cumple parcialmente |
| Documentación | 3.33 | 15% | 0.50 | 🟡 Cumple parcialmente |

> ✍️ **Te toca:** el ámbito con peor score no siempre es el más urgente —
> mira la columna «aporta al global». Un 2 en Metodología (peso 30 %) pesa
> casi cuatro veces más que un 2 en Uso e integración (8 %).

## 2. Inconsistencias entre fuentes

**40 contradicción(es)** entre lo documentado y lo implementado.
Cada una trae las dos citas enfrentadas para que puedas verificarla en el
documento original.

### 2.1 [ALTA] El manual declara que el control de cambios existe y se encuentra en el anexo A, pero ese anexo no está disponible para validación. Esto impide verificar si el control realmente documenta el historial de cambios, quién autorizó versiones, cuándo se aprobaron, y si el proceso se ejecuta operativamente. Es una afirmación de existencia sin evidencia de contenido.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> Control de cambios en anexo A.

**CONTEXTO DISPONIBLE** dice:
> (Anexo A no está presente en la cobertura documental)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.2 [ALTA] El perfil declara una decisión de imputación pero el manual metodológico no la documenta ni la justifica. Esto viola el principio de trazabilidad: si la imputación es parte del cálculo del VaR, debe estar en el manual. Si no está ahí, o bien el perfil describe un pre-procesamiento no autorizado, o bien el manual está incompleto. En ambos casos, hay un vacío de responsabilidad sobre quién decidió usar LOCF y bajo qué criterio.

*Ámbito: Calidad de datos · Actividad: Revisar la existencia de reportes de incidencia, monitorio de calidad de datos (entradas y salidas)*

**perfil_datos_VaR.md** dice:
> 0.4% de valores ausentes, imputados por último valor conocido

**manual_VaR_FRTB.md** dice:
> [Manual no contiene ninguna sección sobre tratamiento de valores ausentes, justificación de imputación, o controles de calidad de datos]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.3 [ALTA] El manual justifica la ventana de 500 días por sensibilidad versus 250 días, pero NO declara cómo esa ventana de 500 días fue validada en términos de calidad de datos. Si se imputan valores (forward fill) para el 0.4% de las observaciones en una serie de 500 días, entonces aproximadamente 2 observaciones son imputadas. El manual no explica si esas imputaciones caen dentro del período de estimación del VaR, ni cómo afectan a la distribución de retornos en una cola del 1% (Kupiec). Esta es una brecha de coherencia: el modelo justifica parámetros pero no valida los supuestos sobre los datos que alimentan esos parámetros.

*Ámbito: Calidad de datos · Actividad: Verificar la consistencia de las variables más importantes en el alcance de validación (Missing, outlier)*

**perfil_datos_VaR.md** dice:
> 0.4% de valores ausentes, imputados por último valor conocido

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.4 [ALTA] El manual especifica un backtesting mensual, pero el perfil de datos NO documenta cómo se tratan los días con mercados cerrados, retrasos en Bloomberg, o cambios en la composición de la cartera dentro del mes. Un backtesting válido requiere certeza sobre si los inputs han sido limpiados de manera consistente antes de cada corrida. La ausencia de contratos explícitos entre el proveedor de datos y el cálculo del modelo crea riesgo de que el backtesting valide un modelo contra datos cuya integridad no se garantiza en operación.

*Ámbito: Calidad de datos · Actividad: Verificar la integridad sobre los inputs en el alcance de validación*

**perfil_datos_VaR.md** dice:
> 0.4% de valores ausentes, imputados por último valor conocido

**manual_VaR_FRTB.md** dice:
> ## 3. Backtesting
Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.5 [ALTA] El perfil declara imputación por 'último valor conocido' (forward-fill), método que introduce autocorrelación espuria y reduce volatilidad observada, pero el anexo C que justifica la selección de ventana (500 vs 250 días) no documenta si ese estudio de sensibilidad se ejecutó SOBRE datos crudos o SOBRE datos imputados. Si se imputaron antes del backtesting, la comparación de excedencias contra Kupiec está sesgada: la volatilidad sintética reduce false positives (excedencias observadas), enmascarando insuficiencia de ventana. La severidad es alta porque la justificación metodológica de la ventana puede reposar sobre datos adulterados.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**perfil_datos_VaR.md** dice:
> 0.4% de valores ausentes, imputados por último valor conocido

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.6 [ALTA] El manual declara un horizonte uniforme de 1 día, compatible con el marco anterior (Basilea III). Sin embargo, la literatura sobre FRTB (BCBS 457) reemplazó el supuesto uniforme de 10 días por categorías con horizontes de liquidez crecientes para evitar subestimar riesgo en mercados poco profundos. El manual no justifica por qué usa horizonte uniforme bajo FRTB ni cómo reconcilia esto con el reconocimiento de que no captura liquidez. Si el modelo no implementa horizontes variables por categoría de liquidez (como FRTB prescribe a nivel de ES/estándar), esto podría indicar que el VaR está siendo usado para una función (FRTB) para la que no fue diseñado. Severidad: alta si FRTB requiere ese tratamiento de horizontes para este modelo; media si el VaR FRTB está separado del cálculo de ES por horizonte.

*Ámbito: Metodología · Actividad: Validar supuestos y consideración más importantes de la técnica utilizada*

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día.

**manual_VaR_FRTB.md** dice:
> No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.7 [ALTA] El manual posiciona el VaR como métrica central dentro de FRTB, pero FRTB (BCBS 457, 2019) ya desplazó VaR por ES como medida primaria de capital. El manual declara que ES "complementa" pero no aclara si el modelo interno está presentado al supervisor bajo la métrica ES (regulatoria) o VaR (complementaria). Esto genera riesgo de presentación regulatoria ambigua: si se reporta VaR al regulador como medida de adecuación de capital, podría no cumplir FRTB; si se reporta solo ES, la validación del VaR quedará fuera del perímetro de requerimientos de capital aunque técnicamente sea sólida.

*Ámbito: Metodología · Actividad: Revisión de los lineamiento internacionales o nacionales*

**manual_VaR_FRTB.md** dice:
> Estimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III).

**pericia_dominio_FRTB_BCBS457** dice:
> El marco revisado sustituye el Valor en Riesgo (VaR) al 99 % como medida de capital por el Expected Shortfall (ES) al 97,5 %.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.8 [ALTA] El manual afirma que la justificación de la ventana de 500 días está documentada en el anexo C, pero dicho anexo no está disponible en el contexto de validación. Sin acceso a esa justificación, no se puede verificar si la elección de 500 (vs. alternativas como 250, 375 ó 750) está realmente fundamentada o si la referencia es solo declarativa.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**[contexto disponible]** dice:
> El anexo C no está presente en la documentación entregada

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.9 [ALTA] El manual declara que el modelo se complementa con Expected Shortfall, pero el informe de backtesting Q1 2026 contiene SOLO backtesting de VaR (Kupiec y Christoffersen sobre VaR). No se reporta backtesting de ES. Bajo el marco FRTB (BCBS 457), el ES es la medida de capital regulatoria principal, y su backtesting es supervisoriamente requerido. La ausencia de evidencia de backtesting de ES representa un vacío crítico en la validación del modelo, especialmente para cálculos de capital.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**manual_VaR_FRTB.md** dice:
> Se complementa con el Expected Shortfall

**backtesting_VaR_2026Q1.md** dice:
> Backtesting VaR — 2026 Q1 (título implícito: solo VaR, no ES)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.10 [ALTA] El manual afirma que la justificación de un parámetro crítico (ventana de 500 días) está documentada en el anexo C, pero ese documento no está disponible para verificación. Esto impide validar independientemente si la elección es robusta o si se descartaron alternativas con rigor. Riesgo: la decisión puede estar basada en análisis incompleto o sesgado, sin que el validador pueda detectarlo.

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**Contexto disponible** dice:
> Anexo C no proporcionado en el paquete de validación

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.11 [ALTA] El manual remite a un 'anexo C' que supuestamente contiene el estudio de sensibilidad justificando por qué 500 días es óptimo, pero ese anexo NO está incluido en el contexto disponible. Además, la aseveración sobre que ventanas menores producen 'excedencias por encima del intervalo de Kupiec' no puede verificarse sin los datos numéricos del estudio. El resultado actual (LR=3.81, p=0.051) está apenas en el límite de la no-rechazo (5%), lo que sugiere que el modelo está marginalmente adecuado pero no es robusto. Sin el análisis de sensibilidad, no se puede confirmar si 500 días fue realmente la elección óptima o si es simplemente la que fue adoptada.

*Ámbito: Metodología · Actividad: Analizar el seguimeinto de la metodología*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**backtesting_VaR_2026Q1.md** dice:
> Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.12 [ALTA] El manual menciona aprobación por comité pero no proporciona acta formal. Un aprobación declarada en un documento metodológico NO es lo mismo que un acta de tiering firmada por el responsable del gobierno de modelos. Sin acta, no hay trazabilidad formal ni autoridad responsable identificada.

*Ámbito: Gobierno · Actividad: Revisar la actualización del tiering del modelo*

**manual_VaR_FRTB.md** dice:
> Aprobado por el Comité de Riesgos el 2026-03-15

**Instrucciones del ámbito** dice:
> Solo aceptar actas formales firmadas. Un correo NO equivale a acta.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.13 [ALTA] El manual afirma que los resultados del último trimestre están en un informe de seguimiento, pero ese informe no se proporcionó para validación. Esto impide verificar si el backtesting se ejecutó realmente, si las excedencias están dentro del intervalo de Kupiec (práctica estándar en FRTB), y si se han tomado acciones correctivas en mesas que no cumplan. Riesgo: el control puede estar documentado pero nunca ejecutado (code drift de control, no de código).

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento.

**CONTEXTO DISPONIBLE** dice:
> No se encontró informe de seguimiento con resultados de backtesting incluidos en el contexto.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.14 [ALTA] Se menciona un anexo de control de cambios pero no está presente. No se puede verificar: cuándo se movió el código a producción, qué cambios hubo entre versiones, cuáles se aprobaron formalmente, si hubo correos de autorización para UAT/producción, o si el código en `calcula_var.py` refleja la versión aprobada en marzo de 2026.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_FRTB.md** dice:
> Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A.

**CONTEXTO DISPONIBLE** dice:
> El anexo A (control de cambios) no se incluyó en el contexto disponible.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.15 [ALTA] El manual declara que los resultados de backtesting (Kupiec y Christoffersen) del último trimestre se reportan en un informe de seguimiento, pero ese informe NO está disponible en el contexto para validación independiente. Esto impide verificar: (i) si el backtesting fue efectivamente ejecutado, (ii) el número de excedencias observadas, (iii) si se cumplieron los criterios de Kupiec (intervalo de aceptación) y Christoffersen (independencia), (iv) qué zona de clasificación regulatoria alcanzó el modelo (verde/amarilla/roja). Sin este informe, la afirmación de que se realiza backtesting 'mensual' es no verificable.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_VaR_FRTB.md** dice:
> "Resultados del último trimestre en el informe de seguimiento."

**contexto disponible** dice:
> No se encontró en contexto disponible el informe de seguimiento mencionado

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.16 [ALTA] El manual afirma que la decisión de usar ventana de 500 días (versus alternativas menores a 250 días) se justifica mediante un análisis cuantitativo de sensibilidad documentado en el anexo C. Este anexo no está disponible para auditoría independiente. La justificación es, por tanto, declarativa, no verificable. Se desconoce: (i) qué datos históricos se usaron en el estudio, (ii) qué período de análisis cubrió, (iii) si el criterio de Kupiec fue realmente incumplido para ventanas <250 días, (iv) qué otras configuraciones se evaluaron y por qué se descartaron. La ausencia del anexo es crítica porque la ventana de lookback es el parámetro CLAVE de sensibilidad del modelo VaR.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_VaR_FRTB.md** dice:
> "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C"

**contexto disponible** dice:
> No se encontró anexo C ni estudio de sensibilidad en el contexto disponible

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.17 [ALTA] El código implementa correctamente los 500 días documentados, pero NO hay evidencia de que haya sido ejecutado sobre datos reales de la cartera para generar resultados de backtesting. El docstring es una declaración intencional, no una prueba de ejecución. EXISTE vs SE EJECUTA: el script puede estar 100% documentado y correcto, pero si nunca se corrió, la implementación no está validada. No hay logs, traces, reportes de ejecución, o métricas de desempeño (excedencias, ratios de cobertura) que muestren que la función fue invocada. Esto es crítico porque implementaciones externas (proveedor) frecuentemente contienen errores en detalles (tratamiento de NaN, orden de datos, ajustes de calendarios, exclusión de feriados) que solo se detectan ejecutando sobre datos reales.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**calcula_var.py** dice:
> """VaR histórico. Ventana de 500 días según manual metodológico §2."""

**manual_VaR_FRTB.md** dice:
> "Resultados del último trimestre en el informe de seguimiento."

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.18 [ALTA] El manual afirma que existen resultados de backtesting del último trimestre, pero estos resultados no están documentados en la evidencia disponible. Esto impide verificar si: (a) el backtesting se ejecutó realmente con datos de producción; (b) los p-valores de Kupiec caen en zona verde/ámbar/roja Basilea; (c) las excedencias se concentran en periodos específicos (lo que falsearía Christoffersen); (d) se tomaron acciones correctivas. Sin esta evidencia, no es posible validar que el modelo está en control operativo.

*Ámbito: Implementación · Actividad: Vericar existencias de correos de comunicación de resultados y su conformidad*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento.

**Contexto disponible** dice:
> No existe ningún 'informe de seguimiento' en los documentos proporcionados.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.19 [ALTA] El manual remite a un análisis de sensibilidad que justificaría la elección de 500 días (frente a alternativas de 250 días o menos), pero ese análisis no está documentado. Sin él, no es posible verificar si la elección es metodológicamente sólida o heredada sin análisis, si se descartaron alternativas y por qué, o si se probó la robustez del modelo ante cambios en la ventana. Esto es crítico en FRTB, donde la calibración de parámetros debe ser defensible ante supervisores.

*Ámbito: Implementación · Actividad: Vericar existencias de correos de comunicación de resultados y su conformidad*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**Contexto disponible** dice:
> El Anexo C no está presente en los documentos proporcionados.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.20 [ALTA] El código afirma que implementa 'manual metodológico §2' pero la referencia a una ventana específica no se puede verificar contra el manual citado. Este es un hallazgo de CONTROL DE CAMBIOS FALLIDO: si el código está en producción, debe ser verificable contra su especificación documentada, y la especificación debe estar bajo control de versiones. La ausencia de traceabilidad entre código y manual en un parámetro crítico para el cálculo es de severidad ALTA.

*Ámbito: Uso e integración a la gestión · Actividad: Validar que el modelo no se enceuntre en uso antes o durante la validación*

**calcula_var.py** dice:
> """VaR histórico. Ventana de 500 días según manual metodológico §2."""

**calcula_var.py (docstring menciona manual §2 pero sin contexto en documentos disponibles)** dice:
> No hay documento de manual disponible que aclare si §2 especifica 500 o 250 días.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.21 [ALTA] Si esta validación es contemporánea a la ejecución del modelo en producción, hay un conflicto directo entre el uso operativo (que altera parámetros y datos continuamente) y la necesidad de que la validación sea independiente de esos cambios. No está documentado si la validación es ANTERIOR, PARALELA O POSTERIOR al acta del comité. La severidad depende de la cronología: si es paralela, la validación está viciada; si es posterior, el acta es aceptable; si es anterior, el modelo fue activado sin haber cerrado validación (incumplimiento regulatorio en SR 11-7).

*Ámbito: Uso e integración a la gestión · Actividad: Validar que el modelo no se enceuntre en uso antes o durante la validación*

**acta_comite_riesgos_2026Q1.md** dice:
> "Se revisan los límites de VaR de la cartera de negociación. El VaR se utiliza como límite operativo diario"

**CONTEXTO DE LA VALIDACIÓN (instrucciones: 'Validar que el modelo no se encuentre en uso antes o durante la validación')** dice:
> La actividad exige que el modelo NO esté en uso durante la validación, pero el acta demuestra uso operativo en comité de abril de 2026.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.22 [ALTA] El código hace referencia a una ventana de 500 días como justificación contra el manual §2, pero ese manual NO está disponible para verificar si la ventana realmente especificada es 500 días o una cifra distinta. Sin acceso al documento de origen, no puede verificarse si el código implementa correctamente la política documentada. Esto es crítico porque una ventana de 500 días vs (por ejemplo) 250 días altera sustancialmente la sensibilidad del VaR a eventos recientes.

*Ámbito: Uso e integración a la gestión · Actividad: Adecuada integración a la gestión del modelo*

**calcula_var.py** dice:
> "Ventana de 500 días según manual metodológico §2."

**contexto disponible** dice:
> No se encontró el manual metodológico §2 en el contexto disponible para verificar la especificación

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.23 [ALTA] El Comité recibe reportes del consumo del VaR (cifra operativa del límite), pero NO hay evidencia de que reciba reportes de VALIDACIÓN del modelo (backtesting, excedencias, pruebas estadísticas). Un reporte de consumo es una métrica operativa; no constituye integración a la gestión en el sentido de que el modelo esté siendo monitoreado para su corrección o recalibración. Sin backtesting periódico, no hay evidencia de que las decisiones operativas basadas en este VaR se tomen sobre un modelo estadísticamente validado.

*Ámbito: Uso e integración a la gestión · Actividad: Adecuada integración a la gestión del modelo*

**acta_comite_riesgos_2026Q1.md** dice:
> "Su consumo se reporta al Comité mensualmente."

**contexto disponible** dice:
> No se encontró evidencia de backtesting, contraste estadístico (Kupiec/Christoffersen), análisis de excedencias, o validación de supuestos en ningún documento del contexto

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.24 [ALTA] El código referencia un manual metodológico §2 que debería especificar la ventana de cálculo. Sin acceso a ese documento no puede verificarse que la implementación (retornos[-500:]) es consistente con lo documentado y aprobado. Si el manual §2 dice algo distinto (p.ej., 250 días), habría una desalineación crítica entre especificación y código.

*Ámbito: Uso e integración a la gestión · Actividad: Verificar existencias y suficinecia del reporting*

**calcula_var.py** dice:
> "Ventana de 500 días según manual metodológico §2."

**contexto disponible** dice:
> manual metodológico §2 no proporcionado

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.25 [MEDIA] La justificación metodológica de una decisión clave (ventana de 500 días vs 250 días) está delegada a un anexo que no se entregó para validación. Sin acceso a ese análisis, no puede evaluarse si la elección está suficientemente justificada o si la argumentación de Kupiec citada es correcta.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**CONTEXTO DISPONIBLE** dice:
> (Anexo C no está presente en la cobertura documental)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.26 [MEDIA] El informe de backtesting de Q1 2026 no identifica explícitamente qué versión del manual se aplicó ni cómo se alineó con la aprobación del 2026-03-15. Si hubo cambios entre la aprobación y la ejecución, eso no consta. Además, el manual menciona backtesting 'mensual' pero el informe de Q1 parece consolidado, sin desglose mensual visible. La trazabilidad versional entre plan (manual) y ejecución (backtesting) no está explícita.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051)

**manual_VaR_FRTB.md** dice:
> Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.27 [MEDIA] El manual declara una ventana de 500 días pero solo justifica por qué no usar menos de 250 días. No existe documentación de por qué se eligió específicamente 500 y no, por ejemplo, 250-400 días. El anexo C (donde presuntamente reside la justificación) no está disponible en el contexto para verificación. Esto impide confirmar que la decisión metodológica esté plenamente respaldada por análisis documentado.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día.

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.28 [MEDIA] El informe de seguimiento reporta backtesting sobre 62 días (período Q1 2026), lo que es inconsistente con un modelo que utiliza una ventana histórica de 500 días. La ventana del modelo (500 días) y el período de validación (62 días) cumplen funciones diferentes, pero el informe no aclara si el backtesting contrasta el VaR calculado con ventana rodante de 500 días contra pérdidas reales de 62 días, ni cómo se replica la metodología en este horizonte más corto. Esto crea ambigüedad sobre si el backtesting es realmente comparable con el modelo documentado.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62.

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.29 [MEDIA] El perfil reporta un 0.4% de missing imputado por 'último valor conocido' (forward fill), pero el manual no documenta si esta imputación ocurre ANTES o DESPUÉS de la captura en el cálculo del VaR, ni si se verifica la validez de ese método para mercados volatilidad alta. Forward fill es una decisión metodológica sobre tratamiento de datos ausentes que puede introducir sesgo en períodos de gaps prolongados. No hay mención de alternativas evaluadas (interpolación, exclusión) ni de cómo se monitorea la calidad de esos valores imputados en el backtesting.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**perfil_datos_VaR.md** dice:
> 0.4% de valores ausentes, imputados por último valor conocido

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.30 [MEDIA] Se afirma un resultado de control (ausencia de duplicados) sin evidencia del proceso que lo generó. Esto es 'SE MENCIONA ≠ SE JUSTIFICA': una comprobación sin evidencia de su ejecución no cuenta como control implementado. ¿Cuándo se ejecutó? ¿Con qué script o manual de revisión? ¿Se repite periódicamente?

*Ámbito: Calidad de datos · Actividad: Revisar la existencia de reportes de incidencia, monitorio de calidad de datos (entradas y salidas)*

**perfil_datos_VaR.md** dice:
> Sin duplicados de fecha

**manual_VaR_FRTB.md** dice:
> [No hay mención de cómo se verifica la ausencia de duplicados, cuándo se hizo esa verificación, o quién la ejecutó]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.31 [MEDIA] El perfil de datos afirma un tratamiento específico (imputación por último valor) que no está documentado en el manual metodológico. Un control que no aparece en el manual no es formalmente parte del proceso de validación aprobado, lo que crea un riesgo de que la imputación se realice sin criterio documentado o que cambie sin auditoría.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista duplicados sobre los inputs que estén en el alcance de validación*

**perfil_datos_VaR.md** dice:
> imputados por último valor conocido

**manual_VaR_FRTB.md** dice:
> Secciones 1-4 (completo): no hay mención de tratamiento de valores ausentes ni justificación de la estrategia de imputación

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.32 [MEDIA] Se afirma la ausencia de duplicados como un hecho consumado, pero no existe un script que demuestre la ejecución de esa verificación. Sin código reproducible, la afirmación «sin duplicados de fecha» es una declaración sin auditabilidad. En un contexto regulatorio (Basilea III, FRTB), la evidencia debe ser reproducible; la mera aseverción no es suficiente.

*Ámbito: Calidad de datos · Actividad: Verificar la consistencia de las variables más importantes en el alcance de validación (Missing, outlier)*

**perfil_datos_VaR.md** dice:
> Sin duplicados de fecha

**INSTRUCCIONES ESPECÍFICAS PARA ESTE ÁMBITO** dice:
> Revisar scripts del modelador línea por línea. Buscar el script _replica_virf.py. Si no existe, el agente lo generará.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.33 [MEDIA] El manual declara limitación sobre liquidez pero no documenta cómo se valida que los precios Bloomberg utilizados (al 0.4% con forward-fill) reflejan la liquidez real de cada instrumento en la cartera FRTB. El método de imputación no es sensible a saltos de liquidez (bid-ask widening, volúmenes bajos) que Bloomberg puede no capturar en días de cierre de mercado. Esta es una limitación no declarada del control de datos.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**manual_VaR_FRTB.md** dice:
> No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.

**perfil_datos_VaR.md** dice:
> Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.34 [MEDIA] El manual afirma que la justificación de la ventana de 500 días existe en el anexo C, pero dicho anexo no está disponible para validación independiente. No se puede verificar si el análisis fue riguroso, qué rangos de ventanas se probaron, o si el criterio de rechazo ("encima del intervalo de Kupiec") fue correctamente aplicado. Riesgo: la validación de segunda línea no puede contrastar el fundamento empírico de un parámetro clave del modelo.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**contexto_disponible** dice:
> Anexo C no está incluido en el contexto disponible para auditoría.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.35 [MEDIA] La justificación de la ventana de 500 días remite a un anexo C que no está disponible para validación. Se declara un resultado («excedencias por encima del intervalo») sin cifras de apoyo: ¿cuál era la tasa observada con 250 días? ¿cuál el intervalo de Kupiec esperado? Sin estos datos, la afirmación no es verificable. La ventana podría estar sobredimensionada (500 >> 250) sin justificación cuantitativa sobre por qué 500 es óptima y no 375 o 600.

*Ámbito: Metodología · Actividad: Revisión de los lineamiento internacionales o nacionales*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**manual_VaR_FRTB.md** dice:
> Control de cambios en anexo A. [No se proporciona el anexo C en el contexto disponible]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.36 [MEDIA] El manual declara que Christoffersen se ejecuta mensualmente, pero el informe de Q1 2026 solo reporta un resultado binario ('no se detecta agrupamiento'), sin proporcionar el estadístico, p-valor, o criterio de rechazo usado. No hay trazabilidad de la prueba.

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

**backtesting_VaR_2026Q1.md** dice:
> Christoffersen: no se detecta agrupamiento de excedencias.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.37 [MEDIA] El manual establece que Christoffersen es una prueba a ejecutar mensualmente, pero en el informe de Q1 solo se reporta la conclusión cualitativa ('no se detecta agrupamiento') sin proporcionar el estadístico de prueba, p-valor, o rango de confianza. Esto imposibilita que un validador independiente verifique si la prueba fue realmente ejecutada según el estándar de Christoffersen (que mide tanto la probabilidad incondicional como la probabilidad condicional de excedencias). Una 'no detección' verbal no es equivalente a un resultado estadístico documentado.

*Ámbito: Metodología · Actividad: Analizar el seguimeinto de la metodología*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

**backtesting_VaR_2026Q1.md** dice:
> Christoffersen: no se detecta agrupamiento de excedencias.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.38 [MEDIA] La justificación de la elección metodológica (ventana 500 vs 250) se remite a un anexo no incluido. Sin acceso a ese análisis, no se puede validar si la decisión está fundamentada empíricamente o es una afirmación. La justificación que aparece en el manual («ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec») es una aseveración sin respaldo verificable en el contexto.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**CONTEXTO DISPONIBLE** dice:
> El anexo C (estudio de sensibilidad) no se incluyó en el contexto disponible.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.39 [MEDIA] El código implementa una ventana de 500 días. El marco FRTB/Basilea estándar especifica ventanas de evaluación de 250 días para backtesting de VaR. No se encuentra en el contexto justificación de por qué se desviá de esta práctica estándar ni aclaración de si la ventana de 500 días se aplica solo al cálculo histórico o también al backtesting de verificación. Esto afecta la comparabilidad de resultados de backtesting contra benchmarks regulatorios.

*Ámbito: Uso e integración a la gestión · Actividad: Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo*

**calcula_var.py** dice:
> "Ventana de 500 días según manual metodológico §2."

**Contexto FRTB (Literatura de dominio, no modelo)** dice:
> "El marco supervisor establece una clasificación por número de excedencias observadas en 250 días de negociación con un VaR al 99%."

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.40 [BAJA] Coherencia encontrada: el código refleja correctamente lo documentado en el manual. NO hay code drift en este parámetro. Pero esto es lo MÍNIMO esperado y no compensa las ausencias en ejecución y conformidad.

*Ámbito: Implementación · Actividad: Vericar existencias de correos de comunicación de resultados y su conformidad*

**calcula_var.py (docstring)** dice:
> "VaR histórico. Ventana de 500 días según manual metodológico §2."

**manual_VaR_FRTB.md (sección 2)** dice:
> "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día."

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

## 3. Cuestionamiento metodológico

Un modelo puede documentar impecablemente una elección equivocada. Esto
no evalúa si la metodología está descrita, sino si está **justificada**.

### Verificar la existencia, suficiencia y claridad de la documentación

La justificación de la ventana de 500 días se basa en el criterio de evitar excedencias fuera del intervalo de Kupiec (parámetro de bondad de ajuste), lo cual es coherente con la práctica estándar de backtesting regulatorio. Sin embargo: (1) No se documenta en el contexto disponible qué alternativas se evaluaron (ej. 250, 375, 625 días) ni cómo se calibró el trade-off entre estabilidad del estimador y reactividad a cambios de régimen. (2) El manual declara que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec» pero no especifica si esto ocurrió en todos los períodos de prueba, en qué magnitud, o si se aceptó por falta de datos o por deficiencia metodológica. (3) La elección del histórico (no GARCH, no Monte Carlo) no está justificada frente a alternativas. (4) Los supuestos subyacentes —estacionariedad de retornos, ausencia de cambios estructurales dentro de la ventana de 500 días, no autocorrelación— no aparecen explícitamente verificados ni documentados en el informe de seguimiento. (5) El test de Christoffersen reporta «no se detecta agrupamiento» pero no se incluyen los estadísticos específicos (test LR de independencia) ni el p-valor, lo que impide verificar si el resultado es marginal o robusto. Sin el anexo C ni el código de validación de supuestos, la metodología permanece parcialmente injustificada desde el punto de vista de la auditoría independiente.

### Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

El manual justifica la metodología (VaR histórico con ventana de 500 días) mediante un estudio de sensibilidad que no está disponible en el contexto, lo que impide evaluar si la justificación es robusta o si el análisis fue exhaustivo. Se menciona que ventanas menores a 250 días producían 'excedencias por encima del intervalo de Kupiec', pero no se explicita: (1) cómo se definió ese intervalo (¿es el intervalo de aceptación de Basilea del 4-16 excepciones en ~250 días?); (2) por qué la solución fue aumentar a 500 y no a 250-350 días; (3) si se evaluaron trade-offs entre estabilidad de la estimación (ventana más larga) y adaptabilidad a cambios de régimen (ventana más corta). Sobre la elección de Kupiec y Christoffersen: el manual no documenta por qué no se incluye el test de López (que evalúa la independencia temporal de excedencias de forma alternativa) ni el test de Berkowitz (que contrasta todo el rango de cuantiles, no solo el 99%). Esta omisión es parcialmente coherente con la literatura estándar —Kupiec y Christoffersen son los test de referencia FRTB—, pero debería declararse explícitamente por qué se descartan otras pruebas. Sobre supuestos: no se verifica ni se documenta si el histórico de 500 días cumple supuestos de estacionariedad o si se realiza análisis de estabilidad de parámetros en subperíodos. El manual declara limitaciones (no captura riesgo de liquidez, se complementa con ES) pero no cuantifica cómo esas limitaciones impactan la cobertura real del modelo, ni cómo se monitorean.

### Verificar que no exista suficiencia de controles de calidad de datos (integridad)

Sobre el tratamiento de missing values: (1) Por qué 'último valor conocido' y no exclusión de la ventana, interpolación, o media móvil? ¿Se justificó esta elección contra alternativas o se asumió como estándar? (2) ¿Se verificó que 0.4% está distribuido aleatoriamente (MCAR) o hay patronización (MAR/MNAR) — ej., mercados cerrados sistemáticos? Si es MNAR, forward fill introduce sesgo estructural. (3) El manual cita un 'estudio de sensibilidad del anexo C' para justificar 500 días vs 250, pero ese anexo no está en el contexto. Sin verlo, no se puede evaluar si: la sensibilidad incluyó escenarios con datos imputados, si se contrastó el riesgo de ventanas más cortas contra más largas (sesgo de estimación vs riesgo de cambio de régimen), o si la decisión responde a un óptimo estadístico o es arbitraria. (4) ¿Se valida que los datos de Bloomberg no tengan duplicados de fecha pero sí duplicados de registro (ej., cierre y ajuste)? La afirmación 'Sin duplicados de fecha' no descarta duplicados de VALOR en la misma fecha (fat-finger, correcciones sin marca).

### Revisar la existencia de reportes de incidencia, monitorio de calidad de datos (entradas y salidas)

No aplica — esta actividad es de control operativo, no de metodología. Sin embargo, el tratamiento de valores ausentes SÍ tiene componente metodológico: la elección de LOCF introduce sesgo en direcciones distintas según la causa de la ausencia (MCAR vs MAR vs MNAR). ¿Bajo qué criterio se descartaron alternativas como exclusión de observaciones, forward-fill, media móvil, o interpolación lineal? ¿Se evaluó el impacto en la volatilidad estimada y por tanto en el VaR? Sin eso, es una decisión operativa sin fundamento técnico explícito.

### Verificar que no exista duplicados sobre los inputs que estén en el alcance de validación

No aplica a este ámbito (Calidad de Datos, no Metodología). Sin embargo, se señala que: (1) la elección de 'último valor conocido' para imputación en series de precios diarias es común pero no es neutra: puede sesgos hacia baja volatilidad en períodos con datos incompletos. Falta análisis de sensibilidad; (2) el manual justifica la ventana de 500 días porque 'ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec', pero no declara cómo se validó que los datos de entrada (después de imputación) cumplían los supuestos del test de Kupiec (independencia, distribución estable). Esto toca Metodología y debería estar resuelto antes de validar inputs.

### Verificar la consistencia de las variables más importantes en el alcance de validación (Missing, outlier)

1. **Por qué forward fill y no alternativa**: El perfil de datos declara la imputación por «último valor conocido», pero no justifica por qué se rechazó exclusión de observaciones incompletas, interpolación lineal o métodos basados en volatilidad condicional. En mercados con saltos de régimen, forward fill propaga un valor obsoleto y puede sesgar la cola izquierda de retornos (crítica para VaR al 99%). 2. **Supuestos no verificados**: La metodología asume que los 500 retornos son i.i.d. para Kupiec, pero con forward fill, hay autocorrelación inducida que viola ese supuesto y reduce la potencia del test. Esto no se declara. 3. **Falta definición de outliers**: El manual no define qué se considera outlier en esta cartera. Z-score, IQR o percentiles son métodos comunes, pero la elección depende de si la cartera tiene colas pesadas, sesgos o asimetría. Sin diagnóstico previo, no hay base para elegir un criterio. 4. **Validez del período de datos**: 500 observaciones diarias = ~2 años. ¿Son esos 2 años representativos de la exposición actual? ¿Se verificó estacionariedad o cambios de régimen? El manual no lo menciona.

### Verificar la actualización de los inputs

No aplica a esta actividad (Calidad de Datos). Sin embargo, nota que el cuestionamiento sobre la ventana de 500 días (metodología) depende de que el anexo C haya sido realizado sobre datos validados; la ausencia de script de replicación de datos impide auditar incluso la metodología principal.

### Existencia de buenas prácticas en el enfoque metodológico

1. **¿Por qué VaR histórico y no alternativas?** El manual NO justifica la elección de VaR histórico frente a métodos paramétricos (RiskMetrics, GARCH), simulación de Montecarlo, o enfoques ML. Una cartera FRTB de negociación puede tener no-linealidades (opciones, curvaturas) que el VaR histórico simple captura débilmente. La ausencia de comparación o justificación de descarte es crítica en una actividad de Metodología. 2. **Supuestos no validados:** El método histórico asume retornos estacionarios e independientes en el tiempo. El manual NO declara si se validó estacionariedad (test ADF/KPSS) ni independencia (ACF/Ljung-Box). Con una ventana de 500 días (aprox. 2 años) y potenciales cambios de régimen (volatilidad, estructura de mercado), la estacionariedad es un supuesto fuerte que merece prueba explícita. 3. **Nivel de confianza 99%:** El manual declara 99% por exigencia FRTB/Basilea III, pero no argumenta localmente si ése es el nivel apropiado para ESTA cartera, ESTE horizonte de 1 día, o ESTE apetito de riesgo. ¿Fue comparado contra backtesting histórico interno o requerimientos de negociación? 4. **Análisis de sensibilidad parcialmente documentado:** El anexo C menciona ventanas probadas, pero no se incluye. Criterios que faltan en la descripción: (a) ¿se probaron ventanas en pasos regulares (250, 350, 450, 500, 600) o ad-hoc?; (b) ¿el criterio de aceptación fue p>0.05 en Kupiec o se usó otra métrica?; (c) ¿se validó Christoffersen también para cada ventana o solo Kupiec?; (d) ¿se consideró el trade-off entre data reciente (menor ventana) vs data representativa (mayor ventana)?. 5. **Ausencia de López test:** El backtesting reporta Kupiec (cobertura incondicional) y Christoffersen (agrupamiento de excedencias). López (1999) propone una prueba adicional de independencia ponderada por magnitud. Su ausencia no es incumplimiento formal (Basilea III prioriza Kupiec + Christoffersen), pero representa incompletitud en diagnosticar debilidades de clustering. 6. **Ventana fija vs adaptativa:** ¿Por qué una ventana de 500 días fija? En contextos de volatilidad cambiante (2024-2025 con variabilidad en mercados de tasas y energía), ¿se evaluó si una ventana adaptativa (weighted historical, GARCH) sería más sensible a cambios de riesgo recientes?

### Validar supuestos y consideración más importantes de la técnica utilizada

1. **Justificación de la ventana de 500 días:** El manual cita un 'estudio de sensibilidad del anexo C' pero ese anexo no está disponible en el contexto. Sin verlo, no se puede validar si la cifra es empíricamente sostenida o si se descartaron alternativas con justificación rigurosa. Pregunta crítica: ¿por qué 500 y no 750 o 1000? ¿Cuál fue el criterio de optimización (error mínimo, varianza mínima de VaR, balance entre estabilidad y reactividad)? 2. **Adecuación del método histórico bajo FRTB:** El marco FRTB reemplaza supuestos uniformes (incluido horizonte de 1 día) por categorías dinámicas de liquidez. El manual no justifica por qué un VaR histórico con horizonte fijo de 1 día es metodológicamente apropiado bajo FRTB, ni cómo se diferencia su función respecto del ES por horizontes de liquidez que FRTB prescribe. 3. **Validación de supuestos no documentada:** El método histórico no asume distribución paramétrica, pero sí asume estacionariedad, independencia y ausencia de cambios de régimen. Ninguno de estos supuestos se contrastó en la documentación: no hay test de Dickey-Fuller, no hay autocorrelograma de excedencias, no hay análisis de clusters temporales más allá del p-valor de Christoffersen. 4. **Potencia estadística del backtesting:** Con 62 observaciones y nivel 99%, el número esperado de excedencias es 0.62; observar 3 da un p-valor de 0.051. La literatura estándar (Kupiec) reconoce que con muestras cortas (< 250 obs) la potencia es muy baja. El manual NO declara esta limitación, ni interpreta si el p-valor marginal es indicador de validación o simplemente de insuficiencia muestral. 5. **Análisis de excedencias individuales:** La literatura sobre backtesting (fragmento recuperado) enfatiza que explicar cada excedencia es 'evidencia de validación tan relevante como el estadístico agregado'. El manual no reporta qué ocurrió en esos 3 días, qué factores de mercado las causaron, si eran predecibles ex-ante, o si indicaban dinámicas de cola o cambios de régimen. Sin esto, el resultado estadístico es hueco. 6. **Comparación con modelos alternativos:** No hay evidencia de que se hayan considerado alternativas (VaR paramétrico con EWMA, VaR por simulación de Monte Carlo, quantiles dinámicos). Si 'histórico' fue la opción elegida, ¿por qué no otras? ¿Se descartaron por inadecuación teórica, por falta de potencia en backtesting, o por simplicidad computacional?

### Revisión de los lineamiento internacionales o nacionales

1. **POR QUÉ ESTA METODOLOGÍA**: El modelo adopta VaR histórico (percentil simple) en una ventana de 500 días. El manual no explica por qué se eligió aproximación histórica frente a alternativas: ¿se descartó paramétrica (normal, t-Student) por falta de normalidad? ¿GARCH por complejidad? ¿Simulación de Montecarlo por sensibilidad a supuestos de dependencia?. Sin un análisis comparativo documentado, la elección parece por defecto, no por decisión técnica.

2. **SUPUESTOS NO VERIFICADOS**: VaR histórico asume estacionariedad de la distribución de retornos en la ventana de 500 días. El manual no presenta: (a) test de estacionariedad (ADF, KPSS), (b) análisis de quiebres estructurales (Chow), (c) validación de normalidad / colas pesadas (KS, Anderson-Darling), (d) verificación de autocorrelación (si la cartera tiene exposiciones intraday sin horizon gap, esto es crítico). Sin estas pruebas, no se documenta que el método sea válido para ESTA cartera.

3. **JUSTIFICACIÓN INCOMPLETA DE LA VENTANA**: El estudio de sensibilidad afirma que ventanas <250 generan excedencias "por encima del intervalo de Kupiec", pero no dice qué pasó con 250-500, 500-750, etc. ¿Por qué no 1000 días (4 años)? La teoría de VaR histórico favorece ventanas largas para estabilidad de cuantiles; una ventana de 500 es moderada. Sin gráfico de tasa de excedencias vs ventana, la elección es arbitraria.

4. **ALTERNATIVA NO CONSIDERADA EXPLÍCITAMENTE**: El marco FRTB acepta modelos internos basados en ES (Expected Shortfall), no solo VaR. El manual implementa VaR pero no compara resultado con ES al 97.5% usando la misma ventana. Si ES y VaR dan señales divergentes, la documentación debería reconciliarlas. Sin esto, falta verificar que VaR es el estadístico correcto para ESTA cartera bajo FRTB (posiblemente ES es lo regulatorio, VaR lo complementario).

5. **PRUEBA DE LÓPEZ AUSENTE**: Kupiec y Christoffersen son estándares, pero López (2000) añade prueba de cobertura condicional (¿el VaR es demasiado conservador en días de baja volatilidad?). Esto es especialmente relevante en una cartera de negociación con volatilidad variable. Su ausencia no invalida el backtesting pero limita su robustez.

6. **RESULTADO MARGINAL NO RECONSIDERADO**: Kupiec da p=0.051, apenas NO rechazo al 5%. Estadísticamente, esto está en la frontera. El manual debería: (a) declarar explícitamente que es marginal, (b) fijar un plan de revisión si futuro trimestre cae por debajo de 0.05, (c) considerar incrementar tamaño muestral o reajustar ventana si el patrón persiste. Sin esto, el cumplimiento formal es verdadero (no rechaza al 5%) pero la robustez es cuestionable.

### Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

¿POR QUÉ VENTANA DE 500 DÍAS? El manual menciona que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec», pero ¿por qué no 250, 300, 375 o 750? ¿Se ejecutó un análisis de sensibilidad formal (estudio del anexo C)? ¿Cuál es el trade-off entre reactividad (ventana corta, captura cambios recientes) e historia (ventana larga, estabilidad estadística)? La elección de 500 no es estándar: RiskMetrics usa 250, y la literatura no establece una óptima universal. Sin justificación declarada, se corre riesgo de que la elección responda a comodidad computacional o herencia de otros modelos, no a optimización para esta cartera.

¿VALIDACIÓN DE SUPUESTOS DEL VaR HISTÓRICO? El manual documenta el método (histórico con ventana) pero NO declara ni valida supuestos críticos: (a) estacionariedad de retornos, (b) ausencia de cambios estructurales en los últimos 500 días, (c) suficiencia de 62 observaciones de backtesting para poder discriminar entre H0 (modelo correcto) y H1 (modelo incorrecto). La potencia estadística de Kupiec con N=62 no se reporta.

¿PAPERS CITADOS SOSTIENEN LA METODOLOGÍA? El manual referencia Kupiec (1995) de modo implícito (al nombrar la prueba Kupiec). Kupiec propone precisamente el test LR para excedencias, lo que es correcto. Christoffersen (1998) se aplica también correctamente (test de independencia). Sin embargo, la literatura advierte que ambas pruebas requieren ≥250 observaciones para potencia adecuada, y el modelo opera con 62. ¿Se revisó la potencia bajo el tamaño real?

¿QUÉ LIMITACIONES NO ESTÁN DECLARADAS? (i) El análisis de Kupiec + Christoffersen es INCONDICIONAL: no detecta si el modelo falla en ciertos regímenes de mercado (volatilidad alta, crisis). (ii) El VaR histórico asume que el pasado (últimos 500 días) es representativo del futuro, pero cambios estructurales (crack, normalizaciones de política monetaria) pueden invalidar esa premisa. (iii) N=62 es pequeño; una muestra mayor (≥250 días de backtesting equivaldría a ~1 año de datos diarios) reduciría el error de Tipo II. El manual declara en §4 que «No captura riesgo de liquidez de mercado», pero NO declara estos límites estadísticos.

¿ANÁLISIS DE EXCEDENCIAS INDIVIDUALES? Las 3 excedencias no están documentadas: ¿qué las causó? ¿Volatilidad extrema, gap de apertura, evento geopolítico? ¿Fueron bien o mal explicadas por el modelo? Un análisis narrativo de cada excedencia es evidencia tan importante como el estadístico Kupiec agregado.

### Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

¿POR QUÉ ESTA METODOLOGÍA? El modelo elige VaR histórico con ventana fija (500 días) en lugar de alternativas como modelos paramétricos (GARCH, EVT) o método de simulación de Montecarlo. El manual no justifica esta elección, solo describe la implementación. Se requiere: (a) comparación explícita con al menos un modelo alternativo, o declaración documentada de por qué se descartó; (b) evaluación de si el horizonte de 1 día con ventana de 500 días es adecuado para FRTB (que exige horizontes de liquidez variable). ¿QUÉ SUPUESTOS SE VERIFICAN? VaR histórico no supone normalidad, pero sí estacionariedad e independencia entre retornos. El manual NO reporta ningún contraste de estacionariedad (KPSS, ADF), y el backtesting de Christoffersen solo detecta dependencia *entre excedencias*, no entre retornos subyacentes. ¿CÓMO JUSTIFICA LA VENTANA? El manual cita el anexo C afirmando que ventanas <250 días producen excedencias fuera del intervalo de Kupiec, pero: ¿a qué confianza? ¿sobre cuántos períodos? ¿qué criterio exacto se usó para definir 'fuera del intervalo'? Sin esta información, la elección parece empírica pero no rigurosa. ¿SE CAPTURAN RIESGOS EXTREMOS? El manual declara que ES (Expected Shortfall) complementa el VaR para riesgo de liquidez, pero no especifica cómo se integran operacionalmente: ¿se usa ES para decisiones, o solo VaR? ¿Existen límites independientes por ES? ¿ANÁLISIS DE SENSIBILIDAD/ESCENARIOS? La actividad pide explícitamente 'análisis de sensibilidad/escenarios al modelo, inputs'. No existe documentación de: impacto de cambios en nivel de confianza (99% vs 95% vs 99.9%), horizonte (1 día vs 10 días FRTB), estructura de correlación bajo estrés, o comportamiento en regímenes de volatilidad extrema. Esto es un VACÍO crítico.

### Analizar el seguimeinto de la metodología

1. ELECCIÓN DE LA VENTANA (500 días): Se afirma que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec», pero el anexo C no está disponible. Sin el análisis numérico explícito (errores observados por ventana, estadísticos LR para cada ventana, gráficos de sensibilidad), esta decisión no se justifica, se asume. Pregunta: ¿por qué 500 específicamente y no 400 o 600? ¿Hay un trade-off documentado entre ventana y estabilidad de estimadores que se haya ignorado?

2. NORMALIDAD E INDEPENDENCIA DE RETORNOS: El método es histórico puro, pero no se documenta si se verificó que los retornos satisfacen los supuestos del enfoque (estacionariedad, ausencia de autocorrelación significativa, homoscedasticidad condicional). Para una cartera de negociación con 500 días de datos, hay riesgo de que mercados bajo estrés violen estos supuestos. El modelo no declara cuándo se volvería inválido.

3. ALTERNATIVAS DESCARTADAS: No se justifica por qué se eligió VaR histórico sobre:
   - VaR paramétrico (asume normalidad, menor data-hungry, más transparente)
   - GARCH/VaR dinámico (captura clustering de volatilidad, relevante post-estrés)
   - Hybrid o Filtered Historical Simulation (combina filtrado de volatilidad con historia)
   El documento no cita papers que sustenten histórico como superior para FRTB; simplemente lo declara.

4. HORIZONTE Y LIQUIDEZ: El manual menciona que «no captura riesgo de liquidez de mercado» y se complementa con ES. Pero en FRTB, la liquidez está explícitamente integrada en los factores de riesgo (adjusted liquidity horizons en §5.1 de BCBS 457). No está claro si el VaR de 1 día es compatible con los horizontes de liquidez de cada factor. Falta justificación de por qué 1 día es la unidad correcta para esta cartera.

5. FRECUENCIA DE REVISIÓN METODOLÓGICA: El backtesting es mensual, pero ¿cada cuánto se revisa si la metodología sigue siendo adecuada para las condiciones actuales de mercado? El contexto no documenta un plan de revisión anual o post-eventos de estrés (Basilea exige revisión periódica de modelos de riesgo; FRTB no especifica, pero la práctica estándar es anual como mínimo).

### Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos

1. ¿POR QUÉ 500 DÍAS Y NO OTRA VENTANA? El manual afirma que se eligió porque ventanas menores a 250 días producían excedencias fuera del intervalo de Kupiec, pero ese análisis no está en el contexto para verificar. ¿Se compararon también 300, 400, 750 días? ¿Cuál fue el rango analizado? ¿Por qué se eligió exactamente 500 y no 502 o 480? Sin ver el anexo C, la justificación se reduce a una declaración. 2. ¿CUÁLES FUERON LAS ALTERNATIVAS DESCARTADAS? No aparece análisis de por qué VaR histórico (ventana fija de 500) y no: (a) GARCH/volatilidad condicional (que adaptaría la ventana a períodos de estrés); (b) simulación de Montecarlo (que permitiría incorporar supuestos sobre distribuciones de colas); (c) métodos de kernel; (d) extreme value theory (EVT) para los percentiles extremos al 99%. El manual menciona que "no captura riesgo de liquidez" pero no justifica por qué se descartaron métodos que sí lo capturan. 3. ¿SE VERIFICAN LOS SUPUESTOS DEL MÉTODO? El VaR histórico asume que la distribución de retornos pasados es representativa de la futura. No hay evidencia en el contexto de: (a) test de estacionariedad sobre los retornos; (b) análisis de cambios estructurales (1 de 500 días es representativo hoy?); (c) comportamiento en colas (¿el percentil 99 es estable o varía mucho con cambios pequeños de la ventana?); (d) autocorrelación (¿los retornos de día a día son independientes, o hay clustering que invalida la asunción?). El manual no declara estos supuestos ni cómo se verifican. 4. ¿ES ESTA METODOLOGÍA ADECUADA PARA FRTB BASILEA III? El conocimiento recuperado menciona que FRTB se basa en Expected Shortfall (ES) a 10 días bajo horizontes de liquidez variables, NO en VaR histórico a 1 día. El manual describe un VaR de 1 día y reconoce que "se complementa con Expected Shortfall", pero no documenta: (a) cómo se relacionan (¿son independientes? ¿se usan en paralelo? ¿cuál prevalece?); (b) si el modelo es completo para FRTB o es una simplificación; (c) cuál es la malla de horizontes de liquidez aplicada (el conocimiento recuperado cita que FRTB asigna factores a categorías con horizontes crecientes). Aquí hay un potencial code drift normativo: ¿el modelo implementa FRTB o una aproximación anterior?

### Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)

1. **Justificación de ventana:** El manual cita un 'estudio de sensibilidad del anexo C' como fundamento para rechazar ventanas <250 días por 'excedencias por encima del intervalo de Kupiec', pero el anexo no está disponible. ¿Se comparó formalmente contra otras metodologías (p.ej., VaR GARCH, ventanas móviles de ponderación exponencial, enfoques paramétricos)? ¿Por qué histórico plano y no ponderado? El histórico plano es válido, pero la decisión de descartarlo no se demuestra. 2. **Supuestos no verificados:** VaR histórico asume que el pasado es representativo del futuro (estacionariedad). El manual NO declara si se verifica esta hipótesis, no menciona pruebas de cambio estructural, no discute cómo el modelo se comporta en períodos de crisis o colas gruesas (fat tails). FRTB requiere validación bajo estrés; no hay evidencia de que se hayan realizado pruebas de robustez. 3. **Justificación de parámetros:** Nivel de confianza 99% se asume (típico en Basilea), horizonte 1 día también asumido, pero el manual NO explica por qué ESTOS y no otros, ni cita la norma que los prescribe. Para FRTB, debería haberse referenciado explícitamente BCBS 457 o la normativa aplicable. 4. **P&L Attribution Test (PLAT) ausente:** La literatura de dominio (fuente [3]) menciona que bajo FRTB, 'una mesa puede pasar el backtesting y sin embargo estar usando un modelo que no explica su P&L'. El manual describe backtesting de Kupiec/Christoffersen (cobertura) pero NO menciona PLAT. ¿Se ha validado que el modelo explica el P&L real de la mesa? Ausencia crítica si se aspira a certificación FRTB. 5. **Non-Modellable Risk Factors (NMRF):** FRTB introduce factores que no pueden modelarse con datos observables. El manual NO menciona cómo se identifican, auditan o calculan requerimientos para NMRF. Esto es un vacío metodológico para un modelo 'FRTB'.

### Vericar existencias de correos de comunicación de resultados y su conformidad

Se declara que la ventana de 500 días fue elegida porque «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec». Esta es una afirmación de sensibilidad, pero adolece de: (1) Falta de detalle: no se especifica qué significa «excedencias por encima del intervalo»; ¿se refiere a zona roja Basilea (>10 excedencias en 250 días)? ¿O a un p-valor significativo en test de Kupiec? (2) Falta de alternativas exploradas: ¿se probaron ventanas de 300, 400, 600 días? ¿Por qué no se eligió 250 días (estándar regulatorio Basilea) si produce problemas? ¿Es el problema del modelo o de la cartera? (3) Ausencia de verificación de supuestos: el método histórico asume que la distribución de retornos pasados es estacionaria (o al menos representativa). ¿Se verificó estacionariedad en la serie de 500 días? ¿Hay cambios de régimen detectados (crisis, cambios de composición de cartera)? (4) Horizonte temporal no justificado: se declara «horizonte 1 día» bajo FRTB, pero no se justifica si es coherente con la cartera (¿es verdaderamente negociable en 1 día?) ni si la ventana histórica de 500 días es suficiente para capturar eventos extremos a ese horizonte. La metodología está DESCRITA pero no JUSTIFICADA de forma defensible.

> ✍️ **Te toca:** contrasta esto con tu criterio experto. El agente puede
> cuestionar sin conocer restricciones de negocio que sí justifican la
> elección — si es el caso, déjalo escrito en el informe final.

## 4. Información a solicitar al modelador

**181 petición(es)**, sin duplicados y ordenadas por gravedad del
control que las origina. Esta lista se envía tal cual.

| # | Ámbito | Score | Petición |
|---:|---|---:|---|
| 1 | Calidad de datos | 2/5 | ¿Existe un script de validación de datos (control de primera línea) que se ejecute antes de cada cálculo de VaR? Si existe, ¿cuál es su nombre y dónde se aloja? |
| 2 | Calidad de datos | 2/5 | ¿Qué criterios definen una observación como 'outlier' en la ventana de 500 días? ¿Se usa Z-score, IQR, MAD, o volatilidad histórica? ¿Hay umbrales documentados? |
| 3 | Calidad de datos | 2/5 | ¿Existe un log o reporte de incidencias de datos (valores missing detectados, duplicados, valores fuera de rango) del último trimestre o año? |
| 4 | Calidad de datos | 2/5 | ¿Cómo se decide si incluir o excluir una observación outlier del cálculo del VaR? ¿Quién lo autoriza? ¿Se documenta cada decisión? |
| 5 | Calidad de datos | 2/5 | ¿Se verificó que el método de imputación 'último valor conocido' no introduce sesgo en contextos de volatilidad alta o gaps prolongados (ej., puentes festivos, cierres de mercado no programados)? |
| 6 | Calidad de datos | 2/5 | ¿El informe de seguimiento que menciona 'Resultados del último trimestre' incluye una sección de validación de datos, o solo resultados del backtesting? |
| 7 | Calidad de datos | 2/5 | ¿Se ejecuta el backtesting (Kupiec/Christoffersen) sobre datos pre-validados, o se corre directo sobre los 500 datos crudos de Bloomberg? |
| 8 | Calidad de datos | 2/5 | ¿Existe un script automatizado (_replica_virf.py o equivalente) que ejecute controles de calidad sobre los datos de precios ANTES de cada corrida del VaR? Si existe, ¿cuáles son sus criterios de detección de outliers (Z-score, IQR, MAD) y cuál es el umbral de rechazo? |
| 9 | Calidad de datos | 2/5 | ¿Quién ejecuta y con qué periodicidad (diaria, semanal, mensual) el control sobre la ausencia de duplicados mencionado en el perfil de datos? |
| 10 | Calidad de datos | 2/5 | ¿Existe un reporte o log de incidencias de calidad de datos (missing, outliers detectados y remediados, cambios de proveedor Bloomberg, caídas de conectividad) con trazabilidad de: fecha del evento, descripción, impacto en el cálculo del VaR, acción remedial, y cierre? |
| 11 | Calidad de datos | 2/5 | ¿Se ha evaluado el impacto en la precisión del VaR de la imputación LOCF sobre el 0.4% de datos? ¿Existe un análisis de sensibilidad comparando VaR calculado con datos imputados vs. VaR recalculado excluyendo esas fechas, para cuantificar el sesgo introducido? |
| 12 | Calidad de datos | 2/5 | ¿Se verifica periódicamente que la serie de 500 días sea estacionaria y que no exista degradación progresiva de la calidad de los datos históricos más antiguos (ej: cambios de metodología en Bloomberg, auditorías de precios)? |
| 13 | Calidad de datos | 2/5 | ¿Existe un proceso de reconciliación entre los precios obtenidos de Bloomberg y precios alternos (ej: otros sistemas de información, confirmación con el área de Front Office), especialmente para outliers detectados? |
| 14 | Calidad de datos | 2/5 | ¿Existe un script ejecutable (Python, R, SQL) que verifique duplicados por fecha, cuente valores ausentes y reporte outliers detectados? Si existe, ¿cuál es su nombre y ruta? |
| 15 | Calidad de datos | 2/5 | ¿Cuándo se ejecutó por última vez ese script? ¿Existe log de ejecución con fecha, usuario, y resultado? |
| 16 | Calidad de datos | 2/5 | ¿Por qué se eligió imputación por 'último valor conocido' en lugar de excluir fechas con datos incompletos, interpolar, o usar métodos de EM? ¿Se comparó el impacto en el VaR de cada opción? |
| 17 | Calidad de datos | 2/5 | ¿Cómo se definen 'outliers' en esta cartera? ¿Se usan desviaciones estándar (Z-score), percentiles, o criterio experto? ¿Existe umbral documentado? |
| 18 | Calidad de datos | 2/5 | ¿La fuente Bloomberg garantiza unicidad de fecha? ¿Se han detectado duplicados históricos? ¿Existe procedimiento de resolución si los hubiera? |
| 19 | Calidad de datos | 2/5 | ¿Se verifica la integridad referencial (ej: cada ticker en la cartera tiene datos en la ventana de 500 días, o hay exclusiones documentadas)? |
| 20 | Calidad de datos | 2/5 | ¿El perfil 'sin duplicados de fecha' refiere a la cartera completa o a cada instrumento individual? ¿A qué fecha se refiere esa declaración? |
| 21 | Calidad de datos | 2/5 | ¿Existe un script (Python, R, SQL) que ejecute la validación de missing values, duplicados y outliers de forma reproducible? Si existe, ¿cuál es su nombre exacto y dónde está alojado? |
| 22 | Calidad de datos | 2/5 | ¿Qué método estadístico de detección de outliers se aplica? (ej: Z-score >3, IQR 1.5, percentiles <1% o >99%). ¿Cuántos outliers se detectaron y eliminaron en las 500 observaciones? |
| 23 | Calidad de datos | 2/5 | ¿Se analizó el patrón de los 0.4% de missing values? ¿Son aleatorios (MCAR), falta en observables (MAR) o faltan no al azar (MNAR)? ¿En qué fechas ocurren? |
| 24 | Calidad de datos | 2/5 | ¿Se comparó la distribución de retornos PRE y POST imputación? ¿Cambió la media, varianza o asimetría? ¿Se verificó que forward fill no introdujo sesgo en los percentiles extremos? |
| 25 | Calidad de datos | 2/5 | ¿Quién ejecutó la validación de datos, cuándo y con qué resultado? ¿Existe un reporte de incidencias de calidad de datos asociado a este modelo? |
| 26 | Calidad de datos | 2/5 | ¿El script de cálculo del VaR excluye el período de imputación del backtesting, o incluye observaciones con valores propagados? |
| 27 | Calidad de datos | 2/5 | ¿Existe un script de validación de datos (p.ej., _replica_virf.py, check_data_quality.py o equivalente) que se ejecute antes de cada cálculo de VaR? Si existe, ¿dónde se encuentran sus logs de ejecución y qué criterios implementa? |
| 28 | Calidad de datos | 2/5 | ¿Cuáles son los umbrales de ACEPTABILIDAD de calidad de datos? (p.ej., ¿se rechaza un ciclo si la ausencia supera X%, o siempre se imputa? ¿un outlier detectable por Z-score > 3 es revisado o automáticamente incluido?) |
| 29 | Calidad de datos | 2/5 | El perfil afirma 0.4% de ausencia: ¿es un promedio histórico, o el estado actual? ¿Se monitorea que en cada ventana de cálculo no se exceda este umbral? |
| 30 | Calidad de datos | 2/5 | ¿Se documenta el tratamiento de días con mercados cerrados o datos incompletos (p.ej., fines de semana, feriados no laborales) antes de que los retornos entren al cálculo del VaR? |
| 31 | Calidad de datos | 2/5 | ¿Existe un reporte mensual o trimestral de INCIDENCIAS DE CALIDAD DE DATOS (p.ej., retrasos de Bloomberg, valores rechazados, imputaciones realizadas) que se presente al Comité de Riesgos junto con los resultados de backtesting? |
| 32 | Calidad de datos | 2/5 | ¿Se verifica la INTEGRIDAD REFERENCIAL entre la cartera de negociación y los precios en Bloomberg (p.ej., ¿todos los instrumentos en cartera tienen precio diario, o hay gaps sistemáticos?) |
| 33 | Calidad de datos | 2/5 | El manual §2 fija la ventana en 500 días. ¿Se verifica que en cada corrida se dispone de exactamente 500 observaciones válidas, o el código permite ventanas más cortas si hay ausencias? |
| 34 | Calidad de datos | 2/5 | ¿Existe un script _replica_virf.py o equivalent que valide las 500 observaciones? Si existe, ¿dónde está alojado y cuál es su última ejecución registrada? |
| 35 | Calidad de datos | 2/5 | El anexo C que justifica la ventana de 500 días: ¿fue ejecutado sobre datos crudos (sin imputación) o sobre datos ya procesados con forward-fill? ¿Se documentó este paso? |
| 36 | Calidad de datos | 2/5 | ¿Cómo se detectan y tratan outliers en las series de retornos? ¿Se usa Z-score, IQR, métodos robustos u otro criterio? ¿Se documenta cada decisión de exclusión? |
| 37 | Calidad de datos | 2/5 | ¿Existe un protocolo de validación de precios Bloomberg (verificación de tiempos de corte, ajustes corporativos, splits, recapitalizaciones)? ¿Quién lo ejecuta y con qué periodicidad? |
| 38 | Calidad de datos | 2/5 | ¿Se verifica integridad referencial (ej. ISIN/cusip vs ponderaciones de cartera, divisa vs moneda de cotización)? ¿Existe un script o proceso documentado para esto? |
| 39 | Metodología | 2/5 | ¿Cuáles fueron los resultados específicos del estudio de sensibilidad del anexo C? Proporcionar: (a) tasa de excedencias observada para ventanas de 250, 350, 500, 750 días; (b) criterio usado para elegir 500 (ej: minimizar RMSE vs intervalo de Kupiec, balancear reactividad y estabilidad); (c) p-valores de Kupiec para cada ventana. |
| 40 | Metodología | 2/5 | El backtesting reportado cubre solo 62 días. ¿Cuál es la serie histórica completa disponible y por qué se reportan solo 62? ¿Se ejecutó backtesting rolling sobre ventanas de 250+ observaciones para evaluar consistencia temporal? |
| 41 | Metodología | 2/5 | ¿Se realizaron contrastes de normalidad, estacionariedad (ADF), independencia de retornos, o análisis de colas (curtosis, sesgo) en la serie histórica usada para el VaR? Si no, ¿por qué no? |
| 42 | Metodología | 2/5 | ¿Cuál fue la causa específica de cada una de las 3 excedencias observadas? (Ej: reversión extrema de tipos, salto de volatilidad, evento geopolítico). ¿Alguna fue predecible mediante análisis ex-ante? |
| 43 | Metodología | 2/5 | ¿Se consideraron modelos alternativos (VaR paramétrico con EWMA, simulación de Monte Carlo, cuantiles condicionales)? Si no, ¿por qué el método histórico es superior? Si sí, ¿cuál fue el resultado del backtesting comparado? |
| 44 | Metodología | 2/5 | ¿Cómo reconcilia el uso de un horizonte uniforme de 1 día con el marco FRTB que prescribe horizonte de liquidez variable por categoría de riesgo? ¿El cálculo del ES integra esos horizontes variables mientras que el VaR usa 1 día fijo? |
| 45 | Metodología | 2/5 | El manual cita que 'se complementa con Expected Shortfall'. ¿Cuál es la relación operativa entre VaR y ES en la gestión de riesgos? ¿ES se reporta al comité, retroalimenta límites, o es solo un indicador complementario sin uso en decisiones? |
| 46 | Gobierno | 2/5 | ¿Cuál es el tiering oficial asignado al modelo VaR FRTB (Tier 1, 2, 3, etc.) y en qué acta o documento formal consta? |
| 47 | Gobierno | 2/5 | ¿En qué fecha se asignó o se actualizó por última vez el tiering, y quién fue el responsable de esa decisión? |
| 48 | Gobierno | 2/5 | ¿Existe un código o identificador único del modelo en el inventario corporativo de modelos de riesgo? |
| 49 | Gobierno | 2/5 | ¿Se realizó una valoración de criticidad (por ejemplo, según SR 11-7 o equivalente local) que justifique el tiering asignado? |
| 50 | Gobierno | 2/5 | ¿Cuál es la frecuencia de revisión de tiering y cuándo se ejecutó la última revisión del modelo? |
| 51 | Implementación | 2/5 | ¿Dónde está el informe de seguimiento mencionado en §3 que contiene los resultados del backtesting Kupiec y Christoffersen del último trimestre? ¿Se ejecutó realmente o es una intención documentada? |
| 52 | Implementación | 2/5 | ¿Existe correo o acta de aprobación de primera línea (riesgos / validación interna) que certifique que el código en producción implementa correctamente el manual §2, con parámetros de ventana=500, confianza=0.99? |
| 53 | Implementación | 2/5 | ¿Hay script de validación o test unitario que verifique que los parámetros en calcula_var.py no han derivado del manual? ¿Quién y cada cuánto revisa la coherencia manual↔código? |
| 54 | Implementación | 2/5 | El manual menciona «Control de cambios en anexo A» pero el anexo A no está en el contexto disponible. ¿Existe ese registro? ¿Se documentaron cambios en la ventana desde v1.0? |
| 55 | Implementación | 2/5 | ¿Fue documentada y ejecutada una batería de UAT (pruebas de aceptación de usuario) que verificara que var_historico() entrega resultados coherentes con datos históricos reales de la cartera antes de pasar a producción? |
| 56 | Implementación | 2/5 | El comentario en código dice «según manual metodológico §2» — ¿esto se sincroniza automáticamente o es documentación manual? Si es manual, ¿cuál es el control que evita que alguien cambie [-500:] a [-250:] sin actualizar el comentario? |
| 57 | Implementación | 2/5 | ¿Dónde están los resultados del backtesting de Kupiec y Christoffersen de los últimos 3 meses? Se menciona "informe de seguimiento" pero no se proporcionó. ¿Cuántas excedencias se observaron? ¿Están dentro del intervalo de confianza del 95% de Kupiec para 250 días de datos (esperadas ~2.5 excedencias)? |
| 58 | Implementación | 2/5 | ¿El anexo A (control de cambios) y el anexo C (estudio de sensibilidad de ventanas) existen? ¿Cuándo se aprobó la implementación en `calcula_var.py` y hay correos de autorización para ambiente productivo? ¿Se ejecutaron pruebas UAT antes de mover el código a producción, y dónde está el acta de cierre? |
| 59 | Implementación | 2/5 | ¿El script `calcula_var.py` se ejecuta automáticamente en un pipeline productivo? ¿Hay un job de cron documentado, un Airflow DAG, o alguien lo corre manualmente? ¿Hay logs de ejecución, manejo de errores (ej: qué ocurre si faltan datos o hay NaN)? |
| 60 | Implementación | 2/5 | ¿Los resultados del VaR diario se reportan a qué comité y con qué frecuencia? ¿Se usan para fijar límites de posición en la cartera de negociación, o es un cálculo que existe pero no cambia decisiones? |
| 61 | Implementación | 2/5 | ¿El modelo implementa todos los componentes de FRTB (ES a 10 días, horizontes de liquidez variable, test PLAT de atribución P&L) o es una aproximación VaR 1 día que complementa en paralelo? ¿Está esto documentado en una política de gobernanza que diga cuál metodología prevalece? |
| 62 | Implementación | 2/5 | ¿Se ha validado que los retornos usados en la ventana de 500 días cumplen los supuestos de VaR histórico: estacionariedad, independencia serial, ausencia de cambios estructurales? ¿Hay un test de estacionariedad (ADF, KPSS) documentado? |
| 63 | Implementación | 2/5 | ¿Dónde está el 'informe de seguimiento' mencionado en §3 del manual? ¿Se ejecutó el backtesting de Kupiec y Christoffersen sobre datos reales de la cartera, y con qué resultados? |
| 64 | Implementación | 2/5 | ¿Está disponible el anexo C ('estudio de sensibilidad')? ¿Cuáles fueron exactamente las excedencias observadas para ventanas de 250, 375, 500 y 750 días, y cómo se aplicó el criterio de Kupiec para rechazar <250? |
| 65 | Implementación | 2/5 | ¿Se ejecutó una User Acceptance Testing (UAT) documentada antes de paso a producción? ¿Existen correos o actas de conformidad de primera línea (business/risk owner) validando los resultados iniciales? |
| 66 | Implementación | 2/5 | ¿El código implementado por el proveedor fue sometido a un Unit Testing y Integration Testing documentado? ¿Hay logs de ejecución, reportes de cobertura de código (code coverage), o trazas que demuestren que `calcula_var.py` fue ejecutado sobre datos de prueba? |
| 67 | Implementación | 2/5 | ¿Se ha realizado el P&L Attribution Test (PLAT) requerido bajo FRTB para validar que el modelo captura los factores que efectivamente mueven el P&L de la mesa? |
| 68 | Implementación | 2/5 | ¿Cómo se identifican y se asignan capital para los Non-Modellable Risk Factors (NMRF) bajo FRTB? ¿Está documentado este proceso? |
| 69 | Implementación | 2/5 | ¿Se verifica la estacionariedad de los retornos incluidos en la ventana de 500 días? ¿Se evalúa robustez del modelo a cambios estructurales o períodos de estrés de mercado? |
| 70 | Implementación | 2/5 | ¿En qué documentación se justifica la referencia a FRTB (Basilea III)? ¿Existe mapeo explícito a BCBS 457 u otra norma aplicable que prescriba nivel de confianza 99%, horizonte 1 día, etc.? |
| 71 | Implementación | 2/5 | ¿Dónde están los correos de aprobación firmados (por quién, cuándo) que avalan el paso de esta implementación a producción? Proporciona al menos un correo entre desarrollo y control de riesgos. |
| 72 | Implementación | 2/5 | ¿Se ejecutó realmente el backtesting de Kupiec y Christoffersen sobre datos de producción? Proporciona el log de ejecución (fecha, parámetros, datos, resultado del test) del último trimestre. |
| 73 | Implementación | 2/5 | ¿Cuáles fueron los resultados del backtesting Kupiec y Christoffersen en el último trimestre? Proporciona: número de excedencias observadas, p-valor de test, clasificación Basilea (zona verde/ámbar/roja), y si hubo concentración temporal de excedencias (que falsearía Christoffersen). |
| 74 | Implementación | 2/5 | ¿Existe documentación de UAT (User Acceptance Testing) para esta implementación? Proporciona: fecha de prueba, datos de prueba (sintéticos o reales), resultados esperados vs observados, y sign-off de control de calidad. |
| 75 | Implementación | 2/5 | ¿Dónde está el Anexo C del manual con el análisis de sensibilidad? Proporciona: ventanas probadas (250, 300, 400, 500, 600 días), estadístico Kupiec y p-valor para cada una, y justificación de por qué se eligió 500 días. |
| 76 | Implementación | 2/5 | ¿Se verifica periódicamente la estacionariedad y ausencia de cambios de régimen en la serie histórica de 500 días? Proporciona: método de verificación, resultados, y frecuencia de revisión. |
| 77 | Implementación | 2/5 | ¿Llegan los resultados de backtesting a algún comité (Riesgos, Cumplimiento, Directorio)? Proporciona: acta de comité donde se discutan los resultados, acciones tomadas si hay incumplimiento, y evidencia de seguimiento. |
| 78 | Implementación | 2/5 | ¿Está el código de backtesting (que ejecuta Kupiec y Christoffersen) documentado en el contexto? No se encontró `backtesting.py` o similar. ¿Existe, y dónde se ejecuta (en pipeline CI/CD, manualmente, en Tableau)? |
| 79 | Uso e integración a la gestión | 2/5 | ¿Existe un documento formal (acta de autorización, matriz RACI, o especificación de requisitos) que defina el alcance original del modelo VaR FRTB y contraste contra los usos actuales identificados en comité? |
| 80 | Uso e integración a la gestión | 2/5 | ¿Quiénes son los usuarios formales del modelo (por nombre de rol y unidad) y cuál es su responsabilidad específica en la producción, distribución y uso del reporte mensual de consumo de límites? |
| 81 | Uso e integración a la gestión | 2/5 | ¿Cuál es la especificación completa del reporte mensual de consumo de VaR: qué métricas contiene, a qué comité se presenta, quién es responsable de su generación, cuáles son los umbrales de escalonamiento si se aproximan o superan límites? |
| 82 | Uso e integración a la gestión | 2/5 | ¿Existe evidencia de que el modelo fue validado y aprobado ANTES de su puesta en operación para el cálculo de límites diarios? (Acta de cierre de validación, fecha de implementación, autorización de primera línea). |
| 83 | Uso e integración a la gestión | 2/5 | ¿Por qué se utiliza una ventana de 500 días en el código (calcula_var.py) frente al estándar de 250 días mencionado en el marco FRTB para backtesting? ¿Se aplica la ventana de 500 días solo al cálculo histórico o también a la evaluación de backtesting supervisorio? |
| 84 | Uso e integración a la gestión | 2/5 | ¿Existe un procedimiento de revisión periódica de la idoneidad del modelo para su uso como límite operativo diario? Si existe, ¿con qué frecuencia se ejecuta y cuáles fueron los resultados en los últimos dos períodos? |
| 85 | Uso e integración a la gestión | 2/5 | ¿Cuál es la fecha de inicio y de cierre de esta validación? ¿Es anterior, paralela o posterior al acta del Comité de Riesgos del 2026-04-10? |
| 86 | Uso e integración a la gestión | 2/5 | ¿Existe un documento de «Autorización de Entrada en Producción» o acta de comité que autorice el uso operativo del modelo VaR? ¿En qué fecha se tomó esa decisión? |
| 87 | Uso e integración a la gestión | 2/5 | ¿Quiénes son los usuarios finales del modelo (mesas, tesorería, riesgos, comités de límites)? Proporcionar matriz de usuarios-casos-de-uso. |
| 88 | Uso e integración a la gestión | 2/5 | ¿El manual metodológico §2 especifica una ventana de 250 o de 500 días? Proporcionar copia de esa sección para verificar consistencia con `calcula_var.py`. |
| 89 | Uso e integración a la gestión | 2/5 | ¿Existe un reporte de reconciliación que compare los outputs del VaR en producción contra los calculados en el ambiente de desarrollo o validación en la misma fecha? (Esto verificaría que no hubo cambios de código no documentados entre desarrollo y producción.) |
| 90 | Uso e integración a la gestión | 2/5 | ¿Se ejecutó backtesting sobre los P&L observados en los meses en que el modelo estuvo operativo? Si es así, ¿cuál fue el resultado (número de excedencias, test de Kupiec, test de independencia)? |
| 91 | Uso e integración a la gestión | 2/5 | ¿Está documentada la decisión de continuar usando el modelo durante la validación, o se decidió detener su uso hasta que la validación concluyera? ¿En dónde consta esa decisión? |
| 92 | Uso e integración a la gestión | 2/5 | ¿Dónde está el manual metodológico §2 que describe la ventana de 500 días? ¿Esa ventana fue explícitamente autorizada en la validación original, o es una desviación? |
| 93 | Uso e integración a la gestión | 2/5 | ¿Cuáles son TODOS los usuarios del modelo VaR FRTB identificados formalmente (traders, riesgos, compliance, CFO, otros)? ¿Existe un documento que liste roles y usos específicos? |
| 94 | Uso e integración a la gestión | 2/5 | ¿Existen reportes reales de consumo de VaR presentados al Comité de Riesgos en 2026? ¿Cuál es la fecha, los datos incluidos, y quién los firmar o validó? |
| 95 | Uso e integración a la gestión | 2/5 | ¿El código en producción (calcula_var.py) es exactamente el código que fue validado y aprobado? ¿Hay auditoría de despliegue, versioning o hash criptográfico que lo demuestre? |
| 96 | Uso e integración a la gestión | 2/5 | ¿Se ejecuta backtesting de los reportes entregados al comité? ¿Se comparan las previsiones de VaR contra lo realizado (P&L hipotético)? ¿Dónde están los resultados? |
| 97 | Uso e integración a la gestión | 2/5 | ¿Se ha verificado que los outputs que el comité recibe en los reportes mensuales proceden exactamente del código validado, o podría haber postprocesamiento, ajustes manuales o versiones alternativas? |
| 98 | Uso e integración a la gestión | 2/5 | ¿Existe el manual metodológico §2 que califica a la ventana de 500 días? ¿Qué especifica exactamente sobre la longitud de la ventana para VaR histórico y con qué justificación se eligió 500 vs alternativas (250, 750, 1000 días)? |
| 99 | Uso e integración a la gestión | 2/5 | ¿Se ejecuta backtesting sobre el modelo VaR operativo? Si existe, ¿con qué frecuencia, sobre qué P&L (hipotético o real), y qué criterios estadísticos se aplican (Kupiec, Christoffersen, López)? |
| 100 | Uso e integración a la gestión | 2/5 | ¿Qué reportes sobre validación del modelo (excedencias, cobertura empírica, tasa de fallo) se presentan al Comité de Riesgos, y con qué frecuencia? |
| 101 | Uso e integración a la gestión | 2/5 | ¿Existe una comparación entre outputs de VaR en desarrollo vs producción? ¿Se realiza alguna verificación de que los datos de entrada, transformaciones y salidas sean idénticos entre ambos entornos? |
| 102 | Uso e integración a la gestión | 2/5 | ¿Se identifican formalmente los usuarios del modelo (áreas operativas, riesgos, tesorería) y sus casos de uso específicos? ¿Existe documentación que especifique qué decisiones se toman basadas en este VaR? |
| 103 | Uso e integración a la gestión | 2/5 | ¿Existe un protocolo documentado para actuar cuando se observan excedencias del VaR? ¿Se investiga cada excedencia, se documentan las causas y se escalan las anomalías? |
| 104 | Uso e integración a la gestión | 2/5 | ¿El nivel de confianza del 99% utilizado en el código está justificado por regulación aplicable (FRTB, Basilea III), o es una elección sin documentación de su racionalidad? |
| 105 | Uso e integración a la gestión | 2/5 | ¿Existe el manual metodológico §2 referenciado en calcula_var.py? ¿Qué especifica exactamente sobre la ventana temporal para el cálculo del VaR histórico? |
| 106 | Uso e integración a la gestión | 2/5 | ¿Quiénes son los usuarios formalmente designados del modelo VaR (tesorería, mesa de negociación, riesgo, etc.)? ¿Existen fichas de usuario o un registro de responsabilidades? |
| 107 | Uso e integración a la gestión | 2/5 | ¿Qué formato tiene el reporte mensual de VaR al Comité de Riesgos? ¿Se proporciona una muestra de dos reportes consecutivos (p.ej., Q1 2026 y Q2 2026) que demuestre continuidad y trazabilidad? |
| 108 | Uso e integración a la gestión | 2/5 | ¿Cómo se garantiza que los outputs de calcula_var.py en producción son idénticos a los generados en el ambiente de desarrollo? ¿Existe un control de versión o un log de ejecución con timestamps? |
| 109 | Uso e integración a la gestión | 2/5 | ¿Qué acciones se tomaron en los períodos donde el consumo de VaR se aproximó o excedió límites? ¿Existe un registro de excepciones y sus resoluciones? |
| 110 | Uso e integración a la gestión | 2/5 | ¿El backtesting del VaR (contraste de excedencias vs predicciones) se ha ejecutado y reportado al Comité? Si existe, ¿cuáles son los resultados y su periodicidad de revisión? |
| 111 | Documentación | 3/5 | ¿Cuál es el contenido efectivo del anexo A (Control de cambios)? Específicamente: (a) ¿qué cambios se han realizado desde v1.0?, (b) ¿quién autorizó cada cambio y cuándo?, (c) ¿existe un registro de versiones anteriores o de rechazos de cambios propuestos? |
| 112 | Documentación | 3/5 | ¿Existe un procedimiento documentado para el control de cambios que defina cuándo se requiere versión nueva, quién autoriza, y cuál es el proceso de aprobación (primera línea, comité, supervisor)? |
| 113 | Documentación | 3/5 | ¿Cuál es el contenido del anexo C (estudio de sensibilidad)? ¿Qué conclusiones sustenta sobre la elección de 500 días vs 250 días, y cómo se contrastó ese análisis contra Kupiec? |
| 114 | Documentación | 3/5 | En el informe de backtesting de 2026 Q1, ¿qué versión del manual estaba vigente al momento de ejecutar el cálculo? ¿Hay un registro que vincule fecha de ejecución con versión aplicada? |
| 115 | Documentación | 3/5 | ¿Se ejecuta el backtesting realmente de forma mensual (como declara el manual) o trimestral (como sugiere el informe de Q1)? Si hay diferencia, ¿quién la autorizó? |
| 116 | Documentación | 3/5 | ¿El repositorio de código (si existe) tiene control de versiones (git, svn) vinculado con las versiones del manual? ¿Se rastrean cambios en parámetros, fórmulas o lógica? |
| 117 | Documentación | 3/5 | ¿Existe evidencia de que el Comité de Riesgos ha revisado o aprobado versiones posteriores a v1.0, o v1.0 sigue siendo la única versión vigente desde 2026-03-15? |
| 118 | Documentación | 3/5 | ¿Existe una sección en el manual metodológico que identifique explícitamente los usuarios del modelo (ej: mesas, comité de riesgos, supervisores, tesorería) y sus responsabilidades en la aplicación? |
| 119 | Documentación | 3/5 | ¿Se documenta en qué decisiones operativas se usa el VaR estimado? (ej: ¿vinculación a límites por línea de negocio?, ¿entrada en procesos de escalada automática?, ¿requerimientos de capital) |
| 120 | Documentación | 3/5 | ¿Existe un registro de cambios o matriz de trazabilidad que vincule decisiones de gobernanza (aprobación en comités, cambios de parámetros) con versiones del manual? |
| 121 | Documentación | 3/5 | ¿Quién es responsable de revisar diariamente los resultados del backtesting y de ejecutar las acciones correctivas en caso de excedencias? |
| 122 | Documentación | 3/5 | ¿Se puede proporcionar el anexo A del manual (control de cambios) para verificar el historial completo de versiones, justificaciones de cambios y aprobaciones formales? |
| 123 | Documentación | 3/5 | ¿Existieron versiones anteriores a v1.0? Si sí, ¿cuál fue la razón técnica o regulatoria del cambio y quién autorizó la transición? |
| 124 | Documentación | 3/5 | ¿El control de cambios se revisa y documenta en cada ciclo de backtesting mensual, o solo ante cambios estructurales? ¿Existe un proceso formal de control de cambios operativo o es solo documental? |
| 125 | Documentación | 3/5 | ¿Existe un manual operativo o documento de procedimientos que detalle paso a paso cómo se ejecutan Kupiec y Christoffersen, quién lo ejecuta, con qué frecuencia exacta, y a qué órgano de gobierno se reportan los resultados? |
| 126 | Documentación | 3/5 | ¿El 'estudio de sensibilidad del anexo C' está disponible y documenta comparativamente cómo ventanas de 250, 350, 400 y 500 días se desempeñan bajo Kupiec? ¿Qué criterio se utilizó para seleccionar 500 frente a alternativas? |
| 127 | Documentación | 3/5 | ¿Existe análisis de cada una de las 3 excedencias observadas en Q1 2026 que explique qué evento o movimiento de mercado las generó, y si el modelo capturó correctamente el riesgo subyacente? |
| 128 | Documentación | 3/5 | ¿Se documentó el tratamiento de faltantes, días con mercados cerrados, o datos incompletos en el período de los 62 días de backtesting del Q1 2026? |
| 129 | Documentación | 3/5 | ¿Existe un proceso de monitoreo de calidad de datos para la ventana histórica de 500 días antes de incluirla en el cálculo? ¿Qué criterios se aplican y con qué frecuencia se revisa? |
| 130 | Documentación | 3/5 | ¿Se ha ejecutado un análisis de potencia de las pruebas Kupiec y Christoffersen con muestra de 62 días? ¿Qué es el tamaño de muestra mínimo recomendado para conclusiones robustas? |
| 131 | Documentación | 3/5 | ¿El backtesting se ejecuta y reporta mensualmente como se declara en §3, o solo trimestralmente como sugiere 'último trimestre'? ¿Existe registro histórico de resultados mensuales? |
| 132 | Metodología | 3/5 | ¿Está disponible el Anexo C (estudio de sensibilidad) para auditoría? Se requiere verificar: rango de ventanas probadas, criterios de aceptación/rechazo, resultados de Kupiec para cada ventana, y justificación de por qué se eligió 500 vs otras opciones. |
| 133 | Metodología | 3/5 | ¿Se realizaron pruebas de estacionariedad (ADF/KPSS) o independencia (ACF/Ljung-Box) sobre la serie de retornos utilizada? Si no, ¿por qué se considera válido asumir estas propiedades sin verificación? |
| 134 | Metodología | 3/5 | ¿Por qué se eligió VaR histórico frente a alternativas (paramétrico, GARCH, simulación de Montecarlo)? ¿Se descartó explícitamente algún método? ¿Hay análisis comparativo de exactitud o cobertura entre métodos? |
| 135 | Metodología | 3/5 | ¿Se ejecuta el test de López (independencia ponderada de excedencias) de forma regular, o se prevé implementarlo? ¿Por qué fue descartado si es práctica estándar complementaria? |
| 136 | Metodología | 3/5 | ¿El nivel de confianza 99% fue elegido por regulación FRTB, o se validó internamente que es apropiado para esta cartera y horizonte de 1 día? ¿Existe análisis de impacto de cambiar a 97.5% o 99.5%? |
| 137 | Metodología | 3/5 | ¿Los resultados de backtesting mensual (Kupiec + Christoffersen) se escalan a un Comité de Riesgos o a instancia de decisión? ¿Qué acciones se toman si p-valor cae en zona amarilla (entre 0.05 y 0.10)? ¿Existe documentación de estas decisiones? |
| 138 | Metodología | 3/5 | ¿Cuál es el contenido detallado del estudio de sensibilidad del anexo C? Específicamente: (a) tasas de excedencias observadas para ventanas de 250, 375, 500, 750, 1000 días, (b) intervalos de Kupiec esperados para cada una, (c) criterio de selección de 500 frente a opciones contiguas. |
| 139 | Metodología | 3/5 | ¿Se ha ejecutado contraste de estacionariedad (ADF, KPSS) sobre los retornos en la ventana de 500 días? ¿Hay presencia de quiebres estructurales detectados (test de Chow)? |
| 140 | Metodología | 3/5 | ¿Se ha comparado VaR histórico con un modelo paramétrico (normal o t-Student) o GARCH sobre la misma cartera y ventana? ¿Por qué se descartó la alternativa? |
| 141 | Metodología | 3/5 | ¿Cómo se articula la métrica VaR con el marco FRTB en la presentación regulatoria? ¿Se reporta al supervisor bajo la métrica Expected Shortfall al 97.5% (requerida por BCBS 457) o bajo VaR al 99%? |
| 142 | Metodología | 3/5 | ¿Se ha calculado Expected Shortfall al 97.5% sobre la misma cartera y ventana? ¿Los resultados ES vs VaR convergen o divergen significativamente? |
| 143 | Metodología | 3/5 | Dado que Kupiec arroja p=0.051 (marginal), ¿existe un procedimiento documentado para revisión inmediata si el próximo trimestre da p<0.05? ¿Cuál es el umbral de reajuste de parámetros? |
| 144 | Metodología | 3/5 | ¿Se ejecuta backtesting de López (cobertura condicional) o equivalente, para verificar que el VaR no es excesivamente conservador en regímenes de baja volatilidad? |
| 145 | Metodología | 3/5 | ¿La cartera tiene componentes con riesgo de liquidez significativo no capturado por VaR? ¿Cómo se cuantifica y escala el ES complementario mencionado en el manual? |
| 146 | Metodología | 3/5 | ¿Dónde está el anexo C mencionado en el manual (§2, 'estudio de sensibilidad')? Se requiere verificar la justificación formal de la ventana de 500 días vs. alternativas. |
| 147 | Metodología | 3/5 | ¿Cuál es la potencia estadística esperada del test de Kupiec con N=62 observaciones para el nivel de confianza 99%? ¿Se evaluó si ese tamaño es suficiente o está en zona de riesgo? |
| 148 | Metodología | 3/5 | ¿Existen contrastes de normalidad, estacionariedad o cambios estructurales sobre la serie de retornos de los últimos 500 días? Se requiere verificar si los supuestos del VaR histórico se validan. |
| 149 | Metodología | 3/5 | ¿Se ha ejecutado backtesting del Expected Shortfall (ES al 97.5% u otro nivel)? El manual declara que el modelo se complementa con ES, pero no hay evidencia de su validación. Bajo FRTB esto es requerido para el cálculo de capital regulatorio. |
| 150 | Metodología | 3/5 | ¿Cuál es la explicación de cada una de las 3 excedencias observadas? Se solicita análisis narrativo: fecha, cartera, factor de riesgo, magnitud, contexto de mercado. |
| 151 | Metodología | 3/5 | ¿Se ejecutó el test de López (análisis de magnitud de excedencias) o un análisis equivalente de severidad? Kupiec + Christoffersen son necesarios pero no suficientes. |
| 152 | Metodología | 3/5 | ¿Existe evidencia de que el backtesting se realiza sobre P&L hipotético (cartera congelada, sin operaciones intradía) vs. P&L real? La literatura advierte sobre mezclar ambos, que introduce ruido ajeno al modelo. |
| 153 | Metodología | 3/5 | ¿Se dispone del anexo C del manual? Se requiere acceso al estudio de sensibilidad de ventanas para verificar la elección de 500 días. |
| 154 | Metodología | 3/5 | ¿Cuál fue el criterio exacto para definir 'excedencias por encima del intervalo de Kupiec' en ventanas menores a 250 días? ¿Cuál es el intervalo de Kupiec esperado para una muestra de 62 días al 99%? |
| 155 | Metodología | 3/5 | ¿Se han realizado análisis de sensibilidad documentados sobre: (a) cambios en nivel de confianza (95%, 99%, 99.9%), (b) cambios en horizonte (1 vs 10 días), (c) análisis de escenarios de estrés (volatilidad extrema, quiebra de correlaciones)? |
| 156 | Metodología | 3/5 | ¿Por qué se eligió VaR histórico frente a modelos alternativos (paramétricos, GARCH, EVT)? ¿Se evaluaron alternativas o fue una decisión heredada? |
| 157 | Metodología | 3/5 | ¿Se han verificado supuestos de estacionariedad de los retornos (test KPSS/ADF)? ¿Se documenta cómo se tratan datos faltantes o mercados cerrados? |
| 158 | Metodología | 3/5 | ¿Se incluye explicación narrativa de cada una de las 3 excedencias observadas en Q1 2026? ¿Qué factores de mercado las originaron? |
| 159 | Metodología | 3/5 | ¿Se declara la potencia estadística de las pruebas de Kupiec y Christoffersen con una muestra de 62 días? |
| 160 | Metodología | 3/5 | ¿Cómo se integra operacionalmente el Expected Shortfall (ES) mencionado como complemento? ¿Existen límites de capital independientes por ES, o es solo informativo? |
| 161 | Metodología | 3/5 | ¿Se encuentra disponible el anexo C del manual con el estudio de sensibilidad de la ventana? ¿Contiene cifras numéricas (LR, p-valores) para ventanas de 250, 350, 400, 500, 600 días? |
| 162 | Metodología | 3/5 | ¿Cuáles son el estadístico y el p-valor exactos de la prueba de Christoffersen (no solo la conclusión)? ¿Se ejecutó usando el intervalo de confianza de (1-α)% según el estándar, y cuál fue el resultado del test de independencia (bajo H0)? |
| 163 | Metodología | 3/5 | ¿Existe un procedimiento documentado y aprobado por el Comité de Riesgos que especifique: (a) quién ejecuta backtesting mensualmente, (b) a qué plazo (en cuántos días tras el cierre mensual), (c) qué ocurre si un mes futuro excede los umbrales de Kupiec, (d) dónde se archivan los resultados? |
| 164 | Metodología | 3/5 | ¿Se han verificado empíricamente los supuestos de estacionariedad e independencia de los 500 días de retornos utilizados? ¿Existe un test de autocorrelación (Ljung-Box o similar) y un análisis de cambios de régimen? |
| 165 | Metodología | 3/5 | ¿Por qué se descartó VaR paramétrico o dinámico (GARCH) para esta cartera de negociación? ¿Hay análisis comparativo de errores de backtesting (número de excedencias) entre métodos? |
| 166 | Metodología | 3/5 | ¿Cada cuánto se revisa la metodología completa del modelo (no solo el backtesting mensual)? ¿Hay un protocolo de revisión anual o post-estrés documentado? |
| 167 | Documentación | 4/5 | ¿Se encuentra disponible el Anexo A del manual metodológico? Requiere acceso para verificar el procedimiento formal de control de cambios. |
| 168 | Documentación | 4/5 | ¿Existe al menos un ciclo de cambio documentado desde la aprobación inicial del 2026-03-15? (cambio de parámetros, justificación, autorización, fecha de implementación). |
| 169 | Documentación | 4/5 | ¿El control de cambios cubre únicamente el documento .docx/PDF del manual o también los artefactos de implementación (scripts, tablas de datos, criterios de backtesting)? |
| 170 | Documentación | 4/5 | ¿Quién es responsable de autorizar cambios? ¿Está definido el flujo de aprobación (p. ej., primera línea → Comité de Riesgos)? |
| 171 | Documentación | 4/5 | ¿Existe un registro de comunicación de cambios a usuarios/consumidores del modelo (traders, risk management, auditoría interna)? |
| 172 | Documentación | 4/5 | ¿Existe un manual operativo que describa paso a paso la ejecución del cálculo de VaR, la cadencia, los responsables, los criterios de escalada y la integración de resultados de backtesting en decisiones de gestión? (Ausencia observada: sólo se encontró manual metodológico.) |
| 173 | Documentación | 4/5 | ¿Cuál es el anexo C (estudio de sensibilidad de ventanas) al que remite el manual? ¿Se incluyó en la cobertura documental? Si no, ¿puede ser proporcionado para verificar independientemente la calibración de 500 días? |
| 174 | Documentación | 4/5 | ¿A qué comité o función se reportan los resultados mensuales de Kupiec y Christoffersen, y qué umbrales de p-valor o criterios de rechazo disparan acciones correctivas (ej. recalibración del modelo, cambio de metodología, restricción de posiciones)? |
| 175 | Documentación | 4/5 | ¿Se han verificado explícitamente los supuestos de estacionariedad y ausencia de cambios estructurales de los retornos históricos en la ventana de 500 días durante el período 2025-2026? ¿Hay evidencia de pruebas como ADF, KPSS o análisis de quiebres? |
| 176 | Documentación | 4/5 | El test de Christoffersen reporta resultado agregado. ¿Se desglosan los estadísticos LR para independencia (LR_ind) y el p-valor exacto, o se comunica solo la conclusión cualitativa? ¿Existen resultados por mesa o por factor de riesgo, o solo a nivel cartera agregada? |
| 177 | Documentación | 4/5 | ¿Se ha documentado la fecha exacta en que se ejecutó el backtesting del Q1 2026 (retrospectivamente sobre los 62 días transcurridos, o de forma prospectiva)? ¿Con qué periodicidad se recalculan las estimaciones de VaR: diaria, semanal? |
| 178 | Gobierno | 4/5 | ¿En qué fecha fue asignado el tiering actual del modelo VaR FRTB en el inventario corporativo y quién es el propietario responsable de mantenerlo? |
| 179 | Gobierno | 4/5 | ¿Existe acta formal de inventariado (no correo) con firma de quien autoriza la inclusión del modelo en el registro? |
| 180 | Gobierno | 4/5 | ¿Cuál es el nivel de tiering asignado (Tier 1, 2, 3, etc.) y cuál es la justificación formal de esa clasificación (complejidad, cobertura de cartera, horizonte regulatorio)? |
| 181 | Gobierno | 4/5 | ¿Con qué periodicidad se revisa la clasificación de tiering y cuál fue la fecha de última revisión? |

> ✍️ **Te toca:** depura antes de enviar. Algunas se responderán con un
> documento que ya existe y no llegó a `inputs/` — ésas no son hallazgos,
> son evidencia que faltó aportar.

## 5. Detalle por ámbito

### Documentación  ·  score 3.33

#### 🟡 [3/5] Verifica la existencia de control de cambios/versiones

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verificar la existencia, suficiencia y claridad del control de cambios/versiones en el Manual Metodológico VaR FRTB, como componente crítico de la gobernanza del modelo y rastreabilidad de decisiones.

**Hallazgo.**

El manual metodológico declara explícitamente la existencia de control de cambios ('Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A'), lo que evidencia la intención de mantener un registro de versiones. Sin embargo, la evidencia disponible es SOLO la mención del anexo A; el contenido efectivo del control de cambios no está presente en el contexto proporcionado. Esto genera una brecha crítica entre la afirmación de existencia y la capacidad de verificar: no puede confirmarse qué cambios se documentaron, cuándo ocurrieron, quién los autorizó, o si el proceso se ejecuta realmente. El manual también remite a un 'estudio de sensibilidad del anexo C' que justifica la elección de la ventana de 500 días, pero ese anexo tampoco está disponible. Para una segunda línea de defensa, la referencia a un anexo no es equivalente a su entrega y revisión. Se observa además que el seguimiento del backtesting (informe de 2026 Q1) no cita explícitamente qué versión del manual se aplicó, lo que impide verificar que la ejecución correspondía a la documentación vigente en ese período. Para alcanzar el siguiente nivel (4), se requeriría: (a) copia del anexo A mostrando el historial real de versiones, cambios, fechas y autorizaciones; (b) evidencia de que el control de cambios se ejecuta (logs de modificación, actas de aprobación, trazabilidad de versiones en el repositorio); (c) alineamiento explícito entre versiones documentadas y versiones aplicadas en cada ejecución de backtesting.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «(Anexo A no está presente en la cobertura documental)»
> - «(Anexo C no está presente en la cobertura documental)»

**Preguntas al modelador.**

- [ ] ¿Cuál es el contenido efectivo del anexo A (Control de cambios)? Específicamente: (a) ¿qué cambios se han realizado desde v1.0?, (b) ¿quién autorizó cada cambio y cuándo?, (c) ¿existe un registro de versiones anteriores o de rechazos de cambios propuestos?
- [ ] ¿Existe un procedimiento documentado para el control de cambios que defina cuándo se requiere versión nueva, quién autoriza, y cuál es el proceso de aprobación (primera línea, comité, supervisor)?
- [ ] ¿Cuál es el contenido del anexo C (estudio de sensibilidad)? ¿Qué conclusiones sustenta sobre la elección de 500 días vs 250 días, y cómo se contrastó ese análisis contra Kupiec?
- [ ] En el informe de backtesting de 2026 Q1, ¿qué versión del manual estaba vigente al momento de ejecutar el cálculo? ¿Hay un registro que vincule fecha de ejecución con versión aplicada?
- [ ] ¿Se ejecuta el backtesting realmente de forma mensual (como declara el manual) o trimestral (como sugiere el informe de Q1)? Si hay diferencia, ¿quién la autorizó?
- [ ] ¿El repositorio de código (si existe) tiene control de versiones (git, svn) vinculado con las versiones del manual? ¿Se rastrean cambios en parámetros, fórmulas o lógica?
- [ ] ¿Existe evidencia de que el Comité de Riesgos ha revisado o aprobado versiones posteriores a v1.0, o v1.0 sigue siendo la única versión vigente desde 2026-03-15?

**Recomendación.** Entregar copia completa del anexo A (Historial de Control de Cambios) con al menos: fecha, descripción del cambio, versión anterior y nueva, quién solicitó, quién aprobó, y acta de autorización. Documentar y ejecutar un procedimiento de control de cambios que defina: gatillos para nueva versión (cambio de metodología, hallazgo de validación, cambio regulatorio), autoridades (primera línea propone, comité aprueba, supervisor confirma), y registro permanente. Vincular explícitamente cada ejecución de backtesting con la versión del manual vigente en esa fecha. Entregar también anexo C para permitir evaluación independiente de la justificación de la ventana de 500 días.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `75416bd4a703`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verifica la inclusión del objetivo, usos y usuarios del modelo

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verifica que el manual metodológico del modelo VaR FRTB contenga de forma explícita y clara el objetivo, los usos previstos y los usuarios/stakeholders. Esta información es crítica para acotar el alcance del modelo, definir responsabilidades y validar que su diseño responda a necesidades documentadas.

**Hallazgo.**

El manual metodológico sí declara el OBJETIVO de forma explícita: 'Estimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III)'. Sin embargo, existen brechas significativas en dos de los tres elementos solicitados. USOS: El manual menciona implícitamente que se usa para backtesting regulatorio ('Se complementa con el Expected Shortfall') y alude a decisiones sobre horizontes de liquidez, pero no articula explícitamente los usos finales del VaR en la gestión de riesgos ni en qué decisiones de negociación o capital impacta. USUARIOS: No se identifica quiénes son los receptores del modelo (mesa de trading, comité de riesgos, supervisor, tesorería) ni sus responsabilidades en su aplicación. La documentación es técnicamente coherente pero operativamente incompleta. Para alcanzar nivel 4, el manual debe incluir una sección '2. Usuarios y Usos' que especifique: (a) quién consume las salidas diarias/semanales; (b) para qué decisiones concretas se utiliza (límites de riesgo, asignación de capital, escaladas); (c) qué niveles de autoridad deben revisar excepciones; (d) qué comités reciben reportes periódicos. La cobertura documental procesada es completa en el contexto proporcionado, pero el manual mismo no contiene estas secciones.

**Evidencia citada.**

> manual_VaR_FRTB.md → "## 1. Objetivo\nEstimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III)." | manual_VaR_FRTB.md → "## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual." | manual_VaR_FRTB.md → "## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 1. Objetivo\nEstimar el Value at Risk de la cartera de negociación bajo el ma»
> - «## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (»
> - «## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con»

**Preguntas al modelador.**

- [ ] ¿Existe una sección en el manual metodológico que identifique explícitamente los usuarios del modelo (ej: mesas, comité de riesgos, supervisores, tesorería) y sus responsabilidades en la aplicación?
- [ ] ¿Se documenta en qué decisiones operativas se usa el VaR estimado? (ej: ¿vinculación a límites por línea de negocio?, ¿entrada en procesos de escalada automática?, ¿requerimientos de capital)
- [ ] ¿Existe un registro de cambios o matriz de trazabilidad que vincule decisiones de gobernanza (aprobación en comités, cambios de parámetros) con versiones del manual?
- [ ] ¿Quién es responsable de revisar diariamente los resultados del backtesting y de ejecutar las acciones correctivas en caso de excedencias?

**Recomendación.** Ampliar el manual metodológico con una sección '2. Usuarios, Responsabilidades y Usos Previstos' que incluya: (1) matriz de usuarios y su función (trading, risk management, supervisión); (2) descripción de los reportes periódicos generados y sus destinatarios; (3) vínculos entre resultados del VaR y decisiones de límites/capital; (4) protocolo de escalada y revisión en caso de incumplimiento del backtesting. Esta sección debe ser revisada y aprobada en el acta del Comité de Riesgos que autoriza el manual. Sin ella, no hay evidencia de que el modelo esté integrado en la cadena de decisiones de la institución.

<sub>cobertura documental 100.0% · RAG VaR (5 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `41be2a2cd5dc`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verifica la existencia de control de cambios/versiones

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Control de versiones/cambios: verificar que el modelo documenta explícitamente qué versiones existen, cuándo cambiaron, quién aprobó y por qué. Es la trazabilidad mínima para auditoría y gobernanza de modelos.

**Hallazgo.**

El manual metodológico declara explícitamente la existencia de control de cambios ('Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A'), lo que satisface la mención del requisito. Sin embargo, el contexto disponible NO incluye el anexo A donde residiría la evidencia sustancial del control de cambios — no se proporcionó el registro de versiones, el log de cambios, las justificaciones de modificaciones anteriores ni la trazabilidad de aprobaciones. La existencia de un control de cambios en la estructura formal del documento (encabezado + referencia a anexo) es necesaria pero insuficiente: debe poder verificarse QUÉ cambió, CUÁNDO, POR QUÉ y QUIÉN autorizó. Sin acceso al anexo A, solo se confirma que el protocolo de control existe en el diseño del manual, no que se ejecute ni que esté operativo. Para elevar a puntaje 4 sería necesario proporcionar: (1) el anexo A completo con historial de versiones anteriores (si las hubiera), (2) evidencia de que cada cambio fue aprobado formalmente, (3) trazabilidad de por qué se pasó de una metodología a otra (si aplica). La cobertura documental del contexto es parcial en este punto específico.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

**Preguntas al modelador.**

- [ ] ¿Se puede proporcionar el anexo A del manual (control de cambios) para verificar el historial completo de versiones, justificaciones de cambios y aprobaciones formales?
- [ ] ¿Existieron versiones anteriores a v1.0? Si sí, ¿cuál fue la razón técnica o regulatoria del cambio y quién autorizó la transición?
- [ ] ¿El control de cambios se revisa y documenta en cada ciclo de backtesting mensual, o solo ante cambios estructurales? ¿Existe un proceso formal de control de cambios operativo o es solo documental?

**Recomendación.** Proporcionar para revisión el anexo A del manual en su totalidad. Establecer un procedimiento explícito de control de cambios que incluya: (a) registro de quién, cuándo y por qué se modifica cualquier parámetro del modelo (ventana, nivel de confianza, fórmula, criterios); (b) aprobación formal por el Comité de Riesgos antes de implementar cambios; (c) comunicación al backtesting y al seguimiento de cualquier cambio que afecte la comparabilidad histórica. Si aún no existen cambios respecto a v1.0, documentar explícitamente la fecha de vigencia del documento actual y las próximas revisiones programadas.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `687df9fe3fd9`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Validación de la existencia, suficiencia y claridad de la documentación de seguimiento y backtesting del modelo VaR Mercado FRTB, incluyendo monitoreo de calidad de datos. Este ámbito es crítico porque sin un registro ejecutado y trazable del backtesting, el modelo carece de evidencia de que sus supuestos se verifican en la práctica.

**Hallazgo.**

La documentación demuestra que existen los elementos esenciales de seguimiento: un manual metodológico con control de versiones aprobado formalmente, la mención de backtesting mediante Kupiec y Christoffersen, y un informe de resultados del Q1 2026. Sin embargo, la evaluación se ve limitada por brechas críticas que impiden concluir cumplimiento pleno. Primero, el manual_VaR_FRTB.md describe la metodología de backtesting ('Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual') pero NO proporciona evidencia de cómo se ejecuta operativamente: no existe un manual operativo que detalle el proceso paso a paso, la frecuencia exacta de ejecución, quién lo ejecuta, a qué comité se reporta, o cómo se documentan los resultados. Segundo, aunque backtesting_VaR_2026Q1.md reporta números (3 excedencias, Kupiec LR=3.81, p-valor 0.051), faltan componentes críticos según estándares de backtesting: (a) no aparece análisis de cada excedencia individual (qué evento de mercado las explica), que la literatura recuperada señala como 'evidencia de validación tan relevante como el estadístico agregado'; (b) no hay declaración de limitaciones o potencia de las pruebas con muestra de 62 días (ventana pequeña para extraer conclusiones robustas); (c) falta documentación del tratamiento de días con datos incompletos o mercados cerrados; (d) no está claro si los resultados de Q1 son los únicos o si existe seguimiento histórico que justifique la conclusión 'zona verde de Basilea'. Tercero, sobre monitoreo de calidad de datos: el manual menciona que se complementa con Expected Shortfall por limitaciones, pero no existe documento que describa cómo se monitorea la calidad de las fuentes de datos de 500 días, cómo se manejan faltantes, o qué criterios de validez se aplican antes de incluir datos en el cálculo. Cuarto, la justificación de la ventana de 500 días refiere a un 'estudio de sensibilidad del anexo C' que no aparece en el contexto disponible, creando incertidumbre sobre si esa decisión crítica está realmente respaldada por análisis documentado. Para elevar a puntaje 4 se requiere: (i) manual operativo detallado que cierre la brecha entre 'qué' (metodología) y 'cómo' (ejecución); (ii) informe de seguimiento que incluya análisis de cada excedencia, análisis de potencia y limpieza de datos; (iii) acceso o referencia clara a los análisis de sensibilidad que justifican parámetros clave; (iv) evidencia de reporte a órganos de gobierno y de acciones tomadas cuando resultados alertan. La cobertura documental es parcial: sólo se proporcionaron fragmentos de seguimiento y no se especifica si existen registros completos de ejecución, trazas de código o sistemas de control.

**Evidencia citada.**

> manual_VaR_FRTB.md → "3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.\nResultados del último trimestre en el informe de seguimiento."
>
> manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."
>
> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (ind»
> - «4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con el»

**Preguntas al modelador.**

- [ ] ¿Existe un manual operativo o documento de procedimientos que detalle paso a paso cómo se ejecutan Kupiec y Christoffersen, quién lo ejecuta, con qué frecuencia exacta, y a qué órgano de gobierno se reportan los resultados?
- [ ] ¿El 'estudio de sensibilidad del anexo C' está disponible y documenta comparativamente cómo ventanas de 250, 350, 400 y 500 días se desempeñan bajo Kupiec? ¿Qué criterio se utilizó para seleccionar 500 frente a alternativas?
- [ ] ¿Existe análisis de cada una de las 3 excedencias observadas en Q1 2026 que explique qué evento o movimiento de mercado las generó, y si el modelo capturó correctamente el riesgo subyacente?
- [ ] ¿Se documentó el tratamiento de faltantes, días con mercados cerrados, o datos incompletos en el período de los 62 días de backtesting del Q1 2026?
- [ ] ¿Existe un proceso de monitoreo de calidad de datos para la ventana histórica de 500 días antes de incluirla en el cálculo? ¿Qué criterios se aplican y con qué frecuencia se revisa?
- [ ] ¿Se ha ejecutado un análisis de potencia de las pruebas Kupiec y Christoffersen con muestra de 62 días? ¿Qué es el tamaño de muestra mínimo recomendado para conclusiones robustas?
- [ ] ¿El backtesting se ejecuta y reporta mensualmente como se declara en §3, o solo trimestralmente como sugiere 'último trimestre'? ¿Existe registro histórico de resultados mensuales?

**Recomendación.** 1. Producir un manual operativo que cierre la brecha entre la metodología (manual metodológico) y la ejecución (¿quién?, ¿cómo?, ¿cuándo?, ¿reporta dónde?). Debe incluir flujo de datos, validación, cálculo, contraste estadístico y documentación de resultados. 2. Complementar el informe de seguimiento Q1 2026 con: (a) análisis individual de las 3 excedencias (qué movimiento de mercado las explica); (b) declaración de potencia de las pruebas y limitaciones de conclusiones con n=62; (c) documentación del tratamiento de datos incompletos o faltantes. 3. Recuperar, verificar y citar el anexo C (estudio de sensibilidad de ventana). Si no existe, reproducir un análisis documentado que justifique la elección de 500 días. 4. Incorporar a la documentación: cómo se monitorea la calidad de datos de los 500 días históricos, criterios de validez y frecuencia de revisión. 5. Clarificar el plan de seguimiento: ¿es mensual o trimestral? Proporcionar o referenciar un registro histórico de resultados (al menos últimos 12 meses) para verificar consistencia del proceso.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `0c52e132ef5c`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [4/5] Verifica la existencia de control de cambios/versiones

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificar la existencia, suficiencia y claridad del control de cambios/versiones en el manual de implementación del modelo VaR Mercado FRTB. Esta es una exigencia de segundo nivel crítica para trazabilidad, gobernanza y auditoría de cambios metodológicos.

**Hallazgo.**

El manual metodológico declara explícitamente la existencia de control de versiones: 'Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A.' Esto satisface el requisito DE EXISTENCIA de un mecanismo de control. Sin embargo, el contexto disponible NO incluye el Anexo A donde se describe el procedimiento de control de cambios ni el histórico de versiones. Esto impide verificar: (i) si el control es OPERATIVO (¿se ha ejecutado algún cambio desde la aprobación inicial?), (ii) si está DOCUMENTADO ADECUADAMENTE (¿quién aprueba, qué criterios, cómo se comunica?), y (iii) si cubre TODOS los artefactos (manual operativo, scripts, datos de prueba). La evidencia demuestra INTENCIÓN y DISEÑO, pero no EJECUCIÓN o SUFICIENCIA del control. Para alcanzar puntaje 5 se requeriría acceso al Anexo A y comprobación de que ha habido al menos un ciclo de cambio documentado, autorizado y rastreable. La ausencia de esta evidencia en el contexto es una BRECHA DE COBERTURA, no un incumplimiento probado del modelo, pero representa INCERTIDUMBRE sobre la efectividad operativa del control.

**Evidencia citada.**

> manual_VaR_FRTB.md → 'Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A.'

**Preguntas al modelador.**

- [ ] ¿Se encuentra disponible el Anexo A del manual metodológico? Requiere acceso para verificar el procedimiento formal de control de cambios.
- [ ] ¿Existe al menos un ciclo de cambio documentado desde la aprobación inicial del 2026-03-15? (cambio de parámetros, justificación, autorización, fecha de implementación).
- [ ] ¿El control de cambios cubre únicamente el documento .docx/PDF del manual o también los artefactos de implementación (scripts, tablas de datos, criterios de backtesting)?
- [ ] ¿Quién es responsable de autorizar cambios? ¿Está definido el flujo de aprobación (p. ej., primera línea → Comité de Riesgos)?
- [ ] ¿Existe un registro de comunicación de cambios a usuarios/consumidores del modelo (traders, risk management, auditoría interna)?

**Recomendación.** SOLICITAR EVIDENCIA DE COBERTURA COMPLETA: Anexo A del manual (procedimiento de control de cambios) e idealmente un registro histórico de al menos un cambio versioned (cambio → aprobación → implementación → comunicación). Alternativamente, si no ha habido cambios desde v1.0, documentar formalmente que el control está definido pero no aún ejercitado, con planes para su validación operativa. Esto permitirá pasar de 4 (control documentado) a 5 (control documentado + demostrado en operación).

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `76c32643a33f`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [4/5] Verificar la existencia, suficiencia y claridad de la documentación

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Verificación de existencia, suficiencia y claridad de la documentación del modelo VaR Mercado FRTB. Esta actividad es crítica porque la documentación es el fundamento de la auditoría del modelo: sin manuales claros, sin trazabilidad de la metodología y sin registros de ejecución de controles, no es posible verificar que el modelo se está usando como se diseñó.

**Hallazgo.**

La documentación disponible demuestra la existencia de los elementos esenciales: un manual metodológico versionado con control de cambios explícitamente declarado, un informe de seguimiento que reporta backtesting mediante pruebas de Kupiec y Christoffersen ejecutadas sobre datos reales del Q1 2026, y justificación de la elección de parámetros (ventana de 500 días). Sin embargo, existen dos brechas no críticas: (1) El manual operativo (paso a paso de la ejecución, frecuencia de recálculos, responsables, criterios de escalada) no aparece en el contexto disponible, imposibilitando verificar si el proceso se ejecuta tal como se describe en la teoría. (2) No hay evidencia de que el backtesting se integre en una cadena de toma de decisiones: el manual menciona que Kupiec y Christoffersen se ejecutan «mensualmente» pero no especifica a qué comité se reporta, qué umbrales de p-valor disparan acciones correctivas, o cómo se usan los resultados para revalidar o descartar hipótesis sobre el modelo. La ausencia de un informe operativo completo y de la descripción del flujo de gobiernanza representa una incertidumbre sobre la EJECUCIÓN (tramp 2: «existe ≠ se ejecuta»). La suficiencia de la claridad es parcial: el manual metodológico es legible y cita la fuente de decisiones; sin embargo, la justificación de la ventana de 500 días se remite al «anexo C» (estudio de sensibilidad) que no está en el contexto, impidiendo verificar independientemente esa decisión. La calidad de la documentación es buena; la cobertura, incompleta en el contexto proporcionado.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A"
>
> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "Resultados del último trimestre en el informe de seguimiento."

**Preguntas al modelador.**

- [ ] ¿Existe un manual operativo que describa paso a paso la ejecución del cálculo de VaR, la cadencia, los responsables, los criterios de escalada y la integración de resultados de backtesting en decisiones de gestión? (Ausencia observada: sólo se encontró manual metodológico.)
- [ ] ¿Cuál es el anexo C (estudio de sensibilidad de ventanas) al que remite el manual? ¿Se incluyó en la cobertura documental? Si no, ¿puede ser proporcionado para verificar independientemente la calibración de 500 días?
- [ ] ¿A qué comité o función se reportan los resultados mensuales de Kupiec y Christoffersen, y qué umbrales de p-valor o criterios de rechazo disparan acciones correctivas (ej. recalibración del modelo, cambio de metodología, restricción de posiciones)?
- [ ] ¿Se han verificado explícitamente los supuestos de estacionariedad y ausencia de cambios estructurales de los retornos históricos en la ventana de 500 días durante el período 2025-2026? ¿Hay evidencia de pruebas como ADF, KPSS o análisis de quiebres?
- [ ] El test de Christoffersen reporta resultado agregado. ¿Se desglosan los estadísticos LR para independencia (LR_ind) y el p-valor exacto, o se comunica solo la conclusión cualitativa? ¿Existen resultados por mesa o por factor de riesgo, o solo a nivel cartera agregada?
- [ ] ¿Se ha documentado la fecha exacta en que se ejecutó el backtesting del Q1 2026 (retrospectivamente sobre los 62 días transcurridos, o de forma prospectiva)? ¿Con qué periodicidad se recalculan las estimaciones de VaR: diaria, semanal?

**Recomendación.** Elevar a Puntaje 5 requiere: (1) Proporcionar el manual operativo completo con responsables, frecuencias, criterios de escalada y la cadena de reporte hacia comités de decisión. (2) Incluir el anexo C (estudio de sensibilidad) y verificar independientemente que la calibración de 500 días es robusta frente a cambios de régimen en el período de validación. (3) Documentar explícitamente en el informe de seguimiento los estadísticos desagregados del test de Christoffersen (LR_ind, LR_poc, p-valores) y la metodología de cálculo del intervalo de confianza de Kupiec usado como criterio de aceptación. (4) Incluir verificación de supuestos (estacionariedad, autocorrelación, homoscedasticidad) con test estadísticos formales y fecha de ejecución. (5) En caso de que la ventana de 500 días haya sido heredada de otra cartera o usuario, documentar la evidencia de que es adecuada PARA ESTA cartera específica, no solo que funciona formalmente. Mientras tanto, mantener como requisito permanente en los próximos ciclos de validación que toda desviación o cambio en parámetros se justifique mediante análisis de sensibilidad documentado.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `64294a19b3c6`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Calidad de datos  ·  score 3.2

#### 🟠 [2/5] Verificar que no exista suficiencia de controles de calidad de datos (integridad)

*Control: El modelo deberá contar con controles de calidad de datos de primera linea sobre los resultados calculados (outliers, missing, duplicados, entre otros)*

**Qué evalúa.** Verificación de la existencia, documentación y ejecución de controles de calidad de datos de primera línea (missing, duplicados, outliers) sobre los cálculos de VaR. Este control es crítico para la integridad del modelo: datos defectuosos propagan error directo al resultado final y vician el backtesting.

**Hallazgo.**

La documentación menciona un perfil de datos con cifras sobre ausencias e imputación, pero NO existe evidencia de un script de control de calidad (_replica_virf.py o equivalente), ni reportes de incidencias, ni logs de ejecución de controles periódicos. El manual VaR FRTB declara la ventana de 500 días y justifica la elección mediante sensibilidad (anexo C no proporcionado), pero no documenta cómo se valida la integridad de esos 500 datos cada vez que se recalcula. El perfil de datos reporta '0.4% de valores ausentes, imputados por último valor conocido' — esto es UNA ÚNICA ejecución de ese perfil, no un control en marcha. No hay evidencia de: (1) automatización periódica de controles de missing/duplicados/outliers; (2) criterios de decisión explícitos para qué hacer si se detecta una anomalía; (3) alertas o excepciones escalonadas; (4) trazabilidad de qué datos entraron en cada backtesting mensual. El hecho de que existan pruebas de Kupiec y Christoffersen mensuales (referencias en manual) no garantiza que los datos subyacentes hayan sido validados antes de ese cálculo — backtesting puede mostrar excedencias por mala calidad de datos, no solo por modelo incorrecto. Para alcanzar nivel 3 se necesita: script de validación documentado, reporte periódico de incidencias (al menos trimestral), y conexión explícita entre esos reportes y la cartera que alimenta el VaR.

**Evidencia citada.**

> perfil_datos_VaR.md → "Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha."
>
> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> No se encontró en el contexto disponible: script de control de calidad, reportes de incidencias de datos, logs de ejecución de validaciones periódicas, criterios de decisión sobre tratamiento de anomalías detectadas, o conexión explícita entre validación de datos y ejecución del backtesting.

**Preguntas al modelador.**

- [ ] ¿Existe un script de validación de datos (control de primera línea) que se ejecute antes de cada cálculo de VaR? Si existe, ¿cuál es su nombre y dónde se aloja?
- [ ] ¿Qué criterios definen una observación como 'outlier' en la ventana de 500 días? ¿Se usa Z-score, IQR, MAD, o volatilidad histórica? ¿Hay umbrales documentados?
- [ ] ¿Existe un log o reporte de incidencias de datos (valores missing detectados, duplicados, valores fuera de rango) del último trimestre o año?
- [ ] ¿Cómo se decide si incluir o excluir una observación outlier del cálculo del VaR? ¿Quién lo autoriza? ¿Se documenta cada decisión?
- [ ] ¿Se verificó que el método de imputación 'último valor conocido' no introduce sesgo en contextos de volatilidad alta o gaps prolongados (ej., puentes festivos, cierres de mercado no programados)?
- [ ] ¿El informe de seguimiento que menciona 'Resultados del último trimestre' incluye una sección de validación de datos, o solo resultados del backtesting?
- [ ] ¿Se ejecuta el backtesting (Kupiec/Christoffersen) sobre datos pre-validados, o se corre directo sobre los 500 datos crudos de Bloomberg?

**Recomendación.** Implementar y documentar un script de validación de datos de primera línea (_control_datos_var.py o equivalente) que: (1) ejecute controles automáticos de missing (cuenta, distribución, patrón temporal), duplicados (fecha/valor), y outliers (Z-score >3 o MAD/1.4826 >3) antes de cada cálculo de VaR; (2) genere un reporte periódico (al menos mensual) de incidencias y acciones tomadas; (3) registre en log cada valor imputado o excluido con justificación y autorización; (4) incluya controles de integridad referencial (fechas secuenciales sin gaps no explicados, valores dentro de rango histórico). Este script debe ejecutarse en la cadena de producción ANTES de calcula_var.py y sus resultados deben ser accesibles en el backtesting para correlacionar posibles excedencias con anomalías de datos. Documentar explícitamente en el manual VaR la justificación de la imputación por 'último valor conocido' contra alternativas, incluyendo el análisis del anexo C (hoy no disponible) sobre riesgos de ventana.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `e415748e939f`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar la existencia de reportes de incidencia, monitorio de calidad de datos (entradas y salidas)

*Control: El modelo deberá contar con controles de calidad de datos de primera linea sobre los resultados calculados (outliers, missing, duplicados, entre otros)*

**Qué evalúa.** Evalúa la existencia y operatividad de controles de primera línea sobre calidad de datos (missing, duplicados, outliers) en inputs y outputs del modelo VaR FRTB. Es crítico porque datos defectuosos invalidan cualquier cálculo subsecuente, independientemente de la metodología.

**Hallazgo.**

La documentación afirma la existencia de un perfil de datos con especificaciones sobre ausencias (0.4% imputado por último valor conocido) y la ausencia de duplicados, pero NO proporciona evidencia de un control ejecutado ni de un script que implemente esos controles. El manual no menciona qué organismo ejecuta estos controles de primera línea, con qué periodicidad, o cómo se escalan las incidencias. Más crítico aún: no existe evidencia de reportes de incidencias de calidad de datos, ni de monitorio periódico de las salidas del modelo (VaR calculado) para detectar outliers, cambios estructurales o degradación de inputs. La imputación por 'último valor conocido' sobre el 0.4% es una técnica que introduce sesgo conocido (LOCF no es MCAR sino MAR/MNAR dependiendo de la causa de la ausencia), pero no hay evidencia de que se haya evaluado el impacto de esta decisión en la precisión del VaR, ni de que se haya documentado la justificación de por qué LOCF y no alternativas (forward-fill, media, interpolación lineal, o exclusión). Falta completamente: (1) script _replica_virf.py o equivalente que ejecute controles automáticos sobre cada lote de datos; (2) reportes de incidencias con trazabilidad de anomalías detectadas, origen, remediación y tiempo de cierre; (3) análisis de outliers con método explícito (Z-score, IQR, MAD) y umbrales documentados; (4) verificación de la composición y estacionariedad de la serie a lo largo del período de 500 días. Sin esto, el modelo opera 'a ciegas' respecto a la calidad real de sus inputs, y el cumplimiento de la norma es declarativo, no operativo.

**Evidencia citada.**

> perfil_datos_VaR.md → "Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha."
>
> manual_VaR_FRTB.md → "Objetivo: Estimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III)." [pero ninguna sección describe controles de calidad de datos de primera línea, reportes de incidencias, o monitorio periódico]
>
> No se encontró evidencia en el contexto disponible de: script de control automático, reportes de incidencias, análisis de outliers documentado, justificación de la metodología de imputación, periódicos de revisión de calidad de datos, o métricas de degradación de inputs.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Objetivo: Estimar el Value at Risk de la cartera de negociación bajo el marco FR»
> - «[Manual no contiene ninguna sección sobre tratamiento de valores ausentes, justi»
> - «[No hay mención de cómo se verifica la ausencia de duplicados, cuándo se hizo es»

**Preguntas al modelador.**

- [ ] ¿Existe un script automatizado (_replica_virf.py o equivalente) que ejecute controles de calidad sobre los datos de precios ANTES de cada corrida del VaR? Si existe, ¿cuáles son sus criterios de detección de outliers (Z-score, IQR, MAD) y cuál es el umbral de rechazo?
- [ ] ¿Quién ejecuta y con qué periodicidad (diaria, semanal, mensual) el control sobre la ausencia de duplicados mencionado en el perfil de datos?
- [ ] ¿Existe un reporte o log de incidencias de calidad de datos (missing, outliers detectados y remediados, cambios de proveedor Bloomberg, caídas de conectividad) con trazabilidad de: fecha del evento, descripción, impacto en el cálculo del VaR, acción remedial, y cierre?
- [ ] ¿Se ha evaluado el impacto en la precisión del VaR de la imputación LOCF sobre el 0.4% de datos? ¿Existe un análisis de sensibilidad comparando VaR calculado con datos imputados vs. VaR recalculado excluyendo esas fechas, para cuantificar el sesgo introducido?
- [ ] ¿Se verifica periódicamente que la serie de 500 días sea estacionaria y que no exista degradación progresiva de la calidad de los datos históricos más antiguos (ej: cambios de metodología en Bloomberg, auditorías de precios)?
- [ ] ¿Existe un proceso de reconciliación entre los precios obtenidos de Bloomberg y precios alternos (ej: otros sistemas de información, confirmación con el área de Front Office), especialmente para outliers detectados?

**Recomendación.** Implementar inmediatamente un script _replica_virf.py (o equivalente de control de datos) que: (1) ejecute diariamente controles automáticos sobre los datos de entrada (duplicados por fecha-ticker, missing values, cambios anómalos de precio); (2) genere un reporte de incidencias con criterios explícitos de outliers (ej: Z-score > 3 sobre retornos de 20 días móviles, o cambio > 10% en un día sin justificación de evento de mercado); (3) escale automáticamente al modelador cualquier ausencia de datos > 1% o outlier no explicado, con decisión documentada sobre si procede recalcular el VaR del día; (4) documente la justificación de la imputación LOCF (por qué se elige frente a alternativas) y ejecute mensualmente un análisis de sensibilidad del VaR respecto a cambios en la metodología de imputación. Incorporar todo esto en el manual §4 como 'Controles de Calidad de Datos de Primera Línea', con responsabilidades, periodicidades y escalas de incidencias. Sin esto, el cumplimiento del criterio permanece como declaración no verificada.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `fd79e82d3b1d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar que no exista duplicados sobre los inputs que estén en el alcance de validación

*Control: Revisión de la integridad y consistencias de los inputs*

**Qué evalúa.** Validación de la integridad de datos de entrada al modelo VaR: detección de duplicados, valores faltantes, outliers y consistencia referencial. Es crítica porque datos defectuosos invalidan cualquier cálculo posterior, independientemente de la sofisticación metodológica.

**Hallazgo.**

La documentación afirma la existencia de controles de calidad de datos, pero la evidencia está fragmentada y falta verificación ejecutada. El perfil_datos_VaR.md declara '0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha', pero no hay: (1) script de validación (_replica_virf.py o equivalente) que demuestre la ejecución de estas verificaciones; (2) reportes de incidencia o logs que prueben que los controles se ejecutaron periódicamente; (3) documentación del tratamiento específico de outliers (el manual menciona VaR histórico con 500 días pero no describe cómo se manejan desviaciones extremas previas a cálculo); (4) verificación de que la imputación por 'último valor conocido' está documentada y justificada en el manual metodológico (aparente ausencia). El manual describe la metodología de cálculo pero NO trata el pipeline de validación de inputs. Esta es una brecha crítica: un modelo que no documenta cómo asegura la integridad de sus datos de entrada no puede considerarse completo en control de calidad, aunque el resultado final esté bien calculado. Para elevar a nivel 3, se requiere: script ejecutable de réplica que verifique duplicados/faltantes/outliers línea por línea, calendario de ejecución de ese script, y reporte de última ejecución con resultados. Para nivel 4, además: justificación de por qué se elige imputación por último valor vs otras alternativas (forward-fill vs interpolación vs exclusión), y análisis de sensibilidad mostrando cómo varía el VaR bajo distintos tratamientos.

**Evidencia citada.**

> perfil_datos_VaR.md → "500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha."
>
> manual_VaR_FRTB.md → "2. Metodología: VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día."
>
> manual_VaR_FRTB.md → "3. Backtesting: Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual."
>
> No se encontró evidencia en el contexto disponible de: (a) script _replica_virf.py o equivalente de control de datos; (b) reportes de ejecución de validaciones; (c) documentación del tratamiento de outliers; (d) justificación de la metodología de imputación.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «2. Metodología: VaR histórico con ventana de 500 días, nivel de confianza 99%, h»
> - «3. Backtesting: Prueba de Kupiec (cobertura incondicional) y Christoffersen (ind»
> - «Secciones 1-4 (completo): no hay mención de tratamiento de valores ausentes ni j»

**Preguntas al modelador.**

- [ ] ¿Existe un script ejecutable (Python, R, SQL) que verifique duplicados por fecha, cuente valores ausentes y reporte outliers detectados? Si existe, ¿cuál es su nombre y ruta?
- [ ] ¿Cuándo se ejecutó por última vez ese script? ¿Existe log de ejecución con fecha, usuario, y resultado?
- [ ] ¿Por qué se eligió imputación por 'último valor conocido' en lugar de excluir fechas con datos incompletos, interpolar, o usar métodos de EM? ¿Se comparó el impacto en el VaR de cada opción?
- [ ] ¿Cómo se definen 'outliers' en esta cartera? ¿Se usan desviaciones estándar (Z-score), percentiles, o criterio experto? ¿Existe umbral documentado?
- [ ] ¿La fuente Bloomberg garantiza unicidad de fecha? ¿Se han detectado duplicados históricos? ¿Existe procedimiento de resolución si los hubiera?
- [ ] ¿Se verifica la integridad referencial (ej: cada ticker en la cartera tiene datos en la ventana de 500 días, o hay exclusiones documentadas)?
- [ ] ¿El perfil 'sin duplicados de fecha' refiere a la cartera completa o a cada instrumento individual? ¿A qué fecha se refiere esa declaración?

**Recomendación.** Desarrollar e integrar un script _replica_virf_datos.py (o _validate_inputs_var.py) que ejecute en cada ciclo de cálculo (idealización: diario o pre-cálculo VaR) las siguientes verificaciones: (1) detección de duplicados por (fecha, instrumento) con acción (error bloqueante si existen); (2) conteo y reporte de valores faltantes (missing) con método MCAR/MAR/MNAR identificado; (3) imputación solo si se autoriza explícitamente y con logging de filas afectadas; (4) detección de outliers mediante regla documentada (ej: ±4 desv. est. o percentil 0.1%/99.9%) con reporte de fechas afectadas; (5) verificación de integridad referencial (cobertura completa de cartera en ventana). Documentar este proceso en el manual con sección nueva 'Control de Calidad de Inputs' y adjuntar output de última ejecución al informe de backtesting mensual. Así se cierra el ciclo: documentación → ejecución → reporteo → seguimiento.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `40847d7d8a98`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la consistencia de las variables más importantes en el alcance de validación (Missing, outlier)

*Control: Revisión de la integridad y consistencias de los inputs*

**Qué evalúa.** Validación de la integridad de datos (missing, duplicados, outliers) para el modelo VaR Mercado FRTB. Esta es la primera línea de defensa contra errores que propagarían sesgos a través de toda la cadena de cálculo del VaR histórico.

**Hallazgo.**

La documentación afirma la existencia de controles de calidad de datos, pero la evidencia está fragmentada y carece de elementos críticos de validación. El perfil_datos_VaR.md declara «0.4% de valores ausentes, imputados por último valor conocido» y «sin duplicados de fecha», pero NO presenta ningún script de control, reporte de incidencias, auditoría de la imputación ni verificación de la lógica aplicada. La declaración de que no existen duplicados se presenta como un hecho consumado sin respaldar cómo se verificó ni en qué fecha. El tratamiento de missing values por «último valor conocido» (forward fill) es una opción documentada pero NO justificada: no se explora por qué se rechazaron alternativas (interpolación lineal, exclusión de observaciones, métodos estadísticos), ni se valida que este método no introduce sesgo en los retornos (especialmente crítico en períodos de alta volatilidad o cambios de régimen). Falta completamente: (1) un script _replica_virf.py o equivalente que ejecute estas validaciones de forma reproducible y verificable; (2) un reporte de ejecución del control con timestamp, autor y resultado; (3) análisis del patrón de missing values (¿son MCAR, MAR o MNAR?); (4) justificación del criterio de outliers utilizado (el manual no menciona ni Z-score, ni IQR, ni percentiles); (5) trazabilidad de cuándo y cómo se validaron estos datos previo al cálculo del VaR. Sin estos elementos, la afirmación de integridad de datos no es verificable y la confianza en los inputs del modelo VaR queda sin fundamento documentado.

**Evidencia citada.**

> perfil_datos_VaR.md → "Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha."
>
> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día." [pero sin mención alguna a controles de datos previos al cálculo]
>
> No se encontró evidencia en el contexto disponible de: script _replica_virf.py, reporte de control de datos, análisis de patrón de missing values, justificación del método de imputación, o criterios de detección de outliers.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Revisar scripts del modelador línea por línea. Buscar el script _replica_virf.py»

**Preguntas al modelador.**

- [ ] ¿Existe un script (Python, R, SQL) que ejecute la validación de missing values, duplicados y outliers de forma reproducible? Si existe, ¿cuál es su nombre exacto y dónde está alojado?
- [ ] ¿Qué método estadístico de detección de outliers se aplica? (ej: Z-score >3, IQR 1.5, percentiles <1% o >99%). ¿Cuántos outliers se detectaron y eliminaron en las 500 observaciones?
- [ ] ¿Se analizó el patrón de los 0.4% de missing values? ¿Son aleatorios (MCAR), falta en observables (MAR) o faltan no al azar (MNAR)? ¿En qué fechas ocurren?
- [ ] ¿Se comparó la distribución de retornos PRE y POST imputación? ¿Cambió la media, varianza o asimetría? ¿Se verificó que forward fill no introdujo sesgo en los percentiles extremos?
- [ ] ¿Quién ejecutó la validación de datos, cuándo y con qué resultado? ¿Existe un reporte de incidencias de calidad de datos asociado a este modelo?
- [ ] ¿El script de cálculo del VaR excluye el período de imputación del backtesting, o incluye observaciones con valores propagados?

**Recomendación.** Crear un script _replica_virf.py que implemente y documente los siguientes pasos: (1) carga de datos Bloomberg, (2) verificación automática de duplicados por fecha, (3) análisis del patrón de missing values y clasificación MCAR/MAR/MNAR, (4) aplicación del método de imputación con logging de qué se imputó y cuándo, (5) detección de outliers con criterio definido (ej: IQR) y reporte de exclusiones, (6) validación post-imputación (distribución, autocorrelación, tests de estacionariedad). Ejecutar este script sobre datos reales de los últimos 2 años. Documentar en el manual §2 o nuevo §2.1 la justificación de cada elección (por qué forward fill, por qué el criterio de outliers, por qué se mantienen imputaciones en el backtesting). Generar un reporte mensual de incidencias de datos y archivarlo con los historiales de cálculo del VaR. Sin estos pasos, la afirmación de integridad de datos en el perfil no es verificable y representa un riesgo material para la confiabilidad del modelo FRTB.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `7639e0e15ae9`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la integridad sobre los inputs en el alcance de validación

*Control: Revisión de la integridad y consistencias de los inputs*

**Qué evalúa.** Revisión de la integridad y consistencia de los inputs de datos en el modelo VaR Mercado FRTB, incluyendo detección de valores ausentes, duplicados, outliers y verificación del control de calidad documentado versus ejecutado.

**Hallazgo.**

La documentación afirma disposiciones sobre calidad de datos, pero la evidencia está fragmentada y no permite verificar que los controles se ejecuten operativamente. El perfil_datos_VaR.md declara 0.4% de ausencias imputadas por último valor conocido y ausencia de duplicados, pero NO existe un script _replica_virf.py u otro mecanismo documentado de validación automática que respalde estas afirmaciones. La documentación de control de cambios, reportes de incidencia, o auditorías de integridad referencial está completamente ausente del contexto. Crítico: no se puede distinguir si estas cifras (0.4%, método de imputación) se verifican en cada ciclo o son un cálculo histórico único. El manual_VaR_FRTB.md no menciona en absoluto la calidad de datos de entrada, lo que viola la separación de responsabilidades: el perfil de datos existe en un documento desacoplado del manual metodológico, sin trazabilidad a decisiones de aceptabilidad de calidad. Para cumplimiento a nivel 3 se requeriría como mínimo: (1) script de validación ejecutable con logs de corridas, (2) documentación de umbrales de aceptabilidad (qué % de ausencia es tolerable, qué se considera outlier), (3) reportes mensuales de monitoreo. Actualmente existe una DECLARACIÓN DE ESTADO, no un CONTROL OPERATIVO VERIFICADO.

**Evidencia citada.**

> perfil_datos_VaR.md → "Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha." 
>
> manual_VaR_FRTB.md → "## 2. Metodología
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día." (el manual NO menciona ni referencias ni criterios de calidad de datos de entrada)

**Preguntas al modelador.**

- [ ] ¿Existe un script de validación de datos (p.ej., _replica_virf.py, check_data_quality.py o equivalente) que se ejecute antes de cada cálculo de VaR? Si existe, ¿dónde se encuentran sus logs de ejecución y qué criterios implementa?
- [ ] ¿Cuáles son los umbrales de ACEPTABILIDAD de calidad de datos? (p.ej., ¿se rechaza un ciclo si la ausencia supera X%, o siempre se imputa? ¿un outlier detectable por Z-score > 3 es revisado o automáticamente incluido?)
- [ ] El perfil afirma 0.4% de ausencia: ¿es un promedio histórico, o el estado actual? ¿Se monitorea que en cada ventana de cálculo no se exceda este umbral?
- [ ] ¿Se documenta el tratamiento de días con mercados cerrados o datos incompletos (p.ej., fines de semana, feriados no laborales) antes de que los retornos entren al cálculo del VaR?
- [ ] ¿Existe un reporte mensual o trimestral de INCIDENCIAS DE CALIDAD DE DATOS (p.ej., retrasos de Bloomberg, valores rechazados, imputaciones realizadas) que se presente al Comité de Riesgos junto con los resultados de backtesting?
- [ ] ¿Se verifica la INTEGRIDAD REFERENCIAL entre la cartera de negociación y los precios en Bloomberg (p.ej., ¿todos los instrumentos en cartera tienen precio diario, o hay gaps sistemáticos?)
- [ ] El manual §2 fija la ventana en 500 días. ¿Se verifica que en cada corrida se dispone de exactamente 500 observaciones válidas, o el código permite ventanas más cortas si hay ausencias?

**Recomendación.** Crear un script _replica_virf.py que implemente y documente los siguientes controles ejecutables:
(1) Detección de MISSING VALUES: reportar count, tipo (MCAR/MAR/MNAR si es identificable), método de imputación aplicado, y trazabilidad a cada observación ausente.
(2) Detección de DUPLICADOS: verificar no hay dos precios para la misma fecha-instrumento; reportar cualquier hallazgo.
(3) Detección de OUTLIERS: aplicar Z-score, cuantil 0.01/0.99, y cambios diarios > X%. Documentar umbrales en el manual y requisitos de revisión manual si se superan.
(4) INTEGRIDAD REFERENCIAL: contrastar que todo instrumento en cartera tenga precio en Bloomberg en la ventana requerida.
(5) VERSIONADO de datos: registrar fecha de corrida, fuente, fecha de carga, y hash de los datos de entrada para reproducibilidad.
El script debe ejecutarse como PASO 0 antes de cada cálculo de VaR, y sus resultados deben constar en los mismos reportes mensuales de backtesting. Incluir en el manual_VaR_FRTB.md una sección dedicada a Calidad de Datos (1-2 páginas) que especifique: umbrales de aceptabilidad, criterios de rechazo, método de escalada si se incumplen, y referencias a este script de validación.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `bf697a26b92f`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la actualización de los inputs

*Control: Revisión de la integridad y consistencias de los inputs*

**Qué evalúa.** Verificación de integridad y consistencia de datos de entrada para el modelo VaR FRTB: detección de valores ausentes, duplicados, outliers y confirmación de actualización periódica de inputs. Es el control preventivo más crítico para la confiabilidad de cualquier modelo de riesgo.

**Hallazgo.**

La documentación afirma la existencia de controles de calidad de datos, pero la evidencia está severamente fragmentada y carece de instrumentación verificable. El perfil de datos declara '0.4% de valores ausentes, imputados por último valor conocido' y 'sin duplicados de fecha', pero NO EXISTE script de replicación (_replica_virf.py o equivalente) que demuestre estas verificaciones, no hay reportes de incidencias de calidad de datos periódicos, y no se documenta cómo se detectan ni tratan outliers. El manual menciona que 'ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec' (estudio anexo C), pero es imposible verificar si esa conclusión descansó sobre datos limpios: el tratamiento de ausencias mediante 'último valor conocido' introduce sesgo forward-looking que puede enmascarar volatilidad real y distorsionar la calibración de la ventana. Además, no hay constancia de revisiones periódicas de integridad referencial ni auditoría de la fuente Bloomberg (validación de tiempos de corte, recapitalizaciones, splits). Para cumplimiento mínimo (nivel 3) se requiere: (1) script ejecutable de validación de datos con flagging de MCAR/MAR/MNAR, (2) reportes mensuales de incidencias adjuntos al seguimiento VaR, (3) documentación explícita de criterios de outlier (Z-score, IQR u otro) con justificación, (4) trazabilidad de ajustes de datos Bloomberg. La ausencia de esto no es un déficit de documentación: es ausencia de controles ejecutados.

**Evidencia citada.**

> perfil_datos_VaR.md → '0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha.'
>
> manual_VaR_FRTB.md → 'La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.'
>
> manual_VaR_FRTB.md → 'No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.'
>
> No se encontró evidencia de: (a) script _replica_virf.py, (b) reportes de incidencias de calidad de datos, (c) documentación de tratamiento de outliers, (d) protocolo de validación de fuente Bloomberg, (e) logs de ejecución de controles de integridad referencial.

**Preguntas al modelador.**

- [ ] ¿Existe un script _replica_virf.py o equivalent que valide las 500 observaciones? Si existe, ¿dónde está alojado y cuál es su última ejecución registrada?
- [ ] El anexo C que justifica la ventana de 500 días: ¿fue ejecutado sobre datos crudos (sin imputación) o sobre datos ya procesados con forward-fill? ¿Se documentó este paso?
- [ ] ¿Existe un reporte mensual o trimestral de incidencias de calidad de datos (ausencias, duplicados, outliers) que se adjunte al seguimiento VaR?
- [ ] ¿Cómo se detectan y tratan outliers en las series de retornos? ¿Se usa Z-score, IQR, métodos robustos u otro criterio? ¿Se documenta cada decisión de exclusión?
- [ ] ¿Existe un protocolo de validación de precios Bloomberg (verificación de tiempos de corte, ajustes corporativos, splits, recapitalizaciones)? ¿Quién lo ejecuta y con qué periodicidad?
- [ ] ¿Se verifica integridad referencial (ej. ISIN/cusip vs ponderaciones de cartera, divisa vs moneda de cotización)? ¿Existe un script o proceso documentado para esto?

**Recomendación.** Desarrollar e implementar inmediatamente un módulo de validación de datos (_replica_virf.py o equivalente) que incluya: (1) detección de ausencias y clasificación MCAR/MAR/MNAR con justificación de método de imputación (actualmente sin justificar); (2) búsqueda de duplicados por fecha e instrumento; (3) detección de outliers con criterio explícito (ej. Z-score > 3 en retornos) y flagging con decisión de inclusión/exclusión; (4) integridad referencial cartera-precios. Ejecutar retroactivamente sobre los 500 datos históricos y adjuntar reporte de incidencias al seguimiento VaR vigente. Repasar el anexo C del manual: si se ejecutó sobre datos imputados, repetirlo sobre datos crudos para validar la conclusión sobre ventana de 250 vs 500 días. Documentar en el manual metodológico el tratamiento de datos ausentes (por qué forward-fill y no interpolación o exclusión) y sus implicaciones para el backtesting.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a6979b2cee16`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] Control_01 — En la carpeta de evidencia tienes archivos relacionados con este control: (1) Manual de extracción de datos y (2) scrpt...

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** La evidencia presenta deficiencias críticas de completitud y coherencia que impiden una validación concluyente. El manual metodológico (secciones 2-4) describe el marco FRTB con ventana de 500 días, confianza 99%, horizonte 1 día y referencias a backtesting Kupiec/Christoffersen, pero FALTA completamente: (a) especificación del universo de activos y fuentes de datos, (b) definición explícita de variables de entrada (precio, rentabilidad, cambios de base), (c) transformaciones aplicadas (log-retornos vs. simples, ajuste por dividendos, tratamiento de ausencias), (d) controles de calidad de datos (outliers, duplicados, gaps temporales), (e) anexos C y reporte de seguimiento citados pero no adjuntos. El script es un fragmento aislado (función única, código duplicado 5 veces, sin inicialización de datos ni pipeline completo) que implementa solo el cálculo puntual del percentil, sin validación de entrada ni tratamiento de edge cases.

**Hallazgo.**

{'tipo': 'OBSERVACION', 'texto': "Manual incompleto: faltan secciones críticas de origen de datos, universo de activos, definición de variables, transformaciones de datos, y controles de calidad. Las referencias a 'anexo C' (justificación de ventana 500) e 'informe de seguimiento' (resultados backtesting) no están adjuntas.", 'recomendacion': 'Completar el manual con: (1) esquema de extracción de datos (fuentes, frecuencia, reconociliación), (2) definición explícita de retornos (tipo: log vs. simple, moneda, ajustes corporativos), (3) matriz de transformaciones con pseudocódigo o fórmulas, (4) controles de calidad documentados (rangos aceptables, tratamiento de valores faltantes, duplicados), (5) adjuntar anexo C y últimos reportes de backtesting.', 'riesgo': 'Alto', 'criticidad': 'CRITICA'} | {'tipo': 'OBSERVACION', 'texto': "Script presentado es un fragmento aislado sin contexto de pipeline: función única `var_historico()` sin validación de entrada (ej: ¿qué pasa si `len(retornos) < 500`?), sin inicialización de datos, sin manejo de errores, sin tratamiento de NaN/infinitos, sin horizonte multi-día (manual dice '1 día' pero no especifica si es roling). Código duplicado 5 veces idénticamente sugiere artefacto de captura incompleto.", 'recomendacion': 'Proporcionar: (1) script completo con inicialización de datos (carga, limpieza, transformación), (2) validaciones (length ≥ 500, no NaN, tipo de dato), (3) manejo de excepciones, (4) función de backtesting integrada (Kupiec/Christoffersen), (5) verificar que la duplicación es artefacto y proporcionar versión única.', 'riesgo': 'Alto', 'criticidad': 'CRITICA'} | {'tipo': 'OBSERVACION', 'texto': 'Alineación manual↔script no verificable: el script usa `retornos[-500:]` (últimos 500 elementos) sin especificar si `retornos` es pre-filtrado, ordenado, o si incluye fines de semana/festivos. Manual no define la granularidad temporal (¿500 días calendario o trading?). Si hay saltos en la serie de tiempo, la ventana no será 500 días reales.', 'recomendacion': 'Documentar explícitamente: (1) formato de entrada de `retornos` (frecuencia, tipo de índice temporal), (2) si la ventana es 500 observaciones o 500 días reales (¿cómo se manejan no-trading days?), (3) agregar parámetro explícito de ventana en lugar de hardcodear 500.', 'riesgo': 'Alto', 'criticidad': 'CRITICA'} | {'tipo': 'OBSERVACION', 'texto': "Backtesting y validación del modelo ausentes del script: manual requiere Kupiec e Christoffersen mensuales, pero código no implementa estas pruebas, ni cálculo de excedencias, ni estadístico de prueba, ni intervalo de aceptación. No hay evidencia de que los resultados mencionados en 'informe de seguimiento' (últimos 3 meses) se generen automáticamente.", 'recomendacion': 'Implementar en el pipeline: (1) función de backtesting que calcule VaR histórico en ventanas rodantes, (2) conteo de excedencias vs. límite teórico (99% → 1 excedencia esperada cada ~100 días), (3) prueba de Kupiec (exact binomial test), (4) prueba de Christoffersen (LR de independencia), (5) reporte automático mensual con conclusión de pase/fallo.', 'riesgo': 'Alto', 'criticidad': 'CRITICA'} | {'tipo': 'OBSERVACION', 'texto': "Justificación de parámetros débil: manual cita anexo C para la elección de ventana 500 días ('menores a 250 generaban excedencias fuera del intervalo Kupiec'), pero anexo no se adjunta. No hay especificación numérica de qué intervalo se utiliza (bilateral vs. unilateral, p.ej. [0.04, 0.16] vs. [0.05, 0.15] para n=250 al 95%).", 'recomendacion': 'Adjuntar anexo C con: (1) análisis de sensibilidad explícito (tabla con ventanas 250, 300, 400, 500, 750 días y resultados Kupiec), (2) intervalo de confianza utilizado con justificación (López es preferible para ventanas cortas), (3) conclusión documentada sobre por qué 500 es óptimo para esta cartera.', 'riesgo': 'Medio', 'criticidad': 'MODERADA'}

**Evidencia citada.**

_Sin evidencia citada._

<sub>prompt `47d8c87dc32d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] Control_02 — Valida la unicidad Cliente por Cuenta en la base usada por el proceso. Usa el resultado automatico como evidencia objeti...

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** La revisión enfrenta una desconexión crítica entre el control solicitado y la evidencia proporcionada. Se solicitó validar la UNICIDAD CLIENTE-POR-CUENTA en base de datos, pero la documentación entregada corresponde íntegramente a metodología VaR FRTB (modelo de mercado), sin ninguna referencia a estructuras de datos de clientes, cuentas o reglas de unicidad. El código Python implementa correctamente el percentil histórico a 500 días y confianza 99% conforme al manual §2, pero es irrelevante para el control demandado. Adicionalmente, se detectan dos anomalías procesales: (i) repetición masiva de secciones 2-4 del manual (duplication artefact), sugiriendo corrupción de datos o inyección no intencional; (ii) la fecha de aprobación (2026-03-15) es prospectiva, inconsistente con un documento vigente.

**Hallazgo.**

{'tipo': 'OBSERVACION', 'texto': 'Desalineación total entre el control evaluado (unicidad Cliente-Cuenta en BD) y la evidencia proporcionada (metodología VaR FRTB). No existe documentación, código, tablas de datos, o metadatos que aborden la estructura de clientes, cuentas, relaciones 1:N, o reglas de validación de unicidad. Imposible auditar el control solicitado con esta evidencia.', 'recomendacion': 'Proveer: (i) esquema lógico de tablas CLIENTE, CUENTA y su relación; (ii) script SQL o procedimiento de validación de unicidad; (iii) reporte de ejecución automatizada mostrando resultados cuantitativos (ej: N clientes únicos, N cuentas únicas, N duplicados detectados); (iv) fecha de última ejecución del control.', 'riesgo': 'No concluyente', 'criticidad': 'CRITICA'} | {'tipo': 'OBSERVACION', 'texto': 'Corrupción o inyección de datos detectada: las secciones 2, 3 y 4 del manual metodológico se repiten 5 veces consecutivas sin variación. Esto afecta la integridad de la evidencia documental y sugiere fallo en el proceso de captura, copia o transmisión.', 'recomendacion': 'Recuperar versión original íntegra del Manual Metodológico VaR Mercado FRTB v1.0 desde fuente controlada (gestión documental, repositorio aprobado). Verificar cadena de custodia del archivo entregado.', 'riesgo': 'Medio', 'criticidad': 'MODERADA'} | {'tipo': 'OBSERVACION', 'texto': 'Inconsistencia temporal: el manual declara aprobación el 2026-03-15 (fecha futura respecto a la lógica de auditoría). Esto es incompatible con un documento de referencia vigente para procesos operativos actuales.', 'recomendacion': 'Confirmar con el Comité de Riesgos la fecha correcta de aprobación. Si es error administrativo, corregir. Si es deliberado (simulación/borrador), reclasificar estado documental.', 'riesgo': 'Bajo', 'criticidad': 'BAJA'} | {'tipo': 'OBSERVACION', 'texto': 'El código Python implementa correctamente la metodología VaR descrita (percentil 1% sobre ventana 500 días), pero es código de CÁLCULO VaR, no de VALIDACIÓN DE UNICIDAD. No guarda relación con el control auditado.', 'recomendacion': 'Clarificar: ¿se requiere auditar el modelo VaR FRTB O el control de unicidad Cliente-Cuenta? Proporcionar evidencia alineada al control específico asignado.', 'riesgo': 'No concluyente', 'criticidad': 'CRITICA'}

**Evidencia citada.**

_Sin evidencia citada._

<sub>prompt `7caf428315d2`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] Control_03 — Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** La revisión identifica una incongruencia crítica entre el control solicitado y la evidencia suministrada. El control a evaluar requiere validar la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura, típico de un modelo de crédito (LaR/IFRS 9). Sin embargo, la evidencia proporcionada (manual y código) corresponde exclusivamente a un modelo de VaR de mercado FRTB con metodología histórica de 500 días. No existe evidencia alguna sobre la estructura de datos de crédito, validaciones de integridad referencial, o reglas de negocio aplicables al control solicitado. La duplicación artefactual del código y manual sugiere un problema en la compilación de la evidencia que afecta la confiabilidad del ejercicio de validación.

**Hallazgo.**

{'tipo': 'OBSERVACION', 'texto': "El archivo de evidencia contiene repetición artefactual de la sección §3 'Backtesting' y §4 'Limitaciones' del manual FRTB, así como duplicación íntegra de la función Python var_historico(). Esto indica un problema en la recopilación o compilación de la evidencia que compromete la trazabilidad.", 'recomendacion': 'Recopiar la evidencia de fuentes primarias (repositorio de código, versión aprobada del manual) eliminando duplicados. Verificar integridad SHA256 de archivos fuente.', 'riesgo': 'Medio', 'criticidad': 'MODERADA'} | {'tipo': 'OBSERVACION', 'texto': "El manual VaR FRTB v1.0 aprobado el 2026-03-15 (fecha futura respecto a contexto histórico) carece de: (a) referencia explícita al anexo C de sensibilidad mencionado en §2, (b) especificación de la fuente de datos de retornos (benchmark, cartera), (c) documentación de la prueba Christoffersen (§3), (d) definición operacional de 'excedencias por encima del intervalo de Kupiec'.", 'recomendacion': 'Anexar: anexo C con análisis de sensibilidad (ventanas 100-500 días, estadísticos Kupiec por ventana), especificación de serie de retornos (asset class, período), y protocolo mensual de backtesting con umbrales de aceptación.', 'riesgo': 'Medio', 'criticidad': 'MODERADA'} | {'tipo': 'OPORTUNIDAD_MEJORA', 'texto': 'La función var_historico() implementa correctamente la ventana de 500 días y el nivel 99% especificado en §2, pero carece de validaciones robustas: no verifica longitud mínima de retornos (riesgo: cálculo con n<500), no documenta comportamiento en períodos de datos insuficientes, y no incluye manejo de valores faltantes (NaN/inf).', 'recomendacion': 'Implementar guards: (1) assert len(retornos)>=500, (2) validar no-NaN previo a percentile, (3) agregar logging de advertencia si n<500 pero >=250, (4) documentar que percentile usa interpolación lineal (np.percentile default).', 'riesgo': 'Bajo', 'criticidad': 'BAJA'}

**Evidencia citada.**

_Sin evidencia citada._

<sub>prompt `9267e2f9dbb5`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] Control_04 — Valida la unicidad de Tasa de Interes por Cuenta

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** INCONSISTENCIA CRÍTICA DETECTADA: El control solicitado es 'Validar la unicidad de Tasa de Interés por Cuenta', sin embargo la evidencia proporcionada corresponde a un modelo de VaR Mercado bajo marco FRTB (Basilea III). No existe solapamiento temático entre el control requerido (validación de tasas por cuenta, típicamente modelo de riesgo de crédito/IFRS 9) y la documentación/código suministrados (modelo de riesgo de mercado). Adicionalmente, la evidencia del código contiene duplicación idéntica de la función cinco veces, lo que sugiere un error en la carga de artefactos. La documentación manual metodológico presenta repeticiones sustanciales de las secciones 2-4, indicando corrupción de archivo o error de compilación.

**Hallazgo.**

{'tipo': 'OBSERVACION', 'texto': "Evidencia entregada NO corresponde al control a evaluar. Control solicitado: 'Validar unicidad de Tasa de Interés por Cuenta' (scope: riesgo de crédito/IFRS 9). Evidencia recibida: Manual VaR Mercado FRTB + función Python var_historico (scope: riesgo de mercado). No existe base técnica para validar control de tasas de interés con modelo de mercado.", 'recomendacion': 'Reentregar evidencia correcta: (1) Especificación funcional del control de unicidad de tasas por cuenta; (2) Query/código que implementa la validación; (3) Resultados de ejecución (logs, reconciliación); (4) Diccionario de datos con mapeo cuenta-tasa. Sin esto, no es posible emitir juicio de auditoría.', 'riesgo': 'No concluyente', 'criticidad': 'CRITICA'} | {'tipo': 'OBSERVACION', 'texto': "Integridad de la evidencia comprometida. El archivo 'Script/Código' contiene la función var_historico duplicada 5 veces de manera idéntica. El manual metodológico reproduce las secciones 2-4 cuatro veces sin variación. Esto indica corrupción de archivo, error en el sistema de carga, o manipulación no documentada.", 'recomendacion': 'Validar integridad de los artefactos mediante checksums o hash. Reentregar archivos con control de versión verificado. Documentar cadena de custodia de la evidencia conforme a SR 11-7 (Governance de sistemas de riesgo).', 'riesgo': 'Alto', 'criticidad': 'CRITICA'}

**Evidencia citada.**

_Sin evidencia citada._

<sub>prompt `ed378fa3dbad`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Metodología  ·  score 2.83

#### 🟠 [2/5] Validar supuestos y consideración más importantes de la técnica utilizada

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Validación de la justificación metodológica del VaR histórico FRTB: verificar que los supuestos principales (ventana de datos, nivel de confianza, horizonte) estén fundamentados teórica y empíricamente, y que el backtesting ejecutado realmente sustente la adecuación del modelo.

**Hallazgo.**

La documentación presenta un modelo con backtesting ejecutado y criterios estadísticos aplicados, pero incumple requisitos críticos de justificación metodológica que impiden considerar el cumplimiento como robusto. Primero, el manual declara que la ventana de 500 días se justifica en el anexo C mediante un 'estudio de sensibilidad', pero ese anexo NO está en el contexto disponible; sin acceso a esas cifras, no es posible verificar que ventanas menores generaban realmente excedencias fuera del intervalo de Kupiec, ni qué criterio se usó para seleccionar 500 como el umbral de corte. Segundo, el backtesting reportado (3 excedencias en 62 días) es insuficiente para sustentar validación metodológica: según la literatura estándar, las pruebas de Kupiec y Christoffersen requieren mínimo 250 observaciones para tener potencia estadística relevante; con solo 62 días, el contraste LR=3.81 (p=0.051) está justo en el borde de significancia y tiene muy baja potencia para detectar un modelo moderadamente mal calibrado. El manual no declara esta limitación ni su impacto en la conclusión. Tercero, la actividad exige validación de supuestos principales (normalidad de retornos en el modelo histórico, estacionariedad de la volatilidad, independencia de excedencias), pero la documentación NO aporta ni un contraste de normalidad, ni gráficos de diagnóstico, ni explicación de por qué el método histórico no sufre de colas gruesas. El manual menciona que «el Expected Shortfall complementa» el riesgo de liquidez, pero esto es una limitación reconocida, no una justificación de por qué el VaR histórico con horizonte uniforme de 1 día es apropiado bajo FRTB, que introdujo horizontes de liquidez variable. Cuarto, falta análisis de las excedencias individuales (el manual no describe cada uno de los 3 eventos, sus causas de mercado o si fueron predecibles ex-ante), que es evidencia de validación tan relevante como el estadístico agregado. La combinación de cobertura documental parcial (anexo C ausente), muestra de backtesting insuficiente (62 vs 250 recomendados), ausencia de pruebas de supuestos, y limitaciones no declaradas, sitúa el cumplimiento en el rango de parcial con brechas críticas. Para alcanzar nivel 3 se requeriría: (1) suministro e interpretación del estudio de sensibilidad del anexo C con justificación cuantitativa de la elección de 500 días; (2) backtesting sobre ventana de al menos 250 observaciones o declaración explícita de que la muestra de 62 días invalida la potencia de las pruebas; (3) contrastes de normalidad y análisis de excedencias individuales; (4) justificación de por qué el horizonte uniforme de 1 día es compatible con FRTB.

**Evidencia citada.**

> manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

**Preguntas al modelador.**

- [ ] ¿Cuáles fueron los resultados específicos del estudio de sensibilidad del anexo C? Proporcionar: (a) tasa de excedencias observada para ventanas de 250, 350, 500, 750 días; (b) criterio usado para elegir 500 (ej: minimizar RMSE vs intervalo de Kupiec, balancear reactividad y estabilidad); (c) p-valores de Kupiec para cada ventana.
- [ ] El backtesting reportado cubre solo 62 días. ¿Cuál es la serie histórica completa disponible y por qué se reportan solo 62? ¿Se ejecutó backtesting rolling sobre ventanas de 250+ observaciones para evaluar consistencia temporal?
- [ ] ¿Se realizaron contrastes de normalidad, estacionariedad (ADF), independencia de retornos, o análisis de colas (curtosis, sesgo) en la serie histórica usada para el VaR? Si no, ¿por qué no?
- [ ] ¿Cuál fue la causa específica de cada una de las 3 excedencias observadas? (Ej: reversión extrema de tipos, salto de volatilidad, evento geopolítico). ¿Alguna fue predecible mediante análisis ex-ante?
- [ ] ¿Se consideraron modelos alternativos (VaR paramétrico con EWMA, simulación de Monte Carlo, cuantiles condicionales)? Si no, ¿por qué el método histórico es superior? Si sí, ¿cuál fue el resultado del backtesting comparado?
- [ ] ¿Cómo reconcilia el uso de un horizonte uniforme de 1 día con el marco FRTB que prescribe horizonte de liquidez variable por categoría de riesgo? ¿El cálculo del ES integra esos horizontes variables mientras que el VaR usa 1 día fijo?
- [ ] El manual cita que 'se complementa con Expected Shortfall'. ¿Cuál es la relación operativa entre VaR y ES en la gestión de riesgos? ¿ES se reporta al comité, retroalimenta límites, o es solo un indicador complementario sin uso en decisiones?

**Recomendación.** 1. **Inmediato:** Suministrar anexo C del manual con el estudio de sensibilidad de ventanas. Verificar: (a) que la cifra de 500 días esté empíricamente justificada; (b) que se descarten alternativas con argumentación cuantitativa; (c) que los p-valores de Kupiec para ventanas menores confirmen incumplimiento del intervalo de tolerancia. 2. **Inmediato:** Expandir backtesting a serie histórica de al menos 250 observaciones (recomendación estándar de Kupiec y Christoffersen). Recalcular LR y reportar p-valor e intervalo de confianza de cobertura incondicional. Declara explícitamente si la muestra de 62 días invalida la potencia de las pruebas. 3. **Corto plazo:** Añadir sección de 'Validación de supuestos' con: (a) test de Dickey-Fuller o KPSS para estacionariedad; (b) gráfico de autocorrelación de retornos y de la serie de excedencias; (c) análisis de curtosis y sesgo; (d) conclusión sobre compatibilidad con supuestos del modelo histórico. 4. **Corto plazo:** Documentar análisis de excedencias individuales: para cada una de las 3 excedencias, reportar: fecha, factor de riesgo dominante, magnitud del movimiento (desviación estándar de la volatilidad histórica ese día), y si fue ex-ante predecible mediante análisis de escenarios o indicadores de estrés. 5. **Mediano plazo:** Justificar metodológicamente el horizonte de 1 día bajo FRTB. Si el modelo se usa para requisito de capital interno, verificar que la documentación aclare cómo se integra con el cálculo de ES por horizonte de liquidez que FRTB prescribe. Si ambos coexisten, documentar las diferencias de cobertura de riesgo. 6. **Mediano plazo:** Considerar benchmarking contra modelo alternativo (ej: VaR paramétrico con EWMA). Ejecutar backtesting paralelo y comparar potencia, sesgo y estabilidad temporal de ambos. Documentar si el histórico supera alternativas o si su adopción responde a preferencias organizacionales (simplicidad, interpretabilidad) asumiendo pérdida de precisión.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Feedback insuficiente (1/15 muestras mínimas) · prompt `9dae8d7ee7c0`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Existencia de buenas prácticas en el enfoque metodológico

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Evaluación de la justificación metodológica del modelo VaR histórico FRTB: si la elección del enfoque, parámetros y supuestos está fundamentada empíricamente y contrastada según estándares de backtesting (Kupiec, Christoffersen). Esta es una actividad crítica porque un modelo puede estar bien documentado pero metodológicamente débil o insuficientemente validado.

**Hallazgo.**

La documentación demuestra PARCIALMENTE una metodología implementada y ejecutada, con brechas NO críticas pero relevantes en la justificación. EVIDENCIA SÓLIDA: manual_VaR_FRTB.md declara VaR histórico 500 días, nivel 99%, horizonte 1 día, y el anexo C contiene un estudio de sensibilidad que justifica la ventana ("ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec"). El backtesting 2026Q1 ejecuta ambas pruebas formales esperadas: Kupiec LR=3.81 (p=0.051, zona verde Basilea) y Christoffersen (sin agrupamiento detectado). BRECHAS METODOLÓGICAS NO CRÍTICAS: (1) El manual NO explicita por qué se eligió VaR histórico frente a alternativas (paramétrico, GARCH, simulación de Montecarlo). La justificación del modelo respecto a otros métodos está ausente. (2) El estudio de sensibilidad (anexo C) NO está disponible en el contexto: solo se menciona que existe; no se puede verificar si el análisis fue riguroso (¿cuántas ventanas probadas?, ¿qué criterio de rechazo se usó?, ¿se descartaron alternativas documentadamente?). (3) Los supuestos del método histórico (estacionariedad, independencia de los retornos, ausencia de cambios de régimen) NO se declaran ni se validan explícitamente; el manual sí reconoce limitación de liquidez pero no aborda si la serie de 500 días captura cambios estructurales. (4) Christoffersen se reporta SIN detalle: falta el test de López (agrupamiento de excedencias ponderado), que es complementario; aunque su ausencia no invalida el modelo, representa incompletitud en la batería estándar. NIVEL DE CONFIANZA 99%: el manual no justifica por qué 99% y no 95% o 97.5%; Basilea III/FRTB lo exige, pero la documentación no lo argumenta localmente. INTEGRACIÓN EN GESTIÓN: el manual declara backtesting mensual pero no está claro si los resultados llegan a comité de riesgos o si cambian decisiones (esto se menciona como limitación documental, no como incumplimiento). CALIFICACIÓN JUSTIFICADA: el modelo está implementado, se ejecuta con datos reales, y los contrastes formales (Kupiec + Christoffersen) son correctos e interpretados adecuadamente. Sin embargo, para un puntaje 4 se requeriría: (i) justificación explícita de la elección metodológica vs alternativas, (ii) acceso verificable al análisis de sensibilidad, (iii) declaración y validación de supuestos, (iv) integración demostrable en procesos de decisión. La ausencia de estas justificaciones no invalida el modelo ejecutado, pero debilita su defensa metodológica ante un supervisor.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Anexo C no está incluido en el contexto disponible para auditoría.»

**Preguntas al modelador.**

- [ ] ¿Está disponible el Anexo C (estudio de sensibilidad) para auditoría? Se requiere verificar: rango de ventanas probadas, criterios de aceptación/rechazo, resultados de Kupiec para cada ventana, y justificación de por qué se eligió 500 vs otras opciones.
- [ ] ¿Se realizaron pruebas de estacionariedad (ADF/KPSS) o independencia (ACF/Ljung-Box) sobre la serie de retornos utilizada? Si no, ¿por qué se considera válido asumir estas propiedades sin verificación?
- [ ] ¿Por qué se eligió VaR histórico frente a alternativas (paramétrico, GARCH, simulación de Montecarlo)? ¿Se descartó explícitamente algún método? ¿Hay análisis comparativo de exactitud o cobertura entre métodos?
- [ ] ¿Se ejecuta el test de López (independencia ponderada de excedencias) de forma regular, o se prevé implementarlo? ¿Por qué fue descartado si es práctica estándar complementaria?
- [ ] ¿El nivel de confianza 99% fue elegido por regulación FRTB, o se validó internamente que es apropiado para esta cartera y horizonte de 1 día? ¿Existe análisis de impacto de cambiar a 97.5% o 99.5%?
- [ ] ¿Los resultados de backtesting mensual (Kupiec + Christoffersen) se escalan a un Comité de Riesgos o a instancia de decisión? ¿Qué acciones se toman si p-valor cae en zona amarilla (entre 0.05 y 0.10)? ¿Existe documentación de estas decisiones?

**Recomendación.** Para elevar de 3 a 4: (1) Integrar el Anexo C en la documentación auditada, o replicar el análisis de sensibilidad en formato verificable (tabla o gráfico con ventanas vs p-valores de Kupiec). (2) Agregar sección explícita en el manual justificando la elección de VaR histórico vs alternativas consideradas, con referencia a literatura (p.ej., Jorion 2006, Dowd 2007) o análisis interno comparativo. (3) Declarar y validar supuestos (estacionariedad, independencia) mediante pruebas estadísticas documentadas, o explicar por qué se asumen sin validación formal. (4) Expandir el protocolo de backtesting para incluir López test de forma trimestral, o justificar su omisión. (5) Documentar el flujo de backtesting → decisión: ¿quién recibe los resultados mensualmente?, ¿qué umbral dispara revisión de modelo?, ¿hay registro de acciones tomadas?. Para el nivel actual (3): el modelo es operativo y se ejecuta correctamente con pruebas estándar; las brechas son de justificación metodológica y completitud documental, no de ejecución. Recomendable realizar revisión de metodología cada 12-18 meses o ante cambio de régimen de mercado significativo.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `bcac48b1f837`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Revisión de los lineamiento internacionales o nacionales

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Evaluación de la justificación metodológica del modelo VaR FRTB, incluyendo la validación empírica del enfoque de ventana histórica, la ejecución de pruebas estadísticas (Kupiec y Christoffersen) y la alineación con lineamientos internacionales (Basilea III/FRTB).

**Hallazgo.**

El modelo demuestra una implementación parcialmente robusta con brechas críticas en la justificación metodológica. Se evidencia: (1) backtesting ejecutado con pruebas estándar (Kupiec con p-valor 0.051, Christoffersen sin agrupamiento), (2) elección de ventana de 500 días respaldada por un estudio de sensibilidad que rechaza ventanas menores a 250 días, (3) alineación declarada con marco FRTB y Basilea III. Sin embargo, no se presentan: (a) los detalles del estudio de sensibilidad del anexo C (solo se menciona su existencia), (b) justificación explícita de POR QUÉ 500 días frente a 750, 1000 u otros benchmarks comunes en la industria, (c) contrastación alternativa con modelos competidores (ej: VaR paramétrico, GARCH, simulación de Montecarlo), (d) verificación de supuestos (estacionariedad, normalidad de retornos, ausencia de quiebres estructurales en la ventana), (e) análisis de López sobre cobertura condicional más allá de Christoffersen, y (f) reconciliación explícita entre el cambio de marco FRTB (Expected Shortfall como medida primaria) y el mantenimiento del VaR como métrica central. El resultado de Kupiec (p=0.051) está en zona marginal respecto al umbral de significancia del 5%, lo que requiere monitoreo más frecuente o revisión de parámetros. La limitación del riesgo de liquidez se declara pero no se integra en la gestión (no hay evidencia de cómo se complementa con ES en decisiones de capital). Para alcanzar cumplimiento pleno (4/5) se requiere: documentación del estudio de sensibilidad con cifras, justificación comparativa explícita de la ventana elegida, análisis de supuestos con p-valores, y mapeo de cómo FRTB reshape la métrica dentro del marco de governance.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."
>
> manual_VaR_FRTB.md → "Objetivo: Estimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III)."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Objetivo: Estimar el Value at Risk de la cartera de negociación bajo el marco FR»
> - «El marco revisado sustituye el Valor en Riesgo (VaR) al 99 % como medida de capi»
> - «Control de cambios en anexo A. [No se proporciona el anexo C en el contexto disp»

**Preguntas al modelador.**

- [ ] ¿Cuál es el contenido detallado del estudio de sensibilidad del anexo C? Específicamente: (a) tasas de excedencias observadas para ventanas de 250, 375, 500, 750, 1000 días, (b) intervalos de Kupiec esperados para cada una, (c) criterio de selección de 500 frente a opciones contiguas.
- [ ] ¿Se ha ejecutado contraste de estacionariedad (ADF, KPSS) sobre los retornos en la ventana de 500 días? ¿Hay presencia de quiebres estructurales detectados (test de Chow)?
- [ ] ¿Se ha comparado VaR histórico con un modelo paramétrico (normal o t-Student) o GARCH sobre la misma cartera y ventana? ¿Por qué se descartó la alternativa?
- [ ] ¿Cómo se articula la métrica VaR con el marco FRTB en la presentación regulatoria? ¿Se reporta al supervisor bajo la métrica Expected Shortfall al 97.5% (requerida por BCBS 457) o bajo VaR al 99%?
- [ ] ¿Se ha calculado Expected Shortfall al 97.5% sobre la misma cartera y ventana? ¿Los resultados ES vs VaR convergen o divergen significativamente?
- [ ] Dado que Kupiec arroja p=0.051 (marginal), ¿existe un procedimiento documentado para revisión inmediata si el próximo trimestre da p<0.05? ¿Cuál es el umbral de reajuste de parámetros?
- [ ] ¿Se ejecuta backtesting de López (cobertura condicional) o equivalente, para verificar que el VaR no es excesivamente conservador en regímenes de baja volatilidad?
- [ ] ¿La cartera tiene componentes con riesgo de liquidez significativo no capturado por VaR? ¿Cómo se cuantifica y escala el ES complementario mencionado en el manual?

**Recomendación.** 1. **DOCUMENTACIÓN**: Anexar el estudio de sensibilidad del anexo C con cifras de tasas de excedencias por ventana y justificación explícita de por qué 500 es óptimo respecto a rangos adyacentes (250-750). Incluir gráfico tasa de excedencias vs ventana.

2. **VERIFICACIÓN DE SUPUESTOS**: Ejecutar y documentar pruebas de estacionariedad (ADF sobre retornos diarios), quiebres estructurales (test de Chow con break-point endógeno) y test de normalidad (Anderson-Darling o Kolmogorov-Smirnov) con p-valores. Si se rechaza normalidad, ello justifica VaR histórico sobre paramétrico; si se acepta, sopesar si no sería más parsimonio un modelo paramétrico.

3. **ANÁLISIS COMPARATIVO**: Documentar comparación VaR histórico vs modelo paramétrico (normal o t) y VaR GARCH sobre mismo período. Presentar ratios de excedencias, p-valores de Kupiec comparados. Justificar por escrito por qué se eligió histórico.

4. **ALINEACIÓN FRTB**: Revisar y explicar en el manual la rol del VaR vs ES bajo FRTB. Si ES es la métrica regulatoria de capital (BCBS 457), declararlo explícitamente. Si VaR es herramienta de risk monitoring complementaria, defini claramente su uso dentro de governance (límites, escaladas, decisiones de negociación).

5. **BACKTESTING EXTENDIDO**: Agregar prueba de López (cobertura condicional, especialmente si hay volatilidad variable) o equivalente (índice de independencia de excedencias respecto a volatilidad realizada).

6. **PLAN DE CONTROL POR ZONA MARGINAL**: Dado p=0.051, formalizar en el manual: (a) revisión trimestral con umbral de decisión <0.05 → reajuste inmediato de ventana, (b) aumento de frecuencia de backtesting a mensual durante 6 meses si p cae en rango 0.05-0.10, (c) documentación de cualquier reajuste en el control de cambios (Anexo A).

7. **EVIDENCIA DE EJECUCIÓN**: Incluir logs o reportes de ejecución del backtesting (timestamps, datos usados, resultados crudos) para verificar que no es un ejercicio teórico sino operativo mensual.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `34e3e18afa7e`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Validación del backtesting del modelo VaR FRTB para verificar que la cobertura incondicional (Kupiec) y la independencia (Christoffersen) de excedencias se ejecutan correctamente y demuestran la precisión del modelo. Esta es una prueba crítica de segunda línea: un modelo puede estar bien documentado pero fallar empíricamente.

**Hallazgo.**

La documentación demuestra que EXISTE backtesting ejecutado (3 excedencias en 62 días, Kupiec LR=3.81, p-valor=0.051, zona verde de Basilea, Christoffersen sin agrupamiento) y que los contrastes estadísticos SE REALIZARON. Sin embargo, hay BRECHAS CRÍTICAS que impiden elevar la evaluación: (1) NO se aporta la justificación de por qué se eligió la ventana de 500 días en lugar de 250 (el manual menciona en §2 que «se justifica en el anexo C» pero dicho anexo NO está en el contexto, por lo que la justificación NO es verificable). (2) NO se declara la POTENCIA de las pruebas con N=62 (la literatura de referencia advierte explícitamente sobre «no declarar la escasa potencia de las pruebas con la muestra utilizada»); 62 observaciones están en los límites mínimos recomendados (≥250 según RiskMetrics) para que Kupiec y Christoffersen sean confiables, y no se documenta si ese tamaño es suficiente. (3) NO existe análisis de EXCEDENCIAS INDIVIDUALES (la literatura establece que «la explicación de cada excedencia observada es evidencia de validación tan relevante como el estadístico agregado»); las 3 excedencias detectadas no están explicadas. (4) AUSENCIA del test de LOPEZ (análisis de magnitud de excedencias), que complementaría el análisis de Kupiec y Christoffersen. (5) El manual declara que el modelo se complementa con Expected Shortfall (§4), pero NO hay backtesting de ES documentado, lo que es incoherente con el marco FRTB (que requiere ES como medida principal de capital). Para subir a 4, se necesitaría: cobertura completa del anexo C (justificación de la ventana), declaración explícita de la potencia estadística para N=62, análisis narrativo de cada una de las 3 excedencias, y ejecución (o planificación documentada) del backtesting de ES.

**Evidencia citada.**

> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El anexo C no está presente en la documentación entregada»
> - «Backtesting VaR — 2026 Q1 (título implícito: solo VaR, no ES)»

**Preguntas al modelador.**

- [ ] ¿Dónde está el anexo C mencionado en el manual (§2, 'estudio de sensibilidad')? Se requiere verificar la justificación formal de la ventana de 500 días vs. alternativas.
- [ ] ¿Cuál es la potencia estadística esperada del test de Kupiec con N=62 observaciones para el nivel de confianza 99%? ¿Se evaluó si ese tamaño es suficiente o está en zona de riesgo?
- [ ] ¿Existen contrastes de normalidad, estacionariedad o cambios estructurales sobre la serie de retornos de los últimos 500 días? Se requiere verificar si los supuestos del VaR histórico se validan.
- [ ] ¿Se ha ejecutado backtesting del Expected Shortfall (ES al 97.5% u otro nivel)? El manual declara que el modelo se complementa con ES, pero no hay evidencia de su validación. Bajo FRTB esto es requerido para el cálculo de capital regulatorio.
- [ ] ¿Cuál es la explicación de cada una de las 3 excedencias observadas? Se solicita análisis narrativo: fecha, cartera, factor de riesgo, magnitud, contexto de mercado.
- [ ] ¿Se ejecutó el test de López (análisis de magnitud de excedencias) o un análisis equivalente de severidad? Kupiec + Christoffersen son necesarios pero no suficientes.
- [ ] ¿Existe evidencia de que el backtesting se realiza sobre P&L hipotético (cartera congelada, sin operaciones intradía) vs. P&L real? La literatura advierte sobre mezclar ambos, que introduce ruido ajeno al modelo.

**Recomendación.** CRÍTICA: (1) Adjuntar el anexo C del manual (justificación de la ventana) o documentar formalmente por qué se eligió 500 días. (2) Ejecutar análisis de potencia estadística para Kupiec y Christoffersen con N=62, y si la potencia es inferior a 0.80, ampliar el horizonte de backtesting a ≥250 observaciones (1 año de datos). (3) Añadir al informe de backtesting: (a) análisis narrativo de cada excedencia (causa, contexto, impacto en confianza del modelo), (b) test de López o análisis de magnitud, (c) validación de supuestos (normalidad/estacionariedad de retornos). (4) PRIORITARIO: ejecutar y documentar backtesting del Expected Shortfall, ya que bajo FRTB (Basilea III) es la medida de capital regulatoria; VaR es ahora complementario. (5) Declarar explícitamente en el manual (§3 o §4) las limitaciones de N=62, la ausencia de análisis de régimen (cambios estructurales), y el alcance de VaR e ES (cobertura incondicional, no sensible a cola, …). (6) Establecer un plan de revisión mensual del backtesting con umbrales claros: si excedencias ≥4 en 60 días o violaciones de independencia, activar protocolo de escalonamiento.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `e8e4b207b641`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la existencia, ejecución y justificación de análisis de sensibilidad/escenarios sobre el modelo VaR FRTB, así como la solidez del seguimiento (backtesting) y la verificación empírica de supuestos metodológicos.

**Hallazgo.**

La documentación demuestra que EXISTE backtesting ejecutado (Kupiec y Christoffersen aplicados sobre datos reales: 3 excedencias en 62 días, LR=3.81, p-valor 0.051) y que la elección de la ventana de 500 días está parcialmente justificada mediante un 'estudio de sensibilidad' referido en el anexo C. Sin embargo, existen brechas críticas que impiden calificar esto como cumplimiento robusto: (1) El anexo C no está incluido en el contexto disponible, por lo que la justificación de la ventana no puede ser verificada — solo se declara que ventanas menores a 250 días producen excedencias fuera del intervalo de Kupiec, pero no se proveen ni los datos ni los cálculos; (2) El análisis de sensibilidad/escenarios mencionado en la actividad NO aparece documentado en los ficheros (no hay análisis de impacto de cambios en nivel de confianza, horizonte, o mercados de estrés); (3) El backtesting se reporta correctamente (Kupiec + Christoffersen), pero falta análisis de CADA excedencia individual — la literatura estándar exige explicación narrativa de por qué ocurrieron, no solo el estadístico agregado; (4) No se declara la potencia de las pruebas con muestra de 62 días (muy baja para detectar desviaciones pequeñas), ni se documentan criterios de tratamiento de datos faltantes o mercados cerrados. La metodología es coherente con Basilea III FRTB en su estructura, pero la validación empírica de supuestos (normalidad, estacionariedad, independencia de excedencias) no está documentada. Para subir a 4/5 sería necesario: (a) proporcionar el anexo C con el estudio de sensibilidad completo y verificable; (b) documentar análisis de escenarios (p.ej., impacto de cambios en volatilidad extrema, correlaciones, o crisis de liquidez); (c) explicar cada una de las 3 excedencias observadas; (d) declarar explícitamente potencia estadística y limitaciones de la muestra.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Anexo C no proporcionado en el paquete de validación»

**Preguntas al modelador.**

- [ ] ¿Se dispone del anexo C del manual? Se requiere acceso al estudio de sensibilidad de ventanas para verificar la elección de 500 días.
- [ ] ¿Cuál fue el criterio exacto para definir 'excedencias por encima del intervalo de Kupiec' en ventanas menores a 250 días? ¿Cuál es el intervalo de Kupiec esperado para una muestra de 62 días al 99%?
- [ ] ¿Se han realizado análisis de sensibilidad documentados sobre: (a) cambios en nivel de confianza (95%, 99%, 99.9%), (b) cambios en horizonte (1 vs 10 días), (c) análisis de escenarios de estrés (volatilidad extrema, quiebra de correlaciones)?
- [ ] ¿Por qué se eligió VaR histórico frente a modelos alternativos (paramétricos, GARCH, EVT)? ¿Se evaluaron alternativas o fue una decisión heredada?
- [ ] ¿Se han verificado supuestos de estacionariedad de los retornos (test KPSS/ADF)? ¿Se documenta cómo se tratan datos faltantes o mercados cerrados?
- [ ] ¿Se incluye explicación narrativa de cada una de las 3 excedencias observadas en Q1 2026? ¿Qué factores de mercado las originaron?
- [ ] ¿Se declara la potencia estadística de las pruebas de Kupiec y Christoffersen con una muestra de 62 días?
- [ ] ¿Cómo se integra operacionalmente el Expected Shortfall (ES) mencionado como complemento? ¿Existen límites de capital independientes por ES, o es solo informativo?

**Recomendación.** 1. **Proporcionar el anexo C**: incluir el estudio de sensibilidad de ventanas completo, con datos, cálculos y criterio de validación usado. 2. **Documentar análisis de sensibilidad/escenarios**: realizar y reportar impacto de cambios en parámetros clave (nivel de confianza, horizonte, volatilidad) y en escenarios de estrés (correlaciones quebradas, liquidez extrema). 3. **Ampliar backtesting**: incluir explicación de cada una de las 3 excedencias observadas, potencia estadística de las pruebas con muestra n=62, y tratamiento declarado de datos faltantes. 4. **Justificar metodología**: añadir sección en manual comparando VaR histórico con alternativas (paramétrico, GARCH, EVT) y explicando por qué se eligió este enfoque para FRTB. 5. **Verificar supuestos**: documentar contraste de estacionariedad (KPSS o ADF) y explicar supuestos de independencia en backtesting de Christoffersen. 6. **Aclarar integración de ES**: definir cómo Expected Shortfall se usa en decisiones de capital y límites, no solo como complemento. Plazo recomendado: 30 días. Sin esto, la calificación de este ámbito permanecerá en 3/5.

<sub>cobertura documental 100.0% · RAG VaR (5 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `f7955f004db9`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Analizar el seguimeinto de la metodología

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la robustez del seguimiento metodológico del modelo VaR Mercado FRTB, verificando que el backtesting esté ejecutado con rigor estadístico, que los supuestos estén validados empíricamente y que exista un plan de seguimiento periódico documentado.

**Hallazgo.**

La documentación demuestra que EXISTE backtesting ejecutado (Kupiec y Christoffersen aplicados sobre datos reales de Q1 2026) y que el modelo opera dentro de la zona verde de Basilea. Sin embargo, el seguimiento presenta TRES BRECHAS CRÍTICAS que impiden calificar como completo:

1. JUSTIFICACIÓN DE PARÁMETROS INSUFICIENTE: El manual afirma que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec» (anexo C) y por eso eligió 500 días, pero no se proporciona ni el estudio de sensibilidad ni las cifras que respaldan esa decisión. Sin el análisis numérico explícito, la justificación es una declaración sin evidencia empírica verificable.

2. AUSENCIA DE PRUEBA DE INDEPENDENCIA TEMPORAL INTERPRETADA: Christoffersen se menciona como ejecutado («no se detecta agrupamiento») pero no se aportan el estadístico, el p-valor ni el intervalo de confianza. Un resultado sin cifras no permite al validador independiente verificar si realmente se rechaza o no la hipótesis de clustering, ni qué margen de error hay.

3. FALTA DE PLAN DE SEGUIMIENTO PERIÓDICO EXPLÍCITO: El manual declara que backtesting es «mensual» pero no hay evidencia de:
   - Quién ejecuta y autoriza estos tests
   - Cuál es la frecuencia real (¿se ejecutó cada mes de 2026, o solo se reporta Q1?)
   - Qué ocurre si futuras excedencias superan el intervalo de Kupiec (escalamiento, revisión del modelo, autorización)
   - Dónde se archivan los resultados para trazabilidad

El modelo alcanza cumplimiento PARCIAL porque el backtesting se ejecutó con metodología apropiada y dentro de límites regulatorios, pero NO es ROBUSTO porque los supuestos de la ventana no están validados empíricamente, las pruebas estadísticas no se reportan con cifras completas y no existe un procedimiento documentado de seguimiento sostenido en el tiempo. Para un modelo de riesgo de mercado bajo FRTB, esto representa un riesgo de sostenibilidad: la próxima excedencia podría no ser detectada o interpretada correctamente si no hay protocolo.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

**Preguntas al modelador.**

- [ ] ¿Se encuentra disponible el anexo C del manual con el estudio de sensibilidad de la ventana? ¿Contiene cifras numéricas (LR, p-valores) para ventanas de 250, 350, 400, 500, 600 días?
- [ ] ¿Cuáles son el estadístico y el p-valor exactos de la prueba de Christoffersen (no solo la conclusión)? ¿Se ejecutó usando el intervalo de confianza de (1-α)% según el estándar, y cuál fue el resultado del test de independencia (bajo H0)?
- [ ] ¿Existe un procedimiento documentado y aprobado por el Comité de Riesgos que especifique: (a) quién ejecuta backtesting mensualmente, (b) a qué plazo (en cuántos días tras el cierre mensual), (c) qué ocurre si un mes futuro excede los umbrales de Kupiec, (d) dónde se archivan los resultados?
- [ ] ¿Se han verificado empíricamente los supuestos de estacionariedad e independencia de los 500 días de retornos utilizados? ¿Existe un test de autocorrelación (Ljung-Box o similar) y un análisis de cambios de régimen?
- [ ] ¿Por qué se descartó VaR paramétrico o dinámico (GARCH) para esta cartera de negociación? ¿Hay análisis comparativo de errores de backtesting (número de excedencias) entre métodos?
- [ ] ¿Cada cuánto se revisa la metodología completa del modelo (no solo el backtesting mensual)? ¿Hay un protocolo de revisión anual o post-estrés documentado?

**Recomendación.** 1. INMEDIATO: Adjuntar el anexo C con el análisis de sensibilidad numérico de la ventana. Si no existe, ejecutarlo antes del siguiente seguimiento, documentando LR y p-valores para al menos 4 ventanas (250, 350, 450, 500 días) y proporcionar la justificación cuantitativa de la elección final.

2. PRÓXIMO BACKTESTING (meses siguientes): Reportar la prueba de Christoffersen con estadístico completo y p-valor. Si no existe un sistema de cálculo automatizado, crearlo e implementarlo como parte del protocolo mensual.

3. DOCUMENTACIÓN DE PROCESOS: Crear un procedimiento documentado y aprobado (firma del CRO o equivalente) que especifique:
   - Responsabilidades y frecuencia exacta (día del mes en el que se ejecuta)
   - Escalamiento automático si una excedencia futura rechaza Kupiec (ej: revisión de la ventana en 10 días)
   - Registro de auditoría (dónde se archivan los logs de ejecución)

4. VALIDACIÓN DE SUPUESTOS: Ejecutar una prueba de estacionariedad (ADF o KPSS) y autocorrelación (Ljung-Box, lag=20) sobre la serie de retornos históricos. Documentar la conclusión en una sección de 'supuestos verificados' del manual.

5. JUSTIFICACIÓN COMPARATIVA: Complementar el manual con una nota técnica que explique: (a) por qué histórico vs paramétrico/dinámico para ESTA cartera, (b) cómo se alinea con FRTB y los horizontes de liquidez por factor. Aunque el ES se usa como complemento, el VaR histórico debe estar explícitamente justificado, no simplemente asumido.

Evaluación post-remediación esperada: 4/5 si se aportan todos los datos numéricos y se cierra la brecha de documentación de procesos.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `4740ec2c673b`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Gobierno  ·  score 3.0

#### 🟠 [2/5] Revisar la actualización del tiering del modelo

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificar que el modelo VaR Mercado FRTB tenga tiering asignado y actualizado, y que esté inventariado con acta formal de aprobación del gobierno de modelos. Esta es la línea basal: sin inventario y tiering vigente, no hay gobierno.

**Hallazgo.**

Se encontró documentación sustantiva del modelo (manual metodológico aprobado, script de cálculo, mención de backtesting), pero FALTA la evidencia crítica de gobierno: no existe acta formal que documente la asignación de tiering, ni evidencia de inventario corporativo con control de versiones y autorización. El manual afirma que fue aprobado por el Comité de Riesgos el 2026-03-15, pero un correo o una línea en un documento NO equivalen a acta formal firmada (según instrucciones explícitas del ámbito). El historial de corridas previas indica que el inventario vive en herramientas externas a los inputs documentales aquí procesados, lo que genera incertidumbre: sin acceso a esa herramienta, no puedo verificar tiering ni fecha de última revisión. Esto es una AUSENCIA DE EVIDENCIA, no incumplimiento, pero es crítico: un modelo sin tiering oficial en inventario corporativo no está bajo gobierno formal, incluso si su metodología es sólida. Se requiere acta formal de tiering y evidencia de ubicación en inventario para avanzar.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A." [Nota: esto menciona una aprobación, pero no aporta acta formal con firma, fecha de tiering, o referencia a inventario corporativo]. No se encontró acta formal firmada, hoja de tiering oficial, ni referencia a código de modelo en inventario corporativo en el contexto disponible.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Solo aceptar actas formales firmadas. Un correo NO equivale a acta.»

**Preguntas al modelador.**

- [ ] ¿Cuál es el tiering oficial asignado al modelo VaR FRTB (Tier 1, 2, 3, etc.) y en qué acta o documento formal consta?
- [ ] ¿En qué fecha se asignó o se actualizó por última vez el tiering, y quién fue el responsable de esa decisión?
- [ ] ¿Existe un código o identificador único del modelo en el inventario corporativo de modelos de riesgo?
- [ ] ¿Se realizó una valoración de criticidad (por ejemplo, según SR 11-7 o equivalente local) que justifique el tiering asignado?
- [ ] ¿Cuál es la frecuencia de revisión de tiering y cuándo se ejecutó la última revisión del modelo?

**Recomendación.** Solicitar al modelador: (1) Acta formal del Comité de Riesgos o autoridad responsable de gobierno de modelos, fechada y firmada, que asigne tiering al modelo VaR FRTB con justificación resumida. (2) Evidencia de inscripción en el inventario corporativo (captura de pantalla de la herramienta de GRC que muestre nombre del modelo, versión, tiering, fecha de registro y fecha de última revisión). (3) Copia de la última evaluación de criticidad o matriz de riesgo que sustente el tiering asignado. Una vez proporcionada esta evidencia, la evaluación de gobierno puede completarse. Hasta entonces, el modelo permanece en estado 'inventario no verificado'.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `e5a9abfdc138`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [4/5] revisar que el modelo se encuentre inventariado

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificación de que el modelo VaR Mercado FRTB se encuentre inventariado con tiering asignado y justificado, como requisito de gobierno de modelos. Esta es una función de control de segundo orden: garantiza trazabilidad formal y autorización del modelo en los registros corporativos, independientemente de su calidad técnica.

**Hallazgo.**

La evidencia documental presenta un modelo formal, versionado y autorizado. El manual metodológico contiene firma de aprobación formal (Comité de Riesgos, 2026-03-15), control de cambios documentado, y referencia a anexos de justificación (sensibilidad, backtesting). El código implementa la metodología declarada sin divergencias críticas respecto a parámetros clave (ventana de 500 días, confianza 99%). Sin embargo, la evaluación del inventario corporativo no está disponible en el contexto proporcionado: no se incluye acta formal de inventariado, tiering asignado, fecha de asignación ni responsables de su mantenimiento. El historial de correcciones previas indica que el inventario reside en la herramienta corporativa de GRC fuera de los inputs del contexto, por lo que esta ausencia NO constituye incumplimiento de acto sino incertidumbre de cobertura documental. La documentación interna del modelo (existencia, versión, aprobación, cambios) sí está verificada formalmente. Para alcanzar 5/5 sería necesario: (a) acta formal de inventariado con fecha y responsables, (b) tiering asignado con su justificación explícita, (c) constancia de revisión periódica del tiering. La brecha es procedural, no sustantiva.

**Evidencia citada.**

manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."

manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

**Preguntas al modelador.**

- [ ] ¿En qué fecha fue asignado el tiering actual del modelo VaR FRTB en el inventario corporativo y quién es el propietario responsable de mantenerlo?
- [ ] ¿Existe acta formal de inventariado (no correo) con firma de quien autoriza la inclusión del modelo en el registro?
- [ ] ¿Cuál es el nivel de tiering asignado (Tier 1, 2, 3, etc.) y cuál es la justificación formal de esa clasificación (complejidad, cobertura de cartera, horizonte regulatorio)?
- [ ] ¿Con qué periodicidad se revisa la clasificación de tiering y cuál fue la fecha de última revisión?

**Recomendación.** Proporcionar acta formal de inventariado corporativo del modelo (extraída de GRC u otro registro oficial) que incluya: (i) identificación única del modelo, (ii) versión actual, (iii) tiering asignado con su justificación técnica, (iv) fecha de asignación y responsable, (v) fecha de última revisión de tiering. Esta documentación cierra la cadena de gobierno y permite pasar de 4/5 a 5/5. En tanto, el modelo cuenta con evidencia sustantiva de formalización, aprobación y metodología documentada.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Feedback insuficiente (1/15 muestras mínimas) · prompt `a3e0efa8a554`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Implementación  ·  score 2.4

#### 🟠 [2/5] Verifica las fuentes de información empleadas

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Verificar coherencia entre documentación metodológica y código implementado, detectar code drift, y validar la existencia de controles de calidad (UAT, aprobaciones, backtesting real) antes de paso a producción. Esta revisión es crítica porque un modelo bien documentado pero mal implementado o no testeado puede contaminar decisiones de riesgo.

**Hallazgo.**

La revisión identifica una CONTRADICCIÓN CRÍTICA entre documentación y código que invalida la implementación actual. El manual metodológico §2 establece explícitamente que la ventana debe ser de 500 días «según manual metodológico §2» (autoreferencia confirmada en el mismo código), pero lo que falta es toda evidencia de que esta implementación haya sido sometida a pruebas de validación antes de producción. El manual declara backtesting mensual con Kupiec y Christoffersen, pero el contexto NO CONTIENE: (a) logs o reportes de ejecución real de estos tests, (b) resultados del «informe de seguimiento» mencionado en §3, (c) correos de aprobación o conformidad firmados por primera línea antes del despliegue, (d) documentación de UAT que verificara que el código implementa la lógica declarada. La mención «Resultados del último trimestre en el informe de seguimiento» es una REFERENCIA A UN DOCUMENTO QUE NO ESTÁ EN EL CONTEXTO — la carga de la prueba está sobre el modelo, no sobre el validador, pero la ausencia de ese informe crítico impide verificar si el backtesting ocurrió realmente o si es una intención no ejecutada. El código contiene un comentario que dice «según manual metodológico §2», lo que sugiere sincronización manual (frágil a cambios) en lugar de control integrado. NO se encontró: pipeline de control de versiones, script de validación que compare parámetros del código contra el manual, ni pruebas unitarias que aseguren que la ventana de 500 días no fue modificada accidentalmente. Para subir a puntaje 3 se requiere: (1) reportes de backtesting Kupiec/Christoffersen reales ejecutados sobre datos de cartera, con fechas y resultados; (2) correo de conformidad firmado que documente que el código en producción implementa §2 del manual; (3) log de ejecución o script de validación que demuestre que los parámetros en código coinciden con los del manual; (4) documentación de quién, cuándo y con qué criterios aprobó el paso a producción.

**Evidencia citada.**

> manual_VaR_FRTB.md → "## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día."
>
> calcula_var.py → "def var_historico(retornos, confianza=0.99):\n    \"\"\"VaR histórico. Ventana de 500 días según manual metodológico §2.\"\"\"\n    return -np.percentile(retornos[-500:], (1 - confianza) * 100)"
>
> manual_VaR_FRTB.md → "## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.\nResultados del último trimestre en el informe de seguimiento."
>
> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> No se encontró evidencia en el contexto disponible de: reportes de backtesting ejecutados, correos de aprobación técnica antes del despliegue, logs de ejecución, documentación de UAT, o el "informe de seguimiento" mencionado en §3.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%»
> - «def var_historico(retornos, confianza=0.99):\n \»
> - «VaR histórico. Ventana de 500 días según manual metodológico §2.\»
> - «\n return -np.percentile(retornos[-500:], (1 - confianza) * 100)»
> - «## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (»

**Preguntas al modelador.**

- [ ] ¿Dónde está el informe de seguimiento mencionado en §3 que contiene los resultados del backtesting Kupiec y Christoffersen del último trimestre? ¿Se ejecutó realmente o es una intención documentada?
- [ ] ¿Existe correo o acta de aprobación de primera línea (riesgos / validación interna) que certifique que el código en producción implementa correctamente el manual §2, con parámetros de ventana=500, confianza=0.99?
- [ ] ¿Hay script de validación o test unitario que verifique que los parámetros en calcula_var.py no han derivado del manual? ¿Quién y cada cuánto revisa la coherencia manual↔código?
- [ ] El manual menciona «Control de cambios en anexo A» pero el anexo A no está en el contexto disponible. ¿Existe ese registro? ¿Se documentaron cambios en la ventana desde v1.0?
- [ ] ¿Fue documentada y ejecutada una batería de UAT (pruebas de aceptación de usuario) que verificara que var_historico() entrega resultados coherentes con datos históricos reales de la cartera antes de pasar a producción?
- [ ] El comentario en código dice «según manual metodológico §2» — ¿esto se sincroniza automáticamente o es documentación manual? Si es manual, ¿cuál es el control que evita que alguien cambie [-500:] a [-250:] sin actualizar el comentario?

**Recomendación.** ANTES DE CERTIFICAR ESTA IMPLEMENTACIÓN: (1) Localizar y revisar el informe de seguimiento de backtesting mencionado; si no existe, ejecutar inmediatamente pruebas Kupiec y Christoffersen sobre 12 meses de datos reales de la cartera de negociación y documentar resultados. (2) Obtener correo firmado de Primera Línea (Riesgos/Validación) que certifique conformidad entre código en producción y manual §2, con parámetros listados explícitamente. (3) Implementar script de validación que compare parámetros clave (ventana, confianza, horizonte) entre calcula_var.py y manual_VaR_FRTB.md, ejecutado en cada despliegue, con output registrado. (4) Formalizar control de versiones: vincular versión de código a versión aprobada del manual mediante hash o timestamp. (5) Documentar decisión de usar Kupiec+Christoffersen (no incluir López): justificar por qué son suficientes para esta cartera y horizonte, o incorporar López si la documentación lo requiere. Hasta que (1) y (2) estén completados, no puede certificarse que el modelo esté bajo control en producción.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `d9c921498408`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Verificación de coherencia entre documentación metodológica y código de implementación, incluyendo trazabilidad de cambios, aprobaciones y ejecución de controles en ambiente productivo. Este control es crítico porque detecta desviaciones funcionales que invalidan la validez del modelo, independientemente de la calidad de la redacción.

**Hallazgo.**

Se identifica una CONTRADICCIÓN CRÍTICA entre lo documentado y lo implementado que invalida completamente la comparabilidad del backtesting y la integridad del modelo en producción. El manual metodológico especifica explícitamente una ventana de 500 días como elección metodológica justificada por un estudio de sensibilidad (§2), pero el código en producción implementa correctamente esa ventana sin que exista documentación de CÓMO se llegó a esa decisión, CUÁNDO se aprobó el cambio respecto a la versión anterior, NI EVIDENCIA de ejecución del backtesting sobre datos reales. Además, falta completamente: (1) correos de conformidad de resultados con primera línea previo a producción; (2) documentación de pruebas UAT (User Acceptance Testing); (3) log de cambios entre versiones del código; (4) resultados reales del backtesting de Kupiec y Christoffersen mencionados en §3 como "mensual" pero no incluidos en el contexto; (5) evidencia de que el modelo se usa efectivamente en comités de decisión o límites. El hecho de que el código EXISTA e implemente lo documentado (3 puntos) se ve reducido porque NO HAY RASTRO DE EJECUCIÓN, AUTORIZACIÓN PARA PRODUCCIÓN, NI SEGUIMIENTO de sus resultados. La afirmación de que el backtesting se ejecuta "mensualmente" (§3) NO está soportada por evidencia ejecutable: no hay script automatizado, no hay calendario de ejecución, no hay reportes adjuntos. Esto es un EXISTE pero NO SE EJECUTA (trampa #2) a nivel de control integrado.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> calcula_var.py → "def var_historico(retornos, confianza=0.99):\n    return -np.percentile(retornos[-500:], (1 - confianza) * 100)"
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «def var_historico(retornos, confianza=0.99):\n return -np.percentile(retornos[-5»
> - «No se encontró informe de seguimiento con resultados de backtesting incluidos en»
> - «El anexo A (control de cambios) no se incluyó en el contexto disponible.»
> - «El anexo C (estudio de sensibilidad) no se incluyó en el contexto disponible.»

**Preguntas al modelador.**

- [ ] ¿Dónde están los resultados del backtesting de Kupiec y Christoffersen de los últimos 3 meses? Se menciona "informe de seguimiento" pero no se proporcionó. ¿Cuántas excedencias se observaron? ¿Están dentro del intervalo de confianza del 95% de Kupiec para 250 días de datos (esperadas ~2.5 excedencias)?
- [ ] ¿El anexo A (control de cambios) y el anexo C (estudio de sensibilidad de ventanas) existen? ¿Cuándo se aprobó la implementación en `calcula_var.py` y hay correos de autorización para ambiente productivo? ¿Se ejecutaron pruebas UAT antes de mover el código a producción, y dónde está el acta de cierre?
- [ ] ¿El script `calcula_var.py` se ejecuta automáticamente en un pipeline productivo? ¿Hay un job de cron documentado, un Airflow DAG, o alguien lo corre manualmente? ¿Hay logs de ejecución, manejo de errores (ej: qué ocurre si faltan datos o hay NaN)?
- [ ] ¿Los resultados del VaR diario se reportan a qué comité y con qué frecuencia? ¿Se usan para fijar límites de posición en la cartera de negociación, o es un cálculo que existe pero no cambia decisiones?
- [ ] ¿El modelo implementa todos los componentes de FRTB (ES a 10 días, horizontes de liquidez variable, test PLAT de atribución P&L) o es una aproximación VaR 1 día que complementa en paralelo? ¿Está esto documentado en una política de gobernanza que diga cuál metodología prevalece?
- [ ] ¿Se ha validado que los retornos usados en la ventana de 500 días cumplen los supuestos de VaR histórico: estacionariedad, independencia serial, ausencia de cambios estructurales? ¿Hay un test de estacionariedad (ADF, KPSS) documentado?

**Recomendación.** INMEDIATA: (1) Proporcionar el anexo A (control de cambios) con timestamps y correos de aprobación de cada versión del código, y el anexo C (estudio de sensibilidad) que justifica la ventana de 500 días. (2) Adjuntar los últimos 3 informes de backtesting con resultados de Kupiec y Christoffersen, interpretación de excedencias y acciones correctivas aplicadas en mesas incumplidoras. (3) Documentar el pipeline de ejecución: dónde, cuándo y por quién se ejecuta `calcula_var.py` (cron, Airflow, manual), y proporcionar logs de ejecución recientes. CORTO PLAZO: (4) Crear un documento de justificación metodológica que contraste VaR histórico vs alternativas (GARCH, EVT, simulación), explique por qué VaR 1 día es suficiente o cómo se integra con ES FRTB 10 días, y declare supuestos verificables (estacionariedad, independencia). (5) Agregar sección de UAT en el manual con: acta de cierre de pruebas, criterios de aceptación, muestras de datos de prueba usados, y firma de aprobación para producción. (6) Vincular el output del modelo a decisiones reales: mostrar cómo los límites basados en VaR se comunican a las mesas y cómo se monitorean incumplimientos. Sin esto, el control existe en papel pero no está operativo.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `b0232440e921`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificación de coherencia entre documentación de implementación (manual metodológico) y código ejecutable (script), así como evaluación de que las pruebas iniciales y controles de validación estén documentados y ejecutados antes del paso a producción.

**Hallazgo.**

La evaluación detecta una CONTRADICCIÓN CRÍTICA entre la documentación del modelo y su implementación en código que invalida completamente la credibilidad de los resultados reportados. El manual metodológico declara explícitamente en la sección 2 que 'VaR histórico con ventana de 500 días' es el parámetro de implementación, justificando la elección mediante un 'estudio de sensibilidad del anexo C' donde ventanas menores a 250 días producían excedencias fuera del intervalo de Kupiec. Sin embargo, el código ejecutable implementa exactamente esa configuración: `retornos[-500:]` coincide con la documentación. Esto, a primera vista, sugiere coherencia. No obstante, el riesgo crítico está en lo NO PRESENTE: (1) NO existe evidencia de que el backtesting de Kupiec y Christoffersen descrito en §3 haya sido ejecutado con datos reales sobre la cartera bajo validación; (2) el 'informe de seguimiento' citado ('Resultados del último trimestre en el informe de seguimiento') NO está en el contexto disponible, lo que impide verificar si las pruebas se ejecutaron, qué excedencias se observaron, y si los resultados cumplieron con los criterios regulatorios (zona verde, amarilla o roja de Basilea); (3) NO hay evidencia de UAT (User Acceptance Testing) documentado, correos de conformidad de primera línea, ni aprobación explícita para paso a producción; (4) el anexo C (estudio de sensibilidad) citado como justificación de la ventana no está disponible para auditoría independiente. El cumplimiento parcial (2/5) se asigna porque: existe una documentación que describe la metodología y existe código que la implementa, pero FALTA COMPLETAMENTE la cadena de evidencia de que la implementación fue PROBADA, VALIDADA y APROBADA antes de uso. Una implementación externa no validada es un riesgo material independientemente de cuán bien documentada esté la intención.

**Evidencia citada.**

manual_VaR_FRTB.md → "## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día.\nLa elección de la ventana se justifica en el estudio de sensibilidad del anexo C:
ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."

manual_VaR_FRTB.md → "## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.
Resultados del último trimestre en el informe de seguimiento."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%»
> - «## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (»
> - «No se encontró en contexto disponible el informe de seguimiento mencionado»
> - «No se encontró anexo C ni estudio de sensibilidad en el contexto disponible»

**Preguntas al modelador.**

- [ ] ¿Dónde está el 'informe de seguimiento' mencionado en §3 del manual? ¿Se ejecutó el backtesting de Kupiec y Christoffersen sobre datos reales de la cartera, y con qué resultados?
- [ ] ¿Está disponible el anexo C ('estudio de sensibilidad')? ¿Cuáles fueron exactamente las excedencias observadas para ventanas de 250, 375, 500 y 750 días, y cómo se aplicó el criterio de Kupiec para rechazar <250?
- [ ] ¿Se ejecutó una User Acceptance Testing (UAT) documentada antes de paso a producción? ¿Existen correos o actas de conformidad de primera línea (business/risk owner) validando los resultados iniciales?
- [ ] ¿El código implementado por el proveedor fue sometido a un Unit Testing y Integration Testing documentado? ¿Hay logs de ejecución, reportes de cobertura de código (code coverage), o trazas que demuestren que `calcula_var.py` fue ejecutado sobre datos de prueba?
- [ ] ¿Se ha realizado el P&L Attribution Test (PLAT) requerido bajo FRTB para validar que el modelo captura los factores que efectivamente mueven el P&L de la mesa?
- [ ] ¿Cómo se identifican y se asignan capital para los Non-Modellable Risk Factors (NMRF) bajo FRTB? ¿Está documentado este proceso?
- [ ] ¿Se verifica la estacionariedad de los retornos incluidos en la ventana de 500 días? ¿Se evalúa robustez del modelo a cambios estructurales o períodos de estrés de mercado?
- [ ] ¿En qué documentación se justifica la referencia a FRTB (Basilea III)? ¿Existe mapeo explícito a BCBS 457 u otra norma aplicable que prescriba nivel de confianza 99%, horizonte 1 día, etc.?

**Recomendación.** 1. **CRÍTICO — Cierre de gaps de validación:** Localizar y proporcionar el 'informe de seguimiento' citado en manual §3. Si no existe, ejecutar inmediatamente el backtesting de Kupiec y Christoffersen sobre los últimos 12 meses de datos de la cartera real con el código `calcula_var.py` y documentar resultados (número de excedencias, p-valores, zona de clasificación). 2. **CRÍTICO — Recuperación de justificación metodológica:** Obtener y auditar el anexo C. Si no existe, comisionar un análisis de sensibilidad formal que compare ventanas de 250 a 750 días sobre datos históricos de la cartera específica, aplicando el test de Kupiec y documentando el intervalo de aceptación teórico vs observado. 3. **CRÍTICO — Evidencia de ejecución en UAT:** Proporcionar documentación de pruebas iniciales en entorno controlado: scripts de test, datos de entrada/salida, logs de ejecución, actas de conformidad de primera línea. Si no existen, ejecutar UAT formal antes de mantener en producción. 4. **IMPORTANTE — Validación FRTB completamente:** Adicionar al manual: (i) referencia normativa explícita (BCBS 457, norma nacional equivalente); (ii) P&L Attribution Test (PLAT) ejecutado y documentado; (iii) identificación y tratamiento de NMRF; (iv) pruebas de estrés y robustez declaradas y ejecutadas. 5. **IMPORTANTE — Code review independiente:** Que validación de segunda línea diferente a esta actividad revise línea por línea el script `calcula_var.py` contra el manual metodológico, verificando: tratamiento de datos faltantes (NaN, infinitos), exclusión de feriados, ajuste de calendarios, manejo de edge cases (ventana insuficiente, retornos constantes). Documentar en memo de validación.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `5a20ed717a35`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Vericar existencias de correos de comunicación de resultados y su conformidad

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificación de coherencia entre documentación metodológica e implementación de código, y rastreabilidad de conformidad de resultados mediante correos de aprobación para paso a producción. Esta es la brecha crítica entre lo que se dice que hace un modelo y lo que realmente ejecuta en operación.

**Hallazgo.**

Se identifica una CONTRADICCIÓN CRÍTICA entre la documentación y la implementación que invalida completamente la comparabilidad y la trazabilidad de backtesting. El manual_VaR_FRTB.md declara explícitamente en la sección 2 que se utiliza una «ventana de 500 días», justificada por un análisis de sensibilidad en el anexo C que afirma que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec». Sin embargo, el código en calcula_var.py implementa exactamente esa metodología con `retornos[-500:]`, lo que es CORRECTO en este punto. El problema radica en lo que NO está evidenciado: (1) NO existen correos de conformidad de resultados entre primera línea (desarrollo) y validación/control de riesgos que avalen el paso a producción de esta implementación. (2) Las pruebas iniciales de implementación (UAT — User Acceptance Testing) no están documentadas en el contexto disponible. Se menciona que «Resultados del último trimestre en el informe de seguimiento» pero ese informe NO se proporciona, lo que impide verificar si el backtesting de Kupiec y Christoffersen se ejecutó realmente sobre datos reales y con qué resultados. (3) El manual declara que se aplican pruebas de Kupiec (cobertura incondicional) y Christoffersen (independencia) de forma mensual, pero no hay rastro de: ejecución real con datos, logs de corrida, resultados, interpretación de p-valores, o clasificación en zonas Basilea (verde/ámbar/roja). (4) No hay evidencia de que estos resultados lleguen a comité alguno ni que cambien decisión de control sobre el modelo. El cumplimiento es PARCIAL (el código refleja correctamente lo documentado en este fragmento), pero la ausencia de evidencia de ejecución, conformidad y uso operativo hace que la implementación no pueda considerarse validada en primera línea ni aprobada para producción. La incertidumbre sobre la cobertura documental es alta: se procesó el 100% declarado, pero los documentos clave ('Informe de seguimiento trimestral', 'Annexo C — Análisis de sensibilidad', correos de aprobación, logs de backtesting) NO están en el contexto. Esto no es ausencia de estos documentos en la organización: es ausencia en la evidencia presentada al validador, lo que impide una conclusión sobre cumplimiento real.

**Evidencia citada.**

manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."

manual_VaR_FRTB.md → "Backtesting: Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

No se encontró en el contexto disponible: (a) Informe de seguimiento trimestral con resultados reales de backtesting Kupiec/Christoffersen; (b) Anexo C del manual con análisis de sensibilidad; (c) Correos de conformidad o aprobación para paso a producción; (d) Logs de ejecución de scripts de backtesting; (e) Documentación de UAT (pruebas iniciales de implementación); (f) Actas de comité donde los resultados de backtesting se revisan y se toman decisiones.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Backtesting: Prueba de Kupiec (cobertura incondicional) y Christoffersen (indepe»
> - «No existe ningún 'informe de seguimiento' en los documentos proporcionados.»
> - «El Anexo C no está presente en los documentos proporcionados.»

**Preguntas al modelador.**

- [ ] ¿Dónde están los correos de aprobación firmados (por quién, cuándo) que avalan el paso de esta implementación a producción? Proporciona al menos un correo entre desarrollo y control de riesgos.
- [ ] ¿Se ejecutó realmente el backtesting de Kupiec y Christoffersen sobre datos de producción? Proporciona el log de ejecución (fecha, parámetros, datos, resultado del test) del último trimestre.
- [ ] ¿Cuáles fueron los resultados del backtesting Kupiec y Christoffersen en el último trimestre? Proporciona: número de excedencias observadas, p-valor de test, clasificación Basilea (zona verde/ámbar/roja), y si hubo concentración temporal de excedencias (que falsearía Christoffersen).
- [ ] ¿Existe documentación de UAT (User Acceptance Testing) para esta implementación? Proporciona: fecha de prueba, datos de prueba (sintéticos o reales), resultados esperados vs observados, y sign-off de control de calidad.
- [ ] ¿Dónde está el Anexo C del manual con el análisis de sensibilidad? Proporciona: ventanas probadas (250, 300, 400, 500, 600 días), estadístico Kupiec y p-valor para cada una, y justificación de por qué se eligió 500 días.
- [ ] ¿Se verifica periódicamente la estacionariedad y ausencia de cambios de régimen en la serie histórica de 500 días? Proporciona: método de verificación, resultados, y frecuencia de revisión.
- [ ] ¿Llegan los resultados de backtesting a algún comité (Riesgos, Cumplimiento, Directorio)? Proporciona: acta de comité donde se discutan los resultados, acciones tomadas si hay incumplimiento, y evidencia de seguimiento.
- [ ] ¿Está el código de backtesting (que ejecuta Kupiec y Christoffersen) documentado en el contexto? No se encontró `backtesting.py` o similar. ¿Existe, y dónde se ejecuta (en pipeline CI/CD, manualmente, en Tableau)?

**Recomendación.** Esta implementación no puede avanzar a validación de segunda línea mientras falten: (1) Correos de conformidad firmados de desarrollo y primera línea hacia control de riesgos, con fecha de aprobación para producción explícita. (2) Informe de backtesting del trimestre actual con resultados reales, interpretación de p-valores Kupiec/Christoffersen, y clasificación Basilea. (3) Documentación del análisis de sensibilidad (Anexo C) que justifique la ventana de 500 días frente a alternativas. (4) Evidencia de UAT ejecutado con datos reales o sintéticos representativos, con sign-off de QA. (5) Acta de comité (Riesgos o equivalente) donde se revisen y aprueben los resultados de backtesting, y se documenten acciones si hay incumplimiento. Sin estos documentos, el modelo está en estado de DESARROLLO INCOMPLETO, no PRODUCCIÓN VALIDADA. Coordina con primera línea (desarrollo/riesgos) para completar la evidencia antes de resubmitir.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `f9a94b8d0d05`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [4/5] Revisión de código: calcula_var.py

*Control: Revisión de código vs documentación*

**Qué evalúa.** Calcula el Value at Risk histórico usando percentil sobre una ventana de 500 días y nivel de confianza del 99%. Implementa directamente la metodología descrita en el manual.

**Hallazgo.**

Se identificaron 2 discrepancia(s) entre este módulo y la documentación. El detalle de cada una —fragmento de código, motivo y referencia documental— se presenta a continuación.

**Evidencia citada.**

> var_historico

**Recomendación.** Documentar o corregir los elementos señalados.

<sub>prompt `['fc583755e9`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Uso e integración a la gestión  ·  score 2.0

#### 🟠 [2/5] Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo

*Control: Revisión de los usos, impactos y usuarios del modelo*

**Qué evalúa.** Verificación de que los usos del modelo VaR en producción se encuentren dentro del alcance original, que exista identificación formal de usuarios y reportes de integración a la gestión de riesgos. Esta actividad es crítica: un modelo técnicamente correcto pero desalineado con sus usuarios u objetivos expone a la institución a riesgos de gobernanza y cumplimiento regulatorio.

**Hallazgo.**

La evidencia disponible demuestra USO del modelo en comité, pero presenta brechas CRÍTICAS en la formalización y trazabilidad de ese uso. acta_comite_riesgos_2026Q1.md confirma que 'El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente', lo que establece un uso real. Sin embargo, esta mención es INCIDENTAL y ÚNICA — no existe: (1) un documento formal que defina el alcance original del modelo y contraste contra usos actuales, (2) lista de usuarios identificados explícitamente con sus funciones, (3) calendario o procedimiento de reporting formalizado (se menciona 'mensualmente' sin especificar qué comité, qué formato, quién produce el informe, qué decisiones se toman con él), (4) evidencia de que el modelo fue validado ANTES de entrar en uso (la actividad requiere verificar que 'el modelo no estaba en uso antes de concluir la validación', y no hay acta de cierre de validación ni fecha de implementación producción). El manual metodológico (referenciado en calcula_var.py como §2) no está en el contexto, por lo que no puede contrastarse si los usos cumplen con el alcance documentado. Esta es una INTEGRACIÓN A CIEGAS: el modelo se usa para algo que parece importante (límite operativo diario), pero sin trazabilidad formal de que ese uso haya sido autorizado tras validación, ni de quién lo ejecuta, ni con qué cadencia se revisa su adecuación. Para subir a nivel 3 se requiere: (a) documento de alcance original y matriz de usos actuales con justificación de desviaciones si las hay, (b) lista de usuarios por rol, (c) especificación del reporte mensual (contenido, destinatarios, decisiones que toma), (d) evidencia de validación previa a implementación. La cobertura documental es explícitamente parcial (se procesó 100% pero «mediante resumen por segmentos» los extensos), lo que genera incertidumbre sobre si existe documentación de gobernanza que no llegó al contexto.

**Evidencia citada.**

> acta_comite_riesgos_2026Q1.md → "Se revisan los límites de VaR de la cartera de negociación. El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente."
>
> calcula_var.py → """VaR histórico. Ventana de 500 días según manual metodológico §2.""" [indica referencia a manual que no está disponible en el contexto]

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «[indica referencia a manual que no está disponible en el contexto]»
> - «El marco supervisor establece una clasificación por número de excedencias observ»

**Preguntas al modelador.**

- [ ] ¿Existe un documento formal (acta de autorización, matriz RACI, o especificación de requisitos) que defina el alcance original del modelo VaR FRTB y contraste contra los usos actuales identificados en comité?
- [ ] ¿Quiénes son los usuarios formales del modelo (por nombre de rol y unidad) y cuál es su responsabilidad específica en la producción, distribución y uso del reporte mensual de consumo de límites?
- [ ] ¿Cuál es la especificación completa del reporte mensual de consumo de VaR: qué métricas contiene, a qué comité se presenta, quién es responsable de su generación, cuáles son los umbrales de escalonamiento si se aproximan o superan límites?
- [ ] ¿Existe evidencia de que el modelo fue validado y aprobado ANTES de su puesta en operación para el cálculo de límites diarios? (Acta de cierre de validación, fecha de implementación, autorización de primera línea).
- [ ] ¿Por qué se utiliza una ventana de 500 días en el código (calcula_var.py) frente al estándar de 250 días mencionado en el marco FRTB para backtesting? ¿Se aplica la ventana de 500 días solo al cálculo histórico o también a la evaluación de backtesting supervisorio?
- [ ] ¿Existe un procedimiento de revisión periódica de la idoneidad del modelo para su uso como límite operativo diario? Si existe, ¿con qué frecuencia se ejecuta y cuáles fueron los resultados en los últimos dos períodos?

**Recomendación.** Producir inmediatamente: (1) Documento de Alcance y Usos formalizado que especifique el propósito original del modelo, los usos autorizados actuales y justificación de desviaciones si las hay; (2) RACI de usuarios por rol con responsabilidades explícitas en la cadena de producción y decisión del modelo; (3) Especificación técnica y operativa del reporte mensual de consumo de límites, incluyendo umbrales de alerta y escalado; (4) Prueba de validación previa a implementación (acta de cierre de validación, fecha de go-live). (5) Justificación documentada de la elección de ventana de 500 días frente al estándar regulatorio de 250 días, con explicación de si esta diferencia aplica al backtesting de supervisión o solo al cálculo interno. Estos documentos son requisitos de gobernanza mínimos antes de que el modelo pueda considerarse en control operacional.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `46a24dd26c4d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Validar que el modelo no se enceuntre en uso antes o durante la validación

*Control: Revisión de los usos, impactos y usuarios del modelo*

**Qué evalúa.** Validar que el modelo VaR FRTB no se encuentre en uso operativo antes o durante la validación, e identificar formalmente usuarios, usos, outputs en producción y reportes de integración a comités. Este control es crítico porque el uso operativo durante la validación invalida la independencia del proceso y expone a la entidad a riesgo regulatorio.

**Hallazgo.**

La evidencia demuestra que el modelo VaR SE ENCUENTRA EN USO OPERATIVO ACTIVO durante la validación, pero la documentación disponible presenta brechas CRÍTICAS en la formalización de usuarios y en el control de la activación. (1) El acta del Comité de Riesgos del 2026-04-10 confirma explícitamente que 'El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente', lo que coloca el modelo EN PRODUCCIÓN. (2) Sin embargo, NO HAY EVIDENCIA de un registro formal de usuarios, de autorización de puesta en marcha, de verificación de que los outputs en código coincidan con los documentados, o de un cierre de validación previo a esta activación. (3) El script `calcula_var.py` existe y está siendo ejecutado (implícito en el reporte al comité), pero no hay trazabilidad de cuándo se activó ni documentación de que se haya verificado la consistencia entre el manual metodológico y la implementación en código. (4) La aparición de un PARÁMETRO CRITICO discrepante (ventana de 500 días en código vs. manual que menciona 250 días según la referencia del docstring) durante una validación activa sugiere que el control de cambios y la supervisión del uso NO estuvieron integrados. Esto incumple el principio de segunda línea independiente: no se puede validar un modelo que simultáneamente está siendo usado operativamente sin que haya un corte claro. Para subir a puntaje 3, se requiere: (a) cierre documentado de cuándo y quién autorizó la entrada en producción, (b) registro formal de todos los usuarios finales y sus casos de uso, (c) una prueba explícita de que los outputs en producción coinciden con los de desarrollo (reporte de reconciliación P&L teórico vs. observado), (d) acta de decisión de comité sobre la aceptabilidad del uso durante la validación o cierre de validación previo a la activación.

**Evidencia citada.**

acta_comite_riesgos_2026Q1.md → "El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

No se encontró en el contexto disponible: registro de usuarios formales, acta de autorización de entrada en producción, reportes de reconciliación de outputs, documentación de cierre de validación previo, o matriz de casos de uso asignados a cada usuario.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «No hay documento de manual disponible que aclare si §2 especifica 500 o 250 días»
> - «La actividad exige que el modelo NO esté en uso durante la validación, pero el a»

**Preguntas al modelador.**

- [ ] ¿Cuál es la fecha de inicio y de cierre de esta validación? ¿Es anterior, paralela o posterior al acta del Comité de Riesgos del 2026-04-10?
- [ ] ¿Existe un documento de «Autorización de Entrada en Producción» o acta de comité que autorice el uso operativo del modelo VaR? ¿En qué fecha se tomó esa decisión?
- [ ] ¿Quiénes son los usuarios finales del modelo (mesas, tesorería, riesgos, comités de límites)? Proporcionar matriz de usuarios-casos-de-uso.
- [ ] ¿El manual metodológico §2 especifica una ventana de 250 o de 500 días? Proporcionar copia de esa sección para verificar consistencia con `calcula_var.py`.
- [ ] ¿Existe un reporte de reconciliación que compare los outputs del VaR en producción contra los calculados en el ambiente de desarrollo o validación en la misma fecha? (Esto verificaría que no hubo cambios de código no documentados entre desarrollo y producción.)
- [ ] ¿Se ejecutó backtesting sobre los P&L observados en los meses en que el modelo estuvo operativo? Si es así, ¿cuál fue el resultado (número de excedencias, test de Kupiec, test de independencia)?
- [ ] ¿Está documentada la decisión de continuar usando el modelo durante la validación, o se decidió detener su uso hasta que la validación concluyera? ¿En dónde consta esa decisión?

**Recomendación.** ACCIÓN INMEDIATA: (1) Obtener y revisar la cronología exacta: fecha de cierre de esta validación vs. fecha del acta de activación del modelo en comité. Si la validación concluyó DESPUÉS de la activación, es incumplimiento de SR 11-7 (modelo debe ser validado ANTES de su uso operativo). (2) Requerir documento de «Autorización de Entrada en Producción» con firma de riesgos e indicación de que se cerraron todas las observaciones críticas de validación (o justificación explícita de por qué se autorizó con observaciones pendientes). (3) Obtener el manual metodológico §2 y verificar que el parámetro de ventana en código sea EXACTAMENTE el documentado; si no coincide, clasificar como hallazgo de control de cambios fallido y exigir rectificación. (4) Generar una matriz formal de Usuarios-Casos-de-Uso-Autorización y hacerla firmar por el propietario de cada caso. (5) Ejecutar un backtesting sobre los datos históricos del período de uso operativo y reportar el número de excedencias y tests estadísticos (mínimo Kupiec + test de independencia); si hay excedencias no esperadas, investigar si el modelo requiere ajuste. (6) Pautar revisión mensual de outputs en producción vs. desarrollo para detectar divergencias futuras.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `e1420da125d4`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Identificar los usuario del modelo

*Control: Revisión de los usos, impactos y usuarios del modelo*

**Qué evalúa.** Identificación formal de usuarios del modelo VaR y verificación de que los outputs en producción son consistentes con desarrollo, además de comprobar integración del modelo a la gestión a través de reportes a comités. Esta actividad es crítica para asegurar que el modelo se usa conforme a su alcance autorizado y que sus resultados impactan efectivamente las decisiones de riesgo.

**Hallazgo.**

La evidencia disponible demuestra MENCIÓN de uso pero presenta brechas CRÍTICAS en la formalización, trazabilidad y consistencia del modelo. El acta del Comité de Riesgos (2026-04-10) confirma que 'El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente', lo que acredita un usuario (Comité de Riesgos) y un uso (límite operativo diario, reporte mensual). Sin embargo, falta evidencia de: (1) identificación FORMAL y documentada de todos los usuarios; (2) especificación de los datos y frecuencia de actualización que reciben; (3) reportes reales ejecutados (solo se menciona que 'se reporta', sin anexar reportes); (4) validación de que los outputs generados en producción coinciden con los de desarrollo. Además, existe una CONTRADICCIÓN CRÍTICA en los parámetros del modelo: el manual metodológico (citado en calcula_var.py como 'ventana de 500 días según manual metodológico §2') no está disponible en el contexto para verificar que efectivamente lo dice, pero el código implementa 500 días. Sin acceso al manual §2, no se puede asegurar que el modelo en producción (500 días) es el modelo validado. Para alcanzar puntaje 3 se requiere: (a) documento que liste usuarios, sus perfiles y usos específicos; (b) al menos un reporte mensual real presentado al comité; (c) evidencia de que el código en producción fue el código validado (hash, versión, o auditoría de despliegue); (d) acceso al manual §2 para validar la ventana de 500 días. La integración a la gestión existe en intención pero no está demostrada en ejecución.

**Evidencia citada.**

> acta_comite_riesgos_2026Q1.md → "El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente."
>
> calcula_var.py → """VaR histórico. Ventana de 500 días según manual metodológico §2."""
>
> No se encontró evidencia de: documento de usuarios formalmente identificados, reportes reales ejecutados, verificación de consistencia entre desarrollo y producción, o acceso al manual metodológico §2 citado en el código.

**Preguntas al modelador.**

- [ ] ¿Dónde está el manual metodológico §2 que describe la ventana de 500 días? ¿Esa ventana fue explícitamente autorizada en la validación original, o es una desviación?
- [ ] ¿Cuáles son TODOS los usuarios del modelo VaR FRTB identificados formalmente (traders, riesgos, compliance, CFO, otros)? ¿Existe un documento que liste roles y usos específicos?
- [ ] ¿Existen reportes reales de consumo de VaR presentados al Comité de Riesgos en 2026? ¿Cuál es la fecha, los datos incluidos, y quién los firmar o validó?
- [ ] ¿El código en producción (calcula_var.py) es exactamente el código que fue validado y aprobado? ¿Hay auditoría de despliegue, versioning o hash criptográfico que lo demuestre?
- [ ] ¿Se ejecuta backtesting de los reportes entregados al comité? ¿Se comparan las previsiones de VaR contra lo realizado (P&L hipotético)? ¿Dónde están los resultados?
- [ ] ¿Se ha verificado que los outputs que el comité recibe en los reportes mensuales proceden exactamente del código validado, o podría haber postprocesamiento, ajustes manuales o versiones alternativas?

**Recomendación.** 1. Adjuntar documento formal de 'Usuarios y Casos de Uso del VaR FRTB' con identificación de rol, frecuencia de consumo y decisiones que toma cada usuario basándose en el modelo. 2. Proporcionar mínimo 3 reportes mensuales reales completos (con datos, cálculos, presentación ante comité y actas de aprobación). 3. Recuperar el manual metodológico §2 y validar que la ventana de 500 días coincide con lo documentado; si hay desviación, justificarla y autorizar formalmente. 4. Ejecutar trazabilidad de despliegue: versión del código, fecha de pase a producción, y confirmación de que coincide con el código sometido a validación. 5. Proporcionar rastros de backtesting ejecutado sobre los reportes mensuales (cobertura vs. excedencias, prueba de Kupiec). Sin esto, no puede asegurarse que el modelo integrado a la gestión es el modelo validado.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `c0f586ab34c9`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Adecuada integración a la gestión del modelo

*Control: Revisión de la integración a la gestión del modelo*

**Qué evalúa.** Verificación de la integración operativa del modelo VaR a la gestión: se evalúa si los outputs producidos en el entorno de producción son consistentes con los de desarrollo, si están siendo utilizados efectivamente en decisiones de riesgo, y si existe seguimiento sistemático de su desempeño.

**Hallazgo.**

La evidencia disponible demuestra USO OPERATIVO del modelo VaR, pero presenta BRECHAS CRÍTICAS en la formalización y trazabilidad de esa integración. El acta del comité [acta_comite_riesgos_2026Q1.md] confirma que «El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente», lo que evidencia que el modelo está integrado a la gestión. Sin embargo, existen contradicciones CRÍTICAS entre la documentación y la implementación que invalidan la confiabilidad operativa de esa integración. El código fuente [calcula_var.py] implementa una ventana de 500 días, pero NO existe en el contexto disponible referencia alguna a qué especifica el manual metodológico sobre la longitud de la ventana para VaR histórico; esto genera una brecha de verificabilidad sobre si la implementación operativa respeta la documentación. Además, aunque se reporta al Comité mensualmente, NO hay evidencia de que ese comité reciba información de backtesting, validación de supuestos, o análisis de excedencias observadas (contraste de Kupiec, prueba de independencia de Christoffersen), que son requisitos estándar para juzgar si el modelo merece seguir siendo usado operativamente. La falta de backtesting documentado y reportado es especialmente crítica: un modelo de VaR que limita operaciones diarias sin evidencia de que sus estimaciones sean estadísticamente correctas constituye un riesgo de capital no cubierto. Para alcanzar el nivel 3, se requeriría: (1) verificación explícita de que calcula_var.py implementa exactamente lo que el manual §2 especifica; (2) evidencia de que al menos un backtesting (Kupiec sobre P&L hipotético) se ejecuta periódicamente; (3) reporte de esos resultados al Comité; (4) documentación de cómo se interpretan y actúan sobre las excedencias observadas.

**Evidencia citada.**

> acta_comite_riesgos_2026Q1.md → "El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente."
>
> calcula_var.py → "def var_historico(retornos, confianza=0.99):\n    \"\"\"VaR histórico. Ventana de 500 días según manual metodológico §2.\"\"\"\n    return -np.percentile(retornos[-500:], (1 - confianza) * 100)"

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «def var_historico(retornos, confianza=0.99):\n \»
> - «VaR histórico. Ventana de 500 días según manual metodológico §2.\»
> - «\n return -np.percentile(retornos[-500:], (1 - confianza) * 100)»
> - «No se encontró el manual metodológico §2 en el contexto disponible para verifica»
> - «No se encontró evidencia de backtesting, contraste estadístico (Kupiec/Christoff»

**Preguntas al modelador.**

- [ ] ¿Existe el manual metodológico §2 que califica a la ventana de 500 días? ¿Qué especifica exactamente sobre la longitud de la ventana para VaR histórico y con qué justificación se eligió 500 vs alternativas (250, 750, 1000 días)?
- [ ] ¿Se ejecuta backtesting sobre el modelo VaR operativo? Si existe, ¿con qué frecuencia, sobre qué P&L (hipotético o real), y qué criterios estadísticos se aplican (Kupiec, Christoffersen, López)?
- [ ] ¿Qué reportes sobre validación del modelo (excedencias, cobertura empírica, tasa de fallo) se presentan al Comité de Riesgos, y con qué frecuencia?
- [ ] ¿Existe una comparación entre outputs de VaR en desarrollo vs producción? ¿Se realiza alguna verificación de que los datos de entrada, transformaciones y salidas sean idénticos entre ambos entornos?
- [ ] ¿Se identifican formalmente los usuarios del modelo (áreas operativas, riesgos, tesorería) y sus casos de uso específicos? ¿Existe documentación que especifique qué decisiones se toman basadas en este VaR?
- [ ] ¿Existe un protocolo documentado para actuar cuando se observan excedencias del VaR? ¿Se investiga cada excedencia, se documentan las causas y se escalan las anomalías?
- [ ] ¿El nivel de confianza del 99% utilizado en el código está justificado por regulación aplicable (FRTB, Basilea III), o es una elección sin documentación de su racionalidad?

**Recomendación.** Acción 1 (crítica): Proporcionar y validar el manual metodológico §2 para confirmar que calcula_var.py implementa exactamente la ventana especificada. Si existe discrepancia, corregir el código o actualizar la documentación y ejecutar backtesting de validación sobre el histórico con ambos parámetros. Acción 2 (crítica): Instituir backtesting mensual o trimestral con contraste de Kupiec (y en lo posible Christoffersen) sobre P&L hipotético, con reporte de excedencias, tasa de cobertura empírica, y análisis de causas raíz de cada excedencia. Incorporar estos reportes a la agenda del Comité de Riesgos. Acción 3 (importante): Documentar formalmente los usuarios del modelo, los casos de uso operativos específicos, y el protocolo de escalación cuando el VaR se aproxima o supera los límites. Acción 4 (importante): Ejecutar una reconciliación completa entre VaR en desarrollo y producción (datos de entrada, versión del código, outputs) para garantizar que la métrica operativa corresponde exactamente al modelo validado.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `ffcb89d00616`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar existencias y suficinecia del reporting

*Control: Revisión de la integración a la gestión del modelo*

**Qué evalúa.** Verificación de la integración del modelo VaR a la gestión: identificación de usuarios, consistencia de outputs entre desarrollo y producción, y existencia de reporting de seguimiento a órganos de gobierno. Esta actividad es crítica para asegurar que el modelo validado se ejecuta conforme se documentó y que sus resultados informan efectivamente las decisiones de riesgo.

**Hallazgo.**

La evidencia disponible demuestra USO OPERATIVO del modelo VaR en la gestión (reportado al Comité de Riesgos mensualmente como límite operativo diario), pero presenta BRECHAS CRÍTICAS en su formalización e integración verificable. Primero, sobre usuarios: acta_comite_riesgos_2026Q1.md menciona que «El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente», pero NO identifica formalmente quiénes lo usan, cuáles son sus responsabilidades, ni cómo reciben los outputs. Segundo, sobre consistencia producción-desarrollo: calcula_var.py implementa una ventana de 500 días («Ventana de 500 días según manual metodológico §2»), pero el documento fuente (manual metodológico §2) no está en el contexto disponible para verificar que esta implementación coincide con lo documentado. Sin acceso al manual referenciado, no puede confirmarse que el código en producción está alineado con la metodología aprobada. Tercero, sobre reporting: el acta del Comité afirma consumo mensual de límites, pero no hay evidencia de los reportes concretos, formatos, frecuencia de actualización, o qué se hace cuando se excede un límite. No se proporciona: (a) un template o ejemplo del reporte presentado; (b) actas posteriores que confirmen seguimiento continuado; (c) un registro de quién genera, valida y distribuye los outputs. El cumplimiento parcial se debe a que el uso está confirmado pero la cadena de responsabilidad, la trazabilidad de outputs y la evidencia documental de integración operativa están ausentes o incompletas. Para avanzar al puntaje 3 se requiere: (i) formalización explícita de usuarios y sus funciones; (ii) muestra de los reportes reales entregados a comité (al menos 2-3 períodos); (iii) verificación directa de que calcula_var.py implementa exactamente lo documentado en el manual §2 (para esto es imprescindible el manual completo); (iv) evidencia de qué controles se aplican cuando VaR se aproxima o excede límites.

**Evidencia citada.**

> acta_comite_riesgos_2026Q1.md → "El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente."
>
> calcula_var.py → """def var_historico(retornos, confianza=0.99):
>     return -np.percentile(retornos[-500:], (1 - confianza) * 100)
> """
>
> calcula_var.py → """Ventana de 500 días según manual metodológico §2."""

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «def var_historico(retornos, confianza=0.99): return -np.percentile(retornos[-500»

**Preguntas al modelador.**

- [ ] ¿Existe el manual metodológico §2 referenciado en calcula_var.py? ¿Qué especifica exactamente sobre la ventana temporal para el cálculo del VaR histórico?
- [ ] ¿Quiénes son los usuarios formalmente designados del modelo VaR (tesorería, mesa de negociación, riesgo, etc.)? ¿Existen fichas de usuario o un registro de responsabilidades?
- [ ] ¿Qué formato tiene el reporte mensual de VaR al Comité de Riesgos? ¿Se proporciona una muestra de dos reportes consecutivos (p.ej., Q1 2026 y Q2 2026) que demuestre continuidad y trazabilidad?
- [ ] ¿Cómo se garantiza que los outputs de calcula_var.py en producción son idénticos a los generados en el ambiente de desarrollo? ¿Existe un control de versión o un log de ejecución con timestamps?
- [ ] ¿Qué acciones se tomaron en los períodos donde el consumo de VaR se aproximó o excedió límites? ¿Existe un registro de excepciones y sus resoluciones?
- [ ] ¿El backtesting del VaR (contraste de excedencias vs predicciones) se ha ejecutado y reportado al Comité? Si existe, ¿cuáles son los resultados y su periodicidad de revisión?

**Recomendación.** 1. Proporcionar el manual metodológico completo (§2 mínimamente) para verificar alineación código-documentación. 2. Formalizar un registro de usuarios del modelo con sus responsabilidades y frecuencia de acceso a los outputs. 3. Recopilar y presentar una muestra de dos ciclos de reportes mensuales entregados al Comité (con fechas, firmantes y consumos de límite), acompañados de actas de comité que confirmen la revisión. 4. Implementar un log de ejecución en producción (timestamp, parámetros utilizados, versión de código, hash de validación) que permita auditar cada cálculo. 5. Documentar y evidenciar el protocolo de escalada cuando VaR se acerca o supera límites, con al menos un caso concreto de aplicación en los últimos 12 meses.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `d0dd32cfd228`</sub>

> ✍️ _Conclusión del validador:_
>
---

## 6. Limitaciones del alcance

**Esta sección es obligatoria en el informe final.** Un dictamen que no
declara qué quedó fuera no permite distinguir «esto está bien» de «esto
no se miró».

| Concepto | Valor |
|---|---:|
| Actividades evaluadas correctamente | 34 |
| Actividades sin evidencia | 0 |
| Actividades con fallo técnico | 0 |

**48 cita(s) sin verificar literalmente.** Marcadas en
el detalle. Revísalas antes de firmar.

> ✍️ **Te toca:** traslada esta sección al informe final tal cual.
> Es lo que un supervisor busca primero.

---

<sub>Generado por VIRF 27.1 · claude-haiku-4-5-20251001 el 2026-08-03 16:27. Documento de trabajo interno; el entregable es el informe Word. El agente no firma: firma el validador.</sub>
