# Revisión de código contra documentación — VaR Mercado FRTB

Generado por `modulos/revision_codigo.py` el 2026-08-03 16:27.

## Resumen

- Módulos revisados: **1/1**
- Llamadas al modelo: 1
- Hallazgos: **2**
- Anclados en la documentación: **0** (sin anclar: 0)
- Revisión confiable: **True**

### Por severidad

- 🔴 critica: 0
- 🟠 alta: 0
- 🟡 media: 1
- ⚪ baja: 1

### Por categoría

- `no_documentado` (Existe en el código y el manual no lo declara): 0
- `documentado_ausente` (El manual lo declara y no existe en el código): 0
- `code_drift` (Existe en ambos pero no coinciden (fórmula, parámetro, umbral)): 0
- `supuesto_tacito` (El código asume algo que el manual no declara ni justifica): 2
- `riesgo_tecnico` (Defecto que afecta al resultado del modelo): 0

## Hallazgos

### 🟡 `calcula_var.py:4` — var_historico

**Categoría:** `supuesto_tacito` · **Severidad:** media

El código aplica un negativo al percentil (-np.percentile(...)) para convertir pérdidas en valores positivos. Esta convención de signo no está explícitamente documentada en el manual metodológico.

```python
return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

### ⚪ `calcula_var.py:2` — var_historico

**Categoría:** `supuesto_tacito` · **Severidad:** baja

La función acepta un parámetro `confianza` con valor por defecto 0.99, permitiendo que sea sobrescrito en tiempo de ejecución. El manual especifica 99% como requisito fijo, pero no documenta si este parámetro debe ser flexible o constante.

```python
def var_historico(retornos, confianza=0.99):
```

> Documentación: nivel de confianza 99%

## Inventario de módulos

| Módulo | Chars | Hallazgos | Revisión |
|---|---:|---:|---|
| `calcula_var.py` | 205 | 2 | ✅ |
