# Informe de validación — VaR Drift

> **BORRADOR DE TRABAJO.** Este documento lo genera el agente VIRF para
> que el validador humano lo revise, corrija y redacte el informe final.
> **No es el entregable** y no sustituye el criterio de quien firma.

| | |
|---|---|
| Modelo | VaR Drift |
| Tier | 1 |
| Fecha | 2026-09-02 |
| Agente | 27.1 · claude-haiku-4-5-20251001 |
| Score global | **1.62** — DEFICIENTE |
| Posición en cadena de custodia | 1 |
| Hash del informe | `e4a6f5561c5bf03ef87b63465bd94a2a` |

## 0-bis. Políticas del procedimiento aplicadas

El agente ha detectado condiciones que `PROCEDIMIENTO_VALIDACION.md`
trata como automáticas. **La decisión formal la firma el validador**
(§1 del procedimiento); esto solo declara lo que no puede pasarse por
alto.

### §6 — Hallazgos críticos automáticos

Ámbitos con score ≤ 2, marcados como críticos sin depender del juicio:

- **Calidad de datos** — score 1.0
- **Documentación** — score 2.0
- **Gobierno** — score 1.5
- **Implementación** — score 1.75
- **Metodología** — score 2.0
- **Uso e integración a la gestión** — score 1.0

Un hallazgo crítico se eleva al Comité de Riesgos en su siguiente
sesión, con copia inmediata al dueño del modelo (§6).

### §4.2 — Ámbito por debajo del umbral bloqueante

Ámbitos con score < 2.5. La política **impide la aprobación aunque el
score global la supere**:

- **Calidad de datos** — score 1.0
- **Documentación** — score 2.0
- **Gobierno** — score 1.5
- **Implementación** — score 1.75
- **Metodología** — score 2.0
- **Uso e integración a la gestión** — score 1.0

## 0. Cómo leer este documento

**El score no es la conclusión.** Es un resumen con pérdida de información,
útil para priorizar por dónde empezar e inútil para concluir nada. Lo que
sostiene un dictamen son las citas y el razonamiento, no el número.

### La escala, y qué exige cada nivel

| | Significa | Para darlo hace falta |
|---|---|---|
| **1** | No cumple | Ausencia total de evidencia sobre el tema |
| **2** | Brechas críticas | Se menciona, pero no se ejecuta o falta lo esencial |
| **3** | Brechas no críticas | Implementado **y ejecutado**, con huecos menores |
| **4** | Observaciones menores | Además, la elección está **justificada** |
| **5** | Cumple plenamente | Además, supuestos verificados y límites declarados |

El eje no es «cuánto se habla del tema», es **cuánto está demostrado**. El 5
es poco frecuente por diseño: exige poder defenderlo ante un supervisor con
las citas en la mano.

### Las cinco trampas que el agente busca

Cosas que aparentan cumplimiento y no lo son. Si vas a discutir un puntaje,
empieza por comprobar cuál de estas aplica:

| Trampa | Ejemplo |
|---|---|
| Documentado ≠ correcto | Manual impecable que describe una decisión equivocada |
| Existe ≠ se ejecuta | Script de backtesting que nadie corrió |
| Se menciona ≠ se justifica | «Se aplica la metodología X» sin decir por qué X |
| Se cita ≠ lo sostiene | Un paper que no dice lo que el manual afirma |
| Se calcula ≠ se usa | Métrica que no llega a ningún comité |

### Dos cosas que NO son lo mismo

- **Ausencia de evidencia** — el agente no lo encontró en lo que pudo leer.
  Es una limitación del alcance, y se declara como tal.
- **Incumplimiento** — la evidencia está y muestra una deficiencia.

Confundirlas es el error más caro al redactar: acusa al modelador de algo
que quizá sí documentó, solo que en una página que no cupo en el contexto.
Revisa siempre la **cobertura documental** antes de convertir un puntaje
bajo en un hallazgo.

### Qué te toca a ti

Los bloques **✍️** marcan dónde el documento espera tu criterio. El agente
propone; el validador dispone y firma. Ninguna cifra de aquí es definitiva
hasta que la revisas.

## 1. Resumen por ámbito

Ordenados **de peor a mejor**: por ahí se empieza.

| Ámbito | Score | Peso | Aporta al global | Lectura |
|---|---:|---:|---:|---|
| Calidad de datos | 1.0 | 20% | 0.20 | 🔴 No cumple |
| Uso e integración a la gestión | 1.0 | 8% | 0.08 | 🔴 No cumple |
| Gobierno | 1.5 | 12% | 0.18 | 🟠 Cumple parcialmente — observaciones críticas |
| Implementación | 1.75 | 15% | 0.26 | 🟠 Cumple parcialmente — observaciones críticas |
| Documentación | 2.0 | 15% | 0.30 | 🟠 Cumple parcialmente — observaciones críticas |
| Metodología | 2.0 | 30% | 0.60 | 🟠 Cumple parcialmente — observaciones críticas |

> ✍️ **Te toca:** el ámbito con peor score no siempre es el más urgente —
> mira la columna «aporta al global». Un 2 en Metodología (peso 30 %) pesa
> casi cuatro veces más que un 2 en Uso e integración (8 %).

## 2. Inconsistencias entre fuentes

**37 contradicción(es)** entre lo documentado y lo implementado.
Cada una trae las dos citas enfrentadas para que puedas verificarla en el
documento original.

### 2.1 [ALTA] El manual describe QUÉ CALCULA (VaR) pero no PARA QUÉ se usa ni QUIÉN lo usa. La mención del Comité de Riesgos como autoridad de cambios implica un usuario y un proceso de gobernanza, pero no están formalizados en una sección de 'Objetivo' o 'Usuarios'. Esto genera ambigüedad sobre si el modelo es para límites de negociación, reporte regulatorio, IFRS 9, o múltiples usos simultáneamente. Sin claridad en el objetivo, no es posible validar si el nivel de confianza (99%), la ventana (250 días) y el horizonte (1 día) son apropiados para cada uso.

*Ámbito: Documentación · Actividad: Verifica la inclusión del objetivo, usos y usuarios del modelo*

**manual_VaR_drift.md** dice:
> El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el método de simulación histórica.

**manual_VaR_drift.md** dice:
> Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.2 [ALTA] El informe de seguimiento concluye que el modelo 'se comporta conforme' basándose únicamente en el test de Kupiec (cobertura incondicional). Sin embargo, el manual declara explícitamente una limitación crítica: la incapacidad de capturar eventos sin precedente. El backtesting no verifica esta limitación (no incluye análisis de cambios de régimen, eventos de cola, o validación de la hipótesis de que la distribución empírica es estable). Esto es una brecha entre lo que el manual reconoce como riesgo y lo que el seguimiento valida. Un modelo que falla en capturar eventos extremos puede pasar Kupiec (que solo mide frecuencia de excepciones) pero ser inadecuado para decisiones de capital o límites en mercados volátiles.

*Ámbito: Documentación · Actividad: Verifica la inclusión del objetivo, usos y usuarios del modelo*

**backtesting_2026Q1.md** dice:
> El modelo se comporta conforme a lo especificado. No se requiere recalibración en este trimestre.

**manual_VaR_drift.md** dice:
> La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.3 [ALTA] El informe de backtesting afirma que usó la ventana del manual, pero sin versión de referencia no se puede verificar si ambos documentos hablan de la misma especificación en el mismo momento. Si el manual fue modificado entre la ejecución del backtesting y la fecha del informe, o viceversa, la trazabilidad se pierde. Esto impide auditar la integridad del contraste.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_drift.md** dice:
> ## 2. Especificación del cálculo\nEl VaR se estima sobre una **ventana de 250 días hábiles**

**backtesting_2026Q1.md** dice:
> sobre la ventana de 250 días establecida en el manual metodológico

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.4 [ALTA] El manual especifica 250 días como ventana de estimación, pero el informe de backtesting no cita explícitamente que la función `backtesting_kupiec()` ejecutada usó exactamente esa ventana. No hay trazabilidad de parámetros entre la especificación y la ejecución. Riesgo: si el código usa 500 días (como se menciona en las instrucciones de validación como ejemplo de contradicción), el backtesting no valida el modelo documentado.

*Ámbito: Documentación · Actividad: Verifica la existencia , suficiencia y claridad de la documentación*

**manual_VaR_drift.md** dice:
> El VaR se estima sobre una ventana de 250 días hábiles

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.5 [ALTA] El manual especifica una ventana de 250 días para la estimación del VaR, pero el informe de backtesting reporta resultados sobre solo 62 días de negociación. No está claro si: (1) la ventana de 250 días se usa para estimar el VaR que luego se contrasta contra 62 días de P&L realizadas (lo cual sería correcto), o (2) se está usando una ventana de 62 días en la ejecución, contraviniendo la especificación. Sin acceso al código y a los logs de ejecución, no se puede verificar cuál es el caso. Esto es crítico porque invalida la comparabilidad del backtesting con el intervalo de Kupiec documentado.

*Ámbito: Documentación · Actividad: Verificar la coherencia del manual de implementación con el manual métodolocios*

**manual_VaR_drift.md** dice:
> El VaR se estima sobre una ventana de 250 días hábiles

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.6 [ALTA] No hay contradicción explícita entre los documentos, pero TAMPOCO hay evidencia de que el código implementado realmente use 250 días. El informe de backtesting afirma que se usó esa ventana, pero no proporciona logs, parámetros de ejecución, ni acceso al código que lo demuestre. Sin acceso a `calcula_var.py` o `backtesting_kupiec()` no se puede verificar si la implementación coincide con la especificación.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**manual_VaR_drift.md** dice:
> El VaR se estima sobre una ventana de 250 días hábiles

**backtesting_2026Q1.md** dice:
> sobre la ventana de 250 días establecida en el manual metodológico

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.7 [ALTA] Ambos documentos son FIXTURES SINTÉTICOS, no documentación de un modelo en producción. Esto invalida la validación de suficiencia y claridad de la documentación operativa real, porque no existe documentación operativa real en el contexto. La evaluación se realiza sobre documentación de prueba, no sobre el modelo que se supone está en uso.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**manual_VaR_drift.md** dice:
> Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad.

**backtesting_2026Q1.md** dice:
> Documento fabricado para probar el juez de código.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.8 [ALTA] Ambos documentos se declaran como fixtures sintéticos sin valor de producción. Esto invalida cualquier conclusión sobre cumplimiento regulatorio real: no hay evidencia de que exista un modelo VaR operativo con control de versiones, seguimiento real o backtesting ejecutado sobre datos reales de la entidad. El contexto disponible no contiene documentación de producción.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_drift.md** dice:
> "Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad."

**backtesting_2026Q1.md** dice:
> "Documento fabricado para probar el juez de código. Ver LEEME.md."

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.9 [ALTA] El informe afirma que los resultados son "compatibles" con Kupiec, pero no proporciona el p-valor ni el intervalo de confianza que el manual dice que la función devuelve. Sin estos números, la afirmación de compatibilidad no es verificable. El riesgo es que se reporte cumplimiento sin evidencia numérica: 4 excepciones en 62 días (6.45%) podría estar dentro o fuera del intervalo esperado (típicamente 0-4 excepciones para 250 observaciones al 99%), pero sin el p-valor no se puede validar.

*Ámbito: Documentación · Actividad: Verificar la existencia, suficiencia y claridad de la documentación*

**backtesting_2026Q1.md** dice:
> Se observaron **4 excepciones** en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.10 [ALTA] El informe afirma que se usaron "los mismos retornos logarítmicos empleados en la estimación", pero no proporciona evidencia de que se verificó esta identidad. No hay logs, hashes de datos, o trazabilidad que demuestre que los retornos del backtesting son idénticos a los de la estimación. El riesgo es que se haya usado una ventana diferente, datos de una fecha distinta, o una transformación ligeramente diferente, invalidando la comparabilidad sin que se detecte.

*Ámbito: Documentación · Actividad: Verificar la existencia, suficiencia y claridad de la documentación*

**backtesting_2026Q1.md** dice:
> El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación.

**manual_VaR_drift.md** dice:
> Los rendimientos de los factores de riesgo se calculan como **retornos logarítmicos**, por su propiedad de aditividad temporal, que es la que permite escalar el horizonte cuando procede.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.11 [ALTA] Ambas fuentes coinciden en la ventana de 250 días, pero NO hay evidencia de que el código implementado (`backtesting_kupiec()`) realmente use 250 días. Sin acceso al script, no se puede verificar si existe una desviación entre especificación y ejecución (ej: si usa 500 días como sugiere la literatura recuperada sobre errores comunes). Esta es una AUSENCIA DE EVIDENCIA, no una contradicción explícita, pero es crítica para validación.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**manual_VaR_drift.md** dice:
> El VaR se estima sobre una **ventana de 250 días hábiles**

**backtesting_2026Q1.md** dice:
> sobre la ventana de 250 días establecida en el manual metodológico

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.12 [ALTA] El manual afirma que la ventana de 250 días fue validada mediante análisis de excepciones en ventanas alternativas, pero el informe de backtesting de Q1 2026 NO PROPORCIONA el intervalo de confianza de Kupiec ni el p-valor del estadístico LR que permitiría verificar esa afirmación. La declaración de compatibilidad es cualitativa ("compatible") sin respaldo cuantitativo. Esto impide auditar si el análisis histórico que justificó 250 días fue realmente riguroso.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**manual_VaR_drift.md** dice:
> Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.13 [ALTA] El manual especifica que la función devuelve el estadístico LR y su p-valor, pero el informe de backtesting NO REPORTA ESTOS VALORES. Solo reporta el número de excepciones (4) y una conclusión cualitativa ("dentro de la zona verde"). Sin el p-valor no puede verificarse si el modelo realmente cumple con el nivel de confianza del 99%, ni si la conclusión de "no requiere recalibración" está justificada estadísticamente.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

**backtesting_2026Q1.md** dice:
> El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.14 [ALTA] El manual afirma que la ventana de 250 días fue seleccionada porque ventanas inferiores producían excepciones FUERA del intervalo de Kupiec, pero no proporciona los datos de esas pruebas comparativas (p-valores, número de excepciones en ventanas de 100, 150, 200 días, etc.). Sin esa evidencia, la afirmación es una declaración no verificable. Además, el informe de backtesting reporta 4 excepciones en 62 días (6.45%), que es significativamente superior al 1% esperado, aunque se declara 'compatible' con Kupiec. La falta de cifras de la prueba de Kupiec (estadístico LR, p-valor) impide verificar si realmente está dentro del intervalo de aceptación o si se está interpretando de forma laxa.

*Ámbito: Metodología · Actividad: Validar supuestos y consideración más importantes de la técnica utilizada*

**manual_VaR_drift.md** dice:
> Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.15 [ALTA] El manual declara que la función devuelve el estadístico LR y su p-valor, pero el informe de backtesting NO REPORTA NINGUNO de estos valores. Solo reporta el número de excepciones y una conclusión cualitativa ('compatible'). Esto impide verificar independientemente si el resultado es realmente aceptable o si la interpretación es correcta. Además, falta completamente la prueba de Christoffersen (independencia de excedencias), que es estándar en backtesting de VaR.

*Ámbito: Metodología · Actividad: Validar supuestos y consideración más importantes de la técnica utilizada*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.16 [ALTA] El manual afirma que la ventana de 250 días fue elegida porque ventanas menores generaban excepciones fuera del intervalo de Kupiec, pero el informe de backtesting NO PROPORCIONA el intervalo de Kupiec específico para 62 observaciones al 99%, ni el p-valor del estadístico LR. Sin estos datos, no es posible verificar si 4 excepciones en 62 días está realmente dentro del intervalo o si la afirmación es correcta. Esto impide validar que la justificación histórica de la ventana sea consistente con los resultados actuales.

*Ámbito: Metodología · Actividad: Revisión de los lineamiento internacionales o nacionales*

**manual_VaR_drift.md** dice:
> Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.17 [ALTA] El manual documenta que la función devuelve el estadístico LR y su p-valor, pero el informe de backtesting NO REPORTA estos valores. Solo reporta el número de excepciones (4) y una conclusión cualitativa ("dentro de la zona verde"). Existe una brecha crítica entre lo que el manual dice que el módulo produce y lo que el informe de seguimiento realmente comunica. Esto sugiere que o bien el módulo no se ejecutó completamente, o bien los resultados no se documentaron.

*Ámbito: Metodología · Actividad: Revisión de los lineamiento internacionales o nacionales*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

**backtesting_2026Q1.md** dice:
> El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.18 [ALTA] El manual especifica que la función devuelve 'el estadístico LR junto con su p-valor', pero el informe de seguimiento reporta solo el conteo de excepciones y una conclusión cualitativa ('compatible con el intervalo'). No se reportan las cifras numéricas (LR, p-valor) que el manual declara que se calculan. Esto impide verificar independientemente si la conclusión es correcta y si el modelo realmente cumple el criterio de Kupiec.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

**backtesting_2026Q1.md** dice:
> Se observaron **4 excepciones** en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.19 [ALTA] El manual afirma que la ventana de 250 días fue elegida tras contrastes previos de Kupiec con ventanas alternativas, pero el informe de backtesting Q1 2026 NO REPORTA ESOS CONTRASTES PREVIOS ni aporta los p-valores, estadísticos LR, o intervalos de confianza que justifiquen la elección. Sin esa evidencia, la afirmación de que 250 días es óptimo es una declaración no verificada. Riesgo: la ventana puede haber sido elegida arbitrariamente o heredada de otro contexto sin validación empírica actual.

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**manual_VaR_drift.md** dice:
> Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen.

**backtesting_2026Q1.md** dice:
> El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.20 [ALTA] El manual promete que `backtesting_kupiec()` devuelve el estadístico LR y su p-valor, pero el informe de backtesting Q1 2026 SOLO REPORTA el número de excepciones (4) y una clasificación cualitativa ("zona verde"). No aparecen el estadístico LR, el p-valor, ni el intervalo de confianza numérico de Kupiec. Sin esos números, no es posible verificar independientemente si el resultado es realmente compatible con el intervalo, ni evaluar la potencia de la prueba con 62 observaciones. Riesgo: conclusión de cumplimiento basada en una clasificación mecánica (semáforo) sin respaldo estadístico documentado.

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.21 [ALTA] El manual declara que la función devuelve el estadístico LR y su p-valor, pero el informe de backtesting NO reporta estas cifras. Solo reporta el conteo de excepciones y una conclusión cualitativa ('zona verde'). Sin el LR y el p-valor, no es posible verificar independientemente si el resultado es realmente compatible con Kupiec, ni reproducir la conclusión. Esto viola la trazabilidad y la verificabilidad del control.

*Ámbito: Metodología · Actividad: Analizar el seguimeinto de la metodología*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

**backtesting_2026Q1.md** dice:
> Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.22 [ALTA] Ambos documentos declaran explícitamente ser fixtures sintéticos de prueba, no implementaciones reales. Esto genera incertidumbre crítica sobre si la actividad de validación de tiering es aplicable a un modelo que no está en producción. Si el modelo no es real, no debería tener tiering asignado en el inventario corporativo, lo que invalidaría la premisa de la actividad.

*Ámbito: Gobierno · Actividad: Revisar la actualización del tiering del modelo*

**calcula_var.py** dice:
> FIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente VIRF. No es la implementación de ningún modelo real.

**manual_VaR_drift.md** dice:
> Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.23 [ALTA] El material proporcionado es explícitamente sintético y de prueba, no un modelo real en producción. Por lo tanto, no puede existir acta formal de inventario, tiering asignado, ni gobierno aplicable. Se está pidiendo validar el gobierno de un modelo que el propio contexto declara que no es real.

*Ámbito: Gobierno · Actividad: revisar que el modelo se encuentre inventariado*

**calcula_var.py** dice:
> FIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente VIRF. No es la implementación de ningún modelo real.

**Instrucciones específicas para este ámbito** dice:
> Solo aceptar actas formales firmadas. Un correo NO equivale a acta. Verificar tiering asignado y su justificación.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.24 [ALTA] El manual especifica 250 días como parámetro fijo de cálculo; el código implementa 500 como valor por defecto. Esta diferencia del 100% invalida la comparabilidad de cualquier backtesting Kupiec ejecutado contra el modelo documentado, ya que la ventana es un factor crítico en la distribución empírica y el número de excepciones esperadas.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**manual_VaR_drift.md** dice:
> El VaR se estima sobre una **ventana de 250 días hábiles**

**calcula_var.py** dice:
> def var_historico(retornos, confianza=0.95, ventana=500)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.25 [ALTA] El manual declara 99% como parámetro fijo sin modificación permitida; el código expone confianza=0.95 como parámetro modificable en tiempo de ejecución. Además, el valor por defecto es 95%, no 99%. Esto viola la restricción de control documentada y permite ejecución con parámetro no autorizado.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**manual_VaR_drift.md** dice:
> El **nivel de confianza es del 99 %** ... Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos.

**calcula_var.py** dice:
> def var_historico(retornos, confianza=0.95, ventana=500)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.26 [ALTA] El manual exige retornos logarítmicos (log(P_t/P_{t-1})); el código implementa retornos aritméticos simples ((P_t - P_{t-1})/P_{t-1}). Los retornos logarítmicos son aditivos en el tiempo (propiedad que el manual cita como justificación para escalabilidad del horizonte); los aritméticos no lo son. Esta desviación invalida la justificación metodológica del manual para escalar el horizonte de 1 día a períodos más largos.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**manual_VaR_drift.md** dice:
> Los rendimientos de los factores de riesgo se calculan como **retornos logarítmicos**, por su propiedad de aditividad temporal

**calcula_var.py** dice:
> def retornos_diarios(precios):
    return (precios[1:] - precios[:-1]) / precios[:-1]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.27 [ALTA] El manual afirma que el módulo implementa backtesting_kupiec(); esta función no existe en calcula_var.py. Es una brecha crítica: el backtesting es un control de validación del modelo mencionado en contexto inter-ámbito como ejecutado en Q1 2026, pero no hay código que lo sustente. Esto impide verificar que el backtesting se ejecutó realmente o que sus resultados son reproducibles.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995)

**calcula_var.py** dice:
> No se encontró la función backtesting_kupiec() en el código proporcionado

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.28 [ALTA] El manual especifica 250 días como ventana de estimación; el código implementa 500 como parámetro por defecto. Una ventana de 500 días diluye la reacción ante cambios de régimen (según el propio manual) y produce un VaR subestimado en periodos de volatilidad creciente. Esto invalida la validez del backtesting Kupiec documentado, que fue calibrado sobre 250 días.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_drift.md** dice:
> El VaR se estima sobre una **ventana de 250 días hábiles**

**calcula_var.py** dice:
> def var_historico(retornos, confianza=0.95, ventana=500)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.29 [ALTA] El manual fija el nivel de confianza en 99% como parámetro fijo que no se admite modificar sin aprobación del Comité de Riesgos; el código implementa 95% como parámetro por defecto. Un VaR al 95% es significativamente menor que al 99%, lo que subestima el capital requerido. Esta desviación no está documentada ni justificada.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_drift.md** dice:
> El **nivel de confianza es del 99 %**

**calcula_var.py** dice:
> def var_historico(retornos, confianza=0.95, ventana=500)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.30 [ALTA] El manual especifica retornos logarítmicos (log(P_t/P_{t-1})); el código implementa retornos simples ((P_t - P_{t-1})/P_{t-1}). Los retornos logarítmicos y simples tienen propiedades estadísticas diferentes, especialmente en las colas de la distribución. Esta diferencia afecta directamente la estimación del VaR y la validez del backtesting. La justificación del manual (aditividad temporal) no se aplica a retornos simples.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_drift.md** dice:
> Los rendimientos de los factores de riesgo se calculan como **retornos logarítmicos**, por su propiedad de aditividad temporal

**calcula_var.py** dice:
> def retornos_diarios(precios):
    return (precios[1:] - precios[:-1]) / precios[:-1]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.31 [ALTA] El manual declara la existencia de una función de backtesting Kupiec; el código no la contiene. Esto indica que la documentación describe una funcionalidad que no está implementada, o que el código proporcionado es incompleto. Sin esta función, no es posible ejecutar el backtesting documentado ni validar que el modelo cumple los criterios de cobertura incondicional.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995)

**calcula_var.py** dice:
> No se encontró la función `backtesting_kupiec()` en el código proporcionado

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.32 [ALTA] El manual especifica 250 días como ventana de estimación, pero el código implementa 500 como parámetro por defecto. Una ventana de 500 observaciones diluye la reacción ante cambios de régimen, lo que el propio manual rechaza como criterio de diseño. Esta desviación invalida cualquier backtesting realizado con el código contra la especificación documentada.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_VaR_drift.md** dice:
> El VaR se estima sobre una **ventana de 250 días hábiles**

**calcula_var.py** dice:
> def var_historico(retornos, confianza=0.95, ventana=500)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.33 [ALTA] El manual fija el nivel de confianza en 99% como parámetro fijo que no se admite modificar sin aprobación del Comité de Riesgos. El código implementa 95% como valor por defecto. Un cambio de 4 puntos porcentuales en el nivel de confianza altera significativamente el percentil de la cola izquierda y, por tanto, el VaR estimado. Esto viola la declaración de que ambos parámetros son fijos.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_VaR_drift.md** dice:
> El **nivel de confianza es del 99 %**

**calcula_var.py** dice:
> def var_historico(retornos, confianza=0.95, ventana=500)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.34 [ALTA] El manual especifica retornos logarítmicos (log(P_t / P_{t-1})) como requisito metodológico para preservar la aditividad temporal. El código implementa retornos simples ((P_t - P_{t-1}) / P_{t-1}). Estos son matemáticamente distintos y producen distribuciones diferentes, especialmente en colas. La elección de retornos simples invalida la justificación metodológica del manual sobre aditividad y afecta la validez del backtesting.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_VaR_drift.md** dice:
> Los rendimientos de los factores de riesgo se calculan como **retornos logarítmicos**, por su propiedad de aditividad temporal

**calcula_var.py** dice:
> def retornos_diarios(precios):
    return (precios[1:] - precios[:-1]) / precios[:-1]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.35 [MEDIA] El manual declara que los parámetros (confianza 99%, horizonte 1 día) son fijos y requieren aprobación de comité para cambiar. El informe de backtesting concluye que no se requiere recalibración, pero NO documenta: (a) quién revisó esta conclusión, (b) si se presentó a comité, (c) qué criterios se usaron para decidir que 4 excepciones en 62 días justifican NO recalibrar. Riesgo: falta de gobernanza en la decisión de mantener parámetros fijos.

*Ámbito: Documentación · Actividad: Verifica la existencia , suficiencia y claridad de la documentación*

**manual_VaR_drift.md** dice:
> Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos.

**backtesting_2026Q1.md** dice:
> El modelo se comporta conforme a lo especificado. No se requiere recalibración en este trimestre.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.36 [MEDIA] El manual describe que el módulo implementa backtesting, pero no se especifica si también implementa la prueba de Christoffersen (independencia de excedencias). El informe de seguimiento solo menciona Kupiec. El corpus de dominio identifica ambas pruebas como estándar en validación de modelos de riesgo. La ausencia de Christoffersen es una brecha metodológica no justificada.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**manual_VaR_drift.md** dice:
> El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor.

**backtesting_2026Q1.md** dice:
> El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.37 [MEDIA] El manual afirma que la ventana de 250 días fue validada mediante pruebas de Kupiec con ventanas alternativas, pero el informe de backtesting Q1 2026 no aporta esos análisis comparativos ni sus p-valores. El seguimiento actual solo valida la ventana elegida, no justifica por qué se eligió esa y no otra. Falta la evidencia de la decisión original de diseño.

*Ámbito: Metodología · Actividad: Analizar el seguimeinto de la metodología*

**manual_VaR_drift.md** dice:
> Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen.

**backtesting_2026Q1.md** dice:
> Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas contra el VaR estimado sobre la ventana de 250 días establecida en el manual metodológico.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

## 3. Cuestionamiento metodológico

Un modelo puede documentar impecablemente una elección equivocada. Esto
no evalúa si la metodología está descrita, sino si está **justificada**.

### Verifica la inclusión del objetivo, usos y usuarios del modelo

No aplica a esta actividad (Verificación de Manual Metodológico — Objetivo, Usos, Usuarios). El cuestionamiento metodológico se aplica cuando se evalúa la ELECCIÓN de la metodología (por qué simulación histórica vs. paramétrico vs. Monte Carlo). Aquí se evalúa la DOCUMENTACIÓN de esa elección. Sin embargo, se observa que el manual justifica la ventana de 250 días ('tras comprobar que ventanas inferiores producían excepciones fuera del intervalo de Kupiec'), pero NO JUSTIFICA la elección de simulación histórica sobre alternativas, ni cita literatura que la sustente para este tipo de cartera. Esto es una ausencia de justificación metodológica, no un cuestionamiento de la metodología en sí.

### Verifica la existencia , suficiencia y claridad de la documentación

El manual justifica la elección de 250 días por contraste empírico contra el intervalo de Kupiec (ventanas menores producen excepciones fuera del intervalo, mayores diluyen reacción ante cambios de régimen), pero NO documenta: (1) qué rango de ventanas se probó (100, 150, 200, 250, 300, 500?); (2) cuál fue el criterio de decisión exacto (minimizar excepciones, maximizar reactividad, balance?); (3) por qué se eligió simulación histórica sobre alternativas (Monte Carlo, GARCH, EVT) — se menciona la propiedad de aditividad de log-retornos pero no se justifica por qué eso hace que la simulación histórica sea superior; (4) si se consideró el trade-off entre captura de eventos extremos (EVT) vs. representatividad de la distribución empírica. La limitación declarada (no captura eventos sin precedente) es crítica pero NO se especifica cómo se monitorea ni qué acciones se disparan si ocurren. Falta análisis de sensibilidad a la ventana y justificación de por qué Kupiec es suficiente (no se menciona Christoffersen para independencia de excepciones ni López para cobertura condicional).

### Verificar la coherencia del manual de implementación con el manual métodolocios

No aplica a este ámbito (Documentación/Coherencia). Sin embargo, se observa que el manual metodológico justifica la elección de 250 días por contraste empírico contra el intervalo de Kupiec, lo cual es un enfoque válido. Falta: (1) justificación de por qué se eligió Kupiec y no Christoffersen (que añade pruebas de independencia de excepciones, relevante para detectar clustering), (2) evidencia de que la distribución empírica de 250 días es representativa del futuro inmediato (supuesto declarado en limitaciones, pero no verificado), (3) análisis de sensibilidad a cambios de régimen (mencionado como razón para no usar ventanas mayores, pero no documentado).

### Verificar la existencia, suficiencia y claridad de la documentación

No aplica a esta actividad (ámbito: Documentación, no Metodología). Sin embargo, se observa que el manual justifica la elección de 250 días por prueba empírica ("ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec"), pero no proporciona esa evidencia en el documento. Tampoco se justifica por qué se eligió Kupiec y no Christoffersen (que además contrasta independencia de excepciones, crítico para detectar clustering). Esta ausencia de justificación comparativa es una debilidad metodológica que debería estar documentada.

### Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

El manual justifica la elección de 250 días mediante un argumento de trade-off (ventanas menores producen excepciones fuera del intervalo de Kupiec; ventanas mayores diluyen reacción ante cambios de régimen), pero esta justificación es DECLARATIVA, no DEMOSTRATIVA: no se proporcionan los resultados de esos experimentos, ni se cita literatura que sustente este trade-off específico. La elección del 99% de confianza y horizonte de 1 día se describe pero no se justifica (¿por qué no 95%? ¿por qué no 10 días?). El manual menciona que retornos logarítmicos se usan por aditividad temporal, lo que es correcto, pero no se verifica que el código realmente los calcule así. La prueba de Kupiec se implementa, pero la literatura estándar exige TAMBIÉN Christoffersen (independencia de excepciones) y análisis de López (magnitud de excepciones), que no aparecen documentados. Sin acceso al código fuente de `backtesting_kupiec()`, no se puede verificar si implementa correctamente el estadístico LR de Kupiec (fórmula, grados de libertad, p-valor bilateral vs unilateral).

### Existencia de buenas prácticas en el enfoque metodológico

1. **Justificación de simulación histórica vs alternativas**: El manual NO justifica por qué se eligió simulación histórica en lugar de métodos paramétricos (GARCH, modelos de volatilidad condicional) o Monte Carlo. No se declara qué alternativas se evaluaron ni con qué criterios se descartaron. Para una cartera de negociación con horizonte de 1 día, métodos paramétricos podrían capturar cambios de régimen mejor que una ventana fija de 250 días. Esta elección debe estar justificada, no solo descrita. 2. **Verificación de supuestos**: La simulación histórica asume que la distribución empírica es estacionaria y representativa. El manual declara esta limitación pero NO VERIFICA el supuesto: no hay pruebas de estacionariedad (ADF, KPSS), no hay análisis de cambios estructurales, no hay comparación de distribuciones en subperíodos. Sin esto, no puede afirmarse que 250 días de datos sean suficientes para capturar la verdadera distribución de riesgos. 3. **Análisis de ventanas**: El manual afirma que se probaron ventanas inferiores y superiores, pero NO APORTA LOS RESULTADOS. ¿Qué ventanas se probaron? ¿Cuál fue el número de excepciones en cada una? ¿Cuáles fueron los p-valores de Kupiec? Sin estos datos, la afirmación de que 250 días es óptimo es indemostrable. 4. **Ausencia de Christoffersen**: El backtesting solo implementa Kupiec (cobertura incondicional), que verifica el número de excepciones pero NO su independencia. Christoffersen (1999) es estándar en validación de VaR y detectaría si las excepciones se agrupan (clustering), lo que indicaría que el modelo no captura la volatilidad condicional. La omisión de esta prueba es una brecha metodológica significativa. 5. **Horizonte de 1 día y ventana de 250 días**: No se justifica por qué una ventana de 250 días es apropiada para un horizonte de mantenimiento de 1 día. En mercados con volatilidad condicional, la información relevante puede estar más concentrada en los últimos 20-50 días. No hay análisis de sensibilidad que muestre cómo varía el VaR con la ventana. 6. **Nivel de confianza fijo al 99%**: El manual declara que el 99% es fijo y no se admite su modificación sin aprobación del Comité de Riesgos. No se justifica por qué el 99% es el nivel apropiado para esta cartera. ¿Se evaluó el 95% o el 99.9%? ¿Cuál es el trade-off entre cobertura y reactividad? Sin este análisis, la elección parece arbitraria.

### Validar supuestos y consideración más importantes de la técnica utilizada

1. **Justificación de la metodología**: El manual declara simulación histórica sin argumentar por qué se eligió sobre alternativas (ej. EWMA paramétrico, modelos de colas gruesas, Expected Shortfall). La única justificación ofrecida es que retornos logarítmicos tienen 'propiedad de aditividad temporal', pero esto es una propiedad técnica, no una justificación de por qué simulación histórica es superior a otros métodos para esta cartera. 2. **Supuestos no verificados**: El supuesto central de que 'la distribución empírica del pasado reciente es representativa del futuro inmediato' NO se verifica. No hay prueba de estacionariedad, análisis de cambios de régimen, ni comparación de distribuciones entre períodos de estimación y validación. Dado que el manual reconoce que el modelo 'no captura eventos sin precedente', la falta de verificación de este supuesto es crítica. 3. **Alternativas descartadas**: No hay mención de qué metodologías se evaluaron y por qué se descartaron. ¿Se consideró EWMA? ¿Modelos de colas gruesas? ¿Expected Shortfall? La ausencia de este análisis sugiere que la elección fue heredada sin justificación contemporánea. 4. **Backtesting incompleto**: El manual menciona Kupiec pero no Christoffersen. La literatura estándar (recuperada en el corpus) exige ambas pruebas: Kupiec valida cobertura incondicional, Christoffersen valida independencia. Con solo Kupiec, no se detecta clustering de excepciones, que es un patrón de fallo común en modelos de simulación histórica bajo cambios de régimen. 5. **Análisis de excedencias**: El manual no declara que se realizará análisis de las excepciones individuales, que es práctica estándar. Las 4 excepciones observadas no se explican: ¿fueron eventos de mercado (ej. volatilidad extrema) o fallos del modelo? Sin esto, no se puede validar si el modelo captura correctamente la dinámica de riesgo.

### Revisión de los lineamiento internacionales o nacionales

1. **Justificación de la metodología**: El manual elige simulación histórica pero NO JUSTIFICA por qué frente a alternativas (método paramétrico, Monte Carlo, GARCH, Expected Shortfall). La única mención es que la ventana de 250 días fue calibrada empíricamente, pero no hay comparación de métodos ni análisis de trade-offs. 2. **Verificación de supuestos**: La simulación histórica requiere que la distribución empírica sea estacionaria y representativa. El manual DECLARA esta limitación (§ 4) pero NO VERIFICA si se cumple: no hay contrastes de estacionariedad (ADF, KPSS), análisis de cambios de régimen, o pruebas de normalidad. La limitación se menciona pero no se monitorea. 3. **Calibración de parámetros**: El manual afirma que la ventana de 250 días fue elegida porque ventanas menores generaban excepciones fuera del intervalo de Kupiec, pero NO APORTA los datos de esos contrastes previos (número de excepciones, p-valores, fechas). Sin esta evidencia, la afirmación es una declaración no verificable. 4. **Backtesting incompleto**: El manual especifica que se implementa Kupiec (cobertura incondicional), pero NO MENCIONA Christoffersen (independencia de excepciones). Según la literatura estándar en backtesting de riesgo de mercado (BCBS 1996, 2019), ambas pruebas son complementarias: Kupiec detecta si la frecuencia es correcta, Christoffersen detecta si hay clustering (excepciones agrupadas, indicativo de cambios de régimen no capturados). La omisión de Christoffersen es una brecha metodológica. 5. **Horizonte y nivel de confianza**: El manual fija horizonte de 1 día y confianza del 99% como «parámetros fijos» sin aprobación del Comité de Riesgos. No hay justificación de por qué estos valores son adecuados para esta cartera, ni análisis de sensibilidad a cambios en estos parámetros. 6. **Definición de excedencia**: El manual no define explícitamente cómo se calcula la excedencia (¿pérdida realizada vs VaR estimado? ¿incluye comisiones? ¿qué tratamiento de faltantes?). Sin esta precisión, el backtesting no es reproducible.

### Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

¿Por qué se implementó SOLO la prueba de Kupiec (cobertura incondicional) y no también Christoffersen (independencia)? El corpus de dominio señala que ambas son estándar y que omitir la prueba de independencia es un 'error frecuente' que puede llevar a conclusiones falsas de adecuación. ¿Se descartó Christoffersen deliberadamente, y con qué justificación? ¿Se verificó que las 4 excepciones no muestren clustering (agrupamiento temporal), que sería evidencia de que el modelo no captura cambios de régimen? El manual declara que la ventana de 250 días se eligió porque 'ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec', pero no se reportan esos contrastes previos ni se justifica por qué 250 es óptimo frente a otras longitudes. ¿Se realizó un análisis de sensibilidad de la ventana? ¿Se verificó que los retornos logarítmicos cumplen el supuesto de aditividad temporal en el horizonte de 1 día, o se asumió? ¿Se analizó si las 4 excepciones corresponden a eventos sin precedente en la ventana de 250 días (limitación declarada del modelo) o a fallos de captura de volatilidad? Sin este análisis, no se puede distinguir si el modelo es adecuado o si simplemente tuvo suerte en una muestra pequeña (n=62).

### Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

1. **Justificación de la metodología**: El manual elige simulación histórica sin justificar por qué frente a alternativas (p.ej., modelos paramétricos, GARCH, simulación de Montecarlo). Se declara una limitación (no captura eventos sin precedente) pero no se argumenta por qué esa limitación es aceptable para esta cartera. ¿Por qué simulación histórica y no un modelo que capte cambios de régimen o colas gruesas? 2. **Supuestos no verificados**: La simulación histórica asume que la distribución empírica de 250 días es estacionaria y representativa. El manual NO REPORTA contrastes de estacionariedad, normalidad, autocorrelación, o heterocedasticidad de los retornos. Sin esos contrastes, no se puede afirmar que los supuestos del método se sostienen. 3. **Parámetros no justificados cuantitativamente**: La ventana de 250 días se fijó tras "comprobar" que otras ventanas fallaban en Kupiec, pero esos contrastes no se documentan. ¿Qué ventanas se probaron? ¿Cuáles fueron los p-valores? ¿Se aplicó un criterio de optimización (p.ej., minimizar excepciones esperadas) o fue prueba y error? 4. **Backtesting incompleto**: Solo se ejecuta Kupiec (cobertura incondicional). Falta Christoffersen (independencia de excepciones), que es estándar desde 1999 y que la literatura recuperada identifica como error frecuente omitirla. Con 4 excepciones en 62 días, la independencia es crítica: ¿se agrupan en períodos de estrés o se distribuyen aleatoriamente? 5. **Análisis de sensibilidad ausente**: No hay documentación de cómo varía el VaR estimado si se cambia la ventana (p.ej., 200, 250, 300 días), el nivel de confianza (95%, 99%, 99.9%), o el horizonte (1, 5, 10 días). Sin eso, no se puede evaluar la robustez del modelo a cambios de parámetros. 6. **Análisis de escenarios ausente**: No hay evaluación de cómo se comportaría el modelo bajo escenarios de estrés (volatilidad extrema, cambios de correlación, eventos de cola). La limitación declarada (no captura eventos sin precedente) sugiere que el modelo es vulnerable a esos escenarios, pero no se cuantifica el riesgo. 7. **Potencia estadística no declarada**: Con 62 observaciones, la prueba de Kupiec tiene baja potencia para detectar modelos deficientes. El manual no declara este límite ni propone compensaciones (p.ej., pruebas complementarias, análisis de excedencias individuales).

### Analizar el seguimeinto de la metodología

1. **Justificación de la metodología**: El manual elige simulación histórica con ventana de 250 días y backtesting Kupiec, pero no justifica por qué esta metodología sobre alternativas (p.ej., GARCH, EVT, simulación de Montecarlo). Solo declara que 250 días fue validado contra Kupiec, sin argumentar por qué Kupiec y no Christoffersen o López. 2. **Supuestos no verificados**: La simulación histórica asume que la distribución empírica del pasado es representativa del futuro (declarado en limitaciones), pero no hay evidencia de que se verifique estacionariedad, independencia de retornos, o ausencia de cambios de régimen. El manual menciona que ventanas superiores «diluyen la reacción ante cambios de régimen», lo que sugiere que el modelo es sensible a este supuesto, pero no hay test de estacionariedad documentado. 3. **Alternativas descartadas**: El manual no documenta qué otras metodologías se consideraron ni por qué se descartaron. ¿Se evaluó GARCH? ¿Por qué no? 4. **Papers citados**: Se cita Kupiec (1995) pero no se verifica que el paper sostenga el uso de backtesting incondicional como único control. La literatura estándar (Christoffersen, 1998) exige también independencia de excepciones. La omisión de Christoffersen no está justificada. 5. **Adecuación a la cartera**: No hay evidencia de que la metodología se haya validado específicamente para la cartera de negociación de esta entidad. ¿Se heredó de otro modelo? ¿Se calibró para este tipo de activos? 6. **Limitaciones declaradas vs. verificadas**: El manual declara que la simulación histórica «no captura eventos sin precedente», pero no hay análisis de stress testing o escenarios extremos que compensen esta limitación.

> ✍️ **Te toca:** contrasta esto con tu criterio experto. El agente puede
> cuestionar sin conocer restricciones de negocio que sí justifican la
> elección — si es el caso, déjalo escrito en el informe final.

## 4. Información a solicitar al modelador

**166 petición(es)**, sin duplicados y ordenadas por gravedad del
control que las origina. Esta lista se envía tal cual.

| # | Ámbito | Score | Petición |
|---:|---|---:|---|
| 1 | Calidad de datos | 1/5 | ¿Existe un script de validación de datos (tipo _replica_virf.py o control_calidad_datos.py) que ejecute controles sobre missing values, duplicados y outliers antes de cada cálculo de VaR? Si existe, ¿cuál es su nombre y dónde se encuentra? |
| 2 | Calidad de datos | 1/5 | ¿Cómo se tratan los días con mercados cerrados o datos incompletos en la ventana de 250 días hábiles? ¿Se excluyen, se interpolan, o se requiere que la ventana tenga exactamente 250 observaciones válidas? |
| 3 | Calidad de datos | 1/5 | ¿Qué criterio se usa para detectar y tratar outliers? ¿Se aplica Z-score, IQR, o algún otro método? ¿Se documentan las decisiones de exclusión o ajuste? |
| 4 | Calidad de datos | 1/5 | ¿Existen reportes periódicos (diarios, semanales, mensuales) que documenten incidencias de calidad de datos (missing, duplicados, valores fuera de rango)? ¿A quién se reportan y qué acciones se toman? |
| 5 | Calidad de datos | 1/5 | ¿Se verifica la integridad referencial de los datos de entrada (p.ej., que los factores de riesgo correspondan a la cartera, que no haya desalineamientos de fechas entre series)? |
| 6 | Calidad de datos | 1/5 | ¿Se ejecutan controles de calidad de datos ANTES de cada cálculo de VaR, o solo en la fase de implementación inicial? |
| 7 | Calidad de datos | 1/5 | ¿Existe un script o procedimiento documentado para validar la calidad de los datos históricos antes de cada cálculo de VaR? Si existe, ¿dónde está ubicado y cuál es su última ejecución? |
| 8 | Calidad de datos | 1/5 | ¿Cómo se detectan y tratan los missing values en la serie de retornos? ¿Se excluyen observaciones, se interpolan, o se rechaza el cálculo si hay gaps? |
| 9 | Calidad de datos | 1/5 | ¿Cuál es el criterio para identificar outliers en los retornos? ¿Se usa Z-score, IQR, o algún otro método? ¿Se documentan las decisiones de exclusión o ajuste? |
| 10 | Calidad de datos | 1/5 | ¿Se verifica la ausencia de duplicados en los datos de entrada? ¿Existe un control de integridad referencial (ej: fechas únicas, sin saltos en días hábiles)? |
| 11 | Calidad de datos | 1/5 | ¿Quién es responsable de actualizar los inputs (precios, retornos) y con qué frecuencia? ¿Existe un log de auditoría que registre cuándo se actualizaron y quién lo hizo? |
| 12 | Calidad de datos | 1/5 | ¿Se han documentado incidencias de calidad de datos (errores detectados, correcciones aplicadas) desde la puesta en producción del modelo? ¿Cómo se registran y comunican? |
| 13 | Calidad de datos | 1/5 | ¿El backtesting de Kupiec (§3) se ejecuta sobre datos que han pasado por estos controles de calidad, o se ejecuta sobre los datos brutos? |
| 14 | Calidad de datos | 1/5 | ¿Se verifica que la ventana de 250 días hábiles no incluya períodos de mercados cerrados o datos incompletos? ¿Cómo se maneja el 31 de diciembre o festivos? |
| 15 | Gobierno | 1/5 | ¿Existe un inventario oficial de modelos de riesgo en la herramienta corporativa de GRC? Si existe, ¿aparece el modelo 'VaR Drift' registrado con tiering asignado? |
| 16 | Gobierno | 1/5 | ¿Cuál es el acta formal (con fecha, firmantes y aprobaciones) que acredita la inclusión de este modelo en el inventario? |
| 17 | Gobierno | 1/5 | ¿Cuál es el tiering asignado al modelo y cuál es la justificación documentada para esa clasificación? |
| 18 | Gobierno | 1/5 | ¿Existe un acta de revisión o actualización del tiering en los últimos 12 meses? |
| 19 | Gobierno | 1/5 | ¿El material proporcionado (calcula_var.py y manual_VaR_drift.md) es realmente el modelo en producción, o es material de prueba que debe ser reemplazado por la documentación y código del modelo real antes de proceder con la validación de gobierno? |
| 20 | Implementación | 1/5 | ¿Existen correos de comunicación entre el equipo de desarrollo (proveedor externo) y la primera línea de riesgos reportando resultados de la implementación? Si existen, ¿en qué fechas se enviaron y qué resultados se reportaron? |
| 21 | Implementación | 1/5 | ¿Se ejecutaron pruebas unitarias o de integración (UAT) sobre el código de implementación? Si existen, ¿dónde están documentadas (logs, reportes de test, actas de UAT)? ¿Quién las ejecutó y quién las aprobó? |
| 22 | Implementación | 1/5 | ¿Existe un correo o acta formal de aprobación para paso a producción? ¿Quién autorizó el paso a producción y en qué fecha? |
| 23 | Implementación | 1/5 | ¿El código proporcionado (calcula_var.py) es la implementación real del modelo VaR Drift o es efectivamente un fixture de prueba? Si es real, ¿por qué contiene la declaración de que es 'código fabricado para probar'? |
| 24 | Implementación | 1/5 | ¿Existe documentación de conformidad de resultados entre la implementación y la especificación metodológica (manual_VaR_drift.md)? Específicamente: ¿se verificó que el parámetro de ventana, nivel de confianza y método de cálculo de retornos en el código coinciden con lo documentado en el manual? |
| 25 | Uso e integración a la gestión | 1/5 | ¿Quiénes son los usuarios finales del modelo VaR Drift en producción? (Proporcionar lista con nombres, áreas, funciones específicas) |
| 26 | Uso e integración a la gestión | 1/5 | ¿Cuál es el alcance original documentado del modelo? (Proporcionar acta de aprobación, especificación de requisitos, o documento de diseño que defina para qué fue construido) |
| 27 | Uso e integración a la gestión | 1/5 | ¿Cuáles son los usos autorizados del modelo? (Proporcionar manual de usuario, guía de integración, o documento de gobernanza que especifique aplicaciones permitidas) |
| 28 | Uso e integración a la gestión | 1/5 | ¿Existe un reporte de seguimiento periódico de usos? (Proporcionar reportes presentados a comités de riesgo, validación o gobierno en los últimos 12 meses) |
| 29 | Uso e integración a la gestión | 1/5 | ¿Cómo se integra el modelo en los sistemas de gestión de riesgo? (Proporcionar documentación de interfaces, flujos de datos, y puntos de decisión donde se usa el output) |
| 30 | Uso e integración a la gestión | 1/5 | ¿Se ha documentado algún cambio de alcance o extensión de usos desde la validación inicial? (Proporcionar actas de cambio, justificaciones, y re-validaciones si aplica) |
| 31 | Uso e integración a la gestión | 1/5 | ¿Existe un control de acceso y auditoría de quién ejecuta el modelo y cuándo? (Proporcionar logs de ejecución, permisos asignados, o matriz de responsabilidades) |
| 32 | Documentación | 2/5 | ¿Existe un documento de control de versiones (changelog, historial de cambios) del manual metodológico? Si existe, ¿cuál es su nombre y ubicación? |
| 33 | Documentación | 2/5 | ¿Cuál es el número de versión actual del manual y cuál es su fecha de vigencia? |
| 34 | Documentación | 2/5 | ¿Quién aprobó la decisión de fijar la ventana en 250 días, en qué fecha, y mediante qué mecanismo (acta de comité, memorando, etc.)? |
| 35 | Documentación | 2/5 | ¿Cuándo fue la última revisión formal del manual metodológico y quién la autorizó? |
| 36 | Documentación | 2/5 | ¿Existe un proceso documentado de gobernanza de cambios que especifique quién puede modificar el manual, qué aprobaciones se requieren, y cómo se comunican los cambios a las áreas de riesgo y cumplimiento? |
| 37 | Documentación | 2/5 | ¿Se han realizado cambios al modelo (parámetros, metodología, backtesting) desde su aprobación inicial? Si es así, ¿están registrados y justificados? |
| 38 | Documentación | 2/5 | ¿Existe un documento formal de 'Objetivo y Alcance' o 'Gobernanza del Modelo' que defina explícitamente: (a) para qué decisiones se usa el VaR (límites de negociación, capital regulatorio, IFRS 9, reporte interno), (b) quién es el usuario autorizado y quién es responsable de su interpretación, (c) qué decisiones NO debe informar? |
| 39 | Documentación | 2/5 | ¿El backtesting incluye pruebas de independencia de excepciones (Christoffersen) o análisis de cambios de régimen para verificar que la distribución empírica es estable, dado que el manual declara esta como una limitación crítica? |
| 40 | Documentación | 2/5 | ¿Existe un documento operativo separado que describa el proceso de ejecución paso a paso, incluyendo: frecuencia de cálculo, responsables, validación de datos de entrada, y escalada de excepciones? |
| 41 | Documentación | 2/5 | ¿Se ha documentado y verificado que el nivel de confianza del 99% y el horizonte de 1 día son apropiados para TODOS los usos declarados del modelo, o varían según el usuario (p.ej., 99% para límites de negociación pero 97.5% para capital regulatorio bajo FRTB)? |
| 42 | Documentación | 2/5 | ¿Existe control de versiones del manual (fecha de aprobación, versión, cambios respecto a versión anterior) que permita auditar la trazabilidad de cambios en parámetros o metodología? |
| 43 | Documentación | 2/5 | ¿Cuál es el número de versión actual del manual metodológico y cuándo fue emitido? |
| 44 | Documentación | 2/5 | ¿Existe un registro de cambios (changelog) que documente todas las modificaciones al manual desde su creación? Si existe, ¿por qué no está incluido en la documentación? |
| 45 | Documentación | 2/5 | ¿Quién aprobó la especificación actual (ventana de 250 días, confianza 99%, horizonte 1 día) y en qué fecha? |
| 46 | Documentación | 2/5 | ¿Contra qué versión específica del manual se ejecutó el backtesting de 2026 Q1? ¿Se conserva un registro de esa versión? |
| 47 | Documentación | 2/5 | ¿Existe un procedimiento documentado para autorizar cambios al manual? ¿Quién es responsable de mantener el control de versiones? |
| 48 | Documentación | 2/5 | ¿Se han realizado cambios al manual desde su emisión inicial? Si sí, ¿cuáles fueron y cuándo se aprobaron? |
| 49 | Documentación | 2/5 | ¿Existe un documento de control de versiones (fecha de creación, versión, aprobador, fecha de aprobación) del manual metodológico y del informe de backtesting? |
| 50 | Documentación | 2/5 | ¿Cuál es el nombre exacto, versión y fecha de ejecución del script `backtesting_kupiec()` que se ejecutó para generar el informe 2026Q1? ¿Se puede reproducir con los mismos datos? |
| 51 | Documentación | 2/5 | ¿El código de `backtesting_kupiec()` implementa exactamente los parámetros del manual (ventana 250 días, confianza 99%, horizonte 1 día)? ¿Hay un test unitario que valide esto? |
| 52 | Documentación | 2/5 | ¿Quién es el propietario del modelo (área, persona, comité) y quién autoriza cambios en parámetros? ¿Se documentó la aprobación inicial del manual? |
| 53 | Documentación | 2/5 | ¿Existe un manual operativo que describa: quién ejecuta el backtesting, con qué frecuencia, sobre qué datos, dónde se almacenan resultados, quién revisa, a quién se reporta? |
| 54 | Documentación | 2/5 | ¿Cómo se monitorea la limitación declarada (distribución histórica representativa del futuro)? ¿Qué indicadores se usan y qué acciones se disparan si se viola? |
| 55 | Documentación | 2/5 | ¿Por qué se eligió simulación histórica sobre Monte Carlo o GARCH? ¿Se evaluaron alternativas y se documentó el descarte? |
| 56 | Documentación | 2/5 | ¿Por qué es suficiente Kupiec para backtesting? ¿Se consideró Christoffersen (independencia) o López (cobertura condicional)? |
| 57 | Documentación | 2/5 | ¿Cuál fue el criterio para decidir que 4 excepciones en 62 días (6.45%) justifican NO recalibrar? ¿Se presentó esta decisión al Comité de Riesgos como requiere el manual? |
| 58 | Documentación | 2/5 | ¿Existe un manual operativo (de implementación) que describa paso a paso cómo se ejecuta el cálculo de VaR y el backtesting? Si existe, ¿cuál es su versión actual y fecha de última revisión? |
| 59 | Documentación | 2/5 | ¿Cuál es el código fuente que implementa la función `backtesting_kupiec()`? ¿Está anotado y disponible para auditoría? |
| 60 | Documentación | 2/5 | ¿Existen logs de ejecución del backtesting de 2026 Q1 que muestren: (a) fecha y hora de ejecución, (b) parámetros utilizados (ventana, nivel de confianza, número de observaciones), (c) datos de entrada (serie de retornos), (d) resultados intermedios (VaR estimado por día), (e) excepciones identificadas con fechas? |
| 61 | Documentación | 2/5 | ¿Cómo se obtienen los datos de entrada (precios, retornos)? ¿Existe un proceso documentado de validación de calidad de datos antes de alimentar el modelo? |
| 62 | Documentación | 2/5 | ¿Se ejecutó en 2026 Q1 una revisión de la adecuación de la ventana de 250 días conforme al procedimiento descrito en el manual (contraste contra intervalo de Kupiec)? ¿Cuáles fueron los resultados? |
| 63 | Documentación | 2/5 | ¿Quién ejecuta el backtesting, quién lo revisa, y cuál es el proceso de escalamiento si se detectan excepciones fuera del intervalo de Kupiec? |
| 64 | Documentación | 2/5 | ¿Existe control de versiones (Git, SharePoint con historial, o similar) de ambos manuales? ¿Cuáles son las versiones vigentes y cuándo se aprobaron por última vez? |
| 65 | Documentación | 2/5 | ¿Por qué se eligió Kupiec y no Christoffersen? ¿Se consideró la prueba de independencia de López o Berkowitz? |
| 66 | Documentación | 2/5 | ¿Cómo se reconcilian los 62 días de negociación reportados en el backtesting con la ventana de 250 días de estimación? ¿Se trata de 62 días de contraste sobre un modelo estimado con 250 días previos? |
| 67 | Documentación | 2/5 | ¿Existe un manual operativo (distinto del metodológico) que describa paso a paso el proceso de cálculo del VaR, incluyendo: fuentes de datos, validaciones previas, responsables, frecuencia de ejecución, y tratamiento de excepciones? |
| 68 | Documentación | 2/5 | ¿Existe documentación de especificación de calidad de datos que defina: criterios de completitud, tratamiento de faltantes, validación de precios, reconciliación con sistemas de origen, y auditoría de cambios? |
| 69 | Documentación | 2/5 | ¿Existe control de versiones del manual metodológico y del código? ¿Qué cambios se han realizado desde la implementación inicial, cuándo, y con qué aprobaciones? |
| 70 | Documentación | 2/5 | ¿Existe evidencia de ejecución real del backtesting (logs, datos de entrada, parámetros, fecha/hora de ejecución, usuario que ejecutó)? ¿Quién ejecuta el backtesting, con qué frecuencia, y a quién se reportan los resultados? |
| 71 | Documentación | 2/5 | ¿Por qué se eligió la prueba de Kupiec y no Christoffersen (que además verifica independencia de excepciones)? ¿Se descartó Christoffersen explícitamente, y si es así, por qué? |
| 72 | Documentación | 2/5 | ¿Existe análisis de las excepciones individuales observadas (las 4 excepciones en Q1 2026)? ¿Se documentó qué movimientos de mercado las causaron y si fueron eventos previsibles o sin precedente? |
| 73 | Documentación | 2/5 | ¿Se ha verificado que los retornos logarítmicos utilizados en el backtesting provienen de las mismas fuentes y con la misma metodología que los utilizados en la estimación del VaR? |
| 74 | Documentación | 2/5 | ¿Existe documentación de las limitaciones del modelo (simulación histórica no captura eventos sin precedente) y cómo se mitigan (ej: pruebas de estrés, límites de concentración)? |
| 75 | Documentación | 2/5 | ¿Cuál es el objetivo declarado del modelo, quiénes son los usuarios finales, y para qué decisiones se utiliza el VaR estimado (capital, límites de riesgo, reportes regulatorios)? |
| 76 | Documentación | 2/5 | ¿Existe evidencia de que el modelo ha sido aprobado por el Comité de Riesgos y de que cualquier cambio en parámetros (ventana, nivel de confianza) requiere esa aprobación? |
| 77 | Documentación | 2/5 | ¿Existe un manual metodológico de PRODUCCIÓN (no fixture) con número de versión, fecha de aprobación, y control de cambios documentado? |
| 78 | Documentación | 2/5 | ¿Quién es responsable de ejecutar el backtesting, con qué frecuencia, y cuál es el procedimiento operativo paso a paso (incluyendo validación de datos, criterios de aceptación, y escalamiento de excepciones)? |
| 79 | Documentación | 2/5 | ¿Existe un registro de cambios (changelog) que documente cuándo y por qué se modificó la ventana de 250 días, quién lo aprobó, y cómo se validó el impacto en el backtesting? |
| 80 | Documentación | 2/5 | ¿Se ejecuta el backtesting sobre datos reales de la cartera de negociación de la entidad, y existe evidencia de logs, timestamps y firmas de control de cada ejecución? |
| 81 | Documentación | 2/5 | ¿Existe un procedimiento de monitoreo de calidad de datos (validación de completitud, reconciliación con fuentes, tratamiento de faltantes) documentado y ejecutado antes de cada backtesting? |
| 82 | Documentación | 2/5 | ¿Se revisa periódicamente la idoneidad de la ventana de 250 días y se documenta esa revisión? ¿Cuál es la frecuencia y quién la autoriza? |
| 83 | Documentación | 2/5 | ¿Cuál es el p-valor exacto de la prueba de Kupiec para las 4 excepciones observadas en 62 días, y cuál es el intervalo de confianza esperado al 99%? (Necesario para verificar la afirmación de compatibilidad.) |
| 84 | Documentación | 2/5 | ¿Existe un script ejecutable de `backtesting_kupiec()` con logs de ejecución, y cuáles fueron los datos de entrada exactos (fechas, número de observaciones, valores de retornos)? |
| 85 | Documentación | 2/5 | ¿Se ejecutó algún test de independencia de excepciones (Christoffersen) o solo se aplicó Kupiec? Si solo Kupiec, ¿por qué se descartó Christoffersen? |
| 86 | Documentación | 2/5 | ¿Existe un manual operativo separado que describa la frecuencia de ejecución del backtesting, responsables, criterios de escalada si se detectan excepciones fuera de banda, y qué cambios se han aplicado en trimestres anteriores? |
| 87 | Documentación | 2/5 | ¿Se documentó el monitoreo de calidad de datos (integridad, faltantes, outliers) antes de ejecutar el backtesting? ¿Qué criterios se usaron para validar los retornos logarítmicos? |
| 88 | Documentación | 2/5 | ¿Cuál es la evidencia de que los retornos usados en el backtesting son exactamente los mismos que se usaron en la estimación del VaR? (Hashes, logs de carga, o trazabilidad de datos.) |
| 89 | Documentación | 2/5 | ¿Existe un script o código fuente de `backtesting_kupiec()` que pueda ser auditado? ¿Dónde se almacena y bajo qué control de versiones? |
| 90 | Documentación | 2/5 | ¿Se ejecutó realmente el backtesting en Q1 2026? ¿Existen logs, timestamps o reportes de ejecución que demuestren cuándo, con qué datos y qué parámetros se corrió? |
| 91 | Documentación | 2/5 | ¿Cuál es el proceso de validación de datos de entrada (retornos logarítmicos)? ¿Cómo se tratan los días con mercados cerrados, datos faltantes o anomalías? |
| 92 | Documentación | 2/5 | ¿Se realizó análisis individual de las 4 excepciones observadas? ¿Qué eventos de mercado las causaron? ¿Revelan debilidades del modelo o son eventos extremos justificables? |
| 93 | Documentación | 2/5 | ¿Se ejecutaron pruebas de independencia (Christoffersen) o de magnitud (López) además de Kupiec? Si no, ¿por qué se descartaron? |
| 94 | Documentación | 2/5 | ¿Cuál es la potencia estadística de la prueba de Kupiec con 62 observaciones? ¿Se documentó este límite? |
| 95 | Documentación | 2/5 | ¿Existe un manual operativo separado que describa paso a paso cómo se ejecuta el backtesting, quién lo ejecuta, con qué frecuencia y a quién se reportan los resultados? |
| 96 | Documentación | 2/5 | ¿El informe de backtesting se presenta a algún comité de riesgos o de validación? ¿Hay evidencia de que los resultados se usan para tomar decisiones (recalibración, límites de riesgo, etc.)? |
| 97 | Documentación | 2/5 | ¿Se revisa periódicamente la justificación de la ventana de 250 días? ¿Existe un proceso documentado para evaluar si sigue siendo óptima? |
| 98 | Metodología | 2/5 | ¿Cuáles fueron los resultados del análisis de ventanas alternativas (número de excepciones, p-valores de Kupiec) que justificó la elección de 250 días? Proporcionar la tabla completa con ventanas de 100, 150, 200, 250, 300, 500 días. |
| 99 | Metodología | 2/5 | ¿Cuál es el intervalo de confianza de Kupiec al 99% para 62 días de negociación, y cuál fue el p-valor del estadístico LR en el backtesting de Q1 2026? Proporcionar el cálculo explícito. |
| 100 | Metodología | 2/5 | ¿Se ejecutó la prueba de Christoffersen (independencia de excepciones) sobre los datos de Q1 2026? Si no, ¿por qué se omitió siendo estándar en validación de VaR? |
| 101 | Metodología | 2/5 | ¿Qué análisis de estacionariedad se realizó sobre los retornos logarítmicos para verificar que la distribución empírica de 250 días es representativa del futuro? Proporcionar pruebas ADF o KPSS. |
| 102 | Metodología | 2/5 | ¿Se evaluaron métodos alternativos (GARCH, EVT, Monte Carlo) antes de elegir simulación histórica? Si no, ¿cuál es la justificación de esta elección para una cartera de negociación con horizonte de 1 día? |
| 103 | Metodología | 2/5 | ¿Cómo se monitorea el riesgo de eventos sin precedente en la ventana de estimación? ¿Existe un procedimiento documentado para detectar y actuar ante cambios de régimen no capturados por el modelo? |
| 104 | Metodología | 2/5 | ¿Se realizó análisis de sensibilidad del VaR respecto a cambios en la ventana, el nivel de confianza o la definición de retornos? Proporcionar gráficos o tablas de sensibilidad. |
| 105 | Metodología | 2/5 | ¿Cuáles fueron los p-valores y estadísticos LR de la prueba de Kupiec en el backtesting de 2026 Q1? ¿Están dentro del intervalo de aceptación al 95% de confianza? |
| 106 | Metodología | 2/5 | ¿Se ejecutó la prueba de Christoffersen (independencia de excedencias) en el backtesting? Si no, ¿por qué se omitió siendo estándar en la industria? |
| 107 | Metodología | 2/5 | ¿Cuáles fueron los eventos de mercado o factores de riesgo que generaron las 4 excepciones observadas en 2026 Q1? ¿Se analizaron individualmente? |
| 108 | Metodología | 2/5 | ¿Qué metodologías alternativas (EWMA, modelos de colas gruesas, Expected Shortfall) se evaluaron antes de elegir simulación histórica? ¿Con qué criterios se descartaron? |
| 109 | Metodología | 2/5 | ¿Se verificó la estacionariedad de la distribución de retornos en la ventana de 250 días? ¿Hay evidencia de cambios de régimen entre el período de estimación y el de validación? |
| 110 | Metodología | 2/5 | ¿Cuál es el intervalo de confianza exacto de Kupiec para 62 observaciones al 99% de confianza? ¿4 excepciones (6.45%) está dentro o fuera de ese intervalo? |
| 111 | Metodología | 2/5 | ¿Se realizó análisis de sensibilidad variando la ventana de estimación (ej. 200, 300, 400 días) para validar la robustez de la elección de 250 días? |
| 112 | Metodología | 2/5 | ¿Se ejecutó realmente la función `backtesting_kupiec()` en 2026 Q1? ¿Existe un log de ejecución, datos de entrada (retornos diarios), y output completo (estadístico LR, p-valor)? |
| 113 | Metodología | 2/5 | ¿Por qué se eligió simulación histórica frente a métodos paramétricos, Monte Carlo o GARCH? ¿Se realizó un análisis comparativo de métodos? |
| 114 | Metodología | 2/5 | ¿Se verificó la estacionariedad de los retornos en la ventana de 250 días? ¿Existen contrastes ADF, KPSS o análisis de cambios de régimen? |
| 115 | Metodología | 2/5 | ¿Por qué no se implementa el test de Christoffersen (independencia de excepciones) además de Kupiec? ¿Se descartó deliberadamente o se omitió? |
| 116 | Metodología | 2/5 | ¿Cuál es la definición operativa de excedencia utilizada en el backtesting? (¿Pérdida realizada > VaR estimado? ¿Incluye comisiones? ¿Tratamiento de faltantes?) |
| 117 | Metodología | 2/5 | ¿Se realizó análisis de sensibilidad del modelo a cambios en la ventana (p.ej., 200, 250, 300 días) o en el nivel de confianza (p.ej., 95%, 99%, 99.5%)? |
| 118 | Metodología | 2/5 | ¿Cuáles fueron los resultados de los contrastes previos que justificaron la elección de 250 días? (Número de excepciones, p-valores, fechas de esos análisis.) |
| 119 | Metodología | 2/5 | ¿Cuál es el valor exacto del estadístico LR y el p-valor reportado por `backtesting_kupiec()` en Q1 2026? Proporcionar la salida numérica completa de la función. |
| 120 | Metodología | 2/5 | ¿Cuáles fueron los 4 eventos de mercado que causaron las excepciones observadas? ¿Ocurrieron en fechas próximas (clustering) o distribuidas a lo largo del trimestre? |
| 121 | Metodología | 2/5 | ¿Se realizó el backtesting sobre P&L hipotético (cartera congelada) o P&L real? ¿Se documentó el tratamiento de días con mercados cerrados o datos incompletos? |
| 122 | Metodología | 2/5 | ¿Se ejecutó un análisis de sensibilidad de la ventana de 250 días? ¿Qué longitudes alternativas se probaron y por qué se descartaron? |
| 123 | Metodología | 2/5 | ¿Se verificó que los retornos logarítmicos cumplen los supuestos de estacionariedad e independencia requeridos por la simulación histórica? |
| 124 | Metodología | 2/5 | ¿Existe un plan de backtesting para Q2 2026 y trimestres posteriores, o fue un ejercicio puntual? ¿Con qué frecuencia se ejecuta el backtesting? |
| 125 | Metodología | 2/5 | ¿Se documentó la potencia estadística de la prueba de Kupiec con n=62 observaciones? ¿Cuál es el tamaño de efecto mínimo que la prueba puede detectar? |
| 126 | Metodología | 2/5 | ¿Qué contrastes previos de Kupiec se realizaron para justificar la elección de 250 días? ¿Cuáles fueron los p-valores y los intervalos de confianza para ventanas de 200, 250, 300, 500 días? |
| 127 | Metodología | 2/5 | ¿Se realizó análisis de sensibilidad documentado sobre los parámetros clave (ventana, nivel de confianza, horizonte)? ¿Cómo varía el VaR estimado y el número de excepciones esperadas si se cambian estos parámetros? |
| 128 | Metodología | 2/5 | ¿Se realizó análisis de escenarios sobre los inputs (composición de cartera, volatilidad de factores, correlaciones)? ¿Cómo se comportaría el modelo bajo volatilidad extrema o cambios de régimen? |
| 129 | Metodología | 2/5 | ¿Se verificaron los supuestos de la simulación histórica (estacionariedad, normalidad, independencia, homocedasticidad) de los retornos en la ventana de 250 días? ¿Cuáles fueron los p-valores de esos contrastes? |
| 130 | Metodología | 2/5 | ¿Se analizaron individualmente las 4 excepciones observadas en Q1 2026? ¿Qué eventos de mercado las causaron? ¿Eran predecibles o fueron eventos de cola sin precedente? |
| 131 | Metodología | 2/5 | ¿Se declaró explícitamente la potencia estadística de la prueba de Kupiec con 62 observaciones? ¿Cuál es la probabilidad de detectar un modelo deficiente con este tamaño muestral? |
| 132 | Metodología | 2/5 | ¿Se comparó el modelo VaR de simulación histórica con alternativas (p.ej., modelos paramétricos, GARCH, Montecarlo)? ¿Por qué se descartaron esas alternativas? |
| 133 | Metodología | 2/5 | ¿Cuál es el valor exacto del estadístico LR y el p-valor de la prueba de Kupiec para Q1 2026? ¿Cuál es el intervalo de confianza al 95% para el número de excepciones esperadas bajo H0? |
| 134 | Metodología | 2/5 | ¿Existe un log de ejecución de `backtesting_kupiec()` con timestamp, usuario y parámetros utilizados? ¿Cuándo se ejecutó exactamente? |
| 135 | Metodología | 2/5 | ¿Cuáles fueron los p-valores de las pruebas de Kupiec con ventanas de 100, 150, 200, 300 y 400 días que justificaron la elección de 250 días? ¿Se documentan esos análisis? |
| 136 | Metodología | 2/5 | ¿A qué comité o proceso de decisión se reportan los resultados del backtesting? ¿Existe un registro de decisiones tomadas (o no tomadas) basadas en estos resultados? |
| 137 | Metodología | 2/5 | ¿Se ha verificado estacionariedad de los retornos logarítmicos en la ventana de 250 días? ¿Hay test de Augmented Dickey-Fuller u otro test de raíz unitaria documentado? |
| 138 | Metodología | 2/5 | ¿Por qué se eligió simulación histórica sobre GARCH, EVT o simulación de Montecarlo? ¿Se evaluaron alternativas? |
| 139 | Metodología | 2/5 | ¿Cuál es la tasa de excepciones esperada bajo H0 para 62 días de negociación al 99% de confianza? ¿Cómo se interpreta que 4 excepciones (6.45%) sea «compatible» con esa expectativa? |
| 140 | Gobierno | 2/5 | ¿El modelo VaR Drift está efectivamente en producción o es un fixture de prueba? Los documentos declaran ser sintéticos; se requiere confirmación de estado real. |
| 141 | Gobierno | 2/5 | ¿Existe acta formal de asignación de tiering para este modelo? Incluir: fecha, firmantes, justificación de la clasificación asignada, y nivel de tiering (Tier 1/2/3). |
| 142 | Gobierno | 2/5 | ¿En qué fecha se realizó la última revisión/actualización del tiering? Proporcionar acta de revisión con resultado y cambios aplicados. |
| 143 | Gobierno | 2/5 | ¿El modelo está registrado en el inventario oficial de modelos de riesgo? Proporcionar referencia o extracto del inventario corporativo (herramienta GRC) que muestre tiering vigente. |
| 144 | Gobierno | 2/5 | ¿Quién es el propietario del modelo y quién es responsable de mantener el tiering actualizado? Incluir estructura de gobierno y frecuencia de revisión. |
| 145 | Implementación | 2/5 | ¿Existen correos de aprobación formal del Comité de Riesgos para los parámetros (ventana=250, confianza=99%) y para el paso a producción de calcula_var.py? Si existen, ¿autorizan explícitamente los valores que el código implementa (ventana=500, confianza=0.95)? |
| 146 | Implementación | 2/5 | ¿Por qué el código implementa ventana=500 y confianza=0.95 si el manual fija 250 y 99%? ¿Fue una decisión posterior documentada y aprobada, o es un code drift no controlado? |
| 147 | Implementación | 2/5 | ¿Dónde está la implementación de backtesting_kupiec() mencionada en el manual §3? ¿Se ejecutó el backtesting Kupiec referenciado en contexto inter-ámbito (Q1 2026)? ¿Existen logs o reportes de esa ejecución? |
| 148 | Implementación | 2/5 | ¿Por qué retornos_diarios() usa diferencia relativa simple en lugar de logarítmica? ¿Fue una desviación justificada y aprobada, o un error de implementación? |
| 149 | Implementación | 2/5 | ¿Existe documentación de UAT (User Acceptance Testing) que valide que calcula_var.py implementa correctamente el manual metodológico? ¿Quién firmó esa validación y cuándo? |
| 150 | Implementación | 2/5 | ¿Se integran los resultados del VaR (y del backtesting, si existe) en algún comité de riesgos o en decisiones de gestión de cartera? ¿Existen actas o reportes que lo demuestren? |
| 151 | Implementación | 2/5 | ¿Cuál es la versión actual de calcula_var.py en producción? ¿Coincide con la proporcionada en el contexto, o ha habido cambios no documentados? |
| 152 | Implementación | 2/5 | ¿Los parámetros por defecto en el código (ventana=500, confianza=0.95) son intencionales o representan un cambio no documentado respecto a la especificación (250 días, 99%)? Si son intencionales, ¿existe aprobación formal del Comité de Riesgos para esta desviación? |
| 153 | Implementación | 2/5 | ¿Por qué el código implementa retornos simples en lugar de retornos logarítmicos como especifica el manual? ¿Se evaluó el impacto de esta diferencia en la estimación del VaR y en los resultados del backtesting? |
| 154 | Implementación | 2/5 | ¿Dónde está implementada la función `backtesting_kupiec()` mencionada en el manual? ¿Existe en otro fichero no proporcionado, o la documentación describe una funcionalidad no implementada? |
| 155 | Implementación | 2/5 | ¿Existen correos de aprobación, actas de comité o documentación de cambios que autoricen la desviación entre la especificación del manual y la implementación del código? |
| 156 | Implementación | 2/5 | ¿Se ejecutó alguna prueba UAT que validara la implementación contra la especificación del manual? Si existe, ¿cuáles fueron los resultados y cómo se resolvieron las discrepancias? |
| 157 | Implementación | 2/5 | ¿Existen logs o reportes de ejecución del backtesting Kupiec mencionado en el manual? ¿Cuáles fueron los resultados y en qué fecha se ejecutó? |
| 158 | Implementación | 2/5 | ¿La función `var_cartera()` suma las contribuciones de VaR por factor de forma aditiva? ¿Se justifica esta aproximación o se requiere un enfoque de correlación/covarianza? |
| 159 | Implementación | 2/5 | ¿Existe documentación de control de cambios que registre cuándo y por qué se modificaron los parámetros por defecto del código respecto a la especificación original? |
| 160 | Implementación | 2/5 | ¿Existe documentación de UAT que valide que calcula_var.py implementa correctamente la especificación del manual_VaR_drift.md? ¿Quién aprobó las desviaciones en ventana (250 vs 500), confianza (99% vs 95%) y tipo de retorno (logarítmico vs simple)? |
| 161 | Implementación | 2/5 | ¿Se ejecutó el backtesting Kupiec sobre datos históricos reales antes de paso a producción? ¿Existen logs, reportes o correos que documenten los resultados y la conformidad de primera línea? |
| 162 | Implementación | 2/5 | ¿Cuál es la fecha de aprobación del paso a producción y quién la autorizó? ¿Se documentó en un correo o en un acta de comité? |
| 163 | Implementación | 2/5 | ¿Por qué se implementó retornos simples en lugar de logarítmicos? ¿Fue una decisión consciente o un error de implementación? ¿Está documentada en algún correo o en un changelog? |
| 164 | Implementación | 2/5 | ¿Se ejecutó algún test de coherencia entre el manual y el código (por ejemplo, comparar el VaR calculado con ambas especificaciones sobre los mismos datos)? |
| 165 | Implementación | 2/5 | ¿Existe documentación de cómo se tratan los días con datos incompletos o mercados cerrados en la ventana de 250 (o 500) observaciones? |
| 166 | Implementación | 2/5 | ¿Se realizó backtesting sobre P&L hipotético (cartera congelada) o sobre P&L real? El manual no lo especifica, pero es crítico para interpretar las excepciones. |

> ✍️ **Te toca:** depura antes de enviar. Algunas se responderán con un
> documento que ya existe y no llegó a `inputs/` — ésas no son hallazgos,
> son evidencia que faltó aportar.

## 5. Detalle por ámbito

### Documentación  ·  score 2.0

#### 🟠 [2/5] Verifica la existencia de control de cambios/versiones

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verificación de la existencia, suficiencia y claridad del control de cambios/versiones en el manual metodológico del modelo VaR Drift. Este control es crítico para la trazabilidad, la gobernanza de cambios y la auditoría de modelos financieros bajo marcos como Basilea III/IV e IFRS 9.

**Hallazgo.**

La documentación disponible (manual_VaR_drift.md y backtesting_2026Q1.md) NO contiene NINGUNA evidencia de un sistema de control de versiones, historial de cambios, o mecanismo de gobernanza de modificaciones. El manual metodológico carece completamente de: (1) número de versión o fecha de vigencia, (2) tabla de cambios que registre qué se modificó, cuándo, por quién y por qué, (3) aprobaciones documentadas de cambios, (4) trazabilidad de decisiones que llevaron a los parámetros actuales (ej: por qué 250 días y no otra ventana). Aunque el manual menciona que la ventana de 250 días se fijó tras comprobar criterios de Kupiec, NO hay registro de cuándo se tomó esa decisión, quién la autorizó, o si ha sido revisada desde entonces. Esto es una brecha crítica: sin control de versiones, es imposible auditar si el modelo que se ejecuta hoy es el que fue aprobado, si los cambios fueron autorizados, o si existe trazabilidad de la evolución del modelo. Para cumplimiento regulatorio (SR 11-7, SS3/17), el control de cambios es obligatorio. El puntaje es 2 porque existe documentación del modelo, pero el control de versiones está COMPLETAMENTE AUSENTE. Para alcanzar 3 se requeriría: número de versión, fecha de vigencia, y al menos un registro de cambios anterior. Para 4: aprobaciones documentadas y trazabilidad de decisiones clave.

**Evidencia citada.**

> manual_VaR_drift.md → No contiene número de versión, fecha de vigencia, tabla de cambios, o registro de aprobaciones. El documento comienza directamente con '# Manual metodológico — VaR de mercado (FIXTURE SINTÉTICO)' sin metadatos de control.
>
> manual_VaR_drift.md → 'El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un año de observaciones. Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec...' — se menciona la justificación de la decisión, pero NO hay registro de cuándo se tomó, quién la aprobó, o si ha sido revisada.
>
> backtesting_2026Q1.md → 'Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas contra el VaR estimado **sobre la ventana de 250 días establecida en el manual metodológico**.' — confirma que se usa el parámetro del manual, pero no hay evidencia de que el manual haya sido revisado o reaprobado antes de este trimestre.

**Preguntas al modelador.**

- [ ] ¿Existe un documento de control de versiones (changelog, historial de cambios) del manual metodológico? Si existe, ¿cuál es su nombre y ubicación?
- [ ] ¿Cuál es el número de versión actual del manual y cuál es su fecha de vigencia?
- [ ] ¿Quién aprobó la decisión de fijar la ventana en 250 días, en qué fecha, y mediante qué mecanismo (acta de comité, memorando, etc.)?
- [ ] ¿Cuándo fue la última revisión formal del manual metodológico y quién la autorizó?
- [ ] ¿Existe un proceso documentado de gobernanza de cambios que especifique quién puede modificar el manual, qué aprobaciones se requieren, y cómo se comunican los cambios a las áreas de riesgo y cumplimiento?
- [ ] ¿Se han realizado cambios al modelo (parámetros, metodología, backtesting) desde su aprobación inicial? Si es así, ¿están registrados y justificados?

**Recomendación.** Implementar inmediatamente un sistema de control de versiones para el manual metodológico que incluya: (1) número de versión y fecha de vigencia en la portada, (2) tabla de cambios con columnas: fecha, versión anterior, versión nueva, descripción del cambio, justificación, autor, aprobador, (3) firma digital o acta de aprobación del Comité de Riesgos para cada versión, (4) archivo de versiones anteriores con trazabilidad completa. Este control debe ser obligatorio antes de cualquier cambio a parámetros clave (ventana, nivel de confianza, horizonte). Recomendación de severidad ALTA: sin esto, el modelo no cumple con SR 11-7 (governance) ni con estándares de auditoría interna.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `c9bd3f40d462`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la inclusión del objetivo, usos y usuarios del modelo

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verificación de la existencia, suficiencia y claridad del Manual Metodológico respecto a objetivo, usos y usuarios del modelo VaR. Esta actividad es crítica porque un manual incompleto en estos aspectos impide que los usuarios comprendan el alcance legítimo del modelo y genera riesgo de mal uso o extrapolación fuera de su dominio de validez.

**Hallazgo.**

La documentación disponible presenta BRECHAS CRÍTICAS en la especificación de objetivo, usos y usuarios. El manual_VaR_drift.md contiene una sección de 'Alcance' que describe QUÉ CALCULA el modelo (VaR por simulación histórica), pero NO DECLARA EXPLÍCITAMENTE: (1) para qué decisiones se usa (¿límites de posición? ¿capital? ¿reporte regulatorio?), (2) quién es responsable de su uso (¿mesa de negociación? ¿comité de riesgos? ¿tesorería?), (3) qué decisiones NO debe informar. El manual menciona que 'parámetros no se admite su modificación sin aprobación del Comité de Riesgos', lo que implica un usuario (Comité), pero no lo define formalmente. El backtesting_2026Q1.md reporta resultados pero no vincula explícitamente el cumplimiento de Kupiec a una acción de gestión (¿qué ocurre si falla? ¿quién decide?). Esta ausencia de mapeo usuario-decisión-acción es una brecha de segundo nivel: el modelo puede ser técnicamente correcto pero operativamente huérfano. Para cumplimiento de IFRS 9 y marcos de validación estándar (SR 11-7), la documentación debe declarar explícitamente el propósito, los usuarios autorizados y los límites de aplicabilidad. La cobertura documental es parcial (no se proporcionó un manual operativo separado ni un documento de gobernanza), por lo que existe incertidumbre sobre si esa información existe en otros ficheros no incluidos en el contexto.

**Evidencia citada.**

> manual_VaR_drift.md → "El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el método de simulación histórica."
>
> manual_VaR_drift.md → "Los rendimientos de los factores de riesgo se calculan como retornos logarítmicos, por su propiedad de aditividad temporal, que es la que permite escalar el horizonte cuando procede."
>
> manual_VaR_drift.md → "Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato."
>
> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El modelo se comporta conforme a lo especificado. No se requiere recalibración en este trimestre."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el m»
> - «Los rendimientos de los factores de riesgo se calculan como retornos logarítmico»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el m»

**Preguntas al modelador.**

- [ ] ¿Existe un documento formal de 'Objetivo y Alcance' o 'Gobernanza del Modelo' que defina explícitamente: (a) para qué decisiones se usa el VaR (límites de negociación, capital regulatorio, IFRS 9, reporte interno), (b) quién es el usuario autorizado y quién es responsable de su interpretación, (c) qué decisiones NO debe informar?
- [ ] ¿El backtesting incluye pruebas de independencia de excepciones (Christoffersen) o análisis de cambios de régimen para verificar que la distribución empírica es estable, dado que el manual declara esta como una limitación crítica?
- [ ] ¿Existe un documento operativo separado que describa el proceso de ejecución paso a paso, incluyendo: frecuencia de cálculo, responsables, validación de datos de entrada, y escalada de excepciones?
- [ ] ¿Se ha documentado y verificado que el nivel de confianza del 99% y el horizonte de 1 día son apropiados para TODOS los usos declarados del modelo, o varían según el usuario (p.ej., 99% para límites de negociación pero 97.5% para capital regulatorio bajo FRTB)?
- [ ] ¿Existe control de versiones del manual (fecha de aprobación, versión, cambios respecto a versión anterior) que permita auditar la trazabilidad de cambios en parámetros o metodología?

**Recomendación.** 1. CRÍTICO: Crear una sección formal en el manual titulada 'Objetivo, Usuarios y Decisiones' que declare explícitamente: (a) propósito del modelo (ej: 'Cálculo de límites de riesgo de mercado para mesas de negociación'), (b) usuarios autorizados y sus responsabilidades, (c) decisiones que el modelo informa y decisiones que NO informa. 2. Ampliar el backtesting para incluir pruebas de independencia (Christoffersen) y análisis de estabilidad de la distribución, alineado con las limitaciones declaradas en el manual. 3. Crear un documento operativo separado con el proceso de ejecución, responsables, frecuencia y escalada. 4. Añadir control de versiones al manual (fecha, versión, registro de cambios) y vincular cada cambio a una aprobación del Comité de Riesgos. 5. Documentar la justificación de la elección de simulación histórica (por qué no paramétrico o Monte Carlo) y citar literatura técnica que la sustente para carteras de negociación.

<sub>cobertura documental 100.0% · RAG VaR (5 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `2bd2fc621b9c`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la existencia de control de cambios/versiones

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificación de la existencia, suficiencia y claridad del control de cambios/versiones en la documentación del modelo VaR Drift. Este control es crítico para la trazabilidad, auditoría y gobernanza de cambios en modelos de riesgo regulados.

**Hallazgo.**

La documentación disponible (manual_VaR_drift.md y backtesting_2026Q1.md) NO CONTIENE NINGUNA EVIDENCIA de control de versiones, historial de cambios, fechas de aprobación, autores, o mecanismo de trazabilidad de modificaciones. El manual metodológico no incluye número de versión, fecha de emisión, fecha de última revisión, ni registro de cambios. El informe de backtesting tampoco declara contra qué versión del manual se ejecutó el contraste, lo que impide verificar si el backtesting validó la especificación vigente o una anterior. Esto viola el principio de trazabilidad exigido en marcos como SR 11-7 (OCC) y SS 3/17 (Banco de España), que requieren documentación versionada y auditable de modelos de riesgo. El riesgo es doble: (1) imposibilidad de reconstruir qué versión del modelo fue aprobada y cuándo, (2) incapacidad de auditar si los cambios fueron autorizados y documentados. Para alcanzar nivel 3 se requiere: número de versión explícito en cada documento, fecha de emisión y última revisión, tabla de cambios con fecha/autor/descripción/aprobador, y referencia cruzada en el informe de backtesting a la versión del manual contra la que se ejecutó. La cobertura documental es completa (100% de documentos procesados), por lo que esta ausencia es un hallazgo real, no una limitación de alcance.

**Evidencia citada.**

> manual_VaR_drift.md → "# Manual metodológico — VaR de mercado (FIXTURE SINTÉTICO)" [sin número de versión, sin fecha, sin historial de cambios]
>
> manual_VaR_drift.md → "## 1. Alcance\nEl modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el método de **simulación histórica**." [sin declaración de cuándo se fijó esta especificación ni quién la aprobó]
>
> backtesting_2026Q1.md → "# Informe de seguimiento — VaR de mercado, 2026 Q1 (FIXTURE SINTÉTICO)" [sin referencia a versión del manual contra la que se ejecutó el backtesting]
>
> backtesting_2026Q1.md → "Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas contra el VaR estimado **sobre la ventana de 250 días establecida en el manual metodológico**." [no especifica si es la versión actual del manual o una anterior]

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 1. Alcance\nEl modelo calcula el Valor en Riesgo (VaR) de la cartera de negoc»
> - «## 2. Especificación del cálculo\nEl VaR se estima sobre una **ventana de 250 dí»

**Preguntas al modelador.**

- [ ] ¿Cuál es el número de versión actual del manual metodológico y cuándo fue emitido?
- [ ] ¿Existe un registro de cambios (changelog) que documente todas las modificaciones al manual desde su creación? Si existe, ¿por qué no está incluido en la documentación?
- [ ] ¿Quién aprobó la especificación actual (ventana de 250 días, confianza 99%, horizonte 1 día) y en qué fecha?
- [ ] ¿Contra qué versión específica del manual se ejecutó el backtesting de 2026 Q1? ¿Se conserva un registro de esa versión?
- [ ] ¿Existe un procedimiento documentado para autorizar cambios al manual? ¿Quién es responsable de mantener el control de versiones?
- [ ] ¿Se han realizado cambios al manual desde su emisión inicial? Si sí, ¿cuáles fueron y cuándo se aprobaron?

**Recomendación.** Implementar inmediatamente un sistema de control de versiones para toda documentación de modelos de riesgo. Cada documento debe incluir: (1) número de versión (ej. v1.2), (2) fecha de emisión y última revisión, (3) tabla de cambios con columnas: fecha | versión | descripción del cambio | autor | aprobador, (4) estado (borrador/aprobado/vigente/obsoleto). El informe de backtesting debe referenciar explícitamente la versión del manual contra la que se ejecutó (ej. 'Backtesting ejecutado contra manual_VaR_drift v1.0, emitido 2025-06-15'). Establecer un Comité de Cambios que apruebe por escrito toda modificación a parámetros, fórmulas o supuestos. Mantener un archivo histórico de versiones anteriores para auditoría. Esta práctica es obligatoria bajo SR 11-7 (OCC) y SS 3/17 (Banco de España).

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `cfc7fba419eb`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la existencia , suficiencia y claridad de la documentación

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificación de la existencia, suficiencia y claridad de la documentación del modelo VaR Drift. Esta actividad es crítica porque la documentación es el primer control de segunda línea: sin ella no hay trazabilidad, reproducibilidad ni base para auditar decisiones metodológicas.

**Hallazgo.**

La documentación presenta BRECHAS CRÍTICAS que impiden validar la suficiencia y claridad del modelo. Aunque existen un manual metodológico y un informe de backtesting, ambos carecen de elementos esenciales para una documentación de producción: (1) NO hay control de versiones, fecha de aprobación ni identificación de propietario del modelo; (2) el manual metodológico NO especifica el objetivo de negocio, usuarios finales ni casos de uso explícitos (solo dice «calcula el VaR»); (3) el informe de backtesting NO incluye metadatos de ejecución (fecha, usuario, entorno, datos utilizados, versión del código); (4) NO hay trazabilidad entre el manual (que especifica 250 días) y la ejecución (no se cita qué script se ejecutó ni se valida que use exactamente esa ventana); (5) NO existe documentación operativa paso a paso (quién ejecuta, cuándo, con qué datos, dónde se almacenan resultados, quién revisa); (6) el manual declara limitaciones pero NO especifica cómo se monitorean ni qué acciones se disparan si se violan (ej: si la distribución histórica deja de ser representativa). Para alcanzar nivel 3 se requiere: control de versiones explícito, manual operativo con procedimiento de ejecución, trazabilidad código-manual, y matriz de responsabilidades. Para nivel 4 se añadiría: justificación de por qué se descartaron alternativas (ej: por qué simulación histórica y no Monte Carlo), y evidencia de que el backtesting se ejecutó con datos reales y se reportó a comité.

**Evidencia citada.**

> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones. Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."
>
> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «El VaR se estima sobre una ventana de 250 días hábiles»
> - «Se observaron 4 excepciones en 62 días de negociación»

**Preguntas al modelador.**

- [ ] ¿Existe un documento de control de versiones (fecha de creación, versión, aprobador, fecha de aprobación) del manual metodológico y del informe de backtesting?
- [ ] ¿Cuál es el nombre exacto, versión y fecha de ejecución del script `backtesting_kupiec()` que se ejecutó para generar el informe 2026Q1? ¿Se puede reproducir con los mismos datos?
- [ ] ¿El código de `backtesting_kupiec()` implementa exactamente los parámetros del manual (ventana 250 días, confianza 99%, horizonte 1 día)? ¿Hay un test unitario que valide esto?
- [ ] ¿Quién es el propietario del modelo (área, persona, comité) y quién autoriza cambios en parámetros? ¿Se documentó la aprobación inicial del manual?
- [ ] ¿Existe un manual operativo que describa: quién ejecuta el backtesting, con qué frecuencia, sobre qué datos, dónde se almacenan resultados, quién revisa, a quién se reporta?
- [ ] ¿Cómo se monitorea la limitación declarada (distribución histórica representativa del futuro)? ¿Qué indicadores se usan y qué acciones se disparan si se viola?
- [ ] ¿Por qué se eligió simulación histórica sobre Monte Carlo o GARCH? ¿Se evaluaron alternativas y se documentó el descarte?
- [ ] ¿Por qué es suficiente Kupiec para backtesting? ¿Se consideró Christoffersen (independencia) o López (cobertura condicional)?
- [ ] ¿Cuál fue el criterio para decidir que 4 excepciones en 62 días (6.45%) justifican NO recalibrar? ¿Se presentó esta decisión al Comité de Riesgos como requiere el manual?

**Recomendación.** Antes de cualquier uso en producción, el modelo requiere: (1) Crear un documento de control de versiones (portada con fecha, versión, propietario, aprobador, fecha de aprobación, historial de cambios) para manual y backtesting; (2) Redactar un manual operativo que incluya: procedimiento paso a paso de ejecución, identificación de datos de entrada (fuente, formato, período), parámetros de ejecución (ventana, confianza, horizonte), responsables (quién ejecuta, quién revisa, quién reporta), frecuencia, criterios de decisión (cuándo recalibrar, cuándo escalar a comité), y trazabilidad de versiones de código; (3) Documentar la justificación metodológica: por qué simulación histórica (comparación explícita con alternativas descartadas), por qué 250 días (análisis de sensibilidad de ventana), por qué Kupiec es suficiente (o añadir Christoffersen y López si se requiere); (4) Especificar el monitoreo de limitaciones: indicadores de representatividad de la distribución histórica, frecuencia de revisión, umbrales de alerta, acciones correctivas; (5) Validar trazabilidad código-manual: ejecutar el script con parámetros del manual y verificar que produce exactamente los resultados reportados; (6) Documentar la decisión de no recalibrar: acta de comité, criterios aplicados, fecha, firmantes.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `6737a07580a5`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la coherencia del manual de implementación con el manual métodolocios

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificar la coherencia entre el manual metodológico y el manual operativo (o de implementación) del modelo VaR Drift, incluyendo la consistencia de parámetros, procesos de ejecución y backtesting. Esta coherencia es crítica para asegurar que lo documentado se ejecuta efectivamente y que los resultados de seguimiento son comparables con la especificación.

**Hallazgo.**

La evaluación revela brechas CRÍTICAS que impiden validar la coherencia entre documentación y ejecución. Aunque el manual metodológico especifica claramente una ventana de 250 días hábiles, nivel de confianza del 99%, retornos logarítmicos y la función `backtesting_kupiec()`, el contexto disponible NO CONTIENE el manual operativo (de implementación) ni el código fuente que ejecuta el modelo. Sin acceso al script de cálculo de VaR (`calcula_var.py` o equivalente) y al script de backtesting (`backtesting_kupiec()` implementado), es imposible verificar si los parámetros documentados coinciden con los codificados, si la ventana se aplica correctamente, o si el backtesting se ejecuta conforme se describe. El informe de seguimiento (backtesting_2026Q1.md) afirma que el contraste se realizó «sobre la ventana de 250 días establecida en el manual metodológico» y que se usó la función `backtesting_kupiec()`, pero no proporciona: (1) logs de ejecución que demuestren que el script corrió con esos parámetros, (2) datos de entrada y salida del backtesting, (3) evidencia de que los 62 días de negociación y las 4 excepciones observadas corresponden a la ventana y nivel de confianza especificados, o (4) el código que implementa la función. Además, falta completamente: control de versiones en ambos documentos, trazabilidad de cambios, fecha de última revisión, aprobación del Comité de Riesgos, y documentación del proceso operativo paso a paso (cómo se obtienen los datos, cómo se calculan los retornos, cómo se ejecuta el backtesting, quién lo valida, con qué frecuencia). La ausencia del manual operativo es una brecha estructural: un validador de segunda línea no puede certificar coherencia entre documentación y ejecución si no tiene acceso a la descripción de cómo se ejecuta. Para alcanzar nivel 3 se requiere: (a) manual operativo completo con pasos de ejecución, (b) código fuente anotado, (c) logs de ejecución del backtesting con parámetros y resultados, (d) control de versiones en ambos manuales. Para nivel 4 se añadiría: justificación de por qué se eligió Kupiec y no Christoffersen, evidencia de que se revisó la adecuación de la ventana de 250 días en este trimestre, y trazabilidad de decisiones del Comité.

**Evidencia citada.**

> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones. Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "El nivel de confianza es del 99 % y el horizonte de mantenimiento es de 1 día. Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos."
>
> manual_VaR_drift.md → "Los rendimientos de los factores de riesgo se calculan como retornos logarítmicos, por su propiedad de aditividad temporal."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> backtesting_2026Q1.md → "Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas contra el VaR estimado sobre la ventana de 250 días establecida en el manual metodológico."
>
> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «El nivel de confianza es del 99 % y el horizonte de mantenimiento es de 1 día. A»
> - «Los rendimientos de los factores de riesgo se calculan como retornos logarítmico»
> - «Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas cont»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «El VaR se estima sobre una ventana de 250 días hábiles»
> - «Se observaron 4 excepciones en 62 días de negociación»

**Preguntas al modelador.**

- [ ] ¿Existe un manual operativo (de implementación) que describa paso a paso cómo se ejecuta el cálculo de VaR y el backtesting? Si existe, ¿cuál es su versión actual y fecha de última revisión?
- [ ] ¿Cuál es el código fuente que implementa la función `backtesting_kupiec()`? ¿Está anotado y disponible para auditoría?
- [ ] ¿Existen logs de ejecución del backtesting de 2026 Q1 que muestren: (a) fecha y hora de ejecución, (b) parámetros utilizados (ventana, nivel de confianza, número de observaciones), (c) datos de entrada (serie de retornos), (d) resultados intermedios (VaR estimado por día), (e) excepciones identificadas con fechas?
- [ ] ¿Cómo se obtienen los datos de entrada (precios, retornos)? ¿Existe un proceso documentado de validación de calidad de datos antes de alimentar el modelo?
- [ ] ¿Se ejecutó en 2026 Q1 una revisión de la adecuación de la ventana de 250 días conforme al procedimiento descrito en el manual (contraste contra intervalo de Kupiec)? ¿Cuáles fueron los resultados?
- [ ] ¿Quién ejecuta el backtesting, quién lo revisa, y cuál es el proceso de escalamiento si se detectan excepciones fuera del intervalo de Kupiec?
- [ ] ¿Existe control de versiones (Git, SharePoint con historial, o similar) de ambos manuales? ¿Cuáles son las versiones vigentes y cuándo se aprobaron por última vez?
- [ ] ¿Por qué se eligió Kupiec y no Christoffersen? ¿Se consideró la prueba de independencia de López o Berkowitz?
- [ ] ¿Cómo se reconcilian los 62 días de negociación reportados en el backtesting con la ventana de 250 días de estimación? ¿Se trata de 62 días de contraste sobre un modelo estimado con 250 días previos?

**Recomendación.** Acción inmediata: (1) Proporcionar el manual operativo completo con control de versiones, fechas de aprobación y descripción paso a paso del proceso de cálculo y backtesting. (2) Proporcionar el código fuente de `backtesting_kupiec()` y de la función de cálculo de VaR, anotado y con trazabilidad a la especificación del manual metodológico. (3) Proporcionar logs de ejecución del backtesting de 2026 Q1 con parámetros, datos de entrada, VaR diarios, excepciones y resultados del estadístico LR. (4) Documentar el proceso de validación de datos de entrada (precios, retornos) y el procedimiento de escalamiento ante excepciones. (5) Añadir a ambos manuales: número de versión, fecha de última revisión, fecha de próxima revisión, y firma de aprobación del Comité de Riesgos. (6) Realizar un análisis de sensibilidad documentado sobre la ventana de 250 días (comparar contra 200, 300 días) y reportar los resultados del intervalo de Kupiec para cada caso, justificando la elección final. Sin estos elementos, no es posible certificar que la documentación y la ejecución son coherentes, ni que el backtesting es verificable y reproducible.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `4b0ba81c27ae`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificación de la existencia, suficiencia y claridad de la documentación de implementación y calidad de datos del modelo VaR Drift. Esta actividad es crítica porque la documentación es el único medio de comunicación entre el diseño del modelo y su ejecución operativa, y su ausencia o incompletitud invalida la trazabilidad y la auditabilidad del modelo.

**Hallazgo.**

La documentación disponible presenta BRECHAS CRÍTICAS que impiden validar la suficiencia y claridad del manual de implementación. Aunque existen dos documentos (manual_VaR_drift.md y backtesting_2026Q1.md), ambos son explícitamente FIXTURES SINTÉTICOS fabricados para pruebas, no documentación de un modelo en producción. El manual metodológico contiene especificación del cálculo (ventana de 250 días, nivel 99%, retornos logarítmicos) y menciona backtesting con Kupiec, pero CARECE de: (1) manual operativo que describa paso a paso la ejecución (quién ejecuta, cuándo, con qué datos, qué validaciones previas se aplican); (2) especificación de calidad de datos (criterios de completitud, tratamiento de faltantes, validación de fuentes, reconciliación); (3) control de versiones y trazabilidad de cambios; (4) definición explícita de objetivo, usuarios y usos del modelo; (5) descripción de la cadena de datos desde fuente hasta cálculo; (6) documentación de la ejecución real del backtesting (logs, fechas, datos utilizados, decisiones tomadas). El informe de backtesting (backtesting_2026Q1.md) reporta resultados (4 excepciones en 62 días) pero NO PROPORCIONA EVIDENCIA DE EJECUCIÓN: no hay logs, no hay datos de entrada, no hay trazabilidad de qué función se ejecutó, cuándo, con qué parámetros. La mención de Kupiec en el manual no se verifica contra la implementación real. Para alcanzar puntaje 3 se requiere: (a) manual operativo completo con flujo de datos, validaciones y responsabilidades; (b) especificación documentada de criterios de calidad de datos; (c) evidencia de ejecución del backtesting (logs, datos, parámetros reales); (d) control de versiones. Para puntaje 4 se añadiría justificación de por qué se descartaron alternativas (ej: por qué Kupiec y no Christoffersen, por qué 250 días y no 500). La incertidumbre es ALTA porque la cobertura documental es parcial (solo dos documentos sintéticos) y no se ha accedido a scripts de ejecución, logs operativos, o manuales de calidad de datos que puedan existir fuera del contexto proporcionado.

**Evidencia citada.**

> manual_VaR_drift.md → "El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el método de simulación histórica."
>
> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones. Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> manual_VaR_drift.md → "Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad."
>
> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."
>
> backtesting_2026Q1.md → "Documento fabricado para probar el juez de código. Ver `LEEME.md`."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el m»
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «Documento fabricado para probar el juez de código. No describe ningún modelo rea»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «El VaR se estima sobre una ventana de 250 días hábiles»
> - «Documento fabricado para probar el juez de código. No describe ningún modelo rea»

**Preguntas al modelador.**

- [ ] ¿Existe un manual operativo (distinto del metodológico) que describa paso a paso el proceso de cálculo del VaR, incluyendo: fuentes de datos, validaciones previas, responsables, frecuencia de ejecución, y tratamiento de excepciones?
- [ ] ¿Existe documentación de especificación de calidad de datos que defina: criterios de completitud, tratamiento de faltantes, validación de precios, reconciliación con sistemas de origen, y auditoría de cambios?
- [ ] ¿Existe control de versiones del manual metodológico y del código? ¿Qué cambios se han realizado desde la implementación inicial, cuándo, y con qué aprobaciones?
- [ ] ¿Existe evidencia de ejecución real del backtesting (logs, datos de entrada, parámetros, fecha/hora de ejecución, usuario que ejecutó)? ¿Quién ejecuta el backtesting, con qué frecuencia, y a quién se reportan los resultados?
- [ ] ¿Por qué se eligió la prueba de Kupiec y no Christoffersen (que además verifica independencia de excepciones)? ¿Se descartó Christoffersen explícitamente, y si es así, por qué?
- [ ] ¿Existe análisis de las excepciones individuales observadas (las 4 excepciones en Q1 2026)? ¿Se documentó qué movimientos de mercado las causaron y si fueron eventos previsibles o sin precedente?
- [ ] ¿Se ha verificado que los retornos logarítmicos utilizados en el backtesting provienen de las mismas fuentes y con la misma metodología que los utilizados en la estimación del VaR?
- [ ] ¿Existe documentación de las limitaciones del modelo (simulación histórica no captura eventos sin precedente) y cómo se mitigan (ej: pruebas de estrés, límites de concentración)?
- [ ] ¿Cuál es el objetivo declarado del modelo, quiénes son los usuarios finales, y para qué decisiones se utiliza el VaR estimado (capital, límites de riesgo, reportes regulatorios)?
- [ ] ¿Existe evidencia de que el modelo ha sido aprobado por el Comité de Riesgos y de que cualquier cambio en parámetros (ventana, nivel de confianza) requiere esa aprobación?

**Recomendación.** CRÍTICO: Obtener y validar la documentación REAL del modelo (no fixtures sintéticos). Específicamente: (1) Manual operativo completo con flujo de datos, validaciones, responsables y frecuencias; (2) Especificación de calidad de datos con criterios de aceptación y tratamiento de excepciones; (3) Logs de ejecución del backtesting (últimos 4 trimestres mínimo) con parámetros, datos utilizados y decisiones tomadas; (4) Control de versiones del manual y código con trazabilidad de cambios; (5) Análisis de las 4 excepciones observadas en Q1 2026 con explicación de causas; (6) Justificación documentada de la elección de Kupiec sobre Christoffersen; (7) Evidencia de aprobación por Comité de Riesgos y de la cadena de autorización para cambios de parámetros. Sin esta documentación, el modelo no puede considerarse validado en términos de implementación y calidad de datos.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `162db15e82e5`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la existencia de control de cambios/versiones

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Evaluación de la existencia, suficiencia y claridad de la documentación de seguimiento y control de versiones del modelo VaR Drift. Este control es crítico para asegurar trazabilidad, reproducibilidad y cumplimiento regulatorio (SR 11-7, BCBS 457).

**Hallazgo.**

La documentación disponible presenta BRECHAS CRÍTICAS que impiden validar el cumplimiento de este control. Aunque el informe de backtesting menciona la ejecución de la prueba de Kupiec y el manual metodológico describe la especificación del modelo, FALTAN COMPLETAMENTE: (1) Control de versiones: ninguno de los dos documentos contiene número de versión, fecha de aprobación, historial de cambios, o identificación del autor/revisor. El manual_VaR_drift.md es un fixture sintético sin metadatos de producción. (2) Documentación operativa de ejecución: el informe de backtesting no describe el proceso paso a paso (quién ejecuta, cuándo, con qué datos, qué criterios de aceptación/rechazo, qué acciones se disparan si falla). (3) Monitoreo de calidad de datos: no hay evidencia de validación de datos de entrada, tratamiento de faltantes, o reconciliación con fuentes. (4) Trazabilidad de cambios: no existe registro de cuándo se modificó la ventana de 250 días, quién lo aprobó, o cómo se documentó el cambio. Para alcanzar nivel 3 se requiere: metadatos de versión en ambos documentos, procedimiento operativo detallado con responsables y frecuencia, y evidencia de ejecución real (logs, timestamps, firmas de control). Para nivel 4 se añadiría: justificación documentada de por qué se rechazaron otras ventanas, y evidencia de revisión periódica del control de cambios.

**Evidencia citada.**

> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones. Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> backtesting_2026Q1.md → "Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas contra el VaR estimado sobre la ventana de 250 días establecida en el manual metodológico. Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> manual_VaR_drift.md → "Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad."
>
> backtesting_2026Q1.md → "Documento fabricado para probar el juez de código. Ver LEEME.md."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas cont»
> - «Documento fabricado para probar el juez de código. No describe ningún modelo rea»
> - «Documento fabricado para probar el juez de código. Ver LEEME.md.»
> - «Documento fabricado para probar el juez de código. No describe ningún modelo rea»
> - «Documento fabricado para probar el juez de código. Ver LEEME.md.»

**Preguntas al modelador.**

- [ ] ¿Existe un manual metodológico de PRODUCCIÓN (no fixture) con número de versión, fecha de aprobación, y control de cambios documentado?
- [ ] ¿Quién es responsable de ejecutar el backtesting, con qué frecuencia, y cuál es el procedimiento operativo paso a paso (incluyendo validación de datos, criterios de aceptación, y escalamiento de excepciones)?
- [ ] ¿Existe un registro de cambios (changelog) que documente cuándo y por qué se modificó la ventana de 250 días, quién lo aprobó, y cómo se validó el impacto en el backtesting?
- [ ] ¿Se ejecuta el backtesting sobre datos reales de la cartera de negociación de la entidad, y existe evidencia de logs, timestamps y firmas de control de cada ejecución?
- [ ] ¿Existe un procedimiento de monitoreo de calidad de datos (validación de completitud, reconciliación con fuentes, tratamiento de faltantes) documentado y ejecutado antes de cada backtesting?
- [ ] ¿Se revisa periódicamente la idoneidad de la ventana de 250 días y se documenta esa revisión? ¿Cuál es la frecuencia y quién la autoriza?

**Recomendación.** ACCIÓN INMEDIATA: Proporcionar documentación de PRODUCCIÓN (no fixtures) que incluya: (1) Manual metodológico con control de versiones (número, fecha, autor, revisor, historial de cambios). (2) Procedimiento operativo de backtesting con responsables, frecuencia, criterios de aceptación/rechazo, y escalamiento de excepciones. (3) Evidencia de ejecución real: logs de backtesting con timestamps, datos de entrada validados, y firmas de control. (4) Registro de cambios documentando cualquier modificación a parámetros (ventana, nivel de confianza, horizonte) con justificación y aprobación. (5) Procedimiento de monitoreo de calidad de datos. Sin esta documentación, no es posible validar el cumplimiento regulatorio del control de versiones y seguimiento.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `0aa5197cfbd6`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la existencia, suficiencia y claridad de la documentación

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Evaluación de la existencia, suficiencia y claridad de la documentación de seguimiento del modelo VaR Drift. Esta actividad es crítica porque la documentación es el único medio de verificar que el modelo se ejecuta conforme a su especificación y que los controles se aplican efectivamente.

**Hallazgo.**

La documentación presenta BRECHAS CRÍTICAS que impiden validar la suficiencia y claridad del seguimiento. Aunque existen dos documentos (manual metodológico e informe de backtesting), ambos adolecen de deficiencias graves que invalidan su capacidad de demostrar cumplimiento real. El manual metodológico [manual_VaR_drift.md] describe la especificación teórica del modelo pero NO contiene un apartado operativo que detalle cómo se ejecuta el backtesting en la práctica: no especifica frecuencia de ejecución, responsables, criterios de escalada, o qué ocurre cuando se detectan excepciones fuera de banda. El informe de backtesting [backtesting_2026Q1.md] reporta resultados (4 excepciones en 62 días) pero carece de trazabilidad crítica: no cita el script ejecutado, no proporciona logs de ejecución, no documenta los datos de entrada (retornos reales vs. estimados), y no incluye el p-valor de Kupiec ni el intervalo de confianza esperado para validar que las 4 excepciones están realmente "dentro de la zona verde". La afirmación "compatible con el intervalo de la prueba de Kupiec al 99% de confianza" es una conclusión sin respaldo numérico. Además, el informe no aborda el monitoreo de calidad de datos (¿se verificó la integridad de los retornos logarítmicos? ¿hay faltantes? ¿se detectaron outliers?), ni documenta la cadena de custodia entre estimación y backtesting (¿se usaron exactamente los mismos retornos?). Para alcanzar el nivel 3 sería necesario: (1) un manual operativo que describa paso a paso la ejecución, frecuencia, responsables y escaladas; (2) un informe de backtesting que cite el script, incluya logs, proporcione el p-valor y el intervalo de Kupiec, y documente los datos de entrada; (3) evidencia de monitoreo de calidad de datos. La cobertura documental es parcial (no se proporcionó código de backtesting ni logs de ejecución), lo que genera incertidumbre sobre si el backtesting se ejecutó realmente o solo se documentó su intención.

**Evidencia citada.**

> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> backtesting_2026Q1.md → "Se observaron **4 excepciones** en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."
>
> manual_VaR_drift.md → "El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un año de observaciones."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."

**Preguntas al modelador.**

- [ ] ¿Cuál es el p-valor exacto de la prueba de Kupiec para las 4 excepciones observadas en 62 días, y cuál es el intervalo de confianza esperado al 99%? (Necesario para verificar la afirmación de compatibilidad.)
- [ ] ¿Existe un script ejecutable de `backtesting_kupiec()` con logs de ejecución, y cuáles fueron los datos de entrada exactos (fechas, número de observaciones, valores de retornos)?
- [ ] ¿Se ejecutó algún test de independencia de excepciones (Christoffersen) o solo se aplicó Kupiec? Si solo Kupiec, ¿por qué se descartó Christoffersen?
- [ ] ¿Existe un manual operativo separado que describa la frecuencia de ejecución del backtesting, responsables, criterios de escalada si se detectan excepciones fuera de banda, y qué cambios se han aplicado en trimestres anteriores?
- [ ] ¿Se documentó el monitoreo de calidad de datos (integridad, faltantes, outliers) antes de ejecutar el backtesting? ¿Qué criterios se usaron para validar los retornos logarítmicos?
- [ ] ¿Cuál es la evidencia de que los retornos usados en el backtesting son exactamente los mismos que se usaron en la estimación del VaR? (Hashes, logs de carga, o trazabilidad de datos.)

**Recomendación.** Elaborar un manual operativo de seguimiento que incluya: (1) descripción paso a paso del proceso de backtesting (frecuencia, responsables, herramientas, datos de entrada); (2) especificación de los criterios de validación de datos (integridad, faltantes, outliers); (3) plantilla de informe de backtesting que incluya obligatoriamente: p-valor de Kupiec, intervalo de confianza esperado, logs de ejecución, datos de entrada (fechas, número de observaciones), y comparación con trimestres anteriores; (4) matriz de escalada (qué hacer si excepciones > umbral); (5) evidencia de trazabilidad entre estimación y backtesting (ej. hash de datos, fecha de carga). Además, ejecutar el backtesting de 2026 Q1 nuevamente con documentación completa y proporcionar el p-valor numérico para validar la conclusión de compatibilidad con Kupiec.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `18f5df23a853`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Evaluación de la existencia, suficiencia y calidad de la documentación de seguimiento del modelo VaR Drift, incluyendo backtesting, monitoreo de datos y trazabilidad de ejecución. Este control es crítico para asegurar que el modelo se comporta conforme a especificación y que las decisiones de riesgo se basan en evidencia verificada.

**Hallazgo.**

La documentación presenta BRECHAS CRÍTICAS que impiden validar la suficiencia del seguimiento. Aunque existen dos documentos (manual metodológico e informe de backtesting Q1 2026), la evaluación revela deficiencias severas en tres áreas: (1) EJECUCIÓN NO VERIFICADA: el informe de backtesting afirma que se ejecutó `backtesting_kupiec()` pero no proporciona logs, timestamps, datos de entrada/salida, ni rastro de ejecución real — solo una conclusión narrativa. (2) MONITOREO DE CALIDAD DE DATOS AUSENTE: no existe documentación sobre cómo se validan los datos de entrada (retornos logarítmicos), tratamiento de faltantes, días de mercado cerrado, o criterios de exclusión — temas explícitamente mencionados en la literatura estándar como obligatorios en backtesting. (3) ANÁLISIS DE EXCEPCIONES INCOMPLETO: el informe menciona 4 excepciones en 62 días pero no proporciona análisis individual de cada una (qué evento de mercado las causó, si fueron predecibles, si revelan debilidades del modelo), lo que es práctica estándar en validación de VaR. Para alcanzar nivel 3 se requiere: (a) logs o evidencia de ejecución del script con datos, parámetros y resultados; (b) sección de calidad de datos en el manual operativo; (c) análisis narrativo de cada excedencia. La cobertura documental es parcial (solo 2 documentos sintéticos de fixture), lo que introduce incertidumbre sobre si existe documentación adicional no proporcionada.

**Evidencia citada.**

> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."
>
> manual_VaR_drift.md → "El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un año de observaciones."
>
> manual_VaR_drift.md → "El **nivel de confianza es del 99 %** y el horizonte de mantenimiento es de **1 día**."
>
> No se encontró evidencia en el contexto disponible de: (a) logs o scripts de ejecución del backtesting; (b) documentación de calidad de datos; (c) análisis individual de las 4 excepciones observadas; (d) tratamiento de días con datos incompletos o mercados cerrados; (e) pruebas de independencia (Christoffersen); (f) análisis de potencia estadística de la prueba.

**Preguntas al modelador.**

- [ ] ¿Existe un script o código fuente de `backtesting_kupiec()` que pueda ser auditado? ¿Dónde se almacena y bajo qué control de versiones?
- [ ] ¿Se ejecutó realmente el backtesting en Q1 2026? ¿Existen logs, timestamps o reportes de ejecución que demuestren cuándo, con qué datos y qué parámetros se corrió?
- [ ] ¿Cuál es el proceso de validación de datos de entrada (retornos logarítmicos)? ¿Cómo se tratan los días con mercados cerrados, datos faltantes o anomalías?
- [ ] ¿Se realizó análisis individual de las 4 excepciones observadas? ¿Qué eventos de mercado las causaron? ¿Revelan debilidades del modelo o son eventos extremos justificables?
- [ ] ¿Se ejecutaron pruebas de independencia (Christoffersen) o de magnitud (López) además de Kupiec? Si no, ¿por qué se descartaron?
- [ ] ¿Cuál es la potencia estadística de la prueba de Kupiec con 62 observaciones? ¿Se documentó este límite?
- [ ] ¿Existe un manual operativo separado que describa paso a paso cómo se ejecuta el backtesting, quién lo ejecuta, con qué frecuencia y a quién se reportan los resultados?
- [ ] ¿El informe de backtesting se presenta a algún comité de riesgos o de validación? ¿Hay evidencia de que los resultados se usan para tomar decisiones (recalibración, límites de riesgo, etc.)?
- [ ] ¿Se revisa periódicamente la justificación de la ventana de 250 días? ¿Existe un proceso documentado para evaluar si sigue siendo óptima?

**Recomendación.** CRÍTICA: (1) Proporcionar el código fuente de `backtesting_kupiec()` con control de versiones y documentación de cambios. (2) Generar un manual operativo que describa el proceso de ejecución del backtesting: frecuencia, responsables, fuentes de datos, validaciones previas, criterios de exclusión, y cómo se reportan resultados. (3) Documentar el proceso de validación de calidad de datos (retornos logarítmicos, tratamiento de faltantes, días cerrados). (4) Proporcionar logs o evidencia de ejecución real del backtesting Q1 2026 (timestamps, parámetros, datos de entrada/salida). (5) Realizar análisis individual de las 4 excepciones: qué evento de mercado las causó, si eran predecibles, qué revelan sobre el modelo. (6) Extender el backtesting para incluir pruebas de Christoffersen (independencia) y López (magnitud), o documentar explícitamente por qué se descartaron. (7) Documentar la potencia estadística de la prueba de Kupiec con la muestra disponible (62 días) y sus implicaciones para la conclusión. (8) Crear un registro de seguimiento trimestral que consolide resultados de backtesting, cambios en parámetros, decisiones del Comité de Riesgos y acciones correctivas.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a2ce4c5833a2`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Calidad de datos  ·  score 1.0

#### 🔴 [1/5] Verificar que no exista suficiencia de controles de calidad de datos (integridad)

*Control: El modelo deberá contar con controles de calidad de datos de primera linea sobre los resultados calculados (outliers, missing, duplicados, entre otros)*

**Qué evalúa.** Verificación de la existencia y suficiencia de controles de calidad de datos de primera línea (missing, duplicados, outliers, integridad referencial) sobre los resultados del cálculo de VaR. Este control es crítico para garantizar que las entradas y salidas del modelo sean confiables y que las excepciones detectadas en backtesting no sean artefactos de datos defectuosos.

**Hallazgo.**

No existe evidencia de ningún control de calidad de datos implementado, documentado o ejecutado. El manual metodológico (manual_VaR_drift.md) describe únicamente la especificación del cálculo de VaR, el backtesting con Kupiec, y limitaciones declaradas, pero NO menciona controles sobre missing values, duplicados, outliers, integridad referencial ni tratamiento de datos incompletos. El script _replica_virf.py no fue proporcionado en el contexto, por lo que no es posible verificar si existe implementación de código. La literatura de referencia recuperada menciona explícitamente que debe "documentar el tratamiento de los días con datos incompletos o mercados cerrados" y que "la explicación de cada excedencia observada es evidencia de validación tan relevante como el estadístico agregado", lo que implica que los datos subyacentes deben estar validados. Sin controles de calidad de datos, no es posible asegurar que: (1) las excepciones del backtesting reflejan riesgo real y no corrupción de datos, (2) los retornos logarítmicos se calculan sobre series completas y consistentes, (3) no hay duplicados que sesgen la distribución empírica. La ausencia de este control es una brecha crítica de primera línea que invalida la confiabilidad de todo el modelo. Para alcanzar puntaje 2 sería necesario: (a) un script de validación de datos (missing, duplicados, outliers con criterios explícitos, no solo Z-score), (b) documentación de cómo se tratan los días con mercados cerrados, (c) reportes de incidencias de calidad ejecutados periódicamente, (d) evidencia de que estos controles se ejecutan antes de cada cálculo de VaR.

**Evidencia citada.**

> manual_VaR_drift.md → "El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el método de simulación histórica." (no menciona controles de datos)
>
> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones." (no especifica tratamiento de datos incompletos o faltantes)
>
> manual_VaR_drift.md → "Los rendimientos de los factores de riesgo se calculan como retornos logarítmicos, por su propiedad de aditividad temporal" (no documenta validación de las series de entrada)
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato." (no aborda cómo se garantiza la integridad de esa distribución empírica)
>
> No se encontró evidencia de script _replica_virf.py o equivalente en el contexto disponible.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el m»
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «Los rendimientos de los factores de riesgo se calculan como retornos logarítmico»

**Preguntas al modelador.**

- [ ] ¿Existe un script de validación de datos (tipo _replica_virf.py o control_calidad_datos.py) que ejecute controles sobre missing values, duplicados y outliers antes de cada cálculo de VaR? Si existe, ¿cuál es su nombre y dónde se encuentra?
- [ ] ¿Cómo se tratan los días con mercados cerrados o datos incompletos en la ventana de 250 días hábiles? ¿Se excluyen, se interpolan, o se requiere que la ventana tenga exactamente 250 observaciones válidas?
- [ ] ¿Qué criterio se usa para detectar y tratar outliers? ¿Se aplica Z-score, IQR, o algún otro método? ¿Se documentan las decisiones de exclusión o ajuste?
- [ ] ¿Existen reportes periódicos (diarios, semanales, mensuales) que documenten incidencias de calidad de datos (missing, duplicados, valores fuera de rango)? ¿A quién se reportan y qué acciones se toman?
- [ ] ¿Se verifica la integridad referencial de los datos de entrada (p.ej., que los factores de riesgo correspondan a la cartera, que no haya desalineamientos de fechas entre series)?
- [ ] ¿Se ejecutan controles de calidad de datos ANTES de cada cálculo de VaR, o solo en la fase de implementación inicial?

**Recomendación.** Desarrollar e implementar un módulo de control de calidad de datos de primera línea que incluya: (1) detección y tratamiento documentado de missing values (clasificar como MCAR/MAR/MNAR y justificar estrategia de imputación o exclusión), (2) detección de duplicados con criterios explícitos (duplicados exactos, duplicados por fecha-factor), (3) detección de outliers con método justificado (no solo Z-score; considerar contexto de mercado), (4) validación de integridad referencial (alineación de fechas, correspondencia factor-cartera), (5) tratamiento explícito de días con mercados cerrados, (6) generación de reportes de incidencias ejecutados antes de cada cálculo de VaR, (7) documentación de todas estas decisiones en el manual metodológico con referencias a los scripts que las implementan. Este control debe ser ejecutado y auditado antes de que los datos lleguen al cálculo de VaR, no después.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a4e1305663e4`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🔴 [1/5] Verificar la actualización de los inputs

*Control: Revisión de la integridad y consistencias de los inputs*

**Qué evalúa.** Verificación de la integridad, consistencia y actualización de los inputs de datos que alimentan el modelo VaR. Este control es crítico porque datos defectuosos (missing, duplicados, outliers no tratados) invalidan cualquier cálculo posterior, independientemente de la solidez metodológica.

**Hallazgo.**

No existe evidencia de ningún control de calidad de datos implementado, documentado o ejecutado. El manual_VaR_drift.md describe la metodología de cálculo del VaR (ventana de 250 días, nivel de confianza 99%, retornos logarítmicos) pero NO menciona: (1) procedimientos de validación de inputs, (2) tratamiento de missing values, (3) detección y manejo de duplicados, (4) criterios para identificar y tratar outliers, (5) verificación de integridad referencial, (6) logs o reportes de incidencias de calidad de datos, (7) frecuencia y responsable de la actualización de inputs. El manual declara limitaciones del modelo (§4: «no captura eventos sin precedente») pero no documenta cómo se garantiza que los datos históricos de entrada son completos, consistentes y libres de errores. No se encontró el script _replica_virf.py ni ningún equivalente de control de datos. La ausencia de estos controles es crítica porque: (a) un modelo con backtesting Kupiec correcto pero datos contaminados produce resultados falsos con confianza estadística, (b) la regulación (SR 11-7, IFRS 9) exige documentación explícita de controles de calidad de datos como parte de la validación de modelos, (c) sin trazabilidad de incidencias de datos, no es posible auditar si las excepciones del backtesting se deben a cambios de régimen o a errores de entrada. Para alcanzar puntaje 2 sería necesario: (i) un documento que describa los controles de calidad (missing, duplicados, outliers, rango, tipo), (ii) un script ejecutable que implemente esos controles, (iii) al menos un reporte de ejecución mostrando qué incidencias se detectaron y cómo se resolvieron. La cobertura documental es parcial (solo manual metodológico, sin scripts de control ni reportes de ejecución), pero la ausencia es tan completa que no se puede atribuir a limitación de contexto: un modelo en producción debe tener estos artefactos.

**Evidencia citada.**

> manual_VaR_drift.md → "El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el método de simulación histórica."
>
> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones."
>
> manual_VaR_drift.md → "Los rendimientos de los factores de riesgo se calculan como retornos logarítmicos, por su propiedad de aditividad temporal."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."
>
> No se encontró evidencia de: (1) script _replica_virf.py o equivalente, (2) documentación de controles de missing values, duplicados, outliers, (3) reportes de incidencias de calidad de datos, (4) procedimientos de actualización de inputs, (5) responsables y frecuencias de validación de datos.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el m»
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «Los rendimientos de los factores de riesgo se calculan como retornos logarítmico»

**Preguntas al modelador.**

- [ ] ¿Existe un script o procedimiento documentado para validar la calidad de los datos históricos antes de cada cálculo de VaR? Si existe, ¿dónde está ubicado y cuál es su última ejecución?
- [ ] ¿Cómo se detectan y tratan los missing values en la serie de retornos? ¿Se excluyen observaciones, se interpolan, o se rechaza el cálculo si hay gaps?
- [ ] ¿Cuál es el criterio para identificar outliers en los retornos? ¿Se usa Z-score, IQR, o algún otro método? ¿Se documentan las decisiones de exclusión o ajuste?
- [ ] ¿Se verifica la ausencia de duplicados en los datos de entrada? ¿Existe un control de integridad referencial (ej: fechas únicas, sin saltos en días hábiles)?
- [ ] ¿Quién es responsable de actualizar los inputs (precios, retornos) y con qué frecuencia? ¿Existe un log de auditoría que registre cuándo se actualizaron y quién lo hizo?
- [ ] ¿Se han documentado incidencias de calidad de datos (errores detectados, correcciones aplicadas) desde la puesta en producción del modelo? ¿Cómo se registran y comunican?
- [ ] ¿El backtesting de Kupiec (§3) se ejecuta sobre datos que han pasado por estos controles de calidad, o se ejecuta sobre los datos brutos?
- [ ] ¿Se verifica que la ventana de 250 días hábiles no incluya períodos de mercados cerrados o datos incompletos? ¿Cómo se maneja el 31 de diciembre o festivos?

**Recomendación.** Desarrollar e implementar un módulo de control de calidad de datos (_replica_virf.py o equivalente) que incluya: (1) validación de completitud (detección de missing values con clasificación MCAR/MAR/MNAR y estrategia de tratamiento documentada), (2) detección de duplicados por fecha y factor de riesgo, (3) análisis de outliers con criterio explícito (ej: Z-score > 3 o IQR × 1.5) y decisión de exclusión/ajuste, (4) verificación de integridad referencial (secuencia de fechas, ausencia de gaps en días hábiles), (5) generación de reporte ejecutable que documente: qué incidencias se encontraron, cuántas observaciones se excluyeron/ajustaron, y justificación de cada decisión. Este reporte debe ejecutarse antes de cada cálculo de VaR y sus resultados deben ser revisados por segunda línea. Integrar los resultados del control en el backtesting: si hay exclusiones de datos, el intervalo de Kupiec debe recalcularse sobre la muestra efectivamente utilizada, no sobre la teórica de 250 días. Documentar en el manual (§5 nueva) el procedimiento de control de datos, responsables, frecuencia y criterios de escalamiento (ej: si se excluyen >5% de observaciones, rechazar el cálculo y alertar al Comité de Riesgos).

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `fc7dc6173bac`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🔴 [1/5] Control_01 — Valida que el manual describa origen, universo, variables, transformaciones y contrles; y que el…

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida que el manual describa origen, universo, variables, transformaciones y contrles; y que el script está alineado con el manual, identifica diferencia entre lo que el manual dice y lo que el script hace

**Hallazgo.**

Se detectan DIVERGENCIAS CRÍTICAS entre el manual metodológico y la implementación en código. El manual especifica explícitamente: (1) ventana de 250 días hábiles, (2) nivel de confianza del 99%, (3) retornos logarítmicos, (4) función backtesting_kupiec() implementada. El código implementado utiliza: (1) ventana por defecto de 500 días, (2) confianza por defecto del 95%, (3) retornos simples (diferencia relativa), (4) NO implementa backtesting_kupiec(). Adicionalmente, el código calcula VaR agregado por suma lineal de contribuciones por factor sin documentar supuestos de correlación o justificación metodológica. El manual declara que parámetros (ventana, confianza) son FIJOS y requieren aprobación del Comité de Riesgos; el código los expone como parámetros modificables en tiempo de ejecución sin control.

9 hallazgo(s) del control automático (4 critica, 3 moderada, 1 potencial, 1 baja), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Alinear parámetro default en función var_historico() a 250. Implementar validación que rechace valores distintos a 250 sin traza de aprobación del Comité de Riesgos. Cambiar default de confianza a 0.99 en función var_historico(). Eliminar capacidad de modificación en tiempo de ejecución o implementar control de cambios con aprobación documentada. Reemplazar línea en retornos_diarios(): cambiar de (precios[1:] - precios[:-1]) / precios[:-1] a np.log(precios[1:] / precios[:-1]). Validar impacto en backtesting histórico. Implementar función backtesting_kupiec(excepciones, n_observaciones, confianza=0.99) que calcule: (1) número esperado de excepciones bajo hipótesis nula, (2) intervalo de confianza de Kupiec, (3) estadístico LR = 2*ln(L1/L0), (4) p-valor. Documentar fórmulas exactas en manual. Documentar en manual: (1) supuesto de correlación asumido, (2) justificación de suma lineal vs. métodos alternativos (ej. matriz de covarianza), (3) validación empírica de supuesto. Considerar implementar agregación por matriz de correlación si datos lo justifican. Agregar validaciones: (1) precios > 0, (2) sin valores faltantes, (3) len(precios) >= ventana + 1. Documentar en manual sección 'Requisitos de datos de entrada'. Solicitar versión limpia del script. Verificar integridad del archivo fuente en repositorio de control de versiones. Documentar versión exacta (hash, rama, fecha) en evidencia de auditoría. Agregar sección 'Origen y extracción de datos' en manual: (1) fuente de precios, (2) frecuencia, (3) tratamiento de feriados/gaps, (4) controles de integridad aplicados. Documentar en manual: (1) controles compensatorios implementados, (2) frecuencia de stress testing, (3) escalada de excepciones de Kupiec, (4) revisión de supuestos ante cambios de régimen.

<sub>prompt `03c09f6780cb`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🔴 [1/5] Control_02 — Valida la unicidad Cliente por Cuenta en la base usada por el proceso

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad Cliente por Cuenta en la base usada por el proceso

**Hallazgo.**

La evidencia presentada contiene inconsistencias críticas entre la documentación metodológica y la implementación de código que impiden validar la conformidad del modelo. El manual declara explícitamente: ventana de 250 días hábiles, nivel de confianza del 99%, retornos logarítmicos, y función backtesting_kupiec(). Sin embargo, el código implementa: ventana por defecto de 500 días, confianza del 95%, retornos simples (no logarítmicos), y NO contiene la función backtesting_kupiec() declarada. Adicionalmente, el código presenta duplicación severa de funciones (var_historico y var_cartera repetidas 5 veces), indicativo de corrupción de datos o control de versiones deficiente. La función var_cartera suma linealmente contribuciones de factores sin considerar correlaciones, violando principios de agregación de riesgo.

8 hallazgo(s) del control automático (5 critica, 2 moderada, 1 potencial), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Alinear parámetro ventana en código a 250 días. Documentar y justificar cualquier desviación con aprobación del Comité de Riesgos conforme a manual sección 2. Corregir parámetro confianza a 0.99 en función var_historico(). Implementar validación que rechace ejecuciones con parámetros no autorizados. Reemplazar cálculo en retornos_diarios() por: np.log(precios[1:] / precios[:-1]). Validar que cambio no afecta backtesting histórico. Implementar función backtesting_kupiec(excepciones, n_observaciones, confianza=0.99) que calcule: LR = 2*[excepciones*ln(excepciones/(n*p)) + (n-excepciones)*ln((n-excepciones)/(n*(1-p)))]. Validar contra tablas críticas de Kupiec. Obtener versión limpia y auditada del código fuente desde repositorio oficial. Verificar integridad mediante hash criptográfico. Documentar cadena de custodia de la evidencia. Clarificar en manual si agregación es aditiva (asume correlación perfecta) o si debe implementarse matriz de correlaciones. Si es aditiva, documentar supuesto y limitación en sección 4 (Limitaciones declaradas). Añadir parámetro horizonte con valor por defecto 1 y validación que lance excepción si se intenta modificar sin flag de autorización documentado. Documentar framework complementario de stress testing y análisis de escenarios. Especificar frecuencia, metodología y escalada de excepciones.

<sub>prompt `e793504f9367`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🔴 [1/5] Control_03 — Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura

**Hallazgo.**

La evaluación se enfrenta a una desconexión crítica entre la documentación y el código. El manual especifica explícitamente: ventana de 250 días hábiles, nivel de confianza del 99%, horizonte de 1 día, retornos logarítmicos, y backtesting mediante Kupiec. El código implementado utiliza: ventana de 500 observaciones (parámetro por defecto), confianza del 95% (parámetro por defecto), retornos simples en lugar de logarítmicos, y NO contiene implementación alguna de backtesting Kupiec. Adicionalmente, el código suma linealmente contribuciones de factores sin considerar correlaciones, violando el principio de agregación de riesgos. La función `retornos_diarios()` implementa diferencias relativas simples, no logarítmicas como se requiere. El control solicitado (unicidad de FechaVencimiento por Cuenta+FechaApertura) no aparece en ninguna de las evidencias proporcionadas.

7 hallazgo(s) del control automático (5 critica, 2 moderada), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Modificar parámetro por defecto en `var_historico()` de ventana=500 a ventana=250. Documentar en código la justificación de Kupiec citada en el manual. Cambiar parámetro por defecto en `var_historico()` de confianza=0.95 a confianza=0.99. Implementar validación que rechace valores distintos de 0.99 sin aprobación del Comité de Riesgos. Reemplazar cálculo en `retornos_diarios()` por: `np.log(precios[1:] / precios[:-1])`. Validar que esta corrección no introduce cambios no documentados en la distribución empírica. Implementar función `backtesting_kupiec(excepciones, n, confianza=0.99)` que calcule: LR = 2*[excepciones*ln(excepciones/(n*(1-confianza))) + (n-excepciones)*ln((n-excepciones)/(n*confianza))]. Integrar en pipeline de validación diaria. Implementar agregación mediante matriz de varianza-covarianza: VaR_cartera = sqrt(w^T * Σ * w), donde Σ se estima sobre la misma ventana de 250 días. Documentar supuestos sobre estacionariedad de correlaciones. Aclarar si el control de unicidad es parte del modelo VaR o pertenece a un módulo de gestión de crédito (IFRS 9). Si es relevante para VaR, proporcionar especificación explícita y código de implementación. Verificar integridad del repositorio de código. Ejecutar `git log` y `git diff` para detectar cambios no documentados. Confirmar que la versión en producción coincide con la evidencia auditada.

<sub>prompt `194d799bea30`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🔴 [1/5] Control_04 — Valida la unicidad de Tasa de Interes por Cuenta

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad de Tasa de Interes por Cuenta

**Hallazgo.**

DESALINEACIÓN CRÍTICA entre documentación y código. El manual especifica: ventana de 250 días hábiles, confianza 99%, retornos logarítmicos, y backtesting Kupiec obligatorio. El código implementa: ventana por defecto de 500 días, confianza 95%, retornos simples (no logarítmicos), y NO contiene función backtesting_kupiec() declarada en sección 3. Adicionalmente, el código suma contribuciones de factores sin correlación (suma lineal), violando principios de agregación de riesgo. La evidencia de código contiene duplicaciones masivas que sugieren corrupción o manipulación del artefacto.

7 hallazgo(s) del control automático (7 critica), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Verificar con propietario del modelo si 500 es intencional o error de implementación. Si es intencional, requiere enmienda formal del manual y justificación de cambio de régimen. Alinear parámetro a 0.99 en código. Documentar si cambio fue deliberado y obtener aprobación formal del Comité de Riesgos. Reemplazar con: np.log(precios[1:] / precios[:-1]). Validar que cambio no afecte calibración histórica de excepciones Kupiec. Localizar implementación de backtesting_kupiec() en repositorio completo. Si no existe, desarrollarla conforme a Kupiec (1995) con intervalo de confianza incondicional. Validar contra López (1999) para independencia de excepciones. Implementar agregación mediante matriz de covarianza o cópula según especificación del modelo. Documentar supuesto de correlación en manual. Obtener versión limpia del código desde control de versiones (git). Verificar integridad de hash. Documentar cadena de custodia de evidencia. Aclarar si control solicitado corresponde a este modelo VaR de mercado. Si es aplicable, proporcionar: (a) especificación de regla de unicidad, (b) código de validación, (c) tabla de cuentas y tasas.

<sub>prompt `b34bc7cec88f`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Metodología  ·  score 2.0

#### 🟠 [2/5] Existencia de buenas prácticas en el enfoque metodológico

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Evaluación de la justificación metodológica del modelo VaR: verificación de que la elección del enfoque (simulación histórica), parámetros (ventana 250 días, confianza 99%) y controles (backtesting Kupiec) estén fundamentados en evidencia empírica y comparación con alternativas. Esta es la base para confiar en que el modelo es adecuado para la cartera y el horizonte de riesgo.

**Hallazgo.**

La documentación declara la metodología de simulación histórica y describe el backtesting con Kupiec, pero presenta BRECHAS CRÍTICAS en la justificación metodológica que impiden validar el cumplimiento de este control. (1) El manual afirma que la ventana de 250 días se fijó tras comprobar que ventanas inferiores producían excepciones fuera del intervalo de Kupiec, pero NO APORTA LOS DATOS, LOS CÁLCULOS NI LOS P-VALORES que respalden esa afirmación: es una declaración sin evidencia verificable. (2) No existe análisis de alternativas: no se justifica por qué simulación histórica y no modelos paramétricos (GARCH, EVT) o métodos de Monte Carlo, ni qué criterios se usaron para descartar otras opciones. (3) El backtesting de Q1 2026 reporta 4 excepciones en 62 días y afirma que están «dentro de la zona verde de Basilea», pero no proporciona el intervalo de confianza de Kupiec ni el p-valor del estadístico LR: sin esos números no puede verificarse que el resultado sea realmente compatible con el nivel de confianza del 99%. (4) No se ejecutó la prueba de Christoffersen (independencia de excepciones), que es estándar en backtesting de VaR y detectaría clustering de pérdidas. (5) El manual declara que la simulación histórica «no captura eventos sin precedente» pero no especifica cómo se monitorea este riesgo ni qué acciones se toman si ocurre. (6) No hay análisis de sensibilidad: no se muestra cómo varía el VaR con cambios en la ventana, el nivel de confianza o la definición de retornos. Sin esta evidencia, la metodología no puede considerarse justificada, solo descrita. Para alcanzar cumplimiento parcial (nivel 3) se requeriría: (a) los cálculos y p-valores del análisis de ventanas que justifique 250 días; (b) la ejecución de Christoffersen sobre los datos de Q1 2026; (c) el intervalo de confianza de Kupiec y la interpretación del p-valor; (d) un análisis explícito de por qué se descartaron alternativas metodológicas.

**Evidencia citada.**

> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones. Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."
>
> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»

**Preguntas al modelador.**

- [ ] ¿Cuáles fueron los resultados del análisis de ventanas alternativas (número de excepciones, p-valores de Kupiec) que justificó la elección de 250 días? Proporcionar la tabla completa con ventanas de 100, 150, 200, 250, 300, 500 días.
- [ ] ¿Cuál es el intervalo de confianza de Kupiec al 99% para 62 días de negociación, y cuál fue el p-valor del estadístico LR en el backtesting de Q1 2026? Proporcionar el cálculo explícito.
- [ ] ¿Se ejecutó la prueba de Christoffersen (independencia de excepciones) sobre los datos de Q1 2026? Si no, ¿por qué se omitió siendo estándar en validación de VaR?
- [ ] ¿Qué análisis de estacionariedad se realizó sobre los retornos logarítmicos para verificar que la distribución empírica de 250 días es representativa del futuro? Proporcionar pruebas ADF o KPSS.
- [ ] ¿Se evaluaron métodos alternativos (GARCH, EVT, Monte Carlo) antes de elegir simulación histórica? Si no, ¿cuál es la justificación de esta elección para una cartera de negociación con horizonte de 1 día?
- [ ] ¿Cómo se monitorea el riesgo de eventos sin precedente en la ventana de estimación? ¿Existe un procedimiento documentado para detectar y actuar ante cambios de régimen no capturados por el modelo?
- [ ] ¿Se realizó análisis de sensibilidad del VaR respecto a cambios en la ventana, el nivel de confianza o la definición de retornos? Proporcionar gráficos o tablas de sensibilidad.

**Recomendación.** Elevar a primera línea para que complete la documentación de justificación metodológica: (1) Proporcionar los cálculos y p-valores del análisis de ventanas que respalden la elección de 250 días, con comparación explícita contra ventanas alternativas. (2) Ejecutar y reportar la prueba de Christoffersen sobre los datos de backtesting de Q1 2026, incluyendo el estadístico LR de independencia y su p-valor. (3) Reportar el intervalo de confianza de Kupiec y el p-valor del estadístico LR para el backtesting de Q1 2026, con interpretación explícita de si el modelo cumple o no con el nivel de confianza del 99%. (4) Documentar el análisis de alternativas metodológicas (GARCH, EVT, Monte Carlo) y la justificación de por qué se descartaron. (5) Añadir al manual una sección de verificación de supuestos (estacionariedad, independencia, homocedasticidad) con pruebas estadísticas y frecuencia de revisión. (6) Definir un procedimiento operativo para monitorear y actuar ante eventos sin precedente o cambios de régimen. Hasta que se complete esta evidencia, el modelo no puede considerarse justificado metodológicamente, solo descrito.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `f6a7cf8d1be0`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Validar supuestos y consideración más importantes de la técnica utilizada

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Validación de la justificación metodológica del modelo VaR: evaluación de supuestos, elección del método, backtesting y limitaciones declaradas. Es crítico porque determina si el modelo es conceptualmente sólido antes de evaluar su ejecución.

**Hallazgo.**

La documentación declara una metodología de simulación histórica con backtesting Kupiec, pero presenta brechas críticas que impiden validar la solidez de la justificación metodológica. Primero, el manual afirma que la ventana de 250 días se eligió tras comprobar que ventanas inferiores producían excepciones fuera del intervalo de Kupiec, pero NO APORTA EVIDENCIA de esas pruebas comparativas: ni p-valores, ni número de excepciones observadas en ventanas alternativas, ni criterio cuantitativo de decisión. Esto es una afirmación sin respaldo verificable. Segundo, el manual declara que la simulación histórica 'asume que la distribución empírica del pasado reciente es representativa del futuro inmediato' como limitación, pero NO VERIFICA este supuesto: no hay contraste de estacionariedad, análisis de cambios de régimen, ni prueba de que la distribución empírica de 2025 sea comparable a la de 2026 Q1. Tercero, el backtesting reporta 4 excepciones en 62 días (6.45%) contra un nivel del 99% (esperado ~0.62 excepciones), lo que está dentro del intervalo de Kupiec, pero el informe NO EJECUTA ni CITA la prueba de Christoffersen de independencia de excedencias, que es estándar en la literatura recuperada y crítica para detectar clustering de pérdidas. Cuarto, no hay análisis de las excedencias individuales: la literatura recuperada señala que 'la explicación de cada excedencia observada es evidencia de validación tan relevante como el estadístico agregado', pero el informe no identifica qué eventos generaron las 4 excepciones ni si fueron eventos de mercado explicables o anomalías del modelo. Quinto, el manual no justifica por qué se eligió simulación histórica sobre alternativas (ej. EWMA paramétrico, Expected Shortfall, modelos de colas gruesas): simplemente la declara sin argumentar la elección. Para alcanzar cumplimiento parcial sin brechas críticas (nivel 3) se requeriría: (a) evidencia cuantitativa de la selección de ventana, (b) prueba de Christoffersen ejecutada, (c) análisis de las 4 excepciones individuales, (d) justificación de por qué simulación histórica y no otra metodología. La cobertura documental es completa (100%), pero la profundidad de justificación es insuficiente.

**Evidencia citada.**

> manual_VaR_drift.md → "Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»

**Preguntas al modelador.**

- [ ] ¿Cuáles fueron los p-valores y estadísticos LR de la prueba de Kupiec en el backtesting de 2026 Q1? ¿Están dentro del intervalo de aceptación al 95% de confianza?
- [ ] ¿Se ejecutó la prueba de Christoffersen (independencia de excedencias) en el backtesting? Si no, ¿por qué se omitió siendo estándar en la industria?
- [ ] ¿Cuáles fueron los eventos de mercado o factores de riesgo que generaron las 4 excepciones observadas en 2026 Q1? ¿Se analizaron individualmente?
- [ ] ¿Qué metodologías alternativas (EWMA, modelos de colas gruesas, Expected Shortfall) se evaluaron antes de elegir simulación histórica? ¿Con qué criterios se descartaron?
- [ ] ¿Se verificó la estacionariedad de la distribución de retornos en la ventana de 250 días? ¿Hay evidencia de cambios de régimen entre el período de estimación y el de validación?
- [ ] ¿Cuál es el intervalo de confianza exacto de Kupiec para 62 observaciones al 99% de confianza? ¿4 excepciones (6.45%) está dentro o fuera de ese intervalo?
- [ ] ¿Se realizó análisis de sensibilidad variando la ventana de estimación (ej. 200, 300, 400 días) para validar la robustez de la elección de 250 días?

**Recomendación.** 1. **Inmediato**: Ejecutar y reportar la prueba de Christoffersen sobre los datos de 2026 Q1. Si el p-valor es significativo, indica clustering de excepciones y sugiere que el modelo no captura correctamente la dinámica de volatilidad. 2. **Inmediato**: Reportar los estadísticos LR y p-valores de Kupiec con cifras exactas, no solo conclusiones cualitativas. Incluir el intervalo de aceptación al 95% de confianza para 62 observaciones. 3. **Corto plazo**: Documentar el análisis de cada una de las 4 excepciones: fecha, factor de riesgo, magnitud de la pérdida, evento de mercado asociado. Esto permite distinguir si las excepciones son anomalías del modelo o eventos genuinamente extremos. 4. **Corto plazo**: Añadir al manual una sección de 'Justificación metodológica' que explique: (a) por qué simulación histórica sobre alternativas, (b) qué metodologías se descartaron y con qué criterios, (c) qué supuestos se verifican y cómo. 5. **Mediano plazo**: Implementar prueba de estacionariedad (ej. Augmented Dickey-Fuller) y análisis de cambios de régimen (ej. test de Chow) para validar que la distribución empírica de la ventana de 250 días es representativa del futuro inmediato. 6. **Mediano plazo**: Realizar análisis de sensibilidad variando la ventana de estimación (200, 300, 400 días) y reportar cómo cambian los resultados de Kupiec y Christoffersen. Esto proporciona evidencia cuantitativa de la robustez de la elección de 250 días.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Feedback insuficiente (1/15 muestras mínimas) · prompt `4b84747b93b7`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisión de los lineamiento internacionales o nacionales

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Validación de la justificación metodológica del modelo VaR: verificar que la elección de simulación histórica, parámetros (ventana, nivel de confianza, horizonte) y backtesting estén fundamentados en evidencia empírica y lineamientos regulatorios, no solo documentados.

**Hallazgo.**

La documentación declara una metodología de simulación histórica con backtesting Kupiec, pero presenta BRECHAS CRÍTICAS que impiden validar el cumplimiento real de esta actividad. Primero, la justificación de la metodología es INCOMPLETA: el manual afirma que «ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec» (manual_VaR_drift.md § 2), pero NO APORTA los datos, p-valores ni conclusiones de esos contrastes previos — es una afirmación sin evidencia verificable. Segundo, NO EXISTE JUSTIFICACIÓN DE ALTERNATIVAS: el manual no explica por qué se eligió simulación histórica frente a otros métodos (paramétrico, Monte Carlo, GARCH), ni qué criterios se usaron para descartar alternativas. Tercero, los SUPUESTOS CLAVE NO SE VERIFICAN: la simulación histórica asume que la distribución empírica del pasado es representativa del futuro (limitación declarada en § 4), pero no hay evidencia de contrastes de estacionariedad, cambios de régimen, o análisis de colas — solo una declaración de limitación. Cuarto, el backtesting reportado (backtesting_2026Q1.md) muestra 4 excepciones en 62 días y afirma que están «dentro de la zona verde de Basilea», pero NO CITA el intervalo de Kupiec específico para este tamaño de muestra, ni proporciona el p-valor del estadístico LR — sin eso, la conclusión «el modelo se comporta conforme» es una afirmación no verificada. Quinto, NO HAY EVIDENCIA DE EJECUCIÓN REAL: el informe dice que «el contraste se realizó con la función backtesting_kupiec()», pero no se proporciona el log de ejecución, los datos de entrada, ni el output del estadístico — existe un script documentado pero no hay rastro de que se haya corrido con datos reales de 2026 Q1. Sexto, FALTA CHRISTOFFERSEN: el manual menciona solo Kupiec (cobertura incondicional), pero no aborda la independencia de excepciones (Christoffersen 1998), que es estándar en backtesting de modelos de riesgo según marcos supervisores. Séptimo, NO HAY ANÁLISIS DE SENSIBILIDAD: no se documenta cómo se comporta el modelo ante cambios en la ventana, nivel de confianza, o definición de excedencia. Para alcanzar cumplimiento parcial con observaciones críticas (nivel 3), se requeriría: (a) p-valor y estadístico LR del backtesting Kupiec con datos reales, (b) justificación explícita de por qué simulación histórica y no alternativas, (c) verificación de supuestos (estacionariedad, cambios de régimen), (d) test de Christoffersen o justificación de su omisión. Actualmente, la documentación es coherente internamente pero no está DEMOSTRADA empíricamente.

**Evidencia citada.**

> manual_VaR_drift.md → "El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de observaciones. Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."
>
> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."
>
> backtesting_2026Q1.md → "El modelo se comporta conforme a lo especificado. No se requiere recalibración en este trimestre."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El VaR se estima sobre una ventana de 250 días hábiles, equivalente a un año de »
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»

**Preguntas al modelador.**

- [ ] ¿Cuál es el intervalo de confianza exacto de Kupiec para 62 observaciones al 99% de confianza, y cuál es el p-valor del estadístico LR para 4 excepciones observadas? (Necesario para verificar la conclusión del backtesting.)
- [ ] ¿Se ejecutó realmente la función `backtesting_kupiec()` en 2026 Q1? ¿Existe un log de ejecución, datos de entrada (retornos diarios), y output completo (estadístico LR, p-valor)?
- [ ] ¿Por qué se eligió simulación histórica frente a métodos paramétricos, Monte Carlo o GARCH? ¿Se realizó un análisis comparativo de métodos?
- [ ] ¿Se verificó la estacionariedad de los retornos en la ventana de 250 días? ¿Existen contrastes ADF, KPSS o análisis de cambios de régimen?
- [ ] ¿Por qué no se implementa el test de Christoffersen (independencia de excepciones) además de Kupiec? ¿Se descartó deliberadamente o se omitió?
- [ ] ¿Cuál es la definición operativa de excedencia utilizada en el backtesting? (¿Pérdida realizada > VaR estimado? ¿Incluye comisiones? ¿Tratamiento de faltantes?)
- [ ] ¿Se realizó análisis de sensibilidad del modelo a cambios en la ventana (p.ej., 200, 250, 300 días) o en el nivel de confianza (p.ej., 95%, 99%, 99.5%)?
- [ ] ¿Cuáles fueron los resultados de los contrastes previos que justificaron la elección de 250 días? (Número de excepciones, p-valores, fechas de esos análisis.)

**Recomendación.** 1. **Inmediato**: Proporcionar el output completo del backtesting Kupiec 2026 Q1 (estadístico LR, p-valor, intervalo de confianza, número de excepciones esperadas vs observadas). Sin esto, la conclusión del informe no es verificable. 2. **Corto plazo**: Documentar la justificación de la metodología: (a) análisis comparativo de simulación histórica vs alternativas (paramétrico, Monte Carlo, GARCH), con criterios de selección explícitos; (b) verificación de supuestos (contrastes de estacionariedad, cambios de régimen); (c) implementación del test de Christoffersen además de Kupiec. 3. **Mediano plazo**: Establecer un protocolo de backtesting que incluya: (a) ejecución trimestral con log documentado; (b) análisis de sensibilidad a parámetros clave (ventana, nivel de confianza); (c) monitoreo de limitaciones declaradas (capacidad de captura de eventos extremos, cambios de régimen). 4. **Documentación**: Actualizar el manual con (a) definición operativa de excedencia; (b) justificación de parámetros fijos (horizonte 1 día, confianza 99%); (c) criterios de recalibración (qué p-valor o número de excepciones dispara revisión del modelo).

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `30e6b956cf53`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la existencia y ejecución del backtesting del modelo VaR mediante pruebas estadísticas (Kupiec, Christoffersen) y análisis de excedencias. Esta actividad es crítica para validar que el modelo de riesgo captura adecuadamente la distribución de pérdidas y que sus predicciones son estadísticamente confiables.

**Hallazgo.**

La documentación declara la ejecución de backtesting con la prueba de Kupiec durante Q1 2026, reportando 4 excepciones en 62 días dentro de la zona verde de Basilea. Sin embargo, existen brechas críticas que impiden validar el cumplimiento real: (1) NO se proporciona el estadístico LR ni el p-valor de la prueba de Kupiec, solo la conclusión cualitativa. El manual especifica que la función `backtesting_kupiec()` devuelve 'el estadístico LR junto con su p-valor', pero el informe de seguimiento no reporta estas cifras verificables. (2) NO se ejecutó la prueba de Christoffersen (independencia de excedencias), que es estándar en validación de modelos de riesgo y que el corpus de dominio identifica como requisito para detectar clustering de excepciones. (3) NO se documentó el análisis individual de las 4 excepciones observadas: qué eventos de mercado las causaron, si fueron eventos sin precedente en la ventana de 250 días, o si revelan deficiencias del modelo. El corpus de dominio señala explícitamente que 'la explicación de cada excedencia observada es evidencia de validación tan relevante como el estadístico agregado'. (4) NO se declara la potencia estadística de la prueba con n=62 observaciones, ni se reconoce que muestras pequeñas pueden no detectar desajustes moderados. (5) NO se especifica si el backtesting se realizó sobre P&L hipotético (cartera congelada) o real, lo que es crítico para aislar el desempeño del modelo de efectos operacionales. Para alcanzar cumplimiento parcial con observaciones no críticas (nivel 3), se requeriría: reportar LR y p-valor, ejecutar Christoffersen, documentar las 4 excepciones, y declarar limitaciones de potencia. Actualmente, el informe es una declaración de conformidad sin respaldo cuantitativo verificable.

**Evidencia citada.**

> backtesting_2026Q1.md → "Se observaron **4 excepciones** en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> backtesting_2026Q1.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."
>
> backtesting_2026Q1.md → "El modelo se comporta conforme a lo especificado. No se requiere recalibración en este trimestre."

**Preguntas al modelador.**

- [ ] ¿Cuál es el valor exacto del estadístico LR y el p-valor reportado por `backtesting_kupiec()` en Q1 2026? Proporcionar la salida numérica completa de la función.
- [ ] ¿Se ejecutó la prueba de Christoffersen (independencia de excedencias) en Q1 2026? Si no, ¿por qué se omitió siendo estándar en validación de modelos de riesgo?
- [ ] ¿Cuáles fueron los 4 eventos de mercado que causaron las excepciones observadas? ¿Ocurrieron en fechas próximas (clustering) o distribuidas a lo largo del trimestre?
- [ ] ¿Se realizó el backtesting sobre P&L hipotético (cartera congelada) o P&L real? ¿Se documentó el tratamiento de días con mercados cerrados o datos incompletos?
- [ ] ¿Se ejecutó un análisis de sensibilidad de la ventana de 250 días? ¿Qué longitudes alternativas se probaron y por qué se descartaron?
- [ ] ¿Se verificó que los retornos logarítmicos cumplen los supuestos de estacionariedad e independencia requeridos por la simulación histórica?
- [ ] ¿Existe un plan de backtesting para Q2 2026 y trimestres posteriores, o fue un ejercicio puntual? ¿Con qué frecuencia se ejecuta el backtesting?
- [ ] ¿Se documentó la potencia estadística de la prueba de Kupiec con n=62 observaciones? ¿Cuál es el tamaño de efecto mínimo que la prueba puede detectar?

**Recomendación.** Requerir a la primera línea que proporcione: (1) Salida numérica completa de `backtesting_kupiec()` incluyendo LR, p-valor e intervalo de confianza de Kupiec para Q1 2026. (2) Ejecución de la prueba de Christoffersen sobre la serie de excepciones, con estadístico de independencia y p-valor. (3) Análisis documentado de cada una de las 4 excepciones: fecha, factor de riesgo que se movió, magnitud de la pérdida vs VaR estimado, y clasificación (evento sin precedente vs fallo de captura). (4) Especificación clara de si el backtesting se realizó sobre P&L hipotético o real, y tratamiento de datos faltantes. (5) Análisis de sensibilidad de la ventana de 250 días: reportar número de excepciones y resultado de Kupiec para ventanas de 150, 200, 300 y 500 días, con justificación de por qué 250 es óptimo. (6) Declaración explícita de la potencia estadística de la prueba con n=62 y reconocimiento de que muestras pequeñas pueden no detectar desajustes moderados. (7) Plan de backtesting trimestral documentado, con calendario y responsables. Hasta que se proporcione esta evidencia, el cumplimiento no puede elevarse de 2/5.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `3e2b7b62f3c1`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la ejecución y justificación del análisis de sensibilidad/escenarios sobre el modelo VaR, así como la validación empírica de supuestos y la robustez metodológica del backtesting. Esta actividad es crítica para demostrar que el modelo no solo se comporta dentro de límites estadísticos, sino que sus supuestos fundamentales se sostienen bajo variaciones de parámetros e inputs.

**Hallazgo.**

La documentación disponible presenta CUMPLIMIENTO PARCIAL CON BRECHAS CRÍTICAS. El informe de backtesting reporta la ejecución de la prueba de Kupiec y declara que el modelo está dentro de la zona verde de Basilea (4 excepciones en 62 días), pero FALTA COMPLETAMENTE: (1) Análisis de sensibilidad sobre los parámetros clave del modelo (ventana de 250 días, nivel de confianza 99%, horizonte de 1 día). El manual menciona que se eligió la ventana de 250 días tras comprobar que ventanas inferiores producían excepciones fuera del intervalo de Kupiec, pero NO APORTA LOS DATOS de esos contrastes previos ni la justificación cuantitativa de por qué 250 es óptimo. (2) Análisis de escenarios sobre los inputs (composición de la cartera, volatilidad de factores de riesgo, correlaciones). (3) Prueba de Christoffersen (independencia de excepciones), que es estándar en backtesting moderno y que la literatura recuperada identifica como error frecuente omitirla. (4) Análisis individual de las 4 excepciones observadas: qué eventos las causaron, si fueron predecibles, si revelan debilidades del modelo. La literatura señala que "la explicación de cada excedencia observada es evidencia de validación tan relevante como el estadístico agregado". (5) Declaración explícita de la potencia estadística de la prueba con 62 observaciones (muestra pequeña). El manual declara limitaciones de la simulación histórica pero no cuantifica cómo afectan a la confiabilidad del backtesting con este tamaño muestral. Para alcanzar cumplimiento parcial sin brechas críticas (nivel 3), se requeriría al menos: análisis de sensibilidad documentado sobre los parámetros principales, prueba de Christoffersen ejecutada, y análisis narrativo de las excepciones. Para nivel 4, además: justificación cuantitativa de la elección de parámetros y análisis de escenarios sobre inputs.

**Evidencia citada.**

> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> manual_VaR_drift.md → "Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> manual_VaR_drift.md → "La simulación histórica asume que la distribución empírica del pasado reciente es representativa del futuro inmediato. No captura eventos sin precedente en la ventana de estimación."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»

**Preguntas al modelador.**

- [ ] ¿Cuáles fueron los p-valores y estadísticos LR de la prueba de Kupiec en Q1 2026? ¿Dentro de qué intervalo de confianza exacto (numérico) cayeron las 4 excepciones?
- [ ] ¿Se ejecutó la prueba de Christoffersen (independencia de excepciones) en Q1 2026? Si no, ¿por qué se omitió siendo estándar en backtesting moderno?
- [ ] ¿Qué contrastes previos de Kupiec se realizaron para justificar la elección de 250 días? ¿Cuáles fueron los p-valores y los intervalos de confianza para ventanas de 200, 250, 300, 500 días?
- [ ] ¿Se realizó análisis de sensibilidad documentado sobre los parámetros clave (ventana, nivel de confianza, horizonte)? ¿Cómo varía el VaR estimado y el número de excepciones esperadas si se cambian estos parámetros?
- [ ] ¿Se realizó análisis de escenarios sobre los inputs (composición de cartera, volatilidad de factores, correlaciones)? ¿Cómo se comportaría el modelo bajo volatilidad extrema o cambios de régimen?
- [ ] ¿Se verificaron los supuestos de la simulación histórica (estacionariedad, normalidad, independencia, homocedasticidad) de los retornos en la ventana de 250 días? ¿Cuáles fueron los p-valores de esos contrastes?
- [ ] ¿Se analizaron individualmente las 4 excepciones observadas en Q1 2026? ¿Qué eventos de mercado las causaron? ¿Eran predecibles o fueron eventos de cola sin precedente?
- [ ] ¿Se declaró explícitamente la potencia estadística de la prueba de Kupiec con 62 observaciones? ¿Cuál es la probabilidad de detectar un modelo deficiente con este tamaño muestral?
- [ ] ¿Se comparó el modelo VaR de simulación histórica con alternativas (p.ej., modelos paramétricos, GARCH, Montecarlo)? ¿Por qué se descartaron esas alternativas?

**Recomendación.** 1. **Inmediato**: Documentar y reportar los estadísticos completos de la prueba de Kupiec (LR, p-valor, intervalo de confianza numérico) para Q1 2026. Ejecutar la prueba de Christoffersen y reportar sus resultados. Analizar individualmente cada una de las 4 excepciones: qué evento de mercado la causó, si era predecible, si revela una debilidad del modelo. 2. **Corto plazo**: Documentar los contrastes previos que justificaron la elección de 250 días (p-valores y intervalos de Kupiec para ventanas alternativas). Realizar y documentar análisis de sensibilidad sobre ventana, nivel de confianza y horizonte. Verificar supuestos de estacionariedad, normalidad e independencia de los retornos. 3. **Mediano plazo**: Realizar análisis de escenarios sobre inputs (volatilidad extrema, cambios de correlación, eventos de cola). Comparar el modelo con alternativas metodológicas y documentar la justificación de por qué se eligió simulación histórica. Declarar explícitamente la potencia estadística de la prueba con el tamaño muestral actual y proponer compensaciones si es baja (p.ej., pruebas complementarias, umbrales de acción más conservadores). 4. **Governance**: Establecer un calendario de revisión trimestral que incluya no solo el backtesting de Kupiec, sino también Christoffersen, análisis de sensibilidad y análisis narrativo de excepciones. Documentar todas las decisiones de parámetros y cambios metodológicos en un registro de control de versiones.

<sub>cobertura documental 100.0% · RAG VaR (5 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `03d15c62399d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Analizar el seguimeinto de la metodología

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación del seguimiento metodológico del modelo VaR mediante backtesting: verifica que la metodología documentada se ejecute periódicamente, que los resultados se interpreten correctamente y que se tomen decisiones basadas en ellos. Es crítico para asegurar que el modelo sigue siendo válido en producción.

**Hallazgo.**

La documentación declara la ejecución de backtesting Kupiec durante Q1 2026 con resultados dentro de límites aceptables, pero presenta BRECHAS CRÍTICAS que impiden validar el cumplimiento real del seguimiento metodológico. Primero, el informe de backtesting carece de cifras verificables: no se proporcionan el estadístico LR, el p-valor, ni el intervalo de confianza de Kupiec contra el cual se contrasta. La afirmación «4 excepciones en 62 días, dentro de la zona verde» es una conclusión sin respaldo numérico. Segundo, no existe evidencia de que el backtesting se haya ejecutado realmente: no hay logs de ejecución, timestamps, ni trazabilidad de cuándo se corrió `backtesting_kupiec()`. Tercero, el manual especifica que «la ventana de 250 días se fijó tras comprobar que ventanas inferiores producían excepciones fuera del intervalo de Kupiec», pero no se aporta ese análisis comparativo ni los p-valores de esas pruebas previas. Cuarto, falta completamente el análisis de Christoffersen (independencia de excepciones), que es estándar en backtesting de VaR y detectaría clustering de pérdidas que Kupiec no captura. Quinto, no hay evidencia de que los resultados del backtesting lleguen a ningún comité de decisión ni que generen acciones correctivas si fuera necesario. El informe concluye «no se requiere recalibración» sin justificar por qué 4 excepciones en 62 días (6.45%) es aceptable cuando el nivel de confianza es 99% (esperado: ~0.62 excepciones). Para alcanzar cumplimiento parcial con brechas no críticas (nivel 3) se requeriría: (a) cifras explícitas del estadístico LR y p-valor de Kupiec, (b) evidencia de ejecución (log, fecha, usuario), (c) análisis de Christoffersen o justificación de su omisión, (d) trazabilidad de cómo se fijó la ventana de 250 días con p-valores de pruebas alternativas.

**Evidencia citada.**

> backtesting_2026Q1.md → "Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde del semáforo de Basilea y compatible con el intervalo de la prueba de Kupiec al 99 % de confianza."
>
> manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto con su p-valor."
>
> manual_VaR_drift.md → "Esta longitud se fijó tras comprobar que ventanas inferiores producían un número de excepciones fuera del intervalo de Kupiec, y que ventanas superiores diluían la reacción del modelo ante cambios de régimen."
>
> manual_VaR_drift.md → "El contraste se realizó con la función `backtesting_kupiec()` documentada en el manual, sobre los mismos retornos logarítmicos empleados en la estimación."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «Se observaron 4 excepciones en 62 días de negociación, dentro de la zona verde d»
> - «Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas cont»

**Preguntas al modelador.**

- [ ] ¿Cuál es el valor exacto del estadístico LR y el p-valor de la prueba de Kupiec para Q1 2026? ¿Cuál es el intervalo de confianza al 95% para el número de excepciones esperadas bajo H0?
- [ ] ¿Existe un log de ejecución de `backtesting_kupiec()` con timestamp, usuario y parámetros utilizados? ¿Cuándo se ejecutó exactamente?
- [ ] ¿Se ejecutó la prueba de Christoffersen (independencia de excepciones) en Q1 2026? Si no, ¿por qué se omite siendo estándar en backtesting de VaR?
- [ ] ¿Cuáles fueron los p-valores de las pruebas de Kupiec con ventanas de 100, 150, 200, 300 y 400 días que justificaron la elección de 250 días? ¿Se documentan esos análisis?
- [ ] ¿A qué comité o proceso de decisión se reportan los resultados del backtesting? ¿Existe un registro de decisiones tomadas (o no tomadas) basadas en estos resultados?
- [ ] ¿Se ha verificado estacionariedad de los retornos logarítmicos en la ventana de 250 días? ¿Hay test de Augmented Dickey-Fuller u otro test de raíz unitaria documentado?
- [ ] ¿Por qué se eligió simulación histórica sobre GARCH, EVT o simulación de Montecarlo? ¿Se evaluaron alternativas?
- [ ] ¿Cuál es la tasa de excepciones esperada bajo H0 para 62 días de negociación al 99% de confianza? ¿Cómo se interpreta que 4 excepciones (6.45%) sea «compatible» con esa expectativa?

**Recomendación.** 1. **Inmediato**: Exigir que el próximo informe de backtesting (Q2 2026) incluya: (a) estadístico LR y p-valor de Kupiec con intervalo de confianza explícito, (b) prueba de Christoffersen con su estadístico y p-valor, (c) log de ejecución con timestamp y parámetros, (d) tabla comparativa de excepciones observadas vs. esperadas. 2. **Corto plazo**: Documentar el análisis de sensibilidad que justificó la ventana de 250 días, incluyendo p-valores de Kupiec para ventanas alternativas (100, 150, 200, 300, 400 días). 3. **Corto plazo**: Añadir al manual una sección de «Supuestos verificados» que incluya: test de estacionariedad (ADF), análisis de autocorrelación de retornos, y justificación de por qué se omite Christoffersen (si aplica). 4. **Mediano plazo**: Establecer un proceso formal de escalada: si el p-valor de Kupiec cae por debajo de 0.05 o si Christoffersen rechaza independencia, definir qué acciones correctivas se toman (recalibración, cambio de ventana, revisión de supuestos). 5. **Documentación**: Crear un registro de decisiones de backtesting que vincule resultados → comité → acción, con trazabilidad de quién aprobó qué y cuándo.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `45aac97cdaa1`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Gobierno  ·  score 1.5

#### 🔴 [1/5] revisar que el modelo se encuentre inventariado

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificar que el modelo VaR Drift se encuentre inventariado en el registro oficial de modelos de riesgo con tiering asignado y actualizado. Este control es requisito de gobierno de modelos bajo SR 11-7 y marcos de validación independiente.

**Hallazgo.**

No se encontró NINGUNA evidencia de inventario oficial, tiering asignado, acta de registro, o documento de gobierno que acredite que el modelo 'VaR Drift' existe en el inventario corporativo de modelos de riesgo. El contexto disponible contiene ÚNICAMENTE: (1) un script de cálculo de VaR etiquetado explícitamente como 'FIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente VIRF. No es la implementación de ningún modelo real'; (2) un manual metodológico también marcado como 'Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad'. Ambos documentos incluyen referencias a 'LEEME.md' que no está en el contexto. La instrucción específica para este ámbito exige 'Solo aceptar actas formales firmadas. Un correo NO equivale a acta. Verificar tiering asignado y su justificación'. No existe acta formal, no existe tiering documentado, no existe evidencia de que este modelo haya sido sometido a proceso de inventario. El hallazgo previo en este ámbito ([2/5]) ya señalaba 'brechas CRÍTICAS en la evidencia de gobierno del modelo'. El aprendizaje de corridas anteriores indica que el inventario 'vive en la herramienta corporativa de GRC, fuera de inputs/', pero esa herramienta NO está disponible en el contexto de esta validación. Sin acceso a esa fuente primaria, no es posible verificar el cumplimiento. La evidencia disponible sugiere que lo que se proporcionó es material de prueba sintético, no un modelo en producción sujeto a gobierno. Esto es una AUSENCIA CRÍTICA DE EVIDENCIA, no una carencia menor.

**Evidencia citada.**

> calcula_var.py → """\nCálculo del VaR de mercado por simulación histórica.\n\nFIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente VIRF. No es la implementación de ningún modelo real. Ver LEEME.md.\n"""
>
> manual_VaR_drift.md → "# Manual metodológico — VaR de mercado (FIXTURE SINTÉTICO)\n\n> Documento fabricado para probar el juez de código. No describe ningún modelo real de la entidad. Ver `LEEME.md` en la raíz de este árbol."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «\nCálculo del VaR de mercado por simulación histórica.\n\nFIXTURE SINTÉTICO — có»
> - «# Manual metodológico — VaR de mercado (FIXTURE SINTÉTICO)\n\n> Documento fabric»
> - «Solo aceptar actas formales firmadas. Un correo NO equivale a acta. Verificar ti»

**Preguntas al modelador.**

- [ ] ¿Existe un inventario oficial de modelos de riesgo en la herramienta corporativa de GRC? Si existe, ¿aparece el modelo 'VaR Drift' registrado con tiering asignado?
- [ ] ¿Cuál es el acta formal (con fecha, firmantes y aprobaciones) que acredita la inclusión de este modelo en el inventario?
- [ ] ¿Cuál es el tiering asignado al modelo y cuál es la justificación documentada para esa clasificación?
- [ ] ¿Existe un acta de revisión o actualización del tiering en los últimos 12 meses?
- [ ] ¿El material proporcionado (calcula_var.py y manual_VaR_drift.md) es realmente el modelo en producción, o es material de prueba que debe ser reemplazado por la documentación y código del modelo real antes de proceder con la validación de gobierno?

**Recomendación.** DETENER la evaluación de gobierno hasta que se proporcione: (1) Acceso a la herramienta corporativa de GRC o copia del inventario oficial de modelos; (2) Acta formal firmada de registro del modelo en el inventario, con fecha y aprobadores; (3) Documento de tiering con justificación de la clasificación asignada; (4) Confirmación de que el código y manual proporcionados corresponden al modelo real en producción, no a material sintético de prueba. Si el modelo 'VaR Drift' no existe en el inventario real, la conclusión es que NO CUMPLE este requisito de gobierno (puntaje 1). Si existe pero no fue proporcionado en el contexto, la evaluación debe repetirse con la evidencia correcta.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Feedback insuficiente (1/15 muestras mínimas) · prompt `fdcab08af3ac`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar la actualización del tiering del modelo

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificar que el modelo VaR Drift tenga tiering asignado, actualizado e inventariado, con actas formales que documenten la decisión de gobierno. Esta actividad es crítica para asegurar que el modelo está bajo control de cambios y que su clasificación de riesgo refleja su estado actual.

**Hallazgo.**

La evaluación revela brechas CRÍTICAS en la evidencia de gobierno del modelo. Aunque el contexto disponible contiene documentación técnica del modelo (manual metodológico y código de implementación), NO EXISTE NINGÚN ACTA FORMAL, DECISIÓN DE TIERING O REFERENCIA A INVENTARIO que demuestre que el modelo ha sido clasificado, autorizado o actualizado en el marco de gobierno corporativo. El manual menciona que 'ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos', lo que PRESUPONE la existencia de un proceso de gobierno, pero no proporciona evidencia de que ese proceso se haya ejecutado. El código contiene un comentario explícito ('FIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente VIRF. No es la implementación de ningún modelo real') que sugiere que el artefacto bajo validación es un fixture de prueba, no un modelo en producción, lo que genera incertidumbre sobre si la actividad de tiering es aplicable o si los documentos son reales. El historial de corridas anteriores indica que el inventario puede residir en herramientas corporativas de GRC fuera del contexto disponible, pero la instrucción específica exige 'actas formales firmadas' — un correo NO equivale a acta. Sin esas actas, no hay evidencia de que el tiering haya sido asignado, revisado o actualizado. Para alcanzar el nivel 3 se requeriría: (1) acta formal de asignación de tiering con fecha, firmantes y justificación; (2) evidencia de que el modelo está en el inventario oficial con tiering vigente; (3) acta de última revisión/actualización del tiering. Actualmente solo hay documentación técnica sin respaldo de gobierno.

**Evidencia citada.**

> manual_VaR_drift.md → "El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el método de simulación histórica."
>
> manual_VaR_drift.md → "Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos."
>
> calcula_var.py → """\nCálculo del VaR de mercado por simulación histórica.\n\nFIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente VIRF. No es la implementación de ningún modelo real. Ver LEEME.md.\n"""
>
> No se encontró evidencia de acta formal de tiering, inventario oficial o decisión de gobierno en el contexto disponible.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el m»
> - «\nCálculo del VaR de mercado por simulación histórica.\n\nFIXTURE SINTÉTICO — có»
> - «No se encontró evidencia de acta formal de tiering, inventario oficial o decisió»
> - «Documento fabricado para probar el juez de código. No describe ningún modelo rea»

**Preguntas al modelador.**

- [ ] ¿El modelo VaR Drift está efectivamente en producción o es un fixture de prueba? Los documentos declaran ser sintéticos; se requiere confirmación de estado real.
- [ ] ¿Existe acta formal de asignación de tiering para este modelo? Incluir: fecha, firmantes, justificación de la clasificación asignada, y nivel de tiering (Tier 1/2/3).
- [ ] ¿En qué fecha se realizó la última revisión/actualización del tiering? Proporcionar acta de revisión con resultado y cambios aplicados.
- [ ] ¿El modelo está registrado en el inventario oficial de modelos de riesgo? Proporcionar referencia o extracto del inventario corporativo (herramienta GRC) que muestre tiering vigente.
- [ ] ¿Quién es el propietario del modelo y quién es responsable de mantener el tiering actualizado? Incluir estructura de gobierno y frecuencia de revisión.

**Recomendación.** Solicitar formalmente al propietario del modelo: (1) Acta de asignación de tiering firmada por el Comité de Riesgos o autoridad equivalente, con justificación técnica de la clasificación; (2) Evidencia de registro en el inventario oficial de modelos (extracto de la herramienta corporativa de GRC con tiering y fecha de última actualización); (3) Acta de la última revisión periódica del tiering, indicando si se mantiene o se modifica la clasificación. Si el modelo es efectivamente un fixture de prueba, clarificar el alcance de la validación y si debe excluirse de este ámbito de gobierno. Hasta obtener estas actas, la actividad no puede considerarse cumplida.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `099b80ca6850`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Implementación  ·  score 1.75

#### 🔴 [1/5] Vericar existencias de correos de comunicación de resultados y su conformidad

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificación de existencia y conformidad de comunicaciones de resultados de implementación (correos, aprobaciones, UAT documentadas) y coherencia entre documentación metodológica e implementación en código. Esta actividad es crítica para asegurar que el modelo pasó controles de calidad antes de producción y que existe trazabilidad de decisiones.

**Hallazgo.**

La evaluación revela AUSENCIA COMPLETA DE EVIDENCIA en los tres ejes críticos de esta actividad: (1) No existe ningún correo de comunicación de resultados entre desarrollador y primera línea; (2) No hay documentación de pruebas iniciales de implementación (UAT, test cases, logs de ejecución); (3) No existe correo de aprobación para paso a producción. El contexto disponible contiene únicamente un script de código (calcula_var.py) marcado explícitamente como 'FIXTURE SINTÉTICO — código fabricado para probar el juez de código' y un manual metodológico también marcado como 'documento fabricado para probar el juez de código'. Ambos documentos declaran que 'No describe ningún modelo real de la entidad'. Esto significa que no hay evidencia de una implementación real que validar. La actividad requiere demostrar conformidad de resultados y trazabilidad de comunicaciones; sin correos, sin logs de UAT, sin aprobaciones formales, no hay nada que demostrar. Para alcanzar puntaje 2 sería necesario: (a) al menos un correo de comunicación de resultados preliminares entre desarrollador e implementador; (b) documentación de pruebas unitarias o de integración ejecutadas (logs, reportes de test); (c) un correo de aprobación formal para paso a producción. La cobertura documental es parcial (solo código y manual, sin comunicaciones ni evidencia de ejecución de controles).

**Evidencia citada.**

> calcula_var.py → """\nCálculo del VaR de mercado por simulación histórica.\n\nFIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente\nVIRF. No es la implementación de ningún modelo real. Ver LEEME.md.\n"""
>
> manual_VaR_drift.md → "> Documento fabricado para probar el juez de código. No describe ningún modelo\n> real de la entidad. Ver `LEEME.md` en la raíz de este árbol."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «\nCálculo del VaR de mercado por simulación histórica.\n\nFIXTURE SINTÉTICO — có»
> - «> Documento fabricado para probar el juez de código. No describe ningún modelo\n»

**Preguntas al modelador.**

- [ ] ¿Existen correos de comunicación entre el equipo de desarrollo (proveedor externo) y la primera línea de riesgos reportando resultados de la implementación? Si existen, ¿en qué fechas se enviaron y qué resultados se reportaron?
- [ ] ¿Se ejecutaron pruebas unitarias o de integración (UAT) sobre el código de implementación? Si existen, ¿dónde están documentadas (logs, reportes de test, actas de UAT)? ¿Quién las ejecutó y quién las aprobó?
- [ ] ¿Existe un correo o acta formal de aprobación para paso a producción? ¿Quién autorizó el paso a producción y en qué fecha?
- [ ] ¿El código proporcionado (calcula_var.py) es la implementación real del modelo VaR Drift o es efectivamente un fixture de prueba? Si es real, ¿por qué contiene la declaración de que es 'código fabricado para probar'?
- [ ] ¿Existe documentación de conformidad de resultados entre la implementación y la especificación metodológica (manual_VaR_drift.md)? Específicamente: ¿se verificó que el parámetro de ventana, nivel de confianza y método de cálculo de retornos en el código coinciden con lo documentado en el manual?

**Recomendación.** Antes de cualquier validación de implementación, proporcionar: (1) Cadena de correos de comunicación de resultados entre desarrollador externo y primera línea, con fechas y contenido de conformidad; (2) Documentación completa de UAT (plan de pruebas, casos de prueba ejecutados, logs de ejecución, resultados, firma de aprobación); (3) Acta o correo de aprobación formal para paso a producción, con autorización del Comité de Riesgos o responsable designado; (4) Confirmación de que el código proporcionado es la versión productiva real, no un fixture de prueba. Sin esta evidencia, no es posible validar conformidad de implementación.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `9cc604a2e494`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica las fuentes de información empleadas

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Verifica coherencia entre documentación de implementación y código ejecutable, y rastrea evidencia de aprobación y ejecución en ambiente controlado (UAT). Es crítico para detectar code drift y asegurar que lo documentado se ejecuta realmente en producción.

**Hallazgo.**

La evaluación revela CUMPLIMIENTO PARCIAL CON BRECHAS CRÍTICAS en la coherencia entre documentación e implementación. El manual declara parámetros específicos que NO se reflejan en el código: (1) VENTANA: el manual fija explícitamente 250 días hábiles como especificación del cálculo, pero calcula_var.py implementa ventana=500 como parámetro por defecto en var_historico(), invalidando la comparabilidad del backtesting Kupiec mencionado en metodología. (2) NIVEL DE CONFIANZA: el manual declara 99% como parámetro fijo sin admitir modificación en tiempo de ejecución, pero el código expone confianza=0.95 como parámetro modificable en var_historico() y var_cartera() no lo especifica, permitiendo ejecución con valor por defecto no documentado. (3) RETORNOS: el manual exige retornos logarítmicos por aditividad temporal, pero retornos_diarios() implementa diferencia relativa simple (precios[1:] - precios[:-1]) / precios[:-1], que es retorno aritmético, no logarítmico. Esta es una desviación metodológica que afecta la escalabilidad del horizonte que el manual justifica. NO SE ENCONTRÓ EVIDENCIA de: correos de aprobación para paso a producción, documentación de UAT, logs de ejecución del backtesting Kupiec mencionado en contexto inter-ámbito (Q1 2026), ni integración de resultados en comités de decisión. El código carece de docstring en var_cartera() explicando cómo se agrega el VaR (suma lineal de contribuciones ponderadas asume correlación perfecta, no documentado). La ausencia de función backtesting_kupiec() mencionada en el manual §3 es una brecha crítica: el manual afirma que el módulo la implementa, pero no existe en el código proporcionado. Para alcanzar puntaje 3 se requiere: (a) alineación de parámetros código-manual con justificación de cualquier desviación, (b) implementación verificable de backtesting_kupiec() con ejecución documentada, (c) corrección de retornos a logarítmicos o justificación explícita de por qué se usa aritmético, (d) evidencia de UAT y aprobación formal.

**Evidencia citada.**

manual_VaR_drift.md → "El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un año de observaciones."

manual_VaR_drift.md → "El **nivel de confianza es del 99 %** y el horizonte de mantenimiento es de **1 día**. Ambos parámetros son fijos: no se admite su modificación en tiempo de ejecución sin aprobación del Comité de Riesgos."

manual_VaR_drift.md → "Los rendimientos de los factores de riesgo se calculan como **retornos logarítmicos**, por su propiedad de aditividad temporal, que es la que permite escalar el horizonte cuando procede."

manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995)."

calcula_var.py → ```
def var_historico(retornos, confianza=0.95, ventana=500):
    muestra = retornos[-ventana:]
    return -np.percentile(muestra, (1 - confianza) * 100)
```

calcula_var.py → ```
def retornos_diarios(precios):
    return (precios[1:] - precios[:-1]) / precios[:-1]
```

calcula_var.py → ```
def var_cartera(precios_por_factor, pesos):
    total = 0.0
    for serie, peso in zip(precios_por_factor, pesos):
        total += peso * var_historico(retornos_diarios(serie))
    return total
```

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El módulo implementa la función `backtesting_kupiec()`, que contrasta el número »
> - «def var_historico(retornos, confianza=0.95, ventana=500): muestra = retornos[-ve»
> - «def retornos_diarios(precios): return (precios[1:] - precios[:-1]) / precios[:-1»
> - «def var_cartera(precios_por_factor, pesos): total = 0.0 for serie, peso in zip(p»
> - «El **nivel de confianza es del 99 %** ... Ambos parámetros son fijos: no se admi»
> - «def retornos_diarios(precios): return (precios[1:] - precios[:-1]) / precios[:-1»
> - «No se encontró la función backtesting_kupiec() en el código proporcionado»

**Preguntas al modelador.**

- [ ] ¿Existen correos de aprobación formal del Comité de Riesgos para los parámetros (ventana=250, confianza=99%) y para el paso a producción de calcula_var.py? Si existen, ¿autorizan explícitamente los valores que el código implementa (ventana=500, confianza=0.95)?
- [ ] ¿Por qué el código implementa ventana=500 y confianza=0.95 si el manual fija 250 y 99%? ¿Fue una decisión posterior documentada y aprobada, o es un code drift no controlado?
- [ ] ¿Dónde está la implementación de backtesting_kupiec() mencionada en el manual §3? ¿Se ejecutó el backtesting Kupiec referenciado en contexto inter-ámbito (Q1 2026)? ¿Existen logs o reportes de esa ejecución?
- [ ] ¿Por qué retornos_diarios() usa diferencia relativa simple en lugar de logarítmica? ¿Fue una desviación justificada y aprobada, o un error de implementación?
- [ ] ¿Existe documentación de UAT (User Acceptance Testing) que valide que calcula_var.py implementa correctamente el manual metodológico? ¿Quién firmó esa validación y cuándo?
- [ ] ¿Se integran los resultados del VaR (y del backtesting, si existe) en algún comité de riesgos o en decisiones de gestión de cartera? ¿Existen actas o reportes que lo demuestren?
- [ ] ¿Cuál es la versión actual de calcula_var.py en producción? ¿Coincide con la proporcionada en el contexto, o ha habido cambios no documentados?

**Recomendación.** ACCIÓN INMEDIATA: (1) Alinear parámetros en calcula_var.py con el manual (ventana=250, confianza=0.99) o documentar y obtener aprobación formal de cualquier desviación. (2) Corregir retornos_diarios() para usar logarítmicos (np.log(precios[1:]/precios[:-1])) o justificar explícitamente por qué se usa aritmético y cómo se escala el horizonte sin aditividad. (3) Implementar y documentar la función backtesting_kupiec() con ejecución verificable sobre datos reales. (4) Obtener y archivar correos de aprobación del Comité de Riesgos para los parámetros finales y para el paso a producción. (5) Documentar y ejecutar UAT formal con firma de conformidad. (6) Generar un informe de reconciliación manual vs código que justifique cada diferencia encontrada. Hasta que estas brechas se cierren, el modelo no puede considerarse validado para producción, ya que no hay evidencia de que lo documentado se ejecuta realmente ni de que ha sido aprobado formalmente.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `64372a9bb574`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Validación de coherencia entre documentación metodológica e implementación de código para el modelo VaR Drift. Esta actividad es crítica porque detecta desviaciones no documentadas (code drift) que invalidan la trazabilidad regulatoria y comprometen la confiabilidad del modelo en producción.

**Hallazgo.**

La evaluación revela CUMPLIMIENTO PARCIAL CON BRECHAS CRÍTICAS entre la documentación y la implementación. El manual declara explícitamente una ventana de 250 días hábiles y nivel de confianza del 99%, pero el código implementa parámetros por defecto de 500 días y 95%, lo que invalida completamente la comparabilidad del backtesting y la validez de cualquier control basado en estos resultados. Adicionalmente, el manual especifica retornos logarítmicos como metodología de cálculo (por su propiedad de aditividad temporal), pero el código implementa retornos simples (diferencia relativa). Esta contradicción es fundamental: los retornos logarítmicos y simples producen distribuciones diferentes, especialmente en colas, lo que afecta directamente la estimación del VaR. No existe evidencia de: (i) correos de aprobación para paso a producción, (ii) documentación de pruebas UAT que validen la implementación contra la especificación, (iii) logs de ejecución del backtesting Kupiec mencionado en el manual, (iv) control de cambios que justifique por qué los parámetros por defecto difieren de la especificación. El manual menciona la función `backtesting_kupiec()` pero no existe en el código proporcionado. Para alcanzar nivel 3 se requiere: reconciliación explícita de parámetros (código vs manual), implementación de la función de backtesting documentada, evidencia de ejecución con datos reales, y aprobación formal del cambio de especificación si los parámetros por defecto son intencionales.

**Evidencia citada.**

manual_VaR_drift.md → "El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un año de observaciones."

calcula_var.py → ```
def var_historico(retornos, confianza=0.95, ventana=500):
    muestra = retornos[-ventana:]
    return -np.percentile(muestra, (1 - confianza) * 100)
```

manual_VaR_drift.md → "El **nivel de confianza es del 99 %**"

manual_VaR_drift.md → "Los rendimientos de los factores de riesgo se calculan como **retornos logarítmicos**, por su propiedad de aditividad temporal"

calcula_var.py → ```
def retornos_diarios(precios):
    return (precios[1:] - precios[:-1]) / precios[:-1]
```

manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995)"

No se encontró evidencia en el contexto disponible de: correos de aprobación para paso a producción, documentación de UAT, logs de ejecución del backtesting, o función `backtesting_kupiec()` en el código.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «def var_historico(retornos, confianza=0.95, ventana=500): muestra = retornos[-ve»
> - «def retornos_diarios(precios): return (precios[1:] - precios[:-1]) / precios[:-1»
> - «def retornos_diarios(precios): return (precios[1:] - precios[:-1]) / precios[:-1»
> - «No se encontró la función `backtesting_kupiec()` en el código proporcionado»

**Preguntas al modelador.**

- [ ] ¿Los parámetros por defecto en el código (ventana=500, confianza=0.95) son intencionales o representan un cambio no documentado respecto a la especificación (250 días, 99%)? Si son intencionales, ¿existe aprobación formal del Comité de Riesgos para esta desviación?
- [ ] ¿Por qué el código implementa retornos simples en lugar de retornos logarítmicos como especifica el manual? ¿Se evaluó el impacto de esta diferencia en la estimación del VaR y en los resultados del backtesting?
- [ ] ¿Dónde está implementada la función `backtesting_kupiec()` mencionada en el manual? ¿Existe en otro fichero no proporcionado, o la documentación describe una funcionalidad no implementada?
- [ ] ¿Existen correos de aprobación, actas de comité o documentación de cambios que autoricen la desviación entre la especificación del manual y la implementación del código?
- [ ] ¿Se ejecutó alguna prueba UAT que validara la implementación contra la especificación del manual? Si existe, ¿cuáles fueron los resultados y cómo se resolvieron las discrepancias?
- [ ] ¿Existen logs o reportes de ejecución del backtesting Kupiec mencionado en el manual? ¿Cuáles fueron los resultados y en qué fecha se ejecutó?
- [ ] ¿La función `var_cartera()` suma las contribuciones de VaR por factor de forma aditiva? ¿Se justifica esta aproximación o se requiere un enfoque de correlación/covarianza?
- [ ] ¿Existe documentación de control de cambios que registre cuándo y por qué se modificaron los parámetros por defecto del código respecto a la especificación original?

**Recomendación.** ACCIÓN INMEDIATA REQUERIDA: (1) Reconciliar parámetros: alinear el código con la especificación del manual (ventana=250, confianza=0.99) O documentar formalmente y obtener aprobación del Comité de Riesgos para cualquier desviación. (2) Corregir la fórmula de retornos: implementar retornos logarítmicos (np.log(precios[1:]/precios[:-1])) en lugar de retornos simples, o justificar por escrito por qué se usa la aproximación simple y validar su impacto en el VaR. (3) Implementar o localizar la función `backtesting_kupiec()` documentada; si no existe, actualizar el manual para reflejar la funcionalidad real. (4) Documentar y ejecutar pruebas UAT que validen la implementación contra la especificación; generar reporte con resultados y resolución de discrepancias. (5) Crear un registro de control de cambios que justifique cualquier desviación entre manual e implementación, con aprobaciones formales. (6) Generar logs de ejecución del backtesting con datos reales y archivarlos como evidencia de cumplimiento. Hasta que estas brechas se cierren, el modelo NO debe pasar a producción.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `bf857c80c6cc`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificación de coherencia entre documentación metodológica e implementación de código, y validación de que las pruebas iniciales (UAT, backtesting, controles) están documentadas y ejecutadas antes de paso a producción. Esta actividad es crítica porque detecta desviaciones entre lo que se dice que hace el modelo y lo que realmente ejecuta.

**Hallazgo.**

La evaluación revela CUMPLIMIENTO PARCIAL CON BRECHAS CRÍTICAS entre documentación e implementación. Se identifican dos contradicciones directas que invalidan la comparabilidad del backtesting y comprometen la validez del modelo en producción: (1) El manual especifica una ventana de 250 días hábiles y nivel de confianza del 99%, pero el código implementa 500 días y 95% por defecto, sin documentación de esta desviación ni justificación de por qué se cambió. (2) El manual declara explícitamente que los rendimientos se calculan como retornos logarítmicos, pero el código implementa retornos simples (diferencia relativa). Estas no son preferencias metodológicas: son cambios de especificación que alteran completamente el comportamiento del modelo. Además, no existe evidencia de: (a) ejecución real del backtesting Kupiec mencionado en el manual; (b) correos de aprobación de primera línea sobre estos resultados; (c) documentación de UAT que valide que el código implementado cumple con la especificación; (d) logs o reportes que demuestren que el backtesting se ejecutó con datos reales antes de paso a producción. El manual menciona la función `backtesting_kupiec()` pero no aparece en el código proporcionado. La ausencia de esta función es crítica: sin ella, no hay forma de verificar que el modelo cumple con el estándar de cobertura incondicional de Kupiec que el manual declara como requisito. Para alcanzar nivel 3 se requiere: (i) reconciliación documentada de los parámetros (ventana, confianza, tipo de retorno) con justificación de cualquier desviación; (ii) implementación visible del backtesting Kupiec en el código; (iii) evidencia de ejecución sobre datos históricos reales con resultados reportados; (iv) correos de conformidad de primera línea; (v) documentación de UAT que cierre la brecha entre especificación y código.

**Evidencia citada.**

manual_VaR_drift.md → "El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un año de observaciones."

manual_VaR_drift.md → "El **nivel de confianza es del 99 %** y el horizonte de mantenimiento es de **1 día**."

manual_VaR_drift.md → "Los rendimientos de los factores de riesgo se calculan como **retornos logarítmicos**, por su propiedad de aditividad temporal."

manual_VaR_drift.md → "El módulo implementa la función `backtesting_kupiec()`, que contrasta el número de excepciones observadas contra el intervalo de confianza de la prueba de cobertura incondicional de Kupiec (1995)."

calcula_var.py → ```
def var_historico(retornos, confianza=0.95, ventana=500):
    muestra = retornos[-ventana:]
    return -np.percentile(muestra, (1 - confianza) * 100)
```

calcula_var.py → ```
def retornos_diarios(precios):
    return (precios[1:] - precios[:-1]) / precios[:-1]
```

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Los rendimientos de los factores de riesgo se calculan como **retornos logarítmi»
> - «El módulo implementa la función `backtesting_kupiec()`, que contrasta el número »
> - «def var_historico(retornos, confianza=0.95, ventana=500): muestra = retornos[-ve»
> - «def retornos_diarios(precios): return (precios[1:] - precios[:-1]) / precios[:-1»
> - «def retornos_diarios(precios): return (precios[1:] - precios[:-1]) / precios[:-1»

**Preguntas al modelador.**

- [ ] ¿Existe documentación de UAT que valide que calcula_var.py implementa correctamente la especificación del manual_VaR_drift.md? ¿Quién aprobó las desviaciones en ventana (250 vs 500), confianza (99% vs 95%) y tipo de retorno (logarítmico vs simple)?
- [ ] ¿Dónde está implementada la función `backtesting_kupiec()` mencionada en el manual? No aparece en calcula_var.py. ¿Existe en otro fichero (.py, .ipynb) que no se proporcionó?
- [ ] ¿Se ejecutó el backtesting Kupiec sobre datos históricos reales antes de paso a producción? ¿Existen logs, reportes o correos que documenten los resultados y la conformidad de primera línea?
- [ ] ¿Cuál es la fecha de aprobación del paso a producción y quién la autorizó? ¿Se documentó en un correo o en un acta de comité?
- [ ] ¿Por qué se implementó retornos simples en lugar de logarítmicos? ¿Fue una decisión consciente o un error de implementación? ¿Está documentada en algún correo o en un changelog?
- [ ] ¿Se ejecutó algún test de coherencia entre el manual y el código (por ejemplo, comparar el VaR calculado con ambas especificaciones sobre los mismos datos)?
- [ ] ¿Existe documentación de cómo se tratan los días con datos incompletos o mercados cerrados en la ventana de 250 (o 500) observaciones?
- [ ] ¿Se realizó backtesting sobre P&L hipotético (cartera congelada) o sobre P&L real? El manual no lo especifica, pero es crítico para interpretar las excepciones.

**Recomendación.** ANTES de paso a producción: (1) Reconciliar parámetros: fijar ventana en 250 días, confianza en 99%, retornos logarítmicos, y documentar cualquier desviación con aprobación escrita del Comité de Riesgos. (2) Implementar y ejecutar backtesting_kupiec() sobre datos históricos reales (mínimo 1 año de P&L hipotético). Documentar el número de excepciones, el estadístico LR, el p-valor y la conclusión (zona verde/amarilla/roja de Basilea). (3) Generar UAT formal que valide que el código implementado cumple con la especificación del manual, con casos de prueba que cubran: cálculo de retornos, ventana móvil, percentil, agregación de cartera. (4) Obtener correo de aprobación de primera línea (modelo) y segunda línea (riesgos) sobre los resultados del backtesting y la conformidad con la especificación. (5) Documentar en un changelog o en un anexo al manual cualquier desviación entre la especificación original y la implementación final, con justificación técnica. (6) Establecer un control en el pipeline productivo que ejecute el backtesting Kupiec mensualmente y alerte si el número de excepciones sale del intervalo de confianza.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `5569aaacab0d`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Uso e integración a la gestión  ·  score 1.0

#### 🔴 [1/5] Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo

*Control: Revisión de los usos, impactos y usuarios del modelo*

**Qué evalúa.** Verificación de que los usos del modelo VaR en producción se alinean con su alcance original, que los usuarios están formalmente identificados, y que existe reporting de integración a la gestión. Esta actividad es crítica para asegurar que el modelo no se desvía hacia aplicaciones no validadas ni se usa sin supervisión.

**Hallazgo.**

No se encontró NINGUNA evidencia de identificación formal de usuarios, documentación de usos en producción, reportes de seguimiento a comités, o verificación de alineación entre alcance original y usos actuales. El contexto disponible contiene únicamente un script de cálculo (`calcula_var.py`) sin metadatos sobre quién lo usa, para qué, o cómo se integra en la gestión. No hay manuales de usuario, actas de comités, reportes de seguimiento, logs de ejecución en producción, ni documentación de cambios de alcance. La ausencia es completa en los tres ejes críticos: (1) identificación de usuarios finales, (2) documentación de usos y propósitos, (3) evidencia de reporting periódico a órganos de gobierno. Esto impide verificar si el modelo está siendo usado dentro de su alcance validado o si ha derivado hacia aplicaciones no autorizadas. Para alcanzar puntaje 2 se requeriría al menos: un documento que liste usuarios y sus funciones, un manual de usuario o guía de integración, y un reporte de seguimiento (aunque sea incompleto) presentado a algún comité. Para puntaje 3 se necesitaría además: evidencia de ejecución periódica en producción, trazabilidad de cambios de alcance, y actas de revisión de usos.

**Evidencia citada.**

> calcula_var.py → """Cálculo del VaR de mercado por simulación histórica. FIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente VIRF. No es la implementación de ningún modelo real."" — El script es explícitamente un fixture de prueba, no código de producción. No contiene información sobre usuarios, propósito operativo, integración a sistemas, ni contexto de uso.
>
> No se encontró en el contexto disponible: (a) documento de alcance original del modelo, (b) lista de usuarios identificados, (c) descripción de usos autorizados, (d) reportes de seguimiento a comités, (e) logs de ejecución en producción, (f) documentación de cambios de alcance, (g) actas de revisión de usos.

**Preguntas al modelador.**

- [ ] ¿Quiénes son los usuarios finales del modelo VaR Drift en producción? (Proporcionar lista con nombres, áreas, funciones específicas)
- [ ] ¿Cuál es el alcance original documentado del modelo? (Proporcionar acta de aprobación, especificación de requisitos, o documento de diseño que defina para qué fue construido)
- [ ] ¿Cuáles son los usos autorizados del modelo? (Proporcionar manual de usuario, guía de integración, o documento de gobernanza que especifique aplicaciones permitidas)
- [ ] ¿Existe un reporte de seguimiento periódico de usos? (Proporcionar reportes presentados a comités de riesgo, validación o gobierno en los últimos 12 meses)
- [ ] ¿Cómo se integra el modelo en los sistemas de gestión de riesgo? (Proporcionar documentación de interfaces, flujos de datos, y puntos de decisión donde se usa el output)
- [ ] ¿Se ha documentado algún cambio de alcance o extensión de usos desde la validación inicial? (Proporcionar actas de cambio, justificaciones, y re-validaciones si aplica)
- [ ] ¿Existe un control de acceso y auditoría de quién ejecuta el modelo y cuándo? (Proporcionar logs de ejecución, permisos asignados, o matriz de responsabilidades)

**Recomendación.** Antes de autorizar el uso en producción, completar la siguiente documentación de gobernanza: (1) Inventario formal del modelo con identificación de usuarios, propósito, alcance y tier de criticidad; (2) Manual de usuario que especifique aplicaciones autorizadas, limitaciones, y criterios de uso; (3) Matriz de integración que documente cómo el output se usa en decisiones de riesgo; (4) Protocolo de seguimiento periódico (trimestral mínimo) que reporte a comité de riesgo: número de ejecuciones, usuarios activos, cambios de alcance detectados, y cualquier desviación respecto al propósito original; (5) Acta de aprobación de alcance firmada por propietario del modelo y usuario final, con fecha de revisión programada. Sin esta evidencia, el modelo no puede considerarse integrado a la gestión de forma controlada.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `9f3bddb4a731`</sub>

> ✍️ _Conclusión del validador:_
>
---

## 6. Limitaciones del alcance

**Esta sección es obligatoria en el informe final.** Un dictamen que no
declara qué quedó fuera no permite distinguir «esto está bien» de «esto
no se miró».

| Concepto | Valor |
|---|---:|
| Actividades evaluadas correctamente | 28 |
| Actividades sin evidencia | 0 |
| Actividades con fallo técnico | 0 |

**74 cita(s) sin verificar literalmente.** Marcadas en
el detalle. Revísalas antes de firmar.

> ✍️ **Te toca:** traslada esta sección al informe final tal cual.
> Es lo que un supervisor busca primero.

---

<sub>Generado por VIRF 27.1 · claude-haiku-4-5-20251001 el 2026-09-02 13:45. Documento de trabajo interno; el entregable es el informe Word. El agente no firma: firma el validador.</sub>
