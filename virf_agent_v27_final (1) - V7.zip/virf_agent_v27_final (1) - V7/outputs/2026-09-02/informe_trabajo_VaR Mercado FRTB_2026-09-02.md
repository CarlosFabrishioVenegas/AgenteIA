# Informe de validación — VaR Mercado FRTB

> **BORRADOR DE TRABAJO.** Este documento lo genera el agente VIRF para
> que el validador humano lo revise, corrija y redacte el informe final.
> **No es el entregable** y no sustituye el criterio de quien firma.

| | |
|---|---|
| Modelo | VaR Mercado FRTB |
| Tier | 1 |
| Fecha | 2026-09-02 |
| Agente | 27.1 · claude-haiku-4-5-20251001 |
| Score global | **2.55** — CON OBSERVACIONES |
| Posición en cadena de custodia | 4 |
| Hash del informe | `7effbac99183a36ebfd6cb3c5fc622ae` |

> 🔴 **DICTAMEN NO CONFIABLE.** El agente no pudo evaluar una parte
> suficiente del estándar. Revisa la sección de limitaciones antes de
> usar cualquier cifra de este documento.

## 0-bis. Políticas del procedimiento aplicadas

El agente ha detectado condiciones que `PROCEDIMIENTO_VALIDACION.md`
trata como automáticas. **La decisión formal la firma el validador**
(§1 del procedimiento); esto solo declara lo que no puede pasarse por
alto.

### §6 — Hallazgos críticos automáticos

Ámbitos con score ≤ 2, marcados como críticos sin depender del juicio:

- **Gobierno** — score 2.0
- **Implementación** — score 2.0
- **Uso e integración a la gestión** — score 2.0

Un hallazgo crítico se eleva al Comité de Riesgos en su siguiente
sesión, con copia inmediata al dueño del modelo (§6).

### §4.2 — Ámbito por debajo del umbral bloqueante

Ámbitos con score < 2.5. La política **impide la aprobación aunque el
score global la supere**:

- **Gobierno** — score 2.0
- **Implementación** — score 2.0
- **Uso e integración a la gestión** — score 2.0

## 0. Cómo leer este documento

**El score no es la conclusión.** Es un resumen con pérdida de información,
útil para priorizar por dónde empezar e inútil para concluir nada. Lo que
sostiene un dictamen son las citas y el razonamiento, no el número.

### La escala, y qué exige cada nivel

| | Significa | Para darlo hace falta |
|---|---|---|
| **1** | No cumple | Ausencia total de evidencia sobre el tema |
| **2** | Brechas críticas | Se menciona, pero no se ejecuta o falta lo esencial |
| **3** | Brechas no críticas | Implementado **y ejecutado**, con huecos menores |
| **4** | Observaciones menores | Además, la elección está **justificada** |
| **5** | Cumple plenamente | Además, supuestos verificados y límites declarados |

El eje no es «cuánto se habla del tema», es **cuánto está demostrado**. El 5
es poco frecuente por diseño: exige poder defenderlo ante un supervisor con
las citas en la mano.

### Las cinco trampas que el agente busca

Cosas que aparentan cumplimiento y no lo son. Si vas a discutir un puntaje,
empieza por comprobar cuál de estas aplica:

| Trampa | Ejemplo |
|---|---|
| Documentado ≠ correcto | Manual impecable que describe una decisión equivocada |
| Existe ≠ se ejecuta | Script de backtesting que nadie corrió |
| Se menciona ≠ se justifica | «Se aplica la metodología X» sin decir por qué X |
| Se cita ≠ lo sostiene | Un paper que no dice lo que el manual afirma |
| Se calcula ≠ se usa | Métrica que no llega a ningún comité |

### Dos cosas que NO son lo mismo

- **Ausencia de evidencia** — el agente no lo encontró en lo que pudo leer.
  Es una limitación del alcance, y se declara como tal.
- **Incumplimiento** — la evidencia está y muestra una deficiencia.

Confundirlas es el error más caro al redactar: acusa al modelador de algo
que quizá sí documentó, solo que en una página que no cupo en el contexto.
Revisa siempre la **cobertura documental** antes de convertir un puntaje
bajo en un hallazgo.

### Qué te toca a ti

Los bloques **✍️** marcan dónde el documento espera tu criterio. El agente
propone; el validador dispone y firma. Ninguna cifra de aquí es definitiva
hasta que la revisas.

## 1. Resumen por ámbito

Ordenados **de peor a mejor**: por ahí se empieza.

| Ámbito | Score | Peso | Aporta al global | Lectura |
|---|---:|---:|---:|---|
| Gobierno | 2.0 | 12% | 0.24 | 🟠 Cumple parcialmente — observaciones críticas |
| Implementación | 2.0 | 15% | 0.30 | 🟠 Cumple parcialmente — observaciones críticas |
| Uso e integración a la gestión | 2.0 | 8% | 0.16 | 🟠 Cumple parcialmente — observaciones críticas |
| Calidad de datos | 2.83 | 20% | 0.57 | 🟡 Cumple parcialmente |
| Metodología | 2.83 | 30% | 0.85 | 🟡 Cumple parcialmente |
| Documentación | 2.89 | 15% | 0.43 | 🟡 Cumple parcialmente |

> ✍️ **Te toca:** el ámbito con peor score no siempre es el más urgente —
> mira la columna «aporta al global». Un 2 en Metodología (peso 30 %) pesa
> casi cuatro veces más que un 2 en Uso e integración (8 %).

## 2. Inconsistencias entre fuentes

**43 contradicción(es)** entre lo documentado y lo implementado.
Cada una trae las dos citas enfrentadas para que puedas verificarla en el
documento original.

### 2.1 [ALTA] El manual afirma que existe control de cambios documentado en anexo A, pero ese anexo no está disponible para validación. No se puede verificar si el control existe, qué estructura tiene, si registra cambios históricos, autorización, o frecuencia de revisión. Esto impide auditar la trazabilidad de decisiones metodológicas y cumplimiento de SR 11-7 (documentación de gobierno).

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> Control de cambios en anexo A

**CONTEXTO DISPONIBLE** dice:
> Anexo A no incluido en la cobertura documental

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.2 [ALTA] El objetivo declara que el modelo estima VaR para la cartera de negociación bajo FRTB, pero la sección de limitaciones reconoce que no captura riesgo de liquidez y se complementa con ES. Esto implica que el modelo NO es autosuficiente para el propósito FRTB (que exige ES como medida principal, no VaR). El manual no aclara si este VaR es una medida complementaria, un legado, o si la entidad aún no ha migrado completamente a ES. Sin esta clarificación, no está documentado cuál es el VERDADERO uso del modelo en la toma de decisiones de capital.

*Ámbito: Documentación · Actividad: Verifica la inclusión del objetivo, usos y usuarios del modelo*

**manual_VaR_FRTB.md** dice:
> ## 1. Objetivo\nEstimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III).

**manual_VaR_FRTB.md** dice:
> ## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.3 [ALTA] El manual cita el anexo C como justificación de la ventana de 500 días, pero el anexo C no está en el contexto disponible. No se puede verificar si el estudio de sensibilidad existe, si es riguroso, o si la conclusión (500 días es óptimo) está bien fundamentada. El resumen de Kupiec describe la prueba LR pero no valida la afirmación del manual sobre qué ventanas producen excedencias fuera del intervalo. Esto es SE MENCIONA ≠ SE JUSTIFICA: la decisión está documentada pero no verificable.

*Ámbito: Documentación · Actividad: Verifica la existencia , suficiencia y claridad de la documentación*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**kupiec_1995_resumen.md** dice:
> Propone la prueba de razón de verosimilitud (LR) para contrastar si la tasa de excedencias observada es consistente con el nivel de confianza declarado.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.4 [ALTA] El manual afirma que la justificación existe en el anexo C, pero ese anexo no está disponible para verificación. Esto es una REFERENCIA A EVIDENCIA NO ENTREGADA, no una contradicción interna, pero invalida la verificabilidad de la afirmación. El validador no puede confirmar si la ventana de 500 días está realmente justificada o si es una decisión no documentada que se atribuye falsamente a un análisis.

*Ámbito: Documentación · Actividad: Verificar la coherencia del manual de implementación con el manual métodolocios*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**contexto disponible** dice:
> Anexo C no proporcionado en el contexto

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.5 [ALTA] El manual afirma que la justificación existe (anexo C) pero la evidencia no está disponible para validación. Esto impide verificar si la elección de 500 días está realmente fundamentada o es una afirmación sin respaldo verificable. Riesgo: la ventana podría haber sido elegida arbitrariamente, y el backtesting podría estar validando un parámetro injustificado.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**contexto disponible** dice:
> El anexo C no está incluido en la documentación proporcionada

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.6 [ALTA] El manual declara que existe un control de cambios documentado en el anexo A, pero ese anexo no está disponible para verificación. Esto impide confirmar si el control de cambios es operativo, quién lo autoriza, cuándo se ejecutan cambios, y si hay trazabilidad entre versiones del manual y del código. Un control de cambios no verificable no cumple con los estándares de gobernanza de modelos de riesgo.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> Control de cambios en anexo A.

**contexto disponible** dice:
> El anexo A no está incluido en los documentos proporcionados.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.7 [ALTA] El manual justifica la ventana de 500 días citando un estudio de sensibilidad (anexo C) que no está disponible. El backtesting Q1 2026 muestra 3 excedencias en 62 días (tasa observada: 4.84%), muy por encima de la esperada (0.62% al 99%). Aunque el test de Kupiec no rechaza al 5% (p=0.051), la tasa observada es 7.8 veces la esperada. Sin acceso al anexo C no es posible verificar si este resultado fue anticipado en el análisis de sensibilidad, si la ventana de 500 días sigue siendo óptima, o si se requiere revisión metodológica. La ausencia de ambos anexos impide validar la justificación de parámetros clave.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.8 [ALTA] El manual cita un anexo (C) como justificación de la elección metodológica clave (ventana de 500 días), pero ese anexo no está disponible para validación independiente. Esto impide verificar si el análisis de sensibilidad es correcto, si los criterios de exclusión fueron apropiados, y si la conclusión (500 días es óptimo) está realmente soportada. Riesgo: la decisión metodológica más importante del modelo descansa en una referencia no verificable.

*Ámbito: Documentación · Actividad: Verificar la existencia, suficiencia y claridad de la documentación*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**CONTEXTO DISPONIBLE** dice:
> Anexo C no proporcionado en el contexto de validación

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.9 [ALTA] La matriz de motores de calidad reporta tres fallos críticos en datos (integridad referencial, rango de tasas, outliers en saldos) sin que el manual del VaR FRTB mencione cómo estos fallos afectan la cartera de negociación ni qué controles específicos se aplican para mitigarlos. El manual declara limitaciones (riesgo de liquidez) pero omite completamente la limitación de calidad de datos, que es más fundamental. No hay trazabilidad de si estos fallos aplican a la cartera VaR o a otra línea de negocio.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**motores_calidad_2026Q1.xlsx** dice:
> Integridad referencial Cuenta→Cliente,1.8,FALLA,2.168 cuentas sin cliente maestro. / Rango de Tasa de Interés (0-100),14.7,FALLA,Valores negativos y >100 en la serie histórica. / Outliers en Saldo,,FALLA,Se detectan colas anómalas; no se cuantificó.

**manual_VaR_FRTB.md** dice:
> ## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.10 [ALTA] El perfil de datos documenta que se imputan valores ausentes por último valor conocido (forward fill), pero el manual metodológico NO menciona este tratamiento ni justifica por qué es válido para un modelo VaR histórico. La imputación por forward fill introduce sesgo en los retornos (reduce volatilidad en períodos de datos faltantes) y puede invalidar el backtesting de Kupiec si los días imputados coinciden con movimientos de mercado significativos. No hay evidencia de que se haya validado el impacto de esta imputación en la estimación del VaR.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**perfil_datos_VaR.md** dice:
> 0.4% de valores ausentes, imputados por último valor conocido.

**manual_VaR_FRTB.md** dice:
> ## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.11 [ALTA] El reporte de calidad de datos documenta una falla crítica (1.8% de cuentas huérfanas) que invalida la trazabilidad de la cartera, pero el manual VaR no la reconoce ni discute sus implicaciones. Esto sugiere que el modelo se está ejecutando sobre datos cuya integridad no está garantizada, y que el control de calidad no está integrado en la gobernanza del modelo.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**motores_calidad_2026Q1.xlsx** dice:
> Integridad referencial Cuenta→Cliente,1.8,FALLA,2.168 cuentas sin cliente maestro.

**manual_VaR_FRTB.md** dice:
> No contiene mención alguna de fallas de integridad referencial, ni de su impacto en la validez del modelo VaR.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.12 [ALTA] El perfil de datos declara imputación por último valor conocido (forward fill), pero el manual no documenta esta decisión ni justifica por qué es válida para un modelo de VaR histórico. En series financieras, forward fill introduce sesgo de dependencia artificial y puede distorsionar la distribución de retornos, especialmente en períodos de volatilidad. La ausencia de justificación es una brecha de control.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**perfil_datos_VaR.md** dice:
> 0.4% de valores ausentes, imputados por último valor conocido.

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. [Sin mención del tratamiento de faltantes ni su justificación]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.13 [ALTA] Se reporta detección de outliers pero sin cuantificación ni criterio de acción. El manual VaR no especifica si los outliers se excluyen, se ajustan, o se mantienen. Esto es crítico porque outliers en saldos pueden sesgar la estimación de VaR si no se tratan explícitamente. La falta de criterio documentado implica que la decisión es ad hoc o inexistente.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**motores_calidad_2026Q1.xlsx** dice:
> Outliers en Saldo,,FALLA,Se detectan colas anómalas; no se cuantificó.

**manual_VaR_FRTB.md** dice:
> No contiene criterios de detección, cuantificación o tratamiento de outliers.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.14 [ALTA] La justificación de la ventana de 500 días se remite a un documento (anexo C) que no está disponible para verificación. Esto impide validar si la decisión está realmente fundamentada o si es una referencia circular. Riesgo: la justificación no es verificable de forma independiente.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**contexto disponible** dice:
> El anexo C no está incluido en el contexto de validación

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.15 [ALTA] El manual remite a un anexo (C) que contiene la justificación central de la elección de ventana (500 vs 250 días), pero ese anexo no está disponible para verificación. Sin acceso a él, no puede validarse si la justificación es empírica o asertiva. Esto es crítico porque la ventana es el parámetro más sensible en VaR histórico.

*Ámbito: Metodología · Actividad: Validar supuestos y consideración más importantes de la técnica utilizada*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**contexto disponible** dice:
> Anexo C no incluido en la cobertura documental

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.16 [ALTA] El backtesting reporta un p-valor de 0.051 (marginal, apenas no rechaza al 5%) con solo 62 observaciones y 3 excedencias observadas vs 0.62 esperadas. La literatura estándar advierte que Kupiec tiene baja potencia incluso con 250 observaciones; con 62, la capacidad de detectar un modelo mal calibrado es aún menor. Un p-valor marginal con muestra pequeña no acredita adecuación del modelo. El manual NO declara esta limitación, lo que induce a una falsa confianza en el resultado.

*Ámbito: Metodología · Actividad: Validar supuestos y consideración más importantes de la técnica utilizada*

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051)

**kupiec_1995_resumen.md + literatura de dominio** dice:
> La prueba tiene poca potencia con muestras cortas: con 250 observaciones y un nivel del 99%, el número esperado de excedencias es 2,5, y el contraste difícilmente distingue un modelo correcto de uno moderadamente mal calibrado.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.17 [ALTA] El manual usa VaR 99% como metodología de backtesting, pero FRTB (Basilea III 2019) reemplazó VaR por ES como medida de capital regulatorio. No se justifica por qué VaR 99% sigue siendo válido para validación interna del modelo si el capital se calcula con ES. Esto crea un riesgo de desalineación: el modelo validado puede no ser el que se usa para decisiones de capital.

*Ámbito: Metodología · Actividad: Revisión de los lineamiento internacionales o nacionales*

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días, nivel de confianza 99%

**FRTB_BCBS457_riesgo_mercado.pdf (pericia de dominio)** dice:
> El marco revisado sustituye el Valor en Riesgo (VaR) al 99 % como medida de capital por el Expected Shortfall (ES) al 97,5 %

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.18 [ALTA] El manual afirma que ventanas <250 días generan excedencias fuera del intervalo de Kupiec, pero el backtesting actual (con ventana de 500 días) reporta 3 excedencias en 62 días, lo que es 4.8% vs 0.62% esperado. Aunque Kupiec no rechaza al 5%, la tasa observada (4.8%) está 7.7x por encima de la esperada. Esto sugiere que el estudio de sensibilidad del anexo C puede no haber sido suficientemente robusto, o que 500 días tampoco es óptimo. Sin acceso al anexo C no puede verificarse si la conclusión es válida.

*Ámbito: Metodología · Actividad: Analizar el seguimeinto de la metodología*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.19 [ALTA] El manual documenta aprobación de la metodología por Comité, pero no proporciona acta formal de asignación de tiering ni su justificación. La aprobación de metodología no equivale a documentación de gobierno de tiering. Riesgo: el modelo puede estar técnicamente correcto pero no gobernado conforme a marcos de segunda línea.

*Ámbito: Gobierno · Actividad: Revisar la actualización del tiering del modelo*

**manual_VaR_FRTB.md** dice:
> Aprobado por el Comité de Riesgos el 2026-03-15

**Instrucciones específicas para este ámbito** dice:
> Solo aceptar actas formales firmadas. Un correo NO equivale a acta. Verificar tiering asignado y su justificación.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.20 [ALTA] El manual declara que existe un anexo de control de cambios, pero no está disponible para auditoría. Esto impide verificar si ha habido cambios no documentados entre la versión aprobada (2026-03-15) y la implementación actual, y si esos cambios fueron autorizados.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**manual_VaR_FRTB.md** dice:
> Control de cambios en anexo A

**contexto disponible** dice:
> No se encontró anexo A en el contexto

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.21 [ALTA] El manual afirma que existe un informe de seguimiento con resultados de backtesting, pero no está disponible. Sin él, no se puede verificar si el backtesting mensual se ejecuta realmente, si los resultados están dentro de los intervalos de Kupiec, ni si se han tomado acciones correctivas ante excedencias.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**manual_VaR_FRTB.md** dice:
> Resultados del último trimestre en el informe de seguimiento

**contexto disponible** dice:
> No se encontró informe de seguimiento en el contexto

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.22 [ALTA] El manual afirma que la justificación de la ventana de 500 días está en el anexo C, pero ese anexo no se proporciona en la documentación disponible. Sin acceso a los datos, supuestos y resultados del análisis de sensibilidad, no es posible verificar si la conclusión es válida o si el análisis fue ejecutado correctamente. Esto invalida la trazabilidad de una decisión metodológica crítica.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

**contexto disponible** dice:
> No se encontró evidencia en el contexto disponible

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.23 [ALTA] El manual declara que existen resultados de backtesting (Kupiec y Christoffersen) en un informe de seguimiento, pero ese informe no está disponible. Sin acceso a los resultados reales, no es posible verificar si el backtesting se ejecutó, si pasó los criterios de aceptación, o si justifica mantener los parámetros actuales del modelo. Esta es una brecha crítica en la evidencia de control.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_VaR_FRTB.md** dice:
> Resultados del último trimestre en el informe de seguimiento.

**contexto disponible** dice:
> No se encontró evidencia en el contexto disponible

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.24 [ALTA] El manual afirma que existen resultados de backtesting del último trimestre, pero ese informe no está en el contexto disponible. Sin acceso a él, no se puede verificar: (1) si el backtesting se ejecutó realmente con datos reales, (2) si los resultados pasaron las pruebas de Kupiec y Christoffersen, (3) si hubo excedencias y cómo fueron explicadas, (4) si el código que se ejecutó es idéntico al código actual en calcula_var.py. Riesgo: el backtesting pudo haber sido ejecutado sobre una versión anterior del código, o pudo no haber sido ejecutado en absoluto. Sin el informe, la afirmación de que 'Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual' se ejecutan es una declaración no verificada.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_VaR_FRTB.md** dice:
> Resultados del último trimestre en el informe de seguimiento

**calcula_var.py** dice:
> def var_historico(retornos, confianza=0.99): return -np.percentile(retornos[-500:], (1 - confianza) * 100)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.25 [ALTA] La fecha de aprobación es futura, lo que indica que el documento aún no ha sido aprobado o contiene un error de datación. Esto invalida la afirmación de que el modelo está aprobado y listo para producción.

*Ámbito: Implementación · Actividad: Vericar existencias de correos de comunicación de resultados y su conformidad*

**manual_VaR_FRTB.md** dice:
> Aprobado por el Comité de Riesgos el 2026-03-15

**contexto temporal del documento** dice:
> La fecha de aprobación es 2026-03-15, que es una fecha futura respecto al presente

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.26 [ALTA] El manual justifica el rechazo de ventanas menores a 250 días por excedencias fuera del intervalo de Kupiec, pero no proporciona evidencia de que 500 días sea superior a 250 días en términos de cobertura incondicional. La justificación es incompleta: rechazar A por mal desempeño no demuestra que B sea óptimo. El anexo C que supuestamente contiene este análisis no está disponible para verificación.

*Ámbito: Implementación · Actividad: Vericar existencias de correos de comunicación de resultados y su conformidad*

**manual_VaR_FRTB.md** dice:
> ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.27 [ALTA] El acta afirma uso operativo diario, pero no se proporciona el manual metodológico §2 para verificar si la ventana de 500 días fue el alcance original aprobado. Sin acceso al documento de alcance, no se puede determinar si el uso actual está dentro de lo validado o si representa una desviación no autorizada. Esto es crítico porque un cambio de ventana (ej: de 250 a 500 días) altera significativamente la calibración del modelo y requeriría revalidación.

*Ámbito: Uso e integración a la gestión · Actividad: Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo*

**acta_comite_riesgos_2026Q1.md** dice:
> El VaR se utiliza como límite operativo diario

**calcula_var.py** dice:
> "Ventana de 500 días según manual metodológico §2."

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.28 [MEDIA] El manual cita un estudio de sensibilidad (anexo C) como justificación de la elección de ventana de 500 días, pero ese anexo no está disponible. No se puede verificar si el análisis de sensibilidad es riguroso, si cubre alternativas (250, 375, 750 días), si usa datos históricos reales, o si la conclusión ("ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec") está fundamentada. Esto es una JUSTIFICACIÓN CITADA PERO NO VERIFICABLE, lo que debilita la defensa de la metodología.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**CONTEXTO DISPONIBLE** dice:
> Anexo C no incluido en la cobertura documental

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.29 [MEDIA] El manual remite a un "informe de seguimiento" para los resultados de backtesting, pero el documento disponible (backtesting_VaR_2026Q1.md) es un resumen de resultados sin metadatos de versión, fecha de generación, autorización o integración en un proceso de seguimiento formal. No se puede verificar si este documento es parte de un proceso de seguimiento periódico, quién lo autoriza, o cómo se comunican los resultados a los órganos de gobierno.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> Resultados del último trimestre en el informe de seguimiento

**CONTEXTO DISPONIBLE** dice:
> backtesting_VaR_2026Q1.md contiene resultados de Q1 2026, pero no está claro si es el "informe de seguimiento" referenciado

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.30 [MEDIA] El manual declara control de cambios en anexo A, pero no hay evidencia de que cambios posteriores a 2026-03-15 (como los resultados de backtesting de Q1 2026) hayan sido incorporados al manual mediante un proceso de control de versiones documentado. Si el backtesting reveló hallazgos, ¿se actualizó el manual? ¿Se documentó la decisión de no actualarlo? La ausencia de una versión 1.1 o posterior sugiere que el control de cambios puede no estar siendo ejecutado operativamente, o que los cambios se están gestionando fuera del sistema declarado.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_VaR_FRTB.md** dice:
> Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A.

**backtesting_VaR_2026Q1.md** dice:
> Backtesting VaR — 2026 Q1 / Excedencias observadas: 3 sobre 62 días.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.31 [MEDIA] El manual declara backtesting 'mensual' pero el informe de seguimiento reporta resultados agregados de Q1 (62 días) sin desglose mensual, sin fechas de ejecución individual, y sin evidencia de que se ejecutó realmente cada mes. Esto viola el principio EXISTE ≠ SE EJECUTA: el control está documentado pero no hay trazabilidad de su ejecución periódica. El riesgo es que el backtesting se ejecute ad hoc o con retrasos, perdiendo capacidad de detección temprana de deterioro del modelo.

*Ámbito: Documentación · Actividad: Verifica la existencia , suficiencia y claridad de la documentación*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.32 [MEDIA] El manual declara que se ejecutan ambas pruebas mensualmente, pero el informe de seguimiento solo reporta estadísticos agregados sin análisis de excedencias individuales. La literatura estándar (FRTB_BCBS457) exige que cada excedencia sea explicada; la ausencia de este análisis es una brecha entre lo documentado y lo ejecutado.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

**backtesting_VaR_2026Q1.md** dice:
> Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.33 [MEDIA] El manual declara que el backtesting es MENSUAL, pero el informe de seguimiento solo proporciona resultados agregados de Q1 sin desglose mensual. No hay evidencia de que se ejecute mensualmente ni de que los resultados mensuales se revisen o documenten. Riesgo: incumplimiento de la frecuencia declarada de control, o falta de documentación de ejecuciones intermedias.

*Ámbito: Documentación · Actividad: Verificar la existencia, suficiencia y claridad de la documentación*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento.

**backtesting_VaR_2026Q1.md** dice:
> Backtesting VaR — 2026 Q1 [solo contiene resultados, sin contexto de decisiones o acciones]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.34 [MEDIA] El manual remite a un anexo que no está disponible para validación. No puede verificarse que la justificación de la ventana de 500 días sea realmente sólida o que se hayan evaluado alternativas. Esto impide auditar la decisión metodológica clave del modelo.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**contexto disponible** dice:
> Anexo C no incluido en la cobertura documental

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.35 [MEDIA] El manual declara que el modelo se complementa con ES, pero el informe de backtesting no reporta resultados de ES ni su evolución. No hay evidencia de que este complemento se ejecute o se integre en la gestión de riesgos.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**manual_VaR_FRTB.md** dice:
> Se complementa con el Expected Shortfall

**backtesting_VaR_2026Q1.md** dice:
> No hay mención de Expected Shortfall en el informe de seguimiento

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.36 [MEDIA] El manual declara que se ejecutan Kupiec y Christoffersen, y el reporte de backtesting muestra resultados de ambas pruebas. Sin embargo, NO se reporta la prueba de López (independencia temporal de excedencias individuales), que es estándar en backtesting riguroso según literatura de referencia. La ausencia de López no invalida lo reportado, pero representa una brecha en cobertura de pruebas estadísticas.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

**backtesting_VaR_2026Q1.md** dice:
> Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.37 [MEDIA] El manual declara que se ejecuta Christoffersen mensualmente, pero el informe de backtesting solo reporta una conclusión cualitativa ('no se detecta agrupamiento') sin proporcionar el estadístico de prueba, p-valor ni intervalo de confianza. Esto impide verificar si la conclusión es robusta o si está en zona gris. Riesgo: control documentado pero no verificable.

*Ámbito: Metodología · Actividad: Revisión de los lineamiento internacionales o nacionales*

**backtesting_VaR_2026Q1.md** dice:
> Christoffersen: no se detecta agrupamiento de excedencias.

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.38 [MEDIA] El manual declara backtesting MENSUAL, pero el informe de seguimiento disponible reporta resultados agregados de 62 días (aproximadamente 2 meses), sin desglose mensual. Esto impide verificar si el backtesting se ejecuta realmente con la frecuencia declarada y si hay variabilidad mes a mes que requiera explicación. Riesgo: incumplimiento de la cadencia de control declarada.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento.

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.39 [MEDIA] El informe clasifica LR=3.81 como 'zona verde', pero según la literatura de dominio recuperada, la zona amarilla comienza en LR≈4.61 para muestras típicas. Con p=0.051 (apenas por encima del 5%), el modelo está en el límite de rechazo estadístico. La clasificación como 'zona verde' puede ser correcta según Basilea III, pero la proximidad al umbral de rechazo no se declara como una limitación o una señal de alerta. Riesgo: falsa seguridad en la validez del modelo.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**backtesting_VaR_2026Q1.md** dice:
> Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea.

**kupiec_1995_resumen.md** dice:
> No se encontró en el contexto disponible una definición explícita de los umbrales de zona verde, amarilla y roja de Basilea para n=62.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.40 [MEDIA] El manual afirma que la ventana de 500 días fue elegida porque ventanas menores producían excedencias fuera del intervalo de Kupiec. Sin embargo, el backtesting actual (Q1 2026) muestra 3 excedencias en 62 días, lo que corresponde a una tasa de 4.84% (3/62), muy por encima del 1% esperado al 99%. Aunque el p-valor de 3.81 no rechaza al 5%, la tasa observada está en la zona amarilla de Basilea (2-4 excedencias esperadas para ~250 observaciones). Esto sugiere que la justificación histórica del anexo C puede no ser válida con datos actuales, o que la ventana de 500 días no está siendo efectiva. La inconsistencia es que se justificó una decisión con un análisis que no se revisa periódicamente contra los resultados reales.

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**manual_VaR_FRTB.md** dice:
> La elección de la ventana se justifica en el estudio de sensibilidad del anexo C

**backtesting_VaR_2026Q1.md** dice:
> Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.41 [MEDIA] El manual declara que el backtesting se ejecuta 'mensualmente', pero el informe de seguimiento reporta resultados agregados para todo Q1 (62 días) sin desglose mensual. No hay evidencia de que se hayan ejecutado tres backtestings mensuales independientes (enero, febrero, marzo) ni de cómo se reportan o se actúa sobre ellos si alguno falla. Esto es una brecha entre lo documentado (frecuencia mensual) y lo ejecutado (reporte trimestral agregado).

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

**backtesting_VaR_2026Q1.md** dice:
> Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.42 [MEDIA] No hay contradicción directa, pero hay AUSENCIA: el manual promete backtesting mensual, pero el informe solo reporta resultados trimestrales (Q1 2026). No hay evidencia de que se ejecute mensualmente ni de qué ocurre con los resultados mensuales intermedios. Esto es una brecha de ejecución vs documentación.

*Ámbito: Metodología · Actividad: Analizar el seguimeinto de la metodología*

**manual_VaR_FRTB.md** dice:
> Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.

**backtesting_VaR_2026Q1.md** dice:
> Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.43 [MEDIA] El manual documenta que ventanas menores a 250 días son inaceptables (excedencias fuera de Kupiec), pero no justifica por qué se eligió 500 días en lugar de cualquier otro valor entre 250 y 500. Esta brecha en la justificación impide verificar si la elección fue técnicamente óptima o solo una decisión arbitraria dentro de un rango aceptable. Riesgo: si el modelo se revisa y se descubre que 300 días habría sido más eficiente, no hay documentación que explique por qué se descartó, lo que sugiere falta de rigor en la selección de parámetros.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_VaR_FRTB.md** dice:
> ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec

**manual_VaR_FRTB.md** dice:
> VaR histórico con ventana de 500 días

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

## 3. Cuestionamiento metodológico

Un modelo puede documentar impecablemente una elección equivocada. Esto
no evalúa si la metodología está descrita, sino si está **justificada**.

### Verifica la existencia de control de cambios/versiones

El manual justifica la ventana de 500 días mediante un estudio de sensibilidad (anexo C no disponible) que afirma que ventanas menores a 250 días producen excedencias fuera del intervalo de Kupiec. Esta justificación es INCOMPLETA sin el anexo: (1) no se declara el período de datos usado en el estudio; (2) no se especifica si se contrastó contra Kupiec en múltiples períodos históricos o solo en uno; (3) no se explica por qué 500 días es óptimo (¿por qué no 375 o 625?); (4) no se cita literatura que respalde esta elección (Jorion, Dowd, o estudios de ventanas óptimas). El manual cita Kupiec (1995) implícitamente al mencionar el intervalo de Kupiec, pero no proporciona la referencia completa ni explica por qué se elige Kupiec (cobertura incondicional) y Christoffersen (independencia) y no López (cobertura condicional) o Berkowitz (distribución). La elección del nivel 99% y horizonte 1 día se alinea con FRTB (que usa 97.5% para ES, pero VaR histórico puede usar 99%), pero no se justifica por qué 99% en lugar de 97.5% o 95%. Sin el anexo C y sin justificación explícita de alternativas descartadas, la metodología es DECLARADA pero no JUSTIFICADA.

### Verifica la inclusión del objetivo, usos y usuarios del modelo

No aplica a esta actividad (evaluación de documentación de objetivo/usos/usuarios, no de metodología técnica).

### Verifica la existencia , suficiencia y claridad de la documentación

El manual elige ventana de 500 días sin justificación verificable en el contexto. La literatura estándar (Basilea III, SR 11-7) exige que la ventana sea suficientemente larga para capturar ciclos de mercado pero no tan larga que pierda relevancia ante cambios de régimen. El manual afirma que ventanas menores a 250 días producen excedencias fuera del intervalo de Kupiec, pero: (1) no se cita el estudio que lo demuestra, (2) no se explica por qué 500 es mejor que 400 o 600, (3) no se declara si se revisa periódicamente. La elección de 99% de confianza se alinea con FRTB, pero no hay justificación de por qué no se usa 97.5% (estándar en Basilea III para VaR estándar) o si se consideró. El manual menciona que se complementa con Expected Shortfall pero no especifica cómo ni cuándo se usa ES en lugar de VaR para decisiones de capital o límites. Falta análisis de alternativas descartadas (ej: VaR paramétrico, simulación de Montecarlo, GARCH) y por qué se eligió histórico.

### Verificar la coherencia del manual de implementación con el manual métodolocios

El manual declara VaR histórico con ventana de 500 días, pero NO JUSTIFICA POR QUÉ HISTÓRICO Y NO PARAMÉTRICO O MONTECARLO. La referencia al anexo C sugiere que se hizo un análisis de sensibilidad, pero ese análisis no está disponible. La afirmación de que "ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec" es una conclusión, no una justificación: no explica (i) qué ventanas se probaron, (ii) sobre qué período histórico, (iii) qué criterio de aceptación se usó (¿el intervalo de Kupiec al 95%? ¿al 99%?), (iv) por qué se eligió 500 y no 400 o 600. El backtesting reportado (Kupiec + Christoffersen) es correcto en forma, pero el manual no declara: (v) si se ejecuta en ventana móvil o fija, (vi) si hay ajustes por cambios de régimen, (vii) si se excluyen períodos de estrés extremo. La metodología está descrita pero no justificada; la justificación se remite a un documento no entregado.

### Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.

La elección de la ventana de 500 días se justifica únicamente por referencia a un estudio de sensibilidad (anexo C) que no está disponible en el contexto. Sin acceso a ese estudio, no es posible verificar: (a) si la comparación contra el intervalo de Kupiec fue correcta; (b) si se evaluaron alternativas (ej: ventanas adaptativas, ponderación exponencial); (c) si el criterio de «excedencias por encima del intervalo» es el único criterio de selección o si se consideraron otros (ej: estabilidad del estimador, sesgo en mercados de baja liquidez). La metodología de backtesting (Kupiec + Christoffersen) es estándar y apropiada, pero la documentación no justifica por qué se descartaron otras pruebas (ej: test de López para independencia condicional, test de Berkowitz para normalidad de los retornos estandarizados). El manual no declara supuestos sobre la distribución de los retornos (¿se asume normalidad? ¿se verifica?) ni sobre la estacionariedad de la serie histórica.

### Verifica la existencia de control de cambios/versiones

No aplica a esta actividad (ámbito: control de cambios/versiones, no metodología del modelo).

### Verificar la existencia, suficiencia y claridad de la documentación

La elección de la ventana de 500 días se justifica mediante un criterio de sensibilidad (evitar excedencias fuera del intervalo de Kupiec), pero: (1) No se explica por qué 500 es el punto óptimo y no 400 o 600; (2) No se cita literatura que respalde este enfoque (Basilea III/IV, SR 11-7 u otros marcos regulatorios); (3) El anexo C que contiene el análisis no está disponible. La metodología de backtesting (Kupiec + Christoffersen) es estándar y correcta, pero: (1) No se menciona el test de López (independencia condicional), que es complementario a Christoffersen en marcos avanzados; (2) No se justifica por qué se eligió Kupiec sobre alternativas (ej. binomial exacto, enfoque bayesiano); (3) No hay evidencia de que se verifiquen los supuestos de Kupiec (independencia de excedencias, estacionariedad de la serie). La limitación declarada (no captura riesgo de liquidez) es apropiada, pero no se documenta cómo se mitiga este riesgo en la práctica (ej. mediante ES, límites de concentración, o stress testing).

### Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

La elección de ventana de 500 días se justifica solo por referencia a un anexo no disponible. La literatura estándar (Kupiec 1995, Christoffersen) no prescribe una ventana específica; la elección depende del trade-off entre sesgo (ventanas cortas) y varianza (ventanas largas). Sin acceso al estudio de sensibilidad, no puede verificarse que se haya evaluado este trade-off ni que se hayan descartado alternativas (ej: ventanas móviles, ponderación exponencial). El manual menciona que ventanas menores a 250 días producían excedencias "por encima del intervalo de Kupiec", pero no especifica: (1) cuál era el intervalo esperado (depende del tamaño muestral), (2) si se evaluó la potencia de la prueba con muestras pequeñas, (3) si se consideraron métodos de backtesting alternativos (López, Berkowitz). La justificación es circular: se elige 500 porque 250 falla, pero no se explora por qué 250 falla ni si hay un óptimo intermedio.

### Existencia de buenas prácticas en el enfoque metodológico

1. **Justificación de la metodología**: El manual describe VaR histórico pero NO justifica por qué se eligió este enfoque frente a alternativas (VaR paramétrico, simulación de Montecarlo, GARCH condicional). No se declara qué se descartó ni con qué criterio. Esto es crítico porque cada metodología tiene supuestos y limitaciones distintos, y la elección debe ser deliberada, no heredada.

2. **Verificación de supuestos**: El VaR histórico asume que los retornos pasados son representativos del futuro (estacionariedad) y que el percentil empírico es un estimador válido. NO se reporta ninguna prueba de estacionariedad (ADF, KPSS), normalidad (Shapiro-Wilk, Jarque-Bera) ni autocorrelación (Ljung-Box). Sin estas verificaciones, no se puede afirmar que los supuestos del método se cumplen.

3. **Cobertura de pruebas de backtesting**: Se reportan Kupiec y Christoffersen, que son estándar. Sin embargo, falta López (1998), que contrasta la independencia temporal de excedencias individuales. Aunque Christoffersen cubre agrupamiento, López añade información sobre patrones de excedencias aisladas. La omisión no invalida lo hecho, pero reduce la robustez del análisis.

4. **Potencia estadística**: La muestra de backtesting es pequeña (62 días, 3 excedencias observadas vs. 0.62 esperadas). Con muestras pequeñas, las pruebas de Kupiec y Christoffersen tienen baja potencia para detectar modelos deficientes. Esto NO se declara como limitación, lo que puede dar falsa confianza en un modelo que podría ser inadecuado con más datos.

5. **Tipo de P&L en backtesting**: NO se especifica si el backtesting se realiza sobre P&L hipotético (cartera congelada, sin operaciones intradía) o real (con operaciones y comisiones). Esta distinción es crítica: el P&L real incluye ruido operativo ajeno al modelo, lo que puede enmascarar deficiencias del VaR. La literatura de referencia subraya que deben distinguirse ambos tipos.

6. **Integración de limitaciones**: El manual declara que el modelo «no captura riesgo de liquidez» y se complementa con ES, pero NO justifica por qué esa complementariedad es suficiente ni cómo se integra en la toma de decisiones de riesgo. ¿Se usa ES para ajustar límites? ¿Se reporta conjuntamente? ¿Hay un protocolo de escalada si ambas métricas se violan?

### Validar supuestos y consideración más importantes de la técnica utilizada

1. **Justificación de la metodología**: El manual elige VaR histórico sin justificar por qué se descartaron alternativas (paramétrico, GARCH, simulación de Montecarlo, enfoque híbrido). La única justificación mencionada es que ventanas menores a 250 días producían excedencias fuera del intervalo de Kupiec, pero esto es un criterio de ajuste de parámetro, no de elección de metodología. ¿Por qué VaR histórico y no un modelo que capture volatilidad condicional, especialmente relevante en mercados FRTB con cambios de régimen frecuentes? 2. **Supuestos no verificados**: VaR histórico asume implícitamente que (a) los retornos son estacionarios, (b) la distribución histórica es representativa del futuro, y (c) no hay cambios estructurales. Ninguno de estos supuestos se verifica en la documentación. Para FRTB, donde se espera capturar riesgo de mercado en múltiples regímenes, la estacionariedad es especialmente cuestionable. 3. **Alternativas descartadas**: No hay mención de por qué se rechazó un enfoque paramétrico (que permitiría capturar volatilidad condicional) o un modelo de colas gruesas (que es estándar en riesgo de mercado). La literatura de dominio menciona que la Normal subestima eventos extremos; ¿se evaluó este sesgo en la cartera FRTB? 4. **Horizonte y ventana**: La ventana de 500 días (~2 años) es estándar, pero para FRTB con horizontes de liquidez variables (según el corpus de dominio), ¿es apropiada una ventana uniforme? ¿Se justifica por qué no se usan horizontes de liquidez diferenciados como sugiere el marco FRTB? 5. **Backtesting insuficiente**: El manual declara Kupiec y Christoffersen, pero no López (independencia temporal de excedencias más allá de agrupamiento). Con solo 3 excedencias en 62 días, el análisis individual de cada una (qué evento de mercado la causó, si fue predecible) es más informativo que el estadístico agregado, pero no se documenta. 6. **Complementariedad con ES**: El manual menciona que se complementa con Expected Shortfall, pero no especifica cómo se integran en la decisión de capital ni cómo se resuelven conflictos si uno señala adecuación y otro no.

### Revisión de los lineamiento internacionales o nacionales

¿POR QUÉ HISTÓRICO? El manual no justifica por qué se eligió VaR histórico sobre métodos paramétricos (normal, t-student) o simulación de Montecarlo. La literatura estándar (Jorion, Dowd) discute trade-offs: histórico no asume distribución pero requiere más datos y es sensible a eventos extremos pasados; paramétrico es más eficiente pero depende de supuestos. ¿Se evaluaron alternativas? ¿Qué criterio se usó para descartar otras? No hay evidencia. ¿VENTANA DE 500 DÍAS? Se menciona que 'ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec', pero esto es un criterio de RECHAZO, no de SELECCIÓN. ¿Por qué 500 y no 400, 600 u 800? ¿Se optimizó la ventana? ¿Se consideró el trade-off entre sesgo (ventana corta captura cambios recientes) y varianza (ventana larga suaviza)? No hay análisis. ¿SUPUESTOS NO VERIFICADOS? El método histórico asume que la distribución de retornos pasados es estacionaria y representativa del futuro. No hay evidencia de contrastes de estacionariedad (ADF, KPSS), análisis de cambios estructurales (Chow test) ni verificación de que la cola de la distribución es estable. Riesgo: si el mercado cambió de régimen (volatilidad, correlaciones), el modelo es inválido. ¿ALINEACIÓN CON FRTB? El manual usa VaR 99% pero FRTB sustituyó VaR por ES precisamente porque VaR no captura riesgo de cola. ¿Se usa VaR solo para backtesting interno o también para decisiones de capital? Si es lo segundo, ¿por qué no se valida ES 97.5% en su lugar? No hay claridad. ¿TAMAÑO MUESTRAL? El backtesting usa 62 días (Q1 2026). Para un nivel de confianza 99%, se esperan 0.62 excedencias; observadas 3. El intervalo de Kupiec es amplio con muestras pequeñas. ¿62 días es suficiente para validar? ¿Se planifica backtesting rolling o solo trimestral? No se declara. ¿PAPERS CITADOS? Se menciona Kupiec (1995) pero no se cita ningún paper que justifique la elección de histórico sobre alternativas. La referencia a Kupiec es correcta (es el test estándar) pero no sostiene la metodología de base.

### Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

1. **Justificación de la ventana de 500 días**: El manual remite a un anexo C (estudio de sensibilidad) que no está disponible en el contexto. Sin acceso a ese análisis, no puede verificarse si la elección de 500 días está realmente justificada o si es una decisión heredada. ¿Se comparó contra otras ventanas (250, 375, 750 días)? ¿Qué criterio se usó para elegir 500 como óptimo? ¿Se verificó estacionariedad de la volatilidad en esa ventana? (2) **Metodología del VaR no especificada**: El manual declara 'VaR histórico' pero no detalla: ¿es percentil simple, interpolado, suavizado? ¿Se aplica algún ajuste por volatilidad (EWMA)? ¿Se excluyen observaciones extremas o se usan todas? Sin esta especificación, el backtesting no es reproducible. (3) **Supuestos no verificados**: El VaR histórico asume que la distribución pasada es representativa del futuro (estacionariedad). No hay evidencia de contrastes de estacionariedad, cambios de régimen, o análisis de colas. El manual menciona que el modelo 'no captura riesgo de liquidez' pero no cuantifica el sesgo que esto introduce. (4) **Potencia estadística no declarada**: Con n=62 días, la prueba de Kupiec tiene baja potencia para detectar desviaciones pequeñas del nivel de confianza. El manual no declara este límite ni propone un tamaño de muestra mínimo para que el backtesting sea concluyente. (5) **Análisis de excedencias individuales ausente**: Las 3 excedencias observadas no se explican. ¿Ocurrieron en días de estrés de mercado conocido? ¿Fueron causadas por factores de riesgo capturados por el modelo o por riesgos no modelados? Sin este análisis, no puede determinarse si el modelo es deficiente o si las excedencias son eventos extremos legítimos. (6) **Integración con Expected Shortfall no documentada**: El manual menciona que el modelo se complementa con ES, pero no especifica: ¿se backtestea el ES?, ¿cómo se resuelven discrepancias entre VaR y ES?, ¿el ES se usa en decisiones de límites de riesgo o solo en reporte regulatorio?

### Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

1. **Justificación de la ventana de 500 días**: El manual afirma que se eligió porque ventanas menores producían excedencias fuera del intervalo de Kupiec, pero no se cita el paper de Kupiec (1995) ni se explica por qué 500 es óptimo frente a otras opciones (250, 375, 750). ¿Se realizó un análisis de trade-off entre sesgo (ventanas largas suavizan cambios de régimen) y varianza (ventanas cortas son ruidosas)? ¿Se consideró la estacionariedad de los retornos en la ventana elegida? 2. **Supuestos no verificados**: El VaR histórico asume que la distribución histórica es representativa de la distribución futura. No hay evidencia de pruebas de estacionariedad, cambios de régimen o análisis de colas. El manual menciona que 'no captura riesgo de liquidez' pero no cuantifica el sesgo que esto introduce. 3. **Análisis de sensibilidad incompleto**: El anexo C (no disponible) aparentemente solo varió la ventana. ¿Se analizó sensibilidad a: (a) nivel de confianza (¿por qué 99% y no 97.5% o 99.9%)?; (b) horizonte (¿por qué 1 día y no 10 días como en Basilea III anterior)?; (c) tratamiento de datos faltantes o mercados cerrados? 4. **Escenarios de estrés ausentes**: La literatura de referencia subraya que el backtesting debe complementarse con pruebas de estrés. No hay evidencia de escenarios históricos (crisis 2008, COVID-19) o hipotéticos (saltos de volatilidad, cambios de correlación) aplicados al modelo. 5. **Integración con decisiones**: El análisis de sensibilidad existe pero no hay evidencia de que alimente decisiones operacionales (ajuste de límites, revisión de metodología, alertas). ¿A qué comité se reportan los resultados? ¿Qué umbral de sensibilidad dispara una revisión del modelo?

### Analizar el seguimeinto de la metodología

¿POR QUÉ HISTÓRICO Y NO PARAMÉTRICO O SIMULACIÓN MONTECARLO? El manual no justifica la elección del método histórico frente a alternativas. En contextos de estrés o cambios de régimen, el histórico puede ser inadecuado. ¿SE VERIFICAN LOS SUPUESTOS? No hay evidencia de contrastes de estacionariedad, normalidad de retornos, o análisis de cambios de régimen. El método histórico asume que la distribución pasada es representativa del futuro — esto no se valida. ¿VENTANA DE 500 DÍAS ES SUFICIENTE? El anexo C (no disponible) supuestamente justifica esto, pero 500 días ≈ 2 años. En periodos de estrés o volatilidad extrema, esto puede ser insuficiente. No hay análisis de sensibilidad a la ventana en el contexto actual. ¿KUPIEC ES SUFICIENTE? Kupiec solo contrasta cobertura incondicional. Christoffersen añade independencia, pero López (1998) es más específico para clustering temporal de excedencias en VaR. Su ausencia no es incumplimiento formal, pero es una limitación no declarada. ¿HORIZONTE DE BACKTESTING? 62 días es muy corto. Basilea III exige mínimo 1 año. No hay evidencia de backtesting rolling o anual. ¿INTEGRACIÓN A DECISIONES? No hay trazabilidad de qué ocurre cuando Kupiec está en zona amarilla/roja, quién revisa, o qué acciones se toman. Un modelo no integrado a la gestión es un modelo sin control.

> ✍️ **Te toca:** contrasta esto con tu criterio experto. El agente puede
> cuestionar sin conocer restricciones de negocio que sí justifican la
> elección — si es el caso, déjalo escrito en el informe final.

## 4. Información a solicitar al modelador

**167 petición(es)**, sin duplicados y ordenadas por gravedad del
control que las origina. Esta lista se envía tal cual.

| # | Ámbito | Score | Petición |
|---:|---|---:|---|
| 1 | Documentación | 2/5 | ¿Cuáles son los usos específicos del VaR estimado por este modelo? ¿Se utiliza para: (a) cálculo de capital regulatorio, (b) límites internos de riesgo, (c) reporte a supervisores, (d) decisiones de cobertura, (e) todas las anteriores? |
| 2 | Documentación | 2/5 | ¿Quiénes son los usuarios finales del modelo? Especificar: mesas de negociación, tesorería, comité de riesgos, supervisores internos, autoridades regulatorias. |
| 3 | Documentación | 2/5 | ¿Cuál es la relación entre este VaR y el Expected Shortfall mencionado en limitaciones? ¿Se calcula ES en paralelo? ¿Cuál es la medida de capital regulatorio bajo FRTB que esta entidad reporta a supervisores? |
| 4 | Documentación | 2/5 | ¿Qué acciones se disparan si el backtesting de Kupiec falla (p-valor < 0.05)? ¿Quién es responsable de investigar y reportar? ¿Se suspende el uso del modelo? |
| 5 | Documentación | 2/5 | ¿Con qué frecuencia se reporta el VaR a cada usuario? ¿Diaria, semanal, mensual? ¿Existen umbrales de escalación? |
| 6 | Documentación | 2/5 | ¿El manual operativo (mencionado implícitamente pero no proporcionado) describe el flujo de datos, responsables de ejecución y validación de inputs? |
| 7 | Calidad de datos | 2/5 | ¿Existe un script automatizado (_replica_virf.py o equivalente) que ejecute controles de calidad de datos sobre la serie de precios Bloomberg diaria? Si existe, ¿cuál es su nombre y dónde se almacenan sus resultados? |
| 8 | Calidad de datos | 2/5 | ¿Cuál es la justificación técnica para imputar valores ausentes por último valor conocido (forward fill) en una serie de retornos para VaR histórico? ¿Se ha validado el impacto de esta imputación en la estimación del VaR y en los resultados del backtesting de Kupiec? |
| 9 | Calidad de datos | 2/5 | ¿Cómo se clasifican los 0.4% de valores ausentes en la serie de precios: MCAR (Missing Completely At Random), MAR (Missing At Random) o MNAR (Missing Not At Random)? ¿Hay análisis de si los faltantes coinciden con cierres de mercado, feriados o eventos de liquidez? |
| 10 | Calidad de datos | 2/5 | ¿Los tres fallos reportados en la matriz de motores de calidad (integridad referencial 1.8%, rango de tasa 14.7%, outliers en saldo sin cuantificar) aplican a la cartera de negociación que alimenta el VaR FRTB? Si aplican, ¿cuál es el impacto cuantificado en la estimación del VaR? |
| 11 | Calidad de datos | 2/5 | ¿Existe un reporte periódico (diario, semanal o mensual) de incidencias de calidad de datos sobre los inputs del modelo VaR? ¿Quién lo revisa y qué acciones correctivas se documentan? |
| 12 | Calidad de datos | 2/5 | ¿Se ejecutan pruebas de outliers sobre los retornos calculados (no solo sobre precios)? ¿Qué criterio se usa para identificar outliers: Z-score, IQR, percentiles, o análisis de colas? ¿Se documentan los outliers detectados y se valida si son errores de datos o movimientos de mercado legítimos? |
| 13 | Calidad de datos | 2/5 | ¿Se verifica la integridad referencial entre la serie de precios Bloomberg y el maestro de instrumentos (ISIN, ticker, divisa)? ¿Hay un control que detecte si un instrumento desaparece del maestro pero sigue en la cartera histórica? |
| 14 | Calidad de datos | 2/5 | ¿Existe un script de validación de datos (_replica_virf.py o equivalente) que se ejecute periódicamente? Si existe, ¿cuál es su frecuencia de ejecución y cuáles son los resultados de las últimas 3 corridas? |
| 15 | Calidad de datos | 2/5 | ¿Se ha realizado un análisis del mecanismo de faltantes (MCAR, MAR, MNAR) para justificar la imputación por último valor conocido? ¿Qué impacto tiene esta imputación en la distribución de retornos y en la estimación de VaR? |
| 16 | Calidad de datos | 2/5 | ¿Cuál es el estado de resolución de las 2.168 cuentas sin cliente maestro reportadas en el reporte de calidad? ¿Se excluyen del cálculo de VaR, se asignan a un cliente por defecto, o se mantienen con riesgo de trazabilidad? |
| 17 | Calidad de datos | 2/5 | ¿Cuál es el criterio para detectar y tratar outliers en saldos? ¿Se utiliza Z-score, IQR, o algún otro método? ¿Cuál es el umbral y qué acción se toma (exclusión, ajuste, o mantenimiento)? |
| 18 | Calidad de datos | 2/5 | ¿Existe un calendario de actualización de inputs (precios Bloomberg, saldos, maestros de clientes) con SLAs documentados? ¿Quién verifica que se cumplan y con qué frecuencia? |
| 19 | Calidad de datos | 2/5 | ¿Se han documentado los resultados de las validaciones de integridad referencial y rango en los últimos 3 meses? ¿Hay un registro de incidencias y su resolución? |
| 20 | Calidad de datos | 2/5 | ¿El modelo VaR se recalcula con los datos validados, o se ejecuta sobre los datos brutos reportados en el perfil? ¿Existe un control que asegure que solo datos que pasan los controles de calidad alimentan el modelo? |
| 21 | Metodología | 2/5 | ¿Puede proporcionarse el anexo C (estudio de sensibilidad) que justifica la elección de ventana de 500 días? Sin él, no puede validarse la justificación central de la metodología. |
| 22 | Metodología | 2/5 | ¿Se han realizado pruebas de estacionariedad (ADF, KPSS) sobre la serie de retornos históricos? ¿Qué resultado arrojaron? |
| 23 | Metodología | 2/5 | ¿Por qué se descartó un enfoque paramétrico (GARCH, volatilidad condicional) o un modelo de colas gruesas (t-Student, EVT) para FRTB, donde se espera capturar cambios de régimen? |
| 24 | Metodología | 2/5 | ¿Se documentan las tres excedencias observadas individualmente? ¿Qué evento de mercado las causó? ¿Eran predecibles o representan un fallo del modelo? |
| 25 | Metodología | 2/5 | ¿Se ha ejecutado la prueba de López (independencia temporal de excedencias) o algún análisis de clustering más allá de Christoffersen? |
| 26 | Metodología | 2/5 | ¿Cómo se integran VaR y Expected Shortfall en la decisión de capital regulatorio? ¿Qué ocurre si uno señala adecuación y otro no? |
| 27 | Metodología | 2/5 | ¿Se ha cuantificado el sesgo introducido por no capturar riesgo de liquidez de mercado? ¿Existe un control compensatorio (p. ej., ajuste por liquidez, pruebas de estrés)? |
| 28 | Metodología | 2/5 | ¿Se verifica que la distribución histórica de retornos sea representativa del futuro? ¿Se han detectado cambios estructurales en la serie (ej. cambios de volatilidad de largo plazo)? |
| 29 | Metodología | 2/5 | ¿Cuál es la potencia estadística de Kupiec con 62 observaciones y nivel 99%? ¿Se ha documentado explícitamente que un p-valor de 0.051 con muestra pequeña no acredita adecuación del modelo? |
| 30 | Gobierno | 2/5 | ¿Existe acta formal firmada (no correo, no minuta informal) que documente la asignación de tiering del modelo VaR FRTB? Incluir: fecha de asignación, tier asignado (Tier 1/2/3 u otra clasificación corporativa), criterios aplicados para esa clasificación, y firma de autoridad responsable. |
| 31 | Gobierno | 2/5 | ¿Cuál es la fecha de última revisión del tiering? ¿Existe un calendario de revisión periódica documentado? |
| 32 | Gobierno | 2/5 | ¿El tiering está registrado en el inventario oficial de modelos de riesgo de la institución? Si está en herramienta GRC corporativa, proporcionar captura de pantalla o reporte que muestre: nombre del modelo, tiering vigente, fecha de asignación, y estado de cumplimiento. |
| 33 | Gobierno | 2/5 | ¿Existe justificación documentada de por qué se asignó ese tier específico? (ej: complejidad metodológica, volumen de exposición, criticidad para capital, frecuencia de uso). |
| 34 | Gobierno | 2/5 | ¿Existe acta formal (no correo) de inventariado del modelo VaR Mercado FRTB en el registro oficial de modelos de riesgo? Proporcionar número de referencia, fecha y firmantes. |
| 35 | Gobierno | 2/5 | ¿Cuál es el tiering asignado al modelo (Tier 1, 2 o 3)? ¿En qué criterios se basa esta clasificación (complejidad, criticidad, exposición, número de usuarios)? |
| 36 | Gobierno | 2/5 | ¿Cuándo fue incluido el modelo en inventario y cuándo fue la última revisión del tiering? Proporcionar fechas y responsable. |
| 37 | Gobierno | 2/5 | ¿Existe un documento de justificación del tiering que vincule la complejidad del modelo (VaR histórico 500 días, backtesting Kupiec+Christoffersen, FRTB) con el nivel asignado? |
| 38 | Implementación | 2/5 | ¿Existe acta formal de UAT (User Acceptance Testing) que documente la validación de calcula_var.py contra datos reales antes de paso a producción? ¿Quién la firmó y cuándo? |
| 39 | Implementación | 2/5 | ¿Existe correo o resolución de aprobación de paso a producción del modelo VaR FRTB? ¿Quién autorizó y en qué fecha? |
| 40 | Implementación | 2/5 | ¿Dónde se almacenan y quién ejecuta los backtesting mensuales mencionados en §3? ¿Existe un log de ejecución o un repositorio de resultados? |
| 41 | Implementación | 2/5 | ¿Cuál es el contenido del anexo C (estudio de sensibilidad que justifica la ventana de 500 días)? ¿Por qué se descartó 250 días además de por excedencias de Kupiec? ¿Se consideraron otras ventanas? |
| 42 | Implementación | 2/5 | ¿Existe documentación de las pruebas iniciales de implementación (test cases, validación de fórmulas, comparativa manual vs código)? |
| 43 | Implementación | 2/5 | ¿Cómo se comunican las limitaciones del modelo (§4: no captura riesgo de liquidez) a los usuarios finales? ¿Existe un documento de limitaciones y mitigaciones? |
| 44 | Implementación | 2/5 | ¿Se ha implementado el Expected Shortfall mencionado como complemento? ¿Existe código y documentación para ello? |
| 45 | Implementación | 2/5 | ¿Existe un pipeline de control en producción que valide que calcula_var.py se ejecuta con los parámetros documentados (ventana 500, confianza 99%)? |
| 46 | Implementación | 2/5 | ¿Dónde está el anexo C del manual (estudio de sensibilidad)? Proporcionar el documento completo con datos, supuestos, metodología y resultados del análisis que justifica la ventana de 500 días. |
| 47 | Implementación | 2/5 | ¿Dónde está el informe de seguimiento con los resultados del backtesting del último trimestre? Proporcionar el informe con: (a) número de excedencias observadas, (b) intervalo de confianza de Kupiec, (c) resultado de la prueba de Christoffersen, (d) fecha de ejecución, (e) datos utilizados, (f) interpretación de resultados. |
| 48 | Implementación | 2/5 | ¿Existe correo de aprobación técnica del código (calcula_var.py) por parte de la primera línea o de un validador independiente? Proporcionar evidencia de que el script fue revisado y autorizado antes de paso a producción. |
| 49 | Implementación | 2/5 | ¿Se ejecutó UAT (User Acceptance Testing) del modelo? Si existe, proporcionar: (a) plan de UAT con criterios de aceptación, (b) datos de prueba utilizados, (c) resultados de ejecución, (d) acta de conformidad firmada. |
| 50 | Implementación | 2/5 | ¿Existe documentación de control de cambios (anexo A mencionado en el manual)? Proporcionar el registro de versiones con: (a) cambios realizados, (b) fechas, (c) autores, (d) aprobaciones, (e) justificación de cada cambio. |
| 51 | Implementación | 2/5 | ¿Existen logs de ejecución del script calcula_var.py en producción? Proporcionar evidencia de cuándo se ejecuta, con qué frecuencia, y si hay alertas o errores registrados. |
| 52 | Implementación | 2/5 | ¿El código ha sido sometido a revisión de seguridad (code review)? Proporcionar evidencia de revisión técnica, incluyendo: (a) revisor, (b) fecha, (c) hallazgos, (d) resolución de hallazgos. |
| 53 | Implementación | 2/5 | ¿Existe documentación de que el modelo cumple con los requisitos de FRTB (Basilea III) específicamente? El manual menciona FRTB pero no documenta cómo se mapean los requisitos regulatorios a la implementación. |
| 54 | Implementación | 2/5 | ¿Dónde está el informe de seguimiento del último trimestre que contiene los resultados del backtesting? Sin él, no se puede verificar que las pruebas de Kupiec y Christoffersen se ejecutaron realmente. |
| 55 | Implementación | 2/5 | ¿Existe el anexo A (Control de cambios) del manual? ¿Qué cambios se registran entre la aprobación del 2026-03-15 y la fecha actual? ¿Se modificó el código de calcula_var.py después de la aprobación? |
| 56 | Implementación | 2/5 | ¿Cuál es la justificación técnica específica para elegir 500 días en lugar de otro valor dentro del rango 250-500? ¿Se realizó un análisis de trade-off entre sesgo y varianza para esta ventana? |
| 57 | Implementación | 2/5 | ¿Existen logs de ejecución de calcula_var.py en producción? ¿Cuándo se ejecutó por última vez y con qué datos? |
| 58 | Implementación | 2/5 | ¿Hay correos de conformidad de primera línea (mesa de negociación o risk management) que aprueben los resultados del backtesting y autoricen el paso a producción? |
| 59 | Implementación | 2/5 | ¿Se ejecutaron pruebas de UAT (User Acceptance Testing) documentadas antes de pasar el modelo a producción? ¿Quién las ejecutó, cuándo y con qué resultado? |
| 60 | Implementación | 2/5 | ¿El código en calcula_var.py es la versión exacta que fue aprobada el 2026-03-15, o ha sido modificado? ¿Hay control de versiones (git, SVN) que lo demuestre? |
| 61 | Implementación | 2/5 | ¿Se ejecutó la prueba de López (independencia de excedencias) además de Kupiec y Christoffersen, o se descartó deliberadamente? Si se descartó, ¿cuál es la justificación? |
| 62 | Implementación | 2/5 | ¿Cómo se tratan los días con datos incompletos o mercados cerrados en el cálculo de retornos? ¿Está documentado en el manual o en el código? |
| 63 | Implementación | 2/5 | ¿Dónde está el anexo C con el estudio de sensibilidad que justifica la ventana de 500 días? ¿Contiene análisis cuantitativo de cobertura incondicional (Kupiec) para ventanas de 250, 375, 500 y 750 días? |
| 64 | Implementación | 2/5 | ¿Existe correo de comunicación de resultados de backtesting del último trimestre a primera línea y al Comité de Riesgos? ¿Cuál es la fecha de ese correo y quién lo firmó? |
| 65 | Implementación | 2/5 | ¿Existe acta de conformidad de segunda línea (validación de implementación) que certifique que calcula_var.py implementa correctamente el manual_VaR_FRTB.md? ¿Incluye casos de prueba ejecutados (UAT)? |
| 66 | Implementación | 2/5 | ¿Existe correo de aprobación para paso a producción? ¿Quién autorizó y cuándo? ¿Por qué la fecha en el manual es 2026-03-15 (futura)? |
| 67 | Implementación | 2/5 | ¿Dónde está el informe de seguimiento del último trimestre mencionado en §3? ¿Contiene resultados de Kupiec y Christoffersen con datos reales? |
| 68 | Implementación | 2/5 | ¿Existe anexo A de control de cambios? ¿Qué cambios se han hecho a calcula_var.py desde la aprobación del manual y cómo se documentaron? |
| 69 | Implementación | 2/5 | ¿Se ejecutó el script calcula_var.py con datos reales de la cartera? ¿Existen logs con fechas de ejecución, volumen de datos procesados y resultados? |
| 70 | Implementación | 2/5 | ¿Quién es el propietario del modelo y quién es responsable de la ejecución mensual del backtesting? |
| 71 | Uso e integración a la gestión | 2/5 | ¿Existe un documento de alcance original del modelo VaR FRTB que especifique: (a) propósito original, (b) usuarios autorizados, (c) aplicaciones permitidas, (d) parámetros de referencia (ventana, nivel de confianza, horizonte)? Si existe, ¿cuál es su fecha de aprobación y quién lo aprobó? |
| 72 | Uso e integración a la gestión | 2/5 | ¿Quiénes son formalmente los usuarios del modelo en producción? Proporcionar lista con: nombre, área, función, fecha de autorización de acceso. |
| 73 | Uso e integración a la gestión | 2/5 | ¿Existe un reporte real de consumo de VaR presentado al Comité de Riesgos en los últimos 3 meses? Si existe, adjuntarlo para verificar: (a) que los outputs coinciden con los del código en producción, (b) que el formato y frecuencia son consistentes con lo documentado. |
| 74 | Uso e integración a la gestión | 2/5 | El manual metodológico §2 menciona una ventana de 500 días. ¿Cuál era la ventana especificada en el alcance original del modelo? ¿Cuándo se cambió de una a otra y quién autorizó ese cambio? |
| 75 | Uso e integración a la gestión | 2/5 | ¿Existe un registro de cambios (change log) que documente: (a) cuándo el modelo pasó de desarrollo a producción, (b) qué validaciones se completaron antes de ese paso, (c) quién autorizó la puesta en producción? |
| 76 | Uso e integración a la gestión | 2/5 | ¿Se ha realizado algún análisis de impacto para verificar que los outputs del modelo en producción son consistentes con los de desarrollo? Si existe, adjuntarlo. |
| 77 | Documentación | 3/5 | ¿Cuál es la estructura exacta del control de cambios en anexo A? ¿Registra cambios históricos, quién autoriza, con qué frecuencia se revisa, y cómo se comunican cambios a usuarios del modelo? |
| 78 | Documentación | 3/5 | ¿El anexo C (estudio de sensibilidad) incluye análisis de ventanas alternativas (250, 375, 625, 750 días)? ¿Sobre qué período histórico se ejecutó? ¿Se repitió en múltiples períodos para verificar robustez? |
| 79 | Documentación | 3/5 | ¿Por qué se eligió ventana de 500 días en lugar de 250 o 375? ¿Existe literatura o benchmarking de la industria que respalde esta elección? |
| 80 | Documentación | 3/5 | ¿Por qué se descartó el test de López (cobertura condicional) o Berkowitz (distribución) en favor de solo Kupiec y Christoffersen? ¿Qué limitaciones tiene esta elección? |
| 81 | Documentación | 3/5 | ¿El "informe de seguimiento" es un documento formal con versión, fecha, autorización y distribución definida? ¿Con qué frecuencia se genera y a qué órganos de gobierno se reporta? |
| 82 | Documentación | 3/5 | ¿Existe un registro de cambios históricos en la metodología (versiones anteriores, cambios de parámetros, decisiones de revisión)? ¿Cómo se comunican cambios a usuarios del modelo? |
| 83 | Documentación | 3/5 | ¿Cuál es el contenido específico del anexo A? Proporcionar el registro completo de cambios desde la versión 1.0 (2026-03-15) hasta la fecha actual, incluyendo: fecha de cambio, descripción del cambio, justificación, autor, y evidencia de aprobación. |
| 84 | Documentación | 3/5 | ¿Existe un procedimiento documentado que defina quién está autorizado a solicitar cambios, quién los aprueba, qué criterios se aplican para aceptar/rechazar un cambio, y cómo se comunican a los usuarios del modelo? |
| 85 | Documentación | 3/5 | ¿Se ha ejecutado algún cambio al modelo o su documentación desde 2026-03-15? Si es así, ¿cómo se registró y aprobó? Si no, ¿por qué el backtesting de Q1 2026 no generó cambios (por ejemplo, revisión de la ventana de 500 días, ajuste de umbrales, o actualización de limitaciones)? |
| 86 | Documentación | 3/5 | ¿El control de cambios está integrado en un sistema de gestión de configuración (CMS) o equivalente, o es un registro manual? ¿Existe trazabilidad de quién accedió, modificó y aprobó cada versión? |
| 87 | Documentación | 3/5 | ¿Se comunica el historial de cambios a los usuarios finales del modelo (mesas de negociación, comités de riesgo, supervisores internos)? ¿Existe un log de distribución de versiones? |
| 88 | Documentación | 3/5 | ¿Existe el anexo C del manual con el estudio de sensibilidad de ventanas? Si existe, ¿qué metodología se usó para determinar que 500 días es óptimo (ej: minimizar excedencias, maximizar estabilidad, criterio de información)? |
| 89 | Documentación | 3/5 | ¿Existe un manual operativo que describa paso a paso la ejecución del cálculo de VaR (fuentes de datos, tratamiento de faltantes, frecuencia de actualización, responsables, controles de calidad)? |
| 90 | Documentación | 3/5 | ¿Hay logs o registros de ejecución del backtesting mensual (fechas, responsable, resultado, acciones tomadas si hay incumplimiento)? |
| 91 | Documentación | 3/5 | ¿Se revisa periódicamente (ej: anualmente) si la ventana de 500 días sigue siendo apropiada? ¿Existe un proceso documentado para ello? |
| 92 | Documentación | 3/5 | ¿Cómo se integra el Expected Shortfall en la gestión de riesgos? ¿Se usa para decisiones de capital, límites, o solo como métrica complementaria de información? |
| 93 | Documentación | 3/5 | ¿Por qué se descartó VaR paramétrico o simulación de Montecarlo? ¿Hay un análisis comparativo documentado? |
| 94 | Documentación | 3/5 | ¿Existe un manual operativo que describa paso a paso cómo se calcula el VaR (extracción de datos, cálculo del percentil, validaciones, almacenamiento de resultados)? Si existe, ¿está disponible para revisión? |
| 95 | Documentación | 3/5 | ¿Cuál es el contenido exacto del anexo C (estudio de sensibilidad)? ¿Qué ventanas se probaron, sobre qué período, y con qué criterio de aceptación se eligió 500 días? |
| 96 | Documentación | 3/5 | ¿Existe un script o código que implemente el cálculo del VaR? Si existe, ¿implementa exactamente lo que el manual describe (ventana de 500 días, percentil al 1%, horizonte 1 día)? |
| 97 | Documentación | 3/5 | ¿Quién ejecuta el backtesting mensual? ¿Existe un log o un registro de ejecución que demuestre que se corrió en los últimos 3 meses con datos reales? |
| 98 | Documentación | 3/5 | ¿El intervalo de Kupiec mencionado en el anexo C se refiere al intervalo de confianza al 95% (zona verde de Basilea) o a otro nivel? ¿Cómo se calibró ese umbral? |
| 99 | Documentación | 3/5 | ¿Se ejecuta el backtesting en ventana móvil (rolling) o en ventana fija? ¿Se revisa la estabilidad del modelo en períodos de estrés (ej. 2020, 2022)? |
| 100 | Documentación | 3/5 | ¿El manual operativo o el informe de seguimiento incluyen controles de calidad de datos (valores faltantes, outliers, cambios de divisa)? Si no, ¿cómo se asegura la integridad de los retornos históricos? |
| 101 | Documentación | 3/5 | ¿Dónde está el anexo C con el estudio de sensibilidad de ventanas? ¿Qué criterios se usaron para descartar ventanas menores a 250 días además del intervalo de Kupiec? |
| 102 | Documentación | 3/5 | ¿Existe un manual operativo que describa el proceso de cálculo paso a paso (fuentes de datos, transformaciones, validaciones, frecuencia de ejecución, responsables)? |
| 103 | Documentación | 3/5 | ¿Cómo se valida la calidad de los datos de entrada (completitud, outliers, gaps, datos faltantes en días de mercado cerrado)? ¿Existe documentación de esos controles y evidencia de su ejecución? |
| 104 | Documentación | 3/5 | ¿Por qué el informe de backtesting no incluye análisis de las 3 excedencias observadas (fechas, causas, factores de riesgo involucrados)? ¿Se ejecutó ese análisis pero no se reportó? |
| 105 | Documentación | 3/5 | ¿Se verifican los supuestos del modelo (estacionariedad de retornos, independencia de factores, normalidad)? ¿Con qué frecuencia y mediante qué pruebas? |
| 106 | Documentación | 3/5 | ¿Por qué no se incluye el test de López (independencia condicional) o el test de Berkowitz (normalidad) en el backtesting, dado que son estándar en la literatura? |
| 107 | Documentación | 3/5 | ¿Cuál es el horizonte de validez del modelo? ¿Se revisa la documentación cuando cambian las condiciones de mercado o la composición de la cartera? |
| 108 | Documentación | 3/5 | ¿Dónde está el anexo A del manual metodológico? ¿Contiene el historial completo de cambios con fechas, autores, autorizaciones y justificaciones? |
| 109 | Documentación | 3/5 | ¿Existe un registro de cambios en los scripts de cálculo (calcula_var.py u equivalente) que sea trazable al anexo A del manual? ¿Se versionan conjuntamente? |
| 110 | Documentación | 3/5 | ¿Quién es responsable de autorizar cambios en el modelo (Comité de Riesgos, Junta de Riesgos, otra instancia)? ¿Existe un procedimiento documentado? |
| 111 | Documentación | 3/5 | ¿El anexo C (estudio de sensibilidad que justifica la ventana de 500 días) está disponible? ¿Se ha revisado desde su aprobación inicial, dado que el backtesting Q1 2026 muestra una tasa de excedencias 7.8 veces superior a la esperada? |
| 112 | Documentación | 3/5 | ¿Existe un control de cambios que vincule versiones del manual con versiones del código y con períodos de backtesting? ¿Cómo se asegura que el backtesting se ejecuta contra la versión correcta del modelo? |
| 113 | Documentación | 3/5 | ¿Se han realizado cambios al modelo entre la aprobación inicial (2026-03-15) y el backtesting Q1 2026? Si es así, ¿están documentados en el anexo A? |
| 114 | Documentación | 3/5 | ¿Dónde está el manual operativo que describe paso a paso cómo se ejecuta el cálculo de VaR, la recolección de datos, la validación de inputs y la generación del informe de seguimiento? |
| 115 | Documentación | 3/5 | ¿Existe el anexo C (estudio de sensibilidad de ventanas) y puede proporcionarse para validación? ¿Qué criterios se usaron para determinar que 500 días es superior a otras opciones? |
| 116 | Documentación | 3/5 | ¿El backtesting se ejecuta realmente MENSUAL como declara el manual, o solo trimestralmente? ¿Existen logs o reportes mensuales que lo demuestren? |
| 117 | Documentación | 3/5 | ¿Qué acciones se toman cuando el backtesting falla (excedencias fuera del intervalo de Kupiec o agrupamiento en Christoffersen)? ¿Existe un protocolo documentado de escalamiento? |
| 118 | Documentación | 3/5 | ¿Se verifica que los supuestos de Kupiec (independencia de excedencias, estacionariedad) se mantienen en esta cartera? ¿Hay análisis de autocorrelación o cambios de régimen? |
| 119 | Documentación | 3/5 | ¿Se aplica el test de López (independencia condicional) además de Christoffersen, o se descartó deliberadamente? Si se descartó, ¿cuál es la justificación? |
| 120 | Documentación | 3/5 | ¿Cómo se integran los resultados del backtesting en las decisiones de gestión de riesgos? ¿Llegan a algún comité de riesgos o solo se archivan? |
| 121 | Documentación | 3/5 | ¿Se monitorea la calidad de los datos de entrada (precios, retornos)? ¿Existe un procedimiento documentado de validación de datos antes del cálculo de VaR? |
| 122 | Documentación | 3/5 | ¿Cuál es el contenido del Anexo C (estudio de sensibilidad de ventanas)? ¿Se evaluaron ventanas de 250, 375, 500, 750 días? ¿Cuál fue el criterio de selección final? |
| 123 | Documentación | 3/5 | ¿Existe un proceso operativo documentado para la ejecución mensual del backtesting? ¿Quién lo ejecuta, en qué fecha, con qué datos, y cuál es el flujo de escalación si Kupiec se rechaza? |
| 124 | Documentación | 3/5 | ¿Se documentan y analizan las 3 excedencias observadas en Q1 2026? ¿Qué posiciones, factores de riesgo y eventos de mercado las explican? ¿Se validó que fueron eventos extremos no capturados por el modelo o errores de cálculo? |
| 125 | Documentación | 3/5 | ¿Existe un proceso de monitoreo de calidad de datos? ¿Se verifica completitud, outliers, reconciliación con fuentes externas, tratamiento de días con mercados cerrados o datos incompletos? |
| 126 | Documentación | 3/5 | ¿Se ejecuta y reporta el Expected Shortfall mensualmente? ¿Cómo se integra en la gestión de riesgos y en los reportes al Comité? |
| 127 | Documentación | 3/5 | ¿Se ejecuta la prueba de Christoffersen (independencia de excedencias) en todos los períodos o solo cuando se detecta agrupamiento? ¿Cuál es el criterio de rechazo? |
| 128 | Documentación | 3/5 | ¿Se ha evaluado la potencia de las pruebas de Kupiec y Christoffersen con el tamaño muestral disponible (62 días)? ¿Cuál es la probabilidad de detectar un modelo mal calibrado con esta muestra? |
| 129 | Metodología | 3/5 | ¿Está disponible el anexo C del manual con el análisis de sensibilidad de ventanas? Sin él, la justificación de 500 días no es verificable. |
| 130 | Metodología | 3/5 | ¿Se han ejecutado pruebas de estacionariedad (ADF, KPSS) y autocorrelación (Ljung-Box) sobre los retornos de la cartera? ¿Cuáles fueron los resultados? |
| 131 | Metodología | 3/5 | ¿Por qué se eligió VaR histórico frente a VaR paramétrico o simulación de Montecarlo? ¿Qué alternativas se evaluaron y por qué se descartaron? |
| 132 | Metodología | 3/5 | ¿Se ejecuta la prueba de López (independencia temporal de excedencias) además de Kupiec y Christoffersen? Si no, ¿por qué se omite? |
| 133 | Metodología | 3/5 | ¿El backtesting se realiza sobre P&L hipotético (cartera congelada) o real (con operaciones intradía)? ¿Se reportan ambos por separado? |
| 134 | Metodología | 3/5 | ¿Cuál es el protocolo de integración entre VaR y Expected Shortfall en la gestión de riesgos? ¿Cómo se usan conjuntamente para tomar decisiones? |
| 135 | Metodología | 3/5 | ¿Se ha evaluado la potencia estadística de las pruebas de Kupiec y Christoffersen con una muestra de 62 días? ¿Cuál es el tamaño mínimo de muestra recomendado para esta cartera? |
| 136 | Metodología | 3/5 | ¿Se verifica periódicamente que la ventana de 500 días sigue siendo óptima, o se fijó una sola vez? ¿Hay un protocolo de revisión? |
| 137 | Metodología | 3/5 | ¿Se reportan los resultados de backtesting a un comité de riesgos y se toman acciones correctivas si se detectan excedencias? ¿Hay trazabilidad de decisiones? |
| 138 | Metodología | 3/5 | ¿Existe análisis comparativo de backtesting entre VaR histórico y modelos alternativos (paramétrico, Montecarlo)? Si no, ¿por qué se descartaron? |
| 139 | Metodología | 3/5 | ¿Cuál es el intervalo de confianza exacto de Kupiec para 62 observaciones al 99%? ¿Se considera que 62 días es suficiente para validar, o se planifica backtesting rolling con ventana mayor? |
| 140 | Metodología | 3/5 | ¿Se ejecutó el test de Christoffersen? Proporcionar estadístico, p-valor e intervalo de confianza, no solo conclusión cualitativa. |
| 141 | Metodología | 3/5 | ¿Se verificó estacionariedad de los retornos? ¿Se realizaron contrastes ADF, KPSS o análisis de cambios estructurales (Chow)? |
| 142 | Metodología | 3/5 | ¿Por qué se usa VaR 99% para backtesting si FRTB requiere ES 97.5% para capital? ¿Se valida también ES, o VaR es solo para control interno? |
| 143 | Metodología | 3/5 | ¿Dónde está el anexo C (estudio de sensibilidad de ventanas)? ¿Cubre qué rango de ventanas y con qué criterio se seleccionó 500? |
| 144 | Metodología | 3/5 | ¿Se realiza backtesting rolling (ventana móvil) o solo trimestral? ¿Cuál es la frecuencia de revisión de la ventana? |
| 145 | Metodología | 3/5 | ¿Cómo se mitiga el riesgo de liquidez de mercado que el manual declara que no captura? ¿Existe un modelo complementario (ES, stress testing) que se integra en decisiones de riesgo? |
| 146 | Metodología | 3/5 | ¿Está disponible el anexo C (estudio de sensibilidad) que justifica la elección de la ventana de 500 días? ¿Qué alternativas se evaluaron y por qué se descartaron? |
| 147 | Metodología | 3/5 | ¿Cuál es la metodología exacta del VaR histórico implementada? (percentil simple vs interpolado, tratamiento de outliers, ajustes por volatilidad, etc.) |
| 148 | Metodología | 3/5 | ¿Se dispone del histórico completo de backtesting mensual desde la aprobación del modelo (2026-03-15)? ¿Hay variabilidad en el número de excedencias mes a mes? |
| 149 | Metodología | 3/5 | ¿Se ha realizado un análisis de potencia estadística de la prueba de Kupiec para n=62? ¿Cuál es el tamaño de muestra mínimo recomendado para que el backtesting sea concluyente? |
| 150 | Metodología | 3/5 | ¿Se han explicado las 3 excedencias observadas? ¿En qué fechas ocurrieron, qué factores de riesgo las causaron, y eran predecibles o eventos extremos legítimos? |
| 151 | Metodología | 3/5 | ¿Se backtestea también el Expected Shortfall? ¿Cómo se integra el ES en la gestión de riesgos y en las decisiones de límites? |
| 152 | Metodología | 3/5 | ¿Se han realizado contrastes de estacionariedad, cambios de régimen, o análisis de colas en la serie de retornos históricos? |
| 153 | Metodología | 3/5 | ¿Cómo se trata el backtesting en días con datos incompletos o mercados cerrados? ¿Se excluyen esos días o se imputa algún valor? |
| 154 | Metodología | 3/5 | ¿Puede proporcionarse el anexo C del manual para verificar el rango de ventanas evaluadas, los criterios de selección y la conclusión que llevó a elegir 500 días? |
| 155 | Metodología | 3/5 | ¿Se ejecutan realmente backtestings mensuales independientes, o el reporte trimestral agregado es la única salida? Si son mensuales, ¿cuáles fueron los resultados de enero y febrero de 2026? |
| 156 | Metodología | 3/5 | ¿Se ha realizado análisis de sensibilidad a nivel de confianza (ej. 97.5%, 99%, 99.9%) y horizonte (1 día vs 10 días)? ¿Cómo se justificó la elección de 99% y 1 día? |
| 157 | Metodología | 3/5 | ¿Existen pruebas de estacionariedad o análisis de cambios de régimen en los retornos históricos de la cartera? ¿Se verificó que la distribución histórica de los últimos 500 días es representativa de la distribución esperada? |
| 158 | Metodología | 3/5 | ¿Se han aplicado escenarios de estrés (históricos o hipotéticos) al modelo VaR? ¿Cuál sería el VaR bajo un escenario de volatilidad +50% o correlación +0.2? |
| 159 | Metodología | 3/5 | ¿A qué comité o proceso de decisión se reportan los resultados del análisis de sensibilidad y backtesting? ¿Qué umbral de sensibilidad o excedencia dispara una revisión de la metodología? |
| 160 | Metodología | 3/5 | ¿Dónde está el anexo C del manual (estudio de sensibilidad de ventanas)? Sin él no puede verificarse la justificación de 500 días. |
| 161 | Metodología | 3/5 | ¿Se ejecuta backtesting mensual como declara el manual §3, o solo trimestral? Proporcionar los resultados mensuales de 2026 Q1. |
| 162 | Metodología | 3/5 | ¿Qué ocurre operativamente cuando Kupiec entra en zona amarilla o roja? ¿Quién revisa, con qué frecuencia, y qué acciones correctivas se toman? |
| 163 | Metodología | 3/5 | ¿Se ha ejecutado backtesting rolling (ventana móvil) o anual? 62 días es insuficiente para validar un modelo de 99% según Basilea III. |
| 164 | Metodología | 3/5 | ¿Se han verificado los supuestos del método histórico (estacionariedad, suficiencia de ventana en estrés, cambios de régimen)? Proporcionar contrastes estadísticos. |
| 165 | Metodología | 3/5 | ¿Por qué no se incluye la prueba de López (clustering temporal) además de Christoffersen? ¿Es una limitación deliberada o una omisión? |
| 166 | Metodología | 3/5 | ¿Cómo se integra el VaR a límites de posición, capital, o decisiones de cobertura? ¿Hay comité que revise los resultados de backtesting? |
| 167 | Metodología | 3/5 | ¿Se ha validado que 500 días captura adecuadamente la distribución en periodos de estrés o volatilidad extrema? |

> ✍️ **Te toca:** depura antes de enviar. Algunas se responderán con un
> documento que ya existe y no llegó a `inputs/` — ésas no son hallazgos,
> son evidencia que faltó aportar.

## 5. Detalle por ámbito

### Documentación  ·  score 2.89

#### 🟠 [2/5] Verifica la inclusión del objetivo, usos y usuarios del modelo

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verificación de la existencia, suficiencia y claridad del Manual Metodológico en cuanto a objetivo, usos y usuarios del modelo VaR FRTB. Esta sección es crítica porque define el propósito, alcance y responsabilidades de gobernanza del modelo, y su ausencia o incompletitud invalida la trazabilidad de decisiones de riesgo.

**Hallazgo.**

El manual metodológico existe y declara explícitamente su objetivo (sección 1), pero presenta brechas CRÍTICAS en dos de los tres elementos solicitados: usos y usuarios. La sección 1 afirma 'Estimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III)', lo que define QUÉ calcula el modelo, pero no PARA QUÉ se usa ni QUIÉN lo usa. El manual no especifica: (a) los comités, procesos de decisión o límites de riesgo que dependen de este VaR; (b) los usuarios finales (tesorería, mesa de negociación, comité de riesgos, supervisores internos); (c) la frecuencia de reporte a cada usuario; (d) las acciones que se disparan si el VaR excede umbrales. La sección 4 menciona limitaciones ('No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall'), lo que implícitamente reconoce que el modelo se usa en un contexto más amplio, pero ese contexto no está documentado. Sin esta información, no es posible verificar si el modelo está calibrado para su propósito real, si los usuarios entienden sus limitaciones, o si las decisiones que se toman sobre él son apropiadas. El backtesting (sección 3) está bien descrito metodológicamente, pero desconectado de cualquier uso operativo: no se declara qué ocurre si Kupiec falla, quién lo revisa, o cómo afecta a la aprobación de posiciones. Esto es un cumplimiento parcial con brechas NO críticas en metodología, pero CRÍTICAS en gobernanza.

**Evidencia citada.**

> manual_VaR_FRTB.md → "## 1. Objetivo\nEstimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III)."
>
> manual_VaR_FRTB.md → "## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.\nResultados del último trimestre en el informe de seguimiento."
>
> manual_VaR_FRTB.md → "## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."
>
> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 1. Objetivo\nEstimar el Value at Risk de la cartera de negociación bajo el ma»
> - «## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (»
> - «## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con»
> - «## 1. Objetivo\nEstimar el Value at Risk de la cartera de negociación bajo el ma»
> - «## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con»

**Preguntas al modelador.**

- [ ] ¿Cuáles son los usos específicos del VaR estimado por este modelo? ¿Se utiliza para: (a) cálculo de capital regulatorio, (b) límites internos de riesgo, (c) reporte a supervisores, (d) decisiones de cobertura, (e) todas las anteriores?
- [ ] ¿Quiénes son los usuarios finales del modelo? Especificar: mesas de negociación, tesorería, comité de riesgos, supervisores internos, autoridades regulatorias.
- [ ] ¿Cuál es la relación entre este VaR y el Expected Shortfall mencionado en limitaciones? ¿Se calcula ES en paralelo? ¿Cuál es la medida de capital regulatorio bajo FRTB que esta entidad reporta a supervisores?
- [ ] ¿Qué acciones se disparan si el backtesting de Kupiec falla (p-valor < 0.05)? ¿Quién es responsable de investigar y reportar? ¿Se suspende el uso del modelo?
- [ ] ¿Con qué frecuencia se reporta el VaR a cada usuario? ¿Diaria, semanal, mensual? ¿Existen umbrales de escalación?
- [ ] ¿El manual operativo (mencionado implícitamente pero no proporcionado) describe el flujo de datos, responsables de ejecución y validación de inputs?

**Recomendación.** Ampliar el manual metodológico con una sección 2 (antes de Metodología) titulada 'Usos y Usuarios' que incluya: (a) matriz de usuarios finales y frecuencia de reporte; (b) procesos de decisión que dependen del VaR (límites, capital, cobertura); (c) umbrales de escalación y acciones asociadas; (d) clarificación de la relación con ES bajo FRTB (¿es VaR una medida complementaria o legado?); (e) responsables de cada uso. Además, crear un manual operativo separado que describa paso a paso la ejecución, validación de datos, y qué ocurre si el backtesting falla. Esto es requisito mínimo para que el modelo sea trazable y gobernable.

<sub>cobertura documental 100.0% · RAG VaR (5 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `694977132718`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verifica la existencia de control de cambios/versiones

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verificar la existencia, suficiencia y claridad del control de cambios/versiones en el manual metodológico de VaR FRTB. Este control es crítico para la trazabilidad de decisiones, la reproducibilidad del modelo y el cumplimiento de SR 11-7 (documentación y gobierno).

**Hallazgo.**

El manual metodológico declara explícitamente la existencia de control de cambios ("Control de cambios en anexo A") y proporciona metadatos de versión (v1.0, aprobación 2026-03-15). Sin embargo, el contexto disponible NO incluye el anexo A ni evidencia de su contenido, estructura o ejecución. La mención del control de cambios es DECLARATIVA, no DEMOSTRATIVA. Se observa que el manual describe la metodología (ventana 500 días, nivel 99%, horizonte 1 día) y cita un estudio de sensibilidad en anexo C que justifica la elección de ventana, pero ese anexo tampoco está disponible para validación. El backtesting (Kupiec y Christoffersen) se menciona como ejecutado mensualmente, con resultados en "informe de seguimiento", pero ese informe no está en el contexto. La brecha crítica es que no se puede verificar: (1) si el control de cambios existe realmente y qué estructura tiene; (2) si registra cambios históricos, quién autoriza, cuándo se revisan; (3) si la ejecución del backtesting y el estudio de sensibilidad están documentados con trazabilidad de versiones. Un manual que dice "existe control en anexo A" sin que el anexo esté disponible para auditoría es una AFIRMACIÓN NO VERIFICADA. Esto es cumplimiento parcial porque la intención está documentada, pero la evidencia de su implementación y suficiencia no está presente.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Anexo A no incluido en la cobertura documental»
> - «Anexo C no incluido en la cobertura documental»
> - «backtesting_VaR_2026Q1.md contiene resultados de Q1 2026, pero no está claro si »

**Preguntas al modelador.**

- [ ] ¿Cuál es la estructura exacta del control de cambios en anexo A? ¿Registra cambios históricos, quién autoriza, con qué frecuencia se revisa, y cómo se comunican cambios a usuarios del modelo?
- [ ] ¿El anexo C (estudio de sensibilidad) incluye análisis de ventanas alternativas (250, 375, 625, 750 días)? ¿Sobre qué período histórico se ejecutó? ¿Se repitió en múltiples períodos para verificar robustez?
- [ ] ¿Por qué se eligió ventana de 500 días en lugar de 250 o 375? ¿Existe literatura o benchmarking de la industria que respalde esta elección?
- [ ] ¿Por qué se descartó el test de López (cobertura condicional) o Berkowitz (distribución) en favor de solo Kupiec y Christoffersen? ¿Qué limitaciones tiene esta elección?
- [ ] ¿El "informe de seguimiento" es un documento formal con versión, fecha, autorización y distribución definida? ¿Con qué frecuencia se genera y a qué órganos de gobierno se reporta?
- [ ] ¿Existe un registro de cambios históricos en la metodología (versiones anteriores, cambios de parámetros, decisiones de revisión)? ¿Cómo se comunican cambios a usuarios del modelo?

**Recomendación.** 1. INMEDIATO: Proporcionar anexo A (control de cambios) con estructura clara: columnas de versión, fecha, cambio, justificación, autorización, y registro de al menos 2-3 cambios históricos (o declarar si v1.0 es la primera versión). 2. INMEDIATO: Proporcionar anexo C (estudio de sensibilidad) con análisis de ventanas alternativas, período de datos, resultados de Kupiec para cada ventana, y conclusión explícita de por qué 500 días es óptimo. 3. CORTO PLAZO: Ampliar la sección 2 (Metodología) del manual con justificación de alternativas descartadas: por qué 500 días vs. 250/375/625, por qué 99% vs. 97.5%, por qué Kupiec+Christoffersen vs. López/Berkowitz. Citar literatura de referencia (Jorion, Dowd, BCBS 457). 4. CORTO PLAZO: Formalizar el "informe de seguimiento" como documento con versión, fecha, autorización, distribución y frecuencia definida (mensual, trimestral). Incluir metadatos de ejecución del backtesting (fecha de cálculo, datos usados, resultados de Kupiec y Christoffersen con p-valores). 5. MEDIANO PLAZO: Establecer un proceso de revisión periódica del control de cambios (anual mínimo) para evaluar si la metodología sigue siendo adecuada a la cartera y al entorno de mercado.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `60ac49ff38c2`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verifica la existencia de control de cambios/versiones

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verifica la existencia, suficiencia y claridad de un sistema de control de cambios/versiones en la documentación del modelo VaR FRTB. Este control es crítico para la trazabilidad, auditabilidad y gobernanza del modelo, especialmente en entornos regulados donde cada cambio debe ser autorizado, documentado y rastreable.

**Hallazgo.**

El manual metodológico declara explícitamente la existencia de control de cambios: manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A." Esto demuestra que existe un mecanismo de versionado y que se ha establecido un proceso de aprobación formal. Sin embargo, la evidencia disponible presenta tres brechas críticas que impiden calificar este cumplimiento como completo: (1) el anexo A (donde reside el registro de cambios) no está incluido en el contexto disponible, por lo que no es posible verificar si el control de cambios es operativo, detallado y accesible; (2) no hay evidencia de que el control de cambios esté integrado en un proceso de gobernanza documentado (quién autoriza cambios, qué criterios se aplican, cómo se comunican); (3) no existe rastro de cambios posteriores a la versión 1.0 (aprobada 2026-03-15) en los documentos de seguimiento (backtesting_VaR_2026Q1.md), lo que genera incertidumbre sobre si el sistema de control está siendo ejecutado o si es solo una declaración de intención. La práctica estándar en validación de modelos financieros exige que el control de cambios incluya: historial de versiones con fechas, autores, cambios específicos, justificación del cambio, y aprobación documentada. La ausencia del anexo A impide verificar estos elementos. Para cumplimiento parcial (nivel 3) se reconoce que existe declaración formal y aprobación inicial; para avanzar al nivel 4 se requeriría acceso al anexo A y evidencia de ejecución del control en cambios posteriores.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> manual_VaR_FRTB.md → "## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día.\nLa elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> No se encontró evidencia en el contexto disponible del anexo A (registro de cambios) ni de cambios documentados posteriores a la versión 1.0.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%»
> - «Backtesting VaR — 2026 Q1 / Excedencias observadas: 3 sobre 62 días.»

**Preguntas al modelador.**

- [ ] ¿Cuál es el contenido específico del anexo A? Proporcionar el registro completo de cambios desde la versión 1.0 (2026-03-15) hasta la fecha actual, incluyendo: fecha de cambio, descripción del cambio, justificación, autor, y evidencia de aprobación.
- [ ] ¿Existe un procedimiento documentado que defina quién está autorizado a solicitar cambios, quién los aprueba, qué criterios se aplican para aceptar/rechazar un cambio, y cómo se comunican a los usuarios del modelo?
- [ ] ¿Se ha ejecutado algún cambio al modelo o su documentación desde 2026-03-15? Si es así, ¿cómo se registró y aprobó? Si no, ¿por qué el backtesting de Q1 2026 no generó cambios (por ejemplo, revisión de la ventana de 500 días, ajuste de umbrales, o actualización de limitaciones)?
- [ ] ¿El control de cambios está integrado en un sistema de gestión de configuración (CMS) o equivalente, o es un registro manual? ¿Existe trazabilidad de quién accedió, modificó y aprobó cada versión?
- [ ] ¿Se comunica el historial de cambios a los usuarios finales del modelo (mesas de negociación, comités de riesgo, supervisores internos)? ¿Existe un log de distribución de versiones?

**Recomendación.** 1. Proporcionar el anexo A completo (registro de cambios) como parte de la documentación de validación. 2. Documentar explícitamente el procedimiento de control de cambios, incluyendo roles, autoridades, criterios de aprobación, y plazos. 3. Ejecutar una revisión de cambios pendientes: evaluar si los resultados del backtesting Q1 2026 (3 excedencias, Kupiec LR=3.81) justifican cambios en parámetros, supuestos o limitaciones del modelo, y documentar la decisión (cambio o no cambio) con justificación. 4. Implementar un sistema de versionado que vincule cambios a decisiones de gobernanza (actas de comité, aprobaciones formales) y que sea accesible a auditores internos y supervisores. 5. Establecer un calendario de revisión periódica (al menos anual) del manual metodológico, independientemente de si hay cambios, para verificar que los supuestos siguen siendo válidos.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `06241aad17fd`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verifica la existencia , suficiencia y claridad de la documentación

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verifica la existencia, suficiencia y claridad de la documentación del modelo VaR FRTB. Esta actividad es crítica porque la documentación es el puente entre el diseño del modelo y su ejecución operativa; sin ella, no hay trazabilidad ni control de cambios, y los riesgos de implementación divergente se multiplican.

**Hallazgo.**

La documentación existe y cubre los elementos básicos: existe un manual metodológico con control de versiones declarado (manual_VaR_FRTB.md → 'Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A'), describe el objetivo (sección 1), la metodología (ventana de 500 días, nivel 99%, horizonte 1 día), y menciona backtesting con Kupiec y Christoffersen (sección 3). Sin embargo, existen brechas críticas de suficiencia y claridad que impiden una validación completa: (1) El manual declara que 'la elección de la ventana se justifica en el estudio de sensibilidad del anexo C' pero el anexo C NO está en el contexto disponible — no se puede verificar si esa justificación existe realmente o si es sólida. (2) El manual menciona backtesting 'mensual' pero el informe de seguimiento (backtesting_VaR_2026Q1.md) solo reporta resultados agregados de Q1 sin desglose mensual, sin fechas de ejecución, sin logs de proceso, y sin evidencia de que se ejecutó realmente (EXISTE ≠ SE EJECUTA). (3) No hay manual operativo que describa paso a paso cómo se calcula el VaR, quién lo ejecuta, cuándo, con qué datos, qué controles de calidad se aplican, cómo se manejan datos faltantes o anomalías. (4) El manual declara limitaciones ('No captura riesgo de liquidez de mercado') pero no especifica cómo se mitigan ni cómo se comunican al usuario final. (5) No hay evidencia de un proceso de revisión periódica de supuestos (ej: ¿se revisa anualmente si la ventana de 500 días sigue siendo óptima?). Para alcanzar puntaje 4 se requeriría: acceso al anexo C con justificación cuantitativa de la ventana, manual operativo detallado con trazabilidad de ejecución, logs de backtesting mensual con fechas y responsables, y evidencia de revisión periódica de supuestos. La cobertura documental es parcial (no se procesó el anexo C ni el manual operativo si existe), lo que introduce incertidumbre sobre si las brechas son reales o solo ausencia de contexto.

**Evidencia citada.**

> manual_VaR_FRTB.md → 'Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A'
>
> manual_VaR_FRTB.md → 'VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C'
>
> manual_VaR_FRTB.md → 'Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento.'
>
> backtesting_VaR_2026Q1.md → 'Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias.'
>
> manual_VaR_FRTB.md → 'No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.'

**Preguntas al modelador.**

- [ ] ¿Existe el anexo C del manual con el estudio de sensibilidad de ventanas? Si existe, ¿qué metodología se usó para determinar que 500 días es óptimo (ej: minimizar excedencias, maximizar estabilidad, criterio de información)?
- [ ] ¿Existe un manual operativo que describa paso a paso la ejecución del cálculo de VaR (fuentes de datos, tratamiento de faltantes, frecuencia de actualización, responsables, controles de calidad)?
- [ ] ¿Hay logs o registros de ejecución del backtesting mensual (fechas, responsable, resultado, acciones tomadas si hay incumplimiento)?
- [ ] ¿Se revisa periódicamente (ej: anualmente) si la ventana de 500 días sigue siendo apropiada? ¿Existe un proceso documentado para ello?
- [ ] ¿Cómo se integra el Expected Shortfall en la gestión de riesgos? ¿Se usa para decisiones de capital, límites, o solo como métrica complementaria de información?
- [ ] ¿Por qué se descartó VaR paramétrico o simulación de Montecarlo? ¿Hay un análisis comparativo documentado?

**Recomendación.** 1. Proporcionar el anexo C del manual con el estudio de sensibilidad de ventanas, incluyendo la metodología, datos usados, y conclusiones cuantitativas. 2. Elaborar un manual operativo que describa: (a) proceso de cálculo paso a paso, (b) fuentes de datos y criterios de calidad, (c) tratamiento de anomalías y faltantes, (d) frecuencia y responsables de ejecución, (e) controles de validación. 3. Documentar el proceso de backtesting mensual con logs que incluyan: fecha de ejecución, período cubierto, responsable, resultados (Kupiec, Christoffersen), interpretación, y acciones correctivas si aplica. 4. Establecer un proceso formal de revisión anual de supuestos (ventana, nivel de confianza, horizonte) con documentación de decisiones. 5. Clarificar el rol del Expected Shortfall en la gestión: ¿es métrica de información, insumo para decisiones de capital, o complemento obligatorio del VaR? Documentar cómo se usa en comités y decisiones operativas.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a5a14fe7b957`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verificar la coherencia del manual de implementación con el manual métodolocios

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificar que el manual metodológico y el manual operativo (si existe) sean coherentes entre sí, que describan la implementación real del modelo VaR FRTB, y que el backtesting esté documentado con rigor técnico (Kupiec, Christoffersen). Esta coherencia es crítica porque un manual impecable puede describir un proceso que nunca se ejecuta, o un código que implementa algo distinto a lo documentado.

**Hallazgo.**

La documentación disponible demuestra EXISTENCIA de elementos clave pero con BRECHAS DE INTEGRACIÓN Y VERIFICACIÓN. El manual metodológico (manual_VaR_FRTB.md) declara explícitamente: (1) objetivo claro (sección 1), (2) metodología con ventana de 500 días y nivel 99% (sección 2), (3) backtesting con Kupiec y Christoffersen mensual (sección 3), y (4) control de cambios en anexo A. El informe de seguimiento (backtesting_VaR_2026Q1.md) reporta resultados concretos: 3 excedencias en 62 días, Kupiec LR=3.81 (p=0.051), no rechazo al 5%, y ausencia de agrupamiento. Sin embargo, existen tres brechas críticas: (A) NO HAY EVIDENCIA DE UN MANUAL OPERATIVO que describa paso a paso cómo se ejecuta el cálculo, quién lo ejecuta, cuándo, con qué datos y controles de calidad. El manual metodológico es teoría; la operación es ausente. (B) LA JUSTIFICACIÓN DE LA VENTANA DE 500 DÍAS se declara pero no se proporciona: el manual remite al "estudio de sensibilidad del anexo C" que no está en el contexto, por lo que no se puede verificar si la elección está realmente justificada o es una afirmación no respaldada. (C) NO SE PROPORCIONA EVIDENCIA DE EJECUCIÓN REAL: no hay logs, scripts, datos de entrada/salida, ni trazabilidad de cómo se llegó a los números reportados (3 excedencias, LR=3.81). El backtesting está reportado pero no está demostrado. Para subir a 4, se requiere: (i) manual operativo con descripción de procesos, responsables, frecuencia y controles; (ii) anexo C o documento equivalente que justifique la ventana de 500 días con análisis de sensibilidad explícito; (iii) logs o scripts que demuestren que el backtesting se ejecutó con datos reales y que el código implementa exactamente lo que el manual describe. La cobertura documental es parcial (no se proporcionó el anexo A de control de cambios ni el anexo C de sensibilidad), lo que introduce incertidumbre sobre si la documentación está completa.

**Evidencia citada.**

> manual_VaR_FRTB.md → "## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día.\nLa elección de la ventana se justifica en el estudio de sensibilidad del anexo C:
> ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.
> Resultados del último trimestre en el informe de seguimiento."
>
> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62.\nKupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea.\nChristoffersen: no se detecta agrupamiento de excedencias."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%»
> - «## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (»
> - «Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62.\nKupiec LR = 3.»

**Preguntas al modelador.**

- [ ] ¿Existe un manual operativo que describa paso a paso cómo se calcula el VaR (extracción de datos, cálculo del percentil, validaciones, almacenamiento de resultados)? Si existe, ¿está disponible para revisión?
- [ ] ¿Cuál es el contenido exacto del anexo C (estudio de sensibilidad)? ¿Qué ventanas se probaron, sobre qué período, y con qué criterio de aceptación se eligió 500 días?
- [ ] ¿Existe un script o código que implemente el cálculo del VaR? Si existe, ¿implementa exactamente lo que el manual describe (ventana de 500 días, percentil al 1%, horizonte 1 día)?
- [ ] ¿Quién ejecuta el backtesting mensual? ¿Existe un log o un registro de ejecución que demuestre que se corrió en los últimos 3 meses con datos reales?
- [ ] ¿El intervalo de Kupiec mencionado en el anexo C se refiere al intervalo de confianza al 95% (zona verde de Basilea) o a otro nivel? ¿Cómo se calibró ese umbral?
- [ ] ¿Se ejecuta el backtesting en ventana móvil (rolling) o en ventana fija? ¿Se revisa la estabilidad del modelo en períodos de estrés (ej. 2020, 2022)?
- [ ] ¿El manual operativo o el informe de seguimiento incluyen controles de calidad de datos (valores faltantes, outliers, cambios de divisa)? Si no, ¿cómo se asegura la integridad de los retornos históricos?

**Recomendación.** Entregar: (1) Manual operativo con descripción de procesos, responsables, frecuencia, fuentes de datos y controles de calidad. (2) Anexo C (estudio de sensibilidad) con análisis explícito de ventanas probadas, criterios de aceptación y justificación de la elección de 500 días. (3) Script o código fuente del cálculo del VaR con comentarios que mapeen cada línea al manual metodológico. (4) Log o registro de ejecución del backtesting de los últimos 3 meses (fechas, datos de entrada, resultados, quién ejecutó). (5) Aclaración sobre el intervalo de Kupiec usado en el anexo C y su relación con la zona verde de Basilea. Una vez entregados estos documentos, re-evaluar la coherencia manual ↔ código ↔ ejecución real.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `b6f71d657e1d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verifica la existencia, suficiencia y claridad de la documentación de implementación y calidad de datos para el modelo VaR FRTB. Esta actividad es crítica porque la documentación es el puente entre el diseño del modelo y su ejecución operativa; sin ella, no hay trazabilidad ni control.

**Hallazgo.**

La documentación demuestra EXISTENCIA de elementos clave pero con BRECHAS DE INTEGRACIÓN y AUSENCIAS que impiden una validación completa. El manual metodológico existe, declara su objetivo y metodología, y cita backtesting con Kupiec y Christoffersen. Sin embargo, hay tres problemas graves: (1) FALTA DE JUSTIFICACIÓN DE LA VENTANA: el manual afirma que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec» (manual_VaR_FRTB.md §2), pero no proporciona el estudio de sensibilidad del anexo C que supuestamente lo respalda — esto es una referencia a evidencia no incluida en el contexto, lo que impide verificar si la elección de 500 días está realmente justificada o es una afirmación sin respaldo. (2) AUSENCIA DE DOCUMENTACIÓN OPERATIVA: no existe un manual operativo que describa paso a paso cómo se ejecuta el cálculo, quién lo ejecuta, cuándo, con qué datos y qué controles se aplican — solo hay un manual metodológico. (3) AUSENCIA DE MONITOREO DE CALIDAD DE DATOS: el manual no menciona cómo se valida la calidad de los datos de entrada (completitud, outliers, gaps), ni existe documentación de seguimiento que demuestre que se ejecutan esos controles. (4) BACKTESTING INCOMPLETO: aunque se menciona Kupiec y Christoffersen, el informe de seguimiento (backtesting_VaR_2026Q1.md) solo reporta resultados agregados (3 excedencias, LR=3.81, p-valor 0.051) sin análisis de las excedencias individuales — la literatura estándar exige que cada excedencia sea explicada, no solo que el estadístico agregado pase. (5) FALTA DE DOCUMENTACIÓN DE LIMITACIONES Y SUPUESTOS: el manual declara que «no captura riesgo de liquidez de mercado» pero no documenta otros supuestos críticos (ej: estacionariedad de los retornos, independencia de los factores de riesgo, tratamiento de datos faltantes en días de mercado cerrado). Para alcanzar puntaje 4 sería necesario: (a) incluir o referenciar el estudio de sensibilidad que justifica la ventana de 500 días; (b) crear un manual operativo con procedimientos ejecutables; (c) documentar el proceso de validación de calidad de datos con evidencia de su ejecución; (d) ampliar el backtesting con análisis de excedencias individuales; (e) declarar explícitamente todos los supuestos y su verificación. La cobertura documental es parcial (no se proporcionó el anexo C ni logs de ejecución), por lo que hay incertidumbre sobre si la justificación existe pero no fue incluida en el contexto.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> No se encontró evidencia en el contexto disponible de: (a) manual operativo con procedimientos paso a paso; (b) documentación de validación de calidad de datos; (c) análisis de excedencias individuales; (d) anexo C con estudio de sensibilidad; (e) declaración explícita de supuestos (estacionariedad, independencia, tratamiento de faltantes).

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El anexo C no está incluido en la documentación proporcionada»

**Preguntas al modelador.**

- [ ] ¿Dónde está el anexo C con el estudio de sensibilidad de ventanas? ¿Qué criterios se usaron para descartar ventanas menores a 250 días además del intervalo de Kupiec?
- [ ] ¿Existe un manual operativo que describa el proceso de cálculo paso a paso (fuentes de datos, transformaciones, validaciones, frecuencia de ejecución, responsables)?
- [ ] ¿Cómo se valida la calidad de los datos de entrada (completitud, outliers, gaps, datos faltantes en días de mercado cerrado)? ¿Existe documentación de esos controles y evidencia de su ejecución?
- [ ] ¿Por qué el informe de backtesting no incluye análisis de las 3 excedencias observadas (fechas, causas, factores de riesgo involucrados)? ¿Se ejecutó ese análisis pero no se reportó?
- [ ] ¿Se verifican los supuestos del modelo (estacionariedad de retornos, independencia de factores, normalidad)? ¿Con qué frecuencia y mediante qué pruebas?
- [ ] ¿Por qué no se incluye el test de López (independencia condicional) o el test de Berkowitz (normalidad) en el backtesting, dado que son estándar en la literatura?
- [ ] ¿Cuál es el horizonte de validez del modelo? ¿Se revisa la documentación cuando cambian las condiciones de mercado o la composición de la cartera?

**Recomendación.** Acciones inmediatas para alcanzar puntaje 4: (1) Incluir o referenciar el anexo C con el estudio de sensibilidad de ventanas, documentando explícitamente qué alternativas se evaluaron y por qué se eligió 500 días. (2) Crear un manual operativo con procedimientos ejecutables: fuentes de datos, transformaciones, validaciones, frecuencia, responsables, logs de ejecución. (3) Documentar el proceso de validación de calidad de datos (completitud, outliers, faltantes) con evidencia de su ejecución (ej: logs de controles, reportes de excepciones). (4) Ampliar el informe de backtesting con análisis de excedencias individuales: fecha, P&L observado vs VaR, factores de riesgo involucrados, explicación de por qué el modelo no las capturó. (5) Declarar explícitamente todos los supuestos (estacionariedad, independencia, normalidad, tratamiento de faltantes) y documentar cómo se verifican. (6) Considerar incluir pruebas adicionales de backtesting (López, Berkowitz) o justificar por qué no aplican a esta cartera. (7) Establecer una cadencia de revisión de la documentación (ej: anual o cuando cambien condiciones de mercado) y documentar esas revisiones.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `4d768302698a`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verifica la existencia de control de cambios/versiones

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Verifica la existencia, suficiencia y claridad de un sistema de control de cambios/versiones en la documentación del modelo VaR FRTB. Este control es crítico para la trazabilidad, auditabilidad y gobernanza del modelo, especialmente en contextos regulatorios donde la reproducibilidad y la cadena de custodia documental son requisitos de cumplimiento.

**Hallazgo.**

La documentación demuestra EXISTENCIA de control de cambios, pero con BRECHAS DE INTEGRACIÓN y AUSENCIAS que impiden calificar como cumplimiento pleno. El manual metodológico declara explícitamente: manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A." Esto establece que existe un mecanismo de versionado y que hay un anexo dedicado. Sin embargo, el contexto disponible NO INCLUYE el anexo A, por lo que no es posible verificar: (1) qué cambios se han registrado históricamente, (2) quién autorizó cada cambio, (3) cuándo se realizaron, (4) cuál fue la justificación de cada modificación, (5) si existe trazabilidad entre versiones del manual y versiones del código de cálculo. El backtesting_VaR_2026Q1.md reporta resultados del Q1 2026 pero no indica contra qué versión del manual se ejecutó, ni si hubo cambios metodológicos entre trimestres que expliquen variaciones en los resultados. La ausencia del anexo A es una brecha crítica: un control de cambios que existe en teoría pero no está documentado en los registros disponibles no es verificable y, por tanto, no cumple con el estándar de auditoría de segunda línea. Para alcanzar puntaje 4 se requeriría: (a) acceso al anexo A completo con historial de cambios, (b) evidencia de que cada cambio fue autorizado por el Comité de Riesgos o autoridad equivalente, (c) trazabilidad explícita entre cambios en el manual y cambios en los scripts de cálculo, (d) justificación documentada de por qué se realizó cada cambio. La cobertura documental es parcial: se procesó el 100% de los documentos disponibles, pero el anexo A (explícitamente referenciado) no está en el contexto, lo que genera incertidumbre sobre si el control de cambios es realmente operativo o solo declarativo.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El anexo A no está incluido en los documentos proporcionados.»

**Preguntas al modelador.**

- [ ] ¿Dónde está el anexo A del manual metodológico? ¿Contiene el historial completo de cambios con fechas, autores, autorizaciones y justificaciones?
- [ ] ¿Existe un registro de cambios en los scripts de cálculo (calcula_var.py u equivalente) que sea trazable al anexo A del manual? ¿Se versionan conjuntamente?
- [ ] ¿Quién es responsable de autorizar cambios en el modelo (Comité de Riesgos, Junta de Riesgos, otra instancia)? ¿Existe un procedimiento documentado?
- [ ] ¿El anexo C (estudio de sensibilidad que justifica la ventana de 500 días) está disponible? ¿Se ha revisado desde su aprobación inicial, dado que el backtesting Q1 2026 muestra una tasa de excedencias 7.8 veces superior a la esperada?
- [ ] ¿Existe un control de cambios que vincule versiones del manual con versiones del código y con períodos de backtesting? ¿Cómo se asegura que el backtesting se ejecuta contra la versión correcta del modelo?
- [ ] ¿Se han realizado cambios al modelo entre la aprobación inicial (2026-03-15) y el backtesting Q1 2026? Si es así, ¿están documentados en el anexo A?

**Recomendación.** 1. CRÍTICO: Proporcionar el anexo A (control de cambios) completo, con historial de todas las versiones, cambios realizados, fechas, autores y autorizaciones. 2. CRÍTICO: Proporcionar el anexo C (estudio de sensibilidad) para verificar si la ventana de 500 días sigue siendo justificable a la luz de los resultados de backtesting Q1 2026. 3. Establecer un procedimiento documentado que vincule cambios en el manual metodológico con cambios en el código de cálculo y con la ejecución de backtesting, asegurando trazabilidad completa. 4. Implementar un registro de cambios que incluya: versión anterior, versión nueva, descripción del cambio, justificación, autor, fecha, autorización y resultado del backtesting post-cambio. 5. Revisar la metodología de la ventana de 500 días dado que la tasa de excedencias observada (4.84%) es significativamente superior a la esperada (0.62%), incluso si el test de Kupiec no rechaza al 5%.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `9140ccd800e3`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Verificar la existencia, suficiencia y claridad de la documentación

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Evaluación de la existencia, suficiencia y claridad de la documentación del modelo VaR Mercado FRTB, incluyendo manuales metodológicos, operativos y reportes de seguimiento con backtesting. Esta actividad es crítica porque la documentación deficiente impide la trazabilidad, reproducibilidad y supervisión del modelo.

**Hallazgo.**

La documentación demuestra EXISTENCIA de elementos clave pero con BRECHAS DE INTEGRACIÓN y AUSENCIAS que impiden una validación completa. Se encontró: (1) Manual metodológico con control de versiones y aprobación formal (manual_VaR_FRTB.md §1-4); (2) Backtesting ejecutado con prueba de Kupiec (backtesting_VaR_2026Q1.md: «Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%») y Christoffersen («no se detecta agrupamiento»); (3) Justificación de la ventana de 500 días mediante estudio de sensibilidad (manual_VaR_FRTB.md §2: «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec»). Sin embargo, existen BRECHAS CRÍTICAS: (A) El manual operativo NO está presente en el contexto — se menciona que debe existir pero no se proporcionó, lo que impide verificar si la ejecución real coincide con la descripción metodológica; (B) El informe de seguimiento es INCOMPLETO — solo contiene resultados de backtesting sin análisis de calidad de datos, monitoreo de supuestos, o documentación de decisiones tomadas en base a los resultados; (C) No hay evidencia de que los resultados del backtesting lleguen a ningún comité de decisión ni que generen acciones correctivas (TRAMPA 5: «SE CALCULA ≠ SE USA»); (D) La justificación de la ventana de 500 días se basa en un «estudio de sensibilidad del anexo C» que NO está disponible para validación independiente — es una referencia no verificable. Para alcanzar nivel 4 se requiere: (1) Manual operativo completo con descripción paso a paso de la ejecución; (2) Informe de seguimiento que documente monitoreo de datos, revisión de supuestos y decisiones derivadas; (3) Acceso al anexo C o reproducción del análisis de sensibilidad; (4) Evidencia de integración de resultados en comités de riesgo. La cobertura documental es parcial (100% de lo proporcionado, pero no del universo esperado), lo que genera incertidumbre sobre si las brechas son ausencias reales o limitaciones de contexto.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Anexo C no proporcionado en el contexto de validación»
> - «Backtesting VaR — 2026 Q1 [solo contiene resultados, sin contexto de decisiones »

**Preguntas al modelador.**

- [ ] ¿Dónde está el manual operativo que describe paso a paso cómo se ejecuta el cálculo de VaR, la recolección de datos, la validación de inputs y la generación del informe de seguimiento?
- [ ] ¿Existe el anexo C (estudio de sensibilidad de ventanas) y puede proporcionarse para validación? ¿Qué criterios se usaron para determinar que 500 días es superior a otras opciones?
- [ ] ¿El backtesting se ejecuta realmente MENSUAL como declara el manual, o solo trimestralmente? ¿Existen logs o reportes mensuales que lo demuestren?
- [ ] ¿Qué acciones se toman cuando el backtesting falla (excedencias fuera del intervalo de Kupiec o agrupamiento en Christoffersen)? ¿Existe un protocolo documentado de escalamiento?
- [ ] ¿Se verifica que los supuestos de Kupiec (independencia de excedencias, estacionariedad) se mantienen en esta cartera? ¿Hay análisis de autocorrelación o cambios de régimen?
- [ ] ¿Se aplica el test de López (independencia condicional) además de Christoffersen, o se descartó deliberadamente? Si se descartó, ¿cuál es la justificación?
- [ ] ¿Cómo se integran los resultados del backtesting en las decisiones de gestión de riesgos? ¿Llegan a algún comité de riesgos o solo se archivan?
- [ ] ¿Se monitorea la calidad de los datos de entrada (precios, retornos)? ¿Existe un procedimiento documentado de validación de datos antes del cálculo de VaR?

**Recomendación.** Acciones inmediatas para alcanzar nivel 4: (1) Proporcionar el manual operativo completo con descripción de procesos, sistemas, validaciones y responsables; (2) Recuperar y validar el anexo C (estudio de sensibilidad) o reproducir el análisis de forma independiente para verificar la elección de 500 días; (3) Expandir el informe de seguimiento para incluir: (a) desglose mensual de backtesting, (b) análisis de calidad de datos, (c) verificación de supuestos, (d) decisiones y acciones tomadas en base a resultados, (e) trazabilidad de escalamientos; (4) Documentar explícitamente por qué se eligió Kupiec+Christoffersen sobre otras pruebas (ej. López, binomial) y qué supuestos se verifican; (5) Crear un protocolo de escalamiento que vincule resultados de backtesting a decisiones de comités de riesgo, con evidencia de ejecución. Plazo recomendado: 30 días para manual operativo y protocolo; 60 días para validación de anexo C y expansión de seguimiento.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a2419e97aef9`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Evaluación de la existencia, suficiencia y claridad de la documentación de seguimiento y monitoreo del modelo VaR FRTB, incluyendo backtesting y calidad de datos. Esta actividad es crítica porque la documentación de seguimiento es el mecanismo de control continuo que detecta degradación del modelo en producción.

**Hallazgo.**

La documentación demuestra EXISTENCIA de elementos clave pero con BRECHAS DE INTEGRACIÓN y AUSENCIAS que impiden una validación completa. El manual metodológico [manual_VaR_FRTB.md] declara que se ejecutan pruebas de Kupiec y Christoffersen mensualmente (§3), y el informe de backtesting [backtesting_VaR_2026Q1.md] proporciona resultados concretos para Q1 2026: 3 excedencias observadas vs 0.62 esperadas, Kupiec LR=3.81 (p-valor 0.051), conclusión de no rechazo al 5%. Esto demuestra que el backtesting se ejecuta y que se aplica el test de Kupiec. Sin embargo, existen brechas críticas: (1) El informe de seguimiento NO contiene análisis de las excedencias individuales (qué posiciones, qué factores de riesgo, qué eventos de mercado explican cada una de las 3 excedencias), que según la literatura estándar es "evidencia de validación tan relevante como el estadístico agregado". (2) NO hay evidencia de monitoreo de calidad de datos (completitud, outliers, reconciliación con fuentes externas, tratamiento de días con mercados cerrados). El manual menciona que el backtesting se ejecuta mensualmente pero no documenta el proceso operativo: quién lo ejecuta, cuándo, qué criterios de escalación se aplican si se rechaza Kupiec, cómo se comunican los resultados. (3) La justificación de la ventana de 500 días se remite al "estudio de sensibilidad del anexo C" pero ese anexo no está en el contexto disponible, por lo que no puede verificarse que la elección esté realmente justificada frente a alternativas. (4) El manual declara que se complementa con Expected Shortfall pero no hay evidencia de que ese complemento se ejecute o se reporte. Para alcanzar puntaje 4 se requeriría: informe de seguimiento que documente cada excedencia, proceso operativo detallado, evidencia de monitoreo de calidad de datos, y acceso a la justificación de parámetros clave.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Anexo C no incluido en la cobertura documental»
> - «No hay mención de Expected Shortfall en el informe de seguimiento»

**Preguntas al modelador.**

- [ ] ¿Cuál es el contenido del Anexo C (estudio de sensibilidad de ventanas)? ¿Se evaluaron ventanas de 250, 375, 500, 750 días? ¿Cuál fue el criterio de selección final?
- [ ] ¿Existe un proceso operativo documentado para la ejecución mensual del backtesting? ¿Quién lo ejecuta, en qué fecha, con qué datos, y cuál es el flujo de escalación si Kupiec se rechaza?
- [ ] ¿Se documentan y analizan las 3 excedencias observadas en Q1 2026? ¿Qué posiciones, factores de riesgo y eventos de mercado las explican? ¿Se validó que fueron eventos extremos no capturados por el modelo o errores de cálculo?
- [ ] ¿Existe un proceso de monitoreo de calidad de datos? ¿Se verifica completitud, outliers, reconciliación con fuentes externas, tratamiento de días con mercados cerrados o datos incompletos?
- [ ] ¿Se ejecuta y reporta el Expected Shortfall mensualmente? ¿Cómo se integra en la gestión de riesgos y en los reportes al Comité?
- [ ] ¿Se ejecuta la prueba de Christoffersen (independencia de excedencias) en todos los períodos o solo cuando se detecta agrupamiento? ¿Cuál es el criterio de rechazo?
- [ ] ¿Se ha evaluado la potencia de las pruebas de Kupiec y Christoffersen con el tamaño muestral disponible (62 días)? ¿Cuál es la probabilidad de detectar un modelo mal calibrado con esta muestra?

**Recomendación.** 1. Incluir en el informe de seguimiento mensual un análisis narrativo de cada excedencia: fecha, posición, factor de riesgo, evento de mercado, y explicación de por qué el modelo no la capturó. 2. Documentar el proceso operativo de backtesting: responsables, calendario, criterios de escalación, flujo de comunicación. 3. Crear un anexo de monitoreo de calidad de datos que reporte mensualmente: completitud de datos, número de outliers detectados y tratados, reconciliación con fuentes externas, días excluidos y justificación. 4. Recuperar y anexar el estudio de sensibilidad de ventanas (Anexo C) o, si no existe, ejecutarlo y documentarlo. 5. Reportar mensualmente el Expected Shortfall junto con Kupiec y Christoffersen, con análisis de su evolución. 6. Documentar explícitamente la potencia de las pruebas estadísticas con el tamaño muestral utilizado y sus implicaciones para la interpretación de resultados.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `c21442027f25`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Calidad de datos  ·  score 2.83

#### 🔴 [1/5] [Motor de la entidad] Rango de Tasa de Interés (0-100)

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Rango de Tasa de Interés (0-100)

**Hallazgo.**

Valores negativos y >100 en la serie histórica. 14.70 % de incumplimiento medido por el motor. La tabla no declara el umbral, así que no consta si la tolerancia era cero: se aplica el tope general de 4. Añade una columna «Umbral» para afinarlo.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar que no exista suficiencia de controles de calidad de datos (integridad)

*Control: El modelo deberá contar con controles de calidad de datos de primera linea sobre los resultados calculados (outliers, missing, duplicados, entre otros)*

**Qué evalúa.** Verificación de la suficiencia de controles de calidad de datos de primera línea sobre los resultados calculados del modelo VaR FRTB (missing, duplicados, outliers, integridad referencial). Este control es crítico porque datos defectuosos invalidan cualquier estimación de riesgo, independientemente de la sofisticación metodológica.

**Hallazgo.**

La evaluación revela brechas CRÍTICAS en la implementación de controles de calidad de datos. Aunque existe documentación que menciona el tema (perfil de datos y matriz de motores de calidad), la evidencia demuestra que: (1) NO EXISTE un script de control de datos (_replica_virf.py o equivalente) que automatice y documente las pruebas de calidad sobre los resultados calculados del VaR; (2) los controles documentados se aplican a datos MAESTROS (cuentas, clientes, tasas) pero NO a las SERIES DE PRECIOS que alimentan el cálculo del VaR histórico; (3) la matriz de motores de calidad reporta TRES FALLOS CRÍTICOS sin que se documente su impacto en el modelo VaR ni las acciones correctivas aplicadas; (4) el tratamiento de missing values en la serie de precios (imputación por último valor conocido) se menciona sin justificación metodológica ni validación de su impacto en la estimación del VaR. El manual metodológico NO MENCIONA NINGÚN CONTROL de calidad de datos sobre los inputs o outputs del modelo. Para alcanzar nivel 3 se requiere: (a) script automatizado que ejecute pruebas de missing (MCAR/MAR/MNAR), duplicados, outliers (con criterio explícito, no solo Z-score), e integridad referencial sobre la serie de precios diaria; (b) documentación de la justificación del método de imputación y su validación; (c) reporte periódico de incidencias de calidad con trazabilidad de acciones correctivas; (d) evidencia de que los fallos reportados en la matriz (integridad referencial 1.8%, outliers en saldo, rango de tasa) han sido evaluados en su impacto sobre el VaR o explícitamente excluidos del alcance del modelo.

**Evidencia citada.**

> perfil_datos_VaR.md → "Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha."
>
> motores_calidad_2026Q1.xlsx → "Integridad referencial Cuenta→Cliente,1.8,FALLA,2.168 cuentas sin cliente maestro."
>
> motores_calidad_2026Q1.xlsx → "Rango de Tasa de Interés (0-100),14.7,FALLA,Valores negativos y >100 en la serie histórica."
>
> motores_calidad_2026Q1.xlsx → "Outliers en Saldo,,FALLA,Se detectan colas anómalas; no se cuantificó."
>
> manual_VaR_FRTB.md → "## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento." [Nota: el manual NO contiene sección de controles de calidad de datos sobre inputs o outputs]
>
> No se encontró evidencia de un script _replica_virf.py o equivalente en el contexto disponible.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (»
> - «Integridad referencial Cuenta→Cliente,1.8,FALLA,2.168 cuentas sin cliente maestr»
> - «## 4. Limitaciones\nNo captura riesgo de liquidez de mercado. Se complementa con»
> - «## 2. Metodología\nVaR histórico con ventana de 500 días, nivel de confianza 99%»

**Preguntas al modelador.**

- [ ] ¿Existe un script automatizado (_replica_virf.py o equivalente) que ejecute controles de calidad de datos sobre la serie de precios Bloomberg diaria? Si existe, ¿cuál es su nombre y dónde se almacenan sus resultados?
- [ ] ¿Cuál es la justificación técnica para imputar valores ausentes por último valor conocido (forward fill) en una serie de retornos para VaR histórico? ¿Se ha validado el impacto de esta imputación en la estimación del VaR y en los resultados del backtesting de Kupiec?
- [ ] ¿Cómo se clasifican los 0.4% de valores ausentes en la serie de precios: MCAR (Missing Completely At Random), MAR (Missing At Random) o MNAR (Missing Not At Random)? ¿Hay análisis de si los faltantes coinciden con cierres de mercado, feriados o eventos de liquidez?
- [ ] ¿Los tres fallos reportados en la matriz de motores de calidad (integridad referencial 1.8%, rango de tasa 14.7%, outliers en saldo sin cuantificar) aplican a la cartera de negociación que alimenta el VaR FRTB? Si aplican, ¿cuál es el impacto cuantificado en la estimación del VaR?
- [ ] ¿Existe un reporte periódico (diario, semanal o mensual) de incidencias de calidad de datos sobre los inputs del modelo VaR? ¿Quién lo revisa y qué acciones correctivas se documentan?
- [ ] ¿Se ejecutan pruebas de outliers sobre los retornos calculados (no solo sobre precios)? ¿Qué criterio se usa para identificar outliers: Z-score, IQR, percentiles, o análisis de colas? ¿Se documentan los outliers detectados y se valida si son errores de datos o movimientos de mercado legítimos?
- [ ] ¿Se verifica la integridad referencial entre la serie de precios Bloomberg y el maestro de instrumentos (ISIN, ticker, divisa)? ¿Hay un control que detecte si un instrumento desaparece del maestro pero sigue en la cartera histórica?

**Recomendación.** Implementar un script de control de calidad de datos (_replica_virf.py o equivalente) que ejecute automáticamente, antes de cada cálculo de VaR: (1) detección de missing values con clasificación MCAR/MAR/MNAR y análisis de patrones; (2) detección de duplicados por fecha-instrumento; (3) detección de outliers en retornos con criterio explícito (ej. percentiles 0.1% y 99.9%, o análisis de colas con test de Anderson-Darling); (4) validación de integridad referencial precio→maestro de instrumentos; (5) reporte de incidencias con trazabilidad de acciones correctivas. Documentar en el manual metodológico (sección nueva: «4. Controles de Calidad de Datos») la justificación del método de imputación (forward fill), su validación, y los criterios de exclusión de observaciones defectuosas. Evaluar el impacto de los fallos reportados en la matriz de motores de calidad sobre la cartera VaR y documentar si aplican o no al modelo. Ejecutar un backtesting retrospectivo (últimos 12 meses) para validar si la imputación por forward fill ha afectado la cobertura del modelo (test de Kupiec).

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `b2e9d655a7b1`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la actualización de los inputs

*Control: Revisión de la integridad y consistencias de los inputs*

**Qué evalúa.** Verificación de la integridad, consistencia y actualización periódica de los inputs de datos que alimentan el modelo VaR FRTB. Esta actividad es crítica porque datos defectuosos invalidan cualquier estimación de riesgo, independientemente de la sofisticación metodológica.

**Hallazgo.**

La evaluación revela brechas CRÍTICAS en la implementación de controles de calidad de datos. Aunque existe documentación de un perfil de datos y un reporte de motores de calidad, la evidencia muestra: (1) AUSENCIA TOTAL de un script de validación (_replica_virf.py o equivalente) que automatice y documente los controles de integridad; (2) TRATAMIENTO NO JUSTIFICADO de valores faltantes: el perfil declara 0.4% de missing imputados por «último valor conocido» sin documentar si son MCAR, MAR o MNAR, ni justificar por qué esta imputación es válida para un modelo de VaR histórico donde la dependencia temporal es crítica; (3) FALLAS DOCUMENTADAS NO RESUELTAS en el reporte de motores: 2.168 cuentas sin cliente maestro (1.8% de integridad referencial fallida), 14.7% de tasas fuera de rango [0-100], y outliers en saldo detectados pero no cuantificados; (4) AUSENCIA DE EVIDENCIA sobre la actualización periódica de inputs: no hay logs de ejecución, calendarios de refresh, ni SLAs de calidad de datos; (5) DESCONEXIÓN entre el reporte de calidad (que marca 6 criterios, 3 de ellos FALLA) y el manual VaR (que no menciona estos hallazgos ni sus implicaciones para la validez del modelo). Para alcanzar nivel 3 se requiere: un script de validación ejecutado y documentado, justificación explícita del tratamiento de faltantes con análisis de mecanismo, resolución o mitigación de las fallas de integridad referencial y rango, cuantificación de outliers con criterio de exclusión/ajuste, y un calendario de actualización con evidencia de cumplimiento. La cobertura documental es parcial en este ámbito: no se proporcionó acceso a logs de ejecución, reportes de incidencias de datos, ni scripts de validación, lo que introduce incertidumbre sobre si existen pero no fueron incluidos en el contexto.

**Evidencia citada.**

> perfil_datos_VaR.md → "Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes, imputados por último valor conocido. Sin duplicados de fecha."
>
> motores_calidad_2026Q1.xlsx → "Integridad referencial Cuenta→Cliente,1.8,FALLA,2.168 cuentas sin cliente maestro."
>
> motores_calidad_2026Q1.xlsx → "Rango de Tasa de Interés (0-100),14.7,FALLA,Valores negativos y >100 en la serie histórica."
>
> motores_calidad_2026Q1.xlsx → "Outliers en Saldo,,FALLA,Se detectan colas anómalas; no se cuantificó."
>
> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día."
>
> No se encontró evidencia en el contexto disponible de: script _replica_virf.py, logs de ejecución de validaciones, calendario de actualización de inputs, análisis del mecanismo de faltantes (MCAR/MAR/MNAR), criterios de exclusión o ajuste de outliers, o documentación de resolución de las fallas reportadas.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «No contiene mención alguna de fallas de integridad referencial, ni de su impacto»
> - «VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. »
> - «No contiene criterios de detección, cuantificación o tratamiento de outliers.»

**Preguntas al modelador.**

- [ ] ¿Existe un script de validación de datos (_replica_virf.py o equivalente) que se ejecute periódicamente? Si existe, ¿cuál es su frecuencia de ejecución y cuáles son los resultados de las últimas 3 corridas?
- [ ] ¿Se ha realizado un análisis del mecanismo de faltantes (MCAR, MAR, MNAR) para justificar la imputación por último valor conocido? ¿Qué impacto tiene esta imputación en la distribución de retornos y en la estimación de VaR?
- [ ] ¿Cuál es el estado de resolución de las 2.168 cuentas sin cliente maestro reportadas en el reporte de calidad? ¿Se excluyen del cálculo de VaR, se asignan a un cliente por defecto, o se mantienen con riesgo de trazabilidad?
- [ ] ¿Cuál es el criterio para detectar y tratar outliers en saldos? ¿Se utiliza Z-score, IQR, o algún otro método? ¿Cuál es el umbral y qué acción se toma (exclusión, ajuste, o mantenimiento)?
- [ ] ¿Existe un calendario de actualización de inputs (precios Bloomberg, saldos, maestros de clientes) con SLAs documentados? ¿Quién verifica que se cumplan y con qué frecuencia?
- [ ] ¿Se han documentado los resultados de las validaciones de integridad referencial y rango en los últimos 3 meses? ¿Hay un registro de incidencias y su resolución?
- [ ] ¿El modelo VaR se recalcula con los datos validados, o se ejecuta sobre los datos brutos reportados en el perfil? ¿Existe un control que asegure que solo datos que pasan los controles de calidad alimentan el modelo?

**Recomendación.** Implementar inmediatamente un script de validación automatizado (_replica_virf.py) que ejecute controles de: (1) completitud (documentar mecanismo de faltantes y justificar imputación), (2) unicidad (duplicados por fecha/instrumento), (3) integridad referencial (cuentas sin cliente maestro), (4) rango (tasas, saldos, precios), (5) outliers (con criterio cuantificado: Z-score, IQR, o percentil). El script debe generar un reporte ejecutivo mensual que se presente al Comité de Riesgos. Resolver las fallas documentadas: (a) investigar y reasignar las 2.168 cuentas huérfanas o excluirlas explícitamente del cálculo; (b) cuantificar y establecer criterio de tratamiento para outliers en saldo; (c) revisar la validez de la imputación por forward fill mediante análisis de sensibilidad del VaR. Integrar los resultados de validación en el manual VaR v1.1, incluyendo limitaciones conocidas y su impacto en la confiabilidad del modelo. Establecer un SLA de actualización de datos (ej: T+1) con evidencia de cumplimiento auditada mensualmente.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `b9c1f9e55205`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] [Motor de la entidad] Integridad referencial Cuenta→Cliente

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Integridad referencial Cuenta→Cliente

**Hallazgo.**

2.168 cuentas sin cliente maestro. 1.80 % de incumplimiento medido por el motor. La tabla no declara el umbral, así que no consta si la tolerancia era cero: se aplica el tope general de 4. Añade una columna «Umbral» para afinarlo.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [4/5] [Motor de la entidad] Completitud de FechaVencimiento

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Completitud de FechaVencimiento

**Hallazgo.**

388 nulos; dentro del umbral interno del 0,5 %. 0.32 % de incumplimiento medido por el motor.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] [Motor de la entidad] Unicidad Cliente por Cuenta

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Unicidad Cliente por Cuenta

**Hallazgo.**

Sin duplicados en 120.450 registros. 0.00 % de incumplimiento medido por el motor.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_01 — Valida que el manual describa origen, universo, variables, transformaciones y contrles; y que el…

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** EVALUACIÓN NO REALIZADA — fallo técnico

**Hallazgo.**

Este control NO pudo evaluarse. Motivo: No se pudo interpretar la respuesta del modelo (JSON inválido). La evidencia SÍ estaba disponible: es un fallo técnico, no una falta de documentación. Re-ejecutar. No se asignó puntaje para no contaminar el dictamen con un valor inventado.

**Evidencia citada.**

_Sin evidencia citada._

<sub>prompt `47d8c87dc32d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_02 — Valida la unicidad Cliente por Cuenta en la base usada por el proceso

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad Cliente por Cuenta en la base usada por el proceso

**Hallazgo.**

La evidencia presentada contiene inconsistencias críticas que impiden una validación concluyente. El manual metodológico (secciones 2-4) aparece duplicado múltiples veces sin variación, lo que sugiere un error en la captura de datos. El código Python implementa correctamente la ventana de 500 días y nivel 99% conforme al manual §2, pero la evidencia de backtesting (Kupiec, Christoffersen) referenciada en §3 no se proporciona: solo se menciona que 'resultados del último trimestre en el informe de seguimiento' sin adjuntar ese informe. No es posible validar si las pruebas de cobertura incondicional e independencia cumplen los intervalos de aceptación regulatorios (SR 11-7, Basilea III). Adicionalmente, el control solicitado (unicidad Cliente×Cuenta) no aparece en ninguna evidencia proporcionada.

5 hallazgo(s) del control automático (2 critica, 2 moderada, 1 baja), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Proporcionar el informe de seguimiento trimestral completo con: (i) número de excedencias observadas vs. esperadas, (ii) p-value del test de Kupiec, (iii) estadístico y p-value del test de Christoffersen, (iv) fecha de cálculo y período de evaluación. Proporcionar: (i) esquema de datos de la cartera (tabla/estructura con campos Cliente, Cuenta, Instrumento, etc.), (ii) script/query de validación de unicidad ejecutado, (iii) resultado automatizado (ej: 'SELECT COUNT(DISTINCT Cliente, Cuenta) vs. COUNT(*) FROM cartera'), (iv) fecha de ejecución. Reenviar evidencia con control de calidad: verificar que cada documento se adjunte una sola vez y completamente (incluyendo anexos A, B, C referenciados). Adjuntar anexo C con: (i) tabla de sensibilidad (tamaño ventana vs. número de excedencias), (ii) intervalos de Kupiec calculados para cada ventana, (iii) conclusión sobre selección de 500 días. Enriquecer función con: (i) assert len(retornos)>=500, (ii) manejo de valores faltantes, (iii) logging de timestamp y parámetros, (iv) documentación de supuestos (ej: retornos en escala decimal, no porcentaje).

<sub>prompt `7caf428315d2`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_03 — Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura

**Hallazgo.**

La evidencia presentada contiene inconsistencias críticas que impiden una validación concluyente. El manual metodológico (secciones 2-4) describe un modelo VaR histórico FRTB con ventana de 500 días, nivel 99%, horizonte 1 día, y backtesting mediante Kupiec y Christoffersen. El código implementa correctamente la fórmula np.percentile(retornos[-500:], 1%) con signo negativo, alineado con la especificación. Sin embargo, existe una desconexión fundamental: el control a evaluar solicita validar 'unicidad de FechaVencimiento por combinación Cuenta+FechaApertura', que es un control de integridad de datos de crédito (LaR/IFRS 9), mientras que toda la evidencia proporcionada corresponde a un modelo de riesgo de mercado (VaR FRTB). Esta incongruencia sugiere un error en la asignación de evidencia o en la definición del control.

4 hallazgo(s) del control automático (2 critica, 2 moderada), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Proporcionar evidencia correcta: (1) Manual metodológico del modelo de riesgo de crédito que incluya reglas de unicidad de FechaVencimiento; (2) Script/código que implemente la validación de combinación Cuenta+FechaApertura; (3) Resultados de pruebas de integridad de datos; (4) Logs de ejecución del control. Verificar la integridad del archivo fuente de evidencia. Reenviar documentación y código sin duplicaciones. Confirmar que la evidencia proporcionada es la versión vigente y completa del control a auditar. Adjuntar informe de seguimiento del último trimestre con: (1) Matriz de excedencias diarias vs. límite VaR; (2) Estadístico de Kupiec (p-value) y conclusión; (3) Estadístico de Christoffersen (independencia) y conclusión; (4) Fechas de ejecución y responsable. Proporcionar anexo C completo con: (1) Rango de ventanas evaluadas; (2) Número de excedencias por ventana; (3) Intervalos de confianza de Kupiec para cada ventana; (4) Conclusión técnica que justifique 500 días como óptimo.

<sub>prompt `9267e2f9dbb5`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_04 — Valida la unicidad de Tasa de Interes por Cuenta

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad de Tasa de Interes por Cuenta

**Hallazgo.**

INCONSISTENCIA CRÍTICA DETECTADA: El control solicitado es 'Valida la unicidad de Tasa de Interes por Cuenta', pero la evidencia proporcionada (manual y código) corresponde exclusivamente a un modelo VaR histórico FRTB sin relación alguna con tasas de interés ni validación de unicidad de cuentas. No existe documentación, especificación técnica, código de validación, ni criterios de aceptación para el control de unicidad de tasa de interés. La evidencia entregada es material de un modelo de riesgo de mercado completamente desvinculado del control a evaluar.

2 hallazgo(s) del control automático (1 critica, 1 moderada), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Proporcionar evidencia correcta: (a) Manual/especificación del control de unicidad de tasa por cuenta; (b) Script/código que implemente la validación; (c) Resultados de ejecución del control; (d) Matriz de trazabilidad requisito-código; (e) Evidencia de backtesting o validación del control. Reenviar evidencia limpia y sin duplicaciones. Verificar integridad de archivos fuente y proceso de extracción de datos.

<sub>prompt `ed378fa3dbad`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] [Motor de la entidad] Outliers en Saldo

> No se pudo evaluar: El motor reporta incumplimiento pero no cuantifica su magnitud: no se asigna puntaje para no inventar la severidad.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Outliers en Saldo

**Hallazgo.**

Se detectan colas anómalas; no se cuantificó. El motor reporta incumplimiento pero no cuantifica su magnitud: no se asigna puntaje para no inventar la severidad.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] [Motor de la entidad] Tipos de dato del maestro

> No se pudo evaluar: 0.00 % de incumplimiento medido por el motor. El motor concluye INCUMPLIMIENTO pese a medir 0 %: la tasa no explica el fallo, así que no se asigna puntaje en vez de contradecir al motor.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Tipos de dato del maestro

**Hallazgo.**

Marcado como falla por criterio interno pese a 0 % medido. 0.00 % de incumplimiento medido por el motor. El motor concluye INCUMPLIMIENTO pese a medir 0 %: la tasa no explica el fallo, así que no se asigna puntaje en vez de contradecir al motor.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

### Metodología  ·  score 2.83

#### 🟠 [2/5] Validar supuestos y consideración más importantes de la técnica utilizada

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Validación de la justificación metodológica del VaR histórico FRTB: verificar que la elección del modelo, sus supuestos y parámetros clave estén fundamentados en evidencia empírica y que los contrastes de validación (Kupiec, Christoffersen) se hayan ejecutado y documentado completamente.

**Hallazgo.**

La documentación demuestra EXISTENCIA de elementos metodológicos clave pero con BRECHAS CRÍTICAS que impiden considerar la metodología como plenamente justificada y validada. El manual declara el uso de VaR histórico con ventana de 500 días y nivel 99%, y afirma que esta elección se justifica en un estudio de sensibilidad (anexo C), pero ese anexo NO está disponible en el contexto para verificación. El backtesting reporta resultados de Kupiec (LR=3.81, p=0.051) y Christoffersen (sin agrupamiento), pero: (1) no se proporcionan los datos brutos de excedencias ni su análisis individual, que la literatura estándar considera evidencia tan relevante como el estadístico agregado; (2) no se declara la baja potencia estadística de Kupiec con 62 observaciones (esperadas 0.62 excedencias, observadas 3), lo que es crítico para la interpretación del p-valor marginal de 0.051; (3) no hay análisis de López (independencia temporal de excedencias más allá de Christoffersen) ni pruebas de estrés complementarias; (4) la metodología VaR histórico asume implícitamente estacionariedad y no captura cambios de régimen, pero no se verifica este supuesto ni se justifica por qué se descartó un enfoque paramétrico o híbrido; (5) el manual menciona que el modelo "no captura riesgo de liquidez" pero no cuantifica el sesgo que esto introduce ni establece controles compensatorios. El resultado de Kupiec está en la zona verde de Basilea (no rechazo al 5%), pero con una muestra tan pequeña y un p-valor tan cercano al umbral, la conclusión de adecuación es frágil y requiere documentación explícita de estas limitaciones. Para alcanzar cumplimiento pleno (4-5), se requiere: (i) acceso y verificación del anexo C con el análisis de sensibilidad; (ii) documentación de cada excedencia individual con explicación de su origen; (iii) declaración explícita de la baja potencia de Kupiec y su implicación para la confiabilidad del resultado; (iv) justificación de por qué se descartaron modelos alternativos; (v) pruebas de supuestos (estacionariedad, independencia de retornos).

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "Limitaciones: No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Limitaciones: No captura riesgo de liquidez de mercado. Se complementa con el Ex»
> - «Anexo C no incluido en la cobertura documental»
> - «La prueba tiene poca potencia con muestras cortas: con 250 observaciones y un ni»

**Preguntas al modelador.**

- [ ] ¿Puede proporcionarse el anexo C (estudio de sensibilidad) que justifica la elección de ventana de 500 días? Sin él, no puede validarse la justificación central de la metodología.
- [ ] ¿Se han realizado pruebas de estacionariedad (ADF, KPSS) sobre la serie de retornos históricos? ¿Qué resultado arrojaron?
- [ ] ¿Por qué se descartó un enfoque paramétrico (GARCH, volatilidad condicional) o un modelo de colas gruesas (t-Student, EVT) para FRTB, donde se espera capturar cambios de régimen?
- [ ] ¿Se documentan las tres excedencias observadas individualmente? ¿Qué evento de mercado las causó? ¿Eran predecibles o representan un fallo del modelo?
- [ ] ¿Se ha ejecutado la prueba de López (independencia temporal de excedencias) o algún análisis de clustering más allá de Christoffersen?
- [ ] ¿Cómo se integran VaR y Expected Shortfall en la decisión de capital regulatorio? ¿Qué ocurre si uno señala adecuación y otro no?
- [ ] ¿Se ha cuantificado el sesgo introducido por no capturar riesgo de liquidez de mercado? ¿Existe un control compensatorio (p. ej., ajuste por liquidez, pruebas de estrés)?
- [ ] ¿Se verifica que la distribución histórica de retornos sea representativa del futuro? ¿Se han detectado cambios estructurales en la serie (ej. cambios de volatilidad de largo plazo)?
- [ ] ¿Cuál es la potencia estadística de Kupiec con 62 observaciones y nivel 99%? ¿Se ha documentado explícitamente que un p-valor de 0.051 con muestra pequeña no acredita adecuación del modelo?

**Recomendación.** 1. **Crítica (bloquea aprobación)**: Proporcionar el anexo C con el análisis de sensibilidad de ventanas. Sin él, la justificación de la elección metodológica no es verificable. 2. **Crítica**: Documentar explícitamente la baja potencia de Kupiec con 62 observaciones y explicar por qué un p-valor de 0.051 (marginal) con muestra pequeña no constituye evidencia concluyente de adecuación. Considerar ampliar la ventana de backtesting o ejecutar pruebas adicionales (López, análisis de excedencias individuales). 3. **Importante**: Realizar y documentar pruebas de supuestos: estacionariedad (ADF/KPSS), normalidad de retornos, independencia. Si se rechaza alguno, justificar por qué el modelo sigue siendo válido o proponer ajustes. 4. **Importante**: Justificar explícitamente por qué se descartaron modelos alternativos (paramétrico, GARCH, EVT). Si no se evaluaron, hacerlo antes de la aprobación. 5. **Importante**: Documentar cada una de las 3 excedencias observadas: fecha, factor de riesgo, evento de mercado, si fue predecible. Esto es evidencia de validación tan relevante como el estadístico agregado. 6. **Deseable**: Cuantificar el sesgo por no capturar riesgo de liquidez y establecer controles compensatorios (ajustes, pruebas de estrés, límites adicionales). 7. **Deseable**: Clarificar la integración de VaR y ES en la decisión de capital y el protocolo de escalamiento si hay conflicto entre ambas métricas.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Feedback insuficiente (1/15 muestras mínimas) · prompt `17c2ca36993d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Existencia de buenas prácticas en el enfoque metodológico

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Evaluación de la justificación metodológica del modelo VaR histórico FRTB: verificación de que la elección del enfoque, parámetros y supuestos están documentados, validados empíricamente y alineados con estándares regulatorios. Esta es la base para confiar en que el modelo mide correctamente el riesgo de mercado.

**Hallazgo.**

La documentación demuestra EXISTENCIA de elementos metodológicos clave pero con BRECHAS CRÍTICAS en justificación y validación de supuestos. El manual describe la metodología (VaR histórico, ventana 500 días, confianza 99%, horizonte 1 día) y cita un estudio de sensibilidad en el anexo C para justificar la ventana, pero ese anexo NO está en el contexto disponible, por lo que la justificación no es verificable. El backtesting ejecutado (Kupiec LR=3.81, p-valor 0.051) está en zona verde de Basilea y Christoffersen no detecta agrupamiento, lo que es positivo; sin embargo, hay ausencias críticas: (1) NO se verifica ningún supuesto del método histórico (estacionariedad, normalidad de retornos, independencia serial), que son requisitos para que el percentil empírico sea un estimador válido del VaR; (2) NO se justifica por qué se eligió VaR histórico frente a alternativas (paramétrico, simulación de Montecarlo, GARCH), ni qué se descartó; (3) NO se reporta la prueba de López (independencia temporal de excedencias), que es estándar en backtesting riguroso junto a Kupiec y Christoffersen; (4) la muestra de backtesting es pequeña (62 días, 3 excedencias esperadas 0.62), lo que reduce la potencia estadística de las pruebas, pero esto NO se declara como limitación; (5) NO se especifica si el backtesting se realiza sobre P&L hipotético (cartera congelada) o real, lo que es crítico para aislar el error del modelo del ruido operativo. El manual declara que el modelo «no captura riesgo de liquidez» y se complementa con ES, pero no justifica por qué esa complementariedad es suficiente ni cómo se integra en la gestión de riesgos. Para alcanzar cumplimiento pleno (4-5) faltaría: (a) acceso y verificación del anexo C con el análisis de sensibilidad; (b) documentación explícita de supuestos verificados (test de estacionariedad, análisis de autocorrelación); (c) justificación de la elección metodológica frente a alternativas; (d) reporte de López además de Kupiec y Christoffersen; (e) declaración de limitaciones de potencia estadística y tamaño de muestra.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El anexo C no está incluido en el contexto de validación»

**Preguntas al modelador.**

- [ ] ¿Está disponible el anexo C del manual con el análisis de sensibilidad de ventanas? Sin él, la justificación de 500 días no es verificable.
- [ ] ¿Se han ejecutado pruebas de estacionariedad (ADF, KPSS) y autocorrelación (Ljung-Box) sobre los retornos de la cartera? ¿Cuáles fueron los resultados?
- [ ] ¿Por qué se eligió VaR histórico frente a VaR paramétrico o simulación de Montecarlo? ¿Qué alternativas se evaluaron y por qué se descartaron?
- [ ] ¿Se ejecuta la prueba de López (independencia temporal de excedencias) además de Kupiec y Christoffersen? Si no, ¿por qué se omite?
- [ ] ¿El backtesting se realiza sobre P&L hipotético (cartera congelada) o real (con operaciones intradía)? ¿Se reportan ambos por separado?
- [ ] ¿Cuál es el protocolo de integración entre VaR y Expected Shortfall en la gestión de riesgos? ¿Cómo se usan conjuntamente para tomar decisiones?
- [ ] ¿Se ha evaluado la potencia estadística de las pruebas de Kupiec y Christoffersen con una muestra de 62 días? ¿Cuál es el tamaño mínimo de muestra recomendado para esta cartera?
- [ ] ¿Se verifica periódicamente que la ventana de 500 días sigue siendo óptima, o se fijó una sola vez? ¿Hay un protocolo de revisión?
- [ ] ¿Se reportan los resultados de backtesting a un comité de riesgos y se toman acciones correctivas si se detectan excedencias? ¿Hay trazabilidad de decisiones?

**Recomendación.** 1. **Inmediato**: Proporcionar el anexo C con el análisis de sensibilidad de ventanas para verificar la justificación de 500 días. Si no existe, documentar formalmente el análisis y los criterios de selección.

2. **Corto plazo**: Ejecutar y documentar pruebas de supuestos (estacionariedad ADF/KPSS, autocorrelación Ljung-Box, normalidad Shapiro-Wilk) sobre los retornos de la cartera. Incluir p-valores y conclusiones explícitas.

3. **Corto plazo**: Ampliar la documentación metodológica para justificar la elección de VaR histórico frente a alternativas. Documentar qué métodos se evaluaron, por qué se descartaron, y qué ventajas tiene el histórico para esta cartera y horizonte.

4. **Corto plazo**: Incluir la prueba de López en el backtesting mensual, junto a Kupiec y Christoffersen. Reportar los tres contrastes en el informe de seguimiento.

5. **Corto plazo**: Especificar explícitamente en el manual si el backtesting se realiza sobre P&L hipotético o real. Si es real, documentar cómo se aísla el error del modelo del ruido operativo. Considerar reportar ambos por separado.

6. **Corto plazo**: Declarar en el manual las limitaciones de potencia estadística derivadas del tamaño de muestra (62 días). Especificar el tamaño mínimo recomendado y el protocolo de revisión si la muestra es insuficiente.

7. **Mediano plazo**: Documentar el protocolo de integración entre VaR y Expected Shortfall: cómo se usan conjuntamente, qué decisiones se toman si ambas métricas se violan, y cómo se reporta al comité de riesgos.

8. **Mediano plazo**: Establecer un protocolo formal de revisión periódica de la ventana de 500 días (ej. anual) para verificar que sigue siendo óptima bajo condiciones de mercado actuales.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `6ec8df345db5`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Revisión de los lineamiento internacionales o nacionales

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Evaluación de la justificación metodológica del modelo VaR histórico FRTB, incluyendo validación empírica mediante backtesting (Kupiec, Christoffersen) y alineación con lineamientos internacionales (Basilea III). Esta es la piedra angular de la credibilidad del modelo: sin justificación sólida de por qué se eligió esta metodología y no otra, el modelo es un cálculo sin fundamento regulatorio ni técnico.

**Hallazgo.**

La documentación demuestra EXISTENCIA de elementos metodológicos clave pero con BRECHAS CRÍTICAS que impiden considerar la justificación como completa. (1) JUSTIFICACIÓN DE LA METODOLOGÍA: El manual declara que se usa VaR histórico con ventana de 500 días, pero la justificación es CIRCULAR: 'La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.' Esto describe QUÉ se observó, no POR QUÉ se eligió histórico sobre paramétrico o simulación de Montecarlo, ni por qué 500 días es óptimo (¿por qué no 400 o 600?). No hay comparación con modelos alternativos ni análisis de trade-offs. (2) VALIDACIÓN EMPÍRICA: El backtesting de Q1 2026 muestra Kupiec LR=3.81 (p=0.051), que está en la zona verde de Basilea pero MARGINAL al 5%. Con solo 62 días de datos y 3 excedencias, el intervalo de confianza es amplio; no se reporta el intervalo de Kupiec esperado (0.62±rango) ni se justifica por qué 62 días es suficiente para validar un modelo. Christoffersen se menciona pero sin resultados numéricos (estadístico, p-valor, conclusión). (3) SUPUESTOS NO VERIFICADOS: El método histórico asume que la distribución pasada es representativa del futuro (estacionariedad). No hay evidencia de contrastes de estacionariedad, cambios estructurales o análisis de colas. El manual declara que 'No captura riesgo de liquidez de mercado' pero no cuantifica el sesgo que esto introduce ni cómo se mitiga. (4) DESALINEACIÓN CON FRTB: El marco FRTB (Basilea III 2019) sustituyó VaR 99% por Expected Shortfall 97.5% como medida de capital precisamente porque VaR es insensible a la severidad de pérdidas en cola. El manual usa VaR 99% para backtesting pero no justifica por qué sigue siendo válido para validación interna si el capital regulatorio se calcula con ES. (5) AUSENCIA DE ANÁLISIS DE SENSIBILIDAD DOCUMENTADO: Se menciona 'estudio de sensibilidad del anexo C' pero el anexo no está en el contexto; sin verlo, no se puede verificar si el análisis fue riguroso o si consideró ventanas de 250-500 días de forma sistemática. Para subir a 4/5 se requiere: (a) justificación explícita de por qué histórico vs. alternativas, con análisis de backtesting comparativo; (b) resultados numéricos completos de Christoffersen (estadístico, p-valor, interpretación); (c) verificación de supuestos (estacionariedad, análisis de colas); (d) reconciliación con FRTB (por qué VaR 99% sigue siendo válido para validación interna); (e) intervalo de confianza de Kupiec y justificación del tamaño muestral.

**Evidencia citada.**

> manual_VaR_FRTB.md → 'VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.'
>
> manual_VaR_FRTB.md → 'Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento.'
>
> backtesting_VaR_2026Q1.md → 'Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias.'
>
> manual_VaR_FRTB.md → 'No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.'

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «El marco revisado sustituye el Valor en Riesgo (VaR) al 99 % como medida de capi»

**Preguntas al modelador.**

- [ ] ¿Existe análisis comparativo de backtesting entre VaR histórico y modelos alternativos (paramétrico, Montecarlo)? Si no, ¿por qué se descartaron?
- [ ] ¿Cuál es el intervalo de confianza exacto de Kupiec para 62 observaciones al 99%? ¿Se considera que 62 días es suficiente para validar, o se planifica backtesting rolling con ventana mayor?
- [ ] ¿Se ejecutó el test de Christoffersen? Proporcionar estadístico, p-valor e intervalo de confianza, no solo conclusión cualitativa.
- [ ] ¿Se verificó estacionariedad de los retornos? ¿Se realizaron contrastes ADF, KPSS o análisis de cambios estructurales (Chow)?
- [ ] ¿Por qué se usa VaR 99% para backtesting si FRTB requiere ES 97.5% para capital? ¿Se valida también ES, o VaR es solo para control interno?
- [ ] ¿Dónde está el anexo C (estudio de sensibilidad de ventanas)? ¿Cubre qué rango de ventanas y con qué criterio se seleccionó 500?
- [ ] ¿Se realiza backtesting rolling (ventana móvil) o solo trimestral? ¿Cuál es la frecuencia de revisión de la ventana?
- [ ] ¿Cómo se mitiga el riesgo de liquidez de mercado que el manual declara que no captura? ¿Existe un modelo complementario (ES, stress testing) que se integra en decisiones de riesgo?

**Recomendación.** Elevar la justificación metodológica a nivel 4/5 requiere: (1) Documentar análisis comparativo de VaR histórico vs. paramétrico y Montecarlo, con backtesting de cada alternativa y criterio de selección explícito. (2) Proporcionar el anexo C completo con gráficos de sensibilidad de ventanas (250-600 días) y justificación de por qué 500 es óptimo (no solo aceptable). (3) Reportar resultados numéricos completos de Christoffersen (estadístico, p-valor, intervalo de confianza) en cada backtesting trimestral. (4) Añadir sección de verificación de supuestos: contrastes de estacionariedad (ADF/KPSS), análisis de colas (QQ-plot, Hill estimator), y análisis de cambios estructurales. (5) Reconciliar con FRTB: aclarar si VaR 99% es solo para validación interna o si se usa también para capital; si es lo segundo, validar también ES 97.5%. (6) Definir tamaño muestral mínimo para backtesting y justificar por qué 62 días es suficiente (o planificar rolling con ventana mayor). (7) Integrar en el manual la política de revisión de la ventana (anual, trimestral, por evento) y criterios de recalibración.

<sub>cobertura documental 100.0% · RAG VaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `529a9d1ef5a9`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la existencia, ejecución y justificación del backtesting del modelo VaR FRTB bajo FRTB. Esta actividad es crítica porque el backtesting es el mecanismo de validación empírica que determina si el modelo predice correctamente la frecuencia y patrón de excedencias, y es requisito regulatorio continuo bajo Basilea III.

**Hallazgo.**

La documentación demuestra EXISTENCIA de backtesting ejecutado con pruebas estadísticas formales (Kupiec y Christoffersen), pero con BRECHAS CRÍTICAS que impiden una validación completa. (1) El manual declara que el backtesting es mensual y que los resultados del último trimestre están en el informe de seguimiento, pero el contexto disponible solo contiene datos de 2026 Q1 (3 excedencias en 62 días). No se proporciona: (a) el histórico de resultados mensuales para verificar consistencia, (b) la metodología de cálculo del VaR (paramétrica, histórica, simulación de Montecarlo), (c) la definición explícita de P&L hipotético vs real, (d) el tratamiento de días con datos incompletos o mercados cerrados. (2) El resultado Kupiec LR=3.81 (p=0.051) está en la zona gris de Basilea (entre 4.61 y 7.30 para zona amarilla), muy próximo al umbral de rechazo al 5%, lo que sugiere un modelo en el límite de aceptabilidad. Sin embargo, no hay análisis de la potencia estadística de la prueba con n=62 (muestra pequeña), ni explicación de las 3 excedencias individuales (cuándo ocurrieron, qué factores de riesgo las causaron, si fueron eventos predecibles). (3) La justificación de la ventana de 500 días se remite al anexo C (estudio de sensibilidad), pero ese anexo no está en el contexto disponible. Sin acceso a ese análisis, no puede verificarse si la elección está realmente justificada o si es una decisión heredada. (4) El manual menciona que el modelo se complementa con Expected Shortfall pero no proporciona: (a) cómo se integra el ES en la gestión de riesgos, (b) si el ES también se backtestea, (c) cómo se resuelven discrepancias entre VaR y ES. Para alcanzar cumplimiento pleno (4-5), se requiere: acceso al histórico completo de backtesting, análisis de potencia estadística, explicación de excedencias individuales, y documentación del tratamiento de datos incompletos.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea."
>
> backtesting_VaR_2026Q1.md → "Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «No se encontró en el contexto disponible una definición explícita de los umbrale»

**Preguntas al modelador.**

- [ ] ¿Está disponible el anexo C (estudio de sensibilidad) que justifica la elección de la ventana de 500 días? ¿Qué alternativas se evaluaron y por qué se descartaron?
- [ ] ¿Cuál es la metodología exacta del VaR histórico implementada? (percentil simple vs interpolado, tratamiento de outliers, ajustes por volatilidad, etc.)
- [ ] ¿Se dispone del histórico completo de backtesting mensual desde la aprobación del modelo (2026-03-15)? ¿Hay variabilidad en el número de excedencias mes a mes?
- [ ] ¿Se ha realizado un análisis de potencia estadística de la prueba de Kupiec para n=62? ¿Cuál es el tamaño de muestra mínimo recomendado para que el backtesting sea concluyente?
- [ ] ¿Se han explicado las 3 excedencias observadas? ¿En qué fechas ocurrieron, qué factores de riesgo las causaron, y eran predecibles o eventos extremos legítimos?
- [ ] ¿Se backtestea también el Expected Shortfall? ¿Cómo se integra el ES en la gestión de riesgos y en las decisiones de límites?
- [ ] ¿Se han realizado contrastes de estacionariedad, cambios de régimen, o análisis de colas en la serie de retornos históricos?
- [ ] ¿Cómo se trata el backtesting en días con datos incompletos o mercados cerrados? ¿Se excluyen esos días o se imputa algún valor?

**Recomendación.** 1. **Inmediato**: Proporcionar el anexo C (estudio de sensibilidad) y documentar explícitamente la metodología del VaR histórico (fórmula, parámetros, tratamiento de datos). 2. **Corto plazo**: Ampliar el período de backtesting a al menos 250 observaciones (aproximadamente 1 año) para aumentar la potencia estadística de las pruebas de Kupiec y Christoffersen. Reportar el histórico mensual completo desde la aprobación del modelo. 3. **Corto plazo**: Realizar un análisis de potencia estadística y declarar explícitamente los límites de la prueba con n=62. Establecer un tamaño de muestra mínimo para que el backtesting sea concluyente. 4. **Corto plazo**: Documentar el análisis de las 3 excedencias observadas: fechas, factores de riesgo causantes, y evaluación de si eran predecibles o eventos extremos legítimos. 5. **Mediano plazo**: Extender el backtesting al Expected Shortfall y documentar cómo se integra en la gestión de riesgos. 6. **Mediano plazo**: Realizar contrastes de estacionariedad, cambios de régimen, y análisis de colas en la serie histórica. Documentar cualquier limitación identificada y su impacto en la validez del modelo.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `934a49413735`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la existencia, ejecución y justificación del análisis de sensibilidad/escenarios sobre el modelo VaR FRTB, sus inputs y supuestos. Esta actividad es crítica para validar que el modelo no solo se ejecuta, sino que su comportamiento ante variaciones de parámetros clave está documentado y controlado.

**Hallazgo.**

La documentación demuestra EXISTENCIA de análisis de sensibilidad, pero con BRECHAS CRÍTICAS en su alcance, profundidad y vinculación con la gestión. El manual_VaR_FRTB.md menciona explícitamente un 'estudio de sensibilidad del anexo C' que justifica la elección de la ventana de 500 días, lo que indica que el análisis se realizó. Sin embargo, el contexto disponible NO incluye el anexo C, por lo que no es posible verificar: (1) qué parámetros fueron sometidos a sensibilidad (¿solo ventana, o también nivel de confianza, horizonte, metodología de cálculo?); (2) qué rango de variación se exploró; (3) cómo se interpretaron los resultados para tomar decisiones; (4) si el análisis se ejecutó una sola vez o se revisa periódicamente. El backtesting_VaR_2026Q1.md reporta resultados agregados (3 excedencias, Kupiec LR=3.81, p-valor 0.051) pero NO incluye análisis de sensibilidad a cambios en los inputs (volatilidad histórica, correlaciones, composición de cartera) ni escenarios de estrés alternativos. La literatura de referencia (backtesting_VaR_Kupiec_Christoffersen.pdf) subraya que 'el backtesting debe complementarse con pruebas de estrés y con análisis de las excedencias individuales', lo que no aparece documentado en el seguimiento. Para alcanzar cumplimiento pleno (4-5), se requiere: (a) acceso y revisión del anexo C con documentación de supuestos, rangos y conclusiones; (b) evidencia de análisis de sensibilidad a inputs clave (volatilidad, correlaciones, composición) ejecutado en el período de seguimiento; (c) documentación de escenarios de estrés aplicados al modelo y su impacto en el VaR; (d) evidencia de que estos análisis alimentan decisiones de gestión (comités, ajustes de límites, revisión de metodología). La ausencia de esta integración entre análisis y decisión sugiere que el análisis existe pero no está operacionalizado.

**Evidencia citada.**

> manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

**Preguntas al modelador.**

- [ ] ¿Puede proporcionarse el anexo C del manual para verificar el rango de ventanas evaluadas, los criterios de selección y la conclusión que llevó a elegir 500 días?
- [ ] ¿Se ejecutan realmente backtestings mensuales independientes, o el reporte trimestral agregado es la única salida? Si son mensuales, ¿cuáles fueron los resultados de enero y febrero de 2026?
- [ ] ¿Se ha realizado análisis de sensibilidad a nivel de confianza (ej. 97.5%, 99%, 99.9%) y horizonte (1 día vs 10 días)? ¿Cómo se justificó la elección de 99% y 1 día?
- [ ] ¿Existen pruebas de estacionariedad o análisis de cambios de régimen en los retornos históricos de la cartera? ¿Se verificó que la distribución histórica de los últimos 500 días es representativa de la distribución esperada?
- [ ] ¿Se han aplicado escenarios de estrés (históricos o hipotéticos) al modelo VaR? ¿Cuál sería el VaR bajo un escenario de volatilidad +50% o correlación +0.2?
- [ ] ¿A qué comité o proceso de decisión se reportan los resultados del análisis de sensibilidad y backtesting? ¿Qué umbral de sensibilidad o excedencia dispara una revisión de la metodología?

**Recomendación.** 1. **Inmediato**: Proporcionar el anexo C del manual con documentación completa del análisis de sensibilidad (parámetros variados, rangos, resultados, conclusiones). Verificar que la justificación de la ventana de 500 días sigue siendo válida con datos actuales. 2. **Corto plazo**: Ejecutar y documentar análisis de sensibilidad a nivel de confianza (97.5%, 99%, 99.9%) y horizonte (1, 5, 10 días) para justificar la elección actual. Incluir análisis de trade-off sesgo-varianza. 3. **Corto plazo**: Implementar pruebas de estacionariedad (ADF, KPSS) y análisis de cambios de régimen en los retornos históricos. Documentar supuestos sobre la representatividad de la ventana histórica. 4. **Mediano plazo**: Diseñar e implementar escenarios de estrés (al menos 5 históricos y 5 hipotéticos) y reportar el impacto en el VaR. Integrar estos resultados en el seguimiento trimestral. 5. **Mediano plazo**: Formalizar la cadena de reporte: backtesting mensual → análisis de sensibilidad trimestral → comité de riesgos con umbrales de decisión explícitos (ej. si Kupiec rechaza al 5%, revisar modelo en 30 días). 6. **Documentación**: Actualizar el manual para especificar frecuencia real de backtesting (mensual con reporte agregado trimestral), incluir referencia a Kupiec (1995) y Christoffersen (1998), y declarar explícitamente las limitaciones del VaR histórico (supuesto de estacionariedad, no captura colas extremas, no incluye riesgo de liquidez).

<sub>cobertura documental 100.0% · RAG VaR (5 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `56cf9349b8fa`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] Analizar el seguimeinto de la metodología

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación del seguimiento metodológico del modelo VaR Mercado FRTB: verificación de que la metodología documentada se ejecuta periódicamente, se contrasta contra estándares estadísticos formales (Kupiec, Christoffersen) y que los resultados alimentan decisiones de gestión de riesgos. Esta actividad es crítica porque un modelo no monitoreado es un modelo sin control.

**Hallazgo.**

La documentación demuestra EXISTENCIA de backtesting ejecutado con pruebas estadísticas formales, pero con BRECHAS CRÍTICAS en la integración del seguimiento a la gestión operativa y en la completitud de la validación metodológica. (1) EJECUCIÓN VERIFICADA: el informe backtesting_VaR_2026Q1.md reporta 3 excedencias sobre 62 días contra 0.62 esperadas al 99%, con Kupiec LR=3.81 (p-valor 0.051), lo que no rechaza la hipótesis nula al 5% — esto es correcto técnicamente y alineado con la zona verde de Basilea. Christoffersen se ejecutó y no detectó agrupamiento. (2) BRECHA CRÍTICA 1 — JUSTIFICACIÓN DE SUPUESTOS NO VERIFICADA: el manual_VaR_FRTB.md declara que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec» (anexo C), pero ese estudio de sensibilidad NO está en el contexto disponible. Sin acceso a los p-valores, los datos de prueba y la metodología de ese análisis, no puede verificarse si la elección de 500 días está realmente justificada o es una afirmación no documentada. (3) BRECHA CRÍTICA 2 — AUSENCIA DE PRUEBA DE INDEPENDENCIA TEMPORAL (LÓPEZ): el manual menciona Kupiec y Christoffersen, pero López (1998) es el estándar para detectar clustering de excedencias en el tiempo. Christoffersen cubre independencia, pero López es más específico para VaR. Su ausencia no es un incumplimiento formal, pero es una limitación no declarada. (4) BRECHA CRÍTICA 3 — INTEGRACIÓN A DECISIONES: no hay evidencia de que los resultados del backtesting alimenten comités, cambios de límites, o acciones correctivas. El manual §3 dice «mensual» pero no hay trazabilidad de qué ocurre cuando Kupiec está en zona amarilla o roja, ni quién revisa ni qué se decide. (5) BRECHA CRÍTICA 4 — HORIZONTE TEMPORAL INSUFICIENTE: 62 días de backtesting (Q1 2026) es muy corto para validar un modelo de 99%. Basilea III exige mínimo 1 año de datos históricos para backtesting. No hay evidencia de que se ejecute backtesting rolling o anual. (6) SUPUESTOS NO VERIFICADOS: el método histórico asume estacionariedad y que la ventana de 500 días captura la distribución relevante. No hay contraste de estacionariedad, análisis de cambios de régimen, ni validación de que 500 días sea suficiente en periodos de estrés. El manual declara limitaciones (§4: «no captura riesgo de liquidez») pero no verifica los supuestos del método elegido. Para alcanzar 4/5 se requiere: (a) acceso y verificación del estudio de sensibilidad del anexo C con p-valores y datos; (b) evidencia de backtesting anual o rolling, no solo trimestral; (c) documentación de qué ocurre cuando se detectan excedencias y quién decide; (d) análisis de supuestos (estacionariedad, suficiencia de ventana en estrés). La cobertura documental es parcial (no se proporcionó el anexo C), lo que genera incertidumbre sobre la completitud de la justificación.

**Evidencia citada.**

> manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."
>
> manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."
>
> backtesting_VaR_2026Q1.md → "Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62. Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea. Christoffersen: no se detecta agrupamiento de excedencias."
>
> manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

**Preguntas al modelador.**

- [ ] ¿Dónde está el anexo C del manual (estudio de sensibilidad de ventanas)? Sin él no puede verificarse la justificación de 500 días.
- [ ] ¿Se ejecuta backtesting mensual como declara el manual §3, o solo trimestral? Proporcionar los resultados mensuales de 2026 Q1.
- [ ] ¿Qué ocurre operativamente cuando Kupiec entra en zona amarilla o roja? ¿Quién revisa, con qué frecuencia, y qué acciones correctivas se toman?
- [ ] ¿Se ha ejecutado backtesting rolling (ventana móvil) o anual? 62 días es insuficiente para validar un modelo de 99% según Basilea III.
- [ ] ¿Se han verificado los supuestos del método histórico (estacionariedad, suficiencia de ventana en estrés, cambios de régimen)? Proporcionar contrastes estadísticos.
- [ ] ¿Por qué no se incluye la prueba de López (clustering temporal) además de Christoffersen? ¿Es una limitación deliberada o una omisión?
- [ ] ¿Cómo se integra el VaR a límites de posición, capital, o decisiones de cobertura? ¿Hay comité que revise los resultados de backtesting?
- [ ] ¿Se ha validado que 500 días captura adecuadamente la distribución en periodos de estrés o volatilidad extrema?

**Recomendación.** 1. CRÍTICA: Proporcionar y verificar el anexo C (estudio de sensibilidad). Sin él, la justificación de 500 días es una afirmación no documentada. 2. CRÍTICA: Implementar backtesting rolling anual (mínimo 252 días) además del trimestral, conforme a Basilea III. 3. CRÍTICA: Documentar el flujo de decisión: qué ocurre cuando Kupiec entra en zona amarilla/roja, quién lo revisa, con qué frecuencia, y qué acciones se toman. Incluir actas de comité o reportes de seguimiento. 4. IMPORTANTE: Añadir análisis de supuestos (estacionariedad, suficiencia de ventana en estrés) al manual. Si no se verifican, declararlos como limitaciones explícitas. 5. IMPORTANTE: Considerar incluir la prueba de López (clustering temporal) o justificar por qué Christoffersen es suficiente en este contexto. 6. RECOMENDADO: Comparar el VaR histórico con un modelo alternativo (paramétrico o Montecarlo) para validar robustez. Documentar por qué se eligió histórico.

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `b726eb309cb5`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Gobierno  ·  score 2.0

#### 🟠 [2/5] Revisar la actualización del tiering del modelo

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificar que el modelo VaR FRTB tenga tiering asignado, actualizado e integrado en el gobierno de modelos, con evidencia formal de su clasificación y justificación. Este control es crítico para asegurar que el modelo está inventariado, clasificado según riesgo/complejidad, y sujeto a revisión periódica conforme a marcos como SR 11-7.

**Hallazgo.**

La evaluación revela AUSENCIA CRÍTICA de evidencia sobre el tiering del modelo. El manual metodológico (manual_VaR_FRTB.md) describe la metodología VaR, su aprobación por Comité de Riesgos (2026-03-15) y backtesting, pero NO CONTIENE: (1) asignación explícita de tiering (ej: Tier 1, 2, 3), (2) justificación de por qué se asignó ese tier, (3) fecha de última revisión del tiering, (4) acta formal de gobierno que documente la clasificación. El manual menciona «Aprobado por el Comité de Riesgos» pero esto es aprobación de la metodología, no del tiering. El código (calcula_var.py) es una implementación técnica sin relevancia para gobierno. El contexto inter-ámbito señala que evaluaciones previas encontraron el modelo inventariado en herramientas corporativas de GRC (fuera de inputs/), pero esa evidencia NO está en el contexto disponible para esta validación. Sin acta formal firmada que documente la asignación de tiering, su justificación y fecha de vigencia, no puede verificarse cumplimiento del requisito de gobierno. La instrucción específica es clara: «Solo aceptar actas formales firmadas. Un correo NO equivale a acta.» No hay acta en el contexto. Esto es una brecha de integración entre la existencia técnica del modelo (que puede estar en GRC) y su documentación de gobierno en el expediente de validación.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."
>
> manual_VaR_FRTB.md → "## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.\nResultados del último trimestre en el informe de seguimiento."
>
> No se encontró en el contexto disponible: acta formal de asignación de tiering, justificación documentada del tier asignado, o fecha de última revisión del tiering.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 3. Backtesting\nPrueba de Kupiec (cobertura incondicional) y Christoffersen (»
> - «Solo aceptar actas formales firmadas. Un correo NO equivale a acta. Verificar ti»

**Preguntas al modelador.**

- [ ] ¿Existe acta formal firmada (no correo, no minuta informal) que documente la asignación de tiering del modelo VaR FRTB? Incluir: fecha de asignación, tier asignado (Tier 1/2/3 u otra clasificación corporativa), criterios aplicados para esa clasificación, y firma de autoridad responsable.
- [ ] ¿Cuál es la fecha de última revisión del tiering? ¿Existe un calendario de revisión periódica documentado?
- [ ] ¿El tiering está registrado en el inventario oficial de modelos de riesgo de la institución? Si está en herramienta GRC corporativa, proporcionar captura de pantalla o reporte que muestre: nombre del modelo, tiering vigente, fecha de asignación, y estado de cumplimiento.
- [ ] ¿Existe justificación documentada de por qué se asignó ese tier específico? (ej: complejidad metodológica, volumen de exposición, criticidad para capital, frecuencia de uso).

**Recomendación.** Obtener y anexar acta formal de gobierno que documente: (1) asignación de tiering del modelo VaR FRTB con fecha y firma de autoridad competente, (2) justificación explícita de la clasificación asignada según criterios corporativos, (3) fecha de última revisión y próxima revisión programada. Si el modelo está inventariado en herramienta GRC, proporcionar reporte oficial que muestre tiering vigente y trazabilidad de cambios. Esto cierra la brecha entre existencia técnica y gobierno formal del modelo.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `1b3cbfdc92aa`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] revisar que el modelo se encuentre inventariado

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificar que el modelo VaR Mercado FRTB se encuentre inventariado en el registro oficial de modelos de riesgo, con tiering asignado y justificado. Este control es crítico para el gobierno de modelos: un modelo no inventariado no tiene trazabilidad regulatoria ni responsabilidad de propiedad.

**Hallazgo.**

La evaluación revela AUSENCIA CRÍTICA de evidencia sobre inventario y tiering. El contexto disponible contiene documentación técnica del modelo (manual metodológico, código de cálculo, backtesting) pero NO incluye: (1) acta formal de inventariado en el registro corporativo de modelos, (2) asignación de tiering (Tier 1/2/3) con justificación, (3) fecha de inclusión en inventario, (4) responsable de propiedad del modelo. El historial de corridas anteriores advierte que el inventario puede residir en herramientas corporativas de GRC fuera de los inputs proporcionados, lo que genera incertidumbre sobre si el modelo está realmente inventariado o si simplemente no se incluyó la evidencia en este contexto. Sin embargo, la CARGA DE LA PRUEBA está en el modelo: la ausencia de acta formal firmada en el contexto disponible es una brecha de documentación que debe subsanarse. Para alcanzar puntaje 3 se requiere: acta formal de inventariado (no correo) con fecha, tiering asignado, y justificación del tiering basada en criterios explícitos (complejidad, criticidad, exposición). Para puntaje 4 se añadiría: evidencia de revisión periódica del tiering y trazabilidad de cambios.

**Evidencia citada.**

> manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A." (demuestra aprobación de la metodología, NO inventariado del modelo). No se encontró en el contexto disponible: acta de inventariado, asignación de tiering, o referencia a registro corporativo de modelos.

**Preguntas al modelador.**

- [ ] ¿Existe acta formal (no correo) de inventariado del modelo VaR Mercado FRTB en el registro oficial de modelos de riesgo? Proporcionar número de referencia, fecha y firmantes.
- [ ] ¿Cuál es el tiering asignado al modelo (Tier 1, 2 o 3)? ¿En qué criterios se basa esta clasificación (complejidad, criticidad, exposición, número de usuarios)?
- [ ] ¿Cuándo fue incluido el modelo en inventario y cuándo fue la última revisión del tiering? Proporcionar fechas y responsable.
- [ ] ¿Existe un documento de justificación del tiering que vincule la complejidad del modelo (VaR histórico 500 días, backtesting Kupiec+Christoffersen, FRTB) con el nivel asignado?

**Recomendación.** Solicitar al modelador: (1) Acta formal de inventariado del modelo firmada por el propietario y el Comité de Riesgos, con tiering explícitamente asignado. (2) Documento de justificación del tiering que cite los criterios aplicados. (3) Evidencia de que el modelo está registrado en la herramienta corporativa de GRC (captura de pantalla o reporte de inventario). (4) Si el modelo aún no está inventariado, establecer fecha límite para su inclusión y asignación de tiering. Nota: el historial indica que inventarios corporativos pueden no estar en inputs; si se confirma que el modelo está inventariado en GRC con tiering vigente, el puntaje puede revisarse a 4/5.

<sub>cobertura documental 100.0% · RAG VaR (6 frag.) · ajuste sesgo: Feedback insuficiente (1/15 muestras mínimas) · prompt `ab616a0abbf7`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Implementación  ·  score 2.0

#### 🟠 [2/5] Verifica las fuentes de información empleadas

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Verifica coherencia entre documentación metodológica e implementación en código, y rastrea evidencia de aprobación, pruebas UAT y controles en pipeline productivo. Es crítico para detectar code drift y asegurar que lo que se ejecuta en producción corresponde a lo autorizado.

**Hallazgo.**

La evaluación revela BRECHAS CRÍTICAS entre documentación e implementación que invalidan la comparabilidad del modelo con su especificación autorizada. El manual_VaR_FRTB.md §2 especifica explícitamente 'ventana de 500 días', pero NO EXISTE JUSTIFICACIÓN DOCUMENTADA de por qué se eligió 500 y no 250, más allá de una referencia genérica al 'anexo C' que no está disponible en el contexto. El código calcula_var.py implementa correctamente esa ventana, pero la AUSENCIA CRÍTICA es: (1) NO hay evidencia de aprobación formal de paso a producción (correos de conformidad, acta de UAT, firma de autorización); (2) NO hay documentación de pruebas iniciales de implementación (test cases, resultados de validación de datos, comparativa manual vs código); (3) NO hay trazabilidad de cambios entre versiones (el manual dice 'Control de cambios en anexo A' pero ese anexo no está en el contexto); (4) NO hay evidencia de que el backtesting mensual mencionado en §3 se ejecute realmente ni de dónde se reportan sus resultados ('informe de seguimiento' no está disponible). El manual declara limitaciones (§4) pero no hay evidencia de que esas limitaciones se comuniquen a usuarios finales ni de cómo se mitigan (se menciona ES pero no hay implementación visible). Para alcanzar nivel 3 se requiere: acta de UAT con datos reales, correo de aprobación de paso a producción, anexo A de control de cambios, y al menos un informe de backtesting ejecutado. Para nivel 4 se añadiría: justificación documentada de la elección de 500 vs 250 días (no solo referencia a anexo), y evidencia de integración en comités de decisión.

**Evidencia citada.**

manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

manual_VaR_FRTB.md → "No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «No se encontró informe de seguimiento en el contexto»

**Preguntas al modelador.**

- [ ] ¿Existe acta formal de UAT (User Acceptance Testing) que documente la validación de calcula_var.py contra datos reales antes de paso a producción? ¿Quién la firmó y cuándo?
- [ ] ¿Existe correo o resolución de aprobación de paso a producción del modelo VaR FRTB? ¿Quién autorizó y en qué fecha?
- [ ] ¿Dónde se almacenan y quién ejecuta los backtesting mensuales mencionados en §3? ¿Existe un log de ejecución o un repositorio de resultados?
- [ ] ¿Cuál es el contenido del anexo C (estudio de sensibilidad que justifica la ventana de 500 días)? ¿Por qué se descartó 250 días además de por excedencias de Kupiec? ¿Se consideraron otras ventanas?
- [ ] ¿Existe documentación de las pruebas iniciales de implementación (test cases, validación de fórmulas, comparativa manual vs código)?
- [ ] ¿Cómo se comunican las limitaciones del modelo (§4: no captura riesgo de liquidez) a los usuarios finales? ¿Existe un documento de limitaciones y mitigaciones?
- [ ] ¿Se ha implementado el Expected Shortfall mencionado como complemento? ¿Existe código y documentación para ello?
- [ ] ¿Existe un pipeline de control en producción que valide que calcula_var.py se ejecuta con los parámetros documentados (ventana 500, confianza 99%)?

**Recomendación.** Antes de cualquier uso en producción o reporte regulatorio: (1) Localizar y auditar el anexo A (control de cambios) y anexo C (justificación de ventana); (2) Obtener y revisar el informe de seguimiento más reciente con resultados de backtesting Kupiec y Christoffersen; (3) Generar acta de UAT con test cases específicos (validación de percentil, manejo de datos faltantes, comparativa con cálculo manual); (4) Obtener correo de aprobación de paso a producción firmado por propietario del riesgo; (5) Documentar el pipeline de control en producción (quién ejecuta, cuándo, con qué parámetros, dónde se almacenan resultados); (6) Crear matriz de trazabilidad manual ↔ código para cada parámetro y fórmula; (7) Documentar explícitamente cómo se mitiga la limitación de riesgo de liquidez (si ES está implementado, incluir en validación; si no, justificar por qué no es necesario para esta cartera).

<sub>cobertura documental 100.0% · RAG VaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `8d54b680ee9e`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Validación de coherencia entre documentación metodológica e implementación de código, y verificación de que los lineamientos de seguridad (aprobaciones, UAT, controles en pipeline) están documentados y ejecutados. Esta actividad es crítica porque detecta desviaciones entre lo que se dice que hace el modelo y lo que realmente hace.

**Hallazgo.**

La evaluación revela una BRECHA CRÍTICA entre documentación e implementación que invalida la comparabilidad del backtesting y cuestiona la integridad operativa del modelo. El manual metodológico (§2) especifica explícitamente una ventana de 500 días para el cálculo de VaR histórico, y el código implementado (calcula_var.py) también usa 500 días, lo que en principio es coherente. Sin embargo, el manual justifica esta elección mediante un estudio de sensibilidad (anexo C) que afirma que «ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec», pero NO se proporciona evidencia de que este anexo C exista en el contexto disponible, ni se documentan los resultados concretos de ese análisis. Más crítico aún: el manual menciona que «resultados del último trimestre» de backtesting están en un «informe de seguimiento», pero ese informe NO está disponible en el contexto. Esto significa que no es posible verificar si el backtesting (Kupiec y Christoffersen) se ejecutó realmente, con qué datos, en qué fechas, y si los resultados justifican mantener la ventana de 500 días. La documentación declara la existencia de controles (backtesting mensual, pruebas de Kupiec y Christoffersen) pero no proporciona evidencia de su ejecución real. Además, NO hay evidencia de: (1) correos de aprobación para paso a producción, (2) documentación de UAT (User Acceptance Testing), (3) controles en el pipeline productivo, (4) trazabilidad de cambios entre versiones del código, (5) logs de ejecución del script. El manual está aprobado por el Comité de Riesgos (2026-03-15) pero no hay evidencia de que el código haya sido validado o autorizado formalmente. La ausencia de estos elementos de segunda línea (aprobaciones, UAT, seguimiento de ejecución) es incompatible con un modelo en producción bajo FRTB. Para alcanzar puntaje 3 se requeriría: informe de backtesting con resultados concretos, logs de ejecución del script, correo de aprobación técnica del código, documentación de UAT con criterios de aceptación y resultados, y evidencia de que los cambios entre versiones están controlados.

**Evidencia citada.**

manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."

manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «No se encontró evidencia en el contexto disponible»
> - «No se encontró evidencia en el contexto disponible»

**Preguntas al modelador.**

- [ ] ¿Dónde está el anexo C del manual (estudio de sensibilidad)? Proporcionar el documento completo con datos, supuestos, metodología y resultados del análisis que justifica la ventana de 500 días.
- [ ] ¿Dónde está el informe de seguimiento con los resultados del backtesting del último trimestre? Proporcionar el informe con: (a) número de excedencias observadas, (b) intervalo de confianza de Kupiec, (c) resultado de la prueba de Christoffersen, (d) fecha de ejecución, (e) datos utilizados, (f) interpretación de resultados.
- [ ] ¿Existe correo de aprobación técnica del código (calcula_var.py) por parte de la primera línea o de un validador independiente? Proporcionar evidencia de que el script fue revisado y autorizado antes de paso a producción.
- [ ] ¿Se ejecutó UAT (User Acceptance Testing) del modelo? Si existe, proporcionar: (a) plan de UAT con criterios de aceptación, (b) datos de prueba utilizados, (c) resultados de ejecución, (d) acta de conformidad firmada.
- [ ] ¿Existe documentación de control de cambios (anexo A mencionado en el manual)? Proporcionar el registro de versiones con: (a) cambios realizados, (b) fechas, (c) autores, (d) aprobaciones, (e) justificación de cada cambio.
- [ ] ¿Existen logs de ejecución del script calcula_var.py en producción? Proporcionar evidencia de cuándo se ejecuta, con qué frecuencia, y si hay alertas o errores registrados.
- [ ] ¿El código ha sido sometido a revisión de seguridad (code review)? Proporcionar evidencia de revisión técnica, incluyendo: (a) revisor, (b) fecha, (c) hallazgos, (d) resolución de hallazgos.
- [ ] ¿Existe documentación de que el modelo cumple con los requisitos de FRTB (Basilea III) específicamente? El manual menciona FRTB pero no documenta cómo se mapean los requisitos regulatorios a la implementación.

**Recomendación.** ANTES de autorizar paso a producción o mantener el modelo en producción: (1) Proporcionar el anexo C completo con el análisis de sensibilidad y sus resultados; (2) Proporcionar el informe de backtesting más reciente con resultados de Kupiec y Christoffersen; (3) Obtener correo de aprobación técnica del código firmado por validador independiente; (4) Ejecutar y documentar UAT con criterios de aceptación explícitos; (5) Crear y mantener registro de control de cambios (anexo A) con trazabilidad completa; (6) Implementar logging de ejecuciones en producción con alertas de anomalías; (7) Documentar explícitamente cómo el modelo satisface cada requisito de FRTB (Basilea III). Estas acciones son obligatorias bajo SR 11-7 (Validación de Modelos) y SS3/17 (Riesgo de Mercado). Sin ellas, el modelo no puede considerarse validado ni autorizado para uso en cálculo de capital regulatorio.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a2a50f380fce`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificación de coherencia entre documentación metodológica e implementación de código, y validación de que las pruebas iniciales del proveedor fueron ejecutadas, documentadas y aprobadas antes de paso a producción. Esta actividad es crítica porque detecta desviaciones no documentadas (code drift) que invalidan la comparabilidad del backtesting y comprometen la confiabilidad del modelo en producción.

**Hallazgo.**

La evaluación revela una BRECHA CRÍTICA entre documentación e implementación que invalida la comparabilidad del backtesting y cuestiona la integridad del control de cambios. El manual_VaR_FRTB.md establece explícitamente en §2 que 'VaR histórico con ventana de 500 días', pero el análisis de sensibilidad citado en el mismo párrafo afirma que 'ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec', lo que sugiere que 500 días fue elegido como límite superior de tolerancia, no como parámetro óptimo. Sin embargo, la justificación de por qué se eligió exactamente 500 días (y no 300, 400 u otro valor dentro del rango aceptable) no está documentada en el contexto disponible. Más grave aún: no existe evidencia de que las pruebas iniciales de implementación (UAT) hayan sido ejecutadas, documentadas ni aprobadas. El manual menciona 'Resultados del último trimestre en el informe de seguimiento' pero ese informe no está en el contexto disponible, por lo que no se puede verificar si el backtesting se ejecutó realmente con datos reales o si fue solo una descripción de intención. No hay correos de conformidad de primera línea, no hay logs de ejecución de calcula_var.py, no hay registro de quién aprobó el paso a producción ni cuándo. La función var_historico() en el código carece de comentarios sobre su origen, versión o fecha de implementación, lo que impide rastrear si fue modificada post-aprobación. El control de cambios mencionado en el manual ('Control de cambios en anexo A') no está incluido en el contexto, por lo que no se puede verificar si hubo cambios no documentados entre la aprobación (2026-03-15) y la implementación actual. Esto constituye una ausencia crítica de trazabilidad que viola el principio de segunda línea independiente: no se puede validar lo que no se puede rastrear.

**Evidencia citada.**

manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día."

manual_VaR_FRTB.md → "La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."

manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «def var_historico(retornos, confianza=0.99): return -np.percentile(retornos[-500»

**Preguntas al modelador.**

- [ ] ¿Dónde está el informe de seguimiento del último trimestre que contiene los resultados del backtesting? Sin él, no se puede verificar que las pruebas de Kupiec y Christoffersen se ejecutaron realmente.
- [ ] ¿Existe el anexo A (Control de cambios) del manual? ¿Qué cambios se registran entre la aprobación del 2026-03-15 y la fecha actual? ¿Se modificó el código de calcula_var.py después de la aprobación?
- [ ] ¿Cuál es la justificación técnica específica para elegir 500 días en lugar de otro valor dentro del rango 250-500? ¿Se realizó un análisis de trade-off entre sesgo y varianza para esta ventana?
- [ ] ¿Existen logs de ejecución de calcula_var.py en producción? ¿Cuándo se ejecutó por última vez y con qué datos?
- [ ] ¿Hay correos de conformidad de primera línea (mesa de negociación o risk management) que aprueben los resultados del backtesting y autoricen el paso a producción?
- [ ] ¿Se ejecutaron pruebas de UAT (User Acceptance Testing) documentadas antes de pasar el modelo a producción? ¿Quién las ejecutó, cuándo y con qué resultado?
- [ ] ¿El código en calcula_var.py es la versión exacta que fue aprobada el 2026-03-15, o ha sido modificado? ¿Hay control de versiones (git, SVN) que lo demuestre?
- [ ] ¿Se ejecutó la prueba de López (independencia de excedencias) además de Kupiec y Christoffersen, o se descartó deliberadamente? Si se descartó, ¿cuál es la justificación?
- [ ] ¿Cómo se tratan los días con datos incompletos o mercados cerrados en el cálculo de retornos? ¿Está documentado en el manual o en el código?

**Recomendación.** Antes de cualquier uso en producción o en reportes regulatorios, se debe: (1) Localizar y revisar el informe de seguimiento del último trimestre para verificar que el backtesting se ejecutó con datos reales y que los resultados pasaron Kupiec y Christoffersen. (2) Obtener y revisar el anexo A (Control de cambios) para verificar que no hubo modificaciones no documentadas entre la aprobación y la implementación actual. (3) Documentar explícitamente la justificación técnica para la elección de 500 días (no solo que esté dentro del rango aceptable, sino por qué es óptimo). (4) Obtener correos de conformidad de primera línea que autoricen el paso a producción. (5) Ejecutar UAT documentadas con datos reales y registrar los resultados. (6) Añadir comentarios en el código (calcula_var.py) que incluyan versión, fecha de aprobación, y referencia al manual. (7) Implementar control de versiones (git) para rastrear cambios post-aprobación. Sin estas acciones, el modelo no puede considerarse validado para producción porque no hay evidencia de que las pruebas iniciales se ejecutaron ni de que fueron aprobadas.

<sub>cobertura documental 100.0% · RAG VaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `eb84082fe0fc`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Vericar existencias de correos de comunicación de resultados y su conformidad

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificación de coherencia entre documentación metodológica e implementación de código, y existencia de evidencia de comunicación de resultados y conformidad para paso a producción en modelo VaR FRTB. Esta actividad es crítica porque detecta desviaciones no documentadas (code drift) que invalidan la validación de primera línea y comprometen la integridad del modelo en producción.

**Hallazgo.**

La evaluación revela una BRECHA CRÍTICA entre documentación e implementación que invalida la comparabilidad del backtesting y cuestiona la integridad del control de cambios. El manual_VaR_FRTB.md establece explícitamente en §2 que la metodología utiliza 'ventana de 500 días', pero el código calcula_var.py implementa exactamente eso: `retornos[-500:]`. Sin embargo, el manual también afirma en §2 que 'la elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec'. Esta justificación es INCOHERENTE: si ventanas menores a 250 días fallaban el test de Kupiec, la elección de 500 días debería estar respaldada por un análisis que demuestre que 500 es superior a 250 en términos de cobertura incondicional. El anexo C no está en el contexto disponible, por lo que no se puede verificar si existe tal análisis. Segundo: NO HAY EVIDENCIA de correos de comunicación de resultados, conformidad de primera línea, aprobación para paso a producción, ni documentación de pruebas iniciales de implementación (UAT). El manual menciona 'Aprobado por el Comité de Riesgos el 2026-03-15' pero esto es una fecha futura (inconsistencia temporal) y no hay rastro de: (a) correos de validación de la implementación contra el manual, (b) logs de ejecución de backtesting con datos reales, (c) acta de conformidad de segunda línea, (d) autorización explícita para producción. Tercero: el manual declara 'Resultados del último trimestre en el informe de seguimiento' pero ese informe NO está en el contexto, por lo que no se puede verificar si el backtesting se ejecutó realmente, con qué datos, y si los resultados fueron comunicados a los órganos de gobierno. Cuarto: la actividad solicita verificar 'existencias de correos de comunicación de resultados y su conformidad' — esto es COMPLETAMENTE AUSENTE. Para alcanzar puntaje 3 se requiere: (1) anexo C con justificación cuantitativa de la ventana de 500 días vs alternativas, (2) correos de comunicación de resultados de backtesting a primera línea y comité, (3) acta de UAT con casos de prueba ejecutados, (4) correo de aprobación para producción con fecha coherente, (5) logs de ejecución del script con datos reales y fechas de ejecución.

**Evidencia citada.**

manual_VaR_FRTB.md → "VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día. La elección de la ventana se justifica en el estudio de sensibilidad del anexo C: ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec."

calcula_var.py → ```
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
```

manual_VaR_FRTB.md → "Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A."

manual_VaR_FRTB.md → "Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual. Resultados del último trimestre en el informe de seguimiento."

No se encontró evidencia en el contexto disponible de: correos de comunicación de resultados, actas de conformidad de primera línea, aprobación para paso a producción, documentación de UAT, logs de ejecución de backtesting, anexo C con justificación de la ventana, anexo A de control de cambios, informe de seguimiento del último trimestre.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «La fecha de aprobación es 2026-03-15, que es una fecha futura respecto al presen»

**Preguntas al modelador.**

- [ ] ¿Dónde está el anexo C con el estudio de sensibilidad que justifica la ventana de 500 días? ¿Contiene análisis cuantitativo de cobertura incondicional (Kupiec) para ventanas de 250, 375, 500 y 750 días?
- [ ] ¿Existe correo de comunicación de resultados de backtesting del último trimestre a primera línea y al Comité de Riesgos? ¿Cuál es la fecha de ese correo y quién lo firmó?
- [ ] ¿Existe acta de conformidad de segunda línea (validación de implementación) que certifique que calcula_var.py implementa correctamente el manual_VaR_FRTB.md? ¿Incluye casos de prueba ejecutados (UAT)?
- [ ] ¿Existe correo de aprobación para paso a producción? ¿Quién autorizó y cuándo? ¿Por qué la fecha en el manual es 2026-03-15 (futura)?
- [ ] ¿Dónde está el informe de seguimiento del último trimestre mencionado en §3? ¿Contiene resultados de Kupiec y Christoffersen con datos reales?
- [ ] ¿Existe anexo A de control de cambios? ¿Qué cambios se han hecho a calcula_var.py desde la aprobación del manual y cómo se documentaron?
- [ ] ¿Se ejecutó el script calcula_var.py con datos reales de la cartera? ¿Existen logs con fechas de ejecución, volumen de datos procesados y resultados?
- [ ] ¿Quién es el propietario del modelo y quién es responsable de la ejecución mensual del backtesting?

**Recomendación.** ANTES de autorizar paso a producción: (1) Obtener y revisar anexo C con análisis cuantitativo de ventanas alternativas (mínimo: 250, 375, 500 días) incluyendo estadísticos de Kupiec y p-valores. (2) Obtener correos de comunicación de resultados de backtesting del último trimestre con resultados de Kupiec y Christoffersen. (3) Ejecutar UAT formal: crear casos de prueba con datos sintéticos y reales, documentar resultados, obtener acta de conformidad firmada por primera línea. (4) Corregir fecha de aprobación en el manual (cambiar 2026-03-15 a fecha actual o pasada) y obtener correo de aprobación del Comité de Riesgos con fecha coherente. (5) Documentar control de cambios: crear anexo A que liste todas las versiones de calcula_var.py, cambios realizados, fechas y autorizaciones. (6) Establecer procedimiento de ejecución mensual del backtesting con responsables, fechas y entrega de resultados a órganos de gobierno. (7) Crear matriz de trazabilidad: manual §2 → calcula_var.py línea X, manual §3 → script de backtesting, manual §4 → limitaciones documentadas en reportes. Sin esta evidencia, el modelo no puede considerarse validado para producción.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `0c36c35af098`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Uso e integración a la gestión  ·  score 2.0

#### 🟠 [2/5] Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo

*Control: Revisión de los usos, impactos y usuarios del modelo*

**Qué evalúa.** Verificación de que los usos del modelo VaR en producción se alinean con el alcance original, que los usuarios están formalmente identificados, y que existe reporting de integración a la gestión. Esta actividad es crítica para asegurar que el modelo no se desvía hacia aplicaciones no validadas y que su impacto en decisiones está documentado.

**Hallazgo.**

La evidencia disponible revela brechas CRÍTICAS en la demostración de integración y uso del modelo. El acta del comité (acta_comite_riesgos_2026Q1.md) menciona que 'El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente', lo que establece un uso declarado. Sin embargo, esta mención es INSUFICIENTE para validar la actividad porque: (1) NO se proporciona evidencia de quiénes son formalmente los usuarios del modelo (¿qué áreas, qué sistemas, qué personas?); (2) NO existe documentación del alcance original del modelo que permita contrastar si los usos actuales están dentro de él; (3) NO se adjuntan reportes reales de seguimiento presentados a comités (solo se afirma que se reporta mensualmente, pero no se ve el reporte); (4) NO se verifica que los outputs en producción sean consistentes con los de desarrollo (el código muestra una ventana de 500 días, pero no hay evidencia de qué ventana se documentó como alcance original). El hallazgo inter-ámbito sobre BRECHAS CRÍTICAS en Implementación refuerza esta conclusión: si ya hay inconsistencias entre documentación e implementación en otros ámbitos, la ausencia de trazabilidad de usos agrava el riesgo. Para alcanzar nivel 3 se requiere: (a) documento que liste formalmente los usuarios y sus funciones; (b) documento de alcance original del modelo con fecha de aprobación; (c) al menos un reporte real de consumo de VaR presentado a comité; (d) verificación explícita de que los parámetros en código coinciden con los documentados. La cobertura documental es parcial (solo acta y código), lo que introduce incertidumbre sobre si existen reportes que no fueron proporcionados.

**Evidencia citada.**

> acta_comite_riesgos_2026Q1.md → "El VaR se utiliza como límite operativo diario y su consumo se reporta al Comité mensualmente."
>
> calcula_var.py → "def var_historico(retornos, confianza=0.99):\n    return -np.percentile(retornos[-500:], (1 - confianza) * 100)"

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «def var_historico(retornos, confianza=0.99):\n return -np.percentile(retornos[-5»

**Preguntas al modelador.**

- [ ] ¿Existe un documento de alcance original del modelo VaR FRTB que especifique: (a) propósito original, (b) usuarios autorizados, (c) aplicaciones permitidas, (d) parámetros de referencia (ventana, nivel de confianza, horizonte)? Si existe, ¿cuál es su fecha de aprobación y quién lo aprobó?
- [ ] ¿Quiénes son formalmente los usuarios del modelo en producción? Proporcionar lista con: nombre, área, función, fecha de autorización de acceso.
- [ ] ¿Existe un reporte real de consumo de VaR presentado al Comité de Riesgos en los últimos 3 meses? Si existe, adjuntarlo para verificar: (a) que los outputs coinciden con los del código en producción, (b) que el formato y frecuencia son consistentes con lo documentado.
- [ ] El manual metodológico §2 menciona una ventana de 500 días. ¿Cuál era la ventana especificada en el alcance original del modelo? ¿Cuándo se cambió de una a otra y quién autorizó ese cambio?
- [ ] ¿Existe un registro de cambios (change log) que documente: (a) cuándo el modelo pasó de desarrollo a producción, (b) qué validaciones se completaron antes de ese paso, (c) quién autorizó la puesta en producción?
- [ ] ¿Se ha realizado algún análisis de impacto para verificar que los outputs del modelo en producción son consistentes con los de desarrollo? Si existe, adjuntarlo.

**Recomendación.** Antes de cualquier conclusión sobre integración a la gestión, la primera línea debe proporcionar: (1) Documento de alcance original del modelo con especificación de parámetros, usuarios y aplicaciones autorizadas; (2) Registro formal de usuarios con fechas de autorización; (3) Últimos 3 reportes mensuales de consumo de VaR presentados a comité (con datos reales, no plantillas); (4) Análisis de consistencia entre outputs de desarrollo y producción, incluyendo verificación de parámetros (ventana, confianza, horizonte); (5) Change log que documente la transición a producción y las validaciones completadas. Sin esta evidencia, no es posible afirmar que los usos están dentro del alcance original ni que el modelo está integrado de forma controlada a la gestión.

<sub>cobertura documental 100.0% · RAG VaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `8a6eb0aba114`</sub>

> ✍️ _Conclusión del validador:_
>
---

## 6. Limitaciones del alcance

**Esta sección es obligatoria en el informe final.** Un dictamen que no
declara qué quedó fuera no permite distinguir «esto está bien» de «esto
no se miró».

| Concepto | Valor |
|---|---:|
| Actividades evaluadas correctamente | 28 |
| Actividades sin evidencia | 0 |
| Actividades con fallo técnico | 6 |

**Fallos técnicos** (limitación del agente, NO deficiencia del modelo validado):

- {'ambito': 'Calidad de datos', 'actividad': 'Control_01 — Valida que el manual describa origen, universo, variables, transformaciones y contrles; y que el…', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Calidad de datos', 'actividad': 'Control_02 — Valida la unicidad Cliente por Cuenta en la base usada por el proceso', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Calidad de datos', 'actividad': 'Control_03 — Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Calidad de datos', 'actividad': 'Control_04 — Valida la unicidad de Tasa de Interes por Cuenta', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Calidad de datos', 'actividad': '[Motor de la entidad] Outliers en Saldo', 'error': 'El motor reporta incumplimiento pero no cuantifica su magnitud: no se asigna puntaje para no inventar la severidad.'}
- {'ambito': 'Calidad de datos', 'actividad': '[Motor de la entidad] Tipos de dato del maestro', 'error': '0.00 % de incumplimiento medido por el motor. El motor concluye INCUMPLIMIENTO pese a medir 0 %: la tasa no explica el fallo, así que no se asigna puntaje en vez de contradecir al motor.'}

**40 cita(s) sin verificar literalmente.** Marcadas en
el detalle. Revísalas antes de firmar.

> ✍️ **Te toca:** traslada esta sección al informe final tal cual.
> Es lo que un supervisor busca primero.

---

<sub>Generado por VIRF 27.1 · claude-haiku-4-5-20251001 el 2026-09-02 13:20. Documento de trabajo interno; el entregable es el informe Word. El agente no firma: firma el validador.</sub>
