# Informe de validación — Modelo LaR (prueba)

> **BORRADOR DE TRABAJO.** Este documento lo genera el agente VIRF para
> que el validador humano lo revise, corrija y redacte el informe final.
> **No es el entregable** y no sustituye el criterio de quien firma.

| | |
|---|---|
| Modelo | Modelo LaR (prueba) |
| Tier | 1 |
| Fecha | 2026-08-31 |
| Agente | 27.1 · claude-haiku-4-5-20251001 |
| Score global | **2.26** — DEFICIENTE |
| Posición en cadena de custodia | 2 |
| Hash del informe | `3b5bf81acc4a9b1a8088785af8283639` |

> 🔴 **DICTAMEN NO CONFIABLE.** El agente no pudo evaluar una parte
> suficiente del estándar. Revisa la sección de limitaciones antes de
> usar cualquier cifra de este documento.

## 0-bis. Políticas del procedimiento aplicadas

El agente ha detectado condiciones que `PROCEDIMIENTO_VALIDACION.md`
trata como automáticas. **La decisión formal la firma el validador**
(§1 del procedimiento); esto solo declara lo que no puede pasarse por
alto.

### §6 — Hallazgos críticos automáticos

Ámbitos con score ≤ 2, marcados como críticos sin depender del juicio:

- **Documentación** — score 2.0
- **Gobierno** — score 2.0
- **Implementación** — score 1.75
- **Metodología** — score 2.0
- **Uso e integración a la gestión** — score 2.0

Un hallazgo crítico se eleva al Comité de Riesgos en su siguiente
sesión, con copia inmediata al dueño del modelo (§6).

### §4.2 — Ámbito por debajo del umbral bloqueante

Ámbitos con score < 2.5. La política **impide la aprobación aunque el
score global la supere**:

- **Documentación** — score 2.0
- **Gobierno** — score 2.0
- **Implementación** — score 1.75
- **Metodología** — score 2.0
- **Uso e integración a la gestión** — score 2.0

## 0. Cómo leer este documento

**El score no es la conclusión.** Es un resumen con pérdida de información,
útil para priorizar por dónde empezar e inútil para concluir nada. Lo que
sostiene un dictamen son las citas y el razonamiento, no el número.

### La escala, y qué exige cada nivel

| | Significa | Para darlo hace falta |
|---|---|---|
| **1** | No cumple | Ausencia total de evidencia sobre el tema |
| **2** | Brechas críticas | Se menciona, pero no se ejecuta o falta lo esencial |
| **3** | Brechas no críticas | Implementado **y ejecutado**, con huecos menores |
| **4** | Observaciones menores | Además, la elección está **justificada** |
| **5** | Cumple plenamente | Además, supuestos verificados y límites declarados |

El eje no es «cuánto se habla del tema», es **cuánto está demostrado**. El 5
es poco frecuente por diseño: exige poder defenderlo ante un supervisor con
las citas en la mano.

### Las cinco trampas que el agente busca

Cosas que aparentan cumplimiento y no lo son. Si vas a discutir un puntaje,
empieza por comprobar cuál de estas aplica:

| Trampa | Ejemplo |
|---|---|
| Documentado ≠ correcto | Manual impecable que describe una decisión equivocada |
| Existe ≠ se ejecuta | Script de backtesting que nadie corrió |
| Se menciona ≠ se justifica | «Se aplica la metodología X» sin decir por qué X |
| Se cita ≠ lo sostiene | Un paper que no dice lo que el manual afirma |
| Se calcula ≠ se usa | Métrica que no llega a ningún comité |

### Dos cosas que NO son lo mismo

- **Ausencia de evidencia** — el agente no lo encontró en lo que pudo leer.
  Es una limitación del alcance, y se declara como tal.
- **Incumplimiento** — la evidencia está y muestra una deficiencia.

Confundirlas es el error más caro al redactar: acusa al modelador de algo
que quizá sí documentó, solo que en una página que no cupo en el contexto.
Revisa siempre la **cobertura documental** antes de convertir un puntaje
bajo en un hallazgo.

### Qué te toca a ti

Los bloques **✍️** marcan dónde el documento espera tu criterio. El agente
propone; el validador dispone y firma. Ninguna cifra de aquí es definitiva
hasta que la revisas.

## 1. Resumen por ámbito

Ordenados **de peor a mejor**: por ahí se empieza.

| Ámbito | Score | Peso | Aporta al global | Lectura |
|---|---:|---:|---:|---|
| Implementación | 1.75 | 15% | 0.26 | 🟠 Cumple parcialmente — observaciones críticas |
| Documentación | 2.0 | 15% | 0.30 | 🟠 Cumple parcialmente — observaciones críticas |
| Metodología | 2.0 | 30% | 0.60 | 🟠 Cumple parcialmente — observaciones críticas |
| Gobierno | 2.0 | 12% | 0.24 | 🟠 Cumple parcialmente — observaciones críticas |
| Uso e integración a la gestión | 2.0 | 8% | 0.16 | 🟠 Cumple parcialmente — observaciones críticas |
| Calidad de datos | 3.5 | 20% | 0.70 | 🟢 Cumple con observaciones menores |

> ✍️ **Te toca:** el ámbito con peor score no siempre es el más urgente —
> mira la columna «aporta al global». Un 2 en Metodología (peso 30 %) pesa
> casi cuatro veces más que un 2 en Uso e integración (8 %).

## 2. Inconsistencias entre fuentes

**55 contradicción(es)** entre lo documentado y lo implementado.
Cada una trae las dos citas enfrentadas para que puedas verificarla en el
documento original.

### 2.1 [ALTA] El manual documenta EWMA con λ=0.94 como metodología vigente, pero el informe de seguimiento Q2 2026 identifica que EWMA subestima volatilidad y propone un piloto con GARCH(1,1). No hay evidencia de que esta propuesta haya sido formalmente aprobada, ni de cuándo entraría en vigor, ni de cómo se gestionaría la transición. Esto crea incertidumbre sobre cuál es la metodología actual en producción y viola el principio de trazabilidad: un cambio metodológico propuesto debe estar documentado, aprobado y reflejado en el manual antes de su uso.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Volatilidad estimada con EWMA: σ²_t = λ · σ²_{t-1} + (1-λ) · r²_{t-1}, λ = 0.94 (diario)

**informe_seguimiento_Q2_2026.md** dice:
> Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.2 [ALTA] El manual documenta EWMA como metodología vigente (v4.2), pero el informe de seguimiento Q2 2026 propone cambiar a GARCH(1,1) sin que exista evidencia de que esta decisión haya generado una nueva versión del manual o un documento de cambio formal. No está claro si el piloto es un cambio aprobado, en qué versión se documentará, o si v4.2 sigue siendo la versión oficial durante el piloto. Esto viola el principio de trazabilidad: un cambio metodológico debe estar documentado y versionado antes de su implementación.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Volatilidad estimada con EWMA: σ²_t = λ · σ²_{t-1} + (1-λ) · r²_{t-1}, λ = 0.94

**informe_seguimiento_Q2_2026.md** dice:
> Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.3 [ALTA] El manual afirma que los tests se aplican mensualmente, pero el informe Q2 2026 (que cubre 63 días de trading, aproximadamente 3 meses) reporta un único resultado de Kupiec con p-value 0.021. No hay evidencia de que se hayan ejecutado tests en los meses anteriores a Q2 ni de un histórico de resultados mensuales. Esto sugiere que o bien (a) los tests no se ejecutan con la frecuencia documentada, o (b) los resultados no se consolidan en un seguimiento sistemático. El riesgo es que desviaciones del modelo no se detecten a tiempo.

*Ámbito: Documentación · Actividad: Verifica la existencia , suficiencia y claridad de la documentación*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente.

**informe_seguimiento_Q2_2026.md** dice:
> Kupiec p-value | 0.021 | > 0.05 | RECHAZO H0

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.4 [ALTA] El manual metodológico declara explícitamente que se reporta curtosis como métrica de validación del supuesto de normalidad. Sin embargo, el informe de seguimiento Q2 2026 no incluye ningún valor de curtosis, ni resultado de Jarque-Bera, ni análisis de colas gruesas. El manual reconoce que la normalidad «puede subestimar colas gruesas» pero no hay evidencia de que se verifique este riesgo en la práctica. Esto es crítico porque el modelo LaR depende del supuesto de normalidad; si no se valida, no se sabe si el modelo infraestima riesgo extremo.

*Ámbito: Documentación · Actividad: Verifica la existencia , suficiencia y claridad de la documentación*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para detectar desviaciones de normalidad y colas pesadas). Implicación: No se proporcionan valores específicos de curtosis en el documento.

**informe_seguimiento_Q2_2026.md** dice:
> | Métrica | Valor | Umbral | Estado | ... | MAPE 30 días | 8.2% | ≤ 10% | OK |

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.5 [ALTA] El manual especifica backtesting mensual sobre 250 observaciones (aproximadamente 20.8 años de datos mensuales) con umbral de alerta en >5 excedencias. El informe reporta 3 excedencias en 63 días (menos de 3 meses), lo que no es comparable con el marco de 250 observaciones mensuales. Además, 3 excedencias está por debajo del umbral de 5 documentado, pero se activó revisión. Esto indica: (a) el backtesting no se ejecuta como se documenta, o (b) existe un protocolo de escalada no documentado que se activa con criterios distintos a los del manual, o (c) la ventana de observaciones se cambió sin actualizar el manual. El riesgo es que no hay trazabilidad de por qué se tomó la decisión de recalibrar, y no se puede auditar si fue correcta.

*Ámbito: Documentación · Actividad: Verificar la coherencia del manual de implementación con el manual métodolocios*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5.

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.6 [ALTA] El manual declara que ambas pruebas se aplican mensualmente, pero el informe de Q2 2026 reporta un único p-value de Kupiec (0.021) y uno de Christoffersen (0.15) sin especificar si son promedios mensuales, resultado de Q2 completo, o de una fecha específica. No hay trazabilidad de cuándo se ejecutaron, con qué ventana de datos (250 obs. requiere ~21 meses), ni cómo se reconcilian con el ciclo mensual declarado. Esto impide verificar si el backtesting se ejecuta realmente como se documenta.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente.

**informe_seguimiento_Q2_2026.md** dice:
> Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0. Christoffersen p-val: 0.15 | > 0.05 | OK.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.7 [ALTA] El manual especifica que se reporta curtosis observada para validar el supuesto de normalidad, pero ni el manual ni el informe de seguimiento proporcionan valores de curtosis ni resultado del test de Jarque-Bera. El informe solo reporta MAPE (error de predicción), que no valida normalidad. Sin curtosis, no se puede confirmar si el modelo infraestima riesgo extremo, como el propio manual advierte en limitaciones.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para detectar desviaciones de normalidad y colas pesadas). Implicación: No se proporcionan valores específicos de curtosis en el documento.

**informe_seguimiento_Q2_2026.md** dice:
> MAPE 30 días: 8.2% | ≤ 10% | OK.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.8 [ALTA] El informe identifica un problema de calidad de datos (rezago de 2 días en 5 fechas) pero no documenta cómo se trató en los cálculos de Q2 2026. No se especifica si esas 5 fechas se excluyeron, si se imputaron, o si se incluyeron con rezago. Sin esta trazabilidad, no se puede validar si el p-value de Kupiec (0.021, que rechaza H0) fue afectado por datos de baja calidad, lo que invalidaría la conclusión de que el modelo tiene un problema de cobertura.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**informe_seguimiento_Q2_2026.md** dice:
> Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas.

**informe_seguimiento_Q2_2026.md** dice:
> Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.9 [ALTA] El manual fija recalibración ANUAL (implícitamente Q4 2026), pero el informe de Q2 2026 reporta una recalibración ADELANTADA a agosto 2026 con cambio metodológico (EWMA → GARCH). No hay evidencia de que este cambio haya sido formalizado en una versión actualizada del manual antes de su implementación. Esto viola el principio de que cambios metodológicos deben estar documentados y aprobados ANTES de su uso operativo, no después.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**manual_metodologico_LaR.md** dice:
> Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria.

**informe_seguimiento_Q2_2026.md** dice:
> Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.10 [ALTA] El manual documenta EWMA como metodología vigente sin mencionar GARCH como alternativa evaluada o en piloto. El informe de seguimiento propone GARCH como respuesta a deficiencias de EWMA detectadas en Q2 2026. No hay evidencia de que la evaluación de GARCH haya sido documentada en el manual antes de su piloto, ni de un proceso formal de comparación (backtesting EWMA vs GARCH) que justifique la transición. Esto sugiere que cambios metodológicos se están implementando sin documentación previa.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Método: EWMA (Exponentially Weighted Moving Average), Parámetro lambda (λ): 0.94 conforme a RiskMetrics

**informe_seguimiento_Q2_2026.md** dice:
> Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1).

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.11 [ALTA] El manual define umbral de alerta para 250 observaciones (esperadas ~2.5 excepciones, alerta si >5). El informe reporta 3 excepciones en 63 días (ventana diferente) y activa alerta. No se justifica por qué se aplica un criterio distinto ni cómo se escala el umbral a 63 días. Esto invalida la comparabilidad del control y sugiere que el umbral se aplica ad-hoc sin metodología clara.

*Ámbito: Documentación · Actividad: Verificar la existencia, suficiencia y claridad de la documentación*

**Manual_Metodologico_LaR.md** dice:
> Umbral de alerta si excedencias observadas > 5 [para 250 observaciones]

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading... Se activó revisión metodológica.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.12 [ALTA] El manual reconoce que la normalidad puede subestimar colas gruesas y menciona que se reporta curtosis observada para detectar esto. Sin embargo, no proporciona los valores reales de curtosis ni el resultado del test de Jarque-Bera. Esto significa que el supuesto de normalidad se declara pero nunca se verifica empíricamente. El riesgo es que el modelo puede estar infraestimando riesgo extremo sin que nadie lo sepa.

*Ámbito: Documentación · Actividad: Verificar la existencia, suficiencia y claridad de la documentación*

**Manual_Metodologico_LaR_completo.pdf (Bloque 3/3)** dice:
> Nota crítica: El documento menciona la métrica pero NO proporciona valores específicos de curtosis ni resultados del test de Jarque-Bera

**Manual_Metodologico_LaR.md** dice:
> Se asume normalidad de retornos: puede subestimar colas gruesas.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.13 [ALTA] El informe menciona que datos críticos (cuenta top-10) llegaron con rezago durante 5 fechas, pero no documenta si esos períodos se excluyeron del backtesting de Kupiec. El p-value de 0.021 rechaza la hipótesis nula (cobertura incondicional). Sin saber si los datos con rezago se incluyeron o excluyeron, no se puede validar si el rechazo es real o artefacto de calidad de datos. Esto invalida la conclusión del backtesting.

*Ámbito: Documentación · Actividad: Verificar la existencia, suficiencia y claridad de la documentación*

**informe_seguimiento_Q2_2026.md** dice:
> Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas.

**informe_seguimiento_Q2_2026.md** dice:
> Kupiec p-value: 0.021 | Umbral: > 0.05 | Estado: RECHAZO H0

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.14 [ALTA] El manual especifica que el backtesting de Kupiec requiere 250 observaciones como mínimo para validez estadística. El informe de Q2 2026 reporta backtesting con solo 63 días de trading (aproximadamente 3 meses), lo que es 75% menor que el mínimo requerido. Esto invalida la confiabilidad estadística del test de Kupiec reportado (p-value 0.021). Un test de Kupiec con n=63 no tiene poder estadístico suficiente para rechazar o aceptar la hipótesis nula con confianza, violando el marco metodológico documentado.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Muestra: 250 observaciones — Frecuencia esperada: ~2.5 excedencias en 250 obs (1% de 250) — Aplicación: Trimestral/mensual

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.15 [ALTA] El manual metodológico documenta que se aplica el test de Jarque-Bera y se reporta curtosis observada como métrica de validación del supuesto de normalidad. El informe de seguimiento de Q2 2026 no incluye ningún resultado de Jarque-Bera ni valores de curtosis en su tabla de métricas de desempeño. Esto indica que el test documentado como requerido no se está ejecutando o reportando, violando el protocolo de seguimiento establecido.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Test de normalidad: Jarque-Bera — Métrica reportada: Curtosis observada (para detectar desviaciones de normalidad y colas pesadas) — Implicación: No se proporcionan valores específicos de curtosis en el documento

**informe_seguimiento_Q2_2026.md** dice:
> | Métrica | Valor | Umbral | Estado | ... | MAPE 30 días | 8.2% | ≤ 10% | OK |

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.16 [ALTA] El manual fija tolerancia cero para unicidad Cliente-Cuenta, pero el reporte de ejecución muestra 1 violación (0.0836% de incumplimiento) y marca FALLA. No hay evidencia de qué acción se tomó: ¿se rechazó el dato?, ¿se imputó?, ¿se pasó al modelo así? Si se pasó al modelo, el control no funcionó. Si se rechazó, ¿por qué el reporte no lo documenta? Esto invalida la trazabilidad de la decisión.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**manual_controles_datos.md** dice:
> Tolerancia: 0 casos. Criticidad ALTA. [para Unicidad Cliente por Cuenta]

**motores_calidad_2026-08-08.xlsx** dice:
> Unicidad de Cliente por Cuenta,0.0836,FALLA,0.0,1 de 1196 grupos ['Cuenta'] tienen más de un valor distinto de 'Cliente'.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.17 [ALTA] El manual exige cero duplicados; el reporte muestra 6 duplicados (0.4988% de incumplimiento) y marca FALLA. No se documenta si fueron eliminados antes de alimentar el modelo o si se pasaron así. Duplicados en datos de entrada sesgan cualquier estadística (media, volatilidad, backtesting) porque sobrerepresentan ciertos eventos.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**manual_controles_datos.md** dice:
> Tolerancia: 0 registros. [para Ausencia de duplicados]

**motores_calidad_2026-08-08.xlsx** dice:
> Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas por ['Cuenta', 'Cliente', 'FechaApertura'].

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.18 [ALTA] El manual exige cero clientes huérfanos; el reporte muestra 1 cliente sin referencia en maestro (0.0831% de incumplimiento) y marca FALLA. Un cliente sin registro en maestro indica desincronización entre sistemas (core bancario y tesorería). No se documenta si se excluyó el registro o si se pasó al modelo con datos incompletos.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**manual_controles_datos.md** dice:
> Tolerancia: 0 casos. Criticidad ALTA. [para Integridad de Cliente contra maestro]

**motores_calidad_2026-08-08.xlsx** dice:
> Integridad referencial Cliente → maestro de clientes,0.0831,FALLA,0.0,1 de 1203 valores de 'Cliente' no existen en la referencia 'Cliente'.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.19 [ALTA] El manual clasifica como ALTA criticidad y tolerancia cero; el reporte muestra 3 valores fuera de rango (0.2519% de incumplimiento) y marca FALLA. Tasas fuera de [0,1] son errores de unidad (ej: 150% en lugar de 1.5 o 0.015). Estos valores distorsionan el cálculo de volatilidad EWMA y el LaR. No se documenta si fueron corregidos, excluidos o pasados al modelo.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**manual_controles_datos.md** dice:
> La `Tasa` de interés debe encontrarse entre **0 y 1** (expresada en tanto por uno). Valores fuera de este rango indican error de unidad. Criticidad ALTA.

**motores_calidad_2026-08-08.xlsx** dice:
> Tasa de interés dentro del rango admisible [0, 1],0.2519,FALLA,0.0,3 valores de 'Tasa' fuera de [0, 1].

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.20 [ALTA] El manual establece tolerancia cero (0 casos) para tres controles de CRITICIDAD ALTA. El reporte de ejecución muestra 1 caso de unicidad violada, 1 cliente huérfano y 3 tasas fuera de rango, todos marcados como FALLA. No existe documentación de acciones correctivas, exclusión de registros o impacto en el modelo. El estado FALLA sin resolución implica que los inputs contienen defectos conocidos que no han sido remediados antes de alimentar el modelo LaR.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**manual_controles_datos.md** dice:
> **Tolerancia: 0 casos.** Criticidad ALTA. [para Unicidad Cliente por Cuenta, Integridad referencial, Rango válido de Tasa]

**motores_calidad_2026-08-08.xlsx** dice:
> Unicidad de Cliente por Cuenta,0.0836,FALLA,0.0 | Integridad referencial Cliente → maestro de clientes,0.0831,FALLA,0.0 | Tasa de interés dentro del rango admisible [0, 1],0.2519,FALLA,0.0

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.21 [ALTA] El manual especifica tolerancia cero para duplicados verificados sobre Cuenta + FechaApertura. El reporte identifica 6 duplicados sobre Cuenta + Cliente + FechaApertura (combinación más restrictiva) y los marca como FALLA. La clave de verificación en el reporte es más estricta que la del manual, pero ambas fallan. No se documenta si estos 6 registros fueron excluidos del dataset antes del cálculo de LaR.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**manual_controles_datos.md** dice:
> ### 2.3 Ausencia de duplicados\nNo deben existir registros completamente duplicados en la base. Se verifica sobre la combinación `Cuenta` + `FechaApertura`. **Tolerancia: 0 registros.**

**motores_calidad_2026-08-08.xlsx** dice:
> Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas por ['Cuenta', 'Cliente', 'FechaApertura'].

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.22 [ALTA] El manual presenta EWMA como la metodología de volatilidad sin mencionar limitaciones o alternativas consideradas. El informe de seguimiento Q2 2026 identifica que EWMA subestimó volatilidad durante estrés de tasas y propone GARCH(1,1) como alternativa. Esto sugiere que la elección de EWMA no fue suficientemente justificada ex-ante ni se consideraron alternativas robustas a cambios de régimen. Riesgo: la metodología documentada puede no ser adecuada para períodos de estrés, que es precisamente cuando el modelo debe ser más confiable.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**Manual_Metodologico_LaR.md** dice:
> Estimador de volatilidad: EWMA con λ = 0.94 (RiskMetrics).

**informe_seguimiento_Q2_2026.md** dice:
> Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.23 [ALTA] El manual reconoce que la validación de normalidad es crítica (curtosis > 3 invalida el modelo) pero NO proporciona los p-valores ni los valores de curtosis observados. Esto es una contradicción entre lo que se declara como requisito (validación explícita) y lo que se ejecuta (mención sin cifras). Riesgo: no es posible verificar si el supuesto de normalidad es válido para esta cartera, lo que invalida la confianza en los cuantiles z(99%) utilizados.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**Manual_Metodologico_LaR_completo.pdf (Bloque 1/3)** dice:
> Limitación crítica: Si curtosis > 3, modelo infraestima riesgo extremo; normalidad asumida pero no validada explícitamente en resultados.

**Manual_Metodologico_LaR_completo.pdf (Bloque 2/3)** dice:
> Nota crítica: El documento menciona la métrica pero NO proporciona valores específicos de curtosis ni resultados del test de Jarque-Bera.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.24 [ALTA] El manual especifica que el backtesting se realiza con 250 observaciones (aproximadamente 10-11 meses de datos mensuales). El informe Q2 2026 reporta resultados de backtesting sobre solo 63 días de trading (3 meses), lo que representa ~25% del tamaño de muestra requerido. Esto invalida la confiabilidad estadística de las pruebas de Kupiec y Christoffersen, que requieren n≥250 para tener poder estadístico suficiente. El modelo no se está backtesting conforme a su propia especificación.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**Manual_Metodologico_LaR_completo.pdf (Bloque 1/3)** dice:
> Backtesting realizado con 250 observaciones — mínimo recomendado por Basel.

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.25 [ALTA] El manual prescribe backtesting mensual. El informe Q2 2026 reporta resultados solo a nivel trimestral, sin logs, actas o evidencia de que las pruebas se ejecutaron cada mes. No hay trazabilidad de cuándo se corrieron, quién las ejecutó, ni cómo se documentaron los resultados mensuales intermedios. Esto sugiere que el backtesting no se ejecuta con la frecuencia documentada.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**Manual_Metodologico_LaR_completo.pdf (Bloque 1/3)** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente.

**informe_seguimiento_Q2_2026.md** dice:
> Informe de Seguimiento — Modelo LaR — Q2 2026 [reporta resultados trimestrales, sin evidencia de ejecución mensual]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.26 [ALTA] El manual declara que se valida normalidad mediante Jarque-Bera y se reporta curtosis observada. El informe Q2 2026 no contiene ninguno de estos resultados. Sin validación del supuesto de normalidad, no se puede confiar en que el modelo LaR (que asume distribución normal) esté correctamente especificado. El manual reconoce que si curtosis > 3 el modelo infraestima riesgo extremo, pero no proporciona evidencia de que se haya verificado este supuesto.

*Ámbito: Metodología · Actividad: Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación*

**Manual_Metodologico_LaR_completo.pdf (Bloque 1/3)** dice:
> Supuesto base: Normalidad de retornos/flujos de liquidez. Test de validación: Jarque-Bera. Métrica reportada: Curtosis observada (para detección de colas gruesas). Limitación crítica: Si curtosis > 3, modelo infraestima riesgo extremo; normalidad asumida pero no validada explícitamente en resultados.

**informe_seguimiento_Q2_2026.md** dice:
> [No hay reporte de resultados de Jarque-Bera, curtosis observada, ni conclusión sobre normalidad]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.27 [ALTA] El manual exige análisis de sensibilidad prospectivo y sistemático ('deben calibrarse', 'contrastarse', 'someterse'); el informe de seguimiento muestra que la comparación EWMA vs GARCH se inicia DESPUÉS de detectar excedencias en Q2 2026, es decir, reactivamente. No hay evidencia de que se hayan ejecutado análisis de sensibilidad antes de ese evento para anticipar el problema. Esto sugiere que el análisis de sensibilidad no está integrado en el ciclo de gestión del modelo, sino que se activa solo cuando hay alertas.

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**Manual_Metodologico_LaR_completo.pdf** dice:
> supuestos de comportamiento aplicados por encima de los mínimos regulatorios deben calibrarse con datos propios, contrastarse con el comportamiento observado en episodios de tensión y someterse a análisis de sensibilidad

**informe_seguimiento_Q2_2026.md** dice:
> Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo. [sin fecha de inicio, sin resultados previos, sin análisis comparativo documentado]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.28 [ALTA] La documentación menciona aprobación por el Comité pero no proporciona el acta formal firmada. Una mención en un manual no es equivalente a un acta de gobierno. Sin acta, no hay evidencia verificable de quién decidió, cuándo, con qué justificación y qué tiering se asignó.

*Ámbito: Gobierno · Actividad: Revisar la actualización del tiering del modelo*

**implementacion_LaR.md** dice:
> Modelo aprobado por el Comité de Riesgo el 2026-01-15

**Instrucciones específicas para este ámbito** dice:
> Solo aceptar actas formales firmadas. Un correo NO equivale a acta.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.29 [ALTA] La documentación reporta aprobación por comité, pero no proporciona el acta formal de inventariado. Aprobación y registro en inventario son actos administrativos distintos: uno valida la metodología, el otro establece la trazabilidad formal y el tiering para gobierno. Sin acta, no hay evidencia de que el modelo esté registrado en el sistema oficial de inventario de modelos.

*Ámbito: Gobierno · Actividad: revisar que el modelo se encuentre inventariado*

**implementacion_LaR.md** dice:
> Modelo aprobado por el Comité de Riesgo el 2026-01-15

**Instrucciones específicas para este ámbito** dice:
> Solo aceptar actas formales firmadas. Un correo NO equivale a acta.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.30 [ALTA] Se declara que existe versionado en Git y que cada corrida guarda metadatos (parámetros, versión, hash), pero simultáneamente se admite que no hay CI/CD y el despliegue es manual en una VM compartida. Esto crea un riesgo de inconsistencia: sin CI/CD automatizado, no hay garantía de que la versión de código guardada en los metadatos sea la que realmente se ejecutó, ni que los cambios en Git se reflejen automáticamente en producción. El despliegue manual en VM compartida es incompatible con la reproducibilidad declarada.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**implementacion_LaR.md** dice:
> Limitaciones actuales: No hay contenedor Docker aún (ejecuta en VM compartida). Falta CI/CD — despliegue manual.

**implementacion_LaR.md** dice:
> Versionado del código en Git (repo `risk-liquidity-models`). Cada corrida guarda: parámetros, versión de código y hash de datos de entrada.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.31 [ALTA] El manual corto fija un umbral de alerta en «excedencias observadas > 5» (criterio de conteo), mientras que el manual completo declara un umbral universal de p-value ≤ 0.05 (criterio estadístico). Estos son dos criterios diferentes: uno es un conteo absoluto, el otro es una probabilidad. No está claro cuál se aplica realmente, ni cómo se reconcilian cuando divergen. Además, el manual completo admite que la «interpretación resulta inconsistente en resultados reportados», lo que sugiere que ni siquiera internamente hay claridad sobre cómo se usan estos umbrales. Esto invalida la reproducibilidad del backtesting.

*Ámbito: Implementación · Actividad: Verifica las fuentes de información empleadas*

**manual_metodologico_LaR.md** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 observaciones — mínimo recomendado por Basel. Umbral de alerta si excedencias observadas > 5.

**Manual_Metodologico_LaR_completo.pdf (Bloque 2/3)** dice:
> Criterio de aceptación/rechazo: Umbral crítico universal: ≤ 0.0500 (5%). Estado OK: p-value ≤ umbral. Estado ALERTA: p-value > umbral (aunque interpretación resulta inconsistente en resultados reportados)

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.32 [ALTA] El modelo se ejecuta DIARIAMENTE pero el backtesting se aplica MENSUALMENTE. No se documenta cómo se reconcilia esta diferencia: ¿se acumulan 30 observaciones diarias para hacer backtesting mensual? ¿se reporta solo al cierre de mes? ¿se usan datos mensuales agregados? Esta ambigüedad invalida la reproducibilidad del backtesting y la comparabilidad de resultados contra el intervalo de Kupiec (que asume 250 observaciones mensuales, no diarias).

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**implementacion_LaR.md** dice:
> Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT.

**manual_metodologico_LaR.md** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.33 [ALTA] Se documenta aprobación de la METODOLOGÍA, pero no de la IMPLEMENTACIÓN. Estos son dos hitos distintos: el modelo puede estar metodológicamente aprobado pero la implementación técnica puede no haber pasado validación formal. Falta evidencia de que alguien haya verificado que el código implementa correctamente la metodología aprobada.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**manual_metodologico_LaR.md** dice:
> Modelo aprobado por el Comité de Riesgo el 2026-01-15.

**implementacion_LaR.md** dice:
> No hay mención de aprobación de la implementación técnica.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.34 [ALTA] El manual corto afirma backtesting mensual de forma definitiva, mientras que el manual completo declara periodicidad ambigua (trimestral/mensual). Esta ambigüedad es crítica porque afecta la frecuencia de detección de desviaciones del modelo. Además, la implementación declara corrida DIARIA del modelo, pero no se especifica si el backtesting se ejecuta diariamente, mensualmente o trimestralmente, lo que genera incertidumbre sobre si las excepciones se están monitoreando en tiempo real o con retraso.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**manual_metodologico_LaR.md** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente.

**Manual_Metodologico_LaR_completo.pdf (Bloque 2/3)** dice:
> Aplicación: Trimestral/mensual

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.35 [ALTA] El manual declara que se ejecutan pruebas de backtesting (Kupiec y Christoffersen) mensualmente, pero el documento de implementación no menciona ningún control que valide los resultados del backtesting ni cómo se integran en la toma de decisiones. Las alertas descritas son sobre ejecución técnica (tiempo, disponibilidad de datos), no sobre validación estadística del modelo. No hay evidencia de que los resultados del backtesting se comuniquen, se revisen o se usen para recalibración.

*Ámbito: Implementación · Actividad: Vericar existencias de correos de comunicación de resultados y su conformidad*

**manual_metodologico_LaR.md** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente.

**implementacion_LaR.md** dice:
> Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Alguna fuente falla o llega vacía.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.36 [ALTA] El manual afirma que el modelo fue aprobado por el Comité de Riesgo, pero el documento de implementación revela que el despliegue es manual y no hay CI/CD. Esto sugiere que la aprobación fue de la metodología, no de la implementación operativa. No hay evidencia de que la implementación actual haya sido validada y aprobada después de la aprobación metodológica. El despliegue manual sin CI/CD es un riesgo de control que debería haber sido documentado en la aprobación.

*Ámbito: Implementación · Actividad: Vericar existencias de correos de comunicación de resultados y su conformidad*

**manual_metodologico_LaR.md** dice:
> Modelo aprobado por el Comité de Riesgo el 2026-01-15.

**implementacion_LaR.md** dice:
> Limitaciones actuales: No hay contenedor Docker aún (ejecuta en VM compartida). Falta CI/CD — despliegue manual.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.37 [ALTA] El documento de uso afirma que existe un control de trazabilidad (cada decisión registrada con ID de corrida), pero el hallazgo de Implementación ya identificó que NO HAY EVIDENCIA DE EJECUCIÓN OPERATIVA (correos, logs, reportes reales). Esto sugiere que el control está DOCUMENTADO pero NO EJECUTADO, o que la documentación describe un estado deseado, no el actual. Riesgo: decisiones de tesorería pueden estar ocurriendo sin trazabilidad real, o el modelo puede no estar integrado en la gestión como se afirma.

*Ámbito: Uso e integración a la gestión · Actividad: Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo*

**uso_LaR_gestion.md** dice:
> Cada decisión de tesorería que se apoya en LaR queda registrada en el acta del comité, con referencia al ID de corrida del modelo.

**contexto inter-ámbito (Implementación)** dice:
> [1/5] La evaluación revela una brecha CRÍTICA entre documentación y evidencia de ejecución operativa. El c[ontexto no proporciona correos de comunicación de resultados]

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.38 [ALTA] Se describe un sistema de alertas por Slack para fallos de ejecución, pero NO HAY EVIDENCIA en el contexto de que estas alertas se hayan disparado, se hayan recibido, o se hayan actuado. Tampoco hay logs de corridas exitosas o fallidas. Esto es consistente con la brecha inter-ámbito: el sistema está DISEÑADO pero no hay prueba de que FUNCIONE en operación. Riesgo: si el DAG falla silenciosamente o no se ejecuta, los usuarios no tendrían LaR actualizado, pero no lo sabrían.

*Ámbito: Uso e integración a la gestión · Actividad: Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo*

**implementacion_LaR.md** dice:
> Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT.

**implementacion_LaR.md** dice:
> Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Alguna fuente falla o llega vacía.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.39 [MEDIA] El manual establece recalibración anual (implícitamente en Q4), pero el informe Q2 2026 adelanta la recalibración a agosto. No hay evidencia de que esta desviación del calendario documentado haya sido formalmente aprobada ni de que se haya actualizado el manual para reflejar el nuevo calendario. Esto sugiere que el manual no se mantiene sincronizado con las decisiones operativas reales.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Recalibración anual obligatoria.

**informe_seguimiento_Q2_2026.md** dice:
> Recalibración adelantada al 2026-08-15 (originalmente Q4).

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.40 [MEDIA] El manual designa como 'Owner' a la Gerencia de Riesgo de Liquidez, pero el informe de seguimiento no identifica QUIÉN activó la revisión metodológica ni CÓMO se conecta con la gobernanza declarada. No hay evidencia de que la Gerencia de Riesgo de Liquidez haya ejecutado una acción documentada en respuesta a las excedencias. Esto sugiere que la cadena de responsabilidad y escalamiento no está clara o no se ejecutó conforme a lo documentado.

*Ámbito: Documentación · Actividad: Verifica la inclusión del objetivo, usos y usuarios del modelo*

**manual_metodologico_LaR.md** dice:
> ## 5. Governance\n\nModelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez.

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.41 [MEDIA] El objetivo describe el PROPÓSITO (estimar pérdida potencial), pero el marco teórico menciona 'lineamientos de Basel III (LCR/NSFR)' sin especificar si el modelo se usa PARA CUMPLIR con esos lineamientos o COMO COMPLEMENTO a ellos. No hay claridad sobre si LaR es un modelo de reporte regulatorio, de gestión interna, o ambos. Esta ambigüedad impide determinar si el modelo está siendo usado conforme a su propósito declarado.

*Ámbito: Documentación · Actividad: Verifica la inclusión del objetivo, usos y usuarios del modelo*

**manual_metodologico_LaR.md** dice:
> ## 1. Objetivo del modelo\n\nEstimar la máxima pérdida potencial de liquidez que la entidad puede sufrir en un horizonte de 30 días con un nivel de confianza del 99%, considerando salidas netas de depósitos, uso de líneas comprometidas y estrés de mercado.

**manual_metodologico_LaR.md** dice:
> ## 2. Marco teórico\n\nEl modelo LaR se apoya en la metodología VaR paramétrica extendida a flujos de caja, siguiendo los lineamientos de Basel III (LCR/NSFR) y las guías internas de Riesgo de Liquidez.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.42 [MEDIA] El manual especifica que el backtesting se realiza con 250 observaciones (aproximadamente 20.8 años de datos mensuales), pero el informe de seguimiento reporta resultados sobre solo 63 días de trading (menos de 3 meses). No está claro si el backtesting de 250 obs se ejecutó en paralelo, si se descartó, o si el modelo está siendo monitoreado con una ventana insuficiente. Esto sugiere que el control de cambios no documentó una desviación de la metodología especificada en el manual.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Backtesting realizado con 250 observaciones — mínimo recomendado por Basel.

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.43 [MEDIA] El manual fija el umbral de alerta en > 5 excedencias, pero el informe Q2 2026 reporta estado ALERTA con solo 3 excedencias (umbral documentado: ≤ 2). Hay una inconsistencia en los criterios de alerta: el manual dice > 5, el informe usa ≤ 2. Esto sugiere que o bien (a) el manual no se actualizó cuando se cambió el criterio, o (b) el informe usa un criterio no documentado. El riesgo es que no hay claridad sobre cuándo se activa revisión metodológica.

*Ámbito: Documentación · Actividad: Verifica la existencia , suficiencia y claridad de la documentación*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Umbral de alerta si excedencias observadas > 5.

**informe_seguimiento_Q2_2026.md** dice:
> | Excedencias 99% | 3 | ≤ 2 | ALERTA |

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.44 [MEDIA] El manual no especifica qué ocurre cuando los datos llegan con rezago, ni quién valida la integridad de los datos antes de ejecutar el modelo. El informe menciona un problema de calidad de datos (rezago de 2 días) como hallazgo, pero no consta en el manual un protocolo de validación de datos ni criterios de aceptación/rechazo. Esto sugiere que la ejecución operativa enfrenta problemas que el manual no prevé ni documenta cómo resolver.

*Ámbito: Documentación · Actividad: Verificar la coherencia del manual de implementación con el manual métodolocios*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Frecuencia de reporte: Cierre mensual

**informe_seguimiento_Q2_2026.md** dice:
> Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.45 [MEDIA] El manual documenta EWMA con λ=0.94 como metodología base, pero el informe de seguimiento identifica que EWMA subestima volatilidad en períodos de estrés y propone cambio a GARCH(1,1). No existe evidencia de que se haya documentado por qué EWMA fue elegido sobre GARCH, ni qué análisis comparativo se realizó. El manual menciona que la normalidad "puede subestimar colas gruesas" pero no conecta esto con la elección de EWMA vs GARCH. El riesgo es que la metodología se cambió sin documentar la justificación de la anterior ni el proceso de validación del cambio.

*Ámbito: Documentación · Actividad: Verificar la coherencia del manual de implementación con el manual métodolocios*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Volatilidad estimada con EWMA: σ²_t = λ · σ²_{t-1} + (1-λ) · r²_{t-1}, λ = 0.94 (diario)

**informe_seguimiento_Q2_2026.md** dice:
> Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1).

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.46 [MEDIA] El manual fija recalibración anual (implícitamente Q4 2026), pero el informe de Q2 2026 adelanta la recalibración a 2026-08-15 sin documentar quién autorizó el cambio, qué criterios lo justificaron (¿solo los 3 excedencias en 63 días?), ni cómo se validó que el cambio es proporcional al riesgo identificado. Esto sugiere que las decisiones de governance no se documentan de forma que permita auditar su justificación.

*Ámbito: Documentación · Actividad: Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.*

**Manual_Metodologico_LaR.md** dice:
> Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria.

**informe_seguimiento_Q2_2026.md** dice:
> Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4).

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.47 [MEDIA] El informe de seguimiento identifica un problema de calidad de datos (rezago de 2 días), pero el manual metodológico no documenta: (a) qué rezagos son aceptables, (b) cómo se detectan y reportan, (c) qué impacto tienen en LaR, (d) qué acciones correctivas se toman. Esto indica que el control de cambios no cubre la calidad de datos de entrada, un componente crítico para la reproducibilidad del modelo.

*Ámbito: Documentación · Actividad: Verifica la existencia de control de cambios/versiones*

**informe_seguimiento_Q2_2026.md** dice:
> Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas.

**Manual_Metodologico_LaR_completo.pdf** dice:
> No se encontró mención de procedimientos de validación de calidad de datos, tratamiento de faltantes, o umbrales de rezago aceptable.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.48 [MEDIA] El manual declara que los datos se procesan a frecuencia mensual (cierre mensual). El informe de seguimiento reporta resultados en términos de 'días de trading' (63 días), lo que sugiere frecuencia diaria. Esta inconsistencia en la granularidad de datos impide verificar si el backtesting se ejecutó con la frecuencia documentada (mensual) o con una diferente (diaria), comprometiendo la trazabilidad del modelo.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**Manual_Metodologico_LaR_completo.pdf** dice:
> Frecuencia de datos: Cierre mensual (explícitamente reportado en notas al pie de todas las secciones)

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.49 [MEDIA] El informe de seguimiento identifica un incidente de calidad de datos (rezagos de 2 días en 5 fechas) pero no existe documentación en el manual metodológico de cómo se detectan, clasifican, escalan o remedian estos incidentes. No hay evidencia de un protocolo de monitoreo de calidad de datos integrado en el proceso de seguimiento del modelo, lo que impide validar si el incidente fue tratado según procedimiento o si fue ad-hoc.

*Ámbito: Documentación · Actividad: Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.*

**informe_seguimiento_Q2_2026.md** dice:
> Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas.

**Manual_Metodologico_LaR_completo.pdf** dice:
> No se encontró en el manual metodológico un protocolo documentado de monitoreo de calidad de datos, umbrales de aceptación de rezagos, o procedimiento de escalamiento cuando se detectan incidentes.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.50 [MEDIA] El perfil documenta que se imputó con media del mes previo, pero también recomienda ejecutar el test de Little's MCAR para clasificar el patrón. No hay evidencia de que el test se haya ejecutado. La imputación con media es válida solo si los datos son MCAR (Missing Completely At Random); si son MAR (Missing At Random) o MNAR (Missing Not At Random), la imputación introduce sesgo. Sin verificar el patrón, no se puede justificar la imputación.

*Ámbito: Calidad de datos · Actividad: Verificar que no exista suficiencia de controles de calidad de datos (integridad)*

**perfil_datos_LaR.md** dice:
> 0.4% de missing en flujos de cuentas corporativas — imputado con la media del mes previo (revisar si MCAR o MAR).

**perfil_datos_LaR.md** dice:
> Adoptar test formal para clasificar patrón de missing (Little's MCAR test).

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.51 [MEDIA] El perfil_datos_LaR.md reporta imputación de missing en flujos (0.4%, dentro del umbral del 1%) pero NO documenta el método de imputación ni su justificación estadística. El manual_controles_datos.md no menciona imputación como opción válida; solo establece tolerancia de 1% de missing. La imputación con media del mes previo es un tratamiento que requiere justificación (¿por qué media y no mediana? ¿se verificó que sea MCAR?). Sin clasificación formal del patrón de missing (MCAR/MAR/MNAR), la imputación puede introducir sesgo en la volatilidad EWMA del modelo LaR.

*Ámbito: Calidad de datos · Actividad: Verificar la actualización de los inputs*

**perfil_datos_LaR.md** dice:
> 0.4% de missing en flujos de cuentas corporativas — imputado con la media del mes previo (revisar si MCAR o MAR).

**manual_controles_datos.md** dice:
> ### 3.1 Valores faltantes en Tasa\nLa columna `Tasa` no debe presentar valores nulos. Se admite hasta un **1%** de missing, por encima del cual se escala al área de datos. Criticidad ALTA.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.52 [MEDIA] El manual fija el umbral de alerta en >5 excedencias (en 250 días, tasa esperada ~2.5). Q2 2026 registró 3 excedencias en 63 días (tasa anualizada ~17 excedencias/año), lo que es 6.8× la tasa esperada, pero está por debajo del umbral de 5 en valor absoluto. Sin embargo, se activó revisión metodológica. Esto indica que el umbral de alerta es INSUFICIENTE para detectar deterioro en tiempo real cuando se observan períodos cortos con concentración de excedencias. El umbral debería ser dinámico o basado en tasas, no en conteos absolutos sobre ventanas fijas de 250 días.

*Ámbito: Metodología · Actividad: Existencia de buenas prácticas en el enfoque metodológico*

**Manual_Metodologico_LaR.md** dice:
> Umbral de alerta si excedencias observadas > 5.

**informe_seguimiento_Q2_2026.md** dice:
> Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.53 [MEDIA] Ambas fuentes reconocen que la normalidad es un supuesto problemático y que se infraestima riesgo extremo. Sin embargo, NO se proporciona: (1) los p-valores del test de Jarque-Bera; (2) los valores de curtosis observada; (3) la conclusión de si la normalidad se rechaza o no; (4) qué se hace cuando se detecta no-normalidad (¿se ajusta el modelo? ¿se aplica corrección de colas?). La limitación está DECLARADA pero no MITIGADA ni CUANTIFICADA.

*Ámbito: Metodología · Actividad: Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique*

**Manual_Metodologico_LaR.md** dice:
> Se asume normalidad de retornos: puede subestimar colas gruesas. No captura contagio entre productos (correlación asumida = 1 en escenario estrés).

**Manual_Metodologico_LaR_completo.pdf (Bloque 1/3)** dice:
> Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para detección de colas gruesas). Limitación crítica: Si curtosis > 3, modelo infraestima riesgo extremo; normalidad asumida pero no validada explícitamente en resultados

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.54 [MEDIA] El manual declara reproducibilidad mediante versionado en Git, pero la implementación admite que no hay CI/CD y el despliegue es manual. Sin CI/CD, no hay garantía de que la versión en Git sea la que se ejecuta en producción, ni que cada corrida use la versión correcta. Esto rompe la cadena de reproducibilidad declarada.

*Ámbito: Implementación · Actividad: Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos*

**implementacion_LaR.md** dice:
> Limitaciones actuales: No hay contenedor Docker aún (ejecuta en VM compartida). Falta CI/CD — despliegue manual.

**manual_metodologico_LaR.md** dice:
> Reproducibilidad: Versionado del código en Git (repo `risk-liquidity-models`). Cada corrida guarda: parámetros, versión de código y hash de datos de entrada.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

### 2.55 [MEDIA] El modelo se ejecuta diariamente pero el backtesting se aplica mensualmente. No se documenta si el backtesting se ejecuta automáticamente cada mes dentro del DAG de Airflow, o si es un proceso manual desacoplado. Esta desconexión impide verificar que el control de backtesting esté integrado en el pipeline productivo y se ejecute sistemáticamente sin intervención manual.

*Ámbito: Implementación · Actividad: Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)*

**implementacion_LaR.md** dice:
> Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT.

**manual_metodologico_LaR.md** dice:
> Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente.

> ✍️ **Verifica ambas citas en el original.** Si se confirma, es un
> hallazgo de informe. Si el agente se equivocó, descártalo y anota por qué.

## 3. Cuestionamiento metodológico

Un modelo puede documentar impecablemente una elección equivocada. Esto
no evalúa si la metodología está descrita, sino si está **justificada**.

### Verifica la existencia de control de cambios/versiones

No aplica a esta actividad (control de cambios/versiones). Sin embargo, la ausencia de un sistema de control de cambios impide verificar si la metodología EWMA con λ=0.94 fue elegida mediante un proceso documentado de comparación con alternativas (GARCH, volatilidad histórica, etc.) o si fue simplemente heredada de RiskMetrics sin justificación local. El manual cita RiskMetrics (1996) como referencia, pero no explica por qué esa metodología es apropiada para esta cartera específica, ni qué análisis de sensibilidad se realizó. La propuesta de piloto GARCH sugiere que la elección original no fue suficientemente robusta, pero sin un changelog no es posible rastrear cuándo se tomó esa decisión ni qué evidencia la sustentaba.

### Verifica la existencia , suficiencia y claridad de la documentación

El manual metodológico cita RiskMetrics (JP Morgan 1996) como base para EWMA con λ=0.94 y distribución normal, pero NO justifica por qué esta metodología es apropiada para LaR (riesgo de liquidez) en lugar de VaR (riesgo de mercado). RiskMetrics fue diseñado para retornos de activos, no para flujos de liquidez. El manual reconoce limitaciones críticas (colas gruesas, correlaciones inestables en estrés) pero no documenta qué alternativas se evaluaron ni por qué se descartaron. El informe Q2 2026 menciona un «piloto GARCH(1,1) vs EWMA» pero no hay documentación de la metodología de comparación, criterios de selección, o resultados esperados. La recomendación de complementar con Expected Shortfall (ES) aparece en el resumen técnico pero NO en el manual metodológico ni en el seguimiento. Falta justificación de por qué se mantiene EWMA si se reconoce que infraestima colas.

### Verificar la coherencia del manual de implementación con el manual métodolocios

El manual metodológico describe EWMA con λ=0.94 citando RiskMetrics (1996) como estándar de mercado, pero no justifica por qué EWMA es superior a alternativas como GARCH(1,1), ARCH, o volatilidad histórica simple para un horizonte de 30 días en flujos de liquidez. El informe de seguimiento Q2 2026 identifica que EWMA subestima volatilidad en estrés, lo que sugiere que el supuesto de decaimiento exponencial uniforme no captura cambios de régimen. El manual menciona que se asume normalidad pero "puede subestimar colas gruesas", y que se reporta curtosis para detectar desviaciones, pero NO se proporcionan valores de curtosis observados ni resultados del test de Jarque-Bera. Esto impide verificar si el supuesto de normalidad fue validado empíricamente. El manual especifica backtesting con Kupiec y Christoffersen sobre 250 observaciones, pero el informe reporta resultados sobre 63 días (menos de 3 meses), lo que invalida la comparabilidad. No existe justificación documentada de por qué se cambió la ventana de backtesting, ni análisis de cómo esto afecta la potencia estadística de las pruebas. El test de López (que valida la magnitud de las pérdidas, no solo su frecuencia) no se menciona en ningún documento, aunque es estándar en backtesting de VaR/LaR según literatura regulatoria (Basel III, SR 11-7).

### Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.

El manual justifica la elección de EWMA (λ=0.94) citando RiskMetrics (JP Morgan 1996) como «estándar de mercado», pero no documenta por qué se eligió EWMA sobre alternativas como GARCH(1,1), ARCH, o volatilidad histórica simple. El informe de Q2 2026 menciona un «piloto GARCH(1,1) vs EWMA» como acción correctiva, lo que sugiere que la elección de EWMA nunca fue comparada empíricamente contra alternativas en esta cartera específica. El manual advierte que la normalidad «puede subestimar colas gruesas» y que «no captura contagio entre productos», pero no documenta análisis de sensibilidad que cuantifiquen el impacto de estas limitaciones en el LaR reportado. La recomendación de complementar con Expected Shortfall (ES) aparece en el resumen técnico de RiskMetrics pero no se implementa ni se justifica su ausencia. Sin este análisis, la elección de EWMA + Normal aparece como una decisión por defecto, no como una decisión justificada.

### Verifica la existencia de control de cambios/versiones

No aplica a esta actividad (evaluación de control de versiones, no de metodología). Sin embargo, la ausencia de documentación de cambios metodológicos impide validar si la transición EWMA → GARCH fue justificada: no hay evidencia de que se haya comparado el desempeño de ambos métodos en backtesting, ni de que se haya evaluado el impacto en el nivel de confianza 99% o en la interpretación de LaR.

### Verificar la existencia, suficiencia y claridad de la documentación

El manual describe EWMA con λ=0.94 (RiskMetrics estándar) pero no justifica por qué esta elección es apropiada para flujos de liquidez (que pueden tener dinámicas distintas a retornos de mercado). El informe de seguimiento menciona un piloto GARCH(1,1) vs EWMA, lo que sugiere que la elección de EWMA no fue validada empíricamente contra alternativas. No hay evidencia de que se haya contrastado EWMA contra GARCH en datos históricos de esta cartera. El manual cita RiskMetrics (1996) como marco teórico, pero RiskMetrics fue diseñado para riesgo de mercado, no riesgo de liquidez. No se justifica la extensión de la metodología a flujos de caja. Además, el manual asume correlación = 1 en escenario de estrés sin documentar cómo se calibra este supuesto ni qué evidencia lo sostiene. La ausencia de justificación de estas elecciones metodológicas es una brecha crítica.

### Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

El manual metodológico cita RiskMetrics (JP Morgan 1996) como justificación para EWMA con λ=0.94, pero no justifica por qué se eligió EWMA sobre alternativas como GARCH(1,1), que el propio informe de seguimiento menciona como piloto. El manual declara que se asume normalidad de retornos pero no documenta cómo se valida este supuesto antes de usar z-scores (z(99%)=2.326). El test de Jarque-Bera se menciona como requerido pero no hay evidencia de que se ejecute sistemáticamente. El manual no justifica por qué se usa un nivel de confianza bilateral del 99% en lugar de unilateral (estándar en VaR). No hay análisis de sensibilidad documentado respecto a la elección de λ=0.94 versus otros valores. El horizonte de 30 días se alinea con LCR/NSFR (Basel III) pero no hay justificación explícita de por qué es apropiado para esta cartera específica. El manual no cita ni contrasta con literatura sobre LaR (Liquidity at Risk) más allá de RiskMetrics; no hay referencia a trabajos sobre modelización de flujos de liquidez o comportamiento de depósitos en estrés.

### Existencia de buenas prácticas en el enfoque metodológico

¿POR QUÉ EWMA Y NO GARCH(1,1)? El manual justifica EWMA únicamente como «conforme a RiskMetrics» (estándar de mercado para retornos de activos), pero no argumenta por qué es adecuado para flujos de liquidez, que pueden exhibir dinámicas de volatilidad distintas (cambios de régimen, contagio entre productos, shocks de tasas). El informe Q2 2026 identifica que EWMA subestimó volatilidad durante estrés, lo que sugiere que la elección no fue robusta. ¿Se evaluó GARCH(1,1) ex-ante y se descartó? ¿Con qué criterio? ¿Qué análisis de sensibilidad se realizó sobre λ=0.94? ¿POR QUÉ NO SE VALIDA NORMALIDAD? El manual menciona Jarque-Bera como test de validación pero no reporta p-valores ni curtosis. Sin estas cifras, la afirmación de que se validó normalidad es una declaración no verificada. ¿Cuál es la curtosis observada? ¿Se rechaza normalidad? Si se rechaza, ¿por qué se sigue usando z(99%) de la distribución normal? ¿POR QUÉ NO EXPECTED SHORTFALL? RiskMetrics recomienda complementar VaR con ES para capturar pérdida esperada más allá del cuantil. El manual LaR no menciona ES. ¿Se consideró? ¿Por qué se descartó? ¿HORIZONTE DE 30 DÍAS: JUSTIFICADO? El modelo usa 30 días como horizonte. ¿Se justifica esta elección? ¿Se validó que 30 días es suficiente para capturar dinámicas de liquidez en esta cartera? ¿Se realizó análisis de sensibilidad sobre el horizonte? ¿NIVEL DE CONFIANZA 99%: JUSTIFICADO? El modelo usa 99% (z=2.326). ¿Se justifica esta elección? ¿Se comparó con 95% o 97.5%? ¿Qué impacto tiene en decisiones de gestión? ¿SUPUESTOS NO VERIFICADOS: INDEPENDENCIA, ESTACIONARIEDAD? El modelo asume que flujos de liquidez son i.i.d. (implícito en el uso de z-scores). ¿Se verificó independencia temporal? ¿Se verificó estacionariedad? ¿Qué ocurre si hay autocorrelación o cambios de régimen?

### Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

¿Por qué se eligió EWMA con λ=0.94 (RiskMetrics) en lugar de GARCH(1,1) u otro estimador de volatilidad condicional? El manual cita RiskMetrics (1996) como justificación, pero no argumenta por qué este parámetro es óptimo para flujos de liquidez de esta entidad. El informe Q2 2026 menciona un 'piloto GARCH(1,1) vs EWMA' como acción correctiva, lo que sugiere que la elección de EWMA no fue validada empíricamente contra alternativas. ¿Se descartó GARCH por razones técnicas, de costo computacional, o simplemente porque RiskMetrics es estándar? Sin esta justificación, la metodología aparece heredada, no elegida. ¿Se verificó que la distribución normal es adecuada para flujos de liquidez? El manual declara que se aplica Jarque-Bera pero no reporta resultados. Si la curtosis observada es > 3 (colas gruesas), el modelo subestima eventos extremos, y el nivel de confianza del 99% es ilusorio. ¿Cómo se reconcilia la recomendación de RiskMetrics (complementar VaR con Expected Shortfall para capturar colas gruesas) con la ausencia de ES en el modelo LaR? El manual cita la limitación pero no implementa la mitigación. ¿Por qué el backtesting se ejecuta sobre 63 días (Q2 2026) cuando el manual exige 250 observaciones? ¿Es una excepción documentada o un incumplimiento no reconocido? Si es excepción, ¿cuál es el impacto en la confiabilidad de Kupiec y Christoffersen con n=63?

### Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

1. **¿Por qué EWMA y no GARCH(1,1) desde el inicio?** El manual justifica EWMA por referencia a RiskMetrics (estándar de mercado), pero no explica por qué ese estándar es adecuado para LaR (que es un modelo de flujos de liquidez, no de retornos de mercado). El informe Q2 2026 sugiere que GARCH captura mejor la volatilidad condicional, pero no hay análisis previo que justifique la elección inicial de EWMA ni que descarte GARCH. ¿Se eligió EWMA por simplicidad, por herencia de otro modelo, o por evidencia empírica? No consta.

2. **¿Qué alternativas de distribución se consideraron?** El manual asume normalidad y reconoce que subestima colas gruesas. ¿Se evaluaron distribuciones con colas pesadas (t-Student, GEV, mezclas)? ¿Se descartaron? ¿Con qué criterio? No hay evidencia de un análisis comparativo de distribuciones.

3. **¿Se verifican los supuestos del modelo?** El manual menciona test de Jarque-Bera y curtosis, pero no reporta resultados. Sin p-valores y conclusiones, no puede verificarse si la normalidad es un supuesto válido o una violación sistemática. Esto es crítico: si la curtosis es > 3 de forma consistente, el modelo está infraestimando riesgo de forma estructural.

4. **¿Qué rango de sensibilidad se considera aceptable?** No hay documentación de umbrales de tolerancia para cambios en LaR ante variaciones en λ (0.94 ± 0.05?), horizonte (30 ± 5 días?), o nivel de confianza (99% ± 1%?). Sin esto, no puede evaluarse si el modelo es robusto o frágil.

5. **¿Se han ejecutado escenarios de estrés histórico?** El manual menciona 'episodios de tensión' (p.ej., mayo 2026 en el informe Q2), pero no hay análisis documentado de cómo el LaR se comportó en esos períodos vs predicción. ¿Cuál fue el LaR predicho en mayo 2026? ¿Cuál fue la pérdida real? ¿Cuántas excedencias se observaron? El informe dice '3 excedencias en 63 días', pero no desglosa si todas fueron en mayo o distribuidas. Sin esto, no puede validarse la capacidad predictiva del modelo en estrés.

6. **¿Cómo se justifica la correlación = 1 en escenario de estrés?** El manual declara este supuesto pero no lo valida. ¿Se ha observado correlación = 1 en datos históricos de estrés? ¿O es un supuesto conservador sin base empírica? Si es lo segundo, ¿cuál es el impacto en el LaR si se relaja a correlación = 0.8 o 0.9?

> ✍️ **Te toca:** contrasta esto con tu criterio experto. El agente puede
> cuestionar sin conocer restricciones de negocio que sí justifican la
> elección — si es el caso, déjalo escrito en el informe final.

## 4. Información a solicitar al modelador

**146 petición(es)**, sin duplicados y ordenadas por gravedad del
control que las origina. Esta lista se envía tal cual.

| # | Ámbito | Score | Petición |
|---:|---|---:|---|
| 1 | Implementación | 1/5 | ¿Existen correos de comunicación de resultados del backtesting (Kupiec y Christoffersen) al Comité de Riesgo o a primera línea? Si existen, ¿cuál es la frecuencia y cuándo fue el último? |
| 2 | Implementación | 1/5 | ¿Cuál es el script Python (.py o .ipynb) que implementa el cálculo de LaR? ¿Dónde se almacena en el repositorio Git `risk-liquidity-models` y cuál es su versión actual? |
| 3 | Implementación | 1/5 | ¿Existen logs de ejecución del DAG de Airflow que demuestren que la corrida diaria a las 07:00 COT se ejecuta exitosamente? ¿Cuál es el período de cobertura de estos logs? |
| 4 | Implementación | 1/5 | ¿Se ejecutó una prueba de aceptación del usuario (UAT) antes de pasar el modelo a producción? Si existe, ¿cuál es el acta de conformidad y quién la firmó? |
| 5 | Implementación | 1/5 | ¿Existe un correo o acta de aprobación formal para el paso a producción del modelo LaR? ¿Quién autorizó el despliegue manual y cuándo? |
| 6 | Implementación | 1/5 | ¿Cuál es el resultado más reciente del backtesting (Kupiec y Christoffersen)? ¿Cuándo se ejecutó y cuáles fueron los p-values observados? |
| 7 | Implementación | 1/5 | ¿El código en producción coincide exactamente con la versión documentada en el manual metodológico? Específicamente: ¿usa λ = 0.94 en EWMA, z(99%) = 2.326, horizonte de 30 días, y ventana de 250 observaciones para backtesting? |
| 8 | Implementación | 1/5 | ¿Existe un control de cambios documentado que registre cualquier modificación al código después de la aprobación del Comité de Riesgo del 2026-01-15? |
| 9 | Documentación | 2/5 | ¿Existe un registro formal de cambios (changelog) que documente todas las versiones del Manual Metodológico LaR, incluyendo fechas, cambios específicos, justificación y aprobador? Si existe, ¿dónde se almacena y cómo se mantiene sincronizado con el manual en producción? |
| 10 | Documentación | 2/5 | ¿Fue formalmente aprobado por el Comité de Riesgo el cambio de recalibración de Q4 a 2026-08-15? ¿Existe acta de esa aprobación? |
| 11 | Documentación | 2/5 | ¿Cuál es el estado actual del piloto GARCH(1,1) propuesto en Q2 2026? ¿Ha sido aprobado? ¿Cuándo se espera que entre en producción? ¿Se actualizará el manual cuando se implemente? |
| 12 | Documentación | 2/5 | ¿Existe un procedimiento documentado que defina cuándo y cómo se deben proponer cambios metodológicos, quién debe aprobarlos, y cómo se comunican e implementan? |
| 13 | Documentación | 2/5 | ¿La versión recalibrada del modelo (post-2026-08-15) está documentada en un manual actualizado (v4.3 o posterior)? Si es así, ¿cuáles fueron los cambios específicos respecto a v4.2? |
| 14 | Documentación | 2/5 | ¿Existe control de versiones en el código de cálculo del modelo (scripts, stored procedures, etc.)? ¿Se etiquetan las versiones de código con las versiones del manual metodológico? |
| 15 | Documentación | 2/5 | ¿Existe un documento de gobernanza del modelo LaR que especifique explícitamente los USOS CONCRETOS (ej: límites de riesgo diarios, reporte regulatorio, stress testing, decisiones de pricing)? Si existe, ¿por qué no está incluido en la documentación revisada? |
| 16 | Documentación | 2/5 | ¿Quiénes son los USUARIOS OPERATIVOS del modelo (por rol y área)? ¿Tesorería lo consulta diariamente? ¿El Comité de Riesgo lo revisa mensualmente? ¿Hay un registro de quién accede a los resultados y con qué frecuencia? |
| 17 | Documentación | 2/5 | ¿Cuál es la CADENA DE ESCALAMIENTO cuando LaR excede un umbral? El informe Q2 2026 menciona 'Se activó revisión metodológica', pero ¿quién la activó, cuándo, y bajo qué criterio? ¿Existe un procedimiento documentado? |
| 18 | Documentación | 2/5 | ¿Se ha validado que el modelo LaR se usa ÚNICAMENTE para los propósitos para los que fue diseñado, o se ha detectado uso para otros fines (ej: decisiones de límites de crédito, pricing de depósitos) sin documentación de esa extensión? |
| 19 | Documentación | 2/5 | ¿El manual metodológico distingue entre el modelo como herramienta de GESTIÓN INTERNA y como herramienta de REPORTE REGULATORIO (LCR/NSFR)? Si ambos usos coexisten, ¿cómo se asegura coherencia entre supuestos? |
| 20 | Documentación | 2/5 | ¿Existe un documento formal de control de cambios (changelog o matriz de cambios) que registre todas las versiones del modelo LaR desde su aprobación inicial? Si existe, ¿por qué no se incluyó en el contexto de validación? |
| 21 | Documentación | 2/5 | ¿Cuál es el proceso formal para documentar y aprobar cambios metodológicos (ej: cambio de EWMA a GARCH)? ¿Genera automáticamente una nueva versión del manual, o se documenta en un registro separado? |
| 22 | Documentación | 2/5 | ¿El piloto GARCH(1,1) mencionado en el informe Q2 2026 ha sido aprobado formalmente? ¿En qué versión del manual se documentará si es aceptado? |
| 23 | Documentación | 2/5 | ¿Existe un manual operativo separado que describa el proceso de ejecución del modelo, incluyendo el procedimiento de control de cambios? Si existe, ¿cuál es su versión actual y cómo se sincroniza con el manual metodológico? |
| 24 | Documentación | 2/5 | ¿Cómo se comunican los cambios de versión a los usuarios del modelo (comités, áreas de negocio, sistemas)? ¿Existe un registro de distribución de versiones? |
| 25 | Documentación | 2/5 | ¿Por qué el backtesting en Q2 2026 se reporta sobre 63 días de trading en lugar de las 250 observaciones especificadas en el manual? ¿Es una desviación documentada o un cambio no registrado? |
| 26 | Documentación | 2/5 | ¿Existe un manual operativo que describa el flujo de datos de entrada (fuentes, frecuencia, validaciones), el proceso de cálculo (quién, cuándo, con qué herramientas), y el flujo de salida (quién recibe el LaR, para qué decisiones)? |
| 27 | Documentación | 2/5 | ¿Cuál es el histórico completo de resultados de backtesting (Kupiec y Christoffersen) mes a mes desde la implementación del modelo? ¿Quién es responsable de ejecutarlos y de escalar desviaciones? |
| 28 | Documentación | 2/5 | ¿Se han ejecutado tests de Jarque-Bera y se han reportado valores de curtosis en algún período? Si sí, ¿cuáles fueron los resultados y qué acciones se tomaron si la curtosis > 3? |
| 29 | Documentación | 2/5 | ¿Por qué el umbral de alerta en el manual es > 5 excedencias pero el informe Q2 2026 usa ≤ 2? ¿Cuándo se cambió este criterio y por qué no se actualizó el manual? |
| 30 | Documentación | 2/5 | ¿Cómo se detectan, escalan y resuelven problemas de calidad de datos (como el rezago de 2 días en la cuenta corporativa top-10)? ¿Existe un procedimiento documentado? |
| 31 | Documentación | 2/5 | ¿Se ha evaluado formalmente GARCH(1,1) vs EWMA? ¿Cuál es la metodología de comparación, los criterios de decisión, y cuándo se espera completar el piloto? |
| 32 | Documentación | 2/5 | ¿Por qué no se implementa Expected Shortfall (ES) si el manual técnico lo recomienda para capturar pérdidas más allá del VaR? |
| 33 | Documentación | 2/5 | ¿Existe un manual operativo que describa paso a paso cómo se ejecuta el modelo LaR en producción (ingesta de datos, validaciones, cálculo, reporte, escalada)? Si existe, ¿por qué no está en el contexto disponible? |
| 34 | Documentación | 2/5 | ¿Cuál es el protocolo documentado para cambiar la ventana de backtesting de 250 observaciones mensuales a 63 días? ¿Quién autoriza este cambio y cómo se valida que sigue siendo estadísticamente válido? |
| 35 | Documentación | 2/5 | ¿Se ejecutó el test de Jarque-Bera sobre los flujos de liquidez para validar el supuesto de normalidad? Si sí, ¿cuáles fueron los resultados y qué curtosis se observó? |
| 36 | Documentación | 2/5 | ¿Por qué se eligió EWMA con λ=0.94 sobre GARCH(1,1) u otros métodos de volatilidad? ¿Se realizó un análisis comparativo documentado? ¿Cuándo y por qué se decidió cambiar a GARCH? |
| 37 | Documentación | 2/5 | ¿Existe un protocolo documentado de validación de datos que especifique qué ocurre cuando los datos llegan con rezago (como los 2 días reportados en Q2 2026)? ¿Quién decide si el modelo se ejecuta o se pospone? |
| 38 | Documentación | 2/5 | ¿Cuál es el criterio exacto para activar una revisión metodológica? El manual menciona umbral de >5 excedencias, pero Q2 2026 reporta 3 excedencias y se activó revisión. ¿Existe un protocolo de escalada no documentado? |
| 39 | Documentación | 2/5 | ¿Se ejecutó el test de López (validación de magnitud de pérdidas) en el backtesting de Q2 2026? Si no, ¿por qué no se incluye en el framework de backtesting? |
| 40 | Documentación | 2/5 | ¿Existe un control de cambios documentado para el Manual Metodológico LaR v4.2? ¿Cuándo fue la última actualización y qué cambios se realizaron? |
| 41 | Documentación | 2/5 | ¿Existe un script ejecutable de backtesting (Kupiec y Christoffersen) con logs de ejecución que muestren cuándo se corrió, con qué datos, y quién validó los resultados? Si existe, ¿dónde está documentado y cómo se integra en el proceso de control mensual? |
| 42 | Documentación | 2/5 | ¿Cuáles son los valores específicos de curtosis observada en los últimos 250 días de datos? ¿Se ejecutó el test de Jarque-Bera y cuál fue el p-value? Si la curtosis > 3, ¿qué acciones se tomaron para ajustar el modelo? |
| 43 | Documentación | 2/5 | ¿Cómo se trató en los cálculos de Q2 2026 el rezago de 2 días en los datos de la cuenta corporativa top-10 durante las 5 fechas identificadas? ¿Se excluyeron esas fechas del backtesting, se imputaron, o se incluyeron con rezago? ¿Afectó esto el p-value de Kupiec reportado (0.021)? |
| 44 | Documentación | 2/5 | ¿Existe un manual operativo (paso a paso) que describa: (a) el flujo de ingesta de datos desde el core bancario, (b) el cálculo de EWMA con λ=0.94, (c) la aplicación del z-score (2.326 para 99%), (d) la generación del reporte de LaR, (e) los controles de validación en cada paso? Si no existe, ¿cuándo se creará? |
| 45 | Documentación | 2/5 | ¿Quién autorizó la recalibración adelantada al 2026-08-15 y con qué criterios se justificó? ¿Se documentó esta decisión en acta del Comité de Riesgo o en algún documento de governance? |
| 46 | Documentación | 2/5 | ¿Se ejecutó un análisis de sensibilidad que compare EWMA vs GARCH(1,1) en datos históricos de esta cartera? ¿Cuáles fueron los resultados del piloto mencionado en el informe de Q2 2026 y cuándo se completará? |
| 47 | Documentación | 2/5 | ¿Por qué no se implementa Expected Shortfall (ES) como complemento a VaR, tal como recomienda RiskMetrics y el propio manual metodológico menciona en limitaciones? |
| 48 | Documentación | 2/5 | ¿Cuál es el proceso formal para aprobar cambios metodológicos (ej: EWMA → GARCH)? ¿Se requiere aprobación del Comité de Riesgo antes de implementación, o después? |
| 49 | Documentación | 2/5 | ¿Se ha documentado en una versión posterior del manual (v4.3 o superior) la evaluación de GARCH(1,1) como alternativa a EWMA? ¿Cuándo se completará esta documentación? |
| 50 | Documentación | 2/5 | ¿Existe un manual operativo separado que describa la ejecución del modelo (scripts, parámetros, datos de entrada)? ¿Tiene su propio control de versiones? |
| 51 | Documentación | 2/5 | ¿Qué procedimiento se sigue cuando se detectan problemas de calidad de datos (como el rezago de 2 días reportado en Q2 2026)? ¿Se documenta en el manual o en un registro de incidentes? |
| 52 | Documentación | 2/5 | ¿El control de versiones cubre solo el manual metodológico, o también los scripts de cálculo, parámetros de configuración y datos de entrada? ¿Cómo se garantiza la coherencia entre versiones de estos componentes? |
| 53 | Documentación | 2/5 | ¿Existen scripts o logs de ejecución del backtesting de Kupiec y Christoffersen? ¿Dónde se almacenan y con qué frecuencia se ejecutan realmente? |
| 54 | Documentación | 2/5 | ¿Cómo se trataron los 5 períodos con datos de rezago de 2 días? ¿Se excluyeron del backtesting de Kupiec reportado en Q2 2026? |
| 55 | Documentación | 2/5 | ¿Por qué se activó alerta con 3 excepciones en 63 días si el umbral definido es >5 para 250 observaciones? ¿Existe un criterio escalado para ventanas menores? |
| 56 | Documentación | 2/5 | ¿Existe documentación operativa (manual de procedimientos) que describa paso a paso cómo se ejecuta el modelo, quién lo ejecuta, cuándo, y dónde se almacenan los resultados? |
| 57 | Documentación | 2/5 | ¿Se ha contrastado empíricamente EWMA vs GARCH(1,1) en datos históricos de esta cartera? ¿Cuáles fueron los resultados del piloto mencionado en el informe? |
| 58 | Documentación | 2/5 | ¿Cómo se integran los resultados del backtesting en decisiones de governance? ¿A qué comité llegan, con qué frecuencia, y qué acciones se toman si p-value < 0.05? |
| 59 | Documentación | 2/5 | ¿Se verifica el supuesto de correlación = 1 en escenario de estrés? ¿Existe análisis empírico que lo sustente? |
| 60 | Documentación | 2/5 | ¿Por qué el informe de Q2 2026 reporta backtesting de Kupiec con 63 días de trading cuando el manual especifica 250 observaciones como mínimo? ¿Se ejecutó el test con una ventana móvil de 250 observaciones o se reportó un resultado inválido? |
| 61 | Documentación | 2/5 | ¿Cuál es la frecuencia real de datos utilizada en el modelo: mensual (como declara el manual) o diaria (como sugiere el reporte en 'días de trading')? ¿Cómo se reconcilia esta diferencia? |
| 62 | Documentación | 2/5 | ¿Dónde están los resultados del test de Jarque-Bera y los valores de curtosis observada que el manual declara como métrica de seguimiento? ¿Se ejecutan mensualmente o solo bajo demanda? |
| 63 | Documentación | 2/5 | ¿Existe un protocolo documentado de monitoreo de calidad de datos que especifique: (a) qué métricas se monitorean (rezagos, faltantes, outliers), (b) umbrales de alerta, (c) procedimiento de escalamiento, (d) impacto en la validez del modelo? |
| 64 | Documentación | 2/5 | ¿Cuál fue la acción correctiva específica tomada respecto al rezago de 2 días en datos de la cuenta corporativa top-10? ¿Se excluyeron esas fechas del backtesting? ¿Se ajustó el modelo? |
| 65 | Documentación | 2/5 | ¿El piloto GARCH(1,1) mencionado en acciones correctivas incluye backtesting comparativo (Kupiec + Christoffersen) contra EWMA? ¿Cuándo se espera completar y qué criterios de decisión se aplicarán? |
| 66 | Documentación | 2/5 | ¿Existe un log o registro de ejecución de scripts de backtesting que demuestre que Kupiec y Christoffersen se ejecutan mensualmente como se documenta? |
| 67 | Documentación | 2/5 | ¿Por qué el manual especifica 'Aplicación: Trimestral/mensual' para Kupiec pero el informe reporta resultados solo para Q2 (trimestral)? ¿Se ejecuta mensualmente o no? |
| 68 | Calidad de datos | 2/5 | ¿Existe un script automatizado (_replica_virf.py o equivalente) que ejecute los controles de calidad de datos en cada corrida mensual? Si existe, ¿cuál es su ubicación y cuándo se ejecutó por última vez? |
| 69 | Calidad de datos | 2/5 | ¿Qué acción se tomó ante cada uno de los cuatro fallos reportados en motores_calidad_2026-08-08.xlsx (Unicidad Cliente, Duplicados, Integridad referencial, Rango de Tasa)? ¿Se rechazaron los registros, se imputaron, o se pasaron al modelo así? |
| 70 | Calidad de datos | 2/5 | ¿Existe un log o reporte de trazabilidad que documente la ejecución de controles de calidad para cada corrida mensual del modelo LaR? ¿Quién ejecuta estos controles y quién aprueba la decisión de pasar datos al modelo? |
| 71 | Calidad de datos | 2/5 | ¿Se ejecutó el test de Little's MCAR sobre los 0.4% de missing en flujos de cuentas corporativas? Si no, ¿cómo se justifica la imputación con media del mes previo? |
| 72 | Calidad de datos | 2/5 | ¿Cuál es la fecha del reporte motores_calidad_2026-08-08.xlsx? ¿Corresponde a la corrida mensual más reciente o es un reporte histórico? ¿Se han subsanado los fallos desde entonces? |
| 73 | Calidad de datos | 2/5 | ¿Existe documentación de cambios o excepciones aprobadas a los umbrales de tolerancia (ej: por qué se aceptó 1 cliente huérfano si la tolerancia es 0)? |
| 74 | Calidad de datos | 2/5 | ¿Se verifica la coherencia entre los datos que pasan los controles de calidad y los datos que efectivamente alimentan el modelo LaR? ¿Hay un punto de control antes de que los datos entren al cálculo de volatilidad EWMA? |
| 75 | Calidad de datos | 2/5 | ¿Existe un script de extracción y control de datos (_replica_virf.py o equivalente) que implemente la lógica descrita en manual_controles_datos.md? Si existe, ¿cuál es su versión, fecha de última ejecución y resultados? |
| 76 | Calidad de datos | 2/5 | ¿Cuál fue la acción correctiva tomada para los 1 caso de unicidad violada, 6 duplicados, 1 cliente huérfano y 3 tasas fuera de rango? ¿Fueron excluidos del dataset antes del cálculo de LaR, o se mantuvieron con alguna justificación documentada? |
| 77 | Calidad de datos | 2/5 | ¿Se ejecutó el test de Little (MCAR test) sobre los 0.4% de missing en flujos antes de imputar con media del mes previo? ¿Qué justificación técnica respalda la elección de media vs. mediana vs. forward-fill? |
| 78 | Calidad de datos | 2/5 | ¿Existe un log de auditoría que registre cuándo se ejecutaron los controles de calidad (motores_calidad_2026-08-08.xlsx), quién los ejecutó, y qué versión del dataset se utilizó? |
| 79 | Calidad de datos | 2/5 | ¿El dataset que alimentó el cálculo de LaR es el mismo que se reporta en motores_calidad_2026-08-08.xlsx, o se aplicaron transformaciones posteriores? Si es distinto, ¿cuál es la trazabilidad? |
| 80 | Calidad de datos | 2/5 | ¿Se documentó en acta de Comité de Riesgo la aceptación de los fallos de calidad de datos (FALLA en 4 controles) como riesgo conocido del modelo? |
| 81 | Metodología | 2/5 | ¿Cuáles son los p-valores específicos del test de Jarque-Bera y los valores de curtosis observada para la cartera de flujos de liquidez? ¿Se rechaza la hipótesis de normalidad? |
| 82 | Metodología | 2/5 | ¿Se realizó un análisis comparativo formal entre EWMA (λ=0.94) y GARCH(1,1) ex-ante a la implementación? ¿Con qué criterios se descartó GARCH(1,1) en la metodología original? |
| 83 | Metodología | 2/5 | ¿Por qué el umbral de alerta se fija en >5 excedencias (en 250 días) cuando Q2 2026 mostró 3 excedencias en 63 días (tasa anualizada ~17) y se activó revisión? ¿Cómo se ajustará el umbral para detectar deterioro en períodos cortos? |
| 84 | Metodología | 2/5 | ¿Se consideró Expected Shortfall (ES) como complemento a LaR? ¿Por qué se descartó si RiskMetrics lo recomienda para capturar riesgo de cola? |
| 85 | Metodología | 2/5 | ¿Se verificó independencia temporal de los flujos de liquidez? ¿Se verificó estacionariedad? ¿Qué ocurre si hay autocorrelación o cambios de régimen no capturados por EWMA? |
| 86 | Metodología | 2/5 | ¿Se realizó análisis de sensibilidad sobre λ (parámetro EWMA), horizonte (30 días) y nivel de confianza (99%)? ¿Cómo cambian los resultados si λ=0.90 o λ=0.97? |
| 87 | Metodología | 2/5 | ¿Cómo se integra el hallazgo de Kupiec p-value=0.021 (rechazo H0) en Q2 2026 en la metodología? ¿Qué cambios se implementarán para evitar subestimación sistemática en períodos de estrés? |
| 88 | Metodología | 2/5 | ¿Se valida que el horizonte de 30 días es suficiente para capturar dinámicas de liquidez en esta cartera? ¿Se comparó con horizontes alternativos (10, 20, 60 días)? |
| 89 | Metodología | 2/5 | ¿Existe documentación de las correlaciones asumidas entre productos? El manual menciona «correlación asumida = 1 en escenario estrés» pero no proporciona evidencia de cómo se estiman o validan estas correlaciones. |
| 90 | Metodología | 2/5 | ¿Existe un log o acta de ejecución mensual del backtesting para los 12 meses anteriores a Q2 2026? Se requiere evidencia de que Kupiec y Christoffersen se ejecutan cada mes, no solo trimestralmente. |
| 91 | Metodología | 2/5 | ¿Cuáles son los p-values de Jarque-Bera y la curtosis observada de los flujos de liquidez? ¿Se rechaza la hipótesis de normalidad? Si es así, ¿cómo se ajusta el modelo para capturar colas gruesas? |
| 92 | Metodología | 2/5 | ¿Por qué el backtesting de Q2 2026 se realizó sobre 63 días en lugar de 250 observaciones? ¿Es una excepción documentada, y si es así, cuál es el impacto en la potencia estadística de las pruebas? |
| 93 | Metodología | 2/5 | ¿Existe un documento de decisión (acta de comité) que muestre cómo los resultados del backtesting (Kupiec p-value=0.021, rechazo de H0) informaron la decisión de recalibración adelantada? ¿Quién aprobó el cambio y cuándo? |
| 94 | Metodología | 2/5 | ¿Se ejecutó el piloto GARCH(1,1) vs EWMA mencionado en las acciones correctivas? ¿Cuáles fueron los resultados y por qué se eligió una metodología sobre la otra? |
| 95 | Metodología | 2/5 | ¿Se implementó Expected Shortfall (ES) como complemento a LaR para capturar riesgo de cola, tal como recomienda RiskMetrics? Si no, ¿cuál es la justificación para no hacerlo? |
| 96 | Metodología | 2/5 | ¿Existen resultados documentados de análisis de sensibilidad del LaR a variaciones en λ (EWMA), horizonte temporal, y nivel de confianza? Si existen, ¿dónde se encuentran y con qué periodicidad se actualizan? |
| 97 | Metodología | 2/5 | ¿Cuáles son los p-valores del test de Jarque-Bera y los valores de curtosis observada en los últimos 250 datos? ¿Se rechaza la hipótesis de normalidad? Si se rechaza, ¿qué correcciones se aplican al modelo? |
| 98 | Metodología | 2/5 | ¿Se ha ejecutado un análisis comparativo EWMA vs GARCH(1,1) con datos históricos? ¿Cuáles son los resultados (AIC, BIC, backtesting Kupiec/Christoffersen para ambos)? ¿Cuándo se completará el piloto mencionado en el informe Q2 2026? |
| 99 | Metodología | 2/5 | ¿Existen escenarios de estrés documentados (p.ej., crisis de tasas de mayo 2026, crisis de crédito, salida masiva de depósitos)? ¿Cuál fue el LaR predicho vs observado en cada escenario? ¿Se documentan en actas de comité? |
| 100 | Metodología | 2/5 | ¿Cuál es el rango de tolerancia aceptable para cambios en LaR ante variaciones en parámetros clave? ¿Existe una matriz de sensibilidad que se revise periódicamente? |
| 101 | Metodología | 2/5 | ¿Se ha validado el supuesto de correlación = 1 en escenario de estrés con datos históricos? ¿Cuál es el impacto en el LaR si se relaja este supuesto? |
| 102 | Gobierno | 2/5 | ¿Existe acta formal firmada del Comité de Riesgo que documente la aprobación del modelo LaR del 2026-01-15? ¿Quiénes fueron los firmantes y qué tiering se asignó en esa acta? |
| 103 | Gobierno | 2/5 | ¿Cuál es el tiering actual asignado al modelo LaR (Tier 1, 2, 3 u otra clasificación)? ¿En qué fecha se asignó y por qué criterios? |
| 104 | Gobierno | 2/5 | ¿Existe acta de actualización del tiering posterior a la aprobación inicial? Si el modelo ha sufrido cambios metodológicos, de volumen o de criticidad, ¿se ha revisado y actualizado el tiering? |
| 105 | Gobierno | 2/5 | ¿El modelo LaR está registrado en el inventario oficial de modelos de la entidad? ¿Cuál es el identificador único del modelo en ese inventario y cuál es su tiering registrado? |
| 106 | Gobierno | 2/5 | ¿Quién es responsable de mantener actualizado el tiering del modelo LaR y con qué frecuencia se revisa (anual, semestral, por evento)? |
| 107 | Gobierno | 2/5 | ¿Existe documentación que justifique por qué se asignó ese tiering específico? (Por ejemplo: criticidad para regulación, volumen de exposición, complejidad metodológica, frecuencia de uso en decisiones de negocio.) |
| 108 | Gobierno | 2/5 | ¿Cuál es el número de registro del modelo LaR en el inventario oficial de modelos de riesgo de la entidad? |
| 109 | Gobierno | 2/5 | ¿Qué tiering ha sido asignado al modelo LaR (Tier 1, 2, 3 u otra clasificación interna) y cuál es la justificación documentada de esa asignación? |
| 110 | Gobierno | 2/5 | ¿Existe un acta formal, firmada por el propietario del modelo (Gerencia de Riesgo de Liquidez) y/o por el comité de riesgo, que certifique la inclusión del modelo en el inventario y la asignación de tiering? |
| 111 | Gobierno | 2/5 | ¿Cuál es la fecha de inclusión del modelo en el inventario y cuándo fue la última actualización del tiering? |
| 112 | Gobierno | 2/5 | ¿El sistema de GRC (herramienta corporativa de gestión de riesgos) contiene un registro activo del modelo LaR con tiering vigente? Si es así, ¿puede proporcionarse un extracto o captura de pantalla que lo demuestre? |
| 113 | Implementación | 2/5 | ¿Se proporcionarán los scripts Python (.py, .ipynb) que implementan el cálculo LaR, la volatilidad EWMA con λ=0.94, y las pruebas de Kupiec y Christoffersen? Sin ellos, no es posible verificar que el código coincida con la especificación metodológica. |
| 114 | Implementación | 2/5 | ¿Existen logs de ejecución real del DAG Airflow (últimas 10 corridas)? ¿Qué muestra el log sobre tiempos de ejecución, fuentes de datos consumidas, y resultados LaR calculados? |
| 115 | Implementación | 2/5 | ¿Se proporcionarán correos de aprobación (de primera línea o Comité de Riesgo) para el paso a producción del modelo? ¿Cuándo se desplegó por primera vez y quién autorizó? |
| 116 | Implementación | 2/5 | ¿Dónde está el Runbook operativo actualizado al 2026-05-30? ¿Qué controles operacionales específicos documenta (p.ej., validación de datos de entrada, reconciliación de resultados, escalada de alertas)? |
| 117 | Implementación | 2/5 | ¿Se puede proporcionar un ejemplo real de los metadatos guardados en una corrida (parámetros, versión de código, hash de datos de entrada)? ¿En qué tabla/archivo se almacenan? |
| 118 | Implementación | 2/5 | ¿Cómo se reconcilian los dos criterios de alerta para backtesting: «excedencias > 5» vs «p-value > 0.05»? ¿Cuál es el criterio operacional que realmente se usa para escalar alertas? |
| 119 | Implementación | 2/5 | ¿Se ejecutó UAT (User Acceptance Testing) antes de pasar a producción? ¿Qué casos de prueba se corrieron y cuáles fueron los resultados? |
| 120 | Implementación | 2/5 | ¿Existe documentación de cambios (change log) que muestre qué versiones del código se han desplegado, cuándo, y qué cambios incluyeron? ¿Cómo se asegura que no hay code drift entre Git y la VM de producción? |
| 121 | Implementación | 2/5 | ¿Quién es el propietario operacional del modelo en producción? ¿Quién monitorea diariamente que el DAG se ejecute a las 07:00 COT y qué hace si falla? |
| 122 | Implementación | 2/5 | ¿Existe correo o acta formal de aprobación de la IMPLEMENTACIÓN técnica del modelo LaR por parte de Riesgo o Tecnología? Si existe, ¿cuál es la fecha y quién la firmó? |
| 123 | Implementación | 2/5 | ¿Cómo se reconcilia la ejecución DIARIA del DAG con el backtesting MENSUAL? ¿Se usan datos diarios o mensuales para el backtesting? ¿Se reporta LaR diariamente o solo al cierre de mes? |
| 124 | Implementación | 2/5 | ¿Se han ejecutado pruebas UAT documentadas antes de pasar el modelo a producción? Si existen, ¿dónde están los casos de prueba, los datos de entrada, los resultados esperados y los resultados observados? |
| 125 | Implementación | 2/5 | ¿Existen ejemplos de logs JSON ejecutados en producción (con datos reales, no sintéticos)? ¿Se ha activado alguna alerta de Slack por LaR > umbral o por falla de fuente? |
| 126 | Implementación | 2/5 | ¿Existe una matriz de trazabilidad que mapee cada parámetro del manual metodológico (λ=0.94, z(99%)=2.326, ventana de 250 obs, etc.) con su valor en el código Python? ¿Dónde se valida que coincidan? |
| 127 | Implementación | 2/5 | ¿Quién es el propietario técnico del código (owner del repo Git)? ¿Existe un SLA de mantenimiento y actualización? |
| 128 | Implementación | 2/5 | ¿Se han ejecutado los tests de Kupiec y Christoffersen con datos reales desde que el modelo está en producción? Si existen resultados, ¿cuáles son los p-values observados y cómo se interpretan contra el umbral de 0.05? |
| 129 | Implementación | 2/5 | ¿Cómo se garantiza que los datos de entrada (Core bancario, SAP Tesorería, Bloomberg) son los especificados en el manual metodológico? ¿Existe validación de esquema o reconciliación documentada? |
| 130 | Implementación | 2/5 | ¿Dónde están los scripts Python (.py, .ipynb) del motor LaR? Se declara que existe un DAG en Airflow y un repositorio Git (`risk-liquidity-models`), pero no se proporciona el código fuente. ¿Puede proporcionarse al menos las funciones principales (cálculo EWMA, cuantil, backtesting)? |
| 131 | Implementación | 2/5 | ¿Existen logs de ejecución del backtesting de Kupiec y Christoffersen? Se declara que se aplica mensualmente, pero no se proporcionan resultados (p-values, número de excepciones observadas, estado OK/ALERTA). ¿Pueden proporcionarse los últimos 3-6 meses de resultados? |
| 132 | Implementación | 2/5 | ¿Hay correos de aprobación o actas de comité que documenten el paso a producción del modelo? El manual metodológico menciona aprobación del Comité de Riesgo el 2026-01-15, pero no se proporciona evidencia de que la implementación haya sido validada y aprobada antes de entrar en producción. |
| 133 | Implementación | 2/5 | ¿Se documentó el análisis de umbrales (¿por qué umbral de alerta en 5 excepciones y no otro?) y el evolutivo histórico del LaR (¿cómo ha evolucionado el estimado en los últimos 12 meses?)? La actividad específicamente pide verificar estos análisis de primera línea. |
| 134 | Implementación | 2/5 | ¿Existe documentación de UAT (User Acceptance Testing)? ¿Se validaron los datos de entrada (fuentes SAP, Bloomberg), los cálculos intermedios (EWMA, volatilidad) y los datos de salida (tabla `lar_daily_estimates`) contra valores esperados? |
| 135 | Implementación | 2/5 | ¿El backtesting se ejecuta automáticamente dentro del DAG de Airflow o es un proceso manual? Si es manual, ¿con qué frecuencia se ejecuta realmente (¿mensual, trimestral, ad-hoc)? |
| 136 | Implementación | 2/5 | ¿Se ha validado la coherencia entre el parámetro λ=0.94 documentado en el manual y el valor implementado en el código? ¿Existen pruebas de sensibilidad que justifiquen esta elección frente a otros valores (0.90, 0.95)? |
| 137 | Implementación | 2/5 | ¿Se han documentado y ejecutado análisis de sensibilidad o escenarios de estrés sobre el modelo LaR? El manual metodológico menciona limitaciones (normalidad, correlación asumida = 1 en estrés), pero no se proporciona evidencia de que se hayan cuantificado sus impactos. |
| 138 | Uso e integración a la gestión | 2/5 | ¿Existen actas de comité ALCO de los últimos 30 días que citen explícitamente corridas del modelo LaR con ID de ejecución? Si existen, ¿cuál es el patrón de frecuencia y qué decisiones se tomaron basadas en el output? |
| 139 | Uso e integración a la gestión | 2/5 | ¿Hay registros operativos (tickets, órdenes de tesorería, confirmaciones de transacción) que tracen decisiones de compra/venta de HQLA a un output específico del modelo LaR? ¿Cómo se documenta esta trazabilidad? |
| 140 | Uso e integración a la gestión | 2/5 | ¿Se ha enviado algún reporte SFC a la Superfinanciera que incluya LaR? Si es así, ¿qué período cubre, qué metodología se reportó, y cómo se integró el output del modelo? |
| 141 | Uso e integración a la gestión | 2/5 | ¿Existen logs de ejecución del DAG de Airflow de los últimos 30 días que demuestren: (a) que la corrida diaria a las 07:00 COT ocurre consistentemente, (b) que no hay fallos no reportados, (c) que los datos se persisten en PostgreSQL? ¿Cuál es la tasa de éxito observada? |
| 142 | Uso e integración a la gestión | 2/5 | ¿Se han disparado alertas por Slack (umbral regulatorio, falla de fuentes, tiempo de ejecución > 15 min) en los últimos 30 días? Si es así, ¿cuántas, cuándo, y qué acciones se tomaron en respuesta? |
| 143 | Uso e integración a la gestión | 2/5 | ¿El modelo LaR está inventariado formalmente en el registro de modelos de riesgo de la institución? ¿Cuál es su estado (desarrollo, piloto, producción)? ¿Cuándo se autorizó su paso a producción? |
| 144 | Uso e integración a la gestión | 2/5 | ¿Existe documentación del alcance original del modelo (fecha de aprobación, usuarios previstos, decisiones que debía soportar)? ¿Se ha verificado que los usos actuales están dentro de ese alcance, o ha habido extensiones no autorizadas? |
| 145 | Uso e integración a la gestión | 2/5 | ¿El dashboard ejecutivo del CFO con alertas amarillas/rojas está activo y siendo consultado? ¿Hay evidencia de que las alertas han disparado acciones (ej., escalamiento a comité de crisis)? |
| 146 | Uso e integración a la gestión | 2/5 | ¿Existe un runbook operativo actualizado que documente qué hacer si el DAG falla, si LaR excede 3 sigma, o si hay inconsistencias entre el output de desarrollo y producción? ¿Quién es responsable de ejecutarlo? |

> ✍️ **Te toca:** depura antes de enviar. Algunas se responderán con un
> documento que ya existe y no llegó a `inputs/` — ésas no son hallazgos,
> son evidencia que faltó aportar.

## 5. Detalle por ámbito

### Documentación  ·  score 2.0

#### 🟠 [2/5] Verifica la existencia de control de cambios/versiones

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verificar la existencia, suficiencia y claridad de un sistema de control de cambios/versiones en la documentación del modelo LaR. Este control es crítico para la trazabilidad, la gobernanza y la auditoría de modelos de riesgo, asegurando que cada cambio metodológico sea documentado, justificado y aprobado antes de su implementación.

**Hallazgo.**

La documentación disponible demuestra que existe un Manual Metodológico LaR (v4.2) y que se menciona una versión anterior (v4.1 implícita en la numeración), pero NO existe evidencia de un sistema formal de control de cambios. El manual menciona aprobación por Comité de Riesgo (2026-01-15) y recalibración anual obligatoria, pero no hay: (1) registro de cambios (changelog) que documente qué cambió entre versiones, cuándo, por qué y quién lo aprobó; (2) trazabilidad de decisiones metodológicas (por ejemplo, por qué λ=0.94 y no otro valor, o por qué se mantiene EWMA cuando el informe Q2 2026 sugiere piloto GARCH(1,1)); (3) evidencia de que los cambios propuestos en el informe de seguimiento (recalibración adelantada, piloto GARCH) fueron formalmente aprobados antes de implementación; (4) control de versiones en el código (no se proporcionó script de cálculo, pero la ausencia de comentarios de versión sería un riesgo adicional). El documento menciona que la recalibración se adelantó al 2026-08-15, pero no hay evidencia de que esa versión recalibrada esté documentada, aprobada y disponible. Esto es una brecha crítica: sin control de cambios, no es posible auditar si el modelo en producción es el que fue aprobado, ni rastrear cuándo y por qué se desviaron de la metodología documentada. Para alcanzar nivel 3 se requeriría: (a) un changelog explícito (fichero o sección del manual) que liste cada versión, fecha, cambios, justificación y aprobador; (b) evidencia de que los cambios propuestos en Q2 2026 fueron formalmente aprobados; (c) confirmación de que la versión recalibrada (post-2026-08-15) está documentada y disponible para auditoría.

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → "Versión: Manual Metodológico LaR v4.2" y "Propietario: BANCO — Gerencia de Riesgo de Liquidez"
>
> Manual_Metodologico_LaR_completo.pdf → "Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria."
>
> informe_seguimiento_Q2_2026.md → "Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo."
>
> No se encontró en el contexto disponible: (1) un registro de cambios (changelog) que documente transiciones entre versiones; (2) acta de aprobación formal de los cambios propuestos en Q2 2026; (3) documentación de la versión recalibrada posterior a 2026-08-15; (4) justificación documentada de por qué se mantiene λ=0.94 o por qué se descartaron alternativas.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Propietario: BANCO — Gerencia de Riesgo de Liquidez»
> - «Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs »
> - «Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). Piloto GARCH(1,1)»

**Preguntas al modelador.**

- [ ] ¿Existe un registro formal de cambios (changelog) que documente todas las versiones del Manual Metodológico LaR, incluyendo fechas, cambios específicos, justificación y aprobador? Si existe, ¿dónde se almacena y cómo se mantiene sincronizado con el manual en producción?
- [ ] ¿Fue formalmente aprobado por el Comité de Riesgo el cambio de recalibración de Q4 a 2026-08-15? ¿Existe acta de esa aprobación?
- [ ] ¿Cuál es el estado actual del piloto GARCH(1,1) propuesto en Q2 2026? ¿Ha sido aprobado? ¿Cuándo se espera que entre en producción? ¿Se actualizará el manual cuando se implemente?
- [ ] ¿Existe un procedimiento documentado que defina cuándo y cómo se deben proponer cambios metodológicos, quién debe aprobarlos, y cómo se comunican e implementan?
- [ ] ¿La versión recalibrada del modelo (post-2026-08-15) está documentada en un manual actualizado (v4.3 o posterior)? Si es así, ¿cuáles fueron los cambios específicos respecto a v4.2?
- [ ] ¿Existe control de versiones en el código de cálculo del modelo (scripts, stored procedures, etc.)? ¿Se etiquetan las versiones de código con las versiones del manual metodológico?

**Recomendación.** Implementar un sistema formal de control de cambios que incluya: (1) un changelog centralizado (fichero o sección del manual) que liste cada versión, fecha de vigencia, cambios específicos, justificación técnica y aprobador; (2) un procedimiento documentado que defina roles (propuesta, revisión técnica, aprobación por Comité, implementación, comunicación); (3) sincronización obligatoria entre versiones del manual y versiones del código en producción (mediante etiquetas de versión en repositorio); (4) un registro de decisiones rechazadas (por ejemplo, por qué se descartó GARCH antes de Q2 2026, si fue considerado); (5) actualización inmediata del manual cuando se aprueben cambios, no retroactivamente. Hasta que esto esté en lugar, no es posible auditar si el modelo en producción es el que fue aprobado, ni rastrear la evolución de las decisiones metodológicas. Esto es un requisito de gobernanza de segundo nivel de defensa y es crítico para la supervisión regulatoria (SR 11-7, Basilea III).

<sub>cobertura documental 100.0% · RAG LaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `0ec6a2184de0`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la inclusión del objetivo, usos y usuarios del modelo

*Control: Verificar la existencia, suficienica y claridad del Manual Metodologico*

**Qué evalúa.** Verificar la existencia, suficiencia y claridad del Manual Metodológico respecto a la inclusión explícita del objetivo, usos y usuarios del modelo LaR. Este es un control de gobernanza fundamental: sin claridad sobre PARA QUÉ sirve el modelo y QUIÉN lo usa, no hay trazabilidad de decisiones ni accountability en su aplicación.

**Hallazgo.**

La documentación disponible demuestra que el Manual Metodológico LaR v4.2 DESCRIBE el objetivo del modelo (estimar máxima pérdida potencial de liquidez a 30 días, NC 99%), pero presenta BRECHAS CRÍTICAS en la especificación de usos y usuarios. El manual declara el objetivo en términos técnicos (§1: 'Estimar la máxima pérdida potencial de liquidez que la entidad puede sufrir en un horizonte de 30 días'), pero NO especifica explícitamente: (1) los USOS CONCRETOS a los que se destina (¿límites de riesgo? ¿reporte regulatorio? ¿decisiones de pricing? ¿stress testing?); (2) los USUARIOS IDENTIFICADOS (¿Comité de Riesgo? ¿Tesorería? ¿Supervisores internos?); (3) la CADENA DE DECISIÓN que depende de este modelo (¿qué acción se toma si LaR excede un umbral?). El Informe de Seguimiento Q2 2026 menciona que 'Se activó revisión metodológica' ante excedencias, pero no documenta QUIÉN activó esa revisión ni CÓMO se conecta con la gobernanza del modelo. El Manual §5 menciona 'Comité de Riesgo' como aprobador, pero no como usuario operativo. Esta ausencia es crítica porque: (a) impide auditar si el modelo se usa para lo que fue diseñado; (b) no hay trazabilidad de quién es responsable de actuar sobre sus resultados; (c) en caso de incumplimiento regulatorio, no hay evidencia de que la entidad haya definido el propósito del modelo de forma que permita supervisión. Para alcanzar puntaje 3, se requiere: documento anexo o sección del manual que liste explícitamente los usos (ej: 'Límite de liquidez diaria', 'Reporte LCR/NSFR', 'Stress testing'), los usuarios por rol (ej: 'Gerencia de Tesorería: monitoreo diario', 'Comité de Riesgo: revisión mensual'), y la cadena de escalamiento (ej: 'Si LaR > umbral X, Tesorería ejecuta plan de contingencia Y'). La cobertura documental es parcial: no se revisó un documento de gobernanza separado que pudiera contener esta información.

**Evidencia citada.**

> manual_metodologico_LaR.md → "## 1. Objetivo del modelo\n\nEstimar la máxima pérdida potencial de liquidez que la entidad puede sufrir en un horizonte de 30 días con un nivel de confianza del 99%, considerando salidas netas de depósitos, uso de líneas comprometidas y estrés de mercado."
>
> manual_metodologico_LaR.md → "## 5. Governance\n\nModelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez."
>
> informe_seguimiento_Q2_2026.md → "Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 1/3) → "**Propietario**: BANCO — Gerencia de Riesgo de Liquidez"

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 1. Objetivo del modelo\n\nEstimar la máxima pérdida potencial de liquidez que»
> - «## 5. Governance\n\nModelo aprobado por el Comité de Riesgo el 2026-01-15. Recal»
> - «## 5. Governance\n\nModelo aprobado por el Comité de Riesgo el 2026-01-15. Recal»
> - «## 1. Objetivo del modelo\n\nEstimar la máxima pérdida potencial de liquidez que»
> - «## 2. Marco teórico\n\nEl modelo LaR se apoya en la metodología VaR paramétrica »

**Preguntas al modelador.**

- [ ] ¿Existe un documento de gobernanza del modelo LaR que especifique explícitamente los USOS CONCRETOS (ej: límites de riesgo diarios, reporte regulatorio, stress testing, decisiones de pricing)? Si existe, ¿por qué no está incluido en la documentación revisada?
- [ ] ¿Quiénes son los USUARIOS OPERATIVOS del modelo (por rol y área)? ¿Tesorería lo consulta diariamente? ¿El Comité de Riesgo lo revisa mensualmente? ¿Hay un registro de quién accede a los resultados y con qué frecuencia?
- [ ] ¿Cuál es la CADENA DE ESCALAMIENTO cuando LaR excede un umbral? El informe Q2 2026 menciona 'Se activó revisión metodológica', pero ¿quién la activó, cuándo, y bajo qué criterio? ¿Existe un procedimiento documentado?
- [ ] ¿Se ha validado que el modelo LaR se usa ÚNICAMENTE para los propósitos para los que fue diseñado, o se ha detectado uso para otros fines (ej: decisiones de límites de crédito, pricing de depósitos) sin documentación de esa extensión?
- [ ] ¿El manual metodológico distingue entre el modelo como herramienta de GESTIÓN INTERNA y como herramienta de REPORTE REGULATORIO (LCR/NSFR)? Si ambos usos coexisten, ¿cómo se asegura coherencia entre supuestos?

**Recomendación.** Elaborar un ANEXO DE GOBERNANZA al Manual Metodológico LaR que incluya: (1) tabla de USOS IDENTIFICADOS con descripción de cada uno (ej: 'Límite de liquidez diaria: máxima salida neta permitida sin activar plan de contingencia'); (2) matriz de USUARIOS POR ROL con frecuencia de consulta y responsabilidades (ej: 'Gerencia de Tesorería: monitoreo diario, escalamiento si LaR > umbral X'); (3) PROCEDIMIENTO DE ESCALAMIENTO con criterios de activación, responsables y plazos (ej: 'Si LaR > 150% del umbral, Gerencia de Riesgo de Liquidez convoca reunión de crisis en 2 horas'); (4) REGISTRO DE CAMBIOS DE USO: si el modelo se extiende a nuevos usos después de su aprobación inicial, documentar la justificación y la aprobación correspondiente. Este anexo debe ser revisado y aprobado por el Comité de Riesgo antes de la próxima recalibración (2026-08-15 según el informe Q2).

<sub>cobertura documental 100.0% · RAG LaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `42e31e6a6d48`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la existencia de control de cambios/versiones

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificar la existencia, suficiencia y claridad de un sistema de control de cambios/versiones en la documentación del modelo LaR. Este control es crítico para garantizar trazabilidad, reproducibilidad y cumplimiento regulatorio (SR 11-7, BCBS 239).

**Hallazgo.**

La documentación disponible demuestra que existe un Manual Metodológico LaR identificado como v4.2, lo que indica la presencia de un esquema de versionado. Sin embargo, el control de cambios está INCOMPLETO y NO SUFICIENTEMENTE DOCUMENTADO. (1) El manual v4.2 NO incluye un registro explícito de cambios (changelog) que especifique qué se modificó, cuándo, por quién y por qué entre v4.1 y v4.2, ni entre versiones anteriores. (2) No existe evidencia de un proceso formal de control de cambios: no hay matriz de cambios, no hay aprobaciones documentadas, no hay trazabilidad de decisiones. (3) El Informe de Seguimiento Q2 2026 menciona 'Recalibración adelantada al 2026-08-15' pero NO especifica si esto genera una nueva versión del manual, cómo se documenta, o cómo se comunica a usuarios. (4) La ausencia de un control de versiones formal crea riesgo de inconsistencia entre la versión en uso, la documentada y la que se ejecuta en código. Para alcanzar puntaje 3, se requeriría: (a) un registro de cambios explícito en el manual (fecha, versión anterior/nueva, descripción del cambio, justificación, aprobador); (b) evidencia de que cada cambio metodológico (ej: cambio de EWMA a GARCH) genera una nueva versión documentada; (c) un proceso de comunicación y control de cambios formalmente descrito en el manual operativo. La cobertura documental es parcial: no se proporcionó un manual operativo separado ni un documento de control de cambios independiente, por lo que existe incertidumbre sobre si estos existen fuera del contexto disponible.

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → 'Versión: Manual Metodológico LaR v4.2' (indica versionado, pero sin registro de cambios)
>
> informe_seguimiento_Q2_2026.md → 'Recalibración adelantada al 2026-08-15 (originalmente Q4)' (cambio metodológico sin trazabilidad de versión)
>
> Manual_Metodologico_LaR_completo.pdf → 'Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria.' (menciona recalibración pero no especifica cómo se documenta el cambio de versión)
>
> No se encontró en el contexto disponible: registro de cambios (changelog), matriz de cambios, aprobaciones de versiones, o proceso formal de control de cambios documentado.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). Piloto GARCH(1,1)»

**Preguntas al modelador.**

- [ ] ¿Existe un documento formal de control de cambios (changelog o matriz de cambios) que registre todas las versiones del modelo LaR desde su aprobación inicial? Si existe, ¿por qué no se incluyó en el contexto de validación?
- [ ] ¿Cuál es el proceso formal para documentar y aprobar cambios metodológicos (ej: cambio de EWMA a GARCH)? ¿Genera automáticamente una nueva versión del manual, o se documenta en un registro separado?
- [ ] ¿El piloto GARCH(1,1) mencionado en el informe Q2 2026 ha sido aprobado formalmente? ¿En qué versión del manual se documentará si es aceptado?
- [ ] ¿Existe un manual operativo separado que describa el proceso de ejecución del modelo, incluyendo el procedimiento de control de cambios? Si existe, ¿cuál es su versión actual y cómo se sincroniza con el manual metodológico?
- [ ] ¿Cómo se comunican los cambios de versión a los usuarios del modelo (comités, áreas de negocio, sistemas)? ¿Existe un registro de distribución de versiones?
- [ ] ¿Por qué el backtesting en Q2 2026 se reporta sobre 63 días de trading en lugar de las 250 observaciones especificadas en el manual? ¿Es una desviación documentada o un cambio no registrado?

**Recomendación.** Implementar un sistema formal de control de cambios que incluya: (1) un registro de cambios (changelog) integrado en el manual metodológico o como documento anexo, con campos obligatorios: versión anterior/nueva, fecha, descripción del cambio, justificación técnica, aprobador, y estado (aprobado/piloto/rechazado); (2) un proceso documentado en el manual operativo que especifique cómo se proponen, aprueban, documentan y comunican cambios metodológicos; (3) una matriz de trazabilidad que vincule cada cambio con la decisión del Comité de Riesgo y con la versión del código que lo implementa; (4) un procedimiento de sincronización entre versiones del manual metodológico, manual operativo y código ejecutable, con auditoría de consistencia al menos trimestral. Hasta que esto esté en lugar, cualquier cambio metodológico (incluyendo el piloto GARCH) debe ser documentado explícitamente como una desviación de v4.2 y no debe considerarse parte de la metodología oficial.

<sub>cobertura documental 100.0% · RAG LaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `1ab98157a559`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la existencia , suficiencia y claridad de la documentación

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Evaluación de la existencia, suficiencia y claridad de la documentación del modelo LaR. Esta actividad es crítica porque la documentación es la base para la auditabilidad, reproducibilidad y gobernanza del modelo; sin ella, no hay forma de verificar que el modelo se implementa como se diseñó ni de detectar desviaciones.

**Hallazgo.**

La documentación del modelo LaR presenta BRECHAS CRÍTICAS que impiden validar su implementación real. Aunque existen manuales metodológicos (v4.2) y reportes de seguimiento, hay tres problemas graves: (1) AUSENCIA DE MANUAL OPERATIVO: no existe documentación que describa paso a paso cómo se ejecuta el modelo en producción, qué sistemas lo alimentan, quién lo ejecuta, con qué frecuencia y cómo se validan los datos de entrada. El manual metodológico describe la teoría pero no la operación. (2) DESCONEXIÓN ENTRE DOCUMENTACIÓN Y EJECUCIÓN: el informe Q2 2026 reporta backtesting con Kupiec y Christoffersen, pero el manual metodológico NO especifica la periodicidad de ejecución de estos tests ni quién es responsable de ejecutarlos. El manual dice «mensualmente» en una sección pero no hay evidencia de que esto ocurra sistemáticamente ni de quién lo supervisa. (3) SUPUESTOS NO VERIFICADOS EN DOCUMENTACIÓN: el manual menciona que se aplica el test de Jarque-Bera para validar normalidad y que se reporta curtosis, pero NO proporciona ni un solo resultado de estos tests en ningún documento. Sin estos resultados, no se puede verificar si el supuesto de normalidad es válido o si el modelo infraestima riesgo extremo como el propio manual reconoce que puede ocurrir. (4) DATOS DE ENTRADA NO DOCUMENTADOS: el informe Q2 2026 menciona que «datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas», pero el manual operativo no existe para documentar cómo se detectan, escalan y resuelven estos problemas de calidad de datos. Para pasar a puntaje 3, se requiere: (a) manual operativo completo con flujos de datos, responsables, frecuencias y controles de calidad; (b) evidencia de ejecución real de backtesting (logs, fechas, resultados) vinculada a responsables; (c) resultados de tests de normalidad (Jarque-Bera, curtosis) en el seguimiento mensual; (d) matriz de responsabilidades clara.

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → "Backtesting realizado con 250 observaciones — mínimo recomendado por Basel."
>
> Manual_Metodologico_LaR_completo.pdf → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente."
>
> Manual_Metodologico_LaR_completo.pdf → "Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para detectar desviaciones de normalidad y colas pesadas). Implicación: No se proporcionan valores específicos de curtosis en el documento."
>
> informe_seguimiento_Q2_2026.md → "Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas."
>
> informe_seguimiento_Q2_2026.md → "Kupiec p-value | 0.021 | > 0.05 | RECHAZO H0"
>
> Manual_Metodologico_LaR_completo.pdf → "Propietario: BANCO — Gerencia de Riesgo de Liquidez."
>
> Manual_Metodologico_LaR_completo.pdf → "Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para det»
> - «Propietario: BANCO — Gerencia de Riesgo de Liquidez.»
> - «Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para det»
> - «| Métrica | Valor | Umbral | Estado | ... | MAPE 30 días | 8.2% | ≤ 10% | OK |»

**Preguntas al modelador.**

- [ ] ¿Existe un manual operativo que describa el flujo de datos de entrada (fuentes, frecuencia, validaciones), el proceso de cálculo (quién, cuándo, con qué herramientas), y el flujo de salida (quién recibe el LaR, para qué decisiones)?
- [ ] ¿Cuál es el histórico completo de resultados de backtesting (Kupiec y Christoffersen) mes a mes desde la implementación del modelo? ¿Quién es responsable de ejecutarlos y de escalar desviaciones?
- [ ] ¿Se han ejecutado tests de Jarque-Bera y se han reportado valores de curtosis en algún período? Si sí, ¿cuáles fueron los resultados y qué acciones se tomaron si la curtosis > 3?
- [ ] ¿Por qué el umbral de alerta en el manual es > 5 excedencias pero el informe Q2 2026 usa ≤ 2? ¿Cuándo se cambió este criterio y por qué no se actualizó el manual?
- [ ] ¿Cómo se detectan, escalan y resuelven problemas de calidad de datos (como el rezago de 2 días en la cuenta corporativa top-10)? ¿Existe un procedimiento documentado?
- [ ] ¿Se ha evaluado formalmente GARCH(1,1) vs EWMA? ¿Cuál es la metodología de comparación, los criterios de decisión, y cuándo se espera completar el piloto?
- [ ] ¿Por qué no se implementa Expected Shortfall (ES) si el manual técnico lo recomienda para capturar pérdidas más allá del VaR?

**Recomendación.** ACCIÓN INMEDIATA (antes de cualquier uso del modelo en decisiones de riesgo): (1) Elaborar y aprobar un MANUAL OPERATIVO que incluya: flujo de datos de entrada con validaciones, responsables, frecuencias, herramientas, criterios de escalamiento de anomalías, y matriz de responsabilidades. (2) Establecer un CALENDARIO DE BACKTESTING VINCULANTE con ejecución mensual documentada (logs, fechas, responsables) y consolidación trimestral en informe de seguimiento. (3) Incluir en el seguimiento mensual RESULTADOS DE TESTS DE NORMALIDAD (Jarque-Bera, curtosis) con interpretación y acciones si se detectan desviaciones. (4) RECONCILIAR el umbral de alerta: actualizar el manual a ≤ 2 excedencias o justificar por qué se cambió y documentar la decisión. (5) Completar y documentar el PILOTO GARCH(1,1) con metodología clara, criterios de decisión, y fecha de conclusión. (6) Evaluar la IMPLEMENTACIÓN DE EXPECTED SHORTFALL como complemento a LaR, dada la limitación conocida de normalidad. PLAZO: 60 días para manual operativo y calendario de backtesting; 90 días para resultados de tests de normalidad integrados en seguimiento.

<sub>cobertura documental 100.0% · RAG LaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `f3fa1d4a0552`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la coherencia del manual de implementación con el manual métodolocios

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Verificar la existencia, suficiencia y claridad del manual de implementación operativa del modelo LaR, y su coherencia con el manual metodológico. Esta actividad es crítica porque un manual operativo deficiente impide reproducir, auditar y controlar la ejecución real del modelo, independientemente de cuán sólida sea su teoría.

**Hallazgo.**

La documentación disponible presenta BRECHAS CRÍTICAS que impiden validar la implementación operativa del modelo LaR. Aunque existe un Manual Metodológico v4.2 que describe la teoría (EWMA con λ=0.94, distribución normal, backtesting con Kupiec y Christoffersen), NO SE ENCONTRÓ un manual operativo que describa paso a paso cómo se ejecuta el modelo en producción. El informe de seguimiento Q2 2026 reporta resultados de backtesting (Kupiec p-value=0.021, Christoffersen p-value=0.15) y menciona acciones correctivas (recalibración, piloto GARCH), pero no existe evidencia de un documento que especifique: (1) quién ejecuta qué, cuándo y con qué herramientas; (2) cómo se ingestan los datos, qué validaciones se aplican, quién autoriza cambios; (3) cómo se documentan y controlan los ajustes manuales; (4) qué ocurre cuando el backtesting falla (como en Q2 2026). El manual metodológico menciona que el backtesting se aplica "mensualmente" y que existe un "umbral de alerta si excedencias observadas > 5", pero el informe de seguimiento reporta 3 excedencias en 63 días (no 250) y activa revisión sin que conste un protocolo documentado de escalada. Esto sugiere que la ejecución operativa se desvía de lo documentado, o que no existe documentación operativa que la rija. Para alcanzar el nivel 3 (cumple parcialmente con brechas no críticas) sería necesario: un manual operativo con flujos de datos, responsables, frecuencias, criterios de validación de datos, y un protocolo de control de cambios. Para el nivel 4 se requeriría además evidencia de que ese manual se ejecuta realmente (logs, auditoría de trazas, actas de comité).

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5."
>
> informe_seguimiento_Q2_2026.md → "Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica."
>
> informe_seguimiento_Q2_2026.md → "Hallazgos: 1. Concentración de excedencias en período de estrés de tasas (mayo 2026). 2. Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). 3. Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas."
>
> informe_seguimiento_Q2_2026.md → "Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo. Automatización de ingesta desde el core bancario — dueño: TI Riesgo."
>
> Manual_Metodologico_LaR_completo.pdf → "Frecuencia de reporte: Cierre mensual"
>
> No se encontró evidencia de un manual operativo que describa el proceso de ejecución, validación de datos, control de cambios, o protocolo de escalada ante fallos de backtesting.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Hallazgos: 1. Concentración de excedencias en período de estrés de tasas (mayo 2»
> - «Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4).»
> - «No se encontró evidencia de un manual operativo que describa el proceso de ejecu»

**Preguntas al modelador.**

- [ ] ¿Existe un manual operativo que describa paso a paso cómo se ejecuta el modelo LaR en producción (ingesta de datos, validaciones, cálculo, reporte, escalada)? Si existe, ¿por qué no está en el contexto disponible?
- [ ] ¿Cuál es el protocolo documentado para cambiar la ventana de backtesting de 250 observaciones mensuales a 63 días? ¿Quién autoriza este cambio y cómo se valida que sigue siendo estadísticamente válido?
- [ ] ¿Se ejecutó el test de Jarque-Bera sobre los flujos de liquidez para validar el supuesto de normalidad? Si sí, ¿cuáles fueron los resultados y qué curtosis se observó?
- [ ] ¿Por qué se eligió EWMA con λ=0.94 sobre GARCH(1,1) u otros métodos de volatilidad? ¿Se realizó un análisis comparativo documentado? ¿Cuándo y por qué se decidió cambiar a GARCH?
- [ ] ¿Existe un protocolo documentado de validación de datos que especifique qué ocurre cuando los datos llegan con rezago (como los 2 días reportados en Q2 2026)? ¿Quién decide si el modelo se ejecuta o se pospone?
- [ ] ¿Cuál es el criterio exacto para activar una revisión metodológica? El manual menciona umbral de >5 excedencias, pero Q2 2026 reporta 3 excedencias y se activó revisión. ¿Existe un protocolo de escalada no documentado?
- [ ] ¿Se ejecutó el test de López (validación de magnitud de pérdidas) en el backtesting de Q2 2026? Si no, ¿por qué no se incluye en el framework de backtesting?
- [ ] ¿Existe un control de cambios documentado para el Manual Metodológico LaR v4.2? ¿Cuándo fue la última actualización y qué cambios se realizaron?

**Recomendación.** Desarrollar e implementar un Manual Operativo LaR que incluya: (1) Flujo de datos: fuentes, frecuencia, validaciones, criterios de aceptación/rechazo, responsables; (2) Proceso de cálculo: quién ejecuta, cuándo, con qué herramientas, cómo se documentan los parámetros usados; (3) Control de cambios: protocolo para modificar parámetros (λ, ventana de backtesting, nivel de confianza), quién autoriza, cómo se valida; (4) Backtesting: especificar si se ejecuta sobre 250 observaciones mensuales o sobre ventanas móviles de 63 días, justificar la elección, incluir test de López además de Kupiec y Christoffersen; (5) Escalada: protocolo documentado de qué ocurre cuando Kupiec rechaza H0, cuándo se activa revisión metodológica, quién decide si se recalibra o se cambia de metodología; (6) Auditoría: logs de ejecución, trazas de datos, actas de decisiones. Además, actualizar el Manual Metodológico para: (a) documentar la justificación de EWMA vs GARCH y el proceso de cambio; (b) reportar resultados de Jarque-Bera y curtosis observada; (c) especificar el protocolo de validación de datos ante retrasos; (d) incluir test de López en el framework de backtesting. Estas acciones son prerequisito para que la segunda línea pueda auditar la implementación real del modelo.

<sub>cobertura documental 100.0% · RAG LaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a8721f6a6016`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar que la documentación contenga los puntos solicitados en el ambito implementación y calidad de datos.

*Control: Vertificar la existencia, sufiencia y claridad del manual de implementación*

**Qué evalúa.** Validación de la existencia, suficiencia y claridad de la documentación del modelo LaR (manual metodológico y operativo) como base para verificar su implementación real. Esta actividad es crítica porque un modelo bien documentado pero no implementado, o implementado de forma distinta a lo documentado, representa un riesgo de gobernanza y control que invalida la confianza en sus resultados.

**Hallazgo.**

La documentación del modelo LaR presenta BRECHAS CRÍTICAS que impiden validar su implementación operativa real. Aunque existen manuales metodológicos (v4.2) y un informe de seguimiento (Q2 2026), la evidencia muestra: (1) DESCONEXIÓN ENTRE MANUAL Y EJECUCIÓN: el manual describe backtesting con Kupiec y Christoffersen como pruebas mensuales/trimestrales, pero el informe de seguimiento reporta resultados de Q2 2026 sin especificar cuándo se ejecutaron, con qué datos, ni quién validó los cálculos. No hay logs de ejecución, scripts de backtesting documentados, ni trazabilidad de los p-values reportados (Kupiec 0.021, Christoffersen 0.15). (2) SUPUESTOS NO VERIFICADOS: el manual menciona test de Jarque-Bera para validar normalidad y reporta curtosis como métrica, pero NO proporciona valores específicos de curtosis observada ni resultados del test. Sin esto, no se puede confirmar si el supuesto de normalidad se sostiene o si el modelo infraestima riesgo extremo como advierte. (3) CALIDAD DE DATOS SIN EVIDENCIA: el informe menciona que «datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas» y se activó automatización, pero no hay documentación de cómo se trató ese rezago en los cálculos de Q2, ni si afectó los p-values reportados. (4) MANUAL OPERATIVO AUSENTE: no existe un documento que describa paso a paso cómo se ejecuta el modelo (ingesta de datos, cálculo de EWMA, aplicación de z-score, generación de reportes, validación de controles). El manual metodológico es teórico; el operativo debería ser prescriptivo. (5) GOVERNANCE INCOMPLETO: el manual aprobado el 2026-01-15 fija recalibración anual, pero el informe de Q2 2026 reporta una recalibración adelantada al 2026-08-15 sin documentar quién autorizó el cambio, qué criterios lo justificaron, ni cómo se validó el piloto GARCH(1,1) antes de implementarlo. Para subir a puntaje 3 se requiere: (a) script de backtesting ejecutable con datos reales y logs de ejecución; (b) valores específicos de curtosis y resultado del test de Jarque-Bera; (c) manual operativo con flujo de datos, fórmulas implementadas y controles; (d) trazabilidad de decisiones de governance (cambios de parámetros, recalibraciones, tratamiento de datos faltantes).

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5."
>
> Manual_Metodologico_LaR_completo.pdf → "Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para detectar desviaciones de normalidad y colas pesadas). Implicación: No se proporcionan valores específicos de curtosis en el documento."
>
> informe_seguimiento_Q2_2026.md → "Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica."
>
> informe_seguimiento_Q2_2026.md → "Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0"
>
> informe_seguimiento_Q2_2026.md → "Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas."
>
> informe_seguimiento_Q2_2026.md → "Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo. Automatización de ingesta desde el core bancario — dueño: TI Riesgo."
>
> Manual_Metodologico_LaR.md → "Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para det»
> - «Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0»
> - «Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4).»
> - «Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0. Christoffersen p-val: 0.15 | > 0.05»
> - «Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para det»
> - «Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4).»
> - «Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0.»

**Preguntas al modelador.**

- [ ] ¿Existe un script ejecutable de backtesting (Kupiec y Christoffersen) con logs de ejecución que muestren cuándo se corrió, con qué datos, y quién validó los resultados? Si existe, ¿dónde está documentado y cómo se integra en el proceso de control mensual?
- [ ] ¿Cuáles son los valores específicos de curtosis observada en los últimos 250 días de datos? ¿Se ejecutó el test de Jarque-Bera y cuál fue el p-value? Si la curtosis > 3, ¿qué acciones se tomaron para ajustar el modelo?
- [ ] ¿Cómo se trató en los cálculos de Q2 2026 el rezago de 2 días en los datos de la cuenta corporativa top-10 durante las 5 fechas identificadas? ¿Se excluyeron esas fechas del backtesting, se imputaron, o se incluyeron con rezago? ¿Afectó esto el p-value de Kupiec reportado (0.021)?
- [ ] ¿Existe un manual operativo (paso a paso) que describa: (a) el flujo de ingesta de datos desde el core bancario, (b) el cálculo de EWMA con λ=0.94, (c) la aplicación del z-score (2.326 para 99%), (d) la generación del reporte de LaR, (e) los controles de validación en cada paso? Si no existe, ¿cuándo se creará?
- [ ] ¿Quién autorizó la recalibración adelantada al 2026-08-15 y con qué criterios se justificó? ¿Se documentó esta decisión en acta del Comité de Riesgo o en algún documento de governance?
- [ ] ¿Se ejecutó un análisis de sensibilidad que compare EWMA vs GARCH(1,1) en datos históricos de esta cartera? ¿Cuáles fueron los resultados del piloto mencionado en el informe de Q2 2026 y cuándo se completará?
- [ ] ¿Por qué no se implementa Expected Shortfall (ES) como complemento a VaR, tal como recomienda RiskMetrics y el propio manual metodológico menciona en limitaciones?

**Recomendación.** CRÍTICA: Antes de cualquier uso operativo del modelo LaR, se requiere: (1) Crear y ejecutar un script de backtesting documentado (Kupiec + Christoffersen) con logs de ejecución, trazabilidad de datos y validación independiente. Integrar en el proceso de control mensual con responsable designado. (2) Documentar y reportar mensualmente: curtosis observada, resultado del test de Jarque-Bera, y análisis de sensibilidad del LaR ante cambios en λ y nivel de confianza. (3) Crear un manual operativo prescriptivo (no solo teórico) que describa cada paso del cálculo, controles de validación, tratamiento de datos faltantes/rezagados, y responsables. (4) Documentar todas las decisiones de governance (cambios de parámetros, recalibraciones, excepciones) en acta del Comité de Riesgo con justificación cuantitativa. (5) Completar el piloto GARCH(1,1) vs EWMA con análisis de backtesting comparativo y documentar la decisión de mantener o cambiar de metodología. (6) Evaluar la implementación de Expected Shortfall como métrica complementaria. Plazo recomendado: 60 días para (1)-(4), 90 días para (5)-(6). Sin estas acciones, el modelo no puede considerarse implementado de forma que permita auditar su cumplimiento con la documentación.

<sub>cobertura documental 100.0% · RAG LaR (5 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `4e891fc1b29d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica la existencia de control de cambios/versiones

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Evaluación de la existencia, suficiencia y claridad de un sistema de control de cambios/versiones en la documentación del modelo LaR. Este control es crítico para garantizar trazabilidad, reproducibilidad y cumplimiento regulatorio (SR 11-7, SS3/17).

**Hallazgo.**

La documentación disponible demuestra la EXISTENCIA de un control de versiones NOMINAL (Manual Metodológico LaR v4.2), pero presenta BRECHAS CRÍTICAS que impiden validar su implementación real y efectividad operativa. (1) El manual v4.2 está identificado por versión, pero NO se proporciona evidencia de: fecha de aprobación específica, historial de cambios previos (v4.1, v4.0, etc.), registro de quién autorizó cada cambio, o log de modificaciones. (2) El informe de seguimiento Q2 2026 menciona «Recalibración adelantada al 2026-08-15» y «Piloto GARCH(1,1) vs EWMA», pero NO hay evidencia de que estos cambios metodológicos hayan sido documentados en una versión posterior del manual, ni de un proceso formal de aprobación antes de su implementación. (3) El manual operativo (si existe) no aparece en el contexto; sin él, no es posible verificar si el control de versiones se extiende a scripts, parámetros de ejecución y datos de entrada. (4) No hay evidencia de un registro de cambios (changelog) que documente: qué cambió, cuándo, por qué, quién lo aprobó, y qué impacto tuvo en resultados de backtesting. Para cumplimiento de segunda línea, esto es insuficiente: un modelo que cambia sin trazabilidad documentada no es auditables. Para subir a puntaje 3, se requiere: (a) historial completo de versiones con fechas y autores; (b) registro de cambios metodológicos con justificación y aprobación; (c) evidencia de que cambios operativos (GARCH, ingesta de datos) fueron formalizados en documentación antes de su uso en producción.

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → "Versión: Manual Metodológico LaR v4.2" y "Propietario: BANCO — Gerencia de Riesgo de Liquidez"
>
> informe_seguimiento_Q2_2026.md → "Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo. Automatización de ingesta desde el core bancario — dueño: TI Riesgo."
>
> Manual_Metodologico_LaR_completo.pdf → "Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria."
>
> No se encontró evidencia en el contexto disponible de: historial de versiones anteriores (v4.1, v4.0, etc.), registro de cambios (changelog), log de aprobaciones, o documentación de cambios metodológicos posteriores a 2026-01-15.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Propietario: BANCO — Gerencia de Riesgo de Liquidez»
> - «Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs »
> - «Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs »
> - «Método: EWMA (Exponentially Weighted Moving Average), Parámetro lambda (λ): 0.94»
> - «No se encontró mención de procedimientos de validación de calidad de datos, trat»

**Preguntas al modelador.**

- [ ] ¿Existe un registro formal de cambios (changelog) que documente todas las versiones del manual desde su creación? Si existe, ¿cuál es su ubicación y formato?
- [ ] ¿Cuál es el proceso formal para aprobar cambios metodológicos (ej: EWMA → GARCH)? ¿Se requiere aprobación del Comité de Riesgo antes de implementación, o después?
- [ ] ¿Se ha documentado en una versión posterior del manual (v4.3 o superior) la evaluación de GARCH(1,1) como alternativa a EWMA? ¿Cuándo se completará esta documentación?
- [ ] ¿Existe un manual operativo separado que describa la ejecución del modelo (scripts, parámetros, datos de entrada)? ¿Tiene su propio control de versiones?
- [ ] ¿Qué procedimiento se sigue cuando se detectan problemas de calidad de datos (como el rezago de 2 días reportado en Q2 2026)? ¿Se documenta en el manual o en un registro de incidentes?
- [ ] ¿El control de versiones cubre solo el manual metodológico, o también los scripts de cálculo, parámetros de configuración y datos de entrada? ¿Cómo se garantiza la coherencia entre versiones de estos componentes?

**Recomendación.** Implementar un sistema formal de control de versiones que incluya: (1) Historial completo de versiones del manual con fechas, autores y resumen de cambios. (2) Registro de cambios (changelog) que documente: qué cambió, por qué, quién lo aprobó, cuándo entró en vigor, y qué impacto tuvo en resultados de backtesting. (3) Proceso de aprobación formal ANTES de implementar cambios metodológicos (no después): cambios deben ser documentados, evaluados (ej: backtesting comparativo) y aprobados por el Comité de Riesgo antes de su uso operativo. (4) Extensión del control de versiones a componentes operativos: scripts, parámetros, datos de entrada, y procedimientos de validación de calidad de datos. (5) Trazabilidad de cambios en backtesting: cuando se cambia metodología, documentar cómo se re-ejecutan las pruebas de Kupiec y Christoffersen con la nueva metodología, y cómo se comparan resultados. (6) Documentación de la evaluación GARCH vs EWMA: incluir en el manual v4.3 (o superior) el análisis comparativo, los resultados de backtesting, y la justificación de la transición. Plazo recomendado: antes de la recalibración de agosto 2026.

<sub>cobertura documental 100.0% · RAG LaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `44d7b3e8cf25`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la existencia, suficiencia y claridad de la documentación

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Evaluación de la existencia, suficiencia y claridad de la documentación del modelo LaR (Liquidity at Risk). Esta actividad es crítica porque la documentación es el único medio verificable para auditar que el modelo se implementa conforme a su diseño y que los controles (backtesting, monitoreo de datos) se ejecutan realmente.

**Hallazgo.**

La documentación del modelo LaR presenta BRECHAS CRÍTICAS que impiden validar su implementación operativa real. Aunque existen manuales metodológicos y un informe de seguimiento Q2 2026, la evidencia muestra: (1) DESCONEXIÓN ENTRE TEORÍA Y EJECUCIÓN: el manual metodológico describe backtesting con Kupiec y Christoffersen, pero el informe de seguimiento reporta resultados de backtesting sin mostrar cómo se ejecutaron, con qué datos, ni cómo se integran en decisiones de governance. El manual afirma «Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente» pero no existe evidencia de scripts, logs de ejecución, ni documentación de los cálculos intermedios. (2) SUPUESTOS NO VERIFICADOS: el manual menciona test de Jarque-Bera para validar normalidad y reporta «curtosis observada» como métrica, pero NO proporciona valores específicos de curtosis ni resultados del test. Sin estos datos, no se puede verificar si el supuesto de normalidad se sostiene realmente. (3) DATOS CON CALIDAD COMPROMETIDA: el informe de seguimiento menciona «Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas» pero no documenta cómo se trató este problema, si se excluyeron esos períodos del backtesting, o si se ajustó la metodología. Esto invalida la comparabilidad de los resultados reportados. (4) FALTA DE TRAZABILIDAD OPERATIVA: no existe documentación que describa paso a paso cómo se ejecuta el modelo (qué sistema, qué frecuencia, quién valida, dónde se almacenan los resultados). El manual operativo no está presente en el contexto. (5) INCONSISTENCIA EN UMBRALES: el manual fija umbral de alerta en «excedencias observadas > 5» para 250 observaciones, pero el informe de seguimiento reporta 3 excedencias en 63 días (no 250) y activa alerta. No se justifica por qué se aplica un criterio diferente. Para subir a puntaje 3 se requiere: (a) documentación operativa paso a paso con evidencia de ejecución (logs, scripts ejecutados, fechas); (b) valores específicos de curtosis y resultado del test de Jarque-Bera; (c) documentación de cómo se trataron los datos con rezago; (d) claridad sobre la ventana de backtesting real vs. la teórica; (e) trazabilidad de cómo los resultados de backtesting llegan a comités de decisión.

**Evidencia citada.**

> Manual_Metodologico_LaR.md → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 1/3) → "Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para detección de colas gruesas). Limitación crítica: Si curtosis > 3, modelo infraestima riesgo extremo; normalidad asumida pero no validada explícitamente en resultados."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 3/3) → "Nota crítica: El documento menciona la métrica pero NO proporciona valores específicos de curtosis ni resultados del test de Jarque-Bera."
>
> informe_seguimiento_Q2_2026.md → "Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica."
>
> informe_seguimiento_Q2_2026.md → "Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas."
>
> informe_seguimiento_Q2_2026.md → "Kupiec p-value: 0.021 | Umbral: > 0.05 | Estado: RECHAZO H0"
>
> Manual_Metodologico_LaR.md → "Backtesting realizado con 250 observaciones — mínimo recomendado por Basel."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para det»
> - «Nota crítica: El documento menciona la métrica pero NO proporciona valores espec»
> - «Kupiec p-value: 0.021 | Umbral: > 0.05 | Estado: RECHAZO H0»
> - «Umbral de alerta si excedencias observadas > 5 [para 250 observaciones]»
> - «Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading... Se »
> - «Nota crítica: El documento menciona la métrica pero NO proporciona valores espec»
> - «Kupiec p-value: 0.021 | Umbral: > 0.05 | Estado: RECHAZO H0»

**Preguntas al modelador.**

- [ ] ¿Existen scripts o logs de ejecución del backtesting de Kupiec y Christoffersen? ¿Dónde se almacenan y con qué frecuencia se ejecutan realmente?
- [ ] ¿Cuáles son los valores específicos de curtosis observada en los últimos 250 observaciones? ¿Cuál fue el resultado del test de Jarque-Bera (estadístico y p-value)?
- [ ] ¿Cómo se trataron los 5 períodos con datos de rezago de 2 días? ¿Se excluyeron del backtesting de Kupiec reportado en Q2 2026?
- [ ] ¿Por qué se activó alerta con 3 excepciones en 63 días si el umbral definido es >5 para 250 observaciones? ¿Existe un criterio escalado para ventanas menores?
- [ ] ¿Existe documentación operativa (manual de procedimientos) que describa paso a paso cómo se ejecuta el modelo, quién lo ejecuta, cuándo, y dónde se almacenan los resultados?
- [ ] ¿Se ha contrastado empíricamente EWMA vs GARCH(1,1) en datos históricos de esta cartera? ¿Cuáles fueron los resultados del piloto mencionado en el informe?
- [ ] ¿Cómo se integran los resultados del backtesting en decisiones de governance? ¿A qué comité llegan, con qué frecuencia, y qué acciones se toman si p-value < 0.05?
- [ ] ¿Se verifica el supuesto de correlación = 1 en escenario de estrés? ¿Existe análisis empírico que lo sustente?

**Recomendación.** Producir documentación operativa completa que incluya: (1) Manual de procedimientos con flujo paso a paso de ejecución del modelo, incluyendo fuentes de datos, transformaciones, cálculos, validaciones y almacenamiento de resultados. (2) Documentación de backtesting con valores específicos de curtosis, resultado del test de Jarque-Bera, y evidencia de que se ejecutan Kupiec y Christoffersen con datos reales (incluir logs de ejecución, fechas, tamaño de muestra usado). (3) Matriz de decisión clara que especifique cómo se escalan los umbrales de alerta a ventanas menores a 250 observaciones, y cómo se integran los resultados en comités. (4) Documentación de tratamiento de datos con rezago: qué períodos se excluyeron, cómo se valida la calidad de datos antes de backtesting. (5) Análisis de sensibilidad comparando EWMA vs GARCH(1,1) con resultados cuantitativos. (6) Justificación documentada de por qué RiskMetrics (diseñado para riesgo de mercado) es apropiado para riesgo de liquidez, o migración a metodología específica para flujos de caja.

<sub>cobertura documental 100.0% · RAG LaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `4b59ee2f37d1`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar que la documentación contengas el seguimiento del modelo y/o monitoreo de calidad de datos, en caso aplique.

*Control: Verifica la existencia, suficiencia y calridad del informe de seguimiento*

**Qué evalúa.** Validación de la existencia, suficiencia y calidad de la documentación de seguimiento y monitoreo del modelo LaR, incluyendo backtesting estadístico y control de calidad de datos. Esta actividad es crítica porque la documentación de seguimiento es el mecanismo de segunda línea que detecta degradación del modelo en producción.

**Hallazgo.**

La documentación presenta BRECHAS CRÍTICAS que impiden validar la implementación operativa del seguimiento. Aunque existen referencias a backtesting (Kupiec, Christoffersen) en el manual metodológico y un informe de seguimiento de Q2 2026, hay contradicciones severas entre lo documentado y lo ejecutado, ausencia de evidencia de ejecución sistemática, y falta de integración del monitoreo de calidad de datos en el proceso de seguimiento. El manual metodológico describe el framework teórico (Kupiec POF, Christoffersen independencia, 250 observaciones) pero el informe de seguimiento reporta solo 63 días de trading en Q2 2026, lo que viola el requisito mínimo de 250 observaciones para validez estadística de ambas pruebas. No existe evidencia de que el test de Jarque-Bera (normalidad) se ejecute o reporte, a pesar de ser documentado como requerido. El monitoreo de calidad de datos (rezagos de 2 días en flujos corporativos) se menciona como hallazgo pero no hay protocolo documentado de cómo se detecta, escala o remedia. Para alcanzar puntaje 3 se requiere: (1) evidencia de ejecución de backtesting con ≥250 observaciones en ventana móvil, (2) reportes mensuales que muestren ambas pruebas (Kupiec + Christoffersen) con p-values e interpretación, (3) protocolo documentado de monitoreo de calidad de datos con umbrales y escalamiento, (4) reconciliación de la contradicción entre 63 días reportados y 250 requeridos.

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → "Prueba de Kupiec (POF — Proportion of Failures) — Propósito: Validar si frecuencia de excepciones observadas coincide con esperada (1% a nivel 99% CL) — Muestra: 250 observaciones — Frecuencia esperada: ~2.5 excedencias en 250 obs (1% de 250) — Aplicación: Trimestral/mensual"
>
> Manual_Metodologico_LaR_completo.pdf → "Prueba de Christoffersen (Independencia) — Propósito: Verificar ausencia de clustering de excepciones — Muestra: 250 observaciones — Hipótesis nula: Independencia temporal de violaciones"
>
> Manual_Metodologico_LaR_completo.pdf → "Test de normalidad: Jarque-Bera — Métrica reportada: Curtosis observada (para detectar desviaciones de normalidad y colas pesadas) — Implicación: No se proporcionan valores específicos de curtosis en el documento"
>
> informe_seguimiento_Q2_2026.md → "Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica."
>
> informe_seguimiento_Q2_2026.md → "Kupiec p-value: 0.021 | Umbral: > 0.05 | Estado: RECHAZO H0"
>
> informe_seguimiento_Q2_2026.md → "Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días de rezago durante 5 fechas."
>
> Manual_Metodologico_LaR_completo.pdf → "Frecuencia de datos: Cierre mensual (explícitamente reportado en notas al pie de todas las secciones)"
>
> Manual_Metodologico_LaR_completo.pdf → "Observaciones: 250 (aproximadamente 10-11 meses de datos mensuales, equivalente a ~20.8 años en frecuencia mensual)"
>
> Manual_Metodologico_LaR_completo.pdf → "Se asume normalidad de retornos: puede subestimar colas gruesas. No captura contagio entre productos (correlación asumida = 1 en escenario estrés). Backtesting realizado con 250 observaciones — mínimo recomendado por Basel."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Prueba de Kupiec (POF — Proportion of Failures) — Propósito: Validar si frecuenc»
> - «Prueba de Christoffersen (Independencia) — Propósito: Verificar ausencia de clus»
> - «Test de normalidad: Jarque-Bera — Métrica reportada: Curtosis observada (para de»
> - «Kupiec p-value: 0.021 | Umbral: > 0.05 | Estado: RECHAZO H0»
> - «Frecuencia de datos: Cierre mensual (explícitamente reportado en notas al pie de»
> - «Observaciones: 250 (aproximadamente 10-11 meses de datos mensuales, equivalente »
> - «Se asume normalidad de retornos: puede subestimar colas gruesas. No captura cont»
> - «Muestra: 250 observaciones — Frecuencia esperada: ~2.5 excedencias en 250 obs (1»
> - «Frecuencia de datos: Cierre mensual (explícitamente reportado en notas al pie de»
> - «Test de normalidad: Jarque-Bera — Métrica reportada: Curtosis observada (para de»
> - «| Métrica | Valor | Umbral | Estado | ... | MAPE 30 días | 8.2% | ≤ 10% | OK |»
> - «No se encontró en el manual metodológico un protocolo documentado de monitoreo d»

**Preguntas al modelador.**

- [ ] ¿Por qué el informe de Q2 2026 reporta backtesting de Kupiec con 63 días de trading cuando el manual especifica 250 observaciones como mínimo? ¿Se ejecutó el test con una ventana móvil de 250 observaciones o se reportó un resultado inválido?
- [ ] ¿Cuál es la frecuencia real de datos utilizada en el modelo: mensual (como declara el manual) o diaria (como sugiere el reporte en 'días de trading')? ¿Cómo se reconcilia esta diferencia?
- [ ] ¿Dónde están los resultados del test de Jarque-Bera y los valores de curtosis observada que el manual declara como métrica de seguimiento? ¿Se ejecutan mensualmente o solo bajo demanda?
- [ ] ¿Existe un protocolo documentado de monitoreo de calidad de datos que especifique: (a) qué métricas se monitorean (rezagos, faltantes, outliers), (b) umbrales de alerta, (c) procedimiento de escalamiento, (d) impacto en la validez del modelo?
- [ ] ¿Cuál fue la acción correctiva específica tomada respecto al rezago de 2 días en datos de la cuenta corporativa top-10? ¿Se excluyeron esas fechas del backtesting? ¿Se ajustó el modelo?
- [ ] ¿El piloto GARCH(1,1) mencionado en acciones correctivas incluye backtesting comparativo (Kupiec + Christoffersen) contra EWMA? ¿Cuándo se espera completar y qué criterios de decisión se aplicarán?
- [ ] ¿Existe un log o registro de ejecución de scripts de backtesting que demuestre que Kupiec y Christoffersen se ejecutan mensualmente como se documenta?
- [ ] ¿Por qué el manual especifica 'Aplicación: Trimestral/mensual' para Kupiec pero el informe reporta resultados solo para Q2 (trimestral)? ¿Se ejecuta mensualmente o no?

**Recomendación.** Para alcanzar cumplimiento (puntaje ≥3), se requiere: (1) Crear un protocolo de seguimiento operativo que especifique: frecuencia de ejecución (mensual vs trimestral), tamaño de ventana móvil (≥250 observaciones), tests a ejecutar (Kupiec POF, Christoffersen independencia, Jarque-Bera normalidad), umbrales de alerta, y procedimiento de escalamiento. (2) Documentar y ejecutar un proceso de monitoreo de calidad de datos con métricas explícitas (rezagos máximos aceptables, % de faltantes, detección de outliers), umbrales de rechazo, y protocolo de remediación. (3) Reconciliar la contradicción entre frecuencia mensual (manual) y diaria (informe) y documentar la decisión. (4) Generar reportes mensuales de backtesting que incluyan: tabla de excepciones observadas vs esperadas, p-values de Kupiec y Christoffersen con interpretación, resultados de Jarque-Bera y curtosis, y acciones correctivas si p-value < 0.05. (5) Crear un log de auditoría que demuestre ejecución sistemática de estos tests. (6) Completar el piloto GARCH(1,1) con backtesting comparativo y documentar criterios de decisión para cambio de metodología. (7) Establecer un comité de revisión (mínimo trimestral) que valide los resultados de seguimiento y apruebe acciones correctivas antes de implementarlas.

<sub>cobertura documental 100.0% · RAG LaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `a85fac6ec33d`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Calidad de datos  ·  score 3.5

#### 🟠 [2/5] Verificar que no exista suficiencia de controles de calidad de datos (integridad)

*Control: El modelo deberá contar con controles de calidad de datos de primera linea sobre los resultados calculados (outliers, missing, duplicados, entre otros)*

**Qué evalúa.** Verificación de suficiencia de controles de calidad de datos de primera línea sobre integridad, completitud y consistencia de inputs del modelo LaR. Este ámbito es crítico porque datos defectuosos invalidan cualquier cálculo posterior, independientemente de la solidez metodológica.

**Hallazgo.**

La documentación describe controles de calidad exhaustivamente en el manual_controles_datos.md, pero la evidencia de EJECUCIÓN REAL y SUFICIENCIA es fragmentaria y contradictoria. El archivo motores_calidad_2026-08-08.xlsx reporta CUATRO FALLOS CRÍTICOS con tolerancia cero: (1) Unicidad Cliente-Cuenta: 0.0836% de incumplimiento (1 de 1196 grupos), (2) Duplicados: 0.4988% (6 filas), (3) Integridad referencial Cliente: 0.0831% (1 cliente huérfano), (4) Rango de Tasa: 0.2519% (3 valores fuera de [0,1]). Todos estos controles están documentados en el manual con tolerancia 0, pero los resultados muestran FALLA en cada uno. Esto indica que: (a) los controles existen en papel pero no se ejecutan con rigor, o (b) se ejecutan pero sus resultados no generan rechazo de datos ni escalamiento, o (c) se ejecutan post-hoc sin impedir que datos defectuosos alimenten el modelo. El perfil_datos_LaR.md menciona 0.4% de missing en flujos imputado con media del mes previo, pero NO se documenta si se ejecutó el test de Little's MCAR para clasificar el patrón de faltantes (recomendación que el propio documento hace pero no evidencia cumplida). No existe evidencia de un script _replica_virf.py o equivalente que automatice y registre la ejecución de estos controles en cada corrida mensual. El manual_controles_datos.md §1 establece que «todo control aquí descrito debe ejecutarse en cada corrida mensual», pero no hay logs, reportes de ejecución, ni trazabilidad de cuándo se corrieron, quién los ejecutó, o qué acción se tomó ante fallos. La brecha entre lo documentado y lo ejecutado es CRÍTICA: un control que no se ejecuta o cuyo resultado no se usa no es un control, es una declaración de intenciones. Para alcanzar puntaje 3 se requeriría: (1) evidencia de ejecución automatizada (script con logs), (2) trazabilidad de cada corrida mensual, (3) documentación de decisiones tomadas ante fallos (rechazo de datos, imputación, escalamiento), (4) verificación de que los datos que alimentan el modelo LaR pasaron efectivamente estos controles. Actualmente hay solo documentación de qué debería hacerse, no prueba de que se haga.

**Evidencia citada.**

> motores_calidad_2026-08-08.xlsx → "Unicidad de Cliente por Cuenta,0.0836,FALLA,0.0,1 de 1196 grupos ['Cuenta'] tienen más de un valor distinto de 'Cliente'."
>
> motores_calidad_2026-08-08.xlsx → "Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas por ['Cuenta', 'Cliente', 'FechaApertura']."
>
> motores_calidad_2026-08-08.xlsx → "Integridad referencial Cliente → maestro de clientes,0.0831,FALLA,0.0,1 de 1203 valores de 'Cliente' no existen en la referencia 'Cliente'."
>
> motores_calidad_2026-08-08.xlsx → "Tasa de interés dentro del rango admisible [0, 1],0.2519,FALLA,0.0,3 valores de 'Tasa' fuera de [0, 1]."
>
> manual_controles_datos.md → "Este documento describe los controles de calidad de datos que se aplican sobre la base `data_subset` antes de alimentar el modelo LaR. Todo control aquí descrito debe ejecutarse en cada corrida mensual."
>
> manual_controles_datos.md → "Tolerancia: 0 casos. Criticidad ALTA." (para Unicidad Cliente por Cuenta)
>
> manual_controles_datos.md → "Tolerancia: 0 registros." (para Ausencia de duplicados)
>
> manual_controles_datos.md → "Tolerancia: 0 casos. Criticidad ALTA." (para Integridad de Cliente contra maestro)
>
> manual_controles_datos.md → "La `Tasa` de interés debe encontrarse entre **0 y 1** (expresada en tanto por uno). Valores fuera de este rango indican error de unidad. Criticidad ALTA."
>
> perfil_datos_LaR.md → "0.4% de missing en flujos de cuentas corporativas — imputado con la media del mes previo (revisar si MCAR o MAR)."
>
> perfil_datos_LaR.md → "Adoptar test formal para clasificar patrón de missing (Little's MCAR test)." (recomendación no evidenciada como ejecutada)

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas p»
> - «Tasa de interés dentro del rango admisible [0, 1],0.2519,FALLA,0.0,3 valores de »
> - «(para Unicidad Cliente por Cuenta) manual_controles_datos.md →»
> - «(para Ausencia de duplicados) manual_controles_datos.md →»
> - «(para Integridad de Cliente contra maestro) manual_controles_datos.md →»
> - «Tolerancia: 0 casos. Criticidad ALTA. [para Unicidad Cliente por Cuenta]»
> - «Tolerancia: 0 registros. [para Ausencia de duplicados]»
> - «Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas p»
> - «Tolerancia: 0 casos. Criticidad ALTA. [para Integridad de Cliente contra maestro»
> - «Tasa de interés dentro del rango admisible [0, 1],0.2519,FALLA,0.0,3 valores de »

**Preguntas al modelador.**

- [ ] ¿Existe un script automatizado (_replica_virf.py o equivalente) que ejecute los controles de calidad de datos en cada corrida mensual? Si existe, ¿cuál es su ubicación y cuándo se ejecutó por última vez?
- [ ] ¿Qué acción se tomó ante cada uno de los cuatro fallos reportados en motores_calidad_2026-08-08.xlsx (Unicidad Cliente, Duplicados, Integridad referencial, Rango de Tasa)? ¿Se rechazaron los registros, se imputaron, o se pasaron al modelo así?
- [ ] ¿Existe un log o reporte de trazabilidad que documente la ejecución de controles de calidad para cada corrida mensual del modelo LaR? ¿Quién ejecuta estos controles y quién aprueba la decisión de pasar datos al modelo?
- [ ] ¿Se ejecutó el test de Little's MCAR sobre los 0.4% de missing en flujos de cuentas corporativas? Si no, ¿cómo se justifica la imputación con media del mes previo?
- [ ] ¿Cuál es la fecha del reporte motores_calidad_2026-08-08.xlsx? ¿Corresponde a la corrida mensual más reciente o es un reporte histórico? ¿Se han subsanado los fallos desde entonces?
- [ ] ¿Existe documentación de cambios o excepciones aprobadas a los umbrales de tolerancia (ej: por qué se aceptó 1 cliente huérfano si la tolerancia es 0)?
- [ ] ¿Se verifica la coherencia entre los datos que pasan los controles de calidad y los datos que efectivamente alimentan el modelo LaR? ¿Hay un punto de control antes de que los datos entren al cálculo de volatilidad EWMA?

**Recomendación.** Implementar un script de control de calidad de datos automatizado y versionado que: (1) ejecute todos los controles definidos en manual_controles_datos.md en cada corrida mensual, (2) genere un reporte de ejecución con timestamp, usuario, y resultado de cada control, (3) rechace automáticamente datos que no cumplan tolerancias cero (Unicidad Cliente, Duplicados, Integridad referencial, Rango de Tasa), (4) escale a Gerencia de Riesgo de Liquidez cualquier fallo en controles ALTA criticidad, (5) documente la decisión tomada (rechazo, imputación, exclusión) y la aprobación correspondiente. Además: (a) ejecutar el test de Little's MCAR sobre los missing values y documentar el patrón antes de cualquier imputación, (b) crear un registro de auditoría que vincule cada corrida del modelo LaR con el reporte de calidad de datos que la precedió, (c) revisar y subsanar los cuatro fallos actuales (1 cliente duplicado, 6 duplicados, 1 cliente huérfano, 3 tasas fuera de rango) antes de la próxima corrida de backtesting.

<sub>cobertura documental 100.0% · RAG LaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `3b3e102790c8`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar la actualización de los inputs

*Control: Revisión de la integridad y consistencias de los inputs*

**Qué evalúa.** Verificación de la integridad, actualización y consistencia de los inputs de datos que alimentan el modelo LaR. Esta actividad es crítica porque datos defectuosos invalidan cualquier cálculo posterior, independientemente de la sofisticación metodológica.

**Hallazgo.**

La documentación describe controles de calidad exhaustivos en el manual_controles_datos.md, pero el reporte de ejecución (motores_calidad_2026-08-08.xlsx) revela FALLOS CRÍTICOS no resueltos que invalidan la integridad de los inputs. El manual establece tolerancia cero para unicidad de Cliente por Cuenta (§2.1), duplicados (§2.3) e integridad referencial (§5.1), pero el reporte muestra: (1) 1 de 1196 grupos de Cuenta con múltiples Clientes (0.0836% incumplimiento, estado FALLA); (2) 6 filas duplicadas por combinación Cuenta+Cliente+FechaApertura (0.4988% incumplimiento, estado FALLA); (3) 1 de 1203 valores de Cliente huérfanos en maestro (0.0831% incumplimiento, estado FALLA); (4) 3 valores de Tasa fuera del rango [0,1] (0.2519% incumplimiento, estado FALLA). Aunque los porcentajes son bajos, el manual_controles_datos.md es explícito: «Tolerancia: 0 casos» para estas tres categorías (CRITICIDAD ALTA). El reporte no documenta acciones correctivas, exclusión de registros defectuosos, ni impacto en el cálculo de LaR. El perfil_datos_LaR.md menciona que 0.4% de missing en flujos fue «imputado con la media del mes previo» sin clasificación formal del patrón (MCAR/MAR/MNAR), lo que viola el principio de trazabilidad. No existe evidencia de un script _replica_virf.py o equivalente que permita auditar la lógica de control de datos de forma independiente. El manual_controles_datos.md §6.1 exige «coherencia manual vs. script» pero no se proporciona el script de extracción ni su alineación con el manual. Sin resolución documentada de estos fallos y sin script de control auditable, no puede afirmarse que los inputs están validados para alimentar el modelo.

**Evidencia citada.**

> motores_calidad_2026-08-08.xlsx → "Unicidad de Cliente por Cuenta,0.0836,FALLA,0.0,1 de 1196 grupos ['Cuenta'] tienen más de un valor distinto de 'Cliente'."
>
> motores_calidad_2026-08-08.xlsx → "Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas por ['Cuenta', 'Cliente', 'FechaApertura']."
>
> motores_calidad_2026-08-08.xlsx → "Integridad referencial Cliente → maestro de clientes,0.0831,FALLA,0.0,1 de 1203 valores de 'Cliente' no existen en la referencia 'Cliente'."
>
> motores_calidad_2026-08-08.xlsx → "Tasa de interés dentro del rango admisible [0, 1],0.2519,FALLA,0.0,3 valores de 'Tasa' fuera de [0, 1]."
>
> manual_controles_datos.md → "### 2.1 Unicidad Cliente por Cuenta\nCada `Cuenta` debe estar asociada a un único `Cliente`. La existencia de una cuenta con más de un cliente indica un problema de integración entre el core bancario y el sistema de tesorería. **Tolerancia: 0 casos.** Criticidad ALTA."
>
> manual_controles_datos.md → "### 2.3 Ausencia de duplicados\nNo deben existir registros completamente duplicados en la base. Se verifica sobre la combinación `Cuenta` + `FechaApertura`. **Tolerancia: 0 registros.**"
>
> manual_controles_datos.md → "### 5.1 Integridad de Cliente contra maestro\nTodo `Cliente` presente en `data_subset` debe existir en el maestro de clientes `maestro_clientes`. Los clientes huérfanos indican desincronización entre sistemas. **Tolerancia: 0 casos.** Criticidad ALTA."
>
> manual_controles_datos.md → "### 4.1 Rango válido de Tasa\nLa `Tasa` de interés debe encontrarse entre **0 y 1** (expresada en tanto por uno). Valores fuera de este rango indican error de unidad. Criticidad ALTA."
>
> perfil_datos_LaR.md → "0.4% de missing en flujos de cuentas corporativas — imputado con la media del mes previo (revisar si MCAR o MAR)."
>
> manual_controles_datos.md → "### 6.1 Coherencia manual vs. script\nEl manual de extracción de datos debe describir origen, universo, variables, transformaciones y controles. El script de extracción debe estar alineado con lo descrito en el manual. Se revisa manualmente en cada validación anual. Criticidad ALTA."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas p»
> - «Tasa de interés dentro del rango admisible [0, 1],0.2519,FALLA,0.0,3 valores de »
> - «### 2.1 Unicidad Cliente por Cuenta\nCada `Cuenta` debe estar asociada a un únic»
> - «### 2.3 Ausencia de duplicados\nNo deben existir registros completamente duplica»
> - «### 5.1 Integridad de Cliente contra maestro\nTodo `Cliente` presente en `data_s»
> - «### 4.1 Rango válido de Tasa\nLa `Tasa` de interés debe encontrarse entre **0 y »
> - «### 6.1 Coherencia manual vs. script\nEl manual de extracción de datos debe desc»
> - «**Tolerancia: 0 casos.** Criticidad ALTA. [para Unicidad Cliente por Cuenta, Int»
> - «Unicidad de Cliente por Cuenta,0.0836,FALLA,0.0 | Integridad referencial Cliente»
> - «### 2.3 Ausencia de duplicados\nNo deben existir registros completamente duplica»
> - «Ausencia de filas duplicadas en la cartera,0.4988,FALLA,0.0,6 filas duplicadas p»
> - «### 3.1 Valores faltantes en Tasa\nLa columna `Tasa` no debe presentar valores n»

**Preguntas al modelador.**

- [ ] ¿Existe un script de extracción y control de datos (_replica_virf.py o equivalente) que implemente la lógica descrita en manual_controles_datos.md? Si existe, ¿cuál es su versión, fecha de última ejecución y resultados?
- [ ] ¿Cuál fue la acción correctiva tomada para los 1 caso de unicidad violada, 6 duplicados, 1 cliente huérfano y 3 tasas fuera de rango? ¿Fueron excluidos del dataset antes del cálculo de LaR, o se mantuvieron con alguna justificación documentada?
- [ ] ¿Se ejecutó el test de Little (MCAR test) sobre los 0.4% de missing en flujos antes de imputar con media del mes previo? ¿Qué justificación técnica respalda la elección de media vs. mediana vs. forward-fill?
- [ ] ¿Existe un log de auditoría que registre cuándo se ejecutaron los controles de calidad (motores_calidad_2026-08-08.xlsx), quién los ejecutó, y qué versión del dataset se utilizó?
- [ ] ¿El dataset que alimentó el cálculo de LaR es el mismo que se reporta en motores_calidad_2026-08-08.xlsx, o se aplicaron transformaciones posteriores? Si es distinto, ¿cuál es la trazabilidad?
- [ ] ¿Se documentó en acta de Comité de Riesgo la aceptación de los fallos de calidad de datos (FALLA en 4 controles) como riesgo conocido del modelo?

**Recomendación.** Antes de validar el modelo LaR como un todo, es OBLIGATORIO: (1) Generar o proporcionar el script de control de datos (_replica_virf.py) con trazabilidad de versión y fecha de ejecución. (2) Documentar la resolución de cada FALLA en motores_calidad_2026-08-08.xlsx: exclusión de registros defectuosos, imputación justificada, o aceptación explícita del riesgo con aprobación de Comité. (3) Ejecutar test de Little sobre missing values y documentar el patrón (MCAR/MAR/MNAR) antes de cualquier imputación. (4) Generar un reporte de trazabilidad que vincule el dataset utilizado en el cálculo de LaR con el reporte de calidad de datos, certificando que los defectos conocidos fueron tratados. (5) Incluir en el manual_controles_datos.md una sección de «Resolución de Incidencias» que describa el flujo de escalado y corrección cuando un control falla. Sin estas acciones, la validación de inputs no puede considerarse completa, y cualquier resultado de LaR derivado de estos datos queda bajo sospecha de integridad.

<sub>cobertura documental 100.0% · RAG LaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `fbb7ce7b383d`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] [Motor de la entidad] Unicidad de Cliente por Cuenta

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Unicidad de Cliente por Cuenta

**Hallazgo.**

1 de 1196 grupos ['Cuenta'] tienen más de un valor distinto de 'Cliente'. 0.08 % de incumplimiento medido por el motor. Tolerancia CERO declarada: el tope del puntaje baja a 3 — sobre tolerancia cero, la magnitud no atenúa haberla superado.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] [Motor de la entidad] Ausencia de filas duplicadas en la cartera

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Ausencia de filas duplicadas en la cartera

**Hallazgo.**

6 filas duplicadas por ['Cuenta', 'Cliente', 'FechaApertura']. 0.50 % de incumplimiento medido por el motor. Tolerancia CERO declarada: el tope del puntaje baja a 3 — sobre tolerancia cero, la magnitud no atenúa haberla superado.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] [Motor de la entidad] Integridad referencial Cliente → maestro de clientes

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Integridad referencial Cliente → maestro de clientes

**Hallazgo.**

1 de 1203 valores de 'Cliente' no existen en la referencia 'Cliente'. 0.08 % de incumplimiento medido por el motor. Tolerancia CERO declarada: el tope del puntaje baja a 3 — sobre tolerancia cero, la magnitud no atenúa haberla superado.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟡 [3/5] [Motor de la entidad] Tasa de interés dentro del rango admisible [0, 1]

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Tasa de interés dentro del rango admisible [0, 1]

**Hallazgo.**

3 valores de 'Tasa' fuera de [0, 1]. 0.25 % de incumplimiento medido por el motor. Tolerancia CERO declarada: el tope del puntaje baja a 3 — sobre tolerancia cero, la magnitud no atenúa haberla superado.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [4/5] [Motor de la entidad] Valores atípicos en la tasa de interés

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Valores atípicos en la tasa de interés

**Hallazgo.**

3 de 1191 valores de 'Tasa' fuera del rango IQR [-0.06135, 0.2203]. 0.25 % de incumplimiento medido por el motor.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] [Motor de la entidad] Completitud de FechaVencimiento

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Completitud de FechaVencimiento

**Hallazgo.**

0 valores nulos sobre 1203 celdas evaluadas. 0.00 % de incumplimiento medido por el motor.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] [Motor de la entidad] Tipo de dato de FechaApertura (fecha válida)

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Tipo de dato de FechaApertura (fecha válida)

**Hallazgo.**

0 de 1203 valores no son convertibles a fecha (FechaApertura: 0/1203). 0.00 % de incumplimiento medido por el motor.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### 🟢 [5/5] [Motor de la entidad] Coherencia FechaVencimiento > FechaApertura

*Control: Motores de calidad de datos de la entidad*

**Qué evalúa.** Coherencia FechaVencimiento > FechaApertura

**Hallazgo.**

0 operación(es) con vencimiento anterior o igual a la apertura. Sin incidencias. 0.00 % de incumplimiento medido por el motor.

**Evidencia citada.**

_Sin evidencia citada._

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_01 — Valida que el manual describa origen, universo, variables, transformaciones y contrles; y que el…

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** EVALUACIÓN NO REALIZADA — fallo técnico

**Hallazgo.**

Este control NO pudo evaluarse. Motivo: No se pudo interpretar la respuesta del modelo (JSON inválido). La evidencia SÍ estaba disponible: es un fallo técnico, no una falta de documentación. Re-ejecutar. No se asignó puntaje para no contaminar el dictamen con un valor inventado.

**Evidencia citada.**

_Sin evidencia citada._

<sub>prompt `a6c6b136e9a2`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_02 — Valida la unicidad Cliente por Cuenta en la base usada por el proceso

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad Cliente por Cuenta en la base usada por el proceso

**Hallazgo.**

La documentación proporcionada corresponde al Manual Metodológico LaR v4.2 y presenta deficiencias críticas de estructura y completitud. Se observa repetición masiva de párrafos idénticos (texto boilerplate) sin variación de contenido entre secciones 1-5, lo que sugiere un documento de plantilla no finalizado o con errores de compilación. Las tablas de backtesting (Tablas 1.1 a 5.1) muestran indicadores genéricos (Indicador X.0 a X.17) con valores incrementales (0.0000 a 0.1700) y umbrales uniformes (≤0.0500), pero carecen de contexto interpretativo, definiciones de métricas, y especificación de qué representa cada indicador. Crítico: NO EXISTE EVIDENCIA DE SCRIPT/CÓDIGO que permita validar la unicidad Cliente-Cuenta en la base de datos operativa, que es el control específico a evaluar. Sin código ejecutable, no es posible verificar si el proceso automatizado detecta duplicados, valida integridad referencial, o genera reportes de excepciones.

6 hallazgo(s) del control automático (3 critica, 3 moderada), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Proporcionar script SQL, Python o equivalente que implemente la validación de unicidad. Debe incluir: (a) consulta que identifique duplicados Cliente-Cuenta, (b) lógica de resolución de conflictos, (c) reporte de excepciones con timestamp y usuario, (d) frecuencia de ejecución. Revisar y reescribir la documentación para: (a) eliminar redundancias, (b) especificar explícitamente qué indicadores miden unicidad vs. otros aspectos del modelo LaR, (c) documentar la relación entre backtesting de LaR y validación de integridad de datos maestros. Confirmar si estas tablas corresponden a datos reales o son ejemplos de plantilla. Si son reales, investigar por qué el patrón es tan regular. Proporcionar: (a) fecha de cierre de datos, (b) población de clientes y cuentas validadas, (c) número de duplicados detectados, (d) p-values de Kupiec y Christoffersen con interpretación. Documentar matriz de impacto: población total, duplicados por tipo (cliente duplicado, cuenta duplicada, ambos), % de cobertura validada, y efecto en métricas de riesgo de liquidez. Incluir trazabilidad de datos desde fuente hasta modelo LaR. Definir política de control: frecuencia mínima (recomendado: diaria o en tiempo real), SLA de resolución (ej: 24 horas), matriz RACI, y protocolo de escalamiento. Documentar en procedimiento operativo separado del manual metodológico. Aclarar alcance: (a) ¿es validación de datos maestros previa a LaR?, (b) ¿es validación dentro del proceso LaR?, (c) ¿es control de segunda línea sobre integridad de base de datos?. Documentar en matriz de controles con referencia a SR 11-7 (validación de modelos) o SS3/17 (calidad de datos).

<sub>prompt `63e56913ddb8`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_03 — Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura

**Hallazgo.**

La documentación proporcionada corresponde a un Manual Metodológico LaR v4.2 que describe un modelo de Riesgo de Liquidez con horizonte de 30 días, nivel de confianza 99%, volatilidad EWMA (λ=0.94) y backtesting mediante pruebas de Kupiec (POF) y Christoffersen. Sin embargo, el documento presenta deficiencias críticas de estructura y completitud: (1) repetición masiva de párrafos idénticos sin contenido adicional, (2) tablas de backtesting incompletas (Tabla 4.1 sin datos), (3) ausencia total de especificación técnica sobre el control solicitado (unicidad de FechaVencimiento por combinación Cuenta+FechaApertura), y (4) no se proporciona script/código de implementación. La evidencia no permite validar si el control de integridad de datos está implementado, documentado o auditado conforme a SR 11-7 o SS3/17.

6 hallazgo(s) del control automático (3 critica, 3 moderada), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Proporcionar documentación explícita del control de unicidad: (a) especificación funcional del validador, (b) lógica de implementación en código, (c) frecuencia de ejecución, (d) matriz de responsabilidades (propietario, auditor, operador), (e) evidencia de pruebas unitarias e integración. Solicitar versión íntegra y validada del manual. Verificar: (1) control de cambios (fecha, autor, aprobación), (2) número de versión consistente, (3) completitud de todas las tablas, (4) ausencia de duplicados. Implementar revisión de calidad documental previa a circulación. Proporcionar: (1) código fuente del validador (SQL, Python, R o lenguaje usado), (2) logs de ejecución últimos 3 meses, (3) matriz de excepciones aprobadas, (4) evidencia de testing (casos de prueba, resultados). Solicitar: (1) estadísticas de backtesting completas (p-value Kupiec, estadístico Christoffersen, número de excepciones observadas vs. esperadas), (2) serie temporal de excepciones (250 observaciones), (3) gráficos de dispersión P&L vs. LaR, (4) análisis de independencia de excepciones. Documentar: (1) mapeo SR 11-7 Sección 4 (Model Risk Governance) a controles específicos, (2) evidencia de aprobación formal del modelo y sus validadores, (3) declaración de independencia del auditor de modelos, (4) frecuencia de revisión (anual mínimo per SR 11-7). Incluir en reporte de backtesting: (1) estadístico Jarque-Bera y p-value, (2) curtosis y asimetría observadas, (3) gráfico Q-Q plot, (4) análisis de colas (tail risk), (5) consideración de modelos alternativos si normalidad rechazada (ej: t-Student, EVT).

<sub>prompt `7d778faec328`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Control_04 — Valida la unicidad de Tasa de Interes por Cuenta

> No se pudo evaluar: Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.. Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Controles Automáticos de Calidad de Datos*

**Qué evalúa.** Valida la unicidad de Tasa de Interes por Cuenta

**Hallazgo.**

La evidencia proporcionada corresponde a un Manual Metodológico LaR v4.2 de la Gerencia de Riesgo de Liquidez, que describe un modelo de estimación de pérdida potencial de liquidez con horizonte de 30 días y nivel de confianza del 99%. El documento presenta repeticiones extensivas del mismo párrafo metodológico y tablas de backtesting con indicadores numéricos. Sin embargo, NO EXISTE EVIDENCIA EXPLÍCITA relacionada con el control solicitado: 'Validación de la unicidad de Tasa de Interés por Cuenta'. El manual aborda aspectos de volatilidad EWMA, pruebas de Kupiec y Christoffersen, pero no contiene especificaciones, reglas de negocio, criterios de validación, ni resultados de pruebas sobre tasas de interés por cuenta. Adicionalmente, NO SE PROPORCIONÓ SCRIPT/CÓDIGO para evaluar la implementación técnica del control.

3 hallazgo(s) del control automático (3 critica), detallados a continuación.

**Evidencia citada.**

_Sin evidencia citada._

**Recomendación.** Proporcionar documentación específica del control: (1) Especificación funcional del control de unicidad de Tasa de Interés por Cuenta; (2) Reglas de negocio que definen qué constituye una 'tasa única' por cuenta; (3) Criterios de validación y umbrales de tolerancia; (4) Resultados de pruebas unitarias, integración y regresión; (5) Evidencia de ejecución del control en ambiente productivo. Entregar: (1) Script/código SQL o procedimiento almacenado que implementa la validación; (2) Logs de ejecución del control con timestamps y resultados; (3) Matriz de trazabilidad entre especificación y código; (4) Evidencia de revisión de código por segunda línea. Confirmar con el propietario del control: (1) Identificación correcta del control a auditar; (2) Ubicación de la documentación y código asociados; (3) Responsable técnico y de negocio; (4) Fecha de última revisión y certificación del control.

<sub>prompt `ba0ee936a184`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Metodología  ·  score 2.0

#### 🟠 [2/5] Existencia de buenas prácticas en el enfoque metodológico

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** Evaluación de la justificación metodológica del modelo LaR: validación de la elección del enfoque paramétrico EWMA, verificación de supuestos distribucionales, y demostración de que el backtesting ejecutado sostiene la idoneidad del modelo para el horizonte y nivel de confianza especificados.

**Hallazgo.**

La documentación describe la metodología LaR con precisión formal pero FALLA en justificar las decisiones metodológicas clave y en demostrar que los supuestos han sido validados empíricamente. (1) El manual declara normalidad de retornos como supuesto base y menciona el test de Jarque-Bera, pero NO proporciona p-valores, resultados de rechazo/aceptación, ni curtosis observada — sin estas cifras, la afirmación de que se validó la normalidad es una declaración no verificada. (2) La elección de EWMA con λ=0.94 se justifica únicamente como «conforme a RiskMetrics» sin argumentar por qué este parámetro es adecuado para flujos de liquidez (que pueden tener dinámicas distintas a retornos de mercado) ni por qué no se consideró GARCH(1,1) como alternativa — el informe Q2 2026 menciona un piloto GARCH(1,1) como acción correctiva, lo que sugiere que la elección original no fue suficientemente justificada. (3) El backtesting reportado en Q2 2026 muestra Kupiec p-value = 0.021 (RECHAZO H0 al 5%), lo que indica que el modelo subestimó el riesgo en ese período, pero la documentación metodológica NO integra este hallazgo ni explica cómo la metodología se ajustará para evitar futuras subestimaciones sistemáticas. (4) El manual fija un umbral de alerta en >5 excedencias en 250 días, pero Q2 2026 registró 3 excedencias en 63 días (tasa anualizada ~17 excedencias/año vs. esperadas ~2.5), lo que sugiere que el umbral de alerta es insuficiente para detectar deterioro en tiempo real. (5) No existe análisis de sensibilidad documentado que justifique la robustez del modelo ante cambios en λ, en el horizonte de 30 días, o en el nivel de confianza del 99%. Para alcanzar cumplimiento parcial con brechas no críticas (nivel 3), se requeriría: (a) reporte explícito de p-valores de Jarque-Bera y curtosis observada con conclusión clara sobre validez de normalidad; (b) justificación documentada de por qué EWMA es superior a GARCH(1,1) para esta cartera, o reconocimiento explícito de que es una aproximación con limitaciones conocidas; (c) integración del hallazgo de Kupiec p=0.021 en la metodología con plan de remediación; (d) análisis de sensibilidad sobre parámetros clave.

**Evidencia citada.**

> Manual_Metodologico_LaR.md → "Se asume normalidad de retornos: puede subestimar colas gruesas."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 1/3) → "Test de validación: Jarque-Bera. Métrica reportada: Curtosis observada (para detección de colas gruesas). Limitación crítica: Si curtosis > 3, modelo infraestima riesgo extremo; normalidad asumida pero no validada explícitamente en resultados."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 2/3) → "Nota crítica: El documento menciona la métrica pero NO proporciona valores específicos de curtosis ni resultados del test de Jarque-Bera."
>
> Manual_Metodologico_LaR.md → "Estimador de volatilidad: EWMA con λ = 0.94 (RiskMetrics)."
>
> riskmetrics_summary.md → "Limitaciones conocidas: Colas gruesas y curtosis: la Normal subestima eventos extremos. Correlaciones inestables en régimen de estrés. Recomendación: complementar con Expected Shortfall (ES) — captura pérdida esperada más allá del VaR."
>
> informe_seguimiento_Q2_2026.md → "Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0. Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo."
>
> Manual_Metodologico_LaR.md → "Backtesting realizado con 250 observaciones — mínimo recomendado por Basel. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5."
>
> informe_seguimiento_Q2_2026.md → "Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63)."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Test de validación: Jarque-Bera. Métrica reportada: Curtosis observada (para det»
> - «Nota crítica: El documento menciona la métrica pero NO proporciona valores espec»
> - «Limitaciones conocidas: Colas gruesas y curtosis: la Normal subestima eventos ex»
> - «Kupiec p-value: 0.021 | > 0.05 | RECHAZO H0. Volatilidad EWMA subestimada — cons»
> - «Backtesting realizado con 250 observaciones — mínimo recomendado por Basel. Exce»
> - «Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1). Piloto GARCH(1,1)»
> - «Limitación crítica: Si curtosis > 3, modelo infraestima riesgo extremo; normalid»
> - «Nota crítica: El documento menciona la métrica pero NO proporciona valores espec»

**Preguntas al modelador.**

- [ ] ¿Cuáles son los p-valores específicos del test de Jarque-Bera y los valores de curtosis observada para la cartera de flujos de liquidez? ¿Se rechaza la hipótesis de normalidad?
- [ ] ¿Se realizó un análisis comparativo formal entre EWMA (λ=0.94) y GARCH(1,1) ex-ante a la implementación? ¿Con qué criterios se descartó GARCH(1,1) en la metodología original?
- [ ] ¿Por qué el umbral de alerta se fija en >5 excedencias (en 250 días) cuando Q2 2026 mostró 3 excedencias en 63 días (tasa anualizada ~17) y se activó revisión? ¿Cómo se ajustará el umbral para detectar deterioro en períodos cortos?
- [ ] ¿Se consideró Expected Shortfall (ES) como complemento a LaR? ¿Por qué se descartó si RiskMetrics lo recomienda para capturar riesgo de cola?
- [ ] ¿Se verificó independencia temporal de los flujos de liquidez? ¿Se verificó estacionariedad? ¿Qué ocurre si hay autocorrelación o cambios de régimen no capturados por EWMA?
- [ ] ¿Se realizó análisis de sensibilidad sobre λ (parámetro EWMA), horizonte (30 días) y nivel de confianza (99%)? ¿Cómo cambian los resultados si λ=0.90 o λ=0.97?
- [ ] ¿Cómo se integra el hallazgo de Kupiec p-value=0.021 (rechazo H0) en Q2 2026 en la metodología? ¿Qué cambios se implementarán para evitar subestimación sistemática en períodos de estrés?
- [ ] ¿Se valida que el horizonte de 30 días es suficiente para capturar dinámicas de liquidez en esta cartera? ¿Se comparó con horizontes alternativos (10, 20, 60 días)?
- [ ] ¿Existe documentación de las correlaciones asumidas entre productos? El manual menciona «correlación asumida = 1 en escenario estrés» pero no proporciona evidencia de cómo se estiman o validan estas correlaciones.

**Recomendación.** Requerir al equipo de Riesgo de Liquidez que: (1) Documente explícitamente los p-valores de Jarque-Bera y curtosis observada con conclusión clara sobre validez de normalidad; si se rechaza normalidad, justificar por qué se sigue usando z(99%) o proponer alternativa (ej. distribución t, simulación histórica). (2) Realice análisis comparativo formal EWMA vs GARCH(1,1) con criterios de selección documentados (ej. AIC, BIC, backtesting Kupiec/Christoffersen en ventanas de estrés); si GARCH(1,1) es superior, implementar como metodología base o como modelo alternativo con governance clara. (3) Revise el umbral de alerta: cambiar de conteo absoluto (>5 en 250 días) a tasa dinámica (ej. >3 excedencias en 63 días consecutivos) o a test de Christoffersen para detectar clustering. (4) Integre el hallazgo de Kupiec p=0.021 en la metodología: documentar plan de remediación (ej. ajuste de λ, cambio a GARCH, inclusión de ES) con cronograma y responsables. (5) Realice análisis de sensibilidad sobre λ, horizonte y nivel de confianza; documentar impacto en decisiones de gestión. (6) Considerar Expected Shortfall como complemento a LaR para capturar riesgo de cola, con justificación de por qué se descartó o se implementa. Plazo: antes de la recalibración adelantada del 2026-08-15.

<sub>cobertura documental 100.0% · RAG LaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `0faef06adb9a`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisión de backtesting del modelo, en caso exista, de lo contrario solicitar planificación

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la existencia, ejecución y justificación del backtesting del modelo LaR. Esta actividad es crítica porque el backtesting es la única prueba empírica de que el modelo predice correctamente el riesgo de liquidez; sin él, la metodología permanece no validada.

**Hallazgo.**

La documentación DECLARA backtesting pero NO DEMUESTRA su ejecución sistemática ni su integración en la gobernanza del modelo. Se identifican brechas críticas que impiden considerar el backtesting como operativo y confiable. (1) El informe Q2 2026 reporta resultados puntuales (Kupiec p-value=0.021, Christoffersen p-value=0.15) pero NO proporciona: (a) la serie histórica de p-values para verificar si el modelo ha pasado consistentemente las pruebas, (b) la metodología exacta de cálculo de excedencias (¿se comparan pérdidas realizadas contra LaR predicho?), (c) evidencia de que estas pruebas se ejecutan MENSUALMENTE como prescribe el manual §4. (2) El manual §4 afirma 'Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente' pero el informe Q2 2026 reporta resultados solo para el trimestre, sin logs de ejecución mensual ni actas de revisión. (3) El manual §3 declara 'Backtesting realizado con 250 observaciones' pero Q2 2026 usa solo 63 días de trading (aproximadamente 3 meses), lo que viola el mínimo de 250 observaciones que el propio manual exige. Esta es una contradicción directa: el modelo no se está backtesting conforme a su especificación. (4) No existe evidencia de que los resultados del backtesting lleguen a ningún comité de decisión ni que cambien la configuración del modelo de forma sistemática. La 'recalibración adelantada al 2026-08-15' se menciona como acción correctiva pero no hay documento que muestre: quién aprobó el cambio, qué parámetros se modificaron, cómo se validó la nueva configuración. (5) El manual menciona test de Jarque-Bera para validar normalidad (supuesto base del modelo) pero NO reporta ningún resultado: ni p-values, ni curtosis observada, ni conclusión sobre si la normalidad se sostiene. Sin validación de supuestos, el backtesting de cobertura (Kupiec) es insuficiente. Para subir a 3/5 se requiere: (a) serie histórica de backtesting mensual con p-values documentados, (b) evidencia de que se usan 250 observaciones mínimo, (c) resultados del test de Jarque-Bera con interpretación, (d) acta de comité que muestre cómo los resultados del backtesting informan decisiones de recalibración.

**Evidencia citada.**

> informe_seguimiento_Q2_2026.md → "Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading, por encima del valor esperado (0.63). Se activó revisión metodológica."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 1/3) → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5."
>
> informe_seguimiento_Q2_2026.md → "| Kupiec p-value | 0.021 | > 0.05 | RECHAZO H0 |"
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 1/3) → "Supuesto base: Normalidad de retornos/flujos de liquidez. Test de validación: Jarque-Bera. Métrica reportada: Curtosis observada (para detección de colas gruesas). Limitación crítica: Si curtosis > 3, modelo infraestima riesgo extremo; normalidad asumida pero no validada explícitamente en resultados."
>
> informe_seguimiento_Q2_2026.md → "Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4). Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 1/3) → "Backtesting realizado con 250 observaciones — mínimo recomendado por Basel."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Supuesto base: Normalidad de retornos/flujos de liquidez. Test de validación: Ja»
> - «Acciones correctivas: Recalibración adelantada al 2026-08-15 (originalmente Q4).»
> - «Informe de Seguimiento — Modelo LaR — Q2 2026 [reporta resultados trimestrales, »
> - «Supuesto base: Normalidad de retornos/flujos de liquidez. Test de validación: Ja»
> - «[No hay reporte de resultados de Jarque-Bera, curtosis observada, ni conclusión »

**Preguntas al modelador.**

- [ ] ¿Existe un log o acta de ejecución mensual del backtesting para los 12 meses anteriores a Q2 2026? Se requiere evidencia de que Kupiec y Christoffersen se ejecutan cada mes, no solo trimestralmente.
- [ ] ¿Cuáles son los p-values de Jarque-Bera y la curtosis observada de los flujos de liquidez? ¿Se rechaza la hipótesis de normalidad? Si es así, ¿cómo se ajusta el modelo para capturar colas gruesas?
- [ ] ¿Por qué el backtesting de Q2 2026 se realizó sobre 63 días en lugar de 250 observaciones? ¿Es una excepción documentada, y si es así, cuál es el impacto en la potencia estadística de las pruebas?
- [ ] ¿Existe un documento de decisión (acta de comité) que muestre cómo los resultados del backtesting (Kupiec p-value=0.021, rechazo de H0) informaron la decisión de recalibración adelantada? ¿Quién aprobó el cambio y cuándo?
- [ ] ¿Se ejecutó el piloto GARCH(1,1) vs EWMA mencionado en las acciones correctivas? ¿Cuáles fueron los resultados y por qué se eligió una metodología sobre la otra?
- [ ] ¿Se implementó Expected Shortfall (ES) como complemento a LaR para capturar riesgo de cola, tal como recomienda RiskMetrics? Si no, ¿cuál es la justificación para no hacerlo?

**Recomendación.** Establecer un proceso de backtesting operativo y documentado: (1) Ejecutar Kupiec, Christoffersen y Jarque-Bera MENSUALMENTE sobre una ventana móvil de 250 observaciones (o justificar por escrito si se usa una ventana menor). (2) Generar un reporte mensual de backtesting que incluya: p-values de ambas pruebas, curtosis observada, conclusión sobre normalidad, número de excedencias observadas vs esperadas, y recomendación de acción (mantener, recalibrar, escalar). (3) Crear un acta de comité mensual o trimestral que documente: revisión de resultados de backtesting, decisiones de recalibración, cambios de parámetros, y aprobación de la Gerencia de Riesgo de Liquidez. (4) Completar el piloto GARCH(1,1) vs EWMA con resultados de backtesting comparativo y documentar la decisión de cuál metodología adoptar. (5) Implementar Expected Shortfall como métrica complementaria a LaR, especialmente si el test de Jarque-Bera rechaza normalidad. (6) Crear un registro de auditoría (log) que demuestre que cada paso del backtesting se ejecutó, quién lo ejecutó, cuándo, y qué decisiones se tomaron como resultado.

<sub>cobertura documental 100.0% · RAG LaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `9458331f124b`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Realizar análisis de sensibilidad/ escenarios al modelo, inputs, en caso aplique

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** Evaluación de la existencia, ejecución y justificación de análisis de sensibilidad/escenarios aplicados al modelo LaR y sus inputs. Esta actividad es crítica para validar que el modelo no solo se calcula, sino que se entienden sus límites y comportamiento bajo condiciones alternativas.

**Hallazgo.**

La documentación disponible DECLARA la necesidad de análisis de sensibilidad y escenarios, pero NO DEMUESTRA su ejecución sistemática ni su integración en la gestión del modelo. El Manual Metodológico LaR v4.2 menciona que 'supuestos de comportamiento aplicados por encima de los mínimos regulatorios deben calibrarse con datos propios, contrastarse con el comportamiento observado en episodios de tensión y someterse a análisis de sensibilidad', pero no proporciona: (1) resultados concretos de análisis de sensibilidad ejecutados; (2) escenarios de estrés documentados y sus impactos cuantitativos; (3) evidencia de que estos análisis alimentan decisiones de gestión o recalibración. El Informe de Seguimiento Q2 2026 identifica que 'volatilidad EWMA subestimada' y propone un 'piloto GARCH(1,1) vs EWMA', lo que sugiere que el análisis comparativo se realiza AD HOC tras detectar problemas, no de forma prospectiva y sistemática. Falta: (a) documentación de la metodología de sensibilidad (qué parámetros varían, en qué rangos, con qué justificación); (b) resultados cuantitativos de escenarios de estrés históricos (p.ej., comportamiento del LaR durante mayo 2026 vs predicción); (c) matriz de sensibilidad del LaR a cambios en λ, horizonte, nivel de confianza; (d) evidencia de que estos análisis se revisan periódicamente y se documentan en actas de comité. Sin esto, no puede verificarse que el modelo sea robusto a variaciones en supuestos clave ni que la gestión entienda sus límites.

**Evidencia citada.**

> Manual_Metodologico_LaR_completo.pdf → 'supuestos de comportamiento aplicados por encima de los mínimos regulatorios — por ejemplo, tasas de fuga internas para el marco de apetito de riesgo— deben calibrarse con datos propios, contrastarse con el comportamiento observado en episodios de tensión y someterse a análisis de sensibilidad.'
>
> informe_seguimiento_Q2_2026.md → 'Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1).'
>
> informe_seguimiento_Q2_2026.md → 'Acciones correctivas: Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo.'
>
> Manual_Metodologico_LaR.md → 'Se asume normalidad de retornos: puede subestimar colas gruesas. No captura contagio entre productos (correlación asumida = 1 en escenario estrés).'
>
> No se encontró en el contexto disponible: (1) resultados de análisis de sensibilidad ejecutados (tablas, gráficos, rangos de variación); (2) escenarios de estrés documentados con impactos cuantitativos; (3) actas o reportes que demuestren revisión periódica de sensibilidades; (4) matriz de sensibilidad del LaR a parámetros clave (λ, horizonte, nivel de confianza).

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «supuestos de comportamiento aplicados por encima de los mínimos regulatorios deb»
> - «Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo. [sin fecha de inicio, si»
> - «Se asume normalidad de retornos: puede subestimar colas gruesas. No captura cont»
> - «Test de normalidad: Jarque-Bera. Métrica reportada: Curtosis observada (para det»

**Preguntas al modelador.**

- [ ] ¿Existen resultados documentados de análisis de sensibilidad del LaR a variaciones en λ (EWMA), horizonte temporal, y nivel de confianza? Si existen, ¿dónde se encuentran y con qué periodicidad se actualizan?
- [ ] ¿Cuáles son los p-valores del test de Jarque-Bera y los valores de curtosis observada en los últimos 250 datos? ¿Se rechaza la hipótesis de normalidad? Si se rechaza, ¿qué correcciones se aplican al modelo?
- [ ] ¿Se ha ejecutado un análisis comparativo EWMA vs GARCH(1,1) con datos históricos? ¿Cuáles son los resultados (AIC, BIC, backtesting Kupiec/Christoffersen para ambos)? ¿Cuándo se completará el piloto mencionado en el informe Q2 2026?
- [ ] ¿Existen escenarios de estrés documentados (p.ej., crisis de tasas de mayo 2026, crisis de crédito, salida masiva de depósitos)? ¿Cuál fue el LaR predicho vs observado en cada escenario? ¿Se documentan en actas de comité?
- [ ] ¿Cuál es el rango de tolerancia aceptable para cambios en LaR ante variaciones en parámetros clave? ¿Existe una matriz de sensibilidad que se revise periódicamente?
- [ ] ¿Se ha validado el supuesto de correlación = 1 en escenario de estrés con datos históricos? ¿Cuál es el impacto en el LaR si se relaja este supuesto?

**Recomendación.** 1. **Documentar y ejecutar análisis de sensibilidad sistemático**: Crear una matriz de sensibilidad del LaR a variaciones en λ (±0.05), horizonte (±5 días), nivel de confianza (±1%), y correlación (0.8, 0.9, 1.0). Ejecutar trimestralmente y reportar en actas de comité de riesgo. Establecer umbrales de tolerancia para cambios en LaR (p.ej., si LaR cambia > 10% ante variación de λ de 0.05, escalar a revisión metodológica).

2. **Completar y documentar el análisis comparativo EWMA vs GARCH(1,1)**: Establecer fecha de conclusión del piloto (máximo 2026-10-31). Reportar resultados de backtesting Kupiec y Christoffersen para ambos métodos. Documentar la decisión (mantener EWMA, migrar a GARCH, o usar modelo híbrido) con justificación cuantitativa. Incluir en el manual metodológico la razón de la elección.

3. **Validar supuestos distribucionales**: Ejecutar test de Jarque-Bera mensualmente sobre los últimos 250 datos. Reportar p-valores y curtosis. Si se rechaza normalidad (p < 0.05) de forma consistente, evaluar distribuciones alternativas (t-Student, GEV) o aplicar correcciones de colas (p.ej., ajuste de VaR por curtosis). Documentar la conclusión en el manual.

4. **Documentar escenarios de estrés histórico**: Para cada período de estrés identificado (p.ej., mayo 2026), calcular LaR predicho vs observado, número de excedencias, y análisis de causa raíz. Crear una tabla de escenarios históricos que se revise anualmente. Usar estos escenarios para validar la capacidad predictiva del modelo en regímenes de volatilidad alta.

5. **Integrar análisis de sensibilidad en el ciclo de governance**: Incluir revisión de sensibilidades en la agenda trimestral del Comité de Riesgo de Liquidez. Establecer que cualquier cambio en parámetros clave (λ, horizonte, distribución) requiera análisis de sensibilidad previo y aprobación del comité. Documentar decisiones en actas.

<sub>cobertura documental 100.0% · RAG LaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `6c433f577330`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Validar supuestos y consideración más importantes de la técnica utilizada

> No se pudo evaluar: La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0). Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** EVALUACIÓN NO REALIZADA — fallo técnico

**Hallazgo.**

Esta actividad NO pudo evaluarse. Motivo: La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0) No se asignó puntaje para no contaminar el dictamen con un valor inventado. Detalle técnico: ```json
{
  "puntaje": 2,
  "concepto": "Validación de la justificación metodológica del modelo LaR: verificar que la elección del enfoque paramétrico-EWMA esté fundamentada en supuestos explícitamente validados, que las limitaciones conocidas se hayan contrastado contra datos reales, y que el backt

**Evidencia citada.**

_Sin evidencia citada._

**Preguntas al modelador.**

- [ ] Re-ejecutar la evaluación de la actividad 'Validar supuestos y consideración más importantes de la técn' y verificar conectividad/cuota de la API.

**Recomendación.** Re-ejecutar el agente. Si persiste, revisar el prompt y la API.

<sub>RAG LaR (4 frag.)</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Revisión de los lineamiento internacionales o nacionales

> No se pudo evaluar: La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0). Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Revisión de la justificación de la metodología*

**Qué evalúa.** EVALUACIÓN NO REALIZADA — fallo técnico

**Hallazgo.**

Esta actividad NO pudo evaluarse. Motivo: La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0) No se asignó puntaje para no contaminar el dictamen con un valor inventado. Detalle técnico: ```json
{
  "puntaje": 2,
  "concepto": "Evaluación de la justificación metodológica del modelo LaR frente a lineamientos internacionales y nacionales, incluyendo validación de supuestos, backtesting y coherencia con marcos regulatorios (Basel III, IFRS 9, SR 11-7). Esta actividad es crítica porque

**Evidencia citada.**

_Sin evidencia citada._

**Preguntas al modelador.**

- [ ] Re-ejecutar la evaluación de la actividad 'Revisión de los lineamiento internacionales o nacionales' y verificar conectividad/cuota de la API.

**Recomendación.** Re-ejecutar el agente. Si persiste, revisar el prompt y la API.

<sub>RAG LaR (2 frag.)</sub>

> ✍️ _Conclusión del validador:_
>
---

#### ⚪ [NO EVALUADA — fallo técnico] Analizar el seguimeinto de la metodología

> No se pudo evaluar: La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0). Queda **sin puntaje** y excluida del score; no cuenta como incumplimiento del modelo validado.

*Control: Revisión del seguimeinto del modelo, en caso no se cuente solicitar la planificación*

**Qué evalúa.** EVALUACIÓN NO REALIZADA — fallo técnico

**Hallazgo.**

Esta actividad NO pudo evaluarse. Motivo: La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0) No se asignó puntaje para no contaminar el dictamen con un valor inventado. Detalle técnico: ```json
{
  "puntaje": 2,
  "concepto": "Evaluación de la justificación, validación empírica y seguimiento sistemático de la metodología LaR. Verifica que los supuestos del modelo estén demostrados, que el backtesting se ejecute regularmente con rigor estadístico, y que las limitaciones conocidas se

**Evidencia citada.**

_Sin evidencia citada._

**Preguntas al modelador.**

- [ ] Re-ejecutar la evaluación de la actividad 'Analizar el seguimeinto de la metodología' y verificar conectividad/cuota de la API.

**Recomendación.** Re-ejecutar el agente. Si persiste, revisar el prompt y la API.

<sub>RAG LaR (0 frag.)</sub>

> ✍️ _Conclusión del validador:_
>
---

### Gobierno  ·  score 2.0

#### 🟠 [2/5] Revisar la actualización del tiering del modelo

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificar que el modelo LaR tenga tiering asignado, actualizado y justificado, y que se encuentre registrado en el inventario oficial de modelos. Esta actividad es crítica para el gobierno de modelos: sin tiering claro y documentado, no hay asignación de responsabilidades, frecuencias de validación ni niveles de control proporcionales al riesgo.

**Hallazgo.**

La documentación disponible NO contiene evidencia de que se haya realizado una actualización formal del tiering del modelo LaR, ni acta alguna que documente la decisión de gobierno sobre su clasificación. El manual metodológico describe la especificación técnica del modelo (objetivo, horizonte, nivel de confianza, metodología EWMA, backtesting con Kupiec y Christoffersen), y la documentación de implementación menciona que el modelo fue 'aprobado por el Comité de Riesgo el 2026-01-15', pero NO hay: (1) acta formal firmada de esa aprobación, (2) asignación explícita de tiering (Tier 1, 2, 3, etc.), (3) justificación documentada de por qué se asignó ese tiering, (4) evidencia de revisión o actualización posterior del tiering, (5) referencia al inventario oficial de modelos. El feedback de corridas anteriores indica que el modelo SÍ está inventariado en la herramienta corporativa de GRC (fuera de los inputs proporcionados), pero esa información no está disponible en el contexto de esta validación. Sin acceso a esa herramienta o a un acta formal de gobierno, no es posible verificar que el tiering esté actualizado ni justificado. La ausencia de acta formal es crítica: un correo o una mención en un manual no equivalen a decisión de gobierno registrada. El riesgo es que cambios en la clasificación del modelo (por ejemplo, de Tier 2 a Tier 1 tras cambios metodológicos o de volumen) no queden documentados, lo que compromete la trazabilidad y la auditoría.

**Evidencia citada.**

> implementacion_LaR.md → "Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez."
>
> manual_metodologico_LaR.md → "## 5. Governance\n\nModelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez."
>
> No se encontró en el contexto disponible: (1) acta formal firmada de aprobación o actualización de tiering, (2) asignación explícita de tiering (Tier 1/2/3), (3) justificación documentada del tiering asignado, (4) referencia al inventario oficial de modelos, (5) evidencia de revisión del tiering posterior a 2026-01-15.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «## 5. Governance\n\nModelo aprobado por el Comité de Riesgo el 2026-01-15. Recal»
> - «Solo aceptar actas formales firmadas. Un correo NO equivale a acta.»

**Preguntas al modelador.**

- [ ] ¿Existe acta formal firmada del Comité de Riesgo que documente la aprobación del modelo LaR del 2026-01-15? ¿Quiénes fueron los firmantes y qué tiering se asignó en esa acta?
- [ ] ¿Cuál es el tiering actual asignado al modelo LaR (Tier 1, 2, 3 u otra clasificación)? ¿En qué fecha se asignó y por qué criterios?
- [ ] ¿Existe acta de actualización del tiering posterior a la aprobación inicial? Si el modelo ha sufrido cambios metodológicos, de volumen o de criticidad, ¿se ha revisado y actualizado el tiering?
- [ ] ¿El modelo LaR está registrado en el inventario oficial de modelos de la entidad? ¿Cuál es el identificador único del modelo en ese inventario y cuál es su tiering registrado?
- [ ] ¿Quién es responsable de mantener actualizado el tiering del modelo LaR y con qué frecuencia se revisa (anual, semestral, por evento)?
- [ ] ¿Existe documentación que justifique por qué se asignó ese tiering específico? (Por ejemplo: criticidad para regulación, volumen de exposición, complejidad metodológica, frecuencia de uso en decisiones de negocio.)

**Recomendación.** 1. Obtener y anexar el acta formal firmada del Comité de Riesgo que aprobó el modelo LaR, indicando explícitamente el tiering asignado y la fecha de vigencia. 2. Documentar en un acta de gobierno (o en una sección del manual de governance) la justificación del tiering asignado, referenciando criterios como criticidad regulatoria, volumen de exposición, complejidad metodológica y frecuencia de uso. 3. Establecer un proceso formal de revisión del tiering (mínimo anual o por evento de cambio material) y documentar cada revisión en acta. 4. Verificar que el modelo esté registrado en el inventario oficial de modelos con el tiering vigente y que ese registro sea accesible a la segunda línea de defensa. 5. Si el tiering ha sido actualizado desde 2026-01-15, proporcionar el acta de esa actualización con la nueva clasificación y su justificación.

<sub>cobertura documental 100.0% · RAG LaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `4d80e2e8214f`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] revisar que el modelo se encuentre inventariado

*Control: Verificar nivel de alineamiento del gobierno de modelos de riesgo financiero*

**Qué evalúa.** Verificar que el modelo LaR se encuentre inventariado en el registro oficial de modelos de riesgo con tiering asignado y justificado. Este control es crítico para el gobierno de modelos: sin inventario formal y tiering, no hay trazabilidad regulatoria ni asignación clara de responsabilidades de validación y seguimiento.

**Hallazgo.**

La documentación disponible NO contiene evidencia de inventario formal del modelo LaR. El manual metodológico (v4.2) y la documentación de implementación describen el modelo, sus parámetros, backtesting y governance, pero ningún documento proporciona: (1) acta formal de inventariado firmada por el propietario o comité de riesgo, (2) tiering asignado (Tier 1, 2, 3 u otra clasificación), (3) justificación del tiering basada en criterios de materialidad, complejidad o impacto regulatorio. El manual menciona que el modelo fue «aprobado por el Comité de Riesgo el 2026-01-15» y que el «Owner: Gerencia de Riesgo de Liquidez», pero aprobación ≠ inventariado formal. La instrucción específica para este ámbito exige «solo aceptar actas formales firmadas. Un correo NO equivale a acta». No se encontró ningún acta. El historial de corridas anteriores advierte que el inventario «vive en la herramienta corporativa de GRC, fuera de inputs/», lo que explica la ausencia en el contexto disponible, pero eso no cambia el hecho de que la evidencia requerida no está presente en los documentos proporcionados para esta validación. Para alcanzar nivel 3 se requeriría al menos una referencia documentada al inventario (número de registro, fecha de inclusión, tiering asignado) en alguno de los ficheros de entrada. Para nivel 4 se necesitaría el acta formal o un extracto verificable del sistema de GRC.

**Evidencia citada.**

> implementacion_LaR.md → "Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez."
>
> manual_metodologico_LaR.md → "Governance: Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez."
>
> No se encontró evidencia de acta formal de inventariado, número de registro en inventario, tiering asignado, o justificación del tiering en el contexto disponible.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Governance: Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración»
> - «Solo aceptar actas formales firmadas. Un correo NO equivale a acta.»

**Preguntas al modelador.**

- [ ] ¿Cuál es el número de registro del modelo LaR en el inventario oficial de modelos de riesgo de la entidad?
- [ ] ¿Qué tiering ha sido asignado al modelo LaR (Tier 1, 2, 3 u otra clasificación interna) y cuál es la justificación documentada de esa asignación?
- [ ] ¿Existe un acta formal, firmada por el propietario del modelo (Gerencia de Riesgo de Liquidez) y/o por el comité de riesgo, que certifique la inclusión del modelo en el inventario y la asignación de tiering?
- [ ] ¿Cuál es la fecha de inclusión del modelo en el inventario y cuándo fue la última actualización del tiering?
- [ ] ¿El sistema de GRC (herramienta corporativa de gestión de riesgos) contiene un registro activo del modelo LaR con tiering vigente? Si es así, ¿puede proporcionarse un extracto o captura de pantalla que lo demuestre?

**Recomendación.** Obtener y adjuntar el acta formal de inventariado del modelo LaR, firmada por el propietario y/o comité de riesgo, que incluya: (1) número de registro en el inventario oficial, (2) tiering asignado, (3) criterios utilizados para la asignación del tiering (materialidad, complejidad, impacto regulatorio), (4) fecha de inclusión y última revisión. Alternativamente, si el inventario reside en la herramienta de GRC, proporcionar un extracto oficial del sistema que demuestre el registro activo y el tiering vigente. Esta evidencia es requisito previo para considerar el modelo como formalmente inventariado en el gobierno de modelos de riesgo.

<sub>cobertura documental 100.0% · RAG LaR (2 frag.) · ajuste sesgo: Feedback insuficiente (1/15 muestras mínimas) · prompt `b37d7a8de4de`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Implementación  ·  score 1.75

#### 🔴 [1/5] Vericar existencias de correos de comunicación de resultados y su conformidad

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificar la existencia y conformidad de comunicaciones (correos) que documenten la aprobación de resultados del modelo LaR y su paso a producción, así como la coherencia entre documentación metodológica, manual de implementación y código ejecutable. Esta actividad es crítica para asegurar que el modelo no solo está documentado, sino que ha sido validado por primera línea y que existe trazabilidad de decisiones de despliegue.

**Hallazgo.**

La evaluación revela una brecha CRÍTICA entre documentación y evidencia de ejecución operativa. El contexto disponible contiene: (1) Manual metodológico detallado con especificaciones técnicas, supuestos y framework de backtesting; (2) Documento de implementación que describe arquitectura, stack técnico y controles; (3) Ningún correo de comunicación, conformidad o aprobación de resultados; (4) Ningún script de código (.py, .ipynb) que permita verificar coherencia entre lo documentado y lo implementado; (5) Ninguna evidencia de UAT (User Acceptance Testing) ejecutadas; (6) Ningún log de ejecución, resultado de backtesting o reporte de paso a producción. El manual declara que el modelo fue «aprobado por el Comité de Riesgo el 2026-01-15» y que existe «backtesting realizado con 250 observaciones», pero no hay evidencia de que estos eventos ocurrieron realmente, ni de que los resultados fueron comunicados a stakeholders. La arquitectura descrita (DAG en Airflow, corrida diaria a las 07:00 COT, persistencia en PostgreSQL) sugiere un sistema operativo, pero sin acceso a logs, scripts o correos de conformidad, no es posible verificar que la implementación coincida con la especificación ni que haya pasado controles de calidad antes de producción. Esto es una AUSENCIA DE EVIDENCIA DE EJECUCIÓN, no un incumplimiento documentado, pero invalida la capacidad de auditar la implementación real del modelo.

**Evidencia citada.**

> implementacion_LaR.md → "Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT. Persistencia: PostgreSQL (tabla `lar_daily_estimates`)." | implementacion_LaR.md → "Log estructurado en JSON — retenido 90 días. Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Alguna fuente falla o llega vacía." | manual_metodologico_LaR.md → "Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual obligatoria. Owner: Gerencia de Riesgo de Liquidez." | manual_metodologico_LaR.md → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5." | No se encontró evidencia en el contexto disponible de: correos de comunicación de resultados, scripts de código (.py, .ipynb), logs de ejecución real, reportes de backtesting ejecutados, actas de UAT, o correos de aprobación para paso a producción.

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT. Persistencia: Postgr»
> - «Log estructurado en JSON — retenido 90 días. Alertas por Slack si: Tiempo de eje»
> - «Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Al»
> - «Limitaciones actuales: No hay contenedor Docker aún (ejecuta en VM compartida). »

**Preguntas al modelador.**

- [ ] ¿Existen correos de comunicación de resultados del backtesting (Kupiec y Christoffersen) al Comité de Riesgo o a primera línea? Si existen, ¿cuál es la frecuencia y cuándo fue el último?
- [ ] ¿Cuál es el script Python (.py o .ipynb) que implementa el cálculo de LaR? ¿Dónde se almacena en el repositorio Git `risk-liquidity-models` y cuál es su versión actual?
- [ ] ¿Existen logs de ejecución del DAG de Airflow que demuestren que la corrida diaria a las 07:00 COT se ejecuta exitosamente? ¿Cuál es el período de cobertura de estos logs?
- [ ] ¿Se ejecutó una prueba de aceptación del usuario (UAT) antes de pasar el modelo a producción? Si existe, ¿cuál es el acta de conformidad y quién la firmó?
- [ ] ¿Existe un correo o acta de aprobación formal para el paso a producción del modelo LaR? ¿Quién autorizó el despliegue manual y cuándo?
- [ ] ¿Cuál es el resultado más reciente del backtesting (Kupiec y Christoffersen)? ¿Cuándo se ejecutó y cuáles fueron los p-values observados?
- [ ] ¿El código en producción coincide exactamente con la versión documentada en el manual metodológico? Específicamente: ¿usa λ = 0.94 en EWMA, z(99%) = 2.326, horizonte de 30 días, y ventana de 250 observaciones para backtesting?
- [ ] ¿Existe un control de cambios documentado que registre cualquier modificación al código después de la aprobación del Comité de Riesgo del 2026-01-15?

**Recomendación.** ACCIÓN INMEDIATA REQUERIDA: (1) Solicitar y revisar todos los correos de comunicación de resultados del modelo LaR desde su aprobación (2026-01-15 en adelante), incluyendo reportes de backtesting, alertas de excepciones y cambios de parámetros. (2) Obtener el código fuente completo (.py, .ipynb) del repositorio Git y ejecutar un análisis de coherencia línea por línea contra el manual metodológico, verificando parámetros, fórmulas y criterios de control. (3) Solicitar logs de ejecución del DAG de Airflow de los últimos 90 días para verificar que la corrida diaria se ejecuta como se describe. (4) Obtener el acta de UAT y la aprobación formal de paso a producción; si no existen, documentar que el modelo fue desplegado sin validación formal de implementación. (5) Ejecutar un backtesting retrospectivo con los datos disponibles para verificar que los resultados coinciden con lo reportado en el manual. (6) Establecer un control de cambios formal en Git con revisión de código (code review) antes de cualquier despliegue futuro, eliminando el despliegue manual. (7) Documentar formalmente la cadena de aprobación: aprobación metodológica → aprobación de implementación → aprobación de paso a producción, con correos y actas de cada etapa.

<sub>cobertura documental 100.0% · RAG LaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `e3902b7844ec`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verifica las fuentes de información empleadas

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Validación de coherencia entre documentación de implementación y código ejecutable, así como verificación de que las fuentes de información declaradas están efectivamente integradas en el pipeline productivo. Esta actividad es crítica porque detecta code drift, cambios no documentados y desconexiones entre lo que el modelo dice hacer y lo que realmente ejecuta.

**Hallazgo.**

La documentación de implementación declara una arquitectura clara (ETL → Motor LaR → DB Riesgo → BI/Excel) y controles operacionales (logs JSON, alertas Slack, versionado Git), pero NO PROPORCIONA EVIDENCIA DE EJECUCIÓN REAL. Específicamente: (1) No se proporcionan scripts Python (.py, .ipynb) que implementen las funciones descritas en el manual metodológico (cálculo EWMA con λ=0.94, pruebas de Kupiec/Christoffersen, cuantil z(99%)=2.326). Sin código, no es posible verificar si la implementación coincide con la especificación. (2) No hay logs de ejecución, corridas de prueba (UAT) documentadas, ni evidencia de que el DAG Airflow se ejecute diariamente a las 07:00 COT como se afirma. (3) No existen correos de aprobación para paso a producción, ni evidencia de que primera línea haya validado los resultados antes del despliegue. (4) El manual de implementación menciona «Runbook operativo actualizado 2026-05-30» pero no se proporciona el documento; sin él, no se puede verificar qué controles están realmente en lugar. (5) Se declara que «cada corrida guarda parámetros, versión de código y hash de datos de entrada» pero no se muestra ningún ejemplo de estos metadatos. El riesgo es que el modelo esté documentado pero no implementado, o implementado de forma divergente a lo documentado, sin que exista trazabilidad de cuándo ocurrió el cambio. Para alcanzar puntaje 3, se requiere: (a) al menos los scripts principales (.py) que ejecutan el cálculo LaR, (b) un log de ejecución real (últimas 5-10 corridas), (c) correos de aprobación para paso a producción, (d) el Runbook operativo, (e) un ejemplo de metadatos guardados en una corrida.

**Evidencia citada.**

> implementacion_LaR.md → "Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT."
>
> implementacion_LaR.md → "Log estructurado en JSON — retenido 90 días. Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Alguna fuente falla o llega vacía."
>
> implementacion_LaR.md → "Versionado del código en Git (repo `risk-liquidity-models`). Cada corrida guarda: parámetros, versión de código y hash de datos de entrada."
>
> implementacion_LaR.md → "Runbook operativo actualizado 2026-05-30."
>
> manual_metodologico_LaR.md → "Ecuación base: LaR_t = μ_t + σ_t · z(1-α) donde μ_t es la salida neta esperada y σ_t la volatilidad EWMA a 30 días."
>
> manual_metodologico_LaR.md → "Estimador de volatilidad: EWMA con λ = 0.94 (RiskMetrics)."
>
> manual_metodologico_LaR.md → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Log estructurado en JSON — retenido 90 días. Alertas por Slack si: Tiempo de eje»
> - «Versionado del código en Git (repo `risk-liquidity-models`). Cada corrida guarda»
> - «Limitaciones actuales: No hay contenedor Docker aún (ejecuta en VM compartida). »
> - «Versionado del código en Git (repo `risk-liquidity-models`). Cada corrida guarda»
> - «Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualm»
> - «Criterio de aceptación/rechazo: Umbral crítico universal: ≤ 0.0500 (5%). Estado »

**Preguntas al modelador.**

- [ ] ¿Se proporcionarán los scripts Python (.py, .ipynb) que implementan el cálculo LaR, la volatilidad EWMA con λ=0.94, y las pruebas de Kupiec y Christoffersen? Sin ellos, no es posible verificar que el código coincida con la especificación metodológica.
- [ ] ¿Existen logs de ejecución real del DAG Airflow (últimas 10 corridas)? ¿Qué muestra el log sobre tiempos de ejecución, fuentes de datos consumidas, y resultados LaR calculados?
- [ ] ¿Se proporcionarán correos de aprobación (de primera línea o Comité de Riesgo) para el paso a producción del modelo? ¿Cuándo se desplegó por primera vez y quién autorizó?
- [ ] ¿Dónde está el Runbook operativo actualizado al 2026-05-30? ¿Qué controles operacionales específicos documenta (p.ej., validación de datos de entrada, reconciliación de resultados, escalada de alertas)?
- [ ] ¿Se puede proporcionar un ejemplo real de los metadatos guardados en una corrida (parámetros, versión de código, hash de datos de entrada)? ¿En qué tabla/archivo se almacenan?
- [ ] ¿Cómo se reconcilian los dos criterios de alerta para backtesting: «excedencias > 5» vs «p-value > 0.05»? ¿Cuál es el criterio operacional que realmente se usa para escalar alertas?
- [ ] ¿Se ejecutó UAT (User Acceptance Testing) antes de pasar a producción? ¿Qué casos de prueba se corrieron y cuáles fueron los resultados?
- [ ] ¿Existe documentación de cambios (change log) que muestre qué versiones del código se han desplegado, cuándo, y qué cambios incluyeron? ¿Cómo se asegura que no hay code drift entre Git y la VM de producción?
- [ ] ¿Quién es el propietario operacional del modelo en producción? ¿Quién monitorea diariamente que el DAG se ejecute a las 07:00 COT y qué hace si falla?

**Recomendación.** Antes de validar la implementación como completa, se debe: (1) Proporcionar los scripts Python principales (al menos `calcula_lar.py`, `backtesting.py`, `etl.py`) con comentarios que mapeen cada función a la especificación metodológica. (2) Ejecutar el DAG Airflow en ambiente de prueba y capturar logs de al menos 5 corridas consecutivas, mostrando entrada de datos, parámetros usados, y resultados LaR. (3) Obtener correos de aprobación para paso a producción (de Gerencia de Riesgo de Liquidez y/o Comité de Riesgo) con fecha y firma. (4) Proporcionar el Runbook operativo completo y verificar que cada control declarado (alertas Slack, validación de fuentes, reconciliación) esté implementado en el código. (5) Aclarar y documentar el criterio único de alerta para backtesting (¿es conteo de excedencias o p-value?) y mostrar evidencia de que se aplica consistentemente. (6) Implementar CI/CD (al menos un script de despliegue automatizado) para eliminar el riesgo de divergencia entre Git y producción. Sin estos pasos, el modelo no puede considerarse implementado de forma verificable.

<sub>cobertura documental 100.0% · RAG LaR (1 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `88873e841399`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Revisar la documentación contenga los puntos solicitados en el ámbitos Metodologicos

*Control: Revisión de Lineamientos de seguridad*

**Qué evalúa.** Validación de coherencia entre documentación metodológica e implementación técnica del modelo LaR, incluyendo verificación de fuentes de datos, aprobaciones formales, pruebas UAT y controles en pipeline productivo. Esta actividad es crítica porque detecta desviaciones entre lo que el modelo DICE que hace y lo que REALMENTE ejecuta.

**Hallazgo.**

La documentación de implementación declara una arquitectura clara y controles de ejecución, pero presenta BRECHAS CRÍTICAS en la demostración de su ejecución real y en la coherencia con la metodología documentada. (1) FALTA EVIDENCIA DE APROBACIÓN FORMAL: no se proporcionan correos de conformidad o actas de paso a producción; el manual metodológico menciona aprobación del Comité de Riesgo el 2026-01-15, pero no hay evidencia de que la IMPLEMENTACIÓN haya sido validada y autorizada formalmente. (2) INCOHERENCIA CRÍTICA EN PARÁMETROS: el manual metodológico especifica backtesting con 250 observaciones y frecuencia mensual, pero la documentación de implementación declara 'corrida diaria a las 07:00 COT' sin aclarar cómo se reconcilia una métrica mensual con una ejecución diaria — ¿se acumula? ¿se reporta solo al cierre? Esto invalida la comparabilidad del backtesting. (3) FALTA EVIDENCIA DE EJECUCIÓN REAL: se declaran 'alertas por Slack si LaR > umbral regulatorio' y 'logs estructurados en JSON', pero no se proporcionan ejemplos de logs, resultados de backtesting ejecutados, ni evidencia de que los controles se hayan activado alguna vez. Un script que existe pero nunca se corrió no es un control implementado. (4) AUSENCIA DE DOCUMENTACIÓN DE PRUEBAS UAT: no hay mención de pruebas iniciales de implementación, casos de prueba, o validación de que el código produce los resultados esperados antes de pasar a producción. (5) FALTA COHERENCIA ENTRE FUENTES: el manual metodológico no menciona la arquitectura técnica (ETL, Airflow, PostgreSQL), lo que impide verificar si la implementación respeta los supuestos metodológicos (ej: ¿cómo se garantiza que los datos de entrada son los especificados en el manual?). Para alcanzar puntaje 3 se requiere: (a) correos de aprobación formal de la implementación, (b) aclaración de la frecuencia de cálculo vs. reporte, (c) ejemplos de logs y alertas ejecutadas, (d) documentación de UAT con casos de prueba y resultados, (e) matriz de trazabilidad entre parámetros del manual y valores en código.

**Evidencia citada.**

> implementacion_LaR.md → "Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT."
>
> implementacion_LaR.md → "Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Alguna fuente falla o llega vacía."
>
> implementacion_LaR.md → "Log estructurado en JSON — retenido 90 días."
>
> manual_metodologico_LaR.md → "Backtesting realizado con 250 observaciones — mínimo recomendado por Basel."
>
> manual_metodologico_LaR.md → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente."
>
> manual_metodologico_LaR.md → "Modelo aprobado por el Comité de Riesgo el 2026-01-15."
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 1/3) → "Frecuencia de reporte: Cierre mensual"
>
> Manual_Metodologico_LaR_completo.pdf (Bloque 2/3) → "Período de validación: 250 observaciones = aproximadamente 20.8 años de datos mensuales (~21 meses mínimo)"

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Al»
> - «Manual_Metodologico_LaR_completo.pdf (Bloque 2/3) →»
> - «No hay mención de aprobación de la implementación técnica.»
> - «Limitaciones actuales: No hay contenedor Docker aún (ejecuta en VM compartida). »
> - «Reproducibilidad: Versionado del código en Git (repo `risk-liquidity-models`). C»

**Preguntas al modelador.**

- [ ] ¿Existe correo o acta formal de aprobación de la IMPLEMENTACIÓN técnica del modelo LaR por parte de Riesgo o Tecnología? Si existe, ¿cuál es la fecha y quién la firmó?
- [ ] ¿Cómo se reconcilia la ejecución DIARIA del DAG con el backtesting MENSUAL? ¿Se usan datos diarios o mensuales para el backtesting? ¿Se reporta LaR diariamente o solo al cierre de mes?
- [ ] ¿Se han ejecutado pruebas UAT documentadas antes de pasar el modelo a producción? Si existen, ¿dónde están los casos de prueba, los datos de entrada, los resultados esperados y los resultados observados?
- [ ] ¿Existen ejemplos de logs JSON ejecutados en producción (con datos reales, no sintéticos)? ¿Se ha activado alguna alerta de Slack por LaR > umbral o por falla de fuente?
- [ ] ¿Existe una matriz de trazabilidad que mapee cada parámetro del manual metodológico (λ=0.94, z(99%)=2.326, ventana de 250 obs, etc.) con su valor en el código Python? ¿Dónde se valida que coincidan?
- [ ] ¿Quién es el propietario técnico del código (owner del repo Git)? ¿Existe un SLA de mantenimiento y actualización?
- [ ] ¿Se han ejecutado los tests de Kupiec y Christoffersen con datos reales desde que el modelo está en producción? Si existen resultados, ¿cuáles son los p-values observados y cómo se interpretan contra el umbral de 0.05?
- [ ] ¿Cómo se garantiza que los datos de entrada (Core bancario, SAP Tesorería, Bloomberg) son los especificados en el manual metodológico? ¿Existe validación de esquema o reconciliación documentada?

**Recomendación.** ANTES de considerar el modelo en producción: (1) Obtener y documentar correo de aprobación formal de la implementación técnica, firmado por Riesgo y Tecnología, con fecha posterior a la aprobación metodológica (2026-01-15). (2) Aclarar y documentar la frecuencia de cálculo vs. reporte: si es diaria, ajustar el backtesting a datos diarios; si es mensual, documentar cómo se agregan los datos diarios. (3) Ejecutar UAT formal: diseñar casos de prueba que cubran (a) cálculo correcto de EWMA con λ=0.94, (b) cuantil z(99%)=2.326, (c) manejo de datos faltantes, (d) alertas de Slack, (e) persistencia en PostgreSQL. Documentar resultados. (4) Ejecutar backtesting con datos reales de al menos 250 observaciones mensuales (o el equivalente en datos diarios si se usa esa frecuencia) y reportar p-values de Kupiec y Christoffersen. (5) Crear matriz de trazabilidad parámetro-a-código y validarla contra el manual. (6) Implementar CI/CD mínimo (ej: GitHub Actions) para garantizar que la versión en Git es la que se ejecuta en producción. (7) Documentar el propietario técnico, SLA de mantenimiento y proceso de cambios.

<sub>cobertura documental 100.0% · RAG LaR (2 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `58271adfc7a5`</sub>

> ✍️ _Conclusión del validador:_
>
---

#### 🟠 [2/5] Verificar el análisis realizado de la promera linea de los resultados provistos por el proveedor (umbrales, evolutivo historico, consistencia, entre otros)

*Control: Pruebas iniciales sobre la implementación de modelo (desarrollo externo)*

**Qué evalúa.** Verificación de coherencia entre documentación de implementación y código ejecutable, así como validación de que las pruebas iniciales del modelo (umbrales, evolutivo histórico, consistencia) están documentadas y ejecutadas. Esta actividad es crítica porque detecta desviaciones entre lo que el modelo DICE que hace y lo que REALMENTE hace en producción.

**Hallazgo.**

La documentación de implementación declara una arquitectura clara (ETL → Motor LaR → DB Riesgo → BI/Tableau) con controles de ejecución (logs JSON, alertas Slack, versionado Git) y un runbook actualizado. Sin embargo, existen brechas críticas que impiden validar que la implementación sea operativa y coherente con la metodología: (1) NO SE PROPORCIONA CÓDIGO FUENTE — ningún script .py, .ipynb ni función del motor LaR está disponible en el contexto. Esto hace imposible verificar si las funciones documentadas (cálculo EWMA con λ=0.94, cuantil z(99%)=2.326, backtesting Kupiec/Christoffersen) existen realmente en el código o si hay code drift. (2) NO HAY EVIDENCIA DE EJECUCIÓN DE PRUEBAS INICIALES — el manual metodológico DECLARA que se aplican tests de Kupiec y Christoffersen mensualmente con umbral de alerta si excepciones > 5, pero no se proporcionan resultados de esas pruebas, logs de ejecución, ni correos de aprobación de paso a producción. (3) NO SE DOCUMENTA EL ANÁLISIS DE UMBRALES, EVOLUTIVO HISTÓRICO O CONSISTENCIA — la actividad específicamente pide verificar estos análisis de primera línea, pero no aparecen en los documentos. (4) AUSENCIA DE UAT DOCUMENTADA — no hay evidencia de pruebas de aceptación del usuario, validación de datos de entrada/salida, o controles en el pipeline productivo más allá de la declaración de alertas. (5) INCONSISTENCIA EN PERIODICIDAD — el manual metodológico menciona backtesting mensual y trimestral sin claridad, mientras que la implementación declara corrida diaria a las 07:00 COT. Para subir a puntaje 3 se requiere: (a) scripts .py/.ipynb del motor LaR con funciones documentadas; (b) logs o reportes de ejecución de backtesting con resultados reales (p-values de Kupiec/Christoffersen); (c) correos de aprobación de paso a producción; (d) análisis documentado de umbrales y evolutivo histórico; (e) especificación clara de periodicidad de pruebas y su alineación con la corrida diaria.

**Evidencia citada.**

> implementacion_LaR.md → "Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT. Persistencia: PostgreSQL (tabla `lar_daily_estimates`)." | implementacion_LaR.md → "Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Alguna fuente falla o llega vacía." | implementacion_LaR.md → "Versionado del código en Git (repo `risk-liquidity-models`). Cada corrida guarda: parámetros, versión de código y hash de datos de entrada." | manual_metodologico_LaR.md → "Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia) mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta si excedencias observadas > 5." | Manual_Metodologico_LaR_completo.pdf (Bloque 2/3) → "Prueba de Kupiec (POF — Proportion of Failures): Propósito: Validar si frecuencia de excepciones observadas coincide con esperada (1% a nivel 99% CL). Muestra: 250 observaciones. Frecuencia esperada: ~2.5 excedencias en 250 obs (1% de 250). Aplicación: Trimestral/mensual" | implementacion_LaR.md → "No hay contenedor Docker aún (ejecuta en VM compartida). Falta CI/CD — despliegue manual."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT. Persistencia: Postgr»
> - «Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Al»
> - «Versionado del código en Git (repo `risk-liquidity-models`). Cada corrida guarda»
> - «Prueba de Kupiec (POF — Proportion of Failures): Propósito: Validar si frecuenci»
> - «No hay contenedor Docker aún (ejecuta en VM compartida). Falta CI/CD — despliegu»

**Preguntas al modelador.**

- [ ] ¿Dónde están los scripts Python (.py, .ipynb) del motor LaR? Se declara que existe un DAG en Airflow y un repositorio Git (`risk-liquidity-models`), pero no se proporciona el código fuente. ¿Puede proporcionarse al menos las funciones principales (cálculo EWMA, cuantil, backtesting)?
- [ ] ¿Existen logs de ejecución del backtesting de Kupiec y Christoffersen? Se declara que se aplica mensualmente, pero no se proporcionan resultados (p-values, número de excepciones observadas, estado OK/ALERTA). ¿Pueden proporcionarse los últimos 3-6 meses de resultados?
- [ ] ¿Hay correos de aprobación o actas de comité que documenten el paso a producción del modelo? El manual metodológico menciona aprobación del Comité de Riesgo el 2026-01-15, pero no se proporciona evidencia de que la implementación haya sido validada y aprobada antes de entrar en producción.
- [ ] ¿Se documentó el análisis de umbrales (¿por qué umbral de alerta en 5 excepciones y no otro?) y el evolutivo histórico del LaR (¿cómo ha evolucionado el estimado en los últimos 12 meses?)? La actividad específicamente pide verificar estos análisis de primera línea.
- [ ] ¿Existe documentación de UAT (User Acceptance Testing)? ¿Se validaron los datos de entrada (fuentes SAP, Bloomberg), los cálculos intermedios (EWMA, volatilidad) y los datos de salida (tabla `lar_daily_estimates`) contra valores esperados?
- [ ] ¿El backtesting se ejecuta automáticamente dentro del DAG de Airflow o es un proceso manual? Si es manual, ¿con qué frecuencia se ejecuta realmente (¿mensual, trimestral, ad-hoc)?
- [ ] ¿Se ha validado la coherencia entre el parámetro λ=0.94 documentado en el manual y el valor implementado en el código? ¿Existen pruebas de sensibilidad que justifiquen esta elección frente a otros valores (0.90, 0.95)?
- [ ] ¿Se han documentado y ejecutado análisis de sensibilidad o escenarios de estrés sobre el modelo LaR? El manual metodológico menciona limitaciones (normalidad, correlación asumida = 1 en estrés), pero no se proporciona evidencia de que se hayan cuantificado sus impactos.

**Recomendación.** Antes de validar la implementación como operativa, se requiere: (1) Proporcionar los scripts Python del motor LaR (al menos las funciones principales de cálculo y backtesting) para verificar coherencia con la documentación metodológica. (2) Proporcionar reportes de ejecución del backtesting de los últimos 6 meses (p-values de Kupiec/Christoffersen, número de excepciones, estado de alerta) para demostrar que el control se ejecuta sistemáticamente. (3) Proporcionar correos o actas de aprobación de paso a producción firmados por Riesgo y TI. (4) Documentar explícitamente la periodicidad del backtesting (diaria, mensual, trimestral) y cómo se integra en el DAG de Airflow. (5) Proporcionar análisis de umbrales (justificación del umbral de 5 excepciones) y evolutivo histórico del LaR (gráfico de estimados diarios/mensuales de los últimos 12 meses). (6) Documentar las pruebas de aceptación (UAT) realizadas sobre datos de entrada, cálculos intermedios y salidas. Sin esta evidencia, no puede afirmarse que la implementación sea coherente con la metodología ni que esté bajo control en producción.

<sub>cobertura documental 100.0% · RAG LaR (4 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `3a9b240179c4`</sub>

> ✍️ _Conclusión del validador:_
>
---

### Uso e integración a la gestión  ·  score 2.0

#### 🟠 [2/5] Verificar que los usos del modelo se encuentren dentro del alcance original y propósito del modelo

*Control: Revisión de los usos, impactos y usuarios del modelo*

**Qué evalúa.** Verificar que los usos del modelo LaR en producción se encuentren dentro del alcance original, que los usuarios estén formalmente identificados, y que exista evidencia de integración operativa a la gestión (reportes a comités, decisiones documentadas, trazabilidad). Este ámbito es crítico porque un modelo bien construido pero mal usado o fuera de alcance genera riesgo de decisiones no informadas o incumplimiento regulatorio.

**Hallazgo.**

La documentación declara formalmente QUIÉNES usan el modelo (ALCO, Tesorería, Riesgo Regulatorio, CFO) y PARA QUÉ (ajuste de reservas, compra/venta de HQLA, escalamiento a crisis, reporte SFC). Sin embargo, la evidencia de que estos usos OCURREN REALMENTE en operación es COMPLETAMENTE AUSENTE del contexto disponible. El documento 'uso_LaR_gestion.md' es una descripción de INTENCIÓN, no de EJECUCIÓN. No hay: (1) actas de comité ALCO que citen corridas del modelo con ID de ejecución; (2) registros de decisiones de tesorería apoyadas en LaR; (3) reportes SFC que muestren cómo se integró el output; (4) logs de ejecución del DAG que demuestren que la corrida diaria a las 07:00 COT ocurre y es consumida; (5) evidencia de que las alertas por Slack (umbral regulatorio, falla de fuentes) han sido disparadas y actuadas. El documento 'implementacion_LaR.md' describe la ARQUITECTURA TÉCNICA (Airflow, PostgreSQL, Tableau) pero no proporciona EVIDENCIA DE EJECUCIÓN REAL: no hay screenshots de dashboards, no hay logs de corridas exitosas, no hay correos de distribución del reporte diario, no hay actas de comité que referencien el modelo. La afirmación «Cada decisión de tesorería que se apoya en LaR queda registrada en el acta del comité, con referencia al ID de corrida del modelo» es una DECLARACIÓN DE CONTROL, no una DEMOSTRACIÓN de que el control funciona. Para cumplir este ámbito se requiere: (a) al menos 3-5 actas de comité ALCO recientes que citen explícitamente corridas del modelo con ID; (b) registros de decisiones de tesorería (compra/venta de HQLA) con trazabilidad a LaR; (c) un reporte SFC enviado a la Superfinanciera que muestre cómo se integró LaR; (d) logs de ejecución del DAG de los últimos 30 días que demuestren consistencia operativa; (e) evidencia de que las alertas se han disparado y se han actuado. La brecha entre documentación y ejecución es CRÍTICA porque: (i) el modelo puede estar en desarrollo o piloto, no en producción real; (ii) si se usa, puede estar fuera de alcance (ej., decisiones de inversión que no estaban contempladas); (iii) sin trazabilidad, no hay auditoría de si las decisiones fueron informadas o no; (iv) el reporte regulatorio podría estar incompleto o no reflejar el modelo real. Hallazgo inter-ámbito: el contexto de Implementación ya señala una brecha CRÍTICA entre documentación y ejecución operativa (correos de comunicación de resultados no encontrados, puntaje 1/5). Este hallazgo es CONSISTENTE con lo que aquí se observa: la documentación describe un flujo que no tiene evidencia de estar ejecutándose.

**Evidencia citada.**

> uso_LaR_gestion.md → "1. **Comité de Activos y Pasivos (ALCO)** — informe semanal. 2. **Tesorería** — insumo para plan de fondeo diario. 3. **Riesgo Regulatorio** — reporte SFC (Superfinanciera) mensual. 4. **CFO** — dashboard ejecutivo con alertas amarillas/rojas."
>
> uso_LaR_gestion.md → "- Ajuste de reservas de liquidez (Tier 1) cuando LaR proyectado > buffer. - Compra/venta de instrumentos líquidos de alta calidad (HQLA). - Escalamiento al Comité de Crisis si LaR excede 3 sigma del baseline."
>
> uso_LaR_gestion.md → "- Cada decisión de tesorería que se apoya en LaR queda registrada en el acta del comité, con referencia al ID de corrida del modelo."
>
> implementacion_LaR.md → "- Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT. - Persistencia: PostgreSQL (tabla `lar_daily_estimates`)."
>
> implementacion_LaR.md → "- Log estructurado en JSON — retenido 90 días. - Alertas por Slack si: - Tiempo de ejecución > 15 min. - LaR > umbral regulatorio. - Alguna fuente falla o llega vacía."
>
> implementacion_LaR.md → "- Versionado del código en Git (repo `risk-liquidity-models`). - Cada corrida guarda: parámetros, versión de código y hash de datos de entrada."

> ⚠️ **Citas sin coincidencia literal en la evidencia leída.**
> Verifícalas contra el documento original antes de darlas por buenas:
> - «[1/5] La evaluación revela una brecha CRÍTICA entre documentación y evidencia de»
> - «Alertas por Slack si: Tiempo de ejecución > 15 min. LaR > umbral regulatorio. Al»

**Preguntas al modelador.**

- [ ] ¿Existen actas de comité ALCO de los últimos 30 días que citen explícitamente corridas del modelo LaR con ID de ejecución? Si existen, ¿cuál es el patrón de frecuencia y qué decisiones se tomaron basadas en el output?
- [ ] ¿Hay registros operativos (tickets, órdenes de tesorería, confirmaciones de transacción) que tracen decisiones de compra/venta de HQLA a un output específico del modelo LaR? ¿Cómo se documenta esta trazabilidad?
- [ ] ¿Se ha enviado algún reporte SFC a la Superfinanciera que incluya LaR? Si es así, ¿qué período cubre, qué metodología se reportó, y cómo se integró el output del modelo?
- [ ] ¿Existen logs de ejecución del DAG de Airflow de los últimos 30 días que demuestren: (a) que la corrida diaria a las 07:00 COT ocurre consistentemente, (b) que no hay fallos no reportados, (c) que los datos se persisten en PostgreSQL? ¿Cuál es la tasa de éxito observada?
- [ ] ¿Se han disparado alertas por Slack (umbral regulatorio, falla de fuentes, tiempo de ejecución > 15 min) en los últimos 30 días? Si es así, ¿cuántas, cuándo, y qué acciones se tomaron en respuesta?
- [ ] ¿El modelo LaR está inventariado formalmente en el registro de modelos de riesgo de la institución? ¿Cuál es su estado (desarrollo, piloto, producción)? ¿Cuándo se autorizó su paso a producción?
- [ ] ¿Existe documentación del alcance original del modelo (fecha de aprobación, usuarios previstos, decisiones que debía soportar)? ¿Se ha verificado que los usos actuales están dentro de ese alcance, o ha habido extensiones no autorizadas?
- [ ] ¿El dashboard ejecutivo del CFO con alertas amarillas/rojas está activo y siendo consultado? ¿Hay evidencia de que las alertas han disparado acciones (ej., escalamiento a comité de crisis)?
- [ ] ¿Existe un runbook operativo actualizado que documente qué hacer si el DAG falla, si LaR excede 3 sigma, o si hay inconsistencias entre el output de desarrollo y producción? ¿Quién es responsable de ejecutarlo?

**Recomendación.** ACCIÓN INMEDIATA: Recopilar evidencia de ejecución operativa real del modelo LaR en los últimos 30-60 días: (1) actas de comité ALCO con referencias explícitas a corridas del modelo (ID, fecha, output); (2) registros de decisiones de tesorería (órdenes de compra/venta de HQLA) con trazabilidad a LaR; (3) logs de ejecución del DAG de Airflow (al menos 30 días) que demuestren consistencia y ausencia de fallos silenciosos; (4) evidencia de alertas disparadas y actuadas; (5) copia del reporte SFC más reciente que incluya LaR. Si esta evidencia no existe, el modelo NO está en producción real, o está en producción sin integración a la gestión, lo que invalida el cumplimiento de este ámbito. ACCIÓN SECUNDARIA: Verificar que el modelo esté inventariado formalmente, que su alcance original esté documentado, y que los usos actuales estén dentro de ese alcance. Si hay extensiones (ej., uso para decisiones de inversión que no estaban previstas), documentar la autorización de esas extensiones. ACCIÓN TERCERA: Establecer un protocolo de trazabilidad que vincule cada decisión de tesorería que se apoya en LaR a un ID de corrida específico, con registro en acta de comité. Esto debe ser verificable, no solo declarado.

<sub>cobertura documental 100.0% · RAG LaR (3 frag.) · ajuste sesgo: Sin feedback previo similar · prompt `fda2fdcb593e`</sub>

> ✍️ _Conclusión del validador:_
>
---

## 6. Limitaciones del alcance

**Esta sección es obligatoria en el informe final.** Un dictamen que no
declara qué quedó fuera no permite distinguir «esto está bien» de «esto
no se miró».

| Concepto | Valor |
|---|---:|
| Actividades evaluadas correctamente | 29 |
| Actividades sin evidencia | 0 |
| Actividades con fallo técnico | 7 |

**Fallos técnicos** (limitación del agente, NO deficiencia del modelo validado):

- {'ambito': 'Calidad de datos', 'actividad': 'Control_01 — Valida que el manual describa origen, universo, variables, transformaciones y contrles; y que el…', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Calidad de datos', 'actividad': 'Control_02 — Valida la unicidad Cliente por Cuenta en la base usada por el proceso', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Calidad de datos', 'actividad': 'Control_03 — Valida la unicidad de FechaVencimiento por combinación Cuenta+FechaApertura', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Calidad de datos', 'actividad': 'Control_04 — Valida la unicidad de Tasa de Interes por Cuenta', 'error': 'Informativo: la calificación de calidad de datos la gobiernan los motores ejecutados por el validador.'}
- {'ambito': 'Metodología', 'actividad': 'Validar supuestos y consideración más importantes de la técnica utilizada', 'error': 'La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0)'}
- {'ambito': 'Metodología', 'actividad': 'Revisión de los lineamiento internacionales o nacionales', 'error': 'La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0)'}
- {'ambito': 'Metodología', 'actividad': 'Analizar el seguimeinto de la metodología', 'error': 'La respuesta no cumple el contrato esperado: JSON malformado en la respuesta: Objeto JSON incompleto (llaves sin cerrar): line 1 column 1 (char 0)'}

**112 cita(s) sin verificar literalmente.** Marcadas en
el detalle. Revísalas antes de firmar.

> ✍️ **Te toca:** traslada esta sección al informe final tal cual.
> Es lo que un supervisor busca primero.

---

<sub>Generado por VIRF 27.1 · claude-haiku-4-5-20251001 el 2026-08-31 18:15. Documento de trabajo interno; el entregable es el informe Word. El agente no firma: firma el validador.</sub>
