# Revisión de código contra documentación — VaR Mercado FRTB

Generado por `modulos/revision_codigo.py` el 2026-08-06 20:05.

## Resumen

- Módulos revisados: **0/1**
- Llamadas al modelo: 1
- Hallazgos: **0**
- Anclados en la documentación: **0** (sin anclar: 0)
- Revisión confiable: **False**

> ⚠️ **1 módulo(s) no se revisaron por fallo técnico.** La revisión está incompleta; re-ejecuta antes de emitir dictamen.

### Por severidad

- 🔴 critica: 0
- 🟠 alta: 0
- 🟡 media: 0
- ⚪ baja: 0

### Por categoría

- `no_documentado` (Existe en el código y el manual no lo declara): 0
- `documentado_ausente` (El manual lo declara y no existe en el código): 0
- `code_drift` (Existe en ambos pero no coinciden (fórmula, parámetro, umbral)): 0
- `supuesto_tacito` (El código asume algo que el manual no declara ni justifica): 0
- `riesgo_tecnico` (Defecto que afecta al resultado del modelo): 0

## Hallazgos

Ninguno. El código revisado es coherente con la documentación.
## Inventario de módulos

| Módulo | Chars | Hallazgos | Revisión |
|---|---:|---:|---|
| `calcula_var.py` | 205 | 0 | ❌ fallo |
