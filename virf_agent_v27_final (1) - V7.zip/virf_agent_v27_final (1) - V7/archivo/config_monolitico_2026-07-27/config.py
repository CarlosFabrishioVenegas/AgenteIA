"""
config.py
═════════════════════════════════════════════════════════════════════════════

CONFIGURACIÓN CENTRALIZADA DEL AGENTE VIRF
Soporta solo: Anthropic Claude y Azure OpenAI

Este es el ÚNICO archivo que necesitas editar para cambiar:
  ✅ API (Anthropic o Azure OpenAI)
  ✅ API Key
  ✅ Parámetros globales
  ✅ Rutas del proyecto

USO:
    from config import get_cliente_ia
    cliente = get_cliente_ia()
    respuesta = cliente.generar_mensaje(prompt="Tu pregunta")

═════════════════════════════════════════════════════════════════════════════
"""

import os
from pathlib import Path
from typing import Optional
from abc import ABC, abstractmethod
from dotenv import load_dotenv

# Cargar variables de entorno desde .env
load_dotenv()

# ═════════════════════════════════════════════════════════════════════════════
# ▼▼▼ EDITA AQUÍ PARA CAMBIAR DE API ▼▼▼
# ═════════════════════════════════════════════════════════════════════════════

# Selecciona tu proveedor de IA
# Opciones: "anthropic" | "azure_openai"
IA_PROVEEDOR = os.getenv("IA_PROVEEDOR", "anthropic").lower()

# Parámetros globales
MAX_CHARS_DOC = int(os.getenv("MAX_CHARS_DOC", 15000))    # [FIX-DOC] Sincronizado con Mx_00
MAX_CHARS_CODIGO = int(os.getenv("MAX_CHARS_CODIGO", 8000)) # [FIX-DOC] Sincronizado con Mx_00
MAX_FILAS_EXCEL = int(os.getenv("MAX_FILAS_EXCEL", 200))   # [FIX-DOC] Sincronizado con Mx_00
TIMEOUT_SEGUNDOS = int(os.getenv("TIMEOUT_SEGUNDOS", 30))
REINTENTOS_API = int(os.getenv("REINTENTOS_API", 3))
MODO = os.getenv("MODO", "debug").lower()  # "debug" | "produccion"

# ═════════════════════════════════════════════════════════════════════════════
# RUTAS DEL PROYECTO
# ═════════════════════════════════════════════════════════════════════════════

BASE_DIR = Path(__file__).parent
ESTANDARES_PATH = BASE_DIR / "inputs" / "Estandares_VIRF.xlsx"
OUTPUTS_DIR = BASE_DIR / "outputs"
AUDIT_LOGS_DIR = BASE_DIR / "audit_logs"
REPOSITORIO_INFORMES = BASE_DIR / "repositorio_informes"

INPUTS = {
    "doc_modelamiento": BASE_DIR / "inputs" / "documentacion" / "modelamiento",
    "doc_seguimiento": BASE_DIR / "inputs" / "documentacion" / "seguimiento",
    "papers": BASE_DIR / "inputs" / "papers",
    "calidad_datos": BASE_DIR / "inputs" / "calidad_datos",
    "implementacion": BASE_DIR / "inputs" / "implementacion",
    "usos": BASE_DIR / "inputs" / "usos",
    "repositorio": BASE_DIR / "repositorio_informes",
}

# ─── TIERS ──────────────────────────────────────────────────────────────────
TIER_COLUMNS = {
    "I": "TIER I",
    "II": "TIER II",
    "III": "TIER III",
    "IV": "TIER IV",
}

# ─── ÁMBITOS Y PESOS PARA SCORE GLOBAL ──────────────────────────────────────
# [D4-FIX] Pesos anclados a estándares regulatorios internacionales.
# Referencias normativas:
#   SR 11-7  (Fed 2011) — §IV "Model validation": énfasis en conceptual soundness
#             (Metodología) y ongoing monitoring (Seguimiento/Calidad de datos).
#   EBA/GL/2023/01 — §6.3: governance & documentation como pilares de validación.
#   BCBS 239 (2013) — principios 3-5: data governance, data architecture.
#   SBS Res. 9075-2012 — Art. 9: gestión del riesgo de liquidez.
#
# Distribución de pesos:
#   Metodología 0.30  ← SR 11-7 §IV: "conceptual soundness" = componente central
#   Calidad de datos 0.20 ← BCBS 239 principios 3-5: data governance crítico
#   Documentación 0.15 ← EBA/GL/2023/01 §6.3: evidencia tratable para auditor
#   Implementación 0.15 ← SR 11-7 §IV: "outcome analysis" e implementación fiel
#   Gobierno 0.12      ← EBA/GL/2023/01 §5: model inventory + tiering obligatorio
#   Uso e integración 0.08 ← SR 11-7 §IV: "ongoing monitoring" del uso efectivo
#
# SUMA = 1.00
# Fuente formal: VIRF_Pesos_Justificacion_Regulatoria_v1.md (docs/)
AMBITO_PESOS = {
    "Documentación":                 0.15,
    "Calidad de datos":              0.20,
    "Metodología":                   0.30,
    "Gobierno":                      0.12,
    "Implementación":                0.15,
    "Uso e integración a la gestión": 0.08,
}

# Metadatos de trazabilidad de pesos (para JSON de resultados y auditoría)
AMBITO_PESOS_REFS = {
    "Documentación":                 "EBA/GL/2023/01 §6.3",
    "Calidad de datos":              "BCBS 239 principios 3-5",
    "Metodología":                   "SR 11-7 §IV conceptual soundness",
    "Gobierno":                      "EBA/GL/2023/01 §5",
    "Implementación":                "SR 11-7 §IV outcome analysis",
    "Uso e integración a la gestión": "SR 11-7 §IV ongoing monitoring",
}

# ─── ESCALA DE PUNTAJE ──────────────────────────────────────────────────────
ESCALA_PUNTAJE = {
    1: {"label": "No cumple", "color": "FF0000"},
    2: {"label": "Cumple parcialmente - obs. críticas", "color": "FF6600"},
    3: {"label": "Cumple parcialmente", "color": "FFCC00"},
    4: {"label": "Cumple con observaciones menores", "color": "92D050"},
    5: {"label": "Cumple plenamente", "color": "00B050"},
}

SCORE_SEMAFORO = {
    (4.5, 5.0): {"label": "SATISFACTORIO", "color": "00B050"},
    (3.5, 4.5): {"label": "ACEPTABLE", "color": "92D050"},
    (2.5, 3.5): {"label": "CON OBSERVACIONES", "color": "FFCC00"},
    (1.5, 2.5): {"label": "DEFICIENTE", "color": "FF6600"},
    (0.0, 1.5): {"label": "CRÍTICO", "color": "FF0000"},
}

# ─── PREGUNTAS METODOLÓGICAS POR ÁMBITO ────────────────────────────────────
PREGUNTAS_METODOLOGICAS = {
    "Documentación": [
        "¿Existe un manual metodológico con control de versiones?",
        "¿El manual operativo describe el proceso de ejecución paso a paso?",
        "¿Los documentos de seguimiento incluyen backtesting (Kupiec, Christoffersen)?",
        "¿El informe de seguimiento cubre monitoreo de calidad de datos?",
    ],
    "Calidad de datos": [
        "¿Existe un script _replica_virf.py o equivalente de control de datos?",
        "¿Se documentan controles sobre missing values, duplicados y outliers?",
        "¿Existen reportes de incidencias de calidad de datos?",
        "¿Se verifica la actualización periódica de los inputs?",
    ],
    "Metodología": [
        "¿Se justifica la elección del modelo estocástico/ML utilizado?",
        "¿Se validan los supuestos principales del modelo?",
        "¿Se referencian lineamientos internacionales o regulatorios?",
        "¿Existe backtesting o planificación de seguimiento?",
        "¿Se realizan análisis de sensibilidad o escenarios?",
    ],
    "Gobierno": [
        "¿El modelo tiene tiering asignado y actualizado?",
        "¿El modelo se encuentra en el inventario oficial?",
    ],
    "Implementación": [
        "¿Se documentan las fuentes de información empleadas?",
        "¿Existen correos de conformidad de resultados con primera línea?",
        "¿El manual de implementación es coherente con el metodológico?",
        "¿Se documentan pruebas iniciales de implementación?",
    ],
    "Uso e integración a la gestión": [
        "¿Los usos del modelo están dentro del alcance original?",
        "¿El modelo no estaba en uso antes de concluir la validación?",
        "¿Se identifican formalmente los usuarios del modelo?",
        "¿Existe reporting de integración a la gestión?",
    ],
}

# ─── EXTENSIONES LEGIBLES ──────────────────────────────────────────────────
EXTENSIONES_SOPORTADAS = [".pdf", ".docx", ".pptx", ".xlsx", ".py", ".json", ".txt", ".csv"]

# ═════════════════════════════════════════════════════════════════════════════
# CLIENTES IA: Interfaz agnóstica para proveedores
# ═════════════════════════════════════════════════════════════════════════════

def _detectar_key_en_example(api_key: str) -> Optional[str]:
    """
    [SEC-FIX] Devuelve la ruta de .env.example si la clave activa aparece
    literalmente en él (indicio de clave real commiteada). None si está limpio.

    Se compara solo si la clave tiene pinta de credencial real (>20 chars),
    para no disparar falsos positivos con placeholders cortos.
    """
    if not api_key or len(api_key) < 20:
        return None
    ejemplo = BASE_DIR / ".env.example"
    try:
        if ejemplo.exists() and api_key in ejemplo.read_text(encoding="utf-8", errors="ignore"):
            return str(ejemplo)
    except Exception:
        pass
    return None


class ClienteIA(ABC):
    """Interfaz abstracta para clientes IA"""
    
    @abstractmethod
    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "", max_tokens: int = None, sistema: str = None) -> str:
        """Genera respuesta"""
        pass
    
    @abstractmethod
    def validar_conexion(self) -> bool:
        """Valida conexión a la API"""
        pass

# ─── Anthropic Claude ──────────────────────────────────────────────────────

class ClienteAnthropicIA(ClienteIA):
    """Cliente para Anthropic Claude"""
    
    def __init__(self):
        try:
            import anthropic
        except ImportError:
            raise ImportError("❌ pip install anthropic")
        
        api_key = os.getenv("ANTHROPIC_API_KEY", "")

        # [v17] Detectar keys vacías O placeholders antes de cualquier llamada API
        _PLACEHOLDERS = {
            "TU_API_KEY_AQUI", "YOUR_REAL_API_KEY_HERE_NEVER_COMMIT",
            "tu-api-key", "tu_api_key", "xxx",
        }
        es_placeholder = (
            not api_key
            or api_key in _PLACEHOLDERS
            or any(p in api_key for p in (
                "YOUR_REAL", "TU_API_KEY", "NEVER_COMMIT",
                "your_key", "placeholder",
            ))
        )
        if es_placeholder:
            raise ValueError(
                "\n"
                "❌ ANTHROPIC_API_KEY no está configurada o contiene un placeholder.\n"
                "\n"
                "   Cómo solucionarlo:\n"
                "   1. Abre el archivo  .env  en la raíz del proyecto.\n"
                "   2. Reemplaza:\n"
                "        ANTHROPIC_API_KEY=TU_API_KEY_AQUI\n"
                "      por tu clave real de Anthropic:\n"
                "        ANTHROPIC_API_KEY=sk-ant-api03-...\n"
                "   3. Obtén tu clave en: https://console.anthropic.com/\n"
            )

        # [SEC-FIX] Guardia anti-fuga: si la clave activa es la misma que aparece
        # en .env.example, significa que alguien commiteó una clave real (o que
        # el usuario copió la plantilla sin cambiarla). Abortamos y avisamos.
        _leak = _detectar_key_en_example(api_key)
        if _leak:
            raise ValueError(
                "\n"
                "🔴 RIESGO DE SEGURIDAD: la ANTHROPIC_API_KEY en uso es idéntica a\n"
                f"   la que aparece en {_leak}\n"
                "\n"
                "   .env.example SE COMMITEA al repositorio → esa clave está expuesta.\n"
                "\n"
                "   Acciones requeridas:\n"
                "   1. Revoca la clave en https://console.anthropic.com/settings/keys\n"
                "   2. Genera una nueva y ponla SOLO en .env (nunca en .env.example)\n"
                "   3. Deja en .env.example el placeholder: ANTHROPIC_API_KEY=TU_API_KEY_AQUI\n"
            )

        self.cliente = anthropic.Anthropic(api_key=api_key)
        self.modelo = os.getenv("ANTHROPIC_MODELO", "claude-sonnet-4-6")  # [FIX-MOD] Sincronizado con Mx_00
        self.max_tokens_default = int(os.getenv("ANTHROPIC_MAX_TOKENS", 4096))
    
    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "", max_tokens: int = None, sistema: str = None) -> str:
        """Genera mensaje con soporte para parámetros alternativos"""
        sys_prompt = sistema or instruccion_sistema or "Eres un auditor experto."
        tokens = max_tokens or self.max_tokens_default
        
        try:
            response = self.cliente.messages.create(
                model=self.modelo,
                max_tokens=tokens,
                system=sys_prompt,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text
        except Exception as e:
            raise RuntimeError(f"❌ Error Anthropic: {e}")
    
    def validar_conexion(self) -> bool:
        try:
            self.cliente.messages.create(
                model=self.modelo,
                max_tokens=100,
                system="Test",
                messages=[{"role": "user", "content": "test"}],
            )
            return True
        except Exception as e:
            print(f"⚠️  Validación Anthropic: {e}")
            return False

# ─── Azure OpenAI ────────────────────────────────────────────────────────

class ClienteAzureOpenAIIA(ClienteIA):
    """Cliente para Azure OpenAI"""
    
    def __init__(self):
        try:
            from openai import AzureOpenAI
        except ImportError:
            raise ImportError("❌ pip install openai")
        
        api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
        deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")
        
        if not api_key:
            raise ValueError("❌ AZURE_OPENAI_API_KEY no configurada")
        if not endpoint:
            raise ValueError("❌ AZURE_OPENAI_ENDPOINT no configurado")
        if not deployment:
            raise ValueError("❌ AZURE_OPENAI_DEPLOYMENT no configurado")
        
        self.cliente = AzureOpenAI(
            api_key=api_key,
            api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
            azure_endpoint=endpoint,
        )
        self.deployment = deployment
        self.max_tokens_default = int(os.getenv("AZURE_OPENAI_MAX_TOKENS", 4096))
    
    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "", max_tokens: int = None, sistema: str = None) -> str:
        """Genera mensaje con soporte para parámetros alternativos.

        [v18] BUG FIX: el parámetro 'system' no existe en chat.completions.create()
        de Azure OpenAI. El sistema debe enviarse como primer mensaje con
        role='system' dentro del array messages.
        """
        sys_prompt = sistema or instruccion_sistema or "Eres un auditor experto."
        tokens = max_tokens or self.max_tokens_default

        try:
            response = self.cliente.chat.completions.create(
                model=self.deployment,
                max_tokens=tokens,
                messages=[
                    {"role": "system", "content": sys_prompt},
                    {"role": "user",   "content": prompt},
                ],
            )
            return response.choices[0].message.content
        except Exception as e:
            raise RuntimeError(f"❌ Error Azure OpenAI: {e}")
    
    def validar_conexion(self) -> bool:
        try:
            self.cliente.chat.completions.create(
                model=self.deployment,
                max_tokens=100,
                messages=[{"role": "user", "content": "test"}],
            )
            return True
        except:
            return False

# ═════════════════════════════════════════════════════════════════════════════
# FACTORY: Crear cliente según proveedor
# ═════════════════════════════════════════════════════════════════════════════

FABRICAS = {
    "anthropic": ClienteAnthropicIA,
    "azure_openai": ClienteAzureOpenAIIA,
}

def _validar_consistencia_modelo() -> None:
    """
    [v17] Mx_00_CargaRutas ahora lee MODELO_CLAUDE desde os.getenv(), igual que
    config.py. No puede haber inconsistencia. Función conservada por compatibilidad.
    """
    pass  # noop: ambos configs leen del mismo .env
# [PERF-FIX] Cliente cacheado a nivel de proceso.
# Antes: cada llamada a get_cliente_ia() construía un cliente nuevo Y ejecutaba
# validar_conexion(), que hace una llamada API REAL de prueba. En una corrida
# Tier 1 esto suponía ~17 requests desperdiciados (100% de sobrecoste).
# Ahora: se construye una sola vez por proceso y la validación es opcional.
_CLIENTE_CACHE: Optional[ClienteIA] = None
_VALIDAR_CONEXION = os.getenv("VIRF_VALIDAR_CONEXION", "0") == "1"


def get_cliente_ia(forzar_recarga: bool = False) -> ClienteIA:
    """
    Devuelve el cliente IA según IA_PROVEEDOR configurado.

    [PERF-FIX] El cliente se cachea a nivel de proceso: llamar a esta función
    N veces construye el cliente UNA sola vez. Esto elimina el 50% de las
    llamadas a la API que se hacían antes (una de validación por evaluación).

    [PERF-FIX] La llamada de validación (`validar_conexion()`) solo se ejecuta
    si VIRF_VALIDAR_CONEXION=1 en .env. Por defecto está desactivada: un fallo
    de credenciales se manifiesta igualmente en la primera llamada real, con
    un mensaje claro, y sin gastar un request extra por proceso.

    Args:
        forzar_recarga: reconstruye el cliente ignorando la caché
                        (útil en tests o si cambia la configuración en runtime).

    Returns:
        ClienteIA listo para usar.

    Raises:
        RuntimeError si la configuración es inválida o no hay conexión.
    """
    global _CLIENTE_CACHE

    if _CLIENTE_CACHE is not None and not forzar_recarga:
        return _CLIENTE_CACHE

    _validar_consistencia_modelo()  # [FIX-MOD]
    proveedor = IA_PROVEEDOR

    if proveedor not in FABRICAS:
        raise ValueError(
            f"❌ Proveedor no soportado: {proveedor}. Opciones: {', '.join(FABRICAS)}"
        )

    try:
        cliente = FABRICAS[proveedor]()

        if _VALIDAR_CONEXION:
            if not cliente.validar_conexion():
                raise RuntimeError(f"❌ No se pudo conectar a {proveedor.upper()}")
            estado = "conexión verificada"
        else:
            estado = "sin verificar (VIRF_VALIDAR_CONEXION=0)"

        modelo = os.getenv(f"{proveedor.upper()}_MODELO", "default")
        print(f"✅ Cliente IA listo: {proveedor} ({modelo}) — {estado}")

        _CLIENTE_CACHE = cliente
        return cliente

    except ValueError:
        raise  # errores de configuración/seguridad se propagan con su mensaje original
    except Exception as e:
        raise RuntimeError(f"❌ Error inicializando IA: {e}")


def reset_cliente_ia() -> None:
    """Limpia la caché del cliente (para tests o recarga de configuración)."""
    global _CLIENTE_CACHE
    _CLIENTE_CACHE = None

# ═════════════════════════════════════════════════════════════════════════════
# VALIDAR Y MOSTRAR RESUMEN
# ═════════════════════════════════════════════════════════════════════════════

def mostrar_configuracion():
    """Muestra resumen de la configuración actual"""
    print("\n" + "=" * 80)
    print("📋 CONFIGURACIÓN AGENTE VIRF")
    print("=" * 80)
    print(f"  🤖 Proveedor IA:     {IA_PROVEEDOR.upper()}")
    print(f"  🔧 Max tokens:       {MAX_CHARS_DOC} (doc) / {MAX_CHARS_CODIGO} (código)")
    print(f"  📂 Base dir:         {BASE_DIR}")
    print(f"  📊 Estandares:       {ESTANDARES_PATH.name}")
    print(f"  💾 Outputs:          {OUTPUTS_DIR}")
    print("=" * 80 + "\n")

# Validar configuración al importar
try:
    if not ESTANDARES_PATH.exists():
        print(f"⚠️  Advertencia: {ESTANDARES_PATH} no encontrado")
except:
    pass

# ═════════════════════════════════════════════════════════════════════════════
# EXPORTS
# ═════════════════════════════════════════════════════════════════════════════

__all__ = [
    # Configuración
    "BASE_DIR", "ESTANDARES_PATH", "OUTPUTS_DIR", "AUDIT_LOGS_DIR",
    "INPUTS", "REPOSITORIO_INFORMES",
    "MAX_CHARS_DOC", "MAX_CHARS_CODIGO", "MAX_FILAS_EXCEL",
    "TIMEOUT_SEGUNDOS", "REINTENTOS_API",
    "IA_PROVEEDOR", "MODO",
    
    # Dominios
    "TIER_COLUMNS", "AMBITO_PESOS", "AMBITO_PESOS_REFS", "ESCALA_PUNTAJE", "SCORE_SEMAFORO",
    "PREGUNTAS_METODOLOGICAS", "EXTENSIONES_SOPORTADAS",
    
    # Funciones
    "get_cliente_ia", "mostrar_configuracion",
    
    # Clientes
    "ClienteIA", "ClienteAnthropicIA", "ClienteAzureOpenAIIA",
]
