#!/usr/bin/env python3
"""
test_challenger_con_rag.py
===========================
Demuestra que el Challenger Model ahora:
1. Usa el RAG para extraer referencias
2. Genera Notebooks con información consisa
3. Integra las skills del agente
"""
# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import sys
from pathlib import Path

_ROOT = Path(__file__).parent
sys.path.insert(0, str(_ROOT))

from agent.virf_agent import VIRFAgent


def main():
    print("=" * 70)
    print("🎯 TEST: CHALLENGER MODEL CON RAG")
    print("=" * 70)
    print()
    
    # 1. Crear agente
    print("[1/3] Inicializando agente...")
    agente = VIRFAgent(
        titulo_modelo="Modelo LaR Cartera Corporativa v3",
        dominio="LaR"
    )
    print(f"✓ Agente listo")
    print()
    
    # 2. Simular detección de hallazgos
    print("[2/3] Simulando detección de hallazgos...")
    hallazgos_simulados = [
        {
            "tipo": "formula",
            "gravedad": "CRÍTICO",
            "descripcion": "VaR paramétrico con signo incorrecto: VaR = μ + σ·z implica pérdida positiva",
            "correccion": "VaR = -(μ - σ · z_α) o equivalentemente VaR = σ·z_α - μ para pérdida positiva",
            "referencia": "Jorion (2006) Value at Risk, cap. 5.",
            "fuente": "formula_detector"
        },
        {
            "tipo": "formula",
            "gravedad": "CRÍTICO",
            "descripcion": "Volatilidad anualizada sin raíz de tiempo",
            "correccion": "σ_annual = σ_daily × √252",
            "referencia": "Gujarati & Porter (2009)",
            "fuente": "methodology_checker"
        },
        {
            "tipo": "metodologia",
            "gravedad": "ALTO",
            "descripcion": "Correlación perfecta (ρ=1) entre activos. Este supuesto sobreestima el riesgo",
            "correccion": "Estimar matriz de correlaciones con período de observación real (mínimo 252 días)",
            "referencia": "Basel Committee (2011) SR 11-7",
            "fuente": "methodology_checker"
        },
        {
            "tipo": "metodologia",
            "gravedad": "MEDIO",
            "descripcion": "Se usa z=1.645 (Normal estándar al 95%) sin verificar normalidad de los retornos",
            "correccion": "Aplicar test Jarque-Bera/Shapiro-Wilk antes de asumir distribución Normal",
            "referencia": "Kupiec (1995) Testing Parametric VaR",
            "fuente": "formula_detector"
        }
    ]
    
    for h in hallazgos_simulados:
        agente._registrar_hallazgo(h)
    
    print(f"✓ {len(agente.hallazgos)} hallazgos registrados")
    print()
    
    # 3. Generar Challenger CON RAG
    print("[3/3] Generando Challenger Model (ahora CON RAG + Skills)...")
    print()
    
    ruta_notebook = agente.generar_challenger()
    
    if ruta_notebook:
        print()
        print("=" * 70)
        print("✅ ÉXITO: CHALLENGER GENERADO CON RAG")
        print("=" * 70)
        print()
        print(f"Notebook generado en: {ruta_notebook}")
        print()
        print("🎁 El Notebook incluye:")
        print("   ✓ Hallazgos resumidos")
        print("   ✓ Referencias del RAG (si disponible)")
        print("   ✓ Modelo Original con errores documentados")
        print("   ✓ Modelo Challenger mejorado")
        print("   ✓ Datos de prueba (252 observaciones)")
        print("   ✓ Backtesting comparativo")
        print("   ✓ Visualizaciones lado-a-lado")
        print("   ✓ Recomendaciones implementadas")
        print("   ✓ Pasos prácticos de corrección")
        print()
        print("📖 Para abrir el notebook:")
        print(f"   jupyter notebook '{ruta_notebook}'")
    else:
        print("❌ Error generando Challenger")
        sys.exit(1)


if __name__ == "__main__":
    main()
