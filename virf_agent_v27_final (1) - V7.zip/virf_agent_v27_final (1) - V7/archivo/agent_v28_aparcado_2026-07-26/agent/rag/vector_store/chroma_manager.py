"""
====================================================================
ARCHIVO: rag/vector_store/chroma_manager.py
====================================================================

OBJETIVO:
    Gestionar el vector store local con ChromaDB para almacenar y
    recuperar embeddings de documentos (PDFs académicos, papers,
    reports) usados en el pipeline RAG del agente.

PARA QUÉ SIRVE:
    Es la capa de persistencia del sistema RAG. Cuando el script
    build_embeddings.py indexa los papers académicos (sales,
    marketing, ML, business), los embeddings se guardan aquí.
    El agente los recupera en tiempo real cuando el usuario hace
    preguntas sobre literatura o best practices.

POR QUÉ ES NECESARIO:
    Sin ChromaManager, el RAG no tiene dónde persistir los embeddings.
    SemanticSearcher y EmbeddingGenerator dependen de este componente
    para guardar y recuperar vectores entre ejecuciones.

QUÉ PASA SI SE ELIMINA:
    - El sistema RAG deja de funcionar completamente.
    - Preguntas sobre papers/documentos no pueden recuperar contexto.
    - El agente responde esas preguntas desde conocimiento general
      del LLM (sin grounding en documentos propios del proyecto).
    - build_embeddings.py falla al intentar persistir.

LÓGICA DE NEGOCIO:
    ChromaDB persiste en data/vector_store/ como:
    - chroma.sqlite3: metadata e índice SQLite
    - {collection_id}/: archivos binarios HNSW (índice de vecinos)
    
    add_documents(chunks, embeddings) → indexa N fragmentos
    search(query_embedding, top_k)   → retorna top-K similares

FLUJO DE DATOS:
    [build_embeddings.py]
    PDFs → EmbeddingGenerator → vectores → ChromaManager.add_documents()

    [agent.py → rag]
    query → EmbeddingGenerator → vector → ChromaManager.search() → chunks

DEPENDENCIAS CRÍTICAS:
    - chromadb >= 0.4    : pip install chromadb
    - data/vector_store/ : directorio de persistencia (debe existir)

RIESGOS:
    - Si chromadb no está instalado → ImportError; el RAG se desactiva
      graciosamente en agent.py (try/except en _init_rag()).
    - El índice HNSW puede corromperse si el proceso se interrumpe
      durante add_documents(). Solución: re-ejecutar build_embeddings.py.
    - Sin versionado: si los papers cambian, hay que re-indexar
      manualmente.

ESCALABILIDAD:
    - Eficiente hasta ~100K fragmentos (suficiente para el proyecto).
    - Para más de 1M vectores: migrar a Pinecone, Weaviate o pgvector.
    - La búsqueda HNSW es aproximada pero muy rápida (ms incluso con
      100K vectores).

IMPACTO DE NEGOCIO:
    MEDIO. Habilita respuestas fundamentadas en papers académicos,
    lo que aumenta credibilidad del agente ante stakeholders técnicos.

NIVEL DE CRITICIDAD:
    MEDIO

NOTAS TÉCNICAS:
    - persist_directory = "data/vector_store/" (relativo al working dir)
    - La colección por defecto se llama "papers" (nombre configurable).
    - count() retorna 0 si la colección está vacía o no existe.
    - ChromaDB maneja la persistencia automáticamente al añadir docs.

====================================================================
"""

import logging
from typing import List, Dict, Any, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Ruta de persistencia por defecto
DEFAULT_PERSIST_DIR = "data/vector_store"


class ChromaManager:
    """
    Gestor de ChromaDB para RAG local.

    Uso:
        mgr = ChromaManager("papers_sales")
        mgr.add_documents(chunks, embeddings)
        results = mgr.search(query_vec, top_k=5)

    La colección se persiste automáticamente en data/vector_store/.
    """

    def __init__(
        self,
        collection_name: str = "sales_ai_docs",
        persist_dir: str = DEFAULT_PERSIST_DIR,
    ):
        self.collection_name = collection_name
        self.persist_dir = persist_dir
        self._client = None
        self._collection = None

    # ── lazy init ──────────────────────────────────────────────────────────────

    def _get_collection(self):
        """
        Inicializa ChromaDB y la colección de forma lazy.

        Por qué lazy:
            ChromaDB tarda ~1s al arrancar (carga SQLite + índice HNSW).
            Si el agente no usa RAG en esa sesión, no pagamos ese costo.
        """
        if self._collection is None:
            try:
                import chromadb
            except ImportError:
                raise ImportError(
                    "chromadb no está instalado.\n"
                    "Instalar con: pip install chromadb"
                )

            Path(self.persist_dir).mkdir(parents=True, exist_ok=True)
            self._client = chromadb.PersistentClient(path=self.persist_dir)
            self._collection = self._client.get_or_create_collection(
                name=self.collection_name,
                metadata={"hnsw:space": "cosine"},  # similitud coseno
            )
            logger.info(
                f"ChromaDB listo — colección '{self.collection_name}' "
                f"en {self.persist_dir} "
                f"({self._collection.count()} docs existentes)"
            )
        return self._collection

    # ── API pública ───────────────────────────────────────────────────────────

    def add_documents(
        self,
        chunks: List[Dict[str, Any]],
        embeddings: List[List[float]],
    ) -> int:
        """
        Indexa documentos en ChromaDB.

        Args:
            chunks:     Lista de dicts con keys: text, source, page, chunk_index.
                        Output directo de TextChunker.chunk_text().
            embeddings: Lista de vectores float (mismo orden que chunks).
                        Output directo de EmbeddingGenerator.batch_generate().

        Returns:
            Número de documentos añadidos.

        Por qué usar metadatas:
            ChromaDB permite filtrar por metadata en la búsqueda.
            Guardar source y page permite citar exactamente de dónde vino
            cada fragmento recuperado.
        """
        if not chunks or not embeddings:
            logger.warning("add_documents llamado con listas vacías")
            return 0

        if len(chunks) != len(embeddings):
            raise ValueError(
                f"chunks ({len(chunks)}) y embeddings ({len(embeddings)}) "
                "deben tener la misma longitud"
            )

        collection = self._get_collection()

        ids = []
        documents = []
        metadatas = []

        for chunk, emb in zip(chunks, embeddings):
            doc_id = f"{chunk['source']}__p{chunk['page']}__c{chunk['chunk_index']}"
            ids.append(doc_id)
            documents.append(chunk["text"])
            metadatas.append({
                "source": chunk.get("source", "unknown"),
                "page": chunk.get("page", 0),
                "chunk_index": chunk.get("chunk_index", 0),
                "char_start": chunk.get("char_start", 0),
            })

        # upsert evita duplicados si se re-indexa el mismo documento
        collection.upsert(
            ids=ids,
            documents=documents,
            embeddings=embeddings,
            metadatas=metadatas,
        )

        logger.info(f"Indexados {len(chunks)} chunks en '{self.collection_name}'")
        return len(chunks)

    def search(
        self,
        query_embedding: List[float],
        top_k: int = 5,
        where: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Busca documentos por similitud coseno.

        Args:
            query_embedding: Vector de la query (output de EmbeddingGenerator).
            top_k:           Número máximo de resultados.
            where:           Filtro de metadata opcional.
                             Ejemplo: {"source": "ventas_q3.pdf"}

        Returns:
            Lista de dicts con keys: text, source, page, chunk_index, score.
            Ordenados de mayor a menor similitud.
        """
        collection = self._get_collection()

        if collection.count() == 0:
            logger.warning("La colección está vacía — ejecuta build_embeddings.py primero")
            return []

        query_kwargs = {
            "query_embeddings": [query_embedding],
            "n_results": min(top_k, collection.count()),
            "include": ["documents", "metadatas", "distances"],
        }
        if where:
            query_kwargs["where"] = where

        result = collection.query(**query_kwargs)

        docs = result["documents"][0]
        metas = result["metadatas"][0]
        dists = result["distances"][0]  # distancia coseno: 0=idéntico, 2=opuesto

        output = []
        for doc, meta, dist in zip(docs, metas, dists):
            # Convertir distancia coseno a score de similitud [0, 1]
            score = round(1 - dist / 2, 4)
            output.append({
                "text": doc,
                "source": meta.get("source", "unknown"),
                "page": meta.get("page", 0),
                "chunk_index": meta.get("chunk_index", 0),
                "score": score,
            })

        return output

    def search_by_text(
        self,
        query_text: str,
        embedder,  # instancia de EmbeddingGenerator
        top_k: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Atajo: genera embedding de query_text y busca.
        Conveniente para uso directo sin gestionar embeddings manualmente.

        Args:
            query_text: Texto de la pregunta del usuario.
            embedder:   Instancia de EmbeddingGenerator.
            top_k:      Número de resultados.
        """
        query_vec = embedder.generate(query_text)
        return self.search(query_vec, top_k=top_k)

    def delete_collection(self):
        """Elimina la colección completa. Útil para re-indexar desde cero."""
        if self._client is not None:
            self._client.delete_collection(self.collection_name)
            self._collection = None
            logger.info(f"Colección '{self.collection_name}' eliminada")

    def count(self) -> int:
        """Número de documentos indexados actualmente."""
        try:
            return self._get_collection().count()
        except Exception:
            return 0

    def get_sources(self) -> List[str]:
        """Lista de fuentes únicas indexadas en la colección."""
        try:
            collection = self._get_collection()
            if collection.count() == 0:
                return []
            result = collection.get(include=["metadatas"])
            sources = list({m["source"] for m in result["metadatas"]})
            return sorted(sources)
        except Exception as e:
            logger.warning(f"No se pudo obtener fuentes: {e}")
            return []

