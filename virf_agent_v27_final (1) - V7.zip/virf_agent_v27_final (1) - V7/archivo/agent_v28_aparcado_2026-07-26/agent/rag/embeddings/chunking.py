"""
====================================================================
ARCHIVO: rag/embeddings/chunking.py
====================================================================

OBJETIVO:
    Dividir documentos largos (PDFs académicos) en fragmentos
    (chunks) de tamaño manejable para su indexación en el vector
    store. Es el paso de pre-procesamiento previo a la generación
    de embeddings.

PARA QUÉ SIRVE:
    Los LLMs y los modelos de embeddings tienen límites de tokens
    de entrada. Un paper de 20 páginas no puede embeberse como un
    solo vector (perdería granularidad). Este módulo lo divide en
    fragmentos solapados para que:
    1. Cada chunk quepa en el contexto del modelo de embeddings.
    2. El solapamiento preserve contexto entre fragmentos contiguos.
    3. La búsqueda semántica recupere el fragmento exacto relevante.


    Divide textos largos (PDFs, papers, reportes) en fragmentos procesables
    para generación de embeddings. Es la primera etapa del pipeline RAG.

    Contiene TextChunker con parámetros configurables:
    chunk_size=800 chars -> tamaño máximo de cada fragmento.
    overlap=150 chars    -> solapamiento entre fragmentos consecutivos.

    Métodos:
    chunk_text(text, source, page) -> lista de dicts con text, source,
        page, chunk_index, char_start. Es el método principal.
    chunk_file(file_path)          -> atajo que lee un .txt o .md desde
        disco y llama a chunk_text().
    _apply_overlap()               -> reinyecta el final del chunk N al
        inicio del chunk N+1 para preservar continuidad semántica.
    _split_large_paragraph()       -> subdivide párrafos que superan
        chunk_size en sub-chunks con stride de (chunk_size - overlap).

    Por qué overlap es crítico:
    Sin overlap, una frase que cae exactamente en el límite entre dos
    chunks queda partida y pierde contexto. Con overlap=150, el final
    del chunk N aparece al inicio del N+1, garantizando que cualquier
    frase tenga al menos un chunk donde aparece completa.


POR QUÉ ES NECESARIO:
    Sin chunking, los papers completos no podrían indexarse
    correctamente. Un embedding de 20 páginas diluiría el significado
    semántico y haría la búsqueda imprecisa.

QUÉ PASA SI SE ELIMINA:
    - build_embeddings.py no puede procesar los PDFs.
    - El vector store no puede poblarse.
    - El RAG completo queda inoperativo.

LÓGICA DE NEGOCIO:
    Estrategia de chunking con solapamiento:
    - chunk_size    : número de caracteres por fragmento (default 500)
    - chunk_overlap : caracteres solapados con el chunk anterior (default 50)

    Ejemplo para texto de 1100 chars, chunk_size=500, overlap=50:
    Chunk 0: chars [0, 500)
    Chunk 1: chars [450, 950)   ← empieza 50 chars antes del fin del anterior
    Chunk 2: chars [900, 1100)

    El solapamiento preserva oraciones cortadas en el límite del chunk.

FLUJO DE DATOS:
    texto_completo (string largo)
    → split en chunks con solapamiento
    → List[str] de chunks de tamaño uniforme

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python (no requiere librerías externas).

RIESGOS:
    - Chunks muy cortos (<100 chars): embeddings poco informativos.
    - Chunks muy largos (>1000 chars): excede el límite del modelo
      de embeddings o diluye la señal semántica.
    - El último chunk puede ser muy corto si el texto no es múltiplo
      del chunk_size.

ESCALABILIDAD:
    - Muy rápido: solo string slicing en Python.
    - Sin límite práctico de tamaño del texto de entrada.

IMPACTO DE NEGOCIO:
    BAJO-MEDIO. Componente de infraestructura RAG, no visible al usuario.

NIVEL DE CRITICIDAD:
    MEDIO (crítico para build_embeddings.py)

====================================================================
"""


import re
from typing import List, Dict, Any
from pathlib import Path


class TextChunker:
    """
    Divide textos en chunks con overlap para RAG.

    Estrategia:
        1. Intentar respetar párrafos (saltos de línea dobles)
        2. Si un párrafo excede chunk_size, subdividirlo
        3. Aplicar overlap entre chunks para preservar continuidad semántica

    Args:
        chunk_size:  Tamaño máximo de un chunk en caracteres (default 800)
        overlap:     Solapamiento entre chunks en caracteres (default 150)
                     Evita perder contexto en los bordes de cada chunk.

    Por qué overlap:
        Sin overlap, una oración que cae exactamente en el límite queda
        partida entre dos chunks y pierde contexto. Con overlap, la parte
        final del chunk N aparece al inicio del chunk N+1, asegurando
        continuidad semántica en el retrieval.
    """

    def __init__(self, chunk_size: int = 800, overlap: int = 150):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk_text(
        self,
        text: str,
        source: str = "unknown",
        page: int = 0,
    ) -> List[Dict[str, Any]]:
        """
        Divide texto en chunks con metadata.

        Args:
            text:   Texto a dividir.
            source: Identificador de la fuente (nombre de archivo, URL).
            page:   Número de página del PDF (0 si no aplica).

        Returns:
            Lista de dicts con keys: text, source, page, chunk_index, char_start.
        """
        if not text or not text.strip():
            return []

        # Normalizar espacios en blanco excesivos
        text = re.sub(r"\n{3,}", "\n\n", text)
        text = re.sub(r" {2,}", " ", text)

        paragraphs = text.split("\n\n")
        chunks: List[Dict[str, Any]] = []
        buffer = ""
        char_pos = 0

        for para in paragraphs:
            para = para.strip()
            if not para:
                continue

            # Si el párrafo solo cabe en el buffer, acumularlo
            if len(buffer) + len(para) + 2 <= self.chunk_size:
                buffer = (buffer + "\n\n" + para).strip()
            else:
                # Volcar buffer actual como chunk
                if buffer:
                    chunks.append(self._make_chunk(buffer, source, page, len(chunks), char_pos))
                    char_pos += len(buffer)

                # Si el párrafo es demasiado grande, subdividirlo
                if len(para) > self.chunk_size:
                    sub_chunks = self._split_large_paragraph(para)
                    for sc in sub_chunks:
                        chunks.append(self._make_chunk(sc, source, page, len(chunks), char_pos))
                        char_pos += len(sc)
                    buffer = ""
                else:
                    buffer = para

        # Volcar buffer restante
        if buffer:
            chunks.append(self._make_chunk(buffer, source, page, len(chunks), char_pos))

        # Aplicar overlap: reinyectar el final del chunk anterior al inicio del siguiente
        if self.overlap > 0 and len(chunks) > 1:
            chunks = self._apply_overlap(chunks)

        return chunks

    # ── helpers ───────────────────────────────────────────────────────────────

    def _make_chunk(
        self, text: str, source: str, page: int, index: int, char_start: int
    ) -> Dict[str, Any]:
        return {
            "text": text.strip(),
            "source": source,
            "page": page,
            "chunk_index": index,
            "char_start": char_start,
        }

    def _split_large_paragraph(self, para: str) -> List[str]:
        """Divide un párrafo largo en sub-chunks por tamaño."""
        result = []
        start = 0
        while start < len(para):
            end = min(start + self.chunk_size, len(para))
            result.append(para[start:end])
            start += self.chunk_size - self.overlap
        return result

    def _apply_overlap(self, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Reinyecta el final de cada chunk al inicio del siguiente.
        Mantiene chunk_index y metadata originales.
        """
        for i in range(1, len(chunks)):
            prev_tail = chunks[i - 1]["text"][-self.overlap :]
            chunks[i]["text"] = (prev_tail + " " + chunks[i]["text"]).strip()
        return chunks

    # ── utilidades públicas ───────────────────────────────────────────────────

    def chunk_file(self, file_path: str) -> List[Dict[str, Any]]:
        """
        Chunking directo desde un archivo .txt o .md.
        Para PDFs usar PDFLoader antes de llamar chunk_text().
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Archivo no encontrado: {file_path}")
        text = path.read_text(encoding="utf-8", errors="ignore")
        return self.chunk_text(text, source=path.name)

