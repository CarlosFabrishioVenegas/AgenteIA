"""
====================================================================
ARCHIVO: rag/embeddings/embedding_generator.py
====================================================================

OBJETIVO:
    Generar representaciones vectoriales (embeddings) de textos usando
    un modelo de sentence-transformers. Es la capa de vectorización
    del pipeline RAG, utilizada tanto para indexar documentos como
    para encodear queries en tiempo real.

PARA QUÉ SIRVE:
    Convierte texto plano en vectores de alta dimensión (típicamente
    384 o 768 dims) que capturan el significado semántico. Vectores
    cercanos en el espacio vectorial corresponden a textos semánticamente
    similares, habilitando la búsqueda semántica del RAG.

POR QUÉ ES NECESARIO:
    Sin embeddings, el sistema RAG no puede comparar la query del
    usuario con los documentos indexados. Es el primer paso de todo
    el pipeline: texto → vector → similitud coseno.

QUÉ PASA SI SE ELIMINA:
    - El sistema RAG deja de funcionar por completo.
    - ChromaManager no puede indexar ni buscar sin vectores.
    - build_embeddings.py y SemanticSearcher fallan.
    - El agente sigue operando pero sin capacidad RAG.

LÓGICA DE NEGOCIO:
    Modelo por defecto: "all-MiniLM-L6-v2"
    - Modelo ligero (~80MB), rápido, multilingüe básico.
    - Dimensión: 384 dims.
    - Muy bueno para búsqueda semántica en inglés; razonable en español.
    - Para mejor soporte en español considerar: "paraphrase-multilingual-MiniLM-L12-v2"

    CRÍTICO: el modelo usado para indexar DEBE ser el mismo que
    para generar embeddings de queries. Cambiar el modelo requiere
    re-indexar todo el vector store.

FLUJO DE DATOS:
    text_str → model.encode(text) → float[] (384 dims)
    texts_list → model.encode(texts) → float[][] (batch)

DEPENDENCIAS CRÍTICAS:
    - sentence-transformers : pip install sentence-transformers
    - torch (transitivo)    : requerido por sentence-transformers

RIESGOS:
    - Primer uso: descarga el modelo (~80MB). Requiere conexión a internet.
    - Sin GPU: la vectorización de muchos documentos es lenta (CPU).
    - Si se cambia el modelo: TODO el vector store debe re-indexarse.

ESCALABILIDAD:
    - Batch encoding disponible: procesar muchos textos a la vez
      es más eficiente que hacerlo uno por uno.
    - En producción con alta carga: usar una API de embeddings
      (OpenAI, Cohere) o desplegar el modelo en GPU dedicada.

IMPACTO DE NEGOCIO:
    MEDIO. Componente técnico de infraestructura RAG.

NIVEL DE CRITICIDAD:
    MEDIO (solo si RAG está en uso)

====================================================================
"""
import logging
from typing import List, Optional
import numpy as np

logger = logging.getLogger(__name__)

# Nombre del modelo por defecto.
# all-MiniLM-L6-v2: 80MB, 384 dims, ideal para RAG local en español e inglés.
# Alternativa más potente (pero más lenta): "paraphrase-multilingual-mpnet-base-v2"
DEFAULT_MODEL = "paraphrase-multilingual-MiniLM-L12-v2"


class EmbeddingGenerator:
    """
    Generador de embeddings con SentenceTransformers.

    Uso:
        gen = EmbeddingGenerator()                      # carga modelo lazy
        vec = gen.generate("texto de ejemplo")          # vector numpy [384]
        vecs = gen.batch_generate(["texto1", "texto2"]) # lista de vectores

    El modelo se descarga automáticamente en el primer uso (~80MB).
    Se cachea en ~/.cache/huggingface/hub/ para usos posteriores.
    """

    def __init__(self, model_name: str = DEFAULT_MODEL):
        self.model_name = model_name
        self._model = None  # Lazy load: no carga hasta el primer uso

    # ── carga lazy del modelo ─────────────────────────────────────────────────

    def _get_model(self):
        """
        Carga el modelo solo cuando se necesita por primera vez.

        Por qué lazy:
            Importar SentenceTransformers toma ~2-3s. Si el agente se inicia
            sin usar RAG, no queremos pagar ese costo de arranque.
        """
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
                logger.info(f"Cargando modelo de embeddings: {self.model_name}")
                self._model = SentenceTransformer(self.model_name)
                logger.info("Modelo cargado correctamente")
            except ImportError:
                raise ImportError(
                    "sentence-transformers no está instalado.\n"
                    "Instalar con: pip install sentence-transformers"
                )
        return self._model

    # ── API pública ───────────────────────────────────────────────────────────

    def generate(self, text: str) -> List[float]:
        """
        Genera embedding para un texto.

        Args:
            text: Texto a codificar. Se trunca a 512 tokens internamente.

        Returns:
            Vector de floats normalizado (norma L2 = 1.0), listo para
            similitud coseno con ChromaDB.
        """
        if not text or not text.strip():
            logger.warning("Texto vacío — retornando vector cero")
            return [0.0] * 384

        text = text.strip()[:4096]  # guardia: evitar textos enormes
        model = self._get_model()
        vec = model.encode(text, normalize_embeddings=True)
        return vec.tolist()

    def batch_generate(
        self,
        texts: List[str],
        batch_size: int = 32,
        show_progress: bool = False,
    ) -> List[List[float]]:
        """
        Genera embeddings para múltiples textos en batch.

        Args:
            texts:         Lista de textos a codificar.
            batch_size:    Tamaño de mini-batch interno (default 32).
                           Reducir a 8-16 si hay OOM en GPU.
            show_progress: Mostrar barra de progreso (útil para indexar PDFs).

        Returns:
            Lista de vectores normalizados, mismo orden que texts.

        Por qué batch:
            SentenceTransformers procesa matrices en GPU/CPU de forma
            vectorizada. Batch de 32 textos es ~10x más rápido que
            llamar generate() 32 veces en loop.
        """
        if not texts:
            return []

        # Filtrar vacíos pero preservar posición
        cleaned = [t.strip()[:4096] if t and t.strip() else "" for t in texts]

        model = self._get_model()
        vecs = model.encode(
            cleaned,
            batch_size=batch_size,
            normalize_embeddings=True,
            show_progress_bar=show_progress,
        )

        # Reemplazar vectores de textos vacíos con ceros
        result = []
        for i, (text, vec) in enumerate(zip(cleaned, vecs)):
            if not text:
                result.append([0.0] * vec.shape[0])
            else:
                result.append(vec.tolist())

        return result

    def similarity(self, vec_a: List[float], vec_b: List[float]) -> float:
        """
        Similitud coseno entre dos vectores ya normalizados.

        Args:
            vec_a, vec_b: Vectores de dimensión igual (output de generate()).

        Returns:
            Float en [-1.0, 1.0]. >0.7 = similar, >0.85 = muy similar.
        """
        a = np.array(vec_a)
        b = np.array(vec_b)
        return float(np.dot(a, b))  # coseno = dot si ambos son L2-norm

    @property
    def dimension(self) -> int:
        """Dimensión de los vectores del modelo cargado."""
        model = self._get_model()
        return model.get_sentence_embedding_dimension()

