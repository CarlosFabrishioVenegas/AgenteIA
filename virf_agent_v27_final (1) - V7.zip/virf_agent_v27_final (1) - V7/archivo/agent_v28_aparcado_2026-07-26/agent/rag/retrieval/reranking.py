"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
rag/retrieval/reranking.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PARA QUÉ SIRVE
--------------
Segunda pasada sobre los candidatos recuperados por ChromaDB.
Reordena los top-k fragmentos por relevancia contextual más fina
que la similitud coseno inicial.

Contiene Reranker con 1 método:
  rerank(query, documents) -> retorna documents sin reordenar.
    Estado actual: STUB completo — devuelve la lista de entrada tal cual.

Por qué reranking mejora el RAG:
  La similitud coseno mide cercanía semántica en el espacio vectorial
  pero no considera la interacción directa query-documento. Un
  CrossEncoder (modelo que lee query+documento juntos) captura matices
  que el coseno no detecta. Ejemplo: "ventas en Q3" puede tener alta
  similitud coseno con un fragmento sobre "Q3 financiero" aunque el
  contexto sea diferente; el CrossEncoder lo distinguiría.

TODO v2: implementar con sentence-transformers CrossEncoder:
  from sentence_transformers import CrossEncoder
  model = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")
  scores = model.predict([(query, d["text"]) for d in documents])
  return [d for _, d in sorted(zip(scores, documents), reverse=True)]

POR QUÉ ES NECESARIO
--------------------
Actualmente no añade valor (es stub). Cuando se implemente mejorará
la precisión del contexto RAG enviado al LLM.

QUÉ PASA SI SE ELIMINA
-----------------------
SemanticSearcher no llama a Reranker en la implementación actual.
El retrieval sigue funcionando normalmente sin ningún impacto.
rag/retrieval/__init__.py exporta Reranker — si se elimina el archivo
ese import falla.
"""
from typing import List, Dict, Any


class Reranker:
    """Reordena resultados de búsqueda por relevancia"""

    def rerank(self, query: str, documents: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Reordena documentos por relevancia"""
        # En producción, usar modelo de reranking como Cross-Encoder
        return documents

