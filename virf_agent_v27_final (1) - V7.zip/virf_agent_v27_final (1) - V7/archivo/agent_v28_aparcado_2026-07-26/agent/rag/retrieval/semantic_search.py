"""
====================================================================
ARCHIVO: rag/retrieval/semantic_search.py
====================================================================

OBJETIVO:
    Orquestar el flujo completo de búsqueda semántica RAG:
    query en texto → embedding → ChromaDB → contexto formateado
    listo para inyectar en el prompt del LLM.

PARA QUÉ SIRVE:
    Es el punto de entrada del pipeline RAG desde el agente.
    Cuando el usuario hace una pregunta sobre papers o literatura,
    agent.py llama a search_and_format() para obtener fragmentos
    relevantes que enriquecen la respuesta del LLM con grounding
    real en documentos académicos.

POR QUÉ ES NECESARIO:
    Sin este módulo, el agente respondería preguntas sobre papers
    únicamente desde el conocimiento general del LLM (sin acceso
    a los PDFs propios del proyecto). Este componente conecta
    EmbeddingGenerator y ChromaManager en un flujo cohesivo.

QUÉ PASA SI SE ELIMINA:
    - El pipeline RAG se rompe (falta el orquestador de búsqueda).
    - ChromaManager y EmbeddingGenerator quedan huérfanos.
    - agent.py captura el error y responde sin contexto RAG.
    - Las respuestas sobre literatura dejan de estar fundamentadas.

LÓGICA DE NEGOCIO:
    Flujo de búsqueda semántica:
    1. query_text → EmbeddingGenerator.generate(query) → vector
    2. vector → ChromaManager.search(vector, top_k) → candidatos
    3. candidatos → filtrar por min_score (default 0.35)
    4. resultados filtrados → formatear como bloque de texto para LLM

    Umbral min_score = 0.35 (similitud coseno):
    - Por debajo: documento probablemente irrelevante para la query.
    - Por encima: documento con suficiente relación semántica.

FLUJO DE DATOS:
    query_text
    → EmbeddingGenerator.generate(query_text) → float[]
    → ChromaManager.search(float[], top_k) → [{text, metadata, score}]
    → filtrar score >= min_score
    → formatear → str con N fragmentos numerados y su fuente

DEPENDENCIAS CRÍTICAS:
    - EmbeddingGenerator : genera el vector de la query
    - ChromaManager      : contiene los vectores indexados

RIESGOS:
    - Si el vector store está vacío: retorna string vacío.
    - Si los embeddings de query y documentos se generaron con
      modelos distintos: los scores serán inútiles (dimensiones
      diferentes causarán error o resultados sin sentido).
    - Un min_score muy alto (>0.7) puede filtrar todos los resultados.

ESCALABILIDAD:
    - Rápido: la búsqueda HNSW en ChromaDB escala bien hasta 100K docs.
    - El cuello de botella es EmbeddingGenerator si el modelo es grande.

IMPACTO DE NEGOCIO:
    MEDIO. Habilita respuestas basadas en papers propios del proyecto.

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""

import logging
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# Score mínimo de similitud coseno para incluir un documento en el contexto.
# Por debajo de 0.35, el documento probablemente no es relevante para la query.
DEFAULT_MIN_SCORE = 0.35


class SemanticSearcher:
    """
    Orquestador de búsqueda semántica para el pipeline RAG.

    Uso típico en agent.py:
        searcher = SemanticSearcher(embedder, chroma_mgr)
        context = searcher.search_and_format("cuáles son los drivers de compra?")
        # → string con los fragmentos más relevantes, listo para el LLM

    Uso standalone:
        results = searcher.search("ventas por segmento", top_k=5)
        # → List[Dict] con text, source, page, score
    """

    def __init__(self, embedder, chroma_manager, min_score: float = DEFAULT_MIN_SCORE):
        """
        Args:
            embedder:       Instancia de EmbeddingGenerator (ya cargada).
            chroma_manager: Instancia de ChromaManager (ya conectada).
            min_score:      Umbral mínimo de similitud coseno [0, 1].
                            Por debajo → el resultado se descarta.
        """
        self.embedder = embedder
        self.chroma = chroma_manager
        self.min_score = min_score

    def search(
        self,
        query: str,
        top_k: int = 5,
        source_filter: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Busca documentos semánticamente relevantes para la query.

        Args:
            query:         Pregunta o texto del usuario.
            top_k:         Número de resultados a recuperar (antes de filtrar).
            source_filter: Limitar búsqueda a una fuente específica (nombre de archivo).

        Returns:
            Lista de dicts: {text, source, page, chunk_index, score}
            Ordenados por score descendente. Solo incluye score >= min_score.
        """
        if not query or not query.strip():
            logger.warning("search() llamado con query vacía")
            return []

        if self.chroma.count() == 0:
            logger.warning("Vector store vacío — ejecuta scripts/build_embeddings.py primero")
            return []

        # Generar embedding de la query
        query_vec = self.embedder.generate(query)

        # Preparar filtro por fuente si se especificó
        where = {"source": source_filter} if source_filter else None

        # Recuperar candidatos de ChromaDB
        candidates = self.chroma.search(query_vec, top_k=top_k, where=where)

        # Filtrar por umbral de similitud
        relevant = [c for c in candidates if c["score"] >= self.min_score]

        if not relevant:
            logger.info(
                f"Ningún resultado superó min_score={self.min_score} "
                f"para query: '{query[:60]}...'"
            )
        else:
            logger.info(
                f"RAG: {len(relevant)}/{len(candidates)} fragmentos relevantes "
                f"(min_score={self.min_score})"
            )

        return relevant

    def search_and_format(
        self,
        query: str,
        top_k: int = 5,
        max_context_chars: int = 3000,
    ) -> str:
        """
        Busca y formatea el contexto RAG para inyectar en el LLM.

        Retorna un string formateado con los fragmentos relevantes,
        sus fuentes y scores. Listo para incluir en el system prompt.

        Args:
            query:             Pregunta del usuario.
            top_k:             Máximo de fragmentos a recuperar.
            max_context_chars: Límite de caracteres del contexto total.
                               Previene exceder el context window del LLM.

        Returns:
            String formateado, o "" si no hay resultados relevantes.

        Por qué limitar chars:
            El LLM tiene un context window finito. Inyectar demasiado
            contexto RAG desplaza el historial conversacional y degrada
            la respuesta. 3000 chars ≈ ~750 tokens, razonable para RAG.
        """
        results = self.search(query, top_k=top_k)
        if not results:
            return ""

        lines = ["CONTEXTO RECUPERADO DE DOCUMENTOS INTERNOS:"]
        total_chars = 0

        for i, doc in enumerate(results, 1):
            fragment = (
                f"\n[{i}] Fuente: {doc['source']} (pág. {doc['page']}) "
                f"| Relevancia: {doc['score']:.2f}\n"
                f"{doc['text']}"
            )
            if total_chars + len(fragment) > max_context_chars:
                lines.append(f"\n[... {len(results) - i + 1} fragmentos adicionales omitidos por límite de tokens]")
                break
            lines.append(fragment)
            total_chars += len(fragment)

        lines.append(
            "\nINSTRUCCIÓN: Usa el contexto anterior SOLO si es directamente relevante "
            "a la pregunta. No lo fuerces si no aplica."
        )

        return "\n".join(lines)

    def get_sources_summary(self) -> str:
        """
        Retorna un resumen de los documentos indexados en el vector store.
        Útil para que el usuario sepa qué documentos puede consultar.
        """
        sources = self.chroma.get_sources()
        count = self.chroma.count()
        if not sources:
            return "Vector store vacío. Ejecuta: python scripts/build_embeddings.py"
        sources_list = "\n".join(f"  • {s}" for s in sources)
        return (
            f"Documentos indexados ({count} chunks de {len(sources)} fuentes):\n"
            f"{sources_list}"
        )

