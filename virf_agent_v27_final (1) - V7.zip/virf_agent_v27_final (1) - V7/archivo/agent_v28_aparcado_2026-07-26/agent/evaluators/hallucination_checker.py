"""
====================================================================
ARCHIVO: evaluators/hallucination_checker.py  — virf_agent_v28
====================================================================

OBJETIVO:
    Detectar alucinaciones en respuestas del agente MRM:
    - Afirmaciones regulatorias falsas (artículos de Basilea inexistentes)
    - Métricas de modelos inventadas (AUC, Gini, KS sin fuente)
    - Referencias académicas fabricadas (papers que no existen)
    - Umbrales regulatorios incorrectos (ej. capital mínimo errado)

LÓGICA DE PENALIZACIÓN:
    1. Frases de incertidumbre ("creo que", "podría ser") → +0.2
    2. Referencias regulatorias sin número de artículo → +0.15
    3. Métricas ML sin fuente explícita en el prompt → +0.15
    4. Años o fechas de normativas inconsistentes → +0.1

====================================================================
"""

import re
import logging
from typing import Tuple, List

logger = logging.getLogger(__name__)

# Frases que revelan estimación en vez de dato concreto
UNCERTAINTY_PHRASES = [
    r"aproximadamente", r"creo que", r"podría ser", r"posiblemente",
    r"supongo que", r"tal vez", r"quizás", r"es probable que",
    r"me parece que", r"no estoy seguro", r"debería ser alrededor de",
]

# Términos regulatorios que deben ir acompañados de referencia
REGULATORY_TERMS = [
    r"basilea\s*(ii|iii|iv)?",
    r"artículo\s+\d+",
    r"circular\s+[a-z]+-\d+",
    r"resolución\s+[a-z]+-\d+",
    r"bcbs\s+\d+",
]

# Métricas de modelos que deben estar ancladas en la fuente
MODEL_METRICS_TERMS = [
    r"auc[_\-\s]*roc\s*[:=]\s*[\d.]+",
    r"gini\s*[:=]\s*[\d.]+",
    r"ks\s*statistic\s*[:=]\s*[\d.]+",
    r"f1[\-\s]*score\s*[:=]\s*[\d.]+",
    r"accuracy\s*[:=]\s*[\d.]+",
]


class HallucinationChecker:
    """
    Detector de alucinaciones calibrado para contexto MRM bancario.

    Retorna (score, warnings):
        score < 0.20  → respuesta probablemente fundamentada
        score 0.20-0.50 → revisar referencias manualmente
        score > 0.50  → alta probabilidad de afirmaciones inventadas
    """

    def __init__(self, source_text: str = ""):
        """
        Args:
            source_text: El texto de contexto (normativas, papers, métricas)
                         contra el cual se anclan las afirmaciones del LLM.
        """
        self.source_text = source_text.lower()

    def check(self, response_text: str) -> Tuple[float, List[str]]:
        text = response_text.lower()
        penalty = 0.0
        warnings: List[str] = []

        # 1. Frases de incertidumbre (señal de estimación)
        for phrase in UNCERTAINTY_PHRASES:
            if re.search(phrase, text, re.IGNORECASE):
                penalty += 0.2
                warnings.append(
                    f"Frase de incertidumbre detectada: '{phrase}'. "
                    "El agente podría estar estimando en vez de citar fuente."
                )
                break  # Una sola penalización por este tipo

        # 2. Métricas numéricas de modelos sin anclaje en fuente
        metric_hits = 0
        for pattern in MODEL_METRICS_TERMS:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                # Verifica si el valor citado aparece en la fuente
                numbers_in_match = re.findall(r"[\d.]+", match)
                for num in numbers_in_match:
                    if num not in self.source_text:
                        penalty += 0.15
                        metric_hits += 1
                        warnings.append(
                            f"Métrica '{match}' no encontrada en la fuente. "
                            "Posible alucinación numérica."
                        )
                if metric_hits >= 3:
                    break  # Tope de penalización
            if metric_hits >= 3:
                break

        # 3. Porcentajes imposibles (>100 o <0 en contextos de probabilidad)
        impossible_pcts = re.findall(r"(\d{3,})\s*%", text)
        for pct in impossible_pcts:
            if int(pct) > 100:
                penalty += 0.15
                warnings.append(
                    f"Porcentaje imposible detectado: {pct}%. "
                    "Revisar cálculo o fuente."
                )

        # 4. Términos regulatorios sin número de referencia contextual
        regulatory_count = 0
        for term in REGULATORY_TERMS:
            if re.search(term, text, re.IGNORECASE):
                # Si el término NO aparece en la fuente, es sospechoso
                if not re.search(term, self.source_text, re.IGNORECASE):
                    penalty += 0.1
                    regulatory_count += 1
                    warnings.append(
                        f"Referencia regulatoria '{term}' no encontrada en fuente. "
                        "Verificar existencia y aplicabilidad."
                    )
                if regulatory_count >= 2:
                    break  # Tope

        final_score = min(1.0, penalty)
        return final_score, warnings

    def get_risk_level(self, score: float) -> str:
        if score < 0.20:
            return "BAJO — Respuesta probablemente fundamentada"
        elif score < 0.50:
            return "MEDIO — Revisar referencias manualmente"
        else:
            return "ALTO — Alta probabilidad de afirmaciones sin sustento"
