"""
agent/evaluators/formula_detector.py
======================================
Motor de detección de errores matemáticos y estadísticos en fórmulas
financieras. Opera sin LLM (regex + reglas) como primera capa de
análisis antes de pasar al LLM para explicación.

Detecta:
- Errores de signo en fórmulas de riesgo
- Distribuciones mal aplicadas (Normal vs t-Student, etc.)
- Parámetros sin justificación (ventanas arbitrarias, alpha sin calibrar)
- Fórmulas conocidas incorrectas (VaR, LaR, spreads, duración)
- Código Python con errores en implementación financiera

Uso:
    detector = FormulaDetector()
    hallazgos = detector.analizar("VaR = μ + σ * z_alpha")
    hallazgos_codigo = detector.analizar_codigo("import scipy\\nvar = norm.ppf(0.95)")
"""

from __future__ import annotations
import re
from typing import List, Dict


# ── Patrones de errores conocidos ─────────────────────────────────────────────

# (pattern, gravedad, descripcion, correccion_sugerida, referencia)
PATRONES_FORMULA = [
    # VaR paramétrico — signo incorrecto
    (
        r"var\s*=\s*[μmu]\s*\+\s*[σs]",
        "CRÍTICO",
        "VaR paramétrico con signo incorrecto: VaR = μ + σ·z implica pérdida positiva "
        "pero el cuantil para pérdidas debería ser μ - σ·z (cola izquierda).",
        "VaR = -(μ - σ · z_α) o equivalentemente VaR = σ·z_α - μ para retornos.",
        "Jorion (2006) Value at Risk, cap. 5.",
    ),
    # VaR con z fijo 1.645 sin mencionar distribución
    (
        r"1\.645|1\.64[^0-9]",
        "MEDIO",
        "Se usa z=1.645 (Normal estándar al 95%) sin verificar normalidad de los retornos. "
        "Si los retornos tienen colas pesadas, subestima el VaR.",
        "Aplicar test Jarque-Bera/Shapiro-Wilk antes de asumir normalidad. "
        "Si p-value < 0.05, usar t-Student o Cornish-Fisher.",
        "Christoffersen (1998), Kupiec (1995).",
    ),
    # Volatilidad anualizada sin raíz de tiempo
    (
        r"vol\s*[\*×]\s*252|sigma\s*[\*×]\s*252",
        "CRÍTICO",
        "Volatilidad anualizada multiplicada por 252 directamente. "
        "La regla de la raíz del tiempo exige multiplicar por √252, no por 252.",
        "σ_anual = σ_diaria × √252",
        "Hull (2018) Options, Futures cap. 15; BIS (2005) Technical Documentation.",
    ),
    # Duración modificada con signo positivo en cambio de precio
    (
        r"[Δδ]P\s*=\s*[Dd]ur\s*[\*×]\s*[Δδ]y(?!\s*[\*×]\s*-)",
        "ALTO",
        "Cambio de precio con duración sin signo negativo. "
        "ΔP = +Dur × Δy implica que al subir tasas sube el precio, lo cual es incorrecto.",
        "ΔP/P = -D_mod × Δy  (signo negativo obligatorio)",
        "Fabozzi (2012) Bond Mathematics, cap. 4.",
    ),
    # EWMA sin restricción lambda
    (
        r"lambda\s*=\s*[01]?\.[0-9]+",
        "BAJO",
        "Parámetro λ de EWMA definido sin citar calibración. "
        "RiskMetrics recomienda λ=0.94 para datos diarios, pero debe verificarse.",
        "Calibrar λ minimizando RMSE entre volatilidad estimada y realizada. "
        "Documentar el período de calibración.",
        "J.P. Morgan RiskMetrics (1996).",
    ),
    # Interpolación lineal de curva — uso inadecuado
    (
        r"interpolaci[oó]n\s+lineal|linear.*interpolat",
        "MEDIO",
        "Interpolación lineal de curva de tasas. Para plazos intermedios, "
        "la interpolación lineal introduce sesgos sistemáticos en la estructura temporal.",
        "Usar interpolación log-lineal o el modelo NSS calibrado con todos los nodos.",
        "Nelson-Siegel-Svensson (1994); BIS Papers No. 25.",
    ),
    # Correlación=1 entre activos sin justificación
    (
        r"corr\s*=\s*1\.0|correlaci[oó]n.*=.*1(?:[^.0-9]|$)",
        "ALTO",
        "Correlación perfecta (ρ=1) entre activos. Este supuesto sobreestima el riesgo "
        "y rara vez está justificado empíricamente.",
        "Estimar matriz de correlaciones con período de observación representativo "
        "(mínimo 250 días hábiles). Aplicar shrinkage si n < p.",
        "Ledoit-Wolf (2004); SR 11-7 Sección IV.",
    ),
    # LCR calculado sin haircuts
    (
        r"lcr\s*=\s*hqla\s*/\s*(?!.*haircut)",
        "ALTO",
        "LCR calculado con HQLA bruto sin aplicar haircuts regulatorios.",
        "HQLA neto = Σ(activo_i × (1 - haircut_i)) según CRR Art. 418.",
        "Basilea III LCR (2013); CRR Regulation (EU) 575/2013.",
    ),
    # Percentil confundido con cuantil complementario
    (
        r"percentil\s*(?:95|99).*pérdida|loss.*percentil\s*(?:5|1)(?:[^0-9]|$)",
        "ALTO",
        "Posible confusión entre percentil de pérdida y de ganancia. "
        "El VaR al 99% es el percentil 99 de pérdidas = percentil 1 de retornos.",
        "Unificar convención: si pérdidas son positivas, usar percentil alto. "
        "Si retornos (pérdidas negativas), usar percentil bajo.",
        "McNeil, Frey, Embrechts (2005) Quantitative Risk Management cap. 2.",
    ),
]

PATRONES_CODIGO = [
    # norm.ppf sin verificar normalidad
    (
        r"norm\.ppf|scipy\.stats\.norm\.ppf",
        "MEDIO",
        "Se usa norm.ppf() (cuantil Normal) sin test previo de normalidad. "
        "Puede subestimar el VaR si los retornos tienen colas pesadas.",
        "Añadir: from scipy.stats import jarque_bera; stat, p = jarque_bera(retornos) "
        "y usar t.ppf si p < 0.05.",
        "Kupiec (1995); Christoffersen (1998).",
    ),
    # std() sin ddof=1
    (
        r"\.std\(\)",
        "BAJO",
        "np.std() / pd.Series.std() sin especificar ddof. "
        "Por defecto pandas usa ddof=1 (sesgado) pero numpy usa ddof=0. "
        "Para muestras financieras se recomienda ddof=1 explícito.",
        "Usar .std(ddof=1) explícito en todos los cálculos de volatilidad.",
        "Hull (2018) cap. 15.",
    ),
    # División sin manejo de cero
    (
        r"\/\s*(?:n|count|len|total)(?!\s*\+)",
        "BAJO",
        "División por variable de conteo sin protección contra denominador cero.",
        "Añadir: assert n > 0 o usar np.where(n > 0, numerador/n, np.nan)",
        "Buenas prácticas de implementación financiera.",
    ),
    # Multiplicación de volatilidad por días sin raíz
    (
        r"sigma\s*\*\s*(?:252|250|365|horizon)(?!\s*\*\*\s*0\.5|\s*\*\*\s*\(0\.5\))",
        "CRÍTICO",
        "Volatilidad multiplicada por número de días sin aplicar raíz cuadrada. "
        "La regla de la raíz del tiempo es σ_h = σ_1 × √h.",
        "sigma_anual = sigma_diaria * np.sqrt(252)",
        "Hull (2018) cap. 15.",
    ),
    # log sin verificar valores positivos
    (
        r"np\.log\((?!1\s*\+|np\.abs)",
        "BAJO",
        "np.log() sin garantizar argumento positivo. "
        "Los retornos log pueden fallar si hay precios cero o negativos.",
        "Añadir validación: assert (prices > 0).all() antes de np.log(prices)",
        "Buenas prácticas.",
    ),
]


class FormulaDetector:
    """
    Detector de errores en fórmulas y código financiero basado en reglas.
    Opera sin LLM → rápido, determinista, sin costo de API.
    """

    def analizar(self, texto: str) -> List[Dict]:
        """
        Analiza texto libre (fórmulas, descripciones metodológicas).

        Returns:
            Lista de dicts con keys: tipo, gravedad, descripcion, correccion, referencia
        """
        hallazgos = []
        texto_lower = texto.lower()

        for pattern, gravedad, desc, correccion, ref in PATRONES_FORMULA:
            if re.search(pattern, texto_lower, re.IGNORECASE):
                hallazgos.append({
                    "tipo":       "formula",
                    "gravedad":   gravedad,
                    "descripcion": desc,
                    "correccion": correccion,
                    "referencia": ref,
                    "fuente":     "formula_detector",
                    "patron":     pattern,
                })

        return hallazgos

    def analizar_codigo(self, codigo: str) -> List[Dict]:
        """
        Analiza código Python buscando implementaciones incorrectas.

        Returns:
            Lista de dicts con hallazgos de código.
        """
        hallazgos = []

        for pattern, gravedad, desc, correccion, ref in PATRONES_CODIGO:
            if re.search(pattern, codigo, re.IGNORECASE):
                # Encontrar la línea específica para contexto
                linea_ctx = ""
                for linea in codigo.split("\n"):
                    if re.search(pattern, linea, re.IGNORECASE):
                        linea_ctx = linea.strip()[:80]
                        break

                hallazgos.append({
                    "tipo":       "codigo",
                    "gravedad":   gravedad,
                    "descripcion": desc + (f"\n    Línea: `{linea_ctx}`" if linea_ctx else ""),
                    "correccion": correccion,
                    "referencia": ref,
                    "fuente":     "codigo_detector",
                    "patron":     pattern,
                })

        return hallazgos

    def resumen(self, hallazgos: List[Dict]) -> str:
        """Retorna un resumen textual de los hallazgos para inyectar en el prompt."""
        if not hallazgos:
            return ""
        lines = ["ERRORES DETECTADOS POR ANÁLISIS ESTÁTICO:"]
        for h in hallazgos:
            lines.append(
                f"- [{h['gravedad']}] {h['descripcion'][:100]}  "
                f"(Corrección: {h['correccion'][:80]}) — Ref: {h['referencia']}"
            )
        return "\n".join(lines)
