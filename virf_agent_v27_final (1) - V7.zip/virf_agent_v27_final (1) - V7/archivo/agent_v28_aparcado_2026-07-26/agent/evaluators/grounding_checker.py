"""
====================================================================
ARCHIVO: evaluators/grounding_checker.py
====================================================================

OBJETIVO:
    Evaluador de calidad de respuestas del agente.
    Verifica que las afirmaciones de la respuesta estén ancladas (grounded) en el contexto proporcionado, no en conocimiento inventado.

PARA QUÉ SIRVE:
    Es parte del sistema de evaluación post-generación que verifica
    la calidad de cada respuesta antes de mostrarla al usuario.
    Permite detectar problemas de calidad de forma automática.

    Mide si la respuesta del LLM está anclada en datos concretos o es
    pura generalización vaga. Distingue respuestas que citan evidencia
    verificable de las que "suenen bien" sin base real.

    Funciona contando dos tipos de señales en el texto:
    DATA_SIGNALS (positivo): IDs de 4+ dígitos, decimales tipo 0.73,
    números con separador de miles, porcentajes, "cluster N", "decil N",
    "top N / bottom N".
    GENERIC_SIGNALS (negativo): "algunos", "muchos", "la mayoría",
    "en general", "típicamente", "normalmente", "suele", "podría".

Score de grounding resultante:
  0 señales de datos -> score 0.1 (muy poca evidencia)
  3+ señales de datos -> score 0.9 (bien anclada)
  Bonus +0.15 si se pasó evidencia SQL/pandas real en evidence dict.
  Penalización -0.2 si hay >3 señales genéricas.

POR QUÉ ES NECESARIO:
    Un sistema de IA empresarial necesita mecanismos de verificación
    automáticos. Sin evaluadores, las respuestas de baja calidad
    o con alucinaciones llegan al usuario sin advertencia.

QUÉ PASA SI SE ELIMINA:
    - El sistema pierde esa dimensión de evaluación de calidad.
    - Las respuestas no se verifican en ese aspecto específico.
    - El sistema sigue funcionando (evaluadores son opcionales).
    - HallucinationChecker es el evaluador más crítico; este es
      complementario.

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python o librerías básicas.

NIVEL DE CRITICIDAD:
    MEDIO

NOTAS TÉCNICAS:
    ESTADO: Implementación parcial/stub. Los scores retornados
    son hardcodeados o heurísticos simples. Para producción real,
    implementar evaluación semántica real.

====================================================================
"""
import re
import logging
from typing import Dict, Any, List, Optional
from pathlib import Path

logger = logging.getLogger(__name__)


class GroundingChecker:
    """
    Verifica que las respuestas estén ancladas en evidencia concreta.

    Score de grounding:
        1.0 = totalmente anclada en datos reales
        0.5 = mezcla de datos y generalización
        0.0 = sin referencias a datos concretos

    Uso:
        checker = GroundingChecker(pred_file="outputs/predictions/predicciones.parquet")
        result = checker.check(response_text, evidence={"sql_result": df, "query": query})
    """

    # Señales de que la respuesta cita datos concretos
    DATA_SIGNALS = [
        r"\b\d{4,}\b",              # IDs numéricos (4+ dígitos)
        r"\b0\.\d{2,4}\b",          # Decimales tipo prob_compra (0.73)
        r"\b\d+[,\.]\d{3}\b",       # Números con separador de miles
        r"\b\d+%",                  # Porcentajes
        r"cluster\s*\d+",           # Referencias a clusters
        r"decil\s*\d+",             # Referencias a deciles
        r"(top|bottom)\s+\d+",      # Top/bottom N
    ]

    # Señales de generalización sin datos
    GENERIC_SIGNALS = [
        r"\balguno[s]?\b",
        r"\bmuchos?\b",
        r"\bpocos?\b",
        r"\bla mayoría\b",
        r"\ben general\b",
        r"\btípicamente\b",
        r"\bnormalmente\b",
        r"\bsuele\b",
        r"\bpodría\b",
    ]

    def __init__(self, pred_file: str = "outputs/predictions/predicciones.parquet"):
        self.pred_file = Path(pred_file)

    def check(
        self,
        response_text: str,
        evidence: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Verifica el grounding de la respuesta.

        Args:
            response_text: Texto generado por el LLM.
            evidence:      Contexto con datos reales usados para generar
                           la respuesta (sql_result, query, etc.).

        Returns:
            Dict con:
            - is_grounded (bool): True si score >= 0.4
            - evidence_quality (float): Score 0-1
            - missing_evidence (list): Qué falta para mejor grounding
            - data_signals_found (int): Cuántas señales de datos concretos
            - generic_signals_found (int): Cuántas señales de generalización
        """
        text_lower = response_text.lower()

        # Contar señales de datos concretos
        data_hits = sum(
            len(re.findall(pattern, response_text, re.IGNORECASE))
            for pattern in self.DATA_SIGNALS
        )

        # Contar señales de generalización
        generic_hits = sum(
            len(re.findall(pattern, text_lower))
            for pattern in self.GENERIC_SIGNALS
        )

        # Calcular score base
        if data_hits == 0:
            score = 0.1  # Sin ningún dato concreto
        elif data_hits >= 3:
            score = 0.9  # Abundantes referencias a datos
        else:
            score = 0.3 + (data_hits * 0.2)

        # Penalizar por exceso de generalización
        if generic_hits > 3:
            score = max(0.1, score - 0.2)

        # Bonus si se usó evidencia SQL/pandas real
        if evidence and evidence.get("sql_result") is not None:
            score = min(1.0, score + 0.15)

        # Detectar qué evidencia falta
        missing = []
        if data_hits == 0:
            missing.append("La respuesta no cita números concretos del dataset")
        if evidence is None:
            missing.append("No se pasó evidencia SQL/pandas al evaluador")
        if generic_hits > 5:
            missing.append(
                f"Demasiada generalización ({generic_hits} frases genéricas). "
                "Reformular la pregunta con datos específicos."
            )

        is_grounded = score >= 0.4

        if not is_grounded:
            logger.info(
                f"GroundingChecker: score={score:.2f} — respuesta poco anclada en datos. "
                f"data_signals={data_hits}, generic={generic_hits}"
            )

        return {
            "is_grounded": is_grounded,
            "evidence_quality": round(score, 3),
            "missing_evidence": missing,
            "data_signals_found": data_hits,
            "generic_signals_found": generic_hits,
        }

