"""
====================================================================
ARCHIVO: evaluators/confidence_score.py
====================================================================

OBJETIVO:
    Evaluador de calidad de respuestas del agente.
    Calcula un score de confianza general para las respuestas del agente basado en señales lingüísticas, longitud y estructura de la respuesta.

PARA QUÉ SIRVE:
    Es parte del sistema de evaluación post-generación que verifica
    la calidad de cada respuesta antes de mostrarla al usuario.
    Permite detectar problemas de calidad de forma automática.

    Calcula un score de confianza compuesto 0-1 para cada respuesta,
    combinando señales de los otros dos evaluadores más heurísticas de
    longitud y estructura del texto.

    Fórmula de score():
    base = 0.5 (neutral)
    - hallucination_score * 0.4  (peso 40%: alucinaciones penalizan fuerte)
    + (evidence_quality - 0.5) * 0.3  (peso 30%: grounding centrado en 0.5)
    - 0.2 si el texto tiene <80 chars  (respuesta demasiado corta)
    - 0.05 si el texto tiene >2000 chars  (verbosidad leve)
    + 0.05 si contiene bullets o guiones  (bien estructurada)

    interpret() traduce el score a texto legible:
    >=0.75 -> "Alta confianza — respuesta anclada en datos reales"
    >=0.5  -> "Confianza media — revisar números citados"
    >=0.25 -> "Confianza baja — posibles generalizaciones o errores"
    <0.25  -> "Confianza muy baja — posible alucinación o respuesta vacía"


POR QUÉ ES NECESARIO:
    Un sistema de IA empresarial necesita mecanismos de verificación
    automáticos. Sin evaluadores, las respuestas de baja calidad
    o con alucinaciones llegan al usuario sin advertencia.

QUÉ PASA SI SE ELIMINA:
    - El sistema pierde esa dimensión de evaluación de calidad.
    - Las respuestas no se verifican en ese aspecto específico.
    - El sistema sigue funcionando (evaluadores son opcionales).
    - HallucinationChecker es el evaluador más crítico; este es
      complementario.

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python o librerías básicas.

NIVEL DE CRITICIDAD:
    MEDIO

NOTAS TÉCNICAS:
    ESTADO: Implementación parcial/stub. Los scores retornados
    son hardcodeados o heurísticos simples. Para producción real,
    implementar evaluación semántica real.

====================================================================
"""
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class ConfidenceScorer:
    """
    Calcula score de confianza compuesto para respuestas del agente.

    Score final:
        1.0 = alta confianza (anclada en datos, sin alucinaciones, bien formateada)
        0.5 = confianza media (revisar)
        0.0 = baja confianza (posibles alucinaciones o respuesta vacía)

    Uso:
        scorer = ConfidenceScorer()
        score = scorer.score(response_dict)
        # response_dict: {"text": "...", "hallucination_score": 0.1, "grounding": {...}}
    """

    # Longitud mínima razonable de una respuesta útil (chars)
    MIN_RESPONSE_CHARS = 80
    # Longitud máxima antes de penalizar por verbosidad
    MAX_RESPONSE_CHARS = 2000

    def score(self, response: Dict[str, Any]) -> float:
        """
        Calcula score de confianza compuesto.

        Args:
            response: Dict con cualquier combinación de:
                - text (str): Texto de la respuesta
                - hallucination_score (float): Output de HallucinationChecker
                - grounding (dict): Output de GroundingChecker
                - error (str): Si hay un error explícito

        Returns:
            Float en [0, 1].
        """
        # Error explícito → confianza cero
        if "error" in response and response["error"]:
            logger.debug("ConfidenceScorer: error detectado → score=0.0")
            return 0.0

        score = 0.5  # base neutral

        # ── 1. Penalizar alucinaciones ────────────────────────────────────────
        h_score = response.get("hallucination_score", None)
        if h_score is not None:
            # h_score alto = mala señal → reducir confianza
            score -= h_score * 0.4  # peso: 40%

        # ── 2. Bonus por grounding ────────────────────────────────────────────
        grounding = response.get("grounding", None)
        if grounding and isinstance(grounding, dict):
            eq = grounding.get("evidence_quality", 0.5)
            score += (eq - 0.5) * 0.3  # peso: 30%, centrado en 0.5

        # ── 3. Heurísticas de longitud ────────────────────────────────────────
        text = response.get("text", "") or response.get("response", "")
        if text:
            n_chars = len(text)
            if n_chars < self.MIN_RESPONSE_CHARS:
                score -= 0.2  # respuesta demasiado corta
            elif n_chars > self.MAX_RESPONSE_CHARS:
                score -= 0.05  # respuesta verbosa, penalización leve

        # ── 4. Bonus por estructura (bullet points, números) ─────────────────
        if text and any(c in text for c in ["•", "–", "-", "\n-", "\n•"]):
            score += 0.05  # respuesta bien estructurada

        final = round(max(0.0, min(1.0, score)), 3)
        logger.debug(f"ConfidenceScorer: score_final={final}")
        return final

    def interpret(self, score: float) -> str:
        """Retorna interpretación legible del score."""
        if score >= 0.75:
            return "Alta confianza — respuesta anclada en datos reales"
        elif score >= 0.5:
            return "Confianza media — revisar números citados"
        elif score >= 0.25:
            return "Confianza baja — posibles generalizaciones o errores"
        else:
            return "Confianza muy baja — posible alucinación o respuesta vacía"

