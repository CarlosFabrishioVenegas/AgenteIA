"""
====================================================================
ARCHIVO: evaluators/response_evaluator.py
====================================================================

OBJETIVO:
    Evaluador de calidad de respuestas del agente.
    Evaluador general de calidad de respuestas que combina múltiples 
    dimensiones: completitud, relevancia, claridad y score global.

PARA QUÉ SIRVE:
    Es parte del sistema de evaluación post-generación que verifica
    la calidad de cada respuesta antes de mostrarla al usuario.
    Permite detectar problemas de calidad de forma automática.

    Punto de entrada unificado de evaluación para el orchestrator.
    Llama a los tres evaluadores especializados (HallucinationChecker,
    GroundingChecker, ConfidenceScorer) y devuelve un único dict con
    completeness, relevance, clarity y overall_score.

    Es el "jefe de QC" que consolida los veredictos de los especialistas
    en un solo informe por respuesta generada.

POR QUÉ ES NECESARIO:
    Un sistema de IA empresarial necesita mecanismos de verificación
    automáticos. Sin evaluadores, las respuestas de baja calidad
    o con alucinaciones llegan al usuario sin advertencia.

QUÉ PASA SI SE ELIMINA:
    - El sistema pierde esa dimensión de evaluación de calidad.
    - Las respuestas no se verifican en ese aspecto específico.
    - El sistema sigue funcionando (evaluadores son opcionales).
    - HallucinationChecker es el evaluador más crítico; este es
      complementario.

DEPENDENCIAS CRÍTICAS:
    - hallucination_checker.py : detector de números inventados
    - grounding_checker.py     : verificador de anclaje en datos
    - confidence_score.py      : scorer compuesto de confianza

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""
from typing import Dict, Any
import logging

from .hallucination_checker import HallucinationChecker
from .grounding_checker import GroundingChecker
from .confidence_score import ConfidenceScorer

logger = logging.getLogger(__name__)


class ResponseEvaluator:
    """
    Orquestador de evaluación de respuestas.

    Coordina HallucinationChecker + GroundingChecker + ConfidenceScorer
    y devuelve un dict con evaluación multidimensional.

    Uso (por el orchestrator):
        evaluator = ResponseEvaluator()
        result = evaluator.evaluate(response_dict, query)
        if result["overall_score"] < 0.5:
            logger.warning("Respuesta de baja calidad")

    Dimensiones evaluadas:
        - completeness  : penaliza respuestas muy cortas (<80 chars)
        - relevance     : basada en evidence_quality del GroundingChecker
        - clarity       : bonus por estructura (bullets, saltos de línea)
        - confidence    : score compuesto del ConfidenceScorer
        - overall_score : promedio de las 4 dimensiones anteriores
    """

    def __init__(self):
        self._hallucination = HallucinationChecker()
        self._grounding     = GroundingChecker()
        self._confidence    = ConfidenceScorer()

    def evaluate(self, response: Dict[str, Any], query: str) -> Dict[str, Any]:
        """
        Evalúa múltiples dimensiones de calidad de la respuesta.

        Args:
            response: Dict con la respuesta del agente. Claves esperadas:
                      "text" o "response" (str), "error" (str, opcional).
            query:    Query original del usuario (para contextualizar).

        Returns:
            Dict con métricas de calidad:
            - completeness      (float 0-1): ¿La respuesta cubre la query?
            - relevance         (float 0-1): ¿Está anclada en datos reales?
            - clarity           (float 0-1): ¿Está bien estructurada?
            - confidence        (float 0-1): Score compuesto de confianza
            - hallucination_score (float 0-1): Riesgo de números inventados
            - overall_score     (float 0-1): Promedio de las 4 dimensiones
            - issues            (list[str]): Problemas detectados
        """
        text   = response.get("text", "") or response.get("response", "")
        issues = []

        # ── 1. Hallucination ──────────────────────────────────────────────────
        # Verifica que los números citados coincidan con metrics.json
        h_score, h_warnings = self._hallucination.check(text, query)
        issues.extend(h_warnings)

        # ── 2. Grounding ──────────────────────────────────────────────────────
        # Verifica que la respuesta esté anclada en datos concretos
        grounding = self._grounding.check(text)
        if not grounding["is_grounded"]:
            issues.extend(grounding["missing_evidence"])

        # ── 3. Confidence ─────────────────────────────────────────────────────
        # Recibe los outputs de los dos anteriores para el score compuesto
        confidence = self._confidence.score({
            "text":                text,
            "hallucination_score": h_score,
            "grounding":           grounding,
        })

        # ── 4. Dimensiones derivadas ──────────────────────────────────────────

        # Completitud: penaliza respuestas muy cortas
        completeness = 1.0 if len(text) >= 80 else max(0.3, len(text) / 80)

        # Relevancia: basada en evidence_quality del GroundingChecker
        relevance = grounding["evidence_quality"]

        # Claridad: bonus si tiene estructura (bullets, saltos de línea)
        has_structure = any(c in text for c in ["•", "-", "\n", "–"])
        clarity = 0.85 if has_structure else 0.6

        # Overall: promedio de las 4 dimensiones
        overall = round((completeness + relevance + clarity + confidence) / 4, 3)

        return {
            "completeness":        round(completeness, 3),
            "relevance":           round(relevance, 3),
            "clarity":             round(clarity, 3),
            "confidence":          round(confidence, 3),
            "hallucination_score": round(h_score, 3),
            "overall_score":       overall,
            "issues":              issues,
        }

