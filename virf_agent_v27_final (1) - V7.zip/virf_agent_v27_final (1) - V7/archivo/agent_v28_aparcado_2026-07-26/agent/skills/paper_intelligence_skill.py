"""
====================================================================
ARCHIVO: skills/paper_intelligence_skill.py  — virf_agent_v28
====================================================================

SKILL: Paper Intelligence
DOMINIO: Academic Research Intelligence / Model Literature Review
ROL SIMULADO: Quantitative Researcher + Data Scientist senior

OBJETIVO:
    Leer profundamente papers científicos y extraer:
    - Metodología completa
    - Supuestos (explícitos e implícitos)
    - Variables independientes y dependientes
    - Fórmulas matemáticas y estadísticas
    - Limitaciones declaradas y no declaradas
    - Resultados y condiciones de reproducibilidad

    Construir:
    - Knowledge Graph de conceptos y relaciones
    - Resumen técnico (para validadores cuantitativos)
    - Resumen ejecutivo (para comités)
    - Hallazgos relevantes para el modelo bajo revisión

OUTPUT:
    {
        "technical_summary": str,
        "executive_summary": str,
        "methodology": {...},
        "assumptions": [...],
        "formulas": [...],
        "limitations": [...],
        "knowledge_graph": {...},
        "relevance_to_model": str
    }

====================================================================
"""

from typing import Dict, Any, List
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

SYSTEM_PROMPT_PAPER = """
Eres un equipo de investigación cuantitativa especializado en revisión de
literatura académica para banca y finanzas.

Tu función al leer un paper:

1. EXTRACCIÓN TÉCNICA (para validadores cuantitativos):
   - Metodología paso a paso
   - Todas las variables con su definición precisa
   - Cada fórmula matemática en notación clara
   - Supuestos estadísticos (independencia, normalidad, estacionariedad, etc.)
   - Condiciones de aplicabilidad
   - Limitaciones reconocidas por los autores
   - Métricas de evaluación utilizadas
   - Resultados numéricos con intervalos de confianza

2. EXTRACCIÓN EJECUTIVA (para comités y directivos):
   - Qué problema resuelve
   - Por qué es relevante para el banco
   - Conclusión principal en 3 oraciones
   - Riesgo de aplicarlo incorrectamente

3. KNOWLEDGE GRAPH:
   Construye un mapa de relaciones:
   [Concepto A] → [relación] → [Concepto B]
   Ejemplo: [Logistic Regression] → [asume] → [linealidad log-odds]

4. HALLAZGOS RELEVANTES:
   Conecta los hallazgos del paper con el modelo bajo validación.
   Identifica si los supuestos del paper se cumplen en el contexto real.

5. RIESGOS DE APLICACIÓN:
   Qué puede salir mal si se implementa este enfoque sin respetar sus supuestos.

Sé exhaustivo en la extracción técnica. Un validador necesita entender
el paper tan bien como sus autores para poder cuestionarlo.
"""


class PaperIntelligenceSkill(BaseSkill):
    """
    Skill de inteligencia académica para MRM.
    
    Extrae metodología, supuestos, fórmulas y limitaciones de papers
    científicos. Construye knowledge graphs y produce resúmenes
    técnicos y ejecutivos.
    """

    def __init__(self):
        super().__init__(
            name="paper_intelligence",
            description=(
                "Extracción profunda de papers académicos: metodología, "
                "supuestos, fórmulas, limitaciones. Construye knowledge graph "
                "y produce resúmenes técnicos y ejecutivos para MRM."
            ),
        )

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "paper", "artículo", "publicación", "investigación", "literatura",
            "metodología", "fórmula", "supuesto", "limitación", "abstract",
            "knowledge graph", "resumen técnico", "citar", "referencia",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)
            paper_content = self._extract_paper_content(tools, context)

            user_prompt = f"""{history}{rag_context}

CONTENIDO DEL PAPER / DOCUMENTO ACADÉMICO:
{paper_content}

CONSULTA / ENFOQUE DE ANÁLISIS:
{query}

Realiza el análisis completo según las instrucciones del sistema.
Si el contenido del paper no está disponible directamente, usa el
contexto RAG y el conocimiento del dominio para construir el análisis.
"""
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=4096,
                system=SYSTEM_PROMPT_PAPER,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw = response.content[0].text
            result = self._structure_output(raw)

        except Exception as e:
            error = str(e)
            logger.error(f"[PaperIntelligenceSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.85 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _extract_paper_content(self, tools: Dict[str, Any], context: Dict[str, Any]) -> str:
        """Extrae el contenido del paper desde tools o contexto RAG."""
        # Prioridad: contenido directo > RAG > descripción
        for key in ["paper", "document", "pdf_text", "text"]:
            val = tools.get(key)
            if val:
                return str(val)[:6000]

        # Intentar desde retrieved_documents del contexto
        docs = getattr(context, 'retrieved_documents', [])
        if docs:
            combined = []
            for doc in docs[:5]:
                text = doc.get("text", doc.get("content", ""))
                source = doc.get("source", "paper")
                combined.append(f"[{source}]:\n{text[:1500]}")
            return "\n\n".join(combined)

        return "Contenido del paper no disponible directamente. Analiza basándote en la consulta y el conocimiento del dominio."

    def _structure_output(self, raw_text: str) -> Dict[str, Any]:
        """Estructura la respuesta en secciones identificables."""
        import re

        sections = {
            "full_analysis": raw_text,
            "technical_summary": "",
            "executive_summary": "",
            "knowledge_graph_raw": "",
            "application_risks": "",
        }

        # Extraer secciones por encabezados comunes
        patterns = {
            "technical_summary": r"(?:extracción técnica|resumen técnico|technical)[:\s]+(.*?)(?=\n#{1,3}|\n\*{3}|$)",
            "executive_summary": r"(?:extracción ejecutiva|resumen ejecutivo|executive)[:\s]+(.*?)(?=\n#{1,3}|\n\*{3}|$)",
            "knowledge_graph_raw": r"(?:knowledge graph|mapa de relaciones|grafo)[:\s]+(.*?)(?=\n#{1,3}|\n\*{3}|$)",
            "application_risks": r"(?:riesgos de aplicación|riesgo|risks)[:\s]+(.*?)(?=\n#{1,3}|\n\*{3}|$)",
        }

        for key, pattern in patterns.items():
            match = re.search(pattern, raw_text, re.IGNORECASE | re.DOTALL)
            if match:
                sections[key] = match.group(1).strip()[:1500]

        return sections
