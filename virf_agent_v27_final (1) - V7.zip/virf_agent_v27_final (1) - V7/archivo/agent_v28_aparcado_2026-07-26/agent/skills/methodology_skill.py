"""
agent/skills/methodology_skill.py
===================================
Skill LLM para análisis profundo de solidez metodológica.
Evalúa sustento científico, regulatorio y estadístico.
"""

from __future__ import annotations
import json
import re
from typing import Dict, List, Any

import anthropic


PROMPT_METODOLOGIA = """Evalúa la solidez metodológica del siguiente texto y extrae hallazgos en JSON.

TEXTO A EVALUAR:
{texto}

CONTEXTO RAG (literatura recuperada):
{rag_contexto}

DOCUMENTOS DEL MODELO:
{docs_contexto}

DOMINIO FINANCIERO: {dominio}

Evalúa estas dimensiones:
1. SUSTENTO CIENTÍFICO: ¿Las metodologías tienen respaldo académico?
2. CUMPLIMIENTO REGULATORIO: ¿Cumple SR 11-7, EBA/GL/2023/01, BCBS, Basilea?
3. VALIDACIÓN ESTADÍSTICA: ¿Tiene backtesting, tests de hipótesis, IC?
4. DOCUMENTACIÓN: ¿Los supuestos y limitaciones están documentados?
5. CALIBRACIÓN: ¿Los parámetros tienen justificación cuantitativa?

Responde SOLO con JSON válido:
{{
  "dimensiones": {{
    "sustento_cientifico":    {{"score": 0-5, "observacion": "..."}},
    "cumplimiento_regulatorio": {{"score": 0-5, "observacion": "..."}},
    "validacion_estadistica": {{"score": 0-5, "observacion": "..."}},
    "documentacion":          {{"score": 0-5, "observacion": "..."}},
    "calibracion":            {{"score": 0-5, "observacion": "..."}}
  }},
  "score_global": 0.0,
  "hallazgos": [
    {{
      "tipo": "metodologia",
      "gravedad": "CRÍTICO"/"ALTO"/"MEDIO"/"BAJO",
      "descripcion": "descripción precisa",
      "dimension": "nombre de la dimensión afectada",
      "accion_requerida": "qué debe hacer el equipo para subsanar",
      "referencia": "norma o paper que respalda el hallazgo"
    }}
  ]
}}

score_global = promedio de las 5 dimensiones / 5.
Solo reporta hallazgos reales. Si una dimensión es adecuada, no generes hallazgo."""


class MethodologySkill:
    """Skill de verificación metodológica profunda con LLM."""

    def __init__(self, client: anthropic.Anthropic, modelo: str):
        self.client = client
        self.modelo = modelo

    def ejecutar(self, texto: str, dominio: str = "shared",
                 docs_contexto: str = "", rag_contexto: str = "") -> Dict[str, Any]:
        """
        Evalúa la solidez metodológica con el LLM.

        Returns:
            {
                "dimensiones": {...},
                "score_global": float,
                "hallazgos": List[Dict]
            }
        """
        prompt = PROMPT_METODOLOGIA.format(
            texto         = texto[:3000],
            rag_contexto  = rag_contexto[:800] if rag_contexto else "(sin literatura recuperada)",
            docs_contexto = docs_contexto[:800] if docs_contexto else "(sin documentos cargados)",
            dominio       = dominio,
        )

        try:
            resp = self.client.messages.create(
                model      = self.modelo,
                max_tokens = 1200,
                messages   = [{"role": "user", "content": prompt}],
            )
            raw = resp.content[0].text.strip()
            raw = re.sub(r"```json|```", "", raw).strip()
            return json.loads(raw)
        except Exception:
            return {"dimensiones": {}, "score_global": None, "hallazgos": []}
