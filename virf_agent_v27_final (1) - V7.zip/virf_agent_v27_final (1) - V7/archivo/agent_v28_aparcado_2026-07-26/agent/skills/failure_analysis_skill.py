"""
====================================================================
ARCHIVO: skills/failure_analysis_skill.py  — virf_agent_v28
====================================================================

SKILL: Failure Analysis
DOMINIO: Model Risk Management / Auditoría Cuantitativa
ROL SIMULADO: Head of Model Validation + MRM Specialist

OBJETIVO:
    Analizar críticamente un proyecto o modelo y detectar:
    - Errores conceptuales (supuestos inválidos)
    - Errores metodológicos (técnica incorrecta para el problema)
    - Errores estadísticos (violación de supuestos, overfitting, etc.)
    - Errores de ingeniería (data leakage, target leakage, etc.)
    - Riesgos regulatorios (incumplimiento normativo)
    - Riesgos operativos (dependencias frágiles, falta de monitoreo)
    - Riesgos de mantenimiento (deuda técnica, falta de documentación)

OUTPUT:
    {
        "findings": [{"id", "category", "description", "evidence", "severity"}],
        "risk_summary": {...},
        "recommendations": [...],
        "validation_score": float  # 0=muy riesgoso, 1=muy sólido
    }

====================================================================
"""

from typing import Dict, Any, List
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

SYSTEM_PROMPT_FAILURE = """
Eres un equipo multidisciplinario de auditoría cuantitativa compuesto por:
- Head of Model Validation (15 años en banca)
- MRM Specialist certificado en Basilea II/III/IV
- Estadístico senior especialista en modelos de riesgo de crédito
- Data Scientist con experiencia en auditoría de ML
- Regulatory Compliance Officer

Tu función es ÚNICAMENTE identificar fallas, riesgos y debilidades.
NUNCA asumas que una implementación es correcta sin evidencia.
SIEMPRE busca evidencia antes de validar un supuesto.
SIEMPRE clasifica los hallazgos por severidad: CRÍTICA / ALTA / MEDIA / BAJA.

Para cada hallazgo, estructura tu respuesta con exactamente estas secciones:

HALLAZGO [N]:
- Categoría: [Conceptual | Metodológico | Estadístico | Ingeniería | Regulatorio | Operativo | Mantenimiento]
- Descripción: [qué está mal y por qué]
- Evidencia: [dónde específicamente se observa el problema]
- Severidad: [CRÍTICA | ALTA | MEDIA | BAJA]
- Recomendación: [acción concreta para corregirlo]

Al final, entrega:
RESUMEN DE RIESGOS:
- Hallazgos críticos: N
- Hallazgos altos: N
- Hallazgos medios: N
- Hallazgos bajos: N
- Score de solidez: X/10 (donde 10 = modelo impecable, 0 = rechazar)

QUICK WINS (pueden implementarse en < 1 semana):
[lista]
"""


class FailureAnalysisSkill(BaseSkill):
    """
    Skill de análisis crítico de fallas para MRM.
    
    Simula un equipo independiente de validación que busca activamente
    errores, riesgos y debilidades en modelos financieros.
    """

    def __init__(self):
        super().__init__(
            name="failure_analysis",
            description=(
                "Análisis crítico de fallas: detecta errores conceptuales, "
                "metodológicos, estadísticos, de ingeniería y riesgos "
                "regulatorios/operativos en modelos financieros."
            ),
        )

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "falla", "error", "riesgo", "debilidad", "analiz", "audit",
            "revisar", "validar", "problema", "brecha", "hallazgo",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            # Extraer artefactos del contexto (código, documentación, etc.)
            artifacts = self._extract_artifacts(tools)
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)

            user_prompt = f"""{history}{rag_context}

ARTEFACTOS A ANALIZAR:
{artifacts}

CONSULTA DEL VALIDADOR:
{query}

Realiza un análisis exhaustivo de fallas. No omitas ningún hallazgo,
por menor que parezca. Los riesgos no detectados en validación son
los más costosos en producción y en revisiones regulatorias.
"""
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=4096,
                system=SYSTEM_PROMPT_FAILURE,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw_text = response.content[0].text
            result = self._parse_findings(raw_text)
            result["raw_analysis"] = raw_text

        except Exception as e:
            error = str(e)
            logger.error(f"[FailureAnalysisSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.90 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _extract_artifacts(self, tools: Dict[str, Any]) -> str:
        """Extrae artefactos disponibles (código, datos, docs) del context."""
        parts = []
        for key in ["code", "notebook", "document", "dataframe_info", "sql"]:
            val = tools.get(key)
            if val:
                parts.append(f"[{key.upper()}]:\n{str(val)[:3000]}")
        if not parts:
            return "No se proporcionaron artefactos específicos. Analiza basándote en la consulta."
        return "\n\n".join(parts)

    def _parse_findings(self, text: str) -> Dict[str, Any]:
        """Parsea el texto de respuesta en una estructura de hallazgos."""
        findings: List[Dict] = []
        risk_summary = {
            "critical": 0, "high": 0, "medium": 0, "low": 0,
            "solidarity_score": None,
        }

        # Extraer hallazgos por severidad (búsqueda simple)
        import re
        severity_counts = {
            "CRÍTICA": 0, "ALTA": 0, "MEDIA": 0, "BAJA": 0,
        }
        for sev in severity_counts:
            count = len(re.findall(rf"Severidad:\s*{sev}", text, re.IGNORECASE))
            severity_counts[sev] = count

        risk_summary["critical"] = severity_counts["CRÍTICA"]
        risk_summary["high"] = severity_counts["ALTA"]
        risk_summary["medium"] = severity_counts["MEDIA"]
        risk_summary["low"] = severity_counts["BAJA"]

        # Extraer score de solidez
        score_match = re.search(r"Score de solidez:\s*(\d+(?:\.\d+)?)/10", text)
        if score_match:
            risk_summary["solidarity_score"] = float(score_match.group(1))

        return {
            "findings_text": text,
            "risk_summary": risk_summary,
        }
