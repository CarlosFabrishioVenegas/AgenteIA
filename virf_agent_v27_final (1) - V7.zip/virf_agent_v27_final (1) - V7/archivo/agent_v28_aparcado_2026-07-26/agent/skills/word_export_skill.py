"""
agent/skills/word_export_skill.py
===================================
Exporta el informe de validación a un archivo .docx formateado.
Usa el mismo motor de la v25 (python-docx).
"""

from __future__ import annotations
from pathlib import Path
from typing import List, Dict
import datetime


def exportar_informe_word(
    informe:       str,
    hallazgos:     List[Dict],
    titulo_modelo: str,
    output_dir:    str,
    fecha:         str = "",
) -> str:
    """
    Exporta el informe de validación a Word.

    Args:
        informe:       Texto markdown del informe (de ConsolidatorSkill)
        hallazgos:     Lista de hallazgos acumulados
        titulo_modelo: Nombre del modelo
        output_dir:    Carpeta de destino
        fecha:         Timestamp para el nombre del archivo

    Returns:
        Ruta del archivo Word generado.
    """
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    fecha = fecha or datetime.datetime.now().strftime("%Y%m%d_%H%M")
    nombre_seg = titulo_modelo.replace(" ", "_").replace("/", "-")[:40]
    output_path = Path(output_dir) / f"Informe_Validacion_{nombre_seg}_{fecha}.docx"

    doc = Document()

    # ── Estilos básicos ───────────────────────────────────────────────────────
    style = doc.styles["Normal"]
    style.font.name = "Arial"
    style.font.size = Pt(11)

    AZUL   = RGBColor(0x1F, 0x4E, 0x79)
    ROJO   = RGBColor(0xC0, 0x00, 0x00)
    NARANJA = RGBColor(0xFF, 0x80, 0x00)

    # ── Portada ───────────────────────────────────────────────────────────────
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run("INFORME DE VALIDACIÓN INDEPENDIENTE")
    run.bold = True
    run.font.size = Pt(20)
    run.font.color.rgb = AZUL

    doc.add_paragraph()
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run2 = p2.add_run(titulo_modelo)
    run2.bold = True
    run2.font.size = Pt(16)

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p3.add_run(f"Fecha: {datetime.datetime.now().strftime('%d/%m/%Y')}")

    doc.add_page_break()

    # ── Tabla de resumen de hallazgos ─────────────────────────────────────────
    doc.add_heading("Resumen de Hallazgos", level=1)

    por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
    for h in hallazgos:
        g = h.get("gravedad", "MEDIO")
        por_gravedad.get(g, por_gravedad["MEDIO"]).append(h)

    tabla = doc.add_table(rows=1, cols=3)
    tabla.style = "Table Grid"
    hdr = tabla.rows[0].cells
    hdr[0].text = "Gravedad"
    hdr[1].text = "Cantidad"
    hdr[2].text = "Descripción representativa"
    for cell in hdr:
        for para in cell.paragraphs:
            for run in para.runs:
                run.bold = True

    colores_grav = {"CRÍTICO": ROJO, "ALTO": NARANJA,
                    "MEDIO": RGBColor(0xFF, 0xD7, 0x00), "BAJO": RGBColor(0x00, 0x80, 0x00)}
    for grav, items in por_gravedad.items():
        if items:
            row = tabla.add_row().cells
            row[0].text = grav
            row[1].text = str(len(items))
            row[2].text = items[0].get("descripcion", "")[:120]

    doc.add_paragraph()

    # ── Cuerpo del informe (markdown → Word básico) ───────────────────────────
    for linea in informe.split("\n"):
        linea = linea.strip()
        if not linea:
            doc.add_paragraph()
            continue
        if linea.startswith("# "):
            doc.add_heading(linea[2:], level=1)
        elif linea.startswith("## "):
            doc.add_heading(linea[3:], level=2)
        elif linea.startswith("### "):
            doc.add_heading(linea[4:], level=3)
        elif linea.startswith("**") and linea.endswith("**"):
            p = doc.add_paragraph()
            run = p.add_run(linea.strip("*"))
            run.bold = True
        elif linea.startswith("- ") or linea.startswith("* "):
            doc.add_paragraph(linea[2:], style="List Bullet")
        elif re.match(r"^\d+\.", linea):
            doc.add_paragraph(linea, style="List Number")
        else:
            doc.add_paragraph(linea)

    doc.save(str(output_path))
    return str(output_path)


# Import regex para la función
import re
