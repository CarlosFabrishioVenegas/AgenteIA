"""
agent/skills/consolidator_skill.py
=====================================
Genera el informe ejecutivo de validación consolidando todos los
hallazgos acumulados durante la conversación.

Se invoca con /validar y produce:
- Resumen ejecutivo
- Hallazgos por gravedad (CRÍTICO, ALTO, MEDIO, BAJO)
- Conclusiones por dimensión (fórmulas, metodología, datos)
- Plan de acción priorizado
- Veredicto final (APTO / APTO CON CONDICIONES / NO APTO)
"""

from __future__ import annotations
import json
from typing import Dict, List, Any

import anthropic


PROMPT_CONSOLIDADOR = """Eres un Validador Senior de Modelos de Riesgo Financiero.
Genera un INFORME EJECUTIVO DE VALIDACIÓN completo y estructurado.

MODELO BAJO VALIDACIÓN: {titulo_modelo}
DOMINIO: {dominio}
FECHA: {fecha}

HALLAZGOS ACUMULADOS EN LA SESIÓN:
{hallazgos_json}

RESUMEN DE LA CONVERSACIÓN:
{resumen_conversacion}

Genera el informe con estas secciones (en español técnico formal):

# INFORME DE VALIDACIÓN INDEPENDIENTE — {titulo_modelo}

## 1. RESUMEN EJECUTIVO
(3-4 párrafos: contexto, metodología de validación aplicada, hallazgos principales, veredicto)

## 2. ALCANCE Y METODOLOGÍA DE VALIDACIÓN
(qué se validó, qué documentos/fórmulas/código se revisó, limitaciones del proceso)

## 3. HALLAZGOS POR GRAVEDAD

### 3.1 Hallazgos CRÍTICOS
(lista numerada con descripción, impacto regulatorio/financiero, acción requerida y plazo)

### 3.2 Hallazgos ALTOS
(ídem)

### 3.3 Hallazgos MEDIOS y BAJOS
(tabla resumida)

## 4. ANÁLISIS POR DIMENSIÓN
- Solidez matemática y estadística
- Sustento científico y regulatorio
- Calidad de implementación
- Documentación y gobernanza

## 5. PLAN DE ACCIÓN PRIORIZADO
| Prioridad | Hallazgo | Responsable sugerido | Plazo recomendado |
(tabla con los hallazgos ordenados por urgencia)

## 6. VEREDICTO FINAL
**[APTO / APTO CON CONDICIONES / NO APTO PARA USO EN GESTIÓN]**
Justificación del veredicto en 2-3 párrafos.
Condiciones específicas si aplica (qué debe subsanarse antes de uso en producción).

## 7. REFERENCIAS REGULATORIAS APLICADAS
(lista de normas y papers citados en los hallazgos)

---
INSTRUCCIONES:
- Sé específico: cita fórmulas incorrectas con su corrección
- Cada hallazgo CRÍTICO debe tener: descripción técnica, referencia regulatoria, acción concreta
- El veredicto debe ser HONESTO aunque sea NO APTO
- Si los hallazgos son escasos, indícalo claramente (no infles el informe)
- Usa lenguaje técnico apropiado para un comité de riesgo bancario"""


class ConsolidatorSkill:
    """Skill de consolidación y generación del informe final de validación."""

    def __init__(self, client: anthropic.Anthropic, modelo: str):
        self.client = client
        self.modelo = modelo

    def generar_informe(
        self,
        titulo_modelo: str,
        dominio:       str,
        hallazgos:     List[Dict],
        resumen_conversacion: str = "",
    ) -> str:
        """
        Genera el informe ejecutivo de validación.

        Args:
            titulo_modelo:        nombre del modelo validado
            dominio:              LaR / VaR / conductuales / shared
            hallazgos:            lista de hallazgos acumulados
            resumen_conversacion: extracto de la conversación de la sesión

        Returns:
            Texto del informe ejecutivo (markdown)
        """
        import datetime
        fecha = datetime.datetime.now().strftime("%d de %B de %Y")

        # Serializar hallazgos, agrupando por gravedad
        por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
        for h in hallazgos:
            g = h.get("gravedad", "MEDIO")
            por_gravedad.get(g, por_gravedad["MEDIO"]).append(h)

        hallazgos_formateados = json.dumps(por_gravedad, ensure_ascii=False, indent=2)

        prompt = PROMPT_CONSOLIDADOR.format(
            titulo_modelo        = titulo_modelo,
            dominio              = dominio,
            fecha                = fecha,
            hallazgos_json       = hallazgos_formateados[:4000],
            resumen_conversacion = resumen_conversacion[:2000],
        )

        try:
            resp = self.client.messages.create(
                model      = self.modelo,
                max_tokens = 4096,
                messages   = [{"role": "user", "content": prompt}],
            )
            return resp.content[0].text.strip()
        except Exception as e:
            # Fallback: informe básico sin LLM
            return self._informe_basico(titulo_modelo, dominio, por_gravedad, fecha, str(e))

    def _informe_basico(self, titulo: str, dominio: str,
                        por_gravedad: Dict, fecha: str, error: str) -> str:
        """Informe de fallback si el LLM no está disponible."""
        criticos = por_gravedad.get("CRÍTICO", [])
        altos    = por_gravedad.get("ALTO",    [])
        total    = sum(len(v) for v in por_gravedad.values())

        veredicto = (
            "NO APTO PARA USO EN GESTIÓN" if criticos
            else ("APTO CON CONDICIONES" if altos else "APTO")
        )

        lines = [
            f"# INFORME DE VALIDACIÓN — {titulo}",
            f"**Dominio:** {dominio} | **Fecha:** {fecha}",
            f"**[LLM no disponible — informe básico: {error[:80]}]**",
            "",
            "## Resumen de Hallazgos",
            f"Total hallazgos: {total}",
        ]
        for grav, items in por_gravedad.items():
            if items:
                lines.append(f"\n### {grav} ({len(items)})")
                for h in items:
                    lines.append(f"- {h.get('descripcion','')[:150]}")

        lines += ["", f"## Veredicto: **{veredicto}**"]
        return "\n".join(lines)
