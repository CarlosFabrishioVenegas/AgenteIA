"""
====================================================================
ARCHIVO: skills/methodology_compliance_skill.py  — virf_agent_v28
====================================================================

SKILL: Methodology Compliance
DOMINIO: Model Governance / Cumplimiento Metodológico
ROL SIMULADO: Regulatory Compliance Officer + Head of Model Validation

OBJETIVO:
    Validar el cumplimiento de un proyecto contra:
    - Manuales metodológicos internos
    - Normativas bancarias (SBS, Basilea II/III/IV, BCBS 239, SR 11-7)
    - Guías regulatorias externas
    - Procedimientos y políticas internas del banco
    - Estándares de la industria (IFRS 9, CECL, etc.)

    Detecta específicamente:
    - Actividades faltantes en el ciclo de validación
    - Entregables obligatorios no producidos
    - Controles de riesgo no implementados
    - Evidencia insuficiente para sustentar conclusiones
    - Brechas de documentación (DMO, DTS, DSR)

OUTPUT:
    Checklist de cumplimiento con estado: ✓ CUMPLE / ✗ FALTA / ⚠ PARCIAL
    Brecha regulatoria cuantificada (% cumplimiento)

====================================================================
"""

from typing import Dict, Any, List
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

# Checklist base de cumplimiento MRM (adaptable por banco/regulador)
COMPLIANCE_CHECKLIST = {
    "Documentación del Modelo": [
        "Documento de Desarrollo del Modelo (DMO/DDS)",
        "Documento Técnico de Validación (DTV)",
        "Resumen Ejecutivo para comité",
        "Inventario de modelo actualizado",
        "Control de versiones documentado",
    ],
    "Desarrollo y Metodología": [
        "Justificación de la técnica elegida vs alternativas",
        "Análisis de supuestos del modelo",
        "Segmentación de población objetivo",
        "Tratamiento de valores atípicos documentado",
        "Análisis de multicolinealidad",
        "Validación de supuestos estadísticos",
        "Análisis de representatividad del dataset",
    ],
    "Pruebas de Validación": [
        "Prueba de discriminación (AUC/Gini/KS)",
        "Prueba de calibración (Hosmer-Lemeshow o equivalente)",
        "Backtesting sobre período out-of-time",
        "Pruebas de estabilidad poblacional (PSI)",
        "Análisis de sensibilidad / stress test",
        "Prueba de benchmark / modelo challenger",
        "Validación de implementación (UAT)",
    ],
    "Gobierno y Control": [
        "Aprobación formal del Comité de Modelos",
        "Designación de Model Owner",
        "Plan de monitoreo continuo definido",
        "Umbrales de alerta configurados",
        "Proceso de actualización documentado",
        "Plan de contingencia / modelo de respaldo",
    ],
    "Cumplimiento Regulatorio": [
        "Alineación con circular/resolución aplicable",
        "Opinión de cumplimiento normativo emitida",
        "Conservación de evidencias por período requerido",
        "Reporte a regulador si aplica",
    ],
}

SYSTEM_PROMPT_COMPLIANCE = """
Eres un equipo de Regulatory Compliance y Model Validation especializado
en normativa bancaria latinoamericana y estándares internacionales.

Tu función es realizar un CHECKLIST EXHAUSTIVO de cumplimiento metodológico.

Para CADA ítem del checklist:
1. Determina si se cumple: ✓ CUMPLE / ✗ FALTA / ⚠ PARCIAL
2. Proporciona evidencia de tu evaluación
3. Si falta: indica el impacto regulatorio y recomendación

Calcula al final:
- % de cumplimiento general
- % por categoría
- Nivel de riesgo regulatorio: ALTO / MEDIO / BAJO

Sé estricto. La ausencia de evidencia se considera INCUMPLIMIENTO.
"""


class MethodologyComplianceSkill(BaseSkill):
    """
    Skill de cumplimiento metodológico para MRM bancario.
    
    Valida proyectos contra normativas, manuales y estándares.
    Produce un checklist de cumplimiento con brechas identificadas.
    """

    def __init__(self, custom_checklist: Dict[str, List[str]] = None):
        super().__init__(
            name="methodology_compliance",
            description=(
                "Validación de cumplimiento contra manuales metodológicos, "
                "normativas internas y guías regulatorias bancarias. "
                "Identifica actividades, entregables y controles faltantes."
            ),
        )
        # Permite inyectar un checklist personalizado por banco
        self.checklist = custom_checklist or COMPLIANCE_CHECKLIST

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "cumplimiento", "compliance", "normativa", "manual", "política",
            "checklist", "faltante", "procedimiento", "regulatorio", "control",
            "entregable", "evidencia",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)
            artifacts = self._extract_artifacts(tools)
            checklist_text = self._format_checklist()

            user_prompt = f"""{history}{rag_context}

CHECKLIST DE CUMPLIMIENTO A EVALUAR:
{checklist_text}

ARTEFACTOS DEL PROYECTO BAJO VALIDACIÓN:
{artifacts}

CONSULTA:
{query}

Evalúa CADA ítem del checklist contra los artefactos proporcionados.
Si no hay suficiente información para evaluar un ítem, marca como ✗ FALTA
y señálalo como brecha de documentación.
"""
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=4096,
                system=SYSTEM_PROMPT_COMPLIANCE,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw = response.content[0].text
            result = {
                "compliance_report": raw,
                "checklist_categories": list(self.checklist.keys()),
                "total_items": sum(len(v) for v in self.checklist.values()),
            }

        except Exception as e:
            error = str(e)
            logger.error(f"[MethodologyComplianceSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.88 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _format_checklist(self) -> str:
        lines = []
        for category, items in self.checklist.items():
            lines.append(f"\n## {category}")
            for i, item in enumerate(items, 1):
                lines.append(f"  {i}. {item}")
        return "\n".join(lines)

    def _extract_artifacts(self, tools: Dict[str, Any]) -> str:
        parts = []
        for key in ["document", "code", "notebook", "dataframe_info"]:
            val = tools.get(key)
            if val:
                parts.append(f"[{key.upper()}]:\n{str(val)[:2500]}")
        return "\n\n".join(parts) if parts else "Sin artefactos proporcionados."
