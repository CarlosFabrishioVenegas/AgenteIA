"""
====================================================================
ARCHIVO: skills/documentation_audit_skill.py  — virf_agent_v28
====================================================================

SKILL: Documentation Audit
DOMINIO: Model Governance / Technical Audit
ROL SIMULADO: Financial Auditor + Head of Model Validation

OBJETIVO:
    Auditar la calidad y completitud de documentación técnica:
    - Documentos de Desarrollo del Modelo (DDM / DMO)
    - Documentos Técnicos de Validación (DTV)
    - Informes ejecutivos para comités
    - Manuales de seguimiento y monitoreo
    - Papers académicos como sustento metodológico
    - Especificaciones técnicas de implementación

    Detecta:
    - Secciones obligatorias faltantes
    - Afirmaciones sin sustento cuantitativo
    - Inconsistencias entre documentos
    - Lenguaje ambiguo en definiciones críticas
    - Ausencia de referencias bibliográficas
    - Versionado incorrecto o faltante

====================================================================
"""

from typing import Dict, Any, List
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

# Secciones obligatorias por tipo de documento
DOCUMENT_SECTIONS = {
    "DDM": [  # Documento de Desarrollo del Modelo
        "Objetivo y alcance del modelo",
        "Definición de la variable objetivo (target)",
        "Descripción de la población objetivo",
        "Fuentes de datos utilizadas",
        "Proceso de limpieza y transformación de datos",
        "Metodología seleccionada con justificación",
        "Análisis de variables (importancia, correlaciones)",
        "Proceso de entrenamiento y validación",
        "Métricas de desempeño del modelo",
        "Limitaciones del modelo",
        "Plan de monitoreo propuesto",
        "Anexos técnicos (código, notebooks)",
    ],
    "DTV": [  # Documento Técnico de Validación
        "Objetivo de la validación",
        "Alcance y limitaciones de la revisión",
        "Metodología de validación utilizada",
        "Revisión de datos y supuestos",
        "Pruebas de discriminación realizadas",
        "Pruebas de calibración realizadas",
        "Análisis de estabilidad (PSI)",
        "Modelo challenger evaluado",
        "Hallazgos y brechas identificadas",
        "Opinión de validación (APROBADO / CONDICIONADO / RECHAZADO)",
        "Recomendaciones y condiciones",
        "Seguimiento de hallazgos anteriores",
    ],
    "INFORME_EJECUTIVO": [
        "Resumen ejecutivo (máx 1 página)",
        "Propósito del modelo",
        "Conclusión de la validación",
        "Riesgos materiales identificados",
        "Condiciones de aprobación",
        "Próximos pasos y cronograma",
    ],
    "MANUAL_SEGUIMIENTO": [
        "Frecuencia de monitoreo",
        "KPIs y métricas a monitorear",
        "Umbrales de alerta (amarillo / rojo)",
        "Proceso de escalamiento",
        "Plan de recalibración",
        "Responsables y roles",
    ],
}

SYSTEM_PROMPT_DOC_AUDIT = """
Eres un Financial Auditor y Head of Model Validation especializado
en auditoría de documentación técnica de modelos bancarios.

Tu función: auditar la calidad y completitud de la documentación presentada.

Para cada documento analizado, evalúa:

1. COMPLETITUD
   ¿Están presentes todas las secciones obligatorias?
   Para cada sección: ✓ PRESENTE / ✗ AUSENTE / ⚠ INCOMPLETA

2. CALIDAD DE CONTENIDO
   Para cada sección presente:
   - ¿Las afirmaciones están sustentadas con datos?
   - ¿El lenguaje es preciso y sin ambigüedad?
   - ¿Las métricas tienen contexto suficiente?
   - ¿Las limitaciones están claramente declaradas?

3. CONSISTENCIA
   ¿Los números, definiciones y conclusiones son coherentes
   entre secciones y entre documentos relacionados?

4. TRAZABILIDAD
   ¿Puede rastrearse cada afirmación hasta su fuente de datos?
   ¿Las referencias bibliográficas son precisas y verificables?

5. HALLAZGOS DE AUDITORÍA
   Para cada problema detectado:
   - Ubicación exacta en el documento
   - Tipo: COMPLETITUD / CALIDAD / CONSISTENCIA / TRAZABILIDAD
   - Severidad: CRÍTICA / ALTA / MEDIA / BAJA
   - Corrección requerida

6. CALIFICACIÓN GLOBAL
   Score de calidad: X/10
   Dictamen: APROBADO / REQUIERE CORRECCIONES / RECHAZADO

Recuerda: la documentación insuficiente es, por sí misma,
un hallazgo de riesgo de modelo. No la documentation, no la approbation.
"""


class DocumentationAuditSkill(BaseSkill):
    """
    Skill de auditoría de documentación técnica y metodológica.
    
    Evalúa completitud, calidad, consistencia y trazabilidad
    de DDM, DTV, informes ejecutivos y manuales de seguimiento.
    """

    def __init__(self):
        super().__init__(
            name="documentation_audit",
            description=(
                "Auditoría de documentación técnica: evalúa completitud, "
                "calidad y trazabilidad de DDM, DTV, informes ejecutivos "
                "y manuales de seguimiento para MRM bancario."
            ),
        )

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "documentación", "documento", "informe", "reporte", "manual",
            "auditoría", "revisar", "calidad", "completitud", "dmo", "dtv",
            "especificación", "trazabilidad",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)
            doc_type = self._detect_doc_type(query, tools)
            sections_checklist = self._get_sections_for_type(doc_type)
            document_content = self._extract_document(tools, context)

            user_prompt = f"""{history}{rag_context}

TIPO DE DOCUMENTO DETECTADO: {doc_type}

SECCIONES OBLIGATORIAS A VERIFICAR:
{sections_checklist}

CONTENIDO DEL DOCUMENTO:
{document_content}

CONSULTA DE AUDITORÍA:
{query}

Realiza la auditoría completa. Si el documento no está disponible
directamente, evalúa basándote en las descripciones y artefactos
proporcionados, marcando como ✗ AUSENTE todo lo que no pueda
verificarse con la información disponible.
"""
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=3072,
                system=SYSTEM_PROMPT_DOC_AUDIT,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw = response.content[0].text
            result = {
                "audit_report": raw,
                "doc_type_detected": doc_type,
                "sections_evaluated": len(DOCUMENT_SECTIONS.get(doc_type, [])),
            }

        except Exception as e:
            error = str(e)
            logger.error(f"[DocumentationAuditSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.84 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _detect_doc_type(self, query: str, tools: Dict[str, Any]) -> str:
        """Detecta el tipo de documento basado en la query y herramientas."""
        q = query.lower()
        if any(t in q for t in ["ddm", "desarrollo", "development"]):
            return "DDM"
        if any(t in q for t in ["dtv", "validación", "validacion", "validation"]):
            return "DTV"
        if any(t in q for t in ["ejecutivo", "comité", "board", "directivo"]):
            return "INFORME_EJECUTIVO"
        if any(t in q for t in ["seguimiento", "monitoreo", "monitoring"]):
            return "MANUAL_SEGUIMIENTO"
        return "DDM"  # default

    def _get_sections_for_type(self, doc_type: str) -> str:
        sections = DOCUMENT_SECTIONS.get(doc_type, DOCUMENT_SECTIONS["DDM"])
        lines = [f"  {i+1}. {s}" for i, s in enumerate(sections)]
        return "\n".join(lines)

    def _extract_document(self, tools: Dict[str, Any], context: Dict[str, Any]) -> str:
        for key in ["document", "pdf_text", "text", "code"]:
            val = tools.get(key)
            if val:
                return str(val)[:5000]
        docs = getattr(context, 'retrieved_documents', [])
        if docs:
            return "\n\n".join(
                doc.get("text", "")[:1000] for doc in docs[:4]
            )
        return "Documento no proporcionado directamente."
