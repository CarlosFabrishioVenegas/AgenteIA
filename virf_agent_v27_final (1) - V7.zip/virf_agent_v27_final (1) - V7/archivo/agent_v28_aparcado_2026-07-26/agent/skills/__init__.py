"""
Skills de virf_agent_v28 — Model Risk Management Platform
8 skills especializadas en validación, auditoría y gobierno de modelos.
"""
from .base_skill import BaseSkill
from .failure_analysis_skill import FailureAnalysisSkill
from .methodology_compliance_skill import MethodologyComplianceSkill
from .challenger_generation_skill import ChallengerGenerationSkill
from .paper_intelligence_skill import PaperIntelligenceSkill
from .repo_reconstruction_skill import RepoReconstructionSkill
from .regulatory_review_skill import RegulatoryReviewSkill
from .documentation_audit_skill import DocumentationAuditSkill
from .model_governance_skill import ModelGovernanceSkill

__all__ = [
    "BaseSkill",
    "FailureAnalysisSkill",
    "MethodologyComplianceSkill",
    "ChallengerGenerationSkill",
    "PaperIntelligenceSkill",
    "RepoReconstructionSkill",
    "RegulatoryReviewSkill",
    "DocumentationAuditSkill",
    "ModelGovernanceSkill",
]
