"""
====================================================================
ARCHIVO: skills/repo_reconstruction_skill.py  — virf_agent_v28
====================================================================

SKILL: Repository Reconstruction
DOMINIO: Code Audit / Technical Due Diligence
ROL SIMULADO: ML Engineer senior + Principal Engineer

OBJETIVO:
    Recibir cualquier combinación de:
    - Python (.py)
    - Notebooks (.ipynb)
    - SQL (.sql)
    - Excel/JSON (.xlsx, .json)
    
    Y reconstruir completamente:
    - Arquitectura del proyecto
    - Dependencias entre módulos
    - Flujo de ejecución end-to-end
    - Flujo de datos

    Generar: project_reverse_engineering.ipynb
    con árbol del proyecto, análisis de dependencias, descripción
    de módulos, diagramas Mermaid, flujo de datos, flujo de
    ejecución y riesgos detectados.

====================================================================
"""

from typing import Dict, Any, List
import logging
import time
import json
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

SYSTEM_PROMPT_REPO = """
Eres un Principal Engineer y ML Architect con experiencia en auditoría
técnica de proyectos de ciencia de datos y machine learning bancario.

Tu misión: reconstruir completamente la arquitectura de un proyecto
a partir de su código fuente, sin documentación previa.

Para cada componente analizado, debes producir:

## 1. ÁRBOL DEL PROYECTO
```
project/
├── módulo_a/
│   ├── archivo_1.py  # [propósito en 1 línea]
│   └── archivo_2.py  # [propósito en 1 línea]
└── ...
```

## 2. ANÁLISIS DE DEPENDENCIAS
Para cada módulo: qué importa, qué exporta, quién lo llama.
Identifica dependencias circulares y acoplamiento excesivo.

## 3. DESCRIPCIÓN DE MÓDULOS
Para cada módulo crítico:
- Propósito
- Inputs / Outputs
- Complejidad: BAJA / MEDIA / ALTA
- Riesgo si falla

## 4. DIAGRAMAS MERMAID
Genera al menos:
a) Diagrama de flujo de ejecución (flowchart)
b) Diagrama de dependencias entre módulos (graph)
c) Diagrama de flujo de datos (flowchart)

Formato:
```mermaid
flowchart TD
    A[Inicio] --> B[Módulo X]
    B --> C{Decisión}
    ...
```

## 5. FLUJO DE DATOS
Trace completo desde la fuente de datos hasta el output final.
Identifica: transformaciones, validaciones, puntos de pérdida de datos.

## 6. FLUJO DE EJECUCIÓN
Secuencia de ejecución: qué se ejecuta primero, qué depende de qué.
Identifica: puntos de fallo, dependencias de orden, paralelizables.

## 7. RIESGOS DETECTADOS
Clasifica por: Data Leakage / Deuda Técnica / Seguridad / Mantenimiento / Escalabilidad.
Severidad: CRÍTICA / ALTA / MEDIA / BAJA.

Sé exhaustivo. Un auditor técnico necesita entender el proyecto
mejor que quien lo construyó, para poder certificar su calidad.
"""

NOTEBOOK_TEMPLATE = '''{{
 "cells": [
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": [
    "# Project Reverse Engineering Report\\n",
    "**Generado por:** virf_agent_v28 — Repository Reconstruction Skill\\n",
    "**Fecha:** {date}\\n",
    "---"
   ]
  }},
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": ["## Árbol del Proyecto\\n", "{tree_section}"]
  }},
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": ["## Análisis de Dependencias\\n", "{dependencies_section}"]
  }},
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": ["## Descripción de Módulos\\n", "{modules_section}"]
  }},
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": ["## Diagramas Mermaid\\n", "{mermaid_section}"]
  }},
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": ["## Flujo de Datos\\n", "{dataflow_section}"]
  }},
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": ["## Flujo de Ejecución\\n", "{execflow_section}"]
  }},
  {{
   "cell_type": "markdown",
   "metadata": {{}},
   "source": ["## Riesgos Detectados\\n", "{risks_section}"]
  }},
  {{
   "cell_type": "code",
   "execution_count": null,
   "metadata": {{}},
   "outputs": [],
   "source": [
    "# Análisis de dependencias automático\\n",
    "# Ejecutar en el directorio raíz del proyecto\\n",
    "import subprocess, sys\\n",
    "result = subprocess.run([sys.executable, '-c',\\n",
    "    'import ast, os\\n",
    "    files = [f for r,d,fs in os.walk(\\'.\\') for f in fs if f.endswith(\\'.py\\')]\\n",
    "    for f in files[:20]: print(f)\\n",
    "    '], capture_output=True, text=True)\\n",
    "print(result.stdout)"
   ]
  }}
 ],
 "metadata": {{
  "kernelspec": {{"display_name": "Python 3", "language": "python", "name": "python3"}},
  "language_info": {{"name": "python", "version": "3.10.0"}}
 }},
 "nbformat": 4,
 "nbformat_minor": 5
}}'''


class RepoReconstructionSkill(BaseSkill):
    """
    Skill de reconstrucción de repositorios para auditoría técnica.
    
    Realiza reverse engineering completo de proyectos Python/ML
    y genera un notebook de documentación con diagramas Mermaid.
    """

    def __init__(self, output_path: str = "outputs/project_reverse_engineering.ipynb"):
        super().__init__(
            name="repo_reconstruction",
            description=(
                "Reverse engineering de repositorios: reconstruye arquitectura, "
                "dependencias y flujo de ejecución. Genera notebook con árbol "
                "del proyecto, diagramas Mermaid y riesgos detectados."
            ),
        )
        self.output_path = output_path

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "repositorio", "repo", "código", "notebook", "script",
            "pipeline", "reverse", "reconstruir", "arquitectura", "flujo",
            "dependencia", "árbol", "estructura", "carpeta",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)
            artifacts = self._collect_artifacts(tools)

            user_prompt = f"""{history}{rag_context}

ARTEFACTOS DEL PROYECTO A RECONSTRUIR:
{artifacts}

SOLICITUD:
{query}

Genera el análisis completo de reconstrucción del repositorio
siguiendo exactamente las 7 secciones del sistema prompt.
Incluye al menos 3 diagramas Mermaid (flujo de ejecución,
dependencias entre módulos y flujo de datos).
"""
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=4096,
                system=SYSTEM_PROMPT_REPO,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw = response.content[0].text
            notebook_path = self._generate_notebook(raw)

            result = {
                "reconstruction_analysis": raw,
                "notebook_path": notebook_path,
                "mermaid_diagrams": self._extract_mermaid_blocks(raw),
            }

        except Exception as e:
            error = str(e)
            logger.error(f"[RepoReconstructionSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.88 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _collect_artifacts(self, tools: Dict[str, Any]) -> str:
        parts = []
        for key in ["code", "notebook", "sql", "json_data", "dataframe_info", "document"]:
            val = tools.get(key)
            if val:
                parts.append(f"[{key.upper()}]:\n{str(val)[:2500]}")
        return "\n\n".join(parts) if parts else "Sin artefactos. Usa la consulta para orientar el análisis."

    def _extract_mermaid_blocks(self, text: str) -> List[str]:
        import re
        return re.findall(r"```mermaid\s*(.*?)```", text, re.DOTALL)

    def _generate_notebook(self, analysis_text: str) -> str:
        """Genera un notebook .ipynb con el análisis de reconstrucción."""
        from datetime import datetime
        import os

        # Escapar el texto para JSON
        def safe(text: str, limit: int = 800) -> str:
            return json.dumps(text[:limit])[1:-1]  # quitar comillas externas

        sections = self._split_sections(analysis_text)

        notebook_content = NOTEBOOK_TEMPLATE.format(
            date=datetime.now().strftime("%Y-%m-%d %H:%M"),
            tree_section=safe(sections.get("tree", analysis_text[:400])),
            dependencies_section=safe(sections.get("dependencies", "")),
            modules_section=safe(sections.get("modules", "")),
            mermaid_section=safe(sections.get("mermaid", "")),
            dataflow_section=safe(sections.get("dataflow", "")),
            execflow_section=safe(sections.get("execflow", "")),
            risks_section=safe(sections.get("risks", "")),
        )

        os.makedirs(os.path.dirname(self.output_path) if os.path.dirname(self.output_path) else ".", exist_ok=True)
        try:
            with open(self.output_path, "w", encoding="utf-8") as f:
                f.write(notebook_content)
            logger.info(f"[RepoReconstructionSkill] Notebook guardado: {self.output_path}")
            return self.output_path
        except Exception as e:
            logger.warning(f"[RepoReconstructionSkill] Error guardando notebook: {e}")
            return ""

    def _split_sections(self, text: str) -> Dict[str, str]:
        """Divide el análisis en secciones identificables."""
        import re
        keys = {
            "tree": r"(?:árbol|tree|estructura del proyecto)[^\n]*\n(.*?)(?=##|\Z)",
            "dependencies": r"(?:dependencias|dependencies)[^\n]*\n(.*?)(?=##|\Z)",
            "modules": r"(?:módulos|modules|descripción)[^\n]*\n(.*?)(?=##|\Z)",
            "mermaid": r"(```mermaid.*?```)",
            "dataflow": r"(?:flujo de datos|data flow)[^\n]*\n(.*?)(?=##|\Z)",
            "execflow": r"(?:flujo de ejecución|execution flow)[^\n]*\n(.*?)(?=##|\Z)",
            "risks": r"(?:riesgos|risks)[^\n]*\n(.*?)(?=##|\Z)",
        }
        sections = {}
        for key, pattern in keys.items():
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                sections[key] = match.group(1).strip()
        return sections
