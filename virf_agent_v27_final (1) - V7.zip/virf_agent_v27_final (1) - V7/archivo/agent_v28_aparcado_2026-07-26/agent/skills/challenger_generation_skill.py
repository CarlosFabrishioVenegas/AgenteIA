"""
====================================================================
ARCHIVO: skills/challenger_generation_skill.py  — virf_agent_v28
====================================================================

SKILL: Challenger Generation
DOMINIO: Model Validation / Independent Review
ROL SIMULADO: Equipo independiente de validación + Data Scientist senior

OBJETIVO:
    Actuar como equipo independiente de validación que:
    - Cuestiona supuestos del modelo champion
    - Busca debilidades metodológicas activamente
    - Genera hipótesis alternativas
    - Identifica riesgos ocultos
    - Diseña y genera pruebas de validación ejecutables

CAPACIDAD CENTRAL:
    Genera automáticamente challenger_analysis.py — un script Python
    ejecutable directamente que demuestra hallazgos con datos reales.

OUTPUT ESTRUCTURA:
    {
        "hypotheses": [...],          # Hipótesis alternativas cuestionadas
        "weaknesses": [...],          # Debilidades encontradas
        "challenger_script": str,     # código Python ejecutable
        "additional_tests": [...]     # pruebas adicionales recomendadas
    }

====================================================================
"""

from typing import Dict, Any, List
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

SYSTEM_PROMPT_CHALLENGER = """
Eres un equipo de validación independiente de modelos financieros.
Tu identidad central: NUNCA aceptas un modelo como correcto sin evidencia propia.

Tu misión:
1. Cuestionar CADA supuesto del modelo champion
2. Identificar debilidades que el equipo de desarrollo pudo haber pasado por alto
3. Generar hipótesis alternativas verificables
4. Diseñar pruebas estadísticas que puedan refutar o confirmar los supuestos
5. Producir un script Python ejecutable (challenger_analysis.py)

El script debe:
- Ser ejecutable con: python challenger_analysis.py
- Incluir imports estándar (pandas, numpy, scipy, sklearn, matplotlib)
- Tener secciones claramente comentadas
- Producir outputs interpretables (métricas, gráficos, tablas)
- Documentar cada prueba con su hipótesis nula y alternativa
- Incluir conclusiones automatizadas

Estructura del script:
```
# ============================================================
# CHALLENGER ANALYSIS — virf_agent_v28
# Generado automáticamente por el Challenger Generation Skill
# ============================================================
# HIPÓTESIS CUESTIONADAS:
# [lista de supuestos cuestionados]
# ============================================================

import pandas as pd
import numpy as np
...

# SECCIÓN 1: [Nombre de la prueba]
# Hipótesis nula: ...
# Hipótesis alternativa: ...
...

# CONCLUSIÓN AUTOMÁTICA
...
```

Sé exhaustivo. Un challenger débil no protege al banco de riesgos reales.
"""

SYSTEM_PROMPT_HYPOTHESES = """
Eres un Head of Model Validation con 20 años de experiencia.
Tu tarea: identificar todos los supuestos implícitos y explícitos de un modelo
y generar hipótesis alternativas que podrían invalidarlo.

Para cada supuesto:
1. Identifica el supuesto
2. Evalúa su validez (VÁLIDO / CUESTIONABLE / INVÁLIDO)
3. Genera la hipótesis alternativa
4. Propón la prueba estadística para verificarla
5. Evalúa el impacto si el supuesto es incorrecto (CRÍTICO / ALTO / MEDIO / BAJO)
"""


class ChallengerGenerationSkill(BaseSkill):
    """
    Skill de generación de challengers para validación independiente.
    
    Produce scripts Python ejecutables que demuestran hallazgos
    y ponen a prueba los supuestos del modelo bajo validación.
    """

    def __init__(self, output_path: str = "outputs/challenger_analysis.py"):
        super().__init__(
            name="challenger_generation",
            description=(
                "Genera análisis challenger independiente: cuestiona supuestos, "
                "identifica riesgos ocultos y produce scripts Python ejecutables "
                "con pruebas estadísticas reproducibles."
            ),
        )
        self.output_path = output_path

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "challenger", "alternativ", "cuestionar", "hipótesis", "supuesto",
            "generar", "script", "prueba", "validación independiente", "demostrar",
            "refutar", "debilidad", "riesgo oculto",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)
            artifacts = self._extract_artifacts(tools)

            client = anthropic.Anthropic()

            # Paso 1: Generar hipótesis y debilidades
            hypotheses_prompt = f"""{history}{rag_context}

MODELO / PROYECTO BAJO CHALLENGER REVIEW:
{artifacts}

CONSULTA:
{query}

Identifica todos los supuestos del modelo y genera hipótesis alternativas.
"""
            hyp_response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=2048,
                system=SYSTEM_PROMPT_HYPOTHESES,
                messages=[{"role": "user", "content": hypotheses_prompt}],
            )
            hypotheses_text = hyp_response.content[0].text

            # Paso 2: Generar script Python ejecutable
            script_prompt = f"""{rag_context}

HIPÓTESIS Y DEBILIDADES IDENTIFICADAS:
{hypotheses_text}

ARTEFACTOS DEL PROYECTO:
{artifacts}

SOLICITUD:
{query}

Genera un script Python completo y ejecutable (challenger_analysis.py)
que implemente las pruebas necesarias para validar o refutar cada hipótesis.
El script debe poder ejecutarse directamente con datos de ejemplo si no
se proporcionan datos reales.
"""
            script_response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=4096,
                system=SYSTEM_PROMPT_CHALLENGER,
                messages=[{"role": "user", "content": script_prompt}],
            )
            script_text = script_response.content[0].text

            # Extraer el bloque de código Python
            challenger_script = self._extract_python_code(script_text)

            # Guardar el script en disco
            if challenger_script:
                self._save_script(challenger_script)

            result = {
                "hypotheses_analysis": hypotheses_text,
                "challenger_script": challenger_script,
                "script_saved_to": self.output_path if challenger_script else None,
                "full_generation_text": script_text,
            }

        except Exception as e:
            error = str(e)
            logger.error(f"[ChallengerGenerationSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.87 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _extract_python_code(self, text: str) -> str:
        """Extrae bloques de código Python del texto de respuesta."""
        import re
        # Buscar bloques ```python ... ```
        pattern = r"```python\s*(.*?)```"
        matches = re.findall(pattern, text, re.DOTALL)
        if matches:
            return "\n\n".join(matches)
        # Si no hay bloques explícitos, buscar el código directamente
        if "import pandas" in text or "import numpy" in text:
            return text
        return ""

    def _save_script(self, script: str) -> None:
        """Guarda el script challenger en disco."""
        import os
        os.makedirs(os.path.dirname(self.output_path) if os.path.dirname(self.output_path) else ".", exist_ok=True)
        try:
            with open(self.output_path, "w", encoding="utf-8") as f:
                f.write("# ============================================================\n")
                f.write("# CHALLENGER ANALYSIS — virf_agent_v28\n")
                f.write("# Generado automáticamente por Challenger Generation Skill\n")
                f.write("# ============================================================\n\n")
                f.write(script)
            logger.info(f"[ChallengerGenerationSkill] Script guardado: {self.output_path}")
        except Exception as e:
            logger.warning(f"[ChallengerGenerationSkill] No se pudo guardar script: {e}")

    def _extract_artifacts(self, tools: Dict[str, Any]) -> str:
        parts = []
        for key in ["code", "notebook", "document", "dataframe_info", "model_info"]:
            val = tools.get(key)
            if val:
                parts.append(f"[{key.upper()}]:\n{str(val)[:3000]}")
        return "\n\n".join(parts) if parts else "Sin artefactos. Genera challenger genérico basado en la consulta."
