"""
====================================================================
ARCHIVO: skills/regulatory_review_skill.py  — virf_agent_v28
====================================================================

SKILL: Regulatory Review
DOMINIO: Regulatory Compliance / Model Risk Management
ROL SIMULADO: Regulatory Compliance Officer + Banking Risk Specialist

OBJETIVO:
    Revisar el cumplimiento regulatorio de modelos y proyectos contra:
    - Basilea II / III / IV
    - SR 11-7 (Federal Reserve — Model Risk Management)
    - BCBS 239 (Risk Data Aggregation)
    - IFRS 9 (Provisiones)
    - Normativas SBS (Superintendencia de Banca y Seguros — Perú)
    - Circulares y resoluciones locales aplicables

MARCOS REGULATORIOS CUBIERTOS:
    - Capital regulatorio: RWA, capital de nivel 1/2
    - Riesgo de crédito: PD, LGD, EAD, EL
    - Stress testing: DFAST, CCAR
    - Backtesting regulatorio
    - Validación independiente obligatoria (SR 11-7)

====================================================================
"""

from typing import Dict, Any, List
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

REGULATORY_FRAMEWORKS = {
    "SR 11-7": {
        "descripcion": "Federal Reserve — Guía de Model Risk Management",
        "requerimientos_clave": [
            "Validación independiente del modelo",
            "Documentación completa del desarrollo",
            "Inventario de modelos actualizado",
            "Monitoreo continuo post-implementación",
            "Aprobación formal antes de uso en producción",
            "Limitaciones del modelo documentadas y comunicadas",
        ],
    },
    "Basilea II/III": {
        "descripcion": "Marco de capital regulatorio internacional",
        "requerimientos_clave": [
            "IRB aprobado por regulador si aplica",
            "Backtesting de PD con al menos 1 año de datos",
            "Validación de LGD y EAD",
            "Stress testing bajo escenarios adversos",
            "Segregación de funciones: desarrollo vs validación",
        ],
    },
    "BCBS 239": {
        "descripcion": "Principios para agregación efectiva de datos de riesgo",
        "requerimientos_clave": [
            "Trazabilidad completa de datos",
            "Exactitud y completitud de datos de riesgo",
            "Reportes oportunos ante crisis",
            "Arquitectura de datos robusta",
        ],
    },
    "IFRS 9": {
        "descripcion": "Provisiones dinámicas y pérdida crediticia esperada",
        "requerimientos_clave": [
            "Segmentación en etapas (Stage 1/2/3)",
            "Información forward-looking incorporada",
            "Backtesting de ECL vs pérdidas reales",
            "Documentación de supuestos macroeconómicos",
        ],
    },
    "SBS Perú": {
        "descripcion": "Normativa de la Superintendencia de Banca y Seguros",
        "requerimientos_clave": [
            "Reglamento para la Gestión del Riesgo de Crédito",
            "Circular de Riesgo Operacional",
            "Requerimiento de capital adicional por riesgo de modelo",
            "Informe de validación interna",
        ],
    },
}

SYSTEM_PROMPT_REGULATORY = """
Eres un Regulatory Compliance Officer y Banking Risk Specialist con
experiencia en banca latinoamericana y marcos internacionales.

Tu función: realizar una revisión regulatoria exhaustiva del modelo
o proyecto presentado.

Para cada marco regulatorio aplicable:

1. APLICABILIDAD
   ¿Este marco aplica al modelo/proyecto? Justifica.

2. ESTADO DE CUMPLIMIENTO
   Para cada requerimiento clave:
   ✓ CUMPLE — con evidencia
   ✗ INCUMPLE — con descripción del gap
   ⚠ PARCIAL — con descripción de lo faltante
   N/A — no aplica, con justificación

3. BRECHAS CRÍTICAS
   Requerimientos incumplidos que generan riesgo regulatorio inmediato.

4. IMPACTO DE INCUMPLIMIENTO
   Para cada brecha: impacto potencial (multa, suspensión, recalificación de riesgo, etc.)

5. PLAN DE REMEDIACIÓN
   Acción concreta, responsable sugerido y plazo estimado.

6. OPINIÓN DE CUMPLIMIENTO
   APROBADO / APROBADO CON CONDICIONES / RECHAZADO (con justificación)

Sé estricto. El costo de un incumplimiento regulatorio es siempre
mayor que el costo de la corrección preventiva.
"""


class RegulatoryReviewSkill(BaseSkill):
    """
    Skill de revisión regulatoria para modelos bancarios.
    
    Evalúa el cumplimiento contra SR 11-7, Basilea II/III,
    BCBS 239, IFRS 9 y normativas SBS.
    """

    def __init__(self, applicable_frameworks: List[str] = None):
        super().__init__(
            name="regulatory_review",
            description=(
                "Revisión regulatoria de modelos: evalúa cumplimiento contra "
                "SR 11-7, Basilea II/III/IV, BCBS 239, IFRS 9 y normativas "
                "SBS. Produce opinión de cumplimiento con plan de remediación."
            ),
        )
        # Frameworks a evaluar (por defecto todos)
        self.applicable_frameworks = applicable_frameworks or list(REGULATORY_FRAMEWORKS.keys())

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "regulatorio", "regulación", "basilea", "sbs", "bcbs", "sr 11-7",
            "ifrs", "normativa", "capital", "cumplimiento", "requerimiento",
            "circular", "resolución", "stress test",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)
            artifacts = self._extract_artifacts(tools)
            frameworks_summary = self._build_frameworks_context()

            user_prompt = f"""{history}{rag_context}

MARCOS REGULATORIOS A EVALUAR:
{frameworks_summary}

ARTEFACTOS DEL MODELO / PROYECTO:
{artifacts}

CONSULTA:
{query}

Realiza la revisión regulatoria completa para cada marco aplicable.
Si el modelo tiene propósito de riesgo de crédito, prioriza:
Basilea II/III, IFRS 9 y SR 11-7.
Si es para reportes de riesgo, prioriza BCBS 239.
"""
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=4096,
                system=SYSTEM_PROMPT_REGULATORY,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw = response.content[0].text
            result = {
                "regulatory_opinion": raw,
                "frameworks_evaluated": self.applicable_frameworks,
                "total_requirements_checked": sum(
                    len(REGULATORY_FRAMEWORKS[f]["requerimientos_clave"])
                    for f in self.applicable_frameworks
                    if f in REGULATORY_FRAMEWORKS
                ),
            }

        except Exception as e:
            error = str(e)
            logger.error(f"[RegulatoryReviewSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.86 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _build_frameworks_context(self) -> str:
        lines = []
        for name in self.applicable_frameworks:
            fw = REGULATORY_FRAMEWORKS.get(name)
            if fw:
                lines.append(f"\n### {name}: {fw['descripcion']}")
                for req in fw["requerimientos_clave"]:
                    lines.append(f"  - {req}")
        return "\n".join(lines)

    def _extract_artifacts(self, tools: Dict[str, Any]) -> str:
        parts = []
        for key in ["document", "code", "model_info", "dataframe_info"]:
            val = tools.get(key)
            if val:
                parts.append(f"[{key.upper()}]:\n{str(val)[:2500]}")
        return "\n\n".join(parts) if parts else "Sin artefactos. Analiza basándote en la consulta."
