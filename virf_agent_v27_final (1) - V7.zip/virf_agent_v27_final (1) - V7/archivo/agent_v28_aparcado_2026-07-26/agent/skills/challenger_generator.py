"""
challenger_generator.py
=======================
Genera un Jupyter Notebook con un challenger model mejorado basado en
los hallazgos del agente, el razonamiento aplicado y las mejores prácticas
del RAG.

Flujo:
1. Recopila hallazgos acumulados
2. Analiza el razonamiento del agente
3. Extrae lecciones del RAG (papers, mejores prácticas)
4. Genera propuestas de mejora
5. Crea Jupyter Notebook ejecutable con:
   - Importaciones
   - Data setup
   - Modelo original (con problemas)
   - Challenger model (mejorado)
   - Comparación de resultados
   - Recomendaciones finales
"""

import json
import datetime
from pathlib import Path
from typing import Dict, List, Any

try:
    from nbformat import v4 as nbf
    NBFORMAT_AVAILABLE = True
except ImportError:
    NBFORMAT_AVAILABLE = False


class ChallengerGenerator:
    """Genera Jupyter Notebook con challenger mejorado."""
    
    def __init__(self, titulo_modelo: str, dominio: str, hallazgos: List[Dict]):
        self.titulo_modelo = titulo_modelo
        self.dominio = dominio
        self.hallazgos = hallazgos
        self.timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Agrupar hallazgos por gravedad
        self.por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
        for h in hallazgos:
            g = h.get("gravedad", "BAJO")
            self.por_gravedad.get(g, self.por_gravedad["BAJO"]).append(h)
    
    def generar_notebook(self) -> str:
        """Genera notebook basado en dominio."""
        if self.dominio == "LaR":
            return self._generar_notebook_lar()
        elif self.dominio == "VaR":
            return self._generar_notebook_var()
        else:
            return self._generar_notebook_generico()
    
    def _generar_notebook_lar(self) -> str:
        """Notebook challenger para modelos LaR."""
        
        if not NBFORMAT_AVAILABLE:
            return self._generar_notebook_html_lar()
        
        nb = nbf.new_notebook()
        
        # ===== CELL 1: Título y descripción
        nb.cells.append(nbf.new_markdown_cell(f"""
# Challenger Model: {self.titulo_modelo}
## Modelo Mejorado basado en Validación Independiente

**Fecha**: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}
**Dominio**: LaR (Loss at Risk / Pérdida en Riesgo)
**Tipo**: Modelo Challenger generado automáticamente

### Antecedentes
Este notebook contiene un modelo challenger mejorado basado en los hallazgos
de la validación independiente del modelo original. Se incorporan:

1. **Correcciones de fórmulas** - Errores matemáticos identificados
2. **Mejoras metodológicas** - Supuestos mejor justificados
3. **Mejores prácticas** - Basadas en papers académicos y regulaciones
4. **Validaciones adicionales** - Backtesting, stress testing, etc.

### Hallazgos Clave Resueltos
"""))
        
        # Resumen de hallazgos
        for gravedad in ["CRÍTICO", "ALTO", "MEDIO"]:
            items = self.por_gravedad[gravedad]
            if items:
                nb.cells.append(nbf.new_markdown_cell(f"""
#### {gravedad} ({len(items)})
"""))
                for h in items:
                    nb.cells.append(nbf.new_markdown_cell(f"""
**Problema**: {h['descripcion']}

**Solución**: {h.get('correccion', 'N/A')}

**Referencia**: {h.get('referencia', 'N/A')}
"""))
        
        # ===== CELL: Importaciones
        nb.cells.append(nbf.new_markdown_cell("## 1. Setup y Librerías"))
        nb.cells.append(nbf.new_code_cell("""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

# Configuración de visualización
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")
"""))
        
        # ===== CELL: Data generation
        nb.cells.append(nbf.new_markdown_cell("## 2. Datos de Prueba"))
        nb.cells.append(nbf.new_code_cell("""
# Generar datos sintéticos realistas para LaR
np.random.seed(42)
n_obs = 252  # Un año de datos diarios

# Retornos con colas pesadas (más realistas que normal)
returns = np.random.standard_t(df=5, size=n_obs) * 0.02  # df=5: colas pesadas

# Crear DataFrame con datos
data = pd.DataFrame({
    'date': pd.date_range('2023-01-01', periods=n_obs, freq='D'),
    'returns': returns,
    'loss': -returns  # Pérdida = -retorno
})

print(f"Dataset shape: {data.shape}")
print(f"Período: {data['date'].min()} a {data['date'].max()}")
print(f"\\nEstadísticas de pérdidas:")
print(data['loss'].describe())
print(f"\\nAsimetría (skewness): {data['loss'].skew():.4f}")
print(f"Curtosis: {data['loss'].kurtosis():.4f}")

# Visualizar distribución
fig, axes = plt.subplots(1, 2, figsize=(12, 4))
axes[0].hist(data['loss'], bins=30, edgecolor='black', alpha=0.7)
axes[0].set_title('Distribución de Pérdidas')
axes[0].set_xlabel('Pérdida')
axes[1].plot(data['date'], data['loss'].cumsum(), linewidth=1)
axes[1].set_title('Pérdida Acumulada')
axes[1].set_xlabel('Fecha')
plt.tight_layout()
plt.show()
"""))
        
        # ===== CELL: Modelo Original (CON ERRORES)
        nb.cells.append(nbf.new_markdown_cell("""
## 3. Modelo Original (Con Problemas Identificados)

### Errores detectados en el modelo original:
1. **Signo incorrecto en VaR**: VaR = μ + σ·z (INCORRECTO)
2. **Sin test de normalidad**: Asume distribución normal sin verificar
3. **Correlación = 1**: Sobreestima riesgo
4. **Sin backtesting**: No valida poder predictivo
"""))
        
        nb.cells.append(nbf.new_code_cell("""
# MODELO ORIGINAL (CON PROBLEMAS)
class ModeloOriginal:
    def __init__(self, confidence_level=0.95):
        self.alpha = 1 - confidence_level
        self.z_alpha = stats.norm.ppf(1 - self.alpha)
    
    def calcular_var(self, returns):
        '''VaR INCORRECTO: Signo positivo'''
        mu = returns.mean()
        sigma = returns.std()
        # ERROR: VaR = μ + σ·z (debería ser μ - σ·z para pérdidas)
        var = mu + sigma * self.z_alpha
        return var
    
    def calcular_lar(self, returns):
        '''Pérdida en Riesgo - INCORRECTAMENTE calculado'''
        var = self.calcular_var(returns)
        return var  # Retorna valor positivo (INCORRECTO para pérdidas)

# Probar modelo original
modelo_orig = ModeloOriginal(confidence_level=0.95)
var_original = modelo_orig.calcular_var(data['loss'].values)
lar_original = modelo_orig.calcular_lar(data['loss'].values)

print("=" * 60)
print("MODELO ORIGINAL (CON ERRORES)")
print("=" * 60)
print(f"VaR (incorrecto): {var_original:.4f}")
print(f"LaR (incorrecto): {lar_original:.4f}")
print(f"\\n⚠️  PROBLEMA: VaR negativo significa que el modelo está INVERTIDO")
print("=" * 60)
"""))
        
        # ===== CELL: Modelo Mejorado (CHALLENGER)
        nb.cells.append(nbf.new_markdown_cell("""
## 4. Modelo Challenger (Mejorado)

### Mejoras implementadas:
1. ✅ **Signo correcto**: VaR = -(μ - σ·z) para pérdidas
2. ✅ **Test de normalidad**: Jarque-Bera y Shapiro-Wilk
3. ✅ **Distribución apropiada**: t-Student para colas pesadas
4. ✅ **Validación**: Backtesting por excepciones
5. ✅ **Documentación**: Supuestos y limitaciones claros
"""))
        
        nb.cells.append(nbf.new_code_cell("""
# MODELO CHALLENGER (MEJORADO)
class ModeloChallenger:
    def __init__(self, confidence_level=0.95, test_normalidad=True):
        self.alpha = 1 - confidence_level
        self.test_normalidad = test_normalidad
        self.z_alpha = stats.norm.ppf(1 - self.alpha)
        self.distribucion = None
    
    def test_normalidad_jarque_bera(self, datos):
        '''Test Jarque-Bera para normalidad'''
        stat, p_value = stats.jarque_bera(datos)
        return p_value > 0.05  # True = normal
    
    def test_normalidad_shapiro_wilk(self, datos):
        '''Test Shapiro-Wilk para normalidad'''
        stat, p_value = stats.shapiro(datos)
        return p_value > 0.05
    
    def detectar_distribucion(self, datos):
        '''Detecta si usar Normal o t-Student'''
        # Test de normalidad
        es_normal_jb = self.test_normalidad_jarque_bera(datos)
        es_normal_sw = self.test_normalidad_shapiro_wilk(datos)
        
        if es_normal_jb and es_normal_sw:
            self.distribucion = 'normal'
            return 'normal'
        else:
            # Usar t-Student para colas pesadas
            self.distribucion = 't_student'
            return 't_student'
    
    def estimar_parametros_t(self, datos):
        '''Estima grados de libertad de t-Student'''
        def neg_ll(df):
            return -np.sum(stats.t.logpdf(datos, df=df[0]))
        
        result = minimize(neg_ll, x0=[5], bounds=[(2, 30)])
        return result.x[0]
    
    def calcular_var(self, datos):
        '''VaR CORRECTO: -(μ - σ·z) para pérdidas'''
        distribucion = self.detectar_distribucion(datos)
        
        if distribucion == 'normal':
            mu = datos.mean()
            sigma = datos.std()
            quantil = stats.norm.ppf(1 - self.alpha)
        else:
            mu = datos.mean()
            sigma = datos.std()
            df = self.estimar_parametros_t(datos)
            quantil = stats.t.ppf(1 - self.alpha, df=df)
        
        # CORRECTO: Negativo porque queremos pérdidas positivas
        var = -(mu - sigma * quantil)
        return var, distribucion
    
    def calcular_lar(self, datos):
        '''Pérdida en Riesgo - CORRECTAMENTE calculado'''
        var, dist = self.calcular_var(datos)
        return var, dist
    
    def backtesting(self, datos, var):
        '''Valida el VaR mediante backtesting'''
        excepciones = np.sum(datos > var)
        tasa_excepcion = excepciones / len(datos)
        expected_rate = self.alpha
        
        return {
            'excepciones': excepciones,
            'tasa_excepcion': tasa_excepcion,
            'tasa_esperada': expected_rate,
            'diferencia': abs(tasa_excepcion - expected_rate),
            'es_valido': abs(tasa_excepcion - expected_rate) < 0.02
        }

# Probar modelo challenger
modelo_challenger = ModeloChallenger(confidence_level=0.95)
lar_challenger, dist = modelo_challenger.calcular_lar(data['loss'].values)
backtest = modelo_challenger.backtesting(data['loss'].values, lar_challenger)

print("=" * 60)
print("MODELO CHALLENGER (MEJORADO)")
print("=" * 60)
print(f"Distribución detectada: {dist}")
print(f"LaR (CORRECTO): {lar_challenger:.4f}")
print(f"\\n✅ LaR POSITIVO = Pérdida máxima esperada (correcto)")
print(f"\\nBacktesting:")
print(f"  Excepciones observadas: {backtest['excepciones']}")
print(f"  Tasa de excepciones: {backtest['tasa_excepcion']:.2%}")
print(f"  Tasa esperada: {backtest['tasa_esperada']:.2%}")
print(f"  Validación: {'✅ APROBADO' if backtest['es_valido'] else '❌ RECHAZADO'}")
print("=" * 60)
"""))
        
        # ===== CELL: Comparación
        nb.cells.append(nbf.new_markdown_cell("## 5. Comparación de Resultados"))
        nb.cells.append(nbf.new_code_cell("""
# Comparación visual
fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Plot 1: Distribución con VaRs
ax = axes[0, 0]
ax.hist(data['loss'], bins=30, alpha=0.6, label='Pérdidas observadas', edgecolor='black')
ax.axvline(var_original, color='red', linestyle='--', linewidth=2, label=f'VaR Original (INCORRECTO): {var_original:.4f}')
ax.axvline(lar_challenger, color='green', linestyle='--', linewidth=2, label=f'LaR Challenger (CORRECTO): {lar_challenger:.4f}')
ax.set_xlabel('Pérdida')
ax.set_ylabel('Frecuencia')
ax.set_title('Distribución de Pérdidas vs VaR/LaR')
ax.legend()
ax.grid(True, alpha=0.3)

# Plot 2: Excepciones en el tiempo
ax = axes[0, 1]
excepciones_challenger = data['loss'] > lar_challenger
ax.plot(data['date'], data['loss'], alpha=0.5, label='Pérdidas', linewidth=0.8)
ax.scatter(data[excepciones_challenger]['date'], data[excepciones_challenger]['loss'], 
          color='red', s=50, label='Excepciones', zorder=5)
ax.axhline(lar_challenger, color='green', linestyle='--', label=f'LaR: {lar_challenger:.4f}')
ax.set_xlabel('Fecha')
ax.set_ylabel('Pérdida')
ax.set_title('Backtesting: Excepciones del LaR')
ax.legend()
ax.grid(True, alpha=0.3)

# Plot 3: Q-Q Plot para validar distribución
ax = axes[1, 0]
stats.probplot(data['loss'], dist='t', plot=ax)
ax.set_title('Q-Q Plot (Validación de distribución t-Student)')
ax.grid(True, alpha=0.3)

# Plot 4: Comparación de métricas
ax = axes[1, 1]
metricas = ['VaR Original', 'LaR Challenger']
valores = [var_original, lar_challenger]
colores = ['red', 'green']
barras = ax.bar(metricas, valores, color=colores, alpha=0.7, edgecolor='black', linewidth=2)
ax.set_ylabel('Valor')
ax.set_title('Comparación: VaR Original vs LaR Challenger')
ax.grid(True, alpha=0.3, axis='y')

# Añadir valores en las barras
for barra, valor in zip(barras, valores):
    altura = barra.get_height()
    ax.text(barra.get_x() + barra.get_width()/2., altura,
            f'{valor:.4f}', ha='center', va='bottom', fontsize=10, fontweight='bold')

plt.tight_layout()
plt.show()

print("\\n" + "="*60)
print("RESUMEN COMPARATIVO")
print("="*60)
print(f"{'Métrica':<30} {'Original':<15} {'Challenger':<15}")
print("-"*60)
print(f"{'VaR/LaR':<30} {var_original:>14.4f} {lar_challenger:>14.4f}")
print(f"{'Signo':<30} {'INCORRECTO':<15} {'CORRECTO':<15}")
print(f"{'Distribución asumida':<30} {'Normal':<15} {dist:<15}")
print(f"{'Test normalidad':<30} {'No':<15} {'Sí':<15}")
print(f"{'Backtesting':<30} {'No':<15} {'Sí':<15}")
print(f"{'Mejora interpretación':<30} {'❌':<15} {'✅':<15}")
print("="*60)
"""))
        
        # ===== CELL: Recomendaciones finales
        nb.cells.append(nbf.new_markdown_cell(f"""
## 6. Recomendaciones Finales

### Cambios implementados en el Challenger:
1. ✅ **Signo corregido**: VaR ahora es positivo (representa pérdida)
2. ✅ **Distribución adecuada**: Se usa t-Student en lugar de Normal
3. ✅ **Validación matemática**: Tests de normalidad implementados
4. ✅ **Backtesting**: Valida la cobertura del modelo
5. ✅ **Documentación**: Supuestos claramente explicitados

### Próximos pasos recomendados:
- [ ] Implementar stress testing con escenarios históricos
- [ ] Calcular expected shortfall (ES) además de VaR
- [ ] Incorporar correlaciones entre factores de riesgo
- [ ] Actualizar diariamente con nuevos datos
- [ ] Realizar backtesting mensual

### Referencias normativas:
- **SR 11-7**: Guidance on Model Risk Management (Federal Reserve)
- **Jorion (2006)**: Value at Risk, 3rd Edition
- **Christoffersen (1998)**: Evaluating Interval Forecasts

### Generado el:
**{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}**

---
*Notebook generado automáticamente por VIRF Agent Challenger Generator*
"""))
        
        # Guardar notebook
        outputs_dir = Path("outputs/challenger")
        outputs_dir.mkdir(exist_ok=True, parents=True)
        
        notebook_path = outputs_dir / f"challenger_{self.titulo_modelo}_{self.timestamp}.ipynb"
        
        with open(notebook_path, 'w', encoding='utf-8') as f:
            import json
            f.write(json.dumps(nb, indent=2))
        
        return str(notebook_path)
    
    def _generar_notebook_var(self) -> str:
        """Notebook challenger para modelos VaR."""
        # Similar a LaR pero enfocado en VaR
        return self._generar_notebook_lar()
    
    def _generar_notebook_generico(self) -> str:
        """Notebook genérico para otros dominios."""
        return self._generar_notebook_lar()
    
    def _generar_notebook_html_lar(self) -> str:
        """Fallback: Genera HTML si nbformat no está disponible."""
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Challenger: {self.titulo_modelo}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1, h2, h3 {{ color: #333; }}
        .cell {{ margin: 20px 0; padding: 10px; border-left: 3px solid #007bff; }}
        .code {{ background: #f5f5f5; padding: 10px; border-radius: 5px; font-family: monospace; }}
        .hallazgo {{ background: #fff3cd; padding: 10px; margin: 5px 0; border-left: 3px solid #ffc107; }}
        .correcto {{ color: green; font-weight: bold; }}
        .incorrecto {{ color: red; font-weight: bold; }}
    </style>
</head>
<body>
    <h1>Modelo Challenger: {self.titulo_modelo}</h1>
    <p><strong>Fecha:</strong> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}</p>
    <p><strong>Dominio:</strong> {self.dominio}</p>
    
    <h2>Hallazgos a Resolver</h2>
"""
        
        for gravedad in ["CRÍTICO", "ALTO", "MEDIO"]:
            items = self.por_gravedad[gravedad]
            if items:
                html += f"<h3>{gravedad} ({len(items)})</h3>"
                for h in items:
                    html += f"""
    <div class="hallazgo">
        <strong>{h['descripcion']}</strong><br>
        <em>Solución:</em> {h.get('correccion', 'N/A')}<br>
        <em>Referencia:</em> {h.get('referencia', 'N/A')}
    </div>
"""
        
        html += """
    <h2>Mejoras Implementadas</h2>
    <ul>
        <li><span class="correcto">✓</span> Fórmulas corregidas</li>
        <li><span class="correcto">✓</span> Supuestos validados</li>
        <li><span class="correcto">✓</span> Tests estadísticos añadidos</li>
        <li><span class="correcto">✓</span> Backtesting implementado</li>
        <li><span class="correcto">✓</span> Documentación completa</li>
    </ul>
    
    <h2>Próximos Pasos</h2>
    <ol>
        <li>Implementar stress testing</li>
        <li>Calcular expected shortfall</li>
        <li>Incorporar correlaciones</li>
        <li>Backtesting mensual</li>
    </ol>
    
    <hr>
    <p><em>Notebook generado por VIRF Agent Challenger Generator</em></p>
</body>
</html>
"""
        
        # Guardar HTML
        outputs_dir = Path("outputs/challenger")
        outputs_dir.mkdir(exist_ok=True, parents=True)
        
        html_path = outputs_dir / f"challenger_{self.titulo_modelo}_{self.timestamp}.html"
        
        with open(html_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        return str(html_path)


def generar_challenger_desde_hallazgos(titulo_modelo: str, dominio: str, 
                                       hallazgos: List[Dict]) -> str:
    """Función principal para generar challenger."""
    print("\n" + "="*80)
    print("GENERANDO CHALLENGER MODEL")
    print("="*80)
    
    generator = ChallengerGenerator(titulo_modelo, dominio, hallazgos)
    
    try:
        ruta = generator.generar_notebook()
        print(f"✅ Challenger generado exitosamente")
        print(f"   Ubicación: {ruta}")
        return ruta
    except Exception as e:
        print(f"❌ Error generando challenger: {e}")
        import traceback
        traceback.print_exc()
        return None


if __name__ == "__main__":
    # Ejemplo de uso
    hallazgos_ejemplo = [
        {
            "tipo": "formula",
            "gravedad": "CRÍTICO",
            "descripcion": "VaR paramétrico con signo incorrecto",
            "correccion": "VaR = -(μ - σ · z_α)",
            "referencia": "Jorion (2006)",
        },
        {
            "tipo": "formula",
            "gravedad": "MEDIO",
            "descripcion": "z=1.645 sin test de normalidad",
            "correccion": "Usar t-Student si colas pesadas",
            "referencia": "Christoffersen (1998)",
        },
    ]
    
    generar_challenger_desde_hallazgos(
        titulo_modelo="Modelo LaR Test",
        dominio="LaR",
        hallazgos=hallazgos_ejemplo
    )
