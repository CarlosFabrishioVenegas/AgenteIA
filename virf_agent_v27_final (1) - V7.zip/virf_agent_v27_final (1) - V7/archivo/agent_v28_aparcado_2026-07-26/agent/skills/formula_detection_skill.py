"""
agent/skills/formula_detection_skill.py
=========================================
Skill LLM para análisis profundo de fórmulas financieras.
Complementa al FormulaDetector (estático) con razonamiento del LLM.

Extrae hallazgos estructurados en JSON de la respuesta del modelo.
"""

from __future__ import annotations
import json
import re
from typing import Dict, List, Any

import anthropic


PROMPT_FORMULA = """Analiza la siguiente fórmula o cálculo financiero y extrae los hallazgos en JSON.

FÓRMULA/CÁLCULO:
{texto}

CONTEXTO ADICIONAL (documentos del modelo):
{docs_contexto}

DOMINIO: {dominio}

Responde SOLO con JSON válido (sin markdown, sin texto adicional):
{{
  "es_correcto": true/false,
  "confianza": "alta"/"media"/"baja",
  "hallazgos": [
    {{
      "tipo": "formula",
      "gravedad": "CRÍTICO"/"ALTO"/"MEDIO"/"BAJO",
      "descripcion": "descripción técnica precisa del error",
      "formula_incorrecta": "la parte exacta que está mal",
      "formula_correcta": "cómo debería ser",
      "referencia": "autor/año/norma que justifica la corrección"
    }}
  ],
  "comentario_general": "evaluación global en 1-2 oraciones"
}}

Si no hay errores, retorna hallazgos: [] y es_correcto: true.
IMPORTANTE: Solo reporta errores de los que estés seguro. Si dudas, indica gravedad BAJO con "requiere verificación adicional"."""


class FormulaDetectionSkill:
    """Skill de detección de errores en fórmulas con LLM."""

    def __init__(self, client: anthropic.Anthropic, modelo: str):
        self.client = client
        self.modelo = modelo

    def ejecutar(self, texto: str, dominio: str = "shared",
                 docs_contexto: str = "") -> Dict[str, Any]:
        """
        Analiza una fórmula con el LLM y extrae hallazgos estructurados.

        Returns:
            {
                "es_correcto": bool,
                "confianza": str,
                "hallazgos": List[Dict],
                "comentario_general": str
            }
        """
        prompt = PROMPT_FORMULA.format(
            texto         = texto[:3000],
            docs_contexto = docs_contexto[:1000] if docs_contexto else "(sin documentos cargados)",
            dominio       = dominio,
        )

        try:
            resp = self.client.messages.create(
                model      = self.modelo,
                max_tokens = 1000,
                messages   = [{"role": "user", "content": prompt}],
            )
            raw = resp.content[0].text.strip()
            # Limpiar markdown si el modelo lo añade
            raw = re.sub(r"```json|```", "", raw).strip()
            result = json.loads(raw)
            return result
        except (json.JSONDecodeError, Exception):
            # Fallback: retornar vacío sin romper el flujo
            return {"es_correcto": None, "confianza": "baja", "hallazgos": [],
                    "comentario_general": "Análisis estructurado no disponible."}
