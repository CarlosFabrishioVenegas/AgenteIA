"""
====================================================================
ARCHIVO: skills/model_governance_skill.py  — virf_agent_v28
====================================================================

SKILL: Model Governance
DOMINIO: Model Risk Management / Enterprise Governance
ROL SIMULADO: MRM Specialist + Head of Model Validation

OBJETIVO:
    Evaluar y gestionar el gobierno de modelos:
    - Estado del inventario de modelos
    - Ciclo de vida: desarrollo → validación → aprobación → producción → retiro
    - Controles de cambio (change management)
    - Trazabilidad y auditabilidad
    - Roles y responsabilidades (Model Owner, Developer, Validator)
    - Materialidad del modelo
    - Planes de contingencia

====================================================================
"""

from typing import Dict, Any
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

SYSTEM_PROMPT_GOVERNANCE = """
Eres un MRM Specialist y Head of Model Validation especializado
en gobierno de modelos financieros para banca.

Tu función: evaluar el estado de gobierno de un modelo o conjunto
de modelos, identificar brechas en el ciclo de vida y proponer controles.

Para el modelo bajo revisión, evalúa:

## 1. INVENTARIO
- ¿Está registrado en el inventario de modelos?
- ¿La ficha del modelo está actualizada?
- ¿La materialidad está clasificada correctamente? (ALTA / MEDIA / BAJA)

## 2. CICLO DE VIDA
Estado actual en:
[ ] Desarrollo → [ ] Validación interna → [ ] Aprobación comité →
[ ] Implementación UAT → [ ] Producción → [ ] Monitoreo continuo → [ ] Retiro

¿Hay evidencia de cada etapa completada?
¿Hay etapas saltadas o sin documentar?

## 3. ROLES Y RESPONSABILIDADES
- Model Owner: ¿designado? ¿activo?
- Developer: ¿documentado?
- Validator: ¿independiente del desarrollador?
- Comité de Modelos: ¿aprobó formalmente?

## 4. CONTROLES DE CAMBIO
- ¿Hay un proceso formal para cambios al modelo?
- ¿Los cambios menores requieren re-validación?
- ¿Los cambios materiales pasan por comité?

## 5. MONITOREO CONTINUO
- ¿Hay un plan de monitoreo activo?
- ¿Se están respetando las frecuencias de reporte?
- ¿Se han activado alertas en los últimos períodos?
- ¿Hay un modelo de respaldo definido?

## 6. TRAZABILIDAD
- ¿Puede rastrearse cada decisión del modelo hasta su dato fuente?
- ¿Hay control de versiones del código?
- ¿Los cambios de parámetros están registrados?

## 7. EVALUACIÓN GLOBAL
Score de gobierno: X/10
Estado: GOBERNADO / PARCIALMENTE GOBERNADO / SIN GOBIERNO ADECUADO
Riesgo de gobierno: ALTO / MEDIO / BAJO
Acciones inmediatas requeridas: [lista]

Un modelo sin gobierno adecuado es un pasivo regulatorio y operacional
independientemente de su desempeño técnico.
"""


class ModelGovernanceSkill(BaseSkill):
    """
    Skill de gobierno de modelos para MRM.
    
    Evalúa inventario, ciclo de vida, roles, controles de cambio
    y monitoreo continuo de modelos bancarios.
    """

    def __init__(self):
        super().__init__(
            name="model_governance",
            description=(
                "Gobierno de modelos: evalúa inventario, ciclo de vida, "
                "roles, controles de cambio, trazabilidad y monitoreo "
                "continuo. Produce assessment de madurez de gobierno MRM."
            ),
        )

    async def validate_input(self, query: str) -> bool:
        keywords = [
            "gobierno", "governance", "inventario", "ciclo de vida", "lifecycle",
            "owner", "aprobación", "comité", "control", "cambio", "monitoreo",
            "trazabilidad", "materialidad", "mrm", "modelo.*riesgo",
        ]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)
            artifacts = self._extract_artifacts(tools)

            user_prompt = f"""{history}{rag_context}

INFORMACIÓN DEL MODELO / PROYECTO:
{artifacts}

CONSULTA DE GOBIERNO:
{query}

Evalúa el estado de gobierno del modelo siguiendo las 7 dimensiones
del sistema prompt. Si falta información para evaluar una dimensión,
marca como DESCONOCIDO y señálalo como brecha de gobierno.
"""
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=3072,
                system=SYSTEM_PROMPT_GOVERNANCE,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw = response.content[0].text
            result = {
                "governance_assessment": raw,
                "dimensions_evaluated": 7,
            }

        except Exception as e:
            error = str(e)
            logger.error(f"[ModelGovernanceSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.88 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }

    def _extract_artifacts(self, tools: Dict[str, Any]) -> str:
        parts = []
        for key in ["document", "model_info", "code", "dataframe_info"]:
            val = tools.get(key)
            if val:
                parts.append(f"[{key.upper()}]:\n{str(val)[:2000]}")
        return "\n\n".join(parts) if parts else "Sin artefactos. Analiza basándote en la consulta."
