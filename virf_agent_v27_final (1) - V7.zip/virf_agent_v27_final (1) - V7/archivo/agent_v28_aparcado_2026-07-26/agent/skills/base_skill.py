"""
====================================================================
ARCHIVO: skills/base_skill.py
====================================================================

OBJETIVO:
    Definir la interfaz base (clase abstracta) que deben implementar
    todos los skills del agente. Establece el contrato de la capa
    de skills del sistema.

PARA QUÉ SIRVE:
    Garantiza que todos los skills (SalesAnalysisSkill, ConversionPredictionSkill,
    etc.) implementen los mismos métodos y puedan ser tratados de forma
    uniforme por el AgentOrchestrator. Sin esta clase base, el
    orquestador no podría llamar a execute() de forma genérica.

POR QUÉ ES NECESARIO:
    Es el contrato de la arquitectura de skills. AgentOrchestrator
    llama skill.execute(query, context, tools) sin saber qué skill
    específica es. Esto solo funciona si todas implementan BaseSkill.

QUÉ PASA SI SE ELIMINA:
    - Todos los skills dejan de tener una interfaz común.
    - AgentOrchestrator no puede ejecutar skills genéricamente.
    - El patrón de herencia de skills se rompe completamente.

LÓGICA DE NEGOCIO:
    Contrato obligatorio:
    - execute(query, context, tools) → Dict : lógica principal del skill
    - validate_input(query) → bool          : validación previa

    Hooks opcionales (pueden sobrescribirse):
    - pre_execute()  : acciones antes de ejecutar (incrementa contador)
    - post_execute() : acciones después de ejecutar

    Métricas integradas:
    - execution_count: cuántas veces se ejecutó el skill
    - total_time     : tiempo total acumulado de ejecución

DEPENDENCIAS CRÍTICAS:
    - abc.ABC, abstractmethod (stdlib)

RIESGOS:
    - Si se agrega un método abstracto nuevo, TODOS los skills
      existentes deben implementarlo o causarán TypeError.

ESCALABILIDAD:
    - Patrón extensible: agregar un nuevo skill = crear una clase
      que herede de BaseSkill e implementar execute().

IMPACTO DE NEGOCIO:
    ALTO. Es la piedra angular de la arquitectura de skills.

NIVEL DE CRITICIDAD:
    ALTO

====================================================================
"""

from abc import ABC, abstractmethod
from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)


class BaseSkill(ABC):

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.execution_count = 0
        self.total_time = 0.0

    @abstractmethod
    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        pass

    @abstractmethod
    async def validate_input(self, query: str) -> bool:
        pass

    async def pre_execute(self):
        self.execution_count += 1

    async def post_execute(self):
        pass

    def get_metrics(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "execution_count": self.execution_count,
            "average_time": self.total_time / self.execution_count if self.execution_count > 0 else 0,
        }

    def get_conversation_history(self, tools: Dict[str, Any], max_turns: int = 3) -> str: #cuanto más turnos, más contexto pero también más ruido. Ajustar según necesidad.
        """
        Recupera el historial reciente de la conversación desde la memoria.
        Disponible para todas las skills automáticamente.

        Args:
            tools: Dict de tools del orquestador (debe incluir 'memory')
            max_turns: Número máximo de interacciones a incluir

        Returns:
            String con el historial formateado para incluir en el prompt,
            o string vacío si no hay historial.
        """
        memory = tools.get("memory")
        if not memory:
            return ""

        try:
            recent_items = memory.get_recent(max_turns * 2)
            sales_responses = [
                item for item in recent_items
                if item.get("category") == "sales_response"
            ][-max_turns:]

            if not sales_responses:
                return ""

            history_lines = []
            for item in sales_responses:
                val = item.get("value", {})
                if isinstance(val, dict):
                    q = val.get("query", "")
                    r = val.get("response", "")[:400]
                    history_lines.append(f"Usuario: {q}\nAgente: {r}...")

            return "Historial reciente:\n" + "\n---\n".join(history_lines) + "\n\n"

        except Exception as e:
            logger.debug(f"No se pudo recuperar historial: {e}")
            return ""
        
    def get_rag_context(self, context: Dict[str, Any], max_docs: int = 3) -> str:
        """
        Recupera documentos relevantes del RAG desde el contexto del workflow.
        Disponible para todas las skills automáticamente.

        Args:
            context: Contexto del workflow (contiene retrieved_documents)
            max_docs: Número máximo de documentos a incluir

        Returns:
            String con evidencia académica formateada para incluir en el prompt,
            o string vacío si no hay documentos recuperados.
        """
        try:
            docs = getattr(context, 'retrieved_documents', [])
            if not docs:
                return ""

            rag_lines = []
            for doc in docs[:max_docs]:
                if isinstance(doc, dict):
                    text   = doc.get("text", doc.get("content", ""))[:300]
                    source = doc.get("source", doc.get("metadata", {}).get("source", "paper"))
                    if text:
                        rag_lines.append(f"[{source}]: {text}...")

            if not rag_lines:
                return ""

            return "Evidencia académica relevante:\n" + "\n".join(rag_lines) + "\n\n"

        except Exception as e:
            logger.debug(f"No se pudo recuperar contexto RAG: {e}")
            return ""
