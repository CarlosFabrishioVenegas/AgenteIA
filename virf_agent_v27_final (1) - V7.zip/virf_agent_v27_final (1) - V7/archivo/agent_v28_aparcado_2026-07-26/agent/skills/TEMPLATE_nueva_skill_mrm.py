"""
====================================================================
ARCHIVO: skills/TEMPLATE_nueva_skill_mrm.py  — virf_agent_v28
====================================================================

INSTRUCCIONES DE USO:
    1. Copia este archivo:
       cp TEMPLATE_nueva_skill_mrm.py mi_nueva_skill.py

    2. Reemplaza:
       - NOMBRE_SKILL → nombre descriptivo (ej: BacktestingSkill)
       - nombre_skill → snake_case (ej: backtesting)
       - TASK_TYPE → añade en task_router.py el TaskType correspondiente
       - keywords → palabras clave para validate_input()
       - SYSTEM_PROMPT → prompt del equipo especialista
       - lógica de execute() → tu implementación específica

    3. Registra en virf_agent_v28.py:
       orchestrator.register_skill(TaskType.NUEVA, NuevaMRMSkill())

    4. Añade el TaskType en task_router.py:
       TaskType.NUEVA = "nueva"
       Con sus 3 patrones regex correspondientes.

====================================================================
"""

from typing import Dict, Any
import logging
import time
import anthropic
from .base_skill import BaseSkill

logger = logging.getLogger(__name__)

SYSTEM_PROMPT_NUEVA = """
Eres un [ROL DEL EQUIPO ESPECIALISTA].
Tu función: [OBJETIVO PRINCIPAL].

Siempre:
1. [INSTRUCCIÓN 1]
2. [INSTRUCCIÓN 2]
3. [INSTRUCCIÓN 3]

Nunca asumas que [SUPUESTO CRÍTICO].
"""


class NOMBRE_SKILLSkill(BaseSkill):
    """
    Skill especializado en [DOMINIO MRM].
    
    Responsabilidades:
    - [Responsabilidad 1]
    - [Responsabilidad 2]
    """

    def __init__(self):
        super().__init__(
            name="nombre_skill",           # ← CAMBIAR: snake_case único
            description="Descripción MRM de qué hace esta skill",  # ← CAMBIAR
        )

    async def validate_input(self, query: str) -> bool:
        # ← CAMBIAR: palabras clave relevantes al dominio MRM
        keywords = ["keyword1", "keyword2", "keyword3"]
        return any(kw in query.lower() for kw in keywords)

    async def execute(
        self,
        query: str,
        context: Dict[str, Any],
        tools: Dict[str, Any],
    ) -> Dict[str, Any]:
        await self.pre_execute()
        start = time.time()
        error = None
        result = None

        try:
            # Contexto disponible automáticamente (heredado de BaseSkill)
            rag_context = self.get_rag_context(context)
            history = self.get_conversation_history(tools)

            # ← CAMBIAR: construir tu prompt específico
            user_prompt = f"""{history}{rag_context}

[INFORMACIÓN RELEVANTE DEL CONTEXTO]

CONSULTA:
{query}

[INSTRUCCIÓN ESPECÍFICA PARA ESTA SKILL]
"""
            # Llamada al LLM
            client = anthropic.Anthropic()
            response = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=3072,
                system=SYSTEM_PROMPT_NUEVA,
                messages=[{"role": "user", "content": user_prompt}],
            )

            raw = response.content[0].text

            # ← CAMBIAR: estructurar el resultado según el output esperado
            result = {
                "analysis": raw,
                # "structured_field": parsed_value,
            }

        except Exception as e:
            error = str(e)
            logger.error(f"[NOMBRE_SKILLSkill] Error: {e}")
        finally:
            await self.post_execute()
            elapsed = time.time() - start
            self.total_time += elapsed

        return {
            "result": result,
            "confidence": 0.85 if not error else 0.0,
            "type": self.name,
            "error": error,
            "data": {"elapsed_ms": round(elapsed * 1000, 2)},
        }
