"""
====================================================================
ARCHIVO: orchestrator/workflow_manager.py
====================================================================

OBJETIVO:
    Gestionar el estado y ciclo de vida de cada workflow procesado
    por el AgentOrchestrator. Rastrea los estados de transición,
    métricas de tiempo y el contexto de cada query.

PARA QUÉ SIRVE:
    Permite que el orquestador tenga visibilidad completa del estado
    de cada query en proceso: en qué fase está (ROUTING, EXECUTING,
    COMPLETED, FAILED), cuánto tiempo lleva, qué documentos RAG
    recuperó, y qué resultados generaron las tools.

    Mantiene el estado de cada ejecución del agente. Cada llamada a
    AgentOrchestrator.process_query() genera un workflow con UUID único
    que pasa por 8 estados posibles:
    INITIALIZED -> ROUTING -> RETRIEVING_CONTEXT -> REASONING
    -> EXECUTING_SKILL -> EVALUATING -> COMPLETED | FAILED

    Contiene 4 estructuras:
    WorkflowState   (Enum)     -> 8 estados del ciclo de vida
    WorkflowMetrics (dataclass)-> start/end time, tokens, tools llamadas
    WorkflowContext (dataclass)-> query, task_type, docs RAG, tool_results
    WorkflowManager            -> crea, actualiza y exporta workflows

    export_workflow_trace() permite debuggear ejecuciones fallidas:
    retorna qué tools se usaron, cuántos docs RAG se recuperaron,
    cuánto tardó cada etapa y el estado final.


POR QUÉ ES NECESARIO:
    Sin WorkflowManager, el orquestador no puede:
    - Crear contextos compartidos entre pasos del pipeline.
    - Rastrear estados del workflow para debugging.
    - Exportar traces completos para auditoría.
    - Medir tiempos de cada fase del pipeline.

QUÉ PASA SI SE ELIMINA:
    - AgentOrchestrator.process_query() falla completamente.
    - No hay forma de rastrear el estado de workflows en proceso.
    - Los traces de auditoría dejan de estar disponibles.

LÓGICA DE NEGOCIO:
    Estados del workflow (WorkflowState enum):
    INITIALIZED → ROUTING → RETRIEVING_CONTEXT → REASONING
    → EXECUTING_SKILL → EVALUATING → COMPLETED
    (o FAILED en cualquier punto si hay error)

    WorkflowContext: contexto compartido entre todos los pasos.
    Contiene documentos RAG, resultados de tools, metadata y el trace.

    WorkflowMetrics: métricas de rendimiento (tiempos, tokens, tools).

FLUJO DE DATOS:
    create_workflow(id, query, task_type) → WorkflowContext
    update_state(id, state)              → transición de estado
    add_retrieved_doc(id, doc)           → añade doc al contexto
    add_tool_result(id, name, result)    → añade resultado de tool
    finalize_workflow(id)                → marca como completado
    export_workflow_trace(id)            → Dict serializable completo

NIVEL DE CRITICIDAD:
    ALTO (dependencia directa del AgentOrchestrator)

====================================================================
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, List
import datetime
import json


class WorkflowState(Enum):
    """
    Estados del ciclo de vida de un workflow.

    Flujo normal:   INITIALIZED → ROUTING → RETRIEVING_CONTEXT → EXECUTING_SKILL → EVALUATING → COMPLETED
    Flujo de error: cualquier estado → FAILED
    """
    INITIALIZED = "initialized"
    ROUTING = "routing"
    RETRIEVING_CONTEXT = "retrieving_context"
    REASONING = "reasoning"
    EXECUTING_SKILL = "executing_skill"
    EVALUATING = "evaluating"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class WorkflowMetrics:
    """
    Métricas de rendimiento por workflow.

    total_duration: segundos entre start_time y end_time. None si aún en curso.
    state_times: conteo de cuántas veces se actualizó cada estado (no duración real).
                 TODO (v2): medir duración real con time.perf_counter() por estado.
    tokens_used: tokens consumidos por componente (LLM, embeddings). Actualmente no se rellena.
    tools_called: lista de herramientas llamadas durante el workflow.
    """
    start_time: datetime.datetime
    end_time: datetime.datetime = None
    state_times: Dict[WorkflowState, float] = field(default_factory=dict)
    tokens_used: Dict[str, int] = field(default_factory=dict)
    tools_called: List[str] = field(default_factory=list)

    @property
    def total_duration(self) -> float:
        """Duración total en segundos"""
        if self.end_time is None:
            return None
        return (self.end_time - self.start_time).total_seconds()


@dataclass
class WorkflowContext:
    """
    Contenedor de datos compartidos durante un workflow.

    Se crea en create_workflow() y se pasa a skill.execute() como argumento.
    La skill puede leer retrieved_documents (docs RAG) y tool_results (resultados previos)
    para enriquecer su respuesta sin hacer llamadas duplicadas.

    Fields:
        query:                Query original del usuario.
        task_type:            TaskType detectado por TaskRouter (string).
        retrieved_documents:  Documentos recuperados por el sistema RAG.
        reasoning_trace:      Pasos de razonamiento del ReasoningEngine.
        tool_results:         Resultados de cada tool llamada (key=tool_name).
        metadata:             Información adicional libre (timestamps, flags, etc.).
    """
    query: str
    task_type: str
    retrieved_documents: List[Dict[str, Any]] = field(default_factory=list)
    reasoning_trace: Dict[str, Any] = field(default_factory=dict)
    tool_results: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)


class WorkflowManager:
    """
    Gestiona el ciclo de vida completo de los workflows del agente.

    Mantiene en memoria dos dicts:
        workflows: {workflow_id → WorkflowContext}  → datos del workflow
        metrics:   {workflow_id → WorkflowMetrics}  → métricas de rendimiento

    NOTA: los workflows se acumulan en memoria indefinidamente mientras
    el agente esté corriendo. Para sesiones muy largas (miles de queries),
    considerar limpiar workflows completados con antigüedad > N minutos.
    """

    def __init__(self, max_retries: int = 3):
        self.max_retries = max_retries
        self.workflows: Dict[str, WorkflowContext] = {}
        self.metrics: Dict[str, WorkflowMetrics] = {}

    def create_workflow(self, workflow_id: str, query: str, task_type: str) -> WorkflowContext:
        """
        Crea y registra un nuevo workflow.

        Args:
            workflow_id: UUID único generado por AgentOrchestrator.
            query:       Query original del usuario.
            task_type:   Nombre del TaskType detectado (string, no Enum).

        Returns:
            WorkflowContext vacío listo para que la skill lo rellene.
        """
        context = WorkflowContext(
            query=query,
            task_type=task_type,
        )
        self.workflows[workflow_id] = context
        self.metrics[workflow_id] = WorkflowMetrics(
            start_time=datetime.datetime.now()
        )
        return context

    def get_workflow(self, workflow_id: str) -> WorkflowContext:
        """Obtiene un flujo de trabajo existente"""
        return self.workflows.get(workflow_id)

    def update_state(self, workflow_id: str, new_state: WorkflowState):
        """Actualiza el estado de un flujo de trabajo"""
        if workflow_id in self.metrics:
            metrics = self.metrics[workflow_id]
            if new_state not in metrics.state_times:
                metrics.state_times[new_state] = 0
            # Rastrear tiempo en cada estado
            metrics.state_times[new_state] += 1

    def add_tool_result(self, workflow_id: str, tool_name: str, result: Any):
        """Agrega resultado de ejecución de herramienta"""
        if workflow_id in self.workflows:
            self.workflows[workflow_id].tool_results[tool_name] = result

    def add_retrieved_doc(self, workflow_id: str, doc: Dict[str, Any]):
        """Agrega documento recuperado por RAG"""
        if workflow_id in self.workflows:
            self.workflows[workflow_id].retrieved_documents.append(doc)

    def finalize_workflow(self, workflow_id: str):
        """Finaliza un flujo de trabajo"""
        if workflow_id in self.metrics:
            self.metrics[workflow_id].end_time = datetime.datetime.now()

    def get_metrics(self, workflow_id: str) -> WorkflowMetrics:
        """Obtiene métricas de un flujo de trabajo"""
        return self.metrics.get(workflow_id)

    def export_workflow_trace(self, workflow_id: str) -> Dict[str, Any]:
        """
        Exporta el trace completo de un workflow para debugging.

        Retorna un dict serializable a JSON con:
          - workflow_id, query, task_type
          - retrieved_docs_count: cuántos docs RAG se recuperaron
          - tools_used: lista de tools que generaron resultados
          - metrics.duration: segundos totales de ejecución
          - metrics.state_times: cuántas veces se actualizó cada estado

        Llamado por AgentOrchestrator.get_workflow_trace(workflow_id).
        """
        if workflow_id not in self.workflows:
            return {}

        context = self.workflows[workflow_id]
        metrics = self.metrics.get(workflow_id)

        return {
            "workflow_id": workflow_id,
            "query": context.query,
            "task_type": context.task_type,
            "retrieved_docs_count": len(context.retrieved_documents),
            "tools_used": list(context.tool_results.keys()),
            "metrics": {
                "duration": metrics.total_duration if metrics else None,
                "state_times": {s.value: t for s, t in (metrics.state_times.items() if metrics else [])},
            },
        }

