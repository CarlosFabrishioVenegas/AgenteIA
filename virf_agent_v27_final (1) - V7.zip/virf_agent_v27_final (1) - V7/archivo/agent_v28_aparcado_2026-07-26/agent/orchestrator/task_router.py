"""
====================================================================
ARCHIVO: orchestrator/task_router.py  — virf_agent_v28
====================================================================

OBJETIVO:
    Enrutador de tareas de Model Risk Management (MRM) y auditoría
    cuantitativa. Mapea queries a TaskType usando scoring regex,
    idéntico al mecanismo de v27 pero con dominio completamente
    nuevo: validación, auditoría y gobierno de modelos bancarios.

TASK TYPES v28:
    FAILURE_ANALYSIS      — análisis de fallas y riesgos del modelo
    METHODOLOGY_COMPLIANCE — cumplimiento contra manuales / normativas
    CHALLENGER_GENERATION  — diseño y generación de modelos challenger
    PAPER_INTELLIGENCE     — lectura profunda de papers académicos
    REPO_RECONSTRUCTION    — reverse engineering de repositorios
    REGULATORY_REVIEW      — revisión regulatoria (Basilea, SBS, etc.)
    DOCUMENTATION_AUDIT    — auditoría de documentación técnica
    MODEL_GOVERNANCE       — gobierno, controles y trazabilidad
    UNKNOWN               — consulta general / sin clasificar

====================================================================
"""

import re
from enum import Enum
from typing import Dict, List, Tuple


class TaskType(Enum):
    FAILURE_ANALYSIS       = "failure_analysis"
    METHODOLOGY_COMPLIANCE = "methodology_compliance"
    CHALLENGER_GENERATION  = "challenger_generation"
    PAPER_INTELLIGENCE     = "paper_intelligence"
    REPO_RECONSTRUCTION    = "repo_reconstruction"
    REGULATORY_REVIEW      = "regulatory_review"
    DOCUMENTATION_AUDIT    = "documentation_audit"
    MODEL_GOVERNANCE       = "model_governance"
    UNKNOWN                = "unknown"


class TaskRouter:

    def __init__(self):
        self.task_patterns: Dict[TaskType, List[str]] = {

            TaskType.FAILURE_ANALYSIS: [
                r"(falla|error|riesgo|debilidad|vulnerabilidad|problema|defecto|brecha)",
                r"(análisis.*falla|failure.*analysis|punto.*crítico|hallazgo|evidencia)",
                r"(severidad|impacto|operativo|metodológico|estadístico|conceptual)",
            ],

            TaskType.METHODOLOGY_COMPLIANCE: [
                r"(cumplimiento|compliance|metodolog|manual|normativa|procedimiento|política)",
                r"(faltante|incompleto|ausente|pendiente|requerido|obligatorio|control)",
                r"(validar.*proceso|proceso.*validación|checklist|entregable|evidencia.*suficiente)",
            ],

            TaskType.CHALLENGER_GENERATION: [
                r"(challenger|alternativ|contraejemplo|hipótesis.*alternativa|modelo.*challenger)",
                r"(generar.*script|código.*validación|prueba.*adicional|test.*estadístico)",
                r"(cuestionar|debatir|refutar|demostrar.*debilidad|diseñar.*prueba)",
            ],

            TaskType.PAPER_INTELLIGENCE: [
                r"(paper|artículo.*científico|publicación|investigación.*académica|literatura)",
                r"(metodología.*paper|supuesto.*paper|fórmula|variable.*modelo|limitación)",
                r"(knowledge.*graph|resumen.*técnico|resumen.*ejecutivo|citar|referencia)",
            ],

            TaskType.REPO_RECONSTRUCTION: [
                r"(repositorio|repo|código.*fuente|notebook|script.*py|pipeline.*código)",
                r"(reverse.*engineering|reconstruir|arquitectura.*código|dependencia|flujo.*ejecución)",
                r"(árbol.*proyecto|estructura.*carpeta|módulo|función|clase|importación)",
            ],

            TaskType.REGULATORY_REVIEW: [
                r"(regulatorio|regulación|basilea|sbs|bcbs|circular|resolución|normativa.*banco)",
                r"(capital.*regulatorio|riesgo.*crédito|riesgo.*mercado|riesgo.*operacional)",
                r"(cumplimiento.*regulatorio|requerimiento.*regulatorio|stress.*test|backtesting.*regulatorio)",
            ],

            TaskType.DOCUMENTATION_AUDIT: [
                r"(documentación|documento|informe|reporte|especificación|manual.*modelo)",
                r"(auditoría.*doc|revisar.*documento|calidad.*documento|trazabilidad.*doc)",
                r"(técnico|ejecutivo|metodológico|dmo|dts|dsr|model.*documentation)",
            ],

            TaskType.MODEL_GOVERNANCE: [
                r"(gobierno|governance|control|aprobación|inventario.*modelo|registro.*modelo)",
                r"(ciclo.*vida|lifecycle|mrm|model.*risk|comité|owner|stakeholder)",
                r"(trazabilidad|auditabilidad|versionado|cambio.*modelo|materialidad)",
            ],
        }

    def route(self, query: str) -> Tuple[TaskType, float]:
        query_lower = query.lower()
        scores: Dict[TaskType, float] = {}

        for task_type, patterns in self.task_patterns.items():
            matches = sum(
                1 for pattern in patterns
                if re.search(pattern, query_lower, re.IGNORECASE)
            )
            scores[task_type] = matches / len(patterns)

        if max(scores.values()) == 0:
            return TaskType.UNKNOWN, 0.0

        best_task = max(scores, key=scores.get)
        return best_task, scores[best_task]

    def get_task_description(self, task_type: TaskType) -> str:
        descriptions = {
            TaskType.FAILURE_ANALYSIS:       "Análisis de Fallas y Riesgos",
            TaskType.METHODOLOGY_COMPLIANCE: "Cumplimiento Metodológico",
            TaskType.CHALLENGER_GENERATION:  "Generación de Challenger",
            TaskType.PAPER_INTELLIGENCE:     "Inteligencia de Papers",
            TaskType.REPO_RECONSTRUCTION:    "Reconstrucción de Repositorio",
            TaskType.REGULATORY_REVIEW:      "Revisión Regulatoria",
            TaskType.DOCUMENTATION_AUDIT:    "Auditoría de Documentación",
            TaskType.MODEL_GOVERNANCE:       "Gobierno de Modelos",
            TaskType.UNKNOWN:                "Consulta General MRM",
        }
        return descriptions.get(task_type, "Desconocido")
