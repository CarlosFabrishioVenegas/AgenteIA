"""
====================================================================
ARCHIVO: orchestrator/orchestrator.py
====================================================================

OBJETIVO:
    Orquestador principal del pipeline de agente orquestado (V2).
    Coordina skills, tools, memoria, RAG y evaluadores en un flujo
    unificado por cada query del usuario.

PARA QUÉ SIRVE:
    Actúa como "director de orquesta" del sistema multicomponente.
    Cuando una query llega, este módulo decide qué skill ejecutar,
    gestiona el estado del workflow, invoca RAG si es necesario,
    evalúa la calidad de la respuesta y registra el resultado.


    Clase central AgentOrchestrator. Es el único componente que conoce
    a todos los demás. process_query() ejecuta el pipeline completo:

    1. TaskRouter.route()         -> detecta el TaskType de la query
    2. WorkflowManager            -> crea contexto con UUID único
    3. RAG (opcional)             -> recupera documentos relevantes
    4. Skill registrada           -> genera la respuesta
    5. _evaluate_response()       -> verifica calidad (hallucination + confidence)
    6. WorkflowManager.finalize() -> cierra y registra métricas

    Patrón de registro (antes de llamar a process_query):
    register_skill(TaskType.SALES_ANALYSIS, SalesAnalysisSkill())
    register_tool("sql_tool", SQLTool())
    register_evaluator("hallucination_checker", HallucinationChecker())
    set_memory(ShortTermMemory())
    set_rag_system(SemanticSearcher(embedder, chroma))
    Si una skill no está registrada, retorna error controlado sin fallar.


POR QUÉ ES NECESARIO:
    Sin este archivo, los componentes del agente (skills, tools,
    memory, RAG, evaluadores) son piezas aisladas. El orquestador
    es el pegamento que los conecta en un flujo coherente y
    rastreable por workflow_id.

QUÉ PASA SI SE ELIMINA:
    - agent_orchestrated.py deja de funcionar completamente.
    - Las skills no pueden ejecutarse (no hay quien las invoque).
    - El sistema de tracing de workflows pierde su coordinador.
    - Solo quedaría el agente simple (agent.py) sin orquestación.

LÓGICA DE NEGOCIO:
    Pipeline de 6 pasos por query:
    1. Routing: TaskRouter clasifica la query → TaskType
    2. Contexto: crea WorkflowContext con ID único (UUID4)
    3. RAG: si hay sistema RAG configurado, recupera docs relevantes
    4. Skill: ejecuta la skill registrada para ese TaskType
    5. Evaluación: evalúa calidad con evaluadores registrados
    6. Finalización: marca workflow como COMPLETED o FAILED

FLUJO DE DATOS:
    query → TaskRouter → WorkflowManager.create_workflow()
         → RAG.retrieve() (opcional)
         → Skill.execute() → tool_results
         → _evaluate_response()
         → WorkflowManager.finalize_workflow()
         → Dict con status, result, workflow_id

FLUJO DE AGENTES:
    Este componente está en la capa de orquestación. Es el
    intermediario entre SalesAgent (agent_orchestrated.py) y
    las skills/tools especializadas. No genera respuestas
    directamente: delega a las skills registradas.

DEPENDENCIAS CRÍTICAS:
    - task_router.TaskRouter      : clasifica queries en TaskType
    - workflow_manager.WorkflowManager : gestiona estados del workflow
    - skills registradas externamente via register_skill()
    - tools registrados via register_tool()
    - evaluadores via register_evaluator()

RIESGOS:
    - Si una skill lanza excepción: el workflow se marca FAILED
      y retorna error dict (no rompe el proceso).
    - Si no hay skill registrada para un TaskType: retorna error
      {"error": "Skill no disponible para X"}.
    - set_memory() recibe un solo argumento pero agent_orchestrated.py
      lo llama con dos (short_term, long_term) → bug potencial.

ESCALABILIDAD:
    - Los workflows se guardan en memoria (dict). En producción con
      muchas sesiones paralelas, usar Redis o base de datos.
    - No tiene límite de workflows activos: puede crecer indefinidamente.

IMPACTO DE NEGOCIO:
    ALTO. Es el componente que permite que el agente orquestado
    procese queries de forma estructurada y rastreable.

NIVEL DE CRITICIDAD:
    ALTO

NOTAS TÉCNICAS:
    - process_query() es async: requiere await en el caller.
    - Los skills también son async (BaseSkill.execute() es coroutine).
    - El método _evaluate_response() es sync (no async) por diseño.
    - workflow_id es UUID4 generado localmente → único por request.

====================================================================
"""

import uuid
from typing import Dict, Any, Optional
import logging

from .task_router import TaskRouter, TaskType
from .workflow_manager import WorkflowManager, WorkflowState, WorkflowContext

logger = logging.getLogger(__name__)


class AgentOrchestrator:
    """
    Orquestador principal del agente. Coordina el flujo completo de una query.

    Flujo de process_query():
        1. TaskRouter.route()        → determina el TaskType
        2. WorkflowManager           → crea contexto y registra estado
        3. RAG (si está configurado) → recupera documentos relevantes
        4. Skill.execute()           → genera la respuesta
        5. _evaluate_response()      → verifica calidad
        6. WorkflowManager.finalize  → cierra el workflow

    Patrón de registro (lazy):
        Los componentes se registran ANTES de llamar a process_query().
        Si una skill no está registrada, se retorna error en lugar de fallar.
    """

    def __init__(self, config: Dict[str, Any] = None):
        """
        Args:
            config: Configuración opcional del agente (model, max_tokens, etc.).
                    Si es None, se usan valores por defecto.
        """
        self.config = config or {}
        self.task_router = TaskRouter()       # Clasifica queries en TaskType
        self.workflow_manager = WorkflowManager()  # Gestiona estado de workflows
        self.skills = {}       # {TaskType → skill_instance} — mapeado en register_skill()
        self.tools = {}        # {tool_name → tool_instance} — mapeado en register_tool()
        self.memory = None     # Instancia de ShortTermMemory o similar
        self.rag_system = None # Instancia de SemanticSearcher
        self.evaluators = {}   # {evaluator_name → evaluator_instance}

    def register_skill(self, task_type: TaskType, skill_instance):
        """
        Asocia una skill a un TaskType.

        Una sola skill por TaskType. Si se registra una segunda skill para
        el mismo TaskType, sobreescribe la anterior (sin warning).

        Args:
            task_type:      Enum que identifica el tipo de tarea.
            skill_instance: Instancia de una subclase de BaseSkill.
        """
        self.skills[task_type] = skill_instance
        logger.info(f"Skill registrada para {task_type.value}: {skill_instance.__class__.__name__}")

    def register_tool(self, tool_name: str, tool_instance):
        """
        Registra una herramienta disponible para las skills.

        Las tools se pasan a skill.execute() como dict completo,
        permitiendo que cada skill use las que necesita.

        Args:
            tool_name:     Nombre clave (ej: "sql_tool", "shap_tool").
            tool_instance: Instancia de una subclase de BaseTool.
        """
        self.tools[tool_name] = tool_instance
        logger.info(f"Herramienta registrada: {tool_name}")

    def register_evaluator(self, evaluator_name: str, evaluator_instance):
        """
        Registra un evaluador de calidad de respuestas.

        Los evaluadores se llaman en _evaluate_response() después de
        que la skill genera su resultado.

        Args:
            evaluator_name:     Clave (ej: "hallucination_checker", "confidence_scorer").
            evaluator_instance: Instancia del evaluador correspondiente.
        """
        self.evaluators[evaluator_name] = evaluator_instance
        logger.info(f"Evaluador registrado: {evaluator_name}")

    def set_memory(self, memory_instance):
        """
        Configura el sistema de memoria del agente.

        Args:
            memory_instance: Instancia de ShortTermMemory, LongTermMemory
                             o cualquier objeto con interface store/retrieve.
        """
        self.memory = memory_instance
        logger.info(f"Sistema de memoria configurado: {memory_instance.__class__.__name__}")

    def set_rag_system(self, rag_instance):
        """
        Configura el sistema RAG para recuperación de documentos.

        Args:
            rag_instance: Instancia de SemanticSearcher o similar.
                          Debe implementar retrieve(query, top_k) async.
        """
        self.rag_system = rag_instance
        logger.info(f"Sistema RAG configurado: {rag_instance.__class__.__name__}")

    async def process_query(self, query: str, task_type_override=None) -> Dict[str, Any]:
        """
        Procesa una query a través del pipeline completo del agente.

        Es async porque las skills y el RAG pueden hacer llamadas I/O
        (LLM API, ChromaDB, DuckDB) que se benefician de async/await.

        Args:
            query: Pregunta del usuario en lenguaje natural.

        Returns:
            Dict con:
            - status: "success" | "error"
            - workflow_id: UUID único de esta ejecución (para trazabilidad)
            - task_type: Nombre del TaskType detectado
            - result: Output de la skill ejecutada
            - context_docs: Número de documentos RAG recuperados
        """
        # Generar ID único por workflow para trazabilidad (logs, debugging)
        workflow_id = str(uuid.uuid4())
        logger.info(f"Procesando query: {query[:100]}... [ID: {workflow_id}]")

        try:
            # ── Paso 1: Enrutamiento ──────────────────────────────────────────
            # TaskRouter clasifica la query en uno de los 7 TaskType definidos
            self.workflow_manager.update_state(workflow_id, WorkflowState.ROUTING)
            if task_type_override is not None:
                task_type = task_type_override
                confidence = 0.3
            else:
                task_type, confidence = self.task_router.route(query)
            logger.info(f"Tarea enrutada a: {task_type.value} (confianza: {confidence:.2f})")

            # ── Paso 2: Crear contexto de workflow ────────────────────────────
            # WorkflowContext agrupa query, documentos RAG, resultados de tools
            # y se pasa a la skill como contexto compartido
            context = self.workflow_manager.create_workflow(
                workflow_id, query, task_type.value
            )

            # ── Paso 3: Recuperación RAG (opcional) ───────────────────────────
            # Si hay un sistema RAG configurado, recuperar documentos relevantes
            # antes de ejecutar la skill para enriquecer el contexto
            if self.rag_system:
                self.workflow_manager.update_state(workflow_id, WorkflowState.RETRIEVING_CONTEXT)
                top_k: int = self.config.get("rag", {}).get("top_k", 5)
                retrieved_docs = await self.rag_system.retrieve(query, top_k=top_k)
                for doc in retrieved_docs:
                    self.workflow_manager.add_retrieved_doc(workflow_id, doc)
                logger.info(f"Documentos recuperados: {len(retrieved_docs)}")

            # ── Paso 4: Ejecución de la skill ─────────────────────────────────
            # La skill correspondiente al TaskType recibe query + context + tools
            if task_type in self.skills:
                self.workflow_manager.update_state(workflow_id, WorkflowState.EXECUTING_SKILL)
                skill = self.skills[task_type]
                result = await skill.execute(query, context, self.tools)
                self.workflow_manager.add_tool_result(workflow_id, "skill_execution", result)
                logger.info(f"Skill ejecutada: {skill.__class__.__name__}")
            else:
                # No hay skill registrada para este TaskType — error controlado
                logger.warning(f"No hay skill registrada para {task_type.value}")
                result = {"error": f"Skill no disponible para {task_type.value}"}

            # ── Paso 5: Evaluación de calidad ─────────────────────────────────
            # Verificar alucinaciones y confianza antes de retornar al usuario
            if self.evaluators:
                self.workflow_manager.update_state(workflow_id, WorkflowState.EVALUATING)
                evaluation = self._evaluate_response(result, query)
                self.workflow_manager.add_tool_result(workflow_id, "evaluation", evaluation)

            # ── Paso 6: Finalizar workflow ────────────────────────────────────
            self.workflow_manager.finalize_workflow(workflow_id)
            self.workflow_manager.update_state(workflow_id, WorkflowState.COMPLETED)

            return {
                "status": "success",
                "workflow_id": workflow_id,
                "task_type": task_type.value,
                "result": result,
                "context_docs": len(context.retrieved_documents),
            }

        except Exception as e:
            logger.error(f"Error procesando query: {str(e)}")
            self.workflow_manager.update_state(workflow_id, WorkflowState.FAILED)
            return {
                "status": "error",
                "workflow_id": workflow_id,
                "error": str(e),
            }

    def _evaluate_response(self, result: Dict, query: str) -> Dict[str, Any]:
        """
        Llama a los evaluadores registrados sobre el resultado de la skill.

        Convierte result a string antes de evaluar — los checkers esperan
        texto, no un dict.
        """
        evaluations = {}

        # Extraer texto plano del resultado para los evaluadores
        if isinstance(result, dict):
            response_text = result.get("response", str(result))
        else:
            response_text = str(result)

        # Verificar alucinaciones numéricas en el texto de respuesta
        if "hallucination_checker" in self.evaluators:
            try:
                score, _ = self.evaluators["hallucination_checker"].check(
                    response_text, query
                )
                evaluations["hallucination_score"] = score
            except Exception:
                pass

        # Score de confianza compuesto
        if "confidence_scorer" in self.evaluators:
            try:
                evaluations["confidence"] = self.evaluators["confidence_scorer"].score(
                    {"response": response_text}
                )
            except Exception:
                pass

        return evaluations

    def get_workflow_trace(self, workflow_id: str) -> Dict[str, Any]:
        """
        Retorna el trace completo de un workflow para debugging.

        Útil para entender exactamente qué ocurrió en una ejecución fallida:
        qué skill se ejecutó, qué tools se llamaron, cuánto tardó cada estado.

        Args:
            workflow_id: UUID retornado por process_query().
        """
        return self.workflow_manager.export_workflow_trace(workflow_id)

    def get_status(self) -> Dict[str, Any]:
        """
        Retorna el estado actual del orquestador.

        Útil para diagnosticar si todos los componentes están registrados
        antes de iniciar el agente en producción.
        """
        return {
            "skills_registered": len(self.skills),
            "tools_registered": len(self.tools),
            "evaluators_registered": len(self.evaluators),
            "memory_configured": self.memory is not None,
            "rag_configured": self.rag_system is not None,
            "active_workflows": len(self.workflow_manager.workflows),
        }
