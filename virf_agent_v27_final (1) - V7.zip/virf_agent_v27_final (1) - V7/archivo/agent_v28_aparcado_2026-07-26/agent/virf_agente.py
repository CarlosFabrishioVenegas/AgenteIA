"""
virf_agente.py — Punto de entrada del VIRF Agent v27
======================================================
Equivalente al agente.py de la v25/v26, pero ahora el modo
conversacional es el principal.

MODOS DE USO:

  # Modo conversacional (NUEVO — principal en v27)
  python virf_agente.py --chat
  python virf_agente.py --chat --titulo "Modelo LaR v3" --dominio LaR

  # Pipeline 1 — por control (v25/v26 legacy)
  python virf_agente.py --titulo "Modelo LaR v3" --tier I --control

  # Pipeline 2 — por ámbito (v25/v26 legacy)
  python virf_agente.py --titulo "Modelo LaR v3" --tier I

  # Pipeline completo + conversación al final
  python virf_agente.py --titulo "Modelo LaR v3" --tier I --chat-post

  # Estadísticas de feedback
  python virf_agente.py --estadisticafeedback
"""

import argparse
import sys
from pathlib import Path

_ROOT = Path(__file__).parent
for _p in [str(_ROOT), str(_ROOT / "motor")]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from dotenv import load_dotenv
    load_dotenv(_ROOT / ".env")
except ImportError:
    pass


def main():
    parser = argparse.ArgumentParser(
        description="VIRF Agent v27 — Validador de Modelos Financieros",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # ── Modo conversacional ───────────────────────────────────────────────────
    parser.add_argument(
        "--chat", action="store_true",
        help="Iniciar sesión conversacional interactiva (modo principal v27)",
    )
    parser.add_argument(
        "--chat-post", action="store_true",
        help="Ejecutar pipeline primero y luego abrir sesión conversacional",
    )

    # ── Parámetros comunes ────────────────────────────────────────────────────
    parser.add_argument("--titulo",  default="", help="Nombre del modelo a validar")
    parser.add_argument("--tier",    default="I",
                        choices=["I", "II", "III", "IV"], help="Tier regulatorio")
    parser.add_argument("--dominio", default="auto",
                        choices=["auto", "LaR", "VaR", "conductuales", "shared"])

    # ── Pipeline legacy ───────────────────────────────────────────────────────
    parser.add_argument("--control", action="store_true",
                        help="Pipeline 1: evaluación por control (ControlesData.xlsx)")
    parser.add_argument("--excel",   default="",
                        help="Ruta al ControlesData.xlsx (Pipeline 1)")
    parser.add_argument("--prdc",    action="store_true",
                        help="Modo producción (sin score iterativo)")
    parser.add_argument("--paralelo", action="store_true",
                        help="Pipeline 2 en paralelo (más rápido)")

    # ── Feedback ──────────────────────────────────────────────────────────────
    parser.add_argument("--estadisticafeedback", action="store_true",
                        help="Mostrar estadísticas de feedback acumulado")

    args = parser.parse_args()

    # ── Estadísticas de feedback ──────────────────────────────────────────────
    if args.estadisticafeedback:
        try:
            from agent.feedback.feedback_store import FeedbackStore
            FeedbackStore().mostrar_estadisticas()
        except Exception as e:
            print(f"Error cargando feedback: {e}")
        return

    # ── Modo conversacional puro ──────────────────────────────────────────────
    if args.chat:
        from agent.virf_agent import VIRFAgent
        agente = VIRFAgent(titulo_modelo=args.titulo, dominio=args.dominio)
        agente.run()
        return

    # ── Pipeline legacy (--control o pipeline 2) ─────────────────────────────
    resultado_pipeline = None

    if not args.titulo:
        parser.print_help()
        print("\n💡 Para modo conversacional: python virf_agente.py --chat")
        sys.exit(1)

    if args.control:
        excel = args.excel or str(
            _ROOT / "inputs" / "calidad_datos" / "ControlesData.xlsx"
        )
        try:
            from modulos.motor_ia import orquestar_pipeline_virf
            resultado_pipeline = orquestar_pipeline_virf(
                base_project_path = str(_ROOT),
                excel_controles   = excel,
                nombre_modelo     = args.titulo,
                fecha_informe     = __import__("datetime").datetime.now().strftime("%Y-%m-%d"),
                tier              = args.tier,
            )
            print(f"\n✅ Pipeline 1 completado")
            if resultado_pipeline:
                print(f"   Word: {resultado_pipeline.get('ruta_word','N/A')}")
        except Exception as e:
            print(f"❌ Error Pipeline 1: {e}")
            sys.exit(1)

    else:
        try:
            from modulos.motor_ia import orquestar_pipeline_ambitos
            resultado_pipeline = orquestar_pipeline_ambitos(
                titulo_modelo = args.titulo,
                tier          = args.tier,
                modo_preprdc  = not args.prdc,
                paralelo      = args.paralelo,
            )
            sc = resultado_pipeline.get("score_global", "N/A")
            sem = resultado_pipeline.get("semaforo", {}).get("label", "")
            print(f"\n✅ Pipeline 2 completado — Score: {sc} | {sem}")
        except Exception as e:
            print(f"❌ Error Pipeline 2: {e}")
            sys.exit(1)

    # ── Conversación post-pipeline ────────────────────────────────────────────
    if args.chat_post:
        print("\n💬 Abriendo sesión conversacional con el contexto del pipeline...")
        from agent.virf_agent import VIRFAgent
        agente = VIRFAgent(titulo_modelo=args.titulo, dominio=args.dominio)

        # Pre-cargar hallazgos del pipeline si los hay
        if resultado_pipeline and resultado_pipeline.get("evaluaciones"):
            for ambito, evals in resultado_pipeline["evaluaciones"].items():
                for ev in evals:
                    puntaje = ev.get("puntaje", 0)
                    if puntaje and puntaje <= 2:
                        agente._registrar_hallazgo({
                            "tipo":       "pipeline",
                            "gravedad":   "ALTO" if puntaje == 1 else "MEDIO",
                            "descripcion": f"[{ambito}] {ev.get('actividad','')} — Score: {puntaje}/5",
                            "fuente":     "pipeline_legacy",
                        })

        print(f"  ℹ️  {len(agente.hallazgos)} hallazgo(s) cargados desde el pipeline.")
        agente.run()


if __name__ == "__main__":
    main()
