"""
====================================================================
ARCHIVO: tools/code_reader_tool.py  — virf_agent_v28
====================================================================

TOOL: Code Reader
PROPÓSITO: Leer y preparar artefactos de código (.py, .sql, .ipynb, .json)
           para ser consumidos por las skills MRM como contexto de análisis.

NUEVO EN v28 — no existía en v27.
====================================================================
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)


class CodeReaderTool:
    """
    Lee archivos de código y los prepara como contexto para skills MRM.
    
    Soporta: .py, .sql, .ipynb, .json, .md, .txt, .csv (preview)
    Límite de tamaño: 8,000 chars por archivo (configurable)
    """

    SUPPORTED_EXTENSIONS = {".py", ".sql", ".ipynb", ".json", ".md", ".txt", ".csv"}
    DEFAULT_MAX_CHARS = 8_000

    def __init__(self, max_chars: int = DEFAULT_MAX_CHARS):
        self.max_chars = max_chars

    def read(self, file_path: str) -> Dict[str, Any]:
        """
        Lee un archivo y retorna su contenido procesado.
        
        Returns:
            {
                "content": str,      # Contenido del archivo
                "file_type": str,    # Extensión detectada
                "truncated": bool,   # Si fue truncado por tamaño
                "error": str | None  # Error si ocurrió
            }
        """
        path = Path(file_path)

        if not path.exists():
            return {"content": "", "file_type": "", "truncated": False,
                    "error": f"Archivo no encontrado: {file_path}"}

        ext = path.suffix.lower()
        if ext not in self.SUPPORTED_EXTENSIONS:
            return {"content": "", "file_type": ext, "truncated": False,
                    "error": f"Extensión no soportada: {ext}"}

        try:
            if ext == ".ipynb":
                content = self._read_notebook(path)
            else:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()

            truncated = len(content) > self.max_chars
            if truncated:
                content = content[:self.max_chars] + "\n\n[... TRUNCADO — archivo mayor a límite ...]"

            return {"content": content, "file_type": ext, "truncated": truncated, "error": None}

        except Exception as e:
            logger.error(f"[CodeReaderTool] Error leyendo {file_path}: {e}")
            return {"content": "", "file_type": ext, "truncated": False, "error": str(e)}

    def read_multiple(self, file_paths: list) -> Dict[str, Any]:
        """
        Lee múltiples archivos y los combina para análisis MRM.
        
        Returns:
            {
                "combined_content": str,  # Todo el contenido combinado
                "files_read": list,       # Archivos leídos exitosamente
                "files_failed": list,     # Archivos con error
            }
        """
        combined_parts = []
        files_read = []
        files_failed = []

        for fp in file_paths:
            result = self.read(fp)
            if result["error"]:
                files_failed.append({"path": fp, "error": result["error"]})
            else:
                combined_parts.append(
                    f"{'='*60}\nARCHIVO: {fp}\nTIPO: {result['file_type']}\n{'='*60}\n"
                    f"{result['content']}\n"
                )
                files_read.append(fp)

        return {
            "combined_content": "\n\n".join(combined_parts),
            "files_read": files_read,
            "files_failed": files_failed,
        }

    def _read_notebook(self, path: Path) -> str:
        """
        Extrae el contenido legible de un Jupyter notebook.
        Solo extrae celdas de código y markdown, sin outputs.
        """
        try:
            with open(path, "r", encoding="utf-8") as f:
                nb = json.load(f)

            lines = []
            for cell in nb.get("cells", []):
                cell_type = cell.get("cell_type", "")
                source = "".join(cell.get("source", []))
                if cell_type == "markdown":
                    lines.append(f"# [MARKDOWN]\n{source}\n")
                elif cell_type == "code":
                    lines.append(f"# [CODE]\n{source}\n")

            return "\n".join(lines)
        except Exception as e:
            return f"Error leyendo notebook: {e}"

    def get_project_tree(self, root_path: str, max_files: int = 100) -> str:
        """
        Genera un árbol de archivos del proyecto (solo archivos soportados).
        
        Útil como input para RepoReconstructionSkill.
        """
        root = Path(root_path)
        if not root.exists():
            return f"Directorio no encontrado: {root_path}"

        lines = [f"{root.name}/"]
        count = 0

        for path in sorted(root.rglob("*")):
            if count >= max_files:
                lines.append("  ... (truncado)")
                break
            # Excluir directorios ocultos y __pycache__
            if any(part.startswith(".") or part == "__pycache__"
                   for part in path.parts):
                continue
            if path.is_file() and path.suffix.lower() in self.SUPPORTED_EXTENSIONS:
                relative = path.relative_to(root)
                depth = len(relative.parts) - 1
                prefix = "  " * depth + "├── "
                lines.append(f"{prefix}{path.name}")
                count += 1

        return "\n".join(lines)
