"""
====================================================================
ARCHIVO: tools/pandas_tool.py
====================================================================

OBJETIVO:
    Ejecuta operaciones de análisis con pandas DataFrames. Usado por skills para análisis estadísticos (describe, correlation, groupby).

PARA QUÉ SIRVE:
    Es una herramienta (tool) del sistema de agente orquestado.
    Los skills la reciben via el dict tools{} en execute() y la
    invocan para realizar operaciones especializadas sin importar
    la herramienta directamente (inyección de dependencias).

POR QUÉ ES NECESARIO:
    Desacopla la lógica de los skills de las implementaciones
    específicas de herramientas. Facilita testing, reemplazo y
    extensión del sistema.

QUÉ PASA SI SE ELIMINA:
    - Los skills que dependan de esta tool específica fallarán
      al intentar ejecutar operaciones que requieren esta herramienta.
    - El sistema se degrada para las queries que la necesiten.

LÓGICA DE NEGOCIO:
    Implementa BaseTool.execute() con la lógica específica de su dominio.
    Sigue el patrón: pre_execute() → lógica → post_execute().

DEPENDENCIAS CRÍTICAS:
    - tools/base_tool.BaseTool : interfaz base obligatoria
    - Librerías del dominio (pandas, matplotlib, shap, etc.)

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""

from typing import Dict, Any
import logging
import pandas as pd
from .base_tool import BaseTool

logger = logging.getLogger(__name__)


class PandasTool(BaseTool):
    """Herramienta para análisis con pandas"""

    def __init__(self, data: pd.DataFrame = None):
        super().__init__(
            name="pandas_tool",
            description="Ejecuta operaciones de análisis de datos con pandas",
        )
        self.data = data

    def set_data(self, data: pd.DataFrame):
        """Carga datos para análisis"""
        self.data = data
        logger.info(f"Datos cargados: {data.shape}")

    async def execute(self, operation: str, **kwargs) -> Dict[str, Any]:
        """
        Ejecuta operación de pandas
        
        Args:
            operation: Tipo de operación (describe, correlation, groupby, etc.)
            **kwargs: Parámetros específicos
            
        Returns:
            Resultado de la operación
        """
        await self.pre_execute()

        try:
            if self.data is None:
                return {"error": "No hay datos cargados"}

            if operation == "describe":
                result = self.data.describe().to_dict()
            elif operation == "correlation":
                result = self.data.corr().to_dict()
            elif operation == "groupby":
                group_col = kwargs.get("column")
                agg_col = kwargs.get("aggregate")
                result = self.data.groupby(group_col)[agg_col].agg(["mean", "sum", "count"]).to_dict()
            else:
                result = {"error": f"Operación no soportada: {operation}"}

            await self.post_execute()
            return {"status": "success", "result": result}

        except Exception as e:
            logger.error(f"Error en PandasTool: {str(e)}")
            self.last_error = str(e)
            return {"error": str(e)}

