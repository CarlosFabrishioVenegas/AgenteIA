"""
====================================================================
ARCHIVO: tools/base_tool.py
====================================================================

OBJETIVO:
    Definir la interfaz base (clase abstracta) que deben implementar
    todas las herramientas (tools) del agente. Establece el contrato
    de la capa de tools del sistema.

PARA QUÉ SIRVE:
    Permite que los skills accedan a herramientas de forma uniforme
    sin acoplarse a implementaciones específicas. Un skill puede llamar
    a tools["pandas_tool"].execute(...) sin saber cómo está implementado.

POR QUÉ ES NECESARIO:
    Es el contrato de la arquitectura de tools. Sin esta clase base,
    cada tool tendría una interfaz diferente y los skills tendrían que
    conocer los detalles de cada herramienta específica (acoplamiento fuerte).

QUÉ PASA SI SE ELIMINA:
    - Todas las tools pierden su interfaz común.
    - Los skills no pueden usar tools de forma genérica.
    - La inyección de dependencias via tools dict en execute() se rompe.

LÓGICA DE NEGOCIO:
    Contrato obligatorio:
    - execute(**kwargs) → Dict : ejecuta la operación de la herramienta

    Hooks opcionales:
    - pre_execute()  : incrementa contador, logging
    - post_execute() : libera recursos, logging

    Métricas:
    - execution_count: veces ejecutada la herramienta
    - total_time     : tiempo acumulado de ejecución

DEPENDENCIAS CRÍTICAS:
    - abc.ABC, abstractmethod (stdlib)

NIVEL DE CRITICIDAD:
    ALTO (base de todas las tools del sistema)

====================================================================
"""


from abc import ABC, abstractmethod
from typing import Dict, Any
import logging

logger = logging.getLogger(__name__)


class BaseTool(ABC):
    """Clase base para todas las herramientas del agente"""

    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
        self.execution_count = 0
        self.last_error = None

    @abstractmethod
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Ejecuta la herramienta"""
        pass

    async def pre_execute(self):
        """Hook antes de ejecutar"""
        self.execution_count += 1

    async def post_execute(self):
        """Hook después de ejecutar"""
        pass

    def get_schema(self) -> Dict[str, Any]:
        """Retorna esquema de parámetros aceptados"""
        return {
            "name": self.name,
            "description": self.description,
        }

