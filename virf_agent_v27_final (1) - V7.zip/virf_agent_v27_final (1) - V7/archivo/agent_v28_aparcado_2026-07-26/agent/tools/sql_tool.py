"""
====================================================================
ARCHIVO: tools/sql_tool.py
====================================================================

OBJETIVO:
    Stub y stubs de herramientas individuales del sistema (SQLTool, PlottingTool, SHAPTool, RetrievalTool, RecommendationTool).

PARA QUÉ SIRVE:
    Es una herramienta (tool) del sistema de agente orquestado.
    Los skills la reciben via el dict tools{} en execute() y la
    invocan para realizar operaciones especializadas sin importar
    la herramienta directamente (inyección de dependencias).

POR QUÉ ES NECESARIO:
    Desacopla la lógica de los skills de las implementaciones
    específicas de herramientas. Facilita testing, reemplazo y
    extensión del sistema.

QUÉ PASA SI SE ELIMINA:
    - Los skills que dependan de esta tool específica fallarán
      al intentar ejecutar operaciones que requieren esta herramienta.
    - El sistema se degrada para las queries que la necesiten.

LÓGICA DE NEGOCIO:
    Implementa BaseTool.execute() con la lógica específica de su dominio.
    Sigue el patrón: pre_execute() → lógica → post_execute().

DEPENDENCIAS CRÍTICAS:
    - tools/base_tool.BaseTool : interfaz base obligatoria
    - Librerías del dominio (pandas, matplotlib, shap, etc.)

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""


from .base_tool import BaseTool


class SQLTool(BaseTool):
    def __init__(self): super().__init__("sql_tool", "SQL tool")
    async def execute(self, query: str, **kwargs): return {}


class PlottingTool(BaseTool):
    def __init__(self): super().__init__("plotting_tool", "Plotting tool")
    async def execute(self, plot_type: str, **kwargs): return {}


class SHAPTool(BaseTool):
    def __init__(self): super().__init__("shap_tool", "SHAP tool")
    async def execute(self, model=None, data=None, **kwargs): return {}


class RetrievalTool(BaseTool):
    def __init__(self): super().__init__("retrieval_tool", "Retrieval tool")
    async def execute(self, query: str, top_k: int = 5, **kwargs): return {}


class RecommendationTool(BaseTool):
    def __init__(self): super().__init__("recommendation_tool", "Recommendation tool")
    async def execute(self, segment: str = None, **kwargs): return {}

