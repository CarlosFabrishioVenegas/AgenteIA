"""
====================================================================
ARCHIVO: memory/summaries.py
====================================================================

OBJETIVO:
    Componente del sistema de memoria del agente.
    context_compression.py: Comprime el historial de conversación
    para que quepa en el context window del LLM manteniendo lo esencial.
    summaries.py: Genera resúmenes de conversaciones largas para
    preservar el contexto esencial cuando el historial es muy extenso.

PARA QUÉ SIRVE:
    Gestiona la degradación graceful de la memoria cuando el contexto
    crece más allá del límite del LLM. Sin compresión ni resúmenes,
    las sesiones largas fallarían por exceder el context window.

    Comprime el historial conversacional cuando se alarga demasiado.
    En una sesión de 20 turnos el historial completo puede consumir
    ~8K tokens del context window del LLM. Un resumen de 5 bullets
    consume ~200 tokens y preserva el 80% del contexto relevante.

    Contiene ConversationSummarizer con 3 métodos:
    summarize_history()    -> genera bullets "preguntó X -> respondió Y"
                                para los últimos 5 intercambios del historial.
    should_summarize()     -> True si el historial supera summary_threshold*2
                                (porque hay user+assistant).
    extract_key_entities() -> extrae IDs de clientes (4+ dígitos numéricos),
                                nombres de métricas (auc, f1, recall, lift, ks)
                                y fechas o períodos mencionados en la sesión.

    Estado actual: implementación heurística funcional (sin LLM).
    TODO v2: llamar al LLM con max_tokens=200 para generar resúmenes
    semánticos en lugar de truncar y formatear strings manualmente.

QUÉ PASA SI SE ELIMINA:
    - Las sesiones muy largas pueden exceder el context window del LLM.
    - El sistema se degrada en conversaciones extensas.
    - Las sesiones cortas (uso típico) no se ven afectadas.

NIVEL DE CRITICIDAD:
    BAJO (solo impacta sesiones muy largas)

====================================================================
"""

import re
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)


class ConversationSummarizer:
    """
    Genera resúmenes del historial conversacional.

    Uso:
        summarizer = ConversationSummarizer()
        if summarizer.should_summarize(history):
            summary = summarizer.summarize_history(history[:-5])
            # Reemplazar historial viejo con resumen + últimos 5 turnos
    """

    def __init__(
        self,
        summary_threshold: Optional[int] = None,
        max_user_chars: int = 120,
        max_assistant_chars: int = 80,
        max_bullets: int = 5,
    ):
        if summary_threshold is None:
            try:
                import yaml
                _cfg_path = Path("config/agent_config.yaml")
                if _cfg_path.exists():
                    with open(_cfg_path) as f:
                        _cfg = yaml.safe_load(f)
                    summary_threshold = (
                        _cfg.get("agent", {})
                            .get("memory", {})
                            .get("short_term", {})
                            .get("summary_threshold", 10)
                    )
                else:
                    summary_threshold = 10
            except Exception:
                summary_threshold = 10

        self.summary_threshold: int = summary_threshold
        self.max_user_chars: int = max_user_chars
        self.max_assistant_chars: int = max_assistant_chars
        self.max_bullets: int = max_bullets

    def summarize_history(self, history: List[Dict[str, Any]]) -> str:
        """
        Genera un resumen comprimido del historial conversacional.

        Estrategia actual (heurística):
            Extrae las últimas preguntas del usuario y las respuestas más
            cortas del asistente. Formatea como bullet points.

        Args:
            history: Lista de dicts {"role": "user"|"assistant", "content": str}.

        Returns:
            String con resumen en bullet points. Vacío si el historial es corto.

        TODO (v2): reemplazar heurística por llamada LLM:
            prompt = f"Resume esta conversación en 5 bullets: {history}"
            summary = llm_call(prompt, max_tokens=200)
        """
        if not history or len(history) < self.summary_threshold:
            return ""

        user_turns = [
            h["content"][:self.max_user_chars] for h in history
            if h.get("role") == "user"
        ]
        assistant_turns = [
            h["content"][:self.max_assistant_chars] for h in history
            if h.get("role") == "assistant"
        ]

        bullets = []
        for q, a in zip(user_turns[-self.max_bullets:], assistant_turns[-self.max_bullets:]):
            bullets.append(
                f"• Usuario preguntó: '{q[:self.max_user_chars]}...' "
                f"→ Agente: '{a[:self.max_assistant_chars]}...'"
            )

        if not bullets:
            return ""

        summary = "RESUMEN DE CONVERSACIÓN ANTERIOR:\n" + "\n".join(bullets)
        logger.debug(f"Historial resumido: {len(history)} turnos → {len(bullets)} bullets")
        return summary

    def should_summarize(self, history: List[Dict[str, Any]]) -> bool:
        """Retorna True si el historial supera el umbral de resumen."""
        return len(history) >= self.summary_threshold * 2  # *2 porque user+assistant

    def extract_key_entities(self, history: List[Dict[str, Any]]) -> Dict[str, List[str]]:
        """
        Extrae entidades clave mencionadas en la conversación.

        Retorna dict con:
            - clientes: IDs de clientes mencionados
            - metricas: métricas del modelo citadas
            - fechas: fechas o períodos mencionados

        Útil para enriquecer el contexto del agente con "memoria" de
        qué entidades ya se analizaron en la sesión.
        """
        full_text = " ".join(h.get("content", "") for h in history)

        clientes = re.findall(r'\b\d{4,8}\b', full_text)
        metricas = re.findall(
            r'\b(auc|f1|recall|precision|lift|ks|threshold)\b',
            full_text.lower()
        )
        fechas = re.findall(
            r'\b(q[1-4]|enero|febrero|marzo|abril|mayo|junio|julio|agosto|'
            r'septiembre|octubre|noviembre|diciembre|\d{4})\b',
            full_text.lower()
        )

        return {
            "clientes": list(set(clientes))[:10],
            "metricas": list(set(metricas)),
            "fechas": list(set(fechas))[:5],
        }

    def summarize_conversation(self, history: List[Dict[str, Any]]) -> str:
        """
        Alias de summarize_history para compatibilidad.
        Genera un resumen del historial de conversación.

        Args:
            history: Lista de items de historial.

        Returns:
            String con resumen en formato bullets.
        """
        return self.summarize_history(history)
