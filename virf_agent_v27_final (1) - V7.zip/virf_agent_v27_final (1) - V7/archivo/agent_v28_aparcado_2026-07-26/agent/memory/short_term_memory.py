"""
====================================================================
ARCHIVO: memory/short_term_memory.py
====================================================================

OBJETIVO:
    Gestiona la memoria a corto plazo del agente durante una sesión
    activa. Almacena interacciones recientes en RAM usando una deque
    de capacidad fija.

PARA QUÉ SIRVE:
    Permite al agente recordar el contexto de la conversación actual:
    respuestas anteriores, resultados de herramientas, datos
    recuperados. Las skills pueden consultar la memoria para evitar
    repetir razonamientos o enriquecer nuevas respuestas con contexto
    previo de la sesión.

    Memoria de sesión del agente. Guarda en RAM los eventos del chat
    actual: queries del usuario, respuestas generadas, resultados de
    SQL/pandas/SHAP y cualquier dato que una skill necesite recordar
    dentro del mismo turno o los siguientes.
    Es la "memoria de trabajo" del agente — rápida, temporal, sin disco.


POR QUÉ ES NECESARIO:
    Los LLMs no tienen estado entre llamadas. La memoria a corto
    plazo simula el "contexto de sesión" que de otro modo se perdería.
    Sin ella, cada query del agente empieza desde cero.

QUÉ PASA SI SE ELIMINA:
    - El agente pierde memoria de sesión (cada query es independiente).
    - No puede hacer referencia a resultados anteriores de la sesión.
    - agent_orchestrated.py sigue funcionando pero sin contexto intra-
      sesión: respuestas menos coherentes en conversaciones largas.

LÓGICA DE NEGOCIO:
    - deque(maxlen=N): cuando se llena, el item más antiguo se elimina
      automáticamente (FIFO). Esto previene crecimiento ilimitado.
    - Cada item tiene: key, value, category, timestamp.
    - Categorías permiten recuperar grupos de items (ej: todos los
      "sales_response" de la sesión).

FLUJO DE DATOS:
    store(key, value, category) → deque.append(item)
    retrieve(key)               → busca por key en deque
    retrieve_by_category(cat)   → filtra deque por category
    get_recent(n)               → últimos N items de deque

DEPENDENCIAS CRÍTICAS:
    - collections.deque : estructura FIFO con maxlen automático
    - datetime          : timestamp de cada item almacenado

RIESGOS:
    - maxlen fijo: si max_items < conversación activa, se pierden
      items viejos aunque sean relevantes.
    - Sin persistencia: al cerrar el proceso, la memoria se pierde.
    - retrieve() por key busca linealmente: O(n). Para n>1000 items,
      usar un dict de índice.

ESCALABILIDAD:
    - Máx. 50 items por defecto (configurable en __init__).
    - Solo en RAM: rápido pero no persiste entre sesiones.
    - Para persistencia: usar LongTermMemory en paralelo.

IMPACTO DE NEGOCIO:
    MEDIO. Mejora coherencia en sesiones largas pero el sistema
    funciona sin ella.

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""

from collections import deque  # deque con maxlen descarta los más viejos automáticamente
from typing import Dict, Any, List, Optional
import datetime


class ShortTermMemory:
    """
    Memoria de sesión basada en deque (cola circular).

    Por qué deque y no list:
        Con maxlen=50, cuando se añade el ítem 51 el más antiguo se descarta
        automáticamente. No hay que gestionar manualmente el límite de tamaño.
        Es O(1) para append y O(n) para búsqueda por key (suficiente para 50 ítems).
    """

    def __init__(self, max_items: Optional[int] = None):
        if max_items is None:
            try:
                import yaml
                from pathlib import Path
                _cfg_path = Path("config/agent_config.yaml")
                if _cfg_path.exists():
                    with open(_cfg_path) as f:
                        _cfg = yaml.safe_load(f)
                    max_items = (
                        _cfg.get("agent", {})
                            .get("memory", {})
                            .get("short_term", {})
                            .get("max_size", 50)
                    )
                else:
                    max_items = 50
            except Exception:
                max_items = 50

        self.max_items: int = max_items
        self.memory: deque = deque(maxlen=max_items)
        self.session_start = datetime.datetime.now()

    def store(self, key: str, value: Any, category: str = "general"):
        """
        Añade un ítem a la memoria.

        Args:
            key:      Identificador único del ítem (ej: "sql_result_q3", "cliente_1234").
            value:    Dato a guardar (cualquier tipo Python serializable).
            category: Categoría para recuperación agrupada.
                      Categorías típicas: "query", "response", "tool_result",
                      "customer_analysis", "metric".

        Nota: si ya existe un ítem con la misma key, se añade un duplicado.
        Para actualizar en lugar de duplicar, usar retrieve() primero y
        decidir si vale la pena la búsqueda O(n).
        """
        item = {
            "key": key,
            "value": value,
            "category": category,
            "timestamp": datetime.datetime.now(),
        }
        self.memory.append(item)

    def retrieve(self, key: str) -> Any:
        """
        Busca el primer ítem con la key dada.

        Recorre la deque completa O(n). Para n=50 es despreciable.
        Retorna None si no encuentra nada — los llamadores deben
        verificar None antes de usar el resultado.
        """
        best_value: Any = None
        best_ts: Optional[datetime.datetime] = None

        for item in self.memory:
            if item["key"] == key:
                ts: datetime.datetime = item["timestamp"]
                if best_ts is None or ts > best_ts:
                    best_value = item["value"]
                    best_ts = ts

        return best_value

    def retrieve_by_category(self, category: str) -> List[Dict[str, Any]]:
        """
        Retorna todos los ítems de una categoría, en orden de inserción.

        Uso típico: recuperar todos los "tool_result" para construir el
        contexto de la siguiente llamada al LLM.
        """
        return [item for item in self.memory if item["category"] == category]

    def get_recent(self, n: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Retorna los N ítems más recientes.

        Usado por el orchestrator para añadir contexto reciente al prompt
        sin incluir el historial completo (que puede ser muy largo).
        """
   

    
        if n is None:
            n = min(10, self.max_items)
        return list(self.memory)[-n:]

    def clear(self):
        """
        Vacía la memoria de la sesión.

        Se llama desde el comando /limpiar del agente o al iniciar
        una nueva sesión de trabajo sobre un dataset diferente.
        """
        self.memory.clear()

    def get_summary(self) -> Dict[str, Any]:
        """
        Retorna estadísticas de la memoria actual.

        Útil para debugging y para el comando /datos del agente,
        que muestra cuántos ítems hay en memoria por categoría.
        """
        categories = {}
        for item in self.memory:
            cat = item["category"]
            categories[cat] = categories.get(cat, 0) + 1

        return {
            "total_items": len(self.memory),
            "categories": categories,
            "session_duration": (datetime.datetime.now() - self.session_start).total_seconds(),
        }

