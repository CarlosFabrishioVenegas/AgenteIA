"""
====================================================================
ARCHIVO: memory/context_compression.py
====================================================================

OBJETIVO:
    Componente del sistema de memoria del agente.
    context_compression.py: Comprime el historial de conversación
    para que quepa en el context window del LLM manteniendo lo esencial.
    summaries.py: Genera resúmenes de conversaciones largas para
    preservar el contexto esencial cuando el historial es muy extenso.

PARA QUÉ SIRVE:
    Gestiona la degradación graceful de la memoria cuando el contexto
    crece más allá del límite del LLM. Sin compresión ni resúmenes,
    las sesiones largas fallarían por exceder el context window.

    Coordinador que activa la compresión automática cuando el contexto
    total (dict de contexto + historial conversacional) supera 8000 chars
    (aproximadamente 2000 tokens).

    Combina dos estrategias complementarias:
    1. ContextCompressor (context_engineering/compression.py):
        trunca strings >500 chars y listas >5 items en el context dict.
    2. ConversationSummarizer (memory/summaries.py):
        cuando el historial tiene >10 turnos, reemplaza los turnos viejos
        con un resumen de bullets y conserva los últimos 4 turnos intactos.

    Flujo de compress_if_needed():
    estimate_chars() → supera max_chars? → comprimir dict
    → resumir historial → retornar (context_comprimido, history_comprimido)


QUÉ PASA SI SE ELIMINA:
    - Las sesiones muy largas pueden exceder el context window del LLM.
    - El sistema se degrada en conversaciones extensas.
    - Las sesiones cortas (uso típico) no se ven afectadas.

NIVEL DE CRITICIDAD:
    BAJO (solo impacta sesiones muy largas)

====================================================================
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class ContextMemoryCompressor:
    """
    Coordina compresión de contexto y resumen de historial.

    Uso:
        cmc = ContextMemoryCompressor(max_chars=8000)
        context, history = cmc.compress_if_needed(context, history, query)
    """

    def __init__(self, max_tokens: int = 8000, history_threshold: int = 10, keep_last_turns: int = 4):
        self.max_chars = max_tokens
        self.history_threshold = history_threshold
        self.keep_last_turns = keep_last_turns
        """
        Args:
            max_chars: Límite de caracteres totales del contexto+historial.
                       ~8000 chars ≈ ~2000 tokens, razonable para conservar
                       espacio para la respuesta y el system prompt.
        """

        try:
            from src.agent.context_engineering.compression import ContextCompressor
            from src.agent.memory.summaries import ConversationSummarizer
            self._compressor = ContextCompressor()
            self._summarizer = ConversationSummarizer()
        except ImportError:
            self._compressor = None
            self._summarizer = None

    def compress_if_needed(
        self,
        context: Dict[str, Any],
        history: List[Dict[str, Any]],
        query: str = "",
    ) -> tuple:
        """
        Comprime contexto e historial si superan el límite.

        Args:
            context: Dict con contexto del agente.
            history: Historial conversacional.
            query:   Query actual (para priorización futura).

        Returns:
            Tupla (context_comprimido, history_comprimido).
        """
        total_chars = self.estimate_chars(context, history)

        if total_chars <= self.max_chars:
            return context, history  # Sin necesidad de compresión

        logger.info(
            f"ContextMemoryCompressor: {total_chars} chars > {self.max_chars}. "
            "Aplicando compresión."
        )

        # Comprimir context dict
        if self._compressor:
            context = self._compressor.compress(context)

        # Resumir historial viejo si hay más de 10 turnos
        if self._summarizer and len(history) > self.history_threshold:
            summary_text = self._summarizer.summarize_history(history[:-self.keep_last_turns])
            if summary_text:
                history = [
                    {"role": "system", "content": summary_text}
                ] + history[-self.keep_last_turns:]

        return context, history

    def estimate_chars(self, context: Dict[str, Any], history: List[Dict[str, Any]]) -> int:
        """Estima el total de caracteres del contexto + historial."""
        ctx_chars: int = sum(len(str(v)) for v in context.values())
        hist_chars: int = sum(len(h.get("content", "")) for h in history)
        return ctx_chars + hist_chars

