"""
====================================================================
ARCHIVO: memory/long_term_memory.py
====================================================================

OBJETIVO:
    Gestiona la memoria persistente del agente entre sesiones.
    Almacena interacciones relevantes en disco (JSONL) con TTL
    (tiempo de vida) configurable por item.

PARA QUÉ SIRVE:
    Persiste en disco conocimiento que debe sobrevivir entre sesiones.
    Mientras short_term_memory vive solo en RAM y muere al cerrar el
    agente, long_term_memory escribe en data/agent_memory.jsonl y está
    disponible la próxima vez que se inicie el sistema.

    Casos de uso típicos:
    - Guardar análisis de clientes ("cliente 5042 tiene riesgo alto")
    - Registrar patrones comerciales detectados en sesiones anteriores
    - Persistir correcciones del usuario para no repetir el mismo error
    - Almacenar resúmenes de análisis anteriores como referencia futura

    El TTL (Time To Live) de 30 días por ítem evita que el archivo crezca
    indefinidamente: cleanup_expired() limpia ítems caducados.

POR QUÉ ES NECESARIO:
    La ShortTermMemory se borra al cerrar el proceso. La
    LongTermMemory persiste entre reinicios del agente,
    proporcionando continuidad histórica.

QUÉ PASA SI SE ELIMINA:
    - El agente pierde memoria entre sesiones.
    - agent_orchestrated.py sigue funcionando (ShortTermMemory
      cubre la sesión actual).
    - Se puede regenerar: no contiene datos críticos del negocio,
      solo historial de interacciones.

LÓGICA DE NEGOCIO:
    - Formato JSONL: append-only, una entrada por línea.
    - TTL por item: cada item tiene campo 'expiration' (ISO 8601).
    - Al recuperar: filtra automáticamente items expirados.
    - Sin índice: búsqueda lineal en el archivo JSONL.

FLUJO DE DATOS:
    store(key, value, category, ttl_days)
    → item dict con expiration → append al archivo JSONL

    retrieve(key)
    → lee JSONL completo → filtra por key y expiración → retorna value

DEPENDENCIAS CRÍTICAS:
    - pathlib.Path  : gestión de rutas cross-platform
    - json          : serialización/deserialización de items
    - datetime      : cálculo de TTL y expiración

RIESGOS:
    - Sin índice: para archivos grandes (>10K entradas), retrieve()
      es muy lento (lectura lineal completa del archivo).
    - Items expirados no se limpian del archivo (solo se ignoran en
      lectura): el archivo crece indefinidamente. Implementar purge().
    - Concurrencia: escrituras simultáneas pueden corromper el JSONL.
      Para múltiples agentes en paralelo, usar una DB real.

ESCALABILIDAD:
    - Funcional para uso single-user con volumen bajo (<1K items).
    - Para producción multi-usuario: reemplazar con SQLite, Redis o
      PostgreSQL con columna expiration indexada.

IMPACTO DE NEGOCIO:
    BAJO-MEDIO. Mejora experiencia en uso prolongado pero el sistema
    funciona correctamente sin ella.

NIVEL DE CRITICIDAD:
    BAJO

====================================================================
"""

from typing import Dict, Any, List, Optional
import json
import datetime
from pathlib import Path


class LongTermMemory:
    """
    Memoria persistente entre sesiones basada en JSONL.

    Por qué JSONL (JSON Lines) y no SQLite o JSON plano:
        - Append-only: store() es O(1), solo añade una línea al final del archivo.
          No hay que leer ni reescribir el archivo completo en cada escritura.
        - Tolerante a fallos: si el proceso muere a mitad de escritura, las líneas
          anteriores siguen siendo válidas. Con JSON plano, el archivo quedaría corrupto.
        - Legible directamente: se puede abrir con cualquier editor para inspección.
        - Desventaja: retrieve() es O(n) — lee el archivo completo buscando la key.
          Aceptable para volúmenes pequeños (<10K entradas).

    Formato de cada línea:
        {"key": "...", "value": ..., "category": "...",
         "timestamp": "ISO8601", "expiration": "ISO8601"}
    """

    def __init__(self, storage_path: Optional[str] = None):
        if storage_path is None:
            try:
                import yaml
                _cfg_path = Path("config/agent_config.yaml")
                if _cfg_path.exists():
                    with open(_cfg_path) as f:
                        _cfg = yaml.safe_load(f)
                    storage_path = (
                        _cfg.get("agent", {})
                            .get("memory", {})
                            .get("long_term", {})
                            .get("storage", "data/agent_memory.jsonl")
                    )
                    self.default_ttl_days: int = (
                        _cfg.get("agent", {})
                            .get("memory", {})
                            .get("long_term", {})
                            .get("ttl_days", 30)
                    )
                else:
                    storage_path = "data/agent_memory.jsonl"
                    self.default_ttl_days = 30
            except Exception:
                storage_path = "data/agent_memory.jsonl"
                self.default_ttl_days = 30
        else:
            self.default_ttl_days = 30

        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)

    def store(self, key: str, value: Any, category: str = "general", ttl_days: Optional[int] = None):
        """
        Persiste un ítem en disco.

        Args:
            key:      Identificador único del ítem (ej: "cliente_5042_analisis").
                      No hay unicidad garantizada: si se llama dos veces con la
                      misma key, habrá dos entradas. retrieve() devuelve la primera
                      que encuentra (la más antigua). Para actualizar un valor,
                      la estrategia más simple es añadir la nueva entrada y dejar
                      que cleanup_expired() limpie eventualmente las viejas.
            value:    Cualquier dato serializable a JSON.
            category: Categoría para recuperación agrupada con retrieve_all_by_category().
                      Categorías recomendadas: "customer", "pattern", "correction",
                      "summary", "metric".
            ttl_days: Días de vida del ítem. Default 30. Después de ese período,
                      cleanup_expired() lo elimina. Usar ttl_days=365 para
                      información que no caduca fácilmente (correcciones del usuario).
        """
        ttl: int = ttl_days if ttl_days is not None else self.default_ttl_days

        item = {
            "key": key,
            "value": value,
            "category": category,
            "timestamp": datetime.datetime.now().isoformat(),
            # Fecha de expiración: beyond this, the item is stale and can be deleted
            "expiration": (datetime.datetime.now() + datetime.timedelta(days=ttl)).isoformat(),
            
        }
        # 'a' = append — añade al final sin leer el archivo
        with open(self.storage_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(item) + "\n")

    def retrieve(self, key: str) -> Optional[Any]:
        """
        Busca el primer ítem no expirado con la key dada.

        Lee el archivo línea a línea (streaming) en lugar de cargarlo completo
        en memoria, lo que es más eficiente para archivos grandes.

        Returns:
            El value guardado, o None si no existe o está expirado.
            Los llamadores deben siempre verificar None antes de usar el resultado.
        """
        if not self.storage_path.exists():
            return None

        now = datetime.datetime.now()
        best_value: Optional[Any] = None
        best_ts: Optional[datetime.datetime] = None

        with open(self.storage_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    item = json.loads(line.strip())
                    if item["key"] == key:
                        exp = datetime.datetime.fromisoformat(item["expiration"])
                        if now < exp:
                            ts = datetime.datetime.fromisoformat(item["timestamp"])
                            if best_ts is None or ts > best_ts:
                                best_value = item["value"]
                                best_ts = ts
                except Exception:
                    continue

        return best_value

    def retrieve_all_by_category(self, category: str) -> List[Dict[str, Any]]:
        """
        Recupera todos los ítems válidos de una categoría.

        Útil para cargar todo el conocimiento acumulado sobre un dominio:
          ltm.retrieve_all_by_category("pattern")  → todos los patrones detectados
          ltm.retrieve_all_by_category("correction") → todas las correcciones

        Returns:
            Lista de dicts completos (con key, value, timestamp, etc.),
            ordenados por orden de inserción (el más antiguo primero).
        """
        if not self.storage_path.exists():
            return []

        results = []
        now = datetime.datetime.now()

        with open(self.storage_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    item = json.loads(line.strip())
                    if item["category"] == category:
                        exp = datetime.datetime.fromisoformat(item["expiration"])
                        if now < exp:
                            results.append(item)
                except Exception:
                    continue

        return results

    def cleanup_expired(self):
        """
        Elimina todos los ítems expirados reescribiendo el archivo.

        Esta es la única operación que lee y reescribe el archivo completo (O(n)).
        Se recomienda llamar periódicamente (ej: al iniciar el agente) para
        mantener el archivo pequeño y las búsquedas rápidas.

        Estrategia: leer todos los válidos en memoria → reescribir el archivo.
        Si el proceso falla durante la escritura, los datos originales se pierden.
        Para mayor robustez en producción: escribir a un archivo temporal
        y luego hacer rename atómico.
        """
        if not self.storage_path.exists():
            return

        now = datetime.datetime.now()
        valid_items = []

        # Primera pasada: filtrar ítems válidos
        with open(self.storage_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    item = json.loads(line.strip())
                    exp = datetime.datetime.fromisoformat(item["expiration"])
                    if now < exp:
                        valid_items.append(item)
                except Exception:
                    continue  # descartar líneas corruptas en el proceso de limpieza

        # Segunda pasada: reescribir solo los válidos
        # Segunda pasada: escribir en temporal y rename atómico
        tmp_path = self.storage_path.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            for item in valid_items:
                f.write(json.dumps(item) + "\n")
        tmp_path.replace(self.storage_path)

