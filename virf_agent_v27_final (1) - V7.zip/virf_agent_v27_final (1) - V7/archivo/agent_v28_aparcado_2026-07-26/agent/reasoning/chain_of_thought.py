"""
====================================================================
ARCHIVO: reasoning/chain_of_thought.py
====================================================================

OBJETIVO:
    Componente de trazabilidad del motor de razonamiento del agente.
    Registra el proceso de pensamiento paso a paso (Chain-of-Thought)
    o las decisiones tomadas durante el razonamiento.

PARA QUÉ SIRVE:
    chain_of_thought.py: Implementa la estructura de datos para
    registrar el proceso de razonamiento CoT del agente. Cada
    "thought" tiene un texto de razonamiento y un nivel de confianza.

    decision_trace.py: Registra las decisiones tomadas (routing,
    selección de skill, etc.) con sus opciones alternativas y la
    justificación de la elección. Fundamental para auditoría.

    Implementa razonamiento paso a paso para queries complejas. Detecta
    si una query requiere múltiples pasos de análisis y la descompone
    en sub-preguntas que se inyectan en el prompt para guiar al LLM.

    Contiene ChainOfThought con 3 métodos:
    is_complex_query() -> True si la query contiene conectores multi-paso:
        "y además", "luego", "después", "comparando", "con", "que tengan".
    decompose()        -> divide la query en sub-pasos usando esos conectores.
        Máximo 4 pasos. Para queries simples retorna ["Analizar: {query}"].
    format_steps()     -> formatea los pasos como texto para el prompt.
        Si hay solo 1 paso retorna "" (sin overhead innecesario).

    Por qué CoT mejora la calidad:
    Los LLMs cometen ~30% menos errores en queries multi-condición cuando
    se les pide razonar paso a paso. "Clientes premium con prob>0.7 y que
    compraron en Q3" -> 3 filtros secuenciales -> menos errores que todo junto.

    Estado actual: heurística funcional. TODO v2: usar una llamada LLM
    con max_tokens=150 para descomponer la query antes de la llamada principal.


POR QUÉ ES NECESARIO:
    Proporciona trazabilidad completa del proceso de decisión del
    agente. En sistemas empresariales de IA, la capacidad de auditar
    por qué se tomó una decisión es crítica para confianza y cumplimiento.

QUÉ PASA SI SE ELIMINA:
    - ReasoningEngine no puede registrar sus pasos de razonamiento.
    - Se pierde la trazabilidad del proceso de decisión.
    - Los workflow traces tendrán menos información de auditoría.
    - El sistema sigue funcionando (las decisiones se toman igualmente).

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python (dataclasses, enum, datetime, typing).

NIVEL DE CRITICIDAD:
    BAJO-MEDIO (trazabilidad importante pero no crítico para operación)

====================================================================
"""
import re
import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

# Conectores que suelen indicar una pregunta multi-paso
MULTI_STEP_SIGNALS = [
    " y ", " además ", " también ", " luego ", " después ",
    " con ", " que tengan ", " filtrando ", " comparando ",
]


class ChainOfThought:
    """
    Descompone queries complejas en pasos de razonamiento.

    Uso:
        cot = ChainOfThought()
        steps = cot.decompose("clientes con prob > 0.7 y que compraron en Q3")
        prompt_addition = cot.format_steps(steps)
    """

    def __init__(self):
        """Inicializa el registro de pasos de razonamiento."""
        self.steps = []  # Lista de pasos añadidos con add_step()

    def add_step(self, thought: str, reasoning: str, confidence: float, context: Dict[str, Any] = None):
        """
        Registra un paso de razonamiento.

        Args:
            thought: Descripción corta del paso de pensamiento.
            reasoning: Explicación detallada del razonamiento.
            confidence: Score 0-1 de confianza en este paso.
            context: Contexto adicional (opcional).
        """
        step = {
            "thought": thought,
            "reasoning": reasoning,
            "confidence": confidence,
            "context": context or {},
        }
        self.steps.append(step)
        logger.debug(f"CoT: paso añadido - {thought} (confianza: {confidence:.2f})")

    def decompose(self, query: str) -> List[str]:
        """
        Descompone una query en sub-pasos de razonamiento.

        Estrategia actual (heurística):
            Detecta conectores multi-paso y extrae fragmentos semánticos.
            Para queries simples, retorna un solo paso.

        Args:
            query: Query del usuario en lenguaje natural.

        Returns:
            Lista de strings, cada uno un sub-paso del razonamiento.

        TODO (v2): reemplazar heurística por llamada LLM:
            prompt = f"Descompón esta pregunta en pasos analíticos: '{query}'"
            steps = llm_call(prompt)  # retorna lista de pasos
        """
        query_lower = query.lower()

        # Detectar si es multi-paso
        is_complex = any(sig in query_lower for sig in MULTI_STEP_SIGNALS)

        if not is_complex:
            return [f"Analizar: {query}"]

        # Heurística simple: dividir por conectores
        steps = []
        parts = re.split(r'\b(y|además|también|luego|después)\b', query_lower)
        parts = [p.strip() for p in parts if p.strip() and p not in {"y", "además", "también", "luego", "después"}]

        for i, part in enumerate(parts[:4], 1):  # max 4 pasos
            steps.append(f"Paso {i}: {part}")

        if not steps:
            steps = [f"Analizar: {query}"]

        logger.debug(f"CoT: query descompuesta en {len(steps)} pasos")
        return steps

    def format_steps(self, steps: List[str]) -> str:
        """
        Formatea los pasos como adición al prompt del LLM.

        Args:
            steps: Lista de pasos de razonamiento.

        Returns:
            String formateado para inyectar antes de la respuesta.
        """
        if len(steps) <= 1:
            return ""  # Query simple, no necesita CoT explícito
        header = "Pasos de análisis para responder correctamente:"
        body = "\n".join(f"  {s}" for s in steps)
        return f"{header}\n{body}\n\nAhora responde siguiendo estos pasos:"

    def is_complex_query(self, query: str) -> bool:
        """Retorna True si la query parece requerir razonamiento multi-paso."""
        return any(sig in query.lower() for sig in MULTI_STEP_SIGNALS)

