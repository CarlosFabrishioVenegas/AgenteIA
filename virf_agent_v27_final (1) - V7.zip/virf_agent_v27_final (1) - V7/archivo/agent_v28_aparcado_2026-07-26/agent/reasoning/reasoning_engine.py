"""
====================================================================
ARCHIVO: reasoning/reasoning_engine.py
====================================================================

OBJETIVO:
    Motor de razonamiento del agente que coordina el proceso de
    Chain-of-Thought (CoT) y el registro de decisiones. Determina
    qué skill usar para cada query mediante análisis de keywords
    y scoring de similitud.

PARA QUÉ SIRVE:
    Implementa la capa de razonamiento explícito del agente:
    en lugar de elegir el skill de forma arbitraria, genera un
    "trace de pensamiento" paso a paso (CoT) que explica por qué
    se eligió un skill específico. Esto aumenta trazabilidad y
    debuggability del sistema.

POR QUÉ ES NECESARIO:
    Proporciona transparencia en el proceso de decisión del agente.
    En sistemas de IA empresarial, es importante poder auditar POR QUÉ
    el agente tomó ciertas decisiones.

QUÉ PASA SI SE ELIMINA:
    - agent_orchestrated.py pierde la capa de razonamiento explícito.
    - Las decisiones de routing se hacen sin Chain-of-Thought.
    - Los traces de workflow tendrán menos información de auditoría.
    - El sistema sigue funcionando (TaskRouter hace el routing básico).

LÓGICA DE NEGOCIO:
    Proceso de razonamiento en 3 pasos CoT:
    1. Analizar la pregunta (extractar keywords relevantes)
    2. Evaluar skills disponibles contra keywords
    3. Elegir el skill con mayor score y registrar la decisión

    Scoring de skills:
    - Para cada skill, se cuenta cuántos de sus keywords aparecen
      en la pregunta (normalizado a [0, 1]).
    - El skill con mayor score es el elegido.

FLUJO DE DATOS:
    query + available_skills
    → _extract_keywords(query) → keywords[]
    → _score_skills(keywords, skills) → {skill: score}
    → max(scores) → best_skill
    → CoT.add_step() × 3 → reasoning trace
    → DecisionTrace.record_decision() → auditoría

DEPENDENCIAS CRÍTICAS:
    - reasoning/chain_of_thought.ChainOfThought
    - reasoning/decision_trace.DecisionTrace, DecisionType

RIESGOS:
    - Keyword scoring es superficial: mismas limitaciones que el
      router principal (TaskRouter). Si las keywords no cubren la
      pregunta, el skill elegido puede ser incorrecto.
    - El CoT se genera pero no se usa para tomar la decisión final
      (el score determina la elección). El CoT es solo documentación.

ESCALABILIDAD:
    - Muy rápido: solo string matching, sin llamadas a LLM.
    - El CoT crece linealmente con el número de steps añadidos.

IMPACTO DE NEGOCIO:
    MEDIO. Añade trazabilidad pero no es crítico para la funcionalidad.

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""
"""
====================================================================
ARCHIVO: reasoning/reasoning_engine.py
====================================================================
Motor de razonamiento del agente. Coordina ChainOfThought y
DecisionTrace para elegir el skill más adecuado por keyword scoring.
====================================================================
"""
from typing import Dict, Any, List
import logging

from .chain_of_thought import ChainOfThought
from .decision_trace import DecisionTrace, DecisionType

logger = logging.getLogger(__name__)


class ReasoningEngine:
    """
    Motor de razonamiento basado en keyword scoring.

    Uso:
        engine = ReasoningEngine()
        best_skill = engine.reason_about_task(query, available_skills)
    """

    def __init__(self):
        self.cot            = ChainOfThought()
        self.decision_trace = DecisionTrace()
        self.context: Dict[str, Any] = {}

    def set_context(self, context: Dict[str, Any]) -> None:
        """Establece el contexto para el razonamiento."""
        self.context = context
        logger.debug(f"Contexto de razonamiento establecido: {len(context)} items")

    def reason_about_task(self, query: str, available_skills: List[str]) -> List[str]:
        """
        Razona sobre cuál skill usar y retorna el trace como lista.

        Returns:
            Lista de strings describiendo el proceso de razonamiento.
            Compatible con SalesAgentResponse.reasoning_trace (list).
        """
        logger.info(f"Razonando sobre tarea: {query[:50]}...")

        # Paso 1: Analizar la pregunta
        self.cot.add_step(
            thought="Analizar la pregunta del usuario",
            reasoning=f"Query recibida: '{query[:80]}'",
            confidence=0.95,
        )

        # Paso 2: Extraer keywords
        keywords = self._extract_keywords(query)
        self.cot.add_step(
            thought="Identificar palabras clave relevantes",
            reasoning=f"Keywords: {', '.join(keywords[:5])}",
            confidence=0.9,
            context={"keywords": keywords},
        )

        # Paso 3: Puntuar y elegir skill
        skill_scores = self._score_skills(keywords, available_skills)
        best_skill   = max(skill_scores, key=skill_scores.get)
        confidence   = skill_scores[best_skill]

        self.cot.add_step(
            thought="Seleccionar skill más apropiado",
            reasoning=f"Scores: {', '.join(f'{k}={v:.2f}' for k, v in list(skill_scores.items())[:3])}",
            confidence=confidence,
        )

        # Registrar decisión en el trace
        self.decision_trace.record_decision(
            decision_type=DecisionType.ROUTING,
            options=[{"name": s, "score": skill_scores.get(s, 0)} for s in available_skills],
            chosen_option={"name": best_skill, "score": confidence},
            reasoning="Basado en keyword scoring contra skills disponibles",
            confidence=confidence,
        )

        logger.info(f"Skill elegida: {best_skill} (confianza: {confidence:.2f})")

        # Retornar como lista para SalesAgentResponse.reasoning_trace
        return [step["thought"] for step in self.cot.steps]

    def _extract_keywords(self, query: str, top_n: int = 10) -> List[str]:
        """Extrae keywords filtrando stopwords básicas en español."""
        stop_words = {
            "el", "la", "de", "que", "es", "un", "en", "y",
            "o", "a", "para", "por", "los", "las", "del"
        }
        words    = query.lower().split()
        keywords = [w for w in words if w not in stop_words and len(w) > 3]
        return keywords[:top_n]

    def _score_skills(
        self, keywords: List[str], available_skills: List[str]
    ) -> Dict[str, float]:
        """Puntúa cada skill por relevancia a las keywords."""
        skill_keywords = {
            "sales_analysis":        ["ventas", "sales", "ingresos", "tendencia", "análisis","correlación", "estadística", "frecuencia", "monto","promedio", "distribución", "agrupación", "relación"],
            "conversion_prediction": ["conversión", "compra", "propensión", "predicción", "probabilidad"],
            "recommendations":       ["recomendación", "sugiere", "acción", "estrategia"],
            "explainability":        ["explicabilidad", "explica", "importance", "driver", "shap"],
            "segmentation":          ["segmentación", "cluster", "cliente", "rfm", "tipos"],
            "executive_summary":     ["resumen", "ejecutivo", "overview", "dirección"],
            "model_metrics":         ["métricas", "auc", "f1", "recall", "precision", "modelo"],
        }

        scores = {}
        for skill in available_skills:
            kw_list = skill_keywords.get(skill, [])
            matches = sum(1 for kw in keywords if any(skw in kw for skw in kw_list))
            scores[skill] = matches / (len(kw_list) + 1) if kw_list else 0.1

        return scores

    def evaluate_reasoning(self) -> Dict[str, Any]:
        """Retorna métricas del razonamiento de la sesión actual."""
        steps      = self.cot.steps
        trace_steps = self.decision_trace.get_session_trace()

        avg_cot_conf = (
            sum(s.get("confidence", 0) for s in steps) / len(steps)
            if steps else 0.0
        )
        avg_dec_conf = (
            sum(s.get("confidence", 0) for s in trace_steps) / len(trace_steps)
            if trace_steps else 0.0
        )

        return {
            "cot_steps":                  len(steps),
            "average_cot_confidence":     round(avg_cot_conf, 3),
            "decisions_made":             len(trace_steps),
            "average_decision_confidence": round(avg_dec_conf, 3),
        }

    def reset(self) -> None:
        """Reinicia el motor para una nueva sesión."""
        self.cot.steps = []
        self.decision_trace._steps.clear()
        self.context = {}
        logger.debug("Motor de razonamiento reiniciado")
