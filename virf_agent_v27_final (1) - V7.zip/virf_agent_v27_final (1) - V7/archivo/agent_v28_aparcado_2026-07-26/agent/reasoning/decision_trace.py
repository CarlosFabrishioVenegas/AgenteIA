"""
====================================================================
ARCHIVO: reasoning/decision_trace.py
====================================================================

OBJETIVO:
    Componente de trazabilidad del motor de razonamiento del agente.
    Registra el proceso de pensamiento paso a paso (Chain-of-Thought)
    o las decisiones tomadas durante el razonamiento.

PARA QUÉ SIRVE:
    chain_of_thought.py: Implementa la estructura de datos para
    registrar el proceso de razonamiento CoT del agente. Cada
    "thought" tiene un texto de razonamiento y un nivel de confianza.

    decision_trace.py: Registra las decisiones tomadas (routing,
    selección de skill, etc.) con sus opciones alternativas y la
    justificación de la elección. Fundamental para auditoría.

POR QUÉ ES NECESARIO:
    Proporciona trazabilidad completa del proceso de decisión del
    agente. En sistemas empresariales de IA, la capacidad de auditar
    por qué se tomó una decisión es crítica para confianza y cumplimiento.

QUÉ PASA SI SE ELIMINA:
    - ReasoningEngine no puede registrar sus pasos de razonamiento.
    - Se pierde la trazabilidad del proceso de decisión.
    - Los workflow traces tendrán menos información de auditoría.
    - El sistema sigue funcionando (las decisiones se toman igualmente).

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python (dataclasses, enum, datetime, typing).

NIVEL DE CRITICIDAD:
    BAJO-MEDIO (trazabilidad importante pero no crítico para operación)

====================================================================
"""

import json
import logging
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

DEFAULT_TRACE_DIR = "outputs/traces"


class DecisionType(Enum):
    """
    Tipos de decisiones que el agente registra en el trace.
    
    Usado por DecisionTrace para categorizar cada paso de razonamiento.
    """
    ROUTING = "routing"                           # Clasificación de query
    SKILL_SELECTION = "skill_selection"           # Selección de skill
    PARAMETER_EXTRACTION = "parameter_extraction" # Extracción de parámetros
    TOOL_CALL = "tool_call"                       # Ejecución de herramienta
    RESULT_EVALUATION = "result_evaluation"       # Evaluación de resultado
    OTHER = "other"                               # Otros pasos


class DecisionTrace:
    """
    Registra el rastro de decisiones del agente por sesión.

    Uso:
        tracer = DecisionTrace()
        tracer.trace("routing", input="¿qué clientes?", output="pred", metadata={"score": 0.9})
        tracer.trace("sql_exec", input="SELECT...", output="15 rows", metadata={"time_ms": 120})
        tracer.save_session()
    """

    def __init__(self, trace_dir: str = DEFAULT_TRACE_DIR):
        self.trace_dir = Path(trace_dir)
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        self._steps: List[Dict[str, Any]] = []

    def trace(
        self,
        step_name: str,
        input_data: Any = None,
        output_data: Any = None,
        metadata: Optional[Dict[str, Any]] = None,
        success: bool = True,
    ) -> None:
        """
        Registra un paso de decisión del agente.

        Args:
            step_name:   Nombre del paso (ej: "routing", "sql_exec", "llm_call").
            input_data:  Entrada al paso (query, SQL, etc.).
            output_data: Salida del paso (tipo, resultado, etc.).
            metadata:    Info adicional (latencia, tokens, scores).
            success:     Si el paso fue exitoso.
        """
        entry = {
            "timestamp": datetime.now().isoformat(),
            "step": step_name,
            "input": str(input_data)[:500] if input_data else None,
            "output": str(output_data)[:500] if output_data else None,
            "success": success,
            "metadata": metadata or {},
        }
        self._steps.append(entry)
        level = logging.DEBUG if success else logging.WARNING
        logger.log(level, f"[DecisionTrace] {step_name}: {'✓' if success else '✗'} | out={str(output_data)[:80]}")

    def record_decision(
        self,
        decision_type: DecisionType,
        options: List[Dict[str, Any]],
        chosen_option: Dict[str, Any],
        reasoning: str,
        confidence: float,
    ) -> None:
        """
        Registra una decisión del agente con opciones consideradas.

        Args:
            decision_type: Tipo de decisión (DecisionType enum).
            options: Lista de opciones consideradas.
            chosen_option: La opción elegida.
            reasoning: Explicación de la decisión.
            confidence: Confianza en la decisión (0-1).
        """
        entry = {
            "timestamp": datetime.now().isoformat(),
            "decision_type": decision_type.value if isinstance(decision_type, DecisionType) else decision_type,
            "options": options,
            "chosen_option": chosen_option,
            "reasoning": reasoning,
            "confidence": confidence,
        }
        self._steps.append(entry)
        logger.debug(f"[Decision] {decision_type.value if isinstance(decision_type, DecisionType) else decision_type}: "
                     f"elegido={chosen_option.get('name', '?')} (conf={confidence:.2f})")


    def get_session_trace(self) -> List[Dict[str, Any]]:
        """Retorna todos los pasos registrados en la sesión actual."""
        return list(self._steps)

    def get_last_step(self) -> Optional[Dict[str, Any]]:
        """Retorna el último paso registrado."""
        return self._steps[-1] if self._steps else None

    def clear(self) -> None:
        """Limpia el trace de la sesión actual."""
        self._steps.clear()

    def save_session(self) -> Optional[Path]:
        """
        Persiste el trace de la sesión en un archivo JSON.

        Returns:
            Path del archivo guardado, o None si falló.
        """
        if not self._steps:
            return None
        try:
            self.trace_dir.mkdir(parents=True, exist_ok=True)
            out_path = self.trace_dir / f"trace_{self.session_id}.json"
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump({
                    "session_id": self.session_id,
                    "total_steps": len(self._steps),
                    "steps": self._steps,
                }, f, indent=2, ensure_ascii=False)
            logger.info(f"Trace guardado: {out_path}")
            return out_path
        except Exception as e:
            logger.warning(f"No se pudo guardar trace: {e}")
            return None

    def summary(self) -> str:
        """Retorna un resumen legible del trace de la sesión."""
        if not self._steps:
            return "Sin pasos registrados"
        success_count = sum(1 for s in self._steps if s["success"])
        steps_str = " → ".join(s["step"] for s in self._steps)
        return (
            f"Sesión {self.session_id}: {len(self._steps)} pasos "
            f"({success_count} exitosos) | {steps_str}"
        )

