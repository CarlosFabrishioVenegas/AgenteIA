"""
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
feedback/feedback_analyzer.py
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PARA QUÉ SIRVE
--------------
Analiza el historial de feedback de FeedbackStore para extraer
patrones: qué tipos de preguntas reciben peores calificaciones,
qué áreas necesitan mejora y cuál es la tendencia de satisfacción.

Es el componente que convierte datos crudos (ratings + queries) en
insights accionables que LearningLoop puede incorporar al system prompt.

Estado actual: STUB — analyze() devuelve listas vacías.
TODO v2: implementar análisis real:
  bad = [f for f in feedback if f["rating"] < 3]
  agrupar por keywords de la query -> identificar temas problemáticos
  calcular tendencia temporal -> ¿está mejorando o empeorando?

NOTA DE ARQUITECTURA: FeedbackAnalyzer está duplicada en este archivo,
en learning_loop.py y en corrections.py. Esta es la versión canónica.
Los otros dos módulos deben importarla de aquí en el próximo refactor.

POR QUÉ ES NECESARIO
--------------------
FeedbackStore solo acumula datos crudos. Sin FeedbackAnalyzer el
feedback se acumula pero nunca se convierte en aprendizaje.

QUÉ PASA SI SE ELIMINA
-----------------------
LearningLoop pierde la capacidad de identificar patrones de error.
FeedbackStore sigue guardando ratings — los datos no se pierden.
Las copias en learning_loop.py y corrections.py siguen disponibles.
"""

from typing import Dict, Any, List
from collections import Counter
import datetime
import logging

logger = logging.getLogger(__name__)


class FeedbackAnalyzer:
    """
    Extrae insights del historial de feedback para mejora continua.

    Uso:
        store    = FeedbackStore()
        analyzer = FeedbackAnalyzer()
        result   = analyzer.analyze(store.get_feedback())
        # result["insights"]        → observaciones sobre el rendimiento
        # result["recommendations"] → strings listos para el system prompt
        # result["stats"]           → métricas agregadas
        # result["bad_topics"]      → temas con peores calificaciones
    """

    BAD_THRESHOLD  = 3.0
    GOOD_THRESHOLD = 4.0
    STOPWORDS = {
        "el", "la", "los", "las", "un", "una", "de", "del", "en",
        "que", "y", "a", "es", "se", "por", "con", "para", "como",
        "qué", "cuál", "cuáles", "me", "mi", "al", "lo", "su",
        "más", "hay", "son", "has", "dame", "dime", "muestra",
    }

    def analyze(self, feedback: List[Dict]) -> Dict[str, Any]:
        """
        Analiza la colección de feedbacks y extrae patrones.

        Args:
            feedback: Lista de dicts de FeedbackStore.get_feedback().
                      Cada dict tiene: timestamp, query, response,
                      rating (puede llegar como str desde JSONL), comment.

        Returns:
            Dict con:
            - insights (list[str])        : observaciones detectadas
            - recommendations (list[str]) : acciones para el system prompt
            - stats (dict)                : métricas agregadas
            - bad_topics (list[str])      : keywords de queries con mal rating
            - trend (str)                 : "mejorando" | "empeorando" | "estable"
        """
        if not feedback:
            return {
                "insights":        [],
                "recommendations": [],
                "stats":           {"total": 0, "average_rating": 0.0},
                "bad_topics":      [],
                "trend":           "sin_datos",
            }

        # ── 1. Normalizar ratings a float ─────────────────────────────────────
        entries = []
        for f in feedback:
            try:
                rating = float(f.get("rating", 3))
            except (ValueError, TypeError):
                rating = 3.0
            entries.append({**f, "rating": rating})

        # ── 2. Stats generales ────────────────────────────────────────────────
        ratings = [e["rating"] for e in entries]
        avg     = round(sum(ratings) / len(ratings), 2)
        stats   = {
            "total":          len(entries),
            "average_rating": avg,
            "min_rating":     min(ratings),
            "max_rating":     max(ratings),
            "bad_count":      sum(1 for r in ratings if r < self.BAD_THRESHOLD),
            "good_count":     sum(1 for r in ratings if r >= self.GOOD_THRESHOLD),
        }

        # ── 3. Separar feedback malo ──────────────────────────────────────────
        bad_entries  = [e for e in entries if e["rating"] < self.BAD_THRESHOLD]
        good_entries = [e for e in entries if e["rating"] >= self.GOOD_THRESHOLD]

        # ── 4. Temas problemáticos ────────────────────────────────────────────
        bad_words = Counter()
        for e in bad_entries:
            query = e.get("query", "")
            for word in query.lower().split():
                word = word.strip("¿?.,;:")
                if len(word) > 3 and word not in self.STOPWORDS:
                    bad_words[word] += 1

        bad_topics = [word for word, _ in bad_words.most_common(5)]

        # ── 5. Temas que funcionan bien ───────────────────────────────────────
        good_words = Counter()
        for e in good_entries:
            query = e.get("query", "")
            for word in query.lower().split():
                word = word.strip("¿?.,;:")
                if len(word) > 3 and word not in self.STOPWORDS:
                    good_words[word] += 1

        good_topics = [word for word, _ in good_words.most_common(3)]

        # ── 6. Tendencia temporal ─────────────────────────────────────────────
        trend = "estable"
        if len(entries) >= 6:
            sorted_entries = sorted(entries, key=lambda e: e.get("timestamp", ""))
            recent_avg = sum(e["rating"] for e in sorted_entries[-5:]) / 5
            older_avg  = sum(e["rating"] for e in sorted_entries[:-5]) / len(sorted_entries[:-5])

            if recent_avg > older_avg + 0.3:
                trend = "mejorando"
            elif recent_avg < older_avg - 0.3:
                trend = "empeorando"

        # ── 7. Comentarios negativos explícitos ───────────────────────────────
        explicit_complaints = [
            e.get("comment", "").strip()
            for e in bad_entries
            if e.get("comment", "").strip()
        ]

        # ── 8. Insights ───────────────────────────────────────────────────────
        insights = []

        if stats["bad_count"] > 0:
            pct = round(stats["bad_count"] / stats["total"] * 100)
            insights.append(
                f"{pct}% del feedback tiene calificación negativa "
                f"({stats['bad_count']} de {stats['total']} entradas)."
            )

        if bad_topics:
            insights.append(
                f"Las queries con peores calificaciones involucran: "
                f"{', '.join(bad_topics)}."
            )

        if good_topics:
            insights.append(
                f"Las queries mejor calificadas involucran: "
                f"{', '.join(good_topics)}."
            )

        if trend == "empeorando":
            insights.append(
                "La calidad muestra tendencia negativa en las últimas interacciones."
            )
        elif trend == "mejorando":
            insights.append(
                "La calidad muestra tendencia positiva reciente."
            )

        for complaint in explicit_complaints[-3:]:
            insights.append(f"Comentario del usuario: \"{complaint}\"")

        if not insights:
            insights.append(
                f"Rendimiento estable. Rating promedio: {avg}/5 "
                f"sobre {stats['total']} interacciones."
            )

        # ── 9. Recommendations (van directo al system prompt) ─────────────────
        recommendations = []

        if bad_topics:
            recommendations.append(
                f"Prestar especial atención a consultas sobre: "
                f"{', '.join(bad_topics)}. "
                f"Estas áreas han recibido las peores calificaciones."
            )

        if stats["average_rating"] < self.BAD_THRESHOLD:
            recommendations.append(
                "El rendimiento general es bajo. Revisar si el contexto "
                "de datos (predicciones, métricas) está correctamente cargado."
            )

        if trend == "empeorando":
            recommendations.append(
                "Tendencia negativa detectada. Considerar revisar el system prompt "
                "y los datos de entrada al agente."
            )

        if explicit_complaints:
            recommendations.append(
                "El usuario ha dejado comentarios negativos explícitos. "
                "Revisar el historial de feedback para ajustar respuestas."
            )

        return {
            "insights":        insights,
            "recommendations": recommendations,
            "stats":           stats,
            "bad_topics":      bad_topics,
            "trend":           trend,
        }
