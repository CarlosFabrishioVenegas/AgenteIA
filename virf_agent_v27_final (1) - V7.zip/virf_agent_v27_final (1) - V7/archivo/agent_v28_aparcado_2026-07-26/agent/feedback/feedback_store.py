"""
====================================================================
ARCHIVO: feedback/feedback_store.py
====================================================================

OBJETIVO:
    Almacenar y recuperar retroalimentación del usuario sobre las
    respuestas del agente. Es la capa de persistencia del sistema
    de mejora continua.

PARA QUÉ SIRVE:
    Cada vez que el usuario califica una respuesta (1-5 estrellas),
    el feedback se guarda en JSONL. Este historial se usa para:
    1. Actualizar el system prompt con lecciones aprendidas.
    2. Analizar patrones de errores recurrentes.
    3. Monitorear calidad del agente en el tiempo.
    Almacena de forma persistente cada evaluación que el usuario hace
    sobre una respuesta del agente (comando /feedback N en agent.py).

    Cada entrada en outputs/agent_feedback.jsonl guarda:
    timestamp, query original, respuesta truncada a 200 chars
    (para mantener el archivo compacto), rating 1-5 y comentario.

    El archivo es append-only: store_feedback() solo añade líneas nuevas
    nunca borra ni reescribe. Esto lo hace O(1) y tolerante a fallos.

    get_feedback_stats() calcula rating promedio, mínimo y máximo
    para el comando /datos y para FeedbackAnalyzer.

POR QUÉ ES NECESARIO:
    Sin este módulo, el sistema de feedback loop de agent.py no
    puede persistir las evaluaciones. Cada sesión empezaría sin
    aprendizaje previo.

QUÉ PASA SI SE ELIMINA:
    - El agente pierde capacidad de aprendizaje continuo.
    - Las evaluaciones del usuario no se persisten.
    - agent_orchestrated.py falla al intentar llamar FeedbackStore.
    - agent.py (versión simple) tiene su propio mecanismo de feedback
      inline y no depende de esta clase.

LÓGICA DE NEGOCIO:
    - Formato JSONL: append-only, un registro por línea.
    - Cada entry: timestamp, query, response (truncado), rating, comment.
    - get_feedback_stats(): calcula promedio, min, max de ratings.

FLUJO DE DATOS:
    store_feedback(query, response, rating, comment)
    → dict entry → append a outputs/agent_feedback.jsonl

    get_feedback() → lee JSONL completo → List[Dict]
    get_feedback_stats() → stats agregadas sobre ratings

DEPENDENCIAS CRÍTICAS:
    - outputs/agent_feedback.jsonl (se crea si no existe)
    - json, datetime, pathlib (stdlib)

RIESGOS:
    - Archivo crece indefinidamente: purgar entradas antiguas
      manualmente si el volumen es alto.
    - Sin autenticación: cualquier proceso puede modificar el JSONL.
    - Concurrencia: múltiples agentes paralelos pueden corromper el
      archivo al escribir simultáneamente.

ESCALABILIDAD:
    - Funcional para uso individual (<10K entradas).
    - Para equipos: migrar a SQLite o PostgreSQL.

IMPACTO DE NEGOCIO:
    ALTO. El feedback loop es lo que permite al sistema mejorar
    su calidad sesión a sesión sin re-entrenar el modelo.

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""


"""
====================================================================
ARCHIVO: feedback/feedback_store.py
====================================================================
"""

from typing import Dict, Any, List
import json
import datetime
from pathlib import Path


class FeedbackStore:
    """
    Almacén persistente de retroalimentación del usuario.

    Formato del archivo outputs/agent_feedback.jsonl:
        Una línea JSON por cada feedback recibido.
        Append-only: nunca se sobreescribe, solo se añade.
    """

    def __init__(self, store_path: str = None):
        if store_path is None:
            _root = Path(__file__).resolve().parent.parent.parent.parent
            store_path = _root / "outputs" / "agent_feedback.jsonl"
        self.store_path = Path(store_path)
        self.store_path.parent.mkdir(parents=True, exist_ok=True)

    def store_feedback(self, query: str, response: str, rating: float, comment: str = ""):
        """
        Persiste una evaluación del usuario.

        Args:
            query:    Query original que generó la respuesta evaluada.
            response: Texto de la respuesta del agente (se trunca a 200 chars).
            rating:   Calificación del usuario (1.0 - 5.0).
            comment:  Comentario libre del usuario (vacío por default).
        """
        try:
            rating = round(max(1.0, min(5.0, float(rating))), 2)
        except (ValueError, TypeError):
            rating = 3.0

        feedback = {
            "timestamp": datetime.datetime.now().isoformat(),
            "query":     query,
            "response":  response[:200],
            "rating":    rating,
            "comment":   comment,
        }
        with open(self.store_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(feedback) + "\n")

    def get_feedback(self) -> List[Dict[str, Any]]:
        """
        Carga todo el historial de feedback del archivo JSONL.

        Returns:
            Lista de dicts con timestamp, query, response, rating y comment.
            Lista vacía si no hay historial.
        """
        if not self.store_path.exists():
            return []

        feedback = []
        with open(self.store_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    feedback.append(json.loads(line.strip()))
                except Exception:
                    continue
        return feedback

    def get_feedback_stats(self) -> Dict[str, Any]:
        """
        Calcula estadísticas agregadas del feedback acumulado.

        Returns:
            Dict con total, average_rating, min_rating, max_rating,
            bad_count y good_count.
            Si no hay feedback: {"total": 0, "average_rating": 0.0}.
        """
        feedback = self.get_feedback()
        if not feedback:
            return {"total": 0, "average_rating": 0.0}

        ratings = []
        for f in feedback:
            try:
                ratings.append(float(f["rating"]))
            except (ValueError, TypeError):
                ratings.append(3.0)

        return {
            "total":          len(feedback),
            "average_rating": round(sum(ratings) / len(ratings), 2),
            "min_rating":     min(ratings),
            "max_rating":     max(ratings),
            "bad_count":      sum(1 for r in ratings if r < 3.0),
            "good_count":     sum(1 for r in ratings if r >= 4.0),
        }
