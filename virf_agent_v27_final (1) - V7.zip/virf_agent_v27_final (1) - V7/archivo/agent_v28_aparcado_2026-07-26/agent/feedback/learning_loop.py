"""
====================================================================
ARCHIVO: feedback/learning_loop.py
====================================================================

OBJETIVO:
    Implementar el loop de aprendizaje continuo del agente: analizar
    el feedback acumulado para identificar patrones de error y
    generar correcciones que mejoren las respuestas futuras.

PARA QUÉ SIRVE:
    Proporciona tres clases auxiliares del sistema de mejora continua:
    - LearningLoop: analiza patrones de fallos en el feedback.
    - CorrectionsTracker: registra correcciones realizadas.
    - FeedbackAnalyzer: genera insights y recomendaciones de mejora.


    Cierra el loop de aprendizaje: toma los insights de FeedbackAnalyzer,
    identifica patrones de error y genera texto de lecciones aprendidas
    que se inyecta en el system prompt del agente en la próxima sesión.

    Contiene 3 clases:
    LearningLoop        -> analyze_failures() identifica patrones de error
                            y retorna strings para el system prompt.
    CorrectionsTracker  -> registra correcciones explícitas del usuario
                            ("la respuesta correcta era X, no Y").
    FeedbackAnalyzer    -> DUPLICADO de feedback_analyzer.py (ver nota).

    En agent.py el mecanismo funciona así:
    entries = _load_feedback_entries()          # lee JSONL
    SYSTEM_PROMPT = _build_system_prompt(entries, ...) # incorpora historial
    /recargar reconstruye el system prompt con las lecciones aprendidas.

    Estado actual: analyze_failures() devuelve strings hardcodeados de ejemplo.
    CorrectionsTracker.track_correction() es no-op (pass sin implementación).
    TODO v2: filtrar feedback con rating<3, extraer patrones reales,
    persistir correcciones en LongTermMemory.


POR QUÉ ES NECESARIO:
    Cierra el ciclo de mejora continua del agente. Sin análisis del
    feedback, los errores no se identifican sistemáticamente y el
    agente no puede mejorar más allá del learning del system prompt.

QUÉ PASA SI SE ELIMINA:
    - Se pierde la capacidad de análisis sistemático del feedback.
    - El loop de mejora continua queda incompleto (se sigue guardando
      feedback pero no se analiza).
    - agent_orchestrated.py no importa directamente estas clases,
      por lo que su eliminación no rompe el sistema inmediatamente.

LÓGICA DE NEGOCIO:
    NOTA: Las tres clases están en estado de STUB (implementaciones
    mínimas que retornan datos hardcodeados). Son esqueletos listos
    para implementación real. Esto es deuda técnica identificada.

    LearningLoop.analyze_failures():
        Debería: agrupar preguntas mal valoradas por similitud,
        identificar patrones de error recurrentes.
        Actualmente: retorna lista hardcodeada.

    CorrectionsTracker.track_correction():
        Debería: persistir correcciones para auditoría.
        Actualmente: no hace nada (pass).

    FeedbackAnalyzer.analyze():
        Debería: generar insights accionables a partir del feedback.
        Actualmente: retorna dict vacío.

FLUJO DE DATOS:
    feedback_list → LearningLoop.analyze_failures() → error_patterns
    error_patterns → FeedbackAnalyzer.analyze() → insights + recommendations
    insights → CorrectionsTracker.track_correction() → auditoría

DEPENDENCIAS CRÍTICAS:
    - Solo stdlib Python (logging)
    - Ninguna dependencia externa

RIESGOS:
    - Estado STUB: no aporta valor funcional real actualmente.
    - Si se implementa analyze_failures() con LLM, puede ser costoso
      en tokens si el historial de feedback es grande.

ESCALABILIDAD:
    - Las implementaciones stub son instantáneas (sin procesamiento).
    - Una implementación real con clustering de embeddings podría
      tardar segundos para historial grande.

IMPACTO DE NEGOCIO:
    BAJO (actualmente stub). ALTO si se implementa completamente.

NIVEL DE CRITICIDAD:
    BAJO

NOTAS TÉCNICAS:
    DEUDA TÉCNICA: Las tres clases necesitan implementación real.
    Prioridad de implementación recomendada:
    1. FeedbackAnalyzer: mayor impacto, puede hacerse con regex/pandas.
    2. LearningLoop: requiere clustering o LLM para análisis semántico.
    3. CorrectionsTracker: requiere diseño del esquema de correcciones.

====================================================================
"""

"""
====================================================================
ARCHIVO: feedback/learning_loop.py
====================================================================
"""

from typing import Dict, Any, List
import logging

from .feedback_analyzer import FeedbackAnalyzer

logger = logging.getLogger(__name__)


class LearningLoop:
    """
    Implementa el loop de aprendizaje del agente.

    Consume FeedbackAnalyzer para convertir el historial de feedback
    en strings de lecciones aprendidas listos para inyectar en el
    system prompt del agente.

    Flujo:
        feedback_list = FeedbackStore().get_feedback()
        patterns      = LearningLoop().analyze_failures(feedback_list)
        # patterns → lista de strings para el system prompt
    """

    def __init__(self):
        self._analyzer = FeedbackAnalyzer()

    def analyze_failures(self, feedback: List[Dict]) -> List[str]:
        """
        Identifica patrones de error en el historial de feedback.

        Args:
            feedback: Lista de dicts de FeedbackStore.get_feedback().
                      Cada dict tiene: timestamp, query, response,
                      rating (str o float), comment.

        Returns:
            Lista de strings describiendo patrones de error detectados.
            Estos strings se incorporan directamente al system prompt.
            Lista vacía si no hay feedback o no hay patrones negativos.
        """
        if not feedback:
            return []

        result  = self._analyzer.analyze(feedback)
        pattern_lines = []

        # 1. Recomendaciones directas al system prompt
        for rec in result.get("recommendations", []):
            pattern_lines.append(rec)

        # 2. Tendencia negativa
        if result.get("trend") == "empeorando":
            pattern_lines.append(
                "ALERTA: La calidad de respuestas muestra tendencia negativa. "
                "Ser más cuidadoso con las respuestas recientes."
            )

        # 3. Temas problemáticos como advertencia explícita
        bad_topics = result.get("bad_topics", [])
        if bad_topics:
            pattern_lines.append(
                f"TEMAS PROBLEMÁTICOS: Las consultas sobre "
                f"{', '.join(bad_topics)} han recibido malas calificaciones. "
                f"Verificar datos antes de responder sobre estos temas."
            )

        # 4. Stats como contexto
        stats = result.get("stats", {})
        if stats.get("bad_count", 0) > 0:
            pattern_lines.append(
                f"HISTORIAL: {stats['bad_count']} de {stats['total']} "
                f"interacciones tuvieron calificación negativa "
                f"(promedio: {stats.get('average_rating', 0)}/5)."
            )

        return pattern_lines
