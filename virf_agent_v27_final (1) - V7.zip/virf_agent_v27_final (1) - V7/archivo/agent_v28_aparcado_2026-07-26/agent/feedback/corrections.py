"""
====================================================================
ARCHIVO: feedback/corrections.py
====================================================================

OBJETIVO:
    Registrar correcciones explícitas del usuario sobre respuestas
    incorrectas del agente, y persistirlas en LongTermMemory para
    que el orquestador las inyecte como contexto en queries futuras.

PARA QUÉ SIRVE:
    Cuando el usuario indica que una respuesta estuvo mal
    ("la respuesta correcta era X, no Y"), CorrectionsTracker
    guarda esa corrección de forma persistente. El orquestador
    puede recuperarlas y usarlas para evitar repetir el mismo error.

FLUJO DE DATOS:
    Usuario indica error
    → CorrectionsTracker.track_correction()
    → LongTermMemory.store(category="correction")
    → AgentOrchestrator.register_tool("corrections_context")
    → Contexto enriquecido en el siguiente process_query()

DEPENDENCIAS CRÍTICAS:
    - src/agent/memory/long_term_memory.py : persistencia
    - src/agent/orchestrator/orchestrator.py : inyección de contexto

NIVEL DE CRITICIDAD:
    MEDIO

====================================================================
"""
from typing import Dict, Any, List
import datetime
import logging

logger = logging.getLogger(__name__)


class CorrectionsTracker:
    """
    Registra y recupera correcciones explícitas del usuario.

    Las correcciones se persisten en LongTermMemory con
    category="correction" y se inyectan en el orquestador
    para enriquecer el contexto de queries futuras.

    Uso:
        tracker = CorrectionsTracker(long_term_memory, orchestrator)
        tracker.track_correction(
            original  = "El AUC es 0.92",
            corrected = "El AUC real es 0.847",
            reason    = "El agente citó un valor incorrecto",
            query     = "¿Cuál es el AUC del modelo?"
        )
    """

    def __init__(self, long_term_memory=None, orchestrator=None):
        """
        Args:
            long_term_memory: Instancia de LongTermMemory para persistencia.
            orchestrator:     Instancia de AgentOrchestrator para inyección
                              de correcciones como tool disponible.
        """
        self._memory               = long_term_memory
        self._orchestrator         = orchestrator
        self._session_corrections: List[Dict[str, Any]] = []

    def track_correction(
        self,
        original:  str,
        corrected: str,
        reason:    str,
        query:     str = "",
    ) -> None:
        """
        Registra una corrección explícita del usuario.

        Args:
            original:  Respuesta incorrecta que dio el agente.
            corrected: Respuesta correcta según el usuario.
            reason:    Explicación de por qué la original estaba mal.
            query:     Query original que generó la respuesta incorrecta.

        Efectos:
            1. Guarda en _session_corrections (memoria de sesión)
            2. Persiste en LongTermMemory si está disponible
            3. Inyecta en orquestador como tool "corrections_context"
        """

        if not original.strip() or not corrected.strip():
            logger.debug("track_correction ignorada: original o corrected vacíos")
            return

        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "query":     query,
            "original":  original,
            "corrected": corrected,
            "reason":    reason,
        }

        # 1. Memoria de sesión
        self._session_corrections.append(entry)
        logger.info("Corrección registrada en sesión")

        # 2. Persistencia en LongTermMemory
        if self._memory is not None:
            try:
                key = f"correction_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S%f')}"
                self._memory.store(
                    key=key,
                    value=entry,
                    category="correction",
                )
                logger.info(f"Corrección persistida en LongTermMemory: {key}")
            except Exception as e:
                logger.warning(f"No se pudo persistir corrección: {e}")

        # 3. Inyectar en orquestador como contexto disponible
        if self._orchestrator is not None:
            try:
                self._orchestrator.register_tool(
                    "corrections_context",
                    {"context": self._build_corrections_context()},
                )

                logger.info("Correcciones inyectadas en el orquestador")
            except Exception as e:
                logger.warning(f"No se pudo inyectar en orquestador: {e}")

    def get_session_corrections(self) -> List[Dict[str, Any]]:
        """Retorna las correcciones registradas en la sesión actual."""
        return self._session_corrections.copy()

    def get_all_corrections(self) -> List[Dict[str, Any]]:
        """Recupera todas las correcciones persistidas en LongTermMemory."""
        if self._memory is None:
            return self._session_corrections.copy()
        try:
            persisted = self._memory.retrieve_by_category("correction") or []
            persisted_values = [item.get("value", item) for item in persisted]
            # Combinar persistidas + sesión actual sin duplicar
            persisted_keys = {c["timestamp"] for c in persisted_values}
            session_only = [
                c for c in self._session_corrections
                if c["timestamp"] not in persisted_keys
            ]
            return persisted_values + session_only
        except Exception as e:
            logger.warning(f"No se pudieron recuperar correcciones: {e}")
            return self._session_corrections.copy()

    def _build_corrections_context(self) -> str:
        """
        Formatea las últimas 5 correcciones como string
        para inyectar en el orquestador como tool corrections_context.
        """
        if not self._session_corrections:
            return ""
        lines = ["CORRECCIONES DEL USUARIO (evitar repetir estos errores):"]
        for c in self._session_corrections[-5:]:
            lines.append(
                f"- Query: '{c['query']}' | "
                f"Error: '{c['original'][:80]}' | "
                f"Correcto: '{c['corrected'][:80]}'"
            )
        return "\n".join(lines)

    def has_corrections(self) -> bool:
        """Retorna True si hay al menos una corrección en la sesión."""
        return len(self._session_corrections) > 0
