"""
====================================================================
ARCHIVO: context_engineering/compression.py
====================================================================

OBJETIVO:
    Componente de Context Engineering del agente.
    Comprime el contexto del agente eliminando información redundante
    o de baja relevancia para reducir el consumo de tokens del LLM sin 
    perder información crítica.

PARA QUÉ SIRVE:
    Es parte del subsistema de Context Engineering que gestiona
    la calidad y relevancia del contexto inyectado en el LLM.
    Un contexto bien construido mejora significativamente la
    calidad de las respuestas del agente.

POR QUÉ ES NECESARIO:
    Los LLMs tienen un límite de tokens de contexto. Sin gestión
    del contexto, respuestas largas o conversaciones extendidas
    pueden exceder el límite, truncando información crítica.

QUÉ PASA SI SE ELIMINA:
    - El Context Engineering pierde una dimensión de optimización.
    - El agente puede incluir contexto irrelevante o excesivo.
    - Las respuestas pueden degradarse en conversaciones largas.
    - El sistema principal (agent.py) no usa estas clases directamente
      por lo que el impacto inmediato es bajo.

LÓGICA DE NEGOCIO:
    Todas las clases de context_engineering/ trabajan sobre el
    contexto del agente (historial, documentos RAG, resultados de
    tools) para optimizarlo antes de enviarlo al LLM.

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python (typing, dataclasses).

NIVEL DE CRITICIDAD:
    BAJO (optimización, no funcionalidad core)

NOTAS TÉCNICAS:
    El módulo context_engineering/ es un sistema de optimización
    complementario. El agente funciona sin él pero con contextos
    subóptimos en sesiones largas.

====================================================================
"""
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class ContextCompressor:

    def __init__(self, max_tokens: int = 2000):
        self.max_tokens = max_tokens
        self.max_chars  = max_tokens * 4  # ~4 chars por token

    def compress(self, context: Dict[str, Any]) -> Dict[str, Any]:
        compressed = {}
        for key, value in context.items():
            if isinstance(value, str) and len(value) > 500:
                compressed[key] = value[:500] + " [... truncado]"
                logger.debug(f"Comprimido '{key}': {len(value)} → 500 chars")
            elif isinstance(value, list) and len(value) > 5:
                compressed[key] = value[:5]
                logger.debug(f"Comprimido '{key}': {len(value)} → 5 items")
            else:
                compressed[key] = value
        return compressed

    def estimate_tokens(self, text: str) -> int:
        return max(1, len(text) // 4)

    def estimate_chars(
        self,
        context: Dict[str, Any],
        history: List[Dict[str, Any]],
    ) -> int:
        """
        Estima el total de caracteres de context + history.
        Compatible con la llamada en agent_orchestrated.py.
        """
        ctx_chars  = sum(len(str(v)) for v in context.values())
        hist_chars = sum(len(str(h.get("value", h))) for h in history)
        return ctx_chars + hist_chars

    def compress_if_needed(
        self,
        context: Dict[str, Any],
        history: List[Dict[str, Any]],
        query: str = "",
    ) -> tuple:
        """
        Comprime si el total de chars supera max_chars.
        Compatible con la llamada en agent_orchestrated.py.
        """
        total = self.estimate_chars(context, history)
        if total <= self.max_chars:
            return context, history

        logger.info(f"Compresión activada: {total} chars > {self.max_chars}")
        context = self.compress(context)
        return context, history

    def should_compress(self, context: Dict[str, Any]) -> bool:
        total_text = " ".join(str(v) for v in context.values())
        estimated  = self.estimate_tokens(total_text)
        if estimated > self.max_tokens:
            logger.info(f"Compresión necesaria: ~{estimated} tokens (límite: {self.max_tokens})")
            return True
        return False

