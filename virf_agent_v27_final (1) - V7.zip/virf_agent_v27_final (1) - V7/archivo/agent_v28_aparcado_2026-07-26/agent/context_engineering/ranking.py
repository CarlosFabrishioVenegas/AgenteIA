"""
====================================================================
ARCHIVO: context_engineering/ranking.py
====================================================================

OBJETIVO:
    Componente de Context Engineering del agente.
    Rankea fragmentos de texto por relevancia semántica o heurística para determinar cuáles 
    incluir en el contexto del LLM cuando hay espacio limitado de tokens.

PARA QUÉ SIRVE:
    Es parte del subsistema de Context Engineering que gestiona
    la calidad y relevancia del contexto inyectado en el LLM.
    Un contexto bien construido mejora significativamente la
    calidad de las respuestas del agente.
    Ordena una lista de items de contexto por relevancia a la query actual,
    usando ContextPrioritizer como función de scoring.

    Contiene ContextRanker con 1 método:
    rank(items, query) -> ordena items de mayor a menor score.
        Usa ContextPrioritizer.get_priority_score() para puntuar cada item.
        Retorna la lista reordenada. Si items o query están vacíos, retorna
        la lista sin modificar.

    Es el coordinador final del pipeline de context engineering:
    filter() -> rank() -> compress() -> enviar al LLM
    (filtra duplicados, luego ordena por relevancia, luego comprime si es grande)

    El __init__.py del módulo exporta ContextRanker como la clase principal
    de context_engineering/ porque es el coordinador del pipeline completo.

POR QUÉ ES NECESARIO:
    Los LLMs tienen un límite de tokens de contexto. Sin gestión
    del contexto, respuestas largas o conversaciones extendidas
    pueden exceder el límite, truncando información crítica.

QUÉ PASA SI SE ELIMINA:
    - El Context Engineering pierde una dimensión de optimización.
    - El agente puede incluir contexto irrelevante o excesivo.
    - Las respuestas pueden degradarse en conversaciones largas.
    - El sistema principal (agent.py) no usa estas clases directamente
      por lo que el impacto inmediato es bajo.

LÓGICA DE NEGOCIO:
    Todas las clases de context_engineering/ trabajan sobre el
    contexto del agente (historial, documentos RAG, resultados de
    tools) para optimizarlo antes de enviarlo al LLM.

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python (typing, dataclasses).

NIVEL DE CRITICIDAD:
    BAJO (optimización, no funcionalidad core)

NOTAS TÉCNICAS:
    El módulo context_engineering/ es un sistema de optimización
    complementario. El agente funciona sin él pero con contextos
    subóptimos en sesiones largas.

====================================================================
"""

import logging
from typing import List, Dict, Any

from .prioritization import ContextPrioritizer

logger = logging.getLogger(__name__)


class ContextRanker:
    """
    Ordena items de contexto por relevancia a la query.

    Uso:
        ranker = ContextRanker()
        ranked = ranker.rank(items, query="qué variables predicen mejor?")
        # → items ordenados de más a menos relevante
    """

    def __init__(self):
        self._prioritizer = ContextPrioritizer()

    def rank(self, items: List[Dict[str, Any]], query: str) -> List[Dict[str, Any]]:
        """
        Ordena items por relevancia a la query.

        Estrategia actual: keyword-based scoring via ContextPrioritizer.

        TODO (v2): reemplazar scoring con embedding similarity.

        Args:
            items: Lista de dicts de contexto a ordenar.
            query: Query del usuario.

        Returns:
            Lista ordenada de mayor a menor relevancia.
        """
        if not items or not query:
            return items

        scored = [
            (item, self._prioritizer.get_priority_score(item, query))
            for item in items
        ]
        ranked = sorted(scored, key=lambda x: x[1], reverse=True)
        logger.debug(
            f"ContextRanker: {len(items)} items rankeados. "
            f"Top score: {ranked[0][1]:.3f}" if ranked else ""
        )
        return [item for item, _ in ranked]

