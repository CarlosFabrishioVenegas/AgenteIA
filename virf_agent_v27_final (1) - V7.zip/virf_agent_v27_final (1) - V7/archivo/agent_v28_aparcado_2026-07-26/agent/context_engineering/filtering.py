"""
====================================================================
ARCHIVO: context_engineering/filtering.py
====================================================================

OBJETIVO:
    Componente de Context Engineering del agente.
    Filtra elementos del contexto que no son relevantes para la query 
    actual. Evita que el LLM procese contexto irrelevante que podría 
    afectar la calidad de la respuesta.

PARA QUÉ SIRVE:
    Es parte del subsistema de Context Engineering que gestiona
    la calidad y relevancia del contexto inyectado en el LLM.
    Un contexto bien construido mejora significativamente la
    calidad de las respuestas del agente.

POR QUÉ ES NECESARIO:
    Los LLMs tienen un límite de tokens de contexto. Sin gestión
    del contexto, respuestas largas o conversaciones extendidas
    pueden exceder el límite, truncando información crítica.

QUÉ PASA SI SE ELIMINA:
    - El Context Engineering pierde una dimensión de optimización.
    - El agente puede incluir contexto irrelevante o excesivo.
    - Las respuestas pueden degradarse en conversaciones largas.
    - El sistema principal (agent.py) no usa estas clases directamente
      por lo que el impacto inmediato es bajo.

LÓGICA DE NEGOCIO:
    Todas las clases de context_engineering/ trabajan sobre el
    contexto del agente (historial, documentos RAG, resultados de
    tools) para optimizarlo antes de enviarlo al LLM.

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python (typing, dataclasses).

NIVEL DE CRITICIDAD:
    BAJO (optimización, no funcionalidad core)

NOTAS TÉCNICAS:
    El módulo context_engineering/ es un sistema de optimización
    complementario. El agente funciona sin él pero con contextos
    subóptimos en sesiones largas.

====================================================================
"""
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class ContextFilter:
    """
    Filtra contexto irrelevante para optimizar tokens y calidad de respuesta.

    Uso:
        cf = ContextFilter()
        context = cf.filter(context, query)
        items = cf.remove_duplicates(items)
    """

    def filter(self, context: Dict[str, Any], query: str) -> Dict[str, Any]:
        """
        Filtra items irrelevantes del contexto para la query actual.

        Implementación actual: pasa el contexto sin modificar.

        TODO (v2): implementar filtrado por relevancia semántica.
            score_fn = lambda item: cosine_sim(embed(query), embed(str(item)))
            return {k: v for k, v in context.items() if score_fn(v) > 0.3}

        Args:
            context: Dict con el contexto del agente.
            query:   Query actual del usuario (para filtrado semántico futuro).

        Returns:
            Contexto filtrado (actualmente sin cambios).
        """
        # TODO (v2): filtrado semántico por relevancia a query
        return context

    def remove_duplicates(self, items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Elimina items duplicados de una lista de dicts.

        Estrategia: hash por repr string. Dos items con el mismo contenido
        se consideran duplicados (conserva el primero).

        Args:
            items: Lista de dicts a deduplicar.

        Returns:
            Lista sin duplicados, preservando el orden original.
        """
        seen: set = set()
        unique: List[Dict[str, Any]] = []
        for item in items:
            key = repr(sorted(item.items()) if isinstance(item, dict) else item)
            if key not in seen:
                seen.add(key)
                unique.append(item)
        removed = len(items) - len(unique)
        if removed > 0:
            logger.debug(f"remove_duplicates: {removed} duplicados eliminados")
        return unique

