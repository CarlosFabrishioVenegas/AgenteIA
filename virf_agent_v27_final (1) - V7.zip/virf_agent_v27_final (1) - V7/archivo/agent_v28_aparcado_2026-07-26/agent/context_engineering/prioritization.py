"""
====================================================================
ARCHIVO: context_engineering/prioritization.py
====================================================================

OBJETIVO:
    Componente de Context Engineering del agente.
    Prioriza los elementos del contexto por relevancia para la query. 
    Los elementos más relevantes se colocan primero en el prompt para 
    aprovechar el 'recency bias' de los LLMs.

PARA QUÉ SIRVE:
    Es parte del subsistema de Context Engineering que gestiona
    la calidad y relevancia del contexto inyectado en el LLM.
    Un contexto bien construido mejora significativamente la
    calidad de las respuestas del agente.
    Calcula un score de relevancia para cada item del contexto respecto
    a la query actual. Es la función de scoring que usa ContextRanker
    para ordenar los items antes de enviarlos al LLM.

    Contiene ContextPrioritizer con 2 métodos:
  get_priority_score(item, query) -> score 0-1 basado en keyword
    matching por dominio. Detecta el dominio de la query (ml, data, rag)
    y cuenta cuántos keywords de ese dominio aparecen en el item.
    Score = item_hits / len(domain_keywords).
  prioritize(context, query)      -> reordena el dict de contexto por
    score descendente. Estado actual: pasa sin modificar.
    TODO v2: ordenar keys por get_priority_score().

Dominios definidos:
  ml   -> modelo, auc, f1, shap, xgboost, threshold, recall, precision
  data -> cliente, compra, ventas, cluster, segmento, decil
  rag  -> paper, documento, estudio, investigación, pdf

Por qué priorizar:
  Los LLMs exhiben "lost in the middle" — atienden mejor el inicio
  y el final del contexto. Poner los items más relevantes primero
  mejora la calidad de respuesta sin cambiar el volumen de datos.


POR QUÉ ES NECESARIO:
    Los LLMs tienen un límite de tokens de contexto. Sin gestión
    del contexto, respuestas largas o conversaciones extendidas
    pueden exceder el límite, truncando información crítica.

QUÉ PASA SI SE ELIMINA:
    - El Context Engineering pierde una dimensión de optimización.
    - El agente puede incluir contexto irrelevante o excesivo.
    - Las respuestas pueden degradarse en conversaciones largas.
    - El sistema principal (agent.py) no usa estas clases directamente
      por lo que el impacto inmediato es bajo.

LÓGICA DE NEGOCIO:
    Todas las clases de context_engineering/ trabajan sobre el
    contexto del agente (historial, documentos RAG, resultados de
    tools) para optimizarlo antes de enviarlo al LLM.

DEPENDENCIAS CRÍTICAS:
    Solo stdlib Python (typing, dataclasses).

NIVEL DE CRITICIDAD:
    BAJO (optimización, no funcionalidad core)

NOTAS TÉCNICAS:
    El módulo context_engineering/ es un sistema de optimización
    complementario. El agente funciona sin él pero con contextos
    subóptimos en sesiones largas.

====================================================================
"""

import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

# Keywords por dominio para scoring básico
DOMAIN_KEYWORDS = {
    "ml": ["modelo", "auc", "f1", "shap", "xgboost", "threshold", "recall", "precision"],
    "data": ["cliente", "compra", "ventas", "cluster", "segmento", "decil"],
    "rag": ["paper", "documento", "estudio", "investigación", "pdf"],
}


class ContextPrioritizer:
    """
    Prioriza items de contexto para maximizar calidad de respuesta del LLM.

    Uso:
        p = ContextPrioritizer()
        prioritized = p.prioritize(context, query)
        top_items = sorted(items, key=lambda x: p.get_priority_score(x, query), reverse=True)
    """

    def prioritize(self, context: Dict[str, Any], query: str) -> Dict[str, Any]:
        """
        Reordena el contexto priorizando items más relevantes a la query.

        Implementación actual: pasa sin modificar.

        TODO (v2): reordenar keys del dict por score descendente.

        Args:
            context: Dict con items de contexto.
            query:   Query actual del usuario.

        Returns:
            Contexto (re)ordenado por relevancia.
        """
        # TODO (v2): ordenar por get_priority_score()
        return context

    def get_priority_score(self, item: Dict[str, Any], query: str) -> float:
        """
        Calcula score de prioridad para un item de contexto.

        Estrategia actual:
            Cuenta cuántas keywords del dominio correcto aparecen
            tanto en el item como en la query. Score en [0, 1].

        Args:
            item:  Item de contexto (cualquier dict).
            query: Query del usuario.

        Returns:
            Float en [0, 1]. Mayor = más prioritario.

        TODO (v2): reemplazar por cosine_similarity(embed(query), embed(item)).
        """
        query_lower = query.lower()
        item_str = str(item).lower()

        # Detectar dominio de la query
        domain_hits = {
            domain: sum(1 for kw in kws if kw in query_lower)
            for domain, kws in DOMAIN_KEYWORDS.items()
        }
        active_domain = max(domain_hits, key=domain_hits.get)

        # Contar matches del dominio activo en el item
        domain_kws = DOMAIN_KEYWORDS[active_domain]
        item_hits = sum(1 for kw in domain_kws if kw in item_str)

        # Normalizar: max posible = len(domain_kws)
        score = min(1.0, item_hits / max(1, len(domain_kws)))
        return round(score, 3)

