"""
virf_agent.py
=============
Interfaz unificada para el agente de validación VIRF.

Proporciona la clase VIRFAgent que actúa como conexión entre:
- virf_agente.py (punto de entrada)
- virf_agent_v28.py (lógica MRM)
- Evaluadores estáticos (FormulaDetector, MethodologyChecker)
- Skill consolidador (generación de informes)

USO:
    from agent.virf_agent import VIRFAgent
    
    agente = VIRFAgent(titulo_modelo="Modelo LaR v3", dominio="LaR")
    agente.run()           # Conversación interactiva
    agente.validar()       # Informe consolidado
"""

import sys
import logging
import datetime
import json
from pathlib import Path
from typing import Optional, Dict, List, Any

# Configurar logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("VIRFAgent")

# ═════════════════════════════════════════════════════════════════════════════
# CLASE VIRF AGENT
# ═════════════════════════════════════════════════════════════════════════════

class VIRFAgent:
    """
    Agente unificado para validación de modelos financieros.
    
    Soporta:
    - Detección estática de fórmulas (sin LLM)
    - Validación metodológica (sin LLM)
    - Conversación interactiva con LLM
    - Generación de informe ejecutivo
    - Exportación a Word
    """
    
    def __init__(self, titulo_modelo: str = "", dominio: str = "auto"):
        """
        Inicializa el agente VIRF.
        
        Args:
            titulo_modelo: Nombre del modelo bajo validación
            dominio: 'auto', 'LaR', 'VaR', 'conductuales', 'shared'
        """
        self.titulo_modelo = titulo_modelo
        self.dominio = dominio
        self.hallazgos: List[Dict[str, Any]] = []
        
        self.session_data = {
            "start_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
            "query_count": 0,
            "total_findings": 0,
            "titulo_modelo": titulo_modelo,
            "dominio": dominio,
        }
        
        # Importar evaluadores estáticos (siempre disponibles)
        try:
            from agent.evaluators.formula_detector import FormulaDetector
            from agent.evaluators.methodology_checker import MethodologyChecker
            
            self.formula_detector = FormulaDetector()
            self.methodology_checker = MethodologyChecker()
            self._evaluadores_ready = True
            logger.info("✓ Evaluadores estáticos cargados (sin LLM)")
        except ImportError as e:
            logger.warning(f"⚠️  Evaluadores estáticos no disponibles: {e}")
            self._evaluadores_ready = False
        
        logger.info(
            f"VIRFAgent inicializado: modelo='{titulo_modelo}', dominio='{dominio}'"
        )
    
    def _registrar_hallazgo(self, hallazgo: Dict[str, Any]):
        """Registra un hallazgo acumulado."""
        if "timestamp" not in hallazgo:
            hallazgo["timestamp"] = datetime.datetime.now().isoformat()
        self.hallazgos.append(hallazgo)
        self.session_data["total_findings"] += 1
        logger.info(
            f"Hallazgo [{hallazgo.get('gravedad')}]: {hallazgo.get('descripcion', '')[:60]}"
        )
    
    def analizar_formula(self, formula: str) -> List[Dict[str, Any]]:
        """Analiza una fórmula con detección estática (sin LLM)."""
        if not self._evaluadores_ready:
            logger.error("Evaluadores no disponibles")
            return []
        
        hallazgos = self.formula_detector.analizar(formula)
        for h in hallazgos:
            self._registrar_hallazgo(h)
        return hallazgos
    
    def analizar_metodologia(self, texto: str) -> Dict[str, Any]:
        """Analiza la metodología con validación estática (sin LLM)."""
        if not self._evaluadores_ready:
            logger.error("Evaluadores no disponibles")
            return {}
        
        resultado = self.methodology_checker.verificar(texto)
        hallazgos = resultado.get("hallazgos", [])
        for h in hallazgos:
            self._registrar_hallazgo(h)
        return resultado
    
    def run(self):
        """
        Inicia sesión conversacional interactiva.
        Combina detección estática + Chat simulado.
        """
        print("\n" + "="*70)
        print("VIRF AGENT — Validador de Modelos Financieros")
        print("="*70)
        print(f"Modelo: {self.titulo_modelo or 'Sin nombre'}")
        print(f"Dominio: {self.dominio}")
        print("\nComandos: /ayuda  /hallazgos  /validar  /limpiar  /salir")
        print("="*70 + "\n")
        
        self._run_loop()
    
    def _run_loop(self):
        """Loop principal de conversación."""
        while True:
            try:
                user_input = input("VIRF> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n[Sesión terminada]")
                break
            
            if not user_input:
                continue
            
            # Procesar comandos especiales
            if user_input.startswith("/"):
                response = self._handle_command(user_input)
                if response:
                    print(response)
                if user_input.lower() in ("/salir", "/exit", "/quit"):
                    break
                continue
            
            # Procesar queries normales
            self._process_query(user_input)
    
    def _process_query(self, user_input: str):
        """Procesa una query de usuario."""
        self.session_data["query_count"] += 1
        logger.info(f"Query #{self.session_data['query_count']}: {user_input[:80]}")
        
        # Detectar si es pregunta sobre fórmula
        if any(kw in user_input.lower() for kw in ["fórmula", "formula", "ecuación", "var", "lar", "=", "σ", "μ"]):
            hallazgos = self.analizar_formula(user_input)
            if hallazgos:
                print("\n" + "-"*60)
                print("[Detección de fórmula]")
                for h in hallazgos:
                    print(f"\n⚠️  [{h['gravedad']}] {h['descripcion'][:120]}")
                    if h.get('correccion'):
                        print(f"✓ Corrección: {h['correccion']}")
                print("-"*60 + "\n")
                return
        
        # Detectar si es pregunta sobre metodología
        if any(kw in user_input.lower() for kw in ["metodología", "backtesting", "calibración", "supuesto", "asunción"]):
            resultado = self.analizar_metodologia(user_input)
            hallazgos = resultado.get("hallazgos", [])
            if hallazgos:
                print("\n" + "-"*60)
                print("[Validación metodológica]")
                for h in hallazgos:
                    print(f"\n⚠️  [{h['gravedad']}] {h['descripcion'][:120]}")
                print("-"*60 + "\n")
                return
        
        # Respuesta genérica
        print("\n" + "-"*60)
        print("ℹ️  Consejo: intenta preguntar sobre:")
        print("   • Fórmulas: 'VaR = μ + σ * 1.645'")
        print("   • Metodología: 'Usamos correlación = 1'")
        print("   • O usa: /ayuda")
        print("-"*60 + "\n")
    
    def _handle_command(self, cmd: str) -> str:
        """Procesa comandos especiales."""
        cmd_lower = cmd.strip().lower()
        
        if cmd_lower == "/ayuda":
            return """
COMANDOS DISPONIBLES:
  /ayuda          — muestra este mensaje
  /hallazgos      — lista hallazgos acumulados (por gravedad)
  /validar        — genera informe consolidado (JSON + resumen)
  /challenger     — genera Jupyter Notebook con modelo mejorado
  /titulo <name>  — cambia modelo bajo validación
  /dominio <dom>  — cambia dominio (LaR|VaR|conductuales|shared|auto)
  /limpiar        — reinicia sesión (conserva hallazgos)
  /reset          — reinicia todo (borra hallazgos)
  /salir          — cierra sesión

FLUJO RECOMENDADO:
  1. /titulo "Mi Modelo LaR"
  2. /dominio LaR
  3. Haz preguntas sobre el modelo
  4. /hallazgos (ver problemas detectados)
  5. /validar (generar informe)
  6. /challenger (generar modelo mejorado)

EJEMPLOS DE PREGUNTAS:
  • "¿Esta fórmula es correcta? VaR = μ + σ * 1.645"
  • "Usamos volatilidad * 252 para anualizar"
  • "Backtesting con solo 10 observaciones"
"""
        
        if cmd_lower == "/hallazgos":
            return self._mostrar_hallazgos()
        
        if cmd_lower == "/validar":
            return self.validar()
        
        if cmd_lower == "/challenger":
            self.generar_challenger()
            return "✓ Notebook Challenger generado en carpeta outputs/challenger/"
        
        if cmd_lower == "/limpiar":
            self.session_data["query_count"] = 0
            return "✓ Memoria de sesión limpiada (hallazgos conservados)."
        
        if cmd_lower == "/reset":
            self.hallazgos = []
            self.session_data["total_findings"] = 0
            return "✓ Todo reiniciado. Sesión limpia."
        
        if cmd_lower.startswith("/titulo "):
            nuevo_titulo = cmd[8:].strip()
            self.titulo_modelo = nuevo_titulo
            self.session_data["titulo_modelo"] = nuevo_titulo
            return f"✓ Modelo: '{nuevo_titulo}'"
        
        if cmd_lower.startswith("/dominio "):
            nuevo_dominio = cmd[9:].strip()
            if nuevo_dominio in ["LaR", "VaR", "conductuales", "shared", "auto"]:
                self.dominio = nuevo_dominio
                self.session_data["dominio"] = nuevo_dominio
                return f"✓ Dominio: {nuevo_dominio}"
            return "✗ Dominio no válido. Opciones: LaR, VaR, conductuales, shared, auto"
        
        return ""
    
    def _mostrar_hallazgos(self) -> str:
        """Muestra hallazgos acumulados organizados por gravedad."""
        if not self.hallazgos:
            return "\n📋 Sin hallazgos registrados aún.\n"
        
        # Agrupar por gravedad
        por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
        for h in self.hallazgos:
            g = h.get("gravedad", "BAJO")
            por_gravedad.get(g, por_gravedad["MEDIO"]).append(h)
        
        lines = [f"\n📋 HALLAZGOS ({len(self.hallazgos)} total)\n"]
        
        for gravedad in ["CRÍTICO", "ALTO", "MEDIO", "BAJO"]:
            items = por_gravedad[gravedad]
            if items:
                lines.append(f"  {gravedad} ({len(items)})")
                for i, h in enumerate(items, 1):
                    lines.append(f"    {i}. {h.get('descripcion', 'N/A')[:80]}...")
                    if h.get("correccion"):
                        lines.append(f"       → {h['correccion'][:60]}...")
                lines.append("")
        
        return "\n".join(lines)
    
    def validar(self) -> str:
        """
        Genera informe consolidado con todos los hallazgos.
        """
        if not self.hallazgos:
            return "\n⚠️  No hay hallazgos. Inicia una sesión de validación primero.\n"
        
        # Crear informe básico (sin LLM)
        informe = self._generar_informe_basico()
        
        # Guardar JSON
        self._guardar_hallazgos_json()
        
        # Intentar exportar a Word
        ruta_word = self.exportar_word()
        if ruta_word:
            informe += f"\n✅ Informe Word: {ruta_word}\n"
        
        return informe
    
    def _generar_informe_basico(self) -> str:
        """Genera informe ejecutivo sin LLM."""
        # Agrupar por gravedad
        por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
        for h in self.hallazgos:
            g = h.get("gravedad", "BAJO")
            por_gravedad.get(g, por_gravedad["MEDIO"]).append(h)
        
        criticos = por_gravedad["CRÍTICO"]
        altos = por_gravedad["ALTO"]
        medios = por_gravedad["MEDIO"]
        bajos = por_gravedad["BAJO"]
        
        # Determinar veredicto
        if criticos:
            veredicto = "❌ NO APTO PARA USO EN GESTIÓN"
        elif altos:
            veredicto = "⚠️  APTO CON CONDICIONES"
        else:
            veredicto = "✅ APTO"
        
        lineas = [
            "\n" + "="*70,
            f"INFORME DE VALIDACIÓN — {self.titulo_modelo or 'Sin modelo'}",
            "="*70,
            f"Fecha: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"Dominio: {self.dominio}",
            f"Total hallazgos: {len(self.hallazgos)}",
            "",
        ]
        
        if criticos:
            lineas.append(f"CRÍTICOS ({len(criticos)})")
            for h in criticos:
                lineas.append(f"  • {h['descripcion'][:70]}...")
                if h.get("referencia"):
                    lineas.append(f"    Ref: {h['referencia']}")
            lineas.append("")
        
        if altos:
            lineas.append(f"ALTOS ({len(altos)})")
            for h in altos[:3]:  # Mostrar solo los primeros 3
                lineas.append(f"  • {h['descripcion'][:70]}...")
            if len(altos) > 3:
                lineas.append(f"  ... y {len(altos)-3} más")
            lineas.append("")
        
        lineas += [
            f"VEREDICTO: {veredicto}",
            "="*70 + "\n",
        ]
        
        return "\n".join(lineas)
    
    def _guardar_hallazgos_json(self):
        """Guarda hallazgos en JSON para auditoría."""
        try:
            outputs_dir = Path("outputs")
            outputs_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = outputs_dir / f"hallazgos_{self.titulo_modelo}_{timestamp}.json"
            
            datos = {
                "titulo_modelo": self.titulo_modelo,
                "dominio": self.dominio,
                "fecha": datetime.datetime.now().isoformat(),
                "total_hallazgos": len(self.hallazgos),
                "hallazgos": self.hallazgos,
            }
            
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(datos, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Hallazgos guardados: {filename}")
            
        except Exception as e:
            logger.error(f"Error guardando JSON: {e}")
    
    def exportar_word(self) -> Optional[str]:
        """Exporta hallazgos a Word si está disponible python-docx."""
        try:
            from docx import Document
            
            doc = Document()
            doc.add_heading(f"Informe de Validación — {self.titulo_modelo}", level=1)
            doc.add_paragraph(f"Fecha: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}")
            doc.add_paragraph(f"Dominio: {self.dominio}")
            
            # Agrupar por gravedad
            por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
            for h in self.hallazgos:
                g = h.get("gravedad", "BAJO")
                por_gravedad.get(g, por_gravedad["MEDIO"]).append(h)
            
            for gravedad in ["CRÍTICO", "ALTO", "MEDIO", "BAJO"]:
                items = por_gravedad[gravedad]
                if items:
                    doc.add_heading(f"{gravedad} ({len(items)})", level=2)
                    for h in items:
                        p = doc.add_paragraph(h['descripcion'], style='List Bullet')
                        if h.get("correccion"):
                            doc.add_paragraph(f"Corrección: {h['correccion']}", style='List Bullet 2')
            
            # Guardar
            outputs_dir = Path("outputs")
            outputs_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            ruta_word = outputs_dir / f"validacion_{self.titulo_modelo}_{timestamp}.docx"
            
            doc.save(ruta_word)
            logger.info(f"Word generado: {ruta_word}")
            return str(ruta_word)
            
        except ImportError:
            logger.warning("python-docx no instalado. Salta exportación a Word.")
            return None
        except Exception as e:
            logger.error(f"Error exportando Word: {e}")
            return None
    
    def generar_challenger(self) -> Optional[str]:
        """
        Genera un Jupyter Notebook con un modelo Challenger mejorado
        basado en los hallazgos acumulados + RAG.
        
        El Challenger incorpora:
        - Fórmulas corregidas
        - Supuestos validados
        - Tests estadísticos
        - Backtesting
        - Comparación visual
        - Referencias del RAG (papers, mejores prácticas)
        - Recomendaciones basadas en documentación
        
        Returns:
            Ruta al notebook generado (o HTML si nbformat no está disponible)
        """
        if not self.hallazgos:
            logger.warning("No hay hallazgos. Genere validación primero con /validar")
            return None
        
        try:
            # Usar versión mejorada con RAG
            from agent.skills.challenger_generator_v2_con_rag import generar_challenger_con_rag_desde_hallazgos
            
            # Intentar obtener RAG retriever si está disponible
            rag_retriever = None
            try:
                rag_retriever = self._get_rag_retriever()
            except Exception:
                logger.warning("RAG no disponible, generando sin referencias documentales")
            
            # Intentar obtener reasoning chain si está disponible
            agent_reasoning = None
            try:
                from agent.reasoning.chain_of_thought import ChainOfThought
                agent_reasoning = ChainOfThought()
            except Exception:
                pass
            
            ruta = generar_challenger_con_rag_desde_hallazgos(
                titulo_modelo=self.titulo_modelo,
                dominio=self.dominio,
                hallazgos=self.hallazgos,
                rag_retriever=rag_retriever,
                agent_reasoning=agent_reasoning
            )
            
            if ruta:
                print(f"\n✅ Challenger Model generado exitosamente")
                print(f"   Ubicación: {ruta}")
                print(f"   Tipo: {'Jupyter Notebook (.ipynb)' if ruta.endswith('.ipynb') else 'HTML'}")
                print(f"   Dominio: {self.dominio}")
                print(f"   Hallazgos integrados: {len(self.hallazgos)}")
                print(f"   💡 Incluye referencias del RAG y análisis profundo")
                return ruta
            
            return None
            
        except ImportError as e:
            logger.error(f"No se pudo importar ChallengerGenerator: {e}")
            return None
        except Exception as e:
            logger.error(f"Error generando Challenger: {e}")
            import traceback
            traceback.print_exc()
            return None
