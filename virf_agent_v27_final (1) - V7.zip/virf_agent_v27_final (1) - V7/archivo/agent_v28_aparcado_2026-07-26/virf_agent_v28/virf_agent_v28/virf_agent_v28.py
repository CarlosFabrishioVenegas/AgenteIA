"""
====================================================================
ARCHIVO: virf_agent_v28.py
====================================================================

AGENTE: VIRF_AGENT_V28 — Model Risk Management & Audit Platform
VERSIÓN: 28
DOMINIO: Validación de modelos financieros, auditoría cuantitativa,
         MRM, cumplimiento metodológico, challenger models,
         revisión crítica de código, documentación técnica,
         papers académicos, trazabilidad de modelos.

IDENTIDAD DEL AGENTE:
    Actúa como un equipo de 8 especialistas:
    1. Head of Model Validation
    2. Quantitative Validator
    3. MRM Specialist
    4. Financial Auditor
    5. Data Scientist
    6. ML Engineer
    7. Regulatory Compliance Officer
    8. Banking Risk Specialist

    PRINCIPIO CENTRAL:
    "La función del agente no es construir modelos.
     La función es cuestionarlos, validarlos, auditarlos
     y demostrar su robustez o debilidad."

USO:
    python virf_agent_v28.py

PREREQUISITOS:
    - ANTHROPIC_API_KEY en .env o variable de entorno
    - Python 3.10+
    - pip install anthropic python-dotenv pyyaml pandas chromadb

COMANDOS EN SESIÓN:
    /ayuda      — comandos disponibles
    /estado     — estado del agente y skills registradas
    /memoria    — resumen de la memoria de sesión
    /skills     — lista de skills disponibles
    /limpiar    — limpia memoria de sesión
    /salir      — termina la sesión

PIPELINE POR QUERY (6 pasos):
    1. Routing      : TaskRouter clasifica la query → TaskType MRM
    2. Memoria      : ShortTermMemory recupera contexto de sesión
    3. Razonamiento : ReasoningEngine genera CoT → elige skill
    4. Orquestación : AgentOrchestrator ejecuta la skill con RAG
    5. Evaluación   : HallucinationChecker MRM + ConfidenceScorer
    6. Memoria      : Almacena resultado en Short y LongTermMemory

SKILLS REGISTRADAS (v28):
    FAILURE_ANALYSIS       → FailureAnalysisSkill
    METHODOLOGY_COMPLIANCE → MethodologyComplianceSkill
    CHALLENGER_GENERATION  → ChallengerGenerationSkill
    PAPER_INTELLIGENCE     → PaperIntelligenceSkill
    REPO_RECONSTRUCTION    → RepoReconstructionSkill
    REGULATORY_REVIEW      → RegulatoryReviewSkill
    DOCUMENTATION_AUDIT    → DocumentationAuditSkill
    MODEL_GOVERNANCE       → ModelGovernanceSkill

====================================================================
"""

import logging
import asyncio
import sys
import json
import datetime
from pathlib import Path
from typing import Dict, Any, Optional

# ─── Configuración de paths ───────────────────────────────────────────────────
_PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_PROJECT_ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(".env")
except ImportError:
    pass

# ─── Imports de infraestructura (reutilizados de v27) ────────────────────────
from agent.orchestrator.orchestrator import AgentOrchestrator
from agent.orchestrator.task_router import TaskRouter, TaskType
from agent.context_engineering.compression import ContextCompressor
from agent.context_engineering.filtering import ContextFilter
from agent.context_engineering.ranking import ContextRanker
from agent.context_engineering.prioritization import ContextPrioritizer
from agent.reasoning.reasoning_engine import ReasoningEngine
from agent.memory.short_term_memory import ShortTermMemory
from agent.memory.long_term_memory import LongTermMemory
from agent.memory import SummaryGenerator
from agent.evaluators.confidence_score import ConfidenceScorer
from agent.evaluators.hallucination_checker import HallucinationChecker
from agent.evaluators.grounding_checker import GroundingChecker
from agent.evaluators.response_evaluator import ResponseEvaluator
from agent.feedback.feedback_store import FeedbackStore
from agent.feedback.feedback_analyzer import FeedbackAnalyzer
from agent.feedback.learning_loop import LearningLoop
from agent.feedback.corrections import CorrectionsTracker

# ─── Imports de NUEVAS SKILLS v28 ────────────────────────────────────────────
from agent.skills.failure_analysis_skill import FailureAnalysisSkill
from agent.skills.methodology_compliance_skill import MethodologyComplianceSkill
from agent.skills.challenger_generation_skill import ChallengerGenerationSkill
from agent.skills.paper_intelligence_skill import PaperIntelligenceSkill
from agent.skills.repo_reconstruction_skill import RepoReconstructionSkill
from agent.skills.regulatory_review_skill import RegulatoryReviewSkill
from agent.skills.documentation_audit_skill import DocumentationAuditSkill
from agent.skills.model_governance_skill import ModelGovernanceSkill

# ─── Logging ─────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/virf_agent_v28.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("virf_agent_v28")

# ─── System Prompt MRM ───────────────────────────────────────────────────────
SYSTEM_PROMPT_MRM = """
Eres VIRF_AGENT_V28 — un equipo de 8 especialistas en Model Risk Management:

1. Head of Model Validation (15 años en banca)
2. Quantitative Validator (PhD en Estadística)
3. MRM Specialist (certificado Basilea II/III/IV)
4. Financial Auditor (certificado CFA)
5. Data Scientist senior (ML para riesgo crediticio)
6. ML Engineer (pipelines y producción)
7. Regulatory Compliance Officer (SBS, Fed, BCE)
8. Banking Risk Specialist (riesgo operacional y mercado)

PRINCIPIO CENTRAL:
Tu función NO es construir modelos.
Tu función ES cuestionarlos, validarlos, auditarlos y demostrar
su robustez o debilidad antes de su aprobación en producción.

SIEMPRE:
1. Busca evidencia antes de validar cualquier supuesto
2. Identifica fallas activamente (el silencio no es aprobación)
3. Identifica riesgos aunque no sean evidentes
4. Cuestiona supuestos metodológicos y estadísticos
5. Genera pruebas reproducibles cuando sea posible
6. Entrega recomendaciones accionables con responsable y plazo
7. Nunca asumas que una implementación es correcta sin evidencia

NUNCA:
- Asumas que un modelo es correcto sin haberlo cuestionado
- Omitas hallazgos por considerarlos menores
- Apruebes documentación incompleta
- Valides sin evidencia suficiente
"""

# ─── Banner ───────────────────────────────────────────────────────────────────
BANNER = """
╔══════════════════════════════════════════════════════════════════╗
║         VIRF_AGENT_V28 — Model Risk Management Platform          ║
║  Validación · Auditoría · MRM · Challenger · Regulatory Review   ║
╠══════════════════════════════════════════════════════════════════╣
║  Skills activas: 8  |  Dominio: Banca & Finanzas                 ║
║  Comandos: /ayuda  /estado  /skills  /memoria  /salir            ║
╚══════════════════════════════════════════════════════════════════╝
"""

SKILL_REGISTRY = {
    TaskType.FAILURE_ANALYSIS:       "FailureAnalysisSkill",
    TaskType.METHODOLOGY_COMPLIANCE: "MethodologyComplianceSkill",
    TaskType.CHALLENGER_GENERATION:  "ChallengerGenerationSkill",
    TaskType.PAPER_INTELLIGENCE:     "PaperIntelligenceSkill",
    TaskType.REPO_RECONSTRUCTION:    "RepoReconstructionSkill",
    TaskType.REGULATORY_REVIEW:      "RegulatoryReviewSkill",
    TaskType.DOCUMENTATION_AUDIT:    "DocumentationAuditSkill",
    TaskType.MODEL_GOVERNANCE:       "ModelGovernanceSkill",
}


async def build_agent() -> AgentOrchestrator:
    """Construye y configura el orquestador con todas las skills v28."""
    orchestrator = AgentOrchestrator()

    # Registrar skills
    orchestrator.register_skill(TaskType.FAILURE_ANALYSIS,       FailureAnalysisSkill())
    orchestrator.register_skill(TaskType.METHODOLOGY_COMPLIANCE, MethodologyComplianceSkill())
    orchestrator.register_skill(TaskType.CHALLENGER_GENERATION,  ChallengerGenerationSkill())
    orchestrator.register_skill(TaskType.PAPER_INTELLIGENCE,     PaperIntelligenceSkill())
    orchestrator.register_skill(TaskType.REPO_RECONSTRUCTION,    RepoReconstructionSkill())
    orchestrator.register_skill(TaskType.REGULATORY_REVIEW,      RegulatoryReviewSkill())
    orchestrator.register_skill(TaskType.DOCUMENTATION_AUDIT,    DocumentationAuditSkill())
    orchestrator.register_skill(TaskType.MODEL_GOVERNANCE,       ModelGovernanceSkill())

    # Registrar evaluadores MRM
    orchestrator.register_evaluator("hallucination_checker", HallucinationChecker())
    orchestrator.register_evaluator("confidence_scorer",     ConfidenceScorer())
    orchestrator.register_evaluator("grounding_checker",     GroundingChecker())
    orchestrator.register_evaluator("response_evaluator",    ResponseEvaluator())

    # Configurar memoria
    memory = ShortTermMemory()
    orchestrator.set_memory(memory)

    logger.info("VIRF_AGENT_V28 — Orquestador configurado con 8 skills MRM")
    return orchestrator


def handle_command(cmd: str, orchestrator: AgentOrchestrator, session_data: Dict) -> str:
    """Procesa comandos especiales del usuario."""
    cmd = cmd.strip().lower()

    if cmd == "/ayuda":
        return """
COMANDOS DISPONIBLES:
  /ayuda   — muestra este mensaje
  /estado  — estado del agente
  /skills  — lista las 8 skills MRM activas
  /memoria — resumen de la sesión actual
  /limpiar — limpia el historial de sesión
  /salir   — cierra la sesión

EJEMPLOS DE CONSULTAS:
  "Analiza las fallas en este modelo de scoring crediticio"
  "¿Cumple este proyecto con SR 11-7?"
  "Genera un challenger para el modelo de PD"
  "Lee este paper y extrae la metodología"
  "Reconstruye la arquitectura de este repositorio"
  "Revisa el cumplimiento regulatorio con Basilea III"
  "Audita la documentación del DDM"
  "Evalúa el gobierno del modelo de IFRS 9"
"""

    if cmd == "/skills":
        lines = ["\nSKILLS ACTIVAS v28:"]
        for task_type, skill_name in SKILL_REGISTRY.items():
            lines.append(f"  [{task_type.value}] → {skill_name}")
        return "\n".join(lines)

    if cmd == "/estado":
        return f"""
ESTADO: VIRF_AGENT_V28
  Skills registradas: {len(SKILL_REGISTRY)}
  Queries procesadas: {session_data.get('query_count', 0)}
  Inicio de sesión: {session_data.get('start_time', 'N/A')}
  Hallazgos acumulados: {session_data.get('total_findings', 0)}
"""

    if cmd == "/memoria":
        return f"Turnos en memoria: {session_data.get('query_count', 0)}"

    if cmd == "/limpiar":
        session_data["query_count"] = 0
        session_data["total_findings"] = 0
        return "Memoria de sesión limpiada."

    return ""


async def main():
    """Punto de entrada principal del agente MRM v28."""
    # Crear directorio de logs
    Path("logs").mkdir(exist_ok=True)
    Path("outputs").mkdir(exist_ok=True)

    print(BANNER)
    logger.info("Iniciando VIRF_AGENT_V28...")

    orchestrator = await build_agent()
    router = TaskRouter()
    reasoning = ReasoningEngine()
    feedback_store = FeedbackStore()
    learning_loop = LearningLoop(feedback_store)
    long_memory = LongTermMemory()

    session_data = {
        "start_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
        "query_count": 0,
        "total_findings": 0,
    }

    print("\n✓ Agente MRM listo. Ingresa tu consulta o /ayuda para comenzar.\n")

    while True:
        try:
            user_input = input("MRM> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[Sesión terminada]")
            break

        if not user_input:
            continue

        if user_input.startswith("/"):
            if user_input.lower() in ("/salir", "/exit", "/quit"):
                print("Cerrando sesión MRM. Hasta pronto.")
                break
            response = handle_command(user_input, orchestrator, session_data)
            if response:
                print(response)
            continue

        # ── Pipeline de procesamiento ─────────────────────────────────────
        session_data["query_count"] += 1
        logger.info(f"Query #{session_data['query_count']}: {user_input[:80]}")

        try:
            # 1. Routing
            task_type, confidence = router.route(user_input)
            task_desc = router.get_task_description(task_type)
            print(f"\n[Routing → {task_desc} | confianza: {confidence:.0%}]")

            # 2. Procesar con orquestador
            context = {"session_data": session_data, "system_prompt": SYSTEM_PROMPT_MRM}
            tools = {}  # Aquí se inyectarían herramientas externas (DataFrames, etc.)

            result = await orchestrator.process_query(
                query=user_input,
                task_type=task_type,
                context=context,
                tools=tools,
            )

            # 3. Extraer respuesta
            response_text = ""
            if isinstance(result, dict):
                inner = result.get("result", {})
                if isinstance(inner, dict):
                    response_text = (
                        inner.get("raw_analysis")
                        or inner.get("compliance_report")
                        or inner.get("hypotheses_analysis")
                        or inner.get("full_analysis")
                        or inner.get("regulatory_opinion")
                        or inner.get("audit_report")
                        or inner.get("governance_assessment")
                        or inner.get("reconstruction_analysis")
                        or str(inner)
                    )
                else:
                    response_text = str(inner) if inner else str(result)
            else:
                response_text = str(result)

            print(f"\n{'─'*60}")
            print(response_text[:4000])  # Truncar para consola
            print(f"{'─'*60}\n")

            # 4. Solicitar feedback
            try:
                rating_input = input("Calidad de la respuesta (1-5, Enter para omitir): ").strip()
                if rating_input and rating_input.isdigit():
                    rating = int(rating_input)
                    if 1 <= rating <= 5:
                        feedback_store.store_feedback(
                            query=user_input,
                            response=response_text[:200],
                            rating=rating,
                            comment="",
                        )
                        print(f"✓ Feedback registrado: {rating}/5")
            except (EOFError, KeyboardInterrupt):
                pass

        except Exception as e:
            logger.error(f"Error en pipeline: {e}", exc_info=True)
            print(f"\n[ERROR] {e}\nRevisa logs/virf_agent_v28.log para detalles.\n")


if __name__ == "__main__":
    asyncio.run(main())
