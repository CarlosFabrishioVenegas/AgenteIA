#!/usr/bin/env python
"""
demo_challenger.py
==================
Script de demostración interactivo del flujo completo con Challenger Model.

Uso:
    python demo_challenger.py

Proporciona:
1. Menú interactivo
2. Ejemplos predefinidos
3. Validación automática
4. Generación de Challenger
"""
# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import sys
import json
from pathlib import Path
from typing import List, Dict

# Agregar agent al path
sys.path.insert(0, str(Path(__file__).parent / "agent"))

from virf_agent import VIRFAgent


# ═══════════════════════════════════════════════════════════════════════════
# CONJUNTOS DE DATOS DE EJEMPLO
# ═══════════════════════════════════════════════════════════════════════════

ESCENARIOS = {
    "LaR": {
        "titulo": "Modelo LaR Cartera Corporativa v3",
        "dominio": "LaR",
        "preguntas": [
            "¿Es correcta esta fórmula? VaR = μ + σ * 1.645",
            "¿Cómo anualizamos volatilidad diaria?",
            "Usamos correlación = 1 entre factores de riesgo",
            "¿Cuántas observaciones mínimas necesitamos en backtesting?",
            "¿Se debe aplicar test de normalidad antes de asumir VaR Normal?",
        ]
    },
    "VaR": {
        "titulo": "Modelo VaR Portafolio Acciones v2",
        "dominio": "VaR",
        "preguntas": [
            "VaR de un portafolio se calcula como suma simple de VaRes individuales",
            "¿El coeficiente de duración debe ser positivo o negativo?",
            "Usamos 100 datos históricos para backtesting",
            "¿Qué es el CVaR (Conditional Value at Risk)?",
        ]
    },
    "Conductuales": {
        "titulo": "Modelo PD Conductual Personas",
        "dominio": "conductuales",
        "preguntas": [
            "Usamos regresión lineal para estimar probabilidad de default",
            "No validamos supuestos de independencia en los datos",
            "¿Cuál es el período mínimo de datos históricos recomendado?",
        ]
    }
}


def limpiar_pantalla():
    """Limpia la pantalla."""
    import os
    os.system('cls' if os.name == 'nt' else 'clear')


def mostrar_encabezado():
    """Muestra encabezado del programa."""
    print("\n" + "="*80)
    print("🚀 VIRF AGENT v27 — FLUJO COMPLETO CON CHALLENGER MODEL")
    print("="*80)
    print("\nEste script demuestra el flujo completo:")
    print("  1. Validación de modelo → Detección de hallazgos")
    print("  2. Generación de informe → JSON + Word")
    print("  3. Generación de Jupyter Notebook con modelo mejorado ⭐")
    print("="*80 + "\n")


def mostrar_menu():
    """Muestra menú principal."""
    print("\n" + "-"*80)
    print("SELECCIONA UN ESCENARIO:")
    print("-"*80)
    print("1. LaR — Pérdida en Riesgo (Cartera Corporativa)")
    print("2. VaR — Value at Risk (Portafolio Acciones)")
    print("3. Conductuales — Riesgo de Default (Personas)")
    print("4. Personalizado — Ingresa tus propias preguntas")
    print("5. Salir")
    print("-"*80)
    return input("Selecciona (1-5): ").strip()


def ejecutar_escenario(nombre_escenario: str):
    """Ejecuta un escenario predefinido."""
    
    if nombre_escenario not in ESCENARIOS:
        print("❌ Escenario no válido")
        return
    
    config = ESCENARIOS[nombre_escenario]
    
    print("\n" + "="*80)
    print(f"ESCENARIO: {nombre_escenario.upper()}")
    print("="*80)
    print(f"Modelo: {config['titulo']}")
    print(f"Dominio: {config['dominio']}")
    print("="*80 + "\n")
    
    # Inicializar agente
    print("[1/5] Inicializando agente...")
    agente = VIRFAgent(
        titulo_modelo=config['titulo'],
        dominio=config['dominio']
    )
    print("✓ Agente listo\n")
    
    # Ejecutar análisis
    print("[2/5] Analizando modelo...")
    for i, pregunta in enumerate(config['preguntas'], 1):
        print(f"\n  [{i}] {pregunta}")
        
        # Analizar fórmula
        if "=" in pregunta:
            respuesta = agente.analizar_formula(pregunta)
            if respuesta and isinstance(respuesta, list):
                for h in respuesta:
                    if isinstance(h, dict):
                        agente._registrar_hallazgo(h)
                        print(f"      ✓ {h['gravedad']}: {h['descripcion'][:70]}...")
        
        # Analizar metodología
        respuesta_met = agente.analizar_metodologia(pregunta)
        if respuesta_met and isinstance(respuesta_met, list):
            for h in respuesta_met:
                if isinstance(h, dict):
                    agente._registrar_hallazgo(h)
                    print(f"      ✓ {h['gravedad']}: {h['descripcion'][:70]}...")
    
    print(f"\n✓ Análisis completado: {len(agente.hallazgos)} hallazgos detectados\n")
    
    # Mostrar hallazgos
    print("[3/5] Hallazgos acumulados:")
    print(agente._mostrar_hallazgos())
    
    # Generar informe
    print("[4/5] Generando informe de validación...")
    informe = agente.validar()
    print(informe)
    
    # Guardar JSON y Word
    agente._guardar_hallazgos_json()
    ruta_word = agente.exportar_word()
    
    # Generar Challenger
    print("\n[5/5] Generando modelo Challenger mejorado...")
    ruta_challenger = agente.generar_challenger()
    
    # Resumen final
    print("\n" + "="*80)
    print("✅ FLUJO COMPLETADO EXITOSAMENTE")
    print("="*80)
    
    if ruta_challenger:
        print(f"\n📊 Salidas generadas:")
        print(f"   • JSON: outputs/hallazgos_*.json")
        print(f"   • Word: outputs/validacion_*.docx")
        print(f"   • Jupyter Notebook (CHALLENGER): {ruta_challenger}")
        
        # Resumen de hallazgos
        por_gravedad = {"CRÍTICO": 0, "ALTO": 0, "MEDIO": 0, "BAJO": 0}
        for h in agente.hallazgos:
            g = h.get("gravedad", "BAJO")
            por_gravedad[g] += 1
        
        print(f"\n📈 Resumen de hallazgos:")
        for g in ["CRÍTICO", "ALTO", "MEDIO", "BAJO"]:
            if por_gravedad[g] > 0:
                print(f"   • {g}: {por_gravedad[g]}")
    
    print("\n" + "="*80 + "\n")


def ejecutar_personalizado():
    """Permite al usuario ingresar preguntas personalizadas."""
    
    print("\n" + "="*80)
    print("MODO PERSONALIZADO")
    print("="*80)
    
    titulo = input("\nNombre del modelo: ").strip()
    if not titulo:
        titulo = "Modelo Personalizado"
    
    print("\nDominios disponibles: LaR, VaR, conductuales, shared, auto")
    dominio = input("Dominio (auto): ").strip() or "auto"
    
    # Inicializar agente
    print(f"\n[1/4] Inicializando agente...")
    agente = VIRFAgent(titulo_modelo=titulo, dominio=dominio)
    print("✓ Agente listo\n")
    
    # Recopilar preguntas
    print("[2/4] Ingresa preguntas (Enter vacío para terminar):")
    preguntas = []
    i = 1
    while True:
        pregunta = input(f"\n[Pregunta {i}]: ").strip()
        if not pregunta:
            break
        preguntas.append(pregunta)
        i += 1
    
    if not preguntas:
        print("❌ No hay preguntas. Abortando.")
        return
    
    # Analizar
    print(f"\n[3/4] Analizando modelo...")
    for pregunta in preguntas:
        if "=" in pregunta:
            respuesta = agente.analizar_formula(pregunta)
            if respuesta and isinstance(respuesta, list):
                for h in respuesta:
                    if isinstance(h, dict):
                        agente._registrar_hallazgo(h)
        
        respuesta_met = agente.analizar_metodologia(pregunta)
        if respuesta_met and isinstance(respuesta_met, list):
            for h in respuesta_met:
                if isinstance(h, dict):
                    agente._registrar_hallazgo(h)
    
    print(f"✓ Análisis completado: {len(agente.hallazgos)} hallazgos\n")
    
    # Mostrar resultados
    print("[4/4] Generando salidas...")
    print(agente._mostrar_hallazgos())
    print(agente.validar())
    
    agente._guardar_hallazgos_json()
    agente.exportar_word()
    ruta_challenger = agente.generar_challenger()
    
    if ruta_challenger:
        print(f"✅ Challenger generado: {ruta_challenger}")
    
    print("\n" + "="*80 + "\n")


def main():
    """Función principal."""
    mostrar_encabezado()
    
    while True:
        opcion = mostrar_menu()
        
        if opcion == "1":
            ejecutar_escenario("LaR")
        elif opcion == "2":
            ejecutar_escenario("VaR")
        elif opcion == "3":
            ejecutar_escenario("Conductuales")
        elif opcion == "4":
            ejecutar_personalizado()
        elif opcion == "5":
            print("\n👋 ¡Hasta luego!\n")
            sys.exit(0)
        else:
            print("❌ Opción no válida")
        
        input("Presiona Enter para continuar...")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Programa interrumpido. ¡Hasta luego!\n")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error: {e}\n")
        import traceback
        traceback.print_exc()
        sys.exit(1)
