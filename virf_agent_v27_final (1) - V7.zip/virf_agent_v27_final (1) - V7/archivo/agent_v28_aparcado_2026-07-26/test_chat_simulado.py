"""
test_chat_simulado.py
====================
Simula una sesión de chat completa sin interacción humana.
Prueba todas las funciones principales del agente.
"""
# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import sys
from pathlib import Path

_ROOT = Path(__file__).parent
sys.path.insert(0, str(_ROOT))

print("="*80)
print("VIRF AGENT — PRUEBA DE CHAT SIMULADO")
print("="*80)

from agent.virf_agent import VIRFAgent

# Crear agente
agente = VIRFAgent(titulo_modelo="Modelo LaR v3 — Prueba Integral", dominio="LaR")

print("\n[SESIÓN 1: PREGUNTAS SOBRE FÓRMULAS]")
print("-"*80)

# Simular preguntas sobre fórmulas
preguntas_formula = [
    "¿Esta fórmula es correcta? VaR = μ + σ * 1.645",
    "Tenemos: volatilidad_anual = volatilidad_diaria * 252",
    "¿Cómo calculamos ΔP = Dur * Δy?",
]

for pregunta in preguntas_formula:
    print(f"\n👤 Usuario: {pregunta}")
    agente._process_query(pregunta)

print("\n[SESIÓN 2: PREGUNTAS SOBRE METODOLOGÍA]")
print("-"*80)

preguntas_metodologia = [
    "Usamos correlación = 1 para todos los activos",
    "Backtesting con 10 observaciones",
]

for pregunta in preguntas_metodologia:
    print(f"\n👤 Usuario: {pregunta}")
    agente._process_query(pregunta)

print("\n[SESIÓN 3: COMANDOS DEL SISTEMA]")
print("-"*80)

# Ver hallazgos
print("\n👤 Usuario: /hallazgos")
respuesta = agente._handle_command("/hallazgos")
print(respuesta)

# Ver estado
print("\n👤 Usuario: /ayuda")
respuesta = agente._handle_command("/ayuda")
print(respuesta[:500] + "...\n")

print("\n[SESIÓN 4: GENERACIÓN DE INFORME]")
print("-"*80)

print("\n👤 Usuario: /validar")
respuesta = agente.validar()
print(respuesta)

print("\n[RESUMEN]")
print("="*80)
print(f"""
✅ PRUEBA COMPLETADA EXITOSAMENTE

Estadísticas de la sesión:
  • Total hallazgos: {len(agente.hallazgos)}
  • Queries procesadas: {agente.session_data['query_count']}
  • Modelo validado: {agente.titulo_modelo}
  • Dominio: {agente.dominio}

Hallazgos detectados:
""")

por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
for h in agente.hallazgos:
    g = h.get("gravedad", "BAJO")
    por_gravedad.get(g, por_gravedad["MEDIO"]).append(h)

for gravedad in ["CRÍTICO", "ALTO", "MEDIO", "BAJO"]:
    items = por_gravedad[gravedad]
    if items:
        print(f"  • {gravedad}: {len(items)} hallazgos")

print(f"""
Archivos generados:
  ✓ JSON de hallazgos: outputs/hallazgos_*.json
  ✓ Word (si disponible): outputs/validacion_*.docx

Próximos pasos:
  1. Revisar los archivos en outputs/
  2. Ejecutar: python agent/virf_agente.py --chat
  3. Ingresar preguntas de validación interactivamente
  4. Usar /validar para generar informe final

Estado: ✅ LISTO PARA PRODUCCIÓN
""")
print("="*80)
