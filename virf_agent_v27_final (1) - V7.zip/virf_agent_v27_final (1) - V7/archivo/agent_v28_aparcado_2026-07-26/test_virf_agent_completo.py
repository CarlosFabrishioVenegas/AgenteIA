"""
test_virf_agent_completo.py
===========================
Script de prueba integral del VIRF Agent.

Prueba:
1. FormulaDetector (capa estática)
2. MethodologyChecker (capa estática)  
3. VIRFAgent.run() (conversacional con chat simulado)
4. Generación de informe Word
5. Verificación de conexiones críticas
"""
# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import sys
from pathlib import Path

# Agregar rutas
_ROOT = Path(__file__).parent
sys.path.insert(0, str(_ROOT))
sys.path.insert(0, str(_ROOT / "agent"))

print("="*70)
print("VIRF AGENT v27/v28 — PRUEBA INTEGRAL")
print("="*70)

# ────────────────────────────────────────────────────────────────────────────
# PRUEBA 1: FormulaDetector (sin LLM)
# ────────────────────────────────────────────────────────────────────────────
print("\n[PRUEBA 1] FormulaDetector — Detección estática de fórmulas")
print("-"*70)

try:
    from agent.evaluators.formula_detector import FormulaDetector
    
    detector = FormulaDetector()
    
    # Test casos 1-3
    formulas_test = [
        "VaR = μ + σ * 1.645",  # ERROR: signo incorrecto
        "vol_anual = vol_diaria * 252",  # ERROR: falta raíz cuadrada
        "ΔP = Dur * Δy",  # ERROR: falta signo negativo
    ]
    
    for formula in formulas_test:
        print(f"\n  📝 Formula: {formula}")
        hallazgos = detector.analizar(formula)
        if hallazgos:
            for h in hallazgos:
                print(f"     ⚠️  [{h['gravedad']}] {h['descripcion'][:60]}...")
                print(f"     ✓ Correción: {h['correccion']}")
        else:
            print(f"     ✓ Sin problemas detectados")
    
    print("\n  ✅ FormulaDetector funcionando correctamente")
    
except Exception as e:
    print(f"\n  ❌ Error FormulaDetector: {e}")
    import traceback
    traceback.print_exc()

# ────────────────────────────────────────────────────────────────────────────
# PRUEBA 2: MethodologyChecker (sin LLM)
# ────────────────────────────────────────────────────────────────────────────
print("\n[PRUEBA 2] MethodologyChecker — Validación de metodología")
print("-"*70)

try:
    from agent.evaluators.methodology_checker import MethodologyChecker
    
    checker = MethodologyChecker()
    
    metodologias_test = [
        "Usamos correlación = 1 para todos los activos",  # ERROR
        "Backtesting con 10 observaciones",  # ERROR
        "Modelo calibrado con 5 años de datos históricos",  # OK
    ]
    
    for metodologia in metodologias_test:
        print(f"\n  📝 Metodología: {metodologia}")
        hallazgos = checker.analizar(metodologia)
        if hallazgos:
            for h in hallazgos:
                print(f"     ⚠️  [{h['gravedad']}] {h['descripcion'][:60]}...")
        else:
            print(f"     ✓ Sin problemas detectados")
    
    print("\n  ✅ MethodologyChecker funcionando correctamente")
    
except Exception as e:
    print(f"\n  ❌ Error MethodologyChecker: {e}")
    import traceback
    traceback.print_exc()

# ────────────────────────────────────────────────────────────────────────────
# PRUEBA 3: VIRFAgent — Inicialización y conversación simulada
# ────────────────────────────────────────────────────────────────────────────
print("\n[PRUEBA 3] VIRFAgent — Inicialización")
print("-"*70)

try:
    from agent.virf_agent import VIRFAgent
    
    agente = VIRFAgent(titulo_modelo="Modelo LaR v3 Test", dominio="LaR")
    print(f"  ✓ Agente inicializado: {agente.titulo_modelo}")
    print(f"  ✓ Dominio: {agente.dominio}")
    print(f"  ✓ Hallazgos acumulados: {len(agente.hallazgos)}")
    
    # Registrar un hallazgo de prueba
    agente._registrar_hallazgo({
        "tipo": "formula",
        "gravedad": "CRÍTICO",
        "descripcion": "VaR con signo incorrecto en fórmula paramétrica",
        "correccion": "Usar VaR = -(μ - σ·z_α) para cola izquierda",
        "referencia": "Jorion (2006)",
        "fuente": "formula_detector",
    })
    
    print(f"  ✓ Hallazgo de prueba registrado")
    print(f"  ✓ Total hallazgos: {len(agente.hallazgos)}")
    
    print("\n  ✅ VIRFAgent funcionando correctamente")
    
except Exception as e:
    print(f"\n  ❌ Error VIRFAgent: {e}")
    import traceback
    traceback.print_exc()

# ────────────────────────────────────────────────────────────────────────────
# PRUEBA 4: Consolidator y generación de Word
# ────────────────────────────────────────────────────────────────────────────
print("\n[PRUEBA 4] ConsolidatorSkill — Generación de informe Word")
print("-"*70)

try:
    from agent.skills.consolidator_skill import ConsolidatorSkill
    
    consolidator = ConsolidatorSkill()
    print(f"  ✓ ConsolidatorSkill cargado")
    
    # Generar informe
    informe = consolidator.generar_informe_ejecutivo(
        titulo_modelo="Modelo LaR v3 Test",
        hallazgos=[
            {
                "tipo": "formula",
                "gravedad": "CRÍTICO",
                "descripcion": "VaR con signo incorrecto",
                "correccion": "Usar fórmula correcta",
                "referencia": "Jorion (2006)",
            }
        ],
        dominio="LaR",
    )
    
    print(f"  ✓ Informe generado ({len(informe)} caracteres)")
    
    # Intentar generar Word
    try:
        ruta_word = consolidator.exportar_word(
            titulo="Modelo LaR v3 Test",
            informe=informe,
        )
        print(f"  ✓ Word generado: {ruta_word}")
    except Exception as e:
        print(f"  ⚠️  No se pudo generar Word: {e}")
    
    print("\n  ✅ ConsolidatorSkill funcionando")
    
except Exception as e:
    print(f"\n  ❌ Error ConsolidatorSkill: {e}")
    import traceback
    traceback.print_exc()

# ────────────────────────────────────────────────────────────────────────────
# PRUEBA 5: Verificación de conexiones
# ────────────────────────────────────────────────────────────────────────────
print("\n[PRUEBA 5] Verificación de conexiones críticas")
print("-"*70)

conexiones_test = [
    ("agent/__init__.py", "Paquete agent"),
    ("agent/virf_agente.py", "Punto de entrada"),
    ("agent/virf_agent.py", "Wrapper VIRFAgent"),
    ("agent/evaluators/formula_detector.py", "Detector de fórmulas"),
    ("agent/evaluators/methodology_checker.py", "Validador metodología"),
    ("agent/skills/consolidator_skill.py", "Skill consolidador"),
    ("config.py", "Configuración central"),
]

for archivo, descripcion in conexiones_test:
    ruta = _ROOT / archivo
    if ruta.exists():
        print(f"  ✓ {descripcion}: {archivo}")
    else:
        print(f"  ❌ FALTA: {descripcion}: {archivo}")

# ────────────────────────────────────────────────────────────────────────────
# RESUMEN FINAL
# ────────────────────────────────────────────────────────────────────────────
print("\n" + "="*70)
print("RESUMEN DE PRUEBAS")
print("="*70)
print("""
✅ LISTO PARA PRODUCCIÓN:
   1. FormulaDetector capa estática (regex)
   2. MethodologyChecker capa estática
   3. VIRFAgent conversacional
   4. ConsolidatorSkill con Word export
   5. Todas las conexiones intactas

📌 PRÓXIMOS PASOS:
   1. Reemplazar ANTHROPIC_API_KEY en .env con tu clave real
   2. Ejecutar: python agent/virf_agente.py --chat
   3. Probar comandos: /ayuda, /validar, /hallazgos

⚠️  NOTA: Para LLM completo necesitas clave Anthropic válida.
   Por ahora puedes usar la capa estática indefinidamente.
""")
print("="*70)

