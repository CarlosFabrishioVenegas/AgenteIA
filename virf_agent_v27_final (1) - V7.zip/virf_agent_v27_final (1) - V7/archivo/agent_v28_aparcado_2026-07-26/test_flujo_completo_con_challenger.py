"""
test_flujo_completo_con_challenger.py
======================================
Test completo que demuestra:
1. Validación de modelo (detección de hallazgos)
2. Generación de informe JSON
3. Exportación a Word
4. Generación de Jupyter Notebook Challenger
"""
# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import sys
from pathlib import Path

# Agregar agent al path
agent_path = Path(__file__).parent / "agent"
sys.path.insert(0, str(agent_path))


def test_flujo_completo():
    """Simula el flujo completo: análisis → informe → challenger."""
    
    print("\n" + "="*80)
    print("TEST: FLUJO COMPLETO CON CHALLENGER")
    print("="*80)
    
    # ========================
    # 1. INICIALIZAR AGENTE
    # ========================
    print("\n[1/5] Inicializando agente...")
    
    from agent.virf_agent import VIRFAgent
    
    agente = VIRFAgent(titulo_modelo="Modelo LaR v3", dominio="LaR")
    print("✓ Agente inicializado")
    
    # ========================
    # 2. EJECUTAR ANÁLISIS
    # ========================
    print("\n[2/5] Analizando modelo...")
    
    # Simular preguntas sobre el modelo
    preguntas = [
        "¿Esta fórmula de VaR es correcta? VaR = μ + σ * z",
        "Anualizamos volatilidad diaria multiplicando por 252",
        "Usamos correlación = 1 entre factores",
        "El backtesting se hace con solo 10 observaciones",
    ]
    
    for i, pregunta in enumerate(preguntas, 1):
        print(f"\n  [{i}] Pregunta: {pregunta}")
        agente.session_data["query_count"] += 1
        
        # Analizar fórmula si contiene una
        if "=" in pregunta:
            respuesta = agente.analizar_formula(pregunta)
            if respuesta and isinstance(respuesta, list):
                for h in respuesta:
                    if isinstance(h, dict):
                        agente._registrar_hallazgo(h)
                        print(f"      → {h['gravedad']}: {h['descripcion'][:60]}...")
        
        # Analizar metodología
        respuesta_met = agente.analizar_metodologia(pregunta)
        if respuesta_met and isinstance(respuesta_met, list):
            for h in respuesta_met:
                if isinstance(h, dict):
                    agente._registrar_hallazgo(h)
                    print(f"      → {h['gravedad']}: {h['descripcion'][:60]}...")
    
    print(f"\n✓ Análisis completado: {len(agente.hallazgos)} hallazgos detectados")
    
    # ========================
    # 3. MOSTRAR HALLAZGOS
    # ========================
    print("\n[3/5] Hallazgos detectados:")
    print(agente._mostrar_hallazgos())
    
    # ========================
    # 4. GENERAR INFORME
    # ========================
    print("\n[4/5] Generando informe de validación...")
    
    # Mostrar informe
    informe = agente.validar()
    print(informe)
    
    # Guardar JSON
    agente._guardar_hallazgos_json()
    print("   ✓ JSON guardado en outputs/")
    
    # Exportar a Word
    ruta_word = agente.exportar_word()
    if ruta_word:
        print(f"   ✓ Word guardado: {ruta_word}")
    
    # ========================
    # 5. GENERAR CHALLENGER
    # ========================
    print("\n[5/5] Generando modelo Challenger mejorado...")
    
    ruta_challenger = agente.generar_challenger()
    
    if ruta_challenger:
        print(f"\n✅ FLUJO COMPLETADO EXITOSAMENTE")
        print(f"\n   📊 Informe JSON: outputs/hallazgos_*.json")
        print(f"   📄 Informe Word: outputs/validacion_*.docx")
        print(f"   🚀 Challenger Model: {ruta_challenger}")
        print(f"\n   Hallazgos incorporados en Challenger: {len(agente.hallazgos)}")
        
        # Mostrar resumen de hallazgos por gravedad
        por_gravedad = {"CRÍTICO": 0, "ALTO": 0, "MEDIO": 0, "BAJO": 0}
        for h in agente.hallazgos:
            g = h.get("gravedad", "BAJO")
            por_gravedad[g] += 1
        
        print(f"\n   Distribucion por gravedad:")
        for g in ["CRÍTICO", "ALTO", "MEDIO", "BAJO"]:
            if por_gravedad[g] > 0:
                print(f"      • {g}: {por_gravedad[g]}")
        
        return True
    else:
        print("\n❌ Error generando Challenger")
        return False


def test_challenger_directo():
    """Test directo del generador de Challenger."""
    
    print("\n" + "="*80)
    print("TEST: GENERADOR DE CHALLENGER (DIRECTO)")
    print("="*80)
    
    from agent.skills.challenger_generator import generar_challenger_desde_hallazgos
    
    # Hallazgos de ejemplo (basados en test anterior)
    hallazgos = [
        {
            "tipo": "formula",
            "gravedad": "CRÍTICO",
            "descripcion": "VaR paramétrico con signo incorrecto: VaR = μ + σ·z",
            "correccion": "VaR = -(μ - σ·z) para pérdidas positivas",
            "referencia": "Jorion (2006), Value at Risk, 3rd Edition",
            "fuente": "formula_detector"
        },
        {
            "tipo": "metodologia",
            "gravedad": "ALTO",
            "descripcion": "Anualización de volatilidad sin validación: volatilidad * 252",
            "correccion": "Usar raíz cuadrada: vol_anual = vol_diaria * sqrt(252)",
            "referencia": "Hull (2012), Options, Futures and Other Derivatives"
        },
        {
            "tipo": "formula",
            "gravedad": "ALTO",
            "descripcion": "Correlación asumida = 1 (máxima dependencia)",
            "correccion": "Estimar correlación empírica de los datos históricos",
            "referencia": "Kupiec (1995), Techniques for Verifying the Accuracy"
        },
        {
            "tipo": "metodologia",
            "gravedad": "MEDIO",
            "descripcion": "Backtesting insuficiente: solo 10 observaciones",
            "correccion": "Mínimo 250 observaciones (1 año de datos diarios)",
            "referencia": "Christoffersen (1998), Evaluating Interval Forecasts"
        }
    ]
    
    print(f"\nGenerando Challenger con {len(hallazgos)} hallazgos...")
    
    ruta = generar_challenger_desde_hallazgos(
        titulo_modelo="Test Modelo LaR",
        dominio="LaR",
        hallazgos=hallazgos
    )
    
    if ruta:
        print(f"\n✅ Challenger generado: {ruta}")
        
        # Verificar que el archivo existe
        path = Path(ruta)
        if path.exists():
            print(f"   Tamaño: {path.stat().st_size} bytes")
            print(f"   Tipo: {path.suffix}")
            return True
    
    return False


if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO)
    
    # Test 1: Flujo completo
    success1 = test_flujo_completo()
    
    # Test 2: Challenger directo
    print("\n" + "-"*80 + "\n")
    success2 = test_challenger_directo()
    
    # Resumen final
    print("\n" + "="*80)
    print("RESUMEN DE TESTS")
    print("="*80)
    print(f"Flujo completo: {'✅ PASADO' if success1 else '❌ FALLIDO'}")
    print(f"Generador Challenger: {'✅ PASADO' if success2 else '❌ FALLIDO'}")
    
    if success1 and success2:
        print("\n🎉 TODOS LOS TESTS PASARON EXITOSAMENTE")
        sys.exit(0)
    else:
        print("\n⚠️  ALGUNOS TESTS FALLARON")
        sys.exit(1)
