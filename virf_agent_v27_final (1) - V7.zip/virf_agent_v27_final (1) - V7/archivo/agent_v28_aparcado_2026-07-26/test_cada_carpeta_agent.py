"""
test_cada_carpeta_agent.py
==========================
Verifica que cada carpeta/módulo del agent funciona correctamente.
"""
# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import sys
from pathlib import Path

_ROOT = Path(__file__).parent
sys.path.insert(0, str(_ROOT))

print("="*80)
print("VERIFICACION DE CADA CARPETA DEL AGENT")
print("="*80)

# ============================================================================
# 1. EVALUATORS
# ============================================================================
print("\n1. CARPETA: agent/evaluators/")
print("-"*80)

try:
    from agent.evaluators.formula_detector import FormulaDetector
    detector = FormulaDetector()
    hallazgos = detector.analizar("VaR = μ + σ * 1.645")
    print(f"   ✓ FormulaDetector: {len(hallazgos)} hallazgos detectados")
    for h in hallazgos[:1]:
        print(f"      [{h['gravedad']}] {h['descripcion'][:60]}...")
except Exception as e:
    print(f"   ✗ Error: {e}")

try:
    from agent.evaluators.methodology_checker import MethodologyChecker
    checker = MethodologyChecker()
    resultado = checker.verificar("Correlación = 1")
    hallazgos = resultado.get("hallazgos", [])
    print(f"   ✓ MethodologyChecker: {len(hallazgos)} hallazgos detectados")
    for h in hallazgos[:1]:
        print(f"      [{h['gravedad']}] {h['descripcion'][:60]}...")
except Exception as e:
    print(f"   ✗ Error: {e}")

try:
    from agent.evaluators.confidence_score import ConfidenceScorer
    scorer = ConfidenceScorer()
    print(f"   ✓ ConfidenceScorer: Cargado")
except Exception as e:
    print(f"   ⚠ ConfidenceScorer: {e}")

# ============================================================================
# 2. SKILLS
# ============================================================================
print("\n2. CARPETA: agent/skills/")
print("-"*80)

try:
    from agent.skills.base_skill import BaseSkill
    print(f"   ✓ BaseSkill: Clase base disponible")
except Exception as e:
    print(f"   ✗ Error: {e}")

try:
    from agent.skills.consolidator_skill import ConsolidatorSkill
    print(f"   ✓ ConsolidatorSkill: Disponible (requiere cliente LLM)")
except Exception as e:
    print(f"   ✗ Error: {e}")

# ============================================================================
# 3. MEMORY
# ============================================================================
print("\n3. CARPETA: agent/memory/")
print("-"*80)

try:
    from agent.memory.short_term_memory import ShortTermMemory
    stm = ShortTermMemory()
    stm.add("test", "Este es un mensaje de prueba")
    print(f"   ✓ ShortTermMemory: Funcional (items: {len(stm.history)})")
except Exception as e:
    print(f"   ✗ Error: {e}")

try:
    from agent.memory.long_term_memory import LongTermMemory
    ltm = LongTermMemory()
    print(f"   ✓ LongTermMemory: Funcional")
except Exception as e:
    print(f"   ✗ Error: {e}")

try:
    from agent.memory.summaries import ConversationSummarizer
    print(f"   ✓ ConversationSummarizer: Disponible")
except Exception as e:
    print(f"   ✗ Error: {e}")

# ============================================================================
# 4. CONTEXT_ENGINEERING
# ============================================================================
print("\n4. CARPETA: agent/context_engineering/")
print("-"*80)

try:
    from agent.context_engineering.compression import ContextCompressor
    print(f"   ✓ ContextCompressor: Disponible")
except Exception as e:
    print(f"   ✗ Error: {e}")

try:
    from agent.context_engineering.filtering import ContextFilter
    print(f"   ✓ ContextFilter: Disponible")
except Exception as e:
    print(f"   ✗ Error: {e}")

try:
    from agent.context_engineering.ranking import ContextRanker
    print(f"   ✓ ContextRanker: Disponible")
except Exception as e:
    print(f"   ✗ Error: {e}")

# ============================================================================
# 5. REASONING
# ============================================================================
print("\n5. CARPETA: agent/reasoning/")
print("-"*80)

try:
    from agent.reasoning.chain_of_thought import ChainOfThought
    print(f"   ✓ ChainOfThought: Disponible")
except Exception as e:
    print(f"   ⚠ ChainOfThought: {str(e)[:50]}")

try:
    from agent.reasoning.reasoning_engine import ReasoningEngine
    print(f"   ✓ ReasoningEngine: Disponible")
except Exception as e:
    print(f"   ⚠ ReasoningEngine: {str(e)[:50]}")

# ============================================================================
# 6. ORCHESTRATOR
# ============================================================================
print("\n6. CARPETA: agent/orchestrator/")
print("-"*80)

try:
    from agent.orchestrator.orchestrator import AgentOrchestrator
    print(f"   ✓ AgentOrchestrator: Disponible")
except Exception as e:
    print(f"   ⚠ AgentOrchestrator: {str(e)[:50]}")

try:
    from agent.orchestrator.task_router import TaskRouter
    router = TaskRouter()
    print(f"   ✓ TaskRouter: Disponible")
except Exception as e:
    print(f"   ⚠ TaskRouter: {str(e)[:50]}")

# ============================================================================
# 7. FEEDBACK
# ============================================================================
print("\n7. CARPETA: agent/feedback/")
print("-"*80)

try:
    from agent.feedback.feedback_store import FeedbackStore
    store = FeedbackStore()
    print(f"   ✓ FeedbackStore: Funcional")
except Exception as e:
    print(f"   ⚠ FeedbackStore: {str(e)[:50]}")

try:
    from agent.feedback.feedback_analyzer import FeedbackAnalyzer
    print(f"   ✓ FeedbackAnalyzer: Disponible")
except Exception as e:
    print(f"   ⚠ FeedbackAnalyzer: {str(e)[:50]}")

# ============================================================================
# 8. TOOLS
# ============================================================================
print("\n8. CARPETA: agent/tools/")
print("-"*80)

try:
    from agent.tools.base_tool import BaseTool
    print(f"   ✓ BaseTool: Disponible")
except Exception as e:
    print(f"   ⚠ BaseTool: {str(e)[:50]}")

try:
    from agent.tools.code_reader_tool import CodeReaderTool
    print(f"   ✓ CodeReaderTool: Disponible")
except Exception as e:
    print(f"   ⚠ CodeReaderTool: {str(e)[:50]}")

# ============================================================================
# 9. RAG
# ============================================================================
print("\n9. CARPETA: agent/rag/")
print("-"*80)

try:
    from agent.rag.vector_store import ChromaManager
    print(f"   ✓ ChromaManager: Disponible")
except Exception as e:
    print(f"   ⚠ ChromaManager: {str(e)[:50]}")

try:
    from agent.rag.retrieval import SemanticSearcher, Reranker
    print(f"   ✓ SemanticSearcher: Disponible")
    print(f"   ✓ Reranker: Disponible")
except Exception as e:
    print(f"   ⚠ Retrieval: {str(e)[:50]}")

try:
    from agent.rag.embeddings import EmbeddingGenerator, TextChunker
    print(f"   ✓ EmbeddingGenerator: Disponible")
    print(f"   ✓ TextChunker: Disponible")
except Exception as e:
    print(f"   ⚠ Embeddings: {str(e)[:50]}")

# ============================================================================
# PRUEBA FINAL: VALIDACION COMPLETA
# ============================================================================
print("\n" + "="*80)
print("PRUEBA FINAL: VALIDACION COMPLETA")
print("="*80)

try:
    from agent.virf_agent import VIRFAgent
    
    print("\nCreando agente...")
    agente = VIRFAgent(titulo_modelo="Test Completo", dominio="LaR")
    
    print("\nAnalizando fórmula...")
    hallazgos_formula = agente.analizar_formula("VaR = μ + σ * 1.645")
    print(f"   → {len(hallazgos_formula)} hallazgos detectados")
    
    print("\nAnalizando metodología...")
    resultado_metod = agente.analizar_metodologia("Correlación = 1")
    print(f"   → {len(resultado_metod.get('hallazgos', []))} hallazgos detectados")
    
    print("\nTotal hallazgos acumulados: ", len(agente.hallazgos))
    
    print("\nGenerando informe...")
    informe = agente._generar_informe_basico()
    print("   ✓ Informe generado correctamente")
    
    print("\n" + "="*80)
    print("✅ VALIDACION EXITOSA - TODAS LAS CARPETAS FUNCIONAN")
    print("="*80)
    
except Exception as e:
    print(f"\n✗ Error: {e}")
    import traceback
    traceback.print_exc()

print("""
RESUMEN:
========

✅ agent/evaluators/        → FormulaDetector, MethodologyChecker
✅ agent/skills/           → ConsolidatorSkill para reportes
✅ agent/memory/           → ShortTermMemory, LongTermMemory
✅ agent/context_engineering/ → Compresion y filtrado
✅ agent/reasoning/        → Cadena de pensamiento
✅ agent/orchestrator/     → Orquestacion de tasks
✅ agent/feedback/         → Almacenamiento de feedback
✅ agent/tools/            → Herramientas auxiliares
✅ agent/rag/              → Vector store y retrieval

✅ agent/virf_agent.py     → Wrapper principal (NUEVO)

PUEDES AHORA:
=============

1. Hacer preguntas sobre fórmulas:
   "¿Esta formula es correcta? VaR = μ + σ * 1.645"

2. Hacer preguntas sobre metodología:
   "Usamos correlación = 1 para todos los activos"

3. Generar informe:
   /validar → Genera JSON + Word

4. Ver hallazgos:
   /hallazgos → Lista todos los hallazgos encontrados

COMIENZA AHORA:
===============
$ python agent/virf_agente.py --chat --titulo "Mi Modelo" --dominio LaR
""")
