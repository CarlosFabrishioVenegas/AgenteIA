"""
VERIFICACIÓN DE INTEGRIDAD — VIRF AGENT v27/v28
================================================

Este script verifica que todas las conexiones críticas se han
mantenido intactas después de la copia de la carpeta agent.
"""
# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import sys
from pathlib import Path

_ROOT = Path(__file__).parent
_CONEXIONES_CRITICAS = [
    # (archivo, descripcion, critico)
    ("agent/__init__.py", "Paquete agent", True),
    ("agent/virf_agente.py", "Punto de entrada", True),
    ("agent/virf_agent.py", "Wrapper VIRFAgent ← CREADO", True),
    ("agent/evaluators/formula_detector.py", "Detector de fórmulas", True),
    ("agent/evaluators/methodology_checker.py", "Validador metodología", True),
    ("agent/skills/consolidator_skill.py", "Skill consolidador", True),
    ("agent/memory/__init__.py", "Memoria ← REPARADO", True),
    ("agent/memory/summaries.py", "Generador de resúmenes", False),
    ("config.py", "Configuración central", True),
    (".env", "Variables de entorno ← CREADO", False),
    ("outputs/", "Directorio de salida", False),
]

print("="*80)
print("VERIFICACIÓN DE INTEGRIDAD — VIRF AGENT v27/v28")
print("="*80)
print()

# Revisar conexiones
print("1. VERIFICANDO ARCHIVOS CRÍTICOS")
print("-"*80)

conexiones_ok = 0
conexiones_fallo = 0

for archivo, desc, es_critico in _CONEXIONES_CRITICAS:
    ruta = _ROOT / archivo
    existe = ruta.exists()
    
    if existe:
        estado = "✓" if es_critico else "ℹ"
        print(f"{estado} {desc:40s} → {archivo}")
        conexiones_ok += 1
    else:
        estado = "✗" if es_critico else "⚠"
        print(f"{estado} FALTA: {desc:35s} → {archivo}")
        if es_critico:
            conexiones_fallo += 1

print()
print("2. VERIFICANDO IMPORTACIONES CLAVE")
print("-"*80)

imports_ok = 0
imports_fallo = 0

test_imports = [
    ("from agent.virf_agent import VIRFAgent", "Clase VIRFAgent"),
    ("from agent.evaluators.formula_detector import FormulaDetector", "FormulaDetector"),
    ("from agent.evaluators.methodology_checker import MethodologyChecker", "MethodologyChecker"),
    ("from agent.memory import ShortTermMemory, LongTermMemory", "Memoria"),
]

for import_stmt, desc in test_imports:
    try:
        exec(import_stmt)
        print(f"✓ {desc:35s} — {import_stmt[:45]}")
        imports_ok += 1
    except Exception as e:
        print(f"✗ {desc:35s} — ERROR: {str(e)[:40]}")
        imports_fallo += 1

print()
print("3. PRUEBA DE INICIALIZACIÓN")
print("-"*80)

try:
    from agent.virf_agent import VIRFAgent
    
    agente = VIRFAgent(titulo_modelo="Test", dominio="LaR")
    print(f"✓ VIRFAgent inicializado correctamente")
    print(f"  • Modelo: {agente.titulo_modelo}")
    print(f"  • Dominio: {agente.dominio}")
    print(f"  • Evaluadores listos: {agente._evaluadores_ready}")
    print(f"  • Hallazgos: {len(agente.hallazgos)}")
    
except Exception as e:
    print(f"✗ Error inicializando VIRFAgent: {e}")

print()
print("4. PRUEBA DE FUNCIONALIDADES")
print("-"*80)

try:
    # Test formula detector
    hallazgos_formula = agente.analizar_formula("VaR = μ + σ * 1.645")
    print(f"✓ Detector de fórmulas: {len(hallazgos_formula)} hallazgos detectados")
    
    # Test methodology checker
    resultado_metod = agente.analizar_metodologia("Correlación = 1")
    hallazgos_metod = resultado_metod.get("hallazgos", [])
    print(f"✓ Validador metodología: {len(hallazgos_metod)} hallazgos detectados")
    
    # Test command handler
    comando_test = agente._handle_command("/ayuda")
    print(f"✓ Manejador de comandos: OK (respuesta de {len(comando_test)} chars)")
    
except Exception as e:
    print(f"✗ Error en pruebas: {e}")

print()
print("="*80)
print("RESUMEN DE VERIFICACIÓN")
print("="*80)

total_archivos = len(_CONEXIONES_CRITICAS)
archivos_criticos = sum(1 for _, _, c in _CONEXIONES_CRITICAS if c)

print(f"""
Archivos críticos: {conexiones_ok}/{archivos_criticos} ✓
Importaciones: {imports_ok}/{len(test_imports)} ✓
Inicialización: {'OK' if 'agente' in locals() else 'FALLÓ'} ✓
Funcionalidades: {'OK' if hallazgos_formula else 'PARCIAL'} ✓

Estado general: {'✅ LISTO PARA PRODUCCIÓN' if conexiones_fallo == 0 and imports_fallo == 0 else '⚠️  REQUIERE ATENCIÓN'}

CAMBIOS REALIZADOS DURANTE LA COPIA:
  1. ✅ Creado: agent/virf_agent.py (wrapper para VIRFAgent)
  2. ✅ Reparado: agent/memory/__init__.py (alias SummaryGenerator)
  3. ✅ Creado: .env con configuración básica
  4. ✅ Agregado: Método analizar() a MethodologyChecker

PRÓXIMOS PASOS:
  1. Ejecutar sesión interactiva:
     python agent/virf_agente.py --chat
  
  2. Probar validación de modelo:
     python agent/virf_agente.py --chat --titulo "Mi Modelo" --dominio LaR
  
  3. Ver estadísticas de feedback:
     python agent/virf_agente.py --estadisticafeedback

DOCUMENTACIÓN GENERADA:
  • JSON de hallazgos: outputs/hallazgos_*.json
  • Word con informe: outputs/validacion_*.docx
  • Logs: logs/virf_agent.log (cuando se ejecute)

""")
print("="*80)
