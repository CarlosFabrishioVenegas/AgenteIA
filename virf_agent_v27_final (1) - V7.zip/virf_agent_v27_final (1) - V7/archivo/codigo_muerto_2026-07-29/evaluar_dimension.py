"""
CÓDIGO MUERTO RETIRADO — 2026-07-29
═══════════════════════════════════════════════════════════════════════════════
Funciones eliminadas de motor/Mx_03_LlamarIA.py porque NINGÚN módulo las llamaba.

Se conservan aquí por trazabilidad, no para reutilizarse. Si alguna vez se
reactivan, revísense antes contra los invariantes vigentes: la versión original
de `evaluar_dimension()` violaba el D3-FIX —emitía estado="No cumple",
riesgo="Alto" y score=0 para una dimensión SIN UN SOLO DOCUMENTO— y el 0 lo
elevaba _normalizar_score() a 1, el peor puntaje de la escala. Se corrigió en la
auditoría del 2026-07-28 y esta copia YA incluye la corrección.

Motivo de la retirada: mantener código público sin llamantes es un pasivo. Nadie
lo ejercita, así que ningún test lo protege, y quien lo reactive heredará el
comportamiento que tuviera en ese momento sin enterarse.
"""

def evaluar_dimension(
    dimension: str,
    actividades: list,
    documentos: list,
    estilo: dict,
    modo: str,
    instrucciones_extra: str = "",
    contexto_feedback: str = "",
) -> dict:
    """
    Evalúa las actividades de una dimensión VIRF.
    Maneja el caso de sin documentos (retorna evaluación vacía con preguntas).
    Retorna dict con evaluaciones, cumplimiento y hallazgos.
    """
    fallback = {
        "dimension":               dimension,
        "evaluaciones":            [],
        "nivel_cumplimiento":      0,
        "actividades_sin_evidencia": len(actividades),
        "resumen_dimension":       "Sin actividades.",
        "hallazgos_criticos":      [],
        "preguntas_globales_dimension": [],
    }

    if not actividades:
        return fallback

    # Sin documentos → preguntas automáticas
    if not documentos:
        preguntas = [
            f"No se encontraron documentos para la dimensión {dimension}. "
            f"¿Puede proporcionar los archivos correspondientes?"
        ]
        evals = []
        for a in [x for x in actividades if x.get("requerida", True)]:
            # ── [AUDIT-FIX · D3] Sin documentos ≠ incumplimiento ──────────────
            # Esta rama emitía `estado="No cumple"`, `riesgo="Alto"` y
            # `score: 0`. Ese 0 llega a generador_word._normalizar_score(), que
            # lo eleva a 1 — el PEOR puntaje de la escala 1-5 — sobre una
            # dimensión de la que no se leyó ni un solo documento.
            #
            # Es el patrón dominante de esta auditoría: la AUSENCIA de
            # evidencia presentada como RESULTADO NEGATIVO. El D3-FIX existe
            # justamente para impedirlo, y esta ruta se le había escapado
            # porque hoy no la llama nadie (ver nota de código muerto arriba).
            # Se corrige igual: la función sigue exportada y quien la reactive
            # heredaría el comportamiento anterior sin enterarse.
            ev = {
                "control":           a.get("control", ""),
                "tipo_ctrl":         a.get("tipo_ctrl", ""),
                "actividad":         a["actividad"],
                "concepto":          "No evaluable — sin documentos.",
                "estado":            "Sin evidencia — no evaluable",
                "simbolo":           "⚪",
                "evidencia":         None,
                "observacion_tecnica": "No se recibieron documentos para esta dimensión.",
                "inconsistencias":   None,
                "riesgo":            "No determinado — sin evidencia",
                "recomendacion":     "Proporcionar documentación correspondiente.",
                "preguntas_faltantes": preguntas,
                # Marcas que el resto del pipeline ya entiende: excluyen la
                # actividad del score en vez de puntuarla como incumplida.
                "sin_evidencia":     True,
                "evaluacion_valida": False,
                "puntaje":           None,
            }
            if modo == "preprdc":
                ev.update({"score": None, "criticidad": "No determinada",
                           "score_justificacion":
                               "Sin evidencia: no se emite puntaje (D3-FIX)."})
            evals.append(ev)

        return {
            "dimension":               dimension,
            "evaluaciones":            evals,
            "nivel_cumplimiento":      0,
            "actividades_sin_evidencia": len(evals),
            "resumen_dimension":       f"Sin documentación para {dimension}.",
            "hallazgos_criticos":      [f"Sin documentación para {dimension}"],
            "preguntas_globales_dimension": preguntas,
        }

    # Llamada normal al modelo
    raw = _llamar_modelo(
        prompt_evaluar_dimension(
            dimension=dimension,
            actividades=actividades,
            documentos=documentos,
            estilo=estilo,
            modo=modo,
            instrucciones_extra=instrucciones_extra,
            contexto_feedback=contexto_feedback,
        ),
        max_tokens=4000,
    )

    resultado = _parsear_json(raw, fallback)

    # Recalcular actividades_sin_evidencia
    evals = resultado.get("evaluaciones", [])
    sin_ev = sum(
        1 for e in evals
        if not e.get("evidencia") or e.get("estado") == "No cumple"
    )
    resultado["actividades_sin_evidencia"] = sin_ev

    return resultado
