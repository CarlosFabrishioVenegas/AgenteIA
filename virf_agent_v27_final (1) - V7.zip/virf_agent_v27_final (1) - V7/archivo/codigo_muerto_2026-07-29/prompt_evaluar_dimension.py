"""
CÓDIGO MUERTO RETIRADO — 2026-07-29
═══════════════════════════════════════════════════════════════════════════════
Funciones eliminadas de motor/Mx_02_EstructuraPrompt.py porque NINGÚN módulo las llamaba.

Se conservan aquí por trazabilidad, no para reutilizarse. Si alguna vez se
reactivan, revísense antes contra los invariantes vigentes: la versión original
de `evaluar_dimension()` violaba el D3-FIX —emitía estado="No cumple",
riesgo="Alto" y score=0 para una dimensión SIN UN SOLO DOCUMENTO— y el 0 lo
elevaba _normalizar_score() a 1, el peor puntaje de la escala. Se corrigió en la
auditoría del 2026-07-28 y esta copia YA incluye la corrección.

Motivo de la retirada: mantener código público sin llamantes es un pasivo. Nadie
lo ejercita, así que ningún test lo protege, y quien lo reactive heredará el
comportamiento que tuviera en ese momento sin enterarse.
"""

def prompt_evaluar_dimension(
    dimension: str,
    actividades: list,
    documentos: list,
    estilo: dict,
    modo: str,
    instrucciones_extra: str = "",
    contexto_feedback: str = "",
) -> str:
    """
    Prompt principal de evaluación de una dimensión VIRF.
    Ordena documentos por prioridad, agrupa actividades por control.
    """
    # Ordenar documentos por prioridad
    manuales    = [d for d in documentos if d["tipo"] in ("PDF", "DOCX", "DOC")]
    scripts_seg = [d for d in documentos if d["tipo"] == "PY" and
                   any(k in d["nombre"].lower() for k in
                       ("seguimiento", "backtest", "kupiec", "christoff", "replica_virf", "monitor"))]
    scripts_mod = [d for d in documentos if d["tipo"] == "PY" and d not in scripts_seg]
    excels      = [d for d in documentos if d["tipo"] in ("XLSX", "XLS", "XLSM", "CSV")]
    otros       = [d for d in documentos if d not in manuales + scripts_seg + scripts_mod + excels]

    docs_str = ""
    for etiqueta, grupo in [
        ("MANUALES (prioridad 1)",               manuales),
        ("SCRIPTS DE SEGUIMIENTO (prioridad 2)", scripts_seg),
        ("SCRIPTS DE MODELADOR (prioridad 3)",   scripts_mod),
        ("EXCELS (prioridad 4)",                 excels),
        ("OTROS (prioridad 5)",                  otros),
    ]:
        if grupo:
            docs_str += f"\n{'─'*40}\n{etiqueta}:\n{'─'*40}\n"
            for d in grupo:
                contenido = d.get('contenido', '')
                # Proteger contra None o contenido vacío
                if contenido is None:
                    contenido = "[Contenido vacío o error de lectura]"
                elif not isinstance(contenido, str):
                    contenido = str(contenido)
                docs_str += f"\n[{d['nombre']}]\n{contenido[:2500]}\n"

    # Agrupar actividades por control
    grupos_str = ""
    acts_sorted = sorted(actividades, key=lambda a: a.get("control", ""))
    for ctrl, grp in groupby(acts_sorted, key=lambda a: a.get("control", "")):
        acts = list(grp)
        tipo = acts[0].get("tipo_ctrl", "")
        grupos_str += f"\n  [CONTROL {tipo.upper()}] {ctrl}\n"
        for a in acts:
            req = "REQUERIDA" if a.get("requerida") else "OPCIONAL"
            grupos_str += f"    · [{req}] {a['actividad']}\n"

    # Campos extra según modo
    campos_extra = ""
    if modo == "preprdc":
        campos_extra = """
      "score": 85,          // 0-100: calidad de la evidencia encontrada
      "criticidad": "Alto|Medio|Bajo",  // riesgo si no se corrige
      "score_justificacion": "por qué ese score","""

    # Bloque de instrucciones adicionales
    bloques_extra = ""
    if instrucciones_extra:
        bloques_extra += f"\nINSTRUCCIONES ESPECIALES:\n{instrucciones_extra}"
    if contexto_feedback:
        bloques_extra += f"\nAPRENDIZAJE DE CORRIDAS ANTERIORES (feedback del validador):\n{contexto_feedback}"

    return f"""Eres un Auditor Senior VIRF evaluando la dimensión: {dimension.upper()}
Modo de ejecución: {modo.upper()}

REGLAS CRÍTICAS:
- NO asumir información faltante. Si no hay evidencia → generar preguntas específicas.
- Prioridad de fuentes: Manuales > Scripts Seguimiento > Scripts Modelador > Excels > Otros.
- Detectar inconsistencias entre documentación y código.
- Elevar a criticidad ALTA si falta evidencia en actividades regulatorias críticas.
- Condición de corte: si >30% de actividades no tienen evidencia → señalarlo explícitamente.
{bloques_extra}

ESTILO DE REDACCIÓN (aprendido de informes previos):
{json.dumps(estilo, ensure_ascii=False)}

ACTIVIDADES A EVALUAR:
{grupos_str}

DOCUMENTOS DISPONIBLES (en orden de prioridad):
{docs_str[:9000]}

Para CADA actividad REQUERIDA debes:
1. Buscar evidencia EXPLÍCITA — citar página/sección/línea concreta.
2. Clasificar: ✅ Cumple | ⚠️ Parcial | ❌ No cumple
3. Si no hay evidencia → generar pregunta específica (¿Existe X? ¿Dónde está Y?)
4. Detectar inconsistencias documentación vs código si existen.

Responde SOLO con JSON válido:
{{
  "dimension": "{dimension}",
  "evaluaciones": [
    {{
      "control": "nombre del control",
      "tipo_ctrl": "Cuantitativo|Cualitativo",
      "actividad": "texto exacto de la actividad",
      "concepto": "qué valida técnicamente esta actividad (1-2 oraciones técnicas)",
      "estado": "Cumple|Parcial|No cumple",
      "simbolo": "✅|⚠️|❌",
      "evidencia": "cita concreta: nombre archivo, sección, línea — o null si no hay",
      "observacion_tecnica": "hallazgo técnico detallado con el estilo aprendido",
      "inconsistencias": "inconsistencias doc vs código detectadas, o null",
      "riesgo": "Alto|Medio|Bajo",
      "recomendacion": "acción concreta recomendada",
      "preguntas_faltantes": ["¿Pregunta 1?", "¿Pregunta 2?"]  // vacío [] si hay evidencia{campos_extra}
    }}
  ],
  "resumen_dimension": "párrafo ejecutivo al estilo del informe de referencia",
  "nivel_cumplimiento": 75,
  "actividades_sin_evidencia": 2,
  "hallazgos_criticos": ["hallazgo 1", "..."],
  "preguntas_globales_dimension": ["¿Pregunta global 1?", "..."]
}}"""
