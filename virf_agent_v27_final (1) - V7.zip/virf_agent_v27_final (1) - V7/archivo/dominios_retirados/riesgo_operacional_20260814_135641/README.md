# Riesgo Operacional

OpRisk avanzado

Dominio creado por `T5443` el 2026-08-14.

Sube papers, estándares y documentos técnicos en esta carpeta y reconstruye el índice: `python scripts/rebuild_rag_databricks.py --dominio riesgo_operacional --force`.
