"""
⚠️  MÓDULO NO ACTIVO EN EL PIPELINE ACTUAL  ⚠️
────────────────────────────────────────────────────────────────────────────
Este generador Word NO se invoca desde agente.py ni desde modulos/.
El informe Word que produce el pipeline lo genera `modulos/generador_word.py`.

Se conserva porque implementa el formato Mx_* (dimensiones/síntesis) usado por
`Mx_03.generar_sintesis()`, que también está fuera del flujo principal.

Antes de modificar o borrar este archivo, comprobar con:
    grep -rn "Mx_05_GeneradorWord" --include="*.py" .
────────────────────────────────────────────────────────────────────────────

Mx_05_GeneradorWord.py
=======================
Generador de informes Word para el pipeline Motor VIRF.
Convierte los JSON de salida del motor (sintesis + resultados por dimensión)
en un documento .docx estructurado con portada, semáforos, tablas de
hallazgos, plan de acción y dictamen final.

Responsabilidades:
  - Proveer la clase GeneradorWord con interfaz .generar(...)
  - Proveer la función generar_word_informe(...) — nombre FIJO, no cambiar
  - Mantener paleta corporativa: Azul oscuro / Azul medio / Gris texto

Uso desde main.ipynb (Celda 10):
    from Mx_05_GeneradorWord import GeneradorWord, generar_word_informe

    gen   = GeneradorWord(outputs_dir)
    ruta  = gen.generar(titulo=TITULO_MODELO, sintesis=sintesis,
                        resultados=resultados, tier=TIER,
                        cuestionamientos=cuestionamientos)

    # ─── o directamente ───────────────────────────────────────────
    ruta  = generar_word_informe(sintesis=sintesis, resultados=resultados,
                                 titulo=TITULO_MODELO, tier=TIER,
                                 outputs_dir=outputs_dir,
                                 cuestionamientos=cuestionamientos)

Dependencias: python-docx  (pip install python-docx)
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor


# ─── Paleta corporativa ───────────────────────────────────────────────────────
AZUL_DARK  = RGBColor(0x1F, 0x38, 0x64)
AZUL_MID   = RGBColor(0x2E, 0x75, 0xB6)
AZUL_LIGHT = RGBColor(0xBD, 0xD7, 0xEE)
VERDE      = RGBColor(0x37, 0x86, 0x44)
AMARILLO   = RGBColor(0xFF, 0xC0, 0x00)
ROJO       = RGBColor(0xC0, 0x00, 0x00)
GRIS_TEXT  = RGBColor(0x40, 0x40, 0x40)
BLANCO     = RGBColor(0xFF, 0xFF, 0xFF)

_HEX = {
    "azul_dark":  "1F3864",
    "azul_mid":   "2E75B6",
    "azul_light": "BDD7EE",
    "verde":      "378644",
    "amarillo":   "FFC000",
    "rojo":       "C00000",
    "gris":       "CCCCCC",
    "gris_claro": "F2F2F2",
    "blanco":     "FFFFFF",
}

_ESTADO_COLOR = {
    "Cumple":                     _HEX["verde"],
    "Parcial":                    _HEX["amarillo"],
    "No cumple":                  _HEX["rojo"],
    "Solicitar Actas":            _HEX["rojo"],
    "APROBADO":                   _HEX["verde"],
    "APROBADO CON OBSERVACIONES": _HEX["amarillo"],
    "RECHAZADO":                  _HEX["rojo"],
    "VALIDACIÓN INSUFICIENTE":    _HEX["rojo"],
    "Alto":                       _HEX["rojo"],
    "Medio":                      _HEX["amarillo"],
    "Bajo":                       _HEX["verde"],
    "Crítico":                    _HEX["rojo"],
}

_CRIT_COLOR = {
    "Alta":     _HEX["rojo"],
    "Media":    _HEX["amarillo"],
    "Baja":     _HEX["verde"],
    "CRITICA":  _HEX["rojo"],
    "MODERADA": _HEX["amarillo"],
    "BAJA":     _HEX["verde"],
    "POTENCIAL": _HEX["gris"],
}

_PRIORIDAD_COLOR = {
    "INMEDIATA": _HEX["rojo"],
    "30D":       _HEX["amarillo"],
    "90D":       _HEX["verde"],
}


# ─── Helpers de formato ───────────────────────────────────────────────────────

def _set_cell_bg(cell, hex_color: str) -> None:
    """Aplica color de fondo a una celda Word."""
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd  = OxmlElement("w:shd")
    shd.set(qn("w:val"),   "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"),  hex_color.upper().lstrip("#"))
    tcPr.append(shd)


def _add_run(para, text: str, *, bold=False, italic=False,
             size: int = 10, color: RGBColor = None, font="Arial") -> None:
    """Agrega un run formateado a un párrafo."""
    run = para.add_run(str(text))
    run.bold            = bold
    run.italic          = italic
    run.font.size       = Pt(size)
    run.font.name       = font
    run.font.color.rgb  = color if color else GRIS_TEXT


def _heading(doc: Document, text: str, level: int = 1) -> None:
    """Encabezado con color corporativo."""
    p     = doc.add_heading(text, level=level)
    color = AZUL_DARK if level == 1 else AZUL_MID
    for run in p.runs:
        run.font.color.rgb = color
        run.font.name      = "Arial"
    p.paragraph_format.space_before = Pt(12 if level == 1 else 8)
    p.paragraph_format.space_after  = Pt(6)


def _paragraph(doc: Document, text: str, *, bold=False, italic=False,
               color: RGBColor = None, size: int = 10,
               align: WD_ALIGN_PARAGRAPH = WD_ALIGN_PARAGRAPH.JUSTIFY) -> None:
    p = doc.add_paragraph()
    p.alignment = align
    _add_run(p, text, bold=bold, italic=italic, size=size, color=color)
    p.paragraph_format.space_after = Pt(4)


def _hrule(doc: Document, color_hex: str = "2E75B6") -> None:
    """Línea separadora horizontal (borde inferior de párrafo)."""
    p   = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pb  = OxmlElement("w:pBdr")
    bot = OxmlElement("w:bottom")
    bot.set(qn("w:val"),   "single")
    bot.set(qn("w:sz"),    "6")
    bot.set(qn("w:space"), "1")
    bot.set(qn("w:color"), color_hex)
    pb.append(bot)
    pPr.append(pb)


def _cell_write(cell, text: str, *, bold=False, size=9,
                color: RGBColor = None,
                align: WD_ALIGN_PARAGRAPH = WD_ALIGN_PARAGRAPH.LEFT) -> None:
    """Escribe texto en celda limpiando el párrafo previo."""
    cell.text = ""
    p = cell.paragraphs[0]
    p.alignment = align
    _add_run(p, str(text) if text else "—", bold=bold, size=size, color=color)


def _make_table(doc: Document, headers: list, col_widths_cm: list):
    """Crea tabla con fila de encabezado en azul oscuro."""
    tabla = doc.add_table(rows=1, cols=len(headers))
    tabla.style     = "Table Grid"
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, (h, w) in enumerate(zip(headers, col_widths_cm)):
        cell = tabla.rows[0].cells[i]
        cell.width = Cm(w)
        _set_cell_bg(cell, _HEX["azul_dark"])
        _cell_write(cell, h, bold=True, size=9, color=BLANCO,
                    align=WD_ALIGN_PARAGRAPH.CENTER)
    return tabla


# ─── Secciones del documento ──────────────────────────────────────────────────

def _portada(doc: Document, titulo: str, tier: str) -> None:
    """Portada corporativa."""
    for _ in range(6):
        doc.add_paragraph()

    p1 = doc.add_paragraph()
    p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r1 = p1.add_run("INFORME DE VALIDACIÓN VIRF")
    r1.font.size      = Pt(24)
    r1.font.bold      = True
    r1.font.color.rgb = AZUL_DARK
    r1.font.name      = "Arial"

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run(titulo)
    r2.font.size      = Pt(18)
    r2.font.color.rgb = AZUL_MID
    r2.font.name      = "Arial"

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r3 = p3.add_run(f"Tier {tier}")
    r3.font.size      = Pt(14)
    r3.font.color.rgb = AZUL_MID
    r3.font.name      = "Arial"

    for _ in range(3):
        doc.add_paragraph()

    _hrule(doc)

    p4 = doc.add_paragraph()
    p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r4 = p4.add_run(
        f"Fecha de emisión: {datetime.now().strftime('%d/%m/%Y')}\n"
        "Validación Independiente de Riesgo Financiero (VIRF)\n"
        "Segunda Línea de Defensa"
    )
    r4.font.size      = Pt(11)
    r4.font.italic    = True
    r4.font.color.rgb = GRIS_TEXT
    r4.font.name      = "Arial"

    doc.add_page_break()


def _seccion_resumen_ejecutivo(doc: Document, sintesis: dict) -> None:
    """Bloque de resumen ejecutivo con dictamen y nivel de riesgo."""
    _heading(doc, "1. RESUMEN EJECUTIVO", level=1)

    tabla = _make_table(doc, ["DICTAMEN GLOBAL", "NIVEL DE RIESGO"], [9.0, 8.5])
    row   = tabla.add_row().cells
    dictamen = sintesis.get("dictamen_global", "—")
    riesgo   = sintesis.get("nivel_riesgo", "—")

    _set_cell_bg(row[0], _ESTADO_COLOR.get(dictamen, _HEX["gris"]))
    _cell_write(row[0], dictamen, bold=True, size=11, color=BLANCO,
                align=WD_ALIGN_PARAGRAPH.CENTER)

    _set_cell_bg(row[1], _ESTADO_COLOR.get(riesgo, _HEX["gris"]))
    _cell_write(row[1], riesgo, bold=True, size=11, color=BLANCO,
                align=WD_ALIGN_PARAGRAPH.CENTER)

    doc.add_paragraph()

    resumen = sintesis.get("resumen_ejecutivo", "")
    if resumen:
        for parrafo in resumen.split("\n\n"):
            if parrafo.strip():
                _paragraph(doc, parrafo.strip())

    justif = sintesis.get("justificacion_dictamen", "")
    if justif:
        _paragraph(doc, "Justificación del Dictamen:", bold=True, size=10, color=AZUL_MID)
        _paragraph(doc, justif)


def _seccion_resultados_dimension(doc: Document, resultados: dict) -> None:
    """Tabla resumen de cumplimiento por dimensión."""
    _heading(doc, "2. RESULTADOS POR DIMENSIÓN", level=1)

    headers    = ["DIMENSIÓN", "CUMPLIMIENTO (%)", "SIN EVIDENCIA", "HALLAZGOS CRÍTICOS"]
    col_widths = [6.5, 3.5, 3.5, 4.0]
    tabla = _make_table(doc, headers, col_widths)

    for dimension, res in resultados.items():
        pct    = res.get("nivel_cumplimiento", 0)
        sin_ev = res.get("actividades_sin_evidencia", 0)
        hall   = len(res.get("hallazgos_criticos", []))

        row = tabla.add_row().cells
        _cell_write(row[0], dimension, size=9)
        _cell_write(row[1], f"{pct}%", size=9, align=WD_ALIGN_PARAGRAPH.CENTER)
        _cell_write(row[2], str(sin_ev), size=9, align=WD_ALIGN_PARAGRAPH.CENTER)
        _cell_write(row[3], str(hall), size=9, align=WD_ALIGN_PARAGRAPH.CENTER)

        # Semáforo de cumplimiento
        if pct >= 80:
            _set_cell_bg(row[1], _HEX["verde"])
            row[1].paragraphs[0].runs[0].font.color.rgb = BLANCO
        elif pct >= 50:
            _set_cell_bg(row[1], _HEX["amarillo"])
        else:
            _set_cell_bg(row[1], _HEX["rojo"])
            row[1].paragraphs[0].runs[0].font.color.rgb = BLANCO

    doc.add_paragraph()


def _seccion_evaluaciones_detalladas(doc: Document, resultados: dict) -> None:
    """Detalle de evaluaciones control por control, dimensión por dimensión."""
    _heading(doc, "3. EVALUACIONES DETALLADAS POR DIMENSIÓN", level=1)

    for idx, (dimension, res) in enumerate(resultados.items(), 1):
        _heading(doc, f"3.{idx}  {dimension}", level=2)

        resumen_dim = res.get("resumen_dimension", "")
        if resumen_dim:
            _paragraph(doc, resumen_dim, italic=True, size=9, color=GRIS_TEXT)

        evaluaciones = res.get("evaluaciones", [])
        if not evaluaciones:
            _paragraph(doc, "Sin evaluaciones registradas para esta dimensión.")
            continue

        headers    = ["CONTROL", "ACTIVIDAD", "ESTADO", "EVIDENCIA",
                      "OBSERVACIÓN TÉCNICA", "RIESGO"]
        col_widths = [3.5, 4.0, 2.0, 3.5, 4.5, 2.0]
        tabla = _make_table(doc, headers, col_widths)

        for ev in evaluaciones:
            estado       = ev.get("estado", "—")
            color_estado = _ESTADO_COLOR.get(estado, _HEX["gris"])

            row = tabla.add_row().cells
            _cell_write(row[0], ev.get("control", "—"), size=8)
            _cell_write(row[1], ev.get("actividad", "—"), size=8)

            _set_cell_bg(row[2], color_estado)
            _cell_write(row[2], f"{ev.get('simbolo','')} {estado}",
                        bold=True, size=8, color=BLANCO,
                        align=WD_ALIGN_PARAGRAPH.CENTER)

            _cell_write(row[3], ev.get("evidencia") or "Sin evidencia", size=8)
            _cell_write(row[4], ev.get("observacion_tecnica", "—"), size=8)

            riesgo = ev.get("riesgo", "—")
            _set_cell_bg(row[5], _ESTADO_COLOR.get(riesgo, _HEX["gris"]))
            _cell_write(row[5], riesgo, size=8, bold=True, color=BLANCO,
                        align=WD_ALIGN_PARAGRAPH.CENTER)

        doc.add_paragraph()

        # Preguntas pendientes de la dimensión
        preguntas = res.get("preguntas_globales_dimension", [])
        if preguntas:
            _paragraph(doc, "Requerimientos de información pendientes:",
                       bold=True, size=9, color=AZUL_MID)
            for i, preg in enumerate(preguntas, 1):
                p = doc.add_paragraph(style="List Number")
                _add_run(p, preg, size=9)

        doc.add_paragraph()


def _seccion_hallazgos_principales(doc: Document, sintesis: dict) -> None:
    """Tabla de hallazgos principales con severidad."""
    _heading(doc, "4. HALLAZGOS PRINCIPALES", level=1)

    hallazgos = sintesis.get("principales_hallazgos", [])
    if not hallazgos:
        _paragraph(doc, "No se registraron hallazgos críticos en esta validación.")
        return

    headers    = ["ID", "DIMENSIÓN", "HALLAZGO", "SEVERIDAD", "ACCIÓN REQUERIDA"]
    col_widths = [1.5, 3.0, 6.0, 2.5, 4.5]
    tabla = _make_table(doc, headers, col_widths)

    for h in hallazgos:
        sev = h.get("severidad", "—")
        row = tabla.add_row().cells
        _cell_write(row[0], h.get("id", "—"), size=8, bold=True,
                    align=WD_ALIGN_PARAGRAPH.CENTER)
        _cell_write(row[1], h.get("dimension", "—"), size=8)
        _cell_write(row[2], h.get("hallazgo", "—"), size=8)

        _set_cell_bg(row[3], _CRIT_COLOR.get(sev, _HEX["gris"]))
        _cell_write(row[3], sev, size=8, bold=True, color=BLANCO,
                    align=WD_ALIGN_PARAGRAPH.CENTER)
        _cell_write(row[4], h.get("accion", "—"), size=8)

    doc.add_paragraph()


def _seccion_informacion_requerida(doc: Document, sintesis: dict) -> None:
    """Preguntas y requerimientos de información al modelador."""
    _heading(doc, "5. REQUERIMIENTOS DE INFORMACIÓN AL MODELADOR", level=1)
    _paragraph(
        doc,
        "Los siguientes requerimientos deben ser respondidos por el equipo modelador "
        "antes del cierre del proceso de validación:",
        italic=True, size=9,
    )

    info_req = sintesis.get("informacion_requerida", [])
    if not info_req:
        _paragraph(doc, "Sin requerimientos de información pendientes.")
        return

    headers    = ["DIMENSIÓN", "REQUERIMIENTO / PREGUNTA", "CRITICIDAD", "ACTIVIDAD ORIGEN"]
    col_widths = [3.5, 7.0, 2.5, 4.5]
    tabla = _make_table(doc, headers, col_widths)

    for req in info_req:
        crit = req.get("criticidad", "—")
        row  = tabla.add_row().cells
        _cell_write(row[0], req.get("dimension", "—"), size=8)
        _cell_write(row[1], req.get("pregunta", "—"), size=8)

        _set_cell_bg(row[2], _CRIT_COLOR.get(crit, _HEX["gris"]))
        _cell_write(row[2], crit, size=8, bold=True, color=BLANCO,
                    align=WD_ALIGN_PARAGRAPH.CENTER)
        _cell_write(row[3], req.get("actividad_origen", "—"), size=8)

    doc.add_paragraph()


def _seccion_plan_accion(doc: Document, sintesis: dict) -> None:
    """Plan de acción con responsables, plazos y prioridades."""
    _heading(doc, "6. PLAN DE ACCIÓN", level=1)

    plan = sintesis.get("plan_accion", [])
    if not plan:
        _paragraph(doc, "Sin acciones definidas en el plan de acción.")
        return

    headers    = ["N°", "ACCIÓN", "RESPONSABLE", "PLAZO", "PRIORIDAD"]
    col_widths = [1.0, 7.0, 3.5, 2.5, 2.5]
    tabla = _make_table(doc, headers, col_widths)

    for item in plan:
        prioridad = str(item.get("prioridad", "—")).upper()
        row = tabla.add_row().cells
        _cell_write(row[0], str(item.get("item", "—")), size=8,
                    align=WD_ALIGN_PARAGRAPH.CENTER)
        _cell_write(row[1], item.get("accion", "—"), size=8)
        _cell_write(row[2], item.get("responsable", "—"), size=8)
        _cell_write(row[3], item.get("plazo", "—"), size=8,
                    align=WD_ALIGN_PARAGRAPH.CENTER)

        _set_cell_bg(row[4], _PRIORIDAD_COLOR.get(prioridad, _HEX["gris"]))
        _cell_write(row[4], prioridad, size=8, bold=True, color=BLANCO,
                    align=WD_ALIGN_PARAGRAPH.CENTER)

    doc.add_paragraph()


def _seccion_cuestionamientos(doc: Document, cuestionamientos: dict) -> None:
    """
    Sección de alertas metodológicas detectadas por Mx_04 (sin API).
    cuestionamientos: dict {archivo: {"alertas_rapidas": [lista_alertas]}}
    """
    todas_alertas = [
        {**alerta, "archivo": archivo}
        for archivo, analisis in cuestionamientos.items()
        for alerta in analisis.get("alertas_rapidas", [])
    ]
    if not todas_alertas:
        return

    _heading(doc, "7. ALERTAS METODOLÓGICAS AUTOMÁTICAS (Motor Mx_04)", level=1)
    _paragraph(
        doc,
        "Las siguientes alertas fueron detectadas automáticamente por análisis estático "
        "de los scripts del modelador, sin intervención de la IA:",
        italic=True, size=9,
    )

    headers    = ["TIPO", "CONTEXTO", "ARCHIVO", "CRÍTICA TÉCNICA"]
    col_widths = [2.0, 4.0, 3.5, 8.0]
    tabla = _make_table(doc, headers, col_widths)

    for alerta in todas_alertas:
        tipo  = alerta.get("tipo", "—")
        color = _HEX["rojo"] if tipo == "presencia" else _HEX["amarillo"]
        row   = tabla.add_row().cells
        _set_cell_bg(row[0], color)
        label = "DETECTADO" if tipo == "presencia" else "AUSENTE"
        _cell_write(row[0], label, size=8, bold=True, color=BLANCO,
                    align=WD_ALIGN_PARAGRAPH.CENTER)
        _cell_write(row[1], alerta.get("contexto", "—"), size=8)
        _cell_write(row[2], alerta.get("archivo", "—"), size=8)
        _cell_write(row[3], alerta.get("critica", "—"), size=8)

    doc.add_paragraph()


def _seccion_conclusion(doc: Document, sintesis: dict) -> None:
    """Dictamen final y conclusión narrativa."""
    _heading(doc, "8. CONCLUSIÓN Y DICTAMEN FINAL", level=1)
    _hrule(doc)

    dictamen = sintesis.get("dictamen_global", "—")
    color    = _ESTADO_COLOR.get(dictamen, _HEX["gris"])

    # Caja de dictamen
    tabla = _make_table(doc, ["DICTAMEN FINAL"], [17.5])
    row   = tabla.add_row().cells
    _set_cell_bg(row[0], color)
    _cell_write(row[0], dictamen, bold=True, size=16, color=BLANCO,
                align=WD_ALIGN_PARAGRAPH.CENTER)
    doc.add_paragraph()

    # Conclusión narrativa
    concl = sintesis.get("conclusion_narrativa", "")
    if concl:
        _paragraph(doc, concl)

    proxima = sintesis.get("proxima_revision", "")
    if proxima:
        _paragraph(doc, f"Próxima revisión sugerida: {proxima}",
                   italic=True, size=9, color=AZUL_MID)

    doc.add_paragraph()
    _hrule(doc)

    # Firma del agente
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    _add_run(
        p,
        f"Validación VIRF — Segunda Línea de Defensa\n"
        f"Emitido: {datetime.now().strftime('%d/%m/%Y %H:%M')}",
        italic=True, size=8, color=GRIS_TEXT,
    )


# ─── Clase pública ────────────────────────────────────────────────────────────

class GeneradorWord:
    """
    Interfaz OOP para la generación del informe Word Motor VIRF.

    Uso:
        gen  = GeneradorWord(outputs_dir)
        ruta = gen.generar(titulo=..., sintesis=..., resultados=..., tier=...,
                           cuestionamientos=...)
    """

    def __init__(self, outputs_dir: Path) -> None:
        self.outputs_dir = Path(outputs_dir)
        self.outputs_dir.mkdir(parents=True, exist_ok=True)

    def generar(
        self,
        titulo: str,
        sintesis: dict,
        resultados: dict,
        tier: str = "—",
        cuestionamientos: Optional[dict] = None,
    ) -> Path:
        """
        Genera el informe Word a partir del JSON del motor.

        Args:
            titulo:           Nombre lógico del modelo.
            sintesis:         dict retornado por generar_sintesis() en Mx_03.
            resultados:       dict {dimension: resultado} de evaluar_dimension().
            tier:             Tier del modelo (I, II, III, IV).
            cuestionamientos: dict de alertas de Mx_04 (opcional).

        Returns:
            Path al archivo .docx generado.
        """
        return generar_word_informe(
            sintesis=sintesis,
            resultados=resultados,
            titulo=titulo,
            tier=tier,
            outputs_dir=self.outputs_dir,
            cuestionamientos=cuestionamientos or {},
        )


# ─── Función pública — nombre FIJO, NO cambiar ───────────────────────────────

def generar_word_informe(
    sintesis: dict,
    resultados: dict,
    titulo: str,
    tier: str,
    outputs_dir: Path,
    cuestionamientos: Optional[dict] = None,
) -> Path:
    """
    Genera el informe Word del Motor VIRF a partir de los JSON de salida.

    Args:
        sintesis:         dict de síntesis global (Mx_03.generar_sintesis).
        resultados:       dict {dimension: resultado} (Mx_03.evaluar_dimension).
        titulo:           Nombre lógico del modelo.
        tier:             Tier (I, II, III, IV).
        outputs_dir:      Carpeta de destino.
        cuestionamientos: Alertas estáticas Mx_04 (opcional).

    Returns:
        Path al archivo .docx generado en outputs_dir.
    """
    cuestionamientos = cuestionamientos or {}
    outputs_dir      = Path(outputs_dir)
    outputs_dir.mkdir(parents=True, exist_ok=True)

    fecha_str = datetime.now().strftime("%d%m%Y")
    nombre    = f"VIRF_Informe_{titulo.replace(' ', '_')}_{fecha_str}.docx"
    ruta      = outputs_dir / nombre

    doc = Document()

    # Márgenes corporativos
    for section in doc.sections:
        section.top_margin    = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin   = Cm(3.0)
        section.right_margin  = Cm(2.5)

    # ── Construir documento ──────────────────────────────────────────────────
    _portada(doc, titulo, tier)

    _seccion_resumen_ejecutivo(doc, sintesis)
    doc.add_page_break()

    _seccion_resultados_dimension(doc, resultados)
    doc.add_paragraph()

    _seccion_evaluaciones_detalladas(doc, resultados)
    doc.add_page_break()

    _seccion_hallazgos_principales(doc, sintesis)
    doc.add_paragraph()

    _seccion_informacion_requerida(doc, sintesis)
    doc.add_page_break()

    _seccion_plan_accion(doc, sintesis)

    if cuestionamientos:
        _seccion_cuestionamientos(doc, cuestionamientos)

    _seccion_conclusion(doc, sintesis)

    doc.save(ruta)
    print(f"  ✓ Word generado → {ruta.name}")
    return ruta
