"""
modulos/lector_inputs.py
Lee y extrae texto de PDF, DOCX, PPTX, XLSX, PY, JSON, TXT, CSV
"""

import json
import csv
from pathlib import Path
from typing import Dict, List

# ─── Importaciones opcionales ────────────────────────────────────────────────
try:
    import pdfplumber
    PDF_OK = True
except ImportError:
    PDF_OK = False

try:
    from docx import Document
    DOCX_OK = True
except ImportError:
    DOCX_OK = False

try:
    from pptx import Presentation
    PPTX_OK = True
except ImportError:
    PPTX_OK = False

try:
    import openpyxl
    XLSX_OK = True
except ImportError:
    XLSX_OK = False


def leer_pdf(path: Path) -> str:
    if not PDF_OK:
        return f"[ERROR] pdfplumber no instalado. pip install pdfplumber"
    texto = []
    try:
        with pdfplumber.open(path) as pdf:
            for i, page in enumerate(pdf.pages):
                t = page.extract_text()
                if t:
                    texto.append(f"[Pág. {i+1}]\n{t}")
        return "\n\n".join(texto)
    except Exception as e:
        return f"[ERROR PDF] {e}"


def leer_docx(path: Path) -> str:
    if not DOCX_OK:
        return f"[ERROR] python-docx no instalado. pip install python-docx"
    try:
        doc = Document(path)
        parrafos = [p.text for p in doc.paragraphs if p.text.strip()]
        # Incluir tablas
        for table in doc.tables:
            for row in table.rows:
                celdas_texto = [c.text.strip() for c in row.cells if c.text.strip()]
                if celdas_texto:  # Solo agregar si hay texto en la fila
                    parrafos.append(" | ".join(celdas_texto))
        
        # Filtrar None values como precaución
        parrafos = [p for p in parrafos if p is not None]
        return "\n".join(parrafos) if parrafos else "[Documento vacío o sin texto]"
    except Exception as e:
        return f"[ERROR DOCX] {e}"


def leer_pptx(path: Path) -> str:
    if not PPTX_OK:
        return f"[ERROR] python-pptx no instalado. pip install python-pptx"
    try:
        prs = Presentation(path)
        slides = []
        for i, slide in enumerate(prs.slides):
            textos = []
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    textos.append(shape.text.strip())
            if textos:
                slides.append(f"[Diapositiva {i+1}]\n" + "\n".join(textos))
        return "\n\n".join(slides)
    except Exception as e:
        return f"[ERROR PPTX] {e}"


def leer_xlsx(path: Path) -> str:
    if not XLSX_OK:
        return f"[ERROR] openpyxl no instalado."
    try:
        wb = openpyxl.load_workbook(path, data_only=True)
        resultado = []
        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            resultado.append(f"[Hoja: {sheet_name}]")
            for row in ws.iter_rows(values_only=True):
                fila = [str(c) if c is not None else "" for c in row]
                if any(f.strip() for f in fila):
                    resultado.append("\t".join(fila))
        return "\n".join(resultado)
    except Exception as e:
        return f"[ERROR XLSX] {e}"


def leer_py(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as e:
        return f"[ERROR PY] {e}"


def leer_json(path: Path) -> str:
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return json.dumps(data, ensure_ascii=False, indent=2)
    except Exception as e:
        return f"[ERROR JSON] {e}"


def leer_csv(path: Path) -> str:
    try:
        with open(path, encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            rows = ["\t".join(r) for r in reader]
        return "\n".join(rows[:200])  # Máx 200 filas para no saturar contexto
    except Exception as e:
        return f"[ERROR CSV] {e}"


def leer_txt(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as e:
        return f"[ERROR TXT] {e}"


LECTORES = {
    ".pdf":  leer_pdf,
    ".docx": leer_docx,
    ".pptx": leer_pptx,
    ".xlsx": leer_xlsx,
    ".xlsm": leer_xlsx,
    ".py":   leer_py,
    ".json": leer_json,
    ".csv":  leer_csv,
    ".txt":  leer_txt,
}


def leer_archivo(path: Path) -> str:
    """Lee un archivo y retorna su contenido como texto."""
    ext = path.suffix.lower()
    lector = LECTORES.get(ext)
    if lector:
        contenido = lector(path)
        return f"{'='*60}\nARCHIVO: {path.name}\n{'='*60}\n{contenido}"
    return f"[SKIP] Formato no soportado: {path.name}"


def leer_directorio(directorio: Path, max_chars: int = 80_000) -> Dict[str, str]:
    """
    Lee todos los archivos soportados de un directorio.
    Retorna dict {nombre_archivo: contenido}.
    max_chars limita el total para no saturar el contexto del modelo.
    """
    resultado = {}
    total = 0
    if not directorio.exists():
        return resultado

    archivos = sorted(directorio.rglob("*"))
    for path in archivos:
        if path.is_file() and path.suffix.lower() in LECTORES:
            contenido = leer_archivo(path)
            resultado[path.name] = contenido
            total += len(contenido)
            if total > max_chars:
                resultado["__TRUNCADO__"] = f"[AVISO] Se alcanzó el límite de {max_chars} chars. Archivos posteriores omitidos."
                break
    return resultado


def consolidar_contexto(dirs_contenido: Dict[str, Dict[str, str]]) -> str:
    """Consolida múltiples directorios en un único bloque de texto para el modelo."""
    bloques = []
    for seccion, archivos in dirs_contenido.items():
        if archivos:
            bloques.append(f"\n{'#'*70}\nSECCIÓN: {seccion.upper()}\n{'#'*70}")
            for nombre, contenido in archivos.items():
                bloques.append(contenido)
    return "\n".join(bloques)


def cargar_todos_los_inputs(inputs_config: dict) -> Dict[str, Dict[str, str]]:
    """Carga todos los inputs definidos en config.INPUTS"""
    resultado = {}
    for seccion, path in inputs_config.items():
        p = Path(path)
        resultado[seccion] = leer_directorio(p)
    return resultado
