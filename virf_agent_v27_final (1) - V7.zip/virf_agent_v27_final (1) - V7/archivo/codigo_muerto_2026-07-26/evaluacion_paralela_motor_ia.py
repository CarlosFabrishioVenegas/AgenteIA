"""
evaluacion_paralela_motor_ia.py — EXTRAÍDO DE modulos/motor_ia.py (2026-07-27)
═══════════════════════════════════════════════════════════════════════════════
CÓDIGO RETIRADO — no estaba conectado al flujo y era incompatible con las
garantías vigentes del pipeline.

POR QUÉ SE RETIRÓ (auditoría D3):
  1. NADIE lo llamaba. `agente.py` implementa el flujo secuencial inline y nunca
     invoca `orquestar_pipeline_ambitos()`. Las únicas referencias estaban
     dentro de DOCSTRINGS (motor_ia.py:55-56 y :1390-1391).
  2. Sacrifica la memoria intra-ámbito por diseño (ver docstring original):
     cada actividad deja de ver los hallazgos de las anteriores.
  3. No acepta `cobertura_docs` → perdería la propagación de cobertura real
     añadida en [COBERTURA-FIX].
  4. PELIGROSO: ante una excepción asignaba `puntaje: 1` — exactamente el
     antipatrón que [CONTRATO-FIX] eliminó. Un fallo de red se convertía en
     "No cumple" dentro de un dictamen regulatorio.

DÓNDE SÍ CONVIENE PARALELIZAR:
  A nivel de CHUNKS, no de actividades. Los segmentos de un documento son
  independientes entre sí y son los que dominan el coste (~57 llamadas para un
  manual de 300 páginas). Las actividades, en cambio, dependen unas de otras
  por la memoria intra-ámbito.

Se conserva como referencia por si se retoma la paralelización.
═══════════════════════════════════════════════════════════════════════════════
"""

# ═══════════════════════════════════════════════════════════════════════════════
# [D5-FIX] EVALUACIÓN PARALELA DE ÁMBITOS
# Reduce tiempo de 25-40 min → 6-10 min usando ThreadPoolExecutor.
# Los ámbitos son independientes entre sí (salvo contexto_global que se construye
# secuencialmente). Las actividades dentro de cada ámbito se evalúan en paralelo.
# ═══════════════════════════════════════════════════════════════════════════════

import concurrent.futures
import threading

# Lock para prints thread-safe
_print_lock = threading.Lock()

def _evaluar_actividad_thread_safe(args_dict: dict) -> dict:
    """Wrapper thread-safe para evaluar_actividad (para ThreadPoolExecutor)."""
    resultado = evaluar_actividad(
        actividad       = args_dict["actividad"],
        ambito          = args_dict["ambito"],
        control         = args_dict["control"],
        contexto        = args_dict["contexto"],
        titulo_modelo   = args_dict["titulo_modelo"],
        modo_preprdc    = args_dict["modo_preprdc"],
        contexto_ambito = args_dict.get("contexto_ambito", []),
    )
    resultado["actividad"] = args_dict["actividad"]
    resultado["control"]   = args_dict["control"]
    with _print_lock:
        pje = resultado.get("puntaje", "?")
        print(f"    ✓ [{args_dict['ambito']}] {args_dict['actividad'][:60]}... → {pje}/5")
    return resultado


def evaluar_ambito_paralelo(
    ambito:        str,
    actividades:   List[Dict],
    contexto:      str,
    titulo_modelo: str,
    modo_preprdc:  bool = True,
    max_workers:   int  = 4,
) -> List[Dict]:
    """
    [D5-FIX] Versión paralela de evaluar_ambito_completo.

    Evalúa todas las actividades de un ámbito en paralelo (ThreadPoolExecutor).
    No soporta memoria intra-ámbito (se sacrifica para ganar velocidad).
    Usar evaluar_ambito_completo() si se necesita razonamiento encadenado.

    Args:
        max_workers: hilos concurrentes por ámbito. Default=4.
                     Ajustar según rate-limit de la API.
    """
    import os as _os
    workers = int(_os.getenv("VIRF_WORKERS", str(max_workers)))

    args_list = [
        {
            "actividad":    act["actividad"],
            "ambito":       ambito,
            "control":      act.get("control", ""),
            "contexto":     contexto,
            "titulo_modelo": titulo_modelo,
            "modo_preprdc": modo_preprdc,
        }
        for act in actividades
    ]

    resultados = [None] * len(args_list)  # mantener orden original

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        future_to_idx = {
            executor.submit(_evaluar_actividad_thread_safe, args): i
            for i, args in enumerate(args_list)
        }
        for future in concurrent.futures.as_completed(future_to_idx):
            idx = future_to_idx[future]
            try:
                resultados[idx] = future.result()
            except Exception as exc:
                with _print_lock:
                    print(f"  ✗ Error en actividad {idx}: {exc}")
                resultados[idx] = {
                    "puntaje": 1,
                    "concepto": "Error en evaluación paralela",
                    "observacion": str(exc),
                    "evidencia_encontrada": "",
                    "preguntas_pendientes": [],
                    "recomendacion": "Reintentar la evaluación",
                    "actividad": args_list[idx]["actividad"],
                    "control": args_list[idx]["control"],
                }

    return [r for r in resultados if r is not None]


def evaluar_todos_ambitos_paralelo(
    ambitos_data:  dict,
    todos_inputs:  dict,
    titulo_modelo: str,
    modo_preprdc:  bool = True,
    max_workers:   int  = 4,
) -> dict:
    """
    [D5-FIX] Evalúa todos los ámbitos en paralelo.

    Estrategia de dos niveles:
      1. Ámbitos en paralelo (ThreadPoolExecutor de ámbitos)
      2. Actividades dentro de cada ámbito en paralelo (ThreadPoolExecutor de actividades)

    Tiempo estimado: 25-40 min → 6-10 min con 4 workers por nivel.

    Returns:
        Dict {ambito: [lista de evaluaciones]}
    """
    from motor.Mx_01_LecturaEvidencias import inputs_para_dimension
    import os as _os

    ambito_workers = int(_os.getenv("VIRF_AMBITO_WORKERS", "3"))  # ámbitos en paralelo

    def _evaluar_un_ambito(ambito_actividades_tuple):
        ambito, actividades = ambito_actividades_tuple
        acts_requeridas = [a for a in actividades if a.get("requerida", True)]
        if not acts_requeridas:
            return ambito, []

        docs_ambito = inputs_para_dimension(todos_inputs, ambito)
        import os as _os2
        from config import MAX_CHARS_DOC
        MAX_CTX = int(_os2.getenv("VIRF_MAX_CTX", str(MAX_CHARS_DOC)))
        contexto_partes = []
        chars = 0
        for d in docs_ambito:
            if chars + len(d.get("contenido", "")) > MAX_CTX and contexto_partes:
                break
            contexto_partes.append(f"[{d['nombre']}]\n{d.get('contenido','')}")
            chars += len(d.get("contenido", ""))
        contexto = "\n".join(contexto_partes)

        with _print_lock:
            print(f"\n🔍 [PARALELO] {ambito} — {len(acts_requeridas)} actividades | {chars:,} chars")

        evals = evaluar_ambito_paralelo(
            ambito        = ambito,
            actividades   = acts_requeridas,
            contexto      = contexto,
            titulo_modelo = titulo_modelo,
            modo_preprdc  = modo_preprdc,
            max_workers   = max_workers,
        )
        return ambito, evals

    resultados = {}
    items = list(ambitos_data.items())

    with concurrent.futures.ThreadPoolExecutor(max_workers=ambito_workers) as executor:
        for ambito, evals in executor.map(_evaluar_un_ambito, items):
            resultados[ambito] = evals

    return resultados


# ══════════════════════════════════════════════════════════════════════════════
# ORQUESTADORES — fachada unificada para los dos pipelines
#
# Estos métodos son el punto de entrada preferido para código externo
# (notebooks Databricks, tests, agente.py). Evitan importar motor_ia_v2

# ═════════════════════════════════════════════════════════════════
# orquestar_pipeline_ambitos() — retirada junto con el bloque paralelo.
# Quedó ROTA al eliminar evaluar_todos_ambitos_paralelo(), a la que
# llamaba cuando paralelo=True. Nadie la invocaba: agente.py implementa
# el flujo de ámbitos inline.
# ═════════════════════════════════════════════════════════════════

def orquestar_pipeline_ambitos(
    titulo_modelo:   str,
    tier:            str,
    modo_preprdc:    bool  = True,
    paralelo:        bool  = False,
    max_workers:     int   = 4,
    rag_top_k:       int   = 3,
    rag_min_score:   float = 0.35,
    outputs_dir:     Optional[str] = None,
) -> Dict:
    """
    Pipeline 2 — Evaluación por ÁMBITO (Estandares_VIRF.xlsx).

    Orquesta el flujo completo end-to-end que antes estaba disperso en agente.py:
        1. Leer Estandares_VIRF.xlsx → actividades por ámbito
        2. Cargar todos los inputs de inputs/
        3. Para cada ámbito: construir contexto + evaluar actividades (con RAG)
        4. Calcular scores y semáforo
        5. Generar resumen ejecutivo
        6. Generar informe Word
        7. Retornar resultado estructurado

    Args:
        titulo_modelo:  nombre del modelo (usado para inferir dominio RAG)
        tier:           tier regulatorio: "I", "II", "III", "IV"
        modo_preprdc:   True = modo pre-PRDC (score iterativo), False = producción
        paralelo:       True = evaluar ámbitos en paralelo (más rápido, sin memoria)
        max_workers:    hilos si paralelo=True
        rag_top_k:      chunks RAG por actividad (0 = desactivar RAG)
        rag_min_score:  similitud mínima para incluir chunk RAG
        outputs_dir:    ruta de salida (None = usa OUTPUTS_DIR de config.py)

    Returns:
        {
          "estado":               "OK" | "ERROR",
          "score_global":         float,
          "semaforo":             {"label": str, "color": str},
          "scores_por_ambito":    {ambito: float},
          "evaluaciones":         {ambito: [lista de dicts]},
          "resumen_ejecutivo":    str,
          "ruta_word":            str | None,
          "rag_dominio":          str,
          "n_actividades":        int,
          "cobertura_promedio":   float,
        }

    Ejemplo (notebook Databricks):
        from modulos.motor_ia import orquestar_pipeline_ambitos
        resultado = orquestar_pipeline_ambitos(
            titulo_modelo = "Modelo LaR v3",
            tier          = "I",
            paralelo      = True,   # 6-10 min vs 25-40 min
        )
        print(f"Score global: {resultado['score_global']} — {resultado['semaforo']['label']}")
    """
    import os as _os
    from datetime import datetime
    from config import OUTPUTS_DIR
    from modulos.generador_word import generar_word_informe

    # ── 1. Cargar estándares y actividades ───────────────────────────────────
    print(f"\n{'═'*65}")
    print(f"  PIPELINE 2 — Evaluación por Ámbito")
    print(f"  Modelo: {titulo_modelo}  |  Tier: {tier}")
    print(f"  Modo: {'PRE-PRDC' if modo_preprdc else 'PRDC'}  |  "
          f"Paralelo: {paralelo}  |  RAG top_k={rag_top_k}")
    print(f"{'═'*65}\n")

    try:
        estandares = leer_estandares_virf(tier)
    except Exception as e:
        return {"estado": "ERROR", "error": f"No se pudo leer Estandares_VIRF.xlsx: {e}"}

    if not estandares:
        return {"estado": "ERROR", "error": f"Sin actividades para Tier {tier}"}

    # ── 2. Cargar todos los inputs ────────────────────────────────────────────
    print("  📂 Cargando inputs...")
    todos_inputs = cargar_todos_inputs()

    # ── 3. Evaluar ámbitos ────────────────────────────────────────────────────
    evaluaciones_por_ambito: Dict[str, List[Dict]] = {}
    contexto_global: List[Dict] = []  # memoria inter-ámbito (solo modo secuencial)

    if paralelo:
        evaluaciones_por_ambito = evaluar_todos_ambitos_paralelo(
            ambitos_data  = estandares,
            todos_inputs  = todos_inputs,
            titulo_modelo = titulo_modelo,
            modo_preprdc  = modo_preprdc,
            max_workers   = max_workers,
        )
    else:
        for ambito, actividades in estandares.items():
            acts_requeridas = [a for a in actividades if a.get("requerida", True)]
            if not acts_requeridas:
                continue

            # Construir contexto para este ámbito
            docs_ambito = inputs_para_dimension(todos_inputs, ambito)
            _max_ctx = int(_os.getenv("VIRF_MAX_CTX", "15000"))
            contexto_partes = []
            chars = 0
            for d in docs_ambito:
                contenido = d.get("contenido", "")
                if chars + len(contenido) > _max_ctx and contexto_partes:
                    break
                contexto_partes.append(f"[{d['nombre']}]\n{contenido}")
                chars += len(contenido)
            contexto = "\n".join(contexto_partes)

            print(f"\n🔍 {ambito} — {len(acts_requeridas)} actividades | {chars:,} chars")

            evals = evaluar_ambito_completo(
                ambito          = ambito,
                actividades     = acts_requeridas,
                contexto        = contexto,
                titulo_modelo   = titulo_modelo,
                modo_preprdc    = modo_preprdc,
                contexto_global = contexto_global,
                rag_top_k       = rag_top_k,
                rag_min_score   = rag_min_score,
            )
            evaluaciones_por_ambito[ambito] = evals

            # Acumular para memoria inter-ámbito
            for ev in evals:
                contexto_global.append({
                    "ambito":      ambito,
                    "actividad":   ev.get("actividad", ""),
                    "puntaje":     ev.get("puntaje"),
                    "observacion": ev.get("observacion", ""),
                })

    # ── 4. Calcular scores ────────────────────────────────────────────────────
    scores_por_ambito = {
        amb: calcular_score_ambito(evals)
        for amb, evals in evaluaciones_por_ambito.items()
    }
    score_global = calcular_score_global(scores_por_ambito)
    semaforo     = get_semaforo(score_global)

    # Métricas de cobertura y RAG
    todas_evals = [e for evals in evaluaciones_por_ambito.values() for e in evals]
    coberturas  = [e.get("cobertura_contexto", 0.0) for e in todas_evals
                   if e.get("cobertura_contexto") is not None]
    cobertura_prom = round(sum(coberturas) / len(coberturas), 3) if coberturas else 0.0
    rag_dominio = _rag_inferir_dominio(titulo_modelo) if _RAG_DISPONIBLE else "no_disponible"
    chunks_rag  = sum(e.get("rag_chunks", 0) for e in todas_evals)

    print(f"\n{'─'*65}")
    print(f"  Score global: {score_global:.2f}/5.00 — {semaforo['label']}")
    print(f"  Cobertura documental promedio: {cobertura_prom*100:.0f}%")
    print(f"  Chunks RAG inyectados: {chunks_rag} (dominio: {rag_dominio})")
    for amb, sc in scores_por_ambito.items():
        print(f"  {amb:<40} {sc:.2f}")
    print(f"{'─'*65}\n")

    # ── 5. Resumen ejecutivo ──────────────────────────────────────────────────
    print("  📝 Generando resumen ejecutivo...")
    resumen = generar_resumen_ejecutivo(
        evaluaciones_por_ambito = evaluaciones_por_ambito,
        scores_por_ambito       = scores_por_ambito,
        score_global            = score_global,
        titulo_modelo           = titulo_modelo,
        tier                    = tier,
    )

    # ── 6. Informe Word ───────────────────────────────────────────────────────
    _out = Path(outputs_dir) if outputs_dir else OUTPUTS_DIR
    _out.mkdir(parents=True, exist_ok=True)
    fecha_str  = datetime.now().strftime("%Y%m%d_%H%M")
    nombre_seg = titulo_modelo.replace(" ", "_").replace("/", "-")[:40]
    word_path  = None

    try:
        word_path = generar_word_informe(
            titulo_modelo           = titulo_modelo,
            tier                    = tier,
            evaluaciones_por_ambito = evaluaciones_por_ambito,
            scores_por_ambito       = scores_por_ambito,
            score_global            = score_global,
            semaforo                = semaforo,
            resumen_ejecutivo       = resumen,
            output_dir              = str(_out),
        )
        print(f"  ✅ Informe Word: {word_path}")
    except Exception as e:
        print(f"  ⚠️  Error generando Word: {e}")

    return {
        "estado":             "OK",
        "score_global":       score_global,
        "semaforo":           semaforo,
        "scores_por_ambito":  scores_por_ambito,
        "evaluaciones":       evaluaciones_por_ambito,
        "resumen_ejecutivo":  resumen,
        "ruta_word":          str(word_path) if word_path else None,
        "rag_dominio":        rag_dominio,
        "rag_chunks_total":   chunks_rag,
        "n_actividades":      len(todas_evals),
        "cobertura_promedio": cobertura_prom,
    }
