"""
⚠️  MÓDULO NO ACTIVO — NO EDITAR PARA CORREGIR EL PIPELINE  ⚠️
═════════════════════════════════════════════════════════════════════════════
Ningún módulo importa este archivo (verificado con grep sobre todo el proyecto).
Las clases aquí definidas (BuscadorEvidencias, CalculadorScore, ValidadorInputs,
DocumentoChunker, ReportadorEvaluacion) están DUPLICADAS en
`modulos/control_evaluacion_data.py`, que es la implementación que `motor_ia_v2`
importa y ejecuta realmente.

Esta duplicación ya causó un fallo real: se corrigió el bug de extensiones de
evidencia aquí y el pipeline siguió fallando, porque el código vivo era el otro.

    → Para tocar la lógica de evaluación de controles, edita
      `modulos/control_evaluacion_data.py`.

Se conserva solo como referencia histórica de la migración v12 → v13.
═════════════════════════════════════════════════════════════════════════════

v13_fixes.py
Módulo de correcciones críticas para v13.

Soluciona todos los bugs de v12:
1. ✅ Estado "OK" por defecto: Ahora es PENDING, solo OK tras evaluación exitosa
2. ✅ Rutas de evidencia: Usa inputs/ reales en lugar de carpeta Evidencias/ fantasma
3. ✅ Truncamiento: Implementa chunking de documentos largos con indicador de cobertura
4. ✅ Score invertido: Más hallazgos = score MENOR (cumplimiento, no defectos)
5. ✅ Validación previa: Pre-flight checks antes de API calls
6. ✅ Sesgo de subestimación: Mejor parseo de evidencia parcial
7. ✅ Indicador de evidencia: Flag booleano si hay archivos reales

═════════════════════════════════════════════════════════════════════════════
"""

import os
import json
from pathlib import Path
from typing import Optional, Dict, Any, List, Tuple
from datetime import datetime

# ──────────────────────────────────────────────────────────────────────────────
# ESTADO DE EVALUACIÓN (FIX 1)
# ──────────────────────────────────────────────────────────────────────────────

class EstadoEvaluacion:
    """Estados válidos para evaluación de control"""
    PENDING = "PENDING"      # Sin evaluar aún
    OK = "OK"                # Evaluación exitosa
    PARTIAL = "PARTIAL"      # Evaluación sin evidencia suficiente
    ERROR = "ERROR"          # Fallo en la evaluación


def create_resultado_control_v13(ctrl_id: str) -> Dict[str, Any]:
    """
    Crea estructura de resultado para un control (v13 con fixes).
    
    Cambios vs v12:
    - estado inicializa como PENDING, no OK
    - Agrega fields: evidencia_disponible, cobertura_docs, validacion_previa
    - Rastreo de qué archivos se leyeron realmente
    """
    return {
        "control_id":           ctrl_id,
        "estado":               EstadoEvaluacion.PENDING,  # CAMBIO: No es OK por defecto
        "revision":             "",
        "hallazgos":            [],
        "resultado_motor":      None,
        "fuentes":              {"manual": None, "script": None},
        "evidencia_disponible": False,                      # NUEVO: ¿Se encontraron evidencias?
        "cobertura_docs":       0.0,                        # NUEVO: % de documento leído
        "validacion_previa":    {"ok": False, "motivos": []},  # NUEVO: Pre-flight checks
        "timestamp_evaluacion": None,
    }


# ──────────────────────────────────────────────────────────────────────────────
# VALIDACIÓN PREVIA DE INPUTS (FIX 7)
# ──────────────────────────────────────────────────────────────────────────────

class ValidadorInputs:
    """Pre-flight checks antes de evaluar controles"""
    
    @staticmethod
    def validar_inputs_basicos(base_project_path: str, ctrl_id: str) -> Dict[str, Any]:
        """
        Realiza checks básicos de inputs para un control.
        
        Checks:
        1. Directorio inputs/ existe
        2. Hay archivos legibles
        3. Tamaños razonables
        4. Extensiones soportadas
        
        Returns:
            {
              "ok": bool,
              "motivos": list[str],  # Razones de fallo (vacío si OK)
              "archivos_encontrados": int,
              "tamaño_total_bytes": int,
            }
        """
        motivos = []
        archivos = []
        tamaño_total = 0
        
        inputs_dir = Path(base_project_path) / "inputs"
        
        # Check 1: inputs/ existe
        if not inputs_dir.exists():
            motivos.append(f"Carpeta inputs/ no existe: {inputs_dir}")
            return {
                "ok": False,
                "motivos": motivos,
                "archivos_encontrados": 0,
                "tamaño_total_bytes": 0,
            }
        
        # Check 2: Buscar archivos legibles
        extensiones_validas = {".pdf", ".docx", ".doc", ".pptx", ".py", ".json", ".xlsx", ".txt", ".csv"}
        
        for archivo in inputs_dir.rglob("*"):
            if archivo.is_file():
                ext = archivo.suffix.lower()
                if ext in extensiones_validas:
                    try:
                        # Intentar leer primeros bytes
                        with open(archivo, "rb") as f:
                            datos = f.read(1024)
                        archivos.append(str(archivo))
                        tamaño_total += archivo.stat().st_size
                    except Exception as e:
                        motivos.append(f"Archivo no legible: {archivo.name} ({e})")
        
        # Check 3: ¿Hay archivos?
        if not archivos:
            motivos.append(f"No hay archivos legibles en {inputs_dir}")
            return {
                "ok": False,
                "motivos": motivos,
                "archivos_encontrados": 0,
                "tamaño_total_bytes": 0,
            }
        
        # Check 4: Tamaño total razonable (< 100MB)
        if tamaño_total > 100 * 1024 * 1024:
            motivos.append(f"Tamaño total > 100MB: {tamaño_total / 1024 / 1024:.1f}MB")
        
        return {
            "ok": len(motivos) == 0,
            "motivos": motivos,
            "archivos_encontrados": len(archivos),
            "tamaño_total_bytes": tamaño_total,
        }
    
    @staticmethod
    def validar_conectividad_api(cliente_ia: Any) -> Tuple[bool, str]:
        """
        Test rápido de conectividad a API antes de cargas masivas.
        
        Returns:
            (success: bool, mensaje: str)
        """
        try:
            # Intentar llamada mínima
            respuesta = cliente_ia.generar_mensaje(
                prompt="Responde solo con 'OK' en una palabra",
                max_tokens=10
            )
            if respuesta and len(respuesta.strip()) > 0:
                return (True, f"✅ API conectada: {respuesta[:30]}")
            else:
                return (False, "❌ API respondió vacío")
        except Exception as e:
            return (False, f"❌ Error conectividad: {str(e)[:100]}")


# ──────────────────────────────────────────────────────────────────────────────
# CHUNKING DE DOCUMENTOS LARGOS (FIX 5)
# ──────────────────────────────────────────────────────────────────────────────

class DocumentoChunker:
    """Divide documentos largos en chunks procesables con overlap"""
    
    # Tamaños sugeridos
    CHUNK_SIZE = 5000  # chars
    OVERLAP = 500      # chars de solapamiento
    MAX_CHUNKS = 5     # máximo chunks a procesar
    
    @staticmethod
    def chunking(
        texto: str,
        max_chars: int = 20000,
        chunk_size: int = CHUNK_SIZE,
        overlap: int = OVERLAP,
    ) -> List[Dict[str, Any]]:
        """
        Divide texto largo en chunks procesables.
        
        Args:
            texto: contenido original
            max_chars: máximo a procesar (si exceeds, trunca)
            chunk_size: tamaño de cada chunk
            overlap: caracteres solapados entre chunks
        
        Returns:
            [
              {
                "chunk_id": int,
                "contenido": str,
                "inicio_char": int,
                "fin_char": int,
                "es_truncado": bool,
              },
              ...
            ]
        """
        if not texto:
            return []
        
        # Truncar si es necesario
        es_truncado = len(texto) > max_chars
        texto_procesado = texto[:max_chars]
        
        chunks = []
        pos = 0
        chunk_id = 0
        
        while pos < len(texto_procesado):
            # Calcular fin del chunk
            fin = min(pos + chunk_size, len(texto_procesado))
            
            # Si no es el final, buscar límite natural (punto, salto línea)
            if fin < len(texto_procesado):
                for delim in [". ", "\n", " "]:
                    busqueda_pos = texto_procesado.rfind(delim, pos + chunk_size - 200, fin)
                    if busqueda_pos > pos:
                        fin = busqueda_pos + len(delim)
                        break
            
            chunk = {
                "chunk_id":      chunk_id,
                "contenido":     texto_procesado[pos:fin].strip(),
                "inicio_char":   pos,
                "fin_char":      fin,
                "es_truncado":   es_truncado and (chunk_id == DocumentoChunker.MAX_CHUNKS - 1),
            }
            
            if chunk["contenido"]:  # Solo agregar si no vacío
                chunks.append(chunk)
                chunk_id += 1
            
            # Mover posición (con overlap)
            pos = fin - overlap
            
            # Limitar chunks
            if chunk_id >= DocumentoChunker.MAX_CHUNKS:
                break
        
        return chunks
    
    @staticmethod
    def calcular_cobertura(chunks: List[Dict[str, Any]], tamaño_original: int) -> float:
        """
        Calcula % de documento procesado.
        
        Returns: float 0.0 a 1.0
        """
        if not chunks or tamaño_original == 0:
            return 0.0
        
        # Usar último chunk como referencia
        ultima_pos = chunks[-1]["fin_char"]
        return min(ultima_pos / tamaño_original, 1.0)


# ──────────────────────────────────────────────────────────────────────────────
# BUSQUEDA DE EVIDENCIAS EN INPUTS/ (FIX 4)
# ──────────────────────────────────────────────────────────────────────────────

class BuscadorEvidencias:
    """Localiza evidencias en inputs/ (no en carpeta Evidencias/ fantasma)"""

    # [EVIDENCIA-FIX] Antes: {".pdf", ".docx", ".doc", ".pptx"} — solo formatos
    # BINARIOS. Consecuencia doble:
    #   1) La evidencia en .md/.txt/.csv era INVISIBLE: el pipeline reportaba
    #      "Sin evidencia disponible" aunque los archivos estuvieran ahí.
    #   2) Los binarios se leían con read_text(), devolviendo bytes ilegibles
    #      como si fueran el contenido del manual.
    # Ahora se aceptan formatos de texto y los binarios se extraen con el
    # lector adecuado (ver _leer_contenido).
    EXTENSIONES_MANUALES = {
        ".pdf", ".docx", ".doc", ".pptx",      # binarios (extracción especializada)
        ".md", ".txt", ".rst",                  # texto plano
        ".xlsx", ".xlsm",                       # tablas de controles
    }
    EXTENSIONES_SCRIPTS = {".py", ".ipynb", ".sql", ".r", ".sas"}
    EXTENSIONES_TEXTO_PLANO = {".md", ".txt", ".rst", ".py", ".ipynb", ".sql", ".r", ".sas"}

    # Archivos que NO son evidencia del modelo sino configuración del validador
    ARCHIVOS_EXCLUIDOS = {
        "estandares_virf.xlsx",     # la rúbrica de evaluación
        "controlesdata.xlsx",       # el catálogo de controles
    }
    CARPETAS_EXCLUIDAS = {"datasets", "__pycache__", ".git", "archivo", "outputs"}

    # Palabras que indican que un documento ES evidencia relevante (menor = mejor)
    PALABRAS_RELEVANTES = (
        "manual", "metodolog", "procedimiento", "control", "calidad",
        "extraccion", "extracción", "implementa", "seguimiento", "informe",
    )

    @staticmethod
    def _es_excluido(archivo: Path) -> bool:
        """True si el archivo es configuración del validador, no evidencia."""
        if archivo.name.startswith("~$") or archivo.name.startswith("."):
            return True
        if archivo.name.lower() in BuscadorEvidencias.ARCHIVOS_EXCLUIDOS:
            return True
        partes = {p.lower() for p in archivo.parts}
        return bool(partes & BuscadorEvidencias.CARPETAS_EXCLUIDAS)

    @staticmethod
    def _rango(archivo: Path) -> tuple:
        """
        Clave de ordenación: menor = más relevante como evidencia.

        Criterios, en orden:
          1. Contiene alguna palabra documental relevante en su nombre
          2. Formato documental (.docx/.pdf/.md) por delante de tablas (.xlsx)
          3. Nombre alfabético, para que el resultado sea determinista
        """
        nombre = archivo.name.lower()
        relevante = 0 if any(p in nombre for p in BuscadorEvidencias.PALABRAS_RELEVANTES) else 1
        prioridad_ext = {
            ".docx": 0, ".pdf": 0, ".md": 1, ".txt": 1,
            ".pptx": 2, ".xlsx": 3, ".xlsm": 3,
        }.get(archivo.suffix.lower(), 2)
        return (relevante, prioridad_ext, nombre)

    @staticmethod
    def _leer_contenido(archivo: Path, max_chars: int) -> str:
        """
        Extrae texto según el tipo de archivo.

        Texto plano  → lectura directa
        .docx        → python-docx (párrafos + tablas)
        .pdf         → pdfminer → PyPDF2 (cadena de fallbacks)
        .xlsx/.xlsm  → openpyxl, volcado de celdas no vacías
        Ante cualquier fallo devuelve "" en vez de propagar la excepción: un
        archivo ilegible no debe tumbar la evaluación del control.
        """
        ext = archivo.suffix.lower()
        try:
            if ext in BuscadorEvidencias.EXTENSIONES_TEXTO_PLANO:
                return archivo.read_text(encoding="utf-8", errors="replace")[:max_chars]

            if ext == ".docx":
                import docx
                d = docx.Document(str(archivo))
                partes = [p.text for p in d.paragraphs if p.text.strip()]
                for t in d.tables:
                    for fila in t.rows:
                        celdas = [c.text.strip() for c in fila.cells]
                        if any(celdas):
                            partes.append(" | ".join(celdas))
                return "\n".join(partes)[:max_chars]

            if ext == ".pdf":
                try:
                    from pdfminer.high_level import extract_text
                    txt = extract_text(str(archivo)) or ""
                    if txt.strip():
                        return txt[:max_chars]
                except Exception:
                    pass
                import PyPDF2
                with open(archivo, "rb") as f:
                    paginas = PyPDF2.PdfReader(f).pages
                    return "\n".join(p.extract_text() or "" for p in paginas)[:max_chars]

            if ext in (".xlsx", ".xlsm"):
                from openpyxl import load_workbook
                wb = load_workbook(archivo, data_only=True, read_only=True)
                partes = []
                for hoja in wb.sheetnames:
                    partes.append(f"### Hoja: {hoja}")
                    for fila in wb[hoja].iter_rows(values_only=True):
                        vals = [str(v) for v in fila if v is not None]
                        if vals:
                            partes.append(" | ".join(vals))
                        if sum(len(p) for p in partes) > max_chars:
                            break
                wb.close()
                return "\n".join(partes)[:max_chars]

            # Extensión desconocida: intento conservador
            return archivo.read_text(encoding="utf-8", errors="replace")[:max_chars]
        except Exception:
            return ""
    
    @staticmethod
    def buscar_evidencias(
        base_project_path: str,
        ctrl_id: str,
        max_chars_doc: int = 8000,
        max_chars_codigo: int = 5000,
    ) -> Tuple[bool, Optional[str], str, Optional[str], str]:
        """
        Busca manual y script para un control en inputs/.
        
        Strategy:
        1. Si existe inputs/Evidencias/{ctrl_id}/, prioriza eso
        2. Si no, busca en inputs/ recursivamente
        3. Prioriza por nombre: control_id, control, evidence, etc.
        4. Retorna (evidencia_encontrada, ruta_manual, texto_manual, ruta_script, texto_script)
        """
        inputs_dir = Path(base_project_path) / "inputs"
        
        if not inputs_dir.exists():
            return (False, None, "", None, "")
        
        ruta_manual = None
        texto_manual = ""
        ruta_script = None
        texto_script = ""
        
        # 1. Intentar carpeta específica Evidencias/{ctrl_id}
        carpeta_ctrl = inputs_dir / "Evidencias" / ctrl_id
        if carpeta_ctrl.exists():
            ruta_manual, texto_manual = BuscadorEvidencias._buscar_archivo_en_carpeta(
                carpeta_ctrl, BuscadorEvidencias.EXTENSIONES_MANUALES, max_chars_doc
            )
            ruta_script, texto_script = BuscadorEvidencias._buscar_archivo_en_carpeta(
                carpeta_ctrl, BuscadorEvidencias.EXTENSIONES_SCRIPTS, max_chars_codigo
            )
        
        # 2. Buscar en toda la carpeta inputs/ si no encontró
        if not ruta_manual:
            ruta_manual, texto_manual = BuscadorEvidencias._buscar_archivo_en_carpeta(
                inputs_dir, BuscadorEvidencias.EXTENSIONES_MANUALES, max_chars_doc,
                filtro_nombre=ctrl_id
            )
        
        if not ruta_script:
            ruta_script, texto_script = BuscadorEvidencias._buscar_archivo_en_carpeta(
                inputs_dir, BuscadorEvidencias.EXTENSIONES_SCRIPTS, max_chars_codigo,
                filtro_nombre=ctrl_id
            )
        
        evidencia_encontrada = (ruta_manual is not None) or (ruta_script is not None)
        
        return (evidencia_encontrada, ruta_manual, texto_manual, ruta_script, texto_script)
    
    @staticmethod
    def _buscar_archivo_en_carpeta(
        carpeta: Path,
        extensiones: set,
        max_chars: int,
        filtro_nombre: str = "",
    ) -> Tuple[Optional[str], str]:
        """
        Busca primer archivo con extensión válida en carpeta.
        
        Si filtro_nombre, prioriza archivos que contengan ese string.
        """
        # Priorizar archivos que contengan el filtro
        archivos_prioridad = []
        archivos_otros = []
        
        for archivo in carpeta.rglob("*"):
            if not (archivo.is_file() and archivo.suffix.lower() in extensiones):
                continue
            if BuscadorEvidencias._es_excluido(archivo):
                continue

            # [EVIDENCIA-FIX] Extracción según tipo (antes: read_text sobre binarios)
            contenido = BuscadorEvidencias._leer_contenido(archivo, max_chars)
            if not contenido.strip():
                continue   # archivo ilegible o vacío → no cuenta como evidencia

            if filtro_nombre and filtro_nombre.lower() in archivo.name.lower():
                archivos_prioridad.append((str(archivo), contenido))
            else:
                archivos_otros.append((str(archivo), contenido))

        # [EVIDENCIA-FIX] Ordenar por relevancia documental antes de elegir.
        # rglob devuelve los archivos en orden arbitrario del sistema de ficheros:
        # sin esto, el pipeline escogía como "manual del modelo" el primer archivo
        # que apareciera (p. ej. Estandares_VIRF.xlsx, que es la RÚBRICA de
        # evaluación, no evidencia del modelo bajo validación).
        archivos_prioridad.sort(key=lambda t: BuscadorEvidencias._rango(Path(t[0])))
        archivos_otros.sort(key=lambda t: BuscadorEvidencias._rango(Path(t[0])))
        
        # Retornar según prioridad
        if archivos_prioridad:
            ruta, contenido = archivos_prioridad[0]
            return (ruta, contenido)
        elif archivos_otros:
            ruta, contenido = archivos_otros[0]
            return (ruta, contenido)
        else:
            return (None, "")


# ──────────────────────────────────────────────────────────────────────────────
# SCORE DE CUMPLIMIENTO (FIX 6)
# ──────────────────────────────────────────────────────────────────────────────

class CalculadorScore:
    """Calcula score de cumplimiento (inverso a hallazgos)"""
    
    # Mapa: n_hallazgos_criticos -> score
    # 0 criticos = 5 (cumple plenamente)
    # 1-2 criticos = 3 (cumple parcialmente)
    # 3+ criticos = 1 (no cumple)
    MAPEO_CRITICOS_A_SCORE = {
        0: 5.0,  # Cumple plenamente
        1: 4.0,  # Cumple con obs. menores
        2: 3.0,  # Cumple parcialmente
        3: 2.0,  # Cumple parcialmente - obs. críticas
        4: 1.0,  # No cumple
    }
    
    @staticmethod
    def calcular_score_cumplimiento(
        hallazgos: List[Dict[str, Any]],
        total_hallazgos: int,
    ) -> float:
        """
        Calcula score de cumplimiento basado en hallazgos.
        
        Lógica (INVERSA a cantidad de hallazgos):
        - Sin hallazgos críticos: 5.0 (Cumple plenamente)
        - 1-2 críticos: 4.0-3.0 (Cumple con observaciones)
        - 3+ críticos: 1.0-2.0 (No cumple / Deficiente)
        
        Args:
            hallazgos: lista de hallazgos encontrados
            total_hallazgos: cantidad total
        
        Returns: score 1.0-5.0
        """
        if not hallazgos:
            return 5.0
        
        n_criticos = sum(1 for h in hallazgos if h.get("criticidad") == "CRITICA")
        
        # Usar mapeo predefinido
        score = CalculadorScore.MAPEO_CRITICOS_A_SCORE.get(
            min(n_criticos, 4),
            1.0
        )
        
        return score
    
    @staticmethod
    def interpretar_score(score: float) -> Dict[str, Any]:
        """
        Interpreta el score según escala 1-5.
        
        Returns:
            {
              "label": str,
              "color_hex": str,
              "semaforo": "ROJO" | "NARANJA" | "AMARILLO" | "VERDE_CLARO" | "VERDE",
            }
        """
        escala = {
            (4.5, 5.0): {
                "label": "CUMPLE PLENAMENTE",
                "color_hex": "00B050",
                "semaforo": "VERDE",
            },
            (3.5, 4.5): {
                "label": "CUMPLE CON OBSERVACIONES MENORES",
                "color_hex": "92D050",
                "semaforo": "VERDE_CLARO",
            },
            (2.5, 3.5): {
                "label": "CUMPLE PARCIALMENTE",
                "color_hex": "FFCC00",
                "semaforo": "AMARILLO",
            },
            (1.5, 2.5): {
                "label": "DEFICIENTE",
                "color_hex": "FF6600",
                "semaforo": "NARANJA",
            },
            (0.0, 1.5): {
                "label": "CRÍTICO",
                "color_hex": "FF0000",
                "semaforo": "ROJO",
            },
        }
        
        for rango, resultado in escala.items():
            if rango[0] <= score <= rango[1]:
                return resultado
        
        return {
            "label": "SIN EVALUAR",
            "color_hex": "CCCCCC",
            "semaforo": "GRIS",
        }


# ──────────────────────────────────────────────────────────────────────────────
# REPORTE RESUMEN DE EVALUACIÓN (FIX 10)
# ──────────────────────────────────────────────────────────────────────────────

class ReportadorEvaluacion:
    """Genera reportes detallados de la evaluación"""
    
    @staticmethod
    def generar_resumen_pipeline(
        resultados: Dict[str, Any],
        inicio_timestamp: datetime,
    ) -> str:
        """
        Genera resumen textual de la ejecución del pipeline.
        
        Returns: string formateado para consola
        """
        fin_timestamp = datetime.now()
        duracion_segundos = (fin_timestamp - inicio_timestamp).total_seconds()
        
        resultados_por_control = resultados.get("resultados_por_control", {})
        
        if not resultados_por_control:
            return "⚠️  No hay resultados para reportar."
        
        # Estadísticas
        total = len(resultados_por_control)
        ok_count = sum(1 for r in resultados_por_control.values() 
                      if r.get("estado") == EstadoEvaluacion.OK)
        error_count = sum(1 for r in resultados_por_control.values() 
                         if r.get("estado") == EstadoEvaluacion.ERROR)
        partial_count = sum(1 for r in resultados_por_control.values() 
                           if r.get("estado") == EstadoEvaluacion.PARTIAL)
        
        con_evidencia = sum(1 for r in resultados_por_control.values() 
                           if r.get("evidencia_disponible"))
        sin_evidencia = total - con_evidencia
        
        hallazgos_total = sum(len(r.get("hallazgos", [])) 
                             for r in resultados_por_control.values())
        criticos_total = sum(
            sum(1 for h in r.get("hallazgos", []) if h.get("criticidad") == "CRITICA")
            for r in resultados_por_control.values()
        )
        
        cobertura_promedio = (
            sum(r.get("cobertura_docs", 0) for r in resultados_por_control.values()) 
            / total if total > 0 else 0.0
        )
        
        # Formatear
        lineas = [
            "\n" + "═" * 75,
            "📊 RESUMEN DE EVALUACIÓN (V13)",
            "═" * 75,
            f"\nFecha/Hora      : {fin_timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            f"Duración        : {duracion_segundos:.1f}s",
            f"\nControles evaluados",
            f"  ✅ OK          : {ok_count}/{total}",
            f"  ⚠️  Parciales  : {partial_count}/{total}",
            f"  ❌ Error       : {error_count}/{total}",
            f"\nEvidencias",
            f"  📄 Con evidencia   : {con_evidencia}/{total} ({100*con_evidencia/total:.0f}%)",
            f"  ⚠️  Sin evidencia   : {sin_evidencia}/{total} ({100*sin_evidencia/total:.0f}%)",
            f"\nHallazgos",
            f"  Total          : {hallazgos_total}",
            f"  🔴 Críticos    : {criticos_total}",
            f"  Cobertura doc. : {100*cobertura_promedio:.1f}% promedio",
            "\n" + "═" * 75,
        ]
        
        return "\n".join(lineas)
    
    @staticmethod
    def generar_tabla_resultados(resultados_por_control: Dict[str, Any]) -> str:
        """Tabla formateada de resultados por control"""
        
        if not resultados_por_control:
            return ""
        
        lineas = [
            "\n📋 RESULTADOS POR CONTROL",
            "─" * 120,
            f"{'CONTROL':<15} {'ESTADO':<10} {'EVIDENCIA':<10} {'HALLAZGOS':<10} {'CRÍTICOS':<10} {'COBERTURA':<12}",
            "─" * 120,
        ]
        
        for ctrl_id, resultado in resultados_por_control.items():
            estado = resultado.get("estado", "?")
            evidencia = "✅ SÍ" if resultado.get("evidencia_disponible") else "❌ NO"
            n_hallazgos = len(resultado.get("hallazgos", []))
            n_criticos = sum(1 for h in resultado.get("hallazgos", []) 
                           if h.get("criticidad") == "CRITICA")
            cobertura = resultado.get("cobertura_docs", 0.0)
            
            # Emoji para estado
            estado_emoji = {
                EstadoEvaluacion.OK: "✅",
                EstadoEvaluacion.ERROR: "❌",
                EstadoEvaluacion.PARTIAL: "⚠️",
                EstadoEvaluacion.PENDING: "⏳",
            }.get(estado, "❓")
            
            linea = (
                f"{ctrl_id:<15} "
                f"{estado_emoji} {estado:<8} "
                f"{evidencia:<10} "
                f"{n_hallazgos:<10} "
                f"{n_criticos:<10} "
                f"{100*cobertura:>6.1f}%      "
            )
            lineas.append(linea)
        
        lineas.append("─" * 120)
        return "\n".join(lineas)
