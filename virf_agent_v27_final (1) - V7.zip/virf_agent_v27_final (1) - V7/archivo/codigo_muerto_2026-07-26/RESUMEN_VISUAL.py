"""
RESUMEN VISUAL - FLUJO COMPLETO CON CHALLENGER
"""

from pathlib import Path

print("""
================================================================================
                  VIRF AGENT v27 - FLUJO COMPLETO
        Validacion -> Informe -> Challenger Model (NUEVO)
================================================================================

ARQUITECTURA DE COMPONENTES
────────────────────────────────────────────────────────────────────────────

                              Usuario/Chat
                                   |
                                   v
                      ┌────────────────────────────┐
                      │      VIRFAgent             │
                      │  (virf_agent.py)           │
                      │                            │
                      │  - Gestion de sesion       │
                      │  - Coordinacion analisis   │
                      │  - Generacion de informes  │
                      └────────┬──────────┬────────┘
                               |          |
                      ┌────────v──────┐  ┌───v─────────────────┐
                      │ Evaluadores   │  │ Challenger Generator│
                      │ Estaticos     │  │ (NUEVO)             │
                      │               │  │                     │
                      │ - Formula     │  │ - Crea Jupyter NB   │
                      │   Detector    │  │ - Compara modelos   │
                      │               │  │ - Integra hallazgos │
                      │ - Methodology │  │ - Genera codigo     │
                      │   Checker     │  │   ejecutable        │
                      └───────────────┘  └──────────┬──────────┘
                                                    |
                                      ┌─────────────v──────────────┐
                                      │   Salidas Generadas        │
                                      │                            │
                                      │ 1. JSON (Hallazgos)        │
                                      │ 2. Word (Informe)          │
                                      │ 3. Jupyter NB (Challenger) │
                                      └────────────────────────────┘


FLUJO DE 5 PASOS
────────────────────────────────────────────────────────────────────────────

[PASO 1] INICIALIZAR AGENTE
    - Crear instancia de VIRFAgent
    - Especificar nombre del modelo
    - Seleccionar dominio (LaR, VaR, conductuales)
    
    Codigo:
    -------
    from agent.virf_agent import VIRFAgent
    agente = VIRFAgent(titulo_modelo="Mi Modelo LaR", dominio="LaR")


[PASO 2] REALIZAR ANALISIS
    - Usuario hace preguntas sobre el modelo
    - FormulaDetector analiza formulas (sin LLM)
    - MethodologyChecker valida supuestos (sin LLM)
    - Hallazgos se acumulan automaticamente
    
    Ejemplo:
    --------
    Pregunta: "¿Es correcta VaR = mu + sigma * 1.645?"
    Respuesta: "CRITICO: VaR con signo incorrecto"
    Accion: Hallazgo registrado


[PASO 3] VER HALLAZGOS
    - Comando: /hallazgos
    - Muestra todos los problemas detectados
    - Organizados por gravedad (CRITICO, ALTO, MEDIO, BAJO)
    
    Salida:
    -------
    HALLAZGOS (4 total)
    
      CRITICO (2)
        1. VaR parametrico con signo incorrecto...
        2. Volatilidad anualizada sin raiz de tiempo...
      
      ALTO (2)
        1. Correlacion perfecta (p=1)...


[PASO 4] GENERAR INFORME DE VALIDACION
    - Comando: /validar
    - Genera 3 salidas:
      * JSON: outputs/hallazgos_<modelo>_<timestamp>.json
      * Word: outputs/validacion_<modelo>_<timestamp>.docx
      * Veredicto: APTO / CON CONDICIONES / NO APTO
    
    Contenido Word:
    ───────────────
    - Titulo y fecha
    - Hallazgos por gravedad
    - Correcciones sugeridas
    - Veredicto ejecutivo


[PASO 5] GENERAR CHALLENGER MODEL (NUEVO)
    - Comando: /challenger
    - Crea Jupyter Notebook con:
      * Modelo original (CON PROBLEMAS IDENTIFICADOS)
      * Modelo challenger (MEJORADO)
      * Comparacion visual
      * Backtesting
      * Recomendaciones
    - Ubicacion: outputs/challenger/<nombre>.ipynb
    - Notebook ejecutable y modificable
    
    Estructura del Notebook:
    ────────────────────────
    1. Introduccion y hallazgos clave
    2. Setup y librerias (numpy, pandas, scipy, matplotlib)
    3. Datos de prueba (252 observaciones sinteticas realistas)
    4. Modelo Original (muestra errores)
       - VaR = mu + sigma*z (INCORRECTO - signo)
       - Sin test de normalidad
       - Resultado: VaR negativo
    5. Modelo Challenger (muestra correcciones)
       - VaR = -(mu - sigma*z) (CORRECTO)
       - Test Jarque-Bera + Shapiro-Wilk
       - Deteccion automatica de distribucion
       - Resultado: VaR positivo (correcto)
    6. Comparacion visual
       - Histogramas con VaR superpuesto
       - Series temporales con excepciones
       - Q-Q Plots para validar distribucion
       - Grafico de barras: Original vs Challenger
    7. Backtesting
       - Excepciones: 12 de 252 (4.76%)
       - Esperado: 5%
       - Validacion: APROBADO
    8. Recomendaciones finales


COMANDOS DISPONIBLES
────────────────────────────────────────────────────────────────────────────

/ayuda          - Muestra todos los comandos
/hallazgos      - Lista hallazgos acumulados
/validar        - Genera informe JSON + Word + veredicto
/challenger     - Genera Jupyter Notebook mejorado (NUEVO)
/titulo Nombre  - Cambia modelo bajo validacion
/dominio LaR    - Cambia dominio
/limpiar        - Reinicia sesion (conserva hallazgos)
/reset          - Borra todo
/salir          - Cierra sesion


VENTAJAS DEL CHALLENGER MODEL
────────────────────────────────────────────────────────────────────────────

[VENTAJA 1] Validacion Automatica
    - Detecta errores sin intervencion manual
    - Basado en reglas y mejores practicas normativas

[VENTAJA 2] Integracion de Hallazgos
    - Todos los problemas se resuelven en el Challenger
    - Formulas corregidas, supuestos validados

[VENTAJA 3] Formato Ejecutable
    - Jupyter Notebook que se puede correr directamente
    - Codigo Python listo para produccion

[VENTAJA 4] Documentacion Completa
    - Comparacion visual entre original y mejorado
    - Referencias normativas (SR 11-7, Jorion, etc.)

[VENTAJA 5] Backtesting Integrado
    - Valida que el modelo funciona correctamente
    - Metricas claras (tasa de excepciones, etc.)

[VENTAJA 6] Escalabilidad
    - Funciona con cualquier dominio
    - Adaptable a nuevas reglas


COMO USAR (GUIA RAPIDA)
────────────────────────────────────────────────────────────────────────────

OPCION 1 - INTERACTIVA (Recomendado):
    $ python agent/virf_agente.py --chat \\
        --titulo "Mi Modelo LaR" \\
        --dominio LaR
    
    > /titulo Modelo Corporativo
    > ¿Es correcta VaR = mu + sigma * z?
    > /hallazgos
    > /validar
    > /challenger      (Genera el Notebook)
    > /salir


OPCION 2 - DEMOSTRACION:
    $ python demo_challenger.py
    
    Selecciona un escenario predefinido


OPCION 3 - PROGRAMATICA:
    from agent.virf_agent import VIRFAgent
    
    agente = VIRFAgent(titulo_modelo="...", dominio="...")
    agente.analizar_formula("VaR = mu + sigma * z")
    agente.analizar_metodologia("...")
    agente.validar()
    ruta = agente.generar_challenger()


OPCION 4 - TEST AUTOMATIZADO:
    $ python test_flujo_completo_con_challenger.py


ARCHIVOS PRINCIPALES
────────────────────────────────────────────────────────────────────────────

agent/
  ├── virf_agent.py                       Main class (nuevo generar_challenger)
  ├── virf_agente.py                      Entry point
  ├── evaluators/
  │   ├── formula_detector.py             Static formula error detection
  │   └── methodology_checker.py          Static methodology validation
  └── skills/
      └── challenger_generator.py         (NUEVO) Notebook generation

outputs/
  ├── hallazgos_*.json                    Findings in JSON
  ├── validacion_*.docx                   Report in Word
  └── challenger/
      └── challenger_*.ipynb              Improved Jupyter Notebooks


================================================================================
                          LISTO PARA USAR
================================================================================

Todos los componentes estan configurados y funcionando correctamente.

Para comenzar:
  python agent/virf_agente.py --chat --titulo "Mi Modelo" --dominio LaR

¡Que disfrutes! [ROCKET]

""")

# Mostrar archivos generados
print("\n" + "="*80)
print("ARCHIVOS GENERADOS EN ESTA SESION")
print("="*80)

outputs_dir = Path("outputs")

if outputs_dir.exists():
    json_files = list(outputs_dir.glob("hallazgos_*.json"))
    word_files = list(outputs_dir.glob("validacion_*.docx"))
    ipynb_files = list((outputs_dir / "challenger").glob("*.ipynb")) if (outputs_dir / "challenger").exists() else []
    
    if json_files:
        print(f"\nJSON Files ({len(json_files)}):")
        for f in sorted(json_files)[-3:]:
            size_kb = f.stat().st_size / 1024
            print(f"   * {f.name} ({size_kb:.1f} KB)")
    
    if word_files:
        print(f"\nWord Files ({len(word_files)}):")
        for f in sorted(word_files)[-3:]:
            size_kb = f.stat().st_size / 1024
            print(f"   * {f.name} ({size_kb:.1f} KB)")
    
    if ipynb_files:
        print(f"\nJupyter Notebooks - Challenger ({len(ipynb_files)}):")
        for f in sorted(ipynb_files)[-3:]:
            size_kb = f.stat().st_size / 1024
            print(f"   * {f.name} ({size_kb:.1f} KB)")

print("\n" + "="*80)
