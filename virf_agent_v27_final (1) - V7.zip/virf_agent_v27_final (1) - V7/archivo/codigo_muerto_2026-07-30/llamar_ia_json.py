"""
CÓDIGO MUERTO RETIRADO — 2026-07-30
═══════════════════════════════════════════════════════════════════════════════
`llamar_ia_json()` eliminada de motor/Mx_03_LlamarIA.py.

Dos motivos:

1. NINGÚN módulo la llamaba. El propio fichero ya lo documentaba en un
   comentario, pero la función seguía exportada.

2. ACOPLAMIENTO AL SDK FUERA DE config/. Instanciaba su propio cliente y
   accedía a la forma cruda de la respuesta:

       texto_respuesta = response.choices[0].message.content

   Eso rompe la frontera del proyecto: el conocimiento de qué forma tiene la
   respuesta de un SDK debe vivir SOLO en config/ia.py, detrás de la interfaz
   ClienteIA. Con esta función en medio, cambiar de proveedor —o que el SDK
   cambie de forma— obligaba a tocar un módulo de negocio.

Lo bueno que tenía y se conservó en otro sitio:
  · `response_format={"type": "json_object"}` → ahora es el parámetro
    `formato_json=True` de ClienteIA.generar_mensaje().
  · el reintento con backoff → pendiente de integrar en el cliente Azure
    para el caso 429 (ver GUIA_MIGRACION §10).
"""

def llamar_ia_json(
    user_msg: str,
    client: Any,
    deployment: str,
    system_msg: str,
    *,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_tokens: int = 1024,
    temperature: float = 0.2,
) -> Dict[str, Any]:
    """
    Llama a la API de Azure OpenAI con respuesta JSON validada.
    
    Reintenta con backoff exponencial si la validación falla.
    
    Parámetros:
        user_msg: mensaje del usuario (el prompt)
        client: cliente de Azure OpenAI
        deployment: nombre del deployment (ej: "gpt-4")
        system_msg: mensaje del sistema (rol)
        max_retries: número máximo de reintentos
        base_delay: retardo inicial en segundos
        max_tokens: tokens máximos de respuesta
        temperature: temperatura del modelo (0.2 = determinístico)
    
    Retorna:
        Dict con JSON validado según contrato
    
    Lanza excepción si max_retries se excede
    """
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=deployment,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": user_msg}
                ],
                response_format={"type": "json_object"},
                max_tokens=max_tokens,
                temperature=temperature,
            )
            
            texto_respuesta = response.choices[0].message.content
            
            # Intentar parsear JSON
            try:
                data = json.loads(texto_respuesta)
            except json.JSONDecodeError:
                # Fallback: extraer JSON del texto
                json_str = _crop_to_json(texto_respuesta)
                if json_str:
                    data = json.loads(json_str)
                else:
                    raise ValueError("No se pudo extraer JSON de la respuesta")
            
            # Validar contrato
            _validar_contrato(data)
            
            # Si llegamos aquí, todo está OK
            return data
        
        except (ValueError, json.JSONDecodeError) as e:
            if attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)  # backoff exponencial
                print(f"  [Reintento {attempt+1}/{max_retries}] Validación falló: {e}")
                print(f"  Esperando {delay}s antes de reintentar...")
                time.sleep(delay)
            else:
                raise RuntimeError(f"Falló después de {max_retries} intentos: {e}")
        
        except Exception as e:
            print(f"  [Error en llamada API] {e}")
            raise
