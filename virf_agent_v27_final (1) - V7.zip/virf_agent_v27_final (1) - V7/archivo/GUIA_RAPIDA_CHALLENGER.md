# GUIA RAPIDA - FLUJO COMPLETO CON CHALLENGER MODEL

## Inicio Rapido (30 segundos)

```bash
cd "c:\Users\REC TECHNOLOGY\Desktop\Cursos\Proyectos\Repo_proyectosPersonales\Proyecto_Validador_autonomo\virf_agent_v27_final (1)"

# Opcion 1: Chat interactivo (Recomendado)
python agent/virf_agente.py --chat --titulo "Mi Modelo" --dominio LaR

# Opcion 2: Demo automatizada
python demo_challenger.py

# Opcion 3: Test completo
python test_flujo_completo_con_challenger.py
```

---

## Flujo Interactivo Paso a Paso

### Paso 1: Iniciar sesion
```
$ python agent/virf_agente.py --chat --titulo "Modelo LaR Corporativo" --dominio LaR
```

### Paso 2: Hacer preguntas sobre el modelo
```
> ¿Es correcta esta formula? VaR = μ + σ * 1.645
  → CRITICO: VaR parametrico con signo incorrecto...
  → MEDIO: Se usa z=1.645 sin verificar normalidad...

> ¿Cómo anualizamos volatilidad?
  → CRITICO: Volatilidad multiplicada por 252 directamente...

> Usamos correlacion = 1 en los calculos
  → ALTO: Correlacion perfecta entre activos...
```

### Paso 3: Ver hallazgos acumulados
```
> /hallazgos

HALLAZGOS (4 total)

  CRITICO (2)
    1. VaR parametrico con signo incorrecto...
    2. Volatilidad anualizada sin raiz de tiempo...
  
  ALTO (1)
    1. Correlacion perfecta (p=1)...
  
  MEDIO (1)
    1. Se usa z=1.645 sin verificar normalidad...
```

### Paso 4: Generar informe
```
> /validar

INFORME DE VALIDACION — Modelo LaR Corporativo
===============================================
Fecha: 2026-06-03 16:02
Dominio: LaR
Total hallazgos: 4

CRITICOS (2)
  • VaR parametrico con signo incorrecto...
  • Volatilidad anualizada sin raiz de tiempo...

ALTOS (1)
  • Correlacion perfecta...

VEREDICTO: NO APTO PARA USO EN GESTION
```

Genera:
- `outputs/hallazgos_*.json` - Hallazgos en formato JSON
- `outputs/validacion_*.docx` - Informe en Word

### Paso 5: Generar Challenger Model (NUEVO)
```
> /challenger

GENERANDO CHALLENGER MODEL
==========================
Challenger generado exitosamente
  Ubicacion: outputs/challenger/challenger_Modelo LaR Corporativo_20260603_160237.ipynb
  Tipo: Jupyter Notebook (.ipynb)
  Dominio: LaR
  Hallazgos integrados: 4
```

**El notebook contiene:**
1. Introduccion con hallazgos identificados
2. Setup y librerías
3. Datos de prueba sinteticos
4. **Modelo Original** (muestra errores)
5. **Modelo Challenger** (corregido y mejorado)
6. Comparacion visual (gráficos)
7. Backtesting (valida que funciona)
8. Recomendaciones finales

---

## Comandos Disponibles

| Comando | Efecto |
|---------|--------|
| `/ayuda` | Muestra todos los comandos |
| `/hallazgos` | Lista hallazgos acumulados por gravedad |
| `/validar` | Genera JSON + Word + veredicto |
| `/challenger` | **NUEVO**: Genera Jupyter Notebook mejorado |
| `/titulo Nombre` | Cambia el modelo bajo validacion |
| `/dominio LaR` | Cambia dominio (LaR, VaR, conductuales, shared) |
| `/limpiar` | Reinicia sesion (conserva hallazgos) |
| `/reset` | Borra todo (sesion + hallazgos) |
| `/salir` | Cierra sesion |

---

## Uso Programatico (Python)

```python
from agent.virf_agent import VIRFAgent

# Inicializar
agente = VIRFAgent(titulo_modelo="Modelo LaR v3", dominio="LaR")

# Analizar formulas
hallazgos1 = agente.analizar_formula("VaR = μ + σ * z")
# Resultado: [{'tipo': 'formula', 'gravedad': 'CRITICO', ...}]

# Analizar metodologia
hallazgos2 = agente.analizar_metodologia("Backtesting con 10 datos")
# Resultado: [{'tipo': 'metodologia', 'gravedad': 'MEDIO', ...}]

# Ver hallazgos acumulados
print(agente._mostrar_hallazgos())

# Generar informe
print(agente.validar())

# Guardar JSON
agente._guardar_hallazgos_json()

# Exportar a Word
ruta_word = agente.exportar_word()
print(f"Word guardado en: {ruta_word}")

# GENERAR CHALLENGER (NUEVO)
ruta_challenger = agente.generar_challenger()
print(f"Challenger generado en: {ruta_challenger}")
```

---

## Estructura del Jupyter Notebook Challenger

El notebook generado es totalmente funcional y contiene:

### Celda 1: Introduccion
- Titulo: "Challenger Model: {nombre_modelo}"
- Resumen de hallazgos encontrados
- Mejoras implementadas

### Celdas 2-3: Setup
```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
```

### Celdas 4-5: Datos de Prueba
- Genera 252 observaciones (1 año de datos diarios)
- Distribución t-Student con colas pesadas
- Calcula estadísticas (skewness, kurtosis)
- Visualiza distribución

### Celdas 6-7: Modelo Original (CON ERRORES)
```python
class ModeloOriginal:
    def calcular_var(self, returns):
        var = mu + sigma * z_alpha  # ❌ SIGNO INCORRECTO
        return var
```

### Celdas 8-9: Modelo Challenger (MEJORADO)
```python
class ModeloChallenger:
    def calcular_var(self, datos):
        # ✓ Test normalidad (Jarque-Bera + Shapiro-Wilk)
        # ✓ Distribucion correcta (Normal o t-Student)
        # ✓ Signo correcto para perdidas positivas
        var = -(mu - sigma * quantil)  # ✓ CORRECTO
        return var
```

### Celdas 10-11: Comparacion Visual
- Histogramas de distribucion
- Series temporales
- Q-Q Plots
- Grafico de barras Original vs Challenger

### Celdas 12-13: Backtesting
```
Excepciones observadas: 12
Tasa de excepciones: 4.76%
Tasa esperada: 5.00%
Diferencia: 0.24%
Validacion: APROBADO
```

### Celda 14: Recomendaciones
- Proximos pasos (stress testing, ES, etc.)
- Referencias normativas
- Limitaciones y supuestos

---

## Salidas Generadas

### 1. JSON de Hallazgos
**Ubicacion:** `outputs/hallazgos_<modelo>_<timestamp>.json`

```json
{
  "titulo_modelo": "Modelo LaR v3",
  "dominio": "LaR",
  "fecha": "2026-06-03T16:02:34",
  "total_hallazgos": 4,
  "hallazgos": [
    {
      "tipo": "formula",
      "gravedad": "CRITICO",
      "descripcion": "VaR parametrico con signo incorrecto...",
      "correccion": "VaR = -(μ - σ · z_α)",
      "referencia": "Jorion (2006)",
      "fuente": "formula_detector",
      "timestamp": "2026-06-03T16:02:34.123456"
    },
    ...
  ]
}
```

### 2. Informe Word
**Ubicacion:** `outputs/validacion_<modelo>_<timestamp>.docx`

Contiene:
- Titulo y metadatos
- Resumen ejecutivo
- Hallazgos por gravedad (CRITICO, ALTO, MEDIO, BAJO)
- Correcciones sugeridas
- Veredicto final
- Referencias

### 3. Jupyter Notebook Challenger
**Ubicacion:** `outputs/challenger/challenger_<modelo>_<timestamp>.ipynb`

Archivo `.ipynb` totalmente ejecutable:
- Puede abrirse en Jupyter Lab / Notebook
- Puede ejecutarse celda por celda
- Codigo Python listo para usar
- Visualizaciones integradas

---

## Dominios Soportados

```
LaR         - Loss at Risk / Perdida en Riesgo
VaR         - Value at Risk
conductuales - Riesgo crediticio conductual
shared      - Utilidades compartidas
auto        - Deteccion automatica
```

---

## Archivos Clave del Proyecto

```
agent/
  ├── virf_agent.py                       Clase principal (+ generar_challenger)
  ├── virf_agente.py                      Punto de entrada
  ├── evaluators/
  │   ├── formula_detector.py             Deteccion de errores en formulas
  │   └── methodology_checker.py          Validacion de metodologia
  └── skills/
      └── challenger_generator.py         NUEVO: Generador de Notebooks

demo_challenger.py                        Demo interactiva
test_flujo_completo_con_challenger.py    Test automatizado
FLUJO_COMPLETO_CHALLENGER.md             Documentacion detallada
RESUMEN_VISUAL.py                        Resumen visual del flujo

outputs/
  ├── hallazgos_*.json                   Hallazgos detectados
  ├── validacion_*.docx                  Informe en Word
  └── challenger/
      └── challenger_*.ipynb             Notebooks mejorados
```

---

## Ejemplos de Preguntas que Detecta

| Pregunta | Deteccion | Gravedad |
|----------|-----------|----------|
| "VaR = μ + σ * 1.645" | VaR con signo incorrecto | CRITICO |
| "Anualizamos vol * 252" | Sin raiz de tiempo | CRITICO |
| "Correlacion = 1" | Correlacion perfecta | ALTO |
| "Backtesting con 10 datos" | Insuficientes observaciones | MEDIO |
| "Usamos Normal sin test" | Sin validar normalidad | MEDIO |
| "Interpolacion lineal" | Uso inadecuado de metodos | BAJO |

---

## Mejoras que Implementa el Challenger

### Automaticas:
- Correccion de formulas
- Tests de normalidad
- Deteccion de distribucion (Normal vs t-Student)
- Backtesting integrado
- Visualizaciones comparativas

### Documentacion:
- Supuestos explicitados
- Referencias normativas (SR 11-7, Jorion, Christoffersen)
- Proximos pasos recomendados
- Limitaciones claras

---

## Casos de Uso

### Caso 1: Validacion de Modelo LaR
1. Inicia sesion con `/chat --titulo "Modelo LaR" --dominio LaR`
2. Haz preguntas sobre el modelo
3. Ejecuta `/validar` para informe ejecutivo
4. Ejecuta `/challenger` para modelo mejorado
5. Presenta el .ipynb y Word a comite de riesgo

### Caso 2: Comparacion Modelo Original vs Mejorado
1. Ejecuta `/challenger` (genera modelo mejorado con comparacion)
2. Abre el .ipynb en Jupyter
3. Ejecuta todas las celdas para ver resultados lado a lado
4. Muestra graficos de comparacion

### Caso 3: Backtesting Automatico
1. Los hallazgos detectados se resuelven en el Challenger
2. El Challenger incluye backtesting integrado
3. Valida que el modelo mejorado funciona correctamente
4. Genera metricas claras (tasa de excepciones, etc.)

---

## Troubleshooting

### Error: "nbformat not found"
```bash
pip install nbformat
```
Si nbformat no esta disponible, genera HTML como fallback.

### Error: "python-docx not found"
```bash
pip install python-docx
```
Sin python-docx no genera archivo Word (usa JSON).

### Error: "No se abre el .ipynb"
- Instala Jupyter: `pip install jupyter`
- Abre en Jupyter Lab: `jupyter lab`
- O usa VS Code con extension Jupyter

### Paths con caracteres especiales
Windows requiere encoding UTF-8. Si hay problemas:
```bash
set PYTHONIOENCODING=utf-8
python test_flujo_completo_con_challenger.py
```

---

## Proximas Mejoras Planeadas

- [ ] Stress testing en el Challenger
- [ ] Expected Shortfall (ES) además de VaR
- [ ] Analisis multivariado con correlaciones
- [ ] Exportar a HTML para presentaciones
- [ ] Integracion con Databricks
- [ ] Validaciones adicionales (sensibilidad, escenarios)

---

## Resumen de Componentes

| Componente | Proposito | Estado |
|------------|-----------|--------|
| FormulaDetector | Deteccion de errores en formulas | Operativo |
| MethodologyChecker | Validacion de supuestos | Operativo |
| ChallengerGenerator | Generacion de Notebooks | **NUEVO - Operativo** |
| VIRFAgent | Orquestacion de flujo | Actualizado |
| ConsolidatorSkill | Generacion de informes | Operativo |
| WordExporter | Exportacion a Word | Operativo |

---

## Contacto y Ayuda

Para mas informacion consulta:
- `FLUJO_COMPLETO_CHALLENGER.md` - Documentacion detallada
- `agent/skills/challenger_generator.py` - Codigo fuente del generador
- `agent/virf_agent.py` - Clase principal

¡Exito en tus validaciones! 

**Ultima actualizacion:** 2026-06-03
