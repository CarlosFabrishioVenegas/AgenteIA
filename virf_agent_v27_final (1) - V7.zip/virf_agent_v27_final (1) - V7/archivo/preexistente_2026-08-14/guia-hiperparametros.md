# Guía Completa de Hiperparámetros en Data Science

Esta guía ha sido diseñada especialmente para **científicos de datos, ingenieros industriales y especialistas técnicos** que buscan dominar la parametrización de sus modelos de aprendizaje automático y deep learning [324, 329]. A través de un enfoque riguroso, matemático y orientado a la industria (banca, minería, cemento y procesos productivos), este documento detalla el funcionamiento de cada hiperparámetro clave, sus interacciones y las mejores estrategias de sintonización (tuning) [192, 202].

---

## Tabla Resumen de Modelos y sus Hiperparámetros Críticos

La siguiente tabla presenta una vista rápida del ecosistema de modelos cubiertos, indicando la cantidad de hiperparámetros analizados y los tres que poseen mayor impacto sobre el balance de sesgo-varianza y el rendimiento de cómputo [16, 209].

| # | Familia de Modelo | Cantidad de Hiperparámetros | 3 Hiperparámetros Más Críticos (Prioritarios) |
|---|---|:---:|---|
| 1 | Regresión Lineal Regularizada | 3 | `alpha` (L1/L2), `l1_ratio` (elastic net), `fit_intercept` |
| 2 | Regresión Logística | 3 | `C` (regularización), `penalty` (norma), `solver` (optimizador) |
| 3 | K-Nearest Neighbors (KNN) | 3 | `n_neighbors` (vecinos), `metric` (distancia), `weights` (pesos) |
| 4 | Naive Bayes | 3 | `alpha` (Laplace), `var_smoothing` (GaussianNB), `fit_prior` |
| 5 | Support Vector Machines (SVM) | 4 | `C` (costo), `gamma` (RBF), `kernel` (tipo), `epsilon` (SVR) |
| 6 | Árboles de Decisión (CART) | 5 | `max_depth`, `min_samples_split`, `min_samples_leaf` |
| 7 | Random Forest | 4 | `n_estimators` (árboles), `max_features` (variables), `min_samples_leaf` |
| 8 | Gradient Boosting Trees (GBRT) | 4 | `learning_rate` (tasa), `n_estimators`, `subsample` |
| 9 | XGBoost | 5 | `learning_rate` (eta), `max_depth`, `min_child_weight` |
| 10| LightGBM | 4 | `num_leaves`, `min_data_in_leaf`, `learning_rate` |
| 11| CatBoost | 5 | `depth` (simétrico), `l2_leaf_reg`, `learning_rate` |
| 12| AdaBoost | 3 | `n_estimators`, `learning_rate`, `estimator` |
| 13| Clustering (K-Means/DBSCAN/Hierarchical) | 4 | `n_clusters` (K-Means), `eps` (DBSCAN), `min_samples` (DBSCAN) |
| 14| Dimensionality Reduction (PCA/t-SNE/UMAP) | 4 | `n_components`, `perplexity` (t-SNE), `n_neighbors` (UMAP) |
| 15| Redes Neuronales Densas (MLP) | 3 | `hidden_layer_sizes` (arquitectura), `activation`, `alpha` (regularización L2) |
| 16| Redes Neuronales Convolucionales (CNN) | 4 | `kernel_size` (filtro), `stride` (paso), `pool_size` (agrupamiento) |
| 17| Redes Neuronales Recurrentes (RNN/LSTM/GRU)| 4 | `hidden_size` (memoria), `num_layers` (capas), `dropout` |
| 18| Transformers | 4 | `d_model` (dimensión), `nhead` (cabezales), `dim_feedforward` |

---

## 1. Regresión Lineal / Ridge / Lasso / ElasticNet

Los modelos lineales regularizados añaden un término de penalización a la suma residual de cuadrados (RSS) para evitar el sobreajuste y estabilizar el modelo ante la multicolinealidad [2, 50, 324].

### 1.1 Multiplicador de Regularización (`alpha` o `lambda` en la literatura)
- **Modelo(s)**: Ridge, Lasso, ElasticNet, SGDRegressor [330, 331, 332, 376].
- **Nivel**: Básico
- **Qué controla**: Controla la severidad de la penalización de los coeficientes del modelo. Multiplica el término de la norma L1 (`Lasso`), L2 (`Ridge`) o la combinación de ambas (`ElasticNet`) [2, 330, 331, 332]. En la fórmula de Ridge, añade \(\alpha \sum_{j=1}^p \theta_j^2\) al error cuadrático medio, forzando a que las magnitudes de los coeficientes disminuyan [377, 378]. En Lasso, añade \(\alpha \sum_{j=1}^p |\theta_j|\), induciendo a que los coeficientes menos importantes se reduzcan a exactamente cero [379, 380].
- **Valores típicos**: Rango logarítmico exponencial [73]. Por ejemplo, `[1e-5, 1e-4, 1e-3, 0.01, 0.1, 1.0, 10.0, 100.0]`. Default en scikit-learn = `1.0`.
- **Qué pasa si es muy alto**: Provoca un fuerte subajuste (underfitting). Los coeficientes se contraen demasiado hacia cero (en Ridge) o se eliminan por completo (en Lasso), convirtiendo la recta en un modelo plano equivalente al promedio de la variable objetivo [378, 381, 415].
- **Qué pasa si es muy bajo**: Se reduce al estimador clásico de mínimos cuadrados ordinarios (OLS) [367, 378]. Si hay alta colinealidad o más variables que observaciones (\(p > n\)), el modelo sufrirá de sobreajuste severo, varianza extrema e inestabilidad numérica (matrices no invertibles) [36, 227].
- **Interacción con otros hiperparámetros**: Íntimamente relacionado con `l1_ratio` (ElasticNet) [332]. A mayor `alpha`, el impacto de la elección de la penalización L1 vs L2 se magnifica de forma exponencial [342].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en escala logarítmica (`GridSearchCV` o `RidgeCV` / `LassoCV` en scikit-learn, que utilizan la validación cruzada eficiente "leave-one-out" de forma nativa) [229, 328, 424].
- **Error común**: Intentar regularizar datos sin estandarizar previamente. Los algoritmos penalizan la magnitud absoluta de los coeficientes. Si una variable está en milímetros y otra en kilómetros, la variable con escala menor recibirá una penalización injustamente alta [461, 500].
- **Aplicación práctica industrial**: *Cemento (Pacasmayo)*. Predicción de la resistencia a la compresión del clínker en base a las proporciones químicas porcentuales del mineral de alimentación. Al estar las composiciones altamente correlacionadas (multicolinealidad), un OLS tradicional arroja coeficientes absurdos (e.g. correlación positiva teórica con signo negativo). Sintonizar `alpha` estabiliza los coeficientes físicos permitiendo la interpretación correcta para el operador de horno [479, 518].
- **Referencia**: Tibshirani, R. (1996). *Regression Shrinkage and Selection via the Lasso*. Journal of the Royal Statistical Society [262].
- **Prioridad**: 🔥 Esencial

### 1.2 Proporción de Mezcla de Penalizaciones (`l1_ratio` o `r`)
- **Modelo(s)**: ElasticNet [332, 382].
- **Nivel**: Intermedio
- **Qué controla**: Es el factor de ponderación convexa entre la penalización L1 (Lasso) y L2 (Ridge) [82, 332, 382]. En la función de costo: \(J(\theta) = \text{MSE}(\theta) + r \alpha \sum |\theta_i| + \frac{1-r}{2} \alpha \sum \theta_i^2\) [383]. Un valor de `l1_ratio = 1.0` equivale a Lasso puro, y `l1_ratio = 0.0` equivale a Ridge puro [382].
- **Valores típicos**: Rango cerrado `[0.0, 1.0]` [342]. Default en scikit-learn = `0.5`.
- **Qué pasa si es muy alto**: El modelo se comportará como Lasso, promoviendo la "escasez" (sparsity), forzando a que las variables menos influyentes tengan coeficientes exactamente de cero y realizando una selección automática de variables [2, 330, 415].
- **Qué pasa si es muy bajo**: El modelo se comportará como Ridge. Mantendrá todas las variables en el modelo pero reduciendo uniformemente su magnitud, lo cual es perjudicial si la mayoría de variables del dataset son puramente ruido [2, 331, 381].
- **Interacción con otros hiperparámetros**: Su efectividad depende directamente de la magnitud de `alpha` [332]. Si `alpha` es muy cercano a cero, alterar `l1_ratio` no tendrá ningún efecto perceptible [342].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula bidimensional combinando `alpha` y `l1_ratio`. Se recomienda probar valores específicos como `[0.1, 0.5, 0.7, 0.9, 0.95, 0.99, 1.0]` debido a que el comportamiento óptimo suele concentrarse cerca de L1 para lograr sparsity conservando el efecto de agrupación de Ridge [342, 420].
- **Error común**: Ajustar `l1_ratio` muy alto en presencia de variables altamente correlacionadas, esperando que el modelo seleccione de forma estable. Lasso tiende a elegir una variable al azar del grupo correlacionado e ignorar las demás. Mantener un `l1_ratio` menor (e.g. 0.5 - 0.8) permite el "efecto agrupación" (grouping effect) donde los coeficientes correlacionados entran o salen juntos [262, 441].
- **Aplicación práctica industrial**: *Minería (Flotación)*. Selección de sensores clave de un total de 120 variables de proceso correlacionadas (vibración de molino, flujo de agua, presión de aire, pH) para predecir la recuperación de mineral valioso. ElasticNet selecciona un conjunto representativo y estable sin descartar arbitrariamente variables físicas complementarias [480, 519].
- **Referencia**: Zou, H., & Hastie, T. (2005). *Regularization and variable selection via the elastic net*. Journal of the Royal Statistical Society [262, 342, 368].
- **Prioridad**: ⚡ Importante

### 1.3 Ajustar Intercepto (`fit_intercept`)
- **Modelo(s)**: LinearRegression, Ridge, Lasso, ElasticNet, SGDRegressor [187, 221, 222].
- **Nivel**: Básico
- **Qué controla**: Define si el modelo calculará matemáticamente el sesgo o intercepto de la función lineal (\(\theta_0\) o sesgo \(b\)) [183, 378]. Si se configura como `False`, se asume que los datos están perfectamente centrados y que la recta o hiperplano de regresión debe pasar obligatoriamente por el origen dimensional exacto (0,0) [221, 378].
- **Valores típicos**: Booleano: `True` o `False` [221, 222]. Default en scikit-learn = `True`.
- **Qué pasa si es muy alto**: N/A (Booleano).
- **Qué pasa si es muy bajo**: Si se define como `False` en datos no centrados, el modelo intentará forzar el paso por el origen, sesgando severamente todos los coeficientes dependientes y arruinando la métrica de ajuste R2, que puede volverse altamente negativa [188, 378].
- **Interacción con otros hiperparámetros**: Si `fit_intercept=True` pero los datos ya han sido preprocesados con un escalador (como `StandardScaler`), el intercepto calculado será prácticamente cero [390].
- **Estrategia de tuning recomendada**: Por regla empírica del negocio. Mantener siempre en `True`, a menos que por leyes físicas estrictas del proceso de ingeniería sepamos que cuando todas las variables predictoras valen cero, la variable objetivo debe ser exactamente cero [378, 390].
- **Error común**: Desactivar `fit_intercept` para simplificar el modelo sin haber centrado previamente la variable objetivo \(Y\), provocando un grave sesgo sistemático en las predicciones [378].
- **Aplicación práctica industrial**: *Manufactura / Metalurgia*. Estimación del desgaste de un revestimiento interno en milímetros en base a las horas de operación acumuladas. Si las horas son cero, el desgaste debe ser exactamente cero, lo que justifica parametrizar `fit_intercept=False` para respetar la restricción física del sistema real.
- **Referencia**: Documentación oficial de Scikit-Learn (Linear Models) [362].
- **Prioridad**: 💡 Opcional

## 2. Regresión Logística

La regresión logística es el estándar industrial para clasificación probabilística binaria y multiclase, mapeando una combinación lineal de las características mediante la función sigmoidea [183, 283, 284].

### 2.1 Parámetro del Término de Penalización (`C`)
- **Modelo(s)**: LogisticRegression [93, 138, 221].
- **Nivel**: Básico
- **Qué controla**: Es el parámetro inverso de la fuerza de regularización [93, 386]. Matemáticamente se expresa como \(C = 1 / \lambda\) o \(C = 1 / \alpha\) [176, 256]. Un valor menor de `C` especifica una regularización más fuerte (penaliza coeficientes grandes con mayor severidad), mientras que valores altos de `C` permiten al modelo ajustar los pesos con mayor libertad al entrenar [93, 386].
- **Valores típicos**: Rango logarítmico: `[0.001, 0.01, 0.1, 1.0, 10.0, 100.0]` [75, 138]. Default en scikit-learn = `1.0`.
- **Qué pasa si es muy alto**: El modelo se desregulariza, permitiendo coeficientes con magnitudes elevadas [327, 433]. Esto conduce a sobreajuste (overfitting), donde el límite de decisión se vuelve demasiado complejo y sensible al ruido operacional [174, 433].
- **Qué pasa si es muy bajo**: Provoca un subajuste (underfitting) extremo. La regularización comprime casi todos los coeficientes hacia cero, impidiendo que el modelo aprenda patrones complejos y reduciendo el clasificador a una constante basada únicamente en el sesgo promedio [174, 381, 415].
- **Interacción con otros hiperparámetros**: Interactúa críticamente con el tipo de penalización (`penalty`) [176, 244]. Si se define `penalty='l1'`, un `C` bajo extinguirá la mayoría de características del dataset [175, 259].
- **Estrategia de tuning recomendada**: Búsqueda exponencial cruzada (`GridSearchCV` o optimización bayesiana con `Optuna` o `Hyperopt`) evaluada bajo la métrica F1-Macro o AUC-ROC en contextos de desbalance de clases [155, 177, 224].
- **Error común**: Configurar valores de `C` extremadamente pequeños (e.g. 1e-7) sin darse cuenta de que están silenciando por completo todas las variables predictoras del modelo de clasificación [174].
- **Aplicación práctica industrial**: *Banca (Riesgos - BCP)*. Modelo de Admisión Crediticia. Predicción de la probabilidad de impago (default) de un cliente minorista. Ajustar adecuadamente `C` evita que variables de comportamiento transaccional reciente (muy ruidosas) dominen la decisión, asegurando que el modelo generalice de forma estable ante cambios en el ciclo económico [163].
- **Referencia**: Sayed, A. H. (2023). *Inference and Learning from Data Volume II_ Inference* [226, 283].
- **Prioridad**: 🔥 Esencial

### 2.2 Tipo de Penalización (`penalty`)
- **Modelo(s)**: LogisticRegression [93, 218].
- **Nivel**: Intermedio
- **Qué controla**: Especifica la norma matemática utilizada para penalizar la complejidad del vector de pesos [173, 218]. Las opciones estándar en scikit-learn son `'l2'` (Ridge, penalización cuadrática), `'l1'` (Lasso, penalización de valor absoluto), `'elasticnet'` (combinación lineal de ambas) y `'none'` o `None` (sin regularización) [172, 176].
- **Valores típicos**: `['l1', 'l2', 'elasticnet', None]` [176]. Default en scikit-learn = `'l2'`.
- **Qué pasa si es muy alto**: N/A (Parámetro categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Restringe fuertemente la elección del solucionador numérico (`solver`) [221, 222]. Por ejemplo, el optimizador clásico `'lbfgs'` solo soporta `'l2'` o `None` [387]. Para utilizar `'l1'` se requiere usar solucionadores como `'liblinear'` o `'saga'` [93].
- **Estrategia de tuning recomendada**: Condicionada por el objetivo de negocio. Si el objetivo es el despliegue rápido en producción con recursos limitados de CPU, priorizar `'l1'` para realizar selección de variables integrada [175, 259]. Si se busca máxima robustez y precisión predictiva pura, priorizar `'l2'` [175].
- **Error común**: Intentar entrenar una regresión logística con `penalty='l1'` usando el solver por defecto `'lbfgs'`, lo cual disparará un error inmediato en tiempo de ejecución de Python, deteniendo el flujo automático de producción [387].
- **Aplicación práctica industrial**: *Banca (BCP)*. Detección de fraude con tarjetas de crédito. Dado que existen miles de variables de telemetría transaccional (coincidencia de IPs, velocidad de compra, montos históricos), configurar `penalty='l1'` depura el modelo en tiempo real, apagando el 95% de variables irrelevantes y reduciendo la latencia de respuesta de la API a menos de 50 milisegundos [175, 259].
- **Referencia**: Murphy, K. P. (2025). *Probabilistic Machine Learning: An Introduction* [329, 420].
- **Prioridad**: ⚡ Importante

### 2.3 Algoritmo de Optimización (`solver`)
- **Modelo(s)**: LogisticRegression [218, 221].
- **Nivel**: Avanzado
- **Qué controla**: Especifica el algoritmo numérico encargado de aproximar la solución al problema de optimización convexa (minimización de la entropía cruzada) [1, 218].
- **Valores típicos**: `['lbfgs', 'liblinear', 'newton-cg', 'sag', 'saga']` [221, 222]. Default en scikit-learn = `'lbfgs'`.
- **Qué pasa si es muy alto**: N/A (Categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Su efectividad está dictada por el tamaño del dataset (filas) y el tipo de penalización [93]. `'saga'` y `'sag'` son los únicos solucionadores eficientes que convergen en tiempo razonable para datasets masivos, y son altamente sensibles al preprocesamiento de escalamiento de variables [93, 171].
- **Estrategia de tuning recomendada**: Para datasets pequeños o medianos, usar `'lbfgs'` [387]. Para datasets lineales masivos con variables escasas, usar `'saga'` con datos estandarizados [93].
- **Error común**: Utilizar `'liblinear'` en datasets masivos creyendo que acelerará el proceso por ser simple, ignorando que es un solucionador de coordenadas descendentes de un solo hilo que escalará de forma prohibitiva en tiempo [93, 171].
- **Aplicación práctica industrial**: *Banca / CRM*. Análisis de propensión de compra de préstamos personales sobre millones de clientes activos. Cambiar el solver por defecto `'lbfgs'` a `'saga'` reduce el tiempo de reentrenamiento semanal de 3 horas a menos de 10 minutos, manteniendo exactamente la misma precisión [93, 171].
- **Referencia**: Pedregosa, F. et al. (2011). *Scikit-learn: Machine Learning in Python* [125].
- **Prioridad**: 💡 Opcional

## 3. K-Nearest Neighbors (KNN)

KNN es un clasificador y regresor no paramétrico basado en instancias, que fundamenta su inferencia en la hipótesis de que las observaciones similares residen juntas en el espacio n-dimensional [98, 120, 235].

### 3.1 Número de Vecinos (`n_neighbors` o `k`)
- **Modelo(s)**: KNeighborsClassifier, KNeighborsRegressor [49, 125].
- **Nivel**: Básico
- **Qué controla**: Define la cantidad de muestras más cercanas del conjunto de entrenamiento que se evaluarán para emitir la predicción de un nuevo dato (por voto de mayoría en clasificación o por promedio aritmético en regresión) [91, 108, 120].
- **Valores típicos**: Enteros impares (para evitar empates en clasificación binaria) de `[1, 3, 5, 11, 15, 21]` o la regla empírica \(k = \sqrt{n}\) donde \(n\) es el número de muestras [101, 122, 359, 360]. Default en scikit-learn = `5` [100, 110].
- **Qué pasa si es muy alto**: Conduce a un subajuste y sobre-suavizado de la frontera de decisión [122]. El modelo se vuelve demasiado simple e introduce un sesgo elevado al verse influenciado por muestras lejanas de otras clases en regiones densas [10, 11, 446].
- **Qué pasa si es muy bajo**: (e.g. `n_neighbors = 1`) Provoca un sobreajuste masivo [11]. El modelo memoriza el ruido de entrenamiento obteniendo un error de cero en el set de desarrollo, pero se vuelve extremadamente sensible a datos anómalos (outliers) y ruido operacional, con una varianza insostenible en validación [8, 10, 122].
- **Interacción con otros hiperparámetros**: Su efectividad depende críticamente del escalamiento previo del espacio n-dimensional [461, 500]. Si las características no están estandarizadas, el cálculo de vecinos se sesgará por completo hacia las variables con magnitudes numéricas mayores [461, 500].
- **Estrategia de tuning recomendada**: Graficar la curva de complejidad (Error vs `K`) tanto en el set de entrenamiento como en el de validación cruzada para identificar visualmente el punto óptimo del codo donde se minimiza el error de generalización [11, 13].
- **Error común**: Configurar un valor de `K` par (como `4` o `6`) en problemas de clasificación binaria, provocando empates constantes que scikit-learn resolverá de forma aleatoria, dañando la reproducibilidad científica [101, 122].
- **Aplicación práctica industrial**: *Minería (Exploración Geológica)*. Clasificación rápida del tipo de roca o dureza del mineral basándose en mediciones tridimensionales de perforación. Un `K` óptimo filtra el ruido de los sensores de perforación sin perder la definición geométrica de las vetas de mineral [473, 512].
- **Referencia**: Sayed, A. H. (2023). *Inference and Learning from Data Volume III_ Learning* [227, 263].
- **Prioridad**: 🔥 Esencial

### 3.2 Métrica de Distancia (`metric`)
- **Modelo(s)**: KNeighborsClassifier, KNeighborsRegressor [100, 109].
- **Nivel**: Intermedio
- **Qué controla**: Define la función matemática utilizada para cuantificar la "cercanía" u homofilia espacial entre los vectores de características en el espacio multidimensional [100, 219].
- **Valores típicos**: `'euclidean'` (L2), `'manhattan'` (L1), `'chebyshev'` (L-infinito) o `'minkowski'` generalizada [100, 101, 121, 371]. Default en scikit-learn = `'minkowski'` con parámetro de potencia `p=2` (que equivale a la Euclidiana) [100].
- **Qué pasa si es muy alto**: N/A (Categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Si se utiliza `'minkowski'`, el hiperparámetro de potencia `p` controla la transición continua de L1 (`p=1`) a L2 (`p=2`) [100, 110].
- **Estrategia de tuning recomendada**: Evaluar la métrica en conjunto con las dimensiones del dataset [9]. En espacios de alta dimensionalidad (\(d > 20\)), la distancia Euclidiana sufre fuertemente por la "maldición de la dimensionalidad" (todas las distancias convergen al mismo valor) [9, 99, 267]. Manhattan (`p=1`) suele ser más estable en dimensiones altas [99, 109].
- **Error común**: Usar la distancia Euclidiana clásica sobre datos mixtos (numéricos y categóricos codificados con One-Hot), lo que genera distancias inconsistentes y sin sentido físico real [101, 357].
- **Aplicación práctica industrial**: *Logística / Cadena de Suministro*. Optimización del flujo de repuestos críticos entre almacenes interconectados. Al calcular distancias de ruta en ciudades con trazado de cuadrícula, la métrica de Manhattan (`manhattan`) predice con precisión milimétrica los tiempos reales de traslado frente a la Euclidiana aérea clásica.
- **Referencia**: Cover, T., & Hart, P. (1967). *Nearest neighbor pattern classification*. IEEE Transactions on Information Theory [3, 9].
- **Prioridad**: ⚡ Importante

### 3.3 Ponderación de los Vecinos (`weights`)
- **Modelo(s)**: KNeighborsClassifier, KNeighborsRegressor [100, 110].
- **Nivel**: Intermedio
- **Qué controla**: Define si todos los `K` vecinos tendrán el mismo peso en la decisión final o si su influencia se ponderará de forma inversamente proporcional a su distancia física respecto a la consulta [100, 110, 265].
- **Valores típicos**: `['uniform', 'distance']` [100, 110]. Default en scikit-learn = `'uniform'`.
- **Qué pasa si es muy alto**: N/A (Categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Su configuración como `'distance'` amortigua el impacto negativo de elegir un `n_neighbors` demasiado alto, ya que los vecinos lejanos tendrán una influencia matemáticamente insignificante en el resultado [265].
- **Estrategia de tuning recomendada**: Probar `'distance'` si los datos de validación cruzada muestran patrones altamente densos pero con bordes de decisión ruidosos o mezclados [265].
- **Error común**: Configurar `'distance'` en datasets con alto nivel de ruido en las etiquetas, lo que provocará que el modelo se comporte de forma errática al dar un peso infinito a un vecino ruidoso que coincida exactamente con la muestra evaluada.
- **Aplicación práctica industrial**: *Banca / Scoring*. Segmentación y tasación automática de propiedades inmobiliarias para colaterales de crédito hipotecario. Los inmuebles inmediatamente adyacentes proveen una referencia de precio drásticamente superior a los ubicados a 500 metros, lo cual se captura perfectamente parametrizando `weights='distance'` [49].
- **Referencia**: Altman, N. S. (1992). *An introduction to kernel and nearest-neighbor nonparametric regression*. The American Statistician [108].
- **Prioridad**: 💡 Opcional

## 4. Naive Bayes (Gaussian, Multinomial, Bernoulli)

Naive Bayes es un conjunto de algoritmos clasificadores probabilísticos basados en el Teorema de Bayes que asumen una fuerte (y simplista) independencia condicional entre todas las variables predictoras dado el estado de la clase [15, 58, 427].

### 4.1 Parámetro de Suavizado de Laplace (`alpha`)
- **Modelo(s)**: MultinomialNB, BernoulliNB [95, 148].
- **Nivel**: Básico
- **Qué controla**: Controla el factor de suavizado aditivo (Laplace / Lidstone) [18, 95]. Añade un pseudo-conteo artificial al numerador y denominador al calcular la probabilidad condicional de cada palabra o categoría: \(\hat{\theta}_{jck} = \frac{N_{dck} + \alpha}{N_c + \alpha K}\) [18, 430]. Esto evita el fenómeno catastrófico del "error de probabilidad cero" cuando una categoría no aparece en el set de entrenamiento de una clase [95, 338].
- **Valores típicos**: Rango lineal/escala fina: `[0.01, 0.1, 0.5, 1.0, 2.0, 5.0]` [148, 151]. Default en scikit-learn = `1.0` (Suavizado de Laplace) [95].
- **Qué pasa si es muy alto**: Provoca un sobre-suavizado extremo de las probabilidades. Todas las probabilidades de transición de las variables condicionales tenderán a igualarse de forma artificial hacia una distribución uniforme, anulando por completo el poder discriminativo del modelo y conduciendo a subajuste [10, 18].
- **Qué pasa si es muy bajo**: (e.g. `alpha = 0.0` o extremadamente pequeño). Se anula el suavizado. Si un nuevo lote de datos contiene un solo sensor o palabra que nunca antes se vio en la clase, la probabilidad acumulada del producto condicional colapsará instantáneamente a cero, impidiendo que el modelo lo clasifique [95].
- **Interacción con otros hiperparámetros**: N/A.
- **Estrategia de tuning recomendada**: Búsqueda lineal fina usando validación cruzada F1-Score [151, 325].
- **Error común**: Desactivar por completo el suavizado de Laplace (`alpha=0`) creyendo que mejorará la pureza de clasificación, provocando fallas masivas del clasificador al procesar datos operacionales en vivo [95].
- **Aplicación práctica industrial**: *Banca / Atención al Cliente*. Clasificación automatizada de correos electrónicos y reclamos dirigidos a las agencias bancarias (e.g., reclamos de fraude vs solicitudes de préstamo). Configurar `alpha=1.0` asegura que palabras de vocabulario nuevo o poco frecuente introducidas por el cliente no arruinen la probabilidad predictiva del sistema [338].
- **Referencia**: Sayed, A. H. (2023). *Inference and Learning from Data Volume II_ Inference* [272].
- **Prioridad**: 🔥 Esencial

### 4.2 Aprender Probabilidades Previas de Clase (`fit_prior`)
- **Modelo(s)**: GaussianNB, MultinomialNB, BernoulliNB [148, 150].
- **Nivel**: Básico
- **Qué controla**: Determina si el clasificador calculará de forma automática las probabilidades de clase a priori basadas en su proporción empírica en el conjunto de entrenamiento (frecuencia relativa), o si por el contrario asumirá una distribución a priori perfectamente uniforme para todas las clases [148, 150, 276].
- **Valores típicos**: Booleano: `True` o `False` [148]. Default en scikit-learn = `True`.
- **Qué pasa si es muy alto**: N/A.
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Si se parametriza como `False`, se puede suministrar manualmente un vector de probabilidades pre-calculadas usando el hiperparámetro `class_prior` [151].
- **Estrategia de tuning recomendada**: Evaluar la representatividad de la muestra. Si el desbalance de clases de tu conjunto de entrenamiento representa fielmente la realidad física u operativa en producción, mantener en `True` [274]. Si el dataset de entrenamiento ha sido balanceado artificialmente (submuestreo), usar `fit_prior=False` para evitar sesgar el clasificador [151].
- **Error común**: Configurar `fit_prior=True` sobre datasets donde una clase crítica está subrepresentada únicamente por falta de recolección de muestras, provocando que el modelo de Bayes la ignore sistemáticamente por su bajísima probabilidad prior [274, 466].
- **Aplicación práctica industrial**: *Cemento / Control de Calidad*. Clasificación de la calidad del empaque del cemento (e.g. bolsas rotas vs bolsas correctas). Las bolsas rotas ocurren en menos del 0.05% de los casos. Configurar `fit_prior=False` nos permite entrenar un modelo con datos balanceados sin que el sesgo de la probabilidad prior ignore el evento de falla crítico [466].
- **Referencia**: Rish, I. (2001). *An empirical study of the naive Bayes classifier*. IJCAI [323].
- **Prioridad**: ⚡ Importante

### 4.3 Estabilizador de Varianza (`var_smoothing` para GaussianNB)
- **Modelo(s)**: GaussianNB [94, 236].
- **Nivel**: Avanzado
- **Qué controla**: Porción de la varianza más grande obtenida entre todas las características que se le añade de forma artificial a la varianza de cada una de las variables [94]. Actúa como un factor estabilizador numérico para ensanchar de forma artificial la curva normal Gaussiana de probabilidad [94, 236].
- **Valores típicos**: Rango extremadamente pequeño: `[1e-9, 1e-8, 1e-6, 1e-4]`. Default en scikit-learn = `1e-9`.
- **Qué pasa si es muy alto**: Aplana y ensancha artificialmente las campanas Gaussianas, lo que incrementa el sesgo del clasificador y diluye la diferencia entre clases de variables muy concentradas, conduciendo a subajuste.
- **Qué pasa si es muy bajo**: Puede provocar inestabilidad numérica extrema en tiempo de ejecución. Si una variable tiene una varianza empírica de prácticamente cero (e.g., lecturas constantes de un sensor industrial bajo control), calcular la función de densidad de probabilidad Gaussiana generará divisiones por cero o desbordamientos lógicos (overflow).
- **Interacción con otros hiperparámetros**: N/A.
- **Estrategia de tuning recomendada**: Usar búsqueda en cuadrícula logarítmica si se observa que el modelo falla en presencia de características numéricas con varianzas extremadamente dispares.
- **Error común**: Ignorar este hiperparámetro al procesar variables continuas industriales que tienen rangos estables de medición, provocando errores silenciosos de cálculo de densidades [94].
- **Aplicación práctica industrial**: *Minería / Planta de Calcinación*. Monitoreo de vibración constante de polines en fajas transportadoras. Si un polín funciona con lecturas perfectas y estables (varianza casi nula), `var_smoothing` garantiza que el cálculo no colapse y que pequeñas desviaciones del sensor no se traduzcan en falsas alarmas probabilísticas extremas [461, 500].
- **Referencia**: Duda, R. O., Hart, P. E., & Stork, D. G. (2001). *Pattern Classification*. Wiley [3].
- **Prioridad**: 💡 Opcional

## 5. Support Vector Machines (SVC, SVR)

SVM es un modelo robusto de aprendizaje supervisado que proyecta el conjunto de características hacia espacios de dimensiones superiores utilizando el método del kernel, con el fin de maximizar el margen geométrico de separación entre clases o ajustar un tubo de tolerancia de error a la función de regresión [85, 96, 239].

### 5.1 Parámetro de Costo de Penalización (`C`)
- **Modelo(s)**: SVC, SVR, LinearSVC, LinearSVR [40, 96, 97, 203].
- **Nivel**: Básico
- **Qué controla**: Es el parámetro de regularización de la función objetivo de optimización de SVM [40, 240, 315]. Controla el balance dinámico entre maximizar el ancho del "margen de la calle" (margen geométrico) y penalizar de forma lineal las violaciones del margen o las clasificaciones erróneas del conjunto de entrenamiento mediante variables de holgura (slack variables \(\xi_i\)) [313, 315, 348]. Un `C` menor da mayor flexibilidad al modelo y tolera más violaciones, mientras que un `C` alto exige que la separación sea estrictamente perfecta en los datos de entrenamiento [315, 316, 370].
- **Valores típicos**: Rango logarítmico: `[0.01, 0.1, 1.0, 10.0, 100.0, 1000.0]` [75, 198]. Default en scikit-learn = `1.0` [196].
- **Qué pasa si es muy alto**: Obliga al modelo a evitar a toda costa cualquier error de clasificación de entrenamiento, lo que conduce a un sobreajuste extremo [97, 327, 348]. El hiperplano de separación se volverá sumamente complejo y sinuoso para capturar cada punto ruidoso del dataset [97].
- **Qué pasa si es muy bajo**: Prioriza la máxima anchura de margen geométrico sobre la precisión de entrenamiento, provocando un subajuste severo [107]. Tolera demasiados errores de entrenamiento, lo que destruye el poder predictivo del modelo en producción [97, 107].
- **Interacción con otros hiperparámetros**: Su comportamiento depende críticamente de la elección del `kernel` [327]. Con el kernel `'linear'`, el modelo es linealmente restrictivo [394]. Con el kernel `'rbf'`, interactúa con el parámetro de radio `gamma` [240].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula exponencial bidimensional gruesa y luego fina combinando `C` y `gamma` utilizando validación cruzada [202, 392].
- **Error común**: Ajustar un `C` sumamente alto sobre datasets ruidosos. SVM no maneja bien de forma nativa los conjuntos de datos que poseen un alto solapamiento de clases, por lo que un `C` alto solo incrementará de forma desastrosa el tiempo de entrenamiento O(n³) y sobreajustará el modelo [315, 395].
- **Aplicación práctica industrial**: *Banca / Ciberseguridad*. Clasificación de firmas digitales y patrones biométricos para autenticación en aplicaciones móviles bancarias (BCP). Un valor de `C` moderado permite una generalización geométrica óptima ante cambios menores de iluminación o sensor sin rechazar a usuarios legítimos.
- **Referencia**: Cortes, C., & Vapnik, V. (1995). *Support-vector networks*. Machine Learning [85, 369].
- **Prioridad**: 🔥 Esencial

### 5.2 Coeficiente de Kernel (`gamma`)
- **Modelo(s)**: SVC, SVR [240, 316, 327].
- **Nivel**: Intermedio
- **Qué controla**: Define la distancia de influencia matemática de cada uno de los vectores de soporte individuales [217, 315, 327]. Para el kernel `'rbf'` (función de base radial), controla el parámetro de ancho de banda local [316]: \(K(x,y) = \exp(-\gamma ||x-y||^2)\). Un `gamma` alto decrece drásticamente el radio de influencia, requiriendo que los nuevos puntos estén extremadamente cerca de los vectores de soporte para ser clasificados en la misma clase [240].
- **Valores típicos**: `['scale', 'auto']` o valores numéricos en escala logarítmica exponencial: `[1e-4, 1e-3, 0.01, 0.1, 1.0, 10.0]` [198, 200]. Default en scikit-learn = `'scale'` (que equivale a \(1 / (d \times \text{Var}(X))\)) [200].
- **Qué pasa si es muy alto**: Provoca un sobreajuste masivo y localizado [97, 327]. El modelo rodea de forma estrecha y aislada a cada punto de entrenamiento (islas aisladas de decisión), perdiendo completamente la capacidad de generalización espacial global [70, 97].
- **Qué pasa si es muy bajo**: El radio de influencia se expande tanto que el clasificador se comporta de forma cuasi-lineal, ignorando los patrones curvados complejos y conduciendo a subajuste del modelo [240, 327].
- **Interacción con otros hiperparámetros**: Su sintonización está totalmente enlazada con `C` [316]. Si `gamma` es muy bajo, `C` no tendrá suficientes regiones complejas que sintonizar.
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula logarítmica bidimensional cruzada. Un punto de partida ideal es el valor por defecto de `'scale'` [200].
- **Error común**: Incrementar `gamma` en exceso tratando de aumentar la precisión en entrenamiento, lo que convierte al modelo en un clasificador de memorización puntual de un solo vecino [70, 97].
- **Aplicación práctica industrial**: *Siderúrgica / Control de Calidad*. Clasificación no lineal de tipos de fallas de soldadura (estructural, superficial, poro) en base a 15 variables continuas de imágenes de rayos X. Ajustar un `gamma` óptimo rodea de forma suave las densidades no lineales de cada defecto geológico, minimizando los falsas alarmas de soldaduras conformes [477, 516].
- **Referencia**: Chang, C. C., & Lin, C. J. (2011). *LIBSVM: A library for support vector machines* [350].
- **Prioridad**: 🔥 Esencial

### 5.3 Tipo de Kernel (`kernel`)
- **Modelo(s)**: SVC, SVR [207, 316].
- **Nivel**: Intermedio
- **Qué controla**: Define la función matemática específica empleada para mapear de forma implícita los datos de entrada a un espacio de características de dimensiones superiores, donde las clases se vuelvan linealmente separables sin computar la costosa proyección de forma explícita (el truco del kernel) [85, 86, 96, 369].
- **Valores típicos**: `['linear', 'poly', 'rbf', 'sigmoid']` [198, 316, 327]. Default en scikit-learn = `'rbf'` [96, 240].
- **Qué pasa si es muy alto**: N/A (Categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: El kernel `'poly'` activa el parámetro de grado `degree` y el coeficiente independiente `coef0` [391]. El kernel `'linear'` es numéricamente mucho más veloz pero no puede modelar fronteras de decisión curvadas [97, 394].
- **Estrategia de tuning recomendada**: Empezar siempre probando `'linear'` por simplicidad y eficiencia de recursos (especialmente si hay miles de variables y pocas observaciones) [394]. Si hay patrones fuertemente no lineales comprobados y el volumen de datos no excede las 50,000 muestras, usar `'rbf'` [394, 395].
- **Error común**: Elegir `'rbf'` o `'poly'` por defecto en datasets masivos (\(n > 200,000\)), provocando que el entrenamiento en la CPU tarde días en completar debido al costo computacional cúbico \(O(n^3)\) de la implementación de la matriz de Gram de libsvm [97, 395].
- **Aplicación práctica industrial**: *Minería (Exploración)*. Clasificación geológica compleja de yacimientos de mineral. La alta irregularidad de la composición de la roca requiere el mapeo no lineal flexible que ofrece el kernel `'rbf'` para delimitar con exactitud las zonas de explotación segura [478, 517].
- **Referencia**: Vapnik, V. (1995). *The Nature of Statistical Learning Theory* [301, 302].
- **Prioridad**: ⚡ Importante

### 5.4 Ancho del Tubo de Tolerancia de Error (`epsilon` para SVR)
- **Modelo(s)**: SVR, LinearSVR [107, 318].
- **Nivel**: Avanzado
- **Qué controla**: Especifica el ancho de la banda o del "tubo" de tolerancia \(\epsilon\) alrededor de la función estimada de regresión, dentro del cual no se penaliza ninguna desviación de las muestras observadas en la función de pérdida del optimizador (pérdida \(\epsilon\)-insensible) [203, 318, 320]. Cualquier residuo menor a \(\epsilon\) vale exactamente cero en el cómputo de la optimización [318, 320].
- **Valores típicos**: Escala continua en relación con la escala de la variable objetivo: `[0.01, 0.05, 0.1, 0.2, 0.5]` [318, 351]. Default en scikit-learn = `0.1`.
- **Qué pasa si es muy alto**: El tubo de tolerancia se vuelve excesivamente ancho, permitiendo que casi todas las muestras de entrenamiento queden sin penalizar. Esto conduce a un fuerte subajuste y genera un regresor plano incapaz de capturar la tendencia de los datos.
- **Qué pasa si es muy bajo**: Se penaliza casi cualquier desviación insignificante por pequeña que sea, incrementando drásticamente el número de vectores de soporte, prolongando el tiempo de entrenamiento numérico y provocando sobreajuste al ruido [107].
- **Interacción con otros hiperparámetros**: Su efectividad se sintoniza en conjunto con el factor de costo `C` y los parámetros del `kernel` [315].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula logarítmica o regla empírica basada en el nivel de ruido de fondo de los sensores físicos del proceso industrial.
- **Error común**: Configurar `epsilon` en un valor numérico menor que el error instrumental de medición de los sensores industriales de campo, desperdiciando cómputo en forzar la precisión de decimales que representan puro ruido mecánico.
- **Aplicación práctica industrial**: *Minería / Automatización de Procesos*. Predicción del nivel de llenado de mineral en una celda de flotación industrial en base a telemetría hidráulica de sensores ultrasónicos. Ajustar `epsilon = 0.05` (5% de tolerancia de ruido ultrasónico) optimiza los recursos de la CPU y estabiliza las alertas de rebose operacional.
- **Referencia**: Smola, A. J., & Schölkopf, B. (2004). *A tutorial on support vector regression*. Statistics and Computing [302].
- **Prioridad**: ⚡ Importante

## 6. Árboles de Decisión (DecisionTreeClassifier / Regressor)

Los árboles de decisión (CART) dividen de forma recursiva el espacio multidimensional de entrada mediante cortes ortogonales a los ejes, buscando maximizar la homogeneidad de la variable objetivo dentro de cada una de las subregiones resultantes [102, 110, 269].

### 6.1 Profundidad Máxima del Árbol (`max_depth`)
- **Modelo(s)**: DecisionTreeClassifier, DecisionTreeRegressor [60, 64, 66].
- **Nivel**: Básico
- **Qué controla**: Define la longitud de la ruta más larga que va desde el nodo raíz hasta cualquier nodo hoja terminal en el árbol construido [158, 217]. Es el hiperparámetro principal para regular la capacidad de complejidad y la libertad geométrica del árbol [64, 402].
- **Valores típicos**: `[3, 5, 7, 10, 15, None]` (donde `None` indica que el árbol crecerá de forma ilimitada hasta lograr hojas perfectamente puras o alcanzar otros límites de parada) [64, 155, 402]. Default en scikit-learn = `None` [102, 104].
- **Qué pasa si es muy alto**: (e.g. `None` o superior a `15` en datasets pequeños). Provoca un sobreajuste severo del árbol [63, 102]. El algoritmo continuará dividiendo las muestras de forma recursiva hasta aislar cada una de las observaciones individuales de entrenamiento en sus propias hojas, memorizando por completo el ruido operacional [63, 102].
- **Qué pasa si es muy bajo**: (e.g. `max_depth = 1` o `2`, conocidos como tocones de decisión o decision stumps) [44]. Provoca un fuerte subajuste del modelo. El árbol será incapaz de capturar interacciones simples y relaciones no lineales complejas entre las características predictoras del sistema [308].
- **Interacción con otros hiperparámetros**: Altamente acoplado con `min_samples_split` y `min_samples_leaf` [190]. Restringir cualquiera de ellos disminuye la necesidad de fijar un `max_depth` estricto, ya que actúan de forma complementaria para regularizar el crecimiento [403].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en un rango acotado: `[3, 5, 7, 9, 11, 13]`. Rara vez se justifica en la práctica industrial permitir profundidades de un solo árbol CART superiores a `10` debido a la pérdida drástica de interpretabilidad para el personal de planta [63, 87].
- **Error común**: Dejar el parámetro por defecto `max_depth=None` en árboles individuales entrenados de forma directa en producción, generando árboles monstruosos e ininterpretables que fallarán catastróficamente al predecir sobre datos nuevos de validación cruzada [102].
- **Aplicación práctica industrial**: *Banca / CRM*. Creación de un flujo lógico de decisiones para que los asesores de la red de agencias recomienden campañas comerciales (e.g. oferta de tarjeta de crédito). Un `max_depth=4` genera una estructura jerárquica con reglas de decisión altamente intuitivas que caben perfectamente en una sola hoja impresa, facilitando el despliegue operativo en campo [152, 234].
- **Referencia**: Breiman, L. et al. (1984). *Classification and Regression Trees* [271, 343].
- **Prioridad**: 🔥 Esencial

### 6.2 Mínimo de Muestras para Dividir un Nodo (`min_samples_split`)
- **Modelo(s)**: DecisionTreeClassifier, DecisionTreeRegressor [64, 104, 105].
- **Nivel**: Intermedio
- **Qué controla**: Especifica la cantidad mínima de observaciones de entrenamiento que deben residir obligatoriamente en un nodo interno para que el algoritmo CART evalúe realizar una nueva división recursiva de sus ramas [60, 64].
- **Valores típicos**: Enteros: `[2, 5, 10, 20, 50, 100]` o porcentajes flotantes del total de la muestra [158, 190, 373]. Default en scikit-learn = `2` [112].
- **Qué pasa si es muy alto**: Regulariza fuertemente el árbol. Evita que el algoritmo continúe dividiendo subnodos pequeños, deteniendo el crecimiento de forma prematura y forzando a que las hojas contengan más muestras, previniendo sobreajuste pero arriesgando subajuste si es excesivo [158].
- **Qué pasa si es muy bajo**: (e.g. `2`, el default). Permite que el árbol evalúe divisiones sobre nodos extremadamente pequeños que contienen casi puras observaciones individuales, lo que conduce a memorizar el ruido de entrenamiento y sobreajustar [102, 158].
- **Interacción con otros hiperparámetros**: Su acción se combina con `min_samples_leaf` [403]. `min_samples_split` debe ser por definición matemática al menos el doble del valor configurado para `min_samples_leaf` para que la división sea realizable dentro de los límites de las hojas de destino [403].
- **Estrategia de tuning recomendada**: Sintonizar de forma logarítmica o lineal según el volumen del dataset de entrenamiento. En datasets industriales medianos (e.g. 50,000 muestras), usar valores de `[20, 50, 100, 200]` suele estabilizar enormemente las reglas lógicas resultantes.
- **Error común**: Mantener `min_samples_split=2` en datasets con alto nivel de ruido, permitiendo que el árbol se ramifique de forma sinuosa para aislar ruidos individuales en vez de generalizar tendencias grupales de la planta [102].
- **Aplicación práctica industrial**: *Siderúrgica / Procesos*. Predicción de fallas operacionales en ventiladores centrífugos de extracción de polvo. Configurar un `min_samples_split=50` asegura que las reglas de alerta lógicas solo se generen si cuentan con al menos 50 registros históricos de telemetría de soporte en cada nodo, filtrando eventos de fallas de medición puntuales del sensor de vibración [542].
- **Referencia**: Quinlan, J. R. (1986). *Induction of decision trees*. Machine Learning [271].
- **Prioridad**: ⚡ Importante

### 6.3 Mínimo de Muestras Requeridas en una Hoja (`min_samples_leaf`)
- **Modelo(s)**: DecisionTreeClassifier, DecisionTreeRegressor [64, 104, 105].
- **Nivel**: Intermedio
- **Qué controla**: Define la cantidad mínima admisible de observaciones que deben residir obligatoriamente dentro de cada nodo terminal u hoja final para que se permita realizar una partición candidata en las ramas superiores [60, 64]. Si un corte candidato genera una hoja izquierda o derecha que tiene menos de `min_samples_leaf` muestras, ese corte se rechaza inmediatamente por el algoritmo CART [64].
- **Valores típicos**: Enteros: `[1, 5, 10, 20, 50]` [190, 191]. Default en scikit-learn = `1` [112].
- **Qué pasa si es muy alto**: Suaviza en exceso las predicciones, reduciendo el árbol a muy pocas hojas. En regresión, el modelo promediará un gran grupo de muestras dispares dentro de la misma hoja, conduciendo a subajuste del modelo [65, 185].
- **Qué pasa si es muy bajo**: (e.g. `1`, el default). Permite la existencia de hojas "singulares" con una sola observación física de entrenamiento, capturando outliers ruidosos y provocando sobreajuste severo [102, 104].
- **Interacción con otros hiperparámetros**: Su sintonización anula de forma práctica el impacto negativo de configurar un `max_depth` ilimitado, ya que el árbol detendrá su crecimiento natural de forma segura mucho antes de llegar a profundidades altas al no poder cumplir la restricción de las hojas [102, 190, 405].
- **Estrategia de tuning recomendada**: Sintonización prioritaria mediante optimización bayesiana o validación cruzada. Para la mayoría de procesos de ingeniería industrial, valores de `[5, 10, 25, 50]` proveen un excelente balance de sesgo-varianza [191, 405].
- **Error común**: Mantener `min_samples_leaf=1` en problemas de regresión CART, generando predicciones escalonadas e inestables que reaccionan de forma drástica y absurda ante pequeños cambios en los valores de entrada de los sensores [103, 111].
- **Aplicación práctica industrial**: *Minería / Procesamiento de Mineral*. Control operacional automático del flujo de reactivos químicos en celdas de flotación. Parametrizar `min_samples_leaf=20` en el árbol de regresión suaviza los saltos de dosificación de reactivos, evitando oscilaciones mecánicas dañinas en las válvulas de dosificación de la planta [467, 506].
- **Referencia**: Breiman, L. et al. (1984). *Classification and Regression Trees* [271, 343].
- **Prioridad**: ⚡ Importante

### 6.4 Número de Características a Evaluar en cada Split (`max_features`)
- **Modelo(s)**: DecisionTreeClassifier, DecisionTreeRegressor [64, 104].
- **Nivel**: Intermedio
- **Qué controla**: Define la cantidad máxima de características o variables predictoras del dataset que el algoritmo CART tiene permitido evaluar de forma aleatoria en cada uno de los nodos individuales para buscar la mejor combinación de división y corte [64, 104].
- **Valores típicos**: `['sqrt', 'log2', None]` (donde `None` evalúa todas las variables predictoras del dataset, y `'sqrt'` evalúa el equivalente a la raíz cuadrada del total de variables) [104, 159, 373]. Default en scikit-learn = `None` [104, 112].
- **Qué pasa si es muy alto**: Se evalúan todas las características del dataset en cada nodo. El árbol se volverá determinista y buscará con codicia (algoritmo greedy) la variable que brinde la pureza máxima de forma global, aumentando el tiempo computacional si el volumen de variables es elevado [104, 153].
- **Qué pasa si es muy bajo**: Se evalúa una porción insignificante de variables en cada nodo. El crecimiento del árbol se acelerará drásticamente en tiempo, pero se corre el riesgo de subajustar el modelo al forzar decisiones basadas en características no informativas asignadas puramente al azar [311].
- **Interacción con otros hiperparámetros**: Crucial para el modelado de bosques aleatorios (`Random Forest`), donde inyectar aleatoriedad mediante un `max_features` bajo es el pilar para descorrelacionar los árboles individuales del ensamble [159, 228].
- **Estrategia de tuning recomendada**: Para un árbol CART individual, se recomienda mantener en `None` (evaluar todas las variables predictoras) para asegurar la máxima interpretabilidad analítica de la estructura de decisión [90, 104].
- **Error común**: Configurar valores extremadamente pequeños en datasets masivos donde unas pocas variables concentran todo el poder de predicción, provocando que el árbol tome decisiones absurdas basadas en variables irrelevantes en la mayoría de sus nodos.
- **Aplicación práctica industrial**: *Manufactura / Logística*. Diagnóstico de fallas en montacargas de almacén en base a 18 variables de sensores. Mantener `max_features=None` garantiza que el árbol de diagnóstico resultante siempre evalúe las variables más significativas físicamente (como presión hidráulica o temperatura del motor) en los niveles jerárquicos superiores, optimizando la resolución de fallas por parte del equipo de mecánicos de planta.
- **Referencia**: Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning* [293, 344].
- **Prioridad**: 💡 Opcional

### 6.5 Criterio de Medición de Pureza o Pérdida (`criterion`)
- **Modelo(s)**: DecisionTreeClassifier, DecisionTreeRegressor [62, 110, 112].
- **Nivel**: Intermedio
- **Qué controla**: Define la función de costo matemática que se utilizará para cuantificar la calidad y pureza de cada una de las divisiones candidatas en los nodos [60, 110, 154]. Para clasificación, las opciones son la impureza de Gini (`'gini'`) o la entropía de información (`'entropy'`) [60, 62, 154]. Para regresión, el estándar es el error cuadrático medio (`'squared_error'` o `'mse'`) o el error absoluto medio (`'absolute_error'` o `'mae'`) [65, 112].
- **Valores típicos**: Clasificación: `['gini', 'entropy', 'log_loss']` [62, 155, 373]; Regresión: `['squared_error', 'friedman_mse', 'absolute_error', 'poisson']` [112]. Default en scikit-learn = `'gini'` (clasificación) [155], `'squared_error'` (regresión).
- **Qué pasa si es muy alto**: N/A.
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: N/A.
- **Estrategia de tuning recomendada**: Por regla empírica general. Para clasificación, mantener `'gini'` por su mayor velocidad de cómputo, ya que no requiere calcular logaritmos de forma continua [102, 155]. Sintonizar a `'entropy'` o `'absolute_error'` si se sospecha de presencia de anomalías severas en el dataset de entrenamiento y se busca mayor robustez [112].
- **Error común**: Forzar el uso de `'absolute_error'` (`'mae'`) en regresores CART sobre datasets masivos sin justificación de outliers, ralentizando de forma catastrófica el tiempo de entrenamiento de la CPU debido a que requiere ordenar y rastrear constantemente las medianas en cada una de las divisiones candidates [112].
- **Aplicación práctica industrial**: *Banca / CRM*. Modelado de fuga de clientes (churn) de cuentas corrientes bancarias. Usar `'entropy'` permite cuantificar directamente la ganancia de información (Information Gain) en cada división lógica del árbol, facilitando al equipo de marketing entender el valor porcentual de reducción de incertidumbre que aporta saber si un cliente posee o no una tarjeta de crédito activa [67, 154].
- **Referencia**: Quinlan, J. R. (1993). *C4.5: Programs for Machine Learning* [271].
- **Prioridad**: 💡 Opcional

## 7. Random Forest

Random Forest es un algoritmo de ensamble de aprendizaje cooperativo que entrena múltiples árboles de decisión independientes en paralelo sobre diferentes subconjuntos de datos (bagging) e introduce aleatoriedad en la selección de características para descorrelacionar los estimadores [88, 228, 310].

### 7.1 Número de Árboles en el Ensamble (`n_estimators`)
- **Modelo(s)**: RandomForestClassifier, RandomForestRegressor [105, 162].
- **Nivel**: Básico
- **Qué controla**: Define la cantidad exacta de árboles de decisión individuales e independientes que se construirán para formar el bosque cooperativo [162, 311]. El resultado final del ensamble será el promedio aritmético directo de las predicciones en regresión [228], o la votación de la mayoría de etiquetas en clasificación [228, 311].
- **Valores típicos**: `[50, 100, 200, 500, 1000]` [162, 229, 311]. Default en scikit-learn = `100`.
- **Qué pasa si es muy alto**: Provoca un desperdicio masivo de recursos de cómputo de CPU y memoria [311]. El modelo aumentará su tiempo de procesamiento de forma lineal al requerir construir y almacenar cientos de árboles adicionales, pero la precisión del ensamble se estancará en una meseta (la varianza del modelo no disminuye indefinidamente una vez que el bosque converge) [311].
- **Qué pasa si es muy bajo**: Deteriora severamente el rendimiento y la estabilidad de las predicciones del bosque [311]. Al contar con muy pocos árboles, no se explota el beneficio de la agregación bootstrap (bagging) para neutralizar la varianza del modelo, resultando en predicciones inestables y sensibles al subconjunto de entrenamiento [311].
- **Interacción con otros hiperparámetros**: Su valor se puede sintonizar junto con `n_jobs` (cantidad de procesadores de CPU asignados en paralelo) [126, 156]. Aumentar `n_estimators` no incrementa el riesgo de sobreajuste de forma matemática debido al principio del promedio asintótico del bagging [228, 309].
- **Estrategia de tuning recomendada**: Configurar un valor moderadamente alto (e.g., `200` o `300`) y evaluar la métrica de validación cruzada. Si el hardware disponible de la CPU lo permite, mantener un número elevado sin necesidad de hacer una sintonía fina exhaustiva en este hiperparámetro específico [311].
- **Error común**: Realizar búsquedas de cuadrícula costosas tratando de encontrar el "mejor" `n_estimators` exacto (e.g. comparar `100` vs `105`), desperdiciando ciclos de procesamiento en un hiperparámetro que solo requiere ser "suficientemente grande" para converger [311].
- **Aplicación práctica industrial**: *Minería / Procesos de Molienda*. Estimación del rendimiento metalúrgico de mineral de cobre triturado en base a lecturas de vibración mecánica y flujo de agua. Configurar `n_estimators=300` estabiliza por completo las predicciones contra picos instantáneos de ruido mecánico del molino autógeno de planta [467, 506].
- **Referencia**: Breiman, L. (2001). *Random Forests*. Machine Learning [88, 310].
- **Prioridad**: 🔥 Esencial

### 7.2 Selección Aleatoria de Características para Divisiones (`max_features`)
- **Modelo(s)**: RandomForestClassifier, RandomForestRegressor [105, 162].
- **Nivel**: Básico
- **Qué controla**: Define la cantidad de variables predictoras que se seleccionarán completamente de forma aleatoria en cada nodo individual de cada árbol del bosque como candidatas a evaluar para realizar el mejor corte [159]. Es el hiperparámetro crucial para descorrelacionar los árboles entre sí [159, 228].
- **Valores típicos**: `['sqrt', 'log2', None]` o fracciones numéricas flotantes (e.g. `0.2`, `0.5`) [104, 159]. Default en scikit-learn = `'sqrt'` (para clasificación) [159], `1.0` o `None` (para regresión).
- **Qué pasa si es muy alto**: (e.g. `1.0` o `None`). Los árboles de decisión del bosque se volverán muy similares y altamente correlacionados entre sí al evaluar siempre las mismas variables, anulando gran parte del beneficio estadístico de la reducción de varianza del ensamble.
- **Qué pasa si es muy bajo**: Se evalúan muy pocas variables de forma aleatoria en cada nodo. El modelo ganará velocidad, pero sus árboles individuales perderán drásticamente capacidad predictiva, deteriorando el rendimiento predictivo del bosque por subajuste localizado de los estimadores individuales [311].
- **Interacción con otros hiperparámetros**: N/A.
- **Estrategia de tuning recomendada**: Por regla empírica general. Para clasificación, mantener el default de `'sqrt'` (que equivale a \(\sqrt{p}\)) [159, 346]. Para regresión, el óptimo suele estar cerca de `0.3` o `1/3` de las variables disponibles [346].
- **Error común**: No sintonizar `max_features` en problemas de regresión industrial de alta dimensión, permitiendo que scikit-learn utilice todas las variables por defecto (`max_features=None`), reduciendo el bosque a un simple bagging correlacionado ineficiente.
- **Aplicación práctica industrial**: *Banca / Riesgos*. Detección de lavado de dinero en base a patrones de comportamiento transaccional del cliente. Sintonizar un `max_features='sqrt'` asegura que variables transaccionales ruidosas pero comunes no enmascaren a variables de alerta silenciosas de comportamiento inusual, obligando a los árboles a explorar variables predictoras alternativas [470, 509].
- **Referencia**: Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning* [293, 344].
- **Prioridad**: 🔥 Esencial

### 7.3 Uso de Bootstrap para Muestras (`bootstrap`)
- **Modelo(s)**: RandomForestClassifier, RandomForestRegressor [105].
- **Nivel**: Intermedio
- **Qué controla**: Define si los árboles de decisión individuales se entrenarán sobre muestras de entrenamiento tomadas de forma aleatoria con reemplazo de los datos originales de entrenamiento (muestreo bootstrap de tamaño \(n\)) [105, 311], o si por el contrario cada uno de los árboles se ajustará sobre el conjunto completo de datos de entrenamiento al 100% [105].
- **Valores típicos**: Booleano: `True` o `False` [105]. Default en scikit-learn = `True`.
- **Qué pasa si es muy alto**: N/A.
- **Qué pasa si es muy bajo**: Si se desactiva (`bootstrap=False`), todos los árboles de decisión se entrenarán sobre el conjunto exacto de datos de entrenamiento completo al 100%. Esto elimina el beneficio de la variabilidad del bagging, provocando un mayor sobreajuste y haciendo inútil el cálculo interno del error fuera de bolsa (Out-of-Bag error) [105, 310].
- **Interacción con otros hiperparámetros**: Si `bootstrap=True`, se habilita el cálculo del estimador `oob_score`, permitiendo evaluar el error de generalización en muestras "fuera de bolsa" de forma gratuita sin necesidad de realizar validación cruzada explícita [114, 310].
- **Estrategia de tuning recomendada**: Mantener siempre en `True` en la práctica industrial para garantizar la correcta reducción de varianza del bosque [105, 311].
- **Error común**: Desactivar `bootstrap` esperando aumentar la precisión en entrenamiento, perdiendo por completo la propiedad fundamental de descorrelación del ensamble.
- **Aplicación práctica industrial**: *Banca / Churn*. Clasificación de la propensión a la fuga de clientes. Mantener `bootstrap=True` habilita el uso de las métricas internas de OOB (Out-of-Bag) para estimar el error de generalización del modelo sin desperdiciar datos adicionales de validación en fases preliminares del proyecto [411, 484].
- **Referencia**: Breiman, L. (1996). *Bagging predictors*. Machine Learning [228].
- **Prioridad**: ⚡ Importante

### 7.4 Muestras Mínimas por Nodo Hoja (`min_samples_leaf`)
- **Modelo(s)**: RandomForestClassifier, RandomForestRegressor [104, 105, 112].
- **Nivel**: Intermedio
- **Qué controla**: Al igual que en los árboles CART de base, restringe la cantidad mínima admitida de observaciones dentro de cada una de las hojas finales de todos los árboles del bosque [64, 403]. Controla indirectamente el tamaño final y la profundidad de crecimiento de los árboles individuales del bosque [217, 403].
- **Valores típicos**: Enteros: `[1, 5, 10, 20, 50]` [190, 191]. Default en scikit-learn = `1` [112].
- **Qué pasa si es muy alto**: Suaviza excesivamente las predicciones del bosque. Conduce a un subajuste severo al forzar a que los árboles estimadores individuales promedien demasiadas muestras en sus decisiones, perdiendo la finura predictiva de las variables del proceso.
- **Qué pasa si es muy bajo**: Permite que los árboles individuales crezcan hasta su máxima profundidad lógica posible con hojas puras, aumentando la varianza del modelo [102]. Sin embargo, la varianza de Random Forest se mitiga internamente de forma natural gracias al principio del promedio del bagging [228, 310].
- **Interacción con otros hiperparámetros**: Interactúa de forma directa con `max_depth` [190]. Restringir `min_samples_leaf` a un valor mayor a `1` estabiliza el modelo de regresión y reduce drásticamente el tamaño en disco del archivo serializado final del modelo (pkl / joblib).
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en un rango acotado: `[1, 3, 5, 10]` [191]. Para problemas industriales de regresión con alto ruido instrumental en planta, valores de `3` a `10` son recomendados.
- **Error común**: Mantener `min_samples_leaf=1` en problemas industriales con millones de registros de sensores ruidosos, generando archivos serializados del modelo inmensos (e.g. gigabytes) que ralentizan de forma prohibitiva la memoria del servidor de producción en el despliegue del FastAPI de planta [541].
- **Aplicación práctica industrial**: *Cemento / Emisión de Polvo*. Predicción del nivel de emisión de material particulado por la chimenea en miligramos en base a la velocidad de giro de los extractores. Configurar un `min_samples_leaf=5` previene que lecturas de ruido puntual de los sensores generen picos absurdos e inexplicables en las predicciones en vivo [542].
- **Referencia**: Documentación oficial de Scikit-Learn (Ensemble Methods) [362].
- **Prioridad**: ⚡ Importante

## 8. Gradient Boosting (GradientBoostingClassifier / Regressor)

GBRT es un algoritmo de ensamble aditivo secuencial que optimiza funciones de pérdida diferenciables genéricas, construyendo de forma iterativa árboles de regresión simples (estimadores débiles) que se ajustan al gradiente negativo de la pérdida (residuos del paso anterior) [113, 229, 346].

### 8.1 Tasa de Aprendizaje (`learning_rate` o `shrinkage`)
- **Modelo(s)**: GradientBoostingClassifier, GradientBoostingRegressor [113, 229, 355].
- **Nivel**: Básico
- **Qué controla**: Multiplica el valor de predicción aportado por cada nuevo árbol que se añade al ensamble secuencial: \(F_m(x) = F_{m-1}(x) + \nu \gamma_m h_m(x)\) [113, 409]. Actúa como un factor de contracción de peso (shrinkage) para desacelerar la velocidad de ajuste del modelo, asegurando que cada árbol individual aporte únicamente un pequeño paso correctivo a la predicción acumulada [113, 409].
- **Valores típicos**: `[0.001, 0.01, 0.05, 0.1, 0.2]` [113, 355]. Default en scikit-learn = `0.1`.
- **Qué pasa si es muy alto**: (e.g. `learning_rate >= 0.5`). El modelo converge demasiado rápido de forma impaciente sobre las muestras de entrenamiento [409]. Esto provoca un sobreajuste inmediato, donde el algoritmo memoriza los patrones específicos de entrenamiento y pierde la capacidad de generalización fina [409].
- **Qué pasa si es muy bajo**: (e.g. `learning_rate <= 0.001`). El aprendizaje secuencial se vuelve excesivamente lento y conservador [409]. Se requerirán miles de árboles adicionales (`n_estimators`) para lograr ajustar los datos de forma correcta, prolongando de forma insostenible el tiempo computacional de entrenamiento y arriesgando subajuste si no se compensa [409].
- **Interacción con otros hiperparámetros**: Estrechamente acoplado con `n_estimators` (relación inversamente proporcional) [409]. Si disminuyes la tasa de aprendizaje, debes incrementar de forma proporcional la cantidad de árboles para asegurar la convergencia completa del ensamble [409].
- **Estrategia de tuning recomendada**: Fijar una tasa de aprendizaje moderadamente baja (e.g. `0.05` o `0.1`) durante la exploración inicial [113, 409], y luego afinar el número de árboles óptimo mediante validación cruzada con parada temprana (`early_stopping`) para evitar el sobreajuste [309, 412].
- **Error común**: Disminuir drásticamente la tasa de aprendizaje a un valor infinitesimal (como `1e-5`) tratando de maximizar la precisión, pero olvidando incrementar el número de árboles predictivos, dejando al ensamble a medio entrenar (subajuste extremo) [409].
- **Aplicación práctica industrial**: *Banca / Scoring*. Pronóstico semanal de la demanda de efectivo en cajeros automáticos (ATMs) del BCP en base a calendarios festivos y ubicación de agencias. Ajustar `learning_rate=0.03` con un número alto de árboles secuenciales asegura que el modelo capture sutilmente las tendencias de retiro sin sobrereaccionar ante feriados imprevistos de un año específico.
- **Referencia**: Friedman, J. H. (2001). *Greedy function approximation: A gradient boosting machine*. Annals of Statistics [481].
- **Prioridad**: 🔥 Esencial

### 8.2 Número de Árboles Secuenciales (`n_estimators`)
- **Modelo(s)**: GradientBoostingClassifier, GradientBoostingRegressor [113, 229, 309].
- **Nivel**: Básico
- **Qué controla**: Define la cantidad total de árboles secuenciales débiles que se construirán paso a paso en el proceso iterativo del ensamble para corregir los residuos acumulados de los pasos previos [229, 309].
- **Valores típicos**: `[100, 200, 500, 1000]` [229, 309, 355]. Default en scikit-learn = `100`.
- **Qué pasa si es muy alto**: Conduce a un sobreajuste severo del ensamble secuencial [309, 409]. A diferencia de Random Forest, donde añadir árboles adicionales nunca sobreajusta el modelo, en Gradient Boosting un número excesivo de árboles secuenciales inevitablemente intentará ajustar y memorizar los residuos ruidosos y outliers individuales de entrenamiento [309, 409].
- **Qué pasa si es muy bajo**: El modelo sufrirá de subajuste severo, dejando al ensamble de árboles débiles a medio camino de corregir los errores iniciales de predicción de la planta [409].
- **Interacción con otros hiperparámetros**: Enlazado con `learning_rate` [409]. Se recomienda usarlo junto con el parámetro `validation_fraction` y un disparador de parada temprana (`n_iter_no_change` o `early_stopping_rounds`) para detener de forma segura la construcción de nuevos árboles una vez que el error de validación empiece a incrementarse [192, 309].
- **Estrategia de tuning recomendada**: No tunear de forma manual. Configurar un valor alto de estimadores (e.g. `1000`) y habilitar la parada temprana utilizando validación cruzada, permitiendo que el algoritmo decida de forma automática el corte óptimo basado en datos [192].
- **Error común**: Intentar sintonizar `n_estimators` como un número constante fijo mediante un GridSearch estático sin parada temprana, desperdiciando horas de cómputo sobreajustando el modelo [192, 309].
- **Aplicación práctica industrial**: *Siderúrgica / Energía*. Pronóstico de consumo eléctrico acumulado por hora en hornos de arco eléctrico de acería. Sintonizar el número óptimo de árboles mediante parada temprana previene que el modelo asuma picos de consumo causados por mantenimiento correctivo inusual como comportamientos cíclicos normales [481, 520].
- **Referencia**: Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning* [293, 344].
- **Prioridad**: 🔥 Esencial

### 8.3 Fracción de Muestras para cada Árbol (`subsample`)
- **Modelo(s)**: GradientBoostingClassifier, GradientBoostingRegressor [114, 251].
- **Nivel**: Intermedio
- **Qué controla**: Define la fracción de muestras de entrenamiento del total que se seleccionarán al azar y sin reemplazo para entrenar cada uno de los árboles individuales secuenciales del ensamble (Gradient Boosting Estocástico) [251, 309].
- **Valores típicos**: Rango cerrado: `[0.5, 0.7, 0.8, 1.0]` [251, 309]. Default en scikit-learn = `1.0` (evaluar todas las muestras).
- **Qué pasa si es muy alto**: (e.g. `1.0`, el default). El modelo se comportará de forma puramente determinista al procesar el gradiente sobre el conjunto completo de datos, perdiendo la oportunidad de inyectar diversidad y reducir la varianza general mediante aleatoriedad estocástica [114].
- **Qué pasa si es muy bajo**: (e.g. `subsample <= 0.5`). Los árboles individuales secuenciales perderán de forma crítica su capacidad de ajuste debido a la escasez de datos informativos disponibles para evaluar, aumentando el sesgo del modelo por subajuste localizado de los estimadores secuenciales.
- **Interacción con otros hiperparámetros**: Sintonizar un `subsample` menor a `1.0` habilita el Gradient Boosting Estocástico, reduciendo drásticamente el tiempo de cómputo general del entrenamiento al procesar menos muestras en cada paso del gradiente [309].
- **Estrategia de tuning recomendada**: Configurar valores de `0.8` o `0.9` por defecto para problemas operacionales ruidosos. Rara vez se requiere realizar un GridSearch exhaustivo sobre este hiperparámetro específico [309].
- **Error común**: Ajustar `subsample` por debajo de `0.3` en datasets industriales pequeños creyendo que evitará el sobreajuste de forma milagrosa, ignorando que solo está destruyendo la poca señal informativa que posee su conjunto de entrenamiento.
- **Aplicación práctica industrial**: *Banca / Riesgos (BCP)*. Clasificación del perfil de riesgo de transacciones de comercio electrónico en banca digital. Usar `subsample=0.8` inyecta robustez en el Gradient Boosting Estocástico, filtrando picos transaccionales inusuales de días festivos específicos sin alterar la precisión del motor en vivo.
- **Referencia**: Friedman, J. H. (2002). *Stochastic gradient boosting*. Computational Statistics & Data Analysis [309].
- **Prioridad**: ⚡ Importante

### 8.4 Profundidad de cada Árbol Débil (`max_depth`)
- **Modelo(s)**: GradientBoostingClassifier, GradientBoostingRegressor [113, 217, 309].
- **Nivel**: Intermedio
- **Qué controla**: Define el número máximo de niveles o profundidad que se le permite crecer a cada uno de los estimadores secuenciales individuales (árboles débiles) del ensamble [217, 309]. Controla directamente el grado de interacción de variables capturado por cada paso de gradiente [44].
- **Valores típicos**: Rango acotado muy bajo: `[2, 3, 4, 5, 6, 8]` [44, 309]. Default en scikit-learn = `3`.
- **Qué pasa si es muy alto**: (e.g. `max_depth >= 10`). Transforma los estimadores individuales del gradiente en modelos complejos individuales que sobreajustarán de forma instantánea al ruido local del dataset, arruinando por completo el principio de boosting (un ensamble de aprendices débiles coordinados secuencialmente) [310, 409].
- **Qué pasa si es muy bajo**: (e.g. `max_depth = 1`, tocones de decisión o stumps). El modelo se vuelve lento de entrenar y puede requerir miles de estimadores secuenciales, pero tiene alta robustez ante el ruido operacional [44].
- **Interacción con otros hiperparámetros**: Su sintonización define el número óptimo de árboles secuenciales a construir [309].
- **Estrategia de tuning recomendada**: Usar de forma estándar `max_depth = 3` o `4` para tabular ruidoso [44, 309]. Solo subir a `6` u `8` si existen interacciones de múltiples variables complejas en sistemas físicos [44].
- **Error común**: Permitir que los árboles del Gradient Boosting crezcan de forma ilimitada como en Random Forest, destruyendo el poder predictivo del ensamble en producción [310, 409].
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Predicción del desgaste por vibración de cojinetes en rodillos de laminación. Un `max_depth=4` permite capturar de forma exacta interacciones de segundo orden (vibración x temperatura de aceite x rpm), sin sobreajustar a lecturas anómalas aisladas de fallas de medición eléctrica de los sensores de planta [464, 481].
- **Referencia**: Elith, J., Leathwick, J. R., & Hastie, T. (2008). *A working guide to boosted regression trees*. Journal of Animal Ecology [293, 309].
- **Prioridad**: ⚡ Importante

## 9. XGBoost

XGBoost es una implementación altamente optimizada de Gradient Boosting que destaca por el uso de regularización formal en la función objetivo, cómputo paralelo de splits y soporte nativo de gradientes de segundo orden mediante la matriz Hessiana [114, 162, 482].

### 9.1 Tasa de Aprendizaje / Eta (`learning_rate` o `eta`)
- **Modelo(s)**: XGBClassifier, XGBRegressor [113, 114].
- **Nivel**: Básico
- **Qué controla**: Cumple la misma función de contracción de peso (shrinkage) que en el algoritmo de Gradient Boosting clásico de scikit-learn, escalando los coeficientes de los nuevos árboles añadidos al ensamble secuencial [113, 114].
- **Valores típicos**: Rango logarítmico lineal fino: `[0.01, 0.03, 0.05, 0.1, 0.2, 0.3]` [113, 249]. Default en XGBoost = `0.3`.
- **Qué pasa si es muy alto**: (e.g. `0.3` o superior). Aumenta dramáticamente la impaciencia de entrenamiento del algoritmo sobre el gradiente [409]. XGBoost sobreajustará rápidamente de forma agresiva en las fases iniciales, perdiendo precisión de generalización en datos de validación cruzada [409].
- **Qué pasa si es muy bajo**: (e.g. `0.01` o inferior). Exige que el ensamble requiera una enorme cantidad de iteraciones secuenciales de reentrenamiento, prolongando el tiempo computacional de la CPU [409].
- **Interacción con otros hiperparámetros**: Enlazado inversamente al número de rondas secuenciales de ajuste (`num_boost_round` o `n_estimators`) y a la sintonización fina de regularización de hojas (`reg_lambda`, `reg_alpha`) [114, 409].
- **Estrategia de tuning recomendada**: Sintonizar de forma secuencial junto con parada temprana [192]. Un valor de `0.05` es un estándar industrial ideal para un equilibrio óptimo de precisión y velocidad de procesamiento de datos en el reentrenamiento semanal de planta [409].
- **Error común**: Ajustar tasas de aprendizaje elevadas confiando puramente en la capacidad de regularización nativa de XGBoost para evitar el sobreajuste del modelo [309, 409].
- **Aplicación práctica industrial**: *Cemento (Pacasmayo)*. Clasificación en tiempo real de anomalías de vibración en molinos de bolas horizontales gigantescos en base a 24 mediciones continuas de sensores piezoeléctricos. Configurar un `learning_rate=0.05` permite que el clasificador en vivo aprenda tendencias estables sin disparar alertas de falsas alarmas operacionales ante ruidos puntuales de arranque mecánico de los molinos de la planta [470, 509].
- **Referencia**: Chen, T., & Guestrin, C. (2016). *XGBoost: A Scalable Tree Boosting System*. ACM SIGKDD [482].
- **Prioridad**: 🔥 Esencial

### 9.2 Peso Mínimo en Nodo Hijo (`min_child_weight`)
- **Modelo(s)**: XGBClassifier, XGBRegressor [249, 250].
- **Nivel**: Intermedio
- **Qué controla**: Especifica el requerimiento de la suma mínima ponderada de las Hessianas (segundas derivadas locales de la pérdida) que deben poseer de forma obligatoria las muestras que residan en un nodo hijo para que el algoritmo permita realizar una nueva división recursiva en las ramas del árbol [249, 482]. En regresión con pérdida cuadrática (MSE), equivale matemáticamente a la cantidad mínima de observaciones de entrenamiento que deben habitar en cada subnodo [482].
- **Valores típicos**: Enteros: `[1, 3, 5, 10, 20, 50]` [249, 250]. Default en XGBoost = `1`.
- **Qué pasa si es muy alto**: Regulariza severamente el crecimiento de las ramas de los árboles. El algoritmo detendrá la ramificación secuencial de forma muy conservadora al no poder cumplir la restricción del peso hessiano en el subnodo, evitando el sobreajuste pero arriesgando un subajuste severo del ensamble [249, 482].
- **Qué pasa si es muy bajo**: (e.g. `1`, el default). Permite que XGBoost continúe ramificando los árboles de forma sinuosa para crear nodos que contengan muy pocas observaciones o incluso una sola muestra de entrenamiento ruidosa, lo que conduce a un sobreajuste masivo y localizada en las hojas.
- **Interacción con otros hiperparámetros**: Su sintonía se combina con la profundidad máxima de los árboles secuenciales (`max_depth`) [190].
- **Estrategia de tuning recomendada**: Sintonización prioritaria en problemas tabulares desbalanceados utilizando optimización bayesiana con validación cruzada [192]. En presencia de clases raras del negocio, configuraciones de `5` a `15` previenen de forma sumamente robusta que el modelo asuma ruido como patrones reales [249].
- **Error común**: Mantener `min_child_weight=1` sobre conjuntos de datos con clases altamente desbalanceadas, permitiendo que XGBoost cree ramas específicas adaptadas únicamente a un par de outliers aislados ruidosos [466].
- **Aplicación práctica industrial**: *Banca / Riesgos (BCP)*. Detección de fraude transaccional financiero digital en cajeros automáticos del BCP. Al presentarse una tasa de fraude ínfima (menos del 0.1% de los datos), configurar un `min_child_weight=10` asegura que el clasificador secuencial de XGBoost solo asuma patrones si cuentan con un peso robusto de soporte en la Hessiana local, eliminando de raíz las falsas alarmas operativas para el cliente [466].
- **Referencia**: Documentación oficial de XGBoost (Parameters) [162, 482].
- **Prioridad**: 🔥 Esencial

### 9.3 Fracción de Características por Árbol (`colsample_bytree`)
- **Modelo(s)**: XGBClassifier, XGBRegressor [114, 249].
- **Nivel**: Intermedio
- **Qué controla**: Define la fracción del total de variables predictoras que se seleccionarán completamente al azar para entrenar cada uno de los árboles secuenciales individuales que se añaden al ensamble de XGBoost [114, 249].
- **Valores típicos**: Rango continuo: `[0.5, 0.6, 0.7, 0.8, 0.9, 1.0]` [114, 249]. Default en XGBoost = `1.0`.
- **Qué pasa si es muy alto**: (e.g. `1.0`, el default). Se evalúan exactamente todas las variables predictoras del dataset en cada árbol secuencial construido. El algoritmo pierde variabilidad de descorrelacionamiento y ralentiza su tiempo de cómputo computacional en datasets con alta dimensionalidad [114].
- **Qué pasa si es muy bajo**: (e.g. `colsample_bytree <= 0.4`). Reduce el número de características a evaluar de forma extrema en cada nodo, acelerando el procesamiento computacional de la CPU pero arriesgando un subajuste si se excluyen las variables físicas predictoras dominantes.
- **Interacción con otros hiperparámetros**: Interactúa en conjunto con `colsample_bylevel` (fracción por nivel de árbol) y `colsample_bynode` (fracción por división de nodo), permitiendo una sintonía fina de aleatoriedad espacial en tres capas jerárquicas [114, 249].
- **Estrategia de tuning recomendada**: Configurar de forma estándar un valor de `0.7` u `0.8` para inyectar diversidad espacial y agilizar enormemente el tiempo de entrenamiento sobre miles de columnas del dataset de planta [114].
- **Error común**: Mantener `colsample_bytree=1.0` en datasets tabulares gigantescos con cientos de variables redundantes, lo que dispara innecesariamente el consumo de hardware de la CPU sin aportar mejoras reales en la precisión del clasificador en vivo.
- **Aplicación práctica industrial**: *Minería / Procesamiento*. Pronóstico del consumo energético del sistema de ventilación forzada en base a telemetría ambiental (vibración de aspas, temperatura externa, humedad, velocidad de aire). Usar `colsample_bytree=0.8` acelera un 40% el tiempo de cómputo de reentrenamiento del modelo diario sin alterar la precisión predictiva.
- **Referencia**: Chen, T., & Guestrin, C. (2016). *XGBoost: A Scalable Tree Boosting System* [482].
- **Prioridad**: ⚡ Importante

### 9.4 Regularización L2 (`reg_lambda`)
- **Modelo(s)**: XGBClassifier, XGBRegressor [114, 249].
- **Nivel**: Avanzado
- **Qué controla**: Coeficiente multiplicador del término de penalización de la norma L2 aplicado directamente sobre los pesos de las hojas de los árboles secuenciales dentro del funcional formal de regularización de la función objetivo de XGBoost [114, 482]. Actúa para contraer y suavizar las predicciones numéricas individuales de cada hoja [114, 482].
- **Valores típicos**: Rango logarítmico lineal: `[0.0, 0.1, 1.0, 5.0, 10.0, 50.0, 100.0]` [114, 249]. Default en XGBoost = `1.0`.
- **Qué pasa si es muy alto**: Obliga a que los pesos calculados de las hojas finales tiendan fuertemente a igualarse hacia cero, regularizando rígidamente el ensamble y provocando subajuste del modelo.
- **Qué pasa si es muy bajo**: Permite que las hojas de los árboles adquieran pesos con magnitudes extremas e inestables para aislar ruidos locales de entrenamiento del dataset, conduciendo a sobreajuste.
- **Interacción con otros hiperparámetros**: Interactúa en conjunto con la tasa de aprendizaje (`learning_rate`) y la regularización L1 (`reg_alpha`) [114, 409].
- **Estrategia de tuning recomendada**: Sintonizar de forma logarítmica si se observa que el modelo final muestra picos o inestabilidades numéricas drásticas en producción.
- **Error común**: Dejar el parámetro de regularización L2 en cero (`reg_lambda=0.0`) esperando ganar precisión de forma milagrosa en problemas tabulares ruidosos, perdiendo el beneficio de la regularización objetivo estructural de XGBoost.
- **Aplicación práctica industrial**: *Banca / Scoring (BCP)*. Modelo predictivo de asignación de tasas de interés preferenciales personalizadas para clientes de préstamos hipotecarios. Sintonizar un `reg_lambda=10.0` previene que clientes individuales con historiales de pago atípicos ruidosos generen picos o valles absurdos en el cálculo de tasas automatizado.
- **Referencia**: Documentación oficial de XGBoost (Regularization Parameters) [162, 482].
- **Prioridad**: ⚡ Importante

### 9.5 Regularización L1 (`reg_alpha`)
- **Modelo(s)**: XGBClassifier, XGBRegressor [114, 249].
- **Nivel**: Avanzado
- **Qué controla**: Coeficiente multiplicador del término de penalización de la norma L1 aplicado directamente sobre los pesos de las hojas secuenciales dentro del funcional formal de regularización de la función objetivo de XGBoost [114, 482]. Induce a que los pesos no informativos de las hojas terminales se contraigan a exactamente cero de forma neta [114, 482].
- **Valores típicos**: Rango logarítmico lineal: `[0.0, 0.1, 1.0, 5.0, 10.0, 50.0]` [114, 249]. Default en XGBoost = `0.0`.
- **Qué pasa si es muy alto**: Provoca una reducción severa de la complejidad de los pesos de las hojas finales de los árboles, apagando la expresividad no lineal y conduciendo a subajuste del modelo.
- **Qué pasa si es muy bajo**: No realiza contracción neta de los pesos de las hojas terminales individuales de forma estable, permitiendo al modelo ajustar en exceso el ruido local del dataset.
- **Interacción con otros hiperparámetros**: Su sintonía se combina con la regularización L2 (`reg_lambda`) [114, 249].
- **Estrategia de tuning recomendada**: Sintonizar como hiperparámetro de última capa mediante optimización bayesiana en datasets con alta variabilidad.
- **Error común**: Confundir `reg_alpha` con `reg_lambda` y no comprender que la penalización L1 induce de forma neta a que muchos pesos de hojas terminales sean exactamente cero (sparsity estructural), facilitando el descarte nativo de ruido de planta.
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Predicción en tiempo real del desgaste superficial del acero laminado en frío en base a telemetría de vibración de la prensa hidráulica. Un `reg_alpha=5.0` estabiliza de forma robusta las alertas lógicas predictivas semanales de planta.
- **Referencia**: Chen, T., & Guestrin, C. (2016). *XGBoost: A Scalable Tree Boosting System* [482].
- **Prioridad**: 💡 Opcional

## 10. LightGBM

LightGBM es una implementación de Gradient Boosting altamente optimizada que destaca por el uso de crecimiento de árbol de forma leaf-wise (basado en hojas de mayor ganancia) en vez de level-wise, acelerando drásticamente el cómputo y optimizando el uso de la memoria RAM con datasets masivos [114, 482].

### 10.1 Número Máximo de Hojas por Árbol (`num_leaves`)
- **Modelo(s)**: LGBMClassifier, LGBMRegressor [249, 250].
- **Nivel**: Básico
- **Qué controla**: Define la cantidad máxima admisible de nodos terminales u hojas que se le permite poseer a cada uno de los árboles secuenciales individuales entrenados de forma paralela [249, 250]. Al utilizar LightGBM un crecimiento leaf-wise, este es el hiperparámetro fundamental para controlar la complejidad estructural y evitar el sobreajuste del modelo [249, 482].
- **Valores típicos**: `[15, 31, 63, 127, 255]` [249, 250]. Default en LightGBM = `31`.
- **Qué pasa si es muy alto**: (e.g. `num_leaves >= 127` en datasets pequeños). El árbol crecerá de forma sumamente sinuosa e indisciplinada, adaptándose milimétricamente a cada observación ruidosa del set de entrenamiento y provocando sobreajuste severo [102, 249].
- **Qué pasa si es muy bajo**: (e.g. `num_leaves <= 7`). Reduce la capacidad y la expresividad no lineal de los árboles secuenciales de forma crítica, impidiendo capturar interacciones complejas de variables predictoras continuas del sistema físico y conduciendo a subajuste [308].
- **Interacción con otros hiperparámetros**: Limitado y enlazado matemáticamente con la profundidad máxima de los árboles (`max_depth`) [190]. Por definición, para que un árbol tenga `num_leaves` hojas terminales, se requiere que la profundidad máxima permita un crecimiento de al menos \(2^{\text{max_depth}} \ge \text{num_leaves}\) [190].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en conjunto con `max_depth` [190]. Para la gran mayoría de problemas tabulares reales de ingeniería industrial de la planta, valores de `31` a `63` proveen un balance de sesgo-varianza inmejorable.
- **Error común**: Incrementar `num_leaves` a valores muy elevados (e.g. `255`) sin restringir la cantidad mínima de datos en las hojas, lo que disparará un sobreajuste localizado catastrófico sobre el ruido del dataset [249].
- **Aplicación práctica industrial**: *Banca / CRM (BCP)*. Clasificación de transacciones bancarias sospechosas de fraude electrónico digital. Un valor de `num_leaves=63` optimiza la sensibilidad no lineal del clasificador secuencial de LightGBM, capturando combinaciones atípicas complejas de hora, geolocalización y montos transaccionales [175, 470].
- **Referencia**: Ke, G. et al. (2017). *LightGBM: A Highly Efficient Gradient Boosting Decision Tree*. Advances in Neural Information Processing Systems [482].
- **Prioridad**: 🔥 Esencial

### 10.2 Mínima Cantidad de Datos en una Hoja (`min_data_in_leaf` o `min_child_samples`)
- **Modelo(s)**: LGBMClassifier, LGBMRegressor [249, 250].
- **Nivel**: Básico
- **Qué controla**: Especifica el número mínimo admisible de observaciones de entrenamiento que deben residir de forma obligatoria dentro de cada uno de los subnodos u hojas finales de todos los árboles del bosque secuencial de LightGBM [249, 250].
- **Valores típicos**: Enteros: `[10, 20, 50, 100, 200, 500]` [249, 250]. Default en LightGBM = `20`.
- **Qué pasa si es muy alto**: Regulariza excesivamente el crecimiento de los árboles de forma drástica. Obliga a que cada una de las hojas contenga demasiadas observaciones físicas promedio, impidiendo que el modelo distinga subpatrones lógicos sutiles del proceso productivo y conduciendo a subajuste.
- **Qué pasa si es muy bajo**: (e.g. `min_data_in_leaf <= 5`). Permite que el crecimiento leaf-wise de LightGBM cree hojas marginales con muy pocas observaciones ruidosas aisladas, capturando outliers del set de entrenamiento y provocando sobreajuste severo [102, 249].
- **Interacción con otros hiperparámetros**: Su sintonía de regularización es complementaria a la sintonía del número de hojas del árbol (`num_leaves`) [249].
- **Estrategia de tuning recomendada**: Sintonización prioritaria mediante validación cruzada. En datasets tabulares con cientos de miles de filas, valores de `min_data_in_leaf=100` o `200` previenen de forma sumamente robusta que el modelo asuma ruido instrumental como patrones reales [249].
- **Error común**: Mantener el default de `min_data_in_leaf=20` en datasets tabulares industriales de gran tamaño (e.g., millones de filas de telemetría de molino minero), permitiendo sobreajuste localized invisible para el científico de datos [249, 540].
- **Aplicación práctica industrial**: *Minería / Procesamiento de Mineral*. Predicción mensual del consumo neto de agua industrial del chancador primario en base al tipo de roca y temperatura ambiental. Configurar un `min_data_in_leaf=100` inyecta robustez en el Gradient Boosting secuencial, filtrando comportamientos de mantenimiento puntuales semanales [540, 542].
- **Referencia**: Documentación oficial de LightGBM (Parameters) [249, 482].
- **Prioridad**: 🔥 Esencial

### 10.3 Fracción de Características por División (`feature_fraction` o `colsample_bytree`)
- **Modelo(s)**: LGBMClassifier, LGBMRegressor [249, 250].
- **Nivel**: Intermedio
- **Qué controla**: Define la fracción del total de variables predictoras que se evaluarán completamente al azar en cada uno de los árboles secuenciales individuales que se añaden al ensamble de LightGBM [114, 249].
- **Valores típicos**: Rango continuo: `[0.5, 0.6, 0.7, 0.8, 0.9, 1.0]` [114, 249]. Default en LightGBM = `1.0`.
- **Qué pasa si es muy alto**: (e.g. `1.0`, el default). Se evalúan exactamente todas las variables predictoras en cada nodo de todos los árboles secuenciales construidos. El modelo pierde variabilidad de descorrelacionamiento y ralentiza su tiempo de cómputo computacional en datasets con alta dimensionalidad [114].
- **Qué pasa si es muy bajo**: (e.g. `feature_fraction <= 0.4`). Reduce la cantidad de características a evaluar de forma extrema en cada nodo, acelerando el procesamiento computacional de la CPU pero arriesgando un subajuste si se excluyen las variables físicas predictoras dominantes.
- **Interacción con otros hiperparámetros**: Interactúa de forma directa con la tasa de aprendizaje (`learning_rate`) y el número de árboles secuenciales de LightGBM [249].
- **Estrategia de tuning recomendada**: Configurar de forma estándar un valor de `0.7` u `0.8` para inyectar diversidad espacial y agilizar enormemente el tiempo de entrenamiento sobre miles de columnas del dataset de planta [114].
- **Error común**: Mantener `feature_fraction=1.0` en datasets con cientos de variables redundantes, ralentizando de forma catastrófica el procesamiento sin aportar mejoras reales en la precisión del clasificador en vivo.
- **Aplicación práctica industrial**: *Minería / Procesamiento*. Pronóstico del consumo energético del sistema de ventilación forzada en base a telemetría ambiental (vibración de aspas, temperatura externa, humedad, velocidad de aire). Usar `feature_fraction=0.8` acelera un 40% el tiempo de cómputo de reentrenamiento del modelo diario sin alterar la precisión predictiva.
- **Referencia**: Ke, G. et al. (2017). *LightGBM: A Highly Efficient Gradient Boosting Decision Tree* [482].
- **Prioridad**: ⚡ Importante

## 11. CatBoost

CatBoost es una implementación de Gradient Boosting desarrollada por Yandex que destaca por el procesamiento nativo extremadamente sofisticado de variables categóricas mediante target statistics y el uso exclusivo de árboles de decisión simétricos oblicuos (oblivious trees) [160, 248, 482].

### 11.1 Profundidad de los Árboles Oblicuos Simétricos (`depth`)
- **Modelo(s)**: CatBoostClassifier, CatBoostRegressor [248, 250].
- **Nivel**: Básico
- **Qué controla**: Define el número de niveles o profundidad al que se le permite crecer a cada uno de los árboles secuenciales simétricos (oblivious trees) entrenados de forma paralela en el ensamble de CatBoost [248, 482]. En estos árboles, se evalúa exactamente la misma variable de corte y condición de forma simétrica a través de todos los nodos de un mismo nivel jerárquico del árbol [248, 482].
- **Valores típicos**: Rango acotado muy bajo: `[4, 5, 6, 7, 8, 10]` [248, 250]. Default en CatBoost = `6`.
- **Qué pasa si es muy alto**: (e.g. `depth >= 10` en datasets pequeños). Aumenta dramáticamente la complejidad estructural de los árboles simétricos, duplicando de forma exponencial el número de hojas terminales simultáneas por nivel, lo que conduce a un sobreajuste masivo y localizada en las hojas.
- **Qué pasa si es muy bajo**: (e.g. `depth <= 4`). Reduce la capacidad y la expresividad no lineal de los árboles simétricos de forma crítica, impidiendo capturar interacciones complejas de variables continuas del sistema físico y conduciendo a subajuste.
- **Interacción con otros hiperparámetros**: Su sintonía se combina con la regularización L2 de hojas (`l2_leaf_reg`) y la tasa de aprendizaje (`learning_rate`) [249, 250].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en conjunto con `l2_leaf_reg`. Para la gran mayoría de problemas tabulares reales de ingeniería industrial de la planta, valores de `depth = 6` o `7` proveen un balance de sesgo-varianza inmejorable.
- **Error común**: Intentar sintonizar profundidades elevadas (como `12` o `16`) creyendo que mejorará la precisión, provocando un desbordamiento de la memoria RAM del servidor de producción y deteniendo el proceso de reentrenamiento automático semanal de planta.
- **Aplicación práctica industrial**: *Banca / CRM (BCP)*. Clasificación en tiempo real del perfil de riesgo de transacciones de comercio electrónico en banca digital. Usar `depth=6` en los árboles simétricos de CatBoost asegura que el clasificador secuencial de Yandex capture sutilmente las tendencias de fraude transaccional sin sobrereaccionar ante ruidos aislados del dataset [175, 470].
- **Referencia**: Prokhorenkova, L. et al. (2018). *CatBoost: unbiased boosting with categorical features*. Advances in Neural Information Processing Systems [482].
- **Prioridad**: 🔥 Esencial

### 11.2 Coeficiente de Regularización L2 (`l2_leaf_reg`)
- **Modelo(s)**: CatBoostClassifier, CatBoostRegressor [248, 250].
- **Nivel**: Intermedio
- **Qué controla**: Coeficiente multiplicador del término de penalización de la norma L2 aplicado directamente sobre los pesos de las hojas secuenciales dentro del funcional formal de regularización de la función objetivo de CatBoost [114, 250].
- **Valores típicos**: Rango lineal: `[1.0, 3.0, 5.0, 10.0, 50.0]` [248, 250]. Default en CatBoost = `3.0`.
- **Qué pasa si es muy alto**: Obliga a que los pesos calculados de las hojas finales tiendan fuertemente a igualarse hacia cero, regularizando rígidamente el ensamble y provocando subajuste del modelo.
- **Qué pasa si es muy bajo**: Permite que las hojas de los árboles adquieran pesos con magnitudes extremas e inestables para aislar ruidos locales de entrenamiento del dataset, conduciendo a sobreajuste.
- **Interacción con otros hiperparámetros**: Su sintonía de regularización es complementaria a la sintonía del número de hojas de los árboles simétricos de CatBoost [249, 250].
- **Estrategia de tuning recomendada**: Sintonizar de forma logarítmica o lineal según el volumen del dataset de entrenamiento. En datasets industriales medianos (e.g. 50,000 muestras), usar valores de `[3.0, 5.0, 10.0, 20.0]` suele estabilizar enormemente las reglas lógicas resultantes.
- **Error común**: Dejar el parámetro de regularización L2 en cero (`l2_leaf_reg=0.0`) esperando ganar precisión de forma milagrosa en problemas tabulares ruidosos, perdiendo el beneficio de la regularización estructural de CatBoost.
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Predicción en tiempo real del desgaste superficial del acero laminado en frío en base a telemetría de vibración de la prensa hidráulica. Un `l2_leaf_reg=5.0` estabiliza de forma robusta las alertas lógicas predictivas semanales de planta.
- **Referencia**: Documentación oficial de CatBoost (Parameters) [248, 482].
- **Prioridad**: ⚡ Importante

### 11.3 Intensidad de Aleatoriedad para Divisiones (`random_strength`)
- **Modelo(s)**: CatBoostClassifier, CatBoostRegressor [249, 250].
- **Nivel**: Avanzado
- **Qué controla**: Define la intensidad de la aleatoriedad que se añade al evaluar las mejores divisiones candidatos en las ramas de los árboles secuenciales individuales del ensamble de CatBoost [249, 250]. Se utiliza para perturbar y descorrelacionar las decisiones lógicas linderas de los oblivious trees de Yandex [249, 250].
- **Valores típicos**: Rango cerrado: `[0.0, 0.5, 1.0, 2.0, 5.0]` [249, 250]. Default en CatBoost = `1.0`.
- **Qué pasa si es muy alto**: (e.g. `random_strength >= 5.0`). Perturba de forma excesiva e inestable la selección de divisiones candidatas linderas de los oblivious trees, impidiendo que el algoritmo elija las variables físicas de corte óptimas del sistema y conduciendo a subajuste del modelo.
- **Qué pasa si es muy bajo**: (e.g. `random_strength = 0.0`). El modelo se comportará de forma puramente determinista al procesar las divisiones de las ramas secuenciales de los oblivious trees, perdiendo la oportunidad de inyectar diversidad espacial y reducir la varianza general mediante aleatoriedad estocástica.
- **Interacción con otros hiperparámetros**: Su sintonía se combina con la tasa de aprendizaje (`learning_rate`) y la regularización L2 de hojas (`l2_leaf_reg`) [249, 250].
- **Estrategia de tuning recomendada**: Sintonizar como hiperparámetro de última capa mediante validación cruzada F1-Score.
- **Error común**: No comprender que la perturbación aleatoria de divisiones de CatBoost es una herramienta nativa de descorrelacionamiento estructural de oblivious trees y desactivarla por defecto (`random_strength=0.0`) en problemas industriales con alto ruido instrumental.
- **Aplicación práctica industrial**: *Siderúrgica / Procesos*. Predicción de fallas operacionales en ventiladores de extracción de polvo. Configurar un `random_strength=1.0` inyecta robustez en el Gradient Boosting secuencial, filtrando eventos de fallas de medición eléctrica de los sensores de planta.
- **Referencia**: Prokhorenkova, L. et al. (2018). *CatBoost: unbiased boosting with categorical features* [482].
- **Prioridad**: 💡 Opcional

## 12. AdaBoost

AdaBoost es un algoritmo pionero de aprendizaje por ensamble secuencial que optimiza la clasificación o regresión reponderando de forma iterativa y aditiva el peso de las observaciones de entrenamiento individuales, obligando a los estimadores débiles subsecuentes a enfocarse con mayor intensidad en las muestras que sufrieron los mayores errores de predicción en el paso previo [303, 346].

### 12.1 Estimador Base (`estimator` o `base_estimator`)
- **Modelo(s)**: AdaBoostClassifier, AdaBoostRegressor [105, 346].
- **Nivel**: Intermedio
- **Qué controla**: Define la clase matemática específica y la arquitectura estructural del estimador débil individual o aprendiz base que se construirá paso a paso de forma secuencial en el proceso iterativo del ensamble [105, 346].
- **Valores típicos**: `DecisionTreeClassifier(max_depth=1)` (tocón de decisión o stump por defecto) [44], `DecisionTreeClassifier(max_depth=2)` [44], o regresores lineales débiles. Default en scikit-learn = `DecisionTreeClassifier(max_depth=1)` (un árbol de un solo corte lógico) [44].
- **Qué pasa si es muy alto**: (e.g. `DecisionTreeClassifier(max_depth=10)`). Transforma los estimadores individuales en modelos complejos e independientes que sobreajustarán de forma instantánea al ruido local del dataset, anulando por completo el principio fundamental de boosting (aprendices débiles reponderados secuencialmente).
- **Qué pasa si es muy bajo**: (e.g. un regresor constante fijo inexpresivo). Impide que el ensamble aditivo de AdaBoost aprenda patrones reales mínimos del proceso productivo, conduciendo a subajuste del modelo secuencial.
- **Interacción con otros hiperparámetros**: Su configuración define la tasa de aprendizaje óptima (`learning_rate`) y la cantidad de estimadores secuenciales a construir del ensamble [309].
- **Estrategia de tuning recomendada**: Por regla general. Mantener el default de tocones de decisión (`max_depth=1`) o probar profundidades muy bajas (`max_depth=2` o `3`) si el dataset tabular industrial posee alta no linealidad física y se requiere capturar interacciones lógicas mínimas [44].
- **Error común**: Utilizar estimadores base excesivamente complejos en AdaBoost, permitiendo que el modelo sobreajuste de forma exponencial al ruido del set de entrenamiento.
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Clasificación de defectos en bobinas de acero en base a mediciones dimensionales de bobinado. Un `estimator=DecisionTreeClassifier(max_depth=2)` permite capturar interacciones mínimas de ancho x espesor x tensión mecánica de bobinado de forma estable.
- **Referencia**: Freund, Y., & Schapire, R. E. (1997). *A decision-theoretic generalization of on-line learning and an application to boosting*. Journal of Computer and System Sciences [228, 298].
- **Prioridad**: ⚡ Importante

### 12.2 Número de Estimadores (`n_estimators`)
- **Modelo(s)**: AdaBoostClassifier, AdaBoostRegressor [105, 346].
- **Nivel**: Básico
- **Qué controla**: Define la cantidad total de estimadores secuenciales débiles que se construirán paso a paso en el proceso iterativo del ensamble para corregir los residuos acumulados de los pasos previos [229, 309].
- **Valores típicos**: `[50, 100, 200, 500]` [229, 309, 355]. Default en scikit-learn = `50`.
- **Qué pasa si es muy alto**: Conduce a un sobreajuste severo del ensamble secuencial [309, 409]. Un número excesivo de estimadores secuenciales inevitablemente intentará ajustar y memorizar las muestras más difíciles y ruidosas de entrenamiento.
- **Qué pasa si es muy bajo**: El modelo sufrirá de subajuste severo, dejando al ensamble de árboles débiles a medio camino de corregir los errores de predicción.
- **Interacción con otros hiperparámetros**: Enlazado inversamente al multiplicador de tasa de aprendizaje (`learning_rate`) [409].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula o regla empírica. Se recomienda probar valores específicos como `[100, 200, 300]` mediante validación cruzada F1-Score [190].
- **Error común**: Configurar valores de `n_estimators` muy elevados sin inyectar regularización mediante una tasa de aprendizaje menor, provocando un sobreajuste severo del ensamble secuencial.
- **Aplicación práctica industrial**: *Banca / CRM*. Análisis de propensión de compra de préstamos personales sobre millones de clientes activos. Sintonizar el número óptimo de árboles previene que el modelo asuma comportamientos inusuales estacionales puntuales como tendencias grupales cíclicas de la banca [163].
- **Referencia**: Hastie, T., Tibshirani, R., & Friedman, J. (2009). *The Elements of Statistical Learning* [293, 344].
- **Prioridad**: 🔥 Esencial

### 12.3 Multiplicador de Tasa de Aprendizaje (`learning_rate`)
- **Modelo(s)**: AdaBoostClassifier, AdaBoostRegressor [105, 346].
- **Nivel**: Básico
- **Qué controla**: Multiplica el valor de la predicción y el peso de ajuste aportado por cada nuevo estimador secuencial que se añade al ensamble [113, 409].
- **Valores típicos**: `[0.01, 0.05, 0.1, 0.5, 1.0]` [113, 355]. Default en scikit-learn = `1.0`.
- **Qué pasa si es muy alto**: (e.g. `learning_rate = 1.0`, el default). El modelo converge demasiado rápido sobre las muestras de entrenamiento [409]. Esto provoca un sobreajuste inmediato, donde el algoritmo memoriza los patrones de ruido locales.
- **Qué pasa si es muy bajo**: (e.g. `learning_rate <= 0.01`). El aprendizaje secuencial se vuelve excesivamente lento [409]. Se requerirán miles de estimadores base adicionales para lograr ajustar los datos, prolongando el tiempo computacional de entrenamiento [409].
- **Interacción con otros hiperparámetros**: Íntimamente acoplado con `n_estimators` (relación inversamente proporcional) [409].
- **Estrategia de tuning recomendada**: Fijar una tasa de aprendizaje moderadamente baja (e.g. `0.1` o `0.2`) durante la exploración inicial [113, 409], y luego afinar el número de estimadores secuenciales óptimo mediante validación cruzada.
- **Error común**: Disminuir drásticamente la tasa de aprendizaje a un valor infinitesimal sin incrementar la cantidad de estimadores, dejando al ensamble de AdaBoost a medio entrenar.
- **Aplicación práctica industrial**: *Siderúrgica / Energía*. Pronóstico de consumo eléctrico diario para una acería. Usar una tasa de aprendizaje baja (`learning_rate=0.1`) con un número adecuado de estimadores secuenciales asegura que el modelo capte las tendencias reales de consumo eléctrico sin verse alterado por anomalías mecánicas puntuales de la acería [481, 520].
- **Referencia**: Documentación oficial de Scikit-Learn (Ensemble Methods) [362].
- **Prioridad**: 🔥 Esencial

## 13. K-Means / DBSCAN / Hierarchical Clustering

Los algoritmos de agrupamiento no supervisado dividen el conjunto de observaciones en subgrupos u homofilias lógicas basándose en métricas de distancia física y densidad espacial en el espacio multidimensional [118, 219, 468].

### 13.1 Número de Centroides / Grupos (`n_clusters` o `k`)
- **Modelo(s)**: KMeans, AgglomerativeClustering [118, 226].
- **Nivel**: Básico
- **Qué controla**: Define de forma determinista la cantidad exacta de centroides espaciales (K-Means) [118, 421] o de grupos finales de la jerarquía (Agrupamiento Jerárquico) que el algoritmo tiene permitido converger o recortar [469]. En K-Means, el algoritmo buscará de forma iterativa actualizar las posiciones de las coordenadas de las \(K\) medias para minimizar la inercia intracluster (suma de cuadrados internos de las distancias de las muestras a su centroide) [118, 421].
- **Valores típicos**: Enteros: `[2, 3, 5, 8, 12, 20]` [351, 410]. Default en scikit-learn = `8`.
- **Qué pasa si es muy alto**: El algoritmo segmentará el espacio en demasiados subgrupos pequeños hiper-localizados y redundantes. En el límite extremo, si \(K\) es igual a la cantidad de observaciones, cada muestra será su propio cluster, obteniendo una inercia de cero pero destruyendo toda utilidad analítica de agrupación.
- **Qué pasa si es muy bajo**: (e.g. `K = 1` o `2`). Conduce a un agrupamiento masivo subajustado, donde grupos con comportamientos mecánicos o geológicos radicalmente dispares se promedian de forma artificial bajo un mismo centroide global lejana [118].
- **Interacción con otros hiperparámetros**: Su sintonía depende de forma crítica del preprocesamiento y escalamiento de variables con media cero y varianza unitaria (`StandardScaler`) [461, 500]. Sin escalamiento previo, K-Means calculará las distancias vectoriales basándose casi exclusivamente en la variable de mayor magnitud del sistema [461, 500].
- **Estrategia de tuning recomendada**: Evaluar la inercia intracluster mediante el método del codo (Elbow Method) en combinación con el coeficiente de silueta (Silhouette Score) para validar de forma matemática y visual el punto óptimo del balance de compactación y separación [61].
- **Error común**: Elegir un valor de \(K\) basándose puramente en un criterio analítico rígido sin contrastar si el resultado posee sentido de ingeniería, negocio o aplicabilidad práctica para el personal operativo de la planta [326].
- **Aplicación práctica industrial**: *Minería / Procesamiento de Mineral*. Segmentación automática de tipos de mineral de roca sobre cintas transportadoras en base a lecturas continuas de telemetría espectral infrarroja. Sintonizar un \(K=4\) óptimo delimita de forma estable los cuatro dominios mineralógicos clave de alimentación para la molienda de la planta [468, 507].
- **Referencia**: Sayed, A. H. (2023). *Inference and Learning from Data Volume III_ Learning* [227, 263].
- **Prioridad**: 🔥 Esencial

### 13.2 Radio del Vecindario de Densidad (`eps` o `epsilon`)
- **Modelo(s)**: DBSCAN [219, 470].
- **Nivel**: Intermedio
- **Qué controla**: Define la distancia física o el radio máximo de proximidad espacial admisible alrededor de cualquier observación para que se le considere como "vecino inmediato" de dicho punto en el cálculo de densidad de DBSCAN [219, 509].
- **Valores típicos**: Rango continuo según escala de los datos: `[0.1, 0.3, 0.5, 1.0, 2.0]` [54, 219]. Default en scikit-learn = `0.5`.
- **Qué pasa si es muy alto**: DBSCAN unirá de forma artificial grupos distantes y dispares en un solo cluster gigantesco y continuo, ignorando pasillos de separación de baja densidad y perdiendo la granularidad estructural del sistema [219].
- **Qué pasa si es muy bajo**: El radio se vuelve tan restrictivo que casi ninguna muestra logrará acumular suficientes vecinos cercanos en su vecindario local. El algoritmo clasificará de forma errática a la gran mayoría de las muestras de entrenamiento como ruido operacional (outliers), impidiendo la convergencia de clusters lógicos [219].
- **Interacción con otros hiperparámetros**: Su sintonización está totalmente acoplada con la cantidad de vecinos mínimos requeridos (`min_samples`) [219].
- **Estrategia de tuning recomendada**: Calcular y graficar las distancias a los K-vecinos más cercanos (K-distance plot) ordenadas de mayor a menor. El valor óptimo de `eps` se localiza exactamente en la zona de inflexión o del codo pronunciado de la curva de distancias.
- **Error común**: Usar el valor por defecto `eps=0.5` sobre datos numéricos que no han sido escalados de forma adecuada, provocando que todas las muestras queden clasificadas instantáneamente como ruido o viceversa en un solo grupo global [461, 500].
- **Aplicación práctica industrial**: *Minería / Geotecnia*. Agrupamiento de eventos microsísmicos locales registrados por geófonos para perfilar fallas tectónicas activas y prevenir derrumbes en el tajo abierto de la mina. Sintonizar el `eps` óptimo delimita de forma exacta la forma arqueada libre de las fallas tectónicas sin verse alterado por el ruido de fondo de las voladuras mecánicas programadas [470, 509].
- **Referencia**: Ester, M., Kriegel, H. P., Sander, J., & Xu, X. (1996). *A density-based algorithm for discovering clusters in large spatial databases with noise*. KDD [213].
- **Prioridad**: 🔥 Esencial

### 13.3 Número Mínimo de Vecinos en el Radio (`min_samples`)
- **Modelo(s)**: DBSCAN [219, 470].
- **Nivel**: Intermedio
- **Qué controla**: Especifica la cantidad mínima de observaciones que deben residir de forma obligatoria dentro del radio `eps` de una muestra para que esta se clasifique de forma matemática como un punto núcleo (core point) con densidad suficiente para iniciar el crecimiento de un nuevo grupo [219].
- **Valores típicos**: Enteros: `[3, 4, 5, 10, 20, 50]` [219]. Default en scikit-learn = `5` [219].
- **Qué pasa si es muy alto**: Se exige un nivel de densidad local extremadamente elevado para iniciar clusters. DBSCAN se volverá muy intolerante y clasificará casi todas las observaciones de entrenamiento como ruido operacional, dejando únicamente grupos densos muy concentrados.
- **Qué pasa si es muy bajo**: (e.g. `min_samples <= 2`). El algoritmo perderá la capacidad de distinguir y descartar el ruido de forma segura. Pequeños ruidos o anomalías aisladas de 2 o 3 muestras consecutivas lograrán formar clusters independientes de forma errática, restando robustez no supervisada [219].
- **Interacción con otros hiperparámetros**: Íntimamente acoplado con `eps` [219]. A mayor `min_samples`, se requiere incrementar el radio `eps` de forma correspondiente para permitir que los vecindarios locales recopilen suficientes observaciones para el core point [219].
- **Estrategia de tuning recomendada**: Por regla general, configurar un valor mínimo de \(\text{min_samples} \ge D + 1\) (donde \(D\) es la cantidad de variables predictoras en el espacio n-dimensional). Incrementar de forma proporcional si el conjunto de datos de entrenamiento posee un alto nivel de ruido de fondo.
- **Error común**: Configurar `min_samples=1` sobre datasets reales ruidosos, convirtiendo de forma inútil al algoritmo DBSCAN en un agrupamiento jerárquico de enlace simple donde no se descarta ningún ruido del sistema de planta.
- **Aplicación práctica industrial**: *Manufactura / Mantenimiento*. Agrupamiento de lecturas anómalas de telemetría de vibración multiaxial de motores eléctricos para clasificar modos de falla específicos. Sintonizar `min_samples=10` asegura que las anomalías se agrupen de forma robusta e independiente de picos de ruido momentáneos e individuales de medición eléctrica del sensor [469, 508].
- **Referencia**: Documentación oficial de Scikit-Learn (Unsupervised Clustering) [362].
- **Prioridad**: ⚡ Importante

### 13.4 Criterio de Enlace de Clusters (`linkage`)
- **Modelo(s)**: AgglomerativeClustering [469, 508].
- **Nivel**: Avanzado
- **Qué controla**: Especifica la fórmula geométrica utilizada para cuantificar la distancia entre dos subgrupos candidatos de la jerarquía antes de decidir su fusión aglomerativa secuencial (bottom-up) [469, 508]. Las opciones estándar en scikit-learn son `'ward'` (minimiza el incremento de la varianza interna total), `'complete'` (distancia máxima entre puntos), `'average'` (distancia promedio de las observaciones de los grupos) y `'single'` (distancia mínima de enlace) [469, 508].
- **Valores típicos**: `['ward', 'complete', 'average', 'single']` [469, 508]. Default en scikit-learn = `'ward'`.
- **Qué pasa si es muy alto**: N/A (Categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Su sintonización define la estructura visual final del dendrograma jerárquico del dataset [469, 508]. `'single'` tiende a formar clusters alargados y continuos (efecto encadenamiento), mientras que `'ward'` genera clusters circulares y compactos altamente balanceados en tamaño [469].
- **Estrategia de tuning recomendada**: Usar `'ward'` por defecto debido a su robustez estadística en la gran mayoría de problemas de ingeniería [469]. Utilizar `'average'` o `'complete'` si el dendrograma de validación muestra estructuras dispares o se sospecha de presencia de anomalías extremas [469, 508].
- **Error común**: Utilizar `'single'` linkage sobre datos reales ruidosos de sensores de planta, provocando que casi todas las muestras de la planta se encadenen de forma artificial en un solo cluster gigantesco debido al ruido de fondo.
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Clasificación de tipos de fallas complejas basadas en registros de vibración multiaxiales de trenes de laminación. El uso de `'ward'` permite estructurar de forma clara y jerárquica un dendrograma con la taxonomía natural de fallas lógicas de rodamiento, facilitando al equipo de mecánicos de planta entender las causas físicas subyacentes [469, 508].
- **Referencia**: Ward, J. H. (1963). *Hierarchical grouping to optimize an objective function*. Journal of the American Statistical Association [469].
- **Prioridad**: 💡 Opcional

## 14. PCA / t-SNE / UMAP

Las técnicas de reducción de dimensionalidad proyectan o incrustan espacios multidimensionales complejos en subespacios de dimensiones inferiores (típicamente bidimensionales para visualización o menor rango para eficiencia computacional de clasificadores) conservando la estructura de varianza o vecindad original [193, 203, 471].

### 14.1 Número de Componentes o Dimensiones de Salida (`n_components`)
- **Modelo(s)**: PCA, TSNE, UMAP [115, 193, 203].
- **Nivel**: Básico
- **Qué controla**: Define la cantidad de dimensiones, componentes principales o coordenadas latentes que tendrá el espacio de salida proyectado una vez aplicada la reducción lineal o no lineal [115, 193]. En PCA, calcula los autovectores principales correspondientes a los autovalores más grandes de la matriz de covarianza de las características del dataset [262].
- **Valores típicos**: PCA: `[2, 3, 5, 10, 15, 20, 50]` [203, 209]. t-SNE / UMAP: `[2, 3]` (para visualización gráfica directa en 2D o 3D) [115, 471]. Default en scikit-learn (PCA) = `None` (retorna todas las variables proyectadas).
- **Qué pasa si es muy alto**: Se reduce el beneficio de la reducción de dimensiones. El subespacio conservará gran parte de la dimensionalidad, el ruido de fondo y la redundancia del dataset, obligando a los clasificadores subsecuentes a procesar hardware innecesario y arriesgando la maldición de la dimensionalidad [209].
- **Qué pasa si es muy bajo**: (e.g. `n_components = 1` o `2` en datasets con miles de variables complejas). Provoca una pérdida catastrófica de información e interpretabilidad [209]. En PCA, la varianza explicada acumulada será insignificante, diluyendo los patrones predictivos reales de los sensores físicos del proceso de la planta [209].
- **Interacción con otros hiperparámetros**: Su sintonización define el rendimiento computacional de clasificadores complejos como SVM [209].
- **Estrategia de tuning recomendada**: Para PCA, graficar la curva de varianza explicada acumulada (Scree Plot) en base a los autovalores y elegir el número de componentes donde la curva se estabilice en un codo pronunciado (típicamente reteniendo entre el 80% y 95% de la varianza total de los sensores) [209]. Para t-SNE/UMAP, mantener estrictamente en `2` para visualización gráfica bidimensional [471, 510].
- **Error común**: Utilizar PCA sin estandarizar previamente las variables de la planta. PCA maximiza la varianza lineal. Si una variable tiene magnitudes de miles (como rpm de molino) y otra decimales de milímetros, la primera componente principal se alineará casi en su totalidad con la variable de mayor rango mecánico [461, 500].
- **Aplicación práctica industrial**: *Manufactura / Siderúrgica*. Reducción de 200 sensores ruidosos de una planta de laminado de acería. Reducir mediante PCA a `n_components=15` retiene el 92% de la varianza física real, depurando por completo el ruido ambiental y acelerando el entrenamiento de modelos clasificadores subsecuentes semanales de planta [209, 484].
- **Referencia**: Pearson, K. (1901). *On lines and planes of closest fit to systems of points in space*. Philosophical Magazine [262].
- **Prioridad**: 🔥 Esencial

### 14.2 Perplejidad o Vecindario Local (`perplexity` para t-SNE)
- **Modelo(s)**: TSNE [193].
- **Nivel**: Intermedio
- **Qué controla**: Define el número efectivo de puntos de entrenamiento que se evaluarán como vecinos inmediatos al aproximar la densidad de distribución de probabilidad conjunta local en el espacio multidimensional complejo original [193]. Actúa de forma intuitiva como un balanceador entre enfocar el algoritmo en la estructura local estrecha de los datos o en la estructura global amplia [115, 193].
- **Valores típicos**: Rango lineal continuo: `[5, 10, 30, 50, 100]` [193]. Default en scikit-learn = `30.0`.
- **Qué pasa si es muy alto**: (e.g. `perplexity >= 100` en datasets pequeños). El algoritmo promediará relaciones espaciales excesivamente distantes en la distribución Gaussiana original, fundiendo grupos que poseen dinámicas físicas independientes en un único aglomerado informe y sin estructura local clara.
- **Qué pasa si es muy bajo**: (e.g. `perplexity <= 2`). El algoritmo enfocará su cómputo de probabilidad exclusivamente en vecindarios hiper-localizados y diminutos. Esto provocará la fragmentación artificial de grupos naturales consolidados en decenas de micro-clusters artificiales (efecto bola de nieve), desorientando por completo el análisis visual.
- **Interacción con otros hiperparámetros**: Íntimamente acoplado con la tasa de aprendizaje del optimizador de gradientes estocásticos (`learning_rate`) y el número de iteraciones computacionales de t-SNE [193].
- **Estrategia de tuning recomendada**: Usar regla empírica. Se recomienda probar valores específicos en el rango de `[10, 30, 50]` y evaluar visualmente las agrupaciones lógicas en base al conocimiento físico del proceso de la planta.
- **Error común**: Creer de forma ingenua que existe un único valor de `perplexity` matemáticamente óptimo, ignorando que t-SNE es una técnica altamente heurística donde el resultado visual debe interpretarse de forma visual complementaria con la física de la planta.
- **Aplicación práctica industrial**: *Banca / CRM*. Visualización bidimensional de agrupamientos de comportamiento transaccional del cliente. Sintonizar un `perplexity=40` permite delimitar de forma clara y compacta los subgrupos transaccionales (e.g., ahorradores pasivos, compradores digitales nocturnos, inversionistas de bolsa BCP) sin fragmentaciones artificiales.
- **Referencia**: van der Maaten, L., & Hinton, G. (2008). *Visualizing Data using t-SNE*. Journal of Machine Learning Research [193, 213].
- **Prioridad**: ⚡ Importante

### 14.3 Número de Vecinos de Vecindad Local (`n_neighbors` para UMAP)
- **Modelo(s)**: UMAP [115].
- **Nivel**: Intermedio
- **Qué controla**: Define la cantidad de vecinos inmediatos que se evaluarán al aproximar la geometría del colector local de datos sobre el cual residen las observaciones en el espacio multidimensional complejo [115]. Controla el balance entre enfocar el algoritmo en la estructura de proximidad hiper-local o en la topología global amplia [115].
- **Valores típicos**: Enteros: `[5, 15, 30, 50, 100]` [115]. Default en UMAP = `15`.
- **Qué pasa si es muy alto**: El algoritmo priorizará conservar la topología de grandes distancias y la estructura macro de los datos, perdiendo la finura de separación de micro-grupos muy especializados en el espacio de salida.
- **Qué pasa si es muy bajo**: (e.g. `n_neighbors <= 4`). El algoritmo se enfocará exclusivamente en preservar las distancias hiper-locales, fragmentando de forma artificial grupos consolidados y perdiendo la visión de la macro-estructura del sistema de planta [115].
- **Interacción con otros hiperparámetros**: Su sintonización está totalmente enlazada con la distancia mínima de empaquetamiento de coordenadas (`min_dist`).
- **Estrategia de tuning recomendada**: Usar de forma estándar `n_neighbors = 15` o `30` para la gran mayoría de problemas tabulares reales de ingeniería [115].
- **Error común**: Configurar valores extremadamente bajos en datasets masivos donde unas pocas variables de planta concentran la señal, provocando fragmentaciones artificiales del colector geométrico.
- **Aplicación práctica industrial**: *Siderúrgica / Procesos*. Visualización bidimensional del mapa de estados térmicos de un horno químico de fundición de acero de alta complejidad física. Un `n_neighbors=30` permite delimitar de forma clara las trayectorias de transición térmica estables del horno de la planta [471, 510].
- **Referencia**: McInnes, L., Healy, J., & Melville, J. (2018). *UMAP: Uniform Manifold Approximation and Projection for Dimension Reduction*. arXiv preprint [213, 217].
- **Prioridad**: ⚡ Importante

### 14.4 Distancia Mínima de Empaquetamiento (`min_dist` para UMAP)
- **Modelo(s)**: UMAP [116].
- **Nivel**: Avanzado
- **Qué controla**: Define la distancia física mínima admisible de separación entre puntos en el espacio de salida proyectado de baja dimensión (2D o 3D) [116]. Controla qué tan densamente empaquetados e incrustados estarán los puntos individuales dentro de las regiones de sus respectivos clusters en el gráfico de salida.
- **Valores típicos**: Rango continuo de `[0.0, 0.01, 0.1, 0.25, 0.5]` [116]. Default en UMAP = `0.1`.
- **Qué pasa si es muy alto**: Los puntos se distribuirán de forma muy holgada y difusa en el gráfico, perdiendo la nitidez visual de la forma compacta de los clusters y asimilándose a un mapa uniforme ruidoso de planta.
- **Qué pasa si es muy bajo**: (e.g. `min_dist = 0.0` o cercano). El algoritmo forzará a que los puntos similares colapsen exactamente a coordenadas idénticas, compactando los clusters en puntos discretos hiper-densos en el mapa, perdiendo el gradiente interno de variabilidad física.
- **Interacción con otros hiperparámetros**: Íntimamente acoplado con `n_neighbors`.
- **Estrategia de tuning recomendada**: Búsqueda lineal fina en escala continua. `min_dist=0.1` provee una definición estándar óptima. Si se busca máxima definición visual de las fronteras físicas de los clusters de planta, reducir a `0.01` o `0.05`.
- **Error común**: Forzar `min_dist = 0.0` sobre datos operacionales ruidosos de sensores de planta, provocando colapsos de coordenadas ininterpretables en el FastAPI semanal.
- **Aplicación práctica industrial**: *Minería / Procesamiento*. Visualización del mapa de estados térmicos de una fundidora de metal compleja de alta dimensión. Configurar un `min_dist=0.05` permite compactar de forma nítida los clusters de anomalías de vibración [471, 510].
- **Referencia**: McInnes, L., Healy, J., & Melville, J. (2018). *UMAP: Uniform Manifold Approximation and Projection for Dimension Reduction* [213, 217].
- **Prioridad**: 💡 Opcional

## 15. Redes Neuronales Densas (MLP)

El perceptrón multicapa (MLP) es la red conexionista de base para procesar datos tabulares, mapeando las características a través de capas densas consecutivas donde cada neurona calcula un promedio ponderado de la capa anterior y le inyecta una transformación no lineal utilizando una función de activación [1, 24, 217].

### 15.1 Estructura y Cantidad de Neuronas por Capa Oculta (`hidden_layer_sizes`)
- **Modelo(s)**: MLPClassifier, MLPRegressor [226, 229].
- **Nivel**: Básico
- **Qué controla**: Define de forma directa la arquitectura y topología estructural del cerebro del conexionismo profundo [140, 217]. Especifica cuántas capas ocultas independientes se construirán en secuencia, y exactamente cuántas neuronas artificiales computarán de forma paralela en el espacio de representación de cada una de esas capas [140, 217, 246].
- **Valores típicos**: Tuplas de enteros: `[(100,)` (una sola capa con 100 neuronas), `(50, 50)` (dos capas con 50 c/u), `(128, 64, 32)` (tres capas reduciendo dimensionalidad en embudo)] [226, 229, 246]. Default en scikit-learn = `(100,)`.
- **Qué pasa si es muy alto**: (e.g. `(512, 256, 128)` en datasets con pocas filas). Dispara la capacidad y expresividad del conexionismo profundo de forma excesiva, multiplicando los millones de pesos libres de entrenamiento del modelo de forma redundante y provocando sobreajuste severo del modelo [192]. Además, prolonga drásticamente el tiempo de entrenamiento de la CPU [140, 192].
- **Qué pasa si es muy bajo**: (e.g. `(2,)`). El modelo sufrirá de subajuste severo del conexionismo profundo, siendo incapaz de aproximar fronteras de decisión curvadas no lineales complejas del sistema físico [3, 24].
- **Interacción con otros hiperparámetros**: Su sintonía de regularización es complementaria a la sintonía de Dropout y regularización L2 (`alpha`) [1, 246].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en un rango acotado combinando la estructura y cantidad de neuronas. Un embudo descendente clásico (e.g. `(64, 32)`) suele converger de forma óptima en datos tabulares industriales [192].
- **Error común**: Diseñar redes neuronales profundas gigantescas y complejas de múltiples capas ocultas sobre datasets tabulares pequeños donde un simple regresor OLS Ridge estabilizaría de forma muy superior la varianza [3, 34].
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Clasificación no lineal de la calidad física del acero laminado en base a 20 mediciones de sensores continuos de la prensa. Configurar una arquitectura de `hidden_layer_sizes=(64, 32)` permite al MLP capturar de forma exacta interacciones térmicas complejas, minimizando los desperdicios en producción [487, 526].
- **Referencia**: Bishop, C. M. (1995). *Neural Networks for Pattern Recognition* [76, 487].
- **Prioridad**: 🔥 Esencial

### 15.2 Función de Activación No Lineal (`activation`)
- **Modelo(s)**: MLPClassifier, MLPRegressor [192, 217].
- **Nivel**: Básico
- **Qué controla**: Define la función matemática específica empleada para transformar la suma ponderada neta de entrada de cada neurona en su valor de salida final [1, 217]. Inyecta la no linealidad necesaria para que el modelo pueda aproximar cualquier función matemática arbitraria (Teorema de Aproximación Universal) [1, 140].
- **Valores típicos**: `'relu'` (Rectified Linear Unit), `'tanh'` (tangente hiperbólica), `'logistic'` (sigmoidea) [1]. Default en scikit-learn = `'relu'`.
- **Qué pasa si es muy alto**: N/A (Categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Si se utiliza `'relu'`, el entrenamiento computacional será drásticamente más rápido, pero se debe vigilar la tasa de aprendizaje (`learning_rate`) para evitar el fenómeno de "muerte de neuronas ReLU" [1].
- **Estrategia de tuning recomendada**: Mantener `'relu'` por defecto por su gran velocidad de convergencia matemática y bajo costo computacional [1].
- **Error común**: Utilizar `'logistic'` de forma general en todas las capas ocultas profundas de la red, provocando un estancamiento del aprendizaje debido al fenómeno del desvanecimiento del gradiente (vanishing gradient) [1].
- **Aplicación práctica industrial**: *Banca / Scoring (BCP)*. Predicción mensual de la demanda de efectivo en cajeros automáticos (ATMs) en base a ubicación de agencias. Usar `'relu'` asegura que la convergencia del modelo se logre en minutos sobre millones de transacciones de entrenamiento.
- **Referencia**: Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning* [135, 140].
- **Prioridad**: ⚡ Importante

### 15.3 Tasa de Penalización L2 / Decaimiento de Pesos (`alpha`)
- **Modelo(s)**: MLPClassifier, MLPRegressor [1, 245, 246].
- **Nivel**: Intermedio
- **Qué controla**: Coeficiente multiplicador del término de regularización L2 aplicado directamente sobre los pesos de la red conexionista profunda [1, 246]. Actúa para contraer las magnitudes absolutas de los pesos de la red profunda, forzando a que las decisiones dependientes del conexionismo profundo sean más suaves y regulares [1, 246].
- **Valores típicos**: Rango logarítmico lineal fino: `[1e-5, 1e-4, 1e-3, 0.01, 0.1]` [246, 247]. Default en scikit-learn = `1e-4`.
- **Qué pasa si es muy alto**: Comprime excesivamente los pesos hacia cero, neutralizando el poder de aprendizaje de la red profunda y conduciendo a subajuste del modelo.
- **Qué pasa si es muy bajo**: No realiza contracción de pesos de la red conexionista, permitiendo al modelo ajustar en exceso el ruido local de entrenamiento de planta y sobreajustar.
- **Interacción con otros hiperparámetros**: Su sintonía se combina con la tasa de aprendizaje (`learning_rate`) y la estructura de neuronas de las capas ocultas de la red profunda [246].
- **Estrategia de tuning recomendada**: Búsqueda exponencial bidimensional en cuadrícula combinando `alpha` y `learning_rate` [247].
- **Error común**: Ignorar este parámetro en redes neuronales MLP complejas entrenadas sobre datos ruidosos de sensores de planta, permitiendo sobreajuste masivo invisible para el científico de datos [192].
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Predicción de fallas mecánicas por fatiga estructural en revestimiento interno del horno en base a telemetría de sensores continuos térmicos de planta. Un `alpha=1e-3` regulariza de forma robusta las predicciones diarias [490, 529].
- **Referencia**: Documentación oficial de Keras / TensorFlow (Regularizers) [347].
- **Prioridad**: ⚡ Importante

## 16. Redes Neuronales Convolucionales (CNN)

Las redes convolucionales (CNN) procesan datos con estructura de cuadrícula (como imágenes de inspección o espectrogramas de vibración), deslizando filtros locales (convoluciones) para extraer características espaciales de forma invariante ante traslaciones [187-3, 200, 213].

### 16.1 Tamaño del Filtro de Convolución (`kernel_size`)
- **Modelo(s)**: Conv2D, Conv1D [200].
- **Nivel**: Básico
- **Qué controla**: Define la altura y el ancho bidimensional de la ventana del filtro deslizante (receptivo local) que se convoluciona a través de la matriz de entrada para calcular el producto punto local de las características espaciales [213, 322].
- **Valores típicos**: Matrices cuadradas de enteros impares: `[(3, 3)`, `(5, 5)`, `(7, 7)]` o enteros simples para Conv1D [200]. Default en keras = `(3, 3)`.
- **Qué pasa si es muy alto**: (e.g. `(11, 11)`). Fuerza a que el filtro tenga un campo receptivo excesivamente ancho de forma burda en las capas iniciales, asumiendo características espaciales demasiado generales y perdiendo la granularidad fina necesaria para identificar pequeños bordes o texturas locales físicas, además de multiplicar de forma drástica el tiempo computacional de convolución.
- **Qué pasa si es muy bajo**: (e.g. `(1, 1)`). Se reduce a una proyección de mezcla de canales individuales lineal. Si se parametriza como `(1,1)` de forma general, la red será incapaz de capturar la vecindad o el contexto espacial mínimo de las características espaciales linderas de la cuadrícula de entrada.
- **Interacción con otros hiperparámetros**: Su efectividad define la necesidad de relleno de bordes (`padding`) y el desplazamiento del paso del filtro (`stride`).
- **Estrategia de tuning recomendada**: Usar de forma estándar `(3, 3)` para capas profundas, ya que apilar múltiples capas pequeñas de `(3, 3)` posee el mismo campo receptivo que un filtro de `(5, 5)` pero con una enorme reducción en la cantidad de parámetros libres de entrenamiento y mayor no linealidad intermedia [187-3, 200].
- **Error común**: Diseñar filtros de gran tamaño en capas profundas del conexionismo de visión creyendo que aumentará la resolución, provocando una ralentización drástica del procesamiento y sobreajuste del modelo.
- **Aplicación práctica industrial**: *Siderúrgica / Calidad de Producto*. Detección en vivo de micro-grietas superficiales en bobinas de acero en caliente mediante visión artificial. Un `kernel_size=(3, 3)` en las primeras capas convolucionales de la red profunda captura con precisión quirúrgica el borde fino de la grieta física del metal [495, 534].
- **Referencia**: LeCun, Y., Bottou, L., Bengio, Y., & Haffner, P. (1998). *Gradient-based learning applied to document recognition*. Proceedings of the IEEE [200, 213].
- **Prioridad**: 🔥 Esencial

### 16.2 Paso del Desplazamiento del Filtro (`stride`)
- **Modelo(s)**: Conv2D, Conv1D, MaxPool2D [200].
- **Nivel**: Intermedio
- **Qué controla**: Define la cantidad de píxeles o celdas de cuadrícula de entrada que la ventana del filtro deslizante de convolución o pooling tiene permitido avanzar de forma consecutiva al desplazarse horizontal y verticalmente sobre la matriz de entrada [200, 312].
- **Valores típicos**: Enteros: `[1, 2, 3]` o tuplas: `(1, 1)`, `(2, 2)` [200]. Default en keras = `1`.
- **Qué pasa si es muy alto**: (e.g. `stride = 4`). Provoca un muestreo de salida excesivamente abrupto e inestable de las características espaciales del dataset. El filtro se saltará gran parte de las zonas de solapamiento de la cuadrícula, provocando una pérdida catastrófica de resolución y de señal de generalización de la red profunda [200].
- **Qué pasa si es muy bajo**: (e.g. `stride = 1`). El filtro avanzará de forma muy lenta píxel a píxel de forma redundante. Esto aumentará drásticamente la dimensión matemática de la capa de salida resultante (mapa de activación) y el tiempo computacional de procesamiento de convolución de la CPU / GPU.
- **Interacción con otros hiperparámetros**: Enlazado con `padding` [200]. Aumentar `stride` es una técnica alternativa para reducir de forma drástica las dimensiones espaciales sin recurrir a capas de agrupamiento (`pooling`) [200, 213].
- **Estrategia de tuning recomendada**: Mantener en `1` por defecto para capas convolucionales primarias para preservar al máximo la resolución espacial [200]. Utilizar `stride = 2` exclusivamente en capas convolucionales de última milla para comprimir las dimensiones espaciales antes de la capa densa del clasificador final.
- **Error común**: Configurar pasos elevados (`stride > 2`) sobre datasets de imágenes de baja resolución de campo, provocando la desaparición instantánea de las micro-características físicas de las soldaduras o texturas [477].
- **Aplicación práctica industrial**: *Siderúrgica / Control de Procesos*. Clasificación de la calidad del granulado del clínker de cemento mediante procesamiento en tiempo real de imágenes de cámara del horno de Pacasmayo. Un `stride=1` en las capas primarias de la red convolucional asegura capturar las texturas finas tridimensionales de las partículas individuales de clínker [489, 528].
- **Referencia**: Documentación oficial de Keras / PyTorch (Convolutional Layers) [347, 491].
- **Prioridad**: ⚡ Importante

### 16.3 Relleno de Bordes de la Entrada (`padding`)
- **Modelo(s)**: Conv2D, Conv1D [200].
- **Nivel**: Intermedio
- **Qué controla**: Define la estrategia matemática utilizada para rellenar de forma artificial los bordes externos de la matriz o imagen de entrada de la capa convolucional antes de aplicar el deslizamiento del filtro [200, 312]. Las dos opciones estándar son `'valid'` (sin relleno, el filtro solo se desliza dentro de los límites estrictos reales de la matriz de entrada) o `'same'` (rellena los bordes perimetrales con ceros para garantizar que la matriz de salida tenga exactamente las mismas dimensiones horizontales y verticales que la matriz de entrada) [200].
- **Valores típicos**: `['valid', 'same']` [200]. Default en keras = `'valid'`.
- **Qué pasa si es muy alto**: N/A (Categórico).
- **Qué pasa si es muy bajo**: N/A.
- **Interacción con otros hiperparámetros**: Si se utiliza `'valid'`, la dimensión espacial de los mapas de activación de salida se contraerá de forma continua e inevitable con cada nueva capa convolucional agregada: \(N_{\text{out}} = N_{\text{in}} - F + 1\) [200]. Esto limita de forma estricta la profundidad de capas de la arquitectura convolucional que se puede apilar en la CPU [200, 213].
- **Estrategia de tuning recomendada**: Usar `'same'` por defecto en la gran mayoría de diseños de redes profundas de visión artificial de la planta [200]. Esto garantiza que los bordes de la imagen (donde a menudo se localizan sensores o anomalías físicas marginales) sean procesados con el mismo peso por los filtros y evita la contracción dimensional prematura [200].
- **Error común**: Mantener `'valid'` por defecto en redes convolucionales profundas complejas, provocando que las capas intermedias colapsen a dimensiones de 1x1 antes de poder extraer patrones abstractos complejos del sistema de planta [200, 213].
- **Aplicación práctica industrial**: *Minería / Automatización de Procesos*. Inspección visual robótica del desgaste de dientes de palas cargadoras mineras pesadas. El uso de `padding='same'` en la red convolucional profunda asegura que el perímetro de desgaste metálico lateral marginal de los dientes no sea ignorado por el filtro convolucional de visión de planta [491, 530].
- **Referencia**: Goodfellow, I., Bengio, Y., & Courville, A. (2016). *Deep Learning* [135, 140].
- **Prioridad**: ⚡ Importante

### 16.4 Tamaño de la Ventana de Agrupamiento (`pool_size` para Max/Average Pooling)
- **Modelo(s)**: MaxPool2D, AveragePool2D [200, 213].
- **Nivel**: Avanzado
- **Qué controla**: Define las dimensiones horizontales y verticales de la ventana de agrupamiento descendente que resume la información espacial de las capas convolucionales [200, 213]. Actúa como un reductor geométrico de dimensiones no entrenable de forma directa en el flujo de la red [200, 213].
- **Valores típicos**: Tuplas de enteros: `[(2, 2)`, `(3, 3)]` [200]. Default en keras = `(2, 2)`.
- **Qué pasa si es muy alto**: (e.g. `(4, 4)` o superior). Contraerá la imagen de forma demasiado brusca y violenta, promediando de forma burda zonas de mapa de activación dispares y perdiendo la resolución fina necesaria para identificar pequeños bordes o texturas locales de planta [200].
- **Qué pasa si es muy bajo**: (e.g. `(1, 1)`). Se reduce a una identidad de mezcla inútil, no logrando comprimir las dimensiones ni inyectar la inmunidad ante pequeñas variaciones espaciales típica del pooling de visión.
- **Interacción con otros hiperparámetros**: Su sintonía de regularización es complementaria a la sintonía del paso del filtro (`stride`) de la red profunda convolucional [200, 213].
- **Estrategia de tuning recomendada**: Usar de forma estándar `pool_size=(2, 2)` con paso de filtro correspondiente de `stride=(2, 2)`, reduciendo la dimensión espacial del mapa de activación a exactamente la mitad de forma limpia en el conexionismo de visión de planta [200].
- **Error común**: Apilar de forma continua múltiples capas de pooling complejas de gran tamaño, perdiendo la resolución espacial necesaria para identificar fallas pequeñas en soldaduras de acería.
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Clasificación de tipos de fallas de soldadura en base a imágenes radiográficas digitalizadas de planta. El uso de `pool_size=(2, 2)` compacta los mapas de activación de forma óptima sin perder los bordes finos de las grietas estructurales del metal [477, 495].
- **Referencia**: Documentación oficial de Keras / PyTorch (Pooling Layers) [347, 491].
- **Prioridad**: 💡 Opcional

## 17. Redes Neuronales Recurrentes (RNN / LSTM / GRU)

Las redes recurrentes procesan datos con secuencia temporal (como series de tiempo de sensores de telemetría de vibración o variables exógenas de planta), manteniendo un estado de memoria oculto para rastrear de forma iterativa y secuencial las dependencias temporales pasadas [98, 255, 312].

### 17.1 Tamaño de la Dimensión de Memoria Oculta (`hidden_size` o `units`)
- **Modelo(s)**: SimpleRNN, LSTM, GRU [193, 226].
- **Nivel**: Básico
- **Qué controla**: Define de forma directa la capacidad y la expresividad no lineal del conexionismo temporal recurrente, especificando cuántas dimensiones ocultas o unidades de memoria individuales calcularán de forma paralela en el espacio de representación latente secuencial [140, 226].
- **Valores típicos**: Enteros: `[16, 32, 64, 128, 256]` [226, 229, 246]. Default en keras = `32` o `64`.
- **Qué pasa si es muy alto**: (e.g. `hidden_size >= 256` en datasets con pocas observaciones secuenciales). Dispara la capacidad y expresividad del conexionismo recurrente de forma excesiva, multiplicando los millones de pesos libres de entrenamiento del modelo de forma redundante y provocando sobreajuste severo en validación cruzada [192].
- **Qué pasa si es muy bajo**: (e.g. `hidden_size <= 8`). El modelo sufrirá de subajuste secuencial, siendo incapaz de aproximar dependencias temporales no lineales de variables físicas predictoras de planta [3, 24].
- **Interacción con otros hiperparámetros**: Su sintonía de regularización es complementaria a la sintonía de Dropout recurrente y regularización L2 (`alpha`) [1, 246].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en un rango acotado combinando la estructura y cantidad de neuronas. Un valor de `64` o `128` suele converger de forma óptima en series de tiempo de planta [192].
- **Error común**: Diseñar redes neuronales recurrentes gigantescas de múltiples capas ocultas sobre datasets con series de tiempo cortas de planta, sobreajustando el modelo secuencial de planta.
- **Aplicación práctica industrial**: *Siderúrgica / Procesos*. Predicción de fallas operacionales por fatiga en revestimiento interno de horno en base a telemetría de sensores continuos térmicos de planta. Un `hidden_size=128` en una red LSTM recurrente captura de forma exacta las dependencias temporales complejas de la planta [490, 529].
- **Referencia**: Hochreiter, S., & Schmidhuber, J. (1997). *Long short-term memory*. Neural Computation [200, 213].
- **Prioridad**: 🔥 Esencial

### 17.2 Número de Capas Recurrentes Apiladas (`num_layers`)
- **Modelo(s)**: SimpleRNN, LSTM, GRU [226, 246].
- **Nivel**: Básico
- **Qué controla**: Define cuántas capas recurrentes independientes de SimpleRNN, LSTM o GRU se construirán e interconectarán de forma jerárquica secuencial en el proceso del ensamble [226, 246].
- **Valores típicos**: Enteros: `[1, 2, 3]` [226, 246]. Default en keras = `1`.
- **Qué pasa si es muy alto**: (e.g. `num_layers >= 4`). Provoca un sobreajuste secuencial extremo de los árboles secuenciales del gradiente. El modelo de la planta intentará ajustar y memorizar los patrones de ruido temporales de forma sinuosa, además de prolongar drásticamente el tiempo de entrenamiento de la CPU.
- **Qué pasa si es muy bajo**: (e.g. `num_layers = 1`, el default). El modelo sufrirá de subajuste secuencial en datasets con dependencias temporales jerárquicas complejas y dinámicas físicas en la planta.
- **Interacción con otros hiperparámetros**: Enlazado con `hidden_size` y `dropout` [246]. Si se incrementa `num_layers`, se recomienda usarlo junto con el parámetro de regularización de Dropout para evitar el sobreajuste del modelo [192].
- **Estrategia de tuning recomendada**: Mantener `num_layers = 1` o `2` en la práctica industrial para garantizar la correcta reducción de varianza del ensamble [226].
- **Error común**: Apilar múltiples capas recurrentes sin configurar `return_sequences=True` en las capas intermedias, provocando errores silenciosos de dimensiones matemáticas de salida en el FastAPI de planta [491].
- **Aplicación práctica industrial**: *Banca / CRM*. Pronóstico de la demanda de efectivo en cajeros automáticos (ATMs) del BCP en base a variables exógenas de la planta. Sintonizar un `num_layers=2` en una red profunda recurrente LSTM con regularización de Dropout captura de forma exacta la ciclicidad compleja de retiros semanales de planta.
- **Referencia**: Graves, A. et al. (2013). *Speech recognition with deep recurrent neural networks*. ICASSP [213].
- **Prioridad**: 🔥 Esencial

### 17.3 Probabilidad de Dropout Recurrente y de Capas (`dropout`)
- **Modelo(s)**: SimpleRNN, LSTM, GRU [246, 247].
- **Nivel**: Intermedio
- **Qué controla**: Define la fracción de neuronas ocultas de las capas de SimpleRNN, LSTM o GRU que se desactivarán de forma aleatoria en el proceso de entrenamiento secuencial para inyectar robustez y regularización estructural (stochastic regularization) [246, 247].
- **Valores típicos**: Rango continuo de `[0.1, 0.2, 0.3, 0.4]` [113, 246, 247]. Default en keras = `0.0` (sin desactivación).
- **Qué pasa si es muy alto**: (e.g. `dropout >= 0.5`). Desactiva una fracción de neuronas recurrentes excesiva, impidiendo que el modelo recurrente secuencial capte las dependencias temporales reales del sistema físico y conduciendo a subajuste del modelo [246].
- **Qué pasa si es muy bajo**: (e.g. `dropout = 0.0`, el default). El modelo recurrente carecerá de regularización estocástica, permitiendo al conexionismo recurrente sobreajustar en exceso el ruido local del dataset [192, 246].
- **Interacción con otros hiperparámetros**: Su sintonía de regularización es complementaria a la sintonía del número de capas recurrentes (`num_layers`) [246].
- **Estrategia de tuning recomendada**: Configurar de forma estándar un valor de `0.2` o `0.3` para inyectar diversidad espacial y agilizar enormemente la generalización del conexionismo recurrente [246, 247].
- **Error común**: No comprender la diferencia entre `dropout` clásico de capas y `recurrent_dropout` (que se aplica de forma secuencial en las conexiones internas de recurrencia), provocando que este último ralentice de forma extrema el entrenamiento en GPUs al no poder usar kernels optimizados de NVIDIA cuDNN.
- **Aplicación práctica industrial**: *Minería / Automatización de Procesos*. Predicción mensual del consumo de agua industrial en base a telemetría de sensores de planta. Un `dropout=0.2` en una red LSTM recurrente inyecta robustez en el Gradient Boosting secuencial, filtrando comportamientos de ruido de fondo instrumentales de planta [491].
- **Referencia**: Gal, Y., & Ghahramani, Z. (2016). *A theoretically grounded application of dropout in recurrent neural networks*. Advances in Neural Information Processing Systems [213, 255].
- **Prioridad**: ⚡ Importante

### 17.4 Recurrencia en Ambos Sentidos Temporales (`bidirectional`)
- **Modelo(s)**: Bidirectional(LSTM), Bidirectional(GRU) [213].
- **Nivel**: Avanzado
- **Qué controla**: Define si el procesamiento de la secuencia temporal se realizará en ambos sentidos temporales (hacia adelante y hacia atrás de forma paralela en dos capas recurrentes independientes) para consolidar un estado latente enriquecido por el contexto futuro y pasado [213], o si por el contrario la recurrencia se limitará estrictamente al sentido temporal secuencial clásico hacia adelante.
- **Valores típicos**: Booleano: `True` o `False`. Default en keras = `False`.
- **Qué pasa si es muy alto**: N/A.
- **Qué pasa si es muy bajo**: Si se desactiva (`bidirectional=False`), el modelo recurrente carecerá de la capacidad de evaluar de forma prospectiva las series de tiempo del dataset, perdiendo precisión en problemas de procesamiento de texto (NLP) de informes de averías de la planta.
- **Interacción con otros hiperparámetros**: Duplica de forma exacta el número de parámetros libres de entrenamiento de la capa recurrente y la dimensión de salida concatenada resultante: \(2 \times \text{hidden_size}\) [213].
- **Estrategia de tuning recomendada**: Usar de forma estándar `bidirectional=True` exclusivamente en problemas de procesamiento de lenguaje natural (NLP) o series de tiempo exógenas consolidadas donde el contexto futuro e histórico sea relevante [213].
- **Error común**: Configurar `bidirectional=True` en modelos en vivo de pronóstico predictivo en tiempo real (forecasting), provocando fuga de datos de validación cruzada y violando la causalidad del sistema al simular que se cuenta con el futuro en vivo.
- **Aplicación práctica industrial**: *Minería / Mantenimiento*. Clasificación del modo de falla de motores gigantescos a partir del texto de bitácoras de informes mecánicos semanales históricos. El uso de `bidirectional=True` sobre la capa de embeddings permite al modelo capturar de forma exacta el contexto semántico de los informes, optimizando el despacho de repuestos [472, 511].
- **Referencia**: Schuster, M., & Paliwal, K. K. (1997). *Bidirectional recurrent neural networks*. IEEE Transactions on Signal Processing [213].
- **Prioridad**: 💡 Opcional

## 18. Transformers (atención, positional encoding)

La arquitectura Transformer procesa secuencias de datos tabulares, series de tiempo o texto utilizando mecanismos de auto-atención multi-cabezal paralelos, prescindiendo de la recurrencia secuencial clásica mediante el uso de codificaciones posicionales espaciales [252, 283, 492].

### 18.1 Dimensión de los Embeddings e Capas Ocultas (`d_model`)
- **Modelo(s)**: TransformerEncoder, TransformerDecoder [283, 492].
- **Nivel**: Básico
- **Qué controla**: Define la dimensión matemática y espacial de los vectores de representación de embeddings e capas ocultas que se propagan a través de los bloques jerárquicos del Transformer [252, 283, 492]. Controla el grado de granularidad y la capacidad de la red para codificar características espaciales complejas del sistema [283, 492].
- **Valores típicos**: Enteros: `[64, 128, 256, 512, 768]` [252, 283, 492]. Default en BERT = `768` [252], en arquitecturas pequeñas de planta = `128` o `256`.
- **Qué pasa si es muy alto**: (e.g. `d_model >= 1024`). Multiplica de forma drástica la cantidad de pesos libres de entrenamiento del modelo de forma redundante y provoca sobreajuste severo en validación cruzada [192]. Además, incrementa de forma exponencial el costo computacional de cálculo de las matrices de atención de la GPU [283].
- **Qué pasa si es muy bajo**: (e.g. `d_model <= 32`). El modelo sufrirá de subajuste, siendo incapaz de capturar la riqueza semántica y las relaciones no lineales complejas entre los sensores continuos de la planta [3, 24].
- **Interacción con otros hiperparámetros**: Debe ser estrictamente un múltiplo exacto de la cantidad de cabezales de atención paralelizados (`nhead`) para permitir la división matemática equitativa de las subdimensiones espaciales: \(d_k = d_{\text{model}} / \text{nhead}\) [283, 492].
- **Estrategia de tuning recomendada**: Búsqueda en cuadrícula en un rango acotado combinando la estructura y cantidad de neuronas. Un valor de `256` o `512` suele converger de forma óptima en series de tiempo de planta [192].
- **Error común**: Diseñar transformadores gigantescos de gran tamaño sobre datasets tabulares pequeños de planta, sobreajustando el modelo secuencial.
- **Aplicación práctica industrial**: *Minería / Procesamiento*. Procesamiento inteligente de miles de informes de averías de motores a gran escala para predecir modos de falla mecánicas. Configurar una dimensión de `d_model=256` permite al Transformer capturar de forma exacta la riqueza semántica de las descripciones, optimizando el despacho de repuestos [492, 531].
- **Referencia**: Vaswani, A. et al. (2017). *Attention is all you need*. Advances in Neural Information Processing Systems [492].
- **Prioridad**: 🔥 Esencial

### 18.2 Cantidad de Cabezales de Auto-Atención Paralelos (`nhead`)
- **Modelo(s)**: MultiHeadAttention [283, 492].
- **Nivel**: Básico
- **Qué controla**: Define cuántos subprocesos independientes y paralelos de auto-atención (cabezales de atención) calcularán de forma paralela en la capa de atención [283, 492]. Esto permite a la red proyectar los vectores de consulta (Query), clave (Key) y valor (Value) en diferentes subespacios de representación, capturando de forma simultánea múltiples tipos de relaciones y dependencias espaciales lejanas de la secuencia de entrada [283, 492].
- **Valores típicos**: Enteros: `[4, 8, 12, 16]` [252, 283, 492]. Default en BERT = `12` [252], en arquitecturas pequeñas de planta = `8` [252].
- **Qué pasa si es muy alto**: (e.g. `nhead >= 32`). Fragmenta la dimensión de los embeddings (`d_model`) en subespacios de dimensiones excesivamente pequeñas y estériles, impidiendo que cada cabezal individual recopile suficiente señal de generalización de la red profunda [283].
- **Qué pasa si es muy bajo**: (e.g. `nhead = 1`, que equivale a atención simple). El modelo perderá la capacidad de capturar de forma simultánea múltiples relaciones lógicas complementarias en la secuencia, reduciendo la flexibilidad no lineal de la capa de atención de la red profunda [283, 492].
- **Interacción con otros hiperparámetros**: Enlazado estrictamente con `d_model` [492].
- **Estrategia de tuning recomendada**: Usar de forma estándar `nhead = 8` o `12` en la práctica industrial para garantizar la correcta reducción de varianza del conexionismo profundo de planta [252].
- **Error común**: Intentar sintonizar valores de `nhead` que no dividan de forma exacta a `d_model`, provocando errores lógicos de dimensiones matemáticas en las capas internas del Transformer [492].
- **Aplicación práctica industrial**: *Minería / Procesamiento de Mineral*. Pronóstico a gran escala de la demanda de mineral de múltiples plantas de chancado en paralelo mediante redes Temporal Fusion Transformer (TFT). Un `nhead=8` en la capa de auto-atención secuencial del Transformer permite capturar la ciclicidad compleja de la demanda de cemento de forma estable [537].
- **Referencia**: Vaswani, A. et al. (2017). *Attention is all you need* [492].
- **Prioridad**: 🔥 Esencial

### 18.3 Dimensión de la Capa de Proyección de Alimentación hacia Adelante (`dim_feedforward` o `d_ff`)
- **Modelo(s)**: TransformerEncoderLayer, TransformerDecoderLayer [492].
- **Nivel**: Intermedio
- **Qué controla**: Define la cantidad de neuronas artificiales del bloque densamente conectado de alimentación hacia adelante (Position-Wise Feed-Forward Network) que procesa de forma individual cada una de las posiciones de la secuencia de salida de la auto-atención [492]. Actúa para proyectar los vectores intermedios de atención en un espacio de mayor dimensión antes de la compresión final [492].
- **Valores típicos**: Enteros: `[128, 256, 512, 1024, 2048]` [252, 283, 492]. Default en scikit-learn/keras = `2048`, en arquitecturas pequeñas de planta = `512` o `1024`.
- **Qué pasa si es muy alto**: (e.g. `dim_feedforward >= 4096`). Provoca un sobreajuste secuencial extremo de los oblivious trees del gradiente, además de prolongar drásticamente el tiempo de entrenamiento de la CPU.
- **Qué pasa si es muy bajo**: (e.g. `dim_feedforward <= 128`). El modelo sufrirá de subajuste, siendo incapaz de realizar proyecciones complejas no lineales entre los sensores de planta.
- **Interacción con otros hiperparámetros**: Sintonizar un `dim_feedforward` adecuado equilibra la capacidad de regularización del Dropout en las capas internas del Transformer [492].
- **Estrategia de tuning recomendada**: Por regla general, configurar un valor de \(\text{dim_feedforward} = 2 \times d_{\text{model}}\) o \(4 \times d_{\text{model}}\).
- **Error común**: Configurar valores elevados de `dim_feedforward` en combinación con tasas de aprendizaje elevadas, provocando un desbordamiento de la memoria RAM del servidor de producción y deteniendo el proceso de reentrenamiento automático.
- **Aplicación práctica industrial**: *Siderúrgica / Procesos*. Predicción de fallas operacionales por fatiga en revestimiento interno de horno en base a telemetría de sensores continuos térmicos de planta mediante redes Temporal Fusion Transformer (TFT). Un `dim_feedforward=512` regulariza de forma robusta las predicciones diarias [537].
- **Referencia**: Documentación oficial de PyTorch (Transformer Layers) [491, 492].
- **Prioridad**: ⚡ Importante

### 18.4 Tasa de Dropout en Bloque Transformer (`dropout`)
- **Modelo(s)**: TransformerEncoderLayer, TransformerDecoderLayer [492].
- **Nivel**: Intermedio
- **Qué controla**: Define la fracción de neuronas ocultas de las capas de auto-atención y de alimentación hacia adelante (Position-Wise Feed-Forward Network) que se desactivarán de forma aleatoria en el proceso de entrenamiento secuencial para inyectar robustez y regularización estructural (stochastic regularization) [246, 247, 492].
- **Valores típicos**: Rango continuo de `[0.1, 0.2, 0.3]` [113, 246, 247]. Default en keras = `0.1` [492].
- **Qué pasa si es muy alto**: (e.g. `dropout >= 0.4`). Desactiva una fracción de neuronas excesiva, impidiendo que el modelo recurrente secuencial capte las dependencias temporales reales del sistema físico y conduciendo a subajuste del modelo [246].
- **Qué pasa si es muy bajo**: (e.g. `dropout = 0.0`). El modelo Transformer carecerá de regularización estocástica, permitiendo al conexionismo profundo sobreajustar en exceso el ruido local del dataset de planta [192].
- **Interacción con otros hiperparámetros**: Su sintonía de regularización es complementaria a la sintonía del número de capas del Transformer [246].
- **Estrategia de tuning recomendada**: Configurar de forma estándar un valor de `0.1` o `0.2` para inyectar diversidad espacial y agilizar enormemente la generalización del conexionismo profundo [246, 247].
- **Error común**: Ignorar este parámetro en transformadores entrenados sobre datos ruidosos de sensores de planta, permitiendo sobreajuste masivo invisible para el científico de datos [192].
- **Aplicación práctica industrial**: *Siderúrgica / Calidad*. Predicción de fallas mecánicas por fatiga en base a telemetría de sensores continuos de planta mediante redes Temporal Fusion Transformer (TFT). Un `dropout=0.1` regulariza de forma robusta las predicciones diarias [490, 529].
- **Referencia**: Vaswani, A. et al. (2017). *Attention is all you need* [492].
- **Prioridad**: ⚡ Importante

## Hiperparámetros de Entrenamiento Transversales

Existen ciertos parámetros fundamentales que regulan el entrenamiento de múltiples familias de modelos de machine learning y deep learning. Su comprensión es clave para garantizar la reproducibilidad y optimizar el hardware [140, 192, 544].

### Semilla de Aleatoriedad (`random_state` o `seed`)
- **Modelos**: Ridge, Lasso, ElasticNet, LogisticRegression, DecisionTree, RandomForest, GradientBoosting, XGBoost, LightGBM, CatBoost, K-Means, MLP, etc [104, 114, 150, 196].
- **Qué controla**: Define el punto de partida (semilla numérica de inicialización) para los generadores de números pseudoaleatorios del sistema de cómputo [150, 544]. Garantiza de forma estricta que procesos estocásticos (como la partición bootstrap del bagging, la aleatorización de variables en divisiones de nodos o la inicialización de pesos de las capas de redes neuronales) generen exactamente los mismos resultados numéricos idénticos bit a bit en ejecuciones independientes [105, 150, 544].
- **Valores típicos**: Enteros: `42` (el estándar por excelencia de la cultura geek), `0`, `1234` [114, 150, 189].
- **Estrategia recomendada**: Fijar siempre un `random_state` único global al inicio de todos los experimentos y reentrenamientos en producción para asegurar la trazabilidad absoluta de las predicciones del modelo en el reentrenamiento semanal de planta [150, 539, 544].
- **Prioridad**: 🔥 Esencial

### Hilos de Cómputo Paralelo (`n_jobs` o `num_threads`)
- **Modelos**: KNN, RandomForest, SGDClassifier, GridSearchCV, etc [100, 114, 126, 156, 198].
- **Qué controla**: Especifica la cantidad máxima de procesadores de CPU que el algoritmo de scikit-learn o XGBoost puede paralelizar y utilizar de forma simultánea para entrenar los árboles del ensamble en paralelo o calcular distancias vectoriales espaciales [114, 126, 156].
- **Valores típicos**: Enteros: `1`, `4`, `8` o `-1` (que indica utilizar todos los procesadores de CPU disponibles físicamente en el servidor de planta) [114, 126, 156, 198].
- **Estrategia recomendada**: Configurar `n_jobs=-1` por defecto durante búsquedas de cuadrícula o entrenamiento de bosques aleatorios de Random Forest en la CPU del servidor de planta para acelerar la velocidad del proceso [114, 156, 198].
- **Prioridad**: 🔥 Esencial

### Nivel de Salida de Registro (`verbose`)
- **Modelos**: SGDClassifier, SVC, RandomForest, MLP, K-Means, etc [98, 114].
- **Qué controla**: Define el nivel de granularidad con el que el algoritmo imprimirá los registros de progreso del optimizador secuencial de gradientes estocásticos, las métricas de entrenamiento de cada época o los detalles internos del proceso de convergencia en la consola de salida [114].
- **Valores típicos**: Enteros: `0` (silencio completo, ideal para producción), `1` (imprime métricas esenciales por época), `2` (imprime detalles internos numéricos) [114].
- **Estrategia recomendada**: Configurar `verbose=1` durante experimentos y exploración preliminar de modelos costosos en la CPU de planta para diagnosticar atascos en el entrenamiento, y silenciar `verbose=0` en producción para no saturar los registros del servidor FastAPI [541].
- **Prioridad**: ⚡ Importante

### Ponderación de Clases Desbalanceadas (`class_weight` o `scale_pos_weight`)
- **Modelos**: LogisticRegression, SVC, RandomForest, XGBoost, LightGBM, CatBoost [104, 105, 198, 249].
- **Qué controla**: Coeficiente multiplicador de la pérdida aplicado directamente sobre las muestras de la clase menor en el funcional de optimización para equilibrar el peso de las clasificaciones erróneas [104, 249].
- **Valores típicos**: `'balanced'` (ajusta de forma inversa al desbalance de clases de forma nativa en scikit-learn) [104, 105, 198], o valores numéricos calculados flotantes [249, 250]. Default = `None` (igual peso a todas las muestras).
- **Estrategia recomendada**: Configurar `'balanced'` o utilizar `scale_pos_weight = total_negativas / total_positivas` en XGBoost si se enfrenta a datasets con un alto desbalance de clases del negocio (e.g. anomalías o fraudes), forzando al clasificador a enfocarse en los eventos raros críticos del negocio [249, 466].
- **Prioridad**: 🔥 Esencial

### Parada Temprana (`early_stopping` o `n_iter_no_change`)
- **Modelos**: GradientBoosting, XGBoost, LightGBM, CatBoost, MLP [192, 226, 249].
- **Qué controla**: Mecanismo de regularización que detiene el entrenamiento secuencial de nuevos árboles o épocas una vez que el error obtenido en un subconjunto de datos de validación cruzada independiente no muestra mejoras significativas durante un número consecutivo de rondas [192, 249].
- **Valores típicos**: Enteros: `5`, `10`, `20`, `50` [192, 249]. Default = `None` (sin parada).
- **Estrategia recomendada**: Utilizar siempre en la práctica industrial para ahorrar recursos de cómputo y evitar de forma matemática el sobreajuste secuencial de los árboles secuenciales del gradiente [192, 309].
- **Prioridad**: 🔥 Esencial

### Tasa de Aprendizaje Dinámica (Schedules)
- **Modelos**: Redes Neuronales (MLP, CNN, LSTM, Transformers), optimizadores de Deep Learning [140, 192].
- **Qué controla**: Define la ley o la función matemática secuencial utilizada para disminuir de forma paulatina el valor del paso del optimizador (`learning_rate`) a medida que avanzan las épocas de entrenamiento (e.g., decaimiento exponencial, coseno recocido o regla '1cycle') [192, 414].
- **Valores típicos**: `'constant'`, `'invscaling'`, `'adaptive'` (scikit-learn) [187, 189], o funciones continuas complejas de reducción.
- **Estrategia recomendada**: Utilizar decaimiento adaptativo o de coseno recocido para asegurar que el optimizador reduzca su impaciencia secuencial sobre el gradiente en las fases finales del entrenamiento, asentando los pesos en el mínimo global sin oscilar de forma inestable.
- **Prioridad**: ⚡ Importante

### Tamaño del Lote de Entrenamiento (`batch_size`)
- **Modelos**: Redes Neuronales (MLP, CNN, LSTM, Transformers), optimizadores de primer orden a gran escala [140, 192].
- **Qué controla**: Define cuántas observaciones individuales de entrenamiento se procesarán en secuencia para acumular los gradientes antes de que el optimizador realice una única actualización del vector de pesos (pesos y sesgos) de la red profunda [140, 192].
- **Valores típicos**: Potencias de dos: `[16, 32, 64, 128, 256, 512]` [181, 412]. Default en Keras = `32` [412].
- **Estrategia recomendada**: Usar `batch_size = 32` o `64` como óptimo estándar para inyectar suficiente variabilidad de gradiente y regularizar el conexionismo profundo [181]. Incrementar de forma lineal si se cuenta con hardware de GPU de gran tamaño y se busca acelerar el proceso computacional [192].
- **Prioridad**: ⚡ Importante

### Cantidad de Épocas de Entrenamiento (`epochs`)
- **Modelos**: Redes Neuronales (MLP, CNN, LSTM, Transformers) [192, 247].
- **Qué controla**: Define la cantidad total de pasadas completas que el optimizador de primer orden tiene permitido realizar sobre el conjunto total de observaciones del dataset de entrenamiento al entrenar [140, 247].
- **Valores típicos**: `[10, 50, 100, 200, 500]` [115, 247].
- **Estrategia recomendada**: Configurar un valor alto (e.g. `200` o `500`) y habilitar la parada temprana (`EarlyStopping` en Keras/PyTorch) monitoreando la pérdida de validación cruzada para detener de forma segura el conexionismo profundo [192].
- **Prioridad**: ⚡ Importante

### Algoritmo de Optimización de Pesos (SGD, Adam, AdamW)
- **Modelos**: Redes Neuronales (MLP, CNN, LSTM, Transformers) [1, 140].
- **Qué controla**: Especifica la fórmula del optimizador de primer orden encargada de actualizar de forma iterativa las matrices de pesos y sesgos de la red conexionista para minimizar el funcional de pérdida total [1, 140, 489].
- **Valores típicos**: `['sgd', 'adam', 'adamw', 'rmsprop']` [1, 140, 489]. Default en scikit-learn = `'adam'`.
- **Estrategia recomendada**: Usar `'adamw'` (Adam con desacoplamiento de decaimiento de pesos) por defecto para el entrenamiento estable de redes complejas, ya que combina la adaptabilidad local del gradiente por coordenada de Adam con la correcta penalización L2 estructurada sin distorsionarla [489].
- **Prioridad**: 🔥 Esencial

### Regularización Profunda (Dropout, BatchNorm, Regularizadores L1/L2)
- **Modelos**: Redes Neuronales (MLP, CNN, LSTM, Transformers) [1, 192].
- **Qué controla**: Técnicas de regularización aplicadas de forma integrada en el flujo de la red para mitigar el sobreajuste del conexionismo profundo de millones de parámetros libres [1, 192, 246].
  - **L1/L2**: Penalizaciones matemáticas directas aplicadas en los pesos de las capas individuales (`kernel_regularizer`) [1, 246].
  - **Dropout**: Capa estocástica que desactiva de forma aleatoria una porción de neuronas durante el entrenamiento, simulando un ensamble aditivo de arquitecturas y previniendo la coadaptación de variables [1, 246].
  - **BatchNorm**: Normaliza dinámicamente los mapas de activación intermedios de cada minilote, acelerando drásticamente el proceso de convergencia y actuando como un regularizador indirecto leve [1, 192].
- **Estrategia recomendada**: Integrar de forma estándar capas de BatchNorm antes de las activaciones no lineales en redes profundas para agilizar la convergencia, y añadir capas de Dropout (`0.1` a `0.3`) después de capas complejas con alta densidad de parámetros libres para inyectar inmunidad al sobreajuste [1, 192, 246].
- **Prioridad**: 🔥 Esencial

## Flujo de Tuning Universal

El proceso de optimización de hiperparámetros (hyperparameter tuning) en un proyecto real de ciencia de datos debe seguir una progresión metodológica estructurada para evitar desperdicio de recursos, evitar el sesgo por fuga de información (data leakage) y garantizar la reproducibilidad y estabilidad de las predicciones en producción [11, 202, 544].

### Paso 1: Configurar un Esquema de Validación Robusto y Seguro
- **Acción**: Separar de forma estricta un conjunto de datos de prueba final (Test Set) al inicio del proyecto (típicamente entre el 15% y 25% del total de las observaciones) [299]. Este conjunto se mantendrá intacto en un cofre sellado de seguridad y solo se evaluará exactamente una sola vez sobre el modelo final ganador seleccionado antes de lanzar a producción [201].
- **Estrategia**: Definir la estrategia de validación interna cruzada (Validation Scheme) según la naturaleza física de los datos del proceso [467, 506]:
  - Si el dataset de la planta posee marcas de tiempo continuas o dependencias temporales cíclicas (series de tiempo), utilizar estrictamente un esquema de validación temporal secuencial (`TimeSeriesSplit`) para evitar inyectar información del futuro al pasado [190].
  - Si el dataset presenta clases altamente desbalanceadas (como anomalías operacionales o eventos raros), utilizar validación cruzada estratificada (`StratifiedKFold`) para mantener la proporción exacta de clases linderas en cada pliegue [155, 247].
  - Si los datos provienen de grupos discretos identificables de maquinaria o clientes específicos, utilizar validación cruzada por grupos (`GroupKFold`) para evaluar la capacidad del clasificador de generalizar de forma robusta sobre grupos nunca vistos [467, 506].

### Paso 2: Ejecutar una Línea Base Simple (Baselines)
- **Acción**: Entrenar un modelo de base sumamente rápido y simple utilizando los parámetros por defecto del sistema (e.g. un árbol CART de profundidad limitada, una regresión logística Ridge simple o un clasificador Naive Bayes) [91, 131, 210, 474].
- **Métrica**: Evaluar de forma preliminar el error empírico obtenido en validación y entrenamiento [10, 415]. Si el error de validación y de entrenamiento son ambos elevados de forma idéntica, el modelo base está sufriendo de subajuste (sesgo alto), indicando que se requiere inyectar características no lineales adicionales o emplear familias de modelos de mayor complejidad [415].

### Paso 3: Definir un Espacio de Búsqueda de Hiperparámetros Acotado
- **Acción**: Identificar cuáles son las variables del modelo predictivo que poseen la mayor influencia sobre la performance predictiva y el tiempo computacional [192, 217, 309]. Definir rangos gruesos exponenciales de búsqueda basados en el conocimiento de la física del modelo (e.g. para `C` en SVM, probar magnitudes de `[0.1, 1.0, 10.0, 100.0]`) [73, 202].

### Paso 4: Seleccionar el Algoritmo de Búsqueda Óptimo
- **GridSearch**: Utilizar exclusivamente si el espacio de búsqueda es sumamente reducido (menos de 10 combinaciones totales simultáneas) o si se busca un rastreo sistemático exhaustivo [328, 363].
- **RandomizedSearch**: El estándar por excelencia para la gran mayoría de problemas de machine learning [418]. Al muestrear combinaciones al azar de distribuciones continuas, RandomizedSearch explora de forma drásticamente superior y más veloz el espacio de hiperparámetros que una cuadrícula estática rígida, logrando mejores resultados en una fracción de tiempo computacional [418].
- **Optimización Bayesiana (Optuna, Hyperopt)**: Indispensable para modelos costosos de entrenar en el hardware de planta, como redes profundas MLP, XGBoost o LightGBM sobre millones de observaciones [192, 224, 483]. Al utilizar un modelo sustituto probabilístico (Proceso Gaussiano o TPE) para guiar inteligentemente la selección de combinaciones basándose en los resultados de los pasos previos, la optimización bayesiana converge de forma asombrosa al mínimo global en menos del 20% de las iteraciones requeridas por otros métodos [220, 483, 522].

### Paso 5: Ejecutar la Búsqueda y Refinar en Escala Fina
- **Acción**: Ejecutar la búsqueda seleccionada en la CPU / GPU de planta paralelizando con `n_jobs=-1` [126, 156, 198]. Una vez identificada la región del espacio donde se minimiza el error de validación, redefinir un nuevo espacio de búsqueda estrecho y lineal (escala fina) concentrado exclusivamente alrededor de ese mínimo local óptimo detectado para pulir los decimales de los hiperparámetros de planta [202, 392].

### Paso 6: Validar en el Set de Prueba y Desplegar
- **Acción**: Tomar el modelo final ganador con los hiperparámetros óptimos sintonizados de la escala fina y reentrenarlo sobre el 100% de los datos de entrenamiento y validación cruzada combinados [329]. Evaluar este modelo unificado final exactamente una sola vez sobre el set de prueba final reservado en el Paso 1 [201]. Si la métrica obtenida coincide con el error estimado de validación de forma estable, felicidades: su modelo posee una capacidad matemática de generalización óptima y robusta y está listo para ser desplegado en producción [201].

---

Esta guía constituye la especificación técnica definitiva para la configuración científica de modelos en los entornos de producción de la planta, asegurando la reproducibilidad, la interpretabilidad por parte de los ingenieros y el óptimo desempeño del negocio [544].
