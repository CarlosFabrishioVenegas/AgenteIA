import logging
logger = logging.getLogger("virf.mx01")
"""
Mx_01_LecturaEvidencias.py
===========================
Lectura y extracción de texto de todas las fuentes de evidencia:
  - PDF, DOCX, PPTX, XLSX, PY, JSON, TXT, MD, IPYNB, SQL
  - Compilación por carpeta de control
  - Compilación por modelo (conocimiento)
  - Detección automática de manual vs script por scoring

Responsabilidades:
  - Leer archivos individuales por tipo
  - Leer carpetas recursivamente (evidencia, conocimiento)
  - Detectar el "mejor" manual y script por scoring de nombres
  - Compilar evidencia por control y por modelo
  - Crear CSV de parámetros de ejecución
"""

import csv
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Tuple, Dict, Any

from Mx_00_CargaRutas import (
    MAX_CHARS_DOC, MAX_CHARS_CODIGO, MAX_FILAS_EXCEL,
    AMBITO_A_INPUTS, RUTAS,
    CACHE_ENABLED, CACHE_DIR,
)

# ─── Sistema de caché de documentos (v15/v17) ─────────────────────────────────
# CRÍTICO: importamos desde 'modulos.document_cache' (no desde 'document_cache')
# para que tanto agente.py como Mx_01 compartan el MISMO objeto de módulo en
# sys.modules y por tanto la misma _instancia_global del caché.
import sys as _sys
_base_path = str(Path(__file__).parent.parent)   # → virf_mejorado/
if _base_path not in _sys.path:
    _sys.path.insert(0, _base_path)

try:
    from modulos.document_cache import get_cache, DocumentCache   # clave: 'modulos.document_cache'
    _CACHE_DISPONIBLE = True
except ImportError:
    _CACHE_DISPONIBLE = False
    def get_cache():   # noqa: E302
        return None

# Constantes de carpetas
EVIDENCIA_FOLDER = "Evidencias"
CONOCIMIENTO_FOLDER = "Conocimiento"


# ─── Lectores por tipo de archivo ─────────────────────────────────────────────

# ── [AUDIT-FIX] Marca de LECTURA FALLIDA ─────────────────────────────────────
# Los lectores devolvían su mensaje de error COMO CONTENIDO, y `leer_archivo`
# lo trataba como texto normal: cobertura_pct=100 sobre un "[Error OCR ...]".
# Medido: un PDF corrupto entraba al pipeline como evidencia con sello de
# cobertura completa, y D3-FIX no lo rechazaba porque "había contenido".
# Ahora esos mensajes se prefijan con esta marca; `leer_archivo` la detecta,
# pone la cobertura a 0 y marca `lectura_fallida=True`.
_MARCA_LECTURA_FALLIDA = "⛔LECTURA-FALLIDA⛔"


def _leer_pdf(path: Path) -> str:
    """
    Lee texto de un PDF **digital**. Dos vías: pdfminer y, si falla, PyPDF2.

    ── POR QUÉ YA NO HAY OCR ────────────────────────────────────────────────
    [POLÍTICA 2026-07-30] Había un tercer intento con `pytesseract` +
    `pdf2image` para PDFs escaneados. Se retiró por la misma política que
    apartó a `sentence-transformers`: la entidad no admite ejecutar modelos
    ajenos a Azure OpenAI, y Tesseract es un motor de reconocimiento propio
    con sus modelos de lenguaje (`spa`, `eng`).

    ── QUÉ SE PIERDE, Y POR QUÉ NO SE PIERDE EN SILENCIO ────────────────────
    Un PDF escaneado —un acta firmada y digitalizada, un manual antiguo— ya no
    se puede leer. Eso NO se disimula: se devuelve la marca de lectura fallida,
    que pone la cobertura a 0 y marca `lectura_fallida=True`.

    Esa distinción es el invariante 3 del proyecto: «no se pudo leer» es un
    fallo TÉCNICO del agente, no una falta del validado. Si el fichero saliera
    con texto vacío y cobertura 100 %, el ámbito puntuaría 0.0 y el informe
    culparía al modelador de no aportar un documento que sí aportó.

    ── QUÉ HACER CON UN PDF ESCANEADO ───────────────────────────────────────
    Convertirlo a texto ANTES de dejarlo en `inputs/`: exportar desde el
    origen, pedir el original digital, o usar la herramienta de OCR que la
    entidad tenga aprobada. La conversión deja de ser responsabilidad del
    agente y pasa a ser parte de la preparación de la evidencia — donde además
    queda bajo el control de quien la aporta.
    """
    texto = ""

    # Intento 1: pdfminer (PDFs digitales)
    #
    # [RUIDO-FIX 2026-07-30] pdfminer emite por logging avisos como
    # «Could not get FontBBox from font descriptor» en PDFs perfectamente
    # legibles: son fuentes incrustadas sin metadatos de caja, y NO afectan al
    # texto extraído. Inundaban la consola durante el chunking de un manual
    # largo y enterraban los avisos que SÍ importan —cobertura parcial, lectura
    # fallida—, que es el daño real: un aviso relevante que nadie ve equivale a
    # no haberlo emitido.
    #
    # Se silencia el logger de pdfminer, no los `warnings` de Python: el
    # segundo apagaría también avisos de otras librerías.
    import logging as _logging
    for _nombre in ("pdfminer", "pdfminer.pdffont", "pdfminer.pdfinterp",
                    "pdfminer.pdfpage", "pdfminer.layout", "pdfminer.cmapdb"):
        _logging.getLogger(_nombre).setLevel(_logging.ERROR)

    try:
        from pdfminer.high_level import extract_text
        texto = extract_text(str(path)) or ""
    except ImportError:
        pass
    except Exception as _exc:
        # Un PDF con extracción PROHIBIDA por metadatos sí importa: no es ruido,
        # es evidencia que no se va a poder leer. Se distingue del fallo
        # genérico para que el mensaje final lo explique.
        if "not allow" in str(_exc).lower() or "extraction" in str(_exc).lower():
            logger.warning("'%s': el PDF declara que NO permite extracción de "
                           "texto.", path.name)

    # Intento 2: PyPDF2 (fallback digital)
    if not texto.strip():
        try:
            import PyPDF2
            parts = []
            with open(path, "rb") as f:
                for page in PyPDF2.PdfReader(f).pages:
                    t = page.extract_text()
                    if t:
                        parts.append(t)
            texto = "\n".join(parts)
        except ImportError:
            pass
        except Exception:
            pass

    # Sin texto tras las dos vías digitales: es un PDF escaneado (o corrupto).
    # Se DECLARA como lectura fallida — nunca como documento vacío.
    if not texto.strip():
        return (
            f"{_MARCA_LECTURA_FALLIDA}"
            f"[⚠️ PDF SIN TEXTO EXTRAÍBLE: {path.name}\n"
            f" Probablemente es un documento ESCANEADO (una imagen).\n"
            f" El OCR se retiró por política: el agente no ejecuta modelos "
            f"externos.\n"
            f" QUÉ HACER: aporta este documento en formato digital, o conviértelo\n"
            f" a texto con la herramienta de OCR aprobada por tu entidad antes de\n"
            f" dejarlo en inputs/.\n"
            f" Esto cuenta como FALLO TÉCNICO de lectura, no como falta de "
            f"evidencia.]"
        )

    return texto


def _leer_docx(path: Path) -> str:
    try:
        from docx import Document
        doc = Document(path)
        partes = []
        
        # Leer párrafos (más simple y robusto)
        for p in doc.paragraphs:
            if p.text.strip():
                partes.append(p.text.strip())
        
        # Leer tablas
        for table in doc.tables:
            for row in table.rows:
                celdas = [c.text.strip() for c in row.cells if c.text.strip()]
                if celdas:
                    partes.append(" | ".join(celdas))
        
        if not partes:
            return f"{_MARCA_LECTURA_FALLIDA}[Documento vacío o sin texto legible: {path.name}]"
        
        return "\n".join(partes)
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error leyendo {path.name}: {str(e)[:100]}]"


def _leer_pptx(path: Path) -> str:
    try:
        from pptx import Presentation
        partes = []
        for i, slide in enumerate(Presentation(path).slides, 1):
            txts = [
                s.text.strip()
                for s in slide.shapes
                if hasattr(s, "text") and s.text.strip()
            ]
            if txts:
                partes.append(f"[Slide {i}] " + " | ".join(txts))
        return "\n".join(partes)
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error PPTX {path.name}: {e}]"


def _leer_excel(path: Path, max_filas: int = 150) -> str:
    """
    [AUDIT-FIX] `df.head(max_filas)` recortaba EN SILENCIO. Medido con un XLSX
    de 10.000 filas: se leían 200 (el 2%), el texto no decía nada y el
    documento salía con `truncado=False` y cobertura 100%. El evaluador creía
    haber visto la tabla entera.

    `_leer_python` ya avisaba de su recorte con «[truncado a N chars]»; aquí
    faltaba. Ahora cada hoja declara cuántas filas se leyeron de cuántas.
    """
    try:
        import pandas as pd
        xf = pd.ExcelFile(path)
        partes = []
        for nombre in xf.sheet_names:
            df = xf.parse(nombre).dropna(how="all").fillna("")
            total = len(df)
            csv = df.head(max_filas).to_csv(index=False)
            cabecera = f"--- Hoja: {nombre} ---"
            if total > max_filas:
                cabecera += (
                    f"\n[⚠️ RECORTADO: se muestran las primeras {max_filas} de "
                    f"{total:,} filas ({max_filas * 100 // total}%). "
                    f"Las conclusiones sobre el conjunto completo NO son "
                    f"verificables con esta muestra. Subir MAX_FILAS_EXCEL "
                    f"para incluir más.]"
                )
            partes.append(f"{cabecera}\n{csv}")
        return "\n".join(partes)
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error Excel {path.name}: {e}]"


def _leer_python(path: Path, max_chars: Optional[int] = None) -> str:
    """
    Lee un fichero .py. Con `max_chars=None` (el default) devuelve el código
    ÍNTEGRO.

    [CODIGO-FIX 2026-07-30] Antes el default era 8000 y el truncado ocurría
    AQUÍ, dentro del lector. Eso lo situaba por debajo del TRUNCADO-FIX de
    `leer_archivo()`: cuando el chunking está activo, esa función entrega el
    texto íntegro al ChunkerService precisamente para que nada se pierda en
    silencio… pero para .py ya no había nada que entregar, porque el lector
    había recortado a 8.000 chars (≈200 líneas) antes de devolver.

    Consecuencia medida: `chars_totales` se calculaba sobre el texto YA
    recortado, así que un módulo de 40.000 chars se reportaba con
    `cobertura_pct = 100.0` habiendo perdido el 80%. Es el mismo defecto que
    el TRUNCADO-FIX eliminó para los PDF, vivo en la ruta del código.

    El tope duro sigue existiendo donde corresponde: `leer_archivo()` aplica
    MAX_CHARS_CODIGO cuando VIRF_CHUNK_ENABLED=0, es decir cuando no hay
    chunker detrás que cubra el resto.
    """
    try:
        code = path.read_text(encoding="utf-8", errors="replace")
        if max_chars is not None and len(code) > max_chars:
            code = code[:max_chars] + f"\n... [truncado a {max_chars} chars]"
        return code
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error .py {path.name}: {e}]"


# Tope por celda para los OUTPUTS de un notebook. No es configurable a
# propósito: un output puede ser una imagen en base64 de varios MB, y eso no es
# evidencia legible sino ruido que desplaza el código del contexto. El código y
# el markdown SÍ van íntegros.
_MAX_CHARS_OUTPUT_CELDA = 2000


def _leer_ipynb_completo(path: Path) -> str:
    """
    Lee un notebook Jupyter íntegro: celdas de código, markdown y un extracto
    acotado de los outputs.

    [CODIGO-FIX 2026-07-30] `.ipynb` NO estaba en LECTORES_EXT, así que
    `leer_archivo()` devolvía None y el fichero se omitía SIN AVISO en el
    pipeline completo. La incoherencia era doble, porque la instrucción que se
    inyecta al modelo para el ámbito Implementación pide literalmente
    comprobar «¿Las funciones documentadas en el manual existen en los scripts
    (.py, .ipynb)?» — se le exigía contrastar algo que el lector nunca le
    entregaba. El pipeline por CONTROL sí lo leía (`leer_archivo_generico`),
    de modo que el mismo notebook era visible o invisible según el pipeline.

    Por qué se incluyen los outputs: en una validación, que una celda haya
    corrido y con qué resultado ES evidencia. Un notebook entregado sin
    ejecutar es un hallazgo, y sin leer los outputs no se puede distinguir de
    uno ejecutado.
    """
    try:
        nb = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error IPYNB {path.name}: {e}]"

    partes: list = []
    n_code = n_ejecutadas = 0

    for idx, cell in enumerate(nb.get("cells", []), start=1):
        tipo = cell.get("cell_type", "")
        # `source` puede ser lista de líneas o un único string, según el editor
        # que guardó el notebook. Ambas formas son válidas en nbformat.
        src = cell.get("source", "")
        fuente = "".join(src) if isinstance(src, list) else str(src)

        if tipo == "code":
            n_code += 1
            ejec = cell.get("execution_count")
            marca = f"ejecutada #{ejec}" if ejec else "SIN EJECUTAR"
            if ejec:
                n_ejecutadas += 1
            partes.append(f"[CELDA {idx} · CÓDIGO · {marca}]\n{fuente}")
            texto_out = _extraer_outputs_celda(cell)
            if texto_out:
                partes.append(f"[CELDA {idx} · OUTPUT]\n{texto_out}")
        elif tipo == "markdown":
            partes.append(f"[CELDA {idx} · MARKDOWN]\n{fuente}")

    # Cabecera de trazabilidad: permite al modelo juzgar si el notebook se
    # ejecutó de verdad sin tener que contar celdas él mismo.
    cabecera = (
        f"[NOTEBOOK {path.name} — {n_code} celda(s) de código, "
        f"{n_ejecutadas} ejecutada(s)"
        + ("" if n_ejecutadas == n_code else
           f" · ⚠️ {n_code - n_ejecutadas} SIN EJECUTAR")
        + "]"
    )
    return cabecera + "\n\n" + "\n\n".join(partes)


def _extraer_outputs_celda(cell: dict) -> str:
    """Texto legible de los outputs de una celda, acotado y sin binarios."""
    trozos: list = []
    for out in cell.get("outputs", []) or []:
        tipo_out = out.get("output_type", "")
        if tipo_out == "stream":
            txt = out.get("text", "")
            trozos.append("".join(txt) if isinstance(txt, list) else str(txt))
        elif tipo_out in ("execute_result", "display_data"):
            data = out.get("data", {}) or {}
            if "text/plain" in data:
                txt = data["text/plain"]
                trozos.append("".join(txt) if isinstance(txt, list) else str(txt))
            # Las imágenes se DECLARAN pero no se vuelcan: un PNG en base64 son
            # cientos de miles de chars que el modelo no puede interpretar.
            for clave in data:
                if clave.startswith("image/"):
                    trozos.append(f"[{clave} omitida — no legible como texto]")
        elif tipo_out == "error":
            nombre = out.get("ename", "Error")
            valor = out.get("evalue", "")
            # Un traceback en un notebook entregado es un hallazgo por sí solo.
            trozos.append(f"⚠️ EXCEPCIÓN NO RESUELTA: {nombre}: {valor}")

    texto = "\n".join(t for t in trozos if t.strip())
    if len(texto) > _MAX_CHARS_OUTPUT_CELDA:
        texto = (texto[:_MAX_CHARS_OUTPUT_CELDA]
                 + f"\n... [output recortado a {_MAX_CHARS_OUTPUT_CELDA} chars]")
    return texto


def _leer_json(path: Path) -> str:
    try:
        return json.dumps(
            json.loads(path.read_text(encoding="utf-8")),
            ensure_ascii=False, indent=2
        )[:5000]
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error JSON {path.name}: {e}]"


LECTORES_EXT = {
    ".pdf":  lambda p: _leer_pdf(p),
    ".docx": lambda p: _leer_docx(p),
    ".doc":  lambda p: _leer_docx(p),
    ".pptx": lambda p: _leer_pptx(p),
    ".ppt":  lambda p: _leer_pptx(p),
    ".xlsx": lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".xls":  lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".xlsm": lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    # [CODIGO-FIX] Sin tope aquí: el código va íntegro y es leer_archivo() quien
    # aplica MAX_CHARS_CODIGO solo si el chunking está desactivado. Un modelo
    # puede tener sus propias librerías en subcarpetas (libs/, src/…) y
    # recortarlas a 200 líneas hacía imposible el contraste función a función
    # que pide el ámbito Implementación.
    ".py":   lambda p: _leer_python(p),
    ".ipynb": lambda p: _leer_ipynb_completo(p),
    # [CODIGO-FIX 2026-07-30, 2ª pasada] .sql y .r caían en el mismo agujero que
    # tenía .ipynb: no estaban registrados, así que `leer_archivo()` devolvía
    # None y el fichero se omitía SIN AVISO. En una entidad financiera el ETL
    # del modelo suele vivir en SQL y buena parte del modelado en R, de modo que
    # el agujero se tragaba justo la parte que más falta hace validar.
    #
    # La clave es `.r` en minúscula a propósito: `leer_archivo()` busca con
    # `path.suffix.lower()`, así que registrar ".R" no habría casado nunca y el
    # fichero habría seguido desapareciendo en silencio.
    ".sql":  lambda p: p.read_text(encoding="utf-8", errors="replace"),
    ".r":    lambda p: p.read_text(encoding="utf-8", errors="replace"),
    ".json": lambda p: _leer_json(p),
    # [v18] TXT/MD/CSV: sin límite artificial — se aplica chunking si son largos
    ".txt":  lambda p: p.read_text(encoding="utf-8", errors="replace"),
    ".md":   lambda p: p.read_text(encoding="utf-8", errors="replace"),
    ".csv":  lambda p: p.read_text(encoding="utf-8", errors="replace"),
}

# Extensiones que se tratan como CÓDIGO: comparten el tope MAX_CHARS_CODIGO
# cuando el chunking está apagado, y son las que alimentan la revisión módulo a
# módulo (modulos/revision_codigo.py).
#
# Todas en MINÚSCULA: la búsqueda se hace con `path.suffix.lower()`, así que una
# entrada ".R" no casaría jamás.
EXTENSIONES_CODIGO = frozenset({".py", ".ipynb", ".sql", ".r"})

# Lenguaje del bloque de código al presentar el fichero al modelo. Etiquetar un
# script de R como `python` invita al modelo a leerlo con la sintaxis
# equivocada y a "corregir" lo que no está roto.
LENGUAJE_POR_EXT = {
    ".py": "python", ".ipynb": "python", ".sql": "sql", ".r": "r",
}

# ─── Constantes de chunking ───────────────────────────────────────────────────
# [CONFIG-CENTRAL v27.2] Este bloque redeclaraba VIRF_CHUNK_SIZE / _OVERLAP /
# _THRESHOLD con los mismos defaults que modulos/chunker.py. Dos declaraciones
# independientes del mismo parámetro: si alguien tocaba una, la otra seguía con
# el valor viejo y el umbral de "documento largo" dejaba de coincidir con el
# tamaño de segmento real. Ahora ambos leen de config/parametros.py.
from config.parametros import (
    CHUNK_OVERLAP as _CHUNK_OVERLAP,
    CHUNK_SIZE as _CHUNK_SIZE,
    CHUNK_THRESHOLD as _CHUNK_THRESHOLD,
)


# [v20] _chunked_summary fue movida a modulos/chunker.py (ChunkerService).
# Mx_01 ya no llama a la IA — devuelve texto crudo para que el pipeline
# aplique chunking de forma centralizada y controlada.


def leer_archivo(path: Path) -> Optional[dict]:
    """
    Lee un archivo y retorna dict con el texto extraído SIN chunking.

    [v20] Esta función es ahora agnóstica a IA: devuelve el texto crudo
    truncado a max_chars (MAX_CHARS_DOC / MAX_CHARS_CODIGO) para documentos
    dentro del umbral, o el texto completo para que ChunkerService (en
    modulos/chunker.py) lo procese externamente.

    El chunking ya NO ocurre aquí — ocurre en agente.py después de leer
    todos los archivos, usando un ChunkerService con el cliente IA inyectado.

    Campos del dict retornado:
      nombre        (str):   nombre del archivo
      tipo          (str):   extensión en mayúsculas (PDF, DOCX, PY…)
      contenido     (str):   texto extraído (puede ser truncado si > max_chars)
      chars_totales (int):   longitud total del texto antes de truncar
      truncado      (bool):  True si chars_totales > max_chars (candidato a chunking)
      cobertura_pct (float): 100.0 si no truncado; <100 si truncado
      fue_resumido  (bool):  siempre False aquí; ChunkerService lo pone en True
      n_chunks      (int):   1 siempre aquí; ChunkerService lo actualiza
      fue_truncado_fc (bool): siempre False aquí
    """
    ext = path.suffix.lower()
    lector = LECTORES_EXT.get(ext)
    if not lector:
        return None

    # [CODIGO-FIX] Antes: `if ext == ".py"`. Al incorporar .ipynb como código,
    # un literal por extensión habría dejado los notebooks con el presupuesto de
    # documento. Se decide contra el catálogo único.
    max_c = MAX_CHARS_CODIGO if ext in EXTENSIONES_CODIGO else MAX_CHARS_DOC

    # ── [AUDIT-FIX 2026-07-28] El TRUNCADO-FIX estaba aplicado a MEDIAS ─────
    # La auditoría del 2026-07-26 arregló la LECTURA DIRECTA (más abajo): con
    # el chunking activo se entrega el texto íntegro y es el ChunkerService
    # quien decide cómo cubrirlo. Pero esta rama —la del CACHÉ— siguió pidiendo
    # `max_chars=max_c` (15.000), así que guardaba y servía el texto recortado
    # declarando `chars_totales` del documento entero.
    #
    # Resultado medido sobre Manual_Metodologico_LaR_completo.pdf (1.302.266
    # chars), misma orden, misma configuración:
    #     sin caché → 40 segmentos, cobertura 100.0%
    #     con caché →  2 segmentos, cobertura   1.2%
    # Es decir: exactamente el fallo que el TRUNCADO-FIX eliminaba seguía vivo
    # en la ruta que se toma en CASI TODAS las corridas, porque el caché está
    # activo por defecto. El chunking adaptativo/jerárquico no servía de nada:
    # el documento nunca le llegaba entero.
    #
    # El tope duro solo tiene sentido cuando NO hay chunker detrás que cubra el
    # resto, así que se decide con el mismo criterio que la lectura directa.
    from config.parametros import CHUNK_ENABLED as _chunk_on
    _max_cache = None if _chunk_on else max_c

    # ── Intentar servir del caché ──────────────────────────────────────────
    cache = get_cache() if _CACHE_DISPONIBLE else None
    if cache is not None and cache.enabled:
        cached = cache.get(
            path=path,
            extractor_fn=lector,
            max_chars=_max_cache,
        )
        if cached is not None:
            # ── [AUDIT-FIX] Entradas anteriores al campo `lectura_fallida` ────
            # Al añadir ese campo, las entradas YA cacheadas se quedaron sin él:
            # el mismo documento daba `lectura_fallida=False` leído en fresco y
            # `None` servido del caché. Peor: una lectura fallida cacheada ANTES
            # del fix conserva su `cobertura_pct=100` — justo la mentira que el
            # fix elimina.
            #
            # En vez de un setdefault más (que perpetuaría la cobertura vieja),
            # se re-deriva del propio contenido: si lleva la firma de un fallo
            # de lectura, se corrige la cobertura aunque venga del caché.
            _cont_cache = cached.get("contenido", "") or ""
            _fallo = (_MARCA_LECTURA_FALLIDA in _cont_cache
                      or bool(re.match(r"^\[(Error|PDF no legible|Documento vacío|⚠️\s+PDF ESCANEADO)",
                                       _cont_cache.strip())))
            if _fallo:
                cached["contenido"] = _cont_cache.replace(_MARCA_LECTURA_FALLIDA, "")
                cached["cobertura_pct"] = 0.0
                cached["lectura_fallida"] = True
            else:
                cached.setdefault("cobertura_pct", 100.0 if not cached.get("truncado") else
                                  round(max_c / cached["chars_totales"] * 100, 1))
                cached["lectura_fallida"] = False

            cached.setdefault("fue_resumido",    False)
            cached.setdefault("n_chunks",        1)
            cached.setdefault("fue_truncado_fc", False)
            # [CUSTODIA] La ruta absoluta viaja con el documento para que la
            # cadena de custodia pueda re-hashear el fichero en disco y
            # demostrar QUÉ VERSIÓN exacta justificó cada puntaje. Sin ella,
            # el informe solo guarda el nombre y no hay forma de verificar
            # a posteriori si el manual citado cambió.
            cached["ruta"] = str(path.resolve())
            # [CUSTODIA-FIX] Faltaba el hash del FICHERO en esta rama, y como el
            # caché está activo por defecto, era el caso NORMAL: la mayoría de
            # informes salían con `version_evidencia_usada.sha256_archivo = None`
            # y `--verificar-evidencia` los reportaba como NO VERIFICABLES.
            # La cadena de custodia existía pero no se podía usar.
            # El propio caché ya guarda ese hash (`hash_sha256`) porque lo usa
            # como clave de invalidación; se reutiliza en vez de recalcularlo, y
            # si por lo que sea no está, se calcula del fichero real.
            cached["sha256_archivo"] = (
                cached.get("hash_sha256")
                or (DocumentCache._hash_archivo(path) if _CACHE_DISPONIBLE else None)
            )
            return cached

    # ── Lectura directa ────────────────────────────────────────────────────
    try:
        contenido = lector(path) or ""
    except Exception as exc:
        logger.error("❌ Error leyendo %s: %s", path.name, exc)
        return None

    chars_totales = len(contenido)

    # ── [TRUNCADO-FIX] No truncar aquí si el chunker va a procesarlo ─────────
    # PROBLEMA DETECTADO EN AUDITORÍA (2026-07-26):
    #   Esta función truncaba SIEMPRE a MAX_CHARS_DOC (15.000). Un manual de
    #   327.360 chars llegaba al ChunkerService ya recortado a 15.000, y el
    #   chunker reportaba "cobertura 100%" — 100% de los 15.000 que recibió,
    #   es decir el 4.6% del documento real. El prompt afirmaba cobertura
    #   completa habiendo perdido el 95.4% del manual.
    #
    #   Es decir: la corrección del chunking (adaptativo/jerárquico) no servía
    #   de nada, porque el documento nunca le llegaba entero.
    #
    # SOLUCIÓN: entregar el texto COMPLETO cuando el chunking está habilitado.
    #   El ChunkerService es quien debe decidir cómo cubrirlo (segmentar y
    #   resumir). MAX_CHARS_DOC solo se aplica como tope duro si el chunking
    #   está desactivado (VIRF_CHUNK_ENABLED=0), para no reventar el prompt.
    from config.parametros import CHUNK_ENABLED as _chunking_activo

    if _chunking_activo:
        contenido_final = contenido          # íntegro → el chunker lo cubrirá
        truncado = False
        cobertura = 100.0
        if chars_totales > max_c:
            logger.info(
                "'%s': %d chars — se entrega íntegro al chunker (antes se "
                "truncaba a %d).", path.name, chars_totales, max_c,
            )
    else:
        contenido_final = contenido[:max_c]
        truncado = chars_totales > max_c
        cobertura = 100.0 if not truncado else round(max_c / chars_totales * 100, 1)
        if truncado:
            logger.warning(
                "'%s': TRUNCADO a %d de %d chars (%.1f%%) — chunking desactivado.",
                path.name, max_c, chars_totales, cobertura,
            )

    # ── [AUDIT-FIX] Lectura fallida ⇒ cobertura 0, no 100 ────────────────────
    # Los lectores devuelven su mensaje de error COMO CONTENIDO. Sin esto, un
    # PDF corrupto entraba al pipeline con contenido «[Error OCR ...]» y
    # cobertura_pct=100: el evaluador recibía un mensaje de error creyendo que
    # era el documento íntegro, y D3-FIX no lo rechazaba porque "había texto".
    lectura_fallida = _MARCA_LECTURA_FALLIDA in contenido_final
    if lectura_fallida:
        contenido_final = contenido_final.replace(_MARCA_LECTURA_FALLIDA, "")
        cobertura = 0.0
        logger.warning("'%s': lectura fallida — cobertura 0%%. %s",
                       path.name, contenido_final.strip()[:120])

    doc = {
        "nombre":        path.name,
        "tipo":          ext.lstrip(".").upper(),
        "contenido":     contenido_final,
        "chars_totales": chars_totales,
        "truncado":      truncado,
        "cobertura_pct": cobertura,
        "lectura_fallida": lectura_fallida,
        "fue_resumido":  False,
        "n_chunks":      1,
        "fue_truncado_fc": False,
        # [CUSTODIA] Ruta absoluta y hash del FICHERO (no del texto extraído).
        # El hash del texto ya viaja en la huella, pero para verificar a
        # posteriori si el manual citado cambió hay que comparar contra el
        # fichero real en disco: el texto extraído no es reproducible sin
        # reejecutar el lector, y su hash cambiaría al actualizar una librería.
        "ruta":          str(path.resolve()),
        "sha256_archivo": DocumentCache._hash_archivo(path) if _CACHE_DISPONIBLE else None,
    }

    # Guardar en caché (el texto crudo, antes del chunking)
    if cache is not None and cache.enabled:
        cache._guardar_entrada(str(path.resolve()),
                               DocumentCache._hash_archivo(path) or "", path, doc)

    return doc


# [EVIDENCIA-FIX] Carpetas cuyo contenido NO es evidencia documental.
#   datasets/ → son los DATOS que evalúa el motor de calidad, no documentos
#               que el LLM deba leer. Se leían como evidencia y un solo .csv
#               consumía los 15.000 chars de contexto (MAX_CHARS_DOC),
#               expulsando el manual metodológico y el perfil de datos reales.
#   El Pipeline 1 ya los excluía (control_evaluacion_data.CARPETAS_EXCLUIDAS);
#   el Pipeline 2 no, hasta esta corrección.
CARPETAS_NO_EVIDENCIA = {"datasets", "__pycache__", ".git", ".ipynb_checkpoints"}

# Archivos de configuración del validador — tampoco son evidencia del modelo
ARCHIVOS_NO_EVIDENCIA = {"estandares_virf.xlsx", "controlesdata.xlsx"}


def _es_evidencia(path: Path) -> bool:
    """True si el archivo debe tratarse como evidencia documental del modelo."""
    if path.name.startswith("~$") or path.name.startswith("."):
        return False
    if path.name.lower() in ARCHIVOS_NO_EVIDENCIA:
        return False
    return not (set(p.lower() for p in path.parts) & CARPETAS_NO_EVIDENCIA)


def leer_carpeta(carpeta: Path) -> list:
    """
    Lee todos los archivos soportados de una carpeta (recursivo).

    [EVIDENCIA-FIX] Excluye datasets/ y los Excel de configuración del
    validador: son insumos del motor de datos, no evidencia a interpretar.

    Retorna lista de dicts.
    """
    if not carpeta.exists():
        return []
    archivos = []
    # BUG FIX: usar rglob en lugar de iterdir para leer subdirectorios
    # (ej: inputs/documentacion/modelamiento/ y inputs/documentacion/seguimiento/)
    for path in sorted(carpeta.rglob("*")):
        if path.is_file() and _es_evidencia(path):
            doc = leer_archivo(path)
            if doc:
                archivos.append(doc)
    return archivos


def leer_repositorio_informes(carpeta: Path) -> str:
    """Consolida el texto de todos los informes de referencia para aprendizaje de estilo."""
    docs = leer_carpeta(carpeta)
    if not docs:
        return ""
    return "\n".join(
        f"=== INFORME: {d['nombre']} ===\n{d['contenido']}\n"
        for d in docs
    )


def cargar_todos_inputs() -> dict:
    """
    Carga todos los inputs definidos en RUTAS['inputs'].
    Retorna dict {nombre_seccion: [lista_de_docs]}.
    """
    resultado = {}
    for nombre, ruta in RUTAS["inputs"].items():
        resultado[nombre] = leer_carpeta(Path(ruta))
    return resultado


def inputs_para_dimension(docs: dict, dimension: str) -> list:
    """
    Filtra y une los documentos relevantes para una dimensión específica.
    Ordena por prioridad: manuales → scripts seguimiento → scripts modelador → excels → otros.
    """
    secciones = AMBITO_A_INPUTS.get(dimension, list(docs.keys()))
    todos = []
    for sec in secciones:
        todos.extend(docs.get(sec, []))

    manuales    = [d for d in todos if d["tipo"] in ("PDF", "DOCX", "DOC")]
    scripts_seg = [d for d in todos if d["tipo"] == "PY" and
                   any(k in d["nombre"].lower() for k in
                       ("seguimiento", "backtest", "kupiec", "christoff", "replica_virf", "monitor"))]
    scripts_mod = [d for d in todos if d["tipo"] == "PY" and d not in scripts_seg]
    excels      = [d for d in todos if d["tipo"] in ("XLSX", "XLS", "XLSM", "CSV")]
    otros       = [d for d in todos if d not in manuales + scripts_seg + scripts_mod + excels]

    return manuales + scripts_seg + scripts_mod + excels + otros


def leer_estandares_virf(tier: str) -> Optional[dict]:
    """
    Lee Estandares_VIRF.xlsx y retorna actividades filtradas por Tier.

    Retorna:
    {
      "Documentación": [
        {
          "control": "...",
          "tipo_ctrl": "Cuantitativo|Cualitativo",
          "actividad": "...",
          "requerida": True,
          "concepto_existente": "..." | None,
          "validaciones_previas": [{"col": "...", "valor": "..."}, ...]
        },
        ...
      ],
      ...
    }
    """
    path = RUTAS["estandares_virf"]
    if not Path(path).exists():
        return None

    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        # [AUDIT-FIX] Aquí vivía un `_TIER_MAP` duplicado de config.dominio.
        # Dos catálogos de tiers que nadie garantizaba iguales; ahora uno solo.
        from config.dominio import normalizar_tier
        tier_norm = normalizar_tier(tier) or str(tier).upper()
        tier_col = f"TIER_{tier_norm}"
        resultado = {}

        for nombre_hoja in wb.sheetnames:
            if any(k in nombre_hoja.lower() for k in ("instruc", "resumen", "readme", "leeme")):
                continue

            ws = wb[nombre_hoja]
            filas = [list(row) for row in ws.iter_rows(values_only=True)]
            if not filas:
                continue

            # Normalizar longitud de filas
            n_cols = max(len(f) for f in filas)
            for f in filas:
                while len(f) < n_cols:
                    f.append(None)

            # ── [PARSER-FIX] Detectar la cabecera ANTES del forward-fill ─────
            # El forward-fill se hacía sobre los índices FIJOS (0, 1) antes de
            # saber dónde estaba cada columna. Si alguien reordenaba el Excel,
            # se rellenaban columnas equivocadas y las filas sin ÁMBITO se
            # descartaban en silencio (ver test F1 de la auditoría).
            cab_idx = None
            palabras_hdr = {"ámbito", "ambito", "control", "actividad", "tier", "requiere"}
            for i, fila in enumerate(filas):
                vals_lower = {str(v).lower().strip() for v in fila if v}
                if vals_lower & palabras_hdr:
                    cab_idx = i
                    break

            if cab_idx is None:
                raise ValueError(
                    f"[{path}] hoja '{nombre_hoja}': no se encontró la fila de "
                    f"cabecera. Se esperaba una fila con alguna de estas palabras: "
                    f"{sorted(palabras_hdr)}. Revisa la estructura del Excel."
                )

            hdr_row = [str(v).lower().strip() if v else "" for v in filas[cab_idx]]
            datos   = filas[cab_idx + 1:]

            def _col(*claves):
                for i, h in enumerate(hdr_row):
                    if any(k in h for k in claves):
                        return i
                return None

            # BUG FIX: 'or N' es falsy cuando _col() retorna 0 (columna 0 encontrada)
            # Usar is None explícito para distinguir "no encontrado" de "columna 0"
            col_ambito = _col("ámbito", "ambito", "dimension", "dimensión")
            col_ctrl   = _col("control", "ctrl")
            col_act    = _col("actividad", "activity", "tarea")

            # ── [PARSER-FIX] Validación explícita de columnas obligatorias ────
            # Antes se caía a los índices fijos 0/1/2 cuando no encontraba una
            # columna. Si alguien renombraba "ACTIVIDAD" a "DESCRIPCIÓN", el
            # parser tomaba la columna CONTROL como actividad y producía datos
            # erróneos SIN ningún error (test F2 de la auditoría).
            _faltantes = []
            if col_ambito is None:
                _faltantes.append("ÁMBITO (o DIMENSIÓN)")
            if col_act is None:
                _faltantes.append("ACTIVIDAD (o TAREA)")

            # ── [AUDIT-FIX 2026-07-30] Hoja auxiliar ≠ columna renombrada ────
            # El Excel real trae una segunda hoja de apoyo con solo ÁMBITO y
            # CONTROL —una lista de referencia, sin actividades ni tiers—. Como
            # la validación de arriba aborta ante CUALQUIER hoja sin ACTIVIDAD,
            # esa pestaña auxiliar tumbaba la lectura del estándar COMPLETO:
            # `leer_estandares_virf()` devolvía None y el pipeline moría con
            # «No se pudieron cargar los estándares».
            #
            # La validación estricta debe seguir existiendo: nació porque
            # renombrar ACTIVIDAD a DESCRIPCIÓN hacía que el parser tomara la
            # columna CONTROL como actividad y produjera datos erróneos EN
            # SILENCIO. Lo que hay que distinguir es el caso:
            #
            #   · hoja SIN actividad pero CON columnas TIER  → es una hoja de
            #     actividades con la columna renombrada → ERROR, como antes;
            #   · hoja SIN actividad y SIN columnas TIER     → no es una hoja de
            #     actividades → se omite con aviso, no se aborta.
            #
            # El criterio es la presencia de TIER porque es lo que convierte a
            # una tabla en el estándar: sin tiers no hay nada que filtrar.
            _tiene_tier = any("tier" in h for h in hdr_row)
            if _faltantes and not _tiene_tier:
                logger.info(
                    "[%s] hoja '%s' omitida: no es una hoja de actividades "
                    "(sin %s y sin columnas TIER). Cabecera: %s",
                    Path(path).name, nombre_hoja, ", ".join(_faltantes),
                    [h for h in hdr_row if h],
                )
                continue

            if _faltantes:
                raise ValueError(
                    f"[{Path(path).name}] hoja '{nombre_hoja}': faltan columnas "
                    f"obligatorias: {', '.join(_faltantes)}.\n"
                    f"  Cabecera encontrada (fila {cab_idx + 1}): "
                    f"{[h for h in hdr_row if h]}\n"
                    f"  El nombre de la columna debe contener alguna de estas "
                    f"palabras: ámbito/ambito/dimensión para el ámbito, y "
                    f"actividad/activity/tarea para la actividad."
                )
            # CONTROL es opcional (agrupador temático): si falta, queda vacío.
            if col_ctrl is None:
                logger.info(
                    "[%s] hoja '%s': sin columna CONTROL; se dejará vacía.",
                    Path(path).name, nombre_hoja,
                )

            # ── [PARSER-FIX] Forward-fill sobre las columnas REALES ───────────
            # Las celdas de ÁMBITO y CONTROL están fusionadas en el Excel: solo
            # la primera fila de cada grupo tiene valor. Se propaga hacia abajo.
            # Antes se hacía sobre los índices fijos (0,1) sin saber dónde
            # estaban realmente esas columnas.
            for col_idx in (c for c in (col_ambito, col_ctrl) if c is not None):
                last = None
                for fila in filas[cab_idx + 1:]:
                    if col_idx >= len(fila):
                        continue
                    v = fila[col_idx]
                    if v is not None and str(v).strip() not in ("", "None", "nan"):
                        last = str(v).strip()
                    else:
                        fila[col_idx] = last

            # Columna del TIER
            tier_key = tier_col.lower()
            col_tier = None
            for i, h in enumerate(hdr_row):
                h_clean = h.replace(" ", "_").replace("-", "_")
                if h_clean == tier_key or h == tier_key:
                    col_tier = i
                    break
            if col_tier is None:
                tier_num = tier.upper()
                for i, h in enumerate(hdr_row):
                    if "tier" in h and tier_num in h.upper():
                        col_tier = i
                        break

            # ── [PARSER-FIX] La ausencia de TIER NO puede pasar en silencio ──
            # Antes: `else: requerida = True` marcaba TODAS las actividades como
            # requeridas sin avisar. El filtro por tier desaparecía y una
            # validación Tier 4 evaluaba las 21 actividades en vez de 11
            # (test F3 de la auditoría) — con impacto directo en el score.
            if col_tier is None:
                _cols_tier = [h for h in hdr_row if "tier" in h]
                aviso = (
                    f"[{Path(path).name}] hoja '{nombre_hoja}': NO se encontró la "
                    f"columna del Tier '{tier_col}'. "
                    f"Columnas tipo TIER presentes: {_cols_tier or 'NINGUNA'}. "
                    f"→ TODAS las actividades se tratarán como REQUERIDAS: el "
                    f"filtro por tier queda desactivado."
                )
                logger.warning(aviso)
                print(f"\n  ⚠️  {aviso}\n")

            # Columna Concepto
            col_concepto = _col("concepto")

            # Columnas historial VALIDACIÓN_*
            cols_validacion = []
            for i, h in enumerate(hdr_row):
                if (re.match(r"validaci[oó]n[_\s]\d{8}.*", h, re.IGNORECASE) or
                        "validación" in h or "validacion" in h):
                    cols_validacion.append((i, filas[cab_idx][i]))

            # [AUDIT-FIX] Aquí había un SEGUNDO forward-fill de col_ctrl,
            # duplicado del que ya se hace arriba (líneas ~545) — y, a
            # diferencia de aquel, sin proteger contra `col_ctrl is None`.
            #
            # El código declara en la línea ~534 que CONTROL es OPCIONAL, pero
            # `len(fila) > col_ctrl` con None lanza
            # «'>' not supported between instances of 'int' and 'NoneType'».
            # Reproducido con un Excel de cabecera ÁMBITO|ACTIVIDAD|TIER_I: el
            # TypeError lo tragaba el `except` de abajo y salía como
            # «Verificar estructura del Excel» — cuando la estructura era
            # válida según la propia documentación del parser.
            #
            # Se elimina el duplicado; el forward-fill guardado de arriba basta.

            # Parsear datos
            for fila in datos:
                ambito  = str(fila[col_ambito]).strip() if fila[col_ambito] else ""
                # CONTROL es opcional: sin columna, queda vacío (contrato de la línea ~534).
                control = (str(fila[col_ctrl]).strip()
                           if col_ctrl is not None and len(fila) > col_ctrl and fila[col_ctrl]
                           else "")
                activ   = str(fila[col_act]).strip()    if len(fila) > col_act and fila[col_act] else ""

                if not activ or activ.lower() in ("actividad", "activity", "nan", "none", ""):
                    continue
                if not ambito or ambito.lower() in ("nan", "none", ""):
                    continue

                # ── [PARSER-FIX] Descartar filas espurias ────────────────────
                # El forward-fill de ÁMBITO hace que CUALQUIER fila posterior
                # herede el último ámbito visto. Una fila de totales o una nota
                # al pie entraba como actividad real (test F4 de la auditoría).
                # Se descarta solo por marcadores EXPLÍCITOS de fila no-actividad.
                # NO se usa un umbral de longitud: descartaría actividades cortas
                # legítimas ("Revisar tiering") y sería un criterio arbitrario.
                _act_norm = activ.strip().lower()
                _ES_FILA_ESPURIA = (
                    _act_norm.startswith((
                        "total", "subtotal", "suma ",
                        "nota:", "notas:", "nota ", "notas ",
                        "fuente:", "fuente ", "elaborado por", "aprobado por",
                        "leyenda", "observacion general", "observación general",
                        "ver anexo", "continúa en", "continua en",
                    ))
                    or _act_norm in ("-", "--", "---", "n/a", "na", "x", "nota", "notas")
                )
                if _ES_FILA_ESPURIA:
                    logger.debug(
                        "[%s] fila descartada por parecer espuria: %r",
                        nombre_hoja, activ[:60],
                    )
                    continue

                # Requerida por Tier
                if col_tier is not None and len(fila) > col_tier:
                    tier_val  = str(fila[col_tier]).strip().upper()
                    requerida = tier_val in ("X", "SI", "YES", "1", "TRUE", "✓", "✔", "V")
                else:
                    requerida = True

                # Concepto existente
                concepto_prev = None
                if col_concepto is not None and len(fila) > col_concepto:
                    v = fila[col_concepto]
                    if v and str(v).strip() not in ("", "None", "nan"):
                        concepto_prev = str(v).strip()

                # Historial de validaciones previas
                validaciones_previas = []
                for col_idx_v, col_nombre_v in cols_validacion:
                    if len(fila) > col_idx_v:
                        v = fila[col_idx_v]
                        if v and str(v).strip() not in ("", "None", "nan"):
                            validaciones_previas.append({
                                "col":   str(col_nombre_v) if col_nombre_v else f"Col{col_idx_v}",
                                "valor": str(v).strip(),
                            })

                # Tipo de control
                tipo_ctrl = "Cualitativo"
                ctrl_l = control.lower()
                if any(k in ctrl_l for k in ("cuantit", "quantit", "medic", "métric", "metric",
                                              "modelador", "backtesting", "seguim")):
                    tipo_ctrl = "Cuantitativo"

                resultado.setdefault(ambito, []).append({
                    "control":              control,
                    "tipo_ctrl":            tipo_ctrl,
                    "actividad":            activ,
                    "requerida":            requerida,
                    "concepto_existente":   concepto_prev,
                    "validaciones_previas": validaciones_previas,
                })

        return resultado if resultado else None

    except Exception as e:
        # [AUDIT-FIX 2026-08-07] El mensaje era una línea sin contexto y el
        # llamante aborta la corrida (`agente.py`: sys.exit(1)), así que el
        # operador se quedaba con «Error leyendo Estandares_VIRF: KeyError» y
        # sin saber qué columna o qué hoja mirar. La rúbrica es el fichero que
        # más manos toca: renombrar una columna es el fallo más probable.
        import traceback as _tb
        print(f"    [!] Error leyendo Estandares_VIRF ({type(e).__name__}): {e}")
        print(f"        Fichero : {RUTAS.get('estandares_virf')}")
        print(f"        Tier     : {tier}")
        print( "        Revisa que la hoja principal conserve las columnas "
               "AMBITO, CONTROL, ACTIVIDAD y TIER I..IV.")
        _linea = (_tb.format_exc().strip().split("\n")[-3:] or [""])[0].strip()
        if _linea:
            print(f"        Punto exacto: {_linea}")
        return None


# ─── NUEVAS FUNCIONES PARA PIPELINE POR CONTROL ─────────────────────────────


def _recortar_declarando(texto: str, tope: int, nombre: str) -> str:
    """
    Aplica el tope del pipeline por control DEJANDO CONSTANCIA del recorte.

    ── Por qué existe ───────────────────────────────────────────────────────
    Estos lectores cortaban con un `[:MAX_CHARS_*]` mudo. El texto llegaba al
    prompt sin ninguna marca, así que el evaluador no podía distinguir «el
    documento no menciona el backtesting» de «la mención estaba en el 40% que
    se cortó». Esa confusión viola el invariante de que la AUSENCIA no es
    incumplimiento: producía observaciones contra el modelo validado por
    material que el validador sí había entregado.

    Es la misma clase de fallo que la auditoría de 2026-07-26 corrigió en
    `leer_archivo` —donde un manual de 327.360 chars llegaba recortado a
    15.000 y el chunker reportaba «cobertura 100%»—, pero en el otro pipeline.
    `leer_ipynb` ya lo hacía bien; el resto no.

    No se sube el tope: el pipeline por control compone su contexto con
    `compilar_textos_de_carpeta` y tiene su propio presupuesto. Lo que cambia
    es que el recorte ahora es VISIBLE, y `motor_ia` ya sabe leer esta marca.
    """
    if len(texto) <= tope:
        return texto
    perdidos = len(texto) - tope
    pct = 100.0 * tope / len(texto)
    return (
        texto[:tope]
        + f"\n\n⚠️ DOCUMENTO TRUNCADO (tope del pipeline por control) — "
          f"'{nombre}': se incluyeron {tope:,} de {len(texto):,} chars "
          f"({pct:.1f}%); faltan {perdidos:,}. Si no encuentras un requisito "
          f"aquí, trátalo como INCERTIDUMBRE, no como incumplimiento: puede "
          f"estar en la parte no incluida."
    )


def leer_txt_csv_log(ruta: str) -> str:
    """Lee .txt, .csv, .log y retorna el contenido como string."""
    try:
        path = Path(ruta)
        if not path.exists():
            return ""
        return _recortar_declarando(
            path.read_text(encoding="utf-8", errors="replace"),
            MAX_CHARS_DOC, path.name)
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error leyendo {ruta}: {e}]"


def leer_sql(ruta: str) -> str:
    """
    Lector de .sql para el pipeline por CONTROL, acotado a MAX_CHARS_CODIGO.

    [CODIGO-FIX 2026-07-30] El pipeline COMPLETO lo lee ahora por LECTORES_EXT
    sin tope, igual que el resto del código. Aquí se conserva el recorte porque
    el pipeline por control compone su contexto con `compilar_textos_de_carpeta`
    y tiene su propio presupuesto.
    """
    try:
        path = Path(ruta)
        if not path.exists():
            return ""
        return _recortar_declarando(
            path.read_text(encoding="utf-8", errors="replace"),
            MAX_CHARS_CODIGO, path.name)
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error leyendo SQL {ruta}: {e}]"


def leer_r(ruta: str) -> str:
    """Lector de .R para el pipeline por CONTROL, acotado a MAX_CHARS_CODIGO."""
    try:
        path = Path(ruta)
        if not path.exists():
            return ""
        return _recortar_declarando(
            path.read_text(encoding="utf-8", errors="replace"),
            MAX_CHARS_CODIGO, path.name)
    except Exception as e:
        return f"{_MARCA_LECTURA_FALLIDA}[Error leyendo R {ruta}: {e}]"


def leer_ipynb(ruta: str) -> str:
    """
    Lector de notebook para el pipeline por CONTROL, acotado a MAX_CHARS_CODIGO.

    [CODIGO-FIX 2026-07-30] Antes era una SEGUNDA implementación completa del
    parseo de nbformat, y no era equivalente a la del pipeline completo: no
    declaraba si las celdas se habían ejecutado, ignoraba los outputs y
    asumía que `source` es siempre una lista (con un notebook guardado con
    `source` como string, `"".join()` lo partía carácter a carácter).

    Ahora hay UNA sola implementación (`_leer_ipynb_completo`) y aquí solo se
    aplica el tope del pipeline por control, que compone su contexto con
    `compilar_textos_de_carpeta` y tiene su propio presupuesto.
    """
    path = Path(ruta)
    if not path.exists():
        return ""
    texto = _leer_ipynb_completo(path)
    if _MARCA_LECTURA_FALLIDA in texto:
        return texto
    # Declaraba el recorte con un texto propio («... [truncado a N chars]») que
    # `motor_ia._fue_truncado_fc` NO reconocía: el aviso existía para el humano
    # y era invisible para el evaluador. Ahora usa la marca común.
    return _recortar_declarando(texto, MAX_CHARS_CODIGO, path.name)


def leer_archivo_generico(ruta: str) -> str:
    """Dispatcher: selecciona lector según extensión."""
    path = Path(ruta)
    ext = path.suffix.lower()
    
    if ext == ".pdf":
        return _leer_pdf(path)
    elif ext in (".docx", ".doc"):
        return _leer_docx(path)
    elif ext in (".pptx", ".ppt"):
        return _leer_pptx(path)
    elif ext in (".xlsx", ".xls", ".xlsm"):
        return _leer_excel(path, MAX_FILAS_EXCEL)
    elif ext == ".py":
        return _leer_python(path, MAX_CHARS_CODIGO)
    elif ext == ".json":
        return _leer_json(path)
    elif ext == ".ipynb":
        return leer_ipynb(ruta)
    elif ext == ".sql":
        return leer_sql(ruta)
    elif ext == ".r":
        return leer_r(ruta)
    elif ext in (".txt", ".csv", ".log"):
        return leer_txt_csv_log(ruta)
    elif ext == ".md":
        return _recortar_declarando(
            path.read_text(encoding="utf-8", errors="replace"),
            MAX_CHARS_DOC, path.name)
    else:
        return ""


def compilar_textos_de_carpeta(base_path: str, subfolder: str, max_chars: int = 14000) -> str:
    """
    Recorre recursivo una carpeta, concatena contenido de archivos soportados.
    Trunca a max_chars total.
    
    Parámetros:
        base_path: ruta base del proyecto
        subfolder: subcarpeta relativa dentro de base_path
        max_chars: máximo de caracteres total a retornar
    
    Retorna:
        String concatenado con encabezados por ruta relativa
    """
    base = Path(base_path) / subfolder
    if not base.exists():
        return ""
    
    partes = []
    total_chars = 0
    
    for archivo in sorted(base.rglob("*")):
        if archivo.is_file():
            contenido = leer_archivo_generico(str(archivo))
            if contenido:
                rel_path = archivo.relative_to(base)
                encabezado = f"\n=== {rel_path} ===\n"
                full_content = encabezado + contenido
                
                if total_chars + len(full_content) > max_chars:
                    # Truncar el último bloque si excede
                    remaining = max_chars - total_chars
                    if remaining > len(encabezado):
                        partes.append(full_content[:remaining])
                    break
                
                partes.append(full_content)
                total_chars += len(full_content)
    
    return "".join(partes)


def obtener_evidencia_por_control(base_project_path: str, ctrl_id: str, max_chars: int = 14000) -> str:
    """
    Lee evidencia dentro de EVIDENCIA_FOLDER/ctrl_id/ y concatena.
    
    Parámetros:
        base_project_path: ruta raíz del proyecto
        ctrl_id: ID del control (ej: "CTRL_001")
        max_chars: trunca a este límite
    
    Retorna:
        String con evidencia compilada del control
    """
    subfolder = f"{EVIDENCIA_FOLDER}/{ctrl_id}"
    return compilar_textos_de_carpeta(base_project_path, subfolder, max_chars)


def obtener_conocimiento_por_modelo(base_project_path: str, nombre_modelo: str, max_chars: int = 9000) -> str:
    """
    Compila contenido en Conocimiento/<NombreModelo>/* para contexto.
    
    Parámetros:
        base_project_path: ruta raíz del proyecto
        nombre_modelo: nombre del modelo (se usa como carpeta)
        max_chars: trunca a este límite
    
    Retorna:
        String con conocimiento del modelo compilado
    """
    subfolder = f"{CONOCIMIENTO_FOLDER}/{nombre_modelo}"
    return compilar_textos_de_carpeta(base_project_path, subfolder, max_chars)


def _score_manual(name: str) -> int:
    """
    Calcula score para detectar si es "manual" (documentación).
    Keywords: manual, guia, guide, metodologia, manual, doc, README, etc.
    """
    name_lower = name.lower()
    score = 0
    
    # Extensión
    if name_lower.endswith((".pdf", ".docx", ".doc", ".txt", ".md")):
        score += 10
    
    # Keywords
    keywords = ["manual", "guia", "guide", "metodolog", "documentation", 
                "readme", "documento", "especificación", "spec"]
    for kw in keywords:
        if kw in name_lower:
            score += 15
    
    # Evitar que sea script
    if any(k in name_lower for k in ["etl", "pipeline", "script", "prog", ".py", ".sql"]):
        score -= 20
    
    return max(0, score)


def _score_script(name: str) -> int:
    """
    Calcula score para detectar si es "script" (código de proceso).
    Keywords: etl, pipeline, prog, proceso, transformacion, etc.
    """
    name_lower = name.lower()
    score = 0
    
    # Extensión
    if name_lower.endswith((".py", ".sql", ".r", ".ipynb", ".scala")):
        score += 15
    
    # Keywords
    keywords = ["etl", "pipeline", "process", "transformacion", "transform",
                "prog", "codigo", "code", "script", "query", "procedure"]
    for kw in keywords:
        if kw in name_lower:
            score += 15
    
    # Evitar que sea manual
    if any(k in name_lower for k in ["manual", "guia", "guide", "metodolog", 
                                       "documentation", "readme", ".pdf", ".docx"]):
        score -= 20
    
    return max(0, score)


def detectar_manual_y_script(carpeta_control: str) -> Tuple[Optional[str], str, Optional[str], str]:
    """
    Encuentra el "mejor" manual y script por scoring de nombres.
    
    Parámetros:
        carpeta_control: ruta a la carpeta del control
    
    Retorna:
        (ruta_manual, texto_manual, ruta_script, texto_script)
        Si no encuentra, retorna None en la ruta y "" en el texto.
    """
    base = Path(carpeta_control)
    if not base.exists():
        return None, "", None, ""
    
    archivos = [(f, f.name) for f in sorted(base.rglob("*")) if f.is_file()]
    
    # Detectar mejor manual
    manuals = [(f, _score_manual(n)) for f, n in archivos if _score_manual(n) > 0]
    best_manual = max(manuals, key=lambda x: x[1]) if manuals else (None, 0)
    ruta_manual = str(best_manual[0]) if best_manual[0] else None
    texto_manual = leer_archivo_generico(ruta_manual) if ruta_manual else ""
    
    # Detectar mejor script
    scripts = [(f, _score_script(n)) for f, n in archivos if _score_script(n) > 0]
    best_script = max(scripts, key=lambda x: x[1]) if scripts else (None, 0)
    ruta_script = str(best_script[0]) if best_script[0] else None
    texto_script = leer_archivo_generico(ruta_script) if ruta_script else ""
    
    return ruta_manual, texto_manual, ruta_script, texto_script


def guardar_parametros_ejecucion(
    outputs_dir: str,
    nombre_modelo: str,
    fecha_informe: str,
    tier: str,
    ruta_excel_controles: str,
) -> Path:
    """
    Crea un CSV _params_<modelo>_<fecha>.csv con parámetros de ejecución.
    
    Retorna:
        Path al archivo CSV creado
    """
    timestamp = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    filename = f"_params_{nombre_modelo}_{fecha_informe}.csv"
    filepath = Path(outputs_dir) / filename
    
    rows = [
        {
            "fecha_informe": fecha_informe,
            "tier": tier,
            "nombre_modelo": nombre_modelo,
            "ruta_excel": ruta_excel_controles,
            "ruta_output": str(filepath.parent),
            "timestamp_ejecucion_utc": timestamp,
        }
    ]
    
    try:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    except Exception as e:
        print(f"[!] Error guardando parámetros: {e}")
    
    return filepath
