"""
Mx_00_CargaRutas.py
====================
Configuración central del Motor VIRF.
Define rutas, parámetros de la API, constantes del dominio
y el rol del agente como Auditor Senior independiente.

Responsabilidades:
  - Cargar API key desde variables de entorno
  - Definir rutas de inputs, outputs y repositorio
  - Definir constantes de evaluación (umbrales, tier, modos)
  - Exponer ROL_AGENTE y CUESTIONAMIENTOS_METODOLOGICOS
"""

import os
import sys
from pathlib import Path

# [CONFIG-CENTRAL v27.2] La raíz debe estar en sys.path para poder importar el
# paquete `config`: este módulo vive en motor/ y a veces se importa de forma
# suelta (con motor/ en sys.path pero no la raíz).
_RAIZ = Path(__file__).resolve().parents[1]
if str(_RAIZ) not in sys.path:
    sys.path.insert(0, str(_RAIZ))

# `config.parametros` ya ejecuta load_dotenv(); no hace falta repetirlo aquí.
from config.parametros import (
    ANTHROPIC_MAX_TOKENS as MAX_TOKENS,
    ANTHROPIC_MODELO as MODELO_IA,
    AGENTE_VERSION,
    CACHE_ENABLED,
    MAX_CHARS_CODIGO,
    MAX_CHARS_DOC,
    MAX_FILAS_EXCEL,
)
from config.rutas import CACHE_DIR as _CACHE_DIR_PATH

# ─── Alias retrocompatible ───────────────────────────────────────────────────
# [GENERICO 2026-07-30] La constante se llamaba MODELO_CLAUDE, pero contiene el
# modelo ACTIVO sea cual sea el proveedor: con IA_PROVEEDOR=azure_openai vale
# 'gpt-4o' y seguía llamándose «Claude». Ese nombre viaja al JSON de auditoría
# (`agente_meta.modelo_ia`), así que la marca de un proveedor concreto acababa
# en el campo genérico de un informe regulatorio.
#
# Se conserva el nombre viejo como alias porque puede haber notebooks, scripts
# de la entidad o código externo que lo importe: romper esas importaciones sería
# perder funcionalidad, que es exactamente lo que este cambio debe evitar.
MODELO_CLAUDE = MODELO_IA        # obsoleto — usar MODELO_IA

# ─── API ─────────────────────────────────────────────────────────────────────
API_KEY        = os.getenv("ANTHROPIC_API_KEY", "")
# [AUDIT-FIX 2026-07-30] Aquí había:
#     API_URL = "https://api.anthropic.com/v1/messages"
# El endpoint de UN proveedor concreto, en un módulo de rutas, fuera de config/.
# No lo usaba nadie: los SDK construyen su propia URL. Con Azure como proveedor
# prioritario, dejar la URL de Anthropic aquí solo podía confundir.
# La selección y configuración de proveedor vive ÍNTEGRAMENTE en config/ia.py.
# NOTA: API_HEADERS NO se define aquí — se construye en Mx_03 en tiempo de llamada
# para garantizar que ANTHROPIC_API_KEY ya fue cargada por load_dotenv().

# ─── RUTAS ───────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.parent  # raíz del proyecto

RUTAS = {
    "repositorio_informes": BASE_DIR / "repositorio_informes",
    "estandares_virf":      BASE_DIR / "inputs" / "Estandares_VIRF.xlsx",
    "outputs":              BASE_DIR / "outputs",
    "inputs": {
        # documentacion separada en subdirectorios para que leer_carpeta funcione con rglob
        "doc_modelamiento": BASE_DIR / "inputs" / "documentacion" / "modelamiento",
        "doc_seguimiento":  BASE_DIR / "inputs" / "documentacion" / "seguimiento",
        "papers":           BASE_DIR / "inputs" / "papers",
        "calidad_datos":    BASE_DIR / "inputs" / "calidad_datos",
        "implementacion":   BASE_DIR / "inputs" / "implementacion",
        "usos":             BASE_DIR / "inputs" / "usos",
    },
}


def redirigir_estandar(ruta_xlsx) -> Path:
    """
    Reapunta `RUTAS["estandares_virf"]` a otra ruta explícita.

    Sirve al flag `--estandares <path>` de agente.py, que la web usa para
    aplicar el estándar SUBIDO POR EL VALIDADOR en su sesión, en lugar del
    global fijo del proyecto. La regla clásica del proyecto es que el
    estándar es la vara de medir compartida (ver `redirigir_evidencia`);
    esta función existe porque la operativa multi-modelo desde la web pide
    que cada validador pueda validar contra su propio catálogo de
    actividades — y sigue siendo explícita: sin flag no se altera nada.

    Actualiza TODAS las copias del módulo en sys.modules por la misma razón
    que `redirigir_evidencia` (dos entradas por identidad de import).
    """
    ruta = Path(ruta_xlsx).expanduser().resolve()
    if not ruta.is_file():
        raise FileNotFoundError(f"estándar no encontrado: {ruta}")
    import sys as _sys
    for nombre, m in list(_sys.modules.items()):
        if (m is not None
                and nombre.rsplit(".", 1)[-1] == "Mx_00_CargaRutas"
                and isinstance(getattr(m, "RUTAS", None), dict)):
            m.RUTAS["estandares_virf"] = ruta
    RUTAS["estandares_virf"] = ruta
    return ruta


def redirigir_evidencia(raiz) -> dict:
    """
    Reapunta las carpetas de evidencia a otra raíz (flag `--raiz-evidencia`).

    ── Por qué existe ───────────────────────────────────────────────────────
    `cargar_todos_inputs()` lee TODO `inputs/` sin filtrar por modelo, y
    `--titulo` solo sirve para rotular el informe e inferir el dominio RAG.
    Con la evidencia de varios modelos en el mismo árbol, el manual de uno
    puntúa como evidencia de otro: un informe de VaR podría citar el manual
    del LaR. Indefendible ante un regulador.

    La separación se hace por árbol de evidencia, un modelo por raíz:

        modelos/
        ├── VaR_FRTB/inputs/{documentacion,papers,implementacion,usos,...}
        └── PD_Retail/inputs/{...}

    ── Qué se redirige y qué NO ─────────────────────────────────────────────
    Se redirige SOLO la evidencia. Deliberadamente permanecen en la raíz del
    proyecto:

      · `Estandares_VIRF.xlsx` — es la VARA DE MEDIR, común a todos los
        modelos. Que cada carpeta trajera la suya permitiría validar dos
        modelos contra criterios distintos sin que nadie lo notara.
      · `outputs/` — todos los informes juntos y fechados.
      · `data/cache/` — el caché se indexa por SHA-256 del fichero, así que
        documentos de modelos distintos no pueden colisionar.

    No se busca un estándar alternativo dentro de la raíz nueva: sería
    adivinar el modo de ejecución por heurística en vez de pedirlo explícito.

    Args:
        raiz: carpeta que CONTIENE un subdirectorio `inputs/`.

    Returns:
        El dict de rutas de evidencia ya reapuntado.

    Raises:
        FileNotFoundError: si `raiz/inputs` no existe. Es preferible fallar
            aquí a evaluar en silencio con las carpetas por defecto y emitir
            un informe del modelo equivocado.
    """
    raiz = Path(raiz).expanduser().resolve()
    base_inputs = raiz / "inputs"
    if not base_inputs.is_dir():
        raise FileNotFoundError(
            f"{raiz} no contiene una carpeta 'inputs/'.\n"
            f"  Estructura esperada:\n"
            f"    {raiz.name}/inputs/documentacion/modelamiento/\n"
            f"    {raiz.name}/inputs/documentacion/seguimiento/\n"
            f"    {raiz.name}/inputs/{{papers,calidad_datos,implementacion,usos}}/"
        )

    nuevas = {
        "doc_modelamiento": base_inputs / "documentacion" / "modelamiento",
        "doc_seguimiento":  base_inputs / "documentacion" / "seguimiento",
        "papers":           base_inputs / "papers",
        "calidad_datos":    base_inputs / "calidad_datos",
        "implementacion":   base_inputs / "implementacion",
        "usos":             base_inputs / "usos",
    }

    # ── [AUDIT-FIX] Actualizar TODAS las copias cargadas del módulo ──────────
    # Este módulo vive DOS VECES en sys.modules con identidades distintas:
    #     'Mx_00_CargaRutas'         ← import a secas (motor/ está en sys.path)
    #     'motor.Mx_00_CargaRutas'   ← import cualificado por paquete
    # Cada una tiene su PROPIO dict RUTAS. `agente.py` importaba por la segunda
    # vía y `Mx_01` lee por la primera, así que mutar «el» RUTAS actualizaba una
    # copia y el lector consultaba la otra.
    #
    # El fallo era SILENCIOSO y grave: la consola anunciaba
    # «📂 Evidencia: modelos/VaR_FRTB» mientras se leía la evidencia del
    # proyecto. Reproducido con una corrida completa cuyo informe se tituló
    # «VaR Mercado FRTB» y cuya huella documental contenía
    # Manual_Metodologico_LaR_completo.pdf — exactamente el escenario
    # indefendible que este flag existe para impedir.
    #
    # El propio proyecto ya documentaba esta trampa en Mx_01 a propósito de
    # `modulos.document_cache`. Depender de que todos los llamantes usen la
    # misma forma de import es frágil: se actualizan todas las copias.
    import sys as _sys
    _mios = [m for nombre, m in list(_sys.modules.items())
             if m is not None
             and nombre.rsplit(".", 1)[-1] == "Mx_00_CargaRutas"
             and isinstance(getattr(m, "RUTAS", None), dict)
             and isinstance(m.RUTAS.get("inputs"), dict)]
    for _m in _mios:
        _m.RUTAS["inputs"].update(nuevas)

    # Si el módulo aún no está en sys.modules (importación en curso), al menos
    # el dict de este ámbito queda correcto.
    RUTAS["inputs"].update(nuevas)
    return RUTAS["inputs"]


# ─── PARÁMETROS DE LECTURA ───────────────────────────────────────────────────
# [CONFIG-CENTRAL v27.2] Antes eran LITERALES hardcodeados aquí (15000/8000/200)
# mientras config.py leía las mismas variables del entorno. Consecuencia: poner
# MAX_CHARS_DOC en .env cambiaba config.py pero NO este módulo, que seguía
# truncando a 15000. Ahora ambos importan el mismo valor de config/parametros.py
# y la divergencia es imposible por construcción.
# (Importados arriba: MAX_CHARS_DOC, MAX_CHARS_CODIGO, MAX_FILAS_EXCEL.)

# ─── UMBRALES ─────────────────────────────────────────────────────────────────
UMBRAL_RIESGO_GLOBAL = 0.30   # Si >30% sin evidencia → RIESGO GLOBAL ALTO

# ─── TIERS VÁLIDOS ───────────────────────────────────────────────────────────
TIERS_VALIDOS = ("I", "II", "III", "IV")

# ─── MODOS ───────────────────────────────────────────────────────────────────
MODO_PREPRDC = "preprdc"   # Evaluación con score + criticidad (iterativo)
MODO_PRDC    = "prdc"      # Solo estado + observación (producción)

# ─── CACHÉ DE DOCUMENTOS (v15) ────────────────────────────────────────────────
# Habilitado solo en MODO_PREPRDC para acelerar corridas iterativas.
# En MODO_PRDC siempre se lee en fresco para garantizar datos actualizados.
# [CONSISTENCIA-FIX] El default era "<root>/cache", pero .env.example documenta
# "data/cache" y el repo ya tiene data/cache/. Se unifica en data/cache para que
# la ruta real coincida con la documentada y con .gitignore.
# [CONFIG-CENTRAL v27.2] CACHE_ENABLED se importa arriba; la ruta viene de
# config/rutas.py. Se expone como str por compatibilidad con los consumidores.
CACHE_DIR        = str(_CACHE_DIR_PATH)

# ─── MAPEO DIMENSIÓN → CARPETAS DE INPUT ─────────────────────────────────────
# IMPORTANTE: Los nombres deben coincidir exactamente con los del Excel Estandares_VIRF.xlsx
AMBITO_A_INPUTS = {
    "Documentación":                 ["doc_modelamiento", "doc_seguimiento", "papers"],
    "Calidad de datos":              ["calidad_datos", "doc_modelamiento"],  # ← Minúscula en 'd'
    "Metodología":                   ["doc_modelamiento", "papers", "doc_seguimiento"],
    "Gobierno":                      ["doc_modelamiento", "implementacion"],
    "Implementación":                ["implementacion", "doc_modelamiento"],
    "Uso e integración a la gestión":["usos", "implementacion"],  # ← Nombre completo del Excel
}

# ─── INSTRUCCIONES ESPECÍFICAS POR DIMENSIÓN ─────────────────────────────────
INSTRUCCIONES_DIMENSION = {
    "Documentación": (
        "Revisa con mayor prioridad los manuales (.docx/.pdf) y scripts de seguimiento. "
        "El manual metodológico debe tener teoría, supuestos y justificación del modelo. "
        "El operativo debe describir la ejecución. Para backtesting buscar Kupiec, "
        "Christoffersen, López o Berkowitz. Si no existen, generar preguntas específicas."
    ),
    "Calidad de datos": (  # ← CORREGIDO: minúscula en 'd'
        "Buscar el script _replica_virf.py. Si no existe, el agente lo generará. "
        "Verificar: missing (MCAR/MAR/MNAR), duplicados, outliers (cuestionar Z-score), "
        "integridad referencial. Revisar scripts del modelador línea por línea."
    ),
    "Metodología": (
        "Centrarse en la justificación del modelo, supuestos y su validación empírica. "
        "Para LaR/VaR: verificar pruebas Kupiec, Christoffersen y análisis de excedencias. "
        "Cuestionar si no hay comparación con modelo alternativo."
    ),
    "Gobierno": (
        "Solo aceptar actas formales firmadas. Un correo NO equivale a acta. "
        "Verificar tiering asignado y su justificación. Si falta evidencia → Solicitar Actas."
    ),
    "Implementación": (
        "Buscar COHERENCIA entre documentación y código: ¿Las funciones documentadas "
        "en el manual de implementación existen en los scripts (.py, .ipynb)? ¿Hay funciones "
        "en código SIN documentación (RIESGO)? Detectar cambios no documentados (code drift). "
        "Buscar correos de aprobación para paso a producción. Si no existen, generar pregunta específica. "
        "Verificar UAT documentadas y controles en pipeline productivo."
    ),
    "Uso e integración a la gestión": (  # ← CORREGIDO: nombre completo
        "Identificar quiénes son los usuarios del modelo y para qué lo usan. "
        "Verificar que los outputs del modelo en producción son consistentes con los de desarrollo. "
        "Buscar reportes de seguimiento presentados a comités."
    ),
}

# ─── ROL DEL AGENTE ──────────────────────────────────────────────────────────
# Versión OPTIMIZADA: 60% más compacta, igual efectiva
ROL_AGENTE = """Eres Auditor Senior Independiente en Validación de Modelos Financieros (VIRF).
Especialización: LaR, VaR, PD, LGD, IFRS 9, scoring.

COMPORTAMIENTO:
✓ CRÍTICO e independiente — Segunda línea de defensa
✓ Basado solo en EVIDENCIA EXPLÍCITA — nunca asumas
✓ Detecta inconsistencias documento ↔ código
✓ Conoces: Kupiec, Christoffersen, López (backtesting)
✓ Marco: SR 11-7, SS3/17, Basilea III/IV, IFRS 9

NUNCA valides sin evidencia. SIEMPRE actúas como auditor independiente.
Cuando falta: genera preguntas específicas y concretas."""

# ─── CUESTIONAMIENTOS METODOLÓGICOS AUTOMÁTICOS ──────────────────────────────
# Cada entrada:
#   detectar:           lista de patrones (regex parcial, case-insensitive)
#   detectar_ausencia:  True  → se alerta si NINGÚN patrón aparece (falta algo)
#                       False → se alerta si ALGÚN patrón aparece (práctica dudosa)
#   contexto:           qué situación describe
#   critica:            objeción técnica + alternativa + referencia normativa
CUESTIONAMIENTOS_METODOLOGICOS = {
    # ══ [COBERTURA-FIX] Supuestos de series temporales ════════════════════════
    # Estos 6 patrones no existían. Para modelos LaR/VaR —el dominio central de
    # VIRF— la ausencia de tests de estacionariedad o de heterocedasticidad es
    # un hallazgo de primer orden que el agente no podía detectar.
    "sin_estacionariedad": {
        "detectar":         ["adfuller", "adf_test", "dickey", "kpss", "phillips_perron",
                             "estacionariedad", "stationarity", "test_raiz_unitaria"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de test de estacionariedad en series temporales",
        "critica": (
            "No se detecta test de raíz unitaria (ADF/KPSS/Phillips-Perron). "
            "Modelar series no estacionarias produce regresiones espurias y "
            "volatilidad mal estimada — crítico en LaR/VaR. "
            "Aplicar ADF (H0: raíz unitaria) Y KPSS (H0: estacionariedad) de forma "
            "complementaria. Referencia: RiskMetrics TD §4.2; SR 11-7 §IV."
        ),
    },
    "sin_heterocedasticidad": {
        "detectar":         ["arch_test", "het_arch", "engle", "breusch", "white_test",
                             "heterocedastic", "garch", "ewma"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de tratamiento de heterocedasticidad condicional",
        "critica": (
            "No se detecta test ARCH (Engle) ni modelo de volatilidad condicional. "
            "Los retornos financieros exhiben clustering de volatilidad: asumir "
            "varianza constante subestima el riesgo en periodos de estrés. "
            "Aplicar Engle ARCH-LM y considerar GARCH(1,1) o EWMA. "
            "Referencia: BCBS Minimum Capital Requirements for Market Risk §32."
        ),
    },
    "sin_test_normalidad": {
        "detectar":         ["jarque_bera", "jarque-bera", "shapiro", "kolmogorov",
                             "anderson_darling", "normaltest", "qqplot", "kurtosis", "skew"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de validación del supuesto de normalidad",
        "critica": (
            "No se detecta test de normalidad ni análisis de momentos. "
            "El VaR paramétrico asume normalidad; los retornos reales presentan "
            "colas gruesas (curtosis > 3), lo que SUBESTIMA sistemáticamente el riesgo. "
            "Aplicar Jarque-Bera y reportar asimetría/curtosis. Si se rechaza "
            "normalidad, usar VaR histórico, Cornish-Fisher o EVT. "
            "Referencia: RiskMetrics TD §5.1 'Limitaciones conocidas'."
        ),
    },
    "sin_expected_shortfall": {
        "detectar":         ["expected_shortfall", "conditional_var", "cvar", "es_99",
                             "tail_risk", "shortfall"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de Expected Shortfall como métrica complementaria",
        "critica": (
            "Solo se detecta VaR, sin Expected Shortfall (ES/CVaR). "
            "El VaR no informa la magnitud de la pérdida MÁS ALLÁ del cuantil y no "
            "es una medida coherente de riesgo (no subaditiva). "
            "Basilea III (FRTB) sustituyó VaR 99% por ES 97.5% precisamente por esto. "
            "Referencia: BCBS d457 §33."
        ),
    },
    "look_ahead_bias": {
        "detectar":         [r"\.shift\(-", "future_", "lead_", r"iloc\[i\+", "target_next",
                             r"rolling\(.*center\s*=\s*True"],
        "detectar_ausencia": False,
        "contexto":         "Posible look-ahead bias (uso de información futura)",
        "critica": (
            "Se detectan patrones que pueden introducir información futura en el "
            "conjunto de entrenamiento (shift negativo, ventanas centradas). "
            "Esto infla artificialmente el desempeño y NO es replicable en producción. "
            "Verificar que toda feature esté disponible en t con información ≤ t. "
            "Referencia: SR 11-7 §V 'Outcomes analysis'."
        ),
    },
    "data_leakage_escalado": {
        "detectar":         [r"fit_transform\(.*X\b(?!_train)", r"scaler\.fit\(X\)",
                             r"StandardScaler\(\)\.fit_transform\(X\)"],
        "detectar_ausencia": False,
        "contexto":         "Posible data leakage por escalado antes del split",
        "critica": (
            "El escalador parece ajustarse sobre TODO el dataset antes de separar "
            "train/test. La media y desviación del test se filtran al entrenamiento. "
            "Correcto: ajustar el scaler SOLO con train y aplicar transform a test, "
            "preferiblemente dentro de un Pipeline de sklearn."
        ),
    },
    "sin_analisis_sensibilidad": {
        "detectar":         ["sensibilidad", "sensitivity", "stress_test", "escenario",
                             "scenario", "shock", "what_if", "montecarlo", "monte_carlo"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de análisis de sensibilidad o escenarios de estrés",
        "critica": (
            "No se detecta análisis de sensibilidad ni pruebas de estrés. "
            "SR 11-7 §IV exige evaluar el comportamiento del modelo ante cambios en "
            "supuestos e inputs clave, especialmente en condiciones adversas. "
            "Incluir al menos: shock de tasas, shock de volatilidad y escenario histórico."
        ),
    },
    "supuesto_correlacion_constante": {
        "detectar":         [r"corr\(\)", "correlation_matrix", "np.corrcoef", "copula",
                             "cholesky"],
        "detectar_ausencia": False,
        "contexto":         "Uso de correlaciones sin validar su estabilidad temporal",
        "critica": (
            "Se emplean correlaciones/cópulas. Verificar que su ESTABILIDAD haya sido "
            "validada: las correlaciones tienden a 1 en episodios de estrés "
            "(contagio), justo cuando la diversificación se necesita. "
            "Evidenciar correlaciones móviles o correlaciones condicionadas a estrés. "
            "Referencia: BCBS 'Principles for sound stress testing' §29."
        ),
    },

    # ══ Patrones originales ═══════════════════════════════════════════════════
    "outliers_zscore": {
        "detectar":         ["zscore", "z_score", "z-score", "scipy.stats.zscore", "3 sigma"],
        "detectar_ausencia": False,
        "contexto":         "Eliminación de outliers con Z-score",
        "critica": (
            "Z-score asume normalidad y es sensible a los propios outliers. "
            "Para datos financieros fat-tail usar: GESD (Generalized ESD), "
            "IQR robusto, Isolation Forest (multivariado) o Mahalanobis Distance."
        ),
    },
    "imputation_mean": {
        # [COBERTURA-FIX] Los patrones originales ('fillna(mean', 'fillna(df.mean')
        # NO capturaban la forma más habitual en pandas: df['x'].fillna(df['x'].mean()).
        # Se sustituyen por regex que cubren fillna(...mean()), fillna(...median())
        # y SimpleImputer con strategy mean/median.
        "detectar": [
            r"fillna\([^)]*\.mean\(",      # df.fillna(df.mean()) / df['x'].fillna(df['x'].mean())
            r"fillna\([^)]*\.median\(",    # idem con mediana
            r"fillna\(\s*mean",            # forma original conservada
            r"fillna\(\s*df\.mean",
            r"simpleimputer[^)]*strategy\s*=\s*['\"](mean|median)",
            r"\.mean\(\)\s*,\s*inplace\s*=\s*True",
        ],
        "detectar_ausencia": False,
        "contexto":         "Imputación de missing con media/mediana aritmética",
        "critica": (
            "Imputar con media destruye varianza e introduce sesgo. "
            "Alternativas: MICE (IterativeImputer), KNN Imputation, MissForest. "
            "Referencia: EBA GL/2021/07 §45."
        ),
    },
    "train_test_split_random": {
        "detectar":         ["train_test_split", "shuffle=True"],
        "detectar_ausencia": False,
        "contexto":         "División aleatoria train/test en datos temporales",
        "critica": (
            "División aleatoria introduce data leakage en datos financieros temporales. "
            "Usar split temporal (OOT) con mínimo 6-12 meses fuera de muestra. SR 11-7."
        ),
    },
    "sin_psi": {
        "detectar":         ["psi", "population_stability", "estabilidad_poblacional"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de análisis PSI",
        "critica": (
            "No se detecta PSI. SR 11-7 y EBA exigen monitoreo de estabilidad. "
            "PSI<0.10: estable | 0.10-0.25: observación | >0.25: rediseño requerido."
        ),
    },
    "sin_backtesting_lar": {
        "detectar":         ["kupiec", "christoffersen", "lopez_test", "berkowitz", "var_backtest"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de backtesting estadístico para modelos de riesgo",
        "critica": (
            "No se detectan pruebas de backtesting (Kupiec, Christoffersen, López). "
            "Requeridas por Basilea III (FRTB) y SR 11-7 para modelos VaR/LaR."
        ),
    },
    "sin_shap_modelos_complejos": {
        "detectar": [
            "XGBClassifier", "LGBMClassifier", "RandomForestClassifier",
            "GradientBoostingClassifier", "xgboost", "lightgbm",
        ],
        "detectar_ausencia": False,
        "contexto":         "Modelos no lineales sin análisis de explicabilidad",
        "critica": (
            "Modelos tree-based sin SHAP values. Incumple SR 11-7 (explicabilidad) "
            "y GDPR art.22. Implementar SHAP para explicabilidad global y local."
        ),
    },
    "sin_replica_virf": {
        "detectar":         ["_replica_virf", "replica_virf"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de script _replica_virf.py de control de calidad de datos",
        "critica": (
            "No se detecta script _replica_virf.py. Este script es el control de "
            "segunda línea para calidad de datos. El agente generará una propuesta."
        ),
    },
}
