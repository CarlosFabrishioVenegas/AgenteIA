/* VIRF Web — guía del procedimiento y ayuda contextual.
 *
 * Tres piezas, todas alimentadas por el mismo catálogo AYUDA:
 *   1. Un «?» junto al título de cada pantalla: abre una ficha con para qué
 *      sirve, qué necesitas y qué obtienes. La primera vez que se abre una
 *      pantalla la ficha aparece sola; después, solo al pulsar el «?».
 *   2. Un círculo «?» fijo abajo a la derecha (o la tecla «?») que abre la
 *      guía completa con el progreso REAL del expediente (/api/guia/progreso).
 *   3. La pantalla de inicio del expediente y las marcas del menú lateral,
 *      que dicen qué está hecho y cuál es el siguiente paso.
 *
 * Se carga después de app.js y solo usa funciones globales de él
 * (pedirJSON, escapeHtml). No escribe nada en el servidor.
 */
"use strict";

const AYUDA = {
    config: {
        num: "01", titulo: "Configuración", nav: "btn-config", vista: "modal-config",
        para: "Indica qué modelo vas a validar (nombre y Tier) y conecta al agente principal, que es GPT.",
        necesitas: ["Las credenciales de GPT: Azure OpenAI (endpoint, deployment y clave) u OpenAI (API key).",
                    "El Tier del modelo: decide qué actividades del estándar aplican.",
                    "Opcional: la API key de Claude para sumarlo como segunda opinión con VIRF PLUS."],
        obtienes: "Una conexión verificada. Pulsa «Verificar conexión» antes de seguir: es una sola llamada mínima.",
        consejo: "La clave se guarda en el .env del proyecto y la comparten todas las sesiones de este equipo.",
    },
    estandares: {
        num: "02", titulo: "Estándares", nav: "btn-estandares", vista: "vista-estandares",
        para: "Carga la lista de actividades contra la que se evaluará el modelo. Es la vara de medir de la validación.",
        necesitas: ["El archivo Estandares_VIRF.xlsx de este modelo."],
        obtienes: "Una vista previa por ámbito. Al aceptarla, queda fijada para esta sesión.",
        consejo: "Revisa la vista previa antes de aceptar: si cambias el estándar después, las corridas dejan de ser comparables.",
    },
    evidencia: {
        num: "03", titulo: "Evidencia", nav: "btn-subir", vista: "vista-upload",
        para: "Reúne todo lo que el agente va a revisar: manuales, código, datos, actas de uso y los Excels de automatización.",
        necesitas: ["Manual metodológico en documentación/modelamiento.",
                    "El código del modelo en un .zip en implementación.",
                    "Opcional: datasets, resultados de calidad de datos y los Excels 00–03."],
        obtienes: "Un árbol con cada archivo y su estado. Tras subir el código puedes pedir el «Entendimiento del modelo».",
        consejo: "Cada tarjeta explica qué acepta. Si dudas dónde va un archivo, ábrela antes de soltarlo.",
    },
    dominio: {
        num: "04", titulo: "Dominio y literatura", nav: "btn-dominio-rag", vista: "vista-rag",
        para: "Elige la literatura técnica con la que el agente contrasta y cuestiona la metodología (VaR, LaR, ALM…).",
        necesitas: ["Nada nuevo si tu dominio ya tiene papers cargados."],
        obtienes: "El índice de búsqueda del dominio, que se usa para citar literatura en el informe.",
        consejo: "Si añades un paper, reconstruye el índice de ese dominio para que el agente lo vea.",
    },
    skills: {
        num: "05", titulo: "Skills", nav: "btn-skills", vista: "vista-skills",
        para: "Activa análisis adicionales (coherencia, supuestos, síntesis…). Producen hallazgos, no cambian el puntaje.",
        necesitas: ["Nada: es opcional."],
        obtienes: "Secciones extra en el informe con lo que cada skill encontró.",
        consejo: "Cada skill añade llamadas a la IA. Activa solo las que vayas a leer.",
    },
    cuestionamientos: {
        num: "06", titulo: "Cuestionamientos", nav: "btn-cuestionamientos", vista: "vista-cuestionamientos",
        para: "Patrones que el agente busca en el código del modelo, más tus propias preguntas metodológicas.",
        necesitas: ["Nada: vienen activos por defecto. Puedes añadir los tuyos en lenguaje natural."],
        obtienes: "Cuestionamientos metodológicos en cada actividad evaluada.",
        consejo: "Escribe tus preguntas como las harías en un comité: concretas y verificables.",
    },
    prevuelo: {
        num: "07", titulo: "Pre-vuelo", nav: "btn-prevuelo", vista: "vista-prevuelo",
        para: "Revisa la evidencia ANTES de validar: qué falta, qué no se puede leer y qué ámbitos quedarían sin sustento.",
        necesitas: ["Haber subido la evidencia."],
        obtienes: "Un diagnóstico por ámbito. Si hay bloqueantes, corrígelos antes de lanzar la validación.",
        consejo: "No llama a la IA: no cuesta nada. Úsalo cada vez que cambies la evidencia.",
    },
    validar: {
        num: "08", titulo: "Validar modelo", nav: "btn-validar", vista: "vista-validar",
        para: "Lanza la evaluación completa: el agente contrasta cada actividad del estándar con la evidencia.",
        necesitas: ["Pasos 01 a 04 completos.", "Nombre y cargo del validador que firma."],
        obtienes: "Un JSON de resultados con puntaje por actividad y por ámbito, visible en «Resultados».",
        consejo: "Puedes seguir la corrida en la consola de esta pantalla. Si la cancelas, no se pierde la evidencia.",
    },
    documentar: {
        num: "09", titulo: "Documentar", nav: "btn-documentar", vista: "vista-documentar",
        para: "Genera el informe de validación en Word y el cuadro de observaciones de las automatizaciones.",
        necesitas: ["Una corrida con resultados.",
                    "Opcional: los Excels 00–03 subidos en «automatizaciones/» para el cuadro."],
        obtienes: "Un .docx versionado (V1, V2…) y el cuadro Ámbito · Riesgo · Observación · Recomendación · Responsable/Fecha.",
        consejo: "Genera primero el cuadro: aparece al inicio del informe. Generar una versión no cierra la sesión.",
    },
    resultados: {
        titulo: "Resultados", nav: "btn-resultados", vista: "vista-resultados",
        para: "Consulta el detalle de cualquier corrida: puntajes, evidencia citada y observaciones.",
        necesitas: ["Al menos una validación terminada."],
        obtienes: "La lectura completa del resultado, actividad por actividad.",
    },
    controles: {
        titulo: "Controles de datos", nav: "btn-controles", vista: "vista-controles",
        para: "Pruebas de calidad de datos y el notebook ejecutable de controles para el entregable.",
        necesitas: ["Datasets o resultados de calidad de datos en la evidencia."],
        obtienes: "Un .ipynb con la tabla de controles lista para revisar.",
    },
    chat: {
        titulo: "Chat de validación", nav: "btn-chat", vista: "vista-chat",
        para: "Sustenta las observaciones pendientes: el área responde y el agente decide si se subsanan.",
        necesitas: ["Un informe de resultados cargado."],
        obtienes: "Cada observación queda aprobada, negada o pendiente, y así pasa al informe.",
    },
};

const ORDEN_PASOS = ["config", "estandares", "evidencia", "dominio", "skills",
                     "cuestionamientos", "prevuelo", "validar", "documentar"];

const ETIQUETA_ESTADO = {
    hecho: "Hecho", en_curso: "En curso", pendiente: "Pendiente",
    opcional: "Opcional", recomendado: "Recomendado",
};

let progreso = null;

// ── Utilidades ───────────────────────────────────────────────────────

function _guardado(clave) {
    try { return localStorage.getItem(clave); } catch { return null; }
}
function _guardar(clave, valor) {
    try { localStorage.setItem(clave, valor); } catch { /* sin almacenamiento */ }
}
function _e(s) { return escapeHtml(String(s ?? "")); }

function irAPaso(id) {
    const a = AYUDA[id];
    if (!a) return;
    cerrarGuia();
    const btn = document.getElementById(a.nav);
    if (btn) btn.click();
}

function fichaHtml(a) {
    return `
        <div class="ficha__fila"><span class="ficha__etq">Para qué sirve</span><p>${_e(a.para)}</p></div>
        <div class="ficha__fila"><span class="ficha__etq">Qué necesitas</span>
            <ul>${a.necesitas.map(n => `<li>${_e(n)}</li>`).join("")}</ul></div>
        <div class="ficha__fila"><span class="ficha__etq">Qué obtienes</span><p>${_e(a.obtienes)}</p></div>
        ${a.consejo ? `<p class="ficha__consejo">${_e(a.consejo)}</p>` : ""}`;
}

// ── 1 · «?» y ficha en cada pantalla ─────────────────────────────────

function botonQ(etiqueta) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "ayuda-q";
    b.textContent = "?";
    b.setAttribute("aria-label", `Ayuda: ${etiqueta}`);
    b.title = "¿Qué hago aquí?";
    return b;
}

function prepararFicha(id) {
    const a = AYUDA[id];
    const cont = document.getElementById(a.vista);
    if (!cont || cont.dataset.ayuda) return;
    cont.dataset.ayuda = id;
    const header = cont.querySelector(".panel__header, .modal__header");
    const titulo = header && header.querySelector(".panel__title, .modal__title");
    if (!header || !titulo) return;

    const ficha = document.createElement("aside");
    ficha.className = "ficha";
    ficha.hidden = true;
    ficha.innerHTML = `
        <div class="ficha__cab">
            <span class="ficha__paso">${a.num ? `Paso ${a.num}` : "Consulta"}</span>
            <button type="button" class="ficha__cerrar" aria-label="Ocultar ayuda">Entendido</button>
        </div>
        ${fichaHtml(a)}`;
    header.insertAdjacentElement("afterend", ficha);

    const q = botonQ(a.titulo);
    titulo.append(q);
    const alternar = (mostrar) => {
        ficha.hidden = !mostrar;
        q.setAttribute("aria-expanded", mostrar ? "true" : "false");
    };
    q.addEventListener("click", () => alternar(ficha.hidden));
    ficha.querySelector(".ficha__cerrar").addEventListener("click", () => {
        alternar(false);
        _guardar(`virf_ayuda_vista_${id}`, "1");
    });

    // Primera visita a la pantalla → la ficha se muestra sola.
    new MutationObserver(() => {
        if (!cont.hidden && !_guardado(`virf_ayuda_vista_${id}`)) alternar(true);
        if (!cont.hidden) refrescarProgreso();
    }).observe(cont, { attributes: true, attributeFilter: ["hidden"] });
}

// ── 2 · Guía lateral con el progreso real ────────────────────────────

function construirGuia() {
    const fab = document.createElement("button");
    fab.type = "button";
    fab.id = "ayuda-fab";
    fab.className = "ayuda-fab";
    fab.textContent = "?";
    fab.setAttribute("aria-label", "Abrir la guía del procedimiento");
    fab.title = "Guía del procedimiento (tecla ?)";
    fab.addEventListener("click", () => (guiaAbierta() ? cerrarGuia() : abrirGuia()));

    const guia = document.createElement("aside");
    guia.id = "guia";
    guia.className = "guia";
    guia.hidden = true;
    guia.setAttribute("aria-label", "Guía del procedimiento");
    guia.innerHTML = `
        <header class="guia__cab">
            <div>
                <div class="guia__eyebrow">Guía</div>
                <h2 class="guia__titulo">Cómo validar este modelo</h2>
            </div>
            <button type="button" class="btn-ghost" id="guia-cerrar" aria-label="Cerrar guía">✕</button>
        </header>
        <div class="guia__progreso" id="guia-progreso"></div>
        <ol class="guia__pasos" id="guia-pasos"></ol>
        <footer class="guia__pie">
            Los pasos 05 a 07 son opcionales. Pulsa <kbd>?</kbd> en cualquier momento para volver aquí.
        </footer>`;
    document.body.append(fab, guia);
    guia.querySelector("#guia-cerrar").addEventListener("click", cerrarGuia);

    document.addEventListener("keydown", (ev) => {
        const t = ev.target;
        const escribiendo = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
        if (ev.key === "?" && !escribiendo && dashboardVisible()) { ev.preventDefault(); abrirGuia(); }
        if (ev.key === "Escape" && guiaAbierta()) cerrarGuia();
    });
}

function dashboardVisible() {
    const d = document.getElementById("pantalla-dashboard");
    return d && !d.hidden;
}
function guiaAbierta() { return !document.getElementById("guia").hidden; }
function cerrarGuia() {
    document.getElementById("guia").hidden = true;
    document.getElementById("ayuda-fab").setAttribute("aria-expanded", "false");
}
async function abrirGuia() {
    document.getElementById("guia").hidden = false;
    document.getElementById("ayuda-fab").setAttribute("aria-expanded", "true");
    pintarGuia();
    await refrescarProgreso();
}

function estadoDe(id) {
    const p = progreso && progreso.pasos.find(x => x.id === id);
    return p || { estado: "pendiente", detalle: "", obligatorio: true };
}

function barraHtml() {
    if (!progreso) return `<div class="guia__barra"><span style="width:0"></span></div>`;
    const pct = Math.round(100 * progreso.hechos / progreso.total);
    return `
        <div class="guia__cifra"><strong>${progreso.hechos}</strong> de ${progreso.total} pasos obligatorios</div>
        <div class="guia__barra" role="progressbar" aria-valuemin="0" aria-valuemax="${progreso.total}"
             aria-valuenow="${progreso.hechos}"><span style="width:${pct}%"></span></div>`;
}

function pintarGuia() {
    const lista = document.getElementById("guia-pasos");
    if (!lista) return;
    document.getElementById("guia-progreso").innerHTML = barraHtml();
    const sig = progreso && progreso.siguiente;
    lista.innerHTML = ORDEN_PASOS.map(id => {
        const a = AYUDA[id], st = estadoDe(id);
        const abierto = id === sig;
        return `
            <li class="guia__paso guia__paso--${st.estado}${abierto ? " es-siguiente" : ""}">
              <details ${abierto ? "open" : ""}>
                <summary>
                  <span class="guia__num">${a.num}</span>
                  <span class="guia__nombre">${_e(a.titulo)}</span>
                  <span class="estado-pill estado-pill--${st.estado}">${abierto ? "Siguiente" : ETIQUETA_ESTADO[st.estado] || ""}</span>
                </summary>
                <div class="guia__cuerpo">
                  ${st.detalle ? `<p class="guia__detalle">${_e(st.detalle)}</p>` : ""}
                  ${fichaHtml(a)}
                  <button type="button" class="btn ${abierto ? "btn--primary" : ""}" data-ir="${id}">Ir a ${_e(a.titulo)}</button>
                </div>
              </details>
            </li>`;
    }).join("");
    for (const b of lista.querySelectorAll("[data-ir]")) {
        b.addEventListener("click", () => irAPaso(b.dataset.ir));
    }
}

// ── 3 · Inicio del expediente y marcas del menú ──────────────────────

function pintarInicio() {
    const vacia = document.getElementById("vista-vacia");
    if (!vacia) return;
    const sig = progreso ? progreso.siguiente : "config";
    const modelo = (document.getElementById("modelo-actual") || {}).textContent || "";
    if (!sig) {
        vacia.innerHTML = `
            <div class="inicio">
              <div class="guia__eyebrow">Expediente ${_e(modelo)}</div>
              <h2 class="inicio__titulo">Validación documentada.</h2>
              <p class="inicio__texto">Todos los pasos obligatorios están completos. Puedes revisar los
                 resultados, sustentar observaciones en el chat o generar una versión nueva del informe.</p>
              ${barraHtml()}
              <div class="inicio__acciones">
                <button type="button" class="btn btn--primary" data-ir="documentar">Ir a Documentar</button>
                <button type="button" class="btn" data-guia>Ver la guía</button>
              </div>
            </div>`;
    } else {
        const a = AYUDA[sig];
        const st = estadoDe(sig);
        vacia.innerHTML = `
            <div class="inicio">
              <div class="guia__eyebrow">Expediente ${_e(modelo)}</div>
              <h2 class="inicio__titulo">${progreso && progreso.hechos
                  ? "Sigamos donde lo dejaste." : "Empecemos la validación."}</h2>
              ${barraHtml()}
              <div class="inicio__siguiente">
                <div class="inicio__etq">Siguiente paso · ${a.num}</div>
                <div class="inicio__paso">${_e(a.titulo)}</div>
                <p class="inicio__texto">${_e(a.para)}</p>
                ${st.detalle ? `<p class="guia__detalle">${_e(st.detalle)}</p>` : ""}
                <div class="inicio__acciones">
                  <button type="button" class="btn btn--primary" data-ir="${sig}">Ir a ${_e(a.titulo)}</button>
                  <button type="button" class="btn" data-guia>Ver todos los pasos</button>
                </div>
              </div>
            </div>`;
    }
    for (const b of vacia.querySelectorAll("[data-ir]")) b.addEventListener("click", () => irAPaso(b.dataset.ir));
    for (const b of vacia.querySelectorAll("[data-guia]")) b.addEventListener("click", abrirGuia);
}

function marcarMenu() {
    for (const id of Object.keys(AYUDA)) {
        const a = AYUDA[id];
        const btn = document.getElementById(a.nav);
        if (!btn) continue;
        btn.title = a.para;
        const st = progreso ? estadoDe(id).estado : null;
        if (st) btn.dataset.estado = st; else delete btn.dataset.estado;
        btn.classList.toggle("es-siguiente", !!progreso && progreso.siguiente === id);
    }
}

let _refrescando = null;
async function refrescarProgreso() {
    if (!dashboardVisible()) return;
    if (_refrescando) return _refrescando;
    _refrescando = (async () => {
        try {
            progreso = await pedirJSON("/api/guia/progreso");
        } catch {
            progreso = null;   // sin sesión o sin modelo: la guía sigue sirviendo como manual
        }
        marcarMenu();
        pintarInicio();
        if (guiaAbierta()) pintarGuia();
    })();
    try { await _refrescando; } finally { _refrescando = null; }
}

// ── Arranque ─────────────────────────────────────────────────────────

function iniciarGuia() {
    construirGuia();
    for (const id of Object.keys(AYUDA)) prepararFicha(id);

    const dash = document.getElementById("pantalla-dashboard");
    if (dash) {
        new MutationObserver(() => {
            if (dash.hidden) { cerrarGuia(); return; }
            refrescarProgreso().then(() => {
                // Primera vez en la herramienta → la guía se abre sola.
                if (!_guardado("virf_guia_vista")) { _guardar("virf_guia_vista", "1"); abrirGuia(); }
            });
        }).observe(dash, { attributes: true, attributeFilter: ["hidden"] });
        if (!dash.hidden) refrescarProgreso();
    }
    const vacia = document.getElementById("vista-vacia");
    if (vacia) {
        new MutationObserver(() => { if (!vacia.hidden) refrescarProgreso(); })
            .observe(vacia, { attributes: true, attributeFilter: ["hidden"] });
    }
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciarGuia);
else iniciarGuia();
