"""
Prompts editables por sesión (v2.3).

Fuente única de prompts para el pipeline:
  - prompts_base.json (defaults, extraídos del código real)
  - sesion/prompts_custom.json (overrides por validador+modelo)

Prioridad: custom de la sesión > base. Si el validador restaura, se
borra la entrada custom y vuelve el default.

Los prompts con `modo: template` conservan {placeholders} — al guardar
se valida que los que declara el base sigan presentes.
"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from ..config_web import WEB_DIR

BASE_PATH = WEB_DIR / "data" / "prompts_base.json"
NOMBRE_FICHERO_SESION = "prompts_custom.json"

_lock = threading.Lock()
_cache_base: Optional[dict[str, Any]] = None


def _cargar_base() -> dict[str, Any]:
    global _cache_base
    if _cache_base is None:
        _cache_base = json.loads(BASE_PATH.read_text(encoding="utf-8"))
    return _cache_base


def prompts_base() -> dict[str, Any]:
    """Todos los prompts base con metadatos (para el GET del router)."""
    return _cargar_base()


def _ruta_custom(ctx: dict) -> Path:
    return ctx["base"] / NOMBRE_FICHERO_SESION


def _leer_custom(ctx: dict) -> dict[str, Any]:
    p = _ruta_custom(ctx)
    if not p.is_file():
        return {}
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _escribir_custom(ctx: dict, data: dict[str, Any]) -> None:
    p = _ruta_custom(ctx)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _ahora() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def prompts_efectivos(ctx: dict) -> dict[str, Any]:
    """Base + overrides de la sesión, con marca de cuál está personalizado."""
    base = _cargar_base()
    custom = _leer_custom(ctx)
    salida = {}
    for pid, meta in base.items():
        entrada = dict(meta)
        if pid in custom and "contenido" in custom[pid]:
            entrada["contenido"] = custom[pid]["contenido"]
            entrada["es_custom"] = True
            entrada["editado_por"] = custom[pid].get("editado_por")
            entrada["fecha_edicion"] = custom[pid].get("fecha_edicion")
            entrada["chars_original"] = len(meta["contenido"])
            entrada["chars_actual"] = len(custom[pid]["contenido"])
        else:
            entrada["es_custom"] = False
        salida[pid] = entrada
    return salida


def get_prompt(ctx: dict, prompt_id: str) -> str:
    """Devuelve el contenido efectivo (custom si existe, si no el base)."""
    base = _cargar_base()
    if prompt_id not in base:
        raise KeyError(f"prompt '{prompt_id}' no está en prompts_base.json")
    custom = _leer_custom(ctx)
    if prompt_id in custom and "contenido" in custom[prompt_id]:
        return custom[prompt_id]["contenido"]
    return base[prompt_id]["contenido"]


# ── Validación de placeholders ────────────────────────────────────────

_RE_PLACEHOLDER = re.compile(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}")


def _placeholders_en(texto: str) -> set[str]:
    return set(_RE_PLACEHOLDER.findall(texto or ""))


def editar_prompt(ctx: dict, prompt_id: str, contenido: str,
                   editor: str) -> dict[str, Any]:
    """
    Guarda un override para la sesión. Devuelve la entrada resultante.

    Reglas:
      - `editable` debe ser True en la base (evaluacion_ambito es readonly).
      - Si el modo es 'template', el contenido debe conservar TODOS los
        placeholders que declara la base. Los renombrados se rechazan.
      - Si `contenido` es idéntico al base, se restaura (borra el custom).
    """
    base = _cargar_base()
    if prompt_id not in base:
        raise KeyError(f"prompt '{prompt_id}' no existe")
    meta = base[prompt_id]
    if not meta.get("editable", False):
        raise PermissionError(
            f"prompt '{prompt_id}' no es editable (modo: {meta.get('modo')})")
    if meta.get("modo") == "template":
        requeridos = set(meta.get("placeholders", []))
        actuales   = _placeholders_en(contenido)
        faltantes  = requeridos - actuales
        if faltantes:
            raise ValueError(
                f"faltan placeholders obligatorios: {sorted(faltantes)}. "
                f"Todos los declarados por la base deben aparecer como {{nombre}}.")
    if (contenido or "") == meta["contenido"]:
        return restaurar_prompt(ctx, prompt_id)
    with _lock:
        custom = _leer_custom(ctx)
        entrada = {
            "contenido":     contenido,
            "editado_por":   editor,
            "fecha_edicion": _ahora(),
        }
        custom[prompt_id] = entrada
        _escribir_custom(ctx, custom)
    salida = dict(meta)
    salida.update(entrada)
    salida["es_custom"] = True
    salida["chars_original"] = len(meta["contenido"])
    salida["chars_actual"]   = len(contenido)
    return salida


def restaurar_prompt(ctx: dict, prompt_id: str) -> dict[str, Any]:
    """Elimina el override. Idempotente."""
    base = _cargar_base()
    if prompt_id not in base:
        raise KeyError(f"prompt '{prompt_id}' no existe")
    with _lock:
        custom = _leer_custom(ctx)
        custom.pop(prompt_id, None)
        _escribir_custom(ctx, custom)
    salida = dict(base[prompt_id])
    salida["es_custom"] = False
    return salida


def clear_cache_para_tests() -> None:
    """Los tests recargan prompts_base.json cuando lo modifican."""
    global _cache_base
    _cache_base = None
