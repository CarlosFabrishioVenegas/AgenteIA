"""
Análisis estructural del ZIP de implementación (Mejora 4 · v2.2).

Dos capas:

1. **estructural** — sin IA, coste 0. AST para .py (funciones, clases,
   imports), líneas para .sql/.R, celdas para .ipynb. Devuelve el árbol
   completo con conteos y grafo de imports.

2. **entendimiento** — con IA. Llama a `_llamar_modelo` con un prompt
   que pide el documento de entendimiento en Markdown. Sin API activa,
   genera un mock coherente basado en la estructura real (para que el
   docx tenga qué renderizar y el operador vea el flujo end-to-end).

Persistencia:
- `sesion.base/entendimiento_modelo.md`
- `sesion.base/feedback_entendimiento.json`
"""
from __future__ import annotations

import ast
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

_EXT_CODIGO = (".py", ".ipynb", ".sql", ".r")
_MAX_CHARS_POR_FICHERO = 6000        # cap por fichero al enviar al modelo
_MAX_CHARS_TOTAL       = 30000       # cap agregado


# ── Análisis estructural (AST + parseo simple) ────────────────────────

def _analizar_py(ruta: Path) -> dict[str, Any]:
    """Extrae funciones, clases e imports de un .py con AST."""
    try:
        codigo = ruta.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return {"error": str(exc), "lineas": 0, "funciones": [], "clases": [], "imports": []}
    try:
        arbol = ast.parse(codigo)
    except SyntaxError as exc:
        return {"error": f"SyntaxError: {exc.msg}", "lineas": codigo.count("\n"),
                "funciones": [], "clases": [], "imports": []}
    funciones: list[str] = []
    clases: list[str] = []
    imports: list[str] = []
    for nodo in ast.walk(arbol):
        if isinstance(nodo, ast.FunctionDef):
            funciones.append(nodo.name)
        elif isinstance(nodo, ast.AsyncFunctionDef):
            funciones.append(nodo.name)
        elif isinstance(nodo, ast.ClassDef):
            clases.append(nodo.name)
        elif isinstance(nodo, ast.Import):
            for a in nodo.names:
                imports.append(a.name.split(".")[0])
        elif isinstance(nodo, ast.ImportFrom):
            if nodo.module:
                imports.append(nodo.module.split(".")[0])
    return {
        "lineas":    codigo.count("\n") + 1,
        "funciones": funciones,
        "clases":    clases,
        "imports":   sorted(set(imports)),
    }


def _analizar_ipynb(ruta: Path) -> dict[str, Any]:
    """Cuenta celdas y extrae imports+defs del código Python."""
    try:
        nb = json.loads(ruta.read_text(encoding="utf-8", errors="replace"))
    except (OSError, json.JSONDecodeError) as exc:
        return {"error": str(exc), "celdas_codigo": 0, "celdas_md": 0,
                "funciones": [], "clases": [], "imports": []}
    celdas = nb.get("cells", []) or []
    codigo_agregado = ""
    n_c = n_m = 0
    for c in celdas:
        tipo = c.get("cell_type")
        if tipo == "code":
            n_c += 1
            codigo_agregado += "\n" + "".join(c.get("source", []))
        elif tipo == "markdown":
            n_m += 1
    funciones, clases, imports = [], [], []
    try:
        arbol = ast.parse(codigo_agregado)
        for n in ast.walk(arbol):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                funciones.append(n.name)
            elif isinstance(n, ast.ClassDef):
                clases.append(n.name)
            elif isinstance(n, ast.Import):
                for a in n.names: imports.append(a.name.split(".")[0])
            elif isinstance(n, ast.ImportFrom) and n.module:
                imports.append(n.module.split(".")[0])
    except SyntaxError:
        pass
    return {
        "celdas_codigo": n_c, "celdas_md": n_m,
        "lineas":        codigo_agregado.count("\n") + 1,
        "funciones":     funciones, "clases": clases,
        "imports":       sorted(set(imports)),
    }


def _analizar_generico(ruta: Path) -> dict[str, Any]:
    try:
        t = ruta.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return {"error": str(exc), "lineas": 0}
    return {"lineas": t.count("\n") + 1}


def estructura(base_impl: Path) -> dict[str, Any]:
    """
    Recorre `base_impl` y devuelve el mapa estructural entero.
    `base_impl` es el directorio `<sesion>/inputs/implementacion/`.
    """
    if not base_impl.is_dir():
        return {"archivos": [], "totales": {"archivos": 0, "lineas": 0,
                                            "funciones": 0, "clases": 0}}

    archivos: list[dict[str, Any]] = []
    tot_lineas = tot_funciones = tot_clases = 0
    for p in sorted(base_impl.rglob("*")):
        if not p.is_file():
            continue
        ext = p.suffix.lower()
        if ext not in _EXT_CODIGO:
            continue
        rel = p.relative_to(base_impl).as_posix()
        if ext == ".py":
            info = _analizar_py(p)
        elif ext == ".ipynb":
            info = _analizar_ipynb(p)
        else:
            info = _analizar_generico(p)
        info["ruta"] = rel
        info["extension"] = ext
        archivos.append(info)
        tot_lineas    += int(info.get("lineas", 0))
        tot_funciones += len(info.get("funciones", []))
        tot_clases    += len(info.get("clases", []))
    return {
        "archivos": archivos,
        "totales":  {
            "archivos":   len(archivos),
            "lineas":     tot_lineas,
            "funciones":  tot_funciones,
            "clases":     tot_clases,
        },
    }


# ── Prompt del entendimiento ─────────────────────────────────────────

_PROMPT_ENTENDIMIENTO = """\
Eres un ingeniero senior de validación de modelos de riesgo financiero.
Te entrego la estructura completa del código de un modelo llamado
{nombre_modelo} del dominio {dominio}.

ESTRUCTURA (AST):
{arbol_estructural}

CONTENIDO DE LOS ARCHIVOS (truncado por fichero a {max_por_fichero} chars):
{contenido_agregado}

{bloque_feedback}
Genera un documento de ENTENDIMIENTO DEL MODELO en Markdown con esta
estructura EXACTA:

# Entendimiento del modelo {nombre_modelo}

## 1. Visión general
3-5 oraciones: qué hace el modelo, tipo (estadístico, ML, simulación),
variable objetivo, horizonte. Nada especulativo — solo lo que se deduce
del código.

## 2. Arquitectura del código
Diagrama textual del flujo entre módulos:
```
mod_a.py → mod_b.py → mod_c.py
```

## 3. Flujo de datos
Dónde entran los datos, transformaciones, dónde salen. Cita archivo:línea.

## 4. Módulos principales
Por cada archivo relevante: propósito (1 línea), funciones/clases clave,
dependencias.

## 5. Modelo matemático/estadístico
Qué técnica, qué supuestos, qué parámetros. Cita archivo:línea donde se
implementa. Si no queda claro del código, dilo.

## 6. Puntos de atención para la validación
Cosas que un validador debería revisar con cuidado.

## 7. Resumen de archivos
| Archivo | Líneas | Propósito |
|---|---|---|
| ... | ... | ... |

Sé concreto. Cita archivo:línea. No inventes funciones que no existan.
"""


def _armar_prompt(nombre_modelo: str, dominio: str, est: dict,
                   feedbacks: list[dict], base_impl: Path,
                   ctx: Optional[dict] = None) -> str:
    lineas_arbol = []
    for a in est["archivos"]:
        cabecera = f"- {a['ruta']} ({a.get('lineas',0)} L)"
        if a.get("funciones"):
            cabecera += f", funciones: {', '.join(a['funciones'][:12])}"
            if len(a.get("funciones", [])) > 12:
                cabecera += f" … (+{len(a['funciones'])-12})"
        if a.get("clases"):
            cabecera += f", clases: {', '.join(a['clases'][:8])}"
        lineas_arbol.append(cabecera)
    arbol_estructural = "\n".join(lineas_arbol) or "(sin archivos)"

    # Contenido agregado con cap por fichero y total.
    trozos, total = [], 0
    for a in est["archivos"]:
        if total >= _MAX_CHARS_TOTAL:
            break
        p = base_impl / a["ruta"]
        try:
            t = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        t = t[:_MAX_CHARS_POR_FICHERO]
        trozos.append(f"\n── FILE: {a['ruta']} ──────────────────────\n{t}")
        total += len(t)
    contenido_agregado = "\n".join(trozos) if trozos else "(sin contenido)"

    bloque_feedback = ""
    if feedbacks:
        bloque_feedback = "CORRECCIONES PREVIAS DEL VALIDADOR:\n"
        for f in feedbacks[-6:]:
            bloque_feedback += f"- ({f.get('timestamp','')}) {f.get('comentario','')}\n"
        bloque_feedback += "\nIntegra estas correcciones donde apliquen.\n\n"

    # v2.3 — usa el prompt editado por el validador si existe.
    template = _PROMPT_ENTENDIMIENTO
    if ctx is not None:
        try:
            from . import prompt_service
            template = prompt_service.get_prompt(ctx, "entendimiento_modelo")
        except (KeyError, OSError):
            pass
    return template.format(
        nombre_modelo=nombre_modelo, dominio=dominio,
        arbol_estructural=arbol_estructural,
        contenido_agregado=contenido_agregado,
        bloque_feedback=bloque_feedback,
        max_por_fichero=_MAX_CHARS_POR_FICHERO,
    )


def _mock_entendimiento(nombre_modelo: str, dominio: str, est: dict) -> str:
    """
    Salida canned SIN API. Aprovecha la estructura real para que el
    contenido sea coherente con lo subido (no un placeholder inerte).
    """
    lineas = [f"# Entendimiento del modelo {nombre_modelo}", "",
              "> _MOCK generado sin API activa (`VIRF_MOCK_CHAT=1`). El texto es "
              "una plantilla estructurada sobre la información AST real; el "
              "contenido narrativo llegará cuando haya saldo del proveedor._", "",
              "## 1. Visión general", "",
              f"Modelo del dominio **{dominio}** con "
              f"{est['totales']['archivos']} ficheros de código, "
              f"{est['totales']['funciones']} funciones y "
              f"{est['totales']['clases']} clases. "
              "La narrativa específica del propósito requiere el proveedor IA.",
              "", "## 2. Arquitectura del código", "",
              "```",
              " → ".join(a["ruta"] for a in est["archivos"][:6]) or "(sin ficheros)",
              "```", "",
              "## 3. Flujo de datos", "",
              "_Pendiente de análisis por IA._", "",
              "## 4. Módulos principales", ""]
    for a in est["archivos"]:
        lineas.append(f"### `{a['ruta']}`")
        lineas.append(f"- Líneas: {a.get('lineas','—')}")
        if a.get("funciones"):
            lineas.append(f"- Funciones: `{'`, `'.join(a['funciones'][:10])}`")
        if a.get("clases"):
            lineas.append(f"- Clases: `{'`, `'.join(a['clases'][:6])}`")
        if a.get("imports"):
            lineas.append(f"- Imports: {', '.join(a['imports'][:8])}")
        lineas.append("")
    lineas += ["## 5. Modelo matemático/estadístico", "",
               "_Requiere análisis por IA._", "",
               "## 6. Puntos de atención para la validación", "",
               "- Revisar supuestos implícitos en los `def`s detectados.",
               "- Verificar valores hardcodeados en los módulos.",
               "- Cobertura de tests si existe.", "",
               "## 7. Resumen de archivos", "",
               "| Archivo | Líneas | Propósito |", "|---|---|---|"]
    for a in est["archivos"]:
        lineas.append(f"| `{a['ruta']}` | {a.get('lineas','—')} | _(pendiente)_ |")
    return "\n".join(lineas)


def generar_entendimiento(ctx: dict, feedbacks: Optional[list[dict]] = None,
                           forzar_mock: bool = False) -> str:
    """
    Genera el documento .md de entendimiento. Devuelve el texto.
    - Sin API (o forzar_mock=True): usa `_mock_entendimiento`.
    - Con API: llama a `_llamar_modelo` y devuelve la respuesta.
    """
    base_impl = ctx["inputs"] / "implementacion"
    est = estructura(base_impl)
    nombre_modelo = ctx["modelo"]["nombre"]
    dominio       = ctx["modelo"].get("dominio", "shared")

    if forzar_mock or os.environ.get("VIRF_MOCK_CHAT") == "1":
        return _mock_entendimiento(nombre_modelo, dominio, est)

    prompt = _armar_prompt(nombre_modelo, dominio, est, feedbacks or [], base_impl, ctx=ctx)
    try:
        from Mx_03_LlamarIA import _llamar_modelo
        salida = _llamar_modelo(prompt=prompt, max_tokens=2500, temperatura=0.0)
    except Exception as exc:                        # noqa: BLE001
        # Fallback: mock con nota del fallo — nunca callar el problema.
        return (f"# Entendimiento del modelo {nombre_modelo}\n\n"
                f"> _No se pudo consultar al proveedor IA: {exc}. Se muestra el "
                "mock estructural mientras se soluciona la conexión._\n\n"
                + _mock_entendimiento(nombre_modelo, dominio, est))
    return (salida or "").strip() or _mock_entendimiento(nombre_modelo, dominio, est)


# ── Persistencia ─────────────────────────────────────────────────────

def ruta_md(ctx: dict) -> Path:
    return ctx["base"] / f"entendimiento_modelo_{ctx['modelo']['slug']}.md"


def ruta_feedback(ctx: dict) -> Path:
    return ctx["base"] / "feedback_entendimiento.json"


def guardar_md(ctx: dict, contenido: str) -> Path:
    ctx["base"].mkdir(parents=True, exist_ok=True)
    p = ruta_md(ctx)
    p.write_text(contenido, encoding="utf-8")
    return p


def leer_md(ctx: dict) -> Optional[str]:
    p = ruta_md(ctx)
    if not p.is_file():
        return None
    try:
        return p.read_text(encoding="utf-8")
    except OSError:
        return None


def leer_feedbacks(ctx: dict) -> list[dict]:
    p = ruta_feedback(ctx)
    if not p.is_file():
        return []
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    return d if isinstance(d, list) else []


def agregar_feedback(ctx: dict, comentario: str, seccion: Optional[str] = None) -> dict:
    fbs = leer_feedbacks(ctx)
    entrada = {
        "timestamp": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "comentario": (comentario or "").strip(),
        "seccion":   (seccion or "").strip() or None,
    }
    if not entrada["comentario"]:
        raise ValueError("el comentario está vacío")
    fbs.append(entrada)
    ctx["base"].mkdir(parents=True, exist_ok=True)
    ruta_feedback(ctx).write_text(
        json.dumps(fbs, ensure_ascii=False, indent=2), encoding="utf-8")
    return entrada
