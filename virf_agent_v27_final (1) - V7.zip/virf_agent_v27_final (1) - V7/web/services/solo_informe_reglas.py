"""
Compatibilidad: las reglas de calificación viven en `modulos.reglas_informe`
porque también las usa el entregable del pipeline, que no puede importar `web/`.
"""
from modulos.reglas_informe import *          # noqa: F401,F403
from modulos.reglas_informe import (          # noqa: F401  (nombres «privados» usados por el servicio)
    _CLAVES_AMBITO, _GRAVEDAD, _sin_tildes,
)
