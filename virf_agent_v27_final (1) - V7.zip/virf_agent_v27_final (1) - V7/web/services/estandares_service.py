"""
Estándares de validación por sesión (v2.4).

Cada validador puede subir SU Estandares.xlsx para el modelo activo, en
lugar de heredar el global fijo del proyecto. La regla arquitectónica
(motor/Mx_00_CargaRutas.py:80) es explícita: no se detecta el estándar
alternativo por heurística, se pasa vía flag `--estandares <path>` a
`agente.py`. Este servicio prepara ese fichero en la sesión y devuelve
la ruta que `pipeline_runner` inyecta al subprocess.

Persistencia:
  sesion/inputs/estandares/estandares_validacion.xlsx   (bytes originales)
  sesion/inputs/estandares/estandares_procesados.json   (parseado + confirmado)

El parseo respeta celdas combinadas: AMBITO y CONTROL se propagan desde
la última fila con valor no vacío hasta que aparezca uno nuevo (openpyxl
no expande merged cells; iter_rows devuelve solo el vértice superior-
izquierdo con valor y el resto como None).
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

COLUMNAS_ESPERADAS = ("AMBITO", "CONTROL CUANTITATIVO Y CUALITATIVO", "ACTIVIDAD",
                       "TIER I", "TIER II", "TIER III", "TIER IV")

NOMBRE_XLSX = "estandares_validacion.xlsx"
NOMBRE_JSON = "estandares_procesados.json"


# ── Rutas por sesión ─────────────────────────────────────────────────

def carpeta(ctx: dict) -> Path:
    return ctx["inputs"] / "estandares"


def ruta_xlsx(ctx: dict) -> Path:
    return carpeta(ctx) / NOMBRE_XLSX


def ruta_json(ctx: dict) -> Path:
    return carpeta(ctx) / NOMBRE_JSON


# ── Parseo ────────────────────────────────────────────────────────────

class EstandarInvalido(ValueError):
    """El .xlsx no tiene el formato esperado."""


def _normalizar_marca(v: Any) -> bool:
    """Cualquier valor no vacío cuenta como 'aplica'; vacío o None cuenta como no."""
    if v is None:
        return False
    s = str(v).strip()
    return bool(s) and s.lower() not in ("no", "n", "false", "0")


def _cabeceras_ok(fila: tuple) -> tuple[dict[str, int], list[str]]:
    """
    Mapea cabeceras del Excel a índices de columna. Tolera espacios extra
    y mayúsculas/minúsculas. Devuelve (mapping, faltantes).
    """
    normalizada = [(str(c).strip().upper() if c is not None else "") for c in fila]
    mapping = {}
    for esperada in COLUMNAS_ESPERADAS:
        clave = esperada.strip().upper()
        if clave in normalizada:
            mapping[esperada] = normalizada.index(clave)
    faltantes = [c for c in COLUMNAS_ESPERADAS if c not in mapping]
    return mapping, faltantes


def parsear(xlsx_path: Path) -> dict[str, Any]:
    """
    Lee el Excel y devuelve el árbol {ambito: [{control, actividades}]}.

    Lanza `EstandarInvalido` si:
      - No se puede abrir como .xlsx.
      - Falta alguna cabecera obligatoria.
      - No hay ninguna actividad no vacía.
    """
    try:
        wb = load_workbook(str(xlsx_path), read_only=True, data_only=True)
    except Exception as exc:                     # noqa: BLE001
        raise EstandarInvalido(f"no se pudo abrir el .xlsx: {exc}")
    ws = wb.active
    # Materializamos las filas antes de cerrar el workbook. En modo read_only
    # openpyxl mantiene el handle abierto mientras el generador exista, y en
    # Windows eso bloquea el borrado del fichero (limpiar() luego falla).
    todas = list(ws.iter_rows(values_only=True))
    wb.close()
    if not todas:
        raise EstandarInvalido("el Excel está vacío")
    cabecera = todas[0]
    filas = iter(todas[1:])
    mapping, faltantes = _cabeceras_ok(cabecera)
    if faltantes:
        raise EstandarInvalido(
            f"faltan columnas obligatorias: {faltantes}. "
            f"Cabeceras encontradas: {[str(c) for c in cabecera]}")

    i_amb = mapping["AMBITO"]
    i_ctl = mapping["CONTROL CUANTITATIVO Y CUALITATIVO"]
    i_act = mapping["ACTIVIDAD"]
    i_t1  = mapping["TIER I"]
    i_t2  = mapping["TIER II"]
    i_t3  = mapping["TIER III"]
    i_t4  = mapping["TIER IV"]

    ambitos: dict[str, dict[str, list[dict]]] = {}
    orden_ambitos: list[str] = []
    ultimo_ambito = ""
    ultimo_control = ""

    for fila in filas:
        if not fila:
            continue
        # openpyxl deja None en las celdas combinadas debajo del vértice: se
        # propaga el último valor no vacío. Es exactamente el patrón que
        # documenta la spec y que no se puede evitar sin expandir merges.
        v_amb = fila[i_amb] if i_amb < len(fila) else None
        v_ctl = fila[i_ctl] if i_ctl < len(fila) else None
        v_act = fila[i_act] if i_act < len(fila) else None
        if v_amb is not None and str(v_amb).strip():
            ultimo_ambito = str(v_amb).strip()
        if v_ctl is not None and str(v_ctl).strip():
            ultimo_control = str(v_ctl).strip()
        if v_act is None or not str(v_act).strip():
            continue
        actividad = str(v_act).strip()
        if not ultimo_ambito or not ultimo_control:
            # actividad huérfana antes del primer ámbito/control: se ignora en
            # vez de fallar, pero el resumen la refleja
            continue
        if ultimo_ambito not in ambitos:
            ambitos[ultimo_ambito] = {}
            orden_ambitos.append(ultimo_ambito)
        controles = ambitos[ultimo_ambito]
        if ultimo_control not in controles:
            controles[ultimo_control] = []
        controles[ultimo_control].append({
            "descripcion": actividad,
            "tier_1": _normalizar_marca(fila[i_t1] if i_t1 < len(fila) else None),
            "tier_2": _normalizar_marca(fila[i_t2] if i_t2 < len(fila) else None),
            "tier_3": _normalizar_marca(fila[i_t3] if i_t3 < len(fila) else None),
            "tier_4": _normalizar_marca(fila[i_t4] if i_t4 < len(fila) else None),
        })

    if not ambitos:
        raise EstandarInvalido(
            "no se encontró ninguna actividad válida. "
            "Verifica que las columnas AMBITO/CONTROL/ACTIVIDAD tengan valores.")

    # Serializar en el orden de aparición para que el frontend respete el
    # orden del Excel.
    estandares = []
    total_actividades = 0
    for amb in orden_ambitos:
        bloque_controles = []
        for ctrl_nombre, actividades in ambitos[amb].items():
            bloque_controles.append({
                "nombre":      ctrl_nombre,
                "actividades": actividades,
            })
            total_actividades += len(actividades)
        estandares.append({"ambito": amb, "controles": bloque_controles})

    return {
        "summary": {
            "total_actividades": total_actividades,
            "total_ambitos":     len(orden_ambitos),
            "ambitos":           orden_ambitos,
        },
        "estandares": estandares,
    }


# ── Persistencia ──────────────────────────────────────────────────────

def guardar_xlsx(ctx: dict, contenido: bytes) -> Path:
    dst = ruta_xlsx(ctx)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(contenido)
    return dst


def confirmar(ctx: dict, parseado: dict[str, Any], validador: str) -> dict[str, Any]:
    """
    Marca el estándar como confirmado y lo guarda en JSON. Este JSON es
    lo que consumen los pasos posteriores (pipeline, chat, informe).
    """
    doc = {
        **parseado,
        "confirmado":     True,
        "confirmado_por": validador,
        "confirmado_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "fichero":        NOMBRE_XLSX,
    }
    dst = ruta_json(ctx)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")
    return doc


def estado(ctx: dict) -> dict[str, Any]:
    """
    Devuelve el estado del paso 02 para la sesión:
      - `subido`:       hay un .xlsx en la sesión (aunque no esté confirmado)
      - `confirmado`:   hay un JSON procesado
      - `summary`:      resumen si está confirmado
      - `ruta_xlsx`:    ruta que se pasará al subprocess vía --estandares
    """
    xlsx = ruta_xlsx(ctx)
    json_p = ruta_json(ctx)
    d: dict[str, Any] = {
        "subido":     xlsx.is_file(),
        "confirmado": False,
        "ruta_xlsx":  str(xlsx) if xlsx.is_file() else None,
    }
    if json_p.is_file():
        try:
            doc = json.loads(json_p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            doc = None
        if doc:
            d["confirmado"]     = bool(doc.get("confirmado"))
            d["summary"]        = doc.get("summary")
            d["confirmado_por"] = doc.get("confirmado_por")
            d["confirmado_utc"] = doc.get("confirmado_utc")
            d["fichero"]        = doc.get("fichero")
    return d


def limpiar(ctx: dict) -> None:
    """Borra xlsx + json de la sesión (usado en 'Cambiar archivo')."""
    for p in (ruta_xlsx(ctx), ruta_json(ctx)):
        try:
            if p.is_file():
                p.unlink()
        except OSError:
            pass
