"""
Word del apartado «Solo Informe» (Informe de Resultados).

La estructura y la estética viven en `modulos.plantilla_bcp`, compartida con
«Generar informe» de la web y con el entregable del pipeline. Aquí solo se
traduce lo que el validador registró (estándar + observaciones) al formato
normalizado de la plantilla.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Optional

from modulos import plantilla_bcp as plantilla
from modulos.plantilla_bcp import (  # noqa: F401  (API usada por tests y router)
    REVISOR_POR_DEFECTO, fecha_larga, periodo_validacion,
)

from . import solo_informe_service as svc


def nombre_fichero(datos: dict, cuando: datetime) -> str:
    # Sin tildes antes de limpiar: «VaR Histórico» → «VaR_Historico», no «VaR_Hist_rico».
    ascii_ = unicodedata.normalize("NFKD", datos["nombre_modelo"]).encode("ascii", "ignore").decode()
    slug = re.sub(r"[^A-Za-z0-9_\-]+", "_", ascii_).strip("_") or "modelo"
    return f"Informe_Resultados_{slug}_{cuando.strftime('%Y%m%d_%H%M%S')}.docx"


def a_plantilla(datos: dict, estandar: dict, base: Path) -> dict:
    """Formulario + estándar → informe normalizado de `plantilla_bcp.generar`."""
    tier = datos.get("tier", "")
    estandar = svc.filtrar_por_tier(estandar, tier)
    obs = []
    for o in svc.limpiar_om(list(datos.get("observaciones") or [])):
        s = dict(o.get("sustento") or {})
        if s.get("tipo") == "imagen":
            s["imagen_ruta"] = svc.ruta_imagen(base, s.get("imagen_id", ""))
        obs.append({**o, "sustento": s,
                    "grafico_ruta": svc.ruta_imagen(base, o.get("grafico_id") or "")})
    return {
        **{k: datos.get(k, "") for k in ("tipo", "nombre_modelo", "fecha_inicio",
                                         "fecha_entrega", "responsable_doc",
                                         "revisado_por", "contexto", "limitaciones")},
        "ambitos": estandar["ambitos"],
        "controles": estandar["controles"],
        "observaciones": obs,
        "nota_alcance": (f", aplicables a un modelo Tier {tier}"
                         if estandar.get("tiene_tier") and tier else ""),
    }


def generar(datos: dict, estandar: dict, base: Path, *,
            raiz_logo: Optional[Path] = None) -> Path:
    """Genera el .docx en `base/salida/` y devuelve su ruta."""
    ruta = svc.dir_salida(base) / nombre_fichero(datos, datetime.now())
    return plantilla.generar(a_plantilla(datos, estandar, base), ruta, raiz_logo=raiz_logo)
