"""
Lectura y escritura del `.env` del proyecto SIN romper comentarios ni
orden de las variables que no se tocan.

Motivo. El `.env.example` del proyecto tiene ~500 líneas de comentarios
explicativos que valen tanto como los propios valores. Un dump plano
de un dict los borraría en el primer guardado desde la web y el
operador dejaría de tener la guía delante.

Contrato:
- `leer_env()` devuelve un `dict[str, str]` con las variables definidas
  (comentarios y líneas vacías se descartan).
- `actualizar_env(cambios)` reescribe el `.env` reemplazando línea a
  línea las variables que estén en `cambios`, dejando el resto —incluidos
  comentarios— tal cual. Las que no existan aún se añaden al final,
  agrupadas y precedidas por un comentario de fecha.
- Nunca borra variables. Para eliminarlas hay que hacerlo a mano.
"""
from __future__ import annotations

import re
from datetime import date
from pathlib import Path

from ..config_web import PROYECTO_DIR

ENV_PATH = PROYECTO_DIR / ".env"

# Coincide con `NOMBRE=valor` (opcional export, sin espacios exóticos).
# El valor puede venir sin comillas, entre comillas dobles o simples.
_LINEA_VAR = re.compile(r"""^\s*(?:export\s+)?
                            (?P<clave>[A-Za-z_][A-Za-z0-9_]*)
                            \s*=\s*
                            (?P<valor>.*)
                            $""", re.VERBOSE)


def _parsear_valor(bruto: str) -> str:
    """
    Quita comillas envolventes y desescapa el interior si la envoltura era
    doble. Simétrico con `_serializar_valor`: `leer(actualizar(x)) == x`.
    """
    v = bruto.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in ("'", '"'):
        interior = v[1:-1]
        if v[0] == '"':
            interior = interior.replace('\\"', '"').replace("\\\\", "\\")
        return interior
    return v


def _serializar_valor(v: str) -> str:
    """
    Escribe siempre entre comillas dobles.

    Motivo: una API key con `#` (`sk-…#…`) sin comillas se cortaría en
    ese carácter al leerla; y `python-dotenv` acepta comillas dobles sin
    peculiaridades. Escapamos solo `"` y `\\` con `\\`.
    """
    escapado = v.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escapado}"'


def leer_env() -> dict[str, str]:
    """Devuelve las variables actualmente definidas en `.env`."""
    if not ENV_PATH.is_file():
        return {}
    salida: dict[str, str] = {}
    for linea in ENV_PATH.read_text(encoding="utf-8").splitlines():
        recortada = linea.strip()
        if not recortada or recortada.startswith("#"):
            continue
        m = _LINEA_VAR.match(linea)
        if m:
            salida[m["clave"]] = _parsear_valor(m["valor"])
    return salida


def actualizar_env(cambios: dict[str, str]) -> dict[str, str]:
    """
    Aplica `cambios` sobre `.env` preservando lo demás.

    Devuelve el estado final leído tras escribir, para que el llamante
    no tenga que asumir que la escritura fue idéntica al pedido (p. ej.,
    por comillas o normalizaciones futuras).
    """
    if not cambios:
        return leer_env()

    # Nada que hacer si no existe: crea uno vacío y añade lo pedido.
    if not ENV_PATH.is_file():
        ENV_PATH.touch()

    pendientes = dict(cambios)
    lineas_originales = ENV_PATH.read_text(encoding="utf-8").splitlines(keepends=False)
    lineas_finales: list[str] = []

    for linea in lineas_originales:
        m = _LINEA_VAR.match(linea)
        if m and m["clave"] in pendientes:
            clave = m["clave"]
            lineas_finales.append(f"{clave}={_serializar_valor(pendientes.pop(clave))}")
        else:
            lineas_finales.append(linea)

    if pendientes:
        lineas_finales.append("")
        lineas_finales.append(f"# [VIRF-WEB {date.today().isoformat()}] Variables añadidas desde la web")
        for clave, valor in pendientes.items():
            lineas_finales.append(f"{clave}={_serializar_valor(valor)}")

    ENV_PATH.write_text("\n".join(lineas_finales) + "\n", encoding="utf-8")
    return leer_env()
