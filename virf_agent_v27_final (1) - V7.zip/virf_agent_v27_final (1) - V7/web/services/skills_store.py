"""
Skills por sesión (v2 · fase 5).

Un «skill» aquí es una CAPACIDAD DE ALTO NIVEL que el agente ejerce
durante la validación. Se distingue de los cuestionamientos (patrones
específicos, regex-powered) — los skills describen QUÉ mira el agente,
los cuestionamientos describen CÓMO detecta cosas puntuales.

Estado:
- Fichero `skills.json` dentro de la carpeta de la sesión.
- `defaults_desactivados`: lista de IDs de skills default que el
  operador ha marcado como inactivos.
- `custom`: skills en LENGUAJE NATURAL añadidos por el operador. Se
  inyectan tal cual como instrucciones adicionales en el prompt del
  agente (cuando haya API; sin ella se almacenan y esperan).
"""
from __future__ import annotations

import json
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_lock = threading.Lock()


SKILLS_DEFAULT: list[dict[str, str]] = [
    {
        "id":          "doc_metodologica",
        "nombre":      "Revisión de documentación metodológica",
        "descripcion": "Verifica completitud y coherencia del manual metodológico contra la rúbrica VIRF.",
    },
    {
        "id":          "codigo_vs_manual",
        "nombre":      "Análisis de código vs manual",
        "descripcion": "Contrasta cada función del código (.py, .ipynb, .sql, .R) contra lo declarado en el manual. Cita archivo:línea cuando hay discrepancias.",
    },
    {
        "id":          "patrones_codigo",
        "nombre":      "Detección de patrones problemáticos en código",
        "descripcion": "Busca los 15 patrones de CUESTIONAMIENTOS_METODOLOGICOS: Z-score, imputación por media, split aleatorio en series temporales, etc.",
    },
    {
        "id":          "backtesting",
        "nombre":      "Verificación de backtesting",
        "descripcion": "Revisa que existan pruebas de backtesting y que los resultados sean coherentes con los umbrales declarados.",
    },
    {
        "id":          "gobierno",
        "nombre":      "Análisis de gobierno del modelo",
        "descripcion": "Verifica aprobaciones formales, control de cambios, roles definidos y actas de comité.",
    },
    {
        "id":          "calidad_datos",
        "nombre":      "Evaluación de calidad de datos",
        "descripcion": "Ejecuta los 8 motores de prueba automática sobre los datasets subidos.",
    },
    {
        "id":          "supuestos",
        "nombre":      "Revisión de supuestos y limitaciones",
        "descripcion": "Verifica que los supuestos del modelo estén declarados, validados y monitoreados.",
    },
    {
        "id":          "contraste_rag",
        "nombre":      "Contraste con literatura de referencia (RAG)",
        "descripcion": "Reta la metodología contra papers y estándares del dominio. Cita papers cuando algo no cuadra.",
    },
    {
        "id":          "sensibilidad",
        "nombre":      "Revisión de análisis de sensibilidad",
        "descripcion": "Verifica si hay análisis de sensibilidad a parámetros clave del modelo.",
    },
    {
        "id":          "reproducibilidad",
        "nombre":      "Verificación de reproducibilidad",
        "descripcion": "Evalúa si el modelo puede replicarse con los mismos datos y obtener el mismo resultado.",
    },
]

# Los dos últimos vienen desactivados por defecto — coincide con el prompt v2.
_ACTIVOS_POR_DEFECTO = {s["id"] for s in SKILLS_DEFAULT
                        if s["id"] not in ("sensibilidad", "reproducibilidad")}


def _fichero(ctx: dict) -> Path:
    return ctx["base"] / "skills.json"


def _leer(ctx: dict) -> dict:
    p = _fichero(ctx)
    if not p.is_file():
        return {"defaults_desactivados": [], "custom": []}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"defaults_desactivados": [], "custom": []}
    d.setdefault("defaults_desactivados", [])
    d.setdefault("custom", [])
    return d


def _escribir(ctx: dict, data: dict) -> None:
    ctx["base"].mkdir(parents=True, exist_ok=True)
    _fichero(ctx).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _ahora() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def get_skills(ctx: dict) -> dict[str, Any]:
    """Snapshot para la UI: defaults con `activo` + custom."""
    data = _leer(ctx)
    desact = set(data.get("defaults_desactivados", []))
    activ  = set(data.get("defaults_activados", []))
    defaults = []
    for s in SKILLS_DEFAULT:
        # Regla: si aparece en desactivados → inactivo.
        # Si no, activo si estaba en el default O si el usuario lo añadió a
        # `defaults_activados` (para permitir activar los dos que vienen
        # apagados de fábrica: sensibilidad, reproducibilidad).
        if s["id"] in desact:
            activo = False
        elif s["id"] in _ACTIVOS_POR_DEFECTO or s["id"] in activ:
            activo = True
        else:
            activo = False
        defaults.append({**s, "activo": activo})
    return {"defaults": defaults, "custom": list(data["custom"])}


def toggle_default(ctx: dict, skill_id: str, activo: bool) -> dict:
    """Marca/desmarca un skill del catálogo por defecto. `activo=True` lo saca
    de la lista de desactivados; `activo=False` lo añade."""
    if skill_id not in {s["id"] for s in SKILLS_DEFAULT}:
        raise ValueError(f"skill default desconocido: {skill_id!r}")
    with _lock:
        data = _leer(ctx)
        desact = set(data["defaults_desactivados"])
        # La regla del store: `defaults_desactivados` invierte el default.
        # Un skill viene activo por defecto y el usuario lo apaga → lo añade.
        # Un skill viene inactivo por defecto y el usuario lo enciende → hoy
        # NO se guarda "activados extra" (KISS); se acepta la petición pero
        # queda inactivo si estaba en la lista fija de inactivos. Para que
        # el usuario pueda activar `sensibilidad`/`reproducibilidad` con este
        # esquema, mantenemos una lista `defaults_activados` opcional.
        data.setdefault("defaults_activados", [])
        act_extra = set(data["defaults_activados"])
        if activo:
            desact.discard(skill_id)
            if skill_id not in _ACTIVOS_POR_DEFECTO:
                act_extra.add(skill_id)
        else:
            act_extra.discard(skill_id)
            desact.add(skill_id)
        data["defaults_desactivados"] = sorted(desact)
        data["defaults_activados"]    = sorted(act_extra)
        _escribir(ctx, data)
    return get_skills(ctx)


def add_custom(ctx: dict, descripcion: str) -> dict:
    """Añade un skill personalizado en lenguaje natural."""
    texto = (descripcion or "").strip()
    if not texto or len(texto) < 6:
        raise ValueError("la descripción es demasiado corta")
    with _lock:
        data = _leer(ctx)
        # ID incremental estable: custom_001, custom_002...
        n = len(data["custom"]) + 1
        cid = f"custom_{n:03d}"
        # Ante huecos por borrados, buscar el primer sufijo libre.
        existentes = {c["id"] for c in data["custom"]}
        while cid in existentes:
            n += 1
            cid = f"custom_{n:03d}"
        skill = {
            "id":          cid,
            "descripcion": texto,
            "creado_utc":  _ahora(),
        }
        data["custom"].append(skill)
        _escribir(ctx, data)
    return skill


def remove_custom(ctx: dict, skill_id: str) -> bool:
    with _lock:
        data = _leer(ctx)
        antes = len(data["custom"])
        data["custom"] = [c for c in data["custom"] if c["id"] != skill_id]
        if len(data["custom"]) == antes:
            return False
        _escribir(ctx, data)
    return True


def get_active_skills_for_prompt(ctx: dict) -> list[str]:
    """
    Instrucciones a inyectar en el prompt del agente (cuando llegue la
    API real). Formato: cada skill activo es una línea; los custom se
    marcan como INSTRUCCIÓN ADICIONAL DEL VALIDADOR.
    """
    snap = get_skills(ctx)
    salida: list[str] = []
    for s in snap["defaults"]:
        if s["activo"]:
            salida.append(s["descripcion"])
    for c in snap["custom"]:
        salida.append(f"INSTRUCCIÓN ADICIONAL DEL VALIDADOR: {c['descripcion']}")
    return salida
