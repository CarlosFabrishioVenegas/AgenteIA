"""
Presupuesto de contexto dinámico por modelo detectado (v2.3).

El agente CLI lee `VIRF_MAX_CTX` del entorno al arrancar (config/parametros.py).
Antes ese valor era fijo (15.000 chars, dimensionado para el modelo original de
200K tokens). Con GPT-4o (128K) o GPT-4.1 (1M) se estaba desperdiciando el 99%
de la ventana.

Este módulo consulta `config/modelos.py` —que ya conoce cada modelo del
catálogo con `contexto_tokens` y `max_ctx` derivado— y devuelve el presupuesto
que corresponde a lo que realmente sirve el deployment.

Uso:
    from web.services import presupuesto_service
    p = presupuesto_service.calcular("gpt-4o-2024-11-20")
    # {'modelo': 'gpt-4o', 'ventana_tokens': 128000, 'presupuesto_evidencia_chars': 184320, ...}

    presupuesto_service.aplicar_env(p)  # sobreescribe VIRF_MAX_CTX antes del subprocess
"""
from __future__ import annotations

import os
from typing import Any, Optional


def calcular(modelo_detectado: Optional[str]) -> dict[str, Any]:
    """
    Devuelve el presupuesto de contexto que corresponde al modelo detectado.

    Si `modelo_detectado` es None o no está catalogado, se usa el perfil
    conservador (16K tokens) — más llamadas de las necesarias, pero jamás
    exceder la ventana.
    """
    # Import diferido: config/ vive fuera de web/, requiere sys.path ya montado
    # por web/app.py.
    from config.modelos import perfil_modelo, CHARS_POR_TOKEN_ES
    p = perfil_modelo(modelo_detectado, verbose=False)
    return {
        "modelo":                       modelo_detectado or "(desconocido)",
        "modelo_perfil":                p.nombre,
        "familia":                      p.familia,
        "ventana_tokens":               p.contexto_tokens,
        "ventana_chars":                p.contexto_chars,
        "presupuesto_evidencia_chars":  p.max_ctx,
        "presupuesto_doc_chars":        p.presupuesto_doc,
        "chunk_size":                   p.chunk_size,
        "max_chunks":                   p.max_chunks,
        "chars_por_token":              CHARS_POR_TOKEN_ES,
        "cabe_todo_en_una_llamada":     p.max_ctx >= 100_000,
        "paginas_equivalentes":         round(p.max_ctx / 2_000, 1),
    }


def aplicar_env(presupuesto: dict[str, Any],
                 env: Optional[dict[str, str]] = None) -> dict[str, str]:
    """
    Copia el env y sobreescribe VIRF_MAX_CTX y VIRF_PRESUPUESTO_DOC con los
    valores del presupuesto calculado. No muta el env real; devuelve el dict
    listo para pasar a subprocess.Popen(..., env=...).
    """
    salida = dict(env if env is not None else os.environ)
    salida["VIRF_MAX_CTX"]       = str(presupuesto["presupuesto_evidencia_chars"])
    salida["VIRF_PRESUPUESTO_DOC"] = str(presupuesto["presupuesto_doc_chars"])
    salida["VIRF_CHUNK_SIZE"]    = str(presupuesto["chunk_size"])
    salida["VIRF_MAX_CHUNKS"]    = str(presupuesto["max_chunks"])
    return salida
