"""
Apartado «Solo Informe»: compone el informe de resultados SIN ejecutar el pipeline.

Entradas: el Estandar_VIRF.xlsx, los datos de cabecera (tipo de validación,
modelo, fechas) y las observaciones que el validador registra a mano. Nada de
esto llama a un LLM: el Word se arma con el estándar y lo registrado.

Persistencia (por validador, no por modelo: el apartado no exige modelo activo):
  web/data/sesiones/{codigo}/_solo_informe/estandar.xlsx
  web/data/sesiones/{codigo}/_solo_informe/estandar.json     (parseado)
  web/data/sesiones/{codigo}/_solo_informe/borrador.json     (formulario)
  web/data/sesiones/{codigo}/_solo_informe/imagenes/<id>.<ext>
  web/data/sesiones/{codigo}/_solo_informe/salida/*.docx

`_solo_informe` no puede chocar con un modelo: los slugs de modelo van en
mayúsculas y empiezan por letra o dígito (`modelos_store._SLUG_RE`).
"""
from __future__ import annotations

import json
import re
import uuid
from pathlib import Path
from typing import Any, Optional

from openpyxl import load_workbook

from .estandares_service import EstandarInvalido, _normalizar_marca
from . import solo_informe_reglas as reglas

CARPETA = "_solo_informe"
EXT_IMAGEN = (".png", ".jpg", ".jpeg", ".gif", ".bmp")
MAX_IMAGEN = 8 * 1024 * 1024


# ── Rutas ─────────────────────────────────────────────────────────────

def base_de(sesiones_dir: Path, codigo: str) -> Path:
    d = Path(sesiones_dir) / codigo / CARPETA
    d.mkdir(parents=True, exist_ok=True)
    return d


def ruta_xlsx(base: Path) -> Path:
    return base / "estandar.xlsx"


def ruta_json(base: Path) -> Path:
    return base / "estandar.json"


def ruta_borrador(base: Path) -> Path:
    return base / "borrador.json"


def dir_imagenes(base: Path) -> Path:
    d = base / "imagenes"
    d.mkdir(parents=True, exist_ok=True)
    return d


def dir_salida(base: Path) -> Path:
    d = base / "salida"
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── Parseo del estándar ───────────────────────────────────────────────
#
# Por qué no se llama directamente a los parsers existentes:
#   · `estandares_service.parsear` exige la cabecera en la PRIMERA fila y las
#     cuatro columnas TIER; el Estandar_VIRF.xlsx real la trae en la fila 2 con
#     la columna A vacía, y el formato que describe el usuario (Ámbito, Control
#     General, Control Específico, Actividad) no tiene por qué traer tiers.
#   · `leer_estandares_virf` lee la ruta GLOBAL de `RUTAS`; aquí el fichero es
#     el que sube el usuario.
# Se reutiliza su criterio (detectar la cabecera por palabras clave antes del
# forward-fill de las celdas combinadas, columnas obligatorias explícitas), la
# marca de tier de `estandares_service` y la excepción `EstandarInvalido`, para
# que el router responda igual que el paso 02.
#
# Tier: si el Excel trae columnas TIER, cada control guarda en qué tiers aplica
# y el informe se filtra por el tier elegido (`filtrar_por_tier`). Sin columnas
# TIER, todas las actividades aplican a cualquier tier.

TIERS = ("I", "II", "III", "IV")
_TIER_RE = re.compile(r"^tier\s*[_\-]?\s*(iv|iii|ii|i|[1-4])$")
_TIER_ARABIGO = {"1": "I", "2": "II", "3": "III", "4": "IV"}


def _norm(v: Any) -> str:
    return reglas._sin_tildes(str(v)) if v is not None else ""


def _mapear_cabecera(fila: list) -> dict[str, int]:
    cols: dict[str, int] = {}
    for i, v in enumerate(fila):
        h = _norm(v)
        if not h:
            continue
        m = _TIER_RE.match(h)
        if m:
            t = m.group(1).upper()
            cols.setdefault(f"tier_{_TIER_ARABIGO.get(t, t)}", i)
        elif "ambito" in h or "dimension" in h:
            cols.setdefault("ambito", i)
        elif "actividad" in h or "tarea" in h:
            cols.setdefault("actividad", i)
        elif "control" in h and "especific" in h:
            cols.setdefault("control_especifico", i)
        elif "control" in h:
            cols.setdefault("control", i)
    return cols


def parsear_estandar(xlsx: Path) -> dict[str, Any]:
    """
    Devuelve {ambitos: [nombre…], controles: [{id, ambito, clave_ambito, control,
    control_especifico, actividad}]}. Cada fila con actividad es un control
    evaluable del informe.
    """
    try:
        wb = load_workbook(str(xlsx), data_only=True)
    except Exception as exc:                         # noqa: BLE001
        raise EstandarInvalido(f"no se pudo abrir el .xlsx: {exc}")
    try:
        for ws in wb.worksheets:
            filas = [list(r) for r in ws.iter_rows(values_only=True)]
            for i, fila in enumerate(filas[:30]):
                cols = _mapear_cabecera(fila)
                if "ambito" in cols and "actividad" in cols:
                    return _extraer(filas[i + 1:], cols)
    finally:
        wb.close()
    raise EstandarInvalido(
        "no se encontró una hoja con columnas ÁMBITO y ACTIVIDAD. "
        "Se esperan, al menos: Ámbito, Control (General/Específico) y Actividad.")


def _extraer(filas: list[list], cols: dict[str, int]) -> dict[str, Any]:
    def celda(fila, clave):
        i = cols.get(clave)
        if i is None or i >= len(fila) or fila[i] is None:
            return ""
        s = str(fila[i]).strip()
        return "" if s.lower() in ("none", "nan") else s

    tiene_tier = any(f"tier_{t}" in cols for t in TIERS)
    ultimo = {"ambito": "", "control": "", "control_especifico": ""}
    controles: list[dict] = []
    ambitos: list[str] = []
    for fila in filas:
        if not any(v is not None and str(v).strip() for v in fila):
            continue
        # Celdas combinadas: openpyxl solo da valor al vértice; se propaga.
        for k in ultimo:
            v = celda(fila, k)
            if v:
                ultimo[k] = v
                if k == "ambito":
                    # Un ámbito nuevo reinicia los controles heredados.
                    ultimo["control"] = celda(fila, "control")
                    ultimo["control_especifico"] = celda(fila, "control_especifico")
        act = celda(fila, "actividad")
        if not act or not ultimo["ambito"]:
            continue
        if act.lower().startswith(("total", "nota:", "fuente:")):
            continue
        if ultimo["ambito"] not in ambitos:
            ambitos.append(ultimo["ambito"])
        controles.append({
            "id":                 f"C{len(controles) + 1:03d}",
            "ambito":             ultimo["ambito"],
            "clave_ambito":       reglas.clave_ambito(ultimo["ambito"]),
            "control":            ultimo["control"],
            "control_especifico": ultimo["control_especifico"],
            "actividad":          act,
            # None = el estándar no distingue tiers (aplica a todos).
            "tiers": ([t for t in TIERS if f"tier_{t}" in cols
                       and _normalizar_marca(fila[cols[f"tier_{t}"]]
                                             if cols[f"tier_{t}"] < len(fila) else None)]
                      if tiene_tier else None),
        })
    if not controles:
        raise EstandarInvalido("el estándar no tiene ninguna actividad con ámbito.")
    return {"ambitos": ambitos, "controles": controles, "tiene_tier": tiene_tier}


def filtrar_por_tier(estandar: dict, tier: str) -> dict:
    """Estándar reducido a las actividades que aplican al tier (y sus ámbitos)."""
    if not estandar.get("tiene_tier"):
        return estandar
    ctrls = [c for c in estandar["controles"] if tier in (c.get("tiers") or [])]
    ambitos = [a for a in estandar["ambitos"] if any(c["ambito"] == a for c in ctrls)]
    return {**estandar, "ambitos": ambitos, "controles": ctrls}


def limpiar_om(observaciones: list[dict]) -> list[dict]:
    """Una Oportunidad de Mejora no lleva responsable ni fecha límite."""
    for o in observaciones:
        try:
            if reglas.es_om(o):
                o["responsable"] = ""
                o["fecha_subsanacion"] = ""
        except ValueError:
            pass        # riesgo inválido: lo reporta validar_datos
    return observaciones


def guardar_estandar(base: Path, contenido: bytes) -> dict[str, Any]:
    xlsx = ruta_xlsx(base)
    xlsx.write_bytes(contenido)
    try:
        est = parsear_estandar(xlsx)
    except EstandarInvalido:
        xlsx.unlink(missing_ok=True)
        raise
    ruta_json(base).write_text(json.dumps(est, ensure_ascii=False, indent=2),
                               encoding="utf-8")
    return est


def cargar_estandar(base: Path) -> Optional[dict]:
    p = ruta_json(base)
    if not p.is_file():
        return None
    try:
        est = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    # JSON guardado antes de que el parser leyera los tiers: se rehace desde el
    # .xlsx para no obligar a subirlo de nuevo.
    if "tiene_tier" not in est and ruta_xlsx(base).is_file():
        try:
            est = parsear_estandar(ruta_xlsx(base))
        except EstandarInvalido:
            return est
        p.write_text(json.dumps(est, ensure_ascii=False, indent=2), encoding="utf-8")
    return est


# ── Borrador del formulario ───────────────────────────────────────────

def guardar_borrador(base: Path, datos: dict) -> None:
    ruta_borrador(base).write_text(json.dumps(datos, ensure_ascii=False, indent=2),
                                   encoding="utf-8")


def cargar_borrador(base: Path) -> Optional[dict]:
    p = ruta_borrador(base)
    if not p.is_file():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None


# ── Imágenes de sustento ──────────────────────────────────────────────

_ID_IMG_RE = re.compile(r"^[0-9a-f]{32}\.(png|jpe?g|gif|bmp)$")


def guardar_imagen(base: Path, nombre: str, contenido: bytes) -> str:
    ext = Path(nombre or "").suffix.lower()
    if ext not in EXT_IMAGEN:
        raise ValueError(f"formato de imagen no admitido: {ext or '(sin extensión)'}. "
                         f"Usa {', '.join(EXT_IMAGEN)}.")
    if not contenido:
        raise ValueError("la imagen está vacía")
    if len(contenido) > MAX_IMAGEN:
        raise ValueError("la imagen supera 8 MB")
    ident = f"{uuid.uuid4().hex}{ext}"
    (dir_imagenes(base) / ident).write_bytes(contenido)
    return ident


def ruta_imagen(base: Path, ident: str) -> Optional[Path]:
    """Ruta de una imagen subida. None si el id no es válido o no existe."""
    if not _ID_IMG_RE.match(ident or ""):
        return None
    p = dir_imagenes(base) / ident
    return p if p.is_file() else None


# ── Cálculos del informe ──────────────────────────────────────────────

def observaciones_por_control(observaciones: list[dict]) -> dict[str, list[dict]]:
    d: dict[str, list[dict]] = {}
    for o in observaciones:
        d.setdefault(o.get("control_id") or "", []).append(o)
    return d


def cumplimiento(estandar: dict, observaciones: list[dict]) -> list[dict]:
    """
    Fila por ámbito del estándar: total, satisfactorios y no cumplidos (con %).
    Un control no se cumple si tiene alguna observación registrada
    (ver `reglas.OM_INCUMPLE`).
    """
    por_ctrl = observaciones_por_control(observaciones)
    filas = []
    for amb in estandar["ambitos"]:
        ctrls = [c for c in estandar["controles"] if c["ambito"] == amb]
        total = len(ctrls)
        no_ok = sum(1 for c in ctrls if not reglas.control_cumple(por_ctrl.get(c["id"], [])))
        ok = total - no_ok
        filas.append({
            "ambito": amb, "total": total, "satisfactorios": ok, "no_cumplidos": no_ok,
            "pct_ok": round(100 * ok / total, 1) if total else 0.0,
            "pct_no": round(100 * no_ok / total, 1) if total else 0.0,
        })
    return filas


def validar_datos(datos: dict, estandar: dict) -> list[str]:
    """
    Errores de formulario que impiden generar el informe (lista vacía = OK).
    `estandar` debe venir ya filtrado por tier: una observación sobre una
    actividad que no aplica al tier elegido se rechaza.
    """
    errores = []
    if estandar.get("tiene_tier") and datos.get("tier") not in TIERS:
        errores.append("Elige el Tier del modelo (el estándar distingue actividades por Tier).")
    if datos.get("tipo") not in ("periodica", "primera_vez"):
        errores.append("Elige el tipo de validación (Periódica o Por Primera Vez).")
    if not str(datos.get("nombre_modelo") or "").strip():
        errores.append("Falta el nombre del modelo.")
    for campo, etiqueta in (("fecha_inicio", "fecha de inicio"),
                            ("fecha_entrega", "fecha de entrega")):
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", str(datos.get(campo) or "")):
            errores.append(f"Falta la {etiqueta} (AAAA-MM-DD).")
    ids = {c["id"] for c in estandar["controles"]}
    for n, o in enumerate(datos.get("observaciones") or [], start=1):
        if o.get("control_id") not in ids:
            errores.append(f"Observación {n}: la actividad no pertenece al estándar cargado "
                           "o no aplica al Tier elegido.")
        try:
            reglas.normalizar_riesgo(o.get("riesgo"))
        except ValueError:
            errores.append(f"Observación {n}: riesgo no válido.")
        if not str(o.get("observacion") or "").strip():
            errores.append(f"Observación {n}: falta la descripción.")
    return errores
