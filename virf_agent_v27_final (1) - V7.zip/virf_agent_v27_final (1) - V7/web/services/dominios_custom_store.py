"""
Dominios RAG personalizados (Mejora 1 · v2.2).

- Persistencia: `web/data/dominios_custom.json`.
- Registro sencillo `{id: {nombre, descripcion, palabras_clave,
  creado_por, fecha_creacion}}`.
- Al crear un dominio: se materializa `inputs/rag/{id}/` con un
  `README.md` y se anota en el JSON. La construcción del índice va
  aparte (`scripts/rebuild_rag_databricks.py --dominio {id}`).
- Al borrar: se mueve la carpeta a `archivo/dominios_retirados/`
  con fecha; NO se elimina — un dominio retirado puede volver a
  usarse si se reactiva.
"""
from __future__ import annotations

import json
import re
import shutil
import threading
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from ..config_web import PROYECTO_DIR, WEB_DIR

DATA_JSON      = WEB_DIR / "data" / "dominios_custom.json"
RAG_GLOBAL     = PROYECTO_DIR / "inputs" / "rag"
ARCHIVO_RETIRO = PROYECTO_DIR / "archivo" / "dominios_retirados"

_lock = threading.Lock()

# Fijos: coincide con src/rag/DOMINIOS_DISPONIBLES.
DOMINIOS_FIJOS = ("LaR", "VaR", "ALM", "shared")

_SLUG_RE       = re.compile(r"^[a-z0-9][a-z0-9_]{1,50}$")
_KEYWORD_RE    = re.compile(r"^[a-z0-9][a-z0-9_\- ]{0,60}$")


def slugify(nombre: str) -> str:
    """
    «Capital Económico» → «capital_economico»
    - Baja mayúsculas, quita acentos, colapsa no-alfanum a `_`.
    - Rechaza si queda vacío o no cumple `_SLUG_RE`.
    """
    n = "".join(c for c in unicodedata.normalize("NFKD", str(nombre or ""))
                if not unicodedata.combining(c))
    n = re.sub(r"[^A-Za-z0-9]+", "_", n).strip("_").lower()
    if not _SLUG_RE.match(n):
        raise ValueError(
            f"nombre inválido: {nombre!r} → slug '{n}' no admisible")
    return n


def _leer() -> dict[str, dict]:
    if not DATA_JSON.is_file():
        return {}
    try:
        d = json.loads(DATA_JSON.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return d if isinstance(d, dict) else {}


def _escribir(d: dict) -> None:
    DATA_JSON.parent.mkdir(parents=True, exist_ok=True)
    DATA_JSON.write_text(
        json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def listar() -> list[dict]:
    """
    Devuelve la lista completa de dominios (fijos + custom).
    Los fijos van marcados `tipo="fijo"`, los custom `tipo="custom"`.
    """
    salida: list[dict] = []
    for f in DOMINIOS_FIJOS:
        salida.append({
            "id":              f,
            "nombre":          f,
            "descripcion":     "",
            "palabras_clave":  [],
            "tipo":            "fijo",
        })
    for cid, meta in _leer().items():
        salida.append({
            "id":              cid,
            "nombre":          meta.get("nombre", cid),
            "descripcion":     meta.get("descripcion", ""),
            "palabras_clave":  meta.get("palabras_clave", []),
            "creado_por":      meta.get("creado_por"),
            "fecha_creacion":  meta.get("fecha_creacion"),
            "tipo":            "custom",
        })
    return salida


def crear(nombre: str, descripcion: str, palabras_clave: list[str],
           creado_por: str) -> dict:
    """
    Crea un dominio custom. Devuelve la entrada creada.
    Falla si el slug ya existe (fijo o custom).
    """
    slug = slugify(nombre)
    if slug in DOMINIOS_FIJOS:
        raise ValueError(f"'{slug}' colisiona con un dominio fijo")
    palabras = [k.strip().lower() for k in (palabras_clave or []) if k.strip()]
    for kw in palabras:
        if not _KEYWORD_RE.match(kw):
            raise ValueError(f"palabra clave inválida: {kw!r}")

    with _lock:
        registro = _leer()
        if slug in registro:
            raise ValueError(f"ya existe un dominio custom con id '{slug}'")
        # Materializa carpeta + README para que la indexación tenga qué leer.
        carpeta = RAG_GLOBAL / slug
        carpeta.mkdir(parents=True, exist_ok=True)
        (carpeta / "README.md").write_text(
            f"# {nombre}\n\n"
            f"{descripcion.strip()}\n\n"
            f"Dominio creado por `{creado_por}` el "
            f"{datetime.now(timezone.utc).date().isoformat()}.\n\n"
            "Sube papers, estándares y documentos técnicos en esta carpeta y "
            f"reconstruye el índice: `python scripts/rebuild_rag_databricks.py "
            f"--dominio {slug} --force`.\n",
            encoding="utf-8",
        )
        entrada = {
            "nombre":         (nombre or "").strip(),
            "descripcion":    (descripcion or "").strip(),
            "palabras_clave": palabras,
            "creado_por":     creado_por,
            "fecha_creacion": datetime.now(timezone.utc).date().isoformat(),
        }
        registro[slug] = entrada
        _escribir(registro)
        return {"id": slug, "tipo": "custom", **entrada}


def existe(dom_id: str) -> bool:
    return dom_id in DOMINIOS_FIJOS or dom_id in _leer()


def borrar(dom_id: str) -> dict:
    """
    Retira un dominio custom. Mueve la carpeta a
    `archivo/dominios_retirados/{id}_{YYYYMMDD}/` (no borra: por si
    alguien lo necesita reconstruir).
    """
    if dom_id in DOMINIOS_FIJOS:
        raise ValueError(f"'{dom_id}' es un dominio fijo; no se borra")
    with _lock:
        registro = _leer()
        if dom_id not in registro:
            raise ValueError(f"dominio custom '{dom_id}' no existe")
        origen = RAG_GLOBAL / dom_id
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        destino = ARCHIVO_RETIRO / f"{dom_id}_{stamp}"
        destino.parent.mkdir(parents=True, exist_ok=True)
        if origen.is_dir():
            shutil.move(str(origen), str(destino))
        # Índice viejo también fuera del camino.
        idx = PROYECTO_DIR / "data" / "rag_lexico" / f"{dom_id}.pkl"
        if idx.is_file():
            idx.unlink()
        entrada = registro.pop(dom_id)
        _escribir(registro)
        return {"id": dom_id, "movido_a": str(destino.relative_to(PROYECTO_DIR)),
                 "entrada": entrada}
