"""
Cuestionamientos POR SESIÓN (v2 · fase 6).

Coexiste con la capa GLOBAL (`config/cuestionamientos_*.json`) que ya
usa Mx_04 vía `modulos.cuestionamientos_ext`. Ambas se suman al inyectar
al prompt:

    prompt += cuestionamientos_globales_activos()
    prompt += cuestionamientos_sesion_activos(ctx)

Diferencias:
- La capa global es REGEX (patrones que Mx_04 busca en el código);
  esa vía se mantiene por compatibilidad.
- La capa por sesión es LENGUAJE NATURAL — el operador escribe una
  frase y se inyecta tal cual. No hay regex ni id que el usuario
  tenga que inventar.

Persistencia: `sesion/cuestionamientos.json`.

Formato:
    {
      "defaults_desactivados": ["outliers_zscore"],
      "custom": [{"id": "cuest_custom_001", "descripcion": "...", "creado_utc": "..."}]
    }
"""
from __future__ import annotations

import json
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_lock = threading.Lock()

_BASE_DIR = Path(__file__).resolve().parent.parent.parent
_MOTOR_DIR = _BASE_DIR / "motor"
if str(_MOTOR_DIR) not in sys.path:
    sys.path.insert(0, str(_MOTOR_DIR))

from Mx_00_CargaRutas import CUESTIONAMIENTOS_METODOLOGICOS  # noqa: E402


def _fichero(ctx: dict) -> Path:
    return ctx["base"] / "cuestionamientos.json"


def _ahora() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _leer(ctx: dict) -> dict:
    p = _fichero(ctx)
    if not p.is_file():
        return {"defaults_desactivados": [], "custom": []}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"defaults_desactivados": [], "custom": []}
    d.setdefault("defaults_desactivados", [])
    d.setdefault("custom", [])
    return d


def _escribir(ctx: dict, data: dict) -> None:
    ctx["base"].mkdir(parents=True, exist_ok=True)
    _fichero(ctx).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def get_estado(ctx: dict) -> dict[str, Any]:
    """
    Snapshot: los 15 defaults con `activo` según lo guardado en la sesión,
    agrupados por tipo (presencia|ausencia), + los custom NL.
    """
    data = _leer(ctx)
    desact = set(data["defaults_desactivados"])
    presencia, ausencia = [], []
    for cid, meta in sorted(CUESTIONAMIENTOS_METODOLOGICOS.items()):
        tipo = "ausencia" if meta.get("detectar_ausencia") else "presencia"
        item = {
            "id":       cid,
            "tipo":     tipo,
            "contexto": meta.get("contexto", ""),
            "critica":  meta.get("critica", ""),
            "activo":   cid not in desact,
        }
        (ausencia if tipo == "ausencia" else presencia).append(item)
    return {
        "presencia": presencia,
        "ausencia":  ausencia,
        "custom":    list(data["custom"]),
    }


def toggle_default(ctx: dict, cid: str, activo: bool) -> dict:
    if cid not in CUESTIONAMIENTOS_METODOLOGICOS:
        raise ValueError(f"cuestionamiento default desconocido: {cid!r}")
    with _lock:
        data = _leer(ctx)
        desact = set(data["defaults_desactivados"])
        if activo:
            desact.discard(cid)
        else:
            desact.add(cid)
        data["defaults_desactivados"] = sorted(desact)
        _escribir(ctx, data)
    return get_estado(ctx)


def add_custom(ctx: dict, descripcion: str) -> dict:
    texto = (descripcion or "").strip()
    if len(texto) < 6:
        raise ValueError("la descripción es demasiado corta")
    with _lock:
        data = _leer(ctx)
        n = len(data["custom"]) + 1
        cid = f"cuest_custom_{n:03d}"
        existentes = {c["id"] for c in data["custom"]}
        while cid in existentes:
            n += 1
            cid = f"cuest_custom_{n:03d}"
        item = {"id": cid, "descripcion": texto, "creado_utc": _ahora()}
        data["custom"].append(item)
        _escribir(ctx, data)
    return item


def remove_custom(ctx: dict, cid: str) -> bool:
    with _lock:
        data = _leer(ctx)
        antes = len(data["custom"])
        data["custom"] = [c for c in data["custom"] if c["id"] != cid]
        if len(data["custom"]) == antes:
            return False
        _escribir(ctx, data)
    return True


def get_for_prompt(ctx: dict) -> list[str]:
    """
    Instrucciones NL a inyectar en el prompt del agente. Los defaults
    van con su `contexto` (el `critica` es demasiado largo para el prompt).
    """
    e = get_estado(ctx)
    salida: list[str] = []
    for grupo in (e["presencia"], e["ausencia"]):
        for c in grupo:
            if c["activo"]:
                salida.append(f"[{c['tipo']}] {c['contexto']}")
    for c in e["custom"]:
        salida.append(f"CUESTIONAMIENTO ADICIONAL DEL VALIDADOR: {c['descripcion']}")
    return salida
