"""
Modelos por validador — cada uno con su carpeta y su `sesion.json`.

Estructura en disco (persistente):

    web/data/sesiones/
      T5443/
        VAR_BCP_2027/
          sesion.json          metadata: dominio, tier, fechas, estado
          inputs/              evidencia (paso 2 la llenará por sesión)
          outputs/             informes generados por esa sesión

El «slug» del modelo es la versión saneada del nombre para usar como
carpeta y como id en la URL: mayúsculas, `_` en vez de espacios, sin
caracteres exóticos. El nombre bonito se conserva en `sesion.json`.
"""
from __future__ import annotations

import json
import re
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from ..config_web import WEB_DIR

SESIONES_DIR = WEB_DIR / "data" / "sesiones"
DOMINIOS_UI  = ("LaR", "VaR", "ALM")  # `shared` no lo elige el usuario
TIERS_VALIDOS = ("I", "II", "III", "IV")

_SLUG_RE       = re.compile(r"^[A-Z0-9][A-Z0-9_\-]{1,63}$")
_NORMALIZA_RE  = re.compile(r"[^A-Za-z0-9_\-]+")
_lock = threading.Lock()


def _ahora() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def slug_de(nombre: str) -> str:
    """
    Convierte «VAR BCP 2027» → «VAR_BCP_2027`. Rechaza cadenas vacías o
    que quedan reducidas a nada tras la normalización.
    """
    limpio = _NORMALIZA_RE.sub("_", (nombre or "").strip().upper()).strip("_")
    if not _SLUG_RE.match(limpio):
        raise ValueError(
            f"nombre inválido: {nombre!r}. Debe empezar por letra/dígito y "
            "contener solo letras, dígitos, guion y guion bajo.")
    return limpio


def _normaliza_tier(tier: str) -> str:
    v = str(tier or "").strip().upper()
    if v in {"1", "2", "3", "4"}:
        v = {"1": "I", "2": "II", "3": "III", "4": "IV"}[v]
    if v not in TIERS_VALIDOS:
        raise ValueError(f"tier inválido: {tier!r}")
    return v


def _valida_dominio(dominio: str) -> str:
    """
    Acepta los 3 fijos del selector + shared + cualquier custom
    registrado en `dominios_custom.json`. Rechaza si es desconocido.
    """
    if dominio in DOMINIOS_UI or dominio == "shared":
        return dominio
    # Import perezoso: evita ciclo web.services.modelos_store ← dominios_custom_store
    from . import dominios_custom_store as _dcs
    if dominio in _dcs._leer():                       # noqa: SLF001
        return dominio
    raise ValueError(
        f"dominio inválido: {dominio!r}. Válidos: {DOMINIOS_UI} + custom")


def _base_validador(codigo: str) -> Path:
    """Carpeta raíz de todos los modelos de un validador."""
    return SESIONES_DIR / codigo


def _base_modelo(codigo: str, slug: str) -> Path:
    return _base_validador(codigo) / slug


def _leer_sesion(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _escribir_sesion(base: Path, data: dict) -> None:
    base.mkdir(parents=True, exist_ok=True)
    (base / "sesion.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _snapshot(codigo: str, slug: str, sesion_json: dict) -> dict:
    """Vista pública que consume la UI."""
    return {
        "codigo_validador":       codigo,
        "slug":                   slug,
        "nombre":                 sesion_json.get("nombre", slug),
        "dominio":                sesion_json.get("dominio"),
        "tier":                   sesion_json.get("tier"),
        "estado":                 sesion_json.get("estado", "sin_iniciar"),
        "creado_utc":             sesion_json.get("creado_utc"),
        "ultima_actividad_utc":   sesion_json.get("ultima_actividad_utc"),
    }


def crear(codigo: str, nombre: str, dominio: str, tier: str) -> dict:
    """
    Crea la sesión del modelo. Falla si ya existe uno con el mismo slug:
    no queremos que un nombre nuevo sobrescriba silenciosamente el trabajo
    previo bajo la misma carpeta.
    """
    slug = slug_de(nombre)
    dominio = _valida_dominio(dominio)
    tier = _normaliza_tier(tier)
    with _lock:
        base = _base_modelo(codigo, slug)
        if base.exists():
            raise ValueError(f"ya existe un modelo con slug {slug!r} para {codigo}")
        base.mkdir(parents=True)
        (base / "inputs").mkdir()
        (base / "outputs").mkdir()
        data = {
            "codigo_validador":     codigo,
            "slug":                 slug,
            "nombre":               (nombre or "").strip() or slug,
            "dominio":              dominio,
            "tier":                 tier,
            "estado":               "sin_iniciar",
            "creado_utc":           _ahora(),
            "ultima_actividad_utc": _ahora(),
        }
        _escribir_sesion(base, data)
        return _snapshot(codigo, slug, data)


def listar(codigo: str) -> list[dict]:
    """Modelos del validador, más recientes primero."""
    base = _base_validador(codigo)
    if not base.is_dir():
        return []
    salida: list[dict] = []
    for sub in base.iterdir():
        if not sub.is_dir():
            continue
        sj = sub / "sesion.json"
        if not sj.is_file():
            continue
        salida.append(_snapshot(codigo, sub.name, _leer_sesion(sj)))
    salida.sort(key=lambda m: m.get("ultima_actividad_utc") or "", reverse=True)
    return salida


def cargar(codigo: str, slug: str) -> Optional[dict]:
    base = _base_modelo(codigo, slug)
    sj = base / "sesion.json"
    if not sj.is_file():
        return None
    return _snapshot(codigo, slug, _leer_sesion(sj))


def actualizar_actividad(codigo: str, slug: str,
                          estado: Optional[str] = None) -> None:
    """Marca que hubo movimiento en la sesión (validación, chat, informe…)."""
    base = _base_modelo(codigo, slug)
    sj = base / "sesion.json"
    if not sj.is_file():
        return
    with _lock:
        data = _leer_sesion(sj)
        data["ultima_actividad_utc"] = _ahora()
        if estado:
            data["estado"] = estado
        _escribir_sesion(base, data)


def actualizar_meta(codigo: str, slug: str, *,
                    nombre: Optional[str] = None,
                    tier: Optional[str] = None) -> Optional[dict]:
    """
    Edita metadatos de una ficha existente EN SITIO. No mueve la carpeta:
    el `slug` sigue siendo la identidad del modelo (derivado del nombre
    original al crearlo), así que renombrar aquí cambia solo la etiqueta
    visible `nombre`, nunca la ruta en disco ni el historial. Devuelve el
    snapshot actualizado, o `None` si la ficha ya no existe.
    """
    base = _base_modelo(codigo, slug)
    sj = base / "sesion.json"
    if not sj.is_file():
        return None
    with _lock:
        data = _leer_sesion(sj)
        if nombre and nombre.strip():
            data["nombre"] = nombre.strip()
        if tier:
            data["tier"] = _normaliza_tier(tier)
        data["ultima_actividad_utc"] = _ahora()
        _escribir_sesion(base, data)
        return _snapshot(codigo, slug, data)


def borrar(codigo: str, slug: str) -> bool:
    """Elimina la sesión entera del disco. Irreversible; usar con cuidado."""
    import shutil
    base = _base_modelo(codigo, slug)
    if not base.is_dir():
        return False
    with _lock:
        shutil.rmtree(base)
    return True
