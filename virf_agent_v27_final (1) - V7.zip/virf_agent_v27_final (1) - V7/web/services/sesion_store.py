"""
Registro de validadores + login por token (v2 · fase 1).

Diseño:

- Los validadores se guardan en `web/data/validadores.json`. Persiste
  entre reinicios del servidor.
- Los tokens de sesión activa viven en memoria. Cuando el servidor se
  reinicia, todos deben volver a loguearse — aceptable con `--reload`
  activo y con un solo operador por sesión.
- El código sigue el formato `T\\d{3,7}` (case-insensitive, normalizado
  a upper). Un código bien formado que no existe se ALTA en el momento
  con el nombre que dio el usuario; un código mal formado se rechaza.
"""
from __future__ import annotations

import json
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from ..config_web import WEB_DIR

DATA_DIR    = WEB_DIR / "data"
VALIDADORES = DATA_DIR / "validadores.json"

_CODIGO_RE = re.compile(r"^T\d{3,7}$", re.IGNORECASE)
_lock = threading.Lock()

# {token: {codigo, nombre, cargo, iniciado_utc}}
_sesiones: dict[str, dict] = {}


def _ahora() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _leer_json(p: Path, default):
    if not p.is_file():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def leer_validadores() -> dict:
    """Snapshot del registro. NUNCA muta el estado en disco."""
    d = _leer_json(VALIDADORES, {})
    return d if isinstance(d, dict) else {}


def _escribir_validadores(d: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    VALIDADORES.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                            encoding="utf-8")


def normalizar_codigo(codigo: str) -> str:
    return (codigo or "").strip().upper()


def formato_valido(codigo: str) -> bool:
    return bool(_CODIGO_RE.match(normalizar_codigo(codigo)))


def alta_validador(codigo: str, nombre: str, cargo: str = "Validador") -> dict:
    """
    Registra un nuevo validador si el código está bien formado.

    Idempotente: si el código ya existe, devuelve el existente sin tocar
    el nombre — un login posterior no debe permitir suplantar a alguien
    cambiándole el nombre.
    """
    codigo = normalizar_codigo(codigo)
    if not formato_valido(codigo):
        raise ValueError(f"código con formato inválido: {codigo!r}")
    with _lock:
        registro = leer_validadores()
        if codigo in registro:
            return registro[codigo]
        registro[codigo] = {
            "codigo":     codigo,
            "nombre":     (nombre or "").strip() or f"Validador {codigo}",
            "cargo":      cargo,
            "alta_utc":   _ahora(),
        }
        _escribir_validadores(registro)
        return registro[codigo]


def login(codigo: str, nombre: str) -> tuple[str, dict]:
    """
    Autentica (si existe) o registra al vuelo y autentica. Devuelve
    `(token, validador)`.
    """
    codigo = normalizar_codigo(codigo)
    if not formato_valido(codigo):
        raise ValueError(
            f"código con formato inválido: {codigo!r}. "
            "Esperado: 'T' seguida de 3-7 dígitos, p. ej. T5443.")
    val = alta_validador(codigo, nombre)
    token = uuid.uuid4().hex
    with _lock:
        _sesiones[token] = {
            **val,
            "iniciado_utc": _ahora(),
        }
    return token, val


def sesion_activa(token: Optional[str]) -> Optional[dict]:
    if not token:
        return None
    return _sesiones.get(token)


def set_atributo_sesion(token: Optional[str], clave: str, valor) -> bool:
    """
    Guarda un atributo volátil en la sesión de login (in-memory).
    Se usa, p. ej., para el modelo IA detectado por /api/config/verificar,
    de modo que el presupuesto de contexto se calcule para el modelo REAL
    en vez del perfil conservador.
    """
    if not token:
        return False
    with _lock:
        s = _sesiones.get(token)
        if s is None:
            return False
        s[clave] = valor
        return True


def logout(token: Optional[str]) -> bool:
    if not token:
        return False
    with _lock:
        return _sesiones.pop(token, None) is not None
