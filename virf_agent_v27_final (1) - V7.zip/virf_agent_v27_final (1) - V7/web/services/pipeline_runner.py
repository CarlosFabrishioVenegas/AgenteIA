"""
Ejecuta `agente.py --prdc` como subproceso para UNA sesión (v2 · fase 2).

Cambios sobre v1:

- Ya no hay `_run_actual` global. Ahora es un dict
  `{clave_sesion: Run}` donde `clave_sesion = "T5443/VAR_BCP_2027"`.
- Dos sesiones distintas pueden correr en paralelo; la MISMA sesión
  rechaza una segunda corrida hasta que la primera acabe (evita
  bifurcar la cadena de custodia de ese modelo).
- El agente se lanza con `--raiz-evidencia <base_sesion>` para que
  `Mx_00_CargaRutas.reapuntar_raiz(...)` mueva `RUTAS["inputs"]` al
  árbol de la sesión.
- El JSON de resultados se busca en `<base_sesion>/outputs/YYYY-MM-DD/`.
"""
from __future__ import annotations

import asyncio
import os
import subprocess
import sys
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

from ..config_web import PROYECTO_DIR


_FASES = [
    ("Leyendo evidencia",   ["📂", "Leyendo", "Cargando inputs"]),
    ("Chunking",             ["chunk", "Chunking", "Consolidando"]),
    ("Evaluando ámbitos",    ["Evaluando", "Ámbito", "score:"]),
    ("Skills",               ["Skill", "skills"]),
    ("RAG",                  ["RAG", "corpus"]),
    ("Generando informe",    ["Word", "informe", "generando"]),
    ("Sellando cadena",      ["custodia", "cadena", "sellado"]),
]


def _clasificar_fase(linea: str) -> Optional[str]:
    baja = linea.lower()
    for etiqueta, patrones in _FASES:
        for p in patrones:
            if p.lower() in baja:
                return etiqueta
    return None


@dataclass
class Run:
    run_id: str
    clave: str                          # "{codigo}/{slug}"
    base_sesion: Path                   # raíz de la sesión
    args: list[str]
    proceso: Optional[asyncio.subprocess.Process] = None
    eventos: asyncio.Queue = field(default_factory=asyncio.Queue)
    estado: str = "arrancando"
    exit_code: Optional[int] = None
    resultado_json: Optional[str] = None
    fase: str = "—"
    iniciado_utc: str = ""
    terminado_utc: Optional[str] = None
    linea_final: str = ""
    cancelado: bool = False             # lo pidió el usuario (no es un fallo)


def _construir_env_hijo(ctx: dict) -> dict[str, str]:
    """
    Copia os.environ y le añade dos capas propias de la sesión web:

    1. Presupuesto de contexto según el modelo detectado por
       /api/config/verificar (persistido en la sesión de login). Si no hay,
       se usa el perfil conservador.
    2. Override del ROL_AGENTE si el validador editó ese prompt para la
       sesión (prompt_service).

    Sin la (1) el pipeline usa VIRF_MAX_CTX=15000 aunque el deployment sea
    GPT-4o (128K). Sin la (2) el subprocess ignora la edición del rol
    porque motor/Mx_00_CargaRutas.py:ROL_AGENTE es una constante.
    """
    env = dict(os.environ)

    # ── (1) Presupuesto ──────────────────────────────────────────────
    from . import presupuesto_service, sesion_store
    # sesion_store guarda por token, pero pipeline_runner no lo tiene aquí.
    # Buscamos la sesión de login que tenga ese validador activo y saque
    # el modelo detectado (in-memory, se pierde al reiniciar).
    validador_codigo = ctx["validador"]["codigo"]
    modelo_ia = None
    for _tok, _val in sesion_store._sesiones.items():
        if _val.get("codigo") == validador_codigo and _val.get("modelo_ia_detectado"):
            modelo_ia = _val["modelo_ia_detectado"]
            break
    if modelo_ia:
        pres = presupuesto_service.calcular(modelo_ia)
        env = presupuesto_service.aplicar_env(pres, env=env)

    # ── (2) Override del rol del agente ─────────────────────────────
    from . import prompt_service
    try:
        base_rol = prompt_service.prompts_base().get("rol_agente", {}).get("contenido", "")
        rol_efectivo = prompt_service.get_prompt(ctx, "rol_agente")
        if rol_efectivo and rol_efectivo != base_rol:
            env["VIRF_ROL_AGENTE_OVERRIDE"] = rol_efectivo
    except (KeyError, OSError):
        pass

    return env


_runs: dict[str, Run] = {}
_por_id: dict[str, Run] = {}
_lock = threading.Lock()

# Referencias FUERTES a las tareas de supervisión en curso. El event loop de
# asyncio solo guarda referencias DÉBILES a las tareas: una tarea sin dueño
# puede ser recolectada por el GC a mitad de la corrida, y con ella se perdería
# el evento "fin" — la web mostraría la validación colgada para siempre, de
# forma intermitente (depende de cuándo pase el GC). Cada tarea se retira sola
# del set al terminar (`add_done_callback`), así que no crece sin límite.
_tareas: set[asyncio.Task] = set()


def run_de_sesion(clave: str) -> Optional[Run]:
    return _runs.get(clave)


def run_por_id(run_id: str) -> Optional[Run]:
    return _por_id.get(run_id)


def _snapshot_outputs_hoy(base_sesion: Path) -> set[str]:
    hoy = datetime.now().strftime("%Y-%m-%d")
    d = base_sesion / "outputs" / hoy
    if not d.is_dir():
        return set()
    return {p.name for p in d.iterdir() if p.is_file()}


def _detectar_json_nuevo(base_sesion: Path, previos: set[str],
                          titulo: str) -> Optional[str]:
    hoy = datetime.now().strftime("%Y-%m-%d")
    d = base_sesion / "outputs" / hoy
    if not d.is_dir():
        return None
    slug = titulo.replace(" ", "_")
    for p in d.iterdir():
        if not p.is_file() or p.suffix != ".json":
            continue
        if p.name in previos:
            continue
        if p.name.startswith("resultados_") or slug in p.name:
            return str(p.relative_to(base_sesion).as_posix())
    return None


def construir_args(base_sesion: Path,
                    titulo: str, tier: str, dominio: str,
                    validador: str, cargo: str,
                    validador_2: Optional[str] = None,
                    cargo_2: Optional[str] = None,
                    estandar_override: Optional[Path] = None) -> list[str]:
    for nombre, valor in [("titulo", titulo), ("tier", tier),
                          ("dominio", dominio),
                          ("validador", validador), ("cargo", cargo)]:
        if not (valor or "").strip():
            raise ValueError(f"'{nombre}' es obligatorio para lanzar --prdc")
    tier_cli = {"I": "1", "II": "2", "III": "3", "IV": "4"}.get(tier, tier)
    args = [
        sys.executable, "-u", "agente.py",
        "--titulo",        titulo,
        "--tier",          tier_cli,
        "--dominio-rag",   dominio,
        "--raiz-evidencia", str(base_sesion),
        "--prdc",
        "--validador",     validador,
        "--cargo",         cargo,
    ]
    if validador_2 and cargo_2:
        args += ["--validador-2", validador_2, "--cargo-2", cargo_2]
    if estandar_override is not None:
        args += ["--estandares", str(estandar_override)]
    return args


async def _bombear_stdout(run: Run) -> None:
    assert run.proceso is not None and run.proceso.stdout is not None
    try:
        async for bruto in run.proceso.stdout:
            linea = bruto.decode("utf-8", errors="replace").rstrip("\r\n")
            run.linea_final = linea
            fase_nueva = _clasificar_fase(linea)
            if fase_nueva and fase_nueva != run.fase:
                run.fase = fase_nueva
                await run.eventos.put({"tipo": "fase", "fase": fase_nueva})
            await run.eventos.put({"tipo": "linea", "texto": linea})
    except Exception as exc:                      # noqa: BLE001
        await run.eventos.put({"tipo": "error_bomba", "detalle": str(exc)})


async def lanzar(ctx: dict,
                  validador: str, cargo: str,
                  validador_2: Optional[str] = None,
                  cargo_2: Optional[str] = None) -> str:
    """
    Inicia una corrida en el contexto de sesión `ctx`. Devuelve `run_id`.

    Rechaza con ValueError si la MISMA sesión ya tiene un run activo:
    dos corridas paralelas del mismo modelo bifurcarían su cadena de
    custodia. Otras sesiones sí pueden correr en paralelo.
    """
    clave       = ctx["clave"]
    base_sesion = ctx["base"]
    modelo      = ctx["modelo"]

    with _lock:
        prev = _runs.get(clave)
        if prev is not None and prev.estado in ("arrancando", "corriendo"):
            raise ValueError(
                f"ya hay una corrida activa para {clave} ({prev.run_id})")

    # [WEB-V2.4] Si el validador subió y CONFIRMÓ un estándar en el paso 02,
    # se pasa vía --estandares. Sin confirmación (solo subido) no se aplica:
    # el paso 02 es el que valida el fichero antes de gastar en la corrida.
    from . import estandares_service as _est
    _st = _est.estado(ctx)
    _est_override = Path(_st["ruta_xlsx"]) if _st.get("confirmado") and _st.get("ruta_xlsx") else None

    args = construir_args(
        base_sesion=base_sesion,
        titulo=modelo["nombre"], tier=modelo["tier"], dominio=modelo["dominio"],
        validador=validador, cargo=cargo,
        validador_2=validador_2, cargo_2=cargo_2,
        estandar_override=_est_override,
    )

    previos = _snapshot_outputs_hoy(base_sesion)
    run = Run(
        run_id=uuid.uuid4().hex[:12],
        clave=clave,
        base_sesion=base_sesion,
        args=args,
        iniciado_utc=datetime.utcnow().isoformat(timespec="seconds") + "Z",
    )
    with _lock:
        _runs[clave] = run
        _por_id[run.run_id] = run

    # [WEB-V2.3] Env del subprocess: presupuesto de contexto según el modelo
    # detectado + override del rol del agente si el validador lo editó.
    # Sin esto el subprocess corre con VIRF_MAX_CTX=15000 (default) aunque el
    # deployment sea GPT-4o (128K) — se desperdicia el 99% de la ventana.
    env_hijo = _construir_env_hijo(ctx)

    await run.eventos.put({
        "tipo": "arranque", "args": args[1:],
        "presupuesto_max_ctx": env_hijo.get("VIRF_MAX_CTX"),
        "rol_agente_editado":  "VIRF_ROL_AGENTE_OVERRIDE" in env_hijo,
    })

    run.proceso = await asyncio.create_subprocess_exec(
        *args,
        cwd=str(PROYECTO_DIR),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
        env=env_hijo,
    )
    run.estado = "corriendo"

    async def _supervisar() -> None:
        await _bombear_stdout(run)
        assert run.proceso is not None
        rc = await run.proceso.wait()
        run.exit_code = rc
        run.terminado_utc = datetime.utcnow().isoformat(timespec="seconds") + "Z"
        # Clasificación del cierre. OJO Windows: terminate() aquí NO deja un
        # returncode negativo (como POSIX con SIGTERM) sino rc=1, así que
        # `rc < 0` jamás se cumple en Windows y una cancelación se veía como
        # "error". Nos apoyamos en la bandera explícita `run.cancelado`.
        if rc == 0:
            run.estado = "ok"
        elif run.cancelado or rc < 0:
            run.estado = "cancelado"
        else:
            run.estado = "error"
        run.resultado_json = _detectar_json_nuevo(
            base_sesion, previos, modelo["nombre"])
        await run.eventos.put({
            "tipo":     "fin",
            "exit":     rc,
            "estado":   run.estado,
            "resultado_json": run.resultado_json,
        })

    tarea = asyncio.create_task(_supervisar())
    _tareas.add(tarea)                      # ver `_tareas`: evita que el GC la mate
    tarea.add_done_callback(_tareas.discard)
    return run.run_id


async def cancelar(run_id: str) -> bool:
    r = _por_id.get(run_id)
    if r is None or r.proceso is None or r.proceso.returncode is not None:
        return False
    r.cancelado = True   # antes de terminate(): así _supervisar lo clasifica bien
    try:
        r.proceso.terminate()
    except ProcessLookupError:
        r.cancelado = False
        return False
    return True
