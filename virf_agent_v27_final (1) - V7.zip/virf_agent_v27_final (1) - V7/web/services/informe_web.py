"""
Generador de informe consolidado por sesión («Generar informe» de la web).

Desde 2026-11 usa la plantilla común `modulos.plantilla_bcp`, la misma del
apartado «Solo Informe» y del entregable del pipeline: portada BCP, encabezado
«Página | N», índice con hipervínculos, I. Objetivos … VII. Barrido de
Controles, y anexos al final. La calificación (Deficiente / Regular / Aceptable /
Satisfactorio) sale de `modulos.reglas_informe`, traduciendo el puntaje del
agente a riesgo (`riesgo_desde_puntaje`) DESPUÉS de aplicar las decisiones del
chat: un APROBADO cuenta como subsanado; NEGADO y PENDIENTE conservan el riesgo.

Lo que este informe sabe y Solo Informe no, va donde corresponde:
- En el barrido, por control: puntaje del agente, evidencia citada del manual,
  contraste de fuentes (manual ↔ implementación ↔ código), código, citas sin
  verificar, salvaguardas aplicadas y el diálogo/decisión del chat.
- En V. Cuadro Resumen: además, las observaciones de las automatizaciones
  (Excels 00–03), que ya traen riesgo, responsable y fecha.
- Anexos: tabla de validación final (8 columnas), entendimiento del modelo,
  cuadro de las automatizaciones y trazabilidad.

Mantiene el versionado V1/V2/V3 por sesión y el puntaje final recomputado con
las decisiones del chat (como información complementaria de la conclusión).
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable, Optional

from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt, RGBColor

from modulos import plantilla_bcp as plantilla
from modulos import reglas_informe as reglas
# Primitivas editoriales: viven en la plantilla común (se reexportan aquí por
# compatibilidad con quien las importaba de este módulo).
from modulos.plantilla_bcp import (  # noqa: F401
    _ALIGN, _ANCHO_UTIL_CM, _AZUL, _AZUL2, _GRIS, _HEADER_FILL, _SELLO, _TINTA,
    _bloque_codigo, _callout, _caption, _cell_left_accent, _cell_margins,
    _estilo_base, _etiqueta_valor, _forzar_ancho, _linea_horizontal, _p, _run,
    _salto_pagina, _set_cell_bg, _tabla, _tbl_header_repeat, campo, cita,
)

from ..config_web import PROYECTO_DIR  # noqa: F401
from . import chat_service

_sombra = _set_cell_bg   # alias retro-compatible


# ── Ubicación de salida por sesión ────────────────────────────────────

def salida_dir_de(ctx: dict) -> Path:
    d = ctx["outputs"]
    d.mkdir(parents=True, exist_ok=True)
    return d


_NOMBRE_RE = re.compile(r"^VIRF_Informe_.+_V(\d+)_\d{8}\.docx$")


def _nombre_canonico(ctx: dict, cuando: datetime) -> tuple[str, int]:
    """(nombre, versión). La versión es 1 + max(V*) existente en la carpeta."""
    salida = salida_dir_de(ctx)
    slug = ctx["modelo"]["slug"]
    max_v = 0
    for p in salida.iterdir():
        if not p.is_file() or p.suffix != ".docx":
            continue
        m = _NOMBRE_RE.match(p.name)
        if m and p.name.startswith(f"VIRF_Informe_{slug}_V"):
            max_v = max(max_v, int(m.group(1)))
    v = max_v + 1
    fecha = cuando.strftime("%d%m%Y")
    return f"VIRF_Informe_{slug}_V{v}_{fecha}.docx", v


def listar_versiones(ctx: dict) -> list[dict]:
    """Enumera los informes generados en esta sesión, más nuevos primero."""
    salida = salida_dir_de(ctx)
    slug = ctx["modelo"]["slug"]
    filas = []
    for p in sorted(salida.iterdir(), reverse=True):
        if not p.is_file() or p.suffix != ".docx":
            continue
        if not p.name.startswith(f"VIRF_Informe_{slug}_V"):
            continue
        m = _NOMBRE_RE.match(p.name)
        if not m:
            continue
        filas.append({
            "nombre":   p.name,
            "version":  int(m.group(1)),
            "tam":      p.stat().st_size,
            "generado": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
        })
    filas.sort(key=lambda x: x["version"], reverse=True)
    return filas



# ── Utilidades de datos y estilo propio del consolidado ───────────────

# Severidad de una inconsistencia → color del rótulo / relleno del callout.
_SEV_COLOR = {
    "alta":  RGBColor(0xC0, 0x39, 0x2B),
    "media": RGBColor(0xB8, 0x83, 0x2B),
    "baja":  RGBColor(0x6E, 0x74, 0x80),
}
_SEV_FILL = {"alta": "F7E4E0", "media": "F6EDD8", "baja": "EDEDF0"}

# Resultado formal → relleno de celda (columna Resultado de la tabla final).
_COLOR_RESULTADO_DOCX = {
    "Cumple": "C6EFCE", "Parcial": "FFEB9C", "No cumple": "FFC7CE",
    "No evidenciado": "FCE4D6", "No aplicable": "E7E6E6", "Pendiente": "D9E1F2",
}




def _titulo(doc, texto, nivel: int) -> None:
    """Título con estilo REAL de Word (alimenta el índice). Nivel 1 centrado."""
    h = doc.add_heading(level=nivel)
    h.alignment = WD_ALIGN_PARAGRAPH.CENTER if nivel == 1 else WD_ALIGN_PARAGRAPH.LEFT
    pf = h.paragraph_format
    pf.keep_with_next = True
    pf.space_before = Pt(16 if nivel == 1 else 10)
    pf.space_after = Pt(8 if nivel == 1 else 5)
    size = {1: 19, 2: 14.5, 3: 12.5}.get(nivel, 12)
    _run(h, texto, size=size, bold=True, color=(_AZUL if nivel <= 1 else _AZUL2))



def _first(d: dict, *claves: str) -> str:
    for k in claves:
        v = d.get(k)
        if v not in (None, "", [], {}):
            return v
    return ""


def _sev(x: Any) -> str:
    s = str(x or "").strip().lower()
    return s if s in _SEV_COLOR else "media"


# ── TOC · pie de página · adornos ─────────────────────────────────────


# ── Glosario: términos técnicos presentes en el informe ───────────────

_CATALOGO_GLOSARIO = {
    "Backtesting": "Contraste retrospectivo de las predicciones del modelo (p. ej. excepciones de VaR) contra lo efectivamente observado.",
    "Cadena de custodia": "Registro sellado que acredita la integridad y trazabilidad de la evidencia y de los resultados.",
    "Christoffersen": "Prueba de independencia de las excepciones de VaR; detecta si los fallos se agrupan en el tiempo.",
    "EWMA": "Media móvil exponencialmente ponderada para estimar volatilidad, dando más peso a los datos recientes.",
    "Excedencia": "Observación en la que la pérdida real supera el VaR estimado para ese día.",
    "GARCH": "Modelo de volatilidad condicional que captura su persistencia y agrupamiento en el tiempo.",
    "Kupiec": "Prueba de proporción de fallos (POF): evalúa si el número de excepciones de VaR es compatible con el nivel de confianza.",
    "LaR": "Liquidity at Risk: máxima pérdida potencial de liquidez en un horizonte y nivel de confianza dados.",
    "LCR": "Coeficiente de cobertura de liquidez (Basilea III): activos líquidos de alta calidad sobre salidas netas a 30 días.",
    "NSFR": "Coeficiente de financiación estable neta (Basilea III): fondeo estable disponible sobre el requerido.",
    "RAG": "Recuperación de literatura especializada del dominio que enriquece la evaluación con fuentes citables.",
    "Score global": "Puntaje agregado 1–5 de la validación; condición necesaria, no suficiente, para aprobar.",
    "Semáforo": "Clasificación por color del estado del modelo según el puntaje y las políticas del procedimiento.",
    "Tier": "Nivel de criticidad del modelo que gradúa la exigencia de la validación.",
    "VaR": "Valor en Riesgo: máxima pérdida esperada para un horizonte y nivel de confianza dados.",
}


def _terminos_presentes(datos: dict, ctx: dict, maximo: int = 12) -> list[tuple[str, str]]:
    """Términos del catálogo que REALMENTE aparecen en el informe, alfabéticos."""
    blob = json.dumps(datos, ensure_ascii=False).lower()
    dom = str((ctx.get("modelo") or {}).get("dominio") or "").lower()
    blob += " " + dom
    elegidos = []
    for termino, definicion in _CATALOGO_GLOSARIO.items():
        clave = termino.lower().split("(")[0].strip()
        if clave in blob:
            elegidos.append((termino, definicion))
    elegidos.sort(key=lambda t: t[0].lower())
    return elegidos[:maximo]



# ── Anexo: cuadro de las automatizaciones (Excels 00–03) ──────────────

def _ultimo_cuadro(ctx: Optional[dict]) -> Optional[dict]:
    """Último cuadro de observaciones de las automatizaciones (Excels 00–03)."""
    if not ctx or "outputs" not in ctx:
        return None
    sal = Path(ctx["outputs"]) / "automatizaciones"
    jsons = sorted(sal.glob("cuadro_observaciones_*.json")) if sal.is_dir() else []
    if not jsons:
        return None
    try:
        return json.loads(jsons[-1].read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


_FILL_RIESGO = {"Crítico": "F5C6C0", "Moderado": "F6E3B4", "Potencial/Bajo": "D9EAD3"}


def _cuadro_observaciones(doc, cuadro: dict) -> None:
    """Anexo: Ámbito · Riesgo · Observación · Recomendación · Responsable/Fecha,
    con la procedencia de cada riesgo (03_Impactos o estimado)."""
    fuentes = ", ".join(f"{c}_{l.get('etapa', '')}" for c, l in
                        (cuadro.get("libros") or {}).items())
    nota = (f"Elaborado a partir de los resultados de las automatizaciones del producto "
            f"({fuentes or 'sin fuentes'}).")
    if cuadro.get("riesgo_desde_impactos"):
        nota += " El riesgo de las observaciones vinculadas a 03_Impactos procede de ese Excel."
    else:
        nota += " No se aportó 03_Impactos: el riesgo es una estimación del validador."
    if cuadro.get("modo") == "determinista":
        nota += " BORRADOR determinista: la redacción debe revisarse antes de emitir."
    _p(doc, nota, size=9.5, italic=True, color=_GRIS, align="l", space_after=4)

    filas = []
    for f in cuadro.get("filas") or []:
        obs = (f"{f['titulo']}. " if f.get("titulo") else "") + f.get("observacion", "")
        riesgo = f.get("riesgo", "") + ("" if str(f.get("riesgo_fuente", "")).startswith("03_")
                                        else " (estimado)")
        filas.append([f.get("ambito", ""), riesgo, obs, f.get("recomendacion", ""),
                      f"{f.get('responsable', '')} — {f.get('fecha_compromiso', '')}"])
    if not filas:
        _p(doc, "Las automatizaciones no presentan resultados que ameriten observación.",
           size=10.5, italic=True, color=_GRIS, align="l")
        return
    tabla = _tabla(doc, ["Ámbito", "Riesgo", "Observación", "Recomendación",
                         "Responsable / Fecha"], filas,
                   widths_cm=[2.2, 1.9, 6.0, 4.6, 2.5], aligns=["l", "c", "l", "l", "l"],
                   cap_font=8.5)
    if tabla is not None:
        for i, f in enumerate(cuadro.get("filas") or [], start=1):
            color = _FILL_RIESGO.get(f.get("riesgo"))
            if color and i < len(tabla.rows):
                _set_cell_bg(tabla.rows[i].cells[1], color)
    _caption(doc, "Cuadro 1. Observaciones de validación de las automatizaciones.")



# ── Anexo: tabla de validación final (título/encabezados fijos: hay tests) ──

def _seccion_tabla_final(doc, datos, ctx,
                         titulo: Optional[str] = "2. Tabla de validación (final)"):
    """Tabla de 8 columnas tras el chat. Con `titulo=None` no pinta título
    (en el informe va como anexo, titulado por la plantilla)."""
    from dataclasses import asdict
    from modulos.consolidacion import consolidar_decisiones, tabla_final

    s = chat_service.sesion_activa(ctx)
    obs = [asdict(o) for o in s.observaciones] if s is not None else []
    filas = tabla_final(datos, obs)

    if titulo:
        _titulo(doc, titulo, 1)
    if not filas:
        _p(doc, "Esta corrida no generó una tabla de validación (sin resultados por "
                "actividad). Ejecuta el pipeline de validación para poblar esta sección.",
           size=10.5, italic=True, color=_GRIS, align="l")
        return
    con = consolidar_decisiones(datos, obs)

    si = datos.get("score_global"); sf = con.get("score_final_global")
    _p(doc, f"Puntaje inicial (agente): {si if si is not None else '—'} / 5"
            f"   →   PUNTAJE FINAL (validado): "
            f"{round(sf, 2) if sf is not None else '—'} / 5", size=12, bold=True,
       color=_AZUL, align="l", space_after=4)
    rf = con.get("resumen_final") or {}
    _p(doc, f"Decisiones del chat: {rf.get('cumple_subsanado', 0)} subsanada(s) · "
            f"{rf.get('no_cumple_confirmado', 0)} confirmada(s) · "
            f"{rf.get('pendiente', 0)} pendiente(s).", size=9.5, italic=True, color=_GRIS,
       align="l")

    cols = ["Ámbito", "Control", "Actividad", "Aplica",
            "Resultado", "Sustento", "Evidencia", "Plan de acción"]
    widths = [1.7, 2.1, 2.3, 1.0, 1.4, 3.3, 2.4, 2.2]
    aligns = ["l", "l", "l", "c", "c", "l", "l", "l"]

    tabla = doc.add_table(rows=1, cols=len(cols))
    tabla.style = "Table Grid"
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, t in enumerate(cols):
        celda = tabla.rows[0].cells[i]
        _set_cell_bg(celda, _HEADER_FILL); _cell_margins(celda)
        par = celda.paragraphs[0]
        par.alignment = _ALIGN.get(aligns[i], WD_ALIGN_PARAGRAPH.LEFT)
        _run(par, t, size=8.5, bold=True, color=_AZUL)

    for f in filas:
        row = tabla.add_row().cells
        aplica = "No" if str(f.get("resultado")) == "No aplicable" else "Sí"
        vals = [
            f.get("ambito", ""), f.get("control", ""), f.get("actividad", ""),
            aplica, f.get("resultado", ""),
            (f.get("evaluacion_sustentada", "") or "")[:420],
            (f.get("fuente_revisada", "") or "")[:260],
            (f.get("accion_requerida", "") or "")[:260],
        ]
        for i, v in enumerate(vals):
            _cell_margins(row[i])
            par = row[i].paragraphs[0]
            par.paragraph_format.line_spacing = 1.15
            par.alignment = _ALIGN.get(aligns[i], WD_ALIGN_PARAGRAPH.LEFT)
            _run(par, str(v), size=8.5)
        color = _COLOR_RESULTADO_DOCX.get(str(f.get("resultado")))
        if color:
            _set_cell_bg(row[4], color)
    _forzar_ancho(tabla, widths)
    tabla.rows[0]._tr.get_or_add_trPr().append(_tbl_header_repeat())
    _caption(doc, "Tabla 3. Validación final por actividad, con el resultado tras el chat de sustentación.")



# ── Anexos: entendimiento y trazabilidad ───────────────────────────────

def _seccion_entendimiento(doc, ctx) -> bool:
    """Anexo fijo (siempre presente). Placeholder si no hay entendimiento."""
    from . import analisis_codigo as _acod
    try:
        md = _acod.leer_md(ctx)
    except Exception:
        md = ""
    if not md:
        _p(doc, "No se registró un análisis de entendimiento del modelo en esta sesión "
                "(se genera al subir el código del modelo para su mapeo).",
           size=10.5, italic=True, color=_GRIS, align="l")
        return False
    for linea in md.splitlines():
        s = linea.rstrip()
        if not s:
            continue
        if s.startswith("# "):
            _titulo(doc, s[2:].strip(), 2)
        elif s.startswith("## "):
            _titulo(doc, s[3:].strip(), 2)
        elif s.startswith("### "):
            _p(doc, s[4:].strip(), size=11, bold=True, color=_AZUL2, align="l", space_after=2)
        elif s.startswith(("- ", "* ")):
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.line_spacing = 1.25
            _run(p, s[2:].strip(), size=10.5)
        elif s.startswith("|"):
            _p(doc, s, size=9)
        else:
            _p(doc, s, size=10.5)
    fbs = _acod.leer_feedbacks(ctx)
    if fbs:
        _titulo(doc, "Correcciones del validador al entendimiento", 2)
        for f in fbs:
            _p(doc, f"· ({f.get('timestamp','')[:19]}) {f.get('comentario','')}", size=9.5, align="l")
    return True


def _seccion_trazabilidad(doc, datos, ctx, version):
    _p(doc, f"Versión de este informe: V{version}.", size=10.5, align="l")
    agente = datos.get("agente") or {}
    filas = [[k, str(agente[k])] for k in ("version", "modelo_ia", "dominio_rag", "huella_ejecucion")
             if agente.get(k)]
    if filas:
        _titulo(doc, "Parámetros de ejecución", 2)
        _tabla(doc, ["Parámetro", "Valor"], filas,
               widths_cm=[5.4, 11.0], aligns=["l", "l"])
    huellas = ((datos.get("integridad") or {}).get("evidencia_huellas")
               or datos.get("documentos_huella") or {})
    if huellas:
        _titulo(doc, "Huellas SHA-256 de la evidencia", 2)
        hfilas = []
        for nombre, meta in list(huellas.items())[:40]:
            sha = (meta or {}).get("sha256") if isinstance(meta, dict) else str(meta)
            hfilas.append([str(nombre), str(sha)])
        _tabla(doc, ["Documento", "SHA-256"], hfilas,
               widths_cm=[6.6, 9.8], aligns=["l", "l"], cap_font=8)
    _titulo(doc, "Contexto de sesión", 2)
    val = ctx.get("validador") or {}; mod = ctx.get("modelo") or {}
    _tabla(doc, ["Campo", "Valor"], [
        ["Validador", f"{val.get('codigo','—')} — {val.get('nombre','—')}"],
        ["Modelo", f"{mod.get('slug','—')} ({mod.get('nombre','—')})"],
        ["Base de sesión", str(ctx.get("base", "—"))],
    ], widths_cm=[4.0, 12.4], aligns=["l", "l"])


# ══════════════════════════════════════════════════════════════════════
#  Traducción a la plantilla común (I–VII + anexos)
# ══════════════════════════════════════════════════════════════════════

_TEXTO_POR_RIESGO = {
    "Crítico": "No cumple con los criterios de validación establecidos para esta actividad.",
    "Moderado": "Cumplimiento parcial: existen brechas que requieren atención.",
    "Oportunidad de Mejora": "Cumplimiento sustancial, con aspectos que conviene mejorar.",
}

# Riesgo de las automatizaciones (03_Impactos) → catálogo de la regla.
_RIESGO_CUADRO = {"Crítico": "Crítico", "Moderado": "Moderado", "Potencial/Bajo": "Bajo",
                  "Bajo": "Bajo", "Potencial": "Potencial"}


def _puntaje(ev: dict):
    p = ev.get("puntaje")
    return p if isinstance(p, (int, float)) else None


def _chat(ctx) -> tuple[dict, dict]:
    """(ámbito, actividad) → observación del chat; id de observación → mensajes."""
    s = chat_service.sesion_activa(ctx) if ctx else None
    obs_por_clave: dict = {}; mensajes_por_obs: dict = {}
    if s is not None:
        for o in s.observaciones:
            obs_por_clave[(o.ambito, o.actividad)] = o
        for m in s.mensajes:
            if m.observacion_id:
                mensajes_por_obs.setdefault(m.observacion_id, []).append(m)
    return obs_por_clave, mensajes_por_obs


# ── Capturas de evidencia («pantallazos») ─────────────────────────────

# Contradicciones con captura por control: el resto queda en texto, para que un
# control con decenas de ambigüedades no convierta el informe en un álbum.
_MAX_INC_CON_CAPTURA = 3


class _Capturas:
    """
    Estado de las capturas de un informe: dónde se guardan, dónde se buscan los
    documentos y qué portadas ya se insertaron (cada portada va una sola vez; los
    demás controles que revisan el mismo documento remiten a ella).

    Raíces de búsqueda: las entradas de la sesión y, como respaldo, `inputs/` del
    proyecto (donde trabaja el agente de línea de comandos). Solo se usa un
    fichero si su NOMBRE coincide con el que citó el agente.
    """

    def __init__(self, ctx: dict):
        self.carpeta = Path(ctx.get("outputs") or ".") / "capturas"
        self.raices = [Path(r) for r in (ctx.get("inputs"), PROYECTO_DIR / "inputs") if r]
        self.portadas: dict[str, str] = {}      # documento → actividad donde se mostró

    def doc(self, nombre: str) -> Optional[Path]:
        from modulos import capturas as cap
        return cap.localizar(nombre, self.raices)


def _figura(doc, ruta, pie: str, ancho_cm: float) -> None:
    from modulos import plantilla_bcp as PB
    if ruta and PB._imagen(doc, ruta, ancho_cm):
        _caption(doc, pie)


def _captura_cita(doc, capt: _Capturas, nombre: str, cita_txt: str, pie: str) -> None:
    from modulos import capturas as cap
    ruta = capt.doc(nombre)
    if ruta is None:
        return
    if ruta.suffix.lower() in cap.EXT_CODIGO:
        png = cap.captura_codigo(cita_txt, capt.carpeta, archivo=ruta)
        _figura(doc, png, f"{pie} — {ruta.name}", 15.5)
        return
    res = cap.captura_cita(ruta, cita_txt, capt.carpeta)
    if res:
        png, desc = res
        ancho = 12.5 if ruta.suffix.lower() == ".pdf" else 15.5
        _figura(doc, png, f"{pie} — {desc}", ancho)


def _portadas(doc, c, capt: _Capturas) -> None:
    """Controles de Documentación: portada de cada documento PDF que revisan."""
    from modulos import capturas as cap
    ev = c["_ev"]
    nombres = [a for a, _ in cap.citas_en_evidencia(
        _first(ev, "evidencia_encontrada", "evidencia", "evidence_text") or "")]
    for inc in ev.get("inconsistencias") or []:
        if isinstance(inc, dict):
            nombres += [inc.get("fuente_a") or "", inc.get("fuente_b") or ""]
    vistos = []
    for n in nombres:
        if n and n.lower().endswith(".pdf") and n not in vistos:
            vistos.append(n)
    for n in vistos:
        if n in capt.portadas:
            campo(doc, f"Portada de {n}",
                  f"ver la captura en el control «{capt.portadas[n]}».")
            continue
        ruta = capt.doc(n)
        png = cap.captura_portada(ruta, capt.carpeta) if ruta else None
        if png:
            capt.portadas[n] = c["actividad"]
            _figura(doc, png, f"Portada del documento revisado — {n}", 8.5)


def _detalle_control(doc, c, os_, capt: Optional[_Capturas] = None):
    """Lo que el agente y el chat aportan sobre el control, en texto estructurado
    y, si se encuentran los documentos, con capturas de la evidencia."""
    ev, o, mensajes = c["_ev"], c.get("_chat"), c.get("_mensajes") or []
    pj = _puntaje(ev)
    if pj is not None:
        campo(doc, "Puntaje del agente", f"{pj:g} / 5")
    if not os_ and not c.get("no_evaluado"):
        ev_txt = _first(ev, "observacion", "evaluacion", "concepto_tecnico")
        if ev_txt:
            campo(doc, "Evaluación", ev_txt)

    if capt is not None and reglas.clave_ambito(c["ambito"]) == "documentacion":
        _portadas(doc, c, capt)

    manual = _first(ev, "evidencia_encontrada", "evidencia", "evidence_text")
    if manual:
        cita(doc, "Evidencia en el manual / documento", f"«{manual}»")
        if capt is not None:
            from modulos import capturas as cap
            for archivo, frag in cap.citas_en_evidencia(manual)[:2]:
                _captura_cita(doc, capt, archivo, frag, "Evidencia")

    n_capt = 0

    for inc in (ev.get("inconsistencias") or []):
        if not isinstance(inc, dict):
            continue
        sev = _sev(inc.get("severidad"))
        campo(doc, f"Ambigüedad de fuentes (severidad {sev})")
        fa = _first(inc, "fuente_a", "fuente_manual", "manual") or "Manual / documento"
        ca = _first(inc, "cita_a", "cita_manual", "fragmento_manual")
        fb = _first(inc, "fuente_b", "fuente_codigo", "implementacion") or "Implementación / código"
        cb = _first(inc, "cita_b", "cita_codigo", "fragmento_codigo")
        contra = _first(inc, "contradiccion", "explicacion", "detalle")
        if ca:
            cita(doc, fa, f"«{ca}»", sangria=1.2)
        if cb:
            cita(doc, fb, f"«{cb}»", sangria=1.2)
        if contra:
            cita(doc, "Por qué importa", contra, aviso=True, sangria=1.2)
        if capt is not None and n_capt < _MAX_INC_CON_CAPTURA and (ca or cb):
            n_capt += 1
            if ca:
                _captura_cita(doc, capt, fa, ca, "Sustento A")
            if cb:
                _captura_cita(doc, capt, fb, cb, "Sustento B")

    cm = _first(ev, "cuestionamiento_metodologico")
    if cm and "no aplica" not in str(cm).strip().lower()[:12]:
        campo(doc, "Cuestionamiento metodológico", cm)

    codigo = _first(ev, "codigo_snippet", "fragmento_codigo", "code_evidence")
    if codigo:
        ref = _first(ev, "codigo_ref", "archivo", "fragmento_ref")
        _bloque_codigo(doc, str(codigo)[:1400], ref)
        if capt is not None:
            # Captura del código en su fichero (con contexto y números de línea).
            from modulos import capturas as cap
            archivo = capt.doc(str(ref).split(":")[0]) if ref else None
            png = cap.captura_codigo(str(codigo), capt.carpeta, archivo=archivo,
                                     nombre=str(ref or ""))
            _figura(doc, png, f"Captura del código{' — ' + str(ref) if ref else ''}", 15.5)

    cnv = ev.get("citas_no_verificadas") or []
    if cnv:
        cita(doc, "Citas sin verificar (revisar contra la fuente)",
             " · ".join(str(x) for x in cnv[:6]), aviso=True)

    ent = ev.get("entailment") or {}
    if ent.get("estado") == "ok" and ent.get("implica") is False:
        cita(doc, "Verificación semántica de la cita",
             f"La evidencia citada NO sostiene la observación ({ent.get('motivo', '')}). "
             "Revisar antes de firmar.", aviso=True)
    elif ent.get("estado") == "ok" and ent.get("implica") is True:
        campo(doc, "Verificación semántica", "La evidencia citada sostiene la observación.")

    iny = ev.get("inyeccion_detectada") or []
    if iny:
        cita(doc, "Posible manipulación en la evidencia",
             f"Se detectaron y neutralizaron {len(iny)} tramo(s) con pinta de instrucción "
             "inyectada dirigida al evaluador. Es un hallazgo sobre el documento: "
             "revísalo en la fuente.", aviso=True)

    pii = ev.get("pii_enmascarada") or []
    if pii:
        campo(doc, "Datos personales enmascarados",
              "Antes de enviar la evidencia al modelo se ocultaron: "
              + ", ".join(f"{h.get('tipo')}×{h.get('n')}" for h in pii) + ".")

    pp = ev.get("preguntas_pendientes") or []
    if pp:
        campo(doc, "Preguntas pendientes del agente", " · ".join(map(str, pp)))

    if o is not None:
        if mensajes:
            campo(doc, "Diálogo con el validador")
            for m in mensajes:
                quien = "Agente" if m.quien == "agente" else "Validador"
                p = campo(doc, f"{quien} · {m.ts_utc[:19]}"
                               + (f" · {m.veredicto}" if m.veredicto else ""),
                          str(m.texto or "").replace("```", ""), sangria=1.2)
                p.runs[0].font.color.rgb = _GRIS
        if getattr(o, "veredicto", "") in ("APROBADO", "NEGADO", "PENDIENTE"):
            campo(doc, "Decisión del chat", o.veredicto
                  + (f" — {o.hallazgo_final}" if getattr(o, "hallazgo_final", "") else ""))


def a_plantilla(datos: dict[str, Any], ctx: dict, version: int = 1) -> dict:
    """Resultados de la corrida + chat + automatizaciones → informe normalizado."""
    mod = ctx.get("modelo") or {}
    val = ctx.get("validador") or {}
    obs_chat, mensajes_por_obs = _chat(ctx)
    capt = _Capturas(ctx)

    ambitos: list[str] = []
    controles: list[dict] = []
    observaciones: list[dict] = []
    for ambito, evs in (datos.get("resultados_por_ambito") or {}).items():
        for ev in (evs or []):
            if ambito not in ambitos:
                ambitos.append(ambito)
            cid = f"E{len(controles) + 1:03d}"
            o = obs_chat.get((ambito, ev.get("actividad")))
            veredicto = str(getattr(o, "veredicto", "") or "").upper()
            pj = _puntaje(ev)
            sin_ev = bool(ev.get("sin_evidencia"))
            c = {
                "id": cid, "ambito": ambito,
                "control": _first(ev, "control") or "",
                "control_especifico": "",
                "actividad": ev.get("actividad") or "(actividad)",
                "descripcion": _first(ev, "concepto") or "",
                "no_evaluado": pj is None and not sin_ev,
                "_ev": ev, "_chat": o,
                "_mensajes": mensajes_por_obs.get(getattr(o, "id", None), []) if o else [],
            }
            if veredicto == "APROBADO":
                c["nota_resultado"] = "observación subsanada en el chat de sustentación"
                riesgo = None
            else:
                riesgo = reglas.riesgo_desde_puntaje(pj, sin_evidencia=sin_ev)
            controles.append(c)
            if riesgo:
                observaciones.append({
                    "control_id": cid, "ambito": ambito, "riesgo": riesgo,
                    "observacion": (_first(ev, "observacion", "evaluacion", "concepto_tecnico")
                                    or _TEXTO_POR_RIESGO.get(riesgo, "")),
                    "recomendacion": _first(ev, "recomendacion", "accion_requerida"),
                })

    # Observaciones de las automatizaciones (traen riesgo, responsable y fecha).
    cuadro = _ultimo_cuadro(ctx)
    for f in (cuadro or {}).get("filas") or []:
        r = _RIESGO_CUADRO.get(str(f.get("riesgo") or "").strip())
        if not r:
            continue
        observaciones.append({
            "control_id": None, "ambito": f.get("ambito", ""), "riesgo": r,
            "actividad": "Automatizaciones (Excels 00–03)",
            "observacion": (f"{f['titulo']}. " if f.get("titulo") else "") + f.get("observacion", ""),
            "recomendacion": f.get("recomendacion", ""),
            "responsable": f.get("responsable", ""),
            "fecha_subsanacion": str(f.get("fecha_compromiso") or "")[:10],
        })

    n_ne = sum(1 for c in controles if c["no_evaluado"])
    hay_entendimiento = _hay_entendimiento(ctx)
    contexto = (
        f"Modelo {mod.get('nombre', '—')} ({mod.get('slug', '—')}) del dominio "
        f"{mod.get('dominio', '—')}, Tier {mod.get('tier', '—')}.\n\n"
        f"El presente informe consolida la corrida del agente VIRF"
        f"{' del ' + str(datos['fecha'])[:10] if datos.get('fecha') else ''}, con "
        f"{len(controles)} actividad(es) evaluada(s) en {len(ambitos)} ámbito(s), y las "
        "decisiones tomadas por el validador en el chat de sustentación."
        + ("\n\nEl entendimiento detallado del modelo se presenta en el Anexo B."
           if hay_entendimiento else ""))
    limitaciones = []
    if n_ne:
        limitaciones.append(f"{n_ne} actividad(es) no pudieron evaluarse por un fallo técnico "
                            "durante la corrida y deben re-ejecutarse.")
    n_cnv = sum(1 for c in controles if c["_ev"].get("citas_no_verificadas"))
    if n_cnv:
        limitaciones.append(f"{n_cnv} actividad(es) contienen citas que no se pudieron "
                            "verificar literalmente contra la fuente.")

    def conclusion_extra(doc):
        _p(doc, "Información complementaria del agente (referencial; no sustituye a la "
                "calificación):", size=9.5, italic=True, color=_GRIS, align="l", space_after=2)
        from dataclasses import asdict
        from modulos.consolidacion import consolidar_decisiones
        s = chat_service.sesion_activa(ctx)
        con = consolidar_decisiones(datos, [asdict(x) for x in s.observaciones] if s else [])
        si, sf = datos.get("score_global"), con.get("score_final_global")
        campo(doc, "Puntaje del agente", f"inicial {si if si is not None else '—'} / 5 → "
                                         f"final {round(sf, 2) if sf is not None else '—'} / 5")
        rf = con.get("resumen_final") or {}
        campo(doc, "Decisiones del chat",
              f"{rf.get('cumple_subsanado', 0)} subsanada(s) · "
              f"{rf.get('no_cumple_confirmado', 0)} confirmada(s) · "
              f"{rf.get('pendiente', 0)} pendiente(s)", seguir=False)
        pol = datos.get("politicas_procedimiento") or {}
        crit, veto = pol.get("criticos_automaticos") or [], pol.get("veto_por_ambito") or []
        if crit:
            campo(doc, "§6 Críticos automáticos (score ≤ 2)", ", ".join(map(str, crit)), seguir=False)
        if veto:
            campo(doc, "§4.2 Ámbitos bajo el umbral (< 2.5)", ", ".join(map(str, veto)), seguir=False)

    anexos = [("Tabla de validación final", lambda d: _seccion_tabla_final(d, datos, ctx, titulo=None)),
              ("Entendimiento del modelo", lambda d: _seccion_entendimiento(d, ctx))]
    if cuadro is not None:
        anexos.append(("Cuadro de observaciones de las automatizaciones",
                       lambda d: _cuadro_observaciones(d, cuadro)))
    anexos.append(("Trazabilidad", lambda d: _seccion_trazabilidad(d, datos, ctx, version)))

    return {
        "tipo": "periodica",
        "nombre_modelo": mod.get("nombre") or mod.get("slug") or "modelo",
        "fecha_inicio": str(mod.get("creado_utc") or datetime.now().date())[:10],
        "fecha_entrega": datetime.now().strftime("%Y-%m-%d"),
        "responsable_doc": val.get("nombre", ""),
        "revisado_por": "",
        "contexto": contexto,
        "limitaciones": "\n\n".join(limitaciones),
        "ambitos": ambitos,
        "controles": controles,
        "observaciones": observaciones,
        "nota_alcance": f", aplicables a un modelo Tier {mod['tier']}" if mod.get("tier") else "",
        "nota_cuadro": ("Cuadro resumen de las observaciones: las del agente tras el chat de "
                        "sustentación y, si las hay, las de las automatizaciones (con su "
                        "responsable y fecha)."),
        "subtitulo_portada": f"Consolidado de cierre · versión V{version}",
        # Sigla = el propio término cuando es un acrónimo (VaR, LaR, EWMA, RAG…).
        "glosario_extra": [(t, t if len(t) <= 6 and sum(ch.isupper() for ch in t) >= 2
                            else "—", d)
                           for t, d in _terminos_presentes(datos, ctx)],
        "detalle_control": lambda doc, c, os_: _detalle_control(doc, c, os_, capt),
        "conclusion_extra": conclusion_extra,
        "anexos": anexos,
    }


def _hay_entendimiento(ctx) -> bool:
    try:
        from . import analisis_codigo as _acod
        return bool(_acod.leer_md(ctx))
    except Exception:                                 # noqa: BLE001
        return False


def generar(datos: dict[str, Any], ruta_json_origen: str, ctx: dict) -> tuple[Path, int]:
    """Genera el .docx versionado con la plantilla común. Devuelve `(ruta, version)`."""
    salida_dir = salida_dir_de(ctx)
    nombre, version = _nombre_canonico(ctx, datetime.now())
    ruta = plantilla.generar(a_plantilla(datos, ctx, version), salida_dir / nombre)
    return ruta, version
