"""
Rutas y constantes del backend web.

v2 · fase 2: los mapas de destino de upload viven ahora en
`web/services/contexto_sesion.py` (dependen de la sesión activa). Aquí
solo quedan las rutas que son GLOBALES al proyecto.
"""
from pathlib import Path

WEB_DIR      = Path(__file__).resolve().parent
PROYECTO_DIR = WEB_DIR.parent

# Nombres de archivo que NUNCA se aceptan por upload (por sesión o global).
# Se comprueba en lowercase por prudencia con FAT.
NOMBRES_PROHIBIDOS: set[str] = {
    ".env",
    "estandares_virf.xlsx",   # la vara de medir se cambia con proceso, no por upload
}
