# VIRF Web — capa web del agente

Interfaz web sobre el agente CLI (`agente.py`). Se construye en 10 pasos;
este README describe cómo arrancarlo tal como está hoy.

## Instalación

Desde la raíz del proyecto:

```bash
pip install -r web/requirements_web.txt
```

## Arrancar

Desde la raíz del proyecto (NO desde `web/`):

```bash
uvicorn web.app:app --reload --port 8000
```

Abre `http://localhost:8000` en un navegador moderno.

## Estado actual

**Paso 10/10 — informe consolidado en .docx.** (v1.0 completa)

Endpoints activos:

- `GET /` — dashboard.
- `GET /api/salud` — smoke test del backend.
- `GET /api/inputs/destinos` — slugs de destino aceptados con etiqueta legible.
- `GET /api/inputs/arbol` — árbol completo de `inputs/` con estado por fichero.
- `POST /api/inputs/upload?destino=<slug>` — archivos sueltos (rechaza ZIP).
- `POST /api/inputs/upload-zip?destino=<slug>` — ZIP. Con `destino=raiz` respeta
  la estructura del ZIP relativa a `inputs/`; con otros destinos aplana.
- `GET /api/config` — snapshot: sesión (modelo/tier/dominio), proveedor activo,
  qué credenciales están seteadas (sin exponer secretos), tiers válidos.
- `POST /api/config/modelo` — `{titulo, tier}` → guarda en memoria.
- `POST /api/config/proveedor` — `{proveedor, credenciales}` → escribe `.env`.
- `POST /api/config/verificar` — llama a `config.ia.prueba_de_humo` (1 request).
- `POST /api/dominio` — `{dominio: LaR|VaR|conductuales}` → guarda en sesión.
- `POST /api/prevuelo` — recorre `inputs/` y devuelve el informe de pre-vuelo
  (coste 0, no llama al modelo).
- `POST /api/validar/lanzar` — `{validador, cargo, validador_2?, cargo_2?}` →
  arranca `agente.py --prdc …` como subproceso. Devuelve `run_id`.
- `GET  /api/validar/estado` — snapshot del runner activo.
- `POST /api/validar/cancelar/{run_id}` — SIGTERM al subproceso.
- `WebSocket /ws/validar/{run_id}` — stream de eventos `arranque | fase |
  linea | ping | fin | error`.
- `GET /api/resultados/lista` — todos los `resultados_*.json` con score/semaforo.
- `GET /api/resultados/actual` — JSON de la corrida activa.
- `GET /api/resultados/{fecha}/{fichero}` — JSON específico (path traversal
  bloqueado por doble validación).
- `GET /api/motores/catalogo` — las 8 pruebas de `motores_datos`.
- `GET /api/motores/entidad` — lectura pura de las tablas de resultados de
  la entidad. **El agente no ejecuta los motores de la entidad** (test AST
  que impide `exec/eval/subprocess` en `motores_entidad.py`).
- `POST /api/chat/iniciar` — `{ruta: "YYYY-MM-DD/fichero.json"}` → crea la
  sesión de chat sobre un informe existente. Extrae las observaciones con
  puntaje ≤ 2 o `preguntas_pendientes` no vacías.
- `GET  /api/chat/estado` — snapshot de la sesión activa.
- `WebSocket /ws/chat` — cliente envía `{tipo: "responder", texto}`, el
  servidor responde con el estado completo.

### Chat sin crédito de API

`VIRF_MOCK_CHAT=1` en el `.env` hace que `_llamar_modelo` no se llame:
cada respuesta se contesta con un mock canned que devuelve `PENDIENTE`
al primer intento y `APROBADO` al segundo. Sirve para probar el flujo,
el WebSocket y el docx final sin gastar API. En modo real, cualquier
fallo del proveedor viaja al chat como mensaje de aviso — no maquillamos.

## Endpoints — cuestionamientos e informe

- `GET  /api/cuestionamientos/default` — 15 patrones de `Mx_00` con flag `activo`.
- `POST /api/cuestionamientos/default/{id}/toggle` — activar/desactivar.
- `GET  /api/cuestionamientos/personalizados` — listar personalizados.
- `POST /api/cuestionamientos/personalizados` — añadir uno nuevo (valida regex).
- `DELETE /api/cuestionamientos/personalizados/{id}` — eliminar.
- `POST /api/informe/consolidado` — `{ruta}` → genera un `.docx` bajo
  `outputs/web/` con portada, scores, políticas, actividades y (si hay
  sesión activa) el diálogo del chat.
- `GET  /api/informe/descargar/{fichero}` — sirve el `.docx` (MIME correcto).

## Cableado de cuestionamientos al motor real

Los cuestionamientos personalizados y las desactivaciones del catálogo por
defecto **se aplican al motor Mx_04** en cada corrida, sin reiniciar el
servidor. Cómo:

- `modulos/cuestionamientos_ext.py` fusiona
  `CUESTIONAMIENTOS_METODOLOGICOS` (fijo) + `config/cuestionamientos_activos.json`
  (opt-out) + `config/cuestionamientos_personalizados.json` (añadidos).
- `motor/Mx_04_MotorControlesData.detectar_cuestionamientos` consume ese
  catálogo fusionado en cada llamada — un `add` en la web afecta a la
  siguiente `--prdc` inmediatamente.
- Un patrón personalizado con regex inválido se **descarta y avisa**
  (nunca a medias). Un id que colisiona con un default también avisa;
  gana el default.

Los tests `TestCuestionamientosExtensibles` en `tests/test_regresion.py`
verifican estos invariantes.

Los demás botones de la barra lateral aún no hacen nada (llegan en los
pasos 4-10). El toggle de dominio actualiza el badge pero no configura
todavía el RAG del backend — eso es el paso 4.

### Sobre la verificación sin crédito de API

`POST /api/config/verificar` hace **una** llamada real al proveedor. Sin
saldo va a devolver `ok: false` con el error del proveedor tal cual. La
UI lo pinta en rojo con el detalle; **no maquilla la respuesta**, porque
un OK falso ante un problema real es exactamente el defecto que el
proyecto marca como inaceptable.

### Contrato de seguridad de los uploads

- Solo se acepta un `slug` del catálogo `DESTINOS` en `web/config_web.py`.
  Nunca una ruta cruda.
- Nombres saneados a basename; nombres prohibidos (`.env`,
  `estandares_virf.xlsx`) rechazados con 403.
- Miembros de ZIP validados uno a uno antes de escribir nada; entrada con
  `..`, absoluta o con byte nulo aborta la extracción entera.

## Restricción operativa

**No hay crédito de API para el proveedor IA.** Todo lo que necesite
llamar al modelo se probará interceptando `_llamar_modelo` con mocks,
como ya hace la suite del agente. Nada de este paso 1 depende de la API.
