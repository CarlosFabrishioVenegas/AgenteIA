import numpy as np
def ewma(returns, lam=0.94):
    return returns.ewm(alpha=1-lam).std()
class VarEngine:
    def compute(self, x): return ewma(x)
