from mod.var_engine import VarEngine
def backtesting(r): return VarEngine().compute(r)
