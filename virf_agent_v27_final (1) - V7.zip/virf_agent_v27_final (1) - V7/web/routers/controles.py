"""
Controles de calidad de datos (v2 · fase 2).

- Catálogo (motores_datos): global, no depende de la sesión.
- Resultados de la entidad (motores_entidad): se leen de la EVIDENCIA
  de la sesión activa (`ctx.inputs`), no del `inputs/` raíz.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Response

from ..config_web import PROYECTO_DIR
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/motores", tags=["controles-datos"])

_EXT_DOC = (".pdf", ".docx", ".md", ".txt")


def _doc_controles_de_sesion(ctx: dict) -> Optional[Path]:
    """Primer manual de extracción/controles subido a la sesión.

    Vive junto a los manuales de modelamiento y seguimiento, en
    documentacion/controles_datos/ (destino de upload `doc_controles_datos`).
    """
    carpeta = ctx["inputs"] / "documentacion" / "controles_datos"
    if carpeta.is_dir():
        for p in sorted(carpeta.iterdir()):
            if p.is_file() and p.suffix.lower() in _EXT_DOC:
                return p
    return None


def _entendimiento_del_modelo(ctx: dict, datasets_dir: Path) -> str:
    """
    Resumen textual del modelo para el modo SIN documento: metadatos +
    columnas reales de los datasets, para que el agente proponga controles
    trazables a columnas que existen de verdad.
    """
    m = ctx["modelo"]
    lineas = [
        f"Modelo: {m.get('nombre', '')}",
        f"Dominio: {m.get('dominio', '')}",
        f"Tier: {m.get('tier', '')}",
        "",
        "Datasets disponibles y sus columnas (úsalos para proponer controles):",
    ]
    try:
        from modulos.motores_datos import cargar_datasets
        ds = cargar_datasets(datasets_dir) if datasets_dir.is_dir() else {}
        if not ds:
            lineas.append("  (aún no se han subido datasets a calidad_datos/datasets/)")
        for nombre, df in ds.items():
            lineas.append(f"  - {nombre}: columnas = {list(df.columns)}; filas = {len(df)}")
    except Exception as exc:                     # noqa: BLE001
        lineas.append(f"  (no se pudieron leer los datasets: {exc})")
    return "\n".join(lineas)


@router.get("/notebook")
def descargar_notebook_controles(ctx: dict = Depends(contexto_sesion)) -> Response:
    """
    Genera y devuelve el .ipynb ENTREGABLE de controles de datos (8 columnas).

    Fuente de los controles:
      1. Si hay un documento en documentacion/controles_datos/ → se extrae de él.
      2. Si no → el agente los PROPONE desde el entendimiento del modelo.

    El notebook lleva las RUTAS al inicio y, al ejecutarse, entrega la tabla:
      Control | Dimensión | Control Esperado | % De cumplimiento del data set |
      Diagnóstico | Decisión | Control o Evidencia requerida | Referencia en el entregable
    """
    datasets_dir = ctx["inputs"] / "calidad_datos" / "datasets"
    ruta_doc = _doc_controles_de_sesion(ctx)
    entendimiento = None if ruta_doc else _entendimiento_del_modelo(ctx, datasets_dir)

    meta = {
        "proyecto_dir": str(PROYECTO_DIR),
        "datasets_dir": str(datasets_dir),
        "salida_dir":   str(ctx["outputs"] / "controles"),
        "titulo":       ctx["modelo"].get("nombre", ""),
        "dominio":      ctx["modelo"].get("dominio", ""),   # activa el catálogo curado
    }
    try:
        from modulos.notebook_controles import generar_ipynb_controles
        ipynb, info = generar_ipynb_controles(ruta_doc, entendimiento, meta)
    except Exception as exc:                     # noqa: BLE001
        raise HTTPException(500, f"no se pudo generar el notebook de controles: {exc}")

    slug = ctx["modelo"]["slug"]
    nombre = f"controles_datos_{slug}.ipynb"
    # Las cabeceras HTTP deben ser latin-1: quita acentos/no-ASCII del texto libre.
    fuente_hdr = (info.get("fuente") or "").encode("ascii", "ignore").decode()[:200]
    return Response(
        content=ipynb,
        media_type="application/x-ipynb+json",
        headers={
            "Content-Disposition": f'attachment; filename="{nombre}"',
            "X-Controles-Fuente":  fuente_hdr,
            "X-Controles-N":       str(info.get("n_controles", 0)),
        },
    )


@router.get("/catalogo")
def catalogo() -> dict[str, Any]:
    """Las pruebas genéricas de `modulos.motores_datos.REGISTRO_MOTORES`."""
    from modulos.motores_datos import REGISTRO_MOTORES
    filas = []
    for nombre in sorted(REGISTRO_MOTORES):
        m = REGISTRO_MOTORES[nombre]
        filas.append({
            "nombre":      nombre,
            "descripcion": m.get("descripcion", ""),
            "requiere":    m.get("requiere", []),
            "opcional":    m.get("opcional", []),
            "ejemplo":     m.get("ejemplo", ""),
        })
    return {"n": len(filas), "motores": filas}


@router.get("/entidad")
def resultados_de_la_entidad(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Lee las tablas de resultados que la entidad deja bajo
    `inputs/calidad_datos/resultadocalidad_de_datos/` DE LA SESIÓN
    activa. Carpeta ausente ⇒ 200 con lista vacía y aviso.

    Mejora 3 · v2.2 — Además de las tablas, se devuelven los reportes
    en TEXTO PLANO (`.txt`, `.md`) para que la UI los muestre y el
    agente los incluya como contexto adicional (los tratará como
    "reporte externo de QC" en el prompt).
    """
    from modulos.motores_entidad import leer_resultados
    try:
        r = leer_resultados(ctx["inputs"])
    except Exception as exc:                     # noqa: BLE001
        raise HTTPException(500, f"lector motores_entidad falló: {exc}")

    # Añade documentos de texto plano encontrados en la misma carpeta.
    from pathlib import Path
    carpeta = Path(r.get("carpeta") or (ctx["inputs"] / "calidad_datos"
                                          / "resultadocalidad_de_datos"))
    docs_texto: list[dict[str, Any]] = []
    if carpeta.is_dir():
        for p in sorted(carpeta.iterdir()):
            if p.is_file() and p.suffix.lower() in (".txt", ".md"):
                try:
                    contenido = p.read_text(encoding="utf-8", errors="replace")
                except OSError as exc:
                    contenido = f"[error leyendo {p.name}: {exc}]"
                docs_texto.append({
                    "nombre":    p.name,
                    "tam":       p.stat().st_size,
                    "contenido": contenido[:20_000],   # tope preventivo
                    "truncado":  len(contenido) > 20_000,
                })
    r["reportes_texto"] = docs_texto
    return r
