"""
Router del paso 02 · Estándares (v2.4).

Endpoints:
  POST  /api/estandares/upload      → sube .xlsx y devuelve vista previa parseada
  POST  /api/estandares/confirmar   → confirma la vista previa (habilita paso 03)
  GET   /api/estandares/estado      → estado del paso en la sesión activa
  GET   /api/estandares/detalle     → JSON completo si está confirmado
  DELETE /api/estandares            → limpia xlsx + json (volver al drag&drop)
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from ..services import estandares_service
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/estandares", tags=["estandares"])


@router.get("/estado")
def get_estado(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    return estandares_service.estado(ctx)


@router.get("/detalle")
def get_detalle(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    ruta = estandares_service.ruta_json(ctx)
    if not ruta.is_file():
        raise HTTPException(404, "no hay estándares confirmados en esta sesión")
    import json
    try:
        return json.loads(ruta.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise HTTPException(500, f"no se pudo leer el JSON: {exc}")


@router.post("/upload")
async def upload(archivo: UploadFile = File(...),
                  ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    nombre = (archivo.filename or "").lower()
    if not nombre.endswith(".xlsx"):
        raise HTTPException(400, "solo se acepta .xlsx")
    contenido = await archivo.read()
    if not contenido:
        raise HTTPException(400, "el fichero está vacío")
    ruta = estandares_service.guardar_xlsx(ctx, contenido)
    try:
        parseado = estandares_service.parsear(ruta)
    except estandares_service.EstandarInvalido as exc:
        estandares_service.limpiar(ctx)
        raise HTTPException(400, f"Excel inválido: {exc}")
    return {
        "status":   "ok",
        "filename": archivo.filename,
        **parseado,
    }


@router.post("/confirmar")
def confirmar(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Confirma el estándar YA parseado (upload lo dejó en el .xlsx de la sesión).
    Re-parseamos aquí para no confiar en un body enviado por el cliente:
    el fuente de verdad es siempre el .xlsx que quedó en disco.
    """
    ruta = estandares_service.ruta_xlsx(ctx)
    if not ruta.is_file():
        raise HTTPException(400, "no hay estándares subidos; sube el .xlsx primero")
    try:
        parseado = estandares_service.parsear(ruta)
    except estandares_service.EstandarInvalido as exc:
        raise HTTPException(400, f"Excel inválido: {exc}")
    doc = estandares_service.confirmar(
        ctx, parseado, validador=ctx["validador"]["codigo"])
    return {"status": "ok", **doc}


@router.delete("")
def borrar(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    estandares_service.limpiar(ctx)
    return {"status": "ok"}
