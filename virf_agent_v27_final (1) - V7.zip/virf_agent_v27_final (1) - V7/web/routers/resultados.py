"""
Lectura de resultados de validación (v2 · fase 2).

Los JSON viven en `web/data/sesiones/{val}/{slug}/outputs/YYYY-MM-DD/`.
El endpoint `/actual` devuelve el JSON de la última corrida de la
sesión activa; `/lista` enumera todos los informes de esa sesión.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from ..services import pipeline_runner
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/resultados", tags=["resultados"])

_FECHA_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _outputs(ctx: dict) -> Path:
    return ctx["outputs"]


def _resolver(ctx: dict, fecha: str, fichero: str) -> Path:
    if not _FECHA_RE.match(fecha):
        raise HTTPException(400, f"fecha inválida: {fecha!r}")
    nombre = Path(fichero).name
    if nombre != fichero or nombre.startswith(".") or not nombre.endswith(".json"):
        raise HTTPException(400, f"nombre inválido: {fichero!r}")
    ruta = (_outputs(ctx) / fecha / nombre).resolve()
    try:
        ruta.relative_to(_outputs(ctx).resolve())
    except ValueError:
        raise HTTPException(400, f"ruta fuera de outputs de la sesión: {fichero!r}")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {fecha}/{fichero}")
    return ruta


def _leer_json(ruta: Path) -> dict:
    try:
        return json.loads(ruta.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise HTTPException(500, f"JSON corrupto en {ruta.name}: {exc}")


@router.get("/lista")
def listar_resultados(ctx: dict = Depends(contexto_sesion)) -> dict:
    """Todos los `resultados_*.json` DE LA SESIÓN activa."""
    outs = _outputs(ctx)
    filas: list[dict] = []
    if outs.is_dir():
        for dia in sorted(outs.iterdir(), reverse=True):
            if not dia.is_dir() or not _FECHA_RE.match(dia.name):
                continue
            for p in sorted(dia.iterdir(), reverse=True):
                if (not p.is_file() or not p.name.startswith("resultados_")
                        or p.suffix != ".json"):
                    continue
                try:
                    d = json.loads(p.read_text(encoding="utf-8"))
                except Exception:  # noqa: BLE001
                    continue
                filas.append({
                    "fecha":        dia.name,
                    "fichero":      p.name,
                    "ruta":         f"{dia.name}/{p.name}",
                    "modelo":       d.get("modelo", "—"),
                    "tier":         d.get("tier", "—"),
                    "score_global": d.get("score_global"),
                    "semaforo":     d.get("semaforo") or {},
                })
    return {"informes": filas, "sesion": ctx["clave"]}


@router.get("/actual")
def resultado_de_la_ultima_corrida(ctx: dict = Depends(contexto_sesion)) -> dict:
    r = pipeline_runner.run_de_sesion(ctx["clave"])
    if r is None or not r.resultado_json:
        raise HTTPException(404, "no hay resultado disponible de una corrida")
    ruta = (ctx["base"] / r.resultado_json).resolve()
    try:
        ruta.relative_to(_outputs(ctx).resolve())
    except ValueError:
        raise HTTPException(400, "resultado fuera de outputs de la sesión")
    return {"ruta": r.resultado_json, "datos": _leer_json(ruta)}


def _resumen_tabla(tabla: list[dict]) -> dict:
    """Conteo por Resultado + cuántas filas van al chat a sustentarse."""
    orden = ["Cumple", "Parcial", "No cumple", "No evidenciado", "No aplicable"]
    conteo = {k: 0 for k in orden}
    n_chat = 0
    for f in tabla or []:
        r = f.get("resultado", "")
        conteo[r] = conteo.get(r, 0) + 1
        if f.get("va_al_chat"):
            n_chat += 1
    return {"por_resultado": conteo, "total": len(tabla or []), "van_al_chat": n_chat}


def _payload_tabla(ruta_rel: str, datos: dict) -> dict:
    tabla = datos.get("tabla_validacion") or []
    return {
        "ruta":     ruta_rel,
        "modelo":   datos.get("modelo", "—"),
        "tier":     datos.get("tier", "—"),
        "tabla":    tabla,
        "resumen":  _resumen_tabla(tabla),
    }


@router.get("/tabla")
def tabla_de_la_ultima_corrida(ctx: dict = Depends(contexto_sesion)) -> dict:
    """
    Output intermedio: la tabla de validación por actividad (Ámbito | Control |
    Actividad | Tier | Resultado | Evaluación Sustentada | Fuente revisada |
    Acción requerida) de la última corrida. Las filas con `va_al_chat` son las
    que 'No cumplen' y pasan al chat a sustentarse.
    """
    r = pipeline_runner.run_de_sesion(ctx["clave"])
    if r is None or not r.resultado_json:
        raise HTTPException(404, "no hay resultado disponible de una corrida")
    ruta = (ctx["base"] / r.resultado_json).resolve()
    try:
        ruta.relative_to(_outputs(ctx).resolve())
    except ValueError:
        raise HTTPException(400, "resultado fuera de outputs de la sesión")
    return _payload_tabla(r.resultado_json, _leer_json(ruta))


@router.get("/tabla/{fecha}/{fichero}")
def tabla_por_ruta(fecha: str, fichero: str,
                   ctx: dict = Depends(contexto_sesion)) -> dict:
    ruta = _resolver(ctx, fecha, fichero)
    return _payload_tabla(f"{fecha}/{fichero}", _leer_json(ruta))


@router.get("/excel")
def descargar_excel(ruta: str, tipo: str = "intermedio",
                    ctx: dict = Depends(contexto_sesion)):
    """
    Descarga la tabla de validación en Excel.
      · tipo=intermedio → estado inicial (pre-chat).
      · tipo=final      → aplica las decisiones del chat de sustentación de la
                          sesión activa y añade el PUNTAJE EXACTO final.
    """
    from dataclasses import asdict
    from fastapi import Response
    from modulos.exportador_excel import a_bytes

    partes = ruta.split("/", 1)
    if len(partes) != 2:
        raise HTTPException(400, "ruta debe ser 'YYYY-MM-DD/fichero.json'")
    datos = _leer_json(_resolver(ctx, partes[0], partes[1]))
    tabla = datos.get("tabla_validacion") or []
    meta = {
        "modelo":       datos.get("modelo", "—"),
        "tier":         datos.get("tier", "—"),
        "fecha":        datos.get("fecha", "—"),
        "tipo":         "intermedio",
        "score_global": datos.get("score_global"),
        "semaforo":     (datos.get("semaforo") or {}).get("label"),
    }

    if tipo == "final":
        from modulos.consolidacion import consolidar_decisiones, tabla_final
        from ..services import chat_service
        s = chat_service.sesion_activa(ctx)
        obs = [asdict(o) for o in s.observaciones] if s is not None else []
        meta["tipo"] = "final"
        meta["score_final"] = consolidar_decisiones(datos, obs)["score_final_global"]
        tabla = tabla_final(datos, obs)

    data = a_bytes(tabla, meta)
    slug = re.sub(r"[^A-Za-z0-9]+", "_", str(datos.get("modelo", "modelo"))).strip("_")
    nombre = f"tabla_{meta['tipo']}_{slug}.xlsx"
    return Response(
        content=data,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{nombre}"'},
    )


@router.get("/{fecha}/{fichero}")
def resultado_por_ruta(fecha: str, fichero: str,
                        ctx: dict = Depends(contexto_sesion)) -> dict:
    ruta = _resolver(ctx, fecha, fichero)
    return {"ruta": f"{fecha}/{fichero}", "datos": _leer_json(ruta)}
