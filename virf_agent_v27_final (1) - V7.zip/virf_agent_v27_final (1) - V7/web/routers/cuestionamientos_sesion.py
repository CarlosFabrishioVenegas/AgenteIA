"""
Cuestionamientos POR SESIÓN — endpoints (v2 · fase 6).

Coexisten con `/api/cuestionamientos/*` (capa global v1 que Mx_04 usa
para regex). Aquí se gestionan el toggle y los personalizados NL DE ESTA
SESIÓN.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..services import cuestionamientos_sesion as store
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/cuestionamientos-sesion",
                    tags=["cuestionamientos-sesion"])


class Toggle(BaseModel):
    id:     str
    activo: bool


class NuevoCustom(BaseModel):
    descripcion: str = Field(..., min_length=6, max_length=1000)


@router.get("")
def get_estado(ctx: dict = Depends(contexto_sesion)) -> dict:
    return {**store.get_estado(ctx), "sesion": ctx["clave"]}


@router.post("/toggle")
def toggle(body: Toggle, ctx: dict = Depends(contexto_sesion)) -> dict:
    try:
        return store.toggle_default(ctx, body.id, body.activo)
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@router.post("/custom")
def crear_custom(body: NuevoCustom,
                  ctx: dict = Depends(contexto_sesion)) -> dict:
    try:
        item = store.add_custom(ctx, body.descripcion)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"cuestionamiento": item}


@router.delete("/custom/{cid}")
def borrar_custom(cid: str,
                    ctx: dict = Depends(contexto_sesion)) -> dict:
    ok = store.remove_custom(ctx, cid)
    if not ok:
        raise HTTPException(404, f"custom {cid!r} no existe")
    return {"ok": True}
