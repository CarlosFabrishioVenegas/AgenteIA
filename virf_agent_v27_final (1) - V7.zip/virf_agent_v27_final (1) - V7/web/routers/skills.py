"""
Endpoints de Skills — capacidades del agente por sesión (v2 · fase 5).

Toma el contexto de la sesión de las cookies (mismo patrón que resto de
routers de v2). Sin login → 401. Sin modelo activo → 400.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..services import skills_store
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/skills", tags=["skills"])


class ToggleDefault(BaseModel):
    skill_id: str
    activo:   bool


class NuevoCustom(BaseModel):
    descripcion: str = Field(..., min_length=6, max_length=1000)


@router.get("/defaults")
def listar_defaults() -> dict:
    """Catálogo por defecto SIN estado (para inspección/documentación)."""
    return {"defaults": skills_store.SKILLS_DEFAULT}


@router.get("")
def get_skills(ctx: dict = Depends(contexto_sesion)) -> dict:
    """
    Skills DE LA SESIÓN activa: defaults (con flag `activo` según el
    estado guardado) + custom.
    """
    return {**skills_store.get_skills(ctx), "sesion": ctx["clave"]}


@router.post("/toggle")
def toggle(body: ToggleDefault, ctx: dict = Depends(contexto_sesion)) -> dict:
    try:
        return skills_store.toggle_default(ctx, body.skill_id, body.activo)
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@router.post("/custom")
def crear_custom(body: NuevoCustom, ctx: dict = Depends(contexto_sesion)) -> dict:
    try:
        skill = skills_store.add_custom(ctx, body.descripcion)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"skill": skill}


@router.delete("/custom/{skill_id}")
def borrar_custom(skill_id: str,
                    ctx: dict = Depends(contexto_sesion)) -> dict:
    ok = skills_store.remove_custom(ctx, skill_id)
    if not ok:
        raise HTTPException(404, f"custom {skill_id!r} no existe")
    return {"ok": True}
