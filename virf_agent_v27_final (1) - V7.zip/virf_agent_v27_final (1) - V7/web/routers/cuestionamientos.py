"""
Cuestionamientos metodológicos — paso 9/10.

Dos fuentes:

- **Por defecto (Mx_00.CUESTIONAMIENTOS_METODOLOGICOS).** Los 15+
  patrones que el agente usa hoy. La UI los expone en modo lectura y
  con un flag `activo` cuyo estado persiste en
  `config/cuestionamientos_activos.json` (opcional; si el fichero no
  existe, todos activos).

- **Personalizados.** Los que el operador añada. Persisten en
  `config/cuestionamientos_personalizados.json`, uno por entrada.
  Se validan al añadir: id único y estructura completa.

Nota importante. Añadir un cuestionamiento aquí NO lo cablea aún al
pipeline; ese cableado exige un cambio en `Mx_04` para leer el JSON
personalizado, y sale del alcance del paso 9. Este paso da la UI y la
persistencia; la conexión al motor entra si el usuario la pide después.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field, field_validator

from ..config_web import PROYECTO_DIR

router = APIRouter(prefix="/api/cuestionamientos", tags=["cuestionamientos"])

CONFIG_DIR = PROYECTO_DIR / "config"
PERS_PATH  = CONFIG_DIR / "cuestionamientos_personalizados.json"
ACT_PATH   = CONFIG_DIR / "cuestionamientos_activos.json"

_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,60}$")


def _leer_json_seguro(p: Path, default: Any) -> Any:
    if not p.is_file():
        return default
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return default


def _cuestionamientos_default() -> dict[str, dict[str, Any]]:
    from Mx_00_CargaRutas import CUESTIONAMIENTOS_METODOLOGICOS
    return dict(CUESTIONAMIENTOS_METODOLOGICOS)


# ── Modelos ───────────────────────────────────────────────────────────

class Cuestionamiento(BaseModel):
    """Estructura pública. `tipo` mapea al concepto del prompt del usuario."""
    id:         str = Field(..., min_length=3, max_length=60)
    tipo:       str = Field(..., description="'presencia' o 'ausencia'")
    patron:     str = Field(..., min_length=1, description="Regex o lista separada por | de subcadenas")
    mensaje:    str = Field(..., min_length=3)
    severidad:  str = Field(..., description="ALTA | MEDIA | BAJA")

    @field_validator("id")
    @classmethod
    def _id_valido(cls, v: str) -> str:
        if not _ID_RE.match(v):
            raise ValueError("id: minúsculas, dígitos y '_', empezando por letra (3–60)")
        return v

    @field_validator("tipo")
    @classmethod
    def _tipo_valido(cls, v: str) -> str:
        v = v.lower().strip()
        if v not in ("presencia", "ausencia"):
            raise ValueError("tipo: 'presencia' o 'ausencia'")
        return v

    @field_validator("severidad")
    @classmethod
    def _sev_valida(cls, v: str) -> str:
        v = v.upper().strip()
        if v not in ("ALTA", "MEDIA", "BAJA"):
            raise ValueError("severidad: ALTA | MEDIA | BAJA")
        return v

    @field_validator("patron")
    @classmethod
    def _patron_compilable(cls, v: str) -> str:
        try:
            re.compile(v)
        except re.error as exc:
            raise ValueError(f"patrón regex no compila: {exc}")
        return v


class ToggleActivo(BaseModel):
    activo: bool


# ── Endpoints ─────────────────────────────────────────────────────────

@router.get("/default")
def listar_default() -> dict[str, Any]:
    """Los cuestionamientos del catálogo + su flag `activo` (default True)."""
    activos = _leer_json_seguro(ACT_PATH, {})
    base = _cuestionamientos_default()
    filas = []
    for cid, m in sorted(base.items()):
        filas.append({
            "id":                 cid,
            "tipo":               "ausencia" if m.get("detectar_ausencia") else "presencia",
            "patrones":           m.get("detectar", []),
            "contexto":           m.get("contexto", ""),
            "critica":            m.get("critica", ""),
            "activo":             bool(activos.get(cid, True)),
        })
    return {"n": len(filas), "cuestionamientos": filas}


@router.post("/default/{cid}/toggle")
def toggle_default(cid: str, body: ToggleActivo) -> dict[str, Any]:
    base = _cuestionamientos_default()
    if cid not in base:
        raise HTTPException(404, f"cuestionamiento default desconocido: {cid}")
    activos = _leer_json_seguro(ACT_PATH, {})
    activos[cid] = bool(body.activo)
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    ACT_PATH.write_text(json.dumps(activos, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "activos": activos}


@router.get("/personalizados")
def listar_personalizados() -> dict[str, Any]:
    lst = _leer_json_seguro(PERS_PATH, [])
    if not isinstance(lst, list):
        lst = []
    return {"n": len(lst), "cuestionamientos": lst}


@router.post("/personalizados")
def agregar_personalizado(body: Cuestionamiento) -> dict[str, Any]:
    lst = _leer_json_seguro(PERS_PATH, [])
    if not isinstance(lst, list):
        lst = []
    if any(x.get("id") == body.id for x in lst):
        raise HTTPException(409, f"ya existe un cuestionamiento con id={body.id!r}")
    # También rechazar si colisiona con un default.
    if body.id in _cuestionamientos_default():
        raise HTTPException(409, f"id={body.id!r} choca con uno del catálogo por defecto")
    lst.append(body.model_dump())
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    PERS_PATH.write_text(json.dumps(lst, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "n": len(lst)}


@router.delete("/personalizados/{cid}")
def borrar_personalizado(cid: str) -> dict[str, Any]:
    lst = _leer_json_seguro(PERS_PATH, [])
    if not isinstance(lst, list):
        lst = []
    nuevo = [x for x in lst if x.get("id") != cid]
    if len(nuevo) == len(lst):
        raise HTTPException(404, f"no existe personalizado con id={cid}")
    PERS_PATH.write_text(json.dumps(nuevo, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "n": len(nuevo)}
