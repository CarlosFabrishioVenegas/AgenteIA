"""
Endpoints del mapa de entendimiento del modelo (Mejora 4 · v2.2).
"""
from __future__ import annotations

from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from ..services import analisis_codigo as acod
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/entendimiento", tags=["entendimiento"])


class Feedback(BaseModel):
    comentario: str = Field(..., min_length=3, max_length=2000)
    seccion:    Optional[str] = None


@router.post("/analizar")
def analizar(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Analiza el ZIP descomprimido y genera `entendimiento_modelo_{slug}.md`.
    Reutiliza feedbacks previos (si los hay) para enriquecer el prompt.
    """
    feedbacks = acod.leer_feedbacks(ctx)
    md = acod.generar_entendimiento(ctx, feedbacks=feedbacks)
    p = acod.guardar_md(ctx, md)
    est = acod.estructura(ctx["inputs"] / "implementacion")
    return {
        "ok":          True,
        "archivo":     p.name,
        "estructura":  est["totales"],
        "entendimiento_md": md,
        "feedbacks":   feedbacks,
    }


@router.get("")
def obtener(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    md = acod.leer_md(ctx)
    if md is None:
        raise HTTPException(404, "aún no se ha analizado el código; "
                                 "usa POST /api/entendimiento/analizar")
    est = acod.estructura(ctx["inputs"] / "implementacion")
    return {
        "entendimiento_md": md,
        "feedbacks":  acod.leer_feedbacks(ctx),
        "estructura": est["totales"],
    }


@router.post("/feedback")
def feedback(body: Feedback,
              ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    try:
        entrada = acod.agregar_feedback(ctx, body.comentario, body.seccion)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"ok": True, "entrada": entrada,
            "feedbacks": acod.leer_feedbacks(ctx)}
