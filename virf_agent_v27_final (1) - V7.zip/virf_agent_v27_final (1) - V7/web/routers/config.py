"""
Configuración del proveedor IA (v2 · fase 2).

El proveedor y sus credenciales viven en el `.env` GLOBAL del proyecto:
son compartidos entre todos los validadores y todas las sesiones. Aquí
no se guarda nada por sesión.

En v1 este router también gestionaba «modelo actual» y «tier». En v2
eso vive en `modelos_store` (la ficha del modelo), y este router se
limita a lo del proveedor.
"""
from __future__ import annotations

import os
from typing import Literal

from fastapi import APIRouter, Cookie, HTTPException
from pydantic import BaseModel, Field, field_validator

from ..services import env_service, modelos_store, sesion_store

router = APIRouter(prefix="/api/config", tags=["config"])

COOKIE_MODELO = "virf_modelo"

PROVEEDORES: dict[str, dict[str, list[str]]] = {
    "azure_openai": {
        "obligatorias": [
            "AZURE_OPENAI_API_KEY",
            "AZURE_OPENAI_ENDPOINT",
            "AZURE_OPENAI_DEPLOYMENT",
            "AZURE_OPENAI_API_VERSION",
        ],
        "opcionales": ["AZURE_OPENAI_MAX_TOKENS"],
    },
    "openai": {
        "obligatorias": ["OPENAI_API_KEY"],
        "opcionales": ["OPENAI_MODELO", "OPENAI_MAX_TOKENS"],
    },
    "anthropic": {
        "obligatorias": ["ANTHROPIC_API_KEY"],
        "opcionales": ["ANTHROPIC_MODELO", "ANTHROPIC_MAX_TOKENS"],
    },
}

CLAVES_SECRETAS = {"AZURE_OPENAI_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY"}

# VIRF PLUS: variables que gobierna su propio panel (no el toggle de proveedor).
# GPT es el agente principal; VIRF PLUS añade a Claude como segunda opinión.
VARS_VIRF_PLUS = ("VIRF_PLUS", "VIRF_PLUS_GPT", "VIRF_PLUS_ARBITRO",
                  "VIRF_PLUS_ARBITRAJE", "ANTHROPIC_API_KEY", "ANTHROPIC_MODELO")
PROVEEDORES_GPT = ("azure_openai", "openai")


class ConfigModelo(BaseModel):
    titulo: str = Field(..., min_length=1, max_length=100)
    tier:   str


class ConfigVirfPlus(BaseModel):
    activo:         bool
    arbitro:        Literal["gpt", "anthropic"] = "gpt"
    arbitraje:      Literal["siempre", "discrepancia"] = "siempre"
    claude_api_key: str = Field("", max_length=400)
    claude_modelo:  str = Field("", max_length=100)


class ConfigProveedor(BaseModel):
    proveedor:    Literal["azure_openai", "openai", "anthropic"]
    credenciales: dict[str, str]

    @field_validator("credenciales")
    @classmethod
    def _sin_claves_raras(cls, v: dict[str, str]) -> dict[str, str]:
        for clave in v:
            if not clave.replace("_", "").isalnum():
                raise ValueError(f"nombre de variable inválido: {clave!r}")
        return v


def _snapshot_env() -> dict:
    env = env_service.leer_env()
    ficha = {"proveedor_activo": env.get("IA_PROVEEDOR", "azure_openai")}
    for prov, catalogo in PROVEEDORES.items():
        ficha[prov] = {}
        for clave in catalogo["obligatorias"] + catalogo["opcionales"]:
            if clave in CLAVES_SECRETAS:
                ficha[prov][clave] = {"seteada": bool(env.get(clave))}
            else:
                ficha[prov][clave] = {
                    "seteada": bool(env.get(clave)),
                    "valor":   env.get(clave, ""),
                }
    ficha["virf_plus"] = _estado_virf_plus(env)
    return ficha


def _estado_virf_plus(env: dict) -> dict:
    """Estado del panel VIRF PLUS, sin secretos."""
    def _v(clave, defecto=""):
        return env.get(clave, os.environ.get(clave, defecto))
    activo = str(_v("VIRF_PLUS", "0")).strip().lower() in (
        "1", "true", "si", "sí", "yes", "on")
    gpt = _gpt_principal(env)
    clave_gpt_ok = (bool(_v("OPENAI_API_KEY")) if gpt == "openai"
                    else bool(_v("AZURE_OPENAI_API_KEY")))
    return {
        "activo":         activo,
        "gpt":            gpt,
        "arbitro":        _v("VIRF_PLUS_ARBITRO", "gpt") or "gpt",
        "arbitraje":      _v("VIRF_PLUS_ARBITRAJE", "siempre") or "siempre",
        "claude_modelo":  _v("ANTHROPIC_MODELO", ""),
        "claude_api_key": {"seteada": bool(_v("ANTHROPIC_API_KEY"))},
        "gpt_listo":      clave_gpt_ok,
        "listo":          bool(_v("ANTHROPIC_API_KEY")) and clave_gpt_ok,
    }


def _gpt_principal(env: dict) -> str:
    """El GPT de VIRF PLUS es el del agente principal; Azure si el principal no es GPT."""
    prov = env.get("IA_PROVEEDOR", os.environ.get("IA_PROVEEDOR", "azure_openai"))
    return prov if prov in PROVEEDORES_GPT else "azure_openai"


def _validador_o_401(token: str | None) -> dict:
    val = sesion_store.sesion_activa(token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    return val


@router.get("")
def get_config(virf_token: str | None = Cookie(default=None)) -> dict:
    """Estado del .env + validador logueado (sin secretos)."""
    val = _validador_o_401(virf_token)
    return {
        "validador":   val,
        "env":         _snapshot_env(),
        "proveedores": PROVEEDORES,
    }


@router.post("/modelo")
def set_modelo(body: ConfigModelo,
               virf_token: str | None = Cookie(default=None),
               virf_modelo: str | None = Cookie(default=None)) -> dict:
    """
    Guarda título (etiqueta visible) y tier del MODELO ACTIVO. El modelo
    activo se identifica por la cookie `virf_modelo` (su slug). No renombra
    la carpeta: el slug es la identidad. Sin modelo activo devuelve 409 en
    vez del 404 opaco que veía la UI.
    """
    val = _validador_o_401(virf_token)
    if not virf_modelo:
        raise HTTPException(
            409, "no hay un modelo activo; entra a un modelo antes de guardar")
    try:
        m = modelos_store.actualizar_meta(
            val["codigo"], virf_modelo, nombre=body.titulo, tier=body.tier)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    if m is None:
        raise HTTPException(404, "el modelo activo ya no existe en disco")
    return {"modelo": m}


@router.post("/proveedor")
def set_proveedor(body: ConfigProveedor,
                   virf_token: str | None = Cookie(default=None)) -> dict:
    _validador_o_401(virf_token)
    catalogo = PROVEEDORES[body.proveedor]
    admitidas = set(catalogo["obligatorias"] + catalogo["opcionales"])
    intrusas = [k for k in body.credenciales if k not in admitidas]
    if intrusas:
        raise HTTPException(
            400,
            f"variables no válidas para '{body.proveedor}': {intrusas}. "
            f"Admitidas: {sorted(admitidas)}",
        )
    cambios: dict[str, str] = {"IA_PROVEEDOR": body.proveedor}
    for clave, valor in body.credenciales.items():
        if valor and valor.strip():
            cambios[clave] = valor.strip()
    env_service.actualizar_env(cambios)
    return {"ok": True, "env": _snapshot_env()}


@router.post("/virf_plus")
def set_virf_plus(body: ConfigVirfPlus,
                  virf_token: str | None = Cookie(default=None)) -> dict:
    """
    Botón VIRF PLUS: suma (o quita) a Claude como segunda opinión del agente
    principal, que es GPT.

    Se persiste en `.env` (para las corridas del pipeline, que son
    subprocesos) y se aplica también al entorno de ESTE proceso y a la caché
    del cliente IA, para que el chat use el modo nuevo sin reiniciar.
    """
    _validador_o_401(virf_token)
    gpt = _gpt_principal(env_service.leer_env())
    cambios: dict[str, str] = {
        "VIRF_PLUS":           "1" if body.activo else "0",
        "VIRF_PLUS_GPT":       gpt,
        "VIRF_PLUS_ARBITRO":   body.arbitro,
        "VIRF_PLUS_ARBITRAJE": body.arbitraje,
    }
    if body.claude_api_key.strip():
        cambios["ANTHROPIC_API_KEY"] = body.claude_api_key.strip()
    if body.claude_modelo.strip():
        cambios["ANTHROPIC_MODELO"] = body.claude_modelo.strip()
    env_service.actualizar_env(cambios)
    os.environ.update(cambios)

    # Los parámetros de VIRF PLUS se leyeron al importar; se refrescan para que
    # el cambio de GPT/árbitro también valga sin reiniciar.
    from config import parametros as _par
    _par.VIRF_PLUS_GPT = gpt
    _par.VIRF_PLUS_ARBITRO = body.arbitro
    _par.VIRF_PLUS_ARBITRAJE = body.arbitraje
    if body.claude_modelo.strip():
        _par.ANTHROPIC_MODELO = body.claude_modelo.strip()
    try:
        from config import virf_plus as _vp, ia as _ia
        _vp.VIRF_PLUS_GPT, _vp.VIRF_PLUS_ARBITRO, _vp.VIRF_PLUS_ARBITRAJE = (
            gpt, body.arbitro, body.arbitraje)
        if body.claude_modelo.strip():
            _ia.ANTHROPIC_MODELO = body.claude_modelo.strip()
        _ia.reset_cliente_ia()
    except Exception:
        pass

    estado = _estado_virf_plus(env_service.leer_env())
    aviso = None
    if body.activo and not estado["listo"]:
        falta = []
        if not estado["gpt_listo"]:
            falta.append("las credenciales del agente principal GPT (sección Proveedor IA)")
        if not estado["claude_api_key"]["seteada"]:
            falta.append("la API key de Claude")
        aviso = "VIRF PLUS está encendido pero falta " + " y ".join(falta) + "."
    return {"ok": True, "virf_plus": estado, "aviso": aviso}


@router.post("/verificar")
def verificar_conexion(virf_token: str | None = Cookie(default=None)) -> dict:
    _validador_o_401(virf_token)
    from config.ia import prueba_de_humo, metadatos_proveedor
    meta = metadatos_proveedor()
    resultado = prueba_de_humo()
    resultado["proveedor_meta"] = {
        "nombre":       meta.get("nombre"),
        "vars_revisar": meta.get("vars_revisar", []),
        "consola":      meta.get("consola"),
    }
    # Persistimos el modelo detectado en la sesión de login para que
    # /api/prompts/presupuesto y pipeline_runner calculen el presupuesto
    # de contexto real (perfil del catálogo) y no el conservador.
    modelo_ia = (resultado.get("modelo")
                 or resultado.get("modelo_real")
                 or resultado.get("deployment"))
    if modelo_ia:
        sesion_store.set_atributo_sesion(
            virf_token, "modelo_ia_detectado", str(modelo_ia))
        from ..services import presupuesto_service
        resultado["presupuesto_contexto"] = presupuesto_service.calcular(str(modelo_ia))
    return resultado
