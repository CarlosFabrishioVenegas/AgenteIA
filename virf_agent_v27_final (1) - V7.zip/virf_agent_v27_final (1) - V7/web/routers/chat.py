"""
Chat argumentativo por sesión (v2 · fase 7).

Cada modelo lleva su propio chat, persistido a disco. Dos validadores
en dos modelos distintos chatean en paralelo sin colisión.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from fastapi import (APIRouter, Depends, File, HTTPException, Response,
                     UploadFile, WebSocket, WebSocketDisconnect)
from pydantic import BaseModel, Field

from ..services import chat_service, sesion_store, modelos_store
from ..services.contexto_sesion import contexto_sesion, SESIONES_DIR

router = APIRouter(tags=["chat"])


class IniciarChat(BaseModel):
    ruta: str = Field(..., description="'YYYY-MM-DD/fichero.json' relativo a outputs de la sesión")


@router.post("/api/chat/iniciar")
def iniciar_chat(body: IniciarChat,
                  ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    partes = body.ruta.split("/")
    if len(partes) != 2:
        raise HTTPException(400, "ruta debe ser 'YYYY-MM-DD/fichero.json'")
    fecha, fichero = partes
    ruta = (ctx["outputs"] / fecha / Path(fichero).name).resolve()
    try:
        ruta.relative_to(ctx["outputs"].resolve())
    except ValueError:
        raise HTTPException(400, "ruta fuera de outputs de la sesión")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {body.ruta}")

    datos = json.loads(ruta.read_text(encoding="utf-8"))
    s = chat_service.iniciar(ctx, datos, body.ruta)
    modelos_store.actualizar_actividad(
        ctx["validador"]["codigo"], ctx["modelo"]["slug"], estado="en_progreso")
    return chat_service.a_dict(s)


@router.get("/api/chat/estado")
def estado_chat(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    s = chat_service.sesion_activa(ctx)
    return {"activa": s is not None, "sesion": chat_service.a_dict(s)}


@router.get("/api/chat/observaciones")
def observaciones(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """Resumen enfocado para dashboards, sin arrastrar todos los mensajes."""
    s = chat_service.sesion_activa(ctx)
    if s is None:
        raise HTTPException(404, "no hay sesión de chat activa")
    return {
        "resumen": s.resumen(),
        "detalle": [
            {
                "numero":    i + 1,
                "ambito":    o.ambito,
                "actividad": o.actividad,
                "puntaje":   o.puntaje,
                "veredicto": o.veredicto,
                "hallazgo":  o.hallazgo_final,
                "intentos":  o.intentos,
            } for i, o in enumerate(s.observaciones)
        ],
    }


@router.post("/api/chat/adjuntar")
async def adjuntar_chat(archivo: UploadFile = File(...),
                        ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    El validador sube un archivo con evidencia nueva para la observación en curso.
    Se extrae su texto y el agente RE-EVALÚA el ítem con esa prueba (llamada real
    al modelo). Devuelve la sesión de chat actualizada.
    """
    nombre = Path(archivo.filename or "adjunto").name
    if not nombre or "\x00" in nombre:
        raise HTTPException(400, "nombre de archivo inválido")
    contenido = await archivo.read()
    if not contenido:
        raise HTTPException(400, "archivo vacío")
    if len(contenido) > 20 * 1024 * 1024:
        raise HTTPException(400, "archivo demasiado grande (máx 20 MB)")

    import tempfile
    with tempfile.NamedTemporaryFile(suffix=Path(nombre).suffix, delete=False) as tf:
        tf.write(contenido)
        tmp = Path(tf.name)
    try:
        from Mx_01_LecturaEvidencias import leer_archivo   # motor/ está en sys.path
        datos = leer_archivo(tmp)
    finally:
        try:
            tmp.unlink()
        except OSError:
            pass

    if not datos or not (datos.get("contenido") or "").strip():
        raise HTTPException(
            400, "no se pudo extraer texto del archivo (¿escaneado o formato no "
                 "soportado?). Formatos con texto: pdf, docx, pptx, xlsx, csv, "
                 "md, txt, py, ipynb, json.")

    # Bloqueante (llama al modelo): fuera del event loop.
    r = await asyncio.to_thread(
        chat_service.adjuntar_evidencia, ctx, nombre, datos["contenido"])
    s = chat_service.sesion_activa(ctx)
    return {"resultado": r, "sesion": chat_service.a_dict(s)}


@router.post("/api/chat/consolidar")
def consolidar_chat(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Cierre HITL: recomputa el PUNTAJE EXACTO final con las decisiones del chat y
    GUARDA cada corrección como feedback (contexto + ajuste automático en futuras
    corridas). Idempotente por sesión de chat.
    """
    from dataclasses import asdict

    s = chat_service.sesion_activa(ctx)
    if s is None:
        raise HTTPException(404, "no hay sesión de chat activa")

    partes = s.ruta_json.split("/")
    ruta = (ctx["outputs"] / partes[0] / Path(partes[-1]).name).resolve()
    try:
        ruta.relative_to(ctx["outputs"].resolve())
    except ValueError:
        raise HTTPException(400, "ruta de resultados fuera de la sesión")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe el JSON de resultados: {s.ruta_json}")

    datos = json.loads(ruta.read_text(encoding="utf-8"))
    obs = [asdict(o) for o in s.observaciones]

    from modulos.consolidacion import consolidar_decisiones
    from modulos.feedback import registrar_aprendizaje_desde_chat

    con = consolidar_decisiones(datos, obs)
    val = ctx.get("validador") or {}
    ident = {"validador": val.get("nombre") or val.get("codigo"), "cargo": val.get("cargo")}
    aprend = registrar_aprendizaje_desde_chat(datos, obs, ident, sesion_id=s.id)

    return {
        "score_inicial": datos.get("score_global"),
        "score_final":   con["score_final_global"],
        "resumen_final": con["resumen_final"],
        "aprendizaje":   aprend,
    }


@router.get("/api/chat/acta.xlsx")
def descargar_acta_cierre(ctx: dict = Depends(contexto_sesion)) -> Response:
    """
    Acta de cierre en Excel (3 hojas: Resumen · Validación · Decisiones) con el
    PUNTAJE EXACTO final tras las decisiones del chat. Es el entregable de cierre.
    """
    from dataclasses import asdict

    s = chat_service.sesion_activa(ctx)
    if s is None:
        raise HTTPException(404, "no hay sesión de chat activa")

    partes = s.ruta_json.split("/")
    ruta = (ctx["outputs"] / partes[0] / Path(partes[-1]).name).resolve()
    try:
        ruta.relative_to(ctx["outputs"].resolve())
    except ValueError:
        raise HTTPException(400, "ruta de resultados fuera de la sesión")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe el JSON de resultados: {s.ruta_json}")

    datos = json.loads(ruta.read_text(encoding="utf-8"))
    obs = [asdict(o) for o in s.observaciones]

    m = ctx.get("modelo") or {}
    v = ctx.get("validador") or {}
    meta = {
        "modelo":    m.get("nombre") or m.get("slug") or "—",
        "tier":      m.get("tier") or datos.get("tier") or "—",
        "dominio":   m.get("dominio") or "—",
        "fecha":     datos.get("fecha") or "",
        "validador": v.get("nombre") or v.get("codigo") or "—",
        "cargo":     v.get("cargo") or "",
        "semaforo":  datos.get("semaforo"),
    }
    from modulos.exportador_excel import acta_cierre_bytes
    xlsx = acta_cierre_bytes(datos, obs, meta)
    slug = m.get("slug") or "modelo"
    return Response(
        content=xlsx,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="acta_cierre_{slug}.xlsx"'},
    )


def _reconstruye_ctx(codigo: str, slug: str) -> dict | None:
    """
    Rehidrata un ctx a partir de la clave `codigo/slug` sin las cookies —
    lo necesita el WebSocket, que no tiene la dependencia Depends()
    disponible del mismo modo que los endpoints REST.
    """
    val = None
    reg = sesion_store.leer_validadores()
    if codigo in reg:
        val = reg[codigo]
    modelo = modelos_store.cargar(codigo, slug)
    if val is None or modelo is None:
        return None
    base = SESIONES_DIR / codigo / slug
    return {
        "validador": val, "modelo": modelo,
        "base":      base,
        "inputs":    base / "inputs",
        "outputs":   base / "outputs",
        "clave":     f"{codigo}/{slug}",
    }


@router.websocket("/ws/chat")
async def ws_chat(ws: WebSocket) -> None:
    """
    Requiere cookies `virf_token` (login) y `virf_modelo` (modelo activo).
    Sirve el chat del modelo activo. Persiste cada respuesta en disco.
    """
    await ws.accept()
    token  = ws.cookies.get("virf_token")
    modelo = ws.cookies.get("virf_modelo")
    val = sesion_store.sesion_activa(token)
    if val is None or not modelo:
        await ws.send_json({"tipo": "error",
                            "detalle": "sesión de login/modelo no válida"})
        await ws.close()
        return
    ctx = _reconstruye_ctx(val["codigo"], modelo)
    if ctx is None:
        await ws.send_json({"tipo": "error", "detalle": "modelo activo no existe"})
        await ws.close()
        return

    try:
        s = chat_service.sesion_activa(ctx)
        if s is None:
            await ws.send_json({"tipo": "error",
                                "detalle": "sin sesión de chat; lanza /api/chat/iniciar primero"})
            await ws.close()
            return
        await ws.send_json({"tipo": "estado", "sesion": chat_service.a_dict(s)})

        while True:
            bruto = await ws.receive_text()
            try:
                msg = json.loads(bruto)
            except json.JSONDecodeError:
                await ws.send_json({"tipo": "error", "detalle": "JSON inválido"})
                continue
            if msg.get("tipo") == "responder":
                texto = (msg.get("texto") or "").strip()
                if not texto:
                    await ws.send_json({"tipo": "error", "detalle": "respuesta vacía"})
                    continue
                # Bloqueante potencialmente lento (llamada al modelo real).
                await asyncio.to_thread(chat_service.responder, ctx, texto)
                s = chat_service.sesion_activa(ctx)
                await ws.send_json({"tipo": "estado", "sesion": chat_service.a_dict(s)})
            else:
                await ws.send_json({"tipo": "error",
                                    "detalle": f"tipo no soportado: {msg.get('tipo')}"})
    except WebSocketDisconnect:
        return
