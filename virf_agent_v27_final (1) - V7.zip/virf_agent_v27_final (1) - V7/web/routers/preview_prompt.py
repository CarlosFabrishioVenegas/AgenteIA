"""
Visor del prompt del agente, protegido con contraseña (Mejora 2 · v2.2).

Devuelve el prompt EXACTO que se enviaría al LLM SIN ejecutar la
llamada. Se usa el truco de interceptar `_llamar_modelo` con un
capturador local y descartar la respuesta — así se reutiliza la
lógica de armado de prompt de `motor_ia.evaluar_actividad` tal cual,
sin duplicarla.

Contraseña: `virf2026` en cabecera `X-Prompt-Password`. No es
seguridad seria — es un cerrojo para el operador junior; el visor
maneja el prompt exacto y no es contenido de consumo habitual.
"""
from __future__ import annotations

from typing import Any
from unittest.mock import patch

from fastapi import APIRouter, Depends, Header, HTTPException

from ..services import (
    analisis_codigo, chat_service, cuestionamientos_sesion,
    skills_store,
)
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/validacion", tags=["preview-prompt"])

CONTRASENA = "virf2026"


def _muestra_rag(dominio: str, consulta: str) -> list[dict]:
    """Top 3 chunks del retriever del dominio para dar visibilidad al RAG."""
    try:
        from src.rag import get_retriever
        retriever = get_retriever(tipo_modelo=dominio)
        chunks = retriever.query(consulta, top_k=3) or []
        return [
            {
                "texto":  (c.get("texto") or c.get("text") or "")[:400],
                "score":  c.get("score"),
                "fuente": c.get("fuente") or c.get("source"),
            }
            for c in chunks
        ]
    except Exception as exc:                        # noqa: BLE001
        return [{"texto": f"[error RAG: {exc}]", "score": None, "fuente": None}]


def _leer_parametros() -> dict:
    """Snapshot de parámetros que la UI del visor muestra al final."""
    import os
    return {
        "VIRF_MAX_CTX":     os.environ.get("VIRF_MAX_CTX",     "15000"),
        "VIRF_CHUNK_SIZE":  os.environ.get("VIRF_CHUNK_SIZE",  "12000"),
        "VIRF_MAX_CHUNKS":  os.environ.get("VIRF_MAX_CHUNKS",  "40"),
        "IA_TEMPERATURE":   os.environ.get("VIRF_IA_TEMPERATURE", "0"),
        "IA_PROVEEDOR":     os.environ.get("IA_PROVEEDOR", "azure_openai"),
    }


@router.post("/preview-prompt")
def preview_prompt(ctx: dict = Depends(contexto_sesion),
                    x_prompt_password: str = Header(default="")) -> dict[str, Any]:
    if x_prompt_password != CONTRASENA:
        raise HTTPException(403, "contraseña incorrecta")

    dominio = ctx["modelo"].get("dominio", "shared")

    # 1) Instrucciones extra (skills + cuestionamientos NL) que el motor inyectaría.
    skills_txt   = skills_store.get_active_skills_for_prompt(ctx)
    cuest_txt    = cuestionamientos_sesion.get_for_prompt(ctx)
    inyectables  = skills_txt + cuest_txt

    # 2) Entendimiento del modelo.
    entend = analisis_codigo.leer_md(ctx)

    # 3) Muestra RAG del dominio.
    rag = _muestra_rag(dominio, f"metodología y supuestos del modelo {ctx['modelo']['nombre']}")

    # 4) Armar el prompt real usando motor_ia con `_llamar_modelo` interceptado.
    from modulos import motor_ia as _mia
    capturado: dict = {}

    def _capturar(prompt, **kw):
        capturado["prompt"]     = prompt
        capturado["max_tokens"] = kw.get("max_tokens")
        # JSON mínimo con campos no vacíos para que el validador de contrato
        # no fuerce reintentos y el prompt se capture en el primer intento.
        return ('{"puntaje": 3, "concepto": "vista previa", '
                '"observacion": "vista previa", "recomendacion": "vista previa", '
                '"preguntas_pendientes": [], "evidencia_encontrada": "vista previa"}')

    try:
        with patch.object(_mia, "_llamar_modelo", side_effect=_capturar):
            _mia.evaluar_actividad(
                actividad="[MUESTRA] Ejemplo de actividad para vista previa",
                ambito="Metodología",
                control="[MUESTRA] Control demostrativo",
                contexto="[MUESTRA] En la vista previa se muestran los bloques del "
                         "prompt tal como se enviarían al LLM, con las skills y "
                         "cuestionamientos activos, el entendimiento del modelo y el "
                         "contexto RAG. La evidencia real se sustituye por este texto "
                         "para no cargar 15k chars en la vista.",
                titulo_modelo=ctx["modelo"]["nombre"],
                modo_preprdc=False,
                dominio_rag=dominio,
                instrucciones_extra=inyectables,
                entendimiento_modelo=entend,
            )
    except Exception as exc:                        # noqa: BLE001
        raise HTTPException(500, f"no se pudo armar el prompt: {exc}")

    prompt_full = capturado.get("prompt", "")

    return {
        "prompt_evaluacion":       prompt_full,
        "skills_inyectados":       skills_txt,
        "cuestionamientos_inyectados": cuest_txt,
        "entendimiento_incluido":  bool(entend),
        "entendimiento_chars":     len(entend or ""),
        "rag_dominio":             dominio,
        "rag_chunks_ejemplo":      rag,
        "max_tokens":              capturado.get("max_tokens"),
        "parametros":              _leer_parametros(),
        "sesion":                  ctx["clave"],
    }
