"""
Guía del procedimiento: en qué paso está el expediente.

- GET /api/guia/progreso → estado de los 9 pasos + el siguiente recomendado

Solo LEE el disco de la sesión (no escribe nada) para que la ayuda de la web
pueda decir «te falta esto» con datos reales y no con una lista fija.
"""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends

from ..services import env_service, estandares_service, informe_web
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/guia", tags=["guia"])

_CLAVE_PROVEEDOR = {
    "anthropic":    "ANTHROPIC_API_KEY",
    "azure_openai": "AZURE_OPENAI_API_KEY",
    "openai":       "OPENAI_API_KEY",
}


def _ficheros(carpeta: Path) -> int:
    if not carpeta.is_dir():
        return 0
    return sum(1 for p in carpeta.rglob("*") if p.is_file() and not p.name.startswith("."))


def _paso(id_: str, estado: str, detalle: str, obligatorio: bool = True) -> dict:
    return {"id": id_, "estado": estado, "detalle": detalle, "obligatorio": obligatorio}


@router.get("/progreso")
def progreso(ctx: dict = Depends(contexto_sesion)) -> dict:
    env = env_service.leer_env()
    prov = env.get("IA_PROVEEDOR", "azure_openai")
    clave_ok = bool(env.get(_CLAVE_PROVEEDOR.get(prov, ""), ""))
    inputs, outputs = ctx["inputs"], ctx["outputs"]
    modelo = ctx["modelo"]

    est = estandares_service.estado(ctx)
    n_docs = _ficheros(inputs / "documentacion")
    n_impl = _ficheros(inputs / "implementacion")
    n_total = _ficheros(inputs)
    resultados = (sorted(outputs.rglob("resultados_*.json")) if outputs.is_dir() else [])
    versiones = informe_web.listar_versiones(ctx) if outputs.is_dir() else []

    pasos = [
        _paso("config", "hecho" if clave_ok else "pendiente",
              f"Proveedor {prov}: " + ("credencial configurada." if clave_ok
                                       else "falta la API key.")),
        _paso("estandares",
              "hecho" if est.get("confirmado") else ("en_curso" if est.get("subido") else "pendiente"),
              "Estándares confirmados." if est.get("confirmado")
              else "Subido, falta aceptarlo." if est.get("subido")
              else "Aún no has subido el Excel de estándares."),
        _paso("evidencia",
              "hecho" if (n_docs and n_impl) else ("en_curso" if n_total else "pendiente"),
              f"{n_docs} documento(s) y {n_impl} archivo(s) de implementación."
              + ("" if n_impl else " Falta el ZIP de implementación.")),
        _paso("dominio", "hecho" if modelo.get("dominio") else "pendiente",
              f"Dominio: {modelo.get('dominio') or 'sin elegir'}."),
        _paso("skills", "opcional", "Análisis transversales adicionales.", obligatorio=False),
        _paso("cuestionamientos", "opcional", "Preguntas metodológicas propias.", obligatorio=False),
        _paso("prevuelo", "recomendado", "Revisa la evidencia antes de gastar en la validación.",
              obligatorio=False),
        _paso("validar", "hecho" if resultados else "pendiente",
              f"{len(resultados)} corrida(s) con resultados." if resultados
              else "Todavía no hay resultados."),
        _paso("documentar", "hecho" if versiones else "pendiente",
              f"{len(versiones)} versión(es) del informe." if versiones
              else "Aún no se ha generado el informe."),
    ]
    siguiente = next((p["id"] for p in pasos if p["obligatorio"] and p["estado"] != "hecho"), None)
    hechos = sum(1 for p in pasos if p["obligatorio"] and p["estado"] == "hecho")
    total = sum(1 for p in pasos if p["obligatorio"])
    return {"pasos": pasos, "siguiente": siguiente, "hechos": hechos, "total": total}
