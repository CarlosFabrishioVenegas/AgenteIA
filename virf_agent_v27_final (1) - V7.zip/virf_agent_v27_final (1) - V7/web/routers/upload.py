"""
Endpoints de subida de evidencia y visualización del árbol de inputs.

v2 · fase 2 — trabajan sobre `web/data/sesiones/{val}/{slug}/inputs/`
(salvo los slugs `rag_*`, que van al RAG global compartido).

Contrato de seguridad (mismo de v1):
- Nunca se acepta una ruta que venga del cliente. Solo un `slug` de
  `contexto_sesion.destinos_disponibles`.
- Basename saneado. Nombres prohibidos rechazados con 403.
- ZIP validado miembro a miembro antes de escribir nada.
"""
from __future__ import annotations

import io
import zipfile
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile

from ..config_web import NOMBRES_PROHIBIDOS
from ..services.contexto_sesion import (
    contexto_sesion,
    destinos_disponibles,
    es_solo_zip,
    inicializar_carpetas_sesion,
    listar_carpeta_sesion,
    resolver_destino,
)

router = APIRouter(prefix="/api/inputs", tags=["inputs"])


# ── Utilidades internas ───────────────────────────────────────────────

# ── Topes contra "ZIP bomb" ───────────────────────────────────────────────────
# Un ZIP de pocos MB con compresión extrema puede expandirse a varios GB y tumbar
# el servidor (memoria o disco). Se limita ANTES de extraer (nº de entradas y
# tamaño total declarado) y DURANTE la extracción (bytes realmente escritos), por
# si las cabeceras del ZIP mienten sobre el tamaño. Holgados a propósito: la
# evidencia legítima (PDFs, código) cabe de sobra.
MAX_MIEMBROS_ZIP = 5_000
MAX_BYTES_DESCOMPRIMIDOS_ZIP = 1024 * 1024 * 1024   # 1 GiB en total
_BLOQUE_COPIA = 1024 * 1024                          # 1 MiB por lectura


def _nombre_seguro(bruto: str) -> str:
    if not bruto or "\x00" in bruto:
        raise HTTPException(400, "nombre de archivo inválido")
    nombre = Path(bruto).name.strip()
    if not nombre or nombre in {".", ".."}:
        raise HTTPException(400, "nombre de archivo inválido")
    if nombre.lower() in NOMBRES_PROHIBIDOS:
        raise HTTPException(
            403,
            f"'{nombre}' no puede subirse por esta vía "
            "(cambio con proceso, no por upload)",
        )
    return nombre


def _clasificar_estado(p: Path) -> str:
    if not p.is_file():
        return "error"
    tam = p.stat().st_size
    if tam == 0:
        return "warn"
    ext = p.suffix.lower()
    conocidas = {
        ".pdf", ".docx", ".doc", ".xlsx", ".xls", ".csv", ".txt", ".md",
        ".ipynb", ".py", ".r", ".sql", ".json", ".yaml", ".yml",
        ".png", ".jpg", ".jpeg", ".svg", ".parquet",
    }
    if ext not in conocidas:
        return "warn"
    return "ok"


def _serializar_dir(base: Path, raiz_vista: Path) -> dict[str, Any]:
    hijos: list[dict[str, Any]] = []
    if base.is_dir():
        for entrada in sorted(base.iterdir(),
                              key=lambda p: (p.is_file(), p.name.lower())):
            if entrada.name.startswith("."):
                continue
            if entrada.is_dir():
                hijos.append(_serializar_dir(entrada, raiz_vista))
            else:
                hijos.append({
                    "tipo":    "archivo",
                    "nombre":  entrada.name,
                    "ruta":    entrada.relative_to(raiz_vista).as_posix(),
                    "tam":     entrada.stat().st_size,
                    "estado":  _clasificar_estado(entrada),
                })
    return {
        "tipo":    "carpeta",
        "nombre":  base.name,
        "ruta":    (base.relative_to(raiz_vista).as_posix()
                    if base != raiz_vista else ""),
        "hijos":   hijos,
    }


# ── Endpoints ─────────────────────────────────────────────────────────

@router.get("/destinos")
def listar_destinos() -> dict[str, Any]:
    """Slugs válidos con etiqueta y alcance (sesion|global)."""
    return {"destinos": destinos_disponibles()}


@router.get("/arbol")
def arbol_inputs(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Árbol de `inputs/` DE LA SESIÓN activa. El RAG global no se muestra
    aquí (tiene su propia UI en Dominio & RAG).
    """
    inicializar_carpetas_sesion(ctx)
    return _serializar_dir(ctx["inputs"], ctx["inputs"])


@router.get("/carpeta/{slug}")
def listar_carpeta(slug: str,
                    ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """Ficheros ya subidos a `slug` — para pintar cada card del upload guiado."""
    return {"slug": slug, "ficheros": listar_carpeta_sesion(slug, ctx)}


@router.delete("/archivo/{slug}/{fichero}")
def borrar_archivo(slug: str, fichero: str,
                    ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Borra un fichero SUBIDO desde este panel. Solo permite eliminar
    archivos directos (no anidados): un ZIP se borra por ejemplo con
    su .zip original si lo hubiera; los archivos extraídos se manejan a
    mano en el disco. Esto evita accidentes en árboles profundos.
    """
    raiz = resolver_destino(slug, ctx)
    nombre = Path(fichero).name
    if nombre != fichero:
        raise HTTPException(400, f"nombre inválido: {fichero!r}")
    ruta = (raiz / nombre).resolve()
    try:
        ruta.relative_to(raiz.resolve())
    except ValueError:
        raise HTTPException(400, "ruta fuera del destino")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {nombre}")
    ruta.unlink()
    return {"ok": True, "borrado": nombre}


@router.post("/upload")
async def subir_archivos(
    destino: str = Query(..., description="Slug de destino"),
    archivos: list[UploadFile] = File(...),
    ctx: dict = Depends(contexto_sesion),
) -> dict[str, Any]:
    if es_solo_zip(destino):
        raise HTTPException(
            400,
            f"'{destino}' solo acepta un .zip; usa /api/inputs/upload-zip",
        )
    raiz = resolver_destino(destino, ctx)
    raiz.mkdir(parents=True, exist_ok=True)

    guardados: list[dict[str, Any]] = []
    for f in archivos:
        nombre = _nombre_seguro(f.filename or "")
        if nombre.lower().endswith(".zip"):
            raise HTTPException(
                400,
                f"'{nombre}' es un ZIP; usa /api/inputs/upload-zip",
            )
        ruta = raiz / nombre
        contenido = await f.read()
        ruta.write_bytes(contenido)
        guardados.append({
            "nombre": nombre,
            "tam":    len(contenido),
            "estado": _clasificar_estado(ruta),
            "ruta":   ruta.relative_to(raiz.parent).as_posix()
                      if raiz.parent != raiz else nombre,
        })
    return {"destino": destino, "guardados": guardados,
            "sesion": ctx["clave"]}


@router.post("/upload-zip")
async def subir_zip(
    archivo: UploadFile = File(...),
    destino: str = Query("implementacion"),
    ctx: dict = Depends(contexto_sesion),
) -> dict[str, Any]:
    """
    Descomprime un ZIP en `destino`. Antes: el flujo especial para el
    slug 'raiz' respetaba subcarpetas; en v2 no se usa (los uploads
    guiados por carpeta van al slug concreto). Con `destino=implementacion`
    o cualquier otro, el ZIP se aplana dentro de esa carpeta.
    """
    raiz_destino = resolver_destino(destino, ctx)
    raiz_destino.mkdir(parents=True, exist_ok=True)

    bruto = await archivo.read()
    if not bruto:
        raise HTTPException(400, "ZIP vacío")

    try:
        zf = zipfile.ZipFile(io.BytesIO(bruto))
    except zipfile.BadZipFile:
        raise HTTPException(400, "archivo no es un ZIP válido")

    # Tope ANTES de extraer: nº de entradas y tamaño total declarado.
    miembros = [m for m in zf.infolist() if not m.is_dir()]
    if len(miembros) > MAX_MIEMBROS_ZIP:
        raise HTTPException(
            413, f"el ZIP tiene {len(miembros)} archivos; máximo {MAX_MIEMBROS_ZIP}")
    declarado = sum(m.file_size for m in miembros)
    if declarado > MAX_BYTES_DESCOMPRIMIDOS_ZIP:
        raise HTTPException(
            413, f"el ZIP descomprimido ocuparía {declarado / 2**20:,.0f} MiB; "
                 f"máximo {MAX_BYTES_DESCOMPRIMIDOS_ZIP / 2**20:,.0f} MiB")

    plan: list[tuple[zipfile.ZipInfo, Path]] = []
    for miembro in miembros:
        nombre_zip = miembro.filename
        if "\x00" in nombre_zip:
            raise HTTPException(400, "el ZIP contiene un nombre con byte nulo")
        partes = Path(nombre_zip).parts
        if any(p in ("", "..") for p in partes) or nombre_zip.startswith(("/", "\\")):
            raise HTTPException(
                400, f"entrada peligrosa en el ZIP: {nombre_zip!r}")
        if Path(nombre_zip).name.lower() in NOMBRES_PROHIBIDOS:
            raise HTTPException(
                403, f"el ZIP contiene un archivo prohibido: {nombre_zip!r}")
        # `implementacion` respeta subestructura del ZIP; otros destinos
        # aplanan (el nombre solo). El caso más importante — código con
        # carpetas — necesita la jerarquía.
        if destino == "implementacion":
            ruta_final = (raiz_destino / nombre_zip).resolve()
        else:
            ruta_final = (raiz_destino / Path(nombre_zip).name).resolve()
        try:
            ruta_final.relative_to(raiz_destino.resolve())
        except ValueError:
            raise HTTPException(
                400, f"entrada escapa del destino: {nombre_zip!r}")
        plan.append((miembro, ruta_final))

    escritos: list[dict[str, Any]] = []
    creados: list[Path] = []
    total_escrito = 0
    for miembro, ruta_final in plan:
        ruta_final.parent.mkdir(parents=True, exist_ok=True)
        creados.append(ruta_final)
        # Copia por bloques con contador: si las cabeceras del ZIP mentían sobre
        # el tamaño, se corta aquí en vez de llenar memoria/disco. Al abortar se
        # borra lo ya extraído de ESTE ZIP para no dejar una carga a medias.
        with zf.open(miembro) as origen, open(ruta_final, "wb") as dst:
            while True:
                bloque = origen.read(_BLOQUE_COPIA)
                if not bloque:
                    break
                total_escrito += len(bloque)
                if total_escrito > MAX_BYTES_DESCOMPRIMIDOS_ZIP:
                    dst.close()
                    for p in creados:
                        p.unlink(missing_ok=True)
                    raise HTTPException(
                        413, "el ZIP supera el tamaño descomprimido máximo "
                             f"({MAX_BYTES_DESCOMPRIMIDOS_ZIP / 2**20:,.0f} MiB)")
                dst.write(bloque)
        escritos.append({
            "origen_zip": miembro.filename,
            "ruta":       ruta_final.relative_to(ctx["inputs"]).as_posix()
                          if ctx["inputs"] in ruta_final.parents else miembro.filename,
            "tam":        miembro.file_size,
            "estado":     _clasificar_estado(ruta_final),
        })

    return {
        "destino": destino,
        "n_miembros": len(escritos),
        "escritos": escritos,
        "sesion":  ctx["clave"],
    }
