"""
Cuadro de observaciones desde los Excels de automatización (00–03).

- GET  /api/automatizaciones/estado            → qué Excels hay y último cuadro
- POST /api/automatizaciones/cuadro            → genera el cuadro (IA o borrador)
- GET  /api/automatizaciones/descargar/{f}     → sirve el .xlsx generado

Los Excels se suben por la tarjeta «automatizaciones/» del upload; el cuadro
se guarda en `outputs/automatizaciones/` de la sesión (JSON + XLSX). El último
JSON es el que el informe .docx pinta como su primera tabla.
"""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/automatizaciones", tags=["automatizaciones"])


class PedirCuadro(BaseModel):
    # Explícito: el validador elige si gasta IA o quiere el borrador gratuito.
    usar_ia: bool = True


def carpeta_entrada(ctx: dict) -> Path:
    return ctx["inputs"] / "automatizaciones"


def carpeta_salida(ctx: dict) -> Path:
    return ctx["outputs"] / "automatizaciones"


def ultimo_cuadro(ctx: dict) -> dict | None:
    """El cuadro más reciente de la sesión, o None."""
    sal = carpeta_salida(ctx)
    if not sal.is_dir():
        return None
    jsons = sorted(sal.glob("cuadro_observaciones_*.json"))
    if not jsons:
        return None
    datos = json.loads(jsons[-1].read_text(encoding="utf-8"))
    datos["_json"] = jsons[-1].name
    xlsx = jsons[-1].with_suffix(".xlsx")
    datos["_xlsx"] = xlsx.name if xlsx.is_file() else None
    return datos


def _contexto_modelo(ctx: dict) -> str:
    """Entendimiento del modelo (si ya se generó) para explicar bien el producto."""
    m = ctx["modelo"]
    partes = [f"Modelo: {m.get('nombre', '')} · dominio: {m.get('dominio', '')} · "
              f"tier: {m.get('tier', '')}"]
    ent = ctx["base"] / f"entendimiento_modelo_{m['slug']}.md"
    if ent.is_file():
        partes.append(ent.read_text(encoding="utf-8", errors="ignore")[:3500])
    return "\n\n".join(partes)


@router.get("/estado")
def estado(ctx: dict = Depends(contexto_sesion)) -> dict:
    from modulos.automatizaciones import ETAPAS, localizar_excels
    encontrados = localizar_excels(carpeta_entrada(ctx))
    return {
        "etapas": [{"codigo": c, "etapa": e,
                    "archivo": encontrados[c].name if c in encontrados else None}
                   for c, e in ETAPAS.items()],
        "ultimo": ultimo_cuadro(ctx),
    }


@router.post("/cuadro")
def generar(body: PedirCuadro, ctx: dict = Depends(contexto_sesion)) -> dict:
    from modulos import automatizaciones as auto
    try:
        cuadro = auto.generar_cuadro(
            carpeta_entrada(ctx), usar_ia=body.usar_ia,
            contexto_modelo=_contexto_modelo(ctx))
    except FileNotFoundError as exc:
        raise HTTPException(404, str(exc))
    except Exception as exc:
        raise HTTPException(502, f"No se pudo generar el cuadro: {exc}")
    rutas = auto.guardar(cuadro, carpeta_salida(ctx))
    cuadro["_json"] = rutas["json"].name
    cuadro["_xlsx"] = rutas["xlsx"].name
    return cuadro


@router.get("/descargar/{fichero}")
def descargar(fichero: str, ctx: dict = Depends(contexto_sesion)) -> FileResponse:
    nombre = Path(fichero).name
    if nombre != fichero or not nombre.endswith(".xlsx"):
        raise HTTPException(400, f"nombre inválido: {fichero}")
    sal = carpeta_salida(ctx)
    ruta = (sal / nombre).resolve()
    try:
        ruta.relative_to(sal.resolve())
    except ValueError:
        raise HTTPException(400, "fuera del directorio de salida")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {nombre}")
    return FileResponse(
        ruta, filename=nombre,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
