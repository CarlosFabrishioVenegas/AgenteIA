"""
Autenticación por código + nombre (v2 · fase 1).

El token de sesión viaja como cookie `virf_token` (httponly, samesite=lax).
No hay contraseña — el sistema es de UN operador en su estación, y el
login sirve para separar validadores en la persistencia, no para proteger
un secreto compartido.
"""
from __future__ import annotations

from fastapi import APIRouter, Cookie, HTTPException, Response
from pydantic import BaseModel, Field

from ..services import sesion_store

router = APIRouter(prefix="/api/auth", tags=["auth"])

COOKIE_TOKEN = "virf_token"


class Login(BaseModel):
    codigo: str = Field(..., min_length=2, max_length=16)
    nombre: str = Field(..., min_length=1, max_length=120)


@router.post("/login")
def hacer_login(body: Login, response: Response) -> dict:
    try:
        token, val = sesion_store.login(body.codigo, body.nombre)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    response.set_cookie(
        key=COOKIE_TOKEN, value=token,
        httponly=True, samesite="lax", max_age=60 * 60 * 12,
    )
    return {"validador": val}


@router.post("/logout")
def hacer_logout(response: Response,
                 virf_token: str | None = Cookie(default=None)) -> dict:
    sesion_store.logout(virf_token)
    response.delete_cookie(COOKIE_TOKEN)
    return {"ok": True}


@router.get("/actual")
def validador_actual(virf_token: str | None = Cookie(default=None)) -> dict:
    """
    Devuelve el validador logueado o 401 si no hay sesión.

    El 401 lo consume la SPA para decidir si mostrar el login antes que
    el dashboard.
    """
    val = sesion_store.sesion_activa(virf_token)
    if val is None:
        raise HTTPException(401, "no autenticado")
    return {"validador": val}
