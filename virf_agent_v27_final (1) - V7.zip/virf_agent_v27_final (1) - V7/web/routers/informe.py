"""
Informe consolidado por sesión (v2 · fase 8).

- POST /api/informe/consolidado          → genera un .docx versionado
- GET  /api/informe/versiones            → lista todos los generados
- GET  /api/informe/descargar/{fichero}  → sirve un .docx concreto
- GET  /api/informe/estado               → resumen de qué hay para el docx
"""
from __future__ import annotations

import json
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel

from ..services import chat_service, informe_web, modelos_store, pipeline_runner
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/informe", tags=["informe"])


class Consolidar(BaseModel):
    ruta: str  # "YYYY-MM-DD/fichero.json" relativo a outputs de la sesión


@router.get("/estado")
def estado(ctx: dict = Depends(contexto_sesion)) -> dict:
    """Panorama para el panel «Documentar Todo»."""
    outs = ctx["outputs"]
    inputs = ctx["inputs"]
    n_ficheros = sum(1 for _ in inputs.rglob("*") if _.is_file()) if inputs.exists() else 0
    # ¿Hay JSON de resultados disponibles?
    jsons = []
    if outs.exists():
        for dia in sorted(outs.iterdir(), reverse=True):
            if not dia.is_dir():
                continue
            for p in sorted(dia.iterdir(), reverse=True):
                if p.is_file() and p.name.startswith("resultados_") and p.suffix == ".json":
                    jsons.append(f"{dia.name}/{p.name}")
    # Chat
    s = chat_service.sesion_activa(ctx)
    chat_resumen = s.resumen() if s else None
    # Run activo
    r = pipeline_runner.run_de_sesion(ctx["clave"])
    return {
        "n_ficheros_inputs": n_ficheros,
        "resultados_disponibles": jsons,
        "chat":     chat_resumen,
        "run":      r.estado if r else None,
        "versiones": informe_web.listar_versiones(ctx),
    }


@router.get("/versiones")
def versiones(ctx: dict = Depends(contexto_sesion)) -> dict:
    return {"versiones": informe_web.listar_versiones(ctx)}


@router.post("/consolidado")
def consolidar(body: Consolidar,
                ctx: dict = Depends(contexto_sesion)) -> dict:
    partes = body.ruta.split("/")
    if len(partes) != 2:
        raise HTTPException(400, "ruta debe ser 'YYYY-MM-DD/fichero.json'")
    fecha, fichero = partes
    ruta_json = (ctx["outputs"] / fecha / Path(fichero).name).resolve()
    try:
        ruta_json.relative_to(ctx["outputs"].resolve())
    except ValueError:
        raise HTTPException(400, "ruta fuera de outputs de la sesión")
    if not ruta_json.is_file():
        raise HTTPException(404, f"no existe: {body.ruta}")

    datos = json.loads(ruta_json.read_text(encoding="utf-8"))
    docx_path, version = informe_web.generar(datos, body.ruta, ctx)
    modelos_store.actualizar_actividad(
        ctx["validador"]["codigo"], ctx["modelo"]["slug"], estado="completado")
    return {
        "ok":       True,
        "docx":     docx_path.name,
        "version":  version,
        "sesion":   ctx["clave"],
    }


@router.get("/descargar/{fichero}")
def descargar(fichero: str,
                ctx: dict = Depends(contexto_sesion)) -> FileResponse:
    nombre = Path(fichero).name
    if nombre != fichero:
        raise HTTPException(400, f"nombre inválido: {fichero}")
    salida = informe_web.salida_dir_de(ctx)
    ruta = (salida / nombre).resolve()
    try:
        ruta.relative_to(salida.resolve())
    except ValueError:
        raise HTTPException(400, "fuera del directorio de salida")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {nombre}")
    return FileResponse(
        ruta, filename=nombre,
        media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    )
