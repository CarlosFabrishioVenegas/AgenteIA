"""
Modelos del validador logueado + selección del modelo activo (v2 · fase 1).

El modelo activo se guarda en una cookie `virf_modelo` (con el slug). La
fase 2 conectará esa cookie con el resto de routers (upload, prevuelo…)
para que trabajen sobre `web/data/sesiones/{val}/{slug}/`.
"""
from __future__ import annotations

from fastapi import APIRouter, Cookie, HTTPException, Response
from pydantic import BaseModel, Field

from ..services import modelos_store, sesion_store

router = APIRouter(prefix="/api/modelos", tags=["modelos"])

COOKIE_MODELO = "virf_modelo"


class NuevoModelo(BaseModel):
    nombre:  str = Field(..., min_length=1, max_length=100)
    dominio: str
    tier:    str


def _validador_logueado_o_401(virf_token: str | None) -> dict:
    val = sesion_store.sesion_activa(virf_token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    return val


@router.get("")
def listar_modelos(virf_token: str | None = Cookie(default=None)) -> dict:
    val = _validador_logueado_o_401(virf_token)
    return {"validador": val, "modelos": modelos_store.listar(val["codigo"])}


@router.post("")
def crear_modelo(body: NuevoModelo,
                 virf_token: str | None = Cookie(default=None)) -> dict:
    val = _validador_logueado_o_401(virf_token)
    try:
        m = modelos_store.crear(val["codigo"], body.nombre, body.dominio,
                                 body.tier)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"modelo": m}


@router.post("/{slug}/activar")
def activar_modelo(slug: str, response: Response,
                    virf_token: str | None = Cookie(default=None)) -> dict:
    """Marca el modelo como activo (cookie); el resto del backend lo usa."""
    val = _validador_logueado_o_401(virf_token)
    m = modelos_store.cargar(val["codigo"], slug)
    if m is None:
        raise HTTPException(404, f"modelo {slug!r} no existe")
    response.set_cookie(
        key=COOKIE_MODELO, value=slug,
        httponly=True, samesite="lax", max_age=60 * 60 * 12,
    )
    return {"modelo": m}


@router.get("/activo")
def modelo_activo(virf_token: str | None = Cookie(default=None),
                   virf_modelo: str | None = Cookie(default=None)) -> dict:
    """Modelo actualmente seleccionado (o `None`)."""
    val = _validador_logueado_o_401(virf_token)
    if not virf_modelo:
        return {"modelo": None}
    m = modelos_store.cargar(val["codigo"], virf_modelo)
    return {"modelo": m}


@router.post("/desactivar")
def desactivar(response: Response,
                virf_token: str | None = Cookie(default=None)) -> dict:
    _validador_logueado_o_401(virf_token)
    response.delete_cookie(COOKIE_MODELO)
    return {"ok": True}


@router.delete("/{slug}")
def borrar_modelo(slug: str,
                   virf_token: str | None = Cookie(default=None)) -> dict:
    val = _validador_logueado_o_401(virf_token)
    ok = modelos_store.borrar(val["codigo"], slug)
    if not ok:
        raise HTTPException(404, f"modelo {slug!r} no existe")
    return {"ok": True}
