"""
Pre-vuelo sobre la EVIDENCIA de la sesión activa (v2 · fase 2).

El dominio ya no es un endpoint aparte — vive en la ficha del modelo
(elegido al crearlo). Este router expone únicamente el pre-vuelo, que
lee la evidencia de la sesión activa (no la de `inputs/` global).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends

from ..services.contexto_sesion import contexto_sesion

router = APIRouter(tags=["prevuelo"])


def _rutas_de_sesion(ctx: dict) -> dict[str, Path]:
    """
    Mapeo `nombre_carpeta_agente → ruta_fisica` para el pre-vuelo.
    Las claves son las que el agente conoce (ver `AMBITO_A_INPUTS` en
    `Mx_00_CargaRutas.py`) — mismos nombres para que el pre-vuelo
    reutilice la lógica de `ejecutar_prevuelo` sin adaptaciones.
    """
    base = ctx["inputs"]
    return {
        "doc_modelamiento": base / "documentacion" / "modelamiento",
        "doc_seguimiento":  base / "documentacion" / "seguimiento",
        "papers":           base / "papers",
        "calidad_datos":    base / "calidad_datos",
        "implementacion":   base / "implementacion",
        "usos":             base / "usos",
    }


@router.post("/api/prevuelo")
def prevuelo(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Coste 0. Recorre `web/data/sesiones/{val}/{slug}/inputs/` y devuelve
    el diagnóstico. Un ámbito sin evidencia en la sesión es un aviso
    fuerte: si se lanza la validación, ese ámbito puntuará 0.0 y arrastra.
    """
    from modulos.prevuelo import ejecutar_prevuelo

    informe = ejecutar_prevuelo(rutas_inputs=_rutas_de_sesion(ctx))
    d = informe.a_dict()
    d["modelo"]  = ctx["modelo"]["slug"]
    d["dominio"] = ctx["modelo"]["dominio"]
    return d
