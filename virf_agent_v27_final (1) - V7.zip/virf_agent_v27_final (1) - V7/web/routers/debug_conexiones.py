"""
Endpoint HTTP para el verificador de conexiones (Mejora 5 · v2.2).
Misma contraseña que el visor de prompt.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException

from ..services.contexto_sesion import contexto_sesion
from ..verificar_conexiones import verificar
from .preview_prompt import CONTRASENA

router = APIRouter(prefix="/api/debug", tags=["debug"])


@router.get("/conexiones")
def conexiones(ctx: dict = Depends(contexto_sesion),
                x_prompt_password: str = Header(default="")) -> dict:
    if x_prompt_password != CONTRASENA:
        raise HTTPException(403, "contraseña incorrecta")
    d = verificar(ctx["validador"]["codigo"], ctx["modelo"]["slug"])
    # No devolvemos `_reporte` ni `_ctx` (objetos internos).
    return {"bloques": d["bloques"], "resumen": d["resumen"]}
