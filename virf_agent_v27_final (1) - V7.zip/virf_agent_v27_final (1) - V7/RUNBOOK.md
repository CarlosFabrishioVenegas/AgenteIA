# RUNBOOK — Validar un modelo de principio a fin

> Guía operativa. Qué comando corres, qué miras, y **cuándo parar**.
>
> Los pasos 0, 2 y 6 son **coste 0**. Solo los pasos 3, 4 y 5 llaman al modelo.
>
> Referencia de flags → `FLAGS.md` · catálogo funcional → `FUNCIONALIDADES.md`

---

## Resumen en una pantalla

```
0. Preparar entorno        (una vez)          coste 0
1. Colocar la evidencia    (manual)           coste 0
2. Verificación previa     ← --prevuelo PRIMERO coste 0
3. Entender el modelo      --explicar-modelo  💰
4. Pre-producción          (itera aquí)       💰
5. Producción              --prdc             💰
6. Cierre de auditoría                        coste 0
```

**Regla de oro:** nunca saltes del 1 al 4. El paso 2 cuesta cero y te dice si
la corrida va a costar $0,05 o $50.

---

## Paso 0 — Preparar el entorno (una sola vez)

```bash
cp .env.example .env
# Pega las 4 credenciales que te dio IT en el bloque de Azure OpenAI
python agente.py --verificar-conexion-azure
python validate_project.py --strict
```

**Qué esperas ver:**

```
✅ azure_openai conectado — modelo: gpt-4o-2024-11-20 — latencia: 812 ms
   Perfil de chunking que se aplicará (gpt-4o): …
```

| ⛔ CRITERIO DE PARADA |
|---|
| Si `--verificar-conexion-azure` sale con **código 1**, para. El mensaje dice qué variable revisar y dónde obtenerla. Nada más va a funcionar. |
| Si `validate_project.py --strict` tiene algún **FAIL**, para y corrígelo. Los WARN suelen ser evidencia ausente y son tolerables. |

> El error más común: `AZURE_OPENAI_DEPLOYMENT` es el **Deployment name** del
> portal, **no** el nombre del modelo. Poner `gpt-4o` cuando tu deployment se
> llama `gpt4o-prod` da `DeploymentNotFound` (404).

---

## Paso 1 — Colocar la evidencia

```
inputs/
├── documentacion/modelamiento/   manual metodológico          ← imprescindible
├── documentacion/seguimiento/    backtesting, seguimiento
├── implementacion/               código: .py .ipynb .sql .R
│   ├── libs/  notebooks/  etl/   subcarpetas: se recorren
│   └── datasets/                 los datos (se perfilan, no se vuelcan)
├── calidad_datos/                ControlesData.xlsx, perfiles
├── papers/                       referencias
└── usos/                         actas de comité, uso en gestión
```

| ⛔ CRITERIO DE PARADA |
|---|
| **Sin manual metodológico no hay contraste.** El agente puede describir el código, pero no puede compararlo contra nada. El informe lo declarará, y ese informe no sirve como validación. |

**Qué NO se lee** (se omite sin aviso): `.scala`, `.yaml`, `.do`, `.sas`.
Si tu modelo los usa, hay que registrarlos en `LECTORES_EXT` antes de seguir.

---

## Paso 2 — Verificación previa · **coste 0**

```bash
python validate_project.py --strict
python agente.py --prevuelo                          # ← EMPIEZA POR AQUÍ
python agente.py --explicar-modelo "<MODELO>" --dry-run
python agente.py --revisar-codigo --dry-run
```

**`--prevuelo` es el más importante de los cuatro.** Responde a «con esta
evidencia, ¿qué va a poder evaluar el agente y qué no?» antes de gastar:

| Detecta | Por qué importa |
|---|---|
| PDFs escaneados | Ilegibles desde que se retiró el OCR. Antes se descubría a mitad de corrida |
| Formatos no registrados (`.sas`, `.yaml`…) | Hoy **desaparecen sin dejar rastro** |
| Ámbitos sin evidencia | Puntúan 0.0 y esa falta se atribuye al **validado** |
| Ámbitos con evidencia parcial | Se evalúan sin su carpeta principal: puntaje débil de sostener |

Sale con **código 1** si algún ámbito queda sin evidencia. Lee los documentos a
través del caché, así que la corrida real reutiliza esas lecturas: adelanta
trabajo, no lo duplica.

**Qué miras:** el inventario. Cuántos ficheros detectó por fuente, cuántos
módulos de código, y el **coste estimado** de cada paso.

| ⛔ CRITERIO DE PARADA |
|---|
| **`--prevuelo` sale con código 1** → hay ámbitos SIN evidencia. Puntuarán 0.0 y esa falta se atribuirá al validado. Consigue la documentación antes de gastar. |
| **PDFs escaneados o formatos omitidos** → esos documentos NO llegarán al evaluador. Conviértelos o regístralos primero. |
| El inventario de código dice **cientos de módulos** → tu árbol arrastra un `.venv` o `site-packages`. Corta y relanza con `VIRF_EXCLUIR_DEPENDENCIAS=1`. |
| El coste estimado te sorprende → baja `VIRF_MAX_CHARS_MANUAL_REVISION` (el manual viaja en *cada* llamada de la revisión de código: es el multiplicador). |

---

## Paso 3 — Entender el modelo 💰

```bash
python agente.py --explicar-modelo "<MODELO>"
```

→ `outputs/<fecha>/explicacion_del_modelo_<MODELO>.md` — 9 secciones fijas
consolidando las 4 fuentes.

**Léelo antes de validar.** Es barato y te dice si la evidencia se sostiene.

| ⛔ CRITERIO DE PARADA |
|---|
| Si aparece **`⚠️ Sin evidencia en fuentes`** en secciones clave (metodología, seguimiento), el dictamen del paso 5 saldrá cojo. Consigue la evidencia primero. |
| Si la sección **9 (Preguntas abiertas)** está llena de cosas básicas, la documentación del modelo es insuficiente — y eso ya es un hallazgo de validación. |

---

## Paso 4 — Pre-producción · **aquí se itera** 💰

```bash
python agente.py --titulo "<MODELO>" --tier <1-4> \
                 --revisar-codigo --perfilar-datasets
```

Al terminar se abre el **bucle de feedback**: corriges los puntajes que el
agente falló, y esas correcciones alimentan las siguientes corridas.

**Las tres cifras que decides mirar, en este orden:**

```
🔎 INTEGRIDAD DE LA EVALUACIÓN:
  • Actividades evaluadas OK : 34
  • Sin evidencia (D3-FIX)   : 0
  • Fallos técnicos          : 0     ← ESTA PRIMERO
```

| ⛔ CRITERIO DE PARADA |
|---|
| **`Fallos técnicos` > 0** → esas actividades **no se evaluaron** y están excluidas del score. **Re-ejecuta** antes de seguir. No emitas nada. |
| **`Revisión confiable: False`** → algún módulo de código falló. La revisión está incompleta. |
| **`Score global: NO EVALUABLE`** → ningún ámbito tenía evidencia. Esto **no** significa que el modelo sea malo: significa que no hay nada que dictaminar. Vuelve al paso 1. |
| **Cobertura documental baja** en un ámbito (p. ej. 30 %) → el evaluador vio un tercio del manual. Sube `VIRF_MAX_CTX` o revisa por qué se saturó el contexto. |

Repite este paso las veces que haga falta. **Es el único paso que se itera.**

---

## Paso 5 — Producción · el entregable 💰

```bash
python agente.py --titulo "<MODELO>" --tier <1-4> --prdc \
                 --validador "Tu Nombre Completo" \
                 --cargo "Validador de Segunda Línea" \
                 --revisar-codigo --perfilar-datasets
```

Genera el **Word**, exige tu firma **antes** de gastar, sella la cadena de
custodia y registra la aprobación.

| ⛔ CRITERIO DE PARADA |
|---|
| **No llegues aquí con `Fallos técnicos` > 0 en el paso 4.** Un entregable firmado sobre una evaluación incompleta es peor que no entregar. |
| Si sale el **aviso de segunda revisión** (3+ firmas consecutivas tuyas sobre el mismo modelo), valóralo: no bloquea, pero queda escrito en el informe y el auditor lo verá. |

> Aquí **no** hay bucle de feedback: es el entregable, no un borrador.

---

## Paso 6 — Cierre de auditoría · **coste 0**

```bash
python agente.py --verificar-cadena "<MODELO>"
python agente.py --verificar-evidencia outputs/<fecha>/resultados_<MODELO>_<fecha>.json
python agente.py --historial-validaciones
python agente.py --comparar "<MODELO>"        # ← si ya hay corridas previas
```

Los dos primeros salen con **código 1** si algo se alteró. Son la respuesta a
las dos preguntas del auditor:

- *«¿Cómo sé que este informe no se editó después?»* → `--verificar-cadena`
- *«¿Sobre qué versión del manual se emitió este puntaje?»* → `--verificar-evidencia`

| ⛔ CRITERIO DE PARADA |
|---|
| Cadena rota → el informe fue alterado o un eslabón se perdió. **No lo presentes.** Investiga antes. |
| Evidencia alterada → el manual cambió después de emitir. El puntaje ya no describe el modelo vigente: **hay que re-emitir**. |

### Si es una revalidación: `--comparar`

```bash
python agente.py --comparar "Modelo LaR"
```

Toma los **dos últimos eslabones de la cadena** y dice qué cambió: score por
ámbito, actividades que subieron o bajaron, documentos con hash distinto.

Y responde a la pregunta que a mano casi no se puede responder:

> **¿el modelo mejoró, o cambió el criterio con el que se le mide?**

Las dos producen la misma subida de nota. Si cambió el estándar VIRF, el modelo
de IA o la versión del agente, el informe lo dice **arriba del todo** y sale con
**código 1** — no es un error, es la señal de que las diferencias **no** son
atribuibles solo al modelo.

```
⚠️  LA VARA DE MEDIR CAMBIÓ ENTRE ESTAS DOS CORRIDAS
   Las diferencias de abajo NO son solo del modelo.
   · Estándar VIRF: EST-V1 → EST-V2
     requeridas en el tier: 11 → 14
   · modelo_ia: gpt-4o → gpt-5
```

También avisa del caso inverso: score distinto con **la misma evidencia y la
misma vara** → es variabilidad del modelo de lenguaje, no del modelo validado.

---

## Qué queda en `outputs/<fecha>/`

| Fichero | Cuándo | Para quién |
|---|---|---|
| `resultados_<modelo>_<fecha>.json` | siempre | auditoría — score, hallazgos, custodia, trazabilidad |
| `VIRF_Informe_*.docx` | solo `--prdc` | **el entregable** |
| `revision_codigo_<modelo>.md` | `--revisar-codigo` | detalle `fichero:línea` |
| `explicacion_del_modelo_<modelo>.md` | paso 3 | entender el modelo |
| `calidad_proceso_*.json` | solo `--prdc` | ⚠️ **uso interno — nunca se entrega** |

---

## Variantes

### Varios modelos en el mismo repositorio

Un comando por modelo, **una raíz de evidencia por modelo**. Sin esto, el manual
de un modelo puntúa como evidencia de otro:

```bash
python agente.py --titulo "VaR FRTB" --tier 1 \
                 --raiz-evidencia modelos/VaR_FRTB \
                 --datasets modelos/VaR_FRTB/inputs/calidad_datos/datasets \
                 --revisar-codigo --perfilar-datasets
```

> `--datasets` hay que pasarlo explícito: su default **no** sigue a
> `--raiz-evidencia`.

### Solo Calidad de Datos, guiado por Excel

```bash
python agente.py --titulo "<MODELO>" --tier <1-4> --control \
                 --excel inputs/calidad_datos/ControlesData.xlsx \
                 --datasets inputs/calidad_datos/datasets
```

| ⚠️ ADVERTENCIA |
|---|
| `--control` **no sella cadena de custodia ni pide firma**, aunque pases `--prdc` (ahí `--prdc` solo cambia el banner). Genera el Word **siempre**. Para un entregable que deba acreditar validación independiente, usa el pipeline completo del paso 5. Detalle en `FLAGS.md` §16.1. |

---

## Diagnóstico rápido

| Síntoma | Causa | Qué hacer |
|---|---|---|
| `❌ API key rechazada (401)` | credencial inválida | El mensaje dice qué variable y qué consola |
| `DeploymentNotFound (404)` | pusiste el nombre del modelo | Usa el **Deployment name** del portal |
| `SIN DOCUMENTOS` en todos los ámbitos | `inputs/` vacío o ruta mal | Revisa el paso 1, o `--raiz-evidencia` |
| `⚠️ Carpetas sin documentos: …` | árbol a medio montar | Esos ámbitos puntuarán 0.0 — **no es culpa del validado** |
| `Sin datasets en …` | falta la carpeta | Los controles con `USA_MOTOR_DATA=1` no correrán |
| Tu `.sql` / `.R` no aparece | — | Ya se leen. Si es `.scala`/`.yaml`, **no**: hay que registrarlos |
| El coste te sorprendió | no hiciste el paso 2 | Siempre `--dry-run` antes |

---

## Checklist imprimible

```
[ ] 0. --verificar-conexion-azure  → ✅ conectado
[ ] 0. validate_project.py --strict → 0 FAIL
[ ] 1. manual metodológico en inputs/documentacion/modelamiento/
[ ] 2. --prevuelo                   → 0 bloqueantes (exit 0)
[ ] 2. --explicar-modelo --dry-run  → coste aceptable
[ ] 2. --revisar-codigo --dry-run   → nº de módulos razonable
[ ] 3. leer la explicación generada
[ ] 4. corrida pre-prod → Fallos técnicos = 0
[ ] 4. registrar feedback de lo que el agente falló
[ ] 5. corrida --prdc con --validador y --cargo
[ ] 6. --verificar-cadena       → exit 0
[ ] 6. --verificar-evidencia    → exit 0
[ ] 6. archivar el .docx y el .json juntos
```
