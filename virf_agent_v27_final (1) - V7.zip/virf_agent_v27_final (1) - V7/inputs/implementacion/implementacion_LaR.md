# Implementación — Modelo LaR

## Stack técnico

- Lenguaje: Python 3.10
- Librerías: numpy, pandas, scipy.stats, statsmodels
- Ejecución: DAG en Airflow — corrida diaria a las 07:00 COT.
- Persistencia: PostgreSQL (tabla `lar_daily_estimates`).

## Arquitectura

```
[Core bancario] ─┐
[SAP Tesorería] ─┼─→ [ETL Python] ─→ [Motor LaR] ─→ [DB Riesgo] ─→ [BI Tableau]
[Bloomberg]     ─┘                       │
                                          └─→ [Reporte diario Excel] → Correo
```

## Controles de ejecución

- Log estructurado en JSON — retenido 90 días.
- Alertas por Slack si:
  - Tiempo de ejecución > 15 min.
  - LaR > umbral regulatorio.
  - Alguna fuente falla o llega vacía.
- Runbook operativo actualizado 2026-05-30.

## Reproducibilidad

- Versionado del código en Git (repo `risk-liquidity-models`).
- Cada corrida guarda: parámetros, versión de código y hash de datos de entrada.

## Limitaciones actuales

- No hay contenedor Docker aún (ejecuta en VM compartida).
- Falta CI/CD — despliegue manual.
