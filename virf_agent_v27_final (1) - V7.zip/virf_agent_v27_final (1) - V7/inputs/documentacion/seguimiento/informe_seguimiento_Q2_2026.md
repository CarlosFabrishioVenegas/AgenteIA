# Informe de Seguimiento — Modelo LaR — Q2 2026

## Resumen ejecutivo

Durante Q2 2026 el modelo LaR produjo 3 excedencias en 63 días de trading,
por encima del valor esperado (0.63). Se activó revisión metodológica.

## Métricas de desempeño

| Métrica              | Valor    | Umbral   | Estado |
|----------------------|----------|----------|--------|
| Excedencias 99%      | 3        | ≤ 2      | ALERTA |
| Kupiec p-value       | 0.021    | > 0.05   | RECHAZO H0 |
| Christoffersen p-val | 0.15     | > 0.05   | OK |
| MAPE 30 días         | 8.2%     | ≤ 10%    | OK |

## Hallazgos

1. Concentración de excedencias en período de estrés de tasas (mayo 2026).
2. Volatilidad EWMA subestimada — considerar cambio a GARCH(1,1).
3. Datos de flujos de una cuenta corporativa top-10 llegaron con 2 días
   de rezago durante 5 fechas.

## Acciones correctivas

- Recalibración adelantada al 2026-08-15 (originalmente Q4).
- Piloto GARCH(1,1) vs EWMA — dueño: Equipo Cuantitativo.
- Automatización de ingesta desde el core bancario — dueño: TI Riesgo.
