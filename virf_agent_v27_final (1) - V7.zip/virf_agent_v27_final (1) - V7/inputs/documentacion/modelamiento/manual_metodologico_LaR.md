# Manual Metodológico — Modelo LaR (Liquidity at Risk)

## 1. Objetivo del modelo

Estimar la máxima pérdida potencial de liquidez que la entidad puede sufrir
en un horizonte de 30 días con un nivel de confianza del 99%, considerando
salidas netas de depósitos, uso de líneas comprometidas y estrés de mercado.

## 2. Marco teórico

El modelo LaR se apoya en la metodología VaR paramétrica extendida a flujos
de caja, siguiendo los lineamientos de Basel III (LCR/NSFR) y las guías
internas de Riesgo de Liquidez.

- Distribución supuesta de retornos de flujos: Normal univariada.
- Estimador de volatilidad: EWMA con λ = 0.94 (RiskMetrics).
- Cuantil crítico: z(99%) = 2.326.

Ecuación base:

    LaR_t = μ_t + σ_t · z(1-α)

donde μ_t es la salida neta esperada y σ_t la volatilidad EWMA a 30 días.

## 3. Supuestos y limitaciones

- Se asume normalidad de retornos: puede subestimar colas gruesas.
- No captura contagio entre productos (correlación asumida = 1 en escenario estrés).
- Backtesting realizado con 250 observaciones — mínimo recomendado por Basel.

## 4. Backtesting

Se aplican las pruebas de Kupiec (POF) y Christoffersen (independencia)
mensualmente. Excedencias esperadas: 2.5 en 250 días al 99%. Umbral de alerta
si excedencias observadas > 5.

## 5. Governance

Modelo aprobado por el Comité de Riesgo el 2026-01-15. Recalibración anual
obligatoria. Owner: Gerencia de Riesgo de Liquidez.
