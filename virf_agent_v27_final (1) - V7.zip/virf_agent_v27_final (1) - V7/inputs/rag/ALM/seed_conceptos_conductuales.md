# Conceptos base de modelos conductuales — documento semilla

> Resumen conceptual propio para dar contexto mínimo al RAG del dominio
> conductuales. No reproduce texto normativo. Complétalo con tus manuales internos.

## Qué son los modelos conductuales
Modelan el comportamiento de clientes cuando el contrato no fija por completo los
flujos: el vencimiento o el importe efectivos dependen de decisiones de las
personas. Son insumo del riesgo de tasa de interés del banking book (IRRBB) y del
riesgo de liquidez.

## Depósitos sin vencimiento definido (NMD)
Cuentas a la vista y de ahorro sin fecha contractual de vencimiento. Se modela:
- **Parte estable vs volátil**: qué proporción del saldo permanece ante cambios de
  tasa o estrés.
- **Vida media conductual** y perfil de reprecio: cómo se asigna el saldo a bandas
  temporales para el cálculo de IRRBB.
- Sensibilidad del saldo y de la tasa pagada ante movimientos de la tasa de
  mercado (pass-through).

## Prepago y cancelación anticipada
En préstamos e hipotecas, los clientes amortizan antes de tiempo. Se modela una
**tasa de prepago** (p. ej. CPR) que depende de incentivos de refinanciación,
estacionalidad y antigüedad de la operación. Afecta la duración efectiva del activo.

## Retiro anticipado de depósitos a plazo
Probabilidad de cancelación antes del vencimiento pactado, sensible a penalizaciones
y a diferenciales de tasa.

## Qué revisa el validador en un modelo conductual
- Justificación estadística de los supuestos (segmentación, ventanas, estabilidad).
- Backtesting del comportamiento estimado frente al observado.
- Análisis de sensibilidad ante escenarios de tasa y de estrés.
- Coherencia entre los supuestos conductuales y su uso en IRRBB/liquidez.
