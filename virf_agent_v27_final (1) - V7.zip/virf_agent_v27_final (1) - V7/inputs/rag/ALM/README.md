# Literatura de referencia — conductuales

**Dominio:** Modelos conductuales

## Qué va aquí

Literatura EXTERNA de referencia: normativa, papers, guías supervisoras.
Se indexa en el RAG y se inyecta como contexto experto al evaluar cualquier
modelo de este dominio.

Ejemplos de contenido apropiado:

- Modelización de prepago de préstamos
- Non-Maturity Deposits (NMD): estabilidad y decaimiento
- EBA/GL/2018/02 — IRRBB
- Papers de comportamiento de clientes y elasticidad

## Qué NO va aquí

❌ **La evidencia del modelo que se valida.** Manuales metodológicos, informes
de seguimiento o scripts del modelo bajo evaluación van en `inputs/` (o en la
raíz que indiques con `--raiz-evidencia`), NO aquí.

Mezclarlos produce razonamiento circular: al preguntar «¿el manual documenta el
backtesting?», el RAG recuperaría fragmentos del propio manual y los
presentaría como referencia autorizada que confirma la afirmación.

## Formatos

`.pdf` · `.docx` · `.pptx` · `.xlsx` · `.py` · `.txt` · `.md`

## Reindexar tras añadir documentos

```python
from src.rag.conductuales.indexer import ConductualesIndexer
ConductualesIndexer().build_index(force_rebuild=True)
```

Una carpeta vacía es un estado válido: el índice queda vacío y la validación
continúa sin contexto RAG. Mejor sin contexto que con contexto ajeno.
