# Conceptos base de riesgo de liquidez (LaR) — documento semilla

> Resumen conceptual propio, redactado para dar contexto mínimo al RAG del dominio
> LaR. No reproduce texto normativo; sintetiza los conceptos que un validador
> contrasta contra la metodología del modelo. Sustitúyelo o complétalo con tus
> manuales internos.

## Coeficiente de Cobertura de Liquidez (LCR)
El LCR exige que la entidad mantenga activos líquidos de alta calidad (HQLA)
suficientes para cubrir las salidas netas de efectivo esperadas durante un
horizonte de estrés de 30 días naturales. Se expresa como:

    LCR = HQLA / Salidas netas de efectivo a 30 días  ≥ 100%

- **HQLA**: activos que pueden convertirse en efectivo con poca o nula pérdida de
  valor. Nivel 1 (efectivo, reservas, deuda soberana de alta calidad) sin recorte
  o con recorte bajo; Nivel 2 (2A y 2B) con recortes crecientes y límites de
  concentración.
- **Salidas netas** = salidas brutas − min(entradas, 75% de las salidas). El tope
  del 75% impide que las entradas asumidas eliminen por completo el colchón.
- **Factores de salida**: los depósitos minoristas estables tienen factores de
  fuga bajos; la financiación mayorista no garantizada, factores altos.

## Coeficiente de Financiación Estable Neta (NSFR)
El NSFR promueve financiación estable a un horizonte de un año:

    NSFR = Financiación estable disponible (ASF) / Financiación estable requerida (RSF) ≥ 100%

- **ASF**: capital y pasivos ponderados por su permanencia esperada (el capital y
  los depósitos estables reciben factores altos).
- **RSF**: activos y exposiciones fuera de balance ponderados por su iliquidez y
  vencimiento residual.

## Qué revisa el validador en un modelo LaR
- Trazabilidad de los factores de salida/entrada aplicados frente a la norma y los
  supuestos internos.
- Clasificación de HQLA y aplicación correcta de recortes y límites.
- Consistencia entre el horizonte de estrés, los escenarios y el backtesting de
  liquidez, si existe.
- Calidad de los datos de flujos contractuales y conductuales que alimentan el
  cálculo.
