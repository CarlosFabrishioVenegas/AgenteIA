# Literatura de referencia — LaR

**Dominio:** Liquidity at Risk / riesgo de liquidez

## Qué va aquí

Literatura EXTERNA de referencia: normativa, papers, guías supervisoras.
Se indexa en el RAG y se inyecta como contexto experto al evaluar cualquier
modelo de este dominio.

Ejemplos de contenido apropiado:

- Basilea III — LCR y NSFR (BCBS 238, BCBS 295)
- Directrices EBA sobre ILAAP
- Papers de modelización de salidas de depósitos y HQLA
- Metodologías de stress testing de liquidez

## Qué NO va aquí

❌ **La evidencia del modelo que se valida.** Manuales metodológicos, informes
de seguimiento o scripts del modelo bajo evaluación van en `inputs/` (o en la
raíz que indiques con `--raiz-evidencia`), NO aquí.

Mezclarlos produce razonamiento circular: al preguntar «¿el manual documenta el
backtesting?», el RAG recuperaría fragmentos del propio manual y los
presentaría como referencia autorizada que confirma la afirmación.

## Formatos

`.pdf` · `.docx` · `.pptx` · `.xlsx` · `.py` · `.txt` · `.md`

## Reindexar tras añadir documentos

```python
from src.rag.LaR.indexer import LaRIndexer
LaRIndexer().build_index(force_rebuild=True)
```

Una carpeta vacía es un estado válido: el índice queda vacío y la validación
continúa sin contexto RAG. Mejor sin contexto que con contexto ajeno.
