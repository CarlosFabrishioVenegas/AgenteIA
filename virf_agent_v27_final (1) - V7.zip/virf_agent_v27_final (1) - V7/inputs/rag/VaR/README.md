# Literatura de referencia — VaR

**Dominio:** Value at Risk / riesgo de mercado

## Qué va aquí

Literatura EXTERNA de referencia: normativa, papers, guías supervisoras.
Se indexa en el RAG y se inyecta como contexto experto al evaluar cualquier
modelo de este dominio.

Ejemplos de contenido apropiado:

- FRTB — Minimum capital requirements for market risk (BCBS 457)
- Kupiec (1995) — Techniques for Verifying the Accuracy of Risk Models
- Christoffersen (1998) — Evaluating Interval Forecasts
- RiskMetrics Technical Document (JP Morgan, 1996)
- Basilea — Supervisory framework for backtesting (zonas verde/ámbar/roja)

## Qué NO va aquí

❌ **La evidencia del modelo que se valida.** Manuales metodológicos, informes
de seguimiento o scripts del modelo bajo evaluación van en `inputs/` (o en la
raíz que indiques con `--raiz-evidencia`), NO aquí.

Mezclarlos produce razonamiento circular: al preguntar «¿el manual documenta el
backtesting?», el RAG recuperaría fragmentos del propio manual y los
presentaría como referencia autorizada que confirma la afirmación.

## Formatos

`.pdf` · `.docx` · `.pptx` · `.xlsx` · `.py` · `.txt` · `.md`

## Reindexar tras añadir documentos

```python
from src.rag.VaR.indexer import VaRIndexer
VaRIndexer().build_index(force_rebuild=True)
```

Una carpeta vacía es un estado válido: el índice queda vacío y la validación
continúa sin contexto RAG. Mejor sin contexto que con contexto ajeno.
