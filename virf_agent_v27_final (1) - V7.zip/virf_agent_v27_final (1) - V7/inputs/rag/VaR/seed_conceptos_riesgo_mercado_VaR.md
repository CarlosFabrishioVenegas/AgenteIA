# Conceptos base de riesgo de mercado (VaR) — documento semilla

> Resumen conceptual propio para dar contexto mínimo al RAG del dominio VaR.
> No reproduce texto normativo; sintetiza lo que un validador contrasta contra la
> metodología y el código del modelo. Complétalo con tus manuales internos.

## Valor en Riesgo (VaR)
El VaR estima la pérdida máxima esperada de una cartera para un **nivel de
confianza** y un **horizonte** dados, bajo condiciones normales de mercado. Un VaR
al 99% a 1 día de S/ 1.0 MM significa que, en un día normal, la pérdida no debería
superar ese monto salvo en el 1% de los casos.

Enfoques habituales:
- **Histórico**: reordena los retornos observados en una **ventana** (p. ej. 250 o
  500 días) y toma el percentil correspondiente al nivel de confianza.
- **Paramétrico (varianza-covarianza)**: asume una distribución (normal) y estima
  volatilidades y correlaciones.
- **Monte Carlo**: simula trayectorias a partir de un modelo estadístico.

Parámetros críticos que deben coincidir entre manual y código: nivel de confianza,
horizonte, ventana de estimación y tipo de retorno (aritmético vs **logarítmico**).

## Backtesting
Contrasta las **excepciones** (días en que la pérdida real superó el VaR) contra
lo esperado por el nivel de confianza:
- **Prueba de Kupiec (cobertura incondicional)**: verifica que la *frecuencia* de
  excepciones sea coherente con 1 − confianza mediante un estadístico de razón de
  verosimilitud (LR).
- **Prueba de Christoffersen (independencia)**: verifica que las excepciones no se
  **agrupen** en el tiempo (que no haya dependencia temporal).
- Semáforo de zonas (verde/ámbar/rojo) según el número de excepciones en la
  ventana de observación.

## Expected Shortfall (ES) y FRTB
El marco de riesgo de mercado revisado sustituye el VaR al 99% por el **Expected
Shortfall** al 97.5% como medida de capital, por capturar mejor el riesgo de cola,
e incorpora horizontes de liquidez por factor de riesgo.

## Qué revisa el validador en un modelo VaR
- Coincidencia exacta de parámetros entre especificación (manual) y ejecución
  (código): confianza, horizonte, ventana, tipo de retorno.
- Existencia y suficiencia del backtesting (Kupiec/Christoffersen) y su
  trazabilidad de datos.
- Análisis de sensibilidad/escenarios y tratamiento de la no linealidad.
