# Gobernanza y validación de modelos (transversal) — documento semilla

> Resumen conceptual propio para dar contexto mínimo al RAG del dominio `shared`
> (transversal a todos los modelos). No reproduce texto normativo. Complétalo con
> tus políticas internas.

## Gestión del riesgo de modelo
El riesgo de modelo es el riesgo de pérdidas por decisiones basadas en modelos
incorrectos o mal utilizados. Se gestiona con un ciclo de vida: desarrollo,
documentación, validación independiente, aprobación, uso controlado, seguimiento y
retiro.

## Validación independiente y "effective challenge"
La validación es un reto crítico y efectivo, ejercido por personas con
independencia, competencia técnica e influencia para que sus observaciones se
atiendan. Cubre tres pilares:
1. **Solidez conceptual**: supuestos, teoría, diseño y calidad de datos.
2. **Monitoreo continuo**: backtesting, análisis de estabilidad y de límites.
3. **Análisis de resultados (outcomes)**: benchmarking y pruebas de desempeño.

## Tres líneas de defensa
- **Primera línea**: los dueños del modelo (desarrollo y uso).
- **Segunda línea**: validación y gestión del riesgo de modelo (independiente).
- **Tercera línea**: auditoría interna, que evalúa la efectividad del marco.

## Agregación de datos de riesgo y reporting
Los principios de agregación exigen precisión, integridad, completitud,
oportunidad y adaptabilidad de los datos de riesgo, con linaje trazable desde el
origen hasta el reporte. Un modelo solo es tan fiable como los datos que lo
alimentan.

## Qué revisa el validador de forma transversal
- Inventario y tiering del modelo actualizados.
- Documentación suficiente y control de versiones.
- Evidencia de uso conforme al alcance aprobado (actas, aprobaciones formales).
- Trazabilidad y calidad de los datos de entrada.
