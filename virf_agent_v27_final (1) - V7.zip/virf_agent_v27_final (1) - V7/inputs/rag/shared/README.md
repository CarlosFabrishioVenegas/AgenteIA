# Literatura de referencia — shared

**Dominio:** Regulación transversal (aplica a CUALQUIER modelo)

## Qué va aquí

Literatura EXTERNA de referencia: normativa, papers, guías supervisoras.
Se indexa en el RAG y se inyecta como contexto experto al evaluar cualquier
modelo de este dominio.

Ejemplos de contenido apropiado:

- SR 11-7 (Fed, 2011) — Guidance on Model Risk Management
- EBA/GL/2023/01 — Directrices sobre validación interna
- BCBS 239 — Principios de agregación de datos de riesgo
- TRIM Guide (BCE) — Targeted Review of Internal Models

## Qué NO va aquí

❌ **La evidencia del modelo que se valida.** Manuales metodológicos, informes
de seguimiento o scripts del modelo bajo evaluación van en `inputs/` (o en la
raíz que indiques con `--raiz-evidencia`), NO aquí.

Mezclarlos produce razonamiento circular: al preguntar «¿el manual documenta el
backtesting?», el RAG recuperaría fragmentos del propio manual y los
presentaría como referencia autorizada que confirma la afirmación.

## Formatos

`.pdf` · `.docx` · `.pptx` · `.xlsx` · `.py` · `.txt` · `.md`

## Reindexar tras añadir documentos

```python
from src.rag.shared.indexer import sharedIndexer
sharedIndexer().build_index(force_rebuild=True)
```

Una carpeta vacía es un estado válido: el índice queda vacío y la validación
continúa sin contexto RAG. Mejor sin contexto que con contexto ajeno.
