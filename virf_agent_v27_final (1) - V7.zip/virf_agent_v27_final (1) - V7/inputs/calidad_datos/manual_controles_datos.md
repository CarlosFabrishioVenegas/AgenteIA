# Manual de Controles de Calidad de Datos — Modelo LaR

**Versión:** 2.1 | **Fecha:** 2026-03-15 | **Owner:** Gerencia de Riesgo de Liquidez

---

## 1. Objetivo

Este documento describe los controles de calidad de datos que se aplican sobre
la base `data_subset` antes de alimentar el modelo LaR. Todo control aquí
descrito debe ejecutarse en cada corrida mensual.

---

## 2. Controles de unicidad e integridad de claves

### 2.1 Unicidad Cliente por Cuenta
Cada `Cuenta` debe estar asociada a un único `Cliente`. La existencia de una
cuenta con más de un cliente indica un problema de integración entre el core
bancario y el sistema de tesorería. **Tolerancia: 0 casos.** Criticidad ALTA.

### 2.2 Unicidad de FechaVencimiento
Para cada combinación de `Cuenta` y `FechaApertura` debe existir una única
`FechaVencimiento`. Criticidad ALTA.

### 2.3 Ausencia de duplicados
No deben existir registros completamente duplicados en la base. Se verifica
sobre la combinación `Cuenta` + `FechaApertura`. **Tolerancia: 0 registros.**

---

## 3. Controles de completitud

### 3.1 Valores faltantes en Tasa
La columna `Tasa` no debe presentar valores nulos. Se admite hasta un **1%**
de missing, por encima del cual se escala al área de datos. Criticidad ALTA.

### 3.2 Completitud del extracto
El extracto mensual debe contener como mínimo **1000 registros** y las columnas
obligatorias: `Cuenta`, `Cliente`, `FechaApertura`, `FechaVencimiento`, `Tasa`.
Criticidad MEDIA.

---

## 4. Controles de consistencia de valores

### 4.1 Rango válido de Tasa
La `Tasa` de interés debe encontrarse entre **0 y 1** (expresada en tanto por
uno). Valores fuera de este rango indican error de unidad. Criticidad ALTA.

### 4.2 Detección de outliers en Tasa
Se identifican valores atípicos de `Tasa` mediante rango intercuartílico (IQR).
Los outliers NO se eliminan automáticamente: se reportan para análisis, ya que
pueden corresponder a operaciones legítimas de estrés. **Tolerancia: 2%.**
Criticidad MEDIA.

### 4.3 Tipo de dato de fechas
Las columnas `FechaApertura` y `FechaVencimiento` deben ser fechas válidas y
convertibles. Criticidad MEDIA.

---

## 5. Controles de integridad referencial

### 5.1 Integridad de Cliente contra maestro
Todo `Cliente` presente en `data_subset` debe existir en el maestro de clientes
`maestro_clientes`. Los clientes huérfanos indican desincronización entre
sistemas. **Tolerancia: 0 casos.** Criticidad ALTA.

---

## 6. Controles documentales (no automatizables)

### 6.1 Coherencia manual vs. script
El manual de extracción de datos debe describir origen, universo, variables,
transformaciones y controles. El script de extracción debe estar alineado con
lo descrito en el manual. Se revisa manualmente en cada validación anual.
Criticidad ALTA.

### 6.2 Trazabilidad de cambios
Todo cambio en la lógica de extracción debe quedar registrado en el control de
versiones con aprobación del owner. Criticidad MEDIA.
