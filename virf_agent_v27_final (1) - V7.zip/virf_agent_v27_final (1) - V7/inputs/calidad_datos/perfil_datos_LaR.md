# Perfil de Datos — Modelo LaR

## Fuentes de datos

- Core bancario (Oracle) — tabla `mov_cuentas` (histórico 5 años).
- Sistema de tesorería (SAP) — líneas comprometidas y flujos.
- Feed de mercado (Bloomberg) — tasas y spreads.

## Chequeos ejecutados

| Chequeo               | Resultado    | Tasa error |
|-----------------------|--------------|------------|
| Missing en flujos     | ADVERTENCIA  | 0.4%       |
| Duplicados por ID     | OK           | 0%         |
| Outliers (Z>3)        | ADVERTENCIA  | 1.2%       |
| Integridad referencial| OK           | 0%         |
| Freshness < 1 día     | ALERTA       | 8% (rezago)|

## Observaciones

- 0.4% de missing en flujos de cuentas corporativas — imputado con la media
  del mes previo (revisar si MCAR o MAR).
- 1.2% de outliers detectados con Z>3. NO se eliminaron (podrían ser eventos
  reales de estrés). Se aisló su impacto en un análisis de sensibilidad.
- El feed de mercado tiene rezago > 1 día en 8% de fechas — impacta cálculo
  del componente de volatilidad de mercado.

## Recomendaciones

1. Adoptar test formal para clasificar patrón de missing (Little's MCAR test).
2. Documentar política de tratamiento de outliers.
3. Establecer SLA con proveedor de datos de mercado.
