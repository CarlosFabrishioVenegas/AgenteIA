# RiskMetrics Technical Document (resumen)

Referencia: JP Morgan / Reuters (1996). RiskMetrics Technical Document, 4th ed.

## Modelo VaR paramétrico

- Supone retornos ~ N(μ, σ²).
- Volatilidad estimada con EWMA:
    σ²_t = λ · σ²_{t-1} + (1-λ) · r²_{t-1},  λ = 0.94 (diario)
- VaR_α = -(μ + σ · z_α) para posición long.

## Limitaciones conocidas

- Colas gruesas y curtosis: la Normal subestima eventos extremos.
- Correlaciones inestables en régimen de estrés.
- Recomendación: complementar con Expected Shortfall (ES) — captura pérdida
  esperada más allá del VaR.

## Backtesting recomendado

- Kupiec (POF): test de proporción de fallas.
- Christoffersen: test de independencia de excedencias.
- Ambos requieren ≥ 250 observaciones.
