# Uso del Modelo LaR en la Gestión

## Consumidores del output

1. **Comité de Activos y Pasivos (ALCO)** — informe semanal.
2. **Tesorería** — insumo para plan de fondeo diario.
3. **Riesgo Regulatorio** — reporte SFC (Superfinanciera) mensual.
4. **CFO** — dashboard ejecutivo con alertas amarillas/rojas.

## Decisiones que dispara

- Ajuste de reservas de liquidez (Tier 1) cuando LaR proyectado > buffer.
- Compra/venta de instrumentos líquidos de alta calidad (HQLA).
- Escalamiento al Comité de Crisis si LaR excede 3 sigma del baseline.

## Integración con otros modelos

- Insumo para el modelo de Fondeo Óptimo (optimización LP).
- Insumo para el modelo de Stress Testing corporativo.

## Trazabilidad

- Cada decisión de tesorería que se apoya en LaR queda registrada en el
  acta del comité, con referencia al ID de corrida del modelo.
