"""Control ALM: gap de reprecios por banda temporal."""

META = {
    "descripcion": "Ninguna banda de reprecio debe presentar un descalce |activos − pasivos| superior al límite sobre el total de activos.",
    "dimension":   "Riesgo de tasa (ALM)",
    "evidencia":   "Balance clasificado por banda de reprecio y signo activo/pasivo.",
    "referencia":  "Basilea IRRBB (BCBS d368); SR 11-7",
    "orden":       10,
    "params": {"dataset": "", "campo_monto": "monto", "campo_banda": "banda_reprecio",
               "campo_tipo": "", "valor_activo": "activo", "limite": 0.10},
}


def control(df, datasets, params):
    import pandas as pd
    c_m, c_b = params.get("campo_monto", "monto"), params.get("campo_banda", "banda_reprecio")
    if df is None or c_m not in getattr(df, "columns", []) or c_b not in df.columns:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas '{c_m}' y/o '{c_b}'"}
    monto = pd.to_numeric(df[c_m], errors="coerce").fillna(0.0)
    c_tipo = params.get("campo_tipo")
    if c_tipo and c_tipo in df.columns:
        val_act = str(params.get("valor_activo", "activo")).strip().lower()
        es_act = df[c_tipo].astype(str).str.strip().str.lower() == val_act
        firmado = monto.abs().where(es_act, -monto.abs())
    else:
        firmado = monto  # ya firmado: + activo / − pasivo

    gap = pd.DataFrame({"b": df[c_b].astype(str), "m": firmado}).groupby("b")["m"].sum()
    total_activos = firmado[firmado > 0].sum()
    if total_activos <= 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "no hay activos (montos > 0)"}

    limite = float(params.get("limite", 0.10) or 0.10)
    ratio = gap / total_activos
    violan = ratio[ratio.abs() > limite]
    peor = float(ratio.abs().max()) if len(ratio) else 0.0
    n = int(len(gap))
    pct = round(100.0 * (1 - len(violan) / n), 2) if n else None
    decision = "Cumple" if len(violan) == 0 else ("No cumple" if peor > 2 * limite else "Observado")
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"{len(violan)}/{n} bandas superan ±{limite:.0%} "
                            f"(peor {peor:.1%} de los activos)")}
