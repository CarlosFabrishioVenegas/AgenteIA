"""Control conductual: backtesting del prepago — error entre CPR observado y modelado bajo tolerancia."""

META = {
    "descripcion": "El CPR modelado debe seguir de cerca al observado: el error absoluto medio (MAE) entre ambos no debe superar la tolerancia.",
    "dimension":   "Conductual (prepago)",
    "evidencia":   "Serie por periodo de CPR observado y CPR modelado.",
    "referencia":  "Backtesting de modelos conductuales de prepago",
    "orden":       15,
    "params": {"dataset": "", "campo_cpr_obs": "cpr_obs", "campo_cpr_mod": "cpr_mod",
               "tolerancia": 0.05},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c_o, c_m = params.get("campo_cpr_obs", "cpr_obs"), params.get("campo_cpr_mod", "cpr_mod")
    if c_o not in cols or c_m not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas '{c_o}'/'{c_m}'"}
    obs = pd.to_numeric(df[c_o], errors="coerce")
    mod = pd.to_numeric(df[c_m], errors="coerce")
    m = obs.notna() & mod.notna()
    if int(m.sum()) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin pares observado/modelado"}
    err = (obs[m] - mod[m]).abs()
    mae = float(err.mean())
    peor = float(err.max())
    tol = float(params.get("tolerancia", 0.05))
    if mae <= tol:
        decision = "Cumple"
    elif mae <= 2 * tol:
        decision = "Observado"
    else:
        decision = "No cumple"
    # sesgo medio (con signo) para diagnóstico: >0 el modelo subestima el prepago.
    sesgo = float((obs[m] - mod[m]).mean())
    pct = round(max(0.0, 100.0 * (1.0 - mae)), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": f"MAE {mae:.2%} (tol {tol:.0%}), peor {peor:.2%}, "
                           f"sesgo {sesgo:+.2%} sobre {int(m.sum())} periodos"}
