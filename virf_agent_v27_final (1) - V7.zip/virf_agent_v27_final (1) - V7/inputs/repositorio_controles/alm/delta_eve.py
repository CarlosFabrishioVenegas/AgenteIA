"""Control ALM: prueba del outlier de ΔEVE (valor económico del patrimonio)."""

META = {
    "descripcion": "La máxima caída del valor económico (ΔEVE) entre los escenarios de shock no debe exceder el 15% del capital de nivel 1 (outlier IRRBB).",
    "dimension":   "Riesgo de tasa (ALM)",
    "evidencia":   "ΔEVE por escenario de shock (±200 pb y los 6 estándar) y capital de nivel 1.",
    "referencia":  "BCBS d368 — IRRBB, prueba de valor atípico (15% de CET1/Tier 1)",
    "orden":       20,
    # ΔEVE por escenario en una columna (negativo = pérdida de valor). Capital:
    # como número en 'capital' o como columna 'campo_capital'.
    "params": {"dataset": "", "campo_delta_eve": "delta_eve",
               "capital": 0.0, "campo_capital": "capital_tier1",
               "limite_pct": 0.15},
}


def control(df, datasets, params):
    import pandas as pd
    c_eve = params.get("campo_delta_eve", "delta_eve")
    if df is None or c_eve not in getattr(df, "columns", []):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de ΔEVE '{c_eve}'"}
    eve = pd.to_numeric(df[c_eve], errors="coerce").dropna()
    if len(eve) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin valores de ΔEVE"}

    capital = float(params.get("capital") or 0.0)
    if capital <= 0:
        c_cap = params.get("campo_capital", "capital_tier1")
        if c_cap in df.columns:
            cap_series = pd.to_numeric(df[c_cap], errors="coerce").dropna()
            capital = float(cap_series.iloc[0]) if len(cap_series) else 0.0
    if capital <= 0:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": "falta el capital de nivel 1 (param 'capital' o columna)"}

    peor_caida = float(-eve.min()) if eve.min() < 0 else 0.0    # magnitud de la pérdida
    ratio = peor_caida / capital
    limite = float(params.get("limite_pct", 0.15))
    decision = "Cumple" if ratio <= limite else "No cumple"
    pct = round(100.0 * (1 - min(ratio, 1.0)), 2)               # capital preservado
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"máx. caída ΔEVE {peor_caida:,.0f} = {ratio:.1%} del capital "
                            f"(límite {limite:.0%})")}
