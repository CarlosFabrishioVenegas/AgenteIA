"""Control conductual: estabilidad / núcleo de depósitos sin vencimiento (NMD)."""

META = {
    "descripcion": "Los depósitos sin vencimiento (NMD) deben mostrar un núcleo estable: la proporción de saldo que permanece (mín/promedio) por encima del umbral 'core'.",
    "dimension":   "Conductual (NMD)",
    "evidencia":   "Serie temporal de saldos de depósitos sin vencimiento.",
    "referencia":  "Modelización de NMD / core deposits; IRRBB (comportamiento de depósitos)",
    "orden":       20,
    "params": {"dataset": "", "campo_saldo": "saldo", "umbral_core": 0.50},
}


def control(df, datasets, params):
    import pandas as pd
    c_s = params.get("campo_saldo", "saldo")
    if df is None or c_s not in getattr(df, "columns", []):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de saldo '{c_s}'"}
    saldo = pd.to_numeric(df[c_s], errors="coerce").dropna()
    if len(saldo) < 2 or saldo.mean() <= 0:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": "serie de saldos insuficiente o promedio ≤ 0"}
    core = float(saldo.min() / saldo.mean())     # proporción estable (núcleo)
    umbral = float(params.get("umbral_core", 0.50))
    cumple = core >= umbral
    pct = round(100.0 * core, 2)
    return {"pct": pct, "decision": "Cumple" if cumple else "Observado",
            "diagnostico": (f"núcleo estable {core:.1%} (mín/promedio) vs umbral {umbral:.0%}; "
                            f"volatilidad {saldo.std()/saldo.mean():.1%}")}
