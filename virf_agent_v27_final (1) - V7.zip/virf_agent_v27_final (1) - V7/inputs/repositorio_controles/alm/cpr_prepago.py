"""Control conductual: razonabilidad de la tasa de prepago (CPR)."""

META = {
    "descripcion": "La tasa de prepago observada (CPR = prepagos / saldo) debe caer dentro de la banda esperada del modelo conductual.",
    "dimension":   "Conductual (prepago)",
    "evidencia":   "Serie de prepagos y saldos por periodo.",
    "referencia":  "Modelos de prepago (CPR/SMM); gobernanza de supuestos conductuales",
    "orden":       10,
    "params": {"dataset": "", "campo_prepago": "prepago", "campo_saldo": "saldo",
               "cpr_min": 0.05, "cpr_max": 0.40},
}


def control(df, datasets, params):
    import pandas as pd
    c_p, c_s = params.get("campo_prepago", "prepago"), params.get("campo_saldo", "saldo")
    if df is None or c_p not in getattr(df, "columns", []) or c_s not in df.columns:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas '{c_p}' y/o '{c_s}'"}
    prepago = pd.to_numeric(df[c_p], errors="coerce").fillna(0.0).sum()
    saldo = pd.to_numeric(df[c_s], errors="coerce").fillna(0.0).sum()
    if saldo <= 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "saldo total ≤ 0"}
    cpr = prepago / saldo
    lo, hi = float(params.get("cpr_min", 0.05)), float(params.get("cpr_max", 0.40))
    dentro = lo <= cpr <= hi
    # % de cumplimiento: 100 dentro de banda; fuera, cae según distancia relativa.
    if dentro:
        pct = 100.0
    else:
        ref = hi if cpr > hi else lo
        pct = round(max(0.0, 100.0 * (1 - abs(cpr - ref) / max(ref, 1e-9))), 2)
    return {"pct": pct, "decision": "Cumple" if dentro else "No cumple",
            "diagnostico": f"CPR observado {cpr:.2%} vs banda [{lo:.0%}, {hi:.0%}]"}
