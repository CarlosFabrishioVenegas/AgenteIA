"""Control ALM: sensibilidad del margen financiero (ΔNII) vs apetito."""

META = {
    "descripcion": "La caída del margen financiero (ΔNII) a 12 meses ante el shock de tasa no debe exceder el límite de apetito (% del NII base).",
    "dimension":   "Riesgo de tasa (ALM)",
    "evidencia":   "ΔNII por escenario de shock y NII base (proyectado a 12 meses).",
    "referencia":  "BCBS d368 — IRRBB, sensibilidad de ingresos (ΔNII)",
    "orden":       30,
    # ΔNII por escenario (negativo = caída). NII base: número en 'nii_base' o
    # columna 'campo_nii_base'.
    "params": {"dataset": "", "campo_delta_nii": "delta_nii",
               "nii_base": 0.0, "campo_nii_base": "nii_base",
               "limite_pct": 0.10},
}


def control(df, datasets, params):
    import pandas as pd
    c_nii = params.get("campo_delta_nii", "delta_nii")
    if df is None or c_nii not in getattr(df, "columns", []):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de ΔNII '{c_nii}'"}
    nii = pd.to_numeric(df[c_nii], errors="coerce").dropna()
    if len(nii) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin valores de ΔNII"}

    base = float(params.get("nii_base") or 0.0)
    if base <= 0:
        c_base = params.get("campo_nii_base", "nii_base")
        if c_base in df.columns:
            b = pd.to_numeric(df[c_base], errors="coerce").dropna()
            base = float(b.iloc[0]) if len(b) else 0.0
    if base <= 0:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": "falta el NII base (param 'nii_base' o columna)"}

    peor_caida = float(-nii.min()) if nii.min() < 0 else 0.0
    ratio = peor_caida / base
    limite = float(params.get("limite_pct", 0.10))
    decision = "Cumple" if ratio <= limite else "No cumple"
    pct = round(100.0 * (1 - min(ratio, 1.0)), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"máx. caída ΔNII {peor_caida:,.0f} = {ratio:.1%} del NII base "
                            f"(límite {limite:.0%})")}
