"""Control conductual: beta de traspaso del depósito dentro de [0, 1] y en banda razonable."""

META = {
    "descripcion": "El beta de traspaso (deposit beta = sensibilidad de la tasa del depósito a la tasa de mercado) debe estar en [0,1] y dentro de la banda esperada del modelo.",
    "dimension":   "Conductual (pricing de depósitos)",
    "evidencia":   "Beta estimado por producto/segmento de depósito.",
    "referencia":  "Modelos de pass-through de depósitos; gobernanza de supuestos conductuales",
    "orden":       30,
    "params": {"dataset": "", "campo_beta": "beta", "beta_min": 0.0, "beta_max": 1.0},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c_b = params.get("campo_beta", "beta")
    if c_b not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de beta '{c_b}'"}
    beta = pd.to_numeric(df[c_b], errors="coerce").dropna()
    n = int(len(beta))
    if n == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin valores de beta"}
    lo, hi = float(params.get("beta_min", 0.0)), float(params.get("beta_max", 1.0))
    fuera = int(((beta < lo) | (beta > hi)).sum())
    pct = round(100.0 * (n - fuera) / n, 2)
    decision = "Cumple" if fuera == 0 else ("Observado" if fuera <= 0.05 * n else "No cumple")
    return {"pct": pct, "decision": decision,
            "diagnostico": f"beta en [{float(beta.min()):.2f}, {float(beta.max()):.2f}] "
                           f"vs banda [{lo:.2f}, {hi:.2f}]; {fuera}/{n} fuera de banda"}
