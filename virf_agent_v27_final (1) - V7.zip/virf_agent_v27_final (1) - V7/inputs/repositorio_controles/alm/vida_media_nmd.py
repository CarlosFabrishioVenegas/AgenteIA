"""Control conductual: vida media de los depósitos sin vencimiento (NMD) bajo el tope."""

META = {
    "descripcion": "La vida media asumida para los depósitos sin vencimiento (NMD) debe ser positiva y no superar el tope prudencial (típicamente 5 años).",
    "dimension":   "Conductual (NMD)",
    "evidencia":   "Vida media (años) por producto/segmento de NMD, o el perfil de decaimiento del que se deriva.",
    "referencia":  "BCBS 368 — IRRBB, tope de 5 años a la vida media de los NMD",
    "orden":       20,
    "params": {"dataset": "", "campo_vida_media": "vida_media_anios", "cap_anios": 5.0},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c_vm = params.get("campo_vida_media", "vida_media_anios")
    if c_vm not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de vida media '{c_vm}'"}
    vm = pd.to_numeric(df[c_vm], errors="coerce").dropna()
    n = int(len(vm))
    if n == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin valores de vida media"}
    cap = float(params.get("cap_anios", 5.0))
    fuera = int(((vm > cap) | (vm <= 0)).sum())
    peor = float(vm.max())
    pct = round(100.0 * (n - fuera) / n, 2)
    decision = "Cumple" if fuera == 0 else ("Observado" if fuera <= 0.05 * n else "No cumple")
    return {"pct": pct, "decision": decision,
            "diagnostico": f"vida media máx {peor:.2f} años vs tope {cap:.1f}; "
                           f"{fuera}/{n} segmentos fuera de rango (>{cap:.0f} o <=0)"}
