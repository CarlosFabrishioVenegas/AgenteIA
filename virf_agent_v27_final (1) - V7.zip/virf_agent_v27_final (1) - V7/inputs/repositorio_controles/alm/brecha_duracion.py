"""Control ALM: brecha de duración — el descalce de duración activo-pasivo dentro de límite."""

META = {
    "descripcion": "La brecha de duración (duración del activo − duración del pasivo) debe mantenerse dentro del límite fijado por el ALCO.",
    "dimension":   "IRRBB (ALM)",
    "evidencia":   "Duración (o duración modificada) de activos y pasivos por fecha, o la brecha ya calculada.",
    "referencia":  "Gestión de riesgo de tasa — análisis de duración / duration gap",
    "orden":       30,
    "params": {"dataset": "", "campo_brecha": "brecha_duracion",
               "campo_dur_activo": "duracion_activo", "campo_dur_pasivo": "duracion_pasivo",
               "limite": 1.0},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c_b = params.get("campo_brecha", "brecha_duracion")
    if c_b in cols:
        brecha = pd.to_numeric(df[c_b], errors="coerce")
    else:
        c_a, c_p = params.get("campo_dur_activo", "duracion_activo"), params.get("campo_dur_pasivo", "duracion_pasivo")
        if c_a not in cols or c_p not in cols:
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": f"falta '{c_b}' o el par '{c_a}'/'{c_p}'"}
        brecha = pd.to_numeric(df[c_a], errors="coerce") - pd.to_numeric(df[c_p], errors="coerce")
    brecha = brecha.dropna()
    n = int(len(brecha))
    if n == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin valores de brecha"}
    limite = abs(float(params.get("limite", 1.0)))
    fuera = int((brecha.abs() > limite).sum())
    peor = float(brecha.abs().max())
    pct = round(100.0 * (n - fuera) / n, 2)
    decision = "Cumple" if fuera == 0 else ("Observado" if fuera <= 0.05 * n else "No cumple")
    return {"pct": pct, "decision": decision,
            "diagnostico": f"brecha máx |{peor:.2f}| años vs límite ±{limite:.2f}; "
                           f"{fuera}/{n} fechas fuera de límite"}
