"""Control ALM: cobertura de escenarios IRRBB — deben estar los 6 shocks supervisores."""

META = {
    "descripcion": "El análisis IRRBB debe cubrir los seis escenarios supervisores: paralelo ↑/↓, empinamiento, aplanamiento, tasa corta ↑/↓.",
    "dimension":   "IRRBB (ALM)",
    "evidencia":   "Columna de escenario con una fila por shock supervisor.",
    "referencia":  "BCBS 368 — IRRBB, seis escenarios de shock estándar",
    "orden":       20,
    "params": {"dataset": "", "campo_escenario": "escenario",
               "esperados": ["paralelo_up", "paralelo_down", "empinamiento",
                             "aplanamiento", "corto_up", "corto_down"]},
}


def control(df, datasets, params):
    cols = getattr(df, "columns", []) if df is not None else []
    c_esc = params.get("campo_escenario", "escenario")
    if c_esc not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de escenario '{c_esc}'"}
    presentes = {str(v).strip().lower() for v in df[c_esc].dropna().unique()}
    esperados = [str(e).strip().lower() for e in (params.get("esperados") or [])]
    if not esperados:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin lista de escenarios esperados"}
    faltan = [e for e in esperados if e not in presentes]
    n = len(esperados)
    pct = round(100.0 * (n - len(faltan)) / n, 2)
    if not faltan:
        decision = "Cumple"
    elif len(faltan) <= 1:
        decision = "Observado"
    else:
        decision = "No cumple"
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"{n - len(faltan)}/{n} escenarios presentes"
                            + (f"; faltan: {', '.join(faltan)}" if faltan else ""))}
