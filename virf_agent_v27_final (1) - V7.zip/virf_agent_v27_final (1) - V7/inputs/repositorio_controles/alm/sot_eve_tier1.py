"""Control ALM: Supervisory Outlier Test — máx |ΔEVE| entre escenarios <= 15% del Tier 1."""

META = {
    "descripcion": "El peor ΔEVE (en valor absoluto) entre los escenarios de shock no debe superar el 15% del capital de Nivel 1 (prueba del valor atípico supervisor).",
    "dimension":   "IRRBB (ALM)",
    "evidencia":   "ΔEVE por escenario de shock y el Tier 1 de referencia.",
    "referencia":  "BCBS 368 — IRRBB, Supervisory Outlier Test (umbral 15% Tier 1)",
    "orden":       21,
    # `tier1`: valor numérico, o nombre de columna si va en el dataset.
    "params": {"dataset": "", "campo_delta_eve": "delta_eve", "tier1": 0.0,
               "campo_tier1": "tier1", "umbral": 0.15},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c_eve = params.get("campo_delta_eve", "delta_eve")
    if c_eve not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de ΔEVE '{c_eve}'"}
    eve = pd.to_numeric(df[c_eve], errors="coerce").dropna()
    if eve.empty:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "ΔEVE sin valores"}

    tier1 = None
    try:
        tier1 = float(params.get("tier1") or 0.0)
    except (TypeError, ValueError):
        tier1 = 0.0
    if tier1 <= 0:
        c_t = params.get("campo_tier1", "tier1")
        if c_t in cols:
            serie_t = pd.to_numeric(df[c_t], errors="coerce").dropna()
            tier1 = float(serie_t.iloc[0]) if not serie_t.empty else 0.0
    if tier1 <= 0:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": "no se pudo determinar el Tier 1 (param `tier1` o columna)"}

    peor = float(eve.abs().max())
    ratio = peor / tier1
    umbral = float(params.get("umbral", 0.15))
    if ratio <= umbral:
        decision = "Cumple"
    elif ratio <= 1.2 * umbral:
        decision = "Observado"
    else:
        decision = "No cumple"
    pct = round(max(0.0, 100.0 * (1.0 - ratio)), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": f"peor |ΔEVE| {peor:,.0f} = {ratio:.1%} del Tier 1 "
                           f"(umbral {umbral:.0%}); {len(eve)} escenarios"}
