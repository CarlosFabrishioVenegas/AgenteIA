"""Control transversal: frescura — la fecha más reciente del data set no debe ser antigua."""

META = {
    "descripcion": "La observación más reciente del data set debe estar dentro de la ventana máxima de antigüedad.",
    "dimension":   "Calidad del dato (transversal)",
    "evidencia":   "Data set con una columna de fecha.",
    "referencia":  "BCBS 239 — oportunidad (timeliness) de los datos de riesgo",
    "orden":       92,
    "params":      {"dataset": "", "campo_fecha": "fecha", "dias_max": 90},
}


def control(df, datasets, params):
    import pandas as pd
    if df is None or getattr(df, "empty", True):
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    col = params.get("campo_fecha", "fecha")
    if col not in getattr(df, "columns", []):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"no hay columna de fecha '{col}'"}
    fechas = pd.to_datetime(df[col], errors="coerce").dropna()
    if fechas.empty:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"'{col}' no tiene fechas parseables"}
    ultima = fechas.max()
    dias = int((pd.Timestamp.now().normalize() - ultima.normalize()).days)
    dias_max = int(params.get("dias_max", 90))
    if dias <= dias_max:
        decision = "Cumple"
    elif dias <= 2 * dias_max:
        decision = "Observado"
    else:
        decision = "No cumple"
    # % = qué tan dentro de ventana está (100 recién actualizado, 0 al doble de la ventana).
    pct = round(max(0.0, 100.0 * (1.0 - dias / (2.0 * dias_max))), 2) if dias_max else None
    return {"pct": pct, "decision": decision,
            "diagnostico": f"última fecha {ultima.date()} ({dias} días de antigüedad; máx {dias_max})"}
