"""Control transversal: columnas constantes — detecta campos sin variación (posible dato muerto)."""

META = {
    "descripcion": "Ninguna columna relevante debería tener un único valor constante en todas las filas (indicio de campo mal poblado o congelado).",
    "dimension":   "Calidad del dato (transversal)",
    "evidencia":   "El data set tal cual se usa en el modelo.",
    "referencia":  "BCBS 239 — integridad; validación de razonabilidad de campos",
    "orden":       94,
    "params":      {"dataset": ""},
}


def control(df, datasets, params):
    if df is None or getattr(df, "empty", True):
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    cols = list(getattr(df, "columns", []))
    if not cols:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin columnas"}
    constantes = []
    for c in cols:
        serie = df[c].dropna()
        # Una columna toda nula NO cuenta aquí (la cubre el control de completitud).
        if len(serie) > 0 and serie.nunique(dropna=True) <= 1:
            constantes.append(str(c))
    n = len(cols)
    pct = round(100.0 * (n - len(constantes)) / n, 2)
    if not constantes:
        decision = "Cumple"
    elif len(constantes) <= max(1, n // 10):
        decision = "Observado"
    else:
        decision = "No cumple"
    muestra = ", ".join(constantes[:6]) + ("…" if len(constantes) > 6 else "")
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"{len(constantes)}/{n} columnas constantes"
                            + (f": {muestra}" if constantes else ""))}
