"""Control transversal: completitud — ninguna columna debe superar el umbral de faltantes."""

META = {
    "descripcion": "Ninguna columna del data set debe superar el umbral de valores faltantes (nulos/NaN).",
    "dimension":   "Calidad del dato (transversal)",
    "evidencia":   "El data set tal cual se usa en el modelo.",
    "referencia":  "BCBS 239 — completitud e integridad de los datos de riesgo",
    "orden":       90,
    "params":      {"dataset": "", "umbral_nulos": 0.05},
}


def control(df, datasets, params):
    import pandas as pd
    if df is None or getattr(df, "empty", True):
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    umbral = float(params.get("umbral_nulos", 0.05))
    n = len(df)
    tasas = (df.isna().sum() / n) if n else pd.Series(dtype=float)
    if tasas.empty:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin columnas"}
    peor_col = tasas.idxmax()
    peor = float(tasas.max())
    pct = round(100.0 * (1.0 - peor), 2)          # completitud de la peor columna
    if peor <= umbral:
        decision = "Cumple"
    elif peor <= 2 * umbral:
        decision = "Observado"
    else:
        decision = "No cumple"
    return {"pct": pct, "decision": decision,
            "diagnostico": f"peor columna '{peor_col}' con {peor:.1%} de faltantes "
                           f"(umbral {umbral:.1%}) sobre {n} filas"}
