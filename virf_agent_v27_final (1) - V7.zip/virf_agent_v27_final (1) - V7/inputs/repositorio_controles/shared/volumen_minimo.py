"""Control transversal: volumen mínimo — suficientes observaciones para que el modelo sea válido."""

META = {
    "descripcion": "El data set debe tener al menos el número mínimo de observaciones para sostener el análisis (p. ej. ~250 para backtesting).",
    "dimension":   "Calidad del dato (transversal)",
    "evidencia":   "El data set tal cual se usa en el modelo.",
    "referencia":  "Buenas prácticas de validación — suficiencia muestral",
    "orden":       93,
    "params":      {"dataset": "", "min_filas": 250},
}


def control(df, datasets, params):
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    n = int(len(df))
    minimo = int(params.get("min_filas", 250))
    if minimo <= 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "min_filas no válido"}
    pct = round(min(100.0, 100.0 * n / minimo), 2)
    if n >= minimo:
        decision = "Cumple"
    elif n >= 0.6 * minimo:
        decision = "Observado"
    else:
        decision = "No cumple"
    return {"pct": pct, "decision": decision,
            "diagnostico": f"{n} filas frente al mínimo de {minimo}"}
