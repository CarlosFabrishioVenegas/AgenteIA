"""Control transversal: duplicados — la tasa de registros repetidos debe ser baja."""

META = {
    "descripcion": "La proporción de registros duplicados (fila completa, o por clave si se indica) debe estar por debajo del umbral.",
    "dimension":   "Calidad del dato (transversal)",
    "evidencia":   "El data set tal cual se usa en el modelo.",
    "referencia":  "BCBS 239 — exactitud e integridad; deduplicación",
    "orden":       91,
    # `clave`: columna(s) separadas por coma que definen la unicidad. Vacío = fila completa.
    "params":      {"dataset": "", "clave": "", "umbral": 0.0},
}


def control(df, datasets, params):
    if df is None or getattr(df, "empty", True):
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    n = len(df)
    clave = str(params.get("clave", "")).strip()
    if clave:
        cols = [c.strip() for c in clave.split(",") if c.strip()]
        faltan = [c for c in cols if c not in df.columns]
        if faltan:
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": f"no están las columnas clave: {', '.join(faltan)}"}
        dup = int(df.duplicated(subset=cols).sum())
        alcance = f"clave ({', '.join(cols)})"
    else:
        dup = int(df.duplicated().sum())
        alcance = "fila completa"

    tasa = dup / n if n else 0.0
    umbral = float(params.get("umbral", 0.0))
    pct = round(100.0 * (1.0 - tasa), 2)
    decision = "Cumple" if tasa <= umbral else ("Observado" if tasa <= max(umbral, 0.01) else "No cumple")
    return {"pct": pct, "decision": decision,
            "diagnostico": f"{dup}/{n} duplicados por {alcance} (tasa {tasa:.2%}, umbral {umbral:.2%})"}
