"""Control LaR: horizonte de supervivencia por buckets de liquidez."""

META = {
    "descripcion": "La posición de liquidez ACUMULADA (entradas − salidas) no debe caer bajo el colchón en ningún bucket.",
    "dimension":   "Liquidez (LaR)",
    "evidencia":   "Escalonamiento de flujos por bucket temporal (maturity ladder).",
    "referencia":  "BCBS 238 — survival horizon / maturity ladder",
    "orden":       10,
    "params": {"dataset": "", "campo_monto": "flujo_neto", "campo_bucket": "bucket",
               "orden_buckets": "0-7d, 8-30d, 31-90d, 91-180d, 181-365d, >365d",
               "buffer": 0.0},
}


def control(df, datasets, params):
    import pandas as pd
    c_m, c_b = params.get("campo_monto", "flujo_neto"), params.get("campo_bucket", "bucket")
    if df is None or c_m not in getattr(df, "columns", []) or c_b not in df.columns:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas '{c_m}' y/o '{c_b}'"}
    monto = pd.to_numeric(df[c_m], errors="coerce").fillna(0.0)
    neto = pd.DataFrame({"b": df[c_b].astype(str), "m": monto}).groupby("b")["m"].sum()

    orden = [x.strip() for x in str(params.get("orden_buckets", "")).split(",") if x.strip()]
    if orden:
        neto = neto.reindex([b for b in orden if b in neto.index])
    else:
        neto = neto.sort_index()
    acumulado = neto.cumsum()
    buffer = float(params.get("buffer", 0.0) or 0.0)

    bajo = acumulado[acumulado < buffer]
    horizonte = next((b for b, v in acumulado.items() if v < buffer), None)
    n = int(len(acumulado))
    pct = round(100.0 * (1 - len(bajo) / n), 2) if n else None
    if len(bajo) == 0:
        return {"pct": pct, "decision": "Cumple",
                "diagnostico": f"posición ≥ colchón en los {n} buckets"}
    return {"pct": pct, "decision": "No cumple",
            "diagnostico": f"posición bajo el colchón en {len(bajo)}/{n} buckets; sobrevive hasta '{horizonte}'"}
