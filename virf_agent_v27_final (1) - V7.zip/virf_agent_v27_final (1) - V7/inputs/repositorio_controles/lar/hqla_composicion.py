"""Control LaR: composición de HQLA — topes de activos de Nivel 2 (<=40%) y 2B (<=15%)."""

META = {
    "descripcion": "Los activos líquidos de Nivel 2 no pueden superar el 40% del HQLA total, y los de Nivel 2B el 15% (tras haircuts).",
    "dimension":   "Liquidez (LaR)",
    "evidencia":   "HQLA desglosado por nivel (1, 2A, 2B) por fecha.",
    "referencia":  "BCBS 238 — composición del HQLA (topes 40% Nivel 2, 15% Nivel 2B)",
    "orden":       21,
    "params": {"dataset": "", "campo_l1": "hqla_l1", "campo_l2a": "hqla_l2a",
               "campo_l2b": "hqla_l2b", "cap_l2": 0.40, "cap_l2b": 0.15},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c1, c2a, c2b = (params.get("campo_l1", "hqla_l1"),
                    params.get("campo_l2a", "hqla_l2a"),
                    params.get("campo_l2b", "hqla_l2b"))
    if c1 not in cols or c2a not in cols or c2b not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas de HQLA por nivel ('{c1}','{c2a}','{c2b}')"}
    l1 = pd.to_numeric(df[c1], errors="coerce").fillna(0.0)
    l2a = pd.to_numeric(df[c2a], errors="coerce").fillna(0.0)
    l2b = pd.to_numeric(df[c2b], errors="coerce").fillna(0.0)
    total = l1 + l2a + l2b
    m = total > 0
    if int(m.sum()) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "HQLA total no positivo"}
    cap_l2 = float(params.get("cap_l2", 0.40))
    cap_l2b = float(params.get("cap_l2b", 0.15))
    share_l2 = (l2a + l2b)[m] / total[m]
    share_l2b = l2b[m] / total[m]
    n = int(m.sum())
    incumplen = int(((share_l2 > cap_l2) | (share_l2b > cap_l2b)).sum())
    pct = round(100.0 * (n - incumplen) / n, 2)
    decision = "Cumple" if incumplen == 0 else ("Observado" if incumplen <= 0.05 * n else "No cumple")
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"Nivel 2 máx {float(share_l2.max()):.0%} (cap {cap_l2:.0%}), "
                            f"Nivel 2B máx {float(share_l2b.max()):.0%} (cap {cap_l2b:.0%}); "
                            f"{incumplen}/{n} fechas fuera de tope")}
