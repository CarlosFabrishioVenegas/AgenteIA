"""Control LaR: concentración de fondeo — ningún proveedor debe superar el umbral de dependencia."""

META = {
    "descripcion": "La financiación no debe depender en exceso de una sola contraparte: la mayor cuota de fondeo por proveedor debe estar por debajo del umbral.",
    "dimension":   "Liquidez (LaR)",
    "evidencia":   "Fondeo por contraparte/proveedor (una fila por proveedor, o columna de proveedor + monto).",
    "referencia":  "BCBS 238 — herramientas de seguimiento: concentración de la financiación",
    "orden":       30,
    "params": {"dataset": "", "campo_proveedor": "proveedor", "campo_monto": "monto",
               "umbral": 0.25},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c_prov, c_monto = params.get("campo_proveedor", "proveedor"), params.get("campo_monto", "monto")
    if c_prov not in cols or c_monto not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas '{c_prov}'/'{c_monto}'"}
    montos = pd.to_numeric(df[c_monto], errors="coerce").fillna(0.0)
    total = float(montos.sum())
    if total <= 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "fondeo total no positivo"}
    por_prov = montos.groupby(df[c_prov]).sum().sort_values(ascending=False)
    top_prov = por_prov.index[0]
    top_share = float(por_prov.iloc[0]) / total
    umbral = float(params.get("umbral", 0.25))
    if top_share <= umbral:
        decision = "Cumple"
    elif top_share <= 1.5 * umbral:
        decision = "Observado"
    else:
        decision = "No cumple"
    pct = round(100.0 * (1.0 - top_share), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": f"mayor proveedor '{top_prov}' concentra {top_share:.1%} "
                           f"del fondeo (umbral {umbral:.0%}); {len(por_prov)} proveedores"}
