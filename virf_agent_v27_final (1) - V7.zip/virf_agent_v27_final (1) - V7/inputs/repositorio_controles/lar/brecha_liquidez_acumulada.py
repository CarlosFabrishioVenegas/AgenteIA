"""Control LaR: brecha de liquidez acumulada — el flujo neto acumulado no debe volverse negativo."""

META = {
    "descripcion": "La brecha de liquidez acumulada (entradas−salidas, sumada por banda temporal en orden) no debe caer por debajo de cero dentro del horizonte.",
    "dimension":   "Liquidez (LaR)",
    "evidencia":   "Flujos por banda temporal: entradas y salidas (o la brecha neta ya calculada), ordenados por plazo.",
    "referencia":  "Análisis de brechas de liquidez (maturity ladder)",
    "orden":       40,
    "params": {"dataset": "", "campo_brecha": "brecha", "campo_entradas": "entradas",
               "campo_salidas": "salidas", "campo_orden": "", "tolerancia": 0.0},
}


def control(df, datasets, params):
    import pandas as pd
    if df is None or getattr(df, "empty", True):
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    d = df
    orden = params.get("campo_orden", "")
    if orden and orden in d.columns:
        d = d.sort_values(orden)
    cols = getattr(d, "columns", [])
    c_b = params.get("campo_brecha", "brecha")
    if c_b in cols:
        brecha = pd.to_numeric(d[c_b], errors="coerce").fillna(0.0)
    else:
        c_e, c_s = params.get("campo_entradas", "entradas"), params.get("campo_salidas", "salidas")
        if c_e not in cols or c_s not in cols:
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": f"falta '{c_b}' o el par '{c_e}'/'{c_s}'"}
        brecha = (pd.to_numeric(d[c_e], errors="coerce").fillna(0.0)
                  - pd.to_numeric(d[c_s], errors="coerce").fillna(0.0))
    acumulada = brecha.cumsum()
    n = int(len(acumulada))
    if n == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin bandas"}
    tol = float(params.get("tolerancia", 0.0))
    negativas = int((acumulada < -abs(tol)).sum())
    peor = float(acumulada.min())
    pct = round(100.0 * (n - negativas) / n, 2)
    decision = "Cumple" if negativas == 0 else ("Observado" if negativas <= 1 else "No cumple")
    return {"pct": pct, "decision": decision,
            "diagnostico": f"brecha acumulada mínima {peor:,.0f}; {negativas}/{n} bandas en negativo"}
