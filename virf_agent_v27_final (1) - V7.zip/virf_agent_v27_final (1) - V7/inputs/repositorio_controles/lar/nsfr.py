"""Control LaR: Ratio de Fondeo Estable Neto (NSFR) >= 100%."""

META = {
    "descripcion": "El NSFR (fondeo estable disponible / requerido) debe ser >= 100%.",
    "dimension":   "Liquidez (LaR)",
    "evidencia":   "ASF (fondeo estable disponible) y RSF (requerido) por fecha, o el NSFR ya calculado.",
    "referencia":  "BCBS 295 — Net Stable Funding Ratio (mínimo 100%)",
    "orden":       30,
    "params": {"dataset": "", "campo_nsfr": "nsfr",
               "campo_asf": "asf", "campo_rsf": "rsf", "minimo": 1.0},
}


def control(df, datasets, params):
    import pandas as pd
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    cols = getattr(df, "columns", [])
    c_nsfr = params.get("campo_nsfr", "nsfr")
    if c_nsfr in cols:
        ratio = pd.to_numeric(df[c_nsfr], errors="coerce")
    else:
        c_a, c_r = params.get("campo_asf", "asf"), params.get("campo_rsf", "rsf")
        if c_a not in cols or c_r not in cols:
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": f"falta '{c_nsfr}' o el par '{c_a}'/'{c_r}'"}
        asf = pd.to_numeric(df[c_a], errors="coerce")
        rsf = pd.to_numeric(df[c_r], errors="coerce").replace(0, pd.NA)
        ratio = asf / rsf

    ratio = ratio.dropna()
    n = int(len(ratio))
    if n == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin valores de NSFR"}
    minimo = float(params.get("minimo", 1.0))
    incumplen = int((ratio < minimo).sum())
    peor = float(ratio.min())
    pct = round(100.0 * (n - incumplen) / n, 2)
    decision = "Cumple" if incumplen == 0 else "No cumple"
    return {"pct": pct, "decision": decision,
            "diagnostico": f"NSFR mínimo {peor:.0%} vs umbral {minimo:.0%}; {incumplen}/{n} periodos por debajo"}
