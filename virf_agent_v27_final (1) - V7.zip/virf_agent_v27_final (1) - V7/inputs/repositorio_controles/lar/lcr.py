"""Control LaR: Ratio de Cobertura de Liquidez (LCR) >= 100%."""

META = {
    "descripcion": "El LCR (HQLA / salidas netas de 30 días) debe ser >= 100% en todo periodo reportado.",
    "dimension":   "Liquidez (LaR)",
    "evidencia":   "HQLA y salidas netas de efectivo a 30 días por fecha (o el LCR ya calculado).",
    "referencia":  "BCBS 238 — Liquidity Coverage Ratio (mínimo 100%)",
    "orden":       20,
    # Da el LCR ya calculado (forma ratio: 1.0 = 100%) o los componentes.
    "params": {"dataset": "", "campo_lcr": "lcr",
               "campo_hqla": "hqla", "campo_salidas": "salidas_netas",
               "minimo": 1.0},
}


def control(df, datasets, params):
    import pandas as pd
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    cols = getattr(df, "columns", [])
    c_lcr = params.get("campo_lcr", "lcr")
    if c_lcr in cols:
        ratio = pd.to_numeric(df[c_lcr], errors="coerce")
    else:
        c_h, c_s = params.get("campo_hqla", "hqla"), params.get("campo_salidas", "salidas_netas")
        if c_h not in cols or c_s not in cols:
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": f"falta '{c_lcr}' o el par '{c_h}'/'{c_s}'"}
        hqla = pd.to_numeric(df[c_h], errors="coerce")
        sal = pd.to_numeric(df[c_s], errors="coerce").replace(0, pd.NA)
        ratio = hqla / sal

    ratio = ratio.dropna()
    n = int(len(ratio))
    if n == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin valores de LCR"}
    minimo = float(params.get("minimo", 1.0))
    incumplen = int((ratio < minimo).sum())
    peor = float(ratio.min())
    pct = round(100.0 * (n - incumplen) / n, 2)
    decision = "Cumple" if incumplen == 0 else "No cumple"
    return {"pct": pct, "decision": decision,
            "diagnostico": f"LCR mínimo {peor:.0%} vs umbral {minimo:.0%}; {incumplen}/{n} periodos por debajo"}
