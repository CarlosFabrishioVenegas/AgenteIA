# Repositorio de controles de datos (funciones Python por dominio)

Repositorio **especializado** de controles escritos como **funciones Python**.
Cuando el modelo activo tiene un tipo (dominio), el notebook entregable toma los
controles de la carpeta de ese dominio y produce un `.ipynb` **específico** —no
genérico— para ese modelo.

## Estructura (una carpeta por DOMINIO real)

```
inputs/repositorio_controles/
  var/           TRADING — modelos de mercado (VaR)
                 kupiec · christoffersen · backtesting_excedencias · var_negativos
                 · semaforo_basilea · monotonia_niveles_var · severidad_excepciones
  conductuales/  ALM — modelos conductuales (prepago MCP, supervivencia/retiro MCR)
                 e IRRBB. cpr_prepago · decaimiento_nmd · vida_media_nmd · beta_deposito
                 · backtesting_prepago · gap_reprecios · delta_eve · delta_nii
                 · sot_eve_tier1 · escenarios_irrbb_completos · brecha_duracion
  lar/           LIQUIDEZ — LaR, RCL (≈LCR), RFNE (≈NSFR)
                 lcr · nsfr · horizonte_supervivencia · hqla_composicion
                 · concentracion_fondeo · brecha_liquidez_acumulada
  shared/        transversales, se añaden a CUALQUIER dominio
                 completitud_datos · duplicados_registros · frescura_datos
                 · volumen_minimo · columnas_constantes
```

**Taxonomía de modelos → dominio → carpeta:**

| Familia (padre) | Modelos hijos | Dominio / carpeta |
|---|---|---|
| **Trading** | VaR (riesgo de mercado) | `var/` |
| **ALM** *(padre)* | conductuales de prepago (MCP), de supervivencia/retiro (MCR), IRRBB | `conductuales/` |
| **Liquidez** | LaR, RCL (cobertura ≈ LCR), RFNE (financiación estable ≈ NSFR) | `lar/` |

> **ALM es el dominio PADRE**: de él nacen los modelos conductuales hijos (prepago
> MCP, supervivencia/retiro MCR, IRRBB). ALM y «conductuales» son el mismo dominio
> y van juntos; el identificador interno se llama `conductuales` para alinearse con
> el RAG. El tipo de modelo que eliges en Configuración decide la carpeta;
> `carpeta_de_dominio` tolera mayúsculas y sinónimos (`alm`, `mcp`, `mcr`,
> `prepago`, `supervivencia`, `rcl`, `lcr`, `rfne`, `nsfr`, `trading`…).

## Contrato de un control

Cada `.py` define un `META` y una función `control`:

```python
META = {
    "descripcion": "qué verifica",       # → 'Control Esperado'
    "dimension":   "Backtesting (VaR)",   # → 'Dimensión'
    "evidencia":   "qué soporte pedir",   # → 'Control o Evidencia requerida'
    "referencia":  "cita a literatura",   # → 'Referencia en el entregable'
    "orden":       20,                    # (opc.) orden en el notebook
    "params":      {"campo_var": "var_99"},  # columnas/umbrales editables
}

def control(df, datasets, params):
    # df = dataset principal; datasets = {nombre: DataFrame}; params = META['params']
    return {
        "pct": 99.4,           # % de cumplimiento (o None si no evaluable)
        "decision": "Cumple",  # Cumple | Observado | No cumple | No evaluable | Revisión manual
        "diagnostico": "3 excepciones en 500 obs...",
    }
```

## Qué genera el notebook

Una celda por control que **embebe el código real** del `.py`, lo ejecuta e
imprime:

```
>>>> C01: Backtesting de VaR (Kupiec POF)...
Control   | Resultado      | % cumplimiento  | Diagnóstico
C01       | No cumple      | 94.40%          | 28 excepciones en 500 obs...
```

y una celda final que consolida el **cuadro de 8 columnas**:

`Control · Dimensión · Control Esperado · % De cumplimiento del data set ·
Diagnóstico · Decisión · Control o Evidencia requerida · Referencia en el
entregable`.

## Añadir un control

1. Crea un `.py` en la carpeta del dominio (copia uno existente).
2. Ajusta `META` y la función `control`.
3. Vuelve a **descargar el notebook**: tu control ya aparece como una celda.

> Los `params` (nombres de columna, umbrales) son editables **dentro del
> notebook** también: si tu dataset usa otros nombres, cámbialos ahí y re-ejecuta.
