"""Control VaR: severidad de las excepciones — cuánto excede la pérdida al VaR cuando lo rompe."""

META = {
    "descripcion": "Cuando la pérdida supera el VaR, el exceso medio (pérdida−VaR)/VaR no debería ser grande: excesos severos apuntan a colas mal capturadas.",
    "dimension":   "Backtesting (VaR)",
    "evidencia":   "Serie diaria de P&L y VaR.",
    "referencia":  "Backtesting basado en magnitud (loss-function / severidad de excepciones)",
    "orden":       22,
    "params": {"dataset": "", "campo_pnl": "pnl", "campo_var": "var_99",
               "convencion": "perdida_positiva", "exceso_max": 0.50},
}


def control(df, datasets, params):
    import pandas as pd
    cols = getattr(df, "columns", []) if df is not None else []
    c_pnl, c_var = params.get("campo_pnl", "pnl"), params.get("campo_var", "var_99")
    if c_pnl not in cols or c_var not in cols:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"faltan columnas '{c_pnl}'/'{c_var}'"}
    pnl = pd.to_numeric(df[c_pnl], errors="coerce")
    var = pd.to_numeric(df[c_var], errors="coerce").abs()
    m = pnl.notna() & var.notna() & (var > 0)
    pnl, var = pnl[m], var[m]
    if len(pnl) == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin observaciones válidas"}
    # Pérdida como número positivo según convención.
    perdida = -pnl if str(params.get("convencion", "perdida_positiva")).lower() == "pnl_negativo" else pnl
    breach = perdida > var
    n_b = int(breach.sum())
    if n_b == 0:
        return {"pct": 100.0, "decision": "Cumple",
                "diagnostico": "no hubo excepciones: sin exceso que medir"}
    exceso = ((perdida[breach] - var[breach]) / var[breach])
    medio = float(exceso.mean())
    peor = float(exceso.max())
    tope = float(params.get("exceso_max", 0.50))
    if medio <= tope:
        decision = "Cumple"
    elif medio <= 2 * tope:
        decision = "Observado"
    else:
        decision = "No cumple"
    pct = round(max(0.0, 100.0 * (1.0 - medio)), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": f"{n_b} excepciones; exceso medio {medio:.1%}, peor {peor:.1%} "
                           f"(tope {tope:.0%})"}
