"""Control VaR: test de independencia de excepciones (Christoffersen)."""

META = {
    "descripcion": "Independencia de las excepciones (Christoffersen): las excepciones no deben agruparse (clustering) en el tiempo.",
    "dimension":   "Backtesting (VaR)",
    "evidencia":   "Serie diaria ORDENADA de excepciones (o P&L y VaR) de la ventana de backtesting.",
    "referencia":  "Christoffersen (1998), Evaluating Interval Forecasts",
    "orden":       25,
    "params": {"dataset": "", "significancia": 0.95,
               "campo_excepcion": "excepcion",
               "campo_pnl": "pnl", "campo_var": "var_99",
               "convencion": "perdida_positiva"},
}

_CHI2_1GL = {0.90: 2.706, 0.95: 3.841, 0.99: 6.635}


def control(df, datasets, params):
    import math
    import pandas as pd
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    chi2 = _CHI2_1GL.get(round(float(params.get("significancia", 0.95)), 2), 3.841)

    col_exc = params.get("campo_excepcion")
    if col_exc and col_exc in df.columns:
        exc = (pd.to_numeric(df[col_exc], errors="coerce").fillna(0) != 0).astype(int)
    else:
        c_pnl, c_var = params.get("campo_pnl"), params.get("campo_var")
        if not (c_pnl in getattr(df, "columns", []) and c_var in getattr(df, "columns", [])):
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": "faltan columnas de excepción o par P&L/VaR"}
        pnl = pd.to_numeric(df[c_pnl], errors="coerce")
        var = pd.to_numeric(df[c_var], errors="coerce")
        m = pnl.notna() & var.notna()
        if str(params.get("convencion", "perdida_positiva")).lower() == "pnl_negativo":
            exc = (pnl[m] < -var[m].abs()).astype(int)
        else:
            exc = (pnl[m] > var[m].abs()).astype(int)

    s = exc.tolist()
    N = len(s)
    if N < 2:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "serie demasiado corta"}

    # Conteo de transiciones i→j entre días consecutivos.
    n = {(0, 0): 0, (0, 1): 0, (1, 0): 0, (1, 1): 0}
    for a, b in zip(s[:-1], s[1:]):
        n[(a, b)] += 1
    n00, n01, n10, n11 = n[(0, 0)], n[(0, 1)], n[(1, 0)], n[(1, 1)]

    pi01 = n01 / (n00 + n01) if (n00 + n01) else 0.0
    pi11 = n11 / (n10 + n11) if (n10 + n11) else 0.0
    pi = (n01 + n11) / (n00 + n01 + n10 + n11) if N > 1 else 0.0

    def _term(cnt, p):
        return cnt * math.log(p) if (cnt > 0 and p > 0) else 0.0

    ll_ind = (_term(n00, 1 - pi01) + _term(n01, pi01)
              + _term(n10, 1 - pi11) + _term(n11, pi11))
    ll_null = _term(n00 + n10, 1 - pi) + _term(n01 + n11, pi)
    lr = 2.0 * (ll_ind - ll_null)
    rechaza = lr > chi2
    decision = "No cumple" if rechaza else "Cumple"
    # % de cumplimiento aquí = 100 si independiente; si se rechaza, baja con el clustering.
    pct = 100.0 if not rechaza else round(max(0.0, 100.0 * chi2 / lr), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"LR_ind={lr:.2f} vs χ²={chi2:.2f}; π01={pi01:.2%}, π11={pi11:.2%} "
                            f"→ excepciones {'AGRUPADAS' if rechaza else 'independientes'} "
                            f"(n11={n11})")}
