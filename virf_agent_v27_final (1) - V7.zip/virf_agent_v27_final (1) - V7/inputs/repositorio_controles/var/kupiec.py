"""Control VaR: backtesting por el test de Kupiec (Proportion of Failures)."""

META = {
    "descripcion": "Backtesting de VaR (Kupiec POF): la tasa de excepciones debe ser consistente con 1 − nivel de confianza.",
    "dimension":   "Backtesting (VaR)",
    "evidencia":   "Serie diaria de P&L y VaR (o una columna 0/1 de excepciones), mín. ~250 obs.",
    "referencia":  "Kupiec (1995); Basilea — backtesting",
    "orden":       20,
    # Da la columna de excepciones 0/1, o el par pnl+var y la convención de signo.
    "params": {"dataset": "", "nivel_confianza": 0.99, "significancia": 0.95,
               "campo_excepcion": "excepcion",
               "campo_pnl": "pnl", "campo_var": "var_99",
               "convencion": "perdida_positiva"},
}

_CHI2_1GL = {0.90: 2.706, 0.95: 3.841, 0.99: 6.635}


def control(df, datasets, params):
    import math
    import pandas as pd
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}

    nivel = float(params.get("nivel_confianza", 0.99))
    p_esp = 1.0 - nivel
    chi2 = _CHI2_1GL.get(round(float(params.get("significancia", 0.95)), 2), 3.841)

    col_exc = params.get("campo_excepcion")
    if col_exc and col_exc in df.columns:
        exc = (pd.to_numeric(df[col_exc], errors="coerce").fillna(0) != 0).astype(int)
    else:
        c_pnl, c_var = params.get("campo_pnl"), params.get("campo_var")
        if not (c_pnl in getattr(df, "columns", []) and c_var in getattr(df, "columns", [])):
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": f"faltan columnas: excepción '{col_exc}' o par '{c_pnl}'/'{c_var}'"}
        pnl = pd.to_numeric(df[c_pnl], errors="coerce")
        var = pd.to_numeric(df[c_var], errors="coerce")
        m = pnl.notna() & var.notna()
        if str(params.get("convencion", "perdida_positiva")).lower() == "pnl_negativo":
            exc = (pnl[m] < -var[m].abs()).astype(int)
        else:
            exc = (pnl[m] > var[m].abs()).astype(int)

    N, x = int(exc.shape[0]), int(exc.sum())
    if N == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin observaciones"}
    tasa = x / N

    def _ll(pi):
        if pi <= 0:
            return 0.0 if x == 0 else float("-inf")
        if pi >= 1:
            return 0.0 if x == N else float("-inf")
        return (N - x) * math.log(1 - pi) + x * math.log(pi)

    lr = 2.0 * (_ll(tasa) - _ll(p_esp)) if math.isfinite(_ll(p_esp)) else float("inf")
    rechaza = lr > chi2
    decision = "No cumple" if rechaza else "Cumple"
    pct = round(100.0 * (1 - tasa), 2)   # % de días dentro del VaR
    return {"pct": pct, "decision": decision,
            "diagnostico": (f"{x} excepciones en {N} obs (tasa {tasa:.2%}; esperada "
                            f"{p_esp:.2%}). LR_POF={lr:.2f} vs χ²={chi2:.2f} → "
                            f"{'RECHAZADO' if rechaza else 'no rechazado'}")}
