"""Control VaR: monotonía por nivel de confianza — |VaR 99%| >= |VaR 95%| >= |VaR 90%|."""

META = {
    "descripcion": "El VaR debe crecer en magnitud con el nivel de confianza: |VaR99| >= |VaR95| >= |VaR90| en cada fecha. Una inversión delata un error de cómputo.",
    "dimension":   "Coherencia metodológica (VaR)",
    "evidencia":   "Columnas de VaR a distintos niveles (p. ej. var_99, var_95, var_90).",
    "referencia":  "Propiedad de monotonía del VaR respecto al nivel de confianza",
    "orden":       30,
    # Columnas ordenadas de MAYOR a MENOR confianza.
    "params": {"dataset": "", "campos_var": ["var_99", "var_95", "var_90"],
               "tolerancia": 0.0},
}


def control(df, datasets, params):
    import pandas as pd
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    cols = [c for c in (params.get("campos_var") or []) if c in getattr(df, "columns", [])]
    if len(cols) < 2:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"se necesitan >=2 columnas de VaR; presentes: {cols or 'ninguna'}"}
    mat = df[cols].apply(lambda s: pd.to_numeric(s, errors="coerce")).abs()
    mat = mat.dropna()
    n = int(len(mat))
    if n == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin filas comparables"}
    tol = float(params.get("tolerancia", 0.0))
    # Cada columna debe ser >= la siguiente (mayor confianza primero), con tolerancia.
    ok = pd.Series(True, index=mat.index)
    for a, b in zip(cols, cols[1:]):
        ok &= (mat[a] >= mat[b] * (1.0 - tol))
    incumplen = int((~ok).sum())
    pct = round(100.0 * (n - incumplen) / n, 2)
    decision = "Cumple" if incumplen == 0 else ("Observado" if incumplen <= 0.01 * n else "No cumple")
    return {"pct": pct, "decision": decision,
            "diagnostico": f"{incumplen}/{n} fechas con inversión de monotonía "
                           f"en {' >= '.join(cols)}"}
