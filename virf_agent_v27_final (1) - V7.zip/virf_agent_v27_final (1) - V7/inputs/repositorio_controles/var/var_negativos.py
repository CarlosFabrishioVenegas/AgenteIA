"""Control VaR: el VaR estimado debe ser estrictamente positivo."""

META = {
    "descripcion": "El VaR estimado debe ser estrictamente positivo (un VaR ≤ 0 es un error de cálculo o de signo).",
    "dimension":   "Validez (VaR)",
    "evidencia":   "Serie de VaR estimado por fecha.",
    "referencia":  "SR 11-7 — razonabilidad de las salidas del modelo",
    "orden":       10,
    "params":      {"dataset": "", "campo_var": "var_99"},
}


def control(df, datasets, params):
    import pandas as pd
    col = params.get("campo_var", "var_99")
    if df is None or col not in getattr(df, "columns", []):
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"falta la columna de VaR '{col}' en el dataset"}
    v = pd.to_numeric(df[col], errors="coerce")
    n = int(v.notna().sum())
    if n == 0:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": f"'{col}' no tiene valores numéricos"}
    negativos = int((v <= 0).sum())
    pct = round(100.0 * (1 - negativos / n), 2)
    decision = "Cumple" if negativos == 0 else "No cumple"
    return {"pct": pct, "decision": decision,
            "diagnostico": f"{negativos} de {n} valores de VaR son ≤ 0"}
