"""Control VaR: semáforo de Basilea — zona (verde/amarilla/roja) por nº de excepciones en la ventana."""

META = {
    "descripcion": "El nº de excepciones de backtesting en ~250 días debe situar el modelo en zona VERDE de Basilea (0-4); amarilla (5-9) es observación, roja (>=10) es rechazo.",
    "dimension":   "Backtesting (VaR)",
    "evidencia":   "Serie diaria de excepciones (0/1) o el par P&L/VaR, ~250 obs.",
    "referencia":  "Basilea — marco de backtesting (traffic light approach)",
    "orden":       21,
    "params": {"dataset": "", "campo_excepcion": "excepcion",
               "campo_pnl": "pnl", "campo_var": "var_99",
               "convencion": "perdida_positiva",
               "verde_max": 4, "amarillo_max": 9, "ventana": 250},
}


def _excepciones(df, params):
    import pandas as pd
    col = params.get("campo_excepcion")
    if col and col in getattr(df, "columns", []):
        return (pd.to_numeric(df[col], errors="coerce").fillna(0) != 0).astype(int)
    c_pnl, c_var = params.get("campo_pnl"), params.get("campo_var")
    cols = getattr(df, "columns", [])
    if c_pnl not in cols or c_var not in cols:
        return None
    pnl = pd.to_numeric(df[c_pnl], errors="coerce")
    var = pd.to_numeric(df[c_var], errors="coerce")
    m = pnl.notna() & var.notna()
    if str(params.get("convencion", "perdida_positiva")).lower() == "pnl_negativo":
        return (pnl[m] < -var[m].abs()).astype(int)
    return (pnl[m] > var[m].abs()).astype(int)


def control(df, datasets, params):
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}
    exc = _excepciones(df, params)
    if exc is None:
        return {"pct": None, "decision": "No evaluable",
                "diagnostico": "falta la columna de excepción o el par P&L/VaR"}
    N, x = int(exc.shape[0]), int(exc.sum())
    if N == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin observaciones"}
    # Umbrales escalados a la ventana real (los de Basilea son sobre 250 días).
    factor = N / float(params.get("ventana", 250) or 250)
    verde = float(params.get("verde_max", 4)) * factor
    amarillo = float(params.get("amarillo_max", 9)) * factor
    if x <= verde:
        zona, decision = "VERDE", "Cumple"
    elif x <= amarillo:
        zona, decision = "AMARILLA", "Observado"
    else:
        zona, decision = "ROJA", "No cumple"
    pct = round(100.0 * (1 - x / N), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": f"{x} excepciones en {N} obs → zona {zona} "
                           f"(verde ≤{verde:.0f}, amarilla ≤{amarillo:.0f})"}
