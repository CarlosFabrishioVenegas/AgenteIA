"""Control VaR: conteo de excedencias vs semáforo de Basilea (zona)."""

META = {
    "descripcion": "Backtesting por conteo de excedencias: nº de excepciones en la ventana debe caer en zona verde del semáforo de Basilea.",
    "dimension":   "Backtesting (VaR)",
    "evidencia":   "Serie diaria de excepciones (o P&L y VaR) de la ventana de 250 días.",
    "referencia":  "Basilea — backtesting traffic light (verde/amarillo/rojo)",
    "orden":       30,
    "params": {"dataset": "", "campo_excepcion": "excepcion",
               "campo_pnl": "pnl", "campo_var": "var_99",
               "convencion": "perdida_positiva",
               "ventana": 250},   # zonas Basilea calibradas a 250 días, VaR 99%
}


def control(df, datasets, params):
    import pandas as pd
    if df is None:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin dataset"}

    col_exc = params.get("campo_excepcion")
    if col_exc and col_exc in df.columns:
        exc = (pd.to_numeric(df[col_exc], errors="coerce").fillna(0) != 0).astype(int)
    else:
        c_pnl, c_var = params.get("campo_pnl"), params.get("campo_var")
        if not (c_pnl in getattr(df, "columns", []) and c_var in getattr(df, "columns", [])):
            return {"pct": None, "decision": "No evaluable",
                    "diagnostico": f"faltan columnas para el conteo de excedencias"}
        pnl = pd.to_numeric(df[c_pnl], errors="coerce")
        var = pd.to_numeric(df[c_var], errors="coerce")
        m = pnl.notna() & var.notna()
        if str(params.get("convencion", "perdida_positiva")).lower() == "pnl_negativo":
            exc = (pnl[m] < -var[m].abs()).astype(int)
        else:
            exc = (pnl[m] > var[m].abs()).astype(int)

    N, x = int(exc.shape[0]), int(exc.sum())
    if N == 0:
        return {"pct": None, "decision": "No evaluable", "diagnostico": "sin observaciones"}

    # Semáforo de Basilea para VaR 99% sobre 250 días: verde ≤4, amarillo 5–9, rojo ≥10.
    if x <= 4:
        zona, decision = "verde", "Cumple"
    elif x <= 9:
        zona, decision = "amarilla", "Observado"
    else:
        zona, decision = "roja", "No cumple"
    pct = round(100.0 * (1 - x / N), 2)
    return {"pct": pct, "decision": decision,
            "diagnostico": f"{x} excedencias en {N} obs → zona {zona} del semáforo de Basilea"}
