# VIRF Agent — qué hace realmente

**Fecha:** 2026-08-07 · **Estado verificado:** 148/148 checks · 835 tests · 1 skipped

Este documento describe lo que el sistema **hace**, no lo que pretende hacer.
Cada afirmación es comprobable con un comando, y las que no he podido comprobar
están marcadas como tales. Está escrito con el mismo criterio que gobierna el
agente: *antes declarar un límite que rellenar un hueco*.

---

## 1. En una frase

**VIRF no valida modelos financieros: valida el EXPEDIENTE de un modelo
financiero.** Lee la documentación que aporta el dueño del modelo, la contrasta
contra un estándar de 32 actividades, y produce un borrador de informe que un
validador humano corrige y firma.

No recalcula el VaR. No comprueba si la cifra es correcta. Comprueba si la
metodología está **documentada, justificada y coherente con la evidencia**.

---

## 2. Qué ocurre exactamente cuando lo ejecutas

```bash
python agente.py --titulo "VaR Mercado FRTB" --tier 4 \
                 --raiz-evidencia modelos/VaR_FRTB --prdc \
                 --validador "Nombre" --cargo "Validador de Segunda Línea"
```

### Paso 1 — Lee la evidencia

Recorre `inputs/` (o la raíz que le indiques) leyendo `.pdf .docx .md .txt .py
.ipynb .r .sql .xlsx .csv .json .pptx`. Los documentos largos se resumen por
segmentos con el propio modelo, no se truncan.

**Lo que importa:** si un documento se lee al 46 %, el informe dice 46 %. La
cobertura declarada es la real.

### Paso 2 — Resuelve el corpus de referencia

Elige uno de 4 corpus de dominio (`LaR`, `VaR`, `conductuales`, `shared`), por
`--dominio-rag` o inferido del título. El informe registra **cuál de las dos
cosas pasó**: `explicito` / `inferido` / `defecto`.

### Paso 3 — Evalúa 32 actividades, una llamada cada una

Por cada actividad del estándar arma un prompt de **~22.000 caracteres** con 16
bloques. Los que cambian según el caso:

| Bloque | Cuándo aparece |
|---|---|
| Instrucción del ámbito | siempre, distinta por ámbito |
| Preguntas guía | siempre, 2–5 según ámbito |
| Pericia de dominio (RAG) | si se recuperó algo |
| Cuestionamiento metodológico | **solo en Metodología** |
| Cobertura documental | siempre, con el % real |
| Calibración anti-sesgo | si hay masa crítica de feedback |
| Memoria intra e inter-ámbito | si hay hallazgos previos |

El resto es fijo: rol de validador escéptico, cinco trampas a detectar, escala
1-5 calibrada con ejemplos, reglas de citación, contraste entre fuentes.

### Paso 4 — Puntúa y pondera

| Ámbito | Peso | Actividades (Tier 1) |
|---|---:|---:|
| Metodología | 0.30 | 6 |
| Calidad de datos | 0.20 | 6 |
| Documentación | 0.15 | 9 |
| Implementación | 0.15 | 4 |
| Gobierno | 0.12 | 2 |
| Uso e integración | 0.08 | 5 |

### Paso 5 — Sella y emite

Genera JSON + borrador Markdown + Word, sella la cadena de custodia y anota la
emisión en un registro append-only fuera de `outputs/`.

---

## 3. Lo que hace que esto sea distinto de «pasarle documentos a un LLM»

Son cinco decisiones de diseño, y las cinco están en el código con tests.

### 3.1 No evalúa sobre el vacío

Si un ámbito no tiene documentos, **no llama al modelo**. Preguntarle a un LLM
por un documento que no existe produce una alucinación con formato de dictamen.

### 3.2 No inventa un puntaje

Si el modelo no responde conforme al contrato JSON, la actividad queda **sin
puntaje** y se reporta como fallo técnico. Nunca se rellena con un valor por
defecto.

### 3.3 Distingue «sin evidencia» de «fallo nuestro»

| Causa | Responsable | Score | En el informe |
|---|---|---|---|
| No se aportó documentación | El validado | **0.0**, con su peso íntegro | «SIN EVIDENCIA», rojo |
| Timeout, PDF ilegible, JSON roto | El agente | `None`, excluido, renormaliza | «FALLO TÉCNICO», gris |

Confundirlas significaría castigar al validado por un error del agente.

### 3.4 Verifica las citas

El prompt exige transcripción literal. Después, el código **comprueba que cada
cita exista de verdad** en la evidencia. Las que no aparecen se declaran en el
informe.

Verificado en ejecución: de 5 citas —4 reales del manual y 1 inventada— cazó
exactamente la inventada.

> Una cita inventada es más dañina que una referencia vaga: parece verificable,
> así que nadie la comprueba.

### 3.5 Declara su propia fiabilidad

```json
"actividades_evaluadas_ok": 31,
"actividades_con_fallo_tecnico": 3,
"dictamen_confiable": false
```

Si algo falló, el informe **lo dice y se marca como no apto** para sostener un
dictamen. No lo disimula con «0 hallazgos».

---

## 4. Los controles de cumplimiento

Ejecutables por el propio auditor, sin gastar API:

```bash
python agente.py --verificar-cadena "MODELO"       # ¿se alteró algún informe?
python agente.py --verificar-emisiones             # ¿falta alguno que se emitió?
python agente.py --verificar-evidencia <json>      # ¿cambió el manual citado?
python agente.py --historial-validaciones          # ¿quién firmó qué y cuándo?
python scripts/verificar_corpus_rag.py             # ¿el corpus está limpio?
python scripts/preguntas_oro_rag.py --strict       # ¿devuelve el doc correcto?
python validate_project.py --strict                # 148 comprobaciones
```

### La diferencia entre los dos primeros

Verificado borrando un informe real:

| Control | Salida | Exit |
|---|---|---|
| `--verificar-cadena` | «No hay informes para este modelo» | **0** |
| `--verificar-emisiones` | `AUSENTE · emitido 2026-08-03 · firma: Ana Perez` | **1** |

El primero opera sobre los ficheros que existen. El segundo compara contra un
registro append-only guardado **fuera** de `outputs/` y versionado en git. Sin
él, borrar la evidencia era indistinguible de no haber validado nunca.

---

## 5. Los análisis opcionales

### `--analizar-codigo` — hechos del código, sin modelo y sin ejecutarlo

Lee el AST de cada `.py` / `.ipynb` y extrae lo que se puede afirmar **sin
interpretar nada**: funciones definidas, valores por defecto, ventanas
literales, métodos estadísticos, aleatoriedad sin semilla. Luego contrasta esos
hechos contra los manuales.

**Coste 0. Determinista: dos corridas sobre el mismo fichero dan lo mismo.**

> **No es un modo aparte.** `--analizar-codigo` es una ETAPA dentro del pipeline
> de validación: exige `--titulo/--tier` y arrastra la corrida entera, con sus
> llamadas al modelo y su emisión. Lo de coste 0 es el análisis en sí, no la
> invocación. Para ejercitarlo solo, llama al módulo directamente (§9).
>
> Desde la auditoría del 2026-08-07, una corrida **sin firmante** se sella como
> `tipo_corrida: trabajo` y no como entregable. Antes toda corrida —incluida una
> de diagnóstico— dejaba en el registro append-only una línea de «entregable»
> con `validador: (no registrado)`: un entregable que nadie emitió ni firmó, e
> imborrable.

```
[alta ] funcion_documentada_ausente  backtesting_kupiec
[media] parametro_no_documentado     var_historico(ventana=500)
[media] parametro_no_documentado     var_historico(confianza=0.95)
[baja ] no_determinable              ventana calculada en tiempo de ejecución
```

La severidad es deliberada:

- **`alta` solo para el hecho inequívoco**: el manual invoca `backtesting_kupiec()`
  y ningún script del árbol la define. O está o no está.
- **`media` para todo lo numérico.** Que un número no aparezca en el manual es
  indicio fuerte; que aparezca **no prueba** que se refiera a ese parámetro.
  Señalan dónde mirar, no dictaminan.

Verificado en los dos sentidos, que es lo que le da valor:

| Evidencia | Manual vs código | Hallazgos de parámetro |
|---|---|---:|
| `VaR_FixtureDrift` | discrepan (250 vs 500) | **2, correctos** |
| `VaR_FRTB` | coinciden (500 y 99 %) | **0** |

Cero falsos positivos cuando coinciden. Requirió que `0.99` en el código
equivalga a «99 %» en el manual: sin esa equivalencia, un parámetro bien
documentado saldría como ausente y el equipo aprendería a desactivar el flag.

El log imprime **los hechos aunque no haya hallazgos**:

```
**Define:** `var_historico(retornos, confianza=0.95, ventana=500)` — línea 17
**Métodos:** `percentile()`×1
```

Un fichero «sin hallazgos» no dice lo mismo que uno del que se sabe qué define y
con qué parámetros: lo segundo lo verifica un humano en diez segundos.

#### Notebooks: lo que el `.ipynb` declara de su propia ejecución

Un `.ipynb` se analiza celda a celda, y además del AST se leen **los metadatos
que el notebook guarda de sí mismo**: `execution_count` por celda y los
`outputs` almacenados. No hay que ejecutar nada — esa información ya está en el
fichero, y en una validación **es evidencia**: de que el cálculo corrió, en qué
orden y con qué resultado.

Tres hechos, los tres deterministas:

| Hallazgo | Severidad | Qué significa |
|---|---|---|
| `notebook_sin_ejecutar` | **alta** si no corrió **ninguna** celda | El fichero no acredita que el cálculo se haya corrido nunca: es código entregado, no evidencia de ejecución |
| | `media` si solo faltan algunas | Los resultados no incluyen lo que esas celdas producirían |
| `notebook_con_excepcion` | **alta** | Una celda quedó guardada con un traceback sin resolver. En un notebook entregado como evidencia es un hallazgo por sí solo |
| `orden_ejecucion_roto` | **alta** | Los contadores no crecen en el orden del documento: el estado que muestra **no corresponde a ninguna corrida de arriba abajo**. Reejecutarlo desde cero puede dar otra cosa |

Y como en el resto del módulo, **el log declara el hecho aunque no haya
hallazgo** —«3/3 celdas ejecutadas · orden correcto» es algo que el validador
quiere ver afirmado, no deducido del silencio:

```
**Ejecución:** 3/3 celdas ejecutadas · orden correcto
**Ejecución:** 0/3 celdas ejecutadas · orden correcto
**Ejecución:** 3/4 celdas ejecutadas · orden **ALTERADO** · **1 excepción(es)**
```

Medido hoy sobre tres notebooks construidos para el caso —limpio, sin ejecutar,
y trabajado a saltos con una excepción guardada:

| Notebook | Hallazgos de notebook |
|---|---|
| Ejecutado de arriba abajo | **0** |
| Entregado sin salidas | 1 — `notebook_sin_ejecutar` (alta) |
| Saltos + traceback + celda pendiente | 3 — orden (alta), excepción (alta), celdas sin ejecutar (media) |

Cero ruido sobre el notebook limpio, que es la mitad que importa: un aviso que
salta cuando no debe enseña al equipo a ignorar el flag.

Dos decisiones deliberadas para no producir falsos positivos:

- **Una celda vacía no cuenta como celda sin ejecutar.** No hay nada que correr;
  contarla generaría un hallazgo por un hueco en blanco.
- **Los hechos de ejecución se extraen aunque el código no compile.** Una celda
  rota se omite del AST y se declara, pero el notebook sigue diciendo si se
  ejecutó, en qué orden y con qué excepciones. Perder eso por un error de
  sintaxis sería tirar evidencia válida.

> **Esto ya no es un falso positivo: es el incumplimiento de una política.**
> El 2026-08-07 la entidad confirmó que los notebooks se entregan ejecutados de
> arriba abajo (`Restart & Run All`, con sus salidas) —
> `PROCEDIMIENTO_VALIDACION.md` §5.1. `Restart & Run All` satisface las tres
> comprobaciones a la vez.
>
> Queda una contradicción menor, y conviene conocerla: la sección de notebooks
> del `.gitignore` está rotulada «limpiar outputs antes de commitear». Es solo
> un comentario —la regla ignora `.ipynb_checkpoints/`, nadie despoja las
> salidas—, pero si alguien la sigue a mano choca con §5.1. Prevalece el
> procedimiento.

> **No ejecuta el código, y es una decisión de seguridad, no una limitación
> técnica.** Ver §7.7.

### `--revisar-codigo` — juez de código anclado

Una llamada por módulo, con el código numerado para que los hallazgos salgan con
`fichero:línea`. Contrasta contra el manual metodológico **y el de seguimiento**.

Lo que lo hace un dictamen y no una opinión: cuando afirma que el manual dice
algo, **debe citar el fragmento, y ese fragmento se verifica**. Si no aparece
literalmente, el hallazgo sale marcado `SIN ANCLAR` en el informe.

Verificado contra `modelos/VaR_FixtureDrift`, con cuatro discrepancias plantadas:

```
[CRITICA] calcula_var.py:14 [code_drift]  →  ✅ ANCLADO
   return (precios[1:] - precios[:-1]) / precios[:-1]
   Calcula retornos aritméticos; el manual especifica logarítmicos.
   «Los rendimientos […] se calculan como retornos logarítmicos»
```

**4 de 4 detectadas. 4 citas verificadas, 0 falsas.** Coste: ~$0,0005.

Además corrige la categoría cuando **contradice los hechos** —si dice «el manual
no lo declara» y el elemento sí aparece en el manual—, y guarda la categoría
original para que se vea qué dijo el modelo y qué ajustó el agente.

### `--skills` — ocho análisis transversales

Investigaciones que cruzan fuentes y no caben en una casilla del estándar:
coherencia doc↔código, supuestos estadísticos, bibliografía, challenger,
regulatorio, gobierno, datos, síntesis.

**No alteran el score.** Producen hallazgos, no puntajes: si lo movieran, dos
corridas con distinta selección de skills dejarían de ser comparables.

Cada skill declara su propia clave de contrato —`discrepancias`, `supuestos`,
`referencias`, `hipotesis`, `brechas`, `hallazgos`, `prioridades`— y **verifica
sus citas contra el mismo contexto que vio**, que es la única defensa contra un
hallazgo que suena bien y cita algo que nadie escribió.

Verificado el 2026-08-07 **sin gastar API**, interceptando `_llamar_modelo`
sobre la evidencia real de `modelos/VaR_FRTB`. Lo único simulado es qué
contestaría el modelo; el anclaje de citas es el real:

| Inyectado en las 8 skills | Resultado |
|---|---|
| 2 frases copiadas literalmente del manual | verificadas — **0 falsos positivos** |
| 1 cita inventada que suena plausible | **cazada en las 8** |

**8/8 parsean su contrato y anclan sus citas.**

#### Y lo que esa verificación destapó

Al montar el arnés envié la clave equivocada a una skill —`hallazgos` donde
esperaba `prioridades`— y la skill devolvió **`ok=True` con 0 hallazgos**. Sin
error, sin aviso. Tres incumplimientos distintos —clave ausente, clave a `null`,
y prosa en lugar de lista— daban los tres el mismo resultado que un análisis
limpio que no encontró nada.

Era el invariante §3.2 invertido: el pipeline principal declara FALLO TÉCNICO en
ese caso, y las skills callaban. En el informe, «el modelo incumplió el
contrato» se leía como «esta skill no encontró nada».

Corregido: los tres casos se declaran ahora como skill fallida. Con el control
que impide pasarse de frenada — **una lista vacía legítima sigue siendo
`ok=True`**, porque «analicé y no hay nada» es un resultado válido y marcarlo
como roto convertiría el aviso en ruido.

> Era la trampa de `.get(clave, respaldo)` por quinta vez: `.get` no distingue
> «la clave falta» de «la clave vale `null`». Hace falta un centinela.

### Motores de calidad de datos de la entidad — solo lectura

El validador escribe sus propios motores, los ejecuta **en su máquina** y deja
la tabla en `inputs/calidad_datos/resultadocalidad_de_datos/` (`.csv`, `.xlsx`
o `.parquet`), con cuatro columnas: descripción, % de incumplimiento, resultado
y detalle de la observación. Los encabezados se reconocen con tolerancia.

**El agente solo la LEE.** No ejecuta esos motores y no debe hacerlo: quien
corre la prueba es quien responde de ella, y ejecutarla aquí la haría correr
con los permisos del validador sobre la máquina que guarda `audit_logs/`. Un
`.py` en esa carpeta se ignora y se declara. Hay un test sobre el AST que lo
impide.

Cada fila entra como una actividad del ámbito con su puntaje, usando la
calibración que ya tenía el proyecto: 0 %→5 · <0,5 %→4 · <2 %→3 · <10 %→2 ·
≥10 %→1.

**El tope depende de la tolerancia declarada** (política del 2026-08-08). Por
eso la tabla lleva una columna `Umbral`:

| Veredicto del motor | Tolerancia | Tope del puntaje |
|---|---|---|
| FALLA | **0** (tolerancia cero) | **3** |
| FALLA | > 0 | 4 |
| FALLA | no consta la columna | 4, y se declara que no consta |

Sobre tolerancia cero la magnitud no atenúa el hecho de haberla superado: la
entidad decidió que ahí no cabe ni un caso. Medido sobre los datos reales —
cuatro controles en FALLA con tasas de 0,08 a 0,5 %— el ámbito pasa de **4,38
a 3,88**.

Sin columna `Umbral` **no se supone tolerancia cero**: endurecer el puntaje
sobre un dato que no consta acusaría al validado por una omisión de formato.

Dos reglas más que evitan contradecir al motor:

- Si concluye **FALLA** y mide 0 %, queda **sin puntaje** en vez de un 5: la
  tasa no explica el fallo y el agente no sobrescribe a quien corrió la prueba.
- Si concluye **FALLA** sin cuantificar, tampoco se puntúa — «falla» no dice
  cuánto, y asignarle un 1 sería inventar la severidad.

**Cómo se genera la tabla.** Hay un pipeline de referencia,
`scripts/pipeline_calidad_datos.py`, que la produce con el formato exacto. Lo
ejecuta el VALIDADOR (`python scripts/pipeline_calidad_datos.py`), nunca el
agente — hay un test que comprueba que `agente.py` no lo importa. Trae un plan
declarativo de 7 controles sobre el catálogo existente y un ejemplo de control
propio para lo que el catálogo no cubre; añadir uno es añadir una entrada a una
lista. Los umbrales los declara el validador: sin umbral, el control se ejecuta
pero deja el veredicto vacío en vez de que el script decida qué es aceptable.

**Precedencia.** VIRF tiene sus propios motores y los sigue ejecutando sobre
`datasets/`, pero cuando hay resultados de la entidad **los internos pasan a
informativos**: si puntuaran ambos, la misma dimensión entraría dos veces en el
score con dos veredictos posibles. El informe declara en cada resultado quién
lo ejecutó.

### `--prevuelo` — coste 0

Dice qué se podrá leer, qué PDFs están escaneados y qué ámbitos quedarían sin
evidencia, **antes de gastar**. Sale con código 1 si algún ámbito quedaría a 0.

---

## 6. Estado real, con cifras

| Concepto | Valor |
|---|---|
| Código activo | 74 ficheros · 30.611 líneas |
| Tests | 12.080 líneas · **835 pasando**, 1 skipped |
| Comprobaciones de integridad | **148**, coste 0 |
| Flags de CLI | 36 |
| Corpus RAG | 43 fragmentos en 4 dominios · **26 de resúmenes secundarios** |
| Rutas que ejecutan código | **1**, y no es la validación (§7.3) |

### Corridas reales ejecutadas

| Fecha | Score | OK | Fallos | Confiable |
|---|---:|---:|---:|:---:|
| 2026-08-03 | 2.87 | 34 | 0 | **sí** |
| 2026-08-03 (previa) | 2.65 | 32 | 1 | no |
| 2026-08-06 | 2.38 | 31 | 3 | no |

La última se quedó **sin crédito de API** a mitad. El sistema degradó como debe:
declaró los 3 fallos, los excluyó del score y marcó el informe como no apto.

---

## 7. Lo que NO hace — leer con atención

### 7.1 No comprueba matemáticas

No recalcula el VaR ni verifica que el número sea correcto. Si el manual
describe impecablemente un método equivocado y el código lo implementa
fielmente, VIRF puede puntuarlo alto.

### 7.2 El corpus de referencia NO son los textos oficiales

`inputs/rag/` contiene documentos de apoyo **generados a partir de** marcos
públicos. No son BCBS 239, ni SR 11-7, ni FRTB.

Medido hoy con `python scripts/verificar_corpus_rag.py`:

| Dominio | Fragmentos | De resúmenes secundarios |
|---|---:|---:|
| `shared` | 16 | 10 |
| `VaR` | 12 | 6 |
| `LaR` | 9 | 6 |
| `conductuales` | 6 | 4 |
| **Total** | **43** | **26 (60 %)** |

El resto (17) proceden de contenido no marcado, principalmente portadas y
metadatos: **no hay ningún fragmento de texto oficial en el corpus.**

Lo que sí está verificado del corpus:

- **Sin contaminación cruzada.** Cada dominio recupera solo sus documentos. Es
  un defecto que ya ocurrió una vez —los cuatro índices llenos del mismo
  manual— y que el verificador comprueba en cada ejecución.
- **Cada dominio responde a su vocabulario.** Los ocho sondeos devuelven
  resultados; ningún índice está mudo.

Y cada informe lo declara:

> Ninguna exigencia regulatoria concreta —y en particular ningún umbral
> numérico— debe darse por acreditada sobre la base de este corpus sin
> contrastarla contra la fuente primaria.

Es admisible porque está **declarado**. Dejaría de serlo el día que alguien lo
lea como si fuera la norma.

**Qué haría falta para cerrarlo:** sustituir los PDF por BCBS 238/239/295/457,
SR 11-7, EBA/GL y TRIM Guide, reindexar con `force_rebuild=True` y volver a
ejecutar el verificador. El aviso del informe desaparece solo cuando dejen de
detectarse fragmentos marcados.

### 7.3 Hay UNA ruta que sí ejecuta código, y no es la validación

`--convertir-excel` traduce hojas de cálculo a notebooks y, para autovalidarlos,
**los ejecuta con `exec()` sin sandbox**. El propio código lo documenta:

> `ns = {}` aísla los NOMBRES de variables, no las CAPACIDADES. El código corre
> con acceso completo a builtins, disco y red, con los permisos del usuario que
> lanzó el agente.

Lo que acota el riesgo, y conviene tenerlo claro:

- Es un **modo aparte**: `--convertir-excel` hace `return` y nunca llega al
  pipeline de validación. Ninguna corrida con `--titulo/--tier` ejecuta nada.
- El código ejecutado lo **genera el propio agente** traduciendo tu Excel, no lo
  aporta el validado.
- Se puede desactivar: `--sin-validacion` genera el notebook sin ejecutarlo.

Aun así, el contenido depende de un fichero de entrada, así que **no conviene
apuntarlo a un Excel de procedencia dudosa**. Un aislamiento real —subproceso
con permisos recortados o kernel en contenedor— sigue siendo una decisión
pendiente del proyecto, anterior a este trabajo.

### 7.4 No sustituye al validador

Produce un **borrador**. El informe declara qué porcentaje de puntajes corrigió
el humano, precisamente para que un supervisor pueda juzgar si hubo revisión
efectiva o aceptación en bloque.

### 7.5 El procedimiento está completo (desde 2026-08-12)

`PROCEDIMIENTO_VALIDACION.md` tenía cinco apartados en ⛔ (roles y segregación,
umbral por ámbito, criterio formal de «crítico», retención, doble firma Tier 1).
El 2026-08-12 la entidad confirmó los cinco y el procedimiento pasó a estado
VIGENTE. En resumen:

- **§1 Roles.** Validador de 2ª línea firma **y** aprueba; incompatibilidad
  estricta con el desarrollador del modelo.
- **§4.2 Umbral por ámbito.** Un ámbito con score < 2.5 impide la aprobación
  aunque el global supere 3.5.
- **§6 Crítico automático.** Un ámbito con score ≤ 2 marca hallazgo crítico
  sin depender del juicio del validador.
- **§8 Retención.** 5 años desde la fecha de emisión de cada informe.
- **§9 Doble firma Tier 1.** DESACTIVADA por decisión, no por omisión: el
  control queda listo para activarse (`VIRF_DOBLE_FIRMA_TIER=1`) si el equipo
  crece o el supervisor lo requiere.

Los otros hitos previos siguen vigentes: entrega de notebooks con
`Restart & Run All` y sus salidas (§5.1, 2026-08-07) y tope de puntaje 3 sobre
tolerancia declarada cero (2026-08-08).

### 7.6 La doble firma existe pero está apagada

El control de dos ojos para Tier 1 está construido y probado —rechaza al mismo
firmante comparando sin acentos ni mayúsculas—, pero **desactivado**. Se
habilita con `VIRF_DOBLE_FIRMA_TIER=1` cuando la entidad lo decida.

### 7.7 No ejecuta el código del modelo, y es deliberado

`--analizar-codigo` lee el AST; **no corre nada**. Ejecutar daría comportamiento
real —que la función corra, qué devuelve con datos conocidos— y se evaluó. Se
descartó por tres motivos:

1. El código de `inputs/implementacion/` lo aporta **el validado**: la parte con
   incentivo en el resultado.
2. Correría con los permisos del validador, en la máquina que guarda
   `audit_logs/`, `outputs/` y `feedback/`. **Un script podría alterar la
   evidencia de su propia validación.**
3. Rompería el invariante 5: una corrida que ejecuta código deja de ser
   reproducible por sí sola.

Hay un test que lo hace cumplir: falla si el módulo introduce `exec`, `eval`,
`subprocess` o `import_module`.

**Consecuencia honesta:** el análisis comprueba que el código *declare* lo que
el manual dice, no que *haga* lo que dice. Un `var_historico(ventana=500)` que
internamente ignorara el parámetro pasaría desapercibido.

### 7.8 Un hueco residual conocido

Un hallazgo de código con el nombre del elemento mal puesto **y** sin cita
escapa a la verificación de anclaje. Se observó una vez. Cerrarlo exigiría
interpretar la prosa de la descripción, que es una heurística frágil.

---

## 8. Qué está verificado y qué no

| Afirmación | Cómo lo sé |
|---|---|
| El pipeline evalúa 32 actividades y pondera | corridas reales, JSON sellado |
| Distingue sin-evidencia de fallo técnico | tests + corridas con fallos reales |
| La cadena de custodia detecta alteración | test que edita un informe |
| El registro detecta un informe borrado | **borrado real**, exit 1 |
| El juez de código ancla sus citas | fixture con 4 discrepancias plantadas |
| Las citas inventadas se declaran | 1 de 5 citas cazada |
| Las skills llegan al Word | 9/9 comprobaciones sobre el `.docx` |
| Un JSON truncado se reintenta | test con el caso exacto de producción |
| El análisis estático detecta discrepancias | fixture con 4 plantadas: 4/4 |
| …y NO las inventa cuando no las hay | `VaR_FRTB`: 0 hallazgos de parámetro |
| Los hechos de ejecución de un `.ipynb` se leen sin ejecutarlo | 3 notebooks construidos: 0 / 1 / 3 hallazgos |
| …y un notebook limpio no genera ruido | el ejecutado de arriba abajo: 0 |
| Las 8 skills anclan sus citas contra evidencia real | modelo interceptado sobre `VaR_FRTB`: 8/8 cazan la inventada, 0 falsos positivos |
| Una skill que incumple el contrato se declara | 3 incumplimientos → `ok=False`; lista vacía legítima → `ok=True` |
| La llamada al modelo fija `temperature=0` | SDK interceptada: el parámetro viaja en la petición |
| Un fallo técnico no puntúa 1 en el borrador | `_pj()` → `None`; y su pregunta no se envía al modelador |
| Sin firmante no hay entregable | corrida real: quedó `tipo_corrida: trabajo` en el registro |
| La memoria inter-ámbito llega íntegra | prompt capturado con 6 hallazgos previos: el bloque entero |
| El RAG declara qué NO conoce | consulta de otro dominio: «no contiene los términos …» |
| El tier cambia el alcance | 24 / 19 / 23 / 29 actividades exigidas |
| El corpus RAG no tiene contaminación cruzada | verificador, 4 dominios |
| El corpus devuelve el documento correcto | 24 preguntas-oro: recall@1 y @3 **100 %** sobre las 19 elegibles |
| …y declara su alcance ante consultas ajenas | 4 consultas adversarias: 4/4 advierten |
| **Calidad del análisis del modelo** | **no verificado** — requiere gasto y juicio experto |

La última línea es la importante. Sé que el sistema **procesa, verifica y
entrega correctamente** lo que el modelo responda. No sé si lo que el modelo
responde es bueno. Eso lo decide un validador leyendo el borrador.

Y conviene decir por qué sigue sin verificarse: **no hay crédito de API, y no
está previsto recargarlo.** Todo lo verificable interceptando el modelo está
verificado —que es más de lo que parece: el parseo, el anclaje de citas contra
la evidencia real, el contrato de las skills y el renderizado al Word son código
nuestro y se ejercitan enteros—. Lo que no se puede simular es el juicio: si el
hallazgo que produce el modelo es *pertinente*. Eso no es una limitación del
arnés, es que la respuesta del modelo es precisamente lo que el arnés sustituye.

> La consecuencia práctica: el sistema está verificado **como maquinaria**, no
> como dictaminador. Es exactamente lo que sostiene el diseño —produce un
> borrador que un humano firma— y por eso la ausencia se declara aquí en vez de
> darse por cubierta.

---

## 9. Cómo comprobar todo esto tú mismo

```bash
# Sin gastar un token:
python validate_project.py --strict      # 148 comprobaciones
python -m pytest -q                      # 835 tests
python scripts/verificar_corpus_rag.py   # estado del corpus
python agente.py --prevuelo --titulo X --tier 1 --raiz-evidencia modelos/VaR_FRTB

# Análisis estático del código — coste 0, no ejecuta nada:
python -c "import sys; sys.path.insert(0,'.'); sys.path.insert(0,'motor'); \nfrom pathlib import Path; from modulos.analisis_estatico import analizar_arbol, informe_markdown; \nb=Path('modelos/VaR_FixtureDrift/inputs'); \nm=(b/'documentacion/modelamiento/manual_VaR_drift.md').read_text(encoding='utf-8'); \nprint(informe_markdown(analizar_arbol(sorted((b/'implementacion').glob('*.py')), m, raiz=b/'implementacion'), 'demo'))"

# Coste conocido antes de gastar:
python agente.py --revisar-codigo --dry-run --raiz-evidencia modelos/VaR_FRTB
```

---

## 10. El criterio que lo gobierna todo

> **Prefiere siempre declarar una ausencia antes que rellenar un hueco.**

Se ve en cada decisión: la actividad que no se pudo evaluar queda sin puntaje;
la cita que no se encuentra se marca; el documento recortado dice cuánto se
recortó; el corpus no oficial lo declara el propio informe; el dominio inferido
se distingue del declarado.

Un validador que se inventa una evidencia hace mucho más daño que uno que dice
«no lo encontré». Todo lo demás de este sistema es consecuencia de eso.
