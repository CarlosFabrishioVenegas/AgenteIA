"""
src/rag/indexador_lexico.py
═════════════════════════════════════════════════════════════════════════════
Construye y persiste el índice LÉXICO (BM25 + TF-IDF) de un dominio RAG.

Qué reemplaza y por qué
───────────────────────
Hasta el 2026-07-31 el RAG era vectorial: ChromaDB + embeddings generados por
un deployment de Azure `text-embedding-3-*`. Dos hechos lo dejaron inservible:

1. NO HAY DEPLOYMENT DE EMBEDDINGS. El recurso Azure de esta entidad tiene un
   único deployment, de chat. `config/embeddings.py` fallaba con «Falta
   AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT», `BaseRetriever.query()` lo capturaba y
   devolvía `[]`, y el pipeline seguía sin contexto RAG. Es decir: el RAG
   llevaba tiempo instalado, documentado y APAGADO, sin que nada lo dijera más
   alto que un warning.

   Y no hay atajo: el deployment de chat NO genera embeddings. Pedirle vectores
   a `/chat/completions` no está soportado por el modelo — devuelve texto que
   parece un vector y no lo es.

2. CHROMADB ARRASTRA HUGGINGFACE. Nadie importaba `transformers` en este
   proyecto, pero `pip show` no miente:

       chromadb → tokenizers → huggingface-hub

   La política de «cero modelos externos» se cumplía en el código y se
   incumplía en el árbol de dependencias. Quitar ChromaDB corta la cadena
   entera; no hay forma de tener ChromaDB y no tener huggingface-hub instalado.

La sustitución es BM25 + TF-IDF, que para literatura regulatoria no es un
premio de consolación:

  - BM25 es el algoritmo de recuperación de Elasticsearch/Lucene. Premia la
    coincidencia EXACTA de término, ponderada por rareza en el corpus y por
    longitud del documento.
  - En este corpus la terminología ES la señal. «Kupiec», «HQLA», «NSFR»,
    «IFRS 9», «Cornish-Fisher» son cadenas literales que aparecen en el paper
    correcto y en ninguno más. Un embedding genérico multilingüe las proyecta
    cerca de «prueba estadística» o «liquidez» y DILUYE justo lo que
    discrimina.
  - Lo que se pierde es el sinónimo no literal («valor en riesgo» vs. «VaR»
    cuando el documento nunca escribe la sigla). Se compensa por tres vías:
    stemming, bigramas en TF-IDF, y una query enriquecida (ámbito + actividad)
    que aporta más términos de anclaje que la pregunta pelada.

Todo el proceso es LOCAL: cero llamadas de red. El único tráfico saliente del
RAG ocurre después, cuando el motor sintetiza la respuesta con el deployment de
chat — y eso es una llamada de chat completions normal.

Uso:
    from src.rag.indexador_lexico import IndexadorLexico
    idx = IndexadorLexico("VaR")
    idx.construir()                 # lee inputs/rag/VaR/, persiste el índice
    idx.construir(force=True)       # ignora lo persistido y reextrae los PDF
"""

from __future__ import annotations

import hashlib
import logging
import os
import pickle
import re
import time
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

# `import src.rag.config_rag` y NO `from src.rag import config_rag`: la segunda
# forma ejecuta `src/rag/__init__.py` —el dispatcher— y crea un ciclo
# src.rag → …retriever → base_retriever → buscador_lexico → src.rag que el
# validador de arquitectura detecta y rechaza. La forma de abajo referencia el
# submódulo directamente y no toca el paquete.
import src.rag.config_rag as cfg

logger = logging.getLogger("virf.rag")

__all__ = [
    "IndiceLexico", "IndexadorLexico", "tokenizar", "vocabulario_crudo",
    "fuentes_rag",
    "raiz_proyecto", "ruta_indice",
]


# ═════════════════════════════════════════════════════════════════════════════
# TOKENIZACIÓN
# ═════════════════════════════════════════════════════════════════════════════
# Por qué NO se usa nltk
# ──────────────────────
# La especificación admitía `nltk` con sus propios corpus vía `nltk.download()`.
# Se descartó, y no por gusto: `nltk.download()` descarga desde
# `raw.githubusercontent.com`. En la red de esta entidad —con inspección TLS y
# CA propia— eso produce EXACTAMENTE el mismo error que motivó echar a
# sentence-transformers:
#
#     SSL: CERTIFICATE_VERIFY_FAILED — self-signed certificate in chain
#
# Cambiar una descarga de huggingface.co por una descarga de github.com no
# resuelve el problema, lo reubica. Las listas de stopwords son cien palabras
# funcionales por idioma: caben en este fichero, no cambian nunca, y así el
# indexado es local de verdad — no «local salvo la primera vez».

_STOPWORDS_ES = frozenset("""
a al algo algunas algunos ante antes como con contra cual cuales cuando de del
desde donde dos e el ella ellas ellos en entre era erais eran eres es esa esas
ese eso esos esta estaba estado estamos estan estar estas este esto estos fue
fueron fui ha habia han hasta hay la las le les lo los mas me mi mientras mucho
muy nada ni no nos nosotros o os otra otras otro otros para pero poco por
porque que quien quienes se sea segun ser si sin sobre solo son su sus tal
tambien tanto te tiene tienen todo todos tu tus un una uno unos y ya
""".split())

_STOPWORDS_EN = frozenset("""
a about above after again against all am an and any are as at be because been
before being below between both but by can cannot could did do does doing down
during each few for from further had has have having he her here hers herself
him himself his how i if in into is it its itself me more most my myself no nor
not of off on once only or other ought our ours ourselves out over own same she
should so some such than that the their theirs them themselves then there these
they this those through to too under until up very was we were what when where
which while who whom why with would you your yours yourself yourselves
""".split())

STOPWORDS = _STOPWORDS_ES | _STOPWORDS_EN

# Términos que NUNCA se filtran aunque sean cortos: son las siglas que dan
# sentido a usar búsqueda léxica en vez de semántica.
#
# NO están «EL» (Expected Loss) ni «ES» (Expected Shortfall), y es una decisión
# consciente. Ambas colisionan con las dos palabras más frecuentes del español.
# Protegerlas significa que «el» sobrevive a la tokenización de TODA consulta en
# castellano, y como aparece en prácticamente todos los chunks, cualquier
# fragmento pasaría el filtro de cobertura: la consulta «receta de tortilla»
# dejaría de devolver vacío y empezaría a devolver regulación al azar. Se pierde
# poder recuperar «EL» como sigla suelta; se gana que el filtro de irrelevancia
# siga funcionando. En la práctica los documentos escriben «expected loss» o
# «pérdida esperada» junto a la sigla, así que la consulta ancla igual.
TERMINOS_PROTEGIDOS = frozenset({
    "var", "lar", "pd", "lgd", "ead", "ul", "hqla", "lcr", "nsfr",
    "irrbb", "nmd", "frtb", "ifrs", "sr", "bcbs", "ccf", "rwa", "svar", "cva",
})

# Un token es una palabra (con acentos), un número, o una sigla con puntos
# internos («e.g.», «u.s.»). Los guiones internos se conservan porque
# «Cornish-Fisher» o «back-testing» son un término, no dos.
_RE_TOKEN = re.compile(r"[a-záéíóúüñç0-9]+(?:[-'][a-záéíóúüñç0-9]+)*", re.IGNORECASE)

# Sufijos ordenados de más largo a más corto: hay que probar «aciones» antes que
# «es», o «validaciones» quedaría en «validacion» y nunca en «valid».
_SUFIJOS_ES = (
    "amiento", "imiento", "acion", "icion", "ancia", "encia",
    "adora", "ador", "ante", "ent", "ant", "idad", "ista", "ismo",
    "able", "ible", "mente", "ado", "ada", "ido", "ida",
)
_SUFIJOS_EN = (
    "ization", "iveness", "fulness", "ousness", "ational", "ation",
    "ingly", "edly", "ment", "ness", "ing", "er", "est", "ed", "ly",
)
_SUFIJOS = tuple(sorted(set(_SUFIJOS_ES + _SUFIJOS_EN), key=len, reverse=True))

# Un stem por debajo de esto deja de ser una palabra y empieza a colisionar con
# cualquier cosa: «es» de «esto» y «es» de «expected shortfall».
_LONGITUD_MINIMA_STEM = 4

_VOCALES = frozenset("aeiou")


def quitar_acentos(texto: str) -> str:
    """
    Normaliza acentos: «ponderación» y «ponderacion» deben ser el mismo token.

    En este corpus la ortografía es inconsistente por origen: los PDF del BCBS
    traducidos y los manuales internos escriben lo mismo con y sin tilde, y un
    extractor de PDF además se come tildes según la fuente tipográfica. Sin esta
    normalización, media consulta en español recupera la mitad de lo que debe.

    La ñ se preserva: «año» y «ano» no son la misma palabra.
    """
    texto = texto.replace("ñ", "\x00").replace("Ñ", "\x00")
    texto = unicodedata.normalize("NFKD", texto)
    texto = "".join(c for c in texto if not unicodedata.combining(c))
    return texto.replace("\x00", "ñ")


def _despluralizar(token: str) -> str:
    """
    Quita el plural aplicando la regla real del español (que también cubre el
    inglés regular). Dos pasos, no uno.

    Recortar «s» a secas o «es» a secas se equivoca en la mitad de los casos,
    porque en español el plural depende de en qué termina el singular:

        consonante + «es»  →  valores → valor,  temporales → temporal
        vocal      + «s»   →  series  → serie,  pruebas    → prueba

    Con la regla simplista, «series» acababa en «seri» y «serie» en «serie»:
    dos tokens distintos para la misma palabra, de modo que una consulta sobre
    «serie temporal» no recuperaba el chunk que dice «series temporales». Ese
    fallo no da error, solo devuelve menos resultados de los que hay.
    """
    if len(token) < 5 or token.endswith("ss"):
        return token
    if token.endswith("es") and len(token) >= 6 and token[-3] not in _VOCALES:
        candidato = token[:-2]
        if len(candidato) >= _LONGITUD_MINIMA_STEM:
            return candidato
    if token.endswith("s"):
        candidato = token[:-1]
        if len(candidato) >= _LONGITUD_MINIMA_STEM:
            return candidato
    return token


def _stem(token: str) -> str:
    """
    Stemmer conservador: despluralizar y, como mucho, UN recorte derivativo.

    No es Snowball y no pretende serlo. Snowball vive en `nltk`, que exige
    `nltk.download()`; y un stemmer agresivo en este corpus hace daño: recortar
    «backtesting» hasta «backtest» está bien, hasta «back» destruye el término.

    Reglas de contención:
      - No toca términos protegidos ni tokens de menos de 5 caracteres, así que
        las siglas y los tecnicismos cortos quedan intactos («kupiec», «hqla»).
      - El recorte derivativo solo se intenta a partir de 6 caracteres.
      - Nunca devuelve stems de menos de 4 caracteres: si el recorte deja menos,
        se prueba el siguiente sufijo, y si ninguno cabe se conserva el token.
    """
    if token in TERMINOS_PROTEGIDOS or len(token) < 5:
        return token

    token = _despluralizar(token)
    if len(token) < 6:
        return token

    for sufijo in _SUFIJOS:
        if token.endswith(sufijo):
            recortado = token[: -len(sufijo)]
            if len(recortado) >= _LONGITUD_MINIMA_STEM:
                return recortado
            # Sufijo demasiado voraz para esta palabra; se prueba uno más corto
            # en vez de abandonar. Sin esto, «series» chocaba con «ies», el
            # recorte quedaba en 3 caracteres y el token se dejaba sin tocar.
    return token


def tokenizar(texto: str, stemming: Optional[bool] = None) -> List[str]:
    """
    Texto → lista de tokens normalizados. MISMA función para chunks y consultas.

    Que indexado y consulta compartan tokenizador no es un detalle de estilo: si
    difieren en un solo paso (una tilde, un stem), la consulta genera términos
    que NO existen en el índice y BM25 devuelve ceros. El fallo no da error —
    devuelve una lista vacía de resultados, igual que un corpus sin coincidencias.

    Pasos: minúsculas → sin acentos → tokens → sin stopwords → stem.
    """
    if not texto:
        return []
    if stemming is None:
        stemming = cfg.STEMMING_ACTIVO

    texto = quitar_acentos(texto.lower())
    tokens: List[str] = []
    for bruto in _RE_TOKEN.findall(texto):
        if bruto in TERMINOS_PROTEGIDOS:
            tokens.append(bruto)
            continue
        if bruto in STOPWORDS:
            continue
        if len(bruto) < cfg.LONGITUD_MINIMA_TOKEN:
            continue
        tokens.append(_stem(bruto) if stemming else bruto)
    return tokens


def vocabulario_crudo(textos) -> set:
    """
    Palabras del corpus SIN stem, para corregir erratas de la consulta.

    Se filtran las de menos de 4 letras y las stopwords: comparar por parecido
    ortográfico contra palabras muy cortas produce falsos positivos a mansalva
    («caso» ↔ «paso» ↔ «peso»), y ahí el remedio sería peor que la enfermedad.
    """
    palabras = set()
    for texto in textos:
        for bruto in _RE_TOKEN.findall(quitar_acentos((texto or "").lower())):
            if len(bruto) >= 4 and bruto not in STOPWORDS:
                palabras.add(bruto)
    return palabras


def texto_normalizado_para_tfidf(texto: str) -> str:
    """
    Versión del texto lista para `TfidfVectorizer`.

    Se le entrega el texto YA tokenizado y reunido con espacios, en vez de
    dejar que sklearn aplique su propio `token_pattern`. Motivo: si sklearn
    tokeniza a su manera y BM25 a la nuestra, las dos señales que se van a
    combinar están midiendo vocabularios distintos, y el peso 0.7/0.3 deja de
    significar lo que dice. Un solo tokenizador para las dos.
    """
    return " ".join(tokenizar(texto))


# ═════════════════════════════════════════════════════════════════════════════
# RUTAS
# ═════════════════════════════════════════════════════════════════════════════

def raiz_proyecto() -> Path:
    """Raíz del proyecto. Un único sitio donde calcularla."""
    return cfg.RAIZ_PROYECTO


def fuentes_rag(dominio: str) -> List[Path]:
    """
    Carpeta de LITERATURA DE REFERENCIA del dominio: `inputs/rag/<dominio>/`.

    ── Por qué no se indexa `inputs/` directamente ──────────────────────────
    Los indexadores leían de `inputs/documentacion/`, `inputs/papers/` y demás,
    que son la EVIDENCIA DEL MODELO QUE SE ESTÁ VALIDANDO. Eso producía dos
    problemas graves:

    1. RAZONAMIENTO CIRCULAR. Ante la actividad «¿el manual documenta el
       backtesting?», el RAG recuperaba fragmentos DEL PROPIO MANUAL y los
       inyectaba como «conocimiento recuperado» del dominio. El modelo veía sus
       propias afirmaciones presentadas como referencia autorizada que las
       confirma. El agente se daba la razón a sí mismo.

    2. CONTAMINACIÓN ENTRE DOMINIOS. Los cuatro dominios apuntaban a las mismas
       carpetas, así que los tres índices especializados quedaban llenos del
       mismo contenido.

    El RAG es conocimiento de DOMINIO (FRTB, Kupiec, Basilea, SR 11-7), externo
    e independiente del modelo evaluado. Por eso vive en su propia carpeta.

    Un dominio sin literatura produce un índice vacío, y el buscador degrada a
    lista vacía: la validación sigue sin contexto RAG. Es el fallo correcto —
    mejor sin contexto que con contexto ajeno.
    """
    return [cfg.RAIZ_PROYECTO / "inputs" / "rag" / dominio]


def ruta_indice(dominio: str) -> Path:
    """Fichero donde se persiste el índice léxico de un dominio."""
    return cfg.INDICE_DIR / f"{dominio}.pkl"


# ═════════════════════════════════════════════════════════════════════════════
# ÍNDICE PERSISTIDO
# ═════════════════════════════════════════════════════════════════════════════

@dataclass
class IndiceLexico:
    """
    Lo que se guarda en disco. Deliberadamente, DATOS y no objetos vivos.

    Qué se persiste y qué no
    ────────────────────────
    Se persiste: el texto de cada chunk, sus metadatos y sus tokens.
    NO se persisten: el objeto `BM25Okapi` ni el `TfidfVectorizer` entrenado.

    Es intencionado. Lo caro del indexado es EXTRAER Y TOKENIZAR los PDF
    (pdfminer sobre un BCBS de 200 páginas domina el tiempo por completo);
    construir BM25 y TF-IDF sobre los tokens ya calculados son milisegundos.
    Guardar solo los datos evita el problema real de picklear objetos de
    sklearn: un pickle de sklearn NO es estable entre versiones de la librería
    —al recargarlo tras un `pip install -U scikit-learn` se obtiene desde un
    warning hasta un objeto silenciosamente roto—. Aquí una actualización de
    sklearn no puede corromper nada, porque lo que se recarga son listas de str.
    """

    dominio: str
    version: int
    chunks: List[Dict[str, Any]] = field(default_factory=list)
    tokens: List[List[str]] = field(default_factory=list)
    huella_fuentes: str = ""
    construido_en: float = 0.0
    # Palabras tal como aparecen en los documentos, ANTES de aplicar el stem.
    #
    # Se guarda para poder corregir erratas de la consulta por parecido
    # ortográfico. Sobre los tokens ya derivados no funciona: «seguimiento» se
    # reduce a «segu», y la distancia entre «seguimeinto» y «segu» es enorme —
    # medido, `difflib` no encontraba nada. Contra la palabra entera, en cambio,
    # «seguimeinto» → «seguimiento» sale a la primera.
    #
    # Cuesta unos pocos KB por dominio (492 palabras en el índice de VaR).
    vocabulario_crudo: set = field(default_factory=set)

    def __len__(self) -> int:
        return len(self.chunks)


# ═════════════════════════════════════════════════════════════════════════════
# INDEXADOR
# ═════════════════════════════════════════════════════════════════════════════

class IndexadorLexico:
    """
    Construye, persiste y recarga el índice léxico de un dominio.

    Args:
        dominio:       "LaR" | "VaR" | "ALM" | "shared"
        chunk_size:    caracteres por chunk (default: config_rag.CHUNK_SIZE)
        chunk_overlap: solapamiento entre chunks
        fuentes:       carpetas a indexar. Default: `inputs/rag/<dominio>/`.
                       Parametrizable para los tests, que no deben depender de
                       que haya PDF reales en el árbol.
    """

    def __init__(
        self,
        dominio: str,
        chunk_size: Optional[int] = None,
        chunk_overlap: Optional[int] = None,
        fuentes: Optional[Sequence[Path]] = None,
        estructural: Optional[bool] = None,
    ):
        self.dominio = dominio
        self.chunk_size = chunk_size or cfg.CHUNK_SIZE
        self.chunk_overlap = chunk_overlap if chunk_overlap is not None else cfg.CHUNK_OVERLAP
        self._fuentes = [Path(f) for f in fuentes] if fuentes else None
        self.ruta = ruta_indice(dominio)
        # [WP · cutover chunking] Chunking ESTRUCTURAL (respeta encabezados, no
        # parte tablas ni fórmulas) como reemplazo OPT-IN del corte por tamaño.
        # Flag EXPLÍCITO centralizado en config (no os.getenv aquí): parámetro
        # directo o cfg.CHUNKING_ESTRUCTURAL (RAG_CHUNKING_ESTRUCTURAL). Queda
        # opt-in (default False): la puerta de recall pasó, pero promoverlo a
        # default rompía un test de integridad de índice acoplado al corte por
        # tamaño — ver docs/evidencia/recall_cutover_dia2.md.
        self.estructural = bool(cfg.CHUNKING_ESTRUCTURAL if estructural is None
                                else estructural)

    # ── Fuentes ──────────────────────────────────────────────────────────────

    def get_source_paths(self) -> List[Path]:
        return self._fuentes if self._fuentes is not None else fuentes_rag(self.dominio)

    def _archivos(self) -> List[Path]:
        """Ficheros indexables de las carpetas fuente, en orden estable."""
        encontrados: List[Path] = []
        for ruta in self.get_source_paths():
            if not ruta.exists():
                continue
            candidatos = sorted(ruta.rglob("*")) if ruta.is_dir() else [ruta]
            for archivo in candidatos:
                if not archivo.is_file():
                    continue
                if archivo.suffix.lower() not in cfg.EXTENSIONES_INDEXABLES:
                    continue
                if archivo.stem.upper() in cfg.NOMBRES_EXCLUIDOS:
                    continue
                encontrados.append(archivo)
        return encontrados

    def _huella_fuentes(self) -> str:
        """
        Huella de (nombre, tamaño, mtime) de los ficheros fuente.

        Sirve para detectar que la literatura cambió sin releer los PDF. Un
        índice cuya huella no coincide con el disco está OBSOLETO, y decirlo es
        mejor que servir en silencio chunks de un documento que ya se sustituyó.
        """
        h = hashlib.sha256()
        for archivo in self._archivos():
            try:
                st = archivo.stat()
                h.update(f"{archivo.name}|{st.st_size}|{int(st.st_mtime)}".encode())
            except OSError:
                h.update(f"{archivo.name}|?".encode())
        return h.hexdigest()[:16]

    # ── Lectura ──────────────────────────────────────────────────────────────

    def _leer_archivo(self, path: Path) -> str:
        """
        Lee un archivo según su extensión (reutiliza los lectores de Mx_01).

        Devuelve "" si no se pudo leer. NUNCA devuelve un mensaje de error como
        si fuera contenido.

        [AUDIT-FIX heredado] El fallback devolvía `f"[No se pudo leer: {name}]"`
        COMO CONTENIDO, y ese texto se troceaba y se indexaba. Medido tras
        indexar el dominio VaR: los chunks recuperados con mayor similitud eran
        literalmente «[No se pudo leer: riskmetrics_summary.md]». El RAG
        inyectaba sus propios errores en el prompt haciéndolos pasar por
        conocimiento experto. Un índice más pequeño es recuperable; uno
        contaminado con mensajes de error envenena todos los prompts en silencio.
        """
        import sys
        raiz = cfg.RAIZ_PROYECTO
        motor_dir = raiz / "motor"
        if motor_dir.is_dir() and str(motor_dir) not in sys.path:
            sys.path.insert(0, str(motor_dir))
        if str(raiz) not in sys.path:
            sys.path.insert(0, str(raiz))

        try:
            from Mx_01_LecturaEvidencias import (
                leer_archivo_generico, _MARCA_LECTURA_FALLIDA,
            )
            texto = leer_archivo_generico(str(path)) or ""
            # Mx_01 prefija sus fallos con un centinela justamente para que el
            # consumidor no los confunda con contenido. Respetarlo.
            if _MARCA_LECTURA_FALLIDA in texto:
                logger.warning("[%s] No se pudo leer %s; se omite del índice.",
                               self.dominio, path.name)
                return ""
            return texto
        except ImportError as exc:
            logger.warning("[%s] Lectores de Mx_01 no disponibles (%s).",
                           self.dominio, exc)
        except Exception as exc:
            logger.warning("[%s] Error leyendo %s: %s", self.dominio, path.name, exc)
            return ""

        # Fallback mínimo: solo texto plano.
        if path.suffix.lower() in (".txt", ".md"):
            try:
                return path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                return ""
        return ""

    # ── Troceado ─────────────────────────────────────────────────────────────

    def _dividir(self, texto: str) -> List[str]:
        """
        Trocea el texto reutilizando el chunker YA EXISTENTE del proyecto.

        `ChunkerService._dividir_en_chunks` es un troceador de texto puro: no
        toca `self.cliente`, así que se instancia con `cliente_ia=None` y NO se
        hace ninguna llamada a la IA. Es deliberado: el índice de búsqueda usa
        el TEXTO CRUDO del chunk, no su resumen. Resumir con IA aquí sería caro
        (una llamada por chunk y por documento) y además contraproducente — un
        resumen pierde justo los tecnicismos literales sobre los que BM25 busca.

        Si el import falla (uso de `src/` fuera del árbol del agente), se cae a
        una ventana deslizante equivalente en vez de quedarse sin índice.
        """
        # Chunking estructural (opt-in): respeta encabezados y no parte tablas ni
        # fórmulas. Se activa solo si pasa la puerta de recall; ver `estructural`.
        if self.estructural:
            try:
                from modulos.chunker_estructural import segmentar_estructural
                trozos = segmentar_estructural(texto, size_max=self.chunk_size)
                if trozos:
                    return trozos
            except Exception as exc:                      # pragma: no cover
                logger.debug("[%s] chunker estructural no disponible (%s); "
                             "cae al corte por tamaño.", self.dominio, exc)

        try:
            from modulos.chunker import ChunkerService
            servicio = ChunkerService(
                cliente_ia=None,
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
            )
            return servicio._dividir_en_chunks(texto)
        except Exception as exc:                          # pragma: no cover
            logger.debug("[%s] chunker.py no disponible (%s); ventana propia.",
                         self.dominio, exc)
            paso = max(self.chunk_size - self.chunk_overlap, 1)
            trozos, inicio = [], 0
            while inicio < len(texto):
                fin = min(inicio + self.chunk_size, len(texto))
                trozos.append(texto[inicio:fin])
                if fin == len(texto):
                    break
                inicio += paso
            return trozos

    # ── Construcción ─────────────────────────────────────────────────────────

    def construir(self, force: bool = False) -> IndiceLexico:
        """
        Construye el índice y lo persiste.

        Args:
            force: si False (default) y hay un índice en disco vigente —misma
                   versión de formato y misma huella de fuentes—, se reutiliza
                   sin releer los PDF.

        Returns:
            El `IndiceLexico` resultante (vacío si el dominio no tiene fuentes).
        """
        if not force:
            existente = self.cargar()
            if existente is not None:
                logger.info("[%s] Índice vigente en disco: %d chunks.",
                            self.dominio, len(existente))
                return existente

        t0 = time.perf_counter()
        chunks: List[Dict[str, Any]] = []
        archivos = self._archivos()

        for archivo in archivos:
            texto = self._leer_archivo(archivo)
            if not texto.strip():
                continue
            trozos = self._dividir(texto)
            for i, trozo in enumerate(trozos):
                if not trozo.strip():
                    continue
                chunks.append({
                    # El ID incorpora fuente y posición: único por chunk y
                    # ESTABLE entre reindexaciones del mismo documento.
                    "id": hashlib.sha256(
                        f"{archivo.name}|{i}|{trozo}".encode()
                    ).hexdigest()[:16],
                    "texto": trozo,
                    "fuente": archivo.name,
                    "ruta": str(archivo),
                    "dominio": self.dominio,
                    "chunk": i,
                    "n_chunks_doc": len(trozos),
                })
            logger.info("  ✓ %s: %d chunks", archivo.name, len(trozos))

        tokens = [tokenizar(c["texto"]) for c in chunks]

        indice = IndiceLexico(
            dominio=self.dominio,
            version=cfg.VERSION_INDICE,
            chunks=chunks,
            tokens=tokens,
            huella_fuentes=self._huella_fuentes(),
            construido_en=time.time(),
            vocabulario_crudo=vocabulario_crudo(c["texto"] for c in chunks),
        )

        # Un índice VACÍO no se escribe. Detectado en la entrega: al consultar
        # un dominio sin literatura, el buscador autoconstruía y aquí se
        # persistía un .pkl de 193 bytes en la carpeta de índices de PRODUCCIÓN.
        # Apareció allí `dominio_que_no_existe.pkl`, creado por un test.
        #
        # No es solo suciedad. Un fichero vacío en esa carpeta significa «este
        # dominio está indexado» para cualquiera que la mire —incluido
        # `--status`—, cuando lo cierto es que no hay nada que buscar. Y en
        # Databricks, DBFS acumularía un fichero por cada dominio mal escrito
        # que alguien consultara.
        #
        # Devolverlo sin escribirlo conserva el comportamiento correcto: el
        # buscador recibe un índice vacío, degrada a lista vacía y la validación
        # continúa sin contexto RAG.
        if not chunks:
            logger.info("[%s] Sin documentos indexables en %s; no se escribe "
                        "índice.", self.dominio,
                        ", ".join(str(f) for f in self.get_source_paths()) or "(sin fuentes)")
            return indice

        self._persistir(indice)

        transcurrido = time.perf_counter() - t0
        logger.info("[%s] Índice léxico construido: %d chunks de %d documentos "
                    "en %.2fs.", self.dominio, len(chunks), len(archivos),
                    transcurrido)
        return indice

    # ── Persistencia ─────────────────────────────────────────────────────────

    def _persistir(self, indice: IndiceLexico) -> None:
        """
        Escribe el índice de forma ATÓMICA (temporal + replace).

        Sin esto, una interrupción a mitad de escritura —Ctrl-C, un job de
        Databricks que se queda sin tiempo— deja un .pkl truncado en la ruta
        oficial. `pickle.load` de un fichero truncado lanza EOFError, que
        `cargar()` trata como «no hay índice» y dispara una reconstrucción
        completa: la corrida siguiente paga la extracción de todos los PDF sin
        que nadie entienda por qué. `os.replace` es atómico también en Windows.
        """
        self.ruta.parent.mkdir(parents=True, exist_ok=True)
        temporal = self.ruta.with_suffix(".pkl.tmp")
        with open(temporal, "wb") as fh:
            pickle.dump(indice, fh, protocol=pickle.HIGHEST_PROTOCOL)
        os.replace(temporal, self.ruta)

    def cargar(self, verificar_huella: bool = True) -> Optional[IndiceLexico]:
        """
        Recarga el índice persistido. Devuelve None si no sirve.

        Devuelve None —y NO una excepción— en los cuatro casos en que el índice
        no es utilizable: no existe, está corrupto, es de un formato anterior, o
        las fuentes cambiaron desde que se construyó. El llamante reconstruye.

        Args:
            verificar_huella: si False, acepta un índice cuyas fuentes cambiaron.
                              Útil para consultar sin poder reindexar (un job de
                              solo lectura, o un entorno sin `inputs/`).
        """
        if not self.ruta.exists():
            return None
        try:
            with open(self.ruta, "rb") as fh:
                indice = pickle.load(fh)
        except Exception as exc:
            logger.warning("[%s] Índice ilegible (%s); se reconstruirá.",
                           self.dominio, exc)
            return None

        if not isinstance(indice, IndiceLexico):
            logger.warning("[%s] Índice de tipo inesperado; se reconstruirá.",
                           self.dominio)
            return None
        if indice.version != cfg.VERSION_INDICE:
            logger.warning("[%s] Índice v%s ≠ formato actual v%s; se reconstruirá.",
                           self.dominio, indice.version, cfg.VERSION_INDICE)
            return None
        if verificar_huella and indice.huella_fuentes != self._huella_fuentes():
            logger.info("[%s] La literatura de referencia cambió; se reindexa.",
                        self.dominio)
            return None
        return indice

    def estado(self) -> Dict[str, Any]:
        """Diagnóstico para `rebuild_rag_databricks.py --status`."""
        indice = self.cargar(verificar_huella=False)
        vigente = indice is not None and indice.huella_fuentes == self._huella_fuentes()
        return {
            "dominio": self.dominio,
            "ruta": str(self.ruta),
            "existe": self.ruta.exists(),
            "chunks": len(indice) if indice else 0,
            "documentos": len({c["fuente"] for c in indice.chunks}) if indice else 0,
            "vigente": vigente,
            "fuentes_en_disco": len(self._archivos()),
            "construido_en": indice.construido_en if indice else 0.0,
        }
