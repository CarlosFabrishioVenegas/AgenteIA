"""
src/rag/buscador_lexico.py
═════════════════════════════════════════════════════════════════════════════
Consulta el índice léxico de un dominio y devuelve los top-K chunks.

Combina dos señales sobre el MISMO vocabulario tokenizado:

  BM25 (rank_bm25.BM25Okapi) — señal principal, peso 0.7.
      Premia la coincidencia exacta de término, ponderada por rareza en el
      corpus (IDF) y saturada por frecuencia y longitud del chunk. Es el
      algoritmo de Elasticsearch/Lucene.

  TF-IDF + coseno (scikit-learn) — señal secundaria, peso 0.3.
      Mide el solape del VECTOR completo de la consulta con el del chunk,
      incluyendo bigramas. Corrige el punto flaco de BM25: un chunk que acierta
      un término muy raro puede escalar al primer puesto aunque no comparta
      nada más con la consulta. El coseno le baja el voto.

Ninguna de las dos llama a la red. Ninguna depende de HuggingFace.

Uso:
    from src.rag.buscador_lexico import BuscadorLexico
    b = BuscadorLexico("VaR")
    for r in b.buscar("backtesting de excepciones Kupiec", top_k=5):
        print(r["score"], r["fuente"], r["texto"][:120])
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

# `import src.rag.config_rag` y NO `from src.rag import config_rag`: la segunda
# forma ejecuta `src/rag/__init__.py` —el dispatcher— y crea un ciclo
# src.rag → …retriever → base_retriever → buscador_lexico → src.rag que el
# validador de arquitectura detecta y rechaza. La forma de abajo referencia el
# submódulo directamente y no toca el paquete.
import src.rag.config_rag as cfg
from src.rag.indexador_lexico import (
    IndexadorLexico, IndiceLexico, tokenizar, texto_normalizado_para_tfidf,
)

logger = logging.getLogger("virf.rag")

__all__ = ["BuscadorLexico", "get_buscador"]


class BuscadorLexico:
    """
    Buscador léxico de un dominio. Carga perezosa y caché en proceso.

    El índice se carga la PRIMERA vez que se consulta, no al construir el
    objeto: `motor_ia` instancia un retriever por dominio al arrancar, y pagar
    la deserialización de cuatro índices para usar uno solo es tiempo tirado.
    """

    def __init__(self, dominio: str, autoconstruir: bool = True):
        """
        Args:
            dominio:       "LaR" | "VaR" | "ALM" | "shared"
            autoconstruir: si no hay índice en disco (o está obsoleto), lo
                           construye al vuelo. En un job de solo lectura se pone
                           a False: entonces un índice ausente devuelve [] en
                           vez de disparar la extracción de todos los PDF en
                           mitad de una validación.
        """
        self.dominio = dominio
        self.autoconstruir = autoconstruir
        self._indexador = IndexadorLexico(dominio)
        self._indice: Optional[IndiceLexico] = None
        self._bm25 = None
        self._vectorizador = None
        self._matriz_tfidf = None
        self._cargado = False

    # ── Carga ────────────────────────────────────────────────────────────────

    def _asegurar_cargado(self) -> bool:
        """
        Carga el índice y construye las dos estructuras en memoria.

        Returns:
            True si hay un índice consultable con al menos un chunk.
        """
        if self._cargado:
            return self._indice is not None and len(self._indice) > 0

        self._cargado = True   # se marca antes: un fallo no debe reintentarse
                               # en cada actividad evaluada del informe.
        try:
            indice = self._indexador.cargar()
            if indice is None and self.autoconstruir:
                indice = self._indexador.construir(force=True)
            if indice is None or len(indice) == 0:
                logger.warning(
                    "[%s] Sin índice léxico (¿falta literatura en inputs/rag/%s/?). "
                    "La validación continúa sin contexto RAG.",
                    self.dominio, self.dominio)
                return False
            self._indice = indice
        except Exception as exc:
            logger.warning("[%s] No se pudo cargar el índice léxico: %s", self.dominio, exc)
            return False

        try:
            self._construir_estructuras()
        except Exception as exc:
            logger.warning("[%s] No se pudieron construir las estructuras de "
                           "búsqueda: %s", self.dominio, exc)
            self._indice = None
            return False
        return True

    def _construir_estructuras(self) -> None:
        """
        Levanta BM25 y TF-IDF sobre los tokens ya persistidos. Milisegundos.

        TF-IDF es OPCIONAL de verdad: si `scikit-learn` no está instalado, el
        buscador sigue funcionando solo con BM25 en vez de caerse. La calidad
        baja un punto; la disponibilidad no. BM25 sí es obligatorio — sin él no
        hay búsqueda que degradar.
        """
        from rank_bm25 import BM25Okapi

        tokens = self._indice.tokens
        self._bm25 = BM25Okapi(tokens, k1=cfg.BM25_K1, b=cfg.BM25_B)

        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            # `analyzer` recibe el texto ya tokenizado por NOSOTROS y solo lo
            # parte por espacios: así BM25 y TF-IDF puntúan sobre el mismo
            # vocabulario. Si sklearn tokenizara a su manera, el peso 0.7/0.3
            # estaría mezclando dos medidas de cosas distintas.
            corpus = [" ".join(t) for t in tokens]
            self._vectorizador = TfidfVectorizer(
                analyzer="word",
                token_pattern=r"\S+",
                ngram_range=(1, cfg.TFIDF_NGRAM_MAX),
                min_df=cfg.TFIDF_MIN_DF,
                sublinear_tf=True,
            )
            self._matriz_tfidf = self._vectorizador.fit_transform(corpus)
        except Exception as exc:
            logger.info("[%s] TF-IDF no disponible (%s); se busca solo con BM25.",
                        self.dominio, exc)
            self._vectorizador = None
            self._matriz_tfidf = None

    # ── Expansión de la consulta ─────────────────────────────────────────────

    def _tesauro(self):
        """Tesauro de dominio, cargado una vez por buscador."""
        if getattr(self, "_tesauro_cache", None) is None:
            from src.rag.tesauro import cargar_tesauro
            try:
                self._tesauro_cache = cargar_tesauro(cfg.TESAURO_PATH)
            except Exception as exc:                      # pragma: no cover
                logger.warning("[%s] Tesauro no disponible (%s); sin expansión.",
                               self.dominio, exc)
                self._tesauro_cache = {}
        return self._tesauro_cache

    def _expandir(self, tokens):
        """
        Tokens de la consulta → CONCEPTOS, cada uno con sus variantes buscables.

        Ésta es la cura del punto ciego de la búsqueda léxica. BM25 encuentra por
        coincidencia de cadena, así que «excepciones» y «excedencias» —sinónimos
        exactos en backtesting de VaR— eran términos distintos y uno de los dos
        no encontraba nada.

        Dos mecanismos, en este orden:

        1. TESAURO de dominio. Conocimiento externo escrito por un experto. Es
           lo ÚNICO que puede resolver el caso real, y conviene entender por qué:
           «excepcion» tiene df=0, no aparece ni una vez en el corpus. Cualquier
           método derivado del corpus —co-ocurrencia, LSA/SVD sobre la matriz
           TF-IDF, que sería local y estaría a mano— necesita que el término
           APAREZCA para aprender algo de él. No se puede inferir la relación
           entre una palabra que está y otra que no está.

        2. CORRECCIÓN DE ERRATAS por parecido ortográfico, solo para los tokens
           que NO existen en el corpus. Resuelve las erratas del propio estándar
           («seguimeinto» → «seguimiento»), que si no jamás casan con nada.

           Se compara contra el vocabulario CRUDO, sin stem. Contra los tokens
           derivados no funciona: «seguimiento» se reduce a «segu», y la
           distancia hasta «seguimeinto» es enorme — medido, `difflib` no
           encontraba nada. Contra la palabra entera sale a la primera.

           Solo se intenta sobre términos de df=0, que aportan cero por
           definición: corregirlos o deja las cosas igual o las mejora. Nunca
           puede empeorar un resultado.

        Returns:
            (conceptos, expansiones)
            · conceptos: lista de conjuntos de tokens. Cada conjunto son las
              variantes de UNA idea; cubrir cualquiera de ellas cubre la idea.
            · expansiones: qué se añadió y por qué, para poder auditarlo. En un
              informe de validación hay que poder explicar que el sistema buscó
              «excedencia» cuando el estándar decía «excepción».
        """
        indice_idf = getattr(self._bm25, "idf", {}) or {}
        vocab_crudo = getattr(self._indice, "vocabulario_crudo", None) or set()
        tesauro, frases = self._tesauro() if cfg.TESAURO_ACTIVO else ({}, {})

        # Expansión por FRASE: «valor en riesgo» → «var». La expansión token a
        # token no puede hacerlo, porque «valor» por sí solo no significa VaR.
        # Solo se dispara si TODOS los tokens de la expresión están presentes.
        presentes = set(tokens)
        siglas_por_frase = set()
        for combinacion, siglas in frases.items():
            if set(combinacion) <= presentes:
                utiles = {s for s in siglas if indice_idf.get(s, 0.0) > 0}
                if utiles:
                    siglas_por_frase |= utiles

        conceptos, expansiones = [], []
        if siglas_por_frase:
            # Entra como concepto PROPIO y no pegado a un token cualquiera de la
            # frase: la sigla es una idea completa, y repartirla entre «valor» y
            # «riesgo» falsearía el peso de ambos.
            conceptos.append(set(siglas_por_frase))
            expansiones.append({"origen": "(expresión)", "tipo": "frase",
                                "añadidos": sorted(siglas_por_frase)})

        for token in dict.fromkeys(tokens):               # únicos, en orden
            variantes = {token}

            if tesauro:
                nuevas = tesauro.get(token, set())
                # Solo interesan las variantes que EXISTEN en este corpus:
                # añadir sinónimos que tampoco están no aporta y ensucia el
                # peso informativo.
                utiles = {v for v in nuevas if indice_idf.get(v, 0.0) > 0}
                if utiles:
                    variantes |= utiles
                    expansiones.append({"origen": token, "tipo": "tesauro",
                                        "añadidos": sorted(utiles)})

            if (cfg.CORREGIR_ERRATAS and vocab_crudo
                    and indice_idf.get(token, 0.0) <= 0
                    and not any(indice_idf.get(v, 0.0) > 0 for v in variantes)):
                import difflib
                from src.rag.indexador_lexico import tokenizar as _tok
                similares = difflib.get_close_matches(
                    token, vocab_crudo, n=1, cutoff=cfg.UMBRAL_ERRATA)
                if similares:
                    corregidos = {t for t in _tok(similares[0])
                                  if indice_idf.get(t, 0.0) > 0}
                    if corregidos:
                        variantes |= corregidos
                        expansiones.append({"origen": token, "tipo": "errata",
                                            "añadidos": sorted(corregidos),
                                            "palabra": similares[0]})

            conceptos.append(variantes)

        if expansiones:
            logger.debug("[%s] Consulta expandida: %s", self.dominio, expansiones)
        return conceptos, expansiones

    # ── Consulta ─────────────────────────────────────────────────────────────

    def buscar(
        self,
        consulta: str,
        top_k: Optional[int] = None,
        filtro_fuente: Optional[str] = None,
        tenant: Optional[str] = None,
        modelo: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Devuelve los top-K chunks más relevantes para la consulta.

        Args:
            consulta:      texto libre. Se tokeniza igual que los chunks.
            top_k:         cuántos devolver (default: config_rag.TOP_K_DEFECTO).
            filtro_fuente: si se indica, solo chunks de ese nombre de fichero.

        Returns:
            Lista de dicts ordenada por `score` descendente, con claves:
              texto, fuente, ruta, dominio, chunk,
              cobertura      ← RELEVANCIA ABSOLUTA [0,1]. Es la que se reporta.
              score          ← POSICIÓN RELATIVA [0,1]. Solo ordena.
              score_bm25, score_tfidf, bm25_bruto, cobertura_terminos,
              peso_informativo_consulta

            Lista VACÍA si no hay índice, si la consulta no deja tokens útiles,
            o si ningún chunk alcanza la cobertura mínima. Nunca lanza: el RAG
            es un enriquecimiento del prompt, y que falle no puede tumbar una
            validación.

        ══ DOS NÚMEROS, DOS TRABAJOS ═══════════════════════════════════════
        Es la corrección del defecto de diseño que tenía la versión anterior,
        donde un único `score` hacía los dos trabajos y no podía hacer bien
        ninguno. Conviene entender por qué son necesariamente distintos.

        `score` — POSICIÓN RELATIVA. Ordena, no mide.
            BM25 no tiene techo: sus valores brutos dependen del corpus, de la
            longitud de la consulta y de cuántos términos raros contenga. Para
            poder combinarlo con el coseno hay que normalizarlo, y se hace
            contra el máximo de ESTA consulta. Consecuencia inevitable: el mejor
            fragmento saca 1.00 SIEMPRE, aunque el corpus sea pésimo.

            Eso está bien para ordenar y es inútil para decidir si algo es
            relevante. Por eso `score` ya NO se reporta como «relevancia» ni
            gobierna el umbral: solo ordena.

        `cobertura` — RELEVANCIA ABSOLUTA. Mide, y es comparable entre consultas.
            Fracción del PESO INFORMATIVO de la consulta que este fragmento
            cubre, medido en IDF:

                cobertura = Σ IDF(t) para t en (consulta ∩ chunk)
                            ─────────────────────────────────────
                            Σ IDF(t) para t en consulta

            Ponderar por IDF y no contar términos a pelo importa: acertar
            «kupiec» (raro) vale más que acertar «numero» (común). Y arregla de
            paso una injusticia — un término que NO existe en el corpus tiene
            IDF 0, así que ahora desaparece del numerador Y del denominador en
            vez de penalizar al fragmento por no contener algo que nadie
            contiene (el caso «excepciones» vs. «excedencias»).

        ── El tercer número: `peso_informativo_consulta` ────────────────────
        Σ IDF(t) sobre la consulta entera. No describe al fragmento: describe a
        la CONSULTA, y es lo que faltaba para cerrar el agujero.

        Medido en este corpus: «estacionariedad EWMA» → 6.51 · «backtesting
        Kupiec» → 1.76 · «modelo» → 0.41 · términos de VaR preguntados al
        dominio LaR → 0.00.

        Que la consulta «modelo» dé cobertura 1.00 en todos los fragmentos NO es
        un fallo del cálculo: es una afirmación CIERTA sobre una consulta que no
        pregunta nada. Ningún reajuste del score del fragmento puede arreglar
        una consulta vacía de información — lo que hay que hacer es DECIRLO, y
        por eso se registra un warning cuando el peso cae por debajo del umbral.
        """
        if top_k is None:
            top_k = cfg.TOP_K_DEFECTO
        if not self._asegurar_cargado():
            return []

        tokens_consulta = tokenizar(consulta)
        if not tokens_consulta:
            logger.debug("[%s] La consulta no deja tokens útiles: %r",
                         self.dominio, consulta[:80])
            return []

        t0 = time.perf_counter()
        chunks = self._indice.chunks

        # Expansión: sinónimos del tesauro + corrección de erratas. Cada
        # «concepto» es un conjunto de tokens intercambiables.
        conceptos, expansiones = self._expandir(tokens_consulta)
        tokens_efectivos = [t for c in conceptos for t in c]

        bm25_bruto = self._bm25.get_scores(tokens_efectivos)

        # ── Señal secundaria: coseno TF-IDF ──────────────────────────────────
        tfidf = [0.0] * len(chunks)
        if self._vectorizador is not None:
            try:
                from sklearn.metrics.pairwise import cosine_similarity
                vec = self._vectorizador.transform([texto_normalizado_para_tfidf(consulta)])
                tfidf = cosine_similarity(vec, self._matriz_tfidf)[0].tolist()
            except Exception as exc:                      # pragma: no cover
                logger.debug("[%s] Coseno TF-IDF falló (%s); solo BM25.",
                             self.dominio, exc)

        # ── Qué chunk es candidato ───────────────────────────────────────────
        # El filtro es la COBERTURA (¿comparte algún término con la consulta?),
        # no la puntuación BM25. Parece equivalente y no lo es.
        #
        # Descubierto probando con un corpus de dos documentos: `BM25Okapi`
        # calcula el IDF como `log(N - df + 0.5) - log(df + 0.5)`, sin el «+1»
        # que otras variantes añaden dentro del logaritmo. Con N=2 y df=1 eso da
        # log(1.5) - log(1.5) = EXACTAMENTE 0, así que un término que aparece en
        # uno de los dos documentos no vale nada y la consulta entera puntúa 0.
        # El caso general es «un término presente en la mitad o más del corpus
        # no discrimina», que es correcto y deseable en un corpus grande; en uno
        # de decenas de chunks —que es el tamaño de estos índices de dominio—
        # se dispara constantemente.
        #
        # `rank_bm25` tiene un `epsilon` para esto, pero solo repara los IDF
        # NEGATIVOS: el cero pasa de largo. Filtrar por cobertura evita el
        # problema de raíz, porque mide el solape real y no depende de la
        # estadística del corpus.
        unicos_consulta = set(tokens_efectivos)

        # ── Peso informativo de la CONSULTA ──────────────────────────────────
        # Σ IDF de sus términos. No describe a ningún fragmento: describe a la
        # pregunta, y es lo que permite distinguir «esta consulta no encuentra
        # nada» de «esta consulta no pregunta nada».
        #
        # Un término ausente del corpus tiene IDF 0 y por tanto no suma. Si la
        # suma entera es ~0, la consulta no aporta información distintiva contra
        # ESTE corpus: o son todo palabras omnipresentes («modelo», «datos»), o
        # se está preguntando al dominio equivocado. En ambos casos lo que salga
        # tendrá poco valor, y callarlo es lo que hacía que el RAG devolviera
        # ruido con aspecto de certeza.
        # Se suma POR CONCEPTO, no por token: si el tesauro añadió «exced» como
        # variante de «excepcion», son la MISMA idea y contarlas dos veces
        # inflaría el peso de esa parte de la consulta y desinflaría la cobertura
        # de todo lo demás. Cada concepto vale lo que valga su mejor variante.
        idf = getattr(self._bm25, "idf", {}) or {}
        peso_concepto = [max((max(idf.get(t, 0.0), 0.0) for t in c), default=0.0)
                         for c in conceptos]
        peso_informativo = sum(peso_concepto)

        # [AUDIT-FIX 2026-08-07] RECONOCIMIENTO DE LA CONSULTA.
        #
        # `cobertura` se divide entre `peso_informativo`, que suma solo los
        # conceptos con IDF > 0 — es decir, EXCLUYE del denominador justo los
        # términos que el corpus no conoce. Efecto medido: la consulta «modelo
        # de scoring de admisión de tarjetas de crédito» contra el corpus VaR
        # devolvía `FRTB_BCBS457_riesgo_mercado.pdf` con «cubre el 100% de los
        # términos clave». Literalmente cierto —de los términos que el corpus
        # conoce («modelo», «crédito») los cubre todos— y engañoso: «scoring»,
        # «admisión» y «tarjetas», que son los que definen la pregunta, valían
        # 0 y desaparecían de la cuenta.
        #
        # Se mide aparte QUÉ FRACCIÓN de la consulta reconoce el corpus. Es el
        # número que distingue «este corpus responde a la pregunta» de «este
        # corpus no sabe de qué le hablan, pero algo devuelve».
        # Se mide QUÉ FRACCIÓN de la consulta reconoce el corpus y, sobre todo,
        # QUÉ TÉRMINOS no conoce.
        #
        # El porcentaje solo NO discrimina —medido: «backtesting de Kupiec y
        # ventana de 500 días» reconoce el 60 % (le faltan «ventana» y «500») y
        # la consulta de otro dominio también el 60 %—, así que un umbral sobre
        # él produciría falsos positivos sobre consultas legítimas. Lo que sí
        # informa siempre es la LISTA: «no conozco: scoring, tarjetas» dice al
        # lector exactamente qué parte de la pregunta se quedó sin cubrir, y es
        # un hecho, no una heurística.
        _n_conceptos = len(conceptos) or 1
        _n_reconocidos = sum(1 for p in peso_concepto if p > 0)
        reconocimiento = _n_reconocidos / _n_conceptos
        terminos_no_reconocidos = sorted(
            {next(iter(c)) for c, p in zip(conceptos, peso_concepto)
             if p <= 0 and c})
        if peso_informativo < cfg.PESO_INFORMATIVO_MINIMO:
            logger.warning(
                "[%s] Consulta de bajo poder discriminante (peso informativo "
                "%.2f < %.2f): %r. Sus términos son omnipresentes en este corpus "
                "o no aparecen en él. Lo que se recupere tendrá poco valor.",
                self.dominio, peso_informativo, cfg.PESO_INFORMATIVO_MINIMO,
                consulta[:80])

        # [WP-10 · versionado] Pre-filtro duro de vigencia. Un chunk marcado
        # is_active=False (metodología derogada) NO se recupera: no se valida
        # código de 2026 contra normas retiradas. Aditivo — un chunk sin
        # metadatos de versión se considera activo, así que el corpus actual
        # (que no los lleva) no cambia de comportamiento.
        from modulos.versionado import chunk_activo

        candidatos = []
        for i, chunk in enumerate(chunks):
            if filtro_fuente and chunk["fuente"] != filtro_fuente:
                continue
            if not chunk_activo(chunk):
                continue
            tokens_chunk = set(self._indice.tokens[i])
            comunes = unicos_consulta & tokens_chunk
            if not comunes:
                # Ni un término en común. No es «poco relevante», es «no
                # relevante»: incluirlo solo sirve para rellenar el top-K con
                # ruido que el prompt presentará como conocimiento recuperado.
                continue

            # COBERTURA ABSOLUTA, ponderada por IDF y contada POR CONCEPTO: un
            # fragmento que dice «excedencia» cubre el concepto que la consulta
            # escribió como «excepción». Es el número que se reporta y el que
            # gobierna el umbral. Ver el docstring del método.
            if peso_informativo > 0:
                cubierto = sum(p for c, p in zip(conceptos, peso_concepto)
                               if c & tokens_chunk)
                cobertura = cubierto / peso_informativo
            else:
                # Todos los términos tienen IDF 0 (corpus diminuto o consulta de
                # puras palabras comunes). El reparto por IDF no significa nada
                # aquí, así que se cae a contar términos, que al menos ordena.
                cobertura = len(comunes) / len(unicos_consulta)

            if cobertura < cfg.MIN_COBERTURA:
                continue
            candidatos.append((i, chunk, cobertura,
                               len(comunes) / len(unicos_consulta)))

        if not candidatos:
            logger.debug("[%s] Ningún chunk alcanza la cobertura mínima (%.2f).",
                         self.dominio, cfg.MIN_COBERTURA)
            return []

        max_bm25 = max(float(bm25_bruto[i]) for i, _, _, _ in candidatos)
        max_tfidf = max(tfidf[i] for i, _, _, _ in candidatos) if tfidf else 0.0

        peso_total = cfg.PESO_BM25 + cfg.PESO_TFIDF
        if peso_total <= 0:                               # pragma: no cover
            peso_total = 1.0

        # Caso degenerado: hay solape léxico pero las dos señales lo puntúan a
        # cero, porque todos los términos de la consulta son omnipresentes en
        # este corpus. Ordenar por cobertura es lo único que queda con sentido —
        # y es mejor que devolver [] fingiendo que no hay nada, o que devolver
        # todo en el orden arbitrario del índice.
        degenerado = max_bm25 <= 0 and max_tfidf <= 0
        if degenerado:
            logger.debug("[%s] BM25 y TF-IDF a cero (corpus pequeño, términos "
                         "omnipresentes); se ordena por cobertura.", self.dominio)

        resultados: List[Dict[str, Any]] = []
        for i, chunk, cobertura, cob_terminos in candidatos:
            bruto = float(bm25_bruto[i])
            s_bm25 = (bruto / max_bm25) if max_bm25 > 0 else 0.0
            s_tfidf = (tfidf[i] / max_tfidf) if max_tfidf > 0 else 0.0
            if degenerado:
                score = cobertura
            else:
                score = (cfg.PESO_BM25 * s_bm25 + cfg.PESO_TFIDF * s_tfidf) / peso_total

            resultados.append({
                "texto": chunk["texto"],
                "fuente": chunk["fuente"],
                "ruta": chunk.get("ruta", ""),
                "dominio": chunk.get("dominio", self.dominio),
                "chunk": chunk.get("chunk", 0),
                # RELEVANCIA ABSOLUTA — la que se reporta y la que se compara
                # entre consultas.
                "cobertura": round(cobertura, 4),
                # POSICIÓN RELATIVA — solo ordena. El primero saca 1.0 siempre.
                "score": round(score, 4),
                "score_bm25": round(s_bm25, 4),
                "score_tfidf": round(s_tfidf, 4),
                "bm25_bruto": round(bruto, 4),
                "cobertura_terminos": round(cob_terminos, 3),
                "peso_informativo_consulta": round(peso_informativo, 3),
                # Qué fracción de la CONSULTA reconoce siquiera este corpus.
                # Baja = se está preguntando al dominio equivocado, por muy
                # alta que salga `cobertura`.
                "reconocimiento_consulta": round(reconocimiento, 3),
                "terminos_no_reconocidos": terminos_no_reconocidos,
                # Qué sinónimos o correcciones se aplicaron. En un informe de
                # validación hay que poder explicar que el sistema buscó
                # «excedencia» cuando el estándar decía «excepción».
                "expansiones": expansiones,
            })

        # Desempate por bm25_bruto: con dos chunks al mismo score combinado,
        # gana el que más coincidencia literal tiene. Sin criterio explícito el
        # orden lo decidiría la posición en el índice, que es arbitraria y
        # además cambia al reindexar — el mismo informe daría distinto contexto.
        resultados.sort(key=lambda r: (r["score"], r["bm25_bruto"]), reverse=True)

        # [WP-02 · aislamiento] Hard pre-filter opcional por (tenant, modelo),
        # ADICIONAL al de dominio. Solo actúa si el llamante lo pide; por defecto
        # (None) el comportamiento es idéntico al histórico. Se filtra ANTES de
        # recortar a top_k para que el tope cuente solo fragmentos del tenant
        # activo, y se asevera que nada ajeno sobrevive (defensa en profundidad).
        if tenant is not None or modelo is not None:
            from modulos.aislamiento import (assert_sin_contaminacion,
                                             filtrar_por_tenant)
            resultados = filtrar_por_tenant(resultados, tenant, modelo)
            assert_sin_contaminacion(resultados, tenant, modelo)

        resultados = resultados[:top_k]

        logger.debug("[%s] Consulta resuelta en %.1f ms sobre %d chunks (%d resultados).",
                     self.dominio, (time.perf_counter() - t0) * 1000,
                     len(chunks), len(resultados))
        return resultados

    # ── Formato para prompt ──────────────────────────────────────────────────

    def buscar_para_prompt(
        self,
        consulta: str,
        top_k: Optional[int] = None,
        min_score: Optional[float] = None,
    ) -> str:
        """
        Versión lista para inyectar en el prompt de evaluación.

        Devuelve "" si no hay nada por encima del umbral — y "" es la señal que
        `motor_ia` interpreta como «sin contexto RAG», no un bloque vacío con
        cabecera. Un encabezado «Conocimiento recuperado» sin contenido debajo
        invita al modelo a inventarse qué había ahí.

        ── Qué número ve el modelo (y acaba en el informe) ──────────────────
        La `cobertura` ABSOLUTA, no el `score` relativo. Es la corrección del
        defecto que motivó todo esto: antes se etiquetaba cada fragmento como
        «relevancia léxica: 1.00» usando el score relativo, de modo que el mejor
        resultado de CUALQUIER consulta —incluida una que el corpus no cubre—
        llegaba al prompt anunciado como coincidencia perfecta. El modelo no
        tenía forma de saber que ese 1.00 solo significaba «el primero de la
        lista», y un lector del informe tampoco.

        Ahora la etiqueta dice qué fracción del peso informativo de la pregunta
        cubre realmente el fragmento, que sí es comparable entre consultas: un
        0.35 es un 0.35 aquí y en cualquier otra búsqueda.
        """
        if min_score is None:
            min_score = cfg.MIN_SCORE_DEFECTO

        resultados = self.buscar(consulta, top_k=top_k)
        # El umbral se aplica sobre `score` (posición relativa) porque ése es su
        # significado histórico y el que documenta RAG_MIN_SCORE: recortar la
        # cola de la lista. El corte ABSOLUTO ya lo hizo `buscar()` con
        # RAG_MIN_COBERTURA, antes de puntuar nada.
        relevantes = [r for r in resultados if r["score"] >= min_score]
        if not relevantes:
            return ""

        partes = [f"## Conocimiento recuperado — dominio: {self.dominio}\n"]

        # El bloque declara su propia incertidumbre. Cuando la consulta no
        # discrimina, sus fragmentos salen con cobertura alta —es cierto: cubren
        # una pregunta que no pregunta nada— y sin este aviso el modelo los
        # leería como referencia sólida. Decirlo aquí es lo que convierte una
        # advertencia de manual, que nadie lee en el momento oportuno, en una
        # salvaguarda que viaja pegada al dato.
        peso = relevantes[0].get("peso_informativo_consulta", 0.0)
        if peso < cfg.PESO_INFORMATIVO_MINIMO:
            partes.append(
                "> ⚠️ AVISO: los términos de esta búsqueda son poco distintivos en "
                "este corpus.\n"
                "> Los fragmentos siguientes pueden no ser específicos de la "
                "cuestión evaluada:\n"
                "> trátalos como contexto de fondo, no como referencia que "
                "confirme o refute nada.\n"
            )

        # [AUDIT-FIX 2026-08-07] Si el corpus no reconoce buena parte de la
        # consulta, decirlo ARRIBA y una sola vez. Antes solo se rotulaba la
        # cobertura —que puede ser 100% sobre los términos que el corpus sí
        # conoce— y el modelo recibía literatura de otro dominio presentada
        # como pericia pertinente, sin ninguna señal de que no lo era.
        _recon = min((r.get("reconocimiento_consulta", 1.0) for r in relevantes),
                     default=1.0)
        _ausentes = []
        for r in relevantes:
            for t in r.get("terminos_no_reconocidos") or []:
                if t not in _ausentes:
                    _ausentes.append(t)
        if _ausentes:
            partes.append(
                f"> ⚠️ ALCANCE DE ESTE CORPUS: no contiene los términos "
                f"«{'», «'.join(_ausentes[:8])}» de la cuestión evaluada "
                f"(reconoce {_recon:.0%} de ella).\n"
                "> Lo que sigue se recuperó por los términos restantes y puede "
                "pertenecer a otro asunto.\n"
                "> NO afirmes qué exige la práctica estándar sobre lo que el "
                "corpus no cubre: decláralo\n"
                "> como limitación de alcance.\n"
            )

        for i, r in enumerate(relevantes, 1):
            # «los términos clave QUE ESTE CORPUS CONOCE», no «de la consulta»:
            # el denominador excluye lo que el corpus ignora, y la redacción
            # anterior hacía leer un 100 % como «cubre toda la pregunta».
            partes.append(
                f"### [{i}] Fuente: {r['fuente']} "
                f"(cubre el {r['cobertura']:.0%} de los términos clave que este "
                f"corpus conoce)\n"
                f"{r['texto'].strip()}\n"
            )
        return "\n".join(partes)

    def diagnostico_consulta(self, consulta: str) -> Dict[str, Any]:
        """
        Qué tan buena es una CONSULTA contra este corpus, sin recuperar nada.

        Existe porque el peso informativo es la señal que faltaba: distingue
        «no hay nada relevante» (corpus incompleto) de «no has preguntado nada
        distintivo» (consulta pobre), y esos dos casos piden acciones opuestas.

        Returns:
            dict con tokens, peso_informativo, si es discriminante, y el desglose
            término a término con su IDF y en cuántos chunks aparece.
        """
        if not self._asegurar_cargado():
            return {"disponible": False, "dominio": self.dominio}

        tokens = tokenizar(consulta)
        conceptos, expansiones = self._expandir(tokens)
        idf = getattr(self._bm25, "idf", {}) or {}

        detalle, peso = [], 0.0
        for variantes in conceptos:
            # El concepto vale lo que su mejor variante: son la misma idea.
            mejor, mejor_idf, mejor_df = None, 0.0, 0
            for t in sorted(variantes):
                df = sum(1 for toks in self._indice.tokens if t in toks)
                v = max(idf.get(t, 0.0), 0.0)
                if mejor is None or v > mejor_idf:
                    mejor, mejor_idf, mejor_df = t, v, df
            detalle.append({
                "token": sorted(variantes)[0] if len(variantes) == 1 else mejor,
                "variantes": sorted(variantes),
                "df": mejor_df,
                "idf": round(mejor_idf, 4),
            })
            peso += mejor_idf

        return {
            "disponible": True,
            "dominio": self.dominio,
            "tokens": tokens,
            "peso_informativo": round(peso, 3),
            "umbral": cfg.PESO_INFORMATIVO_MINIMO,
            "discriminante": peso >= cfg.PESO_INFORMATIVO_MINIMO,
            # Tras expandir: lo que sigue sin aparecer es un hueco REAL del
            # corpus, no un problema de vocabulario que el tesauro pueda tapar.
            "terminos_ausentes": [d["token"] for d in detalle if d["df"] == 0],
            "expansiones": expansiones,
            "detalle": detalle,
        }

    # ── Diagnóstico ──────────────────────────────────────────────────────────

    def estado(self) -> Dict[str, Any]:
        """Estado del índice, para `--status` y para los tests."""
        base = self._indexador.estado()
        base["cargado_en_memoria"] = self._indice is not None
        base["tfidf_activo"] = self._vectorizador is not None
        return base


# ── Caché de buscadores por proceso ──────────────────────────────────────────
# Construir un BuscadorLexico es barato, pero CARGARLO no: deserializar el
# índice y levantar BM25/TF-IDF se paga una vez. `motor_ia` evalúa decenas de
# actividades por informe; sin esta caché pagaría esa carga en cada una.
_BUSCADORES: Dict[str, BuscadorLexico] = {}


def get_buscador(dominio: str, autoconstruir: bool = True) -> BuscadorLexico:
    """Devuelve el buscador del dominio, reutilizándolo dentro del proceso."""
    clave = f"{dominio}|{autoconstruir}"
    if clave not in _BUSCADORES:
        _BUSCADORES[clave] = BuscadorLexico(dominio, autoconstruir=autoconstruir)
    return _BUSCADORES[clave]


def _reset_para_tests() -> None:
    """Vacía la caché de proceso. Solo para los tests."""
    _BUSCADORES.clear()
