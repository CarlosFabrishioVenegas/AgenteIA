"""
tests/test_azure_mocks.py
═══════════════════════════════════════════════════════════════════════════════
Verificación del flujo completo con Azure OpenAI SIMULADO.

No hay credencial de Azure todavía, así que estas pruebas reproducen la FORMA
EXACTA de una respuesta de `chat.completions.create()` —incluidos sus modos de
fallo— y comprueban que todo el sistema la digiere.

Lo que estas pruebas SÍ demuestran:
  · que el cliente Azure construye la petición como espera la API;
  · que negocia `max_tokens` / `max_completion_tokens` en vez de adivinar;
  · que el parser aguanta las tres formas en que el modelo puede envolver el
    JSON;
  · que un fallo de Azure se reporta y DETIENE, sin caer a Anthropic;
  · que el pipeline entero corre de punta a punta con el proveedor simulado.

Lo que NO demuestran, y hay que verificar con la credencial real:
  · qué modelo sirve el deployment y su ventana de contexto;
  · la CALIDAD de los hallazgos (§14.7 de la guía de migración);
  · el comportamiento real del filtro de contenido de Azure.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

RAIZ = Path(__file__).parent.parent
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))


# ══════════════════════════════════════════════════════════════════════════════
# Dobles que imitan la forma real del SDK de OpenAI
# ══════════════════════════════════════════════════════════════════════════════

def respuesta_azure(texto: str, modelo: str = "gpt-4o-2024-11-20",
                    finish_reason: str = "stop"):
    """
    Réplica de `openai.types.chat.ChatCompletion` en lo que el proyecto consume.

    La forma importa: el cliente accede a `.choices[0].message.content`, a
    `.model` y a `.finish_reason`. Un mock con dicts en vez de atributos no
    detectaría una regresión ahí.
    """
    return SimpleNamespace(
        model=modelo,
        choices=[SimpleNamespace(
            message=SimpleNamespace(content=texto, role="assistant"),
            finish_reason=finish_reason, index=0)],
        usage=SimpleNamespace(prompt_tokens=100, completion_tokens=50,
                              total_tokens=150),
    )


class _Completions:
    def __init__(self, padre):
        self._p = padre

    def create(self, **kwargs):
        self._p.llamadas.append(kwargs)
        if self._p.excepcion is not None:
            exc = self._p.excepcion
            self._p.excepcion = self._p.excepcion_persistente and exc or None
            raise exc
        # Simula un modelo que solo acepta un nombre de parámetro de tokens.
        if self._p.param_exigido:
            if self._p.param_exigido not in kwargs:
                otro = ("max_tokens" if self._p.param_exigido == "max_completion_tokens"
                        else "max_completion_tokens")
                raise Exception(
                    f"Error code: 400 - Unsupported parameter: '{otro}' is not "
                    f"supported with this model. Use '{self._p.param_exigido}' instead.")
        r = self._p.respuestas.pop(0) if self._p.respuestas else respuesta_azure("{}")
        return r


class ClienteAzureFalso:
    """Sustituye a `openai.AzureOpenAI` sin tocar la red."""

    def __init__(self, respuestas=None, excepcion=None, param_exigido=None,
                 excepcion_persistente=True, **_):
        self.respuestas = list(respuestas or [])
        self.excepcion = excepcion
        self.excepcion_persistente = excepcion_persistente
        self.param_exigido = param_exigido
        self.llamadas = []
        self.chat = SimpleNamespace(completions=_Completions(self))


@pytest.fixture
def cliente_azure(monkeypatch):
    """Devuelve una fábrica de ClienteAzureOpenAIIA con el SDK simulado."""
    def _fabricar(**kw):
        import config.ia as ia
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "clave-de-prueba-0123456789")
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://falso.openai.azure.com/")
        monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt4o-virf-prod")
        falso = ClienteAzureFalso(**kw)
        cli = object.__new__(ia.ClienteAzureOpenAIIA)
        cli.cliente = falso
        cli.deployment = "gpt4o-virf-prod"
        cli.max_tokens_default = 4096
        cli._modelo_real = None
        cli._perfil = None
        cli._param_tokens = None
        cli._admite_temperature = None
        return cli, falso
    return _fabricar


# ══════════════════════════════════════════════════════════════════════════════
# 1. El cliente construye la petición como espera la API
# ══════════════════════════════════════════════════════════════════════════════
class TestClienteAzureConstruyeBienLaPeticion:

    def test_el_sistema_va_como_primer_mensaje_no_como_parametro(self, cliente_azure):
        # `chat.completions.create()` NO tiene parámetro `system`: va dentro de
        # `messages` con role='system'. Enviarlo aparte da 400.
        cli, falso = cliente_azure(respuestas=[respuesta_azure("ok")])
        cli.generar_mensaje("prompt", instruccion_sistema="Eres auditor.")
        kw = falso.llamadas[0]
        assert "system" not in kw
        assert kw["messages"][0] == {"role": "system", "content": "Eres auditor."}
        assert kw["messages"][1]["role"] == "user"

    def test_usa_el_deployment_no_el_nombre_del_modelo(self, cliente_azure):
        cli, falso = cliente_azure(respuestas=[respuesta_azure("ok")])
        cli.generar_mensaje("prompt")
        assert falso.llamadas[0]["model"] == "gpt4o-virf-prod", (
            "debe llamarse al DEPLOYMENT; usar el nombre del modelo da 404 "
            "DeploymentNotFound")

    def test_devuelve_str_no_el_objeto_del_sdk(self, cliente_azure):
        cli, _ = cliente_azure(respuestas=[respuesta_azure("texto plano")])
        r = cli.generar_mensaje("prompt")
        assert isinstance(r, str) and r == "texto plano", (
            "el contrato de ClienteIA es devolver str: si se filtra el objeto "
            "del SDK, el negocio queda acoplado al proveedor")

    def test_formato_json_activa_response_format(self, cliente_azure):
        cli, falso = cliente_azure(respuestas=[respuesta_azure('{"a":1}')])
        cli.generar_mensaje("dame JSON", formato_json=True)
        assert falso.llamadas[0]["response_format"] == {"type": "json_object"}

    def test_sin_formato_json_no_se_envia_response_format(self, cliente_azure):
        cli, falso = cliente_azure(respuestas=[respuesta_azure("texto")])
        cli.generar_mensaje("prompt")
        assert "response_format" not in falso.llamadas[0]

    def test_memoriza_el_modelo_real_de_la_respuesta(self, cliente_azure):
        cli, _ = cliente_azure(
            respuestas=[respuesta_azure("ok", modelo="gpt-4o-2024-11-20")])
        cli.generar_mensaje("prompt")
        assert cli._modelo_real == "gpt-4o-2024-11-20", (
            "el modelo real viene gratis en la respuesta y determina el perfil "
            "de chunking: no memorizarlo obliga a una llamada extra")
        assert cli.perfil.contexto_tokens == 128_000


# ══════════════════════════════════════════════════════════════════════════════
# 2. Negociación de max_tokens / max_completion_tokens
# ══════════════════════════════════════════════════════════════════════════════
class TestNegociacionDelParametroDeTokens:
    """
    Los modelos de razonamiento (o1/o3/GPT-5) RECHAZAN `max_tokens`. Detectarlo
    por el nombre del deployment no sirve: lo elige el usuario y puede llamarse
    como quiera ('virf-prod'). Hay que negociarlo contra el servidor.
    """

    def test_modelo_clasico_acepta_max_tokens(self, cliente_azure):
        cli, falso = cliente_azure(param_exigido="max_tokens",
                                   respuestas=[respuesta_azure("ok")])
        cli.generar_mensaje("prompt")
        assert "max_tokens" in falso.llamadas[-1]

    def test_modelo_de_razonamiento_recibe_max_completion_tokens(self, cliente_azure):
        cli, falso = cliente_azure(
            param_exigido="max_completion_tokens",
            respuestas=[respuesta_azure("ok", modelo="gpt-5-2026-01-15")])
        r = cli.generar_mensaje("prompt")
        assert r == "ok", "el cliente no consiguió adaptarse al parámetro exigido"
        assert "max_completion_tokens" in falso.llamadas[-1]
        assert cli._param_tokens == "max_completion_tokens"

    def test_el_parametro_negociado_se_memoriza(self, cliente_azure):
        # El chunker hace ~40 llamadas: pagar el reintento en cada una sería
        # duplicar la latencia de toda la corrida.
        cli, falso = cliente_azure(
            param_exigido="max_completion_tokens",
            respuestas=[respuesta_azure("1"), respuesta_azure("2")])
        cli.generar_mensaje("a")
        n_tras_primera = len(falso.llamadas)
        cli.generar_mensaje("b")
        assert len(falso.llamadas) == n_tras_primera + 1, (
            "la segunda llamada volvió a probar ambos parámetros: el resultado "
            "de la negociación no se memorizó")

    def test_si_ambos_parametros_fallan_se_reporta_con_claridad(self, cliente_azure):
        cli, _ = cliente_azure(
            excepcion=Exception("Error code: 400 - Unsupported parameter: "
                                "'max_tokens' and 'max_completion_tokens'"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje("prompt")
        assert "Azure" in str(exc.value)


# ══════════════════════════════════════════════════════════════════════════════
# 3. Modos de fallo propios de Azure
# ══════════════════════════════════════════════════════════════════════════════
class TestModosDeFalloDeAzure:

    def test_choices_vacio_por_filtro_de_contenido(self, cliente_azure):
        """Azure filtra contenido; Anthropic no. `choices=[]` es exclusivo suyo."""
        vacia = SimpleNamespace(model="gpt-4o", choices=[], usage=None)
        cli, _ = cliente_azure(respuestas=[vacia])
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje("prompt")
        assert "filtro de contenido" in str(exc.value).lower()

    def test_content_none_se_reporta_con_su_finish_reason(self, cliente_azure):
        r = respuesta_azure(None, finish_reason="content_filter")
        cli, _ = cliente_azure(respuestas=[r])
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje("prompt")
        assert "content_filter" in str(exc.value)

    def test_un_error_de_red_no_se_traga(self, cliente_azure):
        cli, _ = cliente_azure(excepcion=ConnectionError("timeout"))
        with pytest.raises(RuntimeError):
            cli.generar_mensaje("prompt")

    def test_el_fallo_de_azure_NO_cae_a_anthropic(self, monkeypatch):
        """
        Política de gobernanza. Un informe con evaluaciones de dos modelos bajo
        una sola huella de ejecución haría falsa la reproducibilidad que el
        propio informe declara.
        """
        import importlib
        import config.ia as ia
        import config.parametros as pm

        # El orden importa y ya me costó un fallo: el `monkeypatch.undo()` debe
        # ir en el `finally`, NO antes de la recarga. Deshacerlo primero hace
        # que `reload` lea el .env real (IA_PROVEEDOR=anthropic) y el escenario
        # que se quiere probar desaparece. Y sin restaurar al final, config
        # queda con Azure sin credencial y CONTAMINA al resto de la suite.
        monkeypatch.setenv("IA_PROVEEDOR", "azure_openai")
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "")
        try:
            importlib.reload(pm)
            importlib.reload(ia)
            ia.reset_cliente_ia()
            assert pm.IA_PROVEEDOR == "azure_openai", "el escenario no se montó"

            with pytest.raises(Exception) as exc:
                ia.get_cliente_ia(forzar_recarga=True)
            mensaje = str(exc.value)
            assert "AZURE" in mensaje.upper(), (
                f"el error no menciona Azure: {mensaje!r}. Si el fallo de Azure "
                f"derivara a Anthropic, el informe mezclaría dos modelos bajo "
                f"una sola huella de ejecución.")
        finally:
            monkeypatch.undo()
            importlib.reload(pm)
            importlib.reload(ia)
            ia.reset_cliente_ia()


# ══════════════════════════════════════════════════════════════════════════════
# 4. Parseo del JSON — las tres formas en que puede venir envuelto
# ══════════════════════════════════════════════════════════════════════════════
class TestParseoDeLasTresVariantesDeAzure:
    """
    Aunque `response_format=json_object` garantiza JSON válido, el parser
    robusto sigue siendo necesario: Anthropic no tiene equivalente, y una
    llamada sin `formato_json` puede devolver el JSON envuelto.

    Este proyecto ya sufrió las tres variantes; el parser lleva un AUDIT-FIX
    por ello. Se fijan aquí con la forma que produciría Azure.
    """

    CONTRATO = {
        "puntaje": 3,
        "concepto": "Verificación de backtesting.",
        "evidencia_encontrada": "El manual documenta backtesting de Kupiec.",
        "observacion": "No aporta p-valores.",
        "preguntas_pendientes": [],
        "recomendacion": "Incluir los estadísticos.",
    }

    def _variantes(self):
        limpio = json.dumps(self.CONTRATO, ensure_ascii=False)
        return {
            "json_limpio": limpio,
            "con_markdown_fences": f"```json\n{limpio}\n```",
            "con_texto_alrededor": (
                "Claro, aquí tienes la evaluación solicitada:\n\n"
                f"{limpio}\n\n"
                "Nota: el análisis usa {llaves} en la explicación."),
        }

    @pytest.mark.parametrize("variante", ["json_limpio", "con_markdown_fences",
                                          "con_texto_alrededor"])
    def test_el_parser_extrae_el_contrato(self, variante):
        from modulos.motor_ia import _extraer_json
        datos = _extraer_json(self._variantes()[variante])
        assert datos["puntaje"] == 3
        assert "Kupiec" in datos["evidencia_encontrada"]

    def test_el_texto_posterior_con_llaves_no_confunde_al_parser(self):
        # El caso que rompía el parser antiguo: `rfind("}")` se pasaba de largo
        # hasta la llave de la frase explicativa y producía JSON inválido.
        from modulos.motor_ia import _extraer_json
        datos = _extraer_json(self._variantes()["con_texto_alrededor"])
        assert datos["puntaje"] == 3

    def test_dos_objetos_seguidos_no_se_fusionan(self):
        from modulos.motor_ia import _extraer_json
        doble = json.dumps(self.CONTRATO) + "\n" + json.dumps({"otro": 1})
        datos = _extraer_json(doble)
        assert datos.get("puntaje") == 3 and "otro" not in datos

    def test_json_invalido_no_devuelve_un_dict_inventado(self):
        from modulos.motor_ia import _extraer_json
        with pytest.raises(Exception):
            _extraer_json("esto no es JSON en absoluto")


# ══════════════════════════════════════════════════════════════════════════════
# 5. El pipeline completo corre con Azure simulado
# ══════════════════════════════════════════════════════════════════════════════
class TestPipelineCompletoConAzureSimulado:
    """
    Comprueba que los componentes de negocio funcionan con el proveedor Azure
    sin tocar Anthropic en ningún punto. El cliente se inyecta en la caché de
    proceso de config.ia, que es el único punto de entrada.
    """

    # Cumple el CONTRATO COMPLETO (_CAMPOS_CONTRATO_EVALUACION). Un mock
    # incompleto no probaría el flujo: _validar_contrato_evaluacion lo
    # rechazaría y la actividad saldría como fallo técnico — que es justo lo
    # que hizo la primera versión de este fixture y lo delató.
    RESPUESTA = json.dumps({
        "puntaje": 4,
        "concepto": "Verificación de la existencia de backtesting documentado.",
        "evidencia_encontrada": "El manual §3.2 documenta el backtesting de "
                                "Kupiec sobre 250 observaciones.",
        "observacion": "Documentado y con metodología explícita; no se aportan "
                       "los p-valores obtenidos.",
        "preguntas_pendientes": ["¿Cuáles fueron los p-valores del último ciclo?"],
        "recomendacion": "Incluir los estadísticos y su conclusión.",
    }, ensure_ascii=False)

    @pytest.fixture
    def azure_activo(self, monkeypatch, cliente_azure):
        import config.ia as ia
        cli, falso = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA) for _ in range(80)])
        monkeypatch.setattr(ia, "_CLIENTE_CACHE", cli)
        return cli, falso

    def test_evaluar_actividad_pipeline_2(self, azure_activo):
        cli, falso = azure_activo
        import modulos.motor_ia as motor_ia
        evs = motor_ia.evaluar_ambito_completo(
            ambito="Metodología",
            actividades=[{"actividad": "Revisión de backtesting",
                          "control": "C1", "tipo_ctrl": "Cuantitativo"}],
            contexto="Manual metodológico con backtesting de Kupiec documentado.",
            titulo_modelo="Modelo VaR", cobertura_docs=100.0)
        assert len(evs) == 1
        assert evs[0]["puntaje"] == 4
        assert "Kupiec" in evs[0]["evidencia_encontrada"]
        assert falso.llamadas, "no se llegó a llamar al proveedor"

    def test_chunking_resume_con_azure(self, azure_activo, tmp_path):
        cli, falso = azure_activo
        from modulos.chunker import ChunkerService
        ch = ChunkerService(cliente_ia=cli)
        doc = {"nombre": "manual.pdf", "contenido": "x" * 60_000,
               "chars_totales": 60_000, "tipo": "PDF"}
        r = ch.procesar_doc(doc)
        assert r["fue_resumido"] is True
        assert r["cobertura_pct"] > 0
        assert len(falso.llamadas) >= 1

    def test_el_score_y_el_semaforo_se_calculan(self, azure_activo):
        import modulos.motor_ia as motor_ia
        evs = motor_ia.evaluar_ambito_completo(
            ambito="Metodología",
            actividades=[{"actividad": f"A{i}", "control": "C",
                          "tipo_ctrl": "Cuantitativo"} for i in range(3)],
            contexto="Evidencia suficiente.", titulo_modelo="M",
            cobertura_docs=100.0)
        score = motor_ia.calcular_score_ambito(evs)
        assert score == 4.0
        assert motor_ia.get_semaforo(score)["label"] == "ACEPTABLE"

    def test_no_se_instancia_ningun_cliente_anthropic(self, azure_activo,
                                                      monkeypatch):
        """Ni un solo punto del flujo debe crear el proveedor secundario."""
        import config.ia as ia
        llamadas_anthropic = []
        original = ia.ClienteAnthropicIA.__init__

        def espia(self, *a, **kw):
            llamadas_anthropic.append(1)
            return original(self, *a, **kw)

        monkeypatch.setattr(ia.ClienteAnthropicIA, "__init__", espia)
        import modulos.motor_ia as motor_ia
        motor_ia.evaluar_ambito_completo(
            ambito="Metodología",
            actividades=[{"actividad": "A", "control": "C",
                          "tipo_ctrl": "Cuantitativo"}],
            contexto="Evidencia.", titulo_modelo="M", cobertura_docs=100.0)
        assert not llamadas_anthropic, (
            "se instanció el cliente de Anthropic con Azure activo")


# ══════════════════════════════════════════════════════════════════════════════
# FASE 3 — Los componentes que faltaban por cubrir con Azure simulado
#
# `TestPipelineCompletoConAzureSimulado` ya cubría Pipeline 2, chunking y score.
# Quedaban fuera tres piezas que también llaman al modelo y que, sin cobertura,
# solo se descubrirían rotas el día que llegue la credencial:
#
#   · Pipeline 1 (--control), que tiene su propio contrato de respuesta
#   · el explicador de modelos, con su verificación de 9 secciones
#   · la revisión de código módulo a módulo (--revisar-codigo)
#
# Ninguno hace llamadas reales: todo va contra ClienteAzureFalso.
# ══════════════════════════════════════════════════════════════════════════════
class TestPipeline1ExplicadorYRevisionConAzure:

    # ── Pipeline 1: contrato de evaluación de CONTROL ───────────────────────
    RESPUESTA_CONTROL = json.dumps({
        "estado": "ADVERTENCIA",
        "revision": "Control de unicidad documentado pero sin umbral explícito.",
        "hallazgos": [{"descripcion": "No se declara la tolerancia admitida",
                       "severidad": "media"}],
        "recomendacion": "Fijar el umbral en el manual de calidad de datos.",
        "puntaje": 3,
        "concepto": "Control de unicidad",
        "evidencia_encontrada": "Manual de calidad §4.1",
        "observacion": "Sin umbral cuantificado.",
        "preguntas_pendientes": [],
    }, ensure_ascii=False)

    def test_pipeline_1_evalua_un_control_con_azure(self, monkeypatch,
                                                    cliente_azure, tmp_path):
        """El pipeline por CONTROL usa el mismo cliente abstracto."""
        import config.ia as ia
        cli, falso = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA_CONTROL) for _ in range(20)])
        monkeypatch.setattr(ia, "_CLIENTE_CACHE", cli)

        import motor.Mx_03_LlamarIA as mx03
        monkeypatch.setattr(mx03, "_obtener_cliente", lambda: cli)

        # Se llama a la capa que habla con el modelo, no al orquestador entero:
        # lo que se verifica es que el contrato de Azure se parsea, no el I/O.
        texto = mx03._llamar_modelo("Evalúa el control C-01.")
        assert isinstance(texto, str) and texto, "no devolvió texto"
        datos = mx03._parsear_json(texto, fallback={})
        assert datos.get("estado") == "ADVERTENCIA"
        assert datos.get("hallazgos"), "se perdieron los hallazgos del control"
        assert falso.llamadas, "no se llamó al cliente Azure"

    # ── Explicador de modelos ───────────────────────────────────────────────
    def test_explicador_genera_las_9_secciones_con_azure(self, monkeypatch,
                                                         cliente_azure, tmp_path):
        from modulos.explicador_modelo import ExplicadorModelo

        # El explicador pide bloques de secciones; se devuelve un documento que
        # cumple la estructura fija que él mismo verifica.
        doc = "\n\n".join(
            "## %d. Sección %d\n\nContenido de ejemplo." % (i, i)
            for i in range(1, 10))
        cli, falso = cliente_azure(respuestas=[respuesta_azure(doc)
                                              for _ in range(12)])

        faltan = ExplicadorModelo.verificar(doc)
        assert not faltan, "el verificador de 9 secciones falla: %s" % faltan

        # Y con una sección ausente, DEBE detectarlo (si no, el explicador
        # entregaría documentos incompletos sin avisar).
        incompleto = doc.replace("## 7. Sección 7", "## 7bis. Otra cosa")
        assert ExplicadorModelo.verificar(incompleto), (
            "no detecta una sección faltante")

    def test_explicador_inventaria_sin_llamar_al_modelo(self, tmp_path):
        """El --dry-run no puede gastar: es la comprobación previa al gasto."""
        from modulos.explicador_modelo import ExplicadorModelo
        raiz = tmp_path
        (raiz / "inputs" / "documentacion" / "modelamiento").mkdir(parents=True)
        (raiz / "inputs" / "documentacion" / "modelamiento" / "m_LaR.md").write_text(
            "# Manual\n", encoding="utf-8")

        class ClienteQueNoDebeUsarse:
            def generar_mensaje(self, *a, **k):
                raise AssertionError("el dry-run llamó al modelo")

        ex = ExplicadorModelo(cliente_ia=None, base_dir=raiz)
        inv = ex.inventariar("LaR")
        assert isinstance(inv, dict) and inv, "el inventario salió vacío"

    # ── Revisión de código módulo a módulo ──────────────────────────────────
    RESPUESTA_REVISION = json.dumps({
        "resumen_modulo": "Calcula el VaR por percentil histórico.",
        "elementos_definidos": ["estimar_var"],
        "hallazgos": [{
            "linea": 3, "categoria": "no_documentado", "severidad": "alta",
            "elemento": "_ajuste", "descripcion": "Ajuste no documentado.",
            "evidencia_codigo": "z + skew/6", "referencia_manual": "",
        }],
    }, ensure_ascii=False)

    def test_revision_de_codigo_con_azure(self, cliente_azure, tmp_path):
        from modulos.revision_codigo import RevisorCodigo, descubrir_modulos
        base = tmp_path / "implementacion"
        (base / "libs").mkdir(parents=True)
        (base / "calculo.py").write_text("def f():\n    return 1\n", encoding="utf-8")
        (base / "libs" / "modelo.R").write_text("f <- function() 1\n", encoding="utf-8")

        cli, falso = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA_REVISION) for _ in range(10)])

        mods = descubrir_modulos(base)
        cons = RevisorCodigo(cli).revisar(mods, "Manual del modelo.",
                                          raiz=base, verbose=False)
        assert cons["revision_confiable"] is True, cons.get("fallos_tecnicos")
        assert cons["n_modulos"] == 2
        assert cons["n_hallazgos"] == 2
        assert falso.llamadas, "no se usó el cliente Azure"
        # El lenguaje debe viajar al prompt también con Azure
        lenguajes = {m["lenguaje"] for m in cons["modulos"]}
        assert lenguajes == {"python", "r"}, lenguajes

    def test_la_revision_de_codigo_no_cae_a_anthropic(self, monkeypatch,
                                                     cliente_azure, tmp_path):
        import config.ia as ia
        instanciados = []
        original = ia.ClienteAnthropicIA.__init__

        def espia(self, *a, **kw):
            instanciados.append(1)
            return original(self, *a, **kw)

        monkeypatch.setattr(ia.ClienteAnthropicIA, "__init__", espia)

        from modulos.revision_codigo import RevisorCodigo, descubrir_modulos
        base = tmp_path / "impl"; base.mkdir()
        (base / "a.py").write_text("def f(): pass\n", encoding="utf-8")
        cli, _ = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA_REVISION) for _ in range(5)])
        RevisorCodigo(cli).revisar(descubrir_modulos(base), "m",
                                   raiz=base, verbose=False)
        assert not instanciados, "se instanció Anthropic con Azure activo"


# ══════════════════════════════════════════════════════════════════════════════
# FASE 3 — Fallo de credencial: reportar y DETENERSE, nunca degradar en silencio
# ══════════════════════════════════════════════════════════════════════════════
class TestFalloDeCredencialSeDetiene:

    def test_credencial_invalida_lanza_y_no_devuelve_texto(self, cliente_azure):
        """
        Un 401 no puede convertirse en una cadena vacía: el pipeline la trataría
        como respuesta del modelo y la actividad saldría puntuada sobre nada.

        El fallo se inyecta con `excepcion=`, que es como el doble simula que la
        API revienta. Pasarlo en `respuestas=` no lo lanzaría: se devolvería el
        objeto y el cliente fallaría más tarde por otra causa, con lo que el
        test pasaría por el motivo equivocado.
        """
        cli, _ = cliente_azure(
            excepcion=Exception("Error code: 401 - Unauthorized: Access denied "
                                "due to invalid subscription key"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje(prompt="hola")
        mensaje = str(exc.value)
        assert "401" in mensaje or "Unauthorized" in mensaje, mensaje

    def test_endpoint_incorrecto_se_reporta_con_el_detalle(self, cliente_azure):
        cli, _ = cliente_azure(
            excepcion=ConnectionError("getaddrinfo failed: recurso-inexistente"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje(prompt="hola")
        assert "getaddrinfo" in str(exc.value), (
            "el detalle de red se perdió: el operador no sabría que el endpoint "
            "está mal escrito")

    def test_deployment_inexistente_da_404_accionable(self, cliente_azure):
        """El error más común al configurar Azure: deployment ≠ nombre de modelo."""
        cli, _ = cliente_azure(
            excepcion=Exception("Error code: 404 - DeploymentNotFound: The API "
                                "deployment for this resource does not exist"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje(prompt="hola")
        assert "404" in str(exc.value) or "DeploymentNotFound" in str(exc.value)

    def test_el_mensaje_del_preflight_nombra_al_proveedor_activo(self):
        """
        El diagnóstico debe mandar al operador a la consola correcta. Con Azure
        configurado, remitirle a la de Anthropic le hace revisar una credencial
        que no es la que está fallando.
        """
        from config.ia import metadatos_proveedor
        m = metadatos_proveedor("azure_openai")
        assert "Azure" in m["nombre"]
        assert "azure" in m["consola"].lower() or "portal" in m["consola"].lower()
        assert m["var_clave"] == "AZURE_OPENAI_API_KEY"
        # Y la lista de variables a revisar debe incluir el error más común.
        assert any("DEPLOYMENT" in v for v in m["vars_revisar"])

    def test_no_existe_fallback_automatico_en_el_codigo(self):
        """
        Invariante de política: ninguna rama puede elegir otro proveedor cuando
        el activo falla. Un informe con evaluaciones de dos modelos bajo una
        sola huella de ejecución haría falsa la reproducibilidad que declara.
        """
        fuente = (RAIZ / "config" / "ia.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "fallback" not in vivas.lower(), (
            "apareció lógica de fallback en config/ia.py")
        # get_cliente_ia debe resolver por IA_PROVEEDOR y nada más.
        assert "FABRICAS[" in vivas or "FABRICAS.get" in vivas


# ══════════════════════════════════════════════════════════════════════════════
# FASE 3 — Detección automática del modelo del deployment
# ══════════════════════════════════════════════════════════════════════════════
class TestDeteccionAutomaticaDelDeployment:

    @pytest.mark.parametrize("modelo_real,espera_param,espera_temp", [
        ("gpt-4",                  "max_tokens",            True),
        ("gpt-4-turbo-2024-04-09", "max_tokens",            True),
        ("gpt-4o-2024-11-20",      "max_tokens",            True),
        ("gpt-5-2025-08-01",       "max_completion_tokens", False),
        ("o3-mini-2025-01-31",     "max_completion_tokens", False),
    ])
    def test_el_perfil_se_adapta_al_modelo_que_sirva_el_deployment(
            self, modelo_real, espera_param, espera_temp):
        """
        El requisito operativo: pegar la key y NO tocar código, sirva el
        deployment lo que sirva. El perfil se deriva del modelo REAL que
        devuelve la respuesta, no del nombre del deployment.
        """
        from config.modelos import perfil_modelo
        p = perfil_modelo(modelo_real, verbose=False)
        assert p.param_tokens == espera_param, (
            "%s negociaría el parámetro de tokens equivocado" % modelo_real)
        assert p.admite_temperature is espera_temp
        assert p.max_ctx > 0 and p.chunk_size > 0 and p.max_chunks > 0

    def test_un_modelo_desconocido_no_rompe_y_es_conservador(self):
        """
        Si mañana IT despliega un modelo que no está en el catálogo, el sistema
        debe seguir corriendo con un presupuesto prudente en vez de reventar o
        de asumir un contexto que no tiene.
        """
        from config.modelos import perfil_modelo, PERFIL_CONSERVADOR
        p = perfil_modelo("modelo-que-no-existe-2030", verbose=False)
        assert p is PERFIL_CONSERVADOR
        assert p.contexto_tokens <= 32_000, "el perfil de reserva no es conservador"

    def test_el_cliente_memoriza_el_modelo_real(self, cliente_azure):
        cli, falso = cliente_azure(
            respuestas=[respuesta_azure('{"ok": true}', modelo="gpt-4o-2024-11-20")])
        cli.generar_mensaje(prompt="ping")
        assert getattr(cli, "_modelo_real", None) == "gpt-4o-2024-11-20", (
            "sin memorizar el modelo real, el perfil de chunking no puede "
            "derivarse del deployment y habría que configurarlo a mano")


# ══════════════════════════════════════════════════════════════════════════════
# [AZURE 2026-07-30] Reintento ante cuota agotada (429)
#
# La cuota de Azure es POR DEPLOYMENT (TPM/RPM). El chunker hace hasta 40
# llamadas seguidas, así que el 429 no es excepcional: es lo esperable con un
# deployment de TPM modesto. Sin reintento, abortaba la corrida a mitad del
# chunking con la extracción ya pagada.
#
# `REINTENTOS_API` llevaba tiempo declarado en config/parametros.py y NO LO LEÍA
# NADIE: un mando conectado a nada, que promete un control inexistente. Es el
# mismo defecto que el proyecto ya corrigió con RAG_TOP_K.
# ══════════════════════════════════════════════════════════════════════════════
class TestReintentoAnteCuotaAgotada:

    def test_un_429_se_reintenta_y_la_corrida_continua(self):
        from config.red import con_reintento as _con_reintento
        estado = {"n": 0}

        def flaky():
            estado["n"] += 1
            if estado["n"] < 3:
                raise Exception("Error code: 429 - Too Many Requests")
            return "ok"

        assert _con_reintento(flaky, intentos=5) == "ok"
        assert estado["n"] == 3

    def test_un_401_NO_gasta_reintentos(self):
        """
        Reintentar una credencial inválida cinco veces es puro desperdicio: el
        resultado es el mismo y el operador espera de más para ver el mismo
        error. Solo se reintenta lo que puede cambiar por sí solo.
        """
        from config.red import con_reintento as _con_reintento
        llamadas = {"n": 0}

        def auth():
            llamadas["n"] += 1
            raise Exception("Error code: 401 - Unauthorized")

        with pytest.raises(Exception):
            _con_reintento(auth, intentos=5)
        assert llamadas["n"] == 1, "reintentó un fallo de credencial"

    def test_al_agotarse_propaga_el_error_real(self):
        """
        Un rate limit agotado es un FALLO TÉCNICO del agente, no una falta del
        validado. Debe propagarse para que la actividad quede como
        evaluacion_valida=False, nunca como puntaje 0.
        """
        from config.red import con_reintento as _con_reintento

        def siempre():
            raise Exception("429 rate limit exceeded")

        with pytest.raises(Exception) as exc:
            _con_reintento(siempre, intentos=2)
        assert "429" in str(exc.value)

    def test_respeta_el_retry_after_del_servidor(self):
        """Si la API dice cuánto esperar, se le hace caso."""
        from config.red import espera_sugerida as _espera_sugerida

        class ConRetryAfter(Exception):
            retry_after = 7.0

        assert _espera_sugerida(ConRetryAfter(), 0) == 7.0

    def test_sin_retry_after_usa_backoff_exponencial_acotado(self):
        from config.red import espera_sugerida as _espera_sugerida
        e = Exception("429")
        assert _espera_sugerida(e, 0) < _espera_sugerida(e, 4)
        assert _espera_sugerida(e, 20) <= 60.0, "espera sin tope: cuelga la corrida"

    def test_clasifica_bien_lo_transitorio(self):
        from config.red import es_transitorio as _es_transitorio
        for t in ("Error code: 429", "503 Service Unavailable",
                  "rate limit exceeded", "Too Many Requests"):
            assert _es_transitorio(Exception(t)), t
        for p in ("401 Unauthorized", "404 DeploymentNotFound",
                  "400 Unsupported parameter"):
            assert not _es_transitorio(Exception(p)), p

    def test_el_parametro_esta_conectado_a_config(self):
        """El mando debe leerse de la única fuente de verdad, no de un literal."""
        fuente = (RAIZ / "config" / "red.py").read_text(encoding="utf-8")
        assert "REINTENTOS_API" in fuente, (
            "el reintento volvió a usar un literal en vez del parámetro central")

    def test_el_cliente_azure_reintenta_de_verdad(self, cliente_azure):
        """
        No basta con que la función exista: el cliente tiene que usarla. Una
        primera versión definió _con_reintento y no la enchufó a
        generar_mensaje — el 429 seguía abortando igual.
        """
        cli, falso = cliente_azure(
            excepcion=Exception("Error code: 429 - Too Many Requests"),
            excepcion_persistente=False,
            respuestas=[respuesta_azure('{"ok": true}')])
        # La 1ª llamada lanza 429, la 2ª devuelve la respuesta buena.
        texto = cli.generar_mensaje(prompt="hola")
        assert '"ok"' in texto
        assert len(falso.llamadas) >= 2, (
            "no reintentó: _con_reintento no está enchufado a generar_mensaje")


# ══════════════════════════════════════════════════════════════════════════════
# [HTTPS-FIX 2026-07-30] Red corporativa: proxy e inspección TLS
#
# Los SDK usan httpx, que verifica contra el bundle de certifi y NO contra el
# almacén de certificados de Windows. Con inspección TLS —el proxy descifra y
# vuelve a cifrar firmando con una CA propia— eso da el síntoma más
# desconcertante de la migración: el endpoint ABRE EN EL NAVEGADOR y el agente
# no conecta.
# ══════════════════════════════════════════════════════════════════════════════
class TestRedCorporativa:

    def test_sin_configuracion_no_se_construye_cliente_http(self, monkeypatch):
        """
        Sin nada que declarar se deja al SDK construir el suyo: es el camino
        probado por el proveedor. Intervenir siempre añadiría una superficie de
        fallo propia sin ganar nada.
        """
        for v in ("VIRF_CA_BUNDLE", "VIRF_TLS_INSECURE"):
            monkeypatch.delenv(v, raising=False)
        monkeypatch.setenv("VIRF_HTTP_TIMEOUT", "120")
        import importlib, config.parametros as p, config.red as red
        importlib.reload(p); importlib.reload(red)
        assert red.cliente_http() is None

    def test_un_ca_bundle_inexistente_se_rechaza_con_mensaje_util(self, monkeypatch, tmp_path):
        """
        Apuntar a un fichero que no está es el error típico al copiar la ruta.
        Debe decir qué pedirle a IT, no un FileNotFoundError crudo.
        """
        monkeypatch.setenv("VIRF_CA_BUNDLE", str(tmp_path / "no_existe.pem"))
        import importlib, config.parametros as p, config.red as red
        importlib.reload(p); importlib.reload(red)
        with pytest.raises(ValueError) as exc:
            red.cliente_http()
        assert "no existe" in str(exc.value)
        assert "IT" in str(exc.value), "no dice qué pedirle a IT"

    def test_un_ca_bundle_corrupto_se_explica(self, monkeypatch, tmp_path):
        """
        Un PEM ilegible debe detectarse AL CONSTRUIR el cliente, con un mensaje
        útil, y no en la primera llamada disfrazado de problema de red.

        El caso real: IT entrega el certificado en DER/.cer binario y el
        operador lo renombra a `.pem`. El fichero existe, así que la
        comprobación de existencia pasa, y el fallo aparece mucho después.
        """
        ca = tmp_path / "corp.pem"
        ca.write_bytes(b"\x30\x82\x01\x0a\x02\x82")        # DER binario, no PEM
        monkeypatch.setenv("VIRF_CA_BUNDLE", str(ca))
        monkeypatch.delenv("VIRF_TLS_INSECURE", raising=False)
        import importlib, config.parametros as _p, config.red as red
        importlib.reload(_p); importlib.reload(red)
        with pytest.raises(ValueError) as exc:
            red.cliente_http()
        assert "openssl" in str(exc.value), "no explica cómo convertir desde DER"

    def test_no_se_usa_la_forma_deprecada_de_verify(self):
        """
        `verify=<str>` está DEPRECADO en httpx 0.28 y dejará de funcionar. Hay
        que construir un `ssl.SSLContext` explícito.
        """
        fuente = (RAIZ / "config" / "red.py").read_text(encoding="utf-8")
        assert "ssl.create_default_context(cafile=" in fuente, (
            "volvió la forma deprecada verify=<ruta>")

    def test_el_diagnostico_nombra_la_causa_real(self):
        """
        Un CERTIFICATE_VERIFY_FAILED crudo manda a revisar la credencial, que
        está bien. El diagnóstico debe señalar la CA y el almacén de Windows.
        """
        from config.red import diagnostico_https
        d = diagnostico_https()
        assert "CA" in d
        assert "navegador" in d.lower(), "no explica el síntoma que el operador ve"
        assert "VIRF_CA_BUNDLE" in d, "no dice cuál es la variable"
        assert "VIRF_TLS_INSECURE" in d, "no ofrece la prueba de 10 segundos"

    def test_produccion_rechaza_tls_desactivado(self):
        """
        Un entregable no se emite sobre un canal sin verificar: la cadena de
        custodia que el informe declara no sería defendible.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "args.prdc and _TLS_INSEGURO" in vivas, (
            "se puede emitir producción con la verificación TLS desactivada")

    def test_los_parametros_viven_en_config(self):
        """No pueden declararse con os.getenv sueltos en config/ia.py."""
        from config.parametros import CA_BUNDLE, HTTP_TIMEOUT, TLS_INSECURE
        assert isinstance(HTTP_TIMEOUT, int) and HTTP_TIMEOUT > 0
        assert isinstance(TLS_INSECURE, bool)


# ══════════════════════════════════════════════════════════════════════════════
# [ARQUITECTURA 2026-07-31] El RAG es LÉXICO: ni embeddings, ni HuggingFace
#
# Aquí vivía `TestEmbeddingsSinModelosExternos`, que verificaba que los vectores
# del RAG se generaran con el deployment de embeddings de Azure y no con
# sentence-transformers. Esos tests se eliminan porque su objeto de prueba ya no
# existe: `config/embeddings.py` se borró junto con ChromaDB.
#
# Los dos motivos, cada uno suficiente por sí solo:
#
#   1. NO HAY DEPLOYMENT DE EMBEDDINGS en el recurso Azure de la entidad — hay
#      uno solo, de chat. Aquellos tests pasaban contra un SDK falso mientras en
#      producción `get_embedding_function()` lanzaba siempre, el retriever
#      capturaba y devolvía [], y la validación corría sin contexto RAG. Es el
#      peor resultado posible de una suite: verde sobre una función que en el
#      entorno real no se podía ejecutar ni una vez.
#
#   2. CHROMADB ARRASTRABA HUGGINGFACE por dependencia transitiva
#      (chromadb -> tokenizers -> huggingface-hub), de modo que la política de
#      «cero modelos externos» se cumplía en el código y se incumplía en el
#      entorno instalado.
#
# Lo que se prueba ahora es el invariante que sustituye a aquél: que no queda
# NADA de embeddings ni de HF, ni en el código ni en las dependencias.
# ══════════════════════════════════════════════════════════════════════════════
class TestRagLexicoSinEmbeddingsNiHuggingFace:

    def test_config_embeddings_ya_no_existe(self):
        """
        No basta con dejar de llamarlo. Mientras el módulo exista, un import
        despistado —o un .env heredado— vuelve a meter al proyecto en la vía de
        los vectores, que en este entorno no tiene salida.
        """
        assert not (RAIZ / "config" / "embeddings.py").exists(), (
            "config/embeddings.py ha vuelto: el RAG es léxico, no vectorial")

    def test_los_parametros_de_embeddings_no_se_declaran(self):
        """
        `AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT` prometía un mando que no se podía
        accionar: no existe tal deployment. Un parámetro que solo puede quedar
        vacío es peor que no ofrecerlo, porque sugiere que hay algo que rellenar.
        """
        from config import parametros
        for nombre in ("EMBEDDINGS_PROVEEDOR", "AZURE_EMBEDDINGS_DEPLOYMENT",
                       "EMBEDDINGS_MODELO_LOCAL"):
            assert not hasattr(parametros, nombre), (
                f"{nombre} sigue declarado; el RAG ya no usa embeddings")

    def test_requirements_no_declara_ningun_paquete_de_huggingface(self):
        """
        El fallo que este test cierra NO era visible leyendo el código: ninguna
        línea del proyecto importaba `transformers`, pero `requirements.txt`
        declaraba `chromadb`, y chromadb -> tokenizers -> huggingface-hub.
        Instalar las dependencias metía HuggingFace en el entorno igual.
        """
        import re as _re
        req = (RAIZ / "requirements.txt").read_text(encoding="utf-8")
        declarados = []
        for linea in req.splitlines():
            linea = linea.split("#")[0].strip()      # los comentarios explican el porqué
            if not linea:
                continue
            nombre = _re.split(r"[<>=!\[ ]", linea, 1)[0].strip().lower().replace("-", "_")
            if nombre in {"chromadb", "transformers", "sentence_transformers",
                          "datasets", "tokenizers", "huggingface_hub"}:
                declarados.append(nombre)
        assert not declarados, (
            f"requirements.txt declara paquetes que arrastran HuggingFace: {declarados}")

    def test_requirements_declara_el_motor_lexico(self):
        req = (RAIZ / "requirements.txt").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in req.splitlines() if not l.lstrip().startswith("#"))
        assert "rank_bm25" in vivas, "falta rank_bm25: no hay BM25 que ejecutar"
        assert "scikit-learn" in vivas, "falta scikit-learn: no hay señal TF-IDF"

    def test_el_rag_no_importa_chromadb_ni_pide_embeddings(self):
        """
        Barrido sobre `src/rag/`: ni base vectorial, ni función de embeddings.
        Se buscan los IMPORTS y las LLAMADAS, no las menciones: los docstrings
        citan ChromaDB a propósito para explicar por qué se fue, y prohibir la
        palabra obligaría a borrar la explicación — que es justo lo que hace
        entendible el cambio dentro de seis meses.
        """
        import re as _re
        prohibidos = _re.compile(
            r"^\s*(?:import|from)\s+chromadb\b"
            r"|get_embedding_function\s*\("
            r"|embeddings\.create\s*\(",
            _re.M)
        fugas = []
        for f in (RAIZ / "src" / "rag").rglob("*.py"):
            if "__pycache__" in str(f):
                continue
            vivas = "\n".join(l for l in f.read_text(encoding="utf-8").splitlines()
                              if not l.lstrip().startswith("#"))
            if prohibidos.search(vivas):
                fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, f"el RAG volvió a depender de vectores: {fugas}"

    def test_los_defaults_de_config_rag_no_divergen_de_config(self):
        """
        `src/rag/config_rag.py` duplica los defaults de `config/parametros.py`
        para poder arrancar sin el paquete `config` (el job de Databricks copia
        solo `src/`). Una duplicación así es exactamente el patrón que produjo
        el bug histórico de `VIRF_MAX_CTX`: declarado en dos sitios con valores
        distintos, coincidiendo por casualidad hasta que alguien tocó uno.

        Aquí la copia es aceptable —el fallback no puede importar lo que no
        está— pero solo si algo la vigila. Esto lo vigila.
        """
        from config import parametros
        from src.rag.config_rag import _DEFECTOS

        divergentes = {}
        for nombre, valor_copia in _DEFECTOS.items():
            if not hasattr(parametros, nombre):
                divergentes[nombre] = ("(no declarado en config)", valor_copia)
                continue
            # Solo se comparan cuando el entorno NO los pisa: si el .env define
            # la variable, config tiene el valor del operador y la copia el
            # default, y diferir es lo correcto.
            import os
            if os.getenv(nombre, "").strip():
                continue
            oficial = getattr(parametros, nombre)
            if type(oficial)(valor_copia) != oficial:
                divergentes[nombre] = (oficial, valor_copia)

        assert not divergentes, (
            "los defaults de src/rag/config_rag.py se han separado de "
            f"config/parametros.py: {divergentes}")

    def test_indexar_y_buscar_no_toca_la_red(self, tmp_path, monkeypatch):
        """
        El invariante que justifica toda la arquitectura: el ciclo completo
        —indexar, persistir, recargar, consultar— es 100 % local.

        Se comprueba rompiendo el socket. Si algo intentara resolver un nombre o
        abrir una conexión (a huggingface.co, a Azure, a donde sea), este test
        falla con RuntimeError en vez de pasar silenciosamente porque la red
        estaba disponible en la máquina de quien lo ejecutó.
        """
        import socket
        from src.rag.buscador_lexico import BuscadorLexico
        from src.rag.indexador_lexico import IndexadorLexico

        corpus = tmp_path / "corpus"
        corpus.mkdir()
        (corpus / "kupiec.md").write_text(
            "La prueba de Kupiec contrasta la cobertura incondicional del VaR "
            "comparando el numero de excepciones observadas con las esperadas.",
            encoding="utf-8")
        (corpus / "liquidez.md").write_text(
            "El LCR exige un stock de activos liquidos de alta calidad (HQLA) "
            "suficiente para cubrir las salidas netas de efectivo a 30 dias.",
            encoding="utf-8")

        def _sin_red(*a, **kw):
            raise RuntimeError("el RAG léxico intentó salir a la red")
        monkeypatch.setattr(socket, "socket", _sin_red)
        monkeypatch.setattr(socket, "create_connection", _sin_red)
        monkeypatch.setattr(socket, "getaddrinfo", _sin_red)

        idx = IndexadorLexico("VaR", fuentes=[corpus])
        idx.ruta = tmp_path / "indice" / "VaR.pkl"
        assert len(idx.construir(force=True)) > 0

        buscador = BuscadorLexico("VaR", autoconstruir=False)
        buscador._indexador = idx
        res = buscador.buscar("excepciones de la prueba de Kupiec", top_k=2)
        assert res, "sin resultados: la recuperación léxica no funciona"
        assert res[0]["fuente"] == "kupiec.md", (
            f"recuperó el documento equivocado: {res[0]['fuente']}")

    def test_ningun_modulo_de_negocio_importa_modelos_externos(self):
        """Barrido: ni transformers, ni torch, ni huggingface fuera de config/."""
        import re
        patron = re.compile(
            r"^\s*(?:import|from)\s+(?:sentence_transformers|transformers|torch|huggingface)",
            re.M)
        fugas = []
        for carpeta in ("modulos", "motor", "src"):
            for f in (RAIZ / carpeta).rglob("*.py"):
                if "__pycache__" in str(f):
                    continue
                vivas = "\n".join(l for l in f.read_text(encoding="utf-8").splitlines()
                                  if not l.lstrip().startswith("#"))
                if patron.search(vivas):
                    fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, f"modelos externos importados fuera de config/: {fugas}"


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA CORPORATIVA 2026-07-30] Los tres errores de la corrida en banca
#
#   SSL: CERTIFICATE_VERIFY_FAILED — huggingface.co/sentence-transformers/...
#   Cannot send a request, as the client has been closed
#   ResponsibleAIPolicyViolation — Content Filter
#
# El primero se elimina borrando la llamada, no arreglando el certificado.
# El segundo era real: el SDK toma posesión del http_client.
# El tercero necesitaba un diagnóstico que dijera QUÉ hacer.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaEntornoCorporativo:

    def test_el_parametro_del_modelo_local_no_se_declara(self):
        """El default era `paraphrase-multilingual-MiniLM-L12-v2`: el modelo
        exacto del error SSL. No puede quedar ni como default."""
        from config import parametros
        assert not hasattr(parametros, "EMBEDDINGS_MODELO_LOCAL")

    def test_el_sdk_toma_posesion_del_http_client(self):
        """
        Premisa del bug, verificada contra el SDK real: cerrar el cliente de
        OpenAI cierra el httpx que se le pasó. Si esto cambiara en una versión
        futura, el blindaje sobraría — y conviene enterarse.
        """
        import httpx
        from openai import AzureOpenAI
        h = httpx.Client(timeout=5.0)
        cli = AzureOpenAI(api_key="x" * 30, api_version="2024-10-21",
                          azure_endpoint="https://fake.openai.azure.com/",
                          http_client=h)
        cli.close()
        assert h.is_closed, "el SDK ya no toma posesión: revisar el blindaje"

    def test_el_cliente_de_chat_tambien_se_reconstruye(self):
        src = (RAIZ / "config" / "ia.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert 'getattr(_http, "is_closed", False)' in vivas, (
            "el cliente de chat no detecta que su http_client se cerró")

    def test_el_diagnostico_de_content_filter_nombra_la_categoria(self):
        """
        «Causa habitual: el filtro de contenido» no sirve: con un prompt de
        15.000 chars el operador no sabe qué buscar ni qué pedirle a IT.
        """
        from types import SimpleNamespace
        from config.ia import _diagnostico_filtro
        resp = SimpleNamespace(choices=[], prompt_filter_results=[
            {"content_filter_results": {
                "violence": {"filtered": True, "severity": "medium"}}}])
        d = _diagnostico_filtro(resp, "x" * 15000)
        assert "violence(medium)" in d
        assert "ENTRADA" in d
        assert "Content filters" in d, "no dice cómo lo ajusta IT"
        assert "DEBUG_PROMPTS" in d, "no dice cómo aislar el documento culpable"
        assert "FALLO TÉCNICO" in d, (
            "no aclara que no puntúa 0 contra el validado")

    def test_el_filtro_en_la_salida_tambien_se_diagnostica(self):
        from types import SimpleNamespace
        from config.ia import _diagnostico_filtro
        op = SimpleNamespace(message=SimpleNamespace(content=None),
                             finish_reason="content_filter",
                             content_filter_results={
                                 "self_harm": {"filtered": True, "severity": "low"}})
        d = _diagnostico_filtro(SimpleNamespace(choices=[op]), "prompt")
        assert "SALIDA" in d and "self_harm" in d


class TestValidarConexionNegociaElParametroDeTokens:
    """
    `validar_conexion()` tenía `max_tokens=100` hardcodeado.

    Todo el cliente negocia `max_tokens` vs `max_completion_tokens` porque los
    modelos de razonamiento (o1, o3, gpt-5) rechazan el primero. El comprobador
    no lo hacía: contra un deployment de esa familia devolvía False y dejaba un
    error de la API que se lee como «la credencial está mal».

    Y falla en el peor momento: el primer arranque tras recibir las
    credenciales, cuando nadie sabe si el problema es la clave, el endpoint,
    el proxy o el deployment.
    """

    def _cliente(self, create):
        import config.ia as ia
        c = ia.ClienteAzureOpenAIIA.__new__(ia.ClienteAzureOpenAIIA)
        c.cliente = type("C", (), {"chat": type("Ch", (), {
            "completions": type("X", (), {"create": staticmethod(create)})()})()})()
        c.deployment = "deployment-de-prueba"
        c._param_tokens = None
        c.ultimo_error_conexion = ""
        return c

    def test_un_deployment_tipo_o1_valida_correctamente(self):
        intentos = []

        def create(**kw):
            intentos.append("max_tokens" if "max_tokens" in kw
                            else "max_completion_tokens")
            if "max_tokens" in kw:
                raise Exception("Unsupported parameter: 'max_tokens' is not "
                                "supported with this model. Use "
                                "'max_completion_tokens' instead.")
            return type("R", (), {"model": "o1-2024-12-17"})()

        c = self._cliente(create)
        assert c.validar_conexion() is True, (
            "un deployment o1/o3/gpt-5 debe validar, no reportarse como caido")
        assert intentos == ["max_tokens", "max_completion_tokens"]
        assert c.ultimo_error_conexion == ""

    def test_el_parametro_negociado_queda_memorizado(self):
        # Sin esto, la primera llamada real repetiría la negociación y pagaría
        # una petición rechazada de más.
        def create(**kw):
            if "max_tokens" in kw:
                raise Exception("'max_tokens' is not supported")
            return type("R", (), {"model": "o1"})()

        c = self._cliente(create)
        c.validar_conexion()
        assert c._param_tokens == "max_completion_tokens"

    def test_un_modelo_clasico_acierta_a_la_primera(self):
        llamadas = []

        def create(**kw):
            llamadas.append(kw)
            return type("R", (), {"model": "gpt-4o"})()

        c = self._cliente(create)
        assert c.validar_conexion() is True
        assert len(llamadas) == 1, "gpt-4o no debe pagar una llamada extra"
        assert c._param_tokens == "max_tokens"

    def test_una_credencial_mala_sigue_reportandose(self):
        # El fix no debe tragarse los fallos REALES: un 401 tiene que llegar
        # a `ultimo_error_conexion`, que es lo que el operador acaba leyendo.
        def create(**kw):
            raise Exception("401 Unauthorized: Access denied due to invalid "
                            "subscription key")

        c = self._cliente(create)
        assert c.validar_conexion() is False
        assert "401" in c.ultimo_error_conexion

    def test_no_se_reintenta_indefinidamente(self):
        llamadas = []

        def create(**kw):
            llamadas.append(kw)
            raise Exception("max_tokens not supported; use max_completion_tokens")

        c = self._cliente(create)
        assert c.validar_conexion() is False
        assert len(llamadas) == 2, "solo dos candidatos, no un bucle"

    def test_el_ping_no_pide_100_tokens(self):
        # Es una comprobación de conectividad: el limite no afecta a lo que se
        # verifica, y 100 tokens de respuesta se pagan en cada arranque.
        llamadas = []

        def create(**kw):
            llamadas.append(kw)
            return type("R", (), {"model": "gpt-4o"})()

        self._cliente(create).validar_conexion()
        assert llamadas[0].get("max_tokens") == 5

    def test_el_codigo_no_vuelve_a_hardcodear_el_parametro(self):
        import re
        from pathlib import Path
        fuente = (Path(__file__).resolve().parents[1] / "config" /
                  "ia.py").read_text(encoding="utf-8")
        bloque = fuente[fuente.index("    def validar_conexion(self) -> bool:\n"
                                     "        \"\"\"\n"
                                     "        Comprueba que el deployment"):]
        bloque = bloque[:bloque.index("# ══")] if "# ══" in bloque else bloque
        # El docstring EXPLICA el `max_tokens=100` que se retiró, así que hay
        # que saltárselo: si no, el test caza su propia documentación.
        cuerpo = bloque.split('"""', 2)[2]
        vivas = "\n".join(l for l in cuerpo.splitlines()
                          if not l.lstrip().startswith("#"))
        assert not re.search(r"max_tokens\s*=\s*\d+", vivas), (
            "vuelve el parametro de tokens hardcodeado en validar_conexion")
