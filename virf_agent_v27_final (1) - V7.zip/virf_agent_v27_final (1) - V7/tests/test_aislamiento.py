"""
tests/test_aislamiento.py — WP-02 reducido · indicador D2.

Verifica el aislamiento multi-tenant (modulos/aislamiento.py) de forma
DETERMINISTA y SIN API. Simula una recuperación con fragmentos de dos tenants
y comprueba que, filtrando por el Tenant A, el 0% de lo devuelto es ajeno
(D2 = 0%), y que la aserción de defensa en profundidad grita ante un spillover.
"""
import pytest

from modulos.aislamiento import (
    ContaminacionModelo,
    assert_sin_contaminacion,
    etiquetar_chunk,
    filtrar_por_tenant,
    pertenece,
    porcentaje_contaminacion,
)


def _corpus_mixto():
    """Fragmentos de dos tenants/modelos, como los devolvería un retriever."""
    return [
        {"texto": "VaR 99% ventana 250", "tenant": "T5443", "modelo": "VAR_BCP_2027"},
        {"texto": "backtesting Kupiec",   "tenant": "T5443", "modelo": "VAR_BCP_2027"},
        {"texto": "PD retail scoring",    "tenant": "T9001", "modelo": "PD_RETAIL"},
        {"texto": "LGD downturn",         "tenant": "T9001", "modelo": "PD_RETAIL"},
    ]


def test_no_spillover():
    """Consulta del Tenant A → 0% de fragmentos del Tenant B."""
    corpus = _corpus_mixto()
    solo_a = filtrar_por_tenant(corpus, tenant="T5443", modelo="VAR_BCP_2027")
    assert len(solo_a) == 2
    assert porcentaje_contaminacion(solo_a, "T5443", "VAR_BCP_2027") == 0.0
    # Ninguno del Tenant B sobrevivió al filtro.
    assert all(c["tenant"] == "T5443" for c in solo_a)
    # La aserción de defensa en profundidad no dispara sobre el conjunto limpio.
    assert_sin_contaminacion(solo_a, "T5443", "VAR_BCP_2027")


def test_conjunto_mixto_dispara_la_asercion():
    corpus = _corpus_mixto()
    assert porcentaje_contaminacion(corpus, "T5443", "VAR_BCP_2027") == 50.0
    with pytest.raises(ContaminacionModelo) as exc:
        assert_sin_contaminacion(corpus, "T5443", "VAR_BCP_2027")
    assert exc.value.ajenos == 2
    assert exc.value.total == 4


def test_fragmento_sin_dueno_se_considera_ajeno():
    # "No sé de quién es" nunca es "es tuyo".
    huerfano = [{"texto": "algo", "tenant": None}]
    assert pertenece(huerfano[0], "T5443", None) is False
    assert filtrar_por_tenant(huerfano, "T5443") == []


def test_filtrar_solo_por_tenant_ignora_modelo():
    corpus = _corpus_mixto()
    solo_t = filtrar_por_tenant(corpus, tenant="T9001", modelo=None)
    assert len(solo_t) == 2
    assert {c["modelo"] for c in solo_t} == {"PD_RETAIL"}


def test_etiquetar_no_muta_el_original():
    original = {"texto": "x"}
    etiquetado = etiquetar_chunk(original, "T1", "M1")
    assert "tenant" not in original          # el original queda intacto
    assert etiquetado["tenant"] == "T1"
    assert etiquetado["modelo"] == "M1"


def test_conjunto_vacio_es_limpio():
    assert porcentaje_contaminacion([], "T1") == 0.0
    assert_sin_contaminacion([], "T1")       # no lanza


def test_buscar_acepta_filtro_tenant_sin_indice():
    """buscar() con tenant sobre un dominio sin índice degrada a [] sin romper."""
    from src.rag.buscador_lexico import BuscadorLexico
    b = BuscadorLexico("VaR", autoconstruir=False)
    # Sin índice cargado devuelve [], y el nuevo parámetro no altera ese contrato.
    assert b.buscar("cualquier cosa", tenant="T5443", modelo="VAR_BCP_2027") == []
