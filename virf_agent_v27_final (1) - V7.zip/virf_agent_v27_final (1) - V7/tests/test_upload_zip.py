# -*- coding: utf-8 -*-
"""
POST /api/inputs/upload-zip — extracción segura de ZIP (coste 0, carpeta temporal).

Fija:
  · un ZIP normal se extrae;
  · Zip Slip (`../`) se rechaza;
  · ZIP bomb: demasiadas entradas o demasiado tamaño descomprimido → 413, y no
    queda nada extraído a medias. El caso "bomba" reproduce el ataque real: un
    upload pequeño que se expande mucho al descomprimir.
"""
import io
import zipfile

import pytest
from fastapi.testclient import TestClient

from web.app import app
from web.routers import upload as up
from web.services.contexto_sesion import contexto_sesion


@pytest.fixture()
def ctx(tmp_path):
    c = {
        "validador": {"codigo": "T9999", "nombre": "Test"},
        "modelo": {"slug": "m", "nombre": "M", "dominio": "ALM", "tier": "II"},
        "base": tmp_path, "inputs": tmp_path / "inputs",
        "outputs": tmp_path / "outputs", "clave": "T9999/m",
    }
    (tmp_path / "inputs").mkdir()
    app.dependency_overrides[contexto_sesion] = lambda: c
    yield c
    app.dependency_overrides.pop(contexto_sesion, None)


def _zip(archivos: dict) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for nombre, contenido in archivos.items():
            z.writestr(nombre, contenido)
    return buf.getvalue()


def _subir(datos: bytes):
    return TestClient(app).post(
        "/api/inputs/upload-zip?destino=implementacion",
        files={"archivo": ("x.zip", datos, "application/zip")})


def _extraidos(ctx):
    return [p for p in ctx["inputs"].rglob("*") if p.is_file()]


def test_zip_normal_se_extrae(ctx):
    r = _subir(_zip({"a.py": "print(1)", "sub/b.py": "print(2)"}))
    assert r.status_code == 200, r.text
    assert r.json()["n_miembros"] == 2
    assert len(_extraidos(ctx)) == 2


def test_zip_slip_rechazado(ctx):
    r = _subir(_zip({"../fuera.txt": "x"}))
    assert r.status_code == 400
    assert _extraidos(ctx) == []


def test_demasiadas_entradas_413(ctx, monkeypatch):
    monkeypatch.setattr(up, "MAX_MIEMBROS_ZIP", 2)
    r = _subir(_zip({"1.txt": "a", "2.txt": "b", "3.txt": "c"}))
    assert r.status_code == 413
    assert _extraidos(ctx) == []


def test_tamano_declarado_excesivo_413(ctx, monkeypatch):
    monkeypatch.setattr(up, "MAX_BYTES_DESCOMPRIMIDOS_ZIP", 1_000)
    r = _subir(_zip({"grande.txt": "x" * 5_000}))
    assert r.status_code == 413
    assert _extraidos(ctx) == []


def test_zip_bomba_upload_pequeno_expansion_grande(ctx, monkeypatch):
    # 4 MiB de ceros comprimen a unos pocos KB: el upload es diminuto, pero
    # descomprimido supera el tope. Es exactamente el patrón de una ZIP bomb.
    bomba = _zip({"ceros.bin": b"\x00" * (4 * 1024 * 1024)})
    assert len(bomba) < 64 * 1024, "el ZIP de prueba debería ser pequeño"
    monkeypatch.setattr(up, "MAX_BYTES_DESCOMPRIMIDOS_ZIP", 1 * 1024 * 1024)
    r = _subir(bomba)
    assert r.status_code == 413
    assert _extraidos(ctx) == []
