"""
tests/test_chat_adjuntar.py — WP-C: adjuntar evidencia en el chat → re-evaluar.
Coste 0: usa el mock del chat (VIRF_MOCK_CHAT=1), no llama al modelo.
"""
import pytest


def _ctx(tmp_path):
    return {"clave": "T9/x", "base": tmp_path,
            "modelo": {"nombre": "M", "tier": "I", "dominio": "LaR"}}


def _datos():
    return {"resultados_por_ambito": {"Metodología": [
        {"actividad": "A1 control no-negativos", "puntaje": 2, "resultado": "No cumple",
         "observacion": "no se evidencia el control", "evaluacion_valida": True},
    ]}}


def test_adjuntar_enriquece_evidencia_y_reevalua(monkeypatch, tmp_path):
    monkeypatch.setenv("VIRF_MOCK_CHAT", "1")
    from web.services import chat_service
    chat_service.clear_todo()
    ctx = _ctx(tmp_path)
    s = chat_service.iniciar(ctx, _datos(), "r.json")
    o = s.actual
    assert o is not None

    r = chat_service.adjuntar_evidencia(
        ctx, "manual_var.pdf",
        "El control de no-negativos SÍ existe: sección 3.2, se rechazan valores < 0.")

    assert "manual_var.pdf" in o.adjuntos
    assert "no-negativos" in o.evidencia          # evidencia re-enriquecida
    assert "resumen" in r                          # hubo un turno de re-evaluación


def test_adjuntar_sin_texto_falla(monkeypatch, tmp_path):
    monkeypatch.setenv("VIRF_MOCK_CHAT", "1")
    from web.services import chat_service
    chat_service.clear_todo()
    ctx = _ctx(tmp_path)
    chat_service.iniciar(ctx, _datos(), "r.json")
    with pytest.raises(RuntimeError):
        chat_service.adjuntar_evidencia(ctx, "vacio.txt", "   ")


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
