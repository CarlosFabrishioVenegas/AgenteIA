"""
tests/test_circuit_breakers.py — WP-05 · indicador D6.

Verifica el cortacircuitos (modulos/fusibles.py) de forma DETERMINISTA y SIN API:
el reloj se inyecta, así que no se duerme ni se llama al modelo. Cubre el cap de
iteraciones (<=3), el fusible de tiempo (~10 s), el de tokens (~20.000) y el
escalado a HITL con hallazgos intermedios.
"""
import pytest

from modulos.fusibles import Cortacircuitos, CortacircuitosActivado


class _Reloj:
    """Reloj controlable: el test fija `.t` entre llamadas."""

    def __init__(self, t=0.0):
        self.t = float(t)

    def __call__(self):
        return self.t


# ── Cap de iteraciones ───────────────────────────────────────────────────────
def test_cap_de_iteraciones_corta_al_cuarto_intento():
    cc = Cortacircuitos(max_iter=3, fusible_seg=10, fusible_tokens=10**9,
                        reloj=lambda: 0.0)
    assert cc.nueva_iteracion() == 1
    assert cc.nueva_iteracion() == 2
    assert cc.nueva_iteracion() == 3
    with pytest.raises(CortacircuitosActivado) as exc:
        cc.nueva_iteracion()
    assert exc.value.detalle["disparador"] == "cap_iteraciones"
    assert cc.iteraciones == 4  # registró el intento que lo hizo saltar


def test_cap_por_defecto_es_tres():
    cc = Cortacircuitos.desde_config(reloj=lambda: 0.0)
    assert cc.max_iter == 3
    assert cc.fusible_seg == 10
    assert cc.fusible_tokens == 20000


# ── Fusible de tiempo ────────────────────────────────────────────────────────
def test_fusible_de_tiempo_corta_pasados_los_diez_segundos():
    reloj = _Reloj(0.0)
    cc = Cortacircuitos(max_iter=99, fusible_seg=10, fusible_tokens=10**9,
                        reloj=reloj)
    cc.iniciar()
    reloj.t = 5.0
    cc.nueva_iteracion()          # 5 s: dentro de presupuesto
    reloj.t = 11.0
    with pytest.raises(CortacircuitosActivado) as exc:
        cc.nueva_iteracion()      # 11 s: supera el fusible
    assert exc.value.detalle["disparador"] == "fusible_tiempo"
    assert exc.value.detalle["segundos"] == 11.0


def test_verificar_tiempo_explicito():
    reloj = _Reloj(0.0)
    cc = Cortacircuitos(max_iter=99, fusible_seg=10, fusible_tokens=10**9,
                        reloj=reloj)
    cc.iniciar()
    reloj.t = 9.9
    cc.verificar()                # aún dentro
    reloj.t = 10.1
    with pytest.raises(CortacircuitosActivado):
        cc.verificar()


# ── Fusible de tokens ────────────────────────────────────────────────────────
def test_fusible_de_tokens_corta_pasados_los_veinte_mil():
    cc = Cortacircuitos(max_iter=99, fusible_seg=999, fusible_tokens=20000,
                        reloj=lambda: 0.0)
    cc.iniciar()
    assert cc.sumar_tokens(19000) == 19000
    with pytest.raises(CortacircuitosActivado) as exc:
        cc.sumar_tokens(2000)     # 21.000 > 20.000
    assert exc.value.detalle["disparador"] == "fusible_tokens"
    assert exc.value.detalle["tokens"] == 21000


def test_tokens_negativos_se_rechazan():
    cc = Cortacircuitos(3, 10, 20000, reloj=lambda: 0.0)
    with pytest.raises(ValueError):
        cc.sumar_tokens(-1)


# ── Escalado a HITL ──────────────────────────────────────────────────────────
def test_escalar_preserva_los_hallazgos_intermedios():
    cc = Cortacircuitos(max_iter=1, fusible_seg=10, fusible_tokens=10**9,
                        reloj=lambda: 0.0)
    cc.nueva_iteracion()
    hallazgos = [{"id": "H1"}, {"id": "H2"}]
    try:
        cc.nueva_iteracion()
        raise AssertionError("debió cortar")
    except CortacircuitosActivado:
        escalado = cc.escalar(hallazgos, motivo="cap superado")
    assert escalado["escalado_a_hitl"] is True
    assert escalado["motivo"] == "cap superado"
    assert escalado["hallazgos_intermedios"] == hallazgos  # nada se descarta
    assert escalado["disparador"] == "escalado"


def test_max_iter_invalido():
    with pytest.raises(ValueError):
        Cortacircuitos(max_iter=0, fusible_seg=10, fusible_tokens=10)
