"""
tests/test_tabla_validacion.py
═══════════════════════════════════════════════════════════════════════════════
Veredicto formal por actividad + tabla intermedia + puente al chat.

Coste 0: no llama al modelo. Cubre el output intermedio que pidió el validador
(tabla `Ámbito | Control | Actividad | Tier | Resultado | Evaluación Sustentada |
Fuente revisada | Acción requerida`) y que las filas 'No cumple' vayan al chat.
"""
import pytest


# ── Veredicto formal de 5 estados ─────────────────────────────────────────────

class TestVeredictoActividad:
    def _mod(self):
        from modulos.motor_ia import veredicto_actividad
        return veredicto_actividad

    def test_cumple_desde_4(self):
        v = self._mod()
        assert v({"puntaje": 4, "evaluacion_valida": True}) == "Cumple"
        assert v({"puntaje": 5, "evaluacion_valida": True}) == "Cumple"

    def test_parcial_es_frontera_de_3(self):
        assert self._mod()({"puntaje": 3, "evaluacion_valida": True}) == "Parcial"

    def test_no_cumple_por_debajo_de_3(self):
        v = self._mod()
        assert v({"puntaje": 2, "evaluacion_valida": True}) == "No cumple"
        assert v({"puntaje": 1, "evaluacion_valida": True}) == "No cumple"

    def test_no_evidenciado_por_sin_evidencia(self):
        assert self._mod()({"puntaje": None, "sin_evidencia": True}) == "No evidenciado"

    def test_fallo_tecnico_es_no_evidenciado_no_no_cumple(self):
        # Un fallo del agente NO puede leerse como falta del validado.
        assert self._mod()({"puntaje": None, "evaluacion_valida": False}) == "No evidenciado"

    def test_umbral_configurable(self, monkeypatch):
        monkeypatch.setenv("VIRF_UMBRAL_CUMPLE", "5")
        assert self._mod()({"puntaje": 4, "evaluacion_valida": True}) == "Parcial"


# ── Tabla intermedia ──────────────────────────────────────────────────────────

class TestConstruirTabla:
    def _fn(self):
        from modulos.motor_ia import construir_tabla_validacion
        return construir_tabla_validacion

    def _base(self):
        ambitos = {
            "Metodología": [
                {"actividad": "A1 backtesting", "control": "Backtesting", "requerida": True},
                {"actividad": "A2 estrés",      "control": "Estrés",      "requerida": True},
                {"actividad": "A3 tier4",       "control": "Otros",       "requerida": False},
            ],
        }
        resultados = {
            "Metodología": [
                {"actividad": "A1 backtesting", "control": "Backtesting", "puntaje": 2,
                 "observacion": "obs A1", "evidencia_encontrada": "manual.pdf → \"x\"",
                 "recomendacion": "corregir ventana", "evaluacion_valida": True},
                # A2 requerida SIN evaluación → No evidenciado
            ],
        }
        return ambitos, resultados

    def test_columnas_y_mapeo(self):
        ambitos, resultados = self._base()
        filas = self._fn()(ambitos, resultados, tier="II")
        f = {x["actividad"]: x for x in filas}
        a1 = f["A1 backtesting"]
        assert a1["ambito"] == "Metodología"
        assert a1["control"] == "Backtesting"
        assert a1["tier"] == "II"
        assert a1["resultado"] == "No cumple"
        assert a1["evaluacion_sustentada"] == "obs A1"
        assert a1["fuente_revisada"] == 'manual.pdf → "x"'
        assert a1["accion_requerida"] == "corregir ventana"

    def test_no_aplicable_para_actividad_no_requerida(self):
        ambitos, resultados = self._base()
        filas = self._fn()(ambitos, resultados, tier="II")
        a3 = next(x for x in filas if x["actividad"] == "A3 tier4")
        assert a3["resultado"] == "No aplicable"
        assert a3["va_al_chat"] is False

    def test_requerida_sin_evaluacion_es_no_evidenciado(self):
        ambitos, resultados = self._base()
        filas = self._fn()(ambitos, resultados, tier="II")
        a2 = next(x for x in filas if x["actividad"] == "A2 estrés")
        assert a2["resultado"] == "No evidenciado"

    def test_no_cumple_va_al_chat(self):
        ambitos, resultados = self._base()
        filas = self._fn()(ambitos, resultados, tier="II")
        a1 = next(x for x in filas if x["actividad"] == "A1 backtesting")
        assert a1["va_al_chat"] is True

    def test_anota_resultado_en_la_evaluacion(self):
        # El pipeline necesita que cada evaluación quede anotada con su veredicto
        # para que el chat y el JSON compartan el mismo estado.
        ambitos, resultados = self._base()
        self._fn()(ambitos, resultados, tier="II")
        assert resultados["Metodología"][0]["resultado"] == "No cumple"

    def test_anota_todas_las_evals_incluso_las_no_cruzadas(self):
        # Refinamiento: una evaluación que NO cruza con el estándar (p.ej. control
        # de datos fusionado) también debe quedar anotada, para que el chat sea
        # 100% por veredicto formal y no caiga a la heurística legacy.
        ambitos = {"Metodología": [{"actividad": "A1", "control": "C", "requerida": True}]}
        resultados = {"Metodología": [
            {"actividad": "A1", "puntaje": 2, "evaluacion_valida": True},
            {"actividad": "Extra fuera del estándar", "puntaje": 5, "evaluacion_valida": True},
        ]}
        self._fn()(ambitos, resultados, tier="I")
        assert resultados["Metodología"][0]["resultado"] == "No cumple"
        assert resultados["Metodología"][1]["resultado"] == "Cumple"  # anotada aunque no cruce

    def test_cumple_no_va_al_chat(self):
        ambitos = {"Gobierno": [{"actividad": "G1", "control": "Roles", "requerida": True}]}
        resultados = {"Gobierno": [{"actividad": "G1", "puntaje": 5,
                                    "evaluacion_valida": True, "observacion": "ok"}]}
        fila = self._fn()(ambitos, resultados, tier="I")[0]
        assert fila["resultado"] == "Cumple"
        assert fila["va_al_chat"] is False


# ── Puente al chat: selección por veredicto formal ────────────────────────────

class TestChatSeleccion:
    def _fn(self):
        from web.services.chat_service import _extraer_observaciones
        return _extraer_observaciones

    def test_solo_no_cumple_va_al_chat(self):
        datos = {"resultados_por_ambito": {"M": [
            {"actividad": "A1", "puntaje": 2, "resultado": "No cumple",
             "observacion": "o1", "control": "C1", "evaluacion_valida": True},
            {"actividad": "A2", "puntaje": 5, "resultado": "Cumple",
             "observacion": "o2", "control": "C1", "evaluacion_valida": True},
        ]}}
        obs = self._fn()(datos)
        assert [o.actividad for o in obs] == ["A1"]
        assert obs[0].resultado == "No cumple"
        assert obs[0].control == "C1"

    def test_fallo_tecnico_no_va_al_chat(self):
        datos = {"resultados_por_ambito": {"M": [
            {"actividad": "A1", "puntaje": None, "resultado": "No evidenciado",
             "evaluacion_valida": False},
        ]}}
        assert self._fn()(datos) == []

    def test_placeholder_sin_evidencia_no_va_al_chat(self):
        # El centinela "N/A — ámbito sin evidencia" (D3-FIX) no es una actividad
        # real: no debe llegar al chat aunque su veredicto sea No evidenciado.
        datos = {"resultados_por_ambito": {"Metodología": [
            {"actividad": "N/A — ámbito sin evidencia", "puntaje": None,
             "sin_evidencia": True, "resultado": "No evidenciado"},
        ]}}
        assert self._fn()(datos) == []

    def test_dedup_actividad_repetida_en_el_estandar(self):
        # El estándar repite actividades; el chat no debe preguntar lo mismo N veces.
        datos = {"resultados_por_ambito": {"Documentación": [
            {"actividad": "Control de versiones", "puntaje": 2, "resultado": "No cumple",
             "observacion": "o", "evaluacion_valida": True},
            {"actividad": "Control de versiones", "puntaje": 2, "resultado": "No cumple",
             "observacion": "o", "evaluacion_valida": True},
            {"actividad": "Otra actividad", "puntaje": 2, "resultado": "No cumple",
             "observacion": "o", "evaluacion_valida": True},
        ]}}
        obs = self._fn()(datos)
        assert [o.actividad for o in obs] == ["Control de versiones", "Otra actividad"]

    def test_fallback_json_sin_resultado(self):
        # JSON viejo sin veredicto formal: cae a la heurística puntaje<4.
        datos = {"resultados_por_ambito": {"M": [
            {"actividad": "A1", "puntaje": 2, "observacion": "o", "evaluacion_valida": True},
            {"actividad": "A2", "puntaje": 5, "observacion": "o", "evaluacion_valida": True},
        ]}}
        obs = self._fn()(datos)
        assert [o.actividad for o in obs] == ["A1"]


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
