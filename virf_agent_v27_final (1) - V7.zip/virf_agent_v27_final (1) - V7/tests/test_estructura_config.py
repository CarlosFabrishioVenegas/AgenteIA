"""
tests/test_estructura_config.py
═══════════════════════════════════════════════════════════════════════════════
Estructura de config/ y preparación para Azure OpenAI.

Dos familias de comprobaciones:

  · que nadie vuelva a importar del monolito `config.py` archivado;
  · que el sistema esté listo para recibir la credencial de Azure sin ningún
    ajuste adicional de código.

Todo aquí es verificable SIN credencial: no se hace ninguna llamada real.
"""

from __future__ import annotations

import ast
import re
from pathlib import Path

import pytest

from _arbol import es_de_entorno_virtual   # entornos con cualquier nombre

RAIZ = Path(__file__).resolve().parents[1]
_SKIP = ("archivo", "venv", ".venv", "__pycache__", "outputs", "modelos",
         "node_modules", ".git")


def _ficheros_py(incluir_este=False):
    """
    Ficheros .py del proyecto.

    Este fichero se excluye por defecto: sus mensajes de aserción CITAN los
    patrones prohibidos ('config_monolitico', 'choices[0]'…) para explicar qué
    se está vigilando, y sin excluirlo el test se detecta a sí mismo. Es una
    trampa que ya ha mordido cuatro veces en este proyecto.
    """
    propio = Path(__file__).resolve()
    for f in RAIZ.rglob("*.py"):
        if any(p in f.parts for p in _SKIP) or es_de_entorno_virtual(f, RAIZ):
            continue
        if not incluir_este and f.resolve() == propio:
            continue
        yield f


def _codigo_vivo(f: Path) -> str:
    """Fuente sin líneas de comentario (los comentarios EXPLICAN los fixes)."""
    return "\n".join(l for l in f.read_text(encoding="utf-8").splitlines()
                     if not l.lstrip().startswith("#"))


# ══════════════════════════════════════════════════════════════════════════════
# 1. El monolito archivado no se importa desde ningún sitio
# ══════════════════════════════════════════════════════════════════════════════
class TestMonolitoArchivadoNoSeImporta:
    """
    `config.py` como fichero único se migró a la carpeta `config/`. La copia
    histórica vive en archivo/config_monolitico_2026-07-27/ SOLO como
    referencia. Importar de ahí resucitaría una configuración congelada que ya
    ha divergido de la real, y el sistema tomaría decisiones —pesos de ámbito,
    umbrales anti-sesgo, proveedor— con valores obsoletos sin avisar.
    """

    def test_nadie_importa_del_directorio_archivo(self):
        fugas = []
        for f in _ficheros_py():
            vivo = _codigo_vivo(f)
            if re.search(r"^\s*(from|import)\s+archivo\b", vivo, re.M) or \
               "config_monolitico" in vivo:
                fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, (
            f"import desde el monolito archivado: {fugas}. Esa copia está "
            f"congelada y ya divergió de config/: usarla haría que el sistema "
            f"opere con pesos y umbrales obsoletos sin ningún aviso.")

    def test_no_reaparece_config_py_en_la_raiz(self):
        # Python resuelve los PAQUETES antes que los módulos, así que un
        # config.py junto a config/ quedaría MUERTO en silencio mientras todo
        # el proyecto cree estar leyéndolo.
        assert not (RAIZ / "config.py").exists(), (
            "config.py ha reaparecido en la raíz: el paquete config/ lo "
            "ensombrece y quedaría muerto sin previo aviso.")

    def test_config_resuelve_al_paquete(self):
        import config
        assert config.__file__.replace("\\", "/").endswith("config/__init__.py")

    def test_la_api_publica_de_config_esta_completa(self):
        import config
        for nombre in ("get_cliente_ia", "AMBITO_PESOS", "INPUTS", "OUTPUTS_DIR",
                       "CACHE_DIR", "ESTANDARES_PATH", "BASE_DIR", "IA_PROVEEDOR"):
            assert hasattr(config, nombre), f"config no expone {nombre}"

    def test_ningun_modulo_declara_su_propia_ruta_de_config(self):
        """
        Cada módulo lee de config/, no reconstruye rutas por su cuenta.

        `validate_project.py` se exceptúa a propósito: su referencia literal a
        'config.py' ES el check que impide que el monolito reaparezca en la
        raíz. Prohibirla sería prohibir la propia defensa.
        """
        EXCEPCIONES = {"validate_project.py"}
        sospechosos = []
        for f in _ficheros_py():
            if "config" in f.parts or f.name.startswith("test_"):
                continue
            if f.name in EXCEPCIONES:
                continue
            if re.search(r'["\']config\.py["\']', _codigo_vivo(f)):
                sospechosos.append(str(f.relative_to(RAIZ)))
        assert not sospechosos, (
            f"referencia literal a 'config.py' (el monolito) en: {sospechosos}")


# ══════════════════════════════════════════════════════════════════════════════
# 2. Azure OpenAI como proveedor prioritario — política de la entidad
# ══════════════════════════════════════════════════════════════════════════════
class TestAzureEsElProveedorPrioritario:

    def test_el_default_vive_en_el_codigo_no_en_el_env(self):
        """
        Requisito explícito: si alguien clona el proyecto y olvida definir
        IA_PROVEEDOR, la corrida debe salir por Azure. Depender de que el
        operador recuerde poner una variable es depender de que no se equivoque.
        """
        fuente = (RAIZ / "config" / "parametros.py").read_text(encoding="utf-8")
        m = re.search(r'IA_PROVEEDOR\s*=\s*os\.getenv\(\s*["\']IA_PROVEEDOR["\']\s*,\s*'
                      r'["\']([a-z_]+)["\']', fuente)
        assert m, "no se encontró la declaración de IA_PROVEEDOR en config/parametros.py"
        assert m.group(1) == "azure_openai", (
            f"el default en el código es '{m.group(1)}': si el .env no define "
            f"IA_PROVEEDOR, la corrida saldría por el proveedor equivocado.")

    def test_la_seleccion_de_proveedor_vive_solo_en_config(self):
        fugas = []
        for f in _ficheros_py():
            if "config" in f.parts or "tests" in f.parts:
                continue
            if "FABRICAS[" in _codigo_vivo(f):
                fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, (
            f"selección de proveedor fuera de config/: {fugas}")

    def test_no_hay_fallback_automatico_entre_proveedores(self):
        """
        Decisión de gobernanza. Un informe con evaluaciones de DOS modelos bajo
        una sola huella de ejecución haría falsa la reproducibilidad que el
        propio informe declara — y esa huella es lo que un auditor verifica.
        """
        vivo = _codigo_vivo(RAIZ / "config" / "ia.py")
        assert "for proveedor in FABRICAS" not in vivo, (
            "get_cliente_ia itera sobre las fábricas: eso es un fallback")
        assert vivo.count("FABRICAS[proveedor]()") == 1, (
            "hay más de un punto de instanciación de proveedor")
        # Ningún módulo debe reintentar contra otro proveedor
        for f in _ficheros_py():
            v = _codigo_vivo(f)
            assert not re.search(r'IA_PROVEEDOR\s*=\s*["\'](anthropic|azure_openai)["\']', v), \
                f"{f.name} reasigna IA_PROVEEDOR en tiempo de ejecución"

    def test_ambos_clientes_cumplen_la_misma_interfaz(self):
        import inspect
        from config.ia import ClienteIA, ClienteAnthropicIA, ClienteAzureOpenAIIA
        base = set(inspect.signature(ClienteIA.generar_mensaje).parameters)
        for cls in (ClienteAnthropicIA, ClienteAzureOpenAIIA):
            firma = set(inspect.signature(cls.generar_mensaje).parameters)
            assert base <= firma, (
                f"{cls.__name__}.generar_mensaje no acepta {base - firma}: el "
                f"código de negocio no puede depender de qué proveedor hay detrás")
            assert issubclass(cls, ClienteIA)

    def test_el_negocio_no_toca_el_sdk(self):
        """El conocimiento de la forma de la respuesta vive SOLO en config/ia.py."""
        patron = re.compile(r"\.content\[0\]|choices\[0\]|"
                            r"^\s*(import anthropic|from openai|import openai)", re.M)
        fugas = []
        for carpeta in ("modulos", "motor", "src"):
            for f in (RAIZ / carpeta).rglob("*.py"):
                if any(p in f.parts for p in _SKIP):
                    continue
                if patron.search(_codigo_vivo(f)):
                    fugas.append(str(f.relative_to(RAIZ)))
        if patron.search(_codigo_vivo(RAIZ / "agente.py")):
            fugas.append("agente.py")
        assert not fugas, f"acoplamiento al SDK fuera de config/: {fugas}"

    def test_no_quedan_endpoints_de_proveedor_fuera_de_config(self):
        fugas = []
        for f in _ficheros_py():
            if "config" in f.parts or "tests" in f.parts:
                continue
            v = _codigo_vivo(f)
            if "api.anthropic.com" in v or ".openai.azure.com" in v:
                fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, (
            f"endpoint de proveedor hardcodeado fuera de config/: {fugas}")


# ══════════════════════════════════════════════════════════════════════════════
# 3. Catálogo de modelos — parámetros por modelo, no fijos
# ══════════════════════════════════════════════════════════════════════════════
class TestCatalogoDeModelos:
    """
    El chunking estaba dimensionado para un modelo concreto. Fijar los valores
    «pensando en el modelo que creemos que habrá» ya falló una vez en este
    proyecto: se asumieron 3,3 chars/token cuando el real era 2,48, un desvío
    del 33 % en el presupuesto de contexto.
    """

    def test_resuelve_por_prefijo_con_fecha_de_version(self):
        from config.modelos import perfil_modelo
        # response.model llega con fecha: 'gpt-4o-2024-11-20'
        assert perfil_modelo("gpt-4o-2024-11-20", verbose=False).contexto_tokens == 128_000

    def test_la_coincidencia_mas_larga_gana(self):
        from config.modelos import perfil_modelo
        mini = perfil_modelo("gpt-4o-mini-2024-07-18", verbose=False)
        assert mini.nombre == "gpt-4o-mini", (
            "'gpt-4o-mini' cayó en el perfil de 'gpt-4o': la resolución debe "
            "elegir la clave más larga que encaje")

    def test_reconoce_el_modelo_dentro_de_un_deployment_con_prefijo(self):
        # El nombre del deployment lo elige el usuario: 'virf-gpt-4o-prod'
        from config.modelos import perfil_modelo
        assert perfil_modelo("virf-gpt-4o-prod", verbose=False).nombre == "gpt-4o"

    def test_un_modelo_desconocido_cae_en_perfil_conservador(self):
        from config.modelos import perfil_modelo, PERFIL_CONSERVADOR
        p = perfil_modelo("modelo-inexistente-xyz", verbose=False)
        assert p is PERFIL_CONSERVADOR
        assert p.contexto_tokens <= 16_000, (
            "el perfil de reserva debe quedarse CORTO: exceder el contexto "
            "produce truncados silenciosos y pérdida de cobertura documental")

    def test_los_modelos_de_razonamiento_exigen_max_completion_tokens(self):
        from config.modelos import perfil_modelo
        for m in ("gpt-5-2026-01-15", "o1-preview", "o3-mini"):
            p = perfil_modelo(m, verbose=False)
            assert p.param_tokens == "max_completion_tokens", (
                f"{m}: enviar max_tokens a un modelo de razonamiento da 400")
            assert p.admite_temperature is False

    def test_gpt4_clasico_reduce_el_presupuesto(self):
        # 8K de contexto es MENOS que el presupuesto pensado para Claude.
        from config.modelos import perfil_modelo
        p = perfil_modelo("gpt-4", verbose=False)
        assert p.max_ctx < 15_000, (
            "con 8K de contexto, el max_ctx heredado de Claude (15.000 chars) "
            "no cabe: el perfil debe reducirlo automáticamente")

    def test_el_chunk_size_se_acota_por_calidad(self):
        from config.modelos import perfil_modelo
        # Un contexto enorme no debe producir segmentos gigantes: resumir
        # 100.000 chars de una vez da resúmenes genéricos, y este sistema busca
        # hallazgos concretos.
        p = perfil_modelo("gpt-5-2026-01-15", verbose=False)
        assert p.chunk_size <= 40_000

    def test_max_chunks_nunca_baja_del_umbral_de_coste(self):
        from config.modelos import CATALOGO_MODELOS
        for nombre, p in CATALOGO_MODELOS.items():
            assert p.max_chunks >= 34, (
                f"{nombre}: por debajo de 34 chunks el modo adaptativo no "
                f"alcanza, cae al jerárquico puro y CUESTA MÁS")


# ══════════════════════════════════════════════════════════════════════════════
# 4. Prueba de humo — lista para la credencial
# ══════════════════════════════════════════════════════════════════════════════
class TestPruebaDeHumoListaParaCredencial:

    def test_el_comando_existe(self):
        vivo = _codigo_vivo(RAIZ / "agente.py")
        assert '"--verificar-conexion-azure"' in vivo
        assert "prueba_de_humo" in vivo

    def test_no_exige_api_key_en_el_preflight(self):
        # Es el comando que PRUEBA la credencial: exigirla antes sería circular.
        vivo = _codigo_vivo(RAIZ / "agente.py")
        assert "not args.verificar_conexion_azure" in vivo

    def test_reporta_sin_lanzar_cuando_no_hay_credencial(self, monkeypatch):
        """Debe devolver un diagnóstico, no reventar: el operador necesita leerlo."""
        for v in ("AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT",
                  "AZURE_OPENAI_DEPLOYMENT"):
            monkeypatch.delenv(v, raising=False)
        monkeypatch.setenv("IA_PROVEEDOR", "azure_openai")
        import importlib
        import config.parametros as pm
        import config.ia as ia

        # La restauración va en `finally`: recargar config con el entorno aún
        # parcheado lo deja apuntando a Azure sin credencial y contamina al
        # resto de la suite. Y deshacer el patch ANTES de la recarga eliminaría
        # el escenario que se quiere probar.
        try:
            importlib.reload(pm)
            importlib.reload(ia)
            r = ia.prueba_de_humo()
            assert r["ok"] is False
            assert r["error"], "no explicó por qué falló"
        finally:
            monkeypatch.undo()
            importlib.reload(pm)
            importlib.reload(ia)
            ia.reset_cliente_ia()
