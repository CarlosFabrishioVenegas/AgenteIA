"""
Tests del apartado «Solo Informe» (informe sin pipeline). Coste cero: no hay IA
en ningún punto del flujo, y todo escribe en `tmp_path`.

Cubre:
  - Reglas de conclusión global, incluidos los casos ambiguos A1–A5.
  - Estado y frase de conclusión por control.
  - Parser del estándar: formato del usuario (Control General/Específico) y el
    Estandar_VIRF.xlsx real del repo (cabecera en fila 2, celdas combinadas).
  - Cumplimiento por ámbito.
  - Word: estructura (portada, índice con hipervínculos, secciones, pie, logo,
    conclusión en rojo cuando el control no es adecuado).
  - Endpoints: estándar → imagen → generar → descargar.
"""
from __future__ import annotations

import io
from pathlib import Path

import openpyxl
import pytest
from docx import Document

from web.services import solo_informe_reglas as reglas
from web.services import solo_informe_service as svc
from web.services import solo_informe_word
from web.services.estandares_service import EstandarInvalido

RAIZ = Path(__file__).resolve().parent.parent


def _o(riesgo, ambito="Metodología", control_id="C001", **kw):
    return {"riesgo": riesgo, "ambito": ambito, "control_id": control_id,
            "observacion": kw.get("observacion", "obs"), **kw}


# ── Reglas de conclusión ─────────────────────────────────────────────

class TestConcluir:
    @pytest.mark.parametrize("obs, nivel", [
        ([], "Satisfactorio"),
        ([_o("Bajo")] * 4, "Satisfactorio"),
        ([_o("Bajo")] * 2 + [_o("Potencial")] * 2, "Satisfactorio"),
        ([_o("Bajo")] * 5, "Aceptable"),                       # A3
        ([_o("Potencial")] * 7, "Aceptable"),                  # A3 + A4
        ([_o("Moderado")], "Aceptable"),
        ([_o("Moderado")] + [_o("Bajo")] * 9, "Aceptable"),
        ([_o("Moderado")] * 2, "Regular"),
        ([_o("Crítico")], "Regular"),                          # A1
        ([_o("Crítico")] * 2 + [_o("Moderado")] * 5, "Regular"),
        ([_o("Crítico")] * 3, "Deficiente"),
        ([_o("Oportunidad de Mejora")] * 20, "Satisfactorio"), # A5
    ])
    def test_casos_basicos(self, obs, nivel):
        assert reglas.concluir(obs)["nivel"] == nivel

    def test_excepcion_documentacion_gobierno_dos_moderadas_es_aceptable(self):
        obs = [_o("Moderado", "Documentación"), _o("Moderado", "Gobierno")]
        assert reglas.concluir(obs)["nivel"] == "Aceptable"

    def test_excepcion_tres_moderadas_es_regular_por_prudencia(self):    # A2
        obs = [_o("Moderado", "Documentación"), _o("Moderado", "Gobierno"),
               _o("Moderado", "Metodología")]
        assert reglas.concluir(obs)["nivel"] == "Regular"

    def test_excepcion_cuatro_moderadas_es_regular(self):
        obs = [_o("Moderado", "Documentación"), _o("Moderado", "Gobierno")] * 2
        assert reglas.concluir(obs)["nivel"] == "Regular"

    def test_dos_moderadas_sin_gobierno_no_activan_la_excepcion(self):
        obs = [_o("Moderado", "Documentación"), _o("Moderado", "Documentación")]
        assert reglas.concluir(obs)["nivel"] == "Regular"

    def test_ambito_del_estandar_tambien_casa_la_excepcion(self):
        obs = [_o("Moderado", "Documentación"),
               _o("Moderado", "Gobierno de modelos")]
        assert reglas.concluir(obs)["nivel"] == "Aceptable"

    def test_conteos_y_supuestos(self):
        r = reglas.concluir([_o("Crítico"), _o("Moderado"), _o("Potencial"),
                             _o("Oportunidad de Mejora")])
        assert r["conteos"] == {"criticas": 1, "moderadas": 1,
                                "bajas_potenciales": 1, "om": 1}
        assert len(r["supuestos"]) == 5 and r["motivo"]

    def test_riesgo_tolerante_a_tildes_y_desconocido_falla(self):
        assert reglas.normalizar_riesgo("critico") == "Crítico"
        assert reglas.normalizar_riesgo("oportunidad de mejora") == "Oportunidad de Mejora"
        with pytest.raises(ValueError):
            reglas.normalizar_riesgo("altísimo")


class TestControl:
    def test_sin_observaciones_es_adecuado(self):
        assert reglas.control_cumple([])
        assert reglas.conclusion_control([]).endswith("ha resultado adecuado.")

    def test_frase_toma_el_riesgo_mas_grave(self):
        obs = [_o("Bajo"), _o("Crítico"), _o("Potencial")]
        assert reglas.riesgo_maximo(obs) == "Crítico"
        assert "con riesgo crítico" in reglas.conclusion_control(obs)
        assert not reglas.control_cumple(obs)

    def test_om_no_incumple(self):
        # Confirmado por el usuario: una OM no es un incumplimiento.
        assert reglas.OM_INCUMPLE is False
        om = [_o("Oportunidad de Mejora")]
        assert reglas.control_cumple(om)
        assert "adecuado, con oportunidades de mejora" in reglas.conclusion_control(om)
        # Con una observación de riesgo junto a la OM, el control sí incumple.
        assert not reglas.control_cumple(om + [_o("Bajo")])

    def test_limpiar_om_quita_responsable_y_fecha(self):
        obs = svc.limpiar_om([
            _o("Oportunidad de Mejora", responsable="Equipo", fecha_subsanacion="2027-01-01"),
            _o("Bajo", responsable="Equipo", fecha_subsanacion="2027-01-01")])
        assert (obs[0]["responsable"], obs[0]["fecha_subsanacion"]) == ("", "")
        assert (obs[1]["responsable"], obs[1]["fecha_subsanacion"]) == ("Equipo", "2027-01-01")

    def test_clave_ambito(self):
        assert reglas.clave_ambito("Usos") == reglas.clave_ambito(
            "Uso e integración a la gestión") == "usos"
        assert reglas.clave_ambito("Calidad de Datos") == reglas.clave_ambito(
            "Calidad de datos")


# ── Parser del estándar ──────────────────────────────────────────────

def _xlsx_usuario(ruta: Path):
    wb = openpyxl.Workbook(); ws = wb.active
    ws.append(["Ámbito", "Control General", "Control Específico", "Actividad"])
    ws.append(["Documentación", "Manual metodológico", "Control de cambios", "Act 1"])
    ws.append([None, None, "Objetivo y usos", "Act 2"])
    ws.append(["Gobierno", "Comité", None, "Act 3"])
    ws.append([None, None, None, None])
    ws.append([None, None, None, "Act 4"])
    wb.save(ruta)


class TestParser:
    def test_formato_usuario_con_forward_fill(self, tmp_path):
        x = tmp_path / "e.xlsx"; _xlsx_usuario(x)
        est = svc.parsear_estandar(x)
        assert est["ambitos"] == ["Documentación", "Gobierno"]
        c = est["controles"]
        assert [k["actividad"] for k in c] == ["Act 1", "Act 2", "Act 3", "Act 4"]
        assert c[1]["control"] == "Manual metodológico"
        assert c[1]["control_especifico"] == "Objetivo y usos"
        # Un ámbito nuevo no hereda el control específico del anterior.
        assert c[2]["control_especifico"] == ""
        assert c[3]["ambito"] == "Gobierno" and c[3]["clave_ambito"] == "gobierno"
        assert [k["id"] for k in c] == ["C001", "C002", "C003", "C004"]
        # Sin columnas TIER: todas las actividades aplican a cualquier tier.
        assert est["tiene_tier"] is False and c[0]["tiers"] is None
        assert svc.filtrar_por_tier(est, "IV") is est

    def test_columnas_tier_y_filtro(self, tmp_path):
        wb = openpyxl.Workbook(); ws = wb.active
        ws.append([None, None, None, None, None, None, None])
        ws.append([None, "AMBITO", "CONTROL", "ACTIVIDAD", "TIER I", "Tier_2", "TIER IV"])
        ws.append([None, "Documentación", "Manual", "Act 1", "X", "x", "X"])
        ws.append([None, None, None, "Act 2", "X", None, None])
        ws.append([None, "Gobierno", "Comité", "Act 3", "X", "no", None])
        x = tmp_path / "t.xlsx"; wb.save(x)
        est = svc.parsear_estandar(x)
        assert est["tiene_tier"] is True
        assert [c["tiers"] for c in est["controles"]] == [["I", "II", "IV"], ["I"], ["I"]]
        f4 = svc.filtrar_por_tier(est, "IV")
        assert [c["actividad"] for c in f4["controles"]] == ["Act 1"]
        assert f4["ambitos"] == ["Documentación"]          # Gobierno queda sin actividades
        assert len(svc.filtrar_por_tier(est, "I")["controles"]) == 3
        assert svc.filtrar_por_tier(est, "")["controles"] == []

    def test_estandar_real_del_repo(self):
        real = RAIZ / "inputs" / "Estandares_VIRF.xlsx"
        if not real.is_file():
            pytest.skip("no está el estándar real")
        est = svc.parsear_estandar(real)
        claves = {reglas.clave_ambito(a) for a in est["ambitos"]}
        assert {"documentacion", "calidad", "metodologia", "gobierno",
                "implementacion", "usos"} <= claves
        assert len(est["controles"]) > 20
        assert all(c["control"] for c in est["controles"])
        assert est["tiene_tier"] is True
        n = len(est["controles"])
        assert len(svc.filtrar_por_tier(est, "I")["controles"]) <= n
        assert 0 < len(svc.filtrar_por_tier(est, "IV")["controles"]) < n

    def test_sin_columnas_falla(self, tmp_path):
        wb = openpyxl.Workbook(); wb.active.append(["A", "B"]); wb.active.append([1, 2])
        x = tmp_path / "m.xlsx"; wb.save(x)
        with pytest.raises(EstandarInvalido):
            svc.parsear_estandar(x)

    def test_guardar_estandar_invalido_no_deja_residuos(self, tmp_path):
        with pytest.raises(EstandarInvalido):
            svc.guardar_estandar(tmp_path, b"no es un xlsx")
        assert not svc.ruta_xlsx(tmp_path).exists()
        assert not svc.ruta_json(tmp_path).exists()


# ── Cumplimiento y validación ────────────────────────────────────────

ESTANDAR = {
    "ambitos": ["Documentación", "Gobierno"],
    "controles": [
        {"id": "C001", "ambito": "Documentación", "clave_ambito": "documentacion",
         "control": "Manual", "control_especifico": "", "actividad": "Act 1"},
        {"id": "C002", "ambito": "Documentación", "clave_ambito": "documentacion",
         "control": "Manual", "control_especifico": "", "actividad": "Act 2"},
        {"id": "C003", "ambito": "Gobierno", "clave_ambito": "gobierno",
         "control": "Comité", "control_especifico": "", "actividad": "Act 3"},
    ],
}


def test_cumplimiento_por_ambito():
    obs = [_o("Bajo", control_id="C001"), _o("Crítico", control_id="C001")]
    filas = {f["ambito"]: f for f in svc.cumplimiento(ESTANDAR, obs)}
    assert filas["Documentación"] == {
        "ambito": "Documentación", "total": 2, "satisfactorios": 1, "no_cumplidos": 1,
        "pct_ok": 50.0, "pct_no": 50.0}
    assert filas["Gobierno"]["pct_ok"] == 100.0


def test_validar_datos():
    ok = {"tipo": "periodica", "nombre_modelo": "M", "fecha_inicio": "2026-01-01",
          "fecha_entrega": "2026-02-01", "observaciones": [_o("Bajo")]}
    assert svc.validar_datos(ok, ESTANDAR) == []
    malo = {"tipo": "x", "observaciones": [_o("Bajo", control_id="C999", observacion="")]}
    errores = svc.validar_datos(malo, ESTANDAR)
    assert len(errores) == 6
    # Si el estándar distingue tiers, el Tier es obligatorio.
    con_tier = {**ESTANDAR, "tiene_tier": True}
    assert any("Tier" in e for e in svc.validar_datos(ok, con_tier))
    assert svc.validar_datos({**ok, "tier": "II"}, con_tier) == []


def test_cargar_estandar_antiguo_se_rehace_desde_el_xlsx(tmp_path):
    import json
    x = svc.ruta_xlsx(tmp_path); _xlsx_usuario(x)
    viejo = svc.parsear_estandar(x); viejo.pop("tiene_tier")
    svc.ruta_json(tmp_path).write_text(json.dumps(viejo), encoding="utf-8")
    assert svc.cargar_estandar(tmp_path)["tiene_tier"] is False


def test_imagen_rechaza_extension_y_id_invalido(tmp_path):
    with pytest.raises(ValueError):
        svc.guardar_imagen(tmp_path, "x.exe", b"123")
    assert svc.ruta_imagen(tmp_path, "../estandar.json") is None


# ── Word ─────────────────────────────────────────────────────────────

def _png() -> bytes:
    from PIL import Image
    buf = io.BytesIO(); Image.new("RGB", (40, 20), (200, 30, 30)).save(buf, "PNG")
    return buf.getvalue()


def _datos(base: Path) -> dict:
    img = svc.guardar_imagen(base, "captura.png", _png())
    return {
        "tipo": "periodica", "nombre_modelo": "VaR Histórico",
        "fecha_inicio": "2026-09-01", "fecha_entrega": "2026-11-04",
        "contexto": "Modelo de VaR.\n\nSegundo párrafo.", "limitaciones": "",
        "observaciones": [
            _o("Crítico", "Documentación", "C001", observacion="Manual desactualizado",
               recomendacion="Actualizar el manual", responsable="Equipo Riesgos",
               fecha_subsanacion="2027-01-31",
               sustento={"tipo": "imagen", "imagen_id": img, "contenido": "Captura"}),
            _o("Bajo", "Documentación", "C001", observacion="Erratas",
               sustento={"tipo": "codigo", "contenido": "print('hola')"}),
        ],
    }


def _texto(doc) -> str:
    partes = [p.text for p in doc.paragraphs]
    for t in doc.tables:
        for f in t.rows:
            partes += [c.text for c in f.cells]
    return "\n".join(partes)


def test_word_estructura(tmp_path):
    ruta = solo_informe_word.generar(_datos(tmp_path), ESTANDAR, tmp_path, raiz_logo=RAIZ)
    assert ruta.is_file() and ruta.parent == tmp_path / "salida"
    assert ruta.name.startswith("Informe_Resultados_VaR_Historico_")
    doc = Document(str(ruta))
    txt = _texto(doc)
    for esperado in ("Gerencia de Administración de Riesgo de Modelo",
                     "Gerencia de Validación Interna de Riesgo Financiero",
                     "Banco de Crédito", "Informe de Resultados", "Validación Periódica",
                     "Validación periódica de VaR Histórico", "4 de noviembre de 2026",
                     "I. Objetivos", "II. Alcance", "III. Cumplimiento de Estándar",
                     "IV. Información Relevante", "V. Cuadro Resumen de Observaciones",
                     "VI. Glosario", "VII. Barrido de Controles",
                     "Total de Controles", "Controles no cumplidos (%)",
                     "Calificación: REGULAR", "Término", "Sigla", "Descripción",
                     "Manual desactualizado", "Oportunidad de mejora: Actualizar el manual",
                     "con riesgo crítico", "ha resultado adecuado", "Segundo párrafo"):
        assert esperado in txt, esperado

    # Barrido en texto estructurado (párrafos, no tablas).
    parrafos = [p.text for p in doc.paragraphs]
    assert "Actividad: Act 1" in parrafos
    assert any(t.startswith("Descripción de lo realizado: ") for t in parrafos)
    assert "Resultados: Nivel de riesgo Crítico" in parrafos
    assert "Resultados: Aceptable" in parrafos
    assert any(t.startswith("Conclusión: A partir de la revisión") for t in parrafos)
    assert not any("Descripción de lo realizado" in c.text
                   for t in doc.tables for f in t.rows for c in f.cells)
    # Encabezado: «Página | N» con campo PAGE.
    cab = doc.sections[0].header._element.xml
    assert doc.sections[0].header.paragraphs[0].text.startswith("Página | ")
    assert ">PAGE<" in cab

    pie = doc.sections[0].footer.paragraphs[0].text
    assert pie == "VALIDACIÓN INTERNA DE RIESGO FINANCIERO\tInforme Final"
    xml_header = doc.sections[0].header._element.xml
    if (RAIZ / "inputs" / "logoempresa").is_dir():
        assert "<pic:pic" in xml_header

    body = doc.element.body.xml
    assert 'TOC \\o "1-2" \\h' in body
    assert 'w:anchor="sec_vii_1"' in body and 'w:name="sec_vii_1"' in body
    assert 'w:fill="F8D7DA"' in body           # conclusión no adecuada en rojo
    assert "print('hola')" in txt
    # Imagen del logo (portada + encabezado) + imagen de sustento.
    assert len(doc.inline_shapes) >= 2


def test_word_om_no_va_en_rojo_ni_lleva_responsable(tmp_path):
    d = _datos(tmp_path)
    d["observaciones"] = [_o("Oportunidad de Mejora", "Gobierno", "C003",
                             observacion="Mejorar el acta", recomendacion="Plantilla de acta",
                             responsable="No debe salir", fecha_subsanacion="2027-01-01")]
    doc = Document(str(solo_informe_word.generar(d, ESTANDAR, tmp_path)))
    txt = _texto(doc)
    assert "adecuado, con oportunidades de mejora" in txt
    assert "No debe salir" not in txt
    assert 'w:fill="F8D7DA"' not in doc.element.body.xml
    assert "Calificación: SATISFACTORIO" in txt


def test_word_filtra_por_tier(tmp_path):
    est = {"ambitos": ["Documentación", "Gobierno"], "tiene_tier": True,
           "controles": [{**c, "tiers": ["I", "II"] if c["id"] != "C003" else ["I"]}
                         for c in ESTANDAR["controles"]]}
    d = _datos(tmp_path); d["tier"] = "II"
    doc = Document(str(solo_informe_word.generar(d, est, tmp_path)))
    txt = _texto(doc)
    assert "aplicables a un modelo Tier II" in txt
    assert "Act 3" not in txt and "VII.2 Gobierno" not in txt


@pytest.mark.parametrize("ini, fin, esperado", [
    ("2026-10-01", "2026-10-28", "octubre de 2026"),
    ("2026-09-01", "2026-11-04", "entre septiembre y noviembre de 2026"),
    ("2026-12-01", "2027-01-15", "entre diciembre de 2026 y enero de 2027"),
])
def test_periodo_validacion(ini, fin, esperado):
    assert solo_informe_word.periodo_validacion(ini, fin) == esperado


def test_ficha_del_documento(tmp_path):
    d = _datos(tmp_path)
    d.update(fecha_inicio="2026-10-01", fecha_entrega="2026-10-30",
             responsable_doc="Carlos Venegas", revisado_por="")
    doc = Document(str(solo_informe_word.generar(d, ESTANDAR, tmp_path)))
    ficha = next(t for t in doc.tables if t.rows[1].cells[0].text == "Título")
    filas = {f.cells[0].text: f.cells[1].text for f in ficha.rows[1:]}
    assert filas == {
        "Título": "Validación Periódica VaR Histórico",
        "Descripción del documento": ("El presente documento resume el análisis de la "
                                      "validación periódica realizada en octubre de 2026."),
        "Responsable de la documentación": "Carlos Venegas",
        "Revisado por": "Walter Paiva",               # revisor por defecto
        "Fecha de aprobación": "30 de octubre de 2026",
    }
    # La fecha de aprobación coincide con la de entrega de IV.3.
    assert "Entrega del informe" in _texto(doc) and "30 de octubre de 2026" in _texto(doc)


def test_word_primera_vez_sin_logo(tmp_path, monkeypatch):
    from modulos import word_estilo
    monkeypatch.setattr(word_estilo, "localizar_logo", lambda raiz=None: None)
    d = _datos(tmp_path); d["tipo"] = "primera_vez"; d["observaciones"] = []
    doc = Document(str(solo_informe_word.generar(d, ESTANDAR, tmp_path)))
    txt = _texto(doc)
    assert "Validación por Primera Vez" in txt
    assert "Validación por primera vez de VaR Histórico" in txt
    assert "Calificación: SATISFACTORIO" in txt
    assert 'w:fill="F8D7DA"' not in doc.element.body.xml


# ── Endpoints ────────────────────────────────────────────────────────

@pytest.fixture
def cliente(tmp_path):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.routers.solo_informe import base_solo_informe
    app.dependency_overrides[base_solo_informe] = lambda: tmp_path
    try:
        yield TestClient(app)
    finally:
        app.dependency_overrides.pop(base_solo_informe, None)


def test_flujo_endpoints(cliente, tmp_path):
    x = tmp_path / "subida.xlsx"; _xlsx_usuario(x)
    r = cliente.post("/api/solo-informe/estandar",
                     files={"archivo": ("Estandar_VIRF.xlsx", x.read_bytes())})
    assert r.status_code == 200, r.text
    assert len(r.json()["estandar"]["controles"]) == 4

    r = cliente.post("/api/solo-informe/imagen", files={"archivo": ("a.png", _png())})
    img = r.json()["imagen_id"]
    assert cliente.get(f"/api/solo-informe/imagen/{img}").status_code == 200

    body = {"tipo": "primera_vez", "nombre_modelo": "Modelo X",
            "fecha_inicio": "2026-10-01", "fecha_entrega": "2026-11-04",
            "observaciones": [{"ambito": "Gobierno", "riesgo": "Moderado",
                               "control_id": "C003", "observacion": "Sin acta",
                               "sustento": {"tipo": "imagen", "imagen_id": img}}]}
    r = cliente.post("/api/solo-informe/generar", json=body)
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["conclusion"]["nivel"] == "Aceptable"
    d = cliente.get(j["url"])
    assert d.status_code == 200 and d.content[:2] == b"PK"

    est = cliente.get("/api/solo-informe/estado").json()
    assert est["borrador"]["nombre_modelo"] == "Modelo X"
    assert "Usos" in est["catalogos"]["ambitos"]


def test_generar_exige_tier_si_el_estandar_lo_tiene(cliente):
    real = RAIZ / "inputs" / "Estandares_VIRF.xlsx"
    if not real.is_file():
        pytest.skip("no está el estándar real")
    est = cliente.post("/api/solo-informe/estandar",
                       files={"archivo": ("e.xlsx", real.read_bytes())}).json()["estandar"]
    body = {"tipo": "periodica", "nombre_modelo": "M", "fecha_inicio": "2026-10-01",
            "fecha_entrega": "2026-11-04", "observaciones": []}
    r = cliente.post("/api/solo-informe/generar", json=body)
    assert r.status_code == 400 and "Tier" in r.json()["detail"]
    r = cliente.post("/api/solo-informe/generar", json={**body, "tier": "IV"})
    assert r.status_code == 200, r.text
    total = sum(f["total"] for f in r.json()["cumplimiento"])
    assert total == len(svc.filtrar_por_tier(est, "IV")["controles"]) < len(est["controles"])


def test_generar_sin_estandar_o_con_errores(cliente, tmp_path):
    r = cliente.post("/api/solo-informe/generar", json={"tipo": "periodica"})
    assert r.status_code == 400 and "Estandar" in r.json()["detail"]
    x = tmp_path / "s.xlsx"; _xlsx_usuario(x)
    cliente.post("/api/solo-informe/estandar", files={"archivo": ("e.xlsx", x.read_bytes())})
    r = cliente.post("/api/solo-informe/generar", json={"tipo": "periodica"})
    assert r.status_code == 400 and "nombre del modelo" in r.json()["detail"]


def test_descargar_rechaza_rutas(cliente):
    assert cliente.get("/api/solo-informe/descargar/..%2Festandar.json").status_code in (400, 404)
    assert cliente.get("/api/solo-informe/descargar/otro.docx").status_code == 400
