"""
tests/test_abstencion.py — WP-01 · indicador D3.

Verifica la compuerta de abstención activa (modulos/abstencion.py) de forma
DETERMINISTA y SIN API: la decisión se toma sobre los scores léxicos ya
recuperados. Fixture de "retrieval de score bajo" → devuelve la abstención
estándar "EVIDENCIA INSUFICIENTE".
"""
from modulos.abstencion import (
    EVIDENCIA_INSUFICIENTE,
    evaluar_abstencion,
)


def test_sin_fragmentos_se_abstiene():
    r = evaluar_abstencion([], umbral=0.0)
    assert r["abstenido"] is True
    assert r["etiqueta"] == EVIDENCIA_INSUFICIENTE
    assert r["n_chunks"] == 0
    assert r["score_max"] == 0.0


def test_retrieval_debil_por_debajo_de_beta_se_abstiene():
    # Fixture: todos los fragmentos tienen score bajo.
    scores = [0.01, 0.02, 0.015]
    r = evaluar_abstencion(scores, umbral=0.05)
    assert r["abstenido"] is True
    assert r["etiqueta"] == EVIDENCIA_INSUFICIENTE
    assert r["score_max"] == 0.02


def test_evidencia_fuerte_no_se_abstiene():
    scores = [0.9, 0.4, 0.1]
    r = evaluar_abstencion(scores, umbral=0.05)
    assert r["abstenido"] is False
    assert r["etiqueta"] is None
    assert r["score_max"] == 0.9


def test_beta_por_defecto_solo_abstiene_ante_ausencia_total():
    # β=0.0 (default conservador): cualquier score positivo basta.
    assert evaluar_abstencion([0.001], umbral=0.0)["abstenido"] is False
    assert evaluar_abstencion([], umbral=0.0)["abstenido"] is True


def test_scores_no_numericos_se_ignoran():
    # Un score corrupto no debe romper la decisión.
    r = evaluar_abstencion([None, "x", 0.2], umbral=0.05)
    assert r["abstenido"] is False
    assert r["n_chunks"] == 1  # solo el 0.2 cuenta


def test_la_etiqueta_es_estable():
    assert EVIDENCIA_INSUFICIENTE == "EVIDENCIA INSUFICIENTE"
