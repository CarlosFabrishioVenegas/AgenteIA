# -*- coding: utf-8 -*-
"""
Pruebas del ACTA DE CIERRE en Excel (3 hojas) generada al finalizar el chat.
Coste 0: no llama al LLM; usa datos sintéticos y consolidación determinista.
"""
import io
import json
from pathlib import Path

import pytest
from openpyxl import load_workbook


DATOS = {
    "modelo": "Modelo Prueba", "tier": "II", "fecha": "2026-09-02",
    "score_global": 2.0,
    "scores_por_ambito": {"Documentación": 2.0, "Metodología": 2.0},
    "semaforo": {"label": "CON OBSERVACIONES", "color": "FFCC00"},
    "custodia": {"eslabon": 3, "hash": "deadbeef1234"},
    "tabla_validacion": [
        {"ambito": "Documentación", "control": "C1", "actividad": "Actividad A",
         "resultado": "No cumple", "evaluacion_sustentada": "falta",
         "fuente_revisada": "doc.md", "accion_requerida": "completar"},
        {"ambito": "Metodología", "control": "C2", "actividad": "Actividad B",
         "resultado": "Parcial", "evaluacion_sustentada": "parcial",
         "fuente_revisada": "", "accion_requerida": "revisar"},
    ],
    "resultados_por_ambito": {
        "Documentación": [{"actividad": "Actividad A", "puntaje": 2.0}],
        "Metodología": [{"actividad": "Actividad B", "puntaje": 2.0}],
    },
}
OBS = [
    {"ambito": "Documentación", "actividad": "Actividad A",
     "veredicto": "APROBADO", "hallazgo_final": "subsanado con evidencia"},
    {"ambito": "Metodología", "actividad": "Actividad B",
     "veredicto": "PENDIENTE", "hallazgo_final": "queda abierto"},
]
META = {"modelo": "Modelo Prueba", "tier": "II", "dominio": "VaR",
        "fecha": "2026-09-02", "validador": "Tester", "cargo": "Validador",
        "semaforo": {"label": "CON OBSERVACIONES"}}


def _wb(xlsx: bytes):
    return load_workbook(io.BytesIO(xlsx))


def test_acta_tiene_tres_hojas_y_columnas():
    from modulos.exportador_excel import acta_cierre_bytes
    wb = _wb(acta_cierre_bytes(DATOS, OBS, META))
    assert wb.sheetnames == ["Resumen", "Validación", "Decisiones"]
    cab = [wb["Validación"].cell(row=1, column=i).value for i in range(1, 10)]
    assert cab[:5] == ["Ámbito", "Control", "Actividad", "Aplica o No", "Resultado"]
    assert cab[8] == "Decisión del chat"


def test_acta_resumen_puntaje_sube_con_aprobado():
    from modulos.exportador_excel import acta_cierre_bytes
    rs = _wb(acta_cierre_bytes(DATOS, OBS, META))["Resumen"]
    assert rs["A1"].value == "ACTA DE CIERRE DE VALIDACIÓN"
    inicial, final = rs["B7"].value, rs["B8"].value
    assert isinstance(inicial, (int, float)) and isinstance(final, (int, float))
    assert final >= inicial            # APROBADO solo puede subir el puntaje
    conteo = [c.value for row in rs.iter_rows() for c in row
              if isinstance(c.value, str) and c.value.startswith("Decisiones del chat:")]
    assert conteo and "1 subsanada(s)" in conteo[0] and "1 pendiente(s)" in conteo[0]


def test_acta_hoja_decisiones_lista_cada_veredicto():
    from modulos.exportador_excel import acta_cierre_bytes
    wd = _wb(acta_cierre_bytes(DATOS, OBS, META))["Decisiones"]
    veredictos = {wd.cell(row=r, column=3).value for r in range(2, wd.max_row + 1)}
    assert {"APROBADO", "PENDIENTE"} <= veredictos


def test_acta_marca_decision_en_filas_cambiadas():
    from modulos.exportador_excel import acta_cierre_bytes
    wv = _wb(acta_cierre_bytes(DATOS, OBS, META))["Validación"]
    decisiones = [wv.cell(row=r, column=9).value for r in range(2, wv.max_row + 1)]
    assert "APROBADO" in decisiones and "PENDIENTE" in decisiones


# ── Endpoint ─────────────────────────────────────────────────────────────────

def test_endpoint_acta_descarga_xlsx(monkeypatch, tmp_path):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services.contexto_sesion import contexto_sesion
    from web.services import chat_service

    outputs = tmp_path / "outputs"
    (outputs / "2026-09-02").mkdir(parents=True)
    (outputs / "2026-09-02" / "res.json").write_text(
        json.dumps(DATOS, ensure_ascii=False), encoding="utf-8")

    ctx_fake = {
        "validador": {"codigo": "T1", "nombre": "Tester", "cargo": "Validador"},
        "modelo": {"slug": "modelo_x", "nombre": "Modelo Prueba", "dominio": "VaR", "tier": "II"},
        "base": tmp_path, "inputs": tmp_path / "inputs", "outputs": outputs,
        "clave": "T1/modelo_x",
    }

    from web.services.chat_service import Observacion

    class _Ses:
        ruta_json = "2026-09-02/res.json"
        observaciones = [
            Observacion(id="o1", ambito="Documentación", actividad="Actividad A",
                        puntaje=2.0, observacion="", veredicto="APROBADO",
                        hallazgo_final="subsanado"),
            Observacion(id="o2", ambito="Metodología", actividad="Actividad B",
                        puntaje=2.0, observacion="", veredicto="PENDIENTE",
                        hallazgo_final="abierto"),
        ]

    monkeypatch.setattr(chat_service, "sesion_activa", lambda ctx: _Ses())
    app.dependency_overrides[contexto_sesion] = lambda: ctx_fake
    try:
        r = TestClient(app).get("/api/chat/acta.xlsx")
    finally:
        app.dependency_overrides.pop(contexto_sesion, None)

    assert r.status_code == 200
    assert r.headers["content-type"].startswith(
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    assert "acta_cierre_modelo_x.xlsx" in r.headers["content-disposition"]
    wb = _wb(r.content)
    assert wb.sheetnames == ["Resumen", "Validación", "Decisiones"]
