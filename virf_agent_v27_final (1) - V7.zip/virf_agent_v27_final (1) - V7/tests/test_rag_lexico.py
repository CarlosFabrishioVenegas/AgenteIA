"""
tests/test_rag_lexico.py
═════════════════════════════════════════════════════════════════════════════
Tests del RAG LÉXICO (BM25 + TF-IDF) que sustituyó al RAG vectorial el
2026-07-31.

Qué se prueba aquí y qué NO
───────────────────────────
Aquí: el comportamiento del motor —tokenización, indexado, persistencia,
recuperación y degradación—. Los invariantes de POLÍTICA (que no vuelva
HuggingFace, que no reaparezcan los embeddings) viven en `test_azure_mocks.py`,
junto al resto de las comprobaciones de proveedor y red.

Ninguno de estos tests toca la red ni depende de que haya PDF reales en
`inputs/rag/`: cada uno construye su propio corpus en `tmp_path`. Un test de
recuperación que dependa del corpus del repositorio empieza a fallar el día que
alguien sustituye un paper, y el fallo no significa nada.
"""

from __future__ import annotations

import pickle
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]


# ── Utilidades ───────────────────────────────────────────────────────────────

def _corpus(tmp_path, docs: dict) -> Path:
    """Crea una carpeta de literatura con los documentos indicados."""
    carpeta = tmp_path / "corpus"
    carpeta.mkdir(exist_ok=True)
    for nombre, texto in docs.items():
        (carpeta / nombre).write_text(texto, encoding="utf-8")
    return carpeta


def _indexador(tmp_path, docs: dict, dominio="test"):
    from src.rag.indexador_lexico import IndexadorLexico
    idx = IndexadorLexico(dominio, fuentes=[_corpus(tmp_path, docs)])
    idx.ruta = tmp_path / "indice" / f"{dominio}.pkl"
    return idx


def _buscador(idx):
    from src.rag.buscador_lexico import BuscadorLexico
    b = BuscadorLexico(idx.dominio, autoconstruir=False)
    b._indexador = idx
    return b


DOCS_REGULATORIOS = {
    "kupiec.md": (
        "Backtesting de VaR. La prueba de Kupiec contrasta la cobertura "
        "incondicional comparando el numero de excepciones observadas con las "
        "esperadas bajo el nivel de confianza declarado. Christoffersen añade "
        "la prueba de independencia de las excedencias."
    ),
    "liquidez.md": (
        "El coeficiente de cobertura de liquidez (LCR) exige un stock de "
        "activos liquidos de alta calidad, HQLA, suficiente para cubrir las "
        "salidas netas de efectivo durante treinta dias de estres."
    ),
    "datos.md": (
        "La imputacion de valores faltantes debe documentarse: metodo elegido, "
        "porcentaje de registros afectados y analisis de sensibilidad del "
        "resultado del modelo frente a la imputacion aplicada."
    ),
}


# ═════════════════════════════════════════════════════════════════════════════
# TOKENIZACIÓN
# ═════════════════════════════════════════════════════════════════════════════
class TestTokenizacion:
    """
    El tokenizador es el punto único de fallo del sistema: si indexado y
    consulta difieren en UN paso, la consulta genera términos que no existen en
    el índice y BM25 devuelve ceros. Eso no da error — devuelve una lista vacía,
    indistinguible de «no hay nada relevante».
    """

    def test_singular_y_plural_caen_en_el_mismo_token(self):
        from src.rag.indexador_lexico import tokenizar
        pares = [
            ("serie temporal", "series temporales"),
            ("valor faltante", "valores faltantes"),
            ("modelo de riesgo", "modelos de riesgos"),
            ("prueba de backtesting", "pruebas de backtesting"),
            ("imputacion", "imputaciones"),
        ]
        for singular, plural in pares:
            assert tokenizar(singular) == tokenizar(plural), (
                f"«{singular}» y «{plural}» producen tokens distintos: una "
                f"consulta en singular no recuperará el texto en plural")

    def test_los_acentos_no_parten_el_vocabulario(self):
        """
        La ortografía de este corpus es inconsistente por origen: los PDF del
        BCBS traducidos y los manuales internos escriben lo mismo con y sin
        tilde, y un extractor de PDF además se come tildes según la tipografía.
        """
        from src.rag.indexador_lexico import tokenizar
        assert tokenizar("ponderación") == tokenizar("ponderacion")
        assert tokenizar("año") != tokenizar("ano"), (
            "la ñ debe preservarse: «año» y «ano» no son la misma palabra")

    def test_los_acronimos_del_dominio_sobreviven(self):
        """
        Son la razón de usar búsqueda léxica. Si el tokenizador se come «VaR»
        por corto, o «es» por stopword cuando significa Expected Shortfall, la
        ventaja sobre un embedding semántico desaparece.
        """
        from src.rag.indexador_lexico import tokenizar
        for sigla in ("VaR", "HQLA", "LCR", "NSFR", "PD", "LGD", "IRRBB", "FRTB"):
            assert sigla.lower() in tokenizar(f"analisis de {sigla} del modelo"), (
                f"la sigla {sigla} se pierde en la tokenización")

    def test_las_stopwords_se_filtran(self):
        from src.rag.indexador_lexico import tokenizar
        tokens = tokenizar("el modelo de la entidad y sus supuestos")
        assert "de" not in tokens and "la" not in tokens and "sus" not in tokens
        assert "modelo" in tokens

    def test_el_stemming_no_destruye_los_tecnicismos(self):
        """
        Recortar «backtesting» hasta «backtest» está bien; hasta «back»
        destruye el término y lo hace colisionar con cualquier cosa.
        """
        from src.rag.indexador_lexico import tokenizar
        for termino in ("kupiec", "christoffersen", "estacionariedad", "basilea"):
            assert tokenizar(termino)[0].startswith(termino[:5]), (
                f"el stemmer destrozó «{termino}»: {tokenizar(termino)}")

    def test_una_consulta_vacia_no_revienta(self):
        from src.rag.indexador_lexico import tokenizar
        assert tokenizar("") == []
        assert tokenizar("de la y el") == [], "solo stopwords: nada que buscar"


# ═════════════════════════════════════════════════════════════════════════════
# INDEXADO Y PERSISTENCIA
# ═════════════════════════════════════════════════════════════════════════════
class TestIndexadoYPersistencia:

    def test_el_indice_se_recarga_sin_reconstruir(self, tmp_path):
        """
        Lo caro del indexado es extraer los PDF. Si la recarga no funcionara, el
        coste se pagaría en cada corrida — y el síntoma sería «el agente tarda
        mucho», sin pista de por qué.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        original = idx.construir(force=True)
        assert len(original) > 0

        from src.rag.indexador_lexico import IndexadorLexico
        otro = IndexadorLexico("test", fuentes=idx.get_source_paths())
        otro.ruta = idx.ruta
        recargado = otro.cargar()

        assert recargado is not None, "el índice persistido no se pudo recargar"
        assert len(recargado) == len(original)
        assert [c["id"] for c in recargado.chunks] == [c["id"] for c in original.chunks]

    def test_construir_sin_force_reutiliza_lo_persistido(self, tmp_path):
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        primero = idx.construir(force=True)
        mtime = idx.ruta.stat().st_mtime_ns
        segundo = idx.construir(force=False)
        assert len(segundo) == len(primero)
        assert idx.ruta.stat().st_mtime_ns == mtime, (
            "reescribió el índice pese a que nada había cambiado")

    def test_un_documento_nuevo_invalida_el_indice(self, tmp_path):
        """
        Un índice caduco es peor que ninguno: sirve fragmentos de documentos que
        ya se sustituyeron, y tiene exactamente el mismo aspecto que uno al día.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        assert idx.cargar() is not None

        (idx.get_source_paths()[0] / "nuevo.md").write_text(
            "Documento de referencia añadido despues de indexar.", encoding="utf-8")

        assert idx.cargar() is None, (
            "la literatura cambió y el índice sigue dándose por vigente")
        assert idx.estado()["vigente"] is False

    def test_un_indice_corrupto_se_descarta_en_vez_de_reventar(self, tmp_path):
        """
        Una interrupción a mitad de escritura —Ctrl-C, un job sin tiempo— deja
        un .pkl truncado. Debe tratarse como «no hay índice», no como un fallo.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        idx.ruta.write_bytes(b"\x80\x04\x95basura truncada")
        assert idx.cargar() is None

    def test_un_indice_de_formato_anterior_se_descarta(self, tmp_path):
        """
        Cambiar el formato sin cambiar VERSION_INDICE fue el fallo del RAG
        vectorial: al cambiar de motor de embeddings, las dimensiones dejaban de
        coincidir y el error resultante no significaba nada para el operador.
        """
        from src.rag.indexador_lexico import IndiceLexico
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)

        viejo = IndiceLexico(dominio="test", version=0, chunks=[], tokens=[],
                             huella_fuentes=idx._huella_fuentes())
        idx.ruta.write_bytes(pickle.dumps(viejo))
        assert idx.cargar() is None

    def test_un_dominio_sin_literatura_produce_un_indice_vacio(self, tmp_path):
        """
        Mejor sin contexto que con contexto ajeno: es el fallo correcto.
        """
        idx = _indexador(tmp_path, {})
        indice = idx.construir(force=True)
        assert len(indice) == 0
        assert _buscador(idx).buscar("lo que sea") == []

    def test_no_se_persisten_objetos_de_sklearn(self, tmp_path):
        """
        El pickle guarda DATOS (textos y tokens), no el `TfidfVectorizer` ni el
        `BM25Okapi`. Un pickle de sklearn no es estable entre versiones: tras un
        `pip install -U scikit-learn` se recarga desde un warning hasta un
        objeto silenciosamente roto. Con listas de str eso no puede pasar.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        crudo = idx.ruta.read_bytes()
        assert b"sklearn" not in crudo, "se está picklando un objeto de sklearn"
        assert b"rank_bm25" not in crudo, "se está picklando el objeto BM25"


# ═════════════════════════════════════════════════════════════════════════════
# RECUPERACIÓN
# ═════════════════════════════════════════════════════════════════════════════
class TestRecuperacion:

    def test_recupera_el_documento_correcto(self, tmp_path):
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        b = _buscador(idx)

        casos = [
            ("excepciones y prueba de Kupiec", "kupiec.md"),
            ("activos liquidos de alta calidad HQLA", "liquidez.md"),
            ("imputacion de valores faltantes", "datos.md"),
        ]
        for consulta, esperado in casos:
            res = b.buscar(consulta, top_k=3)
            assert res, f"sin resultados para {consulta!r}"
            assert res[0]["fuente"] == esperado, (
                f"{consulta!r} recuperó {res[0]['fuente']} en vez de {esperado}")

    def test_una_consulta_ajena_al_corpus_devuelve_vacio(self, tmp_path):
        """
        El peor fallo posible en un RAG: inyectar ruido con aspecto de certeza.
        Como el score se normaliza contra el máximo de la consulta, sin el filtro
        por cobertura SIEMPRE habría un «mejor resultado» con score 1.00, aunque
        el corpus no cubra la pregunta en absoluto.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        assert _buscador(idx).buscar("receta de tortilla de patatas") == []

    def test_respeta_top_k(self, tmp_path):
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        assert len(_buscador(idx).buscar("modelo", top_k=1)) <= 1

    def test_el_orden_es_determinista(self, tmp_path):
        """
        Sin desempate explícito, dos chunks con el mismo score los ordenaría su
        posición en el índice, que cambia al reindexar: el mismo informe daría
        distinto contexto en dos corridas.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        b = _buscador(idx)
        primera = [r["id"] if "id" in r else (r["fuente"], r["chunk"])
                   for r in b.buscar("modelo de riesgo y validacion", top_k=5)]
        segunda = [r["id"] if "id" in r else (r["fuente"], r["chunk"])
                   for r in b.buscar("modelo de riesgo y validacion", top_k=5)]
        assert primera == segunda

    def test_combina_las_dos_señales(self, tmp_path):
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        res = _buscador(idx).buscar("prueba de Kupiec", top_k=3)
        assert res
        r = res[0]
        for clave in ("cobertura", "score", "score_bm25", "score_tfidf",
                      "bm25_bruto", "cobertura_terminos",
                      "peso_informativo_consulta"):
            assert clave in r, f"falta {clave}: no se puede auditar el ranking"
        assert 0.0 <= r["score"] <= 1.0
        assert 0.0 <= r["cobertura"] <= 1.0

    def test_filtro_por_fuente(self, tmp_path):
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        res = _buscador(idx).buscar("modelo", top_k=5, filtro_fuente="datos.md")
        assert all(r["fuente"] == "datos.md" for r in res)

    def test_un_corpus_minusculo_no_deja_la_busqueda_muda(self, tmp_path):
        """
        Regresión del fallo encontrado al escribir estos tests: `BM25Okapi`
        calcula el IDF como log(N-df+0.5) - log(df+0.5), sin el «+1» que otras
        variantes meten dentro del logaritmo. Con N=2 y df=1 eso da EXACTAMENTE
        0, así que un término presente en uno de los dos documentos no valía
        nada y la consulta entera puntuaba cero.

        `rank_bm25` tiene un `epsilon` para esto, pero solo repara los IDF
        NEGATIVOS: el cero pasa de largo. Por eso el filtro es por cobertura.
        """
        idx = _indexador(tmp_path, {
            "kupiec.md": "La prueba de Kupiec contrasta la cobertura incondicional.",
            "liquidez.md": "El LCR exige activos liquidos de alta calidad HQLA.",
        })
        idx.construir(force=True)
        res = _buscador(idx).buscar("prueba de Kupiec", top_k=2)
        assert res, ("corpus de dos documentos: BM25 da IDF cero y la búsqueda "
                     "se queda muda")
        assert res[0]["fuente"] == "kupiec.md"


# ═════════════════════════════════════════════════════════════════════════════
# RELEVANCIA ABSOLUTA vs. POSICIÓN RELATIVA
# ═════════════════════════════════════════════════════════════════════════════
class TestRelevanciaAbsoluta:
    """
    [2026-07-31, 2ª pasada] El defecto que estos tests cierran:

    El `score` se normaliza contra el máximo de CADA consulta —hay que acotar
    BM25, que no tiene techo, para poder combinarlo con el coseno—, así que el
    mejor fragmento saca 1.00 SIEMPRE. Ese número gobernaba el umbral Y se
    inyectaba en el prompt etiquetado como «relevancia léxica: 1.00».

    Consecuencia: el primer resultado de CUALQUIER consulta llegaba al modelo y
    al informe anunciado como coincidencia perfecta, incluso cuando el corpus no
    cubría la pregunta. Ni el modelo ni un lector podían distinguir «excelente»
    de «el primero de una lista mala».

    La cura son dos números con un trabajo cada uno, más una señal sobre la
    CONSULTA. Esto lo verifica.
    """

    def test_la_cobertura_es_comparable_entre_consultas(self, tmp_path):
        """
        La propiedad que define «absoluto»: el mismo fragmento, ante una consulta
        que cubre entera y otra que cubre a medias, debe dar coberturas distintas
        — mientras que el `score` daría 1.00 en ambas por ser el mejor de su lista.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        b = _buscador(idx)

        # La consulta parcial mezcla términos de TRES documentos distintos, todos
        # presentes en el corpus. Ningún fragmento puede cubrirlos todos, así que
        # su mejor resultado —aun siendo el primero de su lista— cubre poco.
        #
        # Los términos tienen que EXISTIR en el corpus: uno inventado tiene IDF 0
        # y desaparece del cálculo, que es justo lo que verifica el test
        # siguiente. Aquí haría que la cobertura volviera a 1.00 y el test
        # mediría lo contrario de lo que pretende.
        completa = b.buscar("prueba de Kupiec cobertura incondicional", top_k=1)
        parcial = b.buscar("Kupiec activos liquidos imputacion", top_k=1)
        assert completa and parcial

        assert completa[0]["score"] == 1.0 and parcial[0]["score"] == 1.0, (
            "premisa del test: ambos son los primeros de su lista")
        assert completa[0]["cobertura"] > parcial[0]["cobertura"], (
            "la cobertura no distingue una consulta bien cubierta de una mal "
            "cubierta: ha dejado de ser absoluta")

    def test_un_termino_ausente_del_corpus_no_penaliza_la_cobertura(self, tmp_path):
        """
        Caso real: se pregunta por «excepciones» y el corpus dice «excedencias».
        Ese término tiene IDF 0, así que debe desaparecer del numerador Y del
        denominador — no penalizar al fragmento por no contener algo que NADIE
        contiene. Con cobertura sin ponderar, contaba en el denominador y hundía
        injustamente al mejor resultado.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        b = _buscador(idx)

        sin_ruido = b.buscar("prueba de Kupiec", top_k=1)
        con_ruido = b.buscar("prueba de Kupiec zzzinexistente qqqinventado", top_k=1)
        assert sin_ruido and con_ruido
        assert con_ruido[0]["cobertura"] == pytest.approx(sin_ruido[0]["cobertura"]), (
            "añadir términos que no existen en el corpus cambió la cobertura: "
            "se está penalizando al fragmento por algo que nadie contiene")

    def test_el_peso_informativo_delata_una_consulta_pobre(self, tmp_path):
        """
        La señal que faltaba. Distingue «no hay nada relevante» (corpus
        incompleto) de «no has preguntado nada distintivo» (consulta pobre), que
        piden acciones opuestas y antes eran indistinguibles.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        b = _buscador(idx)

        rica = b.diagnostico_consulta("prueba de Kupiec cobertura incondicional")
        pobre = b.diagnostico_consulta("de datos el modelo")

        assert rica["peso_informativo"] > pobre["peso_informativo"], (
            "el peso informativo no distingue una consulta rica de una vacía")
        assert rica["discriminante"] is True

    def test_una_consulta_pobre_declara_su_incertidumbre_en_el_prompt(self, tmp_path):
        """
        La cura no puede vivir solo en la documentación: el aviso tiene que
        viajar pegado al dato. Si la consulta no discrimina, el bloque inyectado
        lo dice, para que el modelo no lea como referencia sólida unos
        fragmentos que solo cubren una pregunta que no pregunta nada.
        """
        idx = _indexador(tmp_path, {
            "a.md": "El modelo de riesgo se documenta en el manual del modelo.",
            "b.md": "El modelo aplicado y el modelo alternativo se comparan.",
        })
        idx.construir(force=True)
        bloque = _buscador(idx).buscar_para_prompt("modelo", top_k=2, min_score=0.0)
        if bloque:
            assert "AVISO" in bloque, (
                "una consulta sin poder discriminante inyecta contexto sin "
                "declarar que puede no ser específico")

    def test_el_prompt_reporta_la_cobertura_no_el_score(self, tmp_path):
        """
        El número que ve el modelo —y que acaba en el informe— debe ser el
        absoluto. Etiquetar con el relativo es lo que hacía pasar por
        coincidencia perfecta al primero de cualquier lista.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        bloque = _buscador(idx).buscar_para_prompt(
            "activos liquidos HQLA", top_k=2, min_score=0.0)
        assert bloque
        assert "relevancia léxica" not in bloque, (
            "el bloque sigue etiquetando con el score relativo")
        assert "términos clave" in bloque, (
            "el bloque no dice qué mide el porcentaje que muestra")

    def test_la_cobertura_minima_descarta_el_solape_marginal(self, tmp_path):
        """
        El corte absoluto. Un fragmento que solo comparte una palabra común no
        entra, aunque sea lo mejor que hay: es la diferencia entre «no tengo
        nada» y «te doy cualquier cosa».
        """
        import src.rag.config_rag as cfg_rag
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        b = _buscador(idx)

        antes = len(b.buscar("Kupiec cobertura liquidez imputacion", top_k=10))
        monkey = cfg_rag.MIN_COBERTURA
        try:
            cfg_rag.MIN_COBERTURA = 0.99
            despues = len(b.buscar("Kupiec cobertura liquidez imputacion", top_k=10))
        finally:
            cfg_rag.MIN_COBERTURA = monkey
        assert despues < antes, (
            "subir RAG_MIN_COBERTURA no recorta nada: el umbral absoluto no "
            "está conectado")


# ═════════════════════════════════════════════════════════════════════════════
# EXPANSIÓN DE CONSULTA — la cura del punto ciego léxico
# ═════════════════════════════════════════════════════════════════════════════
class TestExpansionDeConsulta:
    """
    BM25 encuentra por coincidencia de cadena, así que «excepciones» y
    «excedencias» —sinónimos exactos en backtesting de VaR— eran términos
    distintos y uno no encontraba nada.

    Dos curas, ambas locales y aplicadas a la CONSULTA (no obligan a reindexar):
    tesauro de dominio para sinónimos, y corrección ortográfica para erratas.
    """

    # SEIS documentos, no dos. Con un corpus de 2, `BM25Okapi` asigna IDF
    # exactamente 0 a todo (ver TestRecuperacion.test_un_corpus_minusculo…), y
    # como la expansión solo añade variantes que APORTAN algo, no dispararía
    # nunca. El fixture necesita que los términos discriminen para poder probar
    # que se expanden bien.
    DOCS = {
        "kupiec.md": (
            "La serie de excedencias es una secuencia de indicadores binarios; "
            "la prueba de Kupiec contrasta la cobertura incondicional a partir "
            "del numero de excedencias observadas en la ventana."
        ),
        "seguimiento.md": (
            "El seguimiento periodico del modelo exige informes con indicadores "
            "de estabilidad y planes de accion documentados y aprobados."
        ),
        "liquidez.md": (
            "El coeficiente de cobertura exige un colchon de activos liquidos "
            "de alta calidad suficiente para cubrir las salidas netas."
        ),
        "gobierno.md": (
            "El comite aprueba las politicas y revisa las limitaciones "
            "declaradas por la unidad de validacion independiente."
        ),
        "datos.md": (
            "Los controles de integridad detectan duplicados, valores atipicos "
            "y registros incompletos antes de alimentar el calculo."
        ),
        "implementacion.md": (
            "El paso a produccion requiere pruebas en paralelo y evidencia de "
            "conciliacion entre el prototipo y el sistema definitivo."
        ),
    }

    def test_el_tesauro_une_sinonimos_del_dominio(self, tmp_path):
        """
        El caso real que motivó todo: el estándar dice «excepciones», la
        literatura dice «excedencias».
        """
        idx = _indexador(tmp_path, self.DOCS)
        idx.construir(force=True)
        b = _buscador(idx)

        res = b.buscar("numero de excepciones del VaR", top_k=2)
        assert res, ("«excepciones» no encontró «excedencias»: el tesauro no "
                     "está expandiendo la consulta")
        assert res[0]["fuente"] == "kupiec.md"

        expansiones = res[0]["expansiones"]
        assert any(e["tipo"] == "tesauro" for e in expansiones), (
            "no consta la expansión: en un informe hay que poder explicar que "
            "se buscó «excedencia» cuando el estándar decía «excepción»")

    def test_se_corrige_una_errata_del_estandar(self, tmp_path):
        """
        `Estandares_VIRF.xlsx` contiene erratas verificadas —«seguimeinto»,
        «monitorio»…— y una errata es un término que no puede coincidir con
        ninguna literatura, nunca.
        """
        idx = _indexador(tmp_path, self.DOCS)
        idx.construir(force=True)
        b = _buscador(idx)

        res = b.buscar("analizar el seguimeinto del modelo", top_k=2)
        assert res, "la errata «seguimeinto» sigue sin encontrar «seguimiento»"
        assert any(e["tipo"] == "errata" for e in res[0]["expansiones"])

    def test_la_correccion_no_inventa_parecidos(self, tmp_path):
        """
        El umbral es estricto a propósito. Corregir «tortilla» a cualquier cosa
        del corpus sería peor que no corregir: convertiría el control negativo
        en ruido con aspecto de certeza.
        """
        idx = _indexador(tmp_path, self.DOCS)
        idx.construir(force=True)
        assert _buscador(idx).buscar("receta de tortilla de patatas") == []

    def test_solo_se_expande_a_terminos_que_existen_en_el_corpus(self, tmp_path):
        """
        Añadir sinónimos que tampoco están no aporta nada y sí infla el peso
        informativo, hundiendo la cobertura de todo lo demás.
        """
        idx = _indexador(tmp_path, self.DOCS)
        idx.construir(force=True)
        b = _buscador(idx)
        b._asegurar_cargado()

        conceptos, _ = b._expandir(["excepcion"])
        idf = b._bm25.idf
        for variantes in conceptos:
            añadidas = variantes - {"excepcion"}
            for v in añadidas:
                assert idf.get(v, 0.0) > 0, (
                    f"se expandió a {v!r}, que no aporta nada en este corpus")

    def test_el_vocabulario_crudo_se_persiste(self, tmp_path):
        """
        Sin él no hay corrección de erratas: comparar contra los tokens ya
        derivados no funciona («seguimiento» → «segu», demasiado lejos de
        «seguimeinto»).
        """
        idx = _indexador(tmp_path, self.DOCS)
        indice = idx.construir(force=True)
        assert "seguimiento" in indice.vocabulario_crudo
        assert "excedencias" in indice.vocabulario_crudo

        recargado = idx.cargar()
        assert recargado is not None
        assert recargado.vocabulario_crudo == indice.vocabulario_crudo

    def test_desactivar_el_tesauro_lo_desactiva(self, tmp_path, monkeypatch):
        """
        Un mando que no se puede accionar es peor que no ofrecerlo.

        Se compara la EXPANSIÓN, no la lista de resultados: la consulta también
        contiene «excedencias»→«numero», que casa por su cuenta, así que apagar
        el tesauro no vacía los resultados — solo deja de unir los sinónimos.
        Afirmar lo segundo sería un test que pasa por el motivo equivocado.
        """
        import src.rag.config_rag as cfg_rag
        from src.rag.buscador_lexico import BuscadorLexico

        idx = _indexador(tmp_path, self.DOCS)
        idx.construir(force=True)

        con_b = _buscador(idx)
        con = con_b.buscar("numero de excepciones", top_k=1)
        assert con and any(e["tipo"] == "tesauro" for e in con[0]["expansiones"])

        monkeypatch.setattr(cfg_rag, "TESAURO_ACTIVO", False)
        monkeypatch.setattr(cfg_rag, "CORREGIR_ERRATAS", False)
        sin_b = BuscadorLexico(idx.dominio, autoconstruir=False)
        sin_b._indexador = idx
        sin = sin_b.buscar("numero de excepciones", top_k=1)

        assert not sin or not sin[0]["expansiones"], (
            "el tesauro sigue expandiendo con RAG_TESAURO desactivado")

        # El efecto NO se ve en la cobertura del mejor fragmento —que puede ser
        # 1.00 en ambos casos, porque «numero» ya casa por su cuenta— sino en el
        # PESO INFORMATIVO: con el tesauro, «excepciones» deja de valer cero y la
        # consulta pasa a preguntar algo que el corpus puede responder.
        peso_con = con[0]["peso_informativo_consulta"]
        peso_sin = sin[0]["peso_informativo_consulta"] if sin else 0.0
        assert peso_con > peso_sin, (
            f"el tesauro no aportó poder discriminante: {peso_con} vs {peso_sin}")

    def test_el_peso_informativo_no_cuenta_dos_veces_la_misma_idea(self, tmp_path):
        """
        Si el tesauro añade «exced» como variante de «excepcion», son la MISMA
        idea: contarlas por separado inflaría esa parte de la consulta y
        desinflaría la cobertura de todo lo demás.
        """
        idx = _indexador(tmp_path, self.DOCS)
        idx.construir(force=True)
        b = _buscador(idx)

        solo_una = b.diagnostico_consulta("excedencias")["peso_informativo"]
        con_sinonimo = b.diagnostico_consulta("excepciones")["peso_informativo"]
        assert con_sinonimo == pytest.approx(solo_una, abs=0.01), (
            "expandir un término duplicó su peso: la cobertura queda falseada")


# ═════════════════════════════════════════════════════════════════════════════
# INTEGRACIÓN CON EL AGENTE
# ═════════════════════════════════════════════════════════════════════════════
class TestIntegracionConElMotor:

    def test_el_retriever_de_dominio_expone_la_api_que_motor_ia_consume(self):
        """
        `modulos/motor_ia.py` llama a `query_para_prompt(query, top_k, min_score)`.
        La sustitución del motor NO podía cambiar esa firma: si lo hubiera hecho,
        `_enriquecer_con_rag` capturaría el TypeError y devolvería "" — el RAG
        quedaría apagado en silencio, que es exactamente el estado del que se
        venía.
        """
        import inspect
        from src.rag import get_retriever

        r = get_retriever(tipo_modelo="VaR")
        for metodo in ("query", "query_para_prompt"):
            assert hasattr(r, metodo), f"el retriever perdió {metodo}()"
        firma = inspect.signature(r.query_para_prompt).parameters
        assert {"texto_consulta", "top_k", "min_score"} <= set(firma)

    def test_la_inferencia_de_dominio_sigue_funcionando(self):
        from src.rag import inferir_dominio
        assert inferir_dominio("Modelo LaR Liquidez") == "LaR"
        assert inferir_dominio("VaR Mercado FRTB") == "VaR"
        assert inferir_dominio("Scoring de originacion") == "shared"

    def test_el_bloque_para_prompt_no_lleva_cabecera_vacia(self, tmp_path):
        """
        "" es la señal que `motor_ia` interpreta como «sin contexto RAG». Un
        encabezado «Conocimiento recuperado» sin nada debajo invita al modelo a
        rellenar el hueco.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        assert _buscador(idx).buscar_para_prompt("receta de paella") == ""

    def test_el_bloque_para_prompt_cita_la_fuente(self, tmp_path):
        """
        Sin la fuente en el bloque, el modelo recibe afirmaciones regulatorias
        sin procedencia y el informe no puede trazar de dónde salió una cita.
        """
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        bloque = _buscador(idx).buscar_para_prompt(
            "excepciones y prueba de Kupiec", top_k=3, min_score=0.0)
        assert "kupiec.md" in bloque
        assert "Fuente:" in bloque

    def test_el_fallo_del_rag_no_tumba_una_validacion(self, tmp_path, monkeypatch):
        """
        Invariante de todo el subsistema: el RAG ENRIQUECE el prompt. Si falla,
        la validación continúa sin contexto — nunca se propaga la excepción.
        """
        from src.rag.VaR.retriever import VaRRetriever

        r = VaRRetriever()

        def _explota(*a, **kw):
            raise RuntimeError("disco ilegible")

        monkeypatch.setattr(r, "_get_buscador", _explota)
        assert r.query("lo que sea") == []
        assert r.query_para_prompt("lo que sea") == ""


# ═════════════════════════════════════════════════════════════════════════════
# RENDIMIENTO
# ═════════════════════════════════════════════════════════════════════════════
class TestRendimiento:

    def test_la_consulta_es_de_milisegundos(self, tmp_path):
        """
        El argumento de esta arquitectura es que sin llamadas a API la
        recuperación es instantánea. Si una consulta tardara segundos, evaluar
        decenas de actividades por informe volvería a ser el cuello de botella
        que se quiso eliminar.

        El umbral es holgado a propósito (250 ms): esto corre en CI compartido y
        un test de rendimiento que falla por carga de la máquina es ruido.
        """
        import time
        idx = _indexador(tmp_path, DOCS_REGULATORIOS)
        idx.construir(force=True)
        b = _buscador(idx)
        b.buscar("calentamiento")          # excluye la carga inicial del índice

        t0 = time.perf_counter()
        for _ in range(10):
            b.buscar("prueba de Kupiec y cobertura incondicional", top_k=5)
        media = (time.perf_counter() - t0) / 10
        assert media < 0.25, f"consulta lenta: {media*1000:.0f} ms de media"
