"""
tests/test_docx_regresion.py — WP-08 (estructura): reporte .docx desde
ValidationReport mock. Sin API (no usa el pipeline real).

Verifica las 4 secciones obligatorias del artefacto primario:
  1. veredictos por ámbito (APROBADO/PENDIENTE/NO APROBADO)
  2. declaración "sin observaciones"
  3. pie dinámico con paginación (campo PAGE)
  4. sección de referencias consolidada
Mueve F2/F3 de ROJO a VERDE. F1 (generación desde el pipeline real) = Día 3.
"""
from docx import Document

from modulos.esquemas import desde_dict
from modulos.reporte_docx import (
    generar_docx_validacion,
    veredicto_de_ambito,
    APROBADO,
    PENDIENTE,
    NO_APROBADO,
    SIN_OBSERVACIONES,
)


def _reporte_mock() -> dict:
    return {
        "model_id": "VAR_RETAIL_01",
        "overall_confidence": 0.78,
        "abstained": False,
        "unresolved_conflicts": [],
        "findings": [
            {   # VaR: un desvío → NO APROBADO
                "requirement_id": "REQ-VAR-99",
                "ambito": "VaR",
                "status": "DESVIADO",
                "evidence_text": "Manual VaR, pág. 4: nivel de confianza 99%.",
                "code_evidence": "modelo_var.py:12  q=0.05  # 95%, no 99%",
                "justification": "El código usa 95% donde el manual exige 99%.",
            },
            {   # ALM: implementado → APROBADO
                "requirement_id": "REQ-ALM-01",
                "ambito": "ALM",
                "status": "IMPLEMENTADO",
                "evidence_text": "Manual ALM, pág. 8: gap de duración.",
                "code_evidence": "alm.py:40  duration_gap()",
                "justification": "El gap de duración está implementado según el manual.",
            },
        ],
    }


def _texto_completo(path) -> str:
    doc = Document(str(path))
    return "\n".join(p.text for p in doc.paragraphs)


def test_veredicto_de_ambito_reglas():
    assert veredicto_de_ambito([]) == APROBADO
    assert veredicto_de_ambito(["IMPLEMENTADO"]) == APROBADO
    assert veredicto_de_ambito(["PARCIAL"]) == PENDIENTE
    assert veredicto_de_ambito(["IMPLEMENTADO", "OMITIDO"]) == NO_APROBADO
    assert veredicto_de_ambito(["DESVIADO"]) == NO_APROBADO


def test_genera_docx_con_veredictos_por_ambito(tmp_path):
    rep = desde_dict(_reporte_mock())
    ruta = generar_docx_validacion(rep, tmp_path / "informe.docx")
    assert ruta.exists()
    texto = _texto_completo(ruta)
    # SECCIÓN 1: veredictos por ámbito
    assert f"VaR: {NO_APROBADO}" in texto
    assert f"ALM: {APROBADO}" in texto


def test_seccion_sin_observaciones(tmp_path):
    # Un ámbito sin hallazgos declara "sin observaciones".
    d = _reporte_mock()
    d["findings"].append({
        "requirement_id": "REQ-LAR-00",
        "ambito": "LaR",
        "status": "IMPLEMENTADO",
        "evidence_text": "Manual LaR pág. 2.",
        "code_evidence": "lar.py:1",
        "justification": "ok",
    })
    # Reporte alterno: un ámbito 'conductuales' vacío se prueba con reporte vacío.
    vacio = desde_dict({"model_id": "M", "overall_confidence": 0.0, "abstained": False})
    ruta = generar_docx_validacion(vacio, tmp_path / "vacio.docx")
    assert SIN_OBSERVACIONES in _texto_completo(ruta)


def test_seccion_referencias_consolidada(tmp_path):
    rep = desde_dict(_reporte_mock())
    ruta = generar_docx_validacion(rep, tmp_path / "informe.docx")
    texto = _texto_completo(ruta)
    assert "Referencias" in texto
    assert "Manual VaR, pág. 4" in texto        # cita documental consolidada
    assert "modelo_var.py:12" in texto          # evidencia de código consolidada


def test_pie_con_paginacion_tiene_campo_page(tmp_path):
    rep = desde_dict(_reporte_mock())
    ruta = generar_docx_validacion(rep, tmp_path / "informe.docx")
    doc = Document(str(ruta))
    # El footer debe contener un campo PAGE (fldChar) — paginación dinámica.
    xml_footer = doc.sections[0].footer._element.xml
    assert "PAGE" in xml_footer
    assert "fldChar" in xml_footer


def test_abstencion_se_declara_en_el_docx(tmp_path):
    rep = desde_dict({"model_id": "M", "overall_confidence": 0.0, "abstained": True})
    ruta = generar_docx_validacion(rep, tmp_path / "abst.docx")
    assert "EVIDENCIA INSUFICIENTE" in _texto_completo(ruta)
