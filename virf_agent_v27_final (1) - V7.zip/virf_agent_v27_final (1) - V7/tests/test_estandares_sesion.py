"""
Tests del paso 02 · Estándares de validación por sesión (WEB-V2.4).

Cubre:
  - Parseo del .xlsx con celdas combinadas simulando ámbito/control merged.
  - Rechazo de Excel sin cabeceras obligatorias.
  - Marca de tier: normalización de "X", "x", "", None.
  - guardar_xlsx + confirmar + estado (round-trip).
  - CLI flag --estandares: `redirigir_estandar` actualiza RUTAS["estandares_virf"].
  - pipeline_runner.construir_args añade --estandares cuando la sesión tiene JSON.
"""
from __future__ import annotations

from pathlib import Path

import openpyxl
import pytest

from web.services import estandares_service


@pytest.fixture
def ctx_de_prueba(tmp_path: Path) -> dict:
    base = tmp_path / "sesion"
    (base / "inputs").mkdir(parents=True, exist_ok=True)
    return {
        "validador": {"codigo": "T5443", "nombre": "Test"},
        "modelo":    {"slug": "MOD_EST", "nombre": "Modelo Est", "dominio": "VaR", "tier": "II"},
        "base":      base,
        "inputs":    base / "inputs",
        "outputs":   base / "outputs",
        "clave":     "T5443/MOD_EST",
    }


def _crear_xlsx_estandar(ruta: Path,
                          filas: list[tuple]) -> None:
    """
    Crea un .xlsx con la cabecera esperada + `filas`. openpyxl no expande
    merged cells al leer con `values_only=True`, así que `None` en las
    columnas de AMBITO/CONTROL simula la celda combinada de abajo del
    vértice — es exactamente el caso que el parser resuelve propagando el
    último valor no vacío.
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["AMBITO", "CONTROL CUANTITATIVO Y CUALITATIVO", "ACTIVIDAD",
               "TIER I", "TIER II", "TIER III", "TIER IV"])
    for f in filas:
        ws.append(list(f))
    wb.save(ruta)


class TestParseo:
    def test_parseo_basico_con_merged_simulado(self, tmp_path):
        xlsx = tmp_path / "est.xlsx"
        _crear_xlsx_estandar(xlsx, [
            ("Documentación", "Manual metodológico", "Verifica control de cambios", "X", "X", "X", "X"),
            (None,            None,                  "Verifica objetivo y usos",  "X", "X", "X", "X"),
            (None,            "Manual de implementación", "Otra actividad",         "X", "",  "X", ""),
            ("Metodología",   "Backtesting",          "Kupiec",                    "X", "X", "X", "X"),
        ])
        d = estandares_service.parsear(xlsx)
        assert d["summary"]["total_ambitos"]     == 2
        assert d["summary"]["total_actividades"] == 4
        doc = next(a for a in d["estandares"] if a["ambito"] == "Documentación")
        assert len(doc["controles"]) == 2
        assert doc["controles"][0]["nombre"] == "Manual metodológico"
        assert len(doc["controles"][0]["actividades"]) == 2
        # Marca tier normalizada
        act = doc["controles"][1]["actividades"][0]
        assert act["tier_1"] is True
        assert act["tier_2"] is False
        assert act["tier_3"] is True
        assert act["tier_4"] is False

    def test_rechaza_sin_cabeceras(self, tmp_path):
        xlsx = tmp_path / "malo.xlsx"
        wb = openpyxl.Workbook()
        wb.active.append(["X", "Y", "Z"])
        wb.save(xlsx)
        with pytest.raises(estandares_service.EstandarInvalido, match="faltan columnas"):
            estandares_service.parsear(xlsx)

    def test_rechaza_sin_actividades(self, tmp_path):
        xlsx = tmp_path / "vacio.xlsx"
        _crear_xlsx_estandar(xlsx, [])
        with pytest.raises(estandares_service.EstandarInvalido, match="ninguna actividad"):
            estandares_service.parsear(xlsx)

    def test_orden_ambitos_es_de_aparicion(self, tmp_path):
        xlsx = tmp_path / "orden.xlsx"
        _crear_xlsx_estandar(xlsx, [
            ("Metodología", "C1", "A1", "X", "X", "X", "X"),
            ("Gobierno",    "C2", "A2", "X", "X", "X", "X"),
            (None,          None, "A3", "X", "X", "X", "X"),
        ])
        d = estandares_service.parsear(xlsx)
        assert [a["ambito"] for a in d["estandares"]] == ["Metodología", "Gobierno"]


class TestPersistencia:
    def test_roundtrip_upload_confirmar_estado(self, tmp_path, ctx_de_prueba):
        xlsx_src = tmp_path / "src.xlsx"
        _crear_xlsx_estandar(xlsx_src, [
            ("Documentación", "Manual", "A1", "X", "X", "X", "X"),
        ])
        # Simular upload: bytes → guardar_xlsx.
        estandares_service.guardar_xlsx(ctx_de_prueba, xlsx_src.read_bytes())
        assert estandares_service.ruta_xlsx(ctx_de_prueba).is_file()

        st = estandares_service.estado(ctx_de_prueba)
        assert st["subido"] is True
        assert st["confirmado"] is False

        parseado = estandares_service.parsear(estandares_service.ruta_xlsx(ctx_de_prueba))
        estandares_service.confirmar(ctx_de_prueba, parseado, validador="T5443")

        st = estandares_service.estado(ctx_de_prueba)
        assert st["confirmado"] is True
        assert st["confirmado_por"] == "T5443"
        assert st["summary"]["total_actividades"] == 1

    def test_limpiar_borra_ambos_ficheros(self, tmp_path, ctx_de_prueba):
        xlsx_src = tmp_path / "src.xlsx"
        _crear_xlsx_estandar(xlsx_src, [("A", "C", "act", "X", "", "", "")])
        estandares_service.guardar_xlsx(ctx_de_prueba, xlsx_src.read_bytes())
        parseado = estandares_service.parsear(estandares_service.ruta_xlsx(ctx_de_prueba))
        estandares_service.confirmar(ctx_de_prueba, parseado, validador="T5443")
        estandares_service.limpiar(ctx_de_prueba)
        st = estandares_service.estado(ctx_de_prueba)
        assert st["subido"] is False
        assert st["confirmado"] is False


class TestCliFlagEstandares:
    def test_redirigir_estandar_actualiza_rutas(self, tmp_path):
        """El flag --estandares reapunta RUTAS["estandares_virf"] al xlsx dado."""
        xlsx = tmp_path / "alt.xlsx"
        wb = openpyxl.Workbook(); wb.save(xlsx)
        from motor.Mx_00_CargaRutas import redirigir_estandar, RUTAS
        original = RUTAS["estandares_virf"]
        try:
            nueva = redirigir_estandar(xlsx)
            assert nueva == xlsx.resolve()
            assert RUTAS["estandares_virf"] == xlsx.resolve()
        finally:
            # Restaurar en TODAS las copias del módulo — redirigir_estandar
            # muta todas las de sys.modules; restaurar solo esta dejaría al
            # resto de la suite con el xlsx de tmp_path (ya borrado) como
            # estándar activo, y los tests posteriores fallan al leerlo.
            if original.exists():
                redirigir_estandar(original)

    def test_redirigir_estandar_lanza_si_no_existe(self, tmp_path):
        from motor.Mx_00_CargaRutas import redirigir_estandar
        with pytest.raises(FileNotFoundError):
            redirigir_estandar(tmp_path / "no_existe.xlsx")

    def test_pipeline_runner_pasa_estandares_si_confirmado(self, tmp_path):
        from web.services import pipeline_runner
        base = tmp_path / "sesion"
        base.mkdir(parents=True, exist_ok=True)
        args = pipeline_runner.construir_args(
            base_sesion=base, titulo="M", tier="II", dominio="VaR",
            validador="T5443", cargo="Val",
            estandar_override=tmp_path / "custom.xlsx",
        )
        assert "--estandares" in args
        assert str(tmp_path / "custom.xlsx") in args

    def test_pipeline_runner_omite_estandares_si_no_override(self, tmp_path):
        from web.services import pipeline_runner
        base = tmp_path / "sesion"
        base.mkdir(parents=True, exist_ok=True)
        args = pipeline_runner.construir_args(
            base_sesion=base, titulo="M", tier="II", dominio="VaR",
            validador="T5443", cargo="Val",
        )
        assert "--estandares" not in args
