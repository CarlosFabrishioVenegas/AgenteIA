# -*- coding: utf-8 -*-
"""
web/requirements_web.txt debe fijar versiones exactas (==), como requirements.txt.

Con `>=` el Python del sistema y el .venv acabaron con FastAPI 0.121 y 0.141, y
esa diferencia cambia comportamiento (desde 0.13x `include_router` ya no aplana
las rutas). Un entorno web no reproducible es un informe no reproducible.
"""
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]


def test_dependencias_web_con_version_exacta():
    lineas = [
        l.split("#")[0].strip()
        for l in (RAIZ / "web" / "requirements_web.txt").read_text(encoding="utf-8").splitlines()
    ]
    deps = [l for l in lineas if l]
    assert deps, "requirements_web.txt vacío"
    sin_fijar = [d for d in deps if "==" not in d]
    assert not sin_fijar, f"dependencias web sin versión exacta (==): {sin_fijar}"
