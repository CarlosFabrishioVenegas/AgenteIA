# -*- coding: utf-8 -*-
"""
Los recorridos del árbol deben reconocer un entorno virtual por `pyvenv.cfg`,
no por su nombre. Con el filtro por nombre, un entorno llamado `env/` o un
respaldo `.venv_respaldo/` dentro del proyecto daba 7 tests en rojo falsos.
"""
from _arbol import es_de_entorno_virtual


def _entorno_falso(raiz, nombre):
    carpeta = raiz / nombre
    (carpeta / "Lib" / "site-packages" / "libx").mkdir(parents=True)
    (carpeta / "pyvenv.cfg").write_text("home = C:\\Python310\n", encoding="utf-8")
    (carpeta / "Scripts").mkdir()
    return carpeta


def test_entorno_con_nombre_arbitrario_se_reconoce(tmp_path):
    env = _entorno_falso(tmp_path, "env_respaldo")      # ni 'venv' ni '.venv'
    fichero = env / "Scripts" / "algo.py"
    fichero.write_text("x = 1\n", encoding="utf-8")
    assert es_de_entorno_virtual(fichero, tmp_path)


def test_site_packages_se_reconoce(tmp_path):
    env = _entorno_falso(tmp_path, ".venv-3.11")
    lib = env / "Lib" / "site-packages" / "libx" / "__init__.py"
    lib.write_text("", encoding="utf-8")
    assert es_de_entorno_virtual(lib, tmp_path)


def test_codigo_del_proyecto_no_se_confunde_con_entorno(tmp_path):
    (tmp_path / "pyvenv.cfg").write_text("", encoding="utf-8")   # la raíz no cuenta
    propio = tmp_path / "modulos" / "motor.py"
    propio.parent.mkdir()
    propio.write_text("x = 1\n", encoding="utf-8")
    assert not es_de_entorno_virtual(propio, tmp_path)
