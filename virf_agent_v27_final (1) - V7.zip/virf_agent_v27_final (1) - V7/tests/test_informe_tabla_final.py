"""
tests/test_informe_tabla_final.py — la tabla final se cablea al .docx. Coste 0.
"""
import pytest


def test_seccion_tabla_final_agrega_tabla_y_puntaje(monkeypatch):
    from web.services import informe_web
    from docx import Document
    # Sin sesión de chat → tabla_final == tabla intermedia, score_final == inicial.
    monkeypatch.setattr(informe_web.chat_service, "sesion_activa", lambda ctx: None)

    datos = {
        "score_global": 2.0,
        "resultados_por_ambito": {"Metodología": [{"actividad": "A1", "puntaje": 2}]},
        "tabla_validacion": [{
            "ambito": "Metodología", "control": "C", "actividad": "A1",
            "resultado": "No cumple", "evaluacion_sustentada": "sustento",
            "fuente_revisada": "evidencia", "accion_requerida": "plan", "tier": "I",
        }],
    }
    doc = Document()
    informe_web._seccion_tabla_final(doc, datos, {})

    assert any(len(t.columns) == 8 for t in doc.tables)      # 8 columnas
    textos = "\n".join(p.text for p in doc.paragraphs)
    assert "2. Tabla de validación (final)" in textos
    assert "PUNTAJE FINAL" in textos
    # Encabezados en la tabla de 8 columnas
    tabla8 = next(t for t in doc.tables if len(t.columns) == 8)
    heads = [c.text for c in tabla8.rows[0].cells]
    assert heads == ["Ámbito", "Control", "Actividad", "Aplica",
                     "Resultado", "Sustento", "Evidencia", "Plan de acción"]


def test_seccion_vacia_no_revienta(monkeypatch):
    from web.services import informe_web
    from docx import Document
    monkeypatch.setattr(informe_web.chat_service, "sesion_activa", lambda ctx: None)
    doc = Document()
    informe_web._seccion_tabla_final(doc, {"tabla_validacion": []}, {})  # sin filas
    assert not doc.tables


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
