"""Motor de deteccion FraudeAML. Corre cada hora sobre la ventana movil."""
import pandas as pd
from sklearn.ensemble import IsolationForest

REGLAS_ALTA = ("R01", "R02")
UMBRAL_ANOMALIA = 0.62
LISTA_GAFI = ("KP", "IR", "MM")


def aplicar_reglas(tx):
    """Capa 1: reglas deterministicas de negocio."""
    tx["R01"] = (tx.groupby("titular")["monto"]
                   .transform(lambda s: (s < 10000).rolling(48).sum() > 3))
    tx["R02"] = tx["jurisdiccion_contraparte"].isin(LISTA_GAFI)
    tx["R03"] = tx.groupby("titular")["id"].transform("count") > 15
    tx["R04"] = tx["monto"] > 20 * tx["monto_promedio_historico"]
    return tx


def score_anomalia(tx, variables):
    """Capa 2: Isolation Forest sobre comportamiento transaccional."""
    modelo = IsolationForest(contamination=0.005, random_state=42)
    modelo.fit(tx[variables])
    tx["anomaly_score"] = -modelo.score_samples(tx[variables])
    return tx


def generar_alertas(tx):
    """Combina ambas capas y produce la cola de revision."""
    dispara_alta = tx[list(REGLAS_ALTA)].any(axis=1)
    dispara_modelo = tx["anomaly_score"] > UMBRAL_ANOMALIA
    tx["alerta"] = dispara_alta | dispara_modelo
    return tx[tx["alerta"]]
