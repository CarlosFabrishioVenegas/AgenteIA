# Manual Metodologico - Modelo FraudeAML (Deteccion de Transacciones Sospechosas)

## 1. Objetivo
Identificar transacciones potencialmente asociadas a lavado de activos o fraude
transaccional, para su escalamiento al Oficial de Cumplimiento.

## 2. Arquitectura de deteccion

**Capa 1 - Reglas de negocio deterministicas**

| Regla | Condicion | Severidad |
|---|---|---|
| R01 Estructuracion | > 3 depositos < 10,000 en 48h mismo titular | ALTA |
| R02 Jurisdiccion de riesgo | Contraparte en lista GAFI de alto riesgo | ALTA |
| R03 Velocidad atipica | > 15 transacciones en 1h | MEDIA |
| R04 Monto atipico | Monto > 20x el promedio historico del cliente | MEDIA |

**Capa 2 - Modelo de anomalias**

Isolation Forest sobre 14 variables de comportamiento transaccional
(frecuencia, monto, dispersion geografica, horario, contrapartes distintas).
Contaminacion configurada en 0.5%.

## 3. Umbral de alerta
Se genera alerta si dispara cualquier regla de severidad ALTA, o si el anomaly
score del Isolation Forest supera 0.62.

## 4. Escalamiento
Las alertas se envian a la cola del Oficial de Cumplimiento, que dispone de
72 horas para descartar o elevar a ROS (Reporte de Operacion Sospechosa).

## 5. Governance
Aprobado por el Comite de Cumplimiento el 2025-06-30.
