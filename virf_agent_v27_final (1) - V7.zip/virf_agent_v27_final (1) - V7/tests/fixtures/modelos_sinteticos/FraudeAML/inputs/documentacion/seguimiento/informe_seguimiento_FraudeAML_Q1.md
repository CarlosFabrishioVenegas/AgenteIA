# Informe de Seguimiento - FraudeAML - Q1 2026

## Volumetria de alertas
| Mes | Transacciones | Alertas | % alertado |
|---|---|---|---|
| Ene | 2,410,332 | 14,880 | 0.62% |
| Feb | 2,238,110 | 19,442 | 0.87% |
| Mar | 2,502,901 | 26,115 | 1.04% |

## Hallazgos
1. Crecimiento sostenido del volumen de alertas sin cambio en la configuracion
   del modelo ni en el umbral.
2. La cola del Oficial de Cumplimiento acumula 4,100 alertas sin revisar al
   cierre de marzo.
3. La regla R03 (velocidad atipica) concentra el 41% de las alertas generadas.
4. Se emitieron 38 ROS en el trimestre.

## Acciones
- Revision del umbral de R03 - dueno: Cumplimiento.
- Priorizacion de cola por severidad - dueno: TI.
