# Perfil de Datos - FraudeAML

## Fuentes
- Switch transaccional - todas las operaciones en linea.
- Maestro de clientes - segmento, antiguedad, actividad economica declarada.
- Listas de vigilancia (GAFI, OFAC) - actualizacion semanal por proveedor.

## Chequeos
| Chequeo | Resultado | Tasa |
|---|---|---|
| Geolocalizacion ausente | ADVERTENCIA | 12.4% |
| Actividad economica sin declarar | ALERTA | 18.9% |
| Monto negativo o cero | OK | 0% |
| Duplicados por id de transaccion | OK | 0% |
| Frescura de listas de vigilancia | ADVERTENCIA | hasta 7 dias |

## Observaciones
- El 12.4% de transacciones sin geolocalizacion se procesan igual; la variable
  de dispersion geografica se calcula solo con las que si la tienen.
- La actividad economica sin declarar se agrupa en la categoria "OTROS", que
  concentra el 18.9% de la cartera.
