"""Implementacion del scorecard PD_Retail. Ejecucion batch diaria."""
import numpy as np
import pandas as pd


def aplicar_woe(df, mapa_woe):
    """Sustituye cada valor por su WOE segun el binning de desarrollo."""
    for var, bins in mapa_woe.items():
        df[var + "_woe"] = pd.cut(df[var], bins=bins["cortes"],
                                  labels=bins["woe"]).astype(float)
    return df


def calcular_score(df, coeficientes, offset=600.0, factor=28.8539):
    """Combina los WOE con los coeficientes y escala el logit a puntos."""
    logit = coeficientes["intercepto"]
    for var, beta in coeficientes["betas"].items():
        logit += beta * df[var + "_woe"]
    pd_estimada = 1.0 / (1.0 + np.exp(-logit))
    odds = (1 - pd_estimada) / pd_estimada
    df["score"] = offset + factor * np.log(odds)
    df["pd"] = pd_estimada
    return df


def decidir(df, corte=580):
    """Regla de decision automatica sobre el score."""
    df["decision"] = np.where(df["score"] >= corte, "APROBAR", "RECHAZAR")
    return df


def ejecutar(ruta_solicitudes, mapa_woe, coeficientes):
    """Orquesta la corrida diaria: lee, imputa, puntua y decide."""
    df = pd.read_csv(ruta_solicitudes)
    df = df.fillna(df.mean(numeric_only=True))
    df = aplicar_woe(df, mapa_woe)
    df = calcular_score(df, coeficientes)
    return decidir(df)
