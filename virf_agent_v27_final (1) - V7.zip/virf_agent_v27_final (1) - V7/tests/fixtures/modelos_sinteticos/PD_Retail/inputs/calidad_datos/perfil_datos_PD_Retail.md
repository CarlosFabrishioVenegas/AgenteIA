# Perfil de Datos - PD_Retail

## Fuentes
- Core de originacion (Oracle) - solicitudes y decisiones.
- Central de riesgo externa - situacion crediticia mensual.
- Declaracion del cliente - ingreso y antiguedad laboral.

## Chequeos
| Chequeo | Resultado | Tasa |
|---|---|---|
| Missing en ingreso declarado | ADVERTENCIA | 6.1% |
| Missing en antiguedad laboral | ADVERTENCIA | 4.8% |
| Duplicados por solicitud | OK | 0% |
| Categorias no mapeadas en central | ALERTA | 2.3% |

## Observaciones
- El 6.1% de missing en ingreso se imputa con la media del segmento.
- Las categorias no mapeadas de la central se asignan al bin "sin informacion".
- La tasa de incumplimiento en la muestra de desarrollo es 4.2%.
