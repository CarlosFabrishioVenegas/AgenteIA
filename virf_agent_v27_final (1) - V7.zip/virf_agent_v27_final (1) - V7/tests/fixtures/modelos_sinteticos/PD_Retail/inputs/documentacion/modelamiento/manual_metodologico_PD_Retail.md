# Manual Metodologico - Modelo PD_Retail (Probabilidad de Incumplimiento Retail)

## 1. Objetivo
Estimar la probabilidad de que un cliente de banca personas entre en mora mayor
a 90 dias dentro de los 12 meses siguientes a la originacion.

## 2. Marco teorico
Scorecard construido sobre **regresion logistica** con variables transformadas
mediante **Weight of Evidence (WOE)**. La seleccion de variables se realiza por
**Information Value (IV)**, reteniendo aquellas con IV entre 0.02 y 0.5.

    logit(PD) = beta_0 + suma_i beta_i * WOE_i(x_i)

El score se escala a puntos mediante:

    Score = Offset + Factor * ln(odds)

con Factor = 20/ln(2) y Offset calibrado a 600 puntos para odds 50:1.

## 3. Variables del scorecard
| Variable | Tipo | IV |
|---|---|---|
| Antiguedad laboral | Continua (binned) | 0.31 |
| Ingreso mensual declarado | Continua (binned) | 0.24 |
| Peor situacion 12m en central de riesgo | Categorica | 0.42 |
| Numero de entidades con deuda vigente | Discreta | 0.18 |
| Edad del titular | Continua (binned) | 0.06 |

## 4. Punto de corte
Se aprueban solicitudes con Score >= 580. Por debajo se rechaza automaticamente.

## 5. Muestra de desarrollo
Originaciones entre 2023-01 y 2024-06. Ventana de desempeno de 12 meses.
Total 84,500 solicitudes.

## 6. Governance
Aprobado por Comite de Modelos el 2025-11-20. Owner: Gerencia de Riesgo Retail.
Recalibracion prevista cada 24 meses.
