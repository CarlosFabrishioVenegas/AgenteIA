# Informe de Seguimiento - PD_Retail - H1 2026

## Metricas de discriminacion
| Metrica | Desarrollo | Actual | Umbral |
|---|---|---|---|
| Gini | 0.52 | 0.41 | >= 0.45 |
| KS  | 0.38 | 0.29 | >= 0.30 |
| AUC | 0.76 | 0.71 | >= 0.72 |

## Hallazgos
1. Deterioro sostenido del poder discriminante durante los ultimos 3 trimestres.
2. La tasa de aprobacion subio de 61% a 73% sin cambio en el punto de corte.
3. La variable "Peor situacion 12m" perdio poder predictivo tras el cambio de
   reporte de la central de riesgo en 2025-09.

## Acciones
- Revision del scorecard programada para 2026-09.
- Analisis de la variable de central de riesgo - dueno: Equipo de Modelos.
