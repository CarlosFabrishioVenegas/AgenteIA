# Informe de Seguimiento - IFRS9_Provisiones - Q1 2026

## Evolucion de la provision
| Concepto | Dic-2025 | Mar-2026 | Var |
|---|---|---|---|
| ECL total (MM) | 412 | 487 | +18.2% |
| Cobertura Stage 3 | 61% | 58% | -3 pp |
| % cartera en Stage 2 | 8.4% | 13.1% | +4.7 pp |

## Hallazgos
1. Migracion relevante de Stage 1 a Stage 2 concentrada en el segmento de
   consumo sin garantia.
2. El backtesting de PD muestra subestimacion en el segmento microempresa:
   PD observada 7.8% vs estimada 5.1%.
3. La provision crecio 18.2% mientras la cartera crecio 3.4%.

## Acciones
- Recalibracion de PD del segmento microempresa - dueno: Equipo de Modelos.
- Revision de la definicion de SICR - dueno: Riesgo Crediticio.
