# Manual Metodologico - Modelo IFRS9_Provisiones (Perdida Esperada Crediticia)

## 1. Objetivo
Estimar la perdida crediticia esperada (ECL) de la cartera de colocaciones
conforme a NIIF 9, para el registro contable de provisiones.

## 2. Ecuacion fundamental

    ECL = suma_t [ PD_t * LGD_t * EAD_t * FD_t ]

donde FD_t es el factor de descuento a la tasa de interes efectiva original.

## 3. Clasificacion por etapas (staging)

| Etapa | Criterio | Horizonte de ECL |
|---|---|---|
| Stage 1 | Sin incremento significativo de riesgo | 12 meses |
| Stage 2 | Incremento significativo (SICR) | Vida remanente |
| Stage 3 | Deterioro crediticio evidenciado | Vida remanente |

**Criterio SICR:** se considera incremento significativo si la PD lifetime
actual supera en mas de 2x la PD lifetime de originacion, o si existe mora
mayor a 30 dias.

## 4. Componente forward-looking
La PD point-in-time se ajusta por escenarios macroeconomicos:

    PD_PiT = PD_TTC * f(PIB, desempleo, tipo de cambio)

Se emplean tres escenarios: base, adverso y optimista.

## 5. LGD
Estimada por severidad historica de recuperaciones sobre operaciones en default
cerradas entre 2019 y 2024, segmentada por tipo de garantia.

## 6. Governance
Modelo aprobado por el Directorio el 2025-12-10. Owner: Gerencia de Riesgo
Crediticio. Revision conjunta con Contabilidad.
