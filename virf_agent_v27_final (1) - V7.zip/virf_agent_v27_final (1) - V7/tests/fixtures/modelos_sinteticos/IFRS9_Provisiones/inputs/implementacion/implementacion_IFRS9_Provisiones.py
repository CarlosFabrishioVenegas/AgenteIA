"""Motor de calculo de ECL bajo NIIF 9. Corrida mensual de cierre contable."""
import numpy as np


def clasificar_etapa(cartera):
    """Asigna Stage 1/2/3 segun criterio SICR y dias de mora."""
    ratio_pd = cartera["pd_lifetime_actual"] / cartera["pd_lifetime_origen"]
    cartera["stage"] = 1
    cartera.loc[(ratio_pd > 2) | (cartera["dias_mora"] > 30), "stage"] = 2
    cartera.loc[cartera["dias_mora"] > 90, "stage"] = 3
    return cartera


def ajustar_forward_looking(pd_ttc, escenarios, pesos):
    """Convierte PD through-the-cycle en point-in-time segun escenarios macro."""
    pd_pit = 0.0
    for esc, peso in zip(escenarios, pesos):
        factor = np.exp(esc["coef_pib"] * esc["pib"] +
                        esc["coef_desempleo"] * esc["desempleo"])
        pd_pit += peso * pd_ttc * factor
    return np.clip(pd_pit, 0.0, 1.0)


def calcular_ecl(cartera, tasa_descuento):
    """ECL = suma sobre el horizonte de PD * LGD * EAD, descontada."""
    horizonte = np.where(cartera["stage"] == 1, 12, cartera["meses_remanentes"])
    ecl = np.zeros(len(cartera))
    for t in range(1, int(horizonte.max()) + 1):
        activo = (t <= horizonte)
        fd = 1.0 / ((1.0 + tasa_descuento) ** (t / 12.0))
        ecl += activo * (cartera["pd_pit"] * cartera["lgd"] *
                         cartera["ead"] * fd)
    cartera["ecl"] = ecl
    return cartera
