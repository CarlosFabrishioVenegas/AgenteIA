# Perfil de Datos - IFRS9_Provisiones

## Fuentes
- Core de colocaciones - saldos, mora, garantias, tasa efectiva.
- Historico de recuperaciones - operaciones en default cerradas 2019-2024.
- Proveedor macroeconomico externo - proyecciones de PIB, desempleo y tipo de
  cambio.

## Chequeos
| Chequeo | Resultado | Tasa |
|---|---|---|
| Operaciones sin fecha de originacion | ALERTA | 3.7% |
| Garantia sin valorizacion vigente | ADVERTENCIA | 9.2% |
| EAD negativo | OK | 0% |
| Recuperaciones sin cierre (casos abiertos) | ADVERTENCIA | 22% |
| Consistencia stage vs dias de mora | OK | 0% |

## Observaciones
- El 3.7% sin fecha de originacion impide calcular la PD lifetime de origen;
  esas operaciones se asignan por defecto a Stage 1.
- El 22% de casos de recuperacion siguen abiertos y se excluyen del calculo de
  LGD.
- Las proyecciones macro se reciben trimestralmente del proveedor.
