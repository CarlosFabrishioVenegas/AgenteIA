# Manual metodológico — Modelo VaR de demostración

## 1. Medida de riesgo
El modelo calcula el **Valor en Riesgo (VaR) histórico** de la cartera.

## 2. Nivel de confianza
El VaR se estima a un **nivel de confianza del 99%**. Este parámetro es
regulatorio y no debe alterarse sin aprobación del comité de modelos.

## 3. Ventana de estimación
Se emplea una **ventana móvil de 250 días hábiles** de retornos.

## 4. Método
VaR histórico por percentil empírico: al 99% de confianza se toma el
**percentil 1** de la distribución de retornos de la ventana, expresado como
pérdida positiva.

> Nota de trazabilidad: el código de implementación debe usar exactamente el
> 99% aquí declarado. Cualquier desviación (p. ej. 95%) es un hallazgo de
> coherencia documento↔código y bloquea la aprobación.
