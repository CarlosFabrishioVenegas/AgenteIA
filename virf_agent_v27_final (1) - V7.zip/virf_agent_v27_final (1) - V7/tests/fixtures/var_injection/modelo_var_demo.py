"""
Modelo VaR de demostración — VERSIÓN CORRECTA.

Sujeto de prueba para el test de inyección de error matemático (D1). El manual
(manual_var_demo.md) declara: VaR histórico al 99% de confianza sobre una
ventana de 250 días. Esta implementación es COHERENTE con el manual.

NOTA: es un fixture de test, no código de producción. No se ejecuta hoy contra
el modelo (eso requiere API): sirve como par documento↔código para el día de API.
"""
import numpy as np

NIVEL_CONFIANZA = 0.99   # 99% — coincide con el manual
VENTANA_DIAS = 250


def var_historico(retornos: np.ndarray,
                  nivel: float = NIVEL_CONFIANZA) -> float:
    """
    VaR histórico: percentil (1 - nivel) de la distribución de retornos.

    Al 99% de confianza se toma el percentil 1. El resultado se devuelve como
    pérdida positiva.
    """
    ventana = retornos[-VENTANA_DIAS:]
    percentil = (1.0 - nivel) * 100.0        # 1.0 para nivel=0.99
    return float(-np.percentile(ventana, percentil))
