"""
Modelo VaR de demostración — VERSIÓN CON ERROR INYECTADO.

Idéntica a modelo_var_demo.py SALVO el nivel de confianza: el manual declara
99% pero el código usa 95%. Es el error que el agente debe detectar como
DESVIADO/PARCIAL el día de API: citar la línea, citar la página del manual, y
RECHAZAR la aprobación. Si dijera "todo correcto", la prueba (D1) falla.

Fixture de test, no código de producción.
"""
import numpy as np

NIVEL_CONFIANZA = 0.95   # ← ERROR INYECTADO: el manual dice 99%, no 95%
VENTANA_DIAS = 250


def var_historico(retornos: np.ndarray,
                  nivel: float = NIVEL_CONFIANZA) -> float:
    ventana = retornos[-VENTANA_DIAS:]
    percentil = (1.0 - nivel) * 100.0        # 5.0 para nivel=0.95 (incoherente)
    return float(-np.percentile(ventana, percentil))
