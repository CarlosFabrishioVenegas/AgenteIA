"""
tests/test_beta_calibracion.py — β de abstención calibrado por datos (Día 2).

β se fijó (config.ABSTENCION_BETA) desde la distribución de `cobertura` léxica
sobre las preguntas-oro: respondibles ∈ [0.379, 1.0], evidencia ausente = 0.0.
β = 0.19 cae en el hueco de separación. Sin API (léxico determinista).
"""
import pytest

from config import parametros
from modulos.abstencion import evaluar_abstencion, EVIDENCIA_INSUFICIENTE
from src.rag.buscador_lexico import BuscadorLexico
from scripts.preguntas_oro_rag import PREGUNTAS


BETA = float(parametros.ABSTENCION_BETA)


def _max_cobertura(dominio: str, pregunta: str) -> float:
    res = BuscadorLexico(dominio).buscar(pregunta, top_k=6)
    return max((r["cobertura"] for r in res), default=0.0)


def test_beta_esta_en_el_hueco_de_separacion():
    # β calibrado: por encima de la evidencia nula (0.0) y por debajo del
    # mínimo de las respondibles (0.379). Ni 0.0 (no discrimina) ni tan alto
    # que castigue una respondible real.
    assert 0.0 < BETA < 0.379


def test_una_respondible_no_se_abstiene():
    # Pregunta de oro a su propio dominio: cobertura por encima de β → responde.
    p = PREGUNTAS[0]
    cob = _max_cobertura(p["dominio"], p["pregunta"])
    r = evaluar_abstencion([cob])   # usa β de config
    assert cob >= BETA
    assert r["abstenido"] is False


def test_todas_las_respondibles_superan_beta():
    # Ninguna pregunta de oro respondible debe caer por abstención con el β fijado.
    fallos = []
    for p in PREGUNTAS:
        cob = _max_cobertura(p["dominio"], p["pregunta"])
        if cob < BETA:
            fallos.append((p["id"], round(cob, 3)))
    assert not fallos, f"β={BETA} abstiene respondibles: {fallos}"


def test_evidencia_ausente_se_abstiene():
    # Consulta de vocabulario AJENO al corpus financiero: el corpus no reconoce
    # ningún término informativo → cobertura 0 (< β) → abstención.
    #
    # Nota honesta: una consulta que COMPARTE vocabulario metodológico (p. ej.
    # "estrés climático 2027") puede dar cobertura alta aunque el tema no esté;
    # ese caso lo caza la declaración de alcance del buscador (reconocimiento de
    # la consulta), no β. β discrimina la evidencia nula o marginal.
    cob = _max_cobertura("VaR", "receta de paella valenciana con mariscos y azafrán")
    r = evaluar_abstencion([cob] if cob > 0 else [])
    assert cob < BETA
    assert r["abstenido"] is True
    assert r["etiqueta"] == EVIDENCIA_INSUFICIENTE


def test_beta_es_configurable_por_el_operador():
    # Subir β exige evidencia más fuerte; bajarlo a 0 recupera el modo conservador.
    fuerte = evaluar_abstencion([0.30], umbral=0.5)
    assert fuerte["abstenido"] is True
    laxo = evaluar_abstencion([0.01], umbral=0.0)
    assert laxo["abstenido"] is False
