"""
tests/test_virf_plus.py
═══════════════════════════════════════════════════════════════════════════════
VIRF PLUS (GPT principal + Claude como segunda opinión) — coste cero, con dobles.

Lo que se fija:
  · las dos opiniones se piden con la MISMA tarea y el árbitro recibe ambas;
  · las discrepancias en campos de decisión se detectan y viajan al árbitro;
  · «discrepancia» se ahorra el árbitro cuando ambos coinciden;
  · si un modelo falla NO hay conclusión con un solo evaluador;
  · get_cliente_ia() solo entra en modo doble con el flag explícito, y el
    cambio de modo invalida la caché;
  · cada conciliación queda en la bitácora.
"""

from __future__ import annotations

import json

import pytest

from config import ia
from config.virf_plus import ClienteConsensoIA, comparar_respuestas


class Doble(ia.ClienteIA):
    def __init__(self, nombre, respuesta, falla=False):
        self.modelo = nombre
        self.respuesta = respuesta
        self.falla = falla
        self.llamadas = []

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                        sistema=None, formato_json=False):
        self.llamadas.append({"prompt": prompt, "sistema": sistema or instruccion_sistema,
                              "formato_json": formato_json})
        if self.falla:
            raise RuntimeError("401 clave rechazada")
        return self.respuesta(prompt) if callable(self.respuesta) else self.respuesta

    def validar_conexion(self):
        return not self.falla


def _consenso(tmp_path, a, b, arbitraje="siempre", arbitro="gpt"):
    claude = Doble("claude-x", a)
    gpt = Doble("gpt-x", b)
    cli = ClienteConsensoIA(claude=claude, gpt=gpt, arbitro=arbitro,
                            arbitraje=arbitraje, ruta_log=tmp_path / "log.jsonl")
    return cli, claude, gpt


def test_comparar_detecta_discrepancia_de_puntaje():
    c = comparar_respuestas('{"puntaje": 3, "observacion": "x"}',
                            '```json\n{"puntaje": 2, "observacion": "y"}\n```')
    assert c["json"] and not c["acuerdo"]
    assert c["discrepancias"] == {"puntaje": [3, 2]}


def test_comparar_acuerdo_ignora_redaccion():
    c = comparar_respuestas('{"resultado": "Cumple", "texto": "a"}',
                            '{"resultado": "cumple ", "texto": "b"}')
    assert c["acuerdo"] and c["coinciden"] == ["resultado"]


def test_arbitro_recibe_ambas_opiniones_y_discrepancias(tmp_path):
    def gpt(prompt):
        if "EVALUADOR A" in prompt:            # llamada de arbitraje
            return '{"puntaje": 2, "observacion": "conciliada"}'
        return '{"puntaje": 4, "observacion": "opinión gpt"}'

    cli, c, g = _consenso(tmp_path, '{"puntaje": 2, "observacion": "opinión claude"}', gpt)
    final = cli.generar_mensaje("TAREA con evidencia", sistema="Eres validador",
                                formato_json=True)

    assert json.loads(final)["observacion"] == "conciliada"
    assert len(g.llamadas) == 2 and len(c.llamadas) == 1   # A, B y árbitro (GPT)
    assert g.llamadas[0]["prompt"] == c.llamadas[0]["prompt"] == "TAREA con evidencia"
    arb = g.llamadas[1]
    assert "opinión claude" in arb["prompt"] and "opinión gpt" in arb["prompt"]
    # A es siempre el agente principal (GPT); B, la segunda opinión (Claude).
    assert "EVALUADOR A (GPT" in arb["prompt"] and "EVALUADOR B (Claude" in arb["prompt"]
    assert "puntaje: A=4" in arb["prompt"] and "B=2" in arb["prompt"]
    assert "CONSERVADORA" in arb["sistema"] and arb["formato_json"] is True
    assert cli.ultimo_consenso["discrepancias"] == {"puntaje": [4, 2]}


def test_modo_discrepancia_ahorra_arbitro_y_vale_gpt(tmp_path):
    cli, c, g = _consenso(tmp_path, '{"puntaje": 3, "t": "claude"}',
                          '{"puntaje": 3, "t": "gpt"}', arbitraje="discrepancia")
    assert cli.generar_mensaje("t") == '{"puntaje": 3, "t": "gpt"}'
    assert len(c.llamadas) == 1 and len(g.llamadas) == 1
    assert cli.ultimo_consenso["arbitrado"] is False


def test_arbitro_claude_opcional(tmp_path):
    cli, c, g = _consenso(tmp_path, "texto A", "texto B", arbitro="anthropic")
    cli.generar_mensaje("t")
    assert len(c.llamadas) == 2 and len(g.llamadas) == 1


def test_por_defecto_gpt_es_principal_y_arbitro(tmp_path, monkeypatch):
    import config.virf_plus as vp
    monkeypatch.setattr(vp, "VIRF_PLUS_ARBITRO", "gpt")
    cli = ClienteConsensoIA(claude=Doble("claude-x", "a"), gpt=Doble("gpt-x", "b"),
                            ruta_log=tmp_path / "l.jsonl")
    assert cli.arbitro == "gpt" and cli.descripcion.startswith("GPT gpt-x + Claude")


def test_defaults_de_parametros_ponen_a_gpt_al_frente():
    import inspect
    from config import parametros
    fuente = inspect.getsource(parametros)
    assert 'os.getenv("VIRF_PLUS_ARBITRO", "gpt")' in fuente
    assert 'os.getenv("IA_PROVEEDOR", "azure_openai")' in fuente


def test_sin_conclusion_con_un_solo_evaluador(tmp_path):
    claude = Doble("claude-x", "ok")
    gpt = Doble("gpt-x", "ok", falla=True)
    cli = ClienteConsensoIA(claude=claude, gpt=gpt, ruta_log=tmp_path / "l.jsonl")
    with pytest.raises(RuntimeError, match="GPT: RuntimeError: 401"):
        cli.generar_mensaje("t")
    assert not cli.validar_conexion()
    assert "GPT" in cli.ultimo_error_conexion


def test_bitacora_registra_cada_conciliacion(tmp_path):
    cli, *_ = _consenso(tmp_path, '{"veredicto": "APROBADO"}', '{"veredicto": "NEGADO"}')
    cli.generar_mensaje("t")
    lineas = (tmp_path / "log.jsonl").read_text(encoding="utf-8").splitlines()
    reg = json.loads(lineas[0])
    # [A=GPT, B=Claude]: Claude dijo APROBADO, GPT NEGADO.
    assert reg["discrepancias"] == {"veredicto": ["NEGADO", "APROBADO"]}
    assert reg["modelos"] == {"gpt": "gpt-x", "claude": "claude-x", "arbitro": "gpt"}
    assert cli.resumen()["con_discrepancia"] == 1


def test_get_cliente_ia_solo_con_flag_explicito(monkeypatch):
    construidos = []

    class FalsoConsenso(Doble):
        descripcion = "doble"

        def __init__(self):
            super().__init__("virf_plus", "ok")
            construidos.append(self)

    import config.virf_plus as vp
    monkeypatch.setattr(vp, "ClienteConsensoIA", FalsoConsenso)
    simple = Doble("simple", "ok")
    ia.reset_cliente_ia()
    monkeypatch.setattr(ia, "_CLIENTE_CACHE", simple)

    # Sin flag: la caché de un solo proveedor sigue valiendo.
    assert ia.get_cliente_ia() is simple
    # Con flag: la caché vieja NO vale, se construye el consenso.
    monkeypatch.setenv("VIRF_PLUS", "1")
    assert ia.virf_plus_activo()
    cons = ia.get_cliente_ia()
    assert isinstance(cons, FalsoConsenso) and len(construidos) == 1
    assert ia.get_cliente_ia() is cons            # y se cachea
    assert ia.metadatos_proveedor()["nombre"].startswith("VIRF PLUS")
    ia.reset_cliente_ia()


@pytest.fixture
def sdk_openai_falso(monkeypatch):
    """SDK de OpenAI mínimo: otros tests sustituyen `openai` en sys.modules."""
    import sys
    from types import ModuleType
    mod = ModuleType("openai")
    mod.OpenAI = lambda **kw: None
    monkeypatch.setitem(sys.modules, "openai", mod)
    # Sin transporte HTTP real (otros tests dejan un CA bundle corrupto adrede).
    monkeypatch.setattr(ia, "_cliente_http", lambda: None)
    return mod


def test_openai_exige_api_key(monkeypatch, sdk_openai_falso):
    monkeypatch.setenv("OPENAI_API_KEY", "TU_API_KEY_AQUI")
    with pytest.raises(ValueError, match="OPENAI_API_KEY"):
        ia.ClienteOpenAIIA()


def test_openai_reutiliza_negociacion_de_azure(monkeypatch, sdk_openai_falso):
    from types import SimpleNamespace
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-" + "x" * 30)
    cli = ia.ClienteOpenAIIA()
    vistos = []

    def crear(**kw):
        vistos.append(kw)
        if "max_tokens" in kw:
            raise RuntimeError("Unsupported parameter: 'max_tokens'; use 'max_completion_tokens'")
        return SimpleNamespace(model="gpt-x-2026", choices=[SimpleNamespace(
            message=SimpleNamespace(content='{"ok": true}'), finish_reason="stop")])

    cli.cliente = SimpleNamespace(chat=SimpleNamespace(
        completions=SimpleNamespace(create=crear)), _client=None)
    cli._admite_temperature = False
    assert cli.generar_mensaje("JSON por favor", formato_json=True) == '{"ok": true}'
    assert cli._param_tokens == "max_completion_tokens"
    assert vistos[-1]["model"] == cli.deployment
