"""
Prueba unitaria de la Skill 2 (Calidad de Datos) — guía §4.B.

Fixture sintético con EXACTAMENTE 10 outliers obvios + 5 duplicados exactos.
El JSON retornado debe registrar exactamente esos números. Además se comprueba
que la vía por SANDBOX (subprocess) devuelve el mismo resultado que la función
pura, y que el chequeo de data leakage cuenta el solapamiento train/test.
"""

from __future__ import annotations

import csv
from pathlib import Path

import pytest

from skills.calidad_datos import (
    DataQualityResult,
    SkillCalidadDatos,
    run_data_quality_check,
)


def _escribir_csv(ruta: Path, filas, cabecera) -> None:
    with ruta.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(cabecera)
        w.writerows(filas)


@pytest.fixture()
def csv_10_outliers_5_duplicados(tmp_path) -> Path:
    """
    100 filas normales (numéricas agrupadas, sin outliers ni duplicados) +
    10 filas con `valor` extremo (outliers) + 5 copias exactas de filas normales.
    """
    cabecera = ["id", "valor", "monto"]
    filas = []
    # 100 normales: id único → sin duplicados; valor 50..59, monto 1000..1040 → sin outliers
    for i in range(100):
        filas.append([f"r{i}", 50 + (i % 10), 1000 + (i % 5) * 10])
    # 10 outliers obvios en 'valor'
    for j in range(10):
        filas.append([f"o{j}", 100000 + j, 1005])
    # 5 duplicados EXACTOS de las primeras 5 filas normales
    for i in range(5):
        filas.append([f"r{i}", 50 + (i % 10), 1000 + (i % 5) * 10])

    ruta = tmp_path / "dataset_qc.csv"
    _escribir_csv(ruta, filas, cabecera)
    return ruta


def test_reporta_exactamente_10_outliers_y_5_duplicados(csv_10_outliers_5_duplicados):
    res = run_data_quality_check(str(csv_10_outliers_5_duplicados))
    assert isinstance(res, DataQualityResult)
    assert res.duplicates == 5, f"esperaba 5 duplicados, obtuvo {res.duplicates}"
    assert res.outliers_total == 10, f"esperaba 10 outliers, obtuvo {res.outliers_total}"
    assert res.outliers_count.get("valor") == 10
    # 'monto' no debe registrar outliers
    assert res.outliers_count.get("monto", 0) == 0


def test_nulos_en_variables_clave(tmp_path):
    ruta = tmp_path / "con_nulos.csv"
    _escribir_csv(ruta,
                  [["a", 1, 10], ["b", "", 20], ["c", 3, ""]],
                  ["id", "tasa", "colateral"])
    res = run_data_quality_check(str(ruta), key_columns=["tasa"])
    assert res.missing_en_variables_clave["tasa"] == 1


def test_data_leakage_cuenta_solapamiento_train_test(tmp_path):
    ruta = tmp_path / "leak.csv"
    # dos filas de features idénticas, una en train y otra en test → 1 solapamiento
    _escribir_csv(
        ruta,
        [["train", 1.0, 5.0], ["train", 2.0, 6.0], ["test", 1.0, 5.0], ["test", 9.0, 9.0]],
        ["split", "x1", "x2"])
    res = run_data_quality_check(str(ruta), split_column="split")
    assert res.data_leakage.evaluado is True
    assert res.data_leakage.filas_solapadas == 1


def test_sandbox_subprocess_devuelve_igual_que_funcion_pura(csv_10_outliers_5_duplicados):
    """El agente invoca la skill por SANDBOX; el resultado debe coincidir."""
    directo = run_data_quality_check(str(csv_10_outliers_5_duplicados))
    por_sandbox = SkillCalidadDatos().ejecutar(str(csv_10_outliers_5_duplicados))
    assert por_sandbox.duplicates == directo.duplicates == 5
    assert por_sandbox.outliers_total == directo.outliers_total == 10
    assert por_sandbox.model_dump() == directo.model_dump()
