"""
Arnés por skill — fundación tipada (SK-00 / SK-01).

Verifica lo que se puede probar SIN API:
  · las 6 skills exponen una declaración de herramienta VÁLIDA (function calling),
  · cada una resuelve su rubro DESDE la config versionada (no texto hardcodeado),
  · una consulta fuera de alcance dispara abstención o derivación,
  · solo Calidad de Datos está marcada como operativa (1/6).

Patrón para las siguientes skills (follow-on): añade un módulo
`tests/skills/test_<skill>.py` que instancie la skill y ejerza su `ejecutar()`
determinista contra un fixture con el resultado esperado exacto.
"""

from __future__ import annotations

import pytest

from skills import SKILLS_TIPADAS, declaraciones_herramientas
from skills.base_tipada import DeclaracionHerramienta, SkillTipada


def test_hay_exactamente_seis_skills_declaradas():
    assert len(SKILLS_TIPADAS) == 6
    nombres = set(SKILLS_TIPADAS)
    assert nombres == {
        "analyze_document_versioning", "run_data_quality_check",
        "retrieve_methodology_evidence", "check_compliance_government",
        "verify_code_implementation", "ingest_operational_channels",
    }


@pytest.mark.parametrize("clase", list(SKILLS_TIPADAS.values()), ids=lambda c: c.nombre)
def test_cada_skill_expone_declaracion_de_herramienta_valida(clase):
    decl = clase().declaracion_herramienta()
    assert isinstance(decl, DeclaracionHerramienta)
    assert decl.name == clase.nombre
    assert decl.parameters["type"] == "object"
    assert isinstance(decl.parameters["properties"], dict)
    # revalida el schema por el contrato Pydantic (extra=forbid + validador).
    DeclaracionHerramienta.model_validate(decl.model_dump())


def test_declaraciones_para_tools_es_serializable_json():
    decls = declaraciones_herramientas()
    assert len(decls) == 6
    import json
    json.loads(json.dumps(decls))  # debe ser JSON puro para pasar a tools=


@pytest.mark.parametrize("clase", list(SKILLS_TIPADAS.values()), ids=lambda c: c.nombre)
def test_rubro_se_resuelve_desde_config_no_hardcode(clase):
    skill = clase()
    alcance = skill.resolver_rubro()
    # Puntero declarado: o bien tiene ámbito del estándar, o IDs de cuestionamiento.
    assert alcance.ambito_estandar or alcance.cuestionamiento_ids
    # Los IDs declarados que estén activos deben resolverse DESDE el catálogo.
    from modulos.cuestionamientos_ext import catalogo_activo
    catalogo, _ = catalogo_activo()
    for cid in alcance.cuestionamiento_ids:
        if cid in catalogo:
            assert cid in alcance.cuestionamientos_resueltos
            # el criterio proviene del catálogo, no de un literal en la skill
            assert alcance.cuestionamientos_resueltos[cid] == catalogo[cid]
    # ninguna definición de criterio está hardcodeada como atributo de la clase
    assert not hasattr(clase, "criterios_texto")


@pytest.mark.parametrize("clase", list(SKILLS_TIPADAS.values()), ids=lambda c: c.nombre)
def test_consulta_fuera_de_alcance_dispara_abstencion_o_derivacion(clase):
    skill = clase()
    if not skill.fronteras_fuera_alcance:
        pytest.skip("skill sin fronteras declaradas")
    consulta = f"por favor revisa el tema de {skill.fronteras_fuera_alcance[0]}"
    res = skill.evaluar_alcance(consulta)
    assert res.en_alcance is False
    assert res.accion in ("ABSTENERSE", "DERIVAR")


@pytest.mark.parametrize("clase", list(SKILLS_TIPADAS.values()), ids=lambda c: c.nombre)
def test_una_skill_nunca_opina_del_dominio_de_otra(clase):
    """Una consulta claramente de OTRO dominio no debe caer 'en alcance'."""
    skill = clase()
    otras = [c for n, c in SKILLS_TIPADAS.items() if n != skill.nombre]
    for otra in otras:
        for termino in otra.terminos_alcance[:2]:
            if termino in skill.fronteras_fuera_alcance:
                res = skill.evaluar_alcance(f"analiza {termino}")
                assert res.en_alcance is False


def test_solo_calidad_de_datos_es_operativa():
    operativas = [n for n, c in SKILLS_TIPADAS.items() if c.operativa]
    assert operativas == ["run_data_quality_check"]


@pytest.mark.parametrize(
    "clase", [c for c in SKILLS_TIPADAS.values() if not c.operativa],
    ids=lambda c: c.nombre)
def test_skills_no_operativas_declaran_pendiente_api(clase):
    """Los stubs exponen contrato pero no ejecutan sin coordinador (día de API)."""
    with pytest.raises(NotImplementedError) as exc:
        SkillTipada.ejecutar(clase())
    assert "coordinador" in str(exc.value).lower()
