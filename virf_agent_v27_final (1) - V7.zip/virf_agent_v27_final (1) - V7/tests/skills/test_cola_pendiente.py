"""
Prueba de la cola PENDIENTE (HITL) — antipatrón exceso de agencia (guía §5.1).

Una acción de impacto externo debe QUEDAR ENCOLADA en estado PENDIENTE, nunca
ejecutarse directamente.
"""

from __future__ import annotations

from skills.cola_pendiente import (
    ACCIONES_DE_IMPACTO,
    encolar_accion,
    listar_pendientes,
)


def test_accion_de_impacto_queda_encolada_no_ejecutada(tmp_path):
    ruta = tmp_path / "pendientes.json"
    accion = encolar_accion(
        tipo="aprobar_produccion",
        descripcion="Aprobar el modelo VAR_BCP_2027 para producción",
        payload={"model_id": "VAR_BCP_2027"},
        model_id="VAR_BCP_2027",
        ruta=ruta,
    )
    # queda en estado PENDIENTE, esperando confirmación humana
    assert accion.estado == "PENDIENTE"
    assert accion.tipo in ACCIONES_DE_IMPACTO

    pendientes = listar_pendientes(ruta=ruta)
    assert len(pendientes) == 1
    assert pendientes[0].id == accion.id
    assert pendientes[0].estado == "PENDIENTE"


def test_el_modulo_no_expone_ninguna_via_de_ejecucion_directa():
    """No debe existir función que EJECUTE la acción: la decisión es humana."""
    import skills.cola_pendiente as cp
    prohibidos = [n for n in dir(cp)
                  if n.startswith(("ejecutar", "enviar_real", "aprobar_real", "run_"))]
    assert prohibidos == []


def test_varias_acciones_se_acumulan(tmp_path):
    ruta = tmp_path / "pendientes.json"
    encolar_accion("enviar_correo", "Comunicar resultados al comité", ruta=ruta)
    encolar_accion("notificar_comite", "Notificar hallazgo crítico", ruta=ruta)
    assert len(listar_pendientes(ruta=ruta)) == 2
