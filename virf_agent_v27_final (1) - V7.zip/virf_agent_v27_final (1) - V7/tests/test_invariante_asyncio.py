# -*- coding: utf-8 -*-
"""
Invariante: ninguna `asyncio.create_task(...)` puede quedar como sentencia suelta.

El event loop solo guarda referencias DÉBILES a las tareas; una tarea que nadie
referencia puede ser recolectada por el GC a mitad de ejecución. En
`web/services/pipeline_runner.py` eso mataba al supervisor de la corrida y la
web mostraba la validación colgada para siempre (intermitente). Se verifica con
AST —no por texto— para no confundirse con comentarios que mencionan el patrón.
"""
import ast
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
CARPETAS = ("web", "modulos", "motor", "src", "config", "skills")


def _es_create_task(nodo: ast.AST) -> bool:
    if not isinstance(nodo, ast.Call):
        return False
    f = nodo.func
    nombre = f.attr if isinstance(f, ast.Attribute) else getattr(f, "id", "")
    return nombre in ("create_task", "ensure_future")


def test_ninguna_create_task_queda_sin_referencia():
    sueltas = []
    for carpeta in CARPETAS:
        for py in (RAIZ / carpeta).rglob("*.py"):
            if "__pycache__" in py.parts:
                continue
            arbol = ast.parse(py.read_text(encoding="utf-8"), filename=str(py))
            for nodo in ast.walk(arbol):
                if isinstance(nodo, ast.Expr) and _es_create_task(nodo.value):
                    sueltas.append(f"{py.relative_to(RAIZ)}:{nodo.lineno}")
    assert not sueltas, (
        "create_task/ensure_future sin guardar la tarea (el GC puede matarla): "
        + ", ".join(sueltas))


def test_pipeline_runner_retiene_sus_tareas():
    from web.services import pipeline_runner
    assert isinstance(pipeline_runner._tareas, set)
