"""
tests/test_presentacion_guia.py — La presentación «Guía de la herramienta» se genera desde el
repositorio y no se queda atrás cuando cambia el código.

Sin IA, sin coste: construye el .pptx en tmp_path y lo inspecciona con python-pptx.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from pptx import Presentation
from pptx.util import Emu

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "scripts"))

import generar_presentacion_guia as G  # noqa: E402
from modulos import reglas_informe as R  # noqa: E402

CONOCIMIENTO = (G.DIR_GUIA / "CONOCIMIENTO_VIRF.md").read_text(encoding="utf-8")


@pytest.fixture(scope="module")
def mazo(tmp_path_factory):
    ruta = G.construir(tmp_path_factory.mktemp("pptx") / "guia.pptx")
    return Presentation(str(ruta))


def _textos(slide) -> str:
    partes = []
    for sh in slide.shapes:
        if sh.has_text_frame:
            partes.append(sh.text_frame.text)
        if sh.has_table:
            partes += [c.text for fila in sh.table.rows for c in fila.cells]
    return "\n".join(partes)


def test_tamano_y_numero_de_diapositivas(mazo):
    assert (mazo.slide_width, mazo.slide_height) == (G.ANCHO, G.ALTO)
    assert len(mazo.slides) >= 45


def test_cada_diapositiva_tiene_notas_del_orador(mazo):
    for i, s in enumerate(mazo.slides, 1):
        assert s.has_notes_slide and s.notes_slide.notes_text_frame.text.strip(), f"diapositiva {i}"


def test_secciones_cubren_todas_las_diapositivas(mazo):
    p14 = "{http://schemas.microsoft.com/office/powerpoint/2010/main}"
    secciones = mazo.part._element.findall(f".//{p14}section")
    nombres = [s.get("name") for s in secciones]
    assert nombres[0] == "Introducción" and nombres[-1] == "Cierre"
    ids = [int(x.get("id")) for s in secciones for x in s.iter(f"{p14}sldId")]
    assert sorted(ids) == sorted(s.slide_id for s in mazo.slides)


def test_ninguna_forma_se_sale_de_la_diapositiva(mazo):
    tolerancia = Emu(20000)
    for i, s in enumerate(mazo.slides, 1):
        for sh in s.shapes:
            assert sh.left >= 0 and sh.top >= 0, f"diapositiva {i}: {sh.name}"
            assert sh.left + sh.width <= mazo.slide_width + tolerancia, f"diapositiva {i}: {sh.name}"
            assert sh.top + sh.height <= mazo.slide_height + tolerancia, f"diapositiva {i}: {sh.name}"


def test_todas_las_capturas_de_la_interfaz_aparecen(mazo):
    usadas = set(G.USO) | {"20_movil_mis_modelos", "21_movil_solo_informe", "22_movil_dashboard"}
    assert {p[0] for p in G.PANTALLAS} == usadas
    for clave in usadas:
        assert G.captura(clave).is_file(), clave
    imagenes = sum(1 for s in mazo.slides for sh in s.shapes if sh.shape_type == 13)
    assert imagenes >= len(usadas)


def test_cada_pantalla_explicada_tiene_pasos(mazo):
    for clave, (pasos, ojo) in G.USO.items():
        assert pasos and ojo, clave


def test_ejemplos_de_calificacion_salen_de_la_regla_real(mazo):
    texto = "\n".join(_textos(s) for s in mazo.slides)
    for _, obs, res in G.ejemplos_calificacion():
        assert res == R.concluir(obs)
        assert res["motivo"] in texto
    niveles = {res["nivel"] for *_, res in G.ejemplos_calificacion()}
    assert niveles == set(R.NIVELES)


def test_escala_de_puntaje_coincide_con_la_regla():
    assert G._escala_puntaje() == [(str(p), R.riesgo_desde_puntaje(p)) for p in range(6)]


def test_reglas_de_oro_y_skills_se_leen_del_conocimiento(mazo):
    reglas = G.reglas_de_oro(CONOCIMIENTO)
    assert len(reglas) == 10
    assert all("`" not in r for r in reglas)
    assert "config/ia.py" in reglas[3]  # la continuación de línea no se pierde
    filas = G.sintoma_skill(CONOCIMIENTO)
    assert [f[1][:3] for f in filas] == [f"S{n:02d}" for n in range(1, 13)]
    texto = "\n".join(_textos(s) for s in mazo.slides)
    for _, skill in filas:
        assert skill in texto


def test_rutas_citadas_existen(mazo):
    rutas = ["modulos/plantilla_bcp.py", "modulos/reglas_informe.py", "modulos/capturas.py",
             "modulos/pii.py", "modulos/inyeccion.py", "modulos/prevuelo.py", "config/ia.py",
             "web/services/solo_informe_word.py", "web/services/informe_web.py",
             "modulos/generador_word.py", "web/routers/dominio_prevuelo.py", "web/routers/upload.py"]
    texto = "\n".join(_textos(s) for s in mazo.slides)
    for r in rutas:
        assert (RAIZ / r).is_file(), r
        assert Path(r).name in texto, r
