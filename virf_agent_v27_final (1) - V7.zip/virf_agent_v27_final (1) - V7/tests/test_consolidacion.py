"""
tests/test_consolidacion.py
═══════════════════════════════════════════════════════════════════════════════
Cierre HITL: el chat produce el puntaje EXACTO final (WP-A).

Coste 0: no llama al modelo. Verifica el mapeo veredicto→estado y el recomputo
del score sin tocar el score inicial del agente.
"""
import pytest


def _fn():
    from modulos.consolidacion import consolidar_decisiones
    return consolidar_decisiones


def _datos():
    # Dos actividades No cumple (puntaje 2) en Metodología.
    return {
        "resultados_por_ambito": {
            "Metodología": [
                {"actividad": "A1 backtesting", "puntaje": 2, "evaluacion_valida": True},
                {"actividad": "A2 estrés",      "puntaje": 2, "evaluacion_valida": True},
            ],
        },
    }


class TestConsolidar:
    def test_aprobado_sube_a_cumple_5(self):
        datos = _datos()
        obs = [{"ambito": "Metodología", "actividad": "A1 backtesting",
                "veredicto": "APROBADO", "hallazgo_final": "subsanado"}]
        r = _fn()(datos, obs)
        # A1 pasa a 5, A2 sigue en 2 → promedio 3.5
        assert r["scores_final_por_ambito"]["Metodología"] == pytest.approx(3.5)
        assert r["resumen_final"]["cumple_subsanado"] == 1

    def test_negado_mantiene_puntaje(self):
        datos = _datos()
        obs = [{"ambito": "Metodología", "actividad": "A1 backtesting",
                "veredicto": "NEGADO", "hallazgo_final": "confirmado"}]
        r = _fn()(datos, obs)
        # Nada sube: sigue 2.0
        assert r["scores_final_por_ambito"]["Metodología"] == pytest.approx(2.0)
        assert r["resumen_final"]["no_cumple_confirmado"] == 1

    def test_no_muta_el_eval_original(self):
        # El score inicial del agente NO se toca.
        datos = _datos()
        obs = [{"ambito": "Metodología", "actividad": "A1 backtesting",
                "veredicto": "APROBADO"}]
        _fn()(datos, obs)
        assert datos["resultados_por_ambito"]["Metodología"][0]["puntaje"] == 2

    def test_valor_cumple_configurable(self, monkeypatch):
        monkeypatch.setenv("VIRF_PUNTAJE_CUMPLE", "4")
        datos = _datos()
        obs = [{"ambito": "Metodología", "actividad": "A1 backtesting", "veredicto": "APROBADO"}]
        r = _fn()(datos, obs)
        # A1=4, A2=2 → 3.0
        assert r["scores_final_por_ambito"]["Metodología"] == pytest.approx(3.0)

    def test_sin_decisiones_score_final_igual_al_inicial(self):
        datos = _datos()
        r = _fn()(datos, [])
        assert r["scores_final_por_ambito"]["Metodología"] == pytest.approx(2.0)
        assert r["resumen_final"]["decisiones"] == 0


class TestTablaFinal:
    def _fn(self):
        from modulos.consolidacion import tabla_final
        return tabla_final

    def _datos(self):
        return {"tabla_validacion": [
            {"ambito": "Metodología", "control": "C", "actividad": "A1",
             "resultado": "No cumple", "evaluacion_sustentada": "obs",
             "fuente_revisada": "ev", "accion_requerida": "fix", "tier": "I"},
            {"ambito": "Metodología", "control": "C", "actividad": "A2",
             "resultado": "No cumple", "evaluacion_sustentada": "", "tier": "I"},
        ]}

    def test_aprobado_marca_cumple_en_la_fila_final(self):
        datos = self._datos()
        obs = [{"ambito": "Metodología", "actividad": "A1", "veredicto": "APROBADO",
                "hallazgo_final": "aportó el manual v4.3"}]
        filas = self._fn()(datos, obs)
        a1 = next(f for f in filas if f["actividad"] == "A1")
        a2 = next(f for f in filas if f["actividad"] == "A2")
        assert a1["resultado"] == "Cumple"
        assert a1["decidido_en_chat"] is True
        assert "Decisión validador — APROBADO" in a1["evaluacion_sustentada"]
        assert a2["resultado"] == "No cumple"       # sin decisión, intacta
        assert a2["decidido_en_chat"] is False


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
