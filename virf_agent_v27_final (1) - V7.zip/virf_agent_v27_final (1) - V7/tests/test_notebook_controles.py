# -*- coding: utf-8 -*-
"""
Pruebas API-free del generador de notebook de controles de datos (8 columnas).

Construye el .ipynb desde una lista sintética de controles, EJECUTA sus celdas de
código contra datasets de prueba (en tmp_path) y verifica que el entregable es la
tabla de 8 columnas con los cómputos correctos. Coste 0: no llama al LLM (solo se
prueba el constructor y la ejecución de motores pandas).
"""
import io
from pathlib import Path

import pandas as pd
import pytest

import nbformat as nbf
from modulos.notebook_controles import (
    construir_notebook_8cols, a_ipynb_bytes,
    _normalizar_controles, DIMENSION_POR_MOTOR, DECISION_POR_ESTADO,
)

RAIZ = Path(__file__).resolve().parents[1]

COLUMNAS = [
    "Control", "Dimensión", "Control Esperado",
    "% De cumplimiento del data set", "Diagnóstico", "Decisión",
    "Control o Evidencia requerida", "Referencia en el entregable",
]


@pytest.fixture()
def datasets_dir(tmp_path):
    d = tmp_path / "datasets"
    d.mkdir()
    pd.DataFrame({
        "Cuenta": [f"C{i:04d}" for i in range(10)],
        "Cliente": [f"CL{i:03d}" for i in range(10)],
        "Tasa": [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.5],  # 1.5 fuera de rango
    }).to_csv(d / "data_subset.csv", index=False)
    # maestro sin CL009 -> integridad referencial detecta 1 huérfano
    pd.DataFrame({"Cliente": [f"CL{i:03d}" for i in range(9)]}).to_csv(
        d / "maestro_clientes.csv", index=False)
    return d


CONTROLES = [
    {"descripcion": "Cuenta única.", "tipo_motor": "unicidad", "dataset": "data_subset",
     "group_cols": "Cuenta", "campo_objetivo": "Cuenta", "umbral": 0.0,
     "nota": "Log de dedup.", "cita_documento": "S.3.1"},
    {"descripcion": "Tasa entre 0 y 1.", "tipo_motor": "rango", "dataset": "data_subset",
     "campo_objetivo": "Tasa", "min": 0.0, "max": 1.0, "umbral": 0.0, "cita_documento": "S.4"},
    {"descripcion": "Cliente en maestro.", "tipo_motor": "integridad_referencial",
     "dataset": "data_subset", "campo_objetivo": "Cliente",
     "dataset_ref": "maestro_clientes", "campo_ref": "Cliente", "umbral": 0.0},
    {"descripcion": "Rango sin parámetros.", "tipo_motor": "rango",
     "dataset": "data_subset", "campo_objetivo": "Tasa", "umbral": 0.0},  # -> No evaluable
    {"descripcion": "Política aprobada.", "tipo_motor": "narrativo", "nota": "Adjuntar."},
]


def _ejecutar_notebook(nb):
    """Ejecuta las celdas de código en un namespace compartido (simula el kernel)."""
    ns = {"__name__": "__nb_test__"}
    for cell in nb["cells"]:
        if cell["cell_type"] != "code":
            continue
        src = cell["source"].replace("display(", "print(")
        exec(compile(src, "<celda>", "exec"), ns)
    return ns


def _meta(datasets_dir, tmp_path):
    return {"proyecto_dir": str(RAIZ), "datasets_dir": str(datasets_dir),
            "salida_dir": str(tmp_path / "salida"), "fuente": "prueba"}


# ── Constructor ──────────────────────────────────────────────────────────────

def test_normaliza_renumera_y_mapea_dimension():
    norm = _normalizar_controles(CONTROLES)
    assert [c["id_sugerido"] for c in norm] == ["C01", "C02", "C03", "C04", "C05"]
    assert norm[0]["_dimension"] == "Unicidad"
    assert norm[2]["_dimension"] == "Consistencia"
    assert norm[4]["_dimension"] == "Documental"


def test_umbral_se_formatea_segun_semantica_del_motor():
    # umbral >= 1 => conteo absoluto de hallazgos (no porcentaje)
    n = _normalizar_controles([
        {"descripcion": "A", "tipo_motor": "unicidad", "umbral": 1.0},
        {"descripcion": "B", "tipo_motor": "missing", "umbral": 0.01},
        {"descripcion": "C", "tipo_motor": "rango", "umbral": 0.0},
        {"descripcion": "D", "tipo_motor": "duplicados", "umbral": 3},
    ])
    assert "tolera ≤ 1 hallazgo)" in n[0]["_control_esperado"]
    assert "100.00%" not in n[0]["_control_esperado"]
    assert "tolerancia ≤ 1.00%" in n[1]["_control_esperado"]
    assert "tolera" not in n[2]["_control_esperado"] and "%" not in n[2]["_control_esperado"]
    assert "tolera ≤ 3 hallazgos)" in n[3]["_control_esperado"]


def test_todos_los_motores_tienen_dimension_y_decision():
    from modulos.motores_datos import REGISTRO_MOTORES
    for nombre in REGISTRO_MOTORES:
        assert nombre in DIMENSION_POR_MOTOR, f"falta dimensión para {nombre}"
    for estado in ("OK", "ADVERTENCIA", "ALERTA", "ERROR", "REVISION_MANUAL", "N/A"):
        assert estado in DECISION_POR_ESTADO


def test_rutas_van_al_inicio_y_es_ipynb_valido(datasets_dir, tmp_path):
    nb = construir_notebook_8cols(CONTROLES, _meta(datasets_dir, tmp_path))
    codigo = [c["source"] for c in nb["cells"] if c["cell_type"] == "code"]
    # la primera celda de código define las RUTAS
    assert "DATASETS_DIR" in codigo[0] and "PROYECTO" in codigo[0]
    assert "META_CONTROLES" in "\n".join(codigo)
    # se relee como ipynb válido
    nb2 = nbf.reads(a_ipynb_bytes(nb).decode("utf-8"), as_version=4)
    assert nb2["metadata"]["n_controles"] == 5


# ── Ejecución end-to-end ─────────────────────────────────────────────────────

def test_ejecuta_y_entrega_tabla_8_columnas(datasets_dir, tmp_path):
    nb = construir_notebook_8cols(CONTROLES, _meta(datasets_dir, tmp_path))
    ns = _ejecutar_notebook(nb)
    tabla = ns["tabla_control"]
    assert list(tabla.columns) == COLUMNAS
    assert len(tabla) == 5
    assert list(tabla["Control"]) == ["C01", "C02", "C03", "C04", "C05"]


def test_decisiones_y_porcentajes_correctos(datasets_dir, tmp_path):
    nb = construir_notebook_8cols(CONTROLES, _meta(datasets_dir, tmp_path))
    tabla = _ejecutar_notebook(nb)["tabla_control"].set_index("Control")
    dec = tabla["Decisión"].to_dict()
    pct = tabla["% De cumplimiento del data set"].to_dict()

    assert dec["C01"] == "Cumple"                       # unicidad ok
    assert pct["C01"] == 100.0
    assert dec["C02"] in ("Observado", "No cumple")     # 1/10 fuera de rango
    assert pct["C02"] == 90.0
    assert dec["C03"] in ("Observado", "No cumple")     # 1 huérfano
    assert dec["C04"] == "No evaluable"                 # rango sin min/max
    assert pd.isna(pct["C04"])                          # % en blanco, no 100
    assert dec["C05"] == "Revisión manual"              # narrativo
    assert pd.isna(pct["C05"])


def test_csv_persistido(datasets_dir, tmp_path):
    nb = construir_notebook_8cols(CONTROLES, _meta(datasets_dir, tmp_path))
    _ejecutar_notebook(nb)
    csv = tmp_path / "salida" / "tabla_control_datos.csv"
    assert csv.exists()
    leido = pd.read_csv(csv)
    assert list(leido.columns) == COLUMNAS


# ── Orquestador (coste 0: se intercepta el LLM) ──────────────────────────────

class _ClienteFake:
    """Cliente IA de mentira: devuelve un JSON de controles fijo."""
    def __init__(self, json_txt):
        self._json = json_txt

    def generar_mensaje(self, prompt, max_tokens=0, **kw):
        return self._json


_JSON_CTRLS = (
    '{"resumen_documento": "dos controles",'
    ' "controles": [{"descripcion": "Cuenta única", "tipo_motor": "unicidad",'
    ' "dataset": "data_subset", "group_cols": "Cuenta", "campo_objetivo": "Cuenta"},'
    ' {"descripcion": "Política aprobada", "tipo_motor": "narrativo"}]}'
)


def test_orquestador_modo_documento(monkeypatch, datasets_dir, tmp_path):
    import modulos.notebook_controles as N
    doc = tmp_path / "controles.txt"
    doc.write_text("controles de prueba", encoding="utf-8")
    monkeypatch.setattr(N, "leer_documento", lambda p: "controles de prueba")
    monkeypatch.setattr(N, "extraer_controles_del_documento",
                        lambda texto, **kw: {"resumen_documento": "x",
                                             "controles": [{"descripcion": "Cuenta única",
                                                            "tipo_motor": "unicidad",
                                                            "group_cols": "Cuenta",
                                                            "campo_objetivo": "Cuenta"}]})
    ipynb, info = N.generar_ipynb_controles(doc, None, _meta(datasets_dir, tmp_path))
    assert info["n_controles"] == 1
    assert "documento subido" in info["fuente"]
    assert b"tabla_control" in ipynb


def test_orquestador_modo_entendimiento(monkeypatch, datasets_dir, tmp_path):
    import config
    monkeypatch.setattr(config, "get_cliente_ia", lambda: _ClienteFake(_JSON_CTRLS))
    import modulos.notebook_controles as N
    ipynb, info = N.generar_ipynb_controles(None, "Modelo LaR con dataset data_subset",
                                            _meta(datasets_dir, tmp_path))
    assert info["n_controles"] == 2
    assert "propuesto por el agente" in info["fuente"]


def test_orquestador_sin_controles_inserta_plantilla(monkeypatch, datasets_dir, tmp_path):
    import modulos.notebook_controles as N
    monkeypatch.setattr(N, "generar_controles_desde_entendimiento",
                        lambda ent, **kw: {"_error": "sin API", "controles": []})
    ipynb, info = N.generar_ipynb_controles(None, "algo", _meta(datasets_dir, tmp_path))
    # notebook sigue siendo válido y ejecutable, con 1 control-plantilla
    nb = nbf.reads(ipynb.decode("utf-8"), as_version=4)
    ns = _ejecutar_notebook(nb)
    assert list(ns["tabla_control"].columns) == COLUMNAS
    assert len(ns["tabla_control"]) == 1
