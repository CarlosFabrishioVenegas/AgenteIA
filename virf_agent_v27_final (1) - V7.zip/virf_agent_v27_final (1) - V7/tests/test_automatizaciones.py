"""
tests/test_automatizaciones.py
═══════════════════════════════════════════════════════════════════════════════
Cuadro de observaciones desde los Excels 00–03 de automatización. Coste cero.

Fija las reglas de negocio de cada columna:
  · Riesgo sale de 03_Impactos cuando la observación se vincula a una fila; si
    no, es «estimado» y lo dice;
  · Responsable/Fecha según origen (modelamiento vs seguimiento) y plazo por
    riesgo;
  · Ámbito siempre dentro del catálogo; Implementación delante a igual riesgo;
  · las citas de evidencia se contrastan con las hojas realmente leídas.
"""

from __future__ import annotations

import json
from datetime import date

import pytest
from openpyxl import Workbook, load_workbook

from modulos import automatizaciones as A


def _libro(ruta, hojas):
    wb = Workbook()
    wb.remove(wb.active)
    for titulo, filas in hojas.items():
        ws = wb.create_sheet(titulo)
        for f in filas:
            ws.append(f)
    wb.save(ruta)


@pytest.fixture
def carpeta(tmp_path):
    d = tmp_path / "automatizaciones"
    d.mkdir()
    _libro(d / "00_Diagnostico.xlsx", {"Poblacion": [
        ["Diagnóstico de cartera"], [],
        ["Control", "Valor", "Resultado"],
        ["Conteo clientes", 15230, "OK"],
        ["Clientes duplicados", 12, "No cumple"]]})
    _libro(d / "01_ControlDatos.xlsx", {"Calidad": [
        ["Variable", "Prueba", "% incumplimiento", "Estado"],
        ["ingreso", "missing", 0.12, "ALERTA"],
        ["edad", "rango", 0.0, "OK"]]})
    _libro(d / "02_Modelamiento.xlsx", {"Backtesting": [
        ["Indicador", "Valor", "Umbral", "Cumple"],
        ["KS", 0.21, 0.30, "No"],
        ["Gini", 0.45, 0.40, "Sí"]]})
    _libro(d / "03_Impactos.xlsx", {"Impacto": [
        ["Concepto", "Impacto %", "Nivel"],
        ["Provisión adicional", 0.08, "Moderado"],
        ["Capital", 0.15, "Alto"]]})
    (d / "~$02_Modelamiento.xlsx").write_bytes(b"temporal de Excel")
    return d


class IAFalsa:
    def __init__(self, respuesta):
        self.respuesta = respuesta
        self.prompt = None
        self.sistema = None

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                        sistema=None, formato_json=False):
        self.prompt, self.sistema = prompt, instruccion_sistema
        return self.respuesta


def test_localiza_por_prefijo_e_ignora_temporales(carpeta):
    enc = A.localizar_excels(carpeta)
    assert sorted(enc) == ["00", "01", "02", "03"]
    assert not any(p.name.startswith("~$") for p in enc.values())


def test_lectura_detecta_encabezado_y_no_conformes(carpeta):
    lib = A.leer_libro(carpeta / "00_Diagnostico.xlsx", "00")
    h = lib.hojas[0]
    assert h.fila_encabezado == 3 and h.columna_estado == "Resultado"
    assert [r["_fila"] for r in h.hallazgos] == [5]
    # «No» cuenta como fallo solo en columnas booleanas (Cumple).
    h2 = A.leer_libro(carpeta / "02_Modelamiento.xlsx", "02").hojas[0]
    assert [r["Indicador"] for r in h2.hallazgos] == ["KS"]


def test_impactos_prefiere_nivel_cualitativo(carpeta):
    t = A.tabla_impactos(A.leer_libro(carpeta / "03_Impactos.xlsx", "03"))
    assert t["Impacto!2"]["nivel"] == "Moderado"
    assert t["Impacto!3"]["nivel"] == "Crítico"           # «Alto» → Crítico


@pytest.mark.parametrize("valor,nivel", [
    (0.02, "Potencial/Bajo"), (0.07, "Moderado"), (12, "Crítico"),
    ("8%", "Moderado"), ("Bajo", "Potencial/Bajo"), ("crítico", "Crítico"),
    ("??", None),
])
def test_normalizar_riesgo(valor, nivel):
    assert A.normalizar_riesgo(valor) == nivel


def test_responsable_y_fecha_por_origen_y_riesgo():
    base = date(2026, 10, 17)
    m = A.asignar_responsable("modelamiento", "Crítico", base)
    s = A.asignar_responsable("seguimiento", "Potencial/Bajo", base)
    assert m["responsable"].startswith("Equipo de Modelamiento")
    assert m["fecha_compromiso"] == "16/11/2026"           # +30 días
    assert s["responsable"].startswith("Equipo de Seguimiento")
    assert s["plazo_dias"] == 180


def test_cuadro_con_ia_riesgo_desde_impactos(carpeta):
    respuesta = json.dumps({"observaciones": [
        {"ambito": "control de datos", "titulo": "Missing en ingreso",
         "observacion": "La variable ingreso presenta 12% de missing…",
         "recomendacion": "Para levantar la observación se deberá evidenciar…",
         "riesgo_estimado": "Bajo", "impacto_ref": "Impacto!3",
         "origen": "modelamiento",
         "evidencia": ["01_ControlDatos.xlsx/Calidad!2"]},
        {"ambito": "Implementación", "titulo": "Duplicados",
         "observacion": "Se identificaron 12 clientes duplicados…",
         "recomendacion": "Depurar la llave…", "riesgo_estimado": "Moderado",
         "impacto_ref": None, "origen": "otro",
         "evidencia": ["00_Diagnostico.xlsx/HojaInexistente!5"]},
    ]})
    ia = IAFalsa(respuesta)
    c = A.generar_cuadro(carpeta, usar_ia=True, cliente=ia,
                         contexto_modelo="Modelo PD retail",
                         fecha_base=date(2026, 10, 17))

    assert "RESULTADOS NO CONFORMES" in ia.prompt and "Modelo PD retail" in ia.prompt
    assert "IMPLEMENTACIÓN es prioritaria" in ia.sistema
    f1, f2 = c["filas"]
    # Riesgo determinista desde 03_Impactos, aunque la IA dijera «Bajo».
    assert (f1["riesgo"], f1["riesgo_fuente"]) == ("Crítico", "03_Impactos (Impacto!3)")
    assert f1["ambito"] == "Control de datos" and f1["evidencia_verificada"] is True
    assert f1["responsable"].startswith("Equipo de Modelamiento")
    # Sin vínculo: estimado; origen inválido → se deduce del ámbito.
    assert f2["riesgo_fuente"].startswith("estimado")
    assert f2["origen"] == "seguimiento" and f2["evidencia_verificada"] is False
    assert c["riesgo_desde_impactos"] is True and c["faltan"] == []


def test_sin_impactos_el_riesgo_es_estimado(carpeta):
    (carpeta / "03_Impactos.xlsx").unlink()
    c = A.generar_cuadro(carpeta, usar_ia=False)
    assert c["faltan"] == ["03_Impactos"]
    assert all(f["riesgo_fuente"] == "estimado (no se aportó 03_Impactos)" for f in c["filas"])


def test_borrador_determinista_y_orden(carpeta):
    c = A.generar_cuadro(carpeta, usar_ia=False)
    assert c["modo"] == "determinista" and len(c["filas"]) == 3
    assert {f["ambito"] for f in c["filas"]} <= set(A.AMBITOS)
    # A igual riesgo, Implementación va primero.
    assert c["filas"][0]["ambito"] == "Implementación"
    assert all(f["evidencia_verificada"] for f in c["filas"])
    assert [f["n"] for f in c["filas"]] == [1, 2, 3]


def test_ia_sin_json_falla_con_mensaje(carpeta):
    with pytest.raises(ValueError, match="observaciones"):
        A.generar_cuadro(carpeta, usar_ia=True, cliente=IAFalsa("no sé"))


def test_carpeta_vacia(tmp_path):
    with pytest.raises(FileNotFoundError, match="00_Diagnostico"):
        A.generar_cuadro(tmp_path, usar_ia=False)


def test_exporta_excel_con_columnas_del_cuadro(carpeta, tmp_path):
    c = A.generar_cuadro(carpeta, usar_ia=False)
    rutas = A.guardar(c, tmp_path / "salida")
    ws = load_workbook(rutas["xlsx"])["Cuadro de observaciones"]
    assert [x.value for x in ws[1]] == list(A.COLUMNAS_CUADRO)
    assert ws.max_row == 1 + len(c["filas"])
    assert json.loads(rutas["json"].read_text(encoding="utf-8"))["filas"]


def test_informe_docx_usa_el_cuadro_en_resumen_y_anexo(carpeta, tmp_path, monkeypatch):
    """
    Con la plantilla común, el cuadro de las automatizaciones alimenta
    «V. Cuadro Resumen de Observaciones» (y cuenta para la calificación) y se
    conserva íntegro, con la procedencia del riesgo, como anexo.
    """
    pytest.importorskip("docx")
    from docx import Document
    from web.services import informe_web

    outputs = tmp_path / "outputs"
    A.guardar(A.generar_cuadro(carpeta, usar_ia=False), outputs / "automatizaciones")
    ctx = {"outputs": outputs, "modelo": {"nombre": "M", "slug": "M", "tier": "II"},
           "validador": {"nombre": "Ana"}}
    monkeypatch.setattr(informe_web.chat_service, "sesion_activa", lambda ctx: None)
    inf = informe_web.a_plantilla({"resultados_por_ambito": {}}, ctx)

    cuadro = informe_web._ultimo_cuadro(ctx)
    con_riesgo = [f for f in cuadro["filas"] if f.get("riesgo")]
    obs = [o for o in inf["observaciones"] if o["control_id"] is None]
    assert len(obs) == len(con_riesgo) and obs
    assert all(o["riesgo"] in ("Crítico", "Moderado", "Bajo", "Potencial") for o in obs)
    assert "Cuadro de observaciones de las automatizaciones" in [t for t, _ in inf["anexos"]]

    doc = Document()
    informe_web._cuadro_observaciones(doc, cuadro)
    cab = [c.text for c in doc.tables[0].rows[0].cells]
    assert cab == ["Ámbito", "Riesgo", "Observación", "Recomendación", "Responsable / Fecha"]