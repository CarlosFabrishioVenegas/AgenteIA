"""
tests/test_chunker_estructural.py — chunking estructural (GAP-29).

Verifica que la segmentación estructural (modulos/chunker_estructural.py) respeta
encabezados y NO parte tablas ni fórmulas por la mitad. Determinista, sin API.
"""
from modulos.chunker_estructural import segmentar_estructural

DOC = """# Sección 1 — Metodología

El VaR se calcula al 99% de confianza sobre 250 días.

```
VaR = -percentil(retornos[-250:], 1.0)
```

# Sección 2 — Datos

| campo | tipo | nulos |
| ----- | ---- | ----- |
| fecha | date | 0 |
| pnl   | float| 3 |

Comentario final con una errata: "provisió" sin la n final.
"""


def test_no_parte_la_tabla_a_la_mitad():
    segs = segmentar_estructural(DOC, size_max=80)  # tamaño pequeño a propósito
    tabla = ("| campo | tipo | nulos |\n| ----- | ---- | ----- |\n"
             "| fecha | date | 0 |\n| pnl   | float| 3 |")
    # La tabla completa debe vivir dentro de UN solo segmento, íntegra.
    assert any(tabla in s for s in segs), "la tabla se partió entre segmentos"


def test_no_parte_la_formula_a_la_mitad():
    segs = segmentar_estructural(DOC, size_max=80)
    formula = "VaR = -percentil(retornos[-250:], 1.0)"
    assert any(formula in s for s in segs), "la fórmula se partió"


def test_segmenta_por_encabezados():
    segs = segmentar_estructural(DOC, size_max=10_000)  # sin presión de tamaño
    # Cada encabezado abre su propio segmento.
    assert any(s.startswith("# Sección 1") for s in segs)
    assert any(s.startswith("# Sección 2") for s in segs)


def test_preserva_erratas():
    segs = segmentar_estructural(DOC, size_max=10_000)
    assert any('"provisió"' in s for s in segs), "no debe corregir el contenido"


def test_ningun_segmento_corta_a_mitad_de_linea():
    # Reconstruir la unión de segmentos por líneas no debe inventar cortes:
    # cada línea original no vacía aparece completa en algún segmento.
    segs = segmentar_estructural(DOC, size_max=60)
    unido = "\n".join(segs)
    for linea in DOC.split("\n"):
        if linea.strip():
            assert linea in unido, f"línea partida o perdida: {linea!r}"


def test_texto_vacio_devuelve_lista_vacia():
    assert segmentar_estructural("") == []
    assert segmentar_estructural("   \n  ") == []


def test_bloque_atomico_mayor_que_el_tope_se_emite_entero():
    doc = "| a | b | c | d | e | f | g | h | i | j | k | l | m |"
    segs = segmentar_estructural(doc, size_max=10)  # tope << tabla
    assert segs == [doc]  # íntegra, en un único segmento
