"""
Plantilla común de los tres informes Word (Solo Informe, «Generar informe» de
la web y entregable del pipeline). Coste cero: sin IA, todo en `tmp_path`.

Cubre:
  - Traducción puntaje del agente → riesgo (`riesgo_desde_puntaje`).
  - Que los tres informes compartan el esqueleto: portada BCP, encabezado
    «Página | N», pie, índice, I–VII, ficha del documento, barrido en texto.
  - Informe de la web: el APROBADO del chat subsana; NEGADO conserva el riesgo;
    anexos propios (tabla final, entendimiento, trazabilidad).
  - Entregable del pipeline: bloques regulatorios como anexos, actividad no
    evaluada declarada, sin el literal «None».
"""
from __future__ import annotations

import contextlib
import io
from types import SimpleNamespace

import pytest
from docx import Document

from modulos import plantilla_bcp as PB
from modulos import reglas_informe as reglas

ESQUELETO = ("Gerencia de Administración de Riesgo de Modelo", "Banco de Crédito",
             "Informe de Resultados", "I. Objetivos", "II. Alcance",
             "III. Cumplimiento de Estándar", "IV. Información Relevante",
             "V. Cuadro Resumen de Observaciones", "VI. Glosario",
             "VII. Barrido de Controles", "Descripción del documento",
             "Revisado por", "Fecha de aprobación")


def _texto(doc) -> str:
    partes = [p.text for p in doc.paragraphs]
    partes += [c.text for t in doc.tables for f in t.rows for c in f.cells]
    return "\n".join(partes)


def _esqueleto_ok(doc):
    txt = _texto(doc)
    for s in ESQUELETO:
        assert s in txt, s
    assert doc.sections[0].header.paragraphs[0].text.startswith("Página | ")
    assert doc.sections[0].footer.paragraphs[0].text == (
        "VALIDACIÓN INTERNA DE RIESGO FINANCIERO\tInforme Final")
    assert 'TOC \\o "1-2" \\h' in doc.element.body.xml
    # El barrido es texto estructurado, no tablas.
    assert any(p.text.startswith("Actividad: ") for p in doc.paragraphs)
    assert any(p.text.startswith("Conclusión: ") for p in doc.paragraphs)
    return txt


@pytest.mark.parametrize("puntaje, sin_ev, esperado", [
    (0, False, "Crítico"), (1, False, "Crítico"), (2, False, "Crítico"),
    (2.4, False, "Moderado"), (3, False, "Moderado"), (4, False, "Oportunidad de Mejora"),
    (5, False, None), (None, False, None), (None, True, "Crítico"), ("x", False, None),
])
def test_riesgo_desde_puntaje(puntaje, sin_ev, esperado):
    assert reglas.riesgo_desde_puntaje(puntaje, sin_evidencia=sin_ev) == esperado


def test_plantilla_minima_y_anexos(tmp_path):
    inf = {
        "tipo": "primera_vez", "nombre_modelo": "M", "fecha_inicio": "2026-10-01",
        "fecha_entrega": "2026-10-20", "ambitos": ["Gobierno"],
        "controles": [{"id": "1", "ambito": "Gobierno", "control": "C", "actividad": "A"},
                      {"id": "2", "ambito": "Gobierno", "control": "C", "actividad": "B",
                       "no_evaluado": True}],
        "observaciones": [],
        "anexos": [("Cosa", lambda d: (PB._p(d, "contenido del anexo"), PB._salto_pagina(d)))],
    }
    doc = Document(str(PB.generar(inf, tmp_path / "x.docx")))
    txt = _esqueleto_ok(doc)
    assert "Validación por primera vez de M" in txt
    assert "Anexo A. Cosa" in txt and "contenido del anexo" in txt
    assert "NO EVALUADA" in txt and "Calificación: SATISFACTORIO" in txt
    # El no evaluado no se da por satisfactorio en el cumplimiento.
    tabla = next(t for t in doc.tables if t.rows[0].cells[0].text == "Ámbito")
    assert [c.text for c in tabla.rows[1].cells] == ["Gobierno", "2", "1 (50.0%)", "1 (50.0%)"]
    # El salto final del anexo se quitó (no queda una hoja en blanco al final).
    ult = [el for el in doc.element.body if el.tag.endswith("}p")][-1]
    assert 'w:type="page"' not in ult.xml


# ── «Generar informe» de la web ──────────────────────────────────────

def _sesion_chat():
    from web.services.chat_service import Mensaje, Observacion
    o1 = Observacion(id="o1", ambito="Metodología", actividad="Supuestos", puntaje=2.0,
                     observacion="", veredicto="APROBADO", hallazgo_final="aclarado en el chat")
    o2 = Observacion(id="o2", ambito="Gobierno", actividad="Comité", puntaje=3.0,
                     observacion="", veredicto="NEGADO", hallazgo_final="sin acta")
    m = Mensaje(quien="validador", texto="No hay acta del comité.",
                ts_utc="2026-11-04T10:00:00", observacion_id="o2")
    return SimpleNamespace(observaciones=[o1, o2], mensajes=[m])


DATOS_WEB = {
    "fecha": "2026-11-01", "score_global": 2.5,
    "resultados_por_ambito": {
        "Metodología": [
            {"actividad": "Supuestos", "puntaje": 2, "control": "Justificación",
             "observacion": "Supuestos sin justificar.", "recomendacion": "Justificarlos.",
             "evidencia_encontrada": "El modelo asume normalidad."},
            {"actividad": "Backtesting", "puntaje": 5, "control": "Seguimiento",
             "observacion": "Kupiec y Christoffersen correctos."},
        ],
        "Gobierno": [
            {"actividad": "Comité", "puntaje": 3, "control": "Aprobación",
             "observacion": "Recalibrado sin aprobación formal.",
             "inconsistencias": [{"severidad": "alta", "cita_a": "ventana de 250 días",
                                  "cita_b": "retornos[-500:]",
                                  "contradiccion": "La ventana difiere."}]},
            {"actividad": "Tiering", "puntaje": None, "control": "Tier"},
        ],
    },
    "tabla_validacion": [{"ambito": "Gobierno", "control": "Aprobación", "actividad": "Comité",
                          "resultado": "Parcial", "evaluacion_sustentada": "s",
                          "fuente_revisada": "e", "accion_requerida": "p", "tier": "II"}],
}


def test_informe_web_con_plantilla(tmp_path, monkeypatch):
    from web.services import informe_web
    monkeypatch.setattr(informe_web.chat_service, "sesion_activa", lambda ctx: _sesion_chat())
    ctx = {"outputs": tmp_path / "out", "base": tmp_path, "clave": "T1/M",
           "modelo": {"nombre": "VaR Trading", "slug": "VAR_TRADING", "dominio": "VaR",
                      "tier": "II", "creado_utc": "2026-10-01T09:00:00"},
           "validador": {"codigo": "T1", "nombre": "Ana Pérez"}}

    inf = informe_web.a_plantilla(DATOS_WEB, ctx)
    riesgos = {o["control_id"]: o["riesgo"] for o in inf["observaciones"]}
    ctrl = {c["actividad"]: c["id"] for c in inf["controles"]}
    assert ctrl["Supuestos"] not in riesgos            # APROBADO en el chat → subsanada
    assert riesgos[ctrl["Comité"]] == "Moderado"        # NEGADO conserva el riesgo (puntaje 3)
    assert ctrl["Backtesting"] not in riesgos           # puntaje 5
    assert next(c for c in inf["controles"] if c["actividad"] == "Tiering")["no_evaluado"]

    ruta, version = informe_web.generar(DATOS_WEB, "x.json", ctx)
    assert version == 1 and ruta.name.startswith("VIRF_Informe_VAR_TRADING_V1_")
    doc = Document(str(ruta))
    txt = _esqueleto_ok(doc)
    for s in ("Validación periódica de VaR Trading", "Ana Pérez",
              "observación subsanada en el chat de sustentación",
              "Decisión del chat: NEGADO — sin acta", "No hay acta del comité.",
              "Ambigüedad de fuentes (severidad alta)", "«retornos[-500:]»",
              "Evidencia en el manual / documento", "Puntaje del agente",
              "Anexo A. Tabla de validación final", "Anexo B. Entendimiento del modelo",
              "Anexo C. Trazabilidad", "Calificación: ACEPTABLE"):
        assert s in txt, s
    # La tabla final de 8 columnas sigue en el anexo.
    assert any(len(t.columns) == 8 for t in doc.tables)


# ── Entregable del pipeline ──────────────────────────────────────────

def test_entregable_pipeline_con_plantilla(tmp_path):
    from modulos.generador_word import generar_word_informe
    evals = {"Metodología": [
        {"actividad": "Backtesting", "puntaje": 4, "concepto": "Se revisó el backtesting.",
         "observacion": "Falta Christoffersen.", "evidencia_encontrada": "manual.md",
         "recomendacion": "Añadir Christoffersen.", "preguntas_pendientes": ["¿Ventana?"]},
        {"actividad": "Supuestos", "puntaje": 1, "concepto": "c",
         "observacion": "Supuestos sin justificar.", "recomendacion": ""},
        {"actividad": "Tiering", "puntaje": None, "concepto": "", "observacion": ""},
    ]}
    with contextlib.redirect_stdout(io.StringIO()):
        ruta = generar_word_informe(
            resumen_ejecutivo="### Contexto\nModelo VaR de la mesa.",
            evaluaciones_por_ambito=evals, scores_por_ambito={"Metodología": 2.5},
            score_global=2.5, titulo_modelo="VaR Mesa", tier="II", outputs_dir=tmp_path,
            validacion_humana={"validador": "Ana Pérez", "cargo": "2LoD"},
            fecha_inicio="2026-10-01", fecha_entrega="2026-10-30")
    doc = Document(str(ruta))
    txt = _esqueleto_ok(doc)
    for s in ("Validación periódica de VaR Mesa", "realizada en octubre de 2026",
              "Ana Pérez", "Modelo VaR de la mesa.", "Puntaje del agente: 4/5",
              "Observación 1 (Oportunidad de Mejora)", "Observación 2 (Crítico)",
              "NO EVALUADA", "¿Ventana?", "Anexo A. Aprobación y responsabilidad",
              "Anexo B. Trazabilidad y cadena de custodia",
              "Anexo C. Escala de evaluación del agente",
              "Anexo D. Correcciones del validador", "Calificación: REGULAR"):
        assert s in txt, s
    assert "Análisis transversales" not in txt          # sin skills, sin anexo E
    assert "None" not in txt.replace("Ninguno", "")
