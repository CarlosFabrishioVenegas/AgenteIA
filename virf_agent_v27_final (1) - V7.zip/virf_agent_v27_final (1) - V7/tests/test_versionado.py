"""
tests/test_versionado.py — WP-10: versionado temporal + ventana de contexto.

Dos piezas, ambas deterministas y sin API:
  · Pre-filtro duro is_active en la recuperación léxica (no validar contra
    metodologías derogadas).
  · Detección config-driven de la ventana de contexto real del modelo, en vez
    del fallback fijo 15000.
"""
from datetime import date

import pytest

from modulos.versionado import chunk_activo, filtrar_activos, marcar_version
from modulos.ventana_contexto import resolver_ventana, max_ctx_efectivo


# ═══════════════════════════════════════════════════════════════════════════
# Versionado — reglas de vigencia
# ═══════════════════════════════════════════════════════════════════════════
class TestVigencia:
    def test_chunk_sin_metadatos_esta_activo(self):
        # Compatibilidad hacia atrás: el corpus actual no lleva versión.
        assert chunk_activo({"texto": "x"}) is True

    def test_is_active_false_es_inactivo(self):
        assert chunk_activo({"is_active": False}) is False

    def test_aun_no_vigente_por_effective_date(self):
        c = {"is_active": True, "effective_date": "2026-01-01"}
        assert chunk_activo(c, en_fecha=date(2025, 12, 31)) is False
        assert chunk_activo(c, en_fecha=date(2026, 1, 1)) is True

    def test_derogado_por_expiration_date(self):
        c = {"is_active": True, "expiration_date": "2026-06-01"}
        assert chunk_activo(c, en_fecha=date(2026, 6, 1)) is False   # límite: ya derogado
        assert chunk_activo(c, en_fecha=date(2026, 5, 31)) is True

    def test_fecha_ilegible_no_revienta(self):
        assert chunk_activo({"effective_date": "ayer"}, en_fecha=date(2026, 1, 1)) is True

    def test_filtrar_activos_preserva_orden(self):
        chunks = [
            {"id": 1},
            {"id": 2, "is_active": False},
            {"id": 3, "is_active": True},
        ]
        assert [c["id"] for c in filtrar_activos(chunks)] == [1, 3]

    def test_marcar_version_es_aditivo(self):
        c = marcar_version({"texto": "t"}, is_active=False, supersedes="v1")
        assert c["texto"] == "t" and c["is_active"] is False and c["supersedes"] == "v1"


# ═══════════════════════════════════════════════════════════════════════════
# Ventana de contexto — config-driven, sin 15000 silencioso
# ═══════════════════════════════════════════════════════════════════════════
class TestVentanaContexto:
    def test_gpt4o_resuelve_su_ventana_real_no_15000(self):
        # Nombre de deployment que contiene el token catalogado 'gpt-4o'. Sin
        # API solo se dispone del nombre; la resolución es por substring.
        r = resolver_ventana("virf-gpt-4o-prod", env={})
        assert r["fuente"] == "catalogo"
        assert r["contexto_tokens"] == 128_000
        assert r["max_ctx"] > 15_000          # ya no es el fallback fijo
        assert r["confirmado_por_api"] is False   # honesto: solo por nombre

    def test_gpt4_clasico_tiene_ventana_menor(self):
        r = resolver_ventana("mi-deploy-gpt-4", env={})
        assert r["contexto_tokens"] == 8_192

    def test_override_explicito_del_operador_gana(self):
        r = resolver_ventana("gpt4o-virf-prod", env={"VIRF_MAX_CTX": "20000"})
        assert r["fuente"] == "env"
        assert r["max_ctx"] == 20_000

    def test_deployment_desconocido_cae_a_conservador_declarado(self):
        r = resolver_ventana("modelo-raro-inexistente", env={})
        assert r["fuente"] == "fallback"
        assert r["nota"]                       # declara el gap, no default mudo

    def test_max_ctx_efectivo_atajo(self):
        assert max_ctx_efectivo("gpt-4o", env={}) == resolver_ventana("gpt-4o", env={})["max_ctx"]


# ═══════════════════════════════════════════════════════════════════════════
# Pre-filtro is_active integrado en el retriever léxico
# ═══════════════════════════════════════════════════════════════════════════
def _corpus(tmp_path, docs):
    carpeta = tmp_path / "corpus"
    carpeta.mkdir(exist_ok=True)
    for nombre, texto in docs.items():
        (carpeta / nombre).write_text(texto, encoding="utf-8")
    return carpeta


def _buscador(tmp_path, docs, dominio="test"):
    from src.rag.indexador_lexico import IndexadorLexico
    from src.rag.buscador_lexico import BuscadorLexico
    idx = IndexadorLexico(dominio, fuentes=[_corpus(tmp_path, docs)])
    idx.ruta = tmp_path / "indice" / f"{dominio}.pkl"
    idx.construir(force=True)
    b = BuscadorLexico(dominio, autoconstruir=False)
    b._indexador = idx
    return b


DOCS = {
    "kupiec.md": ("Backtesting de VaR. La prueba de Kupiec contrasta la cobertura "
                  "incondicional comparando el numero de excepciones observadas "
                  "con las esperadas bajo el nivel de confianza declarado."),
    "liquidez.md": ("El coeficiente de cobertura de liquidez LCR exige un stock de "
                    "activos liquidos de alta calidad HQLA para cubrir salidas."),
}


def test_chunk_inactivo_no_se_recupera(tmp_path):
    b = _buscador(tmp_path, DOCS)

    # Antes de derogar: la consulta sobre Kupiec recupera su documento.
    antes = b.buscar("prueba de Kupiec excepciones", top_k=5)
    assert any("kupiec.md" == r["fuente"] for r in antes), "el corpus debía traer kupiec"

    # Derogamos el/los chunk(s) de kupiec.md marcándolos is_active=False.
    for ch in b._indice.chunks:
        if ch["fuente"] == "kupiec.md":
            ch["is_active"] = False

    despues = b.buscar("prueba de Kupiec excepciones", top_k=5)
    assert not any("kupiec.md" == r["fuente"] for r in despues), \
        "un chunk is_active=False no debe recuperarse (metodología derogada)"
