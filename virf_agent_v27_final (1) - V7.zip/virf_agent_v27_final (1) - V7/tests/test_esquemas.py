"""
tests/test_esquemas.py — contrato Pydantic ValidationReport (WP-09).

Verifica que un dict correcto produce un ValidationReport válido y que uno
malformado (status inválido, cita ausente, confianza fuera de rango) FALLA la
validación. Determinista, sin API.
"""
import pytest

from modulos.esquemas import (
    EstadoRequisito,
    ValidationClaim,
    ValidationReport,
    ValidationError,
    desde_dict,
    intentar_validar,
)


def _reporte_ok() -> dict:
    return {
        "model_id": "VAR_RETAIL_01",
        "overall_confidence": 0.91,
        "abstained": False,
        "unresolved_conflicts": [],
        "findings": [
            {
                "requirement_id": "REQ-VAR-99",
                "status": "IMPLEMENTADO",
                "evidence_text": "Manual metodológico, pág. 4: nivel de confianza 99%.",
                "code_evidence": "modelo_var.py:12  q = 1.0  # percentil 1",
                "justification": "El código usa percentil 1 ↔ 99% del manual.",
            }
        ],
    }


def test_dict_correcto_produce_reporte_valido():
    rep = desde_dict(_reporte_ok())
    assert isinstance(rep, ValidationReport)
    assert rep.model_id == "VAR_RETAIL_01"
    assert 0.0 <= rep.overall_confidence <= 1.0
    assert len(rep.findings) == 1
    assert rep.findings[0].status == EstadoRequisito.IMPLEMENTADO.value


def test_status_invalido_falla():
    malo = _reporte_ok()
    malo["findings"][0]["status"] = "APROBADISIMO"  # fuera del enum
    with pytest.raises(ValidationError):
        desde_dict(malo)


def test_cita_ausente_falla():
    # Un cumplimiento (IMPLEMENTADO) sin evidence_text debe fallar la validación.
    malo = _reporte_ok()
    malo["findings"][0]["evidence_text"] = ""
    with pytest.raises(ValidationError):
        desde_dict(malo)


def test_desviado_sin_codigo_falla():
    malo = _reporte_ok()
    malo["findings"][0]["status"] = "DESVIADO"
    malo["findings"][0]["code_evidence"] = ""  # no se puede alegar desvío sin la línea
    with pytest.raises(ValidationError):
        desde_dict(malo)


def test_omitido_admite_codigo_vacio():
    # OMITIDO es la única excepción: el requisito no está en el código.
    ok = _reporte_ok()
    ok["findings"][0]["status"] = "OMITIDO"
    ok["findings"][0]["code_evidence"] = ""
    rep = desde_dict(ok)
    assert rep.findings[0].status == EstadoRequisito.OMITIDO.value


def test_confianza_fuera_de_rango_falla():
    malo = _reporte_ok()
    malo["overall_confidence"] = 1.5
    with pytest.raises(ValidationError):
        desde_dict(malo)


def test_model_id_en_blanco_falla():
    malo = _reporte_ok()
    malo["model_id"] = "   "
    with pytest.raises(ValidationError):
        desde_dict(malo)


def test_sinonimo_hallazgos_se_acepta():
    # Compatibilidad hacia atrás: el pipeline puede traer 'hallazgos' en vez de 'findings'.
    d = _reporte_ok()
    d["hallazgos"] = d.pop("findings")
    rep = desde_dict(d)
    assert len(rep.findings) == 1


def test_intentar_validar_no_levanta():
    malo = _reporte_ok()
    malo["overall_confidence"] = 9.0
    rep, errores = intentar_validar(malo)
    assert rep is None
    assert errores and isinstance(errores[0], str)


def test_reporte_abstenido_sin_hallazgos_es_valido():
    rep = desde_dict({
        "model_id": "LAR_01",
        "overall_confidence": 0.0,
        "abstained": True,
    })
    assert rep.abstained is True
    assert rep.findings == []
