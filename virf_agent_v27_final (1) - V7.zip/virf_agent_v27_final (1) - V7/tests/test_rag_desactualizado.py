"""
tests/test_rag_desactualizado.py — el panel RAG avisa si el índice quedó obsoleto
tras añadir manuales (cierra el footgun de «subí papers pero no reconstruí»).
"""
import os
import pytest


def _set(p, t):
    os.utime(p, (t, t))


def test_indice_ausente_con_papers_es_desactualizado(tmp_path):
    from web.routers.rag import _esta_desactualizado
    inputs = tmp_path / "LaR"; inputs.mkdir()
    (inputs / "manual_metodologico.md").write_text("contenido")
    pkl = tmp_path / "LaR.pkl"                     # no existe
    assert _esta_desactualizado(inputs, pkl) is True


def test_indice_mas_nuevo_esta_al_dia(tmp_path):
    from web.routers.rag import _esta_desactualizado
    inputs = tmp_path / "LaR"; inputs.mkdir()
    src = inputs / "manual.md"; src.write_text("x"); _set(src, 1000)
    pkl = tmp_path / "LaR.pkl"; pkl.write_text("idx"); _set(pkl, 2000)
    assert _esta_desactualizado(inputs, pkl) is False


def test_source_mas_nuevo_marca_desactualizado(tmp_path):
    from web.routers.rag import _esta_desactualizado
    inputs = tmp_path / "LaR"; inputs.mkdir()
    src = inputs / "manual.md"; src.write_text("x")
    pkl = tmp_path / "LaR.pkl"; pkl.write_text("idx"); _set(pkl, 1000)
    _set(src, 3000)                                # manual añadido/editado después
    assert _esta_desactualizado(inputs, pkl) is True


def test_readme_y_dotfiles_no_cuentan(tmp_path):
    from web.routers.rag import _esta_desactualizado
    inputs = tmp_path / "LaR"; inputs.mkdir()
    pkl = tmp_path / "LaR.pkl"; pkl.write_text("idx"); _set(pkl, 1000)
    for nombre in ("README.md", ".gitkeep"):
        f = inputs / nombre; f.write_text("x"); _set(f, 5000)
    assert _esta_desactualizado(inputs, pkl) is False


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
