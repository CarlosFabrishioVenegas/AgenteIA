# -*- coding: utf-8 -*-
"""
Prueba del endpoint GET /api/motores/notebook (coste 0: LLM interceptado).

Sobrescribe la dependencia de sesión con un contexto de prueba y verifica los DOS
caminos que hoy tiene el orquestador `generar_ipynb_controles`:

  · PRIORIDAD 1 — el dominio tiene controles en `inputs/repositorio_controles/`:
    el notebook es ESPECIALIZADO (una celda por control Python del repo). Es el
    flujo por defecto para VaR/LaR/ALM/conductuales desde que existe el repo.
  · FALLBACK — el dominio NO tiene repo: se cae al flujo anterior (documento →
    catálogo → propuesta del LLM), que aquí se intercepta para no gastar API.

El conteo esperado del camino de repositorio se calcula en vivo con
`cargar_controles`, para que añadir o quitar un control del repo no vuelva a
desfasar este test (era exactamente lo que lo tenía en rojo: el repo pasó a 3
controles y el test seguía esperando 1).
"""
from pathlib import Path

import pandas as pd
import pytest
from fastapi.testclient import TestClient

import nbformat as nbf
from web.app import app
from web.services.contexto_sesion import contexto_sesion


@pytest.fixture()
def make_ctx(tmp_path):
    """Fábrica de contexto de sesión de prueba, parametrizable por dominio."""
    def _crear(dominio: str):
        ds = tmp_path / "inputs" / "calidad_datos" / "datasets"
        ds.mkdir(parents=True, exist_ok=True)
        pd.DataFrame({"Cuenta": ["A", "B", "C"], "Cliente": ["c1", "c2", "c3"]}).to_csv(
            ds / "data_subset.csv", index=False)
        return {
            "validador": {"codigo": "V1", "nombre": "Tester"},
            "modelo": {"slug": "modelo_x", "nombre": "Modelo X",
                       "dominio": dominio, "tier": "II"},
            "base": tmp_path,
            "inputs": tmp_path / "inputs",
            "outputs": tmp_path / "outputs",
            "clave": "V1/modelo_x",
        }
    return _crear


def _get_notebook(ctx):
    app.dependency_overrides[contexto_sesion] = lambda: ctx
    try:
        return TestClient(app).get("/api/motores/notebook")
    finally:
        app.dependency_overrides.pop(contexto_sesion, None)


def test_endpoint_repositorio_dominio(make_ctx):
    """LaR tiene controles en el repositorio → notebook especializado del repo,
    sin tocar el LLM. El número de controles se toma del propio repositorio."""
    from modulos.repositorio_controles import cargar_controles
    repo_ctrls, _ = cargar_controles("LaR")
    n_esperado = len(repo_ctrls)
    assert n_esperado >= 1, "el repositorio de LaR debería traer al menos un control"

    resp = _get_notebook(make_ctx("LaR"))

    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/x-ipynb+json")
    assert "attachment" in resp.headers["content-disposition"]
    assert "modelo_x" in resp.headers["content-disposition"]
    # El conteo lo fija el repositorio, no un número mágico.
    assert resp.headers["x-controles-n"] == str(n_esperado)

    nb = nbf.reads(resp.text, as_version=4)
    fuentes = "\n".join(c["source"] for c in nb["cells"])
    # Marcadores estables del notebook de REPOSITORIO (no del de 8 col por LLM).
    assert "control del repositorio" in fuentes
    assert "tabla_control" in fuentes
    assert nb["metadata"].get("generado_por") == "virf_agent repositorio_controles"


def test_endpoint_fallback_llm_sin_repositorio(monkeypatch, make_ctx):
    """Un dominio SIN carpeta en el repositorio cae al flujo LLM (interceptado):
    un solo control propuesto y el notebook de 8 columnas."""
    import modulos.notebook_controles as N
    monkeypatch.setattr(
        N, "generar_controles_desde_entendimiento",
        lambda ent, **kw: {"resumen_documento": "propuesta",
                           "controles": [{"descripcion": "Cuenta única",
                                          "tipo_motor": "unicidad",
                                          "group_cols": "Cuenta",
                                          "campo_objetivo": "Cuenta"}]})

    # 'credito' no tiene carpeta en inputs/repositorio_controles/ → fallback.
    resp = _get_notebook(make_ctx("credito"))

    assert resp.status_code == 200
    assert resp.headers["x-controles-n"] == "1"
    nb = nbf.reads(resp.text, as_version=4)
    fuentes = "\n".join(c["source"] for c in nb["cells"])
    assert "tabla_control" in fuentes and "META_CONTROLES" in fuentes
