# -*- coding: utf-8 -*-
"""
Verificación semántica de citas (modulos/entailment.py) — SIN API.

Se inyecta un cliente falso (no toca ningún proveedor): coste 0. Lo que se fija:
  · Apagado (default) → NA-diferido, sin llamar al juez.
  · Encendido → interpreta IMPLICA / NO_IMPLICA / INSUFICIENTE.
  · Ancla dura: un veredicto sin cita real del fragmento se degrada a NA (no
    se acepta un «sí» inventado por el juez).
"""
import json
import pytest

from modulos import entailment


class ClienteFake:
    """Cliente IA de mentira: devuelve el JSON que se le programe, contando llamadas."""
    def __init__(self, respuesta):
        self.respuesta = respuesta
        self.llamadas = 0

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                        sistema=None, formato_json=False):
        self.llamadas += 1
        return self.respuesta if isinstance(self.respuesta, str) else json.dumps(
            self.respuesta, ensure_ascii=False)


AFIRM = "El backtesting emplea una ventana de observación de 250 días."
FRAG = ("Sección 4.2 — La ventana de observación es de 250 días, coherente con "
        "la práctica supervisora para el backtesting de VaR.")


def test_apagado_por_defecto_devuelve_na(monkeypatch):
    monkeypatch.setattr("config.parametros.ENTAILMENT_ACTIVO", False, raising=False)
    cli = ClienteFake({"veredicto": "IMPLICA", "confianza": 1, "evidencia": "x"})
    r = entailment.verificar(AFIRM, FRAG, cliente=cli)
    assert r["estado"] == "NA-diferido"
    assert r["implica"] is None
    assert cli.llamadas == 0          # NO se gasta ninguna llamada estando apagado


def test_implica_con_cita_real(monkeypatch):
    monkeypatch.setattr("config.parametros.ENTAILMENT_ACTIVO", True, raising=False)
    cli = ClienteFake({"veredicto": "IMPLICA", "confianza": 0.9,
                       "evidencia": "La ventana de observación es de 250 días"})
    r = entailment.verificar(AFIRM, FRAG, cliente=cli)
    assert r["implica"] is True
    assert r["estado"] == "ok"
    assert cli.llamadas == 1


def test_no_implica(monkeypatch):
    monkeypatch.setattr("config.parametros.ENTAILMENT_ACTIVO", True, raising=False)
    cli = ClienteFake({"veredicto": "NO_IMPLICA", "confianza": 0.8,
                       "evidencia": "La ventana de observación es de 250 días"})
    r = entailment.verificar(AFIRM, FRAG, cliente=cli)
    assert r["implica"] is False
    assert "NO sostiene" in r["motivo"]


def test_veredicto_sin_cita_real_se_degrada(monkeypatch):
    # El juez dice IMPLICA pero su "evidencia" NO está en el fragmento: no se
    # acepta como sí — se degrada a insuficiente (implica None), estado ok.
    monkeypatch.setattr("config.parametros.ENTAILMENT_ACTIVO", True, raising=False)
    cli = ClienteFake({"veredicto": "IMPLICA", "confianza": 0.99,
                       "evidencia": "algo que el fragmento jamás dijo"})
    r = entailment.verificar(AFIRM, FRAG, cliente=cli)
    assert r["implica"] is None
    assert r["estado"] == "ok"
    assert "ancló" in r["motivo"] or "INSUFICIENTE" in r["motivo"]


def test_insuficiente(monkeypatch):
    monkeypatch.setattr("config.parametros.ENTAILMENT_ACTIVO", True, raising=False)
    cli = ClienteFake({"veredicto": "INSUFICIENTE", "confianza": 0.3, "evidencia": ""})
    r = entailment.verificar(AFIRM, FRAG, cliente=cli)
    assert r["implica"] is None and r["estado"] == "ok"


def test_entradas_cortas_no_llaman_al_juez(monkeypatch):
    monkeypatch.setattr("config.parametros.ENTAILMENT_ACTIVO", True, raising=False)
    cli = ClienteFake({"veredicto": "IMPLICA", "confianza": 1, "evidencia": "x"})
    r = entailment.verificar("corto", FRAG, cliente=cli)
    assert r["estado"] == "NA-diferido"
    assert cli.llamadas == 0


def test_juez_que_revienta_no_tumba_la_evaluacion(monkeypatch):
    monkeypatch.setattr("config.parametros.ENTAILMENT_ACTIVO", True, raising=False)

    class ClienteRoto:
        def generar_mensaje(self, *a, **k):
            raise RuntimeError("503 del proveedor")

    r = entailment.verificar(AFIRM, FRAG, cliente=ClienteRoto())
    assert r["estado"] == "error"
    assert r["implica"] is None
