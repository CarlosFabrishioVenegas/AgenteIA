"""
Tests de la capa de prompts editables por sesión y presupuesto dinámico
(WEB-V2.3).

Cubre:
  - PromptService.get_prompt: fallback base cuando no hay override.
  - PromptService.editar_prompt: valida placeholders y persiste custom.
  - PromptService.editar_prompt: rechaza prompts no editables.
  - PromptService.restaurar_prompt: elimina el override (idempotente).
  - presupuesto_service.calcular: perfil de GPT-4o vs desconocido.
  - presupuesto_service.aplicar_env: sobreescribe VIRF_MAX_CTX sin mutar env real.
  - chat_service: usa el prompt custom cuando existe.
  - analisis_codigo: usa el prompt custom cuando existe.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from web.services import prompt_service, presupuesto_service


@pytest.fixture
def ctx_de_prueba(tmp_path: Path) -> dict:
    """Contexto de sesión mínimo — igual al que produce contexto_sesion()."""
    base = tmp_path / "sesion"
    base.mkdir(parents=True, exist_ok=True)
    return {
        "validador": {"codigo": "T5443", "nombre": "Test"},
        "modelo":    {"slug": "MOD_TEST", "nombre": "Modelo Test", "dominio": "VaR", "tier": "II"},
        "base":      base,
        "inputs":    base / "inputs",
        "outputs":   base / "outputs",
        "clave":     "T5443/MOD_TEST",
    }


# ── PromptService ─────────────────────────────────────────────────────

class TestPromptService:
    def test_get_prompt_fallback_a_base(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        rol = prompt_service.get_prompt(ctx_de_prueba, "rol_agente")
        assert "Auditor" in rol and "VIRF" in rol

    def test_editar_texto_plano_persiste(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        nuevo = "Eres un auditor forense de modelos crediticios."
        entrada = prompt_service.editar_prompt(
            ctx_de_prueba, "rol_agente", nuevo, editor="T5443")
        assert entrada["es_custom"] is True
        assert prompt_service.get_prompt(ctx_de_prueba, "rol_agente") == nuevo
        # Y el fichero está en disco.
        assert (ctx_de_prueba["base"] / "prompts_custom.json").is_file()

    def test_editar_template_valida_placeholders(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        # Chat: tiene {modelo}, {dominio}, {tier}, etc.
        malo = "Prompt sin placeholders"
        with pytest.raises(ValueError, match="placeholders"):
            prompt_service.editar_prompt(
                ctx_de_prueba, "chat_agente", malo, editor="T5443")

    def test_editar_template_acepta_todos_los_placeholders(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        base = prompt_service.prompts_base()["chat_agente"]
        # Prompt custom que MANTIENE todos los {placeholders}.
        nuevo = base["contenido"] + "\n\nMENSAJE ADICIONAL DEL VALIDADOR."
        entrada = prompt_service.editar_prompt(
            ctx_de_prueba, "chat_agente", nuevo, editor="T5443")
        assert entrada["es_custom"] is True
        assert "MENSAJE ADICIONAL" in prompt_service.get_prompt(ctx_de_prueba, "chat_agente")

    def test_evaluacion_ambito_no_editable(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        with pytest.raises(PermissionError):
            prompt_service.editar_prompt(
                ctx_de_prueba, "evaluacion_ambito", "cualquier cosa", editor="T5443")

    def test_restaurar_es_idempotente(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        # Restaurar sin haber editado antes: no lanza.
        entrada = prompt_service.restaurar_prompt(ctx_de_prueba, "rol_agente")
        assert entrada["es_custom"] is False
        # Editar, restaurar, editar de nuevo: sigue funcionando.
        prompt_service.editar_prompt(
            ctx_de_prueba, "rol_agente", "V1", editor="T5443")
        prompt_service.restaurar_prompt(ctx_de_prueba, "rol_agente")
        base_rol = prompt_service.prompts_base()["rol_agente"]["contenido"]
        assert prompt_service.get_prompt(ctx_de_prueba, "rol_agente") == base_rol

    def test_editar_con_mismo_contenido_que_base_restaura(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        base_rol = prompt_service.prompts_base()["rol_agente"]["contenido"]
        entrada = prompt_service.editar_prompt(
            ctx_de_prueba, "rol_agente", base_rol, editor="T5443")
        # Si el contenido es idéntico al base, no se crea custom (restaura).
        assert entrada["es_custom"] is False

    def test_prompt_id_desconocido_lanza(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        with pytest.raises(KeyError):
            prompt_service.get_prompt(ctx_de_prueba, "no_existe")


# ── presupuesto_service ───────────────────────────────────────────────

class TestPresupuestoService:
    def test_gpt_4o_tiene_ventana_grande(self):
        p = presupuesto_service.calcular("gpt-4o-2024-11-20")
        assert p["ventana_tokens"] == 128_000
        assert p["presupuesto_evidencia_chars"] > 150_000
        assert p["cabe_todo_en_una_llamada"] is True

    def test_gpt_4_clasico_tiene_ventana_pequena(self):
        p = presupuesto_service.calcular("gpt-4")
        # 8K tokens ≈ 20K chars; presupuesto 60% ≈ ~12K con techo mínimo de 4K.
        assert p["ventana_tokens"] == 8_192
        assert p["cabe_todo_en_una_llamada"] is False

    def test_desconocido_usa_conservador(self):
        p = presupuesto_service.calcular("modelo-fantasma-xyz")
        # PERFIL_CONSERVADOR: 16K tokens.
        assert p["ventana_tokens"] == 16_000

    def test_none_usa_conservador(self):
        p = presupuesto_service.calcular(None)
        assert p["ventana_tokens"] == 16_000

    def test_aplicar_env_no_muta_el_real(self, monkeypatch):
        monkeypatch.setenv("VIRF_MAX_CTX", "15000")
        pres = presupuesto_service.calcular("gpt-4o")
        env_hijo = presupuesto_service.aplicar_env(pres, env={"FOO": "bar"})
        assert env_hijo["VIRF_MAX_CTX"] == str(pres["presupuesto_evidencia_chars"])
        assert env_hijo["FOO"] == "bar"
        # El env REAL sigue en 15000, no se tocó.
        assert os.environ["VIRF_MAX_CTX"] == "15000"


# ── Integración: los servicios usan los prompts custom ────────────────

class TestIntegracionCustom:
    def test_chat_service_usa_prompt_custom(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        base = prompt_service.prompts_base()["chat_agente"]
        # Reemplazamos el rol conservando todos los placeholders.
        nuevo = "SOY UN AGENTE PERSONALIZADO.\n" + base["contenido"]
        prompt_service.editar_prompt(
            ctx_de_prueba, "chat_agente", nuevo, editor="T5443")
        # Comprobamos que get_prompt lo devuelve.
        assert prompt_service.get_prompt(ctx_de_prueba, "chat_agente").startswith(
            "SOY UN AGENTE PERSONALIZADO")

    def test_analisis_codigo_usa_prompt_custom(self, ctx_de_prueba):
        prompt_service.clear_cache_para_tests()
        from web.services import analisis_codigo
        base = prompt_service.prompts_base()["entendimiento_modelo"]
        nuevo = "PROMPT CUSTOM DE ENTENDIMIENTO.\n" + base["contenido"]
        prompt_service.editar_prompt(
            ctx_de_prueba, "entendimiento_modelo", nuevo, editor="T5443")

        # armar_prompt debe usar el custom cuando le pasamos ctx.
        base_impl = ctx_de_prueba["inputs"] / "implementacion"
        base_impl.mkdir(parents=True, exist_ok=True)
        est = {"archivos": [], "totales": {"archivos": 0, "lineas": 0,
                                            "funciones": 0, "clases": 0}}
        prompt = analisis_codigo._armar_prompt(
            "Modelo Test", "VaR", est, [], base_impl, ctx=ctx_de_prueba)
        assert prompt.startswith("PROMPT CUSTOM DE ENTENDIMIENTO")


# ── Verificar que motor_ia respeta VIRF_ROL_AGENTE_OVERRIDE ──────────

class TestRolAgenteOverride:
    def test_mx03_lee_env_override(self, monkeypatch):
        """
        Mx_03_LlamarIA lee VIRF_ROL_AGENTE_OVERRIDE del entorno; el pipeline
        subprocess hereda esa variable y el LLM recibe el rol editado.
        Aquí verificamos que la lectura del env ocurra: mock del cliente y
        capturamos qué instruccion_sistema le llega.
        """
        monkeypatch.setenv("VIRF_ROL_AGENTE_OVERRIDE", "ROL FORZADO POR TEST")
        capturado = {}

        class ClienteFalso:
            def generar_mensaje(self, prompt, max_tokens, instruccion_sistema):
                capturado["sistema"] = instruccion_sistema
                return '{"puntaje": 3, "concepto": "x", "observacion": "y", ' \
                       '"recomendacion": "z", "preguntas_pendientes": [], ' \
                       '"evidencia_encontrada": "x"}'

        import Mx_03_LlamarIA as m3
        monkeypatch.setattr(m3, "_obtener_cliente", lambda: ClienteFalso())
        m3._llamar_modelo(user_prompt="Ping", max_tokens=100)
        assert capturado["sistema"] == "ROL FORZADO POR TEST"

    def test_mx03_fallback_cuando_no_hay_override(self, monkeypatch):
        monkeypatch.delenv("VIRF_ROL_AGENTE_OVERRIDE", raising=False)
        capturado = {}

        class ClienteFalso:
            def generar_mensaje(self, prompt, max_tokens, instruccion_sistema):
                capturado["sistema"] = instruccion_sistema
                return '{"puntaje": 3, "concepto": "x", "observacion": "y", ' \
                       '"recomendacion": "z", "preguntas_pendientes": [], ' \
                       '"evidencia_encontrada": "x"}'

        import Mx_03_LlamarIA as m3
        from Mx_00_CargaRutas import ROL_AGENTE
        monkeypatch.setattr(m3, "_obtener_cliente", lambda: ClienteFalso())
        m3._llamar_modelo(user_prompt="Ping", max_tokens=100)
        assert capturado["sistema"] == ROL_AGENTE
