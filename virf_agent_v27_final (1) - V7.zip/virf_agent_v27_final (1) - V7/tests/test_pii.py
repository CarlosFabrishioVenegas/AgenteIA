# -*- coding: utf-8 -*-
"""
Enmascarado PII (modulos/pii.py): alta precisión, 100% local, sin red.

Lo que se fija:
  · Se enmascara lo que ES PII (correo, tarjeta Luhn-válida, IBAN mod-97, DNI/NIE).
  · NO se enmascaran las cifras legítimas de un documento financiero (importes,
    números sin checksum), que es el riesgo real del dominio.
  · Los teléfonos solo caen con contexto («tel.», «+34…»), nunca una cifra suelta.
"""
from modulos.pii import enmascarar, contiene_pii, PLACEHOLDERS


def _tipos(hallazgos):
    return {h["tipo"] for h in hallazgos}


def test_correo_se_enmascara():
    t, h = enmascarar("Contacto: ana.perez@banco.com para dudas.")
    assert PLACEHOLDERS["CORREO"] in t
    assert "ana.perez@banco.com" not in t
    assert "CORREO" in _tipos(h)


def test_tarjeta_valida_luhn_se_enmascara():
    # 4111 1111 1111 1111 es un número de prueba Visa (Luhn-válido).
    t, h = enmascarar("Pago con la tarjeta 4111 1111 1111 1111 registrada.")
    assert PLACEHOLDERS["TARJETA"] in t
    assert "TARJETA" in _tipos(h)


def test_numero_largo_no_valido_no_se_toca():
    # 16 dígitos que NO pasan Luhn: no es una tarjeta, no debe enmascararse.
    t, h = enmascarar("El identificador interno 1234567812345678 del lote.")
    assert PLACEHOLDERS["TARJETA"] not in t
    assert "1234567812345678" in t


def test_iban_valido_se_enmascara_y_uno_falso_no():
    t, h = enmascarar("Cuenta ES91 2100 0418 4502 0005 1332 del cliente.")
    assert PLACEHOLDERS["IBAN"] in t
    t2, h2 = enmascarar("Referencia ES00 0000 0000 0000 0000 0000 inventada.")
    assert PLACEHOLDERS["IBAN"] not in t2


def test_dni_valido_se_enmascara_y_cifra_sola_no():
    t, h = enmascarar("El titular con DNI 12345678Z firmó el acta.")
    assert PLACEHOLDERS["DOCID"] in t
    assert "DOCID" in _tipos(h)
    # Ocho dígitos sin letra de control = no es un DNI: se respeta.
    t2, _ = enmascarar("La serie tiene 12345678 observaciones.")
    assert PLACEHOLDERS["DOCID"] not in t2


def test_importe_financiero_no_es_pii():
    # El caso que hace peligroso enmascarar en este dominio: cifras por todos
    # lados. Ninguna debe tocarse.
    texto = ("El VaR al 99% fue 1.234.567,89 EUR; la ventana de 250 días con "
             "500 escenarios y umbral de 0,05.")
    t, h = enmascarar(texto)
    assert t == texto
    assert h == []


def test_telefono_solo_con_contexto():
    t, h = enmascarar("Llamar al tel: +34 600 123 456 antes de las 18h.")
    assert PLACEHOLDERS["TELEFONO"] in t
    assert "TELEFONO" in _tipos(h)
    # Sin etiqueta ni prefijo internacional, una tira de 9 dígitos es ambigua
    # (podría ser un importe o un código): NO se enmascara.
    t2, _ = enmascarar("El lote 600123456 se procesó ayer.")
    assert PLACEHOLDERS["TELEFONO"] not in t2


def test_texto_limpio_pasa_igual():
    texto = "El backtesting de Kupiec se ejecutó sobre datos reales."
    t, h = enmascarar(texto)
    assert t == texto and h == []
    assert contiene_pii(texto) is False


def test_nunca_lanza_con_entradas_raras():
    assert enmascarar("") == ("", [])
    assert enmascarar(None)[0] == ""
    # Consistencia: enmascarar dos veces es idempotente (los placeholders no son PII).
    t1, _ = enmascarar("correo a@b.com y otra cosa")
    t2, _ = enmascarar(t1)
    assert t1 == t2
