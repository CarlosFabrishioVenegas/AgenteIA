"""
tests/test_exportador_excel.py — Excel de la tabla de validación (WP-B). Coste 0.
"""
import io
import pytest


def _tabla():
    return [
        {"ambito": "Metodología", "control": "Backtesting", "actividad": "A1",
         "resultado": "No cumple", "evaluacion_sustentada": "sustento A1",
         "fuente_revisada": "manual.pdf → x", "accion_requerida": "corregir"},
        {"ambito": "Metodología", "control": "Otros", "actividad": "A2",
         "resultado": "No aplicable", "evaluacion_sustentada": "",
         "fuente_revisada": "", "accion_requerida": ""},
    ]


def test_xlsx_valido_con_8_columnas_y_aplica():
    from modulos.exportador_excel import a_bytes
    from openpyxl import load_workbook
    data = a_bytes(_tabla(), {"modelo": "M", "tier": "I", "tipo": "intermedio",
                              "score_global": 2.26})
    wb = load_workbook(io.BytesIO(data))
    ws = wb.active
    # Cabecera en la fila 5.
    encabezados = [ws.cell(row=5, column=c).value for c in range(1, 9)]
    assert encabezados == ["Ámbito", "Control", "Actividad", "Aplica o No",
                           "Resultado", "Sustento", "Evidencia", "Plan de acción"]
    # Fila A1: aplica = Sí; A2 (No aplicable): aplica = No.
    assert ws.cell(row=6, column=4).value == "Sí"
    assert ws.cell(row=7, column=4).value == "No"
    assert ws.cell(row=6, column=5).value == "No cumple"


def test_final_incluye_puntaje_validado():
    from modulos.exportador_excel import a_bytes
    from openpyxl import load_workbook
    data = a_bytes(_tabla(), {"modelo": "M", "tier": "I", "tipo": "final",
                              "score_global": 2.26, "score_final": 2.41})
    ws = load_workbook(io.BytesIO(data)).active
    assert "PUNTAJE FINAL" in str(ws["A3"].value)
    assert "2.41" in str(ws["A3"].value)


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
