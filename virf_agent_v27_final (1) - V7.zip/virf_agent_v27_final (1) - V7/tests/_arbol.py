# -*- coding: utf-8 -*-
"""
Ayudas para los tests que RECORREN el árbol del proyecto.

Por qué existe: varios tests filtraban los entornos virtuales por NOMBRE
(`venv`, `.venv`). Cualquier entorno con otro nombre dentro de la carpeta del
proyecto —`env/`, `.venv-3.11/`, un respaldo `.venv_respaldo/`— se escaneaba
como si fuera código propio y producía fallos falsos (medido el 2026-09-28: 7
tests en rojo por endpoints, `getenv` y ciclos de import de librerías de
terceros). Aquí se reconoce un entorno por su marca real, `pyvenv.cfg`, que es
el fichero que crea `python -m venv` en la raíz de todo entorno virtual.
"""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]


@lru_cache(maxsize=None)
def _es_entorno(carpeta: Path) -> bool:
    return (carpeta / "pyvenv.cfg").is_file()


def es_de_entorno_virtual(ruta: Path, raiz: Path = RAIZ) -> bool:
    """
    ¿`ruta` vive dentro de un entorno virtual (se llame como se llame) o de un
    `site-packages`? La raíz del proyecto no cuenta: solo sus subcarpetas.
    """
    ruta = Path(ruta)
    if "site-packages" in ruta.parts:
        return True
    for carpeta in ruta.parents:
        if carpeta == raiz:
            break
        if _es_entorno(carpeta):
            return True
    return False
