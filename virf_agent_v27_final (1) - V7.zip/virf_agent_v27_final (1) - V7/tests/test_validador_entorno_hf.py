# -*- coding: utf-8 -*-
"""
Guardia de la política «cero HuggingFace / cero ChromaDB» (validate_project.py).

Bug que fija: el chequeo del entorno usaba `import_module` dentro de un
`except: pass`, así que un paquete INSTALADO cuya importación revienta quedaba
invisible. Medido en el entorno real: `import chromadb` lanzaba
`ValueError: onnxruntime ... not installed` y chromadb salía como «limpio».

Se reproduce con un paquete falso que existe pero explota al importarse.
"""
import validate_project as vp


def test_paquete_instalado_pero_roto_se_reporta(tmp_path, monkeypatch):
    pkg = tmp_path / "paquete_roto_virf"
    pkg.mkdir()
    (pkg / "__init__.py").write_text(
        'raise ValueError("The onnxruntime python package is not installed")\n',
        encoding="utf-8")
    monkeypatch.syspath_prepend(str(tmp_path))
    monkeypatch.setattr(vp, "_PAQUETES_HF", ["paquete_roto_virf"])

    registros = []
    monkeypatch.setattr(vp, "check",
                        lambda nombre, estado, detalle="": registros.append(
                            (nombre, estado, detalle)))
    vp.val_sin_huggingface()

    entorno = [r for r in registros if r[0] == "entorno limpio de HuggingFace"]
    assert entorno, "el chequeo de entorno no se ejecutó"
    _, estado, detalle = entorno[0]
    assert estado == "WARN", f"un paquete instalado quedó como limpio: {entorno[0]}"
    assert "paquete_roto_virf" in detalle


def test_paquete_ausente_no_se_reporta(monkeypatch):
    monkeypatch.setattr(vp, "_PAQUETES_HF", ["paquete_que_no_existe_virf_xyz"])
    registros = []
    monkeypatch.setattr(vp, "check",
                        lambda nombre, estado, detalle="": registros.append(
                            (nombre, estado, detalle)))
    vp.val_sin_huggingface()
    entorno = [r for r in registros if r[0] == "entorno limpio de HuggingFace"]
    assert entorno and entorno[0][1] == "PASS"
