"""
tests/test_citas_deterministas.py — WP-03/WP-04 · indicador D4 (parte determinista).

Verifica el validador de citas con id de linaje (modulos/validador_citas.py) de
forma DETERMINISTA y SIN API: una afirmación factual solo se acepta si trae un
id [doc:pagina:chunk] bien formado cuyo chunk EXISTE en el contexto recuperado.
La verificación semántica (NLI) queda diferida y se comprueba que lo declara.
"""
from modulos.validador_citas import (
    extraer_ids,
    id_de_chunk,
    validar_afirmacion,
    verificar_afirmaciones,
    verificar_entailment,
)


def _contexto():
    return [
        {"fuente": "manual_var", "pagina": 12, "chunk": 3, "texto": "..."},
        {"fuente": "acta_comite", "pagina": "s/p", "chunk": 0, "texto": "..."},
    ]


def test_cita_determinista_bien_formada_y_localizable_se_acepta():
    ctx = _contexto()
    r = validar_afirmacion(
        'La ventana es de 250 días [manual_var:12:3].', ctx)
    assert r["aceptada"] is True
    assert r["ids_validos"] == ["[manual_var:12:3]"]


def test_cita_determinista_sin_cita_se_rechaza():
    r = validar_afirmacion("El modelo es correcto.", _contexto())
    assert r["aceptada"] is False
    assert r["tiene_cita"] is False


def test_cita_determinista_chunk_inexistente_se_rechaza():
    # chunk_id 9 no está en el contexto recuperado.
    r = validar_afirmacion("Afirmación dudosa [manual_var:12:9].", _contexto())
    assert r["aceptada"] is False
    assert r["ids_invalidos"] == ["[manual_var:12:9]"]


def test_id_de_chunk_se_construye_desde_las_claves_del_proyecto():
    assert id_de_chunk({"fuente": "manual_var", "pagina": 12, "chunk": 3}) == \
        "[manual_var:12:3]"
    # Sin página declarada → 's/p', nunca inventada.
    assert id_de_chunk({"fuente": "x", "chunk": 0}) == "[x:s/p:0]"
    # Sin chunk → no hay id (no se fabrica).
    assert id_de_chunk({"fuente": "x"}) is None


def test_extraer_ids_multiples():
    ids = extraer_ids("uno [a:1:0] dos [b:s/p:2] tres")
    assert ids == ["[a:1:0]", "[b:s/p:2]"]


def test_agregado_alimenta_tasa_para_d4():
    ctx = _contexto()
    afirmaciones = [
        "Bien [manual_var:12:3].",     # aceptada
        "Sin cita.",                    # rechazada
        "Mal [manual_var:99:9].",      # rechazada (chunk inexistente)
    ]
    r = verificar_afirmaciones(afirmaciones, ctx)
    assert r["total"] == 3
    assert r["aceptadas"] == 1
    assert abs(r["tasa_citas_validas"] - 1 / 3) < 1e-9


def test_entailment_esta_diferido_a_api():
    r = verificar_entailment("afirmación", "fragmento")
    assert r["estado"] == "NA-diferido"
    assert r["implica"] is None
