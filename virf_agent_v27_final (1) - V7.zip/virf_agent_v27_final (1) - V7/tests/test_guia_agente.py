"""
Guía del agente corporativo (scripts/generar_guia_agente.py + docs/agente_corporativo/).
Coste cero: sin IA y sin Word (el PDF no se genera en los tests).

Cubre:
  - Toda ruta de archivo citada en el conocimiento y las skills existe en el repo: una guía
    que manda al agente a un archivo inexistente le hace perder pedidos (límite 20/5).
  - Cada skill tiene las secciones que el agente necesita y su frontmatter.
  - Extracción del código: propósito sin repetir el nombre del archivo, endpoints anidados
    (FastAPI agrupa cada router en un `_IncludedRouter`), catálogo de tests.
  - El generador produce el .docx con todas las partes y una ficha por módulo.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parent.parent
GUIA = RAIZ / "docs" / "agente_corporativo"
sys.path.insert(0, str(RAIZ / "scripts"))

import generar_guia_agente as G  # noqa: E402

_EXT = (".py", ".md", ".js", ".html", ".css", ".json", ".xlsx", ".txt", ".jsonl")


def _docs_md() -> list[Path]:
    return [GUIA / "00_LEEME.md", GUIA / "CONOCIMIENTO_VIRF.md",
            *sorted((GUIA / "skills").glob("S*.md"))]


def _rutas_citadas(texto: str) -> set[str]:
    rutas = set()
    for token in re.findall(r"`([^`\s]+)`", texto):
        t = token.split("::")[0].rstrip(".,;:)")
        if "/" not in t or any(c in t for c in "<>{}*$") or t.startswith(("/api", "/ws", "http")):
            continue
        if t.endswith(_EXT) or t.endswith("/"):
            rutas.add(t)
    return rutas


@pytest.mark.parametrize("md", _docs_md(), ids=lambda p: p.name)
def test_rutas_citadas_existen(md):
    faltan = [r for r in sorted(_rutas_citadas(md.read_text(encoding="utf-8")))
              if not (RAIZ / r).exists()]
    assert not faltan, f"{md.name} cita rutas que no existen: {faltan}"


@pytest.mark.parametrize("md", sorted((GUIA / "skills").glob("S*.md")), ids=lambda p: p.name)
def test_skill_tiene_frontmatter_y_secciones(md):
    texto = md.read_text(encoding="utf-8")
    assert texto.startswith("---\nname: ") and "\ndescription: " in texto.split("---")[1]
    for seccion in ("## Qué subir", "## Cómo verificar"):
        assert seccion in texto or md.name.startswith(("S11", "S12")), f"{md.name}: falta «{seccion}»"


def test_hay_doce_skills_y_capturas():
    assert len(list((GUIA / "skills").glob("S*.md"))) == 12
    nombres = {p.stem for p in (GUIA / "capturas").glob("*.jpg")}
    assert {n for n, *_ in G.PANTALLAS} <= nombres


def test_proposito_salta_la_linea_que_repite_el_nombre():
    ruta = Path("modulos/pii.py")
    doc = "modulos/pii.py\n═══════\nEnmascara datos personales\nantes de enviarlos.\n\nOtro párrafo."
    assert G.proposito(doc, ruta) == "Enmascara datos personales antes de enviarlos."


def test_endpoints_incluye_los_routers_anidados():
    rutas = {e["ruta"] for e in G.endpoints()}
    assert len(rutas) >= 50
    assert {"/api/solo-informe/generar", "/api/auth/login", "/api/informe/consolidado"} <= rutas


def test_catalogo_de_tests_y_variables():
    tests = {Path(t["archivo"]).name: t for t in G.catalogo_tests()}
    assert tests["test_guia_agente.py"]["n"] >= 5
    variables = {v["var"] for v in G.variables_entorno()}
    assert {"IA_PROVEEDOR", "ANTHROPIC_API_KEY", "AZURE_OPENAI_DEPLOYMENT"} <= variables


def test_genera_el_docx_con_todas_las_partes(tmp_path):
    from docx import Document
    ruta = G.construir(tmp_path / "guia.docx")
    doc = Document(str(ruta))
    titulos = [p.text for p in doc.paragraphs if p.style.name.startswith("Heading")]
    for k in range(1, 13):
        assert any(t.startswith(f"Parte {k} ·") for t in titulos), f"falta la Parte {k}"
    fichas = [t for t in titulos if t.endswith(".py") and "/" in t]
    assert len(fichas) >= 100
    assert "modulos/plantilla_bcp.py" in fichas
    assert len(doc.inline_shapes) >= 20          # capturas de la interfaz y muestras de informes
