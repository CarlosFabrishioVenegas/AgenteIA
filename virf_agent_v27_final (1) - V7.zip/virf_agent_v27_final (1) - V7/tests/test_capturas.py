"""
Capturas de evidencia para los informes («pantallazos»). Coste cero: sin IA;
los PDF se generan al vuelo con Pillow y todo vive en `tmp_path`.

Cubre:
  - Localizar el documento citado por nombre (ignorando carpetas excluidas).
  - Extraer «archivo → "cita"» del texto de evidencia del agente.
  - PDF: página exacta con la cita resaltada; cita inexistente → sin captura
    (no se presenta una página equivocada como sustento).
  - Portada (primera página) y caché por contenido.
  - .md y código: líneas encontradas, contexto y números de línea reales.
  - Informe web: portada en Documentación (una sola vez) y capturas A/B de las
    contradicciones.
"""
from __future__ import annotations

from pathlib import Path

import pytest
from PIL import Image

from modulos import capturas as C

pypdfium2 = pytest.importorskip("pypdfium2")


def _pdf(ruta: Path, paginas: list[str]) -> Path:
    """PDF con texto real (no imagen) usando pypdfium2, una línea por página."""
    pdf = pypdfium2.PdfDocument.new()
    fuente = pypdfium2.raw.FPDFText_LoadStandardFont(pdf.raw, b"Helvetica")
    for texto in paginas:
        pagina = pdf.new_page(595, 842)
        obj = pypdfium2.raw.FPDFPageObj_NewTextObj(pdf.raw, b"Helvetica", 12.0)
        utf16 = (texto + "\x00").encode("utf-16-le")
        pypdfium2.raw.FPDFText_SetText(obj, (pypdfium2.raw.FPDF_WCHAR * (len(utf16) // 2))
                                       .from_buffer_copy(utf16))
        pypdfium2.raw.FPDFPageObj_Transform(obj, 1, 0, 0, 1, 60, 700)
        pypdfium2.raw.FPDFPage_InsertObject(pagina.raw, obj)
        pypdfium2.raw.FPDFPage_GenerateContent(pagina.raw)
    pypdfium2.raw.FPDFFont_Close(fuente)
    pdf.save(str(ruta))
    pdf.close()
    return ruta


@pytest.fixture
def docs(tmp_path):
    d = tmp_path / "inputs" / "documentacion"
    d.mkdir(parents=True)
    _pdf(d / "Manual.pdf", ["Portada del manual LaR", "Capitulo 1 introduccion general",
                            "La ventana historica es de 250 dias habiles"])
    (d / "seguimiento.md").write_text(
        "# Informe\n\nlinea dos\nRecalibracion adelantada al 2026-08-15.\nfin\n", encoding="utf-8")
    impl = tmp_path / "inputs" / "implementacion"
    impl.mkdir()
    (impl / "var.py").write_text("\n".join(f"x{i} = {i}" for i in range(1, 21))
                                 + "\nretornos = datos[-500:]\n", encoding="utf-8")
    (tmp_path / "inputs" / "rag").mkdir()
    (tmp_path / "inputs" / "rag" / "Manual.pdf").write_bytes(b"no")
    return tmp_path


def test_localizar_y_citas_en_evidencia(docs):
    raices = [docs / "inputs"]
    assert C.localizar("manual.PDF", raices).parent.name == "documentacion"   # no la de rag/
    assert C.localizar("no_existe.pdf", raices) is None
    assert C.localizar("y seguimiento.md", raices).name == "seguimiento.md"
    assert C.citas_en_evidencia('Manual.pdf → "La ventana historica" y seguimiento.md → '
                                '«Recalibracion adelantada»') == [
        ("Manual.pdf", "La ventana historica"), ("seguimiento.md", "Recalibracion adelantada")]


def test_pdf_pagina_exacta_resaltada(docs, tmp_path):
    pdf = docs / "inputs" / "documentacion" / "Manual.pdf"
    png, desc = C.captura_cita(pdf, "ventana historica es de 250 dias", tmp_path / "c")
    assert desc == "Manual.pdf · página 3"
    img = Image.open(png).convert("RGB")
    # Hay píxeles del resaltado (amarillo sobre blanco).
    amarillos = sum(1 for p in img.getdata() if p[0] > 240 and p[1] > 220 and p[2] < 200)
    assert amarillos > 50


def test_pdf_cita_inexistente_no_inventa_pagina(docs, tmp_path):
    pdf = docs / "inputs" / "documentacion" / "Manual.pdf"
    assert C.captura_cita(pdf, "Recalibracion anual obligatoria del modelo", tmp_path / "c") is None


def test_portada_y_cache(docs, tmp_path):
    pdf = docs / "inputs" / "documentacion" / "Manual.pdf"
    p1 = C.captura_portada(pdf, tmp_path / "c")
    assert p1 and p1.is_file()
    mtime = p1.stat().st_mtime
    assert C.captura_portada(pdf, tmp_path / "c") == p1 and p1.stat().st_mtime == mtime
    assert C.captura_portada(docs / "inputs" / "documentacion" / "seguimiento.md",
                             tmp_path / "c") is None


def test_md_y_codigo_con_contexto(docs, tmp_path):
    md = docs / "inputs" / "documentacion" / "seguimiento.md"
    png, desc = C.captura_cita(md, "Recalibracion adelantada al 2026-08-15", tmp_path / "c")
    assert desc == "seguimiento.md · líneas 4–4" and png.is_file()

    py = docs / "inputs" / "implementacion" / "var.py"
    png = C.captura_codigo("retornos = datos[-500:]", tmp_path / "c", archivo=py)
    assert png.is_file() and Image.open(png).height > 200      # con líneas de contexto
    solo = C.captura_codigo("a = 1\nb = 2", tmp_path / "c")
    assert solo.is_file()
    assert C.captura_codigo("   ", tmp_path / "c") is None


def test_informe_web_inserta_capturas(docs, tmp_path, monkeypatch):
    from docx import Document
    from web.services import informe_web
    monkeypatch.setattr(informe_web.chat_service, "sesion_activa", lambda ctx: None)
    ev_doc = {
        "actividad": "Control de versiones", "control": "Manual", "puntaje": 3,
        "observacion": "Sin control de cambios.",
        "evidencia_encontrada": 'Manual.pdf → "La ventana historica es de 250 dias habiles"',
        "inconsistencias": [{"severidad": "alta", "fuente_a": "Manual.pdf",
                             "cita_a": "La ventana historica es de 250 dias habiles",
                             "fuente_b": "var.py", "cita_b": "retornos = datos[-500:]",
                             "contradiccion": "El código usa 500."}]}
    ev_doc2 = {"actividad": "Objetivo y usos", "control": "Manual", "puntaje": 5,
               "observacion": "Completo.",
               "evidencia_encontrada": 'Manual.pdf → "Capitulo 1 introduccion general"'}
    datos = {"resultados_por_ambito": {"Documentación": [ev_doc, ev_doc2]}}
    ctx = {"outputs": tmp_path / "out", "inputs": docs / "inputs", "base": tmp_path,
           "clave": "T1/M", "modelo": {"nombre": "M", "slug": "M"},
           "validador": {"nombre": "Ana"}}
    ruta, _ = informe_web.generar(datos, "x.json", ctx)
    doc = Document(str(ruta))
    pies = [p.text for p in doc.paragraphs]
    assert "Portada del documento revisado — Manual.pdf" in pies
    assert sum(1 for t in pies if t.startswith("Portada del documento revisado")) == 1
    assert any(t.startswith("Portada de Manual.pdf: ver la captura en el control") for t in pies)
    assert "Evidencia — Manual.pdf · página 3" in pies
    assert "Sustento A — Manual.pdf · página 3" in pies
    assert "Sustento B — var.py" in pies
    assert len(doc.inline_shapes) >= 5          # logo ×2 + portada + evidencia + A + B…
    assert list((tmp_path / "out" / "capturas").glob("*.png"))
