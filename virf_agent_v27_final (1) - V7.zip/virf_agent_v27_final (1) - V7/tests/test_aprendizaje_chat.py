"""
tests/test_aprendizaje_chat.py — WP-D: el chat guarda correcciones como feedback
(contexto + ajuste automático en futuras corridas). Coste 0; historial aislado.
"""
import pytest


@pytest.fixture()
def feedback_aislado(tmp_path, monkeypatch):
    """Redirige el historial de feedback a un fichero temporal para no tocar el real."""
    import modulos.feedback as fb
    monkeypatch.setattr(fb, "FEEDBACK_PATH", tmp_path / "historial_feedback.json")
    return fb


def _datos():
    return {
        "modelo": "Modelo LaR (prueba)", "tier": "I",
        "agente": {"agente_version": "27.1"},
        "resultados_por_ambito": {"Metodología": [
            {"actividad": "Control de no-negativos", "puntaje": 2, "evaluacion_valida": True},
        ]},
    }


def test_aprobado_se_guarda_como_correccion(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "APROBADO", "hallazgo_final": "El validador aportó el manual v4.3",
            "adjuntos": ["manual_var.pdf"]}]
    r = fb.registrar_aprendizaje_desde_chat(_datos(), obs,
                                            {"validador": "QA", "cargo": "Val"}, sesion_id="s1")
    assert r["nuevos"] == 1
    hist = fb.cargar_historial()
    assert len(hist) == 1
    reg = hist[0]
    assert reg["puntaje_agente"] == 2 and reg["puntaje_correcto"] == 5
    assert reg["diferencia"] == 3
    assert "manual_var.pdf" in reg["comentario"]
    assert reg["origen"] == "chat_sustentacion"


def test_idempotente_por_sesion(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "APROBADO"}]
    fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    r2 = fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    assert r2["nuevos"] == 0            # no duplica
    assert r2["total"] == 1


def test_pendiente_no_se_aprende(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "PENDIENTE"}]
    r = fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    assert r["nuevos"] == 0


def test_la_correccion_entra_como_contexto_futuro(feedback_aislado):
    fb = feedback_aislado
    obs = [{"ambito": "Metodología", "actividad": "Control de no-negativos",
            "veredicto": "APROBADO", "hallazgo_final": "faltó reconocer el control de no-negativos"}]
    fb.registrar_aprendizaje_desde_chat(_datos(), obs, {}, sesion_id="s1")
    ctx = fb.construir_contexto_feedback("Metodología", "Control de no-negativos")
    assert "HISTORIAL DE FEEDBACK" in ctx
    assert "no-negativos" in ctx


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
