# Procedimiento de Validación Independiente de Modelos

**Sistema de apoyo:** VIRF Agent v27
**Anclajes normativos:** SR 11-7 (Federal Reserve/OCC) · EBA/GL/2023/01 · BCBS 239
**Fecha de emisión:** 2026-08-03 · **Última actualización:** 2026-08-12
**Estado:** VIGENTE — todos los apartados confirmados por la entidad

---

## 0. Cómo leer este documento — y su límite

Este procedimiento tiene tres clases de contenido, y **están marcadas para que
nadie las confunda**. La distinción no es un formalismo: un auditor comprobará
si lo que aquí se declara se cumple, y un procedimiento que afirme una política
que la entidad no ha adoptado es peor que su ausencia.

| Marca | Significado |
|---|---|
| ✅ **POLÍTICA CONFIRMADA** | Confirmado por la entidad el 2026-08-03. Exigible. |
| ⚙️ **CONTROL IMPLEMENTADO** | Descripción de lo que el sistema hace hoy, verificable en el código y por comando. No es una política: es una constatación. |
| ⛔ **PENDIENTE DE DEFINIR** | **La entidad no lo ha definido.** No se ha rellenado con un valor plausible a propósito. Hasta que se defina, este procedimiento NO cubre ese punto. |

> Los cinco apartados que estuvieron ⛔ en el borrador de 2026-08-03 (roles §1,
> umbral por ámbito §4.2, criterio de crítico §6, retención §8, doble firma §9)
> quedaron confirmados el 2026-08-12. No hay ⛔ abiertos.

---

## 1. Roles y segregación de funciones

✅ **POLÍTICA CONFIRMADA** (2026-08-12).

| Función | Rol | Línea |
|---|---|---|
| Prepara y aporta la evidencia | Dueño del modelo | 1ª línea |
| Ejecuta VIRF y firma el informe | Validador | 2ª línea de defensa |
| Aprueba | El propio firmante — **la firma es el acto de aprobación** | 2ª línea |

**Incompatibilidad estricta:** quien desarrolló el modelo **no puede firmar su
validación**, en ningún caso. No hay excepción por tamaño del equipo: cuando la
única persona disponible es el desarrollador, la validación se pospone o se
externaliza; no se firma. El sistema no puede comprobar esto por sí solo (no
sabe quién desarrolló qué); es responsabilidad del firmante declararlo antes
de ejecutar VIRF.

⚙️ **CONTROL IMPLEMENTADO** — lo que el sistema ya exige con independencia de
cómo se resuelva lo anterior:

- Ningún informe de producción se emite sin validador identificado: nombre y
  cargo son obligatorios con `--prdc` (`modulos/validador_humano.py`).
  Sin ellos la corrida se aborta; no hay informe anónimo posible.
- Cada firma queda en un registro acumulado
  (`feedback/registro_validadores.json`), consultable con
  `python agente.py --historial-validaciones`. Es la evidencia de rotación.
- Si la misma persona firma 3 informes consecutivos del mismo modelo, el
  informe incorpora un aviso de falta de segunda revisión. **Avisa, no
  bloquea**: en un equipo de 2-5 personas la rotación puede ser imposible en un
  periodo dado y bloquear impediría trabajar sin ofrecer remedio.
- Cada corrección del validador sobre un puntaje del agente queda firmada con su
  autor, y el anexo del informe muestra quién hizo cada una.

---

## 2. Alcance de la validación

⚙️ **CONTROL IMPLEMENTADO.**

VIRF **no valida las matemáticas del modelo**. Valida que la metodología esté
**documentada, justificada y coherente con la evidencia aportada**, contra el
estándar `inputs/Estandares_VIRF.xlsx`, en 6 ámbitos:

| Ámbito | Peso | Anclaje |
|---|---:|---|
| Metodología | 0.30 | SR 11-7 §IV — conceptual soundness |
| Calidad de datos | 0.20 | BCBS 239 principios 3-5 |
| Documentación | 0.15 | EBA/GL/2023/01 §6.3 |
| Implementación | 0.15 | SR 11-7 §IV — outcome analysis |
| Gobierno | 0.12 | EBA/GL/2023/01 §5 |
| Uso e integración | 0.08 | SR 11-7 §IV — ongoing monitoring |

**El agente produce un borrador. El dictamen lo firma una persona.** El informe
declara explícitamente el porcentaje de puntajes que el validador corrigió, para
que el supervisor pueda juzgar si hubo revisión efectiva o aceptación en bloque.

---

## 3. Periodicidad de revalidación

✅ **POLÍTICA CONFIRMADA.**

| Tier | Periodicidad |
|---|---|
| Tier 1 | **Anual** |
| Tier 2 | **Anual** |
| Tier 3 | **Bienal** |
| Tier 4 | **Bienal** |

**Revalidación anticipada**, con independencia del calendario, cuando concurra
cualquiera de estas circunstancias:

- cambio material en la metodología, en los datos de entrada o en la
  implementación del modelo;
- cambio material en el entorno de mercado, la cartera o el uso del modelo;
- deterioro detectado en el seguimiento continuo (p. ej. excepciones de
  backtesting fuera de umbral);
- hallazgo crítico abierto (§6);
- requerimiento del supervisor.

---

## 4. Criterios de aceptación y rechazo

✅ **POLÍTICA CONFIRMADA.** Escala 1-5.

| Score global | Resultado |
|---|---|
| **< 2.5** | **NO SE APRUEBA.** El modelo no puede usarse en producción hasta remediar y revalidar. |
| **2.5 – 3.5** | **APROBADO CON CONDICIONES.** Requiere plan de remediación con acciones, responsable y fecha. |
| **> 3.5** | **APROBADO.** |

**Reglas que acompañan al umbral:**

1. El score global es **condición necesaria, no suficiente**. Un hallazgo
   crítico (§6) impide la aprobación aunque el score global supere 3.5.
2. ✅ **Umbral por ámbito (2026-08-12):** un ámbito individual con score **< 2.5
   impide la aprobación**, aunque el score global supere 3.5. El razonamiento
   es simétrico al del §4: un ámbito hundido oculto tras un global aceptable es
   precisamente el caso en el que el promedio engaña. El sistema calcula y
   publica el score por ámbito; el firmante debe verificar esta condición antes
   de aprobar.
3. El validador puede apartarse del umbral **justificándolo por escrito** en el
   informe. La corrección queda registrada con su autor y aparece en el anexo:
   apartarse es admisible, hacerlo sin dejar rastro no.

---

## 5. Tratamiento de la falta de evidencia

⚙️ **CONTROL IMPLEMENTADO** — y es el invariante más importante del sistema.

**Ausencia de evidencia y fallo técnico son cosas distintas, con responsables
opuestos, y el informe SIEMPRE los distingue.**

| Causa | Responsable | Score | Efecto |
|---|---|---|---|
| **Sin evidencia** — no se aportó documentación | El validado | **0.0**, con su peso íntegro | «NO EVALUABLE — SIN EVIDENCIA» (rojo). Arrastra el score global. |
| **Fallo técnico** — timeout, PDF ilegible, JSON malformado | El agente | `None`, excluido | «NO EVALUABLE — FALLO TÉCNICO» (gris). Se renormaliza; no penaliza al validado. |

**La falta de evidencia es una falta crítica del validado y debe arrastrar el
score.** Lo inadmisible es (a) imputar al validado un fallo nuestro y (b) que el
informe no distinga una causa de la otra.

Reglas asociadas:

- **No se evalúa sobre el vacío.** Sin evidencia no se llama al modelo:
  preguntar a un LLM por un documento inexistente produce una alucinación con
  formato de dictamen.
- **No se inventa un puntaje.** Si el modelo no responde conforme al contrato
  JSON, la actividad queda sin puntaje y se reporta como fallo técnico. Nunca se
  rellena con un valor por defecto.
- **La cobertura declarada es la cobertura real.** Si solo se leyó el 30 % de un
  documento, el informe dice 30 %.

Antes de gastar, `python agente.py ... --prevuelo` (coste 0) informa de qué
ámbitos quedarían sin evidencia y sale con código 1 si hay alguno.

### 5.1 Forma de entrega de los notebooks

✅ **POLÍTICA CONFIRMADA** (2026-08-07).

**Los notebooks (`.ipynb`) se entregan ejecutados de arriba abajo**, mediante
`Restart & Run All`, **conservando sus salidas**.

Motivo: un notebook sin salidas es código entregado, **no evidencia de
ejecución**. No acredita que el cálculo se haya corrido nunca, y una validación
no puede dar por acreditado lo que no consta.

Consecuencias de esta política, que el análisis estático comprueba a coste 0
(`--analizar-codigo`, sin ejecutar nada):

| Situación en el `.ipynb` entregado | Hallazgo | Severidad |
|---|---|---|
| Ninguna celda ejecutada | `notebook_sin_ejecutar` | **alta** — incumple esta política |
| Algunas celdas sin ejecutar | `notebook_sin_ejecutar` | media |
| Una celda con traceback guardado | `notebook_con_excepcion` | **alta** |
| Contadores no crecientes (ejecutado a saltos) | `orden_ejecucion_roto` | **alta** |

`Restart & Run All` satisface las cuatro a la vez: garantiza que todas las
celdas corrieron, en el orden del documento, y que ninguna quedó con una
excepción sin resolver.

> **Nota de higiene de repo.** La sección de notebooks del `.gitignore` está
> rotulada «limpiar outputs antes de commitear». Es un comentario —la regla solo
> ignora `.ipynb_checkpoints/`—, pero **si se sigue a mano contradice esta
> política**. Prevalece este procedimiento: lo que se entrega como evidencia de
> validación va con sus salidas. Qué se commitea al repo del modelo es una
> cuestión distinta y ajena a este documento.

---

## 6. Escalado de hallazgos críticos

✅ **POLÍTICA CONFIRMADA.**

Un hallazgo crítico se eleva al **Comité de Riesgos en su siguiente sesión**,
con **copia inmediata al dueño del modelo** en el momento de su detección.

**Procedimiento:**

1. El validador marca el hallazgo como crítico en el informe.
2. Notificación inmediata al dueño del modelo (primera línea), sin esperar al
   cierre del informe.
3. Inclusión en el orden del día del Comité de Riesgos siguiente.
4. El Comité decide sobre restricción o suspensión del uso del modelo y fija el
   plan de remediación con responsable y fecha.
5. El hallazgo permanece **abierto** hasta que una revalidación acredite su
   cierre. Un hallazgo crítico abierto impide la aprobación (§4.1).

✅ **Criterio formal de hallazgo crítico (2026-08-12):** un hallazgo es
**crítico si el score del ámbito afectado es ≤ 2**. Es un criterio automático
y reproducible: dos validadores llegan a la misma clasificación sobre la misma
evidencia. El validador puede además marcar como crítico un hallazgo con score
> 2 justificándolo por escrito (p. ej. materialidad de la cartera); lo que no
puede es dejar sin marcar uno que cumpla el criterio automático.

---

## 7. Control del estándar de validación

✅ **POLÍTICA CONFIRMADA.**

`inputs/Estandares_VIRF.xlsx` **es la vara de medir**. Modificarlo cambia todos
los scores futuros y rompe la comparabilidad con los informes ya emitidos.

- **Quién puede modificarlo:** el **Responsable de Validación**.
- **Con qué aprobación:** **visto bueno del Comité de Riesgos**.
- Cada cambio se versiona y se documenta: qué cambió, por qué, y desde qué fecha
  aplica.

⚙️ **CONTROL IMPLEMENTADO:** cada informe incorpora la huella SHA-256 del
estándar con el que se evaluó. `python agente.py --comparar <MODELO>` (coste 0)
detecta si entre dos corridas **cambió la vara de medir** —estándar, modelo de
IA o versión del agente— y lo separa de los cambios en la evidencia. Sin esa
distinción, una caída de score por endurecer el estándar se leería como
deterioro del modelo.

---

## 8. Retención y custodia de informes

✅ **POLÍTICA CONFIRMADA** (2026-08-12).

**Plazo:** los informes y su evidencia asociada (documentos citados con su
huella, JSON de resultados, entregable Word y bloque de custodia) se conservan
**5 años desde la fecha de emisión** del informe. El cómputo es por informe, no
por modelo: un informe emitido en 2026 se conserva hasta 2031, con
independencia de si el modelo sigue vivo o se dio de baja antes.

Purgar un informe antes del plazo requiere autorización expresa del Responsable
de Validación y queda anotada en el registro de emisiones con motivo.

⚙️ **CONTROL IMPLEMENTADO** — la trazabilidad no depende de ese plazo:

**Cadena de custodia.** Cada informe lleva un bloque `custodia` con su hash
SHA-256, el hash del informe anterior del mismo modelo y un sello UTC de
generación que entra en el hash. Alterar un informe, insertarlo, borrarlo,
reordenarlo o manipular su fecha rompe la cadena en un punto identificable.

```bash
python agente.py --verificar-cadena "<MODELO>"      # ¿se alteró algún informe?
```

**Registro de emisiones (control preventivo).** `--verificar-cadena` opera sobre
los informes que existen: si se borra `outputs/`, no hay cadena que verificar.
Por eso cada emisión se anota además en un registro **append-only fuera de
`outputs/`** (`audit_logs/registro_emisiones.jsonl`), **versionado en git**.
Es la prueba de que un informe existió.

```bash
python agente.py --verificar-emisiones              # ¿falta algún informe emitido?
```

Un informe emitido y desaparecido se reporta como **AUSENTE** con su fecha y su
firmante, y el comando sale con código 1. Sin este registro, borrar la evidencia
era indistinguible de no haber validado nunca.

**Versión de la evidencia.** Cada informe congela el SHA-256 de cada documento
usado, y permite comprobar a posteriori si el manual citado cambió:

```bash
python agente.py --verificar-evidencia outputs/<fecha>/resultados_<modelo>_<fecha>.json
```

Un documento MODIFICADO **no invalida el informe**: demuestra que se emitió
sobre una versión anterior, que es el propósito de congelar la versión.

**Un árbol de evidencia = un modelo.** Se ejecuta con `--raiz-evidencia` para
que el informe de un modelo no pueda citar documentos de otro. La prueba es la
huella documental (`agente.documentos_huella`), no el volumen leído.

---

## 9. Aprobación de dos ojos (Tier 1)

⚙️ **CONTROL IMPLEMENTADO, DESACTIVADO POR DEFECTO.**

El sistema admite exigir **dos firmantes distintos** en los tiers que la entidad
declare:

```bash
VIRF_DOBLE_FIRMA_TIER=1     # Tier 1 exige segunda firma. Vacío = desactivado.
```

- El segundo firmante **debe ser una persona distinta**; la comparación
  normaliza mayúsculas, espacios y acentos, de modo que la misma persona no
  puede firmar las dos casillas escribiendo su nombre de dos maneras.
- **Bloquea la emisión**, a diferencia del aviso de §1. La divergencia es
  deliberada: la doble firma tiene remedio inmediato (que el segundo firme
  ahora), es opt-in, y en Tier 1 un aviso ignorable produciría un informe que
  *parece* aprobado por dos personas. El razonamiento completo está en
  `config/parametros.py`.
- Vía no interactiva disponible (`--validador-2/--cargo-2` o
  `VIRF_VALIDADOR_2/VIRF_VALIDADOR_2_CARGO`), para que las corridas
  automatizadas puedan emitir.
- Ambas firmas viajan al JSON y a la hoja de aprobación del Word, con una línea
  de firma por persona.

✅ **DECISIÓN CONFIRMADA (2026-08-12): la doble firma Tier 1 se mantiene
DESACTIVADA.** El control queda construido, probado y listo para activarse en
una línea (`VIRF_DOBLE_FIRMA_TIER=1`) si el equipo crece o el supervisor lo
requiere. Motivo de la decisión: con un equipo de 2-5 personas y la
incompatibilidad estricta de §1, exigir dos firmas distintas en Tier 1 podría
bloquear emisiones sin remedio inmediato. La combinación §1 (incompatibilidad
estricta) + §4 (umbral por ámbito) + §6 (criterio automático de crítico) da
segregación material sin depender de esta segunda firma.

---

## 10. Limitación conocida: el corpus de referencia

⚙️ **CONSTATACIÓN, no política.**

`inputs/rag/` contiene documentos de apoyo **generados a partir de marcos
públicos: no son los textos oficiales.** Cada uno lo declara en portada, pie y
dentro de su texto indexable, y los umbrales numéricos (recortes del LCR,
sublímites de Nivel 2B, plazos de repreciación de NMD) se dejaron
deliberadamente **sin cifra**, remitiendo al texto oficial.

**Ningún dictamen debe sustentarse en un fragmento recuperado sin contrastarlo
contra la fuente primaria.** La responsabilidad es de quien firma.

Estado verificable en cualquier momento, a coste 0:

```bash
python scripts/verificar_corpus_rag.py
python scripts/verificar_corpus_rag.py --informe outputs/<fecha>/resultados_<modelo>_<fecha>.json
```

Comprueba procedencia (oficial vs. resumen), cobertura, **contaminación cruzada
entre dominios** y recuperación efectiva; con `--informe`, que el RAG llegó
realmente al prompt (`rag_chunks > 0`).

**Cierre de la limitación:** sustituir los PDF por los oficiales (BCBS
238/239/295/457, SR 11-7, EBA/GL, TRIM Guide), reindexar con
`force_rebuild=True` y volver a ejecutar el verificador.

---

## 11. Verificación del propio sistema

Antes de dar por bueno cualquier informe, el sistema debe estar íntegro. Ambas
comprobaciones tienen **coste cero** y puede ejecutarlas el propio auditor:

```bash
python validate_project.py --strict     # 148 comprobaciones de integridad
python -m pytest -q                     # 835 tests
```

Que un auditor pueda ejecutarlas es parte de la evidencia: demostrar que los
controles están implementados no debería requerir creernos.

---

## 12. Registro de cambios de este procedimiento

| Fecha | Cambio | Responsable |
|---|---|---|
| 2026-08-03 | Emisión inicial. Confirmados §3, §4, §6, §7. Pendientes §1, §8 y los puntos marcados ⛔. | Responsable de Validación |
| 2026-08-07 | Añadido §5.1: los notebooks se entregan ejecutados de arriba abajo (`Restart & Run All`), con sus salidas. | Responsable de Validación |
| 2026-08-08 | Añadida la política del tope 3 de puntaje sobre tolerancia declarada cero (motores de calidad de datos de la entidad). Registrado en el commit `f0bffc0`. | Responsable de Validación |
| 2026-08-12 | Cerrados los cinco ⛔ del borrador: §1 roles y segregación con incompatibilidad estricta; §4.2 umbral por ámbito < 2.5 bloqueante; §6 criterio automático de crítico (score de ámbito ≤ 2); §8 retención de 5 años desde emisión; §9 doble firma Tier 1 confirmada como desactivada. | Responsable de Validación |

---

## Anexo — Historial de apartados cerrados

Los seis apartados que estaban ⛔ o «pendiente de asignar» en el borrador de
2026-08-03 quedaron confirmados el 2026-08-12. Se conservan aquí para
trazabilidad de la evolución del procedimiento.

| # | Apartado | Cerrado | Resultado |
|---|---|---|---|
| 1 | §1 Roles y segregación | 2026-08-12 | Validador de 2ª línea firma y aprueba; incompatibilidad estricta con el desarrollador. |
| 2 | §8 Plazo de retención | 2026-08-12 | 5 años desde la emisión del informe. |
| 3 | §6 Criterio de «hallazgo crítico» | 2026-08-12 | Automático: score de ámbito ≤ 2. |
| 4 | §4.2 Umbral por ámbito | 2026-08-12 | Ámbito < 2.5 impide aprobación. |
| 5 | §9 Doble firma Tier 1 | 2026-08-12 | Se mantiene DESACTIVADA (decisión, no omisión). |
| 6 | §12 Responsable del procedimiento | 2026-08-12 | Responsable de Validación. |
