# VIRF Agent — Catálogo completo de funcionalidades

> Referencia de **todo lo que el agente sabe hacer**, flag por flag, verificada contra
> el `argparse` de `agente.py:164-191` y el código de cada módulo que ejecuta.
> Fecha de verificación: **2026-07-30**. Versión del agente: `27.1` (`VIRF_AGENTE_VERSION`).
>
> Documentos hermanos:
> · **`RUNBOOK.md`** — el flujo operativo paso a paso, con los criterios de
>   parada de cada fase. Empieza por ahí si vas a validar un modelo.
> · **`FLAGS.md`** — manual de referencia de la CLI: ficha por flag, precedencia de modos,
>   matriz de compatibilidad, códigos de salida y asimetrías entre pipelines.
> · `README.md` — instalación, configuración, arquitectura y changelog de auditoría.
> · `METODOLOGIA_DEL_AGENTE.md` — el criterio de validación (la "vara de medir").
> · `GUIA_MULTIMODELO_Y_RAG.md` — evidencia multimodelo y RAG por dominio.
> · `GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md` — cambio de proveedor IA.

---

## Índice

1. [Cómo leer este documento](#1-cómo-leer-este-documento)
2. [Los 26 flags de un vistazo](#2-los-26-flags-de-un-vistazo)
3. [Orden real de despacho en `main()`](#3-orden-real-de-despacho-en-main)
4. [Los tres pipelines de evaluación](#4-los-tres-pipelines-de-evaluación)
   - 4.1 [Pipeline completo — `--titulo` + `--tier`](#41-pipeline-completo--titulo--tier)
   - 4.2 [Pipeline por control — `--control`](#42-pipeline-por-control--control)
   - 4.3 [Explicador de modelos — `--explicar-modelo`](#43-explicador-de-modelos--explicar-modelo)
5. [Cumplimiento regulatorio (4 funcionalidades)](#5-cumplimiento-regulatorio)
   - 5.1 [`--validador` / `--cargo`](#51---validador--y---cargo--firma-humana-obligatoria)
   - 5.2 [`--verificar-cadena`](#52---verificar-cadena--integridad-de-la-cadena-de-custodia)
   - 5.3 [`--verificar-evidencia`](#53---verificar-evidencia--los-documentos-citados-siguen-intactos)
   - 5.4 [`--historial-validaciones`](#54---historial-validaciones--quién-firmó-qué-y-cuándo)
6. [Feedback y aprendizaje](#6-feedback-y-aprendizaje)
7. [Motor de datos](#7-motor-de-datos)
8. [Ingeniería inversa Excel → Notebook](#8-ingeniería-inversa-excel--notebook)
9. [Documento de controles → Notebook + brechas](#9-documento-de-controles--notebook--brechas)
10. [Caché de documentos y resúmenes](#10-caché-de-documentos-y-resúmenes)
11. [Chunking de documentos largos](#11-chunking-de-documentos-largos)
12. [Multimodelo — `--raiz-evidencia`](#12-multimodelo----raiz-evidencia)
13. [RAG por dominio financiero](#13-rag-por-dominio-financiero)
14. [Proveedor IA y `--verificar-conexion-azure`](#14-proveedor-ia-y---verificar-conexion-azure)
15. [Defensas anti-alucinación y anti-error](#15-defensas-anti-alucinación-y-anti-error)
16. [Salidas del sistema](#16-salidas-del-sistema)
17. [Scripts auxiliares](#17-scripts-auxiliares)
18. [Verificación del proyecto y tests](#18-verificación-del-proyecto-y-tests)
19. [Variables de entorno — referencia completa](#19-variables-de-entorno--referencia-completa)
20. [Recetas de uso](#20-recetas-de-uso)

---

## 1. Cómo leer este documento

Cada funcionalidad se documenta con la misma plantilla:

| Campo | Significado |
|---|---|
| **Qué hace** | El efecto observable |
| **Cuándo usarlo** | El escenario real que lo justifica |
| **Sintaxis** | Comando ejecutable, copiable |
| **Requiere API** | Si consume tokens (= dinero) o es coste 0 |
| **Salidas** | Ficheros que produce y dónde |
| **Código** | `fichero:línea` donde vive la lógica |

**Aclaración sobre `--feedback`:** ese flag **no existe**. El feedback opera de dos
maneras: (a) un **bucle interactivo automático** al final de toda corrida que no use
`--prdc` (`agente.py:1227`), y (b) el flag `--estadisticafeedback` para ver la precisión
acumulada. Detalle en §6.

---

## 2. Los 26 flags de un vistazo

### Grupo A — Evaluación (los que emiten dictamen)

| Flag | Tipo | Requiere API | Qué hace |
|---|---|:---:|---|
| `--titulo NOMBRE` | valor | — | Nombre del modelo. Rotula el informe, infiere el dominio RAG y da nombre al fichero de salida (saneado con `nombre_seguro()`). Obligatorio en ambos pipelines. |
| `--tier {1,2,3,4}` | valor | — | Tier del modelo. Filtra qué actividades del estándar son exigibles. Acepta `1-4` o `I-IV`. Un tier inválido se **rechaza antes de gastar** (`agente.py:622`). |
| `--control` | switch | ✅ | Activa el **pipeline por CONTROL** (Calidad de Datos, guiado por Excel). Exige `--excel`. |
| `--excel RUTA` | valor | — | Ruta al Excel de controles. Obligatorio con `--control`; opcional en `--controles-a-notebook` (ahí sirve de referencia para el análisis de brechas). |
| `--prdc` | switch | ✅ | **Modo producción**: genera el Word entregable, exige firma humana, registra la aprobación y **desactiva el bucle de feedback**. |
| `--datasets RUTA` | valor | — | Carpeta de datasets (`.csv`/`.parquet`/`.xlsx`) para el motor de datos. Default: `inputs/calidad_datos/datasets/`. |
| `--raiz-evidencia RUTA` | valor | — | Raíz alternativa que contiene `inputs/`. **Un modelo por raíz** — evita contaminación cruzada de evidencia. |

### Grupo B — Documentación automática

| Flag | Tipo | Requiere API | Qué hace |
|---|---|:---:|---|
| `--explicar-modelo NOMBRE` | valor | ✅ (salvo `--dry-run`) | Genera `explicacion_del_modelo_<NOMBRE>.md` consolidando las 4 fuentes de `inputs/` en 9 secciones fijas. |
| `--dry-run` | switch | ❌ | Con `--explicar-modelo`: muestra inventario de evidencia + coste estimado **sin llamar al modelo**. |
| `--excluir F1,F2` | valor | — | Con `--explicar-modelo`: ficheros a omitir (p. ej. fixtures de test que viven en `inputs/`). |
| `--solo-coincidentes` | switch | — | Con `--explicar-modelo`: usa SOLO ficheros cuyo nombre contiene el modelo. Por defecto se incluye todo, para no descartar evidencia en silencio. |

### Grupo C — Cumplimiento regulatorio

| Flag | Tipo | Requiere API | Qué hace |
|---|---|:---:|---|
| `--validador NOMBRE` | valor | — | Nombre del validador responsable. **Obligatorio en `--prdc`** (o vía `VIRF_VALIDADOR`, o preguntado por consola). |
| `--cargo CARGO` | valor | — | Cargo del validador. Obligatorio en `--prdc`. |
| `--verificar-cadena MODELO` | valor | ❌ | Verifica la integridad de la cadena de custodia de todos los informes del modelo. Sale con código 0/1. |
| `--verificar-evidencia INFORME.JSON` | valor | ❌ | Comprueba si los documentos citados por un informe siguen intactos. Sale con código 0/1. |
| `--historial-validaciones` | switch | ❌ | Lista, por validador, qué modelos aprobó y cuándo. |

### Grupo D — Motor de datos y notebooks

| Flag | Tipo | Requiere API | Qué hace |
|---|---|:---:|---|
| `--listar-motores` | switch | ❌ | Catálogo de las 8 pruebas de calidad de datos disponibles y sale. |
| `--convertir-excel CARPETA` | valor | ✅ (salvo `--sin-llm`) | Ingeniería inversa: cada `.xlsx`/`.xlsm` de la carpeta → un `.ipynb` ejecutable con VBA traducido, refs externas y auto-validación. |
| `--controles-a-notebook DOC` | valor | ✅ (salvo `--sin-llm`) | Lee un documento en prosa (`.docx`/`.pdf`/`.md`) que describe controles, genera `.ipynb` ejecutable y **análisis de brechas** contra el Excel. |
| `--sin-llm` | switch | — | Modo estructural sin IA para los dos flags anteriores. |
| `--sin-validacion` | switch | — | Con `--convertir-excel`: omite la auto-validación notebook vs Excel. |

### Grupo E — Feedback, caché y diagnóstico

| Flag | Tipo | Requiere API | Qué hace |
|---|---|:---:|---|
| `--estadisticafeedback` | switch | ❌ | Métricas de precisión del agente (MAE, sesgo, % exactos) + informe Excel. |
| `--cache-stats` | switch | ❌ | Estadísticas del caché de documentos. |
| `--limpiar-cache` | switch | ❌ | Borra el caché de documentos **y** el de resúmenes de chunking. |
| `--no-cache` | switch | — | Desactiva el caché para esta corrida. |
| `--verificar-conexion-azure` | switch | ✅ (1 llamada mínima) | Prueba de humo del proveedor activo: credenciales, modelo real del deployment, perfil de chunking y parseo de JSON. |

---

## 3. Orden real de despacho en `main()`

Importa, porque determina qué se puede hacer **sin API** y qué se cobra. Secuencia exacta
(`agente.py:193-1249`):

```
  1. parse_args()
  2. Inicializar caché  ......................  agente.py:208
  3. atexit.register(cerrar_cache)  ..........  agente.py:218   ← persiste aunque haya sys.exit()
  4. Resolver --raiz-evidencia  ..............  agente.py:232   ← ANTES de cualquier rama de modo
  ────────── modos de auditoría, coste 0 ──────────
  5. --verificar-cadena       → sys.exit(0|1)
  6. --verificar-evidencia    → sys.exit(0|1)
  7. --historial-validaciones → return
  8. --verificar-conexion-azure → return       ← hace su propia validación
  9. --listar-motores         → return
  ────────── PRE-FLIGHT de API key ──────────      agente.py:320-375
 10. Se SALTA para: --estadisticafeedback, --limpiar-cache, --cache-stats,
     --listar-motores, --historial-validaciones, --verificar-cadena,
     --verificar-evidencia, --verificar-conexion-azure,
     (--explicar-modelo + --dry-run), (--convertir-excel + --sin-llm)
 11. --explicar-modelo       → return
 12. --limpiar-cache         → return
 13. --cache-stats           → return
 14. --convertir-excel       → return
 15. --controles-a-notebook  → return
 16. --estadisticafeedback   → return
 17. --control               → pipeline por control → return
 18. (default)               → pipeline completo
```

Dos decisiones de diseño que conviene entender:

**`atexit` en el paso 3.** El `try/finally` que persiste el caché está al final de `main()`,
después de **ocho `return` tempranos**. Cualquier modo que saliera antes leía documentos y
tiraba lo cacheado (medido: `--explicar-modelo` leía 5 documentos y persistía 0).
`atexit` cubre tanto los `return` como los `sys.exit()`.

**Los modos de auditoría antes del PRE-FLIGHT.** Verificar la integridad de un informe ya
emitido no debe depender de tener crédito ni conexión: un auditor puede necesitar comprobar
la cadena mucho después de que la clave haya caducado.

---

## 4. Los tres pipelines de evaluación

### 4.1 Pipeline completo — `--titulo` + `--tier`

**Qué hace.** Evalúa el modelo contra **los 6 ámbitos** del estándar VIRF
(`inputs/Estandares_VIRF.xlsx`), filtrando las actividades exigibles por tier, y produce un
score global ponderado con semáforo.

**Cuándo usarlo.** Validación integral de un modelo. Es la ruta insignia del agente.

**Sintaxis.**
```bash
# Pre-producción (con bucle de feedback al final)
python agente.py --titulo "Modelo LaR" --tier 1

# Producción (genera Word, exige firma)
python agente.py --titulo "Modelo LaR" --tier 1 --prdc \
                 --validador "Ana Pérez" --cargo "Validador de Segunda Línea"
```

**Requiere API.** ✅ Sí, es la corrida más costosa (una llamada por actividad + chunking).

**Los 6 ámbitos y sus pesos** (`config/dominio.py:AMBITO_PESOS`, suman exactamente 1.00):

| Ámbito | Peso | Referencia normativa (`AMBITO_PESOS_REFS`) |
|---|---:|---|
| Metodología | 0.30 | SR 11-7 §IV *conceptual soundness* |
| Calidad de datos | 0.20 | BCBS 239 principios 3-5 |
| Documentación | 0.15 | EBA/GL/2023/01 §6.3 |
| Implementación | 0.15 | SR 11-7 §IV *outcome analysis* |
| Gobierno | 0.12 | EBA/GL/2023/01 §5 |
| Uso e integración a la gestión | 0.08 | SR 11-7 §IV *ongoing monitoring* |

> Las claves deben coincidir **con tildes y mayúsculas** entre `AMBITO_PESOS`, el Excel de
> estándares, `AMBITO_A_INPUTS` y `PREGUNTAS_METODOLOGICAS`. Un desajuste de tilde rompe el
> pipeline en silencio; lo verifican `validate_project.py` (bloque 4) y el test
> `test_ambitos_coinciden_en_los_cuatro_sistemas`.

**La escala de puntaje** (`config/dominio.py:ESCALA_PUNTAJE`):

| Puntaje | Etiqueta |
|:---:|---|
| 5 | Cumple plenamente |
| 4 | Cumple con observaciones menores |
| 3 | Cumple parcialmente |
| 2 | Cumple parcialmente — obs. críticas |
| 1 | No cumple |

**El semáforo del score global** (`config/dominio.py:SCORE_SEMAFORO`):

| Rango | Dictamen |
|---|---|
| 4.5 – 5.0 | **SATISFACTORIO** |
| 3.5 – 4.5 | **ACEPTABLE** |
| 2.5 – 3.5 | **CON OBSERVACIONES** |
| 1.5 – 2.5 | **DEFICIENTE** |
| 0.0 – 1.5 | **CRÍTICO** |

> Un `score_global = None` **no** es `CRÍTICO`: significa que nada fue evaluable. Ver §15.

**Flujo interno, paso a paso** (`agente.py:664-1240`):

1. **Cargar estándares** filtrados por tier → `leer_estandares_virf(tier)`.
2. **Cargar evidencia** de todo `inputs/` → `cargar_todos_inputs()`.
3. **Chunking en lote** de los documentos largos → `ChunkerService.procesar_lote()`.
4. **Por cada ámbito:**
   - Seleccionar sus documentos (`inputs_para_dimension`).
   - Llenar el contexto hasta `VIRF_MAX_CTX`, avisando de saturación.
   - Calcular la **cobertura documental real** ponderada por tamaño original.
   - Si no hay documentos → **rechazar la evaluación** (D3-FIX, §15).
   - Evaluar con `evaluar_ambito_completo()`, pasándole la memoria inter-ámbito
     (`hallazgos_globales`) y la cobertura real.
5. **Fusionar controles CDD** de `ControlesData.xlsx` en el ámbito "Calidad de datos",
   calibrando el puntaje por tasa de error (tabla abajo).
6. **Score global** ponderado + semáforo.
7. **Sellado de cadena de custodia** y escritura del JSON.
8. Si `--prdc`: resumen ejecutivo → Word → registro de la aprobación → señal interna de
   calidad del proceso.
9. **Reporte de integridad** (evaluadas OK / sin evidencia / fallos técnicos).
10. Si no `--prdc`: **bucle de feedback** interactivo.

**Calibración de los controles CDD integrados** (`agente.py:857-882`). Antes era
`OK→4, ADVERTENCIA→3, ERROR→1` hardcodeado. Ahora el puntaje depende del estado **y** de la
tasa de error cuantificada:

| Estado | Tasa de error | Puntaje |
|---|---|:---:|
| `OK` | — | 5 |
| `ADVERTENCIA` / `ALERTA` | < 0.5 % | 4 |
| `ADVERTENCIA` / `ALERTA` | 0.5 – 2 % | 3 |
| `ADVERTENCIA` / `ALERTA` | 2 – 10 % | 2 |
| `ADVERTENCIA` / `ALERTA` | > 10 % | 1 |
| `ADVERTENCIA` (sin tasa) | — | 3 |
| `ALERTA` (sin tasa) | — | 2 |
| `ERROR` / desconocido | — | 1 |

Cada decisión se imprime en consola: `CDD [C-01] estado=ALERTA tasa=0.031 → puntaje=2`.

**Salidas.**
- `outputs/<fecha>/resultados_<modelo>_<fecha>.json` — siempre.
- `outputs/<fecha>/VIRF_Informe_*.docx` — solo con `--prdc`.
- `outputs/<fecha>/calidad_proceso_*.json` — solo con `--prdc`, **uso interno**.

**Código.** `agente.py:616-1249`, `modulos/motor_ia.py`, `motor/Mx_00`–`Mx_04`.

---

### 4.2 Pipeline por control — `--control`

**Qué hace.** Evalúa control por control, guiado por `ControlesData.xlsx`, en lugar de por
ámbito. Cada fila del Excel es un control con su prompt, y opcionalmente una prueba
ejecutable del motor de datos.

**Cuándo usarlo.** Validación específica de **Calidad de Datos**, cuando el alcance está
definido como una lista de controles y no como los 6 ámbitos.

**Sintaxis.**
```bash
python agente.py --titulo "Modelo LaR" --tier 1 \
                 --excel inputs/calidad_datos/ControlesData.xlsx --control

# Con datasets propios y en producción
python agente.py --titulo "Modelo LaR" --tier 1 \
                 --excel inputs/calidad_datos/ControlesData.xlsx --control \
                 --datasets data/extractos_2026Q2 --prdc
```

**Contrato de `ControlesData.xlsx`** (`motor/Mx_04_MotorControlesData.py:187` y
`modulos/motor_ia_v2.py:405`):

| Columna | Obligatoria | Para qué |
|---|:---:|---|
| `ID_CONTROL` | ✅ | Identificador del control. Sin él la fila se omite con aviso. |
| `PROMPT_CONTROL` (o `PROMPT`) | ✅ | Qué debe verificar el agente. Sin él la fila se omite. |
| `USA_MOTOR_DATA` | — | `1` activa la prueba ejecutable sobre el dataset. |
| `TIPO_MOTOR` | si `USA_MOTOR_DATA=1` | Nombre de la prueba (ver §7). |
| `DATASET` | si `USA_MOTOR_DATA=1` | Nombre del dataset cargado desde `--datasets`. |
| `GROUP_COLS` | según la prueba | Columnas de agrupación, separadas por comas. |
| `CAMPO_OBJETIVO` | según la prueba | Columna que se evalúa. |
| `UMBRAL` | — | Tolerancia. Ej.: `UMBRAL=1` en unicidad = "tolero como máximo 1 grupo incumplidor". |
| `ACCION` | — | Acción esperada ante el hallazgo. |
| `CONTROL` | — | Agrupador. **Opcional** por diseño (`TestAuditoriaColumnaControlOpcional`). |

**Carga de datasets** (`agente.py:552-566`). Antes se pasaba `datasets_dict=None` **siempre**,
así que los controles con `USA_MOTOR_DATA=1` nunca ejecutaban su prueba: el Excel declaraba
`DATASET='data_subset'` y nadie lo cargaba. Ahora se cargan de `--datasets` (o del default) y
se imprime la forma de cada uno:

```
  📊 Datasets cargados desde datasets/: ['data_subset', 'maestro_clientes']
       data_subset: 48,213 filas x 17 columnas
```

Si no hay datasets, se avisa explícitamente de que los controles con motor no podrán ejecutarse.

**Salida en consola — el campo que importa:**

```
  📊 RESULTADOS:
    • Controles evaluados: 12/14
    • Controles con error: 0
    • Sin evidencia:       2  (falta documentación, no es un fallo)
    • Hallazgos críticos:  3
    • Estado:              CON_HALLAZGOS
    • Dictamen confiable:  True
```

`dictamen_confiable` es la señal de gobierno: si es `False`, **no se debe emitir dictamen**
porque la evaluación está incompleta. "Sin evidencia" se muestra **aparte** de "con error"
porque una corrida sin documentos no es una corrida rota.

**Código.** `agente.py:527-611` → `modulos/motor_ia_v2.orquestar_pipeline_virf()`.

---

### 4.3 Explicador de modelos — `--explicar-modelo`

**Qué hace.** Consolida las **cuatro fuentes** de `inputs/` en un único documento Markdown de
**9 secciones fijas** que permite entender un modelo cuantitativo sin leer su código.

**Cuándo usarlo.** Cuando alguien —humano o otro modelo de IA— necesita entender el modelo:
onboarding de un validador nuevo, preparación de un comité, o alimentar a otro agente.

**Las 4 fuentes** (`modulos/explicador_modelo.py:FUENTES`). El orden refleja la secuencia
natural *qué hace → cómo se vigila → cómo se ejecuta → con qué datos*:

| Fuente | Ruta | Qué aporta |
|---|---|---|
| Manual metodológico | `inputs/documentacion/modelamiento` | problema que resuelve, supuestos, fórmulas, marco teórico, referencias normativas |
| Seguimiento | `inputs/documentacion/seguimiento` | backtesting, tests estadísticos, umbrales de alerta, periodicidad, escalamiento |
| Implementación | `inputs/implementacion` | código o arquitectura real: funciones, stack, orquestación, controles de ejecución |
| Calidad de datos | `inputs/calidad_datos` | fuentes de datos, controles ejecutados, tolerancias, transformaciones previas |

**Las 9 secciones del documento generado:**

1. Resumen en una página
2. Marco metodológico
3. El motor de datos — de dónde vienen los números
4. El modelo — función por función
5. Flujo completo — de principio a fin
6. Seguimiento y monitoreo en producción
7. Limitaciones y supuestos frágiles
8. Glosario
9. Preguntas abiertas

La presencia de las 9 se **verifica programáticamente** tras generar
(`ExplicadorModelo.verificar()`, `explicador_modelo.py:549`): si el modelo omite una sección,
se detecta en vez de entregar un documento incompleto.

**Sintaxis.**
```bash
# Inventario + coste estimado, SIN gastar un token
python agente.py --explicar-modelo "LaR" --dry-run

# Generar de verdad
python agente.py --explicar-modelo "LaR"

# Excluyendo fixtures de test que viven en inputs/
python agente.py --explicar-modelo "LaR" --excluir perfil_datos_VaR.md,manual_VaR_FRTB.md

# Varios modelos comparten inputs/: usar solo los ficheros que nombran al modelo
python agente.py --explicar-modelo "PD_Retail" --solo-coincidentes

# Un modelo en su propia raíz (recomendado, ver §12)
python agente.py --explicar-modelo "VaR_FRTB" --raiz-evidencia modelos/VaR_FRTB
```

**Las tres defensas anti-invención.** Un documento así es peligroso si rellena huecos:
parece riguroso y no lo es.

1. **Inventario previo.** Antes de llamar al modelo se construye el inventario de qué fuente
   aportó qué ficheros, y se escribe **dentro** del documento. El lector siempre sabe sobre
   qué evidencia se apoya lo que lee.
2. **Fuentes vacías explícitas.** Si una de las cuatro fuentes no aporta nada, no se disimula:
   se marca en el inventario y el prompt obliga a escribir `⚠️ Sin evidencia en fuentes` en
   las secciones afectadas.
3. **Discrepancias sin reconciliar.** Si el manual dice una cosa y la implementación otra, el
   prompt exige **señalarlo** en vez de elegir una de las dos.

**El catálogo de supuestos vigilados** (`_SUPUESTOS_VIGILADOS`, `explicador_modelo.py:110+`).
Antes, la única instrucción sobre supuestos frágiles era una línea del prompt ("marca lo que
te parezca cuestionable"). Funcionaba con LaR porque su manual declara sus propios supuestos
—eso no es cobertura, es suerte. En un scorecard nadie escribe "asumo estabilidad
poblacional": el supuesto es tácito, y lo que no está escrito no se detecta improvisando.

El catálogo declara familias de modelo con su **disparador** y su lista de supuestos a
vigilar. Por ejemplo, `series_temporales` vigila estacionariedad (ADF/KPSS), autocorrelación
de residuos (Ljung-Box), heterocedasticidad, normalidad (Jarque-Bera) y justificación de la
ventana de estimación.

**Es agnóstico al modelo por construcción:** el catálogo **no clasifica** el modelo con
heurísticas de palabras clave (fallaría con un híbrido o con un manual que use otro
vocabulario). Se entrega **entero** al modelo junto con la evidencia, exigiéndole aplicar solo
las familias cuyo disparador esté realmente presente y callar sobre las demás. La decisión la
toma quien lee la evidencia. Añadir una familia nueva es añadir una entrada al diccionario;
la lógica de `generar()` no se toca.

**Coste.** Reutiliza `ChunkerService` con su caché de resúmenes: un manual largo se resume una
vez y las regeneraciones posteriores no vuelven a pagarlo. `--dry-run` es coste 0.

**Salida.** `outputs/<fecha>/explicacion_del_modelo_<NOMBRE>.md`

**Código.** `agente.py:381-420` → `modulos/explicador_modelo.py` (709 líneas).

---

## 5. Cumplimiento regulatorio

Cuatro funcionalidades que existen porque **SR 11-7 §V** y **EBA/GL/2023/01** las exigen, no
como mejora técnica. Cada una responde a una pregunta concreta que un auditor externo va a
formular.

### 5.1 `--validador` y `--cargo` — firma humana obligatoria

**La pregunta que responde:** *«¿quién firmó esto?»*

Un informe sin responsable humano identificable no acredita validación independiente:
acredita que se ejecutó un programa.

**Qué hace.** En `--prdc`, exige nombre y cargo del validador responsable **antes de gastar
un solo token**. Se admite por flag, por variable de entorno o interactivamente, pero no se
admite su ausencia.

```bash
# Por flag
python agente.py --titulo "LaR" --tier 1 --prdc \
                 --validador "Ana Pérez" --cargo "Validador de Segunda Línea"

# Por entorno (para CI o lotes)
export VIRF_VALIDADOR="Ana Pérez"
export VIRF_VALIDADOR_CARGO="Validador de Segunda Línea"
python agente.py --titulo "LaR" --tier 1 --prdc

# Sin ninguno de los dos → lo pregunta por consola; si no hay TTY, RECHAZA la corrida
```

**Por qué se pide al principio y no al final** (`agente.py:630-652`). Dos razones: la
económica —descubrir que falta la firma después de pagar la corrida completa obliga a
repetirla— y la de fondo: un informe de producción sin responsable no debe llegar a generarse.

**Tres piezas** (`modulos/validador_humano.py`):

- **2.1 Identidad obligatoria** en `--prdc`.
- **2.2 Registro acumulado** en `feedback/registro_validadores.json`: qué modelo validó cada
  persona y cuándo. Permite demostrar rotación ante el regulador y sirve a equipos de 2-5
  personas con instalaciones separadas sobre el mismo repositorio. Se escribe **después** de
  emitir el Word: si la generación falla, no queda constancia de una aprobación que nunca se
  materializó (`agente.py:1124-1132`).
- **2.3 Detección de auto-aprobación**: si la misma persona firma **3 o más** informes
  consecutivos del mismo modelo (`VIRF_UMBRAL_SEGUNDA_REVISION`, mínimo 2) sin que intervenga
  un segundo validador, se advierte. **No se bloquea**: en un equipo de dos personas puede ser
  inevitable, y bloquearlo impediría trabajar. El aviso queda visible en el informe para que
  el auditor lo valore.

**Señal interna de calidad del proceso.** En `--prdc` se genera además
`calidad_proceso_*.json` (`modulos/override_humano.py:calidad_proceso`), que **nunca** entra
en el informe del regulador: allí sería una acusación implícita al propio validador que firma.

---

### 5.2 `--verificar-cadena` — integridad de la cadena de custodia

**La pregunta que responde:** *«¿cómo sé que este informe no se editó después de generarse?»*

**Qué hace.** Recorre todos los informes JSON de un modelo **siguiendo los enlaces de la
cadena** (no el orden alfabético del sistema de ficheros) y verifica que cada eslabón sigue
íntegro. Alterar cualquier informe rompe la cadena **en un punto identificable**.

**Sintaxis.**
```bash
python agente.py --verificar-cadena "Modelo LaR"
echo $?   # 0 = cadena íntegra · 1 = cadena rota
```

**Requiere API.** ❌ Coste 0, sin conexión.

**Diseño del hash** (`modulos/custodia.py`):

- `hash_este_informe` = SHA-256 canónico (`sort_keys=True`) del JSON completo **excluyendo**
  los campos derivados del propio hash. Determinista: dos corridas con datos idénticos dan el
  mismo hash.
- `hash_cadena` = `SHA-256(hash_propio | hash_anterior_o_GENESIS | timestamp)`. El timestamp
  entra en el material del hash, así que **alterar la fecha rompe la verificación aunque el
  contenido no cambie**.
- El timestamp es de **generación**, va **dentro** del JSON firmado. La fecha del sistema de
  ficheros es irrelevante — copiar el fichero no la manipula.

**El sellado es lo último antes de escribir** (`agente.py:1076-1091`), porque el hash cubre
todo lo anterior: cualquier campo añadido después quedaría fuera del sello y la verificación
lo detectaría como alteración.

**Preservación de eslabones.** Dos corridas del mismo modelo el mismo día escriben el **mismo**
fichero. Sin `preservar_si_existe()` (`custodia.py:219`), la segunda borraba el eslabón
anterior de la cadena. Ahora se archiva:

```
  🔗 Informe previo preservado como resultados_LaR_2026-07-30.prev-143052.json
  🔗 Cadena de custodia: eslabón #4 · hash a3f9c1e2b7d0…
```

---

### 5.3 `--verificar-evidencia` — los documentos citados siguen intactos

**La pregunta que responde:** *«¿sobre qué versión del manual se emitió este puntaje?»*

**Qué hace.** Toma un informe JSON y comprueba, documento por documento, si los ficheros que
lo justificaron siguen siendo los mismos. Compara el SHA-256 del fichero **y** del texto
extraído en el instante de la evaluación (`version_evidencia_usada`).

**Sintaxis.**
```bash
python agente.py --verificar-evidencia outputs/2026-07-30/resultados_LaR_2026-07-30.json
echo $?   # 0 = todos intactos · 1 = alguno cambió o desapareció
```

**Requiere API.** ❌ Coste 0.

**Para qué sirve en la práctica.** Si el manual metodológico se actualizó después de emitir el
informe, el puntaje ya no describe el modelo vigente. Este comando lo detecta en segundos en
vez de por sorpresa en el comité.

---

### 5.4 `--historial-validaciones` — quién firmó qué y cuándo

**Qué hace.** Lee `feedback/registro_validadores.json` e imprime, agrupado por validador, los
modelos aprobados con su fecha, tier, score y huella de ejecución.

```bash
python agente.py --historial-validaciones
```

**Requiere API.** ❌ Coste 0.

**Para qué sirve.** Demostrar segregación de funciones y rotación ante el supervisor sin tener
que abrir informes uno por uno.

---

## 6. Feedback y aprendizaje

El sistema tiene **tres capas** de feedback. Se documentan juntas porque se confunden con
facilidad.

### Capa 1 — Bucle interactivo (automático, sin flag)

**Cuándo se dispara.** Al final de **toda** corrida del pipeline completo que **no** use
`--prdc` (`agente.py:1227`). No hay flag que lo active: es el comportamiento por defecto de
pre-producción.

**Qué pregunta** (`modulos/feedback.py:189-273`):

```
  ¿Deseas registrar feedback? (s/n): s

  Número de actividad a corregir (o 'fin' para terminar, 'ver' para listar): 7

  Ámbito   : Metodología
  Actividad: Se contrastó la hipótesis de normalidad de los retornos
  Puntaje del agente: 4/5
  Puntaje correcto según tu criterio (1-5): 2
  ¿Qué debió hacer el agente? (descripción breve): el manual cita Jarque-Bera
      pero no reporta el p-valor; eso no acredita el contraste
  ✓ Feedback guardado. Diferencia: -2 puntos
```

**Dónde se guarda.** `feedback/historial_feedback.json`, con: fecha, modelo, tier, ámbito,
actividad, `puntaje_agente`, `puntaje_correcto`, `diferencia` y comentario.

**Durabilidad.** `cargar_historial()` respalda un JSON dañado como `.corrupto-<ts>.json` y
avisa por consola, en lugar de devolver `[]` en silencio y perder el historial
(`TestAuditoriaHistorialFeedbackEsDurable`).

### Capa 2 — El feedback vuelve al prompt

En la corrida siguiente, `construir_contexto_feedback(ambito, actividad)`
(`feedback.py:280`) busca correcciones previas relevantes y las inyecta como contexto
adicional al motor IA.

**Dos guardias anti-sesgo, deliberadamente coordinadas:**

| Guardia | Variable | Default | Qué gobierna |
|---|---|:---:|---|
| Bloque de calibración del prompt | `VIRF_MIN_FEEDBACK_ANTISESGO` | 15 | Masa crítica por ámbito antes de que el histórico altere el criterio |
| Ajuste numérico post-hoc | `VIRF_MIN_MUESTRAS_AJUSTE` | hereda el anterior (15) | Muestras por actividad similar antes de mover el puntaje |

El segundo estaba **hardcodeado a 3** en `feedback_mejorado.ajustar_puntaje_por_feedback`.
Medido: con 3 muestras de diferencia +2, un puntaje 2.0 pasaba a 2.8 → redondea a **3**, un
punto entero sobre una escala de 5. Y quien subiera `VIRF_MIN_FEEDBACK_ANTISESGO` a 30
creyendo endurecer el sistema seguía teniendo ese ajuste disparándose con 3 muestras. La
intervención **más** directa sobre el dictamen no puede tener el guardia **más** débil.

### Capa 3 — `--estadisticafeedback`

**Qué hace.** Métricas de precisión del agente + informe Excel detallado.

```bash
python agente.py --estadisticafeedback
```

**Requiere API.** ❌ Coste 0.

**Métricas que reporta** (`modulos/feedback.py:349` + `agente.py:61-92`):

| Métrica | Lectura |
|---|---|
| Total feedbacks / período | Tamaño de la muestra |
| Evaluaciones exactas (%) | Coincidencia perfecta agente-humano |
| Dentro de ±1 punto (%) | Precisión práctica |
| MAE | Error medio absoluto |
| Sesgo promedio + interpretación | Si el agente **sobreestima** o **subestima** de forma sistemática |
| Sobreestimaciones / subestimaciones | Conteo por dirección |
| Desglose por ámbito | MAE, % exactos, % ±1 punto por cada uno de los 6 ámbitos |

**Salida.** Informe Excel en `outputs/` (`modulos/generador_estadistica_feedback.py`), con
gráfico de barras por ámbito.

Un historial sucio (registros incompletos, tipos mezclados) **no tumba** el cálculo:
`_registros_utilizables()` filtra (`TestAuditoriaHistorialSucioNoTumbaLasEstadisticas`).

### Anexo de human override

Independiente de las tres capas: `modulos/override_humano.py` produce, para el informe Word,
el **anexo de correcciones del validador** — qué puntuó el agente, qué corrigió la persona y
por qué. Es la evidencia más directa de que el juicio humano prevalece sobre la sugerencia
automática y que el sistema no es una caja negra que se aprueba sola. Incluye la
`linea_independencia`: qué porcentaje de actividades fue corregido por el humano.

---

## 7. Motor de datos

**Qué es.** El conjunto de pruebas automáticas, ejecutables en pandas, que VIRF sabe correr
sobre un dataset real para validar su calidad. No son evaluaciones del LLM: son cálculos
deterministas.

**`--listar-motores`** muestra el catálogo y sale (coste 0):

```bash
python agente.py --listar-motores
```

**Las 8 pruebas** (`modulos/motores_datos.py:REGISTRO_MOTORES`):

| `TIPO_MOTOR` | Qué verifica | Requiere | Opcional | Ejemplo |
|---|---|---|---|---|
| `unicidad` | Un solo valor del campo objetivo por grupo | `GROUP_COLS`, `CAMPO_OBJETIVO` | `UMBRAL` | Un solo Cliente por Cuenta |
| `duplicados` | Filas duplicadas según columnas clave | — | `GROUP_COLS`, `UMBRAL` | No dos registros idénticos de Cuenta+Fecha |
| `missing` | Cuantifica nulos | — | `CAMPO_OBJETIVO`, `UMBRAL` | Menos del 1 % de nulos en `monto` |
| `outliers` | Atípicos por **IQR robusto** (no Z-score) | `CAMPO_OBJETIVO` | `UMBRAL` | Outliers de `Tasa` fuera de 1.5·IQR |
| `rango` | Valores dentro de `[MIN, MAX]` | `CAMPO_OBJETIVO`, `MIN` y/o `MAX` | `UMBRAL` | Tasa entre 0 y 1 |
| `integridad_referencial` | Los valores existen en un dataset de referencia | `CAMPO_OBJETIVO`, `DATASET_REF` | `CAMPO_REF`, `UMBRAL` | Todo `id_cliente` de operaciones existe en `maestro_clientes` |
| `tipo_dato` | La columna es convertible al tipo esperado | `CAMPO_OBJETIVO` | `TIPO_ESPERADO`, `UMBRAL` | `FechaApertura` debe ser fecha válida |
| `completitud` | Columnas requeridas presentes y filas suficientes | — | `COLUMNAS_REQ`, `MIN_FILAS` | El extracto debe traer ≥ 1000 filas |

> `outliers` usa IQR y no Z-score deliberadamente: el Z-score asume normalidad, y en
> distribuciones de riesgo con colas gruesas marca como normal precisamente lo que interesa
> detectar.

**Contrato de salida idéntico para toda prueba:**

```python
{
  "control_id":   str,
  "tipo_motor":   str,
  "estado":       "OK" | "ADVERTENCIA" | "ALERTA" | "ERROR",
  "n_total":      int,      # filas evaluadas
  "n_hallazgos":  int,      # filas/grupos que incumplen
  "tasa_error":   float,    # n_hallazgos / n_total  (0.0-1.0)
  "umbral":       float,
  ...
}
```

Ese `tasa_error` es exactamente lo que alimenta la calibración de puntaje de §4.1.

**Tres propiedades de diseño:**

1. **Registro auto-descriptivo.** Antes había **una** sola prueba (`unicidad`) escrita a mano
   dentro de `Mx_04`, sin forma de saber qué pruebas existían ni de añadir nuevas sin tocar el
   orquestador.
2. **El catálogo se inyecta en los prompts.** `describir_motores()` genera el texto legible que
   ve el LLM, así que el modelo sabe qué pruebas existen realmente y no inventa.
3. **Cada prueba genera su código pandas equivalente**, para poder volcarla a un notebook
   reproducible (esto es lo que usa §9).

**Uso independiente:**
```bash
python -m modulos.motores_datos     # lista el catálogo
```

---

## 7-bis. Revisión del código contra la documentación

**`--revisar-codigo`** · **`--perfilar-datasets`**

### El problema

El ámbito «Implementación» pide contrastar el código contra el manual, y la
instrucción que se inyecta al modelo lo dice literalmente: *«¿Las funciones
documentadas en el manual existen en los scripts (.py, .ipynb)? ¿Hay funciones en
código SIN documentación (RIESGO)? Detectar cambios no documentados (code drift)»*.

El pipeline por ámbito no podía cumplirlo, por tres defectos concretos:

1. **El `.py` se truncaba a 8.000 chars** (~200 líneas) **dentro del lector**, por
   debajo del TRUNCADO-FIX. Peor que perder texto: `chars_totales` se medía sobre el
   texto ya recortado, así que un módulo de 40.000 chars se reportaba con
   `cobertura_pct = 100.0` habiendo perdido el 80 %.
2. **El `.ipynb` no se leía.** No estaba en `LECTORES_EXT`, así que `leer_archivo()`
   devolvía `None` y el notebook se omitía **sin aviso** — mientras el prompt pedía
   contrastar contra él. El pipeline `--control` sí lo leía: el mismo notebook era
   visible o invisible según el pipeline.
3. **El presupuesto no da.** Todo el ámbito comparte `VIRF_MAX_CTX` (15.000 chars)
   que además debe alojar el manual. Un modelo con librerías propias son 200.000
   chars: no caben, y lo que entra desplaza al manual contra el que había que
   contrastar.

### La solución: un módulo, una llamada

Cada `.py`/`.ipynb`/`.sql`/`.R` se revisa en **su propia llamada**, con el manual metodológico
como contexto fijo. Así cada módulo entra íntegro sin competir con sus hermanos, y
los hallazgos se atribuyen a `fichero:línea`.

```bash
# Inventario y coste, SIN gastar un token ni necesitar credencial
python agente.py --revisar-codigo --dry-run

# Revisión real, integrada en el pipeline
python agente.py --titulo "Modelo LaR" --tier 1 --revisar-codigo --perfilar-datasets
```

**Dónde va el código.** En `inputs/implementacion/`, con la estructura que tenga —
la lectura es recursiva y cubre `.py`, `.ipynb`, `.sql` y `.R`:

```
inputs/implementacion/
├── main.py
├── libs/            ← librerías propias del modelo
│   ├── calculo.py
│   └── utils.py
├── notebooks/
│   └── backtesting.ipynb
├── etl/
│   └── carga.sql    ← el ETL también es el modelo
├── modelo_var.R
└── datasets/        ← NO se lee como texto; se perfila (ver abajo)
```

**Extensiones cubiertas.** La revisión módulo a módulo cubre `.py`, `.ipynb`,
`.sql` y `.R`. Cada fichero viaja al prompt **con su lenguaje declarado** y se
trocea por las fronteras propias de ese lenguaje:

| Lenguaje | Frontera de corte |
|---|---|
| Python | `def` / `class` / `@` de nivel superior |
| R | `nombre <- function(…)` |
| SQL | inicio de sentencia, **solo si la anterior cerró con `;`** |

> El detalle de SQL no es cosmético: `SELECT` es token de frontera y también
> aparece dentro de `CREATE TABLE x AS SELECT …`. Sin la guarda del terminador,
> el corte partía esa sentencia en dos y cada mitad se revisaba por separado —
> media consulta contrastada contra el manual produce el mismo hallazgo falso
> que media función.
>
> Otras extensiones (`.scala`, `.yaml`, `.do`, `.sas`) **no se leen todavía**:
> `leer_archivo()` devuelve `None` y el fichero se omite sin aviso. Si tu modelo
> las usa, hay que registrarlas en `LECTORES_EXT` y `EXTENSIONES_CODIGO`.

**Las 5 categorías de hallazgo** (catálogo cerrado, para poder consolidar 30 módulos):

| Categoría | Qué significa |
|---|---|
| `no_documentado` | Existe en el código y el manual no lo declara |
| `documentado_ausente` | El manual lo declara y no existe en el código |
| `code_drift` | Existe en ambos pero no coinciden (fórmula, parámetro, umbral) |
| `supuesto_tacito` | El código asume algo que el manual no declara ni justifica |
| `riesgo_tecnico` | Defecto que afecta al resultado del modelo |

**Puntaje por módulo**, fusionado en el ámbito Implementación con el mismo patrón
que los controles CDD:

| Hallazgos del módulo | Puntaje |
|---|:---:|
| Alguno crítico | 1 |
| ≥ 3 altos | 2 |
| 1-2 altos | 3 |
| Solo medios | 4 |
| Ninguno | 5 |
| Fallo técnico | `null` — **excluido** del score |

**Detalles de diseño que importan:**

- **El código llega numerado.** Un LLM no cuenta líneas de forma fiable y devuelve
  números inventados. Se le dan escritas (`_numerar_lineas`), lo que convierte cada
  cita en verificable.
- **Los módulos grandes se parten en frontera de `def`/`class`, nunca a media
  función.** Media función revisada contra el manual produce hallazgos **falsos**
  («no valida la entrada» cuando la validación quedó en el otro bloque).
- **El inventario se imprime siempre antes de gastar.** Este flujo multiplica las
  llamadas por el número de ficheros; el coste se ve antes, no en la factura.
- **Un fallo técnico no se disfraza de «0 hallazgos»**: marca la revisión como no
  confiable, igual que hace el pipeline con las actividades.

**Lo que el notebook aporta además.** El lector declara cuántas celdas se ejecutaron
y cuáles no, y expone las excepciones no resueltas. Un notebook entregado sin
ejecutar es un hallazgo de validación en sí mismo:

```
[NOTEBOOK backtesting.ipynb — 3 celda(s) de código, 2 ejecutada(s) · ⚠️ 1 SIN EJECUTAR]
[CELDA 4 · OUTPUT]
⚠️ EXCEPCIÓN NO RESUELTA: ZeroDivisionError: division by zero
```

Las imágenes en base64 se **declaran pero no se vuelcan**: son cientos de miles de
chars que el modelo no puede interpretar.

**Salidas.** `outputs/<fecha>/revision_codigo_<modelo>.md` (detalle completo) y el
bloque `revision_codigo` dentro del JSON de resultados.

### `--perfilar-datasets` — el esquema es evidencia, las filas no

`datasets/` está excluido de la evidencia documental **a propósito**: un solo `.csv`
se comía los 15.000 chars de contexto y expulsaba al manual. Pero de ahí no se sigue
que el dataset no importe: lo que hay que contrastar no son las filas, es el
**esquema**.

```
### operaciones

5,003 filas × 6 columnas

⚠️ 3 fila(s) duplicada(s) (0.1%) — contrastar contra la política de unicidad
   declarada en el manual.

Columnas:
  · monto (float64) | nulos 1.2% | únicos 4,940 | rango [77.26 … 1.058e+05]
  · fecha (object (fechas detectadas)) | nulos 0.0% | rango [2024-01-01 … 2024-07-27]
  · moneda (object) | nulos 0.0% | únicos 1 | valores: PEN
      ⚠️ COLUMNA CONSTANTE (un único valor en todas las filas)
  · campo_muerto (float64) | nulos 100.0% | únicos 0
      ⚠️ COLUMNA ÍNTEGRAMENTE NULA
```

Eso son ~1.400 chars para 5.000 filas, **sin una sola fila de datos**, y permite las
tres comprobaciones que un modelo mal documentado esconde: variables que el código
consume y el manual no declara, variables que el manual promete y el dataset no
tiene, y supuestos de calidad que el perfil desmiente.

No sustituye al motor de datos (§7): aquel **calcula** con umbrales y tasa de error;
el perfilador solo **describe** para dar contexto. Capas separadas a propósito.

**Parámetros** (`config/parametros.py`):

| Variable | Default | Qué controla |
|---|---:|---|
| `VIRF_MAX_CHARS_MODULO` | 120 000 | Chars de un módulo por llamada; por encima se parte |
| `VIRF_MAX_CHARS_MANUAL_REVISION` | 24 000 | Manual por llamada — **es el multiplicador del coste** |
| `VIRF_EXCLUIR_DEPENDENCIAS` | `0` | Excluir `site-packages/`, `.venv/`… **Desactivado** |

> ⚠️ Con el filtro desactivado, si copias a `inputs/implementacion/` un árbol que
> arrastra su entorno virtual, son **miles de módulos y miles de llamadas**. El
> inventario previo lo declara antes de gastar; actívalo con
> `VIRF_EXCLUIR_DEPENDENCIAS=1` si es tu caso.

---

## 8. Ingeniería inversa Excel → Notebook

**`--convertir-excel CARPETA`**

**Qué hace.** Dada una carpeta con libros de Excel —posiblemente con VBA y referencias
cruzadas entre libros— produce **un `.ipynb` ejecutable por libro** que replica el proceso en
Python.

**Cuándo usarlo.** El modelo vive en Excel y hay que validarlo, o hay que migrarlo a Python y
nadie sabe qué hace la hoja de 400 fórmulas.

**Sintaxis.**
```bash
# Completo: estructura + fórmulas traducidas por LLM + auto-validación
python agente.py --convertir-excel inputs/modelo_excel/

# Sin IA: solo estructura y fórmulas sin traducir (coste 0)
python agente.py --convertir-excel inputs/modelo_excel/ --sin-llm

# Con IA pero sin comparar contra el Excel evaluado
python agente.py --convertir-excel inputs/modelo_excel/ --sin-validacion
```

**Estructura de cada notebook generado:**

1. **INPUTS** — carga de datos crudos
2. **CALIDAD DE DATOS** — validaciones básicas sobre inputs
3. **MOTOR DE TRATAMIENTO** — fórmulas Excel traducidas a Python
4. **OUTPUTS** — resultados
5. **VBA** (si existe) — macros traducidas a Python
- **Anexo A** — dependencias cross-hoja detectadas
- **Anexo B** — tabla completa de fórmulas
- **Anexo C** — **REVISIÓN MANUAL REQUERIDA** (fórmulas peligrosas)
- **Anexo D** — **RESULTADO DE AUTO-VALIDACIÓN** (notebook vs Excel evaluado)

**Capacidades** (`modulos/excel_a_notebook.py`, 1231 líneas):

- Sin techos de muestreo fijos (configurables por entorno).
- **Chunking por hoja** para libros grandes.
- **Extracción de VBA** con `olevba`.
- **Grafo topológico entre libros** con refs externas `[libro.xlsx]Hoja!A1`.
- **Auto-validación** notebook vs Excel evaluado (`data_only` + fallback a fórmulas),
  tolerancia `EXCEL_VALIDACION_TOL` (default `1e-6`).
- **Detector de fórmulas peligrosas**: `INDIRECT`, `OFFSET`, fórmulas de array, `LAMBDA`…
  → van al Anexo C en vez de traducirse a algo plausible pero falso.
- Verificación del orden topológico de las variables Python generadas.

**Salida.** `outputs/<fecha>/notebooks/`

> **No copia nada al pipeline principal.** Tú decides qué mover a
> `inputs/implementacion/`. Es deliberado: un notebook autogenerado no es evidencia validada
> hasta que alguien lo revisa.

**La ejecución del notebook es explícita.** No se ejecuta código arbitrario sin que se pida
(`TestAuditoriaEjecucionDeNotebookEsExplicita`), con timeout `EXCEL_NB_TIMEOUT` (120 s).

---

## 9. Documento de controles → Notebook + brechas

**`--controles-a-notebook DOC`**

**El problema que resuelve.** En una validación de Calidad de Datos suele haber **dos** fuentes
que describen los controles, y casi nunca coinciden:

- **(A)** `ControlesData.xlsx` — los controles que el validador **va a ejecutar** (estructurados).
- **(B)** Un documento en prosa (manual de calidad de datos, DDM…) — los controles que el
  modelador **dice** que aplica (Word/PDF/Markdown, no ejecutable).

Hasta este módulo, VIRF solo leía (A). Los controles descritos en (B) quedaban sin contrastar:
si el manual prometía un control de integridad referencial que nadie ejecutaba, **nadie lo
detectaba**.

**Qué hace** (`modulos/controles_a_notebook.py`, 794 líneas):

1. Lee (B) y, con el LLM, **extrae** los controles descritos en prosa, convirtiéndolos a la
   misma estructura que (A).
2. Genera un `.ipynb` **ejecutable** que implementa esos controles en pandas, usando el
   catálogo real de `motores_datos` (§7).
3. Cruza (A) contra (B) y produce un **análisis de brechas**.

**Sintaxis.**
```bash
python agente.py --controles-a-notebook inputs/calidad_datos/manual_controles_datos.md \
                 --excel inputs/calidad_datos/ControlesData.xlsx \
                 --datasets inputs/calidad_datos/datasets
```

Si no se pasa `--excel`, se usa `inputs/calidad_datos/ControlesData.xlsx`. Si no existe, se
genera el notebook **sin** análisis de brechas y se avisa.

**Los dos hallazgos que reporta** (`agente.py:504-510`):

```
  ⚠️  HALLAZGO: 3 control(es) documentado(s) pero NO ejecutado(s).
  ⚠️  HALLAZGO: 1 control(es) ejecutado(s) pero NO documentado(s).
```

El primero es un incumplimiento del modelador. El segundo, un hueco de documentación. Ambos
son hallazgos de validación con nombre propio.

**Salida.** `outputs/<fecha>/controles/` — notebook + reporte de brechas.

---

## 10. Caché de documentos y resúmenes

**Por qué existe.** Leer y parsear PDFs y DOCXs consume tiempo, y **resumir** un documento
largo consume dinero: el manual de 305 páginas del caso real cuesta ~$0.90 en resúmenes de
chunking. Si el documento no cambió, ese gasto es puro desperdicio.

**Cómo funciona** (`modulos/document_cache.py`, 593 líneas):

- **Clave = SHA-256 del contenido binario** del fichero. Un documento modificado produce otra
  clave y se relee. La frescura la garantiza el hash, no una política de expiración.
- `cache/document_cache.json` — índice de textos extraídos.
- Fichero separado para los **resúmenes de chunking**.
- **Lock con timeout** (`VIRF_CACHE_LOCK_TIMEOUT`=10 s, `VIRF_CACHE_LOCK_STALE`=60 s) para que
  dos corridas simultáneas no corrompan el índice.
- `purgar_huerfanos()` al arrancar: limpia entradas de ficheros que ya no existen.

**Comandos.**

```bash
# Ver el estado
python agente.py --cache-stats

# Limpiar TODO (documentos + resúmenes)
python agente.py --limpiar-cache

# Corrida sin caché
python agente.py --titulo "LaR" --tier 1 --no-cache
```

`--cache-stats` reporta total de entradas, hits históricos y distribución por tipo de fichero.

**Dos correcciones que conviene conocer:**

**El caché ya NO se apaga con `--prdc`.** Antes: `cache_activo = CACHE_ENABLED and not
args.prdc and not args.no_cache`, con el motivo "en producción siempre fresco". Ese motivo no
se sostiene: el caché está indexado por hash del contenido, así que la frescura ya está
garantizada. Lo único que compraba desactivarlo era pagar el chunking íntegro (~$1.45)
justo en las corridas que emiten el entregable — anulaba el ahorro precisamente donde más
cuesta. Además, deducir "sin caché" de `--prdc` es **adivinar el modo por heurística** cuando
ya existe el flag explícito `--no-cache` para pedirlo (`agente.py:196-208`,
`TestAuditoriaCacheNoSeApagaPorHeuristica`).

**`--limpiar-cache` ahora limpia de verdad.** Antes solo vaciaba `document_cache.json`; los
**resúmenes** vivían en otro fichero y sobrevivían a la limpieza. Se encontró una entrada con
cobertura del 1,2 % conviviendo con la buena del 100 % sobre el mismo manual
(`agente.py:428-434`, `TestAuditoriaBorrarDelCacheBorraDeVerdad`).

Estado en consola al arrancar:
```
  📦 Caché de documentos: ACTIVO (37 entradas previas)
  📦 Caché de documentos: INACTIVO [--no-cache]
  📦 Caché de documentos: INACTIVO [CACHE_ENABLED=0 en .env]
```

---

## 11. Chunking de documentos largos

**Qué hace.** Permite evaluar un manual de 305 páginas sin truncarlo, resumiéndolo por
segmentos y consolidando jerárquicamente hasta que quepa en el presupuesto de contexto.

**Diseño por inyección de dependencias** (`modulos/chunker.py`, 692 líneas). En v18/v19 el
chunking vivía dentro de `Mx_01_LecturaEvidencias` (capa de lectura) y llamaba internamente a
`get_cliente_ia()` (capa de IA). Consecuencias reales: los errores de API durante la lectura se
capturaban en silencio, no había rate limiting centralizado, no se podía mostrar progreso
("segmento 7/11") y el pre-flight de API key **no protegía el chunking**.

Ahora `ChunkerService` recibe el cliente ya inicializado, `agente.py` lo instancia y llama
`procesar_lote()` justo después de leer todos los ficheros: un único punto de control.

**Metadatos de cobertura que produce.** `procesar_doc()` devuelve el documento enriquecido con
`cobertura_pct`, `n_chunks`, `modo_cobertura`, `chars_totales`, `fue_resumido`. Estos viajan
hasta el prompt de evaluación (`agente.py:724-745`) — antes se calculaban en `chunker.py` y
**morían ahí**, de modo que para un manual de 300 páginas el agente no sabía qué fracción
había visto.

**El cálculo de cobertura del ámbito, corregido.** Dos defectos lo inflaban
(`agente.py:748-772`):

1. El comentario decía "ponderada por tamaño" y el código hacía una **media aritmética
   simple**. Un anexo de 1 página al 100 % y un manual de 300 páginas al 30 % daban **65 %**,
   cuando lo que el evaluador realmente vio era ~30 %.
2. Los documentos descartados por saturación de contexto no entraban en el cálculo: 3 docs
   completos de 10 daban **100 %**.

Ahora se pondera por el tamaño **original** y los descartados cuentan como 0 %. Esta cifra
viaja al prompt, así que inflarla es hacerle creer al modelo que vio más de lo que vio
(`TestAuditoriaCoberturaDocumentalNoSeInfla`, `TestAuditoriaCoberturaDocumentalVsPrompt`).

**El acantilado de coste** (`config/parametros.py:187-196`, `TestAuditoriaAcantiladoDeCoste`).
Medido sobre un PDF real de 305 páginas:

| `VIRF_MAX_CHUNKS` | Coste | Cobertura | Nota |
|:---:|---:|:---:|---|
| 60 | $1.45 | 100 % | gasto innecesario |
| **40** | **$1.14** | **100 %** | **default actual** |
| 30 | $2.27 | 100 % | ⚠️ **más caro** |

Bajar de ~34 sin subir `CHUNK_SIZE_MAX` es contraproducente: el segmento adaptativo necesario
supera el tope, el chunker cae al modo **jerárquico puro** y el coste **sube**.

**Parámetros:**

| Variable | Default | Qué controla |
|---|---:|---|
| `VIRF_CHUNK_ENABLED` | `1` | Activa/desactiva el chunking |
| `VIRF_CHUNK_SIZE` | 12 000 | Tamaño **inicial** del segmento (el adaptativo puede subirlo) |
| `VIRF_CHUNK_SIZE_MAX` | 40 000 | Techo del segmento adaptativo |
| `VIRF_CHUNK_OVERLAP` | 800 | Solape entre segmentos |
| `VIRF_CHUNK_THRESHOLD` | = `CHUNK_SIZE` | A partir de qué tamaño se trocea |
| `VIRF_MAX_CHUNKS` | 40 | Tope de segmentos por documento |
| `VIRF_MAX_NIVELES` | 3 | Niveles de consolidación jerárquica |
| `VIRF_PRESUPUESTO_DOC` | 60 % de `MAX_CTX` | Cuánto puede ocupar **un** documento en el prompt |

**Una lectura fallida no es cobertura total.** Si la extracción falla, el documento no se
reporta al 100 % (`TestAuditoriaLecturaFallidaNoEsCoberturaTotal`). Y el caché no recorta lo
que el chunker debe cubrir (`TestAuditoriaElCacheNoRecortaLoQueElChunkerDebeCubrir`).

---

## 12. Multimodelo — `--raiz-evidencia`

**El problema.** `cargar_todos_inputs()` lee **todo** `inputs/` sin filtrar por modelo, y
`--titulo` solo rotula el informe e infiere el dominio RAG. Con la evidencia de varios modelos
en el mismo árbol, **el manual de uno puntúa como evidencia de otro**: un informe de VaR podría
citar el manual del LaR y nadie lo notaría.

**La solución: un modelo por raíz.**

```bash
python agente.py --titulo "VaR Mercado FRTB" --tier 1 \
                 --raiz-evidencia modelos/VaR_FRTB
```

Con la estructura:
```
modelos/VaR_FRTB/inputs/documentacion/modelamiento/
modelos/VaR_FRTB/inputs/documentacion/seguimiento/
modelos/VaR_FRTB/inputs/implementacion/
modelos/VaR_FRTB/inputs/calidad_datos/
modelos/VaR_FRTB/inputs/papers/
modelos/VaR_FRTB/inputs/usos/
```

**Qué se reapunta y qué no.** Se reapuntan las carpetas de `inputs/`. **Siguen en la raíz del
proyecto**: el estándar VIRF (`Estandares_VIRF.xlsx`), el caché, el `ControlesData.xlsx` que lee
el pipeline completo y el default de `--datasets`. Es correcto: la vara de medir y el historial
son comunes; la evidencia es del modelo.

⚠️ **`outputs/` es una excepción asimétrica.** El pipeline completo escribe siempre en
`OUTPUTS_DIR` (raíz del proyecto, `agente.py:692`), pero `--control` escribe en
`base_project_path/outputs/` (`motor_ia_v2.py:744`) — es decir, **dentro de la raíz de
evidencia**. Con `--control --raiz-evidencia modelos/VaR_FRTB` los resultados aparecen en
`modelos/VaR_FRTB/outputs/<fecha>/`. Detalle completo en `FLAGS.md` §16.2.

**Aplica a los tres pipelines:** completo, `--control` (viaja como `base_project_path`, la
segunda vía de carga de evidencia, que no pasa por `RUTAS` y se olvidaría fácilmente) y
`--explicar-modelo`.

**Se resuelve ANTES de cualquier rama de modo** (`agente.py:232`). Definirla dentro de una
rama la dejaría sin asignar en las demás: ese fue el `UnboundLocalError` que mató el pipeline
en la auditoría.

**Diagnóstico temprano de carpetas vacías** (`agente.py:149-156`):
```
  📂 Evidencia: C:\...\modelos\VaR_FRTB
  ⚠️  Carpetas sin documentos: implementacion, usos
      Los ámbitos que dependan de ellas puntuarán 0.0 (sin evidencia).
```
Sin este aviso, un árbol a medio montar produce ámbitos "sin evidencia" que la política
puntúa 0.0 — **una falta crítica atribuida al validado** cuando en realidad la ruta estaba mal.

**Sin el flag** se usa la raíz del proyecto y nada cambia para quien valide un solo modelo.

Cubierto por `TestMultimodeloRaizDeEvidencia`.

---

## 13. RAG por dominio financiero

**Qué hace.** Antes de llamar a la API, enriquece el prompt con contexto semántico recuperado
del índice vectorial (ChromaDB) del dominio correspondiente.

**Los 4 dominios** (`src/rag/`):

| Dominio | Qué indexa | Papers clave |
|---|---|---|
| `LaR` | Manuales metodológicos LaR, backtesting de liquidez, reportes Comité LaR | Cornish-Fisher, stress testing de liquidez |
| `VaR` | Manuales VaR, pruebas Kupiec/Christoffersen, FRTB | BIS FRTB, Basilea III |
| `conductuales` | Prepago, retiro de depósitos, NMD | papers de comportamiento, EBA guidelines |
| `shared` | SR 11-7, EBA/GL/2023/01, BCBS 239, SBS 9075-2012 | marcos transversales |

**Inferencia del dominio desde `--titulo`** (`src/rag/__init__.py:inferir_dominio`):

| Dominio | Palabras clave en el título |
|---|---|
| `LaR` | `lar`, `liquidity`, `liquidez`, `lic`, `hqla` |
| `VaR` | `var`, `value at risk`, `frtb`, `market risk`, `riesgo de mercado` |
| `conductuales` | `conductual`, `prepago`, `retiro`, `nmd`, `comportamiento`, `behavioural` |
| `shared` | **fallback**: cualquier otro título |

```python
inferir_dominio("Modelo LaR Liquidez")  → "LaR"
inferir_dominio("VaR Mercado FRTB")     → "VaR"
inferir_dominio("Scoring")              → "shared"
```

**Parámetros** (antes eran mandos muertos — `.env.example` los documentaba y **nadie los
leía**, porque vivían hardcodeados en las firmas de `motor_ia.evaluar_actividad()`):

| Variable | Default | Rango | Qué controla |
|---|---:|---|---|
| `RAG_TOP_K` | 3 | ≥ 1 | Fragmentos recuperados por consulta |
| `RAG_MIN_SCORE` | 0.35 | 0.0–1.0 | Similitud mínima para aceptar un fragmento |

**Degradación limpia.** Si el índice no existe o ChromaDB no está instalado, el retriever
devuelve `shared` vacío y el pipeline **continúa sin RAG** con `rag_dominio="no_disponible"`
registrado en el JSON. No se cae.

El dominio consultado y el número de fragmentos usados quedan en el JSON de cada evaluación
(`rag_dominio`, `rag_chunks`).

**Dos invariantes protegidos por tests:**
- `TestAuditoriaRagNoIndexaLaEvidenciaQueEvalua` — el RAG **no** debe indexar la evidencia que
  se está evaluando; sería razonamiento circular.
- `TestAuditoriaIndiceRagNiContaminadoNiIncompleto`.

**Reconstruir índices:**
```bash
python scripts/rebuild_rag_databricks.py --dominio all
python scripts/rebuild_rag_databricks.py --dominio LaR --force
python scripts/rebuild_rag_databricks.py --status
```

---

## 14. Proveedor IA y `--verificar-conexion-azure`

### Política de proveedor

**Azure OpenAI es el proveedor prioritario** por decisión de la entidad. El default vive en el
**código** (`config/parametros.py:127`) y no en el `.env`: si alguien clona el proyecto y
olvida definir `IA_PROVEEDOR`, la corrida debe salir por Azure, no por el secundario. Depender
de que el operador recuerde poner una variable es depender de que no se equivoque.

Anthropic sigue disponible como secundario (`IA_PROVEEDOR=anthropic`).
**No hay fallback automático** entre proveedores.

### Catálogo de modelos — parámetros por modelo, no por proveedor

`config/modelos.py` declara el perfil de **cada modelo conocido**: `chunk_size`, `max_ctx`,
`max_chunks`, `param_tokens` (`max_tokens` vs `max_completion_tokens`) y si admite
`temperature`.

**Por qué existe.** El chunking estaba dimensionado para un modelo concreto (200K de contexto)
con constantes fijas. Al cambiar de proveedor esos números dejan de tener sentido: GPT-4
clásico tiene 8K —menos que el presupuesto actual— y la familia GPT-5 mucho más. Fijar valores
"pensando en el modelo que creemos que habrá" es el error que este proyecto **ya cometió una
vez**: se asumieron 3,3 caracteres por token cuando el valor real medido era **2,48** — un
desvío del 33 % en el presupuesto de contexto.

Por eso aquí no se decide nada de antemano: el sistema **pregunta a la API** qué modelo sirve
realmente el deployment y elige el perfil que corresponda. Un modelo no catalogado recibe un
perfil **conservador** con aviso: es preferible hacer más llamadas de las necesarias que
exceder el contexto y perder cobertura documental en silencio.

### `--verificar-conexion-azure`

**Qué hace.** Prueba de humo del proveedor **activo** (el nombre dice Azure, pero funciona para
cualquiera). Hace **una** llamada mínima y responde a las cuatro preguntas que hay que resolver
antes de gastar en una corrida completa.

```bash
python agente.py --verificar-conexion-azure
```

**Las cuatro preguntas:**

| Pregunta | Qué reporta |
|---|---|
| ¿La credencial vale? | `✅ conectado` + latencia en ms |
| ¿Qué modelo hay detrás? | el `response.model` **real** del deployment, no el nombre configurado |
| ¿Con qué límites voy a trocear? | perfil de chunking completo: contexto, `chunk_size`, `max_ctx`, `max_chunks`, `param_tokens`, si admite `temperature` |
| ¿Entiendo su JSON? | muestra el JSON parseado correctamente |

**Salida de ejemplo:**
```
══════════════════════════════════════════════════════════════════════════
  🔌 PRUEBA DE CONEXIÓN — proveedor activo: azure_openai
══════════════════════════════════════════════════════════════════════════

  ✅ azure_openai conectado — modelo: gpt-4o-2024-11-20 — latencia: 812 ms
     JSON parseado correctamente: {"ok": true}

  Perfil de chunking que se aplicará (GPT-4o):
     contexto      : 128,000 tokens
     chunk_size    : 40,000 chars
     max_ctx       : 15,000 chars
     max_chunks    : 40
     param. tokens : max_tokens
     temperature   : admitida
```

**Si falla**, imprime la respuesta cruda recibida y la lista exacta de variables a revisar,
con el aviso que más errores causa: `AZURE_OPENAI_DEPLOYMENT` es el **Deployment name** del
portal, **no** el nombre del modelo.

### Guardia anti-fuga de credenciales

`config/ia.py:_detectar_key_en_example()` comprueba si la clave activa aparece literalmente en
`.env.example` — indicio de que una credencial real se commiteó. Solo compara claves con pinta
de credencial real (> 20 chars) para no disparar falsos positivos con placeholders.
Complementado por `val_seguridad()` en `validate_project.py` y
`TestAuditoriaSecretosYDistribucion`.

### PRE-FLIGHT de API key

Antes de gastar, `agente.py:326-375` valida la credencial:

- **Clave inválida/vacía/placeholder** → mensaje accionable + `exit 1`.
- **401** → se recorre **toda la cadena de causas** (`__cause__`/`__context__`, hasta 10
  niveles). Antes se usaba `str(e)` a secas: el 401 real venía envuelto en un `RuntimeError`
  genérico, así que la firma de autenticación no aparecía y **una clave rechazada se
  clasificaba como "error de red → continuar"**.
- **Error de red** → `exit 1` con diagnóstico. Antes se advertía y continuaba, lo que solo
  aplazaba la muerte hasta la instanciación del chunker, donde salía como dos tracebacks
  crudos encadenados en vez de un mensaje útil (`TestAuditoriaFallosDeRedSeDiagnosticanBien`).
- Recuerda qué modos siguen disponibles sin API.

---

## 15. Defensas anti-alucinación y anti-error

Funcionalidades transversales que no tienen flag propio pero cambian lo que el agente entrega.

### D3-FIX — el agente NO evalúa sobre el vacío

Si un ámbito no tiene documentos, la evaluación se **rechaza** en lugar de puntuarse
(`agente.py:787-809`):

```
  ✗ [Gobierno] SIN DOCUMENTOS — evaluación rechazada.
    Agrega archivos en las carpetas correspondientes a este ámbito.
    El agente NO evalúa sobre el vacío (D3-FIX: anti-alucinación).
```

El ámbito queda con `puntaje: null` y `sin_evidencia: true`, y su score es `null` en el JSON —
**no** un 0 arbitrario. Un agente evaluando sobre el vacío genera alucinaciones plausibles que
un auditor junior podría tomar como hallazgos verificados.

### "Sin evidencia" ≠ "fallo técnico" ≠ "incumplimiento"

Tres estados distintos que antes se mezclaban, cada uno con su contador en el reporte de
integridad:

| Estado | Significado | Efecto en el score |
|---|---|---|
| Evaluada OK | El agente vio evidencia y puntuó | Entra en el score |
| Sin evidencia | Falta documentación | Excluida; `null`, no 0 |
| Fallo técnico | La llamada o el parseo fallaron | **Excluida** del score, y se pide re-ejecutar |

```
  🔎 INTEGRIDAD DE LA EVALUACIÓN:
    • Actividades evaluadas OK : 19
    • Sin evidencia (D3-FIX)   : 2
    • Fallos técnicos          : 0
```

Con fallos técnicos > 0, `dictamen_confiable` es `False` y se avisa:
*"Estas NO recibieron puntaje y quedan EXCLUIDAS del score → Re-ejecuta para completarlas
antes de emitir dictamen."*

Tests: `TestAuditoriaSinEvidenciaNoEsFalloTecnico`,
`TestAuditoriaSinEvidenciaEsFaltaCriticaNoAusenciaDeDictamen`,
`TestAuditoriaSinDocumentosNoEsIncumplimientoEnMx03`.

### Score global `None` no es "CRÍTICO"

Cuando ningún ámbito pudo evaluarse (`agente.py:1200-1206`):
```
    • Score global:        NO EVALUABLE  [—]
      ⚠️  Ningún ámbito tenía evidencia. NO hay dictamen que emitir;
         esto NO significa que el modelo sea deficiente.
```
Antes llegaba como `0.00` y se anunciaba **"CRÍTICO"** sobre una corrida sin ninguna evidencia.

### Trazabilidad reproducible — la huella de ejecución

**Antes:** `prompt_hash = sha256(str(list(resultados_ambitos.keys())))` — hasheaba **solo los
nombres de ámbito**, por lo que era **idéntico** entre corridas con modelos, documentos y
scores distintos. La trazabilidad prometida no existía.

**Ahora** (`agente.py:924-1019`) la huella se calcula sobre **todo** lo que determina el
resultado:

```
agente_version + modelo_ia + proveedor_ia + tier + pesos_ambito + escala
+ SHA-256 del contenido de CADA documento de evidencia
+ huella del estándar (SHA-256 del Excel, nº de ámbitos, actividades, requeridas en el tier)
```

Dos corridas dan el mismo hash **si y solo si** la entrada es la misma.

**Por qué se registra la versión del estándar.** El estándar es un documento vivo. Dos informes
del mismo modelo con scores distintos pueden deberse a que **el modelo cambió**… o a que
**cambió el criterio**. Sin registrar la versión del estándar esa diferencia es
indistinguible, y un auditor que compare dos trimestres no puede saber cuál de las dos pasó.

Esto se intentaba proteger antes con un test que congelaba los conteos por tier. No
funcionaba: se rompía en cada revisión legítima y el arreglo natural era actualizar el número,
con lo que la protección desaparecía **justo cuando el criterio cambiaba de verdad**. La
trazabilidad pertenece al informe, no a la suite de tests.

### Path traversal en las salidas

`--titulo "../../../evil"` se interpolaba tal cual en la ruta y escribía el JSON **fuera** de
`outputs/`. Ahora `config/rutas.py:nombre_seguro()` sanea el nombre de fichero — el título
original se conserva íntegro **dentro** del JSON. También bloquea nombres reservados de
Windows (`CON`, `PRN`, `AUX`, `NUL`, `COM1-9`, `LPT1-9`), que fallan aunque la ruta sea
válida y sin depender de la extensión. Test: `TestAuditoriaPathTraversalEnSalidas`.

### Consola a prueba de codificación

El proyecto imprime emoji en 19 módulos. En una consola Windows con codepage **cp1252** —el
default en español— `print()` no revienta al escribir, revienta al **codificar**:

```
UnicodeEncodeError: 'charmap' codec can't encode character '\U0001f4d0'
```

Detectado en la auditoría D2: `agente.py` abortaba **a mitad del chunking** de un PDF de 305
páginas, tras ~35 s de extracción y **varias llamadas IA ya pagadas**. Los tests no lo veían
porque pytest captura stdout en un buffer UTF-8, ni `validate_project.py` porque no imprime
emoji en el camino crítico. Solo aparecía en una corrida interactiva real.

**No se arregla quitando los emoji** (19 ficheros, cientos de `print`, y cualquier módulo nuevo
reintroduciría el fallo). El punto único de control es el flujo de salida:
`modulos/consola.py:configurar_consola()` se ejecuta **antes del primer `print`** y antes de
importar módulos que impriman al cargarse (`agente.py:29-31`). Tres capas: (1) poner la consola
en UTF-8 (codepage 65001), (2) reconfigurar el stream, (3) degradar a ASCII como último
recurso. Test: `TestConsolaUnicode`.

### Otras protecciones con test dedicado

| Invariante | Test |
|---|---|
| Un tier inválido se rechaza **antes de gastar** (antes desactivaba el filtro en silencio y evaluaba TODAS las actividades) | `TestAuditoriaTierInvalidoSeRechazaAntesDeGastar` |
| Un import local no ensombrece al global (mató el pipeline entero: `ChunkerService` importado dentro de `main()` hacía la variable local de **toda** la función) | `TestAuditoriaImportLocalNoEnsombreceAlGlobal` |
| Un `.env` malformado no tumba el arranque | `TestAuditoriaEnvMalformadoNoTumbaElArranque` |
| Respuesta vacía de la API se maneja | `TestAuditoriaRespuestaVaciaDeLaAPI` |
| Un solo parser JSON en todo el proyecto | `TestAuditoriaUnSoloParserJSON` |
| El volcado de debug no se escapa a producción | `TestAuditoriaVolcadoDebugNoSeEscapa` |
| El Word no deforma los datos del JSON | `TestAuditoriaInformeWordNoDeformaLosDatos` |
| El score de un control cuenta **todos** los hallazgos | `TestAuditoriaScoreDeControlCuentaTodosLosHallazgos` |
| La cobertura de control no usa el máximo | `TestAuditoriaCoberturaDeControlNoUsaMaximo` |
| El resumen final cuadra consigo mismo (decía "evaluadas OK: 19" sobre "totales: 15" porque los controles CDD se integran después) | `TestAuditoriaElResumenFinalCuadraConsigoMismo` |
| Nombres de ámbito coherentes en los 4 sistemas | `TestAuditoriaNombresDeAmbitoCoherentes` |
| El caché de resúmenes opera bajo lock | `TestAuditoriaCacheDeResumenesBajoLock` |

---

## 16. Salidas del sistema

### Dónde se guarda cada cosa

```
outputs/<YYYY-MM-DD>/
├── resultados_<modelo>_<fecha>.json          ← siempre (pipeline completo)
├── resultados_<modelo>_<fecha>.prev-<hhmmss>.json  ← eslabón preservado
├── VIRF_Informe_*.docx                       ← solo --prdc
├── calidad_proceso_*.json                    ← solo --prdc, USO INTERNO
├── explicacion_del_modelo_<NOMBRE>.md        ← --explicar-modelo
├── notebooks/                                ← --convertir-excel
└── controles/                                ← --controles-a-notebook

feedback/
├── historial_feedback.json                   ← correcciones del validador
└── registro_validadores.json                 ← quién firmó qué y cuándo

cache/
├── document_cache.json                       ← textos extraídos
└── (fichero de resúmenes de chunking)
```

### Estructura del JSON de resultados

```jsonc
{
  "modelo": "Modelo LaR",
  "tier": "1",
  "fecha": "2026-07-30",
  "agente": {
    "agente_version": "27.1",
    "modelo_ia": "gpt-4o-2024-11-20",
    "proveedor_ia": "azure_openai",
    "pesos_ambito": { "...": 0.30 },
    "cache_activo": true,
    "huella_ejecucion": "a3f9c1e2b7d0",      // 12 chars, identifica la corrida
    "huella_completa": "a3f9c1e2b7d0...",    // 64 chars, verificación estricta
    "documentos_huella": {                    // qué evidencia se usó
      "documentacion/manual_LaR.pdf": { "sha256": "9f2c...", "chars": 412033 }
    },
    "estandar": {                             // qué versión de la vara de medir
      "archivo": "Estandares_VIRF.xlsx",
      "sha256": "...",
      "n_ambitos": 6,
      "n_actividades": 21,
      "n_requeridas_en_este_tier": 21
    },
    "n_documentos": 7,
    "chars_evidencia": 812445,
    "generado_utc": "2026-07-30T14:30:52Z",
    "prompt_hash": "a3f9c1e2b7d0"            // compatibilidad hacia atrás
  },
  "integridad": {
    "actividades_evaluadas_ok": 19,
    "actividades_sin_evidencia": 2,
    "actividades_con_fallo_tecnico": 0,
    "detalle_fallos": [],
    "dictamen_confiable": true
  },
  "score_global": 3.42,                       // null si nada fue evaluable
  "semaforo": { "label": "...", "color": "..." },
  "scores_por_ambito": { "Metodología": 3.8, "Gobierno": null },
  "resultados_por_ambito": {
    "Metodología": [{
      "puntaje": 4,
      "concepto": "...",
      "observacion": "...",
      "evidencia_encontrada": "...",
      "preguntas_pendientes": ["..."],
      "recomendacion": "...",
      "actividad": "...",
      "control": "...",
      "rag_dominio": "LaR",
      "rag_chunks": 3
    }]
  },
  "controles_calidad_datos": { "...": "..." },
  "override_validador": { "...": "..." },
  "validacion_humana": {                      // solo --prdc
    "validador": "Ana Pérez",
    "cargo": "Validador de Segunda Línea",
    "aviso_segregacion": "..."                // si aplica
  },
  "custodia": {                               // SIEMPRE lo último
    "hash_este_informe": "...",
    "hash_informe_anterior": "...",
    "hash_cadena": "...",
    "posicion_en_cadena": 4,
    "timestamp_generacion": "...",
    "version_evidencia_usada": { "...": "..." }
  }
}
```

### `--prdc` vs sin `--prdc`

| | sin `--prdc` (pre-producción) | con `--prdc` (producción) |
|---|---|---|
| JSON de resultados | ✅ | ✅ |
| Informe Word | ❌ | ✅ |
| Firma del validador | no se pide | **obligatoria** |
| Registro de aprobación | ❌ | ✅ `registro_validadores.json` |
| Aviso de segunda revisión | ❌ | ✅ si 3+ firmas consecutivas |
| `calidad_proceso_*.json` | ❌ | ✅ (interno) |
| Bucle de feedback | ✅ interactivo | ❌ |
| Caché de documentos | ✅ | ✅ (ya no se apaga) |
| Sellado de custodia | ✅ | ✅ |

---

## 17. Scripts auxiliares

### `scripts/generar_corpus_rag.py`

Genera un corpus de literatura de referencia en PDF para los 4 dominios RAG, a partir de
marcos regulatorios públicos.

```bash
python scripts/generar_corpus_rag.py            # genera los PDF
python scripts/generar_corpus_rag.py --indexar  # genera + reindexa el RAG
python scripts/generar_corpus_rag.py --listar   # solo muestra el catálogo
```

> ⚠️ **Leer antes de usar.** Son **resúmenes secundarios** redactados a partir de marcos
> públicos. **No** son los textos oficiales, no los sustituyen y **no tienen valor normativo**.
> Existen para que el RAG tenga contexto de dominio cuando no se dispone de la documentación
> oficial. Cada PDF lleva el aviso en su primera página **y en el pie de cada página**, de modo
> que si un fragmento se recupera e inyecta en un prompt, el modelo vea la advertencia junto al
> contenido. Antes de emitir un dictamen que se presente a un supervisor, **sustitúyelos por
> los textos oficiales** (la referencia primaria de cada uno está en su portada y en el campo
> `fuente` del catálogo).

Es un generador y no ocho ficheros a mano para que el corpus se amplíe añadiendo entradas a
`CORPUS`, se regenere con un comando, y quede trazable qué produjo cada documento.
Test: `TestCorpusRagSeDeclaraComoResumenSecundario`.

### `scripts/rebuild_rag_databricks.py`

Reconstruye los índices RAG. Ejecutar mensualmente, al añadir documentos a `inputs/`, o tras
cambios en la lógica de chunking.

```bash
python scripts/rebuild_rag_databricks.py --dominio {LaR|VaR|conductuales|shared|all}
python scripts/rebuild_rag_databricks.py --dominio all --force   # borra el índice existente
python scripts/rebuild_rag_databricks.py --status                # verificar sin reconstruir
```

Job de Databricks sugerido: single-node DBR 14+, cron `0 2 1 * *`, timeout 60 min,
`%pip install chromadb sentence-transformers`.

### `scripts/reconstruir_estandar_desde_informes.py`

Reconstruye `inputs/Estandares_VIRF.xlsx` a partir de los informes ya emitidos.

```bash
python scripts/reconstruir_estandar_desde_informes.py --listar
python scripts/reconstruir_estandar_desde_informes.py --escribir
```

> ⛔ **Por qué existe.** El 30/07/2026 se **destruyó** `inputs/Estandares_VIRF.xlsx`. Causa: un
> barrido de imports con `importlib` sobre todos los módulos del proyecto ejecutó el código de
> nivel superior de `create_estandares_excel.py`, que sobrescribió el fichero con un esqueleto
> de 3 filas. No había copia de seguridad y el proyecto no es un repositorio git.
>
> Los informes de `outputs/` conservan las actividades realmente evaluadas, así que el texto de
> cada actividad y su ámbito **sí** son recuperables. Lo que **no** se puede recuperar: la
> matriz TIER I/II/III/IV, las actividades que nunca aparecieron en un informe, y las columnas
> `CONCEPTO` y `VALIDACIÓN_*`.
>
> ⚠️ **Consecuencia que debes asumir:** este script marca **todas** las actividades como
> requeridas en los **cuatro** tiers, porque no hay forma de saber la matriz real.

**La regla general que deja el incidente:** en un proyecto con scripts generadores, **nunca**
verifiques imports con `importlib`. Usa análisis estático (`ast.parse` o `compileall`), que no
ejecuta nada.

### `create_estandares_excel.py`

Genera un **esqueleto** de `Estandares_VIRF.xlsx` (3 filas de ejemplo), útil para arrancar un
proyecto desde cero — **jamás** para reemplazar un estándar en uso. El estándar real tiene ~21
actividades en 6 ámbitos con su matriz TIER I-IV.

```bash
python create_estandares_excel.py            # se NIEGA a sobrescribir un fichero existente
python create_estandares_excel.py --forzar   # sobrescribe (destructivo)
```

Dos protecciones tras el incidente, porque una sola no basta: la guarda `if __name__ ==
"__main__"` (para que importar el módulo no ejecute nada) y la negativa a sobrescribir sin
`--forzar` (para que ni ejecutarlo por error destruya un estándar en uso).

### `test_api_key.py`

Comprobación mínima e independiente de la credencial, sin arrancar el agente.

```bash
python test_api_key.py
```

---

## 18. Verificación del proyecto y tests

### `validate_project.py` — 13 bloques, coste 0

```bash
python validate_project.py            # informe con PASS / WARN / FAIL
python validate_project.py --strict   # exit code 1 si hay algún FAIL
```

No llama a la API. Los bloques que ejecuta (`validate_project.py:917-955`):

| Bloque | Qué verifica |
|---|---|
| `val_estructura` | Carpetas y ficheros esperados |
| `val_seguridad` | Credenciales no commiteadas, `.gitignore`, fugas en `.env.example` |
| `val_config` | Coherencia de la configuración; que `config/` y `Mx_00` no divergieran |
| `val_dependencias` | Paquetes de `requirements.txt` instalados |
| `val_estandar_y_evidencia` | El Excel de estándares y las carpetas de evidencia |
| `val_patrones_cache_modulos` | Patrones de uso del caché en los módulos |
| `val_cobertura_documentos` | Que la cobertura documental no se infle |
| `val_salidas` | Estructura de las salidas |
| `val_codigo_muerto` | Código sin conectar |
| `val_invariantes_auditoria` | Los invariantes de la auditoría exhaustiva |
| `val_cumplimiento_regulatorio` | Custodia, firma humana, override |

Resumen final:
```
  ✅ PASS :  85 / 88
  ⚠️  WARN :   3 / 88
  ❌ FAIL :   0 / 88

  🟡 Sin errores críticos. Revisa los WARN (suelen ser evidencia ausente).
```

### Suite de regresión

```bash
pytest                                    # toda la suite
pytest tests/test_regresion.py -v
pytest -k "Custodia or Multimodelo"       # por nombre
```

`pytest.ini` excluye `archivo/`, `outputs/`, `data/` e `inputs/` de la recolección:
`archivo/` contiene código archivado cuyos tests importan módulos que ya no están en el árbol
activo y ensuciarían el resultado con fallos irrelevantes.

Tres ficheros:
- `tests/test_regresion.py` — ~60 clases. Bloques funcionales (`TestConfiguracion`,
  `TestLectura`, `TestChunking`, `TestContrato`, `TestScores`, `TestFeedback`, `TestCache`,
  `TestMotoresDatos`, `TestWord`, `TestPipelineControles`, `TestSalidas`, `TestIntegridad`,
  `TestParserEstandares`, `TestPDFReal`) + una clase `TestAuditoria*` **por cada hallazgo de
  auditoría corregido**, que fija el invariante para que no vuelva.
- `tests/test_estructura_config.py` — estructura del paquete `config/`.
- `tests/test_azure_mocks.py` — proveedor Azure con dobles de prueba.
- `tests/fixtures/modelos_sinteticos/` — 3 modelos completos (`PD_Retail`, `FraudeAML`,
  `IFRS9_Provisiones`) para probar que el agente es agnóstico al modelo.

---

## 19. Variables de entorno — referencia completa

Única fuente de verdad: `config/parametros.py`. Ningún otro módulo debe llamar a `os.getenv`
para un parámetro de negocio.

**Por qué importa.** Antes de v27.2 la configuración estaba repartida y, en varios casos,
**duplicada con defaults independientes**: `VIRF_MAX_CTX` estaba en `agente.py` **y** en
`chunker.py` **con defaults distintos**. Con una sola declaración por parámetro, la divergencia
deja de ser posible por construcción.

### Generales
| Variable | Default | Qué hace |
|---|---|---|
| `IA_PROVEEDOR` | `azure_openai` | `azure_openai` \| `anthropic`. Sin fallback automático. |
| `MODO` | `debug` | `debug` \| `produccion` |
| `VIRF_AGENTE_VERSION` | `27.1` | Viaja al JSON de auditoría |
| `TIMEOUT_SEGUNDOS` | `30` | Timeout de las llamadas |
| `REINTENTOS_API` | `3` | Reintentos |

### Lectura de documentos
| Variable | Default | Qué hace |
|---|---|---|
| `MAX_CHARS_DOC` | `15000` | Chars por documento |
| `MAX_CHARS_CODIGO` | `8000` | Tope de un fichero de código **solo si `VIRF_CHUNK_ENABLED=0`**. Con el chunking activo (el default) el `.py`/`.ipynb` se entrega íntegro — ver §7-bis |
| `MAX_FILAS_EXCEL` | `200` | Filas leídas por hoja |
| `VIRF_MAX_CTX` | = `MAX_CHARS_DOC` | Contexto máximo por llamada |
| `VIRF_MAX_DOCS_AMBITO` | `0` | Tope de documentos por ámbito. **0 = sin límite** (valor válido, no error) |

### Proveedor IA
| Variable | Default | Qué hace |
|---|---|---|
| `ANTHROPIC_API_KEY` | — | Credencial Anthropic |
| `ANTHROPIC_MODELO` | `claude-sonnet-4-6` | Modelo Anthropic |
| `ANTHROPIC_MAX_TOKENS` | `4096` | Tokens de salida |
| `ANTHROPIC_BASE_URL` | — | Endpoint alternativo / proxy |
| `AZURE_OPENAI_ENDPOINT` | — | Portal → recurso → Keys and Endpoint |
| `AZURE_OPENAI_DEPLOYMENT` | — | ⚠️ El **Deployment name**, NO el nombre del modelo |
| `AZURE_OPENAI_API_KEY` | — | Credencial Azure |
| `AZURE_OPENAI_API_VERSION` | `2024-10-21` | GA estable a propósito: una `preview` puede cambiar de comportamiento sin aviso, y este sistema exige corridas reproducibles |
| `AZURE_OPENAI_MAX_TOKENS` | `4096` | Tokens de salida |
| `VIRF_VALIDAR_CONEXION` | `0` | Gasta 1 request de prueba al arrancar. Off por defecto: un fallo de credenciales se manifiesta igual en la primera llamada real |

### Chunking
Ver la tabla de §11.

### Caché
| Variable | Default | Qué hace |
|---|---|---|
| `CACHE_ENABLED` | `1` | Activa el caché |
| `VIRF_CACHE_LOCK_TIMEOUT` | `10` | Segundos de espera por el lock |
| `VIRF_CACHE_LOCK_STALE` | `60` | Segundos tras los que un lock se considera huérfano |

### Excel → Notebook
| Variable | Default | Qué hace |
|---|---|---|
| `EXCEL_MAX_CELDAS_MUESTRA` | `500` | Celdas muestreadas por hoja |
| `EXCEL_MAX_FORMULAS_HOJA` | `2000` | Fórmulas extraídas por hoja |
| `EXCEL_CHUNK_HOJA_UMBRAL` | `80` | A partir de cuántas fórmulas se trocea la hoja |
| `EXCEL_VALIDACION_TOL` | `1e-6` | Tolerancia numérica de la auto-validación |
| `EXCEL_NB_TIMEOUT` | `120` | Timeout de ejecución del notebook (s) |

### Feedback y diagnóstico
| Variable | Default | Qué hace |
|---|---|---|
| `DEBUG_PROMPTS` | `0` | Vuelca los prompts |
| `VIRF_MIN_FEEDBACK_ANTISESGO` | `15` | Masa crítica por ámbito para el bloque de calibración |
| `VIRF_MIN_MUESTRAS_AJUSTE` | = anterior | Muestras por actividad para el ajuste numérico del puntaje |

### RAG
| Variable | Default | Qué hace |
|---|---|---|
| `RAG_TOP_K` | `3` | Fragmentos recuperados (mín. 1) |
| `RAG_MIN_SCORE` | `0.35` | Similitud mínima (0.0–1.0) |

### Cumplimiento
| Variable | Default | Qué hace |
|---|---|---|
| `VIRF_VALIDADOR` | vacío | Nombre del validador (para corridas no interactivas) |
| `VIRF_VALIDADOR_CARGO` | vacío | Cargo del validador |
| `VIRF_UMBRAL_SEGUNDA_REVISION` | `3` | Firmas consecutivas tras las que se advierte (mín. 2) |

> Si `VIRF_VALIDADOR`/`_CARGO` están vacías —el caso normal— el informe de producción **se
> rechaza igualmente**. Definirlas es una decisión explícita del operador, equivalente a firmar.

**Auto-setup del `.env`.** Si no existe, se copia de `.env.example` en el primer arranque con
un aviso claro (`agente.py:96-113`). Solo hay que editar la credencial.

---

## 20. Recetas de uso

### Verificación antes de gastar (coste 0)

```bash
python validate_project.py --strict          # integridad del proyecto
python agente.py --listar-motores            # qué pruebas de datos existen
python agente.py --cache-stats               # estado del caché
python agente.py --explicar-modelo "LaR" --dry-run   # inventario + coste estimado
python agente.py --verificar-conexion-azure  # 1 llamada mínima: credencial + modelo + perfil
```

### Validación completa de un modelo, de principio a fin

```bash
# 1. Comprobar que el proyecto está sano
python validate_project.py --strict

# 2. Ver qué evidencia hay y cuánto costará documentarla
python agente.py --explicar-modelo "LaR" --dry-run

# 3. Generar el documento de entendimiento del modelo
python agente.py --explicar-modelo "LaR"

# 4. Corrida de pre-producción + registrar feedback al final
python agente.py --titulo "Modelo LaR" --tier 1

# 5. Corrida de producción con firma
python agente.py --titulo "Modelo LaR" --tier 1 --prdc \
                 --validador "Ana Pérez" --cargo "Validador de Segunda Línea"

# 6. Sellar la auditoría
python agente.py --verificar-cadena "Modelo LaR"
python agente.py --verificar-evidencia outputs/2026-07-30/resultados_Modelo_LaR_2026-07-30.json
python agente.py --historial-validaciones
```

### Varios modelos en el mismo repositorio

```bash
python agente.py --titulo "Modelo LaR"      --tier 1 --raiz-evidencia .
python agente.py --titulo "VaR Mercado FRTB" --tier 1 --raiz-evidencia modelos/VaR_FRTB
python agente.py --explicar-modelo "VaR_FRTB"        --raiz-evidencia modelos/VaR_FRTB
```

### Validación de Calidad de Datos con datos reales

```bash
# Ver qué pruebas puedo declarar en el Excel
python agente.py --listar-motores

# Ejecutar los controles contra los datasets
python agente.py --titulo "Modelo LaR" --tier 1 \
                 --excel inputs/calidad_datos/ControlesData.xlsx --control \
                 --datasets inputs/calidad_datos/datasets

# Contrastar lo documentado contra lo ejecutado
python agente.py --controles-a-notebook inputs/calidad_datos/manual_controles_datos.md \
                 --excel inputs/calidad_datos/ControlesData.xlsx
```

### Un modelo que vive en Excel

```bash
# Reconocimiento gratis: estructura y fórmulas sin traducir
python agente.py --convertir-excel inputs/modelo_excel/ --sin-llm

# Traducción completa con auto-validación contra el Excel evaluado
python agente.py --convertir-excel inputs/modelo_excel/

# Revisar el Anexo C (fórmulas peligrosas) y el Anexo D (auto-validación)
# antes de mover nada a inputs/implementacion/
```

### Diagnóstico y mantenimiento

```bash
python agente.py --estadisticafeedback                     # precisión del agente
python agente.py --limpiar-cache                           # documentos + resúmenes
python agente.py --titulo "LaR" --tier 1 --no-cache        # corrida limpia
pytest -k "Auditoria"                                      # invariantes de auditoría
python scripts/rebuild_rag_databricks.py --status           # estado del RAG
```

### Bajar el coste de una corrida

```bash
# El default (MAX_CHUNKS=40) ya es el óptimo medido. NO bajarlo sin subir CHUNK_SIZE_MAX.
export VIRF_MAX_CHUNKS=40
export VIRF_CHUNK_SIZE_MAX=40000

# Mantener el caché activo (lo está por defecto) — es donde está el ahorro real
# Regenerar un documento ya resumido no vuelve a pagar el chunking
```

---

## Errores frecuentes y qué significan

| Mensaje | Causa | Solución |
|---|---|---|
| `--tier X no es un tier válido` | Tier fuera de `1-4`/`I-IV` | Se rechaza antes de gastar. Corrige el valor |
| `❌ API key rechazada (Error 401)` | Credencial inválida | Revisa `ANTHROPIC_API_KEY` o las 4 variables de Azure |
| `❌ No hay conexión con el proveedor de IA` | Red, proxy o `BASE_URL` | Los modos sin API siguen disponibles (§2) |
| `⚠️ Carpetas sin documentos: ...` | Árbol de evidencia a medio montar | Esos ámbitos puntuarán 0.0; monta las carpetas o usa `--raiz-evidencia` |
| `✗ [Ámbito] SIN DOCUMENTOS — evaluación rechazada` | D3-FIX anti-alucinación | Añade evidencia. El agente no evalúa sobre el vacío |
| `⚠️ NO emitir dictamen: la evaluación está incompleta` | `dictamen_confiable=False` | Revisa `detalle_fallos` en el JSON y re-ejecuta |
| `Score global: NO EVALUABLE` | Ningún ámbito tenía evidencia | **No** significa que el modelo sea deficiente |
| `❌ Se requiere validador y cargo` | `--prdc` sin firma | Pasa `--validador`/`--cargo` o define `VIRF_VALIDADOR` |
| `⚠️ 3 firmas consecutivas sin segunda revisión` | Posible auto-aprobación | No bloquea. Queda constancia en el informe |
| `ℹ️ ControlesData.xlsx no encontrado` | Falta el Excel de controles | Los controles CDD se omiten; el resto del pipeline sigue |
| `UnicodeEncodeError` | No debería ocurrir | `configurar_consola()` lo previene; si aparece, reporta el módulo |

---

## Limitaciones conocidas

- **`--titulo` no filtra la evidencia.** Solo rotula y elige el dominio RAG. Para aislar
  modelos usa `--raiz-evidencia` (§12) o `--solo-coincidentes` en el explicador.
- **El corpus RAG generado son resúmenes secundarios**, sin valor normativo. Sustitúyelos por
  los textos oficiales antes de presentar un dictamen a un supervisor (§17).
- **`reconstruir_estandar_desde_informes.py` no recupera la matriz de tiers**: marca todo como
  requerido en los cuatro (§17).
- **La detección de auto-aprobación avisa pero no bloquea**, por diseño (§5.1).
- **No hay fallback automático entre proveedores IA**: si Azure falla, la corrida falla.
- El proyecto **no es un repositorio git**, lo que ya costó la destrucción del estándar. Ver el
  registro completo de auditoría en `README.md` §12.
