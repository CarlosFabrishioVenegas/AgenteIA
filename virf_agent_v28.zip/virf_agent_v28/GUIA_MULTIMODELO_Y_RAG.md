# Guía — Validar varios modelos y poblar el RAG

Dos cosas que se confunden a menudo y conviene separar desde el principio:

| | **Evidencia** | **RAG** |
|---|---|---|
| Qué es | Los documentos **del modelo** que se valida | Conocimiento **de dominio** compartido |
| Dónde vive | `inputs/` (o la raíz que indiques) | `data/vectordb/<dominio>/` |
| Se usa para | Emitir el dictamen | Ayudar al modelo a reconocer conceptos técnicos |
| ¿Obligatorio? | **Sí** | No — es un refuerzo |
| Por modelo | **Uno por modelo** | Compartido por familia |

**El agente NO necesita conocer tu modelo de antemano.** Su vara de medir es
`Estandares_VIRF.xlsx`: preguntas del tipo *«¿existe control de versiones?»*, *«¿se justificó
la elección de la distribución?»*. Esas preguntas son las mismas para un VaR, un scoring de
PD o un IFRS9. Lo que cambia es la respuesta que encuentre **en tus documentos**.

---

# Parte 1 — Validar un modelo nuevo

## 1.1. Montar el árbol de evidencia

Una carpeta por modelo. Estructura obligatoria:

```
modelos/
└── VaR_FRTB/
    └── inputs/
        ├── documentacion/
        │   ├── modelamiento/     ← manual metodológico
        │   └── seguimiento/      ← backtesting, informes periódicos
        ├── papers/               ← literatura de referencia
        ├── implementacion/       ← scripts, código productivo
        ├── usos/                 ← actas de comité, evidencia de uso real
        └── calidad_datos/        ← perfilado, ControlesData.xlsx, datasets
```

**Los nombres de carpeta importan** — son los que `AMBITO_A_INPUTS` mapea a cada ámbito. Un
`documentacion/manual.pdf` suelto (sin el subdirectorio `modelamiento/`) no se lee.

### Qué alimenta a qué

| Ámbito | Lee de |
|---|---|
| Documentación | `doc_modelamiento`, `doc_seguimiento`, `papers` |
| Calidad de datos | `calidad_datos`, `doc_modelamiento` |
| Metodología | `doc_modelamiento`, `papers`, `doc_seguimiento` |
| Gobierno | `doc_modelamiento`, `implementacion` |
| Implementación | `implementacion`, `doc_modelamiento` |
| Uso e integración | `usos`, `implementacion` |

**Sobre los papers:** van en `inputs/papers/` y se usan **de inmediato**, como contexto
directo del prompt en Documentación y Metodología. No hacen falta índices ni RAG. Es la vía
más rápida de dar conocimiento de dominio al agente.

Una carpeta vacía no es neutra: los ámbitos que dependan de ella puntuarán **0.0 (sin
evidencia)**, que la política trata como falta crítica. El agente lo avisa al arrancar.

## 1.2. Ejecutar

```bash
python agente.py --titulo "VaR Mercado FRTB" --tier 1 \
                 --raiz-evidencia modelos/VaR_FRTB --prdc
```

`--raiz-evidencia` es la clave del multimodelo. Sin él, el agente lee **todo** `inputs/` y la
evidencia de varios modelos se evalúa como si fuera de uno solo: el manual del LaR podría
citarse como evidencia del VaR. Indefendible ante un regulador.

**Qué se redirige y qué no:**

| Elemento | Con `--raiz-evidencia` |
|---|---|
| Las 6 carpetas de evidencia | ✅ se redirigen |
| `Estandares_VIRF.xlsx` | ❌ sigue en el proyecto — es la vara de medir **común** |
| `outputs/` | ❌ sigue en el proyecto — todos los informes juntos |
| `data/cache/` | ❌ sigue en el proyecto — indexado por SHA-256, sin colisiones |

Que el estándar no se mueva es deliberado: si cada carpeta trajera el suyo, dos modelos
podrían validarse contra criterios distintos sin que nadie lo notara.

Si la ruta no existe o no contiene `inputs/`, el agente **aborta** mostrando la estructura
esperada. Prefiere fallar a evaluar en silencio con las carpetas por defecto y emitir el
informe del modelo equivocado.

### ⚠️ Comprueba siempre la procedencia, no el volumen

El mensaje `📂 Evidencia: ...` de la consola indica **lo que se pidió**, no necesariamente lo
que se leyó. La única prueba de que se evaluó el modelo correcto está en el JSON:

```python
import json, pathlib
d = json.loads(pathlib.Path("outputs/<fecha>/resultados_<modelo>_<fecha>.json").read_text(encoding="utf-8"))
for ruta, meta in d["agente"]["documentos_huella"].items():
    print(f"{ruta}  ({meta['chars']} chars, sha256 {meta['sha256']})")
```

Esto no es una precaución teórica. Una versión de `--raiz-evidencia` anunciaba
`Evidencia: modelos/VaR_FRTB` mientras leía la evidencia del proyecto, y produjo un informe
titulado «VaR Mercado FRTB» cuya huella contenía `Manual_Metodologico_LaR_completo.pdf`
(bug #41, §2.6). El recuento de caracteres parecía plausible y no delataba nada: **solo la
huella documental responde la pregunta.**

## 1.3. Ejemplo real verificado

En `modelos/VaR_FRTB/` hay un árbol de ejemplo completo. Su corrida en tier 1, con el
aislamiento y el RAG ya funcionando:

```
📂 Evidencia: .../modelos/VaR_FRTB
🔎 INTEGRIDAD: 19 evaluadas OK · 0 sin evidencia · 0 fallos técnicos
📊 Score global: 3.18/5.0 [CON OBSERVACIONES]
   Documentación   4.00     Gobierno        2.00
   Calidad datos   3.60     Implementación  2.50
   Metodología     3.60     Uso e integr.   2.00
   Controles CDD: 3/4 (7 hallazgos críticos)
✅ JSON + Word emitidos    huella: 8d84b297e071
```

Huella documental verificada: **6 de 6 documentos del árbol de VaR, ninguno del proyecto.**

Los ámbitos bajos son coherentes con la evidencia del ejemplo, que no incluye inventario de
modelos ni tiering (Gobierno) y solo un acta de comité (Uso). El agente no inventó
documentación ausente.

Puedes borrar esa carpeta cuando quieras; sirve solo de plantilla.

---

# Parte 2 — Poblar el RAG

## 2.1. Qué aporta y qué no

El RAG inyecta fragmentos de literatura técnica en el prompt de cada actividad. Ante *«¿se
realizaron pruebas de Kupiec?»*, aporta la definición de la prueba para que el modelo
reconozca si lo que ve en el manual **es** un backtesting de Kupiec o solo un párrafo con
números.

**No es obligatorio.** Sin índice, `query()` devuelve lista vacía y la validación continúa
sin contexto adicional. Es un refuerzo de calidad, no un requisito.

### Literatura de referencia ≠ evidencia del modelo

Es la distinción que gobierna todo el diseño del RAG:

| | Va en | Se usa para |
|---|---|---|
| **Evidencia** del modelo validado | `inputs/` o `--raiz-evidencia` | Emitir el dictamen |
| **Literatura** de referencia | `inputs/rag/<dominio>/` | Reconocer conceptos técnicos |

Los indexadores leían de las carpetas de evidencia, lo que producía **razonamiento
circular**: ante «¿el manual documenta el backtesting?», el RAG recuperaba fragmentos del
propio manual y los inyectaba bajo el epígrafe «Conocimiento recuperado». El agente se daba
la razón a sí mismo con la fuente que estaba juzgando (§2.6).

> ⚠️ **El RAG NO sigue a `--raiz-evidencia`.** Es intencional: la literatura de dominio es
> compartida por familia de modelos, no propia de uno. Un mismo corpus de FRTB sirve para
> todos los modelos de mercado que valides.

## 2.2. Los cuatro dominios

| Dominio | Se activa con títulos que contengan |
|---|---|
| `LaR` | lar, liquidity, liquidez, lic, hqla |
| `VaR` | var, value at risk, frtb, market risk, riesgo de mercado |
| `conductuales` | conductual, prepago, retiro, nmd, comportamiento, behavioural |
| `shared` | *(todo lo demás — regulación transversal)* |

```python
from src.rag import inferir_dominio
inferir_dominio("VaR Mercado FRTB")       # → 'VaR'
inferir_dominio("Scoring PD Retail")      # → 'shared'
```

Un modelo que caiga en `shared` **funciona igual**; solo pierde el conocimiento
especializado.

## 2.3. Estado actual del corpus

Los cuatro dominios están poblados con un corpus generado a partir de marcos regulatorios
públicos:

| Dominio | Fragmentos | Documentos |
|---|---:|---|
| `shared` | **19** | SR 11-7 · BCBS 239 · Validación interna UE |
| `VaR` | **14** | FRTB (BCBS 457) · Backtesting Kupiec/Christoffersen |
| `LaR` | **11** | LCR (BCBS 238) · NSFR (BCBS 295) |
| `conductuales` | **7** | IRRBB y modelos conductuales (NMD, prepago) |

> ⚠️ **Son RESÚMENES SECUNDARIOS, no los textos oficiales.** Cada PDF lleva el aviso en su
> portada, en el pie de cada página y —lo importante— **dentro de su texto indexable**: si un
> fragmento se recupera e inyecta en un prompt, el modelo ve la advertencia junto al
> contenido. Cada documento cita además su fuente primaria.
>
> **Sustitúyelos por los textos oficiales antes de emitir un dictamen que se presente a un
> supervisor.** Los conceptos y estructuras están completos; varios umbrales numéricos
> (recortes del LCR, sublímites de Nivel 2B, plazos de repreciación de NMD) se dejaron
> deliberadamente sin cifra y remiten al texto oficial, porque han cambiado con las
> revisiones y difieren según la transposición local.

### Regenerar o ampliar el corpus

```bash
python scripts/generar_corpus_rag.py --listar    # ver el catálogo
python scripts/generar_corpus_rag.py             # generar los PDF
python scripts/generar_corpus_rag.py --indexar   # generar + reindexar
```

Ampliar es añadir una entrada al diccionario `CORPUS` del script y volver a ejecutar. Así el
corpus es reproducible y queda trazable qué produjo cada documento.

## 2.4. Poblar con documentos propios

Suelta los PDF oficiales en la carpeta del dominio y reindexa. Cada carpeta tiene un
`README.md` con la lista concreta de documentos que espera:

```
inputs/rag/LaR/           ← Basilea III LCR/NSFR (BCBS 238, 295), EBA ILAAP
inputs/rag/VaR/           ← FRTB (BCBS 457), Kupiec 1995, Christoffersen 1998
inputs/rag/conductuales/  ← prepago, NMD, EBA/GL/2022/14 (IRRBB)
inputs/rag/shared/        ← SR 11-7, EBA/GL, BCBS 239, TRIM Guide
```

```python
from src.rag.VaR.indexer import VaRIndexer
VaRIndexer().build_index(force_rebuild=True)
```

Formatos: `.pdf` · `.docx` · `.pptx` · `.xlsx` · `.py` · `.txt` · `.md`.
Los ficheros llamados `README` se excluyen del índice: explican qué va en la carpeta, no son
conocimiento del dominio.

## 2.5. Verificar que funciona

**a) El índice tiene contenido y es el correcto:**

```python
from src.rag import get_retriever
res = get_retriever(tipo_modelo="VaR").query("prueba de Kupiec y excedencias", top_k=3)
for c in res:
    print(f"[{c['fuente']}] {c['score']}")
    print(c['texto'][:200])
```

Cada dominio debe devolver **solo sus propios documentos**. Si el índice de VaR devuelve
literatura de liquidez, hay contaminación cruzada.

**b) El RAG llega de verdad al evaluador.** Es la comprobación que importa, y se hace sobre
el JSON de una corrida real:

```python
import json, pathlib
d = json.loads(pathlib.Path("outputs/<fecha>/resultados_<modelo>_<fecha>.json").read_text(encoding="utf-8"))
for amb, evs in d["resultados_por_ambito"].items():
    for e in evs:
        print(amb, e.get("rag_dominio"), e.get("rag_chunks"))
```

`rag_chunks = 0` en todas las actividades significa que el RAG **no aportó nada**, aunque el
índice exista. Medido en la corrida de ejemplo del VaR: **15 de 15 actividades con 3
fragmentos cada una** (45 en total), todas del dominio `VaR`, y la terminología del corpus
apareció en las observaciones — FRTB 18 veces, Christoffersen 16, Kupiec 15, zona verde 5,
Expected Shortfall 5, PLAT 3, NMRF 1.

**Qué mirar cuando algo falla:**

- **`len(res) == 0`** → índice vacío, o los fragmentos no superan `RAG_MIN_SCORE` (0.35).
- **Recuento de fragmentos muy bajo** con documentos sustanciales → algo no se está leyendo;
  revisa el log, los ficheros ilegibles se omiten con un *warning*.
- **Texto que parece un mensaje de error** → no debería ocurrir (§2.6); reconstruye con
  `force_rebuild=True`.

Ajustes por entorno:

```bash
RAG_TOP_K=5        # fragmentos por actividad (default 3)
RAG_MIN_SCORE=0.30 # umbral de similitud 0-1 (default 0.35)
RAG_VECTORDB_DIR=/ruta/alternativa
```

`RAG_MIN_SCORE=5` **no** es «más estricto»: filtraría todos los fragmentos y dejaría el RAG
mudo. El agente rechaza los valores fuera de [0,1] con un aviso.

## 2.6. Defectos corregidos al poblar el RAG por primera vez

Se documentan porque explican por qué el índice estaba vacío o inservible, y qué mirar si
algo va mal.

**#39 — el índice se contaminaba con sus propios errores.** `_leer_archivo()` calculaba la
raíz del proyecto con un `.parent` de más y aterrizaba fuera. Los lectores de `Mx_01`
quedaban inalcanzables, se caía a un *fallback* que solo entiende `.txt`, y ese *fallback*
devolvía `"[No se pudo leer: X]"` **como contenido**. Ese texto se troceaba y se indexaba: el
fragmento con mayor similitud para una consulta sobre backtesting era literalmente
`[No se pudo leer: riskmetrics_summary.md]`. **El RAG inyectaba sus propios errores en el
prompt haciéndolos pasar por conocimiento experto.** Hoy un fichero ilegible se omite y se
registra en el log.

**#40 — los documentos grandes se caían enteros.** El identificador de cada fragmento era
`sha256(texto_del_fragmento)`. Dos fragmentos con el mismo texto —cabeceras o pies
repetidos, constante en un documento largo— colisionaban y ChromaDB rechazaba el fichero
**completo**, con el fallo reducido a una línea de *warning* entre decenas. Medido:
`Manual_Metodologico_LaR_completo.pdf` daba 11 IDs duplicados y quedaba fuera del índice. El
ID incorpora ahora fuente y posición. **Resultado: de 5 fragmentos a 1.538.**

**Razonamiento circular y contaminación cruzada.** Los cuatro dominios indexaban las
carpetas de evidencia, y además las mismas. Al poblarlos: LaR 1.548 fragmentos, VaR 1.538,
conductuales 1.540 — y los tres eran **el mismo manual de LaR**. Consultando el índice de VaR
sobre backtesting FRTB, los tres primeros resultados eran del manual de LaR con similitud
**0.88**, muy por encima del umbral. Validar un modelo de mercado le inyectaba el manual de
uno de liquidez como conocimiento experto de su dominio.

**#41 — `--raiz-evidencia` no llegaba al lector.** No es un bug del RAG pero afecta al mismo
flujo multimodelo. `Mx_00_CargaRutas` vive **dos veces** en `sys.modules` con identidades
distintas —`Mx_00_CargaRutas` (import directo, porque `motor/` está en `sys.path`) y
`motor.Mx_00_CargaRutas` (cualificado)—, cada una con su propio dict `RUTAS`. `agente.py`
mutaba una copia y `Mx_01` leía la otra. El fallo era **silencioso**: la consola anunciaba
`Evidencia: modelos/VaR_FRTB` mientras leía la del proyecto, y se emitió un informe titulado
«VaR Mercado FRTB» cuya huella contenía `Manual_Metodologico_LaR_completo.pdf`.
`redirigir_evidencia()` actualiza ahora todas las copias cargadas del módulo.

De aquí sale la regla de §1.2: **comprueba la procedencia, no el volumen.**

---

# Resumen operativo

**Modelo nuevo, mínimo indispensable:**

```bash
mkdir -p modelos/MiModelo/inputs/{documentacion/{modelamiento,seguimiento},papers,implementacion,usos,calidad_datos}
# copiar la evidencia a cada carpeta
python agente.py --titulo "Mi Modelo" --tier 1 --raiz-evidencia modelos/MiModelo --prdc
```

**Comprobar que se evaluó el modelo correcto** (no opcional):

```bash
python -c "import json,pathlib,sys; d=json.loads(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8')); [print(k) for k in d['agente']['documentos_huella']]" outputs/<fecha>/resultados_<modelo>_<fecha>.json
```

**Añadir conocimiento de dominio (opcional):**

```bash
# soltar los PDF oficiales en inputs/rag/<dominio>/, luego:
python -c "from src.rag.VaR.indexer import VaRIndexer; VaRIndexer().build_index(force_rebuild=True)"
```

**Antes de la primera corrida real:**

```bash
python validate_project.py --strict   # 119 comprobaciones, coste 0
python agente.py --limpiar-cache      # si el proyecto es anterior al 29/07/2026
```

---

*Guía verificada ejecutando cada comando · Agente VIRF v27.1 · 29 de julio de 2026*
*Estado: `validate_project.py --strict` 119/119 · `pytest` 317 passed*
