"""
tests/test_azure_mocks.py
═══════════════════════════════════════════════════════════════════════════════
Verificación del flujo completo con Azure OpenAI SIMULADO.

No hay credencial de Azure todavía, así que estas pruebas reproducen la FORMA
EXACTA de una respuesta de `chat.completions.create()` —incluidos sus modos de
fallo— y comprueban que todo el sistema la digiere.

Lo que estas pruebas SÍ demuestran:
  · que el cliente Azure construye la petición como espera la API;
  · que negocia `max_tokens` / `max_completion_tokens` en vez de adivinar;
  · que el parser aguanta las tres formas en que el modelo puede envolver el
    JSON;
  · que un fallo de Azure se reporta y DETIENE, sin caer a Anthropic;
  · que el pipeline entero corre de punta a punta con el proveedor simulado.

Lo que NO demuestran, y hay que verificar con la credencial real:
  · qué modelo sirve el deployment y su ventana de contexto;
  · la CALIDAD de los hallazgos (§14.7 de la guía de migración);
  · el comportamiento real del filtro de contenido de Azure.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

RAIZ = Path(__file__).parent.parent
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))


# ══════════════════════════════════════════════════════════════════════════════
# Dobles que imitan la forma real del SDK de OpenAI
# ══════════════════════════════════════════════════════════════════════════════

def respuesta_azure(texto: str, modelo: str = "gpt-4o-2024-11-20",
                    finish_reason: str = "stop"):
    """
    Réplica de `openai.types.chat.ChatCompletion` en lo que el proyecto consume.

    La forma importa: el cliente accede a `.choices[0].message.content`, a
    `.model` y a `.finish_reason`. Un mock con dicts en vez de atributos no
    detectaría una regresión ahí.
    """
    return SimpleNamespace(
        model=modelo,
        choices=[SimpleNamespace(
            message=SimpleNamespace(content=texto, role="assistant"),
            finish_reason=finish_reason, index=0)],
        usage=SimpleNamespace(prompt_tokens=100, completion_tokens=50,
                              total_tokens=150),
    )


class _Completions:
    def __init__(self, padre):
        self._p = padre

    def create(self, **kwargs):
        self._p.llamadas.append(kwargs)
        if self._p.excepcion is not None:
            exc = self._p.excepcion
            self._p.excepcion = self._p.excepcion_persistente and exc or None
            raise exc
        # Simula un modelo que solo acepta un nombre de parámetro de tokens.
        if self._p.param_exigido:
            if self._p.param_exigido not in kwargs:
                otro = ("max_tokens" if self._p.param_exigido == "max_completion_tokens"
                        else "max_completion_tokens")
                raise Exception(
                    f"Error code: 400 - Unsupported parameter: '{otro}' is not "
                    f"supported with this model. Use '{self._p.param_exigido}' instead.")
        r = self._p.respuestas.pop(0) if self._p.respuestas else respuesta_azure("{}")
        return r


class ClienteAzureFalso:
    """Sustituye a `openai.AzureOpenAI` sin tocar la red."""

    def __init__(self, respuestas=None, excepcion=None, param_exigido=None,
                 excepcion_persistente=True, **_):
        self.respuestas = list(respuestas or [])
        self.excepcion = excepcion
        self.excepcion_persistente = excepcion_persistente
        self.param_exigido = param_exigido
        self.llamadas = []
        self.chat = SimpleNamespace(completions=_Completions(self))


@pytest.fixture
def cliente_azure(monkeypatch):
    """Devuelve una fábrica de ClienteAzureOpenAIIA con el SDK simulado."""
    def _fabricar(**kw):
        import config.ia as ia
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "clave-de-prueba-0123456789")
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://falso.openai.azure.com/")
        monkeypatch.setenv("AZURE_OPENAI_DEPLOYMENT", "gpt4o-virf-prod")
        falso = ClienteAzureFalso(**kw)
        cli = object.__new__(ia.ClienteAzureOpenAIIA)
        cli.cliente = falso
        cli.deployment = "gpt4o-virf-prod"
        cli.max_tokens_default = 4096
        cli._modelo_real = None
        cli._perfil = None
        cli._param_tokens = None
        cli._admite_temperature = None
        return cli, falso
    return _fabricar


# ══════════════════════════════════════════════════════════════════════════════
# 1. El cliente construye la petición como espera la API
# ══════════════════════════════════════════════════════════════════════════════
class TestClienteAzureConstruyeBienLaPeticion:

    def test_el_sistema_va_como_primer_mensaje_no_como_parametro(self, cliente_azure):
        # `chat.completions.create()` NO tiene parámetro `system`: va dentro de
        # `messages` con role='system'. Enviarlo aparte da 400.
        cli, falso = cliente_azure(respuestas=[respuesta_azure("ok")])
        cli.generar_mensaje("prompt", instruccion_sistema="Eres auditor.")
        kw = falso.llamadas[0]
        assert "system" not in kw
        assert kw["messages"][0] == {"role": "system", "content": "Eres auditor."}
        assert kw["messages"][1]["role"] == "user"

    def test_usa_el_deployment_no_el_nombre_del_modelo(self, cliente_azure):
        cli, falso = cliente_azure(respuestas=[respuesta_azure("ok")])
        cli.generar_mensaje("prompt")
        assert falso.llamadas[0]["model"] == "gpt4o-virf-prod", (
            "debe llamarse al DEPLOYMENT; usar el nombre del modelo da 404 "
            "DeploymentNotFound")

    def test_devuelve_str_no_el_objeto_del_sdk(self, cliente_azure):
        cli, _ = cliente_azure(respuestas=[respuesta_azure("texto plano")])
        r = cli.generar_mensaje("prompt")
        assert isinstance(r, str) and r == "texto plano", (
            "el contrato de ClienteIA es devolver str: si se filtra el objeto "
            "del SDK, el negocio queda acoplado al proveedor")

    def test_formato_json_activa_response_format(self, cliente_azure):
        cli, falso = cliente_azure(respuestas=[respuesta_azure('{"a":1}')])
        cli.generar_mensaje("dame JSON", formato_json=True)
        assert falso.llamadas[0]["response_format"] == {"type": "json_object"}

    def test_sin_formato_json_no_se_envia_response_format(self, cliente_azure):
        cli, falso = cliente_azure(respuestas=[respuesta_azure("texto")])
        cli.generar_mensaje("prompt")
        assert "response_format" not in falso.llamadas[0]

    def test_memoriza_el_modelo_real_de_la_respuesta(self, cliente_azure):
        cli, _ = cliente_azure(
            respuestas=[respuesta_azure("ok", modelo="gpt-4o-2024-11-20")])
        cli.generar_mensaje("prompt")
        assert cli._modelo_real == "gpt-4o-2024-11-20", (
            "el modelo real viene gratis en la respuesta y determina el perfil "
            "de chunking: no memorizarlo obliga a una llamada extra")
        assert cli.perfil.contexto_tokens == 128_000


# ══════════════════════════════════════════════════════════════════════════════
# 2. Negociación de max_tokens / max_completion_tokens
# ══════════════════════════════════════════════════════════════════════════════
class TestNegociacionDelParametroDeTokens:
    """
    Los modelos de razonamiento (o1/o3/GPT-5) RECHAZAN `max_tokens`. Detectarlo
    por el nombre del deployment no sirve: lo elige el usuario y puede llamarse
    como quiera ('virf-prod'). Hay que negociarlo contra el servidor.
    """

    def test_modelo_clasico_acepta_max_tokens(self, cliente_azure):
        cli, falso = cliente_azure(param_exigido="max_tokens",
                                   respuestas=[respuesta_azure("ok")])
        cli.generar_mensaje("prompt")
        assert "max_tokens" in falso.llamadas[-1]

    def test_modelo_de_razonamiento_recibe_max_completion_tokens(self, cliente_azure):
        cli, falso = cliente_azure(
            param_exigido="max_completion_tokens",
            respuestas=[respuesta_azure("ok", modelo="gpt-5-2026-01-15")])
        r = cli.generar_mensaje("prompt")
        assert r == "ok", "el cliente no consiguió adaptarse al parámetro exigido"
        assert "max_completion_tokens" in falso.llamadas[-1]
        assert cli._param_tokens == "max_completion_tokens"

    def test_el_parametro_negociado_se_memoriza(self, cliente_azure):
        # El chunker hace ~40 llamadas: pagar el reintento en cada una sería
        # duplicar la latencia de toda la corrida.
        cli, falso = cliente_azure(
            param_exigido="max_completion_tokens",
            respuestas=[respuesta_azure("1"), respuesta_azure("2")])
        cli.generar_mensaje("a")
        n_tras_primera = len(falso.llamadas)
        cli.generar_mensaje("b")
        assert len(falso.llamadas) == n_tras_primera + 1, (
            "la segunda llamada volvió a probar ambos parámetros: el resultado "
            "de la negociación no se memorizó")

    def test_si_ambos_parametros_fallan_se_reporta_con_claridad(self, cliente_azure):
        cli, _ = cliente_azure(
            excepcion=Exception("Error code: 400 - Unsupported parameter: "
                                "'max_tokens' and 'max_completion_tokens'"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje("prompt")
        assert "Azure" in str(exc.value)


# ══════════════════════════════════════════════════════════════════════════════
# 3. Modos de fallo propios de Azure
# ══════════════════════════════════════════════════════════════════════════════
class TestModosDeFalloDeAzure:

    def test_choices_vacio_por_filtro_de_contenido(self, cliente_azure):
        """Azure filtra contenido; Anthropic no. `choices=[]` es exclusivo suyo."""
        vacia = SimpleNamespace(model="gpt-4o", choices=[], usage=None)
        cli, _ = cliente_azure(respuestas=[vacia])
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje("prompt")
        assert "filtro de contenido" in str(exc.value).lower()

    def test_content_none_se_reporta_con_su_finish_reason(self, cliente_azure):
        r = respuesta_azure(None, finish_reason="content_filter")
        cli, _ = cliente_azure(respuestas=[r])
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje("prompt")
        assert "content_filter" in str(exc.value)

    def test_un_error_de_red_no_se_traga(self, cliente_azure):
        cli, _ = cliente_azure(excepcion=ConnectionError("timeout"))
        with pytest.raises(RuntimeError):
            cli.generar_mensaje("prompt")

    def test_el_fallo_de_azure_NO_cae_a_anthropic(self, monkeypatch):
        """
        Política de gobernanza. Un informe con evaluaciones de dos modelos bajo
        una sola huella de ejecución haría falsa la reproducibilidad que el
        propio informe declara.
        """
        import importlib
        import config.ia as ia
        import config.parametros as pm

        # El orden importa y ya me costó un fallo: el `monkeypatch.undo()` debe
        # ir en el `finally`, NO antes de la recarga. Deshacerlo primero hace
        # que `reload` lea el .env real (IA_PROVEEDOR=anthropic) y el escenario
        # que se quiere probar desaparece. Y sin restaurar al final, config
        # queda con Azure sin credencial y CONTAMINA al resto de la suite.
        monkeypatch.setenv("IA_PROVEEDOR", "azure_openai")
        monkeypatch.setenv("AZURE_OPENAI_API_KEY", "")
        try:
            importlib.reload(pm)
            importlib.reload(ia)
            ia.reset_cliente_ia()
            assert pm.IA_PROVEEDOR == "azure_openai", "el escenario no se montó"

            with pytest.raises(Exception) as exc:
                ia.get_cliente_ia(forzar_recarga=True)
            mensaje = str(exc.value)
            assert "AZURE" in mensaje.upper(), (
                f"el error no menciona Azure: {mensaje!r}. Si el fallo de Azure "
                f"derivara a Anthropic, el informe mezclaría dos modelos bajo "
                f"una sola huella de ejecución.")
        finally:
            monkeypatch.undo()
            importlib.reload(pm)
            importlib.reload(ia)
            ia.reset_cliente_ia()


# ══════════════════════════════════════════════════════════════════════════════
# 4. Parseo del JSON — las tres formas en que puede venir envuelto
# ══════════════════════════════════════════════════════════════════════════════
class TestParseoDeLasTresVariantesDeAzure:
    """
    Aunque `response_format=json_object` garantiza JSON válido, el parser
    robusto sigue siendo necesario: Anthropic no tiene equivalente, y una
    llamada sin `formato_json` puede devolver el JSON envuelto.

    Este proyecto ya sufrió las tres variantes; el parser lleva un AUDIT-FIX
    por ello. Se fijan aquí con la forma que produciría Azure.
    """

    CONTRATO = {
        "puntaje": 3,
        "concepto": "Verificación de backtesting.",
        "evidencia_encontrada": "El manual documenta backtesting de Kupiec.",
        "observacion": "No aporta p-valores.",
        "preguntas_pendientes": [],
        "recomendacion": "Incluir los estadísticos.",
    }

    def _variantes(self):
        limpio = json.dumps(self.CONTRATO, ensure_ascii=False)
        return {
            "json_limpio": limpio,
            "con_markdown_fences": f"```json\n{limpio}\n```",
            "con_texto_alrededor": (
                "Claro, aquí tienes la evaluación solicitada:\n\n"
                f"{limpio}\n\n"
                "Nota: el análisis usa {llaves} en la explicación."),
        }

    @pytest.mark.parametrize("variante", ["json_limpio", "con_markdown_fences",
                                          "con_texto_alrededor"])
    def test_el_parser_extrae_el_contrato(self, variante):
        from modulos.motor_ia import _extraer_json
        datos = _extraer_json(self._variantes()[variante])
        assert datos["puntaje"] == 3
        assert "Kupiec" in datos["evidencia_encontrada"]

    def test_el_texto_posterior_con_llaves_no_confunde_al_parser(self):
        # El caso que rompía el parser antiguo: `rfind("}")` se pasaba de largo
        # hasta la llave de la frase explicativa y producía JSON inválido.
        from modulos.motor_ia import _extraer_json
        datos = _extraer_json(self._variantes()["con_texto_alrededor"])
        assert datos["puntaje"] == 3

    def test_dos_objetos_seguidos_no_se_fusionan(self):
        from modulos.motor_ia import _extraer_json
        doble = json.dumps(self.CONTRATO) + "\n" + json.dumps({"otro": 1})
        datos = _extraer_json(doble)
        assert datos.get("puntaje") == 3 and "otro" not in datos

    def test_json_invalido_no_devuelve_un_dict_inventado(self):
        from modulos.motor_ia import _extraer_json
        with pytest.raises(Exception):
            _extraer_json("esto no es JSON en absoluto")


# ══════════════════════════════════════════════════════════════════════════════
# 5. El pipeline completo corre con Azure simulado
# ══════════════════════════════════════════════════════════════════════════════
class TestPipelineCompletoConAzureSimulado:
    """
    Comprueba que los componentes de negocio funcionan con el proveedor Azure
    sin tocar Anthropic en ningún punto. El cliente se inyecta en la caché de
    proceso de config.ia, que es el único punto de entrada.
    """

    # Cumple el CONTRATO COMPLETO (_CAMPOS_CONTRATO_EVALUACION). Un mock
    # incompleto no probaría el flujo: _validar_contrato_evaluacion lo
    # rechazaría y la actividad saldría como fallo técnico — que es justo lo
    # que hizo la primera versión de este fixture y lo delató.
    RESPUESTA = json.dumps({
        "puntaje": 4,
        "concepto": "Verificación de la existencia de backtesting documentado.",
        "evidencia_encontrada": "El manual §3.2 documenta el backtesting de "
                                "Kupiec sobre 250 observaciones.",
        "observacion": "Documentado y con metodología explícita; no se aportan "
                       "los p-valores obtenidos.",
        "preguntas_pendientes": ["¿Cuáles fueron los p-valores del último ciclo?"],
        "recomendacion": "Incluir los estadísticos y su conclusión.",
    }, ensure_ascii=False)

    @pytest.fixture
    def azure_activo(self, monkeypatch, cliente_azure):
        import config.ia as ia
        cli, falso = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA) for _ in range(80)])
        monkeypatch.setattr(ia, "_CLIENTE_CACHE", cli)
        return cli, falso

    def test_evaluar_actividad_pipeline_2(self, azure_activo):
        cli, falso = azure_activo
        import modulos.motor_ia as motor_ia
        evs = motor_ia.evaluar_ambito_completo(
            ambito="Metodología",
            actividades=[{"actividad": "Revisión de backtesting",
                          "control": "C1", "tipo_ctrl": "Cuantitativo"}],
            contexto="Manual metodológico con backtesting de Kupiec documentado.",
            titulo_modelo="Modelo VaR", cobertura_docs=100.0)
        assert len(evs) == 1
        assert evs[0]["puntaje"] == 4
        assert "Kupiec" in evs[0]["evidencia_encontrada"]
        assert falso.llamadas, "no se llegó a llamar al proveedor"

    def test_chunking_resume_con_azure(self, azure_activo, tmp_path):
        cli, falso = azure_activo
        from modulos.chunker import ChunkerService
        ch = ChunkerService(cliente_ia=cli)
        doc = {"nombre": "manual.pdf", "contenido": "x" * 60_000,
               "chars_totales": 60_000, "tipo": "PDF"}
        r = ch.procesar_doc(doc)
        assert r["fue_resumido"] is True
        assert r["cobertura_pct"] > 0
        assert len(falso.llamadas) >= 1

    def test_el_score_y_el_semaforo_se_calculan(self, azure_activo):
        import modulos.motor_ia as motor_ia
        evs = motor_ia.evaluar_ambito_completo(
            ambito="Metodología",
            actividades=[{"actividad": f"A{i}", "control": "C",
                          "tipo_ctrl": "Cuantitativo"} for i in range(3)],
            contexto="Evidencia suficiente.", titulo_modelo="M",
            cobertura_docs=100.0)
        score = motor_ia.calcular_score_ambito(evs)
        assert score == 4.0
        assert motor_ia.get_semaforo(score)["label"] == "ACEPTABLE"

    def test_no_se_instancia_ningun_cliente_anthropic(self, azure_activo,
                                                      monkeypatch):
        """Ni un solo punto del flujo debe crear el proveedor secundario."""
        import config.ia as ia
        llamadas_anthropic = []
        original = ia.ClienteAnthropicIA.__init__

        def espia(self, *a, **kw):
            llamadas_anthropic.append(1)
            return original(self, *a, **kw)

        monkeypatch.setattr(ia.ClienteAnthropicIA, "__init__", espia)
        import modulos.motor_ia as motor_ia
        motor_ia.evaluar_ambito_completo(
            ambito="Metodología",
            actividades=[{"actividad": "A", "control": "C",
                          "tipo_ctrl": "Cuantitativo"}],
            contexto="Evidencia.", titulo_modelo="M", cobertura_docs=100.0)
        assert not llamadas_anthropic, (
            "se instanció el cliente de Anthropic con Azure activo")


# ══════════════════════════════════════════════════════════════════════════════
# FASE 3 — Los componentes que faltaban por cubrir con Azure simulado
#
# `TestPipelineCompletoConAzureSimulado` ya cubría Pipeline 2, chunking y score.
# Quedaban fuera tres piezas que también llaman al modelo y que, sin cobertura,
# solo se descubrirían rotas el día que llegue la credencial:
#
#   · Pipeline 1 (--control), que tiene su propio contrato de respuesta
#   · el explicador de modelos, con su verificación de 9 secciones
#   · la revisión de código módulo a módulo (--revisar-codigo)
#
# Ninguno hace llamadas reales: todo va contra ClienteAzureFalso.
# ══════════════════════════════════════════════════════════════════════════════
class TestPipeline1ExplicadorYRevisionConAzure:

    # ── Pipeline 1: contrato de evaluación de CONTROL ───────────────────────
    RESPUESTA_CONTROL = json.dumps({
        "estado": "ADVERTENCIA",
        "revision": "Control de unicidad documentado pero sin umbral explícito.",
        "hallazgos": [{"descripcion": "No se declara la tolerancia admitida",
                       "severidad": "media"}],
        "recomendacion": "Fijar el umbral en el manual de calidad de datos.",
        "puntaje": 3,
        "concepto": "Control de unicidad",
        "evidencia_encontrada": "Manual de calidad §4.1",
        "observacion": "Sin umbral cuantificado.",
        "preguntas_pendientes": [],
    }, ensure_ascii=False)

    def test_pipeline_1_evalua_un_control_con_azure(self, monkeypatch,
                                                    cliente_azure, tmp_path):
        """El pipeline por CONTROL usa el mismo cliente abstracto."""
        import config.ia as ia
        cli, falso = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA_CONTROL) for _ in range(20)])
        monkeypatch.setattr(ia, "_CLIENTE_CACHE", cli)

        import motor.Mx_03_LlamarIA as mx03
        monkeypatch.setattr(mx03, "_obtener_cliente", lambda: cli)

        # Se llama a la capa que habla con el modelo, no al orquestador entero:
        # lo que se verifica es que el contrato de Azure se parsea, no el I/O.
        texto = mx03._llamar_modelo("Evalúa el control C-01.")
        assert isinstance(texto, str) and texto, "no devolvió texto"
        datos = mx03._parsear_json(texto, fallback={})
        assert datos.get("estado") == "ADVERTENCIA"
        assert datos.get("hallazgos"), "se perdieron los hallazgos del control"
        assert falso.llamadas, "no se llamó al cliente Azure"

    # ── Explicador de modelos ───────────────────────────────────────────────
    def test_explicador_genera_las_9_secciones_con_azure(self, monkeypatch,
                                                         cliente_azure, tmp_path):
        from modulos.explicador_modelo import ExplicadorModelo

        # El explicador pide bloques de secciones; se devuelve un documento que
        # cumple la estructura fija que él mismo verifica.
        doc = "\n\n".join(
            "## %d. Sección %d\n\nContenido de ejemplo." % (i, i)
            for i in range(1, 10))
        cli, falso = cliente_azure(respuestas=[respuesta_azure(doc)
                                              for _ in range(12)])

        faltan = ExplicadorModelo.verificar(doc)
        assert not faltan, "el verificador de 9 secciones falla: %s" % faltan

        # Y con una sección ausente, DEBE detectarlo (si no, el explicador
        # entregaría documentos incompletos sin avisar).
        incompleto = doc.replace("## 7. Sección 7", "## 7bis. Otra cosa")
        assert ExplicadorModelo.verificar(incompleto), (
            "no detecta una sección faltante")

    def test_explicador_inventaria_sin_llamar_al_modelo(self, tmp_path):
        """El --dry-run no puede gastar: es la comprobación previa al gasto."""
        from modulos.explicador_modelo import ExplicadorModelo
        raiz = tmp_path
        (raiz / "inputs" / "documentacion" / "modelamiento").mkdir(parents=True)
        (raiz / "inputs" / "documentacion" / "modelamiento" / "m_LaR.md").write_text(
            "# Manual\n", encoding="utf-8")

        class ClienteQueNoDebeUsarse:
            def generar_mensaje(self, *a, **k):
                raise AssertionError("el dry-run llamó al modelo")

        ex = ExplicadorModelo(cliente_ia=None, base_dir=raiz)
        inv = ex.inventariar("LaR")
        assert isinstance(inv, dict) and inv, "el inventario salió vacío"

    # ── Revisión de código módulo a módulo ──────────────────────────────────
    RESPUESTA_REVISION = json.dumps({
        "resumen_modulo": "Calcula el VaR por percentil histórico.",
        "elementos_definidos": ["estimar_var"],
        "hallazgos": [{
            "linea": 3, "categoria": "no_documentado", "severidad": "alta",
            "elemento": "_ajuste", "descripcion": "Ajuste no documentado.",
            "evidencia_codigo": "z + skew/6", "referencia_manual": "",
        }],
    }, ensure_ascii=False)

    def test_revision_de_codigo_con_azure(self, cliente_azure, tmp_path):
        from modulos.revision_codigo import RevisorCodigo, descubrir_modulos
        base = tmp_path / "implementacion"
        (base / "libs").mkdir(parents=True)
        (base / "calculo.py").write_text("def f():\n    return 1\n", encoding="utf-8")
        (base / "libs" / "modelo.R").write_text("f <- function() 1\n", encoding="utf-8")

        cli, falso = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA_REVISION) for _ in range(10)])

        mods = descubrir_modulos(base)
        cons = RevisorCodigo(cli).revisar(mods, "Manual del modelo.",
                                          raiz=base, verbose=False)
        assert cons["revision_confiable"] is True, cons.get("fallos_tecnicos")
        assert cons["n_modulos"] == 2
        assert cons["n_hallazgos"] == 2
        assert falso.llamadas, "no se usó el cliente Azure"
        # El lenguaje debe viajar al prompt también con Azure
        lenguajes = {m["lenguaje"] for m in cons["modulos"]}
        assert lenguajes == {"python", "r"}, lenguajes

    def test_la_revision_de_codigo_no_cae_a_anthropic(self, monkeypatch,
                                                     cliente_azure, tmp_path):
        import config.ia as ia
        instanciados = []
        original = ia.ClienteAnthropicIA.__init__

        def espia(self, *a, **kw):
            instanciados.append(1)
            return original(self, *a, **kw)

        monkeypatch.setattr(ia.ClienteAnthropicIA, "__init__", espia)

        from modulos.revision_codigo import RevisorCodigo, descubrir_modulos
        base = tmp_path / "impl"; base.mkdir()
        (base / "a.py").write_text("def f(): pass\n", encoding="utf-8")
        cli, _ = cliente_azure(
            respuestas=[respuesta_azure(self.RESPUESTA_REVISION) for _ in range(5)])
        RevisorCodigo(cli).revisar(descubrir_modulos(base), "m",
                                   raiz=base, verbose=False)
        assert not instanciados, "se instanció Anthropic con Azure activo"


# ══════════════════════════════════════════════════════════════════════════════
# FASE 3 — Fallo de credencial: reportar y DETENERSE, nunca degradar en silencio
# ══════════════════════════════════════════════════════════════════════════════
class TestFalloDeCredencialSeDetiene:

    def test_credencial_invalida_lanza_y_no_devuelve_texto(self, cliente_azure):
        """
        Un 401 no puede convertirse en una cadena vacía: el pipeline la trataría
        como respuesta del modelo y la actividad saldría puntuada sobre nada.

        El fallo se inyecta con `excepcion=`, que es como el doble simula que la
        API revienta. Pasarlo en `respuestas=` no lo lanzaría: se devolvería el
        objeto y el cliente fallaría más tarde por otra causa, con lo que el
        test pasaría por el motivo equivocado.
        """
        cli, _ = cliente_azure(
            excepcion=Exception("Error code: 401 - Unauthorized: Access denied "
                                "due to invalid subscription key"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje(prompt="hola")
        mensaje = str(exc.value)
        assert "401" in mensaje or "Unauthorized" in mensaje, mensaje

    def test_endpoint_incorrecto_se_reporta_con_el_detalle(self, cliente_azure):
        cli, _ = cliente_azure(
            excepcion=ConnectionError("getaddrinfo failed: recurso-inexistente"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje(prompt="hola")
        assert "getaddrinfo" in str(exc.value), (
            "el detalle de red se perdió: el operador no sabría que el endpoint "
            "está mal escrito")

    def test_deployment_inexistente_da_404_accionable(self, cliente_azure):
        """El error más común al configurar Azure: deployment ≠ nombre de modelo."""
        cli, _ = cliente_azure(
            excepcion=Exception("Error code: 404 - DeploymentNotFound: The API "
                                "deployment for this resource does not exist"))
        with pytest.raises(RuntimeError) as exc:
            cli.generar_mensaje(prompt="hola")
        assert "404" in str(exc.value) or "DeploymentNotFound" in str(exc.value)

    def test_el_mensaje_del_preflight_nombra_al_proveedor_activo(self):
        """
        El diagnóstico debe mandar al operador a la consola correcta. Con Azure
        configurado, remitirle a la de Anthropic le hace revisar una credencial
        que no es la que está fallando.
        """
        from config.ia import metadatos_proveedor
        m = metadatos_proveedor("azure_openai")
        assert "Azure" in m["nombre"]
        assert "azure" in m["consola"].lower() or "portal" in m["consola"].lower()
        assert m["var_clave"] == "AZURE_OPENAI_API_KEY"
        # Y la lista de variables a revisar debe incluir el error más común.
        assert any("DEPLOYMENT" in v for v in m["vars_revisar"])

    def test_no_existe_fallback_automatico_en_el_codigo(self):
        """
        Invariante de política: ninguna rama puede elegir otro proveedor cuando
        el activo falla. Un informe con evaluaciones de dos modelos bajo una
        sola huella de ejecución haría falsa la reproducibilidad que declara.
        """
        fuente = (RAIZ / "config" / "ia.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "fallback" not in vivas.lower(), (
            "apareció lógica de fallback en config/ia.py")
        # get_cliente_ia debe resolver por IA_PROVEEDOR y nada más.
        assert "FABRICAS[" in vivas or "FABRICAS.get" in vivas


# ══════════════════════════════════════════════════════════════════════════════
# FASE 3 — Detección automática del modelo del deployment
# ══════════════════════════════════════════════════════════════════════════════
class TestDeteccionAutomaticaDelDeployment:

    @pytest.mark.parametrize("modelo_real,espera_param,espera_temp", [
        ("gpt-4",                  "max_tokens",            True),
        ("gpt-4-turbo-2024-04-09", "max_tokens",            True),
        ("gpt-4o-2024-11-20",      "max_tokens",            True),
        ("gpt-5-2025-08-01",       "max_completion_tokens", False),
        ("o3-mini-2025-01-31",     "max_completion_tokens", False),
    ])
    def test_el_perfil_se_adapta_al_modelo_que_sirva_el_deployment(
            self, modelo_real, espera_param, espera_temp):
        """
        El requisito operativo: pegar la key y NO tocar código, sirva el
        deployment lo que sirva. El perfil se deriva del modelo REAL que
        devuelve la respuesta, no del nombre del deployment.
        """
        from config.modelos import perfil_modelo
        p = perfil_modelo(modelo_real, verbose=False)
        assert p.param_tokens == espera_param, (
            "%s negociaría el parámetro de tokens equivocado" % modelo_real)
        assert p.admite_temperature is espera_temp
        assert p.max_ctx > 0 and p.chunk_size > 0 and p.max_chunks > 0

    def test_un_modelo_desconocido_no_rompe_y_es_conservador(self):
        """
        Si mañana IT despliega un modelo que no está en el catálogo, el sistema
        debe seguir corriendo con un presupuesto prudente en vez de reventar o
        de asumir un contexto que no tiene.
        """
        from config.modelos import perfil_modelo, PERFIL_CONSERVADOR
        p = perfil_modelo("modelo-que-no-existe-2030", verbose=False)
        assert p is PERFIL_CONSERVADOR
        assert p.contexto_tokens <= 32_000, "el perfil de reserva no es conservador"

    def test_el_cliente_memoriza_el_modelo_real(self, cliente_azure):
        cli, falso = cliente_azure(
            respuestas=[respuesta_azure('{"ok": true}', modelo="gpt-4o-2024-11-20")])
        cli.generar_mensaje(prompt="ping")
        assert getattr(cli, "_modelo_real", None) == "gpt-4o-2024-11-20", (
            "sin memorizar el modelo real, el perfil de chunking no puede "
            "derivarse del deployment y habría que configurarlo a mano")


# ══════════════════════════════════════════════════════════════════════════════
# [AZURE 2026-07-30] Reintento ante cuota agotada (429)
#
# La cuota de Azure es POR DEPLOYMENT (TPM/RPM). El chunker hace hasta 40
# llamadas seguidas, así que el 429 no es excepcional: es lo esperable con un
# deployment de TPM modesto. Sin reintento, abortaba la corrida a mitad del
# chunking con la extracción ya pagada.
#
# `REINTENTOS_API` llevaba tiempo declarado en config/parametros.py y NO LO LEÍA
# NADIE: un mando conectado a nada, que promete un control inexistente. Es el
# mismo defecto que el proyecto ya corrigió con RAG_TOP_K.
# ══════════════════════════════════════════════════════════════════════════════
class TestReintentoAnteCuotaAgotada:

    def test_un_429_se_reintenta_y_la_corrida_continua(self):
        from config.ia import _con_reintento
        estado = {"n": 0}

        def flaky():
            estado["n"] += 1
            if estado["n"] < 3:
                raise Exception("Error code: 429 - Too Many Requests")
            return "ok"

        assert _con_reintento(flaky, intentos=5) == "ok"
        assert estado["n"] == 3

    def test_un_401_NO_gasta_reintentos(self):
        """
        Reintentar una credencial inválida cinco veces es puro desperdicio: el
        resultado es el mismo y el operador espera de más para ver el mismo
        error. Solo se reintenta lo que puede cambiar por sí solo.
        """
        from config.ia import _con_reintento
        llamadas = {"n": 0}

        def auth():
            llamadas["n"] += 1
            raise Exception("Error code: 401 - Unauthorized")

        with pytest.raises(Exception):
            _con_reintento(auth, intentos=5)
        assert llamadas["n"] == 1, "reintentó un fallo de credencial"

    def test_al_agotarse_propaga_el_error_real(self):
        """
        Un rate limit agotado es un FALLO TÉCNICO del agente, no una falta del
        validado. Debe propagarse para que la actividad quede como
        evaluacion_valida=False, nunca como puntaje 0.
        """
        from config.ia import _con_reintento

        def siempre():
            raise Exception("429 rate limit exceeded")

        with pytest.raises(Exception) as exc:
            _con_reintento(siempre, intentos=2)
        assert "429" in str(exc.value)

    def test_respeta_el_retry_after_del_servidor(self):
        """Si la API dice cuánto esperar, se le hace caso."""
        from config.ia import _espera_sugerida

        class ConRetryAfter(Exception):
            retry_after = 7.0

        assert _espera_sugerida(ConRetryAfter(), 0) == 7.0

    def test_sin_retry_after_usa_backoff_exponencial_acotado(self):
        from config.ia import _espera_sugerida
        e = Exception("429")
        assert _espera_sugerida(e, 0) < _espera_sugerida(e, 4)
        assert _espera_sugerida(e, 20) <= 60.0, "espera sin tope: cuelga la corrida"

    def test_clasifica_bien_lo_transitorio(self):
        from config.ia import _es_transitorio
        for t in ("Error code: 429", "503 Service Unavailable",
                  "rate limit exceeded", "Too Many Requests"):
            assert _es_transitorio(Exception(t)), t
        for p in ("401 Unauthorized", "404 DeploymentNotFound",
                  "400 Unsupported parameter"):
            assert not _es_transitorio(Exception(p)), p

    def test_el_parametro_esta_conectado_a_config(self):
        """El mando debe leerse de la única fuente de verdad, no de un literal."""
        fuente = (RAIZ / "config" / "ia.py").read_text(encoding="utf-8")
        assert "REINTENTOS_API" in fuente, (
            "el reintento volvió a usar un literal en vez del parámetro central")

    def test_el_cliente_azure_reintenta_de_verdad(self, cliente_azure):
        """
        No basta con que la función exista: el cliente tiene que usarla. Una
        primera versión definió _con_reintento y no la enchufó a
        generar_mensaje — el 429 seguía abortando igual.
        """
        cli, falso = cliente_azure(
            excepcion=Exception("Error code: 429 - Too Many Requests"),
            excepcion_persistente=False,
            respuestas=[respuesta_azure('{"ok": true}')])
        # La 1ª llamada lanza 429, la 2ª devuelve la respuesta buena.
        texto = cli.generar_mensaje(prompt="hola")
        assert '"ok"' in texto
        assert len(falso.llamadas) >= 2, (
            "no reintentó: _con_reintento no está enchufado a generar_mensaje")
