#!/usr/bin/env python3
"""
test_api_key.py - Diagnostico de API key de Anthropic
"""

import os
from dotenv import load_dotenv
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

# Cargar .env
load_dotenv()

print("=" * 70)
print("DIAGNOSTICO DE API KEY - ANTHROPIC")
print("=" * 70)
print()

# 1. Verificar que .env se cargó
api_key = os.getenv("ANTHROPIC_API_KEY")
print(f"1. ¿API Key en memoria? {bool(api_key)}")
if api_key:
    print(f"   Longitud: {len(api_key)} caracteres")
    print(f"   Primeros 30: {api_key[:30]}...")
    print(f"   Últimos 10: ...{api_key[-10:]}")
print()

# 2. Verificar formato
print("2. Validación de formato:")
if api_key:
    if api_key.startswith("sk-ant-api"):
        print("   ✓ Prefijo correcto: sk-ant-api")
    else:
        print(f"   ✗ Prefijo incorrecto: {api_key[:15]}")
    
    if len(api_key) > 100:
        print(f"   ✓ Longitud OK: {len(api_key)} chars (>100)")
    else:
        print(f"   ✗ Longitud sospechosa: {len(api_key)} chars")
else:
    print("   ✗ NO HAY API KEY")
print()

# 3. Intentar conectar a Anthropic
print("3. Verificando conexión con Anthropic:")
try:
    import anthropic
    
    client = anthropic.Anthropic(api_key=api_key)
    print("   ✓ Cliente Anthropic creado")
    
    # Intentar hacer una llamada simple
    response = client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=10,
        messages=[
            {
                "role": "user",
                "content": "Hola"
            }
        ]
    )
    print("   ✓ Conexión exitosa a Anthropic API")
    print(f"   Respuesta: {response.content[0].text}")
    
except Exception as e:
    print(f"   ✗ Error: {type(e).__name__}")
    print(f"   Mensaje: {str(e)}")
    
    if "401" in str(e) or "authentication" in str(e).lower():
        print()
        print("   ⚠️  PROBLEMA: API Key rechazada (401 Unauthorized)")
        print("   Soluciones:")
        print("      1. Verifica que la API key es correcta")
        print("      2. Revisa en https://console.anthropic.com/account/billing/overview")
        print("      3. Crea una nueva key si la actual está revocada")
        print("      4. Asegúrate de tener crédito disponible")
    elif "429" in str(e):
        print("   ⚠️  PROBLEMA: Rate limit excedido (429)")
    elif "overloaded" in str(e).lower():
        print("   ⚠️  PROBLEMA: Servicio Anthropic sobrecargado")
    elif "connection" in str(e).lower():
        print("   ⚠️  PROBLEMA: Error de conexión (revisa internet)")

print()
print("=" * 70)
