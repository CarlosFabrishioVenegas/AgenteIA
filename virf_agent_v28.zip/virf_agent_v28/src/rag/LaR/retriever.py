"""
src/rag/LaR/retriever.py
=========================
Retriever RAG para modelos de Liquidity at Risk (LaR).

Uso en motor_ia.py (dentro de evaluar_actividad):
    from src.rag.LaR.retriever import LaRRetriever

    retriever = LaRRetriever()
    contexto_rag = retriever.query_para_prompt(
        actividad,   # ej. "Verificar existencia de prueba Kupiec"
        top_k=3,
        min_score=0.35
    )
    if contexto_rag:
        prompt += f"\\n\\n{contexto_rag}"
"""

from src.rag.base_retriever import BaseRetriever


class LaRRetriever(BaseRetriever):
    dominio = "LaR"

    def _get_indexer(self):
        from src.rag.LaR.indexer import LaRIndexer
        return LaRIndexer()
