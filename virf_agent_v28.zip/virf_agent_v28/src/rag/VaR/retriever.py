"""
src/rag/VaR/retriever.py
========================
Retriever RAG para modelos de Value at Risk (VaR).
Recupera contexto de riesgo de mercado (FRTB, Basilea III, Kupiec) para el prompt.
Uso: VaRRetriever().query_para_prompt(texto, top_k=3)
"""
from src.rag.base_retriever import BaseRetriever
class VaRRetriever(BaseRetriever):
    dominio = "VaR"
    def _get_indexer(self):
        from src.rag.VaR.indexer import VaRIndexer
        return VaRIndexer()
