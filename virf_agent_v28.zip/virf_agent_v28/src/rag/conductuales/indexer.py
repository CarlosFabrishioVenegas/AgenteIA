"""
src/rag/conductuales/indexer.py
================================
Indexador RAG para modelos conductuales (prepago, retiro de depósitos, NMD).
Indexa manuales conductuales, EBA guidelines y documentos de seguimiento.
Hereda de BaseIndexer. Uso: ConductualesIndexer().build_index()
"""
from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer, fuentes_rag

class ConductualesIndexer(BaseIndexer):
    dominio = "conductuales"
    def get_source_paths(self) -> List[Path]:
        """
        Literatura de referencia del dominio: `inputs/rag/{dom}/`.

        [AUDIT-FIX] Antes apuntaba a las carpetas de EVIDENCIA del modelo
        validado, lo que hacía que el RAG recuperara el propio manual bajo
        evaluación y lo presentara como referencia que lo confirma. Ver
        `base_indexer.fuentes_rag()` para el razonamiento completo.
        """
        return fuentes_rag(self.dominio)
