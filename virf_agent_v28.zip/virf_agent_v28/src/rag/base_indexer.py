"""
src/rag/base_indexer.py
========================
Clase base para indexadores de todos los dominios RAG.

Responsabilidad: construir y mantener un índice ChromaDB a partir de los
documentos de un dominio financiero (LaR, VaR, conductuales, shared).
Usa sentence-transformers (multilingüe, sin API externa) para generar
los embeddings. Detecta automáticamente si el entorno es Databricks y
persiste los índices en DBFS (/dbfs/FileStore/virf/vectordb/<dominio>/).

Subclases concretas: LaRIndexer, VaRIndexer, ConductualesIndexer, SharedIndexer.
Cada subclase solo define `dominio` y `get_source_paths()`.
Cada dominio (LaR, VaR, conductuales, shared) hereda de aquí.

Tecnología: ChromaDB (local) en Databricks DBFS o FileStore.
Embeddings: sentence-transformers (sin llamadas API externas).

Uso en Databricks:
    # En un notebook de setup (correr 1 vez por entorno):
    from src.rag.LaR.indexer import LaRIndexer
    idx = LaRIndexer()
    idx.build_index()   # Indexa todos los docs en inputs/documentacion/modelamiento/
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict, Any

logger = logging.getLogger("virf.rag")

# ── Detectar si estamos en Databricks ────────────────────────────────────────
_EN_DATABRICKS = "DATABRICKS_RUNTIME_VERSION" in os.environ


def raiz_proyecto() -> Path:
    """
    Raíz del proyecto. Un único sitio donde calcularla.

    [AUDIT-FIX] Los cuatro indexadores de dominio repetían
    `Path(__file__).parent.parent.parent.parent` cada uno por su cuenta. Cuatro
    copias de una cuenta de niveles que hay que acertar, y que en
    `base_indexer.py` —un nivel más arriba— ya estaba mal y apuntaba fuera del
    proyecto. `parents[2]` desde src/rag/base_indexer.py es la raíz.
    """
    return Path(__file__).resolve().parents[2]


def fuentes_rag(dominio: str) -> List[Path]:
    """
    Carpeta de LITERATURA DE REFERENCIA del dominio: `inputs/rag/<dominio>/`.

    ── Por qué no se indexa `inputs/` directamente ──────────────────────────
    Los indexadores leían de `inputs/documentacion/`, `inputs/papers/` y demás,
    que son la EVIDENCIA DEL MODELO QUE SE ESTÁ VALIDANDO. Eso producía dos
    problemas graves:

    1. RAZONAMIENTO CIRCULAR. Ante la actividad «¿el manual documenta el
       backtesting?», el RAG recuperaba fragmentos DEL PROPIO MANUAL y los
       inyectaba como «conocimiento recuperado» del dominio. El modelo veía sus
       propias afirmaciones presentadas como referencia autorizada que las
       confirma. El agente se daba la razón a sí mismo.

    2. CONTAMINACIÓN ENTRE DOMINIOS. Los cuatro dominios apuntaban a las mismas
       carpetas, así que los tres índices especializados quedaban llenos del
       mismo contenido. Medido: consultando el índice de VaR sobre backtesting
       FRTB, los tres primeros resultados eran del manual de LaR con similitud
       0.88 — muy por encima del umbral de 0.35. Validar un VaR le inyectaba
       el manual de un modelo de liquidez como conocimiento experto de mercado.

    El RAG es conocimiento de DOMINIO (FRTB, Kupiec, Basilea, SR 11-7), externo
    e independiente del modelo evaluado. Por eso vive en su propia carpeta.

    Un dominio sin literatura devuelve un índice vacío, y `BaseRetriever.query()`
    degrada a lista vacía: la validación sigue sin contexto RAG. Es el fallo
    correcto — mejor sin contexto que con contexto ajeno.
    """
    return [raiz_proyecto() / "inputs" / "rag" / dominio]


def _get_vectordb_base() -> Path:
    """
    Retorna la ruta base para los índices vectoriales.

    [AUDIT-FIX] Esta función calculaba la ruta por su cuenta con
    `Path(__file__).parent.parent.parent.parent`, que son CUATRO saltos desde
    src/rag/base_indexer.py: rag → src → raíz → *el padre de la raíz*. Uno de
    más. El índice se escribía fuera del proyecto mientras config.VECTORDB_DIR
    apuntaba dentro, así que quien leyera por la ruta oficial no encontraba
    nada — y BaseRetriever.query() devuelve [] en silencio ante un índice
    ausente, de modo que el RAG parecía funcionar y nunca aportaba contexto.

    Ahora hay una sola fuente: config.rutas, que además respeta
    RAG_VECTORDB_DIR y detecta Databricks.
    """
    try:
        from config.rutas import VECTORDB_DIR
        return VECTORDB_DIR
    except Exception:
        # src/rag debe seguir siendo utilizable fuera del árbol del agente
        # (p. ej. en el job de Databricks que solo copia src/).
        if _EN_DATABRICKS:
            return Path("/dbfs/FileStore/virf/vectordb")
        return Path(__file__).resolve().parents[2] / "data" / "vectordb"


class BaseIndexer(ABC):
    """
    Indexador base para un dominio RAG.

    Subclases deben implementar:
        - dominio: str (nombre del dominio, ej. "LaR")
        - get_source_paths(): lista de Path con carpetas/archivos a indexar
    """

    dominio: str = "base"

    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 150):
        self.chunk_size    = chunk_size
        self.chunk_overlap = chunk_overlap
        self.vectordb_path = _get_vectordb_base() / self.dominio
        self._collection   = None

    @abstractmethod
    def get_source_paths(self) -> List[Path]:
        """Retorna las carpetas/archivos a indexar para este dominio."""
        ...

    def _get_chroma_client(self):
        """Inicializa ChromaDB apuntando a la ruta correcta (local o DBFS)."""
        try:
            import chromadb
        except ImportError:
            raise ImportError(
                "chromadb no instalado. Ejecutar:\n"
                "  pip install chromadb sentence-transformers\n"
                "En Databricks: %pip install chromadb sentence-transformers"
            )

        self.vectordb_path.mkdir(parents=True, exist_ok=True)
        client = chromadb.PersistentClient(path=str(self.vectordb_path))
        return client

    def _get_embedding_function(self):
        """
        Embeddings locales con sentence-transformers.
        No usa API externa → funciona sin internet en Databricks.
        Modelo: paraphrase-multilingual-MiniLM-L12-v2 (soporta español).
        """
        try:
            from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
            return SentenceTransformerEmbeddingFunction(
                model_name="paraphrase-multilingual-MiniLM-L12-v2"
            )
        except ImportError:
            raise ImportError(
                "sentence-transformers no instalado.\n"
                "  pip install sentence-transformers"
            )

    def _chunk_text(self, texto: str, nombre: str) -> List[Dict[str, Any]]:
        """Divide el texto en chunks con metadatos."""
        chunks = []
        start = 0
        idx = 0
        while start < len(texto):
            end = start + self.chunk_size
            chunk_text = texto[start:end]
            if chunk_text.strip():
                chunks.append({
                    "text":     chunk_text,
                    "id":       f"{nombre}_{idx}",
                    "metadata": {
                        "fuente":  nombre,
                        "dominio": self.dominio,
                        "chunk":   idx,
                    }
                })
            start = end - self.chunk_overlap
            idx += 1
        return chunks

    def _leer_archivo(self, path: Path) -> str:
        """
        Lee un archivo según su extensión (reutiliza los lectores de Mx_01).

        Devuelve "" si no se pudo leer. NUNCA devuelve un mensaje de error como
        si fuera contenido.

        [AUDIT-FIX] Aquí había tres defectos encadenados que se tapaban entre sí:

        1. `Path(__file__).parent.parent.parent.parent` son CUATRO saltos desde
           src/rag/base_indexer.py: rag → src → raíz → *el padre de la raíz*.
           Uno de más — el mismo error que tenía `_get_vectordb_base()`. Como
           `motor/` no está ahí, el `sys.path` quedaba mal y el import fallaba
           SIEMPRE.

        2. Por tanto nunca se usaba `leer_archivo_generico`, que existe en
           Mx_01 y sabe leer PDF, DOCX, XLSX y demás. Se caía al fallback, que
           solo entiende `.txt`.

        3. El fallback devolvía `f"[No se pudo leer: {path.name}]"` COMO
           CONTENIDO, y ese texto se troceaba y se indexaba. Medido tras
           indexar el dominio VaR: los chunks recuperados con mayor similitud
           eran literalmente «[No se pudo leer: riskmetrics_summary.md]».
           El RAG inyectaba sus propios errores en el prompt haciéndolos pasar
           por conocimiento experto — es la misma familia del bug de lectura
           fallida corregido en Mx_01, donde el mensaje de error entraba al
           pipeline como evidencia con cobertura 100%.
        """
        import sys
        # parents[2] desde src/rag/base_indexer.py = raíz del proyecto.
        raiz = Path(__file__).resolve().parents[2]
        motor_dir = raiz / "motor"
        if motor_dir.is_dir() and str(motor_dir) not in sys.path:
            sys.path.insert(0, str(motor_dir))

        try:
            from Mx_01_LecturaEvidencias import (
                leer_archivo_generico, _MARCA_LECTURA_FALLIDA,
            )
            texto = leer_archivo_generico(str(path)) or ""
            # Mx_01 prefija sus fallos con un centinela justamente para que el
            # consumidor no los confunda con contenido. Respetarlo.
            if _MARCA_LECTURA_FALLIDA in texto:
                logger.warning("[%s] No se pudo leer %s; se omite del índice.",
                               self.dominio, path.name)
                return ""
            return texto
        except ImportError as exc:
            logger.warning("[%s] Lectores de Mx_01 no disponibles (%s).",
                           self.dominio, exc)
        except Exception as exc:
            logger.warning("[%s] Error leyendo %s: %s", self.dominio, path.name, exc)
            return ""

        # Fallback mínimo: solo texto plano. Un fallo devuelve cadena vacía y el
        # fichero queda FUERA del índice, que es lo correcto: un índice más
        # pequeño es recuperable; uno contaminado con mensajes de error envenena
        # todos los prompts en silencio.
        if path.suffix.lower() in (".txt", ".md"):
            try:
                return path.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                return ""
        return ""

    def build_index(self, force_rebuild: bool = False) -> None:
        """
        Construye el índice vectorial para este dominio.

        Args:
            force_rebuild: Si True, borra el índice existente y lo reconstruye.
        """
        client     = self._get_chroma_client()
        embed_fn   = self._get_embedding_function()
        coll_name  = f"virf_{self.dominio}"

        # Borrar colección existente si se pide rebuild
        if force_rebuild:
            try:
                client.delete_collection(coll_name)
                logger.info(f"[{self.dominio}] Colección anterior eliminada.")
            except Exception:
                pass

        collection = client.get_or_create_collection(
            name=coll_name,
            embedding_function=embed_fn,
            metadata={"hnsw:space": "cosine"},
        )
        self._collection = collection

        fuentes = self.get_source_paths()
        total_chunks = 0

        for ruta in fuentes:
            archivos = list(ruta.rglob("*")) if ruta.is_dir() else [ruta]
            for archivo in archivos:
                if archivo.suffix not in {".pdf", ".docx", ".pptx", ".xlsx", ".py", ".txt", ".md"}:
                    continue
                # El README de cada carpeta explica QUÉ debe ir en ella; no es
                # conocimiento del dominio. Sin excluirlo, una consulta sobre
                # backtesting podría recuperar «Qué NO va aquí: la evidencia
                # del modelo…» y presentarlo como referencia experta.
                if archivo.stem.upper() in {"README", "LEEME", "LEEME_PRIMERO"}:
                    continue
                try:
                    texto = self._leer_archivo(archivo)
                    chunks = self._chunk_text(texto, archivo.name)
                    if not chunks:
                        continue

                    # [AUDIT-FIX] Antes el ID era `sha256(texto_del_chunk)`.
                    # Dos chunks con el MISMO texto producen el mismo ID, y
                    # ChromaDB rechaza el upsert entero con «Expected IDs to be
                    # unique». En un documento largo eso pasa constantemente:
                    # cabeceras, pies de página o secciones repetidas. Medido
                    # sobre Manual_Metodologico_LaR_completo.pdf: 11 IDs
                    # duplicados y el documento —el más valioso del índice—
                    # quedaba FUERA por completo, con el fallo reducido a una
                    # línea de warning entre decenas.
                    #
                    # El ID incorpora ahora fuente y posición, así que es único
                    # por chunk y sigue siendo ESTABLE entre reindexaciones: al
                    # reindexar el mismo documento, upsert actualiza en vez de
                    # duplicar.
                    ids = [
                        hashlib.sha256(
                            f"{archivo.name}|{c['metadata']['chunk']}|{c['text']}".encode()
                        ).hexdigest()[:16]
                        for c in chunks
                    ]
                    textos   = [c["text"] for c in chunks]
                    metas    = [c["metadata"] for c in chunks]

                    collection.upsert(ids=ids, documents=textos, metadatas=metas)
                    total_chunks += len(chunks)
                    logger.info(f"  ✓ {archivo.name}: {len(chunks)} chunks indexados")
                except Exception as e:
                    logger.warning(f"  ✗ {archivo.name}: {e}")

        logger.info(f"[{self.dominio}] Índice construido: {total_chunks} chunks totales.")
        print(f"✅ [{self.dominio}] Índice RAG listo: {total_chunks} chunks en {self.vectordb_path}")

    def get_collection(self):
        """Retorna la colección ChromaDB (la abre si no está cargada)."""
        if self._collection is None:
            client   = self._get_chroma_client()
            embed_fn = self._get_embedding_function()
            self._collection = client.get_or_create_collection(
                name=f"virf_{self.dominio}",
                embedding_function=embed_fn,
                metadata={"hnsw:space": "cosine"},
            )
        return self._collection
