"""
src/rag/__init__.py
====================
Dispatcher del sistema RAG segmentado por dominio financiero.

Uso:
    from src.rag import get_retriever
    retriever = get_retriever(tipo_modelo="LaR")
    contexto = retriever.query("¿Existe backtesting de Kupiec?", top_k=5)
"""

from __future__ import annotations
from typing import Literal

# Dominios RAG disponibles — agregar aquí al crear un nuevo dominio
DOMINIOS_DISPONIBLES = ["LaR", "VaR", "conductuales", "shared"]

# Mapeo palabras clave en --titulo → dominio RAG
# Se usa en get_retriever(titulo_modelo=...) para inferencia automática
_KEYWORDS_DOMINIO = {
    "LaR":          ["lar", "liquidity", "liquidez", "lic", "hqla"],
    "VaR":          ["var", "value at risk", "frtb", "market risk", "riesgo de mercado"],
    "conductuales": ["conductual", "prepago", "retiro", "nmd", "comportamiento", "behavioural"],
}


def inferir_dominio(titulo_modelo: str) -> str:
    """
    Infiere el dominio RAG a partir del título del modelo.
    Retorna 'shared' si no hay match.

    Ejemplo:
        inferir_dominio("Modelo LaR Liquidez")  → "LaR"
        inferir_dominio("VaR Mercado FRTB")     → "VaR"
        inferir_dominio("Scoring")              → "shared"
    """
    titulo_lower = titulo_modelo.lower()
    for dominio, keywords in _KEYWORDS_DOMINIO.items():
        if any(kw in titulo_lower for kw in keywords):
            return dominio
    return "shared"


def get_retriever(
    tipo_modelo: str | None = None,
    titulo_modelo: str | None = None,
):
    """
    Retorna el retriever del dominio correspondiente.

    Args:
        tipo_modelo:   Dominio explícito: "LaR" | "VaR" | "conductuales" | "shared"
        titulo_modelo: Si tipo_modelo es None, se infiere desde el título.

    Returns:
        Retriever del dominio (objeto con método .query())

    Ejemplo:
        # Explícito:
        retriever = get_retriever(tipo_modelo="LaR")

        # Por inferencia desde --titulo:
        retriever = get_retriever(titulo_modelo="Modelo LaR v2")
    """
    if tipo_modelo is None:
        if titulo_modelo is None:
            tipo_modelo = "shared"
        else:
            tipo_modelo = inferir_dominio(titulo_modelo)

    if tipo_modelo not in DOMINIOS_DISPONIBLES:
        raise ValueError(
            f"Dominio RAG '{tipo_modelo}' no existe. "
            f"Disponibles: {DOMINIOS_DISPONIBLES}"
        )

    # Import lazy para no cargar todos los índices en memoria
    if tipo_modelo == "LaR":
        from src.rag.LaR.retriever import LaRRetriever
        return LaRRetriever()
    elif tipo_modelo == "VaR":
        from src.rag.VaR.retriever import VaRRetriever
        return VaRRetriever()
    elif tipo_modelo == "conductuales":
        from src.rag.conductuales.retriever import ConductualesRetriever
        return ConductualesRetriever()
    else:
        from src.rag.shared.retriever import SharedRetriever
        return SharedRetriever()
