"""
src/rag/shared/retriever.py
============================
Retriever de conocimiento regulatorio compartido.
Fallback cuando el dominio del modelo no tiene índice específico.
Uso: SharedRetriever().query_para_prompt(texto, top_k=3)
"""
from src.rag.base_retriever import BaseRetriever
class SharedRetriever(BaseRetriever):
    dominio = "shared"
    def _get_indexer(self):
        from src.rag.shared.indexer import SharedIndexer
        return SharedIndexer()
