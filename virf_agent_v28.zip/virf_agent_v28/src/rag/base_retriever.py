"""
src/rag/base_retriever.py
==========================
Clase base para retrievers de todos los dominios RAG.

Responsabilidad: dado un texto de consulta, recuperar los chunks de
documentos más similares semánticamente desde el índice ChromaDB del
dominio. Expone `query()` (retorna lista de dicts) y `query_para_prompt()`
(retorna string listo para inyectar en el prompt del LLM).

Subclases concretas: LaRRetriever, VaRRetriever, ConductualesRetriever, SharedRetriever.
Cada subclase solo define `dominio` y `_get_indexer()`.

Uso:
    retriever = LaRRetriever()
    resultados = retriever.query("¿Se realizaron pruebas Kupiec?", top_k=5)
    # → lista de chunks relevantes para inyectar en el prompt
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

logger = logging.getLogger("virf.rag")


class BaseRetriever(ABC):
    """
    Retriever base para un dominio RAG.

    Subclases deben definir:
        - dominio: str (debe coincidir con el indexer del mismo dominio)
    """

    dominio: str = "base"

    def __init__(self):
        self._indexer = None

    def _get_indexer(self):
        """Importa y retorna el indexer del mismo dominio (lazy)."""
        raise NotImplementedError("Subclases deben implementar _get_indexer()")

    def query(
        self,
        texto_consulta: str,
        top_k: int = 5,
        filtro_fuente: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Recupera los chunks más relevantes para la consulta.

        Args:
            texto_consulta: Pregunta o actividad a evaluar.
            top_k:          Número de chunks a retornar.
            filtro_fuente:  Si se especifica, filtra por nombre de archivo fuente.

        Returns:
            Lista de dicts con keys: 'texto', 'fuente', 'dominio', 'score'

        Ejemplo:
            resultados = retriever.query(
                "¿El modelo documenta pruebas de backtesting Kupiec?",
                top_k=3
            )
            for r in resultados:
                print(f"[{r['fuente']}] score={r['score']:.3f}")
                print(r['texto'][:200])
        """
        try:
            indexer    = self._get_indexer()
            collection = indexer.get_collection()
        except Exception as e:
            logger.warning(f"[{self.dominio}] RAG no disponible: {e}. Devolviendo vacío.")
            return []

        where = {"dominio": self.dominio}
        if filtro_fuente:
            where["fuente"] = filtro_fuente

        try:
            results = collection.query(
                query_texts=[texto_consulta],
                n_results=min(top_k, 10),
                where=where if len(where) > 1 else None,
            )
        except Exception as e:
            logger.warning(f"[{self.dominio}] Error en query ChromaDB: {e}")
            return []

        chunks = []
        # [AUDIT-FIX] `results.get("clave", [[]])[0]` solo protege si la clave
        # FALTA; si viene presente pero vacía (`{"documents": []}`), el `[0]`
        # lanza IndexError. Es el mismo patrón que `.get("puntaje", 50)`
        # devolviendo None cuando la clave existe con valor nulo.
        def _primera_fila(clave):
            valor = (results or {}).get(clave) or [[]]
            return valor[0] if valor else []

        docs       = _primera_fila("documents")
        metas      = _primera_fila("metadatas")
        distancias = _primera_fila("distances")

        for doc, meta, dist in zip(docs, metas, distancias):
            # ChromaDB usa distancia coseno [0,2]; convertir a similitud [0,1]
            similitud = 1 - (dist / 2)
            chunks.append({
                "texto":   doc,
                "fuente":  meta.get("fuente", "desconocido"),
                "dominio": meta.get("dominio", self.dominio),
                "chunk":   meta.get("chunk", 0),
                "score":   round(similitud, 4),
            })

        return chunks

    def query_para_prompt(
        self,
        texto_consulta: str,
        top_k: int = 5,
        min_score: float = 0.3,
    ) -> str:
        """
        Versión lista para inyectar en el prompt de evaluación.
        Retorna string formateado con los chunks relevantes.

        Args:
            texto_consulta: Actividad o pregunta a evaluar.
            top_k:          Número máximo de chunks.
            min_score:      Umbral mínimo de similitud (0-1).

        Returns:
            String listo para insertar en el prompt, o "" si no hay resultados.

        Uso típico en evaluar_actividad():
            contexto_rag = retriever.query_para_prompt(actividad, top_k=3)
            if contexto_rag:
                prompt += f"\\n\\n--- CONOCIMIENTO RAG ({dominio}) ---\\n{contexto_rag}"
        """
        resultados = self.query(texto_consulta, top_k=top_k)
        relevantes = [r for r in resultados if r["score"] >= min_score]

        if not relevantes:
            return ""

        partes = [f"## Conocimiento recuperado — dominio: {self.dominio}\n"]
        for i, r in enumerate(relevantes, 1):
            partes.append(
                f"### [{i}] Fuente: {r['fuente']} (similitud: {r['score']:.2f})\n"
                f"{r['texto'].strip()}\n"
            )

        return "\n".join(partes)
