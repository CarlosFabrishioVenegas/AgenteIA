"""
modulos/revision_codigo.py
═══════════════════════════════════════════════════════════════════════════════
REVISIÓN DEL CÓDIGO CONTRA LA DOCUMENTACIÓN — una llamada por módulo.

QUÉ RESUELVE
────────────
El ámbito «Implementación» del estándar VIRF pide contrastar el código contra
el manual: qué funciones documentadas existen de verdad, qué hay en el código
que nadie documentó, y qué se cambió sin actualizar la documentación (*code
drift*). La instrucción que se inyecta al modelo lo pide literalmente
(`Mx_00.INSTRUCCIONES_DIMENSION["Implementación"]`).

Pero el pipeline por ámbito no puede cumplirlo con un modelo real:

  · Todo el ámbito comparte un presupuesto de `VIRF_MAX_CTX` (15.000 chars por
    defecto) que además debe alojar el manual metodológico. Un modelo con sus
    propias librerías en `libs/` son fácilmente 200.000 chars: no caben, y lo
    que entra desplaza al manual contra el que había que contrastar.
  · Una sola respuesta JSON tiene que cubrir el árbol entero, así que los
    hallazgos salen genéricos («faltaría documentar algunas funciones») en vez
    de accionables («`libs/calculo.py:87` define `_ajuste_cf()`, que no aparece
    en el manual»).

DISEÑO: UN MÓDULO, UNA LLAMADA
──────────────────────────────
Cada fichero `.py`/`.ipynb` se revisa en su propia llamada, con el manual
metodológico como contexto FIJO. Consecuencias:

  · Cada módulo entra ÍNTEGRO. No compite por presupuesto con sus hermanos.
  · Los hallazgos se atribuyen a `fichero:línea`, porque el módulo se numera
    antes de enviarlo (`_numerar_lineas`) — un LLM no cuenta líneas fiablemente,
    hay que dárselas escritas.
  · El coste es proporcional al número de módulos y se conoce ANTES de gastar
    (`inventario()`), no después.

POR QUÉ EL INVENTARIO ES OBLIGATORIO
────────────────────────────────────
Este flujo multiplica las llamadas por el número de ficheros. Si el árbol que
se copió a `inputs/implementacion/` arrastra un `.venv/` o un `site-packages/`,
son miles de módulos y miles de llamadas. El proyecto NO excluye esas carpetas
por decisión explícita del operador, así que la defensa no puede ser un filtro
oculto: es declarar el coste y exigir confirmación. `--dry-run` muestra el
inventario sin gastar un token.

Quien quiera el filtro puede activarlo con `VIRF_EXCLUIR_DEPENDENCIAS=1`; viene
DESACTIVADO para no descartar código en silencio.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger("virf.revision_codigo")

__all__ = [
    "RevisorCodigo", "HallazgoCodigo",
    "descubrir_modulos", "inventario",
    "CATEGORIAS_HALLAZGO", "PATRONES_DEPENDENCIAS",
]

# ─────────────────────────────────────────────────────────────────────────────
# Catálogo de hallazgos
# ─────────────────────────────────────────────────────────────────────────────
# Cerrado a propósito: si el modelo pudiera inventar categorías, consolidar los
# resultados de 30 módulos sería imposible (cada uno nombraría lo mismo de otra
# forma). El prompt exige usar exactamente estas claves.
CATEGORIAS_HALLAZGO = {
    "no_documentado":     "Existe en el código y el manual no lo declara",
    "documentado_ausente": "El manual lo declara y no existe en el código",
    "code_drift":         "Existe en ambos pero no coinciden (fórmula, parámetro, umbral)",
    "supuesto_tacito":    "El código asume algo que el manual no declara ni justifica",
    "riesgo_tecnico":     "Defecto que afecta al resultado del modelo",
}

# Severidades admitidas, de mayor a menor. Orden significativo: se usa para
# ordenar el informe consolidado.
SEVERIDADES = ("critica", "alta", "media", "baja")

# Carpetas de dependencias de terceros. NO se excluyen por defecto: el operador
# pidió explícitamente que solo se excluyera `.env`. Se activan con
# VIRF_EXCLUIR_DEPENDENCIAS=1.
PATRONES_DEPENDENCIAS = frozenset({
    "site-packages", ".venv", "venv", "env", "node_modules", "vendor",
    ".tox", ".eggs", "dist-info",
})

# [CONFIG-CENTRAL] Los tres parámetros de este módulo se declaran en
# config/parametros.py, no aquí. Una primera versión los leía con `os.getenv`
# en este fichero y el test `TestConfigCentral` lo rechazó, con razón: el
# proyecto ya pagó tener VIRF_MAX_CTX declarado en dos sitios con defaults
# distintos. Se conservan los nombres locales como alias, igual que hacen
# chunker.py y Mx_01, para no obligar a quien importe a conocer la ruta.
from config.parametros import (
    MAX_CHARS_MANUAL_REVISION as MAX_CHARS_MANUAL_CONTEXTO,
    MAX_CHARS_MODULO as MAX_CHARS_MODULO_POR_LLAMADA,
)


@dataclass
class HallazgoCodigo:
    """Un hallazgo atribuido a un punto concreto del código."""
    fichero: str
    linea: Optional[int]
    categoria: str
    severidad: str
    elemento: str          # función, clase o bloque afectado
    descripcion: str
    evidencia_codigo: str = ""
    referencia_manual: str = ""

    def a_dict(self) -> Dict[str, Any]:
        return {
            "fichero": self.fichero,
            "linea": self.linea,
            "categoria": self.categoria,
            "severidad": self.severidad,
            "elemento": self.elemento,
            "descripcion": self.descripcion,
            "evidencia_codigo": self.evidencia_codigo,
            "referencia_manual": self.referencia_manual,
        }

    @property
    def ubicacion(self) -> str:
        return f"{self.fichero}:{self.linea}" if self.linea else self.fichero


# ─────────────────────────────────────────────────────────────────────────────
# Descubrimiento e inventario
# ─────────────────────────────────────────────────────────────────────────────

def _excluir_dependencias_activo() -> bool:
    """
    Lee el flag EN RUNTIME, no al importar.

    La constante `config.parametros.EXCLUIR_DEPENDENCIAS` se fija al importar el
    módulo, lo que basta para una corrida normal pero impide que un test cambie
    el entorno después. Se delega en la misma función de parseo del paquete de
    configuración para que «1/true/sí» signifiquen lo mismo aquí que en el resto
    del proyecto — reimplementar el parseo booleano es cómo divergen dos
    lecturas del mismo flag.
    """
    from config.parametros import _booleano
    return _booleano("VIRF_EXCLUIR_DEPENDENCIAS", False)


def descubrir_modulos(raiz, extensiones=None) -> List[Path]:
    """
    Módulos de código bajo `raiz`, recursivo.

    Reutiliza `Mx_01._es_evidencia()` como criterio de exclusión para no tener
    un segundo catálogo de qué se ignora: esa función ya descarta `__pycache__`,
    `.git`, `.ipynb_checkpoints`, `datasets/`, los temporales de Office (`~$`) y
    todo fichero oculto — incluido `.env`, que es lo único que el operador pidió
    excluir explícitamente.
    """
    raiz = Path(raiz)
    if not raiz.is_dir():
        return []

    if extensiones is None:
        try:
            from motor.Mx_01_LecturaEvidencias import EXTENSIONES_CODIGO
            extensiones = set(EXTENSIONES_CODIGO)
        except ImportError:
            extensiones = {".py", ".ipynb"}

    try:
        from motor.Mx_01_LecturaEvidencias import _es_evidencia
    except ImportError:                                   # pragma: no cover
        def _es_evidencia(p):                             # noqa: E306
            return not p.name.startswith((".", "~$"))

    encontrados: List[Path] = []
    excluir_deps = _excluir_dependencias_activo()

    for path in sorted(raiz.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in extensiones:
            continue
        if not _es_evidencia(path):
            continue
        if excluir_deps:
            partes = {p.lower() for p in path.parts}
            if partes & PATRONES_DEPENDENCIAS:
                continue
        encontrados.append(path)
    return encontrados


def inventario(modulos: List[Path], raiz=None,
               chars_manual: int = 0) -> Dict[str, Any]:
    """
    Inventario con coste estimado. NO llama al modelo.

    El coste se calcula sobre lo que realmente se va a enviar: el código de cada
    módulo MÁS el manual repetido en cada llamada. Omitir el manual daría una
    cifra optimista justo en el factor que más pesa cuando hay muchos módulos.
    """
    from config.modelos import CHARS_POR_TOKEN_ES, precio_entrada_por_mtok

    raiz = Path(raiz) if raiz else None
    detalle = []
    chars_codigo = 0
    n_llamadas = 0

    for m in modulos:
        try:
            chars = len(m.read_text(encoding="utf-8", errors="replace"))
        except OSError as exc:
            logger.warning("No se pudo medir '%s': %s", m, exc)
            chars = 0
        # Un módulo por encima del tope se parte en varias llamadas.
        llamadas = max(1, -(-chars // MAX_CHARS_MODULO_POR_LLAMADA)) if chars else 1
        chars_codigo += chars
        n_llamadas += llamadas
        detalle.append({
            "fichero": str(m.relative_to(raiz)) if raiz and raiz in m.parents else m.name,
            "chars": chars,
            "llamadas": llamadas,
            "tipo": m.suffix.lstrip(".").upper(),
        })

    manual_efectivo = min(chars_manual, MAX_CHARS_MANUAL_CONTEXTO)
    chars_totales = chars_codigo + manual_efectivo * n_llamadas
    tokens = chars_totales / CHARS_POR_TOKEN_ES

    try:
        from motor.Mx_00_CargaRutas import MODELO_IA as _modelo
    except ImportError:                                   # pragma: no cover
        _modelo = None
    precio = precio_entrada_por_mtok(_modelo)

    return {
        "n_modulos": len(modulos),
        "n_llamadas": n_llamadas,
        "chars_codigo": chars_codigo,
        "chars_manual_por_llamada": manual_efectivo,
        "chars_totales_entrada": int(chars_totales),
        "tokens_estimados": int(tokens),
        "modelo": _modelo or "(desconocido)",
        "precio_entrada_usd_mtok": precio,
        "coste_estimado_usd": round(tokens / 1_000_000 * precio, 4),
        "detalle": sorted(detalle, key=lambda d: -d["chars"]),
        "dependencias_excluidas": _excluir_dependencias_activo(),
    }


def formatear_inventario(inv: Dict[str, Any], max_filas: int = 25) -> str:
    """Inventario legible para consola. Se imprime SIEMPRE antes de gastar."""
    sep = "═" * 74
    lin = [
        "", sep,
        "  🔍 INVENTARIO DE REVISIÓN DE CÓDIGO",
        sep,
        f"  Módulos encontrados : {inv['n_modulos']}",
        f"  Llamadas al modelo  : {inv['n_llamadas']}",
        f"  Código              : {inv['chars_codigo']:,} chars",
        f"  Manual por llamada  : {inv['chars_manual_por_llamada']:,} chars "
        f"(× {inv['n_llamadas']} llamadas)",
        f"  Entrada total       : {inv['chars_totales_entrada']:,} chars "
        f"≈ {inv['tokens_estimados']:,} tokens",
        f"  Modelo              : {inv['modelo']} "
        f"(${inv['precio_entrada_usd_mtok']:.2f}/Mtok entrada)",
        f"  COSTE ESTIMADO      : ~${inv['coste_estimado_usd']:.4f}",
    ]
    if not inv["dependencias_excluidas"]:
        lin.append("  ⚠️  Filtro de dependencias DESACTIVADO: si el árbol incluye")
        lin.append("      .venv/ o site-packages/, sus módulos también se revisarán.")
        lin.append("      Actívalo con VIRF_EXCLUIR_DEPENDENCIAS=1")
    lin += ["  " + "─" * 70, "  Módulos (mayor primero):"]
    for d in inv["detalle"][:max_filas]:
        lin.append(f"    {d['fichero']:<48} {d['chars']:>9,} chars"
                   + (f"  [{d['llamadas']} llamadas]" if d["llamadas"] > 1 else ""))
    if len(inv["detalle"]) > max_filas:
        lin.append(f"    ... y {len(inv['detalle']) - max_filas} módulo(s) más")
    lin += [sep, ""]
    return "\n".join(lin)


# ─────────────────────────────────────────────────────────────────────────────
# Preparación del código para el prompt
# ─────────────────────────────────────────────────────────────────────────────

def _numerar_lineas(texto: str, desde: int = 1) -> str:
    """
    Prefija cada línea con su número.

    Sin esto los hallazgos no son accionables: un LLM no cuenta líneas de forma
    fiable y devuelve números inventados que apuntan a código que no es el
    citado. Dárselas escritas convierte la cita en verificable.
    """
    lineas = texto.splitlines()
    ancho = len(str(desde + len(lineas)))
    return "\n".join(f"{i:>{ancho}} | {l}"
                     for i, l in enumerate(lineas, start=desde))


# Fronteras de definición por lenguaje. Cortar aquí —y no por ventanas de
# caracteres— evita partir una función por la mitad: media función revisada
# contra el manual produce hallazgos FALSOS («no valida la entrada» cuando la
# validación se quedó en el otro bloque).
FRONTERAS_POR_LENGUAJE = {
    # Definiciones de nivel superior, sin indentar.
    "python": re.compile(r"^(?:def |class |@|async def )"),
    # R declara funciones por asignación: `estimar <- function(x)`. También se
    # admite `=` porque hay bases de código que lo usan.
    "r":      re.compile(r"^\s*[\w.]+\s*(?:<-|=)\s*function\s*\("),
    # SQL no tiene funciones de nivel superior en el mismo sentido: la unidad
    # natural es la sentencia. Se corta en las que empiezan un objeto o una
    # consulta, que es lo que un validador contrasta contra el manual.
    "sql":    re.compile(
        r"^\s*(?:CREATE|INSERT|UPDATE|DELETE|MERGE|WITH|SELECT|DROP|ALTER|"
        r"TRUNCATE|GRANT)\b", re.IGNORECASE),
}

# Lenguajes en los que una frontera SOLO es válida si la sentencia anterior ya
# terminó. En SQL, `SELECT` es token de frontera y también aparece DENTRO de
# `CREATE TABLE x AS SELECT …`: sin esta guarda, el corte partía esa sentencia
# en dos y cada mitad se revisaba por separado — media consulta contrastada
# contra el manual produce el mismo hallazgo falso que media función.
_EXIGEN_TERMINADOR = {"sql": ";"}


def _sentencia_cerrada(acumulado: List[str], terminador: str) -> bool:
    """True si el texto acumulado termina en el terminador de sentencia."""
    texto = "".join(acumulado).rstrip()
    # Se ignoran los comentarios de línea finales: `; -- carga inicial` cierra.
    while texto.endswith(("*/",)) or "--" in texto.split("\n")[-1]:
        lineas = texto.split("\n")
        if "--" in lineas[-1]:
            lineas[-1] = lineas[-1].split("--")[0]
        texto = "\n".join(lineas).rstrip()
        if not texto or not ("--" in texto.split("\n")[-1]):
            break
    return texto.endswith(terminador)


def _lenguaje_de(ruta) -> str:
    """
    Lenguaje del fichero a partir de su extensión.

    Se delega en el catálogo de `Mx_01` para no tener un segundo mapa: si
    mañana se añade una extensión allí y aquí no, el fichero se revisaría
    etiquetado como Python y troceado con fronteras que no son las suyas.
    """
    try:
        from motor.Mx_01_LecturaEvidencias import LENGUAJE_POR_EXT
    except ImportError:                                   # pragma: no cover
        LENGUAJE_POR_EXT = {".py": "python", ".ipynb": "python",
                            ".sql": "sql", ".r": "r"}
    return LENGUAJE_POR_EXT.get(Path(ruta).suffix.lower(), "python")


def _partir_por_definiciones(texto: str, max_chars: int,
                             lenguaje: str = "python") -> List[tuple]:
    """
    Parte un módulo grande en bloques que empiezan en una frontera de definición.

    Devuelve [(linea_inicial, texto_bloque), …].

    `lenguaje` decide dónde está esa frontera (ver FRONTERAS_POR_LENGUAJE). Con
    el default de Python aplicado a un script de R, NINGUNA línea casaría y el
    fichero entero caería al reparto por ventanas: funcionaría, pero cortando
    funciones por la mitad, que es justo lo que este corte existe para evitar.
    """
    lineas = texto.splitlines(keepends=True)
    if len(texto) <= max_chars:
        return [(1, texto)]

    frontera = FRONTERAS_POR_LENGUAJE.get(
        lenguaje, FRONTERAS_POR_LENGUAJE["python"])
    bloques: List[tuple] = []
    actual: List[str] = []
    linea_inicio = 1
    chars = 0

    terminador = _EXIGEN_TERMINADOR.get(lenguaje)

    for idx, linea in enumerate(lineas, start=1):
        es_frontera = bool(frontera.match(linea))
        # En SQL, una frontera a mitad de sentencia no es frontera.
        if es_frontera and terminador and actual:
            es_frontera = _sentencia_cerrada(actual, terminador)
        if actual and es_frontera and chars + len(linea) > max_chars:
            bloques.append((linea_inicio, "".join(actual)))
            actual, chars, linea_inicio = [], 0, idx
        actual.append(linea)
        chars += len(linea)

    if actual:
        bloques.append((linea_inicio, "".join(actual)))

    # Si el fichero no tiene definiciones de nivel superior (un script plano),
    # no hay frontera donde cortar: se cae a ventanas de líneas.
    #
    # El corte se hace acumulando CARACTERES, no un número fijo de líneas. Una
    # primera versión usaba `paso = max_chars // 80` asumiendo 80 chars por
    # línea: con un script de líneas cortas (`x = 1`) partía 18.000 chars en 49
    # bloques de ~370 chars, es decir 49 llamadas donde bastaban 4. El ancho de
    # línea es un dato del fichero, no una constante que se pueda suponer.
    if len(bloques) == 1 and len(texto) > max_chars:
        bloques = []
        actual, chars, linea_inicio = [], 0, 1
        for idx, linea in enumerate(lineas, start=1):
            if actual and chars + len(linea) > max_chars:
                bloques.append((linea_inicio, "".join(actual)))
                actual, chars, linea_inicio = [], 0, idx
            actual.append(linea)
            chars += len(linea)
        if actual:
            bloques.append((linea_inicio, "".join(actual)))
    return bloques


# ─────────────────────────────────────────────────────────────────────────────
# El revisor
# ─────────────────────────────────────────────────────────────────────────────

_PROMPT_REVISION = """\
Eres un validador de modelos de riesgo (segunda línea de defensa) revisando el
CÓDIGO de un modelo cuantitativo contra su DOCUMENTACIÓN METODOLÓGICA.

## Documentación metodológica del modelo
{manual}

## Módulo bajo revisión: {fichero}{nota_bloque}
Lenguaje: {lenguaje}
```{lenguaje}
{codigo}
```

## Tu tarea

Contrasta ESTE módulo contra la documentación de arriba y devuelve hallazgos.

REGLAS QUE NO PUEDES INCUMPLIR:

1. Cita SIEMPRE el número de línea que aparece a la izquierda del código. No
   inventes números: si no puedes ubicar algo, pon `null`.
2. Si la documentación NO menciona el área que cubre este módulo, dilo con la
   categoría `no_documentado`. No supongas que "estará documentado en otra
   parte".
3. NO inventes contenido de la documentación. Si afirmas que el manual dice
   algo, cita el fragmento en `referencia_manual`.
4. Si el módulo es coherente con la documentación, devuelve `hallazgos: []`.
   Un módulo correcto es un resultado válido — no fuerces hallazgos.
5. Solo estas categorías: {categorias}
6. Solo estas severidades: {severidades}

Devuelve EXCLUSIVAMENTE un objeto JSON con esta forma:

{{
  "resumen_modulo": "qué hace este módulo, en dos frases",
  "elementos_definidos": ["nombre_funcion_o_clase", "..."],
  "hallazgos": [
    {{
      "linea": 87,
      "categoria": "no_documentado",
      "severidad": "alta",
      "elemento": "_ajuste_cornish_fisher",
      "descripcion": "Aplica un ajuste de Cornish-Fisher que la documentación no menciona.",
      "evidencia_codigo": "z + (z**2 - 1) * skew / 6",
      "referencia_manual": ""
    }}
  ]
}}
"""


class RevisorCodigo:
    """
    Revisa el código de un modelo contra su documentación, módulo a módulo.

    El cliente IA se inyecta ya inicializado, igual que en `ChunkerService`: así
    el pre-flight de credencial protege esta fase y el rate limiting queda en un
    único punto.
    """

    def __init__(self, cliente_ia, max_chars_modulo: Optional[int] = None,
                 max_chars_manual: Optional[int] = None):
        self.cliente = cliente_ia
        self.max_chars_modulo = max_chars_modulo or MAX_CHARS_MODULO_POR_LLAMADA
        self.max_chars_manual = max_chars_manual or MAX_CHARS_MANUAL_CONTEXTO
        self._llamadas = 0
        self._fallos: List[Dict] = []

    # ── una llamada ─────────────────────────────────────────────────────────
    def revisar_bloque(self, fichero: str, codigo_numerado: str, manual: str,
                       nota_bloque: str = "",
                       lenguaje: str = "python") -> Dict[str, Any]:
        prompt = _PROMPT_REVISION.format(
            manual=manual or "⚠️ SIN DOCUMENTACIÓN METODOLÓGICA DISPONIBLE.",
            fichero=fichero,
            nota_bloque=nota_bloque,
            lenguaje=lenguaje,
            codigo=codigo_numerado,
            categorias=", ".join(f"`{k}`" for k in CATEGORIAS_HALLAZGO),
            severidades=", ".join(f"`{s}`" for s in SEVERIDADES),
        )
        self._llamadas += 1
        respuesta = self.cliente.generar_mensaje(
            prompt=prompt,
            instruccion_sistema=(
                "Validador de modelos de riesgo. Respondes SOLO con JSON válido. "
                "No inventas contenido documental ni números de línea."
            ),
        )
        return self._parsear(respuesta, fichero)

    @staticmethod
    def _parsear(respuesta: str, fichero: str) -> Dict[str, Any]:
        """
        Parsea la respuesta reutilizando el ÚNICO extractor JSON del proyecto.

        `motor_ia._extraer_json` cuenta llaves siendo consciente de strings y
        escapes. El proyecto ya pagó tener dos parsers —uno débil basado en
        `find`/`rfind` que fusionaba dos objetos seguidos en JSON inválido— y
        hay un test (`TestAuditoriaUnSoloParserJSON`) que impide reintroducirlo.
        """
        from modulos.motor_ia import _extraer_json
        try:
            return _extraer_json(respuesta)
        except json.JSONDecodeError as exc:
            logger.warning("JSON no parseable en '%s': %s", fichero, exc)
            return {
                "resumen_modulo": "",
                "elementos_definidos": [],
                "hallazgos": [],
                "_error_parseo": str(exc),
                "_raw": (respuesta or "")[:500],
            }

    # ── un módulo (puede ser varias llamadas) ───────────────────────────────
    def revisar_modulo(self, ruta: Path, manual: str,
                       nombre_relativo: Optional[str] = None) -> Dict[str, Any]:
        nombre = nombre_relativo or ruta.name
        try:
            from motor.Mx_01_LecturaEvidencias import LECTORES_EXT
            lector = LECTORES_EXT.get(ruta.suffix.lower())
            texto = lector(ruta) if lector else ruta.read_text(
                encoding="utf-8", errors="replace")
        except Exception as exc:                          # noqa: BLE001
            logger.error("No se pudo leer '%s': %s", nombre, exc)
            self._fallos.append({"fichero": nombre, "error": str(exc)})
            return {"fichero": nombre, "error": str(exc),
                    "hallazgos": [], "revision_valida": False}

        # El lenguaje decide DÓNDE se corta el fichero y con qué etiqueta viaja
        # al prompt. Un script de R troceado con las fronteras de Python cortaría
        # funciones por la mitad, y presentarlo como ```python invita al modelo a
        # "corregir" sintaxis que no está rota.
        lenguaje = _lenguaje_de(ruta)

        bloques = _partir_por_definiciones(texto, self.max_chars_modulo, lenguaje)
        hallazgos: List[Dict] = []
        elementos: List[str] = []
        resumenes: List[str] = []
        valida = True

        for i, (linea_ini, bloque) in enumerate(bloques, start=1):
            nota = (f" (bloque {i}/{len(bloques)}, desde la línea {linea_ini})"
                    if len(bloques) > 1 else "")
            numerado = _numerar_lineas(bloque, desde=linea_ini)
            try:
                res = self.revisar_bloque(nombre, numerado, manual, nota,
                                          lenguaje=lenguaje)
            except Exception as exc:                      # noqa: BLE001
                # Un fallo técnico NO se convierte en "módulo sin hallazgos":
                # se marca, igual que hace el pipeline con las actividades.
                logger.error("Fallo revisando '%s' bloque %d: %s", nombre, i, exc)
                self._fallos.append({"fichero": nombre, "bloque": i,
                                     "error": str(exc)})
                valida = False
                continue

            if res.get("_error_parseo"):
                valida = False
            resumenes.append(str(res.get("resumen_modulo", "")).strip())
            elementos.extend(str(e) for e in (res.get("elementos_definidos") or []))
            for h in (res.get("hallazgos") or []):
                hallazgos.append(self._normalizar_hallazgo(h, nombre))

        return {
            "fichero": nombre,
            "lenguaje": lenguaje,
            "chars": len(texto),
            "n_bloques": len(bloques),
            "resumen_modulo": " ".join(r for r in resumenes if r)[:600],
            "elementos_definidos": sorted(set(elementos)),
            "hallazgos": hallazgos,
            "revision_valida": valida,
        }

    @staticmethod
    def _normalizar_hallazgo(bruto: Dict, fichero: str) -> Dict[str, Any]:
        """
        Normaliza un hallazgo del modelo al contrato interno.

        Categorías y severidades fuera del catálogo se reetiquetan en vez de
        descartarse: un hallazgo real con la etiqueta mal puesta sigue siendo un
        hallazgo, y perderlo por un problema de vocabulario sería peor que
        clasificarlo como genérico.
        """
        cat = str(bruto.get("categoria", "")).strip().lower()
        if cat not in CATEGORIAS_HALLAZGO:
            cat = "riesgo_tecnico"
        sev = str(bruto.get("severidad", "")).strip().lower()
        if sev not in SEVERIDADES:
            sev = "media"
        linea = bruto.get("linea")
        try:
            linea = int(linea) if linea is not None else None
        except (TypeError, ValueError):
            linea = None
        return HallazgoCodigo(
            fichero=fichero,
            linea=linea,
            categoria=cat,
            severidad=sev,
            elemento=str(bruto.get("elemento", ""))[:120],
            descripcion=str(bruto.get("descripcion", ""))[:800],
            evidencia_codigo=str(bruto.get("evidencia_codigo", ""))[:300],
            referencia_manual=str(bruto.get("referencia_manual", ""))[:300],
        ).a_dict()

    # ── el árbol completo ───────────────────────────────────────────────────
    def revisar(self, modulos: List[Path], manual: str,
                raiz=None, verbose: bool = True) -> Dict[str, Any]:
        raiz = Path(raiz) if raiz else None
        manual_recortado = (manual or "")[:self.max_chars_manual]
        if manual and len(manual) > self.max_chars_manual:
            logger.info("Manual recortado a %d de %d chars para la revisión.",
                        self.max_chars_manual, len(manual))

        resultados = []
        for i, m in enumerate(modulos, start=1):
            rel = (str(m.relative_to(raiz))
                   if raiz and raiz in m.parents else m.name)
            if verbose:
                print(f"    [{i}/{len(modulos)}] revisando {rel} …", flush=True)
            res = self.revisar_modulo(m, manual_recortado, nombre_relativo=rel)
            if verbose:
                n = len(res.get("hallazgos", []))
                estado = "✗ fallo" if not res.get("revision_valida") else f"{n} hallazgo(s)"
                print(f"         → {estado}")
            resultados.append(res)

        return self.consolidar(resultados, manual_disponible=bool(manual))

    def consolidar(self, resultados: List[Dict],
                   manual_disponible: bool = True) -> Dict[str, Any]:
        """Agrega los resultados por módulo en un informe único."""
        todos: List[Dict] = []
        for r in resultados:
            todos.extend(r.get("hallazgos", []))

        por_categoria: Dict[str, List[Dict]] = {k: [] for k in CATEGORIAS_HALLAZGO}
        for h in todos:
            por_categoria.setdefault(h["categoria"], []).append(h)

        por_severidad = {s: sum(1 for h in todos if h["severidad"] == s)
                         for s in SEVERIDADES}

        n_validos = sum(1 for r in resultados if r.get("revision_valida"))
        n_fallidos = len(resultados) - n_validos

        return {
            "n_modulos": len(resultados),
            "n_modulos_revisados_ok": n_validos,
            "n_modulos_con_fallo": n_fallidos,
            "n_llamadas": self._llamadas,
            "manual_disponible": manual_disponible,
            "n_hallazgos": len(todos),
            "por_severidad": por_severidad,
            "por_categoria": {k: len(v) for k, v in por_categoria.items()},
            "hallazgos": sorted(
                todos,
                key=lambda h: (SEVERIDADES.index(h["severidad"])
                               if h["severidad"] in SEVERIDADES else 99,
                               h["fichero"], h["linea"] or 0),
            ),
            "modulos": resultados,
            "fallos_tecnicos": self._fallos,
            # Misma semántica que en el pipeline: si algún módulo falló
            # técnicamente, la revisión está incompleta y no debe sostener un
            # dictamen. No se disimula con "0 hallazgos".
            "revision_confiable": n_fallidos == 0 and len(resultados) > 0,
        }


# ─────────────────────────────────────────────────────────────────────────────
# Informe legible
# ─────────────────────────────────────────────────────────────────────────────

_ICONO_SEV = {"critica": "🔴", "alta": "🟠", "media": "🟡", "baja": "⚪"}


def informe_markdown(cons: Dict[str, Any], modelo: str = "") -> str:
    """Informe Markdown del resultado consolidado."""
    from datetime import datetime

    lin = [
        f"# Revisión de código contra documentación — {modelo or 'modelo'}",
        "",
        f"Generado por `modulos/revision_codigo.py` el "
        f"{datetime.now().strftime('%Y-%m-%d %H:%M')}.",
        "",
        "## Resumen",
        "",
        f"- Módulos revisados: **{cons['n_modulos_revisados_ok']}/{cons['n_modulos']}**",
        f"- Llamadas al modelo: {cons['n_llamadas']}",
        f"- Hallazgos: **{cons['n_hallazgos']}**",
        f"- Revisión confiable: **{cons['revision_confiable']}**",
    ]
    if not cons["manual_disponible"]:
        lin += ["", "> ⚠️ **No había documentación metodológica.** Los hallazgos "
                    "describen el código, pero NO son un contraste: sin manual no "
                    "hay nada contra lo que comparar."]
    if cons["n_modulos_con_fallo"]:
        lin += ["", f"> ⚠️ **{cons['n_modulos_con_fallo']} módulo(s) no se "
                    f"revisaron por fallo técnico.** La revisión está incompleta; "
                    f"re-ejecuta antes de emitir dictamen."]

    lin += ["", "### Por severidad", ""]
    for s in SEVERIDADES:
        lin.append(f"- {_ICONO_SEV[s]} {s}: {cons['por_severidad'].get(s, 0)}")

    lin += ["", "### Por categoría", ""]
    for k, desc in CATEGORIAS_HALLAZGO.items():
        lin.append(f"- `{k}` ({desc}): {cons['por_categoria'].get(k, 0)}")

    lin += ["", "## Hallazgos", ""]
    if not cons["hallazgos"]:
        lin.append("Ninguno. El código revisado es coherente con la documentación.")
    for h in cons["hallazgos"]:
        ubic = f"{h['fichero']}:{h['linea']}" if h["linea"] else h["fichero"]
        lin += [
            f"### {_ICONO_SEV.get(h['severidad'], '·')} `{ubic}` — {h['elemento'] or '—'}",
            "",
            f"**Categoría:** `{h['categoria']}` · **Severidad:** {h['severidad']}",
            "",
            h["descripcion"],
        ]
        if h["evidencia_codigo"]:
            lin += ["", "```python", h["evidencia_codigo"], "```"]
        if h["referencia_manual"]:
            lin += ["", f"> Documentación: {h['referencia_manual']}"]
        lin.append("")

    lin += ["## Inventario de módulos", "",
            "| Módulo | Chars | Hallazgos | Revisión |", "|---|---:|---:|---|"]
    for m in sorted(cons["modulos"], key=lambda x: x.get("fichero", "")):
        ok = "✅" if m.get("revision_valida") else "❌ fallo"
        lin.append(f"| `{m.get('fichero','?')}` | {m.get('chars',0):,} | "
                   f"{len(m.get('hallazgos', []))} | {ok} |")
    return "\n".join(lin) + "\n"
