"""
modulos/validador_humano.py
═══════════════════════════════════════════════════════════════════════════════
FIRMA Y RESPONSABILIDAD DEL VALIDADOR HUMANO — segregación de funciones.

Requisito de cumplimiento. SR 11-7 §V exige que la validación la ejecute
personal con independencia efectiva y que exista un responsable identificable;
EBA/GL/2023/01 §5 exige poder demostrar la segregación entre quien desarrolla,
quien ejecuta y quien aprueba.

La pregunta del auditor que esto responde es directa: **«¿quién firmó esto?»**
Un informe sin responsable humano identificable es un informe que nadie asumió,
y por tanto no acredita validación independiente: acredita que se ejecutó un
programa.

Tres piezas:

  2.1  Identidad obligatoria en `--prdc`. Un informe de producción no puede
       emitirse sin nombre y cargo. Se admite por flag, por entorno o
       interactivamente, pero no se admite su ausencia.

  2.2  Registro acumulado (`feedback/registro_validadores.json`): qué modelo
       validó cada persona y cuándo. Permite demostrar rotación ante el
       regulador y sirve a equipos de 2-5 personas con instalaciones separadas
       sobre el mismo repositorio.

  2.3  Detección de auto-aprobación: si la misma persona firma 3+ informes
       consecutivos del mismo modelo sin que intervenga un segundo validador,
       se advierte. NO se bloquea: en un equipo de dos personas puede ser
       inevitable y bloquearlo impediría trabajar. Un aviso visible en el
       informe deja constancia para que el auditor lo valore.
"""

from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

_RAIZ = Path(__file__).resolve().parents[1]
REGISTRO_PATH = _RAIZ / "feedback" / "registro_validadores.json"

# [CONFIG-CENTRAL] Los parámetros de negocio viven en config/parametros.py, no
# aquí: una segunda lectura de VIRF_VALIDADOR en este módulo podría divergir de
# la de config sin que nada avisara. Se re-exporta el umbral por comodidad de
# los llamantes, pero la única declaración está en config.
from config.parametros import (
    UMBRAL_SIN_SEGUNDA_REVISION,
    identidad_validador_entorno,
)


class IdentidadRequerida(RuntimeError):
    """Se intentó emitir un informe de producción sin validador identificable."""


# ═════════════════════════════════════════════════════════════════════════════
# 2.1 — Identificación
# ═════════════════════════════════════════════════════════════════════════════

MAX_INTENTOS = 3


def _leer(prompt: str) -> Optional[str]:
    """
    Lectura de consola. Devuelve None si la entrada se agotó (EOF/Ctrl-C).

    [FIX] Distinguir None de "" es imprescindible: devolver "" en ambos casos
    hacía que el bucle `while not nombre` no pudiera salir cuando stdin estaba
    agotado, y el proceso se colgaba pidiendo el nombre indefinidamente. Se
    reprodujo con `--prdc < /dev/null`, donde isatty() informaba de un terminal
    interactivo pero cada input() devolvía EOF de inmediato.
    """
    try:
        return input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        return None


def solicitar_identidad(
    nombre: Optional[str] = None,
    cargo: Optional[str] = None,
    interactivo: bool = True,
    obligatorio: bool = True,
) -> Dict[str, str]:
    """
    Resuelve la identidad del validador responsable del informe.

    Orden de precedencia, del más explícito al menos:
      1. argumentos `--validador` / `--cargo`
      2. variables de entorno VIRF_VALIDADOR / VIRF_VALIDADOR_CARGO
      3. pregunta interactiva

    Por qué se admiten flags y entorno además de la pregunta: sin una vía no
    interactiva, ninguna corrida automatizada ni ningún test podría emitir un
    informe de producción. La alternativa —permitir informes sin firmante en
    modo no interactivo— sería precisamente el agujero que este requisito cierra.

    Raises:
        IdentidadRequerida: si `obligatorio` y no se obtuvo nombre y cargo.
    """
    # El entorno se lee SIEMPRE a través de config: es el único punto de
    # declaración de estas variables en todo el proyecto.
    _nom_env, _car_env = identidad_validador_entorno()
    nombre = (nombre or _nom_env or "").strip()
    cargo = (cargo or _car_env or "").strip()

    if (not nombre or not cargo) and interactivo and sys.stdin and sys.stdin.isatty():
        print("\n" + "═" * 70)
        print("  ✍️  IDENTIFICACIÓN DEL VALIDADOR RESPONSABLE")
        print("═" * 70)
        print("  El informe de producción requiere un responsable humano")
        print("  identificable (SR 11-7 §V — segregación de funciones).\n")
        # Intentos acotados: si la entrada se agota o el usuario insiste en
        # dejarlo vacío, se abandona y `IdentidadRequerida` explica las tres
        # formas de aportar el dato. Reintentar sin límite colgaba el proceso.
        intentos = 0
        while not nombre and intentos < MAX_INTENTOS:
            intentos += 1
            leido = _leer("  Nombre completo del validador: ")
            if leido is None:          # EOF: no hay nadie al otro lado
                break
            nombre = leido
            if not nombre:
                print("     ⚠️  El nombre es obligatorio.")

        intentos = 0
        while nombre and not cargo and intentos < MAX_INTENTOS:
            intentos += 1
            leido = _leer("  Cargo/rol (ej. Validador de Segunda Línea): ")
            if leido is None:
                break
            cargo = leido
            if not cargo:
                print("     ⚠️  El cargo es obligatorio.")

    if obligatorio and (not nombre or not cargo):
        raise IdentidadRequerida(
            "No se puede emitir un informe de producción sin validador "
            "responsable identificado.\n\n"
            "  SR 11-7 §V y EBA/GL/2023/01 §5 exigen un responsable humano\n"
            "  identificable, distinto del proceso automático.\n\n"
            "  Indícalo de una de estas formas:\n"
            "    --validador \"Nombre Completo\" --cargo \"Validador de Segunda Línea\"\n"
            "    VIRF_VALIDADOR=\"Nombre\" VIRF_VALIDADOR_CARGO=\"Cargo\" python agente.py ...\n"
            "    o ejecuta en una consola interactiva y se te preguntará."
        )

    return {
        "validador": nombre,
        "cargo": cargo,
        "fecha_aprobacion": datetime.now(timezone.utc)
                            .isoformat(timespec="seconds").replace("+00:00", "Z"),
    }


# ═════════════════════════════════════════════════════════════════════════════
# 2.2 — Registro acumulado
# ═════════════════════════════════════════════════════════════════════════════

def _cargar_registro() -> List[Dict]:
    if not REGISTRO_PATH.exists():
        return []
    try:
        datos = json.loads(REGISTRO_PATH.read_text(encoding="utf-8"))
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, OSError):
        # Mismo criterio que el historial de feedback: un fichero corrupto se
        # respalda en vez de descartarse en silencio. Perder el registro de
        # quién validó qué sería perder la evidencia de segregación.
        try:
            sello = datetime.now().strftime("%Y%m%d-%H%M%S")
            REGISTRO_PATH.rename(
                REGISTRO_PATH.with_suffix(f".corrupto-{sello}.json"))
            print(f"  ⚠️  registro_validadores.json ilegible; respaldado como "
                  f".corrupto-{sello}.json")
        except OSError:
            pass
        return []


def registrar_validacion(modelo: str, identidad: Dict, tier: str = "",
                         huella: str = "", score_global=None) -> Dict:
    """
    Añade una firma al registro acumulado, con lock y escritura atómica.

    Se reutilizan los helpers de concurrencia de `document_cache` porque el
    escenario es el mismo que ya rompió el historial de feedback: varios
    validadores del equipo escribiendo sobre el mismo repositorio. Sin lock, la
    firma de uno borra la del otro — y con ella la evidencia de segregación.
    """
    entrada = {
        "modelo": modelo,
        "validador": identidad.get("validador", ""),
        "cargo": identidad.get("cargo", ""),
        "tier": tier,
        "fecha_aprobacion": identidad.get("fecha_aprobacion"),
        "huella_ejecucion": huella,
        "score_global": score_global,
    }
    REGISTRO_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        from modulos.document_cache import _lock_archivo, _escribir_json_atomico
    except ImportError:
        from contextlib import nullcontext

        def _lock_archivo(_p):
            return nullcontext()

        def _escribir_json_atomico(destino, data):
            Path(destino).write_text(
                json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    with _lock_archivo(REGISTRO_PATH):
        # Relectura DENTRO del lock: es lo que evita el lost update.
        registro = _cargar_registro()
        registro.append(entrada)
        _escribir_json_atomico(REGISTRO_PATH, registro)
    return entrada


def historial_por_validador() -> Dict[str, Dict]:
    """Agrupa el registro por validador: cuántos modelos y con qué fechas."""
    resumen: Dict[str, Dict] = {}
    for r in _cargar_registro():
        v = r.get("validador") or "(sin identificar)"
        d = resumen.setdefault(v, {
            "cargo": r.get("cargo", ""),
            "n_aprobaciones": 0,
            "modelos": {},
            "primera": None,
            "ultima": None,
        })
        d["n_aprobaciones"] += 1
        d["cargo"] = r.get("cargo") or d["cargo"]
        modelo = r.get("modelo", "?")
        d["modelos"].setdefault(modelo, []).append(r.get("fecha_aprobacion"))
        fecha = r.get("fecha_aprobacion") or ""
        if fecha:
            d["primera"] = min(d["primera"] or fecha, fecha)
            d["ultima"] = max(d["ultima"] or fecha, fecha)
    return dict(sorted(resumen.items()))


# ═════════════════════════════════════════════════════════════════════════════
# 2.3 — Auto-aprobación sin supervisión
# ═════════════════════════════════════════════════════════════════════════════

def firmas_consecutivas(modelo: str, validador: str) -> int:
    """
    Cuántas firmas consecutivas más recientes del modelo son de este validador.

    Se cuenta desde el final hacia atrás y se para en la primera firma ajena:
    la intervención de un segundo validador reinicia el contador, que es
    exactamente lo que la segregación pretende conseguir.
    """
    del_modelo = [r for r in _cargar_registro() if r.get("modelo") == modelo]
    n = 0
    for r in reversed(del_modelo):
        if (r.get("validador") or "") == validador:
            n += 1
        else:
            break
    return n


def aviso_segunda_revision(modelo: str, validador: str) -> Optional[str]:
    """
    Devuelve el texto del aviso si falta segunda revisión, o None.

    No bloquea (requisito 2.3): en un equipo de dos personas la rotación puede
    ser imposible en un periodo dado, y bloquear impediría trabajar. El aviso
    queda en el informe para que el auditor lo valore con su contexto.

    El recuento incluye la firma en curso, que aún no está en el registro.
    """
    n = firmas_consecutivas(modelo, validador) + 1
    if n >= UMBRAL_SIN_SEGUNDA_REVISION:
        return (f"⚠️ Sin segunda revisión reciente detectada para este modelo: "
                f"{n} informes consecutivos aprobados por el mismo validador "
                f"({validador}). Se recomienda revisión cruzada por un segundo "
                f"validador conforme a segregación de funciones.")
    return None


# ═════════════════════════════════════════════════════════════════════════════
# Presentación en consola
# ═════════════════════════════════════════════════════════════════════════════

def imprimir_historial() -> None:
    resumen = historial_por_validador()
    print("\n" + "═" * 74)
    print("  ✍️  HISTORIAL DE VALIDACIONES POR VALIDADOR")
    print("═" * 74)
    if not resumen:
        print("\n  No hay validaciones registradas.")
        print("  El registro se crea al emitir el primer informe con --prdc.\n")
        return
    for validador, d in resumen.items():
        print(f"\n  {validador}   ({d['cargo'] or 'sin cargo'})")
        print(f"     aprobaciones : {d['n_aprobaciones']}")
        print(f"     modelos      : {len(d['modelos'])}")
        print(f"     periodo      : {d['primera']} → {d['ultima']}")
        for modelo, fechas in sorted(d["modelos"].items()):
            print(f"        · {modelo}  ({len(fechas)}×)  última: {max(f for f in fechas if f)}")
    print("\n" + "─" * 74)
    total = sum(d["n_aprobaciones"] for d in resumen.values())
    print(f"  {len(resumen)} validador(es) · {total} aprobación(es) registradas")
    # Señal de segregación: un único validador para todo es un hallazgo.
    if len(resumen) == 1 and total >= UMBRAL_SIN_SEGUNDA_REVISION:
        print("\n  ⚠️  Un solo validador acumula todas las aprobaciones.")
        print("      Un auditor lo señalará como falta de segregación de funciones.")
    print("═" * 74 + "\n")
