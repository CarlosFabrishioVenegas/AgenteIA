"""
modulos/motor_ia.py
====================
Orquestador principal del agente VIRF.
Financial Controller / Model Risk Validator — LaR, VaR, Conductuales.

ARQUITECTURA DE ORQUESTACIÓN:
==============================

    Infraestructura (motor/):
        Mx_00  →  configuración, rutas, constantes, rol del agente
        Mx_01  →  lectura de archivos (PDF, DOCX, PY, XLSX, ...)
        Mx_02  →  construcción de prompts
        Mx_03  →  llamadas a la API (Anthropic / Azure OpenAI)
        Mx_04  →  controles automáticos estáticos (regex, pandas)

    RAG por dominio financiero (src/rag/):
        LaRRetriever          →  manuales + papers de Liquidity at Risk
        VaRRetriever          →  manuales + papers de Value at Risk
        ConductualesRetriever →  modelos de comportamiento (prepago, NMD)
        SharedRetriever       →  regulación transversal (SR 11-7, BCBS 239)

        El dominio se infiere automáticamente desde --titulo del modelo.
        El retriever enriquece cada prompt con contexto semántico adicional
        ANTES de llamar a la API (ver _enriquecer_con_rag()).

    Orquestadores (puntos de entrada preferidos para código externo):
        orquestar_pipeline_virf()        →  Pipeline 1: por control (ControlesData.xlsx)
                                            Facade de motor_ia_v2. Recomendado para
                                            modelos con controles explícitos.
        (Pipeline 2 por ámbito lo orquesta agente.py directamente)
                                            Encapsula el flujo completo de agente.py.


    Lógica de negocio (este archivo):
        evaluar_actividad()              →  evalúa 1 actividad → puntaje 1-5
        evaluar_ambito_completo()        →  itera actividades de un ámbito (secuencial)
        generar_resumen_ejecutivo()      →  narrativa final del informe
        calcular_score_ambito()          →  promedio de puntajes
        calcular_score_global()          →  score ponderado por ámbito
        get_semaforo()                   →  label y color según score

USO TÍPICO (notebook Databricks o tests):
    # Pipeline 1 — por control:
    from modulos.motor_ia import orquestar_pipeline_virf
    resultado = orquestar_pipeline_virf(
        base_project_path="/dbfs/FileStore/virf/modelo_lar",
        excel_controles="inputs/calidad_datos/ControlesData.xlsx",
        nombre_modelo="Modelo LaR v3", fecha_informe="2026-06-01", tier="I",
    )

    # Pipeline 2 — por ámbito:
    # Pipeline 2 (ámbitos): ejecutar `python agente.py --titulo X --tier 1`
    print(f"Score: {resultado['score_global']} — {resultado['semaforo']['label']}")

FLUJO DE evaluar_actividad() CON RAG:
======================================
    1. Construir prompt base (contexto Mx_01 + instrucciones Mx_00)
    2. _enriquecer_con_rag() → inyectar chunks semánticos del índice RAG
    3. Mx_03._llamar_modelo() → llamada a la API
    4. Ajuste anti-sesgo (feedback histórico)
    5. Retornar dict con puntaje, observación, cobertura, etc.
"""

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Resolver ruta a motor/ para importar los Mx_* ────────────────────────────
_MODULOS_DIR = Path(__file__).parent.resolve()      # .../virf_agent_clean/modulos/
_ROOT_DIR    = _MODULOS_DIR.parent.resolve()         # .../virf_agent_clean/
_MOTOR_DIR   = _ROOT_DIR / "motor"                   # .../virf_agent_clean/motor/

for _p in [str(_MOTOR_DIR), str(_ROOT_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ── Importar infraestructura desde los Mx ────────────────────────────────────

# Mx_00 — configuración centralizada del motor
from Mx_00_CargaRutas import (
    ROL_AGENTE,
    RUTAS,
    AMBITO_A_INPUTS,
    INSTRUCCIONES_DIMENSION,
    UMBRAL_RIESGO_GLOBAL,
    MODO_PREPRDC,
    MODO_PRDC,
)

# Mx_01 — lectura de archivos y evidencias
from Mx_01_LecturaEvidencias import (
    leer_carpeta,
    leer_repositorio_informes,
    leer_estandares_virf,
    cargar_todos_inputs,
    inputs_para_dimension,
)

# Mx_03 — llamada HTTP a la API (lógica de transporte)
from Mx_03_LlamarIA import (
    _llamar_modelo,       # llamada raw → retorna texto
    _parsear_json,        # limpia y parsea JSON de la respuesta
    aprender_estilo,      # aprende lenguaje de informes de referencia
    generar_replica_virf, # genera _replica_virf.py cuando no existe
    generar_sintesis,     # síntesis ejecutiva y dictamen global
)

# Mx_04 — controles de datos (se amplía cada semana)
from Mx_04_MotorControlesData import (
    detectar_cuestionamientos,
    tiene_replica_virf,
    calcular_riesgo_global,
    resumen_cuestionamientos_consola,
)

# ── Config de negocio (desde config.py de la raíz) ───────────────────────────
from config import (
    ESCALA_PUNTAJE,
    SCORE_SEMAFORO,
    AMBITO_PESOS,
    PREGUNTAS_METODOLOGICAS,
    RAG_TOP_K,
    RAG_MIN_SCORE,
)
from modulos.feedback import construir_contexto_feedback
from modulos.feedback_mejorado import (
    construir_bloque_aprendizaje,
    obtener_recomendaciones_evaluacion,
)

# ── RAG por dominio financiero (src/rag/) ─────────────────────────────────────
# Import con fallback: si ChromaDB no está instalado o el índice no existe,
# el agente funciona normalmente sin RAG (degradación elegante).
# Para habilitar: pip install chromadb sentence-transformers
#                 python scripts/rebuild_rag_databricks.py --dominio all
try:
    from src.rag import get_retriever as _rag_get_retriever, inferir_dominio as _rag_inferir_dominio
    _RAG_DISPONIBLE = True
except ImportError:
    _RAG_DISPONIBLE = False
    def _rag_get_retriever(*a, **kw): return None   # noqa: E302
    def _rag_inferir_dominio(*a, **kw): return "shared"   # noqa: E302


# ══════════════════════════════════════════════════════════════════════════════
# RAG — Enriquecimiento semántico de prompts por dominio financiero
# ══════════════════════════════════════════════════════════════════════════════

# Retriever singleton por dominio: se inicializa una sola vez por proceso
# para no reabrir el índice ChromaDB en cada llamada.
_rag_retriever_cache: Dict[str, object] = {}


def _enriquecer_con_rag(
    actividad:     str,
    ambito:        str,
    titulo_modelo: str,
    top_k:         int   = 3,
    min_score:     float = 0.35,
) -> str:
    """
    Recupera contexto semántico adicional del índice RAG del dominio
    correspondiente y lo formatea para inyectar en el prompt.

    El dominio se infiere automáticamente desde titulo_modelo:
      "Modelo LaR v3"       → LaRRetriever  (índice inputs/documentacion/ LaR)
      "VaR Mercado FRTB"    → VaRRetriever
      "Prepago NMD Q1 2026" → ConductualesRetriever
      Cualquier otro        → SharedRetriever (regulación transversal)

    Comportamiento si el RAG no está disponible:
      - ChromaDB no instalado     → retorna "" sin lanzar excepción
      - Índice vacío o sin hits   → retorna "" sin lanzar excepción
      - Similitud < min_score     → retorna "" (chunks irrelevantes descartados)

    Args:
        actividad:     texto de la actividad a evaluar (query semántica)
        ambito:        ámbito VIRF (para enriquecer la query con contexto)
        titulo_modelo: nombre del modelo, usado para inferir el dominio RAG
        top_k:         máximo de chunks a recuperar
        min_score:     umbral mínimo de similitud coseno (0-1)

    Returns:
        String listo para concatenar al prompt, o "" si RAG no aporta.

    Ejemplo de salida:
        ## Conocimiento recuperado — dominio: LaR
        ### [1] Fuente: metodologico_modelamiento.docx (similitud: 0.72)
        El backtesting de Kupiec evalúa si la tasa de excedencias observada...
    """
    if not _RAG_DISPONIBLE:
        return ""

    dominio = _rag_inferir_dominio(titulo_modelo)

    # Reutilizar retriever si ya fue inicializado para este dominio
    if dominio not in _rag_retriever_cache:
        try:
            _rag_retriever_cache[dominio] = _rag_get_retriever(tipo_modelo=dominio)
        except Exception as e:
            import logging
            logging.getLogger("virf.motor_ia").warning(
                f"[RAG] No se pudo inicializar retriever '{dominio}': {e}"
            )
            _rag_retriever_cache[dominio] = None

    retriever = _rag_retriever_cache.get(dominio)
    if retriever is None:
        return ""

    # Query enriquecida: actividad + ámbito para mejor precisión semántica
    query = f"[{ambito}] {actividad}"

    try:
        return retriever.query_para_prompt(query, top_k=top_k, min_score=min_score)
    except Exception as e:
        import logging
        logging.getLogger("virf.motor_ia").warning(f"[RAG] Error en query: {e}")
        return ""


# ══════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN DE ACTIVIDADES — lógica de negocio con scoring 1-5
# ══════════════════════════════════════════════════════════════════════════════

class _ContratoInvalido(Exception):
    """[CONTRATO-FIX] La respuesta del modelo no cumple el esquema esperado."""


def _extraer_json(texto: str) -> Dict:
    """
    [PARSEO-FIX] Extrae el primer objeto JSON completo de la respuesta del modelo.

    Problema real detectado en producción:
        El modelo suele responder con el JSON pedido y AÑADIR texto explicativo
        después (o envolverlo en ```json ... ```). `json.loads()` sobre el texto
        completo falla con "Extra data: line 17 column 1", y esas evaluaciones
        se perdían (antes se enmascaraban como puntaje=2 inventado).

    Estrategia, en orden:
        1. Quitar fences markdown ```json ... ```
        2. Intentar json.loads directo (caso limpio)
        3. Escanear con contador de llaves respetando strings y escapes,
           devolviendo el primer objeto {...} balanceado.

    Raises:
        json.JSONDecodeError si no se encuentra ningún objeto JSON válido.
    """
    limpio = re.sub(r"^\s*```(?:json)?\s*", "", texto.strip())
    limpio = re.sub(r"\s*```\s*$", "", limpio).strip()

    # Caso 1: la respuesta ya es JSON puro
    try:
        return json.loads(limpio)
    except json.JSONDecodeError:
        pass

    # Caso 2: hay texto alrededor → localizar el primer objeto balanceado
    inicio = limpio.find("{")
    if inicio == -1:
        raise json.JSONDecodeError("No se encontró ningún objeto JSON", limpio, 0)

    profundidad = 0
    en_string = False
    escapado = False
    for i in range(inicio, len(limpio)):
        ch = limpio[i]
        if escapado:
            escapado = False
            continue
        if ch == "\\":
            escapado = True
            continue
        if ch == '"':
            en_string = not en_string
            continue
        if en_string:
            continue
        if ch == "{":
            profundidad += 1
        elif ch == "}":
            profundidad -= 1
            if profundidad == 0:
                return json.loads(limpio[inicio:i + 1])

    raise json.JSONDecodeError("Objeto JSON incompleto (llaves sin cerrar)", limpio, inicio)


# Campos obligatorios que debe devolver el modelo por cada actividad evaluada
_CAMPOS_CONTRATO_EVALUACION = (
    "puntaje", "concepto", "observacion",
    "evidencia_encontrada", "preguntas_pendientes", "recomendacion",
)


def _validar_contrato_evaluacion(data: Any) -> List[str]:
    """
    [CONTRATO-FIX] Valida el contrato de una evaluación de actividad.

    Esta validación NO existía en la ruta activa del pipeline: `_validar_contrato`
    en Mx_03 estaba definida pero nunca se invocaba (código muerto), de modo que
    una respuesta malformada se aceptaba en silencio.

    Returns:
        Lista de errores encontrados. Vacía = contrato válido.
    """
    errores: List[str] = []

    if not isinstance(data, dict):
        return [f"la respuesta no es un objeto JSON (es {type(data).__name__})"]

    for campo in _CAMPOS_CONTRATO_EVALUACION:
        if campo not in data:
            errores.append(f"falta el campo '{campo}'")

    # puntaje: debe ser convertible a entero dentro de 1-5
    if "puntaje" in data:
        try:
            p = int(data["puntaje"])
            if not (1 <= p <= 5):
                errores.append(f"'puntaje'={p} fuera del rango 1-5")
        except (TypeError, ValueError):
            errores.append(f"'puntaje' no es numérico (={data['puntaje']!r})")

    # campos de texto: deben ser str no vacíos
    for campo in ("concepto", "observacion"):
        if campo in data:
            v = data[campo]
            if not isinstance(v, str) or not v.strip():
                errores.append(f"'{campo}' debe ser texto no vacío")

    # preguntas_pendientes: debe ser lista (el modelo a veces devuelve str)
    if "preguntas_pendientes" in data:
        if not isinstance(data["preguntas_pendientes"], list):
            errores.append(
                "'preguntas_pendientes' debe ser una lista "
                f"(recibido {type(data['preguntas_pendientes']).__name__})"
            )

    return errores


def _evaluacion_invalida(
    motivo:      str,
    detalle:     str,
    actividad:   str,
    control:     str,
    cobertura:   float,
    rag_dominio: str,
    rag_chunks:  int,
) -> Dict:
    """
    [CONTRATO-FIX] Construye una evaluación marcada como NO VÁLIDA.

    Principio (mismo que D3-FIX): ante un fallo, el agente NO inventa un
    puntaje. Devuelve puntaje=None y evaluacion_valida=False para que:
      - `calcular_score_ambito` la excluya del promedio,
      - el informe Word la muestre como "NO EVALUADA",
      - el auditor humano vea explícitamente qué quedó sin evaluar.
    """
    return {
        "puntaje":              None,
        "evaluacion_valida":    False,
        "error_evaluacion":     motivo,
        "concepto":             "EVALUACIÓN NO REALIZADA — fallo técnico",
        "observacion": (
            f"Esta actividad NO pudo evaluarse. Motivo: {motivo} "
            "No se asignó puntaje para no contaminar el dictamen con un valor inventado. "
            f"Detalle técnico: {detalle}"
        ),
        "evidencia_encontrada": "",
        "preguntas_pendientes": [
            f"Re-ejecutar la evaluación de la actividad '{actividad[:60]}' "
            "y verificar conectividad/cuota de la API."
        ],
        "recomendacion":        "Re-ejecutar el agente. Si persiste, revisar el prompt y la API.",
        "actividad":            actividad,
        "control":              control,
        "cobertura_contexto":   cobertura,
        "ajuste_sesgo":         "N/A — evaluación inválida",
        "rag_dominio":          rag_dominio,
        "rag_chunks":           rag_chunks,
    }


def evaluar_actividad(
    actividad:        str,
    ambito:           str,
    control:          str,
    contexto:         str,
    titulo_modelo:    str,
    modo_preprdc:     bool = True,
    contexto_ambito:  Optional[List[Dict]] = None,  # [NEW-MEM] hallazgos previos del mismo ámbito
    # [AUDIT-FIX] Estos valores estaban hardcodeados aquí mientras
    # .env.example documentaba RAG_TOP_K y RAG_MIN_SCORE como configurables.
    # Coincidían por casualidad, así que tocarlos en .env no hacía nada y
    # tampoco avisaba. Ahora la única fuente es config/parametros.py.
    rag_top_k:        int   = RAG_TOP_K,     # chunks RAG a recuperar por actividad
    rag_min_score:    float = RAG_MIN_SCORE, # similitud mínima para incluir chunk
    cobertura_docs:   float = 100.0, # [COBERTURA-FIX] % real de los documentos leídos
) -> Dict:
    """
    Evalúa una actividad específica del estándar VIRF.

    ENRIQUECIMIENTO RAG (nuevo):
      Antes de llamar a la API, consulta el índice ChromaDB del dominio
      financiero correspondiente (inferido desde titulo_modelo) y añade
      los chunks más relevantes al prompt. Esto permite que el agente
      cite metodología específica (ej. fórmula Kupiec) aunque no esté
      en los documentos del modelo bajo validación.

      Si el RAG no está disponible (índice no construido, ChromaDB no
      instalado), la evaluación continúa sin él — sin excepción ni cambio
      en el contrato de salida.

    [FIX-BIAS] Incorpora calibración anti-sesgo basada en feedback histórico:
      - Detecta si el agente subestima/sobrestima para este ámbito
      - Añade instrucción explícita de corrección al prompt
      - Incluye ejemplos few-shot calibrados

    [FIX-COV] Reporta cobertura_contexto: fracción del contexto disponible
      que fue efectivamente incluida en el prompt.

    [NEW-MEM] Recibe hallazgos previos del mismo ámbito como contexto acumulado,
      permitiendo razonamiento encadenado y detección de inconsistencias cruzadas.

    Returns:
        {
          puntaje:             int (1-5),
          concepto:            str,
          observacion:         str,
          evidencia_encontrada:str,
          preguntas_pendientes:list[str],
          recomendacion:       str,
          cobertura_contexto:  float,   # [FIX-COV] 0.0-1.0
          ajuste_sesgo:        str,     # [FIX-BIAS] descripción del ajuste aplicado
          rag_dominio:         str,     # dominio RAG consultado (o "no_disponible")
          rag_chunks:          int,     # chunks RAG inyectados en el prompt
        }
    """
    from modulos.feedback_mejorado import ajustar_puntaje_por_feedback

    preguntas_guia     = PREGUNTAS_METODOLOGICAS.get(ambito, [])
    contexto_feedback  = construir_contexto_feedback(ambito, actividad)
    bloque_aprendizaje = construir_bloque_aprendizaje(ambito)
    instruccion_dim    = INSTRUCCIONES_DIMENSION.get(ambito, "")

    # ── [v18] MAX_CTX: sincronizado con configuración central, no hardcodeado ──
    # Lee de env VIRF_MAX_CTX → fallback a MAX_CHARS_DOC (Mx_00) → fallback 15000
    import os as _os_mia
    # [CONFIG-CENTRAL v27.2] Antes se derivaba de Mx_00 con un fallback literal
    # a 15000 y un getenv propio: tercera declaración independiente de MAX_CTX.
    from config.parametros import MAX_CTX

    ctx_total    = len(contexto) if contexto else 0
    ctx_incluido = min(ctx_total, MAX_CTX)
    cobertura    = round(ctx_incluido / ctx_total, 3) if ctx_total > 0 else 0.0

    # ── [COBERTURA-FIX] Bloque de cobertura basado en DATOS, no en strings ────
    # ANTES: se detectaba el chunking olfateando la subcadena "Procesado en" en
    #        el contexto. Frágil (cualquier cambio de formato en chunker.py lo
    #        rompía silenciosamente) y, peor, afirmaba "cobertura completa
    #        (100%)" SIEMPRE que detectaba chunking — aunque el chunker hubiera
    #        truncado el documento al 46%.
    # AHORA: `cobertura_docs` llega como número desde chunker.py vía agente.py.
    #        Se distingue cobertura DOCUMENTAL (cuánto del archivo se leyó) de
    #        cobertura de PROMPT (cuánto del contexto cupo en la llamada).
    _fue_truncado_fc = bool(contexto) and "DOCUMENTO TRUNCADO" in contexto
    _cob_doc = float(cobertura_docs if cobertura_docs is not None else 100.0)

    partes_cobertura = []

    if _cob_doc >= 99.9 and not _fue_truncado_fc:
        partes_cobertura.append(
            "NOTA DE COBERTURA DOCUMENTAL: se procesó el 100% de los documentos "
            "(los extensos, mediante resumen por segmentos). Evalúa considerando "
            "TODA la información presente."
        )
    else:
        partes_cobertura.append(
            f"⚠️  COBERTURA DOCUMENTAL PARCIAL: solo se pudo leer el "
            f"{_cob_doc:.1f}% del contenido de los documentos. "
            f"Falta aproximadamente un {100 - _cob_doc:.1f}%. "
            "Si no encuentras evidencia de un requisito, NO penalices con 1 "
            "automáticamente: podría estar en la parte no leída. Expresa "
            "incertidumbre y solicita el fragmento faltante."
        )

    if _fue_truncado_fc:
        partes_cobertura.append(
            "⚠️  Uno o más documentos se truncaron por limitación técnica "
            "(fallo de API durante el resumen). Indica qué información adicional "
            "solicitarías al modelador."
        )

    if ctx_total > MAX_CTX:
        partes_cobertura.append(
            f"⚠️  COBERTURA DE PROMPT: del contexto disponible se incluyeron "
            f"{ctx_incluido:,} de {ctx_total:,} chars ({cobertura*100:.0f}%) por "
            f"límite de tamaño de llamada. Trata la ausencia de un dato como "
            f"incertidumbre, no como incumplimiento."
        )

    bloque_cobertura = "\n" + "\n".join(partes_cobertura) if partes_cobertura else ""

    # ── [RAG] Enriquecimiento semántico por dominio financiero ───────────────
    # Consulta el índice ChromaDB del dominio (LaR / VaR / conductuales / shared)
    # e inyecta los chunks más relevantes en el prompt.
    # Si el RAG no está disponible, bloque_rag = "" y la evaluación continúa.
    bloque_rag     = _enriquecer_con_rag(actividad, ambito, titulo_modelo,
                                         top_k=rag_top_k, min_score=rag_min_score)
    _rag_dominio   = _rag_inferir_dominio(titulo_modelo) if _RAG_DISPONIBLE else "no_disponible"
    _rag_n_chunks  = bloque_rag.count("### [") if bloque_rag else 0

    # ── [FIX-BIAS] Bloque de corrección de sesgo ──────────────────────────────
    bloque_antisesgo = _construir_bloque_antisesgo(ambito)

    # ── [NEW-MEM] Bloque de memoria intra-ámbito ──────────────────────────────
    bloque_memoria = ""
    if contexto_ambito:
        resumen_previos = []
        for prev in contexto_ambito[-4:]:  # máx últimos 4 para no inflar el prompt
            resumen_previos.append(
                f"  • [{prev.get('puntaje','?')}/5] {prev.get('actividad','')[:60]}: "
                f"{prev.get('observacion','')[:100]}"
            )
        bloque_memoria = (
            "\nHALLAZGOS PREVIOS EN ESTE ÁMBITO (para coherencia y detección de inconsistencias):\n"
            + "\n".join(resumen_previos)
            + "\n→ Si detectas contradicciones con lo anterior, indícalo explícitamente."
        )

    # ── Bloques opcionales ────────────────────────────────────────────────────
    bloque_feedback = (
        f"\nAPRENDIZAJE DE CORRIDAS ANTERIORES:\n{contexto_feedback}"
        if contexto_feedback else ""
    )
    bloque_aprendizaje_prompt = f"\n{bloque_aprendizaje}" if bloque_aprendizaje else ""
    bloque_modo = (
        "MODO: PRE-PRODUCCIÓN — proporciona evaluación detallada con puntaje, "
        "concepto técnico y observaciones."
        if modo_preprdc else
        "MODO: PRODUCCIÓN — proporciona evaluación final consolidada."
    )

    prompt = f"""
MODELO BAJO VALIDACIÓN: {titulo_modelo}
ÁMBITO: {ambito}
CONTROL/CRITERIO: {control}
ACTIVIDAD A EVALUAR: {actividad}

INSTRUCCIONES ESPECÍFICAS PARA ESTE ÁMBITO:
{instruccion_dim}

CONTEXTO DISPONIBLE (extractos de documentos, scripts y datos provistos):
{contexto[:MAX_CTX] if contexto else "SIN CONTEXTO — No se encontraron archivos relevantes para este ámbito."}
{bloque_cobertura}
{bloque_rag}
PREGUNTAS GUÍA PARA ESTE ÁMBITO:
{chr(10).join(f"- {p}" for p in preguntas_guia)}
{bloque_memoria}
{bloque_feedback}
{bloque_aprendizaje_prompt}
{bloque_antisesgo}

{bloque_modo}

ESCALA DE EVALUACIÓN (1-5) — EJEMPLOS CALIBRADOS:
1 = No cumple — evidencia COMPLETAMENTE AUSENTE (ningún documento menciona el tema)
    Ejemplo: se pide backtesting y no existe ningún script, log ni mención en manuales.
2 = Cumple parcialmente — hay mención o intento pero con brechas críticas
    Ejemplo: existe script de backtesting pero no se ejecutó con datos reales o falta Kupiec.
3 = Cumple parcialmente — implementado pero con brechas no críticas
    Ejemplo: backtesting presente con Kupiec, falta Christoffersen pero el análisis es coherente.
4 = Cumple con observaciones menores — implementación sólida con mejoras recomendables
    Ejemplo: backtesting completo con Kupiec+Christoffersen, documentado. Falta análisis de López.
5 = Cumple plenamente — evidencia sólida, completa y bien documentada
    Ejemplo: todos los tests, documentados, justificados, con conclusiones claras.

REGLA CLAVE: Distingue entre "evidencia ausente en el contexto" y "requisito incumplido".
Si la cobertura es parcial, expresa incertidumbre en lugar de penalizar con 1 directamente.

Evalúa esta actividad y responde ÚNICAMENTE con este JSON (sin markdown):
{{
  "puntaje": <entero 1-5>,
  "concepto": "<qué evalúa técnicamente esta actividad y su importancia — 1-2 oraciones>",
  "observacion": "<hallazgo: qué se encontró, qué falta, riesgos. Señala si hay incertidumbre por cobertura parcial. Mínimo 2 oraciones.>",
  "evidencia_encontrada": "<documentos o secciones relevantes hallados, o 'No se encontró evidencia en el contexto disponible'>",
  "preguntas_pendientes": ["<pregunta específica al modelador si falta información>"],
  "recomendacion": "<acción concreta para subsanar brechas, si aplica>"
}}"""

    try:
        raw = _llamar_modelo(prompt)
        # [PARSEO-FIX] Extractor robusto: tolera fences markdown y texto
        # explicativo antes/después del objeto JSON.
        resultado = _extraer_json(raw)

        # ── [CONTRATO-FIX] Validar el contrato ANTES de usar el resultado ─────
        # Antes: se confiaba ciegamente en la forma del JSON. Si el modelo
        # devolvía 'puntaje' como texto, o faltaban campos, se colaba basura
        # (o un puntaje inventado) al informe sin ninguna señal.
        _errores_contrato = _validar_contrato_evaluacion(resultado)
        if _errores_contrato:
            raise _ContratoInvalido("; ".join(_errores_contrato))

        # Clampar puntaje al rango válido
        puntaje_raw = max(1, min(5, int(resultado.get("puntaje", 1))))

        # [FIX-BIAS] Aplicar ajuste post-hoc por feedback histórico similar
        puntaje_ajustado, desc_ajuste = ajustar_puntaje_por_feedback(
            ambito, actividad, float(puntaje_raw)
        )
        puntaje_final = max(1, min(5, round(puntaje_ajustado)))

        resultado["puntaje"]            = puntaje_final
        resultado["cobertura_contexto"] = cobertura      # fracción del contexto que cupo en el prompt
        resultado["cobertura_documental"] = _cob_doc     # [COBERTURA-FIX] % del archivo realmente leído
        resultado["ajuste_sesgo"]       = desc_ajuste
        resultado["rag_dominio"]        = _rag_dominio
        resultado["rag_chunks"]         = _rag_n_chunks
        resultado["evaluacion_valida"]  = True   # [CONTRATO-FIX] marca de integridad
        return resultado

    # ── [CONTRATO-FIX] Fallos → evaluación INVÁLIDA, nunca un puntaje inventado ──
    # Antes: cualquier error devolvía puntaje=2, indistinguible de una evaluación
    # legítima. Un fallo de red podía convertirse en "Cumple parcialmente" dentro
    # de un dictamen regulatorio. Ahora puntaje=None y evaluacion_valida=False,
    # de modo que el score del ámbito EXCLUYE estas entradas (igual que D3-FIX).
    except json.JSONDecodeError as e:
        return _evaluacion_invalida(
            motivo=f"JSON malformado en la respuesta del modelo: {e}",
            detalle=(raw[:300] if "raw" in locals() else "sin respuesta"),
            actividad=actividad, control=control,
            cobertura=cobertura, rag_dominio=_rag_dominio, rag_chunks=_rag_n_chunks,
        )
    except _ContratoInvalido as e:
        return _evaluacion_invalida(
            motivo=f"La respuesta no cumple el contrato esperado: {e}",
            detalle=(raw[:300] if "raw" in locals() else "sin respuesta"),
            actividad=actividad, control=control,
            cobertura=cobertura, rag_dominio=_rag_dominio, rag_chunks=_rag_n_chunks,
        )
    except Exception as e:
        return _evaluacion_invalida(
            motivo=f"Error durante la evaluación: {type(e).__name__}: {e}",
            detalle="Verificar API key, cuota y conectividad.",
            actividad=actividad, control=control,
            cobertura=cobertura, rag_dominio=_rag_dominio, rag_chunks=_rag_n_chunks,
        )


def _construir_bloque_antisesgo(ambito: str) -> str:
    """
    [FIX-BIAS] Construye un bloque de instrucción en el prompt que corrige
    el sesgo de subestimación detectado en el historial de feedback.

    [D6-FIX ACTIVADO] Antes de aplicar cualquier corrección se exige MASA
    CRÍTICA de feedback (validar_masa_critica_feedback). Sin esta guardia,
    UN SOLO feedback con diferencia de +2 puntos era suficiente para instruir
    al agente a subir sistemáticamente todos los puntajes del ámbito — un
    sobreajuste a ruido estadístico con impacto directo en el dictamen.

    Umbral: VIRF_MIN_FEEDBACK_ANTISESGO (default 15, según D6).
    """
    try:
        from modulos.feedback_mejorado import analizar_patron_errores, cargar_historial
        patron = analizar_patron_errores(ambito)
    except Exception:
        return ""

    # ── [D6-FIX] Guardia de masa crítica ──────────────────────────────────────
    # Esta validación existía en el código (validar_masa_critica_feedback) pero
    # NUNCA se invocaba. Ahora es la puerta de entrada obligatoria.
    from config.parametros import MIN_FEEDBACK_ANTISESGO as _min_reg
    try:
        _masa = validar_masa_critica_feedback(cargar_historial(), ambito,
                                              min_registros=_min_reg)
    except Exception:
        return ""
    if not _masa["masa_critica_ok"]:
        # Sin masa crítica NO se altera el criterio del agente.
        return ""

    tendencia = patron.get("tendencia", "equilibrado")
    mae       = patron.get("error_abs_promedio", 0)
    n         = _masa["n_registros"]

    if mae < 1.0 or tendencia == "equilibrado":
        return ""  # Sin sesgo significativo detectado

    if tendencia == "subestima":
        return (
            f"\n⚠️  CALIBRACIÓN DE SESGO (basada en {n} evaluaciones anteriores):\n"
            f"  Tu tendencia en este ámbito es SUBESTIMAR (error promedio: +{mae:.1f} puntos).\n"
            "  CORRECCIÓN REQUERIDA:\n"
            "  - Si hay evidencia PARCIAL o IMPLÍCITA → evalúa si merece 2 o 3, no automáticamente 1.\n"
            "  - Reconoce implementaciones en proceso como cumplimiento parcial (puntaje 2-3).\n"
            "  - Reserva el puntaje 1 SOLO para ausencia TOTAL de evidencia o intención.\n"
            "  - Si hay duda entre 1 y 2, elige 2. Si hay duda entre 2 y 3, evalúa si el\n"
            "    esfuerzo documental es serio aunque incompleto.\n"
        )
    elif tendencia == "sobrestima":
        return (
            f"\n⚠️  CALIBRACIÓN DE SESGO (basada en {n} evaluaciones anteriores):\n"
            f"  Tu tendencia en este ámbito es SOBRESTIMAR (error promedio: -{mae:.1f} puntos).\n"
            "  CORRECCIÓN REQUERIDA:\n"
            "  - Verifica que la evidencia sea explícita y suficiente antes de dar 4 o 5.\n"
            "  - Mencionar un concepto sin evidencia documental concreta no es cumplimiento.\n"
            "  - Sé más exigente: pide documentos específicos, no solo intenciones.\n"
        )
    return ""


def evaluar_ambito_completo(
    ambito:            str,
    actividades:       List[Dict],
    contexto:          str,
    titulo_modelo:     str,
    modo_preprdc:      bool = True,
    contexto_global:   Optional[List[Dict]] = None,  # [v18] memoria inter-ámbito
    rag_top_k:         int   = RAG_TOP_K,     # heredado a evaluar_actividad
    rag_min_score:     float = RAG_MIN_SCORE,
    cobertura_docs:    float = 100.0,  # [COBERTURA-FIX] % real reportado por el chunker
) -> List[Dict]:
    """
    Evalúa todas las actividades requeridas de un ámbito.

    [v17-MEM] Acumula hallazgos previos DENTRO del ámbito y los pasa a cada
    nueva actividad, permitiendo detectar inconsistencias cruzadas.

    [v18-GLOB] Recibe hallazgos de OTROS ámbitos ya evaluados (contexto_global).
    Permite detectar contradicciones entre ámbitos: ej. Documentación dice VaR
    Histórico y Metodología detecta VaR Paramétrico.

    Args:
        ambito:          nombre del ámbito VIRF
        actividades:     lista de dicts con claves: actividad, control, requerida
        contexto:        texto concatenado de los documentos relevantes
        titulo_modelo:   nombre del modelo bajo validación
        modo_preprdc:    True = preprdc, False = prdc
        contexto_global: [v18] hallazgos de ámbitos anteriores (lista de dicts)

    Returns:
        Lista de dicts de evaluación, uno por actividad.
    """
    resultados: List[Dict] = []
    hallazgos_acumulados: List[Dict] = []  # memoria intra-ámbito

    # [v20] Preparar bloque de memoria inter-ámbito — filtrado por relevancia + 250 chars
    # Solo se inyectan ámbitos conceptualmente relacionados con el actual.
    _RELACIONES_AMBITO = {
        "Documentación":              ["Gobierno", "Metodología", "Implementación"],
        "Calidad de datos":           ["Implementación", "Metodología"],
        "Metodología":                ["Implementación", "Calidad de datos", "Documentación"],
        "Gobierno":                   ["Documentación", "Uso e integración a la gestión"],
        "Implementación":             ["Metodología", "Calidad de datos"],
        "Uso e integración a la gestión": ["Gobierno", "Implementación"],
    }
    ambitos_relevantes = set(_RELACIONES_AMBITO.get(ambito, []))

    bloque_global = ""
    if contexto_global:
        resumen_global = []
        for h in contexto_global:
            amb_prev = h.get("ambito", "")
            # Filtrar: solo ámbitos relacionados, no el actual
            if amb_prev and amb_prev != ambito and amb_prev in ambitos_relevantes:
                pje  = h.get("puntaje", "?")
                obs  = h.get("observacion", "")[:250]   # [v20] 90 → 250 chars
                act  = h.get("actividad", "")[:80]
                resumen_global.append(f"  [{amb_prev}] {act}\n    → [{pje}/5] {obs}")
        # Limitar a los 5 más recientes relevantes para no inflar el prompt
        if resumen_global:
            bloque_global = (
                "\nCONTEXTO INTER-ÁMBITO (hallazgos de ámbitos relacionados ya evaluados):\n"
                + "\n".join(resumen_global[-5:])
                + "\n→ Si detectas incoherencias o contradicciones con estos hallazgos,"
                  " indícalo explícitamente en tu observación.\n"
            )

    for act in actividades:
        print(f"  → {act['actividad'][:75]}...")

        # Inyectar contexto global en el bloque de memoria intra-ámbito
        ctx_amb_completo = list(hallazgos_acumulados)
        if bloque_global:
            ctx_amb_completo = [{"ambito": "__global__", "actividad": bloque_global,
                                 "puntaje": None, "observacion": ""}] + ctx_amb_completo

        resultado = evaluar_actividad(
            actividad       = act["actividad"],
            ambito          = ambito,
            control         = act.get("control", ""),
            contexto        = contexto,
            titulo_modelo   = titulo_modelo,
            modo_preprdc    = modo_preprdc,
            contexto_ambito = ctx_amb_completo,
            rag_top_k       = rag_top_k,
            rag_min_score   = rag_min_score,
            cobertura_docs  = cobertura_docs,   # [COBERTURA-FIX]
        )
        resultado["actividad"] = act["actividad"]
        resultado["control"]   = act.get("control", "")
        resultados.append(resultado)

        # Acumular para la siguiente actividad del mismo ámbito
        hallazgos_acumulados.append({
            "ambito":     ambito,
            "actividad":  act["actividad"],
            "puntaje":    resultado.get("puntaje"),
            "observacion": resultado.get("observacion", ""),
        })

    return resultados


# ══════════════════════════════════════════════════════════════════════════════
# RESUMEN EJECUTIVO — narrativa final del informe
# ══════════════════════════════════════════════════════════════════════════════

def generar_resumen_ejecutivo(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito:       Dict[str, float],
    score_global:            float,
    titulo_modelo:           str,
    tier:                    str,
) -> str:
    """
    Genera el resumen ejecutivo narrativo para el informe Word.

    Usa Mx_03._llamar_modelo() para la llamada a la API.
    Construye el prompt con los datos de evaluación por ámbito.

    Returns:
        Texto del informe en formato narrativo con secciones ### delimitadas.
    """
    # [FIX-COV] Métricas de cobertura para la sección de limitaciones.
    #
    # [AUDIT-FIX] Este bloque anunciaba «La cobertura DOCUMENTAL promedio fue
    # X%» calculándola desde `cobertura_contexto`, que es otra cosa: la fracción
    # del contexto que cupo en el prompt. El propio módulo distingue ambas
    # (ver el comentario de la línea ~463), así que la etiqueta contradecía al
    # código. Caso que lo delata: un manual cubierto al 30% por el chunker cuyo
    # resumen sí cabe entero en el prompt da cobertura_contexto=1.0 → el informe
    # afirmaba «cobertura documental 100%». Falsa tranquilidad justo en el
    # apartado de LIMITACIONES.
    def _media(clave, escala):
        vals = [e.get(clave) for evals in evaluaciones_por_ambito.values()
                for e in evals if e.get(clave) is not None]
        return round(sum(vals) / len(vals) / escala, 3) if vals else None

    cobertura_prompt = _media("cobertura_contexto", 1.0)      # ya viene 0-1
    cobertura_documental = _media("cobertura_documental", 100.0)  # viene 0-100

    _avisos = []
    if cobertura_documental is not None and cobertura_documental < 0.7:
        _avisos.append(
            f"La cobertura DOCUMENTAL promedio (fracción de cada archivo "
            f"realmente leída) fue {cobertura_documental*100:.0f}%."
        )
    if cobertura_prompt is not None and cobertura_prompt < 0.7:
        _avisos.append(
            f"La cobertura de PROMPT promedio (fracción del contexto que cupo "
            f"en la llamada) fue {cobertura_prompt*100:.0f}%."
        )
    advertencia_cobertura = (
        "\n⚠️  NOTA: " + " ".join(_avisos) +
        " Incluye en el informe una sección de limitaciones indicando qué "
        "ámbitos tuvieron cobertura baja y que sus puntajes deben "
        "interpretarse con cautela. No confundas ambas métricas."
        if _avisos else ""
    )

    resumen_input = json.dumps({
        "titulo":             titulo_modelo,
        "tier":               tier,
        "score_global":       score_global,
        "scores_por_ambito":  scores_por_ambito,
        "hallazgos": {
            ambito: [
                {
                    # [AUDIT-FIX] Estos tres eran acceso directo `e["..."]` junto
                    # a un `.get()` en la línea siguiente. Todas las rutas los
                    # rellenan hoy, pero una evaluación futura sin 'actividad'
                    # tumbaría el resumen ejecutivo entero por un KeyError.
                    "actividad":           e.get("actividad", ""),
                    "puntaje":             e.get("puntaje"),
                    "observacion":         e.get("observacion", ""),
                    "preguntas_pendientes":e.get("preguntas_pendientes", []),
                }
                for e in evals
            ]
            for ambito, evals in evaluaciones_por_ambito.items()
        },
    }, ensure_ascii=False)

    # [AUDIT-FIX] score_global es None si ningún ámbito pudo evaluarse. Meterlo
    # en el prompt como 0.00 hacía que el LLM redactara un resumen ejecutivo
    # demoledor sobre una corrida que simplemente no tenía evidencia.
    _score_txt = (f"{score_global:.2f}/5.0" if score_global is not None else
                  "NO EVALUABLE (ningún ámbito aportó evidencia; NO redactes "
                  "un dictamen desfavorable: informa que falta evidencia)")

    prompt = f"""
Basándote en los resultados de validación del modelo {titulo_modelo} (Tier {tier}),
genera un INFORME EJECUTIVO DE VALIDACIÓN en español con la siguiente estructura:

### 1. RESUMEN EJECUTIVO
2-3 párrafos con score global {_score_txt} y dictamen general.

### 2. HALLAZGOS POR ÁMBITO
Para cada ámbito: score, hallazgos principales, observaciones críticas.

### 3. PREGUNTAS Y REQUERIMIENTOS PENDIENTES
Lista consolidada de información solicitada al modelador.

### 4. PLAN DE REMEDIACIÓN
Priorización por criticidad: Alta / Media / Baja.

### 5. LIMITACIONES DE ESTA EVALUACIÓN  [NUEVO - OBLIGATORIO]
Indica qué ámbitos tuvieron cobertura documental baja (<70%) y que sus puntajes
deben interpretarse con cautela. Menciona si algún PDF era escaneado o ilegible.
Si la cobertura fue alta (>90%), indica que la evaluación es sólida.
{advertencia_cobertura}

### 6. CONCLUSIÓN Y DICTAMEN FINAL
El dictamen debe ser uno de:
APROBADO / APROBADO CON CONDICIONES / OBSERVADO / RECHAZADO

Usa lenguaje técnico de validación de modelos de riesgo financiero.

DATOS DE EVALUACIÓN:
{resumen_input[:8000]}

Responde con el texto del informe en formato narrativo."""

    try:
        return _llamar_modelo(prompt, max_tokens=4096)
    except Exception as e:
        return f"[ERROR al generar resumen ejecutivo]: {e}"


# ══════════════════════════════════════════════════════════════════════════════
# MÉTRICAS Y SEMÁFORO
# ══════════════════════════════════════════════════════════════════════════════

def calcular_score_ambito(evaluaciones: List[Dict]) -> Optional[float]:
    """
    Promedio de puntajes de un ámbito, en la escala de política 0–5.

    ── POLÍTICA DE LA ENTIDAD ───────────────────────────────────────────────
    La FALTA DE EVIDENCIA es una falta crítica: el validado tenía que aportar
    documentación y no lo hizo. Puntúa **0.0** y arrastra el promedio.

    Un FALLO TÉCNICO del agente (timeout de la API, PDF ilegible, JSON roto)
    NO es imputable al validado: se EXCLUYE del promedio y se reporta aparte
    en el bloque «Fallos técnicos». Condenar un modelo porque se cayó nuestra
    red produciría un dictamen indefendible.

    Las dos situaciones llegaban aquí como el mismo `puntaje is None`, así que
    se distinguen por las marcas que ya emite el pipeline:
        sin_evidencia = True       → 0.0  (imputable al validado)
        evaluacion_valida = False  → excluida (imputable al agente)

    ── POR QUÉ 0.0 ES UN VALOR INEQUÍVOCO ───────────────────────────────────
    La escala de puntuación es 1–5, de modo que un promedio de actividades
    realmente evaluadas nunca puede bajar de 1.0. Por tanto **score 0.0 ⟺ sin
    evidencia**, y `get_semaforo()` puede rotularlo por su causa sin recibir
    ningún parámetro extra.

    Returns:
        float  → promedio en 0.0–5.0 (0.0 = sin evidencia, falta crítica)
        None   → NINGUNA actividad pudo evaluarse por fallo técnico
                 (se excluye del score global, que renormaliza los pesos)
    """
    # Un ámbito presente en los resultados pero sin ninguna evaluación es un
    # ámbito del que no se obtuvo evidencia: falta crítica, no ausencia de
    # dictamen. (Los ámbitos sin actividades requeridas para el tier ni
    # siquiera llegan hasta aquí: agente.py los salta antes.)
    if not evaluaciones:
        return 0.0

    puntajes: List[float] = []
    for e in evaluaciones:
        # Fallo técnico → fuera del promedio, sea cual sea su puntaje.
        if e.get("evaluacion_valida", True) is False:
            continue
        if e.get("sin_evidencia"):
            puntajes.append(0.0)          # política: falta crítica
        elif e.get("puntaje") is not None:
            puntajes.append(e["puntaje"])
        else:
            # Sin puntaje y sin ninguna marca que explique por qué. No se
            # inventa un 0.0 (acusaría al validado sin base) ni se ignora en
            # silencio: se trata como no imputable y el contador de fallos
            # técnicos lo hará visible.
            continue

    if not puntajes:
        return None
    return round(sum(puntajes) / len(puntajes), 2)


def calcular_score_con_ic(evaluaciones: List[Dict]) -> Dict:
    """
    [D1/D6-FIX] Calcula score con intervalo de confianza (IC 90%) y
    cobertura de evidencia media.

    En lugar de devolver solo "puntaje: 2", devuelve:
      {
        "score": 2.3,
        "ic_low": 1.5,   # IC 90% límite inferior
        "ic_high": 3.1,  # IC 90% límite superior
        "cobertura_evidencia": 0.42,  # fracción media de cobertura de contexto
        "masa_critica_ok": True/False, # ≥ 15 evaluaciones históricas por ámbito
        "n": 4,          # número de actividades evaluadas
      }

    El IC se calcula con la distribución t de Student (n-1 grados de libertad)
    sobre los puntajes individuales de las actividades.
    """
    import math

    # [AUDIT-FIX] Dos defectos, ambos por no seguir el criterio de
    # `calcular_score_ambito` (que sí los resuelve):
    #
    #  1. `float(e.get("puntaje", 1))` reventaba con TypeError ante cualquier
    #     evaluación con puntaje=None — justo lo que producen D3-FIX y
    #     `_evaluacion_invalida`. El default `1` no protege: solo aplica si la
    #     CLAVE falta, no si su valor es None.
    #  2. Sin evaluaciones devolvía score=0.0, el mismo antipatrón que hacía
    #     que «sin evidencia» se leyera como «pésimo». Debe ser None.
    #
    # Hoy la función no la llama nadie, pero está exportada en __all__: es API
    # pública y no se deja una mina en ella.
    validas = [
        e for e in evaluaciones
        if e.get("puntaje") is not None
        and e.get("evaluacion_valida", True) is not False
    ]

    if not validas:
        return {"score": None, "ic_low": None, "ic_high": None,
                "cobertura_evidencia": 0.0, "n": 0, "masa_critica_ok": False}

    puntajes = [float(e["puntaje"]) for e in validas]
    n = len(puntajes)
    media = sum(puntajes) / n
    evaluaciones = validas   # el resto de la función opera solo sobre válidas

    # Intervalo de confianza con t-Student (90%)
    # t crítico aproximado: n=2→2.92, n=3→2.35, n=4→2.13, n≥5→1.89
    t_criticos = {1: 6.31, 2: 2.92, 3: 2.35, 4: 2.13, 5: 1.89}
    t = t_criticos.get(n, 1.89)  # para n≥5 usar 1.89 (aprox.)

    if n > 1:
        varianza = sum((x - media) ** 2 for x in puntajes) / (n - 1)
        std_err = math.sqrt(varianza / n)
        margen = t * std_err
    else:
        margen = 2.0  # n=1: incertidumbre máxima

    ic_low  = round(max(1.0, media - margen), 2)
    ic_high = round(min(5.0, media + margen), 2)

    # Cobertura de evidencia media
    coberturas = [e.get("cobertura_contexto", 0.0) for e in evaluaciones
                  if e.get("cobertura_contexto") is not None]
    cobertura_media = round(sum(coberturas) / len(coberturas), 3) if coberturas else 0.0

    return {
        "score":               round(media, 2),
        "ic_low":              ic_low,
        "ic_high":             ic_high,
        "cobertura_evidencia": cobertura_media,
        "n":                   n,
        "masa_critica_ok":     False,  # se actualiza en agente.py con historial de feedback
    }


def validar_masa_critica_feedback(historial: List[Dict], ambito: str,
                                   min_registros: int = 15) -> Dict:
    """
    [D6-FIX] Verifica que hay suficiente historial de feedback para que el
    sistema anti-sesgo sea estadísticamente válido.

    Args:
        historial: lista de dicts del historial_feedback.json
        ambito: ámbito a validar
        min_registros: mínimo para masa crítica (default 15, recomendado por D6)

    Returns:
        {
          "masa_critica_ok": bool,
          "n_registros": int,
          "alerta": str o None,
        }
    """
    # [AUDIT-FIX] `r.get(...)` reventaba con AttributeError si el historial
    # traía un elemento que no fuera dict (fichero editado a mano, o escrito
    # por otra versión). Se ignoran esos registros en vez de tumbar la
    # evaluación: un historial sucio no puede impedir validar un modelo.
    registros_ambito = [r for r in (historial or [])
                        if isinstance(r, dict)
                        and str(r.get("ambito", "")).lower() == ambito.lower()]
    n = len(registros_ambito)
    ok = n >= min_registros
    alerta = None if ok else (
        f"⚠ Masa crítica insuficiente para '{ambito}': {n}/{min_registros} registros. "
        f"El anti-sesgo no es estadísticamente confiable. "
        f"Se necesitan al menos {min_registros - n} evaluaciones adicionales con feedback."
    )
    return {"masa_critica_ok": ok, "n_registros": n, "alerta": alerta}


def calcular_score_global(
    scores_por_ambito: Dict[str, float],
    pesos: Optional[Dict[str, float]] = None,
) -> Optional[float]:
    """
    Score global ponderado por ámbito, en la escala de política 0–5.

    ── POLÍTICA DE LA ENTIDAD ───────────────────────────────────────────────
    Un ámbito SIN EVIDENCIA puntúa 0.0 y entra en el promedio **con su peso
    íntegro**: la ausencia de documentación es una falta crítica y tiene que
    arrastrar el score global.

    Un ámbito que no pudo evaluarse por FALLO TÉCNICO del agente llega como
    None y se EXCLUYE, renormalizando los pesos sobre lo que sí se pudo
    evaluar. No es imputable al validado.

    Ejemplo con Gobierno (peso 0.12) sin evidencia y el resto evaluado:
        excluyéndolo y renormalizando →  3.02   (la ausencia no penalizaba)
        contándolo como 0.0 con peso  →  2.66   ← comportamiento correcto

    Devuelve None solo cuando NINGÚN ámbito pudo evaluarse por causas
    técnicas: ahí no hay dictamen que emitir, ni a favor ni en contra.
    """
    _pesos = pesos or AMBITO_PESOS
    total, peso_acum = 0.0, 0.0
    for ambito, score in scores_por_ambito.items():
        # None = fallo técnico → fuera del promedio y del denominador.
        # 0.0  = sin evidencia → dentro, con todo su peso (falta crítica).
        if score is None:
            continue
        peso       = _pesos.get(ambito, 1 / max(len(scores_por_ambito), 1))
        total      += score * peso
        peso_acum  += peso
    return round(total / peso_acum, 2) if peso_acum > 0 else None


def get_semaforo(score: Optional[float]) -> Dict:
    """
    Retorna label y color hex según el score. Usa SCORE_SEMAFORO de config.

    Distingue las DOS causas por las que un score puede no venir de una
    evaluación normal, porque tienen responsables distintos y el informe no
    puede confundirlas:

      score = 0.0   SIN EVIDENCIA — el validado no aportó documentación.
                    Política de la entidad: falta CRÍTICA. Se rotula por su
                    causa («NO EVALUABLE — SIN EVIDENCIA») pero conserva el
                    color crítico, para que nadie lo lea como un aprobado
                    técnico ni como un simple «pendiente».
                    Es un valor inequívoco: la escala de puntuación es 1–5,
                    así que ninguna evaluación real puede promediar 0.0.

      score = None  FALLO TÉCNICO del agente (timeout, PDF ilegible, JSON
                    roto). No es imputable al validado y no se emite dictamen.
                    Gris: no hay veredicto, hay que re-ejecutar.
    """
    if score is None:
        return {"label": "NO EVALUABLE — FALLO TÉCNICO", "color": "CCCCCC"}
    if score <= 0.0:
        return {"label": "NO EVALUABLE — SIN EVIDENCIA", "color": "FF0000"}
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score <= high:
            return info
    return {"label": "SIN CLASIFICAR", "color": "CCCCCC"}


# ══════════════════════════════════════════════════════════════════════════════
# RE-EXPORTAR INFRAESTRUCTURA Mx para quien importe motor_ia
# (evita que el resto del proyecto importe los Mx directamente)
# ══════════════════════════════════════════════════════════════════════════════

__all__ = [
    # ── Orquestadores (punto de entrada preferido) ───────────────────────────
    "orquestar_pipeline_virf",       # Pipeline 1: por control (ControlesData.xlsx)
    # ── Evaluación — lógica de negocio ───────────────────────────────────────
    "evaluar_actividad",
    "evaluar_ambito_completo",
    "generar_resumen_ejecutivo",
    # ── Métricas y semáforo ───────────────────────────────────────────────────
    "calcular_score_ambito",
    "calcular_score_con_ic",
    "calcular_score_global",
    "get_semaforo",
    "validar_masa_critica_feedback",
    # ── RAG — enriquecimiento semántico ───────────────────────────────────────
    "_enriquecer_con_rag",           # útil para tests y debugging
    "_rag_retriever_cache",          # permite inspeccionar qué dominios están cargados
    # ── Mx_01 — lectura de archivos ───────────────────────────────────────────
    "leer_carpeta",
    "leer_repositorio_informes",
    "leer_estandares_virf",
    "cargar_todos_inputs",
    "inputs_para_dimension",
    # ── Mx_03 — llamadas a IA ─────────────────────────────────────────────────
    "aprender_estilo",
    "generar_replica_virf",
    "generar_sintesis",
    # ── Mx_04 — controles automáticos ────────────────────────────────────────
    "detectar_cuestionamientos",
    "tiene_replica_virf",
    "calcular_riesgo_global",
    "resumen_cuestionamientos_consola",
    # ── Constantes re-exportadas ─────────────────────────────────────────────
    "RUTAS",
    "AMBITO_A_INPUTS",
    "INSTRUCCIONES_DIMENSION",
    "MODO_PREPRDC",
    "MODO_PRDC",
    "UMBRAL_RIESGO_GLOBAL",
]



# ══════════════════════════════════════════════════════════════════════════════
# NOTA — EVALUACIÓN PARALELA RETIRADA (auditoría 2026-07-27, D3)
# ══════════════════════════════════════════════════════════════════════════════
# Aquí vivían `evaluar_ambito_paralelo()`, `evaluar_todos_ambitos_paralelo()`,
# `_evaluar_actividad_thread_safe()` y `orquestar_pipeline_ambitos()`.
#
# Se retiraron porque: (a) nadie las llamaba —agente.py hace el flujo
# secuencial inline—, (b) sacrificaban la memoria intra-ámbito por diseño,
# (c) no propagaban `cobertura_docs`, y (d) ante un error asignaban
# `puntaje: 1`, inventando un score en un dictamen regulatorio.
#
# Código completo en: archivo/codigo_muerto_2026-07-26/evaluacion_paralela_motor_ia.py
#
# Si se retoma la paralelización, hacerlo a nivel de CHUNKS (independientes
# entre sí y responsables de ~57 llamadas por manual), no de actividades.
# ══════════════════════════════════════════════════════════════════════════════

# directamente.
#
#   Pipeline 1 — por CONTROL (ControlesData.xlsx):
#       orquestar_pipeline_virf()      ← facade de motor_ia_v2
#
#   Pipeline 2 — por ÁMBITO (Estandares_VIRF.xlsx):
#       orquestar_pipeline_ambitos()   ← encapsula el flujo de agente.py
# ══════════════════════════════════════════════════════════════════════════════


def orquestar_pipeline_virf(
    base_project_path: str,
    excel_controles:   str,
    nombre_modelo:     str,
    fecha_informe:     str,
    tier:              str = "I",
    datasets_dict:     Optional[Dict] = None,
    filtro_controles:  Optional[List[str]] = None,
) -> Dict:
    """
    Pipeline 1 — Evaluación por CONTROL (ControlesData.xlsx).

    Facade sobre motor_ia_v2.orquestar_pipeline_virf().
    Este es el pipeline RECOMENDADO para modelos con controles explícitos.

    Args:
        base_project_path: raíz del proyecto (contiene Evidencias/, Conocimiento/)
        excel_controles:   ruta al ControlesData.xlsx
        nombre_modelo:     nombre del modelo bajo validación (ej. "Modelo LaR v3")
        fecha_informe:     fecha YYYY-MM-DD para nombrar outputs
        tier:              tier regulatorio: "I", "II", "III", "IV"
        datasets_dict:     DataFrames para motor automático (opcional)
        filtro_controles:  lista de IDs de control (None = todos)

    Returns:
        Dict con 'estado', 'ruta_word', 'ruta_json', 'n_controles_evaluados'

    Ejemplo (notebook Databricks):
        from modulos.motor_ia import orquestar_pipeline_virf
        resultado = orquestar_pipeline_virf(
            base_project_path = "/dbfs/FileStore/virf/modelo_lar",
            excel_controles   = "/dbfs/FileStore/virf/modelo_lar/inputs/calidad_datos/ControlesData.xlsx",
            nombre_modelo     = "Modelo LaR v3",
            fecha_informe     = "2026-06-01",
            tier              = "I",
        )
        print(resultado["ruta_word"])
    """
    from modulos.motor_ia_v2 import orquestar_pipeline_virf as _orquestar_v2
    return _orquestar_v2(
        base_project_path = base_project_path,
        excel_controles   = excel_controles,
        nombre_modelo     = nombre_modelo,
        fecha_informe     = fecha_informe,
        tier              = tier,
        datasets_dict     = datasets_dict,
        filtro_controles  = filtro_controles,
    )


# NOTA: `orquestar_pipeline_ambitos()` también se retiró (auditoría D3).
# Llamaba a `evaluar_todos_ambitos_paralelo()` cuando paralelo=True, por lo
# que quedó rota al eliminar el bloque paralelo. Nadie la invocaba: el
# Pipeline 2 lo orquesta `agente.py` directamente.
# Código en: archivo/codigo_muerto_2026-07-26/evaluacion_paralela_motor_ia.py
