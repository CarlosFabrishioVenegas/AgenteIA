# VIRF Agent — Validador Autónomo de Modelos Financieros

> **Estado (2026-07-30):** Azure OpenAI como proveedor prioritario, verificado con mocks.
> `python validate_project.py --strict` → **131/131 PASS · 0 WARN · 0 FAIL · exit 0**
> `pytest` → **465 PASS · 2 skipped · 0 FAIL**
> Cada afirmación técnica cita `archivo:línea`.
>
> ### 📖 ¿Vas a validar un modelo? Empieza por **[`RUNBOOK.md`](RUNBOOK.md)**
> El flujo operativo en 6 pasos con los criterios de parada de cada fase.
> Este README es la referencia técnica; el runbook es el procedimiento.
>
> Otros documentos: **[`FLAGS.md`](FLAGS.md)** (manual de la CLI, 28 flags) ·
> **[`FUNCIONALIDADES.md`](FUNCIONALIDADES.md)** (catálogo funcional) ·
> **[`METODOLOGIA_DEL_AGENTE.md`](METODOLOGIA_DEL_AGENTE.md)** (el criterio de validación)

---

## Índice

### Documentos del proyecto

| Documento | Para qué | Cuándo lo abres |
|---|---|---|
| 📖 **[`RUNBOOK.md`](RUNBOOK.md)** | El flujo operativo en 6 pasos, con los criterios de parada de cada fase | **Vas a validar un modelo** |
| ⚙️ [`FLAGS.md`](FLAGS.md) | Manual de la CLI: ficha por flag, precedencia de modos, códigos de salida | Necesitas un comando concreto |
| 📚 [`FUNCIONALIDADES.md`](FUNCIONALIDADES.md) | Catálogo funcional: qué hace cada pieza y por qué existe | Quieres entender una capacidad |
| 📐 [`METODOLOGIA_DEL_AGENTE.md`](METODOLOGIA_DEL_AGENTE.md) | El criterio de validación — la vara de medir | Discutes un puntaje |
| 🔀 [`GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md`](GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md) | Cambio de proveedor IA | Migras de proveedor |
| 📄 **este README** | Referencia técnica: instalación, arquitectura, changelog | Buscas el porqué de una decisión |

### Secciones de este README

| # | Sección |
|---|---|
| 1 | [Qué es este proyecto](#1-qué-es-este-proyecto) |
| 2 | [Instalación](#2-instalación) |
| 3 | [Configuración (.env)](#3-configuración-env) |
| 4 | [Estructura del proyecto](#4-estructura-del-proyecto) |
| 5 | [Cómo funciona (flujo end-to-end)](#5-cómo-funciona-flujo-end-to-end) |
| 6 | [Comandos disponibles](#6-comandos-disponibles) |
| 7 | [Módulos — referencia](#7-módulos--referencia) |
| 8 | [Limitaciones y código pendiente](#8-limitaciones-y-código-pendiente) |
| 9 | [Preguntas abiertas](#9-preguntas-abiertas) |
| **10** | [**Arquitectura del proyecto**](#10-arquitectura-del-proyecto) |
| **11** | [**Salidas del sistema — detalladas**](#11-salidas-del-sistema--detalladas) |
| **12** | [**Registro de limpieza (changelog de auditoría)**](#12-registro-de-limpieza-changelog-de-auditoría) |
| **13** | [**Catálogo completo de archivos .py**](#13-catálogo-completo-de-archivos-py) |

---

## 1. Qué es este proyecto

En banca, todo modelo de riesgo debe ser revisado por un equipo **independiente** antes de usarse. Ese equipo verifica que la metodología sea sólida, que los datos estén limpios, que exista documentación, que haya aprobación formal y que el modelo se use para lo que fue diseñado. Es un trabajo lento, caro y subjetivo: dos validadores pueden emitir dictámenes distintos sobre el mismo modelo.

**VIRF Agent** automatiza ese primer barrido usando un LLM. Recibe la evidencia del modelo —manuales, informes de seguimiento, código, datasets— y una **rúbrica de evaluación** en Excel (`inputs/Estandares_VIRF.xlsx`), y produce un puntaje 1-5 por actividad, un score global ponderado según pesos anclados a normativa (SR 11-7, BCBS 239, EBA), un informe Word y un JSON auditable con trazabilidad criptográfica de qué evidencia se usó.

El principio de diseño central es **no inventar**. Si un ámbito no tiene evidencia, el agente no llama al LLM y marca esa actividad como no evaluada (`agente.py:443`, `[D3-FIX]`). Si el LLM devuelve una respuesta que no cumple el contrato esperado, la evaluación se descarta en vez de sustituirse por un puntaje por defecto (`modulos/motor_ia.py:_evaluacion_invalida`). Las actividades no evaluadas quedan **excluidas del score**, no contadas como cero. Un dictamen incompleto se marca con `dictamen_confiable: false`.

Además del pipeline de validación, incluye tres herramientas: conversión de procesos Excel (con VBA y referencias entre libros) a notebooks Python verificados, ejecución de controles de calidad de datos sobre datasets reales, y análisis de brechas entre los controles que un manual **promete** y los que realmente **se ejecutan**.

---

## 2. Instalación

### 2.1 Requisitos

| Requisito | Versión | Verificado en |
|---|---|---|
| Python | ≥ 3.10 | sintaxis `str \| None` en `src/rag/__init__.py:45` |
| API key del proveedor IA | — | `config/ia.py` |

### 2.2 Instalar

```bash
cd "virf_agent_v27_final (1)"
pip install -r requirements.txt
python validate_project.py       # debe dar 88/88 PASS
```

### 2.3 OCR (opcional — solo para PDFs escaneados)

`motor/Mx_01_LecturaEvidencias.py:92` intenta OCR como tercer fallback. El paquete `pytesseract` va en `requirements.txt`, pero necesita **binarios del sistema**:

```bash
# Linux
sudo apt install tesseract-ocr tesseract-ocr-spa poppler-utils
# macOS
brew install tesseract tesseract-lang poppler
# Windows: instalar Tesseract-OCR y Poppler y añadirlos al PATH
```

> ⚠️ `pip install pytesseract` **no** instala Tesseract. Sin el binario, un PDF escaneado se lee vacío y el agente lo reporta como falta de evidencia (no como error).

---

## 3. Configuración (.env)

```bash
cp .env.example .env    # luego edita ANTHROPIC_API_KEY
```

Si ejecutas `agente.py` sin `.env`, se crea automáticamente (`agente.py:_setup_env_si_falta`).

### 3.0 Dónde vive la configuración ⭐

Toda la configuración del proyecto está en el paquete **`config/`**. La API
pública no cambió: `from config import get_cliente_ia, AMBITO_PESOS, …` sigue
funcionando igual que cuando era un `config/` monolítico.

| Fichero | Qué contiene | Cuándo tocarlo |
|---|---|---|
| `config/parametros.py` | **Única fuente de verdad** de todo lo ajustable por variable de entorno: chunking, límites de lectura, caché, Excel, IA | Cambiar un límite o un umbral |
| `config/rutas.py` | Dónde vive cada carpeta y fichero | Mover carpetas del proyecto |
| `config/dominio.py` | Pesos de ámbito (con referencia regulatoria), escalas, semáforo, preguntas metodológicas, tiers | Cambiar criterio de validación |
| `config/ia.py` | Clientes Anthropic/Azure, guardia anti-fuga de claves, factory cacheada | Añadir un proveedor |

**La regla:** si un parámetro se puede tocar con una variable de entorno, se
declara en `config/parametros.py` **y en ningún otro sitio**. Ningún módulo
debe volver a llamar a `os.getenv` para un parámetro de negocio — hay un test
(`test_ningun_modulo_redeclara_parametros_de_negocio`) que lo verifica.

> ⚠️ **`config/` y `config/` no pueden coexistir.** Python resuelve los
> paquetes **antes** que los módulos, así que un `config/` que reaparezca en
> la raíz quedaría inalcanzable en silencio mientras los 16 `from config import`
> del proyecto siguen cargando el paquete. El validador y un test lo comprueban;
> el monolito original está archivado en `archivo/config_monolitico_2026-07-27/`.

**Qué resolvió esta centralización** (v27.2). La configuración estaba
duplicada, y en un caso el duplicado ni siquiera leía el entorno:

| Parámetro | Antes | Consecuencia |
|---|---|---|
| `MAX_CHARS_DOC` y compañía | `config/` leía el `.env`; **`Mx_00` lo tenía hardcodeado a 15000** | Ponerlo en `.env` cambiaba un módulo y el otro no: seguía truncando a 15000 |
| `VIRF_CHUNK_SIZE/_OVERLAP/_THRESHOLD` | Declarados en `chunker.py` **y** en `Mx_01` | El umbral de "documento largo" podía dejar de coincidir con el tamaño de segmento real |
| `VIRF_MAX_CTX` | En `agente.py`, `chunker.py` y `motor_ia.py`, con **dos defaults distintos** | Coincidían por casualidad; al tocar `MAX_CHARS_DOC` el chunker calculaba su presupuesto contra un valor obsoleto |

### 3.1 Seguridad de credenciales

| Archivo | Contiene | ¿Se commitea? |
|---|---|---|
| `.env` | Clave real | ❌ Protegido por `.gitignore:2` |
| `.env.example` | `TU_API_KEY_AQUI` | ✅ Es la plantilla |

`config/ia.py` implementa una **guardia anti-fuga** (`_detectar_key_en_example`): si la clave de `.env` aparece literalmente en `.env.example`, el agente aborta y exige revocarla.

### 3.2 Proveedor IA

| Variable | Default real | Consumida en |
|---|---|---|
| `IA_PROVEEDOR` | `azure_openai` | `config/parametros.py:127` |
| `ANTHROPIC_API_KEY` | *(vacío)* | `config/ia.py` |
| `ANTHROPIC_MODELO` | `claude-sonnet-4-6` | `config/ia.py`, `Mx_00` |
| `ANTHROPIC_MAX_TOKENS` | `4096` | `config/ia.py` |
| `VIRF_VALIDAR_CONEXION` | `0` | `config/ia.py` — `1` gasta 1 request al arrancar |
| `AZURE_OPENAI_*` | *(vacío)* | `config/ia.py` |

### 3.3 Lectura de documentos

| Variable | Default real | Consumida en |
|---|---|---|
| `MAX_CHARS_DOC` | `15000` | `config/parametros.py`, `Mx_00:49` |
| `MAX_CHARS_CODIGO` | `8000` | `config/parametros.py`, `Mx_00:50` |
| `MAX_FILAS_EXCEL` | `200` | `config/parametros.py`, `Mx_00:51` |
| `VIRF_MAX_CTX` | `= MAX_CHARS_DOC` | `motor_ia.py:457` |
| `VIRF_MAX_DOCS_AMBITO` | `0` (sin límite) | `agente.py:421` |

> ✅ Verificado: `config/` y `Mx_00` declaran los mismos valores. Sin divergencia.

### 3.4 Chunking de documentos largos ⭐

| Variable | Default real | Consumida en |
|---|---|---|
| `VIRF_CHUNK_SIZE` | `12000` *(solo el tamaño inicial)* | `chunker.py:44` |
| `VIRF_CHUNK_OVERLAP` | `800` | `chunker.py:45` |
| `VIRF_CHUNK_THRESHOLD` | `= CHUNK_SIZE` | `chunker.py:46` |
| **`VIRF_MAX_CHUNKS`** | **`40`** *(era 60, antes 25)* | `chunker.py:66` |
| `VIRF_CHUNK_SIZE_MAX` | `40000` | `chunker.py:72` |
| `VIRF_PRESUPUESTO_DOC` | `9000` (60% de MAX_CTX) | `chunker.py:88` |
| `VIRF_MAX_NIVELES` | `3` | `chunker.py:82` |
| `VIRF_CHUNK_ENABLED` | `1` | `Mx_01:298` |

**Cobertura por configuración:**

La cobertura **no** depende de `VIRF_MAX_CHUNKS` mientras el modo adaptativo
pueda actuar: si el documento no cabe en N segmentos, se agrandan los segmentos
hasta `VIRF_CHUNK_SIZE_MAX` en vez de descartar texto.

| MAX_CHUNKS | Cobertura sin jerarquía | Páginas (~2.000 chars/pág) |
|---:|---:|---:|
| 25 *(v27.0)* | 280.000 chars | ~140 *(truncaba)* |
| 60 *(v27.1)* | 2.376.000 chars | ~1.188 |
| **40** *(actual)* | **1.568.000 chars** | **~784** |

Por encima de eso entra el **modo jerárquico**, que también preserva el 100% —
pero cuesta más, así que el chunker ahora **avisa** al cruzar ese punto
(ver [§3.4.1](#341-coste-por-documento-) y [§10.5](#105-decisión-cobertura-total-en-documentos-grandes)).

### 3.4.1 Coste por documento ⭐

Medido sobre un PDF **real de 305 páginas** (1.302.266 chars). Las cifras de
dólares de esta sección corresponden al modelo con el que se hizo la medición
(`claude-haiku-4-5`, $1 / $5 por 1M tokens in/out): **son un orden de magnitud,
no tu factura**. Con otro modelo cambian proporcionalmente al precio de su
entrada, que está tarifado en `config/modelos.py:PRECIOS_ENTRADA_USD_POR_MTOK`
— el mismo sitio del que salen las estimaciones de `--dry-run`.

Lo que **no** cambia al cambiar de proveedor es el número de tokens: se calibra
contra el endpoint de conteo de la propia API, y sobre este documento da
**2,48 chars/token** (español técnico denso con tablas y cifras — mucho peor
ratio que los ~4 chars/token del inglés corriente). Esa relación es una
propiedad del idioma y del tipo de texto, no del proveedor.

Con el default actual (`VIRF_MAX_CHUNKS=40`):

| Concepto | Llamadas | Tokens in | Tokens out | Coste |
|---|---:|---:|---:|---:|
| Chunking (1ª vez) | 43 | 642.427 | 99.513 | **$1,14** |
| Chunking (re-corrida) | **0** | **0** | **0** | **$0,00** ⚡ |
| 19 evaluaciones de actividad | 19 | ~76.000 | ~19.000 | $0,17 |
| **Total 1ª validación** | 62 | | | **≈ $1,31** |
| **Total re-validación** | 19 | | | **≈ $0,17** |

> ⚠️ El coste de **entrada** ($0,64) es exacto y determinista. El de **salida**
> ($0,50) es el **peor caso**: asume que el modelo agota `max_tokens` en cada
> segmento. En la práctica suele quedarse en el 60-80%, así que el rango real
> por documento es **$0,94 – $1,14**.

**Dónde se va el dinero.** La salida pesa casi tanto como la entrada pese a ser
6× menos tokens, porque se factura a 5×. Los resúmenes de segmento se generan y
después se comprimen a ~8.500 chars para caber en `VIRF_PRESUPUESTO_DOC` — una
relación de ~28:1, así que buena parte de lo que se paga por generar se
descarta en la consolidación.

*(Referencia histórica: con el default anterior de `60` eran 63 llamadas y
$1,45 — misma cobertura del 100%, un 21% más caro.)*

**El caché de resúmenes** (`data/cache/chunk_summaries_cache.json`) elimina el
100% del coste de chunking cuando el documento no cambia. La clave combina el
SHA-256 del texto con la configuración del chunker: si cambia el documento **o**
cambia cómo se segmenta, se recalcula. Verificado sobre el PDF real: 2ª corrida
= 0 llamadas, cobertura 100%.

#### Efecto de `VIRF_MAX_CHUNKS` (medido, mismo PDF)

| `VIRF_MAX_CHUNKS` | Modo | Llamadas | Coste | vs. actual |
|---:|---|---:|---:|---:|
| 60 *(actual)* | adaptativo + consolidación | 63 | $1,45 | — |
| **40** | adaptativo + consolidación | 43 | **$1,14** | **−21%** |
| 30 | ⚠️ jerárquico puro | 120 | $2,27 | **+57%** |

> ⚠️ **Hay un acantilado, no una pendiente.** Bajar `VIRF_MAX_CHUNKS` abarata
> hasta ~40, pero **por debajo de ~33 el coste se dispara**: el segmento
> adaptativo necesario (1.302.266 / 33 ≈ 39.500) supera `VIRF_CHUNK_SIZE_MAX`
> (40.000), el chunker abandona el modo adaptativo y procesa los **117**
> segmentos de 12.000 en modo jerárquico puro. Menos segmentos permitidos
> acaban costando **el doble**. No bajar de 40 sin subir también
> `VIRF_CHUNK_SIZE_MAX`.

**Alternativas descartadas:**
- **Modelo más barato para los segmentos**: no aplicó en la medición, porque el
  modelo usado ya era el más económico de su familia. Si tu proveedor ofrece uno
  más barato con contexto suficiente, la palanca sigue disponible: añádelo a
  `config/modelos.py` y el chunking se redimensiona solo a partir de su ventana
  real. Verifica antes la calidad de los hallazgos — un modelo económico produce
  resúmenes más genéricos, y este sistema busca hallazgos concretos.
- **Subir `VIRF_CHUNK_SIZE`**: no tiene efecto en un documento de este tamaño —
  el modo adaptativo ya recalcula el tamaño de segmento e ignora el valor
  configurado. Solo importa en documentos que caben en `VIRF_MAX_CHUNKS`.

**Para abaratar más:**
- `VIRF_CHUNK_ENABLED=0` → sin resúmenes, pero trunca a `MAX_CHARS_DOC`
  (cobertura reportada correctamente, sin engaño)
- `VIRF_MAX_CHUNKS=40` → −21% de coste conservando el 100% de cobertura

### 3.5 Caché, feedback y Excel

| Variable | Default real | Consumida en |
|---|---|---|
| `CACHE_ENABLED` | `1` | `Mx_00:66` |
| `CACHE_DIR` | `<raíz>/data/cache` | `Mx_00:70` |
| `VIRF_CACHE_LOCK_TIMEOUT` | `10` seg | `document_cache.py:69` |
| `VIRF_CACHE_LOCK_STALE` | `60` seg | `document_cache.py:70` |
| `VIRF_MIN_FEEDBACK_ANTISESGO` | `15` | `motor_ia.py` |
| `EXCEL_MAX_FORMULAS_HOJA` | `2000` | `excel_a_notebook.py:62` |
| `EXCEL_VALIDACION_TOL` | `1e-6` | `excel_a_notebook.py:64` |
| `EXCEL_NB_TIMEOUT` | `120` seg | `excel_a_notebook.py:65` |
| `VIRF_AGENTE_VERSION` | `27.1` | `Mx_00:27` |
| `DEBUG_PROMPTS` | `0` | `Mx_03:78` |

---

## 3-bis. Configuración de Proveedor IA

### Azure OpenAI es el proveedor prioritario

Por **política de la entidad**, VIRF opera contra Azure OpenAI / Azure AI Foundry.
Tres consecuencias, todas deliberadas:

**1. El default vive en el código, no en el `.env`.**
`config/parametros.py` declara `IA_PROVEEDOR = os.getenv("IA_PROVEEDOR", "azure_openai")`.
Si alguien clona el proyecto y olvida definir la variable, la corrida sale por
Azure — no por el proveedor secundario. Depender de que el operador recuerde
poner una variable es depender de que no se equivoque.

**2. No hay fallback automático al proveedor secundario.**
Si Azure falla —rate limit, timeout, credencial inválida, respuesta no
parseable—, el sistema **reporta el error y se detiene**. No reintenta contra
otro proveedor.

No es una limitación pendiente de arreglar: es gobernanza. Un informe con
evaluaciones de **dos modelos distintos** bajo una sola huella de ejecución
haría falsa la reproducibilidad que el propio informe declara (invariante 5 de
`METODOLOGIA_DEL_AGENTE.md`), y esa huella es justo lo que un auditor verifica.

Reintentar ante un `429` contra el **mismo** proveedor no es fallback: es lo que
la propia API pide con `Retry-After`.

**3. Un proveedor por corrida, seleccionado solo desde `config/`.**
Ningún módulo de negocio sabe qué proveedor hay detrás: todos consumen la
interfaz abstracta `ClienteIA.generar_mensaje() -> str`. Hay un test que falla
si aparece `.content[0]`, `choices[0]` o un `import` de SDK fuera de `config/`.

Anthropic se mantiene disponible como **secundario** (`IA_PROVEEDOR=anthropic`).

### Modelo activo

**Pendiente de confirmar con la credencial.** El modelo NO se fija a mano: se
detecta consultando la API, porque el nombre del deployment no lo revela —lo
elige quien despliega— y de él dependen la ventana de contexto, los parámetros
admitidos y el precio.

`config/modelos.py` contiene el catálogo de perfiles. Cuando la primera llamada
devuelve `response.model`, el sistema resuelve el perfil por coincidencia de
prefijo y aplica sus límites de chunking automáticamente:

| Modelo | Contexto | chunk_size | Parámetro de tokens | `temperature` |
|---|---:|---:|---|---|
| GPT-4 (clásico) | 8K | 8.000 | `max_tokens` | sí |
| GPT-4-turbo / GPT-4o | 128K | 40.000 | `max_tokens` | sí |
| GPT-4.1 | 1M | 40.000 | `max_tokens` | sí |
| o1 / o3 | 200K | 40.000 | **`max_completion_tokens`** | **no** |
| GPT-5 | 400K | 40.000 | **`max_completion_tokens`** | **no** |
| Claude (secundario) | 200K | 40.000 | `max_tokens` | sí |

Dos detalles que evitan fallos reales:

- **Los modelos de razonamiento rechazan `max_tokens`** con un `400`. El cliente
  **negocia** el parámetro contra el servidor en la primera llamada y memoriza
  el resultado, en vez de adivinarlo por el nombre del deployment.
- **El `chunk_size` se acota a 40.000 aunque el contexto sea de 1M.** No es un
  límite técnico sino de **calidad**: resumir 100.000 caracteres de una vez
  produce resúmenes genéricos, y este sistema busca hallazgos concretos («el
  manual declara Kupiec pero no aporta p-valores»). El detalle vive en segmentos
  medianos.

Un modelo no catalogado cae en un perfil **conservador** (16K) y se avisa por
consola: quedarse corto produce más llamadas; pasarse produce truncados
silenciosos y pérdida de cobertura documental.

### Qué pedirle a IT ⭐

Si el recurso de Azure OpenAI **lo administra tu organización**, no necesitas
crear nada: necesitas cuatro datos. Copia esto en el ticket:

> Necesito acceso a nuestro recurso de Azure OpenAI. Concretamente:
> 1. La **API key** del recurso (KEY 1 o KEY 2)
> 2. El **endpoint** del recurso (`https://<algo>.openai.azure.com/`)
> 3. El **nombre del deployment** — el nombre que se le dio al desplegar el
>    modelo, no el nombre del modelo
> 4. La **api-version** que estén usando en producción
>
> Es para una herramienta interna de validación de modelos de riesgo.

**Cuando IT te las dé, tú haces dos cosas y nada más:**

```bash
# 1. Pégalas en .env  (la plantilla ya trae las 4 líneas comentadas)
#    AZURE_OPENAI_API_KEY=...
#    AZURE_OPENAI_ENDPOINT=https://....openai.azure.com/
#    AZURE_OPENAI_DEPLOYMENT=nombre-del-deployment
#    AZURE_OPENAI_API_VERSION=2024-10-21

# 2. Un solo comando
python agente.py --verificar-conexion-azure
```

Salida esperada:

```
✅ azure_openai conectado — modelo: gpt-4o-2024-11-20 — latencia: 812 ms
   JSON parseado correctamente: {'ok': True}

Perfil de chunking que se aplicará (gpt-4o):
   contexto      : 128,000 tokens
   chunk_size    : 40,000 chars
   max_ctx       : 184,320 chars
   max_chunks    : 40
   param. tokens : max_tokens
   temperature   : admitida
```

**No hay que tocar código después.** El sistema detecta solo qué modelo sirve el
deployment y ajusta el chunking a su contexto real: si te dan GPT-4 clásico
(8K), reduce el presupuesto; si te dan GPT-5, negocia `max_completion_tokens` y
omite `temperature`. Ese ajuste está en `config/modelos.py`, no en el código de
negocio.

**No hace falta definir `IA_PROVEEDOR`**: el default ya es `azure_openai` y vive
en `config/parametros.py`, no en el `.env` — olvidarlo no cambia de proveedor.

Si algo falla, el comando dice **qué** variable revisar y **dónde** obtenerla, y
sale con código 1. No hay fallback: el sistema se detiene.

---

### Cómo activar Azure OpenAI (si tú administras el recurso)

**Paso 1 — Crear el recurso.** En `portal.azure.com` o `ai.azure.com`, crea un
recurso de Azure OpenAI en tu suscripción y región.

**Paso 2 — Desplegar un modelo.** En el recurso → *Deployments* → *Create new
deployment*. Elige el modelo y dale un **nombre de deployment**. Sube el TPM
(tokens por minuto) todo lo que tu cuota permita: el chunker hace hasta 40
llamadas seguidas por documento y un TPM bajo garantiza `429`. Subirlo no
cuesta: es un reparto de tu cupo regional, no un cargo.

**Paso 3 — Copiar las cuatro variables a `.env`:**

```bash
IA_PROVEEDOR=azure_openai
AZURE_OPENAI_ENDPOINT=https://TU-RECURSO.openai.azure.com/   # Keys and Endpoint
AZURE_OPENAI_API_KEY=…                                        # Keys and Endpoint → KEY 1
AZURE_OPENAI_DEPLOYMENT=nombre-exacto-de-tu-deployment        # Deployments → DEPLOYMENT NAME
AZURE_OPENAI_API_VERSION=2024-10-21                           # GA estable, no preview
```

> ⚠️ **El error nº 1 de toda migración: confundir deployment con modelo.**
> Si tu deployment se llama `gpt4o-virf-prod`, ese es el valor.
> Poner `gpt-4o` da `DeploymentNotFound (404)` aunque el modelo exista.

> ⚠️ **Usa una `api_version` GA, no `preview`.** Una preview puede cambiar de
> comportamiento sin aviso, y este sistema exige corridas reproducibles.

**Paso 4 — Prueba de humo.** Un solo comando:

```bash
python agente.py --verificar-conexion-azure
```

Comprueba cuatro cosas de una vez: que la credencial vale, qué modelo sirve
realmente el deployment, qué perfil de chunking se aplicará, y que el parser
**real** entiende el JSON que devuelve. Salida esperada:

```
✅ azure_openai conectado — modelo: gpt-4o-2024-11-20 — latencia: 412 ms
   JSON parseado correctamente: {'estado': 'ok', 'prueba': True}

Perfil de chunking que se aplicará (gpt-4o):
   contexto      : 128,000 tokens
   chunk_size    : 40,000 chars
   max_ctx       : 184,320 chars
   max_chunks    : 40
   param. tokens : max_tokens
   temperature   : admitida
```

Si falla, el mensaje indica exactamente qué variable revisar y dónde
encontrarla en el portal.

**Paso 5 — Primera corrida real.** Antes de nada, limpia el caché: contiene
resúmenes generados por el proveedor anterior.

```bash
python agente.py --limpiar-cache
python agente.py --titulo "Modelo de prueba" --tier 4
```

### Verificar la calidad tras migrar

Lo único que no se puede automatizar. Coge un modelo ya evaluado con el
proveedor anterior y compara los hallazgos:

- ¿Cita evidencia **concreta y localizable**, o generalidades?
- ¿Distingue «el manual lo declara» de «el manual lo demuestra con cifras»?
- ¿El `puntaje` está **justificado** en la observación?

Si los hallazgos salen más genéricos, ajusta los prompts de
`motor/Mx_02_EstructuraPrompt.py`. Los modelos de OpenAI responden mejor a
instrucciones **numeradas explícitamente** y a un ejemplo del formato esperado;
Claude tolera mejor la instrucción en prosa.

Guía completa: `GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md`.

---

## 4. Estructura del proyecto

**140 archivos** · **115 `.py`** · **~25.700 líneas** *(tras archivar 2.888 líneas de código muerto)*

```
virf_agent_v27_final/
│
├── agente.py                    ⭐ ENTRYPOINT ÚNICO — 4 modos de ejecución
├── config/                      ⭐ CENTRAL DE CONFIGURACIÓN (ver §3.0)
│   ├── __init__.py                  API pública: `from config import X`
│   ├── parametros.py                TODO lo ajustable por entorno (fuente única)
│   ├── rutas.py                     dónde vive cada carpeta y fichero
│   ├── dominio.py                   pesos, escalas, semáforo, preguntas VIRF
│   └── ia.py                        clientes IA + guardia anti-fuga de claves
├── validate_project.py          verificador de integridad — 13 bloques, 95 checks
├── requirements.txt · .env · .env.example · .gitignore
│
├── modulos/     [11 archivos]   LÓGICA DE NEGOCIO
├── motor/       [ 6 archivos]   INFRAESTRUCTURA (Mx_*)
├── src/rag/     [18 archivos]   RAG SEGMENTADO POR DOMINIO  ← el activo
├── agent/       [65 archivos]   PLATAFORMA v28 — chat interactivo (subsistema aparte)
│
├── inputs/                      ⭐ TU EVIDENCIA (ver §4.2)
├── outputs/YYYY-MM-DD/          todos los informes, por fecha
├── data/cache/                  caché de documentos
├── data/vectordb/<dominio>/     índices ChromaDB
├── scripts/                     rebuild_rag_databricks.py
└── archivo/codigo_muerto_2026-07-26/   respaldo de lo retirado (§12)
```

### 4.1 Dónde cargar cada archivo ⭐

```
inputs/
├── Estandares_VIRF.xlsx              ⭐ OBLIGATORIO — la rúbrica de evaluación
├── documentacion/
│   ├── modelamiento/                 manuales metodológicos, DDM, DTV
│   └── seguimiento/                  informes de backtesting, monitoreo
├── calidad_datos/
│   ├── ControlesData.xlsx            catálogo de controles ejecutables
│   ├── manual_controles_datos.md     manual en prosa (para análisis de brechas)
│   └── datasets/                     ⭐ los datos a validar (.csv/.parquet/.xlsx)
├── implementacion/                   código, arquitectura, deploy
├── papers/                           literatura académica
├── usos/                             actas de comité, evidencia de uso
└── excel_procesos/                   libros a convertir a notebook
```

**Mapeo ámbito → carpetas** (`motor/Mx_00_CargaRutas.py:71`, `AMBITO_A_INPUTS`):

| Ámbito | Lee de |
|---|---|
| Documentación | `doc_modelamiento`, `doc_seguimiento`, `papers` |
| Calidad de datos | `calidad_datos`, `doc_modelamiento` |
| Metodología | `doc_modelamiento`, `papers`, `doc_seguimiento` |
| Gobierno | `doc_modelamiento`, `implementacion` |
| Implementación | `implementacion`, `doc_modelamiento` |
| Uso e integración | `usos`, `implementacion` |

> ⚠️ Dejar `implementacion/` vacío hace fallar **tres** ámbitos (Gobierno, Implementación, Uso).

**Exclusiones automáticas** (`control_evaluacion_data.py:ARCHIVOS_EXCLUIDOS`): `Estandares_VIRF.xlsx` y `ControlesData.xlsx` no cuentan como evidencia — son configuración del validador. `datasets/` se excluye de la búsqueda documental.

### 4.2 Formatos leídos

Lectores en `motor/Mx_01_LecturaEvidencias.py`:

| Formato | Función | Estrategia |
|---|---|---|
| `.pdf` | `_leer_pdf` | pdfminer → PyPDF2 → OCR (3 fallbacks) |
| `.docx` / `.doc` | `_leer_docx` | párrafos + tablas |
| `.pptx` / `.ppt` | `_leer_pptx` | texto de diapositivas |
| `.xlsx` / `.xls` / `.xlsm` | `_leer_excel` | celdas no vacías, máx. `MAX_FILAS_EXCEL` |
| **`.py`** | `_leer_python` | **íntegro** — el tope `MAX_CHARS_CODIGO` solo aplica con `VIRF_CHUNK_ENABLED=0` |
| **`.ipynb`** | `_leer_ipynb_completo` | código + markdown + outputs acotados; **declara qué celdas se ejecutaron** |
| **`.sql`** / **`.R`** | directa | íntegro, mismo criterio que `.py` |
| `.json` | `_leer_json` | formateado |
| `.md`, `.txt`, `.csv` | directa | UTF-8 |

**16 extensiones.** Las cuatro en negrita son **código** (`EXTENSIONES_CODIGO`) y
son las que alimentan `--revisar-codigo`, la revisión módulo a módulo contra el
manual.

> ⚠️ Lo que **no** está en esta tabla se omite **sin aviso**: `leer_archivo()`
> devuelve `None` y el fichero desaparece de la evidencia. Si tu modelo usa
> `.scala`, `.yaml`, `.do` o `.sas`, hay que registrarlos en `LECTORES_EXT`
> (y en `EXTENSIONES_CODIGO` + `LENGUAJE_POR_EXT` si deben revisarse).

---

## 5. Cómo funciona (flujo end-to-end)

Trazado real de `python agente.py --titulo "M" --tier 1 --prdc`:

```
agente.py:_setup_env_si_falta()              crea .env si falta
    ↓
agente.py:main()                              argparse — 16 flags
    ↓
document_cache.py:inicializar_cache()         activo solo si NO --prdc  (agente.py:117)
    ↓
config/ia.py:get_cliente_ia()                cliente cacheado [PERF-FIX]
    ↓
motor_ia.py:leer_estandares_virf(tier)        Excel → filtra por columna TIER (X)
    ↓
Mx_01:cargar_todos_inputs()                   6 carpetas → texto por extensión + caché SHA-256
    ↓
chunker.py:ChunkerService.procesar_lote()     documentos largos → resumen por segmentos
    │                                          devuelve cobertura_pct / n_chunks / modo_cobertura
    ↓
POR CADA ÁMBITO  (agente.py:~410):
    ├─ inputs_para_dimension()                filtra docs del ámbito
    ├─ arma contexto hasta VIRF_MAX_CTX
    ├─ calcula cobertura_ambito  ← [COBERTURA-FIX] agente.py:445
    │
    ├─ ¿sin documentos?  → [D3-FIX] agente.py:443
    │                      NO llama al LLM · puntaje=None · excluido del score
    │
    └─ motor_ia.py:evaluar_ambito_completo(cobertura_docs=…)
           └─ evaluar_actividad()  ← por actividad
                ├─ construir_contexto_feedback()        feedback.py
                ├─ construir_bloque_aprendizaje()       feedback_mejorado.py
                ├─ _construir_bloque_antisesgo()        exige ≥15 feedbacks [D6-FIX]
                ├─ _enriquecer_con_rag()                src/rag/ — dominio por título
                ├─ bloque de cobertura REAL             [COBERTURA-FIX motor_ia.py:463]
                ├─ memoria intra-ámbito                 últimos 4 hallazgos
                ├─ Mx_03:_llamar_modelo()               cliente cacheado
                ├─ _extraer_json()                      tolera texto alrededor del JSON
                ├─ _validar_contrato_evaluacion()       [CONTRATO-FIX]
                │     └─ falla → _evaluacion_invalida() · puntaje=None
                └─ ajustar_puntaje_por_feedback()       exige ≥3 muestras
    ↓
motor_ia_v2.py:evaluar_todos_controles()      si existe ControlesData.xlsx
    ↓
calcular_score_ambito()                       excluye puntaje=None
calcular_score_global()                       ponderado por AMBITO_PESOS
    ↓
agente.py:~600   bloque de INTEGRIDAD         evaluadas OK / sin evidencia / fallos
agente.py:~500   huella de trazabilidad       SHA-256 por documento
    ↓
generador_word.py:generar_word_informe()      solo si --prdc
    ↓
feedback.py:bucle_feedback_consola()          solo si NO --prdc
    └─ [CI-FIX] stdin no TTY → retorna [] y exit 0
    ↓
document_cache.py:cerrar_cache()              lock + merge + escritura atómica
```

### 5.1 Contratos entre módulos (verificados)

| Frontera | Produce | Consume | Estado |
|---|---|---|---|
| `Mx_01` → `agente.py` | `{nombre, tipo, contenido, chars_totales, truncado}` | `nombre`, `contenido` | ✅ compatible |
| `chunker` → `agente.py` | `+ {cobertura_pct, n_chunks, modo_cobertura, fue_resumido}` | `cobertura_pct`, `modo_cobertura` | ✅ **conectado en esta auditoría** |
| `agente.py` → `motor_ia` | `contexto` + `cobertura_docs` | ambos | ✅ |
| `motor_ia` → `Mx_03` | `prompt` (str) | `_llamar_modelo(prompt)` | ✅ |
| `motor_ia_v2` → `Mx_02` | config del control | `construir_prompt_final()` | ✅ |
| `motor_ia` → `generador_word` | `evaluaciones_por_ambito`, `scores_por_ambito`, `score_global` | idem | ✅ |

> ⚠️ **Dos rutas de prompt distintas** (no es un bug, es el diseño actual):
> · **Pipeline 2 (ámbitos)** construye el prompt *inline* en `motor_ia.py:531` — **no pasa por Mx_02**.
> · **Pipeline 1 (controles)** sí usa `Mx_02.construir_prompt_final()` (`motor_ia_v2.py:220`).
> Si editas los prompts de la evaluación por ámbitos, hazlo en `motor_ia.py`, no en `Mx_02`.

---

## 6. Comandos disponibles

### 6.1 Tabla de flags (verificada contra el `argparse` de `agente.py`)

| Flag | Tipo | Default | Qué hace |
|---|---|---|---|
| `--titulo` | str | `None` | Nombre del modelo (obligatorio en validación y controles) |
| `--tier` | str | `None` | `1`\|`2`\|`3`\|`4` — filtra actividades del estándar |
| `--excel` | str | `None` | Ruta al Excel de controles |
| `--control` | flag | `False` | Activa el pipeline por control |
| `--prdc` | flag | `False` | Producción: Word + firma obligatoria, sin bucle de feedback. **El caché sigue activo** |
| `--datasets` | str | `inputs/calidad_datos/datasets` | Carpeta de datasets |
| `--raiz-evidencia` | str | raíz del proyecto | Raíz alternativa que contiene `inputs/` — un modelo por raíz |
| `--convertir-excel` | str | `None` | Carpeta con `.xlsx`/`.xlsm` |
| `--controles-a-notebook` | str | `None` | Documento de controles |
| `--listar-motores` | flag | `False` | Catálogo de pruebas de datos y sale |
| `--sin-llm` | flag | `False` | No usa IA (solo estructura) |
| `--sin-validacion` | flag | `False` | Omite auto-validación Excel↔Notebook |
| `--estadisticafeedback` | flag | `False` | Precisión histórica |
| `--cache-stats` / `--limpiar-cache` / `--no-cache` | flag | `False` | Gestión de caché |
| **`--explicar-modelo`** | str | `None` | Genera la explicación consolidada de un modelo (§6.4) |
| `--dry-run` | flag | `False` | Para `--explicar-modelo` y `--revisar-codigo`: inventario y coste, sin llamar a la IA |
| `--excluir` | str | `None` | Para `--explicar-modelo`: ficheros a omitir, separados por coma |
| `--solo-coincidentes` | flag | `False` | Para `--explicar-modelo`: usar solo ficheros cuyo nombre contiene el modelo |
| **`--revisar-codigo`** | flag | `False` | Revisa el código de `inputs/implementacion/` (`.py`, `.ipynb`, `.sql`, `.R`) contra el manual: una llamada por módulo, hallazgos con `fichero:línea` |
| **`--perfilar-datasets`** | flag | `False` | Añade el ESQUEMA de los datasets a la evidencia (sin volcar filas) |
| `--validador` / `--cargo` | str | `None` | Validador responsable. **Obligatorios con `--prdc`** |
| `--verificar-cadena` | str | `None` | Verifica la cadena de custodia de un modelo y sale (coste 0) |
| `--verificar-evidencia` | str | `None` | Comprueba si los documentos citados por un informe siguen intactos (coste 0) |
| `--historial-validaciones` | flag | `False` | Quién firmó qué y cuándo (coste 0) |
| `--verificar-conexion-azure` | flag | `False` | Prueba de humo del proveedor activo: credencial, modelo real y perfil de chunking |

> **28 flags en total.** Referencia exhaustiva —precedencia de modos, matriz de
> compatibilidad, códigos de salida y flags que se ignoran en silencio— en
> **`FLAGS.md`**. Catálogo funcional en **`FUNCIONALIDADES.md`**.

### 6.4 Explicador de modelos ⭐

```bash
python agente.py --explicar-modelo LaR --dry-run     # inventario + coste, gratis
python agente.py --explicar-modelo LaR               # genera el documento
```

Produce `outputs/<fecha>/explicacion_del_modelo_<NOMBRE>.md`: un documento de
9 secciones que permite entender un modelo **sin leer el código**, consolidando
las cuatro fuentes de `inputs/`.

**Es un flujo genérico**: no sabe nada de ningún modelo concreto. Para documentar
otro, deja su evidencia en `inputs/` y cambia el nombre del flag.

| Fuente | Aporta |
|---|---|
| `inputs/documentacion/modelamiento` | supuestos, fórmulas, marco teórico, normativa |
| `inputs/documentacion/seguimiento` | backtesting, tests, umbrales, escalamiento |
| `inputs/implementacion` | funciones, stack, orquestación |
| `inputs/calidad_datos` | fuentes, controles, tolerancias, transformaciones |

**Cómo evita inventar** — el riesgo de un documento así no es que falle, es que
salga plausible y esté a medias:

1. **Inventario dentro del documento.** La cabecera lista qué fichero aportó
   qué, con su tamaño. Toda afirmación debe poder rastrearse ahí.
2. **Vacíos declarados.** Una fuente sin evidencia se marca `⚠️ VACÍA` y el
   prompt obliga a escribir «Sin evidencia en fuentes» en vez de rellenar con
   conocimiento general del dominio.
3. **Discrepancias sin reconciliar.** Si el manual dice una cosa y la
   implementación otra, se señalan ambas — no se elige una en silencio.
4. **Verificación de completitud.** Tras generar, se comprueba que estén las
   9 secciones y que el texto no acabe a media frase. Si algo falta, se avisa
   en vez de entregar un documento truncado como si estuviera completo.

> **Se genera en 3 llamadas**, una por bloque de secciones (1-3, 4-5, 6-9). En
> una sola llamada el modelo agota `max_tokens` a mitad de la sección 4 y el
> documento sale cortado a media frase — comprobado. Trocearlo también permite
> documentar modelos con mucha más evidencia.

**Coste** (evidencia de LaR, ~20 KB): ≈ **$0,03** de entrada + salida, en
3 llamadas. Los manuales largos pasan por `ChunkerService`, así que su resumen
se cachea y las regeneraciones no lo vuelven a pagar (§3.4.1).

> ⚠️ Si en `inputs/` hay fixtures de prueba (p. ej.
> `Manual_Metodologico_LaR_completo.pdf`, el PDF sintético de 305 págs que usan
> los tests de cobertura), **exclúyelos**: son texto generado y contaminarían el
> documento con contenido que no describe el modelo real.
> `--excluir Manual_Metodologico_LaR_completo.pdf`

### 6.2 Cheatsheet

```bash
# ── Verificación (coste 0) ──────────────────────────────────────────
python validate_project.py                    # 13 bloques → 88/88 PASS
python validate_project.py --strict           # exit 1 si hay FAIL (CI)
python agente.py --listar-motores             # 8 pruebas de calidad
python test_api_key.py

# ── Validación de modelo ────────────────────────────────────────────
python agente.py --titulo "ModeloLaR" --tier 1           # pre-prod + feedback
python agente.py --titulo "ModeloLaR" --tier 1 --prdc    # producción + Word
python agente.py --titulo "ModeloLaR" --tier 1 < /dev/null   # desatendido, exit 0

# ── Controles de calidad de datos ───────────────────────────────────
python agente.py --titulo "ModeloLaR" --tier 1 \
    --excel inputs/calidad_datos/ControlesData.xlsx --control

# ── Excel → Notebook ────────────────────────────────────────────────
python agente.py --convertir-excel inputs/excel_procesos

# ── Documento de controles → Notebook + brechas ─────────────────────
python agente.py --controles-a-notebook inputs/calidad_datos/manual_controles_datos.md \
                 --excel inputs/calidad_datos/ControlesData.xlsx

# ── Feedback y caché ────────────────────────────────────────────────
python agente.py --estadisticafeedback
python agente.py --cache-stats
python agente.py --limpiar-cache
```

### 6.3 `--prdc` vs sin `--prdc`

| Línea | Efecto |
|---|---|
| `agente.py:117` | `es_preprdc = not args.prdc` |
| `agente.py:118` | Caché activo solo si NO es `--prdc` |
| `agente.py:387` | `modo_preprdc` cambia el prompt |
| `agente.py:528` | Genera Word **solo si** `--prdc` |
| `agente.py:574` | Bucle de feedback **solo si NO** `--prdc` |

---

## 7. Módulos — referencia

### 7.1 `modulos/` — lógica de negocio

| Archivo | Líneas | Responsabilidad | Funciones clave | Depende de |
|---|---:|---|---|---|
| `motor_ia.py` | 1590 | Evaluación por ámbito, scores, anti-sesgo, RAG, contrato | `evaluar_actividad`, `evaluar_ambito_completo`, `calcular_score_global`, `_extraer_json`, `_validar_contrato_evaluacion` | `config`, `Mx_00/01/03/04`, `feedback*`, `src.rag` |
| `excel_a_notebook.py` | 1211 | Excel→notebook: VBA, refs externas, auto-validación | `generar_notebook_de_carpeta`, `analizar_libro`, `auto_validar` | `config` |
| `generador_word.py` | 1149 | Informe `.docx` | `generar_word_informe`, `_tabla_scores` | `config`, `Mx_00` |
| `motor_ia_v2.py` | 832 | Pipeline por control (CDD) | `orquestar_pipeline_virf`, `evaluar_todos_controles` | `config`, `Mx_00..04`, `control_evaluacion_data` |
| `controles_a_notebook.py` | 790 | Documento→notebook + brechas | `generar_notebook_controles`, `analizar_brechas`, `_score_par` | `config`, `motores_datos` |
| `control_evaluacion_data.py` | 810 | Búsqueda de evidencias, score de controles | `BuscadorEvidencias`, `CalculadorScore` | — |
| `motores_datos.py` | 609 | Catálogo de 8 pruebas de calidad | `ejecutar_motor`, `cargar_datasets`, `REGISTRO_MOTORES` | pandas/numpy |
| `document_cache.py` | 536 | Caché SHA-256, atómico, con lock | `DocumentCache`, `_lock_archivo`, `_escribir_json_atomico` | — |
| `feedback_mejorado.py` | 331 | Patrones de error, ajuste (≥3 muestras) | `analizar_patron_errores`, `ajustar_puntaje_por_feedback` | — |
| `chunker.py` | 340 | Segmentación adaptativa/jerárquica | `ChunkerService.procesar_doc`, `_dividir_en_chunks` | — |
| `feedback.py` | 315 | Bucle interactivo, manejo de EOF | `bucle_feedback_consola`, `_leer` | — |
| `generador_estadistica_feedback.py` | 252 | Informe Excel de precisión | `generar_informe_estadistica` | `config`, `feedback` |

### 7.2 `motor/` — infraestructura

| Archivo | Líneas | Responsabilidad | En uso real |
|---|---:|---|---|
| `Mx_01_LecturaEvidencias.py` | 811 | Lectores PDF/DOCX/PPTX/XLSX/PY/JSON/IPYNB/SQL + OCR | ✅ completo |
| `Mx_03_LlamarIA.py` | 460 | Llamada API, parseo JSON, cliente cacheado | ⚠️ solo `_llamar_modelo`, `_parsear_json`, `_obtener_cliente` |
| `Mx_04_MotorControlesData.py` | 448 | Motor de controles + 15 patrones metodológicos | ✅ |
| `Mx_02_EstructuraPrompt.py` | 386 | Construcción de prompts | ⚠️ solo `construir_prompt_final` |
| `Mx_00_CargaRutas.py` | 333 | Rutas, `ROL_AGENTE`, `AMBITO_A_INPUTS`, patrones | ✅ |

### 7.3 `src/rag/` — RAG activo ⭐

Usado por `motor_ia.py:141` (`from src.rag import get_retriever`).

**Inferencia de dominio** (`src/rag/__init__.py:20`):

| Dominio | Palabras clave en `--titulo` |
|---|---|
| `LaR` | lar, liquidity, liquidez, lic, hqla |
| `VaR` | var, value at risk, frtb, market risk |
| `conductuales` | conductual, prepago, retiro, nmd, comportamiento |
| `shared` | *(cualquier otro)* |

**Persistencia** (`base_indexer.py:42`): `data/vectordb/<dominio>/` en local · `/dbfs/FileStore/virf/vectordb/` en Databricks.
**Degradación elegante** (`motor_ia.py:145`): sin ChromaDB, `_RAG_DISPONIBLE=False` y la evaluación continúa.

### 7.4 `agent/` — plataforma v28

65 archivos, 10.297 líneas. **No participa en el pipeline principal.** Agente conversacional con 8 skills MRM. Entrypoint: `virf_agent_v28/virf_agent_v28/virf_agent_v28.py` (requiere `PYTHONPATH=.`).

> `agent/rag/` (789 líneas) está **muerto**: el RAG real es `src/rag/`.

---

## 8. Limitaciones y código pendiente

### 8.1 TODOs reales en el código

| Ubicación | Marcador |
|---|---|
| `agent/context_engineering/filtering.py:81` | `TODO (v2): filtrado semántico por relevancia a query` |
| `agent/context_engineering/prioritization.py:110` | `TODO (v2): ordenar por get_priority_score()` |

Los demás 61 marcadores (`[D3-FIX]`, `[PERF-FIX]`, `[COBERTURA-FIX]`…) documentan decisiones aplicadas.

### 8.2 Limitaciones funcionales

**Excel → Notebook:**
- VBA con eventos (`Workbook_Open`, `Worksheet_Change`): se extrae el código, no la mecánica de disparo
- VBA con ADODB/DAO/WinAPI/Shell: traducción sintáctica, no equivalencia funcional
- Refs a libros fuera de la carpeta o rutas UNC → TODO en Anexo C del notebook
- Arrays dinámicos (`FILTER`, `UNIQUE`, `SORT`, `LAMBDA`, `LET`) y matriciales `{=...}` → no traducidos
- Formato `.xls` antiguo → no soportado

**Validación:**
- PDFs escaneados requieren Tesseract + Poppler (binarios, no solo pip)
- Anti-sesgo requiere ≥15 feedbacks del ámbito; ajuste de puntaje ≥3 muestras
- Documentos > 336 páginas entran en modo adaptativo: menos segmentos pero más grandes (resumen menos granular, cobertura sigue siendo 100%)

**Análisis de brechas:**
- Emparejamiento heurístico y conservador: ante la duda no empareja, para que el control salga como brecha y lo revise un humano

### 8.3 Código sin conectar (conservado con aviso)

En `motor/Mx_02` y `motor/Mx_03` hay un subgrafo cerrado sin punto de entrada, marcado con bloques explicativos en el propio código:

`Mx_02.prompt_aprender_estilo`, `estilo_por_defecto`, `prompt_generar_replica_virf`, `prompt_evaluar_dimension`, `prompt_sintesis` → llamados solo por `Mx_03.aprender_estilo`, `generar_replica_virf`, `evaluar_dimension`, `generar_sintesis`, que **no tienen llamadores externos**. También `Mx_03.llamar_ia_json` y `Mx_03._validar_contrato`.

Corresponden al diseño v12-v17 (evaluación por dimensión). Ver [§12](#12-registro-de-limpieza-changelog-de-auditoría).

---

## 9. Preguntas abiertas

### 9.1 Evaluación paralela — ¿se usa?

`motor_ia.py:920` define `evaluar_ambito_paralelo()` y `:982` `evaluar_todos_ambitos_paralelo()`, y lee `VIRF_WORKERS` / `VIRF_AMBITO_WORKERS`. El flujo trazado en `agente.py` usa la ruta **secuencial**.
**❓ ¿Código experimental, o hay un activador que no encontré?**

### 9.2 `agent/` (v28) — ¿en producción?

10.297 líneas (40% del código restante) sin participar en ningún pipeline. Su entrypoint arranca.
**❓ ¿Línea de trabajo activa o aparcada?** De la respuesta depende documentarlo a fondo o marcarlo legacy.

### 9.3 `motor/main.ipynb`

578 líneas no analizadas como código ejecutable.
**❓ ¿Exploración obsoleta o parte del flujo?**

### 9.4 Estructura de `Estandares_VIRF.xlsx`

Encabezados en la **fila 2** (no la 1) y columna A vacía. `leer_estandares_virf` lo maneja, pero es frágil ante reordenamientos.
**❓ ¿Formato fijo o puede cambiar?**

### 9.5 PDFs reales para validar el chunking

El proyecto tiene **0 PDFs**; el input más grande son 2.967 chars. El chunking se validó con documentos **sintéticos** de 300/500/1.000 páginas.
**❓ ¿Puedes aportar un PDF real de 300+ páginas para confirmar el rendimiento con OCR y estructura real?**

---

## 10. Arquitectura del proyecto

### 10.1 Diagrama de capas

```
┌──────────────────────────────────────────────────────────────────────────┐
│  CAPA 1 · CLI / ORQUESTACIÓN                                             │
│  ────────────────────────────────────────────────────────────────────    │
│  agente.py            argparse (16 flags) · decide pipeline · JSON final │
│  validate_project.py  13 bloques de verificación · coste 0               │
└───────────────────────────────┬──────────────────────────────────────────┘
                                ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  CAPA 2 · NEGOCIO           modulos/                                     │
│  ────────────────────────────────────────────────────────────────────    │
│  motor_ia.py             evaluación por ámbito · scores · anti-sesgo     │
│  motor_ia_v2.py          evaluación por control (CDD)                    │
│  motores_datos.py        8 pruebas de calidad de datos                   │
│  chunker.py              segmentación adaptativa / jerárquica            │
│  document_cache.py       caché SHA-256 · atómico · lock entre procesos    │
│  feedback.py             correcciones del validador                      │
│  feedback_mejorado.py    patrones de error · ajuste con guardias         │
│  generador_word.py       informe .docx                                   │
│  excel_a_notebook.py     Excel → .ipynb verificado                       │
│  controles_a_notebook.py documento → .ipynb + brechas                    │
│  control_evaluacion_data.py  búsqueda de evidencias · score de controles │
└───────────────────────────────┬──────────────────────────────────────────┘
                                ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  CAPA 3 · INFRAESTRUCTURA   motor/ (Mx_*)          src/rag/              │
│  ────────────────────────────────────────────────────────────────────    │
│  Mx_00_CargaRutas         rutas · ROL_AGENTE · 15 patrones               │
│  Mx_01_LecturaEvidencias  lectores PDF/DOCX/PPTX/XLSX/PY/… + OCR         │
│  Mx_02_EstructuraPrompt   construir_prompt_final (Pipeline 1)            │
│  Mx_03_LlamarIA           _llamar_modelo · _parsear_json · cliente cache │
│  Mx_04_MotorControlesData motor de controles · detección de patrones     │
│  src/rag/                 ChromaDB por dominio (LaR/VaR/conduct./shared) │
└───────────────────────────────┬──────────────────────────────────────────┘
                                ▼
┌──────────────────────────────────────────────────────────────────────────┐
│  CAPA 4 · CONFIGURACIÓN                                                  │
│  config/dominio.py  AMBITO_PESOS · ESCALA_PUNTAJE · SCORE_SEMAFORO      │
│              factory de clientes IA · guardia anti-fuga de credenciales  │
│  .env        36 variables de entorno                                     │
└──────────────────────────────────────────────────────────────────────────┘
```

### 10.2 Flujo de datos: de `inputs/` a `outputs/`

```
inputs/documentacion/modelamiento/manual.docx
   │
   │  Mx_01._leer_docx()          párrafos + tablas → str
   ▼
{nombre, tipo:"DOCX", contenido:str, chars_totales:int, truncado:bool}
   │
   │  document_cache.get()        hash SHA-256 del binario → hit/miss
   ▼
mismo dict (servido de caché o leído fresco)
   │
   │  chunker.procesar_doc()      si chars > 12.000:
   │                                · divide en segmentos solapados
   │                                · resume cada uno con la IA
   │                                · modo directo / adaptativo / jerárquico
   ▼
+ {cobertura_pct: float, n_chunks: int, modo_cobertura: str, fue_resumido: bool}
   │
   │  agente.py                   agrupa por ámbito (AMBITO_A_INPUTS)
   │                              concatena hasta VIRF_MAX_CTX
   │                              promedia cobertura_pct → cobertura_ambito
   ▼
contexto: str  +  cobertura_ambito: float
   │
   │  motor_ia.evaluar_actividad()   compone el prompt con 8 bloques:
   │     instrucción de ámbito · contexto · cobertura REAL · RAG ·
   │     preguntas guía · memoria intra-ámbito · feedback · anti-sesgo
   ▼
prompt: str
   │
   │  Mx_03._llamar_modelo()      cliente cacheado → API del proveedor activo
   ▼
respuesta cruda: str
   │
   │  _extraer_json()             tolera fences y texto alrededor
   │  _validar_contrato_evaluacion()   campos, tipos, rango 1-5
   ▼
{puntaje:1-5, concepto, observacion, evidencia_encontrada,
 preguntas_pendientes, recomendacion, evaluacion_valida:true}
   │
   │  ajustar_puntaje_por_feedback()   si ≥3 muestras similares
   │  calcular_score_ambito()          excluye puntaje=None
   │  calcular_score_global()          ponderado por AMBITO_PESOS
   ▼
score_global: float  +  semaforo: dict
   │
   ├─→ agente.py:695   json.dump()   → outputs/YYYY-MM-DD/resultados_<modelo>_<fecha>.json
   └─→ generador_word.py:914         → outputs/YYYY-MM-DD/VIRF_Informe_<modelo>_<fecha>.docx
```

### 10.3 Los dos pipelines y dónde convergen

```
                    ┌─────────────────────────────────┐
                    │        agente.py:main()          │
                    └────────────┬────────────────────┘
                                 │
              ┌──────────────────┴──────────────────┐
              ▼                                     ▼
   ╔══════════════════════╗              ╔══════════════════════╗
   ║  PIPELINE 2          ║              ║  PIPELINE 1          ║
   ║  Ámbitos (default)   ║              ║  Controles (--control)║
   ╠══════════════════════╣              ╠══════════════════════╣
   ║ Estandares_VIRF.xlsx ║              ║ ControlesData.xlsx   ║
   ║ 6 ámbitos × N activ. ║              ║ N controles          ║
   ║                      ║              ║                      ║
   ║ motor_ia.py          ║              ║ motor_ia_v2.py       ║
   ║  evaluar_actividad() ║              ║  evaluar_control()   ║
   ║                      ║              ║   + motores_datos    ║
   ║ prompt INLINE :531   ║              ║ Mx_02.construir_     ║
   ║ (no usa Mx_02)       ║              ║   prompt_final()     ║
   ╚══════════╤═══════════╝              ╚══════════╤═══════════╝
              │                                     │
              └──────────────┬──────────────────────┘
                             ▼
              ╔══════════════════════════════════╗
              ║  CONVERGENCIA                    ║
              ║  Mx_03._llamar_modelo()          ║
              ║  config.get_cliente_ia() cacheado║
              ╚══════════════╤═══════════════════╝
                             │
              ┌──────────────┴──────────────────┐
              ▼                                 ▼
   Puntaje 1-5 por actividad         Hallazgos con criticidad
   score_global ponderado            score inverso a hallazgos
              │                                 │
              └──────────────┬──────────────────┘
                             ▼
              outputs/YYYY-MM-DD/  (JSON + Word)
```

**Segunda convergencia:** si existe `ControlesData.xlsx`, el Pipeline 2 invoca al 1 y **fusiona** sus controles en el ámbito *Calidad de datos* (`agente.py:~515`, `[D7-FIX]`), calibrando el puntaje por tasa de error:

| Estado del control | Tasa de error | Puntaje |
|---|---|---:|
| `OK` | — | 5 |
| `ADVERTENCIA`/`ALERTA` | < 0.5% | 4 |
| `ADVERTENCIA`/`ALERTA` | 0.5–2% | 3 |
| `ADVERTENCIA`/`ALERTA` | 2–10% | 2 |
| `ADVERTENCIA`/`ALERTA` | > 10% | 1 |
| `ERROR` | — | 1 |

### 10.4 Decisiones arquitectónicas

#### Factory de clientes IA (`config/ia.py`)

**Problema:** el proyecto debía soportar Anthropic y Azure OpenAI sin que la lógica de negocio supiera cuál está activo.
**Solución:** clase abstracta `ClienteIA` + diccionario `FABRICAS` + `get_cliente_ia()` como único punto de acceso. Los 30+ sitios que llaman a la IA usan `generar_mensaje(prompt, max_tokens)` sin conocer el proveedor.
**Beneficio adicional:** al ser un punto único, añadir el **cacheo por proceso** (`[PERF-FIX]`) eliminó el 50% de las llamadas API con un cambio en un solo archivo.

#### Chunker por inyección de dependencias (`chunker.py:81`)

**Problema:** en v18 el chunker llamaba internamente a `get_cliente_ia()`, mezclando la capa de lectura con la de infraestructura IA. Imposible testear sin API real.
**Solución:** `ChunkerService(cliente_ia=...)` recibe el cliente ya construido. `agente.py` lo inyecta.
**Beneficio:** el test de cobertura de `validate_project.py` usa un cliente simulado y verifica el chunking de 1.000 páginas **sin gastar un solo request**.

#### Caché con hash SHA-256 del binario (`document_cache.py:274`)

**Problema:** re-leer PDFs y DOCX en cada iteración es lento; usar la fecha de modificación da falsos negativos (copiar un archivo cambia el mtime pero no el contenido).
**Solución:** la clave es el SHA-256 del **contenido binario**. Mismo contenido → mismo hash → hit, sin importar nombre, ruta ni fecha.
**Refuerzos de la auditoría:** escritura atómica (`tmp` + `os.replace`), lock cooperativo entre procesos y merge con disco. Verificado con 12 escritores concurrentes → 12/12 entradas conservadas.

#### D3-FIX: anti-alucinación (`agente.py:443`)

**Problema:** un LLM al que se le pide evaluar sin información **inventa hallazgos plausibles**. En validación de modelos eso es crítico: un auditor junior podría tomarlos por verificados.
**Solución:** si un ámbito no tiene documentos, **no se llama al LLM**. Se marca `puntaje=None`, `sin_evidencia=true` y se genera una pregunta explícita al modelador. El ámbito se **excluye del score global** (no cuenta como cero, que sería inventar un juicio).
**Extensión de la auditoría:** el mismo principio se aplicó a los fallos técnicos (`[CONTRATO-FIX]`): antes un JSON malformado producía `puntaje=2` inventado; ahora produce `evaluacion_valida=false` y queda fuera del score, con `dictamen_confiable=false` en el JSON.

### 10.5 Decisión: cobertura total en documentos grandes

**Problema detectado en esta auditoría.** Con `MAX_CHUNKS=25` y segmentos de 12.000 chars, la cobertura máxima era 280.000 chars (~140 páginas). Un manual metodológico real de 300 páginas (~600.000 chars) perdía **el 53% del contenido**: `chunks[:25]` se quedaba con la primera mitad y descartaba la segunda — justo donde suelen estar backtesting, validación de supuestos y conclusiones.

**Solución en tres niveles** (`chunker.py:133-190`):

```
        ¿n_chunks ≤ MAX_CHUNKS (60)?
                │
        SÍ ─────┴───── NO
        │              │
   ┌────▼────┐   ¿tamaño adaptativo ≤ 40.000?
   │ DIRECTO │         │
   │  100%   │    SÍ ──┴── NO
   └─────────┘    │        │
            ┌─────▼────┐ ┌─▼──────────┐
            │ADAPTATIVO│ │ JERÁRQUICO │
            │  recalcula│ │ 2 niveles: │
            │  el tamaño│ │ resúmenes  │
            │  de chunk │ │ de resúmenes│
            │   100%    │ │    100%    │
            └──────────┘ └────────────┘
```

**Resultados verificados** (`validate_project.py` §11):

| Documento | Segmentos | Modo | Cobertura |
|---|---:|---|---:|
| 300 págs (600 k) | 54 | directo | **100%** |
| 500 págs (1 M) | 60 | adaptativo | **100%** |
| 1000 págs (2 M) | 60 | adaptativo | **100%** |

**Y la cobertura ahora llega al agente.** Antes, `cobertura_pct` se calculaba en `chunker.py` y moría ahí: `agente.py` solo leía `contenido` y `nombre`. El prompt afirmaba *"cobertura completa (100%)"* siempre que detectaba chunking — aunque el documento estuviera al 46%. Ahora el valor viaja `chunker → agente.py:445 → evaluar_ambito_completo → evaluar_actividad → prompt`, y el bloque de cobertura dice la verdad:

```
⚠️  COBERTURA DOCUMENTAL PARCIAL: solo se pudo leer el 46.7% del contenido…
    Si no encuentras evidencia de un requisito, NO penalices con 1
    automáticamente: podría estar en la parte no leída.
```

---

## 11. Salidas del sistema — detalladas

### 11.1 Dónde se guarda cada cosa

| Artefacto | Ruta | Patrón de nombre | Generado en |
|---|---|---|---|
| JSON de resultados | `outputs/YYYY-MM-DD/` | `resultados_{titulo}_{fecha}.json` | `agente.py:695` |
| Informe Word | `outputs/YYYY-MM-DD/` | `VIRF_Informe_{titulo}_{DDMMYYYY}.docx` | `generador_word.py:914` |
| Informe CDD Word | `outputs/YYYY-MM-DD/` | `VIRF_Informe_CDD_{titulo}_{fecha}.docx` | `motor_ia_v2.py` |
| Notebook de Excel | `outputs/YYYY-MM-DD/notebooks/` | `notebook_{libro}.ipynb` | `excel_a_notebook.py` |
| Validación de notebook | `outputs/YYYY-MM-DD/notebooks/` | `reporte_validacion_{libro}.json` | `excel_a_notebook.py` |
| Notebook de controles | `outputs/YYYY-MM-DD/controles/` | `controles_{documento}.ipynb` | `controles_a_notebook.py` |
| Brechas de controles | `outputs/YYYY-MM-DD/controles/` | `brechas_{documento}.json` | `controles_a_notebook.py` |
| Resultados del notebook | `outputs/YYYY-MM-DD/controles/` | `resultados_controles.json` | notebook generado |
| Estadísticas de feedback | `outputs/` | `estadistica_feedback_*.xlsx` | `generador_estadistica_feedback.py` |

> **Convención:** todo cuelga de `outputs/YYYY-MM-DD/`. Verificado por `validate_project.py` §12.

### 11.2 JSON de resultados — estructura completa

`outputs/2026-07-26/resultados_PostAuditoria_2026-07-26.json`

```json
{
  "modelo": "PostAuditoria",
  "tier": "1",
  "fecha": "2026-07-26",

  "agente": {
    "agente_version":   "27.1",
    // Los dos campos siguientes reflejan el proveedor y el modelo REALMENTE
    // usados en esa corrida: son un ejemplo, no valores fijos. Con
    // IA_PROVEEDOR=azure_openai saldría "azure_openai" y su deployment.
    "modelo_ia":        "claude-haiku-4-5-20251001",
    "proveedor_ia":     "anthropic",
    "pesos_ambito": {
      "Documentación": 0.15, "Calidad de datos": 0.20, "Metodología": 0.30,
      "Gobierno": 0.12, "Implementación": 0.15,
      "Uso e integración a la gestión": 0.08
    },
    "cache_activo":      false,
    "huella_ejecucion":  "b664d203297e",
    "huella_completa":   "b664d203297e8a1f…",
    "documentos_huella": {
      "calidad_datos/perfil_datos_LaR.md":                {"sha256":"0fda10ebda68","chars":1245},
      "doc_modelamiento/manual_metodologico_LaR.md":      {"sha256":"b2034a649b95","chars":1409},
      "doc_seguimiento/informe_seguimiento_Q2_2026.md":   {"sha256":"7789b0078f7f","chars":1051},
      "implementacion/implementacion_LaR.md":             {"sha256":"c3dd5893506d","chars":1025}
    },
    "n_documentos":    6,
    "chars_evidencia": 6319,
    "generado_utc":    "2026-07-26T18:44:12Z",
    "prompt_hash":     "b664d203297e"
  },

  "integridad": {
    "actividades_evaluadas_ok":      19,
    "actividades_sin_evidencia":      0,
    "actividades_con_fallo_tecnico":  0,
    "detalle_fallos":                [],
    "dictamen_confiable":          true
  },

  "score_global": 2.67,
  "semaforo": {"label": "CON OBSERVACIONES", "color": "FFCC00"},

  "scores_por_ambito": {
    "Documentación": 3.00, "Calidad de datos": 2.00, "Metodología": 2.80,
    "Gobierno": 1.00, "Implementación": 2.00,
    "Uso e integración a la gestión": 4.00
  },

  "resultados_por_ambito": {
    "Documentación": [
      {
        "actividad":             "Verifica la existencia de control de cambios/versiones",
        "control":               "Verificar la existencia, suficiencia y claridad del Manual Metodológico",
        "puntaje":               3,
        "evaluacion_valida":     true,
        "concepto":              "Evalúa si el manual mantiene control de versiones…",
        "observacion":           "El manual documenta la metodología pero no evidencia versionado…",
        "evidencia_encontrada":  "manual_metodologico_LaR.md, sección 5 'Governance'",
        "preguntas_pendientes":  ["¿Existe control de versiones formal del manual?"],
        "recomendacion":         "Adoptar versionado semántico con aprobación del owner.",
        "cobertura_contexto":    1.0,
        "cobertura_documental":  100.0,
        "ajuste_sesgo":          "Sin feedback previo similar",
        "rag_dominio":           "LaR",
        "rag_chunks":            2
      }
    ]
  },

  "controles_calidad_datos": {}
}
```

### 11.3 Diccionario de campos

| Campo | Variable que lo genera | Significado |
|---|---|---|
| `agente.huella_ejecucion` | `agente.py:_huella_ejecucion[:12]` | SHA-256 de versión+modelo+tier+pesos+escala+hash de cada documento. **Reproducible**: misma entrada → misma huella |
| `agente.documentos_huella` | `agente.py:_huella_documentos()` | SHA-256 y tamaño de cada documento usado. Prueba ante un auditor de qué evidencia se leyó |
| `agente.chars_evidencia` | suma de `chars` | Volumen total de evidencia procesada |
| `integridad.dictamen_confiable` | `agente.py:_integridad` | ⭐ `false` si hubo fallos técnicos. **No emitir dictamen si es `false`** |
| `integridad.detalle_fallos` | lista de `error_evaluacion` | Qué actividad falló y por qué |
| `score_global` | `motor_ia.calcular_score_global()` | Promedio ponderado; excluye ámbitos sin evidencia del numerador **y** denominador |
| `puntaje` | `motor_ia.evaluar_actividad()` | 1-5, o `null` si no evaluable |
| `evaluacion_valida` | `[CONTRATO-FIX]` | `false` → excluida del score |
| `cobertura_contexto` | `ctx_incluido / ctx_total` | Fracción del contexto que cupo en el prompt (0-1) |
| `cobertura_documental` | `chunker.cobertura_pct` | ⭐ % del archivo original realmente leído (0-100) |
| `ajuste_sesgo` | `ajustar_puntaje_por_feedback()` | Si el feedback histórico modificó el puntaje |
| `rag_dominio` / `rag_chunks` | `_enriquecer_con_rag()` | Dominio consultado y fragmentos inyectados |

### 11.4 Informe Word — estructura

Generado por `modulos/generador_word.py:generar_word_informe()` (`:914`).

| Sección | Función que la construye | Contenido |
|---|---|---|
| Portada | `:900-960` | Título, modelo, tier, fecha |
| **1. Resumen Ejecutivo** | `_add_heading(doc,"1. RESUMEN EJECUTIVO"):964` | Narrativa generada por `generar_resumen_ejecutivo()` |
| Tabla de scores | `_tabla_scores():307` | Ámbito · Peso · Score · Dictamen, con celdas coloreadas por semáforo |
| **2. Detalle de Actividades** | `:1000` | Por ámbito y actividad: concepto, observación, evidencia, preguntas, recomendación |
| Encabezado de ámbito | `_add_ambito_heading():236` | Nombre + puntaje con color |
| Bloque de campo | `_add_field_block():251` | Etiqueta + valor formateado |
| Línea de resultado | `_add_result_line():276` | Estado según `_status_resultado():81` |
| **3. Escala de Evaluación** | `:1107` | Leyenda 1-5 con colores |

**Colores** (`config/dominio.py:ESCALA_PUNTAJE` y `SCORE_SEMAFORO`, aplicados por `_score_color_hex():55`):

| Puntaje | Etiqueta | Hex |
|---:|---|---|
| 5 | Cumple plenamente | `00B050` 🟢 |
| 4 | Cumple con observaciones menores | `92D050` 🟢 |
| 3 | Cumple parcialmente | `FFCC00` 🟡 |
| 2 | Cumple parcialmente — obs. críticas | `FF6600` 🟠 |
| 1 | No cumple | `FF0000` 🔴 |
| `null` | **SIN EVIDENCIA** | `CCCCCC` ⚪ |

> Las actividades sin evidencia muestran `—` en la columna de score y `SIN EVIDENCIA` en dictamen (`_label_semaforo():64`), nunca un cero.

### 11.5 Reporte de brechas de controles

`outputs/YYYY-MM-DD/controles/brechas_{documento}.json`

```json
{
  "documento": "manual_controles_datos.md",
  "excel": "ControlesData.xlsx",
  "generado": "2026-07-26T17:05:33",
  "resumen_documento": "Controles de calidad sobre la base data_subset…",
  "metricas": {
    "n_doc": 11, "n_excel": 4, "n_en_ambos": 2,
    "n_solo_doc": 9, "n_solo_excel": 2,
    "cobertura_documento": 0.182, "total_controles_unicos": 13
  },
  "solo_documento": [
    {"id_sugerido":"LAR_03","descripcion":"No deben existir registros duplicados",
     "tipo_motor":"duplicados","criticidad":"ALTA"}
  ],
  "solo_excel": [
    {"id_control":"Control_04","descripcion":"Valida la unicidad de Tasa por Cuenta",
     "tipo_motor":"unicidad"}
  ],
  "en_ambos": [
    {"doc_id":"LAR_01","excel_id":"Control_02","similitud":0.953}
  ]
}
```

| Categoría | Significado | Tipo de hallazgo |
|---|---|---|
| `en_ambos` | Documentado **y** ejecutado | Conforme |
| `solo_documento` | El manual lo promete, nadie lo ejecuta | **Hallazgo de validación** |
| `solo_excel` | Se ejecuta, el manual no lo describe | **Hallazgo de gobierno** |

---

## 12. Registro de limpieza (changelog de auditoría)

**Fecha:** 2026-07-26 · **Validación posterior:** `88/88 PASS · 0 WARN · 0 FAIL · exit 0`

### 12.1 Archivos retirados del árbol activo

Movidos a `archivo/codigo_muerto_2026-07-26/` (no eliminados: se conserva el historial).

| Archivo | Líneas | Razón | Impacto verificado |
|---|---:|---|---|
| `modulos/v13_fixes.py` | 720 | Duplicado de `control_evaluacion_data.py`. Ya causó un fallo real: se corrigió un bug aquí y el pipeline siguió fallando porque el código vivo era el otro | 13/13 módulos importan ✅ |
| `motor/Mx_05_GeneradorWord.py` | 648 | El Word real lo genera `modulos/generador_word.py`. 0 importadores | ✅ |
| `modulos/generador_excel.py` | 516 | 0 importadores | ✅ |
| `modulos/generador_template.py` | 215 | 0 importadores | ✅ |
| `modulos/lector_inputs.py` | 204 | Superado por `Mx_01`. 0 importadores | ✅ |
| `motor/Mx_05_ComparativaDocCodigo.py` | 186 | 0 importadores | ✅ |
| `RESUMEN_CHALLENGER.py` | 375 | Script informativo, 0 importadores | ✅ |
| `RESUMEN_VISUAL.py` | 284 | Script informativo, 0 importadores | ✅ |
| **Total** | **3.148** | | **0 regresiones** |

### 12.1-bis Subsistema `agent/` v28 archivado

Por decisión del responsable (2026-07-26): **aparcado, posible retoma futura**.
Movido a `archivo/agent_v28_aparcado_2026-07-26/`.

| Elemento | Archivos | Líneas |
|---|---:|---:|
| `agent/` (plataforma conversacional v28) | 65 | 10.297 |
| `virf_agent_v28/` (entrypoint) | 1 | 372 |
| `demo_challenger.py` | 1 | 295 |
| 5 × `test_*.py` del v28 | 5 | 970 |
| `verificar_integridad.py` | 1 | 156 |
| **Total** | **73** | **~12.090** |

**Verificación de no-regresión** (línea base capturada ANTES de archivar):

| Subsistema | Antes | Después |
|---|---|---|
| RAG — dominios e inferencia | `['LaR','VaR','conductuales','shared']` | ✅ idéntico |
| RAG — retriever y `query()` | `LaRRetriever`, 0 chunks | ✅ idéntico |
| Motores de datos | 8 pruebas, `unicidad` OK | ✅ idéntico |
| Feedback — historial y estadísticas | 0 registros | ✅ idéntico |
| Word — colores y etiquetas | `FFCC00` / `CCCCCC` / `SIN EVIDENCIA` | ✅ idéntico |
| Chunker | `MAX_CHUNKS=60`, `CHUNK_SIZE=12000` | ✅ idéntico |
| Config — pesos y escala | suma 1.0, escala 1-5 | ✅ idéntico |
| Hash SHA-256 de los 19 módulos del núcleo | — | ✅ **sin cambios** |
| Pipeline `--prdc` | exit 0, 19/19 actividades | ✅ exit 0, 19/19 |
| `validate_project.py --strict` | 88/88 PASS | ✅ 88/88 PASS |

`diff` de los subsistemas: **cero diferencias**. Las variaciones en el número de
hallazgos y el score entre corridas son no-determinismo del LLM, no efecto del
archivado (mismos inputs, mismos hashes de módulo).

**Para retomarlo:**
```bash
mv archivo/agent_v28_aparcado_2026-07-26/agent .
mv archivo/agent_v28_aparcado_2026-07-26/virf_agent_v28 .
PYTHONPATH=. python virf_agent_v28/virf_agent_v28/virf_agent_v28.py
```

### 12.1-ter Bug encontrado al verificar el archivado

Al comparar las corridas detecté que el contexto de *Calidad de datos* variaba
entre ejecuciones (13.341 vs 13.046 chars). La causa **no era el archivado**,
sino un fallo preexistente:

**`inputs/calidad_datos/datasets/` se leía como evidencia documental.**
`data_subset.csv` consumía los 15.000 chars de `MAX_CHARS_DOC` él solo y
`maestro_clientes.csv` otros 4.593 — juntos **21.297 chars de datos crudos**
que expulsaban del contexto al manual metodológico y al perfil de datos.

El Pipeline 1 ya los excluía (`control_evaluacion_data.CARPETAS_EXCLUIDAS`);
el Pipeline 2 no. Corregido en `Mx_01_LecturaEvidencias.py` con
`CARPETAS_NO_EVIDENCIA` y `ARCHIVOS_NO_EVIDENCIA`.

| Ámbito Calidad de datos | Antes | Después |
|---|---:|---:|
| Docs en contexto | 3 de 6 (saturado) | **3 de 3** |
| Chars de evidencia | 26.887 (79% eran CSV) | **5.590** (100% documental) |
| Contexto saturado | ⚠️ sí | ✅ no |

Los datasets siguen disponibles para el motor de datos vía `cargar_datasets()`
— solo dejan de tratarse como documentos que el LLM debe interpretar.

### 12.2 Código comentado dentro de archivos vivos

| Archivo | Acción | Razón |
|---|---|---|
| `motor/Mx_03_LlamarIA.py` | Bloque explicativo antes de las funciones públicas | `aprender_estilo`, `generar_replica_virf`, `evaluar_dimension`, `generar_sintesis`, `llamar_ia_json`, `_validar_contrato` no tienen llamadores externos. Corresponden al diseño v12-v17 (evaluación por dimensión). En uso real: solo `_llamar_modelo`, `_parsear_json`, `_obtener_cliente` |
| `motor/Mx_02_EstructuraPrompt.py` | Bloque explicativo al inicio | Separa lo vivo (`construir_prompt_final`, usado por `motor_ia_v2:220`) de lo muerto (los 5 `prompt_*`). Advierte que el Pipeline 2 construye sus prompts en `motor_ia.py:531`, no aquí |
| 9 scripts auxiliares | Nota `# No forma parte del flujo VIRF activo` | `create_estandares_excel.py`, `demo_challenger.py`, `verificar_integridad.py`, 5 `test_*.py`, `scripts/rebuild_rag_databricks.py` |

### 12.3 Correcciones funcionales

| Componente | Acción | Razón | Verificación |
|---|---|---|---|
| `chunker.py:52` | `MAX_CHUNKS` 25 → **60** | 25 cubría ~140 págs; un manual de 300 perdía el 53% | Cobertura 1 pasada: 672 k chars (~336 págs) |
| `chunker.py:133-190` | **Chunking adaptativo + jerárquico** | `chunks[:max]` truncaba silenciosamente. Ahora recalcula el tamaño o resume en 2 niveles | 300/500/1000 págs → **100%** cobertura |
| `chunker.py:362` | `_dividir_en_chunks(chunk_size=…)` parametrizable | Necesario para el modo adaptativo | ✅ |
| `agente.py:445` | Propaga `cobertura_pct` del chunker | Los metadatos morían en `chunker.py`; `agente.py` solo leía `contenido` y `nombre` | Log por ámbito muestra cobertura real |
| `motor_ia.py:463` | Bloque de cobertura basado en **datos**, no en strings | Antes detectaba chunking con `"Procesado en" in contexto` y afirmaba "100%" aunque fuera 46% | Cadena verificada agente→motor→prompt |
| `motor_ia.py` | `+ cobertura_documental` en el resultado | Distingue cobertura de archivo vs. de prompt | Presente en el JSON |
| `controles_a_notebook.py:519` | Resultados a `outputs/YYYY-MM-DD/controles/` | Escribía `resultados_controles.json` en el CWD (raíz del repo) | `validate_project.py` §12 ✅ |
| `outputs/` | 19 archivos sueltos + `challenger/` reubicados por fecha | Violaban la convención `outputs/YYYY-MM-DD/` | 3 carpetas de fecha, 0 sueltos |
| `validate_project.py` | +3 bloques (§11 cobertura, §12 salidas, §13 código muerto) | Verificar los cambios de esta auditoría | 75 → **88 checks** |
| `requirements.txt` | Instalados `pytesseract` y `openai` | Declarados pero ausentes → 2 WARN | 0 WARN |

### 12.4 Limpieza de artefactos

| Elemento | Acción |
|---|---|
| `cache/` (raíz) | Eliminado — duplicado de `data/cache/` tras unificar `CACHE_DIR` |
| `resultados_controles.json` (raíz) | Eliminado — ahora se genera en `outputs/` |
| `analisis_ast.json` | Eliminado — artefacto temporal de la auditoría |

### 12.6 Auditoría de regresión — 2026-07-26 (segunda pasada)

Verificación completa tras todos los cambios. **Se encontraron 2 regresiones
críticas que las correcciones anteriores no resolvían.**

#### 🔴 R1 — El chunking no llegaba a operar (CRÍTICA)

`Mx_01.leer_archivo()` truncaba a `MAX_CHARS_DOC` (15.000) **antes** de que el
`ChunkerService` viera el documento.

| Manual de 327.360 chars | Antes | Después |
|---|---:|---:|
| Llega al chunker | 15.000 (**4.6%**) | 327.360 (**100%**) |
| Cobertura reportada | "100%" ❌ falsa | 100% ✅ real |
| Pérdida silenciosa | **95.4%** | 0% |

Toda la corrección del chunking adaptativo/jerárquico (§12.3) era inútil: el
documento nunca llegaba entero. Y el prompt afirmaba *"cobertura completa 100%"*
habiendo perdido el 95% del manual.

**Fix:** `Mx_01_LecturaEvidencias.py:298` entrega el texto íntegro cuando el
chunking está activo (`VIRF_CHUNK_ENABLED=1`, default). `MAX_CHARS_DOC` solo
actúa como tope si el chunking se desactiva.
Además `chunker.py` mide la cobertura contra `chars_totales` (tamaño en disco),
no contra lo que recibió — si algo trunca aguas arriba, ahora se nota.

#### 🔴 R2 — Los resúmenes no cabían en el prompt (CRÍTICA)

Resuelto R1, apareció el siguiente eslabón: 30 segmentos producían **118.332
chars** de resúmenes para un `VIRF_MAX_CTX` de 15.000. El prompt los recortaba
con `contexto[:MAX_CTX]` → **se truncaba otra vez, ahora en la capa del prompt**.

El modo jerárquico existía pero se disparaba por el tamaño de **entrada**, no
por el del **resultado**.

**Fix:** `chunker.py:249` activa la consolidación por tamaño de salida y la
aplica de forma **iterativa** hasta caber en `VIRF_PRESUPUESTO_DOC` (60% de
`MAX_CTX`), con tope de `VIRF_MAX_NIVELES` (3) para no entrar en bucle.

> Nota: la primera versión del fix calculaba `n_bloques` desde el tamaño de
> entrada, lo que generaba **más** bloques en vez de menos. Corregido: se
> calcula desde el tamaño de salida deseado.

**Verificado en el pipeline real:**
```
30 segmentos → Nivel 1 → 3 bloques (5.239 chars) — cobertura 100.0%
[Documentación] 4/4 doc(s) en contexto — 8.607 chars — cobertura 100.0%
```

| Documento | Segmentos | Modo | Cobertura | Resumen final | ¿Cabe en 15k? |
|---|---:|---|---:|---:|:--:|
| 50 págs | 9 | jerárquico | 100% | 8.590 | ✅ |
| 160 págs | 29 | jerárquico | 100% | 8.597 | ✅ |
| 300 págs | 54 | jerárquico | 100% | 8.597 | ✅ |
| 500 págs | 60 | jerárquico | 100% | 8.599 | ✅ |

**Coste:** un manual de 300 páginas consume ~57 llamadas API (54 de segmentación
+ 3 de consolidación). Antes eran 2 llamadas… sobre el 4.6% del documento.

#### 🟠 Otros hallazgos corregidos

| # | Hallazgo | Fix |
|---|---|---|
| R3 | `pytest` recolectaba tests desde `archivo/` (código archivado) | `pytest.ini` con `norecursedirs` |
| R4 | 4 artefactos escritos en la raíz de `outputs/` por el v28 al importarse un test archivado | Reubicados; `pytest.ini` evita la reimportación |
| R5 | Carpeta artefacto `src/rag/{VaR,conductuales,shared,LaR}/` (expansión de llaves de bash literal) | Eliminada |
| R6 | `pdf2image` declarado en `requirements.txt` pero no instalado | Instalado |
| R7 | **El proyecto no tenía suite de tests automatizada** | Creada `tests/test_regresion.py` — 66 tests, coste 0 |

#### Suite de regresión creada

`tests/test_regresion.py` — **66 tests**, sin llamadas a la API (clientes simulados).

| Área | Tests | Qué protege |
|---|---:|---|
| Configuración | 5 | Pesos, nombres de ámbito, cacheo del cliente, seguridad de credenciales |
| Lectura | 4 | Filtro por tier, exclusión de datasets y de la rúbrica |
| Chunking | 9 | Cobertura 150-1000 págs, no-truncado en Mx_01, presupuesto de contexto |
| Contrato JSON | 12 | 6 formatos de respuesta, 4 inválidos, no inventar puntajes |
| Scores | 6 | Exclusión de None e inválidas del promedio y del denominador |
| Feedback | 5 | Guardias de muestra mínima, EOF sin TTY |
| Caché | 4 | Atomicidad, purga, 10 escritores concurrentes |
| Motores de datos | 5 | Detección exacta, respeto del UMBRAL, motor inexistente |
| Word | 2 | Score None no revienta |
| Pipeline 1 | 4 | Excel real, NaN, evidencia .md |
| Salidas | 3 | Convención `outputs/YYYY-MM-DD/` |
| Integridad | 4 | Imports, código muerto fuera, patrones, degradación del RAG |

```bash
pytest                    # 66 tests, ~25 s
pytest -k chunking        # solo cobertura de documentos
```

### 12.7 Auditoría de debilidades — 2026-07-27

Cierre de las 5 debilidades que quedaron abiertas tras la auditoría de regresión.

| # | Debilidad | Acción | Evidencia |
|---|---|---|---|
| **D5** | Parser de `Estandares_VIRF.xlsx` frágil | Cabecera detectada **antes** del forward-fill; validación explícita de `ÁMBITO`/`ACTIVIDAD`; aviso visible si falta la columna TIER; descarte de filas espurias | 4 fragilidades demostradas y corregidas · 7 tests · Excel real intacto (15/12/17/11) |
| **D3** | `VIRF_WORKERS` / evaluación paralela | **Eliminada** (354 líneas → `archivo/`). No la llamaba nadie, sacrificaba la memoria intra-ámbito, no propagaba `cobertura_docs` y ante error inventaba `puntaje: 1` | `motor_ia.py` 1546→1192 · 2 tests · `__all__` saneado |
| **D4** | `motor/main.ipynb` sin analizar | **Archivado.** Las 13 celdas son el flujo v12-v17 por dimensión; no arranca (importa `Mx_05_GeneradorWord`, archivado) | Nota de estado con mapa paso→equivalente actual |
| **D1** | Chunking sin validar con PDF real | PDF de **305 páginas** generado con estructura compleja (2 columnas, tablas que cruzan página, headers repetidos, notas) | 400/400 secciones · 7.200/7.200 filas · 0 segmentos vacíos · **cobertura 100%** · 6 tests |
| **D2** | ~57 llamadas por documento | **Caché de resúmenes** por hash de texto + configuración | **$0,899 → $0,000** en re-corridas · 5 tests |

#### Hallazgos que solo aparecieron con el PDF real

1. **Consolidación insuficiente.** Tras 3 niveles el resumen seguía en 19.817
   chars frente a un presupuesto de 9.000. Se añadió una **pasada final
   forzada**. Resultó ser artefacto del doble de prueba (ignoraba `max_tokens`):
   con cliente realista da 8.676 chars y cabe. Cuando el modelo no comprime lo
   suficiente, ahora **avisa** en vez de recortar en silencio.

2. **29% de los segmentos cortan una tabla.** Mitigado por el solapamiento de
   800 chars (el fragmento reaparece en el segmento siguiente). Limitación
   conocida: el chunker corta por longitud, no por estructura.

#### Limitación pendiente

**OCR sin validar.** El PDF de prueba es digital. El fallback
`pytesseract` + `pdf2image` para escaneos requiere los binarios Tesseract y
Poppler instalados en el sistema, y un PDF escaneado real para probarlo.

### 12.5 Estado final

```
                        ANTES        DESPUÉS
Archivos .py             123             42
Líneas .py            28.612        ~13.600
Código muerto activo   3.148              0
agent/ v28 (aparcado)  12.090        archivado
Checks de validación      75             88
Tests automatizados        0             86
FAIL / WARN              0/2            0/0
Cobertura 300 págs      46.7%         100.0%
Evidencia Calidad datos 26.887 ch      5.590 ch (sin CSV)
```

---

## 13. Catálogo completo de archivos `.py`

**115 archivos** · generado por análisis AST del 100% del árbol.

**Leyenda de estado** (calculada desde el grafo real de imports):

| Estado | Significado |
|---|---|
| 🟢 **entrypoint** | Se ejecuta directamente (`python archivo.py`) |
| 🔵 **conectado** | Otro módulo lo importa — participa en algún flujo |
| ⚪ **sin-importar** | Nadie lo importa ni se ejecuta solo → candidato a retirar |
| 📦 **paquete** | `__init__.py` |

**Resumen:** 13 entrypoints · 64 conectados · 15 sin importar · 23 paquetes

---

### 13.1 Raíz — CLI y utilidades

| Archivo | L | Estado | Uso | Funciones clave |
|---|---:|---|---|---|
| **`agente.py`** | 820 | 🟢 entrypoint | ⭐ **Punto de entrada único.** Interpreta 16 flags, orquesta los 4 modos, arma el JSON con trazabilidad e integridad | `main()`, `modo_estadistica_feedback()` |
| **`config/`** | 495 | 🔵 conectado ×9 | Configuración central: pesos, escalas, factory de clientes IA, guardia anti-fuga de credenciales | `get_cliente_ia()`, `class ClienteAnthropicIA`, `class ClienteAzureOpenAIIA`, `reset_cliente_ia()` |
| **`validate_project.py`** | 470 | 🟢 entrypoint | Verificador de integridad: 13 bloques, 88 checks, coste 0 (no llama a la API) | `val_estructura()`, `val_seguridad()`, `val_cobertura_documentos()`, `val_salidas()` |
| `test_api_key.py` | 89 | 🟢 entrypoint | Diagnóstico de credenciales: formato, longitud, conexión real | — |
| `create_estandares_excel.py` | 33 | 🟢 entrypoint | Genera un `Estandares_VIRF.xlsx` de ejemplo. *Auxiliar* | — |
| `verificar_integridad.py` | 156 | 🟢 entrypoint | Verificación de estructura (precursor de `validate_project.py`). *Auxiliar* | — |
| `demo_challenger.py` | 295 | 🟢 entrypoint | Demo interactiva del generador de challenger models (v28). *Auxiliar* | `ejecutar_escenario()`, `mostrar_menu()` |
| `test_cada_carpeta_agent.py` | 296 | 🟢 entrypoint | Prueba cada subsistema de `agent/` incluido el RAG. *Auxiliar* | — |
| `test_virf_agent_completo.py` | 226 | 🟢 entrypoint | Test end-to-end del agente v28. *Auxiliar* | — |
| `test_flujo_completo_con_challenger.py` | 219 | 🟢 entrypoint | Test del flujo validación→informe→challenger. *Auxiliar* | `test_flujo_completo()` |
| `test_challenger_con_rag.py` | 117 | 🟢 entrypoint | Test del challenger con RAG. *Auxiliar* | `main()` |
| `test_chat_simulado.py` | 112 | 🟢 entrypoint | Simulación de sesión de chat v28. *Auxiliar* | — |

> Los marcados *Auxiliar* llevan la nota `# No forma parte del flujo VIRF activo` en su cabecera.

---

### 13.2 `modulos/` — lógica de negocio (12 archivos)

| Archivo | L | Importado por | Uso | Funciones clave |
|---|---:|---:|---|---|
| **`motor_ia.py`** | 1546 | 3 | ⭐ **Corazón del Pipeline 2.** Evalúa cada actividad: compone el prompt (contexto + cobertura + RAG + memoria + anti-sesgo), llama al LLM, valida el contrato y calcula scores | `evaluar_actividad()`, `evaluar_ambito_completo()`, `calcular_score_ambito()`, `calcular_score_global()`, `_extraer_json()`, `_validar_contrato_evaluacion()`, `leer_estandares_virf()`, `cargar_todos_inputs()` |
| **`excel_a_notebook.py`** | 1212 | 1 | Convierte libros Excel a notebooks Python: analiza fórmulas, VBA y refs entre libros; traduce con LLM; **auto-valida** el resultado contra Excel | `generar_notebook_de_carpeta()`, `analizar_libro()`, `extraer_vba()`, `resolver_libros_externos()`, `auto_validar()`, `construir_grafo_libros()` |
| **`generador_word.py`** | 1149 | 2 | Renderiza el informe `.docx`: portada, resumen ejecutivo, tabla de scores con semáforo, detalle por actividad, escala | `generar_word_informe()`, `generar_word_informe_desde_json()` |
| **`motor_ia_v2.py`** | 805 | 2 | ⭐ **Pipeline 1.** Evalúa control por control: busca evidencia, ejecuta el motor de datos, consulta al LLM, calcula estado y score | `orquestar_pipeline_virf()`, `evaluar_todos_controles()`, `evaluar_control()`, `generar_informe_final()` |
| **`controles_a_notebook.py`** | 795 | 1 | Lee un manual de controles en prosa, extrae los controles con LLM, genera notebook ejecutable y **cruza con el Excel** para detectar brechas | `generar_notebook_controles()`, `analizar_brechas()`, `leer_documento()`, `leer_controles_excel()`, `_score_par()` |
| **`control_evaluacion_data.py`** | 711 | 1 | Infraestructura del Pipeline 1: busca evidencias en `inputs/`, chunkea documentos, calcula score inverso a hallazgos | `class BuscadorEvidencias`, `class CalculadorScore`, `class ValidadorInputs`, `class DocumentoChunker`, `class EstadoEvaluacion` |
| **`motores_datos.py`** | 610 | 2 | ⭐ Catálogo auto-descriptivo de **8 pruebas** de calidad de datos + carga de datasets | `ejecutar_motor()`, `motores_disponibles()`, `describir_motores()`, `cargar_datasets()`, `REGISTRO_MOTORES` |
| **`document_cache.py`** | 537 | 2 | Caché de texto extraído por hash SHA-256 del binario. Escritura atómica + lock entre procesos + merge con disco | `class DocumentCache`, `inicializar_cache()`, `get_cache()`, `cerrar_cache()`, `_lock_archivo()`, `_escribir_json_atomico()` |
| **`chunker.py`** | 407 | 2 | Segmenta documentos largos y los resume con IA. Modos: directo / adaptativo / jerárquico — **siempre 100% de cobertura** | `class ChunkerService`, `procesar_doc()`, `procesar_lote()`, `_dividir_en_chunks()` |
| **`feedback_mejorado.py`** | 332 | 1 | Analiza patrones de error del agente y ajusta puntajes con guardias de muestra mínima (≥3) | `analizar_patron_errores()`, `ajustar_puntaje_por_feedback()`, `construir_bloque_aprendizaje()` |
| **`feedback.py`** | 316 | 3 | Bucle interactivo de correcciones del validador. Maneja EOF para ejecución desatendida | `bucle_feedback_consola()`, `cargar_historial()`, `guardar_historial()`, `calcular_estadisticas()`, `_leer()` |
| **`generador_estadistica_feedback.py`** | 253 | 1 | Informe Excel con la precisión histórica del agente (MAE, sesgo, exactitud por ámbito) | `generar_informe_estadistica()` |

---

### 13.3 `motor/` — infraestructura Mx_* (5 archivos)

| Archivo | L | Importado por | Uso | Funciones clave |
|---|---:|---:|---|---|
| **`Mx_00_CargaRutas.py`** | 334 | **9** | ⭐ Configuración del motor: rutas, `ROL_AGENTE`, `AMBITO_A_INPUTS`, `CUESTIONAMIENTOS_METODOLOGICOS` (15 patrones), `AGENTE_VERSION` | *(solo constantes)* |
| **`Mx_01_LecturaEvidencias.py`** | 812 | 3 | ⭐ Lectores por formato: PDF (3 fallbacks + OCR), DOCX, PPTX, XLSX, PY, JSON, IPYNB, SQL. Integra el caché | `cargar_todos_inputs()`, `leer_archivo()`, `leer_carpeta()`, `leer_repositorio_informes()` |
| **`Mx_03_LlamarIA.py`** | 461 | 2 | Capa de llamada a la API. **En uso real: solo `_llamar_modelo`, `_parsear_json`, `_obtener_cliente`** | `_llamar_modelo()`, `_parsear_json()`, `_obtener_cliente()` · ⚠️ resto sin conectar (§8.3) |
| **`Mx_04_MotorControlesData.py`** | 423 | 2 | Motor de controles automáticos + detección de los 15 patrones metodológicos en código Python | `detectar_cuestionamientos()`, `ejecutar_motor_data_por_fila()`, `calcular_riesgo_global()`, `parsear_config_control()` |
| **`Mx_02_EstructuraPrompt.py`** | 389 | 2 | Construcción de prompts. **En uso real: solo `construir_prompt_final()`** (Pipeline 1) | `construir_prompt_final()` · ⚠️ los 5 `prompt_*` sin conectar (§8.3) |

> ⚠️ **Aviso de mantenimiento:** el Pipeline 2 (ámbitos) **no pasa por `Mx_02`** — construye sus prompts inline en `motor_ia.py:531`. Si editas los prompts de la evaluación por ámbitos, hazlo allí.

---

### 13.4 `src/rag/` — RAG segmentado por dominio (18 archivos) ⭐

**Este es el RAG activo del pipeline** (`motor_ia.py:141`).

| Archivo | L | Uso | Clases |
|---|---:|---|---|
| **`__init__.py`** | 89 | Dispatcher: infiere el dominio desde `--titulo` y devuelve el retriever adecuado | `get_retriever()`, `inferir_dominio()` |
| **`base_indexer.py`** | 212 | Clase base de indexación: construye el índice ChromaDB, detecta Databricks, genera embeddings con sentence-transformers | `class BaseIndexer` |
| **`base_retriever.py`** | 148 | Clase base de recuperación: `query()` (lista de chunks) y `query_para_prompt()` (string listo para inyectar) | `class BaseRetriever` |
| `LaR/indexer.py` · `LaR/retriever.py` | 41 · 28 | Dominio **liquidez** (lar, liquidity, hqla) | `LaRIndexer`, `LaRRetriever` |
| `VaR/indexer.py` · `VaR/retriever.py` | 19 · 14 | Dominio **riesgo de mercado** (var, frtb) | `VaRIndexer`, `VaRRetriever` |
| `conductuales/indexer.py` · `retriever.py` | 20 · 14 | Dominio **modelos conductuales** (prepago, nmd) | `ConductualesIndexer`, `ConductualesRetriever` |
| `shared/indexer.py` · `retriever.py` | 17 · 14 | Dominio **transversal** (default) | `SharedIndexer`, `SharedRetriever` |

Persistencia: `data/vectordb/<dominio>/` (local) · `/dbfs/FileStore/virf/vectordb/` (Databricks).

---

### 13.5 `agent/` — plataforma v28 (65 archivos)

Agente **conversacional** con 8 skills MRM. **Subsistema independiente: no participa en los 4 trabajos del pipeline principal.**

Entrypoint: `virf_agent_v28/virf_agent_v28/virf_agent_v28.py` (372 L) — requiere `PYTHONPATH=.` desde la raíz.

#### 13.5.1 Núcleo del agente

| Archivo | L | Estado | Uso |
|---|---:|---|---|
| `agent/virf_agent.py` | 494 | 🔵 | Clase principal `VIRFAgent`: orquesta routing → memoria → razonamiento → skill → evaluación |
| `agent/virf_agente.py` | 166 | ⚪ | Variante CLI con modo `--chat`. Sin importadores |
| `agent/orchestrator/orchestrator.py` | 369 | 🔵 | `AgentOrchestrator`: ejecuta la skill elegida con contexto RAG |
| `agent/orchestrator/task_router.py` | 127 | 🔵 | `TaskRouter` + `TaskType`: clasifica la consulta en uno de los 9 tipos MRM |
| `agent/orchestrator/workflow_manager.py` | 248 | ⚪ | `WorkflowManager`, `WorkflowState`, `WorkflowMetrics`. Sin importadores |

#### 13.5.2 Skills MRM (16 archivos)

| Archivo | L | Estado | Qué hace |
|---|---:|---|---|
| `base_skill.py` | 176 | 🔵 | Clase abstracta `BaseSkill` — contrato común de todas las skills |
| `failure_analysis_skill.py` | 198 | 🔵 | Análisis de fallas: hallazgos con evidencia, severidad y recomendaciones |
| `methodology_compliance_skill.py` | 209 | 🔵 | Checklist de cumplimiento metodológico con % de brecha |
| `challenger_generation_skill.py` | 254 | 🔵 | Genera un modelo challenger como notebook ejecutable |
| `challenger_generator.py` | 549 | 🔵 | Motor del challenger: notebooks LaR/VaR con backtesting |
| `challenger_generator_v2_con_rag.py` | 560 | 🔵 | Versión con RAG: extrae referencias documentales y las integra |
| `paper_intelligence_skill.py` | 215 | 🔵 | Extrae metodología de papers académicos + knowledge graph |
| `repo_reconstruction_skill.py` | 324 | 🔵 | Ingeniería inversa de un repositorio → notebook + diagramas Mermaid |
| `regulatory_review_skill.py` | 237 | 🔵 | Revisión contra marcos regulatorios (Basilea, SR 11-7, IFRS) |
| `documentation_audit_skill.py` | 251 | 🔵 | Auditoría de completitud, calidad y trazabilidad documental |
| `model_governance_skill.py` | 177 | 🔵 | Assessment de madurez de gobierno de modelos |
| `consolidator_skill.py` | 167 | 🔵 | Consolida resultados de varias skills |
| `formula_detection_skill.py` | 90 | ⚪ | Detección de fórmulas. Sin importadores |
| `methodology_skill.py` | 99 | ⚪ | Precursor de `methodology_compliance_skill`. Sin importadores |
| `word_export_skill.py` | 133 | ⚪ | Exportación a Word. Sin importadores |
| `TEMPLATE_nueva_skill_mrm.py` | 127 | ⚪ | Plantilla para crear skills nuevas *(intencionalmente sin usar)* |

#### 13.5.3 Evaluadores (6 archivos, todos conectados 🔵)

| Archivo | L | Qué hace |
|---|---:|---|
| `formula_detector.py` | 237 | Detecta fórmulas financieras erróneas por regex, sin LLM |
| `grounding_checker.py` | 185 | Verifica que la respuesta esté anclada en las fuentes |
| `methodology_checker.py` | 173 | Valida solidez metodológica sin LLM |
| `response_evaluator.py` | 148 | Evaluación global de la respuesta |
| `confidence_score.py` | 146 | Puntúa la confianza de la respuesta |
| `hallucination_checker.py` | 142 | Detecta afirmaciones no respaldadas (calibrado para MRM) |

#### 13.5.4 Memoria, razonamiento, contexto y feedback

| Archivo | L | Estado | Qué hace |
|---|---:|---|---|
| `memory/long_term_memory.py` | 272 | 🔵 | Memoria persistente entre sesiones |
| `memory/short_term_memory.py` | 207 | 🔵 | Memoria de la sesión actual |
| `memory/summaries.py` | 187 | 🔵 | `ConversationSummarizer` (alias `SummaryGenerator`) |
| `memory/context_compression.py` | 127 | ⚪ | Compresión de memoria. Sin importadores |
| `reasoning/reasoning_engine.py` | 218 | 🔵 | Motor de razonamiento: elige skill vía CoT |
| `reasoning/chain_of_thought.py` | 166 | 🔵 | Cadena de pensamiento explícita |
| `reasoning/decision_trace.py` | 190 | ⚪ | Traza de decisiones. Sin importadores |
| `context_engineering/prioritization.py` | 148 | 🔵 | Prioriza fragmentos de contexto · ⚠️ `TODO (v2)` en L110 |
| `context_engineering/ranking.py` | 113 | 🔵 | Ordena por relevancia |
| `context_engineering/compression.py` | 115 | 🔵 | Comprime el contexto |
| `context_engineering/filtering.py` | 109 | 🔵 | Filtra contexto irrelevante · ⚠️ `TODO (v2)` en L81 |
| `feedback/feedback_analyzer.py` | 235 | 🔵 | Analiza patrones del feedback |
| `feedback/learning_loop.py` | 186 | 🔵 | Bucle de aprendizaje |
| `feedback/feedback_store.py` | 181 | 🔵 | Persistencia del feedback |
| `feedback/corrections.py` | 173 | 🔵 | Seguimiento de correcciones |

#### 13.5.5 Herramientas y RAG de v28

| Archivo | L | Estado | Nota |
|---|---:|---|---|
| `tools/code_reader_tool.py` | 159 | 🔵 | Lector de código para las skills |
| `tools/base_tool.py` | 84 | 🔵 | Clase base de herramientas |
| `tools/pandas_tool.py` | 98 | ⚪ | Sin importadores |
| `tools/sql_tool.py` | 67 | ⚪ | Contiene `SQLTool`, `PlottingTool`, `SHAPTool`. Sin importadores |
| `rag/vector_store/chroma_manager.py` | 303 | ⚪ | ⚠️ **RAG duplicado** — el activo es `src/rag/` |
| `rag/embeddings/chunking.py` | 236 | ⚪ | ⚠️ Duplica `modulos/chunker.py` |
| `rag/retrieval/semantic_search.py` | 226 | ⚪ | ⚠️ Duplicado |
| `rag/embeddings/embedding_generator.py` | 208 | ⚪ | ⚠️ Duplicado |
| `rag/retrieval/reranking.py` | 53 | ⚪ | ⚠️ Duplicado |

> ⚠️ **`agent/rag/` completo (1.026 líneas) está sin conectar.** El RAG que usa el pipeline es `src/rag/`. Conservado porque `agent/` es un subsistema aparte cuyo estado de uso está [pendiente de confirmar](#92-agent-v28--en-producción).

---

### 13.6 `scripts/`

| Archivo | L | Estado | Uso |
|---|---:|---|---|
| `rebuild_rag_databricks.py` | 178 | 🟢 entrypoint | Reconstruye los índices RAG por dominio. Uso: `python scripts/rebuild_rag_databricks.py --dominio all`. *Auxiliar* |

---

### 13.7 Los 15 archivos sin conectar

Nadie los importa ni se ejecutan solos. **No se retiraron** porque 14 de 15 pertenecen a `agent/`, cuyo estado de uso está pendiente de tu confirmación (§9.2).

| Archivo | L | Por qué sigue ahí |
|---|---:|---|
| `agent/rag/vector_store/chroma_manager.py` | 303 | RAG duplicado de `src/rag/` |
| `agent/orchestrator/workflow_manager.py` | 248 | Gestión de workflows del v28 |
| `agent/rag/embeddings/chunking.py` | 236 | Duplica `modulos/chunker.py` |
| `agent/rag/retrieval/semantic_search.py` | 226 | RAG duplicado |
| `agent/rag/embeddings/embedding_generator.py` | 208 | RAG duplicado |
| `agent/reasoning/decision_trace.py` | 190 | Trazas de decisión del v28 |
| `agent/virf_agente.py` | 166 | Variante CLI del agente v28 |
| `agent/skills/word_export_skill.py` | 133 | Exportación Word del v28 |
| `agent/skills/TEMPLATE_nueva_skill_mrm.py` | 127 | **Plantilla — sin usar a propósito** |
| `agent/memory/context_compression.py` | 127 | Compresión de memoria |
| `agent/skills/methodology_skill.py` | 99 | Precursor de `methodology_compliance_skill` |
| `agent/tools/pandas_tool.py` | 98 | Herramienta del v28 |
| `agent/skills/formula_detection_skill.py` | 90 | Skill del v28 |
| `agent/tools/sql_tool.py` | 67 | Herramienta del v28 |
| `agent/rag/retrieval/reranking.py` | 53 | RAG duplicado |
| **Total** | **2.371** | |

> Si confirmas que `agent/` está aparcado, estas 2.371 líneas más las 8.000 restantes de `agent/` podrían archivarse igual que en §12.

---

## Apéndices

### A. Pesos y escala

**Pesos** (`config/parametros.py`, suma = 1.0):

| Ámbito | Peso | Fundamento (`AMBITO_PESOS_REFS`) |
|---|---:|---|
| Metodología | 30% | SR 11-7 §IV conceptual soundness |
| Calidad de datos | 20% | BCBS 239 principios 3-5 |
| Documentación | 15% | EBA/GL/2023/01 §6.3 |
| Implementación | 15% | SR 11-7 §IV outcome analysis |
| Gobierno | 12% | EBA/GL/2023/01 §5 |
| Uso e integración | 8% | SR 11-7 §IV ongoing monitoring |

**Semáforo** (`config/dominio.py:SCORE_SEMAFORO`): 4.5-5.0 SATISFACTORIO · 3.5-4.5 ACEPTABLE · 2.5-3.5 CON OBSERVACIONES · 1.5-2.5 DEFICIENTE · 0-1.5 CRÍTICO

### B. Las 8 pruebas de calidad de datos

`modulos/motores_datos.py:REGISTRO_MOTORES` — `python agente.py --listar-motores`

| Prueba | Requiere | Ejemplo |
|---|---|---|
| `unicidad` | `GROUP_COLS`, `CAMPO_OBJETIVO` | Un Cliente por Cuenta |
| `duplicados` | — | No repetir Cuenta+Fecha |
| `missing` | — | <1% de nulos |
| `outliers` | `CAMPO_OBJETIVO` | IQR robusto (no Z-score) |
| `rango` | `CAMPO_OBJETIVO`, `MIN`/`MAX` | Tasa entre 0 y 1 |
| `integridad_referencial` | `CAMPO_OBJETIVO`, `DATASET_REF` | Cliente existe en maestro |
| `tipo_dato` | `CAMPO_OBJETIVO` | Fechas válidas (multi-columna) |
| `completitud` | — | ≥1000 registros |

**`UMBRAL`** (`motores_datos.py:_estado_por_tasa`): `0` = tolerancia cero · `0<x<1` = proporción · `≥1` = conteo absoluto. Severidad **relativa al umbral**: ≤2× ADVERTENCIA · ≤10× ALERTA · >10× ERROR.

### C. Los 15 patrones metodológicos

`motor/Mx_00_CargaRutas.py:CUESTIONAMIENTOS_METODOLOGICOS` · evaluados por `Mx_04:detectar_cuestionamientos`

**Por presencia:** `outliers_zscore`, `imputation_mean`, `train_test_split_random`, `sin_shap_modelos_complejos`, `look_ahead_bias`, `data_leakage_escalado`, `supuesto_correlacion_constante`

**Por ausencia:** `sin_estacionariedad`, `sin_heterocedasticidad`, `sin_test_normalidad`, `sin_expected_shortfall`, `sin_analisis_sensibilidad`, `sin_psi`, `sin_backtesting_lar`, `sin_replica_virf`

Validado: 13/15 alertas sobre código defectuoso, **0 falsos positivos** sobre código correcto.

### D. Troubleshooting

| Síntoma | Causa | Solución |
|---|---|---|
| `🔴 RIESGO DE SEGURIDAD: la clave está en .env.example` | Clave real commiteada | Revócala, genera otra, restaura el placeholder |
| `❌ API key rechazada (401)` | Clave inválida | La consola del proveedor activo — el propio mensaje la indica |
| `SIN DOCUMENTOS` en todos los ámbitos | `inputs/` vacío | Ver [§4.1](#41-dónde-cargar-cada-archivo-) |
| `Sin evidencia disponible` en controles | Formato no soportado | Usa `.md`, `.docx`, `.pdf`, `.txt` |
| `Sin datasets en …` | Falta `inputs/calidad_datos/datasets/` | Crea la carpeta y pon los `.csv` |
| `Motor 'X' no implementado` | Typo en `TIPO_MOTOR` | `python agente.py --listar-motores` |
| `UnicodeEncodeError` en Windows | Consola cp1252 | `set PYTHONIOENCODING=utf-8` |
| `dictamen_confiable: false` | Fallos técnicos | Revisa `integridad.detalle_fallos`, re-ejecuta |
| PDF se lee vacío | Escaneado sin OCR | Instala Tesseract + Poppler ([§2.3](#23-ocr-opcional--solo-para-pdfs-escaneados)) |
| Cobertura documental < 100% | Fallo de API durante el chunking | Re-ejecuta; el caché conserva lo ya leído |
| Caché corrupto | Interrupción antigua | `python agente.py --limpiar-cache` |

### E. Referencias regulatorias

| Norma | Uso en VIRF |
|---|---|
| **SR 11-7** (Fed, 2011) | §IV conceptual soundness → peso Metodología 30% |
| **EBA/GL/2023/01** | §5 inventario/tiering → Gobierno; §6.3 documentación |
| **BCBS 239** (2013) | Principios 3-5 → Calidad de datos 20% |
| **BCBS d457 (FRTB)** | §33 Expected Shortfall → patrón `sin_expected_shortfall` |
| **SBS Res. 9075-2012** | Art. 9 riesgo de liquidez |
| **RiskMetrics TD** (JP Morgan, 1996) | §4.2 estacionariedad, §5.1 normalidad |

---

## Ayuda rápida

```bash
python validate_project.py     # ⭐ empieza siempre aquí — debe dar 88/88
python agente.py --help
python agente.py --listar-motores
```

Si `validate_project.py` da 0 FAIL y aun así algo falla, el problema está en los datos de entrada, no en la instalación.
