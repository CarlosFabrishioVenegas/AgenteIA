"""
Mx_03_LlamarIA.py
==================
Capa de comunicación con la API del proveedor de IA activo.

El proveedor concreto (Anthropic, Azure OpenAI…) lo resuelve `config/ia.py` a
partir de `IA_PROVEEDOR`; este módulo NO conoce ninguno: pide el cliente a la
fábrica y habla con la interfaz común `ClienteIA`.

Responsabilidades:
  - Ejecutar las llamadas a través del cliente inyectado
  - Parsear respuestas JSON del modelo
  - Manejar errores de red, timeout y JSON inválido
  - Exponer funciones de alto nivel:
      llamar_modelo()       → retorna texto crudo
      llamar_y_parsear()    → retorna dict JSON parseado
      aprender_estilo()     → llama y retorna dict de estilo
      generar_replica()     → retorna código Python como str
      generar_sintesis()    → retorna dict de síntesis

No contiene lógica de negocio ni construcción de prompts.
"""

import json
import re
import requests
from typing import Optional, Dict, Any
import time

from Mx_00_CargaRutas import (
    MODELO_IA, MAX_TOKENS, ROL_AGENTE, UMBRAL_RIESGO_GLOBAL
)
import os as _os
from Mx_02_EstructuraPrompt import (
    prompt_aprender_estilo, estilo_por_defecto,
    prompt_generar_replica_virf,
    prompt_sintesis,
)

# ── Importar cliente IA centralizado desde config.py ──────────────────────────
import sys
from pathlib import Path
_MOTOR_DIR = Path(__file__).parent.resolve()
_ROOT_DIR = _MOTOR_DIR.parent.resolve()
if str(_ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(_ROOT_DIR))

try:
    from config import get_cliente_ia
except Exception as e:
    # Fallback si config.py no está disponible
    get_cliente_ia = None

# [AUDIT-FIX 2026-07-30] Aquí había una SEGUNDA caché de cliente:
#
#     _CLIENTE_MX03 = None
#     def _obtener_cliente():
#         global _CLIENTE_MX03
#         if _CLIENTE_MX03 is None:
#             _CLIENTE_MX03 = get_cliente_ia()
#         return _CLIENTE_MX03
#
# Se justificaba como «defensa en profundidad», pero creaba un cliente ZOMBI:
# `config.ia.reset_cliente_ia()` limpia la caché de config y NO esta, así que
# tras cambiar de proveedor —o tras `forzar_recarga=True`— este módulo seguía
# usando el cliente antiguo. Con Azure como proveedor prioritario eso significa
# que una parte del pipeline podía seguir hablando con Anthropic después de
# migrar, sin ningún síntoma: exactamente el escenario que la política de «un
# solo proveedor por corrida» prohíbe.
#
# `config.get_cliente_ia()` YA cachea a nivel de proceso, así que la segunda
# caché no aportaba rendimiento: solo una fuente de verdad duplicada.


def _obtener_cliente():
    """
    Devuelve el cliente IA. La caché vive ÚNICAMENTE en config.get_cliente_ia().
    """
    if get_cliente_ia is None:
        raise RuntimeError(
            "❌ config no está disponible. Verifica que el paquete config/ "
            "exista en la raíz del proyecto."
        )
    return get_cliente_ia()


# ─── Helpers internos ────────────────────────────────────────────────────────

def _llamar_modelo(user_prompt: str, max_tokens: Optional[int] = None) -> str:
    """
    Llama a la API usando el cliente centralizado desde config.py.
    Soporta múltiples proveedores: Anthropic, OpenAI, Google, Local Ollama.
    
    El proveedor se selecciona mediante IA_PROVEEDOR en .env
    
    Parámetros:
        user_prompt: prompt del usuario
        max_tokens: tokens máximos (usa default si es None)
    
    Retorna:
        String con la respuesta del modelo
    
    Lanza excepción si el cliente no está disponible
    """
    try:
        cliente = _obtener_cliente()   # [PERF-FIX] instancia reutilizada
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError(f"❌ Error al obtener cliente IA: {e}")
    
    from config.parametros import DEBUG_PROMPTS as _debug
    
    # DEBUG: Guardar prompt a archivo si DEBUG_PROMPTS=1
    if _debug:
        import hashlib
        from datetime import datetime
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        prompt_hash = hashlib.md5(user_prompt.encode()).hexdigest()[:8]
        # [AUDIT-FIX] Se escribía con ruta RELATIVA, así que el volcado caía en
        # el directorio desde el que se lanzara el agente. Estos ficheros
        # contienen el prompt ÍNTEGRO —toda la evidencia del modelo— y solo
        # están cubiertos por .gitignore si aterrizan en la raíz del proyecto.
        # Lanzarlo desde otro cwd los dejaba fuera de esa protección.
        # Ahora van siempre a outputs/<fecha>/debug_prompts/, que es la
        # convención de salidas que valida validate_project.py.
        from config.rutas import OUTPUTS_DIR
        _dir_debug = OUTPUTS_DIR / datetime.now().strftime("%Y-%m-%d") / "debug_prompts"
        _dir_debug.mkdir(parents=True, exist_ok=True)
        debug_file = _dir_debug / f"DEBUG_PROMPT_{timestamp}_{prompt_hash}.txt"
        with open(debug_file, 'w', encoding='utf-8') as f:
            f.write(f"TIMESTAMP: {timestamp}\n")
            # [GENERICO] Antes: `_os.getenv('IA_PROVEEDOR', 'anthropic')`. Ese
            # default contradecía al real (`azure_openai`, en
            # config/parametros.py), así que un volcado de depuración hecho sin
            # la variable definida ATRIBUÍA el prompt al proveedor equivocado —
            # justo en el fichero que se usa para diagnosticar qué se envió.
            # Se lee del único punto de declaración.
            from config.parametros import IA_PROVEEDOR as _PROVEEDOR
            f.write(f"IA_PROVEEDOR: {_PROVEEDOR}\n")
            f.write(f"MODELO: {MODELO_IA}\n")
            f.write(f"MAX_TOKENS: {max_tokens or MAX_TOKENS}\n")
            f.write(f"PROMPT_LENGTH: {len(user_prompt)}\n")
            f.write("="*80 + "\n\n")
            f.write(user_prompt)
        print(f"📝 DEBUG: Prompt guardado en {debug_file}")
    
    try:
        respuesta = cliente.generar_mensaje(
            prompt=user_prompt,
            max_tokens=max_tokens or MAX_TOKENS,
            instruccion_sistema=ROL_AGENTE
        )
        return respuesta
    except Exception as e:
        print(f"❌ Error en llamada API: {e}")
        raise


def _parsear_json(texto: str, fallback: dict) -> dict:
    """
    Extrae y parsea el primer objeto JSON encontrado en el texto.
    Si falla, retorna fallback con el raw adjunto.

    [AUDIT-FIX] Este parser usaba `find("{")` + `rfind("}")`, que toma la
    ÚLTIMA llave de todo el texto. El proyecto ya tenía un extractor robusto
    (`motor_ia._extraer_json`, con conteo de llaves consciente de strings y
    escapes) pero el pipeline por CONTROL seguía usando este. Casos medidos en
    los que el débil falla y el robusto acierta:

        · el modelo añade una frase explicativa con llaves:
          '{...}\\n\\nNota: usa {llaves} asi.'   → rfind se pasa de largo
        · el modelo emite DOS objetos seguidos    → los fusiona en JSON inválido

    En ambos, una evaluación perfectamente válida se descartaba y el control
    caía a estado de fallback. Ahora delega en el extractor robusto y solo
    recurre a la heurística antigua si aquel no está disponible.
    """
    try:
        from modulos.motor_ia import _extraer_json   # import diferido: evita ciclo
        return _extraer_json(texto)
    except json.JSONDecodeError:
        return {**fallback, "_raw": texto[:500]}
    except Exception:
        pass   # extractor no disponible → heurística local

    limpio = re.sub(r"```(?:json)?|```", "", texto).strip()
    i, j = limpio.find("{"), limpio.rfind("}")
    if i != -1 and j != -1:
        limpio = limpio[i:j + 1]
    try:
        return json.loads(limpio)
    except json.JSONDecodeError:
        return {**fallback, "_raw": texto[:500]}


def _crop_to_json(text: str) -> str:
    """
    Extrae substring entre la primera "{" y la última "}" (fallback).
    
    Parámetros:
        text: string que puede contener JSON
    
    Retorna:
        String con el JSON extraído (o vacío si no se encuentra)
    """
    i, j = text.find("{"), text.rfind("}")
    if i != -1 and j != -1 and j > i:
        return text[i:j+1]
    return ""


def _validar_contrato(data: Dict[str, Any]) -> None:
    """
    Valida que el JSON retornado cumple con el contrato esperado.
    
    Contrato requerido:
    {
      "revision": str (no vacío),
      "hallazgos": list[dict] con campos: tipo, texto, recomendacion, riesgo, criticidad
    }
    
    Parámetros:
        data: dict a validar
    
    Lanza excepción ValueError si no cumple contrato.
    """
    if not isinstance(data, dict):
        raise ValueError("Response debe ser un diccionario JSON")
    
    # Campo revision
    if "revision" not in data:
        raise ValueError("Falta campo 'revision'")
    if not isinstance(data["revision"], str) or not data["revision"].strip():
        raise ValueError("Campo 'revision' debe ser string no vacío")
    
    # Campo hallazgos
    if "hallazgos" not in data:
        raise ValueError("Falta campo 'hallazgos'")
    if not isinstance(data["hallazgos"], list):
        raise ValueError("Campo 'hallazgos' debe ser lista")
    
    # Validar cada hallazgo
    tipos_validos = {"OBSERVACION", "OPORTUNIDAD_MEJORA"}
    criticidades_validas = {"CRITICA", "MODERADA", "BAJA", "POTENCIAL"}
    
    for i, hallazgo in enumerate(data["hallazgos"]):
        if not isinstance(hallazgo, dict):
            raise ValueError(f"Hallazgo {i} no es diccionario")
        
        # Campos requeridos
        for campo in ["tipo", "texto", "recomendacion", "riesgo", "criticidad"]:
            if campo not in hallazgo:
                raise ValueError(f"Hallazgo {i} falta campo '{campo}'")
            if not isinstance(hallazgo[campo], str) or not hallazgo[campo].strip():
                raise ValueError(f"Hallazgo {i} campo '{campo}' debe ser string no vacío")
        
        # Valores válidos
        if hallazgo["tipo"] not in tipos_validos:
            raise ValueError(f"Hallazgo {i}: tipo debe ser {tipos_validos}")
        if hallazgo["criticidad"] not in criticidades_validas:
            raise ValueError(f"Hallazgo {i}: criticidad debe ser {criticidades_validas}")


# [CÓDIGO MUERTO RETIRADO 2026-07-30] `llamar_ia_json()` se eliminó de aquí:
# no la llamaba nadie Y accedía a `response.choices[0].message.content`, es
# decir a la forma cruda del SDK, fuera de config/. El acoplamiento al SDK
# vive SOLO en config/ia.py, detrás de ClienteIA. Su `response_format`
# json_object sobrevive como `formato_json=True` en la interfaz.
# Copia en archivo/codigo_muerto_2026-07-30/llamar_ia_json.py



# ══════════════════════════════════════════════════════════════════════════════
# ⚠️  RAMA NO CONECTADA AL FLUJO ACTIVO — NO BORRAR SIN LEER ESTO
# ══════════════════════════════════════════════════════════════════════════════
# Auditoría 2026-07-26: las cinco funciones públicas de esta sección
# (aprender_estilo, generar_replica_virf, evaluar_dimension, generar_sintesis)
# más `llamar_ia_json` y `_validar_contrato` NO tienen NINGÚN llamador fuera de
# este archivo. Verificado con grafo de imports AST sobre los 123 .py del
# proyecto y con grep de sitios de llamada.
#
# POR QUÉ EXISTEN (historial):
#   Diseño original v12-v17: el pipeline evaluaba una DIMENSIÓN completa por
#   llamada (evaluar_dimension) y consolidaba con generar_sintesis. El estilo
#   de redacción se aprendía de informes previos (aprender_estilo) y se
#   generaba el script de 2ª línea (_replica_virf.py).
#
# QUÉ LAS REEMPLAZÓ:
#   · Pipeline 2 (ámbitos)   → modulos/motor_ia.py:evaluar_actividad()
#       Evalúa ACTIVIDAD por actividad, con prompt construido inline, memoria
#       intra/inter-ámbito, RAG y calibración anti-sesgo. No usa Mx_02.
#   · Pipeline 1 (controles) → modulos/motor_ia_v2.py:220
#       Usa Mx_02.construir_prompt_final() + Mx_03._llamar_modelo(). Esa SÍ es
#       la ruta viva de este archivo.
#   · Validación de contrato → modulos/motor_ia.py:_validar_contrato_evaluacion()
#       `_validar_contrato` de aquí nunca se conectó: el contrato del pipeline
#       real es distinto (puntaje 1-5, no revision/hallazgos).
#
# EN USO REAL DE ESTE ARCHIVO: solo `_llamar_modelo()`, `_parsear_json()` y
# `_obtener_cliente()`.
#
# Se conservan como referencia del diseño anterior. Si se retoma la evaluación
# por dimensión, aquí está la implementación. Ver README §12.
# ══════════════════════════════════════════════════════════════════════════════

def aprender_estilo(texto_informes: str) -> dict:
    """
    Llama al modelo con el texto de informes de referencia.
    Retorna dict con tono, frases y vocabulario aprendido.
    Si no hay texto, retorna el estilo por defecto.
    """
    if not texto_informes.strip():
        return estilo_por_defecto()
    raw = _llamar_modelo(prompt_aprender_estilo(texto_informes))
    return _parsear_json(raw, {"tono": "formal"})


def generar_replica_virf(docs_modelador: list, scripts_modelador: list) -> str:
    """
    Genera el código del script _replica_virf.py como segunda línea.
    Retorna código Python como string.
    """
    raw = _llamar_modelo(
        prompt_generar_replica_virf(docs_modelador, scripts_modelador),
        max_tokens=4000,
    )
    # Limpiar bloques markdown
    return re.sub(r"```(?:python)?|```", "", raw).strip()


# [CÓDIGO MUERTO RETIRADO 2026-07-29] `evaluar_dimension()` se eliminó de aquí:
# ningún módulo la llamaba. Copia en
# archivo/codigo_muerto_2026-07-29/evaluar_dimension.py con el motivo completo.
# Mantener una función pública sin llamantes es un pasivo: nadie la
# ejercita, ningún test la protege, y quien la reactive hereda su
# comportamiento de entonces sin enterarse. La versión original violaba
# el D3-FIX (dimensión sin documentos → score 0 → peor puntaje).



def generar_sintesis(
    resultados: dict,
    titulo: str,
    modo: str,
    estilo: dict,
    tier: str,
) -> dict:
    """
    Genera la síntesis ejecutiva, dictamen global y plan de acción.
    Retorna dict con resumen_ejecutivo, dictamen_global, plan_accion, etc.
    """
    fallback = {
        "resumen_ejecutivo":       "Ver resultados por dimensión.",
        "dictamen_global":         "APROBADO CON OBSERVACIONES",
        "nivel_riesgo":            "Medio",
        "riesgo_global_alto":      False,
        "justificacion_dictamen":  "",
        "principales_hallazgos":   [],
        "informacion_requerida":   [],
        "plan_accion":             [],
        "proxima_revision":        "Próximo trimestre",
        "conclusion_narrativa":    "",
    }
    raw = _llamar_modelo(
        prompt_sintesis(resultados, titulo, modo, estilo, tier),
        max_tokens=4000,
    )
    return _parsear_json(raw, fallback)
