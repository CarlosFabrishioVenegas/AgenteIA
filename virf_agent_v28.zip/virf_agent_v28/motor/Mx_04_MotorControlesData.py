"""
Mx_04_MotorControlesData.py
============================
Motor de controles de calidad automatizados sobre datos.

Responsabilidades:
  - Ejecutar controles automáticos: unicidad, integridad, etc.
  - Convertir resultados a texto para insertar en prompts
  - Detectar patrones metodológicamente cuestionables en código
  - Devolver alertas estructuradas

Nota: Este módulo NO llama a la API.
      Es análisis estático (regex) + controles de datos (pandas).
"""

import re
from pathlib import Path
from typing import Optional, Dict, Any, List
import pandas as pd

from Mx_00_CargaRutas import CUESTIONAMIENTOS_METODOLOGICOS, RUTAS


# ─── Detección de cuestionamientos en código ──────────────────────────────────

def detectar_cuestionamientos(documentos: list) -> dict:
    """
    Analiza scripts Python en busca de patrones metodológicamente cuestionables.

    Args:
        documentos: Lista de dicts {nombre, tipo, contenido} de todos los inputs.

    Returns:
        Dict {nombre_archivo: {"alertas_rapidas": [lista_de_alertas]}}
        Cada alerta: {"tipo": "presencia|ausencia", "clave": ..., "contexto": ..., "critica": ...}
    """
    codigos = [d for d in documentos if d["tipo"] == "PY"]
    if not codigos:
        return {}

    resultados = {}
    for doc in codigos:
        codigo_lower = doc["contenido"].lower()
        alertas = []

        for clave, info in CUESTIONAMIENTOS_METODOLOGICOS.items():
            patrones    = info["detectar"]
            es_ausencia = info.get("detectar_ausencia", False)

            # BUG FIX: usar re.search para patrones con wildcards (ej: 'SimpleImputer.*mean').
            # Patrones sin metacaracteres regex se escapan para que los paréntesis
            # literales (ej: 'fillna(mean') no rompan el compilador.
            def _match_patron(patron: str, texto: str) -> bool:
                p = patron.lower()
                try:
                    return bool(re.search(p, texto))
                except re.error:
                    # Patrón con caracteres especiales no escapados → búsqueda literal
                    return p in texto

            encontrado = any(_match_patron(p, codigo_lower) for p in patrones)

            if es_ausencia and not encontrado:
                # Alerta por AUSENCIA: el patrón debería estar y no está
                alertas.append({
                    "tipo":     "ausencia",
                    "clave":    clave,
                    "contexto": info["contexto"],
                    "critica":  info["critica"],
                })
            elif not es_ausencia and encontrado:
                # Alerta por PRESENCIA: el patrón está y es cuestionable
                alertas.append({
                    "tipo":     "presencia",
                    "clave":    clave,
                    "contexto": info["contexto"],
                    "critica":  info["critica"],
                })

        resultados[doc["nombre"]] = {"alertas_rapidas": alertas}

    return resultados


def tiene_replica_virf(documentos: list) -> bool:
    """Verifica si existe un script _replica_virf.py entre los documentos."""
    return any(
        "_replica_virf" in d["nombre"].lower()
        for d in documentos
        if d["tipo"] == "PY"
    )


def calcular_riesgo_global(resultados_dimensiones: dict) -> dict:
    """
    Calcula métricas globales de riesgo a partir de todos los resultados.

    Returns:
        {
          "total_actividades": int,
          "total_sin_evidencia": int,
          "pct_sin_evidencia": float,
          "condicion_corte_activada": bool,
          "score_promedio": float | None,
        }
    """
    from Mx_00_CargaRutas import UMBRAL_RIESGO_GLOBAL

    total_acts   = sum(len(r.get("evaluaciones", [])) for r in resultados_dimensiones.values())
    total_sin_ev = sum(r.get("actividades_sin_evidencia", 0) for r in resultados_dimensiones.values())
    pct          = total_sin_ev / total_acts if total_acts > 0 else 0.0

    # Score promedio (solo en modo preprdc)
    todos_scores = [
        ev.get("score", None)
        for res in resultados_dimensiones.values()
        for ev in res.get("evaluaciones", [])
        if ev.get("score") is not None
    ]
    score_promedio = round(sum(todos_scores) / len(todos_scores), 1) if todos_scores else None

    return {
        "total_actividades":         total_acts,
        "total_sin_evidencia":       total_sin_ev,
        "pct_sin_evidencia":         round(pct, 4),
        "condicion_corte_activada":  pct > UMBRAL_RIESGO_GLOBAL,
        "score_promedio":            score_promedio,
    }


def resumen_cuestionamientos_consola(cuestionamientos: dict) -> None:
    """Imprime en consola un resumen de las alertas detectadas."""
    if not cuestionamientos:
        print("  → Sin scripts Python para analizar.")
        return
    for archivo, analisis in cuestionamientos.items():
        n = len(analisis.get("alertas_rapidas", []))
        estado = "⚠" if n > 0 else "✓"
        print(f"  {estado}  {archivo}: {n} alerta(s)")
        for alerta in analisis.get("alertas_rapidas", []):
            tipo_label = "DETECTADO" if alerta["tipo"] == "presencia" else "AUSENTE"
            print(f"       [{tipo_label}] {alerta['contexto']}")


def alertas_criticas(cuestionamientos: dict) -> list:
    """
    Retorna lista plana de todas las alertas de todos los archivos.
    Útil para el generador Word/Excel.
    """
    todas = []
    for archivo, analisis in cuestionamientos.items():
        for alerta in analisis.get("alertas_rapidas", []):
            todas.append({**alerta, "archivo": archivo})
    return todas


# ─── NUEVAS FUNCIONES PARA MOTOR DE CONTROLES AUTOMÁTICOS ─────────────────────


def parsear_lista_campos(texto: Any) -> List[str]:
    """
    Parsea un texto que puede contener lista de campos separados por comas.
    Ejemplo: "Cuenta, FechaApertura" → ["Cuenta","FechaApertura"]
    
    Parámetros:
        texto: string o NaN
    
    Retorna:
        Lista de campos (strings)
    """
    if not texto or str(texto).strip().lower() in ("nan", "none", ""):
        return []
    
    try:
        # Si es string, splitear por coma y limpiar espacios
        campos_str = str(texto).strip()
        campos = [c.strip() for c in campos_str.split(",")]
        return [c for c in campos if c]  # Filtrar vacíos
    except Exception:
        return []


def parsear_config_control(row: Dict[str, Any]) -> Dict[str, Any]:
    """
    Parsea una fila del Excel de configuración de controles.
    
    Espera columnas: ID_CONTROL, USA_MOTOR_DATA, TIPO_MOTOR, DATASET,
                     GROUP_COLS, CAMPO_OBJETIVO, UMBRAL, ACCION
    
    Parámetros:
        row: dict-like (ej: pd.Series) con columnas del Excel
    
    Retorna:
        Dict con config parsada:
        {
          "id_control": str,
          "usa_motor_data": int (0 o 1),
          "tipo_motor": str,
          "dataset": str,
          "group_cols": list[str],
          "campo_objetivo": str,
          "umbral": int,
          "accion": str,
        }
    """
    # [NAN-FIX] Celdas vacías del Excel llegan como float('nan'), que en Python
    # es TRUTHY. La guarda `if row.get("UMBRAL")` no filtraba nada y se llamaba
    # a int(nan) → ValueError "cannot convert float NaN to integer", abortando
    # el motor de datos de ese control.
    def _num(valor, defecto):
        """Convierte a número tolerando NaN, None, '' y texto no numérico."""
        if valor is None:
            return defecto
        try:
            import math
            if isinstance(valor, float) and math.isnan(valor):
                return defecto
        except Exception:
            pass
        txt = str(valor).strip()
        if not txt or txt.lower() in ("nan", "none", "nat"):
            return defecto
        try:
            return int(float(txt))
        except (TypeError, ValueError):
            return defecto

    def _txt(valor):
        """Convierte a str tolerando NaN/None."""
        if valor is None:
            return ""
        txt = str(valor).strip()
        return "" if txt.lower() in ("nan", "none", "nat") else txt

    return {
        "id_control":      _txt(row.get("ID_CONTROL")),
        "usa_motor_data":  _num(row.get("USA_MOTOR_DATA"), 0),
        "tipo_motor":      _txt(row.get("TIPO_MOTOR")).lower(),
        "dataset":         _txt(row.get("DATASET")),
        "group_cols":      parsear_lista_campos(row.get("GROUP_COLS")),
        "campo_objetivo":  _txt(row.get("CAMPO_OBJETIVO")),
        "umbral":          _num(row.get("UMBRAL"), 1),
        "accion":          _txt(row.get("ACCION")),
    }


def validar_config_unicidad(cfg: Dict[str, Any]) -> None:
    """
    Valida que la configuración para control de unicidad es suficiente.
    
    Parámetros:
        cfg: dict de configuración
    
    Lanza ValueError si validación falla.
    """
    if not cfg.get("group_cols"):
        raise ValueError("Falta GROUP_COLS para control de unicidad")
    if not cfg.get("campo_objetivo"):
        raise ValueError("Falta CAMPO_OBJETIVO para control de unicidad")


def ejecutar_control_unicidad(
    df: pd.DataFrame,
    group_cols: List[str],
    campo_objetivo: str,
    umbral: int = 1,
) -> Dict[str, Any]:
    """
    Ejecuta control de unicidad sobre un DataFrame.
    
    Por cada grupo en group_cols, cuenta valores únicos en campo_objetivo.
    Si > umbral, genera alerta.
    
    Parámetros:
        df: DataFrame con datos
        group_cols: lista de columnas para agrupar
        campo_objetivo: columna a validar unicidad
        umbral: máximo de valores únicos permitidos por grupo
    
    Retorna:
        {
          "estado": "PASA" | "NO PASA",
          "grupos_evaluados": int,
          "grupos_con_falla": int,
          "registros_fallidos": int,
          "detalle": DataFrame con registros fallidos (o vacío),
        }
    """
    try:
        # Agrupar y contar valores únicos
        grupos_evaluados = 0
        grupos_falla = 0
        registros_falla = 0
        indices_falla = []
        
        for group_vals, group_df in df.groupby(group_cols, dropna=False):
            grupos_evaluados += 1
            n_uniques = group_df[campo_objetivo].nunique()
            
            if n_uniques > umbral:
                grupos_falla += 1
                indices_falla.extend(group_df.index.tolist())
                registros_falla += len(group_df)
        
        estado = "PASA" if grupos_falla == 0 else "NO PASA"
        
        # Detalle de registros fallidos
        detalle_df = df.loc[indices_falla] if indices_falla else df.iloc[0:0]
        
        return {
            "estado":               estado,
            "grupos_evaluados":     grupos_evaluados,
            "grupos_con_falla":     grupos_falla,
            "registros_fallidos":   registros_falla,
            "detalle":              detalle_df,
        }
    except Exception as e:
        return {
            "estado":               "ERROR",
            "error":                str(e),
            "grupos_evaluados":     0,
            "grupos_con_falla":     0,
            "registros_fallidos":   0,
            "detalle":              pd.DataFrame(),
        }


def ejecutar_motor_data_por_fila(row: Dict[str, Any], datasets_dict: Dict[str, pd.DataFrame]) -> Optional[Dict[str, Any]]:
    """
    Ejecuta control automático según configuración de una fila Excel.
    
    Soporta actualmente: unicidad.
    
    Parámetros:
        row: fila del Excel (dict-like)
        datasets_dict: dict {nombre_dataset: DataFrame}
    
    Retorna:
        Dict resultado del control o None si no aplica
    """
    cfg = parsear_config_control(row)
    
    # Si no usa motor data, retornar None
    if not cfg["usa_motor_data"]:
        return None
    
    # Obtener dataset
    if cfg["dataset"] not in datasets_dict:
        return {
            "tipo_motor": cfg["tipo_motor"],
            "estado":     "ERROR",
            "error":      f"Dataset '{cfg['dataset']}' no encontrado",
        }
    
    df = datasets_dict[cfg["dataset"]]
    
    # Ejecutar según tipo de motor
    if cfg["tipo_motor"] == "unicidad":
        try:
            validar_config_unicidad(cfg)
            return ejecutar_control_unicidad(
                df,
                group_cols=cfg["group_cols"],
                campo_objetivo=cfg["campo_objetivo"],
                umbral=cfg["umbral"],
            )
        except ValueError as e:
            return {
                "tipo_motor": "unicidad",
                "estado":     "ERROR",
                "error":      str(e),
            }
    else:
        return {
            "tipo_motor": cfg["tipo_motor"],
            "estado":     "NO_SOPORTADO",
            "error":      f"Motor '{cfg['tipo_motor']}' no implementado",
        }


def convertir_resultado_data_a_texto(resultado_data: Optional[Dict[str, Any]], max_muestra: int = 10) -> str:
    """
    Convierte resultado del motor de controles automáticos a texto.
    
    Parámetros:
        resultado_data: dict de salida del motor (o None)
        max_muestra: máximo de registros a mostrar en el detalle
    
    Retorna:
        String con el resultado formateado para insertar en prompts
    """
    if not resultado_data:
        return ""
    
    estado = resultado_data.get("estado", "DESCONOCIDO")
    
    if resultado_data.get("error"):
        return f"Control automático: ERROR — {resultado_data['error']}"
    
    tipo = resultado_data.get("tipo_motor", "automático")
    
    if estado == "PASA":
        return f"✅ Control automático ({tipo}): PASA — Sin hallazgos"
    elif estado == "NO PASA":
        grupos_falla = resultado_data.get("grupos_con_falla", 0)
        registros_falla = resultado_data.get("registros_fallidos", 0)
        
        resumen = f"⚠️ Control automático ({tipo}): NO PASA\n"
        resumen += f"  - Grupos evaluados: {resultado_data.get('grupos_evaluados', 0)}\n"
        resumen += f"  - Grupos con falla: {grupos_falla}\n"
        resumen += f"  - Registros fallidos: {registros_falla}\n"
        
        # Mostrar muestra de registros fallidos
        detalle = resultado_data.get("detalle")
        if detalle is not None and len(detalle) > 0:
            muestra = detalle.head(max_muestra)
            resumen += f"\n  Muestra de {min(max_muestra, len(detalle))} registros fallidos:\n"
            resumen += str(muestra) + "\n"
        
        return resumen
    else:
        return f"Control automático: {estado}"
