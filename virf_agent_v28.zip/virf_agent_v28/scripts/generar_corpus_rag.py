#!/usr/bin/env python3
"""
scripts/generar_corpus_rag.py
═══════════════════════════════════════════════════════════════════════════════
Genera un corpus de LITERATURA DE REFERENCIA en PDF para los cuatro dominios
RAG, a partir de marcos regulatorios públicos.

    python scripts/generar_corpus_rag.py            # genera los PDF
    python scripts/generar_corpus_rag.py --indexar  # genera + reindexa el RAG
    python scripts/generar_corpus_rag.py --listar    # solo muestra el catálogo

⚠️  NATURALEZA DE ESTOS DOCUMENTOS — LEER ANTES DE USAR
───────────────────────────────────────────────────────────────────────────────
Son RESÚMENES SECUNDARIOS redactados a partir de marcos regulatorios públicos.
NO son los textos oficiales, no los sustituyen y no tienen valor normativo.

Existen para que el RAG tenga contexto de dominio cuando no se dispone de la
documentación oficial. Cada PDF lleva un aviso en su primera página y en el pie
de cada página, de modo que si un fragmento se recupera e inyecta en un prompt,
el modelo vea la advertencia junto al contenido.

Antes de usar el agente para emitir un dictamen que se presente a un supervisor,
SUSTITUYE estos documentos por los textos oficiales. La referencia primaria de
cada uno está en su portada y en el campo `fuente` del catálogo de abajo.

Por qué es un generador y no ocho ficheros escritos a mano: el corpus se amplía
añadiendo entradas a CORPUS, se regenera con un comando y queda trazable qué
produjo cada documento.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

AVISO = (
    "RESUMEN SECUNDARIO — NO ES EL TEXTO OFICIAL. Documento de apoyo generado "
    "para dar contexto de dominio al agente VIRF. Sin valor normativo. "
    "Verificar siempre contra la fuente primaria indicada en la portada."
)

# ═════════════════════════════════════════════════════════════════════════════
# CATÁLOGO
# ═════════════════════════════════════════════════════════════════════════════
# Añadir un documento = añadir una entrada aquí y volver a ejecutar el script.
# Cada sección es (encabezado, [párrafos]).
# ═════════════════════════════════════════════════════════════════════════════

CORPUS: Dict[str, List[dict]] = {

    # ─────────────────────────────────────────────────────────────────────────
    "shared": [
        {
            "archivo": "SR_11-7_gestion_riesgo_modelo.pdf",
            "titulo": "Gestión del riesgo de modelo — marco SR 11-7",
            "fuente": "Board of Governors of the Federal Reserve System (SR 11-7) y "
                      "OCC Bulletin 2011-12, «Supervisory Guidance on Model Risk "
                      "Management», 4 de abril de 2011.",
            "secciones": [
                ("Definición de modelo y de riesgo de modelo", [
                    "Un modelo es un método cuantitativo, sistema o enfoque que aplica "
                    "teorías estadísticas, económicas, financieras o matemáticas para "
                    "transformar datos de entrada en estimaciones cuantitativas. Comprende "
                    "tres componentes: el componente de información (datos y supuestos de "
                    "entrada), el componente de procesamiento (que traduce las entradas en "
                    "estimaciones) y el componente de reporte (que traduce las estimaciones "
                    "en información útil para la gestión).",
                    "El riesgo de modelo es la posibilidad de consecuencias adversas "
                    "derivadas de decisiones basadas en modelos incorrectos o mal "
                    "utilizados. Tiene dos fuentes principales: (a) el modelo puede "
                    "presentar errores fundamentales y producir estimaciones inexactas "
                    "respecto a su propósito y diseño; (b) el modelo puede usarse de forma "
                    "incorrecta o inapropiada, o aplicarse fuera del ámbito para el que fue "
                    "concebido.",
                    "El riesgo de modelo aumenta con la mayor complejidad del modelo, la "
                    "mayor incertidumbre sobre sus entradas y supuestos, un uso más amplio "
                    "y un mayor impacto potencial. La gestión del riesgo de modelo no "
                    "consiste en eliminarlo, sino en identificarlo, medirlo y mitigarlo de "
                    "forma proporcional a su materialidad.",
                ]),
                ("Los tres elementos del marco de gestión", [
                    "Primero: desarrollo, implementación y uso robustos. El desarrollo debe "
                    "partir de un propósito claramente articulado, con diseño, teoría y "
                    "lógica documentados y sustentados en literatura y práctica aceptadas. "
                    "La calidad y relevancia de los datos deben evaluarse explícitamente, y "
                    "las limitaciones conocidas deben declararse.",
                    "Segundo: validación independiente y efectiva. La validación es el "
                    "conjunto de procesos y actividades destinados a verificar que los "
                    "modelos funcionan como se espera, en línea con sus objetivos de diseño "
                    "y su uso previsto. Debe identificar y evaluar limitaciones y supuestos, "
                    "y valorar su posible impacto.",
                    "Tercero: gobierno, políticas y controles. Incluye responsabilidades "
                    "claras del consejo y la alta dirección, políticas escritas, un "
                    "inventario de modelos, controles sobre cambios y una función de "
                    "auditoría interna que evalúe la efectividad global del marco.",
                ]),
                ("Componentes de la validación", [
                    "Evaluación de la solidez conceptual (conceptual soundness). Examina la "
                    "calidad del diseño y la construcción: revisión de la documentación y de "
                    "la evidencia empírica que respalda los métodos elegidos, las variables "
                    "seleccionadas y las relaciones supuestas. Debe verificarse que el juicio "
                    "experto utilizado está documentado y justificado. El análisis de "
                    "sensibilidad frente a cambios en entradas y parámetros es parte esencial "
                    "de este componente.",
                    "Monitoreo continuo (ongoing monitoring). Confirma que el modelo se "
                    "implementó adecuadamente y que sigue funcionando según lo previsto. "
                    "Incluye verificación de procesos, benchmarking contra alternativas y "
                    "seguimiento de cambios en productos, exposiciones, mercados o prácticas "
                    "que puedan invalidar los supuestos originales.",
                    "Análisis de resultados (outcomes analysis). Compara las salidas del "
                    "modelo con los resultados efectivamente observados. El backtesting es "
                    "una forma de análisis de resultados que contrasta las predicciones "
                    "frente a la realización, con métodos estadísticos que atienden tanto a "
                    "la magnitud del error como a su patrón temporal.",
                ]),
                ("Effective challenge e independencia", [
                    "El principio rector de la validación es el «effective challenge»: una "
                    "revisión crítica por personas con la competencia técnica suficiente, la "
                    "independencia necesaria y el incentivo adecuado para cuestionar el "
                    "modelo y, cuando corresponda, provocar su modificación.",
                    "La independencia no se demuestra únicamente por la posición en el "
                    "organigrama, sino por la ausencia de conflicto en los incentivos y por "
                    "la capacidad real de que las observaciones se traduzcan en cambios. La "
                    "compensación y los objetivos de quien valida no deben depender de la "
                    "aprobación del modelo.",
                    "La validación debe realizarse antes de la puesta en producción, "
                    "periódicamente durante la vida del modelo y de forma extraordinaria "
                    "cuando se produzcan cambios materiales en el modelo, en sus datos o en "
                    "el entorno de uso.",
                ]),
                ("Documentación e inventario", [
                    "La documentación insuficiente es una debilidad recurrente en la gestión "
                    "del riesgo de modelo. Debe ser suficientemente detallada para que una "
                    "persona competente ajena al desarrollo pueda comprender el modelo, "
                    "evaluar su idoneidad y, en principio, reproducir sus resultados.",
                    "La entidad debe mantener un inventario exhaustivo de todos los modelos "
                    "en uso, en desarrollo y recientemente retirados, con información sobre "
                    "propósito, uso, tipo de producto, responsables, fechas de validación y "
                    "restricciones de uso identificadas.",
                    "El uso de modelos de proveedores externos no reduce la responsabilidad "
                    "de la entidad: debe validar su idoneidad para el uso previsto, obtener "
                    "documentación suficiente y, cuando el proveedor no facilite los detalles "
                    "internos, reforzar el monitoreo continuo y el análisis de resultados.",
                ]),
            ],
        },
        {
            "archivo": "BCBS_239_agregacion_datos_riesgo.pdf",
            "titulo": "Principios para la agregación eficaz de datos de riesgo — BCBS 239",
            "fuente": "Basel Committee on Banking Supervision, «Principles for effective "
                      "risk data aggregation and risk reporting» (BCBS 239), enero de 2013.",
            "secciones": [
                ("Objeto y ámbito", [
                    "La crisis financiera evidenció que muchas entidades carecían de la "
                    "capacidad de agregar sus exposiciones al riesgo e identificar "
                    "concentraciones con rapidez y precisión a nivel de grupo, por línea de "
                    "negocio y entre entidades jurídicas. Las deficiencias en la "
                    "infraestructura de datos limitaron su capacidad de gestionar el riesgo.",
                    "El documento establece catorce principios organizados en cuatro "
                    "secciones: gobierno e infraestructura general; capacidades de agregación "
                    "de datos de riesgo; prácticas de reporte de riesgo; y revisión "
                    "supervisora, herramientas y cooperación.",
                ]),
                ("Gobierno e infraestructura (Principios 1 y 2)", [
                    "Principio 1 — Gobierno. Las capacidades de agregación de datos de "
                    "riesgo y las prácticas de reporte deben estar sujetas a acuerdos de "
                    "gobierno sólidos, coherentes con los demás principios y guías del "
                    "Comité. El consejo debe conocer las limitaciones que impiden una "
                    "agregación completa y sus implicaciones.",
                    "Principio 2 — Arquitectura de datos e infraestructura de TI. La entidad "
                    "debe diseñar, construir y mantener una arquitectura de datos e "
                    "infraestructura de TI que soporte plenamente sus capacidades de "
                    "agregación, no solo en condiciones normales sino también en situaciones "
                    "de estrés o crisis, manteniendo los demás principios.",
                ]),
                ("Capacidades de agregación (Principios 3 a 6)", [
                    "Principio 3 — Exactitud e integridad. Los datos de riesgo agregados "
                    "deben ser exactos y fiables. La agregación debe ser en gran medida "
                    "automatizada para minimizar la probabilidad de error, y debe existir un "
                    "«diccionario de datos» y una definición única de cada dato crítico. Los "
                    "ajustes manuales y las intervenciones ad hoc deben documentarse, "
                    "explicarse y estar sujetas a control.",
                    "Principio 4 — Completitud. La entidad debe poder capturar y agregar "
                    "todos los datos de riesgo materiales del grupo, con posibilidad de "
                    "desagregar por línea de negocio, entidad jurídica, tipo de activo, "
                    "industria, región y otras agrupaciones relevantes para el riesgo "
                    "analizado.",
                    "Principio 5 — Oportunidad. La entidad debe poder generar datos de riesgo "
                    "agregados y actualizados con la rapidez suficiente, respetando los "
                    "principios de exactitud, integridad, completitud y adaptabilidad. Los "
                    "plazos concretos dependen de la naturaleza y volatilidad del riesgo y de "
                    "su criticidad para el perfil de riesgo global.",
                    "Principio 6 — Adaptabilidad. Las capacidades deben permitir generar "
                    "datos agregados para satisfacer peticiones ad hoc de gestión del riesgo, "
                    "incluidas las que surgen en situaciones de estrés, cambios en la "
                    "regulación y necesidades de nuevos análisis.",
                ]),
                ("Prácticas de reporte (Principios 7 a 11)", [
                    "Principio 7 — Exactitud. Los informes de riesgo deben transmitir de "
                    "forma precisa y exacta los datos agregados y reflejar el riesgo de forma "
                    "fiel. Deben conciliarse y validarse.",
                    "Principio 8 — Comprensividad. Los informes deben cubrir todas las áreas "
                    "de riesgo materiales de la organización. La profundidad y el alcance "
                    "deben ser coherentes con el tamaño y la complejidad de las operaciones y "
                    "con el perfil de riesgo, así como con los requerimientos de los "
                    "destinatarios.",
                    "Principio 9 — Claridad y utilidad. Los informes deben comunicar la "
                    "información de forma clara y concisa, ser comprensibles y a la vez "
                    "suficientemente completos para permitir decisiones informadas. Deben "
                    "incluir explicación de los supuestos y de las limitaciones.",
                    "Principio 10 — Frecuencia. La frecuencia debe determinarse según las "
                    "necesidades de los destinatarios, la naturaleza del riesgo y la "
                    "velocidad a la que puede cambiar. En situaciones de estrés la frecuencia "
                    "debe poder incrementarse.",
                    "Principio 11 — Distribución. Los informes deben distribuirse a las "
                    "partes relevantes garantizando la confidencialidad, y llegar a tiempo "
                    "para permitir una respuesta eficaz.",
                ]),
                ("Implicaciones para la validación de un modelo", [
                    "Para un validador, BCBS 239 aporta el criterio con el que juzgar el "
                    "ámbito de calidad de datos: no basta con que los datos de entrada del "
                    "modelo «parezcan razonables». Debe existir linaje del dato, definición "
                    "única, controles automatizados, documentación de los ajustes manuales y "
                    "capacidad de reproducir la agregación.",
                    "Las deficiencias más frecuentemente observadas son la dependencia de "
                    "hojas de cálculo y procesos manuales no controlados, la ausencia de un "
                    "diccionario de datos, la imposibilidad de conciliar cifras entre "
                    "sistemas y la falta de evidencia de los controles de calidad ejecutados "
                    "sobre los datos que alimentan el modelo.",
                ]),
            ],
        },
        {
            "archivo": "validacion_interna_expectativas_supervisoras_UE.pdf",
            "titulo": "Validación interna de modelos — expectativas supervisoras en la UE",
            "fuente": "Reglamento (UE) 575/2013 (CRR), art. 185 y 189; EBA/GL/2017/16 "
                      "«Guidelines on PD estimation, LGD estimation and treatment of "
                      "defaulted exposures»; BCE, «Guide to internal models» (TRIM), 2019/2024.",
            "secciones": [
                ("Base normativa", [
                    "El artículo 185 del CRR exige a las entidades que utilicen métodos "
                    "basados en calificaciones internas validar la exactitud y coherencia de "
                    "sus sistemas de calificación, procesos y estimaciones de parámetros de "
                    "riesgo. La validación debe ser periódica y documentada.",
                    "El artículo 189 establece los requisitos de gobierno: la unidad de "
                    "control del riesgo de crédito debe ser independiente del personal y de "
                    "las funciones responsables de originar las exposiciones, y debe "
                    "participar activamente en el desarrollo, selección, implementación y "
                    "validación de los modelos.",
                ]),
                ("Independencia de la función de validación", [
                    "La independencia debe ser efectiva, no solo formal. Se espera "
                    "separación organizativa respecto al desarrollo del modelo, ausencia de "
                    "dependencia jerárquica de quien desarrolla, e incentivos que no estén "
                    "ligados a la aprobación del modelo ni a los resultados del negocio que "
                    "lo utiliza.",
                    "Cuando por razones de proporcionalidad la validación la realicen "
                    "personas que también participan en el desarrollo, deben existir "
                    "controles compensatorios documentados y una revisión independiente "
                    "adicional, y la limitación debe declararse explícitamente en el informe.",
                ]),
                ("Contenido mínimo del ejercicio de validación", [
                    "Revisión del diseño del modelo: justificación de la metodología "
                    "elegida frente a alternativas, adecuación de la definición del evento "
                    "modelizado, representatividad de la muestra de desarrollo respecto a la "
                    "cartera de aplicación, y tratamiento documentado de los datos "
                    "ausentes, atípicos y de las exclusiones.",
                    "Verificación del rendimiento: discriminación, calibración y "
                    "estabilidad. Deben aplicarse pruebas cuantitativas con umbrales "
                    "definidos ex ante y una interpretación documentada de los resultados, "
                    "no una simple enumeración de estadísticos.",
                    "Análisis de los supuestos: identificación explícita de los supuestos "
                    "materiales, contraste empírico cuando sea posible, y evaluación del "
                    "impacto de su incumplimiento mediante análisis de sensibilidad.",
                    "Revisión del uso efectivo: evidencia de que el modelo se utiliza en la "
                    "gestión (use test), coherencia entre el uso regulatorio y el uso "
                    "interno, y verificación de que las limitaciones identificadas se han "
                    "comunicado a los usuarios.",
                ]),
                ("Documentación y trazabilidad", [
                    "El expediente de validación debe permitir que un tercero competente "
                    "reconstruya el juicio emitido: qué se revisó, con qué datos, con qué "
                    "criterios, qué se concluyó y qué recomendaciones se emitieron, con su "
                    "seguimiento hasta el cierre.",
                    "Las deficiencias identificadas deben clasificarse por severidad, "
                    "asignarse a un responsable y tener plazo de remediación. La ausencia de "
                    "seguimiento de las recomendaciones de validaciones anteriores es una "
                    "debilidad recurrentemente señalada en las revisiones supervisoras.",
                    "La falta de evidencia documental no puede tratarse como conformidad "
                    "implícita: si no hay documentación que sustente un requisito, el "
                    "requisito no está acreditado, y el informe debe reflejarlo como tal.",
                ]),
            ],
        },
    ],

    # ─────────────────────────────────────────────────────────────────────────
    "VaR": [
        {
            "archivo": "FRTB_BCBS457_riesgo_mercado.pdf",
            "titulo": "Requerimientos mínimos de capital por riesgo de mercado — FRTB",
            "fuente": "Basel Committee on Banking Supervision, «Minimum capital "
                      "requirements for market risk» (BCBS 457), enero de 2019 "
                      "(revisión del marco publicado en BCBS 352, 2016).",
            "secciones": [
                ("Cambios estructurales respecto al marco anterior", [
                    "El marco revisado sustituye el Valor en Riesgo (VaR) al 99 % como "
                    "medida de capital por el Expected Shortfall (ES) al 97,5 %. La "
                    "motivación es que el VaR no captura el riesgo de cola: al ser un "
                    "cuantil, es insensible a la severidad de las pérdidas que lo exceden. "
                    "El ES, como media condicional de las pérdidas más allá del cuantil, sí "
                    "es sensible a la forma de la cola y además es una medida coherente "
                    "(subaditiva).",
                    "Se introduce una frontera más estricta y objetiva entre la cartera de "
                    "negociación y la cartera de inversión, para limitar el arbitraje "
                    "regulatorio entre ambas mediante reclasificaciones discrecionales.",
                    "La aprobación del modelo interno pasa a otorgarse a nivel de mesa de "
                    "negociación (trading desk) y no a nivel de entidad: una mesa que no "
                    "supere las pruebas debe calcular su capital por el método estándar, sin "
                    "que ello invalide la aprobación de las demás.",
                ]),
                ("Horizontes de liquidez", [
                    "El ES se calcula reconociendo que no todas las posiciones pueden "
                    "liquidarse en el mismo plazo. Los factores de riesgo se asignan a "
                    "categorías con horizontes de liquidez crecientes, y el ES total se "
                    "obtiene agregando los ES calculados sobre esos horizontes.",
                    "Esta construcción reemplaza el supuesto uniforme de 10 días del marco "
                    "anterior, que subestimaba el riesgo de posiciones en mercados poco "
                    "profundos. Para un validador, el punto crítico es la justificación "
                    "documentada de la asignación de cada factor a su categoría de "
                    "liquidez.",
                ]),
                ("Método estándar basado en sensibilidades", [
                    "El método estándar se compone de tres elementos: el método basado en "
                    "sensibilidades, el requerimiento por riesgo de impago (Default Risk "
                    "Charge, DRC) y el requerimiento por riesgos residuales (Residual Risk "
                    "Add-On, RRAO).",
                    "El método basado en sensibilidades agrega cargos de delta, vega y "
                    "curvatura por clase de riesgo (tipos de interés, spread de crédito, "
                    "renta variable, materias primas y tipo de cambio), aplicando "
                    "ponderaciones y correlaciones prescritas, y calculándose bajo tres "
                    "escenarios de correlación (alta, media y baja) de los que se toma el más "
                    "adverso.",
                    "El DRC captura el riesgo de impago súbito no recogido en las medidas "
                    "basadas en spreads. El RRAO cubre instrumentos con pagos exóticos o "
                    "riesgos difíciles de capturar mediante sensibilidades.",
                ]),
                ("Modelo interno: pruebas de admisión", [
                    "Una mesa que aspire a usar el modelo interno debe superar dos pruebas "
                    "de forma continuada. La primera es el backtesting del VaR a nivel de "
                    "mesa, con contraste del número de excedencias observadas frente a lo "
                    "esperado.",
                    "La segunda es la prueba de atribución de pérdidas y ganancias (P&L "
                    "Attribution Test, PLAT), que compara el P&L teórico generado por el "
                    "modelo de riesgo con el P&L hipotético de la mesa. Su propósito es "
                    "detectar si el modelo de riesgo captura los mismos factores que "
                    "efectivamente mueven el resultado: una mesa puede pasar el backtesting "
                    "y sin embargo estar usando un modelo que no explica su P&L.",
                    "Los factores de riesgo que no superan los criterios de "
                    "modelizabilidad (Non-Modellable Risk Factors, NMRF) —esencialmente por "
                    "falta de observaciones de precio reales y verificables con suficiente "
                    "frecuencia— reciben un requerimiento de capital calculado mediante "
                    "escenarios de estrés, no mediante el ES.",
                ]),
                ("Qué debe verificar la validación", [
                    "Que la asignación de factores a horizontes de liquidez está justificada "
                    "y documentada, y que se revisa periódicamente.",
                    "Que la clasificación de factores como modelizables o no modelizables se "
                    "sustenta en evidencia de precios reales observables, con criterios "
                    "documentados y trazabilidad de las fuentes.",
                    "Que existe evidencia del resultado del backtesting y del PLAT por mesa, "
                    "con seguimiento de las mesas en situación de incumplimiento y de las "
                    "consecuencias efectivamente aplicadas.",
                    "Que la frontera entre carteras está definida operativamente y que las "
                    "reclasificaciones se documentan, autorizan y reportan.",
                ]),
            ],
        },
        {
            "archivo": "backtesting_VaR_Kupiec_Christoffersen.pdf",
            "titulo": "Backtesting de modelos de riesgo de mercado — Kupiec, Christoffersen "
                      "y el marco supervisor de Basilea",
            "fuente": "Kupiec, P. (1995), «Techniques for Verifying the Accuracy of Risk "
                      "Measurement Models», Journal of Derivatives 3(2); Christoffersen, P. "
                      "(1998), «Evaluating Interval Forecasts», International Economic "
                      "Review 39(4); BCBS, «Supervisory framework for the use of backtesting» "
                      "(1996) y BCBS 457 (2019).",
            "secciones": [
                ("Planteamiento del problema", [
                    "Un modelo de VaR al nivel de confianza (1−p) predice que las pérdidas "
                    "excederán la cifra estimada en una proporción p de las observaciones. "
                    "El backtesting contrasta si la frecuencia y el patrón de esas "
                    "excedencias son compatibles con el modelo.",
                    "Una excedencia se define como el evento en que la pérdida efectiva "
                    "supera el VaR estimado para ese día. La serie de excedencias es una "
                    "secuencia de indicadores binarios. Un modelo correcto debe generar una "
                    "secuencia con dos propiedades: la proporción de unos debe ser p "
                    "(cobertura incondicional) y los unos deben ser independientes entre sí "
                    "(independencia).",
                ]),
                ("Prueba de cobertura incondicional de Kupiec (POF)", [
                    "Kupiec propone la prueba de proporción de fallos (Proportion of "
                    "Failures, POF), un contraste de razón de verosimilitud sobre la "
                    "hipótesis nula de que la probabilidad real de excedencia es igual a la "
                    "declarada.",
                    "Con T observaciones y N excedencias, el estadístico es "
                    "LR_uc = −2·ln[(1−p)^(T−N)·p^N] + 2·ln[(1−N/T)^(T−N)·(N/T)^N], que bajo "
                    "la hipótesis nula se distribuye asintóticamente como una chi-cuadrado "
                    "con un grado de libertad.",
                    "La prueba tiene poca potencia con muestras cortas: con 250 "
                    "observaciones y un nivel del 99 %, el número esperado de excedencias es "
                    "2,5, y el contraste difícilmente distingue un modelo correcto de uno "
                    "moderadamente mal calibrado. Esta limitación debe declararse al "
                    "interpretar el resultado; un p-valor no significativo con muestra corta "
                    "no acredita que el modelo sea correcto.",
                    "Kupiec propone además la prueba de tiempo hasta el primer fallo (Time "
                    "Until First Failure, TUFF), basada en la distribución geométrica del "
                    "número de periodos hasta la primera excedencia.",
                ]),
                ("Prueba de cobertura condicional de Christoffersen", [
                    "La prueba de Kupiec ignora el orden temporal: una secuencia con el "
                    "número correcto de excedencias todas agrupadas en una misma semana la "
                    "supera igual que una con las excedencias dispersas. Sin embargo, el "
                    "agrupamiento indica que el modelo no reacciona a los cambios de "
                    "volatilidad, que es precisamente el fallo más peligroso.",
                    "Christoffersen descompone la cobertura condicional en dos componentes: "
                    "LR_cc = LR_uc + LR_ind. El primero es la cobertura incondicional de "
                    "Kupiec; el segundo contrasta la independencia serial modelizando la "
                    "secuencia de excedencias como una cadena de Markov de primer orden y "
                    "contrastando que la probabilidad de excedencia no depende de si el día "
                    "anterior hubo excedencia.",
                    "El estadístico conjunto se distribuye asintóticamente como una "
                    "chi-cuadrado con dos grados de libertad. La descomposición permite "
                    "diagnosticar: un rechazo por LR_uc apunta a mala calibración del nivel; "
                    "un rechazo por LR_ind apunta a que el modelo no captura la dinámica de "
                    "la volatilidad.",
                ]),
                ("Marco supervisor de zonas de Basilea", [
                    "El marco supervisor establece una clasificación por número de "
                    "excedencias observadas en 250 días de negociación con un VaR al 99 %.",
                    "Zona verde: hasta 4 excedencias. Los resultados son compatibles con un "
                    "modelo correcto y no dan lugar por sí mismos a consecuencias.",
                    "Zona ámbar: entre 5 y 9 excedencias. El resultado es posible tanto con "
                    "un modelo correcto como con uno deficiente. Da lugar a un incremento "
                    "del factor multiplicador aplicable al requerimiento de capital, y el "
                    "supervisor evalúa la explicación aportada por la entidad.",
                    "Zona roja: 10 o más excedencias. Se presume que el modelo es "
                    "deficiente. El incremento del multiplicador es automático y el "
                    "supervisor puede exigir la corrección del modelo o retirar la "
                    "autorización de uso.",
                    "La clasificación no sustituye al análisis estadístico: es un "
                    "instrumento supervisor de aplicación mecánica. Un ejercicio de "
                    "validación debe aportar además los contrastes formales y su "
                    "interpretación.",
                ]),
                ("Buenas prácticas y errores frecuentes", [
                    "Debe distinguirse el backtesting sobre P&L hipotético (cartera "
                    "congelada, sin operaciones intradía ni comisiones) del realizado sobre "
                    "P&L real. El primero es el adecuado para juzgar el modelo de riesgo; "
                    "mezclarlos introduce en el contraste efectos ajenos al modelo.",
                    "Errores frecuentes: reportar el número de excedencias sin el contraste "
                    "estadístico; omitir la prueba de independencia y concluir que el modelo "
                    "es adecuado solo por la cobertura; no declarar la escasa potencia de "
                    "las pruebas con la muestra utilizada; y no documentar el tratamiento de "
                    "los días con datos incompletos o mercados cerrados.",
                    "El backtesting debe complementarse con pruebas de estrés y con "
                    "análisis de las excedencias individuales: la explicación de cada "
                    "excedencia observada es evidencia de validación tan relevante como el "
                    "estadístico agregado.",
                ]),
            ],
        },
    ],

    # ─────────────────────────────────────────────────────────────────────────
    "LaR": [
        {
            "archivo": "LCR_BCBS238_coeficiente_cobertura_liquidez.pdf",
            "titulo": "Coeficiente de cobertura de liquidez (LCR) — BCBS 238",
            "fuente": "Basel Committee on Banking Supervision, «Basel III: The Liquidity "
                      "Coverage Ratio and liquidity risk monitoring tools» (BCBS 238), "
                      "enero de 2013.",
            "secciones": [
                ("Definición y objetivo", [
                    "El LCR persigue que la entidad mantenga un colchón suficiente de "
                    "activos líquidos de alta calidad, libres de cargas y convertibles en "
                    "efectivo con rapidez y sin pérdida significativa de valor, para "
                    "sobrevivir a un escenario de estrés de liquidez de treinta días "
                    "naturales.",
                    "Se define como el cociente entre el stock de activos líquidos de alta "
                    "calidad (HQLA) y las salidas netas de efectivo previstas en un horizonte "
                    "de treinta días bajo el escenario de estrés prescrito, y debe ser al "
                    "menos del 100 % en condiciones normales.",
                    "El escenario combina un choque idiosincrásico y uno de mercado: bajada "
                    "de la calificación crediticia, retirada parcial de depósitos, pérdida de "
                    "financiación mayorista no garantizada, incremento de los recortes "
                    "aplicados al colateral y disposiciones inesperadas de líneas "
                    "comprometidas.",
                ]),
                ("Composición del stock de HQLA", [
                    "Los activos de Nivel 1 comprenden efectivo, reservas en el banco "
                    "central disponibles en estrés y determinados valores emitidos o "
                    "garantizados por soberanos, bancos centrales y entidades supranacionales "
                    "con el tratamiento más favorable. No están sujetos a límite de "
                    "participación ni a recorte de valoración.",
                    "Los activos de Nivel 2A comprenden determinados valores soberanos y de "
                    "empresas con calidad crediticia elevada, sujetos a un recorte de "
                    "valoración. Los de Nivel 2B incluyen instrumentos de menor calidad "
                    "admisibles con recortes mayores, como determinadas titulizaciones "
                    "hipotecarias residenciales, bonos corporativos de calificación inferior "
                    "y acciones que cumplan criterios estrictos.",
                    "El conjunto de activos de Nivel 2 está sujeto a un límite máximo sobre "
                    "el total del stock, y dentro de él los de Nivel 2B a un sublímite más "
                    "restrictivo. Los porcentajes concretos de recorte y de límite deben "
                    "verificarse en el texto oficial y en la transposición aplicable, que "
                    "puede diferir.",
                    "Requisitos operativos: los activos deben estar efectivamente "
                    "disponibles para la función de tesorería, libres de cargas legales y "
                    "operativas, y debe demostrarse periódicamente la capacidad de "
                    "monetizarlos.",
                ]),
                ("Salidas y entradas de efectivo", [
                    "Las salidas se calculan aplicando tasas de fuga prescritas a cada "
                    "categoría de pasivo y compromiso. Las tasas son crecientes con la "
                    "inestabilidad supuesta de la fuente: los depósitos minoristas estables "
                    "cubiertos por garantía de depósitos reciben la tasa más baja; los menos "
                    "estables, una superior; la financiación mayorista no garantizada de "
                    "entidades financieras recibe la tasa máxima.",
                    "Los depósitos operativos —vinculados a servicios de compensación, "
                    "custodia o gestión de tesorería— reciben una tasa reducida frente a los "
                    "no operativos, siempre que se acredite la vinculación operativa "
                    "mediante criterios objetivos y no meramente comerciales.",
                    "Las entradas se reconocen con límites: solo las contractualmente "
                    "exigibles en el horizonte y de contrapartes que se presumen cumplidoras, "
                    "y el total de entradas computables está limitado como porcentaje de las "
                    "salidas, de modo que siempre subsista un colchón mínimo de HQLA.",
                ]),
                ("Aspectos críticos para la validación de un modelo de liquidez", [
                    "La clasificación de depósitos entre estables, menos estables, "
                    "operativos y no operativos es el juicio con mayor impacto sobre el "
                    "resultado. Debe sustentarse en criterios documentados y en evidencia "
                    "empírica del comportamiento observado, no en la categorización comercial "
                    "de los productos.",
                    "Los supuestos de comportamiento aplicados por encima de los mínimos "
                    "regulatorios —por ejemplo, tasas de fuga internas para el marco de "
                    "apetito de riesgo— deben calibrarse con datos propios, contrastarse con "
                    "el comportamiento observado en episodios de tensión y someterse a "
                    "análisis de sensibilidad.",
                    "La disponibilidad efectiva de los HQLA debe acreditarse: activos "
                    "computados que estén pignorados, en jurisdicciones con restricciones a "
                    "la transferencia, o cuya monetización no se haya probado, no cumplen los "
                    "requisitos operativos aunque cumplan los de admisibilidad.",
                    "Debe verificarse la consistencia entre el LCR regulatorio y las métricas "
                    "internas de liquidez: divergencias no explicadas entre ambos indican que "
                    "uno de los dos no se está usando en la gestión.",
                ]),
            ],
        },
        {
            "archivo": "NSFR_BCBS295_financiacion_estable.pdf",
            "titulo": "Coeficiente de financiación estable neta (NSFR) — BCBS 295",
            "fuente": "Basel Committee on Banking Supervision, «Basel III: the net stable "
                      "funding ratio» (BCBS 295), octubre de 2014.",
            "secciones": [
                ("Objetivo y definición", [
                    "El NSFR complementa al LCR desplazando el foco del corto plazo a la "
                    "estructura de financiación a un año. Persigue que la entidad financie "
                    "sus actividades con fuentes suficientemente estables, limitando la "
                    "dependencia excesiva de financiación mayorista a corto plazo para "
                    "sostener activos de vencimiento largo o poca liquidez.",
                    "Se define como el cociente entre la financiación estable disponible "
                    "(Available Stable Funding, ASF) y la financiación estable requerida "
                    "(Required Stable Funding, RSF), y debe ser al menos del 100 % de forma "
                    "continuada.",
                ]),
                ("Financiación estable disponible", [
                    "El ASF se obtiene ponderando el capital y los pasivos por factores "
                    "crecientes con su estabilidad. El capital regulatorio y los pasivos con "
                    "vencimiento residual superior a un año reciben el factor máximo. Los "
                    "depósitos minoristas y de pequeñas empresas reciben factores elevados, "
                    "mayores en los considerados estables que en los menos estables, "
                    "reflejando el mismo juicio de comportamiento que en el LCR.",
                    "La financiación mayorista con vencimiento inferior a un año recibe "
                    "factores decrecientes según la contraparte y el plazo, y la procedente "
                    "de entidades financieras a corto plazo recibe el tratamiento menos "
                    "favorable.",
                ]),
                ("Financiación estable requerida", [
                    "El RSF se obtiene ponderando los activos y las exposiciones fuera de "
                    "balance por factores que reflejan la necesidad de financiación estable: "
                    "crecientes con el plazo y con la iliquidez del activo, y decrecientes "
                    "con su calidad crediticia y su facilidad de monetización.",
                    "El efectivo y los activos de máxima liquidez reciben factores mínimos; "
                    "los préstamos con vencimiento superior a un año y los activos "
                    "ilíquidos, factores máximos. Los activos gravados reciben un "
                    "tratamiento más exigente en función del plazo del gravamen.",
                    "Se aplica un tratamiento específico a los activos y pasivos "
                    "interdependientes, y a las exposiciones fuera de balance, que consumen "
                    "financiación estable en proporción a la probabilidad de disposición.",
                ]),
                ("Interacción con la modelización interna", [
                    "El NSFR es una métrica de cálculo prescrito, no un modelo estadístico. "
                    "Sin embargo, su resultado depende de clasificaciones que sí implican "
                    "juicio y con frecuencia se apoyan en modelos: la estabilidad de los "
                    "depósitos, la determinación del vencimiento efectivo de los depósitos "
                    "sin vencimiento contractual, y la probabilidad de disposición de "
                    "compromisos.",
                    "Para un validador, el ámbito de revisión no es la fórmula sino esas "
                    "clasificaciones: su justificación documentada, la evidencia empírica que "
                    "las sustenta, la coherencia con los supuestos usados en el LCR y en el "
                    "marco de IRRBB, y la existencia de controles sobre el proceso de "
                    "cálculo y sus ajustes manuales.",
                    "Las incoherencias entre marcos son un hallazgo relevante: si un mismo "
                    "depósito se considera estable a efectos de NSFR y volátil a efectos de "
                    "IRRBB sin una justificación que explique la diferencia, uno de los dos "
                    "supuestos no está bien fundamentado.",
                ]),
            ],
        },
    ],

    # ─────────────────────────────────────────────────────────────────────────
    "conductuales": [
        {
            "archivo": "IRRBB_modelos_conductuales_NMD.pdf",
            "titulo": "Riesgo de tipo de interés del balance (IRRBB) y modelos "
                      "conductuales de depósitos sin vencimiento",
            "fuente": "EBA/GL/2018/02 y su revisión EBA/GL/2022/14, «Guidelines on the "
                      "management of interest rate risk arising from non-trading book "
                      "activities»; BCBS 368, «Interest rate risk in the banking book» (2016).",
            "secciones": [
                ("El problema de los depósitos sin vencimiento", [
                    "Los depósitos sin vencimiento contractual (Non-Maturity Deposits, NMD) "
                    "son jurídicamente exigibles a la vista, pero empíricamente presentan "
                    "una permanencia elevada y una sensibilidad al tipo de interés muy "
                    "inferior a la del mercado. Tratarlos por su vencimiento contractual —a "
                    "un día— produce una medición del riesgo de tipo de interés carente de "
                    "sentido económico.",
                    "La modelización conductual asigna a estos depósitos un perfil de "
                    "repreciación y de vencimiento basado en el comportamiento observado. Es "
                    "la decisión de modelización con mayor impacto sobre las métricas de "
                    "IRRBB, y por tanto el foco principal de la validación.",
                ]),
                ("Descomposición núcleo / no núcleo", [
                    "La práctica habitual descompone el saldo en una parte estable "
                    "(núcleo), que se supone permanente e insensible al tipo, y una parte "
                    "volátil (no núcleo), que se trata como exigible a corto plazo y "
                    "sensible.",
                    "La determinación del núcleo debe basarse en series históricas "
                    "suficientemente largas que incluyan al menos un ciclo completo de tipos, "
                    "y debe distinguirse por segmento: los depósitos minoristas "
                    "transaccionales presentan mayor estabilidad que los minoristas no "
                    "transaccionales, y ambos mayor que los mayoristas.",
                    "Las directrices establecen límites máximos al plazo medio de "
                    "repreciación que puede asignarse a cada segmento, precisamente para "
                    "acotar el efecto de supuestos optimistas. Los valores concretos deben "
                    "verificarse en el texto vigente, ya que han sido objeto de revisión.",
                    "El pass-through —la proporción en que un movimiento del tipo de mercado "
                    "se traslada al tipo del depósito— debe estimarse empíricamente y puede "
                    "ser asimétrico: en la práctica, las subidas se trasladan en menor medida "
                    "y con mayor retardo que las bajadas. Un modelo que suponga simetría sin "
                    "contrastarla infraestima el riesgo.",
                ]),
                ("Modelización del prepago", [
                    "El prepago de préstamos es el segundo comportamiento material. Se mide "
                    "habitualmente mediante la tasa de prepago condicional (Conditional "
                    "Prepayment Rate, CPR) anualizada, o su equivalente mensual (Single "
                    "Monthly Mortality, SMM).",
                    "Los determinantes empíricos habituales son el incentivo de "
                    "refinanciación (diferencia entre el tipo contratado y el tipo de mercado "
                    "vigente), la antigüedad de la operación (seasoning), la estacionalidad, "
                    "el agotamiento del colectivo que ya tuvo incentivo y no lo ejerció "
                    "(burnout), la relación préstamo-valor y las penalizaciones "
                    "contractuales por amortización anticipada.",
                    "El prepago introduce convexidad negativa: cuando los tipos bajan, el "
                    "activo se amortiza anticipadamente y se reinvierte a tipos inferiores; "
                    "cuando suben, la duración se alarga. Un modelo de IRRBB que ignore esta "
                    "dependencia del prepago respecto al escenario de tipos subestima "
                    "sistemáticamente el riesgo.",
                ]),
                ("Escenarios y pruebas supervisoras", [
                    "El marco prescribe un conjunto de escenarios de choque de tipos de "
                    "aplicación obligatoria —desplazamiento paralelo al alza y a la baja, "
                    "aplanamiento, empinamiento, subida de los tipos a corto y bajada de los "
                    "tipos a corto— que deben aplicarse tanto a las métricas de valor "
                    "económico como a las de margen.",
                    "La prueba de valor atípico supervisora compara la variación del valor "
                    "económico del patrimonio bajo los escenarios con el capital de nivel 1, "
                    "y su superación obliga a explicar y, en su caso, a adoptar medidas. Los "
                    "umbrales concretos deben verificarse en el texto vigente.",
                    "Los supuestos conductuales deben aplicarse de forma consistente entre "
                    "escenarios, pero permitiendo que el comportamiento dependa del "
                    "escenario: mantener constante la tasa de prepago entre un escenario de "
                    "subida y uno de bajada de tipos contradice la evidencia empírica y "
                    "anula el efecto que la prueba pretende medir.",
                ]),
                ("Qué debe verificar la validación", [
                    "Que las series usadas para calibrar cubren al menos un ciclo completo "
                    "de tipos y que se ha evaluado la representatividad del periodo respecto "
                    "al entorno actual, especialmente tras episodios prolongados de tipos "
                    "próximos a cero.",
                    "Que existe backtesting de los supuestos conductuales: comparación de la "
                    "permanencia y el pass-through previstos frente a los observados, con "
                    "seguimiento periódico y umbrales de alerta definidos.",
                    "Que la asimetría del pass-through y la dependencia del prepago respecto "
                    "al escenario se han contrastado empíricamente, y que los resultados están "
                    "documentados aunque la conclusión sea que no se aplican.",
                    "Que los supuestos son consistentes con los utilizados en LCR, NSFR y "
                    "planificación de liquidez, y que cualquier divergencia está justificada "
                    "por la diferencia de propósito de cada marco.",
                ]),
            ],
        },
    ],
}


# ═════════════════════════════════════════════════════════════════════════════
# GENERACIÓN
# ═════════════════════════════════════════════════════════════════════════════

def _construir_pdf(destino: Path, doc: dict) -> int:
    """Genera un PDF. Devuelve el número de párrafos escritos."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    )

    estilos = getSampleStyleSheet()
    st_titulo = ParagraphStyle("T", parent=estilos["Title"], fontSize=17, leading=21,
                               spaceAfter=14, textColor=colors.HexColor("#1F3864"))
    st_h = ParagraphStyle("H", parent=estilos["Heading2"], fontSize=12.5, leading=16,
                          spaceBefore=14, spaceAfter=7,
                          textColor=colors.HexColor("#2E75B6"))
    st_p = ParagraphStyle("P", parent=estilos["BodyText"], fontSize=10, leading=14.5,
                          spaceAfter=8, alignment=4)          # 4 = justificado
    st_aviso = ParagraphStyle("A", parent=estilos["BodyText"], fontSize=8.5, leading=11,
                              textColor=colors.HexColor("#8B0000"))
    st_fuente = ParagraphStyle("F", parent=estilos["BodyText"], fontSize=9, leading=12.5,
                               textColor=colors.HexColor("#404040"))

    def _pie(canvas, documento):
        canvas.saveState()
        canvas.setFont("Helvetica", 6.8)
        canvas.setFillColor(colors.HexColor("#8B0000"))
        canvas.drawString(2 * cm, 1.2 * cm,
                          "RESUMEN SECUNDARIO — no es el texto oficial · "
                          "verificar contra la fuente primaria")
        canvas.setFillColor(colors.HexColor("#808080"))
        canvas.drawRightString(19 * cm, 1.2 * cm, f"pág. {documento.page}")
        canvas.restoreState()

    flujo = [Paragraph(doc["titulo"], st_titulo)]

    # El aviso va en un recuadro para que resulte imposible pasarlo por alto,
    # y su TEXTO viaja además en el cuerpo indexable: si el RAG recupera este
    # primer fragmento, el modelo lee la advertencia junto al contenido.
    tabla = Table([[Paragraph(f"<b>AVISO.</b> {AVISO}", st_aviso)]],
                  colWidths=[16.4 * cm])
    tabla.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.9, colors.HexColor("#8B0000")),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF4F4")),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    flujo += [tabla, Spacer(1, 0.5 * cm),
              Paragraph(f"<b>Fuente primaria:</b> {doc['fuente']}", st_fuente),
              Spacer(1, 0.4 * cm)]

    n = 0
    for encabezado, parrafos in doc["secciones"]:
        flujo.append(Paragraph(encabezado, st_h))
        for p in parrafos:
            flujo.append(Paragraph(p, st_p))
            n += 1

    SimpleDocTemplate(
        str(destino), pagesize=A4,
        leftMargin=2.3 * cm, rightMargin=2.3 * cm,
        topMargin=2 * cm, bottomMargin=2 * cm,
        title=doc["titulo"], author="Corpus de referencia RAG — Agente VIRF",
    ).build(flujo, onFirstPage=_pie, onLaterPages=_pie)
    return n


def generar(indexar: bool = False) -> None:
    total_docs = total_parrafos = 0
    for dominio, docs in CORPUS.items():
        destino_dir = RAIZ / "inputs" / "rag" / dominio
        destino_dir.mkdir(parents=True, exist_ok=True)
        print(f"\n─── {dominio} ───")
        for doc in docs:
            destino = destino_dir / doc["archivo"]
            n = _construir_pdf(destino, doc)
            kb = destino.stat().st_size / 1024
            print(f"  ✅ {doc['archivo']:52s} {n:2d} párrafos · {kb:5.1f} KB")
            total_docs += 1
            total_parrafos += n
    print(f"\n  {total_docs} documentos · {total_parrafos} párrafos")
    print("\n  ⚠️  Son RESÚMENES SECUNDARIOS. Sustitúyelos por los textos oficiales")
    print("      antes de emitir un dictamen que se presente a un supervisor.")

    if indexar:
        print("\n─── Reindexando el RAG ───")
        from src.rag.LaR.indexer import LaRIndexer
        from src.rag.VaR.indexer import VaRIndexer
        from src.rag.conductuales.indexer import ConductualesIndexer
        from src.rag.shared.indexer import SharedIndexer
        for Idx in (LaRIndexer, VaRIndexer, ConductualesIndexer, SharedIndexer):
            Idx().build_index(force_rebuild=True)


def listar() -> None:
    for dominio, docs in CORPUS.items():
        print(f"\n{dominio}:")
        for d in docs:
            print(f"  · {d['titulo']}")
            print(f"      archivo: {d['archivo']}")
            print(f"      fuente : {d['fuente'][:88]}...")
            print(f"      {len(d['secciones'])} secciones, "
                  f"{sum(len(p) for _, p in d['secciones'])} párrafos")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("⚠️")[0].strip())
    ap.add_argument("--indexar", action="store_true",
                    help="reconstruye los índices RAG tras generar los PDF")
    ap.add_argument("--listar", action="store_true",
                    help="muestra el catálogo sin generar nada")
    args = ap.parse_args()
    if args.listar:
        listar()
    else:
        generar(indexar=args.indexar)
