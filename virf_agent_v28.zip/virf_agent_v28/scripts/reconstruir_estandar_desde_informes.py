#!/usr/bin/env python3
"""
scripts/reconstruir_estandar_desde_informes.py
═══════════════════════════════════════════════════════════════════════════════
Reconstruye inputs/Estandares_VIRF.xlsx a partir de los informes ya emitidos.

    python scripts/reconstruir_estandar_desde_informes.py --listar
    python scripts/reconstruir_estandar_desde_informes.py --escribir

⛔ POR QUÉ EXISTE ESTE SCRIPT — LEER ANTES DE USARLO
───────────────────────────────────────────────────────────────────────────────
El 30/07/2026 se DESTRUYÓ inputs/Estandares_VIRF.xlsx. Causa: un barrido de
imports con `importlib` sobre todos los módulos del proyecto ejecutó el código
de nivel superior de `create_estandares_excel.py`, que sobrescribió el fichero
con un esqueleto de 3 filas. No había copia de seguridad y el proyecto no es un
repositorio git.

Los informes de `outputs/` conservan las actividades realmente evaluadas, así
que el texto de cada actividad y su ámbito SÍ son recuperables. Lo que NO se
puede recuperar de ningún sitio:

  · la matriz TIER I/II/III/IV — qué actividad se exige en cada tier;
  · las actividades que nunca aparecieron en un informe (las no requeridas en
    los tiers que llegaron a ejecutarse);
  · las columnas CONCEPTO y VALIDACIÓN_* del original.

⚠️  CONSECUENCIA QUE DEBES ASUMIR SI USAS ESTO
    Este script marca TODAS las actividades como requeridas en los CUATRO
    tiers, porque no hay forma de saber la matriz real. Eso significa que:

      · un modelo Tier 4 se evaluará con la exigencia de un Tier 1;
      · los scores NO son comparables con los de informes anteriores;
      · NINGUNA corrida es defendible ante un auditor hasta que un responsable
        revise y corrija la matriz de tiers a mano.

    El fichero generado lleva una hoja «AVISO» que documenta todo esto, para
    que la pérdida no se olvide al cabo de unas semanas.

    Si consigues el original (copia de seguridad, OneDrive, correo, la carpeta
    de un compañero), REPÓNLO y descarta lo que genere este script.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

DESTINO = RAIZ / "inputs" / "Estandares_VIRF.xlsx"
SALIDAS = RAIZ / "outputs"

# Orden canónico de los ámbitos (config/dominio.py es la fuente).
try:
    from config.dominio import AMBITO_PESOS
    ORDEN_AMBITOS = list(AMBITO_PESOS)
except Exception:                                    # pragma: no cover
    ORDEN_AMBITOS = []

# Marcadores de fila que NO es una actividad real del estándar.
_NO_ES_ACTIVIDAD = re.compile(
    r"^\s*(n/?a\b|—|-+$|sin evidencia|control_\d+)", re.IGNORECASE)


def _norm(s: str) -> str:
    """Normaliza para detectar variantes del mismo texto (erratas incluidas)."""
    s = re.sub(r"\s+", " ", str(s or "").strip().lower())
    return re.sub(r"[^\w áéíóúñü]", "", s)


def extraer() -> dict:
    """
    Recolecta (ámbito → control → actividad) de todos los informes emitidos.

    Se consolidan variantes: el estándar original se mantenía a mano y el mismo
    control aparecía escrito de varias formas, con erratas incluidas
    («sufiencia», «suficinecia»). Se conserva la grafía MÁS LARGA de cada
    variante, por ser normalmente la menos truncada.
    """
    por_ambito: dict = defaultdict(lambda: defaultdict(dict))
    n_informes = 0
    for f in sorted(SALIDAS.rglob("resultados_*.json")):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        n_informes += 1
        for ambito, evs in (d.get("resultados_por_ambito") or {}).items():
            for e in evs or []:
                act = str(e.get("actividad", "")).strip()
                ctrl = str(e.get("control", "")).strip()
                if not act or _NO_ES_ACTIVIDAD.match(act):
                    continue
                if ctrl.upper() in ("N/A", "NA", ""):
                    ctrl = "(control no registrado)"
                # Consolidar por forma normalizada, guardando la más larga.
                clave_ctrl = _norm(ctrl)
                grupo = por_ambito[ambito][clave_ctrl]
                grupo.setdefault("_control", ctrl)
                if len(ctrl) > len(grupo["_control"]):
                    grupo["_control"] = ctrl
                clave_act = _norm(act)
                actual = grupo.get(clave_act, "")
                if len(act) > len(actual):
                    grupo[clave_act] = act
    return {"informes": n_informes, "datos": por_ambito}


def filas(extraido: dict) -> list:
    """
    Aplana a filas: UNA por (ámbito, actividad).

    La deduplicación es por ACTIVIDAD, no por (control, actividad). El estándar
    original se mantenía a mano y el mismo control aparecía escrito de varias
    formas —«Verificar la existencia, sufiencia…», «Verifica la existencia,
    suficienci…»—, de modo que agrupar por control duplicaba la misma actividad
    tres veces. Y una actividad duplicada en el Excel se EVALÚA tres veces:
    triplica el coste y descuadra el promedio del ámbito.

    De las variantes de control se conserva la grafía más larga, por ser
    normalmente la menos truncada.
    """
    datos = extraido["datos"]
    orden = [a for a in ORDEN_AMBITOS if a in datos] + \
            [a for a in sorted(datos) if a not in ORDEN_AMBITOS]
    out = []
    for ambito in orden:
        vistas: dict = {}          # actividad normalizada → fila
        for grupo in datos[ambito].values():
            control = grupo["_control"]
            for k, act in sorted(grupo.items()):
                if k == "_control":
                    continue
                previa = vistas.get(k)
                if previa is None:
                    vistas[k] = {"ambito": ambito, "control": control,
                                 "actividad": act}
                else:
                    # Conservar las grafías más largas de ambos campos.
                    if len(act) > len(previa["actividad"]):
                        previa["actividad"] = act
                    if len(control) > len(previa["control"]):
                        previa["control"] = control
        out.extend(vistas.values())
    return out


def escribir(registros: list, n_informes: int) -> Path:
    """Genera el Excel con el formato que espera Mx_01.leer_estandares_virf()."""
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill

    wb = openpyxl.Workbook()

    # ── Hoja AVISO, la PRIMERA que se ve al abrir el fichero ────────────────
    # El lector la ignora (su nombre contiene una palabra de exclusión), así que
    # no interfiere con el parseo.
    av = wb.active
    av.title = "AVISO_LEEME"
    texto = [
        ("RECONSTRUCCIÓN PARCIAL — NO ES EL ESTÁNDAR ORIGINAL", True),
        ("", False),
        (f"Generado: {datetime.now():%Y-%m-%d %H:%M} por "
         f"scripts/reconstruir_estandar_desde_informes.py", False),
        (f"Fuente: {n_informes} informes de outputs/ · "
         f"{len(registros)} actividades recuperadas", False),
        ("", False),
        ("QUÉ PASÓ", True),
        ("El 30/07/2026 se destruyó inputs/Estandares_VIRF.xlsx: un barrido de "
         "imports ejecutó create_estandares_excel.py, que lo sobrescribió con un "
         "esqueleto de 3 filas. No había copia de seguridad.", False),
        ("", False),
        ("QUÉ SE RECUPERÓ", True),
        ("El ámbito, el control y el texto literal de cada actividad que apareció "
         "en algún informe emitido.", False),
        ("", False),
        ("QUÉ NO SE PUDO RECUPERAR", True),
        ("1. La matriz TIER I/II/III/IV: qué actividad se exige en cada tier.", False),
        ("2. Las actividades que nunca aparecieron en un informe.", False),
        ("3. Las columnas CONCEPTO y VALIDACIÓN_* del original.", False),
        ("", False),
        ("CONSECUENCIA — ACCIÓN REQUERIDA", True),
        ("Todas las actividades están marcadas como requeridas en los CUATRO "
         "tiers, porque no se conoce la matriz real. Por tanto:", False),
        ("  · un modelo Tier 4 se evalúa con la exigencia de un Tier 1;", False),
        ("  · los scores NO son comparables con informes anteriores;", False),
        ("  · NINGUNA corrida es defendible ante un auditor hasta que un "
         "responsable revise y corrija la matriz de tiers a mano.", False),
        ("", False),
        ("Si aparece el fichero original, REPÓNLO y descarta este.", True),
    ]
    for i, (linea, negrita) in enumerate(texto, start=1):
        c = av.cell(row=i, column=1, value=linea)
        c.font = Font(bold=negrita, size=12 if negrita and i == 1 else 10,
                      color="9C0006" if negrita else "000000")
        c.alignment = Alignment(wrap_text=True, vertical="top")
    av.column_dimensions["A"].width = 100

    # ── Hoja de estándares ──────────────────────────────────────────────────
    ws = wb.create_sheet("Estandares")
    cab = ["ÁMBITO", "CONTROL", "ACTIVIDAD",
           "TIER I", "TIER II", "TIER III", "TIER IV", "CONCEPTO"]
    ws.append(cab)
    for i, _ in enumerate(cab, start=1):
        c = ws.cell(row=1, column=i)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", start_color="1F3864")
    for r in registros:
        # "X" es el marcador que Mx_01 reconoce como requerida. Ojo: "Obligatorio"
        # NO está en su lista de valores válidos, así que escribirlo dejaría todo
        # como NO requerido y el filtro por tier quedaría vacío.
        ws.append([r["ambito"], r["control"], r["actividad"],
                   "X", "X", "X", "X", ""])
    for col, ancho in zip("ABCDEFGH", (30, 46, 76, 8, 9, 10, 9, 30)):
        ws.column_dimensions[col].width = ancho
    ws.freeze_panes = "A2"

    DESTINO.parent.mkdir(parents=True, exist_ok=True)
    wb.save(DESTINO)
    return DESTINO


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("⛔")[0].strip())
    ap.add_argument("--escribir", action="store_true",
                    help="escribe inputs/Estandares_VIRF.xlsx")
    ap.add_argument("--forzar", action="store_true",
                    help="sobrescribe aunque el destino ya exista")
    args = ap.parse_args()

    ext = extraer()
    regs = filas(ext)
    print(f"\n  {ext['informes']} informes analizados · "
          f"{len(regs)} actividades recuperadas\n")
    ambito_actual = None
    for r in regs:
        if r["ambito"] != ambito_actual:
            ambito_actual = r["ambito"]
            print(f"  {ambito_actual}")
        print(f"     · {r['actividad'][:88]}")

    if not args.escribir:
        print("\n  (solo listado — usa --escribir para generar el Excel)\n")
        return 0

    if DESTINO.exists() and not args.forzar:
        import openpyxl
        try:
            wb = openpyxl.load_workbook(DESTINO)
            n = sum(wb[h].max_row for h in wb.sheetnames)
        except Exception:
            n = "?"
        print(f"\n  ⛔ {DESTINO.name} ya existe ({n} filas en total).")
        print("     No se sobrescribe sin --forzar: si es el estándar original,")
        print("     reconstruirlo encima destruiría la matriz de tiers real.\n")
        return 1

    ruta = escribir(regs, ext["informes"])
    print(f"\n  ✅ Escrito: {ruta}")
    print("     Hoja 'AVISO_LEEME' con lo que se perdió · hoja 'Estandares' con")
    print("     las actividades recuperadas, TODAS requeridas en los 4 tiers.")
    print("\n  ⚠️  Un responsable debe revisar la matriz de tiers antes de emitir")
    print("      cualquier informe destinado a un auditor.\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
