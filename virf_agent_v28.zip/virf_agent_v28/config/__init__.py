"""
config/  [v27.2]
═════════════════════════════════════════════════════════════════════════════

CENTRAL DE CONFIGURACIÓN DEL AGENTE VIRF

Este paquete sustituye al antiguo `config.py` de la raíz. La API pública es
EXACTAMENTE la misma, así que todo el código existente sigue funcionando sin
cambios:

    from config import get_cliente_ia, AMBITO_PESOS, OUTPUTS_DIR

DÓNDE TOCAR CADA COSA
---------------------
    config/parametros.py   Todo lo ajustable por variable de entorno
                           (chunking, límites de lectura, caché, Excel, IA).
                           ÚNICA fuente de verdad: ningún otro módulo debe
                           declarar un `os.getenv` de negocio.

    config/rutas.py        Dónde vive cada carpeta y fichero del proyecto.

    config/dominio.py      Parámetros de negocio VIRF: pesos de ámbito con su
                           referencia regulatoria, escalas, semáforo, preguntas
                           metodológicas y tiers.

    config/ia.py           Clientes IA (Anthropic / Azure OpenAI), guardia
                           anti-fuga de credenciales y factory cacheada.

POR QUÉ ES UN PAQUETE Y NO UN MÓDULO
------------------------------------
Un paquete `config/` y un módulo `config.py` NO pueden convivir: Python
resuelve los paquetes ANTES que los módulos, así que el paquete gana y el
`config.py` de la raíz quedaría inalcanzable en silencio — con los 16
`from config import ...` del proyecto cargando otra cosa sin avisar.
Por eso `config.py` no se dejó "por si acaso": se movió aquí y el original
está archivado en `archivo/`. Ver README §4.
"""

from __future__ import annotations

# ─── Parámetros ajustables (env) ─────────────────────────────────────────────
from .parametros import (
    AGENTE_VERSION,
    ANTHROPIC_MAX_TOKENS,
    ANTHROPIC_MODELO,
    AZURE_API_VERSION,
    AZURE_MAX_TOKENS,
    CACHE_ENABLED,
    CACHE_LOCK_STALE,
    CACHE_LOCK_TIMEOUT,
    CHUNK_ENABLED,
    CHUNK_OVERLAP,
    CHUNK_SIZE,
    CHUNK_SIZE_MAX,
    CHUNK_THRESHOLD,
    DEBUG_PROMPTS,
    EXCEL_CHUNK_HOJA_UMBRAL,
    EXCEL_MAX_CELDAS_MUESTRA,
    EXCEL_MAX_FORMULAS_HOJA,
    EXCEL_NB_TIMEOUT,
    EXCEL_VALIDACION_TOL,
    IA_PROVEEDOR,
    MAX_CHARS_CODIGO,
    MAX_CHARS_DOC,
    MAX_CHUNKS,
    MAX_CTX,
    MAX_DOCS_AMBITO,
    MAX_FILAS_EXCEL,
    MAX_NIVELES,
    MIN_FEEDBACK_ANTISESGO,
    MIN_MUESTRAS_AJUSTE,
    MODO,
    PRESUPUESTO_DOC,
    RAG_MIN_SCORE,
    RAG_TOP_K,
    UMBRAL_SIN_SEGUNDA_REVISION,
    identidad_validador_entorno,
    VALIDADOR_CARGO,
    VALIDADOR_NOMBRE,
    REINTENTOS_API,
    TIMEOUT_SEGUNDOS,
    VALIDAR_CONEXION,
)

# ─── Rutas ───────────────────────────────────────────────────────────────────
from .rutas import (
    AUDIT_LOGS_DIR,
    BASE_DIR,
    CACHE_DIR,
    ESTANDARES_PATH,
    INPUTS,
    OUTPUTS_DIR,
    REPOSITORIO_INFORMES,
    VECTORDB_DIR,
    nombre_seguro,
)

# ─── Dominio VIRF ────────────────────────────────────────────────────────────
from .dominio import (
    AMBITO_PESOS,
    AMBITO_PESOS_REFS,
    ESCALA_PUNTAJE,
    EXTENSIONES_SOPORTADAS,
    PREGUNTAS_METODOLOGICAS,
    SCORE_SEMAFORO,
    TIER_COLUMNS,
    TIERS_VALIDOS,
    normalizar_tier,
)

# ─── Clientes IA ─────────────────────────────────────────────────────────────
from .ia import (
    prueba_de_humo,
    FABRICAS,
    METADATOS_PROVEEDOR,
    ClienteAnthropicIA,
    ClienteAzureOpenAIIA,
    ClienteIA,
    _detectar_key_en_example,
    get_cliente_ia,
    metadatos_proveedor,
    reset_cliente_ia,
)


def mostrar_configuracion() -> None:
    """Muestra resumen de la configuración actual"""
    print("\n" + "=" * 80)
    print("📋 CONFIGURACIÓN AGENTE VIRF")
    print("=" * 80)
    print(f"  🤖 Proveedor IA:     {IA_PROVEEDOR.upper()}")
    print(f"  🔧 Max tokens:       {MAX_CHARS_DOC} (doc) / {MAX_CHARS_CODIGO} (código)")
    print(f"  📂 Base dir:         {BASE_DIR}")
    print(f"  📊 Estandares:       {ESTANDARES_PATH.name}")
    print(f"  💾 Outputs:          {OUTPUTS_DIR}")
    print(f"  ✂️  Chunking:         {MAX_CHUNKS} segmentos máx. / {CHUNK_SIZE:,} chars")
    print("=" * 80 + "\n")


# Validar configuración al importar
try:
    if not ESTANDARES_PATH.exists():
        print(f"⚠️  Advertencia: {ESTANDARES_PATH} no encontrado")
except Exception:
    pass


__all__ = [
    # Rutas
    "BASE_DIR", "ESTANDARES_PATH", "OUTPUTS_DIR", "AUDIT_LOGS_DIR",
    "INPUTS", "REPOSITORIO_INFORMES", "CACHE_DIR", "VECTORDB_DIR",

    # Parámetros generales
    "MAX_CHARS_DOC", "MAX_CHARS_CODIGO", "MAX_FILAS_EXCEL",
    "TIMEOUT_SEGUNDOS", "REINTENTOS_API",
    "IA_PROVEEDOR", "MODO", "AGENTE_VERSION",
    "MAX_CTX", "MAX_DOCS_AMBITO",

    # Proveedor IA
    "ANTHROPIC_MODELO", "ANTHROPIC_MAX_TOKENS", "VALIDAR_CONEXION",
    "AZURE_API_VERSION", "AZURE_MAX_TOKENS",

    # Chunking
    "CHUNK_SIZE", "CHUNK_OVERLAP", "CHUNK_THRESHOLD", "MAX_CHUNKS",
    "CHUNK_SIZE_MAX", "MAX_NIVELES", "PRESUPUESTO_DOC", "CHUNK_ENABLED",

    # Caché
    "CACHE_ENABLED", "CACHE_LOCK_TIMEOUT", "CACHE_LOCK_STALE",

    # Excel
    "EXCEL_MAX_CELDAS_MUESTRA", "EXCEL_MAX_FORMULAS_HOJA",
    "EXCEL_CHUNK_HOJA_UMBRAL", "EXCEL_VALIDACION_TOL", "EXCEL_NB_TIMEOUT",

    # Diagnóstico
    "DEBUG_PROMPTS", "MIN_FEEDBACK_ANTISESGO",

    # Dominio
    "MIN_MUESTRAS_AJUSTE", "RAG_TOP_K", "RAG_MIN_SCORE",
    "VALIDADOR_NOMBRE", "VALIDADOR_CARGO", "UMBRAL_SIN_SEGUNDA_REVISION",
    "identidad_validador_entorno", "nombre_seguro",
    "TIER_COLUMNS", "TIERS_VALIDOS", "normalizar_tier", "AMBITO_PESOS", "AMBITO_PESOS_REFS", "ESCALA_PUNTAJE",
    "SCORE_SEMAFORO", "PREGUNTAS_METODOLOGICAS", "EXTENSIONES_SOPORTADAS",

    # Funciones
    "get_cliente_ia", "prueba_de_humo", "reset_cliente_ia", "mostrar_configuracion",

    # Clientes
    "ClienteIA", "ClienteAnthropicIA", "ClienteAzureOpenAIIA", "FABRICAS",

    # Metadatos de proveedor — para mensajes que no asuman uno concreto
    "METADATOS_PROVEEDOR", "metadatos_proveedor",
]
