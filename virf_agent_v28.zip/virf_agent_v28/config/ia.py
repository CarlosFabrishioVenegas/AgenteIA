"""
config/ia.py  [v27.2]
═════════════════════════════════════════════════════════════════════════════
Clientes IA: interfaz agnóstica de proveedor + factory con caché de proceso.

Soporta Anthropic Claude y Azure OpenAI. Los SDK se importan de forma perezosa
dentro de cada constructor: importar este módulo NO exige tener instalados
ambos proveedores.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from typing import Optional

from .parametros import (
    ANTHROPIC_MAX_TOKENS,
    ANTHROPIC_MODELO,
    AZURE_API_VERSION,
    AZURE_MAX_TOKENS,
    IA_PROVEEDOR,
    VALIDAR_CONEXION,
)
from .rutas import BASE_DIR

__all__ = [
    "ClienteIA", "ClienteAnthropicIA", "ClienteAzureOpenAIIA",
    "FABRICAS", "get_cliente_ia", "reset_cliente_ia",
    "prueba_de_humo",
    "METADATOS_PROVEEDOR", "metadatos_proveedor",
]


def _detectar_key_en_example(api_key: str) -> Optional[str]:
    """
    [SEC-FIX] Devuelve la ruta de .env.example si la clave activa aparece
    literalmente en él (indicio de clave real commiteada). None si está limpio.

    Se compara solo si la clave tiene pinta de credencial real (>20 chars),
    para no disparar falsos positivos con placeholders cortos.
    """
    if not api_key or len(api_key) < 20:
        return None
    ejemplo = BASE_DIR / ".env.example"
    try:
        if ejemplo.exists() and api_key in ejemplo.read_text(
            encoding="utf-8", errors="ignore"
        ):
            return str(ejemplo)
    except Exception:
        pass
    return None


class ClienteIA(ABC):
    """Interfaz abstracta para clientes IA"""

    @abstractmethod
    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        """
        Genera respuesta. Devuelve SIEMPRE `str`.

        `formato_json=True` pide al proveedor JSON sintácticamente válido si lo
        soporta (Azure OpenAI sí; Anthropic no). Los clientes que no lo
        soporten deben IGNORARLO, nunca fallar: el negocio no puede depender de
        qué proveedor hay detrás.
        """

    # [AUDIT-FIX] `validar_conexion()` solo devolvía True/False y el motivo se
    # perdía: get_cliente_ia() levantaba entonces un RuntimeError genérico
    # ("No se pudo conectar a ANTHROPIC") sin rastro del 401. El PRE-FLIGHT de
    # agente.py decide abortar-o-seguir buscando "401" en ese mensaje, así que
    # una clave rechazada se tomaba por un corte de red pasajero: la corrida
    # continuaba, cargaba toda la evidencia y moría 300 líneas después con un
    # traceback crudo. Se conserva el motivo para que el llamante pueda decidir.
    ultimo_error_conexion: str = ""

    @abstractmethod
    def validar_conexion(self) -> bool:
        """Valida conexión a la API. El motivo del fallo queda en
        `ultimo_error_conexion`."""


# ─── Anthropic Claude ──────────────────────────────────────────────────────

class ClienteAnthropicIA(ClienteIA):
    """Cliente para Anthropic Claude"""

    def __init__(self):
        try:
            import anthropic
        except ImportError:
            raise ImportError("❌ pip install anthropic")

        api_key = os.getenv("ANTHROPIC_API_KEY", "")

        # [v17] Detectar keys vacías O placeholders antes de cualquier llamada API
        _PLACEHOLDERS = {
            "TU_API_KEY_AQUI", "YOUR_REAL_API_KEY_HERE_NEVER_COMMIT",
            "tu-api-key", "tu_api_key", "xxx",
        }
        es_placeholder = (
            not api_key
            or api_key in _PLACEHOLDERS
            or any(p in api_key for p in (
                "YOUR_REAL", "TU_API_KEY", "NEVER_COMMIT",
                "your_key", "placeholder",
            ))
        )
        if es_placeholder:
            raise ValueError(
                "\n"
                "❌ ANTHROPIC_API_KEY no está configurada o contiene un placeholder.\n"
                "\n"
                "   Cómo solucionarlo:\n"
                "   1. Abre el archivo  .env  en la raíz del proyecto.\n"
                "   2. Reemplaza:\n"
                "        ANTHROPIC_API_KEY=TU_API_KEY_AQUI\n"
                "      por tu clave real de Anthropic:\n"
                "        ANTHROPIC_API_KEY=sk-ant-api03-...\n"
                "   3. Obtén tu clave en: https://console.anthropic.com/\n"
            )

        # [SEC-FIX] Guardia anti-fuga: si la clave activa es la misma que aparece
        # en .env.example, significa que alguien commiteó una clave real (o que
        # el usuario copió la plantilla sin cambiarla). Abortamos y avisamos.
        _leak = _detectar_key_en_example(api_key)
        if _leak:
            raise ValueError(
                "\n"
                "🔴 RIESGO DE SEGURIDAD: la ANTHROPIC_API_KEY en uso es idéntica a\n"
                f"   la que aparece en {_leak}\n"
                "\n"
                "   .env.example SE COMMITEA al repositorio → esa clave está expuesta.\n"
                "\n"
                "   Acciones requeridas:\n"
                "   1. Revoca la clave en https://console.anthropic.com/settings/keys\n"
                "   2. Genera una nueva y ponla SOLO en .env (nunca en .env.example)\n"
                "   3. Deja en .env.example el placeholder: ANTHROPIC_API_KEY=TU_API_KEY_AQUI\n"
            )

        self.cliente = anthropic.Anthropic(api_key=api_key)
        self.modelo = ANTHROPIC_MODELO
        self.max_tokens_default = ANTHROPIC_MAX_TOKENS

    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        """
        Genera mensaje con soporte para parámetros alternativos.

        `formato_json` se ACEPTA e IGNORA: la API de Anthropic no tiene un
        equivalente a `response_format={"type":"json_object"}`. Ignorarlo —en
        vez de fallar— es lo que permite que el código de negocio pida JSON
        garantizado sin saber qué proveedor hay detrás; con Anthropic el
        respaldo sigue siendo el parser robusto (`_extraer_json`).
        """
        sys_prompt = sistema or instruccion_sistema or "Eres un auditor experto."
        tokens = max_tokens or self.max_tokens_default

        try:
            response = self.cliente.messages.create(
                model=self.modelo,
                max_tokens=tokens,
                system=sys_prompt,
                messages=[{"role": "user", "content": prompt}],
            )
        except Exception as e:
            raise RuntimeError(f"❌ Error Anthropic: {e}")

        # [AUDIT-FIX] `content` puede llegar VACÍO — la API responde 200 con
        # content=[] cuando el modelo rehúsa la petición (stop_reason="refusal")
        # o cuando max_tokens no deja sitio para el primer bloque. Antes esto
        # era `content[0].text` dentro del try: el IndexError salía disfrazado
        # de "❌ Error Anthropic: list index out of range", que no dice nada al
        # operador y parece un fallo de red.
        contenido = getattr(response, "content", None) or []
        if not contenido:
            motivo = getattr(response, "stop_reason", None) or "desconocido"
            raise RuntimeError(
                f"❌ Anthropic devolvió una respuesta VACÍA (stop_reason={motivo}). "
                f"No se recibió texto que evaluar. Causas habituales: el modelo "
                f"rehusó la petición, o max_tokens={tokens} es demasiado bajo."
            )

        texto = getattr(contenido[0], "text", None)
        if texto is None:
            tipo = getattr(contenido[0], "type", type(contenido[0]).__name__)
            raise RuntimeError(
                f"❌ Anthropic devolvió un bloque de tipo '{tipo}' sin campo "
                f"'text'. La respuesta no es utilizable como evaluación."
            )
        return texto

    def validar_conexion(self) -> bool:
        try:
            self.cliente.messages.create(
                model=self.modelo,
                max_tokens=100,
                system="Test",
                messages=[{"role": "user", "content": "test"}],
            )
            self.ultimo_error_conexion = ""
            return True
        except Exception as e:
            self.ultimo_error_conexion = f"{type(e).__name__}: {e}"
            print(f"⚠️  Validación Anthropic: {e}")
            return False


# ─── Azure OpenAI ────────────────────────────────────────────────────────

# ═════════════════════════════════════════════════════════════════════════════
# REINTENTO ANTE LÍMITE DE CUOTA
# ═════════════════════════════════════════════════════════════════════════════
# [AZURE 2026-07-30] La cuota de Azure es POR DEPLOYMENT (TPM/RPM) y la fija
# quien despliega, no la organización. El chunker hace hasta 40 llamadas
# seguidas para un manual grande, así que el 429 no es un caso excepcional: es
# lo esperable con un deployment de TPM modesto.
#
# Sin esto, ese 429 abortaba la corrida a mitad del chunking —con la extracción
# y las llamadas previas ya pagadas— y la actividad quedaba como fallo técnico.
#
# `REINTENTOS_API` estaba declarado en config/parametros.py desde hacía tiempo y
# NO LO LEÍA NADIE: un mando de configuración conectado a nada, que es peor que
# no ofrecerlo porque promete un control que no existe. Es el mismo defecto que
# el proyecto ya corrigió con RAG_TOP_K.
#
# ⚠️ Esto NO es un fallback entre proveedores —la política lo prohíbe—: es
# reintentar contra el MISMO proveedor, que es exactamente lo que la propia API
# pide al enviar `Retry-After`.
_ERRORES_TRANSITORIOS = ("429", "503", "rate limit", "too many requests",
                         "temporarily unavailable", "server_error")


def _es_transitorio(exc: Exception) -> bool:
    texto = str(exc).lower()
    return any(marca in texto for marca in _ERRORES_TRANSITORIOS)


def _espera_sugerida(exc: Exception, intento: int) -> float:
    """
    Segundos a esperar. Prefiere el `Retry-After` del servidor.

    El jitter aleatorio evita que varias corridas simultáneas reintenten en el
    mismo instante y vuelvan a saturar la cuota — el problema del rebaño.
    """
    import random
    for attr in ("retry_after", "retry_after_ms"):
        valor = getattr(exc, attr, None)
        if valor:
            try:
                seg = float(valor)
                return seg / 1000.0 if attr.endswith("_ms") else seg
            except (TypeError, ValueError):
                pass
    resp = getattr(exc, "response", None)
    cabeceras = getattr(resp, "headers", None) or {}
    try:
        if "retry-after" in {k.lower() for k in cabeceras}:
            for k, v in cabeceras.items():
                if k.lower() == "retry-after":
                    return float(v)
    except (TypeError, ValueError):
        pass
    return min(2 ** intento + random.random(), 60.0)


def _con_reintento(fn, intentos: Optional[int] = None):
    """Ejecuta `fn`, reintentando ante errores transitorios de cuota."""
    import time
    from .parametros import REINTENTOS_API
    total = intentos if intentos is not None else REINTENTOS_API
    total = max(1, int(total))
    ultimo = None
    for i in range(total):
        try:
            return fn()
        except Exception as exc:                      # noqa: BLE001
            ultimo = exc
            if not _es_transitorio(exc) or i == total - 1:
                raise
            espera = _espera_sugerida(exc, i)
            print(f"  ⏳ Cuota del proveedor agotada ({type(exc).__name__}): "
                  f"reintento {i + 1}/{total - 1} en {espera:.1f}s")
            time.sleep(espera)
    raise ultimo                                       # pragma: no cover


class ClienteAzureOpenAIIA(ClienteIA):
    """Cliente para Azure OpenAI"""

    def __init__(self):
        try:
            from openai import AzureOpenAI
        except ImportError:
            raise ImportError("❌ pip install openai")

        api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
        deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")

        if not api_key:
            raise ValueError("❌ AZURE_OPENAI_API_KEY no configurada")
        if not endpoint:
            raise ValueError("❌ AZURE_OPENAI_ENDPOINT no configurado")
        if not deployment:
            raise ValueError("❌ AZURE_OPENAI_DEPLOYMENT no configurado")

        self.cliente = AzureOpenAI(
            api_key=api_key,
            api_version=AZURE_API_VERSION,
            azure_endpoint=endpoint,
        )
        self.deployment = deployment
        self.max_tokens_default = AZURE_MAX_TOKENS

        # ── Estado que se resuelve en la PRIMERA llamada real ───────────────
        # No se puede saber de antemano qué modelo sirve un deployment: el
        # nombre lo elige quien despliega ('gpt4o-virf-prod' no dice nada). Y
        # de ese modelo dependen dos cosas que rompen la llamada si se
        # adivinan mal: el nombre del parámetro de límite de tokens y si
        # admite `temperature`. Se negocian contra el servidor y se memorizan.
        self._modelo_real: Optional[str] = None
        self._perfil = None
        self._param_tokens: Optional[str] = None
        self._admite_temperature: Optional[bool] = None

    # ── Detección del modelo real ───────────────────────────────────────────

    def detectar_modelo_deployment(self, forzar: bool = False) -> Optional[str]:
        """
        Consulta a la API qué modelo sirve realmente el deployment.

        `response.model` devuelve el modelo CON su fecha de versión
        ('gpt-4o-2024-11-20'), que es el dato del que dependen el contexto
        máximo, los parámetros admitidos y el precio. El nombre del deployment
        no lo dice: lo elige quien despliega.

        Se cachea: esta llamada cuesta dinero y el modelo de un deployment no
        cambia a mitad de corrida.

        Devuelve None si no se pudo determinar (sin credencial, sin red…), sin
        lanzar: la detección es un refuerzo, no un requisito para operar.
        """
        if self._modelo_real and not forzar:
            return self._modelo_real
        try:
            r = self.cliente.chat.completions.create(
                model=self.deployment,
                messages=[{"role": "user", "content": "ping"}],
                **{self._param_tokens or "max_tokens": 5},
            )
            self._modelo_real = getattr(r, "model", None) or self.deployment
        except Exception as exc:
            # Si falló por el parámetro de tokens, se reintenta con el otro:
            # es justamente el caso que la detección debe resolver.
            if "max_tokens" in str(exc) or "max_completion_tokens" in str(exc):
                otro = ("max_completion_tokens"
                        if (self._param_tokens or "max_tokens") == "max_tokens"
                        else "max_tokens")
                try:
                    r = self.cliente.chat.completions.create(
                        model=self.deployment,
                        messages=[{"role": "user", "content": "ping"}],
                        **{otro: 5})
                    self._param_tokens = otro
                    self._modelo_real = getattr(r, "model", None) or self.deployment
                except Exception:
                    return None
            else:
                return None

        from config.modelos import perfil_modelo
        self._perfil = perfil_modelo(self._modelo_real)
        if self._param_tokens is None:
            self._param_tokens = self._perfil.param_tokens
        if self._admite_temperature is None:
            self._admite_temperature = self._perfil.admite_temperature
        return self._modelo_real

    @property
    def perfil(self):
        """Perfil del modelo (config/modelos.py). Conservador si no se detectó."""
        if self._perfil is None:
            from config.modelos import perfil_modelo
            self._perfil = perfil_modelo(self._modelo_real, verbose=False)
        return self._perfil

    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        """Genera mensaje con soporte para parámetros alternativos.

        [v18] BUG FIX: el parámetro 'system' no existe en chat.completions.create()
        de Azure OpenAI. El sistema debe enviarse como primer mensaje con
        role='system' dentro del array messages.

        `formato_json=True` activa `response_format={"type":"json_object"}`, que
        garantiza JSON sintácticamente válido del lado del servidor.
        """
        sys_prompt = sistema or instruccion_sistema or "Eres un auditor experto."
        tokens = max_tokens or self.max_tokens_default
        mensajes = [
            {"role": "system", "content": sys_prompt},
            {"role": "user",   "content": prompt},
        ]

        extra = {}
        if formato_json:
            # [AZURE] Garantiza JSON sintácticamente válido en el servidor.
            # Elimina de raíz los fallos de parseo por markdown fences, prosa
            # previa u objetos concatenados que este proyecto ya sufrió (ver el
            # AUDIT-FIX de Mx_03._parsear_json). Anthropic no tiene equivalente,
            # así que el parser robusto se conserva para el proveedor secundario.
            # Requisito de la API: el prompt debe mencionar «JSON».
            extra["response_format"] = {"type": "json_object"}

        # ── Negociación del parámetro de límite de tokens ───────────────────
        # Los modelos de razonamiento (o1/o3/GPT-5) RECHAZAN `max_tokens` y
        # exigen `max_completion_tokens`. Detectarlo por el nombre del
        # deployment no sirve: lo elige el usuario y puede llamarse como quiera.
        # Se intenta y se adapta, memorizando el resultado para no pagar el
        # reintento en cada una de las ~40 llamadas del chunker.
        candidatos = ([self._param_tokens] if self._param_tokens
                      else ["max_tokens", "max_completion_tokens"])
        ultimo = None
        response = None
        for nombre_param in candidatos:
            try:
                response = _con_reintento(
                    lambda p=nombre_param: self.cliente.chat.completions.create(
                        model=self.deployment, messages=mensajes,
                        **{p: tokens}, **extra))
                self._param_tokens = nombre_param
                break
            except Exception as e:
                ultimo = e
                texto_err = str(e)
                if ("max_tokens" in texto_err or "max_completion_tokens" in texto_err) \
                        and len(candidatos) > 1:
                    continue          # parámetro no soportado: probar el otro
                raise RuntimeError(f"❌ Error Azure OpenAI: {e}") from e
        if response is None:
            raise RuntimeError(
                f"❌ Azure OpenAI rechazó ambos parámetros de límite de tokens "
                f"(max_tokens y max_completion_tokens). Último error: {ultimo}"
            ) from ultimo

        # Memorizar el modelo real en la primera respuesta útil: viene gratis.
        if self._modelo_real is None:
            self._modelo_real = getattr(response, "model", None)

        # [AUDIT-FIX] Mismo blindaje que en Anthropic: `choices` puede venir
        # vacío (filtro de contenido) y `.content` puede ser None.
        opciones = getattr(response, "choices", None) or []
        if not opciones:
            raise RuntimeError(
                "❌ Azure OpenAI devolvió una respuesta SIN opciones (choices=[]). "
                "Causa habitual: el filtro de contenido bloqueó la petición."
            )
        texto = getattr(getattr(opciones[0], "message", None), "content", None)
        if texto is None:
            razon = getattr(opciones[0], "finish_reason", "desconocida")
            raise RuntimeError(
                f"❌ Azure OpenAI devolvió una opción sin texto "
                f"(finish_reason={razon}). La respuesta no es utilizable."
            )
        return texto

    def validar_conexion(self) -> bool:
        try:
            self.cliente.chat.completions.create(
                model=self.deployment,
                max_tokens=100,
                messages=[{"role": "user", "content": "test"}],
            )
            self.ultimo_error_conexion = ""
            return True
        except Exception as e:
            # [AUDIT-FIX] Este `except Exception: return False` era mudo: un
            # usuario de Azure con la clave mal puesta no veía NADA, ni siquiera
            # el aviso que sí tenía el cliente de Anthropic.
            self.ultimo_error_conexion = f"{type(e).__name__}: {e}"
            print(f"⚠️  Validación Azure OpenAI: {e}")
            return False


# ═════════════════════════════════════════════════════════════════════════════
# FACTORY: Crear cliente según proveedor
# ═════════════════════════════════════════════════════════════════════════════

FABRICAS = {
    "anthropic": ClienteAnthropicIA,
    "azure_openai": ClienteAzureOpenAIIA,
}


# ═════════════════════════════════════════════════════════════════════════════
# METADATOS POR PROVEEDOR — para mensajes que no asuman un proveedor concreto
# ═════════════════════════════════════════════════════════════════════════════
# [GENERICO 2026-07-30] Los mensajes al usuario tenían el proveedor incrustado:
#
#   · `agente.py` mandaba SIEMPRE a console.anthropic.com en el primer arranque,
#     aunque el proveedor por defecto del proyecto es Azure OpenAI.
#   · El error 401 decía «API key rechazada por Anthropic» aunque la clave
#     rechazada fuera la de Azure — mandando al operador a revisar la consola
#     equivocada mientras la corrida seguía caída.
#
# El texto se deriva del proveedor ACTIVO. Añadir un proveedor nuevo es añadir
# una entrada aquí y otra en FABRICAS, sin tocar ningún mensaje.
METADATOS_PROVEEDOR = {
    "anthropic": {
        "nombre":        "Anthropic",
        "consola":       "https://console.anthropic.com/",
        "var_clave":     "ANTHROPIC_API_KEY",
        "vars_revisar":  ("IA_PROVEEDOR=anthropic", "ANTHROPIC_API_KEY",
                          "ANTHROPIC_MODELO"),
    },
    "azure_openai": {
        "nombre":        "Azure OpenAI",
        "consola":       "https://portal.azure.com/  (recurso → Keys and Endpoint)",
        "var_clave":     "AZURE_OPENAI_API_KEY",
        "vars_revisar":  ("IA_PROVEEDOR=azure_openai", "AZURE_OPENAI_ENDPOINT",
                          "AZURE_OPENAI_DEPLOYMENT  (el *Deployment name*, "
                          "NO el nombre del modelo)",
                          "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_API_VERSION"),
    },
}

# Si el proveedor no está catalogado se devuelve una ficha neutra en vez de
# reventar: un mensaje de error no puede fallar al construirse, porque entonces
# el operador pierde también el diagnóstico que venía a darle.
_METADATOS_NEUTROS = {
    "nombre":       "el proveedor de IA configurado",
    "consola":      "la consola de tu proveedor",
    "var_clave":    "la variable de clave de tu proveedor",
    "vars_revisar": ("IA_PROVEEDOR",),
}


def metadatos_proveedor(proveedor: Optional[str] = None) -> dict:
    """
    Ficha del proveedor indicado, o del activo si no se indica ninguno.

    Se usa para construir mensajes de error y de configuración sin incrustar el
    nombre de ningún proveedor en el código que los emite.
    """
    clave = (proveedor or IA_PROVEEDOR or "").strip().lower()
    return METADATOS_PROVEEDOR.get(clave, _METADATOS_NEUTROS)

# [PERF-FIX] Cliente cacheado a nivel de proceso.
# Antes: cada llamada a get_cliente_ia() construía un cliente nuevo Y ejecutaba
# validar_conexion(), que hace una llamada API REAL de prueba. En una corrida
# Tier 1 esto suponía ~17 requests desperdiciados (100% de sobrecoste).
# Ahora: se construye una sola vez por proceso y la validación es opcional.
_CLIENTE_CACHE: Optional[ClienteIA] = None


def get_cliente_ia(forzar_recarga: bool = False) -> ClienteIA:
    """
    Devuelve el cliente IA según IA_PROVEEDOR configurado.

    [PERF-FIX] El cliente se cachea a nivel de proceso: llamar a esta función
    N veces construye el cliente UNA sola vez. Esto elimina el 50% de las
    llamadas a la API que se hacían antes (una de validación por evaluación).

    [PERF-FIX] La llamada de validación (`validar_conexion()`) solo se ejecuta
    si VIRF_VALIDAR_CONEXION=1 en .env. Por defecto está desactivada: un fallo
    de credenciales se manifiesta igualmente en la primera llamada real, con
    un mensaje claro, y sin gastar un request extra por proceso.

    Args:
        forzar_recarga: reconstruye el cliente ignorando la caché
                        (útil en tests o si cambia la configuración en runtime).

    Returns:
        ClienteIA listo para usar.

    Raises:
        RuntimeError si la configuración es inválida o no hay conexión.
    """
    global _CLIENTE_CACHE

    if _CLIENTE_CACHE is not None and not forzar_recarga:
        return _CLIENTE_CACHE

    proveedor = IA_PROVEEDOR

    if proveedor not in FABRICAS:
        raise ValueError(
            f"❌ Proveedor no soportado: {proveedor}. Opciones: {', '.join(FABRICAS)}"
        )

    try:
        cliente = FABRICAS[proveedor]()

        if VALIDAR_CONEXION:
            if not cliente.validar_conexion():
                _motivo = getattr(cliente, "ultimo_error_conexion", "")
                raise RuntimeError(
                    f"❌ No se pudo conectar a {proveedor.upper()}"
                    + (f" — {_motivo}" if _motivo else "")
                )
            estado = "conexión verificada"
        else:
            estado = "sin verificar (VIRF_VALIDAR_CONEXION=0)"

        modelo = os.getenv(f"{proveedor.upper()}_MODELO", "default")
        print(f"✅ Cliente IA listo: {proveedor} ({modelo}) — {estado}")

        _CLIENTE_CACHE = cliente
        return cliente

    except ValueError:
        raise  # errores de configuración/seguridad se propagan con su mensaje original
    except Exception as e:
        # `from e` preserva la cadena para quien inspeccione __cause__.
        raise RuntimeError(f"❌ Error inicializando IA: {e}") from e


def reset_cliente_ia() -> None:
    """Limpia la caché del cliente (para tests o recarga de configuración)."""
    global _CLIENTE_CACHE
    _CLIENTE_CACHE = None


# ═════════════════════════════════════════════════════════════════════════════
# PRUEBA DE HUMO — el único comando manual tras pegar la credencial
# ═════════════════════════════════════════════════════════════════════════════

def prueba_de_humo() -> dict:
    """
    Llamada mínima real al proveedor activo. Confirma cuatro cosas de una vez:

      1. que las credenciales son válidas;
      2. qué MODELO sirve realmente el deployment (el nombre no lo dice);
      3. que el perfil de chunking que se aplicará es el correcto para ese
         modelo (config/modelos.py);
      4. que el parser real —no un mock— entiende el JSON que devuelve.

    El punto 4 es el que justifica que esto exista: el proyecto ya sufrió
    respuestas envueltas en markdown fences y con prosa alrededor, y el parser
    lleva un AUDIT-FIX por ello. Comprobarlo con el proveedor nuevo ANTES de la
    primera corrida real evita descubrirlo con 40 llamadas ya pagadas.

    No lanza: devuelve un dict con `ok` y el diagnóstico, para que el llamante
    decida el código de salida.
    """
    import time
    from .parametros import IA_PROVEEDOR as _prov

    res = {"ok": False, "proveedor": _prov, "modelo": None, "perfil": None,
           "latencia_ms": None, "json_ok": None, "error": None}
    try:
        cliente = get_cliente_ia(forzar_recarga=True)
    except Exception as exc:
        res["error"] = f"{type(exc).__name__}: {exc}"
        return res

    # ── Llamada mínima, midiendo latencia ───────────────────────────────────
    t0 = time.perf_counter()
    try:
        texto = cliente.generar_mensaje(
            prompt='Responde únicamente con este JSON, sin texto adicional: '
                   '{"estado": "ok", "prueba": true}',
            instruccion_sistema="Eres un servicio de verificación. Responde solo JSON.",
            max_tokens=64,
            formato_json=True,
        )
    except Exception as exc:
        res["latencia_ms"] = int((time.perf_counter() - t0) * 1000)
        res["error"] = f"{type(exc).__name__}: {exc}"
        return res
    res["latencia_ms"] = int((time.perf_counter() - t0) * 1000)

    # ── Modelo real y perfil de chunking asociado ───────────────────────────
    modelo = getattr(cliente, "_modelo_real", None) or getattr(cliente, "modelo", None)              or getattr(cliente, "deployment", None)
    res["modelo"] = modelo
    try:
        from .modelos import perfil_modelo
        perfil = perfil_modelo(modelo, verbose=False)
        res["perfil"] = {
            "nombre": perfil.nombre,
            "contexto_tokens": perfil.contexto_tokens,
            "chunk_size": perfil.chunk_size,
            "max_ctx": perfil.max_ctx,
            "max_chunks": perfil.max_chunks,
            "param_tokens": perfil.param_tokens,
            "admite_temperature": perfil.admite_temperature,
            "nota": perfil.nota,
        }
    except Exception:
        pass

    # ── El parser REAL, no un mock ──────────────────────────────────────────
    try:
        import sys as _sys
        from pathlib import Path as _Path
        _sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
        from modulos.motor_ia import _extraer_json
        datos = _extraer_json(texto)
        res["json_ok"] = isinstance(datos, dict)
        res["json_muestra"] = str(datos)[:120]
    except Exception as exc:
        res["json_ok"] = False
        res["error_json"] = f"{type(exc).__name__}: {exc}"
        res["respuesta_cruda"] = texto[:200]

    res["ok"] = bool(res["json_ok"])
    return res
