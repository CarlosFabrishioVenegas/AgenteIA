"""
config/parametros.py  [v27.2]
═════════════════════════════════════════════════════════════════════════════
ÚNICA FUENTE DE VERDAD DE TODOS LOS PARÁMETROS AJUSTABLES DEL PROYECTO.

Si un valor se puede tocar con una variable de entorno, se declara AQUÍ y solo
aquí. Ningún otro módulo debe volver a llamar a `os.getenv` para un parámetro
de negocio: debe importarlo de este fichero.

POR QUÉ EXISTE
--------------
Antes de v27.2 la configuración estaba repartida y, en varios casos,
DUPLICADA con defaults independientes:

    VIRF_CHUNK_SIZE / _OVERLAP / _THRESHOLD  → chunker.py  Y  Mx_01
    MAX_CHARS_DOC / _CODIGO / MAX_FILAS_EXCEL → config.py  Y  Mx_00
    VIRF_MAX_CTX                              → agente.py  Y  chunker.py
                                                (¡con defaults distintos!)

La duplicación era tan conocida que `validate_project.py` tenía —y sigue
teniendo— un check dedicado a detectar que config.py y Mx_00 no divergieran.
Ese check ahora es una red de seguridad, no la única defensa: con una sola
declaración por parámetro, la divergencia deja de ser posible por construcción.

CONVENCIÓN
----------
  · Un parámetro = una línea = un `os.getenv`.
  · El default vive aquí, no en el punto de uso.
  · Los módulos siguen exponiendo sus nombres privados históricos
    (`_CHUNK_SIZE`, `_MAX_CHUNKS`…) como alias, para no romper tests ni el
    validador, pero su VALOR viene de aquí.
"""

from __future__ import annotations

import os

from dotenv import load_dotenv

# Debe ejecutarse ANTES del primer os.getenv de todo el proyecto.
load_dotenv()


# ── Lectura tipada y tolerante del entorno ───────────────────────────────────
# [AUDIT-FIX] Antes cada parámetro hacía `int(os.getenv(...))` a pelo. Un typo
# en .env —MAX_CHARS_DOC=abc, o un "12.000" con separador de miles— reventaba
# el ARRANQUE con un `ValueError: invalid literal for int()` y un traceback
# crudo dentro de un import, antes de que el agente imprimiera nada. El usuario
# veía un fallo del programa, no un error de su configuración.
#
# Ahora un valor inválido avisa por qué y con qué se sigue, en vez de tumbar
# la corrida: un .env mal escrito no debe impedir validar un modelo.

def _num_env(nombre: str, defecto, conv, minimo=None, maximo=None):
    """Lee `nombre` del entorno con `conv`; ante valor inválido usa `defecto`."""
    crudo = os.getenv(nombre)
    if crudo is None or str(crudo).strip() == "":
        return defecto
    try:
        valor = conv(str(crudo).strip())
    except (TypeError, ValueError):
        print(f"  ⚠️  {nombre}='{crudo}' no es un número válido en .env — "
              f"se usa el valor por defecto ({defecto}).")
        return defecto
    if minimo is not None and valor < minimo:
        print(f"  ⚠️  {nombre}={valor} está por debajo del mínimo admitido "
              f"({minimo}) — se usa {defecto}.")
        return defecto
    # [AUDIT-FIX] Faltaba el tope. RAG_MIN_SCORE es una similitud en [0,1]:
    # un 5 no es "más estricto", filtra TODOS los chunks y deja el RAG mudo
    # sin un solo aviso.
    if maximo is not None and valor > maximo:
        print(f"  ⚠️  {nombre}={valor} supera el máximo admitido "
              f"({maximo}) — se usa {defecto}.")
        return defecto
    return valor


def _entero(nombre: str, defecto: int, minimo: int = 1) -> int:
    return _num_env(nombre, defecto, int, minimo)


def _decimal(nombre: str, defecto: float, minimo: float = 0.0,
             maximo: float = None) -> float:
    return _num_env(nombre, defecto, float, minimo, maximo)


def _booleano(nombre: str, defecto: bool = False) -> bool:
    crudo = os.getenv(nombre)
    if crudo is None:
        return defecto
    return str(crudo).strip().lower() in ("1", "true", "si", "sí", "yes", "on")

__all__ = [
    "IA_PROVEEDOR", "MODO", "AGENTE_VERSION",
    "MAX_CHARS_DOC", "MAX_CHARS_CODIGO", "MAX_FILAS_EXCEL",
    "TIMEOUT_SEGUNDOS", "REINTENTOS_API",
    "ANTHROPIC_MODELO", "ANTHROPIC_MAX_TOKENS", "VALIDAR_CONEXION",
    "AZURE_API_VERSION", "AZURE_MAX_TOKENS",
    "MAX_CTX", "MAX_DOCS_AMBITO",
    "CHUNK_SIZE", "CHUNK_OVERLAP", "CHUNK_THRESHOLD", "MAX_CHUNKS",
    "CHUNK_SIZE_MAX", "MAX_NIVELES", "PRESUPUESTO_DOC", "CHUNK_ENABLED",
    "CACHE_ENABLED", "CACHE_LOCK_TIMEOUT", "CACHE_LOCK_STALE",
    "EXCEL_MAX_CELDAS_MUESTRA", "EXCEL_MAX_FORMULAS_HOJA",
    "EXCEL_CHUNK_HOJA_UMBRAL", "EXCEL_VALIDACION_TOL", "EXCEL_NB_TIMEOUT",
    "DEBUG_PROMPTS", "MIN_FEEDBACK_ANTISESGO", "MIN_MUESTRAS_AJUSTE",
    "RAG_TOP_K", "RAG_MIN_SCORE",
    "VALIDADOR_NOMBRE", "VALIDADOR_CARGO", "UMBRAL_SIN_SEGUNDA_REVISION",
    "identidad_validador_entorno",
]


# ═════════════════════════════════════════════════════════════════════════════
# 1. GENERALES
# ═════════════════════════════════════════════════════════════════════════════

# ── [POLÍTICA DE PROVEEDOR] ──────────────────────────────────────────────────
# Azure OpenAI es el proveedor PRIORITARIO por decisión de la entidad.
#
# El DEFAULT vive aquí, en el código, y NO en el .env: si mañana alguien clona
# el proyecto y olvida definir IA_PROVEEDOR, la corrida debe salir por Azure —
# no por el proveedor secundario. Depender de que el operador recuerde poner una
# variable es depender de que no se equivoque, y la política no admite eso.
#
# Anthropic sigue disponible como SECUNDARIO: IA_PROVEEDOR=anthropic.
# NO hay fallback automático entre proveedores (ver config/ia.py:get_cliente_ia).
IA_PROVEEDOR = os.getenv("IA_PROVEEDOR", "azure_openai").lower()   # azure_openai|anthropic
MODO = os.getenv("MODO", "debug").lower()                       # debug|produccion
# Viaja al JSON de auditoría: debe reflejar la versión REAL del evaluador.
# Se mantiene en 27.1 deliberadamente — subirla es una decisión del proyecto,
# no un efecto colateral de reorganizar la configuración.
AGENTE_VERSION = os.getenv("VIRF_AGENTE_VERSION", "27.1")

TIMEOUT_SEGUNDOS = _entero("TIMEOUT_SEGUNDOS", 30)
REINTENTOS_API = _entero("REINTENTOS_API", 3)


# ═════════════════════════════════════════════════════════════════════════════
# 2. LECTURA DE DOCUMENTOS
#    Antes duplicados entre config.py y Mx_00_CargaRutas.
# ═════════════════════════════════════════════════════════════════════════════

MAX_CHARS_DOC = _entero("MAX_CHARS_DOC", 15000)
MAX_CHARS_CODIGO = _entero("MAX_CHARS_CODIGO", 8000)
MAX_FILAS_EXCEL = _entero("MAX_FILAS_EXCEL", 200)

# Contexto máximo que se le pasa al modelo por llamada.
# [UNIFICACIÓN v27.2] agente.py usaba default MAX_CHARS_DOC y chunker.py el
# literal "15000". Coincidían por casualidad: al tocar MAX_CHARS_DOC dejaban de
# hacerlo, y el chunker calculaba su presupuesto contra un valor obsoleto.
MAX_CTX = _entero("VIRF_MAX_CTX", MAX_CHARS_DOC)

# 0 = sin límite de documentos por ámbito. `minimo=0` es deliberado: 0 es un
# valor VÁLIDO aquí, no un error de configuración.
MAX_DOCS_AMBITO = _entero("VIRF_MAX_DOCS_AMBITO", 0, minimo=0)


# ═════════════════════════════════════════════════════════════════════════════
# 3. PROVEEDOR IA
# ═════════════════════════════════════════════════════════════════════════════

ANTHROPIC_MODELO = os.getenv("ANTHROPIC_MODELO", "claude-sonnet-4-6")
ANTHROPIC_MAX_TOKENS = _entero("ANTHROPIC_MAX_TOKENS", 4096)

# Gasta 1 request de prueba al arrancar. Desactivado por defecto: un fallo de
# credenciales se manifiesta igual en la primera llamada real.
VALIDAR_CONEXION = _booleano("VIRF_VALIDAR_CONEXION", False)

# GA estable. Una versión 'preview' puede cambiar de comportamiento sin aviso,
# y este sistema exige corridas reproducibles (METODOLOGIA_DEL_AGENTE.md §11.5):
# dos corridas sobre la misma evidencia deben dar el mismo resultado.
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
AZURE_MAX_TOKENS = _entero("AZURE_OPENAI_MAX_TOKENS", 4096)


# ═════════════════════════════════════════════════════════════════════════════
# 4. CHUNKING DE DOCUMENTOS LARGOS
#    Antes duplicados entre modulos/chunker.py y motor/Mx_01_LecturaEvidencias.
# ═════════════════════════════════════════════════════════════════════════════

# Tamaño INICIAL del segmento. El modo adaptativo puede subirlo hasta
# CHUNK_SIZE_MAX, así que no es el tamaño real en documentos grandes.
CHUNK_SIZE = _entero("VIRF_CHUNK_SIZE", 12000)
CHUNK_OVERLAP = _entero("VIRF_CHUNK_OVERLAP", 800)
CHUNK_THRESHOLD = _entero("VIRF_CHUNK_THRESHOLD", CHUNK_SIZE)

# [COSTE-FIX D2] 40 en vez de 60: medido sobre un PDF real de 305 páginas,
# 40 segmentos cuestan $1,14 y 60 cuestan $1,45, con idéntica cobertura (100%).
#
# ⚠️ NO bajar de ~34 sin subir CHUNK_SIZE_MAX: por debajo de ese punto el
# segmento adaptativo necesario supera el tope, el chunker cae al modo
# jerárquico puro y el coste SUBE ($2,27 con 30). Ver README §3.4.1.
MAX_CHUNKS = _entero("VIRF_MAX_CHUNKS", 40)

# Techo del segmento adaptativo. Subirlo permite bajar MAX_CHUNKS sin penalizar.
CHUNK_SIZE_MAX = _entero("VIRF_CHUNK_SIZE_MAX", 40000)

# Tope de niveles de consolidación jerárquica (evita bucle si el modelo no
# comprime lo suficiente).
MAX_NIVELES = _entero("VIRF_MAX_NIVELES", 3)

# Presupuesto de chars que los resúmenes de UN documento pueden ocupar en el
# prompt de evaluación. Fracción de MAX_CTX para que un ámbito con varios
# documentos largos siga cabiendo.
PRESUPUESTO_DOC = _entero("VIRF_PRESUPUESTO_DOC", int(MAX_CTX * 0.6))

CHUNK_ENABLED = _booleano("VIRF_CHUNK_ENABLED", True)


# ═════════════════════════════════════════════════════════════════════════════
# 5. CACHÉ
# ═════════════════════════════════════════════════════════════════════════════

CACHE_ENABLED = _booleano("CACHE_ENABLED", True)
CACHE_LOCK_TIMEOUT = _entero("VIRF_CACHE_LOCK_TIMEOUT", 10)   # segundos
CACHE_LOCK_STALE = _entero("VIRF_CACHE_LOCK_STALE", 60)       # segundos


# ═════════════════════════════════════════════════════════════════════════════
# 6. EXCEL → NOTEBOOK
# ═════════════════════════════════════════════════════════════════════════════

EXCEL_MAX_CELDAS_MUESTRA = _entero("EXCEL_MAX_CELDAS_MUESTRA", 500)
EXCEL_MAX_FORMULAS_HOJA = _entero("EXCEL_MAX_FORMULAS_HOJA", 2000)
EXCEL_CHUNK_HOJA_UMBRAL = _entero("EXCEL_CHUNK_HOJA_UMBRAL", 80)
EXCEL_VALIDACION_TOL = _decimal("EXCEL_VALIDACION_TOL", 1e-6)
EXCEL_NB_TIMEOUT = _entero("EXCEL_NB_TIMEOUT", 120)


# ═════════════════════════════════════════════════════════════════════════════
# 7. DIAGNÓSTICO Y FEEDBACK
# ═════════════════════════════════════════════════════════════════════════════

DEBUG_PROMPTS = _booleano("DEBUG_PROMPTS", False)

# Masa crítica exigida antes de dejar que el feedback histórico altere el
# criterio del agente (D6-FIX). Gobierna el bloque de calibración del prompt.
MIN_FEEDBACK_ANTISESGO = _entero("VIRF_MIN_FEEDBACK_ANTISESGO", 15)

# [AUDIT-FIX] Umbral del ajuste numérico POST-HOC del puntaje.
#
# Había dos guardias anti-sesgo descoordinadas y solo una era visible:
#   · bloque del prompt      → MIN_FEEDBACK_ANTISESGO (15, configurable)
#   · ajuste numérico directo→ MIN_MUESTRAS = 3, HARDCODEADO en
#                              feedback_mejorado.ajustar_puntaje_por_feedback
#
# Medido: con 3 muestras de diferencia +2, un puntaje 2.0 pasaba a 2.8, que
# redondea a 3 — un punto entero sobre una escala de 5. Y quien subiera
# VIRF_MIN_FEEDBACK_ANTISESGO a 30 creyendo endurecer el sistema seguía
# teniendo ese ajuste disparándose con 3 muestras.
#
# La intervención MÁS directa sobre el dictamen no puede tener el guardia MÁS
# débil, así que por defecto hereda el mismo umbral. Se deja como variable
# propia porque su conteo es por ACTIVIDAD similar (más estrecho que el conteo
# por ámbito del bloque del prompt), y puede querer relajarse a conciencia.
MIN_MUESTRAS_AJUSTE = _entero("VIRF_MIN_MUESTRAS_AJUSTE", MIN_FEEDBACK_ANTISESGO)


# ═════════════════════════════════════════════════════════════════════════════
# REVISIÓN DE CÓDIGO (modulos/revision_codigo.py)
# ═════════════════════════════════════════════════════════════════════════════

# Chars de UN módulo que caben en una sola llamada. Por encima, el módulo se
# parte en bloques que empiezan en un `def`/`class` —nunca a media función— y se
# hacen varias llamadas para ese fichero. 120.000 chars ≈ 50.000 tokens: cabe
# con el manual dentro en cualquier modelo del catálogo con ≥128.000 tokens de
# ventana (ver config/modelos.py). Con un modelo de contexto pequeño, bájalo.
MAX_CHARS_MODULO = _entero("VIRF_MAX_CHARS_MODULO", 120_000)

# Recorte del manual metodológico que viaja como contexto FIJO en cada llamada.
# Es el multiplicador del coste: con 30 módulos, cada char del manual se paga 30
# veces. Subirlo mejora el contraste y encarece la corrida de forma lineal.
MAX_CHARS_MANUAL_REVISION = _entero("VIRF_MAX_CHARS_MANUAL_REVISION", 24_000)

# Excluir site-packages/, .venv/, node_modules/… del árbol de código revisado.
# DESACTIVADO por defecto por decisión explícita del operador: descartar
# ficheros en silencio es peor que revisarlos de más, y el inventario previo
# (que se imprime siempre) ya declara cuántas llamadas van a ocurrir. Actívalo
# si copias a inputs/implementacion/ un árbol que arrastra su entorno virtual.
EXCLUIR_DEPENDENCIAS = _booleano("VIRF_EXCLUIR_DEPENDENCIAS", False)


# ═════════════════════════════════════════════════════════════════════════════
# RAG
# ═════════════════════════════════════════════════════════════════════════════
# [AUDIT-FIX] `.env.example` documentaba RAG_TOP_K=3 y RAG_MIN_SCORE=0.35 desde
# hacía tiempo, pero NADIE las leía: los valores vivían hardcodeados como
# defaults en las firmas de motor_ia.evaluar_actividad() y
# evaluar_ambito_completo(). Coincidían por casualidad con lo documentado, así
# que el usuario que los tocaba en su .env no obtenía ningún efecto y tampoco
# ningún aviso. Un mando de configuración que no está conectado a nada es peor
# que no ofrecerlo: promete un control que no existe.
RAG_TOP_K = _entero("RAG_TOP_K", 3, minimo=1)
RAG_MIN_SCORE = _decimal("RAG_MIN_SCORE", 0.35, minimo=0.0, maximo=1.0)


# ═════════════════════════════════════════════════════════════════════════════
# CUMPLIMIENTO REGULATORIO — validador humano
# ═════════════════════════════════════════════════════════════════════════════
# [CONFIG-CENTRAL] Estos tres viven aquí y no en modulos/validador_humano.py
# porque son parámetros de NEGOCIO ajustables, y el invariante del proyecto es
# que no haya declaraciones dispersas: una segunda lectura de VIRF_VALIDADOR en
# otro módulo podría divergir de esta sin que nada avisara.
#
# La identidad por defecto permite corridas no interactivas (CI, lotes) sin
# abrir un agujero: si estas variables están vacías —el caso normal— el informe
# de producción se rechaza igualmente. Definirlas es una decisión explícita del
# operador, equivalente a firmar.
VALIDADOR_NOMBRE = os.getenv("VIRF_VALIDADOR", "").strip()
VALIDADOR_CARGO = os.getenv("VIRF_VALIDADOR_CARGO", "").strip()


def identidad_validador_entorno():
    """
    Lee la identidad del validador del entorno EN EL MOMENTO de la llamada.

    Las constantes de arriba se fijan al importar el módulo, lo que basta para
    una corrida normal pero no permite que un test cambie el entorno ni que un
    lanzador exporte la variable después del import. Esta función es la única
    lectura en runtime, de modo que sigue habiendo un solo punto de declaración.
    """
    return (os.getenv("VIRF_VALIDADOR", "").strip(),
            os.getenv("VIRF_VALIDADOR_CARGO", "").strip())

# Firmas consecutivas del mismo validador sobre el mismo modelo a partir de las
# cuales se advierte de falta de segunda revisión (SR 11-7 §V, segregación de
# funciones). No bloquea: en un equipo de 2 personas la rotación puede ser
# imposible en un periodo dado y bloquear impediría trabajar.
UMBRAL_SIN_SEGUNDA_REVISION = _entero("VIRF_UMBRAL_SEGUNDA_REVISION", 3, minimo=2)
