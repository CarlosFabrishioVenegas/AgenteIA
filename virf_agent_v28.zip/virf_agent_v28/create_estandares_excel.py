"""
Crear archivo Excel stub para Estandares_VIRF.xlsx
─────────────────────────────────────────────────────────────────────────
⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
    → informe). Script auxiliar/de referencia. Ver README §12.

⛔ ESTE SCRIPT GENERA UN ESQUELETO, NO EL ESTÁNDAR REAL.
   El estándar real de la entidad tiene ~21 actividades repartidas en 6
   ámbitos con su matriz TIER I-IV. Este fichero solo produce 3 filas de
   ejemplo, útiles para arrancar un proyecto desde cero — jamás para
   reemplazar un estándar en uso.
"""

# ═════════════════════════════════════════════════════════════════════════
# [AUDIT-FIX 2026-07-30] Guarda __main__ + negativa a sobrescribir
# ═════════════════════════════════════════════════════════════════════════
# Este script ejecutaba `df.to_excel(...)` a NIVEL DE MÓDULO, sin guarda
# `if __name__ == "__main__"`. Consecuencia real y medida: un barrido de
# imports (`importlib.import_module` sobre todos los módulos del proyecto,
# para comprobar que importaban) DESTRUYÓ inputs/Estandares_VIRF.xlsx —la
# vara de medir del sistema— y la sustituyó por el esqueleto de 3 filas.
# No había copia de seguridad y el proyecto no es un repositorio git.
#
# Se aplican DOS protecciones, porque una sola no basta:
#   1. la guarda `__main__`, para que importar el módulo no ejecute nada;
#   2. la negativa a sobrescribir un fichero existente sin `--forzar`, para
#      que ni siquiera ejecutarlo por error destruya un estándar en uso.
#
# Regla general que deja el incidente: en un proyecto con scripts
# generadores, NUNCA verifiques imports con `importlib`. Usa análisis
# estático (`ast.parse` o `compileall`), que no ejecuta nada.
# ═════════════════════════════════════════════════════════════════════════

import pandas as pd
from pathlib import Path

DESTINO = Path(__file__).parent / "inputs" / "Estandares_VIRF.xlsx"


def construir_stub() -> pd.DataFrame:
    """DataFrame de ejemplo con la estructura mínima esperada."""
    return pd.DataFrame({
        "CONTROL":     ["Control_1", "Control_2", "Control_3"],
        "DESCRIPCION": ["Validación de fórmulas", "Backtesting", "Documentación"],
        "TIER I":      ["Obligatorio", "Obligatorio", "Recomendado"],
        "TIER II":     ["Obligatorio", "Obligatorio", "Obligatorio"],
        "TIER III":    ["Obligatorio", "Obligatorio", "Obligatorio"],
        "TIER IV":     ["Recomendado", "Recomendado", "Recomendado"],
        "FUENTE":      ["SR 11-7", "Kupiec 1995", "EBA/GL/2023/01"],
    })


def main(forzar: bool = False) -> int:
    """Escribe el stub. Devuelve 0 si escribió, 1 si se negó a hacerlo."""
    if DESTINO.exists() and not forzar:
        print(f"\n  ⛔ {DESTINO.name} YA EXISTE y no se sobrescribe.")
        print("     Es la vara de medir del sistema: perderla invalida toda")
        print("     validación posterior y no es reconstruible sin copia.")
        print("     Usa --forzar solo si estás seguro, y haz copia antes.\n")
        return 1

    DESTINO.parent.mkdir(parents=True, exist_ok=True)
    df = construir_stub()
    df.to_excel(DESTINO, index=False, sheet_name="Controles")
    print(f"✓ Archivo creado: {DESTINO}")
    print(f"  Dimensiones: {df.shape}")
    print(f"  Columnas: {list(df.columns)}")
    print("\n  ⚠️  Es un ESQUELETO de 3 filas, no el estándar real de la entidad.")
    return 0


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(
        description="Genera un Excel de estándares VIRF de ejemplo (esqueleto)")
    ap.add_argument("--forzar", action="store_true",
                    help="sobrescribe un Estandares_VIRF.xlsx existente (PELIGROSO)")
    raise SystemExit(main(forzar=ap.parse_args().forzar))
