> Datos elaborados por BCP para uso Interno

# Login con cuenta corporativa (Entra ID) — pasos para la web v3

| Versión | Fecha | Dueño | Estado |
|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Pendiente: web v3 |

**Hoy (web v2)** la web se prueba con **usuario libre** (`python scripts/web_prueba.py`):
nombre y roles se eligen en pantalla y la identidad queda marcada como
«usuario de prueba (sin SSO)». Ese modo se niega a arrancar con `MODO=produccion`.

**El código del SSO ya está hecho** (`config/identidad.py:EntraIDProvider`,
`web/routers/auth.py`, SEG-02). Lo que falta son los pasos de abajo. Los marcados
👤 los hace otra persona o equipo; el agente no los simula.

## Pasos

### 1. Registrar la aplicación en Entra ID 👤 *(equipo de identidad)*

- Tipo: aplicación web, **un solo tenant** (el del banco).
- Redirect URI: `https://<host-de-virf>/api/auth/callback`. Tiene que ser `https://`;
  el código solo admite `http` para `localhost`.
- Entregan tres datos: **tenant id**, **client id (application id)** y la redirect URI registrada.

### 2. Crear el client secret y guardarlo en Key Vault 👤

- Secreto de la app (o certificado) → Key Vault con el nombre **`virf-entra-client-secret`**.
- Nunca en `.env`: `config/secretos.py` lo rechaza.

### 3. Definir los app roles y asignar personas 👤

| App role (valor exacto) | Permite |
|---|---|
| `validador` | Lanzar validaciones, dar feedback propio |
| `revisor` | Aprobar código generado por IA y feedback de otros |
| `admin_corpus` | Gestionar el corpus RAG, editar prompts, diagnóstico |

Asignar usuarios o grupos a cada rol. **Sin rol, todo se deniega** (`web/services/roles.py`).

### 4. Claims del token 👤

- Obligatorios (vienen por defecto): `oid`, `tid`, `preferred_username`, `name`, `roles`.
- Opcionales: `jobTitle` (cargo del firmante; sin él queda «Validador») y `employeeid`
  (código del validador; sin él se usa el usuario del UPN). Pedirlos como *optional claims*
  si se quieren en el informe.

### 5. Aprobar e instalar `msal` 👤 *(Arquitectura / Ciberseguridad)*

`msal` no está en el entorno. Aprobarlo, fijar la versión en `web/requirements_web.txt` e instalar.

### 6. Clave de firma de sesión en Key Vault 👤

Secreto **`virf-clave-firma-sesion`** (≥ 32 caracteres aleatorios). Firma la aserción
de identidad que la web pasa al pipeline. También **`virf-clave-cifrado-reposo`**
para la caché cifrada.

### 7. Configurar el despliegue

```bash
MODO=produccion
VIRF_FUENTE_SECRETOS=keyvault
VIRF_KEYVAULT_URL=https://<vault>.vault.azure.net/
VIRF_IDENTIDAD_PROVEEDOR=entra          # o no declararla: entra es el default
VIRF_ENTRA_TENANT_ID=<paso 1>
VIRF_ENTRA_CLIENT_ID=<paso 1>
VIRF_ENTRA_REDIRECT_URI=https://<host-de-virf>/api/auth/callback
```

La identidad del servidor (Managed Identity) necesita permiso de lectura de secretos en ese Key Vault 👤.

### 8. Servir por HTTPS

La cookie de sesión es `Secure` + `HttpOnly`: fuera de `localhost` exige HTTPS
(App Service, Application Gateway o el proxy corporativo) 👤.

### 9. Verificar

1. Abrir la web → «Entrar con cuenta corporativa» → login de Microsoft → vuelve a VIRF.
2. `GET /api/auth/actual` devuelve el UPN corporativo, no `@prueba.local`.
3. Una persona sin rol recibe 403 en `/api/validar/lanzar`.
4. Un revisor no puede aprobar su propio feedback (403).
5. La bitácora (`modulos/auditoria.py`) tiene la entrada `login` con el `oid`.
6. `pytest tests/test_identidad.py tests/test_roles.py` sigue en verde.

### 10. Retirar el usuario libre

- Confirmar que ningún despliegue declara `VIRF_IDENTIDAD_PROVEEDOR=libre`.
  Con `MODO=produccion` ya se niega solo (`ProveedorLibre`), y el test
  `test_usuario_libre_prohibido_en_produccion` lo vigila.
- Quitar `scripts/web_prueba.py` y la configuración `virf-web-prueba` de los
  entornos compartidos si ya no se usan.
- Los informes firmados en modo prueba llevan «usuario de prueba (sin SSO)» en
  el cargo: no valen como firma corporativa.

## Errores esperables

| Mensaje | Causa | Paso |
|---|---|---|
| `503 Login corporativo no configurado: faltan VIRF_ENTRA_…` | Faltan las variables | 1, 7 |
| `503 Falta el paquete msal` | `msal` sin instalar | 5 |
| `503 … no está configurada en la fuente «keyvault»` | Secreto ausente o sin permiso | 2, 6, 7 |
| `401 token de otro tenant` | Cuenta de otro directorio | 1 |
| `403 tu rol no permite …` | Persona sin app role | 3 |
