"""
modulos/motor_ia_v2.py
======================
Orquestador principal del pipeline VIRF por CONTROL.

Este módulo coordina el flujo end-to-end:
1. Cargar configuración de controles (Excel)
2. Para cada control:
   a. Leer evidencia (manual + script)
   b. Ejecutar motor de controles automáticos (si aplica)
   c. Construir prompt final
   d. Llamar IA con validación de contrato
   e. Compilar hallazgos
3. Generar informe Word consolidado

Arquitectura:
  - Infraestructura (Mx_* en motor/):
      Mx_00 → configuración y constantes
      Mx_01 → lectura de archivos y evidencias
      Mx_02 → construcción de prompts
      Mx_03 → llamadas a API con validación JSON
      Mx_04 → controles automáticos (motor data)
  
  - Orquestación (este archivo):
      evaluar_control()           → evalúa 1 control
      evaluar_todos_controles()   → itera configuración
      generar_informe_final()     → agrega todo en Word
"""

import sys
import json
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime

# Resolver rutas de importación
_MODULOS_DIR = Path(__file__).parent.resolve()
_ROOT_DIR = _MODULOS_DIR.parent.resolve()
_MOTOR_DIR = _ROOT_DIR / "motor"

for _p in [str(_MOTOR_DIR), str(_ROOT_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ─── Importar infraestructura Mx ─────────────────────────────────────────────

# Mx_00: Configuración
from Mx_00_CargaRutas import (
    ROL_AGENTE,
    RUTAS,
    UMBRAL_RIESGO_GLOBAL,
    MODO_PREPRDC,
    MODO_PRDC,
)

# Mx_01: Lectura de evidencias
from Mx_01_LecturaEvidencias import (
    leer_archivo_generico,
    compilar_textos_de_carpeta,
    obtener_evidencia_por_control,
    obtener_conocimiento_por_modelo,
    detectar_manual_y_script,
    guardar_parametros_ejecucion,
)

# Mx_02: Construcción de prompts
from Mx_02_EstructuraPrompt import (
    construir_prompt_final,
)

# Mx_03: Llamadas a API (para la versión Anthropic)
from Mx_03_LlamarIA import (
    _llamar_modelo,
    _parsear_json,
)

# Mx_04: Controles automáticos
from Mx_04_MotorControlesData import (
    ejecutar_motor_data_por_fila,
    convertir_resultado_data_a_texto,
    detectar_cuestionamientos,
)


# ══════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN POR CONTROL
# ══════════════════════════════════════════════════════════════════════════════

def evaluar_control(
    ctrl_id: str,
    prompt_control: str,
    base_project_path: str,
    nombre_modelo: str,
    datasets_dict: Optional[Dict[str, Any]] = None,
    config_row: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Evalúa un control individual mediante el pipeline completo.
    
    Flujo:
    1. Obtener evidencia: manual + script desde carpeta del control
    2. (Opcional) Ejecutar motor de controles automáticos
    3. Obtener conocimiento del modelo (contexto)
    4. Construir prompt final con evidencia + resultado motor
    5. Llamar IA con validación de contrato
    6. Retornar hallazgos estructurados
    
    Parámetros:
        ctrl_id: ID del control (ej: "CTRL_001")
        prompt_control: pregunta específica del control (qué evaluar)
        base_project_path: ruta raíz del proyecto
        nombre_modelo: nombre del modelo (para contexto de conocimiento)
        datasets_dict: dict {nombre_dataset: DataFrame} para motor automático
        config_row: fila del Excel con config del motor (para ejecutar motor)
    
    Retorna:
        Dict con:
        {
          "control_id": str,
          "estado": "OK" | "ERROR",
          "revision": str (análisis técnico),
          "hallazgos": list[dict],
          "resultado_motor": dict | None,
          "fuentes": {
            "manual": str (ruta),
            "script": str (ruta),
          },
        }
    """
    resultado = {
        "control_id":    ctrl_id,
        "estado":        "OK",
        "revision":      "",
        "hallazgos":     [],
        "resultado_motor": None,
        "fuentes":       {"manual": None, "script": None},
    }
    
    try:
        # 1. Obtener evidencia
        ruta_manual, texto_manual, ruta_script, texto_script = detectar_manual_y_script(
            f"{base_project_path}/Evidencias/{ctrl_id}"
        )
        resultado["fuentes"]["manual"] = ruta_manual
        resultado["fuentes"]["script"] = ruta_script
        
        # 2. Ejecutar motor de controles automáticos (si aplica)
        resultado_motor = None
        if config_row and datasets_dict:
            try:
                resultado_motor = ejecutar_motor_data_por_fila(config_row, datasets_dict)
                resultado["resultado_motor"] = resultado_motor
            except Exception as e:
                print(f"  [⚠] Error ejecutando motor: {e}")
        
        # Convertir resultado del motor a texto
        texto_motor = convertir_resultado_data_a_texto(resultado_motor) if resultado_motor else ""
        
        # 3. Obtener contexto de conocimiento del modelo
        contexto_modelo = obtener_conocimiento_por_modelo(base_project_path, nombre_modelo, max_chars=5000)
        
        # 4. Construir prompt final
        prompt_final = construir_prompt_final(
            prompt_control=prompt_control,
            manual=texto_manual,
            script=texto_script,
            resultado_data=texto_motor,
        )
        
        # 5. Llamar a IA
        print(f"  📞 Llamando IA para {ctrl_id}...")
        texto_respuesta = _llamar_modelo(prompt_final, max_tokens=2048)
        
        # Parsear y validar JSON
        fallback = {
            "revision": "No se pudo evaluar el control.",
            "hallazgos": [],
        }
        respuesta_json = _parsear_json(texto_respuesta, fallback)
        
        resultado["revision"] = respuesta_json.get("revision", "")
        resultado["hallazgos"] = respuesta_json.get("hallazgos", [])
        
        # 6. Calcular métricas
        n_hallazgos = len(resultado["hallazgos"])
        n_criticos = sum(1 for h in resultado["hallazgos"] if h.get("criticidad") == "CRITICA")
        
        print(f"  ✅ {ctrl_id}: {n_hallazgos} hallazgos ({n_criticos} críticos)")
        
        return resultado
    
    except Exception as e:
        print(f"  ❌ Error evaluando {ctrl_id}: {e}")
        resultado["estado"] = "ERROR"
        resultado["revision"] = f"Error en evaluación: {str(e)}"
        return resultado


# ══════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN DE TODOS LOS CONTROLES
# ══════════════════════════════════════════════════════════════════════════════

def evaluar_todos_controles(
    excel_controles: str,
    base_project_path: str,
    nombre_modelo: str,
    tier: str = "1",
    datasets_dict: Optional[Dict[str, Any]] = None,
    filtro_controles: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Itera todos los controles del Excel de configuración y los evalúa.
    
    IMPORTANTE: 
    - Solo evalúa controles de CALIDAD DE DATOS (ámbito_control = "Calidad de datos")
    - Filtra por TIER especificado
    - Los controles están organizados jerárquicamente: ÁMBITO → CONTROL → ACTIVIDADES
    
    Parámetros:
        excel_controles: ruta al Excel con configuración de controles
        base_project_path: ruta raíz del proyecto
        nombre_modelo: nombre del modelo
        tier: tier del modelo (para filtrado) — acepta "I", "II", "III", "IV" o "1", "2", "3", "4"
        datasets_dict: dict de DataFrames para motor automático
        filtro_controles: lista de IDs de control a evaluar (None = todos)
    
    Retorna:
        Dict con resultados agregados:
        {
          "fecha_ejecucion": str (ISO),
          "modelo": str,
          "tier": str,
          "total_controles": int,
          "controles_ok": int,
          "controles_error": int,
          "hallazgos_totales": int,
          "hallazgos_criticos": int,
          "resultados_por_control": dict,
        }
    """
    try:
        import pandas as pd
    except ImportError:
        print("[!] Error: pandas no instalado. pip install pandas openpyxl")
        return {}
    
    print(f"\n🔍 Evaluando CALIDAD DE DATOS (Tier {tier})...")

    # Cargar Excel — intentar hoja 'Controles' (ControlesData.xlsx), si no, hoja por defecto
    try:
        xl = pd.ExcelFile(excel_controles)
        sheet = "Controles" if "Controles" in xl.sheet_names else xl.sheet_names[0]
        df_config = xl.parse(sheet)
    except Exception:
        df_config = pd.read_excel(excel_controles)

    # Filtrar solo controles activos si la columna existe
    if "ACTIVO" in df_config.columns:
        df_config = df_config[df_config["ACTIVO"].astype(str).str.strip() == "1"]

    # Filtrar por ámbito solo si la columna existe (ControlesData.xlsx no la tiene)
    if "AMBITO" in df_config.columns:
        df_config = df_config[df_config["AMBITO"].str.lower() == "calidad de datos"]

    # Filtrar por tier si la columna existe
    tier_normalizado = {"I": "I", "II": "II", "III": "III", "IV": "IV",
                        "1": "I", "2": "II", "3": "III", "4": "IV"}.get(str(tier).upper(), str(tier).upper())
    if "TIER" in df_config.columns:
        df_config = df_config[df_config["TIER"].astype(str).str.upper() == tier_normalizado]
    
    if len(df_config) == 0:
        print(f"  ⚠️  No hay controles de CALIDAD DE DATOS para Tier {tier}.")
        return {
            "fecha_ejecucion":       datetime.utcnow().isoformat() + "Z",
            "modelo":                nombre_modelo,
            "tier":                  tier,
            "total_controles":       0,
            "controles_ok":          0,
            "controles_error":       0,
            "hallazgos_totales":     0,
            "hallazgos_criticos":    0,
            "resultados_por_control": {},
        }
    
    # Filtrar por controles específicos si se pasa
    if filtro_controles:
        df_config = df_config[df_config["ID_CONTROL"].isin(filtro_controles)]
    
    print(f"  📊 {len(df_config)} controles a evaluar\n")
    
    # Procesar cada control
    resultados_por_control = {}
    controles_ok = 0
    controles_error = 0
    hallazgos_totales = 0
    hallazgos_criticos = 0
    
    for idx, row in df_config.iterrows():
        ctrl_id = str(row.get("ID_CONTROL", "")).strip()
        prompt = str(row.get("PROMPT_CONTROL", row.get("PROMPT", ""))).strip()

        if not ctrl_id or not prompt:
            print(f"  ⚠️  Fila {idx}: falta ID_CONTROL o PROMPT, omitiendo...")
            continue
        
        print(f"  [{idx+1}/{len(df_config)}] {ctrl_id}")
        
        # Evaluar control
        resultado = evaluar_control(
            ctrl_id=ctrl_id,
            prompt_control=prompt,
            base_project_path=base_project_path,
            nombre_modelo=nombre_modelo,
            datasets_dict=datasets_dict,
            config_row=dict(row),
        )
        resultado["prompt_control"] = prompt
        resultados_por_control[ctrl_id] = resultado
        
        if resultado["estado"] == "OK":
            controles_ok += 1
            hallazgos_totales += len(resultado["hallazgos"])
            hallazgos_criticos += sum(
                1 for h in resultado["hallazgos"] if h.get("criticidad") == "CRITICA"
            )
        else:
            controles_error += 1
    
    # Resumen
    return {
        "fecha_ejecucion":       datetime.utcnow().isoformat() + "Z",
        "modelo":                nombre_modelo,
        "tier":                  tier,
        "total_controles":       len(df_config),
        "controles_ok":          controles_ok,
        "controles_error":       controles_error,
        "hallazgos_totales":     hallazgos_totales,
        "hallazgos_criticos":    hallazgos_criticos,
        "resultados_por_control": resultados_por_control,
    }


# ══════════════════════════════════════════════════════════════════════════════
# GENERACIÓN DE INFORME FINAL
# ══════════════════════════════════════════════════════════════════════════════

def generar_informe_final(
    resultados_evaluacion: Dict[str, Any],
    outputs_dir: str,
    titulo_informe: str,
    tier: str,
) -> Path:
    """
    Genera informe Word consolidando todos los resultados de controles.
    
    Estructura del informe:
    - Portada
    - Resumen ejecutivo
    - ÁMBITO: CALIDAD DE DATOS
      - Control: [nombre]
        - Actividad 1: [evaluación + resultado + recomendación]
        - Actividad 2: [evaluación + resultado + recomendación]
      - Control: [nombre]
        - Actividad 1: [...]
    
    Parámetros:
        resultados_evaluacion: dict retornado por evaluar_todos_controles()
        outputs_dir: ruta de salida para el Word
        titulo_informe: título del informe
        tier: tier del modelo
    
    Retorna:
        Path al archivo Word generado
    """
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor, Cm
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        print("  ❌ Error: python-docx no instalado. pip install python-docx")
        return None
    
    print(f"\n📝 Generando informe Word con estructura jerárquica...")
    
    # Colores corporativos
    AZUL_DARK = RGBColor(0x1F, 0x38, 0x64)
    AZUL_MID = RGBColor(0x2E, 0x75, 0xB6)
    GRIS_TEXT = RGBColor(0x40, 0x40, 0x40)
    BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
    ROJO = RGBColor(0xC0, 0x00, 0x00)
    AMARILLO = RGBColor(0xFF, 0xC0, 0x00)
    VERDE = RGBColor(0x37, 0x86, 0x44)
    
    # Mapeo criticidad → color
    CRIT_COLOR = {
        "CRITICA": ROJO,
        "MODERADA": AMARILLO,
        "BAJA": VERDE,
        "POTENCIAL": GRIS_TEXT,
    }
    
    # Crear documento
    doc = Document()
    
    # ─── PORTADA ─────────────────────────────────────────────────────────────
    for _ in range(8):
        doc.add_paragraph()
    
    p_titulo = doc.add_paragraph()
    p_titulo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_titulo.add_run("INFORME DE VALIDACIÓN VIRF")
    r.font.size = Pt(24)
    r.font.bold = True
    r.font.color.rgb = AZUL_DARK
    
    p_modelo = doc.add_paragraph()
    p_modelo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_modelo.add_run(titulo_informe)
    r.font.size = Pt(18)
    r.font.color.rgb = AZUL_MID
    
    p_tier = doc.add_paragraph()
    p_tier.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_tier.add_run(f"Tier {tier}")
    r.font.size = Pt(14)
    r.font.color.rgb = AZUL_MID
    
    for _ in range(4):
        doc.add_paragraph()
    
    p_fecha = doc.add_paragraph()
    p_fecha.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_fecha.add_run(
        f"Fecha de emisión: {datetime.now().strftime('%d/%m/%Y')}\n"
        "Calidad de Datos — Segunda Línea de Defensa"
    )
    r.font.size = Pt(11)
    r.font.italic = True
    r.font.color.rgb = GRIS_TEXT
    
    doc.add_page_break()
    
    # ─── RESUMEN EJECUTIVO ────────────────────────────────────────────────────
    h1 = doc.add_heading("RESUMEN EJECUTIVO", level=1)
    h1.runs[0].font.color.rgb = AZUL_DARK
    
    p_resumen = doc.add_paragraph()
    r = p_resumen.add_run(
        f"Se ha completado la evaluación de {resultados_evaluacion['total_controles']} controles de Calidad de Datos.\n\n"
    )
    r.font.size = Pt(10)
    
    r2 = p_resumen.add_run(
        f"Resultados:\n"
        f"• Controles exitosos: {resultados_evaluacion['controles_ok']}/{resultados_evaluacion['total_controles']}\n"
        f"• Hallazgos totales: {resultados_evaluacion['hallazgos_totales']}\n"
        f"• Hallazgos críticos: {resultados_evaluacion['hallazgos_criticos']}"
    )
    r2.font.size = Pt(10)
    
    doc.add_paragraph()
    
    # ─── SECCIÓN: ÁMBITO CALIDAD DE DATOS ─────────────────────────────────────
    h2 = doc.add_heading("ÁMBITO: CALIDAD DE DATOS", level=1)
    h2.runs[0].font.color.rgb = AZUL_DARK
    
    resultados = resultados_evaluacion.get("resultados_por_control", {})
    
    for ctrl_num, (ctrl_id, ctrl_resultado) in enumerate(resultados.items(), 1):
        # Encabezado de control
        h3 = doc.add_heading(f"Control: {ctrl_id}", level=2)
        h3.runs[0].font.color.rgb = AZUL_MID
        
        # Actividades (hallazgos) dentro del control
        hallazgos = ctrl_resultado.get("hallazgos", [])
        
        if not hallazgos:
            p_sin_hallazgos = doc.add_paragraph("Sin hallazgos identificados en este control.")
            p_sin_hallazgos.paragraph_format.left_indent = Cm(1.0)
            p_sin_hallazgos.runs[0].font.size = Pt(9)
            p_sin_hallazgos.runs[0].font.italic = True
            p_sin_hallazgos.runs[0].font.color.rgb = VERDE
        else:
            for act_num, hallazgo in enumerate(hallazgos, 1):
                # ─── ACTIVIDAD EVALUADA ───
                p_act = doc.add_paragraph()
                p_act.paragraph_format.left_indent = Cm(0.5)
                p_act.paragraph_format.space_before = Pt(10)
                r_act = p_act.add_run(f"{act_num}. {hallazgo.get('texto', 'Actividad sin descripción')}")
                r_act.font.size = Pt(9)
                r_act.font.bold = True
                r_act.font.color.rgb = AZUL_MID
                
                # ─── CONCEPTO DE ACTIVIDAD ───
                p_concepto_lbl = doc.add_paragraph()
                p_concepto_lbl.paragraph_format.left_indent = Cm(1.0)
                p_concepto_lbl.paragraph_format.space_before = Pt(6)
                p_concepto_lbl.paragraph_format.space_after = Pt(1)
                r_lbl = p_concepto_lbl.add_run("Concepto de actividad:")
                r_lbl.font.size = Pt(9)
                r_lbl.font.bold = True
                r_lbl.font.color.rgb = AZUL_MID
                
                p_concepto = doc.add_paragraph()
                p_concepto.paragraph_format.left_indent = Cm(1.0)
                p_concepto.paragraph_format.space_before = Pt(1)
                p_concepto.paragraph_format.space_after = Pt(3)
                r_concepto = p_concepto.add_run("Pendiente de evaluación — sin documentación disponible.")
                r_concepto.font.size = Pt(9)
                r_concepto.font.color.rgb = GRIS_TEXT
                
                # ─── RESULTADO DE LA ACTIVIDAD ───
                p_resultado_lbl = doc.add_paragraph()
                p_resultado_lbl.paragraph_format.left_indent = Cm(1.0)
                p_resultado_lbl.paragraph_format.space_before = Pt(6)
                p_resultado_lbl.paragraph_format.space_after = Pt(1)
                r_lbl2 = p_resultado_lbl.add_run("Resultado de la actividad:")
                r_lbl2.font.size = Pt(9)
                r_lbl2.font.bold = True
                r_lbl2.font.color.rgb = AZUL_MID
                
                p_resultado = doc.add_paragraph()
                p_resultado.paragraph_format.left_indent = Cm(1.0)
                p_resultado.paragraph_format.space_before = Pt(1)
                p_resultado.paragraph_format.space_after = Pt(3)
                
                criticidad = hallazgo.get('criticidad', 'MODERADA')
                estado_map = {
                    'CRITICA': 'NO CUMPLE',
                    'MODERADA': 'CON OBSERVACIONES',
                    'BAJA': 'CUMPLE CON OBSERVACIONES MENORES',
                    'POTENCIAL': 'CUMPLE PLENAMENTE'
                }
                estado_texto = estado_map.get(criticidad, 'SIN CLASIFICAR')
                
                r_resultado = p_resultado.add_run(f"1/5 — No cumple  |  NO CUMPLE")
                r_resultado.font.size = Pt(9)
                r_resultado.font.bold = True
                r_resultado.font.color.rgb = ROJO
                
                # ─── OBSERVACIÓN ───
                p_obs_lbl = doc.add_paragraph()
                p_obs_lbl.paragraph_format.left_indent = Cm(1.0)
                p_obs_lbl.paragraph_format.space_before = Pt(6)
                p_obs_lbl.paragraph_format.space_after = Pt(1)
                r_lbl3 = p_obs_lbl.add_run("Observación:")
                r_lbl3.font.size = Pt(9)
                r_lbl3.font.bold = True
                r_lbl3.font.color.rgb = AZUL_MID
                
                p_obs = doc.add_paragraph()
                p_obs.paragraph_format.left_indent = Cm(1.0)
                p_obs.paragraph_format.space_before = Pt(1)
                p_obs.paragraph_format.space_after = Pt(3)
                r_obs = p_obs.add_run("No cumple con los criterios de validación establecidos para esta actividad.")
                r_obs.font.size = Pt(9)
                r_obs.font.color.rgb = GRIS_TEXT
                
                # ─── OPORTUNIDAD DE MEJORA ───
                p_mejora_lbl = doc.add_paragraph()
                p_mejora_lbl.paragraph_format.left_indent = Cm(1.0)
                p_mejora_lbl.paragraph_format.space_before = Pt(6)
                p_mejora_lbl.paragraph_format.space_after = Pt(1)
                r_lbl4 = p_mejora_lbl.add_run("Oportunidad de mejora:")
                r_lbl4.font.size = Pt(9)
                r_lbl4.font.bold = True
                r_lbl4.font.color.rgb = AZUL_MID
                
                p_mejora = doc.add_paragraph()
                p_mejora.paragraph_format.left_indent = Cm(1.0)
                p_mejora.paragraph_format.space_before = Pt(1)
                p_mejora.paragraph_format.space_after = Pt(8)
                r_mejora = p_mejora.add_run(hallazgo.get('recomendacion', 'Se recomienda revisar y validar el control según los hallazgos identificados.'))
                r_mejora.font.size = Pt(9)
                r_mejora.font.color.rgb = GRIS_TEXT
    
    # ─── GUARDAR DOCUMENTO ────────────────────────────────────────────────────
    fecha_str = datetime.now().strftime("%Y%m%d")
    nombre_archivo = f"VIRF_Informe_CDD_{titulo_informe.replace(' ', '_')}_{fecha_str}.docx"
    ruta_salida = Path(outputs_dir) / nombre_archivo
    
    doc.save(str(ruta_salida))
    print(f"  ✅ Informe Word generado: {nombre_archivo}")
    
    return ruta_salida


# ══════════════════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL DE ORQUESTACIÓN
# ══════════════════════════════════════════════════════════════════════════════

def orquestar_pipeline_virf(
    base_project_path: str,
    excel_controles: str,
    nombre_modelo: str,
    fecha_informe: str,
    tier: str = "1",
    datasets_dict: Optional[Dict[str, Any]] = None,
    filtro_controles: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Orquesta el pipeline completo end-to-end.
    
    Parámetros:
        base_project_path: ruta raíz del proyecto (contiene Evidencias/, Conocimiento/, etc.)
        excel_controles: ruta al Excel de configuración de controles
        nombre_modelo: nombre del modelo bajo validación
        fecha_informe: fecha en formato YYYY-MM-DD
        tier: tier del modelo (1, 2, 3, 4)
        datasets_dict: dict de DataFrames para motor automático
        filtro_controles: lista de IDs de control a validar (None = todos)
    
    Retorna:
        Dict con estado del pipeline y rutas de salida
    """
    base_path = Path(base_project_path)
    outputs_dir = base_path / "outputs" / fecha_informe
    outputs_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"""
╔════════════════════════════════════════════════════════════════╗
║  PIPELINE VIRF - VALIDACIÓN DE CONTROLES                      ║
║  Modelo: {nombre_modelo:42}║
║  Tier: {tier:51}║
║  Fecha: {fecha_informe:45}║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    # Guardar parámetros de ejecución
    csv_params = guardar_parametros_ejecucion(
        str(outputs_dir),
        nombre_modelo,
        fecha_informe,
        tier,
        excel_controles,
    )
    print(f"  📋 Parámetros guardados: {csv_params.name}")
    
    # Evaluar todos los controles
    resultados_evaluacion = evaluar_todos_controles(
        excel_controles=excel_controles,
        base_project_path=str(base_path),
        nombre_modelo=nombre_modelo,
        tier=tier,
        datasets_dict=datasets_dict,
        filtro_controles=filtro_controles,
    )
    
    if not resultados_evaluacion:
        print("  ❌ No se pudieron evaluar controles")
        return {"estado": "ERROR"}
    
    # Guardar resultados JSON
    json_resultados = outputs_dir / f"resultados_{nombre_modelo}_{fecha_informe}.json"
    try:
        with open(json_resultados, "w", encoding="utf-8") as f:
            # Convertir DataFrames a string para serializar
            res_copy = resultados_evaluacion.copy()
            for ctrl_id, res in res_copy.get("resultados_por_control", {}).items():
                if res.get("resultado_motor") and "detalle" in res["resultado_motor"]:
                    res["resultado_motor"]["detalle"] = str(res["resultado_motor"]["detalle"])
            json.dump(res_copy, f, ensure_ascii=False, indent=2)
        print(f"  💾 Resultados JSON: {json_resultados.name}")
    except Exception as e:
        print(f"  ⚠️  Error guardando JSON: {e}")
    
    # Generar informe Word
    titulo = f"Validación VIRF - {nombre_modelo} - Tier {tier}"
    word_path = generar_informe_final(
        resultados_evaluacion,
        str(outputs_dir),
        titulo,
        tier,
    )
    
    # Resumen final
    print(f"""
╔════════════════════════════════════════════════════════════════╗
║  RESUMEN DE EJECUCIÓN                                          ║
║  ✅ Controles OK:      {resultados_evaluacion['controles_ok']:3d}/{resultados_evaluacion['total_controles']:<3d}
║  ❌ Controles ERROR:   {resultados_evaluacion['controles_error']:3d}
║  🔴 Hallazgos Críticos: {resultados_evaluacion['hallazgos_criticos']:3d}
║  📊 Hallazgos Totales: {resultados_evaluacion['hallazgos_totales']:3d}
║  📁 Salida:            {str(outputs_dir)[:42]:<42}║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    return {
        "estado":              "OK",
        "fecha_ejecucion":     resultados_evaluacion.get("fecha_ejecucion"),
        "modelo":              nombre_modelo,
        "tier":                tier,
        "total_controles":     resultados_evaluacion["total_controles"],
        "controles_ok":        resultados_evaluacion["controles_ok"],
        "hallazgos_criticos":  resultados_evaluacion["hallazgos_criticos"],
        "ruta_json":           str(json_resultados),
        "ruta_word":           str(word_path) if word_path else None,
        "ruta_outputs":        str(outputs_dir),
    }


__all__ = [
    "evaluar_control",
    "evaluar_todos_controles",
    "generar_informe_final",
    "orquestar_pipeline_virf",
]
