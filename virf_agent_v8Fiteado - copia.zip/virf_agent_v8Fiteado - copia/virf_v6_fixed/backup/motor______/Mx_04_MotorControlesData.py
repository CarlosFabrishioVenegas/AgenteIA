"""
Mx_04_MotorControlesData.py
============================
Motor de controles de calidad sobre el código del modelador.
Detecta patrones metodológicamente cuestionables sin llamar a la API.

Responsabilidades:
  - Detectar patrones problemáticos en scripts Python (presencia/ausencia)
  - Aplicar CUESTIONAMIENTOS_METODOLOGICOS definidos en Mx_00_CargaRutas
  - Verificar existencia de _replica_virf.py y su suficiencia
  - Devolver alertas estructuradas listas para el generador de Excel/Word

Nota: Este módulo NO llama a la API de Anthropic.
      Es un análisis estático de texto (regex + búsqueda de patrones).
"""

import re
from pathlib import Path
from typing import Optional

from Mx_00_CargaRutas import CUESTIONAMIENTOS_METODOLOGICOS, RUTAS


# ─── Detección de cuestionamientos en código ──────────────────────────────────

def detectar_cuestionamientos(documentos: list) -> dict:
    """
    Analiza scripts Python en busca de patrones metodológicamente cuestionables.

    Args:
        documentos: Lista de dicts {nombre, tipo, contenido} de todos los inputs.

    Returns:
        Dict {nombre_archivo: {"alertas_rapidas": [lista_de_alertas]}}
        Cada alerta: {"tipo": "presencia|ausencia", "clave": ..., "contexto": ..., "critica": ...}
    """
    codigos = [d for d in documentos if d["tipo"] == "PY"]
    if not codigos:
        return {}

    resultados = {}
    for doc in codigos:
        codigo_lower = doc["contenido"].lower()
        alertas = []

        for clave, info in CUESTIONAMIENTOS_METODOLOGICOS.items():
            patrones    = info["detectar"]
            es_ausencia = info.get("detectar_ausencia", False)

            # BUG FIX: usar re.search para soportar patrones con wildcards (ej: 'SimpleImputer.*mean')
            # Antes se usaba 'in' literal, que no interpreta regex
            encontrado = any(
                bool(re.search(p.lower(), codigo_lower))
                for p in patrones
            )

            if es_ausencia and not encontrado:
                # Alerta por AUSENCIA: el patrón debería estar y no está
                alertas.append({
                    "tipo":     "ausencia",
                    "clave":    clave,
                    "contexto": info["contexto"],
                    "critica":  info["critica"],
                })
            elif not es_ausencia and encontrado:
                # Alerta por PRESENCIA: el patrón está y es cuestionable
                alertas.append({
                    "tipo":     "presencia",
                    "clave":    clave,
                    "contexto": info["contexto"],
                    "critica":  info["critica"],
                })

        resultados[doc["nombre"]] = {"alertas_rapidas": alertas}

    return resultados


def tiene_replica_virf(documentos: list) -> bool:
    """Verifica si existe un script _replica_virf.py entre los documentos."""
    return any(
        "_replica_virf" in d["nombre"].lower()
        for d in documentos
        if d["tipo"] == "PY"
    )


def calcular_riesgo_global(resultados_dimensiones: dict) -> dict:
    """
    Calcula métricas globales de riesgo a partir de todos los resultados.

    Returns:
        {
          "total_actividades": int,
          "total_sin_evidencia": int,
          "pct_sin_evidencia": float,
          "condicion_corte_activada": bool,
          "score_promedio": float | None,
        }
    """
    from Mx_00_CargaRutas import UMBRAL_RIESGO_GLOBAL

    total_acts   = sum(len(r.get("evaluaciones", [])) for r in resultados_dimensiones.values())
    total_sin_ev = sum(r.get("actividades_sin_evidencia", 0) for r in resultados_dimensiones.values())
    pct          = total_sin_ev / total_acts if total_acts > 0 else 0.0

    # Score promedio (solo en modo preprdc)
    todos_scores = [
        ev.get("score", None)
        for res in resultados_dimensiones.values()
        for ev in res.get("evaluaciones", [])
        if ev.get("score") is not None
    ]
    score_promedio = round(sum(todos_scores) / len(todos_scores), 1) if todos_scores else None

    return {
        "total_actividades":         total_acts,
        "total_sin_evidencia":       total_sin_ev,
        "pct_sin_evidencia":         round(pct, 4),
        "condicion_corte_activada":  pct > UMBRAL_RIESGO_GLOBAL,
        "score_promedio":            score_promedio,
    }


def resumen_cuestionamientos_consola(cuestionamientos: dict) -> None:
    """Imprime en consola un resumen de las alertas detectadas."""
    if not cuestionamientos:
        print("  → Sin scripts Python para analizar.")
        return
    for archivo, analisis in cuestionamientos.items():
        n = len(analisis.get("alertas_rapidas", []))
        estado = "⚠" if n > 0 else "✓"
        print(f"  {estado}  {archivo}: {n} alerta(s)")
        for alerta in analisis.get("alertas_rapidas", []):
            tipo_label = "DETECTADO" if alerta["tipo"] == "presencia" else "AUSENTE"
            print(f"       [{tipo_label}] {alerta['contexto']}")


def alertas_criticas(cuestionamientos: dict) -> list:
    """
    Retorna lista plana de todas las alertas de todos los archivos.
    Útil para el generador Excel/Word.
    """
    todas = []
    for archivo, analisis in cuestionamientos.items():
        for alerta in analisis.get("alertas_rapidas", []):
            todas.append({**alerta, "archivo": archivo})
    return todas
