"""
Mx_03_LlamarIA.py
==================
Capa de comunicación con la API de Anthropic.
Responsabilidades:
  - Ejecutar llamadas HTTP a /v1/messages
  - Parsear respuestas JSON del modelo
  - Manejar errores de red, timeout y JSON inválido
  - Exponer funciones de alto nivel:
      llamar_modelo()       → retorna texto crudo
      llamar_y_parsear()    → retorna dict JSON parseado
      aprender_estilo()     → llama y retorna dict de estilo
      generar_replica()     → retorna código Python como str
      evaluar_dimension()   → retorna dict de evaluación
      generar_sintesis()    → retorna dict de síntesis

No contiene lógica de negocio ni construcción de prompts.
"""

import json
import re
import requests
from typing import Optional, Dict, Any
import time

from Mx_00_CargaRutas import (
    API_URL, MODELO_CLAUDE, MAX_TOKENS, ROL_AGENTE, UMBRAL_RIESGO_GLOBAL
)
import os as _os
from Mx_02_EstructuraPrompt import (
    prompt_aprender_estilo, estilo_por_defecto,
    prompt_generar_replica_virf,
    prompt_evaluar_dimension,
    prompt_sintesis,
)


# ─── Helpers internos ────────────────────────────────────────────────────────

def _llamar_modelo(user_prompt: str, max_tokens: Optional[int] = None) -> str:
    """
    Llama a la API de Anthropic y retorna el texto de la respuesta.
    Lanza excepción si el HTTP falla.
    """
    # BUG FIX: construir headers en tiempo de llamada, no en importación,
    # para garantizar que ANTHROPIC_API_KEY ya fue cargada por load_dotenv()
    _api_key = _os.getenv("ANTHROPIC_API_KEY", "")
    _headers = {
        "Content-Type":      "application/json",
        "anthropic-version": "2023-06-01",
        "x-api-key":         _api_key,
    }
    payload = {
        "model":      MODELO_CLAUDE,
        "max_tokens": max_tokens or MAX_TOKENS,
        "system":     ROL_AGENTE,
        "messages":   [{"role": "user", "content": user_prompt}],
    }
    response = requests.post(
        API_URL,
        headers=_headers,
        json=payload,
        timeout=180,
    )
    response.raise_for_status()
    data = response.json()
    return "".join(
        b.get("text", "")
        for b in data.get("content", [])
        if b.get("type") == "text"
    )


def _parsear_json(texto: str, fallback: dict) -> dict:
    """
    Extrae y parsea el primer objeto JSON encontrado en el texto.
    Si falla, retorna fallback con el raw adjunto.
    """
    limpio = re.sub(r"```(?:json)?|```", "", texto).strip()
    i, j = limpio.find("{"), limpio.rfind("}")
    if i != -1 and j != -1:
        limpio = limpio[i:j + 1]
    try:
        return json.loads(limpio)
    except json.JSONDecodeError:
        return {**fallback, "_raw": texto[:500]}


def _crop_to_json(text: str) -> str:
    """
    Extrae substring entre la primera "{" y la última "}" (fallback).
    
    Parámetros:
        text: string que puede contener JSON
    
    Retorna:
        String con el JSON extraído (o vacío si no se encuentra)
    """
    i, j = text.find("{"), text.rfind("}")
    if i != -1 and j != -1 and j > i:
        return text[i:j+1]
    return ""


def _validar_contrato(data: Dict[str, Any]) -> None:
    """
    Valida que el JSON retornado cumple con el contrato esperado.
    
    Contrato requerido:
    {
      "revision": str (no vacío),
      "hallazgos": list[dict] con campos: tipo, texto, recomendacion, riesgo, criticidad
    }
    
    Parámetros:
        data: dict a validar
    
    Lanza excepción ValueError si no cumple contrato.
    """
    if not isinstance(data, dict):
        raise ValueError("Response debe ser un diccionario JSON")
    
    # Campo revision
    if "revision" not in data:
        raise ValueError("Falta campo 'revision'")
    if not isinstance(data["revision"], str) or not data["revision"].strip():
        raise ValueError("Campo 'revision' debe ser string no vacío")
    
    # Campo hallazgos
    if "hallazgos" not in data:
        raise ValueError("Falta campo 'hallazgos'")
    if not isinstance(data["hallazgos"], list):
        raise ValueError("Campo 'hallazgos' debe ser lista")
    
    # Validar cada hallazgo
    tipos_validos = {"OBSERVACION", "OPORTUNIDAD_MEJORA"}
    criticidades_validas = {"CRITICA", "MODERADA", "BAJA", "POTENCIAL"}
    
    for i, hallazgo in enumerate(data["hallazgos"]):
        if not isinstance(hallazgo, dict):
            raise ValueError(f"Hallazgo {i} no es diccionario")
        
        # Campos requeridos
        for campo in ["tipo", "texto", "recomendacion", "riesgo", "criticidad"]:
            if campo not in hallazgo:
                raise ValueError(f"Hallazgo {i} falta campo '{campo}'")
            if not isinstance(hallazgo[campo], str) or not hallazgo[campo].strip():
                raise ValueError(f"Hallazgo {i} campo '{campo}' debe ser string no vacío")
        
        # Valores válidos
        if hallazgo["tipo"] not in tipos_validos:
            raise ValueError(f"Hallazgo {i}: tipo debe ser {tipos_validos}")
        if hallazgo["criticidad"] not in criticidades_validas:
            raise ValueError(f"Hallazgo {i}: criticidad debe ser {criticidades_validas}")


def llamar_ia_json(
    user_msg: str,
    client: Any,
    deployment: str,
    system_msg: str,
    *,
    max_retries: int = 3,
    base_delay: float = 1.0,
    max_tokens: int = 1024,
    temperature: float = 0.2,
) -> Dict[str, Any]:
    """
    Llama a la API de Azure OpenAI con respuesta JSON validada.
    
    Reintenta con backoff exponencial si la validación falla.
    
    Parámetros:
        user_msg: mensaje del usuario (el prompt)
        client: cliente de Azure OpenAI
        deployment: nombre del deployment (ej: "gpt-4")
        system_msg: mensaje del sistema (rol)
        max_retries: número máximo de reintentos
        base_delay: retardo inicial en segundos
        max_tokens: tokens máximos de respuesta
        temperature: temperatura del modelo (0.2 = determinístico)
    
    Retorna:
        Dict con JSON validado según contrato
    
    Lanza excepción si max_retries se excede
    """
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=deployment,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": user_msg}
                ],
                response_format={"type": "json_object"},
                max_tokens=max_tokens,
                temperature=temperature,
            )
            
            texto_respuesta = response.choices[0].message.content
            
            # Intentar parsear JSON
            try:
                data = json.loads(texto_respuesta)
            except json.JSONDecodeError:
                # Fallback: extraer JSON del texto
                json_str = _crop_to_json(texto_respuesta)
                if json_str:
                    data = json.loads(json_str)
                else:
                    raise ValueError("No se pudo extraer JSON de la respuesta")
            
            # Validar contrato
            _validar_contrato(data)
            
            # Si llegamos aquí, todo está OK
            return data
        
        except (ValueError, json.JSONDecodeError) as e:
            if attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)  # backoff exponencial
                print(f"  [Reintento {attempt+1}/{max_retries}] Validación falló: {e}")
                print(f"  Esperando {delay}s antes de reintentar...")
                time.sleep(delay)
            else:
                raise RuntimeError(f"Falló después de {max_retries} intentos: {e}")
        
        except Exception as e:
            print(f"  [Error en llamada API] {e}")
            raise


# ─── Funciones públicas ───────────────────────────────────────────────────────

def aprender_estilo(texto_informes: str) -> dict:
    """
    Llama al modelo con el texto de informes de referencia.
    Retorna dict con tono, frases y vocabulario aprendido.
    Si no hay texto, retorna el estilo por defecto.
    """
    if not texto_informes.strip():
        return estilo_por_defecto()
    raw = _llamar_modelo(prompt_aprender_estilo(texto_informes))
    return _parsear_json(raw, {"tono": "formal"})


def generar_replica_virf(docs_modelador: list, scripts_modelador: list) -> str:
    """
    Genera el código del script _replica_virf.py como segunda línea.
    Retorna código Python como string.
    """
    raw = _llamar_modelo(
        prompt_generar_replica_virf(docs_modelador, scripts_modelador),
        max_tokens=4000,
    )
    # Limpiar bloques markdown
    return re.sub(r"```(?:python)?|```", "", raw).strip()


def evaluar_dimension(
    dimension: str,
    actividades: list,
    documentos: list,
    estilo: dict,
    modo: str,
    instrucciones_extra: str = "",
    contexto_feedback: str = "",
) -> dict:
    """
    Evalúa las actividades de una dimensión VIRF.
    Maneja el caso de sin documentos (retorna evaluación vacía con preguntas).
    Retorna dict con evaluaciones, cumplimiento y hallazgos.
    """
    fallback = {
        "dimension":               dimension,
        "evaluaciones":            [],
        "nivel_cumplimiento":      0,
        "actividades_sin_evidencia": len(actividades),
        "resumen_dimension":       "Sin actividades.",
        "hallazgos_criticos":      [],
        "preguntas_globales_dimension": [],
    }

    if not actividades:
        return fallback

    # Sin documentos → preguntas automáticas
    if not documentos:
        preguntas = [
            f"No se encontraron documentos para la dimensión {dimension}. "
            f"¿Puede proporcionar los archivos correspondientes?"
        ]
        evals = []
        for a in [x for x in actividades if x.get("requerida", True)]:
            estado = "Solicitar Actas" if dimension == "Gobierno" else "No cumple"
            ev = {
                "control":           a.get("control", ""),
                "tipo_ctrl":         a.get("tipo_ctrl", ""),
                "actividad":         a["actividad"],
                "concepto":          "No evaluable — sin documentos.",
                "estado":            estado,
                "simbolo":           "❌",
                "evidencia":         None,
                "observacion_tecnica": "No se recibieron documentos para esta dimensión.",
                "inconsistencias":   None,
                "riesgo":            "Alto",
                "recomendacion":     "Proporcionar documentación correspondiente.",
                "preguntas_faltantes": preguntas,
            }
            if modo == "preprdc":
                ev.update({"score": 0, "criticidad": "Alto", "score_justificacion": "Sin evidencia."})
            evals.append(ev)

        return {
            "dimension":               dimension,
            "evaluaciones":            evals,
            "nivel_cumplimiento":      0,
            "actividades_sin_evidencia": len(evals),
            "resumen_dimension":       f"Sin documentación para {dimension}.",
            "hallazgos_criticos":      [f"Sin documentación para {dimension}"],
            "preguntas_globales_dimension": preguntas,
        }

    # Llamada normal al modelo
    raw = _llamar_modelo(
        prompt_evaluar_dimension(
            dimension=dimension,
            actividades=actividades,
            documentos=documentos,
            estilo=estilo,
            modo=modo,
            instrucciones_extra=instrucciones_extra,
            contexto_feedback=contexto_feedback,
        ),
        max_tokens=4000,
    )

    resultado = _parsear_json(raw, fallback)

    # Recalcular actividades_sin_evidencia
    evals = resultado.get("evaluaciones", [])
    sin_ev = sum(
        1 for e in evals
        if not e.get("evidencia") or e.get("estado") == "No cumple"
    )
    resultado["actividades_sin_evidencia"] = sin_ev

    return resultado


def generar_sintesis(
    resultados: dict,
    titulo: str,
    modo: str,
    estilo: dict,
    tier: str,
) -> dict:
    """
    Genera la síntesis ejecutiva, dictamen global y plan de acción.
    Retorna dict con resumen_ejecutivo, dictamen_global, plan_accion, etc.
    """
    fallback = {
        "resumen_ejecutivo":       "Ver resultados por dimensión.",
        "dictamen_global":         "APROBADO CON OBSERVACIONES",
        "nivel_riesgo":            "Medio",
        "riesgo_global_alto":      False,
        "justificacion_dictamen":  "",
        "principales_hallazgos":   [],
        "informacion_requerida":   [],
        "plan_accion":             [],
        "proxima_revision":        "Próximo trimestre",
        "conclusion_narrativa":    "",
    }
    raw = _llamar_modelo(
        prompt_sintesis(resultados, titulo, modo, estilo, tier),
        max_tokens=4000,
    )
    return _parsear_json(raw, fallback)
