"""
Mx_00_CargaRutas.py
====================
Configuración central del Motor VIRF.
Define rutas, parámetros de la API, constantes del dominio
y el rol del agente como Auditor Senior independiente.

Responsabilidades:
  - Cargar API key desde variables de entorno
  - Definir rutas de inputs, outputs y repositorio
  - Definir constantes de evaluación (umbrales, tier, modos)
  - Exponer ROL_AGENTE y CUESTIONAMIENTOS_METODOLOGICOS
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ─── API ─────────────────────────────────────────────────────────────────────
API_KEY        = os.getenv("ANTHROPIC_API_KEY", "")
MODELO_CLAUDE  = "claude-sonnet-4-6"          # ← actualizado a Sonnet 4.6
MAX_TOKENS     = 4000
API_URL        = "https://api.anthropic.com/v1/messages"
# NOTA: API_HEADERS NO se define aquí — se construye en Mx_03 en tiempo de llamada
# para garantizar que ANTHROPIC_API_KEY ya fue cargada por load_dotenv().

# ─── RUTAS ───────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.parent  # raíz del proyecto

RUTAS = {
    "repositorio_informes": BASE_DIR / "repositorio_informes",
    "estandares_virf":      BASE_DIR / "inputs" / "Estandares_VIRF.xlsx",
    "outputs":              BASE_DIR / "outputs",
    "inputs": {
        # documentacion separada en subdirectorios para que leer_carpeta funcione con rglob
        "doc_modelamiento": BASE_DIR / "inputs" / "documentacion" / "modelamiento",
        "doc_seguimiento":  BASE_DIR / "inputs" / "documentacion" / "seguimiento",
        "papers":           BASE_DIR / "inputs" / "papers",
        "calidad_datos":    BASE_DIR / "inputs" / "calidad_datos",
        "implementacion":   BASE_DIR / "inputs" / "implementacion",
        "usos":             BASE_DIR / "inputs" / "usos",
    },
}

# ─── PARÁMETROS DE LECTURA ───────────────────────────────────────────────────
MAX_CHARS_DOC    = 5000
MAX_CHARS_CODIGO = 8000
MAX_FILAS_EXCEL  = 150

# ─── UMBRALES ─────────────────────────────────────────────────────────────────
UMBRAL_RIESGO_GLOBAL = 0.30   # Si >30% sin evidencia → RIESGO GLOBAL ALTO

# ─── TIERS VÁLIDOS ───────────────────────────────────────────────────────────
TIERS_VALIDOS = ("I", "II", "III", "IV")

# ─── MODOS ───────────────────────────────────────────────────────────────────
MODO_PREPRDC = "preprdc"   # Evaluación con score + criticidad (iterativo)
MODO_PRDC    = "prdc"      # Solo estado + observación (producción)

# ─── MAPEO DIMENSIÓN → CARPETAS DE INPUT ─────────────────────────────────────
AMBITO_A_INPUTS = {
    "Documentación":    ["doc_modelamiento", "doc_seguimiento", "papers"],
    "Calidad de Datos": ["calidad_datos", "doc_modelamiento"],
    "Metodología":      ["doc_modelamiento", "papers", "doc_seguimiento"],
    "Gobierno":         ["doc_modelamiento", "implementacion"],
    "Implementación":   ["implementacion", "doc_modelamiento"],
    "Uso e Integración":["usos", "implementacion"],
}

# ─── INSTRUCCIONES ESPECÍFICAS POR DIMENSIÓN ─────────────────────────────────
INSTRUCCIONES_DIMENSION = {
    "Documentación": (
        "Revisa con mayor prioridad los manuales (.docx/.pdf) y scripts de seguimiento. "
        "El manual metodológico debe tener teoría, supuestos y justificación del modelo. "
        "El operativo debe describir la ejecución. Para backtesting buscar Kupiec, "
        "Christoffersen, López o Berkowitz. Si no existen, generar preguntas específicas."
    ),
    "Calidad de Datos": (
        "Buscar el script _replica_virf.py. Si no existe, el agente lo generará. "
        "Verificar: missing (MCAR/MAR/MNAR), duplicados, outliers (cuestionar Z-score), "
        "integridad referencial. Revisar scripts del modelador línea por línea."
    ),
    "Metodología": (
        "Centrarse en la justificación del modelo, supuestos y su validación empírica. "
        "Para LaR/VaR: verificar pruebas Kupiec, Christoffersen y análisis de excedencias. "
        "Cuestionar si no hay comparación con modelo alternativo."
    ),
    "Gobierno": (
        "Solo aceptar actas formales firmadas. Un correo NO equivale a acta. "
        "Verificar tiering asignado y su justificación. Si falta evidencia → Solicitar Actas."
    ),
    "Implementación": (
        "Buscar evidencia de correos de aprobación para paso a producción. "
        "Si no existen correos → generar pregunta específica. "
        "Verificar UAT documentadas y controles en pipeline productivo."
    ),
    "Uso e Integración": (
        "Identificar quiénes son los usuarios del modelo y para qué lo usan. "
        "Verificar que los outputs del modelo en producción son consistentes con los de desarrollo. "
        "Buscar reportes de seguimiento presentados a comités."
    ),
}

# ─── ROL DEL AGENTE ──────────────────────────────────────────────────────────
ROL_AGENTE = """Actúas como Auditor Senior en Validación Independiente de Modelos (VIRF).
Eres experto en modelos financieros estocásticos y de machine learning, con especialización
en Liquidity at Risk (LaR), Value at Risk (VaR), Expected Shortfall (ES), modelos de
crédito (PD, LGD, EAD), scoring, IFRS 9, y modelos de fraude/AML.

Tu comportamiento es:
- CRÍTICO e independiente (segunda línea de defensa)
- Basado en EVIDENCIA EXPLÍCITA — nunca asumes información faltante
- Detectas inconsistencias entre documentación y código
- Priorizas manuales y scripts de seguimiento como fuentes primarias
- Conoces las pruebas estadísticas: Kupiec, Christoffersen, López, Berkowitz
- Aplicas marco regulatorio: SR 11-7, SS3/17, EBA GL, Basilea III/IV, IFRS 9

NO eres desarrollador. NO completas vacíos con suposiciones.
Cuando falta evidencia, generas preguntas específicas y concretas.
NUNCA validas sin evidencia. SIEMPRE actúas como segunda línea independiente."""

# ─── CUESTIONAMIENTOS METODOLÓGICOS AUTOMÁTICOS ──────────────────────────────
CUESTIONAMIENTOS_METODOLOGICOS = {
    "outliers_zscore": {
        "detectar":         ["zscore", "z_score", "z-score", "scipy.stats.zscore", "3 sigma"],
        "detectar_ausencia": False,
        "contexto":         "Eliminación de outliers con Z-score",
        "critica": (
            "Z-score asume normalidad y es sensible a los propios outliers. "
            "Para datos financieros fat-tail usar: GESD (Generalized ESD), "
            "IQR robusto, Isolation Forest (multivariado) o Mahalanobis Distance."
        ),
    },
    "imputation_mean": {
        "detectar":         ["fillna(mean", "fillna(df.mean", "SimpleImputer.*mean"],
        "detectar_ausencia": False,
        "contexto":         "Imputación de missing con media aritmética",
        "critica": (
            "Imputar con media destruye varianza e introduce sesgo. "
            "Alternativas: MICE (IterativeImputer), KNN Imputation, MissForest. "
            "Referencia: EBA GL/2021/07 §45."
        ),
    },
    "train_test_split_random": {
        "detectar":         ["train_test_split", "shuffle=True"],
        "detectar_ausencia": False,
        "contexto":         "División aleatoria train/test en datos temporales",
        "critica": (
            "División aleatoria introduce data leakage en datos financieros temporales. "
            "Usar split temporal (OOT) con mínimo 6-12 meses fuera de muestra. SR 11-7."
        ),
    },
    "sin_psi": {
        "detectar":         ["psi", "population_stability", "estabilidad_poblacional"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de análisis PSI",
        "critica": (
            "No se detecta PSI. SR 11-7 y EBA exigen monitoreo de estabilidad. "
            "PSI<0.10: estable | 0.10-0.25: observación | >0.25: rediseño requerido."
        ),
    },
    "sin_backtesting_lar": {
        "detectar":         ["kupiec", "christoffersen", "lopez_test", "berkowitz", "var_backtest"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de backtesting estadístico para modelos de riesgo",
        "critica": (
            "No se detectan pruebas de backtesting (Kupiec, Christoffersen, López). "
            "Requeridas por Basilea III (FRTB) y SR 11-7 para modelos VaR/LaR."
        ),
    },
    "sin_shap_modelos_complejos": {
        "detectar": [
            "XGBClassifier", "LGBMClassifier", "RandomForestClassifier",
            "GradientBoostingClassifier", "xgboost", "lightgbm",
        ],
        "detectar_ausencia": False,
        "contexto":         "Modelos no lineales sin análisis de explicabilidad",
        "critica": (
            "Modelos tree-based sin SHAP values. Incumple SR 11-7 (explicabilidad) "
            "y GDPR art.22. Implementar SHAP para explicabilidad global y local."
        ),
    },
    "sin_replica_virf": {
        "detectar":         ["_replica_virf", "replica_virf"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de script _replica_virf.py de control de calidad de datos",
        "critica": (
            "No se detecta script _replica_virf.py. Este script es el control de "
            "segunda línea para calidad de datos. El agente generará una propuesta."
        ),
    },
}
