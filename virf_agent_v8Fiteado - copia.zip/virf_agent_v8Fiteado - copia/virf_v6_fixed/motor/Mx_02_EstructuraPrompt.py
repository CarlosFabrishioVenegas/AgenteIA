"""
Mx_02_EstructuraPrompt.py
==========================
Construcción de todos los prompts que se envían al modelo Claude.
Cada función devuelve el string listo para usar como mensaje "user".

Prompts incluidos:
  - prompt_aprender_estilo()         → analiza informes de referencia
  - prompt_generar_replica_virf()    → genera script de 2da línea
  - prompt_detectar_cuestionamientos() → (inline, ver Mx_04)
  - prompt_evaluar_dimension()       → evaluación de una dimensión VIRF
  - prompt_sintesis()                → dictamen global y plan de acción

Responsabilidades:
  - Concentrar toda la lógica de construcción de texto de los prompts
  - Mantener separado el "qué le pedimos" del "cómo llamamos a la API"
"""

import json
from itertools import groupby
from typing import Optional

from Mx_00_CargaRutas import ROL_AGENTE, UMBRAL_RIESGO_GLOBAL

ESTRUCTURA_AMBITOS = {}


# ─── 1. Aprendizaje de estilo ─────────────────────────────────────────────────

def prompt_aprender_estilo(texto_informes: str) -> str:
    """Prompt para que el modelo aprenda el lenguaje de los informes de referencia."""
    return f"""Analiza estos informes de validación independiente de modelos financieros.
Extrae los patrones de redacción para replicarlos exactamente.

INFORMES DE REFERENCIA:
{texto_informes[:10000]}

Responde SOLO con JSON válido:
{{
  "tono": "descripción del tono técnico/formal",
  "frases_cumple":   ["frase usada cuando hay evidencia suficiente", "..."],
  "frases_parcial":  ["frase usada para cumplimiento parcial", "..."],
  "frases_no_cumple":["frase usada cuando falta evidencia", "..."],
  "frases_solicitar":["frase para solicitar documentación faltante", "..."],
  "vocabulario":     ["término técnico 1", "término técnico 2", "..."],
  "estructura_hallazgo": "cómo se redacta un hallazgo completo",
  "estilo_preguntas": "cómo se formulan preguntas de información faltante"
}}"""


def estilo_por_defecto() -> dict:
    """Estilo base cuando no hay informes de referencia disponibles."""
    return {
        "tono": "Formal, técnico, regulatorio. Lenguaje de auditoría de riesgo de modelos.",
        "frases_cumple":    ["Se verifica evidencia suficiente que da cumplimiento al requerimiento."],
        "frases_parcial":   ["Se cumple parcialmente; se recomienda fortalecer el análisis."],
        "frases_no_cumple": ["No se evidencia documentación que dé cumplimiento al requerimiento."],
        "frases_solicitar": ["Se requiere presentar evidencia formal de:"],
        "vocabulario":      ["validación independiente", "backtesting", "calibración",
                             "estabilidad poblacional", "Kupiec", "Christoffersen", "LaR", "VaR"],
        "estructura_hallazgo": "ID | Dimensión | Evidencia | Estado | Riesgo | Recomendación",
        "estilo_preguntas": "¿Existe [documento/análisis]? ¿En qué sección/script se encuentra?",
    }


# ─── 2. Generar _replica_virf.py ──────────────────────────────────────────────

def prompt_generar_replica_virf(docs_modelador: list, scripts_modelador: list) -> str:
    """Prompt para generar el script de control de calidad de datos de segunda línea."""
    ctx_docs = "\n".join(
        f"[{d['nombre']}]\n{d['contenido'][:2000]}"
        for d in docs_modelador[:3]
    )
    ctx_code = "\n".join(
        f"[{c['nombre']}]\n{c['contenido'][:3000]}"
        for c in scripts_modelador[:2]
    )
    return f"""Eres un experto en calidad de datos financieros y segunda línea de defensa (VIRF).

Basándote en los manuales y scripts del modelador, genera el script Python _replica_virf.py
que actúa como control independiente de calidad de datos.

MANUALES DEL MODELADOR:
{ctx_docs}

SCRIPTS DEL MODELADOR (si existen):
{ctx_code}

El script debe:
1. Replicar de forma independiente las transformaciones de datos del modelador
2. Verificar missing values por variable (con test de Little para MCAR si aplica)
3. Detectar duplicados exactos y cuasi-duplicados
4. Identificar outliers (usar IQR robusto o GESD, NO Z-score simple)
5. Verificar integridad referencial
6. Verificar consistencia temporal de los datos
7. Generar un reporte de hallazgos en formato DataFrame / Excel
8. Incluir comentarios explicando cada validación y su justificación

Genera el código Python completo, funcional y bien comentado.
Incluye al inicio un docstring con: propósito, inputs esperados, outputs y autor (VIRF - Segunda Línea).

Responde SOLO con el código Python, sin explicaciones adicionales."""


# ─── 3. Evaluar dimensión ─────────────────────────────────────────────────────

def prompt_evaluar_dimension(
    dimension: str,
    actividades: list,
    documentos: list,
    estilo: dict,
    modo: str,
    instrucciones_extra: str = "",
    contexto_feedback: str = "",
) -> str:
    """
    Prompt principal de evaluación de una dimensión VIRF.
    Ordena documentos por prioridad, agrupa actividades por control.
    """
    # Ordenar documentos por prioridad
    manuales    = [d for d in documentos if d["tipo"] in ("PDF", "DOCX", "DOC")]
    scripts_seg = [d for d in documentos if d["tipo"] == "PY" and
                   any(k in d["nombre"].lower() for k in
                       ("seguimiento", "backtest", "kupiec", "christoff", "replica_virf", "monitor"))]
    scripts_mod = [d for d in documentos if d["tipo"] == "PY" and d not in scripts_seg]
    excels      = [d for d in documentos if d["tipo"] in ("XLSX", "XLS", "XLSM", "CSV")]
    otros       = [d for d in documentos if d not in manuales + scripts_seg + scripts_mod + excels]

    docs_str = ""
    for etiqueta, grupo in [
        ("MANUALES (prioridad 1)",               manuales),
        ("SCRIPTS DE SEGUIMIENTO (prioridad 2)", scripts_seg),
        ("SCRIPTS DE MODELADOR (prioridad 3)",   scripts_mod),
        ("EXCELS (prioridad 4)",                 excels),
        ("OTROS (prioridad 5)",                  otros),
    ]:
        if grupo:
            docs_str += f"\n{'─'*40}\n{etiqueta}:\n{'─'*40}\n"
            for d in grupo:
                docs_str += f"\n[{d['nombre']}]\n{d['contenido'][:2500]}\n"

    # Agrupar actividades por control
    grupos_str = ""
    acts_sorted = sorted(actividades, key=lambda a: a.get("control", ""))
    for ctrl, grp in groupby(acts_sorted, key=lambda a: a.get("control", "")):
        acts = list(grp)
        tipo = acts[0].get("tipo_ctrl", "")
        grupos_str += f"\n  [CONTROL {tipo.upper()}] {ctrl}\n"
        for a in acts:
            req = "REQUERIDA" if a.get("requerida") else "OPCIONAL"
            grupos_str += f"    · [{req}] {a['actividad']}\n"

    # Campos extra según modo
    campos_extra = ""
    if modo == "preprdc":
        campos_extra = """
      "score": 85,          // 0-100: calidad de la evidencia encontrada
      "criticidad": "Alto|Medio|Bajo",  // riesgo si no se corrige
      "score_justificacion": "por qué ese score","""

    # Bloque de instrucciones adicionales
    bloques_extra = ""
    if instrucciones_extra:
        bloques_extra += f"\nINSTRUCCIONES ESPECIALES:\n{instrucciones_extra}"
    if contexto_feedback:
        bloques_extra += f"\nAPRENDIZAJE DE CORRIDAS ANTERIORES (feedback del validador):\n{contexto_feedback}"

    return f"""Eres un Auditor Senior VIRF evaluando la dimensión: {dimension.upper()}
Modo de ejecución: {modo.upper()}

REGLAS CRÍTICAS:
- NO asumir información faltante. Si no hay evidencia → generar preguntas específicas.
- Prioridad de fuentes: Manuales > Scripts Seguimiento > Scripts Modelador > Excels > Otros.
- Detectar inconsistencias entre documentación y código.
- Elevar a criticidad ALTA si falta evidencia en actividades regulatorias críticas.
- Condición de corte: si >30% de actividades no tienen evidencia → señalarlo explícitamente.
{bloques_extra}

ESTILO DE REDACCIÓN (aprendido de informes previos):
{json.dumps(estilo, ensure_ascii=False)}

ACTIVIDADES A EVALUAR:
{grupos_str}

DOCUMENTOS DISPONIBLES (en orden de prioridad):
{docs_str[:9000]}

Para CADA actividad REQUERIDA debes:
1. Buscar evidencia EXPLÍCITA — citar página/sección/línea concreta.
2. Clasificar: ✅ Cumple | ⚠️ Parcial | ❌ No cumple
3. Si no hay evidencia → generar pregunta específica (¿Existe X? ¿Dónde está Y?)
4. Detectar inconsistencias documentación vs código si existen.

Responde SOLO con JSON válido:
{{
  "dimension": "{dimension}",
  "evaluaciones": [
    {{
      "control": "nombre del control",
      "tipo_ctrl": "Cuantitativo|Cualitativo",
      "actividad": "texto exacto de la actividad",
      "concepto": "qué valida técnicamente esta actividad (1-2 oraciones técnicas)",
      "estado": "Cumple|Parcial|No cumple",
      "simbolo": "✅|⚠️|❌",
      "evidencia": "cita concreta: nombre archivo, sección, línea — o null si no hay",
      "observacion_tecnica": "hallazgo técnico detallado con el estilo aprendido",
      "inconsistencias": "inconsistencias doc vs código detectadas, o null",
      "riesgo": "Alto|Medio|Bajo",
      "recomendacion": "acción concreta recomendada",
      "preguntas_faltantes": ["¿Pregunta 1?", "¿Pregunta 2?"]  // vacío [] si hay evidencia{campos_extra}
    }}
  ],
  "resumen_dimension": "párrafo ejecutivo al estilo del informe de referencia",
  "nivel_cumplimiento": 75,
  "actividades_sin_evidencia": 2,
  "hallazgos_criticos": ["hallazgo 1", "..."],
  "preguntas_globales_dimension": ["¿Pregunta global 1?", "..."]
}}"""


# ─── 4. Síntesis y dictamen final ─────────────────────────────────────────────

def prompt_sintesis(
    resultados: dict,
    titulo: str,
    modo: str,
    estilo: dict,
    tier: str,
) -> str:
    """Prompt para generar la síntesis ejecutiva y el dictamen final."""
    total_acts   = sum(len(r.get("evaluaciones", [])) for r in resultados.values())
    total_sin_ev = sum(r.get("actividades_sin_evidencia", 0) for r in resultados.values())
    pct_sin_ev   = total_sin_ev / total_acts if total_acts > 0 else 0
    condicion_corte = pct_sin_ev > UMBRAL_RIESGO_GLOBAL

    resumen = {
        dim: {
            "cumplimiento":  res.get("nivel_cumplimiento", 0),
            "sin_evidencia": res.get("actividades_sin_evidencia", 0),
            "hallazgos":     res.get("hallazgos_criticos", []),
        }
        for dim, res in resultados.items()
    }

    campos_score = ""
    if modo == "preprdc":
        campos_score = """
  "score_global": 72,
  "distribucion_scores": {"Alto": 3, "Medio": 5, "Bajo": 2},"""

    alerta_corte = (
        "ALERTA: Más del 30% de actividades sin evidencia — "
        "el dictamen debe reflejar RIESGO GLOBAL ALTO / VALIDACIÓN INSUFICIENTE"
        if condicion_corte else ""
    )

    return f"""Genera la síntesis final del informe de validación VIRF.

TÍTULO: {titulo}
TIER: {tier}
MODO: {modo}
CONDICIÓN DE CORTE ACTIVADA: {condicion_corte} ({pct_sin_ev:.0%} actividades sin evidencia)

RESULTADOS POR DIMENSIÓN:
{json.dumps(resumen, ensure_ascii=False, indent=2)}

ESTILO A USAR: {json.dumps(estilo, ensure_ascii=False)}

Redacta con el estilo y lenguaje de un Auditor Senior de Validación Independiente.
{alerta_corte}

Responde SOLO con JSON válido:
{{
  "resumen_ejecutivo": "3-5 párrafos",
  "dictamen_global": "APROBADO|APROBADO CON OBSERVACIONES|RECHAZADO|VALIDACIÓN INSUFICIENTE",
  "nivel_riesgo": "Bajo|Medio|Alto|Crítico",
  "riesgo_global_alto": {str(condicion_corte).lower()},
  "justificacion_dictamen": "párrafo de justificación",
  "principales_hallazgos": [
    {{"id":"H01","dimension":"...","hallazgo":"...","severidad":"Alta|Media|Baja","accion":"..."}}
  ],
  "informacion_requerida": [
    {{"dimension":"...","pregunta":"¿...?","actividad_origen":"...","criticidad":"Alta|Media|Baja"}}
  ],
  "plan_accion": [
    {{"item":1,"accion":"...","responsable":"...","plazo":"...","prioridad":"INMEDIATA|30D|90D"}}
  ],{campos_score}
  "proxima_revision": "período sugerido",
  "conclusion_narrativa": "párrafo final"
}}"""


# ─── NUEVA: Construcción de prompt por control ────────────────────────────────

def construir_prompt_final(
    prompt_control: str,
    manual: str,
    script: str,
    resultado_data: str = "",
) -> str:
    """
    Arma el prompt final para evaluación de un control individual.
    
    Estructura:
    1. ROL del auditor
    2. PROMPT específico del control
    3. MANUAL (evidencia doc)
    4. SCRIPT (evidencia de código)
    5. RESULTADOS DE MOTOR DATA (si aplica)
    6. INSTRUCCIONES DE SALIDA JSON con contrato estricto
    
    Parámetros:
        prompt_control: pregunta específica del control (qué evaluar)
        manual: texto del manual/documentación
        script: texto del script/código del modelador
        resultado_data: salida del motor de controles automáticos (opcional)
    
    Retorna:
        String listo para enviar a la API
    """
    bloque_data = f"\n\n### RESULTADOS DE CONTROLES AUTOMÁTICOS\n{resultado_data}" if resultado_data else ""
    
    return f"""{ROL_AGENTE}

### CONTROL A EVALUAR
{prompt_control}

### EVIDENCIA: MANUAL/DOCUMENTACIÓN
{manual if manual else "[SIN MANUAL DISPONIBLE]"}

### EVIDENCIA: SCRIPT/CÓDIGO
{script if script else "[SIN SCRIPT DISPONIBLE]"}
{bloque_data}

### INSTRUCCIONES DE SALIDA
Responde SOLO con JSON válido (sin markdown). No incluyas explicaciones adicionales.

### CONTRATO DE SALIDA (JSON REQUERIDO)
{{
  "revision": "<máx. 2 párrafos técnicos con análisis de la evidencia>",
  "hallazgos": [
    {{
      "tipo": "OBSERVACION | OPORTUNIDAD_MEJORA",
      "texto": "<descripción del hallazgo>",
      "recomendacion": "<acción concreta recomendada>",
      "riesgo": "<nivel de riesgo: Alto|Medio|Bajo|No concluyente>",
      "criticidad": "CRITICA | MODERADA | BAJA | POTENCIAL"
    }}
  ]
}}

Reglas:
- revision: síntesis técnica de la evaluación (no vacío)
- hallazgos: puede estar vacío [] si no hay problemas
- Cada hallazgo debe tener TODOS los campos string no vacíos
- tipo SOLO puede ser: OBSERVACION o OPORTUNIDAD_MEJORA
- criticidad SOLO puede ser: CRITICA, MODERADA, BAJA o POTENCIAL
- Si falta evidencia y no puedes concluir: usa riesgo="No concluyente"
"""
