#!/usr/bin/env python3
"""
test_agente.py — Verificar que agente.py esté correctamente configurado

Ejecuta: python test_agente.py
"""

import sys
import argparse
from pathlib import Path

def test_imports():
    """Verificar que todos los imports funcionen."""
    print("\n📦 VERIFICANDO IMPORTS...")
    try:
        from config import OUTPUTS_DIR, ESTANDARES_PATH
        print("  ✅ config.py")
        
        from modulos.motor_ia_v2 import orquestar_pipeline_virf
        print("  ✅ modulos.motor_ia_v2")
        
        from modulos.feedback import calcular_estadisticas
        print("  ✅ modulos.feedback")
        
        from modulos.generador_estadistica_feedback import generar_informe_estadistica
        print("  ✅ modulos.generador_estadistica_feedback")
        
        return True
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return False

def test_argparse():
    """Verificar que los argumentos estén definidos."""
    print("\n⚙️  VERIFICANDO ARGUMENTOS...")
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--titulo", default=None)
    parser.add_argument("--tier", default=None)
    parser.add_argument("--excel", default=None)
    parser.add_argument("--control", action="store_true")
    parser.add_argument("--prdc", action="store_true")
    parser.add_argument("--estadisticafeedback", action="store_true")
    
    try:
        # Test 1: --control + --excel
        args = parser.parse_args([
            "--titulo", "Test",
            "--tier", "1",
            "--excel", "inputs/calidad_datos/ControlesData.xlsx",
            "--control"
        ])
        assert args.titulo == "Test"
        assert args.tier == "1"
        assert args.excel == "inputs/calidad_datos/ControlesData.xlsx"
        assert args.control == True
        print("  ✅ Argumentos: --titulo, --tier, --excel, --control")
        
        # Test 2: --prdc
        args = parser.parse_args(["--titulo", "Test", "--tier", "1", "--prdc"])
        assert args.prdc == True
        print("  ✅ Argumentos: --prdc")
        
        # Test 3: --estadisticafeedback
        args = parser.parse_args(["--estadisticafeedback"])
        assert args.estadisticafeedback == True
        print("  ✅ Argumentos: --estadisticafeedback")
        
        return True
    except Exception as e:
        print(f"  ❌ Error: {e}")
        return False

def test_file_paths():
    """Verificar rutas de archivos."""
    print("\n📁 VERIFICANDO RUTAS...")
    
    from config import OUTPUTS_DIR, ESTANDARES_PATH
    
    # Test ESTANDARES_PATH
    if ESTANDARES_PATH.exists():
        print(f"  ✅ ESTANDARES_PATH: {ESTANDARES_PATH}")
    else:
        print(f"  ⚠️  ESTANDARES_PATH no existe: {ESTANDARES_PATH}")
    
    # Test OUTPUTS_DIR
    if OUTPUTS_DIR.exists():
        print(f"  ✅ OUTPUTS_DIR: {OUTPUTS_DIR}")
    else:
        try:
            OUTPUTS_DIR.mkdir(parents=True, exist_ok=True)
            print(f"  ✅ OUTPUTS_DIR creado: {OUTPUTS_DIR}")
        except Exception as e:
            print(f"  ❌ No se pudo crear OUTPUTS_DIR: {e}")
            return False
    
    # Test Excel para Calidad de Datos
    excel_cdd = Path("inputs/calidad_datos/ControlesData.xlsx")
    if excel_cdd.exists():
        print(f"  ✅ Excel (Calidad de Datos): {excel_cdd}")
    else:
        print(f"  ⚠️  Excel (Calidad de Datos) no existe: {excel_cdd}")
    
    return True

def test_anthropic_api():
    """Verificar configuración de Anthropic API."""
    print("\n🔐 VERIFICANDO API ANTHROPIC...")
    
    import os
    
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if api_key:
        masked_key = api_key[:10] + "..." + api_key[-4:]
        print(f"  ✅ ANTHROPIC_API_KEY configurada: {masked_key}")
        return True
    else:
        print(f"  ❌ ANTHROPIC_API_KEY no configurada")
        print(f"     Ejecuta primero:")
        print(f"     • PowerShell: $env:ANTHROPIC_API_KEY = 'sk-ant-...'")
        print(f"     • Bash: export ANTHROPIC_API_KEY='sk-ant-...'")
        return False

def main():
    print("\n" + "=" * 70)
    print("  🧪 TEST DE CONFIGURACIÓN — AGENTE VIRF")
    print("=" * 70)
    
    results = []
    
    results.append(("Imports", test_imports()))
    results.append(("Argumentos", test_argparse()))
    results.append(("Rutas de archivo", test_file_paths()))
    results.append(("API Anthropic", test_anthropic_api()))
    
    print("\n" + "=" * 70)
    print("  📊 RESUMEN")
    print("=" * 70)
    
    for name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"  {status:10} {name}")
    
    all_passed = all(result for _, result in results)
    
    print("\n" + "=" * 70)
    if all_passed:
        print("  ✅ TODOS LOS TESTS PASARON — Sistema listo para usar")
    else:
        print("  ❌ ALGUNOS TESTS FALLARON — Revisa los errores anteriores")
    print("=" * 70 + "\n")
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    sys.exit(main())
