"""
agente.py — Punto de entrada del agente VIRF

PIPELINE 1: CALIDAD DE DATOS (nuevo - recomendado)
  python agente.py --titulo "Modelo LaR" --tier 1 --excel inputs/calidad_datos/ControlesData.xlsx --control
  python agente.py --titulo "Modelo LaR" --tier 1 --excel inputs/calidad_datos/ControlesData.xlsx --control --prdc

PIPELINE 2: TODOS LOS ÁMBITOS (legacy - análisis completo)
  python agente.py --titulo "Modelo LaR" --tier 1
  python agente.py --titulo "Modelo LaR" --tier 1 --prdc

ESTADÍSTICAS:
  python agente.py --estadisticafeedback
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path

from config import OUTPUTS_DIR, ESTANDARES_PATH, BASE_DIR
from modulos.motor_ia_v2 import orquestar_pipeline_virf, evaluar_todos_controles
from modulos.motor_ia import (
    leer_estandares_virf, cargar_todos_inputs, inputs_para_dimension,
    evaluar_ambito_completo, calcular_score_ambito, calcular_score_global,
    get_semaforo, generar_resumen_ejecutivo,
)
from modulos.generador_word import generar_word_informe
from modulos.feedback import calcular_estadisticas
from modulos.generador_estadistica_feedback import generar_informe_estadistica

CONTROLES_DATA_PATH = BASE_DIR / "inputs" / "calidad_datos" / "ControlesData.xlsx"


def modo_estadistica_feedback():
    print("\n" + "═" * 65)
    print("  📈 ESTADÍSTICAS DE PRECISIÓN DEL AGENTE VIRF")
    print("═" * 65 + "\n")

    stats = calcular_estadisticas()
    if "error" in stats:
        print(f"  [!] {stats['error']}")
        print("  Ejecuta al menos una validación con feedback antes de usar este modo.\n")
        sys.exit(0)

    print(f"  Total feedbacks registrados : {stats['total_feedbacks']}")
    print(f"  Período                     : {stats['primer_feedback']} → {stats['ultimo_feedback']}")
    print(f"\n  {'MÉTRICA':<35} {'VALOR':>10}")
    print(f"  {'─'*47}")
    print(f"  {'Evaluaciones exactas':<35} {stats['pct_exactas']:>9.1f}%")
    print(f"  {'Dentro de ±1 punto':<35} {stats['pct_dentro_1_punto']:>9.1f}%")
    print(f"  {'Error medio absoluto (MAE)':<35} {stats['mae']:>10.3f}")
    print(f"  {'Sesgo promedio':<35} {stats['sesgo_promedio']:>10.3f}")
    print(f"  {'Interpretación sesgo':<35} {stats['sesgo_interpretacion']}")
    print(f"  {'Sobreestimaciones':<35} {stats['n_sobreestimaciones']:>10}")
    print(f"  {'Subestimaciones':<35} {stats['n_subestimaciones']:>10}")
    print(f"\n  {'ÁMBITO':<35} {'MAE':>6}  {'EXACTOS':>8}  {'±1 PTO':>7}")
    print(f"  {'─'*58}")
    for amb, s in stats["por_ambito"].items():
        print(f"  {amb:<35} {s['mae']:>6.3f}  {s['pct_exactos']:>7.1f}%  {s['pct_1_punto']:>6.1f}%")

    print("\n  📊 Generando informe Excel detallado...")
    ruta = generar_informe_estadistica(OUTPUTS_DIR)
    if ruta:
        print(f"\n  ✅ Informe guardado en: {ruta.name}")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Agente VIRF — Validador de modelos LaR/VaR"
    )
    parser.add_argument("--titulo",              default=None,  help="Nombre del modelo")
    parser.add_argument("--tier",                default=None,  help="Tier del modelo (1, 2, 3, 4)")
    parser.add_argument("--excel",               default=None,  help="Ruta al Excel de controles (para pipeline Calidad de Datos)")
    parser.add_argument("--control",             action="store_true", help="Usar pipeline por CONTROL (Calidad de Datos)")
    parser.add_argument("--prdc",                action="store_true", help="Modo producción (genera Word)")
    parser.add_argument("--estadisticafeedback", action="store_true", help="Ver estadísticas de feedback")

    args = parser.parse_args()

    # ═════════════════════════════════════════════════════════════════════════
    # MODO 1: Estadísticas
    # ═════════════════════════════════════════════════════════════════════════
    if args.estadisticafeedback:
        modo_estadistica_feedback()
        return

    # ═════════════════════════════════════════════════════════════════════════
    # MODO 2: Pipeline por CONTROL (Calidad de Datos)
    # ═════════════════════════════════════════════════════════════════════════
    if args.control:
        if not args.titulo:
            parser.error("--titulo es obligatorio")
        if not args.tier:
            parser.error("--tier es obligatorio (1, 2, 3, 4)")
        if not args.excel:
            parser.error("--excel es obligatorio (ruta al Excel de controles)")
        
        excel_path = Path(args.excel)
        if not excel_path.exists():
            print(f"  ❌ Error: {args.excel} no encontrado")
            sys.exit(1)
        
        fecha_informe = datetime.now().strftime("%Y-%m-%d")
        
        print("\n" + "═" * 70)
        print("  🔍 AGENTE VIRF — PIPELINE CALIDAD DE DATOS (POR CONTROL)")
        print(f"  Modelo: {args.titulo}")
        print(f"  Tier:   {args.tier}")
        print(f"  Modo:   {'PRODUCCIÓN (--prdc)' if args.prdc else 'PRE-PRODUCCIÓN'}")
        print("═" * 70 + "\n")
        
        try:
            resultado = orquestar_pipeline_virf(
                base_project_path=str(OUTPUTS_DIR.parent),
                excel_controles=str(excel_path),
                nombre_modelo=args.titulo,
                fecha_informe=fecha_informe,
                tier=str(args.tier),
                datasets_dict=None,
                filtro_controles=None,
            )
            
            print("\n" + "═" * 70)
            print("  ✅ PIPELINE CALIDAD DE DATOS COMPLETADO")
            print("═" * 70)
            print(f"\n  📊 RESULTADOS:")
            print(f"    • Controles evaluados: {resultado['controles_ok']}/{resultado['total_controles']}")
            print(f"    • Hallazgos críticos:  {resultado['hallazgos_criticos']}")
            print(f"    • Estado:              {resultado['estado']}")
            print(f"\n  📁 ARCHIVOS GENERADOS:")
            print(f"    • JSON:    {Path(resultado['ruta_json']).name}")
            if resultado.get("ruta_word"):
                print(f"    • Word:    {Path(resultado['ruta_word']).name}")
            print(f"    • Carpeta: {resultado['ruta_outputs']}")
            print("═" * 70 + "\n")
        
        except Exception as e:
            print(f"  ❌ Error en pipeline: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
        
        return
    
    # ═════════════════════════════════════════════════════════════════════════
    # MODO 3: Pipeline COMPLETO (Estandares_VIRF.xlsx + ControlesData.xlsx)
    # ═════════════════════════════════════════════════════════════════════════
    if not args.titulo:
        parser.error("--titulo es obligatorio")
    if not args.tier:
        parser.error("--tier es obligatorio (1, 2, 3, 4)")

    if not ESTANDARES_PATH.exists():
        print(f"  ❌ Error: {ESTANDARES_PATH} no encontrado")
        sys.exit(1)

    fecha_informe = datetime.now().strftime("%Y-%m-%d")
    tier_str = str(args.tier)

    print("\n" + "═" * 70)
    print("  🔍 AGENTE VIRF — PIPELINE TODOS LOS ÁMBITOS")
    print(f"  Modelo: {args.titulo}")
    print(f"  Tier:   {tier_str}")
    print(f"  Modo:   {'PRODUCCIÓN (--prdc)' if args.prdc else 'PRE-PRODUCCIÓN'}")
    print("═" * 70 + "\n")

    try:
        # 1. Cargar estándares VIRF (todos los ámbitos filtrados por tier)
        print("  📖 Cargando Estandares_VIRF.xlsx...")
        ambitos_data = leer_estandares_virf(tier_str)
        if not ambitos_data:
            print("  ❌ No se pudieron cargar los estándares VIRF. Verificar estructura del Excel.")
            sys.exit(1)

        # 2. Cargar todos los documentos de evidencia
        print("  📂 Cargando documentos de evidencia...")
        todos_inputs = cargar_todos_inputs()

        # 3. Preparar directorio de salida
        outputs_dir = OUTPUTS_DIR / fecha_informe
        outputs_dir.mkdir(parents=True, exist_ok=True)

        # 4. Evaluar cada ámbito
        resultados_ambitos = {}
        scores_ambitos = {}
        total_actividades = 0

        for ambito, actividades in ambitos_data.items():
            acts_requeridas = [a for a in actividades if a.get("requerida", True)]
            if not acts_requeridas:
                continue

            print(f"\n🔍 Evaluando {ambito} ({len(acts_requeridas)} actividades)...")
            total_actividades += len(acts_requeridas)

            docs_ambito = inputs_para_dimension(todos_inputs, ambito)
            contexto = "\n".join(
                f"[{d['nombre']}]\n{d['contenido']}"
                for d in docs_ambito[:5]
            )

            evals = evaluar_ambito_completo(
                ambito=ambito,
                actividades=acts_requeridas,
                contexto=contexto,
                titulo_modelo=args.titulo,
                modo_preprdc=not args.prdc,
            )

            resultados_ambitos[ambito] = evals
            scores_ambitos[ambito] = calcular_score_ambito(evals)

        # 5. ADICIONAL: controles de Calidad de Datos desde ControlesData.xlsx
        resultados_cdd = {}
        if CONTROLES_DATA_PATH.exists():
            print("\n🔍 Evaluando controles adicionales de CALIDAD DE DATOS (ControlesData.xlsx)...")
            resultados_cdd = evaluar_todos_controles(
                excel_controles=str(CONTROLES_DATA_PATH),
                base_project_path=str(OUTPUTS_DIR.parent),
                nombre_modelo=args.titulo,
                tier=tier_str,
            )
        else:
            print(f"  ℹ️  ControlesData.xlsx no encontrado en {CONTROLES_DATA_PATH}, omitiendo.")

        # 5b. Fusionar controles CDD con ámbito "Calidad de datos" (para Word conjunto)
        if resultados_cdd and resultados_cdd.get("resultados_por_control"):
            evals_cdd = []
            for ctrl_id, res in resultados_cdd["resultados_por_control"].items():
                estado         = res.get("estado", "ERROR")
                revision       = res.get("revision", "")
                hallazgos      = res.get("hallazgos") or []
                prompt_control = res.get("prompt_control", "")

                puntaje = 4 if estado == "OK" else (3 if estado in ("ADVERTENCIA", "ALERTA") else 1)

                obs_parts = []
                for h in hallazgos[:5]:
                    obs_parts.append(h.get("descripcion", str(h)) if isinstance(h, dict) else str(h))
                observacion = " | ".join(obs_parts) if obs_parts else (
                    revision if revision and not revision.lower().startswith("error") else ""
                )
                concepto = (
                    revision if revision and not revision.lower().startswith("error")
                    else f"Control automático de calidad de datos: {ctrl_id}"
                )

                # Nombre de actividad: ID + resumen del prompt (primeras 120 chars)
                resumen_prompt = prompt_control[:120].strip()
                if len(prompt_control) > 120:
                    resumen_prompt += "..."
                actividad_label = f"{ctrl_id} — {resumen_prompt}" if resumen_prompt else ctrl_id

                evals_cdd.append({
                    "puntaje":              puntaje,
                    "concepto":             concepto,
                    "observacion":          observacion,
                    "evidencia_encontrada": "",
                    "preguntas_pendientes": [],
                    "recomendacion":        "",
                    "actividad":            actividad_label,
                    "control":              "Controles Automáticos de Calidad de Datos",
                })

            ambito_cdd = "Calidad de datos"
            if ambito_cdd not in resultados_ambitos:
                resultados_ambitos[ambito_cdd] = []
            resultados_ambitos[ambito_cdd].extend(evals_cdd)
            scores_ambitos[ambito_cdd] = calcular_score_ambito(resultados_ambitos[ambito_cdd])
            print(f"  ✓ {len(evals_cdd)} controles CDD fusionados en ámbito '{ambito_cdd}'")

        # 6. Score global y semáforo
        score_global = calcular_score_global(scores_ambitos)
        semaforo = get_semaforo(score_global)

        # 7. Guardar JSON con todos los resultados
        import json
        ruta_json = outputs_dir / f"resultados_{args.titulo}_{fecha_informe}.json"
        with open(ruta_json, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "modelo":                   args.titulo,
                    "tier":                     tier_str,
                    "fecha":                    fecha_informe,
                    "score_global":             score_global,
                    "semaforo":                 semaforo,
                    "scores_por_ambito":        scores_ambitos,
                    "resultados_por_ambito":    resultados_ambitos,
                    "controles_calidad_datos":  resultados_cdd,
                },
                f, ensure_ascii=False, indent=2, default=str,
            )

        # 8. Generar informe Word (solo en modo --prdc)
        ruta_word = None
        if args.prdc:
            print("\n📝 Generando resumen ejecutivo...")
            resumen = generar_resumen_ejecutivo(
                evaluaciones_por_ambito=resultados_ambitos,
                scores_por_ambito=scores_ambitos,
                score_global=score_global,
                titulo_modelo=args.titulo,
                tier=tier_str,
            )
            print("📝 Generando informe Word...")
            ruta_word = generar_word_informe(
                resumen_ejecutivo=resumen,
                evaluaciones_por_ambito=resultados_ambitos,
                scores_por_ambito=scores_ambitos,
                score_global=score_global,
                titulo_modelo=args.titulo,
                tier=tier_str,
                outputs_dir=outputs_dir,
            )

        # 9. Resumen final
        print("\n" + "═" * 70)
        print("  ✅ PIPELINE VIRF COMPLETADO")
        print("═" * 70)
        print(f"\n  📊 RESULTADOS:")
        print(f"    • Ámbitos evaluados:   {len(resultados_ambitos)}")
        print(f"    • Actividades totales: {total_actividades}")
        print(f"    • Score global:        {score_global:.2f}/5.0  [{semaforo.get('label', '')}]")
        for amb, sc in scores_ambitos.items():
            print(f"      - {amb:<35} {sc:.2f}")
        if resultados_cdd:
            cdd_ok    = resultados_cdd.get("controles_ok", 0)
            cdd_total = resultados_cdd.get("total_controles", 0)
            cdd_crit  = resultados_cdd.get("hallazgos_criticos", 0)
            print(f"    • Controles CDD:       {cdd_ok}/{cdd_total}  (hallazgos críticos: {cdd_crit})")
        print(f"\n  📁 ARCHIVOS GENERADOS:")
        print(f"    • JSON:    {ruta_json.name}")
        if ruta_word:
            print(f"    • Word:    {Path(ruta_word).name}")
        print(f"    • Carpeta: {outputs_dir}")
        print("═" * 70 + "\n")

    except Exception as e:
        print(f"  ❌ Error en pipeline: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
