"""
agent/evaluators/methodology_checker.py
=========================================
Verifica si una metodología tiene sustento científico y regulatorio
adecuado. Opera como capa estática (sin LLM) antes del análisis
conversacional.

Detecta:
- Ausencia de backtesting documentado
- Ventanas temporales sin justificación
- Parámetros sin calibración
- Inconsistencias con normas regulatorias (SR 11-7, EBA, BCBS)
- Modelos sin documentación de limitaciones
"""

from __future__ import annotations
import re
from typing import List, Dict


# ── Señales de buena práctica (su ausencia es un hallazgo) ───────────────────

INDICADORES_POSITIVOS = {
    "backtesting":       r"backtesting|back.testing|kupiec|christoffersen|excepci[oó]n",
    "calibracion":       r"calibra|calibr[aá]|optimiz|mínimo.*error|rmse|mae",
    "ventana_justif":    r"ventana.*justif|per[íi]odo.*calibr|período.*observaci|lookback.*justif",
    "test_normalidad":   r"jarque.bera|shapiro|kolmogorov|anderson|test.*normalidad",
    "intervalo_confianza": r"intervalo.*confianza|confidence.*interval|ic\s*\d|ci\s*\d",
    "stress_testing":    r"stress|estr[eé]s|escenario.*adverso|shock",
    "documentacion_limite": r"limitaci[oó]n|supuesto|asunci[oó]n|caveats?",
}

# ── Señales que REQUIEREN verificación adicional ──────────────────────────────

PATRONES_RIESGO_METODOLOGICO = [
    (
        r"(?:ventana|window|lookback)\s*(?:de\s*)?\d+(?:\s*d[íi]as?|\s*days?)?(?!.*justif)",
        "MEDIO",
        "Ventana temporal definida numéricamente sin justificación explícita. "
        "La elección de la ventana afecta significativamente los resultados.",
        "Documentar criterio de selección (ej: mínimo 250 días según Basilea, "
        "o análisis de sensibilidad sobre distintas ventanas).",
        "BCBS (2019) FRTB §183; SR 11-7 Sección IV.",
    ),
    (
        r"por\s+experiencia|experto|expert|juicio",
        "ALTO",
        "Parámetro o supuesto basado en 'juicio de experto' sin respaldo cuantitativo. "
        "SR 11-7 exige que los modelos sean reproducibles y verificables.",
        "Reemplazar juicio de experto con calibración estadística documentada "
        "o citar explícitamente el fundamento regulatorio que permite el uso de juicio.",
        "SR 11-7 Sección II; EBA/GL/2023/01 §45.",
    ),
    (
        r"no\s+(?:se\s+)?realiz[oó]\s+backtesting|sin\s+backtesting|backtesting\s+no\s+aplica",
        "CRÍTICO",
        "Backtesting no realizado o declarado como no aplicable. "
        "La validación del poder predictivo del modelo es obligatoria.",
        "Implementar backtesting según Kupiec (1995) para cobertura incondicional "
        "y Christoffersen (1998) para independencia de excepciones.",
        "SR 11-7 Sección V; EBA/GL/2023/01 §67.",
    ),
    (
        r"r[²2]\s*(?:=|:)\s*0\.[0-4][0-9]",
        "ALTO",
        "R² bajo (<0.50) detectado. El modelo explica menos del 50% de la varianza, "
        "lo que puede indicar especificación incorrecta o variables omitidas.",
        "Revisar especificación del modelo, añadir variables explicativas relevantes "
        "o considerar modelos no lineales. Documentar limitaciones.",
        "SR 11-7 Sección III; literatura estándar de econometría.",
    ),
    (
        r"datos?\s+(?:hist[oó]ricos?)?\s*(?:<|menos\s+de|inferior\s+a)\s*(?:1|2|3)\s*a[ñn]o",
        "ALTO",
        "Período de datos insuficiente (menos de 3 años). "
        "Los modelos de riesgo requieren al menos un ciclo económico completo.",
        "Ampliar la muestra a mínimo 5 años o incluir datos sintéticos calibrados. "
        "Documentar el impacto del período corto en las estimaciones.",
        "BCBS (2019) FRTB §179; SR 11-7 Sección IV.",
    ),
    (
        r"normal(?:idad)?\s+asumida?|se\s+asume?\s+normalidad|distribuci[oó]n\s+normal\s+(?:de|del|para)",
        "MEDIO",
        "Normalidad asumida sin verificación estadística. "
        "Los retornos financieros típicamente exhiben curtosis excesiva y asimetría.",
        "Ejecutar tests de normalidad (Jarque-Bera, Shapiro-Wilk). "
        "Si se rechaza normalidad, usar distribución t-Student o métodos no paramétricos.",
        "Christoffersen (1998); McNeil et al. (2005) cap. 2.",
    ),
    (
        r"no\s+se\s+document|sin\s+documentaci[oó]n|no\s+documentado",
        "ALTO",
        "Metodología no documentada o documentación insuficiente.",
        "Documentar: supuestos, limitaciones, ámbito de aplicación, "
        "período de validez y plan de seguimiento periódico.",
        "SR 11-7 Sección II; EBA/GL/2023/01 §30.",
    ),
]


class MethodologyChecker:
    """
    Verificador estático de solidez metodológica.
    Sin LLM — opera por análisis de texto con reglas.
    """

    def verificar(self, texto: str) -> Dict:
        """
        Verifica la solidez metodológica de un texto.

        Returns:
            {
                "hallazgos": [...],
                "indicadores_presentes": [...],
                "indicadores_ausentes": [...],
                "score_metodologico": float (0-1),
            }
        """
        texto_lower = texto.lower()
        hallazgos   = []

        # ── Detectar patrones de riesgo ───────────────────────────────────────
        for pattern, gravedad, desc, correccion, ref in PATRONES_RIESGO_METODOLOGICO:
            if re.search(pattern, texto_lower, re.IGNORECASE):
                hallazgos.append({
                    "tipo":        "metodologia",
                    "gravedad":    gravedad,
                    "descripcion": desc,
                    "correccion":  correccion,
                    "referencia":  ref,
                    "fuente":      "methodology_checker",
                })

        # ── Verificar presencia de buenas prácticas ───────────────────────────
        presentes = []
        ausentes  = []
        for indicador, pattern in INDICADORES_POSITIVOS.items():
            if re.search(pattern, texto_lower, re.IGNORECASE):
                presentes.append(indicador)
            else:
                ausentes.append(indicador)

        # Score metodológico: % de indicadores positivos presentes
        score = len(presentes) / max(len(INDICADORES_POSITIVOS), 1)

        # Si score es muy bajo, añadir hallazgo general
        if score < 0.3 and len(texto) > 200:
            hallazgos.append({
                "tipo":        "metodologia",
                "gravedad":    "ALTO",
                "descripcion": (
                    f"Documentación metodológica insuficiente: solo {len(presentes)}/{len(INDICADORES_POSITIVOS)} "
                    f"indicadores de buenas prácticas presentes. "
                    f"Ausentes: {', '.join(ausentes[:4])}."
                ),
                "correccion":  "Completar la documentación con backtesting, calibración, "
                               "tests estadísticos e intervalos de confianza.",
                "referencia":  "SR 11-7 Sección II; EBA/GL/2023/01.",
                "fuente":      "methodology_checker",
            })

        return {
            "hallazgos":              hallazgos,
            "indicadores_presentes":  presentes,
            "indicadores_ausentes":   ausentes,
            "score_metodologico":     round(score, 2),
        }
