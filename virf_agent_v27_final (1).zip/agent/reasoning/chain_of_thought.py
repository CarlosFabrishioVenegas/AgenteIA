"""agent/reasoning/chain_of_thought.py — Descomposición de queries complejas."""
import re
from typing import List

_CONECTORES = [
    r"\by\s+además\b", r"\bluego\b", r"\bdespués\b", r"\btambién\b",
    r"\bcomparando\b", r"\bque\s+tenga[ns]?\b", r"\bademás\b",
    r"\bpor\s+otro\s+lado\b", r"\bsimultáneamente\b",
]


class ChainOfThought:
    def is_complex_query(self, texto: str) -> bool:
        t = texto.lower()
        return any(re.search(p, t) for p in _CONECTORES) or len(texto.split()) > 40

    def decompose(self, texto: str) -> List[str]:
        pasos = re.split("|".join(_CONECTORES), texto, flags=re.IGNORECASE)
        pasos = [p.strip() for p in pasos if p.strip() and len(p.strip()) > 10]
        return pasos[:4] or [f"Analizar: {texto}"]

    def format_steps(self, texto: str) -> str:
        pasos = self.decompose(texto)
        if len(pasos) <= 1:
            return ""
        return "\n".join(f"Paso {i+1}: {p}" for i, p in enumerate(pasos))
