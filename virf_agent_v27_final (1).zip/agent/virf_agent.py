"""
====================================================================
agent/virf_agent.py  —  VIRF Agent v27
====================================================================

OBJETIVO:
    Agente conversacional de validación de modelos financieros.
    Detecta fórmulas mal desarrolladas, falta de sustento científico
    y genera un informe de validación consolidado con /validar.

QUÉ PUEDE HACER:
    - Conversar sobre cualquier aspecto de un modelo financiero
      (LaR, VaR, conductuales) en lenguaje natural.
    - Detectar fórmulas incorrectas o sin sustento científico
      en scripts Python, fórmulas Excel o texto metodológico.
    - Acumular hallazgos durante la conversación.
    - Con /validar → sintetiza TODOS los hallazgos en un informe
      estructurado listo para Word.

COMANDOS ESPECIALES:
    /validar    → genera informe consolidado con todos los hallazgos
    /hallazgos  → muestra hallazgos acumulados hasta el momento
    /cargar     → recarga documentos del modelo desde inputs/
    /limpiar    → reinicia la conversación (mantiene hallazgos)
    /reset      → reinicia TODO incluyendo hallazgos
    /dominio    → muestra/cambia el dominio RAG activo
    /feedback   → estadísticas de feedback acumulado
    /salir      → sale del agente

FLUJO:
    usuario → input() → _clasificar_consulta()
      [formula]   → FormulaDetectorSkill → hallazgo registrado
      [metodologia] → MethodologySkill → hallazgo registrado
      [rag]       → RAG domain retriever → contexto → LLM
      [datos]     → análisis de scripts/Excel → LLM
      [general]   → conversación directa → LLM
    → ShortTermMemory.store()
    → /validar → ConsolidadorSkill → informe Word

ANTI-ALUCINACIÓN:
    Todos los hallazgos de fórmulas se verifican contra la base
    matemática del dominio (referencias de BaseValidator).
    El agente cita la fuente de cada cuestionamiento.

====================================================================
"""

import os
import re
import sys
import json
import datetime
from pathlib import Path
from collections import deque
from typing import Dict, List, Optional, Any

# ── Resolver rutas ────────────────────────────────────────────────────────────
_AGENT_DIR = Path(__file__).parent.resolve()
_ROOT_DIR  = _AGENT_DIR.parent.resolve()

for _p in [str(_ROOT_DIR), str(_ROOT_DIR / "motor")]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from dotenv import load_dotenv
    load_dotenv(_ROOT_DIR / ".env")
except ImportError:
    pass

import anthropic

# ── Módulos internos ──────────────────────────────────────────────────────────
from agent.memory.short_term_memory import ShortTermMemory
from agent.memory.long_term_memory import LongTermMemory
from agent.reasoning.chain_of_thought import ChainOfThought
from agent.evaluators.formula_detector import FormulaDetector
from agent.evaluators.methodology_checker import MethodologyChecker
from agent.feedback.feedback_store import FeedbackStore
from agent.skills.formula_detection_skill import FormulaDetectionSkill
from agent.skills.methodology_skill import MethodologySkill
from agent.skills.consolidator_skill import ConsolidatorSkill

# ── RAG (opcional — degradación elegante) ─────────────────────────────────────
try:
    from src.rag import get_retriever as _rag_get_retriever, inferir_dominio as _rag_inferir_dominio
    _RAG_DISPONIBLE = True
except ImportError:
    _RAG_DISPONIBLE = False
    def _rag_get_retriever(*a, **kw): return None
    def _rag_inferir_dominio(*a, **kw): return "shared"

# ── Motor IA base ─────────────────────────────────────────────────────────────
try:
    from Mx_00_CargaRutas import ROL_AGENTE, RUTAS, AMBITO_A_INPUTS
except ImportError:
    ROL_AGENTE = "Eres un validador senior de modelos de riesgo financiero."
    RUTAS = {}
    AMBITO_A_INPUTS = {}


# ══════════════════════════════════════════════════════════════════════════════
# SISTEMA PROMPT — ROL Y CONOCIMIENTO BASE
# ══════════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT_BASE = """Eres un Validador Senior de Modelos de Riesgo Financiero con especialización en:
- LaR (Liquidity at Risk): modelos de estrés de liquidez, HQLA, LCR, NSFR
- VaR (Value at Risk): VaR histórico, paramétrico, Monte Carlo, FRTB
- Modelos Conductuales: prepago, retiro de depósitos, NMD, comportamiento

Tu función es detectar:
1. FÓRMULAS INCORRECTAS: errores matemáticos, supuestos inválidos, errores de signo, 
   distribuciones mal aplicadas (ej: usar Normal cuando se necesita t-Student).
2. FALTA DE SUSTENTO CIENTÍFICO: metodologías sin referencia académica o regulatoria,
   backtesting ausente, validación estadística insuficiente.
3. INCONSISTENCIAS METODOLÓGICAS: parámetros no calibrados, ventanas temporales arbitrarias,
   ausencia de pruebas de robustez.

REFERENCIAS REGULATORIAS QUE CONOCES:
- SR 11-7 (Fed 2011): model risk management
- EBA/GL/2023/01: internal models validation
- BCBS 239: risk data aggregation
- Basilea III/IV: FRTB, LCR, NSFR
- SBS Res. 9075-2012: gestión de riesgo de liquidez (Perú)
- Nelson-Siegel-Svensson para curvas de rendimiento
- Kupiec (1995), Christoffersen (1998): backtesting de VaR
- BIS FRTB (2019): capital por riesgo de mercado

REGLAS CRÍTICAS:
- Cuando detectes un error en una fórmula, CITA la referencia correcta.
- Si no tienes certeza de que algo es incorrecto, di "requiere verificación".
- Nunca inventes fórmulas ni referencias académicas.
- Registra CADA hallazgo con: tipo, gravedad (CRÍTICO/ALTO/MEDIO/BAJO), descripción, corrección sugerida.
- Responde siempre en español técnico.
- Sé directo: muestra el error específico, no generalidades."""


def _build_system_prompt(feedback_store: FeedbackStore, titulo_modelo: str,
                         dominio: str, hallazgos_count: int) -> str:
    """Construye el system prompt dinámico con contexto de sesión."""
    lessons = feedback_store.get_lessons_block()
    lessons_section = f"\nAPRENDIZAJE DE SESIONES ANTERIORES:\n{lessons}\n" if lessons else ""

    hallazgos_ctx = (
        f"\nSESIÓN ACTUAL: {hallazgos_count} hallazgo(s) registrado(s) hasta el momento. "
        f"Continúa acumulando evidencia para el informe /validar.\n"
        if hallazgos_count > 0 else ""
    )

    return f"""{SYSTEM_PROMPT_BASE}

MODELO BAJO VALIDACIÓN: {titulo_modelo or "(no especificado — preguntar al usuario)"}
DOMINIO ACTIVO: {dominio}
{hallazgos_ctx}{lessons_section}
COMANDOS DISPONIBLES: /validar /hallazgos /cargar /limpiar /reset /dominio /feedback /salir"""


# ══════════════════════════════════════════════════════════════════════════════
# CLASIFICADOR DE CONSULTAS
# ══════════════════════════════════════════════════════════════════════════════

FORMULA_KEYWORDS = [
    "fórmula", "formula", "ecuación", "ecuacion", "cálculo", "calculo",
    "= ", "σ", "μ", "var(", "std(", "sqrt(", "exp(", "ln(",
    "integral", "sumatoria", "percentil", "cuantil", "quantile",
    "distribución", "distribucion", "normal", "t-student", "garch",
    "ewma", "bootstrap", "monte carlo", "cornish-fisher",
    "error", "mal calculado", "incorrecto", "revisa esta", "verifica",
    "¿está bien", "¿es correcto", "¿tiene sentido",
]

METODOLOGIA_KEYWORDS = [
    "metodología", "metodologia", "método", "metodo", "modelo",
    "supuesto", "hipótesis", "hipotesis", "validación", "validacion",
    "backtesting", "kupiec", "christoffersen", "calibración", "calibracion",
    "ventana", "horizonte temporal", "período", "periodo",
    "sustento", "referencia", "paper", "artículo", "sr 11-7", "eba", "bcbs",
    "regulatorio", "normativo", "cumplimiento", "justificación",
]

RAG_KEYWORDS = [
    "según el paper", "según la norma", "referencia", "literatura",
    "estado del arte", "best practice", "buenas prácticas",
    "qué dice", "marco teórico", "estudio",
]

CODIGO_KEYWORDS = [
    "código", "codigo", "script", "python", "función", "funcion",
    "def ", "import ", "pandas", "numpy", "scipy",
    ".py", "línea", "linea",
]


def _clasificar_consulta(texto: str) -> str:
    """
    Clasifica la consulta del usuario en una de 5 categorías:
    formula | metodologia | rag | codigo | general
    """
    t = texto.lower()

    # Fórmulas matemáticas → detección específica
    formula_score = sum(1 for k in FORMULA_KEYWORDS if k in t)
    metodo_score  = sum(1 for k in METODOLOGIA_KEYWORDS if k in t)
    rag_score     = sum(1 for k in RAG_KEYWORDS if k in t)
    codigo_score  = sum(1 for k in CODIGO_KEYWORDS if k in t)

    scores = {
        "formula":     formula_score,
        "metodologia": metodo_score,
        "rag":         rag_score,
        "codigo":      codigo_score,
    }
    top = max(scores, key=scores.get)
    if scores[top] == 0:
        return "general"
    return top


# ══════════════════════════════════════════════════════════════════════════════
# AGENTE VIRF — CLASE PRINCIPAL
# ══════════════════════════════════════════════════════════════════════════════

class VIRFAgent:
    """
    Agente conversacional de validación de modelos financieros.

    Uso:
        agente = VIRFAgent(titulo_modelo="Modelo LaR v3", dominio="LaR")
        agente.run()  # inicia el loop conversacional

    O desde código:
        respuesta = agente.chat("¿Esta fórmula de VaR es correcta?")
        hallazgos = agente.obtener_hallazgos()
        informe   = agente.validar()  # genera informe consolidado
    """

    def __init__(self, titulo_modelo: str = "", dominio: str = "auto"):
        api_key = os.getenv("ANTHROPIC_API_KEY", "")
        if not api_key or "placeholder" in api_key.lower():
            raise ValueError(
                "❌ ANTHROPIC_API_KEY no configurada.\n"
                "   Edita .env y añade: ANTHROPIC_API_KEY=sk-ant-api03-..."
            )

        self.client = anthropic.Anthropic(api_key=api_key)
        self.modelo_claude = os.getenv("ANTHROPIC_MODELO", "claude-sonnet-4-6")
        self.max_tokens    = int(os.getenv("ANTHROPIC_MAX_TOKENS", "4096"))

        # Estado de sesión
        self.titulo_modelo = titulo_modelo
        self.dominio = (
            _rag_inferir_dominio(titulo_modelo) if dominio == "auto" and titulo_modelo
            else (dominio if dominio != "auto" else "shared")
        )
        self.historial: List[Dict] = []
        self.hallazgos: List[Dict] = []       # hallazgos acumulados en sesión
        self.documentos_cargados: List[Dict] = []

        # Módulos
        self.memoria_corta    = ShortTermMemory(max_items=50)
        self.memoria_larga    = LongTermMemory()
        self.chain_of_thought = ChainOfThought()
        self.formula_detector = FormulaDetector()
        self.metodo_checker   = MethodologyChecker()
        self.feedback_store   = FeedbackStore()

        # Skills
        self.formula_skill    = FormulaDetectionSkill(self.client, self.modelo_claude)
        self.metodo_skill     = MethodologySkill(self.client, self.modelo_claude)
        self.consolidador     = ConsolidatorSkill(self.client, self.modelo_claude)

        # RAG retriever (lazy)
        self._rag_retriever = None

        # System prompt dinámico
        self._actualizar_system_prompt()

    def _actualizar_system_prompt(self):
        """Reconstruye el system prompt con el estado actual de la sesión."""
        self.system_prompt = _build_system_prompt(
            feedback_store  = self.feedback_store,
            titulo_modelo   = self.titulo_modelo,
            dominio         = self.dominio,
            hallazgos_count = len(self.hallazgos),
        )

    def _get_rag_retriever(self):
        """Inicializa el retriever RAG lazy."""
        if self._rag_retriever is None and _RAG_DISPONIBLE:
            try:
                self._rag_retriever = _rag_get_retriever(tipo_modelo=self.dominio)
            except Exception as e:
                print(f"  ⚠️  RAG no disponible: {e}")
        return self._rag_retriever

    def _enriquecer_con_rag(self, texto: str, top_k: int = 3) -> str:
        """Recupera contexto RAG del dominio activo."""
        retriever = self._get_rag_retriever()
        if retriever is None:
            return ""
        try:
            return retriever.query_para_prompt(texto, top_k=top_k, min_score=0.35)
        except Exception:
            return ""

    def _cargar_documentos(self) -> str:
        """Carga los documentos disponibles en inputs/ para el modelo activo."""
        try:
            sys.path.insert(0, str(_ROOT_DIR / "motor"))
            from Mx_01_LecturaEvidencias import cargar_todos_inputs, inputs_para_dimension
            todos = cargar_todos_inputs()
            docs = []
            for dim in ["Metodología", "Documentación", "Calidad de datos"]:
                docs.extend(inputs_para_dimension(todos, dim))
            self.documentos_cargados = docs
            return f"✅ {len(docs)} documento(s) cargado(s) desde inputs/"
        except Exception as e:
            return f"⚠️  No se pudieron cargar documentos: {e}"

    def _registrar_hallazgo(self, hallazgo: Dict):
        """Registra un hallazgo en la sesión."""
        hallazgo["timestamp"] = datetime.datetime.now().isoformat()
        hallazgo["sesion_id"] = id(self)
        self.hallazgos.append(hallazgo)
        self.memoria_corta.store(
            key      = f"hallazgo_{len(self.hallazgos)}",
            value    = hallazgo,
            category = "hallazgo",
        )
        self._actualizar_system_prompt()

    def chat(self, user_input: str) -> str:
        """
        Procesa un mensaje del usuario y retorna la respuesta.
        Registra automáticamente hallazgos detectados.

        Args:
            user_input: mensaje del usuario

        Returns:
            Respuesta del agente como string
        """
        tipo = _clasificar_consulta(user_input)
        prompt_usuario = user_input
        hallazgos_nuevos = []

        # ── Contexto de documentos cargados ──────────────────────────────────
        ctx_docs = ""
        if self.documentos_cargados:
            ctx_docs = "\n\n[DOCUMENTOS DEL MODELO CARGADOS]\n" + "\n".join(
                f"[{d['nombre']}]\n{d.get('contenido','')[:2000]}"
                for d in self.documentos_cargados[:3]
            )

        # ── FÓRMULAS: análisis específico con detector ────────────────────────
        if tipo == "formula":
            detected = self.formula_detector.analizar(user_input)
            if detected:
                hallazgos_nuevos.extend(detected)

            skill_result = self.formula_skill.ejecutar(
                texto          = user_input,
                dominio        = self.dominio,
                docs_contexto  = ctx_docs,
            )
            if skill_result.get("hallazgos"):
                hallazgos_nuevos.extend(skill_result["hallazgos"])

            prompt_usuario = (
                f"CONSULTA SOBRE FÓRMULA:\n{user_input}\n"
                f"{ctx_docs}\n\n"
                f"Analiza si la fórmula o cálculo presentado es matemáticamente correcto. "
                f"Identifica: (1) errores matemáticos, (2) supuestos incorrectos, "
                f"(3) distribuciones mal aplicadas, (4) falta de sustento científico. "
                f"Cita la referencia correcta para cada error encontrado. "
                f"Si no hay errores, confirma la validez y explica por qué."
            )

        # ── METODOLOGÍA: verificar sustento científico ────────────────────────
        elif tipo == "metodologia":
            skill_result = self.metodo_skill.ejecutar(
                texto          = user_input,
                dominio        = self.dominio,
                docs_contexto  = ctx_docs,
            )
            if skill_result.get("hallazgos"):
                hallazgos_nuevos.extend(skill_result["hallazgos"])

            # Enriquecer con RAG del dominio
            rag_ctx = self._enriquecer_con_rag(user_input)

            prompt_usuario = (
                f"CONSULTA METODOLÓGICA:\n{user_input}\n"
                f"{ctx_docs}\n"
                f"{rag_ctx}\n\n"
                f"Evalúa: (1) ¿tiene sustento en literatura académica o regulatoria? "
                f"(2) ¿los supuestos están justificados? "
                f"(3) ¿el backtesting es adecuado? "
                f"(4) ¿hay inconsistencias con estándares (SR 11-7, EBA, BCBS)? "
                f"Sé específico y cita referencias."
            )

        # ── RAG: recuperar de base de conocimiento ────────────────────────────
        elif tipo == "rag":
            rag_ctx = self._enriquecer_con_rag(user_input, top_k=5)
            if rag_ctx:
                prompt_usuario = (
                    f"CONSULTA SOBRE LITERATURA/NORMAS:\n{user_input}\n\n"
                    f"{rag_ctx}\n\n"
                    f"Responde basándote en el contexto recuperado. "
                    f"Si aplica al modelo bajo validación, señala implicaciones concretas."
                )
            else:
                prompt_usuario = (
                    f"{user_input}\n\n"
                    f"[RAG no disponible o sin resultados — responde desde conocimiento base]"
                )

        # ── CÓDIGO: análisis de scripts ───────────────────────────────────────
        elif tipo == "codigo":
            detected = self.formula_detector.analizar_codigo(user_input)
            if detected:
                hallazgos_nuevos.extend(detected)

            prompt_usuario = (
                f"ANÁLISIS DE CÓDIGO:\n{user_input}\n\n"
                f"Revisa el código línea por línea buscando: "
                f"(1) errores en implementación de fórmulas financieras, "
                f"(2) uso incorrecto de distribuciones estadísticas, "
                f"(3) ventanas temporales o parámetros sin justificación, "
                f"(4) ausencia de controles de calidad de datos. "
                f"Cita el estándar o paper que justifica cada observación."
            )

        # ── Razonamiento en cadena para queries complejas ─────────────────────
        if self.chain_of_thought.is_complex_query(user_input):
            pasos = self.chain_of_thought.format_steps(user_input)
            if pasos:
                prompt_usuario += f"\n\nRAZONAMIENTO REQUERIDO (paso a paso):\n{pasos}"

        # ── Memoria de contexto reciente ──────────────────────────────────────
        items_recientes = self.memoria_corta.get_recent(n=3)
        if items_recientes and tipo != "general":
            ctx_memoria = "\n".join(
                f"[{it['category']}] {str(it['value'])[:150]}"
                for it in items_recientes
                if it["category"] in ("hallazgo", "formula_result")
            )
            if ctx_memoria:
                prompt_usuario += f"\n\nCONTEXTO DE HALLAZGOS PREVIOS EN ESTA SESIÓN:\n{ctx_memoria}"

        # ── Llamada al LLM con streaming ──────────────────────────────────────
        self.historial.append({"role": "user", "content": prompt_usuario})

        respuesta_completa = ""
        print("\n🔍 ", end="", flush=True)
        try:
            with self.client.messages.stream(
                model      = self.modelo_claude,
                max_tokens = self.max_tokens,
                system     = self.system_prompt,
                messages   = self.historial,
            ) as stream:
                for text in stream.text_stream:
                    print(text, end="", flush=True)
                    respuesta_completa += text
        except anthropic.APIError as e:
            respuesta_completa = f"[Error API: {e}]"
            print(respuesta_completa)
        print()

        self.historial.append({"role": "assistant", "content": respuesta_completa})

        # ── Extraer hallazgos adicionales de la respuesta ─────────────────────
        hallazgos_respuesta = self._extraer_hallazgos_de_respuesta(
            respuesta_completa, tipo
        )
        hallazgos_nuevos.extend(hallazgos_respuesta)

        # ── Registrar todos los hallazgos detectados ──────────────────────────
        for h in hallazgos_nuevos:
            if h.get("descripcion"):
                self._registrar_hallazgo(h)

        # ── Guardar en memoria corta ──────────────────────────────────────────
        self.memoria_corta.store(
            key      = f"resp_{len(self.historial)}",
            value    = respuesta_completa[:500],
            category = "response",
        )

        return respuesta_completa

    def _extraer_hallazgos_de_respuesta(self, respuesta: str, tipo: str) -> List[Dict]:
        """
        Extrae hallazgos estructurados de la respuesta del LLM.
        Busca patrones de severidad: CRÍTICO, ALTO, MEDIO, BAJO.
        """
        hallazgos = []
        severidades = ["CRÍTICO", "ALTO", "MEDIO", "BAJO", "CRITICO"]

        for sev in severidades:
            # Buscar frases que contengan la severidad seguida de descripción
            pattern = rf"{sev}[:\s]+([^\n\.\,]{{20,200}})"
            matches = re.findall(pattern, respuesta, re.IGNORECASE)
            for m in matches:
                desc = m.strip()
                if len(desc) > 20:
                    hallazgos.append({
                        "tipo":       tipo,
                        "gravedad":   sev.upper().replace("CRITICO", "CRÍTICO"),
                        "descripcion": desc,
                        "fuente":     "respuesta_llm",
                        "auto":       True,
                    })

        return hallazgos

    def obtener_hallazgos(self) -> List[Dict]:
        """Retorna todos los hallazgos acumulados en la sesión."""
        return self.hallazgos

    def mostrar_hallazgos(self):
        """Imprime los hallazgos acumulados de forma legible."""
        if not self.hallazgos:
            print("\n  📋 Sin hallazgos registrados aún.")
            print("  Conversa sobre el modelo y los hallazgos se acumularán automáticamente.")
            return

        print(f"\n{'═'*65}")
        print(f"  HALLAZGOS ACUMULADOS — {len(self.hallazgos)} hallazgo(s)")
        print(f"  Modelo: {self.titulo_modelo or '(sin especificar)'}")
        print(f"{'═'*65}")

        por_gravedad = {"CRÍTICO": [], "ALTO": [], "MEDIO": [], "BAJO": []}
        for h in self.hallazgos:
            g = h.get("gravedad", "MEDIO")
            por_gravedad.get(g, por_gravedad["MEDIO"]).append(h)

        iconos = {"CRÍTICO": "🔴", "ALTO": "🟠", "MEDIO": "🟡", "BAJO": "🟢"}
        for grav in ["CRÍTICO", "ALTO", "MEDIO", "BAJO"]:
            grupo = por_gravedad[grav]
            if grupo:
                print(f"\n  {iconos[grav]} {grav} ({len(grupo)})")
                for i, h in enumerate(grupo, 1):
                    desc = h.get("descripcion", "")[:120]
                    tipo = h.get("tipo", "")
                    print(f"    {i}. [{tipo}] {desc}")
        print()

    def validar(self) -> str:
        """
        Genera el informe consolidado con todos los hallazgos de la sesión.
        Equivale al comando /validar.

        Returns:
            Texto del informe ejecutivo (también se guarda como Word si hay outputs/).
        """
        print(f"\n{'═'*65}")
        print(f"  GENERANDO INFORME DE VALIDACIÓN...")
        print(f"  Modelo: {self.titulo_modelo or '(sin especificar)'}")
        print(f"  Hallazgos: {len(self.hallazgos)}")
        print(f"{'═'*65}\n")

        if not self.hallazgos and not self.historial:
            return "⚠️  Sin hallazgos ni conversación registrada. Conversa primero con el agente."

        # Construir contexto completo de la sesión
        resumen_hallazgos = json.dumps(self.hallazgos, ensure_ascii=False, indent=2)
        resumen_conv = "\n".join(
            f"[{m['role'].upper()}] {m['content'][:300]}"
            for m in self.historial[-20:]  # últimas 20 interacciones
        )

        informe = self.consolidador.generar_informe(
            titulo_modelo      = self.titulo_modelo or "Modelo sin nombre",
            dominio            = self.dominio,
            hallazgos          = self.hallazgos,
            resumen_conversacion = resumen_conv,
        )

        # Guardar JSON de hallazgos
        outputs = _ROOT_DIR / "outputs"
        outputs.mkdir(exist_ok=True)
        fecha = datetime.datetime.now().strftime("%Y%m%d_%H%M")
        nombre_seg = (self.titulo_modelo or "modelo").replace(" ", "_")[:30]

        json_path = outputs / f"hallazgos_{nombre_seg}_{fecha}.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump({
                "titulo_modelo": self.titulo_modelo,
                "dominio":       self.dominio,
                "fecha":         fecha,
                "hallazgos":     self.hallazgos,
                "informe":       informe,
            }, f, ensure_ascii=False, indent=2)
        print(f"\n  💾 Hallazgos guardados: {json_path.name}")

        # Intentar generar Word
        try:
            from agent.skills.word_export_skill import exportar_informe_word
            word_path = exportar_informe_word(
                informe       = informe,
                hallazgos     = self.hallazgos,
                titulo_modelo = self.titulo_modelo or "Modelo",
                output_dir    = str(outputs),
                fecha         = fecha,
            )
            print(f"  📄 Informe Word: {word_path}")
        except Exception as e:
            print(f"  ⚠️  Word no generado: {e} (informe disponible en JSON)")

        # Guardar en memoria larga para sesiones futuras
        self.memoria_larga.store(
            key      = f"validacion_{nombre_seg}_{fecha}",
            value    = {"hallazgos": len(self.hallazgos), "informe_preview": informe[:500]},
            category = "validacion",
        )

        return informe

    def solicitar_feedback(self, pregunta: str, respuesta: str):
        """Solicita rating al usuario y actualiza el system prompt."""
        try:
            raw = input("\n  [Feedback] ¿Útil esta respuesta? (1-5 / Enter para omitir): ").strip()
            if not raw:
                return
            rating = int(raw)
            if not 1 <= rating <= 5:
                return
            comentario = input("  [Feedback] Comentario (Enter para omitir): ").strip()
            self.feedback_store.registrar(pregunta, respuesta, rating, comentario)
            self._actualizar_system_prompt()
            print(f"  📝 Feedback registrado (rating={rating})")
        except (ValueError, EOFError, KeyboardInterrupt):
            pass

    # ══════════════════════════════════════════════════════════════════════════
    # LOOP PRINCIPAL DE CONVERSACIÓN
    # ══════════════════════════════════════════════════════════════════════════

    def run(self):
        """Inicia el loop conversacional interactivo."""
        _print_banner(self.titulo_modelo, self.dominio)

        # Auto-cargar documentos si hay algo en inputs/
        msg_carga = self._cargar_documentos()
        if "✅" in msg_carga:
            print(f"  {msg_carga}")

        while True:
            try:
                user_input = input("\nTú > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n👋 Hasta luego.")
                break

            if not user_input:
                continue

            # ── Comandos especiales ───────────────────────────────────────────
            if user_input == "/salir":
                print("👋 Hasta luego.")
                break

            if user_input == "/validar":
                informe = self.validar()
                print(f"\n{'═'*65}")
                print(informe)
                print(f"{'═'*65}\n")
                continue

            if user_input == "/hallazgos":
                self.mostrar_hallazgos()
                continue

            if user_input == "/cargar":
                msg = self._cargar_documentos()
                print(f"  {msg}")
                continue

            if user_input == "/limpiar":
                self.historial.clear()
                self.memoria_corta.clear()
                print("🗑️  Conversación reiniciada. Los hallazgos se conservan.")
                continue

            if user_input == "/reset":
                self.historial.clear()
                self.hallazgos.clear()
                self.memoria_corta.clear()
                self._actualizar_system_prompt()
                print("🗑️  Sesión reiniciada completamente (conversación + hallazgos).")
                continue

            if user_input.startswith("/dominio"):
                partes = user_input.split()
                if len(partes) > 1:
                    nuevo = partes[1]
                    if nuevo in ["LaR", "VaR", "conductuales", "shared"]:
                        self.dominio = nuevo
                        self._rag_retriever = None
                        self._actualizar_system_prompt()
                        print(f"  ✅ Dominio cambiado a: {nuevo}")
                    else:
                        print(f"  Dominios válidos: LaR, VaR, conductuales, shared")
                else:
                    print(f"  Dominio activo: {self.dominio}")
                    print(f"  RAG disponible: {'Sí' if _RAG_DISPONIBLE else 'No'}")
                continue

            if user_input == "/feedback":
                self.feedback_store.mostrar_estadisticas()
                continue

            if user_input.startswith("/titulo"):
                partes = user_input.split(maxsplit=1)
                if len(partes) > 1:
                    self.titulo_modelo = partes[1].strip()
                    self.dominio = _rag_inferir_dominio(self.titulo_modelo)
                    self._rag_retriever = None
                    self._actualizar_system_prompt()
                    print(f"  ✅ Modelo: {self.titulo_modelo} | Dominio: {self.dominio}")
                else:
                    print(f"  Uso: /titulo Nombre del Modelo LaR v3")
                continue

            # ── Conversación normal ───────────────────────────────────────────
            respuesta = self.chat(user_input)

            # Mostrar resumen de hallazgos si se detectaron nuevos
            n_antes = len(self.hallazgos)
            if len(self.hallazgos) > n_antes:
                print(f"\n  📌 {len(self.hallazgos) - n_antes} nuevo(s) hallazgo(s) registrado(s)")
                print(f"     Total acumulado: {len(self.hallazgos)} | Usa /hallazgos para ver")

            self.solicitar_feedback(user_input, respuesta)
            print("\n" + "─" * 66)


# ══════════════════════════════════════════════════════════════════════════════
# BANNER
# ══════════════════════════════════════════════════════════════════════════════

def _print_banner(titulo: str, dominio: str):
    modelo_str = titulo or "(especifica el modelo con /titulo)"
    print(f"""
╔══════════════════════════════════════════════════════════════════╗
║   🏦  VIRF AGENT v27 — Validador de Modelos Financieros          ║
║                                                                  ║
║  Modelo : {modelo_str:<53}║
║  Dominio: {dominio:<53}║
║                                                                  ║
║  Conversa · Detecta fórmulas · /validar genera el informe        ║
║                                                                  ║
║  /validar   /hallazgos   /cargar   /titulo   /dominio            ║
║  /limpiar   /reset       /feedback  /salir                       ║
╚══════════════════════════════════════════════════════════════════╝
""")


# ══════════════════════════════════════════════════════════════════════════════
# ENTRYPOINT
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="VIRF Agent v27 — Validador de Modelos Financieros")
    parser.add_argument("--titulo",  default="", help="Nombre del modelo a validar")
    parser.add_argument("--dominio", default="auto",
                        choices=["auto", "LaR", "VaR", "conductuales", "shared"],
                        help="Dominio financiero del modelo")
    args = parser.parse_args()

    agente = VIRFAgent(titulo_modelo=args.titulo, dominio=args.dominio)
    agente.run()
