"""agent/memory/short_term_memory.py — Memoria de sesión (deque circular)."""
from collections import deque
from typing import Any, Dict, List, Optional
import datetime


class ShortTermMemory:
    def __init__(self, max_items: int = 50):
        self.max_items     = max_items
        self.memory: deque = deque(maxlen=max_items)
        self.session_start = datetime.datetime.now()

    def store(self, key: str, value: Any, category: str = "general"):
        self.memory.append({
            "key": key, "value": value,
            "category": category,
            "timestamp": datetime.datetime.now(),
        })

    def retrieve(self, key: str) -> Any:
        best, best_ts = None, None
        for item in self.memory:
            if item["key"] == key:
                if best_ts is None or item["timestamp"] > best_ts:
                    best, best_ts = item["value"], item["timestamp"]
        return best

    def retrieve_by_category(self, category: str) -> List[Dict]:
        return [i for i in self.memory if i["category"] == category]

    def get_recent(self, n: Optional[int] = None) -> List[Dict]:
        n = n or min(10, self.max_items)
        return list(self.memory)[-n:]

    def clear(self):
        self.memory.clear()

    def get_summary(self) -> Dict:
        cats: Dict[str, int] = {}
        for item in self.memory:
            cats[item["category"]] = cats.get(item["category"], 0) + 1
        return {
            "total_items": len(self.memory),
            "categories":  cats,
            "session_duration": (datetime.datetime.now() - self.session_start).total_seconds(),
        }
