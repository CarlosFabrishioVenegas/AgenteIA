"""agent/memory/long_term_memory.py — Memoria persistente entre sesiones (JSONL)."""
import json
import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

_DEFAULT_PATH = Path("data/cache/long_term_memory.jsonl")
_DEFAULT_TTL  = 90  # días


class LongTermMemory:
    def __init__(self, path: Optional[str] = None, default_ttl_days: int = _DEFAULT_TTL):
        self.path = Path(path) if path else _DEFAULT_PATH
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.default_ttl = default_ttl_days

    def store(self, key: str, value: Any, category: str = "general",
              ttl_days: Optional[int] = None):
        ttl   = ttl_days or self.default_ttl
        expiry = (datetime.datetime.now() + datetime.timedelta(days=ttl)).isoformat()
        entry = {
            "key":        key,
            "value":      value,
            "category":   category,
            "timestamp":  datetime.datetime.now().isoformat(),
            "expiration": expiry,
        }
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def retrieve(self, key: str) -> Any:
        now = datetime.datetime.now()
        best, best_ts = None, None
        try:
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    try:
                        e = json.loads(line.strip())
                        if e["key"] != key:
                            continue
                        if datetime.datetime.fromisoformat(e["expiration"]) < now:
                            continue
                        ts = datetime.datetime.fromisoformat(e["timestamp"])
                        if best_ts is None or ts > best_ts:
                            best, best_ts = e["value"], ts
                    except Exception:
                        continue
        except FileNotFoundError:
            pass
        return best

    def retrieve_by_category(self, category: str) -> List[Dict]:
        now     = datetime.datetime.now()
        results = []
        try:
            with open(self.path, encoding="utf-8") as f:
                for line in f:
                    try:
                        e = json.loads(line.strip())
                        if e.get("category") != category:
                            continue
                        if datetime.datetime.fromisoformat(e["expiration"]) < now:
                            continue
                        results.append(e)
                    except Exception:
                        continue
        except FileNotFoundError:
            pass
        return results
