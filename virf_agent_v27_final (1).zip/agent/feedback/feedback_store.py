"""agent/feedback/feedback_store.py — Registro y análisis de feedback de sesiones."""
import json
import datetime
from pathlib import Path
from typing import List, Dict
from collections import Counter

_DEFAULT_FILE = Path("outputs/virf_feedback.jsonl")


class FeedbackStore:
    def __init__(self, path: str = ""):
        self.path = Path(path) if path else _DEFAULT_FILE
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def registrar(self, pregunta: str, respuesta: str, rating: int, comentario: str = ""):
        entry = {
            "timestamp":         datetime.datetime.now().isoformat(),
            "pregunta":          pregunta,
            "respuesta_preview": respuesta[:300],
            "rating":            rating,
            "comentario":        comentario,
        }
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def cargar(self) -> List[Dict]:
        if not self.path.exists():
            return []
        entries = []
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                try:
                    entries.append(json.loads(line.strip()))
                except Exception:
                    continue
        return entries

    def get_lessons_block(self) -> str:
        entries = self.cargar()
        if not entries:
            return ""
        ratings = [e["rating"] for e in entries]
        avg     = sum(ratings) / len(ratings)
        poor    = [e for e in entries if e["rating"] <= 2 and e.get("comentario", "").strip()]
        good    = [e for e in entries if e["rating"] >= 4 and e.get("comentario", "").strip()]

        lines = [f"FEEDBACK ACUMULADO ({len(entries)} sesiones, promedio {avg:.1f}/5):"]
        if poor:
            lines.append("  Errores recurrentes (evitar):")
            for e in poor[-4:]:
                q = e.get("pregunta", "")[:70]
                c = e.get("comentario", "").strip()
                lines.append(f'    • Pregunta "{q}" → Problema: "{c}"')
        if good:
            lines.append("  Respuestas bien valoradas (mantener estilo):")
            for e in good[-3:]:
                lines.append(f'    • {e.get("comentario","").strip()[:80]}')
        return "\n".join(lines)

    def mostrar_estadisticas(self):
        entries = self.cargar()
        if not entries:
            print("  Sin feedback registrado aún.")
            return
        ratings = [e["rating"] for e in entries]
        print(f"\n  📊 FEEDBACK ACUMULADO — {len(entries)} evaluaciones")
        print(f"     Promedio: {sum(ratings)/len(ratings):.2f}/5")
        print(f"     Distribución: " + " | ".join(f"{r}★:{ratings.count(r)}" for r in range(1, 6)))
        lecciones = self.get_lessons_block()
        if lecciones:
            print(f"\n  📚 LECCIONES:\n  {lecciones}")
