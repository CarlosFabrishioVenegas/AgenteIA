"""
src/rag/base_indexer.py
========================
Clase base para indexadores de todos los dominios RAG.

Responsabilidad: construir y mantener un índice ChromaDB a partir de los
documentos de un dominio financiero (LaR, VaR, conductuales, shared).
Usa sentence-transformers (multilingüe, sin API externa) para generar
los embeddings. Detecta automáticamente si el entorno es Databricks y
persiste los índices en DBFS (/dbfs/FileStore/virf/vectordb/<dominio>/).

Subclases concretas: LaRIndexer, VaRIndexer, ConductualesIndexer, SharedIndexer.
Cada subclase solo define `dominio` y `get_source_paths()`.
Cada dominio (LaR, VaR, conductuales, shared) hereda de aquí.

Tecnología: ChromaDB (local) en Databricks DBFS o FileStore.
Embeddings: sentence-transformers (sin llamadas API externas).

Uso en Databricks:
    # En un notebook de setup (correr 1 vez por entorno):
    from src.rag.LaR.indexer import LaRIndexer
    idx = LaRIndexer()
    idx.build_index()   # Indexa todos los docs en inputs/documentacion/modelamiento/
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Dict, Any

logger = logging.getLogger("virf.rag")

# ── Detectar si estamos en Databricks ────────────────────────────────────────
_EN_DATABRICKS = "DATABRICKS_RUNTIME_VERSION" in os.environ


def _get_vectordb_base() -> Path:
    """
    Retorna la ruta base para los índices vectoriales.
    En Databricks: /dbfs/FileStore/virf/vectordb/
    En local: data/vectordb/ (relativo a la raíz del proyecto)
    """
    if _EN_DATABRICKS:
        return Path("/dbfs/FileStore/virf/vectordb")
    root = Path(__file__).parent.parent.parent.parent  # raíz del proyecto
    return root / "data" / "vectordb"


class BaseIndexer(ABC):
    """
    Indexador base para un dominio RAG.

    Subclases deben implementar:
        - dominio: str (nombre del dominio, ej. "LaR")
        - get_source_paths(): lista de Path con carpetas/archivos a indexar
    """

    dominio: str = "base"

    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 150):
        self.chunk_size    = chunk_size
        self.chunk_overlap = chunk_overlap
        self.vectordb_path = _get_vectordb_base() / self.dominio
        self._collection   = None

    @abstractmethod
    def get_source_paths(self) -> List[Path]:
        """Retorna las carpetas/archivos a indexar para este dominio."""
        ...

    def _get_chroma_client(self):
        """Inicializa ChromaDB apuntando a la ruta correcta (local o DBFS)."""
        try:
            import chromadb
        except ImportError:
            raise ImportError(
                "chromadb no instalado. Ejecutar:\n"
                "  pip install chromadb sentence-transformers\n"
                "En Databricks: %pip install chromadb sentence-transformers"
            )

        self.vectordb_path.mkdir(parents=True, exist_ok=True)
        client = chromadb.PersistentClient(path=str(self.vectordb_path))
        return client

    def _get_embedding_function(self):
        """
        Embeddings locales con sentence-transformers.
        No usa API externa → funciona sin internet en Databricks.
        Modelo: paraphrase-multilingual-MiniLM-L12-v2 (soporta español).
        """
        try:
            from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction
            return SentenceTransformerEmbeddingFunction(
                model_name="paraphrase-multilingual-MiniLM-L12-v2"
            )
        except ImportError:
            raise ImportError(
                "sentence-transformers no instalado.\n"
                "  pip install sentence-transformers"
            )

    def _chunk_text(self, texto: str, nombre: str) -> List[Dict[str, Any]]:
        """Divide el texto en chunks con metadatos."""
        chunks = []
        start = 0
        idx = 0
        while start < len(texto):
            end = start + self.chunk_size
            chunk_text = texto[start:end]
            if chunk_text.strip():
                chunks.append({
                    "text":     chunk_text,
                    "id":       f"{nombre}_{idx}",
                    "metadata": {
                        "fuente":  nombre,
                        "dominio": self.dominio,
                        "chunk":   idx,
                    }
                })
            start = end - self.chunk_overlap
            idx += 1
        return chunks

    def _leer_archivo(self, path: Path) -> str:
        """Lee un archivo según su extensión (reutiliza lectores de Mx_01)."""
        import sys
        root = Path(__file__).parent.parent.parent.parent
        motor_dir = root / "motor"
        if str(motor_dir) not in sys.path:
            sys.path.insert(0, str(motor_dir))

        try:
            from Mx_01_LecturaEvidencias import leer_archivo_generico
            return leer_archivo_generico(path)
        except ImportError:
            # Fallback básico
            if path.suffix == ".txt":
                return path.read_text(encoding="utf-8", errors="ignore")
            return f"[No se pudo leer: {path.name}]"

    def build_index(self, force_rebuild: bool = False) -> None:
        """
        Construye el índice vectorial para este dominio.

        Args:
            force_rebuild: Si True, borra el índice existente y lo reconstruye.
        """
        client     = self._get_chroma_client()
        embed_fn   = self._get_embedding_function()
        coll_name  = f"virf_{self.dominio}"

        # Borrar colección existente si se pide rebuild
        if force_rebuild:
            try:
                client.delete_collection(coll_name)
                logger.info(f"[{self.dominio}] Colección anterior eliminada.")
            except Exception:
                pass

        collection = client.get_or_create_collection(
            name=coll_name,
            embedding_function=embed_fn,
            metadata={"hnsw:space": "cosine"},
        )
        self._collection = collection

        fuentes = self.get_source_paths()
        total_chunks = 0

        for ruta in fuentes:
            archivos = list(ruta.rglob("*")) if ruta.is_dir() else [ruta]
            for archivo in archivos:
                if archivo.suffix not in {".pdf", ".docx", ".pptx", ".xlsx", ".py", ".txt", ".md"}:
                    continue
                try:
                    texto = self._leer_archivo(archivo)
                    chunks = self._chunk_text(texto, archivo.name)
                    if not chunks:
                        continue

                    # Evitar duplicados: usar hash del contenido como ID
                    ids      = [hashlib.sha256(c["text"].encode()).hexdigest()[:16] for c in chunks]
                    textos   = [c["text"] for c in chunks]
                    metas    = [c["metadata"] for c in chunks]

                    collection.upsert(ids=ids, documents=textos, metadatas=metas)
                    total_chunks += len(chunks)
                    logger.info(f"  ✓ {archivo.name}: {len(chunks)} chunks indexados")
                except Exception as e:
                    logger.warning(f"  ✗ {archivo.name}: {e}")

        logger.info(f"[{self.dominio}] Índice construido: {total_chunks} chunks totales.")
        print(f"✅ [{self.dominio}] Índice RAG listo: {total_chunks} chunks en {self.vectordb_path}")

    def get_collection(self):
        """Retorna la colección ChromaDB (la abre si no está cargada)."""
        if self._collection is None:
            client   = self._get_chroma_client()
            embed_fn = self._get_embedding_function()
            self._collection = client.get_or_create_collection(
                name=f"virf_{self.dominio}",
                embedding_function=embed_fn,
                metadata={"hnsw:space": "cosine"},
            )
        return self._collection
