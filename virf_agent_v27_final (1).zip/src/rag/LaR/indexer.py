"""
src/rag/LaR/indexer.py
=======================
Indexador RAG para modelos de Liquidity at Risk (LaR).

Qué indexa:
  - inputs/documentacion/modelamiento/    ← Manuales metodológico y operativo
  - inputs/documentacion/seguimiento/     ← Backtesting, informes de seguimiento
  - inputs/papers/                         ← Papers académicos (Cornish-Fisher, etc.)
  - inputs/calidad_datos/                  ← _replica_virf.py, controles
  - inputs/usos/                           ← Reportes de uso (Comité LaR)

Uso en Databricks (notebook de setup):
    from src.rag.LaR.indexer import LaRIndexer
    idx = LaRIndexer()
    idx.build_index()                   # Primera vez
    idx.build_index(force_rebuild=True) # Si los documentos cambiaron

Programar rebuild mensual en Databricks Jobs (ver scripts/rebuild_rag.py).
"""

from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer


class LaRIndexer(BaseIndexer):
    dominio = "LaR"

    def get_source_paths(self) -> List[Path]:
        # Ruta raíz del proyecto (4 niveles arriba de este archivo)
        root = Path(__file__).parent.parent.parent.parent

        return [
            root / "inputs" / "documentacion" / "modelamiento",
            root / "inputs" / "documentacion" / "seguimiento",
            root / "inputs" / "papers",
            root / "inputs" / "calidad_datos",
            root / "inputs" / "usos",
        ]
