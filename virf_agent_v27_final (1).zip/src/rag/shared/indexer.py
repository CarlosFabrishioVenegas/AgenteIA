"""
src/rag/shared/indexer.py
=========================
Indexador RAG de conocimiento regulatorio compartido (transversal a todos los dominios).
Indexa: SR 11-7, EBA/GL/2023/01, BCBS 239, papers regulatorios generales.
Es el fallback cuando no hay un dominio específico. Hereda de BaseIndexer.
"""
from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer

class SharedIndexer(BaseIndexer):
    dominio = "shared"
    def get_source_paths(self) -> List[Path]:
        root = Path(__file__).parent.parent.parent.parent
        return [root / "inputs" / "papers"]
