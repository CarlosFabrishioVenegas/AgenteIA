"""
src/rag/conductuales/indexer.py
================================
Indexador RAG para modelos conductuales (prepago, retiro de depósitos, NMD).
Indexa manuales conductuales, EBA guidelines y documentos de seguimiento.
Hereda de BaseIndexer. Uso: ConductualesIndexer().build_index()
"""
from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer

class ConductualesIndexer(BaseIndexer):
    dominio = "conductuales"
    def get_source_paths(self) -> List[Path]:
        root = Path(__file__).parent.parent.parent.parent
        return [root / "inputs" / "documentacion" / "modelamiento",
                root / "inputs" / "documentacion" / "seguimiento",
                root / "inputs" / "papers",
                root / "inputs" / "implementacion"]
