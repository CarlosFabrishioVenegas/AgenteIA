"""
src/rag/VaR/indexer.py
=======================
Indexador RAG para modelos de Value at Risk (VaR).
Indexa manuales metodológicos VaR, papers FRTB/Basilea III y backtesting.
Hereda de BaseIndexer. Uso: VaRIndexer().build_index()
"""
from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer

class VaRIndexer(BaseIndexer):
    dominio = "VaR"
    def get_source_paths(self) -> List[Path]:
        root = Path(__file__).parent.parent.parent.parent
        return [root / "inputs" / "documentacion" / "modelamiento",
                root / "inputs" / "documentacion" / "seguimiento",
                root / "inputs" / "papers"]
