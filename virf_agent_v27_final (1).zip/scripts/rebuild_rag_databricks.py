"""
scripts/rebuild_rag_databricks.py
===================================
Script de mantenimiento para reconstruir los índices RAG en Databricks.

CUÁNDO EJECUTAR:
  - Mensualmente (Databricks Job programado)
  - Cuando se agregan documentos nuevos a inputs/
  - Después de cambios en la lógica de chunking

USO:
  # Desde terminal o notebook Databricks:
  python scripts/rebuild_rag_databricks.py --dominio LaR
  python scripts/rebuild_rag_databricks.py --dominio VaR
  python scripts/rebuild_rag_databricks.py --dominio conductuales
  python scripts/rebuild_rag_databricks.py --dominio shared
  python scripts/rebuild_rag_databricks.py --dominio all       ← Todos los dominios

  # Forzar rebuild completo (borra índice existente):
  python scripts/rebuild_rag_databricks.py --dominio all --force

  # Verificar estado sin reconstruir:
  python scripts/rebuild_rag_databricks.py --status

DATABRICKS JOB (config sugerida):
  - Cluster: Single-node, DBR 14+
  - Schedule: Cron "0 2 1 * *"  (día 1 de cada mes, 2am)
  - Timeout: 60 minutos
  - %pip install chromadb sentence-transformers  (en notebook de setup)
"""

import argparse
import sys
import time
from pathlib import Path

# Agregar raíz del proyecto al path
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "motor"))

DOMINIOS = ["LaR", "VaR", "conductuales", "shared"]


def _get_indexer(dominio: str):
    """Importa y retorna el indexer del dominio especificado."""
    if dominio == "LaR":
        from src.rag.LaR.indexer import LaRIndexer
        return LaRIndexer()
    elif dominio == "VaR":
        from src.rag.VaR.indexer import VaRIndexer
        return VaRIndexer()
    elif dominio == "conductuales":
        from src.rag.conductuales.indexer import ConductualesIndexer
        return ConductualesIndexer()
    elif dominio == "shared":
        from src.rag.shared.indexer import SharedIndexer
        return SharedIndexer()
    else:
        raise ValueError(f"Dominio desconocido: {dominio}. Opciones: {DOMINIOS}")


def rebuild_dominio(dominio: str, force: bool = False) -> dict:
    """
    Reconstruye el índice RAG de un dominio.

    Returns:
        dict con 'dominio', 'ok', 'duracion_seg', 'error'
    """
    print(f"\n{'='*60}")
    print(f"  Rebuilding RAG: {dominio}")
    print(f"{'='*60}")

    t0 = time.time()
    try:
        indexer = _get_indexer(dominio)
        indexer.build_index(force_rebuild=force)
        duracion = round(time.time() - t0, 1)
        print(f"  ✅ {dominio} completado en {duracion}s")
        return {"dominio": dominio, "ok": True, "duracion_seg": duracion, "error": None}
    except Exception as e:
        duracion = round(time.time() - t0, 1)
        print(f"  ❌ {dominio} falló: {e}")
        return {"dominio": dominio, "ok": False, "duracion_seg": duracion, "error": str(e)}


def mostrar_status():
    """Muestra el estado de cada índice RAG (tamaño, ruta, última modificación)."""
    import os
    from src.rag.base_indexer import _get_vectordb_base

    base = _get_vectordb_base()
    print(f"\n{'='*60}")
    print(f"  Estado de índices RAG")
    print(f"  Base: {base}")
    print(f"{'='*60}")

    for dominio in DOMINIOS:
        ruta = base / dominio
        if ruta.exists():
            archivos = list(ruta.rglob("*"))
            tam_mb = sum(f.stat().st_size for f in archivos if f.is_file()) / (1024 * 1024)
            ultima_mod = max(
                (f.stat().st_mtime for f in archivos if f.is_file()),
                default=0
            )
            from datetime import datetime
            fecha = datetime.fromtimestamp(ultima_mod).strftime("%Y-%m-%d %H:%M") if ultima_mod else "?"
            print(f"  ✅ {dominio:<15} {tam_mb:>6.1f} MB  —  última modificación: {fecha}")
        else:
            print(f"  ⚠️  {dominio:<15} No existe ({ruta})")

    print()


def main():
    parser = argparse.ArgumentParser(
        description="Reconstruye índices RAG del agente VIRF en Databricks."
    )
    parser.add_argument(
        "--dominio",
        choices=DOMINIOS + ["all"],
        help="Dominio a reconstruir ('all' para todos)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Borrar índice existente antes de reconstruir",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        default=False,
        help="Mostrar estado de los índices sin reconstruir",
    )
    args = parser.parse_args()

    if args.status:
        mostrar_status()
        return

    if not args.dominio:
        parser.print_help()
        sys.exit(1)

    dominios_a_procesar = DOMINIOS if args.dominio == "all" else [args.dominio]
    t_total = time.time()
    resultados = []

    for dom in dominios_a_procesar:
        res = rebuild_dominio(dom, force=args.force)
        resultados.append(res)

    # Resumen final
    print(f"\n{'='*60}")
    print(f"  RESUMEN REBUILD RAG")
    print(f"{'='*60}")
    ok_count = sum(1 for r in resultados if r["ok"])
    print(f"  Dominios procesados : {len(resultados)}")
    print(f"  Exitosos            : {ok_count}")
    print(f"  Fallidos            : {len(resultados) - ok_count}")
    print(f"  Tiempo total        : {round(time.time() - t_total, 1)}s")

    for r in resultados:
        estado = "✅" if r["ok"] else "❌"
        print(f"  {estado} {r['dominio']:<15} ({r['duracion_seg']}s)"
              + (f"  — {r['error']}" if r["error"] else ""))

    if any(not r["ok"] for r in resultados):
        sys.exit(1)  # Databricks Job detectará el código de salida


if __name__ == "__main__":
    main()
