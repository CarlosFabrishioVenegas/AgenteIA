# VIRF Agent v27 — Validador de Modelos Financieros

> Agente de IA conversacional para la **validación independiente de modelos de riesgo financiero**.
> Detecta fórmulas matemáticamente incorrectas, falta de sustento científico e inconsistencias metodológicas en modelos de **LaR, VaR y modelos conductuales**. Genera un informe ejecutivo de validación con veredicto formal.

---

## Tabla de contenidos

1. [¿Qué hace exactamente?](#qué-hace-exactamente)
2. [Arquitectura general](#arquitectura-general)
3. [Mapa de archivos](#mapa-de-archivos)
4. [Flujos de datos](#flujos-de-datos)
5. [Modos de uso](#modos-de-uso)
6. [Configuración](#configuración)
7. [Sistema RAG](#sistema-rag)
8. [Sistema de hallazgos](#sistema-de-hallazgos)
9. [Sistema de feedback](#sistema-de-feedback)
10. [Despliegue en Databricks](#despliegue-en-databricks)
11. [Referencias regulatorias incorporadas](#referencias-regulatorias-incorporadas)
12. [Convenciones de desarrollo](#convenciones-de-desarrollo)

---

## ¿Qué hace exactamente?

El VIRF Agent v27 es un validador de modelos financieros que opera de dos maneras:

### Modo conversacional (v27 — principal)

El analista **conversa libremente** con el agente sobre el modelo que está validando. Puede pegar fórmulas, fragmentos de código Python, descripciones metodológicas o preguntas sobre normativa. El agente:

1. **Detecta errores automáticamente** en dos capas (ver más abajo).
2. **Acumula hallazgos** durante toda la sesión sin perder contexto.
3. Cuando el analista escribe `/validar`, **sintetiza todos los hallazgos** en un informe ejecutivo Word con veredicto formal: `APTO`, `APTO CON CONDICIONES` o `NO APTO PARA USO EN GESTIÓN`.

```
Tú > Esta es la fórmula de VaR que usamos: VaR = μ + σ × z(0.95)

🔍 [CRÍTICO] Error de signo detectado en VaR paramétrico.
   VaR = μ + σ·z implica que una pérdida es positiva en la cola derecha,
   pero el cuantil de pérdidas debería ser μ - σ·z (cola izquierda).
   Corrección: VaR = -(μ - σ × z_α) — Ref: Jorion (2006) cap. 5.

   📌 1 nuevo hallazgo registrado. Total: 1 | Usa /hallazgos para ver

Tú > /validar
  → Genera informe Word + JSON con todos los hallazgos acumulados
```

### Modo pipeline batch (v25/v26 legacy)

Evaluación automática de un modelo completo contra estándares regulatorios, sin interacción:

- **Pipeline 1** (por control): lee `ControlesData.xlsx`, evalúa cada control con evidencia documental y motor automático de datos.
- **Pipeline 2** (por ámbito): lee `Estandares_VIRF.xlsx`, evalúa todas las actividades de cada ámbito regulatorio.

Ambos pipelines son accesibles desde el mismo punto de entrada (`virf_agente.py`) y pueden combinarse con el modo conversacional (`--chat-post`).

---

## Arquitectura general

```
┌─────────────────────────────────────────────────────────────────────┐
│                        VIRF AGENT v27                               │
│                                                                     │
│  virf_agente.py ──────────────────────────────────────────────────  │
│  (Punto de entrada unificado)                                       │
│         │                                                           │
│         ├─── --chat ──────► agent/virf_agent.py (VIRFAgent)        │
│         │                         │                                 │
│         │         ┌───────────────┴──────────────────┐             │
│         │         │        DOS CAPAS DE DETECCIÓN     │             │
│         │         │                                   │             │
│         │    Capa 1: ESTÁTICA (sin LLM)          Capa 2: LLM       │
│         │    evaluators/                          skills/           │
│         │    ├─ formula_detector.py         ├─ formula_detection   │
│         │    └─ methodology_checker.py      ├─ methodology_skill   │
│         │         │ hallazgos regex          └─ consolidator_skill  │
│         │         └──────────────────────────────┘                 │
│         │                        │                                  │
│         │                 Acumulación en                            │
│         │               VIRFAgent.hallazgos[]                       │
│         │                        │                                  │
│         │                    /validar                               │
│         │                        │                                  │
│         │              ConsolidatorSkill                            │
│         │         (Informe Word + JSON + veredicto)                 │
│         │                                                           │
│         ├─── --control ──► modulos/motor_ia_v2.py  (Pipeline 1)   │
│         │                         │                                 │
│         │    ControlesData.xlsx → evaluar_control() × N            │
│         │         Mx_01(lectura) + Mx_04(datos) + Mx_02(prompt)    │
│         │         + Mx_03(API) → generador_word.py                 │
│         │                                                           │
│         └─── --tier ───► modulos/motor_ia.py  (Pipeline 2)        │
│                                  │                                  │
│         Estandares_VIRF.xlsx → evaluar_ambito() × ámbitos          │
│              + RAG por dominio + memoria inter-ámbito               │
│              → calcular_score_global() → generador_word.py         │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  INFRAESTRUCTURA COMPARTIDA (motor/)                         │  │
│  │  Mx_00 Config · Mx_01 Lectura · Mx_02 Prompts               │  │
│  │  Mx_03 API · Mx_04 Datos · Mx_05 Comparativa Doc/Código     │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │  RAG SEGMENTADO (src/rag/)                                   │  │
│  │  LaR · VaR · conductuales · shared                           │  │
│  │  ChromaDB en DBFS (Databricks) o local                       │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

### Principios de diseño

| Principio | Implementación |
|-----------|---------------|
| **Separación de capas** | `motor/` (infraestructura pura) nunca importa de `modulos/` (negocio) |
| **Degradación elegante** | RAG, caché y Word son opcionales; el agente funciona sin ellos |
| **Fuente única de config** | `config.py` y `Mx_00` son las únicas fuentes de verdad para rutas y parámetros |
| **Sin LLM en la capa estática** | `formula_detector` y `methodology_checker` nunca hacen llamadas API |
| **Hallazgos como ciudadanos de primera clase** | Cada hallazgo tiene tipo, gravedad, descripción, corrección, referencia y timestamp |

---

## Mapa de archivos

```
virf_agent_v27/
│
├── virf_agente.py               ← PUNTO DE ENTRADA unificado (--chat, --control, --tier)
├── agente.py                    ← Punto de entrada legacy v25/v26 (retrocompatibilidad)
├── config.py                    ← Configuración centralizada: API, rutas, parámetros globales
├── requirements.txt             ← Dependencias Python
├── .env.example                 ← Plantilla de variables de entorno
│
├── agent/                       ← AGENTE CONVERSACIONAL (nuevo en v27)
│   ├── virf_agent.py            ← Clase VIRFAgent: loop conversacional, clasificador, /comandos
│   ├── evaluators/
│   │   ├── formula_detector.py       ← Detección estática de fórmulas incorrectas (regex, sin LLM)
│   │   └── methodology_checker.py    ← Verificación estática de solidez metodológica (regex, sin LLM)
│   ├── skills/
│   │   ├── formula_detection_skill.py ← Análisis profundo de fórmulas con LLM → JSON estructurado
│   │   ├── methodology_skill.py       ← Evaluación de 5 dimensiones metodológicas con LLM
│   │   ├── consolidator_skill.py      ← Genera informe ejecutivo con /validar
│   │   └── word_export_skill.py       ← Exporta el informe a .docx
│   ├── memory/
│   │   ├── short_term_memory.py      ← Memoria de sesión: deque RAM circular (max 50 ítems)
│   │   └── long_term_memory.py       ← Memoria persistente entre sesiones: JSONL en disco
│   ├── reasoning/
│   │   └── chain_of_thought.py       ← Descomposición de queries complejas en pasos
│   └── feedback/
│       └── feedback_store.py         ← Rating 1-5 por respuesta, lecciones aprendidas
│
├── motor/                       ← INFRAESTRUCTURA PURA (sin lógica de negocio)
│   ├── Mx_00_CargaRutas.py          ← Rutas, constantes, ROL_AGENTE, AMBITO_A_INPUTS
│   ├── Mx_01_LecturaEvidencias.py   ← Lectores: PDF, DOCX, PPTX, XLSX, PY, JSON, TXT, IPYNB
│   ├── Mx_02_EstructuraPrompt.py    ← Constructores de prompts para cada tipo de evaluación
│   ├── Mx_03_LlamarIA.py            ← HTTP a Anthropic/Azure con retry, parseo JSON, contratos
│   ├── Mx_04_MotorControlesData.py  ← Controles automáticos por regex/pandas (sin API)
│   └── Mx_05_ComparativaDocCodigo.py ← Coherencia entre documentos y código fuente
│
├── modulos/                     ← LÓGICA DE NEGOCIO
│   ├── motor_ia.py              ← Orquestador principal: evaluar_actividad(), orquestar_pipeline_*()
│   ├── motor_ia_v2.py           ← Orquestador Pipeline 1 (por control): evaluar_control()
│   ├── generador_word.py        ← Genera informes Word con scoring, semáforo y tablas
│   ├── generador_excel.py       ← Exporta resultados a Excel con formato condicional
│   ├── generador_template.py    ← Plantillas de documentos Word vacíos para el analista
│   ├── generador_estadistica_feedback.py ← Informe de precisión del agente (MAE, sesgo, etc.)
│   ├── chunker.py               ← Chunking inteligente de documentos largos con LLM
│   ├── document_cache.py        ← Caché SHA-256 de documentos parseados (modo pre-PRDC)
│   ├── lector_inputs.py         ← Lectores alternativos con pdfplumber/openpyxl
│   ├── feedback.py              ← Registro y carga de feedback del validador humano
│   ├── feedback_mejorado.py     ← Análisis de patrones de error y ajuste dinámico de prompts
│   └── v13_fixes.py             ← Correcciones críticas v13: estados, rutas, chunking, scoring
│
├── src/                         ← SISTEMA RAG SEGMENTADO
│   └── rag/
│       ├── __init__.py               ← Dispatcher: get_retriever(), inferir_dominio()
│       ├── base_indexer.py           ← Clase base: ChromaDB + sentence-transformers multilingüe
│       ├── base_retriever.py         ← Clase base: query(), query_para_prompt()
│       ├── LaR/
│       │   ├── indexer.py            ← Indexa docs de liquidez (manuales, papers, controles)
│       │   └── retriever.py          ← Recupera contexto de LaR para el prompt
│       ├── VaR/
│       │   ├── indexer.py            ← Indexa docs de riesgo de mercado
│       │   └── retriever.py          ← Recupera contexto de VaR para el prompt
│       ├── conductuales/
│       │   ├── indexer.py            ← Indexa docs de modelos conductuales
│       │   └── retriever.py          ← Recupera contexto conductual para el prompt
│       └── shared/
│           ├── indexer.py            ← Indexa literatura regulatoria transversal
│           └── retriever.py          ← Fallback para dominios sin índice específico
│
├── scripts/
│   └── rebuild_rag_databricks.py    ← Reconstruye índices RAG (ejecutar mensualmente)
│
├── inputs/                      ← DOCUMENTOS DEL MODELO (poblar con archivos reales)
│   ├── Estandares_VIRF.xlsx         ← Estándares por Tier (Pipeline 2) — NO EDITAR
│   ├── documentacion/
│   │   ├── modelamiento/            ← Manuales metodológico y operativo del modelo
│   │   └── seguimiento/             ← Backtesting, informes de seguimiento, KPIs
│   ├── papers/                      ← Referencias académicas y regulatorias (PDF)
│   ├── calidad_datos/
│   │   ├── ControlesData.xlsx       ← Configuración de controles (Pipeline 1)
│   │   └── _replica_virf.py         ← Script de control de segunda línea
│   ├── implementacion/              ← Correos UAT, controles de implementación
│   └── usos/                        ← Actas de comité, reportes de uso del modelo
│
├── outputs/                     ← SALIDAS GENERADAS (se crean automáticamente)
│   ├── Informe_Validacion_*.docx    ← Informe Word final
│   ├── hallazgos_*.json             ← Hallazgos en formato JSON estructurado
│   └── virf_feedback.jsonl          ← Feedback de sesiones conversacionales
│
├── data/                        ← DATOS DE RAG Y CACHÉ
│   ├── cache/                       ← Caché de documentos parseados (SHA-256)
│   └── vectordb/                    ← Índices ChromaDB por dominio
│
└── .github/
    └── copilot-instructions.md      ← Instrucciones para agentes de IA (Copilot, Cursor, etc.)
```

---

## Flujos de datos

### Flujo conversacional (`--chat`)

```
Usuario escribe texto
        │
        ▼
_clasificar_consulta()
  Detecta: formula | metodologia | rag | codigo | general
        │
        ├── formula / codigo
        │       ├── FormulaDetector.analizar()           [sin LLM — regex]
        │       └── FormulaDetectionSkill.ejecutar()     [LLM → JSON]
        │
        ├── metodologia
        │       ├── MethodologyChecker.verificar()       [sin LLM — regex]
        │       ├── MethodologySkill.ejecutar()          [LLM → JSON]
        │       └── RAG.query_para_prompt()              [ChromaDB]
        │
        ├── rag
        │       └── RAG.query_para_prompt(top_k=5)      [ChromaDB]
        │
        └── general
                └── Conversación directa con contexto de sesión
        │
        ▼
ShortTermMemory.store()              ← guarda en deque RAM
_registrar_hallazgo() × N           ← acumula hallazgos detectados
LLM streaming (claude-sonnet-4-6)   ← genera respuesta visible
_extraer_hallazgos_de_respuesta()   ← extrae hallazgos del texto de respuesta
solicitar_feedback()                ← rating 1-5 opcional
        │
        ▼
  /validar
        │
ConsolidatorSkill.generar_informe() ← prompt con TODOS los hallazgos
        ├── outputs/hallazgos_*.json
        └── outputs/Informe_Validacion_*.docx
```

### Flujo Pipeline 1 (`--control`)

```
ControlesData.xlsx
  │  (una fila = un control)
  ▼
motor_ia_v2.evaluar_todos_controles()
  │
  ├── Mx_01.obtener_evidencia_por_control()
  │     Lee: Evidencias/<ctrl_id>/ → PDF, DOCX, PY, XLSX
  │
  ├── Mx_01.obtener_conocimiento_por_modelo()
  │     Lee: Conocimiento/ → documentos del modelo
  │
  ├── Mx_04.ejecutar_motor_data_por_fila()    [sin LLM]
  │     Controles: unicidad, completitud, rangos, formatos
  │
  ├── Mx_02.construir_prompt_final()
  │     Ensambla: rol + estándares + evidencia + resultado data
  │
  ├── Mx_03._llamar_modelo()                  [API Anthropic/Azure]
  │     Retorna JSON con estado, observación, hallazgos, puntaje
  │
  └── _parsear_json() + _validar_contrato()
        │
        ▼
motor_ia_v2.generar_informe_final()
  └── generador_word.generar_word_informe()
```

### Flujo Pipeline 2 (`--tier`)

```
Estandares_VIRF.xlsx (filtrado por Tier)
  │
  ▼
motor_ia.orquestar_pipeline_ambitos()
  │
  ├── cargar_todos_inputs()
  │     Lee todas las carpetas inputs/ según AMBITO_A_INPUTS
  │     ChunkerService.procesar_lote() → resume docs > 12,000 chars
  │
  ├── [por cada ámbito]
  │     inputs_para_dimension() → selecciona docs del ámbito
  │     evaluar_ambito_completo() o evaluar_todos_ambitos_paralelo()
  │       │
  │       └── [por cada actividad]
  │             _enriquecer_con_rag()            [ChromaDB — opcional]
  │             _construir_bloque_antisesgo()    [previene sesgos]
  │             Mx_03.llamar_ia_json()           [API]
  │             _parsear_json()
  │             memoria inter-ámbito acumulada
  │
  ├── calcular_score_ambito() × ámbito
  ├── calcular_score_global()      [ponderado por AMBITO_PESOS]
  ├── get_semaforo()               [Verde/Amarillo/Rojo]
  ├── generar_resumen_ejecutivo()  [narrativa Word]
  └── generador_word.generar_word_informe()
```

---

## Modos de uso

### Instalación

```bash
# 1. Clonar / descomprimir el proyecto
cd virf_agent_v27

# 2. Instalar dependencias
pip install -r requirements.txt

# 3. Configurar credenciales
cp .env.example .env
# Editar .env con tu ANTHROPIC_API_KEY

# 4. (Opcional) Construir índices RAG si tienes documentos en inputs/
python scripts/rebuild_rag_databricks.py --dominio all
```

### Modo conversacional

```bash
# Inicio básico
python virf_agente.py --chat

# Con modelo y dominio pre-configurados
python virf_agente.py --chat --titulo "Modelo LaR v3" --dominio LaR

# Desde Python (notebooks Databricks)
from agent.virf_agent import VIRFAgent
agente = VIRFAgent(titulo_modelo="Modelo LaR v3", dominio="LaR")
agente.run()  # interactivo

# Uso programático (sin loop)
respuesta = agente.chat("¿Esta fórmula de VaR es correcta? VaR = μ + σ×z")
hallazgos = agente.obtener_hallazgos()
informe   = agente.validar()
```

### Comandos del agente conversacional

| Comando | Descripción |
|---------|-------------|
| `/validar` | Genera el informe ejecutivo consolidado (Word + JSON) con todos los hallazgos |
| `/hallazgos` | Muestra los hallazgos acumulados clasificados por gravedad |
| `/cargar` | Recarga los documentos del modelo desde `inputs/` |
| `/titulo Nombre del modelo` | Cambia el modelo bajo validación e infiere el dominio RAG |
| `/dominio LaR` | Cambia el dominio RAG activo (`LaR`, `VaR`, `conductuales`, `shared`) |
| `/limpiar` | Reinicia la conversación pero conserva los hallazgos |
| `/reset` | Reinicia la sesión completamente (conversación + hallazgos) |
| `/feedback` | Muestra estadísticas de feedback de sesiones anteriores |
| `/salir` | Sale del agente |

### Pipelines batch

```bash
# Pipeline 1 — por control (recomendado para modelos con ControlesData.xlsx)
python virf_agente.py --titulo "Modelo LaR v3" --tier I --control

# Pipeline 1 con Excel específico
python virf_agente.py --titulo "Modelo LaR v3" --tier I \
  --control --excel inputs/calidad_datos/ControlesData.xlsx

# Pipeline 2 — por ámbito
python virf_agente.py --titulo "Modelo LaR v3" --tier I

# Pipeline 2 en paralelo (6-10 min vs 25-40 min secuencial)
python virf_agente.py --titulo "Modelo LaR v3" --tier I --paralelo

# Modo producción (sin score iterativo)
python virf_agente.py --titulo "Modelo LaR v3" --tier I --prdc

# Pipeline + sesión conversacional al terminar
python virf_agente.py --titulo "Modelo LaR v3" --tier I --chat-post

# Estadísticas de precisión del agente
python virf_agente.py --estadisticafeedback
```

---

## Configuración

### `.env` — Variables de entorno

```ini
# Proveedor de IA
IA_PROVEEDOR=anthropic                  # anthropic | azure_openai

# Anthropic
ANTHROPIC_API_KEY=sk-ant-api03-...
ANTHROPIC_MODELO=claude-sonnet-4-6
ANTHROPIC_MAX_TOKENS=4096

# Azure OpenAI (alternativa)
# AZURE_OPENAI_API_KEY=...
# AZURE_OPENAI_ENDPOINT=https://tu-recurso.openai.azure.com/
# AZURE_OPENAI_DEPLOYMENT=gpt-4o
# AZURE_OPENAI_API_VERSION=2024-02-01

# Caché de documentos (acelera modo pre-PRDC)
CACHE_ENABLED=1
CACHE_DIR=data/cache

# RAG
RAG_VECTORDB_DIR=data/vectordb
RAG_TOP_K=3
RAG_MIN_SCORE=0.35

# Chunking de documentos largos
VIRF_CHUNK_SIZE=12000
VIRF_CHUNK_OVERLAP=800
VIRF_MAX_CHUNKS=25
```

### `config.py` — Parámetros de evaluación

`config.py` es la **única fuente de verdad** para configuración. Editar solo este archivo para cambiar el proveedor de IA, la API key o los parámetros de lectura. No duplicar constantes en otros módulos.

### `Estandares_VIRF.xlsx` — Definición de actividades

Define qué actividades se evalúan por Tier y Ámbito en el Pipeline 2. Los nombres de los ámbitos en esta planilla deben coincidir **exactamente** con las claves de `AMBITO_A_INPUTS` en `Mx_00_CargaRutas.py` (son case-sensitive).

---

## Sistema RAG

El RAG (Retrieval-Augmented Generation) enriquece las evaluaciones con contexto semántico recuperado de la literatura del dominio.

### Dominios disponibles

| Dominio | Inferencia automática desde título | Documentos indexados |
|---------|-----------------------------------|---------------------|
| `LaR` | "lar", "liquidez", "hqla", "lic" | Manuales LaR, backtesting liquidez, controles |
| `VaR` | "var", "frtb", "mercado" | Manuales VaR, papers Basilea III, FRTB |
| `conductuales` | "conductual", "prepago", "nmd", "retiro" | Manuales conductuales, EBA guidelines |
| `shared` | Fallback para cualquier dominio | Papers regulatorios transversales |

### Uso desde código

```python
# El dominio se infiere automáticamente desde el título del modelo
from src.rag import get_retriever, inferir_dominio

dominio   = inferir_dominio("Modelo LaR Liquidez v3")  # → "LaR"
retriever = get_retriever(tipo_modelo="LaR")
contexto  = retriever.query_para_prompt(
    "¿Se documenta el backtesting de Kupiec?",
    top_k=3, min_score=0.35
)
# contexto es un string listo para insertar en el prompt
```

### Rebuild de índices

```bash
# Reconstruir un dominio
python scripts/rebuild_rag_databricks.py --dominio LaR

# Reconstruir todos los dominios
python scripts/rebuild_rag_databricks.py --dominio all

# Forzar rebuild (borra índice existente)
python scripts/rebuild_rag_databricks.py --dominio all --force

# Ver estado de índices
python scripts/rebuild_rag_databricks.py --status
```

En Databricks, los índices se persisten en `/dbfs/FileStore/virf/vectordb/<dominio>/`. El script detecta el entorno Databricks automáticamente vía la variable `DATABRICKS_RUNTIME_VERSION`.

---

## Sistema de hallazgos

### Estructura de un hallazgo

Cada hallazgo es un `dict` con este esquema:

```python
{
    "tipo":        "formula" | "metodologia" | "codigo" | "pipeline",
    "gravedad":    "CRÍTICO" | "ALTO" | "MEDIO" | "BAJO",
    "descripcion": "Descripción técnica precisa del problema",
    "correccion":  "Cómo debe corregirse, con fórmula correcta si aplica",
    "referencia":  "Kupiec (1995) / SR 11-7 Sección IV / BCBS FRTB §183",
    "fuente":      "formula_detector" | "methodology_checker" | "respuesta_llm",
    "timestamp":   "2026-06-01T14:32:11.123456",
}
```

### Patrones detectados (capa estática, sin LLM)

**Fórmulas financieras:**
- VaR paramétrico con signo incorrecto (`μ + σ·z` en lugar de `μ - σ·z`)
- Volatilidad anualizada sin raíz del tiempo (`σ × 252` en lugar de `σ × √252`)
- Duración modificada sin signo negativo en cambio de precio
- λ de EWMA sin calibración documentada
- LCR sin haircuts regulatorios sobre HQLA
- Correlación perfecta (ρ=1) sin justificación empírica
- Interpolación lineal de curva de tasas (debe ser log-lineal o NSS)

**Código Python:**
- `norm.ppf()` sin test previo de normalidad
- `.std()` sin `ddof` explícito
- División por variable de conteo sin protección contra denominador cero
- `np.log()` sin validación de argumento positivo

**Metodología:**
- Ventana temporal definida sin justificación
- Parámetros basados en "juicio de experto" sin respaldo cuantitativo
- Backtesting declarado como no realizado o no aplicable
- R² < 0.50 sin análisis de causa raíz
- Período de datos < 3 años
- Normalidad asumida sin test estadístico

### Veredicto final del informe

| Veredicto | Condición |
|-----------|-----------|
| **APTO** | Sin hallazgos CRÍTICOS ni ALTOS |
| **APTO CON CONDICIONES** | Hay hallazgos ALTOS pero no CRÍTICOS — se puede usar si se subsanan |
| **NO APTO PARA USO EN GESTIÓN** | Al menos un hallazgo CRÍTICO — requiere corrección antes de uso |

---

## Sistema de feedback

El sistema de feedback permite al agente **aprender de sus errores** a lo largo del tiempo.

### Feedback conversacional (v27)
Al final de cada respuesta, el agente solicita un rating 1-5. Las respuestas mal valoradas se incorporan al `system_prompt` de la siguiente sesión como "lecciones aprendidas".

### Feedback de pipeline (v25/v26 legacy)
Al final de cada corrida, el analista puede corregir cualquier puntaje. El historial se guarda en `feedback/historial_feedback.json` y se usa como contexto en la siguiente corrida para reducir el sesgo del agente.

### Estadísticas de precisión

```bash
python virf_agente.py --estadisticafeedback
```

Muestra: MAE (Error Absoluto Medio), sesgo promedio (¿sobrestima o subestima?), % de evaluaciones exactas, % dentro de ±1 punto.

---

## Despliegue en Databricks

### Configuración de rutas

```python
# Databricks detecta el entorno automáticamente
# Los índices RAG van a DBFS:
/dbfs/FileStore/virf/vectordb/LaR/
/dbfs/FileStore/virf/vectordb/VaR/
/dbfs/FileStore/virf/vectordb/conductuales/
/dbfs/FileStore/virf/vectordb/shared/

# La caché de documentos va a:
/dbfs/FileStore/virf/cache/
```

### Uso desde notebook Databricks

```python
# Celda 1: instalación
%pip install anthropic chromadb sentence-transformers python-docx openpyxl PyMuPDF

# Celda 2: agente conversacional (no-interactivo)
import sys
sys.path.insert(0, "/dbfs/FileStore/virf/virf_agent_v27")

from agent.virf_agent import VIRFAgent

agente = VIRFAgent(titulo_modelo="Modelo LaR v3", dominio="LaR")

# Conversar programáticamente
agente.chat("El modelo usa una ventana de 60 días sin justificación")
agente.chat("La fórmula de estrés es: LaR = μ + 2σ (sin distribución empírica)")

# Generar informe
informe = agente.validar()
print(informe)

# Celda 3: pipelines batch
from modulos.motor_ia import orquestar_pipeline_virf, orquestar_pipeline_ambitos

resultado = orquestar_pipeline_ambitos(
    titulo_modelo = "Modelo LaR v3",
    tier          = "I",
    paralelo      = True,
)
print(f"Score: {resultado['score_global']} — {resultado['semaforo']['label']}")
```

### Job de mantenimiento RAG (mensual)

```bash
# Configurar en Databricks Jobs:
# Schedule: "0 2 1 * *" (día 1 de cada mes, 2am)
# Cluster: Single-node, DBR 14+
# Script: scripts/rebuild_rag_databricks.py --dominio all
```

---

## Referencias regulatorias incorporadas

El agente conoce y aplica los siguientes marcos normativos en sus evaluaciones:

| Marco | Descripción | Aplicación |
|-------|-------------|-----------|
| **SR 11-7** (Fed, 2011) | Model Risk Management | Validación independiente, documentación, gobernanza |
| **EBA/GL/2023/01** | Internal Models Validation | Backtesting, cobertura, calibración |
| **BCBS 239** (BIS, 2013) | Risk Data Aggregation | Calidad de datos, completitud, integridad |
| **Basilea III / FRTB** (BIS, 2019) | Capital por riesgo de mercado | VaR, Expected Shortfall, períodos mínimos |
| **SBS Res. 9075-2012** | Riesgo de liquidez (Perú) | LaR, LCR, NSFR, escenarios de estrés |
| **Nelson-Siegel-Svensson** | Curvas de rendimiento | Calibración, parámetros, ajuste |
| **Kupiec (1995)** | Backtesting VaR | Cobertura incondicional, prueba LR |
| **Christoffersen (1998)** | Backtesting VaR | Independencia de excepciones |
| **Jorion (2006)** | Value at Risk | Fórmulas, distribuciones, backtesting |
| **McNeil, Frey, Embrechts (2005)** | Quantitative Risk Management | Distribuciones de colas pesadas, copulas |

---

## Convenciones de desarrollo

### Importaciones de `motor/`

`motor/` **no tiene `__init__.py`** (intencional). Los módulos `Mx_*` se importan así:

```python
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "motor"))
from Mx_00_CargaRutas import RUTAS, ROL_AGENTE
```

**Nunca agregar `__init__.py` a `motor/`** — rompería el patrón de importación existente.

### Acceso al LLM

- **Pipelines legacy**: siempre vía `config.get_cliente_ia()` o `Mx_03._llamar_modelo()`.
- **Agente conversacional**: vía `anthropic.Anthropic()` directamente en `virf_agent.py`.

### Caché de documentos

`DocumentCache` opera **solo en modo pre-PRDC**. En modo PRDC (`--prdc`), siempre lee en fresco. No deshabilitar esta distinción.

### Names de ámbitos

Los nombres en `AMBITO_A_INPUTS` son **case-sensitive** y deben coincidir exactamente con `Estandares_VIRF.xlsx`:
- ✅ `"Calidad de datos"` (d minúscula)
- ✅ `"Uso e integración a la gestión"` (nombre largo completo)

### Fallbacks obligatorios

Todos los módulos opcionales tienen fallback explícito:
- **RAG**: si ChromaDB no está instalado, retorna contexto vacío (no rompe el flujo).
- **ConsolidatorSkill**: si el LLM falla, genera `_informe_basico()` con los hallazgos crudos.
- **Word export**: si `python-docx` falla, el informe queda disponible en JSON.

---

## Changelog

| Versión | Cambios principales |
|---------|---------------------|
| **v27** | Agente conversacional con `/validar`, dos capas de detección, hallazgos acumulados, feedback por respuesta |
| **v26** | Sistema RAG segmentado por dominio (LaR/VaR/conductuales/shared), `orquestar_pipeline_ambitos()` como facade |
| **v25** | Orquestadores unificados en `motor_ia.py`, `orquestar_pipeline_virf()` como facade de motor_ia_v2 |
| **v20** | `ChunkerService` desacoplado, inyección de dependencia del cliente IA |
| **v15** | Caché de documentos SHA-256 para modo pre-PRDC |
| **v13** | Correcciones críticas: estados, rutas, scoring invertido, chunking |
