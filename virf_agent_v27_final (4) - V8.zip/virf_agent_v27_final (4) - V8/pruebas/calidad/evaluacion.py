"""
pruebas/calidad/evaluacion.py  [Pasos 42 · 63 · 76]
═════════════════════════════════════════════════════════════════════════════
Métricas de calidad del agente, con resultados VERSIONADOS para comparar cada
semestre (Paso 76).

⚠️ PROVISIONAL: el «Modelo de Evaluación de Validez» oficial está en la hoja
`Modelo_Evaluacion` de «Pasos Generales Agente 2.xlsx», que no está disponible.
Aquí se implementan métricas estándar y verificables; cuando llegue la hoja,
su fórmula se implementa EXACTAMENTE en `modelo_evaluacion_oficial()` (hoy
lanza NotImplementedError a propósito: no se inventa).

Entrada de concordancia (CSV, Paso 63): un dictamen por caso, del agente y del
validador humano, sobre modelos YA validados:
    caso_id,actividad,dictamen_agente,dictamen_humano,puntaje_agente,puntaje_humano

Tasa de alucinación (Paso 42): fracción de evaluaciones del motor cuya
afirmación tuvo que retirarse por falta de respaldo (citas no verificadas o NLI
negativo, SEG-16). Meta de la hoja: 0 %. Se reporta el número real.
"""
from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List

RESULTADOS = Path(__file__).resolve().parent / "resultados"


def _kappa(a: List[str], b: List[str]) -> float:
    n = len(a)
    if n == 0:
        return float("nan")
    po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = Counter(a), Counter(b)
    pe = sum(ca[k] * cb.get(k, 0) for k in ca) / (n * n)
    return 1.0 if pe == 1 else (po - pe) / (1 - pe)


def concordancia(filas: Iterable[Dict[str, str]]) -> Dict[str, float]:
    filas = list(filas)
    da = [f["dictamen_agente"].strip().upper() for f in filas]
    dh = [f["dictamen_humano"].strip().upper() for f in filas]
    pares = [(float(f["puntaje_agente"]), float(f["puntaje_humano"])) for f in filas
             if str(f.get("puntaje_agente", "")).strip() and str(f.get("puntaje_humano", "")).strip()]
    return {
        "n": len(filas),
        "acuerdo_dictamen": round(sum(x == y for x, y in zip(da, dh)) / len(filas), 4) if filas else float("nan"),
        "kappa_cohen": round(_kappa(da, dh), 4),
        "mae_puntaje": round(sum(abs(x - y) for x, y in pares) / len(pares), 4) if pares else float("nan"),
        "acuerdo_puntaje_exacto": round(sum(x == y for x, y in pares) / len(pares), 4) if pares else float("nan"),
    }


def tasa_alucinacion(evaluaciones: Iterable[dict]) -> Dict[str, float]:
    ev = [e for e in evaluaciones if isinstance(e, dict) and "afirmacion_invalidada" in e]
    inval = sum(1 for e in ev if e.get("afirmacion_invalidada"))
    abst = sum(1 for e in ev if e.get("abstenido"))
    return {"n": len(ev), "invalidadas": inval, "abstenciones": abst,
            "tasa_alucinacion": round(inval / len(ev), 4) if ev else float("nan"),
            "tasa_abstencion": round(abst / len(ev), 4) if ev else float("nan")}


def modelo_evaluacion_oficial(*_a, **_k):
    raise NotImplementedError(
        "Falta la hoja `Modelo_Evaluacion` (Pasos Generales Agente 2.xlsx): su fórmula "
        "se implementa tal cual cuando esté disponible. No se inventa.")


def leer_csv(ruta: Path) -> List[Dict[str, str]]:
    with open(ruta, encoding="utf-8") as f:
        return list(csv.DictReader(l for l in f if not l.startswith("#")))


def guardar_resultado(nombre: str, metricas: dict, fuente: str) -> Path:
    RESULTADOS.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    p = RESULTADOS / f"{ts}_{nombre}.json"
    p.write_text(json.dumps({"cuando": ts, "fuente": fuente, "provisional": True,
                             "metricas": metricas}, ensure_ascii=False, indent=2),
                 encoding="utf-8")
    return p


if __name__ == "__main__":  # pragma: no cover
    import argparse
    ap = argparse.ArgumentParser(description="Métricas de calidad del agente (provisionales)")
    ap.add_argument("--concordancia", help="CSV agente vs validador")
    ap.add_argument("--resultados", nargs="*", help="JSON de resultados del motor (alucinación)")
    a = ap.parse_args()
    if a.concordancia:
        m = concordancia(leer_csv(Path(a.concordancia)))
        print(m, guardar_resultado("concordancia", m, a.concordancia))
    if a.resultados:
        evs = []
        for r in a.resultados:
            d = json.loads(Path(r).read_text(encoding="utf-8"))
            for v in (d.get("resultados") or d).values() if isinstance(d, dict) else []:
                evs += v.get("evaluaciones", []) if isinstance(v, dict) else []
        m = tasa_alucinacion(evs)
        print(m, guardar_resultado("alucinacion", m, ",".join(a.resultados)))
