> Datos elaborados por BCP para uso Interno

# Calidad del agente (Modelo de Evaluación de Validez)

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Oportunidad de mejora – fuera del core | 42 · 63 · 76 |

`pruebas/calidad/evaluacion.py` (tests en `pruebas/test_calidad_e2e.py`):

- **Concordancia agente vs validador** (Paso 63): acuerdo de dictamen, kappa de Cohen, MAE de puntaje. Entrada: CSV `caso_id,actividad,dictamen_agente,dictamen_humano,puntaje_agente,puntaje_humano` sobre modelos ya validados 👤.
- **Tasa de alucinación** (Paso 42): fracción de evaluaciones con la afirmación retirada por falta de respaldo (SEG-16). Meta de la hoja: 0 %. Se reportará el número real.
- Resultados versionados en `pruebas/calidad/resultados/` para comparar cada semestre (Paso 76).

**Oportunidad de mejora (no bloquea, fuera del core: nada fuera de `pruebas/` importa este módulo):** la fórmula oficial del «Modelo de Evaluación de Validez» y el set de casos están en la hoja `Modelo_Evaluacion`, que no está disponible. `modelo_evaluacion_oficial()` lanza `NotImplementedError` a propósito. **No hay todavía ninguna medición real de alucinación ni de concordancia.**
