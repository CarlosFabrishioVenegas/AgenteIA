# -*- coding: utf-8 -*-
"""
Paso 64 · Casos borde de la lectura de evidencia (matriz: pruebas/matriz_casos_borde.md).

Regla común: el lector NUNCA lanza, NUNCA inventa contenido y declara la lectura
fallida como fallo técnico (no como «falta de evidencia»).
"""
from __future__ import annotations

import contextlib
import io
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "motor"))
with contextlib.redirect_stdout(io.StringIO()):
    import Mx_01_LecturaEvidencias as M  # noqa: E402


def _leer(p):
    with contextlib.redirect_stdout(io.StringIO()):
        return M.leer_archivo(p)


def test_archivo_vacio(tmp_path):
    p = tmp_path / "vacio.txt"; p.write_text("")
    r = _leer(p)
    assert r["chars_totales"] == 0 and r["contenido"] == ""


def test_archivo_enorme_no_revienta_y_declara_tamano(tmp_path):
    p = tmp_path / "enorme.txt"; p.write_text("linea del manual. " * 300_000)
    r = _leer(p)
    assert r["chars_totales"] == len("linea del manual. ") * 300_000
    assert r["lectura_fallida"] is False


@pytest.mark.parametrize("codificacion", ["cp1252", "latin-1", "utf-8-sig", "utf-16"])
def test_codificaciones_raras(tmp_path, codificacion):
    p = tmp_path / "manual.txt"
    p.write_bytes("Validación de señal del año".encode(codificacion))
    assert _leer(p)["contenido"] == "Validación de señal del año"


@pytest.mark.parametrize("nombre", ["Manual ñ #1 (v2) ✓.md", "acta  con  espacios.md",
                                    "informe_áéíóú.md", "nombre.con.puntos.md"])
def test_nombres_con_caracteres_especiales(tmp_path, nombre):
    p = tmp_path / nombre; p.write_text("contenido", encoding="utf-8")
    r = _leer(p)
    assert r["nombre"] == nombre and r["contenido"] == "contenido"


def test_pdf_protegido_se_diagnostica_como_protegido(tmp_path):
    from PyPDF2 import PdfWriter
    w = PdfWriter(); w.add_blank_page(200, 200); w.encrypt("clave")
    p = tmp_path / "protegido.pdf"
    with open(p, "wb") as f:
        w.write(f)
    r = _leer(p)
    assert r["lectura_fallida"] is True
    assert "PROTEGIDO CON CONTRASEÑA" in r["contenido"] and "ESCANEADO" not in r["contenido"]


def test_falso_pdf(tmp_path):
    p = tmp_path / "falso.pdf"; p.write_bytes(b"esto no es un pdf")
    r = _leer(p)
    assert r["lectura_fallida"] is True and "NO ES UN PDF" in r["contenido"]


def test_json_roto_no_inventa(tmp_path):
    p = tmp_path / "roto.json"; p.write_text('{"a": [1, 2', encoding="utf-8")
    r = _leer(p)
    assert r["lectura_fallida"] is True and "Error JSON" in r["contenido"]


def test_excel_corrupto(tmp_path):
    p = tmp_path / "x.xlsx"; p.write_bytes(b"\x00\x01basura")
    assert _leer(p)["lectura_fallida"] is True


def test_extension_desconocida_se_ignora(tmp_path):
    p = tmp_path / "x.exe"; p.write_bytes(b"MZ")
    assert _leer(p) is None


@pytest.mark.parametrize("bruto, codigo", [("", 400), ("..", 400), ("a\x00b.txt", 400),
                                           ("../../etc/passwd", None)])
def test_nombre_de_subida_peligroso(bruto, codigo):
    from fastapi import HTTPException
    from web.routers.upload import _nombre_seguro
    if codigo is None:
        assert _nombre_seguro(bruto) == "passwd"          # se queda solo el nombre
    else:
        with pytest.raises(HTTPException) as e:
            _nombre_seguro(bruto)
        assert e.value.status_code == codigo


def test_zip_slip_y_zip_bomba_cubiertos():
    # Ya probados en tests/test_upload_zip.py; aquí se exige que sigan existiendo.
    src = (RAIZ / "tests" / "test_upload_zip.py").read_text(encoding="utf-8")
    assert "def test_zip_slip_rechazado" in src and "def test_zip_bomba" in src
