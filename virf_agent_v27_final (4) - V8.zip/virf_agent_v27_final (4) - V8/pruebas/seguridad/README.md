> Datos elaborados por BCP para uso Interno

# Pruebas de seguridad (OWASP Top 10 LLM)

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Remediado – pendiente de validación (pentest 👤) | 62 |

Suite: `pruebas/seguridad/test_owasp_llm.py` (24 casos) contra el gateway real.

| OWASP LLM | Casos | Resultado |
|---|---|---|
| Inyección de prompt directa (chat) e indirecta (documentos), cierre de bloque falsificado | 7 | Neutralizada |
| Divulgación de información sensible: DNI, RUC, CCI, correo, **claves y tokens** | 9 | **Encontró un bug**: las credenciales dentro de la evidencia salían hacia el LLM. Corregido (`modulos/pii.py`, tipo `CREDENCIAL`) |
| Plugins inseguros / agencia excesiva (tools, código de IA) | 4 | Bloqueado |
| Salida insegura (afirmación sin respaldo, HTML) | 2 | Retirada / escapada |
| Envenenamiento (feedback no aprobado, corpus sin dueño) | 2 | Bloqueado |

**Pentest y DAST 👤:** los coordina Ciberseguridad (mismo flujo que SEG-09). Límite conocido: la detección de inyección es por patrones; un ataque semántico nuevo puede pasar.
