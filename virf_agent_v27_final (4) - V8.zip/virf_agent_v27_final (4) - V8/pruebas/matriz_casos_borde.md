> Datos elaborados por BCP para uso Interno

# Matriz de casos borde

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Remediado – pendiente de validación | 64 |

| Caso | Comportamiento esperado | Test | Estado |
|---|---|---|---|
| PDF escaneado | Fallo técnico declarado (OCR retirado por política) | `tests/test_regresion.py` | Verde |
| PDF protegido con contraseña | «PDF PROTEGIDO» (antes se decía «escaneado») | `pruebas/test_casos_borde.py` | **Corregido en este cambio** |
| Falso PDF | «NO ES UN PDF VÁLIDO» | `pruebas/test_casos_borde.py` | **Corregido** |
| JSON roto | `lectura_fallida`, sin inventar | `pruebas/test_casos_borde.py` | Verde |
| Excel corrupto | `lectura_fallida` | `pruebas/test_casos_borde.py` | Verde |
| ZIP-bomba | 413 sin llenar disco | `tests/test_upload_zip.py` | Verde |
| ZIP-slip | 400 | `tests/test_upload_zip.py` | Verde |
| Archivo vacío | 0 caracteres, sin error | `pruebas/test_casos_borde.py` | Verde |
| Archivo enorme (5 MB de texto) | Se lee y declara su tamaño; el chunker lo procesa | `pruebas/test_casos_borde.py` | Verde |
| Codificación cp1252 / latin-1 / UTF-8 BOM / UTF-16 | Texto correcto («Validación») | `pruebas/test_casos_borde.py` | **Corregido** (antes «Validaci�n» y basura UTF-16) |
| Nombres con ñ, tildes, espacios, símbolos | Se leen con su nombre | `pruebas/test_casos_borde.py` | Verde |
| Nombre de subida con `..`, byte nulo o ruta | 400 o se reduce al nombre | `pruebas/test_casos_borde.py` | Verde |
| Extensión desconocida | Se ignora | `pruebas/test_casos_borde.py` | Verde |
