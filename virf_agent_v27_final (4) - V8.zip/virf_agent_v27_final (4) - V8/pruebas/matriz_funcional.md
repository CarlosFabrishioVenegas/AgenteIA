> Datos elaborados por BCP para uso Interno

# Matriz de pruebas funcionales

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Remediado – pendiente de validación | 61 |

Filas derivadas de la matriz de alcance (`gobierno/matriz_alcance.md`, Paso 4). Todas las pruebas automatizadas corren sin coste (IA simulada) en la suite.

| Capacidad | Caso de prueba | Resultado esperado | Test automatizado | Estado |
|---|---|---|---|---|
| Lectura de evidencia: PDF digital / escaneado / protegido / falso | Leer cada tipo | Texto o fallo técnico declarado, nunca contenido inventado | `pruebas/test_casos_borde.py`, `tests/test_regresion.py` (TestAuditoriaLectura…) | Verde |
| Lectura: DOCX, PPTX, XLSX, PY, IPYNB, JSON, TXT/MD/CSV | Leer y corrupto | Contenido o `lectura_fallida` | `pruebas/test_casos_borde.py`, `tests/test_regresion.py` | Verde |
| Subida con clasificación | Sin clasificación / Restringido en portátil | 422 / 403 | `tests/test_almacenamiento.py` | Verde |
| Subida ZIP | ZIP-slip, ZIP-bomba, demasiadas entradas | 400 / 413 | `tests/test_upload_zip.py` | Verde |
| Evaluación por actividad | Cita literal / inventada / NLI negativo / sin evidencia | Observación intacta / retirada / retirada / abstención | `tests/test_salvaguardas_llm.py` | Verde |
| Informe Word (3 plantillas) | Generar y abrir | Estructura completa + etiqueta en todas las secciones | `tests/test_plantilla_bcp.py`, `tests/test_clasificacion_docx.py` | Verde |
| Informe Solo-IA | Pulir texto con PII | PII fuera del prompt | `tests/test_solo_informe_ia.py` | Verde |
| Flujo HITL: firma | Sin sesión / firmante tecleado / sesión SSO | 401 / rechazo / firma con identidad | `tests/test_identidad.py` | Verde |
| Flujo HITL: doble firma | Misma persona / otra identidad | Rechazo / acepta | `tests/test_pendientes_auditoria.py::TestDobleFirma` | Verde |
| Flujo HITL: feedback | Pendiente / aprobado / autor aprueba | No ajusta / ajusta / 403 | `tests/test_gobierno_codigo.py` | Verde |
| Chat de sustentación | Corrección registrada y aprobada | Entra al contexto solo tras aprobar | `tests/test_aprendizaje_chat.py` | Verde |
| Errores esperados | Proveedor no aprobado / host no permitido / clave en `.env` | Error explícito | `tests/test_proveedores_ia.py`, `tests/test_credenciales.py` | Verde |
| E2E | Pipeline completo con datos sintéticos | Informe con etiqueta, PII fuera, inyección neutralizada | `pruebas/test_calidad_e2e.py` (simulado); `--real` 👤 | Simulado verde · real pendiente |
