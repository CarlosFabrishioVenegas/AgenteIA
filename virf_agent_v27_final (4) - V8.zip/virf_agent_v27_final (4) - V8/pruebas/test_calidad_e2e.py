# -*- coding: utf-8 -*-
"""Pasos 42 · 60 · 63 · 65 — métricas de calidad, rúbrica sellada y E2E sintético."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ / "pruebas" / "calidad"))
import evaluacion as ev  # noqa: E402


def test_concordancia_y_kappa():
    filas = [{"dictamen_agente": a, "dictamen_humano": h, "puntaje_agente": pa, "puntaje_humano": ph}
             for a, h, pa, ph in [("CUMPLE", "CUMPLE", "4", "4"), ("NO CUMPLE", "NO CUMPLE", "1", "2"),
                                  ("CUMPLE", "NO CUMPLE", "3", "1"), ("PARCIAL", "PARCIAL", "2", "2")]]
    m = ev.concordancia(filas)
    assert m["n"] == 4 and m["acuerdo_dictamen"] == 0.75
    assert m["mae_puntaje"] == pytest.approx(0.75) and m["acuerdo_puntaje_exacto"] == 0.5
    assert 0 < m["kappa_cohen"] < 1


def test_tasa_de_alucinacion_se_reporta_real():
    evs = [{"afirmacion_invalidada": True}, {"afirmacion_invalidada": False},
           {"afirmacion_invalidada": False, "abstenido": True}, {"sin_campo": 1}]
    m = ev.tasa_alucinacion(evs)
    assert m == {"n": 3, "invalidadas": 1, "abstenciones": 1,
                 "tasa_alucinacion": 0.3333, "tasa_abstencion": 0.3333}


def test_modelo_oficial_no_se_inventa():
    with pytest.raises(NotImplementedError, match="Modelo_Evaluacion"):
        ev.modelo_evaluacion_oficial()


def test_oportunidades_de_mejora_no_tocan_el_core():
    """Pasos 19·42·63·76 son oportunidades de mejora: el core no puede depender de ellos."""
    import ast
    prohibidos = {"evaluacion", "pruebas", "pruebas.calidad", "pruebas.calidad.evaluacion"}
    culpables, revisados = [], 0
    for carpeta in ("modulos", "motor", "web", "config", "scripts"):
        for py in (RAIZ / carpeta).rglob("*.py"):
            revisados += 1
            arbol = ast.parse(py.read_text(encoding="utf-8", errors="replace"))
            for nodo in ast.walk(arbol):
                nombres = ([a.name for a in nodo.names] if isinstance(nodo, ast.Import)
                           else [nodo.module or ""] if isinstance(nodo, ast.ImportFrom) else [])
                if any(n in prohibidos or n.startswith("pruebas.") for n in nombres):
                    culpables.append(str(py.relative_to(RAIZ)))
            texto = py.read_text(encoding="utf-8", errors="replace")
            if "pruebas/calidad" in texto or "matriz_seleccion_llm" in texto:
                culpables.append(str(py.relative_to(RAIZ)))
    assert revisados > 50 and not culpables


def test_resultados_versionados(tmp_path, monkeypatch):
    monkeypatch.setattr(ev, "RESULTADOS", tmp_path)
    p = ev.guardar_resultado("concordancia", {"n": 1}, "x.csv")
    d = json.loads(p.read_text(encoding="utf-8"))
    assert d["provisional"] is True and d["metricas"] == {"n": 1}


# ── Paso 65 · rúbrica sellada ────────────────────────────────────────────────

@pytest.fixture
def ee(tmp_path, monkeypatch):
    from modulos import evaluacion_experta as ee
    monkeypatch.setattr(ee, "RUTA", tmp_path / "ev.jsonl")
    return ee


def test_rubrica_0_1_2_y_consolidado(ee):
    ee.registrar("caso1", "exp1@bcp.com.pe", "oid1", dict(exactitud=2, soporte_evidencia=1,
                                                          completitud=2, claridad=2))
    ee.registrar("caso1", "exp2@bcp.com.pe", "oid2", dict(exactitud=1, soporte_evidencia=1,
                                                          completitud=0, claridad=2))
    c = ee.consolidar()
    assert c["n_evaluaciones"] == 2 and c["media_por_criterio"]["exactitud"] == 1.5


@pytest.mark.parametrize("puntajes", [dict(exactitud=3, soporte_evidencia=1, completitud=1, claridad=1),
                                      dict(exactitud=1)])
def test_rubrica_invalida(ee, puntajes):
    with pytest.raises(ValueError):
        ee.registrar("c", "e", "oid", puntajes)


def test_evaluacion_alterada_se_detecta(ee):
    ee.registrar("c", "e", "oid", dict(exactitud=2, soporte_evidencia=2, completitud=2, claridad=2))
    p = ee._ruta()
    p.write_text(p.read_text(encoding="utf-8").replace('"exactitud": 2', '"exactitud": 0'), encoding="utf-8")
    assert ee.verificar()["ok"] is False
    with pytest.raises(ValueError):
        ee.consolidar()


# ── Paso 60 · E2E sintético (modo simulado) ──────────────────────────────────

def test_e2e_sintetico_simulado(tmp_path):
    sys.path.insert(0, str(RAIZ / "pruebas" / "e2e"))
    import e2e_sintetico
    r = e2e_sintetico.ejecutar("simulado", tmp_path)
    assert r["evaluaciones"] == 2
    assert r["pii_fuera_del_prompt"] is True
    assert r["inyeccion_neutralizada"] is True
    assert r["informe_con_etiqueta"] is True
    assert (tmp_path / "resumen_e2e.json").exists()
