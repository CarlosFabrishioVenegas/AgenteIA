> Datos elaborados por BCP para uso Interno

# Rúbrica de evaluación por expertos

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 65 |

Cada experto puntúa cada caso con 0-1-2 por criterio. Registro sellado con hash encadenado: `modulos/evaluacion_experta.py` (editar o borrar una evaluación se detecta).

| Criterio | 0 | 1 | 2 |
|---|---|---|---|
| Exactitud | Conclusión errónea respecto al validador | Parcialmente correcta | Coincide con el juicio experto |
| Soporte de evidencia | Sin cita o cita que no la sostiene | Cita parcial | Cita literal que sostiene la afirmación |
| Completitud | Omite hallazgos materiales | Omite hallazgos menores | Cubre todos los hallazgos |
| Claridad | Confusa | Comprensible con esfuerzo | Clara y accionable |

**Formulario (por caso):** `caso_id` · experto (identidad SSO) · 4 puntajes · comentario. Registro:
```python
from modulos.evaluacion_experta import registrar, consolidar
registrar("PD-2025-01#Backtesting", upn, oid, {"exactitud": 2, "soporte_evidencia": 1, "completitud": 2, "claridad": 2})
consolidar()
```
👤 Los expertos (nombres en el RACI) evalúan; el agente solo consolida.
