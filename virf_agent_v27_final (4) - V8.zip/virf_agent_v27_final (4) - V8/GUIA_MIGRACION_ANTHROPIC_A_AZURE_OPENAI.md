# Guía de migración — Anthropic → Azure OpenAI

**Para qué sirve.** Cambiar VIRF Agent de Claude a Azure OpenAI sin romper ninguno
de los invariantes del sistema, y sabiendo exactamente qué se rompe si te lo
salteas. No es un tutorial genérico de SDK: cada paso remite al fichero y línea
de **este** proyecto.

> ## ⚠️ LEE ESTO PRIMERO — la migración YA ESTÁ HECHA
>
> Esta guía se escribió como **plan de migración**. Los pasos 2 a 11 ya se
> ejecutaron y están verificados con mocks. Se conserva porque documenta **por
> qué** cada decisión es como es, y porque los §§5-11 siguen siendo la
> referencia para confirmar el comportamiento contra tu deployment concreto.
>
> **Si solo quieres poner el sistema en marcha, no necesitas esta guía:**
> pega las 4 credenciales en `.env` y ejecuta
> `python agente.py --verificar-conexion-azure`. Ver `RUNBOOK.md` paso 0.
>
> Cada sección lleva su estado: **✅ HECHO** · **ℹ️ AHORA AUTOMÁTICO** ·
> **⚠️ REQUIERE TU DEPLOYMENT**.

**Estado real del código** (verificado el 30/07/2026 ejecutando):

| | |
|---|---|
| `openai` instalado | **2.48.0** · `AzureOpenAI` importable |
| `anthropic` instalado | sí (se mantiene como secundario) |
| `IA_PROVEEDOR` **default en el código** | ✅ **`azure_openai`** (`config/parametros.py:127`) |
| `AZURE_OPENAI_API_VERSION` por defecto | ✅ **`2024-10-21`** (GA estable) |
| Cliente Azure | ✅ completo: negocia el parámetro de tokens, detecta el modelo real, blinda `choices`/`content`, reintenta ante 429 |
| Catálogo de modelos | ✅ `config/modelos.py` — el chunking se deriva del modelo real |
| Credenciales Azure en `.env` | **ausentes** — las entrega IT (ver `README.md` §«Qué pedirle a IT») |
| Verificación | `validate_project.py --strict` → **131/131** · `pytest` → **473** |

---

## Índice

1. [Resumen ejecutivo: 6 diferencias que sí rompen cosas](#1-resumen-ejecutivo)
2. [Arquitectura de proveedores en este proyecto](#2-arquitectura-de-proveedores)
3. [Paso 1 — Credenciales y `.env`](#3-paso-1--credenciales-y-env)
4. [Paso 2 — Azure como default EN EL CÓDIGO](#4-paso-2--azure-como-default-en-el-código)
5. [Paso 3 — `api_version`: el error más frecuente](#5-paso-3--api_version)
6. [Paso 4 — `max_tokens` vs `max_completion_tokens`](#6-paso-4--max_tokens-vs-max_completion_tokens)
7. [Paso 5 — `temperature` y los modelos de razonamiento](#7-paso-5--temperature)
8. [Paso 6 — JSON nativo: la mejora que Azure regala](#8-paso-6--json-nativo)
9. [Paso 7 — Filtro de contenido: el fallo que Anthropic no tiene](#9-paso-7--filtro-de-contenido)
10. [Paso 8 — Cuotas TPM/RPM y las 40 llamadas del chunker](#10-paso-8--cuotas-y-rate-limits)
11. [Paso 9 — Recalibrar el chunking](#11-paso-9--recalibrar-el-chunking)
12. [Paso 10 — Eliminar el acoplamiento residual](#12-paso-10--acoplamiento-residual)
13. [Paso 11 — Política de NO fallback](#13-paso-11--política-de-no-fallback)
14. [Verificación: guion de aceptación](#14-verificación)
15. [Tabla de traducción de conceptos](#15-tabla-de-traducción)
16. [Diagnóstico de errores](#16-diagnóstico-de-errores)
17. [Paso 12 — El RAG: embeddings y reconstrucción del índice](#17-paso-12--el-rag-embeddings-y-reconstrucción-del-índice)
18. [Paso 13 — Fallos de transporte y de arranque](#18-paso-13--fallos-de-transporte-y-de-arranque)

---

## 1. Resumen ejecutivo

Seis diferencias entre Anthropic y Azure OpenAI que **rompen código** si las
ignoras. El resto de la migración es mecánico; esto es lo que duele.

| # | Diferencia | Qué se rompe |
|---|---|---|
| 1 | **Deployment ≠ modelo.** En Azure llamas al *nombre que tú diste al despliegue*, no al modelo | `model="gpt-4o"` da `DeploymentNotFound` si tu deployment se llama `gpt4o-prod` |
| 2 | **`api_version` obligatoria y versionada.** No existe en Anthropic | Una versión antigua rechaza parámetros nuevos con `400 Unrecognized request argument` |
| 3 | **`max_tokens` está deprecado** en los modelos de razonamiento (o1/o3/GPT-5): exigen `max_completion_tokens` | `400 Unsupported parameter: 'max_tokens'` — el cliente actual **falla** con esos modelos |
| 4 | **`temperature` rechazada** (o forzada a 1) por los modelos de razonamiento | `400` o resultados no reproducibles |
| 5 | **Filtro de contenido de Azure.** Anthropic no lo tiene | `choices=[]` o `finish_reason="content_filter"` → texto `None` |
| 6 | **Cuota por deployment (TPM/RPM)**, no por organización | Las 40 llamadas seguidas del chunker disparan `429` |

**Diferencia de fondo, y la que más afecta a este proyecto:** los tokenizadores
son distintos. El chunking está calibrado a **2,48 caracteres/token** para
español técnico medido con el `count_tokens` de Anthropic
(`README.md` §3.4.1). El tokenizador de OpenAI (`tiktoken`, `o200k_base` en
modelos recientes) da una relación distinta para español. Si no recalibras, el
presupuesto de contexto que el chunker cree tener **no es el que tiene** — y este
sistema ya emitió informes sobre el 1,2 % de un manual por un error de
presupuesto. Ver §11.

---

## 2. Arquitectura de proveedores

Toda la selección vive en `config/`, y eso ya está bien resuelto. No lo cambies.

```
config/parametros.py    IA_PROVEEDOR = os.getenv("IA_PROVEEDOR", "azure_openai")
        │                AZURE_API_VERSION, AZURE_MAX_TOKENS
        ▼
config/ia.py            ClienteIA (ABC)          ← interfaz abstracta
        │               ├── ClienteAnthropicIA   ← SDK anthropic
        │               └── ClienteAzureOpenAIIA ← SDK openai
        │               FABRICAS = {"anthropic": …, "azure_openai": …}
        │               get_cliente_ia()          ← único punto de entrada
        ▼
todo el negocio         cliente.generar_mensaje(prompt, instruccion_sistema,
                                               max_tokens, sistema) -> str
```

**El contrato de la interfaz es una sola función que devuelve `str`.** Diez sitios
la consumen y ninguno sabe qué proveedor hay detrás:

```
modulos/chunker.py:413, 472, 505      modulos/explicador_modelo.py:627
modulos/controles_a_notebook.py:189   modulos/control_evaluacion_data.py:156
modulos/excel_a_notebook.py:539, 572  modulos/revision_codigo.py:507
motor/Mx_03_LlamarIA.py:149
```

Cambiar de proveedor **no debe tocar ninguno de esos diez**. Si te ves editando
`chunker.py` para que funcione con Azure, algo está mal en el cliente.

---

## 3. Paso 1 — Credenciales y `.env`

### Dónde sacar cada dato en Azure AI Foundry

| Variable | Dónde está en el portal |
|---|---|
| `AZURE_OPENAI_ENDPOINT` | *Overview* del recurso → «Endpoint». Formato `https://<recurso>.openai.azure.com/` |
| `AZURE_OPENAI_API_KEY` | *Keys and Endpoint* → KEY 1 o KEY 2 |
| `AZURE_OPENAI_DEPLOYMENT` | *Deployments* → columna **Deployment name** (no «Model name») |
| `AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT` | *Deployments* → un deployment **distinto**, de `text-embedding-3-small` o `ada-002`. Ver §17 |
| `AZURE_OPENAI_API_VERSION` | Ver §5 |

```bash
# .env
IA_PROVEEDOR=azure_openai
AZURE_OPENAI_ENDPOINT=https://mi-recurso.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt4o-virf-prod
AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT=embeddings-virf-prod
AZURE_OPENAI_API_KEY=…
AZURE_OPENAI_API_VERSION=2024-10-21
AZURE_OPENAI_MAX_TOKENS=4096
```

> ⚠️ **Pide DOS deployments a IT, no uno.** El de chat evalúa; el de embeddings
> alimenta el RAG. Es el olvido más caro de esta migración porque no falla al
> arrancar: el agente corre igual, sin contexto regulatorio, y los informes
> salen más pobres sin que nada lo anuncie. Texto para el ticket:
>
> *«Además del deployment de chat necesito uno de embeddings
> (`text-embedding-3-small`) y su nombre de deployment.»*

> ⚠️ **El error nº 1 de toda migración: confundir deployment con modelo.**
> Si tu deployment se llama `gpt4o-virf-prod`, ese es el valor. Poner `gpt-4o`
> produce `DeploymentNotFound (404)` aunque el modelo exista en tu recurso.

`.env` está cubierto por `.gitignore`; verifícalo con
`python validate_project.py --strict`, que además comprueba que no haya claves
reales fuera de ahí.

### Cómo saber qué modelo sirve tu deployment

El nombre no lo dice. Pregúntaselo a la API:

```python
from openai import AzureOpenAI
import os
c = AzureOpenAI(api_key=os.environ["AZURE_OPENAI_API_KEY"],
                api_version=os.environ["AZURE_OPENAI_API_VERSION"],
                azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"])
r = c.chat.completions.create(
        model=os.environ["AZURE_OPENAI_DEPLOYMENT"],
        messages=[{"role": "user", "content": "ping"}],
        max_tokens=5)
print("modelo real:", r.model)          # ej. 'gpt-4o-2024-11-20'
print("finish_reason:", r.choices[0].finish_reason)
print("uso:", r.usage)
```

`r.model` devuelve el modelo **con su fecha de versión**. Ese es el dato que
determina todo lo demás: contexto máximo, parámetros admitidos y precio.

---

## 4. Paso 2 — Azure como default EN EL CÓDIGO

> ### ✅ HECHO
> `config/parametros.py:127` ya declara `azure_openai` como default, y
> `tests/test_estructura_config.py::test_el_default_vive_en_el_codigo_no_en_el_env`
> lo fija leyendo el literal del fuente con AST (no con `importlib.reload`, por
> el motivo que se explica al final de esta sección).
>
> Lo que sigue documenta **por qué** el default vive en el código.

Requisito de gobernanza: la prioridad de Azure no puede depender de que alguien
recuerde poner una variable.

**Estado actual** — `config/parametros.py:~101`:

```python
IA_PROVEEDOR = os.getenv("IA_PROVEEDOR", "anthropic").lower()
```

**Cambio:**

```python
# [POLÍTICA] Azure OpenAI es el proveedor prioritario por decisión de la
# entidad. El DEFAULT vive aquí, en el código, y no en un .env que alguien
# pueda olvidar: si el .env no define IA_PROVEEDOR, la corrida debe salir por
# Azure, no por el proveedor secundario.
# Anthropic se conserva disponible (IA_PROVEEDOR=anthropic) pero no es el
# camino por defecto.
IA_PROVEEDOR = os.getenv("IA_PROVEEDOR", "azure_openai").lower()
```

**Test que lo fija** (añádelo a `tests/test_regresion.py`):

```python
def test_azure_es_el_proveedor_por_defecto(monkeypatch):
    """La prioridad de Azure debe estar en el código, no en el .env."""
    monkeypatch.delenv("IA_PROVEEDOR", raising=False)
    import importlib, config.parametros as p
    importlib.reload(p)
    assert p.IA_PROVEEDOR == "azure_openai"
```

> Ojo con `importlib.reload` en tests: `config/parametros.py` ejecuta
> `load_dotenv()` al importarse, así que si tu `.env` define `IA_PROVEEDOR` el
> test verá ese valor. Usa `monkeypatch.setenv` explícito o lee el literal del
> fuente con AST.

---

## 5. Paso 3 — `api_version`

> ### ✅ HECHO
> El default ya es **`2024-10-21`** (GA estable) en `config/parametros.py:172`.
> La tabla de abajo sigue siendo útil para decidir si tu deployment necesita
> otra versión.

El default del proyecto **era** `2024-02-15-preview`.
Estaba desactualizado y es la causa más común de errores desconcertantes: una
versión antigua **rechaza parámetros que el modelo sí soporta**.

Recomendación práctica:

| Si usas | Usa al menos |
|---|---|
| GPT-4 / GPT-4-turbo / GPT-4o | `2024-10-21` (GA estable) |
| Modelos de razonamiento (o1, o3, GPT-5) | la `preview` más reciente que documente tu recurso |

Las versiones GA son estables; las `preview` cambian sin aviso. Para un sistema
de auditoría regulatoria, **prefiere GA** salvo que necesites una capacidad que
solo exista en preview: una respuesta que cambia de forma entre corridas rompe
la reproducibilidad, que es el invariante 5 del proyecto.

**Cámbialo en `config/parametros.py`, no en el `.env`:**

```python
# GA estable. Una 'preview' puede cambiar de comportamiento sin aviso, y este
# sistema exige corridas reproducibles (ver METODOLOGIA_DEL_AGENTE.md §11.5).
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
```

---

## 6. Paso 4 — `max_tokens` vs `max_completion_tokens`

> ### ✅ HECHO
> `config/ia.py` **negocia** el parámetro: intenta `max_tokens`, y si el
> servidor lo rechaza reintenta con `max_completion_tokens`, memorizando el que
> funcionó (`self._param_tokens`) para no pagar el reintento en cada una de las
> ~40 llamadas del chunker. Cubierto por
> `TestNegociacionDelParametroDeTokens` (4 tests).
>
> El código de abajo es el que se implementó; se conserva por su razonamiento.

**Este era el que rompía el cliente con modelos nuevos.** El cliente enviaba siempre `max_tokens`:

```python
response = self.cliente.chat.completions.create(
    model=self.deployment,
    max_tokens=tokens,          # ← falla en o1/o3/GPT-5
    messages=[…],
)
```

Los modelos de razonamiento **rechazan `max_tokens`** con
`400 Unsupported parameter: 'max_tokens' is not supported with this model. Use
'max_completion_tokens' instead.`

### Solución robusta: negociar el parámetro, no adivinarlo

No detectes el modelo por su nombre (`"gpt-5" in deployment`) — el deployment
puede llamarse como quieras y esa heurística fallará. Intenta y adapta:

```python
def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                    sistema=None) -> str:
    sys_prompt = sistema or instruccion_sistema or "Eres un auditor experto."
    tokens = max_tokens or self.max_tokens_default
    mensajes = [{"role": "system", "content": sys_prompt},
                {"role": "user",   "content": prompt}]

    # [AZURE] El nombre del parámetro de límite depende de la FAMILIA del
    # modelo, no del nombre del deployment: los modelos de razonamiento
    # (o1/o3/GPT-5) rechazan `max_tokens` y exigen `max_completion_tokens`.
    # Detectarlo por el nombre del deployment no sirve —lo elige el usuario—
    # así que se negocia: se intenta el moderno y se cae al clásico si el
    # servidor lo rechaza. El resultado se memoriza para no pagar el reintento
    # en cada una de las ~40 llamadas del chunker.
    intentos = ([self._param_tokens] if self._param_tokens
                else ["max_completion_tokens", "max_tokens"])
    ultimo_error = None
    for nombre_param in intentos:
        try:
            response = self.cliente.chat.completions.create(
                model=self.deployment, messages=mensajes,
                **{nombre_param: tokens})
            self._param_tokens = nombre_param      # memoriza el que funcionó
            break
        except Exception as e:
            ultimo_error = e
            if "max_tokens" in str(e) or "max_completion_tokens" in str(e):
                continue                            # parámetro no soportado
            raise RuntimeError(f"❌ Error Azure OpenAI: {e}") from e
    else:
        raise RuntimeError(
            f"❌ Azure OpenAI rechazó ambos parámetros de límite de tokens. "
            f"Último error: {ultimo_error}") from ultimo_error
    …
```

Inicializa `self._param_tokens = None` en `__init__`.

> **Por qué negociar y no configurar:** una variable `AZURE_PARAM_TOKENS` en el
> `.env` sería una cosa más que el operador puede poner mal, y el síntoma —un
> `400` a mitad del chunking, con la extracción ya pagada— es caro. La
> negociación se resuelve sola en la primera llamada.

---

## 7. Paso 5 — `temperature`

Los modelos de razonamiento **ignoran o rechazan** `temperature ≠ 1`.

> ### ✅ HECHO — y la afirmación original ya no aplica
> Esta sección decía que `motor/Mx_03_LlamarIA.py` enviaba `temperature`. Ese
> código era una **ruta paralela muerta** que se eliminó: hoy `grep -n
> temperature motor/Mx_03_LlamarIA.py` devuelve **cero** resultados.
>
> Ningún punto del proyecto envía `temperature`. El catálogo registra si cada
> modelo la admite (`PerfilModelo.admite_temperature`) y el cliente lo memoriza
> al detectar el modelo, de modo que si algún día se envía, se hará solo cuando
> el modelo la acepte.

Ni `config/ia.py` ni ningún módulo de negocio envían `temperature`, así que este
frente está cerrado por construcción.

**Recomendación para este proyecto: `temperature=0`** en todo lo que alimente un
dictamen. Es un sistema de auditoría: dos corridas sobre la misma evidencia
deben dar el mismo resultado. Si tu modelo la rechaza y fuerza 1, **documéntalo
en el README** como limitación de reproducibilidad — no lo dejes implícito,
porque afecta al invariante 5.

---

## 8. Paso 6 — JSON nativo

> ### ✅ HECHO
> `generar_mensaje(..., formato_json=True)` activa
> `response_format={"type":"json_object"}` en el cliente Azure, y el de
> Anthropic lo acepta e ignora. La firma abstracta de `ClienteIA` ya lo declara.
> Cubierto por `test_formato_json_activa_response_format`.
>
> **`_parsear_json` y `_extraer_json` se conservan**, como recomienda esta
> sección: son la red del proveedor secundario.

Aquí Azure OpenAI es **mejor** que Anthropic para este proyecto, y conviene
aprovecharlo.

`response_format={"type": "json_object"}` garantiza JSON sintácticamente válido.
Elimina de raíz toda la familia de fallos que este proyecto ya sufrió: modelos
que envuelven el JSON en ```` ```json ````, que añaden una frase explicativa
antes, o que emiten dos objetos seguidos.

`motor/Mx_03_LlamarIA.py:276` **ya lo usa**. `config/ia.py` **no**.

### Cómo integrarlo sin romper la interfaz

`generar_mensaje` devuelve `str` y diez sitios dependen de eso. No cambies la
firma; añade un parámetro opcional:

```python
def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                    sistema=None, formato_json=False) -> str:
    …
    extra = {}
    if formato_json:
        # [AZURE] Garantiza JSON sintácticamente válido en el servidor. Elimina
        # los fallos de parseo por markdown fences, prosa previa u objetos
        # concatenados que el proyecto ya ha sufrido (ver el AUDIT-FIX de
        # Mx_03._parsear_json). Anthropic no ofrece equivalente, así que el
        # parser robusto se conserva: es la red de seguridad del secundario.
        extra["response_format"] = {"type": "json_object"}
```

Y añádelo a la firma abstracta de `ClienteIA` con `formato_json=False` para que
el cliente de Anthropic lo acepte e ignore.

> **No elimines `_parsear_json` ni `_extraer_json`.** Siguen siendo necesarios
> para Anthropic, y `json_object` garantiza JSON *válido*, no que **cumpla tu
> contrato**: `_validar_contrato()` sigue siendo imprescindible.
>
> Y un detalle de la API: con `json_object`, el prompt **debe** mencionar la
> palabra «JSON» o la petición falla. Los prompts de
> `Mx_02_EstructuraPrompt.py` ya lo hacen.

---

## 9. Paso 7 — Filtro de contenido

Azure aplica filtros de contenido que Anthropic no tiene. Un manual metodológico
sobre riesgo de crédito puede disparar categorías inesperadas.

Manifestaciones:

| Síntoma | Causa |
|---|---|
| `choices == []` | La petición fue bloqueada en entrada |
| `finish_reason == "content_filter"` | La respuesta fue bloqueada en salida |
| `message.content is None` | Igual que el anterior |
| `400 content_filter` con `content_filter_result` | Bloqueo con detalle de categoría |

`config/ia.py:~250` **ya cubre los tres primeros** y lanza `RuntimeError` con
mensaje explicativo. Verifícalo antes de añadir nada.

**Lo que falta y sí importa aquí:** que un bloqueo de filtro **no se confunda con
una falta de evidencia**. Es el invariante 3 del proyecto —«ausencia y fallo
técnico son cosas distintas, con responsables opuestos»— y un `content_filter`
es un fallo técnico del agente, nunca una falta del validado. Debe llegar al
informe como `evaluacion_valida=False`, no como `sin_evidencia=True`.

---

## 10. Paso 8 — Cuotas y rate limits

> ### ✅ HECHO
> `config/ia.py:_con_reintento()` reintenta ante `429`/`503`, respeta el
> `Retry-After` del servidor y aplica backoff exponencial con jitter acotado a
> 60 s. Está **enchufado** a `generar_mensaje` del cliente Azure y lee
> `REINTENTOS_API` de `config/parametros.py`.
>
> Detalle que importa: un `401` o un `404` **no** gastan reintentos — solo se
> reintenta lo que puede cambiar por sí solo. Cubierto por
> `TestReintentoAnteCuotaAgotada` (8 tests).
>
> ⚠️ Sigue siendo tuyo el **paso 1**: subir el TPM del deployment en el portal
> antes de la primera corrida grande. Eso no se puede automatizar desde aquí.

Diferencia estructural: la cuota de Azure es **por deployment**, medida en
*tokens por minuto* (TPM) y *peticiones por minuto* (RPM), y la fijas tú al
desplegar. La de Anthropic es por organización y más generosa por defecto.

**Por qué importa en este proyecto concreto:** el chunker hace hasta
**40 llamadas secuenciales** para un manual de 1,3 M de caracteres
(`VIRF_MAX_CHUNKS=40`), más la consolidación jerárquica. Con un deployment de
TPM bajo, eso es un `429` garantizado a mitad del proceso.

### Qué hacer

1. **Sube el TPM del deployment** en el portal antes de la primera corrida
   grande. Es gratis: la cuota es un reparto de tu cupo regional, no un cargo.
2. **Reintento con espera exponencial** ante `429`, respetando el header
   `Retry-After` que Azure envía.
3. **No confundas `429` con fallo del modelo.** Un rate limit agotado tras los
   reintentos es un fallo técnico → `evaluacion_valida=False`. Nunca 0.0.

```python
import time, random

def _con_reintento(self, fn, intentos=5):
    """
    Reintento con espera exponencial ante 429/503.

    [AZURE] La cuota es por DEPLOYMENT (TPM/RPM), no por organización. El
    chunker hace ~40 llamadas seguidas, así que el 429 no es excepcional: es
    lo esperable con un deployment de TPM modesto.

    No es un fallback a otro proveedor —la política lo prohíbe—: es reintentar
    contra el MISMO proveedor, que es lo que la propia API pide con Retry-After.
    """
    for i in range(intentos):
        try:
            return fn()
        except Exception as e:
            transitorio = any(x in str(e) for x in ("429", "503", "rate limit",
                                                    "Too Many Requests"))
            if not transitorio or i == intentos - 1:
                raise
            espera = getattr(e, "retry_after", None) or (2 ** i + random.random())
            print(f"  ⏳ Azure {type(e).__name__}: reintento {i+1}/{intentos} "
                  f"en {espera:.1f}s")
            time.sleep(espera)
```

> El proyecto ya tiene `REINTENTOS_API=3` en `config/parametros.py`. Úsalo en
> lugar de un literal.

---

## 11. Paso 9 — Recalibrar el chunking

> ### ℹ️ AHORA AUTOMÁTICO
> `config/modelos.py` deriva `max_ctx`, `chunk_size`, `max_chunks` y
> `presupuesto_doc` **del contexto real del modelo que sirva el deployment**,
> detectado en la primera llamada. Con GPT-4 clásico (8K) el presupuesto baja
> solo; con GPT-4o (128K) sube. No hay que tocar nada.
>
> Lo que **sí** conviene hacer con la credencial en mano: medir la relación
> chars/token sobre TU documentación (el fragmento de `tiktoken` de abajo) y,
> si difiere mucho de 2,4, ajustar `CHARS_POR_TOKEN_ES` en `config/modelos.py`.
> Es un único valor y está en un solo sitio.

**El paso que más fácil se olvidaba y más caro salía.**

El chunking está dimensionado para Claude con una medición concreta:
**2,48 caracteres por token** para español técnico, obtenida con el
`count_tokens` de Anthropic. Los valores actuales:

| Parámetro | Valor | Origen |
|---|---:|---|
| `VIRF_CHUNK_SIZE` | 12.000 | segmento inicial |
| `VIRF_CHUNK_SIZE_MAX` | 40.000 | tope del segmento adaptativo |
| `VIRF_MAX_CHUNKS` | 40 | tope de llamadas · ⚠️ **no bajar de 34** |
| `VIRF_MAX_CTX` | 15.000 | presupuesto de contexto por prompt |
| `VIRF_PRESUPUESTO_DOC` | 9.000 | resumen final por documento |

### Cómo recalibrar correctamente

**Mide, no estimes.** Con `tiktoken` sobre tu evidencia real:

```python
import tiktoken, pathlib
# o200k_base → modelos recientes (GPT-4o y posteriores)
# cl100k_base → GPT-4 / GPT-4-turbo / GPT-3.5
enc = tiktoken.get_encoding("o200k_base")
texto = pathlib.Path("inputs/documentacion/modelamiento/manual.md").read_text(encoding="utf-8")
ratio = len(texto) / len(enc.encode(texto))
print(f"caracteres por token: {ratio:.2f}")
```

Hazlo sobre **tu** documentación en español, no sobre un texto en inglés: la
diferencia entre idiomas es grande y el proyecto ya se equivocó una vez
asumiendo 3,3 cuando el valor real era 2,48 — un error del 33 % en el
presupuesto, que se tradujo en una cifra de coste equivocada en el README.

Después, ajusta con el contexto real del modelo:

| Modelo | Contexto | Nota |
|---|---:|---|
| GPT-4 (clásico) | 8K / 32K | **más pequeño que Claude**: hay que BAJAR los valores |
| GPT-4-turbo / GPT-4o | 128K | margen para subir |
| Familia GPT-5 / razonamiento | mucho mayor | ver la ficha del modelo en tu recurso |

> ⚠️ **Si tu deployment es GPT-4 clásico (8K), los valores actuales no caben.**
> `VIRF_MAX_CTX=15.000` caracteres ≈ 6.000 tokens de prompt más el sistema y la
> respuesta: te acercas al límite y verás truncados o errores. Baja
> `VIRF_MAX_CTX` y `VIRF_CHUNK_SIZE` proporcionalmente.

### La decisión de calidad: ¿subir el chunk size?

Con 128K de contexto, la tentación es subir `CHUNK_SIZE` para hacer menos
llamadas. **Criterio recomendado: sube, pero con moderación.**

- **A favor:** menos llamadas, menos coste, menos superficie de `429`.
- **En contra:** un resumen de 100K caracteres en una sola pasada pierde detalle
  frente a cuatro de 25K. Este proyecto valida documentación: los hallazgos
  concretos —«el manual declara Kupiec pero no aporta p-valores»— viven en el
  detalle. Un segmento demasiado grande produce resúmenes genéricos, que es
  exactamente el fallo de calidad contra el que hay que protegerse.

Sugerencia: **duplica** `CHUNK_SIZE` a ~24.000 y `CHUNK_SIZE_MAX` a ~80.000, y
**mide la calidad** comparando hallazgos antes y después sobre el mismo
documento. Si los hallazgos se vuelven genéricos, has subido demasiado.

**Y después de tocar cualquiera de estos valores:**

```bash
python agente.py --limpiar-cache
```

La clave del caché de resúmenes incluye la configuración del chunker, así que
técnicamente se invalida sola — pero el caché de **documentos** no, y el
proyecto ya emitió informes sobre el 1,2 % de un manual por una interacción mal
resuelta entre caché y presupuesto. Limpiar es barato; el fallo no.

---

## 12. Paso 10 — Acoplamiento residual

> ### ✅ HECHO — los tres hallazgos están corregidos
> Verificado ejecutando el 30/07/2026, después de aplicarlos:
>
> | Hallazgo | Estado |
> |---|---|
> | a) `API_URL` de Anthropic en `Mx_00` | ✅ **eliminado** — solo queda el comentario que explica por qué |
> | b) `choices[0]` en `Mx_03` | ✅ **eliminado** — era código muerto que nadie llamaba |
> | c) `console.anthropic.com` en `agente.py` | ✅ **eliminado** — `grep -c` devuelve **0**; los mensajes derivan del proveedor activo vía `config.ia.metadatos_proveedor()` |
>
> El test que lo fija existe y pasa:
> `tests/test_estructura_config.py::test_el_negocio_no_toca_el_sdk`.
> Además, `TestNeutralidadDeProveedor` (10 tests) impide que vuelva a filtrarse
> el nombre de una marca al código de negocio.
>
> Lo que sigue documenta cada hallazgo tal como se encontró.

Auditado el 30/07/2026. **Tres hallazgos**, todos fuera de `config/`, **ya corregidos**:

### a) URL de Anthropic hardcodeada — `motor/Mx_00_CargaRutas.py:40`

```python
API_URL = "https://api.anthropic.com/v1/messages"
```

Un endpoint de proveedor en un módulo de rutas. Comprueba quién lo usa: si nadie
—los clientes del SDK construyen su propia URL—, **elimínalo**. Si algo lo usa,
muévelo a `config/ia.py` junto al cliente que le corresponde.

### b) Forma del SDK de OpenAI en un módulo de negocio — `motor/Mx_03_LlamarIA.py:281`

```python
texto_respuesta = response.choices[0].message.content
```

Es una ruta paralela que instancia su propio cliente y accede a la forma cruda de
la respuesta, saltándose `ClienteIA`. Curiosamente ya es código de OpenAI, pero
está en el lado equivocado de la frontera: si mañana cambia el SDK, hay que
tocar un módulo de negocio.

**Corrección:** que esa función use `get_cliente_ia().generar_mensaje(...,
formato_json=True)` y deje el acceso al SDK dentro de `config/ia.py`.

### c) URLs de la consola de Anthropic en mensajes de usuario — `agente.py:110, 304`

```
https://console.anthropic.com/
```

Cosmético pero desorientador: con Azure activo, el mensaje de error manda al
usuario al portal equivocado. Hazlo dependiente del proveedor.

### Cómo comprobar que no vuelve

```bash
grep -rnE "\.content\[0\]|choices\[0\]|import anthropic|from openai" \
     --include=*.py modulos/ motor/ src/ agente.py
```

Debe devolver **cero** resultados. Conviértelo en un test:

```python
def test_ningun_modulo_de_negocio_toca_el_sdk():
    """El acoplamiento al SDK vive SOLO en config/ia.py."""
    import re
    from pathlib import Path
    raiz = Path(__file__).resolve().parents[1]
    patron = re.compile(r"\.content\[0\]|choices\[0\]|^\s*(import anthropic|from openai)",
                        re.M)
    fugas = []
    for carpeta in ("modulos", "motor", "src"):
        for f in (raiz / carpeta).rglob("*.py"):
            vivas = "\n".join(l for l in f.read_text(encoding="utf-8").splitlines()
                              if not l.lstrip().startswith("#"))
            if patron.search(vivas):
                fugas.append(str(f.relative_to(raiz)))
    assert not fugas, f"acoplamiento al SDK fuera de config/: {fugas}"
```

---

## 13. Paso 11 — Política de NO fallback

> ### ✅ HECHO
> Verificado por partida doble:
> `tests/test_estructura_config.py::test_no_hay_fallback_automatico_entre_proveedores`
> y `test_azure_mocks.py::test_el_fallo_de_azure_NO_cae_a_anthropic`, que espía
> el constructor de `ClienteAnthropicIA` durante una corrida con Azure activo y
> confirma que **no se instancia ni una vez**.

Decisión de gobernanza: si Azure falla, el sistema **reporta y se detiene**.
Nunca cambia de proveedor solo.

**Por qué es correcto y no una limitación:** un informe de validación debe poder
declarar con qué modelo se emitió. Si el sistema cambiara de proveedor a mitad de
corrida, el informe tendría evaluaciones de dos modelos distintos bajo una sola
huella de ejecución, y la reproducibilidad —invariante 5— sería falsa.

### Qué comprobar

```bash
# No debe existir ningún cambio de proveedor en tiempo de ejecución
grep -rn "FABRICAS\[" --include=*.py . | grep -v config/
# → cero resultados: solo config/ia.py:336 debe indexar FABRICAS
```

Y un test que fije la política:

```python
def test_no_hay_fallback_entre_proveedores():
    """
    Política de la entidad: un proveedor por corrida. Si Azure falla, se
    reporta y se detiene — nunca se reintenta contra Anthropic, porque un
    informe con evaluaciones de dos modelos bajo una sola huella de ejecución
    haría falsa la reproducibilidad que el informe declara.
    """
    from pathlib import Path
    src = (Path(__file__).resolve().parents[1] / "config" / "ia.py").read_text(encoding="utf-8")
    vivas = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
    # get_cliente_ia resuelve UN proveedor y no itera sobre las fábricas
    assert "for proveedor in FABRICAS" not in vivas
    assert vivas.count("FABRICAS[proveedor]()") == 1
```

**Distinción importante:** reintentar ante un `429` contra el **mismo** proveedor
(§10) **no es** un fallback. Es lo que la propia API pide con `Retry-After`. El
fallback prohibido es cambiar de proveedor.

---

## 14. Verificación

> ### ℹ️ EL PASO 14.2 y 14.3 SE FUSIONARON EN UN COMANDO
> Cuando esta guía se escribió, confirmar el modelo exigía pegar un fragmento de
> Python a mano. Ya no:
>
> ```bash
> python agente.py --verificar-conexion-azure
> ```
>
> Hace **una** llamada mínima y responde a las cuatro preguntas de golpe:
> ¿vale la credencial?, ¿qué modelo sirve el deployment?, ¿con qué perfil de
> chunking se va a trabajar?, ¿se parsea su JSON? Sale con código 1 y dice qué
> variable revisar si algo falla.
>
> **Ese es el único comando que necesitas.** Lo demás de esta sección es
> verificación adicional para quien quiera profundizar.

Guion de aceptación. Ejecútalo en orden; cada paso supone el anterior.

### 14.1 — Coste cero, sin llamar a la API

```bash
python validate_project.py --strict     # debe dar 131/131
python -m pytest -q                     # debe dar 473 passed
python -c "from config import get_cliente_ia, IA_PROVEEDOR; print(IA_PROVEEDOR)"
# → azure_openai
```

### 14.2 — Primera llamada real

```bash
VIRF_VALIDAR_CONEXION=1 python agente.py --cache-stats
```

Debe imprimir `✅ Cliente IA listo: azure_openai (<deployment>) — conexión verificada`.

### 14.3 — Confirmar el modelo y sus parámetros

Ejecuta el fragmento de §3 y anota: `r.model`, `finish_reason`, `usage`. Con eso
decides `api_version`, el parámetro de tokens y si `temperature` es admisible.

### 14.4 — Chunking sobre el documento grande

```bash
python agente.py --explicar-modelo "LaR" --dry-run   # inventario y coste, sin gastar
python agente.py --titulo "Test Azure" --tier 4      # tier 4 = menos actividades
```

Verifica en la salida: **cobertura 100 %**, ningún `429` sin reintentar, ningún
`content_filter`.

### 14.5 — Contrato JSON con la forma real de Azure

> ✅ Las tres variantes (limpio, con *fences*, con prosa alrededor) ya están
> cubiertas con mocks en `TestParseoDeLasTresVariantesDeAzure`, y la corrida
> end-to-end simulada las rotó durante 34 llamadas con **0 fallos de parseo**.
> Lo que sigue es para contrastar con respuestas REALES de tu deployment, que
> pueden tener formas que el mock no anticipó.

Esto es lo que pide comprobación empírica, porque el parser lleva un
`AUDIT-FIX` motivado por respuestas mal formadas:

```python
from modulos.motor_ia import _extraer_json
# Guarda respuestas REALES de Azure y compruébalas
for muestra in respuestas_reales_guardadas:
    _extraer_json(muestra)     # no debe lanzar
```

Y fija tests con las formas que Azure produzca de verdad — con y sin
```` ```json ````, con prosa previa, con objetos concatenados.

### 14.6 — Cadena completa de extremo a extremo

```bash
# El paso --prdc se lanza desde la web (firma = identidad de la sesión; SEG-02).
# Desde la consola, una corrida de trabajo sin firma:
python agente.py --titulo "Test Azure" --tier 1
python agente.py --verificar-cadena "Test Azure"
python agente.py --verificar-evidencia outputs/<fecha>/resultados_Test_Azure_<fecha>.json
```

### 14.7 — Comparación de calidad

**El paso que no se puede automatizar.** Coge el mismo modelo evaluado antes con
Claude y compara los hallazgos:

- ¿Cita evidencia **concreta y localizable**, o generalidades?
- ¿Distingue «el manual lo declara» de «el manual lo demuestra con cifras»?
- ¿Los `puntaje` están **justificados** en la observación?

Si los hallazgos son más genéricos que con Claude, ajusta los prompts de
`Mx_02_EstructuraPrompt.py`. Los modelos de OpenAI suelen responder mejor a
instrucciones **explícitamente numeradas** y a un ejemplo del formato esperado;
Claude tolera mejor la instrucción en prosa.

---

## 15. Tabla de traducción

| Concepto | Anthropic | Azure OpenAI |
|---|---|---|
| SDK | `anthropic` | `openai` (clase `AzureOpenAI`) |
| Autenticación | `ANTHROPIC_API_KEY` | `api_key` + `azure_endpoint` + `api_version` |
| Identificador del modelo | nombre del modelo | **nombre del deployment** |
| Llamada | `client.messages.create(...)` | `client.chat.completions.create(...)` |
| Prompt de sistema | parámetro `system=` | primer mensaje `role="system"` |
| Límite de salida | `max_tokens` | `max_tokens` o `max_completion_tokens` |
| Texto de la respuesta | `resp.content[0].text` | `resp.choices[0].message.content` |
| Motivo de parada | `resp.stop_reason` | `resp.choices[0].finish_reason` |
| Uso de tokens | `resp.usage.input_tokens` | `resp.usage.prompt_tokens` |
| JSON garantizado | no nativo | `response_format={"type":"json_object"}` |
| Contar tokens | `client.messages.count_tokens()` | `tiktoken` (local) |
| Filtro de contenido | no | sí, configurable en el portal |
| Cuota | por organización | **por deployment** (TPM/RPM) |

---

## 16. Diagnóstico de errores

| Error | Causa | Solución |
|---|---|---|
| `DeploymentNotFound` (404) | Pusiste el nombre del **modelo** en vez del **deployment** | §3 |
| `Unrecognized request argument` (400) | `api_version` antigua para un parámetro nuevo | §5 |
| `Unsupported parameter: 'max_tokens'` | Modelo de razonamiento | §6 |
| `temperature does not support 0` | Modelo de razonamiento | §7 |
| `choices=[]` o `content=None` | Filtro de contenido | §9 |
| `429 Too Many Requests` | TPM/RPM del deployment agotado | §10 |
| `401` con clave correcta | Clave de otro recurso, o endpoint con región distinta | Verifica que clave y endpoint sean del **mismo** recurso |
| `InvalidRequestError: maximum context length` | Chunking dimensionado para un contexto mayor | §11 |
| JSON inválido tras `json_object` | El prompt no menciona «JSON» | §8 |
| Respuestas correctas pero hallazgos genéricos | Estilo de prompt | §14.7 |

---

## 17. Paso 12 — El RAG: embeddings y reconstrucción del índice

> **Añadido el 31/07/2026.** Esta sección faltaba, y era la omisión más grave de
> la guía: migraba el proveedor de chat y no decía que el índice vectorial queda
> **inservible**. Sin ella la migración parece completa y el RAG está mudo.

### 17.1 Por qué el índice actual no vale

El RAG convierte texto en vectores. Hasta el 30/07/2026 lo hacía un modelo
local descargado de HuggingFace (`paraphrase-multilingual-MiniLM-L12-v2`, 458 MB).
Esa vía se **eliminó del código** —no se desactivó— por la política de modelos
externos, y porque en una red con inspección TLS fallaba con
`CERTIFICATE_VERIFY_FAILED`.

El problema es que los vectores ya persistidos siguen ahí, y **no son
compatibles**:

| Motor | Dimensiones |
|---|---|
| MiniLM (retirado) | **384** |
| `text-embedding-3-small` (Azure) | **1536** |

Consultar un índice de 384 con vectores de 1536 no degrada la calidad: **falla**.
Son espacios distintos.

### 17.2 Qué hacer, una sola vez

```bash
# 1. Confirma que el deployment de embeddings existe y responde
python -c "from config.embeddings import get_embedding_function; \
           print(len(get_embedding_function()(['prueba'])[0]), 'dimensiones')"
# → 1536

# 2. Reconstruye los cuatro dominios. --force borra el índice de 384
python scripts/rebuild_rag_databricks.py --dominio all --force

# 3. Comprueba
python scripts/rebuild_rag_databricks.py --status
```

> El paso 2 **cuesta dinero**: son llamadas de embeddings sobre toda la
> literatura de `inputs/rag/`. Es barato (los embeddings valen una fracción del
> chat) y se paga una vez, no en cada corrida.

### 17.3 Si el job corre en Databricks

Cambia las dependencias del cluster: **`%pip install chromadb openai`**.
Ya **no** lleva `sentence-transformers`. Y necesita las credenciales
`AZURE_OPENAI_*` como secretos del cluster — antes no las necesitaba, porque
generaba los vectores en local.

### 17.4 Qué NO se indexa, y por qué importa al migrar

El RAG indexa **solo** `inputs/rag/<dominio>/` — literatura de referencia
(FRTB, Kupiec, Basilea, SR 11-7). **No** indexa la evidencia del modelo que se
valida, deliberadamente: al hacerlo, consultar el índice de VaR sobre
backtesting FRTB devolvía el manual de LaR con similitud 0,88, y el agente
acababa citando el propio manual como referencia autorizada que lo confirma.
Se daba la razón a sí mismo.

Si al migrar te tienta «aprovechar y meter todo en el índice», ese es el motivo
de que no esté. Está documentado en `src/rag/base_indexer.py:fuentes_rag()`.

### 17.5 Sin deployment de embeddings

El agente **funciona igual**, sin contexto regulatorio: `BaseRetriever.query()`
degrada a lista vacía. Es el fallo correcto —mejor sin contexto que con
contexto ajeno— pero es una degradación silenciosa de la calidad del informe,
no un error. Si el §14 pasa pero los hallazgos citan menos normativa de lo
habitual, mira aquí primero.

---

## 18. Paso 13 — Fallos de transporte y de arranque

> **Añadido el 31/07/2026**, tras una corrida real en red corporativa.

### 18.1 `Cannot send a request, as the client has been closed`

El SDK de OpenAI **toma posesión** del `http_client` que le pasas. Verificado:

```python
h = httpx.Client(); cli = AzureOpenAI(..., http_client=h)
cli.close()
assert h.is_closed          # True
```

Como la función de embeddings es un **singleton de proceso**, sobrevive a ese
cierre: el índice queda muerto el resto de la corrida y el síntoma es «RAG no
disponible», que no dice nada de la causa.

Ya está resuelto: los clientes de chat y de embeddings comprueban
`is_closed` y se reconstruyen solos. No requiere acción tuya — pero si ves el
aviso `El cliente HTTP … estaba cerrado; se reconstruye`, eso es lo que pasó.

### 18.2 `validar_conexion()` con modelos de razonamiento

Si IT te da un deployment de la familia **o1 / o3 / gpt-5**, la validación de
conexión fallaba con un error de la API que se lee como «la credencial está
mal» — porque tenía `max_tokens` fijo, y esos modelos exigen
`max_completion_tokens`.

Corregido el 31/07/2026: `validar_conexion()` negocia el parámetro igual que
`generar_mensaje()`, y lo memoriza para que la primera llamada real no repita
la negociación. **Importa saberlo porque falla en el peor momento**: el primer
arranque tras recibir las credenciales, cuando no sabes si el problema es la
clave, el endpoint, el proxy o el deployment.

### 18.3 Certificados corporativos

Si aparece `CERTIFICATE_VERIFY_FAILED` **contra tu endpoint de Azure** (no
contra un dominio público: eso ya no puede pasar, §17.1), la solución **no** es
`verify=False`. Apunta `VIRF_CA_BUNDLE` al `.crt` de la CA interna que te
entregue IT: no desactiva la validación, la hace contra la autoridad correcta.

---

## Antes de dar la migración por buena

Cinco comprobaciones que un auditor pedirá, y que corresponden a invariantes
documentados en `METODOLOGIA_DEL_AGENTE.md` §11:

1. **`validate_project.py --strict` en verde** — 129 checks de coste cero.
2. **La huella de ejecución declara el proveedor y el modelo reales.**
   Verifícalo en el JSON: `agente.modelo_ia` y `agente.proveedor_ia` deben decir
   Azure y el modelo confirmado en §3, no valores heredados de Claude.
3. **Sin evidencia sigue puntuando 0.0 y el fallo técnico sigue excluido.** Un
   `content_filter` o un `429` agotado son fallos **del agente**, nunca faltas
   del validado.
4. **La cobertura documental sigue siendo real.** Si recalibraste el chunking,
   confirma en una corrida que sigue declarando 100 % cuando lo alcanza —y menos
   cuando no.
5. **README actualizado** con el modelo activo, la `api_version`, la política de
   no fallback y los valores de chunking recalibrados con su medición.

---

## Resumen de estado

| § | Paso | Estado |
|---|---|---|
| 3 | Credenciales y `.env` | ⚠️ **tuyo** — las entrega IT |
| 4 | Azure como default en el código | ✅ hecho |
| 5 | `api_version` | ✅ hecho (`2024-10-21` GA) |
| 6 | `max_tokens` vs `max_completion_tokens` | ✅ hecho (se negocia) |
| 7 | `temperature` | ✅ no se envía en ningún punto |
| 8 | JSON nativo | ✅ hecho (`formato_json=True`) |
| 9 | Filtro de contenido | ✅ los 3 síntomas cubiertos |
| 10 | Cuotas y `429` | ✅ reintento implementado · ⚠️ subir el TPM es tuyo |
| 11 | Recalibrar el chunking | ℹ️ automático desde `config/modelos.py` |
| 12 | Acoplamiento residual | ✅ los 3 hallazgos corregidos |
| 13 | Política de NO fallback | ✅ verificado por partida doble |
| 14 | Verificación | ✅ `--verificar-conexion-azure` |
| 17 | RAG: embeddings e índice | ⚠️ **tuyo** — falta el deployment y la reconstrucción |
| 18 | Transporte y arranque | ✅ auto-reparación · negociación en `validar_conexion` |

**Lo que queda de tu lado:**

1. Recibir de IT **dos** deployments (chat **y** embeddings) y pegar las
   credenciales en `.env`.
2. Subir el TPM del deployment en el portal (§10).
3. **Reconstruir el índice RAG** — `--dominio all --force` (§17.2). El actual
   es de 384 dimensiones y no sirve.
4. Ejecutar la verificación del §14.
5. La comparación de calidad del §14.7, que no se puede automatizar y sigue
   siendo el juicio de un validador.

> El punto 3 es el que se olvida. No falla al arrancar: el agente corre sin
> contexto regulatorio y los informes salen más pobres sin que nada lo anuncie.

---

*Guía redactada como plan de migración el 30/07/2026 contra VIRF Agent v27.1, y
actualizada el mismo día tras ejecutar los pasos 2-11.*
*Ampliada el 31/07/2026 con los §§17 y 18, tras la auditoría de entorno
corporativo: el §17 cubría un hueco real —la guía migraba el chat y no decía
que el índice RAG queda inservible— y el §18 recoge dos fallos reproducidos.*
*Los §§3-14 se verificaron contra el código; los §§5-11 documentan además el
comportamiento de la API de Azure OpenAI, que debe confirmarse contra tu
deployment concreto con `--verificar-conexion-azure`.*
*El §17 no ha podido verificarse de extremo a extremo: requiere el deployment
de embeddings, que aún no existe. Los comandos y los flags sí están
comprobados contra el código.*
