# Traspaso para el agente corporativo — VIRF

Nota para un agente de IA que vaya a revisar o mejorar este repositorio.
Estado de referencia: commit `be23218` (rama `main`).

## 1. Qué es VIRF

Agente de validación de modelos de riesgo financiero (VaR, LaR, ALM) de la
Gerencia de Validación Interna de Riesgo Financiero. Python + FastAPI.

| Carpeta | Contenido |
|---|---|
| `agente.py`, `motor/` | Pipeline de validación por línea de comandos |
| `modulos/` | Lógica de negocio (motor IA, informes Word, PII, custodia…) |
| `config/` | Parámetros y **selección del proveedor de IA** (`config/ia.py`) |
| `src/rag/` | RAG léxico (BM25 + TF-IDF, sin red ni HuggingFace) |
| `web/` | Web: `routers/` (endpoints), `services/` (lógica), `static/js/app.js` (frontend), `templates/index.html` |
| `tests/` | Suite pytest (~1170 tests) |
| `archivo/`, `codigo_muerto_*` | Código retirado: **no mejorar ni reactivar** |

## 2. Reglas del proyecto (obligatorias)

1. **Entorno:** usar siempre `.venv` (`.venv\Scripts\python.exe`). El Python del
   sistema tiene chromadb/torch/HuggingFace y no debe usarse.
2. **No tocar `.env`.** Solo `.env.example` (plantilla, sin valores reales).
3. **Proveedor de IA:** Azure OpenAI es el principal (`IA_PROVEEDOR=azure_openai`);
   Anthropic es alternativa. La selección de proveedor vive **solo en `config/`**
   (hay tests que lo verifican). Sin plan B automático entre proveedores.
4. **Tests a coste cero:** con mocks, sin llamadas reales a la IA.
   Ejecutar: `.venv\Scripts\python.exe -m pytest -q`.
5. **Sin detección automática:** el modo de ejecución se elige con flags
   explícitos, nunca adivinándolo por heurística.
6. **RAG sin HuggingFace:** nada de embeddings ni vector stores.
7. **No lanzar POSTs a ciegas** contra la web en marcha: escriben en rutas globales.
8. **Salvaguardas:** el texto que sale hacia la IA pasa por `modulos/pii.py`
   (enmascarado) y `modulos/inyeccion.py` (neutralizar instrucciones).
9. Se prefieren **flujos reutilizables** (generadores) a documentos hechos a mano.

## 3. Apartado «Solo Informe» (lo más reciente)

Genera el Informe de Resultados en Word **sin ejecutar el pipeline**: estándar
Excel + observaciones registradas a mano. Pantalla accesible desde «Mis Modelos».

| Archivo | Qué hace |
|---|---|
| `web/services/solo_informe_reglas.py` | Conclusión global (Deficiente/Regular/Aceptable/Satisfactorio). Función pura; los casos ambiguos están documentados y confirmados por el usuario |
| `web/services/solo_informe_service.py` | Lee el estándar (columnas por palabra clave, celdas combinadas, Tier), borrador, imágenes, cumplimiento |
| `web/services/solo_informe_word.py` | Construye el Word (portada BCP, índice con hipervínculos, barrido de controles) |
| `web/services/solo_informe_ia.py` | IA **opcional**: pulir redacción, gráficos de textos largos, redactar desde manuales (BM25 local + citas de página). La calificación nunca pasa por la IA |
| `web/routers/solo_informe.py` | Endpoints `/api/solo-informe/*` |
| `tests/test_solo_informe*.py` | 60 tests con mocks |

Decisiones ya tomadas por el usuario (no reabrir):
- Un «control» es cada actividad (fila) del estándar.
- Una Oportunidad de Mejora no incumple el control y no lleva responsable ni fecha.
- Más de 2 críticas → Deficiente; 1 o 2 → Regular; «Aceptable» nunca lleva críticas.
- El estándar se filtra por el Tier del modelo.

Variables opcionales de la IA del apartado (ver `.env.example`):
`SOLO_INFORME_IA_PROVEEDOR`, `SOLO_INFORME_DEPLOYMENT`, `SOLO_INFORME_MODELO`.

## 4. Cómo usar el grafo de código (`graphify-out/`)

- **`GRAPH_REPORT.md`**: empieza aquí. 313 comunidades con nombre en español
  («Área · Qué hace»), nodos centrales y preguntas sugeridas.
- **`graph.json`**: si tienes `graphify` instalado, consulta sin leer todo:
  - `graphify query "cómo se genera el informe word"`
  - `graphify path "ia_pulir()" "cliente_dedicado()"`
  - `graphify explain "concluir()"`
  - `graphify affected "cliente_dedicado()"` — qué se rompe si lo cambias
- El grafo **no** une el JavaScript con Python (hablan por HTTP): las pantallas
  de `app.js` llaman a `/api/...`, definidos en `web/routers/`.
- Tras cambiar código: `graphify update .` (sin IA, sin coste).
- No hace falta `graphify-out/cache/` ni `.graphify_build_state.json`.

## 5. Antes de proponer un cambio

- Correr la suite completa con `.venv` y confirmar que sigue en verde.
- Respetar las reglas de la sección 2 (sobre todo proveedor en `config/` y tests sin coste).
- Explicar el cambio en español y en lenguaje simple.
