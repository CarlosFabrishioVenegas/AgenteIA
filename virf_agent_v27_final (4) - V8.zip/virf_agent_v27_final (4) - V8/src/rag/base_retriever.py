"""
src/rag/base_retriever.py
════════════════════════════════════════════════════════════════════════════
Clase base para retrievers de todos los dominios RAG.

Desde el 2026-07-31 es un ADAPTADOR sobre `buscador_lexico.py`: la recuperación
es LÉXICA (BM25 + TF-IDF), no vectorial. La firma pública no cambia —`query()` y
`query_para_prompt()` con los mismos argumentos y las mismas claves de salida—
precisamente para que `modulos/motor_ia.py` siga funcionando sin tocar una línea.

Lo único que cambió de semántica es `score`, y conviene saberlo al leer un
informe: antes era una similitud coseno ABSOLUTA en [0,1]; ahora es una
relevancia léxica RELATIVA a la consulta (el mejor chunk saca 1.0 por
construcción). `min_score` sigue filtrando, pero filtra «a menos del X% de lo
mejor que hay» en vez de «se parece menos de un X%». El detalle completo, en
`BuscadorLexico.buscar`.

Uso:
    retriever = LaRRetriever()
    resultados = retriever.query("¿Se realizaron pruebas Kupiec?", top_k=5)
"""

from __future__ import annotations

import logging
from abc import ABC
from typing import Any, Dict, List, Optional

logger = logging.getLogger("virf.rag")

__all__ = ["BaseRetriever"]


class BaseRetriever(ABC):
    """
    Retriever base para un dominio RAG.

    Subclases deben definir:
        - dominio: str (debe coincidir con el indexer del mismo dominio)
    """

    dominio: str = "base"

    def __init__(self, autoconstruir: bool = True):
        self._buscador = None
        self._autoconstruir = autoconstruir

    def _get_buscador(self):
        """Buscador léxico del dominio (lazy, compartido en el proceso)."""
        if self._buscador is None:
            from src.rag.buscador_lexico import get_buscador
            self._buscador = get_buscador(self.dominio,
                                          autoconstruir=self._autoconstruir)
        return self._buscador

    def query(
        self,
        texto_consulta: str,
        top_k: int = 5,
        filtro_fuente: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Recupera los chunks más relevantes para la consulta.

        Args:
            texto_consulta: Pregunta o actividad a evaluar.
            top_k:          Número de chunks a retornar.
            filtro_fuente:  Si se especifica, filtra por nombre de archivo fuente.

        Returns:
            Lista de dicts con keys: 'texto', 'fuente', 'dominio', 'chunk',
            'score' (+ el desglose 'score_bm25' / 'score_tfidf' que añade el
            buscador léxico y que el informe puede ignorar sin problema).

            Lista vacía si no hay índice o la consulta no casa con nada. NUNCA
            lanza: el RAG enriquece el prompt, y su fallo no puede tumbar una
            validación en curso.
        """
        try:
            return self._get_buscador().buscar(
                texto_consulta, top_k=top_k, filtro_fuente=filtro_fuente)
        except Exception as exc:
            logger.warning("[%s] RAG no disponible: %s. Devolviendo vacío.",
                           self.dominio, exc)
            return []

    def query_para_prompt(
        self,
        texto_consulta: str,
        top_k: int = 5,
        min_score: float = 0.3,
    ) -> str:
        """
        Versión lista para inyectar en el prompt de evaluación.

        Retorna string formateado con los chunks relevantes, o "" si no hay
        ninguno por encima del umbral.

        Uso típico en evaluar_actividad():
            contexto_rag = retriever.query_para_prompt(actividad, top_k=3)
            if contexto_rag:
                prompt += f"\\n\\n--- CONOCIMIENTO RAG ({dominio}) ---\\n{contexto_rag}"
        """
        try:
            return self._get_buscador().buscar_para_prompt(
                texto_consulta, top_k=top_k, min_score=min_score)
        except Exception as exc:
            logger.warning("[%s] RAG no disponible: %s. Sin contexto.",
                           self.dominio, exc)
            return ""

    def estado(self) -> Dict[str, Any]:
        """Estado del índice del dominio."""
        try:
            return self._get_buscador().estado()
        except Exception as exc:                          # pragma: no cover
            return {"dominio": self.dominio, "error": str(exc)}
