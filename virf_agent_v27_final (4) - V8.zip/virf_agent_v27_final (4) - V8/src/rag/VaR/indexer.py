"""
src/rag/VaR/indexer.py
=======================
Indexador RAG para modelos de Value at Risk (VaR).
Indexa manuales metodológicos VaR, papers FRTB/Basilea III y backtesting.
Hereda de BaseIndexer. Uso: VaRIndexer().build_index()
"""
from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer, fuentes_rag

class VaRIndexer(BaseIndexer):
    dominio = "VaR"
    def get_source_paths(self) -> List[Path]:
        """
        Literatura de referencia del dominio: `inputs/rag/{dom}/`.

        [AUDIT-FIX] Antes apuntaba a las carpetas de EVIDENCIA del modelo
        validado, lo que hacía que el RAG recuperara el propio manual bajo
        evaluación y lo presentara como referencia que lo confirma. Ver
        `base_indexer.fuentes_rag()` para el razonamiento completo.
        """
        return fuentes_rag(self.dominio)
