"""
src/rag/LaR/indexer.py
=======================
Indexador RAG para modelos de Liquidity at Risk (LaR).

Qué indexa:
  - inputs/documentacion/modelamiento/    ← Manuales metodológico y operativo
  - inputs/documentacion/seguimiento/     ← Backtesting, informes de seguimiento
  - inputs/papers/                         ← Papers académicos (Cornish-Fisher, etc.)
  - inputs/calidad_datos/                  ← _replica_virf.py, controles
  - inputs/usos/                           ← Reportes de uso (Comité LaR)

Uso en Databricks (notebook de setup):
    from src.rag.LaR.indexer import LaRIndexer
    idx = LaRIndexer()
    idx.build_index()                   # Primera vez
    idx.build_index(force_rebuild=True) # Si los documentos cambiaron

Programar rebuild mensual en Databricks Jobs (ver scripts/rebuild_rag.py).
"""

from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer, fuentes_rag


class LaRIndexer(BaseIndexer):
    dominio = "LaR"

    def get_source_paths(self) -> List[Path]:
        """
        Literatura de referencia del dominio: `inputs/rag/{dom}/`.

        [AUDIT-FIX] Antes apuntaba a las carpetas de EVIDENCIA del modelo
        validado, lo que hacía que el RAG recuperara el propio manual bajo
        evaluación y lo presentara como referencia que lo confirma. Ver
        `base_indexer.fuentes_rag()` para el razonamiento completo.
        """
        return fuentes_rag(self.dominio)
