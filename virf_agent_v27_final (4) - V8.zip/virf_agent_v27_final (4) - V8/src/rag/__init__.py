"""
src/rag/__init__.py
====================
Dispatcher del sistema RAG segmentado por dominio financiero.

Uso:
    from src.rag import get_retriever
    retriever = get_retriever(tipo_modelo="LaR")
    contexto = retriever.query("¿Existe backtesting de Kupiec?", top_k=5)
"""

from __future__ import annotations

import json
import re
import unicodedata
from pathlib import Path
from typing import Literal

# Dominios RAG FIJOS — no se modifican. Los personalizados se leen aparte.
# ALM es el dominio PADRE de los modelos conductuales (prepago MCP, supervivencia
# MCR) e IRRBB. "conductuales" es su alias LEGACY (ver _ALIAS_LEGACY).
DOMINIOS_DISPONIBLES = ["LaR", "VaR", "ALM", "shared"]

# Etiquetas antiguas que deben seguir resolviendo (fichas de modelo ya creadas
# con el nombre viejo). No añaden dominios nuevos: solo traducen al canónico.
_ALIAS_LEGACY = {"conductuales": "ALM", "conductual": "ALM"}

# Fichero con dominios personalizados creados desde la web.
_DOM_CUSTOM_PATH = (
    Path(__file__).resolve().parents[2] / "web" / "data" / "dominios_custom.json"
)

# Mapeo palabras clave en --titulo → dominio RAG
# Se usa en get_retriever(titulo_modelo=...) para inferencia automática
_KEYWORDS_DOMINIO = {
    "LaR":          ["lar", "liquidity", "liquidez", "lcr", "rcl", "nsfr", "rfne", "hqla"],
    "VaR":          ["var", "value at risk", "frtb", "market risk", "riesgo de mercado",
                     "trading"],
    "ALM":          ["alm", "conductual", "conductuales", "prepago", "mcp", "mcr",
                     "supervivencia", "retiro", "nmd", "comportamiento",
                     "behavioural", "irrbb"],
}


def _normalizar(texto: str) -> str:
    """Minúsculas sin acentos, para que «liquidez» y «Liquidéz» coincidan."""
    sin_acentos = "".join(
        c for c in unicodedata.normalize("NFKD", str(texto or ""))
        if not unicodedata.combining(c))
    return sin_acentos.lower()


def _cargar_dominios_custom() -> dict:
    """
    Lee `web/data/dominios_custom.json`. Devuelve `{}` si no existe o el
    JSON está corrupto — la ausencia NO es un error: significa que
    ningún validador ha creado dominios propios todavía y el sistema
    funciona con los 4 fijos como siempre.
    """
    if not _DOM_CUSTOM_PATH.is_file():
        return {}
    try:
        d = json.loads(_DOM_CUSTOM_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return d if isinstance(d, dict) else {}


def dominios_conocidos() -> list[str]:
    """Lista de todos los dominios (fijos + custom), fijos primero."""
    salida = list(DOMINIOS_DISPONIBLES)
    for dom_id in _cargar_dominios_custom():
        if dom_id not in salida:
            salida.append(dom_id)
    return salida


def inferir_dominio(titulo_modelo: str) -> str:
    """
    Infiere el dominio RAG a partir del título del modelo.
    Retorna 'shared' si no hay match.

    [AUDIT-FIX] ANTES: `if kw in titulo_lower`, coincidencia de SUBCADENA. Como
    las claves son cortas —«lar», «var», «nmd»— coincidían dentro de palabras
    corrientes del castellano, y el modelo se enrutaba al corpus equivocado.
    Medido sobre títulos realistas, 6 de 12 fallaban:

        Titularizacion Hipotecaria          → LaR   (titu·LAR·izacion)
        Scoring Particulares                → LaR   (particu·LAR·es)
        Modelo de Variables Macroeconomicas → VaR   (·VAR·iables)
        Modelo Escalar de Riesgo            → LaR   (esca·LAR)
        Modelo de Alarma Temprana           → LaR   (a·LAR·ma)
        Provisiones Regulares               → LaR   (regu·LAR·es)

    El efecto no era un fallo visible sino una CITA PLAUSIBLE Y AJENA: validando
    un modelo de scoring, el prompt recibía «## Conocimiento recuperado —
    dominio: LaR» con fragmentos del NSFR/BCBS 295. Normativa de liquidez
    presentada al modelo como referencia autorizada para un modelo de scoring.
    Peor que no recuperar nada, porque suena bien.

    AHORA: coincidencia por PALABRA COMPLETA (`\\b`) sobre el título normalizado
    sin acentos. «Modelo LaR» sigue funcionando; «particulares» ya no.

    Los tests que existían solo cubrían tres títulos que casualmente acertaban
    —«Modelo LaR Liquidez», «VaR Mercado FRTB», «Scoring de originacion»—, así
    que la suite daba confianza falsa. Ver TestEnrutadoRAG.

    Ejemplo:
        inferir_dominio("Modelo LaR Liquidez")   → "LaR"
        inferir_dominio("VaR Mercado FRTB")      → "VaR"
        inferir_dominio("Scoring Particulares")  → "shared"
    """
    titulo_norm = _normalizar(titulo_modelo)
    # 1. Fijos primero — el catálogo de referencia manda.
    for dominio, keywords in _KEYWORDS_DOMINIO.items():
        for kw in keywords:
            # `\b` a ambos lados: la clave debe ser una palabra del título, no
            # un trozo de otra. `re.escape` porque hay claves con espacios
            # («value at risk») y una futura podría traer un metacarácter.
            if re.search(rf"\b{re.escape(_normalizar(kw))}\b", titulo_norm):
                return dominio
    # 2. Dominios personalizados creados desde la web.
    for dom_id, dom_data in _cargar_dominios_custom().items():
        for kw in (dom_data.get("palabras_clave") or []):
            if re.search(rf"\b{re.escape(_normalizar(kw))}\b", titulo_norm):
                return dom_id
    return "shared"


def resolver_dominio(titulo_modelo: str, dominio_explicito: str | None = None
                     ) -> tuple[str, str]:
    """
    Dominio RAG a usar y CÓMO se decidió. Devuelve `(dominio, procedencia)`.

    `procedencia` es "explicito" | "inferido" | "defecto", y viaja al informe.
    Un auditor que lea «dominio: LaR» tiene derecho a saber si lo declaró una
    persona o lo adivinó una heurística sobre el título: son dos niveles de
    garantía distintos, y hasta ahora el informe los presentaba igual.

    El dominio explícito (`--dominio-rag`) NO se valida contra el título a
    propósito: si el validador declara un dominio, manda él. Adivinar por
    encima de una declaración explícita es el defecto que esto corrige.

    Raises:
        ValueError: si `dominio_explicito` no es un dominio conocido. Falla
            pronto y ruidoso: un dominio mal escrito que cayera en silencio a
            `shared` dejaría al validador creyendo que declaró algo.
    """
    if dominio_explicito:
        d = str(dominio_explicito).strip()
        # Traduce etiquetas legacy (p. ej. "conductuales" → "ALM") para que las
        # fichas de modelo antiguas sigan resolviendo tras el renombrado.
        d = _ALIAS_LEGACY.get(d.lower(), d)
        # Case-insensitive para que «lar» y «LaR» valgan: el nombre del dominio
        # es un identificador interno, no algo que el operador deba deletrear.
        for conocido in dominios_conocidos():
            if d.lower() == conocido.lower():
                return conocido, "explicito"
        raise ValueError(
            f"Dominio RAG '{dominio_explicito}' no existe. "
            f"Disponibles: {', '.join(dominios_conocidos())}")

    inferido = inferir_dominio(titulo_modelo)
    return inferido, ("defecto" if inferido == "shared" else "inferido")


def get_retriever(
    tipo_modelo: str | None = None,
    titulo_modelo: str | None = None,
):
    """
    Retorna el retriever del dominio correspondiente.

    Args:
        tipo_modelo:   Dominio explícito: "LaR" | "VaR" | "ALM" | "shared"
                       ("conductuales" se acepta como alias legacy de "ALM").
        titulo_modelo: Si tipo_modelo es None, se infiere desde el título.

    Returns:
        Retriever del dominio (objeto con método .query())

    Ejemplo:
        # Explícito:
        retriever = get_retriever(tipo_modelo="LaR")

        # Por inferencia desde --titulo:
        retriever = get_retriever(titulo_modelo="Modelo LaR v2")
    """
    if tipo_modelo is None:
        if titulo_modelo is None:
            tipo_modelo = "shared"
        else:
            tipo_modelo = inferir_dominio(titulo_modelo)

    # Traduce etiquetas legacy ("conductuales" → "ALM") antes de enrutar.
    tipo_modelo = _ALIAS_LEGACY.get(str(tipo_modelo).lower(), tipo_modelo)

    # Dominios fijos: retriever dedicado.
    if tipo_modelo == "LaR":
        from src.rag.LaR.retriever import LaRRetriever
        return LaRRetriever()
    elif tipo_modelo == "VaR":
        from src.rag.VaR.retriever import VaRRetriever
        return VaRRetriever()
    elif tipo_modelo == "ALM":
        from src.rag.ALM.retriever import ALMRetriever
        return ALMRetriever()
    elif tipo_modelo == "shared":
        from src.rag.shared.retriever import SharedRetriever
        return SharedRetriever()

    # Dominio personalizado: si está registrado, retriever paramétrico.
    if tipo_modelo in _cargar_dominios_custom():
        from src.rag.custom_retriever import CustomDomainRetriever
        return CustomDomainRetriever(tipo_modelo)

    raise ValueError(
        f"Dominio RAG '{tipo_modelo}' no existe. "
        f"Disponibles: {dominios_conocidos()}"
    )
