"""
src/rag/tesauro.py
═════════════════════════════════════════════════════════════════════════════
Tesauro de dominio: los sinónimos que la búsqueda léxica no puede adivinar.

EL PROBLEMA QUE RESUELVE
────────────────────────
BM25 encuentra por coincidencia de cadena. Si el estándar pregunta por
«excepciones» y la literatura dice «excedencias», no hay coincidencia — y son
sinónimos exactos en backtesting de VaR. Medido en el índice real:

    tokenizar("excepciones")  →  ['excepcion']   df = 0   ← el estándar
    tokenizar("excedencias")  →  ['exced']       df = 8   ← la literatura

Ese término aportaba CERO a la consulta.

POR QUÉ UN TESAURO Y NO ALGO AUTOMÁTICO
───────────────────────────────────────
La tentación es derivar los sinónimos del propio corpus: co-ocurrencia, LSA/SVD
sobre la matriz TF-IDF (que `scikit-learn` ofrece y sería 100 % local). No sirve
para ESTE caso, y conviene entender por qué antes de intentarlo:

    Cualquier método derivado del corpus necesita que el término APAREZCA en el
    corpus para aprender algo de él. «excepcion» tiene df = 0: no aparece ni una
    vez. No hay contexto del que inferir nada.

Un método automático puede acercar dos palabras que el corpus usa de forma
parecida. No puede inventar la relación entre una palabra que está y otra que no.
Para eso hace falta conocimiento EXTERNO, y aquí el conocimiento externo admisible
—sin modelos, sin descargas, sin red— es una lista escrita por un experto.

Además, en un entorno regulado tiene una ventaja que ningún modelo da:
**es auditable**. Un validador puede leer este fichero entero, discutir una
equivalencia y corregirla. Nadie puede auditar los pesos de un embedding.

CÓMO SE USA
───────────
La expansión ocurre en la CONSULTA, no en el índice. Consecuencia práctica:
tocar este fichero NO obliga a reindexar. Se puede afinar el tesauro en caliente
y ver el efecto al instante.

Para ampliarlo sin tocar código, crear `config/tesauro_rag.yaml`:

    grupos:
      - [excepción, excedencia, exceedance]
      - [pérdida esperada, expected loss]

Los términos se tokenizan con la MISMA función que el índice, así que se escriben
en lenguaje natural —con tildes, en singular o plural, da igual—.
"""

from __future__ import annotations

import logging
from typing import Dict, FrozenSet, List, Set

logger = logging.getLogger("virf.rag")

__all__ = ["GRUPOS_BASE", "cargar_tesauro", "expandir_token"]


# ═════════════════════════════════════════════════════════════════════════════
# TESAURO BASE
# ═════════════════════════════════════════════════════════════════════════════
# Cada línea es un grupo de términos EQUIVALENTES para buscar. La relación es
# simétrica: buscar cualquiera de ellos encuentra los demás.
#
# CRITERIO DE INCLUSIÓN — importa, porque un tesauro laxo hace más daño que bien:
#
#   ✅ Sinónimos EXACTOS en este dominio, o la sigla y su desarrollo.
#   ✅ Variantes español/inglés del mismo concepto técnico.
#   ✅ Erratas RECURRENTES del estándar (las de una vez las corrige `difflib`).
#
#   ❌ Términos meramente relacionados. «volatilidad» y «riesgo» NO son
#      sinónimos: meterlos aquí haría que toda consulta sobre uno arrastrara
#      literatura del otro, que es justo el ruido que el filtro de cobertura
#      existe para evitar.
#   ❌ Hiperónimos. «modelo» no es sinónimo de «modelo de riesgo de mercado».
GRUPOS_BASE: List[List[str]] = [
    # ── Backtesting y contraste ──────────────────────────────────────────────
    # El caso que motivó el fichero. Verificado en el corpus real: el estándar
    # dice «excepciones», los papers de Kupiec dicen «excedencias».
    ["excepción", "excedencia", "exceedance", "excepciones al VaR"],
    ["backtesting", "back-testing", "contraste retrospectivo", "prueba retrospectiva"],
    ["cobertura incondicional", "unconditional coverage"],
    ["cobertura condicional", "conditional coverage"],

    # ── Riesgo de mercado ────────────────────────────────────────────────────
    ["VaR", "valor en riesgo", "value at risk"],
    ["ES", "expected shortfall", "déficit esperado", "CVaR"],
    ["FRTB", "revisión fundamental de la cartera de negociación",
     "fundamental review of the trading book"],
    ["volatilidad", "desviación típica de los retornos"],
    ["EWMA", "media móvil ponderada exponencialmente",
     "exponentially weighted moving average"],

    # ── Liquidez ─────────────────────────────────────────────────────────────
    ["HQLA", "activos líquidos de alta calidad", "high quality liquid assets"],
    ["LCR", "coeficiente de cobertura de liquidez", "liquidity coverage ratio"],
    ["NSFR", "coeficiente de financiación estable neta",
     "net stable funding ratio", "financiación estable"],
    ["salidas netas de efectivo", "net cash outflows"],

    # ── Riesgo de crédito ────────────────────────────────────────────────────
    ["PD", "probabilidad de incumplimiento", "probability of default"],
    ["LGD", "pérdida en caso de incumplimiento", "loss given default",
     "severidad"],
    ["EAD", "exposición en el momento del incumplimiento",
     "exposure at default"],
    ["pérdida esperada", "expected loss"],

    # ── Conductuales / IRRBB ─────────────────────────────────────────────────
    ["NMD", "depósitos sin vencimiento", "non-maturity deposits",
     "depósitos a la vista"],
    ["prepago", "amortización anticipada", "prepayment", "cancelación anticipada"],
    ["IRRBB", "riesgo de tipo de interés del balance",
     "interest rate risk in the banking book"],
    ["repreciación", "repricing"],

    # ── Validación y gobierno ────────────────────────────────────────────────
    ["validación", "revisión independiente", "validation"],
    ["riesgo de modelo", "model risk"],
    ["seguimiento", "monitoreo", "monitorización", "monitoring", "ongoing monitoring"],
    ["backtest", "prueba retrospectiva"],
    ["análisis de sensibilidad", "sensitivity analysis"],
    ["prueba de estrés", "stress testing", "test de estrés", "escenario de estrés"],
    ["gobierno", "gobernanza", "governance"],
    ["apetito de riesgo", "risk appetite"],

    # ── Datos ────────────────────────────────────────────────────────────────
    ["calidad de datos", "data quality"],
    ["valores faltantes", "datos faltantes", "missing", "valores perdidos",
     "imputación"],
    ["atípico", "outlier", "valor extremo"],
    ["linaje de datos", "trazabilidad de datos", "data lineage"],
    ["diccionario de datos", "data dictionary"],

    # ── Documentación ────────────────────────────────────────────────────────
    ["manual metodológico", "documento metodológico", "nota técnica"],
    ["control de versiones", "control de cambios", "versionado"],
    ["supuesto", "hipótesis", "assumption"],
    ["limitación", "limitation", "restricción del modelo"],
]


def _normalizar(termino: str) -> FrozenSet[str]:
    """
    Un término del tesauro → los tokens que produciría el índice.

    Se usa la MISMA `tokenizar()` que indexa y que consulta. Si se normalizara
    aquí de otra forma, el tesauro generaría variantes que no existen en el
    índice y la expansión sería silenciosamente inútil.
    """
    from src.rag.indexador_lexico import tokenizar
    return frozenset(tokenizar(termino))


def cargar_tesauro(ruta_yaml=None) -> Dict[str, Set[str]]:
    """
    Construye el índice de expansión: token → tokens equivalentes.

    Args:
        ruta_yaml: fichero opcional con `grupos:` para ampliar el tesauro base
                   sin tocar código. Si no existe, se ignora en silencio.

    Returns:
        (unitarios, frases)

        · unitarios: token → tokens equivalentes de UNA palabra. Es la
          expansión directa: «excepcion» → {«exced»}.

        · frases: (tupla de tokens) → tokens equivalentes de una palabra. Cubre
          el caso «valor en riesgo» → «var», que la expansión token a token no
          puede resolver porque «valor» solo no significa VaR.

        Lo que NO se hace nunca es lo contrario —expandir «HQLA» a «activos»,
        «alta», «calidad» sueltos—: esos tokens por separado aparecen en medio
        corpus y meterlos como sinónimos de una sigla precisa es exactamente el
        ruido que el filtro de cobertura existe para evitar. Para la dirección
        sigla → expresión ya está TF-IDF, que indexa bigramas.
    """
    grupos = [list(g) for g in GRUPOS_BASE]

    if ruta_yaml is not None:
        try:
            from pathlib import Path
            p = Path(ruta_yaml)
            if p.is_file():
                import yaml
                datos = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
                extra = datos.get("grupos") or []
                grupos.extend([list(g) for g in extra if isinstance(g, (list, tuple))])
                logger.info("[rag] Tesauro ampliado con %d grupos de %s",
                            len(extra), p)
        except Exception as exc:                          # pragma: no cover
            logger.warning("[rag] No se pudo leer el tesauro %s: %s", ruta_yaml, exc)

    unitarios_idx: Dict[str, Set[str]] = {}
    frases_idx: Dict[tuple, Set[str]] = {}

    for grupo in grupos:
        # Un término puede dar varios tokens («valor en riesgo» → 2).
        unitarios, frases = set(), []
        for termino in grupo:
            toks = _normalizar(termino)
            if len(toks) == 1:
                unitarios.add(next(iter(toks)))
            elif len(toks) > 1:
                frases.append(frozenset(toks))

        # a) token ↔ token
        for t in unitarios:
            unitarios_idx.setdefault(t, set()).update(unitarios - {t})

        # b) frase → sigla. Solo en esta dirección, por el motivo del docstring.
        for f in frases:
            if unitarios:
                frases_idx.setdefault(tuple(sorted(f)), set()).update(unitarios)

    # Un token que solo se apunta a sí mismo no aporta nada y ensucia el
    # diagnóstico; se descarta.
    return ({k: v for k, v in unitarios_idx.items() if v},
            {k: v for k, v in frases_idx.items() if v})


def expandir_token(token: str, tesauro: Dict[str, Set[str]]) -> Set[str]:
    """Token → él mismo más sus equivalentes conocidos."""
    return {token} | tesauro.get(token, set())
