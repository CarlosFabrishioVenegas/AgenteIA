"""
src/rag/custom_retriever.py
════════════════════════════════════════════════════════════════════════════
Retriever + indexer para dominios RAG PERSONALIZADOS (Mejora 1 · v2.2).

Los 4 dominios fijos (LaR, VaR, conductuales, shared) tienen sus propios
archivos en `src/rag/{dominio}/retriever.py` y `.../indexer.py`. Los
dominios personalizados —creados desde la web— usan estas dos clases
parametrizadas para no crear una carpeta con dos ficheros triviales
por cada dominio nuevo.

Los mecanismos de indexado y recuperación son EXACTAMENTE los mismos
que los de los fijos: `BaseIndexer` resuelve `fuentes_rag(self.dominio)`
a `inputs/rag/{dominio_id}/` y `ruta_indice(self.dominio)` a
`data/rag_lexico/{dominio_id}.pkl`.
"""
from __future__ import annotations

from pathlib import Path
from typing import List

from src.rag.base_indexer import BaseIndexer, fuentes_rag
from src.rag.base_retriever import BaseRetriever


class CustomDomainRetriever(BaseRetriever):
    """
    Retriever paramétrico: `CustomDomainRetriever("capital_economico")`
    es equivalente a `VaRRetriever()` pero con dominio dinámico.
    """

    def __init__(self, dominio_id: str, autoconstruir: bool = True):
        # `dominio` es atributo de clase en BaseRetriever, pero al
        # asignarlo como atributo de instancia sobrescribe la lookup —
        # cada instancia mantiene su propio dominio.
        self.dominio = dominio_id
        super().__init__(autoconstruir=autoconstruir)


class CustomDomainIndexer(BaseIndexer):
    """
    Indexer paramétrico: `CustomDomainIndexer("capital_economico")
    .build_index(force_rebuild=True)` construye
    `data/rag_lexico/capital_economico.pkl` a partir de
    `inputs/rag/capital_economico/`.
    """

    def __init__(self, dominio_id: str, chunk_size=None, chunk_overlap=None):
        self.dominio = dominio_id
        super().__init__(chunk_size=chunk_size, chunk_overlap=chunk_overlap)

    def get_source_paths(self) -> List[Path]:
        # Mismo criterio que los indexers fijos: `inputs/rag/{dominio}/`.
        return fuentes_rag(self.dominio)
