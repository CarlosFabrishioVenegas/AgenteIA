"""
src/rag/shared/indexer.py
=========================
Indexador RAG de conocimiento regulatorio compartido (transversal a todos los dominios).
Indexa: SR 11-7, EBA/GL/2023/01, BCBS 239, papers regulatorios generales.
Es el fallback cuando no hay un dominio específico. Hereda de BaseIndexer.
"""
from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer, fuentes_rag

class SharedIndexer(BaseIndexer):
    dominio = "shared"
    def get_source_paths(self) -> List[Path]:
        """
        Literatura de referencia del dominio: `inputs/rag/{dom}/`.

        [AUDIT-FIX] Antes apuntaba a las carpetas de EVIDENCIA del modelo
        validado, lo que hacía que el RAG recuperara el propio manual bajo
        evaluación y lo presentara como referencia que lo confirma. Ver
        `base_indexer.fuentes_rag()` para el razonamiento completo.
        """
        return fuentes_rag(self.dominio)
