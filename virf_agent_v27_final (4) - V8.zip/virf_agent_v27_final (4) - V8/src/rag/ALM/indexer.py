"""
src/rag/ALM/indexer.py
================================
Indexador RAG para el dominio ALM (modelos conductuales: prepago, retiro de
depósitos, NMD; IRRBB). Indexa manuales conductuales, EBA guidelines, documentos
de IRRBB y de seguimiento.
Hereda de BaseIndexer. Uso: ALMIndexer().build_index()
"""
from pathlib import Path
from typing import List
from src.rag.base_indexer import BaseIndexer, fuentes_rag

class ALMIndexer(BaseIndexer):
    dominio = "ALM"
    def get_source_paths(self) -> List[Path]:
        """
        Literatura de referencia del dominio: `inputs/rag/{dom}/`.

        [AUDIT-FIX] Antes apuntaba a las carpetas de EVIDENCIA del modelo
        validado, lo que hacía que el RAG recuperara el propio manual bajo
        evaluación y lo presentara como referencia que lo confirma. Ver
        `base_indexer.fuentes_rag()` para el razonamiento completo.
        """
        return fuentes_rag(self.dominio)
