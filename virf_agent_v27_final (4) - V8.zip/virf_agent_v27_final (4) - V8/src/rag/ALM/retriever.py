"""
src/rag/ALM/retriever.py
==================================
Retriever RAG para el dominio ALM (modelos conductuales: prepago, supervivencia/
retiro de depósitos, NMD, IRRBB).
Recupera contexto de comportamiento de clientes y de riesgo de tasa para el prompt.
Uso: ALMRetriever().query_para_prompt(texto, top_k=3)
"""
from src.rag.base_retriever import BaseRetriever
class ALMRetriever(BaseRetriever):
    dominio = "ALM"
