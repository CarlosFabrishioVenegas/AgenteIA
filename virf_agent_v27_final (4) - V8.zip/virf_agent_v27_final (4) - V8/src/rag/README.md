# RAG — Recuperación por Dominio Financiero

Cada subcarpeta es un **dominio independiente** del RAG.
El retriever (`retriever.py`) selecciona qué índice vectorial consultar
según el tipo de modelo que se está evaluando.

## Estructura

```
src/rag/
├── LaR/            ← Liquidity at Risk
│   ├── indexer.py          Indexa manuales + papers de LaR
│   ├── retriever.py        Recupera contexto específico de LaR
│   └── README.md
│
├── VaR/            ← Value at Risk
│   ├── indexer.py
│   ├── retriever.py
│   └── README.md
│
├── conductuales/   ← Modelos de comportamiento (prepago, retiro, etc.)
│   ├── indexer.py
│   ├── retriever.py
│   └── README.md
│
└── shared/         ← Conocimiento regulatorio compartido (SR 11-7, Basilea, etc.)
    ├── indexer.py
    ├── retriever.py
    └── README.md
```

## Qué va en cada dominio

| Dominio | Documentos a indexar | Papers clave |
|---------|---------------------|--------------|
| `LaR/` | Manuales metodológicos LaR, backtesting de liquidez, reportes Comité LaR | Cornish-Fisher, stress testing liquidez |
| `VaR/` | Manuales VaR, pruebas Kupiec/Christoffersen, FRTB | BIS FRTB, Basilea III |
| `conductuales/` | Modelos de prepago, retiro de depósitos, NMD | Papers de comportamiento, EBA guidelines |
| `shared/` | SR 11-7, EBA/GL/2023/01, BCBS 239, SBS 9075-2012 | Marcos regulatorios aplicables a todos |

## Flujo de uso

```python
# En agente.py / motor_ia.py, el tipo de modelo determina el índice RAG:
from src.rag import get_retriever

retriever = get_retriever(tipo_modelo="LaR")  # o "VaR", "conductuales"
contexto_adicional = retriever.query(actividad, top_k=5)
# → se inyecta en el prompt antes de evaluar_actividad()
```

## Cómo agregar un nuevo dominio

1. Crear carpeta `src/rag/<dominio>/`
2. Copiar estructura de `LaR/` como plantilla
3. Agregar el índice vectorial en `data/vectordb/<dominio>/`
4. Registrar en `src/rag/__init__.py` → `DOMINIOS_DISPONIBLES`
5. Mapear en `motor/Mx_00_CargaRutas.py` → `TIPO_MODELO_A_RAG`
