"""
src/rag/config_rag.py
═════════════════════════════════════════════════════════════════════════════
Parámetros del RAG LÉXICO (BM25 + TF-IDF). Sin embeddings, sin HuggingFace.

De dónde salen los valores
──────────────────────────
De `config/parametros.py`, que es la ÚNICA fuente de verdad del proyecto. Este
módulo no llama a `os.getenv` ni una vez: solo importa y renombra.

La primera versión sí leía el entorno por su cuenta, para que `src/` siguiera
siendo utilizable suelto —el job de Databricks copia solo esa carpeta—. El
invariante CONFIG-CENTRAL pesa más que esa comodidad, y tiene un test que lo
vigila: un segundo sitio llamando a `os.getenv` es exactamente lo que permitía
la divergencia que ese invariante existe para impedir (el proyecto ya vivió
`VIRF_MAX_CTX` declarado dos veces con defaults distintos).

`src/rag` SIGUE funcionando fuera del árbol del agente: si `config` no está
importable, se cae a los MISMOS valores literales que declara
`config/parametros.py`. Lo que se pierde sin `config/` es la configurabilidad
por entorno, no el funcionamiento — y eso es lo correcto, porque un job que solo
copia `src/` tampoco lleva el `.env`.
"""

from __future__ import annotations

import os
from pathlib import Path

__all__ = [
    "RAIZ_PROYECTO", "INDICE_DIR", "DOMINIOS",
    "TOP_K_DEFECTO", "MIN_SCORE_DEFECTO", "MIN_COBERTURA",
    "PESO_INFORMATIVO_MINIMO", "RECONOCIMIENTO_MINIMO",
    "PESO_BM25", "PESO_TFIDF",
    "CHUNK_SIZE", "CHUNK_OVERLAP", "CHUNKING_ESTRUCTURAL",
    "BM25_K1", "BM25_B",
    "TFIDF_NGRAM_MAX", "TFIDF_MIN_DF",
    "STEMMING_ACTIVO", "LONGITUD_MINIMA_TOKEN",
    "TESAURO_ACTIVO", "TESAURO_PATH", "CORREGIR_ERRATAS", "UMBRAL_ERRATA",
    "VERSION_INDICE", "EXTENSIONES_INDEXABLES", "NOMBRES_EXCLUIDOS",
]

# parents[2] desde src/rag/config_rag.py = raíz del proyecto.
RAIZ_PROYECTO = Path(__file__).resolve().parents[2]

_EN_DATABRICKS = "DATABRICKS_RUNTIME_VERSION" in os.environ

DOMINIOS = ["LaR", "VaR", "ALM", "shared"]


# ── Valores por defecto ──────────────────────────────────────────────────────
# Duplican a propósito los de `config/parametros.py`. No es una divergencia
# esperando a ocurrir: hay un test que compara ambos y falla si se separan. Es
# el precio de que `src/rag` arranque sin el paquete `config`.
_DEFECTOS = {
    "RAG_TOP_K": 6,
    "RAG_MIN_SCORE": 0.35,
    "RAG_MIN_COBERTURA": 0.15,
    "RAG_PESO_INFORMATIVO_MINIMO": 0.8,
    "RAG_RECONOCIMIENTO_MINIMO": 0.5,
    "RAG_INDICE_DIR": "",
    "RAG_PESO_BM25": 0.7,
    "RAG_PESO_TFIDF": 0.3,
    "RAG_BM25_K1": 1.5,
    "RAG_BM25_B": 0.75,
    "RAG_TFIDF_NGRAM_MAX": 2,
    "RAG_TFIDF_MIN_DF": 1,
    "RAG_CHUNK_SIZE": 1200,
    "RAG_CHUNK_OVERLAP": 200,
    "RAG_CHUNKING_ESTRUCTURAL": False,
    "RAG_STEMMING": True,
    "RAG_LONGITUD_MINIMA_TOKEN": 2,
    "RAG_TESAURO": True,
    "RAG_CORREGIR_ERRATAS": True,
    "RAG_UMBRAL_ERRATA": 0.85,
}

try:                                                      # pragma: no cover
    from config import parametros as _p
    def _param(nombre):
        return getattr(_p, nombre, _DEFECTOS[nombre])
except Exception:                                         # pragma: no cover
    def _param(nombre):
        return _DEFECTOS[nombre]


# ── Rutas ────────────────────────────────────────────────────────────────────
def _indice_dir_defecto() -> Path:
    """
    Carpeta donde se persisten los índices léxicos, uno por dominio.

    NO se reutiliza `VECTORDB_DIR`. Esa carpeta contiene (o contenía) bases
    ChromaDB con vectores de 1536 dimensiones que ya no significan nada aquí, y
    mezclar los dos formatos en la misma ruta invita a que un índice viejo pase
    por nuevo. Carpeta distinta = imposible confundirlos, y `data/vectordb/`
    puede borrarse a mano cuando el operador quiera recuperar el disco.
    """
    if _EN_DATABRICKS:
        return Path("/dbfs/FileStore/virf/rag_lexico")
    return RAIZ_PROYECTO / "data" / "rag_lexico"


INDICE_DIR = Path(str(_param("RAG_INDICE_DIR")).strip() or _indice_dir_defecto())


# ── Recuperación ─────────────────────────────────────────────────────────────
TOP_K_DEFECTO = int(_param("RAG_TOP_K"))
MIN_SCORE_DEFECTO = float(_param("RAG_MIN_SCORE"))

# Corte ABSOLUTO, aplicado antes de puntuar: fracción del peso informativo
# (Σ IDF) de la consulta que el fragmento debe cubrir. A diferencia de
# MIN_SCORE_DEFECTO, este número significa lo mismo en todas las consultas.
MIN_COBERTURA = float(_param("RAG_MIN_COBERTURA"))

# Por debajo de esto, la CONSULTA (no el fragmento) se considera poco
# discriminante y se avisa. No filtra nada: nombra la causa.
PESO_INFORMATIVO_MINIMO = float(_param("RAG_PESO_INFORMATIVO_MINIMO"))

#: Fracción mínima de la consulta que el corpus debe RECONOCER para que sus
#: fragmentos se presenten sin advertencia. Por debajo, se avisa de que la
#: literatura recuperada puede ser de otro dominio. 0.5 = al menos la mitad de
#: los conceptos de la pregunta existen en este corpus.
RECONOCIMIENTO_MINIMO = float(_param("RAG_RECONOCIMIENTO_MINIMO"))

# Combinación de señales. BM25 manda porque es el que premia la coincidencia
# EXACTA de terminología (Kupiec, HQLA, NSFR, IFRS 9), que es justo lo que se
# busca en literatura regulatoria. TF-IDF/coseno entra como voto de segunda
# opinión: penaliza los chunks que aciertan un término raro por casualidad pero
# no comparten el resto del vocabulario de la consulta.
#
# Los pesos se normalizan al usarse, así que no hace falta que sumen 1.
PESO_BM25 = float(_param("RAG_PESO_BM25"))
PESO_TFIDF = float(_param("RAG_PESO_TFIDF"))

# Parámetros canónicos de BM25 (Robertson; los de Elasticsearch por defecto).
BM25_K1 = float(_param("RAG_BM25_K1"))
BM25_B = float(_param("RAG_BM25_B"))

TFIDF_NGRAM_MAX = int(_param("RAG_TFIDF_NGRAM_MAX"))
TFIDF_MIN_DF = int(_param("RAG_TFIDF_MIN_DF"))


# ── Troceado ─────────────────────────────────────────────────────────────────
CHUNK_SIZE = int(_param("RAG_CHUNK_SIZE"))
CHUNK_OVERLAP = int(_param("RAG_CHUNK_OVERLAP"))

# Chunking estructural opt-in (respeta encabezados; no parte tablas/fórmulas).
# Default False: el corte por tamaño sigue siendo el default (ver la nota en
# config/parametros.py:RAG_CHUNKING_ESTRUCTURAL). Se lee vía _param para no
# llamar a os.getenv fuera de config/parametros.py.
CHUNKING_ESTRUCTURAL = bool(_param("RAG_CHUNKING_ESTRUCTURAL"))


# ── Tokenización ─────────────────────────────────────────────────────────────
STEMMING_ACTIVO = bool(_param("RAG_STEMMING"))
LONGITUD_MINIMA_TOKEN = int(_param("RAG_LONGITUD_MINIMA_TOKEN"))


# ── Expansión de la consulta ─────────────────────────────────────────────────
# Las dos curas del punto ciego de la búsqueda léxica: no entiende sinónimos.
# Ambas actúan sobre la CONSULTA, no sobre el índice, así que se pueden tocar
# sin reindexar.
TESAURO_ACTIVO = bool(_param("RAG_TESAURO"))
# Fichero opcional para ampliar el tesauro sin tocar código.
TESAURO_PATH = RAIZ_PROYECTO / "config" / "tesauro_rag.yaml"

# Corrección ortográfica de términos que NO existen en el corpus. Solo se
# intenta sobre esos: un término con df=0 aporta cero, así que corregirlo o
# deja las cosas igual o las mejora. Nunca puede empeorar el resultado.
CORREGIR_ERRATAS = bool(_param("RAG_CORREGIR_ERRATAS"))
# Parecido mínimo (difflib) para aceptar una corrección. 0.85 es estricto a
# propósito: «seguimeinto»→«seguimiento» pasa; «caso»→«paso» no.
UMBRAL_ERRATA = float(_param("RAG_UMBRAL_ERRATA"))


# ── Formato del índice persistido ────────────────────────────────────────────
# Se compara al cargar. Si no coincide, el índice se considera obsoleto y se
# reconstruye en vez de deserializarse mal en silencio — que es exactamente el
# fallo que tenía el RAG anterior al cambiar de motor de embeddings.
# v3 (2026-07-31): añade `vocabulario_crudo` al índice, para corregir erratas
# de la consulta por parecido ortográfico. Un índice v2 no lo tiene, así que se
# reconstruye en vez de quedarse sin esa función en silencio.
VERSION_INDICE = 3

EXTENSIONES_INDEXABLES = {".pdf", ".docx", ".pptx", ".xlsx", ".txt", ".md"}

# El README de cada carpeta explica QUÉ debe ir en ella; no es conocimiento del
# dominio. Sin excluirlo, una consulta sobre backtesting puede recuperar «Qué NO
# va aquí: la evidencia del modelo…» y presentarlo como referencia experta.
NOMBRES_EXCLUIDOS = {"README", "LEEME", "LEEME_PRIMERO"}
