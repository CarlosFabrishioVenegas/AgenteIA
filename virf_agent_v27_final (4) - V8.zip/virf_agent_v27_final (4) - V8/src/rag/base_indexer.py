"""
src/rag/base_indexer.py
════════════════════════════════════════════════════════════════════════════
Clase base para indexadores de todos los dominios RAG.

Desde el 2026-07-31 esto es un ADAPTADOR fino sobre `indexador_lexico.py`. El
motor real —BM25 + TF-IDF, cero embeddings, cero HuggingFace— vive allí; aquí
solo se conserva la forma que ya consumen `LaRIndexer`, `VaRIndexer`,
`ConductualesIndexer`, `SharedIndexer` y `scripts/rebuild_rag_databricks.py`.

Qué desapareció y por qué
─────────────────────────
ChromaDB y `config/embeddings.py`. Dos motivos independientes, cada uno
suficiente por sí solo:

  1. No existe deployment de embeddings en el recurso Azure de la entidad —hay
     uno solo, de chat—, así que la función que los generaba lanzaba siempre y
     `BaseRetriever.query()` devolvía [] en silencio. El RAG estaba apagado.
  2. `chromadb → tokenizers → huggingface-hub`. La dependencia de HF entraba
     por el árbol transitivo aunque ninguna línea de este proyecto la
     importara. Quitar ChromaDB corta la cadena entera.

La API pública se mantiene íntegra (`build_index`, `get_source_paths`,
`dominio`, `raiz_proyecto`, `fuentes_rag`) para que las subclases de dominio y
los scripts no tengan que cambiar. `get_collection()` ya NO existe: no hay
colección vectorial que devolver, y dejar un método que devuelve algo que no
sirve es peor que quitarlo. El sustituto es `cargar_indice()`.

Uso:
    from src.rag.VaR.indexer import VaRIndexer
    VaRIndexer().build_index()                    # reutiliza si está vigente
    VaRIndexer().build_index(force_rebuild=True)  # reextrae los PDF
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional

# `import src.rag.config_rag` y NO `from src.rag import config_rag`: la segunda
# forma ejecuta `src/rag/__init__.py` —el dispatcher— y crea un ciclo
# src.rag → …retriever → base_retriever → buscador_lexico → src.rag que el
# validador de arquitectura detecta y rechaza. La forma de abajo referencia el
# submódulo directamente y no toca el paquete.
import src.rag.config_rag as cfg
from src.rag.indexador_lexico import (
    IndexadorLexico, IndiceLexico, fuentes_rag, raiz_proyecto, ruta_indice,
)

logger = logging.getLogger("virf.rag")

__all__ = ["BaseIndexer", "fuentes_rag", "raiz_proyecto", "ruta_indice"]


class BaseIndexer(ABC):
    """
    Indexador base para un dominio RAG.

    Subclases deben definir:
        - dominio: str (nombre del dominio, ej. "LaR")
        - get_source_paths(): carpetas/archivos a indexar
    """

    dominio: str = "base"

    def __init__(self, chunk_size: Optional[int] = None,
                 chunk_overlap: Optional[int] = None):
        self.chunk_size = chunk_size or cfg.CHUNK_SIZE
        self.chunk_overlap = chunk_overlap if chunk_overlap is not None else cfg.CHUNK_OVERLAP
        # Ruta del índice léxico del dominio. Se expone con el nombre histórico
        # `indice_path`; `vectordb_path` ya no aplica —no hay vectores— y
        # mantenerlo como alias solo serviría para que un lector creyera que
        # sigue habiendo una base vectorial detrás.
        self.indice_path = ruta_indice(self.dominio)
        self._indice: Optional[IndiceLexico] = None

    @abstractmethod
    def get_source_paths(self) -> List[Path]:
        """Retorna las carpetas/archivos a indexar para este dominio."""
        ...

    # ── Motor ────────────────────────────────────────────────────────────────

    def _motor(self) -> IndexadorLexico:
        """Indexador léxico configurado con las fuentes que declare la subclase."""
        return IndexadorLexico(
            self.dominio,
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            fuentes=self.get_source_paths(),
        )

    # ── API pública ──────────────────────────────────────────────────────────

    def build_index(self, force_rebuild: bool = False) -> None:
        """
        Construye el índice léxico del dominio y lo persiste.

        Args:
            force_rebuild: si True, ignora lo que haya en disco y reextrae los
                           documentos. Sin él, un índice cuya huella de fuentes
                           coincide con el disco se reutiliza tal cual.
        """
        indice = self._motor().construir(force=force_rebuild)
        self._indice = indice
        documentos = len({c["fuente"] for c in indice.chunks})
        print(f"✅ [{self.dominio}] Índice léxico listo: {len(indice)} chunks "
              f"de {documentos} documentos en {self.indice_path}")

    def cargar_indice(self, force_rebuild: bool = False) -> IndiceLexico:
        """
        Devuelve el índice del dominio, construyéndolo si hace falta.

        Sustituye a `get_collection()`, que devolvía una colección ChromaDB.
        """
        if self._indice is None or force_rebuild:
            self._indice = self._motor().construir(force=force_rebuild)
        return self._indice

    def estado(self) -> Dict[str, Any]:
        """Diagnóstico del índice: chunks, documentos, vigencia."""
        return self._motor().estado()
