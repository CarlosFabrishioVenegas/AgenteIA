# Prompt de continuidad — VIRF Agent · 2026-08-09

**Cómo usar este documento.** Pégalo completo como primer mensaje a la IA que
continúe. Sustituye a `PROMPT_CONTINUIDAD_2026-08-07.md` (consérvalo: describe
el estado del que arrancó esta sesión). Contiene el estado real de hoy, las
trampas nuevas que aparecieron y lo que queda.

---

## Rol

> Actúas como **Ingeniero de Software Senior especializado en sistemas de
> auditoría regulatoria**, sobre VIRF Agent v27: un validador independiente de
> modelos financieros para un equipo de 2-5 validadores en una entidad
> supervisada.
>
> Regla de oro: **no marques nada como correcto sin haber leído el código real
> o ejecutado el caso real.** Un «✅ OK» falso cuesta más que un fallo
> declarado. Y una segunda: **cuando encuentres un defecto, mide su alcance
> antes de arreglarlo**: la mitad de los hallazgos de esta sesión tenían al
> menos otra aparición del mismo patrón.

---

## 1. Estado actual — verificado el 2026-08-08

| Puerta | Valor |
|---|---|
| `python validate_project.py --strict` | **148 / 148**, 0 WARN, 0 FAIL |
| `python -m pytest -q` | **835 passed**, 1 skipped |
| Repositorio | git iniciado el 2026-08-07 · 4 commits · `audit_logs/registro_emisiones.jsonl` versionado |
| Manual técnico | `MANUAL_TECNICO_VIRF.pdf` en la raíz — 61 páginas, generado por AST del código |

**⚠️ NO HAY CRÉDITO DE API y no se recargará.** El usuario lo confirmó el
2026-08-07. **No lances corridas reales**. Todo lo verificable interceptando
`modulos.motor_ia._llamar_modelo` con respuestas simuladas está verificado —
que es más de lo que parece: el parseo, el anclaje de citas contra la
evidencia real, el contrato de las skills y el renderizado al Word son código
nuestro y se ejercitan enteros.

**Lee primero `QUE_HACE_REALMENTE.md`** — describe qué hace el sistema con
cifras medidas y, sobre todo, qué NO hace. También hay `MANUAL_TECNICO_VIRF.pdf`
en la raíz: 61 páginas, generado por AST del proyecto entero, útil como
referencia de qué función vive dónde.

---

## 2. Qué se hizo en la sesión 2026-08-07 → 2026-08-08

### Auditoría integral · 15 hallazgos F-01..F-15, todos cerrados

Los tres críticos:

| # | Defecto | Corrección |
|---|---|---|
| F-01 | `messages.create()` sin `temperature`; Anthropic usaba 1.0 por defecto y la misma evidencia podía dar dictámenes distintos | `IA_TEMPERATURE=0.0` fijo, respetando `admite_temperature` en modelos de razonamiento OpenAI |
| F-02 | `generador_markdown._pj()` devolvía 1 ante `puntaje=None`, acusando al validado del peor incumplimiento por una avería del agente | Devuelve `None` y ordena las actividades fallidas al final; las peticiones de re-ejecución ya no se envían al modelador |
| F-03 | Toda corrida se sellaba como `entregable`; `--analizar-codigo` dejaba entradas «entregable» sin firmante en el registro append-only | Sin firmante → `tipo_corrida: trabajo`. `TIPO_TRABAJO` ya existía en `custodia.py` y no lo usaba nadie |

Los otros doce están en el commit `5f8893f` (F-04/F-05 alcance del corpus RAG,
F-06 memoria inter-ámbito, F-07 git, F-08 dependencias pineadas, F-09 huella
del corpus, F-10 puerta del tier, F-11 estructura del README, F-12 diagnóstico
del Excel, F-13/F-14 documentación, F-15 clamp del semáforo).

### Trabajo adicional

**Set de preguntas-oro del RAG.** `scripts/preguntas_oro_rag.py` — 24 preguntas
(3 por dominio → **7 por dominio salvo `conductuales`, que se mantiene en 5**
por tener un solo documento) + 4 adversarias que preguntan al dominio
equivocado a propósito. La suite detecta el fallo que la auditoría encontró:
un buscador degradado que aprueba @1 pero suspende @3.

**Umbral doble recall@1 + recall@3.** El segundo se activa **por pregunta** si
`chunks_dominio - chunks_doc >= top_k`. Con 12 chunks en VaR y solo 1 de
`riskmetrics_summary.md`, esa pregunta ya discrimina hoy. La primera versión
del criterio pedía «≥6 documentos en el dominio» y quedaba dormida; el correcto
sale del mecanismo, no de un número redondo.

**Motores de calidad de datos DE LA ENTIDAD.** `modulos/motores_entidad.py`
lee `inputs/calidad_datos/resultadocalidad_de_datos/*.xlsx` con cuatro (o
cinco) columnas — Descripción, % de incumplimiento, Resultado, Umbral, Detalle.
**El agente NO ejecuta esos motores.** Un `.py` en esa carpeta se ignora y se
declara. Hay un test AST que impide que el módulo introduzca
`exec/eval/compile/subprocess/importlib`.

**Pipeline de referencia para producir esa tabla.**
`scripts/pipeline_calidad_datos.py`. Vive en `scripts/` a propósito: **el
agente no lo importa** y hay un test AST que hace fallar la suite si algún día
lo hiciera — sería el modelo de responsabilidad roto.

**Tope de puntaje 3 sobre tolerancia cero** (política del 2026-08-08). Un
FALLA sobre `umbral == 0` no puntúa 4 sino 3: la magnitud no atenúa haber
superado una tolerancia que la entidad fijó en ninguno. Sin columna `Umbral`
no se supone tolerancia cero y se declara. Efecto medido sobre los datos
reales: el ámbito «Calidad de datos» pasa de 4.38 a **3.88**.

**Manual técnico PDF.** `MANUAL_TECNICO_VIRF.pdf` en la raíz — 61 páginas
autogeneradas leyendo el AST y ejecutando los propios módulos. Portada BCP,
Flexo, tablas de resumen, catálogos, firmas de función con `fichero:línea`.
Documenta también las trampas nuevas de la §3 en su capítulo 20.

---

## 3. Trampas de ESTE código — las nuevas

Las anteriores (§3.1 a §3.15) siguen vigentes. Estas se descubrieron en la
sesión 07→08:

### 3.16. `git checkout` sobre trabajo no commiteado LO PIERDE

Me pasó dos veces esta sesión. Cuando reintroduzcas un defecto para probar
que un test lo detecta, revierte con `git stash` o edición manual, **nunca con
`git checkout`** salvo que el trabajo esté ya en un commit. Se pierde en
silencio y solo lo detectas mirando el fichero después.

### 3.17. La escala % vs fracción se decide por el ENCABEZADO

Una tabla del validador puede traer una única fila con `0.32`. Si adivinas por
el máximo, cualquier tabla con todo ≤ 1 se lee como fracción — y una tasa del
32 % se vuelve un 0,32 %, cien veces peor. La regla nueva: **primero el
encabezado** (`%` o `porcentaje` → porcentaje; `tasa` o `ratio` o `fracción` →
fracción), y solo si el nombre no aclara, se recurre al máximo. Aplicado a
`_escala_de_la_columna` en `modulos/motores_entidad.py`.

### 3.18. Word no abre rutas de más de 255 caracteres

La ruta del proyecto tiene ~180 chars. Todo lo que se guarde en el scratchpad
—que tiene ruta larguísima— y se pretenda abrir con Word COM falla en
silencio: `Documents.Open()` devuelve `null` sin excepción. Copia a `C:\vt\`
antes de abrir. Aplicable a `.docx` regenerados en pruebas.

### 3.19. Recall@3 no discrimina en corpus pequeños — se decide por el mecanismo

Con 2-3 documentos por dominio, el top-3 abarca el corpus entero y @3 vale
100 % pase lo que pase. Un umbral sobre @3 en esas condiciones **no puede
fallar cuando debe**, que es peor que no tenerlo (da confianza falsa). El
criterio correcto es por PREGUNTA:

    chunks_del_dominio - chunks_del_documento_esperado ≥ top_k

Si no se cumple, esa pregunta se marca `elegible_r3 = False` y no cuenta para
@3. Se ajusta solo cuando el corpus crezca.

### 3.20. Con 3 preguntas por dominio la métrica se vuelve binaria

Cada fallo vale 33 puntos y no hay banda intermedia. El set de preguntas-oro
tiene ahora **5-7 por dominio** —según cuántos discriminen— para que @3 pueda
caer en la banda 85-90 %, que es donde aporta algo que @1 no da. Hay un test
que lo fija (`test_hay_bastantes_preguntas_por_dominio_para_resolver`).

### 3.21. Un test que copia un literal no prueba que el defecto no vuelva

Ya estaba documentada como §3.11, pero volvió a picarme: un test que
comprobaba «el umbral se lee como texto» usaba `0,5 %` — que ya da puntaje 3
por la tasa, independientemente del tope. Al reintroducir el defecto (tope
desactivado), el test seguía pasando. Corregido a `0,1 %`, que sin tope daría
4. Regla: **el escenario del test debe DEPENDER del invariante que fija**.

### 3.22. Sandbox de PowerShell bloquea operaciones sobre paths del proyecto

`Remove-Item` sobre un fichero de la raíz del proyecto se rechaza aunque el
comando esté bien escrito. Si tienes que generar un PDF final ahí, usa Python
+ `win32com` (que no cae en esa restricción) y evita cualquier `Remove-Item`
sobre ficheros del árbol vivo.

### 3.23. Los prompts en el fichero de continuidad envejecen

Este documento describe una foto del proyecto en una fecha concreta. Si algo
que aquí sale como «hecho» ya no está o cambió de nombre, es más probable que
la doc esté desfasada a que el código esté roto. **Verifica antes de creer al
prompt.**

---

## 4. Cómo trabajar

```bash
python validate_project.py --strict     # 148 checks, coste 0, exit 1 si falla
python -m pytest -q                     # 835 tests (~5 min)
```

Cada corrección debe llevar: comentario `[AUDIT-FIX]` con **qué hacía antes,
por qué estaba mal y cómo se midió**; un test que falle si el defecto vuelve
—verificado reintroduciéndolo *escrito de otra forma*, no verbatim—; y un
check en `validate_project.py` si el invariante se puede comprobar sin API.

### Verificar sin gastar

La técnica de interceptar `_llamar_modelo` sigue siendo válida. Ejercita el
camino real —parseo, verificación de citas contra la evidencia real,
renderizado al Word— sin API. Lo único simulado es qué contestaría el modelo.
Está documentado en varios tests como referencia (`TestSkillsEnElEntregable`,
`TestCitasInventadasEnSkills`, `TestAuditoriaIntegral20260807`).

### Preguntas de sondeo del RAG (útiles y disponibles)

```bash
python scripts/preguntas_oro_rag.py             # informe completo
python scripts/preguntas_oro_rag.py --strict    # exit 1 si baja del umbral
python scripts/preguntas_oro_rag.py --dominio VaR
```

Cambiando el corpus o los tokens del tesauro, se ve enseguida si el RAG
sigue devolviendo el documento correcto para las 24 consultas de referencia
y si las 4 adversarias siguen declarando su alcance.

---

## 5. ENCARGO PENDIENTE

### 5.1 — Políticas de la entidad ⬛ bloqueante, no es código

`PROCEDIMIENTO_VALIDACION.md` tiene confirmados umbrales de rechazo (< 2,5),
periodicidad, escalado, control del estándar, política de notebooks
(`Restart & Run All`) y **política del tope 3 sobre tolerancia cero
(añadida el 2026-08-08)**. **Siguen sin definir**, marcados ⛔ a propósito:

- **roles y segregación de funciones** (§1);
- **plazo de retención** (§8);
- criterio formal de «hallazgo crítico»;
- umbral de rechazo **por ámbito**;
- activación de la doble firma Tier 1 (construida y probada, apagada).

> **No los inventes.** El encargo original lo prohíbe explícitamente y el
> usuario ya confirmó que no están definidos. Pregunta; si no hay respuesta,
> se quedan en ⛔.

### 5.2 — Corpus RAG oficial ⬛ decisión de proyecto

Sustituir los resúmenes secundarios de `inputs/rag/{LaR,VaR,conductuales,shared}/`
por los textos oficiales: BCBS 238/239/295/457, SR 11-7, EBA/GL, TRIM Guide.
Después reindexar con `force_rebuild=True` y volver a correr
`scripts/verificar_corpus_rag.py`.

Cuando el corpus crezca, el segundo umbral recall@3 se ACTIVARÁ SOLO en más
dominios (hoy ya está activo en 19 de las 24 preguntas gracias al criterio
por chunks). El aviso «RESUMEN SECUNDARIO» del prompt desaparece solo cuando
dejen de detectarse fragmentos marcados así.

### 5.3 — Verificación que sigue sin poder hacerse

Nunca se ha visto, sobre datos reales:

- la **calidad del juicio** del modelo (el cableado sí está probado);
- el juez de código con `--revisar-codigo` sobre un modelo con discrepancias
  reales (probado sobre `modelos/VaR_FixtureDrift`, que es sintético).

**No hay saldo de API para hacerlo, y no está previsto.** Está declarado en
`QUE_HACE_REALMENTE.md` §8 como zona ciega honesta. No lo prometas cubierto.

### 5.4 — Hueco residual conocido, declarado

Un hallazgo de código con el `elemento` mal puesto **y** sin cita escapa a la
verificación de anclaje. Se observó una vez. Cerrarlo exigiría interpretar la
prosa de la descripción — heurística frágil que se descartó a propósito.

### 5.5 — El tope 3 sobre tolerancia cero cambió el histórico

Los informes emitidos ANTES del 2026-08-08 tienen un score de «Calidad de
datos» más benigno. Si el equipo quiere comparar entre corridas, este cambio
importa. Registrado en el commit `f0bffc0`.

---

## 6. Decisiones tomadas que NO hay que revisar

Se discutieron y se cerraron. Reabrirlas sin motivo nuevo es perder tiempo:

| Decisión | Motivo |
|---|---|
| **Doble firma Tier 1 desactivada** | El usuario lo confirmó |
| **Corpus RAG no oficial, por ahora** | Confirmado; se declara en el informe |
| **Tier 1 exige 24 y Tier 4 exige 29** | El usuario confirmó que el Excel es correcto |
| **`--analizar-codigo` NO ejecuta código** | Es del validado; correría con permisos sobre `audit_logs/`. Hay un test que lo impide |
| **Motores de la ENTIDAD son SOLO LECTURA** | Mismo motivo: quien corre la prueba responde de ella. Hay un test AST |
| **La calificación de CDD la gobiernan los motores de la entidad** | Los internos pasan a informativos cuando hay tabla de la entidad |
| **Tope 3 sobre `umbral == 0`, tope 4 en otros casos** | Política del 2026-08-08 |
| **Sin columna Umbral NO se supone tolerancia cero** | Endurecer sobre un dato ausente sería acusar por omisión de formato |
| **Notebooks se entregan ejecutados de arriba abajo** | `Restart & Run All`; §5.1 del procedimiento |
| **El RAG no es un eje de comparación** | Informa los cuatro contrastes existentes; no se añade «RAG vs código» |
| **La coherencia no usa RAG** | Su cometido es manual ↔ implementación |
| **`temperature=0` fijo en la llamada al modelo** | Reproducibilidad; la SDK de Anthropic usa 1.0 por defecto |
| **Recall@1 gobierna siempre; recall@3 solo si `chunks_dominio - chunks_doc ≥ top_k`** | Confianza falsa si no |
| **Los umbrales del pipeline los declara el validador, no el script** | Sin `umbral` el veredicto queda vacío |

---

## 7. Fixtures disponibles

| Ruta | Para qué |
|---|---|
| `modelos/VaR_FRTB` | Modelo coherente: manual y código **coinciden**. Sirve para comprobar que no se inventan discrepancias |
| `modelos/VaR_FixtureDrift` | **4 discrepancias plantadas** y documentadas en su `LEEME.md`. Sirve para probar detección |
| `inputs/calidad_datos/resultadocalidad_de_datos/motores_calidad_2026-08-08.xlsx` | Tabla de motores de la entidad, generada por el pipeline sobre los datasets reales |
| `inputs/calidad_datos/datasets/` | `data_subset.csv` (1203 filas) y `maestro_clientes.csv` (655). Traen incumplimientos reales |

Los dos primeros juntos permiten medir precisión **y** ausencia de falsos
positivos. Úsalos siempre en pareja.

---

## 8. Cómo entregar

1. Ambas puertas en verde, con el número de checks y tests.
2. Los tests nuevos **y la prueba de que detectan el defecto** — reintrodúcelo
   **escrito de otra forma** que el original (trampa §3.11 y §3.21), y muestra
   que falla.
3. Lo que **no** hiciste y por qué.
4. Si el defecto lo introdujiste tú, dilo. En la sesión anterior introduje
   tres —el `autoHyphenation` que documenté mal, la fuente respaldo que no
   escribía nada y el test con literal débil— y decirlo fue lo que permitió
   corregirlos bien.
5. Commit al repo con mensaje que explique el porqué, no el qué. El diff dice
   qué; el mensaje debe decir qué se rompía antes.

---

## 9. Aviso final

> **Prefiere siempre declarar una ausencia antes que rellenar un hueco.**

Todo el diseño sale de ahí: la actividad sin evaluar queda sin puntaje; la cita
que no se encuentra se marca; el documento recortado dice cuánto; el corpus no
oficial lo declara el informe; el dominio inferido se distingue del declarado;
la tabla sin columna `Umbral` no se interpreta como tolerancia cero.

Y su corolario, que costó dos defectos más aprender esta sesión: **un aviso
que salta cuando no debe es tan dañino como uno que no salta.** Si un control
marca como sospechoso algo correcto —una tasa del 0,32 % dada por OK con un
umbral del 0,5 %, un documento en segundo puesto cuando el modelo lo sigue
viendo—, el equipo aprende a ignorarlo y con él pasan los verdaderos. Los
falsos positivos son un defecto, no una precaución.
