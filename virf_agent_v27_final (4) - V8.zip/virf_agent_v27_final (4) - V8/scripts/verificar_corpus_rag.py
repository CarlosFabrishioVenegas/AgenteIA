"""
scripts/verificar_corpus_rag.py
═══════════════════════════════════════════════════════════════════════════════
VERIFICADOR DEL CORPUS RAG — ¿el índice contiene lo que dice contener?

[PENDIENTE-4] Coste 0: no llama al modelo.

Para qué sirve
──────────────
`inputs/rag/<dominio>/` contiene hoy 8 PDF generados por
`scripts/generar_corpus_rag.py` a partir de marcos públicos. **No son los textos
oficiales**, y cada uno lo declara en portada, pie y dentro de su texto
indexable. Sustituirlos por los PDF oficiales (BCBS 238/239/295/457, SR 11-7,
EBA/GL, TRIM Guide) exige descargarlos manualmente — es lo único que este script
NO puede hacer por ti.

Lo que sí hace es responder, antes y después de la sustitución, las cuatro
preguntas que deciden si el RAG aporta o estorba:

  1. PROCEDENCIA — ¿son textos oficiales o resúmenes secundarios? Se detecta por
     el aviso que `generar_corpus_rag.py` inserta en el texto INDEXABLE, no solo
     en la portada: si el aviso está en el índice, el modelo lo está leyendo.

  2. COBERTURA — ¿el índice existe y tiene fragmentos? Que el `.pkl` exista no
     prueba que contenga nada.

  3. CONTAMINACIÓN CRUZADA — ¿cada dominio contiene SOLO lo suyo? Este es el
     defecto que ya se produjo una vez: los cuatro índices llenos del mismo
     manual, porque todos los indexadores apuntaban a las mismas carpetas de
     `inputs/`. Un índice «VaR» lleno de LaR devuelve fragmentos plausibles y
     ajenos, que es peor que no devolver nada.

  4. RECUPERACIÓN EFECTIVA — ¿una consulta propia del dominio recupera algo?
     Un índice íntegro pero que no responde a su propio vocabulario no aporta.

Y, con `--informe`, la quinta pregunta, que es la única que se contesta sobre
una corrida real: **¿`rag_chunks > 0`?** Que el índice exista y responda en el
banco de pruebas no demuestra que el pipeline lo esté inyectando en el prompt.

Uso
───
    python scripts/verificar_corpus_rag.py
    python scripts/verificar_corpus_rag.py --informe outputs/2026-08-03/resultados_X.json

Sale con código 1 si algún dominio falla una comprobación estructural
(2, 3 o 5). La procedencia (1) se REPORTA pero no tumba la ejecución: mientras
no existan los PDF oficiales, un corpus de resúmenes correctamente etiquetado es
el estado conocido y aceptado del proyecto — lo inadmisible sería que dejara de
estar etiquetado.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Dict, List

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

# La consola de Windows es cp1252 al redirigir la salida, y este informe lleva
# cajas y flechas. Sin esto, `... | tee log.txt` aborta con UnicodeEncodeError
# DESPUÉS de haber hecho todo el trabajo. Se reutiliza el módulo del proyecto
# en vez de un `reconfigure` propio: ya cubre los flujos no reconfigurables.
try:
    from modulos.consola import configurar_consola
    configurar_consola()
except Exception:                                          # pragma: no cover
    pass

#: Marca que `generar_corpus_rag.py` inserta en el texto indexable de cada PDF
#: que produce. Su presencia en el índice significa que el fragmento NO procede
#: de un texto oficial. Se compara en mayúsculas y sin acentos por robustez
#: frente a cómo lo extraiga pdfminer.
MARCA_NO_OFICIAL = "NO ES EL TEXTO OFICIAL"

#: Consultas de sondeo por dominio: vocabulario propio y característico. No son
#: exhaustivas; sirven para detectar un índice que no responde a lo suyo.
SONDEOS: Dict[str, List[str]] = {
    "VaR": ["backtesting excepciones Kupiec", "expected shortfall FRTB"],
    "LaR": ["coeficiente de cobertura de liquidez LCR",
            "financiación estable disponible NSFR"],
    "ALM": ["depósitos sin vencimiento NMD repreciación",
                     "riesgo de tipo de interés IRRBB"],
    "shared": ["gestión del riesgo de modelo validación independiente",
               "agregación de datos de riesgo"],
}

DOMINIOS = list(SONDEOS)


def _norm(texto: str) -> str:
    import unicodedata
    sin_acentos = "".join(
        c for c in unicodedata.normalize("NFKD", str(texto or ""))
        if not unicodedata.combining(c))
    return " ".join(sin_acentos.upper().split())


# ═════════════════════════════════════════════════════════════════════════════
# Comprobaciones
# ═════════════════════════════════════════════════════════════════════════════

def _ficheros_esperados(dominio: str) -> set:
    """Nombres de los ficheros fuente que ESTE dominio debe contener."""
    carpeta = RAIZ / "inputs" / "rag" / dominio
    if not carpeta.is_dir():
        return set()
    return {f.name for f in carpeta.iterdir()
            if f.is_file() and f.suffix.lower() in (".pdf", ".md", ".txt")
            and f.name.lower() != "readme.md"}


def verificar_dominio(dominio: str) -> Dict:
    """Comprobaciones 1-4 sobre un dominio."""
    res = {
        "dominio": dominio,
        "problemas": [],
        "avisos": [],
        "n_chunks": 0,
        "n_no_oficiales": 0,
        "fuentes_en_indice": [],
        "ajenas": [],
        "sondeos": {},
    }

    # `IndexadorLexico(...).cargar()` y NO `Indexer().cargar_indice()`: el
    # segundo CONSTRUYE el índice si no sirve, y un verificador que repara lo
    # que va a verificar no puede detectar «el índice está vacío» ni «las
    # fuentes cambiaron y nadie reindexó» — los arreglaría antes de mirarlos.
    # `cargar()` devuelve None en esos cuatro casos, que es la señal buscada.
    indice = None
    try:
        from src.rag.indexador_lexico import IndexadorLexico
        indice = IndexadorLexico(dominio).cargar()
    except Exception as exc:
        res["problemas"].append(f"no se pudo cargar el índice: {exc}")
        return res

    if indice is None:
        res["problemas"].append(
            "índice ausente, corrupto, de formato anterior, o construido sobre "
            "unas fuentes que ya cambiaron. Reindexar: "
            f"`{dominio}Indexer().build_index(force_rebuild=True)`")
        return res

    chunks = list(getattr(indice, "chunks", []) or [])
    res["n_chunks"] = len(chunks)

    # ── 2. Cobertura ─────────────────────────────────────────────────────────
    if not chunks:
        res["problemas"].append(
            "el índice existe pero está VACÍO: que el .pkl esté en disco no "
            "prueba que aporte nada al prompt")
        return res

    # ── 1. Procedencia ───────────────────────────────────────────────────────
    no_oficiales = [c for c in chunks
                    if MARCA_NO_OFICIAL in _norm(c.get("texto", ""))]
    res["n_no_oficiales"] = len(no_oficiales)
    if no_oficiales:
        res["avisos"].append(
            f"{len(no_oficiales)} de {len(chunks)} fragmentos proceden de "
            f"RESÚMENES SECUNDARIOS, no del texto oficial")

    # ── 3. Contaminación cruzada ─────────────────────────────────────────────
    propias = _ficheros_esperados(dominio)
    ajenas_otros = set()
    for otro in DOMINIOS:
        if otro != dominio:
            ajenas_otros |= _ficheros_esperados(otro)

    fuentes = sorted({Path(str(c.get("fuente")
                                 or (c.get("metadata") or {}).get("fuente")
                                 or "")).name
                      for c in chunks} - {""})
    res["fuentes_en_indice"] = fuentes

    ajenas = [f for f in fuentes if f in ajenas_otros and f not in propias]
    desconocidas = [f for f in fuentes
                    if f not in propias and f not in ajenas_otros]
    res["ajenas"] = ajenas
    if ajenas:
        res["problemas"].append(
            f"CONTAMINACIÓN CRUZADA: el índice contiene documentos de otro "
            f"dominio ({', '.join(ajenas)}). Un índice «{dominio}» que devuelve "
            f"fragmentos ajenos produce citas plausibles y equivocadas")
    if desconocidas:
        res["avisos"].append(
            f"fuentes que no están en inputs/rag/{dominio}/: "
            f"{', '.join(desconocidas)}")

    faltan = sorted(propias - set(fuentes))
    if faltan:
        res["problemas"].append(
            f"documentos presentes en inputs/rag/{dominio}/ pero AUSENTES del "
            f"índice ({', '.join(faltan)}): reindexar con force_rebuild=True")

    # ── 4. Recuperación efectiva ─────────────────────────────────────────────
    try:
        from importlib import import_module
        mod = import_module(f"src.rag.{dominio}.retriever")
        # Se busca por `dominio`, NO por «la primera clase cuyo nombre acaba en
        # Retriever». `vars(mod)` incluye `BaseRetriever`, que el módulo importa
        # y que aparece ANTES en el orden de inserción; al instanciarla se
        # obtenía un retriever de dominio "base", sin índice, y los cuatro
        # dominios reportaban «no recupera NADA de su propio dominio».
        #
        # Un falso positivo así es peor que no comprobar: acusa de estar roto a
        # un RAG que funciona, y el equipo aprende a ignorar el verificador.
        clase = next(v for v in vars(mod).values()
                     if isinstance(v, type)
                     and getattr(v, "dominio", None) == dominio)
        retr = clase()
        for consulta in SONDEOS[dominio]:
            hits = retr.query(consulta, top_k=3) or []
            res["sondeos"][consulta] = len(hits)
            if not hits:
                res["problemas"].append(
                    f"la consulta «{consulta}» no recupera NADA de su propio "
                    f"dominio: el índice no responde a su vocabulario")
    except Exception as exc:
        res["avisos"].append(f"no se pudo sondear la recuperación: {exc}")

    return res


def verificar_informe(ruta_json) -> Dict:
    """
    Comprobación 5: ¿el RAG llegó realmente al prompt en una corrida real?

    Es la única que se contesta sobre una corrida: un índice puede existir,
    estar limpio y responder en el banco de pruebas, y aun así no inyectarse.
    """
    ruta = Path(ruta_json)
    datos = json.loads(ruta.read_text(encoding="utf-8"))
    total = con_rag = 0
    por_dominio: Dict[str, int] = {}
    for _amb, evs in (datos.get("resultados_por_ambito") or {}).items():
        for ev in evs or []:
            total += 1
            # `or 0` y no `.get("rag_chunks", 0)`: §3.4 — el respaldo de `.get`
            # no actúa si la clave existe con valor nulo.
            n = ev.get("rag_chunks") or 0
            if n > 0:
                con_rag += 1
                dom = ev.get("rag_dominio") or "(sin dominio)"
                por_dominio[dom] = por_dominio.get(dom, 0) + n
    return {
        "informe": ruta.name,
        "modelo": datos.get("modelo"),
        "n_actividades": total,
        "n_con_rag": con_rag,
        "chunks_por_dominio": por_dominio,
        "aporta": con_rag > 0,
    }


# ═════════════════════════════════════════════════════════════════════════════
# Presentación
# ═════════════════════════════════════════════════════════════════════════════

def main() -> int:
    ap = argparse.ArgumentParser(
        description="Verifica el corpus RAG: procedencia, cobertura, "
                    "contaminación cruzada y recuperación. Coste 0.")
    ap.add_argument("--informe", default=None, metavar="RESULTADOS.JSON",
                    help="JSON de una corrida real: comprueba que rag_chunks > 0")
    args = ap.parse_args()

    print("\n" + "═" * 74)
    print("  📚 VERIFICACIÓN DEL CORPUS RAG")
    print("═" * 74)

    fallo = False
    resumen_no_oficial = 0
    for dominio in DOMINIOS:
        r = verificar_dominio(dominio)
        icono = "❌" if r["problemas"] else ("⚠️ " if r["avisos"] else "✅")
        print(f"\n  {icono} {dominio}   ·   {r['n_chunks']} fragmentos")
        if r["fuentes_en_indice"]:
            for f in r["fuentes_en_indice"]:
                marca = "  ← AJENO" if f in r["ajenas"] else ""
                print(f"        · {f}{marca}")
        for consulta, n in r["sondeos"].items():
            print(f"        sondeo «{consulta[:44]}»: {n} resultado(s)")
        for p in r["problemas"]:
            print(f"        ⛔ {p}")
        for a in r["avisos"]:
            print(f"        ⚠️  {a}")
        resumen_no_oficial += r["n_no_oficiales"]
        if r["problemas"]:
            fallo = True

    if args.informe:
        print("\n" + "─" * 74)
        print("  ¿El RAG llegó al prompt en la corrida real?")
        try:
            ri = verificar_informe(args.informe)
            print(f"\n  Informe : {ri['informe']}")
            print(f"  Modelo  : {ri['modelo']}")
            print(f"  Actividades con fragmentos RAG: {ri['n_con_rag']} "
                  f"de {ri['n_actividades']}")
            for dom, n in sorted(ri["chunks_por_dominio"].items()):
                print(f"        · {dom}: {n} fragmentos inyectados")
            if not ri["aporta"]:
                print("\n  ⛔ rag_chunks = 0 en TODAS las actividades: el índice "
                      "existe pero\n     no se está inyectando. Que exista no "
                      "prueba que aporte.")
                fallo = True
        except Exception as exc:
            print(f"  ⛔ No se pudo leer el informe: {exc}")
            fallo = True

    print("\n" + "─" * 74)
    if resumen_no_oficial:
        print(f"  ⚠️  PROCEDENCIA: {resumen_no_oficial} fragmentos proceden de "
              f"resúmenes\n      secundarios, no de los textos oficiales.")
        print("      Estado conocido del proyecto. Para cerrarlo: sustituir los")
        print("      PDF de inputs/rag/<dominio>/ por BCBS 238/239/295/457,")
        print("      SR 11-7, EBA/GL y TRIM Guide, y reindexar con")
        print("      force_rebuild=True. Después, volver a ejecutar este script.")
        print("      No tumba la verificación: el corpus está ETIQUETADO como")
        print("      tal, y eso es lo que lo hace admisible mientras dure.")
    if fallo:
        print("\n  ❌ El corpus RAG tiene defectos ESTRUCTURALES (arriba).")
    else:
        print("\n  ✅ Estructura del corpus correcta: sin contaminación cruzada,")
        print("     cada dominio recupera lo suyo.")
    print("═" * 74 + "\n")
    return 1 if fallo else 0


if __name__ == "__main__":
    sys.exit(main())
