#!/usr/bin/env python3
"""
scripts/verificar_remoto_git.py  [SEG-11]
═════════════════════════════════════════════════════════════════════════════
Comprueba que TODOS los remotos git apuntan al repositorio corporativo (Azure
DevOps del banco). Un remoto en GitHub, GitLab, Bitbucket o cualquier otro host
hace fallar la verificación: el código y el registro de auditoría versionado
no pueden salir a nubes de código no autorizadas.

Hosts permitidos: dev.azure.com, ssh.dev.azure.com y *.visualstudio.com. Si el
banco fija VIRF_REPO_CORPORATIVO (URL completa), SOLO ese repositorio vale.

    python scripts/verificar_remoto_git.py      # 0 = correcto, 1 = remoto no autorizado
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path
from typing import List, Optional
from urllib.parse import urlsplit

RAIZ = Path(__file__).resolve().parent.parent
_HOSTS = ("dev.azure.com", "ssh.dev.azure.com")
_SUFIJOS = (".visualstudio.com",)


def host_de(url: str) -> str:
    url = url.strip()
    m = re.match(r"^[\w.-]+@([\w.-]+):", url)          # git@host:ruta (scp-like)
    if m:
        return m.group(1).lower()
    return (urlsplit(url).hostname or "").lower()


def _normalizar(url: str) -> str:
    return re.sub(r"(\.git)?/*$", "", url.strip().lower())


def remoto_autorizado(url: str, corporativo: Optional[str] = None) -> bool:
    if corporativo is None:
        sys.path.insert(0, str(RAIZ))
        from config.parametros import repo_corporativo
        corporativo = repo_corporativo()
    if corporativo.strip():
        return _normalizar(url) == _normalizar(corporativo)
    h = host_de(url)
    return h in _HOSTS or h.endswith(_SUFIJOS)


def remotos(salida: Optional[str] = None) -> List[str]:
    if salida is None:
        salida = subprocess.run(["git", "remote", "-v"], cwd=RAIZ, capture_output=True,
                                text=True, check=False).stdout
    return sorted({l.split()[1] for l in salida.splitlines() if len(l.split()) >= 2})


def no_autorizados(salida: Optional[str] = None) -> List[str]:
    return [u for u in remotos(salida) if not remoto_autorizado(u)]


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    malos = no_autorizados()
    if malos:
        for u in malos:
            print(f"✗ remoto NO autorizado: {host_de(u) or u}")
        print("  Solo se admite el repositorio corporativo (Azure DevOps del banco).")
        return 1
    print(f"✓ Remotos correctos ({len(remotos())}).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
