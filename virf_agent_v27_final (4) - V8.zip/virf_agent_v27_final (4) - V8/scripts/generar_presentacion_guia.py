"""
scripts/generar_presentacion_guia.py — Presentación (.pptx) «Guía de la herramienta VIRF».

Genera `docs/agente_corporativo/GUIA_VIRF_PRESENTACION.pptx` a partir del PROPIO repositorio,
para que la presentación no se quede atrás cuando cambia el código:

  · Recorrido por la interfaz: capturas `docs/agente_corporativo/capturas/NN_*.jpg` y la tabla
    PANTALLAS de `scripts/generar_guia_agente.py` (qué es cada pantalla, endpoints, archivos).
  · Páginas de muestra de los informes Word: PDF de `ejemplos/` (si existen).
  · Regla de calificación: los ejemplos y la escala puntaje → riesgo se CALCULAN con
    `modulos/reglas_informe.py`, no se escriben a mano.
  · Reglas de oro y mapa síntoma → skill: se leen de `docs/agente_corporativo/CONOCIMIENTO_VIRF.md`.

Uso:
    .venv\\Scripts\\python.exe scripts\\generar_presentacion_guia.py
    .venv\\Scripts\\python.exe scripts\\generar_presentacion_guia.py --salida otra_ruta.pptx

No llama a ninguna IA. Solo necesita python-pptx, Pillow y pypdfium2 (ya en el .venv).
"""
from __future__ import annotations

import argparse
import re
import sys
import tempfile
from datetime import date
from pathlib import Path
from typing import Iterable, Optional

RAIZ = Path(__file__).resolve().parent.parent
for _p in (RAIZ, RAIZ / "scripts"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from lxml import etree  # noqa: E402
from PIL import Image  # noqa: E402
from pptx import Presentation  # noqa: E402
from pptx.dml.color import RGBColor  # noqa: E402
from pptx.enum.shapes import MSO_SHAPE  # noqa: E402
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN  # noqa: E402
from pptx.oxml.ns import qn  # noqa: E402
from pptx.util import Emu, Inches, Pt  # noqa: E402

from generar_guia_agente import PANTALLAS  # noqa: E402
from modulos import reglas_informe as R  # noqa: E402

DIR_GUIA = RAIZ / "docs" / "agente_corporativo"
DIR_CAPTURAS = DIR_GUIA / "capturas"
SALIDA = DIR_GUIA / "GUIA_VIRF_PRESENTACION.pptx"
LOGO = RAIZ / "inputs" / "logoempresa" / "Logo-bcp-vector.svg.webp"
EJ_RESULTADOS = RAIZ / "ejemplos" / "Ejemplo_Informe_Resultados_LaR.pdf"
EJ_WEB_CAPTURAS = RAIZ / "ejemplos" / "Ejemplo_Informe_Web_LaR_real_con_capturas.pdf"

# ── Paleta: la de la web (tinta oscura, sello bermellón, mostaza) ───────
TINTA = RGBColor(0x14, 0x17, 0x1F)
TINTA2 = RGBColor(0x1F, 0x23, 0x2E)
PAPEL = RGBColor(0xF6, 0xF2, 0xEB)
BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
SELLO = RGBColor(0xB8, 0x4A, 0x3A)
MOSTAZA = RGBColor(0xD9, 0xA4, 0x41)
VERDE = RGBColor(0x4E, 0x7D, 0x5B)
NARANJA = RGBColor(0xD0, 0x7A, 0x34)
TEXTO = RGBColor(0x23, 0x26, 0x30)
TENUE = RGBColor(0x6B, 0x70, 0x7D)
LINEA = RGBColor(0xDD, 0xD6, 0xCA)
CLARO_TENUE = RGBColor(0xA9, 0xAE, 0xBA)
SELLO_SUAVE = RGBColor(0xF3, 0xE1, 0xDC)
MOSTAZA_SUAVE = RGBColor(0xF6, 0xEB, 0xD3)
VERDE_SUAVE = RGBColor(0xE0, 0xEC, 0xE2)

TITULAR, CUERPO, MONO = "Cambria", "Calibri", "Consolas"
ANCHO, ALTO = Inches(13.333), Inches(7.5)
MARGEN = 0.6

COLOR_NIVEL = {"Deficiente": SELLO, "Regular": NARANJA, "Aceptable": MOSTAZA, "Satisfactorio": VERDE}
COLOR_RIESGO = {"Crítico": SELLO, "Moderado": NARANJA, "Oportunidad de Mejora": MOSTAZA, None: VERDE}

# ── Cómo se usa cada pantalla (complementa la tabla PANTALLAS) ──────────
# clave de captura → (pasos para el usuario, «tenga en cuenta»)
USO = {
    "01_login": (
        ["Abra http://localhost:8000 en el navegador.",
         "Escriba su **código de validador** (T + 3 a 7 dígitos, p. ej. T5443) y su nombre.",
         "Pulse **Entrar**. Si el código es nuevo, se registra en ese momento."],
        "La sesión vive en la memoria del servidor: si se reinicia, vuelva a entrar. "
        "Sus expedientes y archivos siguen guardados en disco."),
    "02_mis_modelos": (
        ["Revise la lista: dominio, tier, estado y última actividad de cada modelo.",
         "Haga clic en una fila (o Tab + **Enter**) para abrir el expediente.",
         "**Nuevo modelo** crea un expediente; **Solo Informe** abre el modo sin pipeline."],
        "Cada validador ve solo sus propios modelos."),
    "03_nuevo_modelo": (
        ["Escriba el nombre del modelo (p. ej. «LaR Depósitos a la Vista»).",
         "Elija el **dominio**: VaR, LaR, ALM o uno personalizado.",
         "Elija el **tier** y pulse **Crear**: se abre el expediente."],
        "El dominio decide qué literatura técnica (RAG) usa el agente y no se puede cambiar "
        "después. Elíjalo con cuidado."),
    "04_dashboard_inicio": (
        ["Lea el recuadro **Siguiente paso**: dice qué falta y lleva directo a ese paso.",
         "La barra muestra cuántos de los **6 pasos obligatorios** están hechos.",
         "El menú lateral lleva a los pasos 01–09 y a las consultas."],
        "Un ✓ verde indica paso hecho; «SIGUIENTE» en bermellón marca el próximo obligatorio."),
    "05_configuracion": (
        ["Revise el título del modelo y su tier.",
         "Elija el proveedor de IA: **Azure OpenAI** (el del corporativo), OpenAI o Claude.",
         "Pulse **Verificar conexión**: hace una llamada mínima y confirma la credencial.",
         "Deje **VIRF PLUS** apagado salvo que tenga GPT y Claude a la vez."],
        "Las claves se guardan en el archivo .env del proyecto. Nunca las pegue en el chat "
        "ni en un correo."),
    "06_estandares": (
        ["Suba el **Estandares_VIRF.xlsx** del modelo (Ámbito, Control General, Control "
         "Específico, Actividad).",
         "Revise la vista previa agrupada por ámbito.",
         "Pulse **Confirmar**: ese estándar es la vara de medir de la validación."],
        "Sin estándar confirmado no se puede lanzar la validación."),
    "07_evidencia": (
        ["Suba la documentación en su carpeta: modelamiento, seguimiento, controles de datos.",
         "Suba el **ZIP del código** en Implementación (se descomprime solo).",
         "Si aplica: datasets, resultados de calidad de datos y Excels 00–03 de automatización.",
         "Opcional: pida el **Entendimiento del modelo** a partir del código."],
        "El paso queda hecho con al menos un documento y el código. El código del modelo se "
        "lee, nunca se ejecuta."),
    "08_dominio_rag": (
        ["Compruebe el dominio del modelo.",
         "Revise la literatura técnica disponible para ese dominio.",
         "Si falta, suba papers (PDF) y pulse **Reconstruir índice**."],
        "La literatura es compartida por todos los validadores. La búsqueda es léxica y local "
        "(BM25 + TF-IDF): no usa embeddings ni servicios externos."),
    "09_skills": (
        ["Active los análisis que aporten: coherencia documental, código vs manual, patrones "
         "problemáticos, backtesting, síntesis…",
         "Guarde la selección (vale para esta sesión)."],
        "Paso opcional. Las skills producen hallazgos adicionales; no cambian el puntaje."),
    "10_cuestionamientos": (
        ["Revise los **15 patrones** que el agente busca en el código (data leakage, "
         "imputación por media, look-ahead bias…).",
         "Añada preguntas propias en lenguaje natural.",
         "Guarde: el agente las responde durante la corrida."],
        "Paso opcional, pero recomendable en modelos con código propio."),
    "11_validar": (
        ["Escriba nombre y cargo del **validador firmante** (doble firma opcional).",
         "Pulse **Lanzar validación**: corre el pipeline completo.",
         "Siga la consola en vivo; al terminar queda un JSON de resultados.",
         "Revise el resultado en **Consultas › Resultados**."],
        "Cada corrida hace llamadas reales a la IA (coste en la cuenta de Azure). Haga antes "
        "el pre-vuelo."),
    "12_documentar": (
        ["Revise el estado: evidencia, JSON de resultados, chat y corrida.",
         "Si hay Excels de automatización, genere el **cuadro de observaciones**.",
         "Pulse **Generar informe**: crea un Word versionado (V1, V2…).",
         "Descargue el Word y revíselo antes de enviarlo."],
        "Una observación que el chat cerró como APROBADO aparece como subsanada en el informe."),
    "13_resultados": (
        ["Elija la corrida que quiere revisar.",
         "Lea el puntaje global, el semáforo y las políticas aplicadas (§6 críticos, §4.2 veto).",
         "Abra una actividad para ver su evidencia citada y verifique la cita."],
        "Una actividad sin puntaje es «no evaluada» (fallo técnico): se re-ejecuta, no se califica."),
    "14_controles_datos": (
        ["Consulte el catálogo de motores: completitud, duplicados, integridad referencial, "
         "rangos…",
         "Revise los resultados entregados por la entidad.",
         "Descargue el **notebook** ejecutable de controles para el entregable."],
        "Los controles de datos son deterministas: la IA no calcula resultados."),
    "15_chat": (
        ["Inicie el chat: el agente presenta las observaciones.",
         "El área sustenta cada una; se puede adjuntar evidencia nueva.",
         "El validador decide: **APROBADO**, **NEGADO** o **PENDIENTE**.",
         "Pulse **Consolidar**: recalcula el puntaje y descarga el acta de cierre (Excel)."],
        "La decisión final siempre es del validador; el agente solo propone."),
    "16_guia_ayuda": (
        ["Pulse el botón **?** (abajo a la derecha) en cualquier pantalla.",
         "Vea cada paso con su estado: hecho, siguiente, pendiente u opcional.",
         "Lea qué falta en cada paso y vaya directo a él."],
        "Es la forma más rápida de saber por qué un paso no aparece como hecho."),
    "17_solo_informe": (
        ["Desde **Mis Modelos** pulse **Solo Informe**.",
         "Compruebe el proveedor de IA activo (o «IA no configurada»: todo funciona igual sin IA).",
         "Suba el **Excel del estándar**; si trae columnas TIER, se filtra por el tier elegido.",
         "Opcional: suba los manuales del modelo (PDF, DOCX, TXT, MD) para que la IA cite archivo y página."],
        "No ejecuta el pipeline ni llama a la IA salvo que usted pulse un botón de IA."),
    "18_solo_informe_datos": (
        ["Elija el tipo: **Periódica** o **Por Primera Vez**, y el tier.",
         "Complete modelo, fechas de inicio y de entrega, responsable de la documentación y "
         "revisor (Walter Paiva por defecto).",
         "Escriba contexto y limitaciones; use **Pulir con IA** o **Redactar desde los manuales** si quiere."],
        "Todo se guarda solo como borrador en el servidor: puede cerrar y volver."),
    "19_solo_informe_observacion": (
        ["Elija ámbito, riesgo y la **actividad** del estándar (filtrada por ámbito).",
         "Escriba observación y recomendación; responsable y fecha de subsanación.",
         "Adjunte el sustento: imagen, fragmento de código o texto.",
         "**Añadir observación** y, al final, **Generar informe Word**."],
        "Una Oportunidad de Mejora no lleva responsable ni fecha y no incumple el control."),
}

PREVUELO = (
    "Paso 07 · Pre-vuelo",
    "Revisa la evidencia ANTES de gastar en la validación. No llama a la IA, no puntúa y no "
    "predice hallazgos: responde «con esta evidencia, ¿qué va a poder evaluar el agente?».",
    [("PDF escaneados", "Sin texto extraíble no hay nada que evaluar: se avisa antes de la corrida."),
     ("Formatos que no se leen", "Un .scala o .yaml se omitiría sin aviso: el pre-vuelo lo lista."),
     ("Carpetas vacías", "Un ámbito sin evidencia puntúa 0 = falta crítica. Mejor detectarlo a tiempo."),
     ("Trabajo adelantado", "Las lecturas pasan por la caché (SHA-256): la corrida real las reutiliza.")],
    "POST /api/prevuelo ·modulos/prevuelo.py · web/routers/dominio_prevuelo.py",
)


# ══════════════════════════════════════════════════════════════════════
#  Lectura de contenido del repositorio
# ══════════════════════════════════════════════════════════════════════

def _seccion_md(texto: str, prefijo: str) -> str:
    """Cuerpo de la sección `## {prefijo}…` de un Markdown (hasta la siguiente `## `)."""
    m = re.search(rf"^## {re.escape(prefijo)}.*?$(.*?)(?=^## |\Z)", texto, re.S | re.M)
    return m.group(1) if m else ""


def reglas_de_oro(conocimiento: str) -> list[str]:
    cuerpo = _seccion_md(conocimiento, "8.")
    reglas: list[str] = []
    for linea in cuerpo.splitlines():
        m = re.match(r"^\d+\.\s+(.*)$", linea)
        if m:
            reglas.append(m.group(1).strip())
        elif reglas and linea.startswith(" ") and linea.strip():
            reglas[-1] += " " + linea.strip()  # continuación del punto anterior
    return [re.sub(r"`([^`]*)`", r"\1", r) for r in reglas]


def sintoma_skill(conocimiento: str) -> list[tuple[str, str]]:
    cuerpo = _seccion_md(conocimiento, "11.")
    filas = []
    for linea in cuerpo.splitlines():
        celdas = [c.strip() for c in linea.strip().strip("|").split("|")]
        if len(celdas) == 2 and not set(celdas[0]) <= set("-: ") and celdas[0] != "Síntoma":
            filas.append((celdas[0], celdas[1]))
    return filas


def ejemplos_calificacion() -> list[tuple[str, list[dict], dict]]:
    """Casos típicos calificados con la regla real (`reglas_informe.concluir`)."""
    def obs(riesgo, ambito="Metodología", n=1):
        return [{"riesgo": riesgo, "ambito": ambito}] * n
    casos = [
        ("3 críticas", obs("Crítico", n=3)),
        ("2 críticas", obs("Crítico", n=2)),
        ("2 moderadas (Metodología)", obs("Moderado", n=2)),
        ("2 moderadas (Documentación + Gobierno)", obs("Moderado", "Documentación") + obs("Moderado", "Gobierno")),
        ("1 moderada + 3 bajas", obs("Moderado") + obs("Bajo", n=3)),
        ("5 bajas", obs("Bajo", n=5)),
        ("4 bajas + 6 Oportunidades de Mejora", obs("Bajo", n=4) + obs("Oportunidad de Mejora", n=6)),
    ]
    return [(nombre, o, R.concluir(o)) for nombre, o in casos]


def _escala_puntaje() -> list[tuple[str, Optional[str]]]:
    filas = [(str(p), R.riesgo_desde_puntaje(p)) for p in (0, 1, 2, 3, 4, 5)]
    return filas


# ══════════════════════════════════════════════════════════════════════
#  Primitivas de dibujo
# ══════════════════════════════════════════════════════════════════════

class Mazo:
    """Presentación 16:9 con secciones, numeración y notas en cada diapositiva."""

    def __init__(self, tmp: Path):
        self.prs = Presentation()
        self.prs.slide_width, self.prs.slide_height = ANCHO, ALTO
        self._tema()
        self.tmp = tmp
        self.secciones: list[tuple[str, list]] = []
        self.n = 0

    # ── tema: colores y fuentes del documento (para lo que se añada a mano en PowerPoint)
    def _tema(self):
        master = self.prs.slide_masters[0]
        for rel in master.part.rels.values():
            if rel.reltype.endswith("/theme"):
                parte = rel.target_part
                raiz = etree.fromstring(parte.blob)
                ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
                raiz.set("name", "VIRF")
                colores = {"dk1": "14171F", "lt1": "FFFFFF", "dk2": "232630", "lt2": "F6F2EB",
                           "accent1": "B84A3A", "accent2": "D9A441", "accent3": "4E7D5B",
                           "accent4": "D07A34", "accent5": "6B707D", "accent6": "2F4A6D",
                           "hlink": "B84A3A", "folHlink": "6B707D"}
                esquema = raiz.find(".//a:clrScheme", ns)
                esquema.set("name", "VIRF")
                for nombre, hexa in colores.items():
                    nodo = esquema.find(f"a:{nombre}", ns)
                    for h in list(nodo):
                        nodo.remove(h)
                    etree.SubElement(nodo, qn("a:srgbClr")).set("val", hexa)
                for tipo, fuente in (("majorFont", TITULAR), ("minorFont", CUERPO)):
                    raiz.find(f".//a:{tipo}/a:latin", ns).set("typeface", fuente)
                parte._blob = etree.tostring(raiz, xml_declaration=True, encoding="UTF-8",
                                             standalone=True)

    def nueva(self, seccion: str, oscura: bool = False, notas: str = ""):
        if not self.secciones or self.secciones[-1][0] != seccion:
            self.secciones.append((seccion, []))
        s = self.prs.slides.add_slide(self.prs.slide_layouts[6])  # en blanco
        self.secciones[-1][1].append(s)
        self.n += 1
        fondo = s.background.fill
        fondo.solid()
        fondo.fore_color.rgb = TINTA if oscura else PAPEL
        if notas:
            s.notes_slide.notes_text_frame.text = notas
        if self.n > 1:
            self._pie(s, oscura)
        return s

    def _pie(self, s, oscura: bool):
        color = CLARO_TENUE if oscura else TENUE
        texto(s, MARGEN, 7.05, 6, 0.3, "VIRF · Guía de la herramienta", 10, color)
        texto(s, 13.333 - MARGEN - 1, 7.05, 1, 0.3, str(self.n), 10, color, alinear=PP_ALIGN.RIGHT)

    def guardar(self, ruta: Path):
        self._escribir_secciones()
        ruta.parent.mkdir(parents=True, exist_ok=True)
        self.prs.save(ruta)

    def _escribir_secciones(self):
        """Secciones de PowerPoint (p14:sectionLst) para navegar el mazo por temas."""
        p14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
        pres = self.prs.part._element
        ext_lst = pres.find(qn("p:extLst"))
        if ext_lst is None:
            ext_lst = etree.SubElement(pres, qn("p:extLst"))
        ext = etree.SubElement(ext_lst, qn("p:ext"))
        ext.set("uri", "{521415D9-36F7-43E2-AB2F-B90AF26B5E84}")
        lista = etree.SubElement(ext, f"{{{p14}}}sectionLst", nsmap={"p14": p14})
        ids = {s.slide_id for _, ss in self.secciones for s in ss}
        assert len(ids) == len(self.prs.slides)
        for k, (nombre, diapos) in enumerate(self.secciones):
            sec = etree.SubElement(lista, f"{{{p14}}}section")
            sec.set("name", nombre)
            sec.set("id", "{%08X-0000-4000-8000-%012X}" % (k + 1, k + 1))
            lst = etree.SubElement(sec, f"{{{p14}}}sldIdLst")
            for d in diapos:
                etree.SubElement(lst, f"{{{p14}}}sldId").set("id", str(d.slide_id))


def _runs(parrafo, contenido: str, tam: float, color: RGBColor, fuente: str, negrita: bool,
          cursiva: bool = False, color_negrita: Optional[RGBColor] = None):
    """Escribe `contenido` en el párrafo; los tramos entre ** van en negrita."""
    for i, trozo in enumerate(re.split(r"\*\*", contenido)):
        if not trozo:
            continue
        r = parrafo.add_run()
        r.text = trozo
        f = r.font
        f.size, f.name, f.italic = Pt(tam), fuente, cursiva
        f.bold = negrita or bool(i % 2)
        f.color.rgb = (color_negrita or color) if i % 2 else color


def texto(s, x, y, w, h, contenido, tam=14, color=TEXTO, fuente=CUERPO, negrita=False,
          alinear=PP_ALIGN.LEFT, anclaje=MSO_ANCHOR.TOP, cursiva=False, interlineado=None,
          nombre: Optional[str] = None):
    """Caja de texto sin márgenes internos. `contenido` admite saltos de línea («\n»)."""
    caja = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    if nombre:
        caja.name = nombre
    tf = caja.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = anclaje
    for k, linea in enumerate(str(contenido).split("\n")):
        p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
        p.alignment = alinear
        if interlineado:
            p.line_spacing = interlineado
        _runs(p, linea, tam, color, fuente, negrita, cursiva)
    return caja


def lista(s, x, y, w, h, items: Iterable[str], tam=14, color=TEXTO, numerada=False,
          color_marca=SELLO, espacio=6, color_negrita: Optional[RGBColor] = None):
    """Lista con viñetas o numerada (viñetas reales de PowerPoint, no caracteres)."""
    caja = s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = caja.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    for k, item in enumerate(items):
        p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
        p.space_after = Pt(espacio)
        pPr = p._p.get_or_add_pPr()
        sangria = int(Pt(tam * (1.6 if numerada else 1.1)))
        pPr.set("marL", str(sangria))
        pPr.set("indent", str(-sangria))
        clr = etree.SubElement(pPr, qn("a:buClr"))
        etree.SubElement(clr, qn("a:srgbClr")).set("val", str(color_marca))
        etree.SubElement(pPr, qn("a:buFont")).set("typeface", CUERPO)
        if numerada:
            etree.SubElement(pPr, qn("a:buAutoNum")).set("type", "arabicPeriod")
        else:
            etree.SubElement(pPr, qn("a:buChar")).set("char", "•")
        _runs(p, item, tam, color, CUERPO, False, color_negrita=color_negrita)
    return caja


def rect(s, x, y, w, h, relleno: Optional[RGBColor] = None, borde: Optional[RGBColor] = None,
         redondeado=False, grosor=1.0, nombre: Optional[str] = None):
    forma = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if redondeado else MSO_SHAPE.RECTANGLE,
                               Inches(x), Inches(y), Inches(w), Inches(h))
    if redondeado:
        forma.adjustments[0] = min(0.5, 0.12 / max(min(w, h), 0.01))
    if relleno is None:
        forma.fill.background()
    else:
        forma.fill.solid()
        forma.fill.fore_color.rgb = relleno
    if borde is None:
        forma.line.fill.background()
    else:
        forma.line.color.rgb = borde
        forma.line.width = Pt(grosor)
    forma.shadow.inherit = False
    if nombre:
        forma.name = nombre
    return forma


def circulo(s, x, y, d, relleno, etiqueta="", tam=14, color=BLANCO):
    c = s.shapes.add_shape(MSO_SHAPE.OVAL, Inches(x), Inches(y), Inches(d), Inches(d))
    c.fill.solid()
    c.fill.fore_color.rgb = relleno
    c.line.fill.background()
    c.shadow.inherit = False
    if etiqueta:
        tf = c.text_frame
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        _runs(p, etiqueta, tam, color, CUERPO, True)
    return c


def imagen(s, ruta: Path, x, y, w=None, h=None, marco: Optional[RGBColor] = None, alt=""):
    """Imagen ajustada a la caja (w×h) conservando proporción, centrada; con marco opcional."""
    with Image.open(ruta) as im:
        iw, ih = im.size
    if w and h:
        esc = min(w / iw, h / ih)
        ww, hh = iw * esc, ih * esc
        x, y = x + (w - ww) / 2, y + (h - hh) / 2
    elif w:
        ww, hh = w, w * ih / iw
    else:
        ww, hh = h * iw / ih, h
    if marco is not None:
        rect(s, x - 0.06, y - 0.06, ww + 0.12, hh + 0.12, relleno=marco, redondeado=True)
    pic = s.shapes.add_picture(str(ruta), Inches(x), Inches(y), Inches(ww), Inches(hh))
    if alt:
        pic._element.nvPicPr.cNvPr.set("descr", alt)
    return pic


def encabezado(s, etiqueta: str, titulo: str, oscura=False):
    """Etiqueta en versalitas + título de la diapositiva."""
    texto(s, MARGEN, 0.42, 12, 0.3, etiqueta.upper(), 11, SELLO if not oscura else MOSTAZA,
          negrita=True)
    texto(s, MARGEN, 0.72, 12.1, 0.8, titulo, 28, BLANCO if oscura else TINTA, fuente=TITULAR,
          nombre="Título")


def tarjeta(s, x, y, w, h, titulo, cuerpo, acento=SELLO, fondo=BLANCO, tam=13, numero=None):
    rect(s, x, y, w, h, relleno=fondo, borde=LINEA, redondeado=True, grosor=0.75)
    dx = 0.25
    if numero is not None:
        circulo(s, x + 0.25, y + 0.25, 0.45, acento, str(numero), 14)
        dx = 0.85
    texto(s, x + dx, y + 0.27, w - dx - 0.25, 0.45, titulo, 15, TINTA, negrita=True,
          anclaje=MSO_ANCHOR.MIDDLE if numero is not None else MSO_ANCHOR.TOP)
    texto(s, x + 0.25, y + (0.85 if numero is not None else 0.7), w - 0.5,
          h - (1.0 if numero is not None else 0.85), cuerpo, tam, TEXTO, interlineado=1.08)


def chip(s, x, y, w, etiqueta, relleno, color=BLANCO, tam=11, h=0.32):
    r = rect(s, x, y, w, h, relleno=relleno, redondeado=True)
    tf = r.text_frame
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.CENTER
    _runs(p, etiqueta, tam, color, CUERPO, True)
    return r


def tabla(s, x, y, w, filas: list[list[str]], anchos: list[float], tam=12, alto_fila=0.36,
          cabecera_color=TINTA):
    t = s.shapes.add_table(len(filas), len(filas[0]), Inches(x), Inches(y), Inches(w),
                           Inches(alto_fila * len(filas))).table
    tblPr = t._tbl.tblPr
    tblPr.set("bandRow", "0")
    tblPr.set("firstRow", "1")
    for j, a in enumerate(anchos):
        t.columns[j].width = Inches(a)
    for i, fila in enumerate(filas):
        t.rows[i].height = Inches(alto_fila)
        for j, valor in enumerate(fila):
            c = t.cell(i, j)
            c.margin_left = c.margin_right = Inches(0.1)
            c.margin_top = c.margin_bottom = Inches(0.04)
            c.vertical_anchor = MSO_ANCHOR.MIDDLE
            c.fill.solid()
            c.fill.fore_color.rgb = cabecera_color if i == 0 else (BLANCO if i % 2 else PAPEL)
            tf = c.text_frame
            tf.word_wrap = True
            p = tf.paragraphs[0]
            _runs(p, valor, tam, BLANCO if i == 0 else TEXTO, CUERPO, i == 0)
    return t


def codigo(s, x, y, w, h, lineas: str, tam=12):
    rect(s, x, y, w, h, relleno=TINTA2, redondeado=True)
    texto(s, x + 0.25, y + 0.18, w - 0.5, h - 0.3, lineas, tam, RGBColor(0xE6, 0xE1, 0xD6),
          fuente=MONO, interlineado=1.1)


def nota_tecnica(s, y, contenido, oscura=False):
    texto(s, MARGEN, y, 12.1, 0.3, contenido, 10, CLARO_TENUE if oscura else TENUE, fuente=MONO)


# ══════════════════════════════════════════════════════════════════════
#  Imágenes auxiliares (logo y páginas de los PDF de ejemplo)
# ══════════════════════════════════════════════════════════════════════

def logo_png(tmp: Path) -> Optional[Path]:
    if not LOGO.is_file():
        return None
    destino = tmp / "logo_bcp.png"
    with Image.open(LOGO) as im:
        im.convert("RGBA").save(destino)
    return destino


def pagina_pdf(pdf: Path, numero: int, tmp: Path, escala=1.6) -> Optional[Path]:
    """Página `numero` (1-based) del PDF como PNG; None si no hay PDF o pypdfium2."""
    if not pdf.is_file():
        return None
    try:
        import pypdfium2 as pdfium
    except ImportError:
        return None
    doc = pdfium.PdfDocument(str(pdf))
    try:
        if numero > len(doc):
            return None
        destino = tmp / f"{pdf.stem}_p{numero}.png"
        doc[numero - 1].render(scale=escala).to_pil().save(destino)
        return destino
    finally:
        doc.close()


def captura(clave: str) -> Path:
    return DIR_CAPTURAS / f"{clave}.jpg"


def pantalla(clave: str):
    for fila in PANTALLAS:
        if fila[0] == clave:
            return fila
    raise KeyError(clave)


# ══════════════════════════════════════════════════════════════════════
#  Diapositivas
# ══════════════════════════════════════════════════════════════════════

def d_portada(m: Mazo, logo: Optional[Path]):
    s = m.nueva("Introducción", oscura=True, notas=(
        "Presentación de la herramienta VIRF. Objetivo: que cualquier validador pueda usarla de "
        "principio a fin y que el equipo técnico sepa dónde tocar cuando algo deba cambiar."))
    if logo:
        rect(s, MARGEN, 0.6, 2.3, 0.75, relleno=BLANCO, redondeado=True)
        imagen(s, logo, MARGEN + 0.15, 0.68, w=2.0, h=0.6)
    texto(s, MARGEN, 2.2, 11, 0.4, "GERENCIA DE VALIDACIÓN INTERNA DE RIESGO FINANCIERO", 13,
          MOSTAZA, negrita=True)
    texto(s, MARGEN, 2.7, 11.5, 1.2, "VIRF · Guía de la herramienta", 54, BLANCO, fuente=TITULAR)
    texto(s, MARGEN, 3.95, 10.5, 1.0,
          "Agente de validación de modelos de riesgo financiero: cómo se usa, qué produce y "
          "cómo se mantiene.", 20, CLARO_TENUE)
    rect(s, MARGEN, 5.35, 3.2, 0.04, relleno=SELLO)
    texto(s, MARGEN, 5.55, 9, 0.35, f"Versión de la herramienta: agente v27 · {date.today():%d/%m/%Y}",
          13, CLARO_TENUE)


def d_agenda(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "Recorrido de la sesión: primero qué es VIRF, luego el uso paso a paso, los informes, la "
        "regla de calificación, la IA y, al final, el mantenimiento con el agente corporativo."))
    encabezado(s, "Contenido", "Qué vamos a ver")
    temas = [
        ("Qué es VIRF", "Propósito, formas de uso y vocabulario"),
        ("Primeros pasos", "Arranque, entrada, modelos y expediente"),
        ("Los 9 pasos", "De la configuración al informe"),
        ("Consultas", "Resultados, controles de datos y chat"),
        ("Solo Informe", "El informe sin ejecutar el pipeline"),
        ("El informe Word", "Estructura común y muestras reales"),
        ("Calificación", "La regla única y ejemplos resueltos"),
        ("IA, seguridad y mantenimiento", "Proveedor, salvaguardas, grafo y agente corporativo"),
    ]
    for k, (t, d) in enumerate(temas):
        col, fila = k % 2, k // 2
        x, y = MARGEN + col * 6.15, 1.75 + fila * 1.25
        rect(s, x, y, 5.95, 1.05, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.25, y + 0.27, 0.52, SELLO if k % 2 == 0 else TINTA, f"{k + 1:02d}", 13)
        texto(s, x + 1.0, y + 0.2, 4.8, 0.35, t, 17, TINTA, negrita=True)
        texto(s, x + 1.0, y + 0.58, 4.8, 0.35, d, 13, TENUE)


def d_que_es(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "VIRF recibe la evidencia de un modelo y la contrasta con un estándar de validación. El "
        "resultado es un informe Word con la calificación del modelo. Toda afirmación del informe "
        "debe poder rastrearse a una cita de la evidencia."))
    encabezado(s, "Qué es VIRF", "Evidencia + estándar → informe calificado")
    texto(s, MARGEN, 1.55, 12, 0.7,
          "VIRF es el agente de la segunda línea de defensa que valida modelos de riesgo financiero "
          "(VaR, LaR, ALM…). Lee la evidencia, la compara con el estándar y redacta el informe.",
          16, TEXTO)
    cajas = [
        ("Evidencia", ["Manuales y documentación", "Código del modelo (ZIP)", "Datos y resultados",
                       "Excels de automatización"], TINTA),
        ("Estándar de validación", ["Excel por ámbito", "Control general y específico",
                                    "Actividad a verificar", "Filtrable por tier"], TINTA),
        ("Agente VIRF", ["Lee y cita la evidencia", "Evalúa cada actividad (0–5)",
                         "Literatura técnica (RAG)", "Chat de sustentación"], SELLO),
        ("Informe Word", ["Estructura BCP I–VII", "Calificación del modelo",
                          "Observaciones y sustento", "Anexos de trazabilidad"], VERDE),
    ]
    xs = [MARGEN, MARGEN + 3.15, MARGEN + 6.3, MARGEN + 9.45]
    for (t, items, color), x in zip(cajas, xs):
        y = 2.65
        rect(s, x, y, 2.75, 3.6, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        rect(s, x, y, 2.75, 0.65, relleno=color, redondeado=True)
        rect(s, x, y + 0.4, 2.75, 0.25, relleno=color)
        texto(s, x + 0.2, y + 0.12, 2.4, 0.45, t, 15, BLANCO, negrita=True, anclaje=MSO_ANCHOR.MIDDLE)
        lista(s, x + 0.25, y + 0.9, 2.3, 2.6, items, 13, espacio=8, color_marca=color)
    for x, signo in ((MARGEN + 2.78, "+"), (MARGEN + 5.93, "→"), (MARGEN + 9.08, "→")):
        texto(s, x, 4.1, 0.35, 0.5, signo, 26, SELLO, negrita=True, alinear=PP_ALIGN.CENTER)
    texto(s, MARGEN, 6.45, 12, 0.4, "Regla de oro: toda afirmación del informe debe poder "
          "rastrearse a una cita verificable de la evidencia.", 13, SELLO, cursiva=True)


def d_formas_uso(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "Hay tres formas de uso. La web guiada es la habitual. La línea de comandos la usa la web "
        "por debajo y sirve para automatizar. Solo Informe es para cuando la validación se hizo a "
        "mano y solo se necesita el Word con la plantilla y la regla oficial."))
    encabezado(s, "Formas de uso", "Tres maneras de trabajar con VIRF")
    datos = [
        ("Web guiada · 9 pasos", "La forma habitual. El validador sube la evidencia, lanza la "
         "validación, sustenta en el chat y descarga el informe.",
         "Cuándo: validación completa de un modelo.", "uvicorn web.app:app"),
        ("Línea de comandos", "agente.py ejecuta el pipeline completo y emite el entregable "
         "regulatorio. La web la lanza como subproceso.",
         "Cuándo: automatizar o repetir corridas.", "agente.py --prdc …"),
        ("Solo Informe", "Genera el informe solo con el estándar y las observaciones registradas a "
         "mano. No ejecuta el pipeline; la IA es opcional.",
         "Cuándo: la validación ya se hizo y falta el Word.", "Mis Modelos › Solo Informe"),
    ]
    for k, (t, d, cuando, cmd) in enumerate(datos):
        x = MARGEN + k * 4.1
        rect(s, x, 1.7, 3.85, 4.75, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.3, 2.0, 0.7, [TINTA, TENUE, SELLO][k], str(k + 1), 20)
        texto(s, x + 0.3, 2.9, 3.3, 0.45, t, 19, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.3, 3.45, 3.3, 1.6, d, 14, TEXTO, interlineado=1.1)
        texto(s, x + 0.3, 5.1, 3.3, 0.6, cuando, 13, SELLO, negrita=True)
        texto(s, x + 0.3, 5.85, 3.3, 0.35, cmd, 12, TENUE, fuente=MONO)


def d_vocabulario(m: Mazo):
    s = m.nueva("Introducción", notas=(
        "Vocabulario mínimo para entender las pantallas y el informe. Un control del informe es "
        "cada actividad del estándar."))
    encabezado(s, "Vocabulario", "Los términos que aparecen en toda la herramienta")
    terminos = [
        ("Ámbito", "Gran área evaluada: Documentación, Calidad de Datos, Metodología, "
         "Implementación, Gobierno, Usos."),
        ("Control / Actividad", "Cada fila del estándar. En el informe, cada actividad es un "
         "control del barrido."),
        ("Observación", "Hallazgo con riesgo, recomendación, responsable, fecha y sustento."),
        ("Riesgo", "Crítico, Moderado, Bajo/Potencial u Oportunidad de Mejora (no incumple)."),
        ("Tier", "Nivel de criticidad del modelo; filtra qué actividades del estándar aplican."),
        ("Calificación", "Satisfactorio, Aceptable, Regular o Deficiente: regla única para los "
         "tres informes."),
        ("RAG", "Literatura técnica por dominio, buscada de forma léxica y local."),
        ("Chat de sustentación", "Diálogo con el área: cada observación termina APROBADA, "
         "NEGADA o PENDIENTE."),
    ]
    for k, (t, d) in enumerate(terminos):
        col, fila = k % 2, k // 2
        x, y = MARGEN + col * 6.15, 1.65 + fila * 1.3
        rect(s, x, y, 5.95, 1.15, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        rect(s, x, y + 0.2, 0.08, 0.75, relleno=SELLO if col == 0 else MOSTAZA)
        texto(s, x + 0.3, y + 0.15, 5.4, 0.35, t, 15, TINTA, negrita=True)
        texto(s, x + 0.3, y + 0.5, 5.45, 0.6, d, 13, TEXTO)


def d_divisoria(m: Mazo, seccion: str, numero: int, titulo: str, subtitulo: str):
    s = m.nueva(seccion, oscura=True, notas=f"Sección {numero}: {titulo}. {subtitulo}")
    texto(s, MARGEN, 2.3, 3, 1.2, f"{numero:02d}", 72, SELLO, fuente=TITULAR)
    texto(s, MARGEN, 3.55, 11, 1.0, titulo, 44, BLANCO, fuente=TITULAR)
    texto(s, MARGEN, 4.55, 11, 0.8, subtitulo, 18, CLARO_TENUE)


def d_arranque(m: Mazo):
    s = m.nueva("Primeros pasos", notas=(
        "Antes de abrir la web: entorno virtual del proyecto y archivo .env con el proveedor de IA. "
        "En el corporativo el proveedor es Azure OpenAI. El servidor se arranca con uvicorn y se "
        "abre en el puerto 8000."))
    encabezado(s, "Antes de empezar", "Arrancar la herramienta")
    pasos = [
        ("Entorno del proyecto", "Use siempre el **.venv** del proyecto. El Python del sistema "
         "tiene paquetes que la política prohíbe."),
        ("Credenciales en .env", "IA_PROVEEDOR=**azure_openai** y las variables de Azure. La "
         "plantilla está documentada en .env.example."),
        ("Arrancar el servidor", "Ejecute el comando de la derecha en la raíz del proyecto."),
        ("Abrir la web", "Navegador en **http://localhost:8000** y entrar con su código."),
    ]
    for k, (t, d) in enumerate(pasos):
        y = 1.7 + k * 1.2
        circulo(s, MARGEN, y, 0.55, SELLO, str(k + 1), 15)
        texto(s, MARGEN + 0.8, y - 0.02, 5.3, 0.35, t, 16, TINTA, negrita=True)
        texto(s, MARGEN + 0.8, y + 0.36, 5.3, 0.75, d, 13, TEXTO)
    codigo(s, 7.0, 1.7, 5.73, 2.5,
           "# 1) Arrancar la web\n"
           ".venv\\Scripts\\python.exe -m uvicorn \\\n"
           "    web.app:app --port 8000\n\n"
           "# 2) Comprobar la conexión con Azure\n"
           ".venv\\Scripts\\python.exe agente.py \\\n"
           "    --verificar-conexion-azure", 12)
    rect(s, 7.0, 4.45, 5.73, 1.75, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, 7.25, 4.6, 5.3, 0.35, "Importante", 14, TINTA, negrita=True)
    texto(s, 7.25, 4.97, 5.3, 1.2, "El .env nunca se edita desde el código ni se comparte. Si una "
          "clave se filtra (por ejemplo, pegada en un chat), hay que revocarla y crear otra.", 13,
          TEXTO)


def d_pantalla(m: Mazo, seccion: str, clave: str, etiqueta: Optional[str] = None):
    """Diapositiva estándar de pantalla: captura a la izquierda, uso a la derecha."""
    _, titulo, que, eps, archivos, skill = pantalla(clave)
    pasos, ojo = USO[clave]
    s = m.nueva(seccion, notas=f"{titulo}. {que} Tenga en cuenta: {ojo}")
    partes = titulo.split(" · ", 1)
    titular = partes[1] if len(partes) == 2 else titulo
    encabezado(s, etiqueta or (partes[0] if len(partes) == 2 else seccion),
               titular[:1].upper() + titular[1:])
    imagen(s, captura(clave), MARGEN + 0.06, 1.66, w=7.05, h=5.0, marco=TINTA,
           alt=f"Captura de la pantalla {titulo}")
    x, w = 8.15, 4.6
    texto(s, x, 1.62, w, 1.25, que, 13, TEXTO, interlineado=1.08)
    texto(s, x, 2.95, w, 0.3, "CÓMO SE USA", 11, SELLO, negrita=True)
    alto_pasos = 2.35 if len(pasos) > 3 else 2.0
    lista(s, x, 3.3, w, alto_pasos, pasos, 13, numerada=True, espacio=7)
    y_ojo = 3.3 + alto_pasos + 0.15
    alto_ojo = 0.32 + 0.21 * (len(ojo) // 55 + 1)  # ~55 caracteres por línea a 12 pt
    rect(s, x, y_ojo, w, alto_ojo, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, x + 0.2, y_ojo + 0.13, w - 0.4, alto_ojo - 0.2, f"**Tenga en cuenta.** {ojo}", 12,
          TEXTO)
    if eps and eps != "—":
        texto(s, 8.15, 6.8, 4.6, 0.25, f"Skill {skill} · {eps.split(' · ')[0]}", 9, TENUE,
              fuente=MONO)


def d_flujo(m: Mazo):
    s = m.nueva("Los 9 pasos", notas=(
        "El expediente sigue 9 pasos. Seis son obligatorios: configuración, estándares, evidencia, "
        "dominio, validar y documentar. Skills y cuestionamientos son opcionales; el pre-vuelo es "
        "recomendado. La barra de progreso del expediente cuenta solo los obligatorios."))
    encabezado(s, "Mapa del procedimiento", "Nueve pasos, seis obligatorios")
    pasos = [("01", "Configuración", "ob"), ("02", "Estándares", "ob"), ("03", "Evidencia", "ob"),
             ("04", "Dominio & RAG", "ob"), ("05", "Skills", "op"), ("06", "Cuestionamientos", "op"),
             ("07", "Pre-vuelo", "rec"), ("08", "Validar modelo", "ob"), ("09", "Documentar", "ob")]
    color = {"ob": SELLO, "op": TENUE, "rec": MOSTAZA}
    ancho = (13.333 - 2 * MARGEN) / 9
    for k, (n, t, tipo) in enumerate(pasos):
        x = MARGEN + k * ancho
        if k:
            rect(s, x - ancho / 2 + 0.36, 2.37, ancho - 0.72, 0.05, relleno=LINEA)
        circulo(s, x + ancho / 2 - 0.36, 2.03, 0.72, color[tipo], n, 16)
        texto(s, x, 2.9, ancho, 0.6, t, 11.5, TINTA, negrita=True, alinear=PP_ALIGN.CENTER)
    leyenda = [("Obligatorio", SELLO), ("Recomendado", MOSTAZA), ("Opcional", TENUE)]
    for k, (t, c) in enumerate(leyenda):
        circulo(s, MARGEN + k * 2.2, 3.72, 0.22, c)
        texto(s, MARGEN + k * 2.2 + 0.32, 3.68, 1.8, 0.3, t, 12, TEXTO)
    bloques = [
        ("Preparar (01–04)", "Proveedor de IA, estándar confirmado, evidencia subida y dominio "
         "con su literatura. Sin esto no se puede validar."),
        ("Afinar (05–07)", "Análisis extra, preguntas propias y revisión de la evidencia antes de "
         "gastar en llamadas a la IA."),
        ("Validar y documentar (08–09)", "Corrida del pipeline, sustentación en el chat e informe "
         "Word versionado."),
    ]
    for k, (t, d) in enumerate(bloques):
        x = MARGEN + k * 4.1
        rect(s, x, 4.35, 3.85, 2.2, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        texto(s, x + 0.25, 4.55, 3.4, 0.4, t, 16, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.25, 5.05, 3.4, 1.4, d, 13, TEXTO, interlineado=1.08)


def d_prevuelo(m: Mazo):
    titulo, que, puntos, tecnico = PREVUELO
    s = m.nueva("Los 9 pasos", notas=(
        "El pre-vuelo es recomendado antes de validar: detecta sin coste lo que haría que un "
        "ámbito quede sin evidencia y se califique como falta crítica."))
    encabezado(s, "Paso 07 · Recomendado", "Pre-vuelo: revisar la evidencia antes de gastar")
    texto(s, MARGEN, 1.6, 12, 0.8, que, 15, TEXTO)
    for k, (t, d) in enumerate(puntos):
        col, fila = k % 2, k // 2
        tarjeta(s, MARGEN + col * 6.15, 2.6 + fila * 1.95, 5.95, 1.75, t, d,
                acento=SELLO if k < 3 else VERDE, numero=k + 1, tam=13)
    nota_tecnica(s, 6.65, tecnico)


def d_consultas_chat_estados(m: Mazo):
    s = m.nueva("Consultas", notas=(
        "Cada observación del chat termina en uno de tres estados. Al consolidar, el puntaje se "
        "recalcula y el informe web muestra las aprobadas como subsanadas."))
    encabezado(s, "Chat de sustentación", "Cómo se cierra cada observación")
    estados = [
        ("APROBADO", VERDE, VERDE_SUAVE, "El área sustentó la observación con evidencia suficiente.",
         "En el informe aparece como subsanada y deja de restar."),
        ("NEGADO", SELLO, SELLO_SUAVE, "La sustentación no es suficiente o contradice la evidencia.",
         "La observación se mantiene con su riesgo."),
        ("PENDIENTE", MOSTAZA, MOSTAZA_SUAVE, "Falta información; el área debe aportar más evidencia.",
         "Se mantiene abierta hasta una nueva sesión de chat."),
    ]
    for k, (t, c, suave, que, efecto) in enumerate(estados):
        x = MARGEN + k * 4.1
        rect(s, x, 1.75, 3.85, 3.3, relleno=suave, redondeado=True)
        chip(s, x + 0.3, 2.05, 1.7, t, c, tam=12, h=0.4)
        texto(s, x + 0.3, 2.7, 3.3, 1.0, que, 14, TEXTO)
        texto(s, x + 0.3, 3.85, 3.3, 1.0, f"**Efecto:** {efecto}", 13, TEXTO)
    rect(s, MARGEN, 5.35, 12.13, 1.2, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, MARGEN + 0.3, 5.5, 11.5, 1.0,
          "**Consolidar** recalcula el puntaje final con las decisiones del validador y genera el "
          "**acta de cierre** (Excel). El agente propone; la decisión siempre es del validador.",
          14, TEXTO)


def d_movil(m: Mazo):
    s = m.nueva("Consultas", notas=(
        "La web funciona también en pantallas pequeñas: la cabecera se parte, el menú lateral pasa "
        "a una barra horizontal y los formularios usan una sola columna."))
    encabezado(s, "También en el móvil", "La misma herramienta en pantallas pequeñas")
    claves = ["20_movil_mis_modelos", "21_movil_solo_informe", "22_movil_dashboard"]
    for k, clave in enumerate(claves):
        _, titulo, que, *_ = pantalla(clave)
        x = MARGEN + 0.2 + k * 4.15
        imagen(s, captura(clave), x, 1.65, w=1.95, h=4.25, marco=TINTA, alt=titulo)
        texto(s, x + 2.15, 1.75, 1.75, 0.6, titulo.split(" · ")[-1], 15, TINTA, negrita=True)
        texto(s, x + 2.15, 2.4, 1.75, 3.4, que, 12, TEXTO)
    texto(s, MARGEN, 6.25, 12, 0.5, "Accesibilidad: contraste AA en los textos y foco de teclado "
          "visible (anillo mostaza) en toda la web.", 13, SELLO, cursiva=True)


def d_solo_informe_que(m: Mazo):
    s = m.nueva("Solo Informe", notas=(
        "Solo Informe es para cuando la validación ya se hizo a mano y se necesita el Word oficial. "
        "Usa la misma plantilla y la misma regla de calificación que los otros dos informes."))
    encabezado(s, "Solo Informe", "El informe oficial sin ejecutar el pipeline")
    pasos = [
        ("Estándar", "Sube el Excel y, si tiene columnas TIER, se filtra por el tier del modelo."),
        ("Datos", "Tipo de validación, fechas, responsables, contexto y limitaciones."),
        ("Observaciones", "Ámbito, riesgo, actividad, recomendación y sustento."),
        ("Word", "Calificación automática con la regla única y plantilla BCP."),
    ]
    for k, (t, d) in enumerate(pasos):
        x = MARGEN + k * 3.08
        rect(s, x, 1.75, 2.85, 2.5, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.25, 2.0, 0.6, SELLO if k < 3 else VERDE, str(k + 1), 16)
        texto(s, x + 0.25, 2.75, 2.4, 0.4, t, 17, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.25, 3.2, 2.4, 1.0, d, 13, TEXTO)
        if k < 3:
            texto(s, x + 2.83, 2.75, 0.27, 0.4, "→", 18, SELLO, negrita=True, alinear=PP_ALIGN.CENTER)
    comparacion = [
        ["", "Web (9 pasos)", "Solo Informe"],
        ["Ejecuta el pipeline", "Sí (agente.py)", "No"],
        ["Llamadas a la IA", "Sí, en cada corrida", "Solo si pulsa un botón de IA"],
        ["Quién decide las observaciones", "El agente propone, el chat cierra", "El validador las escribe"],
        ["Plantilla y regla de calificación", "Comunes", "Comunes"],
        ["Necesita modelo creado", "Sí", "No (solo el login)"],
    ]
    tabla(s, MARGEN, 4.5, 12.13, comparacion, [4.0, 4.06, 4.07], tam=12, alto_fila=0.34)


def d_solo_informe_reglas(m: Mazo):
    s = m.nueva("Solo Informe", notas=(
        "Reglas propias del registro de observaciones en Solo Informe, confirmadas con el usuario."))
    encabezado(s, "Solo Informe · reglas del registro", "Lo que la herramienta hace por usted")
    reglas = [
        ("Cada actividad es un control", "El barrido del informe recorre todas las actividades "
         "del estándar (p. ej. 32) y concluye control por control."),
        ("Filtro por tier", "Si el Excel trae columnas TIER, solo entran las actividades que "
         "aplican al tier elegido. El tier es obligatorio en ese caso."),
        ("Oportunidad de Mejora", "No incumple el control, no lleva responsable ni fecha y no "
         "cuenta para la calificación global."),
        ("Sustento", "Imagen, fragmento de código o texto. Va debajo de la observación en el "
         "barrido de controles."),
        ("Descripción de lo realizado", "Texto fijo: «Es un barrido completo», igual para todos "
         "los controles."),
        ("Conclusión del control", "Si el control no es adecuado, la conclusión sale en rojo; "
         "si cumple, en texto normal."),
    ]
    for k, (t, d) in enumerate(reglas):
        col, fila = k % 3, k // 3
        tarjeta(s, MARGEN + col * 4.1, 1.7 + fila * 2.5, 3.85, 2.3, t, d, numero=k + 1,
                acento=[SELLO, TINTA, MOSTAZA, VERDE, TENUE, SELLO][k], tam=13)


def d_solo_informe_ia(m: Mazo):
    s = m.nueva("Solo Informe", notas=(
        "Tres ayudas opcionales con IA. Todas usan el proveedor configurado, que en el corporativo "
        "es GPT de Azure. Si no hay IA configurada, los botones lo indican y el resto funciona."))
    encabezado(s, "Solo Informe · asistencia con IA (opcional)", "Tres botones, siempre bajo su control")
    ayudas = [
        ("Pulir con IA", "Corrige redacción, tono y claridad de contexto, limitaciones, "
         "observaciones y recomendaciones. No inventa hechos ni cifras.", "POST /api/solo-informe/ia/pulir"),
        ("Crear gráfico", "Si un sustento o descripción es muy extenso, propone un gráfico. Solo "
         "usa números que ya están en el texto (se comprueba).", "POST /api/solo-informe/ia/grafico"),
        ("Desde los manuales", "Busca en los manuales subidos (búsqueda léxica local) y redacta "
         "citando archivo y página.", "POST /api/solo-informe/ia/manuales"),
    ]
    for k, (t, d, ep) in enumerate(ayudas):
        x = MARGEN + k * 4.1
        rect(s, x, 1.75, 3.85, 3.35, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.3, 2.05, 0.6, [SELLO, MOSTAZA, VERDE][k], "IA", 13)
        texto(s, x + 1.1, 2.12, 2.6, 0.45, t, 17, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.3, 2.85, 3.3, 1.7, d, 13, TEXTO, interlineado=1.08)
        texto(s, x + 0.3, 4.65, 3.3, 0.3, ep, 9, TENUE, fuente=MONO)
    rect(s, MARGEN, 5.35, 12.13, 1.2, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.3, 5.48, 11.5, 1.0,
          "**Proveedor:** el de IA_PROVEEDOR (Azure OpenAI en el corporativo). Se puede forzar otro "
          "solo para Solo Informe con SOLO_INFORME_IA_PROVEEDOR / SOLO_INFORME_DEPLOYMENT. Antes de "
          "enviar texto se enmascaran datos personales y se neutralizan instrucciones incrustadas.",
          13, TEXTO)


def d_informe_estructura(m: Mazo, portada: Optional[Path], indice: Optional[Path]):
    s = m.nueva("El informe Word", notas=(
        "Los tres informes comparten la plantilla de modulos/plantilla_bcp.py: misma portada, "
        "encabezado con logo y numeración «Página | N», pie, índice con hipervínculos y siete "
        "secciones fijas más anexos."))
    encabezado(s, "Estructura común", "Un mismo esqueleto para los tres informes")
    secciones = [
        ("I", "Objetivos", "Qué se evaluó y desde cuándo."),
        ("II", "Alcance", "Ámbitos y controles revisados."),
        ("III", "Cumplimiento de Estándar", "Controles satisfactorios / no cumplidos por ámbito."),
        ("IV", "Información Relevante", "Ficha del documento, contexto, limitaciones, fechas y conclusión."),
        ("V", "Cuadro Resumen", "Todas las observaciones con riesgo y responsable."),
        ("VI", "Glosario", "Término, sigla y descripción."),
        ("VII", "Barrido de Controles", "Cada actividad: descripción, resultado y conclusión."),
        ("A…", "Anexos", "Según el informe: trazabilidad, firma, custodia, escala…"),
    ]
    for k, (n, t, d) in enumerate(secciones):
        y = 1.65 + k * 0.63
        chip(s, MARGEN, y + 0.05, 0.62, n, SELLO if n != "A…" else TENUE, tam=12, h=0.36)
        texto(s, MARGEN + 0.8, y + 0.02, 2.9, 0.4, t, 14, TINTA, negrita=True)
        texto(s, MARGEN + 3.65, y + 0.04, 3.9, 0.5, d, 12, TEXTO)
    for k, (img, alt) in enumerate(((portada, "Portada del informe"), (indice, "Índice del informe"))):
        if img:
            imagen(s, img, 8.35 + k * 2.3, 1.75, w=2.1, h=4.7, marco=LINEA, alt=alt)
    texto(s, 8.35, 6.5, 4.4, 0.3, "Ejemplo real: Informe de Resultados (Solo Informe), modelo LaR",
          10, TENUE, cursiva=True)


def d_informe_paginas(m: Mazo, paginas: list[tuple[Optional[Path], str, str]]):
    s = m.nueva("El informe Word", notas=(
        "Páginas reales del ejemplo generado por Solo Informe. El cumplimiento por ámbito, la ficha "
        "del documento y la conclusión con la calificación salen calculados."))
    encabezado(s, "Muestras reales", "Así se ven las secciones clave")
    validas = [p for p in paginas if p[0]]
    ancho = 12.13 / max(len(validas), 1)
    for k, (img, t, d) in enumerate(validas):
        x = MARGEN + k * ancho
        imagen(s, img, x + 0.1, 1.65, w=ancho - 0.35, h=3.85, marco=LINEA, alt=t)
        texto(s, x + 0.1, 5.65, ancho - 0.35, 0.35, t, 14, TINTA, negrita=True)
        texto(s, x + 0.1, 6.0, ancho - 0.35, 0.8, d, 12, TEXTO)


def d_barrido(m: Mazo, barrido: Optional[Path], capt1: Optional[Path], capt2: Optional[Path]):
    s = m.nueva("El informe Word", notas=(
        "El barrido de controles va en texto corrido, no en tablas. En el informe web, cada "
        "documento citado aporta la captura de su portada, y cada contradicción entre manual y "
        "código lleva la página citada y el fragmento de código como sustento. Solo se captura "
        "cuando la cita es literal."))
    encabezado(s, "Barrido de controles y capturas", "El sustento visible dentro del informe")
    imgs = [(barrido, "VII. Barrido (Solo Informe)", "Actividad, descripción de lo realizado, "
             "resultado y conclusión; en rojo si el control no es adecuado."),
            (capt1, "Portada citada (informe web)", "Pantallazo de la primera página de cada "
             "documento de Documentación."),
            (capt2, "Página y código (informe web)", "Contradicción manual ↔ código: página "
             "citada resaltada y fragmento con números de línea.")]
    validas = [i for i in imgs if i[0]]
    ancho = 12.13 / max(len(validas), 1)
    for k, (img, t, d) in enumerate(validas):
        x = MARGEN + k * ancho
        imagen(s, img, x + 0.1, 1.65, w=ancho - 0.35, h=3.85, marco=LINEA, alt=t)
        texto(s, x + 0.1, 5.65, ancho - 0.35, 0.35, t, 14, TINTA, negrita=True)
        texto(s, x + 0.1, 6.0, ancho - 0.35, 0.8, d, 12, TEXTO)


def d_tres_informes(m: Mazo):
    s = m.nueva("El informe Word", notas=(
        "Qué añade cada informe sobre la estructura común. Los tres se califican con la misma "
        "regla de modulos/reglas_informe.py."))
    encabezado(s, "Tres informes, una plantilla", "Qué añade cada uno")
    filas = [
        ["", "Solo Informe", "Generar informe (web)", "Entregable del pipeline"],
        ["Se genera desde", "Pantalla Solo Informe", "Paso 09 · Documentar", "agente.py (CLI)"],
        ["Observaciones", "Escritas por el validador", "Puntaje del agente + chat", "Puntaje del agente"],
        ["Sustento", "Imagen, código o texto", "Citas, capturas de portada, página y código", "Citas de evidencia"],
        ["Anexos", "—", "Tabla final, entendimiento, automatizaciones, trazabilidad",
         "Firma, custodia, escala, correcciones, análisis transversales"],
        ["Versionado", "Un Word por generación", "V1, V2… por modelo", "Por corrida"],
        ["Código", "solo_informe_word.py", "informe_web.py", "generador_word.py"],
    ]
    tabla(s, MARGEN, 1.7, 12.13, filas, [2.4, 2.9, 3.4, 3.43], tam=12, alto_fila=0.62)
    texto(s, MARGEN, 6.3, 12, 0.4, "Los tres llaman a modulos/plantilla_bcp.py y se califican con "
          "modulos/reglas_informe.py.", 13, SELLO, cursiva=True)


def d_regla(m: Mazo):
    s = m.nueva("Calificación", notas=(
        "La regla se evalúa de lo más grave a lo menos grave; la primera condición que se cumple "
        "decide el nivel. Las Oportunidades de Mejora no cuentan."))
    encabezado(s, "Regla de calificación", "Cuatro niveles, evaluados de lo más grave a lo menos grave")
    niveles = [
        ("Deficiente", "Más de 2 observaciones críticas."),
        ("Regular", "1 o 2 críticas · o más de 1 moderada · (con al menos una moderada de "
                    "Documentación y una de Gobierno, el umbral sube a 3 o más)."),
        ("Aceptable", "1 moderada (o 2 con la excepción Documentación + Gobierno) · o 5 o más "
                      "bajas/potenciales. Nunca lleva críticas."),
        ("Satisfactorio", "Hasta 4 bajas/potenciales, sin moderadas ni críticas."),
    ]
    for k, (n, d) in enumerate(niveles):
        y = 1.7 + k * 1.05
        chip(s, MARGEN, y + 0.12, 2.3, n, COLOR_NIVEL[n], tam=15, h=0.6)
        rect(s, MARGEN + 2.5, y, 9.63, 0.85, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        texto(s, MARGEN + 2.75, y + 0.1, 9.2, 0.7, d, 14, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
    rect(s, MARGEN, 6.0, 12.13, 0.7, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, MARGEN + 0.3, 6.08, 11.5, 0.55, "**Oportunidades de Mejora:** no cuentan para la "
          "calificación y no dejan el control como incumplido. «Potencial» cuenta junto a «Bajo».",
          13, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)


def d_ejemplos(m: Mazo):
    s = m.nueva("Calificación", notas=(
        "Estos casos no están escritos a mano: el generador de la presentación los calcula con la "
        "función concluir() de la herramienta, así que siempre coinciden con la regla vigente."))
    encabezado(s, "Ejemplos resueltos", "La regla aplicada a casos típicos")
    filas = [["Observaciones del informe", "Calificación", "Motivo (texto que da la herramienta)"]]
    niveles = []
    for nombre, _, res in ejemplos_calificacion():
        filas.append([nombre, res["nivel"], res["motivo"]])
        niveles.append(res["nivel"])
    t = tabla(s, MARGEN, 1.7, 12.13, filas, [3.9, 1.9, 6.33], tam=13, alto_fila=0.58)
    for i, nivel in enumerate(niveles, start=1):
        c = t.cell(i, 1)
        c.fill.solid()
        c.fill.fore_color.rgb = COLOR_NIVEL[nivel]
        for r in c.text_frame.paragraphs[0].runs:
            r.font.color.rgb, r.font.bold = BLANCO, True
    nota_tecnica(s, 6.55, "Calculado con modulos/reglas_informe.py::concluir() al generar esta presentación.")


def d_puntaje(m: Mazo):
    s = m.nueva("Calificación", notas=(
        "En la web y en el pipeline el agente puntúa cada actividad de 0 a 5. Ese puntaje se "
        "traduce a riesgo para aplicar la misma regla que Solo Informe. La falta de evidencia es "
        "falta crítica; una actividad sin puntaje por fallo técnico no se califica y se re-ejecuta."))
    encabezado(s, "Del puntaje del agente al riesgo", "Cómo se califican la web y el pipeline")
    escala = _escala_puntaje()
    ancho = 12.13 / len(escala)
    significado = {"0": "Sin evidencia", "1": "Incumple", "2": "Incumple", "3": "Brechas importantes",
                   "4": "Cumplimiento sustancial", "5": "Cumple"}
    for k, (p, riesgo) in enumerate(escala):
        x = MARGEN + k * ancho
        rect(s, x + 0.05, 1.75, ancho - 0.1, 2.3, relleno=COLOR_RIESGO[riesgo], redondeado=True)
        texto(s, x + 0.05, 1.85, ancho - 0.1, 1.0, p, 48, BLANCO, fuente=TITULAR, negrita=True,
              alinear=PP_ALIGN.CENTER)
        texto(s, x + 0.15, 2.95, ancho - 0.3, 0.9, riesgo or "Sin observación", 14, BLANCO,
              negrita=True, alinear=PP_ALIGN.CENTER)
        texto(s, x + 0.05, 4.2, ancho - 0.1, 0.4, significado[p], 12, TENUE, alinear=PP_ALIGN.CENTER)
    casos = [
        ("Sin evidencia", "Falta crítica (como un 0), aunque no haya puntaje.", SELLO),
        ("Sin puntaje (fallo técnico)", "«No evaluada»: no se califica; hay que re-ejecutar.", TENUE),
        ("APROBADO en el chat", "La observación cuenta como subsanada en el informe web.", VERDE),
    ]
    for k, (t, d, c) in enumerate(casos):
        x = MARGEN + k * 4.1
        rect(s, x, 4.85, 3.85, 1.6, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.25, 5.05, 0.3, c)
        texto(s, x + 0.7, 5.0, 3.0, 0.4, t, 14, TINTA, negrita=True)
        texto(s, x + 0.25, 5.5, 3.4, 0.9, d, 13, TEXTO)
    nota_tecnica(s, 6.6, "Escala calculada con modulos/reglas_informe.py::riesgo_desde_puntaje().")


def d_ia(m: Mazo):
    s = m.nueva("IA y seguridad", notas=(
        "Todas las funciones de IA pasan por config/ia.py, que lee IA_PROVEEDOR. En el corporativo "
        "es Azure OpenAI. Claude se podrá usar cuando haya credenciales. No hay cambio automático "
        "de proveedor si uno falla: el error se muestra."))
    encabezado(s, "Proveedor de IA", "Un solo punto de configuración: config/ia.py")
    proveedores = [
        ("Azure OpenAI (GPT)", "Proveedor por defecto y el del corporativo. Usa el deployment "
         "configurado en el .env.", "IA_PROVEEDOR=azure_openai", SELLO),
        ("Claude (Anthropic)", "Alternativa disponible cuando haya credenciales. Mismo código, "
         "solo cambia la variable.", "IA_PROVEEDOR=anthropic", TINTA),
        ("VIRF PLUS (beta)", "GPT y Claude responden a la vez y un árbitro decide. Apagado por "
         "defecto; requiere ambos.", "Paso 01 › VIRF PLUS", MOSTAZA),
    ]
    for k, (t, d, var, c) in enumerate(proveedores):
        x = MARGEN + k * 4.1
        rect(s, x, 1.7, 3.85, 2.95, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        rect(s, x, 1.7, 3.85, 0.12, relleno=c)
        texto(s, x + 0.3, 2.0, 3.3, 0.45, t, 17, TINTA, fuente=TITULAR, negrita=True)
        texto(s, x + 0.3, 2.55, 3.3, 1.3, d, 13, TEXTO, interlineado=1.08)
        texto(s, x + 0.3, 4.1, 3.3, 0.35, var, 11, TENUE, fuente=MONO)
    usos = ["Validación (pipeline del paso 08)", "Chat de sustentación", "Entendimiento del modelo",
            "Solo Informe: pulir, gráfico y manuales"]
    texto(s, MARGEN, 4.95, 6, 0.35, "TODAS ESTAS FUNCIONES USAN EL MISMO PROVEEDOR", 11, SELLO, negrita=True)
    lista(s, MARGEN, 5.35, 6, 1.4, usos, 13, espacio=3)
    rect(s, 7.0, 4.95, 5.73, 1.75, relleno=MOSTAZA_SUAVE, redondeado=True)
    texto(s, 7.25, 5.08, 5.3, 1.55, "**Sin plan B automático.** Si el proveedor falla (401, 503…), "
          "la herramienta lo dice con claridad; no cambia sola a otro proveedor. Un 401 casi siempre "
          "es una clave mal copiada en el .env.", 13, TEXTO)


def d_salvaguardas(m: Mazo):
    s = m.nueva("IA y seguridad", notas=(
        "Salvaguardas que protegen la evidencia y la trazabilidad del informe."))
    encabezado(s, "Salvaguardas", "Qué protege la evidencia y el informe")
    items = [
        ("Datos personales", "Se enmascaran localmente antes de enviar texto al modelo.",
         "modulos/pii.py"),
        ("Instrucciones incrustadas", "Texto de la evidencia que intente dar órdenes al modelo se "
         "neutraliza.", "modulos/inyeccion.py"),
        ("Citas verificables", "Cada hallazgo cita archivo y pasaje; lo que no se puede rastrear "
         "no entra como hecho.", "Regla de oro 10"),
        ("Capturas exactas", "Solo se captura la página si la cita es literal; nunca una página "
         "«aproximada».", "modulos/capturas.py"),
        ("RAG local", "Búsqueda léxica sin embeddings, sin HuggingFace ni servicios externos.",
         "src/rag/"),
        ("Código del modelo", "Se lee para evaluarlo; nunca se ejecuta lo subido.",
         "web/routers/upload.py"),
    ]
    for k, (t, d, ref) in enumerate(items):
        col, fila = k % 3, k // 3
        x, y = MARGEN + col * 4.1, 1.7 + fila * 2.5
        rect(s, x, y, 3.85, 2.3, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
        circulo(s, x + 0.25, y + 0.25, 0.45, [SELLO, SELLO, VERDE, VERDE, TINTA, TINTA][k], "✓", 14)
        texto(s, x + 0.85, y + 0.3, 2.8, 0.4, t, 15, TINTA, negrita=True)
        texto(s, x + 0.25, y + 0.9, 3.4, 1.0, d, 13, TEXTO)
        texto(s, x + 0.25, y + 1.88, 3.4, 0.3, ref, 10, TENUE, fuente=MONO)


def d_arquitectura(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "Arquitectura en capas. La regla de dependencias es clave: modulos no importa web, porque "
        "el pipeline de línea de comandos no tiene web."))
    encabezado(s, "Arquitectura", "Capas del código y dónde vive cada cosa")
    capas = [
        ("Navegador", "web/static/js/app.js · index.html · styles.css", TENUE),
        ("Endpoints", "web/routers/*.py — validan la entrada, devuelven JSON o archivos", TINTA),
        ("Servicios web", "web/services/*.py — sesión, estándares, chat, informes, Solo Informe", TINTA),
        ("Núcleo", "modulos/*.py — motor IA, plantilla y regla de informes, PII, capturas", SELLO),
        ("Configuración", "config/*.py — parámetros, rutas y ÚNICO lugar que elige proveedor de IA", SELLO),
        ("Pipeline y RAG", "agente.py · motor/Mx_0x_*.py · src/rag/*.py", MOSTAZA),
    ]
    for k, (t, d, c) in enumerate(capas):
        y = 1.65 + k * 0.78
        rect(s, MARGEN, y, 2.6, 0.62, relleno=c, redondeado=True)
        texto(s, MARGEN + 0.2, y, 2.3, 0.62, t, 14, BLANCO, negrita=True, anclaje=MSO_ANCHOR.MIDDLE)
        texto(s, MARGEN + 2.85, y, 5.0, 0.62, d, 12, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
    rect(s, 8.75, 1.65, 3.98, 4.52, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 9.0, 1.85, 3.5, 0.35, "Reglas de dependencia", 15, TINTA, negrita=True)
    lista(s, 9.0, 2.35, 3.5, 3.7, [
        "web/ puede importar modulos/, config/ y src/.",
        "**modulos/ no importa web/**: el pipeline CLI no tiene web.",
        "La calificación solo vive en modulos/reglas_informe.py.",
        "La selección de proveedor de IA solo en config/.",
        "Tests: ~1200, todos sin coste (IA simulada).",
    ], 13, espacio=8)
    nota_tecnica(s, 6.45, "Sesiones: web/data/sesiones/{código}/{MODELO}/inputs|outputs · "
                 "Solo Informe: web/data/sesiones/{código}/_solo_informe/")


def d_reglas_oro(m: Mazo, reglas: list[str]):
    s = m.nueva("Mantenimiento", notas=(
        "Estas reglas se leen de CONOCIMIENTO_VIRF.md. Cualquier cambio a la herramienta debe "
        "respetarlas; varias están vigiladas por tests."))
    encabezado(s, "Reglas de oro", "Lo que ningún cambio puede romper")
    mitad = (len(reglas) + 1) // 2
    for col, grupo in enumerate((reglas[:mitad], reglas[mitad:])):
        for k, r in enumerate(grupo):
            n = k + 1 + col * mitad
            x, y = MARGEN + col * 6.15, 1.7 + k * 0.98
            circulo(s, x, y + 0.05, 0.5, SELLO if n <= 4 else TINTA, str(n), 13)
            texto(s, x + 0.7, y, 5.25, 0.85, r, 13, TEXTO, anclaje=MSO_ANCHOR.MIDDLE)
    nota_tecnica(s, 6.65, "Fuente: docs/agente_corporativo/CONOCIMIENTO_VIRF.md §8")


def d_agente_corporativo(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "El agente corporativo acepta hasta 20 archivos de entrada y devuelve hasta 5. Por eso el "
        "paquete se organiza en un conocimiento corto, una skill por tipo de cambio y la guía PDF "
        "completa para consulta."))
    encabezado(s, "Mejorar la herramienta con el agente corporativo", "Paquete de 20 archivos de entrada / 5 de salida")
    for k, (num, t, d) in enumerate([("20", "archivos de entrada", "como máximo por consulta"),
                                     ("5", "archivos de salida", "actualizados por respuesta")]):
        x = MARGEN + k * 3.0
        texto(s, x, 1.6, 2.8, 1.1, num, 66, SELLO, fuente=TITULAR, negrita=True)
        texto(s, x, 2.75, 2.8, 0.35, t, 15, TINTA, negrita=True)
        texto(s, x, 3.1, 2.8, 0.35, d, 12, TENUE)
    receta = [
        "Suba **CONOCIMIENTO_VIRF.md** (siempre).",
        "Suba la **skill** del tipo de cambio (S01–S12).",
        "Añada los archivos de código que la skill indica (≤ 18).",
        "Pida el cambio con el síntoma y lo esperado.",
        "Pruebe con el comando «Cómo verificar» de la skill.",
    ]
    texto(s, MARGEN, 3.75, 5.6, 0.35, "RECETA DE CADA CONSULTA", 11, SELLO, negrita=True)
    lista(s, MARGEN, 4.15, 5.7, 2.6, receta, 13, numerada=True, espacio=6)
    paquete = [
        ("00_LEEME.md", "Cómo usar el paquete"),
        ("CONOCIMIENTO_VIRF.md", "Base operativa corta"),
        ("skills/S01 … S12", "Una receta por tipo de cambio"),
        ("GUIA_…_CORPORATIVO.pdf", "Guía completa (286 páginas)"),
        ("capturas/", "22 pantallas de la interfaz"),
        ("graphify-out/", "Mapa del código (grafo)"),
    ]
    rect(s, 6.9, 1.65, 5.83, 5.1, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 7.15, 1.85, 5.3, 0.35, "docs/agente_corporativo/", 14, TINTA, fuente=MONO, negrita=True)
    for k, (f, d) in enumerate(paquete):
        y = 2.4 + k * 0.7
        rect(s, 7.15, y, 0.08, 0.5, relleno=SELLO if k < 3 else MOSTAZA)
        texto(s, 7.4, y - 0.02, 5.1, 0.3, f, 13, TINTA, fuente=MONO)
        texto(s, 7.4, y + 0.27, 5.1, 0.3, d, 12, TENUE)


def d_sintoma(m: Mazo, filas: list[tuple[str, str]]):
    s = m.nueva("Mantenimiento", notas=(
        "Tabla para elegir la skill según el síntoma. Se lee de CONOCIMIENTO_VIRF.md §11."))
    encabezado(s, "Qué skill usar", "Del síntoma a la receta de cambio")
    datos = [["Síntoma", "Skill"]] + [[a, b] for a, b in filas]
    tabla(s, MARGEN, 1.6, 12.13, datos, [8.13, 4.0], tam=12, alto_fila=0.385)


def d_grafo(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "El grafo de graphify se construye sin IA a partir del código. Sirve para elegir qué "
        "archivos subir al agente y para saber qué se rompe al cambiar algo."))
    encabezado(s, "El grafo del código", "Encontrar qué tocar y qué se rompe")
    filas = [
        ["Necesito…", "Comando"],
        ["Dónde vive una función y con qué se conecta", 'graphify explain "concluir()"'],
        ["Qué se rompe si la cambio", 'graphify affected "riesgo_desde_puntaje()"'],
        ["Cómo llega un endpoint a una función", 'graphify path "ia_pulir()" "cliente_dedicado()"'],
        ["Una pregunta en lenguaje natural", 'graphify query "cómo se genera el informe word"'],
        ["Los nodos más conectados (delicados)", "graphify god-nodes --top 15"],
        ["Actualizar tras cambiar el código", "graphify update ."],
    ]
    t = tabla(s, MARGEN, 1.65, 7.6, filas, [3.6, 4.0], tam=12, alto_fila=0.52)
    for i in range(1, len(filas)):
        for r in t.cell(i, 1).text_frame.paragraphs[0].runs:
            r.font.name, r.font.size = MONO, Pt(11)
    rect(s, 8.5, 1.65, 4.23, 5.05, relleno=BLANCO, borde=LINEA, redondeado=True, grosor=0.75)
    texto(s, 8.75, 1.85, 3.8, 0.35, "Receta: elegir ≤ 18 archivos", 15, TINTA, negrita=True)
    lista(s, 8.75, 2.35, 3.8, 2.6, [
        "explain sobre la función del síntoma.",
        "affected sobre ella: candidatos a romperse.",
        "Quedarse con su archivo, los que la llaman y su test.",
        "Si sobran, describir el resto en el mensaje.",
    ], 13, numerada=True, espacio=6)
    texto(s, 8.75, 5.0, 3.8, 1.6, "**Límite:** el grafo no une JavaScript con Python (hablan por "
          "HTTP): busque la URL /api/... de app.js en web/routers/.", 12, TEXTO)
    texto(s, MARGEN, 6.4, 7.6, 0.3, "graphify-out/: GRAPH_REPORT.md (comunidades en español) · "
          "graph.json · graph.html", 10, TENUE, fuente=MONO)


def d_problemas(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "Problemas frecuentes y su solución rápida. Si no se resuelve, usar la skill S01 con el "
        "agente corporativo."))
    encabezado(s, "Problemas frecuentes", "Síntoma → qué hacer")
    filas = [
        ["Síntoma", "Causa probable", "Qué hacer"],
        ["Error 401 al usar la IA", "Clave mal copiada o vencida en el .env", "Corregir la clave y «Verificar conexión» (S05)"],
        ["Me saca de la sesión", "Se reinició el servidor", "Volver a entrar; los expedientes siguen en disco"],
        ["El estándar no se lee", "Columnas con otro nombre u hoja distinta", "Revisar Ámbito/Control/Actividad (S06)"],
        ["Un ámbito sale «sin evidencia»", "Carpeta vacía o PDF escaneado", "Hacer el pre-vuelo y subir el documento (S09)"],
        ["No aparece la captura de una cita", "La cita no es literal en el PDF", "Es intencional: no se capturan páginas aproximadas"],
        ["La calificación no es la esperada", "Una OM o «Potencial» mal registrado", "Revisar el riesgo de cada observación (S03)"],
        ["El paso no queda «hecho»", "Falta algo del paso", "Abrir la guía «?»: dice qué falta"],
    ]
    tabla(s, MARGEN, 1.65, 12.13, filas, [3.4, 3.9, 4.83], tam=12, alto_fila=0.6)


def d_pruebas(m: Mazo):
    s = m.nueva("Mantenimiento", notas=(
        "Antes de dar por bueno cualquier cambio, se corre la suite de tests. No cuesta nada: "
        "la IA está simulada."))
    encabezado(s, "Cómo probar un cambio", "Tests sin coste antes de entregar")
    codigo(s, MARGEN, 1.7, 6.6, 2.0,
           "# Suite completa (~5 min)\n"
           ".venv\\Scripts\\python.exe -m pytest -q\n\n"
           "# Un área concreta\n"
           ".venv\\Scripts\\python.exe -m pytest tests/test_X.py -q", 13)
    areas = [
        ["Área", "Tests"],
        ["Solo Informe", "test_solo_informe*.py"],
        ["Plantilla de informes", "test_plantilla_bcp.py"],
        ["Capturas", "test_capturas.py"],
        ["Reglas regulatorias", "test_regresion.py · test_pendientes_auditoria.py"],
        ["Proveedor de IA", "test_estructura_config.py · test_azure_mocks.py"],
        ["RAG", "test_rag_lexico.py"],
        ["Chat", "test_consolidacion.py · test_acta_cierre.py"],
        ["Guía y presentación", "test_guia_agente.py · test_presentacion_guia.py"],
    ]
    tabla(s, 7.5, 1.7, 5.23, areas, [1.9, 3.33], tam=11, alto_fila=0.5)
    pasos = [("Escribir o ajustar el test del área", SELLO), ("Correr el test del área", TINTA),
             ("Correr la suite completa", TINTA), ("Regenerar guía, presentación y grafo", VERDE)]
    for k, (t, c) in enumerate(pasos):
        y = 4.05 + k * 0.62
        circulo(s, MARGEN, y, 0.42, c, str(k + 1), 12)
        texto(s, MARGEN + 0.6, y + 0.03, 6.0, 0.4, t, 14, TEXTO)


def d_cierre(m: Mazo):
    s = m.nueva("Cierre", oscura=True, notas=(
        "Resumen final y dónde encontrar más información."))
    texto(s, MARGEN, 0.9, 11, 0.4, "EN RESUMEN", 13, MOSTAZA, negrita=True)
    texto(s, MARGEN, 1.35, 12, 1.0, "Evidencia + estándar → informe calificado y trazable", 34,
          BLANCO, fuente=TITULAR)
    puntos = [
        ("Web guiada", "9 pasos, 6 obligatorios; el botón «?» dice qué falta."),
        ("Solo Informe", "El Word oficial sin pipeline; la IA es opcional."),
        ("Una regla", "Misma plantilla y calificación para los tres informes."),
        ("IA con control", "Azure GPT por defecto, salvaguardas y citas verificables."),
    ]
    for k, (t, d) in enumerate(puntos):
        x = MARGEN + k * 3.08
        rect(s, x, 2.85, 2.85, 2.2, relleno=TINTA2, redondeado=True)
        texto(s, x + 0.25, 3.05, 2.4, 0.4, t, 17, MOSTAZA if k % 2 else BLANCO, negrita=True)
        texto(s, x + 0.25, 3.55, 2.4, 1.4, d, 14, CLARO_TENUE)
    texto(s, MARGEN, 5.45, 12, 0.35, "MÁS INFORMACIÓN", 11, MOSTAZA, negrita=True)
    texto(s, MARGEN, 5.8, 12, 0.9,
          "docs/agente_corporativo/GUIA_VIRF_AGENTE_CORPORATIVO.pdf · CONOCIMIENTO_VIRF.md · "
          "skills/S01–S12 · ejemplos/ (informes de muestra)", 13, CLARO_TENUE, fuente=MONO)


# ══════════════════════════════════════════════════════════════════════
#  Construcción del mazo
# ══════════════════════════════════════════════════════════════════════

def construir(salida: Path = SALIDA) -> Path:
    conocimiento = (DIR_GUIA / "CONOCIMIENTO_VIRF.md").read_text(encoding="utf-8")
    with tempfile.TemporaryDirectory() as t:
        tmp = Path(t)
        m = Mazo(tmp)
        logo = logo_png(tmp)

        d_portada(m, logo)
        d_agenda(m)
        d_que_es(m)
        d_formas_uso(m)
        d_vocabulario(m)

        d_divisoria(m, "Primeros pasos", 1, "Primeros pasos", "Arrancar, entrar, crear un modelo y leer el expediente.")
        d_arranque(m)
        for clave in ("01_login", "02_mis_modelos", "03_nuevo_modelo", "04_dashboard_inicio",
                      "16_guia_ayuda"):
            d_pantalla(m, "Primeros pasos", clave, etiqueta="Primeros pasos")

        d_divisoria(m, "Los 9 pasos", 2, "Los 9 pasos de la validación",
                    "De la configuración del proveedor de IA al informe Word versionado.")
        d_flujo(m)
        for clave in ("05_configuracion", "06_estandares", "07_evidencia", "08_dominio_rag",
                      "09_skills", "10_cuestionamientos"):
            d_pantalla(m, "Los 9 pasos", clave)
        d_prevuelo(m)
        for clave in ("11_validar", "12_documentar"):
            d_pantalla(m, "Los 9 pasos", clave)

        d_divisoria(m, "Consultas", 3, "Consultas", "Resultados de la corrida, controles de datos y chat de sustentación.")
        for clave in ("13_resultados", "14_controles_datos", "15_chat"):
            d_pantalla(m, "Consultas", clave)
        d_consultas_chat_estados(m)
        d_movil(m)

        d_divisoria(m, "Solo Informe", 4, "Solo Informe",
                    "El informe oficial a partir del estándar y de observaciones registradas a mano.")
        d_solo_informe_que(m)
        for clave in ("17_solo_informe", "18_solo_informe_datos", "19_solo_informe_observacion"):
            d_pantalla(m, "Solo Informe", clave)
        d_solo_informe_reglas(m)
        d_solo_informe_ia(m)

        d_divisoria(m, "El informe Word", 5, "El informe Word", "Una plantilla común para los tres informes.")
        d_informe_estructura(m, pagina_pdf(EJ_RESULTADOS, 1, tmp), pagina_pdf(EJ_RESULTADOS, 2, tmp))
        d_informe_paginas(m, [
            (pagina_pdf(EJ_RESULTADOS, 4, tmp), "III · IV", "Cumplimiento por ámbito y ficha del documento."),
            (pagina_pdf(EJ_RESULTADOS, 5, tmp), "IV.4 Conclusión", "Calificación con su motivo y conteos."),
            (pagina_pdf(EJ_RESULTADOS, 6, tmp), "V · VI", "Cuadro resumen de observaciones y glosario."),
        ])
        d_barrido(m, pagina_pdf(EJ_RESULTADOS, 8, tmp), pagina_pdf(EJ_WEB_CAPTURAS, 32, tmp),
                  pagina_pdf(EJ_WEB_CAPTURAS, 34, tmp))
        d_tres_informes(m)

        d_divisoria(m, "Calificación", 6, "Calificación", "Una regla única, calculada siempre igual.")
        d_regla(m)
        d_ejemplos(m)
        d_puntaje(m)

        d_divisoria(m, "IA y seguridad", 7, "IA y seguridad", "Proveedor, salvaguardas y trazabilidad.")
        d_ia(m)
        d_salvaguardas(m)

        d_divisoria(m, "Mantenimiento", 8, "Mantenimiento y mejora",
                    "Arquitectura, reglas de oro, agente corporativo, grafo y pruebas.")
        d_arquitectura(m)
        d_reglas_oro(m, reglas_de_oro(conocimiento))
        d_agente_corporativo(m)
        d_sintoma(m, sintoma_skill(conocimiento))
        d_grafo(m)
        d_problemas(m)
        d_pruebas(m)

        d_cierre(m)
        m.guardar(salida)
    return salida


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[1])
    ap.add_argument("--salida", type=Path, default=SALIDA, help="Ruta del .pptx a generar.")
    args = ap.parse_args(argv)
    ruta = construir(args.salida)
    print(f"Presentación generada: {ruta}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
