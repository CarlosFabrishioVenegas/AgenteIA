"""
scripts/explicar_rag.py
═══════════════════════════════════════════════════════════════════════════════
Abre el RAG léxico en canal: enseña, paso a paso y con NÚMEROS REALES del índice
que tengas construido, qué le pasa a una consulta desde que se escribe hasta que
sale el top-K.

PARA QUÉ SIRVE
──────────────
1. APRENDER cómo funciona. Es el acompañamiento ejecutable de `GUIA_RAG_LEXICO.md`:
   los números de esa guía salen literalmente de aquí, así que nunca se quedan
   desfasados respecto al código — se regeneran.

2. DIAGNOSTICAR. Cuando una consulta no recupera lo que esperabas, esto te dice
   POR QUÉ: qué tokens generó, cuáles existen en el corpus y cuáles no, cuánto
   pesa cada uno, y cómo se combinaron las dos señales. Casi siempre el culpable
   aparece en la tabla de IDF con `df=0` — un término que creías que estaba y no
   está, normalmente porque el documento usa otra palabra.

USO
───
    python scripts/explicar_rag.py --dominio VaR --consulta "prueba de Kupiec"
    python scripts/explicar_rag.py --dominio LaR --consulta "HQLA" --top-k 5

    # Sin argumentos: usa el ejemplo de la guía.
    python scripts/explicar_rag.py

REQUISITO: el índice del dominio debe estar construido.
    python scripts/rebuild_rag_databricks.py --dominio all
"""

# [CONSOLA-FIX] Antes del primer print: en una consola Windows con codepage
# cp1252 —el default en español— imprimir un emoji o una caja Unicode no falla
# al escribir, falla al CODIFICAR, y aborta el script.
import sys as _sys
from pathlib import Path as _Path

_RAIZ = _Path(__file__).resolve().parents[1]
if str(_RAIZ) not in _sys.path:
    _sys.path.insert(0, str(_RAIZ))

from modulos.consola import configurar_consola

configurar_consola()

# ─────────────────────────────────────────────────────────────────────────
#  ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#      → informe). Herramienta de diagnóstico y didáctica.
# ─────────────────────────────────────────────────────────────────────────

import argparse
import logging

CONSULTA_EJEMPLO = "backtesting: numero de excepciones y prueba de Kupiec"


def _regla(titulo: str) -> None:
    print(f"\n{'═' * 78}\n  {titulo}\n{'═' * 78}")


def explicar(dominio: str, consulta: str, top_k: int) -> int:
    from src.rag import config_rag as cfg
    from src.rag.buscador_lexico import BuscadorLexico
    from src.rag.indexador_lexico import (
        STOPWORDS, TERMINOS_PROTEGIDOS, quitar_acentos, tokenizar,
    )

    buscador = BuscadorLexico(dominio, autoconstruir=False)
    if not buscador._asegurar_cargado():
        print(f"\n❌ No hay índice para el dominio '{dominio}'.\n"
              f"   Constrúyelo:  python scripts/rebuild_rag_databricks.py "
              f"--dominio {dominio}\n")
        return 1

    indice = buscador._indice
    bm25 = buscador._bm25

    # ── PASO 1 ───────────────────────────────────────────────────────────────
    _regla("PASO 1 · TOKENIZACIÓN DE LA CONSULTA")
    print(f"  Consulta: {consulta!r}\n")
    print(f"  1.1 minúsculas + sin acentos → {quitar_acentos(consulta.lower())!r}\n")

    import re
    from src.rag.indexador_lexico import _RE_TOKEN, _stem
    brutos = _RE_TOKEN.findall(quitar_acentos(consulta.lower()))
    print(f"  1.2 partir en palabras ({len(brutos)}): {brutos}\n")
    print("  1.3 filtrar y normalizar cada una:")
    print(f"      {'palabra':16} {'¿qué le pasa?':34} {'token'}")
    print(f"      {'-'*16} {'-'*34} {'-'*14}")
    for b in brutos:
        if b in TERMINOS_PROTEGIDOS:
            print(f"      {b:16} {'SIGLA PROTEGIDA (intacta)':34} {b}")
        elif b in STOPWORDS:
            print(f"      {b:16} {'stopword → DESCARTADA':34} —")
        elif len(b) < cfg.LONGITUD_MINIMA_TOKEN:
            print(f"      {b:16} {'demasiado corta → DESCARTADA':34} —")
        else:
            s = _stem(b) if cfg.STEMMING_ACTIVO else b
            nota = "stem" if s != b else "sin cambios"
            print(f"      {b:16} {nota:34} {s}")

    tokens = tokenizar(consulta)
    print(f"\n  → TOKENS DE BÚSQUEDA: {tokens}")
    if not tokens:
        print("\n  ⚠️  La consulta no deja ni un token útil: el buscador "
              "devuelve [] sin\n      llegar a mirar el índice.")
        return 0

    # ── PASO 2 ───────────────────────────────────────────────────────────────
    _regla("PASO 2 · EL CORPUS Y EL PESO DE CADA TÉRMINO (IDF)")
    docs = len({c["fuente"] for c in indice.chunks})
    print(f"  Dominio '{dominio}': {len(indice)} chunks de {docs} documentos.")
    print(f"  Longitud media de un chunk: {bm25.avgdl:.1f} tokens.\n")
    print("  El IDF mide lo RARO que es un término. Cuanto más raro, más pesa:")
    print("  encontrarlo dice mucho. Un término que está en casi todos los")
    print("  chunks no distingue nada, y su IDF tiende a cero.\n")
    print(f"      {'token':14} {'aparece en':12} {'IDF':>8}   interpretación")
    print(f"      {'-'*14} {'-'*12} {'-'*8}   {'-'*40}")
    ausentes = []
    for t in tokens:
        df = sum(1 for toks in indice.tokens if t in toks)
        idf = bm25.idf.get(t, 0.0)
        if df == 0:
            interp = "NO EXISTE en el corpus → aporta 0"
            ausentes.append(t)
        elif idf <= 0.01:
            interp = "omnipresente → no discrimina"
        elif idf < 0.5:
            interp = "común"
        else:
            interp = "raro → MUY informativo"
        print(f"      {t:14} {df:>3}/{len(indice):<8} {idf:>8.4f}   {interp}")

    if ausentes:
        print(f"\n  {len(ausentes)} término(s) sin coincidencia directa: {ausentes}")

    # ── Expansión de la consulta ─────────────────────────────────────────────
    diag = buscador.diagnostico_consulta(consulta)
    expansiones = diag.get("expansiones", [])
    if expansiones:
        print("\n  🔗 EXPANSIÓN (la cura del punto ciego léxico):")
        for e in expansiones:
            extra = f"   ← palabra real: «{e['palabra']}»" if e.get("palabra") else ""
            print(f"      [{e['tipo']:8}] {e['origen']!r} → {e['añadidos']}{extra}")
        print("      Sin esto, esos términos aportarían CERO a la búsqueda.")

    ausentes_reales = diag.get("terminos_ausentes", [])
    if ausentes_reales:
        print(f"\n  ⚠️  Siguen sin coincidencia TRAS expandir: {ausentes_reales}")
        print("      Es un hueco REAL del corpus, no de vocabulario. O falta el")
        print("      documento, o al tesauro le falta esa equivalencia: añádela")
        print("      en src/rag/tesauro.py o en config/tesauro_rag.yaml.")

    # ── PASO 3 ───────────────────────────────────────────────────────────────
    _regla("PASO 3 · PUNTUACIÓN BM25 (señal principal)")
    print("  BM25 suma, por cada término de la consulta:")
    print("      IDF(término) × (saturación por frecuencia y longitud del chunk)")
    print("  Premia repetición, pero con rendimientos decrecientes, y penaliza")
    print(f"  los chunks largos (aquí la media es {bm25.avgdl:.0f} tokens).\n")
    brutos_bm25 = bm25.get_scores(tokens)
    orden = sorted(range(len(brutos_bm25)), key=lambda i: -brutos_bm25[i])
    print(f"      {'#':>3} {'fuente':42} {'tokens':>7} {'BM25':>9}")
    print(f"      {'-'*3} {'-'*42} {'-'*7} {'-'*9}")
    for i in orden[:6]:
        print(f"      {i:>3} {indice.chunks[i]['fuente'][:42]:42} "
              f"{len(indice.tokens[i]):>7} {brutos_bm25[i]:>9.4f}")

    # ── PASO 4 ───────────────────────────────────────────────────────────────
    _regla("PASO 4 · COBERTURA ABSOLUTA — el corte de verdad")
    unicos = set(tokens)
    suma_idf = sum(max(bm25.idf.get(t, 0.0), 0.0) for t in unicos)
    print("  COBERTURA = fracción del peso informativo (Σ IDF) de la consulta que")
    print("  el fragmento cubre. Es ABSOLUTA: un 0.40 significa lo mismo en esta")
    print("  búsqueda y en cualquier otra. Ponderar por IDF hace que acertar un")
    print("  término raro valga más que acertar uno común.\n")
    print(f"  Peso informativo de esta consulta: Σ IDF = {suma_idf:.2f}")
    if suma_idf < cfg.PESO_INFORMATIVO_MINIMO:
        print(f"\n  ⚠️  POR DEBAJO DEL UMBRAL ({cfg.PESO_INFORMATIVO_MINIMO}). Esta consulta NO")
        print("      DISCRIMINA en este corpus: sus términos son omnipresentes o")
        print("      no aparecen. Lo que salga cubrirá mucho de una pregunta que")
        print("      pregunta poco — el bloque del prompt lo declarará.")

    supera = 0
    for i in range(len(indice)):
        com = unicos & set(indice.tokens[i])
        if not com:
            continue
        c = (sum(max(bm25.idf.get(t, 0.0), 0.0) for t in com) / suma_idf
             if suma_idf > 0 else len(com) / len(unicos))
        if c >= cfg.MIN_COBERTURA:
            supera += 1
    print(f"\n  Fragmentos que superan RAG_MIN_COBERTURA = {cfg.MIN_COBERTURA}: "
          f"{supera} de {len(indice)}")
    if supera == 0:
        print("\n  → Ninguno. El buscador devuelve [] y la validación sigue sin")
        print("    contexto RAG. Es el comportamiento correcto.")
        return 0

    # ── PASO 5 ───────────────────────────────────────────────────────────────
    _regla("PASO 5 · ORDENACIÓN (score relativo) Y TOP-K")
    total = cfg.PESO_BM25 + cfg.PESO_TFIDF
    print(f"  score = ({cfg.PESO_BM25} × BM25_norm + {cfg.PESO_TFIDF} × "
          f"TFIDF_norm) / {total}\n")
    print("  Cada señal se normaliza dividiendo por su máximo EN ESTA CONSULTA,")
    print("  así que el mejor fragmento saca 1.00 POR CONSTRUCCIÓN.\n")
    print("  ⚠️  Por eso `score` ORDENA pero no MIDE, y NO es lo que se reporta.")
    print("      La relevancia que viaja al prompt y al informe es COBERTURA.")
    print("      Compara las dos columnas de abajo.\n")

    resultados = buscador.buscar(consulta, top_k=top_k)
    if not resultados:
        print("  Sin resultados.")
        return 0

    print(f"      {'#':>2} {'fuente':34} {'ch':>3} {'BM25n':>7} {'TFIDFn':>7} "
          f"{'COBERTURA':>10} {'score':>7}")
    print(f"      {'':>2} {'':34} {'':>3} {'':>7} {'':>7} "
          f"{'(absoluta)':>10} {'(rel.)':>7}")
    print(f"      {'-'*2} {'-'*34} {'-'*3} {'-'*7} {'-'*7} {'-'*10} {'-'*7}")
    for n, r in enumerate(resultados, 1):
        print(f"      {n:>2} {r['fuente'][:34]:34} {r['chunk']:>3} "
              f"{r['score_bm25']:>7.4f} {r['score_tfidf']:>7.4f} "
              f"{r['cobertura']:>10.4f} {r['score']:>7.4f}")

    r = resultados[0]
    print(f"\n  Comprobación del #1 a mano:")
    print(f"      ({cfg.PESO_BM25} × {r['score_bm25']:.4f} + {cfg.PESO_TFIDF} × "
          f"{r['score_tfidf']:.4f}) / {total} = "
          f"{(cfg.PESO_BM25*r['score_bm25'] + cfg.PESO_TFIDF*r['score_tfidf'])/total:.4f}")

    # ── PASO 6 ───────────────────────────────────────────────────────────────
    _regla("PASO 6 · QUÉ SE INYECTA EN EL PROMPT")
    print(f"  El corte ABSOLUTO ya se aplicó en el paso 4 "
          f"(RAG_MIN_COBERTURA = {cfg.MIN_COBERTURA}).")
    print(f"  Aquí solo se recorta la cola con RAG_MIN_SCORE = "
          f"{cfg.MIN_SCORE_DEFECTO}, que es relativo:")
    print(f"  «quédate con lo que esté al menos al {cfg.MIN_SCORE_DEFECTO:.0%} "
          f"de lo mejor de esta consulta».\n")
    print("  Fíjate en la etiqueta de cada fragmento: dice qué porcentaje de los")
    print("  términos clave cubre —un número absoluto—, no su posición relativa.\n")
    bloque = buscador.buscar_para_prompt(consulta, top_k=top_k)
    if not bloque:
        print("  (nada supera el umbral → se inyecta cadena vacía)")
    else:
        for linea in bloque.splitlines()[:14]:
            print(f"  │ {linea[:74]}")
        print(f"  │ … ({len(bloque)} caracteres en total, "
              f"{bloque.count('### [')} fragmentos)")
    print()
    return 0


def main() -> int:
    p = argparse.ArgumentParser(
        description="Explica paso a paso cómo el RAG léxico resuelve una consulta.")
    p.add_argument("--dominio", default="VaR",
                   choices=["LaR", "VaR", "ALM", "shared"])
    p.add_argument("--consulta", default=CONSULTA_EJEMPLO)
    p.add_argument("--top-k", type=int, default=3)
    p.add_argument("--verboso", action="store_true",
                   help="muestra también los logs internos del RAG")
    args = p.parse_args()

    if not args.verboso:
        # Los warnings del RAG aquí solo estorban: este script YA explica lo que
        # pasa, y con más detalle del que da un log.
        logging.disable(logging.CRITICAL)

    return explicar(args.dominio, args.consulta, args.top_k)


if __name__ == "__main__":
    raise SystemExit(main())
