#!/usr/bin/env python3
"""
scripts/web_prueba.py — arranca la web v2 en MODO PRUEBA con «usuario libre».

    python scripts/web_prueba.py              # http://127.0.0.1:8000
    python scripts/web_prueba.py --puerto 8010

Qué declara (solo en ESTE proceso; no toca `.env`):
    MODO=debug                      el usuario libre está prohibido en producción
    VIRF_IDENTIDAD_PROVEEDOR=libre  login con nombre + roles, sin Entra ID
    VIRF_FUENTE_SECRETOS=entorno    secretos desde el entorno del proceso
    VIRF_CLAVE_FIRMA_SESION         aleatoria por arranque (si no viene ya dada)
    VIRF_CLAVE_CIFRADO_REPOSO       aleatoria por arranque (si no viene ya dada)

Las claves aleatorias viven solo en memoria: al reiniciar, las sesiones caducan
y la caché cifrada del arranque anterior no se puede leer (se recalcula). Para
conservarla entre arranques, exporta tú VIRF_CLAVE_CIFRADO_REPOSO en la shell.

Escucha solo en 127.0.0.1. Las llamadas a la IA siguen necesitando la clave de
Azure OpenAI (AZURE_OPENAI_API_KEY en el entorno del proceso, nunca en `.env`).

El login corporativo (Entra ID) queda para la web v3:
docs/LOGIN_CORPORATIVO_WEB_V3.md.
"""
from __future__ import annotations

import argparse
import os
import secrets
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent

ENTORNO_PRUEBA = {
    "MODO": "debug",
    "VIRF_IDENTIDAD_PROVEEDOR": "libre",
    "VIRF_FUENTE_SECRETOS": "entorno",
}
CLAVES_EFIMERAS = ("VIRF_CLAVE_FIRMA_SESION", "VIRF_CLAVE_CIFRADO_REPOSO")


def preparar_entorno(entorno: dict) -> list[str]:
    """Aplica el modo prueba sobre `entorno`; devuelve las claves generadas."""
    entorno.update(ENTORNO_PRUEBA)
    generadas = []
    for nombre in CLAVES_EFIMERAS:
        if len(entorno.get(nombre, "")) < 32:
            entorno[nombre] = secrets.token_urlsafe(48)
            generadas.append(nombre)
    return generadas


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Web VIRF v2 en modo prueba (usuario libre).")
    ap.add_argument("--puerto", type=int, default=8000)
    a = ap.parse_args(argv)
    for flujo in (sys.stdout, sys.stderr):        # consolas Windows en cp1252
        try:
            flujo.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    generadas = preparar_entorno(os.environ)
    print("⚠️  MODO PRUEBA — usuario libre, sin SSO. No usar con datos reales ni en producción.")
    if generadas:
        print(f"   Claves efímeras de este arranque: {', '.join(generadas)} (no se muestran).")
    os.chdir(RAIZ)
    sys.path.insert(0, str(RAIZ))
    import uvicorn
    uvicorn.run("web.app:app", host="127.0.0.1", port=a.puerto)
    return 0


if __name__ == "__main__":
    sys.exit(main())
