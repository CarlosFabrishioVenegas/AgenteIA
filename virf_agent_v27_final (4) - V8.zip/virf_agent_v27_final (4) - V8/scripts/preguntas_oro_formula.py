"""
scripts/preguntas_oro_formula.py
═════════════════════════════════════════════════════════════════════════════
Golden set DISCRIMINANTE de fórmula/tabla + medición IR léxica (API-free).

POR QUÉ
───────
El set de oro base (`scripts/preguntas_oro_rag.py`) satura en recall 1.0 y no
distingue un chunker de otro. Este set anexo apunta a las secciones con FÓRMULAS
y TABLAS del corpus real —donde un chunking que parte a la mitad debería perder—
para (a) medir las métricas IR (Recall@k, Precision@5, nDCG@10 → B1/B2/B3) y
(b) resolver con evidencia si el chunking estructural mejora el retrieval.

GROUND TRUTH honesto
────────────────────
Cada consulta anota:
  · `fuente`      — documento donde vive la respuesta (nivel documento).
  · `frase_clave` — literal DISTINTIVO de la fórmula/tabla que debe SOBREVIVIR
                    intacto en un chunk recuperable. Es el ground truth fino: si
                    el chunker parte la fórmula, ningún chunk la contiene entera.
Ninguna consulta se inventa: `frase_clave` se verifica presente en el documento
(el `__main__` falla si alguna no existe). Se preservan las erratas/espaciados
de la extracción PDF (se normaliza el espacio en blanco al comparar).

Es 100% léxico y determinista: NO llama a la API.

Uso:
    python scripts/preguntas_oro_formula.py          # mide size vs estructural
"""
from __future__ import annotations

import math
import re
import sys
import tempfile
from pathlib import Path
from typing import Dict, List

_RAIZ = Path(__file__).resolve().parents[1]
if str(_RAIZ) not in sys.path:
    sys.path.insert(0, str(_RAIZ))


def norm(s: str) -> str:
    """Normaliza el espacio en blanco (la extracción PDF mete espacios dobles)."""
    return re.sub(r"\s+", " ", s or "").strip()


# ═══════════════════════════════════════════════════════════════════════════
# GOLDEN SET DISCRIMINANTE — fórmulas y tablas del corpus real
# ═══════════════════════════════════════════════════════════════════════════
# tipo: "formula" | "tabla" | "hecho". Todas discriminantes salvo las adversarias.
PREGUNTAS_FORMULA: List[Dict] = [
    # ── VaR ──────────────────────────────────────────────────────────────────
    {"id": "F-VaR-01", "dominio": "VaR", "tipo": "formula",
     "pregunta": "cuál es el estadístico de la prueba de cobertura incondicional de Kupiec POF",
     "fuente": "backtesting_VaR_Kupiec_Christoffersen.pdf",
     "frase_clave": "LR_uc = -2·ln[(1-p)^(T-N)·p^N] + 2·ln[(1-N/T)^(T-N)·(N/T)^N]"},
    {"id": "F-VaR-02", "dominio": "VaR", "tipo": "formula",
     "pregunta": "cómo se descompone la cobertura condicional de Christoffersen",
     "fuente": "backtesting_VaR_Kupiec_Christoffersen.pdf",
     "frase_clave": "LR_cc = LR_uc + LR_ind"},
    {"id": "F-VaR-03", "dominio": "VaR", "tipo": "tabla",
     "pregunta": "zona ámbar de Basilea por número de excedencias en 250 días",
     "fuente": "backtesting_VaR_Kupiec_Christoffersen.pdf",
     "frase_clave": "Zona ámbar: entre 5 y 9 excedencias"},
    {"id": "F-VaR-04", "dominio": "VaR", "tipo": "hecho",
     "pregunta": "número esperado de excedencias con 250 observaciones al 99 por ciento",
     "fuente": "backtesting_VaR_Kupiec_Christoffersen.pdf",
     "frase_clave": "el número esperado de excedencias es 2,5"},
    {"id": "F-VaR-05", "dominio": "VaR", "tipo": "hecho",
     "pregunta": "prueba de tiempo hasta el primer fallo TUFF y su distribución",
     "fuente": "backtesting_VaR_Kupiec_Christoffersen.pdf",
     "frase_clave": "distribución geométrica"},
    {"id": "F-VaR-06", "dominio": "VaR", "tipo": "formula",
     "pregunta": "fórmula de la volatilidad EWMA y el factor de decaimiento lambda diario",
     "fuente": "riskmetrics_summary.md",
     "frase_clave": "σ²_t = λ · σ²_{t-1} + (1-λ) · r²_{t-1},  λ = 0.94"},
    {"id": "F-VaR-07", "dominio": "VaR", "tipo": "formula",
     "pregunta": "expresión del VaR paramétrico para una posición larga",
     "fuente": "riskmetrics_summary.md",
     "frase_clave": "VaR_α = -(μ + σ · z_α) para posición long"},
    {"id": "F-VaR-08", "dominio": "VaR", "tipo": "hecho",
     "pregunta": "qué medida de riesgo y a qué nivel sustituye FRTB al VaR 99 por ciento",
     "fuente": "FRTB_BCBS457_riesgo_mercado.pdf",
     "frase_clave": "Expected\nShortfall (ES) al 97,5 %"},
    {"id": "F-VaR-09", "dominio": "VaR", "tipo": "hecho",
     "pregunta": "en qué consiste la prueba de atribución de pérdidas y ganancias PLAT",
     "fuente": "FRTB_BCBS457_riesgo_mercado.pdf",
     "frase_clave": "Attribution Test, PLAT"},
    # ── LaR ──────────────────────────────────────────────────────────────────
    {"id": "F-LaR-10", "dominio": "LaR", "tipo": "formula",
     "pregunta": "definición del coeficiente de cobertura de liquidez LCR como cociente",
     "fuente": "LCR_BCBS238_coeficiente_cobertura_liquidez.pdf",
     "frase_clave": "cociente entre el stock de activos líquidos de alta calidad (HQLA) y las salidas"},
    {"id": "F-LaR-11", "dominio": "LaR", "tipo": "hecho",
     "pregunta": "horizonte en días del escenario de estrés del LCR",
     "fuente": "LCR_BCBS238_coeficiente_cobertura_liquidez.pdf",
     "frase_clave": "treinta días naturales"},
    {"id": "F-LaR-12", "dominio": "LaR", "tipo": "tabla",
     "pregunta": "qué comprenden los activos de Nivel 2A del HQLA",
     "fuente": "LCR_BCBS238_coeficiente_cobertura_liquidez.pdf",
     "frase_clave": "Los activos de Nivel 2A comprenden"},
    {"id": "F-LaR-13", "dominio": "LaR", "tipo": "formula",
     "pregunta": "definición del NSFR como cociente entre financiación disponible y requerida",
     "fuente": "NSFR_BCBS295_financiacion_estable.pdf",
     "frase_clave": "cociente entre la financiación estable disponible (Available Stable Funding, ASF) y"},
    {"id": "F-LaR-14", "dominio": "LaR", "tipo": "hecho",
     "pregunta": "qué factor recibe el capital regulatorio en el ASF del NSFR",
     "fuente": "NSFR_BCBS295_financiacion_estable.pdf",
     "frase_clave": "reciben el factor máximo"},
    # ── conductuales ─────────────────────────────────────────────────────────
    {"id": "F-CON-15", "dominio": "ALM", "tipo": "hecho",
     "pregunta": "cómo se mide la tasa de prepago condicional CPR y su equivalente mensual",
     "fuente": "IRRBB_modelos_conductuales_NMD.pdf",
     "frase_clave": "Conditional Prepayment Rate, CPR"},
    {"id": "F-CON-16", "dominio": "ALM", "tipo": "hecho",
     "pregunta": "descomposición núcleo y no núcleo de los depósitos sin vencimiento",
     "fuente": "IRRBB_modelos_conductuales_NMD.pdf",
     "frase_clave": "una parte estable (núcleo)"},
    {"id": "F-CON-17", "dominio": "ALM", "tipo": "tabla",
     "pregunta": "escenarios de choque de tipos de aplicación obligatoria del IRRBB",
     "fuente": "IRRBB_modelos_conductuales_NMD.pdf",
     "frase_clave": "desplazamiento paralelo al alza"},
    {"id": "F-CON-18", "dominio": "ALM", "tipo": "hecho",
     "pregunta": "qué convexidad introduce el prepago cuando bajan los tipos",
     "fuente": "IRRBB_modelos_conductuales_NMD.pdf",
     "frase_clave": "convexidad\nnegativa"},
    {"id": "F-CON-19", "dominio": "ALM", "tipo": "hecho",
     "pregunta": "qué asimetría presenta el pass-through de los depósitos",
     "fuente": "IRRBB_modelos_conductuales_NMD.pdf",
     "frase_clave": "las subidas se"},
    # ── shared ───────────────────────────────────────────────────────────────
    {"id": "F-SHR-20", "dominio": "shared", "tipo": "tabla",
     "pregunta": "cuántos principios y en cuántas secciones organiza BCBS 239",
     "fuente": "BCBS_239_agregacion_datos_riesgo.pdf",
     "frase_clave": "catorce  principios  organizados  en  cuatro  secciones"},
    {"id": "F-SHR-21", "dominio": "shared", "tipo": "hecho",
     "pregunta": "qué exige el principio 3 de exactitud e integridad sobre los datos",
     "fuente": "BCBS_239_agregacion_datos_riesgo.pdf",
     "frase_clave": "diccionario de datos"},
    {"id": "F-SHR-22", "dominio": "shared", "tipo": "hecho",
     "pregunta": "tres componentes de la validación en el marco SR 11-7",
     "fuente": "SR_11-7_gestion_riesgo_modelo.pdf",
     "frase_clave": "conceptual  soundness"},
    {"id": "F-SHR-23", "dominio": "shared", "tipo": "hecho",
     "pregunta": "qué es el effective challenge en la validación de modelos",
     "fuente": "SR_11-7_gestion_riesgo_modelo.pdf",
     "frase_clave": "effective challenge"},
    {"id": "F-SHR-24", "dominio": "shared", "tipo": "hecho",
     "pregunta": "qué artículos del CRR exigen validar los sistemas de calificación internos",
     "fuente": "validacion_interna_expectativas_supervisoras_UE.pdf",
     "frase_clave": "El artículo 185 del CRR"},
    {"id": "F-SHR-25", "dominio": "shared", "tipo": "hecho",
     "pregunta": "qué guía del BCE regula los modelos internos",
     "fuente": "validacion_interna_expectativas_supervisoras_UE.pdf",
     "frase_clave": "(TRIM)"},
]

# Adversarias: preguntadas al dominio EQUIVOCADO, vocabulario financiero compartido.
ADVERSARIAS_FORMULA: List[Dict] = [
    {"id": "AF-01", "dominio": "VaR",
     "pregunta": "modelo de scoring de admisión de tarjetas de crédito minorista"},
    {"id": "AF-02", "dominio": "LaR",
     "pregunta": "estadístico LR_uc del backtesting de excedencias de Kupiec"},
    {"id": "AF-03", "dominio": "ALM",
     "pregunta": "expected shortfall al 97,5 por ciento y horizontes de liquidez FRTB"},
    {"id": "AF-04", "dominio": "shared",
     "pregunta": "factor de decaimiento lambda 0.94 del alisado exponencial EWMA"},
]


# ═══════════════════════════════════════════════════════════════════════════
# MEDICIÓN — construye índices en temp (no toca producción) por chunker
# ═══════════════════════════════════════════════════════════════════════════
DOMINIOS = ["VaR", "LaR", "ALM", "shared"]


def _buscadores(estructural: bool, base_tmp: Path) -> Dict[str, object]:
    from src.rag.indexador_lexico import IndexadorLexico
    from src.rag.buscador_lexico import BuscadorLexico
    out = {}
    for dom in DOMINIOS:
        idx = IndexadorLexico(dom, estructural=estructural)
        idx.ruta = base_tmp / f"{'estr' if estructural else 'size'}_{dom}.pkl"
        idx.construir(force=True)
        b = BuscadorLexico(dom, autoconstruir=False)
        b._indexador = idx
        out[dom] = b
    return out


def _ndcg(rels: List[int], k: int) -> float:
    dcg = sum(r / math.log2(i + 2) for i, r in enumerate(rels[:k]))
    ideal = sorted(rels, reverse=True)
    idcg = sum(r / math.log2(i + 2) for i, r in enumerate(ideal[:k]))
    return (dcg / idcg) if idcg > 0 else 0.0


def evaluar_chunker(estructural: bool, base_tmp: Path, top_k: int = 10) -> Dict:
    bus = _buscadores(estructural, base_tmp)
    filas = []
    for p in PREGUNTAS_FORMULA:
        res = bus[p["dominio"]].buscar(p["pregunta"], top_k=top_k)
        fuentes = [r.get("fuente", "") for r in res]
        textos = [norm(r.get("texto", "")) for r in res]
        fk = norm(p["frase_clave"])
        # doc-level: ¿aparece el documento esperado en top-k?
        doc_rank = next((i + 1 for i, f in enumerate(fuentes)
                         if p["fuente"].lower() in f.lower()), None)
        # chunk-level (discriminante): ¿algún chunk recuperado contiene la frase entera?
        ans_rank = next((i + 1 for i, t in enumerate(textos) if fk in t), None)
        rels = [1 if fk in t else 0 for t in textos]  # relevancia = chunk porta la respuesta
        prec5 = sum(1 for f in fuentes[:5] if p["fuente"].lower() in f.lower()) / 5.0
        filas.append({"id": p["id"], "doc_rank": doc_rank, "ans_rank": ans_rank,
                      "prec5": prec5, "ndcg10": _ndcg(rels, 10)})
    n = len(filas)

    def r_at(campo, k):
        return sum(1 for f in filas if f[campo] and f[campo] <= k) / n

    return {
        "n": n,
        "doc_recall@1": r_at("doc_rank", 1), "doc_recall@3": r_at("doc_rank", 3),
        "doc_recall@10": r_at("doc_rank", 10),
        "ans@1": r_at("ans_rank", 1), "ans@3": r_at("ans_rank", 3),
        "ans@10": r_at("ans_rank", 10),
        "precision@5": sum(f["prec5"] for f in filas) / n,
        "ndcg@10": sum(f["ndcg10"] for f in filas) / n,
        "filas": filas,
    }


def verificar_ground_truth() -> List[str]:
    """Falla si alguna frase_clave NO existe en su documento (no inventar GT)."""
    from src.rag.indexador_lexico import IndexadorLexico
    faltan = []
    cache = {}
    for p in PREGUNTAS_FORMULA:
        key = (p["dominio"], p["fuente"])
        if key not in cache:
            idx = IndexadorLexico(p["dominio"])
            cache[key] = norm(idx._leer_archivo(_RAIZ / "inputs" / "rag" /
                                                p["dominio"] / p["fuente"]))
        if norm(p["frase_clave"]) not in cache[key]:
            faltan.append(p["id"])
    return faltan


if __name__ == "__main__":
    faltan = verificar_ground_truth()
    if faltan:
        print("❌ frase_clave inexistente en el corpus:", faltan)
        sys.exit(1)
    print(f"✅ ground truth verificado: {len(PREGUNTAS_FORMULA)} consultas, "
          f"{len(ADVERSARIAS_FORMULA)} adversarias. Todas las frase_clave existen.\n")

    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        size = evaluar_chunker(False, base)
        estr = evaluar_chunker(True, base)

    cols = ["doc_recall@1", "doc_recall@3", "doc_recall@10",
            "ans@1", "ans@3", "ans@10", "precision@5", "ndcg@10"]
    print(f"{'métrica':16s} | {'size':>7s} | {'estructural':>11s}")
    print("-" * 42)
    for c in cols:
        print(f"{c:16s} | {size[c]:7.3f} | {estr[c]:11.3f}")

    # Artefacto máquina-legible para el verificador (B1/B2/B3).
    import json
    art = {
        "n_discriminantes": len(PREGUNTAS_FORMULA),
        "n_adversarias": len(ADVERSARIAS_FORMULA),
        "size": {c: round(size[c], 4) for c in cols},
        "estructural": {c: round(estr[c], 4) for c in cols},
        # B1/B2/B3 se reportan sobre el chunker DEFAULT (size, opt-in vigente).
        "B1_recall@10": round(size["doc_recall@10"], 4),
        "B2_precision@5": round(size["precision@5"], 4),
        "B3_ndcg@10": round(size["ndcg@10"], 4),
    }
    out = _RAIZ / "docs" / "evidencia" / "retrieval_metrics.json"
    out.write_text(json.dumps(art, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n-> {out}")
