#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
scripts/pipeline_calidad_datos.py
Pipeline de calidad de datos DEL VALIDADOR. Genera la tabla que el agente lee.

    python scripts/pipeline_calidad_datos.py                    # ejecuta y escribe
    python scripts/pipeline_calidad_datos.py --dry-run          # muestra sin escribir
    python scripts/pipeline_calidad_datos.py --raiz modelos/VaR_FRTB
    python scripts/pipeline_calidad_datos.py --plan mi_plan.json

DE QUIÉN ES ESTE FICHERO
────────────────────────
Tuyo, no del agente. Vive en `scripts/` a propósito: **el agente nunca lo
ejecuta ni lo importa**. Tú lo corres en tu máquina, revisas lo que sale, y el
agente después LEE la tabla. Esa separación es lo que hace que puedas firmar el
resultado: quien corre la prueba es quien responde de ella.

Si algún día alguien lo llama desde `agente.py`, se rompe el modelo entero.
Hay un test que lo impide.

QUÉ HACE
────────
1. Carga los datasets de `inputs/calidad_datos/datasets/`.
2. Ejecuta el PLAN de controles (abajo) usando el catálogo de motores que ya
   existe en `modulos/motores_datos.py` — unicidad, duplicados, nulos,
   outliers, rango, integridad referencial, tipo de dato y completitud.
3. Escribe `inputs/calidad_datos/resultadocalidad_de_datos/motores_calidad_<fecha>.xlsx`
   con las cuatro columnas que el agente espera:

       Descripción · % de incumplimiento · Resultado · Detalle de observación

CÓMO LO HACES TUYO
──────────────────
El PLAN es una lista de diccionarios: añadir un control es añadir una entrada,
sin tocar código. Y si necesitas una comprobación que el catálogo no cubre,
escribe una función `def mi_control(datasets) -> dict` y regístrala en
`CONTROLES_PROPIOS`: el pipeline la ejecuta igual y su resultado sale en la
misma tabla. Ahí hay un ejemplo funcionando (`_control_fechas_coherentes`).

Se puede cargar un plan externo con `--plan plan.json` para no tocar este
fichero.

POR QUÉ NO PONE EL VEREDICTO POR SU CUENTA
──────────────────────────────────────────
La columna `Resultado` sale del umbral que TÚ declaras en cada control
(`umbral`), no de un criterio que se invente el pipeline. El umbral es una
decisión de la entidad —igual que los de `PROCEDIMIENTO_VALIDACION.md`— y aquí
solo se aplica el que pongas. Sin `umbral`, el control se ejecuta pero deja el
veredicto vacío y el agente lo tratará como observación sin puntaje.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

_RAIZ = Path(__file__).resolve().parent.parent
if str(_RAIZ) not in sys.path:
    sys.path.insert(0, str(_RAIZ))


# ═════════════════════════════════════════════════════════════════════════════
# EL PLAN — edítalo para que sea el tuyo
# ═════════════════════════════════════════════════════════════════════════════
#
# Campos:
#   descripcion  qué comprueba, en la frase que quieres ver en el informe
#   dataset      nombre del fichero en datasets/, sin extensión
#   motor        uno de `modulos.motores_datos.motores_disponibles()`
#   umbral       tolerancia declarada POR TI. >=1 = nº de hallazgos tolerados;
#                entre 0 y 1 = proporción; 0 = tolerancia cero.
#   cfg          parámetros del motor (columnas, mínimos, máximos…)

PLAN: List[Dict[str, Any]] = [
    {
        "descripcion": "Unicidad de Cliente por Cuenta",
        "dataset": "data_subset", "motor": "unicidad", "umbral": 0,
        "cfg": {"group_cols": "Cuenta", "campo_objetivo": "Cliente"},
    },
    {
        "descripcion": "Ausencia de filas duplicadas en la cartera",
        "dataset": "data_subset", "motor": "duplicados", "umbral": 0,
        "cfg": {"group_cols": "Cuenta,Cliente,FechaApertura"},
    },
    {
        "descripcion": "Completitud de FechaVencimiento",
        "dataset": "data_subset", "motor": "missing", "umbral": 0.005,
        "cfg": {"campo_objetivo": "FechaVencimiento"},
    },
    {
        "descripcion": "Integridad referencial Cliente → maestro de clientes",
        "dataset": "data_subset", "motor": "integridad_referencial", "umbral": 0,
        "cfg": {"campo_objetivo": "Cliente", "dataset_ref": "maestro_clientes",
                "campo_ref": "Cliente"},
    },
    {
        "descripcion": "Tasa de interés dentro del rango admisible [0, 1]",
        "dataset": "data_subset", "motor": "rango", "umbral": 0,
        "cfg": {"campo_objetivo": "Tasa", "min": 0, "max": 1},
    },
    {
        "descripcion": "Valores atípicos en la tasa de interés",
        "dataset": "data_subset", "motor": "outliers", "umbral": 0.02,
        "cfg": {"campo_objetivo": "Tasa"},
    },
    {
        "descripcion": "Tipo de dato de FechaApertura (fecha válida)",
        "dataset": "data_subset", "motor": "tipo_dato", "umbral": 0,
        "cfg": {"campo_objetivo": "FechaApertura", "tipo_esperado": "fecha"},
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# CONTROLES PROPIOS — lo que el catálogo no cubre
# ═════════════════════════════════════════════════════════════════════════════
#
# Firma: `def control(datasets: dict) -> dict` devolviendo al menos
# `n_total`, `n_hallazgos` y `detalle`. El pipeline calcula la tasa y aplica
# tu umbral igual que con los motores del catálogo.

def _control_fechas_coherentes(datasets: Dict[str, Any]) -> Dict[str, Any]:
    """
    FechaVencimiento debe ser posterior a FechaApertura.

    Ejemplo de control propio: el catálogo valida rangos y tipos columna a
    columna, pero no relaciones ENTRE columnas — y una operación que vence
    antes de abrirse es un error de datos que ningún control por columna ve.
    """
    import pandas as pd
    df = datasets.get("data_subset")
    if df is None:
        return {"error": "falta el dataset data_subset"}
    a = pd.to_datetime(df["FechaApertura"], errors="coerce")
    v = pd.to_datetime(df["FechaVencimiento"], errors="coerce")
    malas = (v <= a) & a.notna() & v.notna()
    n = int(malas.sum())
    ejemplos = df.loc[malas, ["Cuenta", "FechaApertura", "FechaVencimiento"]].head(3)
    return {
        "n_total": int(len(df)),
        "n_hallazgos": n,
        "detalle": (f"{n} operación(es) con vencimiento anterior o igual a la "
                    f"apertura." + (f" Ejemplos: {ejemplos.to_dict('records')}"
                                    if n else " Sin incidencias.")),
    }


CONTROLES_PROPIOS: Dict[str, Dict[str, Any]] = {
    "fechas_coherentes": {
        "descripcion": "Coherencia FechaVencimiento > FechaApertura",
        "funcion": _control_fechas_coherentes,
        "umbral": 0,
    },
}


# ═════════════════════════════════════════════════════════════════════════════
# EJECUCIÓN
# ═════════════════════════════════════════════════════════════════════════════

def _veredicto(tasa: Optional[float], n_hallazgos: int,
               umbral: Optional[float]) -> str:
    """
    Aplica TU umbral. No inventa criterio propio.

    Sin umbral declarado el veredicto queda vacío: el agente lo leerá como
    observación sin puntaje, que es preferible a que este script decida por la
    entidad qué es aceptable.
    """
    if umbral is None:
        return ""
    if umbral >= 1:                      # conteo absoluto de hallazgos
        return "OK" if n_hallazgos <= umbral else "FALLA"
    return "OK" if (tasa or 0.0) <= float(umbral) else "FALLA"


def ejecutar_plan(raiz: Path, plan: Optional[List[Dict]] = None,
                  propios: Optional[Dict[str, Dict]] = None) -> List[Dict]:
    """Corre el plan y devuelve las filas de la tabla. NUNCA lanza por control."""
    from modulos.motores_datos import cargar_datasets, ejecutar_motor

    carpeta_ds = Path(raiz) / "calidad_datos" / "datasets"
    datasets = cargar_datasets(carpeta_ds) or {}
    if not datasets:
        print(f"  ⚠️  Sin datasets en {carpeta_ds}")
    else:
        print(f"  📊 {len(datasets)} dataset(s): {', '.join(sorted(datasets))}")

    filas: List[Dict[str, Any]] = []

    for i, item in enumerate(plan if plan is not None else PLAN, 1):
        desc = item["descripcion"]
        df = datasets.get(item["dataset"])
        if df is None:
            filas.append({
                "Descripción": desc, "% de incumplimiento": None,
                "Resultado": "", "Umbral": item.get("umbral"),
                "Detalle de observación": (
                    f"NO EJECUTADO: falta el dataset «{item['dataset']}». "
                    f"Se declara en vez de omitirlo, para que no parezca que "
                    f"el control pasó."),
            })
            print(f"  {i}. ⚪ {desc[:52]} — sin dataset")
            continue

        cfg = dict(item.get("cfg") or {})
        # El catálogo lee sus parámetros en MINÚSCULA (`campo_objetivo`,
        # `group_cols`, `umbral`…). Se normaliza aquí para que el plan pueda
        # escribirse como resulte natural sin que un control falle por la caja.
        cfg = {str(k).lower(): v for k, v in cfg.items()}
        cfg.setdefault("umbral", item.get("umbral"))
        cfg.setdefault("control_id", f"CTRL_{i:02d}")
        cfg.setdefault("dataset", item["dataset"])
        # El motor de integridad referencial necesita el dataset de referencia
        # ya cargado: lo espera en `_df_ref`.
        if item["motor"] == "integridad_referencial":
            cfg["_df_ref"] = datasets.get(cfg.get("dataset_ref"))

        try:
            r = ejecutar_motor(item["motor"], df, cfg)
        except Exception as exc:                       # nunca tumba el plan
            r = {"error": f"{type(exc).__name__}: {exc}"}

        if r.get("error"):
            filas.append({
                "Descripción": desc, "% de incumplimiento": None,
                "Resultado": "", "Umbral": item.get("umbral"),
                "Detalle de observación": f"NO EJECUTADO: {r['error']}",
            })
            print(f"  {i}. ❌ {desc[:52]} — {r['error'][:40]}")
            continue

        tasa = float(r.get("tasa_error") or 0.0)
        ver = _veredicto(tasa, int(r.get("n_hallazgos") or 0), item.get("umbral"))
        filas.append({
            "Descripción": desc,
            "% de incumplimiento": round(tasa * 100, 4),
            "Resultado": ver,
            # La TOLERANCIA viaja con el resultado. Sin ella el agente no puede
            # saber si un FALLA lo fue sobre tolerancia cero —que baja el tope
            # del puntaje a 3— o sobre un umbral holgado, y tendría que
            # suponerlo. Se escribe aunque sea 0: la ausencia de columna y el
            # valor 0 significan cosas distintas.
            "Umbral": item.get("umbral"),
            "Detalle de observación": str(r.get("detalle") or "")[:800],
        })
        icono = "✅" if ver == "OK" else ("🔴" if ver == "FALLA" else "⚪")
        print(f"  {i}. {icono} {desc[:52]}  {tasa*100:.2f}%  {ver or '—'}")

    # ── Controles propios ───────────────────────────────────────────────────
    for j, (clave, spec) in enumerate((propios if propios is not None
                                       else CONTROLES_PROPIOS).items(),
                                      len(filas) + 1):
        desc = spec["descripcion"]
        try:
            r = spec["funcion"](datasets) or {}
        except Exception as exc:
            r = {"error": f"{type(exc).__name__}: {exc}"}

        if r.get("error"):
            filas.append({"Descripción": desc, "% de incumplimiento": None,
                          "Resultado": "", "Umbral": spec.get("umbral"),
                          "Detalle de observación": f"NO EJECUTADO: {r['error']}"})
            print(f"  {j}. ❌ {desc[:52]} — {str(r['error'])[:40]}")
            continue

        total = int(r.get("n_total") or 0)
        n = int(r.get("n_hallazgos") or 0)
        tasa = (n / total) if total else 0.0
        ver = _veredicto(tasa, n, spec.get("umbral"))
        filas.append({
            "Descripción": desc,
            "% de incumplimiento": round(tasa * 100, 4),
            "Resultado": ver,
            "Umbral": spec.get("umbral"),
            "Detalle de observación": str(r.get("detalle") or "")[:800],
        })
        icono = "✅" if ver == "OK" else ("🔴" if ver == "FALLA" else "⚪")
        print(f"  {j}. {icono} {desc[:52]}  {tasa*100:.2f}%  {ver or '—'}  [propio]")

    return filas


def escribir_tabla(filas: List[Dict], raiz: Path,
                   nombre: Optional[str] = None) -> Path:
    """Escribe la tabla donde el agente la busca."""
    import pandas as pd
    from modulos.motores_entidad import SUBCARPETA

    destino = Path(raiz) / "calidad_datos" / SUBCARPETA
    destino.mkdir(parents=True, exist_ok=True)
    ruta = destino / (nombre or f"motores_calidad_{date.today().isoformat()}.xlsx")
    pd.DataFrame(filas).to_excel(ruta, index=False)
    return ruta


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[2])
    ap.add_argument("--raiz", default="inputs",
                    help="raíz de evidencia (por defecto inputs/); "
                         "usa modelos/<X>/inputs para un modelo concreto")
    ap.add_argument("--dry-run", action="store_true",
                    help="ejecuta y muestra, pero NO escribe la tabla")
    ap.add_argument("--plan", help="JSON con un plan externo")
    ap.add_argument("--salida", help="nombre del fichero de salida")
    args = ap.parse_args()

    raiz = Path(args.raiz)
    if raiz.name != "inputs" and (raiz / "inputs").is_dir():
        raiz = raiz / "inputs"

    plan = PLAN
    if args.plan:
        plan = json.loads(Path(args.plan).read_text(encoding="utf-8"))
        print(f"  📋 Plan externo: {args.plan} ({len(plan)} control(es))")

    print("=" * 74)
    print("  PIPELINE DE CALIDAD DE DATOS — ejecutado por el VALIDADOR")
    print("=" * 74)
    print(f"  Evidencia: {raiz.resolve()}")

    filas = ejecutar_plan(raiz, plan)
    if not filas:
        print("\n  ⚠️  Ningún control produjo resultado.")
        return 1

    n_falla = sum(1 for f in filas if f["Resultado"] == "FALLA")
    n_sin = sum(1 for f in filas if not f["Resultado"])
    print("\n" + "-" * 74)
    print(f"  {len(filas)} control(es) · {n_falla} con incumplimiento · "
          f"{n_sin} sin veredicto")

    if args.dry_run:
        print("\n  --dry-run: no se escribió nada.")
        return 0

    ruta = escribir_tabla(filas, raiz, args.salida)
    print(f"\n  ✅ Tabla escrita: {ruta}")
    print("     El agente la leerá en la próxima corrida. NO la ejecuta:")
    print("     solo consume este resultado.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
