#!/usr/bin/env python3
"""
scripts/generar_inventario_fuentes.py  [Paso 11]

Regenera gobierno/inventario_fuentes.csv desde el corpus RAG (inputs/rag/) y el
registro de dueños/vigencias (gobierno/registro_fuentes_rag.json), y lista las
fuentes huérfanas (sin dueño) y vencidas.

    python scripts/generar_inventario_fuentes.py
"""
from __future__ import annotations

import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    from modulos.fuentes_rag import escribir_inventario_csv
    filas = escribir_inventario_csv(RAIZ / "gobierno" / "inventario_fuentes.csv")
    huerf = [f for f in filas if f["estado"] == "huerfana"]
    venc = [f for f in filas if f["estado"] == "vencida"]
    print(f"{len(filas)} fuentes · {len(huerf)} huérfanas · {len(venc)} vencidas")
    for f in huerf + venc:
        print(f"  [{f['estado']}] {f['dominio']}/{f['fuente']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
