#!/usr/bin/env python3
"""
scripts/generar_observabilidad.py  [Pasos 56 · 57]

Genera el dataset del dashboard operativo y el reporte de costes desde la
bitácora de auditoría:

    python scripts/generar_observabilidad.py                 # → observabilidad/datos/
    python scripts/generar_observabilidad.py --destino otra/carpeta

La especificación del dashboard (tablas, medidas, alertas) está en
observabilidad/ESPECIFICACION_DASHBOARD.md. Publicar en Power BI es un paso
humano: el agente no accede al tenant.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--destino", default=str(RAIZ / "observabilidad" / "datos"))
    a = ap.parse_args(argv)
    from modulos.auditoria import ruta_log, verificar
    from modulos.observabilidad import generar
    v = verificar()
    if not v["ok"]:
        print(f"✗ La bitácora no pasa la verificación (roto en {v['roto_en']}): no se genera.")
        return 1
    res = generar(Path(a.destino))
    print(f"✓ {res['llamadas']} llamadas desde {ruta_log()} → {a.destino}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
