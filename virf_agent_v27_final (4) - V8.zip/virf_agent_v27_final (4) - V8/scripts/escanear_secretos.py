#!/usr/bin/env python3
"""
scripts/escanear_secretos.py  [SEG-03]
═════════════════════════════════════════════════════════════════════════════
Escaneo de credenciales en el repositorio. Sin dependencias (solo `re` + git),
para que corra igual en el PC, en el pre-commit y en el pipeline.

    python scripts/escanear_secretos.py              # archivos versionados
    python scripts/escanear_secretos.py --staged     # lo que va a commitearse
    python scripts/escanear_secretos.py --historial  # todo el historial git

Sale con código 1 si encuentra algo. NUNCA imprime el secreto: solo dónde está
y de qué tipo parece, con el valor recortado a sus 4 primeros caracteres.

No sustituye a gitleaks/detect-secrets corporativos: si el banco tiene uno
aprobado, debe correr además de este (ver .pre-commit-config.yaml).
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path
from typing import Iterable, Iterator, List, Tuple

RAIZ = Path(__file__).resolve().parent.parent

PATRONES: List[Tuple[str, re.Pattern]] = [
    ("anthropic_api_key", re.compile(r"sk-ant-[A-Za-z0-9_\-]{20,}")),
    ("openai_api_key", re.compile(r"\bsk-(?!ant-)(?:proj-|svcacct-)?[A-Za-z0-9_\-]{32,}")),
    ("databricks_token", re.compile(r"\bdapi[0-9a-f]{32}\b")),
    ("azure_key_con_contexto", re.compile(
        r"(?i)(?:azure[_-]?openai[_-]?api[_-]?key|api[_-]?key|ocp-apim-subscription-key)"
        r"[\"']?\s*[:=]\s*[\"']?([0-9a-f]{32}|[A-Za-z0-9]{84})\b")),
    ("clave_privada", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("secreto_generico", re.compile(
        r"(?i)\b(?:api[_-]?key|secret|token|password|passwd|contrase[ñn]a)\b[\"']?\s*[:=]\s*"
        r"[\"']([^\"'\s]{24,})[\"']")),
]

# Valores que son plantilla, no credencial.
_PLACEHOLDERS = re.compile(
    r"(?i)(TU_|YOUR_|XXXX|placeholder|example|ejemplo|<[^>]+>|\*{4,}|●|REDACTED|"
    r"NEVER_COMMIT|\$\{|\{\{)")

_BINARIOS = {".pdf", ".pptx", ".docx", ".xlsx", ".xlsm", ".xls", ".png", ".jpg",
             ".jpeg", ".gif", ".ico", ".bundle", ".zip", ".pkl", ".parquet", ".db",
             ".sqlite", ".woff", ".woff2", ".ttf", ".pyc"}


def _git(*args: str) -> str:
    return subprocess.run(["git", *args], cwd=RAIZ, capture_output=True,
                          text=True, encoding="utf-8", errors="ignore", check=True).stdout


def _recortar(valor: str) -> str:
    return (valor[:4] + "…") if valor else "…"


def escanear_texto(texto: str, origen: str) -> Iterator[str]:
    for n, linea in enumerate(texto.splitlines(), 1):
        for tipo, patron in PATRONES:
            for m in patron.finditer(linea):
                valor = m.group(m.lastindex or 0)
                if _PLACEHOLDERS.search(valor):
                    continue
                yield f"{origen}:{n}: posible {tipo} ({_recortar(valor)})"


def _archivos(staged: bool) -> Iterable[str]:
    salida = (_git("diff", "--cached", "--name-only", "--diff-filter=ACM") if staged
              else _git("ls-files"))
    return [l for l in salida.splitlines() if l.strip()]


def escanear_arbol(staged: bool = False) -> List[str]:
    hallazgos: List[str] = []
    for rel in _archivos(staged):
        p = RAIZ / rel
        if p.suffix.lower() in _BINARIOS or not p.is_file():
            continue
        try:
            texto = (_git("show", f":{rel}") if staged
                     else p.read_text(encoding="utf-8", errors="ignore"))
        except Exception:                                     # noqa: BLE001
            continue
        hallazgos.extend(escanear_texto(texto, rel))
    return hallazgos


def escanear_historial() -> List[str]:
    """Líneas añadidas en cualquier commit de cualquier rama."""
    hallazgos: List[str] = []
    commit, fichero, n = "?", "?", 0
    for linea in _git("log", "-p", "--all", "--no-color", "--unified=0").splitlines():
        if linea.startswith("commit "):
            commit = linea.split()[1][:9]
        elif linea.startswith("+++ "):
            fichero = linea[6:] if linea.startswith("+++ b/") else linea[4:]
        elif linea.startswith("@@"):
            m = re.search(r"\+(\d+)", linea)
            n = int(m.group(1)) - 1 if m else 0
        elif linea.startswith("+") and not linea.startswith("+++"):
            n += 1
            if Path(fichero).suffix.lower() in _BINARIOS:
                continue
            for h in escanear_texto(linea[1:], f"{commit}:{fichero}"):
                hallazgos.append(h.replace(f"{commit}:{fichero}:1:", f"{commit}:{fichero}:{n}:"))
    return hallazgos


def main(argv=None) -> int:
    for flujo in (sys.stdout, sys.stderr):
        if hasattr(flujo, "reconfigure"):
            flujo.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--staged", action="store_true")
    g.add_argument("--historial", action="store_true")
    a = ap.parse_args(argv)
    hallazgos = escanear_historial() if a.historial else escanear_arbol(a.staged)
    for h in hallazgos:
        print(h)
    if hallazgos:
        print(f"\n✗ {len(hallazgos)} posible(s) secreto(s). Si alguno es real: quítalo, "
              "y pide su ROTACIÓN (ya estuvo en disco/git).", file=sys.stderr)
        return 1
    print("✓ Sin secretos detectados.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
