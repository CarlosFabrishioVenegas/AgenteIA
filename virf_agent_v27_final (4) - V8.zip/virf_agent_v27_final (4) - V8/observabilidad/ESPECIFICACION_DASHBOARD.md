> Datos elaborados por BCP para uso Interno

# Especificación del dashboard operativo

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – publicar en Power BI 👤 | 54 · 56 · 57 |

**Origen de datos:** `python scripts/generar_observabilidad.py` → `observabilidad/datos/*.csv`, construido desde la bitácora de auditoría solo-anexar (SEG-12). El script se niega a generar si la cadena de hashes de la bitácora está rota. Los CSV contienen identidades (UPN) y no se versionan.

## Tablas

| Tabla | Grano | Columnas |
|---|---|---|
| `llamadas` | una llamada a IA | cuando, dia, quien, corrida, modelo, origen, resultado, tokens_entrada, tokens_salida, tokens_estimados, latencia_ms, coste_usd |
| `costes_por_corrida` | corrida | llamadas, errores, tokens_entrada, tokens_salida, coste_usd, latencia_p95_ms, con_tokens_estimados |
| `costes_por_usuario` | usuario (UPN) | ídem |
| `uso_diario` | día | ídem |

## Medidas sugeridas (DAX)

- `Coste total = SUM(llamadas[coste_usd])`
- `Tasa de error = DIVIDE(COUNTROWS(FILTER(llamadas, LEFT(llamadas[resultado],2) <> "ok")), COUNTROWS(llamadas))`
- `Latencia p95 = PERCENTILEX.INC(llamadas, llamadas[latencia_ms], 0.95)`
- `Coste por corrida = DIVIDE([Coste total], DISTINCTCOUNT(llamadas[corrida]))`
- `% tokens estimados = DIVIDE(COUNTROWS(FILTER(llamadas, llamadas[tokens_estimados])), COUNTROWS(llamadas))`

## Alertas sugeridas (umbrales a fijar 👤)

| Alerta | Condición |
|---|---|
| Tasa de error | > 5 % en el día |
| Latencia | p95 > 30 000 ms |
| Gasto diario | `Coste total` del día > [umbral 👤] USD |

**Advertencia:** `coste_usd` usa precios de lista de `config/modelos.py` (entrada y salida), no la factura de Azure.
