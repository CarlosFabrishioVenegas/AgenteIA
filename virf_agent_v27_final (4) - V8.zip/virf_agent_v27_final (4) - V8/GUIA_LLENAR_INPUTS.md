# Guía práctica: qué poner en `inputs/`, carpeta por carpeta

> **Para quién.** El validador que va a preparar una corrida: tiene los
> documentos del modelo encima de la mesa y necesita saber **dónde va cada uno**,
> qué pasa si falta alguno, y qué comando ejecutar.
>
> **Empieza por [§1](#1-la-distinción-que-lo-gobierna-todo)** aunque tengas prisa:
> confundir las dos familias de documentos es el único error que **corrompe** un
> informe en vez de empobrecerlo.
>
> **Guías hermanas:**
> [`GUIA_CORPUS_RAG.md`](GUIA_CORPUS_RAG.md) — la literatura de referencia ·
> [`GUIA_RAG_LEXICO.md`](GUIA_RAG_LEXICO.md) — cómo funciona el buscador ·
> [`RUNBOOK.md`](RUNBOOK.md) — el flujo operativo completo
>
> Fecha: **2026-07-31** · Verificado contra `AMBITO_A_INPUTS` y `--prevuelo`

---

## Índice

- [1. La distinción que lo gobierna todo](#1-la-distinción-que-lo-gobierna-todo)
- [2. Mapa: qué carpeta alimenta qué ámbito](#2-mapa-qué-carpeta-alimenta-qué-ámbito)
- [3. Carpeta por carpeta: qué poner](#3-carpeta-por-carpeta-qué-poner)
- [4. Qué formatos se leen (y el PDF escaneado)](#4-qué-formatos-se-leen-y-el-pdf-escaneado)
- [5. Comprobar ANTES de gastar: `--prevuelo`](#5-comprobar-antes-de-gastar---prevuelo)
- [6. Si necesitas ENTENDER el modelo primero](#6-si-necesitas-entender-el-modelo-primero)
- [7. Qué pasa si falta evidencia](#7-qué-pasa-si-falta-evidencia)
- [8. Varios modelos, varias corridas](#8-varios-modelos-varias-corridas)
- [9. Orden de trabajo recomendado](#9-orden-de-trabajo-recomendado)
- [10. Checklist](#10-checklist)
- [11. Problemas frecuentes](#11-problemas-frecuentes)

---

## 1. La distinción que lo gobierna todo

Hay **dos familias** de documentos, en dos sitios distintos, y no se mezclan
nunca:

| | `inputs/documentacion/`, `calidad_datos/`, `implementacion/`, `usos/` | `inputs/rag/` |
|---|---|---|
| **Qué es** | **EVIDENCIA** del modelo que estás validando | **LITERATURA** de referencia externa |
| **Ejemplo** | El manual metodológico del LaR de tu entidad | BCBS 238, SR 11-7, Kupiec (1995) |
| **La pregunta que responde** | *¿Qué hizo este modelo?* | *¿Qué se espera de un modelo así?* |
| **Quién lo escribió** | Tu entidad | El regulador o la academia |
| **Para qué lo usa el agente** | Es **lo que evalúa** | Es **la vara con la que mide** |

### Por qué mezclarlas corrompe el informe

Si metes el manual del modelo en `inputs/rag/`, pasa esto:

> Ante la actividad *«¿el manual documenta el backtesting?»*, el buscador recupera
> fragmentos **del propio manual** y los inyecta en el prompt como «conocimiento
> recuperado del dominio». El modelo ve sus propias afirmaciones presentadas como
> **referencia autorizada que las confirma**, y se da la razón a sí mismo.

El resultado no es «peor»: es **un informe no defendible**. Y no da ningún error
— sale igual de bonito.

> 🔑 **Regla de bolsillo:** si lo escribió tu entidad sobre **este** modelo → es
> evidencia. Si lo escribió un regulador o un académico sobre **cualquier**
> modelo → es literatura.

**Esta guía trata de la EVIDENCIA.** Para la literatura, ve a
[`GUIA_CORPUS_RAG.md`](GUIA_CORPUS_RAG.md).

---

## 2. Mapa: qué carpeta alimenta qué ámbito

El agente puntúa 6 ámbitos con pesos distintos. Cada uno lee de unas carpetas
concretas (`AMBITO_A_INPUTS`, verificado en el código):

| Ámbito | Peso | Lee de |
|---|---|---|
| **Metodología** | **30 %** | `documentacion/modelamiento/` · `papers/` · `documentacion/seguimiento/` |
| **Calidad de datos** | **20 %** | `calidad_datos/` · `documentacion/modelamiento/` |
| **Documentación** | 15 % | `documentacion/modelamiento/` · `documentacion/seguimiento/` · `papers/` |
| **Implementación** | 15 % | `implementacion/` · `documentacion/modelamiento/` |
| **Gobierno** | 12 % | `documentacion/modelamiento/` · `implementacion/` |
| **Uso e integración** | 8 % | `usos/` · `implementacion/` |

### Léelo así

**`documentacion/modelamiento/` aparece en 5 de los 6 ámbitos.** Es la carpeta
más importante con diferencia: si solo tienes tiempo de preparar una, es ésta.

**Metodología + Calidad de datos = 50 % del puntaje.** Si `calidad_datos/` está
vacía, pierdes un quinto de la nota por ausencia de evidencia — no porque el
modelo sea malo.

---

## 3. Carpeta por carpeta: qué poner

### 📁 `inputs/documentacion/modelamiento/` ⭐ *la más importante*

**Qué es:** cómo se construyó el modelo. El documento que explica la metodología.

| Poner | No poner |
|---|---|
| Manual metodológico (completo, no el resumen ejecutivo) | El código fuente → va a `implementacion/` |
| Documento de diseño / nota técnica | Papers académicos → van a `papers/` |
| Justificación de supuestos y decisiones de modelización | Actas de comité → van a `usos/` |
| Descripción de fórmulas, parámetros y calibración | |
| Control de versiones / historial de cambios del documento | |
| Actas de aprobación metodológica | |

> **Detalle que cuesta puntos:** el ámbito Documentación busca *control de
> cambios/versiones*. Si tu manual lleva una tabla de versiones al principio,
> inclúyela; si vive en un documento aparte, ponlo también aquí.

---

### 📁 `inputs/calidad_datos/` — 20 % del puntaje

**Qué es:** la prueba de que los datos que alimentan el modelo están controlados.

| Poner | Notas |
|---|---|
| Manual/procedimiento de controles de calidad de datos | |
| Perfil de datos: nulos, duplicados, outliers, rangos | El estándar los nombra explícitamente |
| Evidencia de **ejecución** de esos controles | No basta con que existan: hay que probar que se corren |
| Diccionario de datos | BCBS 239 lo exige |
| Conciliaciones entre sistemas fuente | |
| Ficheros `.csv` de muestra | Van en `calidad_datos/datasets/` |
| Scripts de control (`.py`) | Se leen como código |

> **Herramienta:** `python agente.py --perfilar-datasets` genera un perfil de los
> `.csv` que dejes en `calidad_datos/datasets/`. Si no tienes perfil de datos
> documentado, esto te lo produce.

---

### 📁 `inputs/documentacion/seguimiento/` — alimenta Metodología y Documentación

**Qué es:** cómo se ha comportado el modelo **después** de ponerse en producción.

| Poner |
|---|
| Informes de seguimiento / monitoreo periódico |
| **Backtesting**: resultados, excepciones, pruebas estadísticas |
| Análisis de estabilidad de la población (PSI, CSI) |
| Análisis de sensibilidad y escenarios |
| Recalibraciones y su justificación |
| Planes de acción sobre desviaciones detectadas |

> **Es donde más se falla.** El estándar tiene varias actividades sobre
> backtesting y seguimiento. Sin esta carpeta, Metodología (30 %) queda coja
> aunque el manual sea excelente.

---

### 📁 `inputs/implementacion/` — Implementación (15 %) y Gobierno (12 %)

**Qué es:** cómo el modelo pasó del papel al sistema productivo.

| Poner | Notas |
|---|---|
| Documento de implementación / paso a producción | |
| Código fuente (`.py`) | **Se lee íntegro**, no truncado |
| Notebooks (`.ipynb`) | Soportados |
| Evidencia de pruebas: unitarias, de integración, paralelo | |
| Control de accesos y segregación de funciones | Gobierno |
| Documentación del entorno productivo | |
| Plan de contingencia / rollback | |

> **Herramienta:** `python agente.py --revisar-codigo` audita el código de esta
> carpeta y produce hallazgos concretos.

---

### 📁 `inputs/usos/` — Uso e integración (8 %)

**Qué es:** la prueba de que el modelo **se usa de verdad** en la gestión.

| Poner |
|---|
| Actas de comité donde se presentan resultados del modelo |
| Reportes periódicos a la alta dirección |
| Evidencia de decisiones tomadas con el modelo (límites, pricing, provisiones) |
| Integración en el apetito de riesgo |
| Formación a los usuarios |

> Peso pequeño (8 %) pero **fácil de llenar** y suele estar vacía. Un acta de
> comité es un PDF que ya tienes.

---

### 📁 `inputs/papers/` — apoyo de Metodología y Documentación

**Qué es:** papers técnicos **específicos de este modelo**.

> ⚠️ **Ojo, es un matiz fino.** `papers/` es EVIDENCIA: los artículos que tu
> equipo citó para construir *este* modelo. Si el manual dice «se aplica la
> corrección de Cornish-Fisher (1937)», ese paper va aquí.
>
> La literatura regulatoria **general** —BCBS, SR 11-7— va a `inputs/rag/`, que
> es otra cosa. Ver [`GUIA_CORPUS_RAG.md`](GUIA_CORPUS_RAG.md).

---

### 📁 `inputs/excel_procesos/` — opcional

Hojas de cálculo con procesos o parámetros. Se convierten a notebook con
`--convertir-excel`. Úsalo si el modelo o sus controles viven en Excel.

---

### 📁 `inputs/Estandares_VIRF.xlsx` — el estándar, no evidencia

Es **la vara de medir**: las actividades que el agente evalúa. No lo toques salvo
para mantener el estándar.

> 🐛 **Tiene erratas que cuestan cobertura RAG.** Verificadas: `seguimeinto`
> (×3), `monitorio`, `suficienica` (×2), `contengas`. Una errata es un término
> que no coincidirá con ninguna literatura, nunca. Corregirlas es la mejora de
> mejor relación coste/beneficio del sistema. Ver
> [`GUIA_CORPUS_RAG.md` §7](GUIA_CORPUS_RAG.md#7-los-dos-hallazgos-que-ya-salieron).

---

## 4. Qué formatos se leen (y el PDF escaneado)

| Formato | Estado |
|---|---|
| `.pdf` | ✅ (digital) |
| `.docx` · `.pptx` · `.xlsx` / `.xlsm` | ✅ |
| `.md` · `.txt` · `.csv` · `.json` | ✅ |
| `.py` | ✅ se lee **íntegro** |
| `.ipynb` | ✅ |
| `.doc` · `.ppt` (formatos antiguos) | ❌ conviértelos |
| **PDF escaneado** | ❌ **ver abajo** |

### El PDF escaneado

**No se puede leer.** El OCR se retiró por la política de «cero modelos externos»
(Tesseract lleva sus propios modelos de lenguaje). Un acta firmada y digitalizada,
un manual antiguo escaneado → el agente no ve nada dentro.

**Pero no falla en silencio:** la lectura se marca como fallida, la cobertura
documental baja, y el informe lo declara como **fallo técnico del agente**, nunca
como falta del validado.

**Qué hacer:** consíguelo en digital, o pásalo por la herramienta de OCR aprobada
por tu entidad **antes** de dejarlo en `inputs/`.

**Cómo detectarlos todos de golpe:** `python agente.py --prevuelo` los lista.

---

## 5. Comprobar ANTES de gastar: `--prevuelo`

**Éste es el comando que más disgustos ahorra.** Coste 0, no llama al modelo:

```bash
python agente.py --prevuelo
```

```
  ✅ LEGIBLES: 8 fichero(s) · 1,311,521 chars
       doc_modelamiento       2 fichero(s)   1,303,675 chars
       calidad_datos          2 fichero(s)       4,181 chars
       doc_seguimiento        1 fichero(s)       1,051 chars
       implementacion         1 fichero(s)       1,025 chars
       usos                   1 fichero(s)         848 chars
       papers                 1 fichero(s)         741 chars

  ✅ Los 6 ámbitos tienen evidencia: ninguno puntuará 0.0 por ausencia.
```

Te dice:

- Qué ficheros **se podrán leer** y cuánto texto aportan
- Qué PDFs están **escaneados**
- Qué formatos se **omiten sin aviso**
- **Qué ámbitos quedarán sin evidencia** y por tanto puntuarán 0.0

Sale con **código 1** si algún ámbito queda vacío, así que sirve en un script.

> **Regla:** no lances una corrida completa sin que `--prevuelo` salga en verde.
> Una corrida gasta llamadas a la API; el pre-vuelo no gasta nada.

### Lee también los tamaños

Arriba, `usos` aporta 848 caracteres: menos de una página. Formalmente hay
evidencia, así que el ámbito no puntúa 0 — pero es **muy poca cosa** para
sostener un dictamen. El pre-vuelo no juzga eso por ti; míralo tú.

---

## 6. Si necesitas ENTENDER el modelo primero

Situación típica: **te asignan la validación de un modelo que no conoces**. Antes
de puntuar nada, necesitas entender qué hace.

```bash
python agente.py --explicar-modelo "LaR" --dry-run     # inventario y coste, GRATIS
python agente.py --explicar-modelo "LaR"               # genera el documento
```

Produce `outputs/<fecha>/explicacion_del_modelo_LaR.md`: **9 secciones fijas** que
consolidan las cuatro fuentes que nadie lee juntas —manual metodológico, informe
de seguimiento, documentación de implementación y perfil/controles de datos— para
que puedas entender el modelo **sin leer el código fuente**.

### Cómo evita inventarse cosas

Un documento así es peligroso si rellena huecos: parece riguroso y no lo es. Tres
defensas, todas en el documento generado:

1. **Inventario previo.** Antes de llamar al modelo se registra qué fuente aportó
   qué ficheros, y ese inventario **se escribe dentro del documento**. Siempre
   sabes sobre qué evidencia se apoya cada afirmación.
2. **Fuentes vacías explícitas.** Si una de las cuatro no aporta nada, no se
   disimula: se marca «⚠️ Sin evidencia en fuentes» en las secciones afectadas.
3. **Discrepancias sin reconciliar.** Si el manual dice una cosa y la
   implementación otra, **lo señala** en vez de elegir una por su cuenta.

### Flags útiles

| Flag | Para qué |
|---|---|
| `--dry-run` | Inventario + coste estimado **sin gastar un token**. Úsalo siempre primero |
| `--excluir F1,F2` | Omitir ficheros concretos (p. ej. fixtures de prueba que viven en `inputs/`) |
| `--solo-coincidentes` | Usar solo los ficheros cuyo nombre contiene el modelo. **Necesario si varios modelos comparten `inputs/`** |

> **Orden recomendado:** `--prevuelo` → `--explicar-modelo --dry-run` →
> `--explicar-modelo` → leerlo → corrida completa. Llegas a la validación
> sabiendo qué estás validando.

---

## 7. Qué pasa si falta evidencia

| Situación | Consecuencia |
|---|---|
| Un ámbito **sin ningún fichero** | Puntúa **0.0**. Con Metodología eso son 30 puntos de 100 |
| Un ámbito **con poca** evidencia | Puntúa bajo con «cobertura documental» reducida, y el informe lo declara |
| Un PDF **escaneado** | Se marca **fallo técnico del agente**, no falta del validado |
| Falta **literatura** en `inputs/rag/` | El agente evalúa **sin referencia regulatoria**. No baja el puntaje, pero el dictamen pierde fundamento |

### El invariante que conviene conocer

> **La falta de evidencia arrastra el score; el fallo técnico, no.**

Si el agente **no pudo leer** un documento, eso es problema suyo y lo dice. Si el
documento **no existe**, eso sí es una carencia del modelo validado y puntúa.

Son cosas distintas y el informe las separa. No las confundas al leerlo.

---

## 8. Varios modelos, varias corridas

Si validas varios modelos, **no los mezcles en la misma `inputs/`**. El informe de
uno citaría documentos de otro.

```bash
python agente.py --raiz-evidencia /ruta/al/modelo_LaR   --titulo "Modelo LaR"
python agente.py --raiz-evidencia /ruta/al/modelo_VaR   --titulo "Modelo VaR"
```

Cada raíz tiene su propio `inputs/`. El estándar VIRF, `outputs/` y el caché
siguen en la raíz del proyecto.

> **Un modelo por raíz.** Es la forma limpia. Si por lo que sea comparten
> carpeta, usa al menos `--solo-coincidentes` en `--explicar-modelo`.

### El `--titulo` importa más de lo que parece

De él se infiere el dominio RAG:

| Si el título contiene… | Dominio |
|---|---|
| `lar`, `liquidity`, `liquidez`, `hqla` | `LaR` |
| `var`, `value at risk`, `frtb`, `riesgo de mercado` | `VaR` |
| `conductual`, `prepago`, `nmd`, `comportamiento` | `conductuales` |
| *(cualquier otra cosa)* | `shared` |

Un título mal puesto trae literatura del dominio equivocado, o ninguna.

---

## 9. Orden de trabajo recomendado

```
 1. Crear/elegir la raíz de evidencia         (§8)
 2. Repartir los documentos por carpeta       (§3)
 3. python agente.py --prevuelo               (§5)   ← ¿verde? si no, volver a 2
 4. python agente.py --explicar-modelo "X" --dry-run
 5. python agente.py --explicar-modelo "X"    (§6)   ← entender qué validas
 6. Leer la explicación generada
 7. Revisar el corpus RAG del dominio         (GUIA_CORPUS_RAG.md)
 8. Corrida completa
 9. Revisar el informe y firmar como validador
```

Los pasos 3 y 4 **no gastan nada**. Hacerlos siempre.

---

## 10. Checklist

```
EVIDENCIA
[ ]  documentacion/modelamiento/  manual metodológico completo (aparece en 5 de 6 ámbitos)
[ ]  documentacion/modelamiento/  control de versiones del documento
[ ]  documentacion/seguimiento/   backtesting y monitoreo        ← el más olvidado
[ ]  calidad_datos/               controles + EVIDENCIA de ejecución (20 % del puntaje)
[ ]  calidad_datos/datasets/      csv de muestra si los hay
[ ]  implementacion/              documento de paso a producción + código
[ ]  usos/                        actas de comité (fácil de llenar, suele estar vacío)
[ ]  papers/                      papers citados POR ESTE modelo

HIGIENE
[ ]  Ningún PDF escaneado                     (--prevuelo los lista)
[ ]  Ningún documento de OTRO modelo          (usar --raiz-evidencia)
[ ]  NADA de esto está en inputs/rag/         ← el error que corrompe (§1)
[ ]  Formatos antiguos (.doc/.ppt) convertidos

COMPROBACIÓN
[ ]  python agente.py --prevuelo              → verde, exit 0
[ ]  Revisados los TAMAÑOS, no solo la presencia
[ ]  python agente.py --explicar-modelo "X" --dry-run
[ ]  Literatura del dominio revisada          (GUIA_CORPUS_RAG.md)
[ ]  --titulo correcto para inferir el dominio RAG
```

---

## 11. Problemas frecuentes

| Síntoma | Causa | Solución |
|---|---|---|
| Un ámbito puntúa 0.0 | Carpeta vacía | `--prevuelo` te dice cuál |
| «No se pudo leer X.pdf» | PDF escaneado | Conseguirlo en digital (§4) |
| El informe cita un documento de otro modelo | `inputs/` compartida | `--raiz-evidencia` (§8) |
| El agente «se da la razón a sí mismo» | Evidencia metida en `inputs/rag/` | Sacarla de ahí (§1) |
| `rag_dominio: "shared"` cuando esperabas VaR | `--titulo` sin palabra clave | Renombrar el título (§8) |
| Puntaje bajo en Metodología con buen manual | Falta `documentacion/seguimiento/` | Aportar backtesting (§3) |
| `--explicar-modelo` mezcla dos modelos | `inputs/` compartida | `--solo-coincidentes` (§6) |
| Formato omitido sin aviso | `.doc`, `.ppt` antiguos | Convertir a `.docx`/`.pptx` |

---

## Resumen en cinco líneas

1. **Evidencia** (lo que evalúas) en `documentacion/`, `calidad_datos/`,
   `implementacion/`, `usos/`, `papers/`. **Literatura** (la vara) en
   `inputs/rag/`. **Nunca al revés.**
2. `documentacion/modelamiento/` alimenta 5 de los 6 ámbitos: es la prioritaria.
3. `--prevuelo` antes de cada corrida. Coste 0, evita gastar en una corrida coja.
4. `--explicar-modelo --dry-run` para entender el modelo sin pagar nada.
5. Lo que falte, que se note: el informe declara los huecos, y eso es lo que hace
   defendible el dictamen.
