> Datos elaborados por BCP para uso Interno

# Plan de mantenimiento y vulnerabilidades

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 75 |

| Actividad | Cadencia | Herramienta / evidencia |
|---|---|---|
| SCA (dependencias) | Mensual | `pip-audit` → `docs/seguridad/sca_pip_audit.json` |
| SAST | Por release | `bandit` → `docs/seguridad/sast_bandit.json` |
| Actualización de dependencias | Trimestral (o según severidad) | PR con suite completa |
| Escaneo de secretos | Cada commit (pre-commit) | `scripts/escanear_secretos.py` |
| Regenerar guía y grafo | Por release | skill S12 |
| Revisar fuentes vencidas del corpus | Mensual | `gobierno/inventario_fuentes.csv` |

**Plazos de parche propuestos (confirmar con Ciberseguridad 👤):** Crítica 7 días · Alta 30 días · Media 90 días · Baja siguiente ciclo trimestral.

**Estado actual:** 46 vulnerabilidades conocidas en 6 paquetes (pillow, tornado, requests, scikit-learn, PyPDF2, pytest) — pendientes de actualizar (SEG-09).
