> Datos elaborados por BCP para uso Interno

# Mapa de integraciones

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Remediado – pendiente de validación | 16 |

Coherente con la lista cerrada de SEG-01 (`config/ia.py → PROVEEDORES`).

```mermaid
flowchart LR
  U[Validador / Revisor / Admin corpus] -- "HTTPS · sesión SSO" --> W[Web VIRF FastAPI]
  W -- "OIDC · identidad" --> E[Microsoft Entra ID]
  W -- "evidencia clasificada (Público/Interno)" --> P[Pipeline agente.py]
  P -- "prompt enmascarado PII + material delimitado · Interno" --> GW[Gateway IA config/ia.py]
  GW -- "HTTPS allowlist *.openai.azure.com · Interno enmascarado" --> AZ[Azure OpenAI APROBADO]
  GW -. "BLOQUEADO (EN_ESPERA)" .-> AN[Anthropic]
  GW -. "BLOQUEADO (RETIRADO)" .-> OA[OpenAI]
  P -- "secretos (lectura)" --> KV[Azure Key Vault]
  P -- "lectura mínima: columnas+filtro · Restringido" --> DB[Databricks Unity Catalog]
  W -- "log solo-anexar" --> AUD[Auditoría → SIEM 👤]
  Dev[Código] -- "push/PR" --> REPO[Azure DevOps corporativo 👤 URL]
```

| Integración | Dirección | Clasificación del dato | ¿Pasa por enmascarado? |
|---|---|---|---|
| Usuario → Web | entrada | Público/Interno (Restringido rechazado en portátil) | No aplica |
| Web ↔ Entra ID | bidireccional | Identidad | No aplica |
| Gateway → Azure OpenAI | salida | Interno | **Sí** (PII + inyección) |
| Pipeline → Key Vault | lectura | Secreto | No aplica |
| Pipeline → Databricks | lectura | Restringido (solo en Databricks) | Antes de salir a IA, sí |
| Web → Auditoría | salida | Metadatos (sin contenido) | No contiene contenido |
| Anthropic / OpenAI | — | — | **Bloqueados** |
