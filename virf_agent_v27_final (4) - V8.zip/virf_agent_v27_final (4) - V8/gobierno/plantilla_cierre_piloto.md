> Datos elaborados por BCP para uso Interno

# Informe de cierre del piloto (plantilla)

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Plantilla | 79 |

1. **Objetivos** del piloto y alcance real.
2. **Resultados:** modelos evaluados, informes emitidos, tiempo ahorrado estimado.
3. **Métricas:** concordancia (63), alucinación (42), abstención, evaluación experta (65), costes (57), latencia p95 (56).
4. **Incidentes:** por severidad, causa raíz y estado (70).
5. **Lecciones aprendidas.**
6. **Recomendación:** industrializar / extender piloto / detener, con condiciones.
7. **Firmas** 👤.
