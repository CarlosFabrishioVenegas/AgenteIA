> Datos elaborados por BCP para uso Interno

# Control de cambios

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 74 |

Todo cambio —incluidos los del agente corporativo— sigue este flujo:

1. **Solicitud** con motivo y riesgo (backlog, Paso 66).
2. **Rama + pull request** en el repositorio corporativo de Azure DevOps (SEG-11); nunca commit directo a `main`.
3. **Revisión humana** obligatoria (≥1 aprobador distinto del autor).
4. **Pruebas en verde**: `pytest` completo, `validate_project.py --strict`, `scripts/escanear_secretos.py --staged`, `scripts/verificar_remoto_git.py`.
5. **Aprobación registrada** en el PR (y en la auditoría si toca código ejecutable, SEG-07).
6. **Versión**: tag + regeneración de la guía (skill S12).

Prompts: mismo flujo; cada prompt deja huella (`modulos/huella_prompts.py`) y solo `admin_corpus` puede editarlos en la web (SEG-08).

**Configuración del repositorio 👤:** rama `main` protegida, PR obligatorio, mínimo 1 revisor, build de validación con las pruebas anteriores.

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Dueño funcional | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
