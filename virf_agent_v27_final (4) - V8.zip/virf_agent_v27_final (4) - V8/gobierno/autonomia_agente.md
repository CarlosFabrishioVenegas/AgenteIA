> Datos elaborados por BCP para uso Interno

# Nivel de autonomía del agente

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 5 · 45 |

**Nivel declarado: RECOMIENDA, NO EJECUTA.** La decisión final es siempre humana (HITL).

Verificado tras SEG-07 (commit `6b60617`): `excel_a_notebook.auto_validar` ya **no** ejecuta código generado por IA sin aprobación. La alerta de coherencia del instructivo queda resuelta.

## Qué ocurre automáticamente y con qué guardas

| Acción automática | Guardas |
|---|---|
| Llamadas al LLM | Gateway único: PII enmascarada, inyección neutralizada, proveedor aprobado, auditoría (SEG-01/04/05/12) |
| Controles deterministas de calidad de datos | Código del repositorio revisado; herramienta `run_data_quality_check` del catálogo, rol `validador` (Paso 15) |
| Retirada de afirmaciones sin respaldo / abstención | Determinista (SEG-16); el texto retirado queda para revisión humana |
| Purga de retención | Al arrancar y al cerrar sesión (SEG-06) |

## Qué NUNCA ocurre sin una persona

- Firmar o emitir un informe (identidad SSO, SEG-02; doble firma por tier).
- Ejecutar código generado por IA (aprobación de revisor por hash, SEG-07).
- Que el feedback afecte a puntajes (aprobación de revisor, Paso 25).
- Cambiar proveedor de IA (lista cerrada del banco, SEG-01).

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Dueño funcional | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
