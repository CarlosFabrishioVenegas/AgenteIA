> Datos elaborados por BCP para uso Interno

# Plan de marcha blanca

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 67 |

**Requisito previo:** Fases 1 y 2 de los SEG cerradas, incluidos los pasos humanos (rotación de claves, Key Vault, Entra ID con roles).

| Elemento | Propuesta |
|---|---|
| Participantes | 2-3 validadores [POR COMPLETAR 👤] + 1 revisor |
| Modelos | 3-5 modelos ya validados manualmente (permite comparar) [POR COMPLETAR 👤] |
| Duración | 6-8 semanas [confirmar 👤] |
| Ambiente | Aprobado (ver despliegue, Paso 68) con datos Interno; nada Restringido fuera de Databricks |
| Registro de hallazgos | Backlog (Paso 66) + evaluación experta (Paso 65) |

**Criterios de salida (propuestos, a fijar 👤):** concordancia agente-validador ≥ [umbral] (Paso 63) · tasa de alucinación medida y dentro de la meta de la hoja · 0 incidentes S1 abiertos · todas las afirmaciones retiradas revisadas por un humano · costes dentro de presupuesto (Paso 57).
