> Datos elaborados por BCP para uso Interno

# Matriz de alcance funcional

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 4 · alimenta el 61 |

| Capacidad (fuente en el repo) | El agente HACE | El agente NO hace |
|---|---|---|
| Lectura de evidencia (`motor/Mx_01`, `upload.py`) | Lee manuales, código, datasets y actas subidos y clasificados | No sube nada por su cuenta; no lee información Restringida fuera de Databricks |
| Evaluación por actividad (`motor_ia.py`, S03) | Propone puntaje y observación citando evidencia | No emite dictamen final; afirmaciones sin cita verificable se retiran (SEG-16) |
| Informes Word (S02, `plantilla_bcp.py`) | Genera el borrador del informe con etiqueta de clasificación | No firma; la firma es de la persona autenticada (SEG-02) |
| Chat de sustentación (S10) | Discute cada observación con el validador | No cierra observaciones sin decisión del validador |
| Calidad de datos (S08, `run_data_quality_check`) | Ejecuta controles deterministas del repositorio | No ejecuta controles nuevos sin code review; no ejecuta código de IA sin aprobación (SEG-07) |
| RAG léxico (S07) | Recupera literatura vigente | No usa fuentes vencidas ni sube fuentes sin dueño y vigencia (Paso 11) |
| Excel/VBA → notebook | Traduce a Python y deja el notebook pendiente de revisión | No ejecuta el notebook sin aprobación de un revisor |
| Proveedores de IA (S05) | Usa solo Azure OpenAI aprobado | No usa Anthropic (en espera) ni OpenAI (retirado) |
| Acciones externas | — | No envía correos, no modifica sistemas, no aprueba modelos |

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Dueño funcional | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
