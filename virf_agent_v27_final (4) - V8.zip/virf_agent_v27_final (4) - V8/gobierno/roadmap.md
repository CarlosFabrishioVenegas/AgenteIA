> Datos elaborados por BCP para uso Interno

# Roadmap (no bloqueante)

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador | 28 · 36 · 58 · 77 |

| Ítem | Paso | Estado | Criterio para activarlo | Dueño |
|---|---|---|---|---|
| Multiagente: coordinador ReAct con function calling sobre el catálogo de tools | 28 | No bloqueante; fuera del alcance de producción inicial | Marcha blanca cerrada (79) y las 5 tools deshabilitadas evaluadas y aprobadas (Paso 15) | [POR COMPLETAR 👤] |
| Planificador de tareas (descomposición por actividad) | 36 | No bloqueante | Coordinador disponible; métricas de calidad (63) estables | [POR COMPLETAR 👤] |
| Optimización de costes (modelo barato por tarea, caché de prompts, lotes) | 58 | No bloqueante | Reporte de costes por corrida (57) con 1 mes de datos | [POR COMPLETAR 👤] |
| Escalabilidad: aislamiento multi-tenant opt-in, jobs Databricks | 77 | No bloqueante | Industrialización aprobada (80) | [POR COMPLETAR 👤] |
