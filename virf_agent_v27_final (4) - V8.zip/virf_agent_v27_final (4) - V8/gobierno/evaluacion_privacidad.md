> Datos elaborados por BCP para uso Interno

# Evaluación de privacidad

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 50 |

| Aspecto | Observado en el repositorio | Pendiente |
|---|---|---|
| Datos personales tratados | Posibles en la evidencia: DNI, RUC (persona natural), CE, CCI/cuentas, correos, teléfonos, nombres en actas/correos | Confirmar categorías reales con el área validada 👤 |
| Finalidad | Validación independiente de modelos de riesgo | [POR COMPLETAR 👤 Legal/Privacidad] |
| Base legal (Ley 29733) | — | [POR COMPLETAR 👤 Legal/Privacidad] |
| Minimización | Lecturas Databricks con columnas + filtro (SEG-14); solo esquema/perfil de datasets al LLM | — |
| Enmascarado | Local y determinista antes de salir a la IA, tokens estables (SEG-04); límite: nombres sin contexto | Valorar NER aprobado 👤 |
| Retención | 30 días configurable; borrado con sobrescritura; Restringido no se guarda en el equipo (SEG-06) | Confirmar plazo con Legal 👤 |
| Terceros | Azure OpenAI (único aprobado, SEG-01) | Términos de no retención / no entrenamiento y región 👤 |
| Derechos ARCO | — | [POR COMPLETAR 👤 Legal/Privacidad] |
| Transferencia internacional | Depende de la región del recurso Azure | [POR COMPLETAR 👤 Legal/Privacidad] |

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Dueño funcional | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
