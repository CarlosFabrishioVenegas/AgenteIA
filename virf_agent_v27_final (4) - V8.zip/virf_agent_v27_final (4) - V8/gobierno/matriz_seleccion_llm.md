> Datos elaborados por BCP para uso Interno

# Matriz de selección del LLM

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Oportunidad de mejora – fuera del core | 19 |

**Oportunidad de mejora (no bloquea, fuera del core):** el agente opera con el único proveedor aprobado (Azure OpenAI). La hoja `Costes` de «Pasos Generales Agente 2.xlsx» no está disponible en el equipo. No se inventan cifras de coste ni de precisión.

Estructura preparada (se rellena con la hoja Costes y con `config/modelos.py`):

| Tarea | Opción | Estado proveedor | Coste entrada / salida (USD/Mtok) | Precisión (Modelo_Evaluacion) | Decisión |
|---|---|---|---|---|---|
| Evaluación por actividad | Azure OpenAI · deployment corporativo | APROBADO | [hoja Costes] | [Modelo_Evaluacion] | [POR COMPLETAR 👤] |
| Solo Informe (redacción) | Azure OpenAI · `SOLO_INFORME_DEPLOYMENT` (más barato) | APROBADO | [hoja Costes] | [Modelo_Evaluacion] | [POR COMPLETAR 👤] |
| — | Anthropic Claude | EN_ESPERA (descartado hasta aprobación) | — | — | Descartado: proveedor no aprobado |
| — | OpenAI directo | RETIRADO | — | — | Descartado: proveedor retirado |

Los precios de `config/modelos.py` son **estimaciones de lista**, no autoritativos.

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Dueño funcional | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
