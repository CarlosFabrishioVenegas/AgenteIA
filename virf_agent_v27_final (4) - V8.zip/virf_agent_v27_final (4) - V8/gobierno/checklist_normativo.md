> Datos elaborados por BCP para uso Interno

# Checklist normativo

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 51 |

No se marca «cumple» sin evidencia enlazada. Estado propuesto; la firma la da Cumplimiento 👤.

| Norma / requisito | Cómo se cumple | Evidencia | Estado propuesto |
|---|---|---|---|
| 2135.010.02 §Gobierno – de-identificación | Enmascarado PII peruano | SEG-04 `8709046`, `test_pii.py` | Cumple – pendiente de validación |
| 2135.010.02 §Aseguramiento – interfaces humano-máquina | Gateway único | SEG-05 `7c7899d`, `test_gateway_ia.py` | Cumple – pendiente de validación |
| 2135.010.02 §Adquisición a terceros | Lista cerrada de proveedores | SEG-01 `657f6cc` | Cumple – pendiente de validación |
| 2135.010.02 §Aseguramiento – credenciales cifradas | Key Vault / scope | SEG-03 `55ff37f` | **Parcial** (rotación de claves 👤) |
| 2135.010.02 §Aseguramiento/§Exploración – identidad | SSO + firmante autenticado | SEG-02 `8615a0f` | **Parcial** (registro Entra 👤) |
| 2135.010.02 §Aseguramiento – RBAC | Roles + feedback sellado | SEG-08 `04c6e78`, Paso 25 | Cumple – pendiente de validación |
| 2135.010.02 §Aseguramiento – auditoría | Log solo-anexar | SEG-12 `aca544f` | **Parcial** (destino SIEM 👤) |
| 2135.010.02 §Almacenamiento | Clasificación, cifrado, retención | SEG-06 `65007fb` | Cumple – pendiente de validación |
| 2135.010.02 §Aseguramiento – diseño seguro | Sin exec; aprobación de código | SEG-07 `6b60617` | **Parcial** (aprobadores 👤) |
| 2135.010.02 §Transmisión | Mínimo dato Databricks | SEG-14 `890dd07` | **Parcial** (service principal 👤) |
| 2135.010.02 §Carga de fuentes | Dueño y vigencia por fuente | Paso 11 | **Parcial** (dueños 👤) |
| 4180.223.02 §Uso aceptable | Proveedores aprobados; Restringido fuera del equipo | SEG-01, SEG-06 | Cumple – pendiente de validación |
| 4180.223.08 | Identidad y datos | SEG-02, SEG-04, SEG-14 | **Parcial** |
| 4205.410.06 | Cuestionario e inventario IA | SEG-09 `f2bf65d` | **Pendiente** (flujo de riesgo, DAST, pentest 👤) |
| Clasificación de informes | Etiqueta en todo Word | SEG-10 `f23a6e7` | Cumple – pendiente de validación |
| Repositorio corporativo | Solo Azure DevOps | SEG-11 `f8d199c` | **Parcial** (URL 👤) |

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Cumplimiento | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
