> Datos elaborados por BCP para uso Interno

# Perfiles de usuario

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 3 |

Fuente: matriz de permisos del código (`web/services/roles.py`, SEG-08) y login SSO (SEG-02). El test `tests/test_gobierno_documentos.py` exige que los roles de esta tabla coincidan 1:1 con `roles.ROLES`.

| Perfil | Rol técnico | Quién es | Qué puede hacer | Qué NO puede hacer | Qué datos ve | Autenticación |
|---|---|---|---|---|---|---|
| Validador | `validador` | Validador de 2.ª línea | Lanzar validaciones, subir evidencia de su sesión, dejar feedback propio, usar herramientas operativas | Gestionar el corpus RAG, editar prompts, aprobar su propio feedback o código | Evidencia de sus modelos; corpus RAG (lectura) | SSO Entra ID; firma con su identidad |
| Administrador de corpus | `admin_corpus` | Responsable del RAG y de los prompts | Subir/borrar fuentes del RAG (con dueño y vigencia), reindexar, editar/restaurar prompts, diagnóstico de conexiones | Lanzar validaciones, aprobar | Corpus RAG; prompts | SSO Entra ID |
| Revisor | `revisor` | Supervisor / segundo par de ojos | Leer, aprobar o negar feedback, aprobar código generado por IA (por hash) | Lanzar validaciones, gestionar corpus | Lectura | SSO Entra ID |
| Área validada | — (sin acceso) | Dueño del modelo validado | Recibe el informe Word firmado | Usar la herramienta | Solo el informe que se le entrega | No aplica |

Sin rol asignado en Entra ID, una sesión no puede hacer nada protegido (denegar por defecto).

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Dueño funcional | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
