> Datos elaborados por BCP para uso Interno

# RACI del agente

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 52 |

El agente no inventa personas: todos los nombres están `[POR COMPLETAR 👤]`.

| Rol | Persona |
|---|---|
| Dueño funcional | [POR COMPLETAR 👤] |
| Dueño técnico | [POR COMPLETAR 👤] |
| Aprobadores de informes (validadores / revisores) | [POR COMPLETAR 👤] |
| Soporte | [POR COMPLETAR 👤] |
| Riesgo No Financiero | [POR COMPLETAR 👤] |
| Ciberseguridad | [POR COMPLETAR 👤] |

| Actividad | Dueño funcional | Dueño técnico | Aprobadores | Soporte | Riesgo No Fin. | Ciberseguridad |
|---|---|---|---|---|---|---|
| Cambios de código | I | A | C | R | I | C |
| Cambios de prompts | A | R | C | I | I | I |
| Alta de fuentes del corpus | A | C | I | R (admin_corpus) | I | I |
| Aprobación de informes | A | I | R | I | I | I |
| Incidentes | I | A | I | R | C | C |
| Reevaluación semestral | A | R | C | I | C | C |
