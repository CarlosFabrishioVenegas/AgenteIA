> Datos elaborados por BCP para uso Interno

# Matriz tarea-modelo

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Remediado – pendiente de validación | 20 |

Solo modelos de proveedores **aprobados**. El test `tests/test_gobierno_codigo.py` comprueba que cada fila usa un proveedor APROBADO o está bloqueada, y que las variables de configuración existen en el código.

| Tarea | Módulo | Proveedor | Configuración (variable) | Estado |
|---|---|---|---|---|
| Evaluación por actividad | modulos/motor_ia.py | azure_openai | AZURE_OPENAI_DEPLOYMENT | activo |
| Resumen de documentos largos | modulos/chunker.py | azure_openai | AZURE_OPENAI_DEPLOYMENT | activo |
| Revisión de código | modulos/revision_codigo.py | azure_openai | AZURE_OPENAI_DEPLOYMENT | activo |
| Excel/VBA → notebook | modulos/excel_a_notebook.py | azure_openai | AZURE_OPENAI_DEPLOYMENT | activo |
| Explicador del modelo | modulos/explicador_modelo.py | azure_openai | AZURE_OPENAI_DEPLOYMENT | activo |
| Chat de sustentación | web/services/chat_service.py | azure_openai | AZURE_OPENAI_DEPLOYMENT | activo |
| Juez NLI | modulos/entailment.py | azure_openai | AZURE_OPENAI_DEPLOYMENT | activo (producción) |
| Solo Informe (asistencia) | web/services/solo_informe_ia.py | azure_openai | SOLO_INFORME_DEPLOYMENT | activo (modelo barato) |
| VIRF PLUS (segunda opinión) | config/virf_plus.py | azure_openai + anthropic | VIRF_PLUS | bloqueado |
