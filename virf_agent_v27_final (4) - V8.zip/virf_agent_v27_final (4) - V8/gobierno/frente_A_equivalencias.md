> Datos elaborados por BCP para uso Interno

# Frente A · Pasos cerrados por los SEG

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Remediado – pendiente de validación | 6, 23, 25, 31, 32, 37, 38, 42, 43, 44, 46, 47, 48, 49, 50, 53, 54, 72 |

Cada SEG tiene commit en `main` y test en verde (suite 1514+ passed). Estado propuesto; lo valida el responsable.

| Paso | Cerrado por | Commit | Test | Estado propuesto | Brecha restante |
|---|---|---|---|---|---|
| 6 | SEG-09 | `f2bf65d` | test_gobierno_ia.py | Parcial | Cuestionario firmado y flujo con Riesgo 👤 |
| 23 | SEG-08 | `04c6e78` | test_roles.py | Cubierto | — |
| 25 | SEG-08 + aprobación de feedback | este cambio | test_gobierno_codigo.py | Cubierto | — |
| 31 | SEG-02 | `8615a0f` | test_identidad.py | Parcial | Registro Entra ID 👤 |
| 32 | SEG-06 | `65007fb` | test_almacenamiento.py | Cubierto | — |
| 37 | SEG-07 | `6b60617` | test_ejecucion_codigo.py | Cubierto | — |
| 38 | SEG-16 | `62b9bd4` | test_salvaguardas_llm.py | Cubierto | — |
| 42 | SEG-16 + métrica | `62b9bd4` | test_salvaguardas_llm.py | Parcial | Oportunidad de mejora: tasa de alucinación con hoja Modelo_Evaluacion |
| 43 | SEG-16 + estado en contrato | `62b9bd4` + este cambio | test_pruebas_calidad.py | Cubierto | — |
| 44 | SEG-02 | `8615a0f` | test_identidad.py | Parcial | Flujo web de co-firma; registro Entra 👤 |
| 46 | SEG-08 | `04c6e78` | test_roles.py | Cubierto | — |
| 47 | SEG-01, 03, 04, 06 | `657f6cc`, `55ff37f`, `8709046`, `65007fb` | varios | Parcial | Rotación de claves (SEG-03) 👤 |
| 48 | SEG-05 | `7c7899d` | test_gateway_ia.py | Cubierto | — |
| 49 | SEG-07 + política de tools | `6b60617` + Paso 15 | test_gobierno_codigo.py | Cubierto | — |
| 50 | SEG-04 + evaluación de privacidad | `8709046` | test_pii.py | Parcial | Decisiones de Legal 👤 |
| 53 | SEG-11 | `f8d199c` | test_repositorio_corporativo.py | Parcial | URL del repo corporativo 👤 |
| 54 | SEG-12 + coste por llamada | `aca544f` + este cambio | test_costes.py | Cubierto | — |
| 72 | SEG-13 | `465ac72` | test_documentacion_consistente.py | Cubierto | — |

**Paso 44 verificado:** el firmante y el segundo firmante salen de aserciones firmadas de sesiones SSO (no de un campo editable): `modulos/validador_humano.solicitar_identidad` / `solicitar_segunda_firma`.
