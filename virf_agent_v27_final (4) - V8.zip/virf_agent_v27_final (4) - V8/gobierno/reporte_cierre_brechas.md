> Datos elaborados por BCP para uso Interno

# Reporte de cierre de brechas — «Pasos Generales Agente 2»

Fecha: 2026-11-09 · Suite: **1597 passed, 2 skipped (1599 recogidos)** · `validate_project --strict` íntegro · escaneo de secretos del árbol limpio.

Generado desde `gobierno/backlog.csv`. Ningún paso se marca «Cubierto»: el estado es una **propuesta**; el responsable valida.

## Resumen

| Estado propuesto | Pasos |
|---|---|
| Remediado – pendiente de validación | 19 |
| Bloqueado – requiere humano | 11 |
| Borrador listo – pendiente de firma 👤 | 13 |
| Borrador | 4 |
| Plantilla | 1 |
| Oportunidad de mejora – fuera del core | 4 |

## Tabla

| Paso | Estado propuesto | Entregable / evidencia | Pendiente humano |
|---|---|---|---|
| 3 · Perfiles de usuario | Borrador listo – pendiente de firma 👤 | gobierno/perfiles_usuario.md + test | Firma |
| 4 · Matriz de alcance | Borrador listo – pendiente de firma 👤 | gobierno/matriz_alcance.md | Firma |
| 5 · Autonomía formal | Borrador listo – pendiente de firma 👤 | gobierno/autonomia_agente.md (SEG-07 cerrado) | Firma |
| 6 · Criticidad / cuestionario | Bloqueado – requiere humano | docs/seguridad/GOBIERNO_RIESGO_IA.md (SEG-09) | Cuestionario firmado |
| 11 · Dueño y vigencia de fuentes | Remediado – pendiente de validación | modulos/fuentes_rag.py + inventario_fuentes.csv | Asignar dueños (13 huérfanas) |
| 15 · Catálogo de tools | Remediado – pendiente de validación | config/tools.py + catalogo_tools.md | No |
| 16 · Mapa de integraciones | Remediado – pendiente de validación | gobierno/mapa_integraciones.md | No |
| 18 · Modelos analíticos (No aplica) | Borrador listo – pendiente de firma 👤 | gobierno/no_aplica.md | Firma |
| 19 · Selección del LLM | Oportunidad de mejora – fuera del core | gobierno/matriz_seleccion_llm.md (esqueleto) | Opcional: hoja Costes |
| 20 · Matriz tarea-modelo | Remediado – pendiente de validación | gobierno/matriz_tarea_modelo.md + test | No |
| 23 · Prompts: quién edita | Remediado – pendiente de validación | SEG-08 | No |
| 25 · Feedback aprobado antes de afectar puntajes | Remediado – pendiente de validación | feedback.aprobar_feedback + /api/feedback | No |
| 28 · Multiagente (roadmap) | Borrador | gobierno/roadmap.md | Dueño |
| 31 · API con identidad corporativa | Bloqueado – requiere humano | SEG-02 | Registro Entra ID |
| 32 · Clasificación al subir | Remediado – pendiente de validación | SEG-06 | No |
| 36 · Planificación de tareas (roadmap) | Borrador | gobierno/roadmap.md | Dueño |
| 37 · Ejecución de herramientas | Remediado – pendiente de validación | SEG-07 | No |
| 38 · Validación intermedia | Remediado – pendiente de validación | SEG-16 | No |
| 42 · Alucinaciones | Oportunidad de mejora – fuera del core | pruebas/calidad/evaluacion.py (métrica sin set) | Opcional: hoja Modelo_Evaluacion |
| 43 · EVIDENCIA INSUFICIENTE explícita | Remediado – pendiente de validación | esquemas.ValidationReport.estado_evidencia | No |
| 44 · Aprobador con identidad real | Bloqueado – requiere humano | SEG-02 | Entra ID; flujo web de co-firma |
| 45 · Acciones automáticas (No aplica) | Borrador listo – pendiente de firma 👤 | gobierno/no_aplica.md (revisado tras SEG-07) | Firma |
| 46 · Control de permisos | Remediado – pendiente de validación | SEG-08 | No |
| 47 · Seguridad de datos | Bloqueado – requiere humano | SEG-01/03/04/06 | Rotación de claves |
| 48 · Seguridad de prompts | Remediado – pendiente de validación | SEG-05 | No |
| 49 · Seguridad de herramientas | Remediado – pendiente de validación | SEG-07 + config/tools.py | No |
| 50 · Privacidad | Borrador listo – pendiente de firma 👤 | gobierno/evaluacion_privacidad.md | Legal/Privacidad |
| 51 · Checklist normativo | Borrador listo – pendiente de firma 👤 | gobierno/checklist_normativo.md | Firma Cumplimiento |
| 52 · RACI | Borrador listo – pendiente de firma 👤 | gobierno/raci.md | Nombres |
| 53 · Versionamiento | Bloqueado – requiere humano | SEG-11 | URL repo |
| 54 · Bitácora con coste | Remediado – pendiente de validación | config/ia.py gateway + test_costes.py | No |
| 56 · Dashboard operativo | Bloqueado – requiere humano | observabilidad/ (dataset + especificación) | Publicar en Power BI |
| 57 · Control de costes | Remediado – pendiente de validación | modulos/observabilidad.py + precio de salida | No |
| 58 · Optimización de costes (roadmap) | Borrador | gobierno/roadmap.md | Dueño |
| 60 · E2E en ambiente controlado | Bloqueado – requiere humano | pruebas/e2e/e2e_sintetico.py (simulado verde) | Acceso a Azure aprobado (--real) |
| 61 · Matriz funcional | Remediado – pendiente de validación | pruebas/matriz_funcional.md | No |
| 62 · Pruebas de seguridad | Bloqueado – requiere humano | pruebas/seguridad/ (24 casos; 1 bug corregido) | Pentest/DAST |
| 63 · Calidad (Modelo de Evaluación) | Oportunidad de mejora – fuera del core | pruebas/calidad/ (métricas provisionales) | Opcional: hoja Modelo_Evaluacion; set de dictámenes |
| 64 · Casos borde | Remediado – pendiente de validación | pruebas/matriz_casos_borde.md (3 bugs corregidos) | No |
| 65 · Evaluación experta | Borrador listo – pendiente de firma 👤 | pruebas/rubrica_experta.md + evaluacion_experta.py | Expertos |
| 66 · Backlog formal | Remediado – pendiente de validación | gobierno/backlog.csv | Responsables |
| 67 · Marcha blanca | Borrador listo – pendiente de firma 👤 | gobierno/plan_marcha_blanca.md | Participantes y decisión |
| 68 · Despliegue | Bloqueado – requiere humano | gobierno/despliegue.md | Ambiente aprobado |
| 69 · Integración productiva | Bloqueado – requiere humano | gobierno/go_no_go.md (NO-GO) | Decisión |
| 70 · Soporte e incidentes | Borrador listo – pendiente de firma 👤 | gobierno/soporte_incidentes.md | Firma |
| 72 · Documentación coherente | Remediado – pendiente de validación | SEG-13 | No |
| 74 · Control de cambios | Borrador listo – pendiente de firma 👤 | gobierno/control_cambios.md | Firma; rama protegida |
| 75 · Mantenimiento | Borrador listo – pendiente de firma 👤 | gobierno/plan_mantenimiento.md | Plazos con Ciberseguridad |
| 76 · Reevaluación semestral | Oportunidad de mejora – fuera del core | gobierno/reevaluacion_semestral.md | Opcional: programar; hoja Modelo_Evaluacion |
| 77 · Escalabilidad (roadmap) | Borrador | gobierno/roadmap.md | Dueño |
| 79 · Cierre del piloto | Plantilla | gobierno/plantilla_cierre_piloto.md | Tras marcha blanca |
| 80 · Industrialización | Bloqueado – requiere humano | gobierno/plan_industrializacion.md (esqueleto) | Tras cierre del piloto |

## Lo que no se pudo cerrar y por qué

- **Hoja `Brechas_80_Pasos`**: el libro `VIRF_Hallazgos_Seguridad_v1` no está en el equipo; `gobierno/backlog.csv` y este reporte hacen sus veces.
- **Documentos de gobierno**: todos son borradores; ninguno está firmado.
- **60**: el E2E solo se ejecutó en modo simulado; el modo real requiere el ambiente con Azure aprobado.
- **62**: la suite red-team no sustituye al pentest/DAST de Ciberseguridad.
- **11**: las 13 fuentes del corpus siguen huérfanas (sin dueño ni vigencia) hasta que el equipo las asigne.
- **67–69, 79–80**: decisiones y ejecución humanas; go/no-go actual = NO-GO.

## Oportunidades de mejora (fuera del core)

Por decisión del usuario (2026-11-09), los pasos **19, 42, 63 y 76** dejan de bloquear y quedan como oportunidades de mejora. No afectan al core: ningún módulo de `modulos/`, `motor/`, `web/`, `config/` ni `scripts/` importa `pruebas/calidad/` ni depende de `gobierno/matriz_seleccion_llm.md`; no condicionan el go/no-go (Paso 69).

| Paso | Mejora | Qué la habilita |
|---|---|---|
| 19 | Matriz de selección del LLM con costes y precisión reales | Hoja `Costes` |
| 42 | Tasa de alucinación medida sobre un set real | Hoja `Modelo_Evaluacion` |
| 63 | Fórmula oficial del Modelo de Evaluación de Validez (`modelo_evaluacion_oficial()`) | Hoja `Modelo_Evaluacion` + set de dictámenes |
| 76 | Reevaluación semestral comparando resultados | Pasos 42/63 y programar el recordatorio |

Sigue sin haber cifras inventadas: no existe todavía ninguna medición real de alucinación ni de concordancia.

## Defectos encontrados por las nuevas pruebas (corregidos)

1. Credenciales dentro de la evidencia salían hacia el LLM (OWASP LLM) → tipo `CREDENCIAL` en `modulos/pii.py`.
2. `.txt` en cp1252/latin-1 se leía como «Validaci�n» → detección de codificación.
3. `.txt` en UTF-16 se leía como basura → BOM UTF-16.
4. PDF protegido o falso se reportaba como «escaneado» → diagnóstico preciso.
