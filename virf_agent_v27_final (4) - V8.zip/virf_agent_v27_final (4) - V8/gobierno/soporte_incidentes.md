> Datos elaborados por BCP para uso Interno

# Soporte e incidentes

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Borrador listo – pendiente de firma 👤 | 70 |

Depende del RACI (Paso 52).

**Canales:** [POR COMPLETAR 👤 mesa de ayuda / canal Teams / correo].

| Severidad | Definición | Respuesta | Resolución objetivo | Escalamiento |
|---|---|---|---|---|
| S1 | Fuga de datos, informe firmado con error material, compromiso de credenciales | 1 h | 24 h | Dueño técnico + Ciberseguridad + Riesgo No Financiero |
| S2 | Pipeline caído o salidas inválidas para todos | 4 h | 2 días | Dueño técnico |
| S3 | Fallo parcial con alternativa | 1 día | 1 semana | Soporte |
| S4 | Mejora / consulta | 3 días | Backlog | Soporte |

(Tiempos propuestos; confirmar 👤.)

**Runbook:** diagnosticar con las skills `docs/agente_corporativo/skills/S01`–`S12` (S01 diagnóstico, S05 proveedor IA, S07 RAG, S09 evidencia…). Revisar el log de auditoría (`modulos/auditoria.verificar()`) y el historial de feedback (`verificar_cadena()`).

**Postmortem (plantilla):** resumen · impacto (usuarios, informes, datos) · línea de tiempo · causa raíz · qué funcionó / qué no · acciones (dueño, fecha) · evidencia.

## Firmas

| Rol | Nombre | Fecha | Firma |
|---|---|---|---|
| Dueño funcional | [POR COMPLETAR 👤] | | |
| Dueño técnico | [POR COMPLETAR 👤] | | |
