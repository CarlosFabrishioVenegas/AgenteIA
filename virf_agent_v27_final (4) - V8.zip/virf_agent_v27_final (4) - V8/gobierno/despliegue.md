> Datos elaborados por BCP para uso Interno

# Despliegue en ambiente aprobado

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Bloqueado – requiere humano | 68 |

Hoy el uso es local. Guía técnica: `docs/DESPLIEGUE_DATABRICKS.md`. Checklist:

- [ ] Service principal de Databricks con solo lectura de las tablas del dominio (SEG-14) 👤
- [ ] Secret scope / Key Vault con `azure-openai-api-key`, `virf-clave-firma-sesion`, `virf-clave-cifrado-reposo`, `virf-entra-client-secret` (SEG-03) 👤
- [ ] `VIRF_ENTORNO=databricks`, `VIRF_FUENTE_SECRETOS=databricks`, `MODO=produccion`
- [ ] Endpoint Azure OpenAI en `VIRF_HOSTS_IA_PERMITIDOS`
- [ ] Repositorio corporativo como origen del código (SEG-11) 👤
- [ ] Destino aprobado del log de auditoría (SEG-12) 👤
- [ ] Prueba E2E `--real` con datos sintéticos (Paso 60) y evidencia guardada
