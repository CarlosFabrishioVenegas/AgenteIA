> Datos elaborados por BCP para uso Interno

# Catálogo de herramientas (tools)

| Versión | Fecha | Dueño | Estado | Paso(s) |
|---|---|---|---|---|
| 0.1 | 2026-11-09 | [POR COMPLETAR 👤] | Remediado – pendiente de validación | 15 · 49 |

Fuente de verdad: `config/tools.py` (política **deny by default**). El test `tests/test_gobierno_codigo.py` exige que esta tabla coincida con el código.

| Tool | Propósito | Rol que puede invocarla | Datos que toca | Riesgo | Estado |
|---|---|---|---|---|---|
| `run_data_quality_check` | Controles deterministas de calidad de datos | validador | Datasets del modelo | Medio | operativa |
| `analyze_document_versioning` | Comparar versiones de documentos | — | Manuales | Bajo | deshabilitada |
| `retrieve_methodology_evidence` | Recuperar evidencia metodológica | — | Corpus + evidencia | Bajo | deshabilitada |
| `check_compliance_government` | Verificar gobierno del modelo | — | Actas, políticas | Medio | deshabilitada |
| `verify_code_implementation` | Contrastar código vs manual | — | Código | Medio | deshabilitada |
| `ingest_operational_channels` | Ingerir correos y documentos operativos | — | Correos (posible PII) | Alto | deshabilitada |

## Política de tools (Paso 49)
1. Una tool no registrada no se ejecuta (`ToolNoRegistrada`).
2. Una tool no operativa no se ejecuta (`ToolDeshabilitada`).
3. Un rol sin permiso no la ejecuta (`PermisoTool`).
4. Toda invocación (éxito o error) queda en la auditoría (`invocacion_tool`).
5. Habilitar una tool es un cambio de código con revisión (control de cambios, Paso 74) y aprobación del dueño técnico 👤.
