# PROMPT DE CONTINUIDAD — VIRF Agent · 2026-08-28

> Pega este archivo (o su ruta) al abrir la próxima sesión. Es el estado real
> del proyecto al cierre del **Golden-1**, no un resumen genérico.

---

## 0. Reglas permanentes (NO negociables)

- **NO `git add -A`.** El repo arrastra cambios *ajenos* sin commitear de otras
  sesiones que **no deben** entrar a ningún commit. Usa siempre `git add <archivo>`
  selectivo.
- **NO subagentes** salvo que se pida explícitamente.
- **Sin dependencias nuevas.** Pydantic v2 ya entra transitivo por FastAPI (no es dep nueva).
- **Sin detección automática por heurística:** usar flags/vars explícitos, nunca adivinar el modo.
- **No inventar métricas ni ground truth.** La decisión la dictan los números.
- **Windows/cp1252:** cualquier script con emojis crashea → exportar `PYTHONIOENCODING=utf-8`.
- **Un WP a la vez:** test → commit selectivo → siguiente.

---

## 1. Estado de la API (bloqueante para Días 3+)

El día de API sigue **bloqueado por credenciales, no por saldo** (ver memoria `project_estado_api`):

- **Azure OpenAI** (PRIORITARIO, default `IA_PROVEEDOR=azure_openai`):
  `AZURE_OPENAI_API_KEY` / `ENDPOINT` / `DEPLOYMENT` están **vacías**
  (`config/ia.py:336-338`; aborta en `:341/:343/:345`). Las entrega IT.
- **Anthropic** (secundario; `.env` tiene `IA_PROVEEDOR=anthropic`): key probada dio
  **401** y luego **400 exigiendo `anthropic-workspace-id`** (key de workspace).
  **NO cablear** ese header — el usuario pidió revertirlo y se revirtió.

**Antes de cualquier pasada de API:** verificar con `prueba_de_humo()` (config) con
`PYTHONIOENCODING=utf-8`. No lanzar hasta ver **200 OK**.

---

## 2. Lo que quedó CERRADO (Golden-1)

Commit **`a4b5d57`** — "Golden-1: set discriminante formula/tabla + IR lexico + decision chunking".
Suite: **950 passed / 0 failed / 1 skipped**. Sin regresiones.

Artefactos creados:
- `scripts/preguntas_oro_formula.py` — 25 consultas discriminantes fórmula/tabla
  (ground truth verificado) + 4 adversarias. Reconstruye índices en temp (no toca producción).
- `docs/evidencia/retrieval_chunking.md` — tabla IR + decisión razonada.
- `docs/evidencia/retrieval_metrics.json` — `B1_recall@10=1.0`, `B2_precision@5=0.52`,
  `B3_ndcg@10=0.9459`.
- `verificador_virf.py` — `bloque_B_C` lee esas métricas; `--hito Golden-1` en choices.

Indicadores movidos: **B1 NA→VERDE** (1.000), **B2 NA→ÁMBAR** (0.520, techo de
corpus ~0.6 por granularidad, no defecto), **B3 NA→VERDE** (0.946), **B4 NA→VERDE**
(49 = 25 fórmula + 24 base). `C1/C2/C3` siguen **NA** (requieren API/generación).

**Decisión de chunking: se queda OPT-IN** (`RAG_CHUNKING_ESTRUCTURAL=1`).
Razón raíz: el corpus es **prosa PDF plana** (sin `#`, `|`, ni fences), así que el
chunker estructural produce esencialmente los mismos chunks que el de tamaño →
empate técnico, ninguna mejora consistente en casos duros. **No se tocó**
`test_chunks_identicos_no_se_pisan_entre_si` (no hay promoción que lo justifique).

---

## 3. Lo que quedó de Día 2 (ya commiteado antes)

- `modulos/esquemas.py` — `EstadoRequisito`, `ValidationClaim` (con `ambito` opcional),
  `ValidationReport`, `desde_dict`/`validar_reporte`/`intentar_validar`.
- `modulos/versionado.py`, `modulos/ventana_contexto.py`, `modulos/reporte_docx.py`.
- `src/rag/indexador_lexico.py` — `__init__(estructural=...)` resuelve de
  `cfg.CHUNKING_ESTRUCTURAL` (sin `os.getenv` propio: violaba el test de centralización).
- Flag centralizado en `config/parametros.py` (`RAG_CHUNKING_ESTRUCTURAL`, default False)
  + `config_rag.py` + `config/__init__.py` + `.env.example`.
- β de abstención calibrada: `ABSTENCION_BETA = 0.19` (gap entre evidencia vacía 0.0
  y mínimo respondible 0.379).

---

## 4. PENDIENTES (elegir con el usuario, no arrancar solo)

### (a) SECUNDARIO diferido — A2 ámbar→verde (extracción tipada E2E)
Cablear validación `ValidationReport` en el free-parse de `motor_ia.py:402-444`.
Test: dict válido valida; malformado falla. **Se dejó anotado a propósito**
("no empezar a medias"). Requiere confirmación para arrancar.

### (b) Día de API (bloqueado) — cuando IT entregue Azure
WP-07 (inyección matemática E2E→D1), IPI (E2E→D5), WP-04 (citas NLI→D4),
F1 (`.docx` real), RAGAS/C1-C2-C3. Pre-flight de costo + circuit breaker de presupuesto.
Requiere `AZURE_OPENAI_*` con 200 OK.

---

## 5. Invariantes de código que rompen tests si los ignoras

- Vars de entorno de negocio (`getenv`) **solo** en `config/parametros.py`; el resto
  lee vía `config_rag._param`. (`test_ningun_modulo_redeclara_parametros_de_negocio`)
- Toda env var leída debe estar documentada en `.env.example`.
  (`test_toda_variable_de_entorno_leida_esta_documentada`)
- Todo item de `parametros.__all__` debe ser importable desde `config`.
  (`test_el_paquete_config_reexporta_todo_lo_que_declara`)

---

## 6. Cierre de hito (patrón)

`verificador_virf.py --hito <Nombre>` escribe `indicadores_<fecha>_<hito>.{json,md}`
(sufijo por hito para **no pisar** el archivo baseline/de otro día). Soporta
`--comparar` (regresiones = indicador que empeoró desde VERDE/ÁMBAR), `--pytest-xml`, `--wps`.
