# Traspaso de sesión — 2026-07-31 · RAG léxico, evaluador crítico y skills

> **Cómo usar este documento.** Pégalo como primer mensaje en la sesión que
> continúe este trabajo, junto con [`PROMPT_CONTINUIDAD.md`](PROMPT_CONTINUIDAD.md)
> (que da el contexto general del proyecto). Éste cuenta **qué se hizo hoy, por
> qué, y qué quedó pendiente**.
>
> Estado al cierre: `pytest` **605 passed, 1 skipped** ·
> `validate_project.py --strict` **133/133 PASS, 0 WARN, 0 FAIL, exit 0**

---

## 0. Las dos restricciones que gobiernan todo

No se negocian. Cualquier propuesta que las viole está mal por definición:

1. **Cero HuggingFace**, incluidas dependencias transitivas.
2. **Un solo deployment de Azure OpenAI, de chat.** No hay ni habrá deployment
   de embeddings. El de chat **no** genera embeddings — pedirle vectores a
   `/chat/completions` devuelve texto que parece un vector y no lo es.

> **No propongas embeddings, ChromaDB, FAISS, sentence-transformers ni ningún
> vector store.** Ya se descartaron con motivo documentado (§1).

---

## 1. RAG: de vectorial a léxico

### El diagnóstico

El RAG anterior (ChromaDB + embeddings Azure) llevaba tiempo **instalado,
documentado y APAGADO**: sin deployment de embeddings, la función fallaba, el
retriever capturaba la excepción y devolvía `[]`, y la validación seguía sin
contexto. Solo lo decía un *warning* entre decenas.

Y un hallazgo que no se ve leyendo el código:

```
chromadb  →  tokenizers  →  huggingface-hub
```

La política de «cero modelos externos» se cumplía **en el código** y se
incumplía **en el árbol de dependencias**. Instalar `requirements.txt` metía
HuggingFace en el entorno.

### Lo que se construyó

| Fichero | Qué hace |
|---|---|
| `src/rag/config_rag.py` | Parámetros. Importa de `config/parametros.py` |
| `src/rag/indexador_lexico.py` | Tokenización, troceado, índice, persistencia |
| `src/rag/buscador_lexico.py` | BM25 + TF-IDF, cobertura, expansión |
| `src/rag/tesauro.py` | Sinónimos de dominio (auditable) |
| `src/rag/base_indexer.py` · `base_retriever.py` | Adaptadores: **misma API** que ya consumía `motor_ia` |

**Eliminados:** `config/embeddings.py`, `chromadb` de requirements, `VECTORDB_DIR`,
`EMBEDDINGS_PROVEEDOR`, `AZURE_EMBEDDINGS_DEPLOYMENT`, y `data/vectordb/` (81 MB).

**Desinstalados del entorno:** `chromadb`, `transformers`, `sentence-transformers`,
`tokenizers`, `huggingface-hub`, `hf-xet`, `safetensors`.

### Cuatro bugs reales encontrados (no los reintroduzcas)

1. **`BM25Okapi` da IDF exactamente 0** en corpus pequeños:
   `log(N−df+0.5) − log(df+0.5)`, sin el `+1` de otras variantes. Con N=2, df=1
   → 0. El `epsilon` de `rank_bm25` solo repara IDF **negativos**.
   → Por eso el filtro es por **cobertura de términos**, no por `BM25 > 0`.

2. **Ciclo de imports**: `from src.rag import config_rag` ejecuta el dispatcher
   `__init__.py`. → Se usa `import src.rag.config_rag as cfg`.

3. **Índices vacíos se persistían** en el directorio de producción (apareció
   `dominio_que_no_existe.pkl` creado por un test). → `construir()` ya no
   escribe índices sin chunks.

4. **El stemmer partía singular/plural**: `series`→`seri` pero `serie`→`serie`.
   → Regla real del plural español: consonante+`es` → quitar `es`;
   vocal+`s` → quitar `s`.

### El defecto de diseño que se curó: un número, dos trabajos

El `score` se normaliza contra el máximo de cada consulta (BM25 no tiene techo),
así que **el mejor fragmento saca 1.00 siempre**. Ese número gobernaba el umbral
Y se inyectaba al prompt como «relevancia léxica: 1.00».

**Cura — dos números con un trabajo cada uno:**

| | `cobertura` | `score` |
|---|---|---|
| Qué es | Relevancia **ABSOLUTA** (Σ IDF cubierto / Σ IDF consulta) | Posición **RELATIVA** |
| Para qué | Medir, filtrar, **reportar** | Solo ordenar |
| Umbral | `RAG_MIN_COBERTURA` (0.15) | `RAG_MIN_SCORE` (0.35) |

Más `peso_informativo_consulta` (Σ IDF): distingue **«no hay nada relevante»**
(corpus incompleto) de **«no has preguntado nada distintivo»** (consulta pobre).
Por debajo de 0.8, warning **y el bloque del prompt declara su incertidumbre**.

### El punto ciego léxico, y su cura

`excepciones` (df=0) vs `excedencias` (df=8) — sinónimos exactos en backtesting
que BM25 no une.

**Por qué no se resolvió con métodos automáticos** (LSA/SVD sobre TF-IDF, que
sería local y estaría a mano): un término con **df=0 no aparece en el corpus**,
así que no hay contexto del que inferir nada. Hace falta conocimiento externo.

1. **Tesauro** (`src/rag/tesauro.py`) — 41 grupos. Auditable: un validador puede
   leerlo entero. Ampliable con `config/tesauro_rag.yaml`.
2. **Corrección de erratas** (`difflib`) — solo sobre términos con df=0 (aportan
   cero, corregirlos nunca empeora). Contra el **vocabulario crudo**, sin stem.

Efecto: actividades sin apoyo VaR 1→**0**, conductuales 4→**1**.

---

## 2. El evaluador ahora es crítico

**El prompt no tenía encuadre de rol**: empezaba directo en `MODELO BAJO
VALIDACIÓN:`. El modelo actuaba como lector complaciente.

Añadido en `modulos/motor_ia.py`:

- **Preámbulo**: *«Eres validador de segunda línea. La carga de la prueba está en
  el modelo, no en ti. No preguntes ¿hay algo que objetar? Pregunta ¿está
  DEMOSTRADO?»*
- **Cinco trampas**: documentado ≠ correcto · existe ≠ se ejecuta · se menciona ≠
  se justifica · se cita ≠ lo sostiene · se calcula ≠ se usa
- **Escala recalibrada**: el 4 exige *existe + se ejecutó + está justificado*;
  el 5 además *supuestos verificados y límites declarados*
- **Ante la duda, el puntaje menor**

**Dos límites deliberados** (no los quites):

1. Ser exigente **no es inventar deficiencias**. Si la evidencia es sólida, hay
   que decirlo.
2. **Ausencia de evidencia ≠ incumplimiento.** Penalizar por lo que no se leyó
   es un error del agente, no un hallazgo.

**Precedencia**: si hay bloque de calibración de sesgo, **ése manda** — mide el
error real contra correcciones humanas.

### Citas verificables

El prompt exige `fichero → "texto literal"`, y código dentro de ``` ```.
**Sin números de línea a propósito**: `Mx_01` lee el código sin numerar, así que
pedirlos garantizaría números inventados.

`_verificar_citas()` comprueba que cada fragmento >40 chars exista de verdad en
el contexto. Lo declara en `citas_no_verificadas`, **no lo corrige**: la
evaluación puede ser correcta aunque el modelo recompusiera una frase.

Campos nuevos **opcionales** (no en `_CAMPOS_CONTRATO_EVALUACION`, a propósito):
`inconsistencias`, `cuestionamiento_metodologico`.

---

## 3. Ocho skills conectadas

```
Pipeline  →  ¿cumple cada control?       →  puntajes  (EL DICTAMEN)
Skills    →  ¿qué se nos está escapando?  →  hallazgos (EL ANÁLISIS)
```

**No puntúan, y no deben hacerlo**: dos corridas con distinta selección tienen
que seguir siendo comparables.

| Skill | Coste | Pregunta |
|---|---|---|
| `coherencia` | medio | ¿El código hace lo que el manual dice? |
| `supuestos` | medio | ¿Se verificaron, o solo se asumieron? |
| `papers` | medio | ¿La bibliografía sostiene lo implementado? |
| `challenger` | alto | La alternativa no elegida **+ script ejecutable** |
| `regulatorio` | medio | ¿Qué exige la norma que aquí no está? |
| `gobierno` | bajo | ¿Quién aprueba, revisa, puede tocarlo? |
| `datos` | bajo | ¿Los datos están controlados? |
| `sintesis` | bajo | De todo lo anterior, ¿qué es grave? |

```bash
python agente.py --listar-skills
python agente.py --skills all|rapidas|coherencia,supuestos --titulo "..."
```

**Cuatro decisiones:** `sintesis` va siempre la última (consume el resto) ·
se ejecutan **antes de sellar** para entrar en la custodia · una skill que falla
**no tumba la corrida** y consta en el informe · las citas se verifican.

**Detalle no obvio:** `todos_inputs` es `{ámbito: [docs]}` y el manual alimenta
5 ámbitos → hay que **deduplicar por nombre** o el contexto trae el manual cinco
veces.

**El `agent/` v28 aparcado NO se reactivó.** Sus 17 skills son más ambiciosas
pero llevan un mes sin correr contra un proyecto que cambió debajo. Éstas son
más pequeñas a propósito: se ejecutan de verdad y entran en la custodia.

---

## 4. Informes

### `modulos/generador_markdown.py` — nuevo

Se genera **siempre**, también sin `--prdc`:
`outputs/<fecha>/informe_trabajo_<titulo>_<fecha>.md`

| Word | Markdown |
|---|---|
| El **entregable** | El **borrador de trabajo** |
| Maquetado, conciso | Razonamiento, citas, avisos, limitaciones |

Secciones **estables aunque estén vacías** (si alguien cita «§5» en un correo,
no puede apuntar a otra cosa la corrida siguiente): 0 Cómo leer · 1 Resumen ·
2 Inconsistencias · 3 Metodología · 3-bis Skills · 4 Peticiones · 5 Detalle ·
6 Limitaciones.

Bloques `> ✍️` marcan dónde escribe el validador.

**Bugs corregidos:** `agente` y `semaforo` son *dicts*, no cadenas — volcaban la
estructura entera en la cabecera.

### Word

Tres bloques nuevos en la ficha de control: `Inconsistencias detectadas`
(ordenadas por severidad, **ambas citas enfrentadas**), `Cuestionamiento
metodológico`, `Verificación de citas`.

---

## 5. Herramientas nuevas

```bash
python scripts/explicar_rag.py --dominio VaR --consulta "..."   # los 6 pasos, con números
python scripts/auditar_cobertura_rag.py --dominio VaR           # qué actividades quedan ciegas
python scripts/rebuild_rag_databricks.py --status               # estado de los índices
```

`explicar_rag.py` es el **acompañamiento ejecutable** de la guía: sus números se
regeneran en vez de envejecer en el `.md`.

### La auditoría mentía, y se corrigió

Su primera versión daba **97 % sólido** para un corpus de 6 KB. Al mirar qué
términos producían esa cobertura:

```
«Verifica la existencia de control de cambios» → cobertura 0.50
 …porque el fragmento contiene la palabra «documentación». Y nada más.
```

→ «CUBIERTA» exige ahora **≥2 términos de anclaje** con IDF>0. VaR cayó a 56 %,
que es la verdad. **Un informe de auditoría que se equivoca hacia arriba da por
resuelto justo lo que hay que arreglar.**

---

## 6. Cuatro guías escritas

| Guía | Para |
|---|---|
| [`GUIA_LLENAR_INPUTS.md`](GUIA_LLENAR_INPUTS.md) | Qué documento va en cada carpeta |
| [`GUIA_CORPUS_RAG.md`](GUIA_CORPUS_RAG.md) | Con qué alimentar el RAG y cómo medirlo |
| [`GUIA_RAG_LEXICO.md`](GUIA_RAG_LEXICO.md) | Cómo funciona el buscador |
| [`RUNBOOK.md`](RUNBOOK.md) | Flujo operativo (ya existía) |

---

## 7. Estado del entorno

**Deployment:** acaban de habilitar **gpt-5** (400k tokens, $1.25/Mtok — más
barato que gpt-4o). Familia de **razonamiento**: sin `temperature`, usa
`max_completion_tokens`. El proyecto lo maneja vía `config/modelos.py`.

⚠️ **Comprobar que lo detecta.** `perfil_modelo()` identifica por nombre. Si sale
*«Modelo X no está en config/modelos.py, perfil conservador (16.000 tokens)»*,
hay que añadir el nombre al catálogo.

**Volumen de evidencia:** bajó de 16,3 M a **324.000 chars** (~81k tokens) tras
depurar. Config recomendada en `.env`:

```bash
VIRF_MAX_CTX=400000
VIRF_PRESUPUESTO_DOC=100000
VIRF_MAX_CHUNKS=100
```

> `PRESUPUESTO_DOC` es el tope **por documento**. Si es alto, dos documentos
> llenan el ámbito y el resto puntúa 0 %. Regla:
> `PRESUPUESTO_DOC ≈ MAX_CTX / nº docs del ámbito más poblado`.

---

## 8. Pendiente — por orden de impacto

### 8.1 🔴 Los PDF reales del corpus RAG

`inputs/rag/` son documentos de apoyo de ~6 KB que se autodeclaran *«RESUMEN
SECUNDARIO — NO ES EL TEXTO OFICIAL»*. **Es la mejora con más impacto.**

| dominio | docs | frag./actividad | apoyo sólido |
|---|---|---|---|
| `shared` | 3 | 0.5 | 66 % |
| `VaR` | 3 | 0.4 | 50 % |
| `LaR` | 2 | 0.3 | 59 % |
| `conductuales` | **1** | **0.2** | **22 %** ← empezar aquí |

Qué conseguir: SR 11-7, BCBS 239, EBA/GL/2023/01 (shared) · BCBS 457 FRTB,
Kupiec 1995, Christoffersen 1998 (VaR) · BCBS 238/295 (LaR) · EBA IRRBB
(conductuales). Detalle en `GUIA_CORPUS_RAG.md` §3.

### 8.2 🟡 Erratas en `inputs/Estandares_VIRF.xlsx`

Verificadas — **coste casi nulo, efecto directo**:

| En el Excel | Debería decir | Impacto |
|---|---|---|
| `seguimeinto` (×3) | seguimiento | Única actividad sin apoyo en VaR y LaR |
| `monitorio` | monitoreo | Nunca casa |
| `suficienica` (×2) | suficiencia | Nunca casa |
| `contengas` | contenga | Nunca casa |

El tesauro tapa algunas, pero corregirlas en origen es lo correcto.

### 8.3 🟡 Calibrar con una corrida real

Nunca se ha ejecutado el pipeline completo con: gpt-5 + evaluador crítico +
skills + RAG expandido. **Guardar ese JSON como línea base.**

Un evaluador más estricto **bajará los scores**, y parte de esa bajada será justa
y parte severidad excesiva. Registrar el feedback (`--preprdc` lo pide al final)
— el bloque anti-sesgo aprende de esas correcciones.

### 8.4 🟢 Pesos y umbrales sin calibrar

`RAG_PESO_BM25=0.7` / `RAG_PESO_TFIDF=0.3` / `RAG_MIN_COBERTURA=0.15` son puntos
de partida razonados, **no calibrados** sobre literatura real.

### 8.5 🟢 Gobierno y Usos siguen puntuando bajo

**No es un bug.** `Gobierno` no tiene carpeta propia: lee de `doc_modelamiento` +
`implementacion`. Falta aportar actas de aprobación, matriz de roles y control de
accesos. Ídem `Usos` (lee de `usos/` + `implementacion/`).

---

## 9. Invariantes que no se pueden romper

1. **Cero HuggingFace, cero embeddings.** `validate_project.py` §5-bis lo vigila.
2. **El RAG no indexa la evidencia que evalúa.** Si `inputs/rag/` contuviera el
   manual del modelo, el agente se daría la razón a sí mismo.
3. **Las skills no puntúan.**
4. **El fallo del RAG o de una skill no tumba una validación.**
5. **Ausencia de evidencia ≠ incumplimiento.**
6. **Todo parámetro configurable vive en `config/parametros.py`.** Un segundo
   `os.getenv` es lo que permitió la divergencia histórica de `VIRF_MAX_CTX`.
7. **Ninguna cita sin verificar contra el contexto.**

---

## 10. Preferencias de trabajo del usuario

- **Flujos reutilizables, no artefactos sueltos.** Prefiere el generador
  automático al documento escrito a mano. Por eso `explicar_rag.py` acompaña a
  la guía y `auditar_cobertura_rag.py` mide en vez de estimar.
- **Flags explícitos, no detección automática por heurística.**
- **Respuestas breves**, sin sacrificar calidad.
- Pide que se le indique **paso a paso** cuando quiere ejecutarlo él.

---

## 11. Comandos de verificación

```bash
python -m pytest tests/ -q                      # 605 passed, 1 skipped
python validate_project.py --strict             # 133/133, exit 0
python agente.py --prevuelo                     # evidencia lista, coste 0
python scripts/rebuild_rag_databricks.py --status
python scripts/auditar_cobertura_rag.py --dominio VaR
```
