# FIXTURE SINTÉTICO — no es un modelo real

Este árbol **no documenta ningún modelo de la entidad**. Es evidencia fabricada
a propósito para probar el anclaje del juez de código (`--revisar-codigo`).

## Por qué existe

La primera corrida real del juez sobre `modelos/VaR_FRTB` salió limpia en el
camino que más importaba probar: los 2 hallazgos fueron `supuesto_tacito`, que
es una categoría que NO exige citar el manual. Las que sí lo exigen —`code_drift`
y `documentado_ausente`— no aparecieron, y por un motivo legítimo: en aquel
fixture el manual dice «ventana de 500 días» y el código usa `retornos[-500:]`.
Coinciden. El juez hizo lo correcto al no inventar una discrepancia.

Pero eso dejó sin ejercitar la verificación de citas: solo estaba probada por
tests unitarios, nunca contra un modelo real.

## Las discrepancias plantadas

Todas son verificables a mano contra los ficheros de este árbol:

| # | El manual dice | El código hace | Categoría esperada |
|---|---|---|---|
| 1 | ventana de **250** días hábiles | `retornos[-250:]` → **no**, usa `[-500:]` | `code_drift` |
| 2 | retornos **logarítmicos** | resta simple (aritméticos) | `code_drift` |
| 3 | declara `backtesting_kupiec()` | esa función **no existe** | `documentado_ausente` |
| 4 | nivel de confianza **99 %** | `confianza=0.95` por defecto | `code_drift` |

El manual de SEGUIMIENTO añade una quinta pista: declara haber medido las
excepciones «sobre la ventana de 250 días establecida en el manual», que es
justo la ventana que el código no usa. Sirve para comprobar que el revisor lee
también ese documento y no solo el metodológico.

## Qué se comprueba con esto

Que cuando el juez afirma «el manual dice X», ese X **existe literalmente** en
los manuales — y que cuando no puede acreditarlo, el hallazgo sale marcado
`SIN ANCLAR` en vez de pasar por probado.
