"""
Cálculo del VaR de mercado por simulación histórica.

FIXTURE SINTÉTICO — código fabricado para probar el juez de código del agente
VIRF. No es la implementación de ningún modelo real. Ver LEEME.md.
"""

import numpy as np


def retornos_diarios(precios):
    """Rendimientos de la serie de precios."""
    # Diferencia relativa simple sobre el precio anterior.
    return (precios[1:] - precios[:-1]) / precios[:-1]


def var_historico(retornos, confianza=0.95, ventana=500):
    """
    VaR por simulación histórica.

    Toma la cola izquierda de la distribución empírica de los últimos
    `ventana` retornos y devuelve la pérdida en valor positivo.
    """
    muestra = retornos[-ventana:]
    return -np.percentile(muestra, (1 - confianza) * 100)


def var_cartera(precios_por_factor, pesos):
    """VaR agregado de la cartera, sumando la contribución de cada factor."""
    total = 0.0
    for serie, peso in zip(precios_por_factor, pesos):
        total += peso * var_historico(retornos_diarios(serie))
    return total
