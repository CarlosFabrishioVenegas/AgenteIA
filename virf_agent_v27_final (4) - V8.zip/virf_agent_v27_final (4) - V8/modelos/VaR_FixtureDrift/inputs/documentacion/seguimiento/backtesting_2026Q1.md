# Informe de seguimiento — VaR de mercado, 2026 Q1 (FIXTURE SINTÉTICO)

> Documento fabricado para probar el juez de código. Ver `LEEME.md`.

## Resultado del backtesting

Durante el primer trimestre de 2026 se contrastaron las pérdidas realizadas
contra el VaR estimado **sobre la ventana de 250 días establecida en el manual
metodológico**.

Se observaron **4 excepciones** en 62 días de negociación, dentro de la zona
verde del semáforo de Basilea y compatible con el intervalo de la prueba de
Kupiec al 99 % de confianza.

## Ejecución

El contraste se realizó con la función `backtesting_kupiec()` documentada en el
manual, sobre los mismos retornos logarítmicos empleados en la estimación.

## Conclusión

El modelo se comporta conforme a lo especificado. No se requiere recalibración
en este trimestre.
