# Manual metodológico — VaR de mercado (FIXTURE SINTÉTICO)

> Documento fabricado para probar el juez de código. No describe ningún modelo
> real de la entidad. Ver `LEEME.md` en la raíz de este árbol.

## 1. Alcance

El modelo calcula el Valor en Riesgo (VaR) de la cartera de negociación por el
método de **simulación histórica**.

## 2. Especificación del cálculo

El VaR se estima sobre una **ventana de 250 días hábiles**, equivalente a un
año de observaciones. Esta longitud se fijó tras comprobar que ventanas
inferiores producían un número de excepciones fuera del intervalo de Kupiec, y
que ventanas superiores diluían la reacción del modelo ante cambios de régimen.

El **nivel de confianza es del 99 %** y el horizonte de mantenimiento es de
**1 día**. Ambos parámetros son fijos: no se admite su modificación en tiempo
de ejecución sin aprobación del Comité de Riesgos.

Los rendimientos de los factores de riesgo se calculan como **retornos
logarítmicos**, por su propiedad de aditividad temporal, que es la que permite
escalar el horizonte cuando procede.

## 3. Backtesting

El módulo implementa la función `backtesting_kupiec()`, que contrasta el número
de excepciones observadas contra el intervalo de confianza de la prueba de
cobertura incondicional de Kupiec (1995), y devuelve el estadístico LR junto
con su p-valor.

## 4. Limitaciones declaradas

La simulación histórica asume que la distribución empírica del pasado reciente
es representativa del futuro inmediato. No captura eventos sin precedente en la
ventana de estimación.
