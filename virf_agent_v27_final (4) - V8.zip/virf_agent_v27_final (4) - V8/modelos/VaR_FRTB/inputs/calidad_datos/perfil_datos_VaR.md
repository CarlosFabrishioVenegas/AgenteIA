# Perfil de datos — series de precios
Fuente: Bloomberg. 500 observaciones diarias. 0.4% de valores ausentes,
imputados por último valor conocido. Sin duplicados de fecha.
