# Acta Comité de Riesgos — 2026-04-10
Se revisan los límites de VaR de la cartera de negociación. El VaR se utiliza como
límite operativo diario y su consumo se reporta al Comité mensualmente.
