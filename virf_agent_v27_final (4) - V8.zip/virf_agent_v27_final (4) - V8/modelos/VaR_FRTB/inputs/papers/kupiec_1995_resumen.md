# Kupiec (1995) — Techniques for Verifying the Accuracy of Risk Measurement Models
Propone la prueba de razón de verosimilitud (LR) para contrastar si la tasa de
excedencias observada es consistente con el nivel de confianza declarado.
