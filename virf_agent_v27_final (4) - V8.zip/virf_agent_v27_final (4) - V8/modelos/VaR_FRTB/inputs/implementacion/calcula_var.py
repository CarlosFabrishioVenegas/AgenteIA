import numpy as np
def var_historico(retornos, confianza=0.99):
    """VaR histórico. Ventana de 500 días según manual metodológico §2."""
    return -np.percentile(retornos[-500:], (1 - confianza) * 100)
