# Backtesting VaR — 2026 Q1
Excedencias observadas: 3 sobre 62 días. Esperadas al 99%: 0.62.
Kupiec LR = 3.81 (p-valor 0.051) → NO se rechaza al 5%. Zona verde de Basilea.
Christoffersen: no se detecta agrupamiento de excedencias.
