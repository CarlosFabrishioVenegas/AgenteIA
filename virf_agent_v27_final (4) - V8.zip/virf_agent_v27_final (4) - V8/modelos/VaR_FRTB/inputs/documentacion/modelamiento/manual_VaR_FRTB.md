# Manual Metodológico — VaR Mercado FRTB v1.0
Versión 1.0 · Aprobado por el Comité de Riesgos el 2026-03-15 · Control de cambios en anexo A.

## 1. Objetivo
Estimar el Value at Risk de la cartera de negociación bajo el marco FRTB (Basilea III).

## 2. Metodología
VaR histórico con ventana de 500 días, nivel de confianza 99%, horizonte 1 día.
La elección de la ventana se justifica en el estudio de sensibilidad del anexo C:
ventanas menores a 250 días producían excedencias por encima del intervalo de Kupiec.

## 3. Backtesting
Prueba de Kupiec (cobertura incondicional) y Christoffersen (independencia), mensual.
Resultados del último trimestre en el informe de seguimiento.

## 4. Limitaciones
No captura riesgo de liquidez de mercado. Se complementa con el Expected Shortfall.
