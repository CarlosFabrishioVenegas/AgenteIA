# Prompt de continuidad — VIRF Agent · 2026-08-07

**Cómo usar este documento.** Pégalo completo como primer mensaje a la IA que
continúe. Sustituye a `PROMPT_CONTINUIDAD.md` (que se conserva: describe el
encargo original, ya cerrado). Contiene el estado real, las trampas nuevas y lo
que queda.

---

## Rol

> Actúas como **Ingeniero de Software Senior especializado en sistemas de
> auditoría regulatoria**, sobre VIRF Agent v27: un validador independiente de
> modelos financieros para un equipo de 2-5 validadores en una entidad
> supervisada.
>
> Regla de oro: **no marques nada como correcto sin haber leído el código real
> o ejecutado el caso real.** Un «✅ OK» falso cuesta más que un fallo
> declarado.

---

## 1. Estado actual — verificado el 2026-08-06

| Puerta | Valor |
|---|---|
| `python validate_project.py --strict` | **145/145**, 0 WARN, 0 FAIL |
| `python -m pytest -q` | **752 passed**, 1 skipped |

**⚠️ NO HAY CRÉDITO DE API.** La última corrida murió a mitad con
`'Your credit balance is too low'` (Anthropic). Hasta que el usuario confirme
saldo, **no lances corridas**. Todo lo verificable sin API está verificado.

**Lee primero `QUE_HACE_REALMENTE.md`** — describe qué hace el sistema con
cifras medidas y, sobre todo, qué NO hace. Es más fiable que el resto de la
documentación, que en parte está desfasada.

---

## 2. Qué se hizo en la sesión anterior

### Encargo original (`PROMPT_CONTINUIDAD.md`) — cerrado

| # | Pendiente | Estado |
|---|---|---|
| 1 | Registro append-only de emisiones | ✅ `--verificar-emisiones`, probado borrando un informe real |
| 2 | Firma en las correcciones de feedback | ✅ ambos módulos, retrocompatible |
| 3 | Doble firma Tier 1 | ✅ construida, **desactivada** por decisión del usuario |
| 4 | Corpus RAG oficial | ⚠️ **cerrado como «no oficial»** por decisión del usuario: se declara en el informe |
| 5 | `PROCEDIMIENTO_VALIDACION.md` | ⚠️ parcial — ver §5 |

### Trabajo adicional

- **Enrutado RAG**: `inferir_dominio` coincidía por subcadena y enrutaba mal
  6 de 12 títulos reales. Ahora palabra completa + `--dominio-rag` explícito,
  con la procedencia declarada en el informe.
- **RAG como pericia**: el bloque llegaba crudo. Ahora va encuadrado con sus
  guardas (no citarlo como evidencia, la ausencia no prueba nada, aviso de
  corpus no oficial).
- **Skills**: recibían el contexto aplastado y sin RAG; ahora reparto por
  cuotas con cobertura declarada, y sus hallazgos **llegan al Word**.
- **Juez de código anclado**: `referencia_manual` se verifica de verdad;
  categorías que contradicen los hechos se corrigen dejando rastro.
- **`--analizar-codigo`** (nuevo): hechos del AST + ejecución de notebooks, sin
  LLM y sin ejecutar nada. Determinista, coste 0.
- **Reintento de contrato**: un JSON truncado ya no pierde la actividad.

---

## 3. Trampas de ESTE código — las nuevas

Las del prompt original siguen vigentes. Estas se descubrieron después.

### 3.9. `.get(clave, respaldo)` — apariciones 3 y 4

El §3.4 original documentaba dos. En la sesión anterior aparecieron **dos más**,
y una tumbaba cinco de las ocho skills en producción:

```python
key=lambda e: e.get("puntaje", 5)   # TypeError: NoneType < int
```

El respaldo solo actúa si la clave **falta**. El invariante 2 escribe
`"puntaje": None` —la clave existe— para toda actividad sin evaluar. Es decir:
**el invariante que protege el dictamen era el que rompía las skills.**

> Cuando encuentres una, busca las demás. Se corrigieron dos: `skills/base.py`
> (la que fallaba) y `feedback.py` (latente, encontrada al buscar).

### 3.10. Trabajo caro que se tira antes del entregable

**Ocurrió dos veces, independientemente.** Un análisis se paga al modelo, se
guarda en el JSON y en el borrador `.md`… y no llega al Word que se entrega:

| Caso | Qué se perdía |
|---|---|
| `--revisar-codigo` | El fragmento de código y el motivo, aplastados a 120 chars |
| `--skills` | Hasta 8 llamadas: `generador_word.py` no mencionaba «skills» |

> **Regla: cuando añadas un análisis, sigue el dato hasta el `.docx`.** El
> borrador `.md` no cuenta: es lo que lee el validador mientras decide, no lo
> que recibe el auditor.

### 3.11. Un test que coincide con un literal no prueba nada

Escribí un test que buscaba `_ctx_skills[:_MAX_CTX]` para detectar el corte
plano. Al reintroducir el defecto **escrito de otra forma**, el test siguió
pasando. Falso negativo detectado justo al probar que detectaba.

> Comprueba que la función correcta **se llama** (AST), no cómo se escribe lo
> incorrecto.

### 3.12. Las aserciones sobre prompts fallan por el salto de línea

Un bloque de prompt formateado parte las frases: `"no\n    se exige"`. Buscar
la frase literal encuentra un fallo inexistente. **Normaliza espacios** antes
de comparar (`" ".join(texto.split())`).

### 3.13. La verificación literal es demasiado estricta con las elisiones

El modelo cita con `[...]` en medio —práctica normal— y las dos mitades sí
están en el manual. Comparar la cadena entera daba `SIN ANCLAR` sobre una cita
**bien formada**.

> Un falso positivo sobre algo correcto es el peor resultado: enseña al equipo
> a ignorar el aviso, y entonces pasan los que sí importan.

### 3.14. `outputs/` solo admite carpetas `YYYY-MM-DD`

Escribí un informe de prueba en la raíz de `outputs/` y tumbé un test y el
gate. Los ficheros temporales van al scratchpad, **nunca a `outputs/`**.

### 3.15. Ojo con los heredocs de bash en este entorno

`cat << 'EOF'` con contenido Python largo falla (`unexpected EOF`). Usa las
herramientas de edición de ficheros, no el shell, para escribir código.

---

## 4. Cómo trabajar

```bash
python validate_project.py --strict     # 145 checks, coste 0, exit 1 si falla
python -m pytest -q                     # 752 tests (~5 min)
```

Cada corrección debe llevar: comentario `[AUDIT-FIX]` con **qué hacía antes,
por qué estaba mal y cómo se midió**; un test que falle si el defecto vuelve
—verificado reintroduciéndolo—; y un check en `validate_project.py` si el
invariante se puede comprobar sin API.

### Verificar sin gastar

La sesión anterior cerró varias verificaciones **interceptando `_llamar_modelo`**
con respuestas simuladas. Eso ejercita el camino real —parseo, verificación de
citas contra la evidencia real, renderizado al Word— sin API. Lo único simulado
es qué contestaría el modelo. Es una técnica válida y conviene reutilizarla.

---

## 5. ENCARGO PENDIENTE

### 5.1 — Políticas de la entidad ⬛ bloqueante, no es código

`PROCEDIMIENTO_VALIDACION.md` tiene confirmados umbrales de rechazo (< 2,5),
periodicidad, escalado y control del estándar. **Siguen sin definir**, marcados
⛔ a propósito:

- **roles y segregación de funciones** (§1);
- **plazo de retención** (§8);
- criterio formal de «hallazgo crítico»;
- umbral de rechazo **por ámbito**.

> **No los inventes.** El encargo original lo prohíbe explícitamente y el
> usuario ya confirmó que no están definidos. Pregunta; si no hay respuesta,
> se quedan en ⛔.

### 5.2 — Notebooks entregados sin salidas ⬛ decisión de política

`.gitignore:74` dice «limpiar outputs antes de commitear». Es buena higiene de
repo y **lo contrario de lo que necesita una validación**: un notebook sin
salidas se marca `alta` («no acredita ejecución»), lo cual es correcto pero
sería un falso positivo si el equipo limpia por costumbre.

**Propuesto y sin respuesta:** añadir al procedimiento que los notebooks se
entregan **ejecutados de arriba abajo** (`Restart & Run All`). Eso arregla
además el orden alterado de raíz.

### 5.3 — Actualizar `QUE_HACE_REALMENTE.md` ⬛ pequeño

La §5 describe `--analizar-codigo` **sin la parte de notebooks** (celdas sin
ejecutar, excepciones guardadas, orden de ejecución alterado), añadida después.

### 5.4 — Verificación que quedó a medias por falta de crédito

Nunca se ha visto, sobre datos reales:

- la **calidad** del análisis de las skills (el cableado sí está probado);
- el juez de código con `--revisar-codigo` sobre un modelo con discrepancias
  reales (probado sobre `modelos/VaR_FixtureDrift`, que es sintético).

Cuando haya saldo: `--skills rapidas` son 3 llamadas y basta.

### 5.5 — Hueco residual conocido, declarado

Un hallazgo de código con el `elemento` mal puesto **y** sin cita escapa a la
verificación de anclaje. Se observó una vez. Cerrarlo exigiría interpretar la
prosa de la descripción — heurística frágil que se descartó a propósito.

---

## 6. Decisiones tomadas que NO hay que revisar

Se discutieron y se cerraron. Reabrirlas sin motivo nuevo es perder tiempo:

| Decisión | Motivo |
|---|---|
| **Doble firma Tier 1 desactivada** | El usuario lo confirmó |
| **Corpus RAG no oficial, por ahora** | Confirmado; se declara en el informe |
| **Tier 1 exige 24 y Tier 4 exige 29** | El usuario confirmó que el Excel es correcto |
| **`--analizar-codigo` NO ejecuta código** | Es del validado; correría con permisos sobre `audit_logs/`. Hay un test que lo impide |
| **El RAG no es un eje de comparación** | Informa los cuatro contrastes existentes; no se añade «RAG vs código» |
| **La coherencia no usa RAG** | Su cometido es manual ↔ implementación |

---

## 7. Fixtures disponibles

| Ruta | Para qué |
|---|---|
| `modelos/VaR_FRTB` | Modelo coherente: manual y código **coinciden**. Sirve para comprobar que no se inventan discrepancias |
| `modelos/VaR_FixtureDrift` | **4 discrepancias plantadas** y documentadas en su `LEEME.md`. Sirve para probar detección |

Los dos juntos son lo que permite medir precisión **y** ausencia de falsos
positivos. Úsalos siempre en pareja.

---

## 8. Cómo entregar

1. Ambas puertas en verde, con el número de checks y tests.
2. Los tests nuevos **y la prueba de que detectan el defecto** — reintrodúcelo
   y muestra que falla.
3. Lo que **no** hiciste y por qué.
4. Si el defecto lo introdujiste tú, dilo. En la sesión anterior introduje tres
   —la contaminación del registro por los tests, el fichero suelto en
   `outputs/`, y un test con falso negativo— y decirlo fue lo que permitió
   corregirlos bien.

---

## 9. Aviso final

> **Prefiere siempre declarar una ausencia antes que rellenar un hueco.**

Todo el diseño sale de ahí: la actividad sin evaluar queda sin puntaje; la cita
que no se encuentra se marca; el documento recortado dice cuánto; el corpus no
oficial lo declara el informe; el dominio inferido se distingue del declarado.

Y su corolario, que costó dos defectos aprender: **un aviso que salta cuando no
debe es tan dañino como uno que no salta.** Si un control marca como sospechoso
algo correcto, el equipo aprende a ignorarlo — y con él pasan los verdaderos.
