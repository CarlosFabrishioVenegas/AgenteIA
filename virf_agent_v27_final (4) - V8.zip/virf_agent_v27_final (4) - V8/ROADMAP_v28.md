# Roadmap v28 — Qué mejorar y cuánto cuesta

> **Cómo se construyó esta lista.** Todo lo que sigue son **hallazgos verificados
> ejecutando código**, no ideas. Cada punto cita el fichero y el documento donde
> quedó registrado durante la auditoría del 30/07/2026. No hay ningún TODO en el
> código activo: estos son los huecos que quedaron *documentados* pero sin cerrar.
>
> **Cómo leer las estimaciones.** En días de desarrollador, **incluyendo** lo que
> este proyecto exige por disciplina propia: tests de regresión que fijen el
> invariante, actualización de los 4 documentos afectados, y la suite completa
> (~4,5 min por corrida). Un cambio "de una línea" aquí nunca es de una línea.
>
> Las estimaciones son de esfuerzo, no de calendario. Con dedicación parcial,
> multiplica.

---

> ## ✅ EJECUTADO EL 30/07/2026 — qué queda vivo de este roadmap
>
> Buena parte del plan se ejecutó el mismo día que se escribió. Estado real:
>
> | Punto | Estado |
> |---|---|
> | **P0.1** `--prdc` no llega a `--control` | ✅ **Resuelto en dos tiempos.** La firma se descartó por decisión: el entregable sale del pipeline completo, que YA ejecuta los controles y los fusiona (`FLAGS.md` §16.1). El **sellado sí se implementó** (P0.1-A) al descubrir que las corridas de `--control` rompían `--verificar-cadena` |
> | **P0.2** Path traversal en `--control` | ✅ **Corregido** + barrido que cubre los tres puntos |
> | **P0.3** `outputs/` divergente | ✅ **Corregido**: ambos pipelines usan `OUTPUTS_DIR` |
> | **P0.4** `--sin-llm` exigía credencial | ✅ **Corregido** |
> | **P1.1** Reintento 429 solo en Azure | ⚠️ **Vivo** — el cliente de Anthropic sigue sin cubrir |
> | **P1.2** Formatos omitidos en silencio | ✅ **Resuelto por otra vía**: `--prevuelo` los declara antes de gastar. Registrar más extensiones sigue siendo opcional |
> | **P1.3** Colisión de dominio RAG | ⚠️ **Vivo** — `"Variables macro"` sigue resolviendo a `VaR` |
> | **P2.1** Razonamiento entre módulos | ⚠️ **Vivo** — sigue siendo el mayor salto de valor pendiente |
> | **P2.2** Cachear el manual en la revisión | ⚠️ **Vivo** |
> | **P2.3** Comparación entre corridas | ✅ **Hecho**: `--comparar`, y detecta cambios de la vara de medir |
> | **P3.1** `validate_project` y los 6 invariantes | ⚠️ **Vivo** — cubre 3 de 6 con checks de coste 0 |
> | **P3.2** `--revisar-codigo` en `--control` | ❌ **Descartado**: dependía de P0.1 |
> | **P3.3** Consolidar documentación | ⚠️ **Vivo** |
>
> **Añadido fuera del plan**, por hallazgos de la propia ejecución:
>
> | | |
> |---|---|
> | Lock en la cadena de custodia | 6 validaciones simultáneas del mismo modelo **bifurcaban la cadena** — los seis informes decían ser el eslabón #1. Reproducido y cerrado |
> | `--prevuelo` | Comprobar la evidencia antes de gastar |
> | Trazabilidad del prompt | `agente.prompts` + `prompt_sha256` en las 34 evaluaciones |
> | RAG léxico (BM25+TF-IDF), sin embeddings ni HuggingFace | Un solo deployment (chat) + política de modelos externos. `chromadb` arrastraba `huggingface-hub` |
> | OCR retirado | Misma política. La pérdida se declara, no se silencia |
> | Proxy corporativo y CA propia | `VIRF_CA_BUNDLE`, diagnóstico de TLS |
>
> **Esfuerzo restante: 8-13 d** (era 16-24).

---

## Resumen ejecutivo · lo que QUEDA

| Prioridad | Bloque | Esfuerzo |
|---|---|---:|
| **P1** | Robustez: reintento en Anthropic · colisión RAG | **2 d** |
| **P2** | Capacidad: grafo entre módulos · caché del manual | **4-6 d** |
| **P3** | Ergonomía: invariantes en `validate_project` · docs | **2-4 d** |
| | **Total** | **8-13 d** |

**Recomendación ahora:** P2.1 (razonamiento entre módulos) es lo que más valor
añade — el *code drift* entre ficheros es de los hallazgos que un validador
humano tarda más en encontrar a mano. P1 son dos arreglos baratos que puedes
hacer en un rato.

---

## P0 — Asimetrías del pipeline `--control`

> **Por qué es P0.** Son cuatro huecos en el **mismo** pipeline, y tres afectan a
> cumplimiento regulatorio. Un informe emitido con `--control --prdc` **parece**
> un entregable firmado y no lo es. Documentado en `FLAGS.md` §16.

### P0.1-A — Sellado sin firma en `--control` · ✅ **HECHO (30/07/2026)**

> Decisión del usuario tras reabrir P0.1: **sellar sí, firmar no.**
>
> Firmar es un acto de aprobación y `--control` no aprueba nada. Sellar es
> trazabilidad de que una corrida ocurrió, gastó llamadas y produjo un JSON.
>
> **Al implementarlo apareció un fallo activo, no una carencia.**
> `informes_de_modelo()` barre `resultados_*.json`, que es exactamente el
> patrón que escribe el pipeline por control. Sus corridas **ya entraban** en
> la cadena, sin sello. Reproducido:
>
> ```
> [ 1] resultados_LaR_ctrl.json  → ⚠️  SIN CUSTODIA
> [ 2] resultados_LaR_A.json     → ❌ ROTO — «se insertó, borró, reordenó
>                                     o alteró un informe de la secuencia»
> integra: False
> ```
>
> Una sola corrida de trabajo bastaba para que `--verificar-cadena` acusara a
> un **entregable legítimo** de haber sido manipulado. Misma clase de daño que
> la carrera que cerró `sellar_y_escribir()`.
>
> **Implementado:** `custodia.sellar()` acepta `tipo` (`TIPO_ENTREGABLE` /
> `TIPO_TRABAJO`); `motor_ia_v2` sella como `trabajo` en vez de escribir el
> JSON a pelo; `--verificar-cadena` distingue los dos tipos y resume
> «N entregable(s), M corrida(s) de trabajo». Sin firma, y el Word se mantiene
> siempre. Compatibilidad: los sellos previos se leen como `entregable`.
>
> **6 tests**, uno de ellos fijando el fallo original.

---

### P0.1 — `--prdc` no llega al pipeline de controles · *(histórico)*

`orquestar_pipeline_virf()` (`modulos/motor_ia_v2.py:719`) **no recibe** ningún
parámetro derivado de `--prdc`. Verificado: el módulo tiene **0 referencias** a
`sellar`, `validador_humano` o `nombre_seguro`.

Consecuencias medidas:

| | Pipeline completo | `--control` |
|---|---|---|
| Word | solo con `--prdc` | **siempre** |
| Firma del validador | obligatoria con `--prdc` | **nunca se pide** |
| Cadena de custodia | siempre | **nunca se sella** |
| Registro de aprobación | con `--prdc` | no |

En `--control`, `--prdc` solo cambia el texto del banner.

**Trabajo:** propagar el modo, reutilizar `validador_humano.solicitar_identidad()`
y `custodia.sellar()` —ambos ya existen y están probados—, y decidir si el Word
pasa a ser condicional (rompe expectativas de quien ya lo usa) o se mantiene
siempre (más seguro).

**Riesgo:** medio. Toca el flujo de un pipeline en uso.

---

### P0.2 — El saneo de nombre no se aplica en `--control` · **0,5 d**

`motor_ia_v2.py:781` interpola `--titulo` **crudo** en la ruta de salida:

```python
json_resultados = outputs_dir / f"resultados_{nombre_modelo}_{fecha_informe}.json"
```

El pipeline completo usa `nombre_seguro()`. El test
`TestAuditoriaPathTraversalEnSalidas::test_los_dos_puntos_vulnerables_lo_usan`
verifica `agente.py` y `explicador_modelo.py`, pero **no** este tercer punto.

**Trabajo:** una línea + extender el test existente a los tres puntos.

**Riesgo:** bajo. Es la corrección más barata de la lista y cierra un agujero de
seguridad conocido.

---

### P0.3 — `--raiz-evidencia` redirige `outputs/` solo en `--control` · **1 d**

| | Ruta de salida |
|---|---|
| Pipeline completo | `OUTPUTS_DIR/<fecha>/` — raíz del proyecto (`agente.py:692`) |
| `--control` | `base_project_path/outputs/<fecha>/` (`motor_ia_v2.py:744`) |

Con `--control --raiz-evidencia modelos/VaR_FRTB`, los resultados aparecen en
`modelos/VaR_FRTB/outputs/`. Si los buscas donde siempre, no están — y
`--verificar-cadena` tampoco los encuentra.

**Trabajo:** unificar en `OUTPUTS_DIR` + test que fije que ambos pipelines
escriben en el mismo sitio. **Decisión de diseño:** unificar es lo correcto (los
informes de todos los modelos juntos y fechados, como dice `redirigir_evidencia`),
pero rompe la ubicación para quien ya use el flag combinado.

---

### P0.4 — `--controles-a-notebook --sin-llm` exige credencial · **0,5 d**

La exención del PRE-FLIGHT (`agente.py:325`) contempla
`(args.convertir_excel and args.sin_llm)` pero no el equivalente para
`--controles-a-notebook`. Con `--sin-llm` no se usará el modelo, pero sin clave
válida el comando muere igual.

**Trabajo:** añadir la condición + test. `FLAGS.md` §16.4.

---

## P1 — Robustez

### P1.1 — El reintento ante `429` solo cubre Azure · **1 d**

`config/red.py:con_reintento()` está enchufado a `ClienteAzureOpenAIIA` pero
**no** a `ClienteAnthropicIA`. Si algún día se opera con el proveedor
secundario, un rate limit vuelve a abortar la corrida a mitad del chunking con
la extracción ya pagada.

> La función se movió de `config/ia.py` a `config/red.py` al añadir los
> embeddings por Azure: `config/ia.py` importa `_extraer_json` de
> `modulos/motor_ia.py` —una inversión de capas— y depender de él cerraba un
> ciclo de imports con `src/rag/`.

**Trabajo:** envolver la llamada del cliente Anthropic igual, y extender
`TestReintentoAnteCuotaAgotada` para cubrir ambos. La función ya existe y está
probada: es aplicarla.

---

### P1.2 — Formatos omitidos en silencio · **1-2 d**

Un fichero cuya extensión no esté en `LECTORES_EXT` **desaparece sin avisar**:
`leer_archivo()` devuelve `None` y nadie lo reporta. Hoy quedan fuera `.scala`,
`.yaml`, `.do`, `.sas`, `.jl`, `.m`.

Es la única frontera del sistema que **no se declara en el informe** — está
documentada en `METODOLOGIA_DEL_AGENTE.md` §13, pero el operador que no lea ese
documento no lo sabrá.

**Dos trabajos, elige o haz ambos:**

| Opción | Esfuerzo | Efecto |
|---|---:|---|
| **a)** Avisar de lo omitido | 0,5 d | `leer_carpeta()` cuenta los ficheros descartados y los lista en consola y en el JSON. **Convierte un silencio en un dato.** |
| **b)** Registrar más formatos | 0,5 d c/u | `.scala`, `.yaml`, `.sas`… El patrón ya está trazado: extensión en `LECTORES_EXT`, lenguaje en `LENGUAJE_POR_EXT`, frontera de corte en `FRONTERAS_POR_LENGUAJE` |

**Recomendación: haz (a) primero.** Es más barato y elimina la clase entera de
problema; (b) se hace bajo demanda cuando un modelo real lo necesite.

---

### P1.3 — Colisión en la inferencia de dominio RAG · **1 d**

`inferir_dominio()` (`src/rag/__init__.py`) busca **subcadenas sin límite de
palabra**. Verificado ejecutando:

```
Variables macroeconomicas    -> VaR      ← contiene "var"
Modelo escalar               -> LaR      ← contiene "lar"
VaR Mercado                  -> VaR      ✓
Modelo LaR                   -> LaR      ✓
```

Un modelo llamado *"Variables macroeconómicas"* consulta el índice de VaR. No
rompe la corrida —el RAG solo enriquece— pero inyecta contexto del dominio
equivocado, y eso queda registrado en `rag_dominio` del JSON.

**Trabajo:** límites de palabra (`\b`) + una tabla de excepciones, o un flag
`--dominio-rag` explícito que gane sobre la heurística. Esto último encaja mejor
con la política del proyecto de no adivinar el modo por heurística.

---

## P2 — Capacidad de análisis

> Aquí está el salto de valor. También el riesgo: son cambios que afectan a la
> calidad del dictamen, no solo a la mecánica.

### P2.1 — Razonamiento entre módulos en la revisión de código · **3-4 d**

`--revisar-codigo` evalúa cada fichero **solo**, con el manual como contexto fijo.
Es lo que permite que cada módulo entre íntegro, pero significa que una
incoherencia *entre* ficheros se le escapa: `main.py` llama a `lar()` con
argumentos que no cuadran con los que define `libs/calculo.py`, y ninguna llamada
ve los dos a la vez.

**Enfoque propuesto — dos fases, sin renunciar a que cada módulo entre entero:**

1. **Fase de índice (barata).** Extraer con `ast` —sin LLM— la firma de cada
   función y clase, y quién llama a quién. Es análisis estático: coste 0.
2. **Fase de contraste.** Pasar ese índice como contexto adicional a cada
   llamada, y añadir una llamada final que revise **solo el grafo**: firmas que no
   cuadran, funciones definidas y nunca llamadas, llamadas a funciones
   inexistentes.

**Coste operativo:** +1 llamada por corrida, no +N. El índice es texto compacto.

**Por qué merece la pena:** el *code drift* entre módulos es de los hallazgos que
un validador humano tarda más en encontrar a mano.

---

### P2.2 — Cachear el manual en la revisión de código · **1-2 d**

El manual viaja como contexto fijo en **cada** llamada. Con 30 módulos, cada
carácter del manual se paga 30 veces — es el multiplicador del coste, y hoy la
única palanca es recortarlo (`VIRF_MAX_CHARS_MANUAL_REVISION`).

**Opciones:**

| Enfoque | Esfuerzo | Ahorro |
|---|---:|---|
| *Prompt caching* del proveedor (si el deployment lo soporta) | 1 d | hasta 90 % del coste del manual |
| Resumir el manual **una vez** con el chunker y reutilizar el resumen | 1-2 d | proporcional al recorte, pero pierde literalidad |

**Recomendación:** la primera si Azure la ofrece en tu deployment; la segunda
degrada la calidad del contraste, que es justo lo que no queremos tocar.

---

### P2.3 — Comparación entre corridas · **2-3 d**

Hoy cada informe es una foto. Un validador que revalida un modelo cada trimestre
quiere saber **qué cambió**: qué puntajes subieron, qué hallazgos desaparecieron,
qué evidencia se actualizó.

Toda la materia prima ya existe —`documentos_huella`, `estandar`,
`huella_ejecucion` y la cadena de custodia enlazan los informes en orden— pero
nadie los compara.

**Trabajo:** un comando `--comparar MODELO` que tome los dos últimos eslabones de
la cadena y produzca un diff legible: score por ámbito, hallazgos nuevos y
resueltos, documentos que cambiaron de hash.

**Por qué es valioso:** distingue *"el modelo mejoró"* de *"cambió el criterio"* —
que es exactamente lo que la huella del estándar se guardó para poder responder.

---

## P3 — Ergonomía y mantenimiento

### P3.1 — Extender `validate_project` a los 6 invariantes · **1-2 d**

Los 6 invariantes tienen test de regresión, pero solo **1, 4 y 5** tienen check de
coste cero en `validate_project.py`. Los invariantes 2, 3 y 6 solo se verifican al
correr la suite (~4,5 min).

**Trabajo:** tres checks estáticos más. Valor: el operador comprueba los seis
invariantes en 3 segundos antes de una corrida cara.

---

### P3.2 — `--revisar-codigo` en el pipeline `--control` · **1 d**

Hoy es exclusivo del pipeline completo. Quien valide solo Calidad de Datos no
puede contrastar el código de los controles contra su documentación.

**Depende de P0.1:** no tiene sentido añadirlo a un pipeline que aún no sella
custodia.

---

### P3.3 — Consolidar la documentación · **1-2 d**

Seis documentos, ~5.500 líneas, con solapamiento real entre `README.md` §6,
`FLAGS.md` y `FUNCIONALIDADES.md`. Están cruzados y contrastados
automáticamente contra el código, pero el solapamiento es deuda: cada cambio de
flag exige tocar tres sitios.

**Trabajo:** que `FLAGS.md` §1 se **genere** desde el `argparse` con un script, y
que el README enlace en vez de duplicar. Encaja con el principio del proyecto de
preferir un generador a un artefacto escrito a mano.

---

## Plan sugerido

### v27.2 — «cumplimiento cerrado» · **4-6 d**

Solo P0. Cierra las cuatro asimetrías de `--control`. Es la versión que hace que
**cualquier** informe del sistema acredite lo que dice acreditar.

> Empieza por **P0.2** (0,5 d): es la más barata, cierra un agujero de seguridad
> y no rompe nada. Sirve de calentamiento para P0.1, que es la de más riesgo.

### v28.0 — «robusto y multiproveedor» · **+3-4 d** (7-10 acumulado)

P0 + P1. Reintento en ambos proveedores, ningún fichero omitido en silencio,
dominio RAG sin colisiones.

### v28.1 — «análisis profundo» · **+6-9 d** (13-19 acumulado)

P2. El grafo entre módulos y la comparación entre corridas son las dos
capacidades que un validador humano pediría después de usar el sistema un
trimestre.

### Continuo

P3 según haga falta. P3.3 se amortiza solo si la CLI sigue creciendo.

---

## Lo que NO recomiendo hacer

**No añadas fallback automático entre proveedores.** Está prohibido por política y
por una razón buena: un informe con evaluaciones de dos modelos bajo una sola
huella de ejecución haría falsa la reproducibilidad que el propio informe declara.

**No subas `VIRF_CHUNK_SIZE` sin medir la calidad.** La tentación con 128K de
contexto es hacer menos llamadas. Un segmento demasiado grande produce resúmenes
genéricos, y este sistema busca hallazgos concretos. Mide antes y después sobre el
mismo documento.

**No bajes `VIRF_MAX_CHUNKS` de 34.** Medido: cuesta **más**, no menos. Por debajo
de ese punto el segmento adaptativo supera el tope, cae al modo jerárquico puro y
el coste sube de $1,14 a $2,27.

**No verifiques imports con `importlib`.** El 30/07/2026 un barrido con
`importlib` ejecutó el código de nivel superior de `create_estandares_excel.py` y
**destruyó** `inputs/Estandares_VIRF.xlsx`. Usa `ast.parse` o `compileall`, que no
ejecutan nada.

---

## Supuestos de la estimación

- Un desarrollador que ya conoce el proyecto. Con onboarding, suma 2-3 d.
- Incluye tests, actualización de los documentos afectados y suite completa.
- **No** incluye la validación con credencial real de Azure (§14.7 de la guía de
  migración: la comparación de calidad de hallazgos no se puede automatizar).
- **No** incluye tiempo de revisión ni aprobación por terceros.

---

*Elaborado el 30/07/2026 contra VIRF Agent v27.1, y actualizado el mismo día*
*tras ejecutar P0 y los bloques 2-4.*
*Estado actual: `validate_project.py --strict` 131/131 · `pytest` 529 passed.*
*Todos los hallazgos verificados ejecutando; ninguno proviene de un TODO en el código —
no hay ninguno en el árbol activo.*
