#!/usr/bin/env python3
"""
test_api_key.py - Diagnóstico de la conexión con el proveedor de IA ACTIVO.

[SEG-05] Antes instanciaba el SDK de Anthropic directamente (saltándose el
gateway único de `config/ia.py`) e imprimía los primeros 30 caracteres de la
clave. Ahora delega en `config.ia.prueba_de_humo()`, que pasa por el gateway
(PII, lista cerrada de proveedores, auditoría) y no muestra ningún fragmento
de credencial: solo dice si está configurada.
"""

# [CONSOLA-FIX] Debe ejecutarse ANTES del primer print (cp1252 + emoji).
try:
    from modulos.consola import configurar_consola
    configurar_consola()
except ImportError:                       # ejecutado fuera de la raíz del proyecto
    pass

import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")


def main() -> int:
    from config.ia import metadatos_proveedor, prueba_de_humo

    ficha = metadatos_proveedor()
    print("=" * 70)
    print(f"DIAGNÓSTICO DE CONEXIÓN IA — {ficha['nombre']}")
    print("=" * 70)
    res = prueba_de_humo()
    if res.get("ok"):
        print(f"✓ Conexión correcta · modelo {res.get('modelo')} · "
              f"{res.get('latencia_ms')} ms · JSON {'ok' if res.get('json_ok') else 'no'}")
        return 0
    print(f"✗ Falló: {res.get('error')}")
    print("  Revisa: " + ", ".join(ficha["vars_revisar"]))
    return 1


if __name__ == "__main__":
    sys.exit(main())
