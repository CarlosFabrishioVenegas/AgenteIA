# VIRF Agent v27 — Instrucciones para Agentes de IA

## Qué es este proyecto
Agente de **validación de modelos financieros** (LaR, VaR, conductuales) con dos modos:
1. **Conversacional** (v27 — principal): conversa, detecta fórmulas incorrectas y falta de sustento científico. Con `/validar` genera el informe consolidado.
2. **Pipeline batch** (v25/v26 legacy): evaluación automática por control o por ámbito contra `Estandares_VIRF.xlsx`.

Desplegado en **Databricks**. LLM: Claude (Anthropic). Vector store: ChromaDB en DBFS.

---

## Arquitectura — leer en este orden

```
virf_agente.py                  ← Punto de entrada unificado
agent/virf_agent.py             ← Clase VIRFAgent (agente conversacional)
  agent/evaluators/
    formula_detector.py         ← Detección ESTÁTICA sin LLM (regex, 9 patrones)
    methodology_checker.py      ← Solidez metodológica ESTÁTICA (6 patrones)
  agent/skills/
    formula_detection_skill.py  ← Análisis profundo con LLM → JSON estructurado
    methodology_skill.py        ← 5 dimensiones metodológicas con LLM
    consolidator_skill.py       ← Genera informe ejecutivo con /validar
    word_export_skill.py        ← Exporta a .docx
  agent/memory/
    short_term_memory.py        ← Deque RAM (sesión actual)
    long_term_memory.py         ← JSONL disco (entre sesiones)
  agent/reasoning/
    chain_of_thought.py         ← Descomposición de queries complejas
  agent/feedback/
    feedback_store.py           ← Rating 1-5 + lecciones aprendidas
config.py                       ← ÚNICA fuente de config. get_cliente_ia() para pipelines legacy.
motor/Mx_00_CargaRutas.py       ← Rutas y constantes. SIN __init__.py.
modulos/motor_ia.py             ← orquestar_pipeline_virf() + orquestar_pipeline_ambitos()
src/rag/                        ← RAG: LaR | VaR | conductuales | shared
```

---

## Comandos principales

```bash
# MODO CONVERSACIONAL (principal v27)
python virf_agente.py --chat
python virf_agente.py --chat --titulo "Modelo LaR v3" --dominio LaR

# Pipeline + chat al terminar
python virf_agente.py --titulo "Modelo LaR v3" --tier I --chat-post

# Pipelines legacy
python virf_agente.py --titulo "Modelo LaR v3" --tier I --control   # Pipeline 1
python virf_agente.py --titulo "Modelo LaR v3" --tier I --paralelo  # Pipeline 2

# Notebook Databricks
from agent.virf_agent import VIRFAgent
agente = VIRFAgent(titulo_modelo="Modelo LaR v3", dominio="LaR")
agente.chat("¿Esta fórmula de VaR es correcta? VaR = μ + σ*z")
agente.validar()  # Word + JSON

# Rebuild RAG
python scripts/rebuild_rag_databricks.py --dominio all
```

---

## Comandos conversacionales

| Comando | Efecto |
|---------|--------|
| `/validar` | Informe consolidado Word + JSON con todos los hallazgos |
| `/hallazgos` | Lista hallazgos acumulados por gravedad |
| `/cargar` | Recarga docs desde `inputs/` |
| `/titulo Nombre` | Cambia modelo bajo validación |
| `/dominio LaR` | Cambia dominio RAG |
| `/limpiar` | Reinicia conversación (conserva hallazgos) |
| `/reset` | Reinicia todo |

---

## Flujo de detección (dos capas)

```
usuario → formula/código/metodología
  ↓ Capa 1 ESTÁTICA (sin LLM — rápido):
    formula_detector.py + methodology_checker.py → hallazgos por regex
  ↓ Capa 2 LLM (profundo):
    FormulaDetectionSkill + MethodologySkill → JSON con gravedad + referencia
  ↓ Acumulación en VIRFAgent.hallazgos []
  ↓ /validar → ConsolidatorSkill → veredicto (APTO / CON CONDICIONES / NO APTO)
```

---

## Estructura de hallazgo (Dict estándar)

```python
{
    "tipo":        "formula" | "metodologia" | "codigo" | "pipeline",
    "gravedad":    "CRÍTICO" | "ALTO" | "MEDIO" | "BAJO",
    "descripcion": "descripción técnica precisa",
    "correccion":  "cómo corregirlo",
    "referencia":  "Kupiec (1995) / SR 11-7 / BCBS FRTB",
    "fuente":      "formula_detector" | "methodology_checker" | "respuesta_llm",
    "timestamp":   "ISO 8601",
}
```
Salida: `outputs/hallazgos_<modelo>_<fecha>.json` + Word opcional.

---

## Convenciones críticas

- `motor/` NO tiene `__init__.py` — importar via `sys.path.insert`. No agregar `__init__.py`.
- `virf_agent.py` usa `anthropic.Anthropic()` directamente (no `config.get_cliente_ia()`).
- `FormulaDetector` y `MethodologyChecker` NUNCA hacen llamadas API — son la capa barata.
- `ConsolidatorSkill` siempre tiene `_informe_basico()` como fallback sin LLM.
- RAG se inicializa lazy en `VIRFAgent._get_rag_retriever()` — no falla al startup.
- Índices RAG en `/dbfs/FileStore/virf/vectordb/<dominio>/` en Databricks.

---

## Documentos reales → dónde colocarlos

| Tipo | Carpeta | RAG que lo indexa |
|------|---------|-------------------|
| Manuales metodológicos | `inputs/documentacion/modelamiento/` | LaR, VaR, conductuales |
| Backtesting, seguimiento | `inputs/documentacion/seguimiento/` | LaR, VaR |
| Papers regulatorios | `inputs/papers/` | shared + todos |
| Scripts réplica | `inputs/calidad_datos/` | LaR |
| Actas comité | `inputs/usos/` | LaR |
