# Auditoría técnica exhaustiva — VIRF Agent v27

**Alcance:** 51 ficheros Python · 20.288 líneas · 100 % del código de producción
**Periodo:** 27–29 de julio de 2026
**Rol:** QA Lead + Auditor Técnico Senior
**Estado final:** `validate_project.py --strict` **119/119** · `pytest` **289 passed** · exit 0

---

## 1. Resumen ejecutivo

Se auditaron las 20.288 líneas del proyecto en siete fases, con la regla de que ningún
elemento podía marcarse como correcto sin haber leído el código real o ejecutado el caso
real. **Se encontraron y corrigieron 38 defectos**, tres de ellos críticos.

El hallazgo de mayor impacto no es ninguno de los defectos individuales, sino lo que
revelan en conjunto: **el sistema emitía informes de validación sobre el 1,2 % del manual
metodológico** y ninguna prueba lo detectaba, porque la suite ejercitaba módulos aislados y
nunca el producto completo.

| Métrica | Antes | Después |
|---|---:|---:|
| Defectos conocidos | — | **38 corregidos** |
| Tests de regresión | 128 | **289** |
| Checks del validador (coste 0) | 88 | **119** |
| Cobertura documental real en producción | **1,2 %** | **100 %** |
| Líneas auditadas | — | 20.288 / 20.288 |

**Veredicto: apto para producción con dos condiciones** (§7).

---

## 2. Metodología

Siete fases, ejecutadas en orden, sin cerrar ninguna con pendientes:

| Fase | Objeto | Resultado |
|---|---|---|
| 0 | Checklist maestro de ficheros | 51 ficheros inventariados |
| 1 (a–g) | Lectura línea por línea de todo el código | 27 defectos |
| 2 | Ejecución real de los 20 flags y sus combinaciones | 4 defectos (1 crítico) |
| 3 | Matriz de casos límite, incl. fallos de red reales | 1 defecto |
| 4 | Consistencia cruzada, grafo de imports, firmas | 4 defectos |
| 5 | Bugs silenciosos (8 escenarios construidos) | incluidos en fase 1 |
| 6 | Seguridad y distribución | 1 defecto |
| 7 | Cierre y verificación de cobertura | **1 defecto crítico** |

Cada hallazgo se acompaña de: fichero, forma de reproducirlo, corrección aplicada y un test
de regresión que falla si el defecto vuelve. Los invariantes que pueden comprobarse sin
gastar en la API se añadieron además a `validate_project.py`.

**Principio rector:** un caso límite que «probablemente funciona bien» se ejecuta para
confirmarlo. Tres divisiones sin guarda aparente en la fase 7 resultaron ser falsos
positivos precisamente por aplicar esta regla en vez de asumir.

---

## 3. Los dos patrones que explican la mayoría de los defectos

### 3.1. Ausencia de evidencia presentada como resultado negativo — 7 de 38

El error conceptual más caro para un validador de modelos. Con un matiz esencial que la
entidad fijó durante la auditoría: **la falta de evidencia SÍ es una falta crítica** y debe
puntuar 0.0 — el validado tenía la obligación de aportar documentación. Lo inadmisible es
otra cosa:

1. que un **fallo del agente** (timeout, PDF ilegible) se impute al validado, y
2. que el informe **no distinga** una causa de la otra, dejando al lector sin saber si faltó
   documentación o si se cayó la herramienta.

Un dictamen adverso infundado sobre un modelo de riesgo tiene consecuencias regulatorias
directas; uno fundado que no explica su causa, también.

| # | Manifestación | Efecto |
|---|---|---|
| 1 | `calcular_score_global`: `0.0` sin evidencia rotulado «CRÍTICO» a secas | Correcto puntuar 0.0 (política), pero sin declarar la causa |
| 2 | `_normalizar_score(None)` → `1`: un FALLO TÉCNICO se convertía en el peor puntaje | Se acusaba al validado de un fallo del agente |
| 3 | Pipeline de control en ERROR → «resolver fallos» | Fallo técnico presentado como incumplimiento |
| 4 | Lectura de fichero fallida con `cobertura_pct = 100` | Un PDF corrupto entraba como evidencia completa |
| 5 | Observación automática «No cumple» en actividad no evaluada | Texto adverso sin base |
| 6 | `Mx_03.evaluar_dimension`: sin documentos → `estado="No cumple"` | El 0 es correcto por política; «No cumple» atribuye un incumplimiento no comprobado |
| 7 | Cobertura documental inflada (65 %/100 % cuando era 30 %) | Exhaustividad aparente falsa |

Todos guardados por tests. **Es un patrón de pensamiento, no una línea de código: volverá a
aparecer en el próximo módulo si no se vigila explícitamente en las revisiones.**

### 3.2. Diagnóstico destruido por el tipo de retorno

`validar_conexion() -> bool` descartaba el motivo del fallo. El llamante que decidía
*abortar o continuar* buscaba la cadena `"401"` en un mensaje del que ya se había eliminado.
Consecuencia: una clave rechazada se clasificaba como corte de red pasajero.

Misma familia: `.get("score", ev.get("puntaje"))` y `.get("puntaje", 50)` — el segundo
argumento de `.get()` solo actúa cuando la clave **falta**, no cuando existe con valor nulo.

---

## 4. Defectos críticos

### CRÍTICO-1 · El pipeline principal estaba muerto al 100 %

**Fichero:** `agente.py` (rama `--explicar-modelo`, dentro de `main()`)
**Detectado en:** fase 2, al ejecutar `--titulo X --tier 1`

```
❌ Error en pipeline: local variable 'ChunkerService' referenced before assignment
```

**Causa.** Un `from modulos.chunker import ChunkerService` colocado *dentro* de `main()`.
Python marca ese nombre como **local de toda la función**, ensombreciendo el import de
módulo. Al no tomarse esa rama, la instanciación posterior del chunker lo usaba sin asignar.

**Reproducción.** Cualquier invocación del pipeline principal. Fallaba el 100 % de las veces.

**Agravante.** El mensaje culpaba al chunker, no al import: el diagnóstico apuntaba al
lugar equivocado.

**Corrección.** Eliminado el import local. Se añadió un test que detecta la **clase** de
fallo —cualquier import local que repita un nombre ya importado a nivel de módulo, en
`agente.py`, `modulos/`, `motor/` y `config/`— y dos checks en el validador.

**Nota de honestidad.** Este defecto lo introdujo el propio trabajo previo de esta auditoría
al añadir el explicador de modelos. Ni los 237 tests ni los 108 checks de entonces lo vieron.

---

### CRÍTICO-2 · Los informes se emitían sobre el 1,2 % del manual

**Ficheros:** `motor/Mx_01_LecturaEvidencias.py` (rama del caché) y `modulos/document_cache.py`
**Detectado en:** fase 7, en la corrida de verificación final

Misma orden, misma configuración, mismo documento:

```
sin caché → 40 segmentos, cobertura 100,0 %
con caché →  2 segmentos, cobertura   1,2 %
```

**Causa.** El `TRUNCADO-FIX` de la auditoría del 26 de julio estaba **aplicado a medias**.
Corrigió la lectura directa —entregar el texto íntegro al `ChunkerService`, que es quien
debe decidir cómo cubrirlo— pero dejó la rama del caché pidiendo `max_chars=15.000`. El
caché guardaba 15.000 caracteres declarando `chars_totales = 1.302.266`.

**Impacto real.** El caché está activo en casi todas las corridas. Todo el trabajo de
chunking adaptativo y consolidación jerárquica (proyecto D2) **no servía de nada en la
práctica**, porque el documento nunca le llegaba entero. Cada validación de pre-producción
desde el 26 de julio se emitió sobre el 1,2 % del manual metodológico.

**Reproducción.**
```
len(entrada["contenido"])       = 15.000
entrada["chars_totales"]        = 1.302.266
entrada["truncado"]             = True
```

**Corrección.** `Mx_01` decide el tope con el mismo criterio que la lectura directa
(`_max_cache = None if _chunk_on else max_c`) y `DocumentCache` acepta `max_chars=None`
como «sin tope». Verificado: **1,2 % → 100 % con el caché activo**. Se añadieron cinco tests
y dos checks, uno de los cuales detecta entradas de caché que declaran más caracteres de los
que guardan.

**Lección.** La auditoría previa dio este fix por cerrado sin ejecutar la ruta que se toma
por defecto.

---

### CRÍTICO-3 · Las dos causas de «sin nota» estaban fundidas en una

**Ficheros:** `modulos/motor_ia.py` (`calcular_score_ambito`, `calcular_score_global`,
`get_semaforo`) y `modulos/generador_word.py`

El sistema usaba un único `None` para dos situaciones con **responsables opuestos**, y las
trataba igual:

| Causa | Responsable | Tratamiento correcto |
|---|---|---|
| **Sin evidencia** — no se aportó documentación | El validado | **0.0**, falta crítica, penaliza con su peso íntegro |
| **Fallo técnico** — timeout, PDF ilegible, JSON roto | El agente | Excluido del score, se renormaliza, se reporta aparte |

**Defecto.** Con evidencia cero, `calcular_score_global` devolvía `0.0` y el semáforo lo
traducía a **«CRÍTICO»** sin decir por qué. Un lector concluía que el modelo era deficiente
cuando el hecho era que nadie había aportado documentos — y con la misma etiqueta con la que
un fallo de nuestra red condenaba al validado.

**Primera corrección, equivocada.** Se hizo devolver `None` y excluir el ámbito del promedio,
renormalizando los pesos. Eso resolvía la atribución injusta pero **invertía la política de
la entidad**: un ámbito sin un solo documento dejaba de penalizar. Medido sobre la corrida
real, Gobierno (peso 0.12) sin evidencia daba **3.02** en vez de **2.66**. No aportar
documentación salía gratis.

**Corrección definitiva.** Se separan las dos causas en todo el recorrido —score de ámbito,
score global, semáforo, etiquetas del Word y texto de la observación automática—:

- **Sin evidencia → `0.0`**, dentro del promedio con su peso completo. Semáforo
  «NO EVALUABLE — SIN EVIDENCIA» en **rojo**: se nombra la causa, pero conserva la severidad
  crítica que la política le asigna.
- **Fallo técnico → `None`**, excluido y renormalizado. Semáforo «NO EVALUABLE — FALLO
  TÉCNICO» en gris, con la indicación de re-ejecutar antes de dictaminar.
- Si una evaluación llega con ambas marcas, **prevalece la no imputable**: no se acusa al
  validado ante la duda.

**Propiedad que hace el diseño robusto.** La escala de puntuación es 1–5, de modo que un
promedio de actividades realmente evaluadas nunca puede dar 0.0. Por tanto **score 0.0 ⟺ sin
evidencia**, y el semáforo puede rotularlo por su causa sin recibir ningún parámetro extra.
Un test fija esa invariante contra futuros cambios de escala.

**Nota de método.** Este defecto se corrigió dos veces porque la primera corrección aplicó un
criterio técnico razonable —no dictaminar sobre el vacío— donde la entidad tiene una política
explícita en sentido contrario. **La regla de negocio manda sobre la intuición del auditor;
lo que no puede admitirse es que las dos causas compartan representación.**

---

## 5. Defectos por fase

### Fase 1 — Lectura línea por línea (27 defectos)

Ámbitos principales, con su clase de test de regresión:

| Área | Defecto | Test |
|---|---|---|
| Puntuación | Score 0.00 = CRÍTICO sin evidencia | `SinEvidenciaNoEsDictamen` |
| Cobertura | Media simple, métrica cruzada y máximo en tres módulos distintos; ninguno erraba con excepción, todos inflaban la cifra que el auditor lee como exhaustividad | `CoberturaDocumentalNoSeInfla`, `CoberturaDocumentalVsPrompt`, `CoberturaDeControlNoUsaMaximo` |
| Lectura | Los 11 lectores devolvían su mensaje de error **como contenido**, con cobertura 100 % | `LecturaFallidaNoEsCoberturaTotal` |
| Excel | `df.head(150)` recortaba en silencio; 200 filas de 10.000 con `truncado=False` | (incluido en el anterior) |
| Informe Word | `_normalizar_score` colapsaba el rango (5, 12] hacia 1; `_es_error` borraba hallazgos legítimos que mencionaban «API» o «error» | `InformeWordNoDeformaLosDatos` |
| Feedback | Historial sin lock: 77 % de pérdida y 6/6 ficheros corruptos con escritura concurrente | `HistorialFeedbackEsDurable` |
| Caché | Resúmenes sin lock entre procesos | `CacheDeResumenesBajoLock` |
| Control | Hallazgos no críticos no penalizaban: 50 moderados = cumplimiento pleno | `ScoreDeControlCuentaTodosLosHallazgos` |
| Seguridad | Nombres de salida sin sanear (path traversal) | `PathTraversalEnSalidas` |
| Arranque | `int(os.getenv(...))` sin guarda: un typo en `.env` tumbaba el arranque con un traceback dentro de un import | `EnvMalformadoNoTumbaElArranque` |
| Anti-sesgo | Dos umbrales incoherentes: la intervención más directa sobre el dictamen tenía el guardia más débil | `UmbralAntisesgoUnificado` |

**Concurrencia verificada con procesos reales:** `document_cache` pasó ambas pruebas sin
cambios (60/60 entradas, 0/6 corruptos). `historial_feedback.json` falló catastróficamente
y, tras la corrección, pasó a 80/80 y 0/6.

### Fase 2 — Ejecución de los 20 flags (4 defectos)

| # | Defecto | Gravedad |
|---|---|---|
| 28 | Pipeline principal muerto (CRÍTICO-1) | Crítico |
| 29 | `--tier 9` y `--tier abc` no se validaban: el parser buscaba una columna `TIER_9` inexistente, **desactivaba el filtro por tier**, evaluaba 21 actividades en vez de 11, facturaba la API completa y rotulaba el informe «Tier: 9» | Alto |
| 30 | `--limpiar-cache` informaba «16 entradas eliminadas» con el fichero intacto. Las **tres** rutas de borrado eran no-ops: el merge del `CONCURRENCIA-FIX` releía el disco y resucitaba todo | Alto |
| 31 | El resumen final se contradecía: «evaluadas OK: 19» sobre «totales: 15» | Medio |

El #31 merece precisión: **el score era correcto.** Las 4 de diferencia son controles CDD
que se integran en el ámbito Calidad de datos y sí pesan (2, 1, 5, 5, 5 → 3,60, el valor
publicado). Fallaba el contador, no el cálculo.

De paso se unificó el catálogo de tiers: `Mx_01` mantenía un `_TIER_MAP` paralelo al de
`config.dominio`.

### Fase 3 — Casos límite y fallos de red (1 defecto)

Probado contra la API real con una clave inválida y contra un host no enrutable
(`ANTHROPIC_BASE_URL=http://10.255.255.1:81`), no con simulaciones.

**Defecto 32 (alto).** Una clave rechazada se tomaba por un corte de red pasajero (§3.2). La
corrida continuaba, cargaba toda la evidencia y moría 300 líneas después con dos tracebacks
encadenados. Corregido en tres niveles: el cliente conserva el motivo, `get_cliente_ia`
propaga con `from e`, y el PRE-FLIGHT recorre la cadena de causas. Ahora aborta en dos
segundos con un mensaje accionable.

Se eliminó además la política «error de red → advertir y continuar»: los modos que funcionan
sin API ya están exceptuados del PRE-FLIGHT, de modo que continuar solo aplazaba el fallo.
Verificado que `--cache-stats`, `--listar-motores`, `--estadisticafeedback`,
`--explicar-modelo --dry-run` y `--convertir-excel --sin-llm` siguen operando sin red.

**El cliente de Azure era mudo:** `except Exception: return False`, sin siquiera el aviso que
sí tenía el de Anthropic. Un usuario de Azure con la clave mal configurada no veía nada.

**Verificado sin defecto:** un corte a mitad de corrida marca `puntaje=None` y
`evaluacion_valida=False`, el ámbito da `None` (no 0.0) y el bloque de integridad lo cuenta
como fallo técnico con detalle. La cadena D3-FIX/CONTRATO-FIX aguanta.

### Fase 4 — Consistencia cruzada (4 defectos)

| # | Defecto | Gravedad |
|---|---|---|
| 33 | Dos rutas distintas para la base vectorial. `src/rag/base_indexer._get_vectordb_base()` encadenaba **cuatro** `.parent` (rag → src → raíz → *padre de la raíz*): el índice se escribía fuera del proyecto mientras `config.VECTORDB_DIR` apuntaba dentro. Como el retriever devuelve `[]` en silencio ante un índice ausente, **el RAG parecía activo y nunca aportaba contexto** | Alto |
| 34 | `RAG_TOP_K`, `RAG_MIN_SCORE` y `RAG_VECTORDB_DIR` llevaban tiempo en `.env.example` sin que una sola línea las leyera. Los valores vivían hardcodeados y coincidían por casualidad: tocarlas no producía efecto **ni aviso** | Medio |
| 35 | 14 variables de entorno reales sin documentar, entre ellas los umbrales anti-sesgo y los parámetros que gobiernan el coste del chunking | Medio |
| 36 | `Mx_03.evaluar_dimension`: sin documentos → `score=0` → peor puntaje (§3.1) | Medio |

`_num_env` ganó tope superior: `RAG_MIN_SCORE=5` no es «más estricto», filtra *todos* los
chunks y deja el RAG mudo.

**Verificado sin defecto:** 0 ciclos de import (51 módulos, 93 aristas) y 225 funciones sin
un solo desajuste entre firma y llamantes.

### Fase 6 — Seguridad y distribución (1 defecto)

**Defecto 37 (alto).** `.claude/settings.local.json` registra cada comando aprobado **tal
cual se escribió** y no estaba en `.gitignore`. Se detectó porque una prueba de la fase 3
quedó allí en claro con su clave en línea (falsa a propósito, pero el mecanismo es idéntico
para una real).

**Verificado sin defecto:**
- Los **26 informes `.docx` no filtran ni una ruta absoluta**. Es lo que sale de la
  organización y no revela usuario ni estructura de carpetas.
- La clave no viaja al JSON de resultados. Los 6 sitios que la mencionan imprimen booleanos,
  longitudes o un sufijo corto.
- 30 dependencias, **todas con versión restringida**: sin esto la corrida deja de ser
  reproducible y el informe no es auditable.

### Fase 7 — Cierre (1 defecto crítico)

CRÍTICO-2 (§4). Además se cerraron los tres pendientes anotados en fases anteriores:

- **`datetime.utcnow()`** (4 usos): obsoleto desde Python 3.12 y devuelve un *naive* al que
  se le añadía una «Z». Corregido a `datetime.now(timezone.utc)`. Afectaba a la trazabilidad
  del informe.
- **`resultado['clave']`**: **no era un problema.** Son escrituras; el caso señalado estaba
  dentro de un docstring.
- **Unificar los cálculos de cobertura**: revisado y **descartado deliberadamente.** Miden
  magnitudes distintas —cobertura documental, cobertura de contexto del prompt y su
  agregado— y la corrida ya las declara por separado. Forzar una función común las
  confundiría, que es exactamente el defecto original. Los tres cálculos concretos que
  estaban mal se corrigieron en su fase.

---

## 6. Verificación final

Corrida real de extremo a extremo, `--titulo VeredictoFinal --tier 1 --prdc`, con caché
activo y todos los cambios aplicados:

```
✅ 'Manual_Metodologico_LaR_completo.pdf': 40 segmentos [jerárquico] — cobertura 100,0 %

🔎 INTEGRIDAD DE LA EVALUACIÓN
   • Actividades evaluadas OK : 19    • Sin evidencia: 0    • Fallos técnicos: 0
   • Actividades totales: 15 del estándar + 4 controles CDD = 19 evaluaciones
   • Score global: 2.85/5.0  [CON OBSERVACIONES]
   • JSON + Word emitidos     generado_utc: 2026-07-29T08:37:14Z
```

Las tres cifras que antes se contradecían cuadran, la cobertura es real y el sello temporal
es correcto.

| Puerta | Resultado |
|---|---|
| `python validate_project.py --strict` | **119/119 PASS · 0 WARN · 0 FAIL · exit 0** |
| `python -m pytest` | **289 passed** |
| Corrida de producción real | JSON + Word emitidos, cobertura 100 % |

---

## 7. Veredicto de producción

> **APTO PARA PRODUCCIÓN, con dos condiciones.**

Lo sostienen: una corrida real de extremo a extremo con cobertura documental del 100 %,
279 tests, 117 checks de coste cero y los dos patrones dominantes bloqueados por tests *y*
por el validador.

### Condición 1 — ejecutar `--limpiar-cache` antes de la primera validación real

**No es opcional.** Cualquier caché anterior al 29/07/2026 contiene documentos recortados a
15.000 caracteres que se sirven declarando el tamaño completo. El validador ya detecta esas
entradas, pero el caché en disco de una instalación existente no se purga solo.

### Condición 2 — tratar cualquier `--strict` en rojo como bloqueante

Los 117 checks cuestan cero y cubren invariantes que costaron dinero descubrir. El defecto
crítico de la fase 2 habría salido en dos segundos.

---

## 8. Riesgos residuales y recomendaciones

1. **El patrón «ausencia → resultado negativo» es cultural, no técnico.** Está guardado en
   siete puntos, pero reaparecerá en el próximo módulo. Recomendación: incorporarlo como
   pregunta explícita en la revisión de código — *¿qué publica esta función cuando no hay
   nada que evaluar?*

2. **La suite probaba piezas, no el producto.** El defecto crítico que dejó el pipeline
   muerto no lo vio ninguno de los 237 tests de entonces porque todos ejercitaban módulos
   aislados. Recomendación: mantener corridas reales de extremo a extremo en el ciclo, no
   solo pruebas unitarias.

3. **`Mx_03.evaluar_dimension()` es código muerto.** Se corrigió en lugar de eliminarse:
   borrar una función pública de un módulo vivo es una decisión del proyecto. Conviene
   decidir si se retira.

4. **Dos decisiones tomadas en esta auditoría, reversibles:**
   - Se desacopló `--prdc` del caché. El hash SHA-256 ya garantiza la frescura; desactivarlo
     solo pagaba ~1,45 USD de más por entregable. Fue ese cambio el que destapó el
     CRÍTICO-2.
   - Se corrigió en vez de borrar `evaluar_dimension()` (punto 3).

5. **Cuatro de los 38 defectos se introdujeron durante esta misma auditoría**, incluido el
   CRÍTICO-1. Es la razón por la que la fase de ejecución real existe y debe conservarse.

6. **El check de `config.py` duplicado demostró su valor en esta misma auditoría.** El
   fichero monolítico reapareció en la raíz el 29/07 a las 09:00 por un error de manejo.
   El paquete `config/` lo ensombrece, así que estaba **muerto**: quien lo hubiera editado
   creyendo ajustar la configuración no habría cambiado nada, sin ningún aviso. Lo
   detectaron simultáneamente el check del validador y dos tests. Se verificó que era
   byte a byte idéntico a `archivo/config_monolitico_2026-07-27/config.py` antes de
   eliminarlo, de modo que no se perdió nada.

   **Recomendación:** conservar ese check. Es el tipo de defecto que no produce ningún
   síntoma hasta que alguien pierde una tarde editando un fichero inerte.

---

## 9. Trazabilidad

Cada defecto tiene:

- un comentario `[AUDIT-FIX]` en el punto de la corrección, explicando **qué hacía antes,
  por qué estaba mal y cómo se midió**;
- una clase de test en `tests/test_regresion.py` (32 clases `TestAuditoria*`) que falla si
  el defecto vuelve;
- cuando el invariante puede comprobarse sin gastar en la API, un check en
  `validate_project.py` (bloque 14, «INVARIANTES DE LA AUDITORÍA»).

**Ficheros con correcciones trazadas:** 21 de 25 ficheros de producción. Los 4 restantes y
los 22 auxiliares se revisaron sin encontrar defectos; ese veredicto se sometió en la fase 7
a un barrido dirigido de los dos patrones dominantes, que devolvió tres falsos positivos y
ningún defecto real.
