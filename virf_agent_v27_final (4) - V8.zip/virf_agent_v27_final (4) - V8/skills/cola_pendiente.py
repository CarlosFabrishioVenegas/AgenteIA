"""
skills/cola_pendiente.py  —  Cola PENDIENTE (Human-in-the-loop)
═════════════════════════════════════════════════════════════════════════════
Antipatrón «Exceso de Agencia» (guía §5.1): el agente NUNCA ejecuta directamente
una acción de impacto externo (enviar un correo de resultados, marcar un modelo
como aprobado para producción). Toda acción de impacto se ENCOLA en estado
`PENDIENTE` y espera la confirmación de un validador senior.

Este módulo SOLO sabe encolar y listar. No expone ninguna función que ejecute la
acción: esa decisión es humana, fuera de este código. Persistencia JSON en
`web/data/pendientes.json` (sin dependencias nuevas).
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

__all__ = ["AccionPendiente", "ACCIONES_DE_IMPACTO", "encolar_accion",
           "listar_pendientes", "ruta_cola_por_defecto"]

# Tipos de acción cuyo impacto es EXTERNO e irreversible: nunca se ejecutan solas.
ACCIONES_DE_IMPACTO = frozenset({
    "enviar_correo",
    "aprobar_produccion",
    "publicar_informe",
    "notificar_comite",
})


def ruta_cola_por_defecto() -> Path:
    """`web/data/pendientes.json` bajo la raíz del proyecto."""
    return Path(__file__).resolve().parents[1] / "web" / "data" / "pendientes.json"


class AccionPendiente(BaseModel):
    """Una acción de impacto externo, encolada a la espera de confirmación humana."""

    model_config = ConfigDict(extra="forbid")

    id: str
    tipo: str
    descripcion: str
    payload: Dict[str, Any] = Field(default_factory=dict)
    model_id: Optional[str] = None
    estado: str = Field(default="PENDIENTE")
    creada_en: str = ""

    @field_validator("estado")
    @classmethod
    def _estado_valido(cls, v: str) -> str:
        if v not in ("PENDIENTE", "CONFIRMADA", "RECHAZADA"):
            raise ValueError("estado debe ser PENDIENTE|CONFIRMADA|RECHAZADA")
        return v


def _leer(ruta: Path) -> List[dict]:
    if not ruta.exists():
        return []
    try:
        datos = json.loads(ruta.read_text(encoding="utf-8"))
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def _escribir(ruta: Path, filas: List[dict]) -> None:
    ruta.parent.mkdir(parents=True, exist_ok=True)
    ruta.write_text(json.dumps(filas, ensure_ascii=False, indent=2), encoding="utf-8")


def encolar_accion(tipo: str, descripcion: str,
                   payload: Optional[Dict[str, Any]] = None,
                   model_id: Optional[str] = None,
                   ruta: Optional[Path] = None) -> AccionPendiente:
    """
    Registra una acción de impacto en la cola `PENDIENTE`. NO la ejecuta.

    Devuelve el registro creado (siempre en estado `PENDIENTE`). Un validador
    senior lo confirma o rechaza fuera de este código.
    """
    ruta = ruta or ruta_cola_por_defecto()
    accion = AccionPendiente(
        id=uuid.uuid4().hex,
        tipo=tipo,
        descripcion=descripcion,
        payload=payload or {},
        model_id=model_id,
        estado="PENDIENTE",
        creada_en=datetime.now(timezone.utc).isoformat(timespec="seconds"),
    )
    filas = _leer(ruta)
    filas.append(accion.model_dump())
    _escribir(ruta, filas)
    return accion


def listar_pendientes(ruta: Optional[Path] = None,
                      solo_pendientes: bool = True) -> List[AccionPendiente]:
    """Lee la cola. Por defecto solo las que siguen en estado `PENDIENTE`."""
    ruta = ruta or ruta_cola_por_defecto()
    filas = _leer(ruta)
    acciones = [AccionPendiente.model_validate(f) for f in filas]
    if solo_pendientes:
        acciones = [a for a in acciones if a.estado == "PENDIENTE"]
    return acciones
