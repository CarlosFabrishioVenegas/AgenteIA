"""
skills/calidad_datos.py  —  Skill 2 (Calidad de Datos), determinista, en sandbox
═════════════════════════════════════════════════════════════════════════════
Única de las 6 skills puramente DETERMINISTA: no llama al modelo. Ingiere un
dataset y devuelve JSON estructurado con outliers (IQR), nulos en variables
clave, duplicados exactos y solapamiento train/test (data leakage).

SANDBOX (guía §2/§4.B): el agente NO calcula a mano. La skill invoca el cálculo
como un SUBPROCESO aislado —`python -m skills.calidad_datos <csv>`— y procesa el
JSON de vuelta. `run_data_quality_check(...)` es la función pura (para test y para
el subproceso); `SkillCalidadDatos.ejecutar(...)` es la vía por subprocess.

Sin dependencias nuevas: pandas y numpy ya están en requirements.txt.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from pydantic import BaseModel, ConfigDict, Field

from skills.base_tipada import SkillTipada

__all__ = ["DataLeakageResult", "DataQualityResult", "run_data_quality_check",
           "SkillCalidadDatos"]


# ── Salida tipada ────────────────────────────────────────────────────────────

class DataLeakageResult(BaseModel):
    model_config = ConfigDict(extra="forbid")
    evaluado: bool = Field(description="True si se pidió chequeo con columna de split.")
    columna_split: Optional[str] = None
    filas_solapadas: int = Field(
        default=0, description="Filas de features idénticas presentes en train Y test.")
    detalle: str = ""


class DataQualityResult(BaseModel):
    """Reporte determinista de calidad de datos de un dataset."""

    model_config = ConfigDict(extra="forbid")

    csv_path: str
    n_filas: int
    n_columnas: int
    missing_values: Dict[str, int] = Field(
        description="Nulos por columna (todas las columnas).")
    missing_en_variables_clave: Dict[str, int] = Field(
        default_factory=dict,
        description="Nulos solo en las variables clave declaradas.")
    duplicates: int = Field(description="Nº de filas duplicadas EXACTAS (extra sobre la 1ª).")
    outliers_count: Dict[str, int] = Field(
        description="Outliers por columna numérica (regla IQR 1.5).")
    outliers_total: int
    data_leakage: DataLeakageResult


# ── Cálculo determinista (función pura) ──────────────────────────────────────

def _outliers_iqr(serie: pd.Series) -> int:
    """Nº de valores fuera de [q1 - 1.5·IQR, q3 + 1.5·IQR]. Determinista."""
    s = serie.dropna()
    if s.empty:
        return 0
    q1 = s.quantile(0.25)
    q3 = s.quantile(0.75)
    iqr = q3 - q1
    if iqr == 0:
        return 0
    bajo = q1 - 1.5 * iqr
    alto = q3 + 1.5 * iqr
    return int(((s < bajo) | (s > alto)).sum())


def run_data_quality_check(
    csv_path: str,
    key_columns: Optional[List[str]] = None,
    split_column: Optional[str] = None,
) -> DataQualityResult:
    """
    Analiza `csv_path` y devuelve un `DataQualityResult`. Cálculo 100% determinista.

    Args:
        csv_path:     ruta al CSV.
        key_columns:  variables clave donde un nulo es especialmente grave.
        split_column: columna que separa train/test; si se da, evalúa data leakage
                      (filas de features idénticas presentes en ambos conjuntos).
    """
    df = pd.read_csv(csv_path)

    missing = {c: int(df[c].isnull().sum()) for c in df.columns}
    key_columns = key_columns or []
    missing_clave = {c: int(df[c].isnull().sum()) for c in key_columns if c in df.columns}

    duplicates = int(df.duplicated().sum())

    numericas = df.select_dtypes(include=[np.number]).columns
    outliers = {c: _outliers_iqr(df[c]) for c in numericas}
    outliers = {c: n for c, n in outliers.items() if n > 0}
    outliers_total = int(sum(outliers.values()))

    leakage = _evaluar_leakage(df, split_column)

    return DataQualityResult(
        csv_path=csv_path,
        n_filas=int(len(df)),
        n_columnas=int(df.shape[1]),
        missing_values=missing,
        missing_en_variables_clave=missing_clave,
        duplicates=duplicates,
        outliers_count=outliers,
        outliers_total=outliers_total,
        data_leakage=leakage,
    )


def _evaluar_leakage(df: pd.DataFrame, split_column: Optional[str]) -> DataLeakageResult:
    if not split_column or split_column not in df.columns:
        return DataLeakageResult(
            evaluado=False, columna_split=None, filas_solapadas=0,
            detalle="No se declaró columna de split; leakage no evaluado.")
    valores = df[split_column].dropna().unique().tolist()
    if len(valores) < 2:
        return DataLeakageResult(
            evaluado=False, columna_split=split_column, filas_solapadas=0,
            detalle="La columna de split no separa en al menos 2 grupos.")
    # Toma los dos primeros grupos como train/test y cuenta filas de FEATURES
    # (todo menos la columna de split) idénticas presentes en ambos.
    feats = [c for c in df.columns if c != split_column]
    g0 = df[df[split_column] == valores[0]][feats]
    g1 = df[df[split_column] == valores[1]][feats]
    claves0 = set(map(tuple, g0.itertuples(index=False, name=None)))
    solape = sum(1 for row in g1.itertuples(index=False, name=None) if tuple(row) in claves0)
    return DataLeakageResult(
        evaluado=True, columna_split=split_column, filas_solapadas=int(solape),
        detalle=(f"{solape} fila(s) de features idénticas aparecen en '{valores[0]}' "
                 f"y '{valores[1]}' — posible contaminación train/test."))


# ── Skill declarada para function calling (vía sandbox) ──────────────────────

class SkillCalidadDatos(SkillTipada):
    """Skill 2 de la guía: Data Quality Guard (determinista, en sandbox)."""

    nombre = "run_data_quality_check"
    titulo = "Calidad de Datos (Data Quality Guard)"
    descripcion = ("Ingiere un dataset y devuelve outliers, nulos en variables "
                   "clave, duplicados y solapamiento train/test (data leakage), "
                   "por cálculo determinista en sandbox.")
    parametros_schema = {
        "type": "object",
        "properties": {
            "csv_path": {"type": "string",
                         "description": "Ruta al dataset CSV a analizar."},
            "key_columns": {"type": "array", "items": {"type": "string"},
                            "description": "Variables clave donde un nulo es crítico."},
            "split_column": {"type": "string",
                             "description": "Columna que separa train/test (para leakage)."},
        },
        "required": ["csv_path"],
    }
    ambito_estandar = "Calidad de datos"
    rubro_ids = ("outliers_zscore", "imputation_mean", "train_test_split_random",
                 "look_ahead_bias", "data_leakage_escalado", "sin_psi")
    terminos_alcance = ("outlier", "nulo", "missing", "duplicad", "dataset", "csv",
                        "leakage", "fuga", "calidad de dato", "dato")
    fronteras_fuera_alcance = ("comité", "aprobación", "tier", "gobierno",
                               "fórmula metodológica", "correo", "email", "acta")
    operativa = True

    def ejecutar(self, csv_path: str, key_columns: Optional[List[str]] = None,
                 split_column: Optional[str] = None) -> DataQualityResult:
        """Ejecuta el cálculo en un SUBPROCESO aislado y parsea su JSON."""
        return _ejecutar_en_sandbox(csv_path, key_columns, split_column)


def _ejecutar_en_sandbox(csv_path: str, key_columns: Optional[List[str]],
                         split_column: Optional[str]) -> DataQualityResult:
    import os
    cmd = [sys.executable, "-m", "skills.calidad_datos", csv_path]
    if key_columns:
        cmd += ["--key-columns", ",".join(key_columns)]
    if split_column:
        cmd += ["--split-column", split_column]
    # cwd = raíz del proyecto para que `-m skills.calidad_datos` resuelva el paquete.
    raiz = str(Path(__file__).resolve().parents[1])
    salida = subprocess.run(cmd, capture_output=True, text=True, timeout=120,
                            cwd=raiz, encoding="utf-8",
                            env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    if salida.returncode != 0:
        raise RuntimeError(
            f"sandbox calidad_datos falló (rc={salida.returncode}): {salida.stderr.strip()}")
    return DataQualityResult.model_validate(json.loads(salida.stdout))


# ── Entrypoint del sandbox: python -m skills.calidad_datos <csv> [...] ───────

def _main(argv: List[str]) -> int:
    import argparse
    p = argparse.ArgumentParser(description="Data Quality Guard (determinista).")
    p.add_argument("csv_path")
    p.add_argument("--key-columns", default="")
    p.add_argument("--split-column", default="")
    args = p.parse_args(argv)
    key_cols = [c for c in args.key_columns.split(",") if c] or None
    split = args.split_column or None
    resultado = run_data_quality_check(args.csv_path, key_cols, split)
    sys.stdout.write(resultado.model_dump_json())
    return 0


if __name__ == "__main__":
    raise SystemExit(_main(sys.argv[1:]))
