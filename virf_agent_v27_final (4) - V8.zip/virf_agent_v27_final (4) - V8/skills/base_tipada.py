"""
skills/base_tipada.py  —  Contrato base tipado de una skill (function calling)
═════════════════════════════════════════════════════════════════════════════
Cada skill de la guía es una HERRAMIENTA declarada para function calling:
    · entrada/salida tipada con Pydantic,
    · un método `declaracion_herramienta()` que emite el JSON Schema de parámetros,
    · un ALCANCE DE REVISIÓN DECLARADO — qué rubro le pertenece (por ID, resuelto
      desde la config VERSIONADA, no hardcodeado) y qué queda FUERA de su frontera,
    · comportamiento fuera de alcance: se abstiene o deriva (nunca opina sobre el
      dominio de otra skill).

POR QUÉ EL RUBRO SE RESUELVE DESDE CONFIG Y NO SE HARDCODEA
──────────────────────────────────────────────────────────
Los criterios que una skill revisa cambian con el estándar. Si se copiaran como
texto en el código, cada cambio del estándar dejaría al validador midiendo con
una vara vieja. Por eso la skill solo declara PUNTEROS (IDs de cuestionamiento y
el ámbito del estándar); el contenido se carga en `resolver_rubro()` desde
`modulos.cuestionamientos_ext.catalogo_activo()` (que respeta `activos`/versionado)
y, para los ámbitos cuyo detalle vive en `Estandares_VIRF.xlsx`, se deja el
puntero de ámbito para que el coordinador lo resuelva contra el estándar parseado.
"""

from __future__ import annotations

from abc import ABC
from typing import Any, ClassVar, Dict, List, Optional, Tuple

from pydantic import BaseModel, ConfigDict, Field, field_validator

__all__ = [
    "DeclaracionHerramienta", "AlcanceRubro", "ResultadoAlcance", "SkillTipada",
]


# ── Modelos tipados del contrato ─────────────────────────────────────────────

class DeclaracionHerramienta(BaseModel):
    """Declaración de una herramienta para function calling (formato OpenAI/Azure)."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1)
    description: str = Field(min_length=1)
    parameters: Dict[str, Any] = Field(
        description="JSON Schema de los parámetros (type=object, properties, required).")

    @field_validator("parameters")
    @classmethod
    def _schema_valido(cls, v: Dict[str, Any]) -> Dict[str, Any]:
        if v.get("type") != "object":
            raise ValueError("parameters.type debe ser 'object'")
        if not isinstance(v.get("properties"), dict):
            raise ValueError("parameters.properties debe ser un objeto")
        return v


class AlcanceRubro(BaseModel):
    """Alcance de revisión resuelto de una skill: qué rubro le pertenece."""

    model_config = ConfigDict(extra="forbid")

    ambito_estandar: Optional[str] = Field(
        default=None,
        description="Ámbito del estándar (Estandares_VIRF.xlsx) que le pertenece.")
    cuestionamiento_ids: List[str] = Field(default_factory=list)
    cuestionamientos_resueltos: Dict[str, Any] = Field(
        default_factory=dict,
        description="Criterios cargados desde la config versionada (id → definición).")
    fronteras_fuera_alcance: List[str] = Field(default_factory=list)


class ResultadoAlcance(BaseModel):
    """Decisión determinista de si una consulta cae dentro de la frontera de la skill."""

    model_config = ConfigDict(extra="forbid")

    en_alcance: bool
    accion: str = Field(description="PROCEDER | ABSTENERSE | DERIVAR")
    motivo: str
    derivar_a: Optional[str] = None

    @field_validator("accion")
    @classmethod
    def _accion_valida(cls, v: str) -> str:
        if v not in ("PROCEDER", "ABSTENERSE", "DERIVAR"):
            raise ValueError("accion debe ser PROCEDER|ABSTENERSE|DERIVAR")
        return v


# ── Base abstracta ───────────────────────────────────────────────────────────

class SkillTipada(ABC):
    """
    Base de las 6 skills tipadas.

    Una subclase declara, como atributos de clase:
        nombre                  nombre de la herramienta (function calling)
        titulo, descripcion     texto legible
        parametros_schema       JSON Schema de parámetros de la herramienta
        ambito_estandar         ámbito del estándar que revisa (puntero)
        rubro_ids               IDs de cuestionamiento que le pertenecen (punteros)
        terminos_alcance        palabras que marcan que una consulta es SUYA
        fronteras_fuera_alcance temas de OTRO dominio ante los que se deriva
        operativa               True solo si está implementada y probada

    NO hardcodees los criterios: declara IDs; `resolver_rubro()` los carga de config.
    """

    nombre: ClassVar[str] = "base"
    titulo: ClassVar[str] = "Skill tipada base"
    descripcion: ClassVar[str] = ""
    parametros_schema: ClassVar[Dict[str, Any]] = {
        "type": "object", "properties": {}, "required": [],
    }
    ambito_estandar: ClassVar[Optional[str]] = None
    rubro_ids: ClassVar[Tuple[str, ...]] = ()
    terminos_alcance: ClassVar[Tuple[str, ...]] = ()
    fronteras_fuera_alcance: ClassVar[Tuple[str, ...]] = ()
    operativa: ClassVar[bool] = False

    # ── Declaración de herramienta (function calling) ────────────────────────
    def declaracion_herramienta(self) -> DeclaracionHerramienta:
        """JSON Schema de la herramienta, validado. API-free."""
        return DeclaracionHerramienta(
            name=self.nombre,
            description=self.descripcion or self.titulo,
            parameters=dict(self.parametros_schema),
        )

    # ── Alcance de revisión declarado (resuelto desde config versionada) ─────
    def resolver_rubro(self) -> AlcanceRubro:
        """
        Carga el rubro de esta skill DESDE la config versionada (no hardcode).

        Los `rubro_ids` se resuelven contra `catalogo_activo()`, que ya filtra por
        `config/cuestionamientos_activos.json` y añade los personalizados. Un ID
        desactivado simplemente no aparece — respeta el versionado/`is_active`.
        """
        from modulos.cuestionamientos_ext import catalogo_activo
        catalogo, _avisos = catalogo_activo()
        resueltos = {cid: catalogo[cid] for cid in self.rubro_ids if cid in catalogo}
        return AlcanceRubro(
            ambito_estandar=self.ambito_estandar,
            cuestionamiento_ids=list(self.rubro_ids),
            cuestionamientos_resueltos=resueltos,
            fronteras_fuera_alcance=list(self.fronteras_fuera_alcance),
        )

    # ── Comportamiento fuera de alcance: se abstiene o deriva ────────────────
    def evaluar_alcance(self, consulta: str) -> ResultadoAlcance:
        """
        Decisión DETERMINISTA (léxica, sin API) de si `consulta` es de esta skill.

          · toca una frontera de OTRO dominio  → DERIVAR (no opina ajeno)
          · no toca ningún término propio       → ABSTENERSE (evidencia insuficiente)
          · toca lo propio y ninguna frontera   → PROCEDER

        Alinea con la compuerta de abstención β del proyecto (modulos.abstencion):
        ante evidencia insuficiente de pertenencia, la skill se retira en vez de
        emitir un juicio sin respaldo.
        """
        q = (consulta or "").lower()
        frontera = next((f for f in self.fronteras_fuera_alcance if f.lower() in q), None)
        if frontera is not None:
            return ResultadoAlcance(
                en_alcance=False, accion="DERIVAR",
                motivo=f"la consulta trata «{frontera}», fuera de la frontera de {self.nombre}",
                derivar_a=None)
        if self.terminos_alcance and not any(t.lower() in q for t in self.terminos_alcance):
            return ResultadoAlcance(
                en_alcance=False, accion="ABSTENERSE",
                motivo=f"la consulta no toca ningún término propio de {self.nombre}")
        return ResultadoAlcance(
            en_alcance=True, accion="PROCEDER",
            motivo=f"la consulta cae dentro del alcance de {self.nombre}")

    # ── Adaptador de compatibilidad hacia el subsistema prompt existente ─────
    def a_resultado_skill(self, ok: bool, hallazgos: Optional[List[dict]] = None,
                          resumen: str = "", error: Optional[str] = None) -> dict:
        """
        Envuelve la salida tipada en un `ResultadoSkill(dict)` de `modulos/skills`,
        para que viaje por el pipeline existente sin conversión. No elimina el
        contrato viejo: lo reutiliza.
        """
        from modulos.skills.base import ResultadoSkill
        return ResultadoSkill(
            nombre=self.nombre, titulo=self.titulo, ok=ok,
            hallazgos=hallazgos or [], resumen=resumen, error=error,
            duracion_seg=0.0, citas_no_verificadas=[], prompt_sha256="")

    # ── Stubs declarados (no operativos hasta el coordinador con API) ─────────
    def ejecutar(self, **kwargs) -> Any:
        """
        Las skills no operativas exponen su contrato pero no ejecutan sin el
        coordinador. Marca clara de 'pendiente coordinador API'.
        """
        raise NotImplementedError(
            f"skill '{self.nombre}' está DECLARADA pero no operativa: requiere el "
            f"Coordinador ReAct + function calling (día de API). "
            f"Ver docs/evidencia/plan_skills.md (SK-05).")
