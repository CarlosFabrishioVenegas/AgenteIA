"""
skills/metodologia.py  —  Skill 3 (Metodología / RAG Metodológico)
═════════════════════════════════════════════════════════════════════════════
DECLARADA para function calling; NO operativa hasta el Coordinador ReAct (día de
API). Busca la justificación teórica de fórmulas y parámetros calibrados en los
manuales metodológicos aprobados, con filtro duro por `model_id` (multi-tenancy).
El RAG léxico ya existe (`src/rag/`); aquí se declara como herramienta tipada.
"""

from __future__ import annotations

from skills.base_tipada import SkillTipada

__all__ = ["SkillMetodologia"]


class SkillMetodologia(SkillTipada):
    nombre = "retrieve_methodology_evidence"
    titulo = "Metodología (RAG Metodológico)"
    descripcion = ("Busca justificaciones matemáticas o metodológicas en los "
                   "manuales autorizados del modelo, filtrando por model_id.")
    parametros_schema = {
        "type": "object",
        "properties": {
            "model_id": {"type": "string",
                         "description": "ID del modelo financiero (ej. 'VAR_RETAIL_01')."},
            "query": {"type": "string",
                      "description": "Fórmula o concepto metodológico a validar "
                                     "(ej. 'calibración de volatilidad EWMA')."},
        },
        "required": ["model_id", "query"],
    }
    ambito_estandar = "Metodología"
    rubro_ids = ("sin_estacionariedad", "sin_heterocedasticidad", "sin_test_normalidad",
                 "sin_expected_shortfall", "sin_analisis_sensibilidad",
                 "supuesto_correlacion_constante", "sin_backtesting_lar",
                 "sin_shap_modelos_complejos")
    terminos_alcance = ("fórmula", "formula", "metodolog", "supuesto", "volatilidad",
                        "var", "expected shortfall", "estacionar", "normalidad",
                        "backtesting", "ewma", "garch")
    fronteras_fuera_alcance = ("nulos", "duplicad", "aprobación", "comité", "tier",
                               "correo", "email", "despliegue")
    operativa = False
