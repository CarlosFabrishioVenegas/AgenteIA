"""
skills/implementacion.py  —  Skill 5 (Implementación / Auditoría de Código)
═════════════════════════════════════════════════════════════════════════════
DECLARADA para function calling; NO operativa hasta el Coordinador ReAct (día de
API). Analiza el código estáticamente (AST), revisa lineamientos de seguridad
(credenciales en entorno, logs, backups) y valida réplicas exactas de la lógica
matemática. El analizador AST ya existe (`modulos/analisis_estatico.py`); aquí se
declara como herramienta tipada. La ejecución de tests unitarios corre en sandbox.
"""

from __future__ import annotations

from skills.base_tipada import SkillTipada

__all__ = ["SkillImplementacion"]


class SkillImplementacion(SkillTipada):
    nombre = "verify_code_implementation"
    titulo = "Implementación (Auditoría de Código y Despliegue)"
    descripcion = ("Analiza el código (AST), revisa seguridad y respaldos, y "
                   "valida réplicas exactas de la lógica matemática implementada.")
    parametros_schema = {
        "type": "object",
        "properties": {
            "code_path": {"type": "string",
                          "description": "Ruta al fichero o carpeta de código a auditar."},
            "model_id": {"type": "string", "description": "ID del modelo (aislamiento)."},
        },
        "required": ["code_path"],
    }
    ambito_estandar = "Implementación"
    rubro_ids = ("sin_replica_virf",)
    terminos_alcance = ("código", "codigo", "ast", "seguridad", "credencial", "backup",
                        "log", "réplica", "replica", "despliegue", "test unitario")
    fronteras_fuera_alcance = ("aprobación", "comité", "tier", "correo", "outlier",
                               "versión del documento")
    operativa = False
