"""
skills/  —  Fundación tipada de las 6 skills de la guía (function calling)
═════════════════════════════════════════════════════════════════════════════
Este paquete es la FUNDACIÓN TIPADA que exige `guia-integracion-skills-agente`:
las 6 skills (Documentación, Calidad de Datos, Metodología, Gobierno,
Implementación, Uso) declaradas como HERRAMIENTAS para function calling, con
entrada/salida Pydantic y alcance de revisión declarado.

RELACIÓN CON `modulos/skills/`
──────────────────────────────
`modulos/skills/` son 8 análisis basados en PROMPT (`ResultadoSkill(dict)`), que
siguen sirviendo y NO se eliminan. Este paquete los ENVUELVE/ADAPTA: cada skill
tipada puede emitir un `ResultadoSkill` compatible (`SkillTipada.a_resultado_skill`).

ESTADO (2026-08-31, hito Skills-1, API-free)
────────────────────────────────────────────
    Declaradas para function calling ...... 6/6
    Operativas y probadas (determinista) .. 1/6  (solo Calidad de Datos)

Las otras 5 quedan DECLARADAS (contrato + schema + alcance) con un marcador
`operativa=False`: se encienden con el Coordinador ReAct + function calling, que
requiere API y está diferido al día de API (ver docs/evidencia/plan_skills.md).
"""

from __future__ import annotations

from typing import Dict, List, Type

from skills.base_tipada import (
    AlcanceRubro,
    DeclaracionHerramienta,
    ResultadoAlcance,
    SkillTipada,
)
from skills.calidad_datos import DataQualityResult, SkillCalidadDatos, run_data_quality_check
from skills.documentacion import SkillDocumentacion
from skills.gobierno import SkillGobierno
from skills.implementacion import SkillImplementacion
from skills.metodologia import SkillMetodologia
from skills.uso import SkillUso

__all__ = [
    "SkillTipada", "DeclaracionHerramienta", "AlcanceRubro", "ResultadoAlcance",
    "DataQualityResult", "run_data_quality_check",
    "SKILLS_TIPADAS", "declaraciones_herramientas",
]

# Registro de las 6 skills de la guía, por nombre de herramienta.
SKILLS_TIPADAS: Dict[str, Type[SkillTipada]] = {
    c.nombre: c for c in (
        SkillDocumentacion,
        SkillCalidadDatos,
        SkillMetodologia,
        SkillGobierno,
        SkillImplementacion,
        SkillUso,
    )
}


def declaraciones_herramientas() -> List[dict]:
    """Lista de declaraciones de herramienta (JSON) para pasar a `tools=` del LLM.

    API-free: solo construye los schemas; el cableado del coordinador con
    `tools=`/`tool_choice` es follow-on (día de API).
    """
    return [c().declaracion_herramienta().model_dump() for c in SKILLS_TIPADAS.values()]
