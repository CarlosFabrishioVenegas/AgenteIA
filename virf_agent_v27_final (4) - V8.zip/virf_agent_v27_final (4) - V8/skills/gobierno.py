"""
skills/gobierno.py  —  Skill 4 (Gobierno / Compliance & Risk Tiering)
═════════════════════════════════════════════════════════════════════════════
DECLARADA para function calling; NO operativa hasta el Coordinador ReAct (día de
API). Deriva el Tier real del modelo por complejidad, lo cruza contra el Tier
autodeclarado y levanta bandera si discrepan; audita actas/correos institucionales.
Toda acción de impacto (aprobar, enviar) pasa por la cola PENDIENTE (skills.cola_pendiente).
El detalle de criterios vive en el ámbito «Gobierno» del estándar versionado.
"""

from __future__ import annotations

from skills.base_tipada import SkillTipada

__all__ = ["SkillGobierno"]


class SkillGobierno(SkillTipada):
    nombre = "check_compliance_government"
    titulo = "Gobierno (Compliance & Risk Tiering)"
    descripcion = ("Determina el Tier real por complejidad, lo cruza contra el "
                   "Tier autodeclarado y audita la comunicación institucional.")
    parametros_schema = {
        "type": "object",
        "properties": {
            "model_id": {"type": "string", "description": "ID del modelo."},
            "declared_tier": {"type": "string",
                              "description": "Tier autodeclarado en los documentos (ej. 'Tier 3')."},
        },
        "required": ["model_id"],
    }
    ambito_estandar = "Gobierno"
    rubro_ids = ()  # criterios de tiering/gobierno: ámbito del estándar versionado
    terminos_alcance = ("gobierno", "tier", "aprobación", "comité", "acta", "rol",
                        "segregación", "compliance", "autoriza")
    fronteras_fuera_alcance = ("outlier", "dataset", "fórmula", "estacionar", "código python")
    operativa = False
