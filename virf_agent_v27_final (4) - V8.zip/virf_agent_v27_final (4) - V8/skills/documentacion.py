"""
skills/documentacion.py  —  Skill 1 (Documentación / Auditoría Documental)
═════════════════════════════════════════════════════════════════════════════
DECLARADA para function calling; NO operativa hasta el Coordinador ReAct (día de
API). Parsea versión/estructura del documento y detecta modificaciones no
declaradas u omisión de apéndices. Su detalle de criterios vive en el ámbito
«Documentación» del estándar versionado (resuelto por el coordinador).
"""

from __future__ import annotations

from skills.base_tipada import SkillTipada

__all__ = ["SkillDocumentacion"]


class SkillDocumentacion(SkillTipada):
    nombre = "analyze_document_versioning"
    titulo = "Documentación (Auditoría Documental)"
    descripcion = ("Extrae la tabla de versiones de un documento y busca "
                   "inconsistencias de formato, apéndices omitidos y cambios "
                   "no declarados.")
    parametros_schema = {
        "type": "object",
        "properties": {
            "file_path": {"type": "string",
                          "description": "Ruta absoluta al documento (PDF/Markdown)."},
            "expected_version": {"type": "string",
                                 "description": "Versión esperada por el negocio (ej. 'v2.1.0')."},
        },
        "required": ["file_path"],
    }
    ambito_estandar = "Documentación"
    rubro_ids = ()  # el detalle vive en el ámbito del estándar versionado
    terminos_alcance = ("versión", "version", "documento", "apéndice", "control de cambios",
                        "changelog", "hash", "página", "estructura")
    fronteras_fuera_alcance = ("outlier", "dataset", "fórmula", "código", "correo", "tier")
    operativa = False
