# Auditoría — Eliminación de dependencias externas y corrección del pipeline

> ⚠️ **DOCUMENTO HISTÓRICO — parte de su contenido quedó superado el 2026-07-31.**
>
> Esta auditoría (30/07/2026) dejó el RAG generando embeddings con un deployment
> de Azure y ChromaDB como base vectorial. Un día después se descubrió que esa
> solución no era viable en este entorno, por dos motivos que la auditoría no
> pudo ver:
>
> 1. **No existe deployment de embeddings** en el recurso Azure de la entidad —
>    hay uno solo, de chat. El RAG quedaba apagado en silencio.
> 2. **ChromaDB arrastraba HuggingFace** por dependencia transitiva
>    (`chromadb → tokenizers → huggingface-hub`): la política de «cero modelos
>    externos» se cumplía en el código y se incumplía al instalar
>    `requirements.txt`.
>
> El RAG pasó a **búsqueda léxica (BM25 + TF-IDF)**, sin vectores y sin red.
> `config/embeddings.py` ya no existe. Lo que sigue se conserva como registro de
> lo que se encontró y decidió entonces — **no** como descripción del sistema
> actual. Para eso, ver **README §7.3**.

---

> Auditoría motivada por una corrida real en red bancaria de producción.
> Fecha: **30/07/2026** · Agente VIRF v27.1
>
> Todo lo que sigue está **verificado ejecutando código**. Donde no he podido
> verificar algo con los datos disponibles, lo digo explícitamente.

---

## Resumen ejecutivo

| # | Error reportado | Causa raíz | Estado |
|---|---|---|---|
| 1 | `SSL: CERTIFICATE_VERIFY_FAILED` → `huggingface.co` | Rama de embeddings locales presente en el código | ✅ **Eliminada de la arquitectura** |
| 2 | `Cannot send a request, as the client has been closed` | El SDK de OpenAI **toma posesión** del `http_client` | ✅ **Auto-reparación** |
| 3 | `ResponsibleAIPolicyViolation` | Filtro de contenido de Azure sobre vocabulario de riesgos | ✅ **Diagnóstico accionable** |
| 4 | `Contexto saturado 11.835/15.000 — 22 omitidos` | `break` en vez de `continue` en la selección | ✅ **Corregido: +19 documentos** |
| 5 | `Could not get FontBBox…` | Ruido de pdfminer que enterraba avisos reales | ✅ **Silenciado el logger** |

**Bug adicional encontrado durante la auditoría:** `NameError: AZURE_API_VERSION`
en `config/embeddings.py` — el RAG por Azure habría fallado en su primera
llamada real. Ver §2.4.

---

## 1. Dependencias hacia Hugging Face

### 1.1 Barrido realizado

Patrones buscados en todos los `.py` y `.txt` del árbol activo:

```
huggingface · sentence-transformers · transformers · AutoTokenizer · AutoModel
AutoModelForSequenceClassification · AutoModelForCausalLM · SentenceTransformer
snapshot_download · hf_hub_download · from_pretrained · langchain_huggingface
langchain.embeddings · HuggingFaceEmbeddings · InstructorEmbedding · MiniLM
```

### 1.2 Única ocurrencia ejecutable encontrada

| Archivo | Función | Motivo de uso | Dependencia |
|---|---|---|---|
| `config/embeddings.py` | `get_embedding_function()`, rama `local` | Generar vectores del RAG sin llamar a una API | `chromadb.utils.embedding_functions.SentenceTransformerEmbeddingFunction` → `sentence-transformers` → `huggingface_hub` |

El parámetro `VIRF_EMBEDDINGS_MODELO_LOCAL` tenía como **default**
`paraphrase-multilingual-MiniLM-L12-v2` — exactamente el modelo de tu traza de
error.

**Estaba bloqueada por política** (`VIRF_PROHIBIR_MODELOS_EXTERNOS=1` por
defecto), pero el código existía: bastaba una variable de entorno a `0` para que
el proceso intentara la descarga.

### 1.3 Acción tomada

**Eliminación, no gateo.** La rama `local` se borró de
`config/embeddings.py`. Ahora `get_embedding_function()` tiene una sola vía:

```python
if EMBEDDINGS_PROVEEDOR != "azure_openai":
    raise ValueError("…la vía local se ELIMINÓ del código el 30/07/2026…")
return _EmbeddingsAzure(AZURE_EMBEDDINGS_DEPLOYMENT, cliente=cliente)
```

También se retiró el parámetro `EMBEDDINGS_MODELO_LOCAL` de
`config/parametros.py` y de `config/__init__.py`.

> **Por qué borrar y no configurar.** Una barrera de configuración protege de un
> descuido; borrar el código protege de todo lo demás. Tu política es absoluta,
> así que la implementación también lo es.

### 1.4 Referencias restantes: todas en comentarios

Quedan 12 menciones, **ninguna ejecutable**: docstrings que explican qué se
retiró y por qué, más `requirements.txt` donde la línea está comentada con la
justificación. Un test lo fija:

```python
def test_la_via_de_embeddings_locales_ya_no_existe_en_el_codigo(self):
    vivas = [l for l in fuente.splitlines() if not l.lstrip().startswith("#")]
    assert "SentenceTransformerEmbeddingFunction" not in vivas
```

---

## 2. Dependencias indirectas

### 2.1 ChromaDB — descarga implícita

`get_or_create_collection()` **sin** `embedding_function` hace que ChromaDB
descargue y ejecute su propio ONNX MiniLM. No aparece en `requirements.txt` y
nadie lo pide explícitamente.

Los dos puntos del código sí pasan la función, pero nada lo impedía. Test
añadido:

```python
for m in re.finditer(r"get_or_create_collection\((.*?)\)", fuente, re.S):
    assert "embedding_function" in m.group(1)
```

### 2.2 ChromaDB — telemetría hacia PostHog

**Hallazgo no solicitado pero relevante.** Verificado:

```
chromadb.config.Settings().anonymized_telemetry → True
```

ChromaDB envía eventos de uso a PostHog **de fábrica**. No es un modelo, pero es
tráfico saliente no declarado desde una herramienta que trata documentación
interna de modelos de riesgo.

Desactivado por `Settings(anonymized_telemetry=False)` **y** por variable de
entorno, porque distintas versiones leen una u otra.

### 2.3 LangChain / LlamaIndex / Haystack / FAISS

**No están instalados ni referenciados.** El proyecto no los usa. El RAG es
ChromaDB directo, sin framework intermedio — lo cual, en este contexto, es una
ventaja: no hay una capa que inicialice modelos por su cuenta.

### 2.4 ⚠️ Bug encontrado: `NameError` en el RAG por Azure

Al separar `config/ia.py` en `config/red.py` + `config/embeddings.py` (para
romper un ciclo de imports), `AZURE_API_VERSION` quedó **usado pero no
importado** en `embeddings.py`. Reproducido:

```
NameError CONFIRMADO -> name 'AZURE_API_VERSION' is not defined
```

El RAG por Azure habría fallado en su **primera llamada real**. Corregido.

---

## 3. Análisis del RAG

### 3.1 Cómo se crean los embeddings

```
src/rag/base_indexer.py:_get_embedding_function()
        ↓
config/embeddings.py:get_embedding_function()
        ↓
_EmbeddingsAzure(deployment)  →  AzureOpenAI.embeddings.create()
```

`_EmbeddingsAzure` implementa el protocolo de ChromaDB (`__call__(input) → list`)
sin heredar de sus clases, para no atar el RAG a una versión de la librería.

Trocea en lotes de 96 y **ordena por `index`**: la API no garantiza el orden de
`data`, y un vector asignado al chunk equivocado corrompe el índice de una forma
que **no da error** — solo devuelve resultados absurdos.

### 3.2 Dónde se inicializa el cliente

Perezosamente, en `_obtener_cliente()`, la primera vez que se piden vectores.
El objeto vive dentro de la colección de ChromaDB, que es **singleton de
proceso** (`_rag_retriever_cache` en `modulos/motor_ia.py`).

### 3.3 Por qué aparece «Cannot send a request, as the client has been closed»

**Verificado contra el SDK real:**

```python
h = httpx.Client()
cli = AzureOpenAI(..., http_client=h)
cli.close()
assert h.is_closed   # ← True: el SDK TOMA POSESIÓN
```

Cualquier `close()` —explícito, por context manager o por recolección de
basura— deja el `httpx.Client` inservible. Y como la función de embeddings es
un singleton de proceso, **sobrevive a ese cierre**: el índice queda muerto el
resto de la corrida y el síntoma es «RAG no disponible», que no dice nada de la
causa.

### 3.4 ¿Es consecuencia del error de Hugging Face?

**Probablemente sí, en tu traza concreta**, aunque son dos fallos independientes:

1. El fallo SSL impide construir la función de embeddings.
2. El retriever queda en estado roto o cacheado como `None`.
3. Las llamadas siguientes reportan el fallo de transporte.

Los he corregido por separado porque **el segundo puede ocurrir sin el
primero**: basta con que algo cierre el cliente. La corrección es
auto-reparación:

```python
if getattr(_http, "is_closed", False):
    logger.warning("El cliente HTTP de embeddings estaba cerrado; se reconstruye.")
    self._cliente = None
```

Verificado: tras `close()`, la llamada siguiente construye un cliente nuevo.

---

## 4. Filtro de contenido de Azure

### 4.1 Qué puedo y qué no puedo determinar

**No puedo decirte qué prompt concreto lo disparó**: eso está en tus logs, no en
el código. Lo que sí he hecho es construir el diagnóstico que te lo dirá.

### 4.2 Por qué ocurre con documentación de riesgos

El vocabulario del dominio se solapa con las categorías de daño del filtro:

| Término del dominio | Categoría que puede disparar |
|---|---|
| «pérdida esperada», «severidad» | `violence`, `self_harm` |
| «default», «quiebra», «estrés» | `violence` |
| «exposición», «mitigación de daños» | `violence` |

Casi siempre es un **falso positivo**.

### 4.3 Qué se implementó

El mensaje anterior decía *«causa habitual: el filtro de contenido»* y ahí
terminaba. Ahora extrae de la respuesta la categoría y la severidad, distingue
**entrada** de **salida**, y da los tres caminos:

```
❌ Azure OpenAI bloqueó la petición por su filtro de contenido.

   Bloqueado en la ENTRADA — categorías: violence(medium)
   Tamaño del prompt: 15,000 chars.

   QUÉ HACER, por orden de eficacia:

   1. Pide a IT que ajuste el filtro del deployment. Es la solución real:
      Azure AI Foundry → Content filters → perfil con umbrales subidos.
      Es un cambio de configuración, no una excepción de seguridad.

   2. Aísla el documento culpable:
        DEBUG_PROMPTS=1 python agente.py ...
      vuelca el prompt íntegro a outputs/<fecha>/debug_prompts/.

   3. Reduce el contexto por llamada:
        VIRF_MAX_CTX=8000

   ⚠️ Esto es un FALLO TÉCNICO del agente, no una falta del validado:
      la actividad queda con evaluacion_valida=False y EXCLUIDA del score.
```

Ese último punto es el invariante 3 del proyecto: un bloqueo del filtro **nunca**
se convierte en un puntaje bajo contra el modelo validado.

### 4.4 Recomendación

**La opción 1 es la única solución de fondo.** Reestructurar prompts para evadir
un filtro es frágil: funciona hasta que cambia el documento. Un perfil de
content filter ajustado para este deployment, aprobado por seguridad, resuelve
la clase entera de problema.

---

## 5. Manejo del contexto

### 5.1 Causa raíz — un `break` que debía ser `continue`

```python
for d in docs_incluidos:
    if chars_acumulados + len(contenido) > MAX_CTX_TOTAL and contexto_partes:
        break          # ← descarta TODOS los siguientes
```

En cuanto **un** documento no cabía, se descartaban **todos los que venían
detrás**, incluidos los pequeños que sí habrían entrado.

Tu traza lo confirma: `11.835 / 15.000` deja **3.165 caracteres libres** y aun
así omite 22 documentos.

### 5.2 Corrección y medición

`continue` en vez de `break`, y orden de menor a mayor tamaño para maximizar
cuántos caben. Simulado con tus números:

```
27 documentos, presupuesto 15.000 chars

ANTES (break)               11.832 chars |  4 dentro | 23 omitidos
AHORA (continue + orden)    12.092 chars | 23 dentro |  4 omitidos

>>> documentos recuperados: +19
```

Además, los omitidos ahora **se nombran**, no solo se cuentan: «22 doc(s)
omitidos» no permitía decidir si lo perdido importaba.

### 5.3 Lo que NO se relajó

Los documentos que no entran **siguen contando 0 %** en la cobertura del ámbito.
Llenar mejor el presupuesto no puede convertirse en inflar la cifra — es el
invariante 4.

### 5.4 Arquitectura recomendada (no implementada)

El orden por tamaño es una mejora, no un ranking. La arquitectura correcta sería
**selección por relevancia**:

1. Puntuar cada documento contra la actividad concreta (el RAG ya tiene el
   índice y la similitud coseno).
2. Llenar el presupuesto por relevancia descendente.
3. Para el documento más relevante que no quepa entero, incluir sus chunks más
   relevantes en vez de descartarlo.

**Esfuerzo: 3-4 días.** Está en `ROADMAP_v28.md` como P2. No lo he hecho porque
cambia la selección de evidencia, y eso altera los puntajes de forma que hay que
medir con corridas comparadas antes y después.

### 5.5 Por qué subir `VIRF_MAX_CTX` NO es «dejar de perder información»

Medido sobre el corpus real:

```
Manual_Metodologico_LaR_completo.pdf → 1.302.266 chars de texto extraído
Ventana de 128K tokens               →   ~480.000 chars (estimado, ~3,75 ch/tok)
```

**El manual es casi el triple de la ventana entera.** No cabe con ningún valor
de `MAX_CTX`. Quien evita la pérdida es el **chunker**, que lo lee por segmentos
y consolida: por eso `cobertura_documental` marca 100 %.

Lo que `MAX_CTX` gobierna es la **compresión** de ese resumen, vía
`PRESUPUESTO_DOC = 0,6 × MAX_CTX`:

| `VIRF_MAX_CTX` | Presupuesto/doc | Compresión del manual |
|---:|---:|---:|
| 15.000 (actual) | 9.000 | 145 : 1 |
| 40.000 | 24.000 | 54 : 1 |
| **60.000** | 36.000 | **36 : 1** ← recomendado con GPT-4o |
| 100.000 | 60.000 | 22 : 1 |

**Recomendación: `60000`, y solo tras confirmar la ventana del deployment.** Con
un modelo de 16K tokens (≈60.000 chars) ese valor no deja sitio ni para las
instrucciones.

**Por qué no maximizarlo aunque quepa:** más prompt es más superficie para el
content filter (§4), y en contextos muy largos el modelo deja de localizar datos
que **sí están** y responde «no hay evidencia». Eso no es una omisión declarada:
es una **observación falsa contra el modelo validado**. Un contexto excesivo
corrompe el resultado en la peor dirección posible para Model Risk.

### 5.6 ⚠️ Bug encontrado: `VIRF_MAX_CTX` declarado dos veces

`.env.example` lo declaraba en dos secciones con valores distintos —`15000` en
«Contexto y lectura de documentos» y `100000` en «Chunking (avanzado)»—.
Verificado con `python-dotenv`:

```
dotenv_values('dup.env') → OrderedDict([('VIRF_MAX_CTX', '100000')])
```

**Gana el último.** Quien copiara el fichero corría con `100000` mientras leía
`15000` más arriba, sin ningún error. El efecto no es solo un presupuesto que
nadie eligió: la cobertura declarada en el informe deja de ser reproducible a
partir del fichero de configuración.

Corregido: declaración única, documentada con la tabla de §5.5, y test
`test_ninguna_variable_se_declara_dos_veces_en_env_example` que cuenta solo las
asignaciones activas.

---

## 6. Procesamiento de PDF

### 6.1 `Could not get FontBBox…`

**No afecta a la calidad.** Son fuentes incrustadas sin metadatos de caja;
pdfminer extrae el texto igual.

**El daño era otro:** inundaban la consola durante el chunking de un manual
largo y **enterraban los avisos que sí importan** — cobertura parcial, lectura
fallida. Un aviso relevante que nadie ve equivale a no haberlo emitido.

Silenciado el logger de `pdfminer` (no los `warnings` globales, que taparían
avisos de otras librerías).

### 6.2 `should not allow text extraction`

**Sí importa.** Es un PDF con extracción prohibida por metadatos: evidencia que
no se va a poder leer. Ahora se distingue del ruido y se registra como aviso.

### 6.3 ¿Conviene cambiar de librería?

**No.** La cadena actual (pdfminer → PyPDF2) es adecuada:

| Alternativa | Veredicto |
|---|---|
| `pypdf` (sucesor de PyPDF2) | Merece la pena: PyPDF2 está deprecado y lo avisa en cada corrida. Cambio mecánico, ~0,5 d |
| `PyMuPDF` / `fitz` | Más rápido y mejor extracción, **pero licencia AGPL** — inviable en banca sin revisión legal |
| `pdfplumber` | Ya está instalado; mejor para tablas. Podría añadirse como tercer intento |

**Recomendación:** migrar `PyPDF2` → `pypdf` y dejarlo ahí.

---

## 7. Arquitectura resultante

```
                    ┌──────────────────────────────┐
   NEGOCIO          │ agente.py · modulos/ · motor/│
   (no sabe de      │        src/rag/              │
    proveedores)    └──────────────┬───────────────┘
                                   │ interfaces abstractas
                    ┌──────────────▼───────────────┐
   CONFIGURACIÓN    │ config/ia.py   → ClienteIA   │
   (única capa      │ config/embeddings.py         │
    que habla       │ config/red.py  → proxy/TLS   │
    con la red)     └──────────────┬───────────────┘
                                   │
                    ┌──────────────▼───────────────┐
   EXTERIOR         │   Azure OpenAI  (único)      │
                    │   Anthropic     (secundario) │
                    └──────────────────────────────┘
```

**Inversión de dependencias:** el negocio depende de `ClienteIA`
(interfaz abstracta) y de `get_embedding_function()`, nunca de un SDK. Cambiar
de proveedor no toca ninguno de los 10 puntos de consumo.

**`config/` no depende de `modulos/`** salvo en un punto que queda pendiente:
`config/ia.py` importa `_extraer_json` de `modulos/motor_ia.py`. Es una
inversión de capas que ya obligó a extraer `config/red.py` para romper un ciclo.
Documentada en `ROADMAP_v28.md`.

---

## 8. Verificación

```
pytest                       → 551 passed, 3 skipped, 0 failed  (554 recolectados)
validate_project.py --strict → 129 / 129 PASS · 0 WARN · 0 FAIL · exit 0
```

### 8.1 Dos fallos que la propia suite detectó en esta auditoría

La primera corrida completa dio **2 failed, 549 passed, 3 skipped**. Los dos
fallos eran míos, de estos mismos cambios, y ninguno lo habría visto leyendo el
código:

**a) `test_ninguna_variable_documentada_es_decorativa`**

Al borrar el parámetro `EMBEDDINGS_MODELO_LOCAL` del código, quedó documentado
en `.env.example` una variable que ya nadie lee. El test existe precisamente
para eso: documentación que promete una palanca inexistente es peor que no
documentarla, porque alguien la va a poner y va a esperar un efecto.

Corregido reescribiendo el bloque de embeddings de `.env.example`, que además
seguía describiendo la opción `local` como si existiera.

**b) `test_content_none_se_reporta_con_su_finish_reason`**

Al sustituir el mensaje escueto de content filter por el diagnóstico largo del
§4, **perdí el token crudo `content_filter`** que la API devuelve. El mensaje
nuevo era más útil para quien lee la consola y menos útil para quien filtra
logs.

Corregido añadiendo una línea literal `finish_reason=<valor>` al diagnóstico.
Los dos lectores importan y no compiten.

> Vale la pena señalarlo: el segundo fallo es exactamente el tipo de regresión
> que se cuela cuando se «mejora» un mensaje de error. La suite lo atrapó en
> el mismo día.

### 8.2 Documentación alineada

Tres afirmaciones en `.md` que contradecían al código ya corregido:

| Archivo | Decía | Ahora |
|---|---|---|
| `.env.example` | opción `local` y `VIRF_EMBEDDINGS_MODELO_LOCAL` | vía eliminada; `PROHIBIR_MODELOS_EXTERNOS` descrito como marcador de política |
| `FUNCIONALIDADES.md` | job Databricks con `%pip install chromadb sentence-transformers` | `chromadb openai` + credenciales Azure como secretos |
| `README.md` (tabla) | `base_indexer` «genera embeddings con sentence-transformers» | delega en `config/embeddings.py` (Azure) |

**Tests nuevos de esta auditoría (22):**

| Clase | Qué fija |
|---|---|
| `TestAuditoriaEntornoCorporativo` | La vía local no existe · el SDK toma posesión del http_client · auto-reparación · diagnóstico de content filter |
| `TestElContextoSeLlenaNoSeAbandona` | `continue` en vez de `break` · omitidos nombrados · cobertura sigue contando 0% |
| `TestRuidoDePdfminer` | Logger silenciado sin tocar warnings globales · extracción prohibida se distingue |
| `TestNingunaLlamadaExterna` | Cero librerías de modelos · cero HTTP fuera del cliente · telemetría off · colecciones con embedding_function |

**Resultado final tras corregir §8.1: 551 passed, 3 skipped, 0 failed.**

---

## 9. Acciones pendientes de tu lado

| # | Acción | Por qué |
|---|---|---|
| 1 | **Pedir a IT el deployment de embeddings** | `AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT`. Sin él no hay RAG (el pipeline funciona igual, sin contexto regulatorio) |
| 2 | **Reconstruir el índice RAG** | El actual tiene **384 dimensiones** (MiniLM). Azure genera 1536. `python scripts/rebuild_rag_databricks.py --dominio all --force` |
| 3 | **Pedir a IT un perfil de content filter** | Es la solución de fondo al `ResponsibleAIPolicyViolation` |
| 4 | **Confirmar la ventana del deployment y subir `VIRF_MAX_CTX` a `60000`** | Solo si es GPT-4o (128K). Cuadruplica la fidelidad del resumen del manual (§5.5). Con un modelo de 16K, déjalo en `15000` |

---

*Auditoría realizada el 30/07/2026 contra VIRF Agent v27.1.*
*Los §§1-3, 5 y 6 se verificaron ejecutando código. El §4 documenta el*
*comportamiento del filtro de Azure; la categoría concreta que te bloqueó está*
*en tus logs y el nuevo diagnóstico la mostrará en la siguiente corrida.*
