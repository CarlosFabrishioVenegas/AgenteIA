# Remediación SEG · Fases 1 a 4

Fechas: 2026-11-05 a 2026-11-09 · Rama base: `main` (local, sin remoto) · Suite final: **1514 passed, 2 skipped** (1516 recogidos; línea base: 1235 passed, 1 skipped) · `validate_project.py --strict`: íntegro (0/146 fallos).

Cada hallazgo va en su propia rama, una encima de la otra (en orden de dependencias); nada está fusionado en `main`:
`main → SEG-04 → SEG-05 → SEG-01 → SEG-03 → SEG-02 → SEG-08 → SEG-12 → SEG-10 → SEG-11 → SEG-13 → SEG-06 → SEG-07 → SEG-14 → SEG-16 → SEG-09 → SEG-15`
(la rama `fix/SEG-15-recursos-externos` contiene todas).

> Las Fases 2, 3 y 4 se abrieron por decisión explícita del usuario con SEG-03 aún **bloqueado por humano** (rotación de claves sin confirmar), contra la regla 1 del plan.

| ID | Estado | Commit | Test | Evidencia | Pendiente humano |
|---|---|---|---|---|---|
| SEG-04 | Remediado – pendiente de validación | `8709046` | `test_pii.py` (48; 27 fallaban antes) | DNI/RUC/CE/CCI/cuentas/nombres; set de control sin falsos positivos | No |
| SEG-05 | Remediado – pendiente de validación | `7c7899d` | `test_gateway_ia.py` (16) | SDK solo en `config/ia.py`; todo cliente envuelto | No |
| SEG-01 | Remediado – pendiente de validación | `657f6cc` | `test_proveedores_ia.py` (29; 27 fallaban antes) | Solo Azure; allowlist de hosts; VIRF PLUS bloqueado | Estado de Anthropic (banco) |
| SEG-03 | **Bloqueado – requiere humano** | `55ff37f` | `test_credenciales.py` (23) | Web sin escritura de claves; Key Vault / scope | Rotar claves y confirmarlo |
| SEG-02 | **Bloqueado – requiere humano** (código remediado) | `8615a0f` | `test_identidad.py` (23) | SSO OIDC; firmante = aserción firmada de la sesión; sin `VIRF_VALIDADOR`/`--validador` | Registro en Entra ID; aprobar `msal` |
| SEG-08 | Remediado – pendiente de validación | `04c6e78` | `test_roles.py` (42) | Matriz de roles probada; sin contraseña compartida; feedback con hash encadenado | Definir y asignar app roles en Entra |
| SEG-12 | Remediado – pendiente de validación | `aca544f` | `test_auditoria.py` (15) | Una entrada por acción; log solo-anexar encadenado | Destino aprobado (SIEM/WORM) y ACL |
| SEG-10 | Remediado – pendiente de validación | `f23a6e7` | `test_clasificacion_docx.py` (6) | Etiqueta en el pie de todas las secciones de todo Word | No |
| SEG-11 | **Bloqueado – requiere humano** (código remediado) | `f8d199c`, `8c604b2` | `test_repositorio_corporativo.py` (12) | Guías solo hacia Azure DevOps; verificador de remotos | Confirmar URL del repo corporativo |
| SEG-13 | Remediado – pendiente de validación | `465ac72` | `test_documentacion_consistente.py` (6; todos fallaban antes) | Defaults en código `produccion` + `azure_openai`; manual regenerado (1447 tests) | No |
| SEG-06 | Remediado – pendiente de validación | `65007fb` | `test_almacenamiento.py` (17) | Clasificación obligatoria; Restringido rechazado en portátil; caché cifrada; capturas sin Restringido; TTL 30 días | Clave `virf-clave-cifrado-reposo` en Key Vault |
| SEG-07 | **Bloqueado – requiere humano** (código remediado) | `6b60617` | `test_ejecucion_codigo.py` (13) | Cero exec/eval (AST); META por AST; IA solo tras aprobación por hash, en subproceso aislado | Definir aprobadores y firma |
| SEG-14 | **Bloqueado – requiere humano** (código remediado) | `890dd07` | `test_databricks_minimo_dato.py` (10) | Lectura UC con columnas + filtro/límite; sin token personal | Service principal |
| SEG-16 | Remediado – pendiente de validación | `62b9bd4` | `test_salvaguardas_llm.py` (15) | Citas dudosas y NLI negativo retiran la afirmación; abstención β cableada; NLI activo en producción | No |
| SEG-09 | **Bloqueado – requiere humano** | `f2bf65d` | `test_gobierno_ia.py` (7) | Inventario + cuestionario (borrador); SAST 0 HIGH/MEDIUM; SCA 46 vulns en 6 paquetes con plan | Flujo de riesgo, DAST, pentest, actualizar dependencias |
| SEG-15 | Remediado – pendiente de validación | `0bff695` | `test_recursos_externos.py` (6; los 3 HTML fallaban antes) | Sin Google Fonts en los 3 HTML; 0 peticiones de red verificadas en el navegador | No |

## Verificación final (sección 6 del plan) — 2026-11-09

- [x] `pytest` completo: **1514 passed, 2 skipped** (1516 recogidos).
- [ ] Escaneo de secretos: **árbol limpio**; el **historial** conserva 1 hallazgo (`9b18e3f44:archivo/REPORTE_FINAL_PRUEBAS.md:171`, clave descrita como dummy, 43 caracteres; también en las dos `.bundle`). Reescribir el historial es destructivo: decisión humana (y rotar la clave si resultara real).
- [x] SDK de proveedor solo en el gateway (`tests/test_gateway_ia.py`, AST).
- [x] Ningún `exec`/`eval`/`compile(…, "exec")` en código de producción (`tests/test_ejecucion_codigo.py`, AST).
- [x] Informe Word con etiqueta de clasificación en todas las secciones (`tests/test_clasificacion_docx.py`).
- [ ] Hoja de hallazgos: **no está en el repositorio**; esta tabla hace sus veces. Volcarla a la hoja oficial es tarea humana.
- [x] Lista de pendientes 👤 entregada (abajo).
- Remotos git: ninguno (correcto); `validate_project.py --strict`: 0/146 fallos.

## Límites honestos

- **SEG-04 · nombres**: solo por contexto; sin NER aprobado, un nombre suelto en una frase no se detecta.
- **SEG-05 · inyección**: se neutraliza solo dentro de los bloques `material_no_confiable` (las plantillas propias contienen a propósito «actúa como»). Cinco llamantes quedan justificados en el test.
- **SEG-03 · Key Vault**: probado con dobles; `azure-identity`/`azure-keyvault-secrets` no instalados ni fijados en `requirements.txt`.
- **SEG-02**:
  - Login Entra probado solo con el proveedor simulado (no hay registro de app): `msal` no instalado.
  - **Doble firma**: la segunda firma exige otra identidad autenticada (`VIRF_ASERCION_IDENTIDAD_2`), pero la web **no tiene aún un flujo de co-firma**; con `VIRF_DOBLE_FIRMA_TIER` activado, la web no puede emitir esos tiers.
  - El CLI ya no firma: `--prdc` solo corre lanzado desde la web con sesión.
  - La aserción usa HMAC con clave de Key Vault; quien tenga esa clave podría forjarla (es infraestructura de confianza).
- **SEG-08**: el rol se comprueba después de validar el cuerpo (un cuerpo inválido da 422 antes que 403). Solo están protegidos por rol los endpoints del plan (RAG, prompts, visor, diagnóstico, subidas, lanzar, feedback); el resto exige sesión.
- **SEG-12**: en Windows el «solo anexar» depende de la ACL del fichero; el código solo abre en modo `a` y encadena hashes.
- **SEG-11**: `.github/copilot-instructions.md` sigue en el repo (configuración de GitHub Copilot); no apunta a ningún remoto, pero conviene que el banco decida si Copilot está autorizado. El primer commit de SEG-11 rompía dos tests de consistencia (no corrí la suite completa antes); corregido en `8c604b2`.
- **SEG-13**: el mensaje del commit dice «5 fallaban antes»; en realidad fallaban los 6. `MANUAL_TECNICO_VIRF.pdf` de la raíz no tiene generador en el repo: es un PDF estático desactualizado; recomiendo retirarlo y usar la guía generada.

- **SEG-06**: el borrado por sobrescritura no garantiza borrado físico en SSD (por eso Restringido no se admite localmente). La purga corre al arrancar la web y al cerrar sesión, no con un temporizador. Sin la clave de cifrado la caché no se persiste.
- **SEG-07**: el notebook generado ya no se auto-valida; la re-validación tras aprobar existe como API (`ejecutar_aprobado`) pero no está cableada a un flag de CLI. El subproceso aislado no es un sandbox de SO (sin red/disco restringidos): el control real es la aprobación humana.
- **SEG-14**: no había acceso a Databricks en el código (solo en la guía); se implementó la función de lectura mínima, probada con un Spark simulado.
- **SEG-16**: la inyección sigue siendo por patrones. El NLI en producción añade una llamada por actividad.
- **SEG-15**: además del archivo del plan se corrigieron su copia en `evidencias/` y `evidencias/informe_rag.html`, que tenían el mismo problema.
- **SEG-09**: las 6 dependencias vulnerables NO se actualizaron (Pillow es salto de versión mayor; hace falta reinstalar y re-ejecutar la suite). bandit y pip-audit se instalaron en un entorno aislado del scratchpad, no en el `.venv`.

## Pendientes humanos 👤

1. **SEG-03**: revocar y rotar claves (`.env` local con `ANTHROPIC_API_KEY`; commit `9b18e3f44` y las dos `.bundle` con una clave descrita como dummy; correos/chats). Cargar `azure-openai-api-key`, `virf-clave-firma-sesion` (≥32 caracteres) y `virf-entra-client-secret` en Key Vault.
2. **SEG-02**: registrar la app en Entra ID → `VIRF_ENTRA_TENANT_ID`, `VIRF_ENTRA_CLIENT_ID`, `VIRF_ENTRA_REDIRECT_URI`, client secret; aprobar `msal`.
3. **SEG-08**: crear los app roles `validador`, `admin_corpus`, `revisor` y asignarlos.
4. **SEG-12**: destino del log aprobado por el banco y ACL de solo anexar.
5. **SEG-11**: confirmar la URL del repositorio corporativo (`VIRF_REPO_CORPORATIVO`).
6. **SEG-01**: el estado de Anthropic solo lo cambia el banco.
7. **SEG-06**: cargar `virf-clave-cifrado-reposo` en Key Vault; declarar `VIRF_ENTORNO` en Databricks.
8. **SEG-07**: definir quiénes aprueban código (rol revisor) y cómo se firma.
9. **SEG-14**: solicitar el service principal (solo lectura de las tablas del dominio) y retirar cualquier token personal.
10. **SEG-09**: abrir el flujo con Riesgo No Financiero y Ciberseguridad; completar los campos 👤 de `docs/seguridad/GOBIERNO_RIESGO_IA.md`; agendar DAST y pentest; aprobar la actualización de dependencias.

## Efecto operativo

- Un `.env` con `IA_PROVEEDOR=anthropic` ya no ejecuta.
- Sin `MODO=debug` el agente arranca en producción y exige Key Vault.
- La web exige login corporativo: sin el registro en Entra ID **nadie puede entrar** (el proveedor simulado solo existe en tests).
