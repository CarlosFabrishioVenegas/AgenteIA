# `agente.py` — Manual de referencia de flags

> Referencia **exhaustiva y por flag** de la interfaz de línea de comandos.
> Verificado contra el `argparse` de `agente.py` (declaración) y contra cada punto de
> lectura (`args.*`) del despacho. Fecha: **2026-07-30**.
>
> **30 flags.** Los seis últimos se añadieron el 2026-07-30:
> `--revisar-codigo` y `--perfilar-datasets` (revisión de código y perfilado de
> datasets), `--prevuelo` (comprobar la evidencia antes de gastar) y
> `--comparar` (qué cambió entre dos corridas). Los números de línea de la
> tabla maestra son los de la declaración original.
>
> **2026-11-09 (SEG-02):** se eliminaron `--validador`, `--cargo`, `--validador-2`
> y `--cargo-2`, y las variables `VIRF_VALIDADOR*`. El firmante ya no se teclea:
> sale de la sesión web. Ver [Firma del informe](#firma-del-informe-antes---validador--cargo).
>
> Para el flujo operativo paso a paso → **`RUNBOOK.md`**.
>
> Este documento es el **manual de la CLI**: tipo, default, validación, interacciones,
> silencios, códigos de salida y errores de cada flag.
> Para *qué hace* cada funcionalidad y por qué existe → **`FUNCIONALIDADES.md`**.

---

## Índice

- [0. Cómo leer una ficha](#0-cómo-leer-una-ficha)
- [1. Tabla maestra](#1-tabla-maestra--26-flags)
- [2. Los 8 modos de ejecución y su precedencia](#2-los-8-modos-de-ejecución-y-su-precedencia)
- [3. Matriz de compatibilidad](#3-matriz-de-compatibilidad)
- [4. Flags que se ignoran en silencio](#4-flags-que-se-ignoran-en-silencio-)
- [5. Fichas — Selectores de modo](#5-fichas--selectores-de-modo)
- [6. Fichas — Identificación del modelo](#6-fichas--identificación-del-modelo)
- [7. Fichas — Evidencia y datos](#7-fichas--evidencia-y-datos)
- [8. Fichas — Cumplimiento regulatorio](#8-fichas--cumplimiento-regulatorio)
- [9. Fichas — Modificadores del explicador](#9-fichas--modificadores-del-explicador)
- [10. Fichas — Modificadores de notebooks](#10-fichas--modificadores-de-notebooks)
- [11. Fichas — Caché](#11-fichas--caché)
- [12. Fichas — Diagnóstico](#12-fichas--diagnóstico)
- [13. Códigos de salida](#13-códigos-de-salida)
- [14. Equivalencias flag ↔ variable de entorno](#14-equivalencias-flag--variable-de-entorno)
- [15. Validaciones, en el orden en que ocurren](#15-validaciones-en-el-orden-en-que-ocurren)
- [16. Asimetrías entre pipelines ⚠️](#16-asimetrías-entre-pipelines-)
- [17. Plantillas de comando](#17-plantillas-de-comando)

---

## 0. Cómo leer una ficha

Cada flag tiene una ficha con esta cabecera:

| Campo | Significado |
|---|---|
| **Tipo** | `switch` (booleano, sin valor) · `valor` (requiere argumento) |
| **Default** | Valor si no se pasa |
| **Rol** | `selector de modo` (decide qué hace el agente) · `modificador` (ajusta un modo) · `global` (afecta a todos) |
| **Coste API** | ✅ consume tokens · ❌ coste 0 · ⚠️ depende de otro flag |
| **Se lee en** | `fichero:línea` donde el código consume `args.<flag>` |
| **Salta PRE-FLIGHT** | Si evita la validación de credencial de `agente.py:320-375` |

Convenciones de notación:
- `--flag VALOR` → requiere argumento.
- `--flag` → switch.
- `{a|b|c}` → valores admitidos.
- ⚠️ marca un comportamiento que sorprende.

---

## 1. Tabla maestra — 26 flags (2 eliminados en SEG-02)

| # | Flag | Tipo | Default | Rol | API | Salta PRE-FLIGHT | Línea decl. |
|---:|---|---|---|---|:---:|:---:|---:|
| 1 | `--titulo NOMBRE` | valor | `None` | identificación | — | — | 164 |
| 2 | `--tier {1,2,3,4}` | valor | `None` | identificación | — | — | 165 |
| 3 | `--excel RUTA` | valor | `None` | evidencia | — | — | 166 |
| 4 | `--control` | switch | `False` | **selector de modo** | ✅ | — | 167 |
| 5 | `--prdc` | switch | `False` | modificador | ✅ | — | 168 |
| 6 | `--estadisticafeedback` | switch | `False` | **selector de modo** | ❌ | ✅ | 169 |
| 7 | `--limpiar-cache` | switch | `False` | **selector de modo** | ❌ | ✅ | 170 |
| 8 | `--cache-stats` | switch | `False` | **selector de modo** | ❌ | ✅ | 171 |
| 9 | `--no-cache` | switch | `False` | **global** | — | — | 172 |
| 10 | `--convertir-excel CARPETA` | valor | `None` | **selector de modo** | ⚠️ | solo con `--sin-llm` | 173 |
| 11 | `--controles-a-notebook DOC` | valor | `None` | **selector de modo** | ⚠️ | ❌ *(ver §16)* | 174 |
| 12 | `--datasets RUTA` | valor | `inputs/calidad_datos/datasets` | evidencia | — | — | 175 |
| 13 | `--listar-motores` | switch | `False` | **selector de modo** | ❌ | ✅ | 176 |
| 14 | `--explicar-modelo NOMBRE` | valor | `None` | **selector de modo** | ⚠️ | solo con `--dry-run` | 177 |
| 15 | `--dry-run` | switch | `False` | modificador | ❌ | — | 178 |
| 16 | `--excluir F1,F2` | valor | `None` | modificador | — | — | 179 |
| 17 | `--solo-coincidentes` | switch | `False` | modificador | — | — | 180 |
| 18 | `--raiz-evidencia RUTA` | valor | `BASE_DIR` | **global** | — | — | 181 |
| 19 | `--sin-llm` | switch | `False` | modificador | — | — | 182 |
| 20 | `--sin-validacion` | switch | `False` | modificador | — | — | 183 |
| 20b | `--revisar-codigo` | switch | `False` | modificador | ⚠️ | solo con `--dry-run` | 186 |
| 20c | `--perfilar-datasets` | switch | `False` | modificador | — | — | 187 |
| 20d | `--prevuelo` | switch | `False` | **selector de modo** | ❌ | ✅ | 188 |
| ~~21~~ | ~~`--validador NOMBRE`~~ | — | — | **eliminado** (SEG-02) | — | — | — |
| ~~22~~ | ~~`--cargo CARGO`~~ | — | — | **eliminado** (SEG-02) | — | — | — |
| 23 | `--verificar-cadena MODELO` | valor | `None` | **selector de modo** | ❌ | ✅ | 188 |
| 24 | `--verificar-evidencia JSON` | valor | `None` | **selector de modo** | ❌ | ✅ | 189 |
| 25 | `--historial-validaciones` | switch | `False` | **selector de modo** | ❌ | ✅ | 190 |
| 25b | `--comparar MODELO` | valor | `None` | **selector de modo** | ❌ | ✅ | 191 |
| 26 | `--verificar-conexion-azure` | switch | `False` | **selector de modo** | ✅ (1 req.) | ✅ *(valida por su cuenta)* | 191 |

**Recuento:** 13 selectores de modo · 9 modificadores · 2 globales · 4 identificación/evidencia.
Los 2 flags de cumplimiento (`--validador`/`--cargo`) se eliminaron: la identidad del
firmante la aporta la sesión web.

> `--revisar-codigo --dry-run` es el **único** modificador que se comporta como
> selector: sale con el inventario impreso sin ejecutar el pipeline, y sin exigir
> `--titulo`/`--tier`. Se despacha justo antes del PRE-FLIGHT (prioridad 5b).

---

## 2. Los 8 modos de ejecución y su precedencia

`main()` no valida que solo se pase un selector de modo. Evalúa `if` en cascada y **el primero
que coincide gana**; los demás se descartan sin aviso. Pasar dos selectores no es un error: es
un ganador silencioso.

**Orden de precedencia real** (`agente.py:238-616`), de mayor a menor:

| Prioridad | Flag | Termina con | Coste |
|:---:|---|---|:---:|
| 1 | `--verificar-cadena` | `sys.exit(0\|1)` | ❌ |
| 2 | `--verificar-evidencia` | `sys.exit(0\|1)` | ❌ |
| 3 | `--historial-validaciones` | `return` | ❌ |
| 4 | `--verificar-conexion-azure` | `return` | ✅ 1 req. |
| 5 | `--listar-motores` | `return` | ❌ |
| 5b | `--revisar-codigo` **+** `--dry-run` | `return` | ❌ |
| — | *(PRE-FLIGHT de credencial)* | `sys.exit(1)` si falla | — |
| 6 | `--explicar-modelo` | `return` | ⚠️ |
| 7 | `--limpiar-cache` | `return` | ❌ |
| 8 | `--cache-stats` | `return` | ❌ |
| 9 | `--convertir-excel` | `return` | ⚠️ |
| 10 | `--controles-a-notebook` | `return` | ⚠️ |
| 11 | `--estadisticafeedback` | `return` | ❌ |
| 12 | `--control` | `return` | ✅ |
| 13 | *(default)* pipeline completo | fin de `main()` | ✅ |

**Consecuencias prácticas:**

```bash
# Gana --verificar-cadena. El pipeline NO se ejecuta, y no se avisa de ello.
python agente.py --titulo "LaR" --tier 1 --verificar-cadena "LaR"

# Gana --explicar-modelo. --control se ignora por completo.
python agente.py --explicar-modelo "LaR" --control --excel x.xlsx

# Gana --cache-stats. La corrida de producción no ocurre.
python agente.py --titulo "LaR" --tier 1 --prdc --cache-stats
```

> **Regla operativa:** un comando, un selector de modo. Si necesitas dos cosas, son dos
> comandos.

**Dos pasos ocurren siempre**, antes de cualquier selector:

1. **Inicialización del caché** (`agente.py:208`) y registro de `atexit` para persistirlo
   (`:218`) — de modo que incluso los modos que salen con `sys.exit()` guardan lo que leyeron.
2. **Resolución de `--raiz-evidencia`** (`:232`) — se resuelve antes de ramificar porque tres
   modos distintos la necesitan.

---

## 3. Matriz de compatibilidad

Leer por filas: *"si uso el flag de la izquierda, ¿tiene efecto el de arriba?"*

| ↓ modo \ modificador → | `--prdc` | `--tier` | `--excel` | `--datasets` | `--raiz-evidencia` | `--no-cache` | `--dry-run` | `--excluir` | `--solo-coincidentes` | `--sin-llm` | `--sin-validacion` | `--revisar-codigo` | `--perfilar-datasets` | firmante (sesión web) |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| **pipeline completo** | ✅ | ✅ req. | ➖ | ✅¹ | ✅ | ✅ | ➖² | ➖ | ➖ | ➖ | ➖ | ✅ | ✅ | ✅ req. si `--prdc` |
| `--control` | ⚠️ cosmético | ✅ req. | ✅ req. | ✅ | ⚠️ *(ver §16)* | ✅ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ⚠️ **no se pide** |
| `--explicar-modelo` | ➖ | ➖ | ➖ | ➖ | ✅ | ✅ | ✅ | ✅ | ✅ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--convertir-excel` | ➖ | ➖ | ➖ | ➖ | ➖ | ✅ | ➖ | ➖ | ➖ | ✅ | ✅ | ➖ | ➖ | ➖ |
| `--controles-a-notebook` | ➖ | ➖ | ✅ | ✅ | ➖ | ✅ | ➖ | ➖ | ➖ | ✅ | ➖ | ➖ | ➖ | ➖ |
| `--revisar-codigo --dry-run` | ➖ | ➖ | ➖ | ➖ | ✅ | ➖ | ✅ req. | ➖ | ➖ | ➖ | ➖ | ✅ req. | ➖ | ➖ |
| `--estadisticafeedback` | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--listar-motores` | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--cache-stats` | ➖ | ➖ | ➖ | ➖ | ➖ | ⚠️ **no** | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--limpiar-cache` | ➖ | ➖ | ➖ | ➖ | ➖ | ⚠️ **no** | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--verificar-cadena` | ➖ | ➖ | ➖ | ➖ | ➖ | ✅ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--verificar-evidencia` | ➖ | ➖ | ➖ | ➖ | ➖ | ✅ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--historial-validaciones` | ➖ | ➖ | ➖ | ➖ | ➖ | ✅ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |
| `--verificar-conexion-azure` | ➖ | ➖ | ➖ | ➖ | ➖ | ✅ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ | ➖ |

¹ `--datasets` pasó a tener efecto en el pipeline completo al añadirse
`--perfilar-datasets`: fija de dónde sale el perfil del esquema. Sin
`--perfilar-datasets` sigue ignorándose ahí.
² `--dry-run` no afecta al pipeline completo **salvo** combinado con
`--revisar-codigo`, que lo convierte en el modo inventario (prioridad 5b).

**Leyenda:** ✅ tiene efecto · ✅ req. obligatorio · ➖ se ignora en silencio · ⚠️ comportamiento
que sorprende, ver §16.

> `--cache-stats` y `--limpiar-cache` **reinicializan el caché con `enabled=True`** de forma
> incondicional (`agente.py:424` y `:438`), así que `--no-cache` no los afecta. Es correcto:
> pedir estadísticas del caché o borrarlo con el caché apagado no tendría sentido.

---

## 4. Flags que se ignoran en silencio ⚠️

No hay ninguna validación que rechace una combinación inútil. Estos comandos **se ejecutan sin
error** haciendo algo distinto de lo que parece:

| Comando | Lo que parece | Lo que hace |
|---|---|---|
| `--explicar-modelo "LaR" --prdc` | genera Word | genera **solo** el `.md`; `--prdc` no se lee en esta rama |
| `--convertir-excel x/ --dry-run` | simula la conversión | convierte **de verdad**; `--dry-run` es exclusivo de `--explicar-modelo` |
| `--titulo "LaR" --tier 1 --sin-llm` | evalúa sin IA | evalúa **con IA**; `--sin-llm` solo aplica a los dos modos de notebook |
| `--titulo "LaR" --tier 1 --dry-run` | estima el coste | **corrida completa y facturada** |
| `--control --excel x.xlsx --solo-coincidentes` | filtra evidencia | no filtra nada; es exclusivo del explicador |
| `--convertir-excel x/ --excluir a.md` | excluye ficheros | no excluye nada; es exclusivo del explicador |
| `--controles-a-notebook d.md --sin-validacion` | omite validación | no hace nada; `--sin-validacion` es exclusivo de `--convertir-excel` |
| `--control --prdc` | exige firma y sella custodia | **ni firma ni sello** — ver §16 |
| `--cache-stats --no-cache` | stats con caché apagado | stats normales; `--no-cache` no llega |
| `--control --revisar-codigo` | revisa el código | **no revisa nada**; es exclusivo del pipeline completo |
| `--control --perfilar-datasets` | perfila el esquema | no perfila; el paso 2a solo existe en el pipeline completo |
| `--titulo … --tier 1 --dry-run` **sin** `--revisar-codigo` | estima el coste | corrida completa y facturada |

**Cómo detectarlo antes de gastar.** El banner de arranque declara el modo real:

```
══════════════════════════════════════════════════════════════════════
  🔍 AGENTE VIRF — PIPELINE TODOS LOS ÁMBITOS
  Modelo: Modelo LaR
  Tier:   1
  Modo:   PRE-PRODUCCIÓN
══════════════════════════════════════════════════════════════════════
```

Si el banner no dice lo que esperabas, corta con `Ctrl-C` antes de que empiecen las llamadas.

---

## 5. Fichas — Selectores de modo

### `--control`

| | |
|---|---|
| **Tipo** | switch |
| **Default** | `False` |
| **Rol** | selector de modo (prioridad 12) |
| **Coste API** | ✅ una llamada por control del Excel |
| **Se lee en** | `agente.py:527` |
| **Salta PRE-FLIGHT** | ❌ |

**Qué activa.** El pipeline por CONTROL: recorre las filas de `--excel`, evalúa cada control
con el LLM y ejecuta las pruebas del motor de datos cuando la fila lo declara.

**Obligatorios junto a él** (`agente.py:528-541`, en este orden):

1. `--titulo` → `error: --titulo es obligatorio`
2. `--tier` → `error: --tier es obligatorio (1, 2, 3, 4)`
3. tier válido → `error: --tier 'X' no es un tier válido...`
4. `--excel` → `error: --excel es obligatorio (ruta al Excel de controles)`
5. el fichero existe → `❌ Error: <ruta> no encontrado` + `exit 1`

Los cuatro primeros son `parser.error()` → **exit 2**. El quinto es `sys.exit(1)`.

**Interacciones.**
- `--datasets` → ✅ carga los DataFrames del motor de datos. Sin ellos, los controles con
  `USA_MOTOR_DATA=1` **no pueden ejecutarse** y se avisa.
- `--raiz-evidencia` → viaja como `base_project_path`. ⚠️ **también redirige `outputs/`** (§16).
- `--prdc` → ⚠️ **solo cambia el texto del banner**. Ver §16.

**Salidas.** `<raíz>/outputs/<fecha>/resultados_<titulo>_<fecha>.json` + Word (**siempre**) +
`parametros_ejecucion_*.csv`.

**Ejemplo mínimo.**
```bash
python agente.py --titulo "Modelo LaR" --tier 1 \
                 --excel inputs/calidad_datos/ControlesData.xlsx --control
```

---

### `--explicar-modelo NOMBRE`

| | |
|---|---|
| **Tipo** | valor (`metavar=NOMBRE`) |
| **Default** | `None` |
| **Rol** | selector de modo (prioridad 6) |
| **Coste API** | ⚠️ ✅ normalmente · ❌ con `--dry-run` |
| **Se lee en** | `agente.py:324, 381, 416` |
| **Salta PRE-FLIGHT** | solo si además se pasa `--dry-run` |

**Qué activa.** Consolida las 4 fuentes de `inputs/` en
`outputs/<fecha>/explicacion_del_modelo_<NOMBRE>.md` con 9 secciones fijas.

**Validación.** El nombre **no** se valida contra nada: no tiene que existir un modelo con ese
nombre. Se usa para (a) titular el documento, (b) filtrar ficheros si se pasa
`--solo-coincidentes`, y (c) nombrar el fichero de salida, saneado con `nombre_seguro()`.

**Errores.** Un `ValueError` del explicador —típicamente *sin evidencia en ninguna de las 4
fuentes*— se imprime y sale con **1** (`agente.py:417-419`).

**Modificadores propios.** `--dry-run`, `--excluir`, `--solo-coincidentes`. También respeta
`--raiz-evidencia` y `--no-cache`.

**Ejemplos.**
```bash
python agente.py --explicar-modelo "LaR" --dry-run          # coste 0
python agente.py --explicar-modelo "LaR"
python agente.py --explicar-modelo "VaR_FRTB" --raiz-evidencia modelos/VaR_FRTB
```

---

### `--convertir-excel CARPETA`

| | |
|---|---|
| **Tipo** | valor (ruta a **carpeta**) |
| **Default** | `None` |
| **Rol** | selector de modo (prioridad 9) |
| **Coste API** | ⚠️ ✅ normalmente · ❌ con `--sin-llm` |
| **Se lee en** | `agente.py:325, 455, 457` |
| **Salta PRE-FLIGHT** | solo si además se pasa `--sin-llm` |

**Qué activa.** Un `.ipynb` por cada `.xlsx`/`.xlsm` de la carpeta, en
`outputs/<fecha>/notebooks/`.

**Validación.** ⚠️ **La existencia de la carpeta no se comprueba antes.** Se pasa a
`generar_notebook_de_carpeta()` y cualquier excepción se captura, se imprime con traceback
completo y sale con **1** (`agente.py:467-470`). Si la carpeta existe pero no contiene libros,
`generados` viene vacío y también sale con **1** (`:471-472`).

**Modificadores propios.** `--sin-llm` (solo estructura, sin traducir fórmulas),
`--sin-validacion` (omite la comparación notebook vs Excel).

**No copia nada al pipeline.** El resultado se queda en `outputs/`; mover algo a
`inputs/implementacion/` es una decisión manual.

**Ejemplos.**
```bash
python agente.py --convertir-excel inputs/modelo_excel/ --sin-llm    # coste 0
python agente.py --convertir-excel inputs/modelo_excel/
python agente.py --convertir-excel inputs/modelo_excel/ --sin-validacion
```

---

### `--controles-a-notebook DOC`

| | |
|---|---|
| **Tipo** | valor (ruta a **fichero** `.docx`/`.pdf`/`.md`) |
| **Default** | `None` |
| **Rol** | selector de modo (prioridad 10) |
| **Coste API** | ⚠️ ✅ normalmente · el LLM se omite con `--sin-llm` |
| **Se lee en** | `agente.py:478, 480` |
| **Salta PRE-FLIGHT** | ⚠️ **nunca** — ni con `--sin-llm`. Ver §16 |

**Qué activa.** Extrae los controles descritos en prosa, genera un `.ipynb` ejecutable y cruza
contra `--excel` para producir el **análisis de brechas**.

**Validación.**
- El documento **sí** se comprueba: `❌ No existe el documento: <ruta>` + **exit 1**
  (`agente.py:481-483`).
- `--excel` es **opcional**. Sin él se usa `inputs/calidad_datos/ControlesData.xlsx`. Si tampoco
  existe: aviso y se genera el notebook **sin** análisis de brechas (`:486-489`).

**Interacciones.** `--excel` ✅ · `--datasets` ✅ · `--sin-llm` ✅ · `--sin-validacion` ➖.

**Los dos hallazgos que reporta** (`agente.py:504-510`):
```
⚠️  HALLAZGO: 3 control(es) documentado(s) pero NO ejecutado(s).
⚠️  HALLAZGO: 1 control(es) ejecutado(s) pero NO documentado(s).
```

**Salidas.** `outputs/<fecha>/controles/`

---

### `--estadisticafeedback`

| | |
|---|---|
| **Tipo** | switch · **Default** `False` · **Rol** selector (prio. 11) |
| **Coste API** | ❌ · **Se lee en** `agente.py:320, 520` · **Salta PRE-FLIGHT** ✅ |

**Qué hace.** Imprime MAE, sesgo, % exactos y % ±1 punto —global y por ámbito— y genera el
informe Excel de precisión en `outputs/`.

**Sin historial:** `[!] <error>` + *"Ejecuta al menos una validación con feedback antes de usar
este modo"* + **exit 0** (`agente.py:66-70`). Es `exit 0` a propósito: no tener feedback todavía
no es un fallo.

```bash
python agente.py --estadisticafeedback
```

---

### `--listar-motores`

| | |
|---|---|
| **Tipo** | switch · **Default** `False` · **Rol** selector (prio. 5) |
| **Coste API** | ❌ · **Se lee en** `agente.py:307, 321` · **Salta PRE-FLIGHT** ✅ |

**Qué hace.** Imprime el catálogo de las 8 pruebas de calidad de datos —descripción, columnas
requeridas, opcionales y ejemplo— y el recordatorio de cómo declararlas en el Excel:

```
  Uso en ControlesData.xlsx:
    USA_MOTOR_DATA=1  +  TIPO_MOTOR=<nombre>  +  columnas requeridas
```

**Equivalente sin agente:** `python -m modulos.motores_datos`

---

### `--verificar-conexion-azure`

| | |
|---|---|
| **Tipo** | switch · **Default** `False` · **Rol** selector (prio. 4) |
| **Coste API** | ✅ **1 request mínima** · **Se lee en** `agente.py:264, 323` |
| **Salta PRE-FLIGHT** | ✅ — hace su propia validación, más informativa |

**Qué hace.** Prueba de humo del proveedor **activo** (funciona para Anthropic también, pese al
nombre). Responde cuatro preguntas: ¿vale la credencial? ¿qué modelo sirve el deployment? ¿con
qué perfil de chunking se va a trabajar? ¿se parsea su JSON?

**Éxito** → `return` (exit 0). **Fallo** → imprime el error, la respuesta cruda si la hubo, la
lista de variables a revisar, y sale con **1** (`agente.py:273-285`).

El aviso que más errores evita: `AZURE_OPENAI_DEPLOYMENT` es el **Deployment name** del portal,
**no** el nombre del modelo.

```bash
python agente.py --verificar-conexion-azure
```

---

## 6. Fichas — Identificación del modelo

### `--titulo NOMBRE`

| | |
|---|---|
| **Tipo** | valor · **Default** `None` · **Rol** identificación |
| **Se lee en** | `agente.py:528, 547, 571, 815, 840, 1053, 1058, 1061, 1088, 1105, 1129, 1233` |

**Obligatorio en:** pipeline completo (`:616`) y `--control` (`:528`). Ignorado en todos los
demás modos.

**Los cinco usos del valor:**

| Uso | Dónde | Efecto |
|---|---|---|
| Rotular el informe | JSON, Word, banner | cosmético, se conserva **íntegro** |
| **Inferir el dominio RAG** | `inferir_dominio()` | decide qué índice vectorial se consulta |
| Nombrar el fichero de salida | `agente.py:1053` | saneado con `nombre_seguro()` |
| Identidad en la cadena de custodia | `sellar()`, `_slug()` | agrupa los informes del mismo modelo |
| Clave del registro de validadores | `registrar_validacion()` | cuenta firmas consecutivas |

⚠️ **`--titulo` no filtra la evidencia.** El pipeline lee **todo** `inputs/` sin importar el
título. Para aislar modelos: `--raiz-evidencia` (§7).

⚠️ **Las palabras del título cambian el RAG.** `inferir_dominio()` busca subcadenas:

| Dominio | Disparadores |
|---|---|
| `LaR` | `lar`, `liquidity`, `liquidez`, `lic`, `hqla` |
| `VaR` | `var`, `value at risk`, `frtb`, `market risk`, `riesgo de mercado` |
| `conductuales` | `conductual`, `prepago`, `retiro`, `nmd`, `comportamiento`, `behavioural` |
| `shared` | fallback |

La búsqueda es por subcadena sin límites de palabra, así que hay colisiones reales:
`"Variables macro"` contiene `var` → se resuelve a **`VaR`**. `"Modelo escalar"` contiene
`lar` → **`LaR`**. Si el dominio importa, revisa el `rag_dominio` del JSON.

**Saneo del nombre de fichero.** `nombre_seguro()` (`config/rutas.py`) elimina separadores,
`..`, caracteres ilegales de Windows (`<>:"/\|?*`), escapa nombres reservados (`CON`, `PRN`,
`AUX`, `NUL`, `COM1-9`, `LPT1-9`), acota a 80 chars y devuelve `sin_nombre` si queda vacío.
Los nombres normales no se tocan: `"Modelo LaR v3"` sale igual.

⚠️ **En `--control` el saneo NO se aplica** — ver §16.

```bash
--titulo "Modelo LaR"
--titulo "VaR Mercado FRTB"
--titulo "PD Retail Scorecard 2026"
```

---

### `--tier {1|2|3|4|I|II|III|IV}`

| | |
|---|---|
| **Tipo** | valor · **Default** `None` · **Rol** identificación |
| **Se lee en** | `agente.py:530-534, 548, 574, 618-624, 655` |

**Obligatorio en:** pipeline completo y `--control`.

**Qué hace.** Filtra qué actividades del estándar son **requeridas**: solo se evalúan las
marcadas para ese tier en las columnas `TIER I`–`TIER IV` del Excel.

**Normalización** (`config/dominio.py:normalizar_tier`). Se aplica `.strip().upper()` y se busca
en `TIERS_VALIDOS`:

| Entrada aceptada | Se resuelve a |
|---|---|
| `1`, `I`, `i`, ` i ` | `I` |
| `2`, `II`, `ii` | `II` |
| `3`, `III` | `III` |
| `4`, `IV`, `iv` | `IV` |
| cualquier otra | `None` → **rechazado** |

**Validación estricta, antes de gastar.**
```
error: --tier '9' no es un tier válido. Valores admitidos: 1, 2, 3, 4 (o I, II, III, IV).
```
→ `parser.error()` = **exit 2**.

**Por qué importa que se rechace.** `--tier 9` y `--tier abc` se aceptaban sin comprobación. El
parser buscaba una columna `TIER_9` inexistente, **desactivaba el filtro por tier** ("todas las
actividades se tratarán como REQUERIDAS") y la corrida evaluaba las 21 actividades en vez de las
11 del tier — **facturando la API completa** y rotulando el informe con un tier que no existe.
Un typo en un dígito producía un informe entregable y equivocado.
Test: `TestAuditoriaTierInvalidoSeRechazaAntesDeGastar`.

⚠️ Nota: al JSON y al Word viaja `str(args.tier)` **tal como se escribió** (`agente.py:655`), no
la forma normalizada. `--tier 1` y `--tier I` producen el mismo filtrado pero distinto rótulo,
y **distinta huella de ejecución** (el tier entra en el hash). Para comparar corridas, usa
siempre la misma notación.

---

## 7. Fichas — Evidencia y datos

### `--excel RUTA`

| | |
|---|---|
| **Tipo** | valor (ruta a fichero) · **Default** `None` · **Rol** evidencia |
| **Se lee en** | `agente.py:485, 535-541` |

**Doble papel según el modo:**

| Modo | Papel | Si falta |
|---|---|---|
| `--control` | **obligatorio** — es la lista de controles a evaluar | `parser.error` → **exit 2** |
| `--controles-a-notebook` | opcional — referencia para el análisis de brechas | default `inputs/calidad_datos/ControlesData.xlsx`; si no existe, aviso y notebook **sin** brechas |
| todos los demás | ➖ ignorado | — |

**Existencia.** En `--control` se comprueba y se sale con **1** si falta. En
`--controles-a-notebook` no se sale: se degrada a `excel = None`.

⚠️ El pipeline **completo** no usa `--excel`: lee `ControlesData.xlsx` de la ruta fija
`BASE_DIR/inputs/calidad_datos/` (`agente.py:58, 835`). Pasar `--excel` ahí no tiene efecto.

---

### `--datasets RUTA`

| | |
|---|---|
| **Tipo** | valor (ruta a **carpeta**) |
| **Default** | `BASE_DIR/inputs/calidad_datos/datasets` |
| **Rol** | evidencia · **Se lee en** `agente.py:491, 557` |

**Qué hace.** Carga los `.csv`/`.parquet`/`.xlsx` de la carpeta como DataFrames, indexados por
**nombre de fichero sin extensión**. Ese nombre es lo que la columna `DATASET` del Excel debe
declarar.

**Modos donde tiene efecto:** `--control` y `--controles-a-notebook`. Ignorado en el resto,
incluido el pipeline completo.

**Sin datasets** no falla, avisa (`agente.py:564-566`):
```
  ℹ️  Sin datasets en <ruta>
     Los controles con USA_MOTOR_DATA=1 no podrán ejecutarse.
```

**Con datasets** confirma la forma de cada uno, que es la verificación más útil antes de
interpretar los resultados:
```
  📊 Datasets cargados desde datasets/: ['data_subset', 'maestro_clientes']
       data_subset: 48,213 filas x 17 columnas
       maestro_clientes: 9,004 filas x 6 columnas
```

⚠️ **`--raiz-evidencia` no redirige el default de `--datasets`.** El default se construye sobre
`BASE_DIR` (`agente.py:491-492, 557-558`), no sobre la raíz de evidencia. Al validar un modelo
en otra raíz, pasa `--datasets` explícitamente.

---

### `--raiz-evidencia RUTA`

| | |
|---|---|
| **Tipo** | valor (ruta a **carpeta** que contiene `inputs/`) |
| **Default** | `BASE_DIR` (la raíz del proyecto) |
| **Rol** | **global** · **Se lee en** `agente.py:232` (una vez, antes de ramificar) |

**Qué reapunta.** Las carpetas de `inputs/`, vía `redirigir_evidencia()`.

**Qué NO reapunta:** `Estandares_VIRF.xlsx`, el caché, `ControlesData.xlsx` del pipeline
completo, y el default de `--datasets`. ⚠️ `outputs/` **sí** se reapunta en `--control` pero
**no** en el pipeline completo — asimetría documentada en §16.

**Modos donde tiene efecto:** pipeline completo, `--control`, `--explicar-modelo`.

**Validación al arrancar.** Ruta inexistente → `FileNotFoundError` capturado, mensaje y
**exit 1** (`agente.py:142-146`). Carpetas presentes pero vacías → **aviso, no error**:

```
  📂 Evidencia: C:\...\modelos\VaR_FRTB
  ⚠️  Carpetas sin documentos: implementacion, usos
      Los ámbitos que dependan de ellas puntuarán 0.0 (sin evidencia).
```

Ese aviso existe porque sin él un árbol a medio montar produce ámbitos "sin evidencia" que la
política puntúa 0.0 — **una falta crítica atribuida al validado** cuando el problema era la ruta.

**Estructura esperada:**
```
<RUTA>/inputs/documentacion/modelamiento/
<RUTA>/inputs/documentacion/seguimiento/
<RUTA>/inputs/implementacion/
<RUTA>/inputs/calidad_datos/
<RUTA>/inputs/papers/
<RUTA>/inputs/usos/
```

**Por qué se resuelve antes de ramificar.** Definirla dentro de una rama la dejaría sin asignar
en las demás: ese fue el `UnboundLocalError` que mató el pipeline en la auditoría.

```bash
python agente.py --titulo "VaR Mercado FRTB" --tier 1 --raiz-evidencia modelos/VaR_FRTB
python agente.py --explicar-modelo "VaR_FRTB" --raiz-evidencia modelos/VaR_FRTB
```

---

## 8. Fichas — Cumplimiento regulatorio

### `--prdc`

| | |
|---|---|
| **Tipo** | switch · **Default** `False` · **Rol** modificador |
| **Se lee en** | `agente.py:549, 638, 661, 816, 1099, 1227` |

**Qué cambia en el pipeline completo:**

| Efecto | Sin `--prdc` | Con `--prdc` |
|---|---|---|
| Informe Word | ❌ | ✅ |
| Identidad del validador | no se pide | **obligatoria, antes de gastar** |
| Registro de aprobación | ❌ | ✅ tras emitir el Word |
| Aviso de segunda revisión | ❌ | ✅ si 3+ firmas consecutivas |
| `calidad_proceso_*.json` | ❌ | ✅ (interno, no entregable) |
| Bucle de feedback | ✅ interactivo | ❌ desactivado |
| Modo del prompt | `modo_preprdc=True` | `modo_preprdc=False` |
| Caché de documentos | ✅ | ✅ (**ya no** se apaga) |

**Lo que `--prdc` ya NO hace.** Antes desactivaba el caché ("en producción siempre fresco").
Ese motivo no se sostenía: el caché se indexa por SHA-256 del contenido, así que la frescura ya
estaba garantizada. Lo único que compraba era pagar el chunking íntegro (~$1.45) **justo en las
corridas que emiten el entregable**. Y deducir "sin caché" de `--prdc` es adivinar el modo por
heurística cuando ya existe `--no-cache` para pedirlo explícitamente.

⚠️ **En `--control`, `--prdc` es cosmético**: cambia el texto del banner y nada más. Ver §16.

⚠️ En `--explicar-modelo` y los modos de notebook se ignora por completo.

---

### Firma del informe (antes `--validador` / `--cargo`)

**Ya no hay flag de firma** (SEG-02, norma 2135.010.02). Con `--validador`, `VIRF_VALIDADOR`
o la pregunta interactiva cualquiera podía firmar a nombre de otra persona.

**De dónde sale el firmante** (`modulos/validador_humano.py:solicitar_identidad`): únicamente
de la aserción firmada `VIRF_ASERCION_IDENTIDAD`, que la web emite a partir de la sesión del
usuario (`config/identidad.py`) y pasa al proceso de `agente.py` al lanzar la validación.
Nombre, cargo, UPN y `oid` del informe son los de esa sesión.

**Obligatoria en:** pipeline completo **+** `--prdc`. Por eso un informe de producción
**se lanza desde la web**, no desde la consola.

**Sin aserción, o con una manipulada o caducada** → `IdentidadRequerida` → **exit 1**, antes de gastar:

```
No se puede emitir un informe de producción sin validador AUTENTICADO.

  SR 11-7 §V · norma 2135.010.02: el firmante es la identidad
  corporativa de quien lanza la validación, no un nombre tecleado.

  Lanza la validación desde la web (login con Entra ID).
```

**Sin `--prdc`** la corrida no pide firmante y se sella como `tipo_corrida: trabajo`, no
como entregable.

**Doble firma** (`VIRF_DOBLE_FIRMA_TIER`): la segunda firma exige otra identidad autenticada
(`VIRF_ASERCION_IDENTIDAD_2`). La web aún no tiene pantalla de co-firma, así que con la doble
firma activa esos tiers no se pueden emitir.

**Aviso de segregación.** Si esta persona ya firmó `VIRF_UMBRAL_SEGUNDA_REVISION` (3) informes
consecutivos de este modelo sin que intervenga otro validador, se imprime un aviso que
**también entra en el informe**. No bloquea.

**Login:** hoy la web v2 se prueba con usuario libre (`scripts/web_prueba.py`); los informes
firmados así llevan «usuario de prueba (sin SSO)» en el cargo. El login corporativo es para
la web v3 (`docs/LOGIN_CORPORATIVO_WEB_V3.md`).

---

### `--verificar-cadena MODELO`

| | |
|---|---|
| **Tipo** | valor (`metavar=MODELO`) · **Rol** selector (prio. **1**, la más alta) |
| **Coste API** | ❌ · **Se lee en** `agente.py:238-242` · **Salta PRE-FLIGHT** ✅ |

**Qué hace.** Localiza los informes JSON del modelo en `OUTPUTS_DIR`, los ordena **siguiendo los
enlaces de la cadena** (no por nombre ni fecha de fichero), recalcula cada hash y reporta el
primer eslabón roto.

**El argumento** se compara por *slug* (`_slug()`: minúsculas, solo alfanuméricos), así que
`"Modelo LaR"`, `"modelo lar"` y `"MODELOLAR"` coinciden con los mismos informes.

**Códigos de salida.** `0` cadena íntegra · `1` cadena rota. Es el único par de modos
—junto a `--verificar-evidencia`— pensado para usarse en un script:

```bash
python agente.py --verificar-cadena "Modelo LaR" || echo "CADENA COMPROMETIDA"
```

**Por qué va primero de todo.** Verificar la integridad de un informe ya emitido no debe
depender de tener crédito ni conexión: un auditor puede necesitar comprobarlo mucho después de
que la clave haya caducado.

⚠️ Solo cubre informes del **pipeline completo**: `--control` no sella custodia (§16).

---

### `--verificar-evidencia INFORME.JSON`

| | |
|---|---|
| **Tipo** | valor (ruta a fichero JSON) · **Rol** selector (prio. 2) |
| **Coste API** | ❌ · **Se lee en** `agente.py:244-252` · **Salta PRE-FLIGHT** ✅ |

**Qué hace.** Lee `custodia.version_evidencia_usada` del informe y comprueba, documento a
documento, si el SHA-256 del fichero y del texto extraído siguen coincidiendo.

**Validación.** Ruta inexistente → `❌ No existe el informe: <ruta>` + **exit 1**.

**Códigos de salida.** `0` todos intactos · `1` alguno cambió o desapareció.

**Para qué sirve.** Si el manual metodológico se actualizó después de emitir el informe, el
puntaje ya no describe el modelo vigente. Esto lo detecta en segundos en vez de por sorpresa en
el comité.

```bash
python agente.py --verificar-evidencia outputs/2026-07-30/resultados_Modelo_LaR_2026-07-30.json
```

---

### `--historial-validaciones`

| | |
|---|---|
| **Tipo** | switch · **Rol** selector (prio. 3) |
| **Coste API** | ❌ · **Se lee en** `agente.py:254-257` · **Salta PRE-FLIGHT** ✅ |

**Qué hace.** Lee `feedback/registro_validadores.json` e imprime, agrupado por validador, los
modelos aprobados con fecha, tier, score y huella de ejecución.

**Sale con `return`** (exit 0) siempre, incluso sin registro.

**Para qué sirve.** Demostrar segregación de funciones y rotación ante el supervisor sin abrir
informes uno por uno.

---

## 9. Fichas — Modificadores del explicador

Los tres **solo** tienen efecto con `--explicar-modelo`. En cualquier otro modo se ignoran sin
aviso.

### `--dry-run`

| | |
|---|---|
| **Tipo** | switch · **Se lee en** `agente.py:324, 389, 408, 416` |

**Qué hace.** Construye el inventario de evidencia y estima el coste **sin instanciar el cliente
IA ni el chunker**. Coste real: **0 tokens**.

**Efecto en el PRE-FLIGHT.** La combinación `--explicar-modelo` + `--dry-run` está en la lista de
exención (`agente.py:324`), así que funciona **sin credencial válida y sin conexión**.

**Qué imprime.** Qué fuente aportó qué ficheros, cuántos chars, qué fuentes están vacías y el
coste estimado de la generación real.

⚠️ Es **exclusivo** del explicador. `--titulo ... --tier 1 --dry-run` ejecuta una corrida
completa y facturada.

```bash
python agente.py --explicar-modelo "LaR" --dry-run
```

---

### `--excluir F1,F2,...`

| | |
|---|---|
| **Tipo** | valor (lista separada por comas) · **Se lee en** `agente.py:384` |

**Qué hace.** Omite ficheros por **nombre**. El parseo es
`[x.strip() for x in valor.split(",") if x.strip()]`, así que los espacios alrededor de las
comas son irrelevantes y las entradas vacías se descartan.

**Caso de uso real.** Los fixtures de prueba y la evidencia de otros modelos viven en `inputs/`
y contaminarían el documento:

```bash
python agente.py --explicar-modelo "LaR" \
  --excluir "perfil_datos_VaR.md, manual_VaR_FRTB.md, kupiec_1995_resumen.md"
```

**Alternativa preferible.** Si tienes varios modelos, `--raiz-evidencia` resuelve el problema de
raíz en vez de enumerar exclusiones que hay que mantener a mano.

---

### `--solo-coincidentes`

| | |
|---|---|
| **Tipo** | switch · **Se lee en** `agente.py:412` |

**Qué hace.** Usa **solo** los ficheros cuyo nombre contiene el nombre del modelo.

**Por qué no es el default.** Por defecto se incluye **toda** la evidencia, deliberadamente:
descartar ficheros en silencio es peor que incluir alguno de más, porque el inventario del
documento declara qué se usó y el lector puede juzgarlo. Con `--solo-coincidentes` el filtrado
es tu decisión explícita.

**Cuándo usarlo.** Varios modelos comparten las carpetas de `inputs/` y sus ficheros llevan el
nombre del modelo (`manual_metodologico_LaR.md`, `perfil_datos_VaR.md`).

**Riesgo.** Un fichero de evidencia legítima que **no** nombre al modelo
(`informe_seguimiento_Q2_2026.md`) queda fuera. Compruébalo en el inventario del documento
generado.

```bash
python agente.py --explicar-modelo "PD_Retail" --solo-coincidentes
```

---

## 10. Fichas — Modificadores de notebooks

### `--sin-llm`

| | |
|---|---|
| **Tipo** | switch · **Se lee en** `agente.py:325, 464, 503` |

**Efecto según el modo:**

| Modo | Efecto | Salta PRE-FLIGHT |
|---|---|:---:|
| `--convertir-excel` | solo estructura + fórmulas **sin traducir** | ✅ |
| `--controles-a-notebook` | no extrae controles con el LLM | ⚠️ **no** — ver §16 |
| cualquier otro | ➖ ignorado | — |

**Qué se pierde con `--convertir-excel --sin-llm`:** la traducción de fórmulas a Python y de VBA.
Se conservan: estructura de hojas, tabla completa de fórmulas (Anexo B), grafo de dependencias
(Anexo A) y el detector de fórmulas peligrosas (Anexo C).

**Para qué sirve.** Reconocimiento gratis antes de decidir si merece la pena pagar la conversión
completa.

```bash
python agente.py --convertir-excel inputs/modelo_excel/ --sin-llm   # coste 0, sin credencial
```

---

### `--revisar-codigo`

| | |
|---|---|
| **Tipo** | switch · **Default** `False` · **Rol** modificador del pipeline completo |
| **Coste API** | ⚠️ ✅ una llamada **por módulo** · ❌ con `--dry-run` |
| **Se lee en** | `agente.py` (bloque dry-run, y paso 5c del pipeline) |
| **Salta PRE-FLIGHT** | solo con `--dry-run` |

**Qué hace.** Revisa cada `.py`/`.ipynb`/`.sql`/`.R` de `inputs/implementacion/` —recursivo—
contra el manual metodológico, en **una llamada por módulo**. Los hallazgos llevan
`fichero:línea` y se fusionan en el ámbito *Implementación*, con el mismo patrón que
los controles CDD en *Calidad de datos*.

**Dos modos:**

```bash
# Inventario + coste. Coste 0, NO requiere credencial, NO requiere --titulo/--tier
python agente.py --revisar-codigo --dry-run

# Revisión real, dentro del pipeline
python agente.py --titulo "Modelo LaR" --tier 1 --revisar-codigo
```

**El inventario se imprime siempre**, también en la corrida real y antes de la
primera llamada. Este flujo multiplica las llamadas por el número de ficheros, así
que el coste debe verse antes, no en la factura:

```
  Módulos encontrados : 4
  Llamadas al modelo  : 4
  Código              : 4,466 chars
  Manual por llamada  : 6,520 chars (× 4 llamadas)
  COSTE ESTIMADO      : ~$0.0127
  ⚠️  Filtro de dependencias DESACTIVADO: si el árbol incluye
      .venv/ o site-packages/, sus módulos también se revisarán.
```

⚠️ **El manual domina el coste.** Viaja como contexto fijo en **cada** llamada: con
30 módulos, cada char del manual se paga 30 veces. `VIRF_MAX_CHARS_MANUAL_REVISION`
(24.000 por defecto) es la palanca.

⚠️ **Sin filtro de dependencias por defecto.** Si copias a `inputs/implementacion/`
un árbol que arrastra `.venv/` o `site-packages/`, son miles de módulos y miles de
llamadas. Es una decisión explícita —descartar ficheros en silencio se consideró
peor— y la defensa es el inventario. Actívalo con `VIRF_EXCLUIR_DEPENDENCIAS=1`.

**Si no hay módulos**, avisa y continúa: el ámbito Implementación se evalúa solo con
la documentación. No es un error.

**Salidas.** `outputs/<fecha>/revision_codigo_<modelo>.md` + bloque
`revision_codigo` en el JSON. La clave **no** aparece si no se pidió la revisión —
su ausencia significa «no se revisó», no «se revisó y no encontró nada».

**Interacciones.** `--perfilar-datasets` ✅ (el perfil se añade al contexto fijo, y
permite comprobar si las columnas que el código consume existen) · `--raiz-evidencia`
✅ · `--no-cache` ✅ · `--prdc` ✅ (los hallazgos pesan en el score del Word).

---

### `--perfilar-datasets`

| | |
|---|---|
| **Tipo** | switch · **Default** `False` · **Rol** modificador del pipeline completo |
| **Coste API** | ❌ — es pandas, no LLM |
| **Se lee en** | `agente.py` paso 2a |

**Qué hace.** Añade a la evidencia un documento sintético (`PERFIL_DATASETS.md`) con
el **esquema** de cada dataset: columnas, dtypes, % de nulos, cardinalidad, rangos,
filas duplicadas, columnas constantes o íntegramente nulas. **No vuelca ninguna
fila.** Entra en la carpeta `calidad_datos`, que es su ámbito natural.

```bash
python agente.py --titulo "Modelo LaR" --tier 1 --perfilar-datasets
python agente.py --titulo "Modelo LaR" --tier 1 --perfilar-datasets \
                 --datasets data/extractos_2026Q2
```

**De dónde lee.** `--datasets` si se pasa; si no,
`<raíz-evidencia>/inputs/calidad_datos/datasets`. Si no hay datasets, avisa y sigue.

**Por qué no está activo por defecto.** `datasets/` está excluido de la evidencia
documental a propósito: un solo `.csv` se comía los 15.000 chars de contexto y
expulsaba al manual. El perfil son ~1.400 chars, pero añadirlo siempre cambiaría el
contexto —y por tanto la huella de ejecución— de todas las corridas existentes.

**No sustituye al motor de datos.** Aquel **calcula** con umbral y tasa de error
(`--control` con `USA_MOTOR_DATA=1`); el perfilador solo **describe**.

---

### `--sin-validacion`

| | |
|---|---|
| **Tipo** | switch · **Se lee en** `agente.py:465` (**un único punto**) |

**Qué hace.** Omite la auto-validación notebook vs Excel evaluado — el **Anexo D** del notebook.

**Exclusivo de `--convertir-excel`.** En `--controles-a-notebook` no hace nada.

**Qué te pierdes.** La auto-validación es la única comprobación objetiva de que la traducción es
correcta: ejecuta el notebook y compara sus resultados con los valores del Excel (`data_only`,
con fallback a fórmulas), con tolerancia `EXCEL_VALIDACION_TOL` (`1e-6`).

**Cuándo justificarlo:** el Excel no tiene valores calculados guardados, la ejecución excede
`EXCEL_NB_TIMEOUT` (120 s), o el notebook depende de datos que no están disponibles.

---

## 11. Fichas — Caché

### `--no-cache`

| | |
|---|---|
| **Tipo** | switch · **Rol** **global** · **Se lee en** `agente.py:208, 224` |

**Qué hace.** `cache_activo = CACHE_ENABLED and not args.no_cache`. Desactiva el caché de
documentos **y** el de resúmenes de chunking (el `cache_dir` del `ChunkerService` se pasa como
`None`, `agente.py:401, 684`).

**Confirmación en consola:**
```
  📦 Caché de documentos: INACTIVO [--no-cache]
  📦 Caché de documentos: INACTIVO [CACHE_ENABLED=0 en .env]
  📦 Caché de documentos: ACTIVO (37 entradas previas)
```

⚠️ **No afecta a `--cache-stats` ni a `--limpiar-cache`**, que reinicializan con `enabled=True`.

**Coste de usarlo.** Medido sobre un manual de 305 páginas: **~$1.14** de chunking que se paga
de nuevo. El caché se indexa por SHA-256 del contenido, así que un documento modificado **ya**
se relee — `--no-cache` no compra frescura, solo la repite.

**Cuándo tiene sentido:** depurar el propio chunking, o sospechar de una entrada corrupta. Para
lo segundo, `--limpiar-cache` es mejor.

---

### `--cache-stats`

| | |
|---|---|
| **Tipo** | switch · **Rol** selector (prio. 8) |
| **Coste API** | ❌ · **Se lee en** `agente.py:320, 437` · **Salta PRE-FLIGHT** ✅ |

Imprime total de entradas, hits históricos, distribución por tipo de fichero y la ruta del
índice. `return` (exit 0).

```
══════════════════════════════════════════════════════════
  📦 ESTADÍSTICAS DEL CACHÉ DE DOCUMENTOS
══════════════════════════════════════════════════════════
  Total entradas en caché : 37
  Hits históricos totales : 214
  Distribución por tipo   :
    docx     → 12 archivos
    pdf      → 8 archivos
    py       → 17 archivos
```

---

### `--limpiar-cache`

| | |
|---|---|
| **Tipo** | switch · **Rol** selector (prio. 7) |
| **Coste API** | ❌ · **Se lee en** `agente.py:320, 423` · **Salta PRE-FLIGHT** ✅ |

**Qué borra — los dos ficheros:**
```
  🧹 Caché de documentos limpiado: 37 entradas eliminadas.
  🧹 Caché de resúmenes limpiado: 4 entradas eliminadas.
```

**Sin confirmación y sin vuelta atrás.** No pregunta.

**Por qué borra dos cosas.** Antes solo vaciaba `document_cache.json`; los **resúmenes de
chunking** viven en otro fichero y sobrevivían a la limpieza. Se encontró una entrada con
cobertura del **1,2 %** conviviendo con la buena del 100 % sobre el mismo manual: "limpiar el
caché" dejaba viva precisamente la entrada mala.
Test: `TestAuditoriaBorrarDelCacheBorraDeVerdad`.

**Coste de la siguiente corrida:** se vuelve a pagar todo el chunking.

---

## 12. Fichas — Diagnóstico

Ver `--verificar-conexion-azure` (§5), `--listar-motores` (§5), `--estadisticafeedback` (§5) y
`--cache-stats` (§11). No hay flag de verbosidad: usa `DEBUG_PROMPTS=1` en el entorno.

---

## 13. Códigos de salida

| Código | Significado | Origen |
|:---:|---|---|
| **0** | Éxito, o verificación con resultado íntegro | `return` normal / `sys.exit(0)` |
| **1** | Fallo de ejecución **o verificación negativa** | `sys.exit(1)` |
| **2** | Error de uso de la CLI | `parser.error()` de argparse |

**Todo lo que sale con 1:**

| Situación | Línea |
|---|---|
| Cadena de custodia **rota** | `agente.py:242` |
| Informe inexistente en `--verificar-evidencia` | `:249` |
| Evidencia **alterada** | `:252` |
| Prueba de conexión fallida | `:285` |
| API key inválida / placeholder | `:335` |
| API key rechazada (401) | `:355` |
| Sin conexión con el proveedor | `:375` |
| `ValueError` del explicador (sin evidencia) | `:419` |
| Error o resultado vacío en `--convertir-excel` | `:470, :472` |
| Documento inexistente en `--controles-a-notebook` | `:483` |
| Error en `--controles-a-notebook` | `:514` |
| Excel de `--control` inexistente | `:541` |
| Excepción en el pipeline de `--control` | `:609` |
| `Estandares_VIRF.xlsx` inexistente | `:628` |
| Falta la identidad del validador | `:646` |
| Estándares ilegibles | `:670` |
| Excepción en el pipeline completo | `:1246` |
| Ruta de `--raiz-evidencia` inexistente | `:146` |

**Todo lo que sale con 2** (`parser.error`): falta `--titulo`, falta `--tier`, tier inválido,
falta `--excel` en `--control`, y cualquier flag desconocido o valor ausente.

⚠️ **`exit 1` es ambiguo:** significa tanto "fallo de ejecución" como "la verificación encontró
un problema real". En `--verificar-cadena` y `--verificar-evidencia`, `1` es el resultado
esperado cuando algo se alteró — lee stdout para distinguir.

**Un exit 0 que sorprende:** `--estadisticafeedback` sin historial sale con **0**
(`agente.py:70`). No tener feedback todavía no es un fallo.

---

## 14. Equivalencias flag ↔ variable de entorno

Ningún flag tiene equivalente directo en el entorno. Los dos que lo tenían
(`--validador` ↔ `VIRF_VALIDADOR`, `--cargo` ↔ `VIRF_VALIDADOR_CARGO`) se eliminaron en
SEG-02: la identidad del firmante solo llega por `VIRF_ASERCION_IDENTIDAD`, que emite la web.

**Comportamientos sin flag, solo por entorno:**

| Variable | Default | Qué hace |
|---|---|---|
| `CACHE_ENABLED=0` | `1` | Equivale a `--no-cache` **permanente** |
| `VIRF_CHUNK_ENABLED=0` | `1` | Desactiva el chunking (no hay flag) |
| `DEBUG_PROMPTS=1` | `0` | Vuelca los prompts (no hay flag) |
| `VIRF_MAX_DOCS_AMBITO=N` | `0` (sin límite) | Tope de documentos por ámbito |
| `VIRF_MAX_CTX=N` | `MAX_CHARS_DOC` | Contexto máximo por llamada |
| `VIRF_MAX_CHUNKS=N` | `40` | Segmentos por documento |
| `IA_PROVEEDOR` | `azure_openai` | Elige proveedor (no hay flag) |
| `VIRF_VALIDAR_CONEXION=1` | `0` | Prueba la conexión al arrancar |
| `VIRF_UMBRAL_SEGUNDA_REVISION=N` | `3` | Firmas consecutivas antes del aviso |
| `VIRF_MAX_CHARS_MODULO=N` | `120000` | Chars de un módulo por llamada en `--revisar-codigo` |
| `VIRF_MAX_CHARS_MANUAL_REVISION=N` | `24000` | Manual por llamada — **multiplicador del coste** |
| `VIRF_EXCLUIR_DEPENDENCIAS=1` | `0` | Excluir `site-packages/`, `.venv/`… del árbol revisado |

**No hay flag para cambiar de proveedor IA ni de modelo.** Es deliberado: la política de la
entidad fija Azure OpenAI como prioritario y el default vive en el **código**
(`config/parametros.py:127`), no en el `.env`, para que un clon que olvide definir
`IA_PROVEEDOR` salga por el proveedor correcto.

Lista completa de las ~40 variables: `FUNCIONALIDADES.md` §19.

---

## 15. Validaciones, en el orden en que ocurren

Saber **dónde** se cae ahorra dinero: todo lo que está por encima del PRE-FLIGHT es gratis.

```
┌─ argparse ────────────────────────────────── exit 2
│  · flag desconocido, valor ausente
│
├─ --raiz-evidencia existe ──────────────────── exit 1   [agente.py:142]
│  · aviso (no error) si hay carpetas vacías
│
├─ MODOS DE AUDITORÍA (coste 0) ─────────────── exit 0|1
│  · --verificar-cadena · --verificar-evidencia
│  · --historial-validaciones · --verificar-conexion-azure
│  · --listar-motores
│
├─ PRE-FLIGHT de credencial ─────────────────── exit 1   [agente.py:326]
│  · clave vacía/placeholder → mensaje accionable
│  · 401 → se recorre TODA la cadena de causas
│  · red → exit 1 + lista de modos que sí funcionan
│  ↑ TODO LO DE ARRIBA ES GRATIS. DE AQUÍ EN ADELANTE SE PAGA.
│
├─ Validaciones por modo ────────────────────── exit 1|2
│  · --control:  --titulo → --tier → tier válido → --excel → existe
│  · pipeline:   --titulo → --tier → tier válido → Estandares_VIRF.xlsx existe
│  · --controles-a-notebook: el documento existe
│
├─ Identidad del validador (solo pipeline + --prdc) ── exit 1  [agente.py:643]
│  ↑ ÚLTIMO PUNTO ANTES DE GASTAR DE VERDAD
│
└─ Ejecución ────────────────────────────────── exit 1 con traceback
```

**Sobre el diagnóstico del 401.** Antes se usaba `str(e)` a secas. El 401 real venía envuelto en
un `RuntimeError` genérico de `config/ia.py`, así que la firma de autenticación no aparecía en el
mensaje superficial y **una clave rechazada se clasificaba como "error de red → continuar"**.
Ahora se recorren hasta 10 niveles de `__cause__`/`__context__`.

**Sobre los errores de red.** Antes se advertía y se continuaba. No servía de nada: el PRE-FLIGHT
ya se salta para todos los modos que funcionan sin API, así que cualquier ejecución que llegue
ahí **necesita** la API. Continuar solo aplazaba la muerte hasta la instanciación del chunker,
donde salía como dos tracebacks crudos encadenados en vez de un mensaje accionable.
Test: `TestAuditoriaFallosDeRedSeDiagnosticanBien`.

---

## 16. Asimetrías entre pipelines

> ### Estado tras la revisión del 30/07/2026
>
> | # | Asimetría | Estado |
> |---|---|---|
> | 16.1 | `--prdc` no llega a `--control` | ✅ **Firma: decisión, no defecto.** **Sellado: CORREGIDO** (P0.1-A, 30/07) — ver abajo |
> | 16.2 | `outputs/` divergente con `--raiz-evidencia` | ✅ **CORREGIDO** |
> | 16.3 | Título sin sanear en `--control` | ✅ **CORREGIDO** |
> | 16.4 | `--controles-a-notebook --sin-llm` exigía credencial | ✅ **CORREGIDO** |
> | 16.5 | `--raiz-evidencia` no redirige `ControlesData.xlsx` ni el default de `--datasets` | ⚠️ **sigue así** — por diseño |
>
> Verificado ejecutando. Las secciones conservan la descripción del problema
> original porque explica **por qué** cada cosa es como es.

### 16.1 `--prdc` no llega al pipeline de controles — la firma no hace falta, el sello sí

> ### ⚠️ ACTUALIZACIÓN (30/07/2026) — P0.1-A
>
> La decisión sobre la **firma** se mantiene: `--control` no la pide, porque
> firmar es aprobar y el entregable sale del pipeline completo.
>
> Pero al reabrirlo se descubrió que el **sellado** no era opcional: sin él,
> `--verificar-cadena` marcaba como `ROTO` a un entregable legítimo en cuanto
> hubiera una corrida de `--control` en el mismo `outputs/`. Ya está corregido:
> las corridas de control se sellan como `tipo_corrida: "trabajo"` y la
> verificación las distingue de los entregables.
>
> ```
> Informes en la cadena: 3  (2 entregable(s), 1 corrida(s) de trabajo)
>   ✅ [ 1] resultados_LaR_A.json
>   ✅ [ 2] resultados_LaR_ctrl.json  ·trabajo·
>   ✅ [ 3] resultados_LaR_B.json
>   ✅ CADENA ÍNTEGRA
> ```
>
> Detalle en `ROADMAP_v28.md` → P0.1-A.


> ### ✅ RESUELTO COMO DECISIÓN DE DISEÑO (30/07/2026)
>
> Esto figuraba como el hueco de cumplimiento más grave: un informe de
> `--control --prdc` **parece** un entregable firmado y no lo es.
>
> Al analizarlo se vio que la premisa era equivocada. **El pipeline completo ya
> ejecuta los controles por su cuenta** y los fusiona en el ámbito «Calidad de
> datos» (`agente.py`, pasos 5 y 5b — el comentario dice literalmente *«para
> Word conjunto»*). El informe centralizado que se entrega ya incluye:
>
> ```
> Actividades totales: 24 del estándar + 4 control(es) CDD
>                      + 6 módulo(s) de código = 34 evaluaciones
> ```
>
> …y **ya va firmado y sellado**, porque sale del pipeline completo.
>
> Con lo cual `--control` es un **subconjunto**: solo los controles, sin los 6
> ámbitos. Sirve para iterar rápido sobre Calidad de Datos sin pagar la corrida
> entera — no para producir el entregable. Añadirle firma y custodia sería
> maquinaria de cumplimiento sobre un modo de trabajo.
>
> **La regla operativa:** el entregable sale SIEMPRE del pipeline completo
> (`--titulo` + `--tier` + `--prdc`). Ver `RUNBOOK.md` paso 5.
>
> Lo que sigue describe el comportamiento real, que no ha cambiado.

`orquestar_pipeline_virf()` (`modulos/motor_ia_v2.py:719-727`) **no recibe** ningún parámetro
derivado de `--prdc`. Los efectos observables:

| Efecto | Pipeline completo | `--control` |
|---|---|---|
| Informe Word | solo con `--prdc` | **siempre**, con o sin `--prdc` |
| Firmante autenticado (sesión web) obligatorio | ✅ con `--prdc` | ❌ **nunca se pide** |
| Registro en `registro_validadores.json` | ✅ con `--prdc` | ❌ |
| Aviso de segunda revisión | ✅ con `--prdc` | ❌ |
| `calidad_proceso_*.json` | ✅ con `--prdc` | ❌ |
| Sellado de cadena de custodia | ✅ siempre | ❌ **nunca** |
| Bucle de feedback | ✅ sin `--prdc` | ❌ |

En `--control`, `--prdc` **solo** cambia el texto del banner (`agente.py:549`).

**Qué significa en la práctica.** Un informe emitido con `--control --prdc`:
- lleva Word, pero **sin firma humana** ni bloques de cumplimiento;
- **no** entra en la cadena de custodia, así que `--verificar-cadena` no lo cubre;
- **no** deja rastro en el registro de validadores, así que `--historial-validaciones` no lo
  muestra.

**Recomendación.** Si el entregable tiene que acreditar validación independiente, emítelo con
el **pipeline completo**. Usa `--control` como análisis de Calidad de Datos, y ten presente que
sus salidas no están selladas.

### 16.2 `--raiz-evidencia` redirigía `outputs/` solo en `--control`

> ### ✅ CORREGIDO — ambos pipelines escriben en `OUTPUTS_DIR`
> `motor_ia_v2.py` usaba `base_project_path / outputs`, que es la raíz de
> EVIDENCIA. Con `--raiz-evidencia` los informes aterrizaban fuera y
> `--verificar-cadena` —que lee de `OUTPUTS_DIR`— no los encontraba: la cadena
> de custodia de un modelo quedaba invisible para su propia herramienta de
> verificación. Fijado por `TestLosDosPipelinesSeComportanIgual`.

| | Ruta de salida |
|---|---|
| Pipeline completo | `OUTPUTS_DIR/<fecha>/` → **siempre la raíz del proyecto** (`agente.py:692`) |
| `--control` | `base_project_path/outputs/<fecha>/` → **la raíz de evidencia** (`motor_ia_v2.py:744`) |

Con `--control --raiz-evidencia modelos/VaR_FRTB`, los resultados van a
`modelos/VaR_FRTB/outputs/<fecha>/`, no a `outputs/<fecha>/`. Si los buscas donde siempre, no
están.

### 16.3 El saneo del nombre de fichero no se aplicaba en `--control`

> ### ✅ CORREGIDO — path traversal cerrado
> `motor_ia_v2.py` interpolaba `--titulo` crudo en la ruta de salida. El test
> `TestAuditoriaPathTraversalEnSalidas` verificaba solo DOS de los tres puntos
> vulnerables, así que este quedó fuera de la red durante toda su vida.
>
> Ahora usa `nombre_seguro()`, el test cubre los tres, y se añadió un barrido
> que detecta cualquier f-string de ruta con el título sin sanear — la red que
> habría encontrado este.

- Pipeline completo: `outputs_dir / f"resultados_{nombre_seguro(args.titulo)}_{fecha}.json"`
  (`agente.py:1053`).
- `--control`: `outputs_dir / f"resultados_{nombre_modelo}_{fecha}.json"` con el título **crudo**
  (`motor_ia_v2.py:781`).

El test `TestAuditoriaPathTraversalEnSalidas::test_los_dos_puntos_vulnerables_lo_usan` verifica
`agente.py` y `modulos/explicador_modelo.py`, pero **no** `motor_ia_v2.py`. Un `--titulo` con
`/`, `\` o `..` en modo `--control` puede escribir fuera de `outputs/` o fallar con
`FileNotFoundError` **después** de pagar las llamadas.

**Mitigación mientras no se corrija:** en `--control`, usa títulos alfanuméricos con espacios,
guiones y guiones bajos.

### 16.4 `--controles-a-notebook --sin-llm` exigía credencial

> ### ✅ CORREGIDO
> La exención existía para `--convertir-excel --sin-llm` y faltaba la
> simétrica. Probado sin credencial: genera el notebook y el análisis de
> brechas.

La lista de exención (`agente.py:325`) contempla `(args.convertir_excel and args.sin_llm)` pero
**no** el equivalente para `--controles-a-notebook`. Con `--sin-llm` no se usará el modelo, pero
la credencial se valida igualmente: sin clave válida el comando muere en el PRE-FLIGHT.

**Vuelta:** ejecuta con una credencial válida, o usa `--convertir-excel --sin-llm` si tu caso lo
admite.

### 16.5 `--raiz-evidencia` no redirige `ControlesData.xlsx` ni el default de `--datasets`

> ### ⚠️ SIGUE ASÍ — y es deliberado
> `ControlesData.xlsx` es configuración del VALIDADOR, no evidencia del modelo:
> el mismo catálogo de controles se aplica a todos, igual que el estándar VIRF.
> Redirigirlo permitiría que cada modelo trajera su propia lista de controles,
> que es exactamente lo que `redirigir_evidencia` evita con la vara de medir.
>
> Los datasets sí son del modelo, pero su default apunta a la raíz del
> proyecto. **Pasa `--datasets` explícito** cuando uses `--raiz-evidencia`.

Ambos se construyen sobre `BASE_DIR`:
- `CONTROLES_DATA_PATH = BASE_DIR/inputs/calidad_datos/ControlesData.xlsx` (`agente.py:58`),
  usado por el pipeline completo en su paso 5 (`:835`).
- `--datasets` default: `BASE_DIR/inputs/calidad_datos/datasets` (`:491, :557`).

Al validar un modelo en otra raíz, pasa `--datasets` explícitamente y ten presente que los
controles CDD del pipeline completo se leen del Excel de la **raíz del proyecto**.

---

## 17. Plantillas de comando

### Verificación previa — todo gratis

```bash
python validate_project.py --strict
python agente.py --verificar-conexion-azure
python agente.py --cache-stats
python agente.py --listar-motores
python agente.py --explicar-modelo "<MODELO>" --dry-run
python agente.py --revisar-codigo --dry-run
```

### Revisión del código contra la documentación

```bash
# 1. Cuántos módulos hay y cuánto costará (coste 0, sin credencial)
python agente.py --revisar-codigo --dry-run

# 2. Si el árbol arrastra un entorno virtual, filtra antes de gastar
VIRF_EXCLUIR_DEPENDENCIAS=1 python agente.py --revisar-codigo --dry-run

# 3. Revisión real, con el perfil de los datasets en el contexto
python agente.py --titulo "<MODELO>" --tier <1-4> \
                 --revisar-codigo --perfilar-datasets

# 4. Leer el detalle fichero:línea
#    outputs/<FECHA>/revision_codigo_<MODELO>.md
```

### Ciclo completo de validación

```bash
# Pre-producción: evalúa y registra feedback
python agente.py --titulo "<MODELO>" --tier <1-4>

# Producción: Word + firma + custodia + registro
#   Se lanza desde la web («Lanzar validación»): la web añade --prdc y la
#   identidad firmada de tu sesión. Desde la consola, --prdc sale con exit 1.

# Cierre de auditoría
python agente.py --verificar-cadena "<MODELO>"
python agente.py --verificar-evidencia outputs/<FECHA>/resultados_<MODELO>_<FECHA>.json
python agente.py --historial-validaciones
```

### Calidad de datos

```bash
python agente.py --titulo "<MODELO>" --tier <1-4> \
                 --excel inputs/calidad_datos/ControlesData.xlsx --control \
                 --datasets inputs/calidad_datos/datasets

python agente.py --controles-a-notebook <DOC.md> \
                 --excel inputs/calidad_datos/ControlesData.xlsx \
                 --datasets inputs/calidad_datos/datasets
```

### Multimodelo — un comando por modelo

```bash
python agente.py --titulo "<MODELO>" --tier <1-4> \
                 --raiz-evidencia modelos/<MODELO> \
                 --datasets modelos/<MODELO>/inputs/calidad_datos/datasets

python agente.py --explicar-modelo "<MODELO>" --raiz-evidencia modelos/<MODELO>
```

### Excel → Notebook

```bash
python agente.py --convertir-excel <CARPETA> --sin-llm     # reconocimiento, coste 0
python agente.py --convertir-excel <CARPETA>               # completo
python agente.py --convertir-excel <CARPETA> --sin-validacion
```

### Mantenimiento

```bash
python agente.py --estadisticafeedback
python agente.py --limpiar-cache
python agente.py --titulo "<MODELO>" --tier <1-4> --no-cache
```

### Corrida no interactiva (CI / lote)

```bash
python validate_project.py --strict          || exit 1
python agente.py --verificar-conexion-azure  || exit 1
python agente.py --titulo "$MODELO" --tier "$TIER" || exit 1   # corrida de TRABAJO
python agente.py --verificar-cadena "$MODELO" || exit 1
```

> Un lote o una CI **no puede emitir un informe de producción**: no hay persona autenticada
> que firme. Corre sin `--prdc` (se sella como `tipo_corrida: trabajo`) y el entregable lo
> lanza un validador desde la web. Antes, `VIRF_VALIDADOR` permitía firmar a nombre de
> cualquiera; ese agujero es el que cierra SEG-02.

---

## Ayuda integrada

```bash
python agente.py --help     # los 26 flags con su texto de ayuda
python agente.py            # sin argumentos → error: --titulo es obligatorio (exit 2)
```

El docstring de cabecera de `agente.py` resume los tres usos principales; este documento cubre
el resto.
