# PROMPT DE CONTINUIDAD — VIRF Web · fixes pendientes (2026-08-16)

## Contexto del proyecto
`virf_agent_v27_final` — validador de modelos de riesgo financiero. Backend FastAPI (`web/app.py`) sobre agente CLI (`agente.py`). HTML/CSS/JS vanilla. Persistencia por sesión en `web/data/sesiones/{codigo}/{slug}/`.

**Reglas duras (no romper):**
- Sin crédito de API: mockear via `patch.object(motor_ia, "_llamar_modelo")` o `_obtener_cliente`; no lanzar corridas reales.
- RAG léxico solo (BM25 + TF-IDF), sin HuggingFace, un solo deployment.
- Flags explícitos, sin heurísticas. `--estandares` sigue esta regla.
- Persistencia JSON (sin BBDD). No npm/React/Vue/webpack.
- `estandares_virf.xlsx` sigue en `NOMBRES_PROHIBIDOS` para uploads genéricos — solo el paso 02 dedicado gestiona el estándar de sesión.

## Estado ahora (881 passed · 0 failed)
Hoy quedó cerrado:
- **v2.3 · Prompts editables + presupuesto dinámico**: `web/services/prompt_service.py`, `web/services/presupuesto_service.py`, `web/routers/prompts.py`, modal ⚙ con tabs editables, `Mx_03_LlamarIA` lee `VIRF_ROL_AGENTE_OVERRIDE`, `pipeline_runner._construir_env_hijo`.
- **v2.4 · Paso 02 Estándares por sesión**: `web/services/estandares_service.py`, `web/routers/estandares.py`, `Mx_00_CargaRutas.redirigir_estandar()`, agente.py `--estandares`, panel `#vista-estandares`, sidebar renumerada 01→09.
- Suite: 881 passed · 1 skipped en `pytest`.

## FIXES PENDIENTES (orden sugerido)

### 1. UX del paso 02 · Estándares — dos huecos
**Problema 1** (`web/static/js/app.js:abrirEstandares`): si el validador subió el xlsx pero no lo confirmó y refresca la página, se pierde la preview en el frontend (el .xlsx sigue en disco). El código tiene un `// TODO` explícito reconociéndolo.

**Fix propuesto:**
- Nuevo endpoint `GET /api/estandares/preview-actual` en `web/routers/estandares.py` que re-parsea el `.xlsx` de la sesión si existe pero no está confirmado. Devuelve el mismo payload que `POST /upload`.
- En `abrirEstandares()`: si `estado.subido && !estado.confirmado`, llamar `/preview-actual` y `pintarPreviewEstandares(d)`.

**Problema 2**: `web/templates/index.html:203` sigue diciendo "Comienza por 01. Configuración". Con la renumeración correcta debería seguir diciendo "01. Configuración" (Config sigue siendo 01), así que **verificar solo** — es probable que ya esté OK.

**Test a añadir en `tests/test_estandares_sesion.py`:**
```python
def test_preview_actual_devuelve_parseo_sin_confirmar(ctx_de_prueba, tmp_path):
    # ... guardar xlsx, no confirmar, llamar servicio de preview
```

### 2. Frontend cacheado tras cambios en app.js
El usuario reportó no encontrar el editor ⚙ tras la implementación de v2.3 — probablemente por caché del navegador (uvicorn --reload solo re-carga Python).

**Fix propuesto:** añadir query-string versionada al `<script src="/static/js/app.js?v=2.4">` en `web/templates/index.html` y bumpar el número cada vez que se toca. Igual para `styles.css`.

Alternativa más limpia: middleware `Cache-Control: no-store` en `/static/*` cuando el flag `VIRF_DEV=1` esté activo.

### 3. Preview del prompt muestra parámetros del PROCESO PADRE, no los que verá el subprocess
En `web/routers/preview_prompt.py:_leer_parametros()` se lee `os.environ.get("VIRF_MAX_CTX", "15000")` del proceso web, pero `pipeline_runner._construir_env_hijo` sobreescribe estos valores por sesión antes de spawnar. La preview muestra 15000 aunque el subprocess vaya a correr con 184000.

**Fix propuesto:** en `_leer_parametros`, si `ctx["validador"]` tiene `modelo_ia_detectado`, llamar `presupuesto_service.aplicar_env({}, env={})` y mostrar los valores efectivos, marcando "(dinámico por modelo detectado)".

### 4. `chat_agente` prompt editado con `{` extra revienta format()
`web/services/prompt_service.py::_placeholders_en` valida que los placeholders declarados sigan presentes, pero **no rechaza placeholders NUEVOS que introduzca el validador**. Si edita el chat_agente y escribe accidentalmente `{ejemplo}`, cuando `chat_service._renderiza_prompt` haga `template.format(...)` sin ese kwarg, lanza `KeyError` en producción y no se detecta hasta la primera repregunta del chat.

**Fix propuesto:** en `editar_prompt`, si `modo == "template"`, comparar `_placeholders_en(contenido)` contra la lista declarada. Si hay **placeholders extra**, rechazar con `ValueError("placeholders no declarados: {...}. Los templates aceptan solo los que la base lista.")`. Añadir test.

### 5. `_construir_env_hijo` busca modelo detectado por código de validador, no por token
`web/services/pipeline_runner.py:_construir_env_hijo` itera `sesion_store._sesiones.items()` buscando por `codigo`. Si un mismo validador tiene dos ventanas (dos tokens), pilla el primero. Es raro pero es un bug latente.

**Fix propuesto:** propagar el `virf_token` al `ctx` en `contexto_sesion()` (añadirlo como campo del dict `ctx`), y en `_construir_env_hijo` buscar directamente `sesion_store.sesion_activa(ctx["token"])`.

### 6. Evaluación por ámbito — abrir "slots" seguros de edición
Hoy `evaluacion_ambito` quedó readonly porque el template tiene 15+ placeholders que romperían format(). El validador puede querer **añadir texto antes o después** sin tocar los placeholders. La solución que se prometió en la spec: dos slots editables.

**Fix propuesto:**
- Añadir al `prompts_base.json` dos entradas nuevas: `evaluacion_ambito_preambulo` y `evaluacion_ambito_postambulo` (texto plano, `editable: true`).
- En `modulos/motor_ia.py::evaluar_actividad`, aceptar dos kwargs opcionales `preambulo` y `postambulo`, y anteponerlos/postponerlos al prompt final.
- En el pipeline_runner, exportar `VIRF_PREAMBULO_ACTIVIDAD` y `VIRF_POSTAMBULO_ACTIVIDAD` con el contenido efectivo; motor_ia los lee del env como fallback.
- UI: dos tabs nuevas en el editor.

### 7. Ficheros untracked heredados
- `MANUAL_TECNICO_VIRF.pdf` en raíz (hermano del .docx que movimos ayer). Decidir: `archivo/preexistente_2026-08-14/` o dejar.
- `PROMPT_CONTINUIDAD_2026-08-09.md` heredado — puedes reemplazarlo con este y borrar el viejo.

### 8. Sin commits desde antes de v2.3
El diff acumulado ya es grande (13 modificados + 15+ untracked, incluyendo web/ entera). Cuando el usuario dé luz verde, commits sugeridos:
1. `feat(web): prompts editables por sesión y presupuesto de contexto dinámico`
2. `feat(web): paso 02 · estándares de validación por sesión con flag --estandares`
3. `chore: mover ficheros preexistentes a archivo/preexistente_2026-08-14/`

## Cómo arrancar mañana
```bash
python -m pytest -q                                    # verificar 881 passed
python -m uvicorn web.app:app --reload --port 8000     # levantar UI
```

Empezar por el fix #1 (UX estándares) o #4 (bug latente de placeholders) — son los más contenidos y ambos tienen test claro.

## Rutas clave para orientarse
- Prompts: `web/services/prompt_service.py`, `web/routers/prompts.py`, `web/data/prompts_base.json`
- Estándares: `web/services/estandares_service.py`, `web/routers/estandares.py`
- Motor: `motor/Mx_00_CargaRutas.py::redirigir_estandar`, `agente.py::--estandares`, `pipeline_runner::_construir_env_hijo`
- UI: `web/templates/index.html::#vista-estandares`, `web/static/js/app.js::cablearEstandares`, `web/static/css/styles.css::.est-*`
- Tests nuevos: `tests/test_prompts_editables.py` (17), `tests/test_estandares_sesion.py` (10)
