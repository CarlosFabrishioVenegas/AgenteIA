# Guía para montar el corpus RAG y medir la calidad de la validación

> **Qué es este documento.** El procedimiento para pasar del corpus actual —tres
> documentos de apoyo de 6 KB por dominio— a una literatura de referencia real, y
> para **medir** en cada paso cuánto mejora la validación.
>
> **Documento hermano:** [`GUIA_RAG_LEXICO.md`](GUIA_RAG_LEXICO.md) explica cómo
> funciona el motor. Éste explica **con qué alimentarlo**.
>
> Fecha: **2026-07-31**

---

## 0. Lo primero: «validación perfecta» no existe, y perseguirla es el error

Conviene decirlo antes de empezar, porque cambia el objetivo.

El agente no produce la verdad sobre un modelo: produce un **dictamen fundamentado
y trazable** que un validador humano firma. La palabra que importa en el estándar
regulatorio (SR 11-7, EBA/GL/2023/01) no es *perfecto*, es **defendible**: que
cada afirmación tenga una fuente, que las limitaciones estén declaradas, y que un
tercero pueda reconstruir cómo se llegó al puntaje.

Un sistema que aspira a la perfección tiende a **ocultar** su incertidumbre —y
eso es exactamente el fallo que este proyecto lleva dos iteraciones corrigiendo:
el RAG apagado que no lo decía, el `score` de 1.00 que no significaba nada. Un
RAG que dice «de esto no tengo literatura» vale más que uno que siempre responde.

**Así que el objetivo operativo no es «100 % de cobertura»**, sino:

| | |
|---|---|
| ✅ Objetivo real | Que **sepas** en qué actividades el agente tiene fundamento documental y en cuáles opina a ciegas — y que quien lea el informe también lo sepa |
| ❌ Objetivo falso | Que todas las actividades salgan «cubiertas» |

Lo que sigue es cómo conseguir lo primero, y cómo medirlo con dos comandos.

---

## Índice

- [1. Las tres cosas que determinan la calidad](#1-las-tres-cosas-que-determinan-la-calidad)
- [2. Punto de partida: dónde estás hoy](#2-punto-de-partida-dónde-estás-hoy)
- [3. Qué documentos poner, y en qué dominio](#3-qué-documentos-poner-y-en-qué-dominio)
- [4. Reglas del corpus (las que evitan corromper la validación)](#4-reglas-del-corpus-las-que-evitan-corromper-la-validación)
- [5. El ciclo de mejora, paso a paso](#5-el-ciclo-de-mejora-paso-a-paso)
- [6. Cómo leer la auditoría](#6-cómo-leer-la-auditoría)
- [7. Los dos hallazgos que ya salieron](#7-los-dos-hallazgos-que-ya-salieron)
- [8. Checklist de puesta en marcha](#8-checklist-de-puesta-en-marcha)
- [9. Mantenimiento](#9-mantenimiento)

---

## 1. Las tres cosas que determinan la calidad

La calidad de lo que el RAG aporta a una validación depende, **en este orden**:

| # | Factor | Impacto | ¿Está resuelto? |
|---|---|---|---|
| 1 | **Qué documentos hay en `inputs/rag/<dominio>/`** | Decisivo | ❌ **Aquí está el trabajo** |
| 2 | Que el vocabulario del corpus coincida con el del estándar | Alto | ⚠️ Medible, ver §7 |
| 3 | El motor de recuperación (BM25, pesos, chunking) | Moderado | ✅ Hecho y probado |

El punto 3 es el único que estaba resuelto cuando empezó esto, y es **el que menos
importa**. Un motor perfecto sobre un corpus vacío devuelve nada; un motor decente
sobre buena literatura devuelve mucho.

> **La consecuencia práctica:** no gastes tiempo ajustando `RAG_PESO_BM25`. Gasta
> tiempo consiguiendo los PDF.

---

## 2. Punto de partida: dónde estás hoy

Ejecuta esto ahora mismo:

```bash
python scripts/rebuild_rag_databricks.py --status
python scripts/auditar_cobertura_rag.py --dominio shared
```

**Línea base medida el 2026-07-31** (32 actividades del estándar, Tier I):

| dominio | docs | fragmentos | frag./actividad | apoyo sólido | sin apoyo |
|---|---|---|---|---|---|
| `shared` | 3 | 16 | 0.5 | **62 %** | 0 |
| `VaR` | 3 | 12 | 0.4 | **56 %** | 1 |
| `LaR` | 2 | 9 | 0.3 | **62 %** | 1 |
| `conductuales` | 1 | 6 | 0.2 | **31 %** | 4 |

Y el aviso que sale en los cuatro:

```
⚠️  CORPUS POCO PROFUNDO: 12 fragmentos para 32 actividades (0.4 por actividad).
```

**Cómo interpretarlo.** Los PDF de `inputs/rag/` **no son los estándares reales**:
son documentos de apoyo de ~6 KB generados por `scripts/generar_corpus_rag.py`, y
ellos mismos lo declaran en su primera línea:

> *AVISO. RESUMEN SECUNDARIO — NO ES EL TEXTO OFICIAL. Documento de apoyo generado
> para dar contexto de dominio al agente VIRF. Sin valor normativo.*

Sirven para que el sistema funcione y se pueda probar. **No sirven para citar en
una validación real.** Ése es el trabajo que queda.

---

## 3. Qué documentos poner, y en qué dominio

`inputs/rag/` es **literatura de referencia externa**: lo que un validador
consultaría para saber qué se espera de un modelo. No es la evidencia del modelo
—eso va en `inputs/documentacion/`— y confundirlas corrompe la validación (§4).

### `shared/` — aplica a cualquier modelo

| Documento | Por qué |
|---|---|
| **SR 11-7** (Fed/OCC) — *Supervisory Guidance on Model Risk Management* | La referencia de gestión de riesgo de modelo. Gobierna casi todo el ámbito «Gobierno» |
| **BCBS 239** — *Principios para la agregación eficaz de datos de riesgo* | Ámbito «Calidad de datos» completo |
| **EBA/GL/2023/01** — directrices de la EBA | Expectativas supervisoras europeas |
| Guía de validación interna de tu supervisor (Banco de España / BCE / SBS…) | Es la vara con la que te van a medir a ti |
| Política interna de riesgo de modelo de la entidad | Lo que tu comité exige, que suele ser más estricto |

### `VaR/` — riesgo de mercado

| Documento | Por qué |
|---|---|
| **BCBS 457 (FRTB)** — *Minimum capital requirements for market risk* | Backtesting, PLAT, horizontes de liquidez, NMRF |
| **Kupiec (1995)** — *Techniques for verifying the accuracy of risk measurement models* | La prueba de cobertura incondicional, con su fórmula |
| **Christoffersen (1998)** — *Evaluating interval forecasts* | Cobertura condicional e independencia |
| **RiskMetrics Technical Document** (JP Morgan, 1996) | EWMA, VaR paramétrico, supuestos de normalidad |
| Basilea — marco de backtesting (zonas verde/amarilla/roja) | El multiplicador de capital por excepciones |

### `LaR/` — liquidez

| Documento | Por qué |
|---|---|
| **BCBS 238 (LCR)** y **BCBS 295 (NSFR)** | Definición de HQLA, salidas netas, financiación estable |
| Directrices de **ILAAP** de tu supervisor | Marco de autoevaluación de liquidez |
| Literatura de *stress testing* de liquidez | Escenarios, supuestos de retirada |

### `conductuales/` — modelos de comportamiento

| Documento | Por qué |
|---|---|
| **BCBS/EBA sobre IRRBB** | Depósitos sin vencimiento (NMD), repreciación conductual |
| **EBA GL sobre IRRBB y CSRBB** | Supuestos conductuales y sus límites |
| Literatura de *prepayment modelling* | Prepago, amortización anticipada |

> **Éste es el más flojo hoy (31 % de apoyo sólido, 1 solo documento).** Si validas
> modelos conductuales, empieza por aquí.

### Formatos admitidos

`.pdf` · `.docx` · `.pptx` · `.xlsx` · `.txt` · `.md`

> ⚠️ **Un PDF escaneado NO se puede leer.** El OCR se retiró por la misma política
> que echó a HuggingFace (Tesseract lleva sus propios modelos). Un PDF escaneado
> queda fuera del índice — no falla en silencio, pero tampoco aporta. Consíguelo
> en digital.

---

## 4. Reglas del corpus (las que evitan corromper la validación)

Estas cuatro no son estilo. Cada una corrige un fallo que ya ocurrió.

### Regla 1 — NUNCA metas la evidencia del modelo que validas

`inputs/rag/` es literatura **externa e independiente**. Si metes ahí el manual
metodológico del modelo bajo validación, pasa esto:

> Ante la actividad *«¿el manual documenta el backtesting?»*, el RAG recupera
> fragmentos **del propio manual** y los inyecta como «conocimiento recuperado del
> dominio». El modelo ve sus propias afirmaciones presentadas como **referencia
> autorizada que las confirma**. El agente se da la razón a sí mismo.

Es razonamiento circular, y el informe resultante no es defendible.

### Regla 2 — Cada dominio, su literatura

Los cuatro dominios apuntaron una vez a las mismas carpetas. Resultado medido:
consultando el índice de VaR sobre backtesting FRTB, los tres primeros resultados
eran del manual de **LaR**, con similitud 0.88. Validar un VaR inyectaba el manual
de un modelo de liquidez como conocimiento experto de mercado.

### Regla 3 — Documentos completos, no resúmenes

Es contraintuitivo, pero la búsqueda es **léxica**: encuentra por coincidencia de
término. Un resumen pierde justo los tecnicismos literales —«Kupiec»,
«excedencia», «HQLA de Nivel 2B»— sobre los que BM25 busca.

**El texto completo es mejor corpus que un buen resumen.** No hace falta trocearlo
tú: el indexador lo hace.

### Regla 4 — Marca lo que no sea oficial

Si por licencia solo puedes incluir un resumen, dilo **dentro del documento**
(los actuales lo hacen). Ese aviso se indexa con el texto y viaja al prompt, así
que el modelo sabe que no está citando la fuente primaria.

> Los `README.md` de cada carpeta se excluyen automáticamente del índice: explican
> qué va ahí, y sin excluirlos una consulta podría recuperar *«Qué NO va aquí: la
> evidencia del modelo…»* y presentarlo como referencia experta.

---

## 5. El ciclo de mejora, paso a paso

```
   ┌─────────────────────────────────────────────────────────────┐
   │  1. MEDIR      auditar_cobertura_rag.py  → línea base       │
   │                                                             │
   │  2. AÑADIR     copiar documentos a inputs/rag/<dominio>/     │
   │                                                             │
   │  3. INDEXAR    rebuild_rag_databricks.py --dominio all --force│
   │                                                             │
   │  4. RE-MEDIR   auditar_cobertura_rag.py  → ¿subió?           │
   │                                                             │
   │  5. DIAGNOSTICAR  explicar_rag.py sobre lo que siga ciego    │
   └──────────────────────────┬──────────────────────────────────┘
                              └──── repetir hasta que el resto
                                    sea conocido y aceptado
```

### Paso 1 — Medir antes de tocar nada

```bash
python scripts/auditar_cobertura_rag.py --dominio VaR --json base_VaR.json
```

Guarda el JSON. Sin línea base no sabrás si lo que añadiste sirvió.

### Paso 2 — Añadir documentos

```bash
cp ~/Descargas/BCBS457_FRTB.pdf  "inputs/rag/VaR/"
```

Nombra los ficheros de forma legible: **el nombre aparece en el informe** como
fuente de la cita. `FRTB_BCBS457_riesgo_mercado.pdf` es mejor que `d457.pdf`.

### Paso 3 — Reindexar

```bash
python scripts/rebuild_rag_databricks.py --dominio all --force
```

`--force` reextrae los PDF. Sin él, un índice cuya huella coincide se reutiliza.

> Tarda segundos, no minutos, y **no gasta ni una llamada a la API**: la
> indexación es 100 % local.

### Paso 4 — Volver a medir

```bash
python scripts/auditar_cobertura_rag.py --dominio VaR --json tras_frtb.json
```

Compara `sólido` y `sin apoyo` con la línea base.

### Paso 5 — Diagnosticar lo que siga ciego

La auditoría lista las actividades sin apoyo y el vocabulario ausente. Para
cualquiera de ellas:

```bash
python scripts/explicar_rag.py --dominio VaR \
    --consulta "[Metodología] Analizar el seguimiento de la metodología"
```

Te dirá si el problema es del corpus (Σ IDF alto pero 0 resultados) o de la
consulta (Σ IDF bajo). **Son fallos opuestos y piden acciones opuestas.**

---

## 6. Cómo leer la auditoría

```
ámbito                            act.  cubiertas  débiles  SIN APOYO
Documentación                        9          4        5          0
...
  Apoyo documental: 97% (56% sólido, con ≥2 términos de anclaje)
```

| Estado | Qué significa | Qué hacer |
|---|---|---|
| **CUBIERTA** | Cobertura ≥ 0.50 **y** ≥ 2 términos de anclaje | Nada |
| **DÉBIL** | Hay solape, pero genérico o escaso | Añadir literatura específica de ese ámbito |
| **SIN APOYO** | Nada, o solo palabras vacías | Prioridad 1 |

### Por qué existe el «anclaje» (y por qué la primera versión mentía)

La primera versión de la auditoría clasificaba solo por cobertura y daba **97 %
sólido** para un corpus de tres documentos de 6 KB. Al mirar **qué términos**
producían esa cobertura, apareció el truco:

```
«Verifica la existencia de control de cambios/versiones»  →  cobertura 0.50
 …porque el fragmento contiene la palabra «documentación». Y nada más.
```

La cobertura es una fracción del peso informativo, así que **un solo término
frecuente basta para llenarla** cuando el resto de la consulta no existe en el
corpus. Es cierto que el fragmento cubre esa fracción; es falso que la literatura
apoye la actividad.

Por eso «CUBIERTA» exige ahora **≥ 2 términos distintos con IDF > 0**. Con ese
cambio, VaR pasó de «97 % sólido» a **56 %** — que es la verdad.

> **Un informe de auditoría que se equivoca hacia arriba es peor que no tenerlo:
> da por resuelto justo lo que hay que arreglar.**

### El aviso de profundidad

```
⚠️  CORPUS POCO PROFUNDO: 12 fragmentos para 32 actividades (0.4 por actividad)
```

Sale por debajo de 60 fragmentos o 2 por actividad. Mientras esté, **cualquier
porcentaje bueno es sospechoso**: con tan poco texto, las cifras miden solape de
vocabulario general más que apoyo real.

**Referencia práctica:** un BCBS completo produce del orden de 150–400 fragmentos.
Con 3–4 documentos reales por dominio, el aviso desaparece solo.

---

## 7. Los dos hallazgos que ya salieron

La auditoría encontró esto en su primera ejecución, sin buscarlo:

### Hallazgo 1 — Hay erratas en `Estandares_VIRF.xlsx`

En la lista de vocabulario ausente aparecieron palabras que **no existen en
español**:

| En el estándar | Debería decir | Efecto |
|---|---|---|
| `seguimeinto` | seguimiento | La actividad *«Analizar el seguimeinto de la metodología»* es la **única sin apoyo** en VaR y LaR |
| `metodolocio` | metodológico | Nunca casará con nada |
| `monitorio` | monitoreo | Íd. |
| `suficienica` | suficiencia | Íd. |

Una errata en el estándar es un término que **no puede coincidir con ninguna
literatura, nunca**. No es un problema del RAG: corrígelas en el Excel y esas
actividades recuperarán contexto sin tocar una línea de código.

> Corrígelas en `inputs/Estandares_VIRF.xlsx` y vuelve a auditar. Es la mejora de
> mejor relación coste/beneficio de toda esta guía.

### Hallazgo 2 — El estándar y la literatura hablan idiomas distintos

El vocabulario ausente está dominado por **verbos de instrucción**: `verificar`,
`revisar`, `exista`, `solicitar`, `aplique`. Es esperable —el estándar dice *qué
hacer*, la literatura dice *qué es*— y no es un problema: esos términos tienen
IDF 0 y **no penalizan** la cobertura.

Pero hay un caso que sí importa, y está documentado en
[`GUIA_RAG_LEXICO.md` §6](GUIA_RAG_LEXICO.md#6-dónde-falla-el-caso-excepciones):

```
tokenizar("excepciones")  →  ['excepcion']   df = 0    ← el estándar
tokenizar("excedencias")  →  ['exced']       df = 8    ← la literatura
```

**Son sinónimos exactos en backtesting de VaR**, y la búsqueda léxica no los une.
Cuando la auditoría te muestre un término huérfano que *deberías* encontrar,
comprueba con qué palabra lo dice el documento y **alinea el vocabulario del
estándar con el de la literatura**.

---

## 8. Checklist de puesta en marcha

```
[ ]  1. Conseguir los documentos reales (§3). Prioridad: conductuales < LaR < VaR
[ ]  2. Verificar que ninguno sea evidencia del modelo a validar (Regla 1)
[ ]  3. Nombrarlos de forma legible: aparecen como fuente en el informe
[ ]  4. Comprobar que ningún PDF sea escaneado (no hay OCR)
[ ]  5. Corregir las erratas de Estandares_VIRF.xlsx (§7, hallazgo 1)
[ ]  6. python scripts/rebuild_rag_databricks.py --dominio all --force
[ ]  7. python scripts/rebuild_rag_databricks.py --status      → los 4 ✅
[ ]  8. python scripts/auditar_cobertura_rag.py --dominio <cada uno>
[ ]  9. ¿Desapareció el aviso de CORPUS POCO PROFUNDO?
[ ] 10. Revisar la lista de actividades SIN APOYO: ¿falta literatura o es errata?
[ ] 11. Anotar en el informe de validación qué ámbitos quedan sin apoyo documental
[ ] 12. python validate_project.py --strict   → sigue en verde
```

> El punto **11 no es burocracia**: es lo que hace defendible el dictamen. Un
> ámbito evaluado sin literatura de referencia es una limitación del alcance, y
> declararla es obligación del validador — no del agente.

---

## 9. Mantenimiento

| Cuándo | Qué hacer |
|---|---|
| Sale una versión nueva de un estándar | Sustituir el PDF y `--force`. La huella detecta el cambio sola |
| Se añade un ámbito o actividad al estándar | Volver a auditar: puede aparecer un hueco nuevo |
| Cada 6 meses | Auditar los 4 dominios y guardar el JSON como evidencia de la revisión |
| Antes de una validación importante | Auditar el dominio que toque y anotar los huecos en el informe |

```bash
# Rutina completa
python scripts/rebuild_rag_databricks.py --dominio all --force
for d in LaR VaR conductuales shared; do
  python scripts/auditar_cobertura_rag.py --dominio $d --json "auditoria_$d.json"
done
```

---

## Resumen

1. **El corpus manda.** El motor ya está resuelto y probado; el trabajo está en
   `inputs/rag/`.
2. **Los documentos actuales son de apoyo, no oficiales.** Sustituirlos por los
   estándares reales es el paso con más impacto de todos.
3. **Mide antes y después.** `auditar_cobertura_rag.py` te dice qué actividades
   quedan a ciegas; `explicar_rag.py` te dice por qué.
4. **Corrige las erratas del Excel del estándar.** Coste casi nulo, efecto directo.
5. **El objetivo no es que no queden huecos, sino saber cuáles hay** y declararlos
   en el informe. Eso es lo que un supervisor acepta; «100 % cubierto» sin
   evidencia, no.
