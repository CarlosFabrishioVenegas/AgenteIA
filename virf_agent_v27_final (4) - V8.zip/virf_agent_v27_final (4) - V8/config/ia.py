"""
config/ia.py  [v27.2]
═════════════════════════════════════════════════════════════════════════════
Clientes IA: interfaz agnóstica de proveedor + factory con caché de proceso.

Soporta Anthropic Claude y Azure OpenAI. Los SDK se importan de forma perezosa
dentro de cada constructor: importar este módulo NO exige tener instalados
ambos proveedores.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from .parametros import (
    ANTHROPIC_MAX_TOKENS,
    ANTHROPIC_MODELO,
    AZURE_API_VERSION,
    AZURE_MAX_TOKENS,
    IA_PROVEEDOR,
    IA_TEMPERATURE,
    OPENAI_MAX_TOKENS,
    OPENAI_MODELO,
    VALIDAR_CONEXION,
)
from .red import cliente_http as _cliente_http, con_reintento as _con_reintento, diagnostico_https
from .rutas import BASE_DIR
from .secretos import obtener_secreto as _obtener_secreto


def _secreto(nombre: str) -> str:
    """[SEG-03] Credencial desde Key Vault / secret scope / entorno de proceso
    (nunca desde el .env). Vacío si no hay: cada cliente da su propio mensaje."""
    return _obtener_secreto(nombre, obligatorio=False)


__all__ = [
    "ClienteIA", "ClienteAnthropicIA", "ClienteAzureOpenAIIA",
    "ClienteOpenAIIA", "virf_plus_activo",
    "FABRICAS", "get_cliente_ia", "reset_cliente_ia",
    "prueba_de_humo",
    "METADATOS_PROVEEDOR", "metadatos_proveedor",
    "diagnostico_https",
    "PROVEEDORES", "ProveedorNoAutorizado", "autorizar_proveedor",
    "PROVEEDORES_SOLO_DESARROLLO", "estado_efectivo", "proveedor_autorizado",
    "proveedores_autorizados", "proveedor_activo", "modelo_activo",
    "material_no_confiable", "llamar_ia",
]


_PLACEHOLDERS = {"TU_API_KEY_AQUI", "YOUR_REAL_API_KEY_HERE_NEVER_COMMIT",
                 "tu-api-key", "tu_api_key", "xxx"}
_TROZOS_PLACEHOLDER = ("YOUR_REAL", "TU_API_KEY", "NEVER_COMMIT", "your_key",
                       "placeholder")


def _es_placeholder(api_key: Optional[str]) -> bool:
    """¿Clave vacía o de plantilla? Una así no cuenta como «clave presente»."""
    return (not api_key or api_key in _PLACEHOLDERS
            or any(t in api_key for t in _TROZOS_PLACEHOLDER))


def _detectar_key_en_example(api_key: str) -> Optional[str]:
    """
    [SEC-FIX] Devuelve la ruta de .env.example si la clave activa aparece
    literalmente en él (indicio de clave real commiteada). None si está limpio.

    Se compara solo si la clave tiene pinta de credencial real (>20 chars),
    para no disparar falsos positivos con placeholders cortos.
    """
    if not api_key or len(api_key) < 20:
        return None
    ejemplo = BASE_DIR / ".env.example"
    try:
        if ejemplo.exists() and api_key in ejemplo.read_text(
            encoding="utf-8", errors="ignore"
        ):
            return str(ejemplo)
    except Exception:
        pass
    return None


# ═════════════════════════════════════════════════════════════════════════════
# GATEWAY ÚNICO DE SALIDA A IA (SEG-05)
# ═════════════════════════════════════════════════════════════════════════════
# Toda llamada a un LLM termina en `ClienteIA.generar_mensaje` de alguna
# subclase. `ClienteIA.__init_subclass__` ENVUELVE ese método en cada subclase,
# así que ningún módulo puede llegar al proveedor sin pasar por aquí — aunque
# instancie el cliente directamente o lo reciba inyectado. En cada llamada:
#
#   (a) enmascara PII (modulos/pii.py) en el prompt y en la instrucción de sistema;
#   (b) neutraliza instrucciones inyectadas (modulos/inyeccion.py) DENTRO de los
#       bloques de material no confiable que el llamante delimita con
#       `material_no_confiable()` — no en el prompt entero, porque las plantillas
#       propias contienen a propósito frases como «actúa como» o «ignora las
#       instrucciones» (que describen el ataque al modelo) y neutralizarlas
#       corrompería el prompt del sistema;
#   (c) autoriza el proveedor contra la lista cerrada (`autorizar_proveedor`);
#   (d) registra la llamada en el log de auditoría (solo metadatos, nunca texto).
#
# Los SDK de proveedor (anthropic, openai) solo se importan en este archivo; el
# test de arquitectura tests/test_gateway_ia.py falla si aparecen en otro lugar.

import contextvars as _contextvars
import functools as _functools
import inspect as _inspect
import logging as _logging
import re as _re

_log_auditoria_ia = _logging.getLogger("virf.auditoria.ia")

from modulos.salida_ia import (  # noqa: E402  (módulo hoja: sin ciclos)
    MARCA_FIN_MATERIAL, MARCA_INI_MATERIAL, material_no_confiable,
    sanear_salida as _sanear_salida)

# Profundidad de gateway en el hilo/tarea actual: VIRF PLUS llama a dos
# clientes desde dentro de su propio generar_mensaje; el saneado se hace una
# vez (en la capa externa) y la autorización de proveedor en CADA capa.
_EN_GATEWAY: "_contextvars.ContextVar[int]" = _contextvars.ContextVar(
    "virf_en_gateway_ia", default=0)


# ── (c) Lista cerrada de proveedores (SEG-01) ─────────────────────────────────
# Decisión del banco (norma 2135.010.02 §Adquisición a terceros · 4180.223.02
# §Uso aceptable). Solo el banco cambia un estado; el código no lo infiere de
# variables de entorno ni de qué claves haya configuradas.
PROVEEDORES = {
    "azure_openai": "APROBADO",
    "anthropic":    "EN_ESPERA",    # standby hasta diciembre
    "openai":       "RETIRADO",
}


class ProveedorNoAutorizado(ValueError):
    """El proveedor no está APROBADO en la lista cerrada. Hereda de ValueError
    para que los llamantes lo traten como error de configuración (se muestra
    con su mensaje, no se reintenta ni se degrada a otro proveedor)."""


# ── Fuera de producción: proveedores en evaluación ────────────────────────────
# [2026-11-11 · decisión del responsable del proyecto] La lista cerrada de
# arriba es la que rige en PRODUCCIÓN y no cambia. En desarrollo (MODO=debug |
# desarrollo) los proveedores de esta tupla también pueden ejecutarse, para
# poder probar el agente —y VIRF PLUS— con la clave que se tenga a mano.
#
# Sigue siendo una lista cerrada en código: un proveedor no catalogado no se
# abre nunca, y qué claves haya configuradas NO cambia qué está permitido, solo
# cuál de los permitidos se usa (`proveedor_activo`). Cualquier MODO que no sea
# explícitamente de desarrollo cuenta como producción (falla cerrado).
PROVEEDORES_SOLO_DESARROLLO = ("anthropic", "openai")
_MODOS_DESARROLLO = ("debug", "desarrollo")
_AVISADOS_DESARROLLO: set = set()


def _en_produccion() -> bool:
    from . import parametros as _par
    return str(getattr(_par, "MODO", "produccion")).strip().lower() not in _MODOS_DESARROLLO


def estado_efectivo(proveedor: Optional[str]) -> str:
    """Estado de un proveedor EN ESTE PROCESO: el de la lista cerrada, o
    `SOLO_DESARROLLO` si está en evaluación y no se corre en producción."""
    clave = proveedor if isinstance(proveedor, str) else None
    estado = PROVEEDORES.get(clave) if clave else None
    if estado is None:
        return "NO_CATALOGADO"
    if (estado != "APROBADO" and clave in PROVEEDORES_SOLO_DESARROLLO
            and not _en_produccion()):
        return "SOLO_DESARROLLO"
    return estado


def proveedor_autorizado(proveedor: Optional[str]) -> bool:
    """¿Puede ejecutarse este proveedor en este proceso?"""
    return estado_efectivo(proveedor) in ("APROBADO", "SOLO_DESARROLLO")


def proveedores_autorizados() -> list:
    """Proveedores que pueden ejecutarse en este proceso, en orden de catálogo."""
    return [p for p in PROVEEDORES if proveedor_autorizado(p)]


def autorizar_proveedor(proveedor: Optional[str]) -> None:
    """Lanza ProveedorNoAutorizado si `proveedor` no puede ejecutarse aquí."""
    estado = estado_efectivo(proveedor)
    if estado == "APROBADO":
        return
    if estado == "SOLO_DESARROLLO":
        if proveedor not in _AVISADOS_DESARROLLO:
            _AVISADOS_DESARROLLO.add(proveedor)
            print(f"  ⚠️  Proveedor de IA «{proveedor}»: permitido solo fuera de producción "
                  f"(el banco lo tiene en {PROVEEDORES.get(proveedor)}). No envíes "
                  "evidencia real del banco; en MODO=produccion queda bloqueado.")
        return
    aprobados = ", ".join(proveedores_autorizados())
    raise ProveedorNoAutorizado(
        f"❌ Proveedor de IA {proveedor!r} no autorizado por el banco "
        f"(estado: {estado}). Solo puede usarse: {aprobados}. "
        "El estado de un proveedor lo actualiza el banco en config/ia.py "
        "(PROVEEDORES), no la configuración local."
        + (" Fuera de producción (MODO=debug) sí se permite, para pruebas."
           if proveedor in PROVEEDORES_SOLO_DESARROLLO else ""))


def _origen_llamada() -> str:
    """Módulo:línea que llamó al gateway, para la auditoría."""
    for fr in _inspect.stack()[2:8]:
        nombre = Path(fr.filename).name
        if nombre not in ("ia.py", "virf_plus.py", "functools.py"):
            return f"{nombre}:{fr.lineno}"
    return "desconocido"


def _uso_y_coste(cliente, prompt: str, respuesta: str) -> dict:
    """[Paso 57] Tokens (reales si el cliente los expone; si no, estimados por
    caracteres y marcados como tales), modelo y coste estimado."""
    from .modelos import CHARS_POR_TOKEN_ES, coste_usd
    uso = dict(getattr(cliente, "ultimo_uso", None) or {})
    modelo = uso.get("modelo") or getattr(cliente, "deployment", None) \
        or getattr(cliente, "modelo", None) or type(cliente).__name__
    ent, sal = uso.get("entrada"), uso.get("salida")
    estimado = ent is None or sal is None
    if ent is None:
        ent = int(len(prompt or "") / CHARS_POR_TOKEN_ES)
    if sal is None:
        sal = int(len(respuesta or "") / CHARS_POR_TOKEN_ES)
    return {"modelo": str(modelo), "tokens_entrada": int(ent), "tokens_salida": int(sal),
            "tokens_estimados": estimado, "coste_usd": coste_usd(modelo, ent, sal)}


def _registrar_llamada(cliente, prompt: str, pii, iny, resultado: str,
                       respuesta: str = "", latencia_ms: Optional[int] = None) -> None:
    """(d) Una entrada por llamada. Solo metadatos: nunca prompt ni respuesta.
    [Paso 54/57] Incluye modelo, tokens, latencia, corrida y coste en la MISMA
    entrada de la bitácora."""
    try:
        from modulos.auditoria import registrar as _registrar
    except Exception:                                   # noqa: BLE001
        _registrar = None
    evento = {
        "accion": "llamada_ia",
        "proveedor": getattr(cliente, "PROVEEDOR", None) or type(cliente).__name__,
        "origen": _origen_llamada(),
        "chars_prompt": len(prompt or ""),
        "pii": {h["tipo"]: h["n"] for h in pii},
        "inyeccion": len(iny),
        "resultado": resultado,
        "corrida": os.getenv("VIRF_ID_CORRIDA", ""),
        "latencia_ms": latencia_ms,
    }
    if getattr(type(cliente), "COMPUESTO", False):
        # VIRF PLUS: los tokens y el coste ya constan en la entrada de cada
        # proveedor interno (GPT, Claude y árbitro). Sumarlos aquí otra vez
        # duplicaría el gasto en el dataset de costes.
        evento.update({"modelo": str(getattr(cliente, "descripcion", "compuesto")),
                       "tokens_entrada": 0, "tokens_salida": 0,
                       "tokens_estimados": False, "coste_usd": 0.0,
                       "compuesto": True})
    else:
        try:
            evento.update(_uso_y_coste(cliente, prompt, respuesta))
        except Exception:                               # noqa: BLE001
            pass
    _log_auditoria_ia.info("llamada_ia %s", evento)
    if _registrar is not None:
        try:
            _registrar(**evento)
        except Exception:                               # noqa: BLE001
            pass


def _envolver_gateway(fn):
    """Envuelve el `generar_mensaje` concreto de un proveedor."""
    firma = _inspect.signature(fn)

    @_functools.wraps(fn)
    def generar_mensaje(self, *args, **kwargs):
        if getattr(type(self), "COMPUESTO", False) is False:
            autorizar_proveedor(getattr(self, "PROVEEDOR", None))
        if _EN_GATEWAY.get() > 0:                       # ya saneado en la capa externa
            return fn(self, *args, **kwargs)

        ligado = firma.bind(self, *args, **kwargs)
        pii_tot, iny_tot = [], []
        for campo in ("prompt", "instruccion_sistema", "sistema"):
            if campo in ligado.arguments:
                limpio, pii, iny = _sanear_salida(ligado.arguments[campo])
                ligado.arguments[campo] = limpio
                pii_tot += pii
                iny_tot += iny
        prompt = ligado.arguments.get("prompt") or ""
        token = _EN_GATEWAY.set(_EN_GATEWAY.get() + 1)
        import time as _time
        t0 = _time.perf_counter()
        try:
            respuesta = fn(*ligado.args, **ligado.kwargs)
        except Exception as exc:
            _registrar_llamada(self, prompt, pii_tot, iny_tot,
                               f"error:{type(exc).__name__}",
                               latencia_ms=int((_time.perf_counter() - t0) * 1000))
            raise
        finally:
            _EN_GATEWAY.reset(token)
        _registrar_llamada(self, prompt, pii_tot, iny_tot, "ok",
                           respuesta=respuesta if isinstance(respuesta, str) else "",
                           latencia_ms=int((_time.perf_counter() - t0) * 1000))
        return respuesta

    generar_mensaje.__virf_gateway__ = True
    return generar_mensaje


def llamar_ia(prompt: str, adjuntos=(), contexto: str = "", sistema: str = "",
              max_tokens: Optional[int] = None, formato_json: bool = False,
              cliente: "Optional[ClienteIA]" = None) -> str:
    """
    Fachada del gateway para código nuevo: `prompt` es la instrucción propia;
    `contexto` y cada elemento de `adjuntos` (texto, o tupla (origen, texto))
    se tratan como material no confiable.
    """
    partes = [prompt]
    if contexto:
        partes.append(material_no_confiable(contexto, "contexto"))
    for i, adj in enumerate(adjuntos or (), 1):
        origen, texto = adj if isinstance(adj, tuple) else (f"adjunto_{i}", adj)
        partes.append(material_no_confiable(texto, origen))
    cli = cliente if cliente is not None else get_cliente_ia()
    return cli.generar_mensaje(prompt="\n\n".join(partes), instruccion_sistema=sistema,
                               max_tokens=max_tokens, formato_json=formato_json)


class ClienteIA(ABC):
    """Interfaz abstracta para clientes IA"""

    # Nombre del proveedor en la lista cerrada (SEG-01). Lo fija cada subclase.
    PROVEEDOR: Optional[str] = None
    # True en clientes que solo orquestan a otros (VIRF PLUS): la autorización
    # se aplica a cada cliente interno.
    COMPUESTO: bool = False

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        fn = cls.__dict__.get("generar_mensaje")
        if fn is not None and not getattr(fn, "__isabstractmethod__", False) \
                and not getattr(fn, "__virf_gateway__", False):
            cls.generar_mensaje = _envolver_gateway(fn)

    @abstractmethod
    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        """
        Genera respuesta. Devuelve SIEMPRE `str`.

        `formato_json=True` pide al proveedor JSON sintácticamente válido si lo
        soporta (Azure OpenAI sí; Anthropic no). Los clientes que no lo
        soporten deben IGNORARLO, nunca fallar: el negocio no puede depender de
        qué proveedor hay detrás.
        """

    # [AUDIT-FIX] `validar_conexion()` solo devolvía True/False y el motivo se
    # perdía: get_cliente_ia() levantaba entonces un RuntimeError genérico
    # ("No se pudo conectar a ANTHROPIC") sin rastro del 401. El PRE-FLIGHT de
    # agente.py decide abortar-o-seguir buscando "401" en ese mensaje, así que
    # una clave rechazada se tomaba por un corte de red pasajero: la corrida
    # continuaba, cargaba toda la evidencia y moría 300 líneas después con un
    # traceback crudo. Se conserva el motivo para que el llamante pueda decidir.
    ultimo_error_conexion: str = ""

    @abstractmethod
    def validar_conexion(self) -> bool:
        """Valida conexión a la API. El motivo del fallo queda en
        `ultimo_error_conexion`."""


# ─── Anthropic Claude ──────────────────────────────────────────────────────

class ClienteAnthropicIA(ClienteIA):
    """Cliente para Anthropic Claude"""

    PROVEEDOR = "anthropic"

    # [MODELO-FIX] Atributo de CLASE (no de instancia): los tests construyen este
    # cliente sin pasar por __init__, así que el default debe existir a nivel de
    # clase. Los modelos Claude actuales (Opus 5, Sonnet 5, Opus 4.7/4.8, Fable 5)
    # RECHAZAN `temperature` con un 400; al detectarlo se memoriza por instancia.
    _omitir_temperature = False

    def __init__(self):
        try:
            import anthropic
        except ImportError:
            raise ImportError("❌ pip install anthropic")

        api_key = _secreto("ANTHROPIC_API_KEY")

        # [v17] Detectar keys vacías O placeholders antes de cualquier llamada API
        if _es_placeholder(api_key):
            raise ValueError(
                "\n"
                "❌ ANTHROPIC_API_KEY no está configurada o contiene un placeholder.\n"
                "\n"
                "   Cómo solucionarlo (la clave NO va en el .env: se rechaza):\n"
                "   · Desarrollo: defínela como variable de entorno del proceso,\n"
                "     p. ej. en PowerShell  $env:ANTHROPIC_API_KEY = \"sk-ant-api03-...\"\n"
                "     con MODO=debug y VIRF_FUENTE_SECRETOS=entorno.\n"
                "   · Producción: Key Vault (y solo si el banco aprueba el proveedor).\n"
                "   Obtén tu clave en: https://console.anthropic.com/\n"
            )

        # [SEC-FIX] Guardia anti-fuga: si la clave activa es la misma que aparece
        # en .env.example, significa que alguien commiteó una clave real (o que
        # el usuario copió la plantilla sin cambiarla). Abortamos y avisamos.
        _leak = _detectar_key_en_example(api_key)
        if _leak:
            raise ValueError(
                "\n"
                "🔴 RIESGO DE SEGURIDAD: la ANTHROPIC_API_KEY en uso es idéntica a\n"
                f"   la que aparece en {_leak}\n"
                "\n"
                "   .env.example SE COMMITEA al repositorio → esa clave está expuesta.\n"
                "\n"
                "   Acciones requeridas:\n"
                "   1. Revoca la clave en https://console.anthropic.com/settings/keys\n"
                "   2. Genera una nueva y ponla SOLO en .env (nunca en .env.example)\n"
                "   3. Deja en .env.example el placeholder: ANTHROPIC_API_KEY=TU_API_KEY_AQUI\n"
            )

        # [WORKSPACE-FIX] Las claves "identity-linked" (ligadas a un usuario, no a
        # un workspace) exigen el header `anthropic-workspace-id` o la API devuelve
        # 400 (invalid_request_error). Es OPCIONAL: solo se envía si el operador
        # define ANTHROPIC_WORKSPACE_ID. Una clave ESTÁNDAR de workspace
        # (sk-ant-api03-…) NO lo necesita y este bloque no se activa. No afecta a
        # Azure ni a claves normales.
        _kwargs = {"api_key": api_key}
        _ws = os.getenv("ANTHROPIC_WORKSPACE_ID", "").strip()
        if _ws:
            _kwargs["default_headers"] = {"anthropic-workspace-id": _ws}
        self.cliente = anthropic.Anthropic(**_kwargs)
        self.modelo = ANTHROPIC_MODELO
        self.max_tokens_default = ANTHROPIC_MAX_TOKENS

    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        """
        Genera mensaje con soporte para parámetros alternativos.

        `formato_json` se ACEPTA e IGNORA: la API de Anthropic no tiene un
        equivalente a `response_format={"type":"json_object"}`. Ignorarlo —en
        vez de fallar— es lo que permite que el código de negocio pida JSON
        garantizado sin saber qué proveedor hay detrás; con Anthropic el
        respaldo sigue siendo el parser robusto (`_extraer_json`).
        """
        sys_prompt = sistema or instruccion_sistema or "Eres un auditor experto."
        tokens = max_tokens or self.max_tokens_default

        def _crear(incluir_temp: bool):
            # [AUDIT-FIX 2026-08-07] `temperature` se fija (config.IA_TEMPERATURE):
            # el default de Anthropic es 1.0 y la misma evidencia daría dictámenes
            # distintos, que un validador no puede firmar. [MODELO-FIX] Pero los
            # modelos Claude actuales la RECHAZAN (400): en ellos se omite y su
            # propio default ya es determinista.
            kwargs = dict(
                model=self.modelo,
                max_tokens=tokens,
                system=sys_prompt,
                messages=[{"role": "user", "content": prompt}],
            )
            if incluir_temp:
                kwargs["temperature"] = IA_TEMPERATURE
            return self.cliente.messages.create(**kwargs)

        try:
            response = _crear(incluir_temp=not self._omitir_temperature)
        except Exception as e:
            # Si la API rechaza `temperature`, se reintenta sin ella y se memoriza
            # para el resto del proceso (una sola vez). Cualquier otro error se
            # propaga con el mensaje original.
            if "temperature" in str(e).lower() and not self._omitir_temperature:
                self._omitir_temperature = True
                try:
                    response = _crear(incluir_temp=False)
                except Exception as e2:
                    raise RuntimeError(f"❌ Error Anthropic: {e2}")
            else:
                raise RuntimeError(f"❌ Error Anthropic: {e}")

        # [AUDIT-FIX] `content` puede llegar VACÍO — la API responde 200 con
        # content=[] cuando el modelo rehúsa la petición (stop_reason="refusal")
        # o cuando max_tokens no deja sitio para el primer bloque. Antes esto
        # era `content[0].text` dentro del try: el IndexError salía disfrazado
        # de "❌ Error Anthropic: list index out of range", que no dice nada al
        # operador y parece un fallo de red.
        contenido = getattr(response, "content", None) or []
        # [Paso 57] Tokens reales de la respuesta, para el coste por llamada.
        _uso = getattr(response, "usage", None)
        self.ultimo_uso = {"modelo": getattr(self, "modelo", None),
                           "entrada": getattr(_uso, "input_tokens", None),
                           "salida": getattr(_uso, "output_tokens", None)}
        if not contenido:
            motivo = getattr(response, "stop_reason", None) or "desconocido"
            raise RuntimeError(
                f"❌ Anthropic devolvió una respuesta VACÍA (stop_reason={motivo}). "
                f"No se recibió texto que evaluar. Causas habituales: el modelo "
                f"rehusó la petición, o max_tokens={tokens} es demasiado bajo."
            )

        texto = getattr(contenido[0], "text", None)
        if texto is None:
            tipo = getattr(contenido[0], "type", type(contenido[0]).__name__)
            raise RuntimeError(
                f"❌ Anthropic devolvió un bloque de tipo '{tipo}' sin campo "
                f"'text'. La respuesta no es utilizable como evaluación."
            )
        return texto

    def validar_conexion(self) -> bool:
        try:
            self.cliente.messages.create(
                model=self.modelo,
                max_tokens=100,
                system="Test",
                messages=[{"role": "user", "content": "test"}],
            )
            self.ultimo_error_conexion = ""
            return True
        except Exception as e:
            self.ultimo_error_conexion = f"{type(e).__name__}: {e}"
            print(f"⚠️  Validación Anthropic: {e}")
            return False


# ─── Azure OpenAI ────────────────────────────────────────────────────────

# ═════════════════════════════════════════════════════════════════════════════
# FILTRO DE CONTENIDO DE AZURE — diagnóstico accionable
# ═════════════════════════════════════════════════════════════════════════════
# [RAI-FIX 2026-07-30] Azure aplica «Responsible AI» sobre entrada y salida.
# Un manual de riesgo de crédito dispara categorías inesperadas con facilidad:
# «pérdida esperada», «severidad», «default», «exposición», «mitigación de
# daños» y el vocabulario de estrés y quiebra que usa cualquier documento de
# gestión de riesgos.
#
# El mensaje anterior decía «causa habitual: el filtro de contenido» y ahí
# terminaba. El operador no sabía QUÉ categoría, ni si fue la entrada o la
# salida, ni qué documento del contexto lo provocó — con un prompt de 15.000
# caracteres, buscarlo a mano es inviable.
#
# Este diagnóstico extrae lo que la propia respuesta trae y da los tres caminos
# reales: pedir a IT que ajuste el filtro para el deployment, trocear el
# contexto para aislar el documento, o excluirlo.

_CATEGORIAS_RAI = ("hate", "self_harm", "sexual", "violence", "jailbreak",
                   "profanity", "protected_material_code",
                   "protected_material_text")


def _extraer_categorias(objeto) -> list:
    """Categorías marcadas en un bloque `content_filter_results`."""
    marcadas = []
    if not objeto:
        return marcadas
    datos = objeto if isinstance(objeto, dict) else getattr(objeto, "__dict__", {})
    for cat in _CATEGORIAS_RAI:
        v = datos.get(cat) if isinstance(datos, dict) else None
        if not v:
            continue
        filtrado = v.get("filtered") if isinstance(v, dict) else getattr(v, "filtered", None)
        severidad = v.get("severity") if isinstance(v, dict) else getattr(v, "severity", None)
        if filtrado:
            marcadas.append(f"{cat}({severidad or 'sin severidad'})")
    return marcadas


def _diagnostico_filtro(response, prompt: str = "") -> str:
    """Mensaje accionable cuando Azure bloquea por Responsible AI."""
    entrada, salida = [], []
    for pr in (getattr(response, "prompt_filter_results", None) or []):
        res = pr.get("content_filter_results") if isinstance(pr, dict) \
            else getattr(pr, "content_filter_results", None)
        entrada += _extraer_categorias(res)
    for op in (getattr(response, "choices", None) or []):
        salida += _extraer_categorias(getattr(op, "content_filter_results", None))

    L = ["❌ Azure OpenAI bloqueó la petición por su filtro de contenido "
         "(ResponsibleAIPolicyViolation).", ""]
    if entrada:
        L.append(f"   Bloqueado en la ENTRADA — categorías: {', '.join(entrada)}")
    if salida:
        L.append(f"   Bloqueado en la SALIDA — categorías: {', '.join(salida)}")
    if not entrada and not salida:
        L.append("   La respuesta no detalla la categoría (el deployment no la "
                 "expone).")

    # El token crudo de la API, literal y sin traducir. El texto de abajo es
    # para quien lee la consola; esta línea es para quien filtra los logs y
    # para el test que fija que la razón técnica no se pierde al enriquecer el
    # mensaje. Ambos lectores importan.
    _op = (getattr(response, "choices", None) or [None])[0]
    _razon = getattr(_op, "finish_reason", None) if _op is not None else None
    L.append(f"   finish_reason={_razon or 'content_filter'}")

    L += [
        "",
        f"   Tamaño del prompt: {len(prompt):,} chars.",
        "",
        "   POR QUÉ PASA con documentación de riesgos: el vocabulario propio",
        "   del dominio —«pérdida», «severidad», «default», «exposición»,",
        "   «estrés», «quiebra»— se solapa con las categorías de daño del",
        "   filtro. Suele ser un FALSO POSITIVO.",
        "",
        "   QUÉ HACER, por orden de eficacia:",
        "",
        "   1. Pide a IT que ajuste el filtro del deployment. Es la solución",
        "      real: en Azure AI Foundry → Content filters → crear un perfil",
        "      con los umbrales subidos y asignarlo a este deployment. Es un",
        "      cambio de configuración, no una excepción de seguridad.",
        "",
        "   2. Aísla el documento culpable sin gastar de más:",
        "        DEBUG_PROMPTS=1 python agente.py ...",
        "      vuelca el prompt íntegro a outputs/<fecha>/debug_prompts/.",
        "      Con el prompt en la mano, la categoría de arriba te dice qué",
        "      buscar.",
        "",
        "   3. Reduce el contexto por llamada para acotar el bloqueo:",
        "        VIRF_MAX_CTX=8000",
        "      Menos texto por petición = menos superficie para el filtro, a",
        "      cambio de más llamadas.",
        "",
        "   ⚠️ Esto es un FALLO TÉCNICO del agente, no una falta del validado:",
        "      la actividad queda con evaluacion_valida=False y EXCLUIDA del",
        "      score. Nunca se convierte en un puntaje bajo.",
    ]
    return "\n".join(L)


class ClienteAzureOpenAIIA(ClienteIA):
    """Cliente para Azure OpenAI"""

    PROVEEDOR = "azure_openai"

    # Nombre en los mensajes de error. ClienteOpenAIIA lo sobreescribe: comparte
    # toda la negociación de parámetros, pero el operador debe saber a QUÉ
    # consola ir cuando falla.
    _ETIQUETA = "Azure OpenAI"

    def _reconstruir_cliente(self):
        from openai import AzureOpenAI as _AzureOpenAI
        return _AzureOpenAI(
            api_key=_secreto("AZURE_OPENAI_API_KEY"),
            api_version=AZURE_API_VERSION,
            azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT", ""),
            http_client=_cliente_http(),
        )

    def __init__(self):
        try:
            from openai import AzureOpenAI
        except ImportError:
            raise ImportError("❌ pip install openai")

        api_key = _secreto("AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
        deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")

        if not api_key:
            raise ValueError("❌ AZURE_OPENAI_API_KEY no configurada")
        if not endpoint:
            raise ValueError("❌ AZURE_OPENAI_ENDPOINT no configurado")
        # [SEG-01] Solo el endpoint corporativo de Azure OpenAI.
        from .red import verificar_host_ia
        verificar_host_ia(endpoint)
        if not deployment:
            raise ValueError("❌ AZURE_OPENAI_DEPLOYMENT no configurado")

        self.cliente = AzureOpenAI(
            api_key=api_key,
            api_version=AZURE_API_VERSION,
            azure_endpoint=endpoint,
            http_client=_cliente_http(),
        )
        self.deployment = deployment
        self.max_tokens_default = AZURE_MAX_TOKENS

        # ── Estado que se resuelve en la PRIMERA llamada real ───────────────
        # No se puede saber de antemano qué modelo sirve un deployment: el
        # nombre lo elige quien despliega ('gpt4o-virf-prod' no dice nada). Y
        # de ese modelo dependen dos cosas que rompen la llamada si se
        # adivinan mal: el nombre del parámetro de límite de tokens y si
        # admite `temperature`. Se negocian contra el servidor y se memorizan.
        self._modelo_real: Optional[str] = None
        self._perfil = None
        self._param_tokens: Optional[str] = None
        self._admite_temperature: Optional[bool] = None

    # ── Detección del modelo real ───────────────────────────────────────────

    def detectar_modelo_deployment(self, forzar: bool = False) -> Optional[str]:
        """
        Consulta a la API qué modelo sirve realmente el deployment.

        `response.model` devuelve el modelo CON su fecha de versión
        ('gpt-4o-2024-11-20'), que es el dato del que dependen el contexto
        máximo, los parámetros admitidos y el precio. El nombre del deployment
        no lo dice: lo elige quien despliega.

        Se cachea: esta llamada cuesta dinero y el modelo de un deployment no
        cambia a mitad de corrida.

        Devuelve None si no se pudo determinar (sin credencial, sin red…), sin
        lanzar: la detección es un refuerzo, no un requisito para operar.
        """
        if self._modelo_real and not forzar:
            return self._modelo_real
        try:
            r = self.cliente.chat.completions.create(
                model=self.deployment,
                messages=[{"role": "user", "content": "ping"}],
                **{self._param_tokens or "max_tokens": 5},
            )
            self._modelo_real = getattr(r, "model", None) or self.deployment
        except Exception as exc:
            # Si falló por el parámetro de tokens, se reintenta con el otro:
            # es justamente el caso que la detección debe resolver.
            if "max_tokens" in str(exc) or "max_completion_tokens" in str(exc):
                otro = ("max_completion_tokens"
                        if (self._param_tokens or "max_tokens") == "max_tokens"
                        else "max_tokens")
                try:
                    r = self.cliente.chat.completions.create(
                        model=self.deployment,
                        messages=[{"role": "user", "content": "ping"}],
                        **{otro: 5})
                    self._param_tokens = otro
                    self._modelo_real = getattr(r, "model", None) or self.deployment
                except Exception:
                    return None
            else:
                return None

        from config.modelos import perfil_modelo
        self._perfil = perfil_modelo(self._modelo_real)
        if self._param_tokens is None:
            self._param_tokens = self._perfil.param_tokens
        if self._admite_temperature is None:
            self._admite_temperature = self._perfil.admite_temperature
        return self._modelo_real

    @property
    def perfil(self):
        """Perfil del modelo (config/modelos.py). Conservador si no se detectó."""
        if self._perfil is None:
            from config.modelos import perfil_modelo
            self._perfil = perfil_modelo(self._modelo_real, verbose=False)
        return self._perfil

    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        """Genera mensaje con soporte para parámetros alternativos.

        [v18] BUG FIX: el parámetro 'system' no existe en chat.completions.create()
        de Azure OpenAI. El sistema debe enviarse como primer mensaje con
        role='system' dentro del array messages.

        `formato_json=True` activa `response_format={"type":"json_object"}`, que
        garantiza JSON sintácticamente válido del lado del servidor.
        """
        sys_prompt = sistema or instruccion_sistema or "Eres un auditor experto."
        tokens = max_tokens or self.max_tokens_default
        mensajes = [
            {"role": "system", "content": sys_prompt},
            {"role": "user",   "content": prompt},
        ]

        extra = {}
        if formato_json:
            # [AZURE] Garantiza JSON sintácticamente válido en el servidor.
            # Elimina de raíz los fallos de parseo por markdown fences, prosa
            # previa u objetos concatenados que este proyecto ya sufrió (ver el
            # AUDIT-FIX de Mx_03._parsear_json). Anthropic no tiene equivalente,
            # así que el parser robusto se conserva para el proveedor secundario.
            # Requisito de la API: el prompt debe mencionar «JSON».
            extra["response_format"] = {"type": "json_object"}

        # ── Negociación del parámetro de límite de tokens ───────────────────
        # Los modelos de razonamiento (o1/o3/GPT-5) RECHAZAN `max_tokens` y
        # exigen `max_completion_tokens`. Detectarlo por el nombre del
        # deployment no sirve: lo elige el usuario y puede llamarse como quiera.
        # Se intenta y se adapta, memorizando el resultado para no pagar el
        # reintento en cada una de las ~40 llamadas del chunker.
        # [HTTPX-FIX 2026-07-30] El SDK toma posesión del `http_client`: un
        # `close()` en cualquier punto deja este cliente inservible y toda
        # llamada posterior falla con «Cannot send a request, as the client has
        # been closed». Se detecta y se reconstruye — el cliente es transporte
        # HTTP, no guarda estado de sesión.
        _http = getattr(self.cliente, "_client", None)
        if getattr(_http, "is_closed", False):
            print("  ⚠️  El cliente HTTP estaba cerrado; se reconstruye.")
            self.cliente = self._reconstruir_cliente()

        candidatos = ([self._param_tokens] if self._param_tokens
                      else ["max_tokens", "max_completion_tokens"])
        ultimo = None
        # [AUDIT-FIX 2026-08-07] Mismo motivo que en Anthropic: sin fijarla, la
        # temperatura por defecto vuelve el dictamen irreproducible. Aquí se
        # respeta el perfil: los modelos de razonamiento (o1/o3/GPT-5) RECHAZAN
        # cualquier temperature ≠ 1, así que a esos no se les manda.
        if self._admite_temperature is None:
            self._admite_temperature = getattr(self._perfil, "admite_temperature", True)
        if self._admite_temperature:
            extra["temperature"] = IA_TEMPERATURE

        response = None
        for nombre_param in candidatos:
            try:
                response = _con_reintento(
                    lambda p=nombre_param: self.cliente.chat.completions.create(
                        model=self.deployment, messages=mensajes,
                        **{p: tokens}, **extra))
                self._param_tokens = nombre_param
                break
            except Exception as e:
                ultimo = e
                texto_err = str(e)
                if ("max_tokens" in texto_err or "max_completion_tokens" in texto_err) \
                        and len(candidatos) > 1:
                    continue          # parámetro no soportado: probar el otro
                raise RuntimeError(f"❌ Error {self._ETIQUETA}: {e}") from e
        if response is None:
            raise RuntimeError(
                f"❌ {self._ETIQUETA} rechazó ambos parámetros de límite de tokens "
                f"(max_tokens y max_completion_tokens). Último error: {ultimo}"
            ) from ultimo

        # Memorizar el modelo real en la primera respuesta útil: viene gratis.
        if self._modelo_real is None:
            self._modelo_real = getattr(response, "model", None)
        # [Paso 57] Tokens reales de la respuesta, para el coste por llamada.
        _uso = getattr(response, "usage", None)
        self.ultimo_uso = {
            "modelo": getattr(response, "model", None) or self._modelo_real or self.deployment,
            "entrada": getattr(_uso, "prompt_tokens", None),
            "salida": getattr(_uso, "completion_tokens", None),
        }

        # [AUDIT-FIX] Mismo blindaje que en Anthropic: `choices` puede venir
        # vacío (filtro de contenido) y `.content` puede ser None.
        opciones = getattr(response, "choices", None) or []
        if not opciones:
            raise RuntimeError(_diagnostico_filtro(response, prompt))
        texto = getattr(getattr(opciones[0], "message", None), "content", None)
        if texto is None:
            razon = getattr(opciones[0], "finish_reason", "desconocida")
            if str(razon).lower() == "content_filter":
                raise RuntimeError(_diagnostico_filtro(response, prompt))
            raise RuntimeError(
                f"❌ {self._ETIQUETA} devolvió una opción sin texto "
                f"(finish_reason={razon}). La respuesta no es utilizable."
            )
        return texto

    def validar_conexion(self) -> bool:
        """
        Comprueba que el deployment responde. Negocia el parámetro de tokens.

        ── [AZURE-FIX 2026-07-31] Por qué NO puede ir `max_tokens=100` fijo ───
        Todo el cliente negocia `max_tokens` vs `max_completion_tokens` porque
        los modelos de razonamiento (o1, o3, gpt-5) RECHAZAN el primero. Este
        comprobador lo tenía hardcodeado, así que contra un deployment de esa
        familia fallaba y dejaba en `ultimo_error_conexion` un mensaje de la
        API que el operador lee como «la credencial está mal».

        El daño real es el momento en que ocurre: el primer arranque tras
        recibir las credenciales de IT, cuando nadie sabe todavía si el
        problema es la clave, el endpoint, el proxy o el deployment. El cliente
        sabía hablar con ese modelo perfectamente; el que no sabía era su
        propio comprobador.

        Se piden 5 tokens y no 100: es un ping, y el límite no afecta a lo que
        se comprueba —que la credencial, el endpoint y el deployment existen—.
        """
        candidatos = ([self._param_tokens] if self._param_tokens
                      else ["max_tokens", "max_completion_tokens"])
        ultimo = None
        for nombre_param in candidatos:
            try:
                self.cliente.chat.completions.create(
                    model=self.deployment,
                    messages=[{"role": "user", "content": "test"}],
                    **{nombre_param: 5},
                )
                # Se memoriza: la primera llamada real se ahorra la negociación.
                self._param_tokens = nombre_param
                self.ultimo_error_conexion = ""
                return True
            except Exception as e:
                ultimo = e
                texto_err = str(e)
                if ("max_tokens" in texto_err or "max_completion_tokens" in texto_err) \
                        and len(candidatos) > 1:
                    continue          # parámetro no soportado: probar el otro
                break

        # [AUDIT-FIX] Este `except Exception: return False` era mudo: un
        # usuario de Azure con la clave mal puesta no veía NADA, ni siquiera
        # el aviso que sí tenía el cliente de Anthropic.
        self.ultimo_error_conexion = f"{type(ultimo).__name__}: {ultimo}"
        print(f"⚠️  Validación {self._ETIQUETA}: {ultimo}")
        return False


# ─── OpenAI directo (api.openai.com) ─────────────────────────────────────

class ClienteOpenAIIA(ClienteAzureOpenAIIA):
    """
    Cliente para la API pública de OpenAI con una sola API key.

    Hereda de Azure TODA la negociación (max_tokens vs max_completion_tokens,
    temperature en modelos de razonamiento, respuestas vacías): el endpoint de
    chat.completions es el mismo, solo cambian la autenticación y que aquí el
    `model` es el nombre real del modelo y no un deployment.
    """

    PROVEEDOR = "openai"

    _ETIQUETA = "OpenAI"

    def __init__(self):
        try:
            from openai import OpenAI  # noqa: F401
        except ImportError:
            raise ImportError("❌ pip install openai")

        api_key = _secreto("OPENAI_API_KEY")
        if _es_placeholder(api_key):
            raise ValueError(
                "\n❌ OPENAI_API_KEY no está configurada o es un placeholder.\n"
                "   Defínela como variable de entorno del proceso (no en el .env:\n"
                "   se rechaza), p. ej. en PowerShell  $env:OPENAI_API_KEY = \"sk-...\"\n"
                "   Se obtiene en https://platform.openai.com/api-keys\n"
            )
        _leak = _detectar_key_en_example(api_key)
        if _leak:
            raise ValueError(
                f"\n🔴 RIESGO DE SEGURIDAD: la OPENAI_API_KEY en uso es idéntica a la "
                f"que aparece en {_leak}. Revócala y deja la nueva SOLO en .env.\n"
            )

        self.cliente = self._reconstruir_cliente()
        self.deployment = OPENAI_MODELO
        self.max_tokens_default = OPENAI_MAX_TOKENS
        self._modelo_real: Optional[str] = None
        self._perfil = None
        self._param_tokens: Optional[str] = None
        self._admite_temperature: Optional[bool] = None

    def _reconstruir_cliente(self):
        from openai import OpenAI
        return OpenAI(api_key=_secreto("OPENAI_API_KEY"),
                      http_client=_cliente_http())


# ═════════════════════════════════════════════════════════════════════════════
# FACTORY: Crear cliente según proveedor
# ═════════════════════════════════════════════════════════════════════════════

FABRICAS = {
    "anthropic": ClienteAnthropicIA,
    "azure_openai": ClienteAzureOpenAIIA,
    "openai": ClienteOpenAIIA,
}


def virf_plus_activo() -> bool:
    """
    ¿Está encendido VIRF PLUS (Claude + GPT con conclusión conciliada)?

    Se lee del entorno EN CADA LLAMADA, no al importar: el botón de la web lo
    cambia en caliente y la siguiente evaluación debe salir ya en modo doble.
    Solo lo enciende el flag explícito VIRF_PLUS=1; tener ambas claves
    configuradas NO lo activa.
    """
    return str(os.getenv("VIRF_PLUS", "")).strip().lower() in (
        "1", "true", "si", "sí", "yes", "on")


# ═════════════════════════════════════════════════════════════════════════════
# METADATOS POR PROVEEDOR — para mensajes que no asuman un proveedor concreto
# ═════════════════════════════════════════════════════════════════════════════
# [GENERICO 2026-07-30] Los mensajes al usuario tenían el proveedor incrustado:
#
#   · `agente.py` mandaba SIEMPRE a console.anthropic.com en el primer arranque,
#     aunque el proveedor por defecto del proyecto es Azure OpenAI.
#   · El error 401 decía «API key rechazada por Anthropic» aunque la clave
#     rechazada fuera la de Azure — mandando al operador a revisar la consola
#     equivocada mientras la corrida seguía caída.
#
# El texto se deriva del proveedor ACTIVO. Añadir un proveedor nuevo es añadir
# una entrada aquí y otra en FABRICAS, sin tocar ningún mensaje.
METADATOS_PROVEEDOR = {
    "anthropic": {
        "nombre":        "Anthropic",
        "consola":       "https://console.anthropic.com/",
        "var_clave":     "ANTHROPIC_API_KEY",
        "vars_revisar":  ("IA_PROVEEDOR=anthropic", "ANTHROPIC_API_KEY",
                          "ANTHROPIC_MODELO"),
    },
    "openai": {
        "nombre":        "OpenAI",
        "consola":       "https://platform.openai.com/api-keys",
        "var_clave":     "OPENAI_API_KEY",
        "vars_revisar":  ("IA_PROVEEDOR=openai", "OPENAI_API_KEY", "OPENAI_MODELO"),
    },
    "virf_plus": {
        "nombre":        "VIRF PLUS (GPT + Claude)",
        "consola":       "Credenciales GPT del agente principal  ·  https://console.anthropic.com/",
        "var_clave":     "las credenciales GPT y ANTHROPIC_API_KEY",
        "vars_revisar":  ("VIRF_PLUS=1", "VIRF_PLUS_GPT=azure_openai|openai",
                          "AZURE_OPENAI_* / OPENAI_API_KEY (GPT, agente principal)",
                          "ANTHROPIC_API_KEY", "ANTHROPIC_MODELO (Claude)"),
    },
    "azure_openai": {
        "nombre":        "Azure OpenAI",
        "consola":       "https://portal.azure.com/  (recurso → Keys and Endpoint)",
        "var_clave":     "AZURE_OPENAI_API_KEY",
        "vars_revisar":  ("IA_PROVEEDOR=azure_openai", "AZURE_OPENAI_ENDPOINT",
                          "AZURE_OPENAI_DEPLOYMENT  (el *Deployment name*, "
                          "NO el nombre del modelo)",
                          "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_API_VERSION"),
    },
}

# Si el proveedor no está catalogado se devuelve una ficha neutra en vez de
# reventar: un mensaje de error no puede fallar al construirse, porque entonces
# el operador pierde también el diagnóstico que venía a darle.
_METADATOS_NEUTROS = {
    "nombre":       "el proveedor de IA configurado",
    "consola":      "la consola de tu proveedor",
    "var_clave":    "la variable de clave de tu proveedor",
    "vars_revisar": ("IA_PROVEEDOR",),
}


# ═════════════════════════════════════════════════════════════════════════════
# PROVEEDOR ACTIVO — se deduce de la clave presente (fuera de producción)
# ═════════════════════════════════════════════════════════════════════════════
# [2026-11-11] Antes había que alinear a mano IA_PROVEEDOR con la clave que se
# tuviera: con la clave de Claude puesta e IA_PROVEEDOR en su valor por defecto
# el agente moría pidiendo la de Azure. Ahora basta con poner la clave.
#
# Regla (determinista, sin heurística sobre el contenido de la clave):
#   · PRODUCCIÓN → siempre IA_PROVEEDOR tal cual. Nada se deduce.
#   · Desarrollo → candidatos = proveedores autorizados con credenciales
#     completas. Si IA_PROVEEDOR está entre ellos, gana (lo declarado manda).
#     Si no, el primero por prioridad: GPT (Azure, OpenAI) antes que Claude.
#     Sin candidatos se devuelve IA_PROVEEDOR, cuyo constructor dice qué falta.
# Tener dos claves NO enciende VIRF PLUS: eso sigue siendo VIRF_PLUS=1.
_PRIORIDAD_DETECCION = ("azure_openai", "openai", "anthropic")
_VARS_CLAVE = {"azure_openai": "AZURE_OPENAI_API_KEY", "openai": "OPENAI_API_KEY",
               "anthropic": "ANTHROPIC_API_KEY"}
_VARS_EXTRA = {"azure_openai": ("AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT")}
_AVISOS_DETECCION: set = set()


def _credenciales_completas(proveedor: str) -> bool:
    """¿Tiene este proveedor todo lo que necesita para construirse? Nunca
    lanza: una fuente de secretos caída o una clave en el .env cuentan como
    «no», y el motivo lo dará el constructor si se llega a usar."""
    if proveedor not in _VARS_CLAVE:
        return False
    try:
        clave = _secreto(_VARS_CLAVE[proveedor])
    except Exception:                                       # noqa: BLE001
        return False
    if _es_placeholder(clave):
        return False
    return all(os.getenv(v, "").strip() for v in _VARS_EXTRA.get(proveedor, ()))


def _motivo_clave_rechazada(proveedor: str) -> str:
    """Mensaje si la clave existe pero la fuente de secretos la rechaza."""
    try:
        _secreto(_VARS_CLAVE[proveedor])
    except Exception as exc:                                # noqa: BLE001
        return str(exc)
    return ""


def proveedor_activo(preferido: Optional[str] = None) -> str:
    """Proveedor que usará el agente en este proceso (ver regla arriba).
    `preferido` sustituye a IA_PROVEEDOR como proveedor declarado."""
    preferido = str(preferido or IA_PROVEEDOR or "azure_openai").strip().lower()
    if _en_produccion():
        return preferido
    candidatos = [p for p in _PRIORIDAD_DETECCION
                  if proveedor_autorizado(p) and _credenciales_completas(p)]
    if preferido in candidatos:
        return preferido
    if not candidatos:
        for p in _PRIORIDAD_DETECCION:
            motivo = _motivo_clave_rechazada(p) if proveedor_autorizado(p) else ""
            # Una fuente de secretos mal configurada da el mismo motivo para
            # los tres proveedores: se avisa una vez, no tres.
            if motivo and ("rechazo", motivo) not in _AVISOS_DETECCION:
                _AVISOS_DETECCION.add(("rechazo", motivo))
                print(f"  ⚠️  No se puede leer la clave de «{p}»: {motivo}")
                if "VIRF_FUENTE_SECRETOS=keyvault" in motivo:
                    print("     En desarrollo, declara VIRF_FUENTE_SECRETOS=entorno y pon la "
                          "clave como variable de entorno del proceso.")
        return preferido
    elegido = candidatos[0]
    if (preferido, elegido) not in _AVISOS_DETECCION:
        _AVISOS_DETECCION.add((preferido, elegido))
        print(f"  🔎 Proveedor de IA detectado por la clave presente: «{elegido}» "
              f"(IA_PROVEEDOR={preferido} no tiene credenciales completas).")
    return elegido


def modelo_activo() -> str:
    """
    Nombre del modelo que usa (o usará) el agente en este proceso.

    Si ya hay cliente construido se toma de él —incluido el modelo real que el
    deployment de Azure reveló en su primera respuesta—; si no, de la
    configuración del proveedor activo. `motor.Mx_00.MODELO_IA` vale siempre
    ANTHROPIC_MODELO, también con GPT: no sirve para rotular un informe.
    """
    cli = _CLIENTE_CACHE
    if cli is not None:
        nombre = (getattr(cli, "_modelo_real", None) or getattr(cli, "modelo", None)
                  or getattr(cli, "deployment", None))
        if nombre:
            return str(nombre)
    prov = proveedor_activo()
    if prov == "azure_openai":
        return os.getenv("AZURE_OPENAI_DEPLOYMENT", "") or "azure_openai"
    if prov == "openai":
        return OPENAI_MODELO
    return ANTHROPIC_MODELO


def _huella_credenciales(proveedores) -> str:
    """Huella (no reversible) de las credenciales y del modelo de estos
    proveedores. Si cambia —se pegó otra clave, otro deployment— la caché del
    cliente deja de valer y se reconstruye sola."""
    import hashlib
    h = hashlib.sha256()
    for p in proveedores:
        try:
            clave = _secreto(_VARS_CLAVE[p]) if (
                p in _VARS_CLAVE and proveedor_autorizado(p)) else ""
        except Exception:                                   # noqa: BLE001
            clave = ""
        extras = [os.getenv(v, "") for v in _VARS_EXTRA.get(p, ())]
        if p == "anthropic":
            extras.append(os.getenv("ANTHROPIC_WORKSPACE_ID", ""))
        h.update("\x1f".join([str(p), clave, *extras]).encode("utf-8", "ignore"))
        h.update(b"\x1e")
    return h.hexdigest()[:16]


def metadatos_proveedor(proveedor: Optional[str] = None) -> dict:
    """
    Ficha del proveedor indicado, o del activo si no se indica ninguno.

    Se usa para construir mensajes de error y de configuración sin incrustar el
    nombre de ningún proveedor en el código que los emite.
    """
    if proveedor is None and virf_plus_activo():
        proveedor = "virf_plus"
    if not proveedor:
        try:
            proveedor = proveedor_activo()
        except Exception:                                   # noqa: BLE001
            proveedor = IA_PROVEEDOR
    clave = (proveedor or "").strip().lower()
    return METADATOS_PROVEEDOR.get(clave, _METADATOS_NEUTROS)

# [PERF-FIX] Cliente cacheado a nivel de proceso.
# Antes: cada llamada a get_cliente_ia() construía un cliente nuevo Y ejecutaba
# validar_conexion(), que hace una llamada API REAL de prueba. En una corrida
# Tier 1 esto suponía ~17 requests desperdiciados (100% de sobrecoste).
# Ahora: se construye una sola vez por proceso y la validación es opcional.
_CLIENTE_CACHE: Optional[ClienteIA] = None
# Modo con el que se construyó la caché («anthropic», «virf_plus»…). Si el
# botón VIRF PLUS cambia el modo, la caché vieja deja de valer.
_CLIENTE_CACHE_MODO: Optional[str] = None
# Huella de las credenciales con las que se construyó. None = caché inyectada
# a mano (tests): no se compara.
_CLIENTE_CACHE_HUELLA: Optional[str] = None


def get_cliente_ia(forzar_recarga: bool = False) -> ClienteIA:
    """
    Devuelve el cliente IA del proveedor activo (`proveedor_activo()`): el de
    IA_PROVEEDOR o, fuera de producción, el que tenga la clave puesta.

    [PERF-FIX] El cliente se cachea a nivel de proceso: llamar a esta función
    N veces construye el cliente UNA sola vez. Esto elimina el 50% de las
    llamadas a la API que se hacían antes (una de validación por evaluación).

    [PERF-FIX] La llamada de validación (`validar_conexion()`) solo se ejecuta
    si VIRF_VALIDAR_CONEXION=1 en .env. Por defecto está desactivada: un fallo
    de credenciales se manifiesta igualmente en la primera llamada real, con
    un mensaje claro, y sin gastar un request extra por proceso.

    Args:
        forzar_recarga: reconstruye el cliente ignorando la caché
                        (útil en tests o si cambia la configuración en runtime).

    Returns:
        ClienteIA listo para usar.

    Raises:
        RuntimeError si la configuración es inválida o no hay conexión.
    """
    global _CLIENTE_CACHE, _CLIENTE_CACHE_MODO, _CLIENTE_CACHE_HUELLA

    proveedor = proveedor_activo()
    modo = "virf_plus" if virf_plus_activo() else proveedor
    if modo == "virf_plus":
        from .virf_plus import proveedor_gpt as _gpt_plus
        huella = _huella_credenciales(("anthropic", _gpt_plus()))
    else:
        huella = _huella_credenciales((proveedor,))
    # Una caché sin modo registrado (inyectada a mano, p. ej. en tests) vale
    # para el modo de un solo proveedor, nunca para VIRF PLUS.
    _modo_cache = _CLIENTE_CACHE_MODO or (
        None if modo == "virf_plus" else modo)
    if (_CLIENTE_CACHE is not None and not forzar_recarga
            and _modo_cache == modo
            and _CLIENTE_CACHE_HUELLA in (None, huella)):
        return _CLIENTE_CACHE

    if modo == "virf_plus":
        # Sin fallback: si falta una de las dos claves, VIRF PLUS no arranca
        # en vez de degradar en silencio a un solo evaluador.
        from .virf_plus import ClienteConsensoIA
        try:
            cliente = ClienteConsensoIA()
        except ValueError:
            raise
        except Exception as e:
            raise RuntimeError(f"❌ Error inicializando VIRF PLUS: {e}") from e
        if VALIDAR_CONEXION and not cliente.validar_conexion():
            raise RuntimeError(
                f"❌ No se pudo conectar a VIRF PLUS — {cliente.ultimo_error_conexion}")
        print(f"✅ Cliente IA listo: VIRF PLUS ({cliente.descripcion})")
        _CLIENTE_CACHE, _CLIENTE_CACHE_MODO, _CLIENTE_CACHE_HUELLA = cliente, modo, huella
        return cliente

    if proveedor not in FABRICAS:
        raise ValueError(
            f"❌ Proveedor no soportado: {proveedor}. Opciones: {', '.join(FABRICAS)}"
        )

    try:
        cliente = _instanciar(proveedor)

        if VALIDAR_CONEXION:
            if not cliente.validar_conexion():
                _motivo = getattr(cliente, "ultimo_error_conexion", "")
                raise RuntimeError(
                    f"❌ No se pudo conectar a {proveedor.upper()}"
                    + (f" — {_motivo}" if _motivo else "")
                )
            estado = "conexión verificada"
        else:
            estado = "sin verificar (VIRF_VALIDAR_CONEXION=0)"

        modelo = os.getenv(f"{proveedor.upper()}_MODELO", "default")
        print(f"✅ Cliente IA listo: {proveedor} ({modelo}) — {estado}")

        _CLIENTE_CACHE, _CLIENTE_CACHE_MODO, _CLIENTE_CACHE_HUELLA = cliente, modo, huella
        return cliente

    except ValueError:
        raise  # errores de configuración/seguridad se propagan con su mensaje original
    except Exception as e:
        # `from e` preserva la cadena para quien inspeccione __cause__.
        raise RuntimeError(f"❌ Error inicializando IA: {e}") from e


def _instanciar(proveedor: str) -> ClienteIA:
    """Único punto de instanciación de un proveedor (nunca se salta a otro).
    Autoriza ANTES de construir: un proveedor no aprobado ni siquiera lee su
    clave."""
    autorizar_proveedor(proveedor)
    return FABRICAS[proveedor]()


def cliente_dedicado(proveedor: str, modelo: Optional[str] = None) -> ClienteIA:
    """
    Cliente NUEVO (sin caché) de un proveedor concreto, opcionalmente con otro
    modelo/deployment. Para funciones auxiliares que quieren un modelo más barato
    que el del pipeline —p. ej. la asistencia de redacción de «Solo Informe»—
    sin tocar el cliente cacheado que usan las evaluaciones.

    Sin plan B: si el proveedor pedido falla, falla.
    """
    if proveedor not in FABRICAS:
        raise ValueError(
            f"❌ Proveedor no soportado: {proveedor}. Opciones: {', '.join(FABRICAS)}")
    cliente = _instanciar(proveedor)
    if modelo:
        # Anthropic guarda el modelo en `modelo`; Azure/OpenAI en `deployment`.
        if hasattr(cliente, "deployment"):
            cliente.deployment = modelo
        else:
            cliente.modelo = modelo
    return cliente


def reset_cliente_ia() -> None:
    """Limpia la caché del cliente (para tests o recarga de configuración)."""
    global _CLIENTE_CACHE, _CLIENTE_CACHE_MODO, _CLIENTE_CACHE_HUELLA
    _CLIENTE_CACHE = None
    _CLIENTE_CACHE_MODO = None
    _CLIENTE_CACHE_HUELLA = None


# ═════════════════════════════════════════════════════════════════════════════
# PRUEBA DE HUMO — el único comando manual tras pegar la credencial
# ═════════════════════════════════════════════════════════════════════════════

def prueba_de_humo() -> dict:
    """
    Llamada mínima real al proveedor activo. Confirma cuatro cosas de una vez:

      1. que las credenciales son válidas;
      2. qué MODELO sirve realmente el deployment (el nombre no lo dice);
      3. que el perfil de chunking que se aplicará es el correcto para ese
         modelo (config/modelos.py);
      4. que el parser real —no un mock— entiende el JSON que devuelve.

    El punto 4 es el que justifica que esto exista: el proyecto ya sufrió
    respuestas envueltas en markdown fences y con prosa alrededor, y el parser
    lleva un AUDIT-FIX por ello. Comprobarlo con el proveedor nuevo ANTES de la
    primera corrida real evita descubrirlo con 40 llamadas ya pagadas.

    No lanza: devuelve un dict con `ok` y el diagnóstico, para que el llamante
    decida el código de salida.
    """
    import time
    _prov = proveedor_activo()

    if virf_plus_activo():
        _prov = "virf_plus"
    res = {"ok": False, "proveedor": _prov, "modelo": None, "perfil": None,
           "latencia_ms": None, "json_ok": None, "error": None}
    try:
        cliente = get_cliente_ia(forzar_recarga=True)
    except Exception as exc:
        res["error"] = f"{type(exc).__name__}: {exc}"
        return res

    # ── Llamada mínima, midiendo latencia ───────────────────────────────────
    t0 = time.perf_counter()
    try:
        texto = cliente.generar_mensaje(
            prompt='Responde únicamente con este JSON, sin texto adicional: '
                   '{"estado": "ok", "prueba": true}',
            instruccion_sistema="Eres un servicio de verificación. Responde solo JSON.",
            max_tokens=64,
            formato_json=True,
        )
    except Exception as exc:
        res["latencia_ms"] = int((time.perf_counter() - t0) * 1000)
        res["error"] = f"{type(exc).__name__}: {exc}"
        return res
    res["latencia_ms"] = int((time.perf_counter() - t0) * 1000)

    # ── Modelo real y perfil de chunking asociado ───────────────────────────
    modelo = getattr(cliente, "_modelo_real", None) or getattr(cliente, "modelo", None)              or getattr(cliente, "deployment", None)
    res["modelo"] = modelo
    try:
        from .modelos import perfil_modelo
        perfil = perfil_modelo(modelo, verbose=False)
        res["perfil"] = {
            "nombre": perfil.nombre,
            "contexto_tokens": perfil.contexto_tokens,
            "chunk_size": perfil.chunk_size,
            "max_ctx": perfil.max_ctx,
            "max_chunks": perfil.max_chunks,
            "param_tokens": perfil.param_tokens,
            "admite_temperature": perfil.admite_temperature,
            "nota": perfil.nota,
        }
    except Exception:
        pass

    # ── El parser REAL, no un mock ──────────────────────────────────────────
    try:
        import sys as _sys
        from pathlib import Path as _Path
        _sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))
        from modulos.motor_ia import _extraer_json
        datos = _extraer_json(texto)
        res["json_ok"] = isinstance(datos, dict)
        res["json_muestra"] = str(datos)[:120]
    except Exception as exc:
        res["json_ok"] = False
        res["error_json"] = f"{type(exc).__name__}: {exc}"
        res["respuesta_cruda"] = texto[:200]

    consenso = getattr(cliente, "ultimo_consenso", None)
    if consenso:
        res["virf_plus"] = {k: consenso.get(k) for k in (
            "modelos", "acuerdo", "arbitrado", "discrepancias")}
    res["ok"] = bool(res["json_ok"])
    return res
