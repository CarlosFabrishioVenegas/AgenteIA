"""
config/dominio.py  [v27.2]
═════════════════════════════════════════════════════════════════════════════
Parámetros de NEGOCIO del marco VIRF: tiers, pesos de ámbito, escalas de
puntaje, semáforo y preguntas metodológicas.

Separados de `parametros.py` a propósito: esto no se ajusta con variables de
entorno, se cambia con criterio de validación y trazabilidad regulatoria.
Cada peso lleva su referencia normativa en AMBITO_PESOS_REFS.

⚠️ AMBITO_PESOS debe sumar exactamente 1.00 y sus claves deben coincidir —
tildes y mayúsculas incluidas— con las del Excel de estándares, AMBITO_A_INPUTS
y PREGUNTAS_METODOLOGICAS. `validate_project.py` (bloque 4) y el test
`test_ambitos_coinciden_en_los_cuatro_sistemas` lo verifican: un desajuste de
tilde rompe el pipeline en silencio.
"""

from __future__ import annotations

__all__ = [
    "TIER_COLUMNS", "TIERS_VALIDOS", "normalizar_tier",
    "AMBITO_PESOS", "AMBITO_PESOS_REFS",
    "ESCALA_PUNTAJE", "SCORE_SEMAFORO", "PREGUNTAS_METODOLOGICAS",
    "EXTENSIONES_SOPORTADAS",
]

# ─── TIERS ──────────────────────────────────────────────────────────────────
TIER_COLUMNS = {
    "I": "TIER I",
    "II": "TIER II",
    "III": "TIER III",
    "IV": "TIER IV",
}

# Equivalencias arábigo → romano. Antes vivían duplicadas en Mx_01 como
# `_TIER_MAP` mientras este módulo declaraba TIER_COLUMNS: dos catálogos de
# tiers que nadie garantizaba iguales.
TIERS_VALIDOS = {"1": "I", "2": "II", "3": "III", "4": "IV",
                 "I": "I", "II": "II", "III": "III", "IV": "IV"}


def normalizar_tier(valor) -> str | None:
    """
    Devuelve el tier en notación romana, o None si no es un tier real.

    [AUDIT-FIX] `--tier 9` y `--tier abc` se aceptaban sin comprobación. El
    parser buscaba entonces una columna "TIER_9" inexistente, DESACTIVABA el
    filtro por tier ("todas las actividades se tratarán como REQUERIDAS") y la
    corrida evaluaba las 21 actividades en vez de las 11 del tier — facturando
    la API completa y rotulando el informe con un tier que no existe. Un typo
    en un dígito producía un informe entregable y equivocado.
    """
    if valor is None:
        return None
    return TIERS_VALIDOS.get(str(valor).strip().upper())

# ─── ÁMBITOS Y PESOS PARA SCORE GLOBAL ──────────────────────────────────────
# [D4-FIX] Pesos anclados a estándares regulatorios internacionales.
# Referencias normativas:
#   SR 11-7  (Fed 2011) — §IV "Model validation": énfasis en conceptual soundness
#             (Metodología) y ongoing monitoring (Seguimiento/Calidad de datos).
#   EBA/GL/2023/01 — §6.3: governance & documentation como pilares de validación.
#   BCBS 239 (2013) — principios 3-5: data governance, data architecture.
#   SBS Res. 9075-2012 — Art. 9: gestión del riesgo de liquidez.
#
# Distribución de pesos:
#   Metodología 0.30  ← SR 11-7 §IV: "conceptual soundness" = componente central
#   Calidad de datos 0.20 ← BCBS 239 principios 3-5: data governance crítico
#   Documentación 0.15 ← EBA/GL/2023/01 §6.3: evidencia tratable para auditor
#   Implementación 0.15 ← SR 11-7 §IV: "outcome analysis" e implementación fiel
#   Gobierno 0.12      ← EBA/GL/2023/01 §5: model inventory + tiering obligatorio
#   Uso e integración 0.08 ← SR 11-7 §IV: "ongoing monitoring" del uso efectivo
#
# SUMA = 1.00
# Fuente formal: VIRF_Pesos_Justificacion_Regulatoria_v1.md (docs/)
AMBITO_PESOS = {
    "Documentación":                 0.15,
    "Calidad de datos":              0.20,
    "Metodología":                   0.30,
    "Gobierno":                      0.12,
    "Implementación":                0.15,
    "Uso e integración a la gestión": 0.08,
}

# Metadatos de trazabilidad de pesos (para JSON de resultados y auditoría)
AMBITO_PESOS_REFS = {
    "Documentación":                 "EBA/GL/2023/01 §6.3",
    "Calidad de datos":              "BCBS 239 principios 3-5",
    "Metodología":                   "SR 11-7 §IV conceptual soundness",
    "Gobierno":                      "EBA/GL/2023/01 §5",
    "Implementación":                "SR 11-7 §IV outcome analysis",
    "Uso e integración a la gestión": "SR 11-7 §IV ongoing monitoring",
}

# ─── ESCALA DE PUNTAJE ──────────────────────────────────────────────────────
ESCALA_PUNTAJE = {
    1: {"label": "No cumple", "color": "FF0000"},
    2: {"label": "Cumple parcialmente - obs. críticas", "color": "FF6600"},
    3: {"label": "Cumple parcialmente", "color": "FFCC00"},
    4: {"label": "Cumple con observaciones menores", "color": "92D050"},
    5: {"label": "Cumple plenamente", "color": "00B050"},
}

SCORE_SEMAFORO = {
    (4.5, 5.0): {"label": "SATISFACTORIO", "color": "00B050"},
    (3.5, 4.5): {"label": "ACEPTABLE", "color": "92D050"},
    (2.5, 3.5): {"label": "CON OBSERVACIONES", "color": "FFCC00"},
    (1.5, 2.5): {"label": "DEFICIENTE", "color": "FF6600"},
    (0.0, 1.5): {"label": "CRÍTICO", "color": "FF0000"},
}

# ─── PREGUNTAS METODOLÓGICAS POR ÁMBITO ────────────────────────────────────
PREGUNTAS_METODOLOGICAS = {
    "Documentación": [
        "¿Existe un manual metodológico con control de versiones?",
        "¿El manual operativo describe el proceso de ejecución paso a paso?",
        "¿Los documentos de seguimiento incluyen backtesting (Kupiec, Christoffersen)?",
        "¿El informe de seguimiento cubre monitoreo de calidad de datos?",
    ],
    "Calidad de datos": [
        "¿Existe un script _replica_virf.py o equivalente de control de datos?",
        "¿Se documentan controles sobre missing values, duplicados y outliers?",
        "¿Existen reportes de incidencias de calidad de datos?",
        "¿Se verifica la actualización periódica de los inputs?",
    ],
    "Metodología": [
        "¿Se justifica la elección del modelo estocástico/ML utilizado?",
        "¿Se validan los supuestos principales del modelo?",
        "¿Se referencian lineamientos internacionales o regulatorios?",
        "¿Existe backtesting o planificación de seguimiento?",
        "¿Se realizan análisis de sensibilidad o escenarios?",
    ],
    "Gobierno": [
        "¿El modelo tiene tiering asignado y actualizado?",
        "¿El modelo se encuentra en el inventario oficial?",
    ],
    "Implementación": [
        "¿Se documentan las fuentes de información empleadas?",
        "¿Existen correos de conformidad de resultados con primera línea?",
        "¿El manual de implementación es coherente con el metodológico?",
        "¿Se documentan pruebas iniciales de implementación?",
    ],
    "Uso e integración a la gestión": [
        "¿Los usos del modelo están dentro del alcance original?",
        "¿El modelo no estaba en uso antes de concluir la validación?",
        "¿Se identifican formalmente los usuarios del modelo?",
        "¿Existe reporting de integración a la gestión?",
    ],
}

# ─── EXTENSIONES LEGIBLES ──────────────────────────────────────────────────
EXTENSIONES_SOPORTADAS = [
    ".pdf", ".docx", ".pptx", ".xlsx", ".py", ".json", ".txt", ".csv",
]
