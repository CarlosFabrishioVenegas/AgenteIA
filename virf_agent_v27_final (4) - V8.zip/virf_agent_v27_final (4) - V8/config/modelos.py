"""
config/modelos.py
═══════════════════════════════════════════════════════════════════════════════
CATÁLOGO DE MODELOS — parámetros óptimos por modelo, no por proveedor.

Problema que resuelve
─────────────────────
El chunking de VIRF estaba dimensionado para UN modelo concreto (el de 200K de
contexto que se usaba entonces) con constantes fijas en `config/parametros.py`.
Al cambiar de proveedor esos números dejan de tener sentido: un GPT-4 clásico
tiene 8K de contexto —menos que el presupuesto actual— y la familia GPT-5 mucho
más.

Fijar los valores «pensando en el modelo que creemos que habrá» es exactamente
el error que este proyecto ya cometió una vez: se asumieron 3,3 caracteres por
token cuando el valor real medido era 2,48, un desvío del 33 % en el
presupuesto de contexto.

Por eso aquí no se decide nada de antemano: se declara el perfil de CADA modelo
conocido y el sistema elige el que corresponda cuando sepa —consultando la API—
qué modelo sirve realmente el deployment.

Cómo se usa
───────────
    from config.modelos import perfil_modelo
    p = perfil_modelo("gpt-4o-2024-11-20")     # lo que devuelve response.model
    p.chunk_size, p.max_ctx, p.max_chunks, p.param_tokens, p.admite_temperature

Si el modelo no está en el catálogo se devuelve un perfil CONSERVADOR y se
avisa: es preferible hacer más llamadas de las necesarias que exceder el
contexto y perder cobertura documental en silencio.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional

__all__ = [
    "PerfilModelo", "CATALOGO_MODELOS", "perfil_modelo",
    "PERFIL_CONSERVADOR", "CHARS_POR_TOKEN_ES",
    "PRECIOS_ENTRADA_USD_POR_MTOK", "PRECIO_ENTRADA_POR_MTOK_DEFECTO",
    "precio_entrada_por_mtok",
    "PRECIOS_SALIDA_USD_POR_MTOK", "precio_salida_por_mtok", "coste_usd",
]

# ─────────────────────────────────────────────────────────────────────────────
# Relación caracteres/token para ESPAÑOL TÉCNICO.
#
# Medido sobre la evidencia real del proyecto: 2,48 chars/token.
#
# Es una propiedad del IDIOMA y del tipo de texto, no del proveedor. Los
# tokenizadores BPE modernos (cl100k_base, o200k_base y los de la competencia)
# dan valores algo distintos para español, pero del mismo orden. Se usa 2,4 como
# base conservadora para dimensionar: subestimar chars/token hace que el
# presupuesto calculado sea MENOR que el real, que es el lado seguro del error.
#
# Para recalibrar con tu propio corpus:
#     import tiktoken
#     enc = tiktoken.get_encoding("o200k_base")
#     ratio = len(texto) / len(enc.encode(texto))
# ─────────────────────────────────────────────────────────────────────────────
CHARS_POR_TOKEN_ES = 2.4


@dataclass(frozen=True)
class PerfilModelo:
    """Parámetros óptimos para un modelo concreto."""

    nombre: str
    contexto_tokens: int          # ventana de contexto declarada por el proveedor
    max_salida_tokens: int        # tope de tokens de RESPUESTA
    param_tokens: str = "max_tokens"       # o "max_completion_tokens"
    admite_temperature: bool = True
    familia: str = "gpt"
    nota: str = ""

    # ── Derivados para el chunking ──────────────────────────────────────────
    # Se calculan a partir del contexto real en vez de fijarse a mano, para que
    # añadir un modelo al catálogo no obligue a recalcular nada.

    @property
    def contexto_chars(self) -> int:
        return int(self.contexto_tokens * CHARS_POR_TOKEN_ES)

    @property
    def max_ctx(self) -> int:
        """
        Presupuesto de EVIDENCIA por prompt, en caracteres.

        Se reserva el 60 % de la ventana para la evidencia. El 40 % restante
        cubre el prompt de sistema, el enunciado de la actividad, el bloque de
        feedback, el contexto RAG y —sobre todo— la respuesta: si la evidencia
        ocupa toda la ventana, el modelo no tiene sitio para contestar y la
        llamada se corta a mitad.
        """
        return max(4_000, int(self.contexto_chars * 0.60))

    @property
    def chunk_size(self) -> int:
        """
        Tamaño del segmento inicial de chunking.

        Un tercio del presupuesto de evidencia: deja margen para que la
        consolidación jerárquica agrupe varios resúmenes en una misma llamada
        sin desbordar.

        Se acota a 40.000 por CALIDAD, no por límite técnico: resumir 100.000
        caracteres de una vez produce resúmenes genéricos, y este sistema busca
        hallazgos concretos («el manual declara Kupiec pero no aporta
        p-valores»). El detalle vive en segmentos medianos.
        """
        return max(8_000, min(40_000, self.max_ctx // 3))

    @property
    def max_chunks(self) -> int:
        """
        Tope de llamadas por documento.

        40 es el valor medido como óptimo de coste/cobertura en este proyecto
        (README §3.4.1). No baja de 34: por debajo, el modo adaptativo no
        alcanza, cae al jerárquico puro y CUESTA MÁS.
        """
        return 40

    @property
    def presupuesto_doc(self) -> int:
        """Caracteres de resumen final por documento."""
        return max(6_000, int(self.max_ctx * 0.60))


# ═════════════════════════════════════════════════════════════════════════════
# CATÁLOGO
# ═════════════════════════════════════════════════════════════════════════════
# Las claves se comparan por PREFIJO contra `response.model`, que llega con la
# fecha de versión (p. ej. 'gpt-4o-2024-11-20'). Se busca la clave más larga
# que encaje, de modo que 'gpt-4o-mini' gane a 'gpt-4o'.
#
# Los valores de contexto son los publicados por el proveedor. Si tu deployment
# declara otro límite, añade una entrada: el catálogo es de este proyecto, no
# una verdad universal.
# ═════════════════════════════════════════════════════════════════════════════

CATALOGO_MODELOS: Dict[str, PerfilModelo] = {

    # ── OpenAI / Azure OpenAI — razonamiento ────────────────────────────────
    # Rechazan `max_tokens` (exigen `max_completion_tokens`) y no admiten
    # temperature ≠ 1. Ver GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md §6 y §7.
    "gpt-5": PerfilModelo(
        nombre="gpt-5", contexto_tokens=400_000, max_salida_tokens=128_000,
        param_tokens="max_completion_tokens", admite_temperature=False,
        familia="razonamiento",
        nota="Familia de razonamiento: exige max_completion_tokens y temperature=1."),
    "o3": PerfilModelo(
        nombre="o3", contexto_tokens=200_000, max_salida_tokens=100_000,
        param_tokens="max_completion_tokens", admite_temperature=False,
        familia="razonamiento"),
    "o1": PerfilModelo(
        nombre="o1", contexto_tokens=200_000, max_salida_tokens=100_000,
        param_tokens="max_completion_tokens", admite_temperature=False,
        familia="razonamiento"),

    # ── OpenAI / Azure OpenAI — GPT-4 ───────────────────────────────────────
    "gpt-4.1": PerfilModelo(
        nombre="gpt-4.1", contexto_tokens=1_000_000, max_salida_tokens=32_768),
    "gpt-4o-mini": PerfilModelo(
        nombre="gpt-4o-mini", contexto_tokens=128_000, max_salida_tokens=16_384,
        nota="Económico. Verificar calidad de hallazgos antes de usarlo en producción."),
    "gpt-4o": PerfilModelo(
        nombre="gpt-4o", contexto_tokens=128_000, max_salida_tokens=16_384),
    "gpt-4-turbo": PerfilModelo(
        nombre="gpt-4-turbo", contexto_tokens=128_000, max_salida_tokens=4_096),
    "gpt-4-32k": PerfilModelo(
        nombre="gpt-4-32k", contexto_tokens=32_768, max_salida_tokens=4_096),
    "gpt-4": PerfilModelo(
        nombre="gpt-4", contexto_tokens=8_192, max_salida_tokens=4_096,
        nota="⚠️ Contexto de 8K: MENOR que el presupuesto por defecto del proyecto. "
             "El chunking se reduce automáticamente; espera más llamadas."),
    "gpt-35-turbo": PerfilModelo(
        nombre="gpt-35-turbo", contexto_tokens=16_385, max_salida_tokens=4_096,
        nota="No recomendado para dictamen regulatorio: calidad insuficiente."),

    # ── Anthropic (proveedor secundario) ────────────────────────────────────
    "claude-haiku-4-5": PerfilModelo(
        nombre="claude-haiku-4-5", contexto_tokens=200_000,
        max_salida_tokens=8_192, familia="claude"),
    "claude-sonnet-4": PerfilModelo(
        nombre="claude-sonnet-4", contexto_tokens=200_000,
        max_salida_tokens=8_192, familia="claude"),
    "claude-opus-4": PerfilModelo(
        nombre="claude-opus-4", contexto_tokens=200_000,
        max_salida_tokens=8_192, familia="claude"),
    "claude-": PerfilModelo(
        nombre="claude-(genérico)", contexto_tokens=200_000,
        max_salida_tokens=8_192, familia="claude",
        nota="Perfil genérico para modelos Claude no catalogados."),
}


# ═════════════════════════════════════════════════════════════════════════════
# PRECIOS — solo para ESTIMAR antes de gastar
# ═════════════════════════════════════════════════════════════════════════════
# USD por millón de tokens de ENTRADA. Sirven para que los modos `--dry-run`
# puedan decir "esto te va a costar ~$X" antes de lanzar la corrida.
#
# Se declaran aquí, junto al catálogo, y no en el punto de uso, porque ya había
# un literal suelto: `modulos/explicador_modelo.py:706` calcula
# `tokens / 1_000_000 * 1.0` con el precio de Haiku incrustado y sin nombrarlo.
# Un segundo literal en otro módulo es la duplicación que este proyecto ya pagó
# caro con los parámetros de chunking (dos declaraciones, defaults divergentes).
#
# ⚠️ NO son autoritativos: los precios de lista cambian y no se consultan a
# ninguna API. Son una cota de orden de magnitud para decidir si merece la pena
# lanzar la corrida, nunca una cifra para facturar a nadie. Verifica en la
# página de precios del proveedor si el importe importa.
PRECIO_ENTRADA_POR_MTOK_DEFECTO = 1.0

PRECIOS_ENTRADA_USD_POR_MTOK = {
    "claude-haiku-4-5":  1.00,
    "claude-sonnet-4":  3.00,
    "claude-opus-4":   15.00,
    "gpt-4o-mini":      0.15,
    "gpt-4o":           2.50,
    "gpt-4.1":          2.00,
    "gpt-4-turbo":     10.00,
    "gpt-4":           30.00,
    "gpt-5":            1.25,
    "o3":               2.00,
    "o1":              15.00,
}


def precio_entrada_por_mtok(nombre_modelo: Optional[str]) -> float:
    """
    USD por millón de tokens de entrada del modelo, por coincidencia de prefijo.

    Devuelve `PRECIO_ENTRADA_POR_MTOK_DEFECTO` si el modelo no está tarifado:
    es preferible una estimación aproximada y declarada como tal que ninguna
    estimación, porque sin cifra el operador lanza la corrida a ciegas.
    """
    if not nombre_modelo:
        return PRECIO_ENTRADA_POR_MTOK_DEFECTO
    n = str(nombre_modelo).strip().lower()
    candidatas = [k for k in PRECIOS_ENTRADA_USD_POR_MTOK if n.startswith(k)]
    if not candidatas:
        candidatas = [k for k in PRECIOS_ENTRADA_USD_POR_MTOK if k in n]
    if not candidatas:
        return PRECIO_ENTRADA_POR_MTOK_DEFECTO
    return PRECIOS_ENTRADA_USD_POR_MTOK[max(candidatas, key=len)]


# [Paso 57] USD por millón de tokens de SALIDA. Misma advertencia que los de
# entrada: estimaciones de lista, NO autoritativas; el coste real lo da la
# factura de Azure. Sin precio de salida, el coste por corrida se subestimaba
# (la salida suele costar 3-5 veces la entrada).
PRECIO_SALIDA_POR_MTOK_DEFECTO = 4.0

PRECIOS_SALIDA_USD_POR_MTOK = {
    "claude-haiku-4-5":  5.00,
    "claude-sonnet-4":  15.00,
    "claude-opus-4":    75.00,
    "gpt-4o-mini":       0.60,
    "gpt-4o":           10.00,
    "gpt-4.1":           8.00,
    "gpt-4-turbo":      30.00,
    "gpt-4":            60.00,
    "gpt-5":            10.00,
    "o3":                8.00,
    "o1":               60.00,
}


def precio_salida_por_mtok(nombre_modelo: Optional[str]) -> float:
    """USD por millón de tokens de salida (coincidencia de prefijo, como la entrada)."""
    if not nombre_modelo:
        return PRECIO_SALIDA_POR_MTOK_DEFECTO
    n = str(nombre_modelo).strip().lower()
    candidatas = [k for k in PRECIOS_SALIDA_USD_POR_MTOK if n.startswith(k)] or \
                 [k for k in PRECIOS_SALIDA_USD_POR_MTOK if k in n]
    if not candidatas:
        return PRECIO_SALIDA_POR_MTOK_DEFECTO
    return PRECIOS_SALIDA_USD_POR_MTOK[max(candidatas, key=len)]


def coste_usd(nombre_modelo: Optional[str], tokens_entrada: int, tokens_salida: int) -> float:
    """Coste estimado = tokens × precio / 1e6 (entrada y salida por separado)."""
    return round(int(tokens_entrada) * precio_entrada_por_mtok(nombre_modelo) / 1_000_000
                 + int(tokens_salida) * precio_salida_por_mtok(nombre_modelo) / 1_000_000, 6)


# Perfil de reserva: contexto pequeño y sin suposiciones sobre parámetros.
# Se prefiere quedarse corto —más llamadas de las necesarias— antes que exceder
# el contexto, que produciría truncados silenciosos y pérdida de cobertura.
PERFIL_CONSERVADOR = PerfilModelo(
    nombre="(desconocido)", contexto_tokens=16_000, max_salida_tokens=4_096,
    nota="Modelo no catalogado: perfil conservador. Añádelo a "
         "config/modelos.py para aprovechar su contexto real.")


def perfil_modelo(nombre_modelo: Optional[str], verbose: bool = True) -> PerfilModelo:
    """
    Devuelve el perfil del modelo por coincidencia de PREFIJO más larga.

    `response.model` llega con la fecha de versión ('gpt-4o-2024-11-20'), así
    que no sirve una búsqueda exacta. Se elige la clave más larga que encaje
    para que 'gpt-4o-mini' no caiga en el perfil de 'gpt-4o'.
    """
    if not nombre_modelo:
        return PERFIL_CONSERVADOR
    n = str(nombre_modelo).strip().lower()
    candidatas = [k for k in CATALOGO_MODELOS if n.startswith(k)]
    if not candidatas:
        # Segunda pasada: el deployment puede llevar prefijo propio
        # ('virf-gpt-4o-prod'), así que se busca la clave CONTENIDA.
        candidatas = [k for k in CATALOGO_MODELOS if k in n]
    if not candidatas:
        if verbose:
            print(f"  ⚠️  Modelo '{nombre_modelo}' no está en config/modelos.py. "
                  f"Se usa un perfil conservador ({PERFIL_CONSERVADOR.contexto_tokens:,} "
                  f"tokens de contexto). Añádelo al catálogo para aprovechar su "
                  f"ventana real.")
        return PERFIL_CONSERVADOR
    return CATALOGO_MODELOS[max(candidatas, key=len)]
