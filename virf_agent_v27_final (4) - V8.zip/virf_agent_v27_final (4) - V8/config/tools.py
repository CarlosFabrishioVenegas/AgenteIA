"""
config/tools.py  [Paso 15 · Paso 49]
═════════════════════════════════════════════════════════════════════════════
Catálogo de herramientas (tools) del agente con política DENY BY DEFAULT.

Las herramientas son las 6 skills tipadas de `skills/` (declaraciones para
function calling). Hoy solo `run_data_quality_check` es operativa; las otras 5
están declaradas pero DESHABILITADAS explícitamente hasta que exista el
coordinador y se aprueben.

Reglas de `invocar()`:
  · tool no registrada en CATALOGO            → ToolNoRegistrada
  · tool con estado != "operativa"            → ToolDeshabilitada
  · rol del invocante fuera de `roles`        → PermisoTool
  · si pasa: se ejecuta y queda en la auditoría (SEG-12)
Todo lo que no está explícitamente permitido, está prohibido.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable

__all__ = ["CATALOGO", "invocar", "ToolNoRegistrada", "ToolDeshabilitada", "PermisoTool"]


class ToolNoRegistrada(PermissionError):
    pass


class ToolDeshabilitada(PermissionError):
    pass


class PermisoTool(PermissionError):
    pass


CATALOGO: Dict[str, Dict[str, Any]] = {
    "run_data_quality_check": {
        "proposito": "Controles deterministas de calidad de datos sobre datasets del modelo",
        "roles": ("validador",),
        "datos": "Datasets del modelo validado (Interno; Restringido solo en Databricks)",
        "riesgo": "Medio: lee datos; no escribe fuera de outputs/ ni llama a la red",
        "estado": "operativa",
    },
    "analyze_document_versioning": {
        "proposito": "Comparar versiones de documentos del modelo",
        "roles": (), "datos": "Manuales del modelo", "riesgo": "Bajo",
        "estado": "deshabilitada",
    },
    "retrieve_methodology_evidence": {
        "proposito": "Recuperar evidencia metodológica del corpus",
        "roles": (), "datos": "Corpus RAG + evidencia", "riesgo": "Bajo",
        "estado": "deshabilitada",
    },
    "check_compliance_government": {
        "proposito": "Verificar cumplimiento de gobierno del modelo",
        "roles": (), "datos": "Actas, políticas", "riesgo": "Medio",
        "estado": "deshabilitada",
    },
    "verify_code_implementation": {
        "proposito": "Contrastar implementación de código con el manual",
        "roles": (), "datos": "Código del modelo", "riesgo": "Medio",
        "estado": "deshabilitada",
    },
    "ingest_operational_channels": {
        "proposito": "Ingerir correos .msg/.eml, .pptx y hojas de cálculo operativas",
        "roles": (), "datos": "Correos y documentos (posible PII)", "riesgo": "Alto",
        "estado": "deshabilitada",
    },
}


def _roles_de(roles: Iterable[str] | str | None) -> set:
    if roles is None:
        return set()
    return {roles} if isinstance(roles, str) else set(roles)


def invocar(nombre: str, roles_invocante, quien: str = "", **kwargs) -> Any:
    """Ejecuta la herramienta SOLO si está registrada, operativa y permitida."""
    ficha = CATALOGO.get(nombre)
    if ficha is None:
        raise ToolNoRegistrada(f"tool {nombre!r} no registrada en el catálogo")
    if ficha["estado"] != "operativa":
        raise ToolDeshabilitada(f"tool {nombre!r} está {ficha['estado']}")
    if not (_roles_de(roles_invocante) & set(ficha["roles"])):
        raise PermisoTool(f"tool {nombre!r} requiere rol {', '.join(ficha['roles'])}")
    from skills import SKILLS_TIPADAS
    from modulos import auditoria
    try:
        resultado = SKILLS_TIPADAS[nombre]().ejecutar(**kwargs)
    except Exception as exc:
        auditoria.registrar("invocacion_tool", nombre, resultado=f"error:{type(exc).__name__}",
                            quien=quien or None)
        raise
    auditoria.registrar("invocacion_tool", nombre, quien=quien or None)
    return resultado
