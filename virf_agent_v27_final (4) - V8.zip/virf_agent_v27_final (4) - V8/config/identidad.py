"""
config/identidad.py  [SEG-02]
═════════════════════════════════════════════════════════════════════════════
Identidad corporativa del validador y firma del informe.

Norma 2135.010.02 §Aseguramiento/§Exploración · 4180.223.08: el firmante de un
informe es la persona AUTENTICADA, no un nombre tecleado. Antes el firmante
salía de `--validador` / `VIRF_VALIDADOR` y la web daba de alta al vuelo a
cualquiera con un código y un nombre.

PIEZAS
──────
· `IdentityProvider` — interfaz. `EntraIDProvider` hace login OIDC (código de
  autorización) contra Microsoft Entra ID con `msal`. `ProveedorSimulado`
  existe SOLO para tests: se niega a construirse fuera de pytest.
  `ProveedorLibre` — «usuario libre» para PROBAR la web sin Entra ID (web v2).
  Solo con VIRF_IDENTIDAD_PROVEEDOR=libre declarado y MODO distinto de
  produccion; la identidad queda marcada como de prueba (dominio
  @prueba.local y cargo «usuario de prueba (sin SSO)»), así que un informe
  firmado así no puede pasar por uno firmado con identidad corporativa.
  El SSO real queda para la web v3: docs/LOGIN_CORPORATIVO_WEB_V3.md.
· `Identidad` — oid/upn (identificador único corporativo), nombre, cargo y
  `codigo` (carpeta del validador en disco).
· ASERCIÓN — la web, con una sesión SSO válida, emite una aserción firmada
  (HMAC-SHA256, clave `VIRF_CLAVE_FIRMA_SESION` desde Key Vault / scope) y la
  pasa al pipeline en `VIRF_ASERCION_IDENTIDAD`. El pipeline SOLO acepta un
  firmante que venga de una aserción válida y vigente: sin ella no corre.

Configuración Entra (la entrega el equipo de identidad 👤):
    VIRF_ENTRA_TENANT_ID, VIRF_ENTRA_CLIENT_ID, VIRF_ENTRA_REDIRECT_URI
    secreto VIRF_ENTRA_CLIENT_SECRET (Key Vault: virf-entra-client-secret)
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import sys
import time
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional, Tuple

__all__ = ["Identidad", "IdentityProvider", "EntraIDProvider", "ProveedorSimulado",
           "ProveedorLibre", "DOMINIO_PRUEBA", "MARCA_PRUEBA", "proveedor_activo",
           "obtener_proveedor", "emitir_asercion", "verificar_asercion",
           "identidad_autenticada", "AsercionInvalida", "IdentidadNoConfigurada",
           "VAR_ASERCION", "VAR_ASERCION_2"]

VAR_ASERCION = "VIRF_ASERCION_IDENTIDAD"
VAR_ASERCION_2 = "VIRF_ASERCION_IDENTIDAD_2"
_VERSION = 1


class AsercionInvalida(PermissionError):
    """Aserción ausente, manipulada o caducada."""


class IdentidadNoConfigurada(RuntimeError):
    """El proveedor de identidad no está configurado (falta registro en Entra)."""


@dataclass(frozen=True)
class Identidad:
    oid: str                 # identificador inmutable del usuario (Entra «oid»)
    upn: str                 # usuario corporativo (preferred_username)
    nombre: str
    cargo: str = "Validador"
    codigo: str = ""         # carpeta del validador en disco
    roles: Tuple[str, ...] = ()   # [SEG-08] app roles de Entra (claim «roles»)

    def __post_init__(self):
        if not self.oid or not self.upn or not self.nombre:
            raise ValueError("identidad incompleta: oid, upn y nombre son obligatorios")

    @staticmethod
    def codigo_de(upn: str, preferido: str = "") -> str:
        base = preferido or (upn or "").split("@")[0]
        return re.sub(r"[^A-Za-z0-9_-]", "_", base).upper()[:40] or "SIN_CODIGO"

    def a_dict(self) -> Dict[str, str]:
        d = asdict(self)
        d["codigo"] = self.codigo or Identidad.codigo_de(self.upn)
        d["roles"] = list(self.roles)
        return d


# ═════════════════════════════════════════════════════════════════════════════
# PROVEEDORES
# ═════════════════════════════════════════════════════════════════════════════

class IdentityProvider(ABC):
    """Login delegado: `iniciar` da la URL de autorización y el estado a guardar
    en servidor; `completar` canjea la respuesta del IdP por una Identidad."""

    @abstractmethod
    def iniciar(self) -> Tuple[str, str, Dict[str, Any]]:
        """Devuelve (url_autorizacion, state, flujo_a_guardar)."""

    @abstractmethod
    def completar(self, flujo: Dict[str, Any], parametros: Dict[str, str]) -> Identidad:
        """Valida state/nonce y devuelve la identidad autenticada."""


class EntraIDProvider(IdentityProvider):
    """OIDC con Microsoft Entra ID (flujo de código de autorización + PKCE, vía msal)."""

    SCOPES = ["User.Read"]

    def __init__(self):
        self.tenant = os.getenv("VIRF_ENTRA_TENANT_ID", "").strip()
        self.client_id = os.getenv("VIRF_ENTRA_CLIENT_ID", "").strip()
        self.redirect = os.getenv("VIRF_ENTRA_REDIRECT_URI", "").strip()
        faltan = [n for n, v in (("VIRF_ENTRA_TENANT_ID", self.tenant),
                                 ("VIRF_ENTRA_CLIENT_ID", self.client_id),
                                 ("VIRF_ENTRA_REDIRECT_URI", self.redirect)) if not v]
        if faltan:
            raise IdentidadNoConfigurada(
                "❌ Login corporativo no configurado: faltan " + ", ".join(faltan)
                + ". Las entrega el equipo de identidad al registrar la app en Entra ID.")
        if not self.redirect.startswith("https://") and "localhost" not in self.redirect:
            raise IdentidadNoConfigurada("❌ VIRF_ENTRA_REDIRECT_URI debe ser https://.")
        try:
            import msal                                       # type: ignore
        except ImportError as exc:
            raise IdentidadNoConfigurada(
                "❌ Falta el paquete msal (aprobarlo y fijar versión).") from exc
        from .secretos import obtener_secreto
        self._app = msal.ConfidentialClientApplication(
            self.client_id,
            authority=f"https://login.microsoftonline.com/{self.tenant}",
            client_credential=obtener_secreto("VIRF_ENTRA_CLIENT_SECRET"))

    def iniciar(self):
        flujo = self._app.initiate_auth_code_flow(self.SCOPES, redirect_uri=self.redirect)
        return flujo["auth_uri"], flujo["state"], flujo

    def completar(self, flujo, parametros):
        r = self._app.acquire_token_by_auth_code_flow(flujo, parametros)
        if "error" in r:
            raise AsercionInvalida(f"Entra ID rechazó el login: {r.get('error')}")
        c = r.get("id_token_claims") or {}
        if c.get("tid") != self.tenant:
            raise AsercionInvalida("token de otro tenant")
        upn = c.get("preferred_username") or c.get("upn") or ""
        return Identidad(oid=c.get("oid", ""), upn=upn, nombre=c.get("name", ""),
                         cargo=c.get("jobTitle") or "Validador",
                         codigo=Identidad.codigo_de(upn, c.get("employeeid", "")),
                         roles=tuple(c.get("roles") or ()))


class ProveedorSimulado(IdentityProvider):
    """IdP falso para tests. Fuera de pytest no se puede construir."""

    def __init__(self, identidad: Optional[Identidad] = None):
        if "pytest" not in sys.modules:
            raise IdentidadNoConfigurada("ProveedorSimulado solo existe para tests.")
        self.identidad = identidad or Identidad(
            oid="00000000-0000-0000-0000-000000000001", upn="ana.quispe@bcp.com.pe",
            nombre="Ana Quispe", cargo="Validador de Segunda Línea", codigo="T5443",
            roles=("validador",))

    def iniciar(self):
        state = os.urandom(8).hex()
        return f"https://idp.simulado/authorize?state={state}", state, {"state": state}

    def completar(self, flujo, parametros):
        if parametros.get("state") != flujo.get("state") or not parametros.get("code"):
            raise AsercionInvalida("state o code inválidos")
        return self.identidad


DOMINIO_PRUEBA = "prueba.local"
MARCA_PRUEBA = "usuario de prueba (sin SSO)"
_ROLES_VALIDOS = ("validador", "revisor", "admin_corpus")


class ProveedorLibre(IdentityProvider):
    """«Usuario libre» para probar la web sin Entra ID. NO es autenticación:
    quien escribe el nombre es quien queda registrado, y por eso la identidad
    resultante va marcada como de prueba en todas partes."""

    def __init__(self):
        from . import parametros
        if parametros.MODO == "produccion":
            raise IdentidadNoConfigurada(
                "❌ El usuario libre está prohibido con MODO=produccion: "
                "declara MODO=debug (o usa scripts/web_prueba.py).")

    def iniciar(self):
        raise IdentidadNoConfigurada(
            "Modo usuario libre: entra con el formulario de prueba (POST /api/auth/login-libre).")

    def completar(self, flujo, parametros):
        raise IdentidadNoConfigurada("Modo usuario libre: no hay callback de IdP.")

    @staticmethod
    def identidad(nombre: str, cargo: str = "", roles=("validador",)) -> Identidad:
        nombre = re.sub(r"\s+", " ", (nombre or "")).strip()
        if not 2 <= len(nombre) <= 80:
            raise ValueError("el nombre debe tener entre 2 y 80 caracteres")
        roles = tuple(r for r in _ROLES_VALIDOS if r in set(roles or ()))
        if not roles:
            raise ValueError(f"elige al menos un rol: {', '.join(_ROLES_VALIDOS)}")
        slug = re.sub(r"[^a-z0-9]+", ".", nombre.lower()).strip(".") or "usuario"
        upn = f"{slug}@{DOMINIO_PRUEBA}"
        cargo = re.sub(r"\s+", " ", (cargo or "Validador")).strip()[:60] or "Validador"
        return Identidad(oid="prueba-" + hashlib.sha256(upn.encode()).hexdigest()[:24],
                         upn=upn, nombre=nombre, cargo=f"{cargo} · {MARCA_PRUEBA}",
                         codigo=Identidad.codigo_de(upn, "PRUEBA_" + slug), roles=roles)


def proveedor_activo() -> str:
    """Nombre del proveedor declarado en VIRF_IDENTIDAD_PROVEEDOR (por defecto entra)."""
    return (os.getenv("VIRF_IDENTIDAD_PROVEEDOR") or "entra").strip().lower()


def obtener_proveedor() -> IdentityProvider:
    """Proveedor elegido EXPLÍCITAMENTE por VIRF_IDENTIDAD_PROVEEDOR (entra|libre|simulado)."""
    tipo = proveedor_activo()
    if tipo == "entra":
        return EntraIDProvider()
    if tipo == "libre":
        return ProveedorLibre()
    if tipo == "simulado":
        return ProveedorSimulado()
    raise IdentidadNoConfigurada(f"VIRF_IDENTIDAD_PROVEEDOR={tipo!r} no válido (entra|libre).")


# ═════════════════════════════════════════════════════════════════════════════
# ASERCIÓN FIRMADA (web → pipeline)
# ═════════════════════════════════════════════════════════════════════════════

def _clave() -> bytes:
    from .secretos import obtener_secreto
    clave = obtener_secreto("VIRF_CLAVE_FIRMA_SESION")
    if len(clave) < 32:
        raise IdentidadNoConfigurada("VIRF_CLAVE_FIRMA_SESION debe tener ≥32 caracteres.")
    return clave.encode("utf-8")


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode("ascii").rstrip("=")


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def emitir_asercion(identidad: Identidad, ttl_s: int = 4 * 3600) -> str:
    ahora = int(time.time())
    carga = {"v": _VERSION, "iat": ahora, "exp": ahora + int(ttl_s), **identidad.a_dict()}
    cuerpo = _b64(json.dumps(carga, sort_keys=True, ensure_ascii=False).encode("utf-8"))
    firma = hmac.new(_clave(), cuerpo.encode("ascii"), hashlib.sha256).hexdigest()
    return f"{cuerpo}.{firma}"


def verificar_asercion(token: Optional[str]) -> Identidad:
    if not token or token.count(".") != 1:
        raise AsercionInvalida("sin aserción de identidad")
    cuerpo, firma = token.split(".")
    esperada = hmac.new(_clave(), cuerpo.encode("ascii"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(esperada, firma):
        raise AsercionInvalida("aserción de identidad manipulada (firma no válida)")
    try:
        carga = json.loads(_unb64(cuerpo))
    except Exception as exc:                                   # noqa: BLE001
        raise AsercionInvalida("aserción ilegible") from exc
    if carga.get("v") != _VERSION or int(carga.get("exp", 0)) < time.time():
        raise AsercionInvalida("aserción de identidad caducada")
    return Identidad(oid=carga["oid"], upn=carga["upn"], nombre=carga["nombre"],
                     cargo=carga.get("cargo") or "Validador", codigo=carga.get("codigo", ""),
                     roles=tuple(carga.get("roles") or ()))


def identidad_autenticada(variable: str = VAR_ASERCION) -> Optional[Identidad]:
    """Identidad de la aserción del entorno, o None si no hay. Si la hay pero es
    inválida, LANZA (una aserción falsa no se trata como «no hay sesión»)."""
    token = os.environ.get(variable, "").strip()
    if not token:
        return None
    return verificar_asercion(token)
