"""
config/virf_plus.py
═════════════════════════════════════════════════════════════════════════════
VIRF PLUS — el agente principal (GPT) suma a Claude como segunda opinión.

Por qué un CLIENTE y no un cambio en cada módulo
------------------------------------------------
Todo el sistema (controles del pipeline, chat de sustentación, entailment,
generador de notebooks, informe) habla con la IA a través de un único
`config.get_cliente_ia().generar_mensaje(...)`. `ClienteConsensoIA` cumple esa
misma interfaz, así que encender VIRF PLUS adapta TODOS los consumidores a la
vez sin tocar sus prompts ni sus parsers.

Cómo llega a una conclusión
---------------------------
  1. La MISMA tarea (sistema + prompt + evidencia) va a GPT y a Claude en
     paralelo. Ninguno ve la respuesta del otro: dos opiniones independientes.
  2. Se comparan los campos de decisión (puntaje, resultado, veredicto,
     cumple…) cuando la respuesta es JSON.
  3. Un árbitro (GPT, el agente principal, por defecto) recibe la tarea original y las dos
     respuestas y redacta UNA respuesta final en el formato exacto que pedía
     la tarea. Regla de prudencia: si la evidencia no zanja un desacuerdo de
     puntaje o resultado, gana la lectura más conservadora.
  4. Cada conciliación queda en `audit_logs/virf_plus_consenso.jsonl` con las
     dos opiniones, las discrepancias y la conclusión, para que el validador
     humano pueda ver dónde discreparon los modelos antes de firmar.

Sin fallback silencioso: si uno de los dos modelos falla, la llamada falla.
Una «conclusión conjunta» con un solo evaluador sería mentir en el informe.

Lo que SÍ se resuelve sin tumbar la evaluación es un fallo del ÁRBITRO: las dos
opiniones independientes ya existen, así que se aplica de forma determinista la
misma regla de prudencia que el árbitro tiene por instrucción (gana la lectura
más conservadora) y queda anotado en la bitácora como `resolucion`.
"""

from __future__ import annotations

import contextvars
import hashlib
import json
import os
import re
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from .ia import ClienteIA, ClienteAnthropicIA, FABRICAS
from .parametros import VIRF_PLUS_ARBITRAJE, VIRF_PLUS_ARBITRO, VIRF_PLUS_GPT
from .rutas import BASE_DIR

__all__ = ["ClienteConsensoIA", "comparar_respuestas", "INSTRUCCION_ARBITRO",
           "proveedor_gpt"]

_GPT_VALIDOS = ("azure_openai", "openai")
_ARBITROS_GPT = ("gpt", "openai", "azure_openai")
_ARBITROS_CLAUDE = ("claude", "anthropic")
_ARBITRAJES = ("siempre", "discrepancia")


def proveedor_gpt() -> str:
    """
    De dónde sale la voz GPT de VIRF PLUS.

    Misma regla que `ia.proveedor_activo`: en producción, VIRF_PLUS_GPT tal
    cual; fuera de producción, si el declarado no tiene credenciales completas
    y el otro GPT sí, se usa el que las tiene. Así basta con poner la clave de
    OpenAI o las de Azure, sin tocar VIRF_PLUS_GPT.
    """
    from . import ia as _ia
    preferido = str(VIRF_PLUS_GPT or "azure_openai").strip().lower()
    if _ia._en_produccion():
        return preferido
    candidatos = [p for p in _GPT_VALIDOS
                  if _ia.proveedor_autorizado(p) and _ia._credenciales_completas(p)]
    if preferido in candidatos or not candidatos:
        return preferido
    return candidatos[0]

# Campos que deciden el dictamen. Si difieren entre los dos modelos hay una
# discrepancia de fondo, no de redacción.
CAMPOS_DECISION = (
    "puntaje", "score", "calificacion", "resultado", "veredicto", "dictamen",
    "cumple", "implica", "estado", "nivel_riesgo", "riesgo", "severidad",
)

INSTRUCCION_ARBITRO = """\
MODO VIRF PLUS — CONCILIACIÓN DE DOS EVALUADORES

Dos evaluadores independientes (A = GPT, agente principal; B = Claude, segunda
opinión) resolvieron la misma tarea sobre la misma evidencia sin ver la
respuesta del otro. Tu trabajo es emitir la
CONCLUSIÓN ÚNICA que firmaría un validador senior:

1. Contrasta ambas respuestas contra la evidencia de la TAREA ORIGINAL. Un
   hallazgo solo se conserva si la evidencia lo sostiene; descarta lo que
   cualquiera de los dos haya afirmado sin respaldo.
2. Donde coinciden, fusiona su redacción en la explicación más clara y
   completa: describe el producto/modelo y el proceso con precisión técnica.
3. Donde discrepan en puntaje, resultado o veredicto, decide por la evidencia.
   Si la evidencia no lo zanja, adopta la lectura MÁS CONSERVADORA (menor
   puntaje, resultado menos favorable): en validación, la duda no favorece al
   modelo validado.
4. No inventes evidencia, citas ni cifras que no estén en la tarea original.
5. Devuelve la respuesta en EXACTAMENTE el formato que pide la tarea original
   (mismas claves si es JSON, sin claves nuevas, sin markdown ni texto fuera
   del JSON). No menciones a «evaluador A/B» en el texto final salvo que el
   formato tenga un campo para ello.
"""

_LOCK_LOG = threading.Lock()
_MAX_HISTORIAL = 200


# ─── Comparación ────────────────────────────────────────────────────────────

def _json_laxo(texto: str) -> Optional[Any]:
    """Primer objeto/lista JSON del texto (tolera fences y prosa). None si no hay."""
    if not texto:
        return None
    limpio = re.sub(r"^\s*```(?:json)?\s*", "", texto.strip())
    limpio = re.sub(r"\s*```\s*$", "", limpio).strip()
    try:
        return json.loads(limpio)
    except (json.JSONDecodeError, ValueError):
        pass
    inicio = limpio.find("{")
    if inicio == -1:
        return None
    prof = 0
    for i in range(inicio, len(limpio)):
        if limpio[i] == "{":
            prof += 1
        elif limpio[i] == "}":
            prof -= 1
            if prof == 0:
                try:
                    return json.loads(limpio[inicio:i + 1])
                except (json.JSONDecodeError, ValueError):
                    return None
    return None


def _campos_decision(obj: Any, prefijo: str = "") -> dict:
    """Aplana los campos de decisión de un JSON (incluidos los anidados)."""
    salida: dict = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            ruta = f"{prefijo}{k}"
            if str(k).lower() in CAMPOS_DECISION and not isinstance(v, (dict, list)):
                salida[ruta] = v
            elif isinstance(v, (dict, list)):
                salida.update(_campos_decision(v, ruta + "."))
    elif isinstance(obj, list):
        for i, v in enumerate(obj[:50]):
            salida.update(_campos_decision(v, f"{prefijo}{i}."))
    return salida


def _normalizar(v: Any) -> str:
    """Forma canónica para comparar: `3`, `3.0` y `"3"` son el mismo puntaje."""
    if isinstance(v, bool):
        return str(v).lower()
    if isinstance(v, (int, float)):
        return repr(float(v))
    texto = re.sub(r"\s+", " ", str(v)).strip().lower()
    try:
        return repr(float(texto))
    except ValueError:
        return texto


_CAMPOS_PUNTAJE = ("puntaje", "score", "calificacion")


def _puntaje_de(texto: str) -> Optional[float]:
    """Puntaje numérico de primer nivel de una respuesta JSON, o None."""
    obj = _json_laxo(texto)
    if not isinstance(obj, dict):
        return None
    for campo in _CAMPOS_PUNTAJE:
        v = obj.get(campo)
        if isinstance(v, bool):
            continue
        try:
            return float(v)
        except (TypeError, ValueError):
            continue
    return None


def _mas_conservadora(a: str, b: str) -> str:
    """De dos respuestas, la de MENOR puntaje. Sin puntaje comparable, la del
    agente principal (A)."""
    pa, pb = _puntaje_de(a), _puntaje_de(b)
    return b if (pa is not None and pb is not None and pb < pa) else a


def _llamada_independiente(cliente, kw: dict):
    """
    Llama a un cliente interno como llamada de gateway PROPIA.

    La profundidad de gateway es un `ContextVar`; se pone a 0 en un contexto
    copiado para que cada proveedor deje su propia entrada de auditoría (modelo,
    tokens y coste reales) también cuando la llamada sale del hilo principal,
    como la del árbitro. El saneado que eso repite es idempotente.
    """
    from . import ia as _ia

    def _ejecutar():
        _ia._EN_GATEWAY.set(0)
        return cliente.generar_mensaje(**kw)
    return contextvars.copy_context().run(_ejecutar)


def comparar_respuestas(a: str, b: str) -> dict:
    """
    Compara dos respuestas. Devuelve:
      json         ambas parsean como JSON
      coinciden    campos de decisión iguales en ambas
      discrepancias {campo: [valor_A, valor_B]}
      acuerdo      True si no hay discrepancia de fondo
    """
    ja, jb = _json_laxo(a), _json_laxo(b)
    if ja is None or jb is None:
        igual = _normalizar(a) == _normalizar(b)
        return {"json": False, "coinciden": [], "discrepancias": {},
                "acuerdo": igual}
    ca, cb = _campos_decision(ja), _campos_decision(jb)
    coinciden, discrepancias = [], {}
    for campo in sorted(set(ca) | set(cb)):
        va, vb = ca.get(campo), cb.get(campo)
        if _normalizar(va) == _normalizar(vb):
            coinciden.append(campo)
        else:
            discrepancias[campo] = [va, vb]
    return {"json": True, "coinciden": coinciden,
            "discrepancias": discrepancias, "acuerdo": not discrepancias}


# ─── Cliente ────────────────────────────────────────────────────────────────

def _nombre_modelo(cliente) -> str:
    return str(getattr(cliente, "_modelo_real", None)
               or getattr(cliente, "modelo", None)
               or getattr(cliente, "deployment", None)
               or type(cliente).__name__)


class ClienteConsensoIA(ClienteIA):
    """Cliente IA que consulta a Claude y a GPT y concilia sus respuestas."""

    PROVEEDOR = "virf_plus"
    COMPUESTO = True   # se autoriza cada cliente interno (SEG-01)

    def __init__(self, claude: Optional[ClienteIA] = None,
                 gpt: Optional[ClienteIA] = None,
                 arbitro: Optional[str] = None,
                 arbitraje: Optional[str] = None,
                 ruta_log: Optional[Path] = None):
        from . import ia as _ia
        prov_gpt = proveedor_gpt()
        if gpt is None and prov_gpt not in _GPT_VALIDOS:
            raise ValueError(
                f"❌ VIRF_PLUS_GPT='{prov_gpt}' no es válido. "
                f"Usa 'openai' (API key de OpenAI) o 'azure_openai'.")
        # [SEG-01] VIRF PLUS envía la misma evidencia a dos proveedores: no
        # arranca si alguno no puede ejecutarse en este proceso. En producción
        # Claude está EN_ESPERA; fuera de producción se permite para pruebas.
        bloqueados = [f"{p} ({_ia.estado_efectivo(p)})"
                      for p in ("anthropic", prov_gpt)
                      if not _ia.proveedor_autorizado(p)]
        if bloqueados:
            raise _ia.ProveedorNoAutorizado(
                "❌ VIRF PLUS bloqueado hasta aprobación del proveedor: "
                + ", ".join(bloqueados) + ". Usa el agente principal (Azure OpenAI)"
                + ("" if not _ia._en_produccion() else
                   ", o pruébalo fuera de producción (MODO=debug)") + ".")
        self.arbitro = str(arbitro or VIRF_PLUS_ARBITRO or "gpt").strip().lower()
        self.arbitraje = str(arbitraje or VIRF_PLUS_ARBITRAJE or "siempre").strip().lower()
        # Un valor mal escrito NO puede elegir árbitro por descarte: antes
        # cualquier cosa que no fuera «gpt» caía en Claude sin avisar.
        if self.arbitro not in _ARBITROS_GPT + _ARBITROS_CLAUDE:
            raise ValueError(
                f"❌ VIRF_PLUS_ARBITRO='{self.arbitro}' no es válido. Usa 'gpt' o 'anthropic'.")
        if self.arbitraje not in _ARBITRAJES:
            raise ValueError(
                f"❌ VIRF_PLUS_ARBITRAJE='{self.arbitraje}' no es válido. "
                "Usa 'siempre' o 'discrepancia'.")
        # Errores de configuración (clave vacía, placeholder) salen con el
        # mensaje del propio proveedor, que dice qué variable falta. Se junta
        # lo que falte de LOS DOS, para no arreglar una clave y tropezar con la
        # otra en el siguiente intento.
        faltan = []
        if claude is None:
            try:
                claude = _ia._instanciar("anthropic")
            except (ValueError, ImportError) as exc:
                faltan.append(f"Claude — {str(exc).strip()}")
        if gpt is None:
            try:
                gpt = _ia._instanciar(prov_gpt)
            except (ValueError, ImportError) as exc:
                faltan.append(f"GPT ({prov_gpt}) — {str(exc).strip()}")
        if faltan:
            raise ValueError(
                "❌ VIRF PLUS necesita los DOS evaluadores y falta configurar:\n   · "
                + "\n   · ".join(faltan)
                + "\n   Con una sola clave el agente funciona igual: apaga VIRF PLUS "
                  "(VIRF_PLUS=0).")
        self.claude = claude
        self.gpt = gpt
        self.ruta_log = Path(ruta_log) if ruta_log else (
            Path(os.getenv("VIRF_PLUS_LOG", "")) if os.getenv("VIRF_PLUS_LOG")
            else BASE_DIR / "audit_logs" / "virf_plus_consenso.jsonl")
        self.ultimo_consenso: dict = {}
        self.historial: list = []

    # Perfil de contexto: el del modelo GPT, que suele ser la ventana más
    # estrecha de los dos. Un prompt que cabe en GPT cabe en Claude.
    @property
    def modelo(self) -> str:
        return _nombre_modelo(self.gpt)

    @property
    def descripcion(self) -> str:
        return (f"GPT {_nombre_modelo(self.gpt)} + Claude {_nombre_modelo(self.claude)}"
                f" · árbitro={self.arbitro} · arbitraje={self.arbitraje}")

    def _cliente_arbitro(self) -> ClienteIA:
        return self.gpt if self.arbitro in _ARBITROS_GPT else self.claude

    # ── Interfaz ClienteIA ──────────────────────────────────────────────────

    def generar_mensaje(self, prompt: str, instruccion_sistema: str = "",
                        max_tokens: int = None, sistema: str = None,
                        formato_json: bool = False) -> str:
        kw = dict(prompt=prompt, instruccion_sistema=instruccion_sistema,
                  max_tokens=max_tokens, sistema=sistema, formato_json=formato_json)

        respuestas, errores = {}, {}
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="virf_plus") as ex:
            futuros = {"gpt": ex.submit(_llamada_independiente, self.gpt, kw),
                       "claude": ex.submit(_llamada_independiente, self.claude, kw)}
            for nombre, fut in futuros.items():
                try:
                    respuestas[nombre] = fut.result()
                except Exception as exc:  # se reporta abajo, con el otro
                    errores[nombre] = f"{type(exc).__name__}: {exc}"
        if errores:
            raise RuntimeError(
                "❌ VIRF PLUS no pudo obtener las dos opiniones — "
                + " | ".join(f"{k.upper()}: {v}" for k, v in errores.items())
                + ". No se emite una conclusión conjunta con un solo evaluador; "
                  "corrige la credencial indicada o apaga VIRF PLUS.")

        # Una respuesta vacía no es una opinión: contarla como tal sería, otra
        # vez, una conclusión conjunta con un solo evaluador.
        vacias = [k.upper() for k, v in respuestas.items()
                  if not isinstance(v, str) or not v.strip()]
        if vacias:
            raise RuntimeError(
                "❌ VIRF PLUS no pudo obtener las dos opiniones — respuesta vacía de "
                + ", ".join(vacias) + ". No se emite una conclusión conjunta con un "
                  "solo evaluador; reintenta o apaga VIRF PLUS.")

        # A = agente principal (GPT): si coinciden y no se arbitra, vale la suya.
        a, b = respuestas["gpt"], respuestas["claude"]
        comp = comparar_respuestas(a, b)

        error_arbitro = ""
        if self.arbitraje == "discrepancia" and comp["acuerdo"]:
            final, arbitrado, resolucion = a, False, "acuerdo"
        else:
            arbitrado, resolucion = True, "arbitro"
            try:
                final = self._arbitrar(prompt, sistema or instruccion_sistema,
                                       a, b, comp, max_tokens, formato_json)
                # Si las dos opiniones eran JSON, la conclusión también debe
                # serlo: el pipeline la va a parsear con el mismo contrato.
                if comp["json"] and _json_laxo(final) is None:
                    raise RuntimeError("el árbitro no devolvió JSON válido")
            except Exception as exc:                        # noqa: BLE001
                error_arbitro = f"{type(exc).__name__}: {exc}"
                final = _mas_conservadora(a, b)
                arbitrado, resolucion = False, "conservadora_por_fallo_del_arbitro"
                print("  ⚠️  VIRF PLUS: el árbitro falló; se adopta la opinión MÁS "
                      f"CONSERVADORA de las dos ({error_arbitro[:160]}).")

        self._registrar(prompt, a, b, final, comp, arbitrado, resolucion, error_arbitro)
        return final

    def _arbitrar(self, prompt, sistema_original, a, b, comp,
                  max_tokens, formato_json) -> str:
        if comp["discrepancias"]:
            disc = "\n".join(f"  · {campo}: A={va!r}  ·  B={vb!r}"
                             for campo, (va, vb) in comp["discrepancias"].items())
        elif comp["json"]:
            disc = "  · Ninguna en los campos de decisión: concilia la redacción."
        else:
            disc = "  · Respuestas en texto libre: compáralas tú."

        prompt_arbitro = (
            "=== TAREA ORIGINAL (con su evidencia) ===\n"
            f"{prompt}\n\n"
            f"=== RESPUESTA DEL EVALUADOR A (GPT · {_nombre_modelo(self.gpt)}) ===\n"
            f"{a}\n\n"
            f"=== RESPUESTA DEL EVALUADOR B (Claude · {_nombre_modelo(self.claude)}) ===\n"
            f"{b}\n\n"
            "=== DISCREPANCIAS DETECTADAS EN CAMPOS DE DECISIÓN ===\n"
            f"{disc}\n\n"
            "=== TU TAREA ===\n"
            "Emite la respuesta FINAL conciliada, en el formato exacto que pide "
            "la tarea original.")
        sistema = ((sistema_original or "Eres un auditor experto.").strip()
                   + "\n\n" + INSTRUCCION_ARBITRO)
        try:
            return _llamada_independiente(self._cliente_arbitro(), dict(
                prompt=prompt_arbitro, sistema=sistema,
                max_tokens=max_tokens, formato_json=formato_json))
        except Exception as exc:
            raise RuntimeError(
                f"❌ VIRF PLUS: el árbitro ({self.arbitro}) falló al conciliar — "
                f"{type(exc).__name__}: {exc}") from exc

    def _registrar(self, prompt, a, b, final, comp, arbitrado,
                   resolucion: str = "", error_arbitro: str = "") -> None:
        registro = {
            "ts": datetime.now().isoformat(timespec="seconds"),
            "prompt_sha": hashlib.sha256(prompt.encode("utf-8", "ignore")).hexdigest()[:16],
            "modelos": {"gpt": _nombre_modelo(self.gpt),
                        "claude": _nombre_modelo(self.claude),
                        "arbitro": self.arbitro},
            "acuerdo": comp["acuerdo"],
            "discrepancias": comp["discrepancias"],
            "coinciden": comp["coinciden"],
            "arbitrado": arbitrado,
            # acuerdo | arbitro | conservadora_por_fallo_del_arbitro
            "resolucion": resolucion or ("arbitro" if arbitrado else "acuerdo"),
            "error_arbitro": error_arbitro[:300],
            "respuesta_gpt": a[:4000],
            "respuesta_claude": b[:4000],
            "conclusion": final[:4000],
        }
        self.ultimo_consenso = registro
        self.historial.append(registro)
        del self.historial[:-_MAX_HISTORIAL]
        try:
            self.ruta_log.parent.mkdir(parents=True, exist_ok=True)
            with _LOCK_LOG, self.ruta_log.open("a", encoding="utf-8") as f:
                f.write(json.dumps(registro, ensure_ascii=False, default=str) + "\n")
        except OSError as exc:
            # La bitácora es trazabilidad, no un requisito para evaluar.
            print(f"  ⚠️  VIRF PLUS: no se pudo escribir {self.ruta_log}: {exc}")

    def resumen(self) -> dict:
        """Totales de la sesión: cuántas llamadas, cuántas con discrepancia."""
        n = len(self.historial)
        con_disc = sum(1 for r in self.historial if not r["acuerdo"])
        return {"llamadas": n, "con_discrepancia": con_disc,
                "sin_arbitro_por_fallo": sum(
                    1 for r in self.historial
                    if r.get("resolucion") == "conservadora_por_fallo_del_arbitro"),
                "acuerdo_pct": round(100 * (n - con_disc) / n, 1) if n else None,
                "modelos": self.descripcion}

    def validar_conexion(self) -> bool:
        fallos = []
        for nombre, cli in (("Claude", self.claude), ("GPT", self.gpt)):
            if not cli.validar_conexion():
                fallos.append(f"{nombre}: {getattr(cli, 'ultimo_error_conexion', '')}")
        self.ultimo_error_conexion = " | ".join(fallos)
        return not fallos
