"""
config/secretos.py  [SEG-03]
═════════════════════════════════════════════════════════════════════════════
Único punto de lectura de CREDENCIALES (claves de IA). Norma 2135.010.02
§Aseguramiento: credenciales cifradas, nunca en texto plano en disco.

FUENTE EXPLÍCITA (sin detección automática)
───────────────────────────────────────────
`VIRF_FUENTE_SECRETOS` decide de dónde se lee. No se adivina por heurística:

  keyvault    (por defecto) Azure Key Vault con `DefaultAzureCredential`
              — Managed Identity en Azure; en local, `az login`.
              Requiere VIRF_KEYVAULT_URL=https://<vault>.vault.azure.net/
              y los paquetes azure-identity + azure-keyvault-secrets.
  databricks  `dbutils.secrets.get(scope, clave)` con VIRF_SECRET_SCOPE.
  entorno     Variable de entorno del PROCESO (CI, tests, shell). Prohibida con
              MODO=produccion, y RECHAZA la clave si está escrita en el `.env`
              del proyecto: una clave en ese fichero es texto plano en disco.

EXCEPCIÓN DE DESARROLLO  [2026-11-11 · decisión del responsable del proyecto]
─────────────────────────────────────────────────────────────────────────────
Solo con MODO=debug | desarrollo, declarado explícitamente:

  · si VIRF_FUENTE_SECRETOS no se declara, la fuente es `entorno` (no keyvault);
  · una clave escrita en el `.env` SE ACEPTA, con un aviso en cada arranque.

Así en el portátil basta con editar la clave del `.env`. Nada de esto alcanza a
producción: allí la fuente por defecto sigue siendo keyvault, `entorno` sigue
prohibida y por tanto el `.env` nunca es origen de una clave. Cualquier otro
MODO (CI, valores desconocidos) conserva el rechazo del `.env`.

El nombre lógico (p. ej. AZURE_OPENAI_API_KEY) se traduce al nombre del
secreto en Key Vault / scope con `NOMBRES_SECRETO` (Key Vault no admite «_»).

Nunca se imprime ni se registra el valor de un secreto.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Dict, Optional

from .rutas import BASE_DIR

__all__ = ["obtener_secreto", "secreto_configurado", "fuente_secretos",
           "SecretoNoDisponible", "SecretoEnTextoPlano", "NOMBRES_SECRETO",
           "FUENTES"]

FUENTES = ("keyvault", "databricks", "entorno")

NOMBRES_SECRETO: Dict[str, str] = {
    "AZURE_OPENAI_API_KEY": "azure-openai-api-key",
    # [SEG-02] Firma de la aserción de identidad web→pipeline y secreto de la
    # app registrada en Entra ID.
    "VIRF_CLAVE_FIRMA_SESION": "virf-clave-firma-sesion",
    "VIRF_ENTRA_CLIENT_SECRET": "virf-entra-client-secret",
    # [SEG-06] Cifrado en reposo de caché y outputs locales.
    "VIRF_CLAVE_CIFRADO_REPOSO": "virf-clave-cifrado-reposo",
    # Proveedores en standby/retirados (SEG-01): se mantienen los nombres para
    # cuando el banco cambie el estado; el gateway los bloquea antes de leerlos.
    "ANTHROPIC_API_KEY": "anthropic-api-key",
    "OPENAI_API_KEY": "openai-api-key",
}

# Fichero cuyo contenido NUNCA puede ser el origen de una clave.
RUTA_ENV: Path = BASE_DIR / ".env"

_CACHE: Dict[str, str] = {}


class SecretoNoDisponible(ValueError):
    """La credencial no está en la fuente configurada (o la fuente falla)."""


class SecretoEnTextoPlano(SecretoNoDisponible):
    """La credencial está escrita en el `.env`: se rechaza."""


_MODOS_DESARROLLO = ("debug", "desarrollo")
_AVISADAS_EN_ENV: set = set()


def _modo_desarrollo() -> bool:
    """¿MODO explícitamente de desarrollo? Cualquier otro valor cuenta como no."""
    from . import parametros as _par
    return str(getattr(_par, "MODO", "produccion")).strip().lower() in _MODOS_DESARROLLO


def fuente_secretos() -> str:
    defecto = "entorno" if _modo_desarrollo() else "keyvault"
    fuente = (os.getenv("VIRF_FUENTE_SECRETOS") or defecto).strip().lower()
    if fuente not in FUENTES:
        raise SecretoNoDisponible(
            f"❌ VIRF_FUENTE_SECRETOS={fuente!r} no es válido. Opciones: {', '.join(FUENTES)}.")
    return fuente


def _en_archivo_env(nombre: str) -> bool:
    """¿Está `nombre` asignado con un valor no vacío en el `.env`? Solo se mira
    si hay valor; el valor no se devuelve ni se guarda."""
    try:
        texto = Path(RUTA_ENV).read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    patron = re.compile(r"^\s*(?:export\s+)?" + re.escape(nombre) + r"\s*=\s*(\S.*)$", re.M)
    for m in patron.finditer(texto):
        valor = m.group(1).split(" #")[0].strip().strip("'\"")
        if valor:
            return True
    return False


def _desde_entorno(nombre: str) -> str:
    from .parametros import MODO
    if str(MODO).lower() == "produccion":
        raise SecretoNoDisponible(
            "❌ VIRF_FUENTE_SECRETOS=entorno no está permitido con MODO=produccion. "
            "Usa keyvault (o databricks en el clúster).")
    if _en_archivo_env(nombre) and _modo_desarrollo():
        # Excepción de desarrollo (ver cabecera): se usa, y se dice cada vez.
        if nombre not in _AVISADAS_EN_ENV:
            _AVISADAS_EN_ENV.add(nombre)
            print(f"  ⚠️  {nombre} leída del {Path(RUTA_ENV).name} (texto plano en disco). "
                  "Solo vale en MODO=debug: usa una clave de pruebas, nunca la de "
                  "producción, y no subas ese fichero al repositorio.")
        return os.environ.get(nombre, "").strip()
    if _en_archivo_env(nombre):
        raise SecretoEnTextoPlano(
            f"❌ {nombre} está escrita en texto plano en {Path(RUTA_ENV).name}. "
            "Bórrala de ese fichero, pide su ROTACIÓN (ha estado en disco) y cárgala "
            "en Azure Key Vault.")
    return os.environ.get(nombre, "").strip()


def _desde_keyvault(nombre: str) -> str:
    url = (os.getenv("VIRF_KEYVAULT_URL") or "").strip()
    if not url:
        raise SecretoNoDisponible(
            "❌ VIRF_FUENTE_SECRETOS=keyvault requiere VIRF_KEYVAULT_URL "
            "(https://<vault>.vault.azure.net/).")
    try:
        from azure.identity import DefaultAzureCredential
        from azure.keyvault.secrets import SecretClient
    except ImportError as exc:
        raise SecretoNoDisponible(
            "❌ Faltan azure-identity y azure-keyvault-secrets para leer de Key Vault "
            "(pip install azure-identity azure-keyvault-secrets).") from exc
    try:
        cliente = SecretClient(vault_url=url, credential=DefaultAzureCredential())
        return (cliente.get_secret(NOMBRES_SECRETO.get(nombre, nombre)).value or "").strip()
    except Exception as exc:                                  # noqa: BLE001
        # El mensaje del SDK no incluye el valor del secreto; sí el nombre.
        raise SecretoNoDisponible(
            f"❌ No se pudo leer {nombre} de Key Vault: {type(exc).__name__}") from exc


def _dbutils():
    try:
        import IPython                                       # type: ignore
        ns = IPython.get_ipython().user_ns                   # type: ignore[union-attr]
        if "dbutils" in ns:
            return ns["dbutils"]
    except Exception:                                        # noqa: BLE001
        pass
    try:
        from pyspark.dbutils import DBUtils                  # type: ignore
        from pyspark.sql import SparkSession                 # type: ignore
        return DBUtils(SparkSession.builder.getOrCreate())
    except Exception as exc:                                 # noqa: BLE001
        raise SecretoNoDisponible(
            "❌ VIRF_FUENTE_SECRETOS=databricks pero no hay dbutils en este proceso.") from exc


def _desde_databricks(nombre: str) -> str:
    scope = (os.getenv("VIRF_SECRET_SCOPE") or "").strip()
    if not scope:
        raise SecretoNoDisponible("❌ VIRF_FUENTE_SECRETOS=databricks requiere VIRF_SECRET_SCOPE.")
    try:
        return (_dbutils().secrets.get(scope=scope, key=NOMBRES_SECRETO.get(nombre, nombre))
                or "").strip()
    except SecretoNoDisponible:
        raise
    except Exception as exc:                                  # noqa: BLE001
        raise SecretoNoDisponible(
            f"❌ No se pudo leer {nombre} del secret scope {scope!r}: {type(exc).__name__}") from exc


_LECTORES = {"keyvault": _desde_keyvault, "databricks": _desde_databricks,
             "entorno": _desde_entorno}


def obtener_secreto(nombre: str, obligatorio: bool = True) -> str:
    """Devuelve la credencial `nombre` desde la fuente configurada.

    Con `obligatorio=True` (por defecto) un secreto vacío lanza
    SecretoNoDisponible. Las fuentes remotas se cachean por proceso; `entorno`
    no (los tests cambian el entorno entre casos)."""
    fuente = fuente_secretos()
    clave_cache = f"{fuente}:{nombre}"
    if fuente != "entorno" and clave_cache in _CACHE:
        return _CACHE[clave_cache]
    valor = _LECTORES[fuente](nombre)
    if not valor and obligatorio:
        raise SecretoNoDisponible(f"❌ {nombre} no está configurada en la fuente «{fuente}».")
    if valor and fuente != "entorno":
        _CACHE[clave_cache] = valor
    return valor


def secreto_configurado(nombre: str) -> bool:
    """¿Hay valor para `nombre`? Nunca lanza ni devuelve el valor (para la web)."""
    try:
        return bool(obtener_secreto(nombre, obligatorio=False))
    except Exception:                                         # noqa: BLE001
        return False


def limpiar_cache() -> None:
    _CACHE.clear()
