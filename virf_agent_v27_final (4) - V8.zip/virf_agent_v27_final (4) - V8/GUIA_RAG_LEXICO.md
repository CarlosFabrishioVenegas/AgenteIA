# Guía del RAG léxico de VIRF — cómo funciona, de verdad

> **Qué es este documento.** La explicación completa y paso a paso del sistema de
> recuperación de literatura regulatoria del agente VIRF: qué hace, cómo lo hace,
> por qué se construyó así, dónde falla y cómo diagnosticarlo.
>
> **No hace falta saber de motores de búsqueda para leerlo.** Cada concepto se
> explica cuando aparece.
>
> **Los números son reales.** Todos los ejemplos salen del índice del dominio
> `VaR` tal como está construido en este repositorio. Puedes regenerarlos:
>
> ```bash
> python scripts/explicar_rag.py --dominio VaR --consulta "tu consulta aquí"
> ```
>
> Ese script es el acompañamiento ejecutable de esta guía: si el código cambia,
> los números se recalculan solos en vez de quedarse desfasados aquí.
>
> Fecha: **2026-07-31** · Referencia rápida en README §7.3

---

## Índice

- [1. Resumen en 60 segundos](#1-resumen-en-60-segundos)
- [2. El problema: por qué NO hay embeddings](#2-el-problema-por-qué-no-hay-embeddings)
- [3. Dos formas de buscar: semántica vs. léxica](#3-dos-formas-de-buscar-semántica-vs-léxica)
- [4. El pipeline completo, paso a paso](#4-el-pipeline-completo-paso-a-paso)
  - [4.1 Tokenización](#41-tokenización--convertir-texto-en-piezas-comparables)
  - [4.2 Troceado](#42-troceado--partir-los-documentos-en-chunks)
  - [4.3 BM25](#43-bm25--la-señal-principal)
  - [4.4 TF-IDF](#44-tf-idf--la-segunda-opinión)
  - [4.5 Persistencia](#45-persistencia--no-releer-los-pdf-cada-vez)
  - [4.6 Consulta y combinación](#46-consulta-y-combinación)
- [5. Ejemplo completo con números reales](#5-ejemplo-completo-con-números-reales)
- [6. Dónde falla: el caso «excepciones»](#6-dónde-falla-el-caso-excepciones)
- [6-bis. La cura: expansión de la consulta](#6-bis-la-cura-expansión-de-la-consulta)
- [7. Los dos números: relevancia absoluta y posición relativa](#7-los-dos-números-relevancia-absoluta-y-posición-relativa)
- [8. Las tres redes de seguridad](#8-las-tres-redes-de-seguridad)
- [9. Cómo se conecta con el agente](#9-cómo-se-conecta-con-el-agente)
- [10. Operación diaria](#10-operación-diaria)
- [11. Parámetros y cuándo tocarlos](#11-parámetros-y-cuándo-tocarlos)
- [12. Diagnóstico: no recupera lo que espero](#12-diagnóstico-no-recupera-lo-que-espero)
- [13. Mapa de ficheros](#13-mapa-de-ficheros)
- [14. Decisiones de diseño y por qué](#14-decisiones-de-diseño-y-por-qué)

---

## 1. Resumen en 60 segundos

El agente VIRF valida modelos financieros. Cuando evalúa una actividad —por
ejemplo, *«¿el modelo documenta el backtesting?»*— le viene bien tener delante lo
que dice la **literatura regulatoria de referencia** sobre backtesting: Kupiec,
Christoffersen, el marco de Basilea.

Esa literatura vive en `inputs/rag/<dominio>/`. El RAG es el sistema que, dada
una pregunta, encuentra los fragmentos más relevantes y los pega en el prompt
antes de llamar al modelo de lenguaje.

**En una frase:** el RAG de VIRF encuentra fragmentos por **coincidencia de
palabras** (BM25 + TF-IDF), no por parecido semántico, y lo hace **100 % en local**
sin llamar a ninguna API.

```
inputs/rag/VaR/*.pdf
        │
        │  [indexado, se hace una vez]
        ▼
   extraer texto → trocear → tokenizar → data/rag_lexico/VaR.pkl
        
        
   "prueba de Kupiec"
        │
        │  [consulta, milisegundos]
        ▼
   tokenizar → BM25 (70%) + TF-IDF (30%) → top-K fragmentos
        │
        ▼
   se pegan al prompt → llamada de CHAT a Azure → respuesta
```

La única llamada de red en todo el recorrido es la última, y es una llamada de
chat normal.

---

## 2. El problema: por qué NO hay embeddings

La mayoría de los RAG del mundo funcionan con **embeddings**: se convierte cada
fragmento en un vector de números que captura su «significado», y se busca por
proximidad geométrica. VIRF **no puede hacer eso**, por dos restricciones del
entorno. Cada una, por sí sola, ya lo impediría.

### Restricción 1 — Solo hay un deployment de Azure, y es de chat

Generar embeddings con Azure OpenAI requiere un *deployment* específico de un
modelo de embeddings (`text-embedding-3-small`, `ada-002`…). El recurso Azure de
la entidad tiene **uno solo, de chat**, y no va a haber otro.

> **Punto importante que suele confundirse:** el deployment de chat **no puede
> generar embeddings**. No es que sea peor o más caro — es que la operación no
> existe para ese modelo. Si le pides a `/chat/completions` que te devuelva «el
> vector» de un texto, te devolverá una lista de números *inventada*, con
> aspecto de vector y sin ninguna de sus propiedades. Sería peor que no tener
> nada, porque el sistema parecería funcionar.

**Qué pasaba antes de arreglarlo.** El RAG anterior pedía ese deployment. Al no
existir, la función de embeddings lanzaba una excepción, el retriever la
capturaba, devolvía lista vacía, y la validación continuaba **sin contexto**. El
RAG llevaba tiempo instalado, documentado y **apagado**, y lo único que lo decía
era una línea de *warning* entre decenas.

### Restricción 2 — Cero HuggingFace, incluidas dependencias transitivas

La política de la entidad prohíbe ejecutar modelos ajenos a Azure OpenAI. El
proyecto lo cumplía en apariencia: ninguna línea importaba `transformers` ni
`sentence-transformers`.

Pero `requirements.txt` declaraba **ChromaDB**, la base de datos vectorial. Y:

```
chromadb  →  tokenizers  →  huggingface-hub
```

Instalar las dependencias del proyecto metía `huggingface-hub` en el entorno. La
política se cumplía **en el código** y se incumplía **en el árbol de
dependencias** — un incumplimiento que no se detecta leyendo el código, porque
ChromaDB no menciona HuggingFace por ninguna parte: simplemente depende de algo
que depende de ello.

No hay forma de tener ChromaDB sin tener `huggingface-hub`. La única solución era
no tener ChromaDB.

> Hoy `validate_project.py` comprueba las dos mitades por separado (sección
> *5-bis*), precisamente porque fallan por separado.

---

## 3. Dos formas de buscar: semántica vs. léxica

Para entender qué se gana y qué se pierde, conviene tener claro en qué se
diferencian.

### Búsqueda semántica (embeddings) — la que NO usamos

Convierte cada texto en un punto en un espacio de cientos o miles de dimensiones,
colocado de forma que **textos de significado parecido queden cerca**.

- ✅ Encuentra *«valor en riesgo»* cuando buscas *«VaR»*, aunque no compartan ni
  una letra.
- ❌ Necesita un modelo que haga la conversión: o una API (no la tenemos) o un
  modelo descargado (prohibido).
- ❌ **Diluye la terminología exacta.** Un modelo de embeddings genérico coloca
  «Kupiec» cerca de «prueba estadística» y «HQLA» cerca de «liquidez», porque eso
  es lo que ha aprendido del lenguaje general. El término específico deja de
  distinguir.

### Búsqueda léxica (BM25 + TF-IDF) — la que usamos

Cuenta **coincidencias de palabras**, ponderando cada palabra por lo rara que es
en la colección.

- ✅ *«Kupiec»* aparece en el paper de backtesting y en ninguno más. La
  coincidencia exacta es exactamente lo que queremos.
- ✅ Sin API, sin modelo, sin red. Milisegundos.
- ⚠️ No entiende sinónimos por sí sola: si el documento dice «excedencias» y tú
  preguntas por «excepciones», no hay coincidencia. **Pasa de verdad**
  ([§6](#6-dónde-falla-el-caso-excepciones)) — y se resuelve con un tesauro de
  dominio ([§6-bis](#6-bis-la-cura-expansión-de-la-consulta)).

### Por qué léxico es la elección correcta *aquí*

No es un premio de consolación. En literatura regulatoria **la terminología ES la
señal**:

| Término | Qué hace un embedding genérico | Qué hace BM25 |
|---|---|---|
| `Kupiec` | lo acerca a *«prueba estadística»*, *«test»* | coincidencia exacta, IDF alto |
| `HQLA` | lo acerca a *«liquidez»*, *«activos»* | coincidencia exacta |
| `IFRS 9` | lo acerca a *«norma contable»* | coincidencia exacta |
| `NSFR` | probablemente no lo conoce | coincidencia exacta |

Cuando el vocabulario es técnico, cerrado y preciso, la coincidencia literal
**gana**. Y tres mecanismos cubren parcialmente el hueco del sinónimo:

1. **Stemming** — `series temporales` y `serie temporal` producen los mismos
   tokens.
2. **Bigramas en TF-IDF** — *«value at risk»* solo existe como pareja.
3. **Consulta enriquecida** — el agente pregunta con `[ámbito] actividad`, no con
   la pregunta pelada: más términos, más superficie de coincidencia.

---

## 4. El pipeline completo, paso a paso

### 4.1 Tokenización — convertir texto en piezas comparables

Un ordenador no compara frases: compara **tokens**. Tokenizar es partir el texto
en unidades normalizadas.

> 🔑 **La regla de oro de todo el sistema:** los documentos y las consultas se
> tokenizan con **exactamente la misma función**. Si difirieran en un solo paso
> —una tilde, un stem— la consulta generaría términos que no existen en el
> índice, BM25 devolvería ceros y el resultado sería una lista vacía…
> **indistinguible de «no hay nada relevante»**. Un fallo silencioso.
>
> Por eso `tokenizar()` es una sola función en `indexador_lexico.py`, usada por
> los dos lados.

Los pasos, en orden:

#### a) Minúsculas y sin acentos

`"Ponderación"` → `"ponderacion"`

**Por qué.** La ortografía de este corpus es inconsistente *por origen*: los PDF
del BCBS traducidos y los manuales internos escriben lo mismo con y sin tilde, y
un extractor de PDF además se come tildes según la tipografía. Sin esta
normalización, media consulta en español recuperaría la mitad de lo que debe.

**Excepción: la ñ se preserva.** `año` y `ano` no son la misma palabra.

#### b) Partir en palabras

Se usa una expresión regular que conserva los guiones internos, porque
`Cornish-Fisher` o `back-testing` son **un** término, no dos.

#### c) Descartar stopwords

Las palabras funcionales (`de`, `la`, `the`, `of`…) aparecen en todos los textos
y no distinguen nada. Se descartan con listas de español e inglés.

> **Por qué NO usamos `nltk`** (que trae estas listas). `nltk.download()`
> descarga desde `raw.githubusercontent.com`. En una red con inspección TLS eso
> produce **el mismo error** `CERTIFICATE_VERIFY_FAILED` que motivó echar a
> `sentence-transformers`. Cambiar una descarga de huggingface.co por una de
> github.com reubica el problema, no lo resuelve. Las listas son cien palabras
> por idioma: van escritas en el fichero, y así el indexado es local *de verdad*
> — no «local salvo la primera vez».

#### d) Proteger las siglas del dominio

`VaR`, `HQLA`, `LCR`, `NSFR`, `PD`, `LGD`, `FRTB`, `IRRBB`… nunca se filtran ni
se recortan, aunque sean cortas. Son la razón de usar búsqueda léxica.

> **Una decisión consciente y discutible:** `EL` (*Expected Loss*) y `ES`
> (*Expected Shortfall*) **no** están protegidas. Colisionan con las dos palabras
> más frecuentes del español. Protegerlas significaría que «el» sobrevive a la
> tokenización de *toda* consulta en castellano y, como aparece en casi todos los
> fragmentos, **cualquiera** pasaría el filtro de relevancia: la consulta «receta
> de tortilla» dejaría de devolver vacío y empezaría a devolver regulación al
> azar. Se pierde poder buscar «EL» como sigla suelta; se gana que el filtro de
> irrelevancia siga funcionando.

#### e) Stemming conservador

Recortar la palabra a su raíz para que singular y plural coincidan.

**Primero el plural, con la regla real del español** (que también cubre el inglés
regular):

| Termina en | Regla | Ejemplo |
|---|---|---|
| consonante + `es` | quitar `es` | `valores` → `valor`, `temporales` → `temporal` |
| vocal + `s` | quitar `s` | `series` → `serie`, `pruebas` → `prueba` |

> Esto no es pedantería gramatical. La primera versión quitaba `es` a secas:
> `series` acababa en `seri` y `serie` seguía siendo `serie` — **dos tokens
> distintos para la misma palabra**, de modo que una consulta sobre «serie
> temporal» no recuperaba el fragmento que dice «series temporales». Y ese fallo
> no da error: solo devuelve menos resultados de los que hay.

**Después, como mucho UN recorte derivativo** (`-ación`, `-miento`, `-ing`,
`-ment`…), con tres contenciones:

- No toca términos protegidos ni palabras de menos de 5 letras.
- El recorte derivativo solo se intenta a partir de 6 letras.
- **Nunca devuelve raíces de menos de 4 caracteres.** Recortar `backtesting`
  hasta `backtest` está bien; hasta `back` destruye el término y lo hace
  colisionar con cualquier cosa.

**Ejemplo real completo:**

```
"backtesting: numero de excepciones y prueba de Kupiec"

  palabra          ¿qué le pasa?                 token
  ---------------- ----------------------------- ----------
  backtesting      stem                          backtest
  numero           sin cambios                   numero
  de               stopword → DESCARTADA         —
  excepciones      stem                          excepcion
  y                stopword → DESCARTADA         —
  prueba           sin cambios                   prueba
  de               stopword → DESCARTADA         —
  kupiec           sin cambios                   kupiec

  → ['backtest', 'numero', 'excepcion', 'prueba', 'kupiec']
```

---

### 4.2 Troceado — partir los documentos en *chunks*

No se indexa un PDF entero: se parte en fragmentos de **1200 caracteres con 200
de solape**.

**Por qué trocear.** El chunk es la **unidad de respuesta**: lo que se pega al
prompt. Un documento entero no cabe y además diluiría la señal. 1200 caracteres
es un párrafo largo: suficiente para entenderse solo, y seis de ellos no se comen
el presupuesto de contexto.

**Por qué el solape.** Sin él, una frase que cae justo en la frontera se parte en
dos y no se entiende en ninguno de los dos lados. 200 caracteres de solape
garantizan que toda idea aparece entera en al menos un fragmento.

**Se reutiliza el chunker que ya existía** (`modulos/chunker.py`), instanciado con
`cliente_ia=None`. Es deliberado: `_dividir_en_chunks` es un troceador de texto
puro que no toca la IA.

> ⚠️ **El índice guarda el TEXTO CRUDO del chunk, no su resumen con IA.** Podría
> parecer mejor resumir cada fragmento, pero sería:
> - **caro** — una llamada a la API por chunk y por documento;
> - **contraproducente** — un resumen pierde justo los tecnicismos literales
>   sobre los que BM25 busca. Resumir «la prueba de Kupiec contrasta la cobertura
>   incondicional» como «se describe un test estadístico» destruye la señal.

---

### 4.3 BM25 — la señal principal

BM25 es el algoritmo de ranking de **Elasticsearch y Lucene**: el estándar
industrial de la búsqueda por texto desde hace treinta años.

Puntúa cada fragmento sumando, por cada término de la consulta:

```
        ⎧             f(término, chunk) × (k1 + 1)                      ⎫
Σ  IDF × ⎨ ─────────────────────────────────────────────────────────── ⎬
término  ⎩  f(término, chunk) + k1 × (1 − b + b × longitud/longitud_media) ⎭
```

Suena peor de lo que es. Son **tres ideas**:

#### Idea 1 — IDF: las palabras raras valen más

*Inverse Document Frequency*. Si un término aparece en **pocos** fragmentos,
encontrarlo dice mucho. Si aparece en **todos**, no distingue nada.

Números reales del dominio `VaR` (12 fragmentos):

| token | aparece en | IDF | lectura |
|---|---|---|---|
| `kupiec` | 4/12 | **0.6360** | raro → muy informativo |
| `backtest` | 7/12 | 0.4090 | común |
| `prueba` | 7/12 | 0.4090 | común |
| `numero` | 5/12 | 0.3102 | común |
| `excepcion` | **0/12** | **0.0000** | **no existe → aporta 0** |

Encontrar `kupiec` pesa **el doble** que encontrar `numero`. Eso es exactamente
lo que queremos: el término técnico manda.

#### Idea 2 — Saturación: repetir tiene rendimientos decrecientes

Un fragmento que dice «Kupiec» 10 veces no es 10 veces más relevante que uno que
lo dice una vez. El parámetro **`k1` (=1.5)** controla la curva de saturación.

#### Idea 3 — Normalización por longitud: los fragmentos largos no ganan por acumulación

Un fragmento largo contiene más palabras y, sin corregir, ganaría siempre. El
parámetro **`b` (=0.75)** penaliza los fragmentos más largos que la media (aquí,
88 tokens).

> `k1=1.5` y `b=0.75` son los valores canónicos de Robertson, los mismos que trae
> Elasticsearch de fábrica.

---

### 4.4 TF-IDF — la segunda opinión

Se construye **en paralelo** una segunda representación con `scikit-learn`, y se
mide la **similitud coseno** entre la consulta y cada fragmento.

**Qué corrige.** BM25 tiene un punto flaco: un fragmento que acierta *un* término
rarísimo puede escalar al primer puesto aunque no comparta **nada más** con la
consulta. TF-IDF mira el **vector completo** —el solape de todo el vocabulario— y
le baja el voto.

**Los bigramas importan.** TF-IDF indexa palabras sueltas *y* parejas
consecutivas:

- *«value at risk»* solo significa algo como pareja.
- *«riesgo de mercado»* íd.
- Con unigramas puros, `risk` es tan común en este corpus que no discrimina nada.

> 🔑 **Detalle crítico:** a `TfidfVectorizer` se le pasa el texto **ya tokenizado
> por nosotros**, y se le dice que solo parta por espacios. Si sklearn tokenizara
> a su manera, las dos señales estarían midiendo **vocabularios distintos**, y el
> peso 0.7/0.3 estaría mezclando dos medidas de cosas diferentes.

**TF-IDF es opcional de verdad.** Si `scikit-learn` no estuviera instalado, el
buscador sigue funcionando solo con BM25. La calidad baja un punto; la
disponibilidad no. BM25 sí es obligatorio.

---

### 4.5 Persistencia — no releer los PDF cada vez

El índice se guarda en `data/rag_lexico/<dominio>.pkl`.

#### Qué se guarda y qué NO

| Se guarda | NO se guarda |
|---|---|
| Texto de cada fragmento | El objeto `BM25Okapi` |
| Metadatos (fuente, posición) | El `TfidfVectorizer` entrenado |
| Los tokens ya calculados | La matriz TF-IDF |

**Dos razones, ambas importantes:**

1. **Lo caro es extraer los PDF**, no construir las estructuras. `pdfminer` sobre
   un BCBS domina el tiempo por completo; levantar BM25 y TF-IDF sobre tokens ya
   calculados son milisegundos. Se cachea lo caro.

2. **Un pickle de scikit-learn no es estable entre versiones.** Al recargarlo
   tras un `pip install -U scikit-learn` se obtiene desde un warning hasta un
   objeto silenciosamente roto. Guardando solo **listas de texto**, una
   actualización de sklearn no puede corromper nada.

#### La huella de las fuentes

El índice guarda un hash de `(nombre, tamaño, fecha)` de cada documento. Al
cargarlo, se recalcula y se compara.

**Por qué importa.** Un índice caduco es **peor que ninguno**: sirve fragmentos de
documentos que ya se sustituyeron, y tiene exactamente el mismo aspecto que uno
al día. Con la huella, `--status` lo marca como desfasado y se reconstruye.

#### Escritura atómica

Se escribe a un fichero temporal y se renombra (`os.replace`, atómico también en
Windows). Sin esto, un `Ctrl-C` a mitad de escritura dejaría un `.pkl` truncado
en la ruta oficial; se trataría como «no hay índice» y la corrida siguiente
pagaría la extracción de todos los PDF sin que nadie entendiera por qué.

#### Un índice vacío NO se escribe

Si un dominio no tiene literatura, se devuelve un índice vacío **sin
persistirlo**. Un fichero vacío en esa carpeta significaría «este dominio está
indexado» para cualquiera que la mire —incluido `--status`— cuando no hay nada
que buscar.

---

### 4.6 Consulta y combinación

```
consulta
   │
   ├─→ tokenizar (LA MISMA función que en el indexado)
   │
   ├─→ ¿quedan tokens?          NO → devolver []
   │
   ├─→ PESO INFORMATIVO = Σ IDF(términos de la consulta)
   │     └─ si < 0.8 → warning + el bloque del prompt declarará su incertidumbre
   │
   ├─→ COBERTURA ABSOLUTA por fragmento = Σ IDF(comunes) / Σ IDF(consulta)
   │     └─ descartar los que no lleguen a RAG_MIN_COBERTURA
   │        ¿ninguno? → devolver []
   │
   ├─→ BM25 sobre los candidatos     → normalizar / máximo de esta consulta
   ├─→ coseno TF-IDF                 → normalizar / máximo de esta consulta
   │
   ├─→ score = (0.7 × BM25n + 0.3 × TFIDFn) / 1.0     ← SOLO PARA ORDENAR
   │
   ├─→ ordenar por (score, BM25 bruto)   ← el desempate importa, ver §8
   │
   └─→ top-K   ·   se REPORTA la cobertura, no el score
```

> **El orden importa.** La cobertura se calcula y filtra **antes** de puntuar: es
> el corte absoluto. El `score` solo interviene después, para decidir quién va
> delante de quién. Ver [§7](#7-los-dos-números-relevancia-absoluta-y-posición-relativa).

**El desempate por BM25 bruto no es cosmético.** Sin un criterio explícito, dos
fragmentos con el mismo score los ordenaría su posición en el índice, que es
arbitraria y **cambia al reindexar**: el mismo informe daría distinto contexto en
dos corridas.

---

## 5. Ejemplo completo con números reales

Consulta: **`"backtesting: numero de excepciones y prueba de Kupiec"`**
Dominio: `VaR` (12 fragmentos, 3 documentos, longitud media 88.4 tokens)

### Paso 1 — Tokens

```
['backtest', 'numero', 'excepcion', 'prueba', 'kupiec']
```

### Paso 2 — IDF de cada término

| token | df | IDF |
|---|---|---|
| `kupiec` | 4/12 | 0.6360 |
| `backtest` | 7/12 | 0.4090 |
| `prueba` | 7/12 | 0.4090 |
| `numero` | 5/12 | 0.3102 |
| `excepcion` | 0/12 | 0.0000 ⚠️ |

### Paso 3 — BM25 bruto

| # | fuente | tokens | BM25 |
|---|---|---|---|
| 2 | `backtesting_VaR_Kupiec_Christoffersen.pdf` | 99 | **2.1177** |
| 1 | `backtesting_VaR_Kupiec_Christoffersen.pdf` | 91 | 1.8829 |
| 0 | `backtesting_VaR_Kupiec_Christoffersen.pdf` | 103 | 1.5174 |
| 9 | `FRTB_BCBS457_riesgo_mercado.pdf` | 92 | 1.4581 |

### Paso 4 — Cobertura absoluta y corte

**Peso informativo de la consulta: Σ IDF = 1.76** → por encima de 0.8, la
consulta **sí discrimina**. No se emite aviso.

La cobertura de cada fragmento se calcula sobre ese 1.76. Nótese que `excepcion`
(IDF 0) **no entra en el denominador**: no se penaliza a nadie por no contener una
palabra que no está en el corpus.

Todos los fragmentos por debajo de `RAG_MIN_COBERTURA = 0.15` se descartan aquí,
antes de puntuar nada.

### Paso 5 — Ordenar y quedarse con el top-K

| # | fuente | **cobertura** *(absoluta)* | BM25n | TFIDFn | score *(rel.)* |
|---|---|---|---|---|---|
| 1 | `backtesting…Christoffersen.pdf` ch2 | **0.7682** | 1.0000 | 1.0000 | 1.0000 |
| 2 | `backtesting…Christoffersen.pdf` ch1 | **0.7682** | 0.8891 | 0.5710 | 0.7937 |
| 3 | `backtesting…Christoffersen.pdf` ch0 | **0.5924** | 0.7166 | 0.4274 | 0.6298 |

Comprobación del `score` del #2 a mano:

```
0.7 × 0.8891  +  0.3 × 0.5710  =  0.6224 + 0.1713  =  0.7937  ✓
```

**Dos lecturas, y conviene hacer las dos:**

- **El trabajo de TF-IDF.** Al #2, BM25 le da 0.889 (mucha coincidencia literal)
  pero el coseno solo 0.571. La segunda señal dice *«coincide en los términos
  importantes, pero su vocabulario general se parece menos»*, y le baja el
  resultado a 0.794. Eso es exactamente para lo que está.

- **Por qué `score` no sirve para medir.** Los fragmentos #1 y #2 tienen la
  **misma cobertura** (0.7682): cubren los mismos términos clave de la consulta.
  Y sin embargo sus `score` son 1.00 y 0.79, porque uno tiene que ir delante del
  otro. El `score` está describiendo el **orden**, no la relevancia. Si se
  reportara ese número, el #2 parecería un 21 % peor que el #1 cuando cubren
  exactamente lo mismo.

**Los tres resultados son del documento correcto.** El sistema funciona.

### Paso 6 — Lo que ve el modelo

```markdown
### [1] Fuente: backtesting_VaR_Kupiec_Christoffersen.pdf
        (cubre el 77% de los términos clave de la consulta)
```

Un **77 %**, absoluto y comparable con cualquier otra búsqueda — no un 1.00 que
solo significaba «el primero de la lista».

---

## 6. Dónde falla: el caso «excepciones»

Vuelve a la tabla de IDF del paso 2. El término `excepcion` tiene **df = 0**: no
aparece en **ningún** fragmento del corpus.

¿Por qué? Porque los documentos usan **otra palabra**:

```
tokenizar("excepciones")  →  ['excepcion']     df = 0
tokenizar("excedencias")  →  ['exced']         df = 8
```

Y el texto real dice:

> *«…basada en la distribución geométrica del número de periodos hasta la primera
> **excedencia**. Prueba de cobertura condicional de Christoffersen…»*

**En backtesting de VaR, «excepción» y «excedencia» son sinónimos exactos.** Un
embedding semántico los habría acercado. BM25 no: son cadenas distintas, y ese
término de la consulta **aportó cero al resultado**.

### Por qué la consulta funcionaba igualmente

Porque los otros cuatro términos (`kupiec`, `backtest`, `prueba`, `numero`)
llevaban el peso. **Ésa es la primera defensa del sistema: la redundancia.** Una
consulta con varios términos de anclaje sobrevive a que uno falle.

Pero esa defensa se agota cuando el término perdido es el importante.

---

## 6-bis. La cura: expansión de la consulta

> **Esto ya no es una limitación abierta.** Desde el 2026-07-31 hay dos
> mecanismos que lo resuelven, ambos locales y sin tocar las restricciones.

### Por qué NO se puede resolver con métodos automáticos

La tentación es derivar los sinónimos del propio corpus: co-ocurrencia, o
LSA/SVD sobre la matriz TF-IDF —que `scikit-learn` ya ofrece, sería 100 % local
y no violaría ninguna restricción—. **No sirve para este caso**, y entender por
qué ahorra tiempo:

> Cualquier método derivado del corpus necesita que el término **aparezca** en el
> corpus para aprender algo de él. `excepcion` tiene **df = 0**: no aparece ni
> una vez. No hay contexto del que inferir nada.

Un método automático puede acercar dos palabras que el corpus usa de forma
parecida. **No puede inventar la relación entre una palabra que está y otra que
no está.** Para eso hace falta conocimiento externo.

### Mecanismo 1 — Tesauro de dominio (`src/rag/tesauro.py`)

Una lista de grupos de términos equivalentes, escrita por un experto:

```python
["excepción", "excedencia", "exceedance"],
["HQLA", "activos líquidos de alta calidad"],
["seguimiento", "monitoreo", "monitorización", "monitoring"],
```

En un entorno regulado tiene una ventaja que ningún modelo da: **es auditable**.
Un validador puede leer el fichero entero, discutir una equivalencia y
corregirla. Nadie puede auditar los pesos de un embedding.

Se amplía sin tocar código creando `config/tesauro_rag.yaml`:

```yaml
grupos:
  - [excepción, excedencia, exceedance]
  - [pérdida esperada, expected loss]
```

**Resultado medido** sobre la consulta del §5:

```
+ [tesauro] 'excepcion' → ['exced']
→ cobertura 0.768  →  1.000
```

### Mecanismo 2 — Corrección de erratas

Para términos que **no existen** en el corpus, se busca la palabra más parecida
del vocabulario real (`difflib`, biblioteca estándar). Resuelve las erratas del
propio estándar:

```
+ [errata] 'seguimeinto' → ['segu']   ← palabra real: «seguimiento»
```

Tres decisiones de diseño que lo hacen seguro:

1. **Solo sobre términos de `df = 0`.** Aportan cero por definición, así que
   corregirlos o deja las cosas igual o las mejora. **Nunca puede empeorar un
   resultado.**
2. **Contra el vocabulario CRUDO, sin stem.** Contra los tokens derivados no
   funciona: «seguimiento» se reduce a «segu», y la distancia hasta
   «seguimeinto» es enorme — medido, `difflib` no encontraba nada.
3. **Umbral estricto (0.85).** `seguimeinto → seguimiento` pasa; `caso → paso`
   no.

### Dos salvaguardas importantes

**Solo se expande a términos que aportan algo.** Si el sinónimo tampoco existe
en el corpus —o su IDF es 0—, no se añade: metería ruido en el peso informativo
y hundiría la cobertura de todo lo demás.

> Caso real observado: `valor en riesgo` → `VaR` **no** se expande en el dominio
> VaR, porque ahí `var` aparece en 6 de 12 fragmentos y su IDF es exactamente 0.
> Añadirlo no aportaría nada. El filtro está haciendo su trabajo.

**El peso se cuenta por CONCEPTO, no por token.** Si el tesauro añade `exced`
como variante de `excepcion`, son la misma idea: contarlas por separado inflaría
esa parte de la consulta y desinflaría la cobertura del resto.

### Es auditable

Cada expansión queda registrada en el resultado y en el diagnóstico:

```bash
python scripts/explicar_rag.py --consulta "numero de excepciones y prueba de Kupiec"
```
```
  🔗 EXPANSIÓN (la cura del punto ciego léxico):
      [tesauro ] 'excepcion' → ['exced']
      Sin esto, esos términos aportarían CERO a la búsqueda.
```

En un informe de validación hay que poder explicar que el sistema buscó
«excedencia» cuando el estándar decía «excepción».

### Qué queda sin resolver

Tras expandir, los términos que **sigan** con `df = 0` señalan un hueco **real**
del corpus, no de vocabulario:

```
⚠️  Siguen sin coincidencia TRAS expandir: ['analizar', 'metodologia']
```

O falta ese documento, o al tesauro le falta esa equivalencia. El script lo
distingue por ti.

### Efecto medido sobre el estándar completo

| dominio | actividades sin apoyo, antes | después |
|---|---|---|
| `VaR` | 1 | **0** |
| `LaR` | 1 | 1 |
| `conductuales` | 4 | **1** |
| `shared` | 0 | 0 |

> La cobertura media baja unos puntos, y es correcto: la consulta ahora pide
> legítimamente **más cosas encontrables**, así que un fragmento que solo cubre
> una parte cubre menos porcentaje. Lo que importa es que hay menos actividades
> ciegas.

**Los dos mecanismos se apagan con `RAG_TESAURO=0` y `RAG_CORREGIR_ERRATAS=0`.**

---

## 7. Los dos números: relevancia absoluta y posición relativa

Esta sección era, hasta el 2026-07-31, una **advertencia**: «cuidado, el `score`
no significa lo que parece». Ya no hace falta advertir, porque el defecto que la
motivaba está corregido. Merece la pena contar el problema y la cura, porque es
el error de diseño más fácil de cometer en un RAG.

### El problema

BM25 no tiene techo. Sus valores brutos dependen del corpus, de la longitud de la
consulta y de cuántos términos raros contenga. Para poder combinarlo con el
coseno hay que acotarlo, y la única forma es normalizar **contra el máximo de esa
consulta**. Consecuencia inevitable:

> **El mejor fragmento saca 1.00. Siempre.** Aunque el corpus sea pésimo. Aunque
> la pregunta no venga a cuento.

Eso está **bien para ordenar** y es **inútil para decidir si algo es relevante**.
El fallo fue usar ese mismo número para las dos cosas: gobernaba el umbral, y se
inyectaba en el prompt con la etiqueta «relevancia léxica: 1.00».

El daño real: el primer resultado de cualquier consulta llegaba al modelo —y al
informe— anunciado como coincidencia perfecta. Ni el modelo ni un lector podían
distinguir *«coincidencia excelente»* de *«el primero de una lista mala»*. **Un
umbral que no significa lo que parece es un defecto de diseño, no de redacción**,
y no se arregla escribiendo un aviso más grande.

### La cura: dos números, un trabajo cada uno

| | `cobertura` | `score` |
|---|---|---|
| **Qué es** | Relevancia **ABSOLUTA** | Posición **RELATIVA** |
| **Para qué** | Medir, filtrar, **reportar** | Solo ordenar |
| **Comparable entre consultas** | ✅ sí | ❌ no |
| **Umbral** | `RAG_MIN_COBERTURA` | `RAG_MIN_SCORE` |
| **Llega al prompt/informe** | ✅ sí | ❌ no |

**`cobertura`** es la fracción del **peso informativo** de la consulta que el
fragmento cubre realmente, medida en IDF:

```
              Σ IDF(t)  para t en (consulta ∩ fragmento)
cobertura =  ─────────────────────────────────────────────
              Σ IDF(t)  para t en consulta
```

Ponderar por IDF —y no contar términos a pelo— importa por dos motivos:

1. **Acertar `kupiec` (raro) vale más que acertar `numero` (común).** Es la misma
   intuición que hace funcionar a BM25, aplicada a la cobertura.
2. **Arregla de paso la injusticia del caso «excepciones».** Un término que no
   existe en el corpus tiene IDF 0, así que ahora desaparece del numerador **y
   del denominador**, en vez de penalizar al fragmento por no contener algo que
   nadie contiene.

### La pieza que faltaba: el peso informativo de la *consulta*

Al medir esto apareció el agujero de verdad. Con la cobertura sola, la consulta
`"modelo"` da **1.00 en todos los fragmentos**. Y eso **no es un error de
cálculo**: es cierto. `"modelo"` está en todas partes, así que todo la cubre
entera.

El problema no era el fragmento, era **la pregunta**. Y eso ningún reajuste del
score del fragmento puede arreglarlo — lo que hay que hacer es **decirlo**:

```
peso_informativo = Σ IDF(t) sobre los términos de la consulta
```

Medido en el índice de `VaR`:

| consulta | Σ IDF | lectura |
|---|---|---|
| `estacionariedad de series temporales y volatilidad EWMA` | **6.51** | consulta rica |
| `activos liquidos de alta calidad HQLA` | 5.54 | rica |
| `backtesting: numero de excepciones y prueba de Kupiec` | 1.76 | buena |
| **`modelo`** | **0.41** | ⚠️ casi no pregunta nada |
| `kupiec christoffersen backtesting` **al dominio LaR** | **0.00** | ⚠️ dominio equivocado |

Por debajo de `RAG_PESO_INFORMATIVO_MINIMO` (0.8) pasan dos cosas:

1. Se registra un **warning** que nombra la causa.
2. El bloque inyectado al prompt **declara su propia incertidumbre**:

```markdown
## Conocimiento recuperado — dominio: VaR

> ⚠️ AVISO: los términos de esta búsqueda son poco distintivos en este corpus.
> Los fragmentos siguientes pueden no ser específicos de la cuestión evaluada:
> trátalos como contexto de fondo, no como referencia que confirme o refute nada.

### [1] Fuente: … (cubre el 100% de los términos clave de la consulta)
```

**Ésa es la diferencia entre una advertencia y una cura.** Un aviso en un manual
lo lee quien ya sospecha; una salvaguarda que viaja pegada al dato la lee el
modelo, y queda en el informe.

### Cómo distinguir los dos fracasos

Con el peso informativo, dos situaciones que antes eran indistinguibles —y que
piden acciones **opuestas**— ahora se separan solas:

| Señal | Qué pasa | Qué hacer |
|---|---|---|
| Peso **alto**, 0 resultados | La consulta es buena; **el corpus no lo cubre** | Añadir literatura a `inputs/rag/<dominio>/` |
| Peso **bajo** (< 0.8) | El corpus puede estar bien; **la consulta no distingue** | Reformular con términos específicos |
| Peso **0.00** | Ningún término del corpus | ¿Dominio equivocado? |

```bash
python scripts/explicar_rag.py --dominio VaR --consulta "…"   # te lo dice todo
```

---

## 8. Las tres redes de seguridad

### Red 1 — Corte absoluto por cobertura (contra el ruido con aspecto de certeza)

Antes de puntuar nada, se descarta todo fragmento cuya **cobertura absoluta** no
alcance `RAG_MIN_COBERTURA` (0.15). Como mínimo eso exige compartir algún término
con la consulta; y además exige que lo compartido pese algo.

**Por qué es imprescindible.** El `score` se normaliza contra el mejor de la
consulta, así que sin un corte absoluto **siempre** habría un «mejor resultado»
con 1.00 — incluso preguntando por una receta de cocina. Sería el peor fallo
posible en un RAG: **inyectar ruido con aspecto de certeza** en el prompt de una
validación.

Verificado:

```
consulta: "receta de tortilla de patatas"   →   0 resultados ✅
```

> **Un detalle técnico que costó encontrar.** El filtro está sobre la cobertura y
> no sobre «BM25 > 0» por un motivo concreto: `BM25Okapi` calcula el IDF como
> `log(N−df+0.5) − log(df+0.5)`, **sin** el «+1» que otras variantes meten dentro
> del logaritmo. Con N=2 y df=1 eso da **exactamente 0**, así que un término
> presente en uno de dos documentos no vale nada y la consulta entera puntúa
> cero. `rank_bm25` tiene un `epsilon` para esto, pero solo repara los IDF
> **negativos**: el cero pasa de largo. La cobertura mide solape real y no
> depende de la estadística del corpus.

### Red 2 — Degradación elegante (el RAG nunca tumba una validación)

El RAG **enriquece** el prompt. Si falla, la validación **continúa sin contexto**.
Nunca se propaga una excepción.

| Qué pasa | Respuesta |
|---|---|
| No hay índice | `[]` |
| Falta `rank_bm25` | `[]` |
| Índice corrupto | `[]` (y se reconstruye) |
| La consulta solo tiene stopwords | `[]` |
| Nada supera el umbral | `""` |
| Cualquier excepción inesperada | `[]` + warning |

Y devuelve `""`, no un bloque con cabecera vacía: un encabezado *«Conocimiento
recuperado»* sin nada debajo **invita al modelo a rellenar el hueco**.

### Red 3 — El RAG no indexa la evidencia que evalúa

El índice lee **solo** de `inputs/rag/<dominio>/` — literatura de referencia
externa. **Nunca** de `inputs/documentacion/`, que es la evidencia del modelo bajo
validación.

**Por qué, y esto es grave:** si el RAG indexara la evidencia, ante la actividad
*«¿el manual documenta el backtesting?»* recuperaría fragmentos **del propio
manual** y los inyectaría como «conocimiento recuperado del dominio». El modelo
vería sus propias afirmaciones presentadas como **referencia autorizada que las
confirma**. El agente se daría la razón a sí mismo.

También se excluyen los `README.md` de esas carpetas: explican *qué debe ir ahí*,
no son conocimiento del dominio. Sin excluirlos, una consulta podría recuperar
*«Qué NO va aquí: la evidencia del modelo…»* y presentarlo como referencia
experta.

---

## 9. Cómo se conecta con el agente

```
agente.py
    └─ motor_ia.evaluar_actividad(actividad, ambito, titulo_modelo, …)
          │
          ├─ _rag_inferir_dominio("Modelo VaR Mercado FRTB") ────→ "VaR"
          │      (por palabras clave del --titulo; sin match → "shared")
          │
          ├─ _enriquecer_con_rag(actividad, ambito, …)
          │      │
          │      └─ get_retriever("VaR").query_para_prompt(
          │              f"[{ambito}] {actividad}",   ← consulta ENRIQUECIDA
          │              top_k=6, min_score=0.35)
          │              │
          │              └─ BuscadorLexico("VaR").buscar_para_prompt(…)
          │
          ├─ prompt = contexto + cobertura + BLOQUE_RAG + anti-sesgo + …
          │
          └─ llamada de CHAT a Azure  ← la ÚNICA salida a red de todo el flujo
```

**La consulta va enriquecida** con el ámbito (`[Seguimiento] Verificar…`) y no
pelada. Con búsqueda léxica esto importa mucho más que con embeddings: cada
término adicional es **superficie de coincidencia**.

**Inferencia de dominio** desde `--titulo`:

| Dominio | Palabras clave |
|---|---|
| `LaR` | lar, liquidity, liquidez, lic, hqla |
| `VaR` | var, value at risk, frtb, market risk, riesgo de mercado |
| `conductuales` | conductual, prepago, retiro, nmd, comportamiento |
| `shared` | *(cualquier otro)* |

En el JSON de salida quedan `rag_dominio` y `rag_chunks`, para poder auditar
después qué contexto vio el modelo en cada evaluación.

---

## 10. Operación diaria

### Ver el estado

```bash
python scripts/rebuild_rag_databricks.py --status
```

```
  ✅ LaR                9 chunks / 2 docs (2 en disco)  —  2026-07-31 07:25
  ✅ VaR               12 chunks / 3 docs (3 en disco)  —  2026-07-31 07:25
  ✅ conductuales       6 chunks / 1 docs (1 en disco)  —  2026-07-31 07:25
  ✅ shared            16 chunks / 3 docs (3 en disco)  —  2026-07-31 07:25
```

Un `🔄 DESFASADO` significa que la literatura cambió desde que se construyó.

### Añadir literatura nueva

1. Deja el PDF/DOCX/MD en `inputs/rag/<dominio>/`.
2. Reconstruye:

```bash
python scripts/rebuild_rag_databricks.py --dominio all --force
```

> `--force` reextrae los documentos. Sin él, un índice cuya huella coincide con
> el disco se reutiliza tal cual.

### Entender o depurar una consulta

```bash
python scripts/explicar_rag.py --dominio VaR --consulta "prueba de Kupiec"
```

### Rendimiento medido

| Operación | Tiempo |
|---|---|
| Indexar los 4 dominios (`--force`) | **1,7 s** |
| Recargar un índice de disco | ~25 ms |
| Consultar (índice en memoria) | **2–4 ms** |

Los índices ocupan 104 KB en total. La base vectorial anterior ocupaba **81 MB**.

---

## 11. Parámetros y cuándo tocarlos

Todos se declaran en `config/parametros.py` (fuente única) y se ajustan por
`.env`. `src/rag/config_rag.py` los importa; solo los duplica como valores de
respaldo para poder usar `src/` fuera del árbol del agente, y hay un test que
impide que las dos copias diverjan.

| Variable | Default | Qué hace | Cuándo tocarlo |
|---|---|---|---|
| `RAG_TOP_K` | **6** | Fragmentos inyectados | Subir si falta contexto; bajar si el prompt se llena |
| `RAG_MIN_COBERTURA` | **0.15** | Relevancia mínima **ABSOLUTA**. El corte de verdad | Subir para exigir más solape real |
| `RAG_MIN_SCORE` | 0.35 | Recorte **relativo** de la cola de la lista | Subir para quedarte solo con la cabeza |
| `RAG_PESO_INFORMATIVO_MINIMO` | 0.8 | Σ IDF por debajo del cual la **consulta** se declara poco discriminante. No filtra: avisa | Bajar si el corpus es pequeño y salta de más |
| `RAG_PESO_BM25` | 0.7 | Peso de la coincidencia exacta | Subir si la terminología es lo único que importa |
| `RAG_PESO_TFIDF` | 0.3 | Peso del solape de vocabulario | Subir si hay falsos positivos por un término raro suelto |
| `RAG_BM25_K1` | 1.5 | Saturación por repetición | Rara vez |
| `RAG_BM25_B` | 0.75 | Penalización por longitud | Rara vez |
| `RAG_CHUNK_SIZE` | 1200 | Caracteres por fragmento | Subir para fragmentos con más contexto |
| `RAG_CHUNK_OVERLAP` | 200 | Solape | Subir si se parten ideas |
| `RAG_TFIDF_NGRAM_MAX` | 2 | Hasta bigramas | 3 para trigramas (más lento, más preciso) |
| `RAG_STEMMING` | 1 | Stemming ES/EN | 0 para búsqueda literal estricta |
| `RAG_INDICE_DIR` | `data/rag_lexico` | Dónde se persiste | En Databricks, a DBFS |

> ⚠️ **`RAG_TOP_K` subió de 3 a 6** al pasar al RAG léxico. Es un cambio de
> comportamiento deliberado: con embeddings, la similitud coseno concentraba lo
> relevante en los primeros puestos y 3 bastaba. La recuperación léxica reparte
> la señal entre más fragmentos —un término puede estar en la definición, en el
> ejemplo y en la tabla— y con 3 se dejaba fuera contexto pertinente.

> ⚠️ **Los pesos 0.7/0.3 y `RAG_MIN_COBERTURA` son puntos de partida razonados,
> NO calibrados empíricamente.** El corpus actual son documentos de apoyo de
> ~6 KB, no los BCBS íntegros. Con la literatura real conviene revisarlos:
> `RAG_MIN_COBERTURA` se eligió como suelo contra la irrelevancia (en este
> corpus las fuentes correctas puntúan 0.47–1.00 y el ruido 0.20–0.26), no como
> mando de precisión.

---

## 12. Diagnóstico: no recupera lo que espero

**Empieza siempre por aquí:**

```bash
python scripts/explicar_rag.py --dominio <dom> --consulta "<tu consulta>"
```

Y recorre esta tabla en orden:

| Síntoma | Causa probable | Comprobación | Solución |
|---|---|---|---|
| **0 resultados** | La consulta solo tiene stopwords | Paso 1: ¿la lista de tokens está vacía? | Reformula con términos con contenido |
| **0 resultados** | Ningún término existe en el corpus | Paso 4: ¿Σ IDF = 0.00? | El corpus no cubre el tema, o preguntas al dominio equivocado |
| **Todo sale con cobertura 1.00** | La **consulta** no discrimina | Paso 4: ¿Σ IDF < 0.8? | Reformula con términos específicos. No es un fallo del índice |
| **0 resultados** | El índice no existe | `--status` | `rebuild… --dominio <dom>` |
| **Recupera el documento equivocado** | Falta un término de anclaje | Paso 2: ¿algún `df=0`? | **El caso más común.** Ver [§6](#6-dónde-falla-el-caso-excepciones): busca con la palabra que usa el documento |
| **Recupera lo correcto pero con score bajo** | `score` solo indica posición | Mira `cobertura`, que es la que mide | Normal. Ver [§7](#7-los-dos-números-relevancia-absoluta-y-posición-relativa) |
| **Recupera fragmentos irrelevantes en el top** | Un término raro suelto engaña a BM25 | Compara `BM25n` y `TFIDFn` | Sube `RAG_PESO_TFIDF` |
| **Devuelve texto de un documento borrado** | Índice desfasado | `--status`: ¿🔄? | `rebuild… --force` |
| **Recupera el README de la carpeta** | No debería pasar nunca | — | Es un bug: hay test que lo cubre |
| **Recupera el manual bajo validación** | Fuente mal configurada | ¿Se indexó `inputs/documentacion/`? | **Grave** — razonamiento circular, ver [§8](#red-3--el-rag-no-indexa-la-evidencia-que-evalúa) |
| **`rag_dominio: "no_disponible"`** | El import del RAG falló | `pip show rank_bm25` | `pip install rank_bm25 scikit-learn` |

---

## 13. Mapa de ficheros

```
src/rag/
├── config_rag.py          Parámetros. Importa de config/parametros.py.
├── indexador_lexico.py    ⭐ MOTOR DE INDEXADO
│                            · tokenizar()          ← la función clave
│                            · _stem/_despluralizar ← normalización morfológica
│                            · IndexadorLexico      ← construir/cargar/estado
│                            · IndiceLexico         ← lo que se guarda en disco
├── buscador_lexico.py     ⭐ MOTOR DE CONSULTA
│                            · BuscadorLexico.buscar()            → top-K
│                            · BuscadorLexico.buscar_para_prompt()→ texto
├── base_indexer.py        Adaptador: conserva build_index() para los scripts
├── base_retriever.py      Adaptador: conserva query()/query_para_prompt()
│                            con la MISMA firma que ya consumía motor_ia
├── __init__.py            Dispatcher: get_retriever(), inferir_dominio()
└── {LaR,VaR,conductuales,shared}/
    ├── indexer.py         Solo declara el dominio
    └── retriever.py       Solo declara el dominio

scripts/
├── rebuild_rag_databricks.py   Construir / --status
└── explicar_rag.py             ⭐ Esta guía, ejecutable

config/parametros.py       Fuente única de los parámetros RAG_*
inputs/rag/<dominio>/      Literatura de referencia (la entrada)
data/rag_lexico/*.pkl      Índices persistidos (la salida)
tests/test_rag_lexico.py   26 tests del motor
```

**Por qué hay adaptadores.** `base_indexer.py` y `base_retriever.py` son capas
finas sobre el motor. Existen para que la sustitución del backend **no cambiara
ni una firma** de lo que ya consumían `motor_ia.py` y los scripts. Si
`query_para_prompt()` hubiera cambiado de firma, `_enriquecer_con_rag` habría
capturado el `TypeError` y devuelto `""`: el RAG habría quedado apagado en
silencio — exactamente el estado del que se venía.

---

## 14. Decisiones de diseño y por qué

| Decisión | Alternativa descartada | Por qué |
|---|---|---|
| BM25 + TF-IDF | Embeddings | No hay deployment de embeddings, y el de chat no los genera |
| Sin ChromaDB | ChromaDB | Arrastra `huggingface-hub` transitivamente |
| Stopwords escritas en el fichero | `nltk.download()` | Descarga de GitHub → mismo `CERTIFICATE_VERIFY_FAILED` que HuggingFace. Reubica el problema, no lo resuelve |
| Stemmer propio conservador | Snowball (nltk) | Misma razón + un stemmer agresivo destruye los tecnicismos |
| Persistir datos, no objetos | Picklear sklearn/BM25 | Un pickle de sklearn no es estable entre versiones |
| Filtro por cobertura | Filtro por `BM25 > 0` | `BM25Okapi` da IDF exactamente 0 en corpus pequeños |
| Cobertura ponderada por IDF | Contar términos coincidentes | Acertar un término raro vale más; y un término ausente del corpus deja de penalizar |
| Tesauro escrito a mano | Sinónimos derivados del corpus (LSA/co-ocurrencia) | Un término con df=0 no aparece nunca: no hay contexto del que inferir nada. Y un tesauro es auditable por un validador |
| Corregir solo términos con df=0 | Corrección ortográfica general | Sobre un término que ya aporta cero, corregir no puede empeorar el resultado |
| Reportar `cobertura`, ordenar por `score` | Un único número para todo | Un número no puede medir y ordenar a la vez: normalizar contra el máximo destruye el significado absoluto |
| Avisar del peso informativo de la consulta | Solo puntuar fragmentos | Una consulta vacía de información no se arregla ajustando el score de lo que devuelve |
| Texto crudo en el índice | Resumir cada chunk con IA | Caro, y el resumen destruye la terminología literal que BM25 busca |
| Un tokenizador para ambos lados | Dejar que sklearn tokenice | Las dos señales medirían vocabularios distintos |
| Carpeta `data/rag_lexico/` | Reutilizar `data/vectordb/` | Formatos distintos en la misma ruta = un índice viejo pasa por nuevo |
| `EL`/`ES` sin proteger | Protegerlas como siglas | Colisionan con las palabras más frecuentes del español y romperían el filtro de irrelevancia |
| Escritura atómica | Escribir directo | Un `Ctrl-C` dejaría un `.pkl` truncado en la ruta oficial |

---

## Verificación de las dos restricciones

```bash
python validate_project.py --strict     # sección 5-bis: POLÍTICA CERO HUGGINGFACE
pytest tests/test_rag_lexico.py         # 26 tests del motor
```

Estado a fecha de esta guía:

- **0** paquetes de HuggingFace en el código, en `requirements.txt` y en el
  entorno instalado.
- **0** llamadas a un deployment de embeddings.
- Hay un test que **rompe el socket** (`socket`, `create_connection`,
  `getaddrinfo`) y ejerce el ciclo completo indexar → persistir → recargar →
  consultar. Si algo intentara salir a la red, falla con `RuntimeError` en vez de
  pasar silenciosamente porque la máquina tenía conexión.

---

*Documento vivo. Los números se regeneran con `python scripts/explicar_rag.py`.*
