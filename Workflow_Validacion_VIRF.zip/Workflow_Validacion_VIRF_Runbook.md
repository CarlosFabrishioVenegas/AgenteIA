---
title: "Workflow de Validación VIRF — Runbook secuencial"
subtitle: "Un agente por prompt · Copilot Studio · handoff por archivo · anclaje anti-alucinación"
author: "Unidad de Validación de Modelos (MRM) — Validaciones Periódicas"
date: "Versión 1.0"
lang: es
toc-title: "Contenido"
---

# 0. Cómo leer este runbook

Este documento es el **procedimiento operativo** para ejecutar una validación periódica completa cuando **solo puedes usar un agente por prompt**. No hay orquestación automática: **tú eres el orquestador**. Ejecutas un agente, guardas su salida como archivo, y la subes al siguiente agente.

Para cada paso encontrarás cinco cosas, en este orden fijo:

1. **Cargar** — qué archivos adjuntar a esa conversación.
2. **Formato** — en qué formato debe estar cada archivo.
3. **Formato preferido** — el que da resultados más fiables.
4. **Prompt** — el texto exacto a pegar (listo para copiar).
5. **Salida** — cómo guardar la respuesta y con qué nombre, para el siguiente paso.

# 1. Los tres principios que hacen fehaciente el resultado

**Principio 1 — Anclaje del modelo en cada prompt (anti-alucinación).** Desde el Paso 0 en adelante, **todo** prompt empieza con el *bloque de anclaje* (sección 3) y **re-adjunta** el archivo de entendimiento del modelo. Esto evita que el agente "recuerde" mal el modelo o infiera de otro: en cada turno vuelve a leer qué modelo es, de qué tipo y con qué evidencia. Es la medida más eficaz contra la alucinación en un flujo de sesiones separadas.

**Principio 2 — Handoff por archivo, en Markdown.** Cada agente devuelve **solo** contenido Markdown (sin texto conversacional). Copias esa respuesta y la guardas como `.md` con el nombre indicado. Ese `.md` es el insumo del siguiente agente. Markdown es el formato preferido para los entregables intermedios porque es texto plano —se re-sube sin pérdida, no arrastra formato que confunda al modelo y es legible y auditable.

**Principio 3 — Sin fuente no hay afirmación.** Todo prompt exige que cada fila de salida cite su fuente exacta (documento > sección > página; archivo > hoja > celda; archivo > línea). Sin fuente verificable, el agente escribe `No evidenciado`, nunca "Cumple". Esta regla ya está en las instrucciones de cada agente; el prompt la refuerza.

# 2. Preparación (una sola vez por ciclo, antes del Paso 0)

Crea la **carpeta del ciclo** con esta estructura y deja ahí todo lo que produzcas:

```
Validacion_<CODIGO>_<CICLO>/
├── 00_insumos/           manuales, acta, herramienta, correos, PPT, informe anterior
├── 01_salidas_agentes/   los .md que devuelve cada agente (handoff)
├── 02_notebook/          notebook y reconciliación (si la herramienta es Excel)
└── inventario.csv        archivo, tipo, fecha, versión, hash SHA-256
```

Antes de empezar, verifica los insumos: los PDF permiten **búsqueda de texto** (si no, requieren OCR), hay **una sola versión** de cada manual, y renombraste los archivos con la convención `<CODIGO>_<CICLO>_<Tipo>_<version>.pdf`. Registra el hash SHA-256 de cada insumo en `inventario.csv`.

# 3. Bloque de anclaje (se pega al inicio de CADA prompt desde el Paso 0)

Rellénalo una vez con los datos del modelo y **reúsalo idéntico** en todos los pasos siguientes. Es el corazón del Principio 1.

```text
=== ANCLAJE DEL MODELO (no inferir nada fuera de esto) ===
Modelo:            [nombre oficial, tal como figura en el acta]
Código:            [código de inventario]
Tipo de modelo:    [VaR/Mercado | IFRS9/Crédito | ALM conductual/IRRBB | LaR/Liquidez | Operacional | Otro]
Tier:              [1 | 2 | 3]
Ciclo evaluado:    [AAAA-QN]
Fecha de corte:    [AAAA-MM-DD]
Documento de entendimiento adjunto: [nombre del .md de entendimiento] (LÉELO ANTES DE RESPONDER)

REGLAS DE ESTA SESIÓN
- Solo afirmas lo que esté literalmente en la evidencia adjunta a este prompt.
- Cada fila de salida cita su fuente exacta. Sin fuente => "No evidenciado".
- No uses conocimiento de otros modelos ni de otros ciclos.
- Si algo es ambiguo o contradictorio, escribe "Consulta abierta" con la pregunta exacta.
- Devuelve SOLO Markdown, sin texto antes ni después, para guardarlo como archivo.
=== FIN DEL ANCLAJE ===
```

> **Nota sobre el "Tipo de modelo".** En el Paso 0 (Agente A1/A4) el agente **determina** el tipo de modelo a partir de los manuales y lo escribe en el entendimiento. A partir de ahí, ese tipo viaja en el bloque de anclaje y cada control aplica los controles cuantitativos correctos. Si aún no lo conoces al iniciar, deja `Tipo de modelo: por determinar` en A1; a partir de A4 ya estará fijado.

\newpage

# 4. Secuencia del workflow (orden de ejecución)

Ejecuta los agentes en este orden. Los pasos 1 y 2 pueden hacerse en cualquier orden entre sí; el resto es secuencial.

| # | Agente | Qué hace | Entrega (archivo) |
|---|---|---|---|
| 1 | **A1** | Genera el entendimiento `.md` desde los manuales PDF | `A1_entendimiento.md` |
| 2 | **A2** | Convierte la herramienta Excel a notebook (solo si es Excel) | `A2_notebook.ipynb` + `A2_reconciliacion.md` |
| 3 | **A4** | Paso 0: consolida el entendimiento + mapa de evidencia + guion de infografía | `A4_paso0.md` ← **archivo de anclaje** |
| 4 | **A3** | Evaluador técnico de calidad de datos (matriz de 7 columnas) | `A3_matriz_datos.md` |
| 5 | **A6** | Control de Calidad de Datos (juicio de negocio) | `A6_control_datos.md` |
| 6 | **A5** | Control de Documentación | `A5_control_documentacion.md` |
| 7 | **A7** | Control de Metodología (con prompt especializado por tipo) | `A7_control_metodologia.md` |
| 8 | **A8** | Control de Implementación | `A8_control_implementacion.md` |
| 9 | **A9** | Control de Gobierno | `A9_control_gobierno.md` |
| 10 | **A10** | Control de Usos | `A10_control_usos.md` |
| 11 | **A11** | Validador final: consolida todo en la tabla de 8 columnas | `A11_informe_validacion.md` |

**Regla de re-adjunto (Principio 1).** Desde el Paso 3 en adelante, **siempre** adjunta `A4_paso0.md` (el archivo de anclaje) además de la evidencia propia del paso. Es lo que mantiene al agente anclado al modelo correcto en cada sesión.
\newpage

# 5. Pasos detallados

En cada prompt, el texto entre `[corchetes]` lo reemplazas tú. El bloque de anclaje va **siempre** al inicio (aquí se abrevia como `<<ANCLAJE>>`).

## Paso 1 — Agente A1 · Entendimiento desde PDFs

**Cargar:** manuales del modelo (metodológico, de usuario, de seguimiento), acta del modelo, presentaciones (PPT) del modelo.
**Formato:** PDF con capa de texto; el acta puede ser PDF o Word.
**Formato preferido:** PDF con numeración de página impresa (para citas verificables).

**Prompt:**
```text
<<ANCLAJE>>  (en este primer paso el Tipo de modelo puede ir "por determinar")

TAREA: Genera el archivo de entendimiento del modelo a partir de los manuales
adjuntos, siguiendo la plantilla oficial. Determina e indica explícitamente el
TIPO de modelo (VaR/Mercado, IFRS9/Crédito, ALM conductual/IRRBB, LaR/Liquidez,
Operacional u otro) a partir de su propósito, inputs y outputs, citando dónde lo
sustentas. Transcribe supuestos y limitaciones de forma LITERAL, entre comillas.
Cada campo lleva su cita con página. Los campos sin evidencia se marcan
"No evidenciado". Cierra con: documentos leídos (con su hash si lo tienes),
documentos esperados y no recibidos, y consultas abiertas numeradas.
```
**Salida:** guarda la respuesta como **`A1_entendimiento.md`** en `01_salidas_agentes/`.

## Paso 2 — Agente A2 · Conversor Excel → notebook (solo si la herramienta es Excel)

**Cargar:** la herramienta del modelo (`.xlsx`/`.xlsm`), su manual de usuario y `A1_entendimiento.md`.
**Formato:** Excel el libro; Markdown el entendimiento.
**Formato preferido:** el libro Excel original, sin proteger; si tiene macros VBA, inclúyelas.

**Prompt:**
```text
<<ANCLAJE>>

TAREA: Convierte la herramienta Excel adjunta en un notebook de Python
funcionalmente equivalente, con trazabilidad celda->código. Replica la lógica
tal cual (no la corrijas; reporta lo discutible como observación). Entrega:
(a) el código del notebook, (b) la tabla de trazabilidad hoja>celda>función>línea,
(c) la tabla de RECONCILIACIÓN de cada salida (Excel vs notebook, tolerancia 1e-9),
(d) la lista de elementos no traducibles (VBA, conexiones externas) con su riesgo.
No entregues el notebook sin la tabla de reconciliación.
```
**Salida:** guarda el código como **`A2_notebook.ipynb`** y la tabla de reconciliación como **`A2_reconciliacion.md`**.

> Si la herramienta ya es Python, **omite el Paso 2** y anótalo en el Paso 0.

## Paso 3 — Agente A4 · Paso 0 (entendimiento consolidado)

**Cargar:** `A1_entendimiento.md`, `A2_reconciliacion.md` (si aplica), minutas de la reunión de entendimiento y de kick-off, acta del modelo, correos del requerimiento, informe de la validación anterior.
**Formato:** Markdown las salidas previas; PDF/Word el resto.
**Formato preferido:** Markdown para todo lo que sea texto; PDF con página para actas y correos.

**Prompt:**
```text
<<ANCLAJE>>  (ya con el Tipo de modelo determinado en A1)

TAREA: Consolida el Paso 0. Reconcilia manual, acta y minutas y construye la
tabla de discrepancias (qué dice cada fuente, con cita). Declara el ESTADO DE
ADMISIBILIDAD de la herramienta (Python corre sin errores / con errores / Excel
con .md / no entregada) y confirma el TIPO y TIER del modelo. Entrega:
(a) el documento de entendimiento consolidado,
(b) el MAPA DE EVIDENCIA por control (C1 a C6): qué evidencia existe y cuál falta,
    con rutas de archivo exactas,
(c) el guion de la infografía de una página,
(d) el porcentaje de completitud y las consultas abiertas.
Si la completitud es < 80%, rotula "Entendimiento parcial" y lista lo faltante.
```
**Salida:** guarda como **`A4_paso0.md`**. **Este es el archivo de anclaje**: se re-adjunta en todos los pasos siguientes.

## Paso 4 — Agente A3 · Evaluador técnico de calidad de datos

**Cargar:** `A4_paso0.md`, el catálogo de controles de datos (`ControlesData.xlsx` si existe), el dataset del ciclo (o su perfilado), y la salida del notebook de controles.
**Formato:** Markdown el anclaje; Excel/CSV el catálogo; CSV/Parquet el dataset; Markdown/HTML la salida del notebook.
**Formato preferido:** entrega el **perfilado** del dataset (conteos, nulos, rangos) en vez del microdato; **nunca subas datos de clientes identificables**.

**Prompt (base):**
```text
<<ANCLAJE>>

TAREA: Evalúa la calidad de datos y devuelve la MATRIZ DE 7 COLUMNAS
(Dimensión | Control esperado | ¿Existe según evidencia? | Diagnóstico |
Decisión | Control o evidencia requerida | Referencia en el entregable).
Cubre las nueve dimensiones (completitud, unicidad, validez, consistencia,
exactitud, integridad referencial, oportunidad, estabilidad poblacional,
trazabilidad del linaje). Cada diagnóstico incluye la cifra (registros
afectados y %). Aplica los controles de datos correspondientes al TIPO de
modelo indicado en el anclaje (ver la nota de especialización más abajo).
Cierra con el bloque de reproducibilidad (versión, semilla, hashes).
```
**Especialización por tipo** (añade la línea que corresponda al final del prompt):
- **Mercado/VaR:** "Aplica los controles de la base de riesgo de mercado (calendario de días hábiles, stale prices, saltos, arbitraje triangular, no-arbitraje de curva, superficie de vol)."
- **IFRS9/Crédito:** "Prioriza estabilidad poblacional (PSI/CSI), integridad referencial préstamo-cliente-garantía, linaje del dato de default y representatividad de la muestra."
- **ALM conductual/LaR:** "Prioriza la calidad de las series de saldos y flujos, la consistencia de fechas de corte y el linaje de los supuestos conductuales."

**Salida:** guarda como **`A3_matriz_datos.md`**.

## Paso 5 — Agente A6 · Control de Calidad de Datos (juicio)

**Cargar:** `A4_paso0.md`, `A3_matriz_datos.md`, el diccionario de datos y el marco de controles del banco.
**Formato:** Markdown.
**Formato preferido:** Markdown.

**Prompt:**
```text
<<ANCLAJE>>

TAREA: Emite el CONTROL de Calidad de Datos usando la matriz de A3 adjunta.
Primero verifica que las nueve dimensiones estén completas, con cifra y
referencia; si falta algo, indícalo y no concluyas. Para cada actividad VIRF de
Calidad de Datos, traduce el defecto a IMPACTO sobre el output del modelo (qué
variable, qué peso, qué dirección/magnitud). Evalúa la existencia del MARCO de
control (umbral, responsable, periodicidad), no solo el resultado. Devuelve la
tabla de control con estado (Cumple / Cumple con observación / No cumple /
No evidenciado / No verificable) y la acción pendiente con responsable y fecha.
```
**Salida:** guarda como **`A6_control_datos.md`**.

## Paso 6 — Agente A5 · Control de Documentación

**Cargar:** `A4_paso0.md`, los manuales, el acta, el informe de la validación anterior, y el estándar VIRF filtrado por tier (si lo tienes como archivo).
**Formato:** Markdown el anclaje; PDF/Word los manuales y el acta.
**Formato preferido:** PDF con página para poder citar sección y página.

**Prompt:**
```text
<<ANCLAJE>>

TAREA: Ejecuta el control de Documentación. Genera la matriz con una fila por
actividad VIRF de Documentación aplicable al TIER. Evalúa por separado
completitud, VIGENCIA (que corresponda a la versión productiva del acta y del
código) y coherencia. Marca los defectos formales (secciones vacías, anexos
faltantes, gráficos sin fuente, ausencia de versionado/autor/fecha). Verifica el
cierre de las observaciones documentales del ciclo anterior (una declaración sin
manual actualizado NO cierra). Reporta la cobertura (% de actividades
evidenciadas) antes de la tabla. Cada fila cita documento > sección > página y el
ID de la actividad VIRF.
```
**Salida:** guarda como **`A5_control_documentacion.md`**.
\newpage

## Paso 7 — Agente A7 · Control de Metodología (especializado por tipo)

**Cargar:** `A4_paso0.md`, el manual metodológico, la carpeta de papers, los resultados de las pruebas (discriminación, calibración, estabilidad, backtesting) y `A2_reconciliacion.md` si aplica.
**Formato:** Markdown el anclaje y resultados; PDF los papers y el manual; CSV/imágenes los resultados de pruebas.
**Formato preferido:** los resultados numéricos de las pruebas en tabla (CSV/Markdown), no como captura de pantalla.

**Prompt (base):**
```text
<<ANCLAJE>>

TAREA: Ejecuta el control de Metodología. Evalúa por separado, en filas
distintas, (1) la SUFICIENCIA DEL SUSTENTO de cada decisión metodológica (paper,
norma, prueba, acta; sin acta, "criterio experto" es "No evidenciado") y (2) la
EJECUCIÓN de las actividades exigidas por el estándar. Verifica reproducibilidad
de las métricas reportadas y contrasta cada una contra su umbral declarado.
Aplica las pruebas cuantitativas propias del TIPO de modelo (ver especialización).
Devuelve la matriz metodológica con estado, resultado (cifra), evaluación
sustentada, fuente exacta y acción pendiente; más la tabla métrica reportada vs
reproducida vs umbral.
```
**Especialización por tipo (añade el bloque que corresponda):**
- **Mercado/VaR:** "Aplica: metodologías de VaR (histórico/paramétrico/Monte Carlo), Expected Shortfall, EWMA, escalamiento √t, y el backtesting de Kupiec, Christoffersen y semáforo de Basilea. Verifica positividad y coherencia del VaR, subaditividad/diversificación, y el contraste delta-normal vs revaluación completa. Referencia: Res. SBS 4906-2017 (VaR/SVaR/CVaR/SCVaR, backtesting trimestral) y FRTB (ES 97.5%, PLA)."
- **IFRS9/Crédito:** "Aplica: discriminación (AUC/Gini/KS), IV/WoE y monotonicidad, calibración (Hosmer-Lemeshow, binomial, Jeffreys), estabilidad (PSI/CSI), backtesting de la tasa de default, matriz de transición, LGD (cura, downturn), EAD/CCF, ECL por stage y disparador de SICR. Referencia: IFRS 9 y Res. SBS 3780-2011."
- **ALM conductual/IRRBB:** "Aplica: SMM/CPR y su conversión, curva PSA, runoff, maduración (WAL), duración conductual, backtesting del prepago, y curvas de supervivencia (Kaplan-Meier, hazard). Para IRRBB: ΔEVE, seis escenarios de Basilea, ΔNII, EaR y beta de depósitos."
- **LaR/Liquidez:** "Aplica: gap de liquidez, LaR histórico/paramétrico/Monte Carlo, LCR/NSFR, capacidad de contrabalance, período de supervivencia, CFaR y backtesting del LaR."

**Salida:** guarda como **`A7_control_metodologia.md`**.

## Paso 8 — Agente A8 · Control de Implementación

**Cargar:** `A4_paso0.md`, el código productivo (o `A2_notebook.ipynb`), el log de ejecución del ciclo, los outputs generados, los manuales y `A2_reconciliacion.md`.
**Formato:** Markdown el anclaje; `.py`/`.ipynb`/`.sql` el código; `.log`/`.txt` el log; CSV los outputs.
**Formato preferido:** el log de ejecución completo (sin truncar) y el output del ciclo en CSV.

**Prompt:**
```text
<<ANCLAJE>>

PRECONDICIÓN: verifica que exista log de ejecución del ciclo y outputs revisados.
Si no, devuelve "Precondición no satisfecha" con lo faltante y detente.

TAREA: Ejecuta el control de Implementación. Construye el inventario de bloques
funcionales del código y mapéalos a la sección del manual que los describe.
Compara PARÁMETRO por parámetro (cortes, pesos, umbrales, ventanas); cualquier
diferencia con el manual es "No cumple" y se cuantifica su impacto. Revisa la
higiene con foco en riesgo (warnings silenciados, rutas locales, credenciales,
semillas no fijadas, dependencias sin versión) y el control de cambios (versión,
aprobador, fecha de pase). Reproduce al menos un output y compáralo cifra a cifra
(diferencia absoluta y relativa). Devuelve la matriz de trazabilidad código<->manual.
```
**Salida:** guarda como **`A8_control_implementacion.md`**.

## Paso 9 — Agente A9 · Control de Gobierno

**Cargar:** `A4_paso0.md`, el acta del modelo, el extracto del inventario, los criterios de tiering, y las salidas de los controles previos (`A5`, `A6`, `A7`, `A8`).
**Formato:** Markdown las salidas; PDF/Word el acta y los criterios.
**Formato preferido:** el acta en PDF con página; las matrices de C1-C4 en Markdown.

**Prompt:**
```text
<<ANCLAJE>>

TAREA: Ejecuta el control de Gobierno. Revisa el acta campo por campo evaluando
cuatro atributos: presente, legible, vigente y COHERENTE con la evidencia técnica
de los controles adjuntos (A5-A8). Recalcula el TIERING con los criterios
vigentes y compáralo con el registrado; una diferencia es hallazgo de severidad
alta. Verifica la segregación de funciones (desarrollador/propietario/usuario/
validador) y la consistencia con el inventario. Convierte cada ambigüedad en una
CONSULTA FORMAL (pregunta, evidencia con cita, destinatario, plazo, efecto de la
no respuesta); no resuelvas por inferencia. Cada fila cita el acta y la evidencia
técnica contrastada.
```
**Salida:** guarda como **`A9_control_gobierno.md`**.

## Paso 10 — Agente A10 · Control de Usos

**Cargar:** `A4_paso0.md`, los correos de envío del output (con acuse), las actas de comité donde se sustentó, y la evidencia de publicación.
**Formato:** PDF los correos y actas; Markdown el anclaje.
**Formato preferido:** correos exportados a PDF **con encabezado visible** (remitente, asunto, fecha) y el acuse del área usuaria.

**Prompt:**
```text
<<ANCLAJE>>

TAREA: Ejecuta el control de Usos. Para cada output declarado, reconstruye la
CADENA DE USO (generación -> envío -> recepción acusada -> sustento en el foro ->
decisión) e indica en qué eslabón se rompe. Verifica que el uso real coincida con
el uso DECLARADO en el acta; un uso distinto es hallazgo. Verifica la periodicidad
comprometida (días de desviación) y que la cifra publicada coincida con la que
genera la herramienta. Si no hay ni envío ni sustento en comité, concluye USO NO
SATISFACTORIO y emite la recomendación formal de retiro del inventario. Cada fila
cita correo (remitente>asunto>fecha) o acta (comité>acta>acuerdo).
```
**Salida:** guarda como **`A10_control_usos.md`**.

## Paso 11 — Agente A11 · Validador final (consolidación)

**Cargar:** `A4_paso0.md` y **las seis salidas de control** (`A3`/`A6`, `A5`, `A7`, `A8`, `A9`, `A10`) más el estándar VIRF filtrado por tier.
**Formato:** Markdown todo.
**Formato preferido:** Markdown; adjunta las seis matrices completas, sin resumir.

**Prompt:**
```text
<<ANCLAJE>>

TAREA: Consolida la validación en la TABLA DE 8 COLUMNAS (Ámbito | Control
cuantitativo o cualitativo | Actividad | Cumple o no | Resultado | Evaluación
sustentada | Fuente revisada | Acción pendiente), integrando las seis matrices
adjuntas SIN revalidar. Primero verifica la COBERTURA: cruza las actividades VIRF
aplicables al tier contra las filas recibidas; toda actividad sin fila se agrega
como "No evidenciado". Reporta la cobertura por control y global ANTES de la
tabla. Aplica las reglas de conclusión: un "No cumple" crítico en Implementación
o Usos impide "satisfactoria"; sin evidencia de uso => recomendación de retiro;
cobertura < 100% => "Validación incompleta". Cierra con la conclusión (máx. 12
líneas), el plan de acción consolidado y el anexo de trazabilidad (evidencias con
hash, faltantes, consultas abiertas). Conserva la cita original de cada fila.
```
**Salida:** guarda como **`A11_informe_validacion.md`**. Es el informe final del ciclo.

\newpage

# 6. Matriz de especialización por tipo de modelo

El TIPO se fija en el Paso 0 y determina qué prompts especializados usar. Solo A3, A7 (y matices de A8) cambian; el resto es genérico.

| Tipo de modelo | A3 / A6 (datos) | A7 (metodología) — controles a exigir |
|---|---|---|
| Mercado / VaR | Controles de base de mercado (calendario, stale, saltos, curva, superficie) | VaR (hist/param/MC), ES, EWMA, backtesting Kupiec/Christoffersen/Basilea, MtM, PLA |
| Crédito / IFRS 9 | Estabilidad (PSI/CSI), integridad referencial, linaje del default | AUC/Gini/KS, IV/WoE, Hosmer-Lemeshow, binomial/Jeffreys, LGD/EAD/CCF, ECL, SICR, transición |
| ALM conductual / IRRBB | Series de saldos/flujos, fechas de corte, linaje de supuestos | SMM/CPR, PSA, runoff, maduración/WAL, duración conductual, supervivencia; ΔEVE, ΔNII, EaR, beta depósitos |
| LaR / Liquidez | Series de flujos, contrapartes, monedas | Gap, LaR (hist/param/MC), LCR/NSFR, contrabalance, período de supervivencia, backtesting LaR |
| Operacional | Completitud de pérdidas, umbral de recolección, duplicados | LDA (frecuencia/severidad), EVT/GPD, EL/UL, bondad de ajuste, backtesting de pérdidas |

# 7. Checklist de handoff (para no romper la cadena)

Antes de pasar al siguiente agente, confirma:

1. La respuesta del agente es **solo Markdown** (sin texto conversacional). Si no, vuelve a pedirla con "Devuelve solo Markdown".
2. La guardaste con el **nombre exacto** de la tabla del punto 4.
3. Cada fila tiene **cita**; ninguna afirmación de estado quedó sin fuente.
4. Adjuntaste `A4_paso0.md` (anclaje) al siguiente paso, junto con la evidencia propia.
5. El bloque de anclaje del siguiente prompt es **idéntico** al de los anteriores (mismo modelo, tipo, tier, ciclo).
6. Registraste en `inventario.csv` cualquier evidencia nueva recibida a mitad de camino (evidencia extemporánea, con su fecha).

# 8. Reglas anti-alucinación (resumen operativo)

- **Re-anclar siempre.** Cada prompt abre con el bloque de anclaje y re-adjunta `A4_paso0.md`. Nunca asumas que el agente "recuerda" el modelo.
- **Una sesión, un modelo.** No valides dos modelos en la misma conversación; el agente mezclaría citas.
- **Sin fuente, no hay estado.** Si el agente concluye "Cumple" sin cita, recházalo: "Cita la fuente exacta o marca No evidenciado".
- **No completar por analogía.** Si el agente rellena un campo con lo que "suele" pasar en modelos similares, recházalo: "Usa solo la evidencia adjunta".
- **Literalidad en supuestos.** Supuestos y limitaciones se transcriben entre comillas; si el agente parafrasea, pídelo literal.
- **Consulta, no inferencia.** Ante contradicción entre fuentes, el agente escribe "Consulta abierta", no elige una versión.
- **Verifica el tipo.** Si el "Tipo de modelo" del anclaje no coincide con lo que el agente describe, detente y corrige el Paso 0 antes de seguir.

# 9. Qué necesito de ti para afinar aún más el workflow

Este runbook ya es ejecutable tal cual. Si quieres una versión todavía más precisa, me sirve saber: (a) si tus agentes en Copilot Studio pueden **adjuntar archivos** en la conversación o solo aceptan texto pegado (cambia el Principio 2); (b) el **nombre real** de los campos del acta de tu banco (para incrustarlos en el anclaje y en A9); (c) si usas una **plantilla fija de informe** para A11 (para alinear la tabla de 8 columnas a tu formato); y (d) si el estándar VIRF (`Estandares_VIRF.xlsx`) puede cargarse como archivo en cada control o ya está como conocimiento del agente.
