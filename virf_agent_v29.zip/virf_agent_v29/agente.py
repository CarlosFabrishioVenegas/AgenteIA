"""
agente.py — Punto de entrada del agente VIRF

PIPELINE 1: CALIDAD DE DATOS (nuevo - recomendado)
  python agente.py --titulo "Modelo LaR" --tier 1 --excel inputs/calidad_datos/ControlesData.xlsx --control
  python agente.py --titulo "Modelo LaR" --tier 1 --excel inputs/calidad_datos/ControlesData.xlsx --control --prdc

PIPELINE 2: TODOS LOS ÁMBITOS (legacy - análisis completo)
  python agente.py --titulo "Modelo LaR" --tier 1
  python agente.py --titulo "Modelo LaR" --tier 1 --prdc

ESTADÍSTICAS:
  python agente.py --estadisticafeedback
"""

import argparse
import hashlib
import json
import sys
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# [CONSOLA-FIX] Debe ejecutarse ANTES del primer print y antes de importar
# módulos que impriman al cargarse. En una consola cp1252 (default en Windows
# español) cualquier emoji abortaba la corrida con UnicodeEncodeError — a mitad
# del chunking, con la extracción y varias llamadas IA ya pagadas.
from modulos.consola import configurar_consola

configurar_consola()

from config import (
    OUTPUTS_DIR, ESTANDARES_PATH, BASE_DIR, IA_PROVEEDOR,
    AMBITO_PESOS, ESCALA_PUNTAJE, normalizar_tier,
    MAX_CTX as _MAX_CTX,
    MAX_DOCS_AMBITO as _MAX_DOCS_AMBITO,
)
from modulos.motor_ia_v2 import orquestar_pipeline_virf, evaluar_todos_controles
from modulos.motor_ia import (
    leer_estandares_virf, cargar_todos_inputs, inputs_para_dimension,
    evaluar_ambito_completo, calcular_score_ambito, calcular_score_global,
    get_semaforo, generar_resumen_ejecutivo,
)
from modulos.generador_word import generar_word_informe
from modulos.feedback import calcular_estadisticas, bucle_feedback_consola
from modulos.generador_estadistica_feedback import generar_informe_estadistica

# ── Caché de documentos (v15) ─────────────────────────────────────────────────
from modulos.document_cache import inicializar_cache, cerrar_cache
from motor.Mx_00_CargaRutas import (
    CACHE_ENABLED, CACHE_DIR, AGENTE_VERSION, MAX_CHARS_DOC,
    redirigir_evidencia,
)
from modulos.chunker import ChunkerService

# ── Constantes de límites de contexto ──────────────────────────────────────
CONTROLES_DATA_PATH = BASE_DIR / "inputs" / "calidad_datos" / "ControlesData.xlsx"


def modo_estadistica_feedback():
    print("\n" + "═" * 65)
    print("  📈 ESTADÍSTICAS DE PRECISIÓN DEL AGENTE VIRF")
    print("═" * 65 + "\n")

    stats = calcular_estadisticas()
    if "error" in stats:
        print(f"  [!] {stats['error']}")
        print("  Ejecuta al menos una validación con feedback antes de usar este modo.\n")
        sys.exit(0)

    print(f"  Total feedbacks registrados : {stats['total_feedbacks']}")
    print(f"  Período                     : {stats['primer_feedback']} → {stats['ultimo_feedback']}")
    print(f"\n  {'MÉTRICA':<35} {'VALOR':>10}")
    print(f"  {'─'*47}")
    print(f"  {'Evaluaciones exactas':<35} {stats['pct_exactas']:>9.1f}%")
    print(f"  {'Dentro de ±1 punto':<35} {stats['pct_dentro_1_punto']:>9.1f}%")
    print(f"  {'Error medio absoluto (MAE)':<35} {stats['mae']:>10.3f}")
    print(f"  {'Sesgo promedio':<35} {stats['sesgo_promedio']:>10.3f}")
    print(f"  {'Interpretación sesgo':<35} {stats['sesgo_interpretacion']}")
    print(f"  {'Sobreestimaciones':<35} {stats['n_sobreestimaciones']:>10}")
    print(f"  {'Subestimaciones':<35} {stats['n_subestimaciones']:>10}")
    print(f"\n  {'ÁMBITO':<35} {'MAE':>6}  {'EXACTOS':>8}  {'±1 PTO':>7}")
    print(f"  {'─'*58}")
    for amb, s in stats["por_ambito"].items():
        print(f"  {amb:<35} {s['mae']:>6.3f}  {s['pct_exactos']:>7.1f}%  {s['pct_1_punto']:>6.1f}%")

    print("\n  📊 Generando informe Excel detallado...")
    ruta = generar_informe_estadistica(OUTPUTS_DIR)
    if ruta:
        print(f"\n  ✅ Informe guardado en: {ruta.name}")
    print()


# ── [v20] Auto-setup de .env en primer arranque ───────────────────────────────
def _setup_env_si_falta() -> None:
    """
    Si no existe .env, lo copia desde .env.example con un aviso claro.

    [GENERICO] El aviso indica la clave y la consola DEL PROVEEDOR ACTIVO. Antes
    mandaba siempre a la consola de Anthropic, aunque el proveedor por defecto
    del proyecto es Azure OpenAI: en una instalación nueva, el primer mensaje
    que veía el operador le decía que fuera a pedir la credencial equivocada.
    """
    from pathlib import Path as _Path
    env_path     = _Path(__file__).parent / ".env"
    example_path = _Path(__file__).parent / ".env.example"
    if not env_path.exists() and example_path.exists():
        import shutil
        shutil.copy(example_path, env_path)
        from config.ia import metadatos_proveedor
        _meta = metadatos_proveedor()
        print("\n" + "═" * 60)
        print("  📋 PRIMER ARRANQUE — archivo .env creado automáticamente")
        print(f"  Proveedor configurado: {_meta['nombre']}")
        print(f"  Edita .env y define {_meta['var_clave']} con tu clave real:")
        print(f"    {_meta['consola']}")
        print("═" * 60 + "\n")

_setup_env_si_falta()

def _aplicar_raiz_evidencia(ruta: Optional[str]) -> Path:
    """
    Resuelve la raíz de evidencia y reapunta las carpetas de `inputs/`.

    ── El problema que resuelve ─────────────────────────────────────────────
    `cargar_todos_inputs()` lee TODO `inputs/` sin filtrar por modelo, y
    `--titulo` solo rotula el informe e infiere el dominio RAG. Con la
    evidencia de varios modelos en el mismo árbol, el manual de uno puntúa
    como evidencia de otro: un informe de VaR podría citar el manual del LaR.

    ── Cómo se usa ──────────────────────────────────────────────────────────
        python agente.py --titulo "VaR Mercado FRTB" --tier 1 \\
                         --raiz-evidencia modelos/VaR_FRTB

    Con la estructura:
        modelos/VaR_FRTB/inputs/documentacion/modelamiento/
        modelos/VaR_FRTB/inputs/papers/   ... etc.

    Sin el flag, se usa la raíz del proyecto y el comportamiento es el de
    siempre: nada cambia para quien valide un solo modelo.

    Devuelve la raíz resuelta, que además viaja como `base_project_path` al
    pipeline de controles — la SEGUNDA vía de carga de evidencia, que no pasa
    por RUTAS y se olvidaría fácilmente.
    """
    if not ruta:
        return BASE_DIR
    try:
        _rutas = redirigir_evidencia(ruta)
    except FileNotFoundError as exc:
        print(f"\n  ❌ {exc}\n")
        sys.exit(1)
    _raiz = Path(ruta).expanduser().resolve()
    print(f"  📂 Evidencia: {_raiz}")
    # Declarar las carpetas vacías aquí evita el diagnóstico tardío: sin este
    # aviso, un árbol a medio montar produce ámbitos «sin evidencia» que la
    # política puntúa 0.0 — una falta crítica atribuida al validado cuando en
    # realidad la ruta estaba mal.
    _vacias = [n for n, p in _rutas.items() if not p.is_dir() or not any(p.iterdir())]
    if _vacias:
        print(f"  ⚠️  Carpetas sin documentos: {', '.join(sorted(_vacias))}")
        print(f"      Los ámbitos que dependan de ellas puntuarán 0.0 (sin evidencia).")
    return _raiz


def main():
    parser = argparse.ArgumentParser(
        description="Agente VIRF — Validador de modelos LaR/VaR"
    )
    parser.add_argument("--titulo",              default=None,  help="Nombre del modelo")
    parser.add_argument("--tier",                default=None,  help="Tier del modelo (1, 2, 3, 4)")
    parser.add_argument("--excel",               default=None,  help="Ruta al Excel de controles (para pipeline Calidad de Datos)")
    parser.add_argument("--control",             action="store_true", help="Usar pipeline por CONTROL (Calidad de Datos)")
    parser.add_argument("--prdc",                action="store_true", help="Modo producción (genera Word)")
    parser.add_argument("--estadisticafeedback", action="store_true", help="Ver estadísticas de feedback")
    parser.add_argument("--limpiar-cache",       action="store_true", help="Limpiar caché de documentos y salir")
    parser.add_argument("--cache-stats",         action="store_true", help="Ver estadísticas del caché de documentos")
    parser.add_argument("--no-cache",            action="store_true", help="Deshabilitar caché para esta corrida")
    parser.add_argument("--convertir-excel",     default=None, help="FASE 1: Ruta a carpeta con .xlsx/.xlsm. Genera .ipynb por libro con VBA, refs externas y auto-validación contra Excel. NO copia al pipeline principal — tú decides qué mover a inputs/implementacion/.")
    parser.add_argument("--controles-a-notebook", default=None, help="Ruta a un DOCUMENTO (.docx/.pdf/.md) que describe controles de calidad de datos. Genera un .ipynb ejecutable y un análisis de brechas contra --excel.")
    parser.add_argument("--datasets",            default=None, help="Carpeta con los datasets (.csv/.parquet/.xlsx) para los controles de motor de datos. Default: inputs/calidad_datos/datasets/")
    parser.add_argument("--listar-motores",      action="store_true", help="Muestra el catálogo de pruebas de calidad de datos disponibles y sale")
    parser.add_argument("--explicar-modelo",     default=None, metavar="NOMBRE", help="Genera outputs/<fecha>/explicacion_del_modelo_<NOMBRE>.md consolidando las 4 fuentes de inputs/ (metodología, seguimiento, implementación, calidad de datos)")
    parser.add_argument("--dry-run",             action="store_true", help="Para --explicar-modelo: muestra el inventario de evidencia y el coste estimado SIN llamar al modelo")
    parser.add_argument("--excluir",             default=None, metavar="F1,F2", help="Para --explicar-modelo: nombres de fichero a omitir (p. ej. fixtures de prueba que viven en inputs/)")
    parser.add_argument("--solo-coincidentes",   action="store_true", help="Para --explicar-modelo: usar SOLO los ficheros cuyo nombre contiene el modelo. Úsalo cuando varios modelos comparten las carpetas de inputs/; por defecto se incluye toda la evidencia para no descartar nada en silencio")
    parser.add_argument("--raiz-evidencia",      default=None, metavar="RUTA", help="Raíz alternativa que contiene inputs/ (default: la del proyecto). UN MODELO POR RAÍZ: evita que la evidencia de varios modelos se mezcle y que el informe de uno cite documentos de otro. El estándar VIRF, outputs/ y el caché siguen en la raíz del proyecto. Aplica al pipeline completo, a --control y a --explicar-modelo")
    parser.add_argument("--sin-llm",             action="store_true", help="Para --convertir-excel: no usa LLM (solo estructura + fórmulas sin traducir)")
    parser.add_argument("--sin-validacion",      action="store_true", help="Para --convertir-excel: omite la auto-validación notebook vs Excel")

    # ── Revisión del código contra la documentación ──────────────────────────
    parser.add_argument("--revisar-codigo",      action="store_true", help="Revisa el código de inputs/implementacion/ (recursivo, .py e .ipynb) contra el manual metodológico: UNA llamada por módulo, hallazgos con fichero:línea. Sus hallazgos se fusionan en el ámbito Implementación. Con --dry-run muestra el inventario y el coste estimado SIN gastar")
    parser.add_argument("--perfilar-datasets",   action="store_true", help="Añade a la evidencia un perfil del ESQUEMA de los datasets (columnas, tipos, nulos, rangos, duplicados). No vuelca ninguna fila de datos. Permite contrastar las variables reales contra las que declara el manual")
    parser.add_argument("--prevuelo",            action="store_true", help="Revisa la evidencia ANTES de gastar y sale: qué se podrá leer, qué PDFs están escaneados, qué formatos se omiten sin aviso y qué ámbitos quedarán sin evidencia (puntúan 0.0). Coste 0, no llama al modelo. Sale con código 1 si algún ámbito queda sin evidencia")

    # ── Cumplimiento regulatorio (SR 11-7 · EBA/GL/2023/01) ──────────────────
    parser.add_argument("--validador",           default=None, metavar="NOMBRE", help="Nombre completo del validador responsable. OBLIGATORIO en --prdc (también vía VIRF_VALIDADOR o preguntado en consola)")
    parser.add_argument("--cargo",               default=None, metavar="CARGO", help="Cargo/rol del validador (ej. 'Validador de Segunda Línea'). OBLIGATORIO en --prdc")
    parser.add_argument("--verificar-cadena",    default=None, metavar="MODELO", help="Verifica la integridad de la cadena de custodia de todos los informes de un modelo y sale")
    parser.add_argument("--verificar-evidencia", default=None, metavar="INFORME.JSON", help="Comprueba si los documentos citados por un informe siguen intactos y sale")
    parser.add_argument("--historial-validaciones", action="store_true", help="Lista, por validador, qué modelos ha aprobado y cuándo")
    parser.add_argument("--comparar",            default=None, metavar="MODELO", help="Compara las dos últimas corridas del modelo y sale: score por ámbito, actividades que subieron o bajaron, documentos que cambiaron, y si cambió la VARA DE MEDIR (estándar, modelo de IA, versión del agente). Coste 0")
    parser.add_argument("--verificar-conexion-azure", action="store_true", help="Prueba de humo del proveedor activo: confirma credenciales, detecta el modelo real del deployment, muestra el perfil de chunking que se aplicará y valida que el parser entiende su JSON")

    args = parser.parse_args()

    # ── Inicializar caché de documentos ───────────────────────────────────────
    # [AUDIT-FIX] Antes: `cache_activo = CACHE_ENABLED and not args.prdc and
    # not args.no_cache`, con el motivo "en producción siempre fresco".
    #
    # Ese motivo no se sostiene: el caché está indexado por SHA-256 del fichero
    # (document_cache._hash_archivo), así que un documento modificado produce
    # otra clave y se relee igualmente. La frescura ya la garantiza el hash.
    # Lo único que compraba desactivarlo era pagar el chunking íntegro (~$1.45
    # por el manual de 305 págs) justo en las corridas que emiten el entregable
    # — es decir, anulaba el ahorro de D2 precisamente donde más cuesta.
    #
    # Además, deducir "sin caché" de `--prdc` es adivinar el modo por
    # heurística cuando ya existe el flag explícito `--no-cache` para pedirlo.
    cache_activo = CACHE_ENABLED and not args.no_cache
    cache = inicializar_cache(cache_dir=CACHE_DIR, enabled=cache_activo)

    # [AUDIT-FIX] El try/finally que persiste el caché empieza en la línea ~433,
    # DESPUÉS de los ocho `return` tempranos de esta función. Cualquier modo que
    # salga antes (--explicar-modelo, --convertir-excel, --controles-a-notebook,
    # --cache-stats, --listar-motores) leía documentos y tiraba lo cacheado.
    # Medido: --explicar-modelo leía 5 documentos nuevos y persistía 0.
    # atexit cubre tanto los `return` como los `sys.exit()`.
    import atexit
    atexit.register(cerrar_cache)

    if cache_activo:
        cache.purgar_huerfanos()
        print(f"  📦 Caché de documentos: ACTIVO ({len(cache._data)} entradas previas)")
    else:
        motivo = "--no-cache" if args.no_cache else "CACHE_ENABLED=0 en .env"
        print(f"  📦 Caché de documentos: INACTIVO [{motivo}]")

    # ── [MULTIMODELO] Raíz de evidencia ──────────────────────────────────────
    # Se resuelve ANTES de cualquier rama de modo: --control la usa en su
    # `base_project_path` y el pipeline completo en `cargar_todos_inputs()`.
    # Definirla dentro de una rama la dejaría sin asignar en las demás
    # (es el UnboundLocalError que mató el pipeline en la auditoría).
    _raiz_ev = _aplicar_raiz_evidencia(args.raiz_evidencia)

    # ── Modos de auditoría (coste 0, no requieren API) ───────────────────────
    # Van antes del PRE-FLIGHT: verificar la integridad de informes ya emitidos
    # no debe depender de tener crédito ni conexión. Un auditor puede necesitar
    # comprobar la cadena mucho después de que la clave haya caducado.
    if args.verificar_cadena:
        from modulos.custodia import verificar_cadena, imprimir_cadena
        _res = verificar_cadena(OUTPUTS_DIR, args.verificar_cadena)
        imprimir_cadena(_res)
        sys.exit(0 if _res["integra"] else 1)

    if args.verificar_evidencia:
        from modulos.custodia import verificar_evidencia, imprimir_evidencia
        _ruta_inf = Path(args.verificar_evidencia)
        if not _ruta_inf.exists():
            print(f"\n  ❌ No existe el informe: {_ruta_inf}\n")
            sys.exit(1)
        _res = verificar_evidencia(_ruta_inf)
        imprimir_evidencia(_res)
        sys.exit(0 if _res["todos_intactos"] else 1)

    if args.historial_validaciones:
        from modulos.validador_humano import imprimir_historial
        imprimir_historial()
        return

    # ── Comparación entre corridas (coste 0) ─────────────────────────────────
    # Va con los modos de auditoría, antes del PRE-FLIGHT: comparar dos
    # informes ya emitidos no debe depender de tener crédito ni conexión, igual
    # que verificar la cadena.
    if args.comparar:
        from modulos.comparador import comparar, formatear as _fmt_comp
        try:
            _cmp = comparar(OUTPUTS_DIR, args.comparar)
        except ValueError as exc:
            print(f"\n  ℹ️  {exc}\n")
            sys.exit(1)
        print(_fmt_comp(_cmp))
        # Código 1 si cambió la vara de medir: no es un error, es una señal de
        # que las diferencias NO son atribuibles solo al modelo. Quien encadene
        # esto en un script quiere enterarse.
        sys.exit(1 if _cmp.vara_cambiada else 0)

    # ── [FASE 5] Prueba de humo del proveedor ────────────────────────────────
    # Único comando manual necesario tras pegar la credencial. Hace UNA llamada
    # mínima y responde a las cuatro preguntas que hay que resolver antes de
    # gastar en una corrida completa: ¿la credencial vale?, ¿qué modelo hay
    # detrás?, ¿con qué límites voy a trocear?, ¿entiendo su JSON?
    if args.verificar_conexion_azure:
        from config.ia import prueba_de_humo
        from config import IA_PROVEEDOR as _prov
        _sep = "═" * 74
        print(f"\n{_sep}")
        print(f"  🔌 PRUEBA DE CONEXIÓN — proveedor activo: {_prov}")
        print(f"{_sep}\n")
        r = prueba_de_humo()

        if not r["ok"]:
            print(f"  ❌ FALLO — {r.get('error') or r.get('error_json') or 'desconocido'}")
            if r.get("respuesta_cruda"):
                print(f"\n     Respuesta cruda recibida:")
                print(f"     {r['respuesta_cruda']}")
            # [GENERICO] La lista de variables sale de la ficha del proveedor
            # ACTIVO. Antes se imprimían siempre las de Azure, así que un fallo
            # con Anthropic configurado mandaba a revisar cinco variables que ni
            # siquiera intervenían en la llamada que acababa de fallar.
            from config.ia import metadatos_proveedor as _meta_prov
            _m = _meta_prov()
            print(f"\n  Comprueba en .env (proveedor activo: {_m['nombre']}):")
            for _v in _m["vars_revisar"]:
                print(f"     {_v}")
            print(f"\n  Credenciales: {_m['consola']}")

            # [HTTPS-FIX] Un fallo de TLS/proxy no se parece a un fallo de
            # credencial, pero el operador ve el mismo «no conecta». Se detecta
            # por la firma del error y se explica en términos accionables: sin
            # esto, un CERTIFICATE_VERIFY_FAILED manda a revisar la clave, que
            # está bien, mientras el problema es el proxy de su propia empresa.
            _err = (str(r.get('error') or '') + str(r.get('error_json') or '')).lower()
            if any(_s in _err for _s in ("certificate", "ssl", "tls", "proxy",
                                          "handshake", "self signed", "verify failed")):
                from config.ia import diagnostico_https
                print(diagnostico_https())
            print()
            sys.exit(1)

        pf = r.get("perfil") or {}
        print(f"  ✅ {r['proveedor']} conectado — modelo: {r['modelo']} — "
              f"latencia: {r['latencia_ms']} ms")
        print(f"     JSON parseado correctamente: {r.get('json_muestra', '')}")
        if pf:
            print(f"\n  Perfil de chunking que se aplicará ({pf['nombre']}):")
            print(f"     contexto      : {pf['contexto_tokens']:,} tokens")
            print(f"     chunk_size    : {pf['chunk_size']:,} chars")
            print(f"     max_ctx       : {pf['max_ctx']:,} chars")
            print(f"     max_chunks    : {pf['max_chunks']}")
            print(f"     param. tokens : {pf['param_tokens']}")
            print(f"     temperature   : "
                  f"{'admitida' if pf['admite_temperature'] else 'NO admitida'}")
            if pf.get("nota"):
                print(f"     ⚠️  {pf['nota']}")
        print(f"\n{_sep}\n")
        return

    # ── PRE-FLIGHT: validar API key antes de iniciar el pipeline ──────────────
    # ── Catálogo de motores de datos (no requiere API) ───────────────────────
    if args.listar_motores:
        from modulos.motores_datos import describir_motores, REGISTRO_MOTORES
        print("\n" + "═" * 70)
        print("  🔧 MOTOR DE DATA — PRUEBAS DE CALIDAD DISPONIBLES")
        print("═" * 70)
        print(f"\n  Total: {len(REGISTRO_MOTORES)} pruebas\n")
        print(describir_motores())
        print("\n" + "═" * 70)
        print("  Uso en ControlesData.xlsx:")
        print("    USA_MOTOR_DATA=1  +  TIPO_MOTOR=<nombre>  +  columnas requeridas")
        print("═" * 70 + "\n")
        return

    # ── Pre-vuelo de la evidencia (coste 0) ───────────────────────────────────
    # Va ANTES del PRE-FLIGHT de credencial: comprobar qué evidencia hay no
    # necesita API, y es justo lo que se quiere poder hacer sin gastar —incluso
    # antes de tener la clave.
    #
    # Lee los documentos de verdad (única forma de saber si un PDF tiene texto),
    # pero a través del caché: la corrida real posterior reutiliza esas lecturas.
    # El pre-vuelo ADELANTA trabajo, no lo duplica.
    if args.prevuelo:
        from modulos.prevuelo import ejecutar_prevuelo, formatear
        _inf = ejecutar_prevuelo()
        print(formatear(_inf))
        if args.perfilar_datasets:
            from modulos.perfilador_datasets import perfilar_carpeta
            from motor.Mx_00_CargaRutas import RUTAS as _R
            _dir_ds = Path(args.datasets) if args.datasets else \
                (Path(_R["inputs"]["calidad_datos"]) / "datasets")
            _perfil = perfilar_carpeta(_dir_ds)
            print(_perfil if _perfil else f"  ℹ️  Sin datasets en {_dir_ds}\n")
        # Código 1 solo si hay BLOQUEANTES: un ámbito sin evidencia puntuará
        # 0.0 y esa nota se le atribuye al validado. Los ficheros ilegibles son
        # graves pero el resto del ámbito puede sostener la evaluación, así que
        # no bloquean: se reportan y el operador decide.
        sys.exit(1 if _inf.hay_bloqueantes else 0)

    # ── Inventario de revisión de código (coste 0) ────────────────────────────
    # `--revisar-codigo --dry-run` es el único uso que NO exige --titulo/--tier:
    # es la comprobación que hay que poder hacer ANTES de decidir si se lanza la
    # corrida, y pedir el título para contar ficheros sería fricción sin motivo.
    # Va antes del PRE-FLIGHT porque no llama al modelo.
    if args.revisar_codigo and args.dry_run:
        from modulos.revision_codigo import (
            descubrir_modulos, inventario, formatear_inventario,
        )
        # RUTAS["inputs"] ya viene reapuntado si se pasó --raiz-evidencia: este
        # bloque se ejecuta DESPUÉS de _aplicar_raiz_evidencia(), así que el
        # inventario describe el árbol del modelo correcto y no el del proyecto.
        from motor.Mx_00_CargaRutas import RUTAS as _RUTAS
        _raiz_codigo = Path(_RUTAS["inputs"]["implementacion"])
        if not _raiz_codigo.is_dir():
            print(f"\n  ❌ No existe la carpeta de implementación: {_raiz_codigo}\n")
            sys.exit(1)
        _mods = descubrir_modulos(_raiz_codigo)
        if not _mods:
            print(f"\n  ⚠️  Sin módulos de código (.py/.ipynb) en {_raiz_codigo}")
            print("     Coloca ahí el código del modelo, con sus subcarpetas "
                  "(libs/, notebooks/…).\n")
            return
        # El manual se mide para que el coste incluya su repetición en cada
        # llamada: es el factor que domina cuando hay muchos módulos.
        _chars_manual = 0
        _dir_manual = Path(_RUTAS["inputs"]["doc_modelamiento"])
        if _dir_manual.is_dir():
            from motor.Mx_01_LecturaEvidencias import leer_carpeta as _leer_c
            _chars_manual = sum(d.get("chars_totales", 0) for d in _leer_c(_dir_manual))
        print(formatear_inventario(
            inventario(_mods, raiz=_raiz_codigo, chars_manual=_chars_manual)))
        print("  Para ejecutar la revisión de verdad, quita --dry-run y añade "
              "--titulo/--tier.\n")
        return

    if not args.estadisticafeedback and not args.limpiar_cache and not args.cache_stats \
            and not args.listar_motores and not args.historial_validaciones \
            and not args.verificar_cadena and not args.verificar_evidencia \
            and not args.verificar_conexion_azure and not args.prevuelo \
            and not args.comparar \
            and not (args.explicar_modelo and args.dry_run) \
            and not (args.revisar_codigo and args.dry_run) \
            and not (args.convertir_excel and args.sin_llm) \
            and not (args.controles_a_notebook and args.sin_llm):
        # [P0.4] La última condición faltaba: `--controles-a-notebook --sin-llm`
        # no usa el modelo, pero exigía credencial igual y moría en el
        # PRE-FLIGHT. La exención existía para `--convertir-excel --sin-llm` y
        # nadie añadió la simétrica.
        print("  🔑 Verificando API key...", end=" ", flush=True)
        try:
            from config import get_cliente_ia
            cliente_test = get_cliente_ia()
            print("✅ OK")
        except ValueError as e:
            # Clave inválida, vacía o placeholder
            print("❌\n")
            print(str(e))
            sys.exit(1)
        except Exception as e:
            # [AUDIT-FIX] Antes: `err_str = str(e)`. El 401 real venía envuelto
            # en un RuntimeError genérico de config/ia.py, así que la firma de
            # autenticación no aparecía en el mensaje superficial y la clave
            # rechazada se clasificaba como "error de red → continuar". Se
            # recorre toda la cadena de causas.
            _cadena, _cur = [], e
            while _cur is not None and len(_cadena) < 10:
                _cadena.append(str(_cur))
                _cur = _cur.__cause__ or _cur.__context__
            err_str = " | ".join(_cadena)
            if "401" in err_str or "authentication" in err_str.lower():
                # [GENERICO] El proveedor sale de la ficha activa. Antes este
                # mensaje decía «rechazada por Anthropic» y remitía a su consola
                # SIEMPRE: con Azure configurado, mandaba al operador a revisar
                # una credencial que no era la que estaba fallando.
                from config.ia import metadatos_proveedor
                _meta = metadatos_proveedor()
                print("❌\n")
                print(
                    f"❌ API key rechazada por {_meta['nombre']} (Error 401).\n\n"
                    f"   La clave configurada no es válida.\n"
                    f"   Verifica en: {_meta['consola']}\n"
                    f"   y actualiza {_meta['var_clave']} en el archivo .env\n"
                )
                sys.exit(1)
            # [AUDIT-FIX] Antes: «otro error de red → advertir pero continuar».
            # No servía de nada. El PRE-FLIGHT ya se salta para todos los modos
            # que funcionan sin API (--estadisticafeedback, --limpiar-cache,
            # --cache-stats, --listar-motores, --explicar-modelo --dry-run,
            # --convertir-excel --sin-llm), así que cualquier ejecución que
            # llegue hasta aquí NECESITA la API. Continuar solo aplazaba la
            # muerte hasta la instanciación del chunker, y allí salía como dos
            # tracebacks crudos encadenados en vez de un mensaje accionable.
            # Reproducido apuntando ANTHROPIC_BASE_URL a un host no enrutable.
            from config.ia import metadatos_proveedor
            _meta = metadatos_proveedor()
            _vars = "\n".join(f"     · {v}" for v in _meta["vars_revisar"])
            print("❌\n")
            print(
                f"❌ No hay conexión con el proveedor de IA "
                f"({_meta['nombre']}).\n\n"
                f"   Detalle: {e}\n\n"
                f"   Comprueba tu conexión a internet o el proxy corporativo,\n"
                f"   y la configuración del proveedor activo:\n{_vars}\n\n"
                f"   Los modos que no requieren API siguen disponibles:\n"
                f"   --cache-stats, --listar-motores, --estadisticafeedback,\n"
                f"   --explicar-modelo --dry-run, --convertir-excel --sin-llm,\n"
                f"   --revisar-codigo --dry-run\n"
            )
            # [HTTPS-FIX] Mismo diagnóstico que en la prueba de humo: si la
            # firma del error es de TLS o proxy, el problema no es la red ni la
            # credencial, y decirlo aquí ahorra la mañana de buscar en el sitio
            # equivocado.
            if any(_s in err_str.lower() for _s in
                   ("certificate", "ssl", "tls", "proxy", "handshake",
                    "self signed", "verify failed")):
                from config.ia import diagnostico_https
                print(diagnostico_https())
            sys.exit(1)

    # ── Explicador de modelos ────────────────────────────────────────────────
    # Flujo reutilizable: no sabe nada de ningún modelo concreto. Para
    # documentar otro basta con dejar su evidencia en inputs/ y cambiar el
    # nombre del flag.
    if args.explicar_modelo:
        from modulos.explicador_modelo import ExplicadorModelo

        _excluir = [x.strip() for x in (args.excluir or "").split(",") if x.strip()]

        # El chunker permite documentar manuales largos sin truncarlos, y su
        # caché evita volver a pagar el resumen en cada regeneración.
        _chunker = None
        if not args.dry_run:
            # [AUDIT-FIX crítico] Aquí había `from modulos.chunker import
            # ChunkerService`. Al ser un import DENTRO de main(), Python marca
            # `ChunkerService` como local de TODA la función y ensombrece el
            # import de módulo (línea 51). Resultado: cuando no se tomaba esta
            # rama, el pipeline principal moría en su propia línea 465 con
            # "local variable 'ChunkerService' referenced before assignment".
            # Es decir, la ruta insignia (--titulo/--tier) estaba muerta al
            # 100% y el mensaje culpaba al chunker en vez de al import.
            from config import get_cliente_ia as _get_ia
            _chunker = ChunkerService(
                cliente_ia=_get_ia(),
                cache_dir=CACHE_DIR if cache_activo else None,
            )

        # Ya resuelta y validada arriba, en un único punto para todos los modos.
        _raiz = _raiz_ev

        _explicador = ExplicadorModelo(
            cliente_ia=(None if args.dry_run else _get_ia()),
            base_dir=_raiz,
            chunker=_chunker,
            excluir=_excluir,
            solo_coincidentes=args.solo_coincidentes,
        )
        _salida = OUTPUTS_DIR / datetime.now().strftime("%Y-%m-%d")
        try:
            _explicador.generar(args.explicar_modelo, _salida, dry_run=args.dry_run)
        except ValueError as e:
            print(f"\n  ❌ {e}\n")
            sys.exit(1)
        return

    # ── Comandos de gestión del caché ─────────────────────────────────────────
    if args.limpiar_cache:
        cache_mgr = inicializar_cache(cache_dir=CACHE_DIR, enabled=True)
        n = len(cache_mgr._data)
        cache_mgr.limpiar_todo()
        print(f"  🧹 Caché de documentos limpiado: {n} entradas eliminadas.")
        # [AUDIT-FIX] Antes solo se vaciaba document_cache.json. Los RESÚMENES
        # de chunking viven en otro fichero y sobrevivían a la limpieza, así que
        # una entrada con cobertura falsa persistía después de «limpiar el
        # caché». Se encontró una del 1,2% conviviendo con la buena del 100%
        # sobre el mismo manual.
        n_res = ChunkerService.limpiar_cache_resumenes(CACHE_DIR)
        print(f"  🧹 Caché de resúmenes limpiado: {n_res} entradas eliminadas.")
        return

    if args.cache_stats:
        cache_mgr = inicializar_cache(cache_dir=CACHE_DIR, enabled=True)
        stats = cache_mgr.estadisticas()
        print("\n" + "═" * 60)
        print("  📦 ESTADÍSTICAS DEL CACHÉ DE DOCUMENTOS")
        print("═" * 60)
        ac = stats["acumulado"]
        print(f"  Total entradas en caché : {ac['total_entradas']}")
        print(f"  Hits históricos totales : {ac['hits_historicos']}")
        print(f"  Distribución por tipo   :")
        for tipo, n in sorted(ac["por_tipo"].items()):
            print(f"    {tipo:8s} → {n} archivos")
        print(f"\n  Archivo: {stats['archivo_cache']}")
        return

    # ═════════════════════════════════════════════════════════════════════════
    # FASE 1: EXCEL → NOTEBOOK (con VBA, refs externas, auto-validación)
    # ═════════════════════════════════════════════════════════════════════════
    if args.convertir_excel:
        from modulos.excel_a_notebook import generar_notebook_de_carpeta
        carpeta_in  = Path(args.convertir_excel)
        fecha       = datetime.now().strftime("%Y-%m-%d")
        carpeta_out = OUTPUTS_DIR / fecha / "notebooks"
        try:
            generados = generar_notebook_de_carpeta(
                carpeta_excels=carpeta_in,
                carpeta_salida=carpeta_out,
                usar_llm=not args.sin_llm,
                auto_validar=not args.sin_validacion,
            )
        except Exception as e:
            print(f"  ❌ Error: {e}")
            import traceback; traceback.print_exc()
            sys.exit(1)
        if not generados:
            sys.exit(1)
        return

    # ═════════════════════════════════════════════════════════════════════════
    # MODO: DOCUMENTO DE CONTROLES → NOTEBOOK + ANÁLISIS DE BRECHAS
    # ═════════════════════════════════════════════════════════════════════════
    if args.controles_a_notebook:
        from modulos.controles_a_notebook import generar_notebook_controles
        doc = Path(args.controles_a_notebook)
        if not doc.exists():
            print(f"  ❌ No existe el documento: {doc}")
            sys.exit(1)

        excel = Path(args.excel) if args.excel else CONTROLES_DATA_PATH
        if not excel.exists():
            print(f"  ⚠️  No se encontró el Excel de controles ({excel}).")
            print("     Se generará el notebook sin análisis de brechas.")
            excel = None

        datasets_dir = Path(args.datasets) if args.datasets else \
            (BASE_DIR / "inputs" / "calidad_datos" / "datasets")

        fecha = datetime.now().strftime("%Y-%m-%d")
        salida = OUTPUTS_DIR / fecha / "controles"
        try:
            _out, brechas = generar_notebook_controles(
                ruta_documento=doc,
                ruta_excel=excel,
                carpeta_salida=salida,
                carpeta_datasets=datasets_dir,
                usar_llm=not args.sin_llm,
            )
            m = brechas["metricas"]
            if m["n_solo_doc"]:
                print(f"  ⚠️  HALLAZGO: {m['n_solo_doc']} control(es) documentado(s) "
                      f"pero NO ejecutado(s).")
            if m["n_solo_excel"]:
                print(f"  ⚠️  HALLAZGO: {m['n_solo_excel']} control(es) ejecutado(s) "
                      f"pero NO documentado(s).")
        except Exception as e:
            print(f"  ❌ Error: {e}")
            import traceback; traceback.print_exc()
            sys.exit(1)
        return

    # ═════════════════════════════════════════════════════════════════════════
    # MODO 1: Estadísticas
    # ═════════════════════════════════════════════════════════════════════════
    if args.estadisticafeedback:
        modo_estadistica_feedback()
        return

    # ═════════════════════════════════════════════════════════════════════════
    # MODO 2: Pipeline por CONTROL (Calidad de Datos)
    # ═════════════════════════════════════════════════════════════════════════
    if args.control:
        if not args.titulo:
            parser.error("--titulo es obligatorio")
        if not args.tier:
            parser.error("--tier es obligatorio (1, 2, 3, 4)")
        if normalizar_tier(args.tier) is None:
            parser.error(f"--tier {args.tier!r} no es un tier válido. "
                         f"Valores admitidos: 1, 2, 3, 4 (o I, II, III, IV).")
        if not args.excel:
            parser.error("--excel es obligatorio (ruta al Excel de controles)")
        
        excel_path = Path(args.excel)
        if not excel_path.exists():
            print(f"  ❌ Error: {args.excel} no encontrado")
            sys.exit(1)
        
        fecha_informe = datetime.now().strftime("%Y-%m-%d")
        
        print("\n" + "═" * 70)
        print("  🔍 AGENTE VIRF — PIPELINE CALIDAD DE DATOS (POR CONTROL)")
        print(f"  Modelo: {args.titulo}")
        print(f"  Tier:   {args.tier}")
        print(f"  Modo:   {'PRODUCCIÓN (--prdc)' if args.prdc else 'PRE-PRODUCCIÓN'}")
        print("═" * 70 + "\n")
        
        # ── [DATASETS-FIX] Cargar los datasets para el motor de datos ────────
        # Antes se pasaba datasets_dict=None SIEMPRE, por lo que los controles
        # con USA_MOTOR_DATA=1 nunca ejecutaban su prueba: el Excel declaraba
        # DATASET='data_subset' y nadie lo cargaba.
        from modulos.motores_datos import cargar_datasets
        datasets_dir = Path(args.datasets) if args.datasets else \
            (BASE_DIR / "inputs" / "calidad_datos" / "datasets")
        datasets = cargar_datasets(datasets_dir)
        if datasets:
            print(f"  📊 Datasets cargados desde {datasets_dir.name}/: {list(datasets)}")
            for _n, _d in datasets.items():
                print(f"       {_n}: {_d.shape[0]:,} filas x {_d.shape[1]} columnas")
        else:
            print(f"  ℹ️  Sin datasets en {datasets_dir}")
            print("     Los controles con USA_MOTOR_DATA=1 no podrán ejecutarse.")

        try:
            resultado = orquestar_pipeline_virf(
                base_project_path=str(_raiz_ev),
                excel_controles=str(excel_path),
                nombre_modelo=args.titulo,
                fecha_informe=fecha_informe,
                tier=str(args.tier),
                datasets_dict=datasets or None,
                filtro_controles=None,
            )
            
            _confiable = resultado.get("dictamen_confiable", False)
            _icono = "✅" if _confiable else "⚠️"
            print("\n" + "═" * 70)
            print(f"  {_icono} PIPELINE CALIDAD DE DATOS COMPLETADO")
            print("═" * 70)
            print(f"\n  📊 RESULTADOS:")
            print(f"    • Controles evaluados: {resultado.get('controles_ok', 0)}/{resultado.get('total_controles', 0)}")
            print(f"    • Controles con error: {resultado.get('controles_error', 0)}")
            # [AUDIT-FIX] Se muestra aparte: antes se sumaba a "con error" y una
            # corrida sin documentos parecía una corrida rota.
            if resultado.get("controles_sin_evidencia"):
                print(f"    • Sin evidencia:       {resultado['controles_sin_evidencia']}"
                      f"  (falta documentación, no es un fallo)")
            print(f"    • Hallazgos críticos:  {resultado['hallazgos_criticos']}")
            print(f"    • Estado:              {resultado['estado']}")
            print(f"    • Dictamen confiable:  {_confiable}")
            if not _confiable:
                print(f"\n  ⚠️  NO emitir dictamen: la evaluación está incompleta.")
                print(f"     Revisa el JSON para ver qué controles fallaron y por qué.")
            print(f"\n  📁 ARCHIVOS GENERADOS:")
            print(f"    • JSON:    {Path(resultado['ruta_json']).name}")
            if resultado.get("ruta_word"):
                print(f"    • Word:    {Path(resultado['ruta_word']).name}")
            print(f"    • Carpeta: {resultado['ruta_outputs']}")
            print("═" * 70 + "\n")
        
        except Exception as e:
            print(f"  ❌ Error en pipeline: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
        
        return
    
    # ═════════════════════════════════════════════════════════════════════════
    # MODO 3: Pipeline COMPLETO (Estandares_VIRF.xlsx + ControlesData.xlsx)
    # ═════════════════════════════════════════════════════════════════════════
    if not args.titulo:
        parser.error("--titulo es obligatorio")
    if not args.tier:
        parser.error("--tier es obligatorio (1, 2, 3, 4)")
    # [AUDIT-FIX] Un tier inexistente desactivaba el filtro en silencio y
    # evaluaba TODAS las actividades. Se rechaza antes de gastar en la API.
    if normalizar_tier(args.tier) is None:
        parser.error(f"--tier {args.tier!r} no es un tier válido. "
                     f"Valores admitidos: 1, 2, 3, 4 (o I, II, III, IV).")

    if not ESTANDARES_PATH.exists():
        print(f"  ❌ Error: {ESTANDARES_PATH} no encontrado")
        sys.exit(1)

    # ── [CUMPLIMIENTO 2.1] Validador responsable, ANTES de gastar ────────────
    # Se resuelve aquí y no al final por dos razones. La primera es económica:
    # descubrir que falta la firma después de pagar la corrida completa obliga a
    # repetirla. La segunda es de fondo: un informe de producción sin
    # responsable humano identificable no acredita validación independiente
    # (SR 11-7 §V), así que no debe llegar a generarse.
    # ── [HTTPS-FIX] Un entregable no se emite sobre un canal sin verificar ───
    # `VIRF_TLS_INSECURE=1` existe para diagnosticar en 10 segundos si el
    # problema es la CA corporativa. Olvidarlo encendido significa que la
    # credencial y la evidencia íntegra del modelo viajaron por un canal
    # interceptable — y el informe no puede declarar la cadena de custodia que
    # declara. Se bloquea en producción, y solo ahí: en pre-producción se avisa.
    from config.parametros import TLS_INSECURE as _TLS_INSEGURO
    if args.prdc and _TLS_INSEGURO:
        print("\n  ❌ No se puede emitir un informe de PRODUCCIÓN con "
              "VIRF_TLS_INSECURE=1.\n")
        print("     La verificación TLS está desactivada: la credencial y la "
              "evidencia\n     del modelo viajan por un canal interceptable, y "
              "la cadena de custodia\n     que el informe declara no sería "
              "defendible ante un auditor.\n")
        print("     Pon VIRF_TLS_INSECURE=0 y configura VIRF_CA_BUNDLE con el "
              "certificado\n     de la CA corporativa. "
              "Ver `python agente.py --verificar-conexion-azure`.\n")
        sys.exit(1)

    _identidad = None
    _aviso_segregacion = None
    if args.prdc:
        from modulos.validador_humano import (
            solicitar_identidad, IdentidadRequerida, aviso_segunda_revision,
        )
        try:
            _identidad = solicitar_identidad(args.validador, args.cargo)
        except IdentidadRequerida as exc:
            print(f"\n  ❌ {exc}\n")
            sys.exit(1)
        _aviso_segregacion = aviso_segunda_revision(args.titulo, _identidad["validador"])
        print(f"  ✍️  Validador responsable: {_identidad['validador']} "
              f"({_identidad['cargo']})")
        if _aviso_segregacion:
            print(f"  {_aviso_segregacion}")
            _identidad["aviso_segregacion"] = _aviso_segregacion

    fecha_informe = datetime.now().strftime("%Y-%m-%d")
    tier_str = str(args.tier)

    print("\n" + "═" * 70)
    print("  🔍 AGENTE VIRF — PIPELINE TODOS LOS ÁMBITOS")
    print(f"  Modelo: {args.titulo}")
    print(f"  Tier:   {tier_str}")
    print(f"  Modo:   {'PRODUCCIÓN (--prdc)' if args.prdc else 'PRE-PRODUCCIÓN'}")
    print("═" * 70 + "\n")

    try:
        # 1. Cargar estándares VIRF (todos los ámbitos filtrados por tier)
        print("  📖 Cargando Estandares_VIRF.xlsx...")
        ambitos_data = leer_estandares_virf(tier_str)
        if not ambitos_data:
            print("  ❌ No se pudieron cargar los estándares VIRF. Verificar estructura del Excel.")
            sys.exit(1)

        # 2. Cargar todos los documentos de evidencia
        print("  📂 Cargando documentos de evidencia...")
        todos_inputs = cargar_todos_inputs()

        # 2a. Perfil de los datasets como evidencia derivada ──────────────────
        # `datasets/` está excluido de la evidencia documental a propósito: un
        # solo .csv consumía los 15.000 chars de contexto y expulsaba al manual.
        # Pero el ESQUEMA sí es evidencia: es lo que permite comprobar si las
        # variables que el manual declara existen de verdad, con qué tipo y con
        # cuántos nulos. El perfil son ~1.500 chars, no vuelca ninguna fila, y
        # entra en la carpeta 'calidad_datos' porque ese es su ámbito natural.
        # RUTAS["inputs"] ya viene reapuntado por --raiz-evidencia, así que el
        # default de datasets sigue al modelo y no a la raíz del proyecto.
        from motor.Mx_00_CargaRutas import RUTAS as _RUTAS_PIPE
        _RUTAS_INPUTS = _RUTAS_PIPE["inputs"]

        _perfil_datasets = None
        if args.perfilar_datasets:
            from modulos.perfilador_datasets import documento_perfil
            _dir_ds = Path(args.datasets) if args.datasets else \
                (Path(_RUTAS_INPUTS["calidad_datos"]) / "datasets")
            _perfil_datasets = documento_perfil(_dir_ds)
            if _perfil_datasets:
                todos_inputs.setdefault("calidad_datos", []).append(_perfil_datasets)
                print(f"  📊 Perfil de datasets añadido a la evidencia "
                      f"({_perfil_datasets['chars_totales']:,} chars, sin datos crudos)")
            else:
                print(f"  ℹ️  Sin datasets perfilables en {_dir_ds}")

        # 2b. [v20] Aplicar chunking inteligente en lote (capa de pipeline)
        #     ChunkerService recibe el cliente IA ya validado — separación de capas.
        from config import get_cliente_ia as _get_ia
        # [COSTE-FIX] Se pasa CACHE_DIR para reutilizar los resúmenes entre
        # corridas: resumir un manual de 305 págs cuesta ~$0.90 y se repetía
        # íntegro aunque el documento no hubiera cambiado.
        _chunker = ChunkerService(
            cliente_ia=_get_ia(),
            cache_dir=CACHE_DIR if cache_activo else None,
        )
        todos_inputs = {
            ambito: _chunker.procesar_lote(docs, verbose=False)
            for ambito, docs in todos_inputs.items()
        }

        # 3. Preparar directorio de salida
        outputs_dir = OUTPUTS_DIR / fecha_informe
        outputs_dir.mkdir(parents=True, exist_ok=True)
        # Nombre de fichero saneado, UNA sola vez. `--titulo` llega de la línea
        # de comandos y no puede interpolarse crudo en una ruta (path traversal);
        # se resuelve aquí porque lo usan tanto el JSON de resultados como el
        # informe de revisión de código, y dos saneos independientes acabarían
        # divergiendo.
        from config.rutas import nombre_seguro
        nombre_seguro_titulo = nombre_seguro(args.titulo)

        # 4. Evaluar cada ámbito
        resultados_ambitos = {}
        scores_ambitos = {}
        total_actividades = 0
        hallazgos_globales: list = []  # [v18] memoria inter-ámbito

        for ambito, actividades in ambitos_data.items():
            acts_requeridas = [a for a in actividades if a.get("requerida", True)]
            if not acts_requeridas:
                continue

            print(f"\n🔍 Evaluando {ambito} ({len(acts_requeridas)} actividades)...")
            total_actividades += len(acts_requeridas)

            docs_ambito = inputs_para_dimension(todos_inputs, ambito)

            # [D8-FIX] El límite anterior de [:5] descartaba evidencia silenciosamente.
            # Ahora: todos los documentos se incluyen hasta MAX_CHARS_DOC total.
            # Se loguea cuántos documentos y chars se incluyen/omiten.
            MAX_DOCS_AMBITO = _MAX_DOCS_AMBITO or len(docs_ambito)
            docs_incluidos = docs_ambito[:MAX_DOCS_AMBITO]
            if len(docs_ambito) > len(docs_incluidos):
                print(f"  ⚠ [{ambito}] {len(docs_ambito) - len(docs_incluidos)} doc(s) omitidos "
                      f"(VIRF_MAX_DOCS_AMBITO={MAX_DOCS_AMBITO}). "
                      f"Ajusta la variable de entorno para incluirlos.")

            contexto_partes = []
            chars_acumulados = 0
            MAX_CTX_TOTAL = _MAX_CTX
            # [COBERTURA-FIX] Propagar los metadatos de cobertura del chunker.
            # Antes se leían solo 'contenido' y 'nombre': cobertura_pct, n_chunks
            # y modo_cobertura se calculaban en chunker.py y MORÍAN ahí. Para un
            # manual de 300 páginas el agente no sabía qué fracción había visto.
            docs_omitidos_ctx = 0
            cobertura_docs = []          # (nombre, cobertura_pct, modo)
            nombres_omitidos = []

            # ── [CONTEXTO-FIX 2026-07-30] Llenar el presupuesto, no abandonarlo
            #
            # Aquí había un `break`: en cuanto UN documento no cabía, se
            # descartaban TODOS los siguientes — incluidos los pequeños que sí
            # habrían entrado. Medido en una corrida real de banca:
            #
            #     Contexto saturado: 11.835 / 15.000 chars — 22 doc(s) omitidos
            #
            # 3.165 caracteres libres y 22 documentos fuera. El evaluador juzgó
            # el ámbito sin evidencia que cabía de sobra, y la cobertura
            # declarada bajó por un fallo del algoritmo, no por falta de sitio.
            #
            # Con `continue` se sigue probando: un documento grande que no entra
            # ya no bloquea a los que vienen detrás.
            #
            # Se ordena de MENOR a MAYOR tamaño para maximizar cuántos caben.
            # No es ranking semántico —eso es trabajo mayor, ver ROADMAP P2— pero
            # convierte «primero los que llegaron» en «tantos como quepan», que
            # con evidencia heterogénea cambia mucho el resultado.
            _por_tamano = sorted(
                docs_incluidos,
                key=lambda x: len(x.get("contenido", "") or ""))

            for d in _por_tamano:
                contenido = d.get("contenido", "") or ""
                if chars_acumulados + len(contenido) > MAX_CTX_TOTAL and contexto_partes:
                    nombres_omitidos.append(d.get("nombre", "?"))
                    continue          # ← antes: break
                contexto_partes.append(f"[{d['nombre']}]\n{contenido}")
                chars_acumulados += len(contenido)
                cobertura_docs.append((
                    d.get("nombre", "?"),
                    float(d.get("cobertura_pct", 100.0)),
                    d.get("modo_cobertura", "directo"),
                    int(d.get("chars_totales", len(contenido)) or len(contenido)),
                ))

            docs_omitidos_ctx = len(nombres_omitidos)
            if docs_omitidos_ctx:
                _libres = MAX_CTX_TOTAL - chars_acumulados
                print(f"  ℹ [{ambito}] Contexto lleno: {chars_acumulados:,}/"
                      f"{MAX_CTX_TOTAL:,} chars ({_libres:,} libres). "
                      f"{docs_omitidos_ctx} doc(s) no cupieron:")
                for _n in nombres_omitidos[:5]:
                    print(f"       · {_n}")
                if docs_omitidos_ctx > 5:
                    print(f"       … y {docs_omitidos_ctx - 5} más")
                print(f"     Cuentan como 0% en la cobertura del ámbito. "
                      f"Sube VIRF_MAX_CTX si tu modelo tiene ventana de sobra.")
            contexto = "\n".join(contexto_partes)

            # ── Cobertura documental del ámbito ───────────────────────────────
            # [AUDIT-FIX] Dos defectos que inflaban esta cifra:
            #
            #  1. El comentario decía "ponderada por tamaño" y el código hacía
            #     una MEDIA ARITMÉTICA SIMPLE. Un anexo de 1 página al 100% y un
            #     manual de 300 páginas al 30% daban 65%, cuando lo que el
            #     evaluador realmente vio era ~30%.
            #  2. Los documentos descartados por saturación de contexto (el
            #     `break` de arriba) no entraban en el cálculo, así que 3 docs
            #     completos de 10 daban 100%.
            #
            # Ahora se pondera por el tamaño ORIGINAL de cada documento y los
            # descartados cuentan como 0%: es la fracción real de la evidencia
            # del ámbito que llegó al modelo. Esta cifra viaja al prompt de
            # evaluación, así que inflarla es hacerle creer que vio más de lo
            # que vio.
            _chars_vistos = sum(c * pct / 100.0 for _, pct, _, c in cobertura_docs)
            _chars_totales_ambito = sum(
                int(d.get("chars_totales", len(d.get("contenido", "") or "")) or 0)
                for d in docs_incluidos
            )
            if _chars_totales_ambito > 0:
                cobertura_ambito = round(_chars_vistos / _chars_totales_ambito * 100, 1)
            else:
                cobertura_ambito = 0.0

            print(f"  📄 [{ambito}] {len(contexto_partes)}/{len(docs_incluidos)} doc(s) "
                  f"en contexto — {chars_acumulados:,} chars — "
                  f"cobertura documental {cobertura_ambito}%")
            parciales = [(n, c, m, ch) for n, c, m, ch in cobertura_docs if c < 100.0]
            for _n, _c, _m, _ch in parciales:
                print(f"      ⚠ '{_n}': cobertura {_c}% ({_m}, {_ch:,} chars)")
            if docs_omitidos_ctx:
                print(f"      ⚠ {docs_omitidos_ctx} doc(s) NO entraron en contexto "
                      f"→ cuentan como 0% en la cobertura del ámbito")

            # [D3-FIX] Rechazar evaluación si el ámbito no tiene documentos.
            # Un agente evaluando sobre el vacío genera alucinaciones plausibles
            # que un auditor junior podría tomar como hallazgos verificados.
            if not docs_incluidos or chars_acumulados == 0:
                print(f"  ✗ [{ambito}] SIN DOCUMENTOS — evaluación rechazada.")
                print(f"    Agrega archivos en las carpetas correspondientes a este ámbito.")
                print(f"    El agente NO evalúa sobre el vacío (D3-FIX: anti-alucinación).")
                resultados_ambitos[ambito] = [{
                    "puntaje":               None,
                    "concepto":              "EVALUACIÓN NO REALIZADA — Sin evidencia",
                    "observacion":           (
                        f"El ámbito '{ambito}' no tiene documentos de entrada. "
                        "No es posible realizar una evaluación válida. "
                        "Por favor proporciona los documentos correspondientes antes de ejecutar."
                    ),
                    "evidencia_encontrada":  "",
                    "preguntas_pendientes":  [
                        f"¿Dónde se encuentran los documentos de evidencia para el ámbito '{ambito}'?"
                    ],
                    "recomendacion":         "Proporcionar los documentos de evidencia antes de la evaluación.",
                    "actividad":             "N/A — ámbito sin evidencia",
                    "control":               "N/A",
                    "sin_evidencia":         True,
                }]
                scores_ambitos[ambito] = None  # null en el JSON, no score arbitrario
                continue

            evals = evaluar_ambito_completo(
                ambito          = ambito,
                actividades     = acts_requeridas,
                contexto        = contexto,
                titulo_modelo   = args.titulo,
                modo_preprdc    = not args.prdc,
                contexto_global = hallazgos_globales,  # [v18] pasar memoria acumulada
                cobertura_docs  = cobertura_ambito,    # [COBERTURA-FIX] % real del chunker
            )

            resultados_ambitos[ambito] = evals
            scores_ambitos[ambito]     = calcular_score_ambito(evals)

            # [v18] Acumular hallazgos para los siguientes ámbitos
            for ev in evals:
                hallazgos_globales.append({
                    "ambito":     ambito,
                    "actividad":  ev.get("actividad", "")[:60],
                    "puntaje":    ev.get("puntaje"),
                    "observacion": ev.get("observacion", "")[:100],
                })

        # 5. ADICIONAL: controles de Calidad de Datos desde ControlesData.xlsx
        resultados_cdd = {}
        if CONTROLES_DATA_PATH.exists():
            print("\n🔍 Evaluando controles adicionales de CALIDAD DE DATOS (ControlesData.xlsx)...")
            resultados_cdd = evaluar_todos_controles(
                excel_controles=str(CONTROLES_DATA_PATH),
                base_project_path=str(_raiz_ev),
                nombre_modelo=args.titulo,
                tier=tier_str,
            )
        else:
            print(f"  ℹ️  ControlesData.xlsx no encontrado en {CONTROLES_DATA_PATH}, omitiendo.")

        # 5b. Fusionar controles CDD con ámbito "Calidad de datos" (para Word conjunto)
        if resultados_cdd and resultados_cdd.get("resultados_por_control"):
            evals_cdd = []
            for ctrl_id, res in resultados_cdd["resultados_por_control"].items():
                estado         = res.get("estado", "ERROR")
                revision       = res.get("revision", "")
                hallazgos      = res.get("hallazgos") or []
                prompt_control = res.get("prompt_control", "")
                tipo_control   = res.get("tipo_control", "generico")
                tasa_error     = res.get("tasa_error", None)  # e.g. 0.001 = 0.1%

                # [D7-FIX] Calibración por criticidad y tasa de error real.
                # Antes: OK→4, ADVERTENCIA/ALERTA→3, ERROR→1 (hardcodeado, sin matices).
                # Ahora: el puntaje depende del estado Y de la tasa de hallazgos cuantificada.
                if estado == "OK":
                    puntaje = 5  # sin hallazgos → cumple plenamente
                elif estado in ("ADVERTENCIA", "ALERTA"):
                    # Calibrar por tasa de error si está disponible
                    if tasa_error is not None:
                        if tasa_error < 0.005:    # < 0.5% → obs. menores
                            puntaje = 4
                        elif tasa_error < 0.02:   # 0.5–2% → cumple parcialmente
                            puntaje = 3
                        elif tasa_error < 0.10:   # 2–10% → obs. críticas
                            puntaje = 2
                        else:                      # > 10% → no cumple
                            puntaje = 1
                    else:
                        # Sin tasa cuantificada: ADVERTENCIA=3, ALERTA=2
                        puntaje = 3 if estado == "ADVERTENCIA" else 2
                elif estado == "ERROR":
                    puntaje = 1
                else:
                    puntaje = 1  # desconocido → conservador

                # [D7-FIX] Registrar en log el criterio aplicado
                print(f"      CDD [{ctrl_id}] estado={estado} tasa={tasa_error} → puntaje={puntaje}")

                obs_parts = []
                for h in hallazgos[:5]:
                    obs_parts.append(h.get("descripcion", str(h)) if isinstance(h, dict) else str(h))
                observacion = " | ".join(obs_parts) if obs_parts else (
                    revision if revision and not revision.lower().startswith("error") else ""
                )
                concepto = (
                    revision if revision and not revision.lower().startswith("error")
                    else f"Control automático de calidad de datos: {ctrl_id}"
                )

                # Nombre de actividad: ID + resumen del prompt (primeras 120 chars)
                resumen_prompt = prompt_control[:120].strip()
                if len(prompt_control) > 120:
                    resumen_prompt += "..."
                actividad_label = f"{ctrl_id} — {resumen_prompt}" if resumen_prompt else ctrl_id

                evals_cdd.append({
                    "puntaje":              puntaje,
                    "concepto":             concepto,
                    "observacion":          observacion,
                    "evidencia_encontrada": "",
                    "preguntas_pendientes": [],
                    "recomendacion":        "",
                    "actividad":            actividad_label,
                    "control":              "Controles Automáticos de Calidad de Datos",
                    "prompt_sha256":        res.get("prompt_sha256"),
                })

            ambito_cdd = "Calidad de datos"
            if ambito_cdd not in resultados_ambitos:
                resultados_ambitos[ambito_cdd] = []
            resultados_ambitos[ambito_cdd].extend(evals_cdd)
            scores_ambitos[ambito_cdd] = calcular_score_ambito(resultados_ambitos[ambito_cdd])
            print(f"  ✓ {len(evals_cdd)} controles CDD fusionados en ámbito '{ambito_cdd}'")

        # 5c. REVISIÓN DEL CÓDIGO MÓDULO A MÓDULO ─────────────────────────────
        # Se fusiona en 'Implementación' con el mismo patrón que los controles
        # CDD en 'Calidad de datos': cada módulo revisado aporta una evaluación
        # con su puntaje, así que pesa en el score del ámbito.
        #
        # Por qué un pase aparte y no dentro de evaluar_ambito_completo(): el
        # ámbito comparte un presupuesto de VIRF_MAX_CTX que debe alojar también
        # el manual. Un modelo con librerías propias no cabe, y lo que entra
        # desplaza al manual contra el que había que contrastar. Aquí cada
        # módulo entra íntegro en su propia llamada.
        revision_cod = {}
        if args.revisar_codigo:
            from modulos.revision_codigo import (
                RevisorCodigo, descubrir_modulos, inventario,
                formatear_inventario, informe_markdown,
                CATEGORIAS_HALLAZGO as _CATS,
            )
            _raiz_cod = Path(_RUTAS_INPUTS["implementacion"])
            _mods_cod = descubrir_modulos(_raiz_cod)

            if not _mods_cod:
                print(f"\n  ⚠️  --revisar-codigo: sin módulos (.py/.ipynb) en {_raiz_cod}")
                print("     La revisión de código se omite. El ámbito "
                      "Implementación se evalúa solo con la documentación.")
            else:
                # El manual viaja como contexto fijo de CADA llamada, así que su
                # tamaño multiplica el coste. Se toma del ámbito ya cargado para
                # no volver a leer disco.
                _docs_manual = todos_inputs.get("doc_modelamiento", []) or []
                _manual_txt = "\n\n".join(
                    f"[{d.get('nombre','?')}]\n{d.get('contenido','')}"
                    for d in _docs_manual
                )
                # El perfil de datasets, si se generó, permite además comprobar
                # si las columnas que el código consume existen de verdad.
                if _perfil_datasets:
                    _manual_txt += ("\n\n[PERFIL DE DATASETS]\n"
                                    + _perfil_datasets["contenido"])

                _inv_cod = inventario(_mods_cod, raiz=_raiz_cod,
                                      chars_manual=len(_manual_txt))
                # El inventario se imprime SIEMPRE antes de gastar: este flujo
                # multiplica las llamadas por el número de ficheros y el
                # operador tiene derecho a ver el coste antes de que ocurra.
                print(formatear_inventario(_inv_cod))
                print(f"\n🔬 Revisando {len(_mods_cod)} módulo(s) de código "
                      f"contra la documentación...")

                _revisor = RevisorCodigo(cliente_ia=_get_ia())
                revision_cod = _revisor.revisar(
                    _mods_cod, _manual_txt, raiz=_raiz_cod, verbose=True,
                )
                revision_cod["inventario"] = _inv_cod

                # ── Informe Markdown aparte ──────────────────────────────────
                # El detalle fichero:línea no cabe en el Word sin ahogarlo, y un
                # anexo de 200 hallazgos no es legible en un informe ejecutivo.
                _ruta_rev = outputs_dir / f"revision_codigo_{nombre_seguro_titulo}.md"
                _ruta_rev.write_text(
                    informe_markdown(revision_cod, args.titulo), encoding="utf-8")
                print(f"\n  📄 Informe de revisión: {_ruta_rev.name}")

                # ── Fusión en el ámbito Implementación ───────────────────────
                # Puntaje por módulo derivado de la severidad de sus hallazgos.
                # Se calibra igual que los controles CDD: el estado manda, y la
                # gravedad matiza. Un módulo sin hallazgos cumple plenamente.
                _evals_cod = []
                for _m in revision_cod.get("modulos", []):
                    _hs = _m.get("hallazgos", []) or []
                    if not _m.get("revision_valida"):
                        # Fallo técnico: NO recibe puntaje. Igual que las
                        # actividades fallidas, queda fuera del score en vez de
                        # puntuar 1 y castigar al validado por un error nuestro.
                        _evals_cod.append({
                            "puntaje":              None,
                            "concepto":             "REVISIÓN NO REALIZADA — fallo técnico",
                            "observacion":          str(_m.get("error", ""))[:300],
                            "evidencia_encontrada": "",
                            "preguntas_pendientes": [],
                            "recomendacion":        "Re-ejecutar la revisión de código.",
                            "actividad":            f"Revisión de código: {_m.get('fichero','?')}",
                            "control":              "Revisión de código vs documentación",
                            "evaluacion_valida":    False,
                            "error_evaluacion":     str(_m.get("error", ""))[:200],
                        })
                        continue

                    _n_crit = sum(1 for h in _hs if h["severidad"] == "critica")
                    _n_alta = sum(1 for h in _hs if h["severidad"] == "alta")
                    _n_media = sum(1 for h in _hs if h["severidad"] == "media")
                    if _n_crit:
                        _pt = 1
                    elif _n_alta >= 3:
                        _pt = 2
                    elif _n_alta:
                        _pt = 3
                    elif _n_media:
                        _pt = 4
                    else:
                        _pt = 5

                    _obs = " | ".join(
                        f"{h['fichero']}:{h['linea'] or '?'} [{h['categoria']}] "
                        f"{h['descripcion'][:120]}"
                        for h in _hs[:5]
                    )
                    if len(_hs) > 5:
                        _obs += f" | … y {len(_hs) - 5} hallazgo(s) más (ver informe .md)"

                    _evals_cod.append({
                        "puntaje":              _pt,
                        "concepto":             (_m.get("resumen_modulo") or
                                                 "Módulo revisado contra la documentación."),
                        "observacion":          _obs or "Sin discrepancias con la documentación.",
                        "evidencia_encontrada": ", ".join(_m.get("elementos_definidos", [])[:12]),
                        "preguntas_pendientes": [],
                        "recomendacion":        ("Documentar o corregir los elementos señalados."
                                                 if _hs else ""),
                        "actividad":            f"Revisión de código: {_m.get('fichero','?')}",
                        "control":              "Revisión de código vs documentación",
                        "prompt_sha256":        _m.get("prompt_sha256"),
                    })

                _amb_impl = "Implementación"
                if _amb_impl not in resultados_ambitos:
                    resultados_ambitos[_amb_impl] = []
                resultados_ambitos[_amb_impl].extend(_evals_cod)
                scores_ambitos[_amb_impl] = calcular_score_ambito(
                    resultados_ambitos[_amb_impl])
                print(f"  ✓ {len(_evals_cod)} módulo(s) fusionados en ámbito "
                      f"'{_amb_impl}'")

                _rc = revision_cod
                print(f"\n  🔬 REVISIÓN DE CÓDIGO:")
                print(f"    • Módulos revisados : {_rc['n_modulos_revisados_ok']}/{_rc['n_modulos']}")
                print(f"    • Llamadas al modelo: {_rc['n_llamadas']}")
                print(f"    • Hallazgos         : {_rc['n_hallazgos']} "
                      f"(críticos {_rc['por_severidad'].get('critica',0)}, "
                      f"altos {_rc['por_severidad'].get('alta',0)})")
                for _k in _CATS:
                    _n = _rc["por_categoria"].get(_k, 0)
                    if _n:
                        print(f"        {_k:<22} {_n}")
                if not _rc["revision_confiable"]:
                    print(f"    ⚠️  Revisión INCOMPLETA: "
                          f"{_rc['n_modulos_con_fallo']} módulo(s) con fallo técnico.")

        # 6. Score global y semáforo
        score_global = calcular_score_global(scores_ambitos)
        semaforo = get_semaforo(score_global)

        # 7. Guardar JSON con todos los resultados
        # ── [TRAZA-FIX] Metadatos de trazabilidad auditables ──────────────────
        # ANTES: prompt_hash = sha256(str(list(resultados_ambitos.keys())))
        #        → hasheaba SOLO los nombres de ámbito, por lo que era IDÉNTICO
        #          entre corridas con modelos, documentos y scores distintos.
        #          La trazabilidad prometida no existía.
        # AHORA: la huella se calcula sobre TODO lo que determina el resultado:
        #        versión del agente + modelo IA + tier + pesos + escala +
        #        hash SHA-256 del contenido de CADA documento de evidencia.
        #        Dos corridas dan el mismo hash si y solo si la entrada es la misma.
        from motor.Mx_00_CargaRutas import MODELO_IA

        def _huella_documentos(inputs_por_carpeta: dict) -> dict:
            """SHA-256 (12 chars) del contenido de cada documento de evidencia."""
            huellas = {}
            for _carpeta, _docs in (inputs_por_carpeta or {}).items():
                for _d in _docs:
                    _nombre = _d.get("nombre", "?")
                    _cont = _d.get("contenido", "") or ""
                    huellas[f"{_carpeta}/{_nombre}"] = {
                        "sha256": hashlib.sha256(_cont.encode("utf-8")).hexdigest()[:12],
                        "chars":  len(_cont),
                    }
            return dict(sorted(huellas.items()))

        _docs_huella = _huella_documentos(todos_inputs)

        # ── [TRAZA-ESTÁNDAR] Qué versión de la VARA DE MEDIR se aplicó ────────
        # El estándar es un documento vivo: la entidad lo revisa y crece. Dos
        # informes del mismo modelo con scores distintos pueden deberse a que
        # el modelo cambió… o a que cambió el criterio. Sin registrar la versión
        # del estándar, esa diferencia es indistinguible, y un auditor que
        # compare informes de dos trimestres no puede saber cuál de las dos
        # cosas pasó.
        #
        # Antes esto se intentaba proteger con un test que congelaba los
        # conteos por tier. No funcionaba: el test se rompía en cada revisión
        # legítima y el arreglo natural era actualizar el número, con lo que la
        # protección desaparecía justo cuando el criterio cambiaba de verdad.
        # La trazabilidad pertenece al informe, no a la suite de tests.
        def _huella_estandar(datos_ambitos: dict) -> dict:
            _ruta = ESTANDARES_PATH
            _sha = None
            try:
                _h = hashlib.sha256()
                with open(_ruta, "rb") as _f:
                    for _b in iter(lambda: _f.read(65536), b""):
                        _h.update(_b)
                _sha = _h.hexdigest()
            except OSError:
                pass
            _req = sum(1 for _acts in (datos_ambitos or {}).values()
                       for _a in _acts if _a.get("requerida", True))
            return {
                "archivo": _ruta.name,
                "sha256": _sha,
                "n_ambitos": len(datos_ambitos or {}),
                "n_actividades": sum(len(v) for v in (datos_ambitos or {}).values()),
                "n_requeridas_en_este_tier": _req,
            }

        _estandar_huella = _huella_estandar(ambitos_data)

        # ── [BLOQUE 4] Huella de la LÓGICA de prompts ─────────────────────────
        # El informe ya respondía «¿sobre qué evidencia?» y «¿con qué criterio?».
        # Faltaba la tercera pregunta del auditor: «¿y qué le preguntasteis al
        # modelo?». Se hashean el rol del agente, las instrucciones por ámbito y
        # los ficheros que ensamblan los prompts.
        from modulos.huella_prompts import huella_plantilla_prompts
        _prompts_huella = huella_plantilla_prompts()

        # Fuente canónica y determinista de la huella global
        _fuente_huella = json.dumps(
            {
                "agente_version": AGENTE_VERSION,
                "modelo_ia":      MODELO_IA,
                "proveedor_ia":   IA_PROVEEDOR,
                "tier":           tier_str,
                "pesos_ambito":   AMBITO_PESOS,
                "escala":         {str(k): v.get("label") for k, v in ESCALA_PUNTAJE.items()},
                "ambitos":        sorted(resultados_ambitos.keys()),
                "documentos":     _docs_huella,
                "estandar":       _estandar_huella,
                # [BLOQUE 4] La lógica de prompts entra en la huella: si alguien
                # reescribe una instrucción de ámbito, dos corridas con la misma
                # evidencia y el mismo estándar dejan de ser reproducibles, y
                # hasta ahora nada lo delataba.
                "prompts":        _prompts_huella,
            },
            sort_keys=True, ensure_ascii=False, default=str,
        )
        _huella_ejecucion = hashlib.sha256(_fuente_huella.encode("utf-8")).hexdigest()

        _agente_meta = {
            "agente_version":   AGENTE_VERSION,
            "modelo_ia":        MODELO_IA,
            "proveedor_ia":     IA_PROVEEDOR,
            "pesos_ambito":     AMBITO_PESOS,
            "cache_activo":     cache_activo,
            # ── Trazabilidad reproducible ─────────────────────────────────────
            "huella_ejecucion":  _huella_ejecucion[:12],   # identifica la corrida
            "huella_completa":   _huella_ejecucion,        # para verificación estricta
            "documentos_huella": _docs_huella,             # qué evidencia se usó
            "estandar":          _estandar_huella,        # qué versión del estándar
            "prompts":           _prompts_huella,         # qué se le preguntó al modelo
            "n_documentos":      len(_docs_huella),
            "chars_evidencia":   sum(v["chars"] for v in _docs_huella.values()),
            "generado_utc":      datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
            # Compatibilidad hacia atrás con informes previos
            "prompt_hash":       _huella_ejecucion[:12],
        }
        # [CONTRATO-FIX] Métricas de integridad para el JSON de auditoría
        _integridad = {
            "actividades_evaluadas_ok": sum(
                1 for evs in resultados_ambitos.values() for e in evs
                if e.get("puntaje") is not None and not e.get("sin_evidencia")
                and e.get("evaluacion_valida") is not False
            ),
            "actividades_sin_evidencia": sum(
                1 for evs in resultados_ambitos.values() for e in evs
                if e.get("sin_evidencia")
            ),
            "actividades_con_fallo_tecnico": sum(
                1 for evs in resultados_ambitos.values() for e in evs
                if e.get("evaluacion_valida") is False
            ),
            "detalle_fallos": [
                {"ambito": amb,
                 "actividad": str(e.get("actividad", ""))[:120],
                 "error": str(e.get("error_evaluacion", ""))[:200]}
                for amb, evs in resultados_ambitos.items() for e in evs
                if e.get("evaluacion_valida") is False
            ],
        }
        _integridad["dictamen_confiable"] = (
            _integridad["actividades_con_fallo_tecnico"] == 0
            and _integridad["actividades_evaluadas_ok"] > 0
        )

        # [AUDIT-FIX] `args.titulo` llega de la línea de comandos y se
        # interpolaba tal cual: `--titulo "../../../evil"` escribía el JSON de
        # resultados FUERA de outputs/. Se sanea el nombre de fichero (el
        # título original se conserva íntegro DENTRO del JSON).
        # `nombre_seguro_titulo` se resolvió en el paso 3, junto a outputs_dir.
        ruta_json = outputs_dir / f"resultados_{nombre_seguro_titulo}_{fecha_informe}.json"

        # ── [CUMPLIMIENTO 3] Overrides del validador y métrica de independencia
        from modulos.override_humano import resumen_override
        _n_actividades = sum(len(v) for v in resultados_ambitos.values())
        _override = resumen_override(args.titulo, _n_actividades)

        _payload = {
            "modelo":                   args.titulo,
            "tier":                     tier_str,
            "fecha":                    fecha_informe,
            "agente":                   _agente_meta,
            "integridad":               _integridad,
            "score_global":             score_global,
            "semaforo":                 semaforo,
            "scores_por_ambito":        scores_ambitos,
            "resultados_por_ambito":    resultados_ambitos,
            "controles_calidad_datos":  resultados_cdd,
            "override_validador":       _override,
        }
        # Solo si se pidió: un campo vacío en todos los informes previos
        # confundiría a quien compare corridas ("¿se revisó el código y no
        # encontró nada, o no se revisó?"). Su ausencia significa "no se pidió".
        if revision_cod:
            _payload["revision_codigo"] = revision_cod
        if _identidad:
            _payload["validacion_humana"] = _identidad

        # ── [CUMPLIMIENTO 1] Sellado de cadena de custodia ───────────────────
        # DEBE ser lo último antes de escribir: el hash cubre todo lo anterior,
        # y cualquier campo añadido después quedaría fuera del sello y la
        # verificación lo detectaría como alteración.
        # [CONCURRENCIA 2026-07-30] Preservar + sellar + escribir van en UNA
        # operación bajo lock. Antes eran tres pasos sueltos, y entre la lectura
        # del último eslabón y la escritura cabía otro proceso: dos validaciones
        # simultáneas del mismo modelo bifurcaban la cadena y `--verificar-cadena`
        # la reportaba ROTA sin que nadie hubiera manipulado nada.
        from modulos.custodia import sellar_y_escribir

        _payload, _archivado = sellar_y_escribir(
            _payload, ruta_json, OUTPUTS_DIR, args.titulo, todos_inputs)
        if _archivado:
            print(f"  🔗 Informe previo preservado como {_archivado.name}")

        _cust = _payload["custodia"]
        print(f"  🔗 Cadena de custodia: eslabón #{_cust['posicion_en_cadena']} · "
              f"hash {_cust['hash_este_informe'][:12]}…")

        # 8. Generar informe Word (solo en modo --prdc)
        ruta_word = None
        if args.prdc:
            print("\n📝 Generando resumen ejecutivo...")
            resumen = generar_resumen_ejecutivo(
                evaluaciones_por_ambito=resultados_ambitos,
                scores_por_ambito=scores_ambitos,
                score_global=score_global,
                titulo_modelo=args.titulo,
                tier=tier_str,
            )
            print("📝 Generando informe Word...")
            ruta_word = generar_word_informe(
                resumen_ejecutivo=resumen,
                evaluaciones_por_ambito=resultados_ambitos,
                scores_por_ambito=scores_ambitos,
                score_global=score_global,
                titulo_modelo=args.titulo,
                tier=tier_str,
                outputs_dir=outputs_dir,
                # ── Bloques de cumplimiento regulatorio ──────────────────────
                validacion_humana=_identidad,
                custodia=_cust,
                agente_meta=_agente_meta,
                override=_override,
            )

            # ── [CUMPLIMIENTO 2.2] Registro acumulado de aprobaciones ─────────
            # Se registra DESPUÉS de emitir el Word: si la generación falla, no
            # debe quedar constancia de una aprobación que nunca se materializó.
            from modulos.validador_humano import registrar_validacion
            registrar_validacion(
                modelo=args.titulo, identidad=_identidad, tier=tier_str,
                huella=_agente_meta.get("huella_ejecucion", ""),
                score_global=score_global,
            )

            # ── [CUMPLIMIENTO 3.2] Señal INTERNA de calidad del proceso ───────
            # Fichero aparte, NUNCA en el informe del regulador: allí sería una
            # acusación implícita al propio validador que firma.
            from modulos.override_humano import calidad_proceso, guardar_calidad_proceso
            _calidad = calidad_proceso(_identidad["validador"])
            _ruta_calidad = guardar_calidad_proceso(_calidad, outputs_dir)
            if _calidad.get("señales"):
                print("\n  🔎 Señales internas de calidad del proceso "
                      "(NO se incluyen en el informe entregable):")
                for _s in _calidad["señales"]:
                    print(f"     • {_s}")
                if _ruta_calidad:
                    print(f"     registrado en {_ruta_calidad.name}")

        # ── [CONTRATO-FIX] Reporte de integridad de la corrida ────────────────
        # Cuenta actividades realmente evaluadas vs. las que fallaron técnicamente
        # o quedaron sin evidencia. El auditor debe ver esto ANTES del score.
        _n_validas = _n_sin_evidencia = _n_fallidas = 0
        _fallos_detalle = []
        for _amb, _evs in resultados_ambitos.items():
            for _ev in _evs:
                if _ev.get("sin_evidencia"):
                    _n_sin_evidencia += 1
                elif _ev.get("evaluacion_valida") is False:
                    _n_fallidas += 1
                    _fallos_detalle.append(
                        f"{_amb} → {str(_ev.get('actividad', ''))[:50]}: "
                        f"{str(_ev.get('error_evaluacion', ''))[:80]}"
                    )
                elif _ev.get("puntaje") is not None:
                    _n_validas += 1

        # 9. Resumen final
        print("\n" + "═" * 70)
        print("  ✅ PIPELINE VIRF COMPLETADO")
        print("═" * 70)

        print(f"\n  🔎 INTEGRIDAD DE LA EVALUACIÓN:")
        print(f"    • Actividades evaluadas OK : {_n_validas}")
        print(f"    • Sin evidencia (D3-FIX)   : {_n_sin_evidencia}")
        print(f"    • Fallos técnicos          : {_n_fallidas}")
        if _n_fallidas:
            print(f"\n    ⚠️  {_n_fallidas} actividad(es) NO se evaluaron por fallo técnico.")
            print(f"       Estas NO recibieron puntaje y quedan EXCLUIDAS del score.")
            for _f in _fallos_detalle[:5]:
                print(f"         - {_f}")
            if len(_fallos_detalle) > 5:
                print(f"         ... y {len(_fallos_detalle) - 5} más (ver JSON)")
            print(f"       → Re-ejecuta para completarlas antes de emitir dictamen.")

        print(f"\n  📊 RESULTADOS:")
        print(f"    • Ámbitos evaluados:   {len(resultados_ambitos)}")
        # [AUDIT-FIX] Aquí se imprimía solo `total_actividades`, que cuenta las
        # actividades del estándar VIRF. Pero los controles CDD se integran
        # después en el ámbito 'Calidad de datos' y también reciben puntaje y
        # pesan en su score. Resultado: el resumen decía "evaluadas OK: 19"
        # sobre "totales: 15" — más evaluadas que existentes. El score era
        # correcto; el contador era el que no cuadraba. Se declara el desglose.
        #
        # [CODIGO-FIX] Al añadir la revisión de código apareció una SEGUNDA
        # fuente de evaluaciones integradas, y la resta de arriba las atribuía
        # todas a CDD: con 4 controles y 4 módulos el resumen declaraba
        # «8 control(es) CDD», que es falso. La resta solo funciona mientras
        # haya una única fuente añadida, así que ahora cada una se cuenta por
        # separado y el residuo se declara como tal en vez de asignarse a la
        # primera etiqueta disponible.
        _n_evaluaciones = sum(len(v) for v in resultados_ambitos.values())
        _n_cdd_integrados = len(
            [e for e in resultados_ambitos.get("Calidad de datos", [])
             if e.get("control") == "Controles Automáticos de Calidad de Datos"]
        )
        _n_codigo_integrados = len(
            [e for e in resultados_ambitos.get("Implementación", [])
             if e.get("control") == "Revisión de código vs documentación"]
        )
        _partes_cuenta = [f"{total_actividades} del estándar"]
        if _n_cdd_integrados:
            _partes_cuenta.append(f"{_n_cdd_integrados} control(es) CDD")
        if _n_codigo_integrados:
            _partes_cuenta.append(f"{_n_codigo_integrados} módulo(s) de código")
        _residuo = _n_evaluaciones - total_actividades - _n_cdd_integrados \
            - _n_codigo_integrados
        if _residuo:
            _partes_cuenta.append(f"{_residuo} sin clasificar")
        if len(_partes_cuenta) > 1:
            print(f"    • Actividades totales: {' + '.join(_partes_cuenta)} "
                  f"= {_n_evaluaciones} evaluaciones")
        else:
            print(f"    • Actividades totales: {total_actividades}")
        # [AUDIT-FIX] score_global es None cuando ningún ámbito pudo evaluarse.
        # Formatearlo con .2f reventaba; y antes, peor: llegaba como 0.00 y se
        # anunciaba "CRÍTICO" sobre una corrida sin ninguna evidencia.
        if score_global is None:
            print(f"    • Score global:        NO EVALUABLE  [{semaforo.get('label', '')}]")
            print(f"      ⚠️  Ningún ámbito tenía evidencia. NO hay dictamen que emitir;")
            print(f"         esto NO significa que el modelo sea deficiente.")
        else:
            print(f"    • Score global:        {score_global:.2f}/5.0  [{semaforo.get('label', '')}]")
        for amb, sc in scores_ambitos.items():
            if sc is not None:
                print(f"      - {amb:<35} {sc:.2f}")
            else:
                print(f"      - {amb:<35} SIN DOCUMENTOS")
        if resultados_cdd:
            cdd_ok    = resultados_cdd.get("controles_ok", 0)
            cdd_total = resultados_cdd.get("total_controles", 0)
            cdd_crit  = resultados_cdd.get("hallazgos_criticos", 0)
            print(f"    • Controles CDD:       {cdd_ok}/{cdd_total}  (hallazgos críticos: {cdd_crit})")
        print(f"\n  📁 ARCHIVOS GENERADOS:")
        print(f"    • JSON:    {ruta_json.name}")
        if ruta_word:
            print(f"    • Word:    {Path(ruta_word).name}")
        print(f"    • Carpeta: {outputs_dir}")
        print("═" * 70 + "\n")

        # 10. BUCLE DE FEEDBACK (solo si se ejecutó con --preprdc)
        if not args.prdc:
            print("\n" + "═" * 70)
            print("  📝 REGISTRO DE FEEDBACK")
            print("═" * 70)
            feedbacks_nuevos = bucle_feedback_consola(
                evaluaciones_por_ambito=resultados_ambitos,
                titulo_modelo=args.titulo,
                tier=tier_str,
                version="",
            )
            if feedbacks_nuevos:
                print(f"\n  ✅ Se registraron {len(feedbacks_nuevos)} correcciones.")
                print("  En la siguiente ejecución, el agente considerará este feedback.")
            print("=" * 70 + "\n")

    except Exception as e:
        print(f"  ❌ Error en pipeline: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        # ── Persistir caché y mostrar resumen de sesión ───────────────────
        cerrar_cache()


if __name__ == "__main__":
    main()
