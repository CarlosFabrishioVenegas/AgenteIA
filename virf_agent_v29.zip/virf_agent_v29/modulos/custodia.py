"""
modulos/custodia.py
═══════════════════════════════════════════════════════════════════════════════
CADENA DE CUSTODIA — trazabilidad inmutable de los informes de validación.

Requisito de cumplimiento, no mejora técnica. SR 11-7 §V y EBA/GL/2023/01
exigen poder demostrar que un resultado no fue alterado después de emitirse y
que cada puntaje está vinculado a la versión exacta de la evidencia que lo
justificó.

Responde a tres preguntas que un auditor externo va a formular:

  «¿Cómo sé que este informe no se editó después de generarse?»
      → hash de contenido + hash encadenado al informe anterior del mismo
        modelo. Alterar cualquier informe rompe la cadena en un punto
        identificable (`verificar_cadena`).

  «¿Cómo sé que la fecha es real y no se manipuló copiando el fichero?»
      → el timestamp es de GENERACIÓN, va DENTRO del JSON firmado, y entra en
        el hash. La fecha del sistema de ficheros es irrelevante.

  «¿Sobre qué versión del manual se emitió este puntaje?»
      → `version_evidencia_usada`: SHA-256 del fichero y del texto extraído en
        el instante de la evaluación (`verificar_evidencia`).

Diseño del hash
───────────────
`hash_este_informe` se calcula sobre el JSON completo EXCLUYENDO el propio
campo (sería circular) y el campo `hash_cadena`, que lo deriva. La
serialización es canónica —`sort_keys=True`— para que dos procesos que
produzcan los mismos datos obtengan el mismo hash independientemente del orden
de inserción de las claves.

`hash_cadena` = SHA-256(hash_este_informe + hash_informe_anterior + timestamp).
Cambiar el timestamp rompe la verificación aunque el contenido sea idéntico,
que es exactamente el requisito de 1.2.
"""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Campos que NO entran en el hash de contenido (lo derivan o serían circulares)
_EXCLUIDOS_DEL_HASH = ("hash_este_informe", "hash_cadena")

_CLAVE_CUSTODIA = "custodia"


# ═════════════════════════════════════════════════════════════════════════════
# Hashing canónico
# ═════════════════════════════════════════════════════════════════════════════

def _sin_campos_derivados(datos: Dict) -> Dict:
    """Copia del informe sin los campos que derivan del propio hash."""
    copia = dict(datos)
    custodia = dict(copia.get(_CLAVE_CUSTODIA) or {})
    for k in _EXCLUIDOS_DEL_HASH:
        custodia.pop(k, None)
    if custodia:
        copia[_CLAVE_CUSTODIA] = custodia
    else:
        copia.pop(_CLAVE_CUSTODIA, None)
    return copia


def hash_contenido(datos: Dict) -> str:
    """
    SHA-256 canónico del contenido de un informe.

    Determinista: `sort_keys=True` garantiza que el orden de inserción de las
    claves no altere el hash. Sin eso, dos corridas con datos idénticos podrían
    dar hashes distintos y la verificación sería inútil.
    """
    fuente = json.dumps(
        _sin_campos_derivados(datos),
        sort_keys=True, ensure_ascii=False, default=str, separators=(",", ":"),
    )
    return hashlib.sha256(fuente.encode("utf-8")).hexdigest()


def hash_archivo(ruta) -> Optional[str]:
    """SHA-256 del contenido binario. None si no se puede leer."""
    try:
        h = hashlib.sha256()
        with open(ruta, "rb") as f:
            for bloque in iter(lambda: f.read(65536), b""):
                h.update(bloque)
        return h.hexdigest()
    except OSError:
        return None


def _hash_cadena(hash_propio: str, hash_anterior: Optional[str], ts: str) -> str:
    """
    Eslabón de la cadena. Incluye el timestamp para que alterarlo rompa la
    verificación aunque el contenido no cambie (requisito 1.2).
    """
    material = f"{hash_propio}|{hash_anterior or 'GENESIS'}|{ts}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


# ═════════════════════════════════════════════════════════════════════════════
# Localización de informes
# ═════════════════════════════════════════════════════════════════════════════

def _slug(texto: str) -> str:
    """Normaliza un nombre de modelo para comparar entre ficheros."""
    return re.sub(r"[^a-z0-9]", "", str(texto or "").lower())


def informes_de_modelo(outputs_dir, modelo: str) -> List[Path]:
    """
    Informes JSON de un modelo, ordenados SIGUIENDO LOS ENLACES de la cadena.

    [AUDIT-FIX] La primera versión ordenaba por el `generado_utc` interno. Falla:
    ese sello tiene precisión de SEGUNDOS, así que dos o tres corridas dentro
    del mismo segundo son indistinguibles y el orden quedaba a merced de
    `rglob()`. Reproducido con tres corridas seguidas del mismo modelo: los tres
    eslabones se reportaron como ROTOS por estar mal ordenados, no por estar
    alterados — un falso positivo que destruye la confianza en el control.

    Ordenar por fecha es además conceptualmente incorrecto en una cadena de
    hashes: el orden ya está codificado en los propios enlaces. Cada informe
    declara el hash de su predecesor, así que la secuencia se reconstruye
    siguiéndolos. Eso la hace inmune a colisiones de reloj Y a la manipulación
    del timestamp, que es precisamente lo que se quiere detectar.

    Los informes sin bloque de custodia (previos a esta función) no participan
    de los enlaces: se devuelven primero, ordenados por nombre.
    """
    base = Path(outputs_dir)
    if not base.exists():
        return []
    objetivo = _slug(modelo)

    sellados: Dict[str, Path] = {}      # hash propio → fichero
    por_predecesor: Dict[Optional[str], List[Path]] = {}
    legado: List[Path] = []

    for f in sorted(base.rglob("resultados_*.json")):
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        if _slug(d.get("modelo", "")) != objetivo:
            continue
        cust = d.get(_CLAVE_CUSTODIA) or {}
        propio = cust.get("hash_este_informe")
        if not propio:
            legado.append(f)
            continue
        sellados[propio] = f
        por_predecesor.setdefault(cust.get("hash_informe_anterior"), []).append(f)

    # Recorrido desde el génesis (sin predecesor) siguiendo los enlaces.
    orden: List[Path] = []
    vistos = set()
    frontera = list(por_predecesor.get(None, []))
    while frontera:
        actual = frontera.pop(0)
        if actual in vistos:
            continue          # ciclo o duplicado: se corta, no se cuelga
        vistos.add(actual)
        orden.append(actual)
        try:
            h = (json.loads(actual.read_text(encoding="utf-8"))
                 .get(_CLAVE_CUSTODIA) or {}).get("hash_este_informe")
        except (json.JSONDecodeError, OSError):
            continue
        frontera.extend(por_predecesor.get(h, []))

    # Huérfanos: sellados cuyo predecesor declarado no existe. No se descartan
    # —serían invisibles— sino que se añaden al final para que la verificación
    # los examine y los marque.
    huerfanos = [f for f in sellados.values() if f not in vistos]
    return legado + orden + sorted(huerfanos)


# ═════════════════════════════════════════════════════════════════════════════
# Sellado
# ═════════════════════════════════════════════════════════════════════════════

def version_evidencia(inputs_por_carpeta: Dict) -> Dict[str, Dict]:
    """
    Congela la versión de cada documento de evidencia usado.

    Guarda DOS hashes por documento, porque responden preguntas distintas:

      · `sha256_archivo`  — del fichero en disco. Es el que permite verificar a
        posteriori si el manual citado cambió (`verificar_evidencia`).
      · `sha256_texto`    — del texto extraído que realmente vio el modelo. No
        es reproducible sin reejecutar el lector (una actualización de pdfminer
        lo cambiaría), pero demuestra qué contenido exacto se evaluó.

    Sin el primero no se puede verificar nada contra el disco; sin el segundo no
    se puede demostrar qué leyó el agente. Hacen falta ambos.
    """
    versiones: Dict[str, Dict] = {}
    for carpeta, docs in (inputs_por_carpeta or {}).items():
        for d in docs or []:
            nombre = d.get("nombre", "?")
            contenido = d.get("contenido", "") or ""
            clave = f"{carpeta}/{nombre}"
            versiones[clave] = {
                "ruta": d.get("ruta"),
                "sha256_archivo": d.get("sha256_archivo"),
                "sha256_texto": hashlib.sha256(contenido.encode("utf-8")).hexdigest(),
                "chars": len(contenido),
                "cobertura_pct": d.get("cobertura_pct"),
            }
    return dict(sorted(versiones.items()))


def preservar_si_existe(ruta_destino) -> Optional[Path]:
    """
    Si en `ruta_destino` ya hay un informe SELLADO, lo archiva antes de que se
    sobrescriba. Devuelve la nueva ruta, o None si no había nada que preservar.

    [AUDIT-FIX] El nombre del informe es `resultados_<modelo>_<fecha>.json`, con
    granularidad de DÍA. Dos corridas del mismo modelo la misma fecha escriben
    el mismo fichero, así que la segunda BORRABA la primera. Consecuencias para
    una cadena de custodia:

      · imposible tener dos eslabones el mismo día;
      · re-ejecutar destruía el eslabón anterior, y la cadena pasaba a declarar
        un predecesor inexistente — verificado: `--verificar-cadena` reportaba
        «declara un informe anterior pero es el primero de la cadena»;
      · un validador que repitiera la corrida para obtener un score más
        favorable eliminaba la evidencia de la anterior.

    Que el verificador lo DETECTE es correcto, pero detectar la pérdida no la
    evita. El informe previo se conserva con su hash en el nombre: el hash es
    único por contenido, así que no puede colisionar ni sobrescribirse a sí mismo.
    """
    ruta_destino = Path(ruta_destino)
    if not ruta_destino.exists():
        return None
    try:
        previo = json.loads(ruta_destino.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    h = (previo.get(_CLAVE_CUSTODIA) or {}).get("hash_este_informe")
    if not h:
        return None      # informe sin sellar: no es un eslabón, no se preserva
    archivado = ruta_destino.with_name(
        f"{ruta_destino.stem}__{h[:12]}{ruta_destino.suffix}")
    if archivado.exists():
        return archivado  # mismo contenido exacto ya archivado
    try:
        ruta_destino.rename(archivado)
        return archivado
    except OSError:
        return None


#: Tipos de corrida que pueden entrar en la cadena. `entregable` es el informe
#: que se presenta; `trabajo` es una corrida intermedia (hoy, `--control`) que
#: se sella por trazabilidad pero NO se firma: firmar es un acto de aprobación
#: y `--control` no aprueba nada. Ver P0.1-A en ROADMAP_v28.md.
TIPO_ENTREGABLE = "entregable"
TIPO_TRABAJO = "trabajo"


def sellar(datos: Dict, outputs_dir, modelo: str,
           inputs_por_carpeta: Optional[Dict] = None,
           tipo: str = TIPO_ENTREGABLE) -> Dict:
    """
    Añade el bloque `custodia` al informe. Devuelve el mismo dict, mutado.

    El sellado ocurre justo antes de escribir el JSON: cualquier campo añadido
    después queda fuera del hash y la verificación lo detectará.

    ── `tipo` ───────────────────────────────────────────────────────────────
    `informes_de_modelo()` barre `resultados_*.json`, que es EXACTAMENTE el
    patrón que escribe el pipeline por control. Sus corridas ya entraban en la
    cadena, sin sello, y el efecto medido era grave:

        [ 1] resultados_LaR_ctrl.json  → ⚠️  SIN CUSTODIA
        [ 2] resultados_LaR_A.json     → ❌ ROTO — «se insertó, borró,
                                            reordenó o alteró un informe»
        integra: False

    Es decir: una corrida de trabajo bastaba para que la verificación acusara
    a un ENTREGABLE LEGÍTIMO de haber sido manipulado. Misma clase de daño que
    la carrera que cerró `sellar_y_escribir()` —marcar como sospechoso algo que
    nadie tocó— y con el mismo coste: destruye la confianza en el control.

    Sellar ambos tipos cierra el hueco de integridad; `tipo` permite además que
    el auditor distinga qué eslabones son entregables presentables y cuáles son
    corridas de trabajo. Los informes anteriores a este campo se leen como
    `entregable`, que es lo que eran.
    """
    anteriores = informes_de_modelo(outputs_dir, modelo)
    hash_anterior = None
    ruta_anterior = None
    if anteriores:
        ruta_anterior = anteriores[-1]
        try:
            prev = json.loads(ruta_anterior.read_text(encoding="utf-8"))
            hash_anterior = (prev.get(_CLAVE_CUSTODIA) or {}).get("hash_este_informe")
            if not hash_anterior:
                # Informe previo a la custodia: se recalcula para poder
                # encadenarlo igualmente y no dejar un hueco en la cadena.
                hash_anterior = hash_contenido(prev)
        except (json.JSONDecodeError, OSError):
            hash_anterior = None

    ts = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")

    datos[_CLAVE_CUSTODIA] = {
        "generado_utc": ts,
        "hash_informe_anterior": hash_anterior,
        "informe_anterior": ruta_anterior.name if ruta_anterior else None,
        "posicion_en_cadena": len(anteriores) + 1,
        "tipo_corrida": tipo,
        "algoritmo": "sha256",
        "version_evidencia_usada": version_evidencia(inputs_por_carpeta or {}),
    }
    # Orden importante: primero el contenido (que ya incluye todo lo anterior),
    # después el eslabón que lo une a la cadena.
    datos[_CLAVE_CUSTODIA]["hash_este_informe"] = hash_contenido(datos)
    datos[_CLAVE_CUSTODIA]["hash_cadena"] = _hash_cadena(
        datos[_CLAVE_CUSTODIA]["hash_este_informe"], hash_anterior, ts)
    return datos


# ═════════════════════════════════════════════════════════════════════════════
# Sellado ATÓMICO — obligatorio con más de un validador
# ═════════════════════════════════════════════════════════════════════════════

def _ruta_lock(outputs_dir, modelo: str):
    """
    Fichero de bloqueo por MODELO.

    Por modelo y no global: dos personas validando modelos distintos no tienen
    por qué esperarse. Lo que no puede solaparse es el encadenado del MISMO
    modelo, que es donde está la condición de carrera.
    """
    base = Path(outputs_dir)
    base.mkdir(parents=True, exist_ok=True)
    return base / f".custodia_{_slug(modelo) or 'sinnombre'}.lock"


def sellar_y_escribir(datos: Dict, ruta_json, outputs_dir, modelo: str,
                      inputs_por_carpeta: Optional[Dict] = None,
                      tipo: str = TIPO_ENTREGABLE) -> Dict:
    """
    Sella y escribe el informe en UNA sola operación protegida por lock.

    ── LA CARRERA QUE CIERRA ────────────────────────────────────────────────
    `sellar()` LEE el último eslabón de la cadena y `agente.py` ESCRIBÍA el
    JSON después, en dos pasos separados. Entre uno y otro cabe otro proceso:

        Ana:  lee eslabón #4 ──┐
        Luis: lee eslabón #4 ──┤  ambos ven el mismo
        Ana:  escribe #5 ──────┤
        Luis: escribe #5 ──────┘  sobre el mismo `hash_informe_anterior`

    Resultado: la cadena se BIFURCA. Dos informes distintos declaran ser el
    eslabón #5 y encadenar al mismo #4. `verificar_cadena` lo reporta como
    cadena ROTA —que es lo correcto— pero nadie ha manipulado nada: solo
    coincidieron dos validaciones del mismo modelo, algo normal en un cierre
    trimestral con un equipo de 2-5 personas.

    Y el daño es peor que un fallo: un informe legítimo queda marcado como
    sospechoso ante el auditor, que es justo lo que la cadena existe para
    evitar.

    ── POR QUÉ AQUÍ Y NO EN `sellar()` ──────────────────────────────────────
    El lock tiene que cubrir LECTURA + ESCRITURA. Ponerlo solo dentro de
    `sellar()` protegería la lectura y dejaría la escritura fuera: la carrera
    seguiría abierta, con la falsa sensación de estar resuelta.
    """
    try:
        from modulos.document_cache import _escribir_json_atomico, _lock_archivo
    except ImportError:                                   # pragma: no cover
        # Degradación explícita: mejor emitir el informe que perderlo. Se avisa
        # porque en un equipo esto SÍ importa.
        print("  ⚠️  Sellado sin lock (document_cache no disponible). "
              "Con más de un validador simultáneo la cadena puede bifurcarse.")
        archivado = preservar_si_existe(ruta_json)
        datos = sellar(datos, outputs_dir, modelo, inputs_por_carpeta, tipo)
        with open(ruta_json, "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False, indent=2, default=str)
        return datos, archivado

    with _lock_archivo(_ruta_lock(outputs_dir, modelo)):
        # Dentro del lock: preservar el informe previo, releer la cadena, sellar
        # y escribir. Cualquier informe que otro proceso haya añadido mientras
        # esperábamos ya está en disco, así que `sellar()` lo verá y encadenará
        # detrás de él.
        #
        # `preservar_si_existe` va DENTRO: renombra el fichero del día, y hacerlo
        # fuera del lock reabre la carrera por otra puerta —dos procesos
        # archivando el mismo fichero.
        archivado = preservar_si_existe(ruta_json)
        datos = sellar(datos, outputs_dir, modelo, inputs_por_carpeta, tipo)
        # `_escribir_json_atomico` no admite `default=`, y el payload lleva
        # objetos que json no serializa de fábrica (Path, datetime). Se
        # normaliza aquí en vez de tocar el escritor compartido, que lo usan
        # el caché y el feedback con dicts ya planos.
        _escribir_json_atomico(
            Path(ruta_json),
            json.loads(json.dumps(datos, ensure_ascii=False, default=str)))
    return datos, archivado


# ═════════════════════════════════════════════════════════════════════════════
# Verificación
# ═════════════════════════════════════════════════════════════════════════════

def verificar_cadena(outputs_dir, modelo: str) -> Dict:
    """
    Recorre todos los informes de un modelo y verifica la cadena completa.

    Devuelve un dict con `integra` (bool) y `eslabones`, cada uno con su
    diagnóstico. Se comprueban tres cosas por informe:

      1. que su `hash_este_informe` coincida con el contenido actual
         → detecta edición del informe;
      2. que su `hash_informe_anterior` coincida con el hash real del anterior
         → detecta inserción, borrado o reordenación de informes;
      3. que su `hash_cadena` coincida con hash(propio + anterior + timestamp)
         → detecta manipulación del timestamp.
    """
    informes = informes_de_modelo(outputs_dir, modelo)
    resultado = {
        "modelo": modelo,
        "n_informes": len(informes),
        "integra": True,
        "eslabones": [],
        "primer_fallo": None,
    }
    hash_previo_real: Optional[str] = None

    for i, ruta in enumerate(informes, 1):
        eslabon = {"posicion": i, "archivo": ruta.name, "problemas": []}
        try:
            datos = json.loads(ruta.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            eslabon["problemas"].append(f"ilegible: {exc}")
            eslabon["estado"] = "ILEGIBLE"
            resultado["eslabones"].append(eslabon)
            resultado["integra"] = False
            resultado["primer_fallo"] = resultado["primer_fallo"] or ruta.name
            hash_previo_real = None
            continue

        cust = datos.get(_CLAVE_CUSTODIA) or {}
        eslabon["generado_utc"] = cust.get("generado_utc")
        # Los informes anteriores a `tipo_corrida` eran todos entregables: solo
        # el pipeline completo sellaba. Ese default es el histórico correcto.
        eslabon["tipo_corrida"] = cust.get("tipo_corrida", TIPO_ENTREGABLE)

        if not cust:
            eslabon["estado"] = "SIN CUSTODIA"
            eslabon["problemas"].append(
                "informe anterior a la cadena de custodia; no verificable")
            hash_previo_real = hash_contenido(datos)
            resultado["eslabones"].append(eslabon)
            continue

        # 1. Integridad del contenido
        real = hash_contenido(datos)
        declarado = cust.get("hash_este_informe")
        eslabon["hash_declarado"] = (declarado or "")[:16]
        eslabon["hash_recalculado"] = real[:16]
        if declarado != real:
            eslabon["problemas"].append(
                "el contenido NO coincide con su hash: el informe fue alterado "
                "después de generarse")

        # 2. Enlace con el anterior
        esperado_prev = cust.get("hash_informe_anterior")
        if i == 1:
            if esperado_prev is not None:
                eslabon["problemas"].append(
                    "declara un informe anterior pero es el primero de la cadena: "
                    "puede haberse borrado un informe previo")
        elif esperado_prev != hash_previo_real:
            eslabon["problemas"].append(
                "el enlace con el informe anterior NO coincide: se insertó, "
                "borró, reordenó o alteró un informe de la secuencia")

        # 3. Timestamp dentro del sello
        ts = cust.get("generado_utc") or ""
        if cust.get("hash_cadena") != _hash_cadena(declarado or "", esperado_prev, ts):
            eslabon["problemas"].append(
                "el sello de cadena NO coincide: el timestamp de generación fue "
                "modificado")

        eslabon["estado"] = "OK" if not eslabon["problemas"] else "ROTO"
        if eslabon["problemas"]:
            resultado["integra"] = False
            resultado["primer_fallo"] = resultado["primer_fallo"] or ruta.name
        resultado["eslabones"].append(eslabon)
        hash_previo_real = real

    return resultado


def verificar_evidencia(ruta_json) -> Dict:
    """
    Comprueba si los documentos citados por un informe siguen intactos.

    Tres estados por documento:
      · INTACTO   — el fichero existe y su hash coincide
      · MODIFICADO— existe pero cambió desde la evaluación
      · AUSENTE   — ya no está en la ruta registrada
      · NO VERIFICABLE — el informe no guardó el hash del fichero

    Un documento MODIFICADO no invalida el informe: demuestra que el informe se
    emitió sobre una versión ANTERIOR, que es precisamente el propósito de
    congelar la versión. Lo que sería grave es no poder saberlo.
    """
    ruta_json = Path(ruta_json)
    datos = json.loads(ruta_json.read_text(encoding="utf-8"))
    versiones = ((datos.get(_CLAVE_CUSTODIA) or {}).get("version_evidencia_usada")
                 or {})
    resultado = {
        "informe": ruta_json.name,
        "modelo": datos.get("modelo"),
        "generado_utc": (datos.get(_CLAVE_CUSTODIA) or {}).get("generado_utc"),
        "n_documentos": len(versiones),
        "todos_intactos": True,
        "documentos": [],
    }
    for clave, meta in versiones.items():
        entrada = {"documento": clave, "estado": "INTACTO"}
        ruta = meta.get("ruta")
        esperado = meta.get("sha256_archivo")
        if not esperado:
            entrada["estado"] = "NO VERIFICABLE"
            entrada["detalle"] = "el informe no registró el hash del fichero"
        elif not ruta or not Path(ruta).exists():
            entrada["estado"] = "AUSENTE"
            entrada["detalle"] = f"no existe: {ruta}"
        else:
            actual = hash_archivo(ruta)
            if actual != esperado:
                entrada["estado"] = "MODIFICADO"
                entrada["detalle"] = (
                    f"hash en la evaluación {esperado[:16]}… · "
                    f"hash actual {(actual or '')[:16]}…")
        if entrada["estado"] not in ("INTACTO",):
            resultado["todos_intactos"] = False
        resultado["documentos"].append(entrada)
    return resultado


# ═════════════════════════════════════════════════════════════════════════════
# Presentación en consola
# ═════════════════════════════════════════════════════════════════════════════

def imprimir_cadena(res: Dict) -> None:
    print("\n" + "═" * 74)
    print(f"  🔗 CADENA DE CUSTODIA — {res['modelo']}")
    print("═" * 74)
    if not res["n_informes"]:
        print("\n  No hay informes para este modelo.\n")
        return
    _n_trab = sum(1 for e in res["eslabones"]
                  if e.get("tipo_corrida") == TIPO_TRABAJO)
    print(f"\n  Informes en la cadena: {res['n_informes']}"
          + (f"  ({res['n_informes'] - _n_trab} entregable(s), "
             f"{_n_trab} corrida(s) de trabajo)" if _n_trab else "") + "\n")
    for e in res["eslabones"]:
        icono = {"OK": "✅", "ROTO": "❌", "SIN CUSTODIA": "⚠️ ",
                 "ILEGIBLE": "❌"}.get(e["estado"], "•")
        # La etiqueta solo aparece en las corridas de trabajo: marcar también
        # los entregables añadiría ruido a la lectura habitual, donde todo lo
        # que no está marcado ES el entregable.
        _etiq = "  ·trabajo·" if e.get("tipo_corrida") == TIPO_TRABAJO else ""
        print(f"  {icono} [{e['posicion']:>2}] {e['archivo']}{_etiq}")
        if e.get("generado_utc"):
            print(f"         generado: {e['generado_utc']}")
        if e.get("hash_declarado"):
            print(f"         hash: {e['hash_declarado']}…  "
                  f"recalculado: {e['hash_recalculado']}…")
        for p in e["problemas"]:
            print(f"         ⛔ {p}")
    print("\n" + "─" * 74)
    if res["integra"]:
        print("  ✅ CADENA ÍNTEGRA — ningún informe fue alterado tras su emisión.")
    else:
        print(f"  ❌ CADENA ROTA — primer informe afectado: {res['primer_fallo']}")
        print("     Un informe alterado NO puede sustentar un dictamen ante el")
        print("     regulador. Recuperar la versión original o re-emitir.")
    print("═" * 74 + "\n")


def imprimir_evidencia(res: Dict) -> None:
    print("\n" + "═" * 74)
    print(f"  📄 VERIFICACIÓN DE EVIDENCIA — {res['informe']}")
    print("═" * 74)
    print(f"\n  Modelo   : {res['modelo']}")
    print(f"  Generado : {res['generado_utc']}")
    print(f"  Documentos citados: {res['n_documentos']}\n")
    for d in res["documentos"]:
        icono = {"INTACTO": "✅", "MODIFICADO": "⚠️ ", "AUSENTE": "❌",
                 "NO VERIFICABLE": "•"}.get(d["estado"], "•")
        print(f"  {icono} {d['estado']:<15} {d['documento']}")
        if d.get("detalle"):
            print(f"       {d['detalle']}")
    print("\n" + "─" * 74)
    if res["todos_intactos"]:
        print("  ✅ Toda la evidencia citada sigue intacta.")
    else:
        print("  ⚠️  Parte de la evidencia cambió o desapareció desde la emisión.")
        print("     Esto NO invalida el informe: demuestra sobre qué versión se")
        print("     emitió. Para dictaminar sobre la versión actual, re-ejecutar.")
    print("═" * 74 + "\n")
