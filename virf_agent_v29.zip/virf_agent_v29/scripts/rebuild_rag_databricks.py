"""
scripts/rebuild_rag_databricks.py
===================================
Script de mantenimiento para reconstruir los índices RAG en Databricks.

CUÁNDO EJECUTAR:
  - Mensualmente (Databricks Job programado)
  - Cuando se agregan documentos nuevos a inputs/
  - Después de cambios en la lógica de chunking

USO:
  # Desde terminal o notebook Databricks:
  python scripts/rebuild_rag_databricks.py --dominio LaR
  python scripts/rebuild_rag_databricks.py --dominio VaR
  python scripts/rebuild_rag_databricks.py --dominio conductuales
  python scripts/rebuild_rag_databricks.py --dominio shared
  python scripts/rebuild_rag_databricks.py --dominio all       ← Todos los dominios

  # Forzar rebuild completo (reextrae los PDF, ignora lo persistido):
  python scripts/rebuild_rag_databricks.py --dominio all --force

  # Verificar estado sin reconstruir:
  python scripts/rebuild_rag_databricks.py --status

DATABRICKS JOB (config sugerida):
  - Cluster: Single-node, DBR 14+
  - Schedule: Cron "0 2 1 * *"  (día 1 de cada mes, 2am)
  - Timeout: 60 minutos
  - %pip install rank_bm25 scikit-learn  (en notebook de setup)
"""

# [CONSOLA-FIX] Debe ejecutarse ANTES del primer print. En una consola Windows
# con codepage cp1252 —el default en español— imprimir un emoji no falla al
# escribir, falla al CODIFICAR, y aborta el script con UnicodeEncodeError.
# Este fichero imprime emoji, así que sin esto es inejecutable en esa consola.
#
# La raíz del proyecto se añade a sys.path porque un script de scripts/ solo
# tiene su PROPIA carpeta en la ruta de búsqueda: sin esto, el import falla y
# —si se tragara la excepción— el arreglo quedaría inactivo sin que nadie lo
# note. Por eso el fallback NO silencia el ImportError del proyecto.
import sys as _sys
from pathlib import Path as _Path
_RAIZ_PROYECTO = _Path(__file__).resolve().parents[1]
if str(_RAIZ_PROYECTO) not in _sys.path:
    _sys.path.insert(0, str(_RAIZ_PROYECTO))

from modulos.consola import configurar_consola
configurar_consola()

# ─────────────────────────────────────────────────────────────────────────
# ⚠️  NO forma parte del flujo VIRF activo (lectura → prompt → IA → score
#     → informe). Script auxiliar/de referencia. Ver README §12.
# ─────────────────────────────────────────────────────────────────────────


import argparse
import sys
import time
from pathlib import Path

# Agregar raíz del proyecto al path
ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "motor"))

DOMINIOS = ["LaR", "VaR", "conductuales", "shared"]


def _get_indexer(dominio: str):
    """Importa y retorna el indexer del dominio especificado."""
    if dominio == "LaR":
        from src.rag.LaR.indexer import LaRIndexer
        return LaRIndexer()
    elif dominio == "VaR":
        from src.rag.VaR.indexer import VaRIndexer
        return VaRIndexer()
    elif dominio == "conductuales":
        from src.rag.conductuales.indexer import ConductualesIndexer
        return ConductualesIndexer()
    elif dominio == "shared":
        from src.rag.shared.indexer import SharedIndexer
        return SharedIndexer()
    else:
        raise ValueError(f"Dominio desconocido: {dominio}. Opciones: {DOMINIOS}")


def rebuild_dominio(dominio: str, force: bool = False) -> dict:
    """
    Reconstruye el índice RAG de un dominio.

    Returns:
        dict con 'dominio', 'ok', 'duracion_seg', 'error'
    """
    print(f"\n{'='*60}")
    print(f"  Rebuilding RAG: {dominio}")
    print(f"{'='*60}")

    t0 = time.time()
    try:
        indexer = _get_indexer(dominio)
        indexer.build_index(force_rebuild=force)
        duracion = round(time.time() - t0, 1)
        print(f"  ✅ {dominio} completado en {duracion}s")
        return {"dominio": dominio, "ok": True, "duracion_seg": duracion, "error": None}
    except Exception as e:
        duracion = round(time.time() - t0, 1)
        print(f"  ❌ {dominio} falló: {e}")
        return {"dominio": dominio, "ok": False, "duracion_seg": duracion, "error": str(e)}


def mostrar_status():
    """
    Muestra el estado de cada índice RAG léxico.

    Además de tamaño y fecha, informa de si el índice está VIGENTE: si la
    literatura de `inputs/rag/<dominio>/` cambió desde que se construyó, el
    índice existe pero sirve fragmentos de documentos que ya se sustituyeron.
    Antes esto no se veía —solo se listaba la carpeta— y un índice caduco tenía
    exactamente el mismo aspecto que uno al día.
    """
    from datetime import datetime

    from src.rag.config_rag import INDICE_DIR
    from src.rag.indexador_lexico import IndexadorLexico

    print(f"\n{'='*72}")
    print(f"  Estado de índices RAG léxicos (BM25 + TF-IDF)")
    print(f"  Base: {INDICE_DIR}")
    print(f"{'='*72}")

    for dominio in DOMINIOS:
        est = IndexadorLexico(dominio).estado()
        if not est["existe"]:
            print(f"  ⚠️  {dominio:<15} No existe — ejecutar --dominio {dominio}")
            continue
        fecha = (datetime.fromtimestamp(est["construido_en"]).strftime("%Y-%m-%d %H:%M")
                 if est["construido_en"] else "?")
        icono = "✅" if est["vigente"] else "🔄"
        nota = "" if est["vigente"] else "  ← DESFASADO, reconstruir con --force"
        print(f"  {icono} {dominio:<15} {est['chunks']:>4} chunks / "
              f"{est['documentos']} docs ({est['fuentes_en_disco']} en disco)  —  {fecha}{nota}")

    print()


def main():
    parser = argparse.ArgumentParser(
        description="Reconstruye índices RAG del agente VIRF en Databricks."
    )
    parser.add_argument(
        "--dominio",
        choices=DOMINIOS + ["all"],
        help="Dominio a reconstruir ('all' para todos)",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Borrar índice existente antes de reconstruir",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        default=False,
        help="Mostrar estado de los índices sin reconstruir",
    )
    args = parser.parse_args()

    if args.status:
        mostrar_status()
        return

    if not args.dominio:
        parser.print_help()
        sys.exit(1)

    dominios_a_procesar = DOMINIOS if args.dominio == "all" else [args.dominio]
    t_total = time.time()
    resultados = []

    for dom in dominios_a_procesar:
        res = rebuild_dominio(dom, force=args.force)
        resultados.append(res)

    # Resumen final
    print(f"\n{'='*60}")
    print(f"  RESUMEN REBUILD RAG")
    print(f"{'='*60}")
    ok_count = sum(1 for r in resultados if r["ok"])
    print(f"  Dominios procesados : {len(resultados)}")
    print(f"  Exitosos            : {ok_count}")
    print(f"  Fallidos            : {len(resultados) - ok_count}")
    print(f"  Tiempo total        : {round(time.time() - t_total, 1)}s")

    for r in resultados:
        estado = "✅" if r["ok"] else "❌"
        print(f"  {estado} {r['dominio']:<15} ({r['duracion_seg']}s)"
              + (f"  — {r['error']}" if r["error"] else ""))

    if any(not r["ok"] for r in resultados):
        sys.exit(1)  # Databricks Job detectará el código de salida


if __name__ == "__main__":
    main()
