"""
Agente IA de Validación de Modelos ML Financieros
==================================================
Uso:
    python agente.py --titulo "Validación Modelo Scoring Q1 2025"
    python agente.py --titulo "..." --instrucciones "Incluir análisis PSI por segmento"
"""

import argparse
import sys
from pathlib import Path
from config import CONFIG
from modulos.lector_formatos import LectorFormatos
from modulos.lector_excel import LectorExcel
from modulos.motor_ia import MotorIA
from modulos.generador_word import GeneradorWord
from modulos.generador_excel import GeneradorExcel


# ─── COLORES TERMINAL ────────────────────────────────────────────────────────

class Color:
    RESET  = "\033[0m"
    BLUE   = "\033[94m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    RED    = "\033[91m"
    CYAN   = "\033[96m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"

def log(msg, tipo="info"):
    icons = {"info": "›", "ok": "✓", "error": "✗", "warn": "⚠", "step": "◈"}
    colores = {
        "info":  Color.BLUE,
        "ok":    Color.GREEN,
        "error": Color.RED,
        "warn":  Color.YELLOW,
        "step":  Color.CYAN + Color.BOLD,
    }
    icon  = icons.get(tipo, "›")
    color = colores.get(tipo, Color.RESET)
    print(f"  {color}{icon}{Color.RESET}  {msg}")


# ─── BANNER ──────────────────────────────────────────────────────────────────

def banner():
    print(f"\n{Color.CYAN}{Color.BOLD}")
    print("  ╔══════════════════════════════════════════════════════╗")
    print("  ║     AGENTE IA  ·  VALIDACIÓN ML FINANCIERO           ║")
    print("  ║     Genera documentos Word + Excel con IA            ║")
    print("  ╚══════════════════════════════════════════════════════╝")
    print(f"{Color.RESET}\n")


# ─── PIPELINE PRINCIPAL ──────────────────────────────────────────────────────

def ejecutar(titulo: str, instrucciones: str = ""):
    banner()

    # ── PASO 1: Leer documentos de referencia de estilo ─────────────────────
    log("PASO 1 — Leyendo repositorio de formatos...", "step")
    repo = Path(CONFIG["repositorio_formatos"])
    lector_fmt = LectorFormatos(repo)
    estilo_ctx = lector_fmt.extraer_estilo()
    log(f"Documentos analizados: {lector_fmt.n_docs}", "ok")
    if lector_fmt.n_docs == 0:
        log("Sin documentos de referencia — se usará estilo estándar", "warn")

    # ── PASO 2: Leer Excels de validación ────────────────────────────────────
    log("PASO 2 — Leyendo datos de validación Excel...", "step")
    carpeta_xl = Path(CONFIG["datos_validacion"])
    lector_xl = LectorExcel(carpeta_xl)
    datos_excel = lector_xl.leer_todos()
    if not datos_excel:
        log("No se encontraron archivos Excel en datos_validacion/", "error")
        sys.exit(1)
    log(f"Archivos Excel leídos: {len(datos_excel)}", "ok")
    for fname, hojas in datos_excel.items():
        log(f"  {fname} → {list(hojas.keys())}", "info")

    # ── PASO 3: Motor IA — análisis y generación ────────────────────────────
    log("PASO 3 — Analizando con Motor IA (Claude)...", "step")
    motor = MotorIA(CONFIG["api_key"])

    log("  Analizando estilo de documentos de referencia...", "info")
    patron_estilo = motor.analizar_estilo(estilo_ctx)
    log("  Patrón de estilo aprendido", "ok")

    log("  Analizando métricas de validación...", "info")
    analisis = motor.analizar_validacion(
        datos_excel=datos_excel,
        patron_estilo=patron_estilo,
        titulo=titulo,
        instrucciones=instrucciones,
    )
    log("  Análisis completado", "ok")

    # ── PASO 4: Generar documento Word ──────────────────────────────────────
    log("PASO 4 — Generando documento Word...", "step")
    gen_word = GeneradorWord(Path(CONFIG["outputs"]))
    ruta_word = gen_word.generar(titulo=titulo, analisis=analisis)
    log(f"Word generado: {ruta_word.name}", "ok")

    # ── PASO 5: Generar Excel de conclusiones ───────────────────────────────
    log("PASO 5 — Generando Excel de conclusiones...", "step")
    gen_excel = GeneradorExcel(Path(CONFIG["outputs"]))
    ruta_excel = gen_excel.generar(titulo=titulo, analisis=analisis)
    log(f"Excel generado: {ruta_excel.name}", "ok")

    # ── RESUMEN FINAL ────────────────────────────────────────────────────────
    print(f"\n  {Color.GREEN}{Color.BOLD}{'─'*54}")
    print(f"  ✓ PROCESO COMPLETADO")
    print(f"{'─'*56}{Color.RESET}")
    print(f"  📄 Word  → outputs/{ruta_word.name}")
    print(f"  📊 Excel → outputs/{ruta_excel.name}")
    riesgo = analisis.get("nivel_riesgo_global", "—")
    color_riesgo = {"BAJO": Color.GREEN, "MEDIO": Color.YELLOW, "ALTO": Color.RED}.get(riesgo, "")
    print(f"  🚦 Riesgo global: {color_riesgo}{riesgo}{Color.RESET}\n")


# ─── ENTRY POINT ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Agente IA Validación ML Financiero")
    parser.add_argument("--titulo",
                        default="Informe de Validación de Modelos ML Financieros",
                        help="Título del informe")
    parser.add_argument("--instrucciones", default="",
                        help="Instrucciones adicionales para el agente")
    args = parser.parse_args()
    ejecutar(titulo=args.titulo, instrucciones=args.instrucciones)
