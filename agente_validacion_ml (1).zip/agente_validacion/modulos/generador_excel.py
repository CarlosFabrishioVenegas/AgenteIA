"""
modulos/generador_excel.py
===========================
Genera el Excel de conclusiones con 4 hojas:
  1. Resumen       — cabecera + resumen ejecutivo + riesgo global
  2. Métricas      — tabla de métricas con semáforos de color
  3. Hallazgos     — tabla de hallazgos con colores por severidad
  4. Recomendaciones — tabla priorizada
"""

from pathlib import Path
from datetime import datetime
import openpyxl
from openpyxl.styles import (
    Font, PatternFill, Alignment, Border, Side, numbers
)
from openpyxl.utils import get_column_letter


# ─── COLORES (ARGB) ───────────────────────────────────────────────────────────

AZUL_OSCURO  = "FF1A3A5C"
AZUL_MEDIO   = "FF2C5F8A"
BLANCO       = "FFFFFFFF"
GRIS_BG      = "FFF4F7FB"
GRIS_HDR     = "FFD0D8E4"

VERDE_BG     = "FFD5F5E3"
VERDE_TXT    = "FF1E8B4C"
AMARILLO_BG  = "FFFFF3CD"
AMARILLO_TXT = "FF9A6100"
ROJO_BG      = "FFFDEDED"
ROJO_TXT     = "FFC0392B"

ESTADO_FILLS = {
    "APROBADO":  (PatternFill("solid", fgColor=VERDE_BG),    Font(bold=True, color=VERDE_TXT)),
    "OBSERVADO": (PatternFill("solid", fgColor=AMARILLO_BG), Font(bold=True, color=AMARILLO_TXT)),
    "RECHAZADO": (PatternFill("solid", fgColor=ROJO_BG),     Font(bold=True, color=ROJO_TXT)),
}

SEVERIDAD_FILLS = {
    "ALTA":  (PatternFill("solid", fgColor=ROJO_BG),      Font(bold=True, color=ROJO_TXT)),
    "MEDIA": (PatternFill("solid", fgColor=AMARILLO_BG),  Font(bold=True, color=AMARILLO_TXT)),
    "BAJA":  (PatternFill("solid", fgColor=VERDE_BG),     Font(bold=True, color=VERDE_TXT)),
}

RIESGO_FILLS = {
    "BAJO":  (PatternFill("solid", fgColor=VERDE_BG),    Font(bold=True, color=VERDE_TXT,    size=13)),
    "MEDIO": (PatternFill("solid", fgColor=AMARILLO_BG), Font(bold=True, color=AMARILLO_TXT, size=13)),
    "ALTO":  (PatternFill("solid", fgColor=ROJO_BG),     Font(bold=True, color=ROJO_TXT,     size=13)),
}

THIN = Side(border_style="thin", color="FFB0BEC5")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def _header_fill():
    return PatternFill("solid", fgColor=AZUL_OSCURO)

def _header_font():
    return Font(bold=True, color=BLANCO, name="Arial", size=10)

def _body_font(bold=False, size=10):
    return Font(bold=bold, name="Arial", size=size, color="FF222222")

def _center():
    return Alignment(horizontal="center", vertical="center", wrap_text=True)

def _left():
    return Alignment(horizontal="left", vertical="center", wrap_text=True)

def _set_col_widths(ws, widths: list):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

def _write_header_row(ws, row: int, cols: list):
    for i, texto in enumerate(cols, 1):
        c = ws.cell(row=row, column=i, value=texto)
        c.fill   = _header_fill()
        c.font   = _header_font()
        c.border = BORDER
        c.alignment = _center()

def _autofit_rows(ws, min_height=18):
    for row in ws.iter_rows():
        ws.row_dimensions[row[0].row].height = min_height


# ─── GENERADOR ───────────────────────────────────────────────────────────────

class GeneradorExcel:

    def __init__(self, carpeta_output: Path):
        self.carpeta = carpeta_output
        self.carpeta.mkdir(parents=True, exist_ok=True)

    def generar(self, titulo: str, analisis: dict) -> Path:
        wb = openpyxl.Workbook()
        wb.remove(wb.active)  # quitar hoja default

        self._hoja_resumen(wb, titulo, analisis)
        self._hoja_metricas(wb, analisis)
        self._hoja_hallazgos(wb, analisis)
        self._hoja_recomendaciones(wb, analisis)

        fecha = datetime.now().strftime("%Y%m%d_%H%M%S")
        nombre = f"Conclusiones_ML_{fecha}.xlsx"
        ruta = self.carpeta / nombre
        wb.save(ruta)
        return ruta

    # ── HOJA 1: RESUMEN ──────────────────────────────────────────────────────

    def _hoja_resumen(self, wb, titulo: str, analisis: dict):
        ws = wb.create_sheet("Resumen")
        ws.sheet_view.showGridLines = False

        # Título principal
        ws.merge_cells("A1:E1")
        c = ws["A1"]
        c.value     = titulo.upper()
        c.fill      = PatternFill("solid", fgColor=AZUL_OSCURO)
        c.font      = Font(bold=True, color=BLANCO, name="Arial", size=14)
        c.alignment = _center()
        ws.row_dimensions[1].height = 36

        # Metadatos
        fecha = datetime.now().strftime("%d/%m/%Y %H:%M")
        riesgo = analisis.get("nivel_riesgo_global", "MEDIO")

        meta = [
            ("Fecha de generación:", fecha),
            ("Generado por:",        "Agente IA Validación ML"),
            ("Nivel de Riesgo Global:", riesgo),
        ]
        for fila_idx, (label, valor) in enumerate(meta, 3):
            ws.cell(row=fila_idx, column=1, value=label).font = Font(bold=True, name="Arial", size=11, color="FF1A3A5C")
            c = ws.cell(row=fila_idx, column=2, value=valor)
            c.font = Font(name="Arial", size=11)
            if "Riesgo" in label:
                fill, font = RIESGO_FILLS.get(riesgo, (None, None))
                if fill:
                    ws.merge_cells(f"B{fila_idx}:C{fila_idx}")
                    c.fill      = fill
                    c.font      = font
                    c.alignment = _center()

        # Separador
        ws.row_dimensions[6].height = 6

        # Resumen ejecutivo
        ws.cell(row=7, column=1, value="RESUMEN EJECUTIVO").font = Font(bold=True, name="Arial", size=11, color="FF1A3A5C")
        ws.row_dimensions[7].height = 20
        resumen = analisis.get("resumen_ejecutivo", "")
        ws.merge_cells("A8:E15")
        c = ws["A8"]
        c.value     = resumen
        c.font      = Font(name="Arial", size=10)
        c.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
        c.fill      = PatternFill("solid", fgColor=GRIS_BG)
        c.border    = BORDER
        ws.row_dimensions[8].height = 90

        # Resumen de hallazgos por severidad
        ws.row_dimensions[17].height = 6
        ws.cell(row=18, column=1, value="RESUMEN DE HALLAZGOS").font = Font(bold=True, name="Arial", size=11, color="FF1A3A5C")
        _write_header_row(ws, 19, ["Severidad", "Cantidad", "Estado"])
        hallazgos = analisis.get("hallazgos", [])
        conteo = {"ALTA": 0, "MEDIA": 0, "BAJA": 0}
        for h in hallazgos:
            sev = h.get("severidad", "").upper()
            if sev in conteo:
                conteo[sev] += 1
        for fila_idx, (sev, cnt) in enumerate(conteo.items(), 20):
            fill, font = SEVERIDAD_FILLS.get(sev, (None, None))
            c_sev = ws.cell(row=fila_idx, column=1, value=sev)
            c_cnt = ws.cell(row=fila_idx, column=2, value=cnt)
            c_est = ws.cell(row=fila_idx, column=3, value="Con hallazgos" if cnt > 0 else "Sin hallazgos")
            for c in [c_sev, c_cnt, c_est]:
                c.border    = BORDER
                c.alignment = _center()
                c.font      = Font(name="Arial", size=10)
            if fill:
                c_sev.fill = fill
                c_sev.font = font

        _set_col_widths(ws, [28, 30, 20, 20, 20])
        _autofit_rows(ws)

    # ── HOJA 2: MÉTRICAS ─────────────────────────────────────────────────────

    def _hoja_metricas(self, wb, analisis: dict):
        ws = wb.create_sheet("Métricas")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:E1")
        c = ws["A1"]
        c.value     = "MÉTRICAS DE VALIDACIÓN"
        c.fill      = PatternFill("solid", fgColor=AZUL_OSCURO)
        c.font      = Font(bold=True, color=BLANCO, name="Arial", size=12)
        c.alignment = _center()
        ws.row_dimensions[1].height = 28

        cols = ["Métrica", "Valor", "Umbral Regulatorio", "Estado", "Interpretación"]
        _write_header_row(ws, 2, cols)

        metricas = analisis.get("metricas_clave", [])
        for i, m in enumerate(metricas, 3):
            estado = m.get("estado", "")
            fill, font = ESTADO_FILLS.get(estado, (PatternFill("solid", fgColor=GRIS_BG), _body_font()))

            row_data = [
                m.get("metrica", ""),
                m.get("valor", ""),
                m.get("umbral", "—"),
                estado,
                m.get("interpretacion", ""),
            ]
            for j, val in enumerate(row_data, 1):
                c = ws.cell(row=i, column=j, value=val)
                c.border    = BORDER
                c.font      = _body_font(bold=(j == 4))
                c.alignment = _center() if j in (2, 3, 4) else _left()
                if j == 1:
                    c.font = _body_font(bold=True)
                elif j == 4:
                    c.fill = fill
                    c.font = font

            if i % 2 == 0:
                for j in range(1, 5):
                    if j != 4:
                        ws.cell(row=i, column=j).fill = PatternFill("solid", fgColor=GRIS_BG)

        _set_col_widths(ws, [22, 14, 22, 16, 45])
        _autofit_rows(ws)

    # ── HOJA 3: HALLAZGOS ────────────────────────────────────────────────────

    def _hoja_hallazgos(self, wb, analisis: dict):
        ws = wb.create_sheet("Hallazgos")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:F1")
        c = ws["A1"]
        c.value     = "HALLAZGOS DE VALIDACIÓN"
        c.fill      = PatternFill("solid", fgColor=AZUL_OSCURO)
        c.font      = Font(bold=True, color=BLANCO, name="Arial", size=12)
        c.alignment = _center()
        ws.row_dimensions[1].height = 28

        cols = ["ID", "Categoría", "Título / Descripción", "Severidad", "Recomendación", "Plazo"]
        _write_header_row(ws, 2, cols)

        hallazgos = analisis.get("hallazgos", [])
        for i, h in enumerate(hallazgos, 3):
            sev = h.get("severidad", "MEDIA")
            fill, font = SEVERIDAD_FILLS.get(sev, (PatternFill("solid", fgColor=GRIS_BG), _body_font()))
            desc = f"{h.get('titulo', '')}\n{h.get('descripcion', '')}"

            row_data = [
                h.get("id", f"H{i-2:02d}"),
                h.get("categoria", ""),
                desc,
                sev,
                h.get("recomendacion", ""),
                h.get("plazo", "—"),
            ]
            for j, val in enumerate(row_data, 1):
                c = ws.cell(row=i, column=j, value=val)
                c.border    = BORDER
                c.alignment = _center() if j in (1, 4, 6) else _left()
                c.font      = _body_font()
                if j == 4:
                    c.fill = fill
                    c.font = font

        _set_col_widths(ws, [8, 18, 40, 14, 38, 16])
        _autofit_rows(ws, min_height=30)

    # ── HOJA 4: RECOMENDACIONES ──────────────────────────────────────────────

    def _hoja_recomendaciones(self, wb, analisis: dict):
        ws = wb.create_sheet("Recomendaciones")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:D1")
        c = ws["A1"]
        c.value     = "RECOMENDACIONES"
        c.fill      = PatternFill("solid", fgColor=AZUL_OSCURO)
        c.font      = Font(bold=True, color=BLANCO, name="Arial", size=12)
        c.alignment = _center()
        ws.row_dimensions[1].height = 28

        cols = ["#", "Recomendación", "Responsable", "Plazo"]
        _write_header_row(ws, 2, cols)

        recs = analisis.get("recomendaciones", [])
        for i, r in enumerate(recs, 3):
            row_data = [
                r.get("numero", i - 2),
                r.get("texto", ""),
                r.get("responsable", "—"),
                r.get("plazo", "—"),
            ]
            for j, val in enumerate(row_data, 1):
                c = ws.cell(row=i, column=j, value=val)
                c.border    = BORDER
                c.alignment = _center() if j in (1, 3, 4) else _left()
                c.font      = _body_font()
                if j == 1:
                    c.font = _body_font(bold=True)
                if i % 2 == 0:
                    c.fill = PatternFill("solid", fgColor=GRIS_BG)

        _set_col_widths(ws, [6, 55, 22, 16])
        _autofit_rows(ws, min_height=22)
