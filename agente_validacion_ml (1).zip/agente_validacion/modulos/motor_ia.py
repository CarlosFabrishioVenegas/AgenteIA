"""
modulos/motor_ia.py
====================
Motor del agente: llama a la API de Claude para
1) Aprender el patrón de estilo de los documentos de referencia.
2) Analizar los datos de validación ML y generar el análisis estructurado.
"""

import json
import re
import requests
from config import CONFIG


# ─── SISTEMA DE PROMPTS ──────────────────────────────────────────────────────

SYSTEM_ESTILO = """Eres un experto en análisis de documentos de validación de modelos 
de machine learning financiero (scoring crediticio, PD, LGD, EAD, IFRS 9, modelos de riesgo).

Tu tarea es analizar documentos de referencia y extraer los PATRONES de escritura y formato
para que puedan ser replicados en nuevos informes.

Responde ÚNICAMENTE con JSON válido, sin texto adicional, sin bloques markdown."""

SYSTEM_VALIDACION = """Eres un experto senior en validación de modelos de machine learning 
financiero. Tienes experiencia en:
- Scoring crediticio y modelos de riesgo (PD, LGD, EAD)
- Métricas: Gini, KS, AUC-ROC, PSI, Brier Score, Hosmer-Lemeshow
- Backtesting y stress testing de modelos
- Normativa: Basilea III, IFRS 9, SR 11-7
- Redacción de informes de validación independiente

Recibirás el patrón de estilo aprendido de informes previos y los datos de validación.
Tu objetivo es generar un análisis exhaustivo que replique fielmente el estilo de los 
documentos de referencia.

Responde ÚNICAMENTE con JSON válido, sin texto adicional, sin bloques markdown."""


# ─── PROMPTS ─────────────────────────────────────────────────────────────────

def prompt_estilo(texto_docs: str) -> str:
    return f"""Analiza los siguientes documentos de validación de modelos ML y extrae 
los patrones de escritura y formato. Documentos de referencia:

{texto_docs[:12000]}

Responde con este JSON exacto:
{{
  "tono": "descripción del tono (formal/técnico/etc)",
  "vocabulario_clave": ["término1", "término2", ...],
  "estructura_secciones": ["sección1", "sección2", ...],
  "formato_metricas": "cómo se presentan las métricas",
  "estilo_conclusiones": "cómo se redactan las conclusiones",
  "estilo_alertas": "cómo se expresan los hallazgos críticos",
  "frases_tipicas": ["frase1", "frase2", ...]
}}"""


def prompt_validacion(datos_excel: dict, patron_estilo: dict,
                      titulo: str, instrucciones: str) -> str:
    # Construir resumen de datos Excel
    resumen_excel = ""
    for fname, hojas in datos_excel.items():
        resumen_excel += f"\n{'='*60}\nARCHIVO: {fname}\n{'='*60}\n"
        for nombre_hoja, info in hojas.items():
            resumen_excel += f"\n--- HOJA: {nombre_hoja} ({info['n_filas']} filas) ---\n"
            resumen_excel += info["csv"][:3000]
            resumen_excel += "\n"

    estilo_str = json.dumps(patron_estilo, ensure_ascii=False, indent=2)

    instrucciones_extra = (
        f"\nINSTRUCCIONES ADICIONALES DEL USUARIO:\n{instrucciones}"
        if instrucciones else ""
    )

    return f"""Título del informe: {titulo}
{instrucciones_extra}

PATRÓN DE ESTILO A REPLICAR:
{estilo_str}

DATOS DE VALIDACIÓN:
{resumen_excel[:10000]}

Genera el análisis completo. Responde con este JSON exacto (sin campos adicionales):
{{
  "resumen_ejecutivo": "texto del resumen ejecutivo (2-3 párrafos)",
  "nivel_riesgo_global": "BAJO|MEDIO|ALTO",
  "modelos_analizados": [
    {{"nombre": "...", "tipo": "...", "version": "...", "descripcion": "..."}}
  ],
  "metricas_clave": [
    {{
      "metrica": "nombre de la métrica",
      "valor": "valor encontrado",
      "umbral": "umbral regulatorio o interno",
      "estado": "APROBADO|OBSERVADO|RECHAZADO",
      "interpretacion": "texto de interpretación"
    }}
  ],
  "hallazgos": [
    {{
      "id": "H01",
      "categoria": "Discriminación|Calibración|Estabilidad|Datos|Implementación",
      "titulo": "título corto del hallazgo",
      "descripcion": "descripción detallada",
      "severidad": "ALTA|MEDIA|BAJA",
      "recomendacion": "acción recomendada",
      "plazo": "Inmediato|30 días|90 días|Siguiente ciclo"
    }}
  ],
  "analisis_por_seccion": {{
    "descripcion_modelos": "texto HTML o plano con descripción detallada",
    "analisis_desempeno": "texto con análisis de métricas de desempeño",
    "pruebas_validacion": "texto con resultados de pruebas aplicadas",
    "analisis_estabilidad": "texto con análisis PSI y estabilidad poblacional",
    "conclusion_detallada": "texto con conclusión técnica detallada"
  }},
  "conclusion_general": "conclusión final del informe (2-4 párrafos)",
  "recomendaciones": [
    {{"numero": 1, "texto": "...", "responsable": "...", "plazo": "..."}}
  ],
  "proxima_validacion": "fecha o período sugerido para siguiente validación"
}}"""


# ─── MOTOR ───────────────────────────────────────────────────────────────────

class MotorIA:
    API_URL = "https://api.anthropic.com/v1/messages"
    HEADERS = {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
    }

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.headers = {**self.HEADERS, "x-api-key": api_key}

    def _llamar(self, system: str, user: str) -> str:
        payload = {
            "model": CONFIG["modelo_claude"],
            "max_tokens": CONFIG["max_tokens"],
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        resp = requests.post(self.API_URL, headers=self.headers, json=payload, timeout=120)
        resp.raise_for_status()
        data = resp.json()
        return "".join(
            bloque.get("text", "")
            for bloque in data.get("content", [])
            if bloque.get("type") == "text"
        )

    def _parsear_json(self, texto: str, fallback: dict) -> dict:
        """Limpia y parsea JSON de la respuesta."""
        limpio = re.sub(r"```(?:json)?|```", "", texto).strip()
        # Buscar primer { y último }
        inicio = limpio.find("{")
        fin    = limpio.rfind("}")
        if inicio != -1 and fin != -1:
            limpio = limpio[inicio:fin + 1]
        try:
            return json.loads(limpio)
        except json.JSONDecodeError:
            print("    [!] No se pudo parsear JSON — usando fallback")
            return fallback

    def analizar_estilo(self, texto_docs: str) -> dict:
        """
        Si no hay documentos de referencia devuelve un patrón estándar.
        Si los hay, extrae el patrón real con Claude.
        """
        if not texto_docs.strip():
            return {
                "tono": "Formal, técnico, objetivo. Lenguaje de riesgo financiero cuantitativo.",
                "vocabulario_clave": ["modelo", "validación", "discriminación", "calibración",
                                      "estabilidad", "backtesting", "umbral", "métrica"],
                "estructura_secciones": [
                    "Resumen Ejecutivo", "Alcance y Objetivo",
                    "Descripción del Modelo", "Métricas de Desempeño",
                    "Pruebas de Validación", "Hallazgos", "Conclusiones y Recomendaciones"
                ],
                "formato_metricas": "Tablas con columnas: Métrica | Valor | Umbral | Estado | Comentario",
                "estilo_conclusiones": "Conclusiones con nivel de riesgo (ALTO/MEDIO/BAJO) y "
                                       "recomendaciones accionables con plazo y responsable",
                "estilo_alertas": "Hallazgos clasificados por severidad ALTA/MEDIA/BAJA con ID único",
                "frases_tipicas": [
                    "El modelo presenta un desempeño adecuado en términos de discriminación.",
                    "Se recomienda monitorear mensualmente el indicador PSI.",
                    "El coeficiente Gini se encuentra dentro del umbral aceptable.",
                ]
            }

        raw = self._llamar(SYSTEM_ESTILO, prompt_estilo(texto_docs))
        return self._parsear_json(raw, fallback={"tono": "formal", "vocabulario_clave": []})

    def analizar_validacion(self, datos_excel: dict, patron_estilo: dict,
                            titulo: str, instrucciones: str) -> dict:
        """Análisis principal: genera el contenido completo del informe."""
        raw = self._llamar(
            SYSTEM_VALIDACION,
            prompt_validacion(datos_excel, patron_estilo, titulo, instrucciones)
        )
        fallback = {
            "resumen_ejecutivo": "Ver datos adjuntos.",
            "nivel_riesgo_global": "MEDIO",
            "modelos_analizados": [],
            "metricas_clave": [],
            "hallazgos": [],
            "analisis_por_seccion": {
                "descripcion_modelos":   "",
                "analisis_desempeno":    "",
                "pruebas_validacion":    "",
                "analisis_estabilidad":  "",
                "conclusion_detallada":  raw,
            },
            "conclusion_general": raw[:500],
            "recomendaciones": [],
            "proxima_validacion": "Próximo trimestre",
        }
        return self._parsear_json(raw, fallback)
