"""
modulos/generador_word.py
==========================
Toma el análisis del motor IA y genera un documento .docx
profesional con la estructura estándar de un informe de
validación de modelos ML financieros.
"""

from pathlib import Path
from datetime import datetime
from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import copy


# ─── PALETA DE COLORES ────────────────────────────────────────────────────────

AZUL_OSCURO  = RGBColor(0x1A, 0x3A, 0x5C)
AZUL_MEDIO   = RGBColor(0x2C, 0x5F, 0x8A)
GRIS_TEXTO   = RGBColor(0x33, 0x33, 0x33)
BLANCO       = RGBColor(0xFF, 0xFF, 0xFF)
VERDE        = RGBColor(0x27, 0xAE, 0x60)
AMARILLO_BG  = RGBColor(0xFF, 0xF3, 0xCD)
ROJO         = RGBColor(0xC0, 0x39, 0x2B)
AMARILLO     = RGBColor(0xF3, 0x9C, 0x12)
GRIS_BG      = RGBColor(0xF4, 0xF7, 0xFB)
AZUL_HEADER  = RGBColor(0x1A, 0x3A, 0x5C)

ESTADO_COLOR = {
    "APROBADO":  (RGBColor(0xD5, 0xF5, 0xE3), RGBColor(0x1E, 0x8B, 0x4C)),
    "OBSERVADO": (RGBColor(0xFF, 0xF3, 0xCD), RGBColor(0x9A, 0x61, 0x00)),
    "RECHAZADO": (RGBColor(0xFD, 0xED, 0xED), RGBColor(0xC0, 0x39, 0x2B)),
}

SEVERIDAD_COLOR = {
    "ALTA":  (RGBColor(0xFD, 0xED, 0xED), RGBColor(0xC0, 0x39, 0x2B)),
    "MEDIA": (RGBColor(0xFF, 0xF3, 0xCD), RGBColor(0x9A, 0x61, 0x00)),
    "BAJA":  (RGBColor(0xD5, 0xF5, 0xE3), RGBColor(0x1E, 0x8B, 0x4C)),
}

RIESGO_COLOR = {
    "BAJO":  RGBColor(0x27, 0xAE, 0x60),
    "MEDIO": RGBColor(0xF3, 0x9C, 0x12),
    "ALTO":  RGBColor(0xC0, 0x39, 0x2B),
}


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def _set_cell_bg(cell, color: RGBColor):
    """Aplica color de fondo a una celda."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    hex_color = f"{color[0]:02X}{color[1]:02X}{color[2]:02X}"
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def _cell_margins(cell, top=80, bottom=80, left=120, right=120):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = OxmlElement("w:tcMar")
    for side, val in [("top", top), ("bottom", bottom), ("left", left), ("right", right)]:
        m = OxmlElement(f"w:{side}")
        m.set(qn("w:w"), str(val))
        m.set(qn("w:type"), "dxa")
        tcMar.append(m)
    tcPr.append(tcMar)


def _add_run(para, texto: str, bold=False, color: RGBColor = None,
             size_pt: int = None, italic=False) -> None:
    run = para.add_run(texto)
    run.bold   = bold
    run.italic = italic
    if color:
        run.font.color.rgb = color
    if size_pt:
        run.font.size = Pt(size_pt)


def _add_heading(doc: Document, texto: str, level: int) -> None:
    para = doc.add_heading(texto, level=level)
    for run in para.runs:
        run.font.color.rgb = AZUL_OSCURO


def _horizontal_rule(doc: Document) -> None:
    """Añade una línea horizontal."""
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "1A3A5C")
    pBdr.append(bottom)
    pPr.append(pBdr)


# ─── GENERADOR ───────────────────────────────────────────────────────────────

class GeneradorWord:

    def __init__(self, carpeta_output: Path):
        self.carpeta = carpeta_output
        self.carpeta.mkdir(parents=True, exist_ok=True)

    def generar(self, titulo: str, analisis: dict) -> Path:
        doc = Document()
        self._configurar_estilos(doc)
        self._portada(doc, titulo, analisis)
        self._tabla_contenido_manual(doc, analisis)
        self._resumen_ejecutivo(doc, analisis)
        self._modelos_analizados(doc, analisis)
        self._metricas(doc, analisis)
        self._hallazgos(doc, analisis)
        self._analisis_secciones(doc, analisis)
        self._conclusiones(doc, analisis)
        self._recomendaciones(doc, analisis)
        self._pie_pagina(doc, titulo)

        fecha = datetime.now().strftime("%Y%m%d_%H%M%S")
        nombre = f"Validacion_ML_{fecha}.docx"
        ruta = self.carpeta / nombre
        doc.save(ruta)
        return ruta

    # ── ESTILOS GLOBALES ─────────────────────────────────────────────────────

    def _configurar_estilos(self, doc: Document):
        from docx.oxml.ns import nsmap
        style = doc.styles["Normal"]
        style.font.name  = "Arial"
        style.font.size  = Pt(11)
        style.font.color.rgb = GRIS_TEXTO

        for nivel, tamaño, negrita in [
            ("Heading 1", 14, True),
            ("Heading 2", 12, True),
            ("Heading 3", 11, True),
        ]:
            s = doc.styles[nivel]
            s.font.name  = "Arial"
            s.font.size  = Pt(tamaño)
            s.font.bold  = negrita
            s.font.color.rgb = AZUL_OSCURO

        # Márgenes de página
        for section in doc.sections:
            section.page_width   = Cm(21.59)  # US Letter
            section.page_height  = Cm(27.94)
            section.top_margin   = Cm(2.54)
            section.bottom_margin = Cm(2.54)
            section.left_margin  = Cm(2.54)
            section.right_margin = Cm(2.54)

    # ── PORTADA ──────────────────────────────────────────────────────────────

    def _portada(self, doc: Document, titulo: str, analisis: dict):
        doc.add_paragraph()
        doc.add_paragraph()
        doc.add_paragraph()

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_run(p, "INFORME DE VALIDACIÓN", bold=True, color=AZUL_MEDIO, size_pt=13)

        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_run(p2, titulo, bold=True, color=AZUL_OSCURO, size_pt=18)

        doc.add_paragraph()
        _horizontal_rule(doc)
        doc.add_paragraph()

        fecha = datetime.now().strftime("%d de %B de %Y")
        riesgo = analisis.get("nivel_riesgo_global", "MEDIO")

        meta = [
            ("Fecha de emisión:", fecha),
            ("Nivel de riesgo global:", riesgo),
            ("Generado por:", "Agente IA de Validación de Modelos"),
        ]
        for label, valor in meta:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _add_run(p, f"{label}  ", bold=True, color=AZUL_MEDIO, size_pt=11)
            color_v = RIESGO_COLOR.get(riesgo, GRIS_TEXTO) if "riesgo" in label.lower() else GRIS_TEXTO
            _add_run(p, valor, bold="riesgo" in label.lower(), color=color_v, size_pt=11)

        doc.add_page_break()

    # ── TABLA DE CONTENIDO MANUAL ────────────────────────────────────────────

    def _tabla_contenido_manual(self, doc: Document, analisis: dict):
        _add_heading(doc, "Tabla de Contenido", 1)
        secciones = [
            "1. Resumen Ejecutivo",
            "2. Modelos Analizados",
            "3. Métricas de Desempeño",
            "4. Hallazgos",
            "5. Análisis Detallado",
            "6. Conclusiones",
            "7. Recomendaciones",
        ]
        for s in secciones:
            p = doc.add_paragraph(s, style="List Bullet")
        doc.add_paragraph()

    # ── RESUMEN EJECUTIVO ────────────────────────────────────────────────────

    def _resumen_ejecutivo(self, doc: Document, analisis: dict):
        doc.add_page_break()
        _add_heading(doc, "1. Resumen Ejecutivo", 1)

        riesgo = analisis.get("nivel_riesgo_global", "MEDIO")
        color_bg, color_txt = {
            "BAJO":  (RGBColor(0xD5, 0xF5, 0xE3), VERDE),
            "MEDIO": (RGBColor(0xFF, 0xF3, 0xCD), AMARILLO),
            "ALTO":  (RGBColor(0xFD, 0xED, 0xED), ROJO),
        }.get(riesgo, (GRIS_BG, GRIS_TEXTO))

        # Caja de nivel de riesgo
        tabla = doc.add_table(rows=1, cols=1)
        tabla.style = "Table Grid"
        celda = tabla.cell(0, 0)
        _set_cell_bg(celda, color_bg)
        _cell_margins(celda, top=120, bottom=120, left=200, right=200)
        p = celda.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _add_run(p, f"NIVEL DE RIESGO GLOBAL: {riesgo}", bold=True, color=color_txt, size_pt=13)

        doc.add_paragraph()
        resumen = analisis.get("resumen_ejecutivo", "")
        for parrafo in resumen.split("\n"):
            if parrafo.strip():
                p = doc.add_paragraph(parrafo.strip())
                p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    # ── MODELOS ANALIZADOS ───────────────────────────────────────────────────

    def _modelos_analizados(self, doc: Document, analisis: dict):
        _add_heading(doc, "2. Modelos Analizados", 1)
        modelos = analisis.get("modelos_analizados", [])
        if not modelos:
            doc.add_paragraph("No se identificaron modelos específicos en los datos.")
            return

        tabla = doc.add_table(rows=1, cols=4)
        tabla.style = "Table Grid"
        tabla.alignment = WD_TABLE_ALIGNMENT.CENTER

        encabezados = ["Modelo", "Tipo", "Versión", "Descripción"]
        for i, enc in enumerate(encabezados):
            celda = tabla.cell(0, i)
            _set_cell_bg(celda, AZUL_HEADER)
            _cell_margins(celda)
            p = celda.paragraphs[0]
            _add_run(p, enc, bold=True, color=BLANCO, size_pt=10)

        for m in modelos:
            fila = tabla.add_row()
            vals = [
                m.get("nombre", ""),
                m.get("tipo", ""),
                m.get("version", ""),
                m.get("descripcion", ""),
            ]
            for i, val in enumerate(vals):
                celda = fila.cells[i]
                _cell_margins(celda)
                celda.paragraphs[0].add_run(str(val)).font.size = Pt(10)

        desc = analisis.get("analisis_por_seccion", {}).get("descripcion_modelos", "")
        if desc:
            doc.add_paragraph()
            for parrafo in desc.split("\n"):
                if parrafo.strip():
                    p = doc.add_paragraph(parrafo.strip())
                    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    # ── MÉTRICAS ─────────────────────────────────────────────────────────────

    def _metricas(self, doc: Document, analisis: dict):
        _add_heading(doc, "3. Métricas de Desempeño", 1)
        metricas = analisis.get("metricas_clave", [])
        if not metricas:
            doc.add_paragraph("No se extrajeron métricas de los datos proporcionados.")
            return

        tabla = doc.add_table(rows=1, cols=5)
        tabla.style = "Table Grid"

        encabezados = ["Métrica", "Valor", "Umbral", "Estado", "Interpretación"]
        for i, enc in enumerate(encabezados):
            celda = tabla.cell(0, i)
            _set_cell_bg(celda, AZUL_HEADER)
            _cell_margins(celda)
            _add_run(celda.paragraphs[0], enc, bold=True, color=BLANCO, size_pt=10)

        for m in metricas:
            fila = tabla.add_row()
            estado = m.get("estado", "")
            bg_color, txt_color = ESTADO_COLOR.get(estado, (GRIS_BG, GRIS_TEXTO))

            vals = [
                (m.get("metrica", ""), True, None),
                (m.get("valor", ""), False, None),
                (m.get("umbral", "—"), False, None),
                (estado, True, txt_color),
                (m.get("interpretacion", ""), False, None),
            ]
            for i, (val, bold, color) in enumerate(vals):
                celda = fila.cells[i]
                _cell_margins(celda)
                if i == 3:
                    _set_cell_bg(celda, bg_color)
                run = celda.paragraphs[0].add_run(str(val))
                run.bold = bold
                run.font.size = Pt(10)
                if color:
                    run.font.color.rgb = color

        texto = analisis.get("analisis_por_seccion", {}).get("analisis_desempeno", "")
        if texto:
            doc.add_paragraph()
            _add_heading(doc, "Análisis de Desempeño", 2)
            for parrafo in texto.split("\n"):
                if parrafo.strip():
                    p = doc.add_paragraph(parrafo.strip())
                    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    # ── HALLAZGOS ────────────────────────────────────────────────────────────

    def _hallazgos(self, doc: Document, analisis: dict):
        _add_heading(doc, "4. Hallazgos", 1)
        hallazgos = analisis.get("hallazgos", [])
        if not hallazgos:
            doc.add_paragraph("No se identificaron hallazgos críticos.")
            return

        tabla = doc.add_table(rows=1, cols=6)
        tabla.style = "Table Grid"

        encabezados = ["ID", "Categoría", "Hallazgo", "Severidad", "Recomendación", "Plazo"]
        for i, enc in enumerate(encabezados):
            celda = tabla.cell(0, i)
            _set_cell_bg(celda, AZUL_HEADER)
            _cell_margins(celda)
            _add_run(celda.paragraphs[0], enc, bold=True, color=BLANCO, size_pt=10)

        for h in hallazgos:
            fila = tabla.add_row()
            severidad = h.get("severidad", "MEDIA")
            bg_color, txt_color = SEVERIDAD_COLOR.get(severidad, (GRIS_BG, GRIS_TEXTO))

            vals = [
                h.get("id", ""),
                h.get("categoria", ""),
                f"{h.get('titulo', '')}\n{h.get('descripcion', '')}",
                severidad,
                h.get("recomendacion", ""),
                h.get("plazo", ""),
            ]
            for i, val in enumerate(vals):
                celda = fila.cells[i]
                _cell_margins(celda)
                if i == 3:
                    _set_cell_bg(celda, bg_color)
                run = celda.paragraphs[0].add_run(str(val))
                run.bold = (i == 3)
                run.font.size = Pt(9)
                if i == 3:
                    run.font.color.rgb = txt_color

    # ── ANÁLISIS POR SECCIÓN ─────────────────────────────────────────────────

    def _analisis_secciones(self, doc: Document, analisis: dict):
        secciones = analisis.get("analisis_por_seccion", {})
        _add_heading(doc, "5. Análisis Detallado", 1)

        for subtitulo, clave in [
            ("5.1 Pruebas de Validación",   "pruebas_validacion"),
            ("5.2 Análisis de Estabilidad", "analisis_estabilidad"),
        ]:
            texto = secciones.get(clave, "")
            if texto:
                _add_heading(doc, subtitulo, 2)
                for parrafo in texto.split("\n"):
                    if parrafo.strip():
                        p = doc.add_paragraph(parrafo.strip())
                        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    # ── CONCLUSIONES ─────────────────────────────────────────────────────────

    def _conclusiones(self, doc: Document, analisis: dict):
        _add_heading(doc, "6. Conclusiones", 1)
        conclusion = analisis.get("conclusion_general", "")
        for parrafo in conclusion.split("\n"):
            if parrafo.strip():
                p = doc.add_paragraph(parrafo.strip())
                p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

        detalle = analisis.get("analisis_por_seccion", {}).get("conclusion_detallada", "")
        if detalle:
            doc.add_paragraph()
            for parrafo in detalle.split("\n"):
                if parrafo.strip():
                    p = doc.add_paragraph(parrafo.strip())
                    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

        proxima = analisis.get("proxima_validacion", "")
        if proxima:
            doc.add_paragraph()
            p = doc.add_paragraph()
            _add_run(p, "Próxima validación sugerida:  ", bold=True, color=AZUL_MEDIO)
            _add_run(p, proxima)

    # ── RECOMENDACIONES ──────────────────────────────────────────────────────

    def _recomendaciones(self, doc: Document, analisis: dict):
        _add_heading(doc, "7. Recomendaciones", 1)
        recs = analisis.get("recomendaciones", [])
        if not recs:
            doc.add_paragraph("Sin recomendaciones adicionales.")
            return

        tabla = doc.add_table(rows=1, cols=4)
        tabla.style = "Table Grid"
        encabezados = ["#", "Recomendación", "Responsable", "Plazo"]
        for i, enc in enumerate(encabezados):
            celda = tabla.cell(0, i)
            _set_cell_bg(celda, AZUL_HEADER)
            _cell_margins(celda)
            _add_run(celda.paragraphs[0], enc, bold=True, color=BLANCO, size_pt=10)

        for r in recs:
            fila = tabla.add_row()
            vals = [
                str(r.get("numero", "")),
                r.get("texto", ""),
                r.get("responsable", "—"),
                r.get("plazo", "—"),
            ]
            for i, val in enumerate(vals):
                celda = fila.cells[i]
                _cell_margins(celda)
                run = celda.paragraphs[0].add_run(val)
                run.font.size = Pt(10)

    # ── PIE DE PÁGINA ────────────────────────────────────────────────────────

    def _pie_pagina(self, doc: Document, titulo: str):
        from docx.oxml import OxmlElement
        fecha = datetime.now().strftime("%d/%m/%Y")
        for section in doc.sections:
            footer = section.footer
            p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
            p.clear()
            _horizontal_rule(doc)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _add_run(p,
                     f"{titulo}  ·  Generado: {fecha}  ·  Agente IA Validación ML",
                     color=RGBColor(0x88, 0x88, 0x88), size_pt=9)
