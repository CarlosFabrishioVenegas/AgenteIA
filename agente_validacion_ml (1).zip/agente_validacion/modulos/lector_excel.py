"""
modulos/lector_excel.py
========================
Lee todos los archivos Excel de la carpeta datos_validacion/
y devuelve un diccionario estructurado por archivo y hoja.
"""

from pathlib import Path
import pandas as pd
from config import CONFIG


class LectorExcel:
    EXTENSIONES = {".xlsx", ".xls", ".xlsm"}

    def __init__(self, carpeta: Path):
        self.carpeta = carpeta

    def leer_todos(self) -> dict:
        """
        Retorna:
        {
          "nombre_archivo.xlsx": {
            "Hoja1": {
              "dataframe": pd.DataFrame,
              "csv":       str,          # versión CSV para el prompt
              "columnas":  list[str],
              "n_filas":   int,
            },
            ...
          },
          ...
        }
        """
        if not self.carpeta.exists():
            return {}

        archivos = [
            f for f in self.carpeta.iterdir()
            if f.suffix.lower() in self.EXTENSIONES
        ]
        resultado = {}
        max_filas = CONFIG.get("max_filas_excel", 200)

        for archivo in archivos:
            try:
                xf = pd.ExcelFile(archivo)
                hojas = {}
                for nombre_hoja in xf.sheet_names:
                    df = xf.parse(nombre_hoja)
                    df = df.dropna(how="all").fillna("")

                    # Muestra parcial para el prompt (evitar tokens excesivos)
                    df_muestra = df.head(max_filas)
                    csv_str = df_muestra.to_csv(index=False)

                    hojas[nombre_hoja] = {
                        "dataframe": df,
                        "csv":       csv_str,
                        "columnas":  list(df.columns),
                        "n_filas":   len(df),
                    }
                resultado[archivo.name] = hojas
            except Exception as e:
                print(f"    [!] No se pudo leer {archivo.name}: {e}")

        return resultado
