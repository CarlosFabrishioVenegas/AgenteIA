"""
modulos/lector_formatos.py
===========================
Lee los documentos Word del repositorio de formatos
y extrae su contenido de texto para que el motor IA
aprenda el estilo, vocabulario y estructura de los informes.
"""

from pathlib import Path
from docx import Document


class LectorFormatos:
    EXTENSIONES = {".docx", ".doc"}

    def __init__(self, carpeta: Path):
        self.carpeta = carpeta
        self.n_docs = 0
        self._documentos: list[dict] = []

    def extraer_estilo(self) -> str:
        """
        Lee todos los .docx del repositorio y devuelve
        un string con el contenido concatenado para el prompt.
        """
        if not self.carpeta.exists():
            return ""

        archivos = [
            f for f in self.carpeta.iterdir()
            if f.suffix.lower() in self.EXTENSIONES
        ]
        if not archivos:
            return ""

        textos = []
        for archivo in archivos:
            texto = self._leer_docx(archivo)
            if texto:
                self._documentos.append({"nombre": archivo.name, "texto": texto})
                textos.append(f"=== DOCUMENTO: {archivo.name} ===\n{texto}\n")

        self.n_docs = len(self._documentos)
        return "\n".join(textos)

    def _leer_docx(self, path: Path) -> str:
        """Extrae texto plano de un .docx respetando párrafos y tablas."""
        try:
            doc = Document(path)
            partes = []

            for elem in doc.element.body:
                tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag

                if tag == "p":
                    # Párrafo normal
                    from docx.oxml.ns import qn
                    texto = "".join(r.text for r in elem.iter(qn("w:t")))
                    if texto.strip():
                        partes.append(texto.strip())

                elif tag == "tbl":
                    # Tabla — extraer como texto tabulado
                    from docx.oxml.ns import qn
                    for fila in elem.iter(qn("w:tr")):
                        celdas = []
                        for celda in fila.iter(qn("w:tc")):
                            txt = "".join(r.text for r in celda.iter(qn("w:t")))
                            celdas.append(txt.strip())
                        if any(celdas):
                            partes.append(" | ".join(celdas))

            return "\n".join(partes)

        except Exception as e:
            print(f"    [!] No se pudo leer {path.name}: {e}")
            return ""
