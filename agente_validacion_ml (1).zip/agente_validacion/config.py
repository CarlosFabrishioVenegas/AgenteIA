"""
config.py — Configuración del Agente
=====================================
Modifica CONFIG para ajustar rutas y credenciales.
"""

import os

CONFIG = {
    # ── Tu API key de Anthropic ─────────────────────────────────────────────
    # Puedes setearla como variable de entorno: export ANTHROPIC_API_KEY="sk-..."
    # O escribirla directamente aquí (no recomendado para producción)
    "api_key": os.getenv("ANTHROPIC_API_KEY", "TU_API_KEY_AQUI"),

    # ── Carpetas del proyecto ────────────────────────────────────────────────
    # Coloca aquí tus informes .docx de referencia (para aprender el estilo)
    "repositorio_formatos": "repositorio_formatos",

    # Coloca aquí tus Excel .xlsx con las métricas de validación ML
    "datos_validacion": "datos_validacion",

    # Los archivos generados se guardan aquí
    "outputs": "outputs",

    # ── Parámetros del modelo ────────────────────────────────────────────────
    "modelo_claude": "claude-sonnet-4-20250514",
    "max_tokens": 4000,

    # Cuántos caracteres de texto de cada documento de referencia usar
    # (más = mejor aprendizaje de estilo, más costo de tokens)
    "max_chars_por_doc": 4000,

    # Cuántas filas de cada hoja Excel incluir en el prompt
    "max_filas_excel": 200,
}
