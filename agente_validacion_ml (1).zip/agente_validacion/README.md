# Agente IA · Validación de Modelos ML Financieros

Sistema de documentación generativa que aprende el estilo de tus informes previos
y produce automáticamente un documento Word + Excel de conclusiones a partir de
los datos de validación en Excel.

---

## Estructura del proyecto

```
agente_validacion/
│
├── agente.py                    ← PUNTO DE ENTRADA — ejecuta esto
├── config.py                    ← Configura tu API key y rutas
│
├── repositorio_formatos/        ← PON AQUÍ tus informes .docx de referencia
│   ├── informe_q1_2024.docx
│   ├── informe_q2_2024.docx
│   └── ...
│
├── datos_validacion/            ← PON AQUÍ tus Excel de validación ML
│   ├── scoring_crediticio.xlsx
│   ├── modelo_pd_2025.xlsx
│   └── ...
│
├── outputs/                     ← Los archivos generados aparecen aquí
│   ├── Validacion_ML_20250101_120000.docx
│   └── Conclusiones_ML_20250101_120000.xlsx
│
└── modulos/
    ├── lector_formatos.py       ← Lee .docx de referencia, extrae estilo
    ├── lector_excel.py          ← Parsea todos los Excel de validación
    ├── motor_ia.py              ← Llama a Claude (aprendizaje + análisis)
    ├── generador_word.py        ← Genera el .docx profesional
    └── generador_excel.py       ← Genera el .xlsx de conclusiones
```

---

## Instalación

```bash
pip install python-docx openpyxl pandas requests
```

---

## Configuración

Edita `config.py` y pon tu API key de Anthropic:

```python
"api_key": "sk-ant-...",
```

O expórtala como variable de entorno:

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

---

## Uso

### Básico

```bash
python agente.py
```

### Con título personalizado

```bash
python agente.py --titulo "Validación Modelo Scoring Retail Q1 2025"
```

### Con instrucciones adicionales al agente

```bash
python agente.py \
  --titulo "Validación Modelo PD Corporativo" \
  --instrucciones "Incluir análisis PSI por segmento, enfatizar pruebas de backtesting 2022-2024"
```

---

## Qué espera en cada carpeta

### `repositorio_formatos/` (opcional pero recomendado)
Coloca aquí tus informes Word previos (.docx). El agente leerá estos documentos
y aprenderá:
- Tono y estilo de redacción
- Vocabulario técnico específico de tu organización
- Estructura de secciones que usas
- Cómo presentas métricas y alertas

Si la carpeta está vacía, el agente usará un estilo estándar de validación ML.

### `datos_validacion/`
Coloca aquí tus Excel (.xlsx) con los datos de validación. Pueden tener:
- Múltiples archivos (uno por modelo, por período, etc.)
- Múltiples hojas por archivo
- Cualquier estructura — el agente interpreta el contenido

Ejemplos de qué puedes poner:
- Tabla de métricas (Gini, KS, AUC, PSI)
- Resultados de backtesting por año
- Comparativo de versiones de modelos
- Distribución de scores por deciles
- Matrices de confusión

---

## Outputs generados

### `Validacion_ML_YYYYMMDD_HHMMSS.docx`
Documento Word profesional con:
- Portada con nivel de riesgo global
- Tabla de contenido
- Resumen ejecutivo
- Modelos analizados (tabla)
- Métricas de desempeño (tabla con semáforos)
- Hallazgos por severidad (ALTA/MEDIA/BAJA)
- Análisis detallado por sección
- Conclusiones
- Recomendaciones con responsable y plazo

### `Conclusiones_ML_YYYYMMDD_HHMMSS.xlsx`
Excel con 4 hojas:
1. **Resumen** — Cabecera + resumen ejecutivo + conteo de hallazgos
2. **Métricas** — Tabla con estado APROBADO/OBSERVADO/RECHAZADO (colores)
3. **Hallazgos** — Tabla con severidad ALTA/MEDIA/BAJA (colores)
4. **Recomendaciones** — Lista priorizada con responsable y plazo

---

## Flujo interno del agente

```
repositorio_formatos/*.docx
        │
        ▼
[lector_formatos.py]  ←── Extrae texto de los Word
        │
        ▼
[motor_ia.py]  ──── Claude aprende el estilo ────►  patrón_estilo
        │
datos_validacion/*.xlsx
        │
        ▼
[lector_excel.py]  ←── Parsea todas las hojas
        │
        ▼
[motor_ia.py]  ──── Claude analiza los datos ────►  análisis_json
        │
        ├──► [generador_word.py]  →  outputs/Validacion_ML_*.docx
        │
        └──► [generador_excel.py] →  outputs/Conclusiones_ML_*.xlsx
```
