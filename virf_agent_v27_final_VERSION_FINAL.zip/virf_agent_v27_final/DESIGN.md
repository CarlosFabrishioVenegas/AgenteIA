# DESIGN.md — VIRF Agent · capa visual «Sello institucional»

Rediseño de la interfaz web (dirección A, elegida el 2026-11-18). Solo capa visual: no cambia endpoints, ids ni lógica.

## Dónde vive

| Archivo | Qué es |
| --- | --- |
| `web/static/css/ui-sello.css` | Tokens y componentes. Se carga **después** de `styles.css` y lo sobrescribe. |
| `web/static/js/ui.js` | Comportamiento solo visual: tema, zonas de carga, guía acoplada, filtros de Mis Modelos. No llama a la API. |
| `web/templates/index.html` | Enlaza los dos archivos, aplica el tema antes de pintar y añade clases `si-sec--*` a las secciones de Solo Informe. |
| `web/app.py` | El token de caché `?v=` cubre también los dos archivos nuevos. |
| `_respaldo_ui/20261118_antes_rediseno/` | Copia de `index.html`, `styles.css`, `app.js` y `guia.js` antes del cambio. |
| `diseno_ui/direcciones/` | Las tres maquetas de dirección (A, B, C). |

**Revertir:** quitar las dos líneas `ui-sello.css` y `ui.js` de `index.html` vuelve al aspecto anterior. Los cambios en `app.js` (atributos `data-*` e iconos de estado) y en `guia.js` (botón secundario) son compatibles con ambas capas.

## Principios

1. **Una sola cosa en acento.** El bermellón es la acción principal de la pantalla y lo crítico. Nada más va en rojo: ni la navegación ni los estados neutros.
2. **El estado nunca depende solo del color.** Icono + texto + color: `○ Sin iniciar`, `◐ En progreso`, `✓ Completado`.
3. **Usar el ancho.** Barra lateral | contenido | guía. El contenido es fluido hasta 1400 px y la guía se acopla como columna desde 1280 px.
4. **Texto legible.** Cuerpo 15 px; nada por debajo de 13 px; rótulos en minúsculas, sin versalitas espaciadas.
5. **Movimiento funcional y opcional.** 150–250 ms en hover, foco, pulsación y entrada de la guía; con `prefers-reduced-motion` se apaga.

## Tokens

### Color (oscuro por defecto · claro con `html[data-theme="light"]`)

| Token | Oscuro | Claro | Uso |
| --- | --- | --- | --- |
| `--c-fondo` | `#0F1217` | `#F5F4F1` | Fondo de página, campos |
| `--c-capa` | `#171B23` | `#FFFFFF` | Tarjetas, paneles, lateral, guía |
| `--c-capa-2` | `#1F2430` | `#F0EEEA` | Hover, elemento activo |
| `--c-linea` / `--c-linea-2` | `#2C3340` / `#3B4454` | `#DEDAD2` / `#C9C3B8` | Filetes y bordes |
| `--c-texto` | `#E6E8EC` | `#1B1E24` | Texto principal |
| `--c-texto-2` | `#AEB4C0` | `#4A505C` | Texto secundario, rótulos |
| `--c-texto-3` | `#959CAA` | `#5E6470` | Metadatos |
| `--c-acento` / `-hover` | `#B9493B` / `#C95848` | `#A63D30` / `#8F3327` | Acción principal, crítico |
| `--c-acento-txt` | `#F08B79` | `#A63D30` | Acento como texto |
| `--c-ok`, `--c-warn`, `--c-mal`, `--c-info` (+ `-fondo`) | ver archivo | ver archivo | Estados |
| `--c-foco` | `#9DB2D6` | `#34507F` | Anillo de foco (no rojo: el rojo es acción) |

Contraste medido en la app real (912 textos en Mis Modelos, Expediente con guía, Evidencia y Solo Informe, en ambos temas): **mínimo 5.13:1**; ninguno bajo 4.5:1.

Los nombres antiguos de `styles.css` (`--tinta`, `--capa`, `--texto-mu`, `--sello`…) quedan como **puente** hacia estos tokens, por lo que las reglas existentes heredan el tema sin reescribirse.

### Tipografía

| Token | Valor | Uso |
| --- | --- | --- |
| `--f-serif` | Newsreader | Marca y títulos de pantalla (con mesura) |
| `--f-sans` | Inter | Todo lo demás |
| `--f-mono` | IBM Plex Mono | Códigos de modelo, números de paso, rutas, log |
| `--t-xs` | 13 px | Rótulos, metadatos, insignias (mínimo de la interfaz) |
| `--t-sm` | 14 px | Tablas, texto secundario |
| `--t-base` | 15 px | Cuerpo y campos |
| `--t-md` | 17 px | Títulos de sección |
| `--t-lg` | 22 px | Títulos de panel |
| `--t-xl` | 30 px | Título de pantalla |

### Espacio, radios, movimiento, disposición

- Espacio: `--s-1…7` = 4 · 8 · 12 · 16 · 24 · 32 · 48 px.
- Radios: `--r-1` 4 · `--r-2` 6 (controles) · `--r-3` 10 (tarjetas) · `--r-pill`.
- Movimiento: `--m-rapido` 150 ms · `--m-medio` 200 ms · `--m-lento` 250 ms · curva `cubic-bezier(.2,.7,.2,1)`.
- Disposición: `--ancho-lateral` 272 px · `--ancho-guia` 380 px · `--ancho-contenido` 1400 px · `--alto-control` 40 px.

## Componentes

| Componente | Clase | Estados |
| --- | --- | --- |
| Botón principal | `.btn--primary` | hover, active (1 px abajo), disabled, foco. **Uno por pantalla.** |
| Botón secundario / fantasma | `.btn--sec`, `.btn--ghost`, `.btn` | ídem |
| Campo | `.field` + `.field__label` + `.field__control` | hover, foco (borde + halo info) |
| Tarjeta | `.panel`, `.config-section` en Solo Informe | — |
| Zona de carga | `.zona-carga` (envuelve el `input[type=file]` original) | hover, arrastre (`.is-drag`), foco, archivos seleccionados |
| Insignia de estado | `.chip--sin-iniciar` · `--en-progreso` · `--completado` | icono + texto + color |
| Tabla | `.tabla-modelos` dentro de `.tabla-scroll` | cabecera fija, fila clicable con hover y foco |
| Resumen y filtros | `.modelos-resumen`, `.modelos-filtros` | recuento «n de m», vacío «Ningún modelo coincide…» |
| Barra de progreso | `.guia__barra` | `role="progressbar"` con valores |
| Panel lateral (guía) | `.guia` + `html.guia-abierta` | acoplado ≥1280 px; cajón con sombra en tableta |

## Comportamiento visual (ui.js)

- **Tema:** botón «Modo claro / Modo oscuro» en la cabecera de Mis Modelos / Solo Informe y en el pie de la barra lateral. Se guarda en `localStorage` (`virf-tema`) y se aplica antes del primer pintado.
- **Zonas de carga:** cada `input[type=file].field__control` se envuelve en una zona con arrastrar y soltar. El input es el mismo elemento (mismo id, mismos listeners); el `change` lo dispara la zona al soltar.
- **Guía acoplada:** se abre sola al entrar a un expediente con ≥1440 px salvo que el validador la haya cerrado (`virf-guia`). Abierta, el contenido se estrecha en vez de quedar tapado.
- **Mis Modelos:** resumen (total por dominio, en progreso, completados, tiers), búsqueda por nombre o código y filtros por estado, tier y dominio. Usa los `data-*` que pinta `app.js`.
