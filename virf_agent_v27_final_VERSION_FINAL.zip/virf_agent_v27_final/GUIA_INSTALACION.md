# Guía de instalación paso a paso — VIRF Agent

> Checklist para instalar y verificar el agente en una máquina nueva.
> Marca cada casilla al terminar. Si un paso falla, **para** y mira su fila «Si falla».
>
> Los pasos 1 a 7 tienen **coste 0** (no llaman a ninguna IA). Solo el paso 8 llama
> a Azure OpenAI.
> Referencias: `README.md` §2 y §2-bis · `RUNBOOK.md` · `REMEDIACION_SEG.md`

---

## Antes de empezar

- [ ] Python **3.10 o superior** (`python --version`).
- [ ] Git (solo si vas a clonar el repositorio; si recibiste el `.zip`, no hace falta).
- [ ] Acceso a internet hacia el índice oficial de PyPI (`pypi.org`) para instalar paquetes.
- [ ] Un editor de texto para el `.env`.
- [ ] Solo para llamar a la IA (paso 8): lo que entrega IT — endpoint, *deployment name*,
      api-version y acceso a la clave (Key Vault o variable de entorno).

> Los comandos usan la sintaxis de Windows (`.venv\Scripts\...`). En Linux/macOS
> cambia `.venv\Scripts\python` por `.venv/bin/python`.

---

## Paso 1 — Descomprimir y entrar a la carpeta

```bash
unzip virf_agent_v27_final_copia.zip      # o clic derecho → Extraer todo
cd virf_agent_v27_final
```

- [ ] Ves en la raíz: `agente.py`, `requirements.txt`, `web/`, `config/`, `inputs/`.

> El zip **no incluye** `.env`, `.venv` ni `.git`. Se crean en los pasos siguientes.

---

## Paso 2 — Crear el entorno virtual limpio

```bash
python -m venv .venv
.venv\Scripts\python -m pip install --upgrade pip
```

- [ ] Existe la carpeta `.venv`.

| ⛔ Por qué un `.venv` limpio |
|---|
| El Python del sistema puede traer paquetes **retirados por política** (`chromadb`, `torch`, Hugging Face). Usa siempre el `.venv`, nunca el Python global. |

---

## Paso 3 — Instalar las dependencias

Son **dos** archivos: el del agente y el de la web.

```bash
.venv\Scripts\python -m pip install -r requirements.txt -r web/requirements_web.txt
```

- [ ] Termina sin errores.
- [ ] `pip check` no reporta conflictos:

```bash
.venv\Scripts\python -m pip check
```

Debe decir `No broken requirements found.`

**Qué debes saber de `requirements.txt`:**

| Punto | Detalle |
|---|---|
| Versiones | Todas fijas con `==` (reproducibilidad del dictamen). |
| Origen | Solo PyPI oficial. Sin `--index-url`, sin `git+` ni URLs directas. |
| Cuatro paquetes nuevos | `azure-identity`, `azure-keyvault-secrets`, `msal` y `reportlab` se añadieron el 2026-11-11 y quedaron **instaladas y verificadas el 2026-11-18** (`pip check` limpio, imports OK, suite en verde). Los pasos 6 y 7 lo repiten en tu máquina. |
| Fuera de requirements | `pyspark` solo se usa en Databricks, que ya lo trae. |

| Si falla |
|---|
| Error de compilación en `numpy`/`pandas`/`lxml` → versión de Python demasiado nueva o antigua. Usa 3.10–3.12. |
| Error SSL / certificado en la red corporativa → pide a IT el certificado raíz; ver `config/red.py` (`VIRF_TLS_ALMACEN_SISTEMA=1` usa el almacén del sistema y requiere `truststore`, ya incluido). |

---

## Paso 4 — Comprobar que NO hay paquetes prohibidos

```bash
.venv\Scripts\python -m pip list | findstr /i "torch transformers huggingface chromadb sentence pytesseract"
```

- [ ] **No devuelve nada.** Si aparece alguno, el entorno no es el limpio: bórralo y repite desde el paso 2.

---

## Paso 5 — Crear el `.env` (solo configuración, sin secretos)

```bash
copy .env.example .env
```

Abre `.env` y descomenta/completa **solo** lo no secreto:

```ini
MODO=debug                    # desarrollo local; sin esto rige MODO=produccion
AZURE_OPENAI_ENDPOINT=https://<recurso>.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=<Deployment name del portal, NO el nombre del modelo>
AZURE_OPENAI_API_VERSION=2024-10-21
```

- [ ] `.env` creado y completado.
- [ ] **No hay ninguna clave** (`AZURE_OPENAI_API_KEY`, `ANTHROPIC_API_KEY`…) escrita en el `.env`.

| ⛔ Regla de seguridad (SEG-03) |
|---|
| Si el agente encuentra una **clave escrita en el `.env`**, se niega a usarla y pide rotarla. Las claves van en Key Vault, Databricks secrets o como variable del **proceso** (solo en desarrollo). |

| Error común |
|---|
| `AZURE_OPENAI_DEPLOYMENT` es el **Deployment name** del portal. Poner `gpt-4o` cuando tu deployment se llama `gpt4o-prod` da `DeploymentNotFound` (404). |
| Anthropic y OpenAI directo están **bloqueados** por decisión del banco: el único proveedor que ejecuta es `azure_openai`. |

---

## Paso 6 — Verificar la instalación (coste 0)

```bash
.venv\Scripts\python validate_project.py --strict
```

- [ ] Termina con **0 FAIL** y código de salida 0 (el README esperaba 146/146 PASS; el número puede variar, lo que importa es 0 FAIL).

Comprueba también que los imports de los cuatro paquetes nuevos funcionan:

```bash
.venv\Scripts\python -c "import azure.identity, azure.keyvault.secrets, msal, reportlab; print('OK imports nuevos')"
```

- [ ] Imprime `OK imports nuevos`.

| Si falla |
|---|
| Un FAIL en `validate_project.py` → léelo: dice qué archivo o regla. No sigas hasta corregirlo. |
| Los WARN suelen ser evidencia ausente en `inputs/` y son tolerables. |

---

## Paso 7 — Correr la suite de tests (coste 0, IA simulada)

```bash
.venv\Scripts\python -m pytest -q
```

- [ ] Termina sin fallos (tarda unos 6 minutos; usa IA simulada, no gasta).

> Para una comprobación rápida de las dependencias: `.venv\Scripts\python -m pytest tests -q -k "requirements or dependenc or fijad"`.

---

## Paso 8 — Conexión con la IA (único paso con coste)

**8.1 Dar la clave al proceso (no al `.env`).** Elige una fuente (`VIRF_FUENTE_SECRETOS`):

| Fuente | Cuándo | Qué necesitas |
|---|---|---|
| `keyvault` (defecto) | Producción | `VIRF_KEYVAULT_URL` + `az login` o Managed Identity. El secreto se llama `azure-openai-api-key`. |
| `databricks` | En Databricks | `VIRF_SECRET_SCOPE` |
| `entorno` | Solo desarrollo | Variable de la **shell**, no del `.env` (prohibido con `MODO=produccion`) |

Ejemplo de desarrollo en PowerShell:

```powershell
$env:VIRF_FUENTE_SECRETOS = "entorno"
$env:AZURE_OPENAI_API_KEY = "<la clave que te dio IT>"
```

**8.2 Probar la conexión:**

```bash
.venv\Scripts\python agente.py --verificar-conexion-azure
```

- [ ] Sale `✅ azure_openai conectado — modelo: … — latencia: … ms`.

| ⛔ Criterio de parada |
|---|
| Si sale con **código 1**, para. El mensaje indica qué variable revisar. Nada más funcionará hasta resolverlo. |

---

## Paso 9 — Arrancar la web

**Opción A — Prueba local (sin SSO).** Escribes un nombre, eliges roles y entras. Solo funciona fuera de producción; lo que firmes queda marcado «usuario de prueba (sin SSO)».

```bash
.venv\Scripts\python scripts/web_prueba.py
```

**Opción B — Corporativa (SSO Microsoft Entra ID).** Requiere el registro de la app y las variables `VIRF_ENTRA_TENANT_ID`, `VIRF_ENTRA_CLIENT_ID`, `VIRF_ENTRA_REDIRECT_URI`. Ver `docs/LOGIN_CORPORATIVO_WEB_V3.md`.

```bash
.venv\Scripts\python -m uvicorn web.app:app --port 8000
```

- [ ] Abres `http://localhost:8000` y carga la página.
- [ ] `http://localhost:8000/api/salud` responde `{"estado":"ok"}`.

> Sin Entra ID registrado, en la opción B el botón «Entrar con cuenta corporativa» responde **503** y nombra las variables que faltan. Es lo esperado, no un fallo de instalación.

---

## Paso 10 — Primera validación de prueba (opcional)

Antes de gastar, **siempre** el pre-vuelo (coste 0):

```bash
.venv\Scripts\python agente.py --prevuelo
```

Coloca la evidencia en `inputs/` (ver `GUIA_LLENAR_INPUTS.md`). Sin el **manual metodológico** en `inputs/documentacion/modelamiento/` el contraste no sirve. Flujo completo en `RUNBOOK.md`.

---

## Resumen: lista de verificación final

- [ ] Python ≥ 3.10 y `.venv` creado
- [ ] `requirements.txt` + `web/requirements_web.txt` instalados, `pip check` limpio
- [ ] Sin `torch` / `transformers` / `huggingface` / `chromadb` en el `.venv`
- [ ] `.env` creado, **sin claves**
- [ ] `validate_project.py --strict` con 0 FAIL
- [ ] Imports de `azure.identity`, `azure.keyvault.secrets`, `msal`, `reportlab` OK
- [ ] `pytest -q` sin fallos
- [ ] `--verificar-conexion-azure` conectado
- [ ] Web responde en `/api/salud`

## Pendientes humanos que bloquean **producción** (no la instalación)

Rotar claves, crear el Key Vault, registrar la app en Entra ID con sus *app roles*, nombrar aprobadores de código, destino de la bitácora (SIEM), pentest/DAST y actualizar 6 dependencias vulnerables. Lista completa en `gobierno/go_no_go.md` y `gobierno/backlog.csv`.

## Notas

- **PDFs escaneados:** no se pueden leer (el OCR se retiró por política). Conviértelos a texto antes de ponerlos en `inputs/`.
- **No hay RAG vectorial:** el RAG es léxico (BM25 + TF-IDF), 100 % local, sin descargar modelos.
- **Sin `.git` en el zip:** si necesitas el historial, pide los `.bundle` (`virf_agent_golden1.bundle`, `virf_agent_pre_migracion.bundle`) aparte.
