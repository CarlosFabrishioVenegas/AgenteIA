# Guía de traspaso de contexto — VIRF Agent (edición exhaustiva)

> **Objetivo:** que otra persona, otra IA o tú mismo en otra computadora podáis retomar el proyecto
> **sin ninguna duda abierta**: qué es, cómo funciona por dentro, qué reglas no se rompen, qué hay que
> cambiar si cambia la IA o la máquina, **cómo** cambiarlo, **dónde** medir que sigue bien y qué hacer
> cuando algo falla.
>
> Estado de referencia: **2026-11-18** · rama de trabajo `docs/firma-sin-validador` · último commit
> `b742a5e` · rama principal `main` **local y sin remoto** · suite: 1827 passed, 2 skipped
> (1 prueba conocida en rojo: ver §19.3).

## Cómo está organizada la documentación (léela en este orden)

| # | Documento | Es… | Cuándo |
|---|---|---|---|
| 1 | **Esta guía** | Texto escrito y revisado a mano: el *porqué* y el *cómo* | Primero |
| 2 | [`REFERENCIA_TECNICA.md`](REFERENCIA_TECNICA.md) | **Generada del código**: flags, 127 variables de entorno, endpoints, parámetros de negocio, catálogo de modelos, dependencias, pruebas, nodos centrales | Para datos exactos (no envejecen) |
| 3 | [`INVENTARIO_ARCHIVOS.md`](INVENTARIO_ARCHIVOS.md) | **Generada**: una línea por archivo | Para ubicar un archivo |
| 4 | `graphify-out/GRAPH_REPORT.md` y `graph.json` | **Generada**: grafo de código (8089 nodos) | Para navegar dependencias |
| 4b | [`AUDITORIA_ANTIALUCINACION.md`](AUDITORIA_ANTIALUCINACION.md) | Auditoría de los controles contra invención de la IA: qué hay, qué se cerró el 2026-11-18, qué sigue abierto y cómo medirlo con la IA real | Antes de confiar en una IA nueva o de cambiar prompts/citas |
| 5 | `README.md` · `GUIA_INSTALACION.md` · `RUNBOOK.md` · `FLAGS.md` · `HANDOFF_AGENTE.md` · `PROCEDIMIENTO_VALIDACION.md` · `REMEDIACION_SEG.md` | Documentos de dominio ya existentes | Según el tema |

**Regla de oro de esta documentación:** lo que *envejece* (flags, variables, endpoints, archivos, tests)
está **generado**; lo que *no* envejece (principios, decisiones, recetas) está **escrito**. Si ves una
discrepancia, manda el código y se regenera (§18).

---

## Índice

0. Prompt de arranque para una IA nueva
1. Qué es el proyecto, para quién y qué NO es
2. Glosario
3. Principios no negociables
4. Mapa del repositorio
5. Anatomía de una corrida (de la evidencia al informe)
6. El modelo de puntaje, exacto
7. Estándar Excel, ámbitos e inputs
8. Datos que produce y guarda el sistema (formatos y ubicaciones)
9. La web: sesiones, roles, pantallas y modos de trabajo
10. Seguridad: capas y qué las rompe
11. **Cambiar de IA** (qué, cómo, dónde medir)
12. **Cambiar de computadora** (qué, cómo, dónde medir)
13. Dónde medir: mapa completo de instrumentos
14. Recetas: cómo hacer cada tipo de cambio
15. Parámetros ajustables (guía de criterio)
16. Decisiones ya tomadas (no reabrir)
17. Errores frecuentes → causa → solución
18. Cómo regenerar la documentación y el grafo
19. Estado actual, pendientes y lo que NO está medido
20. La memoria del asistente no viaja con el repositorio
21. Checklists finales

---

## 0. Prompt de arranque para una IA nueva

Pégalo tal cual al abrir el proyecto con otro asistente:

```text
Lee primero GUIA_TRASPASO_CONTEXTO.md (enteros §1-§5 y §16), luego HANDOFF_AGENTE.md.
Datos exactos: REFERENCIA_TECNICA.md. Ubicar archivos: INVENTARIO_ARCHIVOS.md.
Navegar dependencias: graphify-out/GRAPH_REPORT.md (comandos: graphify query/path/explain/affected).

Reglas duras (no negociables):
1) Usa SIEMPRE el entorno .venv (nunca el Python del sistema).
2) No toques .env; solo .env.example.
3) No cambies config/ia.py -> PROVEEDORES: la lista la decide el banco, no el código.
4) Los tests son coste 0 (IA simulada). Nunca llames a una IA real para probar código.
5) Sin detección automática: modos y proveedores se eligen con flags/variables explícitas.
6) RAG léxico (BM25 + TF-IDF): nada de embeddings, ChromaDB, HuggingFace ni vector stores.
7) No lances POSTs a ciegas contra la web en marcha: escriben en rutas globales.
8) Todo parámetro nuevo se declara en config/parametros.py; no leer el entorno en otro sitio.
9) Antes de proponer un cambio corre la suite y confirma que sigue en verde.
10) No reabras decisiones de GUIA_TRASPASO_CONTEXTO.md §16.
Explica los cambios en español y en lenguaje simple. Verifica antes de afirmar que algo funciona.
```

---

## 1. Qué es el proyecto, para quién y qué NO es

**VIRF Agent** es un validador autónomo de modelos de riesgo financiero (VaR, LaR/liquidez, ALM y
conductuales) para la Gerencia de Validación Interna de Riesgo Financiero. Lee la evidencia de un modelo
(manual metodológico, seguimiento, código, calidad de datos, usos), la contrasta contra un **estándar**
(`inputs/Estandares_VIRF.xlsx`) y un **corpus de referencia** (RAG), y produce observaciones puntuadas,
un Excel de acta y un informe Word. Anclajes normativos: SR 11-7, EBA/GL/2023/01, BCBS 239.

**Quién decide:** el **validador humano** decide y firma; el agente **propone**. El score del agente no se
reescribe nunca: el puntaje validado por el humano se recomputa aparte (§6.5).

**Qué NO es:** no es un sistema que apruebe modelos por sí solo; no ejecuta modelos de terceros no
aprobados; no hace OCR; no recupera por vectores; no cambia de proveedor por su cuenta en producción.

Tecnología: Python 3.10+ y FastAPI. Dos puertas de entrada:

| Puerta | Qué es | Arranque |
|---|---|---|
| **CLI** | `agente.py` con flags explícitos (tabla completa en `REFERENCIA_TECNICA.md` §1) | `.venv\Scripts\python agente.py <flags>` |
| **Web** | FastAPI en `web/` (sesiones por validador y modelo, chat de sustentación, informes) | Prueba: `.venv\Scripts\python scripts/web_prueba.py` · Corporativa: `.venv\Scripts\python -m uvicorn web.app:app --port 8000` |

---

## 2. Glosario

| Término | Significado |
|---|---|
| **Ámbito** | Una de las 6 dimensiones de la validación (§6.2). Sus nombres deben coincidir *exactamente* (tildes y mayúsculas) en 4 sitios (§7.2) |
| **Actividad / control** | Una fila del estándar Excel (columna `ACTIVIDAD`). En «Solo Informe», cada actividad es un «control» |
| **Tier** | Criticidad del modelo: I, II, III, IV (`--tier 1..4` se normaliza a romano). Filtra qué actividades aplican |
| **Evidencia** | Documentos y código en `inputs/` (o en la carpeta de la sesión web) |
| **Prevuelo** | Chequeo gratuito de qué podrá leer y evaluar el agente antes de gastar |
| **RAG léxico** | Recuperación de literatura de referencia por BM25 + TF-IDF, 100 % local |
| **Dominio RAG** | Corpus por tipo de modelo: `LaR`, `VaR`, `ALM`, `shared` (+ dominios personalizados). `conductuales` es alias legacy de `ALM` |
| **Gateway** | `ClienteIA` en `config/ia.py`: único punto por el que sale una llamada a la IA |
| **PII** | Datos personales; se enmascaran antes de salir (`modulos/pii.py`) |
| **Entailment / NLI** | Juez que comprueba si la cita realmente implica la observación (`modulos/entailment.py`) |
| **Abstención** | El agente se niega a puntuar cuando la evidencia es insuficiente (`modulos/abstencion.py`) |
| **HITL** | *Human in the loop*: el chat de sustentación y la consolidación |
| **Cadena de custodia** | Hash encadenado de cada informe (`modulos/custodia.py`) |
| **Fallo técnico** | Fallo del agente (timeout, PDF ilegible, JSON roto): **excluido** del promedio; no se imputa al validado |
| **Sin evidencia** | Falta del validado: puntúa **0.0** |
| **VIRF PLUS** | Claude + GPT con árbitro; flag explícito; bloqueado mientras Claude no esté aprobado |
| **Solo Informe** | Apartado web que genera el Word sin ejecutar el pipeline |
| **Validación completa** | Modalidad con 5 chats por etapa que entrega notebooks `ITERn` (§9.5) |
| **SEG-nn** | Hallazgo de seguridad de la remediación del banco (detalle en `REMEDIACION_SEG.md`) |
| **Fixture** | Modelo de prueba sintético: `VaR_FRTB` (coherente) y `VaR_FixtureDrift` (4 discrepancias plantadas) |

---

## 3. Principios no negociables

| Principio | Consecuencia práctica | Dónde se vigila |
|---|---|---|
| **No evaluar sobre el vacío** | Un ámbito sin evidencia puntúa 0.0 y se declara; un fallo de **lectura** es del agente, no del validado (invariante 3) | `METODOLOGIA_DEL_AGENTE.md` §11; tests de integridad |
| **Un flag = un modo** | Nada de «detectar el tipo de entrada». Excepción acotada: el *proveedor* de IA se deduce de la clave presente **solo en `MODO=debug|desarrollo`** (con dos claves gana GPT; VIRF PLUS sigue siendo flag) | `tests/test_deteccion_proveedor.py` |
| **Cero modelos externos no aprobados** | Sin OCR, sin embeddings, sin HuggingFace/ChromaDB. Un PDF escaneado no se lee y se declara fallo técnico | `validate_project.py` (guardia HF), `tests/test_validador_entorno_hf.py` |
| **Seguridad por defecto** | `MODO=produccion` es el default del código; claves solo en Key Vault/scope/entorno del proceso | `tests/test_credenciales.py`, `test_proveedores_ia.py` |
| **Tests a coste cero** | La IA se simula: `modulos.motor_ia._llamar_modelo`, `VIRF_MOCK_CHAT=1`, `simular_aprobacion` (`tests/conftest.py`) | toda la suite |
| **Una sola fuente de configuración** | Todo parámetro se declara en `config/parametros.py`; el entorno **no se lee en ningún otro sitio** | `tests/test_regresion.py::TestConfigCentral` |
| **Flujos reutilizables** | Si se pide un entregable concreto, se construye el generador que lo produce para cualquier modelo | preferencia del usuario |
| **Código retirado no se reactiva** | `archivo/` y `_respaldo_ui/` son históricos | — |
| **Sin `exec`/`eval` en producción** | Se valida sintaxis con `ast.parse`; el código de la IA solo corre tras aprobación por hash y aislado | `tests/test_ejecucion_codigo.py` |

---

## 4. Mapa del repositorio

Detalle archivo por archivo: [`INVENTARIO_ARCHIVOS.md`](INVENTARIO_ARCHIVOS.md).

| Carpeta | Contenido | Se toca cuando… |
|---|---|---|
| `agente.py` | Punto de entrada CLI (`main()`, argparse) | Añades un modo/flag |
| `motor/Mx_00…Mx_04` | Pipeline: rutas y constantes de dominio → lectura de evidencia → prompts → llamada a la IA → motor de controles de datos | Cambias el flujo o los prompts base |
| `config/` | `parametros.py` (todos los ajustables) · `dominio.py` (negocio) · `ia.py` (proveedores y gateway) · `modelos.py` (catálogo y precios) · `secretos.py` · `identidad.py` (SSO) · `red.py` (proxy/TLS/host permitido) · `rutas.py` · `tools.py` · `virf_plus.py` | Cambias de IA, entorno o límites |
| `modulos/` | Lógica de negocio (62 archivos): motor IA, informes, PII, inyección, citas, auditoría, caché, feedback, skills, prevuelo, repositorio de controles, validación completa… | Cambias reglas o salidas |
| `src/rag/` | RAG léxico por dominio (`LaR/`, `VaR/`, `ALM/`, `shared/`, `custom_retriever.py`, `tesauro.py`) | Cambias recuperación o corpus |
| `skills/` | 6 skills tipadas (documentación, calidad de datos, metodología, gobierno, implementación, uso) + cola HITL | Añades capacidades |
| `web/routers`, `web/services` | Endpoints y su lógica | Cambias la web |
| `web/static/js`, `web/templates` | Frontend (JS plano) | Cambias pantallas |
| `inputs/` | Evidencia, corpus RAG (`inputs/rag/<dominio>/`), repositorio de controles, estándar | Cargas un modelo |
| `modelos/` | Fixtures sintéticos | Pruebas con modelos de referencia |
| `tests/`, `pruebas/` | Suite pytest, E2E sintético, red-team OWASP LLM, kit QA | Siempre |
| `gobierno/`, `docs/seguridad/`, `docs/` | Normativa, RACI, go/no-go, backlog, SCA/SAST, guías | Políticas |
| `audit_logs/`, `feedback/`, `outputs/`, `web/data/` | **Estado vivo** | Se respaldan; no se editan |
| `scripts/` | Utilidades: generadores de documentación, RAG, observabilidad, QA | Mantenimiento |
| `archivo/`, `_respaldo_ui/` | Retirado/respaldos | Nunca |
| `graphify-out/` | Grafo de código | Se regenera (§18) |

Los **hubs** del grafo (lo más conectado, donde un cambio se propaga más): `agente.py`/`main()`,
`modulos/motor_ia.py`, `config/ia.py`/`get_cliente_ia()`, `modulos/plantilla_bcp.py`,
`modulos/generador_word.py`, `web/services/informe_web.py`, `modulos/validacion_completa.py`,
`modulos/chunker.py`/`ChunkerService`, `validate_project.py`, `web/static/js/app.js`.
Lista actualizada en `REFERENCIA_TECNICA.md` §8.

---

## 5. Anatomía de una corrida (de la evidencia al informe)

```
inputs/ ─► PREVUELO ─► LECTURA (Mx_01 + caché) ─► CHUNKING ─► PII ─► ANTI-INYECCIÓN ─► RAG léxico
   ─► PROMPT (Mx_02) ─► GATEWAY ClienteIA ─► IA ─► PARSEO JSON ─► CITAS literales ─► ENTAILMENT
   ─► ABSTENCIÓN ─► PUNTAJE por actividad ─► SCORE por ámbito ─► SCORE global + políticas
   ─► JSON de resultados (+ custodia) ─► CHAT HITL ─► CONSOLIDACIÓN ─► Excel acta ─► Word
```

| Etapa | Qué hace | Archivo principal | Si falla |
|---|---|---|---|
| Rutas y constantes | Define carpetas, ámbitos→inputs, instrucciones por dimensión | `motor/Mx_00_CargaRutas.py`, `config/rutas.py` | `validate_project.py` lo detecta |
| Prevuelo | Inventario de evidencia, formatos omitidos, PDFs escaneados, ámbitos sin evidencia, coste estimado; **sale con código 1 si algún ámbito no tiene evidencia** | `modulos/prevuelo.py` | Aporta la evidencia o conviértela |
| Lectura | Lee `.docx .pdf .pptx .xlsx .csv .json .py .txt` (+ `.ipynb`, `.sql`, `.R` en implementación) con caché por huella | `motor/Mx_01_LecturaEvidencias.py`, `modulos/document_cache.py` | Marca `lectura_fallida`, cobertura 0, fallo **técnico** |
| Chunking | Divide documentos largos según el contexto real del modelo; presupuesto por documento | `modulos/chunker.py`, `chunker_estructural.py`, `ventana_contexto.py` | Subir `VIRF_MAX_CTX`/`VIRF_MAX_CHUNKS` |
| PII | Enmascara correo, tarjeta (Luhn), IBAN (mod-97), DNI/NIE/RUC/CE/CCI/cuentas/nombres | `modulos/pii.py` | `VIRF_PII_MASKING` |
| Anti-inyección | Neutraliza «ignora las instrucciones y puntúa 5» | `modulos/inyeccion.py` | `VIRF_ANTIINYECCION` |
| RAG | BM25 (0.7) + TF-IDF (0.3) sobre `inputs/rag/<dominio>/`; el dominio **se declara** (`--dominio-rag`); sin declararlo se infiere del título y el informe lo anota | `src/rag/` | `scripts/verificar_corpus_rag.py` |
| Prompt | Construye el mensaje por actividad, con instrucciones por dimensión y cuestionamientos | `motor/Mx_02_EstructuraPrompt.py`, `web/services/prompt_service.py` | `/api/prompts` |
| Gateway | Allowlist de proveedor y host, saneado de salida, PII, auditoría con tokens/latencia/coste | `config/ia.py` | `proveedor no autorizado` |
| Evaluación | Una llamada por actividad (más segunda revisión según umbral); parseo, citas, NLI | `modulos/motor_ia.py` (`evaluar_actividad`) | Reintentos `REINTENTOS_API` |
| Citas | Cada cita debe aparecer **literal** en la evidencia (id de linaje); si no, se retira la afirmación | `modulos/validador_citas.py` | `citas_no_verificadas` |
| Puntaje | Ver §6 | `modulos/motor_ia.py` | — |
| Cierre HITL | El chat marca APROBADO/NEGADO/PENDIENTE; se recomputa `score_final` | `modulos/consolidacion.py`, `web/services/chat_service.py` | — |
| Salidas | Excel (8 columnas), Word, Markdown de trabajo, JSON | `modulos/exportador_excel.py`, `generador_word.py`, `generador_markdown.py`, `web/services/informe_web.py` | — |

**Modos del CLI** (un flag = un modo; lista exacta en `REFERENCIA_TECNICA.md` §1): pipeline completo
(`--prdc`, con `--titulo` y `--tier`), pre-producción (itera con feedback), `--control` (por control de
calidad de datos + `--excel`), `--prevuelo`, `--explicar-modelo` (+ `--dry-run`, `--excluir`,
`--solo-coincidentes`), `--revisar-codigo`, `--convertir-excel` (Excel → notebook), `--controles-a-notebook`,
`--cuadro-automatizaciones` (+ `--sin-ia`), `--virf-plus`, `--skills`/`--listar-skills`,
`--listar-motores`, `--estadisticafeedback`, `--cache-stats`/`--limpiar-cache`/`--no-cache`,
`--verificar-conexion-azure`, `--raiz-evidencia` (un modelo por raíz), `--estandares` (estándar alternativo).

---

## 6. El modelo de puntaje, exacto

### 6.1 Escala por actividad (1–5)

| Puntaje | Etiqueta | Color |
|---:|---|---|
| 1 | No cumple | `FF0000` |
| 2 | Cumple parcialmente – obs. críticas | `FF6600` |
| 3 | Cumple parcialmente | `FFCC00` |
| 4 | Cumple con observaciones menores | `92D050` |
| 5 | Cumple plenamente | `00B050` |

### 6.2 Pesos por ámbito (suman exactamente **1,00**)

| Ámbito | Peso | Ancla normativa |
|---|---:|---|
| Documentación | 0,15 | EBA/GL/2023/01 §6.3 |
| Calidad de datos | 0,20 | BCBS 239 principios 3-5 |
| Metodología | 0,30 | SR 11-7 §IV conceptual soundness |
| Gobierno | 0,12 | EBA/GL/2023/01 §5 |
| Implementación | 0,15 | SR 11-7 §IV outcome analysis |
| Uso e integración a la gestión | 0,08 | SR 11-7 §IV ongoing monitoring |

Fuente: `config/dominio.py` (`AMBITO_PESOS`, `AMBITO_PESOS_REFS`). **No se ajustan con variables de
entorno**: se cambian «con criterio de validación y trazabilidad regulatoria». El informe registra los
pesos usados (`agente.pesos_ambito`).

### 6.3 Score por ámbito y score global (0–5)

- **Score de ámbito** = promedio de los puntajes de sus actividades (`calcular_score_ambito`).
  - Sin evidencia → la actividad vale **0.0** y arrastra el promedio (falta imputable al validado).
  - Fallo técnico del agente → **se excluye** del promedio (no imputable al validado).
  - Si **ninguna** actividad pudo evaluarse por fallo técnico → el ámbito vale `None`.
  - Como el mínimo real de una actividad evaluada es 1.0, **score 0.0 ⟺ sin evidencia** (el semáforo lo
    rotula «SIN EVIDENCIA»).
- **Score global** = suma ponderada de ámbitos (`calcular_score_global`).
  - Un ámbito en 0.0 entra **con su peso íntegro** (ejemplo documentado: Gobierno sin evidencia da 2,66
    contando 0.0, en vez de 3,02 si se excluyera).
  - Un ámbito `None` se excluye y los pesos se **renormalizan**.
  - Global `None` solo si ningún ámbito pudo evaluarse: no hay dictamen que emitir.

### 6.4 Semáforo y políticas

| Rango del score | Etiqueta | Color |
|---|---|---|
| 4,5 – 5,0 | SATISFACTORIO | `00B050` |
| 3,5 – 4,5 | ACEPTABLE | `92D050` |
| 2,5 – 3,5 | CON OBSERVACIONES | `FFCC00` |
| 1,5 – 2,5 | DEFICIENTE | `FF6600` |
| 0,0 – 1,5 | CRÍTICO | `FF0000` |

Políticas (`PROCEDIMIENTO_VALIDACION.md`, confirmadas por la entidad el 2026-08-12):
`criticos_automaticos` = ámbitos con score **≤ 2,0** (§6) · `veto_por_ambito` = ámbitos con score
**< 2,5** (§4.2: impide aprobar aunque el global supere el umbral) · `puede_aprobarse` = sin veto ni
críticos (**informativo, no vinculante**: firma el humano). Un ámbito ≤ 2 aparece en ambas listas a
propósito. Los ámbitos `None` se ignoran.

### 6.5 Consolidación (cierre HITL)

El score inicial del agente **no se toca** (vara comparable entre corridas y sellada en la custodia).
`score_final` se recomputa aparte (`modulos/consolidacion.py`):

| Decisión del chat | Efecto |
|---|---|
| APROBADO | El ítem queda «Cumple»: puntaje = `VIRF_PUNTAJE_CUMPLE` (5,0; acotado a 1–5) |
| NEGADO | No conformidad **confirmada**: mantiene su puntaje |
| PENDIENTE | Queda abierto: mantiene su puntaje |
| Sin decisión | Igual que estaba |

Por tanto `score_final` **solo puede subir** (vía subsanaciones aprobadas). Un feedback solo afecta a los
puntajes tras la aprobación de un revisor distinto del autor (SEG-08).

### 6.6 «Solo Informe» (reglas propias, decididas por el usuario)

Cada actividad del estándar es un «control»; una **Oportunidad de Mejora** no incumple el control y no lleva
responsable ni fecha; **>2 críticas → Deficiente · 1–2 → Regular · «Aceptable» nunca lleva críticas**;
el estándar se filtra por Tier. Código: `modulos/reglas_informe.py` (puro, sin IA).

---

## 7. Estándar Excel, ámbitos e inputs

### 7.1 `inputs/Estandares_VIRF.xlsx`

Hojas `Hoja1` (34 filas × 8 columnas) y `Hoja2` (19 × 2). En `Hoja1` la **fila 2** es el encabezado:
`AMBITO · CONTROL CUANTITATIVO Y CUALITATIVO · ACTIVIDAD · TIER I · TIER II · TIER III · TIER IV`; cada fila
siguiente es una actividad y una **`X`** en la columna de un Tier indica que aplica a ese Tier. El lector
(`web/services/solo_informe_service.py`, `motor/Mx_01`) busca columnas **por palabra clave** y tolera celdas
combinadas. `scripts/reconstruir_estandar_desde_informes.py` puede reconstruirlo desde informes y
`create_estandares_excel.py` es solo un stub de referencia. Cada validador puede subir **su** estándar por
sesión (`web/services/estandares_service.py`, flag `--estandares`) sin tocar el global.

### 7.2 Los 4 sitios donde los nombres de ámbito deben coincidir

`AMBITO_PESOS` (`config/dominio.py`) · columna `AMBITO` del Excel · `AMBITO_A_INPUTS`
(`motor/Mx_00_CargaRutas.py`) · `PREGUNTAS_METODOLOGICAS`. **Una tilde distinta rompe el pipeline en
silencio.** Lo verifican `validate_project.py` (bloque 4) y `test_ambitos_coinciden_en_los_cuatro_sistemas`.

### 7.3 Qué carpeta de `inputs/` alimenta cada ámbito

| Ámbito | Carpetas (`AMBITO_A_INPUTS`) |
|---|---|
| Documentación | `doc_modelamiento`, `doc_seguimiento`, `papers` |
| Calidad de datos | `calidad_datos`, `doc_modelamiento` |
| Metodología | `doc_modelamiento`, `papers`, `doc_seguimiento` |
| Gobierno | `doc_modelamiento`, `implementacion` |
| Implementación | `implementacion`, `doc_modelamiento` |
| Uso e integración a la gestión | `usos`, `implementacion` |

Carpetas reales (`config/rutas.py: INPUTS`): `inputs/documentacion/modelamiento` (**imprescindible: el
manual metodológico**; sin él no hay contraste), `inputs/documentacion/seguimiento`, `inputs/papers`,
`inputs/calidad_datos` (+ `datasets/`), `inputs/implementacion` (`.py .ipynb .sql .R`; subcarpetas se
recorren), `inputs/usos`, `repositorio_informes`. **No se leen:** `.scala .yaml .do .sas` (hay que
registrarlos en `LECTORES_EXT`; el prevuelo los lista). Guía de llenado: `GUIA_LLENAR_INPUTS.md`.

---

## 8. Datos que produce y guarda el sistema

### 8.1 JSON de resultados (`outputs/<fecha>/resultados_<modelo>_<fecha>.json`)

Claves de primer nivel: `modelo, tier, fecha, agente, integridad, score_global, semaforo,
scores_por_ambito, politicas_procedimiento, tabla_validacion, resultados_por_ambito,
controles_calidad_datos, override_validador, custodia`.

| Bloque | Contiene |
|---|---|
| `agente` | versión, modelo y proveedor de IA, pesos, caché activo, huellas de ejecución y de documentos, estándar usado, prompts, nº de documentos, caracteres de evidencia, dominio RAG y su procedencia (declarado/inferido), huella del corpus |
| `integridad` | actividades evaluadas OK / sin evidencia / con fallo técnico, detalle de fallos, **`dictamen_confiable`** |
| `tabla_validacion` (una fila por actividad) | `ambito, control, actividad, tier, resultado, evaluacion_sustentada, fuente_revisada, accion_requerida, puntaje, es_fallo_tecnico, citas_no_verificadas, va_al_chat` |
| `override_validador` | correcciones del humano, ajustes al alza/baja, autores |
| `custodia` | hash de este informe, hash del anterior, posición en la cadena, tipo de corrida, algoritmo, versión de evidencia |

Contrato tipado de salida (Pydantic): `modulos/esquemas.py` (`ValidationClaim`, `ValidationReport`, estados
de requisito). Un informe con `dictamen_confiable=false` **no debe usarse como dictamen**.

### 8.2 Estado vivo (se respalda, no se edita a mano)

| Ruta | Qué es | Notas |
|---|---|---|
| `audit_logs/auditoria_acciones.jsonl` | Una entrada por acción web y por llamada a la IA (quién, qué, tokens, latencia, coste), encadenada | Base de `scripts/generar_observabilidad.py` |
| `audit_logs/registro_emisiones.jsonl` | Registro **append-only** de informes emitidos (control preventivo de doble emisión) | **Respaldar y restaurar** antes/después de validaciones reales; ya hubo una contaminación por tests (`…contaminado-por-tests-20260803.jsonl`) |
| `feedback/historial_feedback.json`, `feedback/registro_validadores.json` | Aprendizaje por feedback y registro de validadores | `POST` a ciegas lo escribe |
| `outputs/<fecha>/` | JSON, Markdown de trabajo, Word, Excel de la corrida | Por fecha |
| `data/cache/` (`CACHE_DIR`) | Caché de documentos por huella SHA-256; **cifrada en reposo**; con bloqueo (`VIRF_CACHE_LOCK_*`) | `--cache-stats`, `--limpiar-cache` |
| `web/data/sesiones/<validador>/<MODELO_SLUG>/` | `sesion.json` (dominio, tier, fechas, estado), `inputs/`, `outputs/` (+ `capturas/`), chat | **gitignored**; retención `VIRF_RETENCION_DIAS` (30) |
| `web/data/validadores.json`, `dominios_custom.json` | Registro de validadores y dominios RAG personalizados | — |
| `inputs/rag/<dominio>/` + índice léxico (`RAG_INDICE_DIR`, carpeta distinta de `data/vectordb/`) | Corpus y su índice `.pkl` **firmado** (`modulos/pickle_firmado.py`) | `scripts/rebuild_rag_databricks.py` |

---

## 9. La web

### 9.1 Sesiones

Cada validador tiene una carpeta y cada modelo una subcarpeta (slug en mayúsculas con `_`; regex
`^[A-Z0-9][A-Z0-9_\-]{1,63}$`). El modelo activo va en la cookie `virf_modelo`. Dos validadores en dos
modelos trabajan en paralelo sin colisión (cada uno tiene su `Run` en `pipeline_runner.py`, que lanza
`agente.py --prdc` como **subproceso**).

### 9.2 Roles (`web/services/roles.py`, SEG-08)

`validador` · `revisor` (aprueba código de IA y feedback) · `admin_corpus` (gestiona RAG global). Llegan como
*app roles* de Entra ID; **sin rol, todo se deniega**. No hay contraseña compartida ni cuentas locales.

### 9.3 Identidad y modo

| Modo | Cómo | Restricciones |
|---|---|---|
| Prueba (web v2) | `scripts/web_prueba.py`: fija solo para su proceso `MODO=debug`, `VIRF_IDENTIDAD_PROVEEDOR=libre`, `VIRF_FUENTE_SECRETOS=entorno`; escucha en `127.0.0.1`; claves efímeras de sesión | Prohibido en producción; lo firmado queda marcado «usuario de prueba (sin SSO)» (`@prueba.local`) |
| Corporativa (web v3) | `uvicorn web.app:app` + SSO Entra ID | Requiere `VIRF_ENTRA_TENANT_ID`, `VIRF_ENTRA_CLIENT_ID`, `VIRF_ENTRA_REDIRECT_URI`, `VIRF_CLAVE_FIRMA_SESION` (≥32 caracteres, desde Key Vault). Sin ellas, el login responde **503** nombrando lo que falta (esperado, no es un fallo) |

### 9.4 Pantallas y rutas

Los 9 pasos de la guía (`/api/guia/progreso`), todos los endpoints (método · ruta · archivo · función) y
las descripciones están en [`REFERENCIA_TECNICA.md`](REFERENCIA_TECNICA.md) §3. Grupos principales:
modelos, subida de evidencia (`/api/inputs`), RAG (`/api/rag`), estándares, prompts, cuestionamientos,
skills, validación (REST + WebSocket), resultados, chat de sustentación, informe consolidado, controles de
datos y notebook, automatizaciones, aprobación de código, aprobación de feedback, Solo Informe,
Validación completa, guía y salud (`/api/salud`).

**Informe final:** el botón «Generar informe» (`POST /api/informe/consolidado`) lo produce
`web/services/informe_web.py`, **no** `modulos/generador_word.py` (ese es el entregable regulatorio del
CLI). Los tres informes Word comparten `modulos/plantilla_bcp.py` y `modulos/reglas_informe.py`.
Estructura **fija** de 5 secciones (siempre aparecen; sin datos se muestra una nota): Portada → Glosario →
Cómo leer → Índice → 1 Resumen ejecutivo · 2 **Tabla de validación (final)** · 3 Detalle por ámbito y
observación · 4 Entendimiento del modelo · 5 Anexo de trazabilidad. Tipografía `Flexo` (respaldo `Segoe UI`),
interlineado 1,3, pie «Pág. X de Y». Etiqueta de clasificación en el pie de todo Word (SEG-10).
`tests/test_informe_tabla_final.py` fija el título literal, los **8 encabezados** y la firma de
`_seccion_tabla_final`.

### 9.5 Modalidades de validación (por modelo, explícitas desde 2026-11-18)

- **Normal:** pipeline + estándar; **no** pide automatizaciones.
- **Completa:** 5 chats especializados — 00 Diagnóstico · 01 ControlDatos · 02 Modelamiento · 03 Impactos ·
  04 Seguimiento. Ciclo: el validador da rutas de datos y evidencias → el agente **entrega**
  `{etapa}ITERn.ipynb` → el validador lo ejecuta donde están los datos y obtiene
  `{etapa}_resultadoITERn.xlsx` → lo devuelve con comentarios e imágenes → `ITERn+1` hasta cumplir. El
  validador cierra cada etapa; con las 5 cerradas el modelo está listo para enviarse a validar. Las imágenes
  van a un anexo del Word (`modulos/adjuntos_ole.py`, `capturas.py`). Los insumos (manuales, Excels de
  primera línea, scripts, `.zip`) se **estudian enteros** antes de cada notebook y se cachean por huella
  (`modulos/estudio_insumos.py`). Código: `modulos/validacion_completa.py`, `/api/completa/*`,
  `web/static/js/completa.js`.
- **Solo Informe:** Word sin pipeline (§6.6). IA **opcional** (pulir redacción, gráficos de textos largos,
  redactar desde manuales con BM25 local y citas de página); **la calificación nunca pasa por la IA**.
  Variables propias: `SOLO_INFORME_IA_PROVEEDOR`, `SOLO_INFORME_DEPLOYMENT`, `SOLO_INFORME_MODELO`.
- **VIRF PLUS:** Claude da segunda opinión, ambos evalúan por separado y GPT concilia (`VIRF_PLUS=1`,
  `--virf-plus` o botón). **Bloqueado** mientras Claude no esté aprobado.
- **Cuadro de automatizaciones:** observaciones (Ámbito · Riesgo · Observación · Recomendación ·
  Responsable/Fecha) desde los Excels `00_Diagnostico`, `01_ControlDatos`, `02_Modelamiento`,
  `03_Impactos` (`modulos/automatizaciones.py`); va como 1.1 del Resumen ejecutivo.

### 9.6 Controles de calidad de datos

Dos fuentes: los **8 motores genéricos** de `modulos/motores_datos.py` (catálogo, pipeline) y el
**repositorio de controles por dominio**: `inputs/repositorio_controles/<dominio>/*.py`, donde cada `.py` es
un control con `META` (descripción → «Control Esperado», dimensión, evidencia, referencia, orden, params) y
`def control(df, datasets, params) -> {pct, decision, diagnostico}`. `modulos/repositorio_controles.py`
los lee (META por AST, sin ejecutar); `modulos/notebook_controles.py` **embebe el código real** en cada
celda de un `.ipynb`, lo ejecuta e imprime `>>>> Cnn: descripción` + una fila
`Control | Resultado | % cumplimiento | Diagnóstico`, y cierra con el cuadro de 8 columnas (print + CSV).
La ruta de repositorio solo se activa si el dominio tiene controles **propios** (no solo `shared`); si no,
cae al flujo documento/LLM. Taxonomía (decisión del usuario, 2026-09-24): **tres dominios** — Trading→`var/`
(12 controles), ALM→`alm/` (16; incluye conductuales: prepago, supervivencia/retiro, NMD, IRRBB),
Liquidez→`lar/` (11: LCR, NSFR, horizonte de supervivencia, HQLA, concentración de fondeo, brecha) — más
`shared/` (5, BCBS 239: completitud, duplicados, frescura, volumen mínimo, columnas constantes) que se añade
a todos.

---

## 10. Seguridad: capas y qué las rompe

| Capa | Qué hace | Archivo | Qué la rompería |
|---|---|---|---|
| Lista cerrada de proveedores (SEG-01) | Solo `azure_openai` ejecuta en producción | `config/ia.py: PROVEEDORES` | Editar la lista |
| Host permitido | Solo `*.openai.azure.com` / `*.cognitiveservices.azure.com` | `config/red.py` | Declarar otro host |
| Secretos (SEG-03) | Fuente explícita `VIRF_FUENTE_SECRETOS` = `keyvault` (defecto) \| `databricks` \| `entorno` (solo proceso; prohibido en producción). Una clave en `.env` se **rechaza** (salvo `MODO=debug`) | `config/secretos.py` | Leer claves con `os.getenv` |
| Gateway único (SEG-05) | SDK solo en `config/ia.py`; todo cliente va envuelto | `config/ia.py` | Importar el SDK en otro módulo |
| PII (SEG-04) | Enmascarado determinista local | `modulos/pii.py` | `VIRF_PII_MASKING=0` |
| Anti-inyección | Neutraliza instrucciones en la evidencia | `modulos/inyeccion.py` | `VIRF_ANTIINYECCION=0` |
| Saneado de salida | Lo que sale hacia la IA | `modulos/salida_ia.py` | — |
| Identidad (SEG-02) | SSO Entra ID; sesión firmada HMAC-SHA256 | `config/identidad.py`, `web/routers/auth.py` | — |
| Roles (SEG-08) | Matriz de permisos | `web/services/roles.py` | — |
| Auditoría (SEG-12) | Log solo-anexar encadenado | `modulos/auditoria.py`, `web/services/auditoria_web.py` | Una acción sin entrada |
| Clasificación (SEG-06/10) | `Publico`/`Interno`/`Restringido` en cada subida; etiqueta en el pie de todo Word; `Restringido` solo con `VIRF_ENTORNO=databricks` o `repositorio_aprobado` | `modulos/almacenamiento.py`, `clasificacion_docx.py` | — |
| Ejecución de código (SEG-07) | Cero `exec/eval`; el código de IA corre solo tras aprobación de un revisor **por hash**, aislado (`python -I`) | `modulos/aprobacion_codigo.py`, `aislamiento.py` | `compile/exec` |
| Pickle firmado (SEG-09) | Índices RAG con firma | `modulos/pickle_firmado.py` | — |
| Robustez LLM (SEG-16) | Citas dudosas y NLI negativo retiran la afirmación; abstención β; NLI activo en producción | `modulos/salvaguardas_llm.py`, `entailment.py`, `abstencion.py` | — |
| Fusibles | Cortacircuitos de bucles (`MAX_ITER`, segundos, tokens) | `modulos/fusibles.py` | — |
| Databricks (SEG-14) | Lectura mínima de datos: columnas + filtro/límite; sin token personal | `modulos/motores_datos.py` | — |
| Recursos externos (SEG-15) | Cero peticiones de red del navegador (sin Google Fonts) | `web/templates`, `web/static` | Añadir CDN |
| Repositorio (SEG-11) | Guías solo hacia Azure DevOps | `scripts/verificar_remoto_git.py` | Remotos no corporativos |
| Secretos en el repo | Escáner | `scripts/escanear_secretos.py`, `.pre-commit-config.yaml` | Commit con clave |

Estado de cada SEG (remediado / bloqueado por humano) y el commit que lo cerró: `REMEDIACION_SEG.md`.

---

## 11. Cambiar de IA

### 11.1 Situación actual

| Proveedor | Producción | `MODO=debug`/`desarrollo` |
|---|---|---|
| `azure_openai` | **APROBADO** | ejecuta |
| `anthropic` | EN_ESPERA (el gateway lo bloquea **antes** de leer su clave) | ejecuta |
| `openai` | RETIRADO | ejecuta |

En desarrollo el proveedor activo sale de `proveedor_activo()`: `IA_PROVEEDOR` si está declarado y sus
credenciales están completas; si no, se deduce de la clave presente; con dos claves gana GPT. En
producción rige `IA_PROVEEDOR` tal cual. **Solo el banco cambia un estado.**

### 11.2 Mismo proveedor, otro modelo (fácil)

| Qué | Dónde | Cómo |
|---|---|---|
| Deployment (Azure) | `AZURE_OPENAI_DEPLOYMENT` | Es el **Deployment name** del portal (no el nombre del modelo) |
| Endpoint | `AZURE_OPENAI_ENDPOINT` | `https://<recurso>.openai.azure.com/` |
| Versión de API | `AZURE_OPENAI_API_VERSION` (`2024-10-21`) | La que use IT en producción |
| Modelo directo (debug) | `ANTHROPIC_MODELO` (`claude-sonnet-4-6`), `OPENAI_MODELO` (`gpt-4.1`) | Entorno |
| Tokens de salida | `AZURE_OPENAI_MAX_TOKENS`, `ANTHROPIC_MAX_TOKENS`, `OPENAI_MAX_TOKENS` (4096) | Sube si las respuestas se cortan |
| Perfil y precios | `config/modelos.py` | Entrada en `CATALOGO_MODELOS`, `PRECIOS_ENTRADA_USD_POR_MTOK`, `PRECIOS_SALIDA_USD_POR_MTOK` |

Sin entrada en el catálogo se usa `PERFIL_CONSERVADOR` y se avisa (prefiere más llamadas a perder
cobertura en silencio). Sin precio se usan los defectos (1,0 / 4,0 USD por Mtok): las estimaciones serán
aproximadas.

### 11.3 Otro proveedor (difícil) — en este orden

1. **Decisión humana:** en producción, el banco debe marcarlo `APROBADO`. Sin eso, solo `MODO=debug`.
2. **Cliente:** subclase de `ClienteIA` en `config/ia.py` (molde: `ClienteAzureOpenAIIA`). Debe llamar,
   devolver texto y reportar tokens para la auditoría.
3. **Registro:** añadir a `PROVEEDORES` (estado del banco), `_instanciar()`, los metadatos y
   `vars_revisar` (qué variable falta).
4. **Red:** declarar el host en `config/red.py` (decisión de seguridad).
5. **Secreto:** leerlo **solo** con `_secreto("NOMBRE")` (`config/secretos.py`). En Key Vault el nombre es
   minúsculas con guiones: `AZURE_OPENAI_API_KEY → azure-openai-api-key`.
6. **Catálogo y precios:** `config/modelos.py`.
7. **Parámetros nuevos** (si los hay): `config/parametros.py` + `__all__` + `config/__init__.py` +
   `.env.example`.
8. **Pruebas:** `simular_aprobacion` (`tests/conftest.py`); molde `tests/test_deteccion_proveedor.py`,
   `test_proveedores_ia.py`.

### 11.4 Diferencias entre familias (por esto falla un cambio «inocente»)

| Familia | Parámetro de tokens | Temperatura | Contexto |
|---|---|---|---|
| GPT-4, 4-turbo, 4o, 4o-mini, 4.1, 35-turbo | `max_tokens` | libre | 8 K · 128 K · 128 K · 128 K · 1 M · 16 K |
| GPT-5, o1, o3 (razonamiento) | `max_completion_tokens` | **solo 1** | 400 K · 200 K · 200 K |
| Claude (haiku/sonnet) | `max_tokens` | libre | 200 K |

Tabla completa y exacta en `REFERENCIA_TECNICA.md` §5. Si `param_tokens` o `admite_temperature` están mal
declarados, la API rechaza la llamada. Detalle: `GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md` §6–7.

### 11.5 Qué recalibrar y con qué medirlo

| Cambia… | Recalibrar | Medir con |
|---|---|---|
| Ventana de contexto | `VIRF_MAX_CTX` (**60000**, decisión del usuario; el defecto de código es 15000), `VIRF_CHUNK_SIZE` 12000, `VIRF_MAX_CHUNKS` 40, `VIRF_PRESUPUESTO_DOC` (60 % de `MAX_CTX`) | `--prevuelo`, `--explicar-modelo … --dry-run`: chunks y coste sin gastar |
| Tokenización | `CHARS_POR_TOKEN_ES = 2.4` (medido 2,48 en español técnico; error histórico: se asumió 3,3 y desvió el presupuesto 33 %) | Recalibrar con `tiktoken` sobre tu corpus (instrucciones en el docstring de `config/modelos.py`) |
| Determinismo | `VIRF_IA_TEMPERATURE` (0.0) | Misma evaluación ×3: puntaje estable |
| Abstención | `VIRF_ABSTENCION_BETA` (0.19) | Actividades con «evidencia insuficiente» |
| NLI | `VIRF_ENTAILMENT` (ON en producción; +1 llamada por actividad) | Coste vs. citas degradadas |
| Red | `REINTENTOS_API` 3, `TIMEOUT_SEGUNDOS` 30, `VIRF_HTTP_TIMEOUT` 120 | `audit_logs/auditoria_acciones.jsonl` |

### 11.6 La prueba que importa: ¿la IA nueva discrimina?

Conectar no es validar bien. Existen dos fixtures sintéticos: `modelos/VaR_FRTB` (manual y código
alineados) y `modelos/VaR_FixtureDrift` (4 discrepancias plantadas, p. ej. el código usa confianza 0,95 y
ventana 500 frente a 250 días, 99 %, retornos logarítmicos del manual). **Criterio histórico**
(corridas reales del 2026-09-02, modelo Haiku): coherente → **2,55/5 «con observaciones»**; con drift →
**1,62/5 «deficiente»**, y el agente citó las cifras contradictorias. **Si la IA nueva no separa ambos
casos, no está lista**, aunque pase todos los tests: los tests usan IA simulada y **no miden pertinencia**
(`QUE_HACE_REALMENTE.md` §8). Esa corrida real **gasta**: confirma antes y usa el modelo barato.

---

## 12. Cambiar de computadora

### 12.1 Qué llevar y qué rehacer

| Llevar | No llevar / rehacer |
|---|---|
| El repositorio (zip `…_VERSION_FINAL.zip`) | `.venv` → recrear |
| `audit_logs/`, `feedback/`, `web/data/` (estado vivo) si quieres continuidad | `.env` → recrear desde `.env.example` (**no viaja**) |
| `inputs/` (evidencia y `inputs/rag/`) | Caché `data/cache/` (se reconstruye) |
| Los `.bundle` de git (historial; el zip no lleva `.git`) | Claves, tokens, cookies |
| La carpeta de **memoria del asistente** (§20) | Índices RAG (se reconstruyen) |

### 12.2 Qué cambiar y cómo comprobarlo

| Qué | Cómo | Comprobación |
|---|---|---|
| Python | 3.10–3.12 | `python --version` |
| Entorno | `python -m venv .venv` + `pip install -r requirements.txt -r web/requirements_web.txt` | `pip check`; sin torch/transformers/huggingface/chromadb |
| Rutas | Nada absoluto en el código: todo cuelga de `config/rutas.py` | `validate_project.py --strict` |
| `.env` | `copy .env.example .env`; solo configuración no secreta | `agente.py --verificar-conexion-azure` |
| Secretos | Key Vault: `VIRF_FUENTE_SECRETOS=keyvault` + `VIRF_KEYVAULT_URL` + `az login`/Managed Identity. Desarrollo: `entorno` y la clave como variable del **proceso** | Mensaje del gateway |
| Proxy / TLS | `VIRF_CA_BUNDLE` (ruta al certificado raíz), `VIRF_TLS_ALMACEN_SISTEMA=1` (usa `truststore`), `VIRF_HTTP_TIMEOUT`. **No usar `VIRF_TLS_INSECURE`** | Prueba de conexión |
| Identidad web | §9.3 | `GET /api/salud` → `{"estado":"ok"}` |
| Tipografía | `VIRF_FUENTE` (Flexo; respaldo `VIRF_FUENTE_RESPALDO` Segoe UI; mono `Cascadia Mono`) | Mirar el Word |
| Logo | `VIRF_DIR_LOGO` (`inputs/logoempresa`) | Mirar el Word |
| Repositorio corporativo | `VIRF_REPO_CORPORATIVO` + `scripts/verificar_remoto_git.py` | Hoy **no hay remoto** |
| Windows ↔ Linux/macOS | `.venv\Scripts\…` ↔ `.venv/bin/…`; `modulos/consola.py` evita errores de emoji en consolas cp1252 (usa `PYTHONUTF8=1` si imprimes Unicode) | `validate_project.py` |
| Databricks | `VIRF_ENTORNO=databricks`, `VIRF_SECRET_SCOPE`; reconstrucción mensual del RAG: `scripts/rebuild_rag_databricks.py`; guía `docs/DESPLIEGUE_DATABRICKS.pdf` | — |
| Ver el Word como PDF | No hay LibreOffice: se exportó con Word COM (PowerShell, `SaveAs` formato 17, actualizando campos para el TOC) y se rasterizó con PyMuPDF en carpeta temporal (`--target`, **no** en el `.venv`) | Solo si necesitas inspección visual |

### 12.3 Verificación completa tras migrar (en orden)

```bash
.venv\Scripts\python -m pip check
.venv\Scripts\python validate_project.py --strict          # 0 FAIL
.venv\Scripts\python -m pytest -q                           # ~6,5 min, coste 0
.venv\Scripts\python agente.py --verificar-conexion-azure   # único paso que llama a la IA
.venv\Scripts\python agente.py --prevuelo                   # coste 0
.venv\Scripts\python scripts/web_prueba.py                  # y GET /api/salud
```

---

## 13. Dónde medir: mapa completo de instrumentos

| Pregunta | Instrumento | Comando / ubicación | Coste |
|---|---|---|---|
| ¿Proyecto íntegro? | Validador (146 comprobaciones) | `validate_project.py --strict` (**0 FAIL**; los WARN suelen ser evidencia ausente) | 0 |
| ¿Algo se rompió? | pytest (~1790 tests) | `.venv\Scripts\python -m pytest -q` | 0 |
| ¿Cumple los indicadores del plan? | Verificador WP-00 | `verificador_virf.py --hito <X> --pytest-xml <ruta>` → `docs/evidencia/indicadores_<fecha>.{json,md}` (sin XML, los dependientes de tests quedan «NA con motivo») | 0 |
| ¿Qué podrá evaluar con esta evidencia? | Prevuelo | `agente.py --prevuelo` (código 1 si falta un ámbito) | 0 |
| ¿Cuánto costará? | Dry-run | `--explicar-modelo "<M>" --dry-run`, `--revisar-codigo --dry-run` | 0 |
| ¿Cuánto cuesta/tarda cada llamada? | Bitácora | `audit_logs/auditoria_acciones.jsonl`; `scripts/generar_observabilidad.py` (dataset + costes; spec en `observabilidad/ESPECIFICACION_DASHBOARD.md`) | 0 |
| ¿Doble emisión? | Registro append-only | `audit_logs/registro_emisiones.jsonl` | 0 |
| ¿El RAG recupera lo correcto? | Preguntas-oro y cobertura | `scripts/preguntas_oro_rag.py`, `preguntas_oro_formula.py`, `auditar_cobertura_rag.py`, `verificar_corpus_rag.py`, `explicar_rag.py` | 0 |
| ¿Hay credenciales en el repo? | Escáner | `scripts/escanear_secretos.py --staged` / `--historial` | 0 |
| ¿Resiste ataques a LLM? | Red-team OWASP | `pruebas/seguridad/test_owasp_llm.py` | 0 |
| ¿Casos borde de lectura? | Matriz | `pruebas/test_casos_borde.py` (`matriz_casos_borde.md`) | 0 |
| ¿E2E sintético? | Recorrido | `pruebas/e2e/e2e_sintetico.py` | 0 |
| ¿Se reutiliza el caché? | Estadísticas | `agente.py --cache-stats` | 0 |
| ¿Precisión del agente según feedback? | Excel de precisión | `agente.py --estadisticafeedback` | 0 |
| ¿Alucina / concuerda con el validador? | Módulo de calidad | `pruebas/calidad/evaluacion.py` — **hoy sin medición real** (falta la hoja `Modelo_Evaluacion`; `modelo_evaluacion_oficial()` lanza `NotImplementedError` a propósito) | 0 |
| ¿Un humano coincide con el agente? | Rúbrica 0-1-2 | `modulos/evaluacion_experta.py`, `pruebas/rubrica_experta.md` | 0 |
| ¿Discrimina sano vs. con drift? | Corrida real con fixtures | §11.6 | **Gasta** |
| ¿Conecta la IA? | Prueba de humo | `agente.py --verificar-conexion-azure`, `test_api_key.py`, `diagnostico_azure_virf.py` (por capas) | mínimo |
| ¿Conexiones de la web OK? | Verificador | `web/verificar_conexiones.py --validador <V> --modelo <M>` / `/api/debug` | 0 |
| ¿Qué se rompe si cambio X? | Grafo | `graphify affected "X"` | 0 |

---

## 14. Recetas: cómo hacer cada tipo de cambio

Cada receta termina con **cómo verificar**. Regla común: `validate_project.py --strict` y `pytest -q` en verde.

| Quiero… | Pasos | Verificar |
|---|---|---|
| **Añadir un parámetro** | Declararlo con `_entero/_decimal/_booleano` en `config/parametros.py` (+ `__all__`) → re-exportar en `config/__init__.py` → documentar en `.env.example` | `TestConfigCentral`; `REFERENCIA_TECNICA.md` §2 lo lista al regenerar |
| **Añadir un flag al CLI** | `parser.add_argument` en `agente.py` (flag explícito, sin autodetección) → documentarlo en `FLAGS.md` | `REFERENCIA_TECNICA.md` §1; tests de documentación consistente |
| **Añadir un endpoint** | Función en `web/routers/<x>.py` → `app.include_router` en `web/app.py` → permiso en `web/services/roles.py` → entrada en `ACCIONES` de `web/services/auditoria_web.py` si es acción auditada | `tests/test_roles.py`, `test_auditoria.py` |
| **Añadir un control de datos** | Crear `inputs/repositorio_controles/<dominio>/<nombre>.py` con `META` y `control(df, datasets, params)` (carpeta del dominio; `shared/` aplica a todos) | `modulos/repositorio_controles.py::cargar_controles`; test del endpoint de notebook |
| **Añadir un dominio RAG** | Web: dominio personalizado (`dominios_custom_store.py`, persistido en `web/data/dominios_custom.json`); fijo: carpeta `inputs/rag/<D>/`, paquete `src/rag/<D>/`, `DOMINIOS` en `src/rag/config_rag.py`, alias en `src/rag/__init__.py`, `DOMINIOS_UI` en `modelos_store.py`, `index.html` y `app.js` | `scripts/verificar_corpus_rag.py`, `preguntas_oro_rag.py` |
| **Añadir papers al RAG** | Subir con clasificación, dueño y vigencia (`modulos/fuentes_rag.py`), reconstruir el índice del dominio | `scripts/auditar_cobertura_rag.py` |
| **Cambiar el estándar** | Subir `Estandares_VIRF.xlsx` (por sesión, o el global `inputs/Estandares_VIRF.xlsx`); respetar tildes de ámbito (§7.2) y la `X` por Tier | `validate_project.py` bloque 4 |
| **Añadir un ámbito** | Los **4 sitios** de §7.2 + pesos que sigan sumando 1,00 | `test_ambitos_coinciden_en_los_cuatro_sistemas` |
| **Cambiar un peso o umbral de negocio** | `config/dominio.py` (con su referencia normativa) y `PROCEDIMIENTO_VALIDACION.md` | `validate_project.py`; es decisión de validación, no un ajuste |
| **Cambiar un prompt** | Web: `/api/prompts` (por sesión) · Base: `motor/Mx_02_EstructuraPrompt.py` | `modulos/huella_prompts.py` registra la huella en el informe |
| **Añadir un cuestionamiento** | Global: `config/cuestionamientos_personalizados.json` · Por sesión: `web/services/cuestionamientos_sesion.py` | `/api/cuestionamientos` |
| **Cambiar el informe Word** | Plantilla común `modulos/plantilla_bcp.py`; estilo `modulos/word_estilo.py`; **no** cambiar los textos fijados por `tests/test_informe_tabla_final.py` | Generar y mirar el Word (§12.2) |
| **Añadir una skill** | `skills/<x>.py` heredando de `skills/base_tipada.py` + registro en el catálogo; las transversales en `modulos/skills/catalogo.py` | `tests/skills/` |
| **Cambiar de proveedor/modelo** | §11 | §11.5 y §11.6 |
| **Cambiar una dependencia** | Editar el pin (`==`) en el `requirements` → `pip install` → `pip check` | `tests/test_requirements_web_fijados.py`; escaneo `docs/seguridad/sca_pip_audit.json` |
| **Añadir una prueba que recorra el árbol** | Usar `tests/_arbol.py::es_de_entorno_virtual` (reconoce `pyvenv.cfg`), nunca una lista de nombres de carpeta | Que no falle con otro entorno dentro del proyecto |
| **Registrar un módulo que llama a la IA** | Fila en `docs/seguridad/GOBIERNO_RIESGO_IA.md` (el estado de aprobación lo decide el usuario) | `tests/test_gobierno_ia.py` |

---

## 15. Parámetros ajustables (guía de criterio)

La lista **exacta y completa** (127 variables, con su tipo, defecto y dónde se leen) está en
`REFERENCIA_TECNICA.md` §2. Aquí, cuándo mover cada grupo:

| Grupo | Variables clave (defecto) | Cuándo moverlas |
|---|---|---|
| Modo | `MODO` (`produccion`), `IA_PROVEEDOR` (`azure_openai`) | Desarrollo local: `MODO=debug` |
| Contexto | `VIRF_MAX_CTX`, `VIRF_CHUNK_SIZE` 12000, `VIRF_CHUNK_OVERLAP` 800, `VIRF_MAX_CHUNKS` 40, `VIRF_CHUNK_SIZE_MAX` 40000, `VIRF_MAX_NIVELES` 3, `VIRF_CHUNK_ENABLED` | Cambia el modelo/contexto o ves cobertura documental baja |
| Lectura | `MAX_CHARS_DOC` 15000, `MAX_CHARS_CODIGO` 8000, `MAX_FILAS_EXCEL` 200, `EXCEL_*` | Evidencia muy grande |
| Revisión de código | `VIRF_MAX_CHARS_MODULO` 120000, `VIRF_MAX_CHARS_MANUAL_REVISION` 24000 (**el manual viaja en cada llamada: es el multiplicador del coste**), `VIRF_EXCLUIR_DEPENDENCIAS` | Coste alto; inventario de «cientos de módulos» = hay un `.venv` dentro de `inputs/` → activar |
| RAG | `RAG_TOP_K` 6, `RAG_PESO_BM25` 0.7, `RAG_PESO_TFIDF` 0.3, `RAG_BM25_K1` 1.5, `RAG_BM25_B` 0.75, `RAG_CHUNK_SIZE` 1200, `RAG_CHUNK_OVERLAP` 200, `RAG_MIN_SCORE` 0.35, `RAG_MIN_COBERTURA` 0.15, `RAG_STEMMING`, `RAG_TESAURO`, `RAG_CORREGIR_ERRATAS` | Solo midiendo con las preguntas-oro. **`RAG_MIN_SCORE` es relevancia relativa a la consulta, no coseno** |
| Salvaguardas | `VIRF_PII_MASKING` ON, `VIRF_ANTIINYECCION` ON, `VIRF_ENTAILMENT` (ON en producción), `VIRF_PROHIBIR_MODELOS_EXTERNOS` ON | No apagar en producción |
| Robustez | `VIRF_MAX_ITER` 3, `VIRF_FUSIBLE_SEG` 10, `VIRF_FUSIBLE_TOKENS` 20000, `VIRF_INTENTOS_CONTRATO` 2, `VIRF_ABSTENCION_BETA` 0.19, `VIRF_UMBRAL_SEGUNDA_REVISION` 3 | Tras medir |
| Feedback | `VIRF_MIN_FEEDBACK_ANTISESGO` 15, `VIRF_MIN_MUESTRAS_AJUSTE` 15 | Cuando haya historial suficiente |
| Cuadro | `VIRF_PLAZO_CRITICO` 30, `_MODERADO` 90, `_BAJO` 180 (días); `VIRF_IMPACTO_UMBRAL_MODERADO` 0.05, `_CRITICO` 0.10 | Política de plazos |
| Consolidación | `VIRF_PUNTAJE_CUMPLE` 5.0 | Solo por decisión de validación |
| Caché y retención | `CACHE_ENABLED`, `CACHE_DIR`, `VIRF_CACHE_LOCK_TIMEOUT` 10, `VIRF_CACHE_LOCK_STALE` 60, `VIRF_RETENCION_DIAS` 30 | Política de retención |
| Red | `VIRF_HTTP_TIMEOUT` 120, `VIRF_CA_BUNDLE`, `VIRF_TLS_ALMACEN_SISTEMA` | Entorno corporativo |
| Informe | `VIRF_FUENTE`, `VIRF_FUENTE_MONO`, `VIRF_FUENTE_RESPALDO`, `VIRF_DIR_LOGO`, `VIRF_DOBLE_FIRMA_TIER` | Identidad visual / doble firma |
| VIRF PLUS | `VIRF_PLUS` (OFF), `VIRF_PLUS_ARBITRO` (gpt), `VIRF_PLUS_ARBITRAJE` (siempre) | Solo si Claude queda aprobado |
| Pruebas | `VIRF_MOCK_CHAT=1` | Probar el chat sin IA |

---

## 16. Decisiones ya tomadas (no reabrir)

| Decisión | Quién · cuándo | Efecto |
|---|---|---|
| Lista cerrada de proveedores; solo Azure OpenAI en producción | Banco (SEG-01) | No tocar `PROVEEDORES` |
| Claves solo en Key Vault / scope / entorno del proceso | Banco (SEG-03) | Clave en `.env` se rechaza en producción |
| En `MODO=debug` Claude y OpenAI directo ejecutan y SEG-03 se relaja | Usuario · 2026-11-11 | Solo desarrollo; producción no cambia |
| El proveedor se deduce de la clave solo en debug; con dos claves gana GPT; VIRF PLUS sigue siendo flag | Usuario · 2026-11-11 | No extender la excepción a otros modos |
| RAG léxico: sin embeddings, ChromaDB ni HuggingFace | Usuario / entorno (un solo deployment de chat) | Mejorar solo `src/rag/` |
| Sin OCR | Política de modelos externos | PDF escaneado = fallo técnico declarado |
| Taxonomía de 3 dominios: Trading (VaR), ALM (incluye conductuales), Liquidez (LaR). `conductuales` = alias de `ALM` | Usuario · 2026-09-24 | Carpetas `var/`, `alm/`, `lar/`, `shared/` |
| Controles de datos = funciones Python por dominio (no plugins ni YAML) | Usuario · 2026-09-08 | Añadir control = crear un `.py` |
| Reglas de Solo Informe (§6.6) | Usuario | `modulos/reglas_informe.py` |
| Validación completa con 5 chats; el entregable del agente es el **notebook** | Usuario · 2026-11-18 | §9.5 |
| Pasos 19, 42, 63, 76 (hojas `Costes` y `Modelo_Evaluacion`): «oportunidad de mejora, fuera del core» | Usuario | Un test impide que el core importe `pruebas/calidad` |
| Login: SSO Entra ID; web de prueba con «usuario libre» solo fuera de producción | Usuario · 2026-11-09 | Firmante = identidad corporativa |
| `VIRF_MAX_CTX = 60000` | Usuario · 2026-11-18 | Hallazgo H1 del plan de parches |
| Un manual metodológico es imprescindible para validar | Metodología | Sin él, el informe no sirve como validación |
| «Resuélvelo todo» = arreglar y **verificar** sin preguntar paso a paso; parar solo en decisiones suyas o imposibles | Usuario | Estilo de trabajo |

---

## 17. Errores frecuentes → causa → solución

| Síntoma / mensaje | Causa | Solución |
|---|---|---|
| `DeploymentNotFound` (404) | Usaste el nombre del modelo en vez del *Deployment name* | `AZURE_OPENAI_DEPLOYMENT` = nombre del portal |
| «no autorizado por el banco» (`ProveedorNoAutorizado`) | Proveedor `EN_ESPERA`/`RETIRADO` en producción | Azure; para pruebas `MODO=debug` — **no** editar `PROVEEDORES` |
| El agente «se niega» a usar la clave | Está escrita en `.env` en producción | Key Vault o variable del proceso; rótala |
| Error de parámetro en GPT-5/o-series | `max_tokens` o temperatura ≠ 1 | `param_tokens="max_completion_tokens"`, `admite_temperature=False` en el catálogo |
| Login web responde 503 | Faltan variables de Entra ID | Esperado sin registro; usa `scripts/web_prueba.py` o registra la app |
| `lectura_fallida`, cobertura 0 | PDF escaneado o formato no registrado | Aportar digital o registrar en `LECTORES_EXT`; es fallo **técnico**, no del validado |
| `--prevuelo` sale con código 1 | Algún ámbito sin evidencia | Aportar la evidencia antes de gastar |
| Inventario de «cientos de módulos» | Hay un `.venv`/`site-packages` en `inputs/implementacion` | `VIRF_EXCLUIR_DEPENDENCIAS=1` |
| `--tier 9` o `abc` | Tier inexistente | `normalizar_tier` lo rechaza (antes evaluaba todo y facturaba de más) |
| Una tilde distinta en un ámbito | Los 4 sistemas no coinciden | §7.2 |
| `from pyspark…` falla | Solo existe en Databricks | Esperado fuera de Databricks |
| `import chromadb` revienta (onnxruntime) | Python del sistema, no `.venv` | Usar `.venv`; detectar con `importlib.util.find_spec` |
| «2 rutas» al enumerar `app.routes` | FastAPI ≥ 0.13x anida routers (`_IncludedRouter`) | No es pérdida de rutas; en 0.121 salen 78 planas |
| Un test recorre el árbol y falla «de más» | Otro entorno virtual dentro del proyecto | `tests/_arbol.py::es_de_entorno_virtual` |
| `registro_emisiones.jsonl` con basura de tests | Se corrieron validaciones reales sin respaldo | Respaldar antes y restaurar después |
| `UnicodeEncodeError` `charmap` al imprimir | Consola cp1252 | `PYTHONUTF8=1` |
| Resultados RAG «no coinciden con el coseno» | Con BM25 el score es relativo | Medir con preguntas-oro, no con intuición |
| `test_inventario_cubre_cada_llamante_de_ia` en rojo | Faltan filas de `validacion_completa` y `estudio_insumos` en `GOBIERNO_RIESGO_IA.md` | Las añade el usuario (decide el estado de aprobación) |
| Probé un POST y cambió algo global | `/api/config/proveedor`, RAG global, `historial_feedback.json` escriben fuera de la sesión | Solo GET con `contexto_sesion` en carpeta temporal |

---

## 18. Cómo regenerar la documentación y el grafo

Todo con coste 0 (sin IA). Desde la raíz del proyecto:

```bash
.venv\Scripts\python scripts/generar_inventario_archivos.py      # → INVENTARIO_ARCHIVOS.md
.venv\Scripts\python scripts/generar_referencia_tecnica.py       # → REFERENCIA_TECNICA.md
graphify update .                                                # → graphify-out/ (graph.json, GRAPH_REPORT.md, graph.html)
```

**Grafo (`graphify`):** instalado como herramienta global (`~/.local/bin/graphify`). Comandos útiles:
`graphify query "cómo se genera el informe word"` · `graphify path "A" "B"` · `graphify explain "X"` ·
`graphify affected "X"` (qué se rompe si lo cambias) · `graphify god-nodes`. El grafo **no une el JavaScript
con Python** (hablan por HTTP): las pantallas de `app.js` llaman a `/api/...` definidos en `web/routers/`.
Última actualización: 2026-11-18, 8089 nodos, 18113 aristas, 399 comunidades, construido desde el commit
`b742a5e`; comprueba frescura con `git rev-parse HEAD`. Los nombres de comunidad en español se asignan con
`graphify label` (usa una IA): **no se ejecutó**, así que las comunidades nuevas conservan nombres
derivados de su hub. Faltan extras opcionales (`graphifyy[pdf]` para PDF, `graphifyy[sql]` para `.sql`).
No hace falta llevar `graphify-out/cache/` ni `.graphify_build_state.json`.

Regenera los tres **cada vez** que cambies código y antes de entregar una copia.

---

## 19. Estado actual, pendientes y lo que NO está medido

### 19.1 Git y copias

- `main` local, **sin remoto**; rama de trabajo `docs/firma-sin-validador`.
- **Dos copias del proyecto:** esta (Escritorio; suite en verde) y la **corporativa** (otro equipo, OneDrive,
  `…\MarlA\virf_agent_v27_final`) con kits y shim (`kit_subsanacion_virf`, `kit_validacion_proceso_v2`,
  `modulos/estandares_shim.py`, `estandar_contrato.py`, `normalizar_estandares_virf.py`,
  `validacion_resultados.py`) y 16 fallos de tests. **Antes de ejecutar un plan de parches, comprueba en
  qué copia aplica.** Entregables para la corporativa: `Downloads\VIRF_plan_v3\`, `kit_informe_contexto\`
  (fuera del proyecto: dentro haría fallar los tests de estructura). Falta el libro
  `VIRF_v27_Mapa_de_parches_para_modelo.xlsx` (solo en el equipo corporativo).

### 19.2 Pendientes humanos que bloquean **producción** (no la instalación)

Rotar claves (el historial git conserva una clave «dummy» en `9b18e3f44`; el `.env` local tuvo una
`ANTHROPIC_API_KEY` en texto plano: **rótala**) · crear el Key Vault · registrar la app en Entra ID con sus
*app roles* · service principal de Databricks · URL del repositorio corporativo · destino de la bitácora
(SIEM) · nombrar aprobadores de código · flujo de riesgo IA / pentest / DAST · actualizar 6 dependencias
con vulnerabilidades (SCA: 46 vulns en 6 paquetes). Detalle: `gobierno/go_no_go.md`, `gobierno/backlog.csv`,
`REMEDIACION_SEG.md`.

### 19.3 Lo que no está medido o no se ha visto

| Tema | Estado |
|---|---|
| Alucinación y concordancia agente↔validador | **Sin medición real** (falta la hoja `Modelo_Evaluacion`). Controles deterministas auditados el 2026-11-18: ver `AUDITORIA_ANTIALUCINACION.md` (brechas abiertas R6, R8–R11, R13 y decisión pendiente R14) |
| Pertinencia de los hallazgos con la IA actual | Medida solo en 2026-09-02 con Haiku; la IA de producción (Azure) **no se ha medido** |
| Lector de Excels de automatización | Construido **sin ver los archivos reales** (detecta encabezado y resultado por nombre): ajustar sinónimos con un archivo real |
| `03_Impactos` ausente | El riesgo queda «estimado» (la frase del usuario sobre ese caso quedó incompleta) |
| 4 dependencias nuevas (`azure-identity`, `azure-keyvault-secrets`, `msal`, `reportlab`) | Instaladas y verificadas el 2026-11-18 (`pip check` limpio, imports OK, suite en verde); pendiente solo confirmar contra Key Vault/Entra reales |
| `pytest` | 1827 passed, 2 skipped, **1 en rojo conocido** (`test_inventario_cubre_cada_llamante_de_ia`: depende de una decisión del usuario) |
| Corpus de referencia | Limitación documentada en `PROCEDIMIENTO_VALIDACION.md` §10 |

---

## 20. La memoria del asistente no viaja con el repositorio

El asistente guardó notas fuera del proyecto (`C:\Users\<usuario>\.claude\projects\…\memory\`). **No están
en el zip ni en git**: al cambiar de computadora o de IA se pierden. Todo lo esencial de esas notas ya está
integrado en esta guía (taxonomía §9.6, plantilla de informe §9.4, salvaguardas §10, estado de la API §11,
remediación SEG §10 y §19, dos copias §19.1, validación completa §9.5, decisiones §16). Si quieres
conservarlas literalmente, copia esa carpeta aparte.

---

## 21. Checklists finales

**Contexto**
- [ ] Leídas esta guía (§1–§5 y §16), `HANDOFF_AGENTE.md` y `README.md` §2-bis.
- [ ] Pegado el prompt de arranque (§0) en la IA nueva.
- [ ] Copiada la carpeta de memoria (§20), si se quiere conservar.

**Computadora nueva**
- [ ] `.venv` recreado; `pip check` limpio; sin paquetes prohibidos.
- [ ] `.env` desde `.env.example`, **sin claves**.
- [ ] Fuente de secretos configurada (Key Vault + `az login`, o variable del proceso en desarrollo).
- [ ] Proxy/TLS resuelto si la red lo exige.
- [ ] `validate_project.py --strict` con 0 FAIL y `pytest -q` sin fallos nuevos.

**IA nueva**
- [ ] Estado del proveedor decidido por el banco (o `MODO=debug` para pruebas).
- [ ] Entrada en `config/modelos.py` (contexto, parámetro de tokens, temperatura, precios).
- [ ] `VIRF_MAX_CTX`/chunking recalibrados con `--prevuelo` y `--dry-run`.
- [ ] Prueba de conexión OK.
- [ ] Corrida sobre `VaR_FRTB` y `VaR_FixtureDrift`: la IA separa sano de con-drift (§11.6).
- [ ] Bitácora de auditoría registrando tokens, latencia y coste.

**Antes de dar algo por entregado**
- [ ] Respaldos de `audit_logs/` y `feedback/`.
- [ ] Regenerados `INVENTARIO_ARCHIVOS.md`, `REFERENCIA_TECNICA.md` y el grafo (§18).
- [ ] Anotado en `gobierno/control_cambios.md` qué cambió y por quién.
