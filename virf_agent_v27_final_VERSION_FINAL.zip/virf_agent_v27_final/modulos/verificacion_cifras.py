# -*- coding: utf-8 -*-
"""
modulos/verificacion_cifras.py — avisos deterministas sobre lo que afirma el modelo.
═════════════════════════════════════════════════════════════════════════════
Complementa a `validador_citas` (que comprueba CITAS) con tres controles que no
llaman a ninguna IA y que producen AVISOS, nunca retiradas:

  1. `cifras_ausentes(texto, base)` — cifras de la observación que no aparecen en
     nada de lo que se le entregó al modelo. Una cifra que no estaba en la
     evidencia ni en el prompt es inventada o calculada: en ambos casos el
     validador debe poder verlo (auditoría anti-alucinación 2026-11-18, brecha R4).
  2. `sin_cita_literal(evidencia)` — la «evidencia» no trae ninguna cita entre
     comillas ni bloque de código: lo más probable es una paráfrasis presentada
     como cita, que `_verificar_citas` no puede comprobar (brecha R3).
  3. `ventana_relevante(contexto, afirmacion)` — el fragmento más pertinente del
     contexto, para el juez NLI cuando el modelo no citó nada. Antes se pasaban los
     primeros 4000 caracteres, que casi nunca son los relevantes (brecha R5).

Por qué AVISO y no retirada: la retirada (SEG-16) está reservada a lo que se puede
probar falso (una cita que no existe). Una cifra ausente puede ser un cálculo
legítimo; una paráfrasis puede ser fiel. Se declaran para que el validador decida.
"""
from __future__ import annotations

import re
from typing import List

__all__ = ["es_sentinela", "cifras_ausentes", "sin_cita_literal", "ventana_relevante"]

_RE_NUM = re.compile(r"\d+(?:[.,]\d+)*")
_RE_CITA = re.compile(r'"[^"]{10,}"|«[^»]{10,}»|“[^”]{10,}”|```.+?```', re.DOTALL)


def es_sentinela(evidencia: str) -> bool:
    """¿Es la respuesta permitida «No se encontró evidencia…» (y no una cita)?"""
    t = (evidencia or "").strip().lower()
    return t.startswith(("no se encontró evidencia", "no se encontro evidencia"))


def _formas(num: str) -> set:
    """Formas canónicas de una cifra: «99,0»≈«99.0»≈«99»; «1.000»≈«1,000»≈«1000»."""
    formas = {re.sub(r"[.,]", "", num)}
    seps = re.findall(r"[.,]", num)
    if len(seps) == 1:
        ent, dec = re.split(r"[.,]", num)
        if len(dec) == 3 and len(ent) <= 3:          # «1.000»: separador de miles
            return formas
        try:
            formas.add(f"{float(ent + '.' + dec):g}")
        except ValueError:
            pass
    return formas


def _significativa(num: str) -> bool:
    """Los enteros de una cifra (1-9) son numeración y énfasis, no datos."""
    return bool(re.search(r"[.,]", num)) or len(num) >= 2


def cifras_ausentes(texto: str, base: str, maximo: int = 10) -> List[str]:
    """Cifras de `texto` que no aparecen (en ninguna forma equivalente) en `base`."""
    en_base = set()
    for n in _RE_NUM.findall(base or ""):
        en_base |= _formas(n)
    ausentes: List[str] = []
    for n in _RE_NUM.findall(texto or ""):
        if not _significativa(n) or (_formas(n) & en_base) or n in ausentes:
            continue
        ausentes.append(n)
    return ausentes[:maximo]


def sin_cita_literal(evidencia: str) -> bool:
    """Evidencia no vacía, que no es el «no se encontró» y que no trae ninguna cita."""
    e = (evidencia or "").strip()
    return bool(e) and not es_sentinela(e) and not _RE_CITA.search(e)


def ventana_relevante(contexto: str, afirmacion: str, tope: int = 4000) -> str:
    """
    Los párrafos del contexto que más palabras comparten con la afirmación, sin pasar
    de `tope` caracteres y en su orden original. Si el contexto cabe, se devuelve entero.
    """
    contexto = contexto or ""
    if len(contexto) <= tope:
        return contexto
    parrafos = [p for p in re.split(r"\n\s*\n", contexto) if p.strip()]
    # Un párrafo gigante (PDF sin saltos) se parte en trozos para poder elegir.
    trozos: List[str] = []
    for p in parrafos:
        trozos += [p[i:i + 800] for i in range(0, len(p), 800)]
    claves = {w for w in re.findall(r"\w{4,}", (afirmacion or "").lower())}
    if not claves:
        return contexto[:tope]
    puntuados = sorted(
        ((len(claves & set(re.findall(r"\w{4,}", t.lower()))), -i, i) for i, t in enumerate(trozos)),
        reverse=True)
    elegidos, usado = [], 0
    for punt, _, i in puntuados:
        if punt == 0 or usado + len(trozos[i]) > tope:
            continue
        elegidos.append(i)
        usado += len(trozos[i])
    if not elegidos:
        return contexto[:tope]
    return "\n\n".join(trozos[i] for i in sorted(elegidos))
