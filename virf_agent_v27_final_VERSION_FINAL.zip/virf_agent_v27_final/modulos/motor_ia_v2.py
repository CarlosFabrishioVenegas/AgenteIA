"""
modulos/motor_ia_v2.py
======================
Orquestador principal del pipeline VIRF por CONTROL.

Este módulo coordina el flujo end-to-end:
1. Cargar configuración de controles (Excel)
2. Para cada control:
   a. Leer evidencia (manual + script)
   b. Ejecutar motor de controles automáticos (si aplica)
   c. Construir prompt final
   d. Llamar IA con validación de contrato
   e. Compilar hallazgos
3. Generar informe Word consolidado

Arquitectura:
  - Infraestructura (Mx_* en motor/):
      Mx_00 → configuración y constantes
      Mx_01 → lectura de archivos y evidencias
      Mx_02 → construcción de prompts
      Mx_03 → llamadas a API con validación JSON
      Mx_04 → controles automáticos (motor data)
  
  - Orquestación (este archivo):
      evaluar_control()           → evalúa 1 control
      evaluar_todos_controles()   → itera configuración
      generar_informe_final()     → agrega todo en Word
"""

import sys
import json
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timezone

# Resolver rutas de importación
_MODULOS_DIR = Path(__file__).parent.resolve()
_ROOT_DIR = _MODULOS_DIR.parent.resolve()
_MOTOR_DIR = _ROOT_DIR / "motor"

for _p in [str(_MOTOR_DIR), str(_ROOT_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ─── Importar infraestructura Mx ─────────────────────────────────────────────

# Mx_00: Configuración
from Mx_00_CargaRutas import (
    ROL_AGENTE,
    RUTAS,
    UMBRAL_RIESGO_GLOBAL,
    MODO_PREPRDC,
    MODO_PRDC,
)

# Mx_01: Lectura de evidencias
from Mx_01_LecturaEvidencias import (
    leer_archivo_generico,
    compilar_textos_de_carpeta,
    obtener_evidencia_por_control,
    obtener_conocimiento_por_modelo,
    detectar_manual_y_script,
    guardar_parametros_ejecucion,
)

# Mx_02: Construcción de prompts
from Mx_02_EstructuraPrompt import (
    construir_prompt_final,
)

# Mx_03: Llamadas a la API del proveedor activo (Anthropic o Azure OpenAI)
from Mx_03_LlamarIA import (
    _llamar_modelo,
    _parsear_json,
)

# Mx_04: Controles automáticos
from Mx_04_MotorControlesData import (
    ejecutar_motor_data_por_fila,
    convertir_resultado_data_a_texto,
    detectar_cuestionamientos,
)

# ─── Importar utilidades de control y evaluación de datos ─────────────────────
try:
    from modulos.control_evaluacion_data import (
        EstadoEvaluacion,
        create_resultado_control_v13,
        ValidadorInputs,
        DocumentoChunker,
        BuscadorEvidencias,
        CalculadorScore,
        ReportadorEvaluacion,
    )
except ImportError as e:
    print(f"⚠️  Advertencia: control_evaluacion_data no disponible ({e}). Usando modo legacy.")
    # Define fallbacks para compatibilidad
    EstadoEvaluacion = type('EstadoEvaluacion', (), {
        'PENDING': 'PENDING',
        'OK': 'OK',
        'ERROR': 'ERROR',
        'PARTIAL': 'PARTIAL',
    })
    def create_resultado_control_v13(ctrl_id):
        return {
            "control_id": ctrl_id,
            "estado": "PENDING",
            "revision": "",
            "hallazgos": [],
            "resultado_motor": None,
            "fuentes": {"manual": None, "script": None},
            "evidencia_disponible": False,
            "cobertura_docs": 0.0,
            "validacion_previa": {"ok": False, "motivos": []},
            "timestamp_evaluacion": None,
        }


# ══════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN POR CONTROL
# ══════════════════════════════════════════════════════════════════════════════

def evaluar_control(
    ctrl_id: str,
    prompt_control: str,
    base_project_path: str,
    nombre_modelo: str,
    datasets_dict: Optional[Dict[str, Any]] = None,
    config_row: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Evalúa un control individual mediante el pipeline completo (v13 con fixes).
    
    CAMBIOS vs v12:
    ✅ FIX 1: estado = PENDING (no OK), solo OK tras evaluación exitosa
    ✅ FIX 3: Se valida que haya evidencia antes de API call
    ✅ FIX 4: Busca evidencias en inputs/, no en carpeta Evidencias/ fantasma
    ✅ FIX 5: Chunking de documentos largos
    ✅ FIX 7: Pre-flight checks de inputs
    ✅ FIX 8: Flag evidencia_disponible
    
    Flujo:
    1. Pre-flight checks (validación previa)
    2. Buscar evidencia en inputs/ (no en Evidencias/)
    3. Marcar si hay evidencia disponible
    4. Si hay evidencia: chunk, motor, prompt, IA, parseador
    5. Calcular compliance score (inverso a hallazgos)
    6. Retornar resultado con estado PENDING/OK/PARTIAL/ERROR
    
    Parámetros:
        ctrl_id: ID del control (ej: "CTRL_001")
        prompt_control: pregunta específica del control
        base_project_path: ruta raíz del proyecto
        nombre_modelo: nombre del modelo
        datasets_dict: dict de DataFrames para motor
        config_row: fila del Excel con config
    
    Retorna:
        Dict con campos: estado, revision, hallazgos, evidencia_disponible, cobertura_docs
    """
    from config import MAX_CHARS_DOC, MAX_CHARS_CODIGO
    
    # 1. Crear estructura v13
    resultado = create_resultado_control_v13(ctrl_id)
    resultado["timestamp_evaluacion"] = datetime.now().isoformat()
    
    try:
        # 2. PRE-FLIGHT CHECKS (FIX 7)
        validacion = ValidadorInputs.validar_inputs_basicos(base_project_path, ctrl_id)
        resultado["validacion_previa"] = validacion
        
        if not validacion["ok"]:
            resultado["estado"] = EstadoEvaluacion.ERROR
            resultado["revision"] = f"Pre-flight check fallido: {'; '.join(validacion['motivos'])}"
            print(f"  ⚠️  {ctrl_id}: Pre-flight falló - {validacion['motivos'][0] if validacion['motivos'] else 'desconocido'}")
            return resultado
        
        # 3. BUSCAR EVIDENCIAS EN INPUTS/ (FIX 4)
        evidencia_ok, ruta_manual, texto_manual, ruta_script, texto_script = BuscadorEvidencias.buscar_evidencias(
            base_project_path,
            ctrl_id,
            max_chars_doc=MAX_CHARS_DOC,
            max_chars_codigo=MAX_CHARS_CODIGO,
        )
        
        resultado["fuentes"]["manual"] = ruta_manual
        resultado["fuentes"]["script"] = ruta_script
        resultado["evidencia_disponible"] = evidencia_ok  # FIX 8
        
        if not evidencia_ok:
            resultado["estado"] = EstadoEvaluacion.PARTIAL
            resultado["revision"] = "No se encontró evidencia en inputs/ para este control. Evaluación parcial."
            print(f"  ⚠️  {ctrl_id}: Sin evidencia disponible → PARTIAL")
            return resultado
        
        # 4. CHUNKING DE DOCUMENTOS (FIX 5)
        chunks_manual = DocumentoChunker.chunking(texto_manual, max_chars=20000)
        chunks_script = DocumentoChunker.chunking(texto_script, max_chars=20000)
        
        # ── Cobertura de la evidencia de este control ─────────────────────────
        # [AUDIT-FIX] Antes era `max(cobertura_manual, cobertura_script)`. El
        # máximo INFLA: un script de 50 líneas leído entero (1.0) tapaba un
        # manual de 300 páginas truncado al 30%, y el control reportaba
        # "cobertura_docs: 100%" sobre la evidencia que de verdad importa.
        #
        # Se pondera por tamaño, igual criterio que el pipeline de ámbitos.
        _cob_manual = DocumentoChunker.calcular_cobertura(chunks_manual, len(texto_manual))
        _cob_script = DocumentoChunker.calcular_cobertura(chunks_script, len(texto_script))
        _len_manual, _len_script = len(texto_manual or ""), len(texto_script or "")
        _total = _len_manual + _len_script
        cobertura = (
            (_cob_manual * _len_manual + _cob_script * _len_script) / _total
            if _total > 0 else 0.0
        )
        resultado["cobertura_docs"] = round(cobertura, 3)
        resultado["cobertura_detalle"] = {
            "manual": round(_cob_manual, 3), "manual_chars": _len_manual,
            "script": round(_cob_script, 3), "script_chars": _len_script,
        }
        
        # 5. MOTOR DE CONTROLES (si aplica)
        resultado_motor = None
        if config_row and datasets_dict:
            try:
                resultado_motor = ejecutar_motor_data_por_fila(config_row, datasets_dict)
                resultado["resultado_motor"] = resultado_motor
            except Exception as e:
                print(f"  [⚠] Error motor: {e}")
        
        # Convertir motor a texto
        texto_motor = convertir_resultado_data_a_texto(resultado_motor) if resultado_motor else ""
        
        # 6. CONSTRUIR PROMPT FINAL
        prompt_final = construir_prompt_final(
            prompt_control=prompt_control,
            manual="\n".join(c["contenido"] for c in chunks_manual),
            script="\n".join(c["contenido"] for c in chunks_script),
            resultado_data=texto_motor,
        )
        
        # 7. LLAMAR A IA
        print(f"  📞 Llamando IA para {ctrl_id}...")
        texto_respuesta = _llamar_modelo(prompt_final, max_tokens=2048)
        
        # 8. PARSEAR Y VALIDAR (FIX 1: Cambiar estado solo si exitoso)
        fallback = {
            "revision": "No se pudo evaluar el control.",
            "hallazgos": [],
        }
        respuesta_json = _parsear_json(texto_respuesta, fallback)
        
        resultado["revision"] = respuesta_json.get("revision", "")
        resultado["hallazgos"] = respuesta_json.get("hallazgos", [])

        # [BLOQUE 4] Estos controles reciben puntaje y se fusionan en el ámbito
        # «Calidad de datos» del informe: deben poder responder «¿qué prompt
        # produjo este puntaje?» igual que las actividades del estándar.
        from modulos.huella_prompts import sha256_texto as _sha_txt
        resultado["prompt_sha256"] = _sha_txt(prompt_final)[:12]
        resultado["prompt_chars"] = len(prompt_final)
        
        # 9. CALCULAR SCORE (FIX 6: Score inverso a hallazgos)
        n_hallazgos = len(resultado["hallazgos"])
        n_criticos = sum(1 for h in resultado["hallazgos"] if h.get("criticidad") == "CRITICA")
        
        score = CalculadorScore.calcular_score_cumplimiento(resultado["hallazgos"], n_hallazgos)
        resultado["score"] = score
        resultado["interpretacion_score"] = CalculadorScore.interpretar_score(score)
        
        # 10. DETERMINAR ESTADO FINAL (FIX 1)
        # [AUDIT-FIX] Un fallo de PARSEO no es «sin evidencia»: la evidencia
        # estaba y se envió, lo que falló fue interpretar la respuesta. Antes
        # ambos casos caían en PARTIAL; desde que PARTIAL significa «faltan
        # documentos», etiquetar así un fallo técnico manda al operador a
        # buscar evidencia que ya tenía. Se marca como ERROR, que es lo que es.
        if respuesta_json == fallback or "_raw" in respuesta_json:
            resultado["estado"] = EstadoEvaluacion.ERROR
            resultado["revision"] = (
                "No se pudo interpretar la respuesta del modelo (JSON inválido). "
                "La evidencia SÍ estaba disponible: es un fallo técnico, no una "
                "falta de documentación. Re-ejecutar."
            )
        else:
            resultado["estado"] = EstadoEvaluacion.OK  # ✅ CAMBIO: Solo OK si evaluación exitosa
        
        print(f"  ✅ {ctrl_id}: {n_hallazgos} hallazgos ({n_criticos} críticos, score {score:.1f})")
        return resultado
    
    except Exception as e:
        print(f"  ❌ Error evaluando {ctrl_id}: {e}")
        resultado["estado"] = EstadoEvaluacion.ERROR
        resultado["revision"] = f"Error en evaluación: {str(e)}"
        import traceback
        print(f"     Traceback: {traceback.format_exc()[:200]}")
        return resultado


# ══════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN DE TODOS LOS CONTROLES
# ══════════════════════════════════════════════════════════════════════════════

def evaluar_todos_controles(
    excel_controles: str,
    base_project_path: str,
    nombre_modelo: str,
    tier: str = "1",
    datasets_dict: Optional[Dict[str, Any]] = None,
    filtro_controles: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Itera todos los controles del Excel de configuración y los evalúa.
    
    IMPORTANTE: 
    - Solo evalúa controles de CALIDAD DE DATOS (ámbito_control = "Calidad de datos")
    - Filtra por TIER especificado
    - Los controles están organizados jerárquicamente: ÁMBITO → CONTROL → ACTIVIDADES
    
    Parámetros:
        excel_controles: ruta al Excel con configuración de controles
        base_project_path: ruta raíz del proyecto
        nombre_modelo: nombre del modelo
        tier: tier del modelo (para filtrado) — acepta "I", "II", "III", "IV" o "1", "2", "3", "4"
        datasets_dict: dict de DataFrames para motor automático
        filtro_controles: lista de IDs de control a evaluar (None = todos)
    
    Retorna:
        Dict con resultados agregados:
        {
          "fecha_ejecucion": str (ISO),
          "modelo": str,
          "tier": str,
          "total_controles": int,
          "controles_ok": int,
          "controles_error": int,
          "hallazgos_totales": int,
          "hallazgos_criticos": int,
          "resultados_por_control": dict,
        }
    """
    try:
        import pandas as pd
    except ImportError:
        print("[!] Error: pandas no instalado. pip install pandas openpyxl")
        return {}
    
    print(f"\n🔍 Evaluando CALIDAD DE DATOS (Tier {tier})...")

    # Cargar Excel — intentar hoja 'Controles' (ControlesData.xlsx), si no, hoja por defecto
    try:
        xl = pd.ExcelFile(excel_controles)
        sheet = "Controles" if "Controles" in xl.sheet_names else xl.sheet_names[0]
        df_config = xl.parse(sheet)
    except Exception:
        df_config = pd.read_excel(excel_controles)

    # Filtrar solo controles activos si la columna existe
    if "ACTIVO" in df_config.columns:
        df_config = df_config[df_config["ACTIVO"].astype(str).str.strip() == "1"]

    # Filtrar por ámbito solo si la columna existe (ControlesData.xlsx no la tiene)
    # [AUDIT-FIX] Faltaba el `.astype(str)` que SÍ usan los filtros de ACTIVO y
    # TIER (líneas de arriba y abajo). Si la columna AMBITO existe pero está
    # vacía, pandas la lee como float64 y `.str` lanza
    # «Can only use .str accessor with string values». Reproducido con un
    # ControlesData.xlsx de columna AMBITO en blanco.
    if "AMBITO" in df_config.columns:
        df_config = df_config[
            df_config["AMBITO"].astype(str).str.strip().str.lower() == "calidad de datos"
        ]

    # Filtrar por tier si la columna existe
    tier_normalizado = {"I": "I", "II": "II", "III": "III", "IV": "IV",
                        "1": "I", "2": "II", "3": "III", "4": "IV"}.get(str(tier).upper(), str(tier).upper())
    if "TIER" in df_config.columns:
        df_config = df_config[df_config["TIER"].astype(str).str.upper() == tier_normalizado]
    
    if len(df_config) == 0:
        print(f"  ⚠️  No hay controles de CALIDAD DE DATOS para Tier {tier}.")
        return {
            "fecha_ejecucion":       datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "modelo":                nombre_modelo,
            "tier":                  tier,
            "total_controles":       0,
            "controles_ok":          0,
            "controles_error":       0,
            "controles_sin_evidencia": 0,
            "hallazgos_totales":     0,
            "hallazgos_criticos":    0,
            "resultados_por_control": {},
        }
    
    # Filtrar por controles específicos si se pasa
    if filtro_controles:
        df_config = df_config[df_config["ID_CONTROL"].isin(filtro_controles)]
    
    print(f"  📊 {len(df_config)} controles a evaluar\n")
    
    # Procesar cada control
    resultados_por_control = {}
    controles_ok = 0
    controles_error = 0
    controles_sin_evidencia = 0
    hallazgos_totales = 0
    hallazgos_criticos = 0
    
    # [AUDIT-FIX] `enumerate` en vez del índice del DataFrame. `iterrows()`
    # devuelve el índice ORIGINAL del Excel, que tras filtrar por ACTIVO/ÁMBITO/
    # TIER deja de ser contiguo: el progreso mostraba «[7/5]» y «[9/5]»,
    # fracciones imposibles, durante corridas que duran minutos.
    # `idx` se conserva para los avisos, porque ahí sí interesa la fila del Excel.
    for pos, (idx, row) in enumerate(df_config.iterrows(), start=1):
        ctrl_id = str(row.get("ID_CONTROL", "")).strip()
        prompt = str(row.get("PROMPT_CONTROL", row.get("PROMPT", ""))).strip()

        if not ctrl_id or not prompt:
            print(f"  ⚠️  Fila {idx} del Excel: falta ID_CONTROL o PROMPT, omitiendo...")
            continue

        print(f"  [{pos}/{len(df_config)}] {ctrl_id}")
        
        # Evaluar control
        resultado = evaluar_control(
            ctrl_id=ctrl_id,
            prompt_control=prompt,
            base_project_path=base_project_path,
            nombre_modelo=nombre_modelo,
            datasets_dict=datasets_dict,
            config_row=dict(row),
        )
        resultado["prompt_control"] = prompt
        resultados_por_control[ctrl_id] = resultado
        
        # [AUDIT-FIX] Antes: `if estado == "OK" … else: controles_error += 1`.
        # Dos consecuencias, ambas del mismo error de agrupar «todo lo que no
        # es OK» como error:
        #
        #  1. PARTIAL (control SIN EVIDENCIA) se contaba como ERROR. Con todos
        #     los controles sin evidencia, `_err == _total` → estado "ERROR" y
        #     «El dictamen NO es concluyente hasta resolver los fallos»: se
        #     acusa de fallo al sistema cuando lo que falta son documentos.
        #     Es el gemelo del bug de score_global 0.00 → CRÍTICO.
        #  2. Los hallazgos solo se acumulaban en la rama OK. Si la excepción
        #     salta DESPUÉS de poblar `resultado["hallazgos"]` (línea ~253), el
        #     control queda en ERROR y sus hallazgos críticos —ya extraídos—
        #     desaparecían del recuento.
        _estado_ctrl = resultado.get("estado")
        _hallazgos = resultado.get("hallazgos") or []

        if _estado_ctrl == EstadoEvaluacion.OK:
            controles_ok += 1
        elif _estado_ctrl == EstadoEvaluacion.PARTIAL:
            controles_sin_evidencia += 1
        else:
            controles_error += 1

        # Los hallazgos ya extraídos son reales, cualquiera sea el estado final.
        hallazgos_totales += len(_hallazgos)
        hallazgos_criticos += sum(
            1 for h in _hallazgos if h.get("criticidad") == "CRITICA"
        )
    
    # Resumen
    return {
        "fecha_ejecucion":       datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "modelo":                nombre_modelo,
        "tier":                  tier,
        "total_controles":       len(df_config),
        "controles_ok":          controles_ok,
        "controles_error":       controles_error,
        "controles_sin_evidencia": controles_sin_evidencia,
        "hallazgos_totales":     hallazgos_totales,
        "hallazgos_criticos":    hallazgos_criticos,
        "resultados_por_control": resultados_por_control,
    }


# ══════════════════════════════════════════════════════════════════════════════
# GENERACIÓN DE INFORME FINAL
# ══════════════════════════════════════════════════════════════════════════════

def generar_informe_final(
    resultados_evaluacion: Dict[str, Any],
    outputs_dir: str,
    titulo_informe: str,
    tier: str,
) -> Path:
    """
    Genera informe Word consolidando todos los resultados de controles.
    
    Estructura del informe:
    - Portada
    - Resumen ejecutivo
    - ÁMBITO: CALIDAD DE DATOS
      - Control: [nombre]
        - Actividad 1: [evaluación + resultado + recomendación]
        - Actividad 2: [evaluación + resultado + recomendación]
      - Control: [nombre]
        - Actividad 1: [...]
    
    Parámetros:
        resultados_evaluacion: dict retornado por evaluar_todos_controles()
        outputs_dir: ruta de salida para el Word
        titulo_informe: título del informe
        tier: tier del modelo
    
    Retorna:
        Path al archivo Word generado
    """
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor, Cm
        from docx.enum.text import WD_ALIGN_PARAGRAPH
    except ImportError:
        print("  ❌ Error: python-docx no instalado. pip install python-docx")
        return None
    
    print(f"\n📝 Generando informe Word con estructura jerárquica...")
    
    # Colores corporativos
    AZUL_DARK = RGBColor(0x1F, 0x38, 0x64)
    AZUL_MID = RGBColor(0x2E, 0x75, 0xB6)
    GRIS_TEXT = RGBColor(0x40, 0x40, 0x40)
    BLANCO = RGBColor(0xFF, 0xFF, 0xFF)
    ROJO = RGBColor(0xC0, 0x00, 0x00)
    AMARILLO = RGBColor(0xFF, 0xC0, 0x00)
    VERDE = RGBColor(0x37, 0x86, 0x44)
    
    # Mapeo criticidad → color
    CRIT_COLOR = {
        "CRITICA": ROJO,
        "MODERADA": AMARILLO,
        "BAJA": VERDE,
        "POTENCIAL": GRIS_TEXT,
    }
    
    # Crear documento
    doc = Document()
    
    # ─── PORTADA ─────────────────────────────────────────────────────────────
    for _ in range(8):
        doc.add_paragraph()
    
    p_titulo = doc.add_paragraph()
    p_titulo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_titulo.add_run("INFORME DE VALIDACIÓN VIRF")
    r.font.size = Pt(24)
    r.font.bold = True
    r.font.color.rgb = AZUL_DARK
    
    p_modelo = doc.add_paragraph()
    p_modelo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_modelo.add_run(titulo_informe)
    r.font.size = Pt(18)
    r.font.color.rgb = AZUL_MID
    
    p_tier = doc.add_paragraph()
    p_tier.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_tier.add_run(f"Tier {tier}")
    r.font.size = Pt(14)
    r.font.color.rgb = AZUL_MID
    
    for _ in range(4):
        doc.add_paragraph()
    
    p_fecha = doc.add_paragraph()
    p_fecha.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_fecha.add_run(
        f"Fecha de emisión: {datetime.now().strftime('%d/%m/%Y')}\n"
        "Calidad de Datos — Segunda Línea de Defensa"
    )
    r.font.size = Pt(11)
    r.font.italic = True
    r.font.color.rgb = GRIS_TEXT
    
    doc.add_page_break()
    
    # ─── RESUMEN EJECUTIVO ────────────────────────────────────────────────────
    h1 = doc.add_heading("RESUMEN EJECUTIVO", level=1)
    h1.runs[0].font.color.rgb = AZUL_DARK
    
    p_resumen = doc.add_paragraph()
    r = p_resumen.add_run(
        f"Se ha completado la evaluación de {resultados_evaluacion['total_controles']} controles de Calidad de Datos.\n\n"
    )
    r.font.size = Pt(10)
    
    r2 = p_resumen.add_run(
        f"Resultados:\n"
        f"• Controles exitosos: {resultados_evaluacion['controles_ok']}/{resultados_evaluacion['total_controles']}\n"
        f"• Hallazgos totales: {resultados_evaluacion['hallazgos_totales']}\n"
        f"• Hallazgos críticos: {resultados_evaluacion['hallazgos_criticos']}"
    )
    r2.font.size = Pt(10)
    
    doc.add_paragraph()
    
    # ─── SECCIÓN: ÁMBITO CALIDAD DE DATOS ─────────────────────────────────────
    h2 = doc.add_heading("ÁMBITO: CALIDAD DE DATOS", level=1)
    h2.runs[0].font.color.rgb = AZUL_DARK
    
    resultados = resultados_evaluacion.get("resultados_por_control", {})
    
    for ctrl_num, (ctrl_id, ctrl_resultado) in enumerate(resultados.items(), 1):
        # Encabezado de control
        h3 = doc.add_heading(f"Control: {ctrl_id}", level=2)
        h3.runs[0].font.color.rgb = AZUL_MID
        
        # Actividades (hallazgos) dentro del control
        hallazgos = ctrl_resultado.get("hallazgos", [])
        
        if not hallazgos:
            p_sin_hallazgos = doc.add_paragraph("Sin hallazgos identificados en este control.")
            p_sin_hallazgos.paragraph_format.left_indent = Cm(1.0)
            p_sin_hallazgos.runs[0].font.size = Pt(9)
            p_sin_hallazgos.runs[0].font.italic = True
            p_sin_hallazgos.runs[0].font.color.rgb = VERDE
        else:
            for act_num, hallazgo in enumerate(hallazgos, 1):
                # ─── ACTIVIDAD EVALUADA ───
                p_act = doc.add_paragraph()
                p_act.paragraph_format.left_indent = Cm(0.5)
                p_act.paragraph_format.space_before = Pt(10)
                r_act = p_act.add_run(f"{act_num}. {hallazgo.get('texto', 'Actividad sin descripción')}")
                r_act.font.size = Pt(9)
                r_act.font.bold = True
                r_act.font.color.rgb = AZUL_MID
                
                # ─── CONCEPTO DE ACTIVIDAD ───
                p_concepto_lbl = doc.add_paragraph()
                p_concepto_lbl.paragraph_format.left_indent = Cm(1.0)
                p_concepto_lbl.paragraph_format.space_before = Pt(6)
                p_concepto_lbl.paragraph_format.space_after = Pt(1)
                r_lbl = p_concepto_lbl.add_run("Concepto de actividad:")
                r_lbl.font.size = Pt(9)
                r_lbl.font.bold = True
                r_lbl.font.color.rgb = AZUL_MID
                
                p_concepto = doc.add_paragraph()
                p_concepto.paragraph_format.left_indent = Cm(1.0)
                p_concepto.paragraph_format.space_before = Pt(1)
                p_concepto.paragraph_format.space_after = Pt(3)
                r_concepto = p_concepto.add_run("Pendiente de evaluación — sin documentación disponible.")
                r_concepto.font.size = Pt(9)
                r_concepto.font.color.rgb = GRIS_TEXT
                
                # ─── RESULTADO DE LA ACTIVIDAD ───
                p_resultado_lbl = doc.add_paragraph()
                p_resultado_lbl.paragraph_format.left_indent = Cm(1.0)
                p_resultado_lbl.paragraph_format.space_before = Pt(6)
                p_resultado_lbl.paragraph_format.space_after = Pt(1)
                r_lbl2 = p_resultado_lbl.add_run("Resultado de la actividad:")
                r_lbl2.font.size = Pt(9)
                r_lbl2.font.bold = True
                r_lbl2.font.color.rgb = AZUL_MID
                
                p_resultado = doc.add_paragraph()
                p_resultado.paragraph_format.left_indent = Cm(1.0)
                p_resultado.paragraph_format.space_before = Pt(1)
                p_resultado.paragraph_format.space_after = Pt(3)
                
                criticidad = hallazgo.get('criticidad', 'MODERADA')
                estado_map = {
                    'CRITICA': 'NO CUMPLE',
                    'MODERADA': 'CON OBSERVACIONES',
                    'BAJA': 'CUMPLE CON OBSERVACIONES MENORES',
                    'POTENCIAL': 'CUMPLE PLENAMENTE'
                }
                estado_texto = estado_map.get(criticidad, 'SIN CLASIFICAR')
                
                r_resultado = p_resultado.add_run(f"1/5 — No cumple  |  NO CUMPLE")
                r_resultado.font.size = Pt(9)
                r_resultado.font.bold = True
                r_resultado.font.color.rgb = ROJO
                
                # ─── OBSERVACIÓN ───
                p_obs_lbl = doc.add_paragraph()
                p_obs_lbl.paragraph_format.left_indent = Cm(1.0)
                p_obs_lbl.paragraph_format.space_before = Pt(6)
                p_obs_lbl.paragraph_format.space_after = Pt(1)
                r_lbl3 = p_obs_lbl.add_run("Observación:")
                r_lbl3.font.size = Pt(9)
                r_lbl3.font.bold = True
                r_lbl3.font.color.rgb = AZUL_MID
                
                p_obs = doc.add_paragraph()
                p_obs.paragraph_format.left_indent = Cm(1.0)
                p_obs.paragraph_format.space_before = Pt(1)
                p_obs.paragraph_format.space_after = Pt(3)
                r_obs = p_obs.add_run("No cumple con los criterios de validación establecidos para esta actividad.")
                r_obs.font.size = Pt(9)
                r_obs.font.color.rgb = GRIS_TEXT
                
                # ─── OPORTUNIDAD DE MEJORA ───
                p_mejora_lbl = doc.add_paragraph()
                p_mejora_lbl.paragraph_format.left_indent = Cm(1.0)
                p_mejora_lbl.paragraph_format.space_before = Pt(6)
                p_mejora_lbl.paragraph_format.space_after = Pt(1)
                r_lbl4 = p_mejora_lbl.add_run("Oportunidad de mejora:")
                r_lbl4.font.size = Pt(9)
                r_lbl4.font.bold = True
                r_lbl4.font.color.rgb = AZUL_MID
                
                p_mejora = doc.add_paragraph()
                p_mejora.paragraph_format.left_indent = Cm(1.0)
                p_mejora.paragraph_format.space_before = Pt(1)
                p_mejora.paragraph_format.space_after = Pt(8)
                r_mejora = p_mejora.add_run(hallazgo.get('recomendacion', 'Se recomienda revisar y validar el control según los hallazgos identificados.'))
                r_mejora.font.size = Pt(9)
                r_mejora.font.color.rgb = GRIS_TEXT
    
    # ─── GUARDAR DOCUMENTO ────────────────────────────────────────────────────
    fecha_str = datetime.now().strftime("%Y%m%d")
    nombre_archivo = f"VIRF_Informe_CDD_{titulo_informe.replace(' ', '_')}_{fecha_str}.docx"
    ruta_salida = Path(outputs_dir) / nombre_archivo
    
    from modulos.clasificacion_docx import aplicar as _clasificar  # [SEG-10]
    _clasificar(doc)
    doc.save(str(ruta_salida))
    print(f"  ✅ Informe Word generado: {nombre_archivo}")
    
    return ruta_salida


# ══════════════════════════════════════════════════════════════════════════════
# FUNCIÓN PRINCIPAL DE ORQUESTACIÓN
# ══════════════════════════════════════════════════════════════════════════════

def orquestar_pipeline_virf(
    base_project_path: str,
    excel_controles: str,
    nombre_modelo: str,
    fecha_informe: str,
    tier: str = "1",
    datasets_dict: Optional[Dict[str, Any]] = None,
    filtro_controles: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Orquesta el pipeline completo end-to-end.
    
    Parámetros:
        base_project_path: ruta raíz del proyecto (contiene Evidencias/, Conocimiento/, etc.)
        excel_controles: ruta al Excel de configuración de controles
        nombre_modelo: nombre del modelo bajo validación
        fecha_informe: fecha en formato YYYY-MM-DD
        tier: tier del modelo (1, 2, 3, 4)
        datasets_dict: dict de DataFrames para motor automático
        filtro_controles: lista de IDs de control a validar (None = todos)
    
    Retorna:
        Dict con estado del pipeline y rutas de salida
    """
    base_path = Path(base_project_path)

    # [P0.3 2026-07-30] Antes: `base_path / "outputs" / fecha_informe`.
    #
    # `base_project_path` es la RAÍZ DE EVIDENCIA, no la del proyecto: con
    # `--raiz-evidencia modelos/VaR_FRTB` los resultados aterrizaban en
    # `modelos/VaR_FRTB/outputs/`, mientras el pipeline completo escribía en
    # `outputs/`. Dos pipelines del mismo agente dejando los informes en sitios
    # distintos según un flag que solo debía redirigir la ENTRADA.
    #
    # Consecuencias medidas: el operador no encontraba los informes donde
    # siempre, y `--verificar-cadena` —que lee de OUTPUTS_DIR— no los veía, así
    # que la cadena de custodia de un modelo validado por controles quedaba
    # invisible para su propia herramienta de verificación.
    #
    # `redirigir_evidencia` ya declara la regla: se redirige la evidencia;
    # `outputs/`, el estándar y el caché permanecen en la raíz del proyecto.
    from config.rutas import OUTPUTS_DIR
    outputs_dir = OUTPUTS_DIR / fecha_informe
    outputs_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"""
╔════════════════════════════════════════════════════════════════╗
║  PIPELINE VIRF - VALIDACIÓN DE CONTROLES                      ║
║  Modelo: {nombre_modelo:42}║
║  Tier: {tier:51}║
║  Fecha: {fecha_informe:45}║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    # Guardar parámetros de ejecución
    csv_params = guardar_parametros_ejecucion(
        str(outputs_dir),
        nombre_modelo,
        fecha_informe,
        tier,
        excel_controles,
    )
    print(f"  📋 Parámetros guardados: {csv_params.name}")
    
    # Evaluar todos los controles
    resultados_evaluacion = evaluar_todos_controles(
        excel_controles=excel_controles,
        base_project_path=str(base_path),
        nombre_modelo=nombre_modelo,
        tier=tier,
        datasets_dict=datasets_dict,
        filtro_controles=filtro_controles,
    )
    
    if not resultados_evaluacion:
        print("  ❌ No se pudieron evaluar controles")
        return {"estado": "ERROR"}
    
    # Guardar resultados JSON
    # [SEGURIDAD 2026-07-30] `nombre_modelo` viene de `--titulo`, es decir, de la
    # línea de comandos. Aquí se interpolaba CRUDO en la ruta de salida:
    # `--titulo "../../../evil"` escribía el JSON fuera de outputs/, y un título
    # con `/` fallaba con FileNotFoundError DESPUÉS de pagar todas las llamadas.
    #
    # El pipeline completo ya saneaba (agente.py, `nombre_seguro_titulo`) y hay
    # un test que lo fija —TestAuditoriaPathTraversalEnSalidas— pero solo
    # verificaba agente.py y explicador_modelo.py. Este tercer punto quedó fuera
    # de la red y siguió vulnerable.
    #
    # El título original se conserva íntegro DENTRO del JSON: solo se sanea el
    # nombre de fichero.
    from config.rutas import nombre_seguro
    json_resultados = (outputs_dir /
                       f"resultados_{nombre_seguro(nombre_modelo)}_{fecha_informe}.json")
    # [P0.1-A 2026-07-30] El JSON se SELLA en la cadena de custodia.
    #
    # Antes se escribía con un `json.dump` suelto. Como `informes_de_modelo()`
    # barre `resultados_*.json` —el patrón que se escribe justo aquí arriba—,
    # estas corridas YA entraban en la cadena, pero sin sello. Medido:
    #
    #     [ 1] resultados_LaR_ctrl.json  → ⚠️  SIN CUSTODIA
    #     [ 2] resultados_LaR_A.json     → ❌ ROTO  «se insertó, borró,
    #                                          reordenó o alteró un informe»
    #     integra: False
    #
    # Una sola corrida de trabajo bastaba para que `--verificar-cadena`
    # acusara a un ENTREGABLE LEGÍTIMO de haber sido manipulado.
    #
    # Se sella como `trabajo`, NO como entregable, y NO se pide firma: firmar
    # es un acto de aprobación y este pipeline no aprueba nada — el entregable
    # sale del pipeline completo, que ya ejecuta y fusiona estos controles
    # (decisión registrada en FLAGS.md §16.1).
    try:
        # Convertir DataFrames a string para serializar
        res_copy = resultados_evaluacion.copy()
        for ctrl_id, res in res_copy.get("resultados_por_control", {}).items():
            if res.get("resultado_motor") and "detalle" in res["resultado_motor"]:
                res["resultado_motor"]["detalle"] = str(res["resultado_motor"]["detalle"])

        from modulos import custodia as _custodia
        res_copy, _archivado = _custodia.sellar_y_escribir(
            res_copy, json_resultados, outputs_dir, nombre_modelo,
            tipo=_custodia.TIPO_TRABAJO)
        _pos = (res_copy.get("custodia") or {}).get("posicion_en_cadena", "?")
        print(f"  💾 Resultados JSON: {json_resultados.name} "
              f"(sellado, eslabón #{_pos} · corrida de trabajo)")
        if _archivado:
            print(f"     ↩️  Corrida previa preservada: {_archivado.name}")
    except Exception as e:
        print(f"  ⚠️  Error guardando JSON: {e}")
    
    # Generar informe Word
    titulo = f"Validación VIRF - {nombre_modelo} - Tier {tier}"
    word_path = generar_informe_final(
        resultados_evaluacion,
        str(outputs_dir),
        titulo,
        tier,
    )
    
    # Resumen final
    print(f"""
╔════════════════════════════════════════════════════════════════╗
║  RESUMEN DE EJECUCIÓN                                          ║
║  ✅ Controles OK:      {resultados_evaluacion['controles_ok']:3d}/{resultados_evaluacion['total_controles']:<3d}
║  ❌ Controles ERROR:   {resultados_evaluacion['controles_error']:3d}
║  🔴 Hallazgos Críticos: {resultados_evaluacion['hallazgos_criticos']:3d}
║  📊 Hallazgos Totales: {resultados_evaluacion['hallazgos_totales']:3d}
║  📁 Salida:            {str(outputs_dir)[:42]:<42}║
╚════════════════════════════════════════════════════════════════╝
    """)
    
    # ── [ESTADO-FIX] Estado DERIVADO del resultado real ──────────────────────
    # Antes esto era `"estado": "OK"` hardcodeado: el pipeline informaba OK
    # aunque los 4 controles hubieran fallado. En una herramienta de dictamen
    # regulatorio, un "OK" falso es peor que un error visible.
    _total = resultados_evaluacion["total_controles"]
    _ok = resultados_evaluacion["controles_ok"]
    _err = resultados_evaluacion.get("controles_error", 0)
    _sin_ev = resultados_evaluacion.get("controles_sin_evidencia", 0)
    _crit = resultados_evaluacion.get("hallazgos_criticos", 0)

    # [AUDIT-FIX] «Sin evidencia» y «fallo técnico» son diagnósticos distintos y
    # exigen acciones distintas. Antes ambos caían en `controles_error`, así que
    # una corrida donde faltaban los documentos se anunciaba como
    # estado "ERROR" + «resolver los fallos»: se acusaba al sistema de estar
    # roto cuando lo que faltaba era la evidencia. Mismo defecto que el score
    # global 0.00 → CRÍTICO, y la misma corrección: nombrar el vacío.
    if _total == 0:
        _estado = "SIN_CONTROLES"
    elif _err == _total:
        _estado = "ERROR"            # ningún control pudo evaluarse por fallo
    elif _sin_ev == _total:
        _estado = "SIN_EVIDENCIA"    # el sistema funcionó; faltan documentos
    elif _err > 0 or _ok < _total:
        _estado = "PARCIAL"          # evaluación incompleta
    elif _crit > 0:
        _estado = "CON_HALLAZGOS"    # todo evaluado, pero hay hallazgos críticos
    else:
        _estado = "OK"

    _confiable = (_estado in ("OK", "CON_HALLAZGOS"))

    if not _confiable:
        print(f"  ⚠️  ESTADO: {_estado} — {_ok}/{_total} controles evaluados"
              f"{f', {_err} con error' if _err else ''}"
              f"{f', {_sin_ev} sin evidencia' if _sin_ev else ''}.")
        if _estado == "SIN_EVIDENCIA":
            print("      NO hay nada roto: no se encontró evidencia en inputs/")
            print("      para ninguno de los controles. Aporta los documentos")
            print("      y vuelve a ejecutar. Esto NO es un dictamen desfavorable.")
        elif _sin_ev and _err:
            print(f"      {_err} fallo(s) técnico(s) a resolver y {_sin_ev} "
                  f"control(es) esperando evidencia.")
        else:
            print("      El dictamen NO es concluyente hasta resolver los fallos.")

    return {
        "estado":              _estado,
        "dictamen_confiable":  _confiable,
        "fecha_ejecucion":     resultados_evaluacion.get("fecha_ejecucion"),
        "modelo":              nombre_modelo,
        "tier":                tier,
        "total_controles":     _total,
        "controles_ok":        _ok,
        "controles_error":     _err,
        "controles_sin_evidencia": _sin_ev,
        "hallazgos_criticos":  _crit,
        "ruta_json":           str(json_resultados),
        "ruta_word":           str(word_path) if word_path else None,
        "ruta_outputs":        str(outputs_dir),
    }


__all__ = [
    "evaluar_control",
    "evaluar_todos_controles",
    "generar_informe_final",
    "orquestar_pipeline_virf",
]
