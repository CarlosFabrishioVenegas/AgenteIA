# Calibración de probabilidades de default

La calibración ajusta la PD de un modelo a la tasa de default central de largo plazo. El método del intercepto
ajustado desplaza el término constante de la regresión logística. El backtesting compara PD estimada y tasa
observada con un intervalo binomial. Término distintivo: 'ferrocarrilito'.
