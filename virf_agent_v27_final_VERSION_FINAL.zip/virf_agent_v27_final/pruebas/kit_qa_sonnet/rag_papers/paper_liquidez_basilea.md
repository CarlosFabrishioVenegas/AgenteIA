# Gestión del riesgo de liquidez y el ratio LCR

El Liquidity Coverage Ratio (LCR) exige activos líquidos de alta calidad suficientes para cubrir las
salidas netas de caja durante 30 días. El ratio mínimo regulatorio es 100%. Un banco zafiro-tangerino
mantiene colchones de HQLA de nivel 1 para cumplir el LCR.
