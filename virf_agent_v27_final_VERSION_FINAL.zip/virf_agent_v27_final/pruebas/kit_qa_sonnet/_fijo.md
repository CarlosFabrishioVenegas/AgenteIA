
## Fallos

### F1 · Cuestionamientos globales sin autenticación (SEGURIDAD, alta)
- Repro: sin cookie, `POST /api/cuestionamientos/default/data_leakage_escalado/toggle` con `{"activo": true}` devuelve **200** y escribe `config/cuestionamientos_activos.json`. Igual `GET /api/cuestionamientos/default`, `GET|POST /api/cuestionamientos/personalizados` y `DELETE /api/cuestionamientos/personalizados/{id}`.
- Esperado: 401 sin sesión (y rol de gestión para escribir un fichero global compartido por todos los validadores). El resto de routers sí exigen sesión.
- Causa probable: `web/routers/cuestionamientos.py:105,123,135,143,159` — ningún endpoint declara `Depends(contexto_sesion)` ni `requiere(...)`. (La prueba escribió el mismo valor `true` que ya tenía el fichero versionado: sin cambio efectivo.)

### F2 · No se pueden subir papers a un dominio RAG custom (funcional, alta)
- Repro: `POST /api/rag/dominios/crear` (200) y luego `POST /api/inputs/upload?destino=rag_<id>&clasificacion=Publico&dueno=QA&vigencia=2027-12-31` (lo que hace la UI en `subirPapersRag`) devuelve **400 «destino desconocido: 'rag_qa_sonnet_dom_…'»**. `/api/inputs/destinos` solo lista rag_LaR/VaR/ALM/shared.
- Esperado: los dominios custom aceptan papers (su tarjeta ofrece dropzone y el mensaje «Subidos N paper(s)»).
- Causa probable: `web/services/contexto_sesion.py:208-232` (`_DESTINOS_GLOBALES` fijo) y `resolver_destino` (`:267-276`) no consideran los dominios de `dominios_custom_store`; la UI los construye como `rag_${dom.dominio}` (`web/static/js/app.js:764`, `:891-905`).
- Consecuencia: **no se pudieron subir ni indexar los 4 papers de prueba, así que no se probó la búsqueda/recuperación sobre el dominio `qa_sonnet_*`** (ver SKIP). No se escribió a mano en `inputs/rag`.

### F3 · La subida de evidencia no valida la extensión contra `formatos` de la tarjeta (media)
- Repro: `POST /api/inputs/upload?destino=doc_modelamiento&clasificacion=Interno` con `macro.exe` devuelve **200** y lo guarda (luego se borró).
- Esperado: 400/415 (la tarjeta declara `.pdf,.docx,.md,.txt`); hoy solo el `<input accept>` del navegador lo limita.
- Causa probable: `web/routers/upload.py:176-215` (`subir_archivos`) y `_nombre_seguro` (`:48-60`) solo comprueban `NOMBRES_PROHIBIDOS` (`web/config_web.py:15`); no usan los `formatos` de `destinos_disponibles()`.

### F4 · El notebook 01 «Control de datos» sin IA no detecta duplicados de llave (calidad, media)
- Repro: insumos con `clientes.csv` que tiene 2 `id_cliente` repetidos; ITER0 de la etapa 01 con `usar_ia=false`; ejecutar el `.ipynb`. Hoja «Controles»: `clientes | filas duplicadas | 0`; `saldos.saldo | negativos | 48`. No hay control de unicidad de la llave, ni integridad referencial (saldos con `id_cliente=99999` huérfano), ni columna `resultado`.
- Esperado (misión de la etapa 01: «unicidad, nulos, rangos, integridad referencial…»): al menos unicidad de llave con afectados>0. El 00 tampoco marca duplicados de llave (`duplicados` cuenta filas completas).
- Causa probable: plantilla determinista `modulos/validacion_completa.py:520` (`_celdas_plantilla`) y `_determinista` (`:800`).

### F5 · Firmante vacío en «Validar modelo» (UI, baja)
- Repro: entrar a un modelo, abrir Validar modelo: «Firma la identidad con la que entraste (SSO): **—**» (también tras recargar).
- Causa probable: `web/static/js/app.js:2139-2143` rellena `#firm-identidad` en el cableado inicial, cuando `estado.validador` aún es `null` (se carga después en `:2759-2762` y `:3628`). Debe actualizarse al abrir la vista.

### F6 · Texto de ayuda obsoleto en «Documentar» (UI, baja)
- `web/templates/index.html:524` indica subir los Excels en «Subir evidencia → automatizaciones/», pero esa tarjeta está oculta (`"oculto": True`, `web/services/contexto_sesion.py:~180`) y en Validación completa se envían al chat de cada etapa.

### Observaciones (no cuentan como FAIL)
- La cookie `virf_token` se emite con `Secure` (`web/routers/auth.py:84-85`): clientes HTTP planos (httpx/requests) no la reenvían en `http://localhost`; el driver gestiona la cookie a mano. Chrome sí la acepta en localhost.
- `GET /api/auth/login` responde 503 en modo libre (esperado: SSO no configurado).
- `POST /api/auth/login-libre` con un rol inexistente no se rechaza (informativo).
- Borrar un dominio custom lo mueve a `archivo/dominios_retirados/` en vez de borrarlo; los 5 directorios `qa_sonnet_dom_*` generados por estas pruebas se eliminaron a mano.
- Los notebooks 00–04 sin IA se ejecutan con exit 0 y producen su Excel (`<etapa>_resultadoITER0.xlsx`); una ruta UNC inexistente se registra como error en la hoja «Mapeo» sin romper el notebook.
- El Word del informe consolidado SÍ incluye el anexo «Validación completa · sustento por etapa» con las imágenes y pies «Figura S1…».
- El JSON de resultados para el informe se SIEMBRA a mano en la carpeta de la sesión del modelo QA (el pipeline real llama al LLM). Un campo `agente` como cadena (en vez de objeto) rompe `POST /api/chat/iniciar` con 500 (`web/services/chat_service.py` en `iniciar`, `(datos.get("agente") or {}).get(...)`): JSON mal formado, pero sería más robusto responder 400/422.

## SKIP (no probado)
- `POST /api/config/modelo|virf_plus|verificar`: escriben configuración global o llaman al proveedor IA.
- `POST /api/entendimiento/analizar`, `POST /api/validar/lanzar`, `POST /api/chat/adjuntar`, `POST /api/solo-informe/ia/*`: llaman al LLM de pago (sin flag `usar_ia`).
- `POST /api/chat/consolidar`, `POST /api/feedback/aprobar`, `POST /api/codigo/aprobar`, `POST|DELETE /api/cuestionamientos/default|personalizados` (salvo la prueba 401 de F1): escrituras globales o aprobaciones.
- `POST /api/auth/logout`: ejecuta `purgar_vencidos()` sobre raíces de retención globales (borraría ficheros ajenos vencidos).
- Subidas a destinos globales `rag_LaR|VaR|ALM|shared` y `POST /api/rag/reconstruir` de dominios fijos o `all`: tocarían el corpus compartido.
- Recuperación/búsqueda RAG sobre el dominio de prueba, reconstrucción de su índice y borrado de paper: bloqueados por F2.
- UI: subida masiva por las 10 tarjetas, chat de etapa, insumos y reglas por UI: el clasificador de permisos del entorno bloqueó el script de subida masiva vía navegador; cubierto por HTTP y por el mapa estático de botones.

## Limpieza
Modelos `QA_SONNET_*` (HTTP y UI), dominio `qa_sonnet_dom_*` y sus archivados borrados; sin residuos en `inputs/rag` ni `data/rag_lexico`. Quedan el kit y `descargas/` (docx/ipynb generados) en `pruebas/kit_qa_sonnet/`, más las carpetas de usuario `PRUEBA_QA_SONNET` y `PRUEBA_QA_SONNET_UI` bajo `web/data/sesiones` y sus entradas en `web/data/validadores.json` (creadas por el login libre).
