"""
Reproduce «Validar modelo» SIN gastar IA: lanza agente.py con los mismos
argumentos que la web (pipeline_runner.construir_args), sobre una sesión
temporal armada con la evidencia del kit, y con un cliente IA FALSO que
responde el JSON de evaluación esperado. Sirve para ver si la corrida falla por
algo ajeno al proveedor (lectura de evidencia, estándar, chunking, informe…).

Uso:
  .venv/Scripts/python.exe -X utf8 pruebas/kit_qa_sonnet/reproducir_corrida.py            # lanza
  (internamente se relanza a sí mismo con --hijo como proceso del pipeline)
"""
from __future__ import annotations

import json
import os
import runpy
import secrets
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
KIT = Path(__file__).resolve().parent


class IAFalsa:
    """Cliente IA sin red: responde el esquema de evaluación de motor_ia."""
    descripcion = "IA falsa (reproducción local)"
    ultimo_error_conexion = ""
    modelo = "falso"

    def validar_conexion(self) -> bool:
        return True

    def generar_mensaje(self, prompt="", instruccion_sistema="", max_tokens=None,
                        sistema=None, formato_json=False, **_):
        if "puntaje" in prompt and "evidencia_encontrada" in prompt:
            return json.dumps({
                "puntaje": 3,
                "concepto": "Actividad evaluada por la IA falsa de la reproducción.",
                "observacion": "Respuesta sintética. Sirve para recorrer el pipeline. "
                               "No es una evaluación real. Se usa en pruebas locales.",
                "evidencia_encontrada": "No se encontró evidencia en el contexto disponible",
                "inconsistencias": [], "cuestionamiento_metodologico": "",
                "preguntas_pendientes": [], "recomendacion": "",
            }, ensure_ascii=False)
        # Resto de llamadas (resúmenes, chunking, informe narrativo…): JSON neutro
        # que también es texto aceptable.
        return json.dumps({"resumen": "Texto sintético de la reproducción.",
                           "texto": "Texto sintético de la reproducción."}, ensure_ascii=False)


def hijo(argv: list[str]) -> None:
    import config.ia as ia
    falsa = IAFalsa()
    ia.get_cliente_ia = lambda *a, **k: falsa
    import config
    config.get_cliente_ia = ia.get_cliente_ia
    sys.argv = ["agente.py", *argv]
    os.chdir(RAIZ)
    sys.path.insert(0, str(RAIZ / "motor"))
    runpy.run_path(str(RAIZ / "agente.py"), run_name="__main__")


def armar_sesion(base: Path) -> None:
    if os.environ.get("REPRO_VACIA") == "1":      # sesión sin evidencia
        (base / "inputs").mkdir(parents=True, exist_ok=True)
        (base / "outputs").mkdir(parents=True, exist_ok=True)
        return
    ins = base / "inputs"
    destinos = {
        "documentacion/modelamiento": ["manuales/Manual_Metodologico_MCR_CC.docx",
                                       "manuales/Manual_Metodologico_MCR_CC.md"],
        "documentacion/seguimiento": ["manuales/Manual_Seguimiento_MCR_CC.md"],
        "documentacion/controles_datos": ["manuales/Manual_Extraccion_Controles_Datos.md"],
        "implementacion": ["scripts/etl_modelo_cc.py", "scripts/extraccion.sql",
                           "scripts/calibracion.ipynb"],
        "excel_procesos": ["primera_linea/01_ControlDatos.xlsx"],
    }
    for d, archivos in destinos.items():
        (ins / d).mkdir(parents=True, exist_ok=True)
        for a in archivos:
            shutil.copy(KIT / a, ins / d / Path(a).name)
    (base / "outputs").mkdir(parents=True, exist_ok=True)


def main() -> int:
    sys.path.insert(0, str(RAIZ))
    tmp = Path(tempfile.mkdtemp(prefix="virf_repro_"))
    base = tmp / "sesion"
    armar_sesion(base)
    env = dict(os.environ)
    env.update({"MODO": "debug", "VIRF_FUENTE_SECRETOS": "entorno",
                "VIRF_IDENTIDAD_PROVEEDOR": "libre",
                "VIRF_CLAVE_FIRMA_SESION": secrets.token_hex(32),
                "VIRF_CLAVE_CIFRADO_REPOSO": secrets.token_hex(32),
                "PYTHONIOENCODING": "utf-8"})
    os.environ.update(env)
    from config.identidad import Identidad, emitir_asercion, VAR_ASERCION
    env[VAR_ASERCION] = emitir_asercion(Identidad(oid="repro", upn="repro@prueba.local",
                                                  nombre="Reproducción", codigo="REPRO"))
    from web.services.pipeline_runner import construir_args
    args = construir_args(base_sesion=base, titulo="MCR_Cuenta_Corriente_REPRO", tier="II",
                          dominio="LaR",
                          estandar_override=None if os.environ.get("REPRO_VACIA") == "1" else KIT / "estandares" / "Estandares_VIRF.xlsx")
    log = KIT / "reproduccion_corrida.log"
    print("args:", args[2:])
    with open(log, "w", encoding="utf-8") as f:
        rc = subprocess.run([sys.executable, "-X", "utf8", __file__, "--hijo", *args[3:]],
                            cwd=RAIZ, env=env, stdout=f, stderr=subprocess.STDOUT).returncode
    print(f"código de salida: {rc} · log: {log} · sesión: {base}")
    return rc


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--hijo":
        sys.path.insert(0, str(RAIZ))
        hijo(sys.argv[2:])
    else:
        sys.exit(main())
