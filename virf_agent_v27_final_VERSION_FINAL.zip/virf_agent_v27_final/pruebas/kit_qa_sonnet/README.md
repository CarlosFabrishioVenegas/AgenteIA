# Kit de pruebas QA (sintético) · MCR_Cuenta_Corriente

Generado por `generar_kit.py`. Todo es ficticio.

| Archivo | Qué es / qué prueba |
|---|---|
| estandares/Estandares_VIRF.xlsx | Estándar con formato REAL: título en B1, cabecera fila 2 desde col B, celdas combinadas ÁMBITO/CONTROL, X por tier, columna CONCEPTO (5 ámbitos, 14 actividades) |
| estandares/Estandares_VIRF_erratas.xlsx | Misma matriz con erratas (ACTVIDAD, TIER ll/lll, TIER V): lector tolerante y avisos |
| estandares/no_es_estandar.xlsx | Excel inválido: debe rechazarse con 400 |
| manuales/Manual_Metodologico_MCR_CC.md/.docx | Manual metodológico con secciones numeradas (población…umbrales PSI/KS/Gini) |
| manuales/Manual_Seguimiento_MCR_CC.md/.pdf | Manual de seguimiento (md y pdf con texto extraíble) |
| manuales/Manual_Extraccion_Controles_Datos.md | Manual de extracción y controles de datos |
| primera_linea/00_Diagnostico.xlsx ... 03_Impactos.xlsx | Excels de primera línea (resultados OK/No cumple, nivel de impacto) |
| primera_linea/Resultado_notebook_primera_linea.xlsx | Resultado tipo notebook de primera línea |
| primera_linea/ITER1_resultado_0X.xlsx | Excel de resultado que se devuelve en ITER1 de cada etapa |
| scripts/etl_modelo_cc.py | ETL con pd.read_csv con rutas Windows y UNC y funciones |
| scripts/extraccion.sql | SELECT ... FROM dwh.x JOIN dwh.y |
| scripts/calibracion.ipynb | Notebook de entrada (ipynb) |
| scripts/codigo_modelo.zip | ZIP con código en subcarpetas (implementación / insumos script) |
| datos/clientes.csv, datos/saldos.csv | Datasets con ids duplicados, nulos, saldos negativos y un id huérfano |
| imagenes/captura_1.png, captura_2.png | Imágenes de sustento |
| rag_papers/* | Papers del dominio RAG de prueba con términos distintivos (cuprometeo, ferrocarrilito, quilombometro) |
| qa_endpoints.py | Driver HTTP de las pruebas; RESULTADOS_QA.md es su informe |
