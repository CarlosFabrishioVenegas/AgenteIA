# -*- coding: utf-8 -*-
"""Genera el kit de documentos de prueba (banco ficticio, modelo MCR_Cuenta_Corriente).
Uso: .venv/Scripts/python.exe pruebas/kit_qa_sonnet/generar_kit.py
Todo es sintético; no contiene datos reales."""
from __future__ import annotations

import json
import random
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from PIL import Image, ImageDraw
import docx

KIT = Path(__file__).resolve().parent
for sub in ("estandares", "manuales", "primera_linea", "scripts", "datos", "imagenes", "rag_papers"):
    (KIT / sub).mkdir(parents=True, exist_ok=True)

random.seed(7)
np.random.seed(7)

# ───────────────────────── 1. Estándares ─────────────────────────
AMBITOS = {
    "Documentación": [
        ("Manual metodológico", ["Existe manual metodológico versionado", "El manual describe población y exclusiones",
                                  "El manual documenta la segmentación"]),
    ],
    "Metodología": [
        ("Estimación y calibración", ["Se documenta el método de estimación", "Se documenta la calibración",
                                       "Se justifican las variables seleccionadas"]),
    ],
    "Datos": [
        ("Calidad de datos", ["Se controla unicidad de llaves", "Se controla nulos y rangos",
                               "Se concilia con contabilidad"]),
    ],
    "Implementación": [
        ("Código productivo", ["El código está versionado", "Existen pruebas de la implementación"]),
    ],
    "Seguimiento": [
        ("Monitoreo", ["Se calcula PSI trimestral", "Se calculan KS y Gini", "Existen umbrales y alertas"]),
    ],
}
# Matriz de X por tier (I, II, III, IV): cuanto más bajo el tier, más actividades.
def marcas(i: int):
    return ["X", "X", "X" if i % 2 == 0 else "", "" if i % 3 else "X"]


def hacer_estandar(ruta: Path, erratas: bool):
    wb = Workbook()
    ws = wb.active
    ws.title = "Estándares"
    ws["B1"] = "Estándares de validación VIRF v28"
    ws["B1"].font = Font(bold=True, size=14)
    cab = ["AMBITO", "CONTROL CUANTITATIVO Y CUALITATIVO", "ACTIVIDAD", "TIER I", "TIER II", "TIER III",
           "TIER IV", "CONCEPTO"]
    if erratas:
        cab = ["AMBITO", "CONTROL CUANTITATIVO Y CUALITATIVO", "ACTVIDAD", "TIER I", "TIER ll", "TIER lll",
               "TIER V", "CONCEPTO"]
    for j, c in enumerate(cab):
        cel = ws.cell(row=2, column=2 + j, value=c)
        cel.font = Font(bold=True, color="FFFFFF")
        cel.fill = PatternFill("solid", fgColor="1F3864")
        cel.alignment = Alignment(wrap_text=True, vertical="center")
    r = 3
    k = 0
    for amb, controles in AMBITOS.items():
        r_amb = r
        for ctrl, acts in controles:
            r_ctrl = r
            for a in acts:
                ws.cell(row=r, column=4, value=a)
                for t, m in enumerate(marcas(k)):
                    if m:
                        ws.cell(row=r, column=5 + t, value=m)
                ws.cell(row=r, column=9, value=f"Concepto de referencia {k + 1}: {a.lower()}.")
                r += 1
                k += 1
            ws.cell(row=r_ctrl, column=3, value=ctrl)
            if r - 1 > r_ctrl:
                ws.merge_cells(start_row=r_ctrl, start_column=3, end_row=r - 1, end_column=3)
        ws.cell(row=r_amb, column=2, value=amb)
        ws.merge_cells(start_row=r_amb, start_column=2, end_row=r - 1, end_column=2)
    for col, w in zip("BCDEFGHI", (18, 30, 48, 8, 8, 8, 8, 55)):
        ws.column_dimensions[col].width = w
    wb.save(ruta)


hacer_estandar(KIT / "estandares" / "Estandares_VIRF.xlsx", erratas=False)
hacer_estandar(KIT / "estandares" / "Estandares_VIRF_erratas.xlsx", erratas=True)
# Excel inválido a propósito (sin fila de títulos reconocible) para probar el rechazo.
wb = Workbook(); wb.active["A1"] = "esto no es un estándar"; wb.active["B3"] = 42
wb.save(KIT / "estandares" / "no_es_estandar.xlsx")

# ───────────────────────── 2. Manuales ─────────────────────────
MM = """# Manual metodológico · MCR_Cuenta_Corriente v3.2

Modelo de pérdida esperada (PD/LGD) para saldos de cuenta corriente del banco ficticio Banco Andino Demo.

## 1. Población objetivo
La población son los clientes personas naturales con cuenta corriente activa entre 2019-01 y 2024-12.
Se toma una observación por cliente y mes (granularidad cliente-mes).

## 2. Exclusiones
2.1 Se excluyen cuentas inactivas por más de 12 meses.
2.2 Se excluyen saldos negativos mayores a 5.000 USD por considerarse sobregiro autorizado.
2.3 Se excluyen empleados del banco.

## 3. Variables
Las variables candidatas son: saldo_promedio_3m, antiguedad_meses, num_movimientos, ratio_sobregiro,
ingreso_declarado, segmento_comercial. Se transforman con WoE y se corrigen valores atípicos al percentil 99.

## 4. Segmentación
Se definen 3 segmentos: Masivo, Preferente y Premium, mediante un árbol de decisión de profundidad 3
con mínimo de 5% de población por hoja.

## 5. Estimación
La PD se estima con regresión logística por segmento; la LGD con regresión beta sobre recuperaciones a 24 meses.
Muestra de desarrollo: 70%; muestra de validación: 30%.

## 6. Calibración
Se calibra la PD a la tasa de default central de largo plazo mediante el método del intercepto ajustado.
El ajuste debe mantenerse dentro de ±10% de la tasa observada.

## 7. Umbrales de seguimiento
PSI: verde < 0.10, ámbar entre 0.10 y 0.25, rojo > 0.25.
KS: mínimo aceptable 30%. Gini: mínimo aceptable 40%.
Backtesting: tolerancia de ±15% entre PD estimada y observada.
"""
(KIT / "manuales" / "Manual_Metodologico_MCR_CC.md").write_text(MM, encoding="utf-8")

d = docx.Document()
d.add_heading("Manual metodológico · MCR_Cuenta_Corriente v3.2", 0)
for bloque in MM.split("\n## ")[1:]:
    tit, _, cuerpo = bloque.partition("\n")
    d.add_heading(tit, 1)
    for linea in cuerpo.strip().splitlines():
        d.add_paragraph(linea)
t = d.add_table(rows=1, cols=3)
t.style = "Table Grid"
for c, txt in zip(t.rows[0].cells, ("Indicador", "Verde", "Rojo")):
    c.text = txt
for fila in (("PSI", "< 0.10", "> 0.25"), ("KS", ">= 40%", "< 30%"), ("Gini", ">= 50%", "< 40%")):
    cs = t.add_row().cells
    for c, v in zip(cs, fila):
        c.text = v
d.save(KIT / "manuales" / "Manual_Metodologico_MCR_CC.docx")

(KIT / "manuales" / "Manual_Seguimiento_MCR_CC.md").write_text("""# Manual de seguimiento · MCR_Cuenta_Corriente

## 1. Frecuencia
El seguimiento es trimestral. Se publica dentro de los 20 días hábiles posteriores al cierre.

## 2. Indicadores
2.1 PSI de cada variable y del score. 2.2 KS y Gini sobre la cartera vigente. 2.3 Backtesting de PD por segmento.

## 3. Umbrales
PSI > 0.25 dispara alerta roja y revisión del modelo. KS < 30% alerta ámbar. Gini < 40% alerta roja.

## 4. Fuentes
Base: S:\\\\modelos\\\\seguimiento\\\\cuentas_2024Q4.csv, extraída desde dwh.cuentas_mensual.
""", encoding="utf-8")

(KIT / "manuales" / "Manual_Extraccion_Controles_Datos.md").write_text("""# Manual de extracción y controles de datos

## 1. Extracción
Las bases se extraen del datawarehouse (esquema dwh) el día 5 de cada mes: dwh.clientes, dwh.saldos_diarios.

## 2. Controles de calidad
C01 Unicidad de id_cliente en clientes. C02 Nulos en saldo < 1%. C03 Saldos negativos revisados contra
sobregiro autorizado. C04 Conciliación de montos contra contabilidad con tolerancia de 0.5%.
C05 Integridad referencial saldos -> clientes.

## 3. Resultado
Cada control se registra con resultado Cumple / No cumple y número de registros afectados.
""", encoding="utf-8")

# Manual de seguimiento en PDF real (matplotlib), texto extraíble
import matplotlib
matplotlib.use("Agg")
matplotlib.rcParams["pdf.fonttype"] = 42
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages


def pdf_texto(ruta: Path, paginas: list[list[str]]):
    with PdfPages(ruta) as pdf:
        for lineas in paginas:
            fig = plt.figure(figsize=(8.27, 11.69))
            fig.text(0.08, 0.95, lineas[0], fontsize=16, weight="bold", va="top")
            y = 0.90
            for ln in lineas[1:]:
                fig.text(0.08, y, ln, fontsize=10, va="top")
                y -= 0.03
            pdf.savefig(fig)
            plt.close(fig)


pdf_texto(KIT / "manuales" / "Manual_Seguimiento_MCR_CC.pdf", [[
    "Manual de seguimiento MCR_Cuenta_Corriente (PDF)",
    "1. El PSI se calcula trimestralmente sobre 10 deciles del score.",
    "2. Umbral PSI: verde menor a 0.10; ambar 0.10 a 0.25; rojo mayor a 0.25.",
    "3. KS minimo aceptable 30%; Gini minimo aceptable 40%.",
    "4. Los resultados se archivan en S:\\modelos\\seguimiento.",
]])

# ───────────────────────── 5. Datasets sintéticos ─────────────────────────
n = 400
ids = np.arange(1000, 1000 + n)
clientes = pd.DataFrame({
    "id_cliente": ids,
    "segmento": np.random.choice(["Masivo", "Preferente", "Premium"], n, p=[.6, .3, .1]),
    "antiguedad_meses": np.random.randint(1, 240, n),
    "ingreso_declarado": np.round(np.random.lognormal(7.5, .5, n), 2),
    "default_12m": np.random.binomial(1, .04, n),
})
clientes.loc[[10, 11], "id_cliente"] = clientes.loc[5, "id_cliente"]          # duplicados de id
clientes.loc[[20, 21, 22], "ingreso_declarado"] = np.nan                       # nulos
clientes.to_csv(KIT / "datos" / "clientes.csv", index=False)

saldos = pd.DataFrame({
    "id_cliente": np.random.choice(ids, 900),
    "periodo": np.random.choice(["2024-10", "2024-11", "2024-12"], 900),
    "saldo": np.round(np.random.normal(1500, 900, 900), 2),
})
saldos.loc[[3, 40, 77, 120], "saldo"] = [-250.5, -9800.0, -75.0, -6200.0]      # negativos
saldos.loc[[8, 9], "saldo"] = np.nan
saldos.loc[200, "id_cliente"] = 99999                                          # huérfano
saldos.to_csv(KIT / "datos" / "saldos.csv", index=False)

# ───────────────────────── 3. Excels de primera línea ─────────────────────────
def excel(ruta: Path, hoja: str, cols: list[str], filas: list[list]):
    wb = Workbook()
    ws = wb.active
    ws.title = hoja
    ws.append(cols)
    for c in ws[1]:
        c.font = Font(bold=True)
    for f in filas:
        ws.append(f)
    wb.save(ruta)


PL = KIT / "primera_linea"
excel(PL / "00_Diagnostico.xlsx", "Diagnostico",
      ["Base", "Registros", "Monto total (USD)", "Resultado"],
      [["dwh.clientes", int(len(clientes)), None, "OK"],
       ["dwh.saldos_diarios", int(len(saldos)), round(float(saldos.saldo.sum()), 2), "No cumple"],
       ["dwh.cuentas_mensual", 12000, 18_540_000.5, "OK"],
       ["contabilidad.gl_cc", 36, 18_612_300.0, "No cumple"]])
excel(PL / "01_ControlDatos.xlsx", "Controles",
      ["Control", "Base", "Variable", "Resultado", "Registros afectados", "Comentario"],
      [["C01 Unicidad", "dwh.clientes", "id_cliente", "No cumple", 2, "Hay id_cliente repetidos"],
       ["C02 Nulos", "dwh.saldos_diarios", "saldo", "Cumple", 2, "0.2% < 1%"],
       ["C03 Negativos", "dwh.saldos_diarios", "saldo", "No cumple", 4, "Saldos negativos sin sobregiro"],
       ["C04 Conciliacion", "contabilidad.gl_cc", "monto", "No cumple", 1, "Diferencia 0.39%"],
       ["C05 Integridad ref.", "dwh.saldos_diarios", "id_cliente", "No cumple", 1, "id 99999 no existe"]])
excel(PL / "02_Modelamiento.xlsx", "Replica",
      ["Paso", "Fuente", "Resultado implementador", "Resultado"],
      [["Poblacion", "Manual 1", "9.870 clientes", "OK"],
       ["Exclusiones", "Manual 2", "1.130 excluidos", "OK"],
       ["Estimacion PD", "Manual 5", "Gini 52%", "OK"],
       ["Calibracion", "Manual 6", "Ajuste +12%", "No cumple"]])
excel(PL / "03_Impactos.xlsx", "Impactos",
      ["Hallazgo", "Etapa", "Metrica", "Valor original", "Valor corregido", "Impacto", "Nivel de impacto"],
      [["Duplicados id_cliente", "01", "PD media", 0.0412, 0.0419, 0.0007, "Potencial/Bajo"],
       ["Saldos negativos", "01", "EAD", 18540000, 18102000, -438000, "Moderado"],
       ["Calibracion fuera de banda", "02", "PD calibrada", 0.0412, 0.0371, -0.0041, "Crítico"]])
excel(PL / "Resultado_notebook_primera_linea.xlsx", "Resultado",
      ["Indicador", "Valor reportado", "Umbral", "Resultado"],
      [["PSI score", 0.08, 0.25, "OK"], ["KS", 0.34, 0.30, "OK"], ["Gini", 0.38, 0.40, "No cumple"]])

# Excels "resultado de la etapa" que la IA/usuario devolvería en ITER1 (con columna Resultado)
RES = KIT / "primera_linea"
excel(RES / "ITER1_resultado_00.xlsx", "Mapeo", ["Base", "Filas", "Columnas", "Nulos", "Duplicados llave"],
      [["clientes", 400, 5, 3, 2], ["saldos", 900, 3, 2, 0]])
excel(RES / "ITER1_resultado_01.xlsx", "Controles",
      ["elemento", "control", "resultado", "n_afectados", "pct", "conclusion"],
      [["clientes.id_cliente", "unicidad", "No cumple", 2, 0.5, "duplicados"],
       ["saldos.saldo", "negativos", "No cumple", 4, 0.44, "sobregiro sin soporte"]])
excel(RES / "ITER1_resultado_02.xlsx", "Replica",
      ["paso", "implementador", "replicado", "diferencia", "conclusion"],
      [["Calibracion", "+12%", "+9%", "3pp", "No cumple"]])
excel(RES / "ITER1_resultado_03.xlsx", "Impactos",
      ["hallazgo", "metrica", "impacto", "nivel"], [["Saldos negativos", "EAD", -438000, "Moderado"]])
excel(RES / "ITER1_resultado_04.xlsx", "Seguimiento",
      ["indicador", "umbral", "implementador", "replicado", "semaforo"],
      [["PSI", 0.25, 0.08, 0.09, "Verde"], ["Gini", 0.40, 0.38, 0.37, "Rojo"]])

# ───────────────────────── 4. Scripts ─────────────────────────
SC = KIT / "scripts"
(SC / "etl_modelo_cc.py").write_text('''# -*- coding: utf-8 -*-
"""ETL del modelo MCR_Cuenta_Corriente (sintético)."""
import pandas as pd

RUTA_CLIENTES = r"C:\\Users\\analista\\Documents\\modelos\\cc\\clientes.csv"
RUTA_SALDOS = r"\\\\srv-datos01\\modelos\\cc\\saldos.csv"


def cargar():
    clientes = pd.read_csv(r"C:\\Users\\analista\\Documents\\modelos\\cc\\clientes.csv")
    saldos = pd.read_csv(r"\\\\srv-datos01\\modelos\\cc\\saldos.csv")
    return clientes, saldos


def depurar(clientes, saldos):
    """Excluye saldos negativos y duplicados de llave (regla 2.2 del manual)."""
    clientes = clientes.drop_duplicates("id_cliente")
    saldos = saldos[saldos["saldo"] >= 0]
    return clientes, saldos


def construir_base(clientes, saldos):
    prom = saldos.groupby("id_cliente")["saldo"].mean().rename("saldo_promedio_3m").reset_index()
    return clientes.merge(prom, on="id_cliente", how="left")


if __name__ == "__main__":
    c, s = cargar()
    c, s = depurar(c, s)
    construir_base(c, s).to_csv(r"S:\\\\modelos\\\\salida\\\\base_modelo.csv", index=False)
''', encoding="utf-8")

(SC / "extraccion.sql").write_text("""-- Extraccion mensual del modelo MCR_Cuenta_Corriente
SELECT c.id_cliente, c.segmento, s.periodo, s.saldo
FROM dwh.clientes c
JOIN dwh.saldos_diarios s ON s.id_cliente = c.id_cliente
WHERE s.periodo >= '2024-10'
  AND c.estado = 'ACTIVO';

SELECT periodo, SUM(saldo) AS monto
FROM dwh.cuentas_mensual
GROUP BY periodo;
""", encoding="utf-8")

nb = {
    "nbformat": 4, "nbformat_minor": 5,
    "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"}},
    "cells": [
        {"cell_type": "markdown", "metadata": {}, "source": ["# Calibración PD · MCR_Cuenta_Corriente"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
         "source": ["import pandas as pd\n", "df = pd.read_csv('clientes.csv')\n",
                    "tasa = df['default_12m'].mean()\n", "print('tasa default', tasa)\n"]},
        {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
         "source": ["def calibrar(pd_modelo, tasa_obs):\n", "    return pd_modelo * tasa_obs / pd_modelo.mean()\n"]},
    ],
}
(SC / "calibracion.ipynb").write_text(json.dumps(nb, indent=1), encoding="utf-8")

zp = KIT / "scripts" / "codigo_modelo.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    z.write(SC / "etl_modelo_cc.py", "src/etl/etl_modelo_cc.py")
    z.write(SC / "extraccion.sql", "src/sql/extraccion.sql")
    z.writestr("src/modelo/estimacion.py", "import statsmodels.api as sm\n\ndef ajustar(X, y):\n    return sm.Logit(y, X).fit()\n")
    z.writestr("src/seguimiento/psi.py", "import numpy as np\n\ndef psi(a, b):\n    return float(np.sum((a - b) * np.log(a / b)))\n")
    z.writestr("README.txt", "Codigo ficticio del modelo MCR_Cuenta_Corriente.\n")

# ───────────────────────── 6. Imágenes ─────────────────────────
for i, (txt, col) in enumerate((("Captura 1: control C01 unicidad", (30, 90, 160)),
                                 ("Captura 2: conciliacion contabilidad", (20, 120, 70))), 1):
    im = Image.new("RGB", (900, 420), (245, 245, 245))
    dr = ImageDraw.Draw(im)
    dr.rectangle([0, 0, 900, 50], fill=col)
    dr.text((15, 18), txt, fill="white")
    for k in range(6):
        dr.text((20, 80 + 45 * k), f"fila {k + 1}   id_cliente=100{k}   saldo={random.randint(-500, 4000)}", fill="black")
        dr.line([20, 105 + 45 * k, 880, 105 + 45 * k], fill=(200, 200, 200))
    im.save(KIT / "imagenes" / f"captura_{i}.png")

# ───────────────────────── 7. Papers RAG ─────────────────────────
RP = KIT / "rag_papers"
(RP / "paper_liquidez_basilea.md").write_text("""# Gestión del riesgo de liquidez y el ratio LCR

El Liquidity Coverage Ratio (LCR) exige activos líquidos de alta calidad suficientes para cubrir las
salidas netas de caja durante 30 días. El ratio mínimo regulatorio es 100%. Un banco zafiro-tangerino
mantiene colchones de HQLA de nivel 1 para cumplir el LCR.
""", encoding="utf-8")
(RP / "paper_psi_estabilidad.txt").write_text(
    "El Population Stability Index (PSI) mide el cambio de distribución de un score entre dos periodos. "
    "Umbrales habituales: PSI menor a 0.10 estable, entre 0.10 y 0.25 cambio moderado, mayor a 0.25 cambio "
    "significativo que exige revisión del modelo. La palabra clave unica de este documento es 'cuprometeo'.\n",
    encoding="utf-8")
(RP / "paper_calibracion_pd.md").write_text("""# Calibración de probabilidades de default

La calibración ajusta la PD de un modelo a la tasa de default central de largo plazo. El método del intercepto
ajustado desplaza el término constante de la regresión logística. El backtesting compara PD estimada y tasa
observada con un intervalo binomial. Término distintivo: 'ferrocarrilito'.
""", encoding="utf-8")
pdf_texto(RP / "paper_gini_ks.pdf", [[
    "Discriminacion de modelos: Gini y KS",
    "El coeficiente de Gini es dos veces el AUC menos uno.",
    "El estadistico KS es la maxima distancia entre las distribuciones acumuladas de buenos y malos.",
    "Termino distintivo del PDF: quilombometro.",
]])

# ───────────────────────── README ─────────────────────────
(KIT / "README.md").write_text("""# Kit de pruebas QA (sintético) · MCR_Cuenta_Corriente

Generado por `generar_kit.py`. Todo es ficticio.

| Archivo | Qué es / qué prueba |
|---|---|
| estandares/Estandares_VIRF.xlsx | Estándar con formato REAL: título en B1, cabecera fila 2 desde col B, celdas combinadas ÁMBITO/CONTROL, X por tier, columna CONCEPTO (5 ámbitos, 14 actividades) |
| estandares/Estandares_VIRF_erratas.xlsx | Misma matriz con erratas (ACTVIDAD, TIER ll/lll, TIER V): lector tolerante y avisos |
| estandares/no_es_estandar.xlsx | Excel inválido: debe rechazarse con 400 |
| manuales/Manual_Metodologico_MCR_CC.md/.docx | Manual metodológico con secciones numeradas (población…umbrales PSI/KS/Gini) |
| manuales/Manual_Seguimiento_MCR_CC.md/.pdf | Manual de seguimiento (md y pdf con texto extraíble) |
| manuales/Manual_Extraccion_Controles_Datos.md | Manual de extracción y controles de datos |
| primera_linea/00_Diagnostico.xlsx ... 03_Impactos.xlsx | Excels de primera línea (resultados OK/No cumple, nivel de impacto) |
| primera_linea/Resultado_notebook_primera_linea.xlsx | Resultado tipo notebook de primera línea |
| primera_linea/ITER1_resultado_0X.xlsx | Excel de resultado que se devuelve en ITER1 de cada etapa |
| scripts/etl_modelo_cc.py | ETL con pd.read_csv con rutas Windows y UNC y funciones |
| scripts/extraccion.sql | SELECT ... FROM dwh.x JOIN dwh.y |
| scripts/calibracion.ipynb | Notebook de entrada (ipynb) |
| scripts/codigo_modelo.zip | ZIP con código en subcarpetas (implementación / insumos script) |
| datos/clientes.csv, datos/saldos.csv | Datasets con ids duplicados, nulos, saldos negativos y un id huérfano |
| imagenes/captura_1.png, captura_2.png | Imágenes de sustento |
| rag_papers/* | Papers del dominio RAG de prueba con términos distintivos (cuprometeo, ferrocarrilito, quilombometro) |
| qa_endpoints.py | Driver HTTP de las pruebas; RESULTADOS_QA.md es su informe |
""", encoding="utf-8")
print("kit ok")
