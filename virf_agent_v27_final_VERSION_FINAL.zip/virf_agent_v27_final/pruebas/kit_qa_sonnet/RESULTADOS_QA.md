# Resultados QA · VIRF (servidor de prueba :8010)

Ejecutado el 2026-11-18 con `qa_endpoints.py` (httpx contra http://localhost:8010, usuario libre «QA Sonnet», modelo `QA_SONNET_<n>` modalidad completa, dominio LaR) y una pasada manual por el navegador integrado. Ningún check llamó a un LLM de pago (siempre `usar_ia=false`; el resto se omitió).

## Correcciones aplicadas tras el QA (2026-11-18)

Los 6 fallos se verificaron en el código y se corrigieron; cada uno tiene un test de regresión en `tests/test_fallos_qa_sonnet.py`.

| # | Fallo | Corrección |
|---|---|---|
| F1 | `/api/cuestionamientos/*` escribía config global sin sesión | Lectura exige rol `leer`, escritura exige `validar` (401 sin sesión, 403 sin rol) — `web/routers/cuestionamientos.py` |
| F2 | No se podían subir papers a un dominio RAG propio | `resolver_destino` reconoce `rag_<id>` de dominios registrados — `web/services/contexto_sesion.py` |
| F3 | La subida aceptaba extensiones no declaradas (.exe) | Cada tarjeta solo acepta sus formatos (`formatos_destino`) — `web/routers/upload.py` |
| F4 | Notebook 01 sin IA no veía llaves duplicadas ni huérfanos | La plantilla controla llaves (id/código/llave) duplicadas e integridad referencial entre bases — `modulos/validacion_completa.py` |
| F5 | «Firmante (SSO)» siempre «—» | Se pinta al cargar el validador — `web/static/js/app.js` |
| F6 | Ayuda de Documentar apuntaba a la tarjeta oculta | Texto actualizado — `web/templates/index.html` |
| extra | JSON de resultados malformado daba 500 en `/api/chat/iniciar` | Responde 400 con el motivo — `web/routers/chat.py` |

**RAG (antes SKIP por F2):** `qa_rag_dominio.py` crea un dominio `qa_claude_rag_*`, sube los 4 papers, reconstruye SOLO ese dominio, busca y lo borra: **13 PASS · 0 FAIL**. Las 4 consultas devuelven su paper en primera posición y una consulta sin relación no devuelve nada. Los dominios LaR/VaR/ALM/shared no se tocaron.

## Resumen (corrida original, antes de las correcciones)

| PASS | FAIL | SKIP | Total |
|---|---|---|---|
| 362 | 11 | 13 | 386 |

| Área | PASS | FAIL | SKIP |
|---|---|---|---|
| Auth | 21 | 1 | 1 |
| Modelos | 19 | 0 | 0 |
| Config/Lecturas | 35 | 0 | 3 |
| Skills/Cuestionamientos | 16 | 0 | 3 |
| Estándares (Paso 02) | 28 | 0 | 0 |
| Evidencia (Paso 03) | 35 | 1 | 1 |
| Validación completa | 106 | 0 | 0 |
| Notebooks (ejecución) | 20 | 1 | 0 |
| Documentar | 35 | 0 | 1 |
| Solo informe | 18 | 0 | 1 |
| RAG | 9 | 6 | 2 |
| UI (navegador) | 13 | 2 | 1 |
| Limpieza | 7 | 0 | 0 |

## Fallos

### F1 · Cuestionamientos globales sin autenticación (SEGURIDAD, alta)
- Repro: sin cookie, `POST /api/cuestionamientos/default/data_leakage_escalado/toggle` con `{"activo": true}` devuelve **200** y escribe `config/cuestionamientos_activos.json`. Igual `GET /api/cuestionamientos/default`, `GET|POST /api/cuestionamientos/personalizados` y `DELETE /api/cuestionamientos/personalizados/{id}`.
- Esperado: 401 sin sesión (y rol de gestión para escribir un fichero global compartido por todos los validadores). El resto de routers sí exigen sesión.
- Causa probable: `web/routers/cuestionamientos.py:105,123,135,143,159` — ningún endpoint declara `Depends(contexto_sesion)` ni `requiere(...)`. (La prueba escribió el mismo valor `true` que ya tenía el fichero versionado: sin cambio efectivo.)

### F2 · No se pueden subir papers a un dominio RAG custom (funcional, alta)
- Repro: `POST /api/rag/dominios/crear` (200) y luego `POST /api/inputs/upload?destino=rag_<id>&clasificacion=Publico&dueno=QA&vigencia=2027-12-31` (lo que hace la UI en `subirPapersRag`) devuelve **400 «destino desconocido: 'rag_qa_sonnet_dom_…'»**. `/api/inputs/destinos` solo lista rag_LaR/VaR/ALM/shared.
- Esperado: los dominios custom aceptan papers (su tarjeta ofrece dropzone y el mensaje «Subidos N paper(s)»).
- Causa probable: `web/services/contexto_sesion.py:208-232` (`_DESTINOS_GLOBALES` fijo) y `resolver_destino` (`:267-276`) no consideran los dominios de `dominios_custom_store`; la UI los construye como `rag_${dom.dominio}` (`web/static/js/app.js:764`, `:891-905`).
- Consecuencia: **no se pudieron subir ni indexar los 4 papers de prueba, así que no se probó la búsqueda/recuperación sobre el dominio `qa_sonnet_*`** (ver SKIP). No se escribió a mano en `inputs/rag`.

### F3 · La subida de evidencia no valida la extensión contra `formatos` de la tarjeta (media)
- Repro: `POST /api/inputs/upload?destino=doc_modelamiento&clasificacion=Interno` con `macro.exe` devuelve **200** y lo guarda (luego se borró).
- Esperado: 400/415 (la tarjeta declara `.pdf,.docx,.md,.txt`); hoy solo el `<input accept>` del navegador lo limita.
- Causa probable: `web/routers/upload.py:176-215` (`subir_archivos`) y `_nombre_seguro` (`:48-60`) solo comprueban `NOMBRES_PROHIBIDOS` (`web/config_web.py:15`); no usan los `formatos` de `destinos_disponibles()`.

### F4 · El notebook 01 «Control de datos» sin IA no detecta duplicados de llave (calidad, media)
- Repro: insumos con `clientes.csv` que tiene 2 `id_cliente` repetidos; ITER0 de la etapa 01 con `usar_ia=false`; ejecutar el `.ipynb`. Hoja «Controles»: `clientes | filas duplicadas | 0`; `saldos.saldo | negativos | 48`. No hay control de unicidad de la llave, ni integridad referencial (saldos con `id_cliente=99999` huérfano), ni columna `resultado`.
- Esperado (misión de la etapa 01: «unicidad, nulos, rangos, integridad referencial…»): al menos unicidad de llave con afectados>0. El 00 tampoco marca duplicados de llave (`duplicados` cuenta filas completas).
- Causa probable: plantilla determinista `modulos/validacion_completa.py:520` (`_celdas_plantilla`) y `_determinista` (`:800`).

### F5 · Firmante vacío en «Validar modelo» (UI, baja)
- Repro: entrar a un modelo, abrir Validar modelo: «Firma la identidad con la que entraste (SSO): **—**» (también tras recargar).
- Causa probable: `web/static/js/app.js:2139-2143` rellena `#firm-identidad` en el cableado inicial, cuando `estado.validador` aún es `null` (se carga después en `:2759-2762` y `:3628`). Debe actualizarse al abrir la vista.

### F6 · Texto de ayuda obsoleto en «Documentar» (UI, baja)
- `web/templates/index.html:524` indica subir los Excels en «Subir evidencia → automatizaciones/», pero esa tarjeta está oculta (`"oculto": True`, `web/services/contexto_sesion.py:~180`) y en Validación completa se envían al chat de cada etapa.

### Observaciones (no cuentan como FAIL)
- La cookie `virf_token` se emite con `Secure` (`web/routers/auth.py:84-85`): clientes HTTP planos (httpx/requests) no la reenvían en `http://localhost`; el driver gestiona la cookie a mano. Chrome sí la acepta en localhost.
- `GET /api/auth/login` responde 503 en modo libre (esperado: SSO no configurado).
- `POST /api/auth/login-libre` con un rol inexistente no se rechaza (informativo).
- Borrar un dominio custom lo mueve a `archivo/dominios_retirados/` en vez de borrarlo; los 5 directorios `qa_sonnet_dom_*` generados por estas pruebas se eliminaron a mano.
- Los notebooks 00–04 sin IA se ejecutan con exit 0 y producen su Excel (`<etapa>_resultadoITER0.xlsx`); una ruta UNC inexistente se registra como error en la hoja «Mapeo» sin romper el notebook.
- El Word del informe consolidado SÍ incluye el anexo «Validación completa · sustento por etapa» con las imágenes y pies «Figura S1…».
- El JSON de resultados para el informe se SIEMBRA a mano en la carpeta de la sesión del modelo QA (el pipeline real llama al LLM). Un campo `agente` como cadena (en vez de objeto) rompe `POST /api/chat/iniciar` con 500 (`web/services/chat_service.py` en `iniciar`, `(datos.get("agente") or {}).get(...)`): JSON mal formado, pero sería más robusto responder 400/422.

## SKIP (no probado)
- `POST /api/config/modelo|virf_plus|verificar`: escriben configuración global o llaman al proveedor IA.
- `POST /api/entendimiento/analizar`, `POST /api/validar/lanzar`, `POST /api/chat/adjuntar`, `POST /api/solo-informe/ia/*`: llaman al LLM de pago (sin flag `usar_ia`).
- `POST /api/chat/consolidar`, `POST /api/feedback/aprobar`, `POST /api/codigo/aprobar`, `POST|DELETE /api/cuestionamientos/default|personalizados` (salvo la prueba 401 de F1): escrituras globales o aprobaciones.
- `POST /api/auth/logout`: ejecuta `purgar_vencidos()` sobre raíces de retención globales (borraría ficheros ajenos vencidos).
- Subidas a destinos globales `rag_LaR|VaR|ALM|shared` y `POST /api/rag/reconstruir` de dominios fijos o `all`: tocarían el corpus compartido.
- Recuperación/búsqueda RAG sobre el dominio de prueba, reconstrucción de su índice y borrado de paper: bloqueados por F2.
- UI: subida masiva por las 10 tarjetas, chat de etapa, insumos y reglas por UI: el clasificador de permisos del entorno bloqueó el script de subida masiva vía navegador; cubierto por HTTP y por el mapa estático de botones.

## Limpieza
Modelos `QA_SONNET_*` (HTTP y UI), dominio `qa_sonnet_dom_*` y sus archivados borrados; sin residuos en `inputs/rag` ni `data/rag_lexico`. Quedan el kit y `descargas/` (docx/ipynb generados) en `pruebas/kit_qa_sonnet/`, más las carpetas de usuario `PRUEBA_QA_SONNET` y `PRUEBA_QA_SONNET_UI` bajo `web/data/sesiones` y sus entradas en `web/data/validadores.json` (creadas por el login libre).


## Tabla de todos los checks

| # | Área | Endpoint / prueba | Entrada | Esperado | Actual | Estado |
|---|---|---|---|---|---|---|
| 1 | Auth | GET /api/auth/modo | - | 200 proveedor=libre | 200 {"proveedor":"libre"} | PASS |
| 2 | Auth | GET /api/auth/actual (sin cookie) | - | 401 | 401 | PASS |
| 3 | Auth | POST /api/auth/login-libre nombre corto | nombre='x' | 422 | 422 | PASS |
| 4 | Auth | POST /api/auth/login-libre | ['validador', 'revisor', 'admin_corpus'] | 200 + cookie virf_token | 200 cookie=True | PASS |
| 5 | Auth | Set-Cookie virf_token flags | - | HttpOnly; SameSite; (Secure solo con https) | virf_token=8ac02373318346aea4cd5e7248dbbe0e51aa026879a548e6830a90444c1d93a6; HttpOnly; Max-Age=28800; Path=/;  | PASS |
| 6 | Auth | GET /api/auth/actual | - | 200 validador | 200 PRUEBA_QA_SONNET | PASS |
| 7 | Auth | POST login-libre >3 roles | 4 roles | 422 | 422 | PASS |
| 8 | Auth | POST login-libre rol inexistente | roles=['superadmin'] | rechazado (4xx) o rol ignorado | 422 {"detail":"elige al menos un rol: validador, revisor, admin_corpus"} | PASS |
| 9 | Auth | POST /api/auth/logout | - | - | el logout ejecuta purgar_vencidos() sobre las raíces de retención GLOBALES (borra ficheros ajenos vencidos) | SKIP |
| 10 | Auth | GET /api/auth/login (SSO) | - | 503 claro (SSO no configurado en modo libre) o redirección | 503 {"detail":"Modo usuario libre: entra con el formulario de pr | PASS |
| 11 | Auth | GET /api/modelos sin sesión | - | 401 (o 200 si es catálogo público) | 401 | PASS |
| 12 | Auth | GET /api/rag/dominios sin sesión | - | 401 (o 200 si es catálogo público) | 401 | PASS |
| 13 | Auth | GET /api/estandares/estado sin sesión | - | 401 (o 200 si es catálogo público) | 401 | PASS |
| 14 | Auth | GET /api/completa/estado sin sesión | - | 401 (o 200 si es catálogo público) | 401 | PASS |
| 15 | Auth | GET /api/inputs/arbol sin sesión | - | 401 (o 200 si es catálogo público) | 401 | PASS |
| 16 | Auth | GET /api/cuestionamientos/default sin sesión | - | 401 (o 200 si es catálogo público) | 200 | PASS |
| 17 | Auth | GET /api/cuestionamientos/personalizados sin sesión | - | 401 (o 200 si es catálogo público) | 200 | PASS |
| 18 | Auth | GET /api/skills/defaults sin sesión | - | 401 (o 200 si es catálogo público) | 200 | PASS |
| 19 | Auth | GET /api/motores/catalogo sin sesión | - | 401 (o 200 si es catálogo público) | 200 | PASS |
| 20 | Auth | GET /api/prompts/base sin sesión | - | 401 (o 200 si es catálogo público) | 200 | PASS |
| 21 | Auth | GET /api/inputs/destinos sin sesión | - | 401 (o 200 si es catálogo público) | 200 | PASS |
| 22 | Auth | GET /api/feedback/pendientes sin sesión | - | 401 (o 200 si es catálogo público) | 401 | PASS |
| 23 | Auth | POST /api/cuestionamientos/default/{id}/toggle SIN sesión | activo=True (idempotente) | 401/403 (escritura global) | 200 | FAIL |
| 24 | Modelos | GET /api/modelos | - | 200 lista | 200 | PASS |
| 25 | Modelos | GET /api/rag/dominios (para elegir dominio) | - | incluye LaR | ['LaR', 'VaR', 'ALM', 'shared'] | PASS |
| 26 | Modelos | POST /api/modelos dominio inválido | dominio=NoExiste | 400 | 400 {"detail":"dominio inválido: 'NoExiste'. Válidos: ('LaR', 'VaR', 'ALM') + custom | PASS |
| 27 | Modelos | POST /api/modelos modalidad inválida | modalidad=rara | 400 | 400 {"detail":"modalidad inválida: 'rara' (válidas: normal, completa)"} | PASS |
| 28 | Modelos | POST /api/modelos tier inválido | tier=VII | 400 | 400 {"detail":"tier inválido: 'VII'"} | PASS |
| 29 | Modelos | POST /api/modelos (completa) | QA_SONNET_031769 | 200 modelo | 200 slug=QA_SONNET_031769 modalidad=completa | PASS |
| 30 | Modelos | POST /api/modelos duplicado | QA_SONNET_031769 | 400 | 400 {"detail":"ya existe un modelo con slug 'QA_SONNET_031769' para PRUEBA_QA_SONNET | PASS |
| 31 | Modelos | POST /api/modelos (normal) | QA_SONNET_B_031769 | 200 | 200 slug=QA_SONNET_B_031769 | PASS |
| 32 | Modelos | GET /api/modelos contiene los creados | - | ambos slugs | ['QA_SONNET_031769', 'QA_SONNET_B_031769'] | PASS |
| 33 | Modelos | POST /api/modelos/{slug}/activar inexistente | - | 404 | 404 | PASS |
| 34 | Modelos | GET /api/modelos/activo (ninguno) | - | modelo=None | {'modelo': None} | PASS |
| 35 | Modelos | GET /api/estandares/estado sin modelo activo | - | 400 | 400 | PASS |
| 36 | Modelos | POST /api/modelos/{slug}/activar (normal) | - | 200 + cookie virf_modelo | 200 | PASS |
| 37 | Modelos | GET /api/modelos/activo | - | slug2 | QA_SONNET_B_031769 | PASS |
| 38 | Modelos | POST /api/completa/etapa/00/iteracion en modalidad normal | - | 409 | 409 {"detail":"Este modelo está en Validación normal. Cámbialo a Validación completa | PASS |
| 39 | Modelos | POST /api/modelos/desactivar | - | 200, cookie borrada | 200 cookies=['virf_token'] | PASS |
| 40 | Modelos | POST /api/modelos/{slug}/activar (completa) | - | 200 | 200 | PASS |
| 41 | Modelos | DELETE /api/modelos/{slug} (modelo B) | - | 200 | 200 | PASS |
| 42 | Modelos | DELETE /api/modelos/{slug} repetido | - | 404 | 404 | PASS |
| 43 | Config/Lecturas | GET /api/config | - | 200 con env y sin secretos en claro | 200 | PASS |
| 44 | Config/Lecturas | GET /api/config no filtra claves | - | ninguna 'sk-' ni valor de API_KEY | sin patrón sk- | PASS |
| 45 | Config/Lecturas | POST /api/config/modelo \| /virf_plus \| /verificar | - | - | escriben config global o llaman al proveedor IA (de pago) | SKIP |
| 46 | Config/Lecturas | GET /api/prompts/base | - | 200 | 200 {"prompts":{"rol_agente":{"titulo":"Rol del agente (system prompt)","d | PASS |
| 47 | Config/Lecturas | GET /api/prompts | - | 200 | 200 {"sesion":"PRUEBA_QA_SONNET/QA_SONNET_031769","prompts":{"rol_agente": | PASS |
| 48 | Config/Lecturas | GET /api/prompts/presupuesto | - | 200 | 200 {"modelo":"(desconocido)","modelo_perfil":"(desconocido)","familia":"g | PASS |
| 49 | Config/Lecturas | GET /api/skills/defaults | - | 200 | 200 {"defaults":[{"id":"doc_metodologica","nombre":"Revisión de documentac | PASS |
| 50 | Config/Lecturas | GET /api/skills | - | 200 | 200 {"defaults":[{"id":"doc_metodologica","nombre":"Revisión de documentac | PASS |
| 51 | Config/Lecturas | GET /api/cuestionamientos/default | - | 200 | 200 {"n":15,"cuestionamientos":[{"id":"data_leakage_escalado","tipo":"pres | PASS |
| 52 | Config/Lecturas | GET /api/cuestionamientos/personalizados | - | 200 | 200 {"n":0,"cuestionamientos":[]} | PASS |
| 53 | Config/Lecturas | GET /api/cuestionamientos-sesion | - | 200 | 200 {"presencia":[{"id":"data_leakage_escalado","tipo":"presencia","contex | PASS |
| 54 | Config/Lecturas | GET /api/motores/catalogo | - | 200 | 200 {"n":8,"motores":[{"nombre":"completitud","descripcion":"El dataset ti | PASS |
| 55 | Config/Lecturas | GET /api/motores/entidad | - | 200 | 200 {"filas":[],"ficheros":[],"avisos":[],"carpeta":"C:\\Users\\REC TECHNO | PASS |
| 56 | Config/Lecturas | GET /api/guia/progreso | - | 200 | 200 {"pasos":[{"id":"config","estado":"hecho","detalle":"Proveedor anthrop | PASS |
| 57 | Config/Lecturas | GET /api/resultados/lista | - | 200 | 200 {"informes":[],"sesion":"PRUEBA_QA_SONNET/QA_SONNET_031769"} | PASS |
| 58 | Config/Lecturas | GET /api/validar/estado | - | 200 | 200 {"run":null} | PASS |
| 59 | Config/Lecturas | GET /api/chat/estado | - | 200 | 200 {"activa":false,"sesion":null} | PASS |
| 60 | Config/Lecturas | GET /api/informe/estado | - | 200 | 200 {"n_ficheros_inputs":0,"resultados_disponibles":[],"chat":null,"run":n | PASS |
| 61 | Config/Lecturas | GET /api/informe/versiones | - | 200 | 200 {"versiones":[]} | PASS |
| 62 | Config/Lecturas | GET /api/feedback/pendientes | - | 200 | 200 {"pendientes":[{"_id":"5ad73a10eee49880","ambito":"Metodología","activ | PASS |
| 63 | Config/Lecturas | GET /api/inputs/arbol | - | 200 | 200 {"tipo":"carpeta","nombre":"inputs","ruta":"","hijos":[{"tipo":"carpet | PASS |
| 64 | Config/Lecturas | GET /api/automatizaciones/estado | - | 200 | 200 {"etapas":[{"codigo":"00","etapa":"Diagnóstico","archivo":null},{"codi | PASS |
| 65 | Config/Lecturas | GET /api/solo-informe/estado | - | 200 | 200 {"estandar":null,"borrador":{"tipo":"periodica","tier":"II","nombre_mo | PASS |
| 66 | Config/Lecturas | GET /api/debug/conexiones | - | 200 o 403 (rol diagnostico) | 200 {"bloques":{"1. SESIÓN Y PERSISTENCIA":[{"estado":"OK","nombre":"Carpeta de sesi | PASS |
| 67 | Config/Lecturas | GET /api/chat/observaciones sin chat | - | 404 | 404 | PASS |
| 68 | Config/Lecturas | GET /api/salud | - | 200 ok | {"estado":"ok","version":"2.0"} | PASS |
| 69 | Config/Lecturas | GET / (SPA) | - | 200 html | 200 | PASS |
| 70 | Config/Lecturas | GET /static/css/styles.css | - | 200 | 200 | PASS |
| 71 | Config/Lecturas | GET /static/js/app.js | - | 200 | 200 | PASS |
| 72 | Config/Lecturas | GET /static/js/completa.js | - | 200 | 200 | PASS |
| 73 | Config/Lecturas | GET /static/js/ui.js | - | 200 | 200 | PASS |
| 74 | Config/Lecturas | GET /static/js/guia.js | - | 200 | 200 | PASS |
| 75 | Config/Lecturas | GET /static/css/ui-sello.css | - | 200 | 200 | PASS |
| 76 | Config/Lecturas | POST /api/prompts/editar (por sesión) | rol_agente | 200 o 4xx explicado | 200 {"ok":true,"prompt_id":"rol_agente","entrada":{"titulo":"Rol del agente (system prompt)","descripcio | PASS |
| 77 | Config/Lecturas | POST /api/prompts/restaurar | rol_agente | 200 | 200 {"ok":true,"prompt_id":"rol_agente","entrada":{"titulo":"Rol del agente (system  | PASS |
| 78 | Config/Lecturas | POST /api/prompts/restaurar id inexistente | - | 404 | 404 | PASS |
| 79 | Config/Lecturas | POST /api/feedback/aprobar, /api/codigo/aprobar | - | - | escriben aprobaciones globales (hash de código / feedback) | SKIP |
| 80 | Config/Lecturas | POST/DELETE /api/cuestionamientos/default\|personalizados | - | - | escritura global compartida (sin ctx de sesión); solo se probó lectura y 401 sin sesión | SKIP |
| 81 | Skills/Cuestionamientos | GET /api/skills | - | 200 defaults + custom | ['defaults', 'custom', 'sesion'] | PASS |
| 82 | Skills/Cuestionamientos | POST /api/skills/toggle | doc_metodologica | 200 | 200 {"defaults":[{"id":"doc_metodologica","nombre":"Revisión de documentación metodo | PASS |
| 83 | Skills/Cuestionamientos | POST /api/skills/toggle (restaurar) | doc_metodologica | 200 | 200 | PASS |
| 84 | Skills/Cuestionamientos | POST /api/skills/toggle inexistente | - | 400 | 400 | PASS |
| 85 | Skills/Cuestionamientos | POST /api/skills/custom descripción corta | abc | 422 | 422 | PASS |
| 86 | Skills/Cuestionamientos | POST /api/skills/custom | - | 200 skill.id | 200 custom_001 | PASS |
| 87 | Skills/Cuestionamientos | DELETE /api/skills/custom/{id} | custom_001 | 200 | 200 | PASS |
| 88 | Skills/Cuestionamientos | DELETE /api/skills/custom inexistente | - | 404 | 404 | PASS |
| 89 | Skills/Cuestionamientos | GET /api/cuestionamientos-sesion | - | 200 | ['presencia', 'ausencia', 'custom', 'sesion'] | PASS |
| 90 | Skills/Cuestionamientos | POST /api/cuestionamientos-sesion/custom | - | 200 id | 200 cuest_custom_001 | PASS |
| 91 | Skills/Cuestionamientos | DELETE /api/cuestionamientos-sesion/custom/{id} | cuest_custom_001 | 200 | 200 | PASS |
| 92 | Skills/Cuestionamientos | DELETE cuestionamientos-sesion custom inexistente | - | 404 | 404 | PASS |
| 93 | Skills/Cuestionamientos | POST /api/prevuelo (coste 0) | - | 200 diagnóstico | 200 ['n_legibles', 'chars_totales', 'escaneados', 'sin_lector', 'lectura_fallida', 'carpetas_vacias'] | PASS |
| 94 | Skills/Cuestionamientos | POST /api/validacion/preview-prompt (LLM interceptado) | - | 200 prompt | 200 len_prompt=20416 | PASS |
| 95 | Skills/Cuestionamientos | GET /api/entendimiento sin análisis | - | 404 | 404 | PASS |
| 96 | Skills/Cuestionamientos | POST /api/entendimiento/analizar | - | - | llama al LLM de pago (salvo VIRF_MOCK_CHAT=1, desconocido en el servidor) | SKIP |
| 97 | Skills/Cuestionamientos | POST /api/entendimiento/feedback | comentario | 200 o 403/400 | 200 {"ok":true,"entrada":{"timestamp":"2026-11-18T19:56:13+00:00","comentario":"comentario de  | PASS |
| 98 | Skills/Cuestionamientos | POST /api/validar/lanzar | - | - | lanza el pipeline completo que llama al LLM de pago | SKIP |
| 99 | Skills/Cuestionamientos | POST /api/chat/iniciar\|adjuntar\|consolidar (adjuntar llama al LLM) | - | - | adjuntar re-evalúa con el LLM; iniciar/consolidar se prueban solo si hay JSON (ver Documentar) | SKIP |
| 100 | Estándares (Paso 02) | GET /api/estandares/estado inicial | - | subido/confirmado false | {'subido': False, 'confirmado': False, 'fichero': None, 'ruta_xlsx': None, 'pendiente': False} | PASS |
| 101 | Estándares (Paso 02) | GET /api/estandares/detalle sin confirmar | - | 404 | 404 | PASS |
| 102 | Estándares (Paso 02) | GET /api/estandares/vista-previa sin nada | - | 404 | 404 | PASS |
| 103 | Estándares (Paso 02) | POST /api/estandares/upload .txt | x.txt | 400 | 400 | PASS |
| 104 | Estándares (Paso 02) | POST /api/estandares/upload vacío | 0 bytes | 400 | 400 | PASS |
| 105 | Estándares (Paso 02) | POST /api/estandares/upload Excel inválido | no_es_estandar.xlsx | 400 'Excel inválido' | 400 {"detail":"Excel inválido: no se encontró una fila de títulos con ÁMBITO y ACTIVIDAD en la | PASS |
| 106 | Estándares (Paso 02) | estado tras rechazo: no quedan pendientes | - | pendiente=false | False | PASS |
| 107 | Estándares (Paso 02) | POST /api/estandares/upload (formato real) | Estandares_VIRF.xlsx | 200, 5 ámbitos y 14 actividades | 200 ámbitos=5 act=14 avisos=0 | PASS |
| 108 | Estándares (Paso 02) | merged cells ÁMBITO/CONTROL propagadas | - | cada actividad bajo su ámbito/control | [('Documentación', ['Manual metodológico']), ('Metodología', ['Estimación y calibración']), ('Datos', ['Calida | PASS |
| 109 | Estándares (Paso 02) | GET estado con pendiente | - | pendiente=true confirmado=false | True/False | PASS |
| 110 | Estándares (Paso 02) | GET vista-previa?pendiente=true | - | 200 summary | 200 | PASS |
| 111 | Estándares (Paso 02) | POST /api/estandares/confirmar | - | 200 confirmado_por | 200 PRUEBA_QA_SONNET | PASS |
| 112 | Estándares (Paso 02) | estado tras confirmar | - | confirmado=true, pendiente=false | True/False fichero=Estandares_VIRF.xlsx | PASS |
| 113 | Estándares (Paso 02) | GET detalle | - | 200 json | 200 | PASS |
| 114 | Estándares (Paso 02) | upload variante con erratas (tolerante) | ACTVIDAD / TIER ll / TIER V | 200 y avisos de corrección | 200 avisos=['«ACTVIDAD» (columna D) se leyó como Actividad.', '«TIER ll» (columna F) se leyó como Tier II.', ' | PASS |
| 115 | Estándares (Paso 02) | variante erratas: mismas 14 actividades | - | 14 | 14 | PASS |
| 116 | Estándares (Paso 02) | reemplazo pendiente: vigente intacto | - | pendiente=true, confirmado=true, fichero original | True/True/Estandares_VIRF.xlsx | PASS |
| 117 | Estándares (Paso 02) | DELETE /api/estandares/pendiente (Cancelar) | - | 200 | 200 | PASS |
| 118 | Estándares (Paso 02) | tras cancelar: vigente intacto | - | pendiente=false, confirmado=true, detalle idéntico | False/True/Estandares_VIRF.xlsx | PASS |
| 119 | Estándares (Paso 02) | vista-previa pendiente tras cancelar | - | 404 | 404 | PASS |
| 120 | Estándares (Paso 02) | DELETE pendiente sin pendiente (idempotente) | - | 200 | 200 | PASS |
| 121 | Estándares (Paso 02) | reemplazar y Aceptar (confirmar) | - | 200, fichero=erratas, pendiente=false | 200 Estandares_VIRF_erratas.xlsx | PASS |
| 122 | Estándares (Paso 02) | POST confirmar sin pendiente (doble clic) | - | idempotente 200 o 4xx claro | 200 {"status":"ok","summary":{"total_actividades":14,"total_ambitos":5,"ambitos":["D | PASS |
| 123 | Estándares (Paso 02) | DELETE /api/estandares (Eliminar) | - | 200, confirmado=false | 200 False/False | PASS |
| 124 | Estándares (Paso 02) | detalle tras eliminar | - | 404 | 404 | PASS |
| 125 | Estándares (Paso 02) | POST /api/solo-informe/estandar (erratas) | - | 200 | 200 {"status":"ok","filename":"Estandares_VIRF_erratas.xlsx","estandar":{"ambitos":[ | PASS |
| 126 | Estándares (Paso 02) | POST /api/solo-informe/estandar inválido | - | 400 | 400 | PASS |
| 127 | Estándares (Paso 02) | POST /api/solo-informe/estandar .csv | - | 400 | 400 | PASS |
| 128 | Evidencia (Paso 03) | GET /api/inputs/destinos | - | lista no vacía | 14 destinos: ['doc_modelamiento', 'doc_seguimiento', 'doc_controles_datos', 'calidad_datos_datasets', 'calidad | PASS |
| 129 | Evidencia (Paso 03) | upload sin clasificacion | - | 422/400 | 422 | PASS |
| 130 | Evidencia (Paso 03) | upload clasificacion inválida | Secreto | 400 | 400 | PASS |
| 131 | Evidencia (Paso 03) | upload Restringido en este equipo | Restringido | 403 | 403 | PASS |
| 132 | Evidencia (Paso 03) | upload destino desconocido | - | 400 | 400 | PASS |
| 133 | Evidencia (Paso 03) | upload nombre con ..\.. | ..\..\evil.md | nombre saneado a evil.md (sin escapar) | 200 [{'nombre': 'evil.md', 'tam': 1, 'estado': 'ok', 'ruta': 'modelamiento/evil.md'}] | PASS |
| 134 | Evidencia (Paso 03) | upload .zip por /upload | - | 400 usar upload-zip | 400 | PASS |
| 135 | Evidencia (Paso 03) | upload nombre en NOMBRES_PROHIBIDOS (si aplica) | config.py | no 500 | 200 | PASS |
| 136 | Evidencia (Paso 03) | upload a card doc_modelamiento | qa_doc_modelamiento.pdf (.pdf) | 200 guardado | 200 {"destino":"doc_modelamiento","guardados":[{"nombre":"qa_doc_modelamiento.pdf","tam":18720,"estado": | PASS |
| 137 | Evidencia (Paso 03) | GET carpeta/doc_modelamiento lista el fichero | - | qa_doc_modelamiento.pdf | ['config.py', 'qa_doc_modelamiento.pdf'] | PASS |
| 138 | Evidencia (Paso 03) | upload a card doc_seguimiento | qa_doc_seguimiento.pdf (.pdf) | 200 guardado | 200 {"destino":"doc_seguimiento","guardados":[{"nombre":"qa_doc_seguimiento.pdf","tam":18720,"estado":"o | PASS |
| 139 | Evidencia (Paso 03) | GET carpeta/doc_seguimiento lista el fichero | - | qa_doc_seguimiento.pdf | ['qa_doc_seguimiento.pdf'] | PASS |
| 140 | Evidencia (Paso 03) | upload a card doc_controles_datos | qa_doc_controles_datos.pdf (.pdf) | 200 guardado | 200 {"destino":"doc_controles_datos","guardados":[{"nombre":"qa_doc_controles_datos.pdf","tam":18720,"es | PASS |
| 141 | Evidencia (Paso 03) | GET carpeta/doc_controles_datos lista el fichero | - | qa_doc_controles_datos.pdf | ['qa_doc_controles_datos.pdf'] | PASS |
| 142 | Evidencia (Paso 03) | upload a card calidad_datos_datasets | qa_calidad_datos_datasets.csv (.csv) | 200 guardado | 200 {"destino":"calidad_datos_datasets","guardados":[{"nombre":"qa_calidad_datos_datasets.csv","tam":110 | PASS |
| 143 | Evidencia (Paso 03) | GET carpeta/calidad_datos_datasets lista el fichero | - | qa_calidad_datos_datasets.csv | ['qa_calidad_datos_datasets.csv'] | PASS |
| 144 | Evidencia (Paso 03) | upload a card calidad_datos_resultados | qa_calidad_datos_resultados.xlsx (.xlsx) | 200 guardado | 200 {"destino":"calidad_datos_resultados","guardados":[{"nombre":"qa_calidad_datos_resultados.xlsx","tam | PASS |
| 145 | Evidencia (Paso 03) | GET carpeta/calidad_datos_resultados lista el fichero | - | qa_calidad_datos_resultados.xlsx | ['qa_calidad_datos_resultados.xlsx'] | PASS |
| 146 | Evidencia (Paso 03) | upload implementacion (solo_zip) con fichero suelto | a.md | 400 | 400 | PASS |
| 147 | Evidencia (Paso 03) | upload-zip implementacion | codigo_modelo.zip | 200 con subcarpetas src/ | 200 n=5 ['implementacion/src/etl/etl_modelo_cc.py', 'implementacion/src/sql/extraccion.sql', 'implementacion/s | PASS |
| 148 | Evidencia (Paso 03) | upload a card usos | qa_usos.pdf (.pdf) | 200 guardado | 200 {"destino":"usos","guardados":[{"nombre":"qa_usos.pdf","tam":18720,"estado":"ok","ruta":"usos/qa_uso | PASS |
| 149 | Evidencia (Paso 03) | GET carpeta/usos lista el fichero | - | qa_usos.pdf | ['qa_usos.pdf'] | PASS |
| 150 | Evidencia (Paso 03) | upload a card excel_procesos | qa_excel_procesos.xlsx (.xlsx) | 200 guardado | 200 {"destino":"excel_procesos","guardados":[{"nombre":"qa_excel_procesos.xlsx","tam":5223,"estado":"ok" | PASS |
| 151 | Evidencia (Paso 03) | GET carpeta/excel_procesos lista el fichero | - | qa_excel_procesos.xlsx | ['qa_excel_procesos.xlsx'] | PASS |
| 152 | Evidencia (Paso 03) | upload a card logoempresa | qa_logoempresa.png (.png) | 200 guardado | 200 {"destino":"logoempresa","guardados":[{"nombre":"qa_logoempresa.png","tam":13443,"estado":"ok","ruta | PASS |
| 153 | Evidencia (Paso 03) | GET carpeta/logoempresa lista el fichero | - | qa_logoempresa.png | ['qa_logoempresa.png'] | PASS |
| 154 | Evidencia (Paso 03) | upload a card papers | qa_papers.pdf (.pdf) | 200 guardado | 200 {"destino":"papers","guardados":[{"nombre":"qa_papers.pdf","tam":18720,"estado":"ok","ruta":"papers/ | PASS |
| 155 | Evidencia (Paso 03) | GET carpeta/papers lista el fichero | - | qa_papers.pdf | ['qa_papers.pdf'] | PASS |
| 156 | Evidencia (Paso 03) | upload formato no declarado (.exe) a doc_modelamiento | macro.exe | 400/403 (idealmente) — hoy ¿lo acepta? | 200 {"destino":"doc_modelamiento","guardados":[{"nombre":"macro.exe","tam":2,"estado | FAIL |
| 157 | Evidencia (Paso 03) | GET /api/inputs/arbol | - | árbol con lo subido | 19 archivos en árbol | PASS |
| 158 | Evidencia (Paso 03) | DELETE /api/inputs/archivo/{slug}/{fichero} | doc_modelamiento/qa_doc_modelamiento.pdf | 200 | 200 | PASS |
| 159 | Evidencia (Paso 03) | DELETE archivo ya borrado | - | 404 | 404 | PASS |
| 160 | Evidencia (Paso 03) | DELETE archivo con ../ | - | 400/404 | 404 | PASS |
| 161 | Evidencia (Paso 03) | upload-zip zip-slip (../../escape.txt) | - | 400 | 400 {"detail":"entrada peligrosa en el ZIP: '../../escape.txt'"} | PASS |
| 162 | Evidencia (Paso 03) | upload-zip no-zip | - | 400 | 400 | PASS |
| 163 | Evidencia (Paso 03) | upload-zip sin clasificacion | - | 422/400 | 422 | PASS |
| 164 | Evidencia (Paso 03) | upload a destinos globales ['rag_LaR', 'rag_VaR', 'rag_ALM', 'rag_shared'] | - | - | escribirían en el corpus RAG compartido; solo se prueba con dominio qa_sonnet_ (ver RAG) | SKIP |
| 165 | Validación completa | GET /api/completa/estado | - | modalidad=completa, 5 etapas | 200 modalidad=completa etapas=5 lista=False | PASS |
| 166 | Validación completa | POST /api/completa/modalidad normal | - | 200 modalidad=normal | 200 | PASS |
| 167 | Validación completa | iteración con modalidad normal | - | 409 | 409 | PASS |
| 168 | Validación completa | POST modalidad inválida | rara | 400 | 400 | PASS |
| 169 | Validación completa | POST /api/completa/modalidad completa | - | 200 | 200 | PASS |
| 170 | Validación completa | GET etapa desconocida | 99 | 404 | 404 | PASS |
| 171 | Validación completa | GET /api/completa/etapa/00 | - | 200 sin iteraciones | 200 keys=['codigo', 'fichero', 'nombre', 'tabla', 'mision', 'previas'] | PASS |
| 172 | Validación completa | GET /api/completa/etapa/01 | - | 200 sin iteraciones | 200 keys=['codigo', 'fichero', 'nombre', 'tabla', 'mision', 'previas'] | PASS |
| 173 | Validación completa | GET /api/completa/etapa/02 | - | 200 sin iteraciones | 200 keys=['codigo', 'fichero', 'nombre', 'tabla', 'mision', 'previas'] | PASS |
| 174 | Validación completa | GET /api/completa/etapa/03 | - | 200 sin iteraciones | 200 keys=['codigo', 'fichero', 'nombre', 'tabla', 'mision', 'previas'] | PASS |
| 175 | Validación completa | GET /api/completa/etapa/04 | - | 200 sin iteraciones | 200 keys=['codigo', 'fichero', 'nombre', 'tabla', 'mision', 'previas'] | PASS |
| 176 | Validación completa | POST insumos/subir [manual] | Manual_Metodologico_MCR_CC.docx | 200 guardado | 200 ['manual/Manual_Metodologico_MCR_CC.docx'] | PASS |
| 177 | Validación completa | POST insumos/subir [manual] | Manual_Metodologico_MCR_CC.md | 200 guardado | 200 ['manual/Manual_Metodologico_MCR_CC.md'] | PASS |
| 178 | Validación completa | POST insumos/subir [manual] | Manual_Seguimiento_MCR_CC.pdf | 200 guardado | 200 ['manual/Manual_Seguimiento_MCR_CC.pdf'] | PASS |
| 179 | Validación completa | POST insumos/subir [manual] | Manual_Seguimiento_MCR_CC.md | 200 guardado | 200 ['manual/Manual_Seguimiento_MCR_CC.md'] | PASS |
| 180 | Validación completa | POST insumos/subir [manual] | Manual_Extraccion_Controles_Datos.md | 200 guardado | 200 ['manual/Manual_Extraccion_Controles_Datos.md'] | PASS |
| 181 | Validación completa | POST insumos/subir [excel_primera_linea] | 00_Diagnostico.xlsx | 200 guardado | 200 ['excel_primera_linea/00_Diagnostico.xlsx'] | PASS |
| 182 | Validación completa | POST insumos/subir [excel_primera_linea] | 01_ControlDatos.xlsx | 200 guardado | 200 ['excel_primera_linea/01_ControlDatos.xlsx'] | PASS |
| 183 | Validación completa | POST insumos/subir [excel_primera_linea] | 02_Modelamiento.xlsx | 200 guardado | 200 ['excel_primera_linea/02_Modelamiento.xlsx'] | PASS |
| 184 | Validación completa | POST insumos/subir [excel_primera_linea] | 03_Impactos.xlsx | 200 guardado | 200 ['excel_primera_linea/03_Impactos.xlsx'] | PASS |
| 185 | Validación completa | POST insumos/subir [excel_primera_linea] | Resultado_notebook_primera_linea.xlsx | 200 guardado | 200 ['excel_primera_linea/Resultado_notebook_primera_linea.xlsx'] | PASS |
| 186 | Validación completa | POST insumos/subir [script] | etl_modelo_cc.py | 200 guardado | 200 ['script/etl_modelo_cc.py'] | PASS |
| 187 | Validación completa | POST insumos/subir [script] | extraccion.sql | 200 guardado | 200 ['script/extraccion.sql'] | PASS |
| 188 | Validación completa | POST insumos/subir [script] | calibracion.ipynb | 200 guardado | 200 ['script/calibracion.ipynb'] | PASS |
| 189 | Validación completa | POST insumos/subir [script] | codigo_modelo.zip | 200 guardado | 200 ['script/codigo_modelo.zip'] | PASS |
| 190 | Validación completa | POST insumos/subir [otro] | clientes.csv | 200 guardado | 200 ['otro/clientes.csv'] | PASS |
| 191 | Validación completa | insumos/subir categoría inválida | - | 400 | 400 | PASS |
| 192 | Validación completa | insumos/subir formato no admitido | .exe | 400 | 400 | PASS |
| 193 | Validación completa | insumos/subir archivo vacío | - | 400 | 400 | PASS |
| 194 | Validación completa | GET /api/completa/insumos | - | 15 insumos | total=32 estudiados=0 | PASS |
| 195 | Validación completa | POST insumos/estudiar usar_ia=false | - | 200, todos estudiados | 200 32/32 0.2s | PASS |
| 196 | Validación completa | estudio detecta rutas Windows/UNC del script | - | incluye C:\Users… y \\srv-datos01… | ['C:\\Users\\analista\\Documents\\modelos\\cc\\clientes.csv', '\\\\srv-datos01\\modelos\\cc\\saldos.csv', 'S:\ | PASS |
| 197 | Validación completa | estudio: ficha .sql detecta tablas dwh.* | - | tablas dwh.clientes/dwh.saldos_diarios | {"id": "implementacion/src/sql/extraccion.sql", "nombre": "implementacion/src/sql/extraccion.sql", "origen": " | PASS |
| 198 | Validación completa | estudio: ZIP con código en subcarpetas | - | ficha(s) del zip estudiada(s) | 5 fichas con 'codigo_modelo' | PASS |
| 199 | Validación completa | insumos/estudiar repetido (caché) | - | 200 idempotente | 200 | PASS |
| 200 | Validación completa | DELETE insumos/archivo | otro/borrar_me.md | 200 | 200 | PASS |
| 201 | Validación completa | DELETE insumos/archivo repetido | - | 404 | 404 | PASS |
| 202 | Validación completa | DELETE insumos/archivo con path traversal | ../../… | 400 | 400 {"detail":"solo se pueden borrar insumos de la carpeta común"} | PASS |
| 203 | Validación completa | traversal no tocó el estándar | - | estándar sigue confirmado | True | PASS |
| 204 | Validación completa | [00] ITER0 rutas+2 imágenes (usar_ia=false) | rutas + captura_1/2.png | 200 ITER0 ipynb+md | 200 00_DiagnosticoITER0.ipynb modo=plantilla sin IA imgs=['captura_1.png', 'captura_2.png']  | PASS |
| 205 | Validación completa | [00] ITER0 reporta rutas y 2 imágenes | - | imagenes=2 | ['captura_1.png', 'captura_2.png'] | PASS |
| 206 | Validación completa | [00] GET descargar 00_DiagnosticoITER0.ipynb | - | 200 | 200 6114B ct=application/x-ipynb+json | PASS |
| 207 | Validación completa | [00] ipynb JSON válido nbformat 4 (validate) | - | nbformat.validate OK | 5 celdas | PASS |
| 208 | Validación completa | [00] GET descargar 00_DiagnosticoITER0.md | - | 200 | 200 3819B ct=text/markdown; charset=utf-8 | PASS |
| 209 | Validación completa | [00] .md con contenido de revisión | - | texto con ITER0 | # 00_DiagnosticoITER0 · revisión del agente  - **Modelo:** | PASS |
| 210 | Validación completa | [00] GET imagen ITER0/captura_1.png | - | 200 image/png | 200 image/png | PASS |
| 211 | Validación completa | [00] ITER1 devuelve Excel resultado + comentario | ITER1_resultado_00.xlsx | 200 ITER1 | 200 n=1 veredicto={"estado": "otra_iteracion", "motivo": "Borrador sin IA: la etapa no se puede da  | PASS |
| 212 | Validación completa | [00] etapa tiene 2 iteraciones y mensajes | - | iteraciones=2 | it=2 msgs=4 | PASS |
| 213 | Validación completa | [00] ITER2 solo comentario (reusa rutas) | - | 200 | 200  | PASS |
| 214 | Validación completa | [01] ITER0 rutas+2 imágenes (usar_ia=false) | rutas + captura_1/2.png | 200 ITER0 ipynb+md | 200 01_ControlDatosITER0.ipynb modo=plantilla sin IA imgs=['captura_1.png', 'captura_2.png']  | PASS |
| 215 | Validación completa | [01] ITER0 reporta rutas y 2 imágenes | - | imagenes=2 | ['captura_1.png', 'captura_2.png'] | PASS |
| 216 | Validación completa | [01] GET descargar 01_ControlDatosITER0.ipynb | - | 200 | 200 7573B ct=application/x-ipynb+json | PASS |
| 217 | Validación completa | [01] ipynb JSON válido nbformat 4 (validate) | - | nbformat.validate OK | 7 celdas | PASS |
| 218 | Validación completa | [01] GET descargar 01_ControlDatosITER0.md | - | 200 | 200 3927B ct=text/markdown; charset=utf-8 | PASS |
| 219 | Validación completa | [01] .md con contenido de revisión | - | texto con ITER0 | # 01_ControlDatosITER0 · revisión del agente  - **Modelo:* | PASS |
| 220 | Validación completa | [01] GET imagen ITER0/captura_1.png | - | 200 image/png | 200 image/png | PASS |
| 221 | Validación completa | [01] ITER1 devuelve Excel resultado + comentario | ITER1_resultado_01.xlsx | 200 ITER1 | 200 n=1 veredicto={"estado": "otra_iteracion", "motivo": "Borrador sin IA: la etapa no se puede da  | PASS |
| 222 | Validación completa | [01] etapa tiene 2 iteraciones y mensajes | - | iteraciones=2 | it=2 msgs=4 | PASS |
| 223 | Validación completa | [01] ITER2 solo comentario (reusa rutas) | - | 200 | 200  | PASS |
| 224 | Validación completa | [02] ITER0 rutas+2 imágenes (usar_ia=false) | rutas + captura_1/2.png | 200 ITER0 ipynb+md | 200 02_ModelamientoITER0.ipynb modo=plantilla sin IA imgs=['captura_1.png', 'captura_2.png']  | PASS |
| 225 | Validación completa | [02] ITER0 reporta rutas y 2 imágenes | - | imagenes=2 | ['captura_1.png', 'captura_2.png'] | PASS |
| 226 | Validación completa | [02] GET descargar 02_ModelamientoITER0.ipynb | - | 200 | 200 7090B ct=application/x-ipynb+json | PASS |
| 227 | Validación completa | [02] ipynb JSON válido nbformat 4 (validate) | - | nbformat.validate OK | 7 celdas | PASS |
| 228 | Validación completa | [02] GET descargar 02_ModelamientoITER0.md | - | 200 | 200 4005B ct=text/markdown; charset=utf-8 | PASS |
| 229 | Validación completa | [02] .md con contenido de revisión | - | texto con ITER0 | # 02_ModelamientoITER0 · revisión del agente  - **Modelo:* | PASS |
| 230 | Validación completa | [02] GET imagen ITER0/captura_1.png | - | 200 image/png | 200 image/png | PASS |
| 231 | Validación completa | [02] ITER1 devuelve Excel resultado + comentario | ITER1_resultado_02.xlsx | 200 ITER1 | 200 n=1 veredicto={"estado": "otra_iteracion", "motivo": "Borrador sin IA: la etapa no se puede da  | PASS |
| 232 | Validación completa | [02] etapa tiene 2 iteraciones y mensajes | - | iteraciones=2 | it=2 msgs=4 | PASS |
| 233 | Validación completa | [03] ITER0 rutas+2 imágenes (usar_ia=false) | rutas + captura_1/2.png | 200 ITER0 ipynb+md | 200 03_ImpactosITER0.ipynb modo=plantilla sin IA imgs=['captura_1.png', 'captura_2.png']  | PASS |
| 234 | Validación completa | [03] ITER0 reporta rutas y 2 imágenes | - | imagenes=2 | ['captura_1.png', 'captura_2.png'] | PASS |
| 235 | Validación completa | [03] GET descargar 03_ImpactosITER0.ipynb | - | 200 | 200 6576B ct=application/x-ipynb+json | PASS |
| 236 | Validación completa | [03] ipynb JSON válido nbformat 4 (validate) | - | nbformat.validate OK | 6 celdas | PASS |
| 237 | Validación completa | [03] GET descargar 03_ImpactosITER0.md | - | 200 | 200 4065B ct=text/markdown; charset=utf-8 | PASS |
| 238 | Validación completa | [03] .md con contenido de revisión | - | texto con ITER0 | # 03_ImpactosITER0 · revisión del agente  - **Modelo:** QA | PASS |
| 239 | Validación completa | [03] GET imagen ITER0/captura_1.png | - | 200 image/png | 200 image/png | PASS |
| 240 | Validación completa | [03] ITER1 devuelve Excel resultado + comentario | ITER1_resultado_03.xlsx | 200 ITER1 | 200 n=1 veredicto={"estado": "otra_iteracion", "motivo": "Borrador sin IA: la etapa no se puede da  | PASS |
| 241 | Validación completa | [03] etapa tiene 2 iteraciones y mensajes | - | iteraciones=2 | it=2 msgs=4 | PASS |
| 242 | Validación completa | [04] ITER0 rutas+2 imágenes (usar_ia=false) | rutas + captura_1/2.png | 200 ITER0 ipynb+md | 200 04_SeguimientoITER0.ipynb modo=plantilla sin IA imgs=['captura_1.png', 'captura_2.png']  | PASS |
| 243 | Validación completa | [04] ITER0 reporta rutas y 2 imágenes | - | imagenes=2 | ['captura_1.png', 'captura_2.png'] | PASS |
| 244 | Validación completa | [04] GET descargar 04_SeguimientoITER0.ipynb | - | 200 | 200 6482B ct=application/x-ipynb+json | PASS |
| 245 | Validación completa | [04] ipynb JSON válido nbformat 4 (validate) | - | nbformat.validate OK | 6 celdas | PASS |
| 246 | Validación completa | [04] GET descargar 04_SeguimientoITER0.md | - | 200 | 200 4175B ct=text/markdown; charset=utf-8 | PASS |
| 247 | Validación completa | [04] .md con contenido de revisión | - | texto con ITER0 | # 04_SeguimientoITER0 · revisión del agente  - **Modelo:** | PASS |
| 248 | Validación completa | [04] GET imagen ITER0/captura_1.png | - | 200 image/png | 200 image/png | PASS |
| 249 | Validación completa | [04] ITER1 devuelve Excel resultado + comentario | ITER1_resultado_04.xlsx | 200 ITER1 | 200 n=1 veredicto={"estado": "otra_iteracion", "motivo": "Borrador sin IA: la etapa no se puede da  | PASS |
| 250 | Validación completa | [04] etapa tiene 2 iteraciones y mensajes | - | iteraciones=2 | it=2 msgs=4 | PASS |
| 251 | Validación completa | iteración con formato no admitido | .exe | 400 | 400 | PASS |
| 252 | Validación completa | iteración nombre con ../ | ../../evil.md | saneado (200) o 400, nunca fuera de la carpeta | 200 | PASS |
| 253 | Validación completa | iteración con rutas malformadas | - | no 500 | 200 {"iteracion":{"n":2,"ts":"2026-11-18T19:56:17+00:00","modo":"plantilla sin IA"," | PASS |
| 254 | Validación completa | imagen con traversal | - | 400/404 | 404 | PASS |
| 255 | Validación completa | imagen extensión no imagen | - | 400 | 400 | PASS |
| 256 | Validación completa | imagen de iteración inexistente | - | 404 | 404 | PASS |
| 257 | Validación completa | descargar con traversal | - | 400/404 | 404 | PASS |
| 258 | Validación completa | descargar .json (no permitido) | - | 400 | 400 | PASS |
| 259 | Validación completa | descargar inexistente | - | 404 | 404 | PASS |
| 260 | Validación completa | cerrar sin motivo | motivo='' | 200 o 400 claro | 200 {"codigo":"00","fichero":"00_Diagnostico","nombre":"Diagnóstico","tabla":"Mapeo  | PASS |
| 261 | Validación completa | [00] POST cerrar | motivo | 200 cierre | 200 {'iter': 3, 'por': 'PRUEBA_QA_SONNET', 'ts': '2026-11-18T19:56:17+00:00', 'motiv  | PASS |
| 262 | Validación completa | [01] POST cerrar | motivo | 200 cierre | 200 {'iter': 2, 'por': 'PRUEBA_QA_SONNET', 'ts': '2026-11-18T19:56:17+00:00', 'motiv  | PASS |
| 263 | Validación completa | [02] POST cerrar | motivo | 200 cierre | 200 {'iter': 1, 'por': 'PRUEBA_QA_SONNET', 'ts': '2026-11-18T19:56:17+00:00', 'motiv  | PASS |
| 264 | Validación completa | [03] POST cerrar | motivo | 200 cierre | 200 {'iter': 2, 'por': 'PRUEBA_QA_SONNET', 'ts': '2026-11-18T19:56:17+00:00', 'motiv  | PASS |
| 265 | Validación completa | [04] POST cerrar | motivo | 200 cierre | 200 {'iter': 1, 'por': 'PRUEBA_QA_SONNET', 'ts': '2026-11-18T19:56:18+00:00', 'motiv  | PASS |
| 266 | Validación completa | estado.lista_para_validar tras cerrar 00–04 | - | true | lista=True cerradas=5/5 | PASS |
| 267 | Validación completa | reabrir etapa 02 | reabrir=true | 200 y lista_para_validar=false | 200 lista=False | PASS |
| 268 | Validación completa | cerrar etapa desconocida | 99 | 404 | 404 | PASS |
| 269 | Validación completa | re-cerrar 02 | - | lista_para_validar=true | True | PASS |
| 270 | Validación completa | nueva iteración reabre la etapa (cierre=None) | - | lista_para_validar=false | False | PASS |
| 271 | Notebooks (ejecución) | ejecutar notebook 00 (exec en un namespace, venv) | 3 celdas de código | exit 0 | exit=0 cwd=C:\Users\RECTEC~1\AppData\Local\Temp\qa_nb00_hc8uwov0  | PASS |
| 272 | Notebooks (ejecución) | notebook 00 produce Excel de resultado | - | ≥1 .xlsx | ['C:\\Users\\RECTEC~1\\AppData\\Local\\Temp\\qa_nb00_hc8uwov0\\00_Diagnostico_resultadoITER0.xlsx'] | PASS |
| 273 | Notebooks (ejecución) | notebook 00: Excel con hojas y filas | 00_Diagnostico_resultadoITER0.xlsx | hojas con datos | ['Indice', 'perfil_clientes', 'perfil_saldos', 'Mapeo'] {'Indice': 4, 'perfil_clientes': 6, 'perfil_saldos': 4 | PASS |
| 274 | Notebooks (ejecución) | notebook 00: hoja «Mapeo» con datos (no solo cabecera) | 00_Diagnostico_resultadoITER0.xlsx | ≥2 filas | filas=4 cabecera=['base', 'ruta', 'filas', 'columnas', 'duplicados', 'pct_nulos_medio'] | PASS |
| 275 | Notebooks (ejecución) | ejecutar notebook 01 (exec en un namespace, venv) | 4 celdas de código | exit 0 | exit=0 cwd=C:\Users\RECTEC~1\AppData\Local\Temp\qa_nb01_bi3z76z1  | PASS |
| 276 | Notebooks (ejecución) | notebook 01 produce Excel de resultado | - | ≥1 .xlsx | ['C:\\Users\\RECTEC~1\\AppData\\Local\\Temp\\qa_nb01_bi3z76z1\\01_ControlDatos_resultadoITER0.xlsx'] | PASS |
| 277 | Notebooks (ejecución) | notebook 01: Excel con hojas y filas | 01_ControlDatos_resultadoITER0.xlsx | hojas con datos | ['Indice', 'perfil_clientes', 'perfil_saldos', 'Mapeo', 'Controles'] {'Indice': 5, 'perfil_clientes': 6, 'perf | PASS |
| 278 | Notebooks (ejecución) | notebook 01: hoja «Controles» con datos (no solo cabecera) | 01_ControlDatos_resultadoITER0.xlsx | ≥2 filas | filas=6 cabecera=['elemento', 'control', 'afectados', 'total', 'pct'] | PASS |
| 279 | Notebooks (ejecución) | notebook 01 (plantilla sin IA) detecta DUPLICADOS DE LLAVE id_cliente (2 ids repetidos sembrados) | clientes.csv con id repetido | control de unicidad de llave con afectados>0 | filas=[['elemento', 'control', 'afectados', 'total'], ['clientes', 'filas duplicadas', 0, 400], ['clientes.ing | FAIL |
| 280 | Notebooks (ejecución) | ejecutar notebook 02 (exec en un namespace, venv) | 4 celdas de código | exit 0 | exit=0 cwd=C:\Users\RECTEC~1\AppData\Local\Temp\qa_nb02_55jmft6r  | PASS |
| 281 | Notebooks (ejecución) | notebook 02 produce Excel de resultado | - | ≥1 .xlsx | ['C:\\Users\\RECTEC~1\\AppData\\Local\\Temp\\qa_nb02_55jmft6r\\02_Modelamiento_resultadoITER0.xlsx'] | PASS |
| 282 | Notebooks (ejecución) | notebook 02: Excel con hojas y filas | 02_Modelamiento_resultadoITER0.xlsx | hojas con datos | ['Indice', 'perfil_clientes', 'perfil_saldos', 'Mapeo', 'Replica'] {'Indice': 5, 'perfil_clientes': 6, 'perfil | PASS |
| 283 | Notebooks (ejecución) | notebook 02: hoja «Replica» con datos (no solo cabecera) | 02_Modelamiento_resultadoITER0.xlsx | ≥2 filas | filas=2 cabecera=['paso', 'fuente', 'implementador', 'replicado', 'diferencia', 'conclusion'] | PASS |
| 284 | Notebooks (ejecución) | ejecutar notebook 03 (exec en un namespace, venv) | 4 celdas de código | exit 0 | exit=0 cwd=C:\Users\RECTEC~1\AppData\Local\Temp\qa_nb03_e9biu3ld  | PASS |
| 285 | Notebooks (ejecución) | notebook 03 produce Excel de resultado | - | ≥1 .xlsx | ['C:\\Users\\RECTEC~1\\AppData\\Local\\Temp\\qa_nb03_e9biu3ld\\03_Impactos_resultadoITER0.xlsx'] | PASS |
| 286 | Notebooks (ejecución) | notebook 03: Excel con hojas y filas | 03_Impactos_resultadoITER0.xlsx | hojas con datos | ['Indice', 'perfil_clientes', 'perfil_saldos', 'Mapeo', 'Impactos'] {'Indice': 5, 'perfil_clientes': 6, 'perfi | PASS |
| 287 | Notebooks (ejecución) | notebook 03: hoja «Impactos» con datos (no solo cabecera) | 03_Impactos_resultadoITER0.xlsx | ≥2 filas | filas=2 cabecera=['origen', 'etapa', 'metrica', 'valor_original', 'valor_corregido', 'impacto'] | PASS |
| 288 | Notebooks (ejecución) | ejecutar notebook 04 (exec en un namespace, venv) | 4 celdas de código | exit 0 | exit=0 cwd=C:\Users\RECTEC~1\AppData\Local\Temp\qa_nb04_o_bj6x2s  | PASS |
| 289 | Notebooks (ejecución) | notebook 04 produce Excel de resultado | - | ≥1 .xlsx | ['C:\\Users\\RECTEC~1\\AppData\\Local\\Temp\\qa_nb04_o_bj6x2s\\04_Seguimiento_resultadoITER0.xlsx'] | PASS |
| 290 | Notebooks (ejecución) | notebook 04: Excel con hojas y filas | 04_Seguimiento_resultadoITER0.xlsx | hojas con datos | ['Indice', 'perfil_clientes', 'perfil_saldos', 'Mapeo', 'Seguimiento'] {'Indice': 5, 'perfil_clientes': 6, 'pe | PASS |
| 291 | Notebooks (ejecución) | notebook 04: hoja «Seguimiento» con datos (no solo cabecera) | 04_Seguimiento_resultadoITER0.xlsx | ≥2 filas | filas=2 cabecera=['indicador', 'umbral', 'implementador', 'replicado', 'semaforo', 'conclusion'] | PASS |
| 292 | Documentar | GET /api/automatizaciones/estado (completa: vigentes de cada etapa) | - | etapas 00–03 con archivo | {'00': '00_Diagnostico.xlsx', '01': '01_ControlDatos.xlsx', '02': '02_Modelamiento.xlsx', '03': '03_Impactos.x | PASS |
| 293 | Documentar | POST /api/automatizaciones/cuadro usar_ia=false | - | 200 con filas y _xlsx | 200 filas=2  | PASS |
| 294 | Documentar | GET automatizaciones/descargar cuadro .xlsx | cuadro_observaciones_20261118_145628.xlsx | 200 xlsx | 200 6741B | PASS |
| 295 | Documentar | cuadro: filas con riesgo/responsable | - | filas con riesgo | 2 filas, riesgos={'Potencial/Bajo', 'Moderado'} | PASS |
| 296 | Documentar | automatizaciones/descargar traversal | - | 400/404 | 404 | PASS |
| 297 | Documentar | automatizaciones/descargar no-xlsx | - | 400 | 400 | PASS |
| 298 | Documentar | estado.ultimo tras generar | - | ultimo no nulo | True | PASS |
| 299 | Documentar | siembra resultados_*.json sintético | 2026-11-18/resultados_QA_SONNET_031769_2026-11-18.json | - | escrito en la sesión del modelo de prueba | PASS |
| 300 | Documentar | GET /api/resultados/lista | - | incluye el sintético | 200 | PASS |
| 301 | Documentar | GET /api/resultados/{fecha}/{fichero} | - | 200 datos | 200 | PASS |
| 302 | Documentar | GET /api/resultados/tabla/{fecha}/{fichero} | - | 200 | 200 | PASS |
| 303 | Documentar | GET /api/resultados/actual | - | 200 o 404 | 404 {"detail":"no hay resultado disponible de una corrida"} | PASS |
| 304 | Documentar | GET /api/resultados/tabla (sin corrida) | - | 404 | 404 | PASS |
| 305 | Documentar | GET /api/resultados/excel intermedio | - | 200 xlsx | 200 5399B | PASS |
| 306 | Documentar | GET /api/resultados/excel final | - | 200 xlsx | 200 5419B | PASS |
| 307 | Documentar | resultados traversal | - | 400/404 | 404 | PASS |
| 308 | Documentar | resultados fecha inválida | - | 400 | 400 | PASS |
| 309 | Documentar | POST /api/chat/iniciar (sin LLM) | 2026-11-18/resultados_QA_SONNET_031769_2026-11-18.json | 200 sesión de chat | 200 {"id":"13c609302477","clave":"PRUEBA_QA_SONNET/QA_SONNET_031769","modelo":"QA_SONNET_031769","tier": | PASS |
| 310 | Documentar | GET /api/chat/estado tras iniciar | - | activa=true | True | PASS |
| 311 | Documentar | GET /api/chat/observaciones | - | 200 detalle | 200 {'APROBADO': 0, 'NEGADO': 0, 'PENDIENTE': 0, 'SIN_TRATAR': 2, 'total': 2} | PASS |
| 312 | Documentar | POST /api/chat/adjuntar \| POST /api/chat/consolidar | - | - | adjuntar llama al LLM; consolidar no se ejecutó por depender del veredicto del chat | SKIP |
| 313 | Documentar | GET /api/chat/acta.xlsx | - | 200 xlsx o 4xx claro | 200 7048B | PASS |
| 314 | Documentar | informe/consolidado ruta mala | - | 400 | 400 | PASS |
| 315 | Documentar | informe/consolidado inexistente | - | 404 | 404 | PASS |
| 316 | Documentar | POST /api/informe/consolidado (Word) | 2026-11-18/resultados_QA_SONNET_031769_2026-11-18.json | 200 docx | 200 VIRF_Informe_QA_SONNET_031769_V1_18112026.docx V1  | PASS |
| 317 | Documentar | GET /api/informe/descargar/{docx} | VIRF_Informe_QA_SONNET_031769_V1_18112026.docx | 200 docx | 200 108128B | PASS |
| 318 | Documentar | Word contiene anexo «Validación completa · sustento por etapa» | - | título presente | encontrado | PASS |
| 319 | Documentar | Word incluye las imágenes de sustento (≥2 inline) | - | ≥2 imágenes (hay 10 subidas, 2 por etapa) | inline_shapes=11 | PASS |
| 320 | Documentar | Word: pies de figura S# | - | 'Figura S1.' … | Figura S1. 00_DiagnosticoITER0 — captura_1.png.; Figura S2. 00_DiagnosticoITER0 — captura_2.png.; Figura S3. 0 | PASS |
| 321 | Documentar | Word: tabla de etapas (00–04 con estado) | - | 5 filas de etapa |  | PASS |
| 322 | Documentar | Word: observación de prueba presente | - | texto del control |  | PASS |
| 323 | Documentar | informe/descargar traversal | - | 400/404 | 404 | PASS |
| 324 | Documentar | GET /api/informe/versiones | - | ≥1 versión | 1 | PASS |
| 325 | Documentar | GET /api/informe/estado | - | resultados_disponibles incluye el sintético | 200 | PASS |
| 326 | Documentar | GET /api/motores/notebook (controles de datos) | - | 200 ipynb | 200 35921B x-n=11 | PASS |
| 327 | Documentar | motores/notebook es nbformat válido | - | válido | ok | PASS |
| 328 | Solo informe | GET /api/solo-informe/estado | - | estándar con 14 controles | 200 controles=14 | PASS |
| 329 | Solo informe | POST /api/solo-informe/imagen | captura_1.png | 200 imagen_id | 200 a6b69b7cad11476fb325b70a4111b8c3.png | PASS |
| 330 | Solo informe | GET /api/solo-informe/imagen/{id} | - | 200 png | 200 | PASS |
| 331 | Solo informe | POST solo-informe/imagen no-imagen | - | 400 | 400 | PASS |
| 332 | Solo informe | POST solo-informe/adjunto sin clasificación | - | 422/400 | 422 | PASS |
| 333 | Solo informe | POST solo-informe/adjunto Interno | - | 200 id | 200 {"status":"ok","id":"b8b80f19635a45108de8012b3ac8b74d.xlsx","nombre":"Resultado. | PASS |
| 334 | Solo informe | POST solo-informe/adjunto Restringido | - | 403 | 403 | PASS |
| 335 | Solo informe | PUT /api/solo-informe/borrador | - | 200 | 200 {"status":"ok"} | PASS |
| 336 | Solo informe | POST /api/solo-informe/generar | - | 200 + url | 200 {"status":"ok","nombre":"Informe_Resultados_MCR_CC_QA_20261118_145629.docx","url":"/api/solo-informe/desca | PASS |
| 337 | Solo informe | GET solo-informe/descargar | /api/solo-informe/descargar/Informe_Resultados_MCR_CC_QA_202 | 200 docx | 200 94902B | PASS |
| 338 | Solo informe | generar con riesgo inválido | - | 400 | 400 {"detail":"Observación 1: riesgo no válido."} | PASS |
| 339 | Solo informe | solo-informe/descargar traversal | - | 400/404 | 404 | PASS |
| 340 | Solo informe | solo-informe/descargar nombre fuera de patrón | - | 400 | 400 | PASS |
| 341 | Solo informe | GET solo-informe/manuales | - | 200 | 200 | PASS |
| 342 | Solo informe | POST solo-informe/manuales | - | 200 | 200 {"status":"ok","nombre":"Manual_Metodologico_MCR_CC.md","fragmentos":2,"manuales | PASS |
| 343 | Solo informe | DELETE solo-informe/manuales/{n} | - | 200 | 200 | PASS |
| 344 | Solo informe | DELETE solo-informe/manuales inexistente | - | 404 | 404 | PASS |
| 345 | Solo informe | POST /api/solo-informe/ia/pulir\|grafico\|manuales | - | - | llaman al LLM de pago | SKIP |
| 346 | Solo informe | DELETE solo-informe/estandar | - | 200 | 200 | PASS |
| 347 | RAG | GET /api/rag/dominios | - | fijos con índice | [('LaR', 11, False), ('VaR', None, False), ('ALM', None, False), ('shared', None, False)] | PASS |
| 348 | RAG | crear dominio nombre corto | x | 422 | 422 | PASS |
| 349 | RAG | POST /api/rag/dominios/crear (qa_sonnet_) | qa_sonnet_dom_031769 | 200 id | 200 id=qa_sonnet_dom_031769 {"dominio":{"id":"qa_sonnet_dom_031769","tipo":"custom","nombre":"qa_sonnet_dom_ | PASS |
| 350 | RAG | id del dominio empieza por qa_sonnet_ | - | qa_sonnet_* | qa_sonnet_dom_031769 | PASS |
| 351 | RAG | crear dominio duplicado | - | 400 | 400 {"detail":"ya existe un dominio custom con id 'qa_sonnet_dom | PASS |
| 352 | RAG | DELETE dominio fijo LaR | - | 400 (no se borra) | 400 | PASS |
| 353 | RAG | /api/inputs/destinos incluye rag_qa_sonnet_dom_031769 | - | rag_qa_sonnet_dom_031769 presente | ['rag_LaR', 'rag_VaR', 'rag_ALM', 'rag_shared'] | FAIL |
| 354 | RAG | upload paper a rag_qa_sonnet_dom_031769 | paper_calibracion_pd.md | 200 (así lo hace la UI) | 400 {"detail":"destino desconocido: 'rag_qa_sonnet_dom_031769'"} | FAIL |
| 355 | RAG | upload paper a rag_qa_sonnet_dom_031769 | paper_gini_ks.pdf | 200 (así lo hace la UI) | 400 {"detail":"destino desconocido: 'rag_qa_sonnet_dom_031769'"} | FAIL |
| 356 | RAG | upload paper a rag_qa_sonnet_dom_031769 | paper_liquidez_basilea.md | 200 (así lo hace la UI) | 400 {"detail":"destino desconocido: 'rag_qa_sonnet_dom_031769'"} | FAIL |
| 357 | RAG | upload paper a rag_qa_sonnet_dom_031769 | paper_psi_estabilidad.txt | 200 (así lo hace la UI) | 400 {"detail":"destino desconocido: 'rag_qa_sonnet_dom_031769'"} | FAIL |
| 358 | RAG | upload RAG sin dueño/vigencia | - | 400 (o 400 destino desconocido) | 400 {"detail":"una fuente del corpus RAG necesita dueño y vigencia (2135.010.02 §Car | PASS |
| 359 | RAG | dominio de prueba lista los papers subidos | - | 4 papers | 1 papers; subidos=0 | FAIL |
| 360 | RAG | reconstruir índice / búsquedas / borrar paper del dominio qa_sonnet_ | - | - | BLOQUEADO por el fallo de subida (destino rag_<custom> desconocido): no hay papers que indexar y no se escribe | SKIP |
| 361 | RAG | reconstruir dominio inexistente | - | 400 | 400 | PASS |
| 362 | RAG | POST /api/rag/reconstruir {dominio:'all'} y reconstruir de dominios fijos | - | - | reconstruirían índices globales/compartidos | SKIP |
| 363 | RAG | dominios existentes intactos (chunks/papers/índice) | - | idénticos a antes | iguales | PASS |
| 364 | UI (navegador) | Login libre en 127.0.0.1:8010 (cookie aparte) y alta de modelo completa desde el formulario | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | entra a la vista del modelo; 0 errores de consola | PASS |
| 365 | UI (navegador) | Sidebar: 18 botones nav (config, estándares, evidencia, RAG, skills, cuestionamientos, pre-vuelo, validar, documentar, insumos, etapas 00–04, resultados, controles, chat) | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | cada uno abre su panel; 0 errores JS/consola | PASS |
| 366 | UI (navegador) | Estándares: subir .xlsx → vista previa (14 act, 5 ámbitos) → Aceptar | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | estado confirmado | PASS |
| 367 | UI (navegador) | Estándares: Cambiar archivo (descarta pendiente y vuelve a la dropzone) | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | ok | PASS |
| 368 | UI (navegador) | Estándares: Ver detalle / Reemplazar / (Cancelar reemplazo) con pendiente subido | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | al cancelar: pendiente=false, vigente intacto | PASS |
| 369 | UI (navegador) | Estándares: Eliminar (confirm) | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | confirmado=false, dropzone visible | PASS |
| 370 | UI (navegador) | Estándares: archivo .txt y 'xlsx' no-zip → mensaje de error claro en #est-error | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | ok | PASS |
| 371 | UI (navegador) | Validar modelo: botón Vista previa del prompt (preview-prompt, LLM interceptado) | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | sin errores | PASS |
| 372 | UI (navegador) | Documentar: «Cuadro borrador» (usar_ia=false) y panel de estado | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | sin errores de consola | PASS |
| 373 | UI (navegador) | Modal de Configuración abre/cierra (Cancelar), Verificar NO pulsado (llama al proveedor) | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | ok | PASS |
| 374 | UI (navegador) | Toggle VALIDACIÓN normal↔completa (btn-modalidad) | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | alterna y refleja la etiqueta (primer clic mostró aún «normal» hasta recargar la etiqueta) | PASS |
| 375 | UI (navegador) | Validar modelo: «Firmante … (SSO): —» debería mostrar la identidad del usuario | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | SIEMPRE muestra «—». web/static/js/app.js:2139-2143 rellena #firm-identidad en el cableado inicial, cuando est | FAIL |
| 376 | UI (navegador) | Documentar: texto de ayuda (index.html:524) dice «súbelos en Subir evidencia → automatizaciones/» | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | esa tarjeta está oculta ('oculto': True en contexto_sesion.py:~180); en completa los Excels van al chat de cad | FAIL |
| 377 | UI (navegador) | Subida masiva a las 10 tarjetas de Evidencia por la UI, chat de etapa (enviar/cerrar/reabrir), insumos subir/estudiar/borrar por UI | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | el clasificador de permisos del entorno BLOQUEÓ el script de subida masiva por UI (DataTransfer a 10 tarjetas) | SKIP |
| 378 | UI (navegador) | Mapa estático: 92 ids interactivos de index.html | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | todos tienen listener en JS (btn-etapa-00..04 se cablean dinámicamente en completa.js:53,63) | PASS |
| 379 | UI (navegador) | Mapa estático: 92 endpoints /api/* citados en el JS | navegador (JS .click / fetch) | sin error de consola y comportamiento correcto | todos existen en el backend (incl. /api/resultados/${ruta}, /api/completa/etapa/${..}/descargar/); /api/estand | PASS |
| 380 | Limpieza | borrar modelo creado por la UI | QA_SONNET_UI | 200 | 200 | PASS |
| 381 | Limpieza | DELETE dominio qa_sonnet_ | qa_sonnet_dom_031769 | 200 | 200 {"id":"qa_sonnet_dom_031769","movido_a":"archivo\\dominios_retirados\\qa_sonnet_dom_031769_20261118_ | PASS |
| 382 | Limpieza | dominio de prueba ya no está | - | ausente |  | PASS |
| 383 | Limpieza | borrado del dominio limpia disco (inputs/rag y .pkl) | - | sin residuos | inputs=False pkl=False | PASS |
| 384 | Limpieza | borrar modelo QA principal | QA_SONNET_031769 | 200 | 200 | PASS |
| 385 | Limpieza | sin modelos QA_SONNET residuales | - | [] | [] | PASS |
| 386 | Limpieza | residuos del dominio en data/*.json (registro de fuentes) | - | ninguno | ninguno | PASS |
