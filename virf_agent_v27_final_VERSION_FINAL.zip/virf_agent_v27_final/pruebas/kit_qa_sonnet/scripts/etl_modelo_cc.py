# -*- coding: utf-8 -*-
"""ETL del modelo MCR_Cuenta_Corriente (sintético)."""
import pandas as pd

RUTA_CLIENTES = r"C:\Users\analista\Documents\modelos\cc\clientes.csv"
RUTA_SALDOS = r"\\srv-datos01\modelos\cc\saldos.csv"


def cargar():
    clientes = pd.read_csv(r"C:\Users\analista\Documents\modelos\cc\clientes.csv")
    saldos = pd.read_csv(r"\\srv-datos01\modelos\cc\saldos.csv")
    return clientes, saldos


def depurar(clientes, saldos):
    """Excluye saldos negativos y duplicados de llave (regla 2.2 del manual)."""
    clientes = clientes.drop_duplicates("id_cliente")
    saldos = saldos[saldos["saldo"] >= 0]
    return clientes, saldos


def construir_base(clientes, saldos):
    prom = saldos.groupby("id_cliente")["saldo"].mean().rename("saldo_promedio_3m").reset_index()
    return clientes.merge(prom, on="id_cliente", how="left")


if __name__ == "__main__":
    c, s = cargar()
    c, s = depurar(c, s)
    construir_base(c, s).to_csv(r"S:\\modelos\\salida\\base_modelo.csv", index=False)
