-- Extraccion mensual del modelo MCR_Cuenta_Corriente
SELECT c.id_cliente, c.segmento, s.periodo, s.saldo
FROM dwh.clientes c
JOIN dwh.saldos_diarios s ON s.id_cliente = c.id_cliente
WHERE s.periodo >= '2024-10'
  AND c.estado = 'ACTIVO';

SELECT periodo, SUM(saldo) AS monto
FROM dwh.cuentas_mensual
GROUP BY periodo;
