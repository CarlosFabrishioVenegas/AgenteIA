# -*- coding: utf-8 -*-
"""Convierte resultados_qa.json en RESULTADOS_QA.md (tabla + secciones fijas)."""
import json
from pathlib import Path

K = Path(__file__).resolve().parent
R = json.load(open(K / "resultados_qa.json", encoding="utf-8"))
n = {s: sum(1 for x in R if x["status"] == s) for s in ("PASS", "FAIL", "SKIP")}


def esc(s):
    return str(s).replace("|", "\\|").replace("\n", " ")


L = []
L.append("# Resultados QA · VIRF (servidor de prueba :8010)\n")
L.append("Ejecutado el 2026-11-18 con `qa_endpoints.py` (httpx contra http://localhost:8010, usuario libre «QA Sonnet», "
         "modelo `QA_SONNET_<n>` modalidad completa, dominio LaR) y una pasada manual por el navegador integrado. "
         "Ningún check llamó a un LLM de pago (siempre `usar_ia=false`; el resto se omitió).\n")
L.append(f"## Resumen\n\n| PASS | FAIL | SKIP | Total |\n|---|---|---|---|\n| {n['PASS']} | {n['FAIL']} | {n['SKIP']} | {len(R)} |\n")
by = {}
for x in R:
    by.setdefault(x["area"], {"PASS": 0, "FAIL": 0, "SKIP": 0})[x["status"]] += 1
L.append("| Área | PASS | FAIL | SKIP |\n|---|---|---|---|")
for a, v in by.items():
    L.append(f"| {a} | {v['PASS']} | {v['FAIL']} | {v['SKIP']} |")
L.append((K / "_fijo.md").read_text(encoding="utf-8"))
L.append("\n## Tabla de todos los checks\n\n| # | Área | Endpoint / prueba | Entrada | Esperado | Actual | Estado |\n|---|---|---|---|---|---|---|")
for i, x in enumerate(R, 1):
    L.append(f"| {i} | {esc(x['area'])} | {esc(x['endpoint'])} | {esc(x['entrada'])[:60]} | {esc(x['esperado'])[:60]} | {esc(x['actual'])[:110]} | {x['status']} |")
(K / "RESULTADOS_QA.md").write_text("\n".join(L) + "\n", encoding="utf-8")
print("ok", len(L))
