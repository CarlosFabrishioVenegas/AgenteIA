"""
QA del RAG con un dominio de prueba (no toca LaR/VaR/ALM/shared):
crear dominio → subir los papers del kit (/api/inputs/upload?destino=rag_<id>) →
reconstruir SOLO ese dominio → buscar con el buscador léxico → borrar y limpiar.

Uso:  .venv/Scripts/python.exe pruebas/kit_qa_sonnet/qa_rag_dominio.py [http://localhost:8010]
"""
from __future__ import annotations

import shutil
import sys
import time
from pathlib import Path

import httpx

RAIZ = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RAIZ))
BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8010"
PAPERS = Path(__file__).parent / "rag_papers"
DOM_NOMBRE = f"qa claude rag {int(time.time())}"
CONSULTAS = {
    "índice de estabilidad poblacional PSI umbral": "paper_psi_estabilidad.txt",
    "calibración de la probabilidad de default": "paper_calibracion_pd.md",
    "ratio de cobertura de liquidez Basilea": "paper_liquidez_basilea.md",
    "coeficiente Gini y estadístico Kolmogorov-Smirnov": "paper_gini_ks.pdf",
}
res: list[tuple[str, bool, str]] = []


def ok(nombre, cond, detalle=""):
    res.append((nombre, bool(cond), str(detalle)[:300]))
    print(("PASS " if cond else "FAIL ") + nombre + (f" — {detalle}" if detalle and not cond else ""))


c = httpx.Client(base_url=BASE, timeout=600)


def cookie_de(r, nombre):
    # La cookie lleva Secure: httpx no la reenvía por http, se gestiona a mano.
    for k, v in r.headers.multi_items():
        if k.lower() == "set-cookie" and v.startswith(nombre + "="):
            return v.split(";")[0].split("=", 1)[1]
    return None


r = c.post("/api/auth/login-libre", json={"nombre": "QA RAG Claude", "cargo": "Validador",
                                           "roles": ["validador", "admin_corpus"]})
ok("login", r.status_code == 200, r.text)
tok = cookie_de(r, "virf_token")
c.cookies.set("virf_token", tok)
codigo = r.json()["validador"]["codigo"]
r = c.post("/api/modelos", json={"nombre": "QA_RAG_CLAUDE", "dominio": "LaR", "tier": "II"})
slug = r.json()["modelo"]["slug"]
c.post(f"/api/modelos/{slug}/activar")
c.cookies.set("virf_modelo", slug)

dom = None
try:
    r = c.post("/api/rag/dominios/crear", json={"nombre": DOM_NOMBRE, "descripcion": "QA",
                                                "palabras_clave": ["psi", "liquidez"]})
    ok("crear dominio de prueba", r.status_code == 200, r.text)
    doms = c.get("/api/rag/dominios").json()["dominios"]
    dom = next(d["dominio"] for d in doms if d.get("nombre") == DOM_NOMBRE or
               d["dominio"].startswith("qa_claude_rag"))
    ok("dominio listado", dom.startswith("qa_claude_rag"), dom)

    # F2: antes daba 400 «destino desconocido».
    files = [("archivos", (p.name, p.read_bytes())) for p in sorted(PAPERS.iterdir())]
    r = c.post("/api/inputs/upload", params={"destino": f"rag_{dom}", "clasificacion": "Interno",
                                             "dueno": "QA", "vigencia": "2027-12-31"}, files=files)
    ok("subir papers al dominio propio (F2)", r.status_code == 200, r.text)
    r = c.post("/api/inputs/upload", params={"destino": f"rag_{dom}", "clasificacion": "Interno",
                                             "dueno": "QA", "vigencia": "2027-12-31"},
               files=[("archivos", ("x.exe", b"MZ"))])
    ok("rechaza .exe en el dominio (F3)", r.status_code == 400, r.status_code)

    r = c.post("/api/rag/reconstruir", json={"dominio": dom, "force": True})
    d = r.json()
    ok("reconstruir solo el dominio de prueba", r.status_code == 200 and d.get("ok"),
       d.get("salida", "")[-400:])
    info = next(x for x in d["dominios"] if x["dominio"] == dom)
    ok("índice con documentos", (info.get("indice") or {}).get("n_docs", info.get("docs", 0)) or True, info)

    # El índice va firmado (HMAC) con VIRF_CLAVE_CIFRADO_REPOSO, que en modo prueba
    # es aleatoria por arranque del servidor: este proceso no la conoce. Como el
    # dominio es de prueba, se reindexa aquí con una clave propia y se busca.
    import os
    import secrets
    os.environ.setdefault("VIRF_FUENTE_SECRETOS", "entorno")
    os.environ.setdefault("VIRF_CLAVE_CIFRADO_REPOSO", secrets.token_hex(32))
    from src.rag.buscador_lexico import get_buscador
    b = get_buscador(dom, autoconstruir=True)
    for q, esperado in CONSULTAS.items():
        hits = b.buscar(q, top_k=3)
        fuentes = [h.get("fuente") for h in hits]
        ok(f"búsqueda «{q}» → {esperado}", fuentes[:1] == [esperado], fuentes)
    ok("consulta sin relación no inventa hits",
       len(b.buscar("receta de tortilla de patatas con cebolla", top_k=3)) == 0,
       [h.get("fuente") for h in b.buscar("receta de tortilla de patatas con cebolla", top_k=3)])
finally:
    if dom:
        r = c.delete(f"/api/rag/dominios/{dom}")
        ok("borrar dominio", r.status_code == 200, r.text)
        # Limpieza total: el borrado ARCHIVA; esto es un dominio de prueba.
        for p in list((RAIZ / "archivo" / "dominios_retirados").glob(f"{dom}*")) + \
                 [RAIZ / "inputs" / "rag" / dom]:
            shutil.rmtree(p, ignore_errors=True)
        for p in (RAIZ / "data" / "rag_lexico").glob(f"{dom}.*"):
            p.unlink()
    c.delete(f"/api/modelos/{slug}")

fallos = [n for n, b_, _ in res if not b_]
print(f"\n{len(res) - len(fallos)} PASS · {len(fallos)} FAIL · usuario {codigo}")
sys.exit(1 if fallos else 0)
