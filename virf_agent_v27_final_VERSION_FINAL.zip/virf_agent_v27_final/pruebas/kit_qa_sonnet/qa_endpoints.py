# -*- coding: utf-8 -*-
"""Driver QA por HTTP de VIRF (servidor de prueba ya levantado en :8010).

Uso:  .venv/Scripts/python.exe pruebas/kit_qa_sonnet/qa_endpoints.py
Regla: NUNCA llama a un LLM de pago (usar_ia=false o se omite el endpoint).
Escribe resultados_qa.json (datos crudos) junto a este fichero.
"""
from __future__ import annotations

import io
import json
import re
import sys
import time
import traceback
import zipfile
from datetime import date
from pathlib import Path

import httpx

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
BASE = "http://localhost:8010"
KIT = Path(__file__).resolve().parent
PROYECTO = KIT.parents[1]
SUF = str(int(time.time()))[-6:]
NOMBRE_MODELO = f"QA_SONNET_{SUF}"
NOMBRE_MODELO2 = f"QA_SONNET_B_{SUF}"
DOM_TEST_NOMBRE = f"qa_sonnet_dom_{SUF}"

R: list[dict] = []
ESTADO: dict = {}


def reg(area, endpoint, entrada, esperado, actual, status, nota=""):
    R.append({"area": area, "endpoint": endpoint, "entrada": str(entrada)[:140],
              "esperado": str(esperado)[:140], "actual": str(actual)[:220],
              "status": status, "nota": nota})
    marca = {"PASS": "OK  ", "FAIL": "FAIL", "SKIP": "SKIP"}[status]
    print(f"[{marca}] {area} | {endpoint} | {str(actual)[:110]}", flush=True)


def chk(area, endpoint, entrada, esperado, cond, actual, nota=""):
    reg(area, endpoint, entrada, esperado, actual, "PASS" if cond else "FAIL", nota)
    return cond


def skip(area, endpoint, motivo):
    reg(area, endpoint, "-", "-", motivo, "SKIP", motivo)


def seguro(f):
    """Un fallo inesperado del driver se registra como FAIL y no corta la suite."""
    def w(*a, **k):
        try:
            return f(*a, **k)
        except Exception as exc:                                  # noqa: BLE001
            reg("driver", f.__name__, "-", "sin excepción", f"{type(exc).__name__}: {exc}", "FAIL",
                traceback.format_exc()[-400:])
    return w


class Cli:
    """httpx con cookies manuales: virf_token va con `Secure` y httpx no la reenvía por http."""

    def __init__(self):
        self.c = httpx.Client(base_url=BASE, timeout=120)
        self.ck: dict[str, str] = {}

    def _absorber(self, r):
        for sc in r.headers.get_list("set-cookie"):
            par = sc.split(";")[0]
            k, _, v = par.partition("=")
            if "max-age=0" in sc.lower() or v == "" or 'expires=thu, 01 jan 1970' in sc.lower():
                self.ck.pop(k, None)
            else:
                self.ck[k] = v

    def rq(self, m, url, **kw):
        h = kw.pop("headers", {}) or {}
        if self.ck:
            h["Cookie"] = "; ".join(f"{k}={v}" for k, v in self.ck.items())
        r = self.c.request(m, url, headers=h, **kw)
        self._absorber(r)
        return r

    def get(self, u, **k): return self.rq("GET", u, **k)
    def post(self, u, **k): return self.rq("POST", u, **k)
    def delete(self, u, **k): return self.rq("DELETE", u, **k)
    def put(self, u, **k): return self.rq("PUT", u, **k)


def J(r):
    try:
        return r.json()
    except Exception:                                             # noqa: BLE001
        return {}


c = Cli()
anon = Cli()
LOGIN = {"nombre": "QA Sonnet", "cargo": "Validador", "roles": ["validador", "revisor", "admin_corpus"]}

# ───────────────────────── Auth ─────────────────────────
@seguro
def t_auth():
    a = "Auth"
    r = anon.get("/api/auth/modo")
    chk(a, "GET /api/auth/modo", "-", "200 proveedor=libre", r.status_code == 200 and J(r).get("proveedor") == "libre", f"{r.status_code} {r.text[:60]}")
    r = anon.get("/api/auth/actual")
    chk(a, "GET /api/auth/actual (sin cookie)", "-", "401", r.status_code == 401, r.status_code)
    r = c.post("/api/auth/login-libre", json={"nombre": "x"})
    chk(a, "POST /api/auth/login-libre nombre corto", "nombre='x'", "422", r.status_code == 422, r.status_code)
    r = c.post("/api/auth/login-libre", json=LOGIN)
    ok = r.status_code == 200 and "virf_token" in c.ck
    chk(a, "POST /api/auth/login-libre", LOGIN["roles"], "200 + cookie virf_token", ok, f"{r.status_code} cookie={'virf_token' in c.ck}")
    sc = r.headers.get("set-cookie", "")
    reg(a, "Set-Cookie virf_token flags", "-", "HttpOnly; SameSite; (Secure solo con https)", sc[:140],
        "PASS", "OBSERVACIÓN: la cookie lleva `Secure`; un cliente HTTP plano (httpx/requests) no la reenvía en http://localhost. Chrome sí la acepta en localhost." if "Secure" in sc else "")
    r = c.get("/api/auth/actual")
    chk(a, "GET /api/auth/actual", "-", "200 validador", r.status_code == 200 and J(r).get("validador", {}).get("codigo"), f"{r.status_code} {J(r).get('validador', {}).get('codigo')}")
    ESTADO["codigo"] = J(r).get("validador", {}).get("codigo")
    r = c.post("/api/auth/login-libre", json={"nombre": "Otro", "cargo": "x", "roles": ["a", "b", "c", "d"]})
    chk(a, "POST login-libre >3 roles", "4 roles", "422", r.status_code == 422, r.status_code)
    r = c.post("/api/auth/login-libre", json={"nombre": "Otro", "cargo": "x", "roles": ["superadmin"]})
    chk(a, "POST login-libre rol inexistente", "roles=['superadmin']", "rechazado (4xx) o rol ignorado", r.status_code >= 400 or True, f"{r.status_code} {r.text[:100]}",
        "informativo")
    # restaurar identidad principal
    c.ck.clear()
    c.post("/api/auth/login-libre", json=LOGIN)
    skip(a, "POST /api/auth/logout", "el logout ejecuta purgar_vencidos() sobre las raíces de retención GLOBALES (borra ficheros ajenos vencidos)")
    r = anon.get("/api/auth/login", follow_redirects=False)
    reg(a, "GET /api/auth/login (SSO)", "-", "503 claro (SSO no configurado en modo libre) o redirección", f"{r.status_code} {r.text[:60]}", "PASS" if r.status_code in (302, 303, 307, 503) else "FAIL", "modo libre: sin SSO")
    # endpoints protegidos sin sesión
    for u in ("/api/modelos", "/api/rag/dominios", "/api/estandares/estado", "/api/completa/estado", "/api/inputs/arbol",
              "/api/cuestionamientos/default", "/api/cuestionamientos/personalizados", "/api/skills/defaults",
              "/api/motores/catalogo", "/api/prompts/base", "/api/inputs/destinos", "/api/feedback/pendientes"):
        r = anon.get(u)
        chk(a, f"GET {u} sin sesión", "-", "401 (o 200 si es catálogo público)", r.status_code in (401, 400, 200), r.status_code,
            "200 sin login: catálogo expuesto sin autenticar" if r.status_code == 200 else "")
    r = anon.post("/api/cuestionamientos/default/data_leakage_escalado/toggle", json={"activo": True})
    chk(a, "POST /api/cuestionamientos/default/{id}/toggle SIN sesión", "activo=True (idempotente)", "401/403 (escritura global)",
        r.status_code in (401, 403), r.status_code, "SEGURIDAD: escritura global sin autenticación" if r.status_code == 200 else "")


# ───────────────────────── Modelos ─────────────────────────
@seguro
def t_modelos():
    a = "Modelos"
    r = c.get("/api/modelos")
    chk(a, "GET /api/modelos", "-", "200 lista", r.status_code == 200 and "modelos" in J(r), r.status_code)
    r = c.get("/api/rag/dominios")
    doms = [d["id"] for d in J(r).get("dominios", [])]
    ESTADO["dominios"] = doms
    chk(a, "GET /api/rag/dominios (para elegir dominio)", "-", "incluye LaR", "LaR" in doms, doms)
    r = c.post("/api/modelos", json={"nombre": NOMBRE_MODELO + "x", "dominio": "NoExiste", "tier": "II", "modalidad": "completa"})
    chk(a, "POST /api/modelos dominio inválido", "dominio=NoExiste", "400", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/modelos", json={"nombre": NOMBRE_MODELO + "x", "dominio": "LaR", "tier": "II", "modalidad": "rara"})
    chk(a, "POST /api/modelos modalidad inválida", "modalidad=rara", "400", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/modelos", json={"nombre": NOMBRE_MODELO + "x", "dominio": "LaR", "tier": "VII", "modalidad": "completa"})
    chk(a, "POST /api/modelos tier inválido", "tier=VII", "400", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/modelos", json={"nombre": NOMBRE_MODELO, "dominio": "LaR", "tier": "II", "modalidad": "completa"})
    m = J(r).get("modelo", {})
    ok = r.status_code == 200 and m.get("slug")
    chk(a, "POST /api/modelos (completa)", NOMBRE_MODELO, "200 modelo", ok, f"{r.status_code} slug={m.get('slug')} modalidad={m.get('modalidad')}")
    ESTADO["slug"] = m.get("slug")
    r = c.post("/api/modelos", json={"nombre": NOMBRE_MODELO, "dominio": "LaR", "tier": "II", "modalidad": "completa"})
    chk(a, "POST /api/modelos duplicado", NOMBRE_MODELO, "400", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/modelos", json={"nombre": NOMBRE_MODELO2, "dominio": "LaR", "tier": "I", "modalidad": "normal"})
    m2 = J(r).get("modelo", {})
    chk(a, "POST /api/modelos (normal)", NOMBRE_MODELO2, "200", r.status_code == 200, f"{r.status_code} slug={m2.get('slug')}")
    ESTADO["slug2"] = m2.get("slug")
    r = c.get("/api/modelos")
    slugs = [x["slug"] for x in J(r).get("modelos", [])]
    chk(a, "GET /api/modelos contiene los creados", "-", "ambos slugs", ESTADO["slug"] in slugs and ESTADO["slug2"] in slugs, slugs[-4:])
    r = c.post("/api/modelos/NO_EXISTE_QA/activar")
    chk(a, "POST /api/modelos/{slug}/activar inexistente", "-", "404", r.status_code == 404, r.status_code)
    r = c.get("/api/modelos/activo")
    chk(a, "GET /api/modelos/activo (ninguno)", "-", "modelo=None", r.status_code == 200 and J(r).get("modelo") is None, J(r))
    r = c.get("/api/estandares/estado")
    chk(a, "GET /api/estandares/estado sin modelo activo", "-", "400", r.status_code == 400, r.status_code)
    r = c.post(f"/api/modelos/{ESTADO['slug2']}/activar")
    chk(a, "POST /api/modelos/{slug}/activar (normal)", "-", "200 + cookie virf_modelo", r.status_code == 200 and c.ck.get("virf_modelo") == ESTADO["slug2"], r.status_code)
    r = c.get("/api/modelos/activo")
    chk(a, "GET /api/modelos/activo", "-", "slug2", J(r).get("modelo", {}).get("slug") == ESTADO["slug2"], J(r).get("modelo", {}).get("slug"))
    # modalidad normal: iterar debe dar 409
    r = c.post("/api/completa/etapa/00/iteracion", data={"comentario": "x", "usar_ia": "false", "rutas": "a=b"})
    chk(a, "POST /api/completa/etapa/00/iteracion en modalidad normal", "-", "409", r.status_code == 409, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/modelos/desactivar")
    chk(a, "POST /api/modelos/desactivar", "-", "200, cookie borrada", r.status_code == 200 and "virf_modelo" not in c.ck, f"{r.status_code} cookies={list(c.ck)}")
    r = c.post(f"/api/modelos/{ESTADO['slug']}/activar")
    chk(a, "POST /api/modelos/{slug}/activar (completa)", "-", "200", r.status_code == 200 and c.ck.get("virf_modelo") == ESTADO["slug"], r.status_code)
    # borrar el modelo B (normal)
    r = c.delete(f"/api/modelos/{ESTADO['slug2']}")
    chk(a, "DELETE /api/modelos/{slug} (modelo B)", "-", "200", r.status_code == 200, r.status_code)
    r = c.delete(f"/api/modelos/{ESTADO['slug2']}")
    chk(a, "DELETE /api/modelos/{slug} repetido", "-", "404", r.status_code == 404, r.status_code)


@seguro
def t_config_y_lecturas():
    a = "Config/Lecturas"
    r = c.get("/api/config")
    j = J(r)
    chk(a, "GET /api/config", "-", "200 con env y sin secretos en claro", r.status_code == 200 and "env" in j, r.status_code)
    txt = r.text
    chk(a, "GET /api/config no filtra claves", "-", "ninguna 'sk-' ni valor de API_KEY", not re.search(r"sk-[A-Za-z0-9_\-]{10,}", txt), "sin patrón sk-")
    skip(a, "POST /api/config/modelo | /virf_plus | /verificar", "escriben config global o llaman al proveedor IA (de pago)")
    for u in ("/api/prompts/base", "/api/prompts", "/api/prompts/presupuesto", "/api/skills/defaults", "/api/skills",
              "/api/cuestionamientos/default", "/api/cuestionamientos/personalizados", "/api/cuestionamientos-sesion",
              "/api/motores/catalogo", "/api/motores/entidad", "/api/guia/progreso", "/api/resultados/lista",
              "/api/validar/estado", "/api/chat/estado", "/api/informe/estado", "/api/informe/versiones",
              "/api/feedback/pendientes", "/api/inputs/arbol", "/api/automatizaciones/estado", "/api/solo-informe/estado"):
        r = c.get(u)
        chk(a, f"GET {u}", "-", "200", r.status_code == 200, f"{r.status_code} {r.text[:70]}")
    r = c.get("/api/debug/conexiones")
    reg(a, "GET /api/debug/conexiones", "-", "200 o 403 (rol diagnostico)", f"{r.status_code} {r.text[:80]}",
        "PASS" if r.status_code in (200, 403) else "FAIL", "verifica conexiones: podría tocar el proveedor IA; solo se llamó con estado de la respuesta")
    r = c.get("/api/chat/observaciones")
    chk(a, "GET /api/chat/observaciones sin chat", "-", "404", r.status_code == 404, r.status_code)
    r = c.get("/api/salud")
    chk(a, "GET /api/salud", "-", "200 ok", r.status_code == 200 and J(r).get("estado") == "ok", r.text[:60])
    r = c.get("/")
    chk(a, "GET / (SPA)", "-", "200 html", r.status_code == 200 and "<html" in r.text.lower(), r.status_code)
    for st in ("css/styles.css", "js/app.js", "js/completa.js", "js/ui.js", "js/guia.js", "css/ui-sello.css"):
        r = c.get(f"/static/{st}")
        chk(a, f"GET /static/{st}", "-", "200", r.status_code == 200, r.status_code)
    # prompts: editar/restaurar es por sesión (ctx) -> seguro y reversible
    r = c.get("/api/prompts")
    ids = list(J(r).get("prompts", {}).keys())
    if ids:
        pid = ids[0]
        r = c.post("/api/prompts/editar", json={"prompt_id": pid, "contenido": "texto de prueba QA"})
        reg(a, "POST /api/prompts/editar (por sesión)", pid, "200 o 4xx explicado", f"{r.status_code} {r.text[:100]}",
            "PASS" if r.status_code in (200, 400, 403) else "FAIL")
        r2 = c.post("/api/prompts/restaurar", json={"prompt_id": pid})
        chk(a, "POST /api/prompts/restaurar", pid, "200", r2.status_code == 200, f"{r2.status_code} {r2.text[:80]}")
    r = c.post("/api/prompts/restaurar", json={"prompt_id": "no_existe_qa"})
    chk(a, "POST /api/prompts/restaurar id inexistente", "-", "404", r.status_code == 404, r.status_code)
    skip(a, "POST /api/feedback/aprobar, /api/codigo/aprobar", "escriben aprobaciones globales (hash de código / feedback)")
    skip(a, "POST/DELETE /api/cuestionamientos/default|personalizados", "escritura global compartida (sin ctx de sesión); solo se probó lectura y 401 sin sesión")


@seguro
def t_skills_cuest():
    a = "Skills/Cuestionamientos"
    r = c.get("/api/skills")
    j = J(r)
    chk(a, "GET /api/skills", "-", "200 defaults + custom", r.status_code == 200, list(j.keys()))
    defs = j.get("defaults") or j.get("skills") or []
    if defs:
        sid = defs[0].get("id")
        act = defs[0].get("activo", True)
        r = c.post("/api/skills/toggle", json={"skill_id": sid, "activo": not act})
        chk(a, "POST /api/skills/toggle", sid, "200", r.status_code == 200, f"{r.status_code} {r.text[:80]}")
        r = c.post("/api/skills/toggle", json={"skill_id": sid, "activo": act})
        chk(a, "POST /api/skills/toggle (restaurar)", sid, "200", r.status_code == 200, r.status_code)
    r = c.post("/api/skills/toggle", json={"skill_id": "no_existe", "activo": True})
    chk(a, "POST /api/skills/toggle inexistente", "-", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/skills/custom", json={"descripcion": "abc"})
    chk(a, "POST /api/skills/custom descripción corta", "abc", "422", r.status_code == 422, r.status_code)
    r = c.post("/api/skills/custom", json={"descripcion": "Revisar que la calibración cite la tasa de default central"})
    sk = J(r).get("skill", {})
    chk(a, "POST /api/skills/custom", "-", "200 skill.id", r.status_code == 200 and sk.get("id"), f"{r.status_code} {sk.get('id')}")
    if sk.get("id"):
        r = c.delete(f"/api/skills/custom/{sk['id']}")
        chk(a, "DELETE /api/skills/custom/{id}", sk["id"], "200", r.status_code == 200, r.status_code)
    r = c.delete("/api/skills/custom/no_existe")
    chk(a, "DELETE /api/skills/custom inexistente", "-", "404", r.status_code == 404, r.status_code)
    # cuestionamientos de sesión
    r = c.get("/api/cuestionamientos-sesion")
    j = J(r)
    chk(a, "GET /api/cuestionamientos-sesion", "-", "200", r.status_code == 200, list(j.keys()))
    r = c.post("/api/cuestionamientos-sesion/custom", json={"descripcion": "Verificar que no haya fuga de información (data leakage)"})
    it = J(r).get("cuestionamiento", {})
    chk(a, "POST /api/cuestionamientos-sesion/custom", "-", "200 id", r.status_code == 200 and it.get("id"), f"{r.status_code} {it.get('id')}")
    cd = (j.get("defaults") or j.get("cuestionamientos") or [])
    if cd:
        cid = cd[0].get("id")
        act = cd[0].get("activo", True)
        r = c.post("/api/cuestionamientos-sesion/toggle", json={"id": cid, "activo": not act})
        chk(a, "POST /api/cuestionamientos-sesion/toggle", cid, "200", r.status_code == 200, f"{r.status_code} {r.text[:60]}")
        c.post("/api/cuestionamientos-sesion/toggle", json={"id": cid, "activo": act})
    if it.get("id"):
        r = c.delete(f"/api/cuestionamientos-sesion/custom/{it['id']}")
        chk(a, "DELETE /api/cuestionamientos-sesion/custom/{id}", it["id"], "200", r.status_code == 200, r.status_code)
    r = c.delete("/api/cuestionamientos-sesion/custom/no_existe")
    chk(a, "DELETE cuestionamientos-sesion custom inexistente", "-", "404", r.status_code == 404, r.status_code)
    r = c.post("/api/prevuelo")
    chk(a, "POST /api/prevuelo (coste 0)", "-", "200 diagnóstico", r.status_code == 200, f"{r.status_code} {list(J(r).keys())[:6]}")
    r = c.post("/api/validacion/preview-prompt")
    j = J(r)
    chk(a, "POST /api/validacion/preview-prompt (LLM interceptado)", "-", "200 prompt", r.status_code == 200 and j.get("prompt_evaluacion"),
        f"{r.status_code} len_prompt={len(j.get('prompt_evaluacion') or '')}")
    r = c.get("/api/entendimiento")
    chk(a, "GET /api/entendimiento sin análisis", "-", "404", r.status_code == 404, r.status_code)
    skip(a, "POST /api/entendimiento/analizar", "llama al LLM de pago (salvo VIRF_MOCK_CHAT=1, desconocido en el servidor)")
    r = c.post("/api/entendimiento/feedback", json={"comentario": "comentario de prueba QA"})
    reg(a, "POST /api/entendimiento/feedback", "comentario", "200 o 403/400", f"{r.status_code} {r.text[:90]}", "PASS" if r.status_code in (200, 400, 403, 404) else "FAIL")
    skip(a, "POST /api/validar/lanzar", "lanza el pipeline completo que llama al LLM de pago")
    skip(a, "POST /api/chat/iniciar|adjuntar|consolidar (adjuntar llama al LLM)", "adjuntar re-evalúa con el LLM; iniciar/consolidar se prueban solo si hay JSON (ver Documentar)")


# ───────────────────────── Estándares ─────────────────────────
def _up_std(nombre, ruta=None, contenido=None, ctype=None):
    data = contenido if contenido is not None else Path(ruta).read_bytes()
    return c.post("/api/estandares/upload", files={"archivo": (nombre, data, ctype or "application/octet-stream")})


@seguro
def t_estandares():
    a = "Estándares (Paso 02)"
    E = KIT / "estandares"
    r = c.get("/api/estandares/estado")
    chk(a, "GET /api/estandares/estado inicial", "-", "subido/confirmado false", r.status_code == 200 and not J(r).get("confirmado") and not J(r).get("pendiente"), J(r))
    r = c.get("/api/estandares/detalle")
    chk(a, "GET /api/estandares/detalle sin confirmar", "-", "404", r.status_code == 404, r.status_code)
    r = c.get("/api/estandares/vista-previa")
    chk(a, "GET /api/estandares/vista-previa sin nada", "-", "404", r.status_code == 404, r.status_code)
    r = _up_std("x.txt", contenido=b"hola")
    chk(a, "POST /api/estandares/upload .txt", "x.txt", "400", r.status_code == 400, r.status_code)
    r = _up_std("vacio.xlsx", contenido=b"")
    chk(a, "POST /api/estandares/upload vacío", "0 bytes", "400", r.status_code == 400, r.status_code)
    r = _up_std("no_es_estandar.xlsx", E / "no_es_estandar.xlsx")
    chk(a, "POST /api/estandares/upload Excel inválido", "no_es_estandar.xlsx", "400 'Excel inválido'", r.status_code == 400 and "inv" in r.text.lower(), f"{r.status_code} {r.text[:90]}")
    r = c.get("/api/estandares/estado")
    chk(a, "estado tras rechazo: no quedan pendientes", "-", "pendiente=false", not J(r).get("pendiente"), J(r).get("pendiente"))
    r = _up_std("Estandares_VIRF.xlsx", E / "Estandares_VIRF.xlsx")
    j = J(r)
    summ = j.get("summary", {})
    chk(a, "POST /api/estandares/upload (formato real)", "Estandares_VIRF.xlsx", "200, 5 ámbitos y 14 actividades",
        r.status_code == 200 and summ.get("total_ambitos") == 5 and summ.get("total_actividades") == 14,
        f"{r.status_code} ámbitos={summ.get('total_ambitos')} act={summ.get('total_actividades')} avisos={len(j.get('avisos', []))}")
    est = j.get("estandares", [])
    deep = [(e["ambito"], [b["nombre"] for b in e["controles"]]) for e in est]
    chk(a, "merged cells ÁMBITO/CONTROL propagadas", "-", "cada actividad bajo su ámbito/control", all(e["controles"] and all(b["actividades"] for b in e["controles"]) for e in est), deep[:3])
    r = c.get("/api/estandares/estado")
    chk(a, "GET estado con pendiente", "-", "pendiente=true confirmado=false", J(r).get("pendiente") and not J(r).get("confirmado"), f"{J(r).get('pendiente')}/{J(r).get('confirmado')}")
    r = c.get("/api/estandares/vista-previa", params={"pendiente": "true"})
    chk(a, "GET vista-previa?pendiente=true", "-", "200 summary", r.status_code == 200 and J(r).get("summary", {}).get("total_actividades") == 14, r.status_code)
    r = c.post("/api/estandares/confirmar")
    chk(a, "POST /api/estandares/confirmar", "-", "200 confirmado_por", r.status_code == 200 and J(r).get("confirmado"), f"{r.status_code} {J(r).get('confirmado_por')}")
    r = c.get("/api/estandares/estado")
    s1 = J(r)
    chk(a, "estado tras confirmar", "-", "confirmado=true, pendiente=false", s1.get("confirmado") and not s1.get("pendiente"), f"{s1.get('confirmado')}/{s1.get('pendiente')} fichero={s1.get('fichero')}")
    d1 = c.get("/api/estandares/detalle")
    chk(a, "GET detalle", "-", "200 json", d1.status_code == 200, d1.status_code)
    # flujo reemplazar: sube la variante con erratas como PENDIENTE
    r = _up_std("Estandares_VIRF_erratas.xlsx", E / "Estandares_VIRF_erratas.xlsx")
    j = J(r)
    av = j.get("avisos", [])
    chk(a, "upload variante con erratas (tolerante)", "ACTVIDAD / TIER ll / TIER V", "200 y avisos de corrección",
        r.status_code == 200 and len(av) > 0, f"{r.status_code} avisos={av[:3]} tiers={j.get('summary', {}).get('tiers_presentes')} act={j.get('summary', {}).get('total_actividades')}")
    chk(a, "variante erratas: mismas 14 actividades", "-", "14", j.get("summary", {}).get("total_actividades") == 14, j.get("summary", {}).get("total_actividades"))
    r = c.get("/api/estandares/estado")
    s2 = J(r)
    chk(a, "reemplazo pendiente: vigente intacto", "-", "pendiente=true, confirmado=true, fichero original", s2.get("pendiente") and s2.get("confirmado") and s2.get("fichero") == s1.get("fichero"), f"{s2.get('pendiente')}/{s2.get('confirmado')}/{s2.get('fichero')}")
    r = c.delete("/api/estandares/pendiente")
    chk(a, "DELETE /api/estandares/pendiente (Cancelar)", "-", "200", r.status_code == 200, r.status_code)
    r = c.get("/api/estandares/estado")
    s3 = J(r)
    d3 = c.get("/api/estandares/detalle")
    chk(a, "tras cancelar: vigente intacto", "-", "pendiente=false, confirmado=true, detalle idéntico",
        (not s3.get("pendiente")) and s3.get("confirmado") and s3.get("fichero") == s1.get("fichero") and d3.json() == d1.json(), f"{s3.get('pendiente')}/{s3.get('confirmado')}/{s3.get('fichero')}")
    r = c.get("/api/estandares/vista-previa", params={"pendiente": "true"})
    chk(a, "vista-previa pendiente tras cancelar", "-", "404", r.status_code == 404, r.status_code)
    r = c.delete("/api/estandares/pendiente")
    chk(a, "DELETE pendiente sin pendiente (idempotente)", "-", "200", r.status_code == 200, r.status_code)
    # Aceptar un reemplazo
    _up_std("Estandares_VIRF_erratas.xlsx", E / "Estandares_VIRF_erratas.xlsx")
    r = c.post("/api/estandares/confirmar")
    s4 = c.get("/api/estandares/estado").json()
    chk(a, "reemplazar y Aceptar (confirmar)", "-", "200, fichero=erratas, pendiente=false", r.status_code == 200 and s4.get("fichero") == "Estandares_VIRF_erratas.xlsx" and not s4.get("pendiente"), f"{r.status_code} {s4.get('fichero')}")
    r = c.post("/api/estandares/confirmar")
    reg(a, "POST confirmar sin pendiente (doble clic)", "-", "idempotente 200 o 4xx claro", f"{r.status_code} {r.text[:80]}", "PASS" if r.status_code in (200, 400, 404) else "FAIL")
    r = c.delete("/api/estandares")
    s5 = c.get("/api/estandares/estado").json()
    chk(a, "DELETE /api/estandares (Eliminar)", "-", "200, confirmado=false", r.status_code == 200 and not s5.get("confirmado") and not s5.get("subido"), f"{r.status_code} {s5.get('confirmado')}/{s5.get('subido')}")
    r = c.get("/api/estandares/detalle")
    chk(a, "detalle tras eliminar", "-", "404", r.status_code == 404, r.status_code)
    # dejar confirmado el estándar bueno para el resto de la suite
    _up_std("Estandares_VIRF.xlsx", E / "Estandares_VIRF.xlsx"); c.post("/api/estandares/confirmar")
    # Solo informe: el mismo lector, otra ruta
    r = c.post("/api/solo-informe/estandar", files={"archivo": ("Estandares_VIRF_erratas.xlsx", (E / "Estandares_VIRF_erratas.xlsx").read_bytes())})
    chk(a, "POST /api/solo-informe/estandar (erratas)", "-", "200", r.status_code == 200, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/solo-informe/estandar", files={"archivo": ("no_es_estandar.xlsx", (E / "no_es_estandar.xlsx").read_bytes())})
    chk(a, "POST /api/solo-informe/estandar inválido", "-", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/solo-informe/estandar", files={"archivo": ("x.csv", b"a,b")})
    chk(a, "POST /api/solo-informe/estandar .csv", "-", "400", r.status_code == 400, r.status_code)


# ───────────────────────── Evidencia (paso 03) ─────────────────────────
EJEMPLO = {
    ".pdf": KIT / "manuales" / "Manual_Seguimiento_MCR_CC.pdf",
    ".docx": KIT / "manuales" / "Manual_Metodologico_MCR_CC.docx",
    ".md": KIT / "manuales" / "Manual_Extraccion_Controles_Datos.md",
    ".txt": KIT / "rag_papers" / "paper_psi_estabilidad.txt",
    ".xlsx": KIT / "primera_linea" / "01_ControlDatos.xlsx",
    ".xlsm": KIT / "primera_linea" / "01_ControlDatos.xlsx",
    ".xls": KIT / "primera_linea" / "01_ControlDatos.xlsx",
    ".csv": KIT / "datos" / "clientes.csv",
    ".json": None, ".parquet": None,
    ".png": KIT / "imagenes" / "captura_1.png", ".jpg": KIT / "imagenes" / "captura_1.png", ".jpeg": KIT / "imagenes" / "captura_1.png",
    ".svg": None,
}


@seguro
def t_evidencia():
    a = "Evidencia (Paso 03)"
    r = c.get("/api/inputs/destinos")
    dests = J(r).get("destinos", [])
    chk(a, "GET /api/inputs/destinos", "-", "lista no vacía", r.status_code == 200 and len(dests) > 5, f"{len(dests)} destinos: {[d['slug'] for d in dests]}")
    ses = [d for d in dests if d["alcance"] == "sesion"]
    glob = [d for d in dests if d["alcance"] == "global"]
    ESTADO["destinos"] = ses
    base = "/api/inputs/upload"
    f0 = KIT / "manuales" / "Manual_Extraccion_Controles_Datos.md"
    # validaciones de clasificación (SEG-06)
    r = c.post(base, params={"destino": "doc_modelamiento"}, files={"archivos": ("a.md", b"x")})
    chk(a, "upload sin clasificacion", "-", "422/400", r.status_code in (400, 422), r.status_code)
    r = c.post(base, params={"destino": "doc_modelamiento", "clasificacion": "Secreto"}, files={"archivos": ("a.md", b"x")})
    chk(a, "upload clasificacion inválida", "Secreto", "400", r.status_code == 400, r.status_code)
    r = c.post(base, params={"destino": "doc_modelamiento", "clasificacion": "Restringido"}, files={"archivos": ("a.md", b"x")})
    chk(a, "upload Restringido en este equipo", "Restringido", "403", r.status_code == 403, r.status_code)
    r = c.post(base, params={"destino": "no_existe", "clasificacion": "Interno"}, files={"archivos": ("a.md", b"x")})
    chk(a, "upload destino desconocido", "-", "400", r.status_code == 400, r.status_code)
    r = c.post(base, params={"destino": "doc_modelamiento", "clasificacion": "Interno"}, files={"archivos": ("..\\..\\evil.md", b"x")})
    reg(a, "upload nombre con ..\\..", "..\\..\\evil.md", "nombre saneado a evil.md (sin escapar)", f"{r.status_code} {J(r).get('guardados')}", "PASS" if r.status_code in (200, 400, 403) and "evil" in str(J(r).get("guardados", "evil")) else "FAIL")
    if r.status_code == 200:
        c.delete("/api/inputs/archivo/doc_modelamiento/evil.md")
    r = c.post(base, params={"destino": "doc_modelamiento", "clasificacion": "Interno"}, files={"archivos": ("m.zip", b"PK")})
    chk(a, "upload .zip por /upload", "-", "400 usar upload-zip", r.status_code == 400, r.status_code)
    r = c.post(base, params={"destino": "doc_modelamiento", "clasificacion": "Interno"}, files={"archivos": ("config" + ".py", b"x=1")})
    reg(a, "upload nombre en NOMBRES_PROHIBIDOS (si aplica)", "config" + ".py", "no 500", r.status_code, "PASS" if r.status_code < 500 else "FAIL")
    # recorrer todas las cards de sesión
    subidos = []
    for d in ses:
        slug = d["slug"]
        if d["solo_zip"]:
            r = c.post(base, params={"destino": slug, "clasificacion": "Interno"}, files={"archivos": ("a.md", b"x")})
            chk(a, f"upload {slug} (solo_zip) con fichero suelto", "a.md", "400", r.status_code == 400, r.status_code)
            zb = (KIT / "scripts" / "codigo_modelo.zip").read_bytes()
            r = c.post("/api/inputs/upload-zip", params={"destino": slug, "clasificacion": "Interno"}, files={"archivo": ("codigo_modelo.zip", zb)})
            j = J(r)
            chk(a, f"upload-zip {slug}", "codigo_modelo.zip", "200 con subcarpetas src/", r.status_code == 200 and any("src/" in e.get("ruta", "") for e in j.get("escritos", [])), f"{r.status_code} n={j.get('n_miembros')} {[e['ruta'] for e in j.get('escritos', [])][:3]}")
            continue
        fmts = d["formatos"]
        elegido = next((f for f in fmts if EJEMPLO.get(f)), None)
        if not elegido:
            skip(a, f"upload {slug}", f"sin fichero de ejemplo para {fmts}")
            continue
        src = EJEMPLO[elegido]
        nombre = f"qa_{slug}{elegido}"
        r = c.post(base, params={"destino": slug, "clasificacion": "Interno"}, files={"archivos": (nombre, src.read_bytes())})
        j = J(r)
        ok = r.status_code == 200 and j.get("guardados")
        chk(a, f"upload a card {slug}", f"{nombre} ({elegido})", "200 guardado", ok, f"{r.status_code} {r.text[:100]}")
        if ok:
            subidos.append((slug, nombre))
            # un formato NO admitido por la card: el servidor lo acepta igual? (informativo)
        rr = c.get(f"/api/inputs/carpeta/{slug}")
        chk(a, f"GET carpeta/{slug} lista el fichero", "-", nombre, ok and any(f["nombre"] == nombre for f in J(rr).get("ficheros", [])), [f["nombre"] for f in J(rr).get("ficheros", [])][:4])
    # formato fuera de lo declarado por la card
    if ses:
        d0 = next(d for d in ses if d["slug"] == "doc_modelamiento")
        r = c.post(base, params={"destino": "doc_modelamiento", "clasificacion": "Interno"}, files={"archivos": ("macro.exe", b"MZ")})
        reg(a, "upload formato no declarado (.exe) a doc_modelamiento", "macro.exe", "400/403 (idealmente) — hoy ¿lo acepta?", f"{r.status_code} {r.text[:80]}",
            "PASS" if r.status_code in (400, 403, 415) else "FAIL",
            "El servidor no valida la extensión contra `formatos` de la card (solo el <input accept> del navegador)" if r.status_code == 200 else "")
        if r.status_code == 200:
            c.delete("/api/inputs/archivo/doc_modelamiento/macro.exe")
    r = c.get("/api/inputs/arbol")
    arbol = J(r)

    def archivos(n):
        return [n["ruta"]] if n.get("tipo") == "archivo" else [x for h in n.get("hijos", []) for x in archivos(h)]

    lst = archivos(arbol)
    chk(a, "GET /api/inputs/arbol", "-", "árbol con lo subido", r.status_code == 200 and len(lst) >= len(subidos), f"{len(lst)} archivos en árbol")
    # borrar un fichero
    if subidos:
        slug, nombre = subidos[0]
        r = c.delete(f"/api/inputs/archivo/{slug}/{nombre}")
        chk(a, "DELETE /api/inputs/archivo/{slug}/{fichero}", f"{slug}/{nombre}", "200", r.status_code == 200, r.status_code)
        r = c.delete(f"/api/inputs/archivo/{slug}/{nombre}")
        chk(a, "DELETE archivo ya borrado", "-", "404", r.status_code == 404, r.status_code)
        r = c.delete(f"/api/inputs/archivo/{slug}/..%2F..%2Fx.md")
        chk(a, "DELETE archivo con ../", "-", "400/404", r.status_code in (400, 404, 405), r.status_code)
    # zip malicioso
    bad = io.BytesIO()
    with zipfile.ZipFile(bad, "w") as z:
        z.writestr("../../escape.txt", "x")
    r = c.post("/api/inputs/upload-zip", params={"destino": "implementacion", "clasificacion": "Interno"}, files={"archivo": ("bad.zip", bad.getvalue())})
    chk(a, "upload-zip zip-slip (../../escape.txt)", "-", "400", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/inputs/upload-zip", params={"destino": "implementacion", "clasificacion": "Interno"}, files={"archivo": ("no.zip", b"no es zip")})
    chk(a, "upload-zip no-zip", "-", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/inputs/upload-zip", params={"destino": "implementacion"}, files={"archivo": ("codigo_modelo.zip", (KIT / "scripts" / "codigo_modelo.zip").read_bytes())})
    chk(a, "upload-zip sin clasificacion", "-", "422/400", r.status_code in (400, 422), r.status_code)
    # globales (RAG compartido) -> NO se tocan
    skip(a, f"upload a destinos globales {[d['slug'] for d in glob]}", "escribirían en el corpus RAG compartido; solo se prueba con dominio qa_sonnet_ (ver RAG)")


# ───────────────────────── Validación completa ─────────────────────────
RUTAS_TXT = (f"clientes = {KIT / 'datos' / 'clientes.csv'}\n"
             f"saldos = {KIT / 'datos' / 'saldos.csv'}\n"
             r"contabilidad = \\srv-datos01\modelos\cc\gl_cc.xlsx" "\n")
IMG = [KIT / "imagenes" / "captura_1.png", KIT / "imagenes" / "captura_2.png"]


def _iter(cod, comentario="", rutas=None, archivos=None, usar_ia="false"):
    data = {"comentario": comentario, "usar_ia": usar_ia}
    if rutas is not None:
        data["rutas"] = rutas
    files = [("archivos", (n, b, "application/octet-stream")) for n, b in (archivos or [])]
    return c.post(f"/api/completa/etapa/{cod}/iteracion", data=data, files=files or None)


@seguro
def t_completa():
    a = "Validación completa"
    r = c.get("/api/completa/estado")
    j = J(r)
    chk(a, "GET /api/completa/estado", "-", "modalidad=completa, 5 etapas", r.status_code == 200 and j.get("modalidad") == "completa" and len(j.get("etapas", [])) == 5, f"{r.status_code} modalidad={j.get('modalidad')} etapas={len(j.get('etapas', []))} lista={j.get('lista_para_validar')}")
    r = c.post("/api/completa/modalidad", json={"modalidad": "normal"})
    chk(a, "POST /api/completa/modalidad normal", "-", "200 modalidad=normal", r.status_code == 200 and J(r).get("modelo", {}).get("modalidad") == "normal", f"{r.status_code}")
    r = _iter("00", "x", RUTAS_TXT)
    chk(a, "iteración con modalidad normal", "-", "409", r.status_code == 409, r.status_code)
    r = c.post("/api/completa/modalidad", json={"modalidad": "rara"})
    chk(a, "POST modalidad inválida", "rara", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/completa/modalidad", json={"modalidad": "completa"})
    chk(a, "POST /api/completa/modalidad completa", "-", "200", r.status_code == 200 and J(r).get("modelo", {}).get("modalidad") == "completa", r.status_code)
    r = c.get("/api/completa/etapa/99")
    chk(a, "GET etapa desconocida", "99", "404", r.status_code == 404, r.status_code)
    for cod in ("00", "01", "02", "03", "04"):
        r = c.get(f"/api/completa/etapa/{cod}")
        chk(a, f"GET /api/completa/etapa/{cod}", "-", "200 sin iteraciones", r.status_code == 200 and not J(r).get("iteraciones"), f"{r.status_code} keys={list(J(r).keys())[:6]}")

    # Insumos
    M, PL, SC = KIT / "manuales", KIT / "primera_linea", KIT / "scripts"
    plan = [("manual", M / "Manual_Metodologico_MCR_CC.docx"), ("manual", M / "Manual_Metodologico_MCR_CC.md"),
            ("manual", M / "Manual_Seguimiento_MCR_CC.pdf"), ("manual", M / "Manual_Seguimiento_MCR_CC.md"),
            ("manual", M / "Manual_Extraccion_Controles_Datos.md"),
            ("excel_primera_linea", PL / "00_Diagnostico.xlsx"), ("excel_primera_linea", PL / "01_ControlDatos.xlsx"),
            ("excel_primera_linea", PL / "02_Modelamiento.xlsx"), ("excel_primera_linea", PL / "03_Impactos.xlsx"),
            ("excel_primera_linea", PL / "Resultado_notebook_primera_linea.xlsx"),
            ("script", SC / "etl_modelo_cc.py"), ("script", SC / "extraccion.sql"), ("script", SC / "calibracion.ipynb"),
            ("script", SC / "codigo_modelo.zip"), ("otro", KIT / "datos" / "clientes.csv")]
    for cat, p in plan:
        r = c.post("/api/completa/insumos/subir", data={"categoria": cat}, files=[("archivos", (p.name, p.read_bytes()))])
        chk(a, f"POST insumos/subir [{cat}]", p.name, "200 guardado", r.status_code == 200 and f"{cat}/{p.name}" in J(r).get("guardados", []), f"{r.status_code} {str(J(r).get('guardados') or r.text)[:80]}")
    r = c.post("/api/completa/insumos/subir", data={"categoria": "inventada"}, files=[("archivos", ("a.md", b"x"))])
    chk(a, "insumos/subir categoría inválida", "-", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/completa/insumos/subir", data={"categoria": "manual"}, files=[("archivos", ("a.exe", b"MZ"))])
    chk(a, "insumos/subir formato no admitido", ".exe", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/completa/insumos/subir", data={"categoria": "manual"}, files=[("archivos", ("vacio.md", b""))])
    chk(a, "insumos/subir archivo vacío", "-", "400", r.status_code == 400, r.status_code)
    r = c.get("/api/completa/insumos")
    j = J(r)
    chk(a, "GET /api/completa/insumos", "-", f"{len(plan)} insumos", r.status_code == 200 and j.get("total", 0) >= len(plan), f"total={j.get('total')} estudiados={j.get('estudiados')}")
    t0 = time.time()
    r = c.post("/api/completa/insumos/estudiar", json={"usar_ia": False})
    j = J(r)
    chk(a, "POST insumos/estudiar usar_ia=false", "-", "200, todos estudiados", r.status_code == 200 and j.get("estudiados") == j.get("total") and j.get("total", 0) > 0, f"{r.status_code} {j.get('estudiados')}/{j.get('total')} {time.time()-t0:.1f}s")
    ESTADO["insumos_json"] = j
    rutas_enc = j.get("rutas_encontradas", [])
    chk(a, "estudio detecta rutas Windows/UNC del script", "-", "incluye C:\\Users… y \\\\srv-datos01…", any("srv-datos01" in x for x in rutas_enc) and any("Users" in x for x in rutas_enc), rutas_enc[:6])
    fichas = j.get("insumos", [])
    ET = [f for f in fichas if f["nombre"].endswith("extraccion.sql") or "extraccion.sql" in f.get("nombre", "")]
    reg(a, "estudio: ficha .sql detecta tablas dwh.*", "-", "tablas dwh.clientes/dwh.saldos_diarios", json.dumps(ET[0], ensure_ascii=False)[:200] if ET else "sin ficha", "PASS" if ET and "dwh" in json.dumps(ET[0]) else "FAIL")
    zf = [f for f in fichas if f["nombre"].endswith(".zip") or "codigo_modelo" in f.get("nombre", "")]
    reg(a, "estudio: ZIP con código en subcarpetas", "-", "ficha(s) del zip estudiada(s)", f"{len(zf)} fichas con 'codigo_modelo'", "PASS" if zf else "FAIL")
    r = c.post("/api/completa/insumos/estudiar", json={"usar_ia": False})
    chk(a, "insumos/estudiar repetido (caché)", "-", "200 idempotente", r.status_code == 200, r.status_code)
    # borrar insumo propio
    r = c.post("/api/completa/insumos/subir", data={"categoria": "otro"}, files=[("archivos", ("borrar_me.md", b"# x"))])
    r = c.delete("/api/completa/insumos/archivo", params={"ruta": "otro/borrar_me.md"})
    chk(a, "DELETE insumos/archivo", "otro/borrar_me.md", "200", r.status_code == 200, r.status_code)
    r = c.delete("/api/completa/insumos/archivo", params={"ruta": "otro/borrar_me.md"})
    chk(a, "DELETE insumos/archivo repetido", "-", "404", r.status_code == 404, r.status_code)
    r = c.delete("/api/completa/insumos/archivo", params={"ruta": "../../../estandares/estandares_validacion.xlsx"})
    chk(a, "DELETE insumos/archivo con path traversal", "../../…", "400", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.get("/api/estandares/estado")
    chk(a, "traversal no tocó el estándar", "-", "estándar sigue confirmado", J(r).get("confirmado"), J(r).get("confirmado"))

    # Etapas: ITER0 + ITER1 en cada una
    ETAPA_NB = {}
    iter_it0 = {"00": "Mapea las bases clientes y saldos del producto.",
                "01": "Revisa el control de datos de las bases mapeadas.",
                "02": "Replica el modelamiento paso a paso.",
                "03": "Cuantifica el impacto de los saldos negativos.",
                "04": "Replica el seguimiento PSI/KS/Gini."}
    for cod in ("00", "01", "02", "03", "04"):
        # ITER0 con rutas + imágenes
        r = _iter(cod, iter_it0[cod], RUTAS_TXT, [(p.name, p.read_bytes()) for p in IMG])
        j = J(r)
        it = j.get("iteracion", {})
        ok = r.status_code == 200 and it.get("n") == 0 and it.get("ipynb")
        chk(a, f"[{cod}] ITER0 rutas+2 imágenes (usar_ia=false)", "rutas + captura_1/2.png", "200 ITER0 ipynb+md", ok,
            f"{r.status_code} {str(it.get('ipynb'))} modo={it.get('modo')} imgs={it.get('imagenes')} {r.text[:100] if not ok else ''}")
        if not ok:
            continue
        chk(a, f"[{cod}] ITER0 reporta rutas y 2 imágenes", "-", "imagenes=2", len(it.get("imagenes", [])) == 2, it.get("imagenes"))
        # descargas
        for ext in (".ipynb", ".md"):
            nombre = it["ipynb"] if ext == ".ipynb" else it["md"]
            rr = c.get(f"/api/completa/etapa/{cod}/descargar/{nombre}")
            chk(a, f"[{cod}] GET descargar {nombre}", "-", "200", rr.status_code == 200 and len(rr.content) > 50, f"{rr.status_code} {len(rr.content)}B ct={rr.headers.get('content-type')}")
            if ext == ".ipynb" and rr.status_code == 200:
                try:
                    nb = json.loads(rr.content)
                    import nbformat
                    nbformat.validate(nbformat.from_dict(nb))
                    good = nb.get("nbformat") == 4 and len(nb.get("cells", [])) > 2
                    chk(a, f"[{cod}] ipynb JSON válido nbformat 4 (validate)", "-", "nbformat.validate OK", good, f"{len(nb['cells'])} celdas")
                    ETAPA_NB[cod] = rr.content
                except Exception as exc:                          # noqa: BLE001
                    chk(a, f"[{cod}] ipynb JSON válido nbformat 4", "-", "válido", False, f"{type(exc).__name__}: {str(exc)[:150]}")
                (KIT / "descargas").mkdir(exist_ok=True)
                (KIT / "descargas" / nombre).write_bytes(rr.content)
            elif ext == ".md" and rr.status_code == 200:
                chk(a, f"[{cod}] .md con contenido de revisión", "-", "texto con ITER0", "ITER0" in rr.text or "Iter" in rr.text, rr.text[:60].replace("\n", " "))
        # imagen
        rr = c.get(f"/api/completa/etapa/{cod}/imagen/0/captura_1.png")
        chk(a, f"[{cod}] GET imagen ITER0/captura_1.png", "-", "200 image/png", rr.status_code == 200 and rr.headers.get("content-type", "").startswith("image/png"), f"{rr.status_code} {rr.headers.get('content-type')}")
        # ITER1 con resultado
        ex = PL / f"ITER1_resultado_{cod}.xlsx"
        r = _iter(cod, "Aquí el resultado del notebook: hay No cumple en la primera línea.", None, [(ex.name, ex.read_bytes())])
        j = J(r)
        it1 = j.get("iteracion", {})
        chk(a, f"[{cod}] ITER1 devuelve Excel resultado + comentario", ex.name, "200 ITER1", r.status_code == 200 and it1.get("n") == 1, f"{r.status_code} n={it1.get('n')} veredicto={json.dumps(it1.get('veredicto'), ensure_ascii=False)[:80]} {r.text[:100] if r.status_code != 200 else ''}")
        rr = c.get(f"/api/completa/etapa/{cod}")
        e = J(rr)
        chk(a, f"[{cod}] etapa tiene 2 iteraciones y mensajes", "-", "iteraciones=2", len(e.get("iteraciones", [])) == 2, f"it={len(e.get('iteraciones', []))} msgs={len(e.get('mensajes', []))}")
        # ITER2 sin archivos ni rutas (reutiliza)
        if cod in ("00", "01"):
            r = _iter(cod, "Una vuelta más sin archivos.", None, None)
            chk(a, f"[{cod}] ITER2 solo comentario (reusa rutas)", "-", "200", r.status_code == 200, f"{r.status_code} {r.text[:80] if r.status_code != 200 else ''}")
    # casos de borde de iteración
    r = _iter("00", "x", None, [("a.exe", b"MZ")])
    chk(a, "iteración con formato no admitido", ".exe", "400", r.status_code == 400, r.status_code)
    r = _iter("00", "x", None, [("../../evil.md", b"hola")])
    reg(a, "iteración nombre con ../", "../../evil.md", "saneado (200) o 400, nunca fuera de la carpeta", r.status_code, "PASS" if r.status_code in (200, 400) else "FAIL")
    ESTADO["nbs"] = ETAPA_NB
    # etapa 02 y 03, 04 con rutas distintas / 'rutas' malformadas
    r = _iter("03", "rutas raras", "esto no es ruta\n=\n   \n# comentario\nx = ", None)
    reg(a, "iteración con rutas malformadas", "-", "no 500", f"{r.status_code} {r.text[:80]}", "PASS" if r.status_code < 500 else "FAIL")
    # imagen: traversal
    r = c.get("/api/completa/etapa/00/imagen/0/..%2F..%2Fsecret.png")
    chk(a, "imagen con traversal", "-", "400/404", r.status_code in (400, 404), r.status_code)
    r = c.get("/api/completa/etapa/00/imagen/0/captura_1.exe")
    chk(a, "imagen extensión no imagen", "-", "400", r.status_code == 400, r.status_code)
    r = c.get("/api/completa/etapa/00/imagen/9/captura_1.png")
    chk(a, "imagen de iteración inexistente", "-", "404", r.status_code == 404, r.status_code)
    r = c.get("/api/completa/etapa/00/descargar/..%2F..%2Fx.md")
    chk(a, "descargar con traversal", "-", "400/404", r.status_code in (400, 404), r.status_code)
    r = c.get("/api/completa/etapa/00/descargar/00_DiagnosticoITER0.json")
    chk(a, "descargar .json (no permitido)", "-", "400", r.status_code == 400, r.status_code)
    r = c.get("/api/completa/etapa/00/descargar/noexiste.md")
    chk(a, "descargar inexistente", "-", "404", r.status_code == 404, r.status_code)

    # Cierre
    r = c.post("/api/completa/etapa/00/cerrar", json={"motivo": ""})
    reg(a, "cerrar sin motivo", "motivo=''", "200 o 400 claro", f"{r.status_code} {r.text[:80]}", "PASS" if r.status_code in (200, 400) else "FAIL")
    for cod in ("00", "01", "02", "03", "04"):
        r = c.post(f"/api/completa/etapa/{cod}/cerrar", json={"motivo": "Cumplida: QA automático"})
        j = J(r)
        chk(a, f"[{cod}] POST cerrar", "motivo", "200 cierre", r.status_code == 200 and j.get("cierre"), f"{r.status_code} {str(j.get('cierre'))[:80]} {r.text[:80] if r.status_code != 200 else ''}")
    r = c.get("/api/completa/estado")
    j = J(r)
    chk(a, "estado.lista_para_validar tras cerrar 00–04", "-", "true", j.get("lista_para_validar") is True, f"lista={j.get('lista_para_validar')} cerradas={j.get('cerradas')}/{j.get('total')}")
    r = c.post("/api/completa/etapa/02/cerrar", json={"reabrir": True})
    j = J(r)
    r2 = c.get("/api/completa/estado")
    chk(a, "reabrir etapa 02", "reabrir=true", "200 y lista_para_validar=false", r.status_code == 200 and J(r2).get("lista_para_validar") is False, f"{r.status_code} lista={J(r2).get('lista_para_validar')}")
    r = c.post("/api/completa/etapa/99/cerrar", json={})
    chk(a, "cerrar etapa desconocida", "99", "404", r.status_code == 404, r.status_code)
    r = c.post("/api/completa/etapa/02/cerrar", json={"motivo": "Cumplida: QA automático"})
    r = c.get("/api/completa/estado")
    chk(a, "re-cerrar 02", "-", "lista_para_validar=true", J(r).get("lista_para_validar") is True, J(r).get("lista_para_validar"))
    # iteración nueva reabre
    r = _iter("04", "otra más", None, None)
    r2 = c.get("/api/completa/estado")
    chk(a, "nueva iteración reabre la etapa (cierre=None)", "-", "lista_para_validar=false", J(r2).get("lista_para_validar") is False, J(r2).get("lista_para_validar"))
    c.post("/api/completa/etapa/04/cerrar", json={"motivo": "Cumplida: QA automático"})


# ───────────────────────── Ejecutar notebooks ─────────────────────────
@seguro
def t_notebooks():
    a = "Notebooks (ejecución)"
    import os
    import subprocess
    import tempfile
    nbs = ESTADO.get("nbs", {})
    for cod in ("00", "01", "02", "03", "04"):
        if cod not in nbs:
            skip(a, f"ejecutar notebook {cod}", "no se descargó")
            continue
        nb = json.loads(nbs[cod])
        work = Path(tempfile.mkdtemp(prefix=f"qa_nb{cod}_"))
        codigo = []
        for celda in nb["cells"]:
            if celda["cell_type"] == "code":
                src = "".join(celda["source"]) if isinstance(celda["source"], list) else celda["source"]
                # elimina magics de Jupyter para ejecutarlo como script
                src = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith(("%", "!")))
                codigo.append(src)
        script = work / "run_nb.py"
        # un solo namespace: todas las celdas en el mismo script (como un kernel)
        cuerpo = "\n\n# ---- celda ----\n".join(codigo)
        script.write_text(cuerpo, encoding="utf-8")
        env = {**os.environ, "PYTHONIOENCODING": "utf-8", "MPLBACKEND": "Agg"}
        py = str(PROYECTO / ".venv" / "Scripts" / "python.exe")
        p = subprocess.run([py, "-I", str(script)], cwd=str(work), capture_output=True, text=True, timeout=300, env=env, encoding="utf-8", errors="replace")
        xl = [x for x in work.rglob("*.xlsx")]
        # el notebook puede escribir fuera de cwd: busca por nombre esperado cerca de RUTAS/ salida
        extra = []
        for m in re.finditer(r"""['"]([^'"\n]+\.xlsx)['"]""", cuerpo):
            q = Path(m.group(1))
            if q.is_file():
                extra.append(q)
        ok = p.returncode == 0
        chk(a, f"ejecutar notebook {cod} (exec en un namespace, venv)", f"{len(codigo)} celdas de código", "exit 0", ok,
            f"exit={p.returncode} cwd={work} {(p.stderr or '')[-300:].replace(chr(10), ' | ')}")
        chk(a, f"notebook {cod} produce Excel de resultado", "-", "≥1 .xlsx", bool(xl or extra), [str(x) for x in (xl + extra)][:3],
            (p.stdout or "")[-300:].replace("\n", " | "))
        if xl or extra:
            from openpyxl import load_workbook
            f = (xl + extra)[0]
            wb = load_workbook(f)
            hojas = wb.sheetnames
            filas = {h: wb[h].max_row for h in hojas}
            chk(a, f"notebook {cod}: Excel con hojas y filas", f.name, "hojas con datos", any(v > 1 for v in filas.values()), f"{hojas} {filas}")
            hoja_etapa = {"00": "Mapeo", "01": "Controles", "02": "Replica", "03": "Impactos", "04": "Seguimiento"}[cod]
            if hoja_etapa in wb.sheetnames:
                ws = wb[hoja_etapa]
                chk(a, f"notebook {cod}: hoja «{hoja_etapa}» con datos (no solo cabecera)", f.name, "≥2 filas", ws.max_row >= 2, f"filas={ws.max_row} cabecera={[x.value for x in ws[1]][:6]}")
            else:
                reg(a, f"notebook {cod}: hoja «{hoja_etapa}»", f.name, "existe", f"hojas={wb.sheetnames}", "FAIL")
            if cod in ("00", "01"):
                filas_x = [[x for x in row] for row in wb[hoja_etapa].iter_rows(values_only=True)]
                txt = json.dumps(filas_x, ensure_ascii=False)
                ok_llave = ("id_cliente" in txt and cod == "01" and any(("id_cliente" in str(r[0]) or "llave" in " ".join(map(str, r)).lower()) and (r[2] or 0) > 0 for r in filas_x[1:] if len(r) > 2)) if cod == "01" else None
                if cod == "01":
                    chk(a, "notebook 01 (plantilla sin IA) detecta DUPLICADOS DE LLAVE id_cliente (2 ids repetidos sembrados)", "clientes.csv con id repetido", "control de unicidad de llave con afectados>0", ok_llave,
                        f"filas={[r[:4] for r in filas_x[:6]]}", "La misión de 01 dice «unicidad»; la plantilla solo cuenta filas duplicadas COMPLETAS (0) y no la llave; tampoco hay integridad referencial saldos->clientes ni columna 'resultado'")
            ESTADO[f"xl_{cod}"] = str(f)


# ───────────────────────── Documentar ─────────────────────────
@seguro
def t_documentar():
    a = "Documentar"
    r = c.get("/api/automatizaciones/estado")
    j = J(r)
    enc = {e["codigo"]: e["archivo"] for e in j.get("etapas", [])}
    chk(a, "GET /api/automatizaciones/estado (completa: vigentes de cada etapa)", "-", "etapas 00–03 con archivo", r.status_code == 200 and all(enc.get(k) for k in ("00", "01", "02", "03")), enc)
    r = c.post("/api/automatizaciones/cuadro", json={"usar_ia": False})
    j = J(r)
    chk(a, "POST /api/automatizaciones/cuadro usar_ia=false", "-", "200 con filas y _xlsx", r.status_code == 200 and j.get("_xlsx"), f"{r.status_code} filas={len(j.get('filas', []))} {r.text[:100] if r.status_code != 200 else ''}")
    if j.get("_xlsx"):
        r = c.get(f"/api/automatizaciones/descargar/{j['_xlsx']}")
        chk(a, "GET automatizaciones/descargar cuadro .xlsx", j["_xlsx"], "200 xlsx", r.status_code == 200 and r.content[:2] == b"PK", f"{r.status_code} {len(r.content)}B")
        filas = j.get("filas", [])
        niveles = {str(f.get("riesgo") or f.get("nivel")) for f in filas}
        reg(a, "cuadro: filas con riesgo/responsable", "-", "filas con riesgo", f"{len(filas)} filas, riesgos={niveles}", "PASS" if filas else "FAIL")
    r = c.get("/api/automatizaciones/descargar/..%2Fx.xlsx")
    chk(a, "automatizaciones/descargar traversal", "-", "400/404", r.status_code in (400, 404), r.status_code)
    r = c.get("/api/automatizaciones/descargar/a.txt")
    chk(a, "automatizaciones/descargar no-xlsx", "-", "400", r.status_code == 400, r.status_code)
    r = c.get("/api/automatizaciones/estado")
    chk(a, "estado.ultimo tras generar", "-", "ultimo no nulo", J(r).get("ultimo"), bool(J(r).get("ultimo")))

    # Informe consolidado: requiere un resultados_*.json de corrida; el pipeline real llama al LLM, así que se siembra uno sintético
    slug = ESTADO["slug"]
    cod = ESTADO["codigo"]
    out = PROYECTO / "web" / "data" / "sesiones" / cod / slug / "outputs" / str(date.today())
    out.mkdir(parents=True, exist_ok=True)
    datos = {"modelo": NOMBRE_MODELO, "tier": "II", "fecha": str(date.today()), "agente": {"dominio_rag": "LaR", "nombre": "sintetico-QA"}, "score_global": 3.2,
             "semaforo": {"label": "Ámbar", "color": "amarillo"}, "scores_por_ambito": {"Documentación": 3.5, "Datos": 2.5},
             "resultados_por_ambito": {
                 "Documentación": [{"actividad": "Existe manual metodológico versionado", "control": "Manual metodológico", "puntaje": 4, "concepto": "Cumple", "observacion": "Manual v3.2 con secciones 1–7.", "evidencia_encontrada": "Manual_Metodologico_MCR_CC §1–7", "recomendacion": "Mantener versionado."}],
                 "Datos": [{"actividad": "Se controla unicidad de llaves", "control": "Calidad de datos", "puntaje": 1, "concepto": "No cumple", "observacion": "Hay id_cliente duplicados (2 registros).", "evidencia_encontrada": "clientes.csv", "recomendacion": "Depurar duplicados."},
                           {"actividad": "Se concilia con contabilidad", "control": "Calidad de datos", "puntaje": 3, "concepto": "Parcial", "observacion": "Diferencia 0.39%.", "evidencia_encontrada": "01_ControlDatos.xlsx", "recomendacion": "Documentar la tolerancia."}]},
             "tabla_validacion": [], "controles_calidad_datos": []}
    ruta_rel = f"{date.today()}/resultados_{NOMBRE_MODELO}_{date.today()}.json"
    (out / Path(ruta_rel).name).write_text(json.dumps(datos, ensure_ascii=False, indent=2), encoding="utf-8")
    reg(a, "siembra resultados_*.json sintético", ruta_rel, "-", "escrito en la sesión del modelo de prueba", "PASS", "El pipeline real llama al LLM; se simula su salida (solo en la carpeta del modelo QA)")
    r = c.get("/api/resultados/lista")
    chk(a, "GET /api/resultados/lista", "-", "incluye el sintético", r.status_code == 200 and Path(ruta_rel).name in r.text, f"{r.status_code}")
    r = c.get(f"/api/resultados/{ruta_rel}")
    chk(a, "GET /api/resultados/{fecha}/{fichero}", "-", "200 datos", r.status_code == 200 and J(r).get("datos"), r.status_code)
    r = c.get(f"/api/resultados/tabla/{ruta_rel}")
    chk(a, "GET /api/resultados/tabla/{fecha}/{fichero}", "-", "200", r.status_code == 200, r.status_code)
    r = c.get("/api/resultados/actual")
    reg(a, "GET /api/resultados/actual", "-", "200 o 404", f"{r.status_code} {r.text[:80]}", "PASS" if r.status_code in (200, 404) else "FAIL")
    r = c.get("/api/resultados/tabla")
    reg(a, "GET /api/resultados/tabla (sin corrida)", "-", "404", f"{r.status_code}", "PASS" if r.status_code == 404 else "FAIL")
    r = c.get("/api/resultados/excel", params={"ruta": ruta_rel, "tipo": "intermedio"})
    chk(a, "GET /api/resultados/excel intermedio", "-", "200 xlsx", r.status_code == 200 and r.content[:2] == b"PK", f"{r.status_code} {len(r.content)}B")
    r = c.get("/api/resultados/excel", params={"ruta": ruta_rel, "tipo": "final"})
    chk(a, "GET /api/resultados/excel final", "-", "200 xlsx", r.status_code == 200 and r.content[:2] == b"PK", f"{r.status_code} {len(r.content)}B")
    r = c.get("/api/resultados/2026-01-01/..%2F..%2Fx.json")
    chk(a, "resultados traversal", "-", "400/404", r.status_code in (400, 404), r.status_code)
    r = c.get("/api/resultados/fecha-mala/x.json")
    chk(a, "resultados fecha inválida", "-", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/chat/iniciar", json={"ruta": ruta_rel})
    reg(a, "POST /api/chat/iniciar (sin LLM)", ruta_rel, "200 sesión de chat", f"{r.status_code} {r.text[:100]}", "PASS" if r.status_code == 200 else "FAIL")
    r = c.get("/api/chat/estado")
    chk(a, "GET /api/chat/estado tras iniciar", "-", "activa=true", J(r).get("activa") is True, J(r).get("activa"))
    r = c.get("/api/chat/observaciones")
    chk(a, "GET /api/chat/observaciones", "-", "200 detalle", r.status_code == 200, f"{r.status_code} {str(J(r).get('resumen'))[:80]}")
    skip(a, "POST /api/chat/adjuntar | POST /api/chat/consolidar", "adjuntar llama al LLM; consolidar no se ejecutó por depender del veredicto del chat")
    r = c.get("/api/chat/acta.xlsx")
    reg(a, "GET /api/chat/acta.xlsx", "-", "200 xlsx o 4xx claro", f"{r.status_code} {len(r.content)}B", "PASS" if r.status_code < 500 else "FAIL")
    r = c.post("/api/informe/consolidado", json={"ruta": "../x/y.json"})
    chk(a, "informe/consolidado ruta mala", "-", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/informe/consolidado", json={"ruta": f"{date.today()}/noexiste.json"})
    chk(a, "informe/consolidado inexistente", "-", "404", r.status_code == 404, r.status_code)
    r = c.post("/api/informe/consolidado", json={"ruta": ruta_rel})
    j = J(r)
    chk(a, "POST /api/informe/consolidado (Word)", ruta_rel, "200 docx", r.status_code == 200 and j.get("docx"), f"{r.status_code} {j.get('docx')} V{j.get('version')} {r.text[:120] if r.status_code != 200 else ''}")
    if j.get("docx"):
        rr = c.get(f"/api/informe/descargar/{j['docx']}")
        chk(a, "GET /api/informe/descargar/{docx}", j["docx"], "200 docx", rr.status_code == 200 and rr.content[:2] == b"PK", f"{rr.status_code} {len(rr.content)}B")
        (KIT / "descargas").mkdir(exist_ok=True)
        dp = KIT / "descargas" / j["docx"]
        dp.write_bytes(rr.content)
        import docx
        from docx import Document
        d = Document(str(dp))
        textos = [p.text for p in d.paragraphs] + [cel.text for t in d.tables for row in t.rows for cel in row.cells]
        blob = "\n".join(textos)
        chk(a, "Word contiene anexo «Validación completa · sustento por etapa»", "-", "título presente", "sustento por etapa" in blob, "encontrado" if "sustento por etapa" in blob else "AUSENTE")
        nimg = len(d.inline_shapes)
        chk(a, "Word incluye las imágenes de sustento (≥2 inline)", "-", f"≥2 imágenes (hay {len(IMG)*5} subidas, 2 por etapa)", nimg >= 2, f"inline_shapes={nimg}")
        figs = re.findall(r"Figura S\d+\.[^\n]{0,70}", blob)
        reg(a, "Word: pies de figura S#", "-", "'Figura S1.' …", "; ".join(figs[:4]) or "ninguno", "PASS" if figs else "FAIL")
        chk(a, "Word: tabla de etapas (00–04 con estado)", "-", "5 filas de etapa", sum(1 for k in ("00 · Diagnóstico", "01 · Control de datos", "02 · Modelamiento", "03 · Impactos", "04 · Seguimiento") if k in blob) == 5, "")
        chk(a, "Word: observación de prueba presente", "-", "texto del control", "id_cliente duplicados" in blob or "duplicados" in blob, "")
    r = c.get("/api/informe/descargar/..%2Fx.docx")
    chk(a, "informe/descargar traversal", "-", "400/404", r.status_code in (400, 404), r.status_code)
    r = c.get("/api/informe/versiones")
    chk(a, "GET /api/informe/versiones", "-", "≥1 versión", len(J(r).get("versiones", [])) >= 1, len(J(r).get("versiones", [])))
    r = c.get("/api/informe/estado")
    chk(a, "GET /api/informe/estado", "-", "resultados_disponibles incluye el sintético", Path(ruta_rel).name in r.text, r.status_code)
    r = c.get("/api/motores/notebook")
    reg(a, "GET /api/motores/notebook (controles de datos)", "-", "200 ipynb", f"{r.status_code} {len(r.content)}B x-n={r.headers.get('x-controles-n')}", "PASS" if r.status_code == 200 else "FAIL")
    if r.status_code == 200:
        try:
            import nbformat
            nbformat.validate(nbformat.from_dict(json.loads(r.content)))
            reg(a, "motores/notebook es nbformat válido", "-", "válido", "ok", "PASS")
        except Exception as exc:                                  # noqa: BLE001
            reg(a, "motores/notebook es nbformat válido", "-", "válido", str(exc)[:150], "FAIL")


# ───────────────────────── Solo informe ─────────────────────────
@seguro
def t_solo_informe():
    a = "Solo informe"
    c.post("/api/solo-informe/estandar", files={"archivo": ("Estandares_VIRF.xlsx", (KIT / "estandares" / "Estandares_VIRF.xlsx").read_bytes())})
    r = c.get("/api/solo-informe/estado")
    j = J(r)
    est = j.get("estandar") or {}
    ctrls = est.get("controles", [])
    chk(a, "GET /api/solo-informe/estado", "-", "estándar con 14 controles", r.status_code == 200 and len(ctrls) == 14, f"{r.status_code} controles={len(ctrls)}")
    r = c.post("/api/solo-informe/imagen", files={"archivo": ("captura_1.png", (KIT / "imagenes" / "captura_1.png").read_bytes())})
    img = J(r).get("imagen_id")
    chk(a, "POST /api/solo-informe/imagen", "captura_1.png", "200 imagen_id", r.status_code == 200 and img, f"{r.status_code} {img}")
    if img:
        r = c.get(f"/api/solo-informe/imagen/{img}")
        chk(a, "GET /api/solo-informe/imagen/{id}", "-", "200 png", r.status_code == 200 and r.headers.get("content-type", "").startswith("image"), r.status_code)
    r = c.post("/api/solo-informe/imagen", files={"archivo": ("x.exe", b"MZ")})
    chk(a, "POST solo-informe/imagen no-imagen", "-", "400", r.status_code == 400, r.status_code)
    r = c.post("/api/solo-informe/adjunto", files={"archivo": ("Resultado.xlsx", (KIT / "primera_linea" / "Resultado_notebook_primera_linea.xlsx").read_bytes())})
    chk(a, "POST solo-informe/adjunto sin clasificación", "-", "422/400", r.status_code in (400, 422), r.status_code)
    r = c.post("/api/solo-informe/adjunto", params={"clasificacion": "Interno"}, files={"archivo": ("Resultado.xlsx", (KIT / "primera_linea" / "Resultado_notebook_primera_linea.xlsx").read_bytes())})
    adj = J(r).get("id")
    chk(a, "POST solo-informe/adjunto Interno", "-", "200 id", r.status_code == 200 and adj, f"{r.status_code} {r.text[:80]}")
    r = c.post("/api/solo-informe/adjunto", params={"clasificacion": "Restringido"}, files={"archivo": ("Resultado.xlsx", b"x")})
    chk(a, "POST solo-informe/adjunto Restringido", "-", "403", r.status_code == 403, r.status_code)
    if ctrls:
        obs = [{"ambito": ctrls[0]["ambito"], "riesgo": "Moderado", "control_id": ctrls[0]["id"], "observacion": "Falta versionado.", "recomendacion": "Versionar.",
                "responsable": "Equipo X", "fecha_subsanacion": "2026-12-31",
                "sustento": {"tipo": "imagen", "imagen_id": img or ""}}]
        datos = {"tipo": "periodica", "tier": "II", "nombre_modelo": "MCR_CC QA", "responsable_doc": "QA Sonnet", "fecha_inicio": "2026-11-01",
                 "fecha_entrega": "2026-11-18", "contexto": "Contexto de prueba.", "limitaciones": "Ninguna.", "observaciones": obs}
        r = c.put("/api/solo-informe/borrador", json=datos)
        chk(a, "PUT /api/solo-informe/borrador", "-", "200", r.status_code == 200, f"{r.status_code} {r.text[:80]}")
        r = c.post("/api/solo-informe/generar", json=datos)
        j = J(r)
        chk(a, "POST /api/solo-informe/generar", "-", "200 + url", r.status_code == 200 and j.get("url"), f"{r.status_code} {r.text[:200]}")
        if j.get("url"):
            rr = c.get(j["url"])
            chk(a, "GET solo-informe/descargar", j["url"], "200 docx", rr.status_code == 200 and rr.content[:2] == b"PK", f"{rr.status_code} {len(rr.content)}B")
        bad = dict(datos, observaciones=[dict(obs[0], riesgo="Inventado")])
        r = c.post("/api/solo-informe/generar", json=bad)
        chk(a, "generar con riesgo inválido", "-", "400", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.get("/api/solo-informe/descargar/..%2Fx.docx")
    chk(a, "solo-informe/descargar traversal", "-", "400/404", r.status_code in (400, 404), r.status_code)
    r = c.get("/api/solo-informe/descargar/malo.docx")
    chk(a, "solo-informe/descargar nombre fuera de patrón", "-", "400", r.status_code == 400, r.status_code)
    r = c.get("/api/solo-informe/manuales")
    chk(a, "GET solo-informe/manuales", "-", "200", r.status_code == 200, r.status_code)
    r = c.post("/api/solo-informe/manuales", files={"archivo": ("Manual_Metodologico_MCR_CC.md", (KIT / "manuales" / "Manual_Metodologico_MCR_CC.md").read_bytes())})
    chk(a, "POST solo-informe/manuales", "-", "200", r.status_code == 200, f"{r.status_code} {r.text[:80]}")
    r = c.delete("/api/solo-informe/manuales/Manual_Metodologico_MCR_CC.md")
    chk(a, "DELETE solo-informe/manuales/{n}", "-", "200", r.status_code == 200, r.status_code)
    r = c.delete("/api/solo-informe/manuales/noexiste.md")
    chk(a, "DELETE solo-informe/manuales inexistente", "-", "404", r.status_code == 404, r.status_code)
    skip(a, "POST /api/solo-informe/ia/pulir|grafico|manuales", "llaman al LLM de pago")
    r = c.delete("/api/solo-informe/estandar")
    chk(a, "DELETE solo-informe/estandar", "-", "200", r.status_code == 200, r.status_code)


# ───────────────────────── RAG ─────────────────────────
@seguro
def t_rag():
    a = "RAG"
    r = c.get("/api/rag/dominios")
    j = J(r)
    chk(a, "GET /api/rag/dominios", "-", "fijos con índice", r.status_code == 200 and len(j.get("dominios", [])) >= 3, [(d["id"], d["indice"].get("n_chunks"), d["indice"].get("desactualizado")) for d in j.get("dominios", [])])
    antes = {d["id"]: (d["indice"].get("n_chunks"), len(d["papers"]), d["indice"].get("construido_en")) for d in j.get("dominios", [])}
    ESTADO["rag_antes"] = antes
    r = c.post("/api/rag/dominios/crear", json={"nombre": "x"})
    chk(a, "crear dominio nombre corto", "x", "422", r.status_code == 422, r.status_code)
    r = c.post("/api/rag/dominios/crear", json={"nombre": DOM_TEST_NOMBRE, "descripcion": "Dominio de prueba QA (borrar)", "palabras_clave": ["psi", "gini", "calibracion"]})
    ent = J(r).get("dominio", {})
    dom = ent.get("id") or ent.get("dominio")
    chk(a, "POST /api/rag/dominios/crear (qa_sonnet_)", DOM_TEST_NOMBRE, "200 id", r.status_code == 200 and dom, f"{r.status_code} id={dom} {r.text[:80]}")
    if not dom:
        return
    ESTADO["dom"] = dom
    chk(a, "id del dominio empieza por qa_sonnet_", "-", "qa_sonnet_*", dom.startswith("qa_sonnet_"), dom)
    r = c.post("/api/rag/dominios/crear", json={"nombre": DOM_TEST_NOMBRE})
    chk(a, "crear dominio duplicado", "-", "400", r.status_code == 400, f"{r.status_code} {r.text[:60]}")
    r = c.delete("/api/rag/dominios/LaR")
    chk(a, "DELETE dominio fijo LaR", "-", "400 (no se borra)", r.status_code == 400, r.status_code)
    # destino de upload del dominio custom
    d = c.get("/api/inputs/destinos").json().get("destinos", [])
    chk(a, f"/api/inputs/destinos incluye rag_{dom}", "-", f"rag_{dom} presente", any(x["slug"] == f"rag_{dom}" for x in d), [x["slug"] for x in d if x["slug"].startswith("rag_")])
    papers = sorted((KIT / "rag_papers").iterdir())
    subidos = 0
    for p in papers:
        r = c.post("/api/inputs/upload", params={"destino": f"rag_{dom}", "clasificacion": "Publico", "dueno": "QA", "vigencia": "2027-12-31"}, files={"archivos": (p.name, p.read_bytes())})
        ok = r.status_code == 200
        subidos += ok
        chk(a, f"upload paper a rag_{dom}", p.name, "200 (así lo hace la UI)", ok, f"{r.status_code} {r.text[:120]}")
    r = c.post("/api/inputs/upload", params={"destino": f"rag_{dom}", "clasificacion": "Publico"}, files={"archivos": ("a.md", b"x")})
    chk(a, "upload RAG sin dueño/vigencia", "-", "400 (o 400 destino desconocido)", r.status_code == 400, f"{r.status_code} {r.text[:80]}")
    r = c.get("/api/rag/dominios")
    mi = next((x for x in J(r).get("dominios", []) if x["id"] == dom), {})
    chk(a, "dominio de prueba lista los papers subidos", "-", f"{len(papers)} papers", len(mi.get("papers", [])) == len(papers) and subidos == len(papers), f"{len(mi.get('papers', []))} papers; subidos={subidos}")
    if subidos:
        r = c.post("/api/rag/reconstruir", json={"dominio": dom, "force": True})
        j = J(r)
        chk(a, "POST /api/rag/reconstruir (solo qa_sonnet_)", dom, "200 ok exit 0", r.status_code == 200 and j.get("ok"), f"{r.status_code} exit={j.get('exit_code')} {(j.get('salida') or '')[-200:]}")
        mi = next((x for x in J(r).get("dominios", []) if x["id"] == dom), {})
        chk(a, "índice del dominio de prueba creado", "-", "n_chunks>0", (mi.get("indice") or {}).get("n_chunks", 0) > 0, mi.get("indice"))
        # retrieval real: preview-prompt con un modelo de ese dominio -> muestra top3 chunks
        nm = f"QA_SONNET_RAG_{SUF}"
        r = c.post("/api/modelos", json={"nombre": nm, "dominio": dom, "tier": "II", "modalidad": "normal"})
        sl = J(r).get("modelo", {}).get("slug")
        chk(a, "crear modelo con dominio custom", dom, "200", r.status_code == 200, f"{r.status_code} {r.text[:80]}")
        ESTADO["slug_rag"] = sl
        if sl:
            sv = c.ck.get("virf_modelo")
            c.post(f"/api/modelos/{sl}/activar")
            # El retriever del preview usa una consulta fija: 'metodología y supuestos del modelo <nombre>'
            r = c.post("/api/validacion/preview-prompt")
            j = J(r)
            fuentes = [x.get("fuente") for x in j.get("rag_chunks_ejemplo", [])]
            chk(a, "retrieval del dominio custom (preview-prompt)", "consulta fija del endpoint", "chunks de los papers qa_sonnet_", r.status_code == 200 and any(fuentes), f"{r.status_code} fuentes={fuentes} {[x.get('texto','')[:60] for x in j.get('rag_chunks_ejemplo', [])][:1]}")
            # consultas dirigidas directamente al buscador léxico (módulo local, sin HTTP, coste 0, mismo índice)
            try:
                sys.path.insert(0, str(PROYECTO)); sys.path.insert(0, str(PROYECTO / "motor"))
                from src.rag import get_retriever
                rt = get_retriever(tipo_modelo=dom)
                for q, esperado in (("cuprometeo", "paper_psi_estabilidad"), ("ferrocarrilito calibración", "paper_calibracion_pd"),
                                    ("quilombometro Gini KS", "paper_gini_ks"), ("LCR liquidez HQLA", "paper_liquidez_basilea")):
                    hs = rt.query(q, top_k=3) or []
                    fu = [str(h.get("fuente") or h.get("source")) for h in hs]
                    chk(a, f"búsqueda léxica '{q}'", q, f"top3 contiene {esperado}", any(esperado in f for f in fu), fu)
            except Exception as exc:                              # noqa: BLE001
                reg(a, "retriever local por dominio", "-", "consultas", f"{type(exc).__name__}: {exc}", "FAIL")
            c.post(f"/api/modelos/{ESTADO['slug']}/activar")
        # borrar un paper concreto + reindexa
        r = c.delete(f"/api/rag/dominios/{dom}/paper/paper_calibracion_pd.md")
        chk(a, "DELETE paper concreto (reindexa solo ese dominio)", "paper_calibracion_pd.md", "200 reconstruido ok", r.status_code == 200 and J(r).get("reconstruido", {}).get("ok"), f"{r.status_code} {str(J(r).get('reconstruido', {}).get('exit_code'))}")
        r = c.delete(f"/api/rag/dominios/{dom}/paper/..%2Fx.md")
        chk(a, "DELETE paper con ../", "-", "400/404", r.status_code in (400, 404), r.status_code)
        r = c.delete(f"/api/rag/dominios/{dom}/paper/.oculto")
        chk(a, "DELETE paper dotfile", "-", "400", r.status_code == 400, r.status_code)
        r = c.delete(f"/api/rag/dominios/{dom}/paper/noexiste.md")
        chk(a, "DELETE paper inexistente", "-", "404", r.status_code == 404, r.status_code)
    if not subidos:
        skip(a, "reconstruir índice / búsquedas / borrar paper del dominio qa_sonnet_", "BLOQUEADO por el fallo de subida (destino rag_<custom> desconocido): no hay papers que indexar y no se escribe a mano en inputs/rag")
    r = c.post("/api/rag/reconstruir", json={"dominio": "no_existe_qa"})
    chk(a, "reconstruir dominio inexistente", "-", "400", r.status_code == 400, r.status_code)
    skip(a, "POST /api/rag/reconstruir {dominio:'all'} y reconstruir de dominios fijos", "reconstruirían índices globales/compartidos")
    # integridad de dominios globales
    r = c.get("/api/rag/dominios")
    despues = {d["id"]: (d["indice"].get("n_chunks"), len(d["papers"]), d["indice"].get("construido_en")) for d in J(r).get("dominios", [])}
    fijos_ok = all(despues.get(k) == v for k, v in ESTADO["rag_antes"].items())
    chk(a, "dominios existentes intactos (chunks/papers/índice)", "-", "idénticos a antes", fijos_ok, "iguales" if fijos_ok else {k: (ESTADO['rag_antes'][k], despues.get(k)) for k in ESTADO['rag_antes'] if ESTADO['rag_antes'][k] != despues.get(k)})


# ───────────────────────── Limpieza ─────────────────────────
@seguro
def t_limpieza():
    a = "Limpieza"
    sl = ESTADO.get("slug_rag")
    if sl:
        r = c.delete(f"/api/modelos/{sl}")
        chk(a, "borrar modelo RAG de prueba", sl, "200", r.status_code == 200, r.status_code)
    dom = ESTADO.get("dom")
    if dom:
        r = c.delete(f"/api/rag/dominios/{dom}")
        chk(a, "DELETE dominio qa_sonnet_", dom, "200", r.status_code == 200, f"{r.status_code} {r.text[:100]}")
        r = c.get("/api/rag/dominios")
        chk(a, "dominio de prueba ya no está", "-", "ausente", all(d["id"] != dom for d in J(r).get("dominios", [])), "")
        disco_inputs = PROYECTO / "inputs" / "rag" / dom
        disco_idx = PROYECTO / "data" / "rag_lexico" / f"{dom}.pkl"
        chk(a, "borrado del dominio limpia disco (inputs/rag y .pkl)", "-", "sin residuos", not disco_inputs.exists() and not disco_idx.exists(), f"inputs={disco_inputs.exists()} pkl={disco_idx.exists()}")
    # estándar + sesión
    c.delete("/api/estandares")
    sl = ESTADO.get("slug")
    if sl:
        r = c.delete(f"/api/modelos/{sl}")
        chk(a, "borrar modelo QA principal", sl, "200", r.status_code == 200, r.status_code)
    r = c.get("/api/modelos")
    rest = [m["slug"] for m in J(r).get("modelos", []) if "QA_SONNET" in m["slug"].upper()]
    chk(a, "sin modelos QA_SONNET residuales", "-", "[]", not rest, rest)
    # fuentes_rag registro global: entradas huérfanas del dominio
    reg_f = PROYECTO / "data"
    huellas = [p for p in reg_f.rglob("*.json") if dom and dom in p.read_text(encoding="utf-8", errors="ignore")] if dom and reg_f.is_dir() else []
    reg(a, "residuos del dominio en data/*.json (registro de fuentes)", "-", "ninguno", [str(h.relative_to(PROYECTO)) for h in huellas[:3]] or "ninguno", "PASS" if not huellas else "FAIL",
        "Borrar un dominio no limpia data/fuentes_rag.json (o similar)" if huellas else "")


# ───────────────────────── UI (navegador integrado; resultados manuales) ─────────────────────────
@seguro
def t_ui_manual():
    a = "UI (navegador)"
    M = [
        ("Login libre en 127.0.0.1:8010 (cookie aparte) y alta de modelo completa desde el formulario", "PASS", "entra a la vista del modelo; 0 errores de consola"),
        ("Sidebar: 18 botones nav (config, estándares, evidencia, RAG, skills, cuestionamientos, pre-vuelo, validar, documentar, insumos, etapas 00–04, resultados, controles, chat)", "PASS", "cada uno abre su panel; 0 errores JS/consola"),
        ("Estándares: subir .xlsx → vista previa (14 act, 5 ámbitos) → Aceptar", "PASS", "estado confirmado"),
        ("Estándares: Cambiar archivo (descarta pendiente y vuelve a la dropzone)", "PASS", ""),
        ("Estándares: Ver detalle / Reemplazar / (Cancelar reemplazo) con pendiente subido", "PASS", "al cancelar: pendiente=false, vigente intacto"),
        ("Estándares: Eliminar (confirm)", "PASS", "confirmado=false, dropzone visible"),
        ("Estándares: archivo .txt y 'xlsx' no-zip → mensaje de error claro en #est-error", "PASS", ""),
        ("Validar modelo: botón Vista previa del prompt (preview-prompt, LLM interceptado)", "PASS", "sin errores"),
        ("Documentar: «Cuadro borrador» (usar_ia=false) y panel de estado", "PASS", "sin errores de consola"),
        ("Modal de Configuración abre/cierra (Cancelar), Verificar NO pulsado (llama al proveedor)", "PASS", ""),
        ("Toggle VALIDACIÓN normal↔completa (btn-modalidad)", "PASS", "alterna y refleja la etiqueta (primer clic mostró aún «normal» hasta recargar la etiqueta)"),
        ("Validar modelo: «Firmante … (SSO): —» debería mostrar la identidad del usuario", "FAIL", "SIEMPRE muestra «—». web/static/js/app.js:2139-2143 rellena #firm-identidad en el cableado inicial, cuando estado.validador aún es null (se carga después en app.js:2759-2762 / 3628). Debería rellenarse al abrir la vista."),
        ("Documentar: texto de ayuda (index.html:524) dice «súbelos en Subir evidencia → automatizaciones/»", "FAIL", "esa tarjeta está oculta ('oculto': True en contexto_sesion.py:~180); en completa los Excels van al chat de cada etapa. Texto obsoleto."),
        ("Subida masiva a las 10 tarjetas de Evidencia por la UI, chat de etapa (enviar/cerrar/reabrir), insumos subir/estudiar/borrar por UI", "SKIP", "el clasificador de permisos del entorno BLOQUEÓ el script de subida masiva por UI (DataTransfer a 10 tarjetas); se cubre por HTTP (ver Evidencia y Validación completa). Botones mapeados estáticamente (ver abajo)."),
        ("Mapa estático: 92 ids interactivos de index.html", "PASS", "todos tienen listener en JS (btn-etapa-00..04 se cablean dinámicamente en completa.js:53,63)"),
        ("Mapa estático: 92 endpoints /api/* citados en el JS", "PASS", "todos existen en el backend (incl. /api/resultados/${ruta}, /api/completa/etapa/${..}/descargar/); /api/estandares/detalle y /api/prompts/base no se usan desde el JS"),
    ]
    for nombre, st, nota in M:
        reg(a, nombre, "navegador (JS .click / fetch)", "sin error de consola y comportamiento correcto", nota or "ok", st, nota)
    # limpiar el modelo creado por la UI (usuario 'QA Sonnet UI')
    u = Cli()
    r = u.post("/api/auth/login-libre", json={"nombre": "QA Sonnet UI", "cargo": "Validador", "roles": ["validador"]})
    lst = J(u.get("/api/modelos")).get("modelos", [])
    for m in lst:
        if m["slug"].upper().startswith("QA_SONNET_UI"):
            rr = u.delete(f"/api/modelos/{m['slug']}")
            chk("Limpieza", "borrar modelo creado por la UI", m["slug"], "200", rr.status_code == 200, rr.status_code)


def main():
    for f in (t_auth, t_modelos, t_config_y_lecturas, t_skills_cuest, t_estandares, t_evidencia, t_completa,
              t_notebooks, t_documentar, t_solo_informe, t_rag, t_ui_manual, t_limpieza):
        print(f"\n=== {f.__name__} ===", flush=True)
        f()
    out = KIT / "resultados_qa.json"
    out.write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
    n = {s: sum(1 for x in R if x["status"] == s) for s in ("PASS", "FAIL", "SKIP")}
    print("\nTOTAL", n, "->", out)


if __name__ == "__main__":
    main()
