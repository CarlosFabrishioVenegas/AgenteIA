# Manual de extracción y controles de datos

## 1. Extracción
Las bases se extraen del datawarehouse (esquema dwh) el día 5 de cada mes: dwh.clientes, dwh.saldos_diarios.

## 2. Controles de calidad
C01 Unicidad de id_cliente en clientes. C02 Nulos en saldo < 1%. C03 Saldos negativos revisados contra
sobregiro autorizado. C04 Conciliación de montos contra contabilidad con tolerancia de 0.5%.
C05 Integridad referencial saldos -> clientes.

## 3. Resultado
Cada control se registra con resultado Cumple / No cumple y número de registros afectados.
