# Manual metodológico · MCR_Cuenta_Corriente v3.2

Modelo de pérdida esperada (PD/LGD) para saldos de cuenta corriente del banco ficticio Banco Andino Demo.

## 1. Población objetivo
La población son los clientes personas naturales con cuenta corriente activa entre 2019-01 y 2024-12.
Se toma una observación por cliente y mes (granularidad cliente-mes).

## 2. Exclusiones
2.1 Se excluyen cuentas inactivas por más de 12 meses.
2.2 Se excluyen saldos negativos mayores a 5.000 USD por considerarse sobregiro autorizado.
2.3 Se excluyen empleados del banco.

## 3. Variables
Las variables candidatas son: saldo_promedio_3m, antiguedad_meses, num_movimientos, ratio_sobregiro,
ingreso_declarado, segmento_comercial. Se transforman con WoE y se corrigen valores atípicos al percentil 99.

## 4. Segmentación
Se definen 3 segmentos: Masivo, Preferente y Premium, mediante un árbol de decisión de profundidad 3
con mínimo de 5% de población por hoja.

## 5. Estimación
La PD se estima con regresión logística por segmento; la LGD con regresión beta sobre recuperaciones a 24 meses.
Muestra de desarrollo: 70%; muestra de validación: 30%.

## 6. Calibración
Se calibra la PD a la tasa de default central de largo plazo mediante el método del intercepto ajustado.
El ajuste debe mantenerse dentro de ±10% de la tasa observada.

## 7. Umbrales de seguimiento
PSI: verde < 0.10, ámbar entre 0.10 y 0.25, rojo > 0.25.
KS: mínimo aceptable 30%. Gini: mínimo aceptable 40%.
Backtesting: tolerancia de ±15% entre PD estimada y observada.
