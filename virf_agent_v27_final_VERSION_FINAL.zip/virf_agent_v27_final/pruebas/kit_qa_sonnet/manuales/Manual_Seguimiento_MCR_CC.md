# Manual de seguimiento · MCR_Cuenta_Corriente

## 1. Frecuencia
El seguimiento es trimestral. Se publica dentro de los 20 días hábiles posteriores al cierre.

## 2. Indicadores
2.1 PSI de cada variable y del score. 2.2 KS y Gini sobre la cartera vigente. 2.3 Backtesting de PD por segmento.

## 3. Umbrales
PSI > 0.25 dispara alerta roja y revisión del modelo. KS < 30% alerta ámbar. Gini < 40% alerta roja.

## 4. Fuentes
Base: S:\\modelos\\seguimiento\\cuentas_2024Q4.csv, extraída desde dwh.cuentas_mensual.
