# Auditoría anti-alucinación — VIRF Agent

> Fecha: 2026-11-18 · Alcance: todos los puntos donde una IA genera texto, cifras o citas
> (pipeline de evaluación, revisión de código, chat de sustentación, RAG, explicador de modelo,
> Solo Informe, Validación completa, cuadro de automatizaciones, resúmenes de documentos largos).
> Método: lectura del código de cada punto + pruebas con entradas fabricadas (sin llamar a ninguna IA).

## 0. Lo que esta auditoría puede y NO puede afirmar

**No se puede demostrar que un modelo «no alucina en ninguna parte».** Ningún control de software
lo garantiza, y esta auditoría no llamó a ninguna IA real (no hay credencial en esta máquina y cada
corrida gasta). Lo que sí se puede afirmar, y está probado por tests:

1. Qué controles **deterministas** existen en cada punto y qué tipo de invención atrapan.
2. Qué invenciones **no** atrapan (brechas abiertas, §4.3 y §4.4) — declaradas, no ocultas.
3. Que las brechas encontradas hoy se **cerraron** (§3 y §4.1) y que quedó una prueba por cada una
   (`tests/test_antialucinacion_brechas.py`).
4. Que **medir** la alucinación real exige una corrida con la IA de producción (§6).

Principio de diseño que sostiene todo el sistema: el humano firma; el agente propone; **lo que no se
puede verificar se declara, no se calla** (citas «no verificadas», observación retirada, abstención,
fallo técnico excluido del promedio).

## 1. Mapa de puntos donde la IA genera contenido

| # | Punto | Qué genera | ¿Llega a un entregable firmado? |
|---|---|---|---|
| 1 | Pipeline de evaluación (`modulos/motor_ia.py`) | Puntaje, observación, citas, inconsistencias | **Sí** (informe regulatorio) |
| 2 | Revisión de código (`modulos/revision_codigo.py`) | Hallazgos con `fichero:línea` | Sí (se fusiona en «Implementación») |
| 3 | Chat de sustentación (`web/services/chat_service.py`) | Veredicto APROBADO/NEGADO/PENDIENTE | **Sí: APROBADO sube el puntaje final** |
| 4 | RAG léxico (`src/rag/`) | **No genera**: recupera literatura | Indirecto (alimenta el prompt) |
| 5 | Resumen de documentos largos (`modulos/chunker.py`) | Resúmenes que **sustituyen** al documento | Indirecto (base de la evaluación) |
| 6 | Explicador de modelo (`modulos/explicador_modelo.py`) | Documento de 9 secciones | Documento de apoyo |
| 7 | Solo Informe — IA (`web/services/solo_informe_ia.py`) | Pulido, gráficos, redacción desde manuales | Sí (va al Word si el validador acepta) |
| 8 | Validación completa (`modulos/validacion_completa.py`, `estudio_insumos.py`) | Notebooks, fichas de estudio | Sí (anexo y notebooks) |
| 9 | Cuadro de automatizaciones (`modulos/automatizaciones.py`) | Observaciones y recomendaciones | Sí (1.1 del Resumen ejecutivo) |
| 10 | Conversión Excel→notebook, controles→notebook | Código y traducción de fórmulas | Notebooks (se validan contra el Excel) |
| 11 | Entailment / NLI (`modulos/entailment.py`) | Juez de si la cita sostiene la afirmación | Control, no entregable |

## 2. Controles que ya existían (verificados)

| Control | Qué atrapa | Dónde |
|---|---|---|
| Temperatura fija (`VIRF_IA_TEMPERATURE`=0.0) | Variabilidad aleatoria | `config/ia.py` (se omite sola en modelos que no la admiten) |
| Prompt «PROHIBIDO INVENTAR CITAS» + respuesta válida «No se encontró evidencia» | Incentivo a fabricar | `modulos/motor_ia.py` |
| Verificación **literal** de citas contra el contexto | Citas inventadas | `motor_ia._verificar_citas` + `validador_citas.cita_en_texto` (tolera formato, no letras ni cifras: «250» no casa con «500») |
| Citas de **inconsistencias** verificadas | Acusaciones falsas manual↔código | `motor_ia.evaluar_actividad` |
| Retirada de la afirmación (SEG-16) | Observación con cita dudosa o NLI negativo | `modulos/salvaguardas_llm.py` → queda en `observacion_retirada` + `requiere_revision_humana` |
| Entailment (NLI) con subcadena literal obligatoria | Cita que existe pero **no sostiene** la conclusión | `modulos/entailment.py` (ON en producción, OFF en debug) |
| Abstención β | Puntuar sin evidencia recuperada | `modulos/abstencion.py` (`VIRF_ABSTENCION_BETA`=0.19) |
| Fallo técnico ≠ falta de evidencia | Penalizar al validado por un fallo del agente | `calcular_score_ambito` (excluye; no puntúa 0) |
| Contrato JSON validado, sin «puntaje 2 por defecto» | Respuesta malformada convertida en dictamen | `_validar_contrato_evaluacion`, `_evaluacion_invalida` |
| Anti-inyección + PII | Instrucciones ocultas en la evidencia | `modulos/inyeccion.py`, `pii.py` |
| Sin evidencia → 0.0 y se declara | Evaluar sobre el vacío | `prevuelo`, `calcular_score_ambito` |
| Procedencia del RAG declarada | Corpus equivocado | `--dominio-rag` (declarado vs inferido en el informe) |
| Gráficos: cada cifra debe estar en el texto | Cifras inventadas en gráficos | `solo_informe_ia._validar_spec` |
| Cuadro de automatizaciones: cada evidencia debe apuntar a una hoja leída | Evidencia a hojas inexistentes | `automatizaciones._evidencia_verificada` |
| Documento largo: marca de cobertura y de truncado | Documento a medias que parece completo | `explicador_modelo.verificar`, `chunker` |

## 3. Brechas encontradas hoy y CERRADAS

Cada una se demostró con una entrada fabricada **antes** del arreglo y tiene prueba después.

| # | Brecha (antes) | Prueba de la brecha | Arreglo | Prueba que la fija |
|---|---|---|---|---|
| B1 | **La verificación de citas solo reconocía comillas rectas `"…"`**. Una cita **inventada** entre `“…”` o `«…»` no se comprobaba nunca. | Cita inventada con `“ ”` y `« »` → «NO detectada» | `_verificar_citas` iguala las comillas antes de buscar | `TestCitasPipeline` (parametrizado ×3 tipos de comilla) |
| B2 | **Las citas de una inconsistencia (<40 caracteres) escapaban a la comprobación.** Eran justo las más graves («retornos[-500:]» tiene 15). | `"ventana de 500 días"` inventada → «NO detectada» | Mínimo bajo (10) solo para citas de inconsistencias; el de la evidencia sigue en 40 | `test_cita_corta_de_inconsistencia_*` |
| B3 | **El chat no verificaba nada.** Su prompt no decía «no inventes», pedía «cita archivo:línea» sin comprobar, y un `APROBADO` del modelo **subía el puntaje final**. | Respuesta con cita y archivo inventados → pasaba intacta | (a) Reglas «NO INVENTES» y «NO APRUEBES POR CORTESÍA» en el prompt; (b) `verificar_respuesta`: comprueba citas y archivos contra la evidencia de la observación y avisa en el propio mensaje; (c) un APROBADO apoyado en algo no verificable **se degrada a PENDIENTE** | `TestChat` (6 pruebas) |
| B4 | **El prompt real del chat vive en `web/data/prompts_base.json`, no en el código**; cambiar solo el código no habría surtido efecto. | `get_prompt` lee el JSON | Regla añadida en ambos + prueba de que son **idénticos** | `TestPromptChat::test_el_json_base_es_identico_al_codigo` |
| B4b | Los otros prompts base (`rol_agente`, `evaluacion_ambito`) no tienen la palabra «inventes» | — | **No se tocaron**: el prompt de evaluación completo (en `motor_ia`) ya la tiene; queda anotado en §4 | — |
| B5 | **Los resúmenes de documentos largos los hace una IA con un prompt sin «no inventes»**, y luego **sustituyen al documento**: una cita «literal» contra el resumen pasa la verificación aunque el resumen sea falso. | Lectura del prompt y de `doc["contenido"]=contenido_final` | Prompts con «REGLAS ANTI-INVENCIÓN»; el texto del documento resumido ahora **declara** «RESUMEN generado por IA… una cita literal NO prueba que el documento diga eso» | `TestChunker` |
| B6 | **El explicador solo comprobaba la estructura** (9 secciones, sin truncar). Podía nombrar funciones o cifras inexistentes sin que nada lo notara. | `verificar()` solo mira secciones | Nuevo contraste sin IA: nombres/cifras entre comillas invertidas que **no constan** en la evidencia → sección «⚠️ Verificación automática — a contrastar» al final del documento | `TestExplicador` |
| B7 | **Solo Informe — «redactar desde manuales»** pedía citar `[archivo, pág. N]` pero nunca comprobaba que ese archivo y página se hubieran consultado. | Lectura del código | `citas_sin_respaldo`: cita sin fragmento consultado → se escribe un aviso **dentro** del texto propuesto y se devuelve `citas_sin_respaldo` | `TestSoloInforme` |
| B8 | **Solo Informe — «pulir»**: «conserva las cifras; no añadas información» era solo una petición. | Lectura del código | Si el texto pulido tiene cifras que el original no tenía, **se descarta** | `TestPulir` |

## 4. Segunda revisión de las brechas pendientes (mismo día)

Se revisó cada una de las 13 brechas residuales. Resultado: **6 cerradas o mitigadas con código y
prueba, 2 reclasificadas con datos reales, 5 siguen abiertas por razones concretas.** Además apareció
una brecha nueva (R14) y una nueva observación (R15).

### 4.1 Cerradas o mitigadas

| # | Brecha | Qué se hizo | Prueba |
|---|---|---|---|
| R3 | Paráfrasis presentada como cita (sin comillas) | `sin_cita_literal()`: si la evidencia no trae ninguna cita entre comillas ni bloque de código, se **avisa** (no se retira: puede ser fiel). Aviso visible en Markdown, Word e informe web | `TestVerificacionCifras` |
| R4 | Cifras de la observación no contrastadas | `cifras_ausentes()`: cifras de la observación que no constan en **nada** de lo entregado al modelo → aviso. Tolera equivalencias (`99,0`≈`99`; `1.250`≈`1,250`) e ignora enteros de un dígito (numeración) | idem |
| R5 | El juez NLI, sin cita del modelo, recibía los **primeros** 4000 caracteres | Ahora recibe los párrafos más parecidos a la observación (`ventana_relevante`). Si el modelo escribió «No se encontró evidencia…» no se toca (es una afirmación de ausencia: cambiarlo podría retirar hallazgos legítimos) | idem |
| R7 | Cuadro de automatizaciones: `evidencia_verificada` **se calculaba y no se mostraba en ningún sitio**; las cifras nunca se contrastaban con los Excels | Avisos por fila (evidencia a hoja no leída; cifras ausentes de los Excels) escritos en la columna Observación del Excel y en el anexo del informe. Los borradores deterministas no llevan avisos | `TestCuadroAutomatizaciones` (3) |
| R12 | `rol_agente` y `evaluacion_ambito` sin cláusula anti-invención | **No hacía falta**: `rol_agente` ya dice «Basado solo en EVIDENCIA EXPLÍCITA — nunca asumas / NUNCA valides sin evidencia», y `evaluacion_ambito` es una copia de solo lectura (el prompt real tiene «PROHIBIDO INVENTAR CITAS»). Cambiar `ROL_AGENTE` alteraría la huella de prompts y la custodia | — |
| R15 (nueva) | Citas entre **comillas simples** (`fichero → 'texto'`): en los resultados reales aparecen en 3 de 69 evidencias y **no se verificaban** | `_verificar_citas` las reconoce tras «→» o «:» (un apóstrofo normal no la activa) | `TestComillasSimples` |

### 4.2 Reclasificadas con datos reales

Se midió sobre los **27 archivos de resultados históricos** de `outputs/` (128 actividades, 69 con evidencia):

| Dato | Valor |
|---|---|
| Citas entre comillas en total | 308 |
| …de menos de 40 caracteres (las que no se verifican) | **14 (4,5 %)** |
| …de 40 o más (verificadas) | 294 (95,5 %) |
| Evidencias sin ninguna comilla doble | 3 de 69 (usaban comillas simples → R15) |
| Evidencias con la frase «No se encontró evidencia…» | 0 |

| # | Antes | Ahora |
|---|---|---|
| R1 | Riesgo **medio** | Riesgo **bajo y acotado**: solo el 4,5 % de las citas escapa. Se mantiene el umbral de 40 porque bajarlo retiraría observaciones válidas (SEG-16) y no hay datos que midan ese coste |
| R2 | Riesgo bajo | Sin cambio (menos de 10 caracteres: coincidencia casual probable) |

### 4.3 Siguen ABIERTAS

| # | Brecha | Por qué sigue abierta | Riesgo | Cómo cerrarla |
|---|---|---|---|---|
| R6 | NLI apagado en `MODO=debug` | Decisión de coste (+1 llamada por actividad) | Solo desarrollo | `VIRF_ENTAILMENT=1` en pruebas serias |
| R8 | Notebooks (Validación completa, Excel→notebook): solo se comprueba la **sintaxis** | Por seguridad (SEG-07) el código no se ejecuta aquí; lo ejecuta el validador donde están los datos | Medio | Por diseño |
| R9 | Explicador: las afirmaciones en **prosa** no se contrastan, solo lo que va entre comillas invertidas | No hay verificador de prosa sin IA | Medio | Revisión humana (la sección final lo recuerda) |
| R10 | Resúmenes de documentos largos: se **declaran** y se les prohíbe inventar, pero no se verifican contra el original | Verificarlos cuesta tanto como hacerlos | Medio | Contrastar con el original los hallazgos graves |
| R11 | El chat no verifica el texto del **validador** | Es afirmación humana | — | Firma y custodia del validador |
| R13 | Un validador puede editar el prompt y quitar las reglas | Es una función de la web | Medio | El hash del prompt queda en el informe (`prompt_sha256`); revisar prompts editados |

### 4.4 Decisión que NO tomé (es tuya) — R14

**La frase permitida «No se encontró evidencia en el contexto disponible» cuenta como evidencia** para
la abstención: `salvaguardas_llm.aplicar` usa `hay_evidencia = bool(evidencia_encontrada.strip())`, y esa
frase no está vacía. Consecuencia: cuando el modelo declara que no encontró nada, **la abstención β
nunca se activa**, aunque el RAG no haya recuperado nada tampoco. Puede ser deliberado (una ausencia
de evidencia en el modelo validado es un hallazgo legítimo —«falta»— y no debe ocultarse como
«evidencia insuficiente»), o un descuido. **No lo cambié** porque alteraría cómo se puntúa la falta de
evidencia (política de la entidad: sin evidencia = 0.0). Dime cuál es la intención y lo ajusto.

## 5. RAG: qué se midió

Medido hoy con `scripts/preguntas_oro_rag.py` (coste 0):

| Métrica | Resultado | Umbral |
|---|---|---|
| Recall@1, preguntas discriminantes (19) | **89 %** | 85 % |
| Recall@1 incluyendo no discriminantes (24) | 88 % | — |
| Consultas adversarias que **declaran su alcance** (4) | **4/4** | — |
| Recall@3 | 100 % (**INACTIVO**: con 2-3 documentos por dominio el top-3 abarca el corpus entero y no informa) | — |

**Lo que esto NO acredita** (lo dice el propio script): que la respuesta del modelo sea buena, solo que
el RAG vio el documento que debía ver. Además:

- `scripts/verificar_corpus_rag.py` reportó **«índice ausente»** (0 fragmentos) en LaR, ALM y shared:
  los índices no están construidos **en disco** en esta máquina (no viajan en el zip y se autoconstruyen
  al primer uso). Antes de una validación real: `…Indexer().build_index(force_rebuild=True)` o
  `scripts/rebuild_rag_databricks.py`, y repetir `verificar_corpus_rag.py`.
- El corpus es pequeño: el límite está documentado en `PROCEDIMIENTO_VALIDACION.md` §10.
- `RAG_MIN_SCORE` es relevancia **relativa**, no coseno: un fragmento mediocre puede pasar si es el
  «menos malo». La protección es la abstención β y que el prompt prohíbe citar la literatura RAG como
  evidencia del modelo («PERICIA DE DOMINIO» ≠ «CONTEXTO DISPONIBLE»).

## 6. Cómo MEDIR la alucinación real (lo que falta y gasta)

Los controles deterministas no sustituyen una medición con la IA de producción. Plan mínimo:

1. **Par de referencia**: corrida real sobre `modelos/VaR_FRTB` (coherente) y
   `modelos/VaR_FixtureDrift` (4 discrepancias plantadas). Esperado (histórico, Haiku): ≈2,55/5 vs
   ≈1,62/5, citando las cifras contradictorias.
2. **Tasa de citas no verificadas**: en el JSON de resultados, `tabla_validacion[].citas_no_verificadas`.
   Fórmula: actividades con citas dudosas / actividades evaluadas. Meta de la hoja: 0 %. Hoy **no hay
   medición real** de este número con la IA de producción.
3. **Observaciones retiradas** (`afirmacion_invalidada`) y **abstenciones** (`abstenido`): cuántas, y si
   son legítimas.
4. **Concordancia agente↔validador**: `pruebas/calidad/evaluacion.py` (hoy bloqueado: falta la hoja
   `Modelo_Evaluacion`).
5. **Revisión humana por muestreo** con la rúbrica 0-1-2 (`modulos/evaluacion_experta.py`,
   `pruebas/rubrica_experta.md`).

## 7. Qué se cambió en el código (para revisar)

| Archivo | Cambio |
|---|---|
| `modulos/motor_ia.py` | `_verificar_citas(…, min_chars=40)`: iguala comillas «» “” y simples tras «→»; citas de inconsistencias con `min_chars=10`; juez NLI con `ventana_relevante`; campo nuevo `avisos_verificacion` (también en `tabla_validacion`) |
| `modulos/verificacion_cifras.py` | **Nuevo**: `cifras_ausentes`, `sin_cita_literal`, `ventana_relevante`, `es_sentinela` (sin IA) |
| `modulos/generador_markdown.py`, `modulos/generador_word.py`, `web/services/informe_web.py` | Pintan `avisos_verificacion` junto a las citas no verificadas |
| `modulos/automatizaciones.py` | Avisos por fila (evidencia a hoja no leída, cifras ausentes) en el Excel y en el anexo del informe |
| `web/services/chat_service.py` | Reglas 4 y 5 en `_PROMPT_JUEZ`; `verificar_respuesta()`; degradación APROBADO→PENDIENTE |
| `web/data/prompts_base.json` | Mismas reglas 4 y 5 en `chat_agente` (idéntico al código, con test) |
| `modulos/chunker.py` | Reglas anti-invención en los 2 prompts; aviso «RESUMEN generado por IA» en el contenido |
| `modulos/explicador_modelo.py` | `elementos_no_hallados()` y `seccion_verificacion()`; se añade al documento generado |
| `web/services/solo_informe_ia.py` | `citas_sin_respaldo()` (manuales) y guarda de cifras nuevas en `pulir()` |
| `tests/test_antialucinacion_brechas.py` | Pruebas nuevas, coste 0 (una por cada brecha cerrada) |
| `tests/test_solo_informe_ia.py` | Un test ajustado: el texto de entrada ahora lleva la cifra que la respuesta simulada repite |

Efecto operativo a vigilar: los avisos nuevos (`avisos_verificacion`) **no retiran nada**; solo se muestran. Y B1/B2 harán que **algunas observaciones antes aceptadas queden «retiradas»**
si sus citas eran inventadas (es el comportamiento buscado) y que el chat degrade más APROBADOS a
PENDIENTE. Si un validador ve mucho de esto, revisar si el modelo cita con paráfrasis en vez de copiar.
