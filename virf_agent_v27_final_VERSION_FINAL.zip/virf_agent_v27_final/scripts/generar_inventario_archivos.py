# -*- coding: utf-8 -*-
"""
scripts/generar_inventario_archivos.py — Inventario de TODOS los archivos del proyecto.

Genera `INVENTARIO_ARCHIVOS.md`: una línea por archivo con su propósito, leído del
propio archivo (docstring de los .py, primer título de los .md). Es el anexo de
`GUIA_TRASPASO_CONTEXTO.md`. Se regenera, no se edita a mano:

    .venv\\Scripts\\python scripts/generar_inventario_archivos.py

Coste 0: no llama a ninguna IA, no escribe fuera de INVENTARIO_ARCHIVOS.md.
Qué entra: lo versionado en git + lo nuevo sin ignorar. Quedan fuera `.env`, el
entorno virtual y los volcados (`archivo/`, `graphify-out/`), que se resumen aparte.
"""
from __future__ import annotations

import ast
import re
import subprocess
import sys
from collections import defaultdict
from datetime import date
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
SALIDA = RAIZ / "INVENTARIO_ARCHIVOS.md"
RESUMIR = ("archivo/", "graphify-out/")           # se cuentan, no se listan
SOLO_CONTEO = ("inputs/rag/", "inputs/repositorio_controles/", "inputs/papers/",
               "inputs/documentacion/", "inputs/calidad_datos/",
               "inputs/excel_procesos/", "inputs/implementacion/", "inputs/usos/",
               "docs/agente_corporativo/", "docs/evidencia/", "tests/fixtures/",
               "modelos/", "ejemplos/", "evidencias/", "web/static/", "web/data/")


def _archivos() -> list[str]:
    salida = subprocess.check_output(
        ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
        cwd=RAIZ).decode("utf-8", "replace")
    return sorted({f for f in salida.split("\0") if f and (RAIZ / f).is_file()
                   and f != ".env" and not f.endswith((".bundle", ".zip"))})


def _limpiar(texto: str, tope: int = 150) -> str:
    lineas = []
    for l in texto.splitlines():
        l = l.strip()
        if not l or set(l) <= set("=-─━#*_ "):
            continue
        lineas.append(l)
    t = " ".join(lineas)
    t = re.sub(r"\[[A-Za-z0-9·\- ]{1,30}\]", "", t).replace("|", "/")
    t = re.sub(r"\s+", " ", t).strip()
    return (t[: tope - 1] + "…") if len(t) > tope else t


def _describir(f: str) -> str:
    p = RAIZ / f
    try:
        if f.endswith(".py"):
            return _limpiar(ast.get_docstring(ast.parse(p.read_text(encoding="utf-8"))) or "")
        if f.endswith(".md"):
            for l in p.read_text(encoding="utf-8", errors="replace").splitlines():
                if l.startswith("#"):
                    return _limpiar(l.lstrip("# "))
        if f.endswith(".json"):
            return "datos JSON"
        if f.endswith(".csv"):
            return "tabla CSV"
        if f.endswith((".xlsx", ".xlsm")):
            return "libro Excel"
        if f.endswith((".docx", ".pdf", ".pptx")):
            return "documento"
    except Exception:                                 # nunca romper por un archivo raro
        return "(no se pudo leer)"
    return ""


def main() -> int:
    grupos: dict[str, list[str]] = defaultdict(list)
    resumen: dict[str, int] = defaultdict(int)
    todos = subprocess.check_output(
        ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard"],
        cwd=RAIZ).decode("utf-8", "replace").split("\0")
    for f in todos:
        for pref in RESUMIR:
            if f.startswith(pref):
                resumen[pref] += 1
    for f in _archivos():
        if f.startswith(RESUMIR):
            continue
        carpeta = f.rsplit("/", 1)[0] if "/" in f else "(raíz)"
        grupos[carpeta].append(f)

    out = [f"# Inventario de archivos — VIRF Agent",
           "",
           f"> Generado el {date.today().isoformat()} por `scripts/generar_inventario_archivos.py` "
           "(no editar a mano: se regenera). Anexo de `GUIA_TRASPASO_CONTEXTO.md`.",
           "",
           f"Total listado: **{sum(len(v) for v in grupos.values())}** archivos en "
           f"**{len(grupos)}** carpetas. Resumidos aparte: "
           + ", ".join(f"`{k}` ({v})" for k, v in resumen.items()) + ".",
           "",
           "Leyenda: las carpetas de datos (evidencia, corpus, fixtures, salidas) se resumen con "
           "su conteo por tipo; el código, las pruebas y los documentos se listan archivo a archivo.",
           ""]
    for carpeta in sorted(grupos, key=lambda c: (c != "(raíz)", c)):
        archivos = grupos[carpeta]
        out.append(f"## `{carpeta}/`" if carpeta != "(raíz)" else "## Raíz del proyecto")
        out.append("")
        if (carpeta + "/").startswith(SOLO_CONTEO) or any(
                (carpeta + "/").startswith(s) for s in SOLO_CONTEO):
            tipos: dict[str, int] = defaultdict(int)
            for f in archivos:
                tipos[Path(f).suffix.lower() or "(sin ext.)"] += 1
            out.append(f"{len(archivos)} archivos — " +
                       ", ".join(f"{n}× `{e}`" for e, n in sorted(tipos.items())) + ".")
            nombres = [Path(f).name for f in archivos]
            if len(nombres) <= 12:
                out.append("")
                out.extend(f"- `{n}`" for n in nombres)
            out.append("")
            continue
        out.append("| Archivo | Qué es |")
        out.append("|---|---|")
        for f in archivos:
            out.append(f"| `{Path(f).name}` | {_describir(f)} |")
        out.append("")
    SALIDA.write_text("\n".join(out), encoding="utf-8")
    print(f"OK: {SALIDA.name}: {sum(len(v) for v in grupos.values())} archivos, "
          f"{len(grupos)} carpetas")
    return 0


if __name__ == "__main__":
    sys.exit(main())
