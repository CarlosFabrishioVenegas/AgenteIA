# -*- coding: utf-8 -*-
"""
scripts/generar_referencia_tecnica.py — Referencia técnica EXACTA, leída del código.

Genera `REFERENCIA_TECNICA.md`: lo que una persona (o una IA) necesita saber con
precisión y que NO debe copiarse a mano porque envejece —

  1. Flags de `agente.py`            (del `argparse` real)
  2. Variables de entorno           (nombre · tipo · valor por defecto · dónde se lee)
  3. Endpoints de la web            (método · ruta · archivo · función)
  4. Parámetros de negocio          (tiers, pesos por ámbito, escala, semáforo)
  5. Proveedores y catálogo de modelos
  6. Dependencias fijadas           (de los requirements)
  7. Pruebas                        (archivo · nº de tests · qué cubre)
  8. Nodos centrales del grafo      (si existe graphify-out/graph.json)

Se regenera, no se edita a mano:

    .venv\\Scripts\\python scripts/generar_referencia_tecnica.py

Coste 0. Solo lee archivos del proyecto; escribe únicamente REFERENCIA_TECNICA.md.
Todo se extrae con `ast` (no se importa ni se ejecuta código del agente), salvo
`config.dominio`, que es una tabla de constantes sin efectos.
"""
from __future__ import annotations

import ast
import json
import re
import subprocess
import sys
from datetime import date
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
SALIDA = RAIZ / "REFERENCIA_TECNICA.md"
LECTORES_ENV = {"getenv", "get", "_entero", "_decimal", "_booleano", "_num_env", "_texto"}


def _tracked(patron: str) -> list[Path]:
    out = subprocess.check_output(
        ["git", "ls-files", "-z", "--cached", "--others", "--exclude-standard", "--", patron],
        cwd=RAIZ).decode("utf-8", "replace")
    return sorted(RAIZ / f for f in out.split("\0") if f and (RAIZ / f).is_file()
                  and not f.startswith(("archivo/", "graphify-out/", "_respaldo_ui/")))


def _ast(p: Path):
    try:
        return ast.parse(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def _limpia(t: str, tope: int = 160) -> str:
    t = re.sub(r"\s+", " ", (t or "").replace("|", "/")).strip()
    return t if len(t) <= tope else t[: tope - 1] + "…"


def _lit(n) -> str:
    try:
        return repr(ast.literal_eval(n))
    except Exception:
        try:
            return ast.unparse(n)
        except Exception:
            return "?"


# ── 1 · flags ────────────────────────────────────────────────────────────────
def flags() -> list[str]:
    t = _ast(RAIZ / "agente.py")
    filas = []
    for n in ast.walk(t):
        if isinstance(n, ast.Call) and getattr(n.func, "attr", "") == "add_argument":
            nombres = [a.value for a in n.args if isinstance(a, ast.Constant)]
            kw = {k.arg: k.value for k in n.keywords}
            accion = _lit(kw["action"]).strip("'") if "action" in kw else "valor"
            filas.append(f"| `{' / '.join(nombres)}` | {accion} | "
                         f"{_lit(kw['default']) if 'default' in kw else '—'} | "
                         f"{_limpia(_lit(kw['help']).strip(chr(39)).strip(chr(34))) if 'help' in kw else ''} |")
    return ["| Flag | Tipo | Por defecto | Qué hace |", "|---|---|---|---|"] + filas


# ── 2 · variables de entorno ─────────────────────────────────────────────────
def entorno() -> list[str]:
    vistos: dict[str, dict] = {}
    for p in _tracked("*.py"):
        rel = p.relative_to(RAIZ).as_posix()
        if rel.startswith(("tests/", "pruebas/")):
            continue
        t = _ast(p)
        if t is None:
            continue
        for n in ast.walk(t):
            if not isinstance(n, ast.Call) or not n.args:
                continue
            f = n.func
            nombre_f = f.attr if isinstance(f, ast.Attribute) else getattr(f, "id", "")
            if nombre_f not in LECTORES_ENV:
                continue
            a0 = n.args[0]
            if not (isinstance(a0, ast.Constant) and isinstance(a0.value, str)
                    and re.fullmatch(r"[A-Z][A-Z0-9_]{2,}", a0.value)):
                continue
            if nombre_f == "get" and "environ" not in ast.unparse(f):
                continue
            defecto = _lit(n.args[1]) if len(n.args) > 1 else "—"
            tipo = {"_entero": "entero", "_decimal": "decimal", "_booleano": "booleano"}.get(
                nombre_f, "texto")
            d = vistos.setdefault(a0.value, {"tipo": tipo, "def": defecto, "donde": []})
            if d["def"] == "—" and defecto != "—":
                d["def"], d["tipo"] = defecto, tipo
            d["donde"].append(f"{rel}:{n.lineno}")
    filas = ["| Variable | Tipo | Por defecto | Se lee en |", "|---|---|---|---|"]
    for k in sorted(vistos):
        d = vistos[k]
        donde = ", ".join(f"`{x}`" for x in d["donde"][:3]) + (" …" if len(d["donde"]) > 3 else "")
        filas.append(f"| `{k}` | {d['tipo']} | `{_limpia(d['def'], 50)}` | {donde} |")
    return [f"{len(vistos)} variables.", ""] + filas


# ── 3 · endpoints ────────────────────────────────────────────────────────────
def endpoints() -> list[str]:
    filas = []
    for p in _tracked("web/*.py") + _tracked("web/routers/*.py"):
        t = _ast(p)
        if t is None:
            continue
        prefijo = ""
        for n in ast.walk(t):
            if isinstance(n, ast.Assign) and isinstance(n.value, ast.Call) \
                    and getattr(n.value.func, "id", "") == "APIRouter":
                for k in n.value.keywords:
                    if k.arg == "prefix":
                        prefijo = _lit(k.value).strip("'")
        for n in ast.walk(t):
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for d in n.decorator_list:
                    if isinstance(d, ast.Call) and isinstance(d.func, ast.Attribute) \
                            and d.func.attr in {"get", "post", "put", "delete", "patch", "websocket"} \
                            and d.args and isinstance(d.args[0], ast.Constant):
                        filas.append((prefijo + d.args[0].value, d.func.attr.upper(),
                                      p.relative_to(RAIZ).as_posix(), n.name,
                                      _limpia(ast.get_docstring(n) or "", 90)))
    filas.sort()
    return [f"{len(filas)} endpoints.", "", "| Método | Ruta | Archivo · función | Qué hace |", "|---|---|---|---|"] + \
        [f"| {m} | `{r}` | `{a}` · `{f}` | {d} |" for r, m, a, f, d in filas]


# ── 4 · negocio ──────────────────────────────────────────────────────────────
def negocio() -> list[str]:
    sys.path.insert(0, str(RAIZ))
    out = []
    try:
        from config import dominio as d
        out += ["**Tiers válidos:** " + ", ".join(f"`{k}`→`{v}`" for k, v in d.TIERS_VALIDOS.items()), "",
                "**Pesos por ámbito** (deben sumar exactamente 1,00):", "",
                "| Ámbito | Peso | Referencia normativa |", "|---|---:|---|"]
        for k, v in d.AMBITO_PESOS.items():
            out.append(f"| {k} | {v} | {_limpia(str(d.AMBITO_PESOS_REFS.get(k, '')), 140)} |")
        out += ["", f"Suma de pesos: **{sum(d.AMBITO_PESOS.values()):.2f}**", "",
                f"**Escala de puntaje:** `{d.ESCALA_PUNTAJE}`", "",
                f"**Semáforo:** `{d.SCORE_SEMAFORO}`", "",
                f"**Extensiones soportadas:** `{sorted(d.EXTENSIONES_SOPORTADAS) if hasattr(d.EXTENSIONES_SOPORTADAS, '__iter__') else d.EXTENSIONES_SOPORTADAS}`"]
    except Exception as e:
        out.append(f"(no se pudo leer config.dominio: {e})")
    return out


# ── 5 · proveedores y modelos ────────────────────────────────────────────────
def proveedores() -> list[str]:
    t = _ast(RAIZ / "config" / "ia.py")
    out = ["| Proveedor | Estado en producción |", "|---|---|"]
    for n in ast.walk(t):
        if isinstance(n, ast.Assign) and any(getattr(x, "id", "") == "PROVEEDORES" for x in n.targets):
            d = ast.literal_eval(n.value)
            out += [f"| `{k}` | {v} |" for k, v in d.items()]
        if isinstance(n, ast.Assign) and any(getattr(x, "id", "") == "PROVEEDORES_SOLO_DESARROLLO" for x in n.targets):
            dev = ast.literal_eval(n.value)
    out += ["", "Ejecutan además en `MODO=debug|desarrollo`: " + ", ".join(f"`{x}`" for x in dev), "",
            "**Catálogo de modelos** (`config/modelos.py`):", "",
            "| Modelo | Contexto (tokens) | Máx. salida | Parámetro de tokens | ¿Admite temperature? | Familia |",
            "|---|---:|---:|---|---|---|"]
    t = _ast(RAIZ / "config" / "modelos.py")
    for n in ast.walk(t):
        if isinstance(n, ast.AnnAssign) and getattr(n.target, "id", "") == "CATALOGO_MODELOS":
            for k, v in zip(n.value.keys, n.value.values):
                kw = {x.arg: x.value for x in v.keywords}
                g = lambda c, dflt: _lit(kw[c]).strip("'") if c in kw else dflt   # noqa: E731
                out.append(f"| `{k.value}` | {g('contexto_tokens', '?')} | {g('max_salida_tokens', '?')} | "
                           f"`{g('param_tokens', 'max_tokens')}` | "
                           f"{'no' if g('admite_temperature', 'True') == 'False' else 'sí'} | {g('familia', 'gpt')} |")
    return out


# ── 6 · dependencias ─────────────────────────────────────────────────────────
def dependencias() -> list[str]:
    out = []
    for f in ("requirements.txt", "web/requirements_web.txt"):
        out += [f"**`{f}`**", "", "| Paquete | Versión | Comentario |", "|---|---|---|"]
        for l in (RAIZ / f).read_text(encoding="utf-8").splitlines():
            if not l.strip() or l.lstrip().startswith("#"):
                continue
            cuerpo, _, com = l.partition("#")
            m = re.match(r"\s*([A-Za-z0-9_.\-\[\]]+)\s*(==|>=)\s*([^\s;]+)", cuerpo)
            if m:
                out.append(f"| `{m.group(1)}` | `{m.group(2)}{m.group(3)}` | {_limpia(com, 90)} |")
        out.append("")
    return out


# ── 7 · pruebas ──────────────────────────────────────────────────────────────
def pruebas() -> list[str]:
    filas, total = [], 0
    for p in _tracked("tests/*.py") + _tracked("tests/skills/*.py") + _tracked("pruebas/*.py") + \
            _tracked("pruebas/seguridad/*.py"):
        t = _ast(p)
        if t is None:
            continue
        n = sum(1 for x in ast.walk(t) if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef))
                and x.name.startswith("test"))
        if p.name.startswith("test_") or p.parent.name in ("seguridad",):
            total += n
            doc = _limpia(re.sub(r"[═\-─]{3,}", " ", ast.get_docstring(t) or ""), 130)
            filas.append(f"| `{p.relative_to(RAIZ).as_posix()}` | {n} | {doc} |")
    return [f"{len(filas)} archivos de prueba · {total} funciones `test*` "
            "(pytest expande las parametrizadas: el total ejecutado es mayor).", "",
            "| Archivo | Tests | Qué cubre |", "|---|---:|---|"] + filas


# ── 8 · grafo ────────────────────────────────────────────────────────────────
def grafo() -> list[str]:
    g = RAIZ / "graphify-out" / "graph.json"
    if not g.exists():
        return ["(no existe `graphify-out/graph.json`; ejecuta `graphify update .`)"]
    try:
        d = json.loads(g.read_text(encoding="utf-8"))
        nodos, aristas = d.get("nodes", []), d.get("links", d.get("edges", []))
        grado: dict = {}
        for e in aristas:
            for k in ("source", "target"):
                grado[e[k]] = grado.get(e[k], 0) + 1
        por_id = {n["id"]: n for n in nodos}
        top = sorted(grado.items(), key=lambda x: -x[1])
        out = [f"{len(nodos)} nodos · {len(aristas)} aristas.", "",
               "| Nodo central (hub) | Archivo | Conexiones |", "|---|---|---:|"]
        c = 0
        for i, gr in top:
            n = por_id.get(i, {})
            f = n.get("source_file", "")
            if not f or f.startswith(("archivo/", "tests/", "_respaldo_ui/")):
                continue
            out.append(f"| `{n.get('label', i)}` | `{f}` | {gr} |")
            c += 1
            if c >= 25:
                break
        return out
    except Exception as e:
        return [f"(no se pudo leer el grafo: {e})"]


def main() -> int:
    secciones = [
        ("1. Flags de `agente.py`", flags()),
        ("2. Variables de entorno", entorno()),
        ("3. Endpoints de la web", endpoints()),
        ("4. Parámetros de negocio (`config/dominio.py`)", negocio()),
        ("5. Proveedores de IA y catálogo de modelos", proveedores()),
        ("6. Dependencias fijadas", dependencias()),
        ("7. Pruebas", pruebas()),
        ("8. Nodos centrales del grafo de código", grafo()),
    ]
    out = ["# Referencia técnica — VIRF Agent (generada del código)", "",
           f"> Generada el {date.today().isoformat()} por `scripts/generar_referencia_tecnica.py`. "
           "**No editar a mano**: se regenera. Complementa `GUIA_TRASPASO_CONTEXTO.md` "
           "e `INVENTARIO_ARCHIVOS.md`.", ""]
    for titulo, cuerpo in secciones:
        out += [f"## {titulo}", ""] + cuerpo + [""]
    SALIDA.write_text("\n".join(out), encoding="utf-8")
    print(f"OK: {SALIDA.name} ({len(out)} lineas)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
