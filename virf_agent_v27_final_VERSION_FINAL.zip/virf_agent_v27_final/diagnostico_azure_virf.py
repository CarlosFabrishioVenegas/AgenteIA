#!/usr/bin/env python3
"""
diagnostico_azure_virf.py — diagnóstico por capas de la conexión con Azure OpenAI.

    .\\.venv\\Scripts\\python.exe diagnostico_azure_virf.py
    .\\.venv\\Scripts\\python.exe diagnostico_azure_virf.py --sin-llamada   # sin tocar el modelo

Recorre, en orden, las capas por las que pasa una llamada del agente:

    0. Python / venv          4. TLS / certificado
    1. .env                   5. Autenticación (key)
    2. Endpoint               6. Deployment
    3. DNS / TCP 443          7. Respuesta del modelo

y marca cada una como OK, WARN, FAIL o PENDIENTE (no se pudo comprobar porque
falló una capa anterior). La primera FAIL es la que hay que arreglar.

Garantías:
  · Nunca imprime ni escribe la API key (ni su longitud ni un prefijo).
  · Nunca desactiva la verificación TLS: usa exactamente la misma configuración
    de red que el agente (`config.red.cliente_http`: VIRF_CA_BUNDLE o
    VIRF_TLS_ALMACEN_SISTEMA). Con VIRF_TLS_INSECURE=1 la capa 4 sale en FAIL.
  · Del .env solo lee y muestra NOMBRES de variables, nunca valores.
  · Hace como máximo dos peticiones al recurso: una sin credencial (TLS) y una
    con la mínima llamada al modelo (capas 5–7). `--sin-llamada` omite esta.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import socket
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import urlsplit

RAIZ = Path(__file__).resolve().parent
if str(RAIZ) not in sys.path:
    sys.path.insert(0, str(RAIZ))

OK, WARN, FAIL, PEND = "OK", "WARN", "FAIL", "PENDIENTE"

CAPAS = ("Python / venv", ".env", "Endpoint", "DNS / TCP 443", "TLS / certificado",
         "Autenticación (key)", "Deployment", "Respuesta del modelo")

# Variables de configuración NO secreta que se esperan en el .env.
ESPERADAS = ("IA_PROVEEDOR", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT",
             "AZURE_OPENAI_API_VERSION", "MODO", "VIRF_FUENTE_SECRETOS")
OBLIGATORIAS = ("AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT")
# Nombres que delatan un secreto: nunca deben tener valor en el .env.
_PATRON_SECRETO = re.compile(r"(API_KEY|SECRET|PASSWORD|CLAVE_FIRMA|CLAVE_CIFRADO|TOKEN)$")
# Variables de TLS que el agente NO lee (restos de guías antiguas).
_TLS_AJENAS = ("AZURE_OPENAI_VERIFY_SSL", "VERIFY_SSL", "PYTHONHTTPSVERIFY",
               "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE", "SSL_CERT_FILE")


@dataclass
class Capa:
    numero: int
    estado: str = PEND
    detalle: str = "no comprobada"
    acciones: list[str] = field(default_factory=list)


@dataclass
class Contexto:
    """Lo que una capa deja para las siguientes."""
    endpoint: str = ""
    host: str = ""
    deployment: str = ""
    api_version: str = ""
    fuente_ca: str = ""
    clave: str = ""          # solo en memoria; nunca se imprime


# ── Utilidades ────────────────────────────────────────────────────────────

def _nombres_env(ruta: Path) -> dict[str, bool]:
    """{NOMBRE: tiene_valor} del .env. El valor no se devuelve."""
    nombres: dict[str, bool] = {}
    try:
        texto = ruta.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return nombres
    for linea in texto.splitlines():
        m = re.match(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", linea)
        if m:
            valor = m.group(2).split(" #")[0].strip().strip("'\"")
            nombres[m.group(1)] = nombres.get(m.group(1), False) or bool(valor)
    return nombres


def _ocultar(texto: str, ctx: Contexto) -> str:
    """Quita la clave de cualquier texto antes de mostrarlo (por si un error la cita)."""
    texto = str(texto)
    if ctx.clave and len(ctx.clave) >= 8:
        texto = texto.replace(ctx.clave, "***")
    return texto[:400]


# ── Capas ─────────────────────────────────────────────────────────────────

def capa_python(c: Capa, ctx: Contexto) -> None:
    v = sys.version_info
    en_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    dentro = Path(sys.prefix).resolve().is_relative_to(RAIZ) if en_venv else False
    faltan = []
    for mod in ("httpx", "openai", "dotenv"):
        try:
            __import__(mod)
        except ImportError:
            faltan.append(mod)
    desc = f"Python {v.major}.{v.minor}.{v.micro} · {sys.executable}"
    if v < (3, 10):
        c.estado, c.detalle = FAIL, desc + " — el proyecto necesita Python ≥ 3.10."
        return
    if not en_venv or not dentro:
        c.estado, c.detalle = FAIL, desc + " — no es el entorno virtual del proyecto."
        c.acciones.append("Ejecuta con .\\.venv\\Scripts\\python.exe (nunca el Python global).")
        return
    if faltan:
        c.estado, c.detalle = FAIL, desc + f" — faltan paquetes: {', '.join(faltan)}."
        c.acciones.append(".\\.venv\\Scripts\\python.exe -m pip install -r requirements.txt")
        return
    c.estado, c.detalle = OK, desc
    if v < (3, 12):
        c.estado = WARN
        c.detalle += " — funciona, pero la guía de despliegue pide 3.12."


def capa_env(c: Capa, ctx: Contexto, ruta_env: Path) -> None:
    nombres = _nombres_env(ruta_env)
    fallos, avisos = [], []
    if not ruta_env.is_file():
        avisos.append(f"no hay {ruta_env.name}: la configuración debe venir del entorno del proceso")
    secretos = sorted(n for n, con_valor in nombres.items()
                      if con_valor and _PATRON_SECRETO.search(n))
    if secretos:
        fallos.append("secretos en texto plano en el .env: " + ", ".join(secretos))
        c.acciones.append(f"Borra del .env: {', '.join(secretos)}. Considéralas expuestas: "
                          "rótalas en su portal y carga la de Azure con "
                          '$env:AZURE_OPENAI_API_KEY = Read-Host "API key".')
    from config import parametros as par            # misma lectura que el agente
    if par.TLS_INSECURE:
        fallos.append("VIRF_TLS_INSECURE=1 desactiva la verificación TLS")
        c.acciones.append("Borra VIRF_TLS_INSECURE (o ponla a 0). Para la CA usa VIRF_CA_BUNDLE "
                          "o VIRF_TLS_ALMACEN_SISTEMA=1.")
    ajenas = [n for n in _TLS_AJENAS if n in nombres]
    if ajenas:
        avisos.append(f"{', '.join(ajenas)} no la(s) lee el agente: bórrala(s) del .env")
    proveedor = str(par.IA_PROVEEDOR).strip().lower()
    if proveedor != "azure_openai":
        fallos.append(f"IA_PROVEEDOR={proveedor} (debe ser azure_openai)")
    ctx.endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()
    ctx.deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "").strip()
    faltan = [n for n, v in zip(OBLIGATORIAS, (ctx.endpoint, ctx.deployment)) if not v]
    if faltan:
        fallos.append("faltan " + ", ".join(faltan))
    if "MODO" not in os.environ:
        avisos.append("MODO no declarado: el agente asume produccion (clave desde Key Vault)")
    otras = sorted(n for n in nombres if n not in ESPERADAS and n not in secretos
                   and n not in ajenas and n not in ("VIRF_CA_BUNDLE", "VIRF_TLS_ALMACEN_SISTEMA",
                                                     "VIRF_VALIDAR_CONEXION"))
    resumen = f"{len(nombres)} variables en {ruta_env.name}"
    if otras:
        resumen += f" (además de las esperadas: {', '.join(otras)})"
    if fallos:
        c.estado, c.detalle = FAIL, "; ".join(fallos + avisos) + f". {resumen}"
    elif avisos:
        c.estado, c.detalle = WARN, "; ".join(avisos) + f". {resumen}"
    else:
        c.estado, c.detalle = OK, resumen
    ctx.api_version = par.AZURE_API_VERSION            # la misma que usa el agente


def capa_endpoint(c: Capa, ctx: Contexto) -> None:
    if not ctx.endpoint:
        c.estado, c.detalle = FAIL, "AZURE_OPENAI_ENDPOINT vacío."
        c.acciones.append("Declara AZURE_OPENAI_ENDPOINT con la URL https:// del recurso "
                          "(portal de Azure → Keys and Endpoint).")
        return
    from config.red import HostNoPermitido, verificar_host_ia
    try:
        ctx.host = verificar_host_ia(ctx.endpoint)
    except HostNoPermitido as exc:
        c.estado, c.detalle = FAIL, str(exc).replace("❌ ", "")
        return
    c.estado, c.detalle = OK, f"{ctx.endpoint} (api-version {ctx.api_version})"


def capa_red(c: Capa, ctx: Contexto) -> None:
    from urllib.request import getproxies            # HTTPS_PROXY, como httpx
    proxy = getproxies().get("https", "")
    destino, puerto, via = ctx.host, 443, "directo"
    if proxy:
        p = urlsplit(proxy if "://" in proxy else f"http://{proxy}")
        destino, puerto, via = p.hostname or "", p.port or 8080, f"vía proxy {p.hostname}:{p.port or 8080}"
    try:
        ips = sorted({i[4][0] for i in socket.getaddrinfo(destino, puerto, type=socket.SOCK_STREAM)})
    except socket.gaierror as exc:
        c.estado, c.detalle = FAIL, f"DNS no resuelve {destino}: {exc}"
        c.acciones.append("Revisa la red/VPN y el DNS corporativo (nslookup " + destino + ").")
        return
    try:
        t0 = time.perf_counter()
        socket.create_connection((destino, puerto), timeout=8).close()
        ms = (time.perf_counter() - t0) * 1000
    except OSError as exc:
        c.estado, c.detalle = FAIL, f"TCP {destino}:{puerto} sin respuesta ({via}): {exc}"
        c.acciones.append(f"Test-NetConnection {destino} -Port {puerto}  (firewall o proxy)")
        return
    c.estado, c.detalle = OK, f"{destino} → {', '.join(ips[:3])} · TCP {puerto} en {ms:.0f} ms ({via})"


def _cliente(ctx: Contexto):
    """El mismo cliente HTTP que usa el agente (misma CA, mismo proxy)."""
    import httpx
    from config import parametros as p
    from config.red import cliente_http
    if p.CA_BUNDLE:
        ctx.fuente_ca = f"VIRF_CA_BUNDLE ({Path(p.CA_BUNDLE).name})"
    elif p.TLS_ALMACEN_SISTEMA:
        ctx.fuente_ca = "almacén del sistema (VIRF_TLS_ALMACEN_SISTEMA)"
    else:
        ctx.fuente_ca = "certifi (por defecto de Python)"
    return cliente_http() or httpx.Client(timeout=float(p.HTTP_TIMEOUT))


def capa_tls(c: Capa, ctx: Contexto, fabrica: Callable) -> None:
    from config.parametros import TLS_INSECURE
    if TLS_INSECURE:
        c.estado, c.detalle = FAIL, "verificación TLS desactivada (VIRF_TLS_INSECURE=1): no se prueba así."
        return
    try:
        with fabrica(ctx) as cli:
            r = cli.get(f"https://{ctx.host}/", timeout=20)
    except ValueError as exc:                       # PEM inexistente/corrupto, falta truststore
        c.estado, c.detalle = FAIL, str(exc).replace("❌ ", "").splitlines()[0]
        c.acciones.append(str(exc).strip())
        return
    except Exception as exc:                        # noqa: BLE001
        txt = _ocultar(exc, ctx)
        c.estado = FAIL
        if "CERTIFICATE_VERIFY_FAILED" in txt or "certificate verify failed" in txt.lower():
            c.detalle = f"CERTIFICATE_VERIFY_FAILED con {ctx.fuente_ca}: el proxy corporativo inspecciona TLS."
            c.acciones += [
                "Opción A: .\\.venv\\Scripts\\python.exe -m pip install truststore  y en el .env "
                "VIRF_TLS_ALMACEN_SISTEMA=1 (usa el almacén de Windows, como el navegador).",
                "Opción B: exporta la CA corporativa a PEM y declara VIRF_CA_BUNDLE=<ruta>.pem.",
                "Nunca desactives la verificación TLS."]
        else:
            c.detalle = f"{type(exc).__name__}: {txt}"
        return
    c.estado, c.detalle = OK, f"handshake verificado con {ctx.fuente_ca} (HTTP {r.status_code} sin credencial)"


def capa_clave(c: Capa, ctx: Contexto) -> bool:
    """Lee la clave de la fuente configurada (sin mostrarla). True si la hay."""
    from config.secretos import SecretoNoDisponible, fuente_secretos, obtener_secreto
    try:
        fuente = fuente_secretos()
        ctx.clave = obtener_secreto("AZURE_OPENAI_API_KEY", obligatorio=False)
    except SecretoNoDisponible as exc:
        c.estado, c.detalle = FAIL, str(exc).replace("❌ ", "")
        return False
    if not ctx.clave:
        c.estado, c.detalle = FAIL, f"AZURE_OPENAI_API_KEY no está cargada (fuente «{fuente}»)."
        if fuente == "entorno":
            c.acciones.append('En esta ventana de PowerShell: $env:AZURE_OPENAI_API_KEY = Read-Host "API key"')
        return False
    c.detalle = f"clave presente (fuente «{fuente}»)"
    return True


def capas_llamada(c5: Capa, c6: Capa, c7: Capa, ctx: Contexto, fabrica: Callable) -> None:
    """Una llamada mínima al deployment decide las capas 5, 6 y 7."""
    url = (f"{ctx.endpoint.rstrip('/')}/openai/deployments/{ctx.deployment}"
           f"/chat/completions?api-version={ctx.api_version}")
    cuerpo = {"messages": [
        {"role": "system", "content": "Responde solo con un objeto JSON."},
        {"role": "user", "content": 'Devuelve exactamente {"ok": true}'}],
        "response_format": {"type": "json_object"}}
    try:
        with fabrica(ctx) as cli:
            t0 = time.perf_counter()
            r = cli.post(url, json=cuerpo, headers={"api-key": ctx.clave}, timeout=60)
            ms = (time.perf_counter() - t0) * 1000
    except Exception as exc:                        # noqa: BLE001
        c5.estado, c5.detalle = WARN, c5.detalle + " · sin respuesta del servicio"
        c6.estado, c6.detalle = FAIL, f"{type(exc).__name__}: {_ocultar(exc, ctx)}"
        return
    try:
        datos = r.json()
    except ValueError:
        datos = {}
    error = datos.get("error") or {}
    msg = _ocultar(f"{error.get('code', '')} {error.get('message', '')}".strip(), ctx)
    if r.status_code in (401, 403):
        c5.estado, c5.detalle = FAIL, f"HTTP {r.status_code}: la clave no es válida para este recurso. {msg}"
        c5.acciones.append("Carga la clave vigente (Key 1 regenerada) con Read-Host; no la pegues en ningún archivo.")
        return
    c5.estado = OK
    c5.detalle += " · aceptada por el recurso"
    if r.status_code == 404:
        c6.estado, c6.detalle = FAIL, f"HTTP 404 con deployment «{ctx.deployment}». {msg}"
        c6.acciones.append("Compara AZURE_OPENAI_DEPLOYMENT con el nombre exacto en el portal "
                           "(Azure AI Foundry → Deployments).")
        return
    if r.status_code == 429:
        c6.estado, c6.detalle = WARN, f"HTTP 429: el deployment existe pero no tiene cuota ahora. {msg}"
        return
    if r.status_code >= 400:
        c6.estado, c6.detalle = FAIL, f"HTTP {r.status_code}. {msg}"
        return
    modelo = datos.get("model", "desconocido")
    c6.estado, c6.detalle = OK, f"«{ctx.deployment}» sirve el modelo {modelo}"
    try:
        contenido = datos["choices"][0]["message"]["content"]
        valido = json.loads(contenido)
    except (KeyError, IndexError, TypeError, ValueError):
        c7.estado, c7.detalle = FAIL, f"la respuesta no es JSON válido ({ms:.0f} ms)."
        return
    c7.estado, c7.detalle = OK, f"JSON válido {json.dumps(valido, ensure_ascii=False)} en {ms:.0f} ms"


# ── Orquestación ──────────────────────────────────────────────────────────

def diagnosticar(ruta_env: Optional[Path] = None, sin_llamada: bool = False,
                 fabrica: Callable = _cliente) -> list[Capa]:
    capas = [Capa(i) for i in range(len(CAPAS))]
    ctx = Contexto()
    import config.parametros  # noqa: F401  — carga el .env igual que el agente

    def bloquear(desde: int, motivo: int) -> list[Capa]:
        for k in capas[desde:]:
            if k.estado == PEND:
                k.detalle = f"bloqueada: primero arregla la capa {motivo}"
        return capas

    capa_python(capas[0], ctx)
    if capas[0].estado == FAIL:
        return bloquear(1, 0)
    capa_env(capas[1], ctx, ruta_env or (RAIZ / ".env"))
    capa_endpoint(capas[2], ctx)
    if capas[2].estado == FAIL:
        return bloquear(3, 2)
    capa_red(capas[3], ctx)
    if capas[3].estado == FAIL:
        return bloquear(4, 3)
    capa_tls(capas[4], ctx, fabrica)
    if capas[4].estado == FAIL:
        return bloquear(5, 4)
    if not capa_clave(capas[5], ctx):
        return bloquear(6, 5)
    if capas[1].estado == FAIL:
        capas[5].detalle += " · llamada no hecha hasta corregir el .env"
        return bloquear(5, 1)
    if sin_llamada:
        capas[5].detalle += " · sin validar contra el recurso (--sin-llamada)"
        for k in capas[5:]:
            k.detalle = k.detalle if k.numero == 5 else "omitida (--sin-llamada)"
        return capas
    capas_llamada(capas[5], capas[6], capas[7], ctx, fabrica)
    if capas[6].estado == FAIL:
        bloquear(7, 6)
    if capas[5].estado == FAIL:
        bloquear(6, 5)
    return capas


def imprimir(capas: list[Capa]) -> None:
    sep = "═" * 74
    print(f"\n{sep}\n  DIAGNÓSTICO VIRF → AZURE OPENAI (por capas)\n{sep}")
    for k in capas:
        print(f"  [{k.estado:^9}] {k.numero}. {CAPAS[k.numero]:<22} {k.detalle}")
    primera = next((k for k in capas if k.estado == FAIL), None)
    print(sep)
    if primera:
        print(f"  ➜ Primera capa en FAIL: {primera.numero}. {CAPAS[primera.numero]}")
        for a in primera.acciones:
            print(f"     · {a}")
    elif all(k.estado == OK for k in capas):
        print("  ➜ Todas las capas en OK.")
    else:
        print("  ➜ Sin FAIL. Revisa las capas en WARN o PENDIENTE.")
    print(f"{sep}\n  (La API key no se muestra en ningún caso.)\n")


def main(argv: Optional[list[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--sin-llamada", action="store_true",
                    help="no hace la llamada al modelo (capas 5–7 sin validar contra el recurso)")
    args = ap.parse_args(argv)
    # Consola de Windows en cp1252: sin esto, «═» o «→» abortan el informe.
    for flujo in (sys.stdout, sys.stderr):
        try:
            flujo.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    capas = diagnosticar(sin_llamada=args.sin_llamada)
    imprimir(capas)
    return 1 if any(k.estado == FAIL for k in capas) else 0


if __name__ == "__main__":
    sys.exit(main())
