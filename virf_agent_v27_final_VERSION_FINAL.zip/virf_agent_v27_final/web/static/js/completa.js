// ── VALIDACIÓN COMPLETA ──────────────────────────────────────────────
//
// Cinco chats especializados (00 Diagnóstico · 01 Control de datos ·
// 02 Modelamiento · 03 Impactos · 04 Seguimiento). En cada iteración el agente
// ENTREGA un notebook ({etapa}ITERn.ipynb) que el validador ejecuta donde están
// los datos; el notebook genera {etapa}_resultadoITERn.xlsx, que vuelve al chat
// con comentarios e imágenes de sustento para la siguiente iteración. El
// validador cierra cada etapa; con las cinco cerradas, el modelo está listo
// para enviarse a validar. La modalidad (normal | completa) es explícita.
// Usa utilidades de app.js: $, $$, pedirJSON, escapeHtml, mostrarVista,
// estado, fmtTs, formatearMensajeChat, VISTA_A_NAV.

const VC = { etapa: "00", datos: null, resumen: null, archivos: [], enviando: false };
const VC_IMG = /\.(png|jpe?g|gif|bmp|webp)$/i;

function vcModalidad() {
    return (estado.modelo && estado.modelo.modalidad) || "normal";
}

function pintarModalidad() {
    const completa = vcModalidad() === "completa";
    const btn = $("#btn-modalidad");
    if (btn) btn.setAttribute("aria-pressed", completa ? "true" : "false");
    const est = $("#modalidad-estado");
    if (est) est.textContent = completa ? "completa" : "normal";
    const nav = $("#nav-completa");
    if (nav) nav.hidden = !completa;
    if (completa) vcCargarResumen();
}

async function alternarModalidad() {
    const nueva = vcModalidad() === "completa" ? "normal" : "completa";
    const msg = nueva === "completa"
        ? "¿Pasar este modelo a VALIDACIÓN COMPLETA?\n\nSe habilitan 5 chats (00–04). En cada uno el agente te entrega un notebook; lo ejecutas, genera un Excel y se lo devuelves con tus comentarios e imágenes hasta que la etapa cumpla."
        : "¿Volver a VALIDACIÓN NORMAL?\n\nLo hecho en las etapas se conserva, pero se ocultan y no se piden automatizaciones.";
    if (!confirm(msg)) return;
    try {
        const r = await pedirJSON("/api/completa/modalidad", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ modalidad: nueva }),
        });
        estado.modelo = r.modelo;
        pintarModalidad();
        if (nueva === "completa") abrirInsumos();      // primer paso: subir manuales, Excels y scripts
        else if (!$("#vista-completa").hidden) mostrarVista("vista-vacia");
    } catch (err) { alert(err.message); }
}

async function vcCargarResumen() {
    try {
        VC.resumen = await pedirJSON("/api/completa/estado");
        for (const e of VC.resumen.etapas) {
            const b = $(`#btn-etapa-${e.codigo}`);
            const lab = b && b.querySelector(".nav-btn__label");
            if (lab) lab.textContent = e.nombre
                + (e.iteraciones ? ` · ITER${e.iteraciones - 1}` : "") + (e.cerrada ? " ✓" : "");
        }
    } catch { /* sin modelo activo */ }
}

async function abrirEtapa(codigo) {
    VC.etapa = codigo;
    VISTA_A_NAV["vista-completa"] = `btn-etapa-${codigo}`;
    mostrarVista("vista-completa");
    VC.archivos = [];
    vcPintarAdjuntos();
    $("#vc-comentario").value = "";
    $("#vc-estado").textContent = "";
    await vcCargarResumen();
    vcPintarPestanas();
    try {
        VC.datos = await pedirJSON(`/api/completa/etapa/${codigo}`);
        vcPintarEtapa();
        vcCargarInsumos();
    } catch (err) {
        $("#vc-mensajes").innerHTML = `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

function vcPintarPestanas() {
    const r = VC.resumen || { etapas: [], cerradas: 0, total: 5 };
    $("#vc-global").innerHTML = r.lista_para_validar
        ? `<div class="verificacion is-ok"><strong>Las ${r.total} etapas están cerradas:</strong>
             el modelo está listo para enviarse a validar.</div>`
        : `<div class="tam">Etapas cerradas: <strong>${r.cerradas} de ${r.total}</strong>.
             Cuando las ${r.total} estén cerradas, el modelo queda listo para enviarse a validar.</div>`;
    $("#vc-etapas").innerHTML = r.etapas.map(e => `
        <button type="button" class="vc-etapa ${e.cerrada ? "is-cerrada" : ""}" role="tab"
                data-etapa="${e.codigo}" aria-selected="${e.codigo === VC.etapa}">
            ${e.codigo} · ${escapeHtml(e.nombre)}<span class="tam">${e.iteraciones ? `ITER${e.iteraciones - 1}` : "—"}</span>
        </button>`).join("");
    for (const b of $$("#vc-etapas .vc-etapa")) {
        b.addEventListener("click", () => abrirEtapa(b.dataset.etapa));
    }
}

function vcVeredicto(v) {
    if (!v) return "";
    return v.estado === "lista"
        ? `<span class="vc-ver vc-ver--lista" title="${escapeHtml(v.motivo || "")}">LISTA</span>`
        : `<span class="vc-ver vc-ver--otra" title="${escapeHtml(v.motivo || "")}">OTRA ITERACIÓN</span>`;
}

function vcThumbs(codigo, iter, imagenes) {
    if (!imagenes || !imagenes.length) return "";
    return `<div class="vc-thumbs">${imagenes.map(n => {
        const u = `/api/completa/etapa/${codigo}/imagen/${iter}/${encodeURIComponent(n)}`;
        return `<a href="${u}" target="_blank" rel="noopener" title="${escapeHtml(n)}"><img src="${u}" alt="${escapeHtml(n)}" loading="lazy"></a>`;
    }).join("")}</div>`;
}

function vcPintarEtapa() {
    const d = VC.datos;
    const n = d.iteraciones.length;
    const ult = n ? d.iteraciones[n - 1] : null;
    $("#vc-titulo").textContent = `Validación completa · ${d.fichero}`;
    $("#vc-mision").textContent = d.mision + (d.profundo
        ? " El agente escribe el notebook en dos pasadas (redacción y revisión crítica): tarda más."
        : "");
    const previas = (d.previas || []).map(c => {
        const e = (VC.resumen.etapas || []).find(x => x.codigo === c);
        return e ? `${e.fichero}${e.iteraciones ? ` (ITER${e.iteraciones - 1})` : " (sin iteraciones)"}` : c;
    });
    $("#vc-previas").textContent = previas.length
        ? `Usa como contexto la última iteración de: ${previas.join(" · ")}.` : "";
    $("#vc-excel-esperado").textContent = ult ? ult.resultado_esperado : "el Excel que generó el notebook";
    $("#vc-enviar").textContent = `Pedir notebook ITER${n}`;

    // Rutas vigentes
    const rutas = d.rutas || {};
    const nr = Object.keys(rutas).length;
    $("#vc-rutas").value = Object.entries(rutas).map(([k, v]) => `${k} = ${v}`).join("\n");
    $("#vc-rutas").dataset.original = $("#vc-rutas").value;
    $("#vc-rutas-resumen").textContent = nr ? `· ${nr} definida${nr === 1 ? "" : "s"}` : "· ninguna todavía";
    $("#vc-rutas-wrap").open = !nr;

    // Cierre (decisión del validador)
    const c = d.cierre;
    $("#vc-cierre").innerHTML = !n ? "" : c
        ? `<div class="vc-cierre verificacion is-ok"><span><strong>Etapa cerrada</strong> por
             ${escapeHtml(c.por || "")} en ITER${c.iter} · ${escapeHtml(fmtTs(c.ts))}${c.motivo ? ` — ${escapeHtml(c.motivo)}` : ""}</span>
             <button type="button" class="btn btn--ghost" id="vc-reabrir">Reabrir</button></div>`
        : `<div class="vc-cierre"><span class="tam">Veredicto del agente en ITER${ult.n}: ${vcVeredicto(ult.veredicto)}
             ${ult.veredicto && ult.veredicto.motivo ? escapeHtml(ult.veredicto.motivo) : ""}</span>
             <button type="button" class="btn ${ult.veredicto && ult.veredicto.estado === "lista" ? "btn--primary" : "btn--ghost"}"
                     id="vc-cerrar">Cerrar etapa</button></div>`;
    const bc = $("#vc-cerrar"), br = $("#vc-reabrir");
    if (bc) bc.addEventListener("click", () => vcCerrar(false));
    if (br) br.addEventListener("click", () => vcCerrar(true));

    const base = `/api/completa/etapa/${d.codigo}/descargar/`;
    $("#vc-iteraciones").innerHTML = n ? `<div class="vc-iters">${d.iteraciones.slice().reverse().map(it => `
        <div class="vc-iter">
            <span class="vc-iter__n">${escapeHtml(d.fichero)}ITER${it.n}</span>
            <a href="${base}${encodeURIComponent(it.ipynb)}" download>⬇ .ipynb</a>
            <a href="${base}${encodeURIComponent(it.md)}" download>revisión .md</a>
            ${vcVeredicto(it.veredicto)}
            <span class="tam">${escapeHtml(fmtTs(it.ts))} · ${escapeHtml(it.modo)} ·
                ${it.abiertos} abiertos · ${it.resueltos} resueltos · genera ${escapeHtml(it.resultado_esperado)}</span>
            <span class="vc-iter__res">${escapeHtml(it.resumen || "")}</span>
            <div class="vc-iter__imgs">${vcThumbs(d.codigo, it.n, it.imagenes)}</div>
        </div>`).join("")}</div>`
        : "<em>Sin notebooks todavía. Indica las rutas de datos y las evidencias para recibir el primero.</em>";

    const cont = $("#vc-mensajes");
    cont.innerHTML = "";
    if (!d.mensajes.length) {
        cont.innerHTML = `<div class="chat-msg chat-msg--agente"><div class="chat-msg__meta">🤖 Agente</div>
            Estudio los manuales, Excels de primera línea y scripts que subas en <strong>Insumos</strong>.
            Aquí dame las <strong>rutas de las bases</strong> y tus indicaciones.
            Te entregaré <strong>${escapeHtml(d.fichero)}ITER0.ipynb</strong>: ejecútalo y genera
            <strong>${escapeHtml(d.fichero)}_resultadoITER0.xlsx</strong>. Devuélvemelo con tus comentarios y
            las capturas que sustenten la revisión, y te doy el ITER1, hasta que la etapa cumpla.</div>`
            .replace(/\n\s+/g, " ");            // .chat-msg usa white-space: pre-wrap
    }
    for (const m of d.mensajes) cont.appendChild(vcMensaje(m, base, d.codigo));
    cont.scrollTop = cont.scrollHeight;
}

function vcMensaje(m, base, codigo) {
    const div = document.createElement("div");
    div.className = `chat-msg chat-msg--${m.quien}`;
    const quien = m.quien === "agente" ? "🤖 Agente" : "👤 Validador";
    let extra = "";
    const otros = (m.archivos || []).filter(f => !VC_IMG.test(f));
    if (otros.length) {
        extra += `<div class="chat-msg__entregables">📎 ${otros.map(escapeHtml).join(" · ")}</div>`;
    }
    if (m.imagenes && m.imagenes.length && codigo) extra += vcThumbs(codigo, m.iter, m.imagenes);
    if (m.pendientes && m.pendientes.length) {
        // Sin saltos ni sangría: .chat-msg usa white-space: pre-wrap.
        extra += `<div class="tam" style="margin-top:6px;">Necesito:</div><ol class="chat-msg__pend">`
            + m.pendientes.map(p => `<li>${escapeHtml(p)}</li>`).join("") + `</ol>`;
    }
    if (m.veredicto) extra += `<div style="margin-top:6px;">${vcVeredicto(m.veredicto)}</div>`;
    if (m.entregables && m.entregables.length && base) {
        extra += `<div class="chat-msg__entregables">${m.entregables.map(f =>
            `<a href="${base}${encodeURIComponent(f)}" download>⬇ ${escapeHtml(f)}</a>`).join("")}</div>`;
    }
    const texto = m.texto ? formatearMensajeChat(m.texto) : "<em>(sin comentario)</em>";
    div.innerHTML = `<div class="chat-msg__meta">${quien} · ITER${m.iter} · ${escapeHtml(fmtTs(m.ts))}</div>${texto}${extra}`;
    return div;
}

// ── Insumos comunes (manuales, Excels de primera línea, scripts) ─────
// Se suben UNA vez en la vista «Insumos» y los usan los 5 chats. En cada chat
// solo se muestra cuántos hay estudiados y las rutas que citan los scripts.
const VC_TIPO = { manual: "Manual", script: "Script", excel_primera_linea: "Excel 1ª línea",
                  excel: "Excel", otro: "Otro" };

function vcPintarInsumos(d) {
    // Línea del chat
    const linea = $("#vc-insumos-linea");
    if (linea) {
        linea.innerHTML = d.total
            ? `📚 <strong>${d.estudiados} de ${d.total}</strong> insumos estudiados (manuales, Excels de primera línea y scripts).
               <a href="#" id="vc-ir-insumos">Ver o subir insumos</a>`
            : `<div class="verificacion is-warn">Aún no hay manuales, Excels ni scripts.
               <a href="#" id="vc-ir-insumos">Súbelos en «Insumos»</a> para que el agente los estudie antes de escribir el notebook.</div>`;
        const ir = $("#vc-ir-insumos");
        if (ir) ir.addEventListener("click", ev => { ev.preventDefault(); abrirInsumos(); });
    }
    const rs = d.rutas_encontradas || [];
    const sug = $("#vc-rutas-sugeridas");
    if (sug) {
        sug.innerHTML = rs.length ? `<div class="tam" style="margin:6px 0 2px;">Rutas que citan
            los scripts y manuales (pulsa para añadirlas a las rutas del notebook):</div>`
            + rs.map((r, i) => `<button type="button" class="btn btn--ghost vc-ruta-sug" data-i="${i}">+ ${escapeHtml(r)}</button>`).join("") : "";
        for (const b of $$("#vc-rutas-sugeridas .vc-ruta-sug")) {
            b.addEventListener("click", () => {
                const ta = $("#vc-rutas");
                const r = rs[Number(b.dataset.i)];
                if (!ta.value.split("\n").some(l => l.includes(r))) ta.value = (ta.value.trim() + "\n" + r).trim();
                $("#vc-rutas-wrap").open = true;
                b.disabled = true;
            });
        }
    }
    // Tabla de la vista «Insumos»
    const tabla = $("#vci-tabla");
    if (!tabla) return;
    $("#vci-resumen").textContent = d.total ? `· ${d.estudiados} de ${d.total} estudiados` : "";
    tabla.innerHTML = d.total ? `<table class="tabla-modelos">
        <thead><tr><th>Archivo</th><th>Tipo</th><th>Origen</th><th>Estudio</th><th>Ficha</th><th></th></tr></thead>
        <tbody>${d.insumos.map((x, i) => `<tr>
            <td>${escapeHtml(x.nombre)}</td>
            <td>${escapeHtml(VC_TIPO[x.tipo] || x.tipo || "—")}</td>
            <td>${escapeHtml(x.origen)}</td>
            <td>${x.estudiado ? (x.modo === "ia" ? `IA · ${x.partes || 1} parte${(x.partes || 1) > 1 ? "s" : ""}`
                                                  : "sin IA") : "<em>pendiente</em>"}</td>
            <td>${escapeHtml(x.resumen || "")}</td>
            <td>${x.borrar ? `<button type="button" class="btn-ghost" data-borrar="${i}" aria-label="Borrar ${escapeHtml(x.nombre)}">✕</button>` : ""}</td>
        </tr>`).join("")}</tbody></table>`
        : `<p class="tam">Todavía no hay insumos.</p>`;
    for (const b of tabla.querySelectorAll("[data-borrar]")) {
        b.addEventListener("click", async () => {
            const x = d.insumos[Number(b.dataset.borrar)];
            if (!confirm(`¿Borrar ${x.nombre} de los insumos?`)) return;
            try {
                vcPintarInsumos(await pedirJSON(`/api/completa/insumos/archivo?ruta=${encodeURIComponent(x.borrar)}`,
                                                { method: "DELETE" }));
            } catch (err) { alert(err.message); }
        });
    }
}

async function vcCargarInsumos() {
    try { vcPintarInsumos(await pedirJSON("/api/completa/insumos")); } catch { /* sin modelo */ }
}

async function abrirInsumos() {
    VISTA_A_NAV["vista-vc-insumos"] = "btn-vc-insumos";
    mostrarVista("vista-vc-insumos");
    $("#vci-subida-estado").textContent = "";
    await vcCargarInsumos();
}

async function vcSubirInsumos(lista) {
    const files = [...lista];
    if (!files.length) return;
    const cat = ($("input[name=vci-cat]:checked") || {}).value || "manual";
    const fd = new FormData();
    fd.append("categoria", cat);
    for (const f of files) fd.append("archivos", f);
    $("#vci-subida-estado").textContent = `Subiendo ${files.length} archivo(s)…`;
    try {
        const r = await fetch("/api/completa/insumos/subir", { method: "POST", body: fd });
        const d = await r.json();
        if (!r.ok) throw new Error(d.detail || `Error ${r.status}`);
        vcPintarInsumos(d);
        $("#vci-subida-estado").textContent = `Subidos: ${d.guardados.join(", ")}. Pulsa «Estudiar insumos pendientes» `
            + "(o se estudiarán solos al pedir el siguiente notebook).";
    } catch (err) {
        $("#vci-subida-estado").textContent = err.message;
    }
}

async function vcEstudiar() {
    const ia = $("#vci-usar-ia").checked;
    $("#vci-estudiar").disabled = true;
    $("#vci-estudio-estado").textContent = ia
        ? "Leyendo y estudiando los insumos con IA (los manuales largos van por partes; puede tardar)…"
        : "Estudiando sin IA…";
    try {
        const d = await pedirJSON("/api/completa/insumos/estudiar", {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ usar_ia: ia }),
        });
        vcPintarInsumos(d);
        $("#vci-estudio-estado").textContent = `Listo: ${d.estudiados} de ${d.total} estudiados.`;
    } catch (err) {
        $("#vci-estudio-estado").textContent = err.message;
    } finally {
        $("#vci-estudiar").disabled = false;
    }
}

async function vcCerrar(reabrir) {
    let motivo = "";
    if (!reabrir) {
        const ult = VC.datos.iteraciones[VC.datos.iteraciones.length - 1];
        const lista = ult && ult.veredicto && ult.veredicto.estado === "lista";
        const r = prompt((lista ? "" : "⚠ El agente aún pide otra iteración.\n\n")
            + `Cerrar ${VC.datos.fichero} en ITER${ult.n}. Motivo o conclusión (opcional):`, "");
        if (r === null) return;
        motivo = r;
    } else if (!confirm("¿Reabrir la etapa?")) return;
    try {
        await pedirJSON(`/api/completa/etapa/${VC.etapa}/cerrar`, {
            method: "POST", headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ motivo, reabrir }),
        });
        await abrirEtapa(VC.etapa);
    } catch (err) { alert(err.message); }
}

function vcPintarAdjuntos() {
    const cont = $("#vc-adjuntos");
    if (!cont) return;
    cont.innerHTML = VC.archivos.map((f, i) => `<span class="vc-adjunto">${VC_IMG.test(f.name) ? "🖼 " : ""}${escapeHtml(f.name)}
        <button type="button" data-quitar="${i}" aria-label="Quitar ${escapeHtml(f.name)}">✕</button></span>`).join("");
    for (const b of cont.querySelectorAll("[data-quitar]")) {
        b.addEventListener("click", ev => {
            ev.stopPropagation();
            VC.archivos.splice(Number(b.dataset.quitar), 1);
            vcPintarAdjuntos();
        });
    }
}

function vcAgregar(lista) {
    for (const f of lista) {
        if (!VC.archivos.some(x => x.name === f.name)) VC.archivos.push(f);
    }
    vcPintarAdjuntos();
}

async function vcEnviar(ev) {
    ev.preventDefault();
    if (VC.enviando) return;
    const comentario = $("#vc-comentario").value.trim();
    const rutas = $("#vc-rutas").value.trim();
    const rutasCambiaron = rutas !== ($("#vc-rutas").dataset.original || "");
    if (!VC.archivos.length && !comentario && !rutasCambiaron && !(VC.datos && VC.datos.iteraciones.length)) {
        $("#vc-estado").textContent = "Indica las rutas de datos, adjunta evidencias o escribe un comentario.";
        return;
    }
    const fd = new FormData();
    fd.append("comentario", comentario);
    fd.append("usar_ia", $("#vc-usar-ia").checked ? "true" : "false");
    if (rutasCambiaron) fd.append("rutas", rutas);
    for (const f of VC.archivos) fd.append("archivos", f);
    VC.enviando = true;
    $("#vc-enviar").disabled = true;
    const lento = VC.datos && VC.datos.profundo;
    $("#vc-estado").textContent = $("#vc-usar-ia").checked
        ? `El agente estudia los insumos nuevos y escribe el notebook${lento ? " en dos pasadas (puede tardar varios minutos)" : ""}…`
        : "Generando el notebook plantilla…";
    const cont = $("#vc-mensajes");
    const n = VC.datos ? VC.datos.iteraciones.length : 0;
    cont.appendChild(vcMensaje({ quien: "validador", iter: n, ts: new Date().toISOString(),
        texto: comentario, archivos: VC.archivos.map(f => f.name) }, "", null));
    cont.scrollTop = cont.scrollHeight;
    try {
        const r = await fetch(`/api/completa/etapa/${VC.etapa}/iteracion`, { method: "POST", body: fd });
        let d = null;
        try { d = await r.json(); } catch { d = null; }
        if (!r.ok) throw new Error((d && d.detail) || `Error ${r.status}`);
        VC.datos = d;
        VC.archivos = [];
        vcPintarAdjuntos();
        $("#vc-comentario").value = "";
        $("#vc-estado").textContent = `Listo: ${d.iteracion.ipynb}. Ejecútalo y devuélveme ${d.iteracion.resultado_esperado}.`;
        await vcCargarResumen();
        vcPintarPestanas();
        vcPintarEtapa();
        vcCargarInsumos();
    } catch (err) {
        $("#vc-estado").textContent = "";
        const e = document.createElement("div");
        e.className = "verificacion is-error";
        e.textContent = err.message;
        cont.appendChild(e);
        cont.scrollTop = cont.scrollHeight;
    } finally {
        VC.enviando = false;
        $("#vc-enviar").disabled = false;
    }
}

function cablearCompleta() {
    const bm = $("#btn-modalidad");
    if (!bm) return;
    bm.addEventListener("click", alternarModalidad);
    for (const b of $$(".nav-etapa")) b.addEventListener("click", () => abrirEtapa(b.dataset.etapa));
    const drop = $("#vc-drop"), input = $("#vc-archivos");
    drop.addEventListener("click", () => input.click());
    drop.addEventListener("keydown", ev => {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); input.click(); }
    });
    drop.addEventListener("dragover", ev => { ev.preventDefault(); drop.classList.add("is-hover"); });
    drop.addEventListener("dragleave", () => drop.classList.remove("is-hover"));
    drop.addEventListener("drop", ev => {
        ev.preventDefault();
        drop.classList.remove("is-hover");
        vcAgregar(ev.dataTransfer.files);
    });
    // Pegar capturas directamente (Ctrl+V) en el comentario.
    $("#vc-comentario").addEventListener("paste", ev => {
        const imgs = [...(ev.clipboardData ? ev.clipboardData.files : [])].filter(f => f.type.startsWith("image/"));
        if (!imgs.length) return;
        ev.preventDefault();
        const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
        vcAgregar(imgs.map((f, i) => new File([f], `captura_${ts}_${i + 1}.png`, { type: f.type })));
    });
    input.addEventListener("change", () => { vcAgregar(input.files); input.value = ""; });
    $("#vc-form").addEventListener("submit", vcEnviar);
    $("#vci-estudiar").addEventListener("click", vcEstudiar);
    $("#btn-vc-insumos").addEventListener("click", abrirInsumos);
    const dz = $("#vci-drop"), fi = $("#vci-archivos");
    dz.addEventListener("click", () => fi.click());
    dz.addEventListener("keydown", ev => {
        if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); fi.click(); }
    });
    dz.addEventListener("dragover", ev => { ev.preventDefault(); dz.classList.add("est-dropzone--hover"); });
    dz.addEventListener("dragleave", () => dz.classList.remove("est-dropzone--hover"));
    dz.addEventListener("drop", ev => {
        ev.preventDefault();
        dz.classList.remove("est-dropzone--hover");
        vcSubirInsumos(ev.dataTransfer.files);
    });
    fi.addEventListener("change", () => { vcSubirInsumos(fi.files); fi.value = ""; });
    $("#vc-comentario").addEventListener("keydown", ev => {
        if (ev.key === "Enter" && (ev.ctrlKey || ev.metaKey)) vcEnviar(ev);
    });
}

window.addEventListener("DOMContentLoaded", cablearCompleta);
