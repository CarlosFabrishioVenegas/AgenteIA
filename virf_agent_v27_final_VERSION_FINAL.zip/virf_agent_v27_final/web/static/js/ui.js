/* VIRF Web — mejoras SOLO de presentación (capa «Sello institucional»).
 *
 * Se carga después de app.js y guia.js. No llama a la API, no cambia ids ni
 * eventos existentes: escucha el DOM y añade comportamiento visual.
 *   1. Tema claro / oscuro (oscuro por defecto; preferencia en este navegador).
 *   2. Zonas de carga para los <input type="file"> visibles: el input sigue
 *      siendo el mismo (mismo id, mismo «change»), solo cambia su envoltorio.
 *   3. La Guía se acopla como columna cuando hay ancho (sin tapar contenido).
 *   4. Mis Modelos: resumen, búsqueda y filtros sobre la tabla ya pintada.
 */
"use strict";

(() => {
    const leer = (k) => { try { return localStorage.getItem(k); } catch { return null; } };
    const guardar = (k, v) => { try { localStorage.setItem(k, v); } catch { /* sin almacenamiento */ } };
    const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

    // ── 1 · Tema ───────────────────────────────────────────────────────
    const raiz = document.documentElement;
    function aplicarTema(t) {
        raiz.dataset.theme = t;
        for (const b of document.querySelectorAll(".btn-tema")) {
            b.textContent = t === "dark" ? "Modo claro" : "Modo oscuro";
            b.setAttribute("aria-label", t === "dark" ? "Cambiar a modo claro" : "Cambiar a modo oscuro");
        }
    }
    function botonTema() {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "btn btn--ghost btn-tema";
        b.addEventListener("click", () => {
            const t = raiz.dataset.theme === "light" ? "dark" : "light";
            guardar("virf-tema", t);
            aplicarTema(t);
        });
        return b;
    }
    for (const sitio of document.querySelectorAll(".pantalla__usuario, .sidebar__footer")) {
        sitio.append(botonTema());
    }
    aplicarTema(leer("virf-tema") === "light" ? "light" : "dark");

    // ── 2 · Zonas de carga ─────────────────────────────────────────────
    function textoAcepta(input) {
        const a = (input.getAttribute("accept") || "").split(",").map(x => x.trim()).filter(Boolean);
        return a.length ? a.join(" ") : "cualquier tipo";
    }
    function zona(input) {
        if (input.closest(".zona-carga")) return;
        const caja = document.createElement("div");
        caja.className = "zona-carga";
        const multiple = input.multiple;
        const icono = (input.getAttribute("accept") || "").split(",")[0].replace(".", "").toUpperCase().slice(0, 4) || "ARCH";
        caja.innerHTML = `
            <span class="zona-carga__icono" aria-hidden="true">${esc(icono)}</span>
            <span class="zona-carga__texto">
                <strong>Arrastra ${multiple ? "los archivos" : "el archivo"} aquí o haz clic para elegir${multiple ? "los" : "lo"}</strong>
                <span class="zona-carga__acepta">${esc(textoAcepta(input))}</span>
                <span class="zona-carga__archivos" aria-live="polite"></span>
            </span>`;
        input.classList.remove("field__control");
        input.before(caja);
        caja.append(input);
        const lista = caja.querySelector(".zona-carga__archivos");
        const pintar = () => {
            const n = [...(input.files || [])].map(f => f.name);
            lista.textContent = n.length ? `Seleccionado: ${n.join(", ")}` : "";
        };
        input.addEventListener("change", pintar);
        // El código de la app limpia input.value tras subir: refleja ese estado.
        new MutationObserver(pintar).observe(input, { attributes: true });
        for (const ev of ["dragenter", "dragover"]) {
            caja.addEventListener(ev, e => { e.preventDefault(); caja.classList.add("is-drag"); });
        }
        for (const ev of ["dragleave", "dragend"]) {
            caja.addEventListener(ev, () => caja.classList.remove("is-drag"));
        }
        caja.addEventListener("drop", e => {
            e.preventDefault();
            caja.classList.remove("is-drag");
            const archivos = [...(e.dataTransfer?.files || [])];
            if (!archivos.length || input.disabled) return;
            const dt = new DataTransfer();
            for (const f of (multiple ? archivos : archivos.slice(0, 1))) dt.items.add(f);
            input.files = dt.files;
            input.dispatchEvent(new Event("change", { bubbles: true }));
        });
    }
    for (const input of document.querySelectorAll('input[type="file"].field__control')) zona(input);

    // ── 3 · Guía acoplada ──────────────────────────────────────────────
    // guia.js construye #guia en DOMContentLoaded; este listener se registra
    // después del suyo, así que corre cuando la guía ya existe.
    function acoplarGuia() {
    const guia = document.getElementById("guia");
    const dashboard = document.getElementById("pantalla-dashboard");
    if (guia && dashboard) {
        const sincronizar = () => {
            const abierta = !guia.hidden && !dashboard.hidden;
            raiz.classList.toggle("guia-abierta", abierta);
        };
        new MutationObserver(() => {
            sincronizar();
            if (!dashboard.hidden) guardar("virf-guia", guia.hidden ? "cerrada" : "abierta");
        }).observe(guia, { attributes: true, attributeFilter: ["hidden"] });
        // Al entrar en un expediente con pantalla ancha, la guía vuelve como
        // la dejó el validador (abierta por defecto: es la columna de contexto).
        new MutationObserver(() => {
            sincronizar();
            if (!dashboard.hidden && guia.hidden && leer("virf-guia") !== "cerrada"
                && window.innerWidth >= 1440 && typeof abrirGuia === "function") {
                abrirGuia();
            }
        }).observe(dashboard, { attributes: true, attributeFilter: ["hidden"] });
        sincronizar();
    }
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", acoplarGuia);
    else acoplarGuia();

    // ── 4 · Mis Modelos: resumen, búsqueda y filtros ───────────────────
    const lista = document.getElementById("modelos-lista");
    const ETQ_ESTADO = { sin_iniciar: "Sin iniciar", en_progreso: "En progreso", completado: "Completado" };
    function contar(filas, attr) {
        const c = new Map();
        for (const f of filas) { const v = f.dataset[attr] || "—"; c.set(v, (c.get(v) || 0) + 1); }
        return [...c.entries()].sort((a, b) => b[1] - a[1]);
    }
    function opciones(pares, etiquetas = {}) {
        return pares.map(([v, n]) => `<option value="${esc(v)}">${esc(etiquetas[v] || v)} (${n})</option>`).join("");
    }
    function mejorarTabla() {
        const tabla = lista && lista.querySelector("table.tabla-modelos");
        if (!tabla || tabla.dataset.mejorada) return;
        tabla.dataset.mejorada = "1";
        const filas = [...tabla.querySelectorAll("tbody tr[data-slug]")];
        for (const f of filas) {
            const s = f.querySelector("td strong");
            if (s) s.title = s.textContent;
        }
        const est = contar(filas, "estado"), tiers = contar(filas, "tier"), doms = contar(filas, "dominio");
        const n = (k) => (est.find(([v]) => v === k) || [0, 0])[1];
        const resumen = document.createElement("div");
        resumen.className = "modelos-resumen";
        resumen.innerHTML = `
            <div class="modelos-resumen__item"><div class="modelos-resumen__etq">modelos</div>
                <div class="modelos-resumen__valor">${filas.length}</div>
                <div class="modelos-resumen__det">${doms.map(([v, c]) => `${esc(v)} ${c}`).join(" · ")}</div></div>
            <div class="modelos-resumen__item"><div class="modelos-resumen__etq">en progreso</div>
                <div class="modelos-resumen__valor">${n("en_progreso")}</div>
                <div class="modelos-resumen__det">sin iniciar ${n("sin_iniciar")}</div></div>
            <div class="modelos-resumen__item"><div class="modelos-resumen__etq">completados</div>
                <div class="modelos-resumen__valor">${n("completado")}</div></div>
            <div class="modelos-resumen__item"><div class="modelos-resumen__etq">tiers distintos</div>
                <div class="modelos-resumen__valor">${tiers.length}</div>
                <div class="modelos-resumen__det">${tiers.map(([v, c]) => `Tier ${esc(v)}: ${c}`).join(" · ")}</div></div>`;
        const filtros = document.createElement("div");
        filtros.className = "modelos-filtros";
        filtros.innerHTML = `
            <label class="field field--busca"><span class="field__label">Buscar modelo</span>
                <input type="search" class="field__control" data-f="texto" placeholder="Nombre o código"></label>
            <label class="field"><span class="field__label">Estado</span>
                <select class="field__control" data-f="estado"><option value="">Todos</option>${opciones(est, ETQ_ESTADO)}</select></label>
            <label class="field"><span class="field__label">Tier</span>
                <select class="field__control" data-f="tier"><option value="">Todos</option>${opciones(tiers)}</select></label>
            <label class="field"><span class="field__label">Dominio</span>
                <select class="field__control" data-f="dominio"><option value="">Todos</option>${opciones(doms)}</select></label>
            <span class="modelos-filtros__cuenta" aria-live="polite"></span>`;
        const envoltura = document.createElement("div");
        envoltura.className = "tabla-scroll";
        tabla.before(resumen, filtros, envoltura);
        envoltura.append(tabla);
        const vacio = document.createElement("div");
        vacio.className = "modelos-sin-resultados";
        vacio.hidden = true;
        vacio.textContent = "Ningún modelo coincide con la búsqueda o los filtros.";
        envoltura.after(vacio);
        const cuenta = filtros.querySelector(".modelos-filtros__cuenta");
        const valor = (k) => filtros.querySelector(`[data-f="${k}"]`).value;
        const filtrar = () => {
            const q = valor("texto").trim().toLowerCase();
            let vis = 0;
            for (const f of filas) {
                const ok = (!q || `${f.dataset.nombre} ${f.dataset.slug}`.toLowerCase().includes(q))
                    && (!valor("estado") || f.dataset.estado === valor("estado"))
                    && (!valor("tier") || f.dataset.tier === valor("tier"))
                    && (!valor("dominio") || f.dataset.dominio === valor("dominio"));
                f.hidden = !ok;
                vis += ok ? 1 : 0;
            }
            cuenta.textContent = `${vis} de ${filas.length}`;
            vacio.hidden = vis > 0;
            envoltura.hidden = vis === 0;
        };
        filtros.addEventListener("input", filtrar);
        filtrar();
    }
    if (lista) new MutationObserver(mejorarTabla).observe(lista, { childList: true });
})();
