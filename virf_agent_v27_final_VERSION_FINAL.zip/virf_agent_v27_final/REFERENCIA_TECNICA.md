# Referencia técnica — VIRF Agent (generada del código)

> Generada el 2026-11-18 por `scripts/generar_referencia_tecnica.py`. **No editar a mano**: se regenera. Complementa `GUIA_TRASPASO_CONTEXTO.md` e `INVENTARIO_ARCHIVOS.md`.

## 1. Flags de `agente.py`

| Flag | Tipo | Por defecto | Qué hace |
|---|---|---|---|
| `--titulo` | valor | None | Nombre del modelo |
| `--tier` | valor | None | Tier del modelo (1, 2, 3, 4) |
| `--excel` | valor | None | Ruta al Excel de controles (para pipeline Calidad de Datos) |
| `--control` | store_true | — | Usar pipeline por CONTROL (Calidad de Datos) |
| `--prdc` | store_true | — | Modo producción (genera Word) |
| `--estadisticafeedback` | store_true | — | Ver estadísticas de feedback |
| `--limpiar-cache` | store_true | — | Limpiar caché de documentos y salir |
| `--cache-stats` | store_true | — | Ver estadísticas del caché de documentos |
| `--no-cache` | store_true | — | Deshabilitar caché para esta corrida |
| `--convertir-excel` | valor | None | FASE 1: Ruta a carpeta con .xlsx/.xlsm. Genera .ipynb por libro con VBA, refs externas y auto-validación contra Excel. NO copia al pipeline principal — tú deci… |
| `--cuadro-automatizaciones` | valor | None | Carpeta con los Excels de automatización del producto (00_Diagnostico, 01_ControlDatos, 02_Modelamiento, 03_Impactos opcional). Genera el cuadro de observacion… |
| `--sin-ia` | store_true | — | Con --cuadro-automatizaciones: borrador determinista, sin llamadas a la IA. |
| `--virf-plus` | store_true | — | Activa VIRF PLUS en esta corrida: suma a Claude como segunda opinión del agente GPT; ambos evalúan por separado y GPT concilia la conclusión (equivale a VIRF_P… |
| `--controles-a-notebook` | valor | None | Ruta a un DOCUMENTO (.docx/.pdf/.md) que describe controles de calidad de datos. Genera un .ipynb ejecutable y un análisis de brechas contra --excel. |
| `--datasets` | valor | None | Carpeta con los datasets (.csv/.parquet/.xlsx) para los controles de motor de datos. Default: inputs/calidad_datos/datasets/ |
| `--listar-motores` | store_true | — | Muestra el catálogo de pruebas de calidad de datos disponibles y sale |
| `--dominio-rag` | valor | None | Corpus RAG a consultar: LaR / VaR / conductuales / shared. DECLÁRALO: sin este flag el dominio se INFIERE del título, y la inferencia es una heurística que pue… |
| `--skills` | valor | None | Análisis transversales tras la evaluación. 'all' / 'rapidas' / lista separada por comas (ej. coherencia,supuestos,sintesis). NO alteran el score: producen hall… |
| `--listar-skills` | store_true | — | Muestra el catálogo de skills de validación disponibles y sale |
| `--explicar-modelo` | valor | None | Genera outputs/<fecha>/explicacion_del_modelo_<NOMBRE>.md consolidando las 4 fuentes de inputs/ (metodología, seguimiento, implementación, calidad de datos) |
| `--dry-run` | store_true | — | Para --explicar-modelo: muestra el inventario de evidencia y el coste estimado SIN llamar al modelo |
| `--excluir` | valor | None | Para --explicar-modelo: nombres de fichero a omitir (p. ej. fixtures de prueba que viven en inputs/) |
| `--solo-coincidentes` | store_true | — | Para --explicar-modelo: usar SOLO los ficheros cuyo nombre contiene el modelo. Úsalo cuando varios modelos comparten las carpetas de inputs/; por defecto se in… |
| `--raiz-evidencia` | valor | None | Raíz alternativa que contiene inputs/ (default: la del proyecto). UN MODELO POR RAÍZ: evita que la evidencia de varios modelos se mezcle y que el informe de un… |
| `--estandares` | valor | None | Ruta a un Estandares_VIRF.xlsx alternativo (default: el global del proyecto). Introducido por la web v2.4 para que cada validador aplique su propio catálogo de… |
| `--sin-llm` | store_true | — | Para --convertir-excel: no usa LLM (solo estructura + fórmulas sin traducir) |
| `--sin-validacion` | store_true | — | Para --convertir-excel: omite la auto-validación notebook vs Excel |
| `--revisar-codigo` | store_true | — | Revisa el código de inputs/implementacion/ (recursivo, .py e .ipynb) contra el manual metodológico: UNA llamada por módulo, hallazgos con fichero:línea. Sus ha… |
| `--analizar-codigo` | store_true | — | Análisis ESTÁTICO del código de inputs/implementacion/ (.py e .ipynb): extrae por AST los hechos duros —funciones, valores por defecto, ventanas, métodos, alea… |
| `--perfilar-datasets` | store_true | — | Añade a la evidencia un perfil del ESQUEMA de los datasets (columnas, tipos, nulos, rangos, duplicados). No vuelca ninguna fila de datos. Permite contrastar la… |
| `--prevuelo` | store_true | — | Revisa la evidencia ANTES de gastar y sale: qué se podrá leer, qué PDFs están escaneados, qué formatos se omiten sin aviso y qué ámbitos quedarán sin evidencia… |
| `--verificar-cadena` | valor | None | Verifica la integridad de la cadena de custodia de todos los informes de un modelo y sale |
| `--verificar-evidencia` | valor | None | Comprueba si los documentos citados por un informe siguen intactos y sale |
| `--verificar-emisiones` | valor | None | Contrasta el registro append-only de emisiones (audit_logs/registro_emisiones.jsonl) contra los informes presentes en outputs/ y sale. Detecta informes emitido… |
| `--historial-validaciones` | store_true | — | Lista, por validador, qué modelos ha aprobado y cuándo |
| `--comparar` | valor | None | Compara las dos últimas corridas del modelo y sale: score por ámbito, actividades que subieron o bajaron, documentos que cambiaron, y si cambió la VARA DE MEDI… |
| `--verificar-conexion-azure` | store_true | — | Prueba de humo del proveedor activo: confirma credenciales, detecta el modelo real del deployment, muestra el perfil de chunking que se aplicará y valida que e… |

## 2. Variables de entorno

127 variables.

| Variable | Tipo | Por defecto | Se lee en |
|---|---|---|---|
| `ANTHROPIC_MAX_TOKENS` | entero | `4096` | `config/parametros.py:181` |
| `ANTHROPIC_MODELO` | texto | `'claude-sonnet-4-6'` | `config/parametros.py:180`, `validate_project.py:246` |
| `ANTHROPIC_WORKSPACE_ID` | texto | `''` | `config/ia.py:440`, `config/ia.py:1162` |
| `AZURE_OPENAI_API_VERSION` | texto | `'2024-10-21'` | `config/parametros.py:190` |
| `AZURE_OPENAI_DEPLOYMENT` | texto | `''` | `config/ia.py:669`, `config/ia.py:1142`, `diagnostico_azure_virf.py:159` … |
| `AZURE_OPENAI_ENDPOINT` | texto | `''` | `config/ia.py:668`, `config/ia.py:657`, `diagnostico_azure_virf.py:158` |
| `AZURE_OPENAI_MAX_TOKENS` | entero | `4096` | `config/parametros.py:191` |
| `CACHE_DIR` | texto | `str(BASE_DIR / 'data' / 'cache')` | `config/rutas.py:90` |
| `CACHE_ENABLED` | booleano | `True` | `config/parametros.py:342` |
| `DEBUG_PROMPTS` | booleano | `False` | `config/parametros.py:362` |
| `EXCEL_CHUNK_HOJA_UMBRAL` | entero | `80` | `config/parametros.py:353` |
| `EXCEL_MAX_CELDAS_MUESTRA` | entero | `500` | `config/parametros.py:351` |
| `EXCEL_MAX_FORMULAS_HOJA` | entero | `2000` | `config/parametros.py:352` |
| `EXCEL_NB_TIMEOUT` | entero | `120` | `config/parametros.py:355` |
| `EXCEL_VALIDACION_TOL` | decimal | `1e-06` | `config/parametros.py:354` |
| `HTTPS_PROXY` | texto | `—` | `config/red.py:172` |
| `HTTP_PROXY` | texto | `—` | `config/red.py:172` |
| `IA_PROVEEDOR` | texto | `'azure_openai'` | `config/parametros.py:143`, `web/routers/config.py:113`, `web/routers/preview_prompt.py:58` |
| `MAX_CHARS_CODIGO` | entero | `8000` | `config/parametros.py:162` |
| `MAX_CHARS_DOC` | entero | `15000` | `config/parametros.py:161` |
| `MAX_FILAS_EXCEL` | entero | `200` | `config/parametros.py:163` |
| `MODO` | texto | `'produccion'` | `config/parametros.py:146` |
| `NO_PROXY` | texto | `'(vacío)'` | `config/red.py:174` |
| `OPENAI_MAX_TOKENS` | entero | `4096` | `config/parametros.py:196` |
| `OPENAI_MODELO` | texto | `'gpt-4.1'` | `config/parametros.py:195` |
| `RAG_BM25_B` | decimal | `0.75` | `config/parametros.py:606` |
| `RAG_BM25_K1` | decimal | `1.5` | `config/parametros.py:605` |
| `RAG_CHUNKING_ESTRUCTURAL` | booleano | `False` | `config/parametros.py:629` |
| `RAG_CHUNK_OVERLAP` | entero | `200` | `config/parametros.py:621` |
| `RAG_CHUNK_SIZE` | entero | `1200` | `config/parametros.py:620` |
| `RAG_CORREGIR_ERRATAS` | booleano | `True` | `config/parametros.py:649` |
| `RAG_INDICE_DIR` | texto | `''` | `config/parametros.py:595` |
| `RAG_LONGITUD_MINIMA_TOKEN` | entero | `2` | `config/parametros.py:635` |
| `RAG_MIN_COBERTURA` | decimal | `0.15` | `config/parametros.py:558` |
| `RAG_MIN_SCORE` | decimal | `0.35` | `config/parametros.py:563` |
| `RAG_PESO_BM25` | decimal | `0.7` | `config/parametros.py:601` |
| `RAG_PESO_INFORMATIVO_MINIMO` | decimal | `0.8` | `config/parametros.py:576` |
| `RAG_PESO_TFIDF` | decimal | `0.3` | `config/parametros.py:602` |
| `RAG_RECONOCIMIENTO_MINIMO` | decimal | `0.5` | `config/parametros.py:782` |
| `RAG_STEMMING` | booleano | `True` | `config/parametros.py:633` |
| `RAG_TESAURO` | booleano | `True` | `config/parametros.py:648` |
| `RAG_TFIDF_MIN_DF` | entero | `1` | `config/parametros.py:615` |
| `RAG_TFIDF_NGRAM_MAX` | entero | `2` | `config/parametros.py:611` |
| `RAG_TOP_K` | entero | `6` | `config/parametros.py:530` |
| `RAG_UMBRAL_ERRATA` | decimal | `0.85` | `config/parametros.py:650` |
| `REINTENTOS_API` | entero | `3` | `config/parametros.py:153` |
| `SOLO_INFORME_DEPLOYMENT` | texto | `—` | `web/services/solo_informe_ia.py:95`, `web/services/solo_informe_ia.py:128` |
| `SOLO_INFORME_IA_PROVEEDOR` | texto | `—` | `web/services/solo_informe_ia.py:74` |
| `SOLO_INFORME_MODELO` | texto | `—` | `web/services/solo_informe_ia.py:97`, `web/services/solo_informe_ia.py:129` |
| `TIMEOUT_SEGUNDOS` | entero | `30` | `config/parametros.py:152` |
| `VIRF_ABSTENCION_BETA` | decimal | `0.19` | `config/parametros.py:335` |
| `VIRF_AGENTE_VERSION` | texto | `'27.1'` | `config/parametros.py:150` |
| `VIRF_ANTIINYECCION` | booleano | `True` | `config/parametros.py:450` |
| `VIRF_ASERCION_IDENTIDAD` | texto | `—` | `validate_project.py:1053` |
| `VIRF_AUDITORIA_LOG` | texto | `—` | `config/parametros.py:793` |
| `VIRF_CACHE_LOCK_STALE` | entero | `60` | `config/parametros.py:344` |
| `VIRF_CACHE_LOCK_TIMEOUT` | entero | `10` | `config/parametros.py:343` |
| `VIRF_CA_BUNDLE` | texto | `''` | `config/parametros.py:467` |
| `VIRF_CHAT_INCLUYE_NO_EVIDENCIADO` | texto | `'1'` | `modulos/motor_ia.py:1984`, `web/services/chat_service.py:190` |
| `VIRF_CHAT_INCLUYE_PARCIAL` | texto | `'1'` | `modulos/motor_ia.py:1982`, `web/services/chat_service.py:188` |
| `VIRF_CHUNK_ENABLED` | booleano | `True` | `config/parametros.py:264` |
| `VIRF_CHUNK_OVERLAP` | entero | `800` | `config/parametros.py:241` |
| `VIRF_CHUNK_SIZE` | entero | `12000` | `config/parametros.py:240`, `web/routers/preview_prompt.py:55` |
| `VIRF_CHUNK_SIZE_MAX` | entero | `40000` | `config/parametros.py:253` |
| `VIRF_CHUNK_THRESHOLD` | entero | `CHUNK_SIZE` | `config/parametros.py:242` |
| `VIRF_CLASIFICACION_INFORME` | texto | `—` | `config/parametros.py:805` |
| `VIRF_COMPLETA_MAX_PROMPT` | texto | `'90000'` | `modulos/validacion_completa.py:170` |
| `VIRF_DIR_LOGO` | texto | `'inputs/logoempresa'` | `config/parametros.py:754` |
| `VIRF_DOBLE_FIRMA_TIER` | texto | `''` | `config/parametros.py:719`, `validate_project.py:1223`, `validate_project.py:1249` |
| `VIRF_ENTAILMENT` | booleano | `MODO == 'produccion'` | `config/parametros.py:442` |
| `VIRF_ENTORNO` | texto | `—` | `config/parametros.py:823` |
| `VIRF_ENTRA_CLIENT_ID` | texto | `''` | `config/identidad.py:115` |
| `VIRF_ENTRA_REDIRECT_URI` | texto | `''` | `config/identidad.py:116` |
| `VIRF_ENTRA_TENANT_ID` | texto | `''` | `config/identidad.py:114` |
| `VIRF_ESTUDIO_MAX_PARTES` | texto | `'12'` | `modulos/estudio_insumos.py:47` |
| `VIRF_ESTUDIO_PARTE` | texto | `'24000'` | `modulos/estudio_insumos.py:46` |
| `VIRF_EXCLUIR_DEPENDENCIAS` | booleano | `False` | `config/parametros.py:509`, `modulos/revision_codigo.py:340` |
| `VIRF_FUENTE` | texto | `'Flexo'` | `config/parametros.py:739` |
| `VIRF_FUENTE_MONO` | texto | `'Cascadia Mono'` | `config/parametros.py:743` |
| `VIRF_FUENTE_RESPALDO` | texto | `'Segoe UI'` | `config/parametros.py:748` |
| `VIRF_FUENTE_SECRETOS` | texto | `—` | `config/secretos.py:92` |
| `VIRF_FUSIBLE_SEG` | entero | `10` | `config/parametros.py:317` |
| `VIRF_FUSIBLE_TOKENS` | entero | `20000` | `config/parametros.py:318` |
| `VIRF_HOSTS_IA_PERMITIDOS` | texto | `''` | `config/red.py:70` |
| `VIRF_HTTP_TIMEOUT` | entero | `120` | `config/parametros.py:476` |
| `VIRF_IA_TEMPERATURE` | decimal | `0.0` | `config/parametros.py:774`, `web/routers/preview_prompt.py:57` |
| `VIRF_IDENTIDAD_PROVEEDOR` | texto | `—` | `config/identidad.py:218` |
| `VIRF_ID_CORRIDA` | texto | `''` | `config/ia.py:252` |
| `VIRF_IMPACTO_UMBRAL_CRITICO` | decimal | `0.1` | `config/parametros.py:230` |
| `VIRF_IMPACTO_UMBRAL_MODERADO` | decimal | `0.05` | `config/parametros.py:229` |
| `VIRF_INTENTOS_CONTRATO` | entero | `2` | `config/parametros.py:301` |
| `VIRF_KEYVAULT_URL` | texto | `—` | `config/secretos.py:137` |
| `VIRF_MAX_CHARS_MANUAL_REVISION` | entero | `24000` | `config/parametros.py:502` |
| `VIRF_MAX_CHARS_MODULO` | entero | `120000` | `config/parametros.py:497` |
| `VIRF_MAX_CHUNKS` | entero | `40` | `config/parametros.py:250`, `web/routers/preview_prompt.py:56` |
| `VIRF_MAX_CTX` | entero | `MAX_CHARS_DOC` | `config/parametros.py:169`, `web/routers/preview_prompt.py:54` |
| `VIRF_MAX_CTX_SKILLS` | entero | `MAX_CTX * 4` | `config/parametros.py:281` |
| `VIRF_MAX_DOCS_AMBITO` | entero | `0` | `config/parametros.py:173` |
| `VIRF_MAX_ITER` | entero | `3` | `config/parametros.py:316` |
| `VIRF_MAX_NIVELES` | entero | `3` | `config/parametros.py:257` |
| `VIRF_MIN_FEEDBACK_ANTISESGO` | entero | `15` | `config/parametros.py:366` |
| `VIRF_MIN_MUESTRAS_AJUSTE` | entero | `MIN_FEEDBACK_ANTISESGO` | `config/parametros.py:384` |
| `VIRF_MOCK_CHAT` | texto | `—` | `modulos/estudio_insumos.py:371`, `modulos/validacion_completa.py:878`, `modulos/validacion_completa.py:866` … |
| `VIRF_PII_MASKING` | booleano | `True` | `config/parametros.py:430` |
| `VIRF_PLAZO_BAJO` | entero | `180` | `config/parametros.py:226` |
| `VIRF_PLAZO_CRITICO` | entero | `30` | `config/parametros.py:224` |
| `VIRF_PLAZO_MODERADO` | entero | `90` | `config/parametros.py:225` |
| `VIRF_PLUS` | texto | `''` | `config/ia.py:989` |
| `VIRF_PLUS_ARBITRAJE` | texto | `'siempre'` | `config/parametros.py:214` |
| `VIRF_PLUS_ARBITRO` | texto | `'gpt'` | `config/parametros.py:213` |
| `VIRF_PLUS_GPT` | texto | `IA_PROVEEDOR if IA_PROVEEDOR in ('openai', 'azure…` | `config/parametros.py:209` |
| `VIRF_PLUS_LOG` | texto | `''` | `config/virf_plus.py:316`, `config/virf_plus.py:316` |
| `VIRF_PRESUPUESTO_DOC` | entero | `int(MAX_CTX * 0.6)` | `config/parametros.py:262` |
| `VIRF_PROHIBIR_MODELOS_EXTERNOS` | booleano | `True` | `config/parametros.py:417` |
| `VIRF_PUNTAJE_CUMPLE` | texto | `5` | `modulos/consolidacion.py:41`, `modulos/feedback.py:647` |
| `VIRF_RAG_TOP_K_SKILLS` | entero | `8` | `config/parametros.py:286` |
| `VIRF_REPO_CORPORATIVO` | texto | `''` | `config/parametros.py:813` |
| `VIRF_RESP_MODELAMIENTO` | texto | `'Equipo de Modelamiento (desarrollador del modelo…` | `config/parametros.py:219` |
| `VIRF_RESP_SEGUIMIENTO` | texto | `'Equipo de Seguimiento de Modelos'` | `config/parametros.py:221` |
| `VIRF_RETENCION_DIAS` | decimal | `30.0` | `config/parametros.py:828` |
| `VIRF_ROL_AGENTE_OVERRIDE` | texto | `—` | `motor/Mx_03_LlamarIA.py:156` |
| `VIRF_SECRET_SCOPE` | texto | `—` | `config/secretos.py:176` |
| `VIRF_SESION_TTL_MIN` | texto | `'480'` | `web/services/sesion_store.py:37` |
| `VIRF_TLS_ALMACEN_SISTEMA` | booleano | `False` | `config/parametros.py:472` |
| `VIRF_TLS_INSECURE` | booleano | `False` | `config/parametros.py:485` |
| `VIRF_UMBRAL_SEGUNDA_REVISION` | entero | `3` | `config/parametros.py:664` |
| `VIRF_VALIDAR_CONEXION` | booleano | `False` | `config/parametros.py:185` |

## 3. Endpoints de la web

236 endpoints.

| Método | Ruta | Archivo · función | Qué hace |
|---|---|---|---|
| GET | `/` | `web/app.py` · `index` |  |
| GET | `/api/auth/actual` | `web/routers/auth.py` · `validador_actual` | Validador logueado o 401 (la SPA decide si mostrar el login). |
| GET | `/api/auth/actual` | `web/routers/auth.py` · `validador_actual` | Validador logueado o 401 (la SPA decide si mostrar el login). |
| GET | `/api/auth/callback` | `web/routers/auth.py` · `completar_login` |  |
| GET | `/api/auth/callback` | `web/routers/auth.py` · `completar_login` |  |
| GET | `/api/auth/login` | `web/routers/auth.py` · `iniciar_login` |  |
| GET | `/api/auth/login` | `web/routers/auth.py` · `iniciar_login` |  |
| POST | `/api/auth/login-libre` | `web/routers/auth.py` · `login_libre` | Usuario libre para PROBAR la web sin Entra ID (web v2). Fuera del modo «libre», o con MOD… |
| POST | `/api/auth/login-libre` | `web/routers/auth.py` · `login_libre` | Usuario libre para PROBAR la web sin Entra ID (web v2). Fuera del modo «libre», o con MOD… |
| POST | `/api/auth/logout` | `web/routers/auth.py` · `hacer_logout` |  |
| POST | `/api/auth/logout` | `web/routers/auth.py` · `hacer_logout` |  |
| GET | `/api/auth/modo` | `web/routers/auth.py` · `modo_login` | Qué pantalla de login pinta la SPA. Solo «libre» cambia la vista. |
| GET | `/api/auth/modo` | `web/routers/auth.py` · `modo_login` | Qué pantalla de login pinta la SPA. Solo «libre» cambia la vista. |
| POST | `/api/automatizaciones/cuadro` | `web/routers/automatizaciones.py` · `generar` |  |
| POST | `/api/automatizaciones/cuadro` | `web/routers/automatizaciones.py` · `generar` |  |
| GET | `/api/automatizaciones/descargar/{fichero}` | `web/routers/automatizaciones.py` · `descargar` |  |
| GET | `/api/automatizaciones/descargar/{fichero}` | `web/routers/automatizaciones.py` · `descargar` |  |
| GET | `/api/automatizaciones/estado` | `web/routers/automatizaciones.py` · `estado` |  |
| GET | `/api/automatizaciones/estado` | `web/routers/automatizaciones.py` · `estado` |  |
| GET | `/api/chat/acta.xlsx` | `web/routers/chat.py` · `descargar_acta_cierre` | Acta de cierre en Excel (3 hojas: Resumen · Validación · Decisiones) con el PUNTAJE EXACT… |
| GET | `/api/chat/acta.xlsx` | `web/routers/chat.py` · `descargar_acta_cierre` | Acta de cierre en Excel (3 hojas: Resumen · Validación · Decisiones) con el PUNTAJE EXACT… |
| POST | `/api/chat/adjuntar` | `web/routers/chat.py` · `adjuntar_chat` | El validador sube un archivo con evidencia nueva para la observación en curso. Se extrae … |
| POST | `/api/chat/adjuntar` | `web/routers/chat.py` · `adjuntar_chat` | El validador sube un archivo con evidencia nueva para la observación en curso. Se extrae … |
| POST | `/api/chat/consolidar` | `web/routers/chat.py` · `consolidar_chat` | Cierre HITL: recomputa el PUNTAJE EXACTO final con las decisiones del chat y GUARDA cada … |
| POST | `/api/chat/consolidar` | `web/routers/chat.py` · `consolidar_chat` | Cierre HITL: recomputa el PUNTAJE EXACTO final con las decisiones del chat y GUARDA cada … |
| GET | `/api/chat/estado` | `web/routers/chat.py` · `estado_chat` |  |
| GET | `/api/chat/estado` | `web/routers/chat.py` · `estado_chat` |  |
| POST | `/api/chat/iniciar` | `web/routers/chat.py` · `iniciar_chat` |  |
| POST | `/api/chat/iniciar` | `web/routers/chat.py` · `iniciar_chat` |  |
| GET | `/api/chat/observaciones` | `web/routers/chat.py` · `observaciones` | Resumen enfocado para dashboards, sin arrastrar todos los mensajes. |
| GET | `/api/chat/observaciones` | `web/routers/chat.py` · `observaciones` | Resumen enfocado para dashboards, sin arrastrar todos los mensajes. |
| POST | `/api/codigo/aprobar` | `web/routers/codigo.py` · `aprobar` |  |
| POST | `/api/codigo/aprobar` | `web/routers/codigo.py` · `aprobar` |  |
| GET | `/api/completa/estado` | `web/routers/validacion_completa.py` · `estado` |  |
| GET | `/api/completa/estado` | `web/routers/validacion_completa.py` · `estado` |  |
| GET | `/api/completa/etapa/{codigo}` | `web/routers/validacion_completa.py` · `ver_etapa` |  |
| GET | `/api/completa/etapa/{codigo}` | `web/routers/validacion_completa.py` · `ver_etapa` |  |
| POST | `/api/completa/etapa/{codigo}/cerrar` | `web/routers/validacion_completa.py` · `cerrar` | El validador da la etapa por cumplida (o la reabre). Decisión humana. |
| POST | `/api/completa/etapa/{codigo}/cerrar` | `web/routers/validacion_completa.py` · `cerrar` | El validador da la etapa por cumplida (o la reabre). Decisión humana. |
| GET | `/api/completa/etapa/{codigo}/descargar/{fichero}` | `web/routers/validacion_completa.py` · `descargar` | Notebook ITERn (.ipynb) o revisión (.md) de la etapa. |
| GET | `/api/completa/etapa/{codigo}/descargar/{fichero}` | `web/routers/validacion_completa.py` · `descargar` | Notebook ITERn (.ipynb) o revisión (.md) de la etapa. |
| GET | `/api/completa/etapa/{codigo}/imagen/{iteracion}/{fichero}` | `web/routers/validacion_completa.py` · `imagen` | Imagen de sustento enviada en la iteración. |
| GET | `/api/completa/etapa/{codigo}/imagen/{iteracion}/{fichero}` | `web/routers/validacion_completa.py` · `imagen` | Imagen de sustento enviada en la iteración. |
| POST | `/api/completa/etapa/{codigo}/iteracion` | `web/routers/validacion_completa.py` · `iterar` |  |
| POST | `/api/completa/etapa/{codigo}/iteracion` | `web/routers/validacion_completa.py` · `iterar` |  |
| GET | `/api/completa/insumos` | `web/routers/validacion_completa.py` · `ver_insumos` | Manuales, Excels de primera línea y scripts disponibles, y si ya se estudiaron. |
| GET | `/api/completa/insumos` | `web/routers/validacion_completa.py` · `ver_insumos` | Manuales, Excels de primera línea y scripts disponibles, y si ya se estudiaron. |
| DELETE | `/api/completa/insumos/archivo` | `web/routers/validacion_completa.py` · `borrar_insumo` | Borra un archivo de la carpeta común (no toca la evidencia del paso 03). |
| DELETE | `/api/completa/insumos/archivo` | `web/routers/validacion_completa.py` · `borrar_insumo` | Borra un archivo de la carpeta común (no toca la evidencia del paso 03). |
| POST | `/api/completa/insumos/estudiar` | `web/routers/validacion_completa.py` · `estudiar_insumos` | Lee ENTEROS y estudia los insumos pendientes (caché por huella). |
| POST | `/api/completa/insumos/estudiar` | `web/routers/validacion_completa.py` · `estudiar_insumos` | Lee ENTEROS y estudia los insumos pendientes (caché por huella). |
| POST | `/api/completa/insumos/subir` | `web/routers/validacion_completa.py` · `subir_insumos` | Sube manuales, Excels de primera línea o scripts a la carpeta COMÚN de los 5 chats. |
| POST | `/api/completa/insumos/subir` | `web/routers/validacion_completa.py` · `subir_insumos` | Sube manuales, Excels de primera línea o scripts a la carpeta COMÚN de los 5 chats. |
| POST | `/api/completa/modalidad` | `web/routers/validacion_completa.py` · `cambiar_modalidad` |  |
| POST | `/api/completa/modalidad` | `web/routers/validacion_completa.py` · `cambiar_modalidad` |  |
| GET | `/api/config` | `web/routers/config.py` · `get_config` | Estado del .env + validador logueado (sin secretos). |
| GET | `/api/config` | `web/routers/config.py` · `get_config` | Estado del .env + validador logueado (sin secretos). |
| POST | `/api/config/modelo` | `web/routers/config.py` · `set_modelo` | Guarda título (etiqueta visible) y tier del MODELO ACTIVO. El modelo activo se identifica… |
| POST | `/api/config/modelo` | `web/routers/config.py` · `set_modelo` | Guarda título (etiqueta visible) y tier del MODELO ACTIVO. El modelo activo se identifica… |
| POST | `/api/config/verificar` | `web/routers/config.py` · `verificar_conexion` |  |
| POST | `/api/config/verificar` | `web/routers/config.py` · `verificar_conexion` |  |
| POST | `/api/config/virf_plus` | `web/routers/config.py` · `set_virf_plus` | Botón VIRF PLUS: suma (o quita) a Claude como segunda opinión del agente principal, que e… |
| POST | `/api/config/virf_plus` | `web/routers/config.py` · `set_virf_plus` | Botón VIRF PLUS: suma (o quita) a Claude como segunda opinión del agente principal, que e… |
| GET | `/api/cuestionamientos-sesion` | `web/routers/cuestionamientos_sesion.py` · `get_estado` |  |
| GET | `/api/cuestionamientos-sesion` | `web/routers/cuestionamientos_sesion.py` · `get_estado` |  |
| POST | `/api/cuestionamientos-sesion/custom` | `web/routers/cuestionamientos_sesion.py` · `crear_custom` |  |
| POST | `/api/cuestionamientos-sesion/custom` | `web/routers/cuestionamientos_sesion.py` · `crear_custom` |  |
| DELETE | `/api/cuestionamientos-sesion/custom/{cid}` | `web/routers/cuestionamientos_sesion.py` · `borrar_custom` |  |
| DELETE | `/api/cuestionamientos-sesion/custom/{cid}` | `web/routers/cuestionamientos_sesion.py` · `borrar_custom` |  |
| POST | `/api/cuestionamientos-sesion/toggle` | `web/routers/cuestionamientos_sesion.py` · `toggle` |  |
| POST | `/api/cuestionamientos-sesion/toggle` | `web/routers/cuestionamientos_sesion.py` · `toggle` |  |
| GET | `/api/cuestionamientos/default` | `web/routers/cuestionamientos.py` · `listar_default` | Los cuestionamientos del catálogo + su flag `activo` (default True). |
| GET | `/api/cuestionamientos/default` | `web/routers/cuestionamientos.py` · `listar_default` | Los cuestionamientos del catálogo + su flag `activo` (default True). |
| POST | `/api/cuestionamientos/default/{cid}/toggle` | `web/routers/cuestionamientos.py` · `toggle_default` |  |
| POST | `/api/cuestionamientos/default/{cid}/toggle` | `web/routers/cuestionamientos.py` · `toggle_default` |  |
| GET | `/api/cuestionamientos/personalizados` | `web/routers/cuestionamientos.py` · `listar_personalizados` |  |
| GET | `/api/cuestionamientos/personalizados` | `web/routers/cuestionamientos.py` · `listar_personalizados` |  |
| POST | `/api/cuestionamientos/personalizados` | `web/routers/cuestionamientos.py` · `agregar_personalizado` |  |
| POST | `/api/cuestionamientos/personalizados` | `web/routers/cuestionamientos.py` · `agregar_personalizado` |  |
| DELETE | `/api/cuestionamientos/personalizados/{cid}` | `web/routers/cuestionamientos.py` · `borrar_personalizado` |  |
| DELETE | `/api/cuestionamientos/personalizados/{cid}` | `web/routers/cuestionamientos.py` · `borrar_personalizado` |  |
| GET | `/api/debug/conexiones` | `web/routers/debug_conexiones.py` · `conexiones` |  |
| GET | `/api/debug/conexiones` | `web/routers/debug_conexiones.py` · `conexiones` |  |
| GET | `/api/entendimiento` | `web/routers/entendimiento.py` · `obtener` |  |
| GET | `/api/entendimiento` | `web/routers/entendimiento.py` · `obtener` |  |
| POST | `/api/entendimiento/analizar` | `web/routers/entendimiento.py` · `analizar` | Analiza el ZIP descomprimido y genera `entendimiento_modelo_{slug}.md`. Reutiliza feedbac… |
| POST | `/api/entendimiento/analizar` | `web/routers/entendimiento.py` · `analizar` | Analiza el ZIP descomprimido y genera `entendimiento_modelo_{slug}.md`. Reutiliza feedbac… |
| POST | `/api/entendimiento/feedback` | `web/routers/entendimiento.py` · `feedback` |  |
| POST | `/api/entendimiento/feedback` | `web/routers/entendimiento.py` · `feedback` |  |
| DELETE | `/api/estandares` | `web/routers/estandares.py` · `borrar` |  |
| DELETE | `/api/estandares` | `web/routers/estandares.py` · `borrar` |  |
| POST | `/api/estandares/confirmar` | `web/routers/estandares.py` · `confirmar` | Acepta el estándar: si hay uno pendiente, reemplaza al vigente. Se re-parsea aquí en vez … |
| POST | `/api/estandares/confirmar` | `web/routers/estandares.py` · `confirmar` | Acepta el estándar: si hay uno pendiente, reemplaza al vigente. Se re-parsea aquí en vez … |
| GET | `/api/estandares/detalle` | `web/routers/estandares.py` · `get_detalle` |  |
| GET | `/api/estandares/detalle` | `web/routers/estandares.py` · `get_detalle` |  |
| GET | `/api/estandares/estado` | `web/routers/estandares.py` · `get_estado` |  |
| GET | `/api/estandares/estado` | `web/routers/estandares.py` · `get_estado` |  |
| DELETE | `/api/estandares/pendiente` | `web/routers/estandares.py` · `descartar_pendiente` | Descarta la subida sin aceptar; el estándar vigente sigue igual. |
| DELETE | `/api/estandares/pendiente` | `web/routers/estandares.py` · `descartar_pendiente` | Descarta la subida sin aceptar; el estándar vigente sigue igual. |
| POST | `/api/estandares/upload` | `web/routers/estandares.py` · `upload` | Sube el .xlsx como PENDIENTE y devuelve su vista previa. El estándar vigente (si lo hay) … |
| POST | `/api/estandares/upload` | `web/routers/estandares.py` · `upload` | Sube el .xlsx como PENDIENTE y devuelve su vista previa. El estándar vigente (si lo hay) … |
| GET | `/api/estandares/vista-previa` | `web/routers/estandares.py` · `get_vista_previa` | Vista previa del estándar que está en la sesión: el pendiente (recién subido, sin aceptar… |
| GET | `/api/estandares/vista-previa` | `web/routers/estandares.py` · `get_vista_previa` | Vista previa del estándar que está en la sesión: el pendiente (recién subido, sin aceptar… |
| POST | `/api/feedback/aprobar` | `web/routers/feedback_aprobacion.py` · `aprobar` |  |
| POST | `/api/feedback/aprobar` | `web/routers/feedback_aprobacion.py` · `aprobar` |  |
| GET | `/api/feedback/pendientes` | `web/routers/feedback_aprobacion.py` · `pendientes` |  |
| GET | `/api/feedback/pendientes` | `web/routers/feedback_aprobacion.py` · `pendientes` |  |
| GET | `/api/guia/progreso` | `web/routers/guia.py` · `progreso` |  |
| GET | `/api/guia/progreso` | `web/routers/guia.py` · `progreso` |  |
| POST | `/api/informe/consolidado` | `web/routers/informe.py` · `consolidar` |  |
| POST | `/api/informe/consolidado` | `web/routers/informe.py` · `consolidar` |  |
| GET | `/api/informe/descargar/{fichero}` | `web/routers/informe.py` · `descargar` |  |
| GET | `/api/informe/descargar/{fichero}` | `web/routers/informe.py` · `descargar` |  |
| GET | `/api/informe/estado` | `web/routers/informe.py` · `estado` | Panorama para el panel «Documentar Todo». |
| GET | `/api/informe/estado` | `web/routers/informe.py` · `estado` | Panorama para el panel «Documentar Todo». |
| GET | `/api/informe/versiones` | `web/routers/informe.py` · `versiones` |  |
| GET | `/api/informe/versiones` | `web/routers/informe.py` · `versiones` |  |
| GET | `/api/inputs/arbol` | `web/routers/upload.py` · `arbol_inputs` | Árbol de `inputs/` DE LA SESIÓN activa. El RAG global no se muestra aquí (tiene su propia… |
| GET | `/api/inputs/arbol` | `web/routers/upload.py` · `arbol_inputs` | Árbol de `inputs/` DE LA SESIÓN activa. El RAG global no se muestra aquí (tiene su propia… |
| DELETE | `/api/inputs/archivo/{slug}/{fichero}` | `web/routers/upload.py` · `borrar_archivo` | Borra un fichero SUBIDO desde este panel. Solo permite eliminar archivos directos (no ani… |
| DELETE | `/api/inputs/archivo/{slug}/{fichero}` | `web/routers/upload.py` · `borrar_archivo` | Borra un fichero SUBIDO desde este panel. Solo permite eliminar archivos directos (no ani… |
| GET | `/api/inputs/carpeta/{slug}` | `web/routers/upload.py` · `listar_carpeta` | Ficheros ya subidos a `slug` — para pintar cada card del upload guiado. |
| GET | `/api/inputs/carpeta/{slug}` | `web/routers/upload.py` · `listar_carpeta` | Ficheros ya subidos a `slug` — para pintar cada card del upload guiado. |
| GET | `/api/inputs/destinos` | `web/routers/upload.py` · `listar_destinos` | Slugs válidos con etiqueta y alcance (sesion/global). |
| GET | `/api/inputs/destinos` | `web/routers/upload.py` · `listar_destinos` | Slugs válidos con etiqueta y alcance (sesion/global). |
| POST | `/api/inputs/upload` | `web/routers/upload.py` · `subir_archivos` |  |
| POST | `/api/inputs/upload` | `web/routers/upload.py` · `subir_archivos` |  |
| POST | `/api/inputs/upload-zip` | `web/routers/upload.py` · `subir_zip` | Descomprime un ZIP en `destino`. Antes: el flujo especial para el slug 'raiz' respetaba s… |
| POST | `/api/inputs/upload-zip` | `web/routers/upload.py` · `subir_zip` | Descomprime un ZIP en `destino`. Antes: el flujo especial para el slug 'raiz' respetaba s… |
| GET | `/api/modelos` | `web/routers/modelos.py` · `listar_modelos` |  |
| GET | `/api/modelos` | `web/routers/modelos.py` · `listar_modelos` |  |
| POST | `/api/modelos` | `web/routers/modelos.py` · `crear_modelo` |  |
| POST | `/api/modelos` | `web/routers/modelos.py` · `crear_modelo` |  |
| GET | `/api/modelos/activo` | `web/routers/modelos.py` · `modelo_activo` | Modelo actualmente seleccionado (o `None`). |
| GET | `/api/modelos/activo` | `web/routers/modelos.py` · `modelo_activo` | Modelo actualmente seleccionado (o `None`). |
| POST | `/api/modelos/desactivar` | `web/routers/modelos.py` · `desactivar` |  |
| POST | `/api/modelos/desactivar` | `web/routers/modelos.py` · `desactivar` |  |
| DELETE | `/api/modelos/{slug}` | `web/routers/modelos.py` · `borrar_modelo` |  |
| DELETE | `/api/modelos/{slug}` | `web/routers/modelos.py` · `borrar_modelo` |  |
| POST | `/api/modelos/{slug}/activar` | `web/routers/modelos.py` · `activar_modelo` | Marca el modelo como activo (cookie); el resto del backend lo usa. |
| POST | `/api/modelos/{slug}/activar` | `web/routers/modelos.py` · `activar_modelo` | Marca el modelo como activo (cookie); el resto del backend lo usa. |
| GET | `/api/motores/catalogo` | `web/routers/controles.py` · `catalogo` | Las pruebas genéricas de `modulos.motores_datos.REGISTRO_MOTORES`. |
| GET | `/api/motores/catalogo` | `web/routers/controles.py` · `catalogo` | Las pruebas genéricas de `modulos.motores_datos.REGISTRO_MOTORES`. |
| GET | `/api/motores/entidad` | `web/routers/controles.py` · `resultados_de_la_entidad` | Lee las tablas de resultados que la entidad deja bajo `inputs/calidad_datos/resultadocali… |
| GET | `/api/motores/entidad` | `web/routers/controles.py` · `resultados_de_la_entidad` | Lee las tablas de resultados que la entidad deja bajo `inputs/calidad_datos/resultadocali… |
| GET | `/api/motores/notebook` | `web/routers/controles.py` · `descargar_notebook_controles` | Genera y devuelve el .ipynb ENTREGABLE de controles de datos (8 columnas). Fuente de los … |
| GET | `/api/motores/notebook` | `web/routers/controles.py` · `descargar_notebook_controles` | Genera y devuelve el .ipynb ENTREGABLE de controles de datos (8 columnas). Fuente de los … |
| POST | `/api/prevuelo` | `web/routers/dominio_prevuelo.py` · `prevuelo` | Coste 0. Recorre `web/data/sesiones/{val}/{slug}/inputs/` y devuelve el diagnóstico. Un á… |
| POST | `/api/prevuelo` | `web/routers/dominio_prevuelo.py` · `prevuelo` | Coste 0. Recorre `web/data/sesiones/{val}/{slug}/inputs/` y devuelve el diagnóstico. Un á… |
| GET | `/api/prompts` | `web/routers/prompts.py` · `get_efectivos` | Los prompts efectivos de la sesión (custom si existen, base si no). |
| GET | `/api/prompts` | `web/routers/prompts.py` · `get_efectivos` | Los prompts efectivos de la sesión (custom si existen, base si no). |
| GET | `/api/prompts/base` | `web/routers/prompts.py` · `get_base` | Los prompts por defecto (para el editor cuando aún no hay sesión). |
| GET | `/api/prompts/base` | `web/routers/prompts.py` · `get_base` | Los prompts por defecto (para el editor cuando aún no hay sesión). |
| POST | `/api/prompts/editar` | `web/routers/prompts.py` · `editar` |  |
| POST | `/api/prompts/editar` | `web/routers/prompts.py` · `editar` |  |
| GET | `/api/prompts/presupuesto` | `web/routers/prompts.py` · `presupuesto` | Presupuesto de contexto para la sesión. Usa el modelo detectado por /api/config/verificar… |
| GET | `/api/prompts/presupuesto` | `web/routers/prompts.py` · `presupuesto` | Presupuesto de contexto para la sesión. Usa el modelo detectado por /api/config/verificar… |
| POST | `/api/prompts/restaurar` | `web/routers/prompts.py` · `restaurar` |  |
| POST | `/api/prompts/restaurar` | `web/routers/prompts.py` · `restaurar` |  |
| GET | `/api/rag/dominios` | `web/routers/rag.py` · `listar_dominios` | Fijos primero, custom después. Cada uno con estado del índice y papers. |
| GET | `/api/rag/dominios` | `web/routers/rag.py` · `listar_dominios` | Fijos primero, custom después. Cada uno con estado del índice y papers. |
| POST | `/api/rag/dominios/crear` | `web/routers/rag.py` · `crear_dominio` |  |
| POST | `/api/rag/dominios/crear` | `web/routers/rag.py` · `crear_dominio` |  |
| DELETE | `/api/rag/dominios/{dom_id}` | `web/routers/rag.py` · `borrar_dominio` |  |
| DELETE | `/api/rag/dominios/{dom_id}` | `web/routers/rag.py` · `borrar_dominio` |  |
| DELETE | `/api/rag/dominios/{dom_id}/paper/{nombre}` | `web/routers/rag.py` · `borrar_paper` | Elimina un libro/manual CONCRETO del corpus `inputs/rag/{dom_id}/` y reindexa, para que e… |
| DELETE | `/api/rag/dominios/{dom_id}/paper/{nombre}` | `web/routers/rag.py` · `borrar_paper` | Elimina un libro/manual CONCRETO del corpus `inputs/rag/{dom_id}/` y reindexa, para que e… |
| POST | `/api/rag/reconstruir` | `web/routers/rag.py` · `reconstruir` | Reconstruye el índice del dominio dado. Acepta cualquier dominio conocido (fijo o custom)… |
| POST | `/api/rag/reconstruir` | `web/routers/rag.py` · `reconstruir` | Reconstruye el índice del dominio dado. Acepta cualquier dominio conocido (fijo o custom)… |
| GET | `/api/resultados/actual` | `web/routers/resultados.py` · `resultado_de_la_ultima_corrida` |  |
| GET | `/api/resultados/actual` | `web/routers/resultados.py` · `resultado_de_la_ultima_corrida` |  |
| GET | `/api/resultados/excel` | `web/routers/resultados.py` · `descargar_excel` | Descarga la tabla de validación en Excel. · tipo=intermedio → estado inicial (pre-chat). … |
| GET | `/api/resultados/excel` | `web/routers/resultados.py` · `descargar_excel` | Descarga la tabla de validación en Excel. · tipo=intermedio → estado inicial (pre-chat). … |
| GET | `/api/resultados/lista` | `web/routers/resultados.py` · `listar_resultados` | Todos los `resultados_*.json` DE LA SESIÓN activa. |
| GET | `/api/resultados/lista` | `web/routers/resultados.py` · `listar_resultados` | Todos los `resultados_*.json` DE LA SESIÓN activa. |
| GET | `/api/resultados/tabla` | `web/routers/resultados.py` · `tabla_de_la_ultima_corrida` | Output intermedio: la tabla de validación por actividad (Ámbito / Control / Actividad / T… |
| GET | `/api/resultados/tabla` | `web/routers/resultados.py` · `tabla_de_la_ultima_corrida` | Output intermedio: la tabla de validación por actividad (Ámbito / Control / Actividad / T… |
| GET | `/api/resultados/tabla/{fecha}/{fichero}` | `web/routers/resultados.py` · `tabla_por_ruta` |  |
| GET | `/api/resultados/tabla/{fecha}/{fichero}` | `web/routers/resultados.py` · `tabla_por_ruta` |  |
| GET | `/api/resultados/{fecha}/{fichero}` | `web/routers/resultados.py` · `resultado_por_ruta` |  |
| GET | `/api/resultados/{fecha}/{fichero}` | `web/routers/resultados.py` · `resultado_por_ruta` |  |
| GET | `/api/salud` | `web/app.py` · `salud` |  |
| GET | `/api/skills` | `web/routers/skills.py` · `get_skills` | Skills DE LA SESIÓN activa: defaults (con flag `activo` según el estado guardado) + custo… |
| GET | `/api/skills` | `web/routers/skills.py` · `get_skills` | Skills DE LA SESIÓN activa: defaults (con flag `activo` según el estado guardado) + custo… |
| POST | `/api/skills/custom` | `web/routers/skills.py` · `crear_custom` |  |
| POST | `/api/skills/custom` | `web/routers/skills.py` · `crear_custom` |  |
| DELETE | `/api/skills/custom/{skill_id}` | `web/routers/skills.py` · `borrar_custom` |  |
| DELETE | `/api/skills/custom/{skill_id}` | `web/routers/skills.py` · `borrar_custom` |  |
| GET | `/api/skills/defaults` | `web/routers/skills.py` · `listar_defaults` | Catálogo por defecto SIN estado (para inspección/documentación). |
| GET | `/api/skills/defaults` | `web/routers/skills.py` · `listar_defaults` | Catálogo por defecto SIN estado (para inspección/documentación). |
| POST | `/api/skills/toggle` | `web/routers/skills.py` · `toggle` |  |
| POST | `/api/skills/toggle` | `web/routers/skills.py` · `toggle` |  |
| POST | `/api/solo-informe/adjunto` | `web/routers/solo_informe.py` · `subir_adjunto` | Excel, Word, PowerPoint, correo (.msg/.eml) o PDF que se incrusta en el Word con su icono… |
| POST | `/api/solo-informe/adjunto` | `web/routers/solo_informe.py` · `subir_adjunto` | Excel, Word, PowerPoint, correo (.msg/.eml) o PDF que se incrusta en el Word con su icono… |
| PUT | `/api/solo-informe/borrador` | `web/routers/solo_informe.py` · `guardar_borrador` |  |
| PUT | `/api/solo-informe/borrador` | `web/routers/solo_informe.py` · `guardar_borrador` |  |
| GET | `/api/solo-informe/descargar/{nombre}` | `web/routers/solo_informe.py` · `descargar` |  |
| GET | `/api/solo-informe/descargar/{nombre}` | `web/routers/solo_informe.py` · `descargar` |  |
| GET | `/api/solo-informe/estado` | `web/routers/solo_informe.py` · `estado` |  |
| GET | `/api/solo-informe/estado` | `web/routers/solo_informe.py` · `estado` |  |
| DELETE | `/api/solo-informe/estandar` | `web/routers/solo_informe.py` · `borrar_estandar` |  |
| DELETE | `/api/solo-informe/estandar` | `web/routers/solo_informe.py` · `borrar_estandar` |  |
| POST | `/api/solo-informe/estandar` | `web/routers/solo_informe.py` · `subir_estandar` |  |
| POST | `/api/solo-informe/estandar` | `web/routers/solo_informe.py` · `subir_estandar` |  |
| POST | `/api/solo-informe/generar` | `web/routers/solo_informe.py` · `generar` |  |
| POST | `/api/solo-informe/generar` | `web/routers/solo_informe.py` · `generar` |  |
| GET | `/api/solo-informe/ia/estado` | `web/routers/solo_informe.py` · `ia_estado` |  |
| GET | `/api/solo-informe/ia/estado` | `web/routers/solo_informe.py` · `ia_estado` |  |
| POST | `/api/solo-informe/ia/grafico` | `web/routers/solo_informe.py` · `ia_grafico` |  |
| POST | `/api/solo-informe/ia/grafico` | `web/routers/solo_informe.py` · `ia_grafico` |  |
| POST | `/api/solo-informe/ia/manuales` | `web/routers/solo_informe.py` · `ia_manuales` |  |
| POST | `/api/solo-informe/ia/manuales` | `web/routers/solo_informe.py` · `ia_manuales` |  |
| POST | `/api/solo-informe/ia/pulir` | `web/routers/solo_informe.py` · `ia_pulir` |  |
| POST | `/api/solo-informe/ia/pulir` | `web/routers/solo_informe.py` · `ia_pulir` |  |
| POST | `/api/solo-informe/imagen` | `web/routers/solo_informe.py` · `subir_imagen` |  |
| POST | `/api/solo-informe/imagen` | `web/routers/solo_informe.py` · `subir_imagen` |  |
| GET | `/api/solo-informe/imagen/{ident}` | `web/routers/solo_informe.py` · `ver_imagen` |  |
| GET | `/api/solo-informe/imagen/{ident}` | `web/routers/solo_informe.py` · `ver_imagen` |  |
| GET | `/api/solo-informe/manuales` | `web/routers/solo_informe.py` · `manuales` |  |
| GET | `/api/solo-informe/manuales` | `web/routers/solo_informe.py` · `manuales` |  |
| POST | `/api/solo-informe/manuales` | `web/routers/solo_informe.py` · `subir_manual` |  |
| POST | `/api/solo-informe/manuales` | `web/routers/solo_informe.py` · `subir_manual` |  |
| DELETE | `/api/solo-informe/manuales/{nombre}` | `web/routers/solo_informe.py` · `borrar_manual` |  |
| DELETE | `/api/solo-informe/manuales/{nombre}` | `web/routers/solo_informe.py` · `borrar_manual` |  |
| POST | `/api/validacion/preview-prompt` | `web/routers/preview_prompt.py` · `preview_prompt` |  |
| POST | `/api/validacion/preview-prompt` | `web/routers/preview_prompt.py` · `preview_prompt` |  |
| POST | `/api/validar/cancelar/{run_id}` | `web/routers/validacion.py` · `cancelar_validacion` |  |
| POST | `/api/validar/cancelar/{run_id}` | `web/routers/validacion.py` · `cancelar_validacion` |  |
| GET | `/api/validar/estado` | `web/routers/validacion.py` · `estado_actual` |  |
| GET | `/api/validar/estado` | `web/routers/validacion.py` · `estado_actual` |  |
| POST | `/api/validar/lanzar` | `web/routers/validacion.py` · `lanzar_validacion` |  |
| POST | `/api/validar/lanzar` | `web/routers/validacion.py` · `lanzar_validacion` |  |
| WEBSOCKET | `/ws/chat` | `web/routers/chat.py` · `ws_chat` | Requiere cookies `virf_token` (login) y `virf_modelo` (modelo activo). Sirve el chat del … |
| WEBSOCKET | `/ws/chat` | `web/routers/chat.py` · `ws_chat` | Requiere cookies `virf_token` (login) y `virf_modelo` (modelo activo). Sirve el chat del … |
| WEBSOCKET | `/ws/validar/{run_id}` | `web/routers/validacion.py` · `ws_validar` | Emite el stream de eventos del runner identificado por `run_id`. Al ser un WebSocket, la … |
| WEBSOCKET | `/ws/validar/{run_id}` | `web/routers/validacion.py` · `ws_validar` | Emite el stream de eventos del runner identificado por `run_id`. Al ser un WebSocket, la … |

## 4. Parámetros de negocio (`config/dominio.py`)

**Tiers válidos:** `1`→`I`, `2`→`II`, `3`→`III`, `4`→`IV`, `I`→`I`, `II`→`II`, `III`→`III`, `IV`→`IV`

**Pesos por ámbito** (deben sumar exactamente 1,00):

| Ámbito | Peso | Referencia normativa |
|---|---:|---|
| Documentación | 0.15 | EBA/GL/2023/01 §6.3 |
| Calidad de datos | 0.2 | BCBS 239 principios 3-5 |
| Metodología | 0.3 | SR 11-7 §IV conceptual soundness |
| Gobierno | 0.12 | EBA/GL/2023/01 §5 |
| Implementación | 0.15 | SR 11-7 §IV outcome analysis |
| Uso e integración a la gestión | 0.08 | SR 11-7 §IV ongoing monitoring |

Suma de pesos: **1.00**

**Escala de puntaje:** `{1: {'label': 'No cumple', 'color': 'FF0000'}, 2: {'label': 'Cumple parcialmente - obs. críticas', 'color': 'FF6600'}, 3: {'label': 'Cumple parcialmente', 'color': 'FFCC00'}, 4: {'label': 'Cumple con observaciones menores', 'color': '92D050'}, 5: {'label': 'Cumple plenamente', 'color': '00B050'}}`

**Semáforo:** `{(4.5, 5.0): {'label': 'SATISFACTORIO', 'color': '00B050'}, (3.5, 4.5): {'label': 'ACEPTABLE', 'color': '92D050'}, (2.5, 3.5): {'label': 'CON OBSERVACIONES', 'color': 'FFCC00'}, (1.5, 2.5): {'label': 'DEFICIENTE', 'color': 'FF6600'}, (0.0, 1.5): {'label': 'CRÍTICO', 'color': 'FF0000'}}`

**Extensiones soportadas:** `['.csv', '.docx', '.json', '.pdf', '.pptx', '.py', '.txt', '.xlsx']`

## 5. Proveedores de IA y catálogo de modelos

| Proveedor | Estado en producción |
|---|---|
| `azure_openai` | APROBADO |
| `anthropic` | EN_ESPERA |
| `openai` | RETIRADO |

Ejecutan además en `MODO=debug|desarrollo`: `anthropic`, `openai`

**Catálogo de modelos** (`config/modelos.py`):

| Modelo | Contexto (tokens) | Máx. salida | Parámetro de tokens | ¿Admite temperature? | Familia |
|---|---:|---:|---|---|---|
| `gpt-5` | 400000 | 128000 | `max_completion_tokens` | no | razonamiento |
| `o3` | 200000 | 100000 | `max_completion_tokens` | no | razonamiento |
| `o1` | 200000 | 100000 | `max_completion_tokens` | no | razonamiento |
| `gpt-4.1` | 1000000 | 32768 | `max_tokens` | sí | gpt |
| `gpt-4o-mini` | 128000 | 16384 | `max_tokens` | sí | gpt |
| `gpt-4o` | 128000 | 16384 | `max_tokens` | sí | gpt |
| `gpt-4-turbo` | 128000 | 4096 | `max_tokens` | sí | gpt |
| `gpt-4-32k` | 32768 | 4096 | `max_tokens` | sí | gpt |
| `gpt-4` | 8192 | 4096 | `max_tokens` | sí | gpt |
| `gpt-35-turbo` | 16385 | 4096 | `max_tokens` | sí | gpt |
| `claude-haiku-4-5` | 200000 | 8192 | `max_tokens` | sí | claude |
| `claude-sonnet-4` | 200000 | 8192 | `max_tokens` | sí | claude |
| `claude-opus-4` | 200000 | 8192 | `max_tokens` | sí | claude |
| `claude-` | 200000 | 8192 | `max_tokens` | sí | claude |

## 6. Dependencias fijadas

**`requirements.txt`**

| Paquete | Versión | Comentario |
|---|---|---|
| `anthropic` | `==0.105.2` |  |
| `openai` | `==2.48.0` | requerido por ClienteAzureOpenAIIA (config.py) |
| `pandas` | `==2.1.4` |  |
| `numpy` | `==1.26.4` |  |
| `pyarrow` | `==23.0.1` |  |
| `python-docx` | `==1.2.0` | .docx |
| `python-pptx` | `==1.0.2` | .pptx |
| `openpyxl` | `==3.1.5` | .xlsx / .xlsm |
| `PyPDF2` | `==3.0.1` | PDF (intento 2 en Mx_01) |
| `pdfminer.six` | `==20251230` | PDF (intento 1 en Mx_01) |
| `pdfplumber` | `==0.11.9` | PDF tabular |
| `rank_bm25` | `==0.2.2` | BM25Okapi — Python puro, solo depende de numpy |
| `scikit-learn` | `==1.4.2` |  |
| `scipy` | `==1.11.4` |  |
| `statsmodels` | `==0.14.5` |  |
| `matplotlib` | `==3.7.5` |  |
| `seaborn` | `==0.13.2` |  |
| `nbformat` | `==5.10.4` |  |
| `nbclient` | `==0.10.4` |  |
| `jupytext` | `==1.19.5` |  |
| `ipykernel` | `==6.30.1` | kernel python3 para ejecutar notebooks |
| `oletools` | `==0.60.2` | extracción de macros VBA de .xlsm |
| `formulas` | `==1.3.4` | evaluador de fórmulas Excel en Python puro |
| `requests` | `==2.32.5` | usado en Mx_03_LlamarIA |
| `python-dotenv` | `==1.2.2` |  |
| `pyyaml` | `==6.0.3` |  |
| `pytest` | `==8.4.2` |  |
| `httpx` | `==0.28.1` |  |
| `pydantic` | `==2.13.5` |  |
| `cryptography` | `==50.0.1` |  |
| `certifi` | `==2026.7.22` |  |
| `lxml` | `==6.1.3` |  |
| `olefile` | `==0.47` |  |
| `pillow` | `==12.3.0` |  |
| `pypdfium2` | `==5.13.0` |  |
| `truststore` | `==0.10.5` | config/red.py, solo con VIRF_TLS_ALMACEN_SISTEMA=1 |
| `azure-identity` | `==1.27.0` | config/secretos.py (Key Vault) |
| `azure-keyvault-secrets` | `==4.12.0` | config/secretos.py (Key Vault) |
| `msal` | `==1.39.0` | config/identidad.py (SSO) |
| `reportlab` | `==5.1.0` | scripts/generar_corpus_rag.py (corpus RAG) |

**`web/requirements_web.txt`**

| Paquete | Versión | Comentario |
|---|---|---|
| `fastapi` | `==0.141.1` |  |
| `uvicorn[standard]` | `==0.52.2` |  |
| `python-multipart` | `==0.0.32` |  |


## 7. Pruebas

80 archivos de prueba · 1554 funciones `test*` (pytest expande las parametrizadas: el total ejecutado es mayor).

| Archivo | Tests | Qué cubre |
|---|---:|---|
| `tests/skills/test_calidad_datos.py` | 4 | Prueba unitaria de la Skill 2 (Calidad de Datos) — guía §4.B. Fixture sintético con EXACTAMENTE 10 outliers obvios + 5 duplicados… |
| `tests/skills/test_cola_pendiente.py` | 3 | Prueba de la cola PENDIENTE (HITL) — antipatrón exceso de agencia (guía §5.1). Una acción de impacto externo debe QUEDAR ENCOLADA… |
| `tests/skills/test_skills_tipadas.py` | 8 | Arnés por skill — fundación tipada (SK-00 / SK-01). Verifica lo que se puede probar SIN API: · las 6 skills exponen una declaraci… |
| `tests/test_abstencion.py` | 6 | tests/test_abstencion.py — WP-01 · indicador D3. Verifica la compuerta de abstención activa (modulos/abstencion.py) de forma DETE… |
| `tests/test_acta_cierre.py` | 5 | Pruebas del ACTA DE CIERRE en Excel (3 hojas) generada al finalizar el chat. Coste 0: no llama al LLM; usa datos sintéticos y con… |
| `tests/test_adjuntos_ole.py` | 5 | tests/test_adjuntos_ole.py — Archivos incrustados en el Word con su icono (modulos/adjuntos_ole.py). Sin coste y sin Microsoft Wo… |
| `tests/test_aislamiento.py` | 7 | tests/test_aislamiento.py — WP-02 reducido · indicador D2. Verifica el aislamiento multi-tenant (modulos/aislamiento.py) de forma… |
| `tests/test_almacenamiento.py` | 15 | SEG-06 · Almacenamiento local. · Sin clasificación no se sube nada; Restringido en el portátil se rechaza. · La caché de document… |
| `tests/test_antialucinacion_brechas.py` | 33 | tests/test_antialucinacion_brechas.py — auditoría anti-alucinación (2026-11-18). Cada prueba fija una brecha que se encontró y se… |
| `tests/test_aprendizaje_chat.py` | 11 | tests/test_aprendizaje_chat.py — WP-D: el chat guarda correcciones como feedback (contexto + ajuste automático en futuras corrida… |
| `tests/test_arbol_entornos.py` | 3 | Los recorridos del árbol deben reconocer un entorno virtual por `pyvenv.cfg`, no por su nombre. Con el filtro por nombre, un ento… |
| `tests/test_auditoria.py` | 9 | SEG-12 · Auditoría de acciones web. Cada acción sensible produce EXACTAMENTE una entrada con quién, qué, cuándo, desde dónde y re… |
| `tests/test_automatizaciones.py` | 12 | tests/test_automatizaciones.py Cuadro de observaciones desde los Excels 00–03 de automatización. Coste cero. Fija las reglas de n… |
| `tests/test_azure_mocks.py` | 70 | tests/test_azure_mocks.py Verificación del flujo completo con Azure OpenAI SIMULADO. No hay credencial de Azure todavía, así que … |
| `tests/test_beta_calibracion.py` | 5 | tests/test_beta_calibracion.py — β de abstención calibrado por datos (Día 2). β se fijó (config.ABSTENCION_BETA) desde la distrib… |
| `tests/test_capturas.py` | 6 | Capturas de evidencia para los informes («pantallazos»). Coste cero: sin IA; los PDF se generan al vuelo con Pillow y todo vive e… |
| `tests/test_chat_adjuntar.py` | 2 | tests/test_chat_adjuntar.py — WP-C: adjuntar evidencia en el chat → re-evaluar. Coste 0: usa el mock del chat (VIRF_MOCK_CHAT=1),… |
| `tests/test_chunker_estructural.py` | 7 | tests/test_chunker_estructural.py — chunking estructural (GAP-29). Verifica que la segmentación estructural (modulos/chunker_estr… |
| `tests/test_circuit_breakers.py` | 8 | tests/test_circuit_breakers.py — WP-05 · indicador D6. Verifica el cortacircuitos (modulos/fusibles.py) de forma DETERMINISTA y S… |
| `tests/test_citas_deterministas.py` | 7 | tests/test_citas_deterministas.py — WP-03/WP-04 · indicador D4 (parte determinista). Verifica el validador de citas con id de lin… |
| `tests/test_clasificacion_docx.py` | 6 | SEG-10 · Clasificación de informes: ningún Word sale sin la etiqueta «Datos elaborados por BCP para uso Interno» en el pie de tod… |
| `tests/test_consolidacion.py` | 6 | tests/test_consolidacion.py Cierre HITL: el chat produce el puntaje EXACTO final (WP-A). Coste 0: no llama al modelo. Verifica el… |
| `tests/test_corrida_fallida.py` | 12 | tests/test_corrida_fallida.py — una corrida que no puede evaluar lo dice. Reproducido el 2026-11-11 lanzando `agente.py` con una … |
| `tests/test_costes.py` | 5 | Pasos 54 · 56 · 57 — coste por llamada en la bitácora y reporte por corrida/usuario. |
| `tests/test_credenciales.py` | 20 | SEG-03 · Credenciales. · Ningún endpoint web acepta una clave y nada en web/ escribe el `.env`. · Las claves solo se leen vía con… |
| `tests/test_databricks_minimo_dato.py` | 6 | SEG-14 · Databricks: identidad de servicio y mínimo dato necesario. · Ninguna lectura de Unity Catalog trae la tabla completa: co… |
| `tests/test_deteccion_proveedor.py` | 33 | tests/test_deteccion_proveedor.py — basta con poner la clave (2026-11-11). Fija tres cosas, todas con dobles (coste 0, sin red): … |
| `tests/test_diagnostico_azure.py` | 11 | Diagnóstico por capas de la conexión con Azure OpenAI (sin red real). |
| `tests/test_documentacion_consistente.py` | 6 | SEG-13 · Una sola verdad entre código, manual y CONOCIMIENTO. · Defaults EN CÓDIGO: MODO=produccion e IA_PROVEEDOR=azure_openai. … |
| `tests/test_docx_regresion.py` | 6 | tests/test_docx_regresion.py — WP-08 (estructura): reporte .docx desde ValidationReport mock. Sin API (no usa el pipeline real). … |
| `tests/test_ejecucion_codigo.py` | 11 | SEG-07 · Ejecución de código. · No existe exec/eval/compile(…, "exec") en el código de producción (AST). · META se lee con AST: u… |
| `tests/test_endpoint_notebook_controles.py` | 2 | Prueba del endpoint GET /api/motores/notebook (coste 0: LLM interceptado). Sobrescribe la dependencia de sesión con un contexto d… |
| `tests/test_entailment.py` | 7 | Verificación semántica de citas (modulos/entailment.py) — SIN API. Se inyecta un cliente falso (no toca ningún proveedor): coste … |
| `tests/test_esquemas.py` | 10 | tests/test_esquemas.py — contrato Pydantic ValidationReport (WP-09). Verifica que un dict correcto produce un ValidationReport vá… |
| `tests/test_estandares_sesion.py` | 16 | Tests del paso 02 · Estándares de validación por sesión (WEB-V2.4). Cubre: - Parseo del .xlsx con celdas combinadas simulando ámb… |
| `tests/test_estructura_config.py` | 22 | tests/test_estructura_config.py Estructura de config/ y preparación para Azure OpenAI. Dos familias de comprobaciones: · que nadi… |
| `tests/test_estudio_insumos.py` | 6 | Estudio de insumos (manuales, Excels de primera línea, scripts) para la Validación completa: lectura ÍNTEGRA por partes, .zip, ca… |
| `tests/test_exportador_excel.py` | 2 | tests/test_exportador_excel.py — Excel de la tabla de validación (WP-B). Coste 0. |
| `tests/test_fallos_qa_sonnet.py` | 6 | Regresiones de los fallos que encontró el QA con Sonnet (pruebas/kit_qa_sonnet): F1 /api/cuestionamientos/* escribía config globa… |
| `tests/test_gateway_ia.py` | 16 | SEG-05 · Punto único de salida a IA. Fija dos cosas: 1. ARQUITECTURA — los SDK de proveedor solo se importan en config/ia.py; tod… |
| `tests/test_gobierno_codigo.py` | 16 | Brechas «Pasos Generales Agente 2» con código: 3, 11, 15, 20, 25, 43, 49. Los documentos de gobierno deben coincidir con el códig… |
| `tests/test_gobierno_ia.py` | 7 | SEG-09 · Gobierno de riesgo de modelo IA y tratamiento de SAST/SCA. · Los índices RAG (pickle) solo se deserializan con firma HMA… |
| `tests/test_guia_agente.py` | 7 | Guía del agente corporativo (scripts/generar_guia_agente.py + docs/agente_corporativo/). Coste cero: sin IA y sin Word (el PDF no… |
| `tests/test_guia_progreso.py` | 5 | tests/test_guia_progreso.py — Paso 01 de la guía de la web (/api/guia/progreso). [SEG-01/03] La guía solo da el paso 01 por hecho… |
| `tests/test_identidad.py` | 23 | SEG-02 · Identidad y firma. · Sin sesión → 401 en la web y el pipeline no firma. · El firmante = identidad autenticada (aserción … |
| `tests/test_informe_tabla_final.py` | 2 | tests/test_informe_tabla_final.py — la tabla final se cablea al .docx. Coste 0. |
| `tests/test_invariante_asyncio.py` | 2 | Invariante: ninguna `asyncio.create_task(...)` puede quedar como sentencia suelta. El event loop solo guarda referencias DÉBILES … |
| `tests/test_inyeccion.py` | 7 | Defensa anti-inyección de instrucciones (modulos/inyeccion.py): alta precisión, 100% local. Neutraliza órdenes dirigidas al evalu… |
| `tests/test_notebook_controles.py` | 10 | Pruebas API-free del generador de notebook de controles de datos (8 columnas). Construye el .ipynb desde una lista sintética de c… |
| `tests/test_pendientes_auditoria.py` | 231 | tests/test_pendientes_auditoria.py Tests de los pendientes de auditoría externa (SBS / Big4). Cada clase fija un control que un a… |
| `tests/test_pii.py` | 24 | Enmascarado PII (modulos/pii.py): alta precisión, 100% local, sin red. Lo que se fija: · SEG-04 — base PERUANA: DNI (8 díg., con/… |
| `tests/test_plantilla_bcp.py` | 4 | Plantilla común de los tres informes Word (Solo Informe, «Generar informe» de la web y entregable del pipeline). Coste cero: sin … |
| `tests/test_presentacion_guia.py` | 10 | tests/test_presentacion_guia.py — La presentación «Guía de la herramienta» se genera desde el repositorio y no se queda atrás cua… |
| `tests/test_prompts_editables.py` | 17 | Tests de la capa de prompts editables por sesión y presupuesto dinámico (WEB-V2.3). Cubre: - PromptService.get_prompt: fallback b… |
| `tests/test_proveedores_ia.py` | 15 | SEG-01 · Lista cerrada de proveedores de IA (decisión del banco, no reabrir): azure_openai = APROBADO · anthropic = EN_ESPERA · o… |
| `tests/test_rag_desactualizado.py` | 4 | tests/test_rag_desactualizado.py — el panel RAG avisa si el índice quedó obsoleto tras añadir manuales (cierra el footgun de «sub… |
| `tests/test_rag_lexico.py` | 39 | tests/test_rag_lexico.py Tests del RAG LÉXICO (BM25 + TF-IDF) que sustituyó al RAG vectorial el 2026-07-31. Qué se prueba aquí y … |
| `tests/test_recursos_externos.py` | 3 | SEG-15 · Recursos externos: ningún HTML versionado carga nada de la red (fuentes, scripts, hojas de estilo, imágenes). Deben func… |
| `tests/test_regresion.py` | 464 | tests/test_regresion.py — Red de regresión del núcleo VIRF Origen: creada durante la auditoría de regresión del 2026-07-26, tras … |
| `tests/test_repositorio_corporativo.py` | 6 | SEG-11 · Repositorio de código: ninguna guía ni configuración apunta a nubes de código no autorizadas, y los remotos git solo pue… |
| `tests/test_requirements_web_fijados.py` | 1 | web/requirements_web.txt debe fijar versiones exactas (==), como requirements.txt. Con `>=` el Python del sistema y el .venv acab… |
| `tests/test_roles.py` | 15 | SEG-08 · Roles y permisos + integridad del feedback. · validador ejecuta y deja feedback propio; admin_corpus gestiona el RAG com… |
| `tests/test_salvaguardas_llm.py` | 11 | SEG-16 · Robustez del LLM: afirmaciones sin respaldo no llegan al informe. Casos adversariales: inyección reformulada, cita inexi… |
| `tests/test_solo_informe.py` | 39 | Tests del apartado «Solo Informe» (informe sin pipeline). Coste cero: no hay IA en ningún punto del flujo, y todo escribe en `tmp… |
| `tests/test_solo_informe_ia.py` | 21 | Tests de la asistencia con IA de «Solo Informe». Coste cero: el modelo se sustituye por `_llm_de_prueba`, que registra el prompt … |
| `tests/test_tabla_validacion.py` | 18 | tests/test_tabla_validacion.py Veredicto formal por actividad + tabla intermedia + puente al chat. Coste 0: no llama al modelo. C… |
| `tests/test_upload_zip.py` | 5 | POST /api/inputs/upload-zip — extracción segura de ZIP (coste 0, carpeta temporal). Fija: · un ZIP normal se extrae; · Zip Slip (… |
| `tests/test_usuario_libre.py` | 9 | Usuario libre (web v2, modo prueba) — el SSO corporativo queda para la web v3. · Solo existe con VIRF_IDENTIDAD_PROVEEDOR=libre d… |
| `tests/test_validacion_completa.py` | 10 | Validación completa: 5 chats (00–04). Cada iteración entrega un notebook {etapa}ITERn.ipynb que, ejecutado, genera {etapa}_result… |
| `tests/test_validador_entorno_hf.py` | 2 | Guardia de la política «cero HuggingFace / cero ChromaDB» (validate_project.py). Bug que fija: el chequeo del entorno usaba `impo… |
| `tests/test_verificacion_citas.py` | 12 | tests/test_verificacion_citas.py — una cita literal no se rechaza por su formato. Medido el 2026-11-11 sobre la corrida real de `… |
| `tests/test_versionado.py` | 13 | tests/test_versionado.py — WP-10: versionado temporal + ventana de contexto. Dos piezas, ambas deterministas y sin API: · Pre-fil… |
| `tests/test_virf_plus.py` | 12 | tests/test_virf_plus.py VIRF PLUS (GPT principal + Claude como segunda opinión) — coste cero, con dobles. Lo que se fija: · las d… |
| `tests/skills/test_calidad_datos.py` | 4 | Prueba unitaria de la Skill 2 (Calidad de Datos) — guía §4.B. Fixture sintético con EXACTAMENTE 10 outliers obvios + 5 duplicados… |
| `tests/skills/test_cola_pendiente.py` | 3 | Prueba de la cola PENDIENTE (HITL) — antipatrón exceso de agencia (guía §5.1). Una acción de impacto externo debe QUEDAR ENCOLADA… |
| `tests/skills/test_skills_tipadas.py` | 8 | Arnés por skill — fundación tipada (SK-00 / SK-01). Verifica lo que se puede probar SIN API: · las 6 skills exponen una declaraci… |
| `pruebas/seguridad/test_owasp_llm.py` | 10 | Paso 62 · Suite red-team alineada a OWASP Top 10 para aplicaciones LLM. Corre contra el gateway real (SEG-05) y los controles rea… |
| `pruebas/test_calidad_e2e.py` | 9 | Pasos 42 · 60 · 63 · 65 — métricas de calidad, rúbrica sellada y E2E sintético. |
| `pruebas/test_casos_borde.py` | 11 | Paso 64 · Casos borde de la lectura de evidencia (matriz: pruebas/matriz_casos_borde.md). Regla común: el lector NUNCA lanza, NUN… |
| `pruebas/seguridad/test_owasp_llm.py` | 10 | Paso 62 · Suite red-team alineada a OWASP Top 10 para aplicaciones LLM. Corre contra el gateway real (SEG-05) y los controles rea… |

## 8. Nodos centrales del grafo de código

8089 nodos · 18113 aristas.

| Nodo central (hub) | Archivo | Conexiones |
|---|---|---:|
| `web/static/js/app.js` | `web/static/js/app.js` | 193 |
| `agente.py` | `agente.py` | 114 |
| `main()` | `agente.py` | 96 |
| `generar_presentacion_guia.py` | `scripts/generar_presentacion_guia.py` | 80 |
| `motor_ia.py` | `modulos/motor_ia.py` | 75 |
| `plantilla_bcp.py` | `modulos/plantilla_bcp.py` | 73 |
| `ia.py` | `config/ia.py` | 68 |
| `generador_word.py` | `modulos/generador_word.py` | 68 |
| `informe_web.py` | `web/services/informe_web.py` | 67 |
| `pedirJSON()` | `web/static/js/app.js` | 66 |
| `escapeHtml()` | `web/static/js/app.js` | 65 |
| `modulos/validacion_completa.py` | `modulos/validacion_completa.py` | 62 |
| `generar_guia_agente.py` | `scripts/generar_guia_agente.py` | 54 |
| `validate_project.py` | `validate_project.py` | 53 |
| `get_cliente_ia()` | `config/ia.py` | 52 |
| `ChunkerService` | `modulos/chunker.py` | 50 |
| `solo_informe_ia.py` | `web/services/solo_informe_ia.py` | 50 |
| `Mx_01_LecturaEvidencias.py` | `motor/Mx_01_LecturaEvidencias.py` | 49 |
| `IndexadorLexico` | `src/rag/indexador_lexico.py` | 48 |
| `chat_service.py` | `web/services/chat_service.py` | 47 |
| `enmascarar()` | `modulos/pii.py` | 46 |
| `solo_informe_service.py` | `web/services/solo_informe_service.py` | 46 |
| `modulos/automatizaciones.py` | `modulos/automatizaciones.py` | 45 |
| `app.py` | `web/app.py` | 43 |
| `BuscadorLexico` | `src/rag/buscador_lexico.py` | 43 |
