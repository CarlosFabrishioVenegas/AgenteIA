# -*- coding: utf-8 -*-
"""
tests/test_antialucinacion_brechas.py — auditoría anti-alucinación (2026-11-18).

Cada prueba fija una brecha que se encontró y se cerró. Coste 0: ninguna llama a
una IA; las respuestas del modelo se simulan.

  1. Citas del pipeline: comillas «» y “” también se verifican; las citas cortas de
     una inconsistencia ya no escapan a la comprobación.
  2. Chat: citas y archivos inventados se avisan y un APROBADO apoyado en ellos
     queda PENDIENTE (nunca sube el puntaje por algo inventado).
  3. Prompt del chat: la regla «no inventes / no apruebes por cortesía» está en el
     código Y en `prompts_base.json` (que es el que se usa en ejecución).
  4. Resúmenes de documentos largos: el prompt prohíbe añadir y el texto avisa de
     que es un resumen de IA.
  5. Explicador: nombres y cifras que no constan en la evidencia se declaran.
  6. Solo Informe: una cita «[archivo, pág. N]» sin fragmento consultado se declara.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))

CONTEXTO = ("El modelo usa una ventana de 250 días y un nivel de confianza del 99% con "
            "retornos logarítmicos diarios. def f(r): return r[-500:]")
INVENTADA = ("ventana de 500 días y confianza del 95% con retornos simples semanales "
             "sobre toda la cartera")


# ── 1. Citas del pipeline ────────────────────────────────────────────────────
class TestCitasPipeline:
    @pytest.mark.parametrize("abre,cierra", [('"', '"'), ("“", "”"), ("«", "»")])
    def test_cita_inventada_se_detecta_con_cualquier_comilla(self, abre, cierra):
        from modulos.motor_ia import _verificar_citas
        assert _verificar_citas(f"manual.pdf → {abre}{INVENTADA}{cierra}", CONTEXTO)

    @pytest.mark.parametrize("abre,cierra", [('"', '"'), ("“", "”"), ("«", "»")])
    def test_cita_real_no_se_marca(self, abre, cierra):
        from modulos.motor_ia import _verificar_citas
        real = "una ventana de 250 días y un nivel de confianza del 99%"
        assert _verificar_citas(f"manual.pdf → {abre}{real}{cierra}", CONTEXTO) == []

    def test_cita_corta_de_inconsistencia_inventada_se_detecta(self):
        from modulos.motor_ia import _verificar_citas
        assert _verificar_citas('\n"ventana de 500 días"\n', CONTEXTO, min_chars=10)

    def test_cita_corta_de_inconsistencia_real_no_se_marca(self):
        from modulos.motor_ia import _verificar_citas
        assert _verificar_citas('\n"ventana de 250 días"\n"r[-500:]"\n', CONTEXTO,
                                min_chars=10) == []

    def test_el_minimo_por_defecto_sigue_siendo_40(self):
        """Por debajo de 40 una coincidencia casual es probable: no se endurece la evidencia."""
        from modulos.motor_ia import _verificar_citas
        assert _verificar_citas('"ventana de 500 días"', CONTEXTO) == []


# ── 2. Chat ──────────────────────────────────────────────────────────────────
def _obs():
    from web.services.chat_service import Observacion
    return Observacion(
        id="1", ambito="Implementación", actividad="x", puntaje=2,
        observacion="La ventana es de 500 días",
        evidencia='modelo.py → "retornos[-500:] en la función var_historico"',
        fragmento_codigo="def var_historico(r):\n    return r[-500:]",
        fragmento_ref="modelo.py:12", rag_contexto="Kupiec test")


class TestChat:
    def test_cita_real_no_genera_aviso(self):
        from web.services.chat_service import verificar_respuesta
        assert verificar_respuesta(_obs(), "", "", "Veo «return r[-500:]» en modelo.py:12") == []

    def test_cita_inventada_se_avisa(self):
        from web.services.chat_service import verificar_respuesta
        p = verificar_respuesta(_obs(), "", "",
                                "Según el manual «la ventana es de 250 días y se recalibra cada mes»")
        assert p and "cita no encontrada" in p[0]

    def test_archivo_inventado_se_avisa(self):
        from web.services.chat_service import verificar_respuesta
        p = verificar_respuesta(_obs(), "", "", "Revisé calibrar.py:88 y todo está bien")
        assert p and "calibrar.py:88" in p[0]

    def test_pregunta_sin_citas_no_genera_aviso(self):
        from web.services.chat_service import verificar_respuesta
        assert verificar_respuesta(_obs(), "", "", "¿Puedes aportar el acta de aprobación?") == []

    @staticmethod
    def _ctx(tmp_path):
        return {"clave": "T9/aa", "base": tmp_path,
                "modelo": {"nombre": "M", "tier": "I", "dominio": "LaR"}}

    @staticmethod
    def _datos():
        return {"resultados_por_ambito": {"Metodología": [
            {"actividad": "A1 ventana", "puntaje": 2, "resultado": "No cumple",
             "observacion": "ventana de 500 días", "evaluacion_valida": True}]}}

    def test_aprobado_apoyado_en_cita_inventada_queda_pendiente(self, monkeypatch, tmp_path):
        from web.services import chat_service as cs
        cs.clear_todo()
        ctx = self._ctx(tmp_path)
        cs.iniciar(ctx, self._datos(), "r.json")
        monkeypatch.setattr(cs, "_invocar_modelo", lambda prompt: {
            "veredicto": "APROBADO",
            "respuesta": "Subsanado: el manual dice «la ventana se fija en 250 días desde 2019»",
            "hallazgo": "ok"})
        r = cs.responder(ctx, "Ya está corregido")
        assert r["veredicto"] == "PENDIENTE"
        resp = [m for m in cs.sesion_activa(ctx).mensajes
                if m.quien == "agente" and m.observacion_id and m.veredicto == "PENDIENTE"][-1]
        assert "Verificación automática" in resp.texto

    def test_aprobado_sin_citas_inventadas_se_respeta(self, monkeypatch, tmp_path):
        from web.services import chat_service as cs
        cs.clear_todo()
        ctx = self._ctx(tmp_path)
        cs.iniciar(ctx, self._datos(), "r.json")
        monkeypatch.setattr(cs, "_invocar_modelo", lambda prompt: {
            "veredicto": "APROBADO", "respuesta": "De acuerdo, queda subsanado.",
            "hallazgo": "El validador aportó la corrección."})
        assert cs.responder(ctx, "Corregido en la versión 3")["veredicto"] == "APROBADO"


# ── 3. Prompt del chat: código y base editable en sincronía ──────────────────
class TestPromptChat:
    def test_regla_en_el_codigo(self):
        from web.services.chat_service import _PROMPT_JUEZ
        assert "NO INVENTES" in _PROMPT_JUEZ and "NO APRUEBES POR CORTESÍA" in _PROMPT_JUEZ

    def test_el_json_base_es_identico_al_codigo(self):
        """`prompts_base.json` es lo que se usa en ejecución: no puede diverger del código."""
        from web.services.chat_service import _PROMPT_JUEZ
        base = json.loads((RAIZ / "web" / "data" / "prompts_base.json")
                          .read_text(encoding="utf-8"))["chat_agente"]["contenido"]
        assert base.strip() == _PROMPT_JUEZ.strip()


# ── 4. Resúmenes de documentos largos ────────────────────────────────────────
class TestChunker:
    def test_prompts_prohiben_anadir(self):
        from modulos import chunker
        assert "ANTI-INVENCIÓN" in chunker._PROMPT_EXTRACCION
        assert "Consolidar no es interpretar" in chunker._PROMPT_CONSOLIDACION

    def test_el_texto_resumido_se_declara_resumen_de_ia(self):
        fuente = (RAIZ / "modulos" / "chunker.py").read_text(encoding="utf-8")
        assert "RESUMEN generado por IA" in fuente


# ── 5. Explicador ────────────────────────────────────────────────────────────
class TestExplicador:
    def _cls(self):
        from modulos.explicador_modelo import ExplicadorModelo
        return ExplicadorModelo

    def test_nombre_inexistente_se_declara(self):
        ev = "def var_historico(retornos): return -np.percentile(retornos[-500:], 1)  modelo_var.py"
        doc = "Usa `var_historico` en `modelo_var.py`, llama a `calibrar_lambda()` y `retornos[-500:]`."
        assert self._cls().elementos_no_hallados(doc, ev) == ["calibrar_lambda"]

    def test_bloques_de_codigo_no_se_evaluan(self):
        doc = "Flujo:\n```\n`dibujo_ascii`\n```"
        assert self._cls().elementos_no_hallados(doc, "nada") == []

    def test_seccion_de_verificacion(self):
        c = self._cls()
        assert "a contrastar" in c.seccion_verificacion(["x"])
        assert "constan en la evidencia" in c.seccion_verificacion([])


# ── 6. Solo Informe ──────────────────────────────────────────────────────────
class TestSoloInforme:
    FUENTES = [{"archivo": "Manual_LaR.pdf", "pagina": 12},
               {"archivo": "Manual_LaR.pdf", "pagina": 13}]

    def test_citas_validas_no_se_marcan(self):
        from web.services.solo_informe_ia import citas_sin_respaldo
        t = "X [Manual_LaR.pdf, pág. 12]. Y [manual_lar.pdf, pág. 13]."
        assert citas_sin_respaldo(t, self.FUENTES) == []

    def test_pagina_o_archivo_inexistente_se_marca(self):
        from web.services.solo_informe_ia import citas_sin_respaldo
        t = "Z [Manual_LaR.pdf, pág. 99] y [Otro.pdf, pág. 3]."
        assert citas_sin_respaldo(t, self.FUENTES) == [
            "[Manual_LaR.pdf, pág. 99]", "[Otro.pdf, pág. 3]"]


# ── 7. Solo Informe: «pulir» no puede introducir cifras ──────────────────────
class TestPulir:
    def _con_respuesta(self, monkeypatch, respuesta):
        from web.services import solo_informe_ia as ia
        monkeypatch.setattr(ia, "_llm_de_prueba", lambda prompt, sistema, max_tokens: respuesta)
        return ia

    def test_cifra_nueva_se_descarta(self, monkeypatch):
        ia = self._con_respuesta(monkeypatch, "La ventana es de 250 días y cubre 3 años.")
        with pytest.raises(ia.IAFallo, match="introduce cifras"):
            ia.pulir("La ventana es de 250 dias.", "observacion")

    def test_mismas_cifras_se_aceptan(self, monkeypatch):
        ia = self._con_respuesta(monkeypatch, "La ventana asciende a 250 días, con 99,0 % de confianza.")
        assert ia.pulir("ventana 250 dias confianza 99% .", "observacion") == \
            "La ventana asciende a 250 días, con 99,0 % de confianza."


# ── 8. Avisos deterministas: cifras, paráfrasis y ventana para el juez NLI ────
class TestVerificacionCifras:
    def test_cifra_ausente_se_marca_y_las_equivalentes_no(self):
        from modulos import verificacion_cifras as v
        base = "ventana 250 dias, 99% confianza, 1,250 casos, 7.5"
        texto = "ventana de 250 días, confianza 99,0 % y 1.250 casos; 7,5 puntos y 120 filas"
        assert v.cifras_ausentes(texto, base) == ["120"]

    def test_enteros_de_un_digito_son_numeracion_no_datos(self):
        from modulos import verificacion_cifras as v
        assert v.cifras_ausentes("el punto 3 y 5 casos", "sin cifras") == []

    def test_paráfrasis_sin_cita_se_detecta(self):
        from modulos import verificacion_cifras as v
        assert v.sin_cita_literal("el manual dice que la ventana es de 250 días") is True
        assert v.sin_cita_literal('manual.pdf → "la ventana es de 250 días"') is False
        assert v.sin_cita_literal("No se encontró evidencia en el contexto disponible") is False
        assert v.sin_cita_literal("") is False

    def test_ventana_relevante_trae_lo_pertinente_y_no_el_principio(self):
        from modulos import verificacion_cifras as v
        relleno = "\n\n".join(f"párrafo {i} sobre otros temas sin relación " * 30 for i in range(30))
        ctx = relleno + "\n\nLa ventana de 250 días del backtesting de Kupiec se aplica al VaR."
        w = v.ventana_relevante(ctx, "ventana backtesting Kupiec VaR")
        assert "Kupiec" in w and len(w) <= 4000 < len(ctx)
        assert "Kupiec" not in ctx[:4000]            # el método antiguo no lo habría visto

    def test_contexto_corto_se_devuelve_entero(self):
        from modulos import verificacion_cifras as v
        assert v.ventana_relevante("texto corto", "x") == "texto corto"


class TestCuadroAutomatizaciones:
    def _cuadro(self, tmp_path, obs):
        from datetime import date
        from modulos import automatizaciones as A
        from tests.test_automatizaciones import IAFalsa, _libro
        d = tmp_path / "automatizaciones"
        d.mkdir()
        _libro(d / "00_Diagnostico.xlsx", {"Poblacion": [
            ["Control", "Valor", "Resultado"],
            ["Conteo clientes", 15230, "OK"], ["Clientes duplicados", 12, "No cumple"]]})
        r = json.dumps({"observaciones": [obs]})
        return A.generar_cuadro(d, usar_ia=True, cliente=IAFalsa(r), contexto_modelo="M",
                                fecha_base=date(2026, 11, 18))["filas"][0]

    def test_cifra_inventada_y_evidencia_inexistente_se_avisan(self, tmp_path):
        f = self._cuadro(tmp_path, {
            "ambito": "Implementación", "titulo": "Duplicados",
            "observacion": "Se identificaron 12 clientes duplicados sobre 98765 registros.",
            "recomendacion": "Depurar.", "riesgo_estimado": "Moderado", "origen": "otro",
            "evidencia": ["00_Diagnostico.xlsx/HojaInexistente!5"]})
        txt = " ".join(f["avisos_verificacion"])
        assert "98765" in txt and "12" not in txt.replace("98765", "")
        assert "no corresponde a un libro/hoja" in txt

    def test_observacion_respaldada_no_genera_avisos(self, tmp_path):
        f = self._cuadro(tmp_path, {
            "ambito": "Implementación", "titulo": "Duplicados",
            "observacion": "Se identificaron 12 clientes duplicados sobre 15230 registros.",
            "recomendacion": "Depurar.", "riesgo_estimado": "Moderado", "origen": "otro",
            "evidencia": ["00_Diagnostico.xlsx/Poblacion!3"]})
        assert f["avisos_verificacion"] == []

    def test_el_excel_muestra_los_avisos(self, tmp_path):
        from modulos import automatizaciones as A
        from openpyxl import load_workbook
        fila = {"n": 1, "ambito": "Metodología", "riesgo": "Bajo", "riesgo_fuente": "estimado",
                "titulo": "", "observacion": "Obs.", "recomendacion": "Rec.",
                "evidencia": [], "responsable": "Eq", "fecha_compromiso": "2026-12-01",
                "avisos_verificacion": ["Cifras de la observación que no constan: 98765."]}
        ruta = A.exportar_excel({"filas": [fila], "libros": {}, "modo": "ia",
                                 "proveedor": "prueba", "faltan": []}, tmp_path / "c.xlsx")
        celda = load_workbook(ruta)["Cuadro de observaciones"].cell(2, 4).value
        assert "⚠ Cifras de la observación" in celda


# ── 9. Comillas simples tras «→» (aparecen en los resultados reales) ─────────
class TestComillasSimples:
    def test_cita_inventada_entre_comillas_simples_se_detecta(self):
        from modulos.motor_ia import _verificar_citas
        assert _verificar_citas(f"manual.pdf → '{INVENTADA}'", CONTEXTO)

    def test_cita_real_entre_comillas_simples_no_se_marca(self):
        from modulos.motor_ia import _verificar_citas
        real = "una ventana de 250 días y un nivel de confianza del 99%"
        assert _verificar_citas(f"manual.pdf → '{real}'", CONTEXTO) == []

    def test_un_apostrofo_normal_no_activa_la_comprobacion(self):
        from modulos.motor_ia import _verificar_citas
        assert _verificar_citas("el modelo d'Hondt no aplica aquí, según el manual", CONTEXTO) == []
