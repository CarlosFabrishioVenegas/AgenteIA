"""Diagnóstico por capas de la conexión con Azure OpenAI (sin red real)."""
from __future__ import annotations

import json
import socket

import httpx
import pytest

import diagnostico_azure_virf as diag
from config import red

CLAVE = "clave-de-prueba-0123456789abcdef"


@pytest.fixture
def entorno(monkeypatch, tmp_path):
    """Configuración válida, red simulada y un .env limpio."""
    env = tmp_path / ".env"
    env.write_text("IA_PROVEEDOR=azure_openai\nAZURE_OPENAI_ENDPOINT=https://rec.openai.azure.com/\n"
                   "AZURE_OPENAI_DEPLOYMENT=DEP01\nAZURE_OPENAI_API_VERSION=2024-10-21\n"
                   "MODO=debug\nVIRF_FUENTE_SECRETOS=entorno\n", encoding="utf-8")
    for k, v in {"IA_PROVEEDOR": "azure_openai", "MODO": "debug",
                 "AZURE_OPENAI_ENDPOINT": "https://rec.openai.azure.com/",
                 "AZURE_OPENAI_DEPLOYMENT": "DEP01", "VIRF_FUENTE_SECRETOS": "entorno",
                 "AZURE_OPENAI_API_KEY": CLAVE}.items():
        monkeypatch.setenv(k, v)
    for k in ("VIRF_TLS_INSECURE", "HTTPS_PROXY", "https_proxy", "VIRF_HOSTS_IA_PERMITIDOS"):
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setattr("config.secretos.RUTA_ENV", env)
    monkeypatch.setattr("config.parametros.MODO", "debug")
    monkeypatch.setattr("config.parametros.IA_PROVEEDOR", "azure_openai")
    monkeypatch.setattr("config.parametros.TLS_INSECURE", False)
    monkeypatch.setattr("config.parametros.AZURE_API_VERSION", "2024-10-21")
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(0, 0, 0, "", ("10.0.0.1", 443))])

    class _Sock:
        def close(self):
            pass
    monkeypatch.setattr(socket, "create_connection", lambda *a, **k: _Sock())
    # El intérprete de los tests puede no ser el del venv del proyecto.
    monkeypatch.setattr(diag, "capa_python", lambda c, ctx: setattr(c, "estado", diag.OK))
    return env


def _fabrica(respuesta):
    """Cliente con transporte simulado; GET / responde 404 (TLS OK)."""
    vistas = []

    def manejar(req: httpx.Request):
        vistas.append(req)
        if req.method == "GET":
            return httpx.Response(404)
        return respuesta(req)

    def fabrica(ctx):
        ctx.fuente_ca = "simulada"
        return httpx.Client(transport=httpx.MockTransport(manejar))
    fabrica.vistas = vistas
    return fabrica


def _ok_json(req):
    return httpx.Response(200, json={"model": "gpt-4o-2024-11-20",
                                     "choices": [{"message": {"content": '{"ok": true}'}}]})


def _estados(capas):
    return [k.estado for k in capas]


def test_todo_ok_y_la_clave_no_aparece(entorno, capsys):
    fab = _fabrica(_ok_json)
    capas = diag.diagnosticar(entorno, fabrica=fab)
    assert _estados(capas) == [diag.OK] * 8
    assert "gpt-4o" in capas[6].detalle
    post = [r for r in fab.vistas if r.method == "POST"][0]
    assert "/openai/deployments/DEP01/chat/completions" in str(post.url)
    assert post.headers["api-key"] == CLAVE
    diag.imprimir(capas)
    assert CLAVE not in capsys.readouterr().out


def test_clave_rechazada_es_capa_5(entorno):
    capas = diag.diagnosticar(entorno, fabrica=_fabrica(
        lambda r: httpx.Response(401, json={"error": {"code": "401", "message": "Access denied"}})))
    assert capas[5].estado == diag.FAIL
    assert capas[6].estado == capas[7].estado == diag.PEND


def test_deployment_inexistente_es_capa_6(entorno):
    capas = diag.diagnosticar(entorno, fabrica=_fabrica(
        lambda r: httpx.Response(404, json={"error": {"code": "DeploymentNotFound", "message": "x"}})))
    assert _estados(capas)[5:] == [diag.OK, diag.FAIL, diag.PEND]
    assert "DeploymentNotFound" in capas[6].detalle


def test_respuesta_no_json_es_capa_7(entorno):
    capas = diag.diagnosticar(entorno, fabrica=_fabrica(lambda r: httpx.Response(
        200, json={"model": "gpt-4o", "choices": [{"message": {"content": "hola"}}]})))
    assert _estados(capas)[6:] == [diag.OK, diag.FAIL]


def test_certificado_corporativo_es_capa_4_y_no_desactiva_tls(entorno):
    def fabrica(ctx):
        def manejar(req):
            raise httpx.ConnectError("[SSL: CERTIFICATE_VERIFY_FAILED] self-signed certificate in chain")
        return httpx.Client(transport=httpx.MockTransport(manejar))
    capas = diag.diagnosticar(entorno, fabrica=fabrica)
    assert capas[4].estado == diag.FAIL and "CERTIFICATE_VERIFY_FAILED" in capas[4].detalle
    assert all(k.estado == diag.PEND for k in capas[5:])
    assert not any("TLS_INSECURE=1" in a for a in capas[4].acciones)


def test_tls_insecure_falla_sin_probar(entorno, monkeypatch):
    monkeypatch.setattr("config.parametros.TLS_INSECURE", True)
    capas = diag.diagnosticar(entorno, fabrica=_fabrica(_ok_json))
    assert capas[1].estado == diag.FAIL and capas[4].estado == diag.FAIL


def test_secreto_en_el_env_es_capa_1_y_no_se_llama(entorno):
    entorno.write_text(entorno.read_text() + "AZURE_OPENAI_API_KEY=algo\nAZURE_OPENAI_VERIFY_SSL=false\n",
                       encoding="utf-8")
    fab = _fabrica(_ok_json)
    capas = diag.diagnosticar(entorno, fabrica=fab)
    assert capas[1].estado == diag.FAIL
    assert "AZURE_OPENAI_API_KEY" in capas[1].detalle and "algo" not in capas[1].detalle
    assert "AZURE_OPENAI_VERIFY_SSL" in capas[1].detalle
    assert not any(r.method == "POST" for r in fab.vistas)


def test_sin_clave_es_capa_5(entorno, monkeypatch):
    monkeypatch.delenv("AZURE_OPENAI_API_KEY")
    capas = diag.diagnosticar(entorno, fabrica=_fabrica(_ok_json))
    assert capas[5].estado == diag.FAIL
    assert any("Read-Host" in a for a in capas[5].acciones)


def test_endpoint_ajeno_es_capa_2(entorno, monkeypatch):
    monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "http://otro.example.com/")
    capas = diag.diagnosticar(entorno, fabrica=_fabrica(_ok_json))
    assert capas[2].estado == diag.FAIL
    assert all(k.estado == diag.PEND for k in capas[3:])


def test_sin_llamada_no_toca_el_modelo(entorno):
    fab = _fabrica(_ok_json)
    capas = diag.diagnosticar(entorno, sin_llamada=True, fabrica=fab)
    assert not any(r.method == "POST" for r in fab.vistas)
    assert capas[4].estado == diag.OK


def test_almacen_del_sistema_usa_truststore(monkeypatch):
    truststore = pytest.importorskip("truststore")
    monkeypatch.setattr("config.parametros.CA_BUNDLE", "")
    monkeypatch.setattr("config.parametros.TLS_INSECURE", False)
    monkeypatch.setattr("config.parametros.TLS_ALMACEN_SISTEMA", True)
    cli = red.cliente_http()
    assert cli is not None
    assert isinstance(red.contexto_almacen_sistema(), truststore.SSLContext)
    cli.close()
