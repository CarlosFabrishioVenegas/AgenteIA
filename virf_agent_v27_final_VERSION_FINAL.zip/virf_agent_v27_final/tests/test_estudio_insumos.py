"""
Estudio de insumos (manuales, Excels de primera línea, scripts) para la
Validación completa: lectura ÍNTEGRA por partes, .zip, caché por huella, modo
determinista y con IA (cliente falso, coste cero).
"""
from __future__ import annotations

import io
import json
import zipfile

import openpyxl
import pytest

from modulos import estudio_insumos as E

SCRIPT = '''import pandas as pd
cartera = pd.read_csv(r"D:\\datos\\cartera_202610.csv", sep=";")
saldos = pd.read_parquet("//srv/riesgo/saldos.parquet")
def calcular_pd(df):
    return df
q = "SELECT * FROM dwh.clientes c JOIN dwh.saldos s ON c.id = s.id"
'''


class ClienteEstudio:
    def __init__(self):
        self.llamadas: list[str] = []

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                        formato_json=False, **_):
        self.llamadas.append(prompt)
        n = len(self.llamadas)
        return json.dumps({"tipo": "manual", "resumen": f"Parte {n}.",
                           "pasos": [f"Paso de la parte {n}"], "umbrales": ["PSI < 0.25"],
                           "etapas": ["02", "04"]})


@pytest.fixture
def inputs(tmp_path):
    d = tmp_path / "inputs"
    (d / "implementacion").mkdir(parents=True)
    (d / "implementacion" / "modelo.py").write_text(SCRIPT, encoding="utf-8")
    (d / "documentacion" / "modelamiento").mkdir(parents=True)
    manual = "\n".join(f"{i}. Sección {i}\nTexto de la sección {i}. " + "x" * 400
                       for i in range(1, 200))
    (d / "documentacion" / "modelamiento" / "manual.md").write_text(
        manual + "\nEl umbral del PSI es 0.25 para alerta.", encoding="utf-8")
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Controles"
    ws.append(["Control", "Resultado", "Monto"])
    ws.append(["Nulos", "OK", 10])
    ws.append(["Duplicados", "No cumple", 20])
    ws.append(["Rangos", "OK", 30])
    (d / "excel_procesos").mkdir()
    wb.save(d / "excel_procesos" / "controles_1L.xlsx")
    return d


def test_ficha_determinista_de_script_manual_y_excel(inputs):
    fichas = {f["nombre"]: f for f in E.estudiar(inputs, usar_ia=False)}
    s = fichas["implementacion/modelo.py"]
    assert s["tipo"] == "script"
    assert "D:\\datos\\cartera_202610.csv" in s["bases_y_rutas"]
    assert "//srv/riesgo/saldos.parquet" in s["bases_y_rutas"]
    assert "dwh.clientes" in s["bases_y_rutas"] and "función calcular_pd" in s["pasos"]
    m = fichas["documentacion/modelamiento/manual.md"]
    assert m["tipo"] == "manual" and len(m["pasos"]) >= 40
    assert any("0.25" in u for u in m["umbrales"])            # leído hasta el final
    x = fichas["excel_procesos/controles_1L.xlsx"]
    assert x["tipo"] == "excel_primera_linea"
    assert any("no conformes" in a for a in x["puntos_de_atencion"])
    assert "D:\\datos\\cartera_202610.csv" in E.rutas_encontradas(list(fichas.values()))


def test_ia_lee_el_manual_entero_por_partes_y_cachea(inputs, monkeypatch):
    monkeypatch.setattr(E, "TAM_PARTE", 20000)
    cli = ClienteEstudio()
    fichas = E.estudiar(inputs, usar_ia=True, cliente=cli)
    manual = next(f for f in fichas if f["nombre"].endswith("manual.md"))
    assert manual["modo"] == "ia" and manual["partes"] >= 4
    # La última parte contiene el final del manual (lectura íntegra).
    assert any("El umbral del PSI es 0.25" in p for p in cli.llamadas)
    assert manual["etapas"] == ["02", "04"] and manual["umbrales"] == ["PSI < 0.25"]
    n = len(cli.llamadas)
    E.estudiar(inputs, usar_ia=True, cliente=cli)              # caché: sin llamadas nuevas
    assert len(cli.llamadas) == n
    # Si el archivo cambia, se vuelve a estudiar solo ese.
    (inputs / "implementacion" / "modelo.py").write_text(SCRIPT + "\n# v2\n", encoding="utf-8")
    E.estudiar(inputs, usar_ia=True, cliente=cli)
    assert len(cli.llamadas) == n + 1
    estado = E.fichas_en_cache(inputs)
    assert all(x["estudiado"] for x in estado)


def test_zip_enviado_al_chat_se_estudia_por_miembro(inputs):
    d = inputs / "validacion_completa" / "02_Modelamiento" / "ITER0"
    d.mkdir(parents=True)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("scripts/etl.sql", "SELECT * FROM dwh.cartera WHERE fecha >= '2026-01-01'")
        zf.writestr("scripts/modelo.py", SCRIPT)
        zf.writestr("img/logo.png", b"x")                     # no estudiable
    (d / "codigo.zip").write_bytes(buf.getvalue())
    fichas = {f["nombre"]: f for f in E.estudiar(inputs, usar_ia=False)}
    assert "codigo.zip/scripts/etl.sql" in fichas
    assert fichas["codigo.zip/scripts/etl.sql"]["origen"] == "chat 02 · ITER0"
    assert "dwh.cartera" in fichas["codigo.zip/scripts/etl.sql"]["bases_y_rutas"]
    assert not any("logo.png" in n for n in fichas)


def test_texto_para_prompt_prioriza_la_etapa_y_respeta_el_tope(inputs):
    cli = ClienteEstudio()
    fichas = E.estudiar(inputs, usar_ia=True, cliente=cli)
    t = E.texto_para_prompt(fichas, "02", 100000)
    assert t.index("manual.md") < t.index("controles_1L.xlsx")
    assert len(E.texto_para_prompt(fichas, "02", 1500)) <= 1600


def test_fallo_de_ia_deja_ficha_determinista(inputs):
    class Roto:
        def generar_mensaje(self, **_):
            raise RuntimeError("sin cuota")
    fichas = E.estudiar(inputs, usar_ia=True, cliente=Roto())
    s = next(f for f in fichas if f["nombre"].endswith("modelo.py"))
    assert s["modo"] == "determinista"
    assert "sin cuota" in s["puntos_de_atencion"][0]


def test_carpeta_comun_categoria_explicita_y_borrado(inputs):
    g = E.subir(inputs, "excel_primera_linea", [("Resultados 1L.xlsx", (inputs / "excel_procesos" / "controles_1L.xlsx").read_bytes()),
                                                ("guia.md", b"# Guia\n1. Paso uno")])
    assert g == ["excel_primera_linea/Resultados 1L.xlsx", "excel_primera_linea/guia.md"]
    estado = {x["nombre"]: x for x in E.fichas_en_cache(inputs)}
    assert estado["excel_primera_linea/guia.md"]["origen"] == "insumos comunes"
    fichas = {f["nombre"]: f for f in E.estudiar(inputs, usar_ia=False)}
    # La categoría la elige el validador: manda sobre la extensión.
    assert fichas["excel_primera_linea/guia.md"]["tipo"] == "excel_primera_linea"
    with pytest.raises(ValueError, match="categoría"):
        E.subir(inputs, "cualquiera", [("a.md", b"x")])
    with pytest.raises(ValueError, match="formato"):
        E.subir(inputs, "manual", [("a.exe", b"x")])
    with pytest.raises(ValueError, match="carpeta común"):
        E.borrar(inputs, "../../excel_procesos/controles_1L.xlsx")
    assert E.borrar(inputs, "excel_primera_linea/guia.md")
    assert "excel_primera_linea/guia.md" not in {x["nombre"] for x in E.fichas_en_cache(inputs)}
