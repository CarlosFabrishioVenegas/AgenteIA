"""
Paso 09 · Revisión con el agente (antes de Documentar). Coste cero (mock).

Tras sustentar las observaciones, el agente muestra cómo quedará cada una en el
informe con avisos de comprensión; el validador da su conformidad o pide
reescribir. La guía cuenta el paso como obligatorio antes de Documentar.
"""
from __future__ import annotations

import pytest

from web.services import chat_service as C


@pytest.fixture
def ctx(tmp_path, monkeypatch):
    monkeypatch.setenv("VIRF_MOCK_CHAT", "1")
    base = tmp_path / "s"
    (base / "inputs").mkdir(parents=True)
    (base / "outputs").mkdir()
    C.clear_todo()
    return {"validador": {"codigo": "T1", "nombre": "T"},
            "modelo": {"slug": "M", "nombre": "M", "tier": "II", "dominio": "LaR"},
            "base": base, "inputs": base / "inputs", "outputs": base / "outputs", "clave": "T1/M"}


def _sesion(ctx, textos):
    obs = [C.Observacion(id=f"o{i}", ambito="Datos", actividad=f"Act {i}", puntaje=2.0,
                         observacion=t, veredicto="NEGADO") for i, t in enumerate(textos, 1)]
    s = C.SesionChat(id="x", clave=ctx["clave"], modelo="M", tier="II", dominio="LaR",
                     ruta_json="r.json", observaciones=obs)
    with C._lock:
        C._sesiones[ctx["clave"]] = s
    C._emitir_pregunta(ctx, s)          # sin observaciones por tratar → resumen de revisión
    return s


def test_avisos_de_comprension():
    assert any("breve" in a for a in C.avisos_comprension("No cumple."))
    assert any("restos técnicos" in a for a in C.avisos_comprension(
        "La observación tiene {_raw: None} dentro del texto y no debería verse así en el informe."))
    assert any("cortada" in a for a in C.avisos_comprension("x" * 120))
    largo_ok = ("Se revisó la población de desarrollo del modelo y se encontró que 980 registros "
                "de SALDOS no concilian con contabilidad, lo que sesga la calibración.")
    assert C.avisos_comprension(largo_ok) == []


def test_resumen_y_conformidad(ctx):
    s = _sesion(ctx, ["No cumple.", "Se revisó la población de desarrollo y se encontró que 980 "
                                    "registros de SALDOS no concilian con contabilidad, lo que sesga la calibración."])
    ultimo = s.mensajes[-1].texto
    assert "Revisión antes de documentar" in ultimo and "1. **Datos — Act 1**" in ultimo
    assert "⚠️ muy breve" in ultimo
    assert C.estado_revision(ctx)["conforme_utc"] == ""
    C.responder(ctx, "Conforme.")
    assert C.estado_revision(ctx)["conforme_utc"]
    assert "Documentar" in s.mensajes[-1].texto
    # Persistido en disco y recuperado.
    C.clear_todo()
    assert C.sesion_activa(ctx).conforme_utc


def test_reescribir_reabre_la_conformidad(ctx):
    s = _sesion(ctx, ["No cumple.", "Otro texto suficientemente largo para no ser breve, con su explicación completa."])
    C.responder(ctx, "conforme")
    C.responder(ctx, "reescribe 1: Se revisó X y se encontró Y, lo que afecta a Z en la calibración del modelo.")
    assert s.observaciones[0].hallazgo_final.startswith("Se revisó X")
    assert s.conforme_utc == ""                       # hay que volver a confirmar
    C.responder(ctx, "reescribe 2")                   # propuesta del agente (mock: limpieza)
    assert s.observaciones[1].hallazgo_final.endswith(".")
    C.responder(ctx, "reescribe 9: nada")
    assert "No existe la observación 9" in s.mensajes[-1].texto
    C.responder(ctx, "¿esto se puede mejorar?")
    assert s.notas_revision and "conforme" in s.mensajes[-1].texto


def test_guia_cuenta_el_paso_09(ctx):
    from web.routers.guia import _paso_revision
    assert _paso_revision(ctx, False)["estado"] == "pendiente"
    _sesion(ctx, ["Texto de observación lo bastante largo para el informe y con su punto final."])
    assert _paso_revision(ctx, True)["estado"] == "en_curso"
    C.responder(ctx, "conforme")
    p = _paso_revision(ctx, True)
    assert p["estado"] == "hecho" and p["id"] == "chat"
