"""
Validación completa: 5 chats (00–04). Cada iteración entrega un notebook
{etapa}ITERn.ipynb que, ejecutado, genera {etapa}_resultadoITERn.xlsx.

Coste cero: modo plantilla y un cliente IA falso. Uno de los tests EJECUTA el
notebook generado sobre datos sintéticos para comprobar que produce el Excel.
"""
from __future__ import annotations

import io
import json
from pathlib import Path

import openpyxl
import pandas as pd
import pytest

from modulos import validacion_completa as VC

def _png() -> bytes:
    from PIL import Image
    b = io.BytesIO()
    Image.new("RGB", (40, 30), "red").save(b, "PNG")
    return b.getvalue()


PNG = _png()


def _excel_resultado() -> bytes:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Mapeo"
    ws.append(["Base", "Descripción", "Registros", "Monto", "Resultado"])
    ws.append(["CLIENTES", "Maestro de clientes", 1200, 5000.5, "OK"])
    ws.append(["SALDOS", "Saldos mensuales", 980, 7300.0, "No cumple"])
    ws.append(["MOVIMIENTOS", "Movimientos diarios", 15000, 120.25, "OK"])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _ejecutar_notebook(nb_path: Path, cwd: Path) -> None:
    """Ejecuta las celdas de código del .ipynb en un mismo espacio de nombres."""
    nb = json.loads(nb_path.read_text(encoding="utf-8"))
    ns: dict = {}
    import os
    previo = os.getcwd()
    os.chdir(cwd)
    try:
        for c in nb["cells"]:
            if c["cell_type"] == "code":
                exec(compile("".join(c["source"]), "celda", "exec"), ns)   # noqa: S102
    finally:
        os.chdir(previo)


class ClienteFalso:
    def __init__(self, cuaderno=None, veredicto="otra_iteracion", malo_primero=False):
        self.prompts: list[str] = []
        self.estudios: list[str] = []
        self.cuaderno = cuaderno or [
            {"tipo": "markdown", "contenido": "## Población"},
            {"tipo": "code", "contenido": "df = leer('clientes')\nregistrar('Replica', [{'paso': 'n', 'replicado': len(df)}])"},
        ]
        self.veredicto = veredicto
        self.malo_primero = malo_primero

    def generar_mensaje(self, prompt, instruccion_sistema="", max_tokens=None,
                        formato_json=False, **_):
        if "ESTUDIAS un" in instruccion_sistema:          # estudio de un insumo
            self.estudios.append(prompt)
            return json.dumps({"tipo": "manual", "resumen": "Ficha IA.",
                               "pasos": ["Excluir saldos negativos (§2)"], "etapas": ["02"]})
        self.prompts.append(prompt)
        cuaderno = self.cuaderno
        if self.malo_primero and len(self.prompts) == 1:
            cuaderno = [{"tipo": "code", "contenido": "def roto(:\n    pass"}]
        return json.dumps({
            "respuesta": f"Pasada {len(self.prompts)}.", "resumen": "Resumen.",
            "cambios_notebook": "Replica la población.", "cuaderno": cuaderno,
            "tabla": [{"paso": "Población", "replicado": "975"}],
            "hallazgos": [{"id": "H1", "descripcion": "Conteo distinto", "evidencia": "x/Mapeo!3",
                           "severidad": "crítico", "estado": "nuevo", "accion": "Conciliar"}],
            "pendientes": ["Ruta de contabilidad"],
            "veredicto": {"estado": self.veredicto, "motivo": "m"},
        })


@pytest.fixture
def dirs(tmp_path):
    return tmp_path / "inputs", tmp_path / "outputs"


def test_parsear_rutas():
    r = VC.parsear_rutas("clientes = D:\\datos\\cli.csv\nD:\\datos\\saldos_2026.parquet\n# nota\n"
                         "\\\\srv\\riesgo\\mov.xlsx")
    assert r == {"clientes": "D:\\datos\\cli.csv", "saldos_2026": "D:\\datos\\saldos_2026.parquet",
                 "mov": "\\\\srv\\riesgo\\mov.xlsx"}


def test_plantilla_iter0_es_notebook_ejecutable_que_genera_el_excel(dirs, tmp_path):
    inputs, outputs = dirs
    datos = tmp_path / "datos"
    datos.mkdir()
    pd.DataFrame({"id": [1, 2, 2, 3], "saldo": [10.0, None, 5.0, -1.0]}).to_csv(
        datos / "saldos.csv", index=False)
    r = VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="01", archivos=[],
                              comentario="", usar_ia=False,
                              rutas_texto=f"saldos = {datos / 'saldos.csv'}")
    it = r["iteracion"]
    assert it["ipynb"] == "01_ControlDatosITER0.ipynb"
    assert it["resultado_esperado"] == "01_ControlDatos_resultadoITER0.xlsx"
    nb_path = VC.dir_salida(outputs, "01") / it["ipynb"]
    nb = json.loads(nb_path.read_text(encoding="utf-8"))
    assert nb["nbformat"] == 4 and nb["metadata"]["virf"]["iteracion"] == 0
    _ejecutar_notebook(nb_path, tmp_path)
    xlsx = tmp_path / "01_ControlDatos_resultadoITER0.xlsx"
    assert xlsx.is_file()
    hojas = openpyxl.load_workbook(xlsx).sheetnames
    assert {"Indice", "Mapeo", "perfil_saldos", "Controles"} <= set(hojas)


def test_iteraciones_encadenadas_imagenes_y_rutas_reutilizadas(dirs):
    inputs, outputs = dirs
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[],
                          comentario="", usar_ia=False, rutas_texto="clientes = C:/d/cli.csv")
    r = VC.ejecutar_iteracion(
        inputs=inputs, outputs=outputs, codigo="00",
        archivos=[("00_Diagnostico_resultadoITER0.xlsx", _excel_resultado()),
                  ("captura saldos.png", PNG)],
        comentario="La base SALDOS falla, ver captura", usar_ia=False)
    it = r["iteracion"]
    assert it["ipynb"] == "00_DiagnosticoITER1.ipynb"
    assert it["imagenes"] == ["captura saldos.png"]
    assert any("Mapeo!3" in h["evidencia"] for h in r["resultado"]["hallazgos"])
    h = VC.cargar_historial(outputs, "00")
    assert h["rutas"] == {"clientes": "C:/d/cli.csv"}          # reutilizadas
    # Imágenes de sustento y Excel vigente para el cuadro.
    imgs = VC.imagenes_sustento(inputs)
    assert [(i["etapa"], i["iter"], i["nombre"]) for i in imgs] == [("00", 1, "captura saldos.png")]
    assert (VC.dir_vigentes(inputs) / "00_Diagnostico.xlsx").is_file()
    md = (VC.dir_salida(outputs, "00") / "00_DiagnosticoITER1.md").read_text(encoding="utf-8")
    assert "ITER1/captura saldos.png" in md and "00_Diagnostico_resultadoITER1.xlsx" in md
    # La etapa 01 hereda las rutas del 00 en su primera iteración.
    r1 = VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="01", archivos=[],
                               comentario="empieza", usar_ia=False)
    assert VC.cargar_historial(outputs, "01")["rutas"] == {"clientes": "C:/d/cli.csv"}
    assert r1["iteracion"]["n"] == 0


def test_primera_iteracion_sin_nada_falla(dirs):
    inputs, outputs = dirs
    with pytest.raises(ValueError, match="rutas de datos"):
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00",
                              archivos=[], comentario="", usar_ia=False)


def test_formato_no_admitido(dirs):
    inputs, outputs = dirs
    with pytest.raises(ValueError, match="formato no admitido"):
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00",
                              archivos=[("virus.exe", b"MZ")], comentario="x", usar_ia=False)


def test_02_dos_pasadas_contexto_y_notebook_de_la_ia(dirs, tmp_path):
    inputs, outputs = dirs
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[],
                          comentario="", usar_ia=False, rutas_texto="clientes = cli.csv")
    man = inputs / "documentacion" / "modelamiento"
    man.mkdir(parents=True)
    (man / "manual.md").write_text("## 2. Población\nSe excluyen saldos negativos.", encoding="utf-8")
    cli = ClienteFalso()
    r = VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="02",
                              archivos=[("evid.png", PNG)],
                              comentario="Replica la población", usar_ia=True, cliente=cli)
    assert len(cli.prompts) == 2
    p = cli.prompts[0]
    assert "00_DiagnosticoITER0" in p and "Se excluyen saldos negativos" in p
    assert "Replica la población" in p and "evid.png" in p and "cli.csv" in p
    assert "SEGUNDA PASADA" in cli.prompts[1]
    # El manual se estudió con IA y su ficha entra en el contexto del notebook.
    assert len(cli.estudios) == 1 and "ESTUDIO DE LOS INSUMOS" in p
    assert "Excluir saldos negativos (§2)" in p
    assert r["iteracion"]["modo"] == "ia · 2 pasadas"
    # Hallazgo crítico abierto → no puede estar «lista».
    assert r["resultado"]["veredicto"]["estado"] == "otra_iteracion"
    nb = json.loads((VC.dir_salida(outputs, "02") / "02_ModelamientoITER0.ipynb")
                    .read_text(encoding="utf-8"))
    fuentes = ["".join(c["source"]) for c in nb["cells"]]
    assert any("registrar('Replica'" in f for f in fuentes)
    assert "ExcelWriter(SALIDA)" in fuentes[-1]
    # Ejecuta el notebook de la IA sobre datos sintéticos.
    pd.DataFrame({"a": [1, 2, 3]}).to_csv(tmp_path / "cli.csv", index=False)
    _ejecutar_notebook(VC.dir_salida(outputs, "02") / "02_ModelamientoITER0.ipynb", tmp_path)
    df = pd.read_excel(tmp_path / "02_Modelamiento_resultadoITER0.xlsx", sheet_name="Replica")
    assert df["replicado"].tolist() == [3]


def test_error_de_sintaxis_se_repara(dirs):
    inputs, outputs = dirs
    cli = ClienteFalso(malo_primero=True)
    r = VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00", archivos=[],
                              comentario="", usar_ia=True, cliente=cli,
                              rutas_texto="clientes = cli.csv")
    assert len(cli.prompts) == 2 and "errores de sintaxis" in cli.prompts[1]
    assert not VC._errores_sintaxis(r["resultado"]["cuaderno"])


def test_cierre_de_etapas_y_lista_para_validar(dirs):
    inputs, outputs = dirs
    with pytest.raises(ValueError):
        VC.cerrar_etapa(outputs, "00", "T1")
    for c in VC.ETAPAS:
        VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo=c, archivos=[],
                              comentario="x", usar_ia=False, rutas_texto="a = a.csv")
        VC.cerrar_etapa(outputs, c, "T1", "ok")
    res = VC.resumen_etapas(outputs)
    assert res["cerradas"] == 5 and res["lista_para_validar"]
    # Una iteración nueva reabre la etapa.
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="03", archivos=[],
                          comentario="otra", usar_ia=False)
    assert not VC.resumen_etapas(outputs)["lista_para_validar"]


def test_anexo_del_informe_con_imagenes(dirs):
    from docx import Document
    from web.services import informe_web
    inputs, outputs = dirs
    VC.ejecutar_iteracion(inputs=inputs, outputs=outputs, codigo="00",
                          archivos=[("c.png", PNG)], comentario="x", usar_ia=False,
                          rutas_texto="a = a.csv")
    doc = Document()
    informe_web._sustento_completa(doc, {"inputs": inputs, "outputs": outputs})
    assert len(doc.inline_shapes) == 1
    assert any("00_DiagnosticoITER0" in p.text for p in doc.paragraphs)


# ── Endpoints ────────────────────────────────────────────────────────────────

def test_endpoints(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services import contexto_sesion as CS, modelos_store, sesion_store

    monkeypatch.setattr(CS, "SESIONES_DIR", tmp_path / "sesiones")
    monkeypatch.setenv("VIRF_MOCK_CHAT", "1")
    val = {"codigo": "T0001", "nombre": "Test", "roles": ["validador"]}
    monkeypatch.setattr(sesion_store, "sesion_activa", lambda tok: val if tok else None)
    monkeypatch.setattr(modelos_store, "_base_validador", lambda c: tmp_path / "sesiones" / c)
    monkeypatch.setattr(modelos_store, "_base_modelo",
                        lambda c, s: tmp_path / "sesiones" / c / s)
    m = modelos_store.crear("T0001", "MCR Prueba", "shared", "II")
    assert m["modalidad"] == "normal"

    c = TestClient(app)
    c.cookies.set("virf_token", "tok")
    c.cookies.set("virf_modelo", m["slug"])
    r = c.post("/api/completa/etapa/00/iteracion", data={"rutas": "a = a.csv"})
    assert r.status_code == 409                          # validación normal
    assert c.post("/api/completa/modalidad", json={"modalidad": "completa"}).status_code == 200
    r = c.post("/api/completa/etapa/00/iteracion",
               data={"comentario": "hola", "usar_ia": "true", "rutas": "a = a.csv"},
               files=[("archivos", ("cap.png", PNG, "image/png"))])
    assert r.status_code == 200, r.text
    d = r.json()
    assert d["iteracion"]["ipynb"] == "00_DiagnosticoITER0.ipynb"
    assert d["rutas"] == {"a": "a.csv"}
    r = c.get("/api/completa/etapa/00/descargar/00_DiagnosticoITER0.ipynb")
    assert r.status_code == 200 and json.loads(r.content)["nbformat"] == 4
    assert c.get("/api/completa/etapa/00/imagen/0/cap.png").status_code == 200
    assert c.get("/api/completa/etapa/00/imagen/0/..%2F..%2Fx.png").status_code in (400, 404)
    assert c.get("/api/completa/etapa/00/descargar/historial.json").status_code == 400
    r = c.post("/api/completa/etapa/00/cerrar", json={"motivo": "ok"})
    assert r.status_code == 200 and r.json()["cierre"]["iter"] == 0
    est = c.get("/api/completa/estado").json()
    assert est["modalidad"] == "completa" and est["cerradas"] == 1 and est["total"] == 5
    assert c.get("/api/completa/etapa/09").status_code == 404
    # Insumos comunes: subir, listar y borrar.
    r = c.post("/api/completa/insumos/subir", data={"categoria": "manual"},
               files=[("archivos", ("manual.md", b"# Manual\n1. Poblacion", "text/markdown"))])
    assert r.status_code == 200, r.text
    assert any(x["nombre"] == "manual/manual.md" for x in r.json()["insumos"])
    r = c.post("/api/completa/insumos/estudiar", json={"usar_ia": False})
    assert r.json()["estudiados"] == r.json()["total"]
    r = c.delete("/api/completa/insumos/archivo", params={"ruta": "manual/manual.md"})
    assert r.status_code == 200 and r.json()["total"] == 0
    assert c.delete("/api/completa/insumos/archivo",
                    params={"ruta": "../ITER0/cap.png"}).status_code == 400
