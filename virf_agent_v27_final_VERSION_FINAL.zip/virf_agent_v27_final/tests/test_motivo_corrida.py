"""
«Validar modelo» terminaba en «error» sin decir por qué y con una fase falsa
(«Evaluando ámbitos» por un aviso que mencionaba «ámbitos»). Salida REAL de
agente.py con una clave de Anthropic rechazada (2026-11-18).
"""
from __future__ import annotations

from web.services.pipeline_runner import _clasificar_fase, motivo_error

SALIDA_401 = """\
📂 Evidencia: C:\\tmp\\s
  ⚠️  Carpetas sin documentos: calidad_datos, papers, usos
      Los ámbitos que dependan de ellas puntuarán 0.0 (sin evidencia).
  🔑 Verificando API key...   ⚠️  ANTHROPIC_API_KEY leída del .env (texto plano en disco).
✅ Cliente IA listo: anthropic (claude-haiku-4-5-20251001) — sin verificar (VIRF_VALIDAR_CONEXION=0)
⚠️  Validación Anthropic: Error code: 401 - {'type': 'error', 'error': {'type': 'authentication_error', 'message': 'invalid x-api-key'}}
❌

❌ API key rechazada por Anthropic (Error 401).

   La clave configurada no es válida.
   Verifica en: https://console.anthropic.com/
   y actualiza ANTHROPIC_API_KEY en el archivo .env

  📦 Caché de documentos: no utilizado esta sesión.
""".splitlines()


def test_fase_no_se_engana_con_la_palabra_ambito():
    fases = []
    for l in SALIDA_401:
        f = _clasificar_fase(l)
        if f and (not fases or fases[-1] != f):
            fases.append(f)
    assert "Evaluando ámbitos" not in fases
    assert fases[-1] == "Verificando IA"
    assert _clasificar_fase("🔍 Evaluando Documentación (3 actividades)...") == "Evaluando ámbitos"


def test_motivo_y_pista_de_clave_rechazada():
    motivo, pista = motivo_error(SALIDA_401)
    assert motivo.startswith("❌ API key rechazada por Anthropic (Error 401).")
    assert "ANTHROPIC_API_KEY" in motivo and "Caché" not in motivo
    assert "clave del proveedor de IA no es válida" in pista


def test_motivo_de_corrida_sin_actividades_evaluadas():
    lineas = ["🔍 Evaluando Documentación (3 actividades)...",
              "❌ Error en llamada API: timeout",
              "  ❌ La corrida NO evaluó ninguna actividad (fallo técnico). Código de salida 1.", ""]
    motivo, pista = motivo_error(lineas)
    assert "NO evaluó ninguna actividad" in motivo
    assert pista                       # timeout → conexión, o el genérico de «ninguna actividad»


def test_motivo_de_traceback_sin_marca():
    motivo, pista = motivo_error(["Traceback (most recent call last):", '  File "x.py"',
                                  "KeyError: 'ambito'"])
    assert motivo == "KeyError: 'ambito'"


def test_modelo_sin_evidencia_no_es_fallo_tecnico():
    """Caso real del 2026-11-18: GPT conecta, el modelo no tiene evidencia."""
    lineas = ["  📖 Cargando Estandares_VIRF.xlsx...",
              "  ✗ [Documentación] SIN DOCUMENTOS — evaluación rechazada.",
              "  ⚠️  Control_01: Pre-flight falló - No hay archivos legibles en C:\s\inputs",
              "  ❌ La corrida NO evaluó ninguna actividad: el modelo no tiene evidencia "
              "(sin documentos en ningún ámbito). Sube los manuales, el código y los datos en "
              "03 · Evidencia y vuelve a lanzar. Código de salida 1.", ""]
    motivo, pista = motivo_error(lineas)
    assert "no tiene evidencia" in motivo
    assert "03 · Evidencia" in pista and "estándar" not in pista


def test_lanzar_sin_evidencia_se_rechaza(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services import contexto_sesion as CS, modelos_store, sesion_store
    monkeypatch.setattr(CS, "SESIONES_DIR", tmp_path / "s")
    monkeypatch.setattr(sesion_store, "sesion_activa",
                        lambda tok: {"codigo": "T9", "roles": ["validador"]} if tok else None)
    monkeypatch.setattr(modelos_store, "_base_validador", lambda c: tmp_path / "s" / c)
    monkeypatch.setattr(modelos_store, "_base_modelo", lambda c, s: tmp_path / "s" / c / s)
    m = modelos_store.crear("T9", "Sin Evidencia", "LaR", "II")
    c = TestClient(app)
    c.cookies.set("virf_token", "tok")
    c.cookies.set("virf_modelo", m["slug"])
    r = c.post("/api/validar/lanzar", json={})
    assert r.status_code == 409 and "no tiene evidencia" in r.text
