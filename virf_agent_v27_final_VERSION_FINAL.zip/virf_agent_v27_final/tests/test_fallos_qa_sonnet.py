"""
Regresiones de los fallos que encontró el QA con Sonnet (pruebas/kit_qa_sonnet):

F1  /api/cuestionamientos/* escribía config global sin sesión ni rol.
F2  No se podían subir papers a un dominio RAG personalizado (destino desconocido).
F3  /api/inputs/upload aceptaba extensiones que la tarjeta no declara (.exe).
F4  El notebook 01 sin IA no detectaba llaves duplicadas ni huérfanos entre bases.
"""
from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import pytest
from fastapi import HTTPException


# ── F1 ──────────────────────────────────────────────────────────────────────

def test_cuestionamientos_exigen_sesion():
    from fastapi.testclient import TestClient
    from web.app import app
    c = TestClient(app)
    assert c.get("/api/cuestionamientos/default").status_code == 401
    assert c.post("/api/cuestionamientos/default/x/toggle", json={"activo": True}).status_code == 401
    assert c.get("/api/cuestionamientos/personalizados").status_code == 401
    assert c.delete("/api/cuestionamientos/personalizados/x").status_code == 401


def test_cuestionamientos_escritura_requiere_rol_validar(monkeypatch):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services import sesion_store
    monkeypatch.setattr(sesion_store, "sesion_activa",
                        lambda tok: {"codigo": "R1", "roles": ["revisor"]} if tok else None)
    c = TestClient(app)
    c.cookies.set("virf_token", "tok")
    assert c.get("/api/cuestionamientos/default").status_code == 200          # leer: sí
    r = c.post("/api/cuestionamientos/default/x/toggle", json={"activo": True})
    assert r.status_code == 403                                                # escribir: no


# ── F2 / F3 ─────────────────────────────────────────────────────────────────

def test_destino_rag_de_dominio_personalizado(monkeypatch, tmp_path):
    from web.services import contexto_sesion as CS, dominios_custom_store as D
    monkeypatch.setattr(D, "_leer", lambda: {"capital_eco": {"nombre": "Capital"}})
    monkeypatch.setattr(CS, "RAG_GLOBAL", tmp_path / "rag")
    assert CS.resolver_destino("rag_capital_eco", {}) == tmp_path / "rag" / "capital_eco"
    assert CS.formatos_destino("rag_capital_eco") == (".pdf", ".md", ".txt")
    with pytest.raises(HTTPException):
        CS.resolver_destino("rag_no_existe", {})
    with pytest.raises(HTTPException):
        CS.resolver_destino("rag_../../x", {})


def test_formatos_de_tarjeta():
    from web.services.contexto_sesion import formatos_destino
    assert ".exe" not in formatos_destino("doc_modelamiento")
    assert ".pdf" in formatos_destino("doc_modelamiento")
    assert formatos_destino("destino_inexistente") == ()


def test_upload_rechaza_extension_no_declarada(monkeypatch, tmp_path):
    from fastapi.testclient import TestClient
    from web.app import app
    from web.services import contexto_sesion as CS, modelos_store, sesion_store
    monkeypatch.setattr(CS, "SESIONES_DIR", tmp_path / "s")
    monkeypatch.setattr(sesion_store, "sesion_activa",
                        lambda tok: {"codigo": "T9", "roles": ["validador"]} if tok else None)
    monkeypatch.setattr(modelos_store, "_base_validador", lambda c: tmp_path / "s" / c)
    monkeypatch.setattr(modelos_store, "_base_modelo", lambda c, s: tmp_path / "s" / c / s)
    m = modelos_store.crear("T9", "M QA", "shared", "II")
    c = TestClient(app)
    c.cookies.set("virf_token", "tok")
    c.cookies.set("virf_modelo", m["slug"])
    r = c.post("/api/inputs/upload", params={"destino": "doc_modelamiento", "clasificacion": "Interno"},
               files=[("archivos", ("malo.exe", b"MZ", "application/octet-stream"))])
    assert r.status_code == 400 and "formato no admitido" in r.text
    r = c.post("/api/inputs/upload", params={"destino": "doc_modelamiento", "clasificacion": "Interno"},
               files=[("archivos", ("manual.md", b"# ok", "text/markdown"))])
    assert r.status_code == 200, r.text


# ── F4 ──────────────────────────────────────────────────────────────────────

def test_notebook_01_detecta_llave_duplicada_y_huerfanos(tmp_path):
    from modulos import validacion_completa as VC
    datos = tmp_path / "datos"
    datos.mkdir()
    pd.DataFrame({"id_cliente": [1, 2, 2, 3], "nombre": list("abcd")}).to_csv(datos / "clientes.csv", index=False)
    pd.DataFrame({"id_cliente": [1, 2, 9], "saldo": [10, 20, 30]}).to_csv(datos / "saldos.csv", index=False)
    r = VC.ejecutar_iteracion(
        inputs=tmp_path / "in", outputs=tmp_path / "out", codigo="01", archivos=[],
        comentario="", usar_ia=False,
        rutas_texto=f"clientes = {datos / 'clientes.csv'}\nsaldos = {datos / 'saldos.csv'}")
    nb = json.loads((VC.dir_salida(tmp_path / "out", "01") / r["iteracion"]["ipynb"]).read_text(encoding="utf-8"))
    ns: dict = {}
    import os
    prev = os.getcwd()
    os.chdir(tmp_path)
    try:
        for cel in nb["cells"]:
            if cel["cell_type"] == "code":
                exec(compile("".join(cel["source"]), "celda", "exec"), ns)       # noqa: S102
    finally:
        os.chdir(prev)
    ctl = pd.read_excel(tmp_path / "01_ControlDatos_resultadoITER0.xlsx", sheet_name="Controles")
    dup = ctl[(ctl.control == "llave duplicada") & (ctl.elemento == "clientes.id_cliente")]
    assert int(dup.afectados.iloc[0]) == 1
    huerf = ctl[(ctl.control.str.startswith("integridad")) & (ctl.elemento.str.startswith("saldos."))]
    assert int(huerf.afectados.iloc[0]) == 1                                    # id 9 sin cliente
