# Graph Report - virf_agent_v27_final (1)  (2026-11-18)

## Corpus Check
- 422 files · ~805,130 words
- Verdict: corpus is large enough that graph structure adds value.
- Unclassified: 41 file(s) not represented in the graph (top: .csv 9, .ipynb 7, (none) 5)

## Summary
- 8089 nodes · 18113 edges · 399 communities (225 shown, 174 thin omitted)
- Extraction: 96% EXTRACTED · 4% INFERRED · 0% AMBIGUOUS · INFERRED: 755 edges (avg confidence: 0.87)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `b742a5eb`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- BaseSkill
- material_no_confiable
- app.py
- pipeline_calidad_datos.py
- ia.py
- typing
- Guía · Generador del PDF del agente corporativo
- Tests · RAG léxico (recuperación)
- Mx_03_LlamarIA.py
- BaseIndexer
- BuscadorLexico
- agente.py
- motor_ia.py
- estandares_service.py
- Archivado v28 · Traza de decisiones
- get_retriever
- Archivado v28 · Vector store Chroma
- plantilla_bcp.py
- qa_endpoints.py
- Controles · Excel a notebook ejecutable
- Informe Word · Primitivas del entregable
- Archivado · Parches v13 (código muerto)
- Revisión de código · Juez anclado y hallazgos
- RAG · Indexador léxico
- Archivado · Generador Word antiguo (Mx_05)
- Web · Verificar conexiones y cuestionamientos
- Web · Gestión de modelos (store y rutas)
- Archivado v28 · Herramientas SQL y pandas
- Mx_01_LecturaEvidencias.py
- Seguridad · Cortacircuitos (fusibles)
- analisis_codigo.py
- rag.py
- Informes · Reglas de calificación y cumplimiento
- ClienteIA
- Automatizaciones · Cuadro de observaciones
- Prevuelo · Chequeo previo de evidencia
- Web · Catálogo de skills
- configurar_consola
- DocumentCache
- comparar
- test_versionado.py
- Tests · Simulación de Azure (pipeline)
- Archivado v28 · Compresión de contexto
- sys
- ClienteAzureOpenAIIA
- VIRF PLUS · Consenso entre dos modelos
- generar_presentacion_guia.py
- routers/config.py
- preguntas_oro_rag.py
- estudio_insumos.py
- Custodia · Registro de emisiones
- chat_service.py
- Solo Informe · Estándar, borrador e imágenes
- RevisorCodigo
- test_proveedores_ia.py
- Skills · Calidad de datos
- Skills · Catálogo y clase base
- solicitar_segunda_firma
- sesion_store.py
- refrescarCard
- evaluar_abstencion
- Archivado · Config monolítica antigua
- Salvaguardas · Entailment (LLM como juez)
- Tests · RAG como pericia (no evidencia)
- Verificador VIRF · Paquete de verificación
- Tests · Estructura de la configuración
- get
- enmascarar
- pedirJSON
- Solo Informe · Router y endpoints
- Aislamiento entre clientes (tenant)
- generador_markdown.py
- Motor IA · Scores y semáforo
- Archivado · Generador Excel antiguo
- Skills tipadas · Documentación y gobierno
- Feedback · Calidad del proceso y autoría
- Esquemas de datos (contratos)
- diagnosticar
- Solo Informe · Asistencia con IA
- Tests · Presentación del Word
- Web · Pantalla Solo Informe (frontend)
- Motor · Controles sobre datos (Mx_04)
- ChunkerService
- get_cliente_ia
- TestCoherenciaManualVsImplementacion
- Abstención y calibración beta
- test_antialucinacion_brechas.py
- Citas · Validación determinista
- Tests · Controles de calidad de datos
- diagnostico_azure_virf.py
- modulos/validacion_completa.py
- validate_project.py
- feedback.py
- TestConstruirTabla
- Skills · Cola de acciones pendientes
- Tests · Análisis estático
- web/static/js/app.js
- Frontend · Guía interactiva
- Archivado v28 · Challenger con RAG
- motores_datos.py
- 20261118_antes_rediseno/static/js/app.js
- Tests · Catálogo y detección de modelos
- Análisis estático del código
- Tests · SQL y R como código del modelo
- leer_resultados
- Informe web · Generador con capturas
- Evidencia · Capturas (pantallazos)
- auth.py
- Archivado · Lector de inputs antiguo
- Fixtures · IFRS9 y VaR de demostración
- Motor IA v2 · Cálculo de score
- cuestionamientos.py
- SkillSintesis
- leer_estandares_virf
- Tests · Resultados por celda del notebook
- upload.py
- json
- Tests · Informe Word sin puntajes falsos
- modulos/__init__.py
- Informe · Contrato ValidationReport
- pipeline_runner.py
- Archivado v28 · Challenger sin RAG
- test_solo_informe.py
- Chunker estructural
- TestCitasInventadasEnSkills
- Tests · Tope por tolerancia cero
- Tests · PDF real y chunking
- TestParserEstandares
- Tests · Neutralidad de proveedor IA
- Agente · Acotar contexto de skills
- Salvaguardas · Inyección de prompts
- Firma humana · Identidad del validador
- identidad.py
- Tests · Conexión Azure y parámetros
- inferir_dominio
- ExplicadorModelo
- Tests · Automatizaciones
- revision_codigo.py
- Seguridad · Nombres de archivo seguros
- Feedback · Estadísticas
- Tests · Skills en el entregable
- Exportador Excel
- generar_word_informe
- Datos · Perfilado de datasets
- Tests · DOCX de regresión
- Multimodelo · Raíz de evidencia
- Tests · Skills tipadas
- Tests · Reintento ante cuota (429)
- test_owasp_llm.py
- Tests · Auditoría integral 2026-08-07
- pii.py
- Tests · Explicador agnóstico al modelo
- Tests · Cuestionamientos extensibles
- routers/automatizaciones.py
- cablearSoloInforme
- Tests · Subida ZIP (límites)
- columns
- test_auditoria.py
- test_gobierno_codigo.py
- material_no_confiable
- almacenamiento.py
- es_de_entorno_virtual
- Tests · Score de control ponderado
- Trazabilidad · Huella de prompts
- Archivado v28 · Lector de código
- TestAuditoriaEntornoCorporativo
- test_gobierno_ia.py
- test_ejecucion_codigo.py
- Tests · Contrato y estadísticas
- solo_informe_ia.py
- Tests · Umbral antisesgo
- Tests · Lectura íntegra de código e ipynb
- Frontend · Chat
- verificacion_cifras.py
- pedirJSON
- test_roles.py
- consolidar_decisiones
- sellar_y_escribir
- Tests · Políticas del procedimiento 2026
- AST
- sesion_activa
- AgentOrchestrator
- secretos.py
- Tests · Reintento de contrato
- Tests · Sin evidencia no es fallo
- Tests · Caché de resúmenes con bloqueo
- Tests · Lectura fallida declarada
- resultados.py
- Tests · Ninguna llamada externa
- test_costes.py
- PerfilModelo
- estandares.py
- 20261118_antes_rediseno/static/js/guia.js
- Skills · Regulatoria con RAG
- Tests · Historial de feedback
- Tests · Índice RAG sin contaminación
- Tests · Contexto se llena sin abandonar
- escapeHtml
- completa.js
- Identidad
- red.py
- generar_informe_md
- cuestionamientos_ext.py
- Acta de cierre (Excel)
- test_aprendizaje_chat.py
- Tests · Fallo de credencial Azure
- openpyxl
- test_validacion_completa.py
- Tests · OCR retirado
- Archivado v28 · Skill detección de fórmulas
- Archivado v28 · Skill metodología
- response_evaluator.py
- Tests · Anexo de correcciones
- Fixtures · Modelo sintético Fraude/AML
- Tests · Un solo parser JSON
- verificar_remoto_git.py
- ejecutar_aprobado
- Frontend · Estándares
- test_corrida_fallida.py
- Análisis estático · Contraste doc vs código
- Tests · Sin documentos no hay puntaje
- _label_semaforo
- TestAuditoriaRespuestaVaciaDeLaAPI
- Tests · Cobertura documental ponderada
- test_verificacion_citas.py
- Tests · Columna de control opcional
- Tests · Filtrado de controles
- Tests · El resumen final cuadra
- Código muerto · Buscador de evidencias
- test_calidad_e2e.py
- ClienteSimulado
- Frontend · Lanzar validación
- arrancar
- ShortTermMemory
- TestCumplimientoCadenaDeCustodia
- test_casos_borde.py
- conftest.py
- test_owasp_llm.py
- descargar_notebook_controles
- Tests · Endpoint del notebook
- invocar
- motor_ia_v2.py
- Tests · Pipeline de controles
- Tests · Ningún recorte silencioso
- reconstruir_estandar_desde_informes.py
- test_usuario_libre.py
- calcular
- EmbeddingGenerator
- test_estudio_insumos.py
- Tests · Dos métricas de cobertura
- mostrarVista
- TestAcantiladoDeCoste
- guia.py
- presupuesto
- Control VaR · Kupiec
- Control VaR · Semáforo de Basilea
- test_clasificacion_docx.py
- informe.py
- perfilar_carpeta
- TestRagLexicoSinEmbeddingsNiHuggingFace
- Control ALM · Backtesting de prepago
- Control ALM · Beta de depósitos
- Control ALM · Brecha de duración
- Control ALM · CPR de prepago
- Control ALM · Decaimiento NMD
- Control ALM · Sensibilidad NII
- Control ALM · Escenarios IRRBB
- Control ALM · Gap de reprecios
- Control ALM · Vida media NMD
- Control LaR · Brecha de liquidez
- Control LaR · Concentración de fondeo
- Control LaR · Horizonte de supervivencia
- Control LaR · Composición HQLA
- Control LaR · LCR
- Control LaR · NSFR
- Control transversal · Columnas constantes
- Control transversal · Frescura
- Control VaR · Excedencias
- Control VaR · Severidad de excepciones
- Control VaR · VaR negativos
- test_regresion.py
- TestConfigCentral
- Tests · Modelo simulado de Solo Informe
- adjuntos_ole.py
- generar_kit.py
- IdentityProvider
- BuscadorEvidencias
- verificar_cadena
- pandas
- Tests · Feedback
- abrirChat
- pathlib
- TestCadenaDeCustodiaBajoConcurrencia
- test_identidad.py
- Tests · Fallos de red
- abrirConfiguracion
- TestAuditoriaConsistenciaCruzada
- abrirConfiguracion
- desde_manuales
- qa_rag_dominio.py
- comparar_doc_y_codigo
- _extraer_json
- tempfile
- TestPuntajeNuloNoRompeNada
- os
- TestElInformeDeclaraLaVersionDelEstandar
- TestVeredictoActividad
- hooks
- refrescarCard
- _sombrear_parrafo
- escanear_secretos.py
- normalizar_tier
- test_rag_desactualizado.py
- siAccionIA
- prevuelo
- abrirEstandares
- test_plantilla_bcp.py
- crear_sesion
- TestAuditoriaSecretosYDistribucion
- ui.js
- cablearValidacion
- subprocess
- consolidator_skill.py
- TestExplicador
- _funciones_documentadas_ausentes
- TestLosDosPipelinesSeComportanIgual
- TestChatSeleccion
- verificar_corpus_rag.py
- word_estilo.py
- test_chat_adjuntar.py
- IAFallo
- detectar_cuestionamientos
- _Reporte
- sca_pip_audit.json
- .limpiar_cache_resumenes
- cita
- TestPromptChat
- entorno
- TestRuidoDePdfminer
- TestCorpusRagSeDeclaraComoResumenSecundario

## God Nodes (most connected - your core abstractions)
1. `main()` - 96 edges
2. `pedirJSON()` - 66 edges
3. `pedirJSON()` - 66 edges
4. `escapeHtml()` - 65 edges
5. `escapeHtml()` - 60 edges
6. `get_cliente_ia()` - 52 edges
7. `ChunkerService` - 50 edges
8. `IndexadorLexico` - 48 edges
9. `enmascarar()` - 46 edges
10. `BuscadorLexico` - 43 edges

## Surprising Connections (you probably didn't know these)
- `orquestar_pipeline_ambitos()` --calls--> `_rag_inferir_dominio()`  [INFERRED]
  archivo/codigo_muerto_2026-07-26/evaluacion_paralela_motor_ia.py → modulos/motor_ia.py
- `test_todo_cliente_concreto_pasa_por_el_gateway()` --uses--> `ClienteConsensoIA`  [INFERRED]
  tests/test_gateway_ia.py → config/virf_plus.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/backtesting_prepago.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/beta_deposito.py → tests/test_regresion.py
- `control()` --indirect_call--> `columns()`  [INFERRED]
  inputs/repositorio_controles/alm/brecha_duracion.py → tests/test_regresion.py

## Import Cycles
- None detected.

## Communities (399 total, 174 thin omitted)

### Community 0 - "BaseSkill"
Cohesion: 0.04
Nodes (9): ChallengerGenerationSkill, DocumentationAuditSkill, FailureAnalysisSkill, MethodologyComplianceSkill, ModelGovernanceSkill, PaperIntelligenceSkill, RegulatoryReviewSkill, RepoReconstructionSkill (+1 more)

### Community 1 - "material_no_confiable"
Cohesion: 0.04
Nodes (37): analizar_brechas(), _code(), _codigo_control(), construir_notebook_controles(), extraer_controles_del_documento(), _firma(), generar_notebook_controles(), leer_controles_excel() (+29 more)

### Community 2 - "app.py"
Cohesion: 0.08
Nodes (12): index(), _version_assets(), Aprobacion, aprobar(), crear_custom(), NuevoCustom, Toggle, toggle() (+4 more)

### Community 3 - "pipeline_calidad_datos.py"
Cohesion: 0.08
Nodes (7): _control_fechas_coherentes(), ejecutar_plan(), escribir_tabla(), main(), _veredicto(), TestPipelineCalidadDatos, _explota()

### Community 4 - "ia.py"
Cohesion: 0.07
Nodes (27): _credenciales_completas(), _en_produccion(), estado_efectivo(), metadatos_proveedor(), _motivo_clave_rechazada(), proveedor_activo(), proveedor_autorizado(), proveedores_autorizados() (+19 more)

### Community 5 - "typing"
Cohesion: 0.04
Nodes (9): ContextFilter, ContextPrioritizer, ContextRanker, CorrectionsTracker, FeedbackAnalyzer, LearningLoop, LongTermMemory, BaseSkill (+1 more)

### Community 6 - "Guía · Generador del PDF del agente corporativo"
Cohesion: 0.06
Nodes (38): a_pdf(), analizar_modulos(), archivos_codigo(), catalogo_tests(), comunidades_del_grafo(), comunidades_por_archivo(), construir(), defaults_en_codigo() (+30 more)

### Community 7 - "Tests · RAG léxico (recuperación)"
Cohesion: 0.06
Nodes (8): _buscador(), _corpus(), _indexador(), TestExpansionDeConsulta, TestIntegracionConElMotor, TestRecuperacion, TestRelevanciaAbsoluta, TestRendimiento

### Community 8 - "Mx_03_LlamarIA.py"
Cohesion: 0.07
Nodes (14): evaluar_dimension(), prompt_evaluar_dimension(), llamar_ia_json(), modelo_activo(), estilo_por_defecto(), aprender_estilo(), _crop_to_json(), generar_replica_virf() (+6 more)

### Community 9 - "BaseIndexer"
Cohesion: 0.05
Nodes (20): construir_stub(), main(), configurar_consola(), consola_soporta_unicode(), _forzar_codepage_utf8_windows(), _reconfigurar(), _construir_pdf(), generar() (+12 more)

### Community 10 - "BuscadorLexico"
Cohesion: 0.05
Nodes (20): _anclas(), auditar(), _clasificar(), main(), explicar(), main(), _regla(), evaluar_adversarias() (+12 more)

### Community 11 - "agente.py"
Cohesion: 0.05
Nodes (25): _aplicar_raiz_evidencia(), _codigo_salida_corrida(), _firmante_opcional(), _huella_corpus_rag(), main(), _modelo_ia_real(), _motivo_ambito_sin_score(), _motivo_no_evaluable() (+17 more)

### Community 12 - "motor_ia.py"
Cohesion: 0.05
Nodes (31): calibra_puntaje(), cargar_historial_aprobado(), cargar_historial_calibracion(), construir_contexto_feedback(), ajustar_puntaje_por_feedback(), analizar_patron_errores(), cargar_historial(), construir_bloque_aprendizaje() (+23 more)

### Community 13 - "estandares_service.py"
Cohesion: 0.14
Nodes (22): TestPersistencia, avisos_para_tier(), _cabeceras_ok(), carpeta(), _columnas_extra(), confirmar(), descartar_pendiente(), _escribir_meta() (+14 more)

### Community 14 - "Archivado v28 · Traza de decisiones"
Cohesion: 0.06
Nodes (3): DecisionTrace, DecisionType, ReasoningEngine

### Community 15 - "get_retriever"
Cohesion: 0.07
Nodes (17): ALMRetriever, BaseRetriever, CustomDomainRetriever, _cargar_dominios_custom(), dominios_conocidos(), get_retriever(), inferir_dominio(), _normalizar() (+9 more)

### Community 16 - "Archivado v28 · Vector store Chroma"
Cohesion: 0.06
Nodes (3): Reranker, SemanticSearcher, ChromaManager

### Community 17 - "plantilla_bcp.py"
Cohesion: 0.09
Nodes (37): _alcance(), _bloque_codigo(), _bullet(), _callout(), _cell_left_accent(), _cell_margins(), _cuadro_resumen(), _cumplimiento() (+29 more)

### Community 18 - "qa_endpoints.py"
Cohesion: 0.25
Nodes (24): chk(), Cli, _iter(), J(), main(), reg(), seguro(), w() (+16 more)

### Community 19 - "Controles · Excel a notebook ejecutable"
Cohesion: 0.10
Nodes (24): exportar_informe_word(), extraer_seccion_docstring(), extraer_variables_globales(), analizar_libro(), analizar_libro_externo_ligero(), auto_validar(), _code(), _codigo_notebook() (+16 more)

### Community 20 - "Informe Word · Primitivas del entregable"
Cohesion: 0.11
Nodes (31): _add_ambito_heading(), _add_bullet(), _add_hallazgos_codigo(), _add_heading(), _add_numbered(), _add_para(), _alcance_desde_json(), _anexo_correcciones() (+23 more)

### Community 21 - "Archivado · Parches v13 (código muerto)"
Cohesion: 0.08
Nodes (5): CalculadorScore, create_resultado_control_v13(), DocumentoChunker, ReportadorEvaluacion, ValidadorInputs

### Community 22 - "Revisión de código · Juez anclado y hallazgos"
Cohesion: 0.05
Nodes (3): _aparece(), recategorizar(), TestJuezCodigoAnclado

### Community 23 - "RAG · Indexador léxico"
Cohesion: 0.05
Nodes (9): _buscadores(), evaluar_chunker(), _ndcg(), norm(), verificar_ground_truth(), fuentes_rag(), IndexadorLexico, IndiceLexico (+1 more)

### Community 24 - "Archivado · Generador Word antiguo (Mx_05)"
Cohesion: 0.13
Nodes (18): _add_run(), _cell_write(), GeneradorWord, generar_word_informe(), _heading(), _hrule(), _make_table(), _paragraph() (+10 more)

### Community 25 - "Web · Verificar conexiones y cuestionamientos"
Cohesion: 0.11
Nodes (14): borrar_custom(), get_estado(), _leer_parametros(), _muestra_rag(), preview_prompt(), add_custom(), _ahora(), _escribir() (+6 more)

### Community 26 - "Web · Gestión de modelos (store y rutas)"
Cohesion: 0.09
Nodes (24): activar_modelo(), borrar_modelo(), crear_modelo(), desactivar(), listar_modelos(), modelo_activo(), NuevoModelo, _validador_logueado_o_401() (+16 more)

### Community 27 - "Archivado v28 · Herramientas SQL y pandas"
Cohesion: 0.07
Nodes (7): BaseTool, PandasTool, PlottingTool, RecommendationTool, RetrievalTool, SHAPTool, SQLTool

### Community 28 - "Mx_01_LecturaEvidencias.py"
Cohesion: 0.06
Nodes (29): get_cache(), compilar_textos_de_carpeta(), _decodificar_texto(), detectar_manual_y_script(), _es_evidencia(), _extraer_outputs_celda(), get_cache(), guardar_parametros_ejecucion() (+21 more)

### Community 29 - "Seguridad · Cortacircuitos (fusibles)"
Cohesion: 0.11
Nodes (11): Cortacircuitos, CortacircuitosActivado, _Reloj, test_cap_de_iteraciones_corta_al_cuarto_intento(), test_cap_por_defecto_es_tres(), test_escalar_preserva_los_hallazgos_intermedios(), test_fusible_de_tiempo_corta_pasados_los_diez_segundos(), test_fusible_de_tokens_corta_pasados_los_veinte_mil() (+3 more)

### Community 30 - "analisis_codigo.py"
Cohesion: 0.06
Nodes (33): ctx_de_prueba(), TestIntegracionCustom, TestPromptService, TestRolAgenteOverride, analizar(), Feedback, feedback(), obtener() (+25 more)

### Community 31 - "rag.py"
Cohesion: 0.09
Nodes (20): borrar_dominio(), borrar_paper(), crear_dominio(), _ejecutar_rebuild(), _leer_indice(), listar_dominios(), _modelos_que_usan(), NuevoDominio (+12 more)

### Community 32 - "Informes · Reglas de calificación y cumplimiento"
Cohesion: 0.08
Nodes (20): _adjuntos(), _barrido(), control_satisfactorio(), cumplimiento(), observaciones_por_control(), _sustento(), _tamano(), clave_ambito() (+12 more)

### Community 33 - "ClienteIA"
Cohesion: 0.07
Nodes (9): ClienteAnthropicIA, ClienteIA, _envolver_gateway(), generar_mensaje(), _origen_llamada(), ProveedorNoAutorizado, _registrar_llamada(), _uso_y_coste() (+1 more)

### Community 34 - "Automatizaciones · Cuadro de observaciones"
Cohesion: 0.11
Nodes (25): asignar_responsable(), _buscar_columna(), _celda(), construir_prompt(), _cuadro_determinista(), _es_fallo(), _evidencia_verificada(), exportar_excel() (+17 more)

### Community 35 - "Prevuelo · Chequeo previo de evidencia"
Cohesion: 0.12
Nodes (5): _clasificar_fallo(), ejecutar_prevuelo(), formatear(), InformePrevuelo, TestPrevueloDeEvidencia

### Community 36 - "Web · Catálogo de skills"
Cohesion: 0.10
Nodes (16): borrar_custom(), crear_custom(), get_skills(), listar_defaults(), NuevoCustom, toggle(), ToggleDefault, add_custom() (+8 more)

### Community 38 - "DocumentCache"
Cohesion: 0.05
Nodes (14): DocumentCache, _escribir_cache_cifrada(), inicializar_cache(), _leer_cache_cifrada(), _cache_cifrada_con_una_entrada(), test_cache_cifrada_en_disco_e_ilegible_sin_clave(), test_cache_de_otra_clave_o_sin_clave_no_tumba_el_arranque(), test_limpiar_cache_cifrada_funciona_sin_clave() (+6 more)

### Community 39 - "comparar"
Cohesion: 0.09
Nodes (9): CambioActividad, _cargar(), Comparacion, comparar(), _flecha(), formatear(), _indice_actividades(), _num() (+1 more)

### Community 40 - "test_versionado.py"
Cohesion: 0.09
Nodes (11): max_ctx_efectivo(), resolver_ventana(), _a_fecha(), chunk_activo(), filtrar_activos(), marcar_version(), _buscador(), _corpus() (+3 more)

### Community 41 - "Tests · Simulación de Azure (pipeline)"
Cohesion: 0.08
Nodes (9): cliente_azure(), respuesta_azure(), TestClienteAzureConstruyeBienLaPeticion, TestDeteccionAutomaticaDelDeployment, TestModosDeFalloDeAzure, TestNegociacionDelParametroDeTokens, TestPipeline1ExplicadorYRevisionConAzure, TestPipelineCompletoConAzureSimulado (+1 more)

### Community 42 - "Archivado v28 · Compresión de contexto"
Cohesion: 0.10
Nodes (3): ContextCompressor, ContextMemoryCompressor, ConversationSummarizer

### Community 43 - "sys"
Cohesion: 0.03
Nodes (16): FormulaDetector, MethodologyChecker, FeedbackStore, ChainOfThought, generar_challenger_con_rag_desde_hallazgos(), VIRFAgent, main(), ejecutar_escenario() (+8 more)

### Community 44 - "ClienteAzureOpenAIIA"
Cohesion: 0.10
Nodes (9): ClienteAzureOpenAIIA, ClienteOpenAIIA, _detectar_key_en_example(), _es_placeholder(), _huella_credenciales(), _secreto(), test_cliente_azure_rechaza_endpoint_no_permitido(), test_openai_exige_api_key() (+1 more)

### Community 45 - "VIRF PLUS · Consenso entre dos modelos"
Cohesion: 0.06
Nodes (23): _campos_decision(), ClienteConsensoIA, comparar_respuestas(), _llamada_independiente(), _mas_conservadora(), _nombre_modelo(), _normalizar(), _puntaje_de() (+15 more)

### Community 46 - "generar_presentacion_guia.py"
Cohesion: 0.07
Nodes (63): captura(), chip(), circulo(), codigo(), construir(), d_agenda(), d_agente_corporativo(), d_arquitectura() (+55 more)

### Community 47 - "routers/config.py"
Cohesion: 0.10
Nodes (24): fuente_secretos(), obtener_secreto(), secreto_configurado(), sec(), _escaner(), _esquema(), _propiedades(), test_databricks_secret_scope() (+16 more)

### Community 48 - "preguntas_oro_rag.py"
Cohesion: 0.07
Nodes (9): _chunks_del_dominio(), _elegible_r3(), evaluar(), _fuentes_del_dominio(), informe(), main(), _metricas(), TestPreguntasOroRAG (+1 more)

### Community 49 - "estudio_insumos.py"
Cohesion: 0.12
Nodes (21): _json_laxo(), borrar(), _bytes(), _cliente_por_defecto(), dir_cache(), dir_comun(), estudiar(), ficha_determinista() (+13 more)

### Community 50 - "Custodia · Registro de emisiones"
Cohesion: 0.12
Nodes (3): leer_registro(), verificar_emisiones(), TestRegistroEmisiones

### Community 51 - "chat_service.py"
Cohesion: 0.13
Nodes (20): estado_chat(), a_dict(), _agregar(), _ahora(), _cargar_de_disco(), _emitir_pregunta(), _estados_para_sustentar(), _extraer_observaciones() (+12 more)

### Community 52 - "Solo Informe · Estándar, borrador e imágenes"
Cohesion: 0.08
Nodes (31): test_adjunto_rechaza_extension_tamano_y_id_invalido(), test_cargar_estandar_antiguo_se_rehace_desde_el_xlsx(), test_generar_exige_tier_si_el_estandar_lo_tiene(), test_imagen_rechaza_extension_y_id_invalido(), TestParser, borrar_estandar(), descargar(), ver_imagen() (+23 more)

### Community 53 - "RevisorCodigo"
Cohesion: 0.12
Nodes (3): descubrir_modulos(), _excluir_dependencias_activo(), TestRevisionCodigo

### Community 54 - "test_proveedores_ia.py"
Cohesion: 0.08
Nodes (18): autorizar_proveedor(), cliente_dedicado(), _instanciar(), reset_cliente_ia(), verificar_host_ia(), test_un_proveedor_no_catalogado_no_se_abre_nunca(), produccion(), test_allowlist_explicita_restringe_a_un_solo_recurso() (+10 more)

### Community 55 - "Skills · Calidad de datos"
Cohesion: 0.12
Nodes (13): DataLeakageResult, DataQualityResult, _ejecutar_en_sandbox(), _evaluar_leakage(), _main(), _outliers_iqr(), run_data_quality_check(), csv_10_outliers_5_duplicados() (+5 more)

### Community 56 - "Skills · Catálogo y clase base"
Cohesion: 0.06
Nodes (11): ResultadoSkill, SkillBase, listar_skills(), obtener_skill(), SkillChallenger, SkillCoherencia, SkillDatos, SkillGobierno (+3 more)

### Community 57 - "solicitar_segunda_firma"
Cohesion: 0.06
Nodes (11): aviso_segunda_revision(), _cargar_registro(), firmas_consecutivas(), historial_por_validador(), imprimir_historial(), _normalizar_nombre(), requiere_doble_firma(), SegundaFirmaRequerida (+3 more)

### Community 58 - "sesion_store.py"
Cohesion: 0.09
Nodes (18): validador_actual(), _reconstruye_ctx(), ws_chat(), _login_o_401(), cancelar_validacion(), lanzar_validacion(), accion_de(), middleware_auditoria() (+10 more)

### Community 59 - "refrescarCard"
Cohesion: 0.21
Nodes (12): cablearCard(), cargarMotoresEntidad(), claseEstado(), clasifSubida(), fmtPct(), iconoEstado(), logSubida(), refrescarCard() (+4 more)

### Community 60 - "evaluar_abstencion"
Cohesion: 0.14
Nodes (13): evaluar_abstencion(), _scores(), umbral_beta(), test_beta_por_defecto_solo_abstiene_ante_ausencia_total(), test_evidencia_fuerte_no_se_abstiene(), test_retrieval_debil_por_debajo_de_beta_se_abstiene(), test_scores_no_numericos_se_ignoran(), test_sin_fragmentos_se_abstiene() (+5 more)

### Community 61 - "Archivado · Config monolítica antigua"
Cohesion: 0.08
Nodes (8): ClienteAnthropicIA, ClienteAzureOpenAIIA, ClienteIA, _detectar_key_en_example(), get_cliente_ia(), mostrar_configuracion(), reset_cliente_ia(), _validar_consistencia_modelo()

### Community 62 - "Salvaguardas · Entailment (LLM como juez)"
Cohesion: 0.11
Nodes (15): activo(), _na(), _parsear(), _prompt(), _subcadena_laxa(), verificar(), ClienteFake, test_apagado_por_defecto_devuelve_na() (+7 more)

### Community 64 - "Verificador VIRF · Paquete de verificación"
Cohesion: 0.17
Nodes (16): bloque_A(), bloque_B_C(), bloque_D(), bloque_E(), bloque_F(), bloque_G(), Coleccion, _commit() (+8 more)

### Community 65 - "Tests · Estructura de la configuración"
Cohesion: 0.10
Nodes (5): _codigo_vivo(), _ficheros_py(), TestAzureEsElProveedorPrioritario, TestMonolitoArchivadoNoSeImporta, TestPruebaDeHumoListaParaCredencial

### Community 66 - "get"
Cohesion: 0.10
Nodes (24): get(), salud(), descargar_acta_cierre(), conexiones(), borrar_insumo(), cambiar_modalidad(), CambiarModalidad, cerrar() (+16 more)

### Community 67 - "enmascarar"
Cohesion: 0.15
Nodes (28): contiene_pii(), enmascarar(), token(), test_campos_de_acta(), test_carne_extranjeria(), test_carne_sin_digitos_no_se_toca(), test_cci_20_digitos(), test_correo_se_enmascara() (+20 more)

### Community 68 - "pedirJSON"
Cohesion: 0.09
Nodes (42): abrirControles(), abrirCuestionamientos(), abrirModalNuevoModelo(), abrirResultados(), abrirSkills(), agregarCuestCustom(), agregarSkillCustom(), arrancar() (+34 more)

### Community 69 - "Solo Informe · Router y endpoints"
Cohesion: 0.15
Nodes (20): Adjunto, DatosInforme, estado(), generar(), guardar_borrador(), _ia(), ia_estado(), ia_grafico() (+12 more)

### Community 70 - "Aislamiento entre clientes (tenant)"
Cohesion: 0.09
Nodes (15): assert_sin_contaminacion(), ContaminacionModelo, etiquetar_chunk(), filtrar_por_tenant(), pertenece(), porcentaje_contaminacion(), get_buscador(), _reset_para_tests() (+7 more)

### Community 71 - "generador_markdown.py"
Cohesion: 0.15
Nodes (12): _bloque_citas(), _cabecera(), _detalle(), _etiqueta_pj(), _firma_agente(), _metodologia(), _orden_pj(), _pedidos() (+4 more)

### Community 72 - "Motor IA · Scores y semáforo"
Cohesion: 0.10
Nodes (5): calcular_score_ambito(), calcular_score_global(), get_semaforo(), TestAuditoriaSinEvidenciaEsFaltaCriticaNoAusenciaDeDictamen, TestScores

### Community 73 - "Archivado · Generador Excel antiguo"
Cohesion: 0.15
Nodes (15): _align(), _border_all(), _border_medium(), _color_puntaje_celda(), _color_score(), _crear_hoja_ambito(), _crear_hoja_resumen(), _crear_hoja_tracking() (+7 more)

### Community 74 - "Skills tipadas · Documentación y gobierno"
Cohesion: 0.11
Nodes (9): AlcanceRubro, ResultadoAlcance, SkillTipada, SkillCalidadDatos, SkillDocumentacion, SkillGobierno, SkillImplementacion, SkillMetodologia (+1 more)

### Community 75 - "Feedback · Calidad del proceso y autoría"
Cohesion: 0.09
Nodes (4): aprobar_feedback(), autor_de(), calidad_proceso(), TestAutoriaFeedback

### Community 76 - "Esquemas de datos (contratos)"
Cohesion: 0.26
Nodes (13): desde_dict(), intentar_validar(), _reporte_ok(), test_cita_ausente_falla(), test_confianza_fuera_de_rango_falla(), test_desviado_sin_codigo_falla(), test_dict_correcto_produce_reporte_valido(), test_intentar_validar_no_levanta() (+5 more)

### Community 77 - "diagnosticar"
Cohesion: 0.22
Nodes (17): diagnosticar(), _estados(), _fabrica(), fabrica(), manejar(), _ok_json(), test_certificado_corporativo_es_capa_4_y_no_desactiva_tls(), fabrica() (+9 more)

### Community 78 - "Solo Informe · Asistencia con IA"
Cohesion: 0.09
Nodes (20): test_azure_por_defecto_y_lo_que_falta(), test_azure_usa_deployment_propio_del_apartado(), test_clave_rechazada_da_mensaje_claro(), test_grafico_barras_con_cifras_del_texto(), test_grafico_flujo(), test_grafico_rechaza_cifras_inventadas(), test_grafico_texto_corto_o_json_roto(), test_manual_formato_no_admitido() (+12 more)

### Community 80 - "Web · Pantalla Solo Informe (frontend)"
Cohesion: 0.16
Nodes (26): cablearSoloInforme(), entrarASoloInforme(), siClaveAmbito(), siClaveRiesgo(), siControl(), siControlesVisibles(), siDatos(), siEditar() (+18 more)

### Community 81 - "Motor · Controles sobre datos (Mx_04)"
Cohesion: 0.11
Nodes (10): alertas_criticas(), calcular_riesgo_global(), convertir_resultado_data_a_texto(), ejecutar_control_unicidad(), ejecutar_motor_data_por_fila(), parsear_config_control(), parsear_lista_campos(), resumen_cuestionamientos_consola() (+2 more)

### Community 83 - "get_cliente_ia"
Cohesion: 0.06
Nodes (39): get_cliente_ia(), _azure(), _clave_en_env(), _consenso(), Doble, _espia(), fabricas(), _fabrica() (+31 more)

### Community 85 - "Abstención y calibración beta"
Cohesion: 0.14
Nodes (15): aplicar(), _retirar(), test_afirmacion_sin_respaldo_no_llega_al_informe(), test_motor_marca_estado_evidencia(), _evaluar(), _res(), test_cita_inexistente_invalida_la_afirmacion(), test_con_evidencia_citable_no_se_abstiene_aunque_rag_sea_debil() (+7 more)

### Community 86 - "test_antialucinacion_brechas.py"
Cohesion: 0.16
Nodes (6): _obs(), TestChat, TestChunker, TestPulir, clear_todo(), verificar_respuesta()

### Community 87 - "Citas · Validación determinista"
Cohesion: 0.17
Nodes (14): extraer_ids(), id_de_chunk(), _ids_disponibles(), validar_afirmacion(), verificar_afirmaciones(), verificar_entailment(), _contexto(), test_agregado_alimenta_tasa_para_d4() (+6 more)

### Community 89 - "diagnostico_azure_virf.py"
Cohesion: 0.17
Nodes (14): Capa, capa_clave(), capa_endpoint(), capa_env(), capa_python(), capa_red(), capa_tls(), capas_llamada() (+6 more)

### Community 90 - "modulos/validacion_completa.py"
Cohesion: 0.09
Nodes (35): _ahora(), cargar_historial(), _celdas_plantilla(), cerrar_etapa(), construir_notebook(), contexto_para_cuadro(), _contexto_previas(), _determinista() (+27 more)

### Community 91 - "validate_project.py"
Cohesion: 0.14
Nodes (20): _es_ambito_metodologia(), Hallazgo, test_paquete_ausente_no_se_reporta(), test_paquete_instalado_pero_roto_se_reporta(), check(), _es_de_entorno_virtual(), main(), seccion() (+12 more)

### Community 92 - "feedback.py"
Cohesion: 0.07
Nodes (20): _escribir_json_atomico(), _lock_archivo(), bucle_feedback_consola(), _bucle_feedback_interactivo(), _canonico(), cargar_historial_crudo(), _contenido(), dar_de_baja() (+12 more)

### Community 94 - "Skills · Cola de acciones pendientes"
Cohesion: 0.15
Nodes (9): AccionPendiente, encolar_accion(), _escribir(), _leer(), listar_pendientes(), ruta_cola_por_defecto(), test_accion_de_impacto_queda_encolada_no_ejecutada(), test_el_modulo_no_expone_ninguna_via_de_ejecucion_directa() (+1 more)

### Community 96 - "web/static/js/app.js"
Cohesion: 0.09
Nodes (35): abrirDocumentar(), abrirModalPasswd(), AMBITO_PESOS, analizarCodigo(), cablearDocumentar(), cablearEntendimiento(), cablearVisorPrompt(), CLASE_RIESGO (+27 more)

### Community 97 - "Frontend · Guía interactiva"
Cohesion: 0.23
Nodes (22): abrirGuia(), AYUDA, barraHtml(), botonQ(), cerrarGuia(), construirGuia(), dashboardVisible(), _e() (+14 more)

### Community 99 - "motores_datos.py"
Cohesion: 0.06
Nodes (26): _base(), cargar_datasets(), cargar_datasets_uc(), _cols(), ejecutar_motor(), _estado_por_tasa(), _falta(), LecturaNoMinima (+18 more)

### Community 100 - "20261118_antes_rediseno/static/js/app.js"
Cohesion: 0.08
Nodes (45): abrirControles(), abrirDocumentar(), abrirModalPasswd(), abrirResultados(), AMBITO_PESOS, cablearDocumentar(), cablearResultados(), cablearTabs() (+37 more)

### Community 102 - "Análisis estático del código"
Cohesion: 0.14
Nodes (6): analizar_arbol(), analizar_modulo(), _codigo_de(), _contrastar_notebook(), _hechos(), _hechos_notebook()

### Community 104 - "Tests · SQL y R como código del modelo"
Cohesion: 0.10
Nodes (3): _partir_por_definiciones(), _sentencia_cerrada(), TestSqlYRSonCodigoDelModelo

### Community 105 - "leer_resultados"
Cohesion: 0.06
Nodes (12): _a_fraccion(), _carpeta(), _escala_de_la_columna(), evaluaciones_desde_motores_entidad(), leer_resultados(), _leer_tabla(), _mapear_columnas(), _norm() (+4 more)

### Community 106 - "Informe web · Generador con capturas"
Cohesion: 0.07
Nodes (28): citas_en_evidencia(), campo(), _caption(), _etiqueta_valor(), _p(), test_informe_docx_usa_el_cuadro_en_resumen_y_anexo(), test_seccion_tabla_final_agrega_tabla_y_puntaje(), test_seccion_vacia_no_revienta() (+20 more)

### Community 107 - "Evidencia · Capturas (pantallazos)"
Cohesion: 0.17
Nodes (16): captura_cita(), captura_codigo(), captura_portada(), _clave(), _fuente(), _leer(), _lineas_de(), localizar() (+8 more)

### Community 108 - "auth.py"
Cohesion: 0.11
Nodes (15): IdentidadNoConfigurada, obtener_proveedor(), proveedor_activo(), ProveedorLibre, raices_retencion(), _purgar_retencion(), completar_login(), hacer_logout() (+7 more)

### Community 109 - "Archivado · Lector de inputs antiguo"
Cohesion: 0.16
Nodes (12): cargar_todos_los_inputs(), consolidar_contexto(), leer_archivo(), leer_csv(), leer_directorio(), leer_docx(), leer_json(), leer_pdf() (+4 more)

### Community 110 - "Fixtures · IFRS9 y VaR de demostración"
Cohesion: 0.09
Nodes (9): retornos_diarios(), var_cartera(), var_historico(), var_historico(), ajustar_forward_looking(), calcular_ecl(), clasificar_etapa(), var_historico() (+1 more)

### Community 111 - "Motor IA v2 · Cálculo de score"
Cohesion: 0.08
Nodes (6): CalculadorScore, DocumentoChunker, _enunciado_control(), EstadoEvaluacion, ReportadorEvaluacion, ValidadorInputs

### Community 112 - "cuestionamientos.py"
Cohesion: 0.17
Nodes (9): agregar_personalizado(), borrar_personalizado(), Cuestionamiento, _cuestionamientos_default(), _leer_json_seguro(), listar_default(), listar_personalizados(), toggle_default() (+1 more)

### Community 114 - "leer_estandares_virf"
Cohesion: 0.08
Nodes (10): _evaluar_actividad_thread_safe(), evaluar_ambito_paralelo(), evaluar_todos_ambitos_paralelo(), _evaluar_un_ambito(), orquestar_pipeline_ambitos(), cargar_todos_inputs(), inputs_para_dimension(), leer_estandares_virf() (+2 more)

### Community 116 - "upload.py"
Cohesion: 0.07
Nodes (19): test_formatos_de_tarjeta(), test_upload_rechaza_extension_no_declarada(), arbol_inputs(), borrar_archivo(), _clasificacion_o_error(), _clasificar_estado(), listar_carpeta(), listar_destinos() (+11 more)

### Community 117 - "json"
Cohesion: 0.07
Nodes (27): aprobado(), leer(), registrar(), ruta_log(), _ultimo_hash(), verificar(), _hash_cadena(), informes_de_modelo() (+19 more)

### Community 118 - "Tests · Informe Word sin puntajes falsos"
Cohesion: 0.13
Nodes (3): _es_error(), _normalizar_score(), TestAuditoriaInformeWordNoDeformaLosDatos

### Community 119 - "modulos/__init__.py"
Cohesion: 0.10
Nodes (7): docs(), _pdf(), test_informe_web_inserta_capturas(), generar(), listar_versiones(), _nombre_canonico(), salida_dir_de()

### Community 120 - "Informe · Contrato ValidationReport"
Cohesion: 0.09
Nodes (8): EstadoRequisito, validar_reporte(), ValidationClaim, ValidationReport, _agrupar_por_ambito(), _añadir_pie_con_paginacion(), _run_campo(), _run_texto()

### Community 121 - "pipeline_runner.py"
Cohesion: 0.11
Nodes (15): test_runner_no_pasa_firmante_por_argumentos(), _es_create_task(), test_ninguna_create_task_queda_sin_referencia(), ws_validar(), _bombear_stdout(), _clasificar_fase(), construir_args(), _construir_env_hijo() (+7 more)

### Community 122 - "Archivado v28 · Challenger sin RAG"
Cohesion: 0.19
Nodes (3): ChallengerGenerator, generar_challenger_desde_hallazgos(), test_challenger_directo()

### Community 123 - "test_solo_informe.py"
Cohesion: 0.07
Nodes (27): cliente(), _datos(), _o(), _png(), test_cumplimiento_por_ambito(), test_ficha_del_documento(), test_flujo_endpoints(), test_generar_sin_estandar_o_con_errores() (+19 more)

### Community 124 - "Chunker estructural"
Cohesion: 0.18
Nodes (11): _es_cerca(), _es_tabla(), segmentar_estructural(), _unidades(), test_bloque_atomico_mayor_que_el_tope_se_emite_entero(), test_ningun_segmento_corta_a_mitad_de_linea(), test_no_parte_la_formula_a_la_mitad(), test_no_parte_la_tabla_a_la_mitad() (+3 more)

### Community 131 - "Salvaguardas · Inyección de prompts"
Cohesion: 0.18
Nodes (12): contiene_inyeccion(), neutralizar(), sanear_salida(), _rep(), _patrones(), test_anular_hallazgos_se_neutraliza(), test_forzar_puntaje_se_neutraliza(), test_ignorar_instrucciones_se_neutraliza() (+4 more)

### Community 133 - "identidad.py"
Cohesion: 0.22
Nodes (12): _b64(), _clave(), emitir_asercion(), identidad_autenticada(), _unb64(), verificar_asercion(), _quien_por_defecto(), test_asercion_caducada_falla() (+4 more)

### Community 134 - "Tests · Conexión Azure y parámetros"
Cohesion: 0.13
Nodes (4): _fabricar(), ClienteAzureFalso, _Completions, TestValidarConexionNegociaElParametroDeTokens

### Community 136 - "ExplicadorModelo"
Cohesion: 0.06
Nodes (3): ExplicadorModelo, _render_supuestos(), TestExplicadorModelo

### Community 138 - "Tests · Automatizaciones"
Cohesion: 0.10
Nodes (7): TestCuadroAutomatizaciones, carpeta(), IAFalsa, _libro(), test_cuadro_con_ia_riesgo_desde_impactos(), test_ia_sin_json_falla_con_mensaje(), test_normalizar_riesgo()

### Community 139 - "revision_codigo.py"
Cohesion: 0.09
Nodes (5): HallazgoCodigo, inventario(), _lenguaje_de(), _numerar_lineas(), RevisorCodigo

### Community 141 - "Feedback · Estadísticas"
Cohesion: 0.16
Nodes (12): modo_estadistica_feedback(), calcular_estadisticas(), cargar_historial(), _registros_utilizables(), _align(), _border(), _color_mae(), _color_pct() (+4 more)

### Community 143 - "Exportador Excel"
Cohesion: 0.20
Nodes (10): a_bytes(), _docx_con(), test_familia_e_icono(), test_fichero_compuesto_con_muchos_flujos(), test_fichero_compuesto_grande_usa_difat(), test_office_moderno_va_nativo_y_el_resto_como_paquete(), test_paquete_ole_legible_y_con_el_archivo_intacto(), _tabla() (+2 more)

### Community 144 - "generar_word_informe"
Cohesion: 0.12
Nodes (8): _generar_recomendacion_automatica(), generar_word_informe(), conclusion_extra(), detalle_control(), escala(), _procedencia_nota(), linea_independencia(), TestWord

### Community 145 - "Datos · Perfilado de datasets"
Cohesion: 0.13
Nodes (5): _describir_rango(), _intentar_fechas(), perfilar_dataframe(), PerfilColumna, PerfilDataset

### Community 146 - "Tests · DOCX de regresión"
Cohesion: 0.28
Nodes (10): generar_docx_validacion(), veredicto_de_ambito(), _reporte_mock(), test_abstencion_se_declara_en_el_docx(), test_genera_docx_con_veredictos_por_ambito(), test_pie_con_paginacion_tiene_campo_page(), test_seccion_referencias_consolidada(), test_seccion_sin_observaciones() (+2 more)

### Community 148 - "Tests · Skills tipadas"
Cohesion: 0.10
Nodes (8): DeclaracionHerramienta, declaraciones_herramientas(), test_cada_skill_expone_declaracion_de_herramienta_valida(), test_consulta_fuera_de_alcance_dispara_abstencion_o_derivacion(), test_declaraciones_para_tools_es_serializable_json(), test_rubro_se_resuelve_desde_config_no_hardcode(), test_skills_no_operativas_declaran_pendiente_api(), test_una_skill_nunca_opina_del_dominio_de_otra()

### Community 150 - "test_owasp_llm.py"
Cohesion: 0.20
Nodes (12): _clave(), escribir_inventario_csv(), estado_fuente(), _fecha(), fuente_vencida(), FuenteInvalida, inventario(), _leer() (+4 more)

### Community 152 - "pii.py"
Cohesion: 0.10
Nodes (11): _dni_nie_es_valido(), _dni_pe_verificador_valido(), _enmascarar_nombres(), _rep_linea(), _rep_nombre(), _es_nombre(), _iban_valido(), _luhn_valido() (+3 more)

### Community 155 - "routers/automatizaciones.py"
Cohesion: 0.15
Nodes (10): localizar_excels(), dir_vigentes(), carpeta_entrada(), carpeta_salida(), _contexto_modelo(), descargar(), estado(), generar() (+2 more)

### Community 156 - "cablearSoloInforme"
Cohesion: 0.12
Nodes (33): cablearSoloInforme(), cablearSoloInformeIA(), entrarASoloInforme(), siAccionIA(), siCargarIA(), siClaveAmbito(), siClaveRiesgo(), siControl() (+25 more)

### Community 157 - "Tests · Subida ZIP (límites)"
Cohesion: 0.35
Nodes (9): ctx(), _extraidos(), _subir(), test_demasiadas_entradas_413(), test_tamano_declarado_excesivo_413(), test_zip_bomba_upload_pequeno_expansion_grande(), test_zip_normal_se_extrae(), test_zip_slip_rechazado() (+1 more)

### Community 158 - "columns"
Cohesion: 0.14
Nodes (5): control(), control(), control(), control(), columns()

### Community 159 - "test_auditoria.py"
Cohesion: 0.17
Nodes (9): cliente(), _como(), _entradas(), test_cada_accion_una_entrada(), test_entrada_tiene_quien_que_cuando_donde_resultado(), test_intento_denegado_tambien_queda(), test_lectura_normal_no_genera_ruido(), test_llamada_a_ia_atribuida_a_la_persona() (+1 more)

### Community 160 - "test_gobierno_codigo.py"
Cohesion: 0.13
Nodes (6): fb(), fuentes(), test_cargar_fuente_sin_dueno_o_vigencia_falla(), test_contrato_declara_evidencia_insuficiente(), test_feedback_nace_pendiente_y_no_ajusta(), test_tool_sin_permiso_falla()

### Community 161 - "material_no_confiable"
Cohesion: 0.08
Nodes (15): llamar_ia(), grabador(), _Grabador, _py_del_repo(), test_automatizaciones_delimita_excels_y_contexto(), test_cada_llamante_delimita_su_material(), test_consenso_sanea_una_vez_y_autoriza_cada_interno(), test_controles_a_notebook_delimita_el_documento() (+7 more)

### Community 162 - "almacenamiento.py"
Cohesion: 0.07
Nodes (31): dias_retencion(), entorno_almacenamiento(), AlmacenamientoNoPermitido, borrado_seguro(), cifrado_disponible(), CifradoNoDisponible, cifrar(), clasificacion_de() (+23 more)

### Community 163 - "es_de_entorno_virtual"
Cohesion: 0.26
Nodes (6): es_de_entorno_virtual(), _es_entorno(), _entorno_falso(), test_codigo_del_proyecto_no_se_confunde_con_entorno(), test_entorno_con_nombre_arbitrario_se_reconoce(), test_site_packages_se_reconoce()

### Community 167 - "TestAuditoriaEntornoCorporativo"
Cohesion: 0.17
Nodes (3): _diagnostico_filtro(), _extraer_categorias(), TestAuditoriaEntornoCorporativo

### Community 168 - "test_gobierno_ia.py"
Cohesion: 0.15
Nodes (12): cargar(), _clave(), _firma(), guardar(), PickleNoFirmado, _Bomba, _llamadas(), test_pickle_firmado_ida_y_vuelta() (+4 more)

### Community 169 - "test_ejecucion_codigo.py"
Cohesion: 0.12
Nodes (12): cargar_controles(), carpeta_de_dominio(), _extraer_meta(), cliente(), _llamadas_peligrosas(), _nb(), test_controles_reales_cargan_sin_ejecutar(), test_meta_calculado_se_rechaza() (+4 more)

### Community 170 - "Tests · Contrato y estadísticas"
Cohesion: 0.14
Nodes (3): _validar_contrato_evaluacion(), TestAuditoriaHistorialSucioNoTumbaLasEstadisticas, TestContrato

### Community 171 - "solo_informe_ia.py"
Cohesion: 0.24
Nodes (14): test_busqueda_no_repite_bloques_de_plantilla(), test_manual_fragmentos_con_pagina_y_busqueda(), borrar_manual(), borrar_manual(), buscar(), _dibujar(), dir_manuales(), _fragmentar() (+6 more)

### Community 174 - "Frontend · Chat"
Cohesion: 0.24
Nodes (13): abrirChat(), adjuntarEvidenciaChat(), cablearChat(), cargarListaInformesChat(), conectarChatWS(), consolidarChat(), descargarActaCierre(), enviarChat() (+5 more)

### Community 175 - "verificacion_cifras.py"
Cohesion: 0.14
Nodes (7): cifras_ausentes(), es_sentinela(), _formas(), _significativa(), sin_cita_literal(), ventana_relevante(), TestVerificacionCifras

### Community 176 - "pedirJSON"
Cohesion: 0.20
Nodes (25): abrirCuestionamientos(), agregarCuestCustom(), agregarSkillCustom(), borrarDominio(), borrarPaperRag(), cablearCuestionamientos(), cablearRagDominio(), cargarCuestionamientos() (+17 more)

### Community 177 - "test_roles.py"
Cohesion: 0.12
Nodes (13): cliente(), _como(), fb(), _ident(), test_admin_pasa_el_control_de_rol(), test_corpus_compartido_solo_admin(), test_editar_prompts_solo_admin(), test_lanzar_validacion_exige_rol_validador() (+5 more)

### Community 178 - "consolidar_decisiones"
Cohesion: 0.15
Nodes (9): consolidar_decisiones(), _indexar_decisiones(), _norm(), tabla_final(), valor_cumple(), _datos(), _fn(), TestConsolidar (+1 more)

### Community 181 - "AST"
Cohesion: 0.37
Nodes (13): _ast(), dependencias(), endpoints(), entorno(), flags(), grafo(), _limpia(), _lit() (+5 more)

### Community 182 - "sesion_activa"
Cohesion: 0.20
Nodes (5): adjuntar_chat(), consolidar_chat(), iniciar_chat(), IniciarChat, observaciones()

### Community 183 - "AgentOrchestrator"
Cohesion: 0.05
Nodes (9): AgentOrchestrator, TaskRouter, TaskType, WorkflowContext, WorkflowManager, WorkflowMetrics, WorkflowState, handle_command() (+1 more)

### Community 184 - "secretos.py"
Cohesion: 0.20
Nodes (8): _dbutils(), _desde_databricks(), _desde_entorno(), _desde_keyvault(), _en_archivo_env(), _modo_desarrollo(), SecretoEnTextoPlano, SecretoNoDisponible

### Community 189 - "resultados.py"
Cohesion: 0.23
Nodes (11): descargar_excel(), _leer_json(), listar_resultados(), _outputs(), _payload_tabla(), _resolver(), resultado_de_la_ultima_corrida(), resultado_por_ruta() (+3 more)

### Community 191 - "test_costes.py"
Cohesion: 0.08
Nodes (18): coste_usd(), precio_entrada_por_mtok(), precio_salida_por_mtok(), agregar(), _csv(), generar(), llamadas(), p95() (+10 more)

### Community 193 - "estandares.py"
Cohesion: 0.18
Nodes (7): borrar(), confirmar(), descartar_pendiente(), get_detalle(), get_estado(), get_vista_previa(), upload()

### Community 194 - "20261118_antes_rediseno/static/js/guia.js"
Cohesion: 0.23
Nodes (22): abrirGuia(), AYUDA, barraHtml(), botonQ(), cerrarGuia(), construirGuia(), dashboardVisible(), _e() (+14 more)

### Community 199 - "escapeHtml"
Cohesion: 0.17
Nodes (22): abrirDominioRag(), borrarDominio(), borrarPaperRag(), cablearCrearDominio(), cablearRagDominio(), cargarRagDominios(), colorSemaforo(), crearDominio() (+14 more)

### Community 200 - "completa.js"
Cohesion: 0.23
Nodes (22): abrirEtapa(), abrirInsumos(), alternarModalidad(), cablearCompleta(), pintarModalidad(), VC, VC_TIPO, vcAgregar() (+14 more)

### Community 201 - "Identidad"
Cohesion: 0.14
Nodes (6): AsercionInvalida, Identidad, ProveedorSimulado, firmar_como(), _firmar(), test_simulado_no_existe_fuera_de_tests()

### Community 202 - "red.py"
Cohesion: 0.17
Nodes (7): cliente_http(), con_reintento(), contexto_almacen_sistema(), es_transitorio(), espera_sugerida(), HostNoPermitido, test_almacen_del_sistema_usa_truststore()

### Community 203 - "generar_informe_md"
Cohesion: 0.13
Nodes (6): _como_leer(), generar_informe_md(), _inconsistencias(), _limitaciones(), _politicas(), _skills()

### Community 204 - "cuestionamientos_ext.py"
Cohesion: 0.29
Nodes (4): catalogo_activo(), _leer(), _traducir_personalizado(), _valida_regex()

### Community 205 - "Acta de cierre (Excel)"
Cohesion: 0.23
Nodes (10): acta_cierre_bytes(), _aplica(), construir_libro(), _norm_act(), test_acta_hoja_decisiones_lista_cada_veredicto(), test_acta_marca_decision_en_filas_cambiadas(), test_acta_resumen_puntaje_sube_con_aprobado(), test_acta_tiene_tres_hojas_y_columnas() (+2 more)

### Community 206 - "test_aprendizaje_chat.py"
Cohesion: 0.13
Nodes (14): _corr(), _datos(), feedback_aislado(), test_aprobado_se_guarda_como_correccion(), test_autoaprobacion_bloqueada_por_nombre_si_falta_oid(), test_bloque_aprendizaje_exige_masa_critica(), test_bloque_aprendizaje_ignora_feedback_sin_aprobar(), test_chat_guarda_oid_y_bloquea_autoaprobacion() (+6 more)

### Community 208 - "openpyxl"
Cohesion: 0.11
Nodes (8): redirigir_estandar(), _crear_xlsx_estandar(), ctx_de_prueba(), TestCliFlagEstandares, TestParseo, TestTolerante, _xlsx_con_titulo(), parsear()

### Community 209 - "test_validacion_completa.py"
Cohesion: 0.11
Nodes (10): ClienteFalso, dirs(), _ejecutar_notebook(), _excel_resultado(), test_02_dos_pasadas_contexto_y_notebook_de_la_ia(), test_anexo_del_informe_con_imagenes(), test_endpoints(), test_error_de_sintaxis_se_repara() (+2 more)

### Community 213 - "response_evaluator.py"
Cohesion: 0.08
Nodes (5): ConfidenceScorer, GroundingChecker, HallucinationChecker, ResponseEvaluator, build_agent()

### Community 214 - "Tests · Anexo de correcciones"
Cohesion: 0.12
Nodes (8): cargo_de(), _mismo_modelo(), _orden_sesion(), overrides_de_modelo(), resumen_override(), _sesion(), ultimo_ciclo(), TestCumplimientoAnexoOverride

### Community 215 - "Fixtures · Modelo sintético Fraude/AML"
Cohesion: 0.22
Nodes (3): aplicar_reglas(), generar_alertas(), score_anomalia()

### Community 217 - "verificar_remoto_git.py"
Cohesion: 0.17
Nodes (13): repo_corporativo(), host_de(), main(), no_autorizados(), _normalizar(), remoto_autorizado(), remotos(), test_azure_devops_autorizado() (+5 more)

### Community 218 - "ejecutar_aprobado"
Cohesion: 0.15
Nodes (10): aprobar(), CodigoNoAprobado, ejecutar_aprobado(), hash_codigo(), _ejecutar_notebook(), test_codigo_generado_por_ia_no_se_ejecuta_sin_aprobacion(), test_aprobado_se_ejecuta_aislado_y_sin_secretos(), test_aprobar_otro_codigo_no_habilita_este() (+2 more)

### Community 219 - "Frontend · Estándares"
Cohesion: 0.28
Nodes (13): abrirEstandares(), aceptarEstandares(), cablearEstandares(), cambiarArchivoEstandares(), estAvisosHtml(), estOrigenHtml(), mostrarErrorEstandares(), pintarEstandaresConfirmado() (+5 more)

### Community 220 - "test_corrida_fallida.py"
Cohesion: 0.13
Nodes (10): _resumen(), _Cliente, test_borrador_markdown_con_todos_los_ambitos_sin_puntaje(), test_borrador_markdown_ordena_los_no_evaluados_al_final(), test_cada_script_compila(), test_clave_rechazada_se_detecta_en_el_arranque_con_su_motivo(), test_codigo_de_salida_de_la_corrida(), test_el_arranque_no_dice_ok_sin_haber_verificado() (+2 more)

### Community 221 - "Análisis estático · Contraste doc vs código"
Cohesion: 0.29
Nodes (3): _contrastar(), _norm(), _numero_en_texto()

### Community 223 - "_label_semaforo"
Cohesion: 0.17
Nodes (6): _add_result_line(), _label_semaforo(), _puntaje_color_hex(), _puntaje_label(), _score_color_hex(), _status_resultado()

### Community 224 - "TestAuditoriaRespuestaVaciaDeLaAPI"
Cohesion: 0.14
Nodes (5): pdf_real(), TestAuditoriaRespuestaVaciaDeLaAPI, _BloqueSinTexto, _RespuestaVacia, texto_largo()

### Community 226 - "test_verificacion_citas.py"
Cohesion: 0.08
Nodes (20): _verificar_citas(), verificar_referencia_manual(), cita_en_texto(), _limpio(), normalizar_cita(), TestCitasPipeline, TestComillasSimples, _dudosas() (+12 more)

### Community 231 - "test_calidad_e2e.py"
Cohesion: 0.13
Nodes (3): ee(), test_oportunidades_de_mejora_no_tocan_el_core(), test_rubrica_invalida()

### Community 233 - "Frontend · Lanzar validación"
Cohesion: 0.46
Nodes (8): actualizarEstadoUI(), cablearValidacion(), cancelarValidacion(), conectarWebSocket(), lanzarValidacion(), pintarLinea(), pintarPrecondiciones(), precondicionesValidacion()

### Community 234 - "arrancar"
Cohesion: 0.16
Nodes (18): abrirModalNuevoModelo(), arrancar(), cablearAuth(), cablearDominio(), cablearDropzone(), cargarDominiosEnSelectorModelo(), cargarVirfPlus(), cerrarModalNuevoModelo() (+10 more)

### Community 236 - "TestCumplimientoCadenaDeCustodia"
Cohesion: 0.19
Nodes (3): verificar_evidencia(), hash_archivo(), TestCumplimientoCadenaDeCustodia

### Community 237 - "test_casos_borde.py"
Cohesion: 0.23
Nodes (12): _leer(), test_archivo_enorme_no_revienta_y_declara_tamano(), test_archivo_vacio(), test_codificaciones_raras(), test_excel_corrupto(), test_extension_desconocida_se_ignora(), test_falso_pdf(), test_json_roto_no_inventa() (+4 more)

### Community 238 - "conftest.py"
Cohesion: 0.21
Nodes (4): _registro_emisiones_aislado(), _secretos_de_test(), simular_aprobacion(), _virf_plus_aislado()

### Community 239 - "test_owasp_llm.py"
Cohesion: 0.20
Nodes (6): _enviar(), _Espia, test_abuso_de_tools_bloqueado(), test_datos_sensibles_no_salen_hacia_el_llm(), test_feedback_no_aprobado_no_envenena_puntajes(), test_inyeccion_indirecta_en_documento_subido()

### Community 240 - "descargar_notebook_controles"
Cohesion: 0.16
Nodes (5): catalogo(), descargar_notebook_controles(), _doc_controles_de_sesion(), _entendimiento_del_modelo(), resultados_de_la_entidad()

### Community 241 - "Tests · Endpoint del notebook"
Cohesion: 0.25
Nodes (4): _get_notebook(), make_ctx(), test_endpoint_fallback_llm_sin_repositorio(), test_endpoint_repositorio_dominio()

### Community 242 - "invocar"
Cohesion: 0.23
Nodes (8): invocar(), PermisoTool, _roles_de(), ToolDeshabilitada, ToolNoRegistrada, test_tool_deshabilitada_falla_aunque_tengas_rol(), test_tool_fuera_de_catalogo_falla(), test_tool_permitida_se_ejecuta_y_audita()

### Community 243 - "motor_ia_v2.py"
Cohesion: 0.16
Nodes (8): create_resultado_control_v13(), sha256_texto(), create_resultado_control_v13(), evaluar_control(), evaluar_todos_controles(), generar_informe_final(), orquestar_pipeline_virf(), construir_prompt_final()

### Community 246 - "reconstruir_estandar_desde_informes.py"
Cohesion: 0.19
Nodes (5): escribir(), extraer(), filas(), main(), _norm()

### Community 247 - "test_usuario_libre.py"
Cohesion: 0.17
Nodes (9): _aislar(), cliente_libre(), _entrar(), test_identidad_libre_rechaza_datos_invalidos(), test_login_libre_crea_sesion_marcada(), test_login_libre_queda_en_la_auditoria(), test_login_libre_respeta_roles(), test_sin_declarar_libre_el_endpoint_no_existe() (+1 more)

### Community 248 - "calcular"
Cohesion: 0.23
Nodes (3): TestPresupuestoService, aplicar_env(), calcular()

### Community 251 - "test_estudio_insumos.py"
Cohesion: 0.15
Nodes (6): prioridad(), ClienteEstudio, inputs(), test_fallo_de_ia_deja_ficha_determinista(), test_ia_lee_el_manual_entero_por_partes_y_cachea(), test_texto_para_prompt_prioriza_la_etapa_y_respeta_el_tope()

### Community 253 - "mostrarVista"
Cohesion: 0.18
Nodes (15): abrirDominioRag(), abrirSkills(), analizarCodigo(), cablearCrearDominio(), cablearEntendimiento(), cablearNav(), cargarEntendimiento(), ejecutarPrevuelo() (+7 more)

### Community 255 - "guia.py"
Cohesion: 0.15
Nodes (11): test_fuente_de_secretos_invalida_no_rompe_la_guia(), test_proveedor_aprobado_con_clave_en_la_fuente_queda_hecho(), test_proveedor_aprobado_sin_clave_en_la_fuente_queda_pendiente(), test_proveedor_no_aprobado_queda_pendiente_aunque_tenga_clave(), test_proveedor_no_catalogado(), _estado_config(), _ficheros(), _paso() (+3 more)

### Community 256 - "presupuesto"
Cohesion: 0.18
Nodes (7): BodyEditar, BodyRestaurar, editar(), get_base(), get_efectivos(), presupuesto(), restaurar()

### Community 259 - "test_clasificacion_docx.py"
Cohesion: 0.10
Nodes (16): clasificacion_informe(), aplicar(), etiqueta_por_defecto(), _pies(), pies_sin_etiqueta(), _cliente_simulado(), ejecutar(), main() (+8 more)

### Community 260 - "informe.py"
Cohesion: 0.21
Nodes (5): Consolidar, consolidar(), descargar(), estado(), versiones()

### Community 261 - "perfilar_carpeta"
Cohesion: 0.24
Nodes (4): documento_perfil(), perfilar_carpeta(), perfilar_datasets(), TestPerfiladorDatasets

### Community 286 - "test_regresion.py"
Cohesion: 0.06
Nodes (8): _estandar_es_reconstruccion(), TestAuditoriaCoberturaDeControlNoUsaMaximo, TestAuditoriaImportLocalNoEnsombreceAlGlobal, TestAuditoriaNombresDeAmbitoCoherentes, TestAuditoriaUnSoloAccesoAlHistorial, TestAuditoriaVolcadoDebugNoSeEscapa, TestIntegridad, TestSalidas

### Community 290 - "adjuntos_ole.py"
Cohesion: 0.14
Nodes (14): _ansi(), _arbol(), construir(), descripcion(), _entrada(), familia(), fichero_compuesto(), _fuente() (+6 more)

### Community 291 - "generar_kit.py"
Cohesion: 0.21
Nodes (4): excel(), hacer_estandar(), marcas(), pdf_texto()

### Community 306 - "verificar_cadena"
Cohesion: 0.24
Nodes (3): preservar_si_existe(), verificar_cadena(), TestCustodiaVariasCorridasElMismoDia

### Community 307 - "pandas"
Cohesion: 0.10
Nodes (10): actualizar_estandares_con_version(), agrupar_por_ambito(), cargar_actividades_por_tier(), _limpiar_str(), cargar(), depurar(), aplicar_woe(), calcular_score() (+2 more)

### Community 309 - "abrirChat"
Cohesion: 0.24
Nodes (13): abrirChat(), adjuntarEvidenciaChat(), cablearChat(), cargarListaInformesChat(), conectarChatWS(), consolidarChat(), descargarActaCierre(), enviarChat() (+5 more)

### Community 310 - "pathlib"
Cohesion: 0.04
Nodes (5): generar_instruccion_implementacion_mejorada(), EstadoEvaluacion, BaseIndexer, _indice_dir_defecto(), raiz_proyecto()

### Community 313 - "test_identidad.py"
Cohesion: 0.10
Nodes (18): identidad_para_feedback(), _ficha(), IdentidadRequerida, solicitar_identidad(), _clave_firma(), cliente(), _entrar(), test_asercion_falsa_en_el_entorno_no_firma() (+10 more)

### Community 315 - "abrirConfiguracion"
Cohesion: 0.26
Nodes (12): abrirConfiguracion(), abrirModal(), alternarVirfPlus(), cablearConfig(), cerrarModal(), guardarConfig(), guardarVirfPlus(), pintarContextoSidebar() (+4 more)

### Community 316 - "TestAuditoriaConsistenciaCruzada"
Cohesion: 0.18
Nodes (3): ruta_indice(), TestAuditoriaConsistenciaCruzada, dfs()

### Community 317 - "abrirConfiguracion"
Cohesion: 0.26
Nodes (12): abrirConfiguracion(), abrirModal(), alternarVirfPlus(), cablearConfig(), cerrarModal(), guardarConfig(), guardarVirfPlus(), pintarContextoSidebar() (+4 more)

### Community 318 - "desde_manuales"
Cohesion: 0.20
Nodes (6): TestSoloInforme, test_desde_manuales_cita_fuentes(), test_desde_manuales_sin_manuales(), citas_sin_respaldo(), desde_manuales(), _texto_plano()

### Community 320 - "comparar_doc_y_codigo"
Cohesion: 0.20
Nodes (5): comparar_doc_y_codigo(), extraer_clases_python(), extraer_funciones_python(), extraer_imports(), extraer_palabras_clave_doc()

### Community 322 - "tempfile"
Cohesion: 0.25
Nodes (5): _texto_completo(), _columnas_json(), construir_prompt(), _fmt_perfil(), _perfil_excel()

### Community 324 - "os"
Cohesion: 0.07
Nodes (10): _booleano(), _decimal(), _entero(), _num_env(), ruta_log_auditoria(), tiers_doble_firma(), cerrar_cache(), _reset_cierre_para_tests() (+2 more)

### Community 327 - "hooks"
Cohesion: 0.20
Nodes (9): always_run, entry, id, language, name, pass_filenames, repos, hooks (+1 more)

### Community 328 - "refrescarCard"
Cohesion: 0.27
Nodes (10): cablearCard(), clasifSubida(), iconoEstado(), logSubida(), refrescarCard(), renderCardHTML(), renderRagDominioHTML(), renderUploadCards() (+2 more)

### Community 330 - "escanear_secretos.py"
Cohesion: 0.40
Nodes (7): _archivos(), escanear_arbol(), escanear_historial(), escanear_texto(), _git(), main(), _recortar()

### Community 335 - "test_rag_desactualizado.py"
Cohesion: 0.36
Nodes (6): _set(), test_indice_ausente_con_papers_es_desactualizado(), test_indice_mas_nuevo_esta_al_dia(), test_readme_y_dotfiles_no_cuentan(), test_source_mas_nuevo_marca_desactualizado(), _esta_desactualizado()

### Community 336 - "siAccionIA"
Cohesion: 0.24
Nodes (10): cablearSoloInformeIA(), siAccionIA(), siCargarIA(), siFijarTexto(), siMostrarPropuesta(), siPintarEstadoIA(), siPintarManuales(), siQuitarPropuesta() (+2 more)

### Community 338 - "abrirEstandares"
Cohesion: 0.33
Nodes (9): abrirEstandares(), aceptarEstandares(), cablearEstandares(), cambiarArchivoEstandares(), pintarEstandaresConfirmado(), pintarPreviewEstandares(), resetEstandaresUI(), subirEstandares() (+1 more)

### Community 339 - "test_plantilla_bcp.py"
Cohesion: 0.31
Nodes (7): _esqueleto_ok(), _sesion_chat(), test_entregable_pipeline_con_plantilla(), test_informe_web_con_plantilla(), test_plantilla_minima_y_anexos(), test_riesgo_desde_puntaje(), _texto()

### Community 340 - "crear_sesion"
Cohesion: 0.22
Nodes (5): cliente(), test_solo_revisor_aprueba(), test_sesion_caduca(), crear_sesion(), _ttl()

### Community 342 - "ui.js"
Cohesion: 0.33
Nodes (7): aplicarTema(), botonTema(), contar(), mejorarTabla(), opciones(), textoAcepta(), zona()

### Community 343 - "cablearValidacion"
Cohesion: 0.46
Nodes (8): actualizarEstadoUI(), cablearValidacion(), cancelarValidacion(), conectarWebSocket(), lanzarValidacion(), pintarLinea(), pintarPrecondiciones(), precondicionesValidacion()

### Community 344 - "subprocess"
Cohesion: 0.12
Nodes (7): _archivos(), _describir(), _limpiar(), main(), _html_versionados(), test_hay_html_que_revisar(), test_html_sin_cargas_externas()

### Community 351 - "verificar_corpus_rag.py"
Cohesion: 0.29
Nodes (5): _ficheros_esperados(), main(), _norm(), verificar_dominio(), verificar_informe()

### Community 352 - "word_estilo.py"
Cohesion: 0.06
Nodes (16): _add_field_block(), add_bloque_codigo(), add_codigo_inline(), aplicar_estilo_documento(), _asegurar_estilos_nota(), _asegurar_parte_footnotes(), _borde(), _FootnotesPart (+8 more)

### Community 353 - "test_chat_adjuntar.py"
Cohesion: 0.36
Nodes (6): _ctx(), _datos(), test_adjuntar_enriquece_evidencia_y_reevalua(), test_adjuntar_sin_texto_falla(), _correr(), adjuntar_evidencia()

### Community 354 - "IAFallo"
Cohesion: 0.20
Nodes (6): IAFallo, IANoConfigurada, _json(), _llamar(), _numeros(), _validar_spec()

## Knowledge Gaps
- **174 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `TestAuditoriaIntegral20260807` connect `Tests · Auditoría integral 2026-08-07` to `ClienteIA`, `BuscadorLexico`, `Skills · Regulatoria con RAG`, `.test_las_preguntas_de_un_fallo_tecnico_no_van_al_modelador`?**
  _High betweenness centrality (0.021) - this node is a cross-community bridge._
- **Are the 8 inferred relationships involving `main()` (e.g. with `diagnostico_https()` and `.generar()`) actually correct?**
  _`main()` has 8 INFERRED edges - model-reasoned connections that need verification._
- **Should `BaseSkill` be split into smaller, more focused modules?**
  _Cohesion score 0.036231884057971016 - nodes in this community are weakly interconnected._
- **Why does `IndexadorLexico` connect `RAG · Indexador léxico` to `test_gobierno_codigo.py`, `Tests · Índice RAG sin contaminación`, `Aislamiento entre clientes (tenant)`, `TestRagLexicoSinEmbeddingsNiHuggingFace`, `Tests · RAG léxico (recuperación)`, `BaseIndexer`, `BuscadorLexico`, `agente.py`, `Tests · Simulación de Azure (pipeline)`, `test_versionado.py`, `preguntas_oro_rag.py`, `ChunkerService`, `pathlib`, `TestAuditoriaConsistenciaCruzada`, `test_regresion.py`, `verificar_corpus_rag.py`?**
  _High betweenness centrality (0.020) - this node is a cross-community bridge._
- **Should `material_no_confiable` be split into smaller, more focused modules?**
  _Cohesion score 0.044148380355276906 - nodes in this community are weakly interconnected._
- **Why does `columns()` connect `columns` to `Control VaR · Kupiec`, `Control VaR · Semáforo de Basilea`, `Control ALM · Backtesting de prepago`, `Control ALM · Beta de depósitos`, `Control ALM · Brecha de duración`, `Control ALM · CPR de prepago`, `Control ALM · Decaimiento NMD`, `Control ALM · Sensibilidad NII`, `Control ALM · Escenarios IRRBB`, `Control ALM · Gap de reprecios`, `Control ALM · Vida media NMD`, `Control LaR · Brecha de liquidez`, `Control LaR · Concentración de fondeo`, `Control LaR · Horizonte de supervivencia`, `Control LaR · Composición HQLA`, `Control LaR · LCR`, `Control LaR · NSFR`, `Control transversal · Columnas constantes`, `Datos · Perfilado de datasets`, `Control transversal · Frescura`, `Control VaR · Excedencias`, `Control VaR · Severidad de excepciones`, `Control VaR · VaR negativos`?**
  _High betweenness centrality (0.019) - this node is a cross-community bridge._
- **Should `app.py` be split into smaller, more focused modules?**
  _Cohesion score 0.07832080200501253 - nodes in this community are weakly interconnected._