# Inventario de archivos — VIRF Agent

> Generado el 2026-11-18 por `scripts/generar_inventario_archivos.py` (no editar a mano: se regenera). Anexo de `GUIA_TRASPASO_CONTEXTO.md`.

Total listado: **590** archivos en **97** carpetas. Resumidos aparte: `graphify-out/` (23), `archivo/` (102).

Leyenda: las carpetas de datos (evidencia, corpus, fixtures, salidas) se resumen con su conteo por tipo; el código, las pruebas y los documentos se listan archivo a archivo.

## Raíz del proyecto

| Archivo | Qué es |
|---|---|
| `.env.example` |  |
| `.gitignore` |  |
| `.pre-commit-config.yaml` |  |
| `AUDITORIA_ANTIALUCINACION.md` | Auditoría anti-alucinación — VIRF Agent |
| `AUDITORIA_ENTORNO_CORPORATIVO.md` | Auditoría — Eliminación de dependencias externas y corrección del pipeline |
| `DESIGN.md` | DESIGN.md — VIRF Agent · capa visual «Sello institucional» |
| `FLAGS.md` | `agente.py` — Manual de referencia de flags |
| `FUNCIONALIDADES.md` | VIRF Agent — Catálogo completo de funcionalidades |
| `GUIA_CORPUS_RAG.md` | Guía para montar el corpus RAG y medir la calidad de la validación |
| `GUIA_INSTALACION.md` | Guía de instalación paso a paso — VIRF Agent |
| `GUIA_LLENAR_INPUTS.md` | Guía práctica: qué poner en `inputs/`, carpeta por carpeta |
| `GUIA_MIGRACION_ANTHROPIC_A_AZURE_OPENAI.md` | Guía de migración — Anthropic → Azure OpenAI |
| `GUIA_MULTIMODELO_Y_RAG.md` | Guía — Validar varios modelos y poblar el RAG |
| `GUIA_RAG_LEXICO.md` | Guía del RAG léxico de VIRF — cómo funciona, de verdad |
| `GUIA_TRASPASO_CONTEXTO.md` | Guía de traspaso de contexto — VIRF Agent (edición exhaustiva) |
| `HANDOFF_AGENTE.md` | Traspaso para el agente corporativo — VIRF |
| `INFORME_AUDITORIA_2026-07-29.md` | Auditoría técnica exhaustiva — VIRF Agent v27 |
| `INVENTARIO_ARCHIVOS.md` | Inventario de archivos — VIRF Agent |
| `MANUAL_TECNICO_VIRF.pdf` | documento |
| `METODOLOGIA_DEL_AGENTE.md` | Metodología del Agente VIRF |
| `PROCEDIMIENTO_VALIDACION.md` | Procedimiento de Validación Independiente de Modelos |
| `PROMPT_CONTINUIDAD.md` | Prompt de continuidad — VIRF Agent v27 |
| `PROMPT_CONTINUIDAD_2026-08-07.md` | Prompt de continuidad — VIRF Agent · 2026-08-07 |
| `PROMPT_CONTINUIDAD_2026-08-09.md` | Prompt de continuidad — VIRF Agent · 2026-08-09 |
| `PROMPT_CONTINUIDAD_2026-08-16.md` | PROMPT DE CONTINUIDAD — VIRF Web · fixes pendientes (2026-08-16) |
| `PROMPT_CONTINUIDAD_2026-08-28.md` | PROMPT DE CONTINUIDAD — VIRF Agent · 2026-08-28 |
| `QUE_HACE_REALMENTE.md` | VIRF Agent — qué hace realmente |
| `README.md` | VIRF Agent — Validador Autónomo de Modelos Financieros |
| `REFERENCIA_TECNICA.md` | Referencia técnica — VIRF Agent (generada del código) |
| `REMEDIACION_SEG.md` | Remediación SEG · Fases 1 a 4 |
| `ROADMAP_v28.md` | Roadmap v28 — Qué mejorar y cuánto cuesta |
| `RUNBOOK.md` | RUNBOOK — Validar un modelo de principio a fin |
| `SESION_2026-07-31_RAG_Y_SKILLS.md` | Traspaso de sesión — 2026-07-31 · RAG léxico, evaluador crítico y skills |
| `agente.py` | agente.py — Punto de entrada del agente VIRF PIPELINE 1: CALIDAD DE DATOS (nuevo - recomendado) python agente.py --titulo "Modelo LaR" --tier 1 --exc… |
| `create_estandares_excel.py` | Crear archivo Excel stub para Estandares_VIRF.xlsx ⚠️ NO forma parte del flujo VIRF activo (lectura → prompt → IA → score → informe). Script auxiliar… |
| `diagnostico_azure_virf.py` | diagnostico_azure_virf.py — diagnóstico por capas de la conexión con Azure OpenAI. .\.venv\Scripts\python.exe diagnostico_azure_virf.py .\.venv\Scrip… |
| `pytest.ini` |  |
| `requirements.txt` |  |
| `test_api_key.py` | test_api_key.py - Diagnóstico de la conexión con el proveedor de IA ACTIVO. Antes instanciaba el SDK de Anthropic directamente (saltándose el gateway… |
| `validate_project.py` | validate_project.py — Verificación de integridad del proyecto VIRF ═══════════════════════════════════════════════════════════════════════════════ Ej… |
| `verificador_virf.py` | verificador_virf.py — Verificador de Indicadores del VIRF Agent (WP-00). ════════════════════════════════════════════════════════════════════════════… |

## `.github/`

| Archivo | Qué es |
|---|---|
| `copilot-instructions.md` | VIRF Agent v27 — Instrucciones para Agentes de IA |

## `_respaldo_ui/20261118_antes_rediseno/static/css/`

| Archivo | Qué es |
|---|---|
| `styles.css` |  |

## `_respaldo_ui/20261118_antes_rediseno/static/js/`

| Archivo | Qué es |
|---|---|
| `app.js` |  |
| `guia.js` |  |

## `_respaldo_ui/20261118_antes_rediseno/templates/`

| Archivo | Qué es |
|---|---|
| `index.html` |  |

## `audit_logs/`

| Archivo | Qué es |
|---|---|
| `registro_emisiones.jsonl` |  |

## `config/`

| Archivo | Qué es |
|---|---|
| `__init__.py` | config/ [v27.2] ═════════════════════════════════════════════════════════════════════════════ CENTRAL DE CONFIGURACIÓN DEL AGENTE VIRF Este paquete s… |
| `cuestionamientos_activos.json` | datos JSON |
| `cuestionamientos_personalizados.json` | datos JSON |
| `dominio.py` | config/dominio.py [v27.2] ═════════════════════════════════════════════════════════════════════════════ Parámetros de NEGOCIO del marco VIRF: tiers, … |
| `ia.py` | config/ia.py [v27.2] ═════════════════════════════════════════════════════════════════════════════ Clientes IA: interfaz agnóstica de proveedor + fac… |
| `identidad.py` | config/identidad.py ═════════════════════════════════════════════════════════════════════════════ Identidad corporativa del validador y firma del inf… |
| `modelos.py` | config/modelos.py ═══════════════════════════════════════════════════════════════════════════════ CATÁLOGO DE MODELOS — parámetros óptimos por modelo… |
| `parametros.py` | config/parametros.py [v27.2] ═════════════════════════════════════════════════════════════════════════════ ÚNICA FUENTE DE VERDAD DE TODOS LOS PARÁME… |
| `red.py` | config/red.py ═════════════════════════════════════════════════════════════════════════════ Capa de RED: proxy, inspección TLS y reintento ante cuota… |
| `rutas.py` | config/rutas.py [v27.2] ═════════════════════════════════════════════════════════════════════════════ Rutas del proyecto. Única fuente de verdad de d… |
| `secretos.py` | config/secretos.py ═════════════════════════════════════════════════════════════════════════════ Único punto de lectura de CREDENCIALES (claves de IA… |
| `tools.py` | config/tools.py ═════════════════════════════════════════════════════════════════════════════ Catálogo de herramientas (tools) del agente con polític… |
| `virf_plus.py` | config/virf_plus.py ═════════════════════════════════════════════════════════════════════════════ VIRF PLUS — el agente principal (GPT) suma a Claude… |

## `diseno_ui/direcciones/`

| Archivo | Qué es |
|---|---|
| `A_sello_institucional.html` |  |
| `B_registro_tecnico.html` |  |
| `C_expediente_de_auditoria.html` |  |

## `docs/`

| Archivo | Qué es |
|---|---|
| `DESPLIEGUE_DATABRICKS.md` | Poner VIRF en Databricks — guía para tu primera vez en producción |
| `DESPLIEGUE_DATABRICKS.pdf` | documento |
| `FLUJO_AGENTE.md` | FLUJO DEL AGENTE — VIRF Agent (extremo a extremo) |
| `LOGIN_CORPORATIVO_WEB_V3.md` | Login con cuenta corporativa (Entra ID) — pasos para la web v3 |
| `PLAN_MAESTRO_VIRF.md` | PLAN MAESTRO DE ELEVACIÓN — VIRF AGENT |
| `como_aprende_el_agente.html` |  |
| `guia_crear_controles_repositorio.pdf` | documento |

## `docs/agente_corporativo/`

5 archivos — 1× `.docx`, 2× `.md`, 1× `.pdf`, 1× `.pptx`.

- `00_LEEME.md`
- `CONOCIMIENTO_VIRF.md`
- `GUIA_VIRF_AGENTE_CORPORATIVO.docx`
- `GUIA_VIRF_AGENTE_CORPORATIVO.pdf`
- `GUIA_VIRF_PRESENTACION.pptx`

## `docs/agente_corporativo/capturas/`

22 archivos — 22× `.jpg`.

## `docs/agente_corporativo/skills/`

12 archivos — 12× `.md`.

- `S01_diagnosticar_fallo.md`
- `S02_informes_word.md`
- `S03_regla_calificacion.md`
- `S04_web_pantallas_endpoints.md`
- `S05_proveedor_ia.md`
- `S06_estandar_validacion.md`
- `S07_rag_lexico.md`
- `S08_calidad_datos.md`
- `S09_evidencia_y_capturas.md`
- `S10_chat_sustentacion.md`
- `S11_usar_el_grafo.md`
- `S12_regenerar_guia_y_grafo.md`

## `docs/evidencia/`

27 archivos — 8× `.json`, 4× `.log`, 10× `.md`, 5× `.xml`.

## `docs/guias/`

| Archivo | Qué es |
|---|---|
| `guia-arquitectura-agente-financiero (1).md` | Guía de Arquitectura del Agente VIRF: Validación de Modelos Financieros con RAG Avanzado y Observabilidad |
| `guia-errores-loops-validacion-rag (1).md` | Guía Avanzada de Ingeniería para Agentes RAG: Diagnóstico de Errores, Verificación del Retrieval y Bucles de Autocorrección |
| `guia-integracion-skills-agente (1).md` | Guía de Integración y Conexión de Skills para el Agente de Validación Financiera (VIRF Agent) |

## `docs/seguridad/`

| Archivo | Qué es |
|---|---|
| `GOBIERNO_RIESGO_IA.md` | VIRF · Gobierno de riesgo de modelo IA (SEG-09) — BORRADOR |
| `sast_bandit.json` | datos JSON |
| `sca_pip_audit.json` | datos JSON |

## `ejemplos/`

8 archivos — 4× `.docx`, 4× `.pdf`.

- `Ejemplo_Informe_Pipeline_LaR.docx`
- `Ejemplo_Informe_Pipeline_LaR.pdf`
- `Ejemplo_Informe_Resultados_LaR.docx`
- `Ejemplo_Informe_Resultados_LaR.pdf`
- `Ejemplo_Informe_Web_LaR.docx`
- `Ejemplo_Informe_Web_LaR.pdf`
- `Ejemplo_Informe_Web_LaR_real_con_capturas.docx`
- `Ejemplo_Informe_Web_LaR_real_con_capturas.pdf`

## `evidencias/`

2 archivos — 2× `.html`.

- `como_aprende_el_agente.html`
- `informe_rag.html`

## `feedback/`

| Archivo | Qué es |
|---|---|
| `registro_validadores.json` | datos JSON |

## `gobierno/`

| Archivo | Qué es |
|---|---|
| `autonomia_agente.md` | Nivel de autonomía del agente |
| `backlog.csv` | tabla CSV |
| `catalogo_tools.md` | Catálogo de herramientas (tools) |
| `checklist_normativo.md` | Checklist normativo |
| `control_cambios.md` | Control de cambios |
| `despliegue.md` | Despliegue en ambiente aprobado |
| `evaluacion_privacidad.md` | Evaluación de privacidad |
| `frente_A_equivalencias.md` | Frente A · Pasos cerrados por los SEG |
| `go_no_go.md` | Checklist go / no-go a producción |
| `inventario_fuentes.csv` | tabla CSV |
| `mapa_integraciones.md` | Mapa de integraciones |
| `matriz_alcance.md` | Matriz de alcance funcional |
| `matriz_seleccion_llm.md` | Matriz de selección del LLM |
| `matriz_tarea_modelo.md` | Matriz tarea-modelo |
| `no_aplica.md` | Justificación de pasos «No aplica» |
| `perfiles_usuario.md` | Perfiles de usuario |
| `plan_industrializacion.md` | Plan de industrialización |
| `plan_mantenimiento.md` | Plan de mantenimiento y vulnerabilidades |
| `plan_marcha_blanca.md` | Plan de marcha blanca |
| `plantilla_cierre_piloto.md` | Informe de cierre del piloto (plantilla) |
| `raci.md` | RACI del agente |
| `reevaluacion_semestral.md` | Reevaluación periódica |
| `reporte_cierre_brechas.md` | Reporte de cierre de brechas — «Pasos Generales Agente 2» |
| `roadmap.md` | Roadmap (no bloqueante) |
| `soporte_incidentes.md` | Soporte e incidentes |

## `inputs/`

| Archivo | Qué es |
|---|---|
| `Estandares_VIRF.xlsx` | libro Excel |

## `inputs/calidad_datos/`

3 archivos — 2× `.md`, 1× `.xlsx`.

- `ControlesData.xlsx`
- `manual_controles_datos.md`
- `perfil_datos_LaR.md`

## `inputs/calidad_datos/datasets/`

2 archivos — 2× `.csv`.

- `data_subset.csv`
- `maestro_clientes.csv`

## `inputs/calidad_datos/resultadocalidad_de_datos/`

1 archivos — 1× `.xlsx`.

- `motores_calidad_2026-08-08.xlsx`

## `inputs/documentacion/modelamiento/`

2 archivos — 1× `.md`, 1× `.pdf`.

- `Manual_Metodologico_LaR_completo.pdf`
- `manual_metodologico_LaR.md`

## `inputs/documentacion/seguimiento/`

1 archivos — 1× `.md`.

- `informe_seguimiento_Q2_2026.md`

## `inputs/excel_procesos/`

3 archivos — 1× `.xlsm`, 2× `.xlsx`.

- `parametros.xlsx`
- `proceso_complejo.xlsm`
- `proceso_demo_mercado.xlsx`

## `inputs/implementacion/`

1 archivos — 1× `.md`.

- `implementacion_LaR.md`

## `inputs/logoempresa/`

| Archivo | Qué es |
|---|---|
| `Logo-bcp-vector.svg.webp` |  |

## `inputs/papers/`

1 archivos — 1× `.md`.

- `riskmetrics_summary.md`

## `inputs/rag/ALM/`

4 archivos — 1× `(sin ext.)`, 2× `.md`, 1× `.pdf`.

- `.gitkeep`
- `IRRBB_modelos_conductuales_NMD.pdf`
- `README.md`
- `seed_conceptos_conductuales.md`

## `inputs/rag/LaR/`

5 archivos — 1× `(sin ext.)`, 2× `.md`, 2× `.pdf`.

- `.gitkeep`
- `LCR_BCBS238_coeficiente_cobertura_liquidez.pdf`
- `NSFR_BCBS295_financiacion_estable.pdf`
- `README.md`
- `seed_conceptos_liquidez_LaR.md`

## `inputs/rag/VaR/`

6 archivos — 1× `(sin ext.)`, 3× `.md`, 2× `.pdf`.

- `.gitkeep`
- `FRTB_BCBS457_riesgo_mercado.pdf`
- `README.md`
- `backtesting_VaR_Kupiec_Christoffersen.pdf`
- `riskmetrics_summary.md`
- `seed_conceptos_riesgo_mercado_VaR.md`

## `inputs/rag/shared/`

6 archivos — 1× `(sin ext.)`, 2× `.md`, 3× `.pdf`.

- `.gitkeep`
- `BCBS_239_agregacion_datos_riesgo.pdf`
- `README.md`
- `SR_11-7_gestion_riesgo_modelo.pdf`
- `seed_gobernanza_validacion.md`
- `validacion_interna_expectativas_supervisoras_UE.pdf`

## `inputs/repositorio_controles/`

1 archivos — 1× `.md`.

- `README.md`

## `inputs/repositorio_controles/alm/`

11 archivos — 11× `.py`.

- `backtesting_prepago.py`
- `beta_deposito.py`
- `brecha_duracion.py`
- `cpr_prepago.py`
- `decaimiento_nmd.py`
- `delta_eve.py`
- `delta_nii.py`
- `escenarios_irrbb_completos.py`
- `gap_reprecios.py`
- `sot_eve_tier1.py`
- `vida_media_nmd.py`

## `inputs/repositorio_controles/lar/`

6 archivos — 6× `.py`.

- `brecha_liquidez_acumulada.py`
- `concentracion_fondeo.py`
- `horizonte_supervivencia.py`
- `hqla_composicion.py`
- `lcr.py`
- `nsfr.py`

## `inputs/repositorio_controles/shared/`

5 archivos — 5× `.py`.

- `columnas_constantes.py`
- `completitud_datos.py`
- `duplicados_registros.py`
- `frescura_datos.py`
- `volumen_minimo.py`

## `inputs/repositorio_controles/var/`

7 archivos — 7× `.py`.

- `backtesting_excedencias.py`
- `christoffersen.py`
- `kupiec.py`
- `monotonia_niveles_var.py`
- `semaforo_basilea.py`
- `severidad_excepciones.py`
- `var_negativos.py`

## `inputs/usos/`

1 archivos — 1× `.md`.

- `uso_LaR_gestion.md`

## `modelos/VaR_FRTB/inputs/calidad_datos/`

1 archivos — 1× `.md`.

- `perfil_datos_VaR.md`

## `modelos/VaR_FRTB/inputs/calidad_datos/resultadocalidad_de_datos/`

1 archivos — 1× `.xlsx`.

- `motores_calidad_2026Q1.xlsx`

## `modelos/VaR_FRTB/inputs/documentacion/modelamiento/`

1 archivos — 1× `.md`.

- `manual_VaR_FRTB.md`

## `modelos/VaR_FRTB/inputs/documentacion/seguimiento/`

1 archivos — 1× `.md`.

- `backtesting_VaR_2026Q1.md`

## `modelos/VaR_FRTB/inputs/implementacion/`

1 archivos — 1× `.py`.

- `calcula_var.py`

## `modelos/VaR_FRTB/inputs/papers/`

1 archivos — 1× `.md`.

- `kupiec_1995_resumen.md`

## `modelos/VaR_FRTB/inputs/usos/`

1 archivos — 1× `.md`.

- `acta_comite_riesgos_2026Q1.md`

## `modelos/VaR_FixtureDrift/`

1 archivos — 1× `.md`.

- `LEEME.md`

## `modelos/VaR_FixtureDrift/inputs/documentacion/modelamiento/`

1 archivos — 1× `.md`.

- `manual_VaR_drift.md`

## `modelos/VaR_FixtureDrift/inputs/documentacion/seguimiento/`

1 archivos — 1× `.md`.

- `backtesting_2026Q1.md`

## `modelos/VaR_FixtureDrift/inputs/implementacion/`

1 archivos — 1× `.py`.

- `calcula_var.py`

## `modulos/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |
| `abstencion.py` | modulos/abstencion.py ═════════════════════════════════════════════════════════════════════════════ Compuerta de abstención activa (WP-01, indicador … |
| `adjuntos_ole.py` | modulos/adjuntos_ole.py — Archivos adjuntos INCRUSTADOS en un Word (python-docx). Un sustento puede ser un Excel, un Word, una presentación, un corre… |
| `aislamiento.py` | modulos/aislamiento.py ═════════════════════════════════════════════════════════════════════════════ Aislamiento multi-tenant por (tenant, modelo) — … |
| `almacenamiento.py` | modulos/almacenamiento.py ═════════════════════════════════════════════════════════════════════════════ Almacenamiento local de evidencia: clasificac… |
| `analisis_estatico.py` | modulos/analisis_estatico.py ═══════════════════════════════════════════════════════════════════════════════ QUÉ HACE EL CÓDIGO, LEÍDO DEL CÓDIGO — s… |
| `aprobacion_codigo.py` | modulos/aprobacion_codigo.py ═════════════════════════════════════════════════════════════════════════════ La IA nunca ejecuta su propio código sin a… |
| `auditoria.py` | modulos/auditoria.py ═════════════════════════════════════════════════════════════════════════════ Registro de auditoría de acciones: QUIÉN (identida… |
| `automatizaciones.py` | modulos/automatizaciones.py ═══════════════════════════════════════════════════════════════════════════════ Cuadro de observaciones a partir de los E… |
| `capturas.py` | Capturas de evidencia para los informes Word («pantallazos»), sin IA. El agente cita texto («Manual.pdf → "λ = 0.94"», contradicciones manual ↔ códig… |
| `chunker.py` | chunker.py Servicio de chunking inteligente para documentos largos. PROBLEMA QUE RESUELVE (v18 → v20) En v18/v19, `_chunked_summary()` vivía dentro d… |
| `chunker_estructural.py` | modulos/chunker_estructural.py ═════════════════════════════════════════════════════════════════════════════ Chunking ESTRUCTURAL por secciones (WP ·… |
| `clasificacion_docx.py` | modulos/clasificacion_docx.py ═════════════════════════════════════════════════════════════════════════════ Etiqueta de clasificación en el pie de TO… |
| `comparador.py` | modulos/comparador.py ═══════════════════════════════════════════════════════════════════════════════ COMPARACIÓN ENTRE CORRIDAS — qué cambió desde l… |
| `consola.py` | consola.py [v27.2] Salida de consola a prueba de codificación. PROBLEMA QUE RESUELVE El proyecto imprime emoji en 19 módulos (`📐 CHUNKING ADAPTATIVO`… |
| `consolidacion.py` | modulos/consolidacion.py ═════════════════════════════════════════════════════════════════════════════ Cierre HITL: convierte las decisiones del chat… |
| `control_evaluacion_data.py` | control_evaluacion_data.py ═════════════════════════════════════════════════════════════════════════════ ESTRUCTURAS Y UTILIDADES PARA CONTROL DE EVA… |
| `controles_a_notebook.py` | controles_a_notebook.py — Documento de controles de datos → Notebook + Brechas ══════════════════════════════════════════════════════════════════════… |
| `cuestionamientos_ext.py` | Catálogo extensible de cuestionamientos metodológicos. `Mx_04_MotorControlesData` importaba directamente `CUESTIONAMIENTOS_METODOLOGICOS` de `Mx_00` … |
| `custodia.py` | modulos/custodia.py ═══════════════════════════════════════════════════════════════════════════════ CADENA DE CUSTODIA — trazabilidad inmutable de lo… |
| `document_cache.py` | document_cache.py Sistema de memoria de documentos para modo pre-producción (MODO_PREPRDC). Propósito En cada corrida del agente, leer y parsear PDFs… |
| `entailment.py` | modulos/entailment.py ═════════════════════════════════════════════════════════════════════════════ Verificación SEMÁNTICA de citas (entailment / NLI… |
| `esquemas.py` | modulos/esquemas.py ═════════════════════════════════════════════════════════════════════════════ Contrato de salida TIPADO del validador (WP-09 · GA… |
| `estudio_insumos.py` | modulos/estudio_insumos.py ═══════════════════════════════════════════════════════════════════════════════ ESTUDIO DE LOS INSUMOS de la Validación co… |
| `evaluacion_experta.py` | modulos/evaluacion_experta.py ═════════════════════════════════════════════════════════════════════════════ Evaluación humana por expertos con rúbric… |
| `excel_a_notebook.py` | excel_a_notebook.py ═══════════════════════════════════════════════════════════════════════════════ INGENIERÍA INVERSA EXCEL → NOTEBOOK PYTHON Objeti… |
| `explicador_modelo.py` | explicador_modelo.py [v27.2] ═════════════════════════════════════════════════════════════════════════════ Genera `explicacion_del_modelo_<MODELO>.md… |
| `exportador_excel.py` | modulos/exportador_excel.py ═════════════════════════════════════════════════════════════════════════════ Exporta la tabla de validación a Excel (.xl… |
| `feedback.py` | modulos/feedback.py Gestión de feedback del validador sobre las evaluaciones del agente. Flujo: 1. Al final de cada corrida (--preprdc o --prdc), se … |
| `feedback_mejorado.py` | modulos/feedback_mejorado.py ════════════════════════════════════════════════════════════════════════════════ Sistema de feedback mejorado que REAPRE… |
| `fuentes_rag.py` | modulos/fuentes_rag.py [Paso 11 · norma 2135.010.02 §Carga de fuentes] ═════════════════════════════════════════════════════════════════════════════ … |
| `fusibles.py` | modulos/fusibles.py ═════════════════════════════════════════════════════════════════════════════ Cortacircuitos para bucles de razonamiento y ejecuc… |
| `generador_estadistica_feedback.py` | modulos/generador_estadistica_feedback.py Genera un informe Excel de precisión del agente basado en el historial de feedback. Se invoca con: python a… |
| `generador_markdown.py` | modulos/generador_markdown.py ═════════════════════════════════════════════════════════════════════════════ Informe de validación en Markdown: el BOR… |
| `generador_word.py` | modulos/generador_word.py Genera VIRF_Informe_*.docx — Informe de validación en formato PLANO y legible Estructura simplificada del informe: 1. Porta… |
| `huella_informe.py` | modulos/huella_informe.py ═══════════════════════════════════════════════════════════════════════════════ PRIMITIVAS DE HUELLA DE UN INFORME — hash c… |
| `huella_prompts.py` | modulos/huella_prompts.py ═══════════════════════════════════════════════════════════════════════════════ TRAZABILIDAD DEL PROMPT — qué se le pregunt… |
| `instrucciones_sesion.py` | Lectura de instrucciones extra (skills + cuestionamientos NL) que la web deja en la raíz de la sesión (v2 · cableado al motor). Contrato: - La web es… |
| `inyeccion.py` | modulos/inyeccion.py ═════════════════════════════════════════════════════════════════════════════ Defensa contra INYECCIÓN DE INSTRUCCIONES en la ev… |
| `motor_ia.py` | modulos/motor_ia.py Orquestador principal del agente VIRF. Financial Controller / Model Risk Validator — LaR, VaR, Conductuales. ARQUITECTURA DE ORQU… |
| `motor_ia_v2.py` | modulos/motor_ia_v2.py Orquestador principal del pipeline VIRF por CONTROL. Este módulo coordina el flujo end-to-end: 1. Cargar configuración de cont… |
| `motores_datos.py` | motores_datos.py — Catálogo de pruebas de calidad de datos ═══════════════════════════════════════════════════════════════════════════════ QUÉ ES El … |
| `motores_entidad.py` | modulos/motores_entidad.py Lectura de los resultados de los motores de calidad de datos DE LA ENTIDAD. QUÉ ES El validador escribe sus propios motore… |
| `notebook_controles.py` | modulos/notebook_controles.py ═════════════════════════════════════════════════════════════════════════════ Genera un .ipynb ENTREGABLE de controles … |
| `observabilidad.py` | modulos/observabilidad.py ═════════════════════════════════════════════════════════════════════════════ Dataset operativo y reporte de costes a parti… |
| `override_humano.py` | modulos/override_humano.py ═══════════════════════════════════════════════════════════════════════════════ REPORTE DE HUMAN OVERRIDE — dónde el valid… |
| `perfilador_datasets.py` | modulos/perfilador_datasets.py ═══════════════════════════════════════════════════════════════════════════════ PERFILADO DE DATASETS — el esquema com… |
| `pickle_firmado.py` | modulos/pickle_firmado.py [SEG-09 · tratamiento de SAST B301] ═════════════════════════════════════════════════════════════════════════════ `pickle.l… |
| `pii.py` | modulos/pii.py ═════════════════════════════════════════════════════════════════════════════ Enmascarado DETERMINISTA de datos personales (PII) en la… |
| `plantilla_bcp.py` | Plantilla común de los informes Word de VIRF (estética «Informe de Resultados»). La usan los TRES informes —Solo Informe, «Generar informe» de la web… |
| `prevuelo.py` | modulos/prevuelo.py ═══════════════════════════════════════════════════════════════════════════════ PRE-VUELO DE LA EVIDENCIA — qué se va a poder lee… |
| `registro_emisiones.py` | modulos/registro_emisiones.py ═══════════════════════════════════════════════════════════════════════════════ REGISTRO APPEND-ONLY DE EMISIONES — con… |
| `reglas_informe.py` | Reglas puras de calificación de los informes VIRF: conclusión global y estado por control. Las usan los TRES informes Word (Solo Informe, «Generar in… |
| `reporte_docx.py` | modulos/reporte_docx.py ═════════════════════════════════════════════════════════════════════════════ Reporte `.docx` estructurado desde un Validatio… |
| `repositorio_controles.py` | modulos/repositorio_controles.py ═════════════════════════════════════════════════════════════════════════════ REPOSITORIO de controles de datos ESCR… |
| `revision_codigo.py` | modulos/revision_codigo.py ═══════════════════════════════════════════════════════════════════════════════ REVISIÓN DEL CÓDIGO CONTRA LA DOCUMENTACIÓ… |
| `salida_ia.py` | modulos/salida_ia.py ═════════════════════════════════════════════════════════════════════════════ Saneado de lo que sale hacia la IA (SEG-05). Módul… |
| `salvaguardas_llm.py` | modulos/salvaguardas_llm.py ═════════════════════════════════════════════════════════════════════════════ Robustez del LLM (OWASP Top 10 LLM: LLM09 «… |
| `validacion_completa.py` | modulos/validacion_completa.py ═══════════════════════════════════════════════════════════════════════════════ VALIDACIÓN COMPLETA: cinco chats espec… |
| `validador_citas.py` | modulos/validador_citas.py ═════════════════════════════════════════════════════════════════════════════ Validador DETERMINISTA de citas con id de li… |
| `validador_humano.py` | modulos/validador_humano.py ═══════════════════════════════════════════════════════════════════════════════ FIRMA Y RESPONSABILIDAD DEL VALIDADOR HUM… |
| `ventana_contexto.py` | modulos/ventana_contexto.py ═════════════════════════════════════════════════════════════════════════════ Resolución de la ventana de contexto real d… |
| `verificacion_cifras.py` | modulos/verificacion_cifras.py — avisos deterministas sobre lo que afirma el modelo. ════════════════════════════════════════════════════════════════… |
| `versionado.py` | modulos/versionado.py ═════════════════════════════════════════════════════════════════════════════ Versionado temporal de chunks/estándares (WP-10 ·… |
| `word_estilo.py` | modulos/word_estilo.py Infraestructura de presentación del informe Word. Reutilizable: aquí vive el CÓMO se ve el documento, no QUÉ dice. `generador_… |

## `modulos/skills/`

| Archivo | Qué es |
|---|---|
| `__init__.py` | modulos/skills/ ═════════════════════════════════════════════════════════════════════════════ Skills de validación: análisis transversales sobre la e… |
| `base.py` | modulos/skills/base.py ═════════════════════════════════════════════════════════════════════════════ Infraestructura común de las skills de validació… |
| `catalogo.py` | modulos/skills/catalogo.py ═════════════════════════════════════════════════════════════════════════════ Las ocho skills de validación. CRITERIO DE S… |

## `motor/`

| Archivo | Qué es |
|---|---|
| `Mx_00_CargaRutas.py` | Mx_00_CargaRutas.py Configuración central del Motor VIRF. Define rutas, parámetros de la API, constantes del dominio y el rol del agente como Auditor… |
| `Mx_01_LecturaEvidencias.py` |  |
| `Mx_02_EstructuraPrompt.py` | Mx_02_EstructuraPrompt.py Construcción de todos los prompts que se envían al modelo de IA activo. Cada función devuelve el string listo para usar com… |
| `Mx_03_LlamarIA.py` | Mx_03_LlamarIA.py Capa de comunicación con la API del proveedor de IA activo. El proveedor concreto (Anthropic, Azure OpenAI…) lo resuelve `config/ia… |
| `Mx_04_MotorControlesData.py` | Mx_04_MotorControlesData.py Motor de controles de calidad automatizados sobre datos. Responsabilidades: - Ejecutar controles automáticos: unicidad, i… |
| `__init__.py` |  |

## `observabilidad/`

| Archivo | Qué es |
|---|---|
| `ESPECIFICACION_DASHBOARD.md` | Especificación del dashboard operativo |

## `pruebas/`

| Archivo | Qué es |
|---|---|
| `matriz_casos_borde.md` | Matriz de casos borde |
| `matriz_funcional.md` | Matriz de pruebas funcionales |
| `rubrica_experta.md` | Rúbrica de evaluación por expertos |
| `test_calidad_e2e.py` | Pasos 42 · 60 · 63 · 65 — métricas de calidad, rúbrica sellada y E2E sintético. |
| `test_casos_borde.py` | Paso 64 · Casos borde de la lectura de evidencia (matriz: pruebas/matriz_casos_borde.md). Regla común: el lector NUNCA lanza, NUNCA inventa contenido… |

## `pruebas/calidad/`

| Archivo | Qué es |
|---|---|
| `README.md` | Calidad del agente (Modelo de Evaluación de Validez) |
| `evaluacion.py` | pruebas/calidad/evaluacion.py ═════════════════════════════════════════════════════════════════════════════ Métricas de calidad del agente, con resul… |

## `pruebas/e2e/`

| Archivo | Qué es |
|---|---|
| `e2e_sintetico.py` | pruebas/e2e/e2e_sintetico.py ═════════════════════════════════════════════════════════════════════════════ Recorrido extremo a extremo con datos SINT… |

## `pruebas/kit_qa_sonnet/`

| Archivo | Qué es |
|---|---|
| `README.md` | Kit de pruebas QA (sintético) · MCR_Cuenta_Corriente |
| `RESULTADOS_QA.md` | Resultados QA · VIRF (servidor de prueba :8010) |
| `_fijo.md` | Fallos |
| `generar_informe.py` | Convierte resultados_qa.json en RESULTADOS_QA.md (tabla + secciones fijas). |
| `generar_kit.py` | Genera el kit de documentos de prueba (banco ficticio, modelo MCR_Cuenta_Corriente). Uso: .venv/Scripts/python.exe pruebas/kit_qa_sonnet/generar_kit.… |
| `qa_endpoints.py` | Driver QA por HTTP de VIRF (servidor de prueba ya levantado en :8010). Uso: .venv/Scripts/python.exe pruebas/kit_qa_sonnet/qa_endpoints.py Regla: NUN… |
| `qa_rag_dominio.py` | QA del RAG con un dominio de prueba (no toca LaR/VaR/ALM/shared): crear dominio → subir los papers del kit (/api/inputs/upload?destino=rag_<id>) → re… |
| `resultados_qa.json` | datos JSON |

## `pruebas/kit_qa_sonnet/datos/`

| Archivo | Qué es |
|---|---|
| `clientes.csv` | tabla CSV |
| `saldos.csv` | tabla CSV |

## `pruebas/kit_qa_sonnet/descargas/`

| Archivo | Qué es |
|---|---|
| `00_DiagnosticoITER0.ipynb` |  |
| `01_ControlDatosITER0.ipynb` |  |
| `02_ModelamientoITER0.ipynb` |  |
| `03_ImpactosITER0.ipynb` |  |
| `04_SeguimientoITER0.ipynb` |  |
| `VIRF_Informe_QA_SONNET_031769_V1_18112026.docx` | documento |

## `pruebas/kit_qa_sonnet/estandares/`

| Archivo | Qué es |
|---|---|
| `Estandares_VIRF.xlsx` | libro Excel |
| `Estandares_VIRF_erratas.xlsx` | libro Excel |
| `no_es_estandar.xlsx` | libro Excel |

## `pruebas/kit_qa_sonnet/imagenes/`

| Archivo | Qué es |
|---|---|
| `captura_1.png` |  |
| `captura_2.png` |  |

## `pruebas/kit_qa_sonnet/manuales/`

| Archivo | Qué es |
|---|---|
| `Manual_Extraccion_Controles_Datos.md` | Manual de extracción y controles de datos |
| `Manual_Metodologico_MCR_CC.docx` | documento |
| `Manual_Metodologico_MCR_CC.md` | Manual metodológico · MCR_Cuenta_Corriente v3.2 |
| `Manual_Seguimiento_MCR_CC.md` | Manual de seguimiento · MCR_Cuenta_Corriente |
| `Manual_Seguimiento_MCR_CC.pdf` | documento |

## `pruebas/kit_qa_sonnet/primera_linea/`

| Archivo | Qué es |
|---|---|
| `00_Diagnostico.xlsx` | libro Excel |
| `01_ControlDatos.xlsx` | libro Excel |
| `02_Modelamiento.xlsx` | libro Excel |
| `03_Impactos.xlsx` | libro Excel |
| `ITER1_resultado_00.xlsx` | libro Excel |
| `ITER1_resultado_01.xlsx` | libro Excel |
| `ITER1_resultado_02.xlsx` | libro Excel |
| `ITER1_resultado_03.xlsx` | libro Excel |
| `ITER1_resultado_04.xlsx` | libro Excel |
| `Resultado_notebook_primera_linea.xlsx` | libro Excel |

## `pruebas/kit_qa_sonnet/rag_papers/`

| Archivo | Qué es |
|---|---|
| `paper_calibracion_pd.md` | Calibración de probabilidades de default |
| `paper_gini_ks.pdf` | documento |
| `paper_liquidez_basilea.md` | Gestión del riesgo de liquidez y el ratio LCR |
| `paper_psi_estabilidad.txt` |  |

## `pruebas/kit_qa_sonnet/scripts/`

| Archivo | Qué es |
|---|---|
| `calibracion.ipynb` |  |
| `etl_modelo_cc.py` | ETL del modelo MCR_Cuenta_Corriente (sintético). |
| `extraccion.sql` |  |

## `pruebas/seguridad/`

| Archivo | Qué es |
|---|---|
| `README.md` | Pruebas de seguridad (OWASP Top 10 LLM) |
| `test_owasp_llm.py` | Paso 62 · Suite red-team alineada a OWASP Top 10 para aplicaciones LLM. Corre contra el gateway real (SEG-05) y los controles reales. Un caso que pas… |

## `scripts/`

| Archivo | Qué es |
|---|---|
| `auditar_cobertura_rag.py` | scripts/auditar_cobertura_rag.py ═══════════════════════════════════════════════════════════════════════════════ ¿Contra qué actividades del estándar… |
| `escanear_secretos.py` | scripts/escanear_secretos.py ═════════════════════════════════════════════════════════════════════════════ Escaneo de credenciales en el repositorio.… |
| `explicar_rag.py` | scripts/explicar_rag.py ═══════════════════════════════════════════════════════════════════════════════ Abre el RAG léxico en canal: enseña, paso a p… |
| `generar_corpus_rag.py` | scripts/generar_corpus_rag.py ═══════════════════════════════════════════════════════════════════════════════ Genera un corpus de LITERATURA DE REFER… |
| `generar_guia_agente.py` | scripts/generar_guia_agente.py — Guía de VIRF para el agente corporativo (DOCX y PDF). Genera `docs/agente_corporativo/GUIA_VIRF_AGENTE_CORPORATIVO.d… |
| `generar_inventario_archivos.py` | scripts/generar_inventario_archivos.py — Inventario de TODOS los archivos del proyecto. Genera `INVENTARIO_ARCHIVOS.md`: una línea por archivo con su… |
| `generar_inventario_fuentes.py` | scripts/generar_inventario_fuentes.py Regenera gobierno/inventario_fuentes.csv desde el corpus RAG (inputs/rag/) y el registro de dueños/vigencias (g… |
| `generar_observabilidad.py` | scripts/generar_observabilidad.py Genera el dataset del dashboard operativo y el reporte de costes desde la bitácora de auditoría: python scripts/gen… |
| `generar_presentacion_guia.py` | scripts/generar_presentacion_guia.py — Presentación (.pptx) «Guía de la herramienta VIRF». Genera `docs/agente_corporativo/GUIA_VIRF_PRESENTACION.ppt… |
| `generar_referencia_tecnica.py` | scripts/generar_referencia_tecnica.py — Referencia técnica EXACTA, leída del código. Genera `REFERENCIA_TECNICA.md`: lo que una persona (o una IA) ne… |
| `pipeline_calidad_datos.py` | scripts/pipeline_calidad_datos.py Pipeline de calidad de datos DEL VALIDADOR. Genera la tabla que el agente lee. python scripts/pipeline_calidad_dato… |
| `preguntas_oro_formula.py` | scripts/preguntas_oro_formula.py ═════════════════════════════════════════════════════════════════════════════ Golden set DISCRIMINANTE de fórmula/ta… |
| `preguntas_oro_rag.py` | scripts/preguntas_oro_rag.py Set de preguntas-oro del RAG léxico: ¿recupera el corpus el documento correcto? python scripts/preguntas_oro_rag.py # in… |
| `rebuild_rag_databricks.py` | scripts/rebuild_rag_databricks.py Script de mantenimiento para reconstruir los índices RAG en Databricks. CUÁNDO EJECUTAR: - Mensualmente (Databricks… |
| `reconstruir_estandar_desde_informes.py` | scripts/reconstruir_estandar_desde_informes.py ═══════════════════════════════════════════════════════════════════════════════ Reconstruye inputs/Est… |
| `verificar_corpus_rag.py` | scripts/verificar_corpus_rag.py ═══════════════════════════════════════════════════════════════════════════════ VERIFICADOR DEL CORPUS RAG — ¿el índi… |
| `verificar_remoto_git.py` | scripts/verificar_remoto_git.py ═════════════════════════════════════════════════════════════════════════════ Comprueba que TODOS los remotos git apu… |
| `web_prueba.py` | scripts/web_prueba.py — arranca la web v2 en MODO PRUEBA con «usuario libre». python scripts/web_prueba.py # http://127.0.0.1:8000 python scripts/web… |

## `skills/`

| Archivo | Qué es |
|---|---|
| `__init__.py` | skills/ — Fundación tipada de las 6 skills de la guía (function calling) ════════════════════════════════════════════════════════════════════════════… |
| `base_tipada.py` | skills/base_tipada.py — Contrato base tipado de una skill (function calling) ════════════════════════════════════════════════════════════════════════… |
| `calidad_datos.py` | skills/calidad_datos.py — Skill 2 (Calidad de Datos), determinista, en sandbox ══════════════════════════════════════════════════════════════════════… |
| `cola_pendiente.py` | skills/cola_pendiente.py — Cola PENDIENTE (Human-in-the-loop) ═════════════════════════════════════════════════════════════════════════════ Antipatró… |
| `documentacion.py` | skills/documentacion.py — Skill 1 (Documentación / Auditoría Documental) ════════════════════════════════════════════════════════════════════════════… |
| `gobierno.py` | skills/gobierno.py — Skill 4 (Gobierno / Compliance & Risk Tiering) ═════════════════════════════════════════════════════════════════════════════ DEC… |
| `implementacion.py` | skills/implementacion.py — Skill 5 (Implementación / Auditoría de Código) ═══════════════════════════════════════════════════════════════════════════… |
| `metodologia.py` | skills/metodologia.py — Skill 3 (Metodología / RAG Metodológico) ═════════════════════════════════════════════════════════════════════════════ DECLAR… |
| `uso.py` | skills/uso.py — Skill 6 (Uso / Análisis de Canales Operativos) ═════════════════════════════════════════════════════════════════════════════ DECLARAD… |

## `src/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |

## `src/rag/`

| Archivo | Qué es |
|---|---|
| `README.md` | RAG — Recuperación por Dominio Financiero |
| `__init__.py` | src/rag/__init__.py Dispatcher del sistema RAG segmentado por dominio financiero. Uso: from src.rag import get_retriever retriever = get_retriever(ti… |
| `base_indexer.py` | src/rag/base_indexer.py ════════════════════════════════════════════════════════════════════════════ Clase base para indexadores de todos los dominio… |
| `base_retriever.py` | src/rag/base_retriever.py ════════════════════════════════════════════════════════════════════════════ Clase base para retrievers de todos los domini… |
| `buscador_lexico.py` | src/rag/buscador_lexico.py ═════════════════════════════════════════════════════════════════════════════ Consulta el índice léxico de un dominio y de… |
| `config_rag.py` | src/rag/config_rag.py ═════════════════════════════════════════════════════════════════════════════ Parámetros del RAG LÉXICO (BM25 + TF-IDF). Sin em… |
| `custom_retriever.py` | src/rag/custom_retriever.py ════════════════════════════════════════════════════════════════════════════ Retriever + indexer para dominios RAG PERSON… |
| `indexador_lexico.py` | src/rag/indexador_lexico.py ═════════════════════════════════════════════════════════════════════════════ Construye y persiste el índice LÉXICO (BM25… |
| `tesauro.py` | src/rag/tesauro.py ═════════════════════════════════════════════════════════════════════════════ Tesauro de dominio: los sinónimos que la búsqueda lé… |

## `src/rag/ALM/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |
| `indexer.py` | src/rag/ALM/indexer.py Indexador RAG para el dominio ALM (modelos conductuales: prepago, retiro de depósitos, NMD; IRRBB). Indexa manuales conductual… |
| `retriever.py` | src/rag/ALM/retriever.py Retriever RAG para el dominio ALM (modelos conductuales: prepago, supervivencia/ retiro de depósitos, NMD, IRRBB). Recupera … |

## `src/rag/LaR/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |
| `indexer.py` | src/rag/LaR/indexer.py Indexador RAG para modelos de Liquidity at Risk (LaR). Qué indexa: - inputs/documentacion/modelamiento/ ← Manuales metodológic… |
| `retriever.py` | src/rag/LaR/retriever.py Retriever RAG para modelos de Liquidity at Risk (LaR). Uso en motor_ia.py (dentro de evaluar_actividad): from src.rag.LaR.re… |

## `src/rag/VaR/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |
| `indexer.py` | src/rag/VaR/indexer.py Indexador RAG para modelos de Value at Risk (VaR). Indexa manuales metodológicos VaR, papers FRTB/Basilea III y backtesting. H… |
| `retriever.py` | src/rag/VaR/retriever.py Retriever RAG para modelos de Value at Risk (VaR). Recupera contexto de riesgo de mercado (FRTB, Basilea III, Kupiec) para e… |

## `src/rag/shared/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |
| `indexer.py` | src/rag/shared/indexer.py Indexador RAG de conocimiento regulatorio compartido (transversal a todos los dominios). Indexa: SR 11-7, EBA/GL/2023/01, B… |
| `retriever.py` | src/rag/shared/retriever.py Retriever de conocimiento regulatorio compartido. Fallback cuando el dominio del modelo no tiene índice específico. Uso: … |

## `tests/`

| Archivo | Qué es |
|---|---|
| `_arbol.py` | Ayudas para los tests que RECORREN el árbol del proyecto. Por qué existe: varios tests filtraban los entornos virtuales por NOMBRE (`venv`, `.venv`).… |
| `conftest.py` | tests/conftest.py ═══════════════════════════════════════════════════════════════════════════════ Aislamiento del estado mutable del proyecto durante… |
| `test_abstencion.py` | tests/test_abstencion.py — WP-01 · indicador D3. Verifica la compuerta de abstención activa (modulos/abstencion.py) de forma DETERMINISTA y SIN API: … |
| `test_acta_cierre.py` | Pruebas del ACTA DE CIERRE en Excel (3 hojas) generada al finalizar el chat. Coste 0: no llama al LLM; usa datos sintéticos y consolidación determini… |
| `test_adjuntos_ole.py` | tests/test_adjuntos_ole.py — Archivos incrustados en el Word con su icono (modulos/adjuntos_ole.py). Sin coste y sin Microsoft Word: el fichero compu… |
| `test_aislamiento.py` | tests/test_aislamiento.py — WP-02 reducido · indicador D2. Verifica el aislamiento multi-tenant (modulos/aislamiento.py) de forma DETERMINISTA y SIN … |
| `test_almacenamiento.py` | SEG-06 · Almacenamiento local. · Sin clasificación no se sube nada; Restringido en el portátil se rechaza. · La caché de documentos está cifrada: ile… |
| `test_antialucinacion_brechas.py` | tests/test_antialucinacion_brechas.py — auditoría anti-alucinación (2026-11-18). Cada prueba fija una brecha que se encontró y se cerró. Coste 0: nin… |
| `test_aprendizaje_chat.py` | tests/test_aprendizaje_chat.py — WP-D: el chat guarda correcciones como feedback (contexto + ajuste automático en futuras corridas). Coste 0; histori… |
| `test_arbol_entornos.py` | Los recorridos del árbol deben reconocer un entorno virtual por `pyvenv.cfg`, no por su nombre. Con el filtro por nombre, un entorno llamado `env/` o… |
| `test_auditoria.py` | SEG-12 · Auditoría de acciones web. Cada acción sensible produce EXACTAMENTE una entrada con quién, qué, cuándo, desde dónde y resultado; el log es s… |
| `test_automatizaciones.py` | tests/test_automatizaciones.py ═══════════════════════════════════════════════════════════════════════════════ Cuadro de observaciones desde los Exce… |
| `test_azure_mocks.py` | tests/test_azure_mocks.py ═══════════════════════════════════════════════════════════════════════════════ Verificación del flujo completo con Azure O… |
| `test_beta_calibracion.py` | tests/test_beta_calibracion.py — β de abstención calibrado por datos (Día 2). β se fijó (config.ABSTENCION_BETA) desde la distribución de `cobertura`… |
| `test_capturas.py` | Capturas de evidencia para los informes («pantallazos»). Coste cero: sin IA; los PDF se generan al vuelo con Pillow y todo vive en `tmp_path`. Cubre:… |
| `test_chat_adjuntar.py` | tests/test_chat_adjuntar.py — WP-C: adjuntar evidencia en el chat → re-evaluar. Coste 0: usa el mock del chat (VIRF_MOCK_CHAT=1), no llama al modelo. |
| `test_chunker_estructural.py` | tests/test_chunker_estructural.py — chunking estructural (GAP-29). Verifica que la segmentación estructural (modulos/chunker_estructural.py) respeta … |
| `test_circuit_breakers.py` | tests/test_circuit_breakers.py — WP-05 · indicador D6. Verifica el cortacircuitos (modulos/fusibles.py) de forma DETERMINISTA y SIN API: el reloj se … |
| `test_citas_deterministas.py` | tests/test_citas_deterministas.py — WP-03/WP-04 · indicador D4 (parte determinista). Verifica el validador de citas con id de linaje (modulos/validad… |
| `test_clasificacion_docx.py` | SEG-10 · Clasificación de informes: ningún Word sale sin la etiqueta «Datos elaborados por BCP para uso Interno» en el pie de todas sus secciones. |
| `test_consolidacion.py` | tests/test_consolidacion.py ═══════════════════════════════════════════════════════════════════════════════ Cierre HITL: el chat produce el puntaje E… |
| `test_corrida_fallida.py` | tests/test_corrida_fallida.py — una corrida que no puede evaluar lo dice. Reproducido el 2026-11-11 lanzando `agente.py` con una clave rechazada (401… |
| `test_costes.py` | Pasos 54 · 56 · 57 — coste por llamada en la bitácora y reporte por corrida/usuario. |
| `test_credenciales.py` | SEG-03 · Credenciales. · Ningún endpoint web acepta una clave y nada en web/ escribe el `.env`. · Las claves solo se leen vía config/secretos.py (Key… |
| `test_databricks_minimo_dato.py` | SEG-14 · Databricks: identidad de servicio y mínimo dato necesario. · Ninguna lectura de Unity Catalog trae la tabla completa: columnas declaradas + … |
| `test_deteccion_proveedor.py` | tests/test_deteccion_proveedor.py — basta con poner la clave (2026-11-11). Fija tres cosas, todas con dobles (coste 0, sin red): 1. Fuera de producci… |
| `test_diagnostico_azure.py` | Diagnóstico por capas de la conexión con Azure OpenAI (sin red real). |
| `test_documentacion_consistente.py` | SEG-13 · Una sola verdad entre código, manual y CONOCIMIENTO. · Defaults EN CÓDIGO: MODO=produccion e IA_PROVEEDOR=azure_openai. · La guía generada l… |
| `test_docx_regresion.py` | tests/test_docx_regresion.py — WP-08 (estructura): reporte .docx desde ValidationReport mock. Sin API (no usa el pipeline real). Verifica las 4 secci… |
| `test_ejecucion_codigo.py` | SEG-07 · Ejecución de código. · No existe exec/eval/compile(…, "exec") en el código de producción (AST). · META se lee con AST: un control con código… |
| `test_endpoint_notebook_controles.py` | Prueba del endpoint GET /api/motores/notebook (coste 0: LLM interceptado). Sobrescribe la dependencia de sesión con un contexto de prueba y verifica … |
| `test_entailment.py` | Verificación semántica de citas (modulos/entailment.py) — SIN API. Se inyecta un cliente falso (no toca ningún proveedor): coste 0. Lo que se fija: ·… |
| `test_esquemas.py` | tests/test_esquemas.py — contrato Pydantic ValidationReport (WP-09). Verifica que un dict correcto produce un ValidationReport válido y que uno malfo… |
| `test_estandares_sesion.py` | Tests del paso 02 · Estándares de validación por sesión (WEB-V2.4). Cubre: - Parseo del .xlsx con celdas combinadas simulando ámbito/control merged. … |
| `test_estructura_config.py` | tests/test_estructura_config.py ═══════════════════════════════════════════════════════════════════════════════ Estructura de config/ y preparación p… |
| `test_estudio_insumos.py` | Estudio de insumos (manuales, Excels de primera línea, scripts) para la Validación completa: lectura ÍNTEGRA por partes, .zip, caché por huella, modo… |
| `test_exportador_excel.py` | tests/test_exportador_excel.py — Excel de la tabla de validación (WP-B). Coste 0. |
| `test_fallos_qa_sonnet.py` | Regresiones de los fallos que encontró el QA con Sonnet (pruebas/kit_qa_sonnet): F1 /api/cuestionamientos/* escribía config global sin sesión ni rol.… |
| `test_gateway_ia.py` | SEG-05 · Punto único de salida a IA. Fija dos cosas: 1. ARQUITECTURA — los SDK de proveedor solo se importan en config/ia.py; todo cliente concreto t… |
| `test_gobierno_codigo.py` | Brechas «Pasos Generales Agente 2» con código: 3, 11, 15, 20, 25, 43, 49. Los documentos de gobierno deben coincidir con el código (no pueden derivar… |
| `test_gobierno_ia.py` | SEG-09 · Gobierno de riesgo de modelo IA y tratamiento de SAST/SCA. · Los índices RAG (pickle) solo se deserializan con firma HMAC válida. · No queda… |
| `test_guia_agente.py` | Guía del agente corporativo (scripts/generar_guia_agente.py + docs/agente_corporativo/). Coste cero: sin IA y sin Word (el PDF no se genera en los te… |
| `test_guia_progreso.py` | tests/test_guia_progreso.py — Paso 01 de la guía de la web (/api/guia/progreso). [SEG-01/03] La guía solo da el paso 01 por hecho si el proveedor est… |
| `test_identidad.py` | SEG-02 · Identidad y firma. · Sin sesión → 401 en la web y el pipeline no firma. · El firmante = identidad autenticada (aserción firmada), nunca un n… |
| `test_informe_tabla_final.py` | tests/test_informe_tabla_final.py — la tabla final se cablea al .docx. Coste 0. |
| `test_invariante_asyncio.py` | Invariante: ninguna `asyncio.create_task(...)` puede quedar como sentencia suelta. El event loop solo guarda referencias DÉBILES a las tareas; una ta… |
| `test_inyeccion.py` | Defensa anti-inyección de instrucciones (modulos/inyeccion.py): alta precisión, 100% local. Neutraliza órdenes dirigidas al evaluador SIN mutilar pro… |
| `test_notebook_controles.py` | Pruebas API-free del generador de notebook de controles de datos (8 columnas). Construye el .ipynb desde una lista sintética de controles, EJECUTA su… |
| `test_pendientes_auditoria.py` | tests/test_pendientes_auditoria.py ═══════════════════════════════════════════════════════════════════════════════ Tests de los pendientes de auditor… |
| `test_pii.py` | Enmascarado PII (modulos/pii.py): alta precisión, 100% local, sin red. Lo que se fija: · SEG-04 — base PERUANA: DNI (8 díg., con/sin verificador, con… |
| `test_plantilla_bcp.py` | Plantilla común de los tres informes Word (Solo Informe, «Generar informe» de la web y entregable del pipeline). Coste cero: sin IA, todo en `tmp_pat… |
| `test_presentacion_guia.py` | tests/test_presentacion_guia.py — La presentación «Guía de la herramienta» se genera desde el repositorio y no se queda atrás cuando cambia el código… |
| `test_prompts_editables.py` | Tests de la capa de prompts editables por sesión y presupuesto dinámico (WEB-V2.3). Cubre: - PromptService.get_prompt: fallback base cuando no hay ov… |
| `test_proveedores_ia.py` | SEG-01 · Lista cerrada de proveedores de IA (decisión del banco, no reabrir): azure_openai = APROBADO · anthropic = EN_ESPERA · openai = RETIRADO Fij… |
| `test_rag_desactualizado.py` | tests/test_rag_desactualizado.py — el panel RAG avisa si el índice quedó obsoleto tras añadir manuales (cierra el footgun de «subí papers pero no rec… |
| `test_rag_lexico.py` | tests/test_rag_lexico.py ═════════════════════════════════════════════════════════════════════════════ Tests del RAG LÉXICO (BM25 + TF-IDF) que susti… |
| `test_recursos_externos.py` | SEG-15 · Recursos externos: ningún HTML versionado carga nada de la red (fuentes, scripts, hojas de estilo, imágenes). Deben funcionar sin red. Los n… |
| `test_regresion.py` | tests/test_regresion.py — Red de regresión del núcleo VIRF ═══════════════════════════════════════════════════════════════════════════════ Origen: cr… |
| `test_repositorio_corporativo.py` | SEG-11 · Repositorio de código: ninguna guía ni configuración apunta a nubes de código no autorizadas, y los remotos git solo pueden ser el repositor… |
| `test_requirements_web_fijados.py` | web/requirements_web.txt debe fijar versiones exactas (==), como requirements.txt. Con `>=` el Python del sistema y el .venv acabaron con FastAPI 0.1… |
| `test_roles.py` | SEG-08 · Roles y permisos + integridad del feedback. · validador ejecuta y deja feedback propio; admin_corpus gestiona el RAG compartido y los prompt… |
| `test_salvaguardas_llm.py` | SEG-16 · Robustez del LLM: afirmaciones sin respaldo no llegan al informe. Casos adversariales: inyección reformulada, cita inexistente, afirmación s… |
| `test_solo_informe.py` | Tests del apartado «Solo Informe» (informe sin pipeline). Coste cero: no hay IA en ningún punto del flujo, y todo escribe en `tmp_path`. Cubre: - Reg… |
| `test_solo_informe_ia.py` | Tests de la asistencia con IA de «Solo Informe». Coste cero: el modelo se sustituye por `_llm_de_prueba`, que registra el prompt y devuelve una respu… |
| `test_tabla_validacion.py` | tests/test_tabla_validacion.py ═══════════════════════════════════════════════════════════════════════════════ Veredicto formal por actividad + tabla… |
| `test_upload_zip.py` | POST /api/inputs/upload-zip — extracción segura de ZIP (coste 0, carpeta temporal). Fija: · un ZIP normal se extrae; · Zip Slip (`../`) se rechaza; ·… |
| `test_usuario_libre.py` | Usuario libre (web v2, modo prueba) — el SSO corporativo queda para la web v3. · Solo existe con VIRF_IDENTIDAD_PROVEEDOR=libre declarado y MODO≠prod… |
| `test_validacion_completa.py` | Validación completa: 5 chats (00–04). Cada iteración entrega un notebook {etapa}ITERn.ipynb que, ejecutado, genera {etapa}_resultadoITERn.xlsx. Coste… |
| `test_validador_entorno_hf.py` | Guardia de la política «cero HuggingFace / cero ChromaDB» (validate_project.py). Bug que fija: el chequeo del entorno usaba `import_module` dentro de… |
| `test_verificacion_citas.py` | tests/test_verificacion_citas.py — una cita literal no se rechaza por su formato. Medido el 2026-11-11 sobre la corrida real de `modelos/VaR_FixtureD… |
| `test_versionado.py` | tests/test_versionado.py — WP-10: versionado temporal + ventana de contexto. Dos piezas, ambas deterministas y sin API: · Pre-filtro duro is_active e… |
| `test_virf_plus.py` | tests/test_virf_plus.py ═══════════════════════════════════════════════════════════════════════════════ VIRF PLUS (GPT principal + Claude como segund… |

## `tests/fixtures/modelos_sinteticos/FraudeAML/inputs/calidad_datos/`

2 archivos — 1× `.csv`, 1× `.md`.

- `perfil_datos_FraudeAML.md`
- `transacciones_muestra.csv`

## `tests/fixtures/modelos_sinteticos/FraudeAML/inputs/documentacion/modelamiento/`

1 archivos — 1× `.md`.

- `manual_metodologico_FraudeAML.md`

## `tests/fixtures/modelos_sinteticos/FraudeAML/inputs/documentacion/seguimiento/`

1 archivos — 1× `.md`.

- `informe_seguimiento_FraudeAML_Q1.md`

## `tests/fixtures/modelos_sinteticos/FraudeAML/inputs/implementacion/`

1 archivos — 1× `.py`.

- `implementacion_FraudeAML.py`

## `tests/fixtures/modelos_sinteticos/IFRS9_Provisiones/inputs/calidad_datos/`

2 archivos — 1× `.csv`, 1× `.md`.

- `cartera_muestra.csv`
- `perfil_datos_IFRS9_Provisiones.md`

## `tests/fixtures/modelos_sinteticos/IFRS9_Provisiones/inputs/documentacion/modelamiento/`

1 archivos — 1× `.md`.

- `manual_metodologico_IFRS9_Provisiones.md`

## `tests/fixtures/modelos_sinteticos/IFRS9_Provisiones/inputs/documentacion/seguimiento/`

1 archivos — 1× `.md`.

- `informe_seguimiento_IFRS9_2026Q1.md`

## `tests/fixtures/modelos_sinteticos/IFRS9_Provisiones/inputs/implementacion/`

1 archivos — 1× `.py`.

- `implementacion_IFRS9_Provisiones.py`

## `tests/fixtures/modelos_sinteticos/PD_Retail/inputs/calidad_datos/`

2 archivos — 1× `.csv`, 1× `.md`.

- `perfil_datos_PD_Retail.md`
- `solicitudes_muestra.csv`

## `tests/fixtures/modelos_sinteticos/PD_Retail/inputs/documentacion/modelamiento/`

1 archivos — 1× `.md`.

- `manual_metodologico_PD_Retail.md`

## `tests/fixtures/modelos_sinteticos/PD_Retail/inputs/documentacion/seguimiento/`

1 archivos — 1× `.md`.

- `informe_seguimiento_PD_Retail_2026H1.md`

## `tests/fixtures/modelos_sinteticos/PD_Retail/inputs/implementacion/`

1 archivos — 1× `.py`.

- `implementacion_PD_Retail.py`

## `tests/fixtures/var_injection/`

3 archivos — 1× `.md`, 2× `.py`.

- `manual_var_demo.md`
- `modelo_var_demo.py`
- `modelo_var_roto.py`

## `tests/skills/`

| Archivo | Qué es |
|---|---|
| `test_calidad_datos.py` | Prueba unitaria de la Skill 2 (Calidad de Datos) — guía §4.B. Fixture sintético con EXACTAMENTE 10 outliers obvios + 5 duplicados exactos. El JSON re… |
| `test_cola_pendiente.py` | Prueba de la cola PENDIENTE (HITL) — antipatrón exceso de agencia (guía §5.1). Una acción de impacto externo debe QUEDAR ENCOLADA en estado PENDIENTE… |
| `test_skills_tipadas.py` | Arnés por skill — fundación tipada (SK-00 / SK-01). Verifica lo que se puede probar SIN API: · las 6 skills exponen una declaración de herramienta VÁ… |

## `web/`

| Archivo | Qué es |
|---|---|
| `README_WEB.md` | VIRF Web — capa web del agente |
| `__init__.py` |  |
| `app.py` | VIRF Web — capa web sobre el agente CLI. El paso 3 introduce la primera dependencia real del agente (`config.ia.prueba_de_humo`), así que aquí se hac… |
| `config_web.py` | Rutas y constantes del backend web. v2 · fase 2: los mapas de destino de upload viven ahora en `web/services/contexto_sesion.py` (dependen de la sesi… |
| `requirements_web.txt` |  |
| `verificar_conexiones.py` | Verificador end-to-end de conexiones del VIRF Agent Web (Mejora 5 · v2.2). Uso CLI: python web/verificar_conexiones.py --validador T5443 --modelo VAR… |

## `web/data/`

3 archivos — 3× `.json`.

- `dominios_custom.json`
- `prompts_base.json`
- `validadores.json`

## `web/routers/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |
| `auth.py` | Autenticación SSO con Microsoft Entra ID (SEG-02). Antes: login por código + nombre, sin contraseña, con alta al vuelo — cualquiera podía entrar (y f… |
| `automatizaciones.py` | Cuadro de observaciones desde los Excels de automatización (00–03). - GET /api/automatizaciones/estado → qué Excels hay y último cuadro - POST /api/a… |
| `chat.py` | Chat argumentativo por sesión (v2 · fase 7). Cada modelo lleva su propio chat, persistido a disco. Dos validadores en dos modelos distintos chatean e… |
| `codigo.py` | Aprobación humana de código generado por IA (SEG-07). POST /api/codigo/aprobar {hash, motivo} → rol revisor (permiso «aprobar»). La aprobación queda … |
| `config.py` | Configuración del proveedor IA (v2 · fase 2). Este router es de SOLO LECTURA para credenciales: muestra si la clave está configurada en la fuente de … |
| `controles.py` | Controles de calidad de datos (v2 · fase 2). - Catálogo (motores_datos): global, no depende de la sesión. - Resultados de la entidad (motores_entidad… |
| `cuestionamientos.py` | Cuestionamientos metodológicos — paso 9/10. Dos fuentes: - **Por defecto (Mx_00.CUESTIONAMIENTOS_METODOLOGICOS).** Los 15+ patrones que el agente usa… |
| `cuestionamientos_sesion.py` | Cuestionamientos POR SESIÓN — endpoints (v2 · fase 6). Coexisten con `/api/cuestionamientos/*` (capa global v1 que Mx_04 usa para regex). Aquí se ges… |
| `debug_conexiones.py` | Endpoint HTTP para el verificador de conexiones (Mejora 5 · v2.2). Misma contraseña que el visor de prompt. |
| `dominio_prevuelo.py` | Pre-vuelo sobre la EVIDENCIA de la sesión activa (v2 · fase 2). El dominio ya no es un endpoint aparte — vive en la ficha del modelo (elegido al crea… |
| `entendimiento.py` | Endpoints del mapa de entendimiento del modelo (Mejora 4 · v2.2). |
| `estandares.py` | Router del paso 02 · Estándares (v2.4). Endpoints: POST /api/estandares/upload → sube .xlsx como pendiente y devuelve vista previa GET /api/estandare… |
| `feedback_aprobacion.py` | Aprobación del feedback antes de que afecte a los puntajes (Paso 25). GET /api/feedback/pendientes → rol revisor POST /api/feedback/aprobar {id, deci… |
| `guia.py` | Guía del procedimiento: en qué paso está el expediente. - GET /api/guia/progreso → estado de los 9 pasos + el siguiente recomendado Solo LEE el disco… |
| `informe.py` | Informe consolidado por sesión (v2 · fase 8). - POST /api/informe/consolidado → genera un .docx versionado - GET /api/informe/versiones → lista todos… |
| `modelos.py` | Modelos del validador logueado + selección del modelo activo (v2 · fase 1). El modelo activo se guarda en una cookie `virf_modelo` (con el slug). La … |
| `preview_prompt.py` | Visor del prompt del agente, protegido con contraseña (Mejora 2 · v2.2). Devuelve el prompt EXACTO que se enviaría al LLM SIN ejecutar la llamada. Se… |
| `prompts.py` | Endpoints CRUD de prompts editables por sesión (v2.3). GET /api/prompts/base → los prompts por defecto (sin sesión) GET /api/prompts → los prompts EF… |
| `rag.py` | Dominio & RAG: papers al RAG global + reconstrucción + dominios custom. v2 · fase 4 + Mejora 1 (v2.2). Alcance: - `inputs/rag/{dominio}/` es GLOBAL —… |
| `resultados.py` | Lectura de resultados de validación (v2 · fase 2). Los JSON viven en `web/data/sesiones/{val}/{slug}/outputs/YYYY-MM-DD/`. El endpoint `/actual` devu… |
| `skills.py` | Endpoints de Skills — capacidades del agente por sesión (v2 · fase 5). Toma el contexto de la sesión de las cookies (mismo patrón que resto de router… |
| `solo_informe.py` | Router del apartado «Solo Informe»: genera el Informe de Resultados sin pipeline. Solo exige login (no modelo activo): el apartado es independiente d… |
| `upload.py` | Endpoints de subida de evidencia y visualización del árbol de inputs. v2 · fase 2 — trabajan sobre `web/data/sesiones/{val}/{slug}/inputs/` (salvo lo… |
| `validacion.py` | Endpoints REST + WebSocket del pipeline de validación (v2 · fase 2). Ahora anclado a la sesión activa: cada modelo gestiona su propio run. |
| `validacion_completa.py` | VALIDACIÓN COMPLETA: chat por etapa (00–04) sobre las automatizaciones. - GET /api/completa/estado → modalidad + resumen de etapas - POST /api/comple… |

## `web/services/`

| Archivo | Qué es |
|---|---|
| `__init__.py` |  |
| `analisis_codigo.py` | Análisis estructural del ZIP de implementación (Mejora 4 · v2.2). Dos capas: 1. **estructural** — sin IA, coste 0. AST para .py (funciones, clases, i… |
| `auditoria_web.py` | Middleware de auditoría de acciones web (SEG-12). Cada petición que encaja en `ACCIONES` produce EXACTAMENTE una entrada en el log de auditoría (modu… |
| `chat_service.py` | Chat argumentativo por sesión — v2 · fase 7. Cambios sobre v1: - **Multi-sesión**: cada modelo tiene su propio chat, indexado por `clave = "codigo/sl… |
| `contexto_sesion.py` | Resolución del contexto de sesión (v2 · fase 2). Todos los routers que trabajen "sobre el modelo activo" consumen este helper via `Depends(...)`. Dev… |
| `cuestionamientos_sesion.py` | Cuestionamientos POR SESIÓN (v2 · fase 6). Coexiste con la capa GLOBAL (`config/cuestionamientos_*.json`) que ya usa Mx_04 vía `modulos.cuestionamien… |
| `dominios_custom_store.py` | Dominios RAG personalizados (Mejora 1 · v2.2). - Persistencia: `web/data/dominios_custom.json`. - Registro sencillo `{id: {nombre, descripcion, palab… |
| `env_service.py` | Lectura (SOLO lectura) del `.env` del proyecto. Antes este módulo también ESCRIBÍA el `.env` (función de escritura retirada), y el Paso 01 de la web … |
| `estandares_service.py` | Estándares de validación por sesión (v2.4). Cada validador puede subir SU Estandares.xlsx para el modelo activo, en lugar de heredar el global fijo d… |
| `informe_web.py` | Generador de informe consolidado por sesión («Generar informe» de la web). Desde 2026-11 usa la plantilla común `modulos.plantilla_bcp`, la misma del… |
| `modelos_store.py` | Modelos por validador — cada uno con su carpeta y su `sesion.json`. Estructura en disco (persistente): web/data/sesiones/ T5443/ VAR_BCP_2027/ sesion… |
| `pipeline_runner.py` | Ejecuta `agente.py --prdc` como subproceso para UNA sesión (v2 · fase 2). Cambios sobre v1: - Ya no hay `_run_actual` global. Ahora es un dict `{clav… |
| `presupuesto_service.py` | Presupuesto de contexto dinámico por modelo detectado (v2.3). El agente CLI lee `VIRF_MAX_CTX` del entorno al arrancar (config/parametros.py). Antes … |
| `prompt_service.py` | Prompts editables por sesión (v2.3). Fuente única de prompts para el pipeline: - prompts_base.json (defaults, extraídos del código real) - sesion/pro… |
| `roles.py` | Roles y permisos de la web (SEG-08). Norma 2135.010.02 §Aseguramiento: control de acceso por rol, sin cuentas ni contraseñas compartidas. Los roles s… |
| `sesion_store.py` | Sesiones de login ligadas a la IDENTIDAD CORPORATIVA (SEG-02). - El login es SSO con Entra ID (`config/identidad.py`). Ya no existe el login por códi… |
| `skills_store.py` | Skills por sesión (v2 · fase 5). Un «skill» aquí es una CAPACIDAD DE ALTO NIVEL que el agente ejerce durante la validación. Se distingue de los cuest… |
| `solo_informe_ia.py` | Asistencia con IA del apartado «Solo Informe» (opcional). Tres ayudas, todas a pedido del validador y nunca aplicadas solas: la web muestra la propue… |
| `solo_informe_reglas.py` | Compatibilidad: las reglas de calificación viven en `modulos.reglas_informe` porque también las usa el entregable del pipeline, que no puede importar… |
| `solo_informe_service.py` | Apartado «Solo Informe»: compone el informe de resultados SIN ejecutar el pipeline. Entradas: el Estandar_VIRF.xlsx, los datos de cabecera (tipo de v… |
| `solo_informe_word.py` | Word del apartado «Solo Informe» (Informe de Resultados). La estructura y la estética viven en `modulos.plantilla_bcp`, compartida con «Generar infor… |

## `web/static/css/`

2 archivos — 2× `.css`.

- `styles.css`
- `ui-sello.css`

## `web/static/js/`

4 archivos — 4× `.js`.

- `app.js`
- `completa.js`
- `guia.js`
- `ui.js`

## `web/templates/`

| Archivo | Qué es |
|---|---|
| `index.html` |  |
