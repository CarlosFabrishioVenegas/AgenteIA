"""
Mx_03_LlamarIA.py
==================
Capa de comunicación con la API de Anthropic.
Responsabilidades:
  - Ejecutar llamadas HTTP a /v1/messages
  - Parsear respuestas JSON del modelo
  - Manejar errores de red, timeout y JSON inválido
  - Exponer funciones de alto nivel:
      llamar_modelo()       → retorna texto crudo
      llamar_y_parsear()    → retorna dict JSON parseado
      aprender_estilo()     → llama y retorna dict de estilo
      generar_replica()     → retorna código Python como str
      evaluar_dimension()   → retorna dict de evaluación
      generar_sintesis()    → retorna dict de síntesis

No contiene lógica de negocio ni construcción de prompts.
"""

import json
import re
import requests
from typing import Optional

from Mx_00_CargaRutas import (
    API_URL, MODELO_CLAUDE, MAX_TOKENS, ROL_AGENTE, UMBRAL_RIESGO_GLOBAL
)
import os as _os
from Mx_02_EstructuraPrompt import (
    prompt_aprender_estilo, estilo_por_defecto,
    prompt_generar_replica_virf,
    prompt_evaluar_dimension,
    prompt_sintesis,
)


# ─── Helpers internos ────────────────────────────────────────────────────────

def _llamar_modelo(user_prompt: str, max_tokens: Optional[int] = None) -> str:
    """
    Llama a la API de Anthropic y retorna el texto de la respuesta.
    Lanza excepción si el HTTP falla.
    """
    # BUG FIX: construir headers en tiempo de llamada, no en importación,
    # para garantizar que ANTHROPIC_API_KEY ya fue cargada por load_dotenv()
    _api_key = _os.getenv("ANTHROPIC_API_KEY", "")
    _headers = {
        "Content-Type":      "application/json",
        "anthropic-version": "2023-06-01",
        "x-api-key":         _api_key,
    }
    payload = {
        "model":      MODELO_CLAUDE,
        "max_tokens": max_tokens or MAX_TOKENS,
        "system":     ROL_AGENTE,
        "messages":   [{"role": "user", "content": user_prompt}],
    }
    response = requests.post(
        API_URL,
        headers=_headers,
        json=payload,
        timeout=180,
    )
    response.raise_for_status()
    data = response.json()
    return "".join(
        b.get("text", "")
        for b in data.get("content", [])
        if b.get("type") == "text"
    )


def _parsear_json(texto: str, fallback: dict) -> dict:
    """
    Extrae y parsea el primer objeto JSON encontrado en el texto.
    Si falla, retorna fallback con el raw adjunto.
    """
    limpio = re.sub(r"```(?:json)?|```", "", texto).strip()
    i, j = limpio.find("{"), limpio.rfind("}")
    if i != -1 and j != -1:
        limpio = limpio[i:j + 1]
    try:
        return json.loads(limpio)
    except json.JSONDecodeError:
        return {**fallback, "_raw": texto[:500]}


# ─── Funciones públicas ───────────────────────────────────────────────────────

def aprender_estilo(texto_informes: str) -> dict:
    """
    Llama al modelo con el texto de informes de referencia.
    Retorna dict con tono, frases y vocabulario aprendido.
    Si no hay texto, retorna el estilo por defecto.
    """
    if not texto_informes.strip():
        return estilo_por_defecto()
    raw = _llamar_modelo(prompt_aprender_estilo(texto_informes))
    return _parsear_json(raw, {"tono": "formal"})


def generar_replica_virf(docs_modelador: list, scripts_modelador: list) -> str:
    """
    Genera el código del script _replica_virf.py como segunda línea.
    Retorna código Python como string.
    """
    raw = _llamar_modelo(
        prompt_generar_replica_virf(docs_modelador, scripts_modelador),
        max_tokens=4000,
    )
    # Limpiar bloques markdown
    return re.sub(r"```(?:python)?|```", "", raw).strip()


def evaluar_dimension(
    dimension: str,
    actividades: list,
    documentos: list,
    estilo: dict,
    modo: str,
    instrucciones_extra: str = "",
    contexto_feedback: str = "",
) -> dict:
    """
    Evalúa las actividades de una dimensión VIRF.
    Maneja el caso de sin documentos (retorna evaluación vacía con preguntas).
    Retorna dict con evaluaciones, cumplimiento y hallazgos.
    """
    fallback = {
        "dimension":               dimension,
        "evaluaciones":            [],
        "nivel_cumplimiento":      0,
        "actividades_sin_evidencia": len(actividades),
        "resumen_dimension":       "Sin actividades.",
        "hallazgos_criticos":      [],
        "preguntas_globales_dimension": [],
    }

    if not actividades:
        return fallback

    # Sin documentos → preguntas automáticas
    if not documentos:
        preguntas = [
            f"No se encontraron documentos para la dimensión {dimension}. "
            f"¿Puede proporcionar los archivos correspondientes?"
        ]
        evals = []
        for a in [x for x in actividades if x.get("requerida", True)]:
            estado = "Solicitar Actas" if dimension == "Gobierno" else "No cumple"
            ev = {
                "control":           a.get("control", ""),
                "tipo_ctrl":         a.get("tipo_ctrl", ""),
                "actividad":         a["actividad"],
                "concepto":          "No evaluable — sin documentos.",
                "estado":            estado,
                "simbolo":           "❌",
                "evidencia":         None,
                "observacion_tecnica": "No se recibieron documentos para esta dimensión.",
                "inconsistencias":   None,
                "riesgo":            "Alto",
                "recomendacion":     "Proporcionar documentación correspondiente.",
                "preguntas_faltantes": preguntas,
            }
            if modo == "preprdc":
                ev.update({"score": 0, "criticidad": "Alto", "score_justificacion": "Sin evidencia."})
            evals.append(ev)

        return {
            "dimension":               dimension,
            "evaluaciones":            evals,
            "nivel_cumplimiento":      0,
            "actividades_sin_evidencia": len(evals),
            "resumen_dimension":       f"Sin documentación para {dimension}.",
            "hallazgos_criticos":      [f"Sin documentación para {dimension}"],
            "preguntas_globales_dimension": preguntas,
        }

    # Llamada normal al modelo
    raw = _llamar_modelo(
        prompt_evaluar_dimension(
            dimension=dimension,
            actividades=actividades,
            documentos=documentos,
            estilo=estilo,
            modo=modo,
            instrucciones_extra=instrucciones_extra,
            contexto_feedback=contexto_feedback,
        ),
        max_tokens=4000,
    )

    resultado = _parsear_json(raw, fallback)

    # Recalcular actividades_sin_evidencia
    evals = resultado.get("evaluaciones", [])
    sin_ev = sum(
        1 for e in evals
        if not e.get("evidencia") or e.get("estado") == "No cumple"
    )
    resultado["actividades_sin_evidencia"] = sin_ev

    return resultado


def generar_sintesis(
    resultados: dict,
    titulo: str,
    modo: str,
    estilo: dict,
    tier: str,
) -> dict:
    """
    Genera la síntesis ejecutiva, dictamen global y plan de acción.
    Retorna dict con resumen_ejecutivo, dictamen_global, plan_accion, etc.
    """
    fallback = {
        "resumen_ejecutivo":       "Ver resultados por dimensión.",
        "dictamen_global":         "APROBADO CON OBSERVACIONES",
        "nivel_riesgo":            "Medio",
        "riesgo_global_alto":      False,
        "justificacion_dictamen":  "",
        "principales_hallazgos":   [],
        "informacion_requerida":   [],
        "plan_accion":             [],
        "proxima_revision":        "Próximo trimestre",
        "conclusion_narrativa":    "",
    }
    raw = _llamar_modelo(
        prompt_sintesis(resultados, titulo, modo, estilo, tier),
        max_tokens=4000,
    )
    return _parsear_json(raw, fallback)
