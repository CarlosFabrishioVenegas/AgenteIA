"""
Mx_01_LecturaEvidencias.py
===========================
Lectura y extracción de texto de todas las fuentes de evidencia:
  - PDF, DOCX, PPTX, XLSX, PY, JSON, TXT, MD
  - Estandares_VIRF.xlsx (con celdas fusionadas, TIER y historial)
  - Repositorio de informes de referencia

Responsabilidades:
  - Leer archivos individuales por tipo
  - Leer carpetas completas y devolver lista de documentos
  - Parsear Estandares_VIRF.xlsx filtrando por Tier
  - Consolidar texto de informes de referencia para aprendizaje de estilo
"""

import json
import re
from pathlib import Path
from typing import Optional

from Mx_00_CargaRutas import (
    MAX_CHARS_DOC, MAX_CHARS_CODIGO, MAX_FILAS_EXCEL,
    AMBITO_A_INPUTS, RUTAS,
)


# ─── Lectores por tipo de archivo ─────────────────────────────────────────────

def _leer_pdf(path: Path) -> str:
    try:
        from pdfminer.high_level import extract_text
        return extract_text(str(path))
    except ImportError:
        pass
    try:
        import PyPDF2
        texts = []
        with open(path, "rb") as f:
            for page in PyPDF2.PdfReader(f).pages:
                t = page.extract_text()
                if t:
                    texts.append(t)
        return "\n".join(texts)
    except ImportError:
        return f"[PDF no legible — instalar pdfminer.six: {path.name}]"


def _leer_docx(path: Path) -> str:
    try:
        from docx import Document
        from docx.oxml.ns import qn
        doc = Document(path)
        partes = []
        for elem in doc.element.body:
            tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
            if tag == "p":
                t = "".join(r.text for r in elem.iter(qn("w:t")))
                if t.strip():
                    partes.append(t.strip())
            elif tag == "tbl":
                for fila in elem.iter(qn("w:tr")):
                    celdas = [
                        "".join(r.text for r in c.iter(qn("w:t"))).strip()
                        for c in fila.iter(qn("w:tc"))
                    ]
                    if any(celdas):
                        partes.append(" | ".join(celdas))
        return "\n".join(partes)
    except Exception as e:
        return f"[Error leyendo {path.name}: {e}]"


def _leer_pptx(path: Path) -> str:
    try:
        from pptx import Presentation
        partes = []
        for i, slide in enumerate(Presentation(path).slides, 1):
            txts = [
                s.text.strip()
                for s in slide.shapes
                if hasattr(s, "text") and s.text.strip()
            ]
            if txts:
                partes.append(f"[Slide {i}] " + " | ".join(txts))
        return "\n".join(partes)
    except Exception as e:
        return f"[Error PPTX {path.name}: {e}]"


def _leer_excel(path: Path, max_filas: int = 150) -> str:
    try:
        import pandas as pd
        xf = pd.ExcelFile(path)
        partes = []
        for nombre in xf.sheet_names:
            df = xf.parse(nombre).dropna(how="all").fillna("")
            csv = df.head(max_filas).to_csv(index=False)
            partes.append(f"--- Hoja: {nombre} ---\n{csv}")
        return "\n".join(partes)
    except Exception as e:
        return f"[Error Excel {path.name}: {e}]"


def _leer_python(path: Path, max_chars: int = 8000) -> str:
    try:
        code = path.read_text(encoding="utf-8", errors="replace")
        if len(code) > max_chars:
            code = code[:max_chars] + f"\n... [truncado a {max_chars} chars]"
        return code
    except Exception as e:
        return f"[Error .py {path.name}: {e}]"


def _leer_json(path: Path) -> str:
    try:
        return json.dumps(
            json.loads(path.read_text(encoding="utf-8")),
            ensure_ascii=False, indent=2
        )[:5000]
    except Exception as e:
        return f"[Error JSON {path.name}: {e}]"


LECTORES_EXT = {
    ".pdf":  lambda p: _leer_pdf(p),
    ".docx": lambda p: _leer_docx(p),
    ".doc":  lambda p: _leer_docx(p),
    ".pptx": lambda p: _leer_pptx(p),
    ".ppt":  lambda p: _leer_pptx(p),
    ".xlsx": lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".xls":  lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".xlsm": lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".py":   lambda p: _leer_python(p, MAX_CHARS_CODIGO),
    ".json": lambda p: _leer_json(p),
    ".txt":  lambda p: p.read_text(encoding="utf-8", errors="replace")[:5000],
    ".md":   lambda p: p.read_text(encoding="utf-8", errors="replace")[:5000],
    ".csv":  lambda p: p.read_text(encoding="utf-8", errors="replace")[:5000],
}


# ─── Funciones públicas ───────────────────────────────────────────────────────

def leer_archivo(path: Path) -> Optional[dict]:
    """Lee un archivo y retorna dict {nombre, tipo, contenido} o None si no soportado."""
    ext = path.suffix.lower()
    lector = LECTORES_EXT.get(ext)
    if not lector:
        return None
    contenido = lector(path)
    max_c = MAX_CHARS_CODIGO if ext == ".py" else MAX_CHARS_DOC
    return {
        "nombre":    path.name,
        "tipo":      ext.lstrip(".").upper(),
        "contenido": contenido[:max_c],
    }


def leer_carpeta(carpeta: Path) -> list:
    """Lee todos los archivos soportados de una carpeta (recursivo). Retorna lista de dicts."""
    if not carpeta.exists():
        return []
    archivos = []
    # BUG FIX: usar rglob en lugar de iterdir para leer subdirectorios
    # (ej: inputs/documentacion/modelamiento/ y inputs/documentacion/seguimiento/)
    for path in sorted(carpeta.rglob("*")):
        if path.is_file():
            doc = leer_archivo(path)
            if doc:
                archivos.append(doc)
    return archivos


def leer_repositorio_informes(carpeta: Path) -> str:
    """Consolida el texto de todos los informes de referencia para aprendizaje de estilo."""
    docs = leer_carpeta(carpeta)
    if not docs:
        return ""
    return "\n".join(
        f"=== INFORME: {d['nombre']} ===\n{d['contenido']}\n"
        for d in docs
    )


def cargar_todos_inputs() -> dict:
    """
    Carga todos los inputs definidos en RUTAS['inputs'].
    Retorna dict {nombre_seccion: [lista_de_docs]}.
    """
    resultado = {}
    for nombre, ruta in RUTAS["inputs"].items():
        resultado[nombre] = leer_carpeta(Path(ruta))
    return resultado


def inputs_para_dimension(docs: dict, dimension: str) -> list:
    """
    Filtra y une los documentos relevantes para una dimensión específica.
    Ordena por prioridad: manuales → scripts seguimiento → scripts modelador → excels → otros.
    """
    secciones = AMBITO_A_INPUTS.get(dimension, list(docs.keys()))
    todos = []
    for sec in secciones:
        todos.extend(docs.get(sec, []))

    manuales    = [d for d in todos if d["tipo"] in ("PDF", "DOCX", "DOC")]
    scripts_seg = [d for d in todos if d["tipo"] == "PY" and
                   any(k in d["nombre"].lower() for k in
                       ("seguimiento", "backtest", "kupiec", "christoff", "replica_virf", "monitor"))]
    scripts_mod = [d for d in todos if d["tipo"] == "PY" and d not in scripts_seg]
    excels      = [d for d in todos if d["tipo"] in ("XLSX", "XLS", "XLSM", "CSV")]
    otros       = [d for d in todos if d not in manuales + scripts_seg + scripts_mod + excels]

    return manuales + scripts_seg + scripts_mod + excels + otros


def leer_estandares_virf(tier: str) -> Optional[dict]:
    """
    Lee Estandares_VIRF.xlsx y retorna actividades filtradas por Tier.

    Retorna:
    {
      "Documentación": [
        {
          "control": "...",
          "tipo_ctrl": "Cuantitativo|Cualitativo",
          "actividad": "...",
          "requerida": True,
          "concepto_existente": "..." | None,
          "validaciones_previas": [{"col": "...", "valor": "..."}, ...]
        },
        ...
      ],
      ...
    }
    """
    path = RUTAS["estandares_virf"]
    if not Path(path).exists():
        return None

    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        tier_col = f"TIER_{tier.upper()}"
        resultado = {}

        for nombre_hoja in wb.sheetnames:
            if any(k in nombre_hoja.lower() for k in ("instruc", "resumen", "readme", "leeme")):
                continue

            ws = wb[nombre_hoja]
            filas = [list(row) for row in ws.iter_rows(values_only=True)]
            if not filas:
                continue

            # Normalizar longitud de filas
            n_cols = max(len(f) for f in filas)
            for f in filas:
                while len(f) < n_cols:
                    f.append(None)

            # Forward-fill ÁMBITO (col 0) y CONTROL (col 1)
            for col_idx in (0, 1):
                last = None
                for fila in filas:
                    v = fila[col_idx]
                    if v is not None and str(v).strip() not in ("", "None", "nan"):
                        last = str(v).strip()
                    else:
                        fila[col_idx] = last

            # Detectar fila cabecera
            cab_idx = 0
            palabras_hdr = {"ámbito", "ambito", "control", "actividad", "tier", "requiere"}
            for i, fila in enumerate(filas):
                vals_lower = {str(v).lower().strip() for v in fila if v}
                if vals_lower & palabras_hdr:
                    cab_idx = i
                    break

            hdr_row = [str(v).lower().strip() if v else "" for v in filas[cab_idx]]
            datos   = filas[cab_idx + 1:]

            def _col(*claves):
                for i, h in enumerate(hdr_row):
                    if any(k in h for k in claves):
                        return i
                return None

            col_ambito = _col("ámbito", "ambito", "dimension", "dimensión") or 0
            col_ctrl   = _col("control", "ctrl") or 1
            col_act    = _col("actividad", "activity", "tarea") or 2

            # Columna del TIER
            tier_key = tier_col.lower()
            col_tier = None
            for i, h in enumerate(hdr_row):
                h_clean = h.replace(" ", "_").replace("-", "_")
                if h_clean == tier_key or h == tier_key:
                    col_tier = i
                    break
            if col_tier is None:
                tier_num = tier.upper()
                for i, h in enumerate(hdr_row):
                    if "tier" in h and tier_num in h.upper():
                        col_tier = i
                        break

            # Columna Concepto
            col_concepto = _col("concepto")

            # Columnas historial VALIDACIÓN_*
            cols_validacion = []
            for i, h in enumerate(hdr_row):
                if (re.match(r"validaci[oó]n[_\s]\d{8}.*", h, re.IGNORECASE) or
                        "validación" in h or "validacion" in h):
                    cols_validacion.append((i, filas[cab_idx][i]))

            # Parsear datos
            for fila in datos:
                ambito  = str(fila[col_ambito]).strip() if fila[col_ambito] else ""
                control = str(fila[col_ctrl]).strip()   if fila[col_ctrl]   else ""
                activ   = str(fila[col_act]).strip()    if len(fila) > col_act and fila[col_act] else ""

                if not activ or activ.lower() in ("actividad", "activity", "nan", "none", ""):
                    continue
                if not ambito or ambito.lower() in ("nan", "none", ""):
                    continue

                # Requerida por Tier
                if col_tier is not None and len(fila) > col_tier:
                    tier_val  = str(fila[col_tier]).strip().upper()
                    requerida = tier_val in ("X", "SI", "YES", "1", "TRUE", "✓", "✔", "V")
                else:
                    requerida = True

                # Concepto existente
                concepto_prev = None
                if col_concepto is not None and len(fila) > col_concepto:
                    v = fila[col_concepto]
                    if v and str(v).strip() not in ("", "None", "nan"):
                        concepto_prev = str(v).strip()

                # Historial de validaciones previas
                validaciones_previas = []
                for col_idx_v, col_nombre_v in cols_validacion:
                    if len(fila) > col_idx_v:
                        v = fila[col_idx_v]
                        if v and str(v).strip() not in ("", "None", "nan"):
                            validaciones_previas.append({
                                "col":   str(col_nombre_v) if col_nombre_v else f"Col{col_idx_v}",
                                "valor": str(v).strip(),
                            })

                # Tipo de control
                tipo_ctrl = "Cualitativo"
                ctrl_l = control.lower()
                if any(k in ctrl_l for k in ("cuantit", "quantit", "medic", "métric", "metric",
                                              "modelador", "backtesting", "seguim")):
                    tipo_ctrl = "Cuantitativo"

                resultado.setdefault(ambito, []).append({
                    "control":              control,
                    "tipo_ctrl":            tipo_ctrl,
                    "actividad":            activ,
                    "requerida":            requerida,
                    "concepto_existente":   concepto_prev,
                    "validaciones_previas": validaciones_previas,
                })

        return resultado if resultado else None

    except Exception as e:
        print(f"    [!] Error leyendo Estandares_VIRF: {e}")
        return None
