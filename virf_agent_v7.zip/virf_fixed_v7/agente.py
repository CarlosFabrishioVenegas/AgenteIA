"""
agente.py — Punto de entrada del agente VIRF
Uso:
  python agente.py --titulo "Modelo LaR" --tier II --preprdc
  python agente.py --titulo "Modelo LaR" --tier II --prdc
  python agente.py --estadisticafeedback
"""

import argparse
import sys
from datetime import datetime
from pathlib import Path

from config import INPUTS, OUTPUTS_DIR, AMBITO_PESOS
from modulos.lector_inputs import cargar_todos_los_inputs, consolidar_contexto
from modulos.generador_template import (
    cargar_actividades_por_tier, agrupar_por_ambito, actualizar_estandares_con_version
)
from modulos.motor_ia import (
    evaluar_ambito_completo, calcular_score_ambito,
    calcular_score_global, generar_resumen_ejecutivo, get_semaforo,
)
from modulos.generador_excel import generar_excel_resultados
from modulos.generador_word import generar_word_informe
from modulos.feedback import bucle_feedback_consola, calcular_estadisticas
from modulos.generador_estadistica_feedback import generar_informe_estadistica


AMBITO_A_INPUTS = {
    "Documentación":                  ["doc_modelamiento", "doc_seguimiento", "repositorio"],
    "Calidad de datos":               ["calidad_datos", "doc_modelamiento"],
    "Metodología":                    ["doc_modelamiento", "papers", "doc_seguimiento"],
    "Gobierno":                       ["doc_modelamiento", "implementacion"],
    "Implementación":                 ["implementacion", "doc_modelamiento"],
    "Uso e integración a la gestión": ["usos", "implementacion"],
}


def _construir_contexto_ambito(todos_inputs, ambito):
    secciones = AMBITO_A_INPUTS.get(ambito, list(todos_inputs.keys()))
    return consolidar_contexto({k: v for k, v in todos_inputs.items() if k in secciones})


def _print_banner(titulo, tier, modo):
    print("\n" + "═" * 65)
    print("  🔍 AGENTE VIRF — VALIDADOR DE MODELOS DE RIESGO FINANCIERO")
    print(f"  Modelo : {titulo}")
    print(f"  Tier   : {tier}")
    print(f"  Modo   : {'PRE-PRODUCCIÓN (--preprdc)' if modo == 'preprdc' else 'PRODUCCIÓN (--prdc)'}")
    print(f"  Fecha  : {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    print("═" * 65 + "\n")


def _print_progreso(ambito, n, total):
    pct = int((n / total) * 100)
    barra = "█" * (pct // 5) + "░" * (20 - pct // 5)
    print(f"\n[{barra}] {pct}%  ▶  ÁMBITO: {ambito}")


def modo_estadistica_feedback():
    print("\n" + "═" * 65)
    print("  📈 ESTADÍSTICAS DE PRECISIÓN DEL AGENTE VIRF")
    print("═" * 65 + "\n")

    stats = calcular_estadisticas()
    if "error" in stats:
        print(f"  [!] {stats['error']}")
        print("  Ejecuta al menos una validación con feedback antes de usar este modo.\n")
        sys.exit(0)

    print(f"  Total feedbacks registrados : {stats['total_feedbacks']}")
    print(f"  Período                     : {stats['primer_feedback']} → {stats['ultimo_feedback']}")
    print(f"\n  {'MÉTRICA':<35} {'VALOR':>10}")
    print(f"  {'─'*47}")
    print(f"  {'Evaluaciones exactas':<35} {stats['pct_exactas']:>9.1f}%")
    print(f"  {'Dentro de ±1 punto':<35} {stats['pct_dentro_1_punto']:>9.1f}%")
    print(f"  {'Error medio absoluto (MAE)':<35} {stats['mae']:>10.3f}")
    print(f"  {'Sesgo promedio':<35} {stats['sesgo_promedio']:>10.3f}")
    print(f"  {'Interpretación sesgo':<35} {stats['sesgo_interpretacion']}")
    print(f"  {'Sobreestimaciones':<35} {stats['n_sobreestimaciones']:>10}")
    print(f"  {'Subestimaciones':<35} {stats['n_subestimaciones']:>10}")
    print(f"\n  {'ÁMBITO':<35} {'MAE':>6}  {'EXACTOS':>8}  {'±1 PTO':>7}")
    print(f"  {'─'*58}")
    for amb, s in stats["por_ambito"].items():
        print(f"  {amb:<35} {s['mae']:>6.3f}  {s['pct_exactos']:>7.1f}%  {s['pct_1_punto']:>6.1f}%")

    print("\n  📊 Generando informe Excel detallado...")
    ruta = generar_informe_estadistica(OUTPUTS_DIR)
    if ruta:
        print(f"\n  ✅ Informe guardado en: {ruta.name}")
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Agente VIRF — Validador de modelos LaR/VaR"
    )
    parser.add_argument("--titulo", default=None)
    parser.add_argument("--tier", default=None, choices=["I", "II", "III", "IV"])

    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument("--preprdc", action="store_true")
    mode_group.add_argument("--prdc", action="store_true")
    mode_group.add_argument("--estadisticafeedback", action="store_true")

    args = parser.parse_args()

    if args.estadisticafeedback:
        modo_estadistica_feedback()
        return

    if not args.titulo:
        parser.error("--titulo es obligatorio")
    if not args.tier:
        parser.error("--tier es obligatorio")

    titulo = args.titulo
    tier   = args.tier.upper()
    modo   = "preprdc" if args.preprdc else "prdc"

    _print_banner(titulo, tier, modo)

    # 1. Cargar actividades
    print("📋 Cargando estándares VIRF...")
    try:
        actividades = cargar_actividades_por_tier(tier)
        actividades_por_ambito = agrupar_por_ambito(actividades)
    except Exception as e:
        print(f"[ERROR] No se pudo leer Estandares_VIRF.xlsx: {e}")
        sys.exit(1)

    total_actividades = sum(len(v) for v in actividades_por_ambito.values())
    print(f"  ✓ {total_actividades} actividades cargadas para Tier {tier}")
    print(f"  ✓ Ámbitos: {', '.join(actividades_por_ambito.keys())}\n")

    # 2. Cargar inputs
    print("📁 Cargando inputs del modelo...")
    todos_inputs = cargar_todos_los_inputs(INPUTS)
    print(f"  ✓ {sum(len(v) for v in todos_inputs.values())} archivos procesados\n")

    # 3. Evaluar
    print("🤖 Iniciando evaluación con Claude opus-4-5...\n")
    evaluaciones_por_ambito = {}
    scores_por_ambito = {}

    for n, (ambito, acts) in enumerate(actividades_por_ambito.items(), start=1):
        _print_progreso(ambito, n, len(actividades_por_ambito))
        contexto = _construir_contexto_ambito(todos_inputs, ambito)
        evals = evaluar_ambito_completo(
            ambito=ambito, actividades=acts, contexto=contexto,
            titulo_modelo=titulo, modo_preprdc=(modo == "preprdc"),
        )
        evaluaciones_por_ambito[ambito] = evals
        scores_por_ambito[ambito] = calcular_score_ambito(evals)
        print(f"  ✓ Score {ambito}: {scores_por_ambito[ambito]:.2f}/5.0  [{get_semaforo(scores_por_ambito[ambito])['label']}]")

    score_global = calcular_score_global(scores_por_ambito, AMBITO_PESOS)
    print(f"\n{'─'*50}")
    print(f"  📊 SCORE GLOBAL: {score_global:.2f}/5.0  —  {get_semaforo(score_global)['label']}")
    print(f"{'─'*50}\n")

    # 4. Excel (genera versión internamente)
    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")
    print("📊 Generando Excel de resultados...")
    ruta_excel = generar_excel_resultados(
        evaluaciones_por_ambito=evaluaciones_por_ambito,
        scores_por_ambito=scores_por_ambito,
        score_global=score_global,
        titulo_modelo=titulo, tier=tier, outputs_dir=OUTPUTS_DIR,
    )
    # BUG FIX: extraer versión del nombre real del archivo generado
    # para que ruta_estandares_out use exactamente la misma versión
    import re as _re
    _vm = _re.search(r"_(V\d+)\.xlsx$", ruta_excel.name)
    version = _vm.group(1) if _vm else "V1"
    ruta_estandares_out = OUTPUTS_DIR / f"Estandares_VIRF_{titulo.replace(' ','_')}_{fecha_str}_{version}.xlsx"
    actualizar_estandares_con_version(
        evaluaciones_por_ambito=evaluaciones_por_ambito,
        tier=tier, fecha_str=fecha_str, version=version, ruta_salida=ruta_estandares_out,
    )

    # 6. Word (solo --prdc)
    ruta_word = None
    if modo == "prdc":
        print("\n📝 Generando informe Word consolidado...")
        resumen = generar_resumen_ejecutivo(
            evaluaciones_por_ambito=evaluaciones_por_ambito,
            scores_por_ambito=scores_por_ambito,
            score_global=score_global, titulo_modelo=titulo, tier=tier,
        )
        ruta_word = generar_word_informe(
            resumen_ejecutivo=resumen,
            evaluaciones_por_ambito=evaluaciones_por_ambito,
            scores_por_ambito=scores_por_ambito,
            score_global=score_global, titulo_modelo=titulo,
            tier=tier, outputs_dir=OUTPUTS_DIR,
        )

    # 7. Resumen consola
    print("\n" + "═" * 65)
    print("  ✅ AGENTE VIRF COMPLETADO")
    print(f"  📊 Excel  : {ruta_excel.name}")
    print(f"  📋 Estánd.: {ruta_estandares_out.name}")
    if ruta_word:
        print(f"  📄 Word   : {ruta_word.name}")
    print(f"\n  SCORES FINALES:")
    for ambito, score in scores_por_ambito.items():
        print(f"    {ambito:<35} {score:.2f}/5.0  [{get_semaforo(score)['label']}]")
    print(f"\n  {'SCORE GLOBAL PONDERADO':<35} {score_global:.2f}/5.0  [{get_semaforo(score_global)['label']}]")
    total_preg = sum(len(ev.get("preguntas_pendientes",[])) for evals in evaluaciones_por_ambito.values() for ev in evals)
    if total_preg > 0:
        print(f"\n  ⚠️  {total_preg} requerimientos pendientes al modelador.")
    print("═" * 65)

    # 8. Feedback interactivo
    bucle_feedback_consola(
        evaluaciones_por_ambito=evaluaciones_por_ambito,
        titulo_modelo=titulo, tier=tier, version=version,
    )


if __name__ == "__main__":
    main()
