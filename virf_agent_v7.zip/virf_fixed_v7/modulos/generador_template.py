"""
modulos/generador_template.py
Lee Estandares_VIRF.xlsx y extrae las actividades aplicables según el tier.
También actualiza el archivo con columnas de concepto y versión de validación.
"""

import openpyxl
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple
import re

from config import ESTANDARES_PATH


TIER_COL_MAP = {
    "I":   "TIER I",
    "II":  "TIER II",
    "III": "TIER III",
    "IV":  "TIER IV",
}


def _limpiar_str(val) -> str:
    if val is None or str(val).strip() in ("None", "nan", "NaN", ""):
        return ""
    return str(val).strip()


def cargar_actividades_por_tier(tier: str) -> List[Dict]:
    """
    Lee Estandares_VIRF.xlsx y retorna las actividades marcadas con X
    para el tier especificado.
    """
    tier = tier.upper()
    if tier not in TIER_COL_MAP:
        raise ValueError(f"Tier '{tier}' no válido. Opciones: {list(TIER_COL_MAP.keys())}")

    tier_col = TIER_COL_MAP[tier]

    df = pd.read_excel(ESTANDARES_PATH, header=None)

    # Encontrar la fila de encabezado (contiene "AMBITO" o "TIER I")
    header_row = None
    for i, row in df.iterrows():
        row_vals = [str(v).strip().upper() for v in row.values]
        if "AMBITO" in row_vals or "TIER I" in row_vals:
            header_row = i
            break

    if header_row is None:
        raise ValueError("No se encontró la fila de encabezados en Estandares_VIRF.xlsx")

    df.columns = [_limpiar_str(c) for c in df.iloc[header_row]]
    df = df.iloc[header_row + 1:].reset_index(drop=True)

    # Mapear columnas reales
    col_ambito    = next((c for c in df.columns if "AMBITO" in c.upper()), None)
    col_control   = next((c for c in df.columns if "CONTROL" in c.upper()), None)
    col_actividad = next((c for c in df.columns if "ACTIVIDAD" in c.upper()), None)
    col_tier      = next((c for c in df.columns if c.upper() == tier_col.upper()), None)

    if not all([col_ambito, col_actividad, col_tier]):
        raise ValueError(f"No se encontraron columnas necesarias. Cols: {list(df.columns)}")

    actividades = []
    ambito_actual = ""
    control_actual = ""

    for _, row in df.iterrows():
        ambito_val    = _limpiar_str(row.get(col_ambito, ""))
        control_val   = _limpiar_str(row.get(col_control, "")) if col_control else ""
        actividad_val = _limpiar_str(row.get(col_actividad, ""))
        tier_val      = _limpiar_str(row.get(col_tier, ""))

        if ambito_val:
            ambito_actual = ambito_val
        if control_val:
            control_actual = control_val

        if actividad_val and tier_val.upper() == "X":
            actividades.append({
                "ambito":    ambito_actual,
                "control":   control_actual,
                "actividad": actividad_val,
            })

    return actividades


def agrupar_por_ambito(actividades: List[Dict]) -> Dict[str, List[Dict]]:
    """Agrupa la lista de actividades por ámbito."""
    resultado = {}
    for act in actividades:
        ambito = act["ambito"]
        if ambito not in resultado:
            resultado[ambito] = []
        resultado[ambito].append(act)
    return resultado


def actualizar_estandares_con_version(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    tier: str,
    fecha_str: str,
    version: str,
    ruta_salida: Path,
):
    """
    Agrega al Estandares_VIRF.xlsx dos nuevas columnas:
      - CONCEPTO: descripción técnica de la actividad
      - VALIDACIÓN-DDMMYYYY_VN: resultado/puntaje de la corrida
    """
    wb = openpyxl.load_workbook(ESTANDARES_PATH)
    ws = wb.active

    # Encontrar fila de headers
    header_row_idx = None
    for i, row in enumerate(ws.iter_rows(values_only=True), start=1):
        row_strs = [str(v).strip().upper() if v else "" for v in row]
        if "ACTIVIDAD" in row_strs:
            header_row_idx = i
            break

    if header_row_idx is None:
        print("[WARN] No se encontró fila de headers para actualizar el Excel.")
        return

    # Determinar última columna usada
    max_col = ws.max_column + 1

    col_concepto  = max_col
    col_validacion = max_col + 1

    header_concepto   = "CONCEPTO"
    header_validacion = f"VALIDACIÓN-{fecha_str}_{version}"

    ws.cell(header_row_idx, col_concepto,   header_concepto)
    ws.cell(header_row_idx, col_validacion, header_validacion)

    # BUG FIX: imports movidos fuera del bucle (ya están disponibles en el módulo)
    from openpyxl.styles import PatternFill, Font, Alignment
    for col in [col_concepto, col_validacion]:
        c = ws.cell(header_row_idx, col)
        c.fill = PatternFill("solid", fgColor="1F3864")
        c.font = Font(bold=True, color="FFFFFF", size=9, name="Arial")
        c.alignment = Alignment(horizontal="center", wrap_text=True)

    # Construir mapa actividad → evaluación
    mapa_eval = {}
    for ambito, evals in evaluaciones_por_ambito.items():
        for ev in evals:
            key = ev.get("actividad", "").strip().lower()
            mapa_eval[key] = ev

    # Encontrar columna ACTIVIDAD
    act_col = None
    for col in range(1, ws.max_column + 1):
        val = ws.cell(header_row_idx, col).value
        if val and "ACTIVIDAD" in str(val).upper():
            act_col = col
            break

    if act_col is None:
        print("[WARN] No se encontró columna ACTIVIDAD.")
        return

    # Rellenar filas
    for row_idx in range(header_row_idx + 1, ws.max_row + 1):
        actividad_celda = ws.cell(row_idx, act_col).value
        if not actividad_celda:
            continue
        key = str(actividad_celda).strip().lower()
        ev = mapa_eval.get(key)
        if ev:
            puntaje = ev.get("puntaje", "")
            concepto = ev.get("concepto", "")
            label = {1:"No cumple",2:"Obs. críticas",3:"Cumple parcial",4:"Obs. menores",5:"Cumple"}.get(puntaje,"")

            ws.cell(row_idx, col_concepto,   concepto)
            ws.cell(row_idx, col_validacion, f"{puntaje}/5 - {label}")

            # BUG FIX: import eliminado del interior del bucle (ya importado arriba)
            color_map = {1:"FF0000",2:"FF6600",3:"FFCC00",4:"92D050",5:"00B050"}
            color = color_map.get(puntaje, "CCCCCC")
            c = ws.cell(row_idx, col_validacion)
            c.fill = PatternFill("solid", fgColor=color)
            c.font = Font(bold=True, color="FFFFFF", size=9, name="Arial")

    ruta_salida.parent.mkdir(parents=True, exist_ok=True)
    wb.save(ruta_salida)
    print(f"  ✓ Estandares actualizado: {ruta_salida}")
