"""
modulos/motor_ia.py
====================
Orquestador principal del agente VIRF.
Financial Controller / Model Risk Validator — LaR, VaR, IFRS 9.

Este módulo contiene la lógica de negocio (scoring 1-5, semáforo,
resumen ejecutivo) y delega en los módulos Mx_* para la infraestructura:

    Infraestructura (motor/):
        Mx_00  →  configuración, rutas, constantes, rol del agente
        Mx_01  →  lectura de archivos (PDF, DOCX, PY, XLSX, ...)
        Mx_02  →  construcción de prompts
        Mx_03  →  llamadas a la API de Anthropic
        Mx_04  →  controles de datos (crece cada semana)

    Lógica de negocio (este archivo):
        evaluar_actividad()         →  evalúa 1 actividad → puntaje 1-5
        evaluar_ambito_completo()   →  itera actividades de un ámbito
        generar_resumen_ejecutivo() →  narrativa final del informe
        calcular_score_ambito()     →  promedio de puntajes
        calcular_score_global()     →  score ponderado por ámbito
        get_semaforo()              →  label y color según score
"""

import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

# ── Resolver ruta a motor/ para importar los Mx_* ────────────────────────────
_MODULOS_DIR = Path(__file__).parent.resolve()      # .../virf_agent_clean/modulos/
_ROOT_DIR    = _MODULOS_DIR.parent.resolve()         # .../virf_agent_clean/
_MOTOR_DIR   = _ROOT_DIR / "motor"                   # .../virf_agent_clean/motor/

for _p in [str(_MOTOR_DIR), str(_ROOT_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ── Importar infraestructura desde los Mx ────────────────────────────────────

# Mx_00 — configuración centralizada del motor
from Mx_00_CargaRutas import (
    ROL_AGENTE,
    RUTAS,
    AMBITO_A_INPUTS,
    INSTRUCCIONES_DIMENSION,
    UMBRAL_RIESGO_GLOBAL,
    MODO_PREPRDC,
    MODO_PRDC,
)

# Mx_01 — lectura de archivos y evidencias
from Mx_01_LecturaEvidencias import (
    leer_carpeta,
    leer_repositorio_informes,
    leer_estandares_virf,
    cargar_todos_inputs,
    inputs_para_dimension,
)

# Mx_03 — llamada HTTP a la API (lógica de transporte)
from Mx_03_LlamarIA import (
    _llamar_modelo,       # llamada raw → retorna texto
    _parsear_json,        # limpia y parsea JSON de la respuesta
    aprender_estilo,      # aprende lenguaje de informes de referencia
    generar_replica_virf, # genera _replica_virf.py cuando no existe
    generar_sintesis,     # síntesis ejecutiva y dictamen global
)

# Mx_04 — controles de datos (se amplía cada semana)
from Mx_04_MotorControlesData import (
    detectar_cuestionamientos,
    tiene_replica_virf,
    calcular_riesgo_global,
    resumen_cuestionamientos_consola,
)

# ── Config de negocio (desde config.py de la raíz) ───────────────────────────
from config import (
    ESCALA_PUNTAJE,
    SCORE_SEMAFORO,
    AMBITO_PESOS,
    PREGUNTAS_METODOLOGICAS,
)
from modulos.feedback import construir_contexto_feedback


# ══════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN DE ACTIVIDADES — lógica de negocio con scoring 1-5
# ══════════════════════════════════════════════════════════════════════════════

def evaluar_actividad(
    actividad:     str,
    ambito:        str,
    control:       str,
    contexto:      str,
    titulo_modelo: str,
    modo_preprdc:  bool = True,
) -> Dict:
    """
    Evalúa una actividad específica del estándar VIRF.

    Usa Mx_03._llamar_modelo() para la llamada a la API.
    Aplica escala de puntaje 1-5 definida en config.py.

    Returns:
        {
          puntaje:             int (1-5),
          concepto:            str,
          observacion:         str,
          evidencia_encontrada:str,
          preguntas_pendientes:list[str],
          recomendacion:       str,
        }
    """
    preguntas_guia    = PREGUNTAS_METODOLOGICAS.get(ambito, [])
    contexto_feedback = construir_contexto_feedback(ambito, actividad)

    # ── Construir prompt de evaluación de actividad individual ────────────────
    bloque_feedback = (
        f"\nAPRENDIZAJE DE CORRIDAS ANTERIORES:\n{contexto_feedback}"
        if contexto_feedback else ""
    )
    bloque_modo = (
        "MODO: PRE-PRODUCCIÓN — proporciona evaluación detallada con puntaje, "
        "concepto técnico y observaciones."
        if modo_preprdc else
        "MODO: PRODUCCIÓN — proporciona evaluación final consolidada."
    )
    instruccion_dim = INSTRUCCIONES_DIMENSION.get(ambito, "")

    prompt = f"""
MODELO BAJO VALIDACIÓN: {titulo_modelo}
ÁMBITO: {ambito}
CONTROL/CRITERIO: {control}
ACTIVIDAD A EVALUAR: {actividad}

INSTRUCCIONES ESPECÍFICAS PARA ESTE ÁMBITO:
{instruccion_dim}

CONTEXTO DISPONIBLE (extractos de documentos, scripts y datos provistos):
{contexto[:6000] if contexto else "SIN CONTEXTO — No se encontraron archivos relevantes para este ámbito."}

PREGUNTAS GUÍA PARA ESTE ÁMBITO:
{chr(10).join(f"- {p}" for p in preguntas_guia)}
{bloque_feedback}

{bloque_modo}

ESCALA DE EVALUACIÓN (1-5):
1 = No cumple — evidencia ausente o completamente insuficiente
2 = Cumple parcialmente — observaciones críticas que requieren remediación inmediata
3 = Cumple parcialmente — brechas importantes pero no críticas
4 = Cumple con observaciones menores — mejoras recomendadas
5 = Cumple plenamente — evidencia sólida y suficiente

REGLA: Si no hay evidencia → NO asumir cumplimiento. Puntuar 1 o 2 y formular preguntas específicas.

Evalúa esta actividad y responde ÚNICAMENTE con este JSON (sin markdown):
{{
  "puntaje": <entero 1-5>,
  "concepto": "<qué evalúa técnicamente esta actividad y su importancia para el modelo — 1-2 oraciones>",
  "observacion": "<hallazgo basado en el contexto: qué se encontró, qué falta, riesgos. Mínimo 2 oraciones.>",
  "evidencia_encontrada": "<documentos o evidencias relevantes hallados, o 'No se encontró evidencia'>",
  "preguntas_pendientes": ["<pregunta específica al modelador si falta información>"],
  "recomendacion": "<acción concreta para subsanar brechas, si aplica>"
}}"""

    try:
        raw = _llamar_modelo(prompt)
        raw = re.sub(r"^```json\s*", "", raw)
        raw = re.sub(r"```$", "", raw).strip()
        resultado = json.loads(raw)
        resultado["puntaje"] = max(1, min(5, int(resultado.get("puntaje", 1))))
        return resultado

    except json.JSONDecodeError as e:
        return {
            "puntaje": 1,
            "concepto": f"Error al parsear respuesta: {e}",
            "observacion": f"Respuesta bruta: {raw[:300] if 'raw' in locals() else 'N/A'}",
            "evidencia_encontrada": "N/A",
            "preguntas_pendientes": ["Revisar manualmente esta actividad"],
            "recomendacion": "Reejecutar el agente con más contexto",
        }
    except Exception as e:
        return {
            "puntaje": 1,
            "concepto": "Error en evaluación",
            "observacion": str(e),
            "evidencia_encontrada": "N/A",
            "preguntas_pendientes": [],
            "recomendacion": "Verificar API key y conectividad",
        }


def evaluar_ambito_completo(
    ambito:        str,
    actividades:   List[Dict],
    contexto:      str,
    titulo_modelo: str,
    modo_preprdc:  bool = True,
) -> List[Dict]:
    """
    Evalúa todas las actividades requeridas de un ámbito.

    Args:
        ambito:        nombre del ámbito VIRF
        actividades:   lista de dicts con claves: actividad, control, requerida
        contexto:      texto concatenado de los documentos relevantes
        titulo_modelo: nombre del modelo bajo validación
        modo_preprdc:  True = preprdc, False = prdc

    Returns:
        Lista de dicts de evaluación, uno por actividad.
    """
    resultados = []
    for act in actividades:
        if not act.get("requerida", True):
            continue  # Saltar actividades no requeridas para este TIER
        print(f"  → {act['actividad'][:75]}...")
        resultado = evaluar_actividad(
            actividad     = act["actividad"],
            ambito        = ambito,
            control       = act.get("control", ""),
            contexto      = contexto,
            titulo_modelo = titulo_modelo,
            modo_preprdc  = modo_preprdc,
        )
        resultado["actividad"] = act["actividad"]
        resultado["control"]   = act.get("control", "")
        resultados.append(resultado)
    return resultados


# ══════════════════════════════════════════════════════════════════════════════
# RESUMEN EJECUTIVO — narrativa final del informe
# ══════════════════════════════════════════════════════════════════════════════

def generar_resumen_ejecutivo(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito:       Dict[str, float],
    score_global:            float,
    titulo_modelo:           str,
    tier:                    str,
) -> str:
    """
    Genera el resumen ejecutivo narrativo para el informe Word.

    Usa Mx_03._llamar_modelo() para la llamada a la API.
    Construye el prompt con los datos de evaluación por ámbito.

    Returns:
        Texto del informe en formato narrativo con secciones ### delimitadas.
    """
    resumen_input = json.dumps({
        "titulo":             titulo_modelo,
        "tier":               tier,
        "score_global":       score_global,
        "scores_por_ambito":  scores_por_ambito,
        "hallazgos": {
            ambito: [
                {
                    "actividad":           e["actividad"],
                    "puntaje":             e["puntaje"],
                    "observacion":         e["observacion"],
                    "preguntas_pendientes":e.get("preguntas_pendientes", []),
                }
                for e in evals
            ]
            for ambito, evals in evaluaciones_por_ambito.items()
        },
    }, ensure_ascii=False)

    prompt = f"""
Basándote en los resultados de validación del modelo {titulo_modelo} (Tier {tier}),
genera un INFORME EJECUTIVO DE VALIDACIÓN en español con la siguiente estructura:

### 1. RESUMEN EJECUTIVO
2-3 párrafos con score global {score_global:.2f}/5.0 y dictamen general.

### 2. HALLAZGOS POR ÁMBITO
Para cada ámbito: score, hallazgos principales, observaciones críticas.

### 3. PREGUNTAS Y REQUERIMIENTOS PENDIENTES
Lista consolidada de información solicitada al modelador.

### 4. PLAN DE REMEDIACIÓN
Priorización por criticidad: Alta / Media / Baja.

### 5. CONCLUSIÓN Y DICTAMEN FINAL
El dictamen debe ser uno de:
APROBADO / APROBADO CON CONDICIONES / OBSERVADO / RECHAZADO

Usa lenguaje técnico de validación de modelos de riesgo financiero.

DATOS DE EVALUACIÓN:
{resumen_input[:8000]}

Responde con el texto del informe en formato narrativo."""

    try:
        return _llamar_modelo(prompt, max_tokens=4096)
    except Exception as e:
        return f"[ERROR al generar resumen ejecutivo]: {e}"


# ══════════════════════════════════════════════════════════════════════════════
# MÉTRICAS Y SEMÁFORO
# ══════════════════════════════════════════════════════════════════════════════

def calcular_score_ambito(evaluaciones: List[Dict]) -> float:
    """Promedio simple de puntajes (1-5) de un ámbito."""
    if not evaluaciones:
        return 0.0
    return round(sum(e["puntaje"] for e in evaluaciones) / len(evaluaciones), 2)


def calcular_score_global(
    scores_por_ambito: Dict[str, float],
    pesos: Optional[Dict[str, float]] = None,
) -> float:
    """
    Score global ponderado por ámbito.

    Si no se pasan pesos explícitos usa AMBITO_PESOS de config.py.
    """
    _pesos = pesos or AMBITO_PESOS
    total, peso_acum = 0.0, 0.0
    for ambito, score in scores_por_ambito.items():
        peso       = _pesos.get(ambito, 1 / max(len(scores_por_ambito), 1))
        total      += score * peso
        peso_acum  += peso
    return round(total / peso_acum, 2) if peso_acum > 0 else 0.0


def get_semaforo(score: float) -> Dict:
    """
    Retorna label y color hex según el score (1-5).
    Usa SCORE_SEMAFORO de config.py.
    """
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score <= high:
            return info
    return {"label": "SIN CLASIFICAR", "color": "CCCCCC"}


# ══════════════════════════════════════════════════════════════════════════════
# RE-EXPORTAR INFRAESTRUCTURA Mx para quien importe motor_ia
# (evita que el resto del proyecto importe los Mx directamente)
# ══════════════════════════════════════════════════════════════════════════════

__all__ = [
    # Negocio
    "evaluar_actividad",
    "evaluar_ambito_completo",
    "generar_resumen_ejecutivo",
    "calcular_score_ambito",
    "calcular_score_global",
    "get_semaforo",
    # Mx_01 — lectura
    "leer_carpeta",
    "leer_repositorio_informes",
    "leer_estandares_virf",
    "cargar_todos_inputs",
    "inputs_para_dimension",
    # Mx_03 — IA
    "aprender_estilo",
    "generar_replica_virf",
    "generar_sintesis",
    # Mx_04 — controles de datos
    "detectar_cuestionamientos",
    "tiene_replica_virf",
    "calcular_riesgo_global",
    "resumen_cuestionamientos_consola",
    # Constantes
    "RUTAS",
    "AMBITO_A_INPUTS",
    "INSTRUCCIONES_DIMENSION",
    "MODO_PREPRDC",
    "MODO_PRDC",
    "UMBRAL_RIESGO_GLOBAL",
]
