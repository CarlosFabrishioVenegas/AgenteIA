"""
modulos/generador_estadistica_feedback.py
Genera un informe Excel de precisión del agente basado en el historial de feedback.
Se invoca con: python agente.py --estadisticafeedback
"""

import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference
from openpyxl.chart.series import SeriesLabel
from datetime import datetime
from pathlib import Path
from typing import Dict, List

from modulos.feedback import calcular_estadisticas, cargar_historial
from config import OUTPUTS_DIR


def _fill(hex_color): return PatternFill("solid", fgColor=hex_color)
def _font(bold=False, color="000000", size=10, italic=False):
    return Font(bold=bold, color=color, size=size, italic=italic, name="Arial")
def _align(h="center", wrap=False): return Alignment(horizontal=h, vertical="center", wrap_text=wrap)
def _border():
    s = Side(style="thin", color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)

AZUL   = "1F3864"
AZUL2  = "2E75B6"
VERDE  = "00B050"
ROJO   = "FF0000"
NARANJ = "FF6600"
AMAR   = "FFCC00"
GRIS   = "F2F2F2"
BLANCO = "FFFFFF"


def _color_mae(mae: float) -> str:
    if mae <= 0.3:   return VERDE
    if mae <= 0.7:   return "92D050"
    if mae <= 1.0:   return AMAR
    if mae <= 1.5:   return NARANJ
    return ROJO


def _color_pct(pct: float) -> str:
    if pct >= 85:  return VERDE
    if pct >= 70:  return "92D050"
    if pct >= 55:  return AMAR
    if pct >= 40:  return NARANJ
    return ROJO


def generar_informe_estadistica(outputs_dir: Path = OUTPUTS_DIR) -> Path:
    stats = calcular_estadisticas()
    historial = cargar_historial()

    if "error" in stats:
        print(f"  [!] {stats['error']}")
        return None

    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")
    ruta = outputs_dir / f"VIRF_EstadisticaFeedback_{fecha_str}.xlsx"

    wb = openpyxl.Workbook()

    # ── Pestaña 1: RESUMEN EJECUTIVO ─────────────────────────────────────────
    ws = wb.active
    ws.title = "RESUMEN"
    ws.sheet_view.showGridLines = False

    # Título
    ws.merge_cells("A1:H1")
    ws["A1"] = f"INFORME DE PRECISIÓN DEL AGENTE VIRF — Generado {now.strftime('%d/%m/%Y %H:%M')}"
    ws["A1"].font = _font(bold=True, color=BLANCO, size=14)
    ws["A1"].fill = _fill(AZUL)
    ws["A1"].alignment = _align()
    ws.row_dimensions[1].height = 35

    ws.merge_cells("A2:H2")
    ws["A2"] = f"Basado en {stats['total_feedbacks']} evaluaciones corregidas | {stats['primer_feedback']} → {stats['ultimo_feedback']}"
    ws["A2"].font = _font(italic=True, color=BLANCO, size=10)
    ws["A2"].fill = _fill(AZUL2)
    ws["A2"].alignment = _align()
    ws.row_dimensions[2].height = 20

    # KPIs principales
    kpis = [
        ("Total feedbacks",         stats["total_feedbacks"],            AZUL2,  BLANCO),
        ("Evaluaciones exactas",     f"{stats['pct_exactas']}%",          _color_pct(stats['pct_exactas']), BLANCO),
        ("Dentro de ±1 punto",       f"{stats['pct_dentro_1_punto']}%",   _color_pct(stats['pct_dentro_1_punto']), BLANCO),
        ("MAE (error promedio)",     stats["mae"],                        _color_mae(stats['mae']), BLANCO),
        ("Sesgo",                    stats["sesgo_promedio"],             AZUL2,  BLANCO),
        ("Interpretación sesgo",     stats["sesgo_interpretacion"],       AZUL,   BLANCO),
    ]

    ws.row_dimensions[4].height = 18
    ws.merge_cells("A4:H4")
    ws["A4"] = "INDICADORES CLAVE DE PRECISIÓN"
    ws["A4"].font = _font(bold=True, color=AZUL, size=11)
    ws["A4"].alignment = _align()

    for i, (label, valor, bg, fg) in enumerate(kpis):
        col = i + 1
        ws.column_dimensions[get_column_letter(col)].width = 20
        r_label = ws.cell(5, col, label)
        r_label.font = _font(bold=True, color=BLANCO, size=9)
        r_label.fill = _fill(AZUL)
        r_label.alignment = _align(wrap=True)
        r_label.border = _border()
        ws.row_dimensions[5].height = 28

        r_val = ws.cell(6, col, valor)
        r_val.font = _font(bold=True, color=fg, size=14)
        r_val.fill = _fill(bg)
        r_val.alignment = _align()
        r_val.border = _border()
        ws.row_dimensions[6].height = 38

    # Distribución de diferencias
    ws.row_dimensions[8].height = 20
    ws.merge_cells("A8:H8")
    ws["A8"] = "DISTRIBUCIÓN DE DIFERENCIAS (puntaje correcto − puntaje agente)"
    ws["A8"].font = _font(bold=True, color=AZUL, size=11)
    ws["A8"].alignment = _align()

    dist_headers = ["CATEGORÍA", "N° CASOS", "% DEL TOTAL", "INTERPRETACIÓN"]
    dist_data = [
        ("Exacto (diferencia = 0)",  stats["evaluaciones_exactas"], stats["pct_exactas"],   "Agente coincidió perfectamente"),
        ("Diferencia de 1 punto",    stats["diferencia_1_punto"],   stats["pct_diff_1"],    "Error leve, aceptable"),
        ("Diferencia ≥ 2 puntos",    stats["diferencia_2_o_mas"],   stats["pct_diff_2_mas"],"Error significativo"),
        ("Sobreestimaciones",        stats["n_sobreestimaciones"],  round(stats["n_sobreestimaciones"]/stats["total_feedbacks"]*100,1), "Agente dio puntaje mayor al correcto"),
        ("Subestimaciones",          stats["n_subestimaciones"],    round(stats["n_subestimaciones"]/stats["total_feedbacks"]*100,1),   "Agente dio puntaje menor al correcto"),
    ]
    col_w = [35, 12, 14, 40]
    for ci, (h, w) in enumerate(zip(dist_headers, col_w), start=1):
        c = ws.cell(9, ci, h)
        c.font = _font(bold=True, color=BLANCO, size=9)
        c.fill = _fill(AZUL2)
        c.alignment = _align()
        c.border = _border()
        ws.column_dimensions[get_column_letter(ci)].width = w
    ws.row_dimensions[9].height = 22

    color_dist = [VERDE, "92D050", NARANJ, ROJO, AMAR]
    for ri, (row_data, color) in enumerate(zip(dist_data, color_dist), start=10):
        fill = _fill(GRIS) if ri % 2 == 0 else _fill(BLANCO)
        for ci, val in enumerate(row_data, start=1):
            c = ws.cell(ri, ci, f"{val}%" if ci == 3 else val)
            c.font = _font(size=9)
            c.fill = fill
            c.alignment = _align("left" if ci in (1, 4) else "center")
            c.border = _border()
        # Color en columna N° CASOS
        ws.cell(ri, 2).fill = _fill(color)
        ws.cell(ri, 2).font = _font(bold=True, color=BLANCO, size=10)
        ws.row_dimensions[ri].height = 18

    # ── Pestaña 2: POR ÁMBITO ────────────────────────────────────────────────
    ws2 = wb.create_sheet("POR ÁMBITO")
    ws2.sheet_view.showGridLines = False

    ws2.merge_cells("A1:G1")
    ws2["A1"] = "PRECISIÓN DEL AGENTE POR ÁMBITO"
    ws2["A1"].font = _font(bold=True, color=BLANCO, size=13)
    ws2["A1"].fill = _fill(AZUL)
    ws2["A1"].alignment = _align()
    ws2.row_dimensions[1].height = 30

    headers_amb = ["ÁMBITO", "TOTAL FEEDBACKS", "EXACTOS (%)", "DENTRO ±1 (%)", "MAE", "SESGO", "INTERPRETACIÓN SESGO"]
    widths_amb  = [35,        16,                15,             15,              10,    10,      30]
    for ci, (h, w) in enumerate(zip(headers_amb, widths_amb), start=1):
        c = ws2.cell(2, ci, h)
        c.font = _font(bold=True, color=BLANCO, size=9)
        c.fill = _fill(AZUL2)
        c.alignment = _align(wrap=True)
        c.border = _border()
        ws2.column_dimensions[get_column_letter(ci)].width = w
    ws2.row_dimensions[2].height = 30

    for ri, (ambito, s) in enumerate(stats["por_ambito"].items(), start=3):
        fill = _fill(GRIS) if ri % 2 == 0 else _fill(BLANCO)
        sesgo_interp = "Subestima" if s["sesgo"] > 0.2 else "Sobreestima" if s["sesgo"] < -0.2 else "Calibrado"
        row_data = [
            ambito, s["total"], f"{s['pct_exactos']}%",
            f"{s['pct_1_punto']}%", s["mae"], s["sesgo"], sesgo_interp
        ]
        for ci, val in enumerate(row_data, start=1):
            c = ws2.cell(ri, ci, val)
            c.font = _font(size=9)
            c.fill = fill
            c.alignment = _align("left" if ci == 1 else "center")
            c.border = _border()
        # Colorear MAE y % exactos
        ws2.cell(ri, 3).fill = _fill(_color_pct(s["pct_exactos"]))
        ws2.cell(ri, 3).font = _font(bold=True, color=BLANCO, size=9)
        ws2.cell(ri, 4).fill = _fill(_color_pct(s["pct_1_punto"]))
        ws2.cell(ri, 4).font = _font(bold=True, color=BLANCO, size=9)
        ws2.cell(ri, 5).fill = _fill(_color_mae(s["mae"]))
        ws2.cell(ri, 5).font = _font(bold=True, color=BLANCO, size=9)
        ws2.row_dimensions[ri].height = 20

    # ── Pestaña 3: HISTORIAL COMPLETO ────────────────────────────────────────
    ws3 = wb.create_sheet("HISTORIAL")
    ws3.sheet_view.showGridLines = False

    ws3.merge_cells("A1:J1")
    ws3["A1"] = "HISTORIAL COMPLETO DE FEEDBACK"
    ws3["A1"].font = _font(bold=True, color=BLANCO, size=13)
    ws3["A1"].fill = _fill(AZUL)
    ws3["A1"].alignment = _align()
    ws3.row_dimensions[1].height = 28

    hist_headers = ["FECHA", "MODELO", "TIER", "VERSIÓN", "ÁMBITO", "ACTIVIDAD",
                    "PUNTAJE AGENTE", "PUNTAJE CORRECTO", "DIFERENCIA", "COMENTARIO"]
    hist_widths  = [18, 20, 8, 10, 25, 55, 15, 16, 12, 50]

    for ci, (h, w) in enumerate(zip(hist_headers, hist_widths), start=1):
        c = ws3.cell(2, ci, h)
        c.font = _font(bold=True, color=BLANCO, size=8)
        c.fill = _fill(AZUL2)
        c.alignment = _align(wrap=True)
        c.border = _border()
        ws3.column_dimensions[get_column_letter(ci)].width = w
    ws3.row_dimensions[2].height = 30

    for ri, fb in enumerate(historial, start=3):
        diff = fb.get("diferencia", 0)
        fill = _fill(GRIS) if ri % 2 == 0 else _fill(BLANCO)
        row_data = [
            fb.get("fecha", ""), fb.get("titulo_modelo", ""), fb.get("tier", ""),
            fb.get("version", ""), fb.get("ambito", ""), fb.get("actividad", "")[:80],
            fb.get("puntaje_agente", ""), fb.get("puntaje_correcto", ""),
            f"{'+' if diff > 0 else ''}{diff}", fb.get("comentario", "")
        ]
        for ci, val in enumerate(row_data, start=1):
            c = ws3.cell(ri, ci, val)
            c.font = _font(size=8)
            c.fill = fill
            c.alignment = _align("left" if ci in (5, 6, 10) else "center", wrap=(ci == 10))
            c.border = _border()
        # Colorear diferencia
        color_diff = VERDE if diff == 0 else (AMAR if abs(diff) == 1 else ROJO)
        ws3.cell(ri, 9).fill = _fill(color_diff)
        ws3.cell(ri, 9).font = _font(bold=True, color=BLANCO, size=9)
        ws3.row_dimensions[ri].height = 35

    outputs_dir.mkdir(parents=True, exist_ok=True)
    wb.save(ruta)
    print(f"  ✓ Informe de estadísticas generado: {ruta}")
    return ruta
