"""
modulos/generador_excel.py
Genera VIRF_Resultados_*.xlsx con:
  - Pestaña 1: Resumen ejecutivo con scores por ámbito + score global
  - Pestaña 2: Tracking de validación (actividad x actividad con historial de versiones)
  - Pestaña 3+: Detalle por ámbito
"""

import openpyxl
from openpyxl.styles import (
    PatternFill, Font, Alignment, Border, Side, GradientFill
)
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import re

from config import ESCALA_PUNTAJE, SCORE_SEMAFORO, AMBITO_PESOS


# ─── Estilos helpers ─────────────────────────────────────────────────────────

def _fill(hex_color: str) -> PatternFill:
    return PatternFill("solid", fgColor=hex_color)

def _font(bold=False, color="000000", size=11, italic=False) -> Font:
    return Font(bold=bold, color=color, size=size, italic=italic, name="Arial")

def _align(h="left", v="center", wrap=False) -> Alignment:
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def _border_all() -> Border:
    s = Side(style="thin", color="CCCCCC")
    return Border(left=s, right=s, top=s, bottom=s)

def _border_medium() -> Border:
    s = Side(style="medium", color="404040")
    return Border(left=s, right=s, top=s, bottom=s)

HEADER_FILL   = _fill("1F3864")   # Azul oscuro corporativo
SUBHEAD_FILL  = _fill("2E75B6")   # Azul medio
ALT_ROW_FILL  = _fill("EBF3FB")   # Azul muy claro (filas alternadas)
WHITE_FILL    = _fill("FFFFFF")
GOLD_FILL     = _fill("FFD700")


def _color_score(score: float) -> str:
    """Retorna hex según puntaje 1-5."""
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score <= high:
            return info["color"]
    return "CCCCCC"


def _color_puntaje_celda(puntaje: int) -> str:
    return ESCALA_PUNTAJE.get(puntaje, {}).get("color", "CCCCCC")


def _label_semaforo(score: float) -> str:
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score <= high:
            return info["label"]
    return "SIN CLASIFICAR"


# ─── Pestaña 1: RESUMEN ──────────────────────────────────────────────────────

def _crear_hoja_resumen(wb, titulo_modelo: str, tier: str,
                         scores_por_ambito: Dict[str, float],
                         score_global: float, fecha_str: str, version: str):
    ws = wb.active
    ws.title = "RESUMEN"
    ws.sheet_view.showGridLines = False

    # Cabecera principal
    ws.merge_cells("A1:H1")
    ws["A1"] = f"INFORME DE VALIDACIÓN VIRF — {titulo_modelo.upper()}"
    ws["A1"].font = _font(bold=True, color="FFFFFF", size=14)
    ws["A1"].fill = HEADER_FILL
    ws["A1"].alignment = _align("center")
    ws.row_dimensions[1].height = 35

    ws.merge_cells("A2:H2")
    ws["A2"] = f"Tier {tier}  |  Fecha de corrida: {fecha_str}  |  Versión: {version}"
    ws["A2"].font = _font(italic=True, color="FFFFFF", size=10)
    ws["A2"].fill = SUBHEAD_FILL
    ws["A2"].alignment = _align("center")
    ws.row_dimensions[2].height = 20

    # Score global
    ws.merge_cells("A4:C4")
    ws["A4"] = "SCORE GLOBAL PONDERADO"
    ws["A4"].font = _font(bold=True, size=11)
    ws["A4"].fill = _fill("D6E4F0")
    ws["A4"].alignment = _align("center")

    ws.merge_cells("D4:E4")
    ws["D4"] = round(score_global, 2)
    ws["D4"].font = _font(bold=True, size=20, color="FFFFFF")
    ws["D4"].fill = _fill(_color_score(score_global))
    ws["D4"].alignment = _align("center")

    ws.merge_cells("F4:H4")
    ws["F4"] = _label_semaforo(score_global)
    ws["F4"].font = _font(bold=True, size=13, color="FFFFFF")
    ws["F4"].fill = _fill(_color_score(score_global))
    ws["F4"].alignment = _align("center")
    ws.row_dimensions[4].height = 45

    # Cabecera tabla ámbitos
    ws.row_dimensions[6].height = 22
    headers = ["ÁMBITO", "PESO (%)", "SCORE", "SEMÁFORO", "ESTADO", "PUNTAJE PONDERADO"]
    cols_w = [35, 12, 10, 20, 25, 20]
    for col_letters, (h, w) in enumerate(zip(headers, cols_w), start=1):
        c = ws.cell(row=6, column=col_letters, value=h)
        c.font = _font(bold=True, color="FFFFFF", size=10)
        c.fill = HEADER_FILL
        c.alignment = _align("center")
        c.border = _border_all()
        ws.column_dimensions[get_column_letter(col_letters)].width = w

    # Filas por ámbito
    for i, (ambito, score) in enumerate(scores_por_ambito.items(), start=7):
        peso = AMBITO_PESOS.get(ambito, 0)
        ponderado = score * peso
        row_fill = ALT_ROW_FILL if i % 2 == 0 else WHITE_FILL  # BUG FIX: renamed to avoid shadowing _fill()

        data = [ambito, f"{peso*100:.0f}%", round(score, 2),
                "●" * round(score) + "○" * (5 - round(score)),
                _label_semaforo(score), round(ponderado, 3)]

        for col, val in enumerate(data, start=1):
            c = ws.cell(row=i, column=col, value=val)
            c.font = _font(size=10)
            c.alignment = _align("center" if col > 1 else "left")
            c.border = _border_all()
            if col == 3:  # Score numérico
                c.fill = _fill(_color_score(score))
                c.font = _font(bold=True, color="FFFFFF", size=11)
            elif col == 5:  # Estado texto
                c.fill = _fill(_color_score(score))
                c.font = _font(bold=True, color="FFFFFF", size=9)
            else:
                c.fill = row_fill
        ws.row_dimensions[i].height = 20

    # Leyenda escala
    last_row = 7 + len(scores_por_ambito) + 2
    ws.merge_cells(f"A{last_row}:H{last_row}")
    ws.cell(last_row, 1, "ESCALA DE PUNTAJE").font = _font(bold=True, size=10)
    ws.cell(last_row, 1).fill = _fill("D6E4F0")
    ws.cell(last_row, 1).alignment = _align("center")

    for j, (puntaje, info) in enumerate(ESCALA_PUNTAJE.items(), start=last_row+1):
        c1 = ws.cell(j, 1, f"{puntaje} - {info['label']}")
        c1.fill = _fill(info['color'])
        c1.font = _font(bold=True, color="FFFFFF", size=9)
        c1.alignment = _align("center")
        ws.merge_cells(f"A{j}:H{j}")
        ws.row_dimensions[j].height = 16


# ─── Pestaña 2: TRACKING ─────────────────────────────────────────────────────

def _crear_hoja_tracking(wb, evaluaciones_por_ambito: Dict[str, List[Dict]],
                          scores_por_ambito: Dict[str, float],
                          score_global: float,
                          fecha_str: str, version: str,
                          titulo_modelo: str, tier: str,
                          historial_versiones: Optional[List[Dict]] = None):
    ws = wb.create_sheet("TRACKING VALIDACIÓN")
    ws.sheet_view.showGridLines = False

    # Título
    ws.merge_cells("A1:L1")
    ws["A1"] = f"TRACKING DE VALIDACIÓN — {titulo_modelo} | Tier {tier} | {fecha_str} | {version}"
    ws["A1"].font = _font(bold=True, color="FFFFFF", size=12)
    ws["A1"].fill = HEADER_FILL
    ws["A1"].alignment = _align("center")
    ws.row_dimensions[1].height = 30

    # Cabecera columnas
    headers = [
        "ÁMBITO", "CONTROL/CRITERIO", "ACTIVIDAD",
        "PUNTAJE", "SEMÁFORO", "CONCEPTO",
        "OBSERVACIÓN / HALLAZGO", "EVIDENCIA ENCONTRADA",
        "PREGUNTAS PENDIENTES", "RECOMENDACIÓN",
        f"VALIDACIÓN-{fecha_str}_{version}",
        "ESTADO CIERRE"
    ]
    col_widths = [20, 35, 45, 10, 18, 35, 50, 30, 40, 40, 22, 18]

    for col, (h, w) in enumerate(zip(headers, col_widths), start=1):
        c = ws.cell(2, col, h)
        c.font = _font(bold=True, color="FFFFFF", size=9)
        c.fill = SUBHEAD_FILL
        c.alignment = _align("center", wrap=True)
        c.border = _border_all()
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.row_dimensions[2].height = 40

    row = 3
    for ambito, evals in evaluaciones_por_ambito.items():
        ambito_start = row
        for i, ev in enumerate(evals):
            puntaje = ev.get("puntaje", 1)
            color_p = _color_puntaje_celda(puntaje)
            row_fill = ALT_ROW_FILL if i % 2 == 0 else WHITE_FILL  # BUG FIX: renamed

            preguntas = "\n".join(ev.get("preguntas_pendientes", []))
            estado_cierre = "ABIERTO" if ev.get("preguntas_pendientes") else "CERRADO"

            vals = [
                ambito,
                ev.get("control", ""),
                ev.get("actividad", ""),
                puntaje,
                _label_semaforo(puntaje),
                ev.get("concepto", ""),
                ev.get("observacion", ""),
                ev.get("evidencia_encontrada", ""),
                preguntas,
                ev.get("recomendacion", ""),
                f"Ejecutado {fecha_str}",
                estado_cierre,
            ]

            for col, val in enumerate(vals, start=1):
                c = ws.cell(row, col, val)
                c.font = _font(size=9)
                c.alignment = _align("left", wrap=True)
                c.border = _border_all()

                if col == 1:
                    # BUG FIX: eliminar asignación doble de font (la primera era sobreescrita)
                    c.fill = _fill("2E75B6")
                    c.font = Font(bold=True, color="FFFFFF", size=9, name="Arial")
                elif col == 4:
                    c.fill = _fill(color_p)
                    c.font = _font(bold=True, color="FFFFFF", size=11)
                    c.alignment = _align("center")
                elif col == 5:
                    c.fill = _fill(color_p)
                    c.font = _font(bold=True, color="FFFFFF", size=9)
                    c.alignment = _align("center")
                elif col == 12:
                    c.fill = _fill("FF0000") if estado_cierre == "ABIERTO" else _fill("00B050")
                    c.font = _font(bold=True, color="FFFFFF", size=9)
                    c.alignment = _align("center")
                else:
                    c.fill = row_fill

            ws.row_dimensions[row].height = 60
            row += 1

        # Separador por ámbito
        ws.row_dimensions[row].height = 8
        row += 1

    # Tabla resumen final de scores al final del tracking
    row += 1
    ws.merge_cells(f"A{row}:L{row}")
    ws.cell(row, 1, "RESUMEN DE SCORES POR ÁMBITO").font = _font(bold=True, color="FFFFFF", size=11)
    ws.cell(row, 1).fill = HEADER_FILL
    ws.cell(row, 1).alignment = _align("center")
    ws.row_dimensions[row].height = 25
    row += 1

    for ambito, score in scores_por_ambito.items():
        ws.merge_cells(f"A{row}:E{row}")
        ws.cell(row, 1, ambito).font = _font(bold=True, size=10)
        ws.cell(row, 1).fill = _fill("D6E4F0")
        ws.cell(row, 1).alignment = _align("left")

        ws.merge_cells(f"F{row}:H{row}")
        ws.cell(row, 6, round(score, 2)).font = _font(bold=True, color="FFFFFF", size=12)
        ws.cell(row, 6).fill = _fill(_color_score(score))
        ws.cell(row, 6).alignment = _align("center")

        ws.merge_cells(f"I{row}:L{row}")
        ws.cell(row, 9, _label_semaforo(score)).font = _font(bold=True, color="FFFFFF", size=10)
        ws.cell(row, 9).fill = _fill(_color_score(score))
        ws.cell(row, 9).alignment = _align("center")
        ws.row_dimensions[row].height = 22
        row += 1

    # Score global
    row += 1
    ws.merge_cells(f"A{row}:E{row}")
    ws.cell(row, 1, "SCORE GLOBAL PONDERADO").font = _font(bold=True, color="FFFFFF", size=12)
    ws.cell(row, 1).fill = HEADER_FILL
    ws.cell(row, 1).alignment = _align("center")

    ws.merge_cells(f"F{row}:H{row}")
    ws.cell(row, 6, round(score_global, 2)).font = _font(bold=True, color="FFFFFF", size=16)
    ws.cell(row, 6).fill = _fill(_color_score(score_global))
    ws.cell(row, 6).alignment = _align("center")

    ws.merge_cells(f"I{row}:L{row}")
    ws.cell(row, 9, _label_semaforo(score_global)).font = _font(bold=True, color="FFFFFF", size=13)
    ws.cell(row, 9).fill = _fill(_color_score(score_global))
    ws.cell(row, 9).alignment = _align("center")
    ws.row_dimensions[row].height = 40


# ─── Pestañas de detalle por ámbito ──────────────────────────────────────────

def _crear_hoja_ambito(wb, ambito: str, evaluaciones: List[Dict],
                        score_ambito: float, fecha_str: str, version: str):
    nombre_hoja = ambito[:25].replace("/", "-").replace("\\", "-")
    ws = wb.create_sheet(nombre_hoja)
    ws.sheet_view.showGridLines = False

    ws.merge_cells("A1:G1")
    ws["A1"] = f"{ambito.upper()} — Score: {round(score_ambito, 2)}/5.0 — {_label_semaforo(score_ambito)}"
    ws["A1"].font = _font(bold=True, color="FFFFFF", size=12)
    ws["A1"].fill = _fill(_color_score(score_ambito))
    ws["A1"].alignment = _align("center")
    ws.row_dimensions[1].height = 28

    headers = ["N°", "ACTIVIDAD", "PUNTAJE", "CONCEPTO", "OBSERVACIÓN", "PREGUNTAS PENDIENTES", "RECOMENDACIÓN"]
    widths   = [5,    55,          10,        40,          55,            45,                      45]

    for col, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(2, col, h)
        c.font = _font(bold=True, color="FFFFFF", size=9)
        c.fill = SUBHEAD_FILL
        c.alignment = _align("center", wrap=True)
        c.border = _border_all()
        ws.column_dimensions[get_column_letter(col)].width = w
    ws.row_dimensions[2].height = 35

    for i, ev in enumerate(evaluaciones, start=1):
        puntaje = ev.get("puntaje", 1)
        row = i + 2
        row_fill = ALT_ROW_FILL if i % 2 == 0 else WHITE_FILL  # BUG FIX: renamed
        preguntas = "\n• ".join(ev.get("preguntas_pendientes", []))

        vals = [
            i,
            ev.get("actividad", ""),
            puntaje,
            ev.get("concepto", ""),
            ev.get("observacion", ""),
            preguntas,
            ev.get("recomendacion", ""),
        ]
        for col, val in enumerate(vals, start=1):
            c = ws.cell(row, col, val)
            c.font = _font(size=9)
            c.alignment = _align("left", wrap=True)
            c.border = _border_all()
            if col == 3:
                c.fill = _fill(_color_puntaje_celda(puntaje))
                c.font = _font(bold=True, color="FFFFFF", size=11)
                c.alignment = _align("center")
            else:
                c.fill = row_fill
        ws.row_dimensions[row].height = 55


# ─── FUNCIÓN PRINCIPAL ───────────────────────────────────────────────────────

def generar_excel_resultados(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito: Dict[str, float],
    score_global: float,
    titulo_modelo: str,
    tier: str,
    outputs_dir: Path,
    historial_versiones: Optional[List[Dict]] = None,
) -> Path:
    """Genera el archivo Excel completo de resultados VIRF."""

    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")

    # Determinar versión (V1, V2... si ya existe el mismo día)
    patron = f"VIRF_Resultados_{titulo_modelo.replace(' ', '_')}_{fecha_str}_V*.xlsx"
    existentes = list(outputs_dir.glob(patron))
    version_num = len(existentes) + 1
    version = f"V{version_num}"

    nombre_archivo = f"VIRF_Resultados_{titulo_modelo.replace(' ', '_')}_{fecha_str}_{version}.xlsx"
    ruta_salida = outputs_dir / nombre_archivo

    wb = openpyxl.Workbook()

    # Pestaña 1: Resumen
    _crear_hoja_resumen(wb, titulo_modelo, tier, scores_por_ambito,
                         score_global, fecha_str, version)

    # Pestaña 2: Tracking
    _crear_hoja_tracking(wb, evaluaciones_por_ambito, scores_por_ambito,
                          score_global, fecha_str, version,
                          titulo_modelo, tier, historial_versiones)

    # Pestañas por ámbito
    for ambito, evals in evaluaciones_por_ambito.items():
        score = scores_por_ambito.get(ambito, 0)
        _crear_hoja_ambito(wb, ambito, evals, score, fecha_str, version)

    outputs_dir.mkdir(parents=True, exist_ok=True)
    wb.save(ruta_salida)
    print(f"  ✓ Excel generado: {ruta_salida}")
    return ruta_salida
