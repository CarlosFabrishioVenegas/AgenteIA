"""
modulos/generador_word.py
Genera VIRF_Informe_*.docx — Informe narrativo consolidado de validación (modo --prdc)
"""

from docx import Document
from docx.shared import Pt, RGBColor, Cm, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import re

from config import ESCALA_PUNTAJE, SCORE_SEMAFORO, AMBITO_PESOS


# ─── Colores corporativos ─────────────────────────────────────────────────────
AZUL_DARK  = RGBColor(0x1F, 0x38, 0x64)
AZUL_MID   = RGBColor(0x2E, 0x75, 0xB6)
GRIS_TEXT  = RGBColor(0x40, 0x40, 0x40)
BLANCO     = RGBColor(0xFF, 0xFF, 0xFF)


def _hex_to_rgb(hex_str: str) -> RGBColor:
    h = hex_str.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _score_color(score: float) -> RGBColor:
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score <= high:
            return _hex_to_rgb(info["color"])
    return RGBColor(0xCC, 0xCC, 0xCC)


def _label_semaforo(score: float) -> str:
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score <= high:
            return info["label"]
    return "SIN CLASIFICAR"


def _set_cell_bg(cell, hex_color: str):
    """Relleno de fondo en celda de tabla Word."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color.upper())
    tcPr.append(shd)


def _add_heading(doc: Document, text: str, level: int = 1):
    p = doc.add_heading(text, level=level)
    for run in p.runs:
        run.font.color.rgb = AZUL_DARK if level == 1 else AZUL_MID
        run.font.name = "Arial"
    return p


def _add_paragraph(doc: Document, text: str, bold=False, italic=False,
                    color: Optional[RGBColor] = None, size: int = 10):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    run.font.name = "Arial"
    if color:
        run.font.color.rgb = color
    else:
        run.font.color.rgb = GRIS_TEXT
    return p


def _tabla_scores(doc: Document, scores_por_ambito: Dict[str, float],
                   score_global: float):
    """Tabla resumen de scores con semáforos."""
    tabla = doc.add_table(rows=1, cols=4)
    tabla.style = "Table Grid"
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Encabezado
    headers = ["ÁMBITO", "PESO", "SCORE", "DICTAMEN"]
    widths_cm = [7, 2.5, 2.5, 5]
    hdr_cells = tabla.rows[0].cells
    for i, (h, w) in enumerate(zip(headers, widths_cm)):
        hdr_cells[i].text = h
        hdr_cells[i].paragraphs[0].runs[0].font.bold = True
        hdr_cells[i].paragraphs[0].runs[0].font.color.rgb = BLANCO
        hdr_cells[i].paragraphs[0].runs[0].font.size = Pt(9)
        hdr_cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_cell_bg(hdr_cells[i], "1F3864")
        hdr_cells[i].width = Cm(w)

    for ambito, score in scores_por_ambito.items():
        peso = AMBITO_PESOS.get(ambito, 0)
        row_cells = tabla.add_row().cells
        data = [str(ambito or ""), f"{peso*100:.0f}%", f"{score:.2f}", _label_semaforo(score)]  # BUG FIX: None-safe
        color_hex = ""
        for (low, high), info in SCORE_SEMAFORO.items():
            if low <= score <= high:
                color_hex = info["color"]
        for i, val in enumerate(data):
            row_cells[i].text = val
            row_cells[i].paragraphs[0].runs[0].font.size = Pt(9)
            row_cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER if i > 0 else WD_ALIGN_PARAGRAPH.LEFT
            if i in (2, 3) and color_hex:
                _set_cell_bg(row_cells[i], color_hex)
                row_cells[i].paragraphs[0].runs[0].font.color.rgb = BLANCO
                row_cells[i].paragraphs[0].runs[0].font.bold = True

    # Fila score global
    row_global = tabla.add_row().cells
    color_global = ""
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score_global <= high:
            color_global = info["color"]

    row_global[0].merge(row_global[1])
    row_global[0].text = "SCORE GLOBAL PONDERADO"
    row_global[0].paragraphs[0].runs[0].font.bold = True
    row_global[0].paragraphs[0].runs[0].font.color.rgb = BLANCO
    row_global[0].paragraphs[0].runs[0].font.size = Pt(10)
    _set_cell_bg(row_global[0], "1F3864")

    row_global[2].text = f"{score_global:.2f}"
    row_global[2].paragraphs[0].runs[0].font.bold = True
    row_global[2].paragraphs[0].runs[0].font.color.rgb = BLANCO
    row_global[2].paragraphs[0].runs[0].font.size = Pt(12)
    row_global[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_cell_bg(row_global[2], color_global)

    row_global[3].text = _label_semaforo(score_global)
    row_global[3].paragraphs[0].runs[0].font.bold = True
    row_global[3].paragraphs[0].runs[0].font.color.rgb = BLANCO
    row_global[3].paragraphs[0].runs[0].font.size = Pt(11)
    row_global[3].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    _set_cell_bg(row_global[3], color_global)

    doc.add_paragraph()


def _seccion_ambito(doc: Document, ambito: str,
                     evaluaciones: List[Dict], score: float):
    """Sección detallada de un ámbito."""
    _add_heading(doc, f"{ambito}  —  {score:.2f}/5.0  ({_label_semaforo(score)})", level=2)

    # Tabla de actividades del ámbito
    tabla = doc.add_table(rows=1, cols=4)
    tabla.style = "Table Grid"
    headers = ["ACTIVIDAD", "PUNTAJE", "HALLAZGO", "PREGUNTAS PENDIENTES"]
    widths_cm = [6, 2, 8, 6]
    for i, (h, w) in enumerate(zip(headers, widths_cm)):
        cell = tabla.rows[0].cells[i]
        cell.text = h
        cell.paragraphs[0].runs[0].font.bold = True
        cell.paragraphs[0].runs[0].font.color.rgb = BLANCO
        cell.paragraphs[0].runs[0].font.size = Pt(8)
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        _set_cell_bg(cell, "2E75B6")
        cell.width = Cm(w)

    for ev in evaluaciones:
        puntaje = ev.get("puntaje", 1)
        color_hex = ESCALA_PUNTAJE.get(puntaje, {}).get("color", "CCCCCC")
        preguntas = "\n• ".join(ev.get("preguntas_pendientes", []))

        row_cells = tabla.add_row().cells
        # BUG FIX: forzar string para evitar crash si el campo es None
        row_cells[0].text = str(ev.get("actividad") or "")
        row_cells[1].text = str(puntaje)
        row_cells[2].text = str(ev.get("observacion") or "")
        row_cells[3].text = preguntas if preguntas else "—"

        for i, cell in enumerate(row_cells):
            cell.paragraphs[0].runs[0].font.size = Pt(8)
            if i == 1:
                cell.paragraphs[0].runs[0].font.bold = True
                cell.paragraphs[0].runs[0].font.color.rgb = BLANCO
                cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                _set_cell_bg(cell, color_hex)

    doc.add_paragraph()


def generar_word_informe(
    resumen_ejecutivo: str,
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito: Dict[str, float],
    score_global: float,
    titulo_modelo: str,
    tier: str,
    outputs_dir: Path,
) -> Path:
    """Genera el informe Word consolidado (modo --prdc)."""

    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")
    nombre = f"VIRF_Informe_{titulo_modelo.replace(' ', '_')}_{fecha_str}.docx"
    ruta = outputs_dir / nombre

    doc = Document()

    # Configurar márgenes
    for section in doc.sections:
        section.top_margin    = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin   = Cm(3.0)
        section.right_margin  = Cm(2.5)

    # ── Portada ──────────────────────────────────────────────────────────────
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run(f"\n\n\nINFORME DE VALIDACIÓN VIRF")
    run.font.size = Pt(22)
    run.font.bold = True
    run.font.color.rgb = AZUL_DARK
    run.font.name = "Arial"

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run(f"{titulo_modelo}\nTier {tier}")
    r2.font.size = Pt(16)
    r2.font.color.rgb = AZUL_MID
    r2.font.name = "Arial"

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r3 = p3.add_run(f"\nFecha de emisión: {now.strftime('%d/%m/%Y')}\nSegunda Línea de Defensa — Validación de Modelos")
    r3.font.size = Pt(11)
    r3.font.color.rgb = GRIS_TEXT
    r3.font.name = "Arial"
    r3.font.italic = True

    doc.add_page_break()

    # ── 1. Resumen ejecutivo generado por IA ─────────────────────────────────
    _add_heading(doc, "1. RESUMEN EJECUTIVO", level=1)

    # Tabla de scores primero
    _tabla_scores(doc, scores_por_ambito, score_global)

    # Texto narrativo (dividir por secciones ### si existen)
    secciones = re.split(r"###\s*", resumen_ejecutivo)
    for seccion in secciones:
        if seccion.strip():
            lineas = seccion.strip().split("\n")
            titulo_sec = lineas[0].strip()
            cuerpo = "\n".join(lineas[1:]).strip()
            if titulo_sec and cuerpo:
                _add_paragraph(doc, titulo_sec, bold=True, color=AZUL_MID, size=11)
                _add_paragraph(doc, cuerpo)
            else:
                _add_paragraph(doc, seccion.strip())

    doc.add_page_break()

    # ── 2. Hallazgos por ámbito ───────────────────────────────────────────────
    _add_heading(doc, "2. HALLAZGOS DETALLADOS POR ÁMBITO", level=1)
    for ambito, evals in evaluaciones_por_ambito.items():
        score = scores_por_ambito.get(ambito, 0)
        _seccion_ambito(doc, ambito, evals, score)

    doc.add_page_break()

    # ── 3. Consolidado de preguntas pendientes ────────────────────────────────
    _add_heading(doc, "3. REQUERIMIENTOS Y PREGUNTAS PENDIENTES", level=1)
    _add_paragraph(doc, "Las siguientes preguntas y requerimientos de información deben ser respondidos "
                        "por el equipo modelador antes del cierre de la validación:", italic=True)

    contador = 1
    for ambito, evals in evaluaciones_por_ambito.items():
        preguntas_ambito = []
        for ev in evals:
            preguntas_ambito.extend(ev.get("preguntas_pendientes", []))
        if preguntas_ambito:
            _add_paragraph(doc, f"\n{ambito.upper()}", bold=True, color=AZUL_MID, size=10)
            for preg in preguntas_ambito:
                p = doc.add_paragraph(style="List Number")
                run = p.add_run(f"{preg}")
                run.font.size = Pt(9)
                run.font.name = "Arial"
                run.font.color.rgb = GRIS_TEXT
                contador += 1

    doc.add_page_break()

    # ── 4. Leyenda de escala ──────────────────────────────────────────────────
    _add_heading(doc, "4. ESCALA DE EVALUACIÓN", level=1)
    tabla_esc = doc.add_table(rows=1, cols=3)
    tabla_esc.style = "Table Grid"
    for i, h in enumerate(["PUNTAJE", "ESTADO", "CRITERIO"]):
        c = tabla_esc.rows[0].cells[i]
        c.text = h
        c.paragraphs[0].runs[0].font.bold = True
        c.paragraphs[0].runs[0].font.color.rgb = BLANCO
        _set_cell_bg(c, "1F3864")

    for puntaje, info in ESCALA_PUNTAJE.items():
        row = tabla_esc.add_row().cells
        row[0].text = str(puntaje)
        row[1].text = info["label"]
        row[2].text = {
            1: "Evidencia ausente o completamente insuficiente",
            2: "Requiere remediación inmediata — observaciones críticas",
            3: "Brechas importantes pero no bloquean el proceso",
            4: "Cumplimiento sustancial con mejoras recomendadas",
            5: "Evidencia sólida, completa y bien documentada",
        }.get(puntaje, "")
        for i, cell in enumerate(row):
            cell.paragraphs[0].runs[0].font.size = Pt(9)
            if i < 2:
                _set_cell_bg(cell, info["color"])
                cell.paragraphs[0].runs[0].font.color.rgb = BLANCO
                cell.paragraphs[0].runs[0].font.bold = (i == 0)

    outputs_dir.mkdir(parents=True, exist_ok=True)
    doc.save(ruta)
    print(f"  ✓ Word generado: {ruta}")
    return ruta
