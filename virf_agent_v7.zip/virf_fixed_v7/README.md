# 🔍 AGENTE VIRF — Validador de Modelos de Riesgo Financiero (LaR/VaR)

Agente de segunda línea de defensa para validación integral de modelos estocásticos
y de machine learning bajo el marco **VIRF** (Validación Integral de Riesgo Financiero).

---

## 📁 Estructura del proyecto

```
virf_agent/
│
├── agente.py                          ← PUNTO DE ENTRADA
├── config.py                          ← API key, rutas, pesos, escala
├── requirements.txt
├── .env.example                       ← Copia a .env y agrega tu API key
├── Estandares_VIRF.xlsx               ← Estándares y actividades por Tier
│
├── repositorio_informes/              ← Informes de validación previos (.docx/.pdf)
│                                        El agente aprende el lenguaje y estilo de estos docs
│
├── inputs/
│   ├── documentacion/
│   │   ├── modelamiento/              ← Manuales metodológico y operativo del modelador
│   │   └── seguimiento/               ← Manuales de seguimiento, backtesting (Kupiec, etc.)
│   ├── papers/                        ← Papers científicos del modelo
│   ├── calidad_datos/                 ← Excel de datos + scripts del modelo
│   │   └── _replica_virf.py           ← Script de calidad de datos de 2da línea
│   ├── implementacion/                ← Correos, PDFs de controles, JSON de sistemas
│   └── usos/                          ← PPTs de comités, actas, PDFs de usos
│
├── outputs/                           ← Archivos generados automáticamente
│   ├── VIRF_Resultados_*.xlsx         ← Excel con evaluación, semáforos y tracking
│   ├── VIRF_Informe_*.docx            ← Word con informe narrativo consolidado (solo --prdc)
│   └── Estandares_VIRF_*_VN.xlsx     ← Estandares actualizado con columnas de validación
│
└── modulos/
    ├── lector_inputs.py               ← Lee PDF, DOCX, PPTX, XLSX, PY, JSON, CSV
    ├── motor_ia.py                    ← Claude opus-4-5 como Model Risk Controller
    ├── generador_excel.py             ← Excel con semáforos y tracking de versiones
    ├── generador_word.py              ← Informe Word narrativo
    └── generador_template.py          ← Lee y actualiza Estandares_VIRF.xlsx
```

---

## ⚙️ Instalación

```bash
# 1. Crear entorno virtual (recomendado)
python -m venv venv
source venv/bin/activate        # Linux/Mac
venv\Scripts\activate           # Windows

# 2. Instalar dependencias
pip install -r requirements.txt

# 3. Configurar API key
cp .env.example .env
# Editar .env y poner tu ANTHROPIC_API_KEY
```

---

## 🚀 Uso

### Modo PRE-PRODUCCIÓN (`--preprdc`)
Úsalo cada vez que agregues más documentos al proyecto.
Genera/actualiza el Excel con evaluaciones iterativas.
**Versiona automáticamente** si se corre el mismo día (V1, V2...).

```bash
python agente.py --titulo "Modelo LaR" --tier II --preprdc
```

### Modo PRODUCCIÓN (`--prdc`)
Úsalo cuando el modelo esté listo para dictamen final.
Genera el Excel de resultados **+ el informe Word consolidado**.

```bash
python agente.py --titulo "Modelo LaR" --tier II --prdc
```

### Parámetros

| Parámetro   | Descripción                            | Opciones            |
|-------------|----------------------------------------|---------------------|
| `--titulo`  | Nombre del modelo a validar            | Texto libre         |
| `--tier`    | Tier del modelo según inventario       | `I`, `II`, `III`, `IV` |
| `--preprdc` | Modo iterativo pre-producción          | Flag (sin valor)    |
| `--prdc`    | Modo producción con informe Word       | Flag (sin valor)    |

---

## 📊 Outputs generados

### Excel de Resultados (`VIRF_Resultados_*.xlsx`)

| Pestaña | Contenido |
|---------|-----------|
| **RESUMEN** | Score global ponderado + scores por ámbito con semáforos |
| **TRACKING VALIDACIÓN** | Todas las actividades con puntaje, concepto, observación, preguntas pendientes y columna `VALIDACIÓN-DDMMYYYY_VN` |
| **Documentación** | Detalle de actividades del ámbito |
| **Calidad de datos** | Detalle de actividades del ámbito |
| *(un tab por ámbito)* | ... |

### Estandares actualizado (`Estandares_VIRF_*_VN.xlsx`)
El archivo original enriquecido con dos nuevas columnas:
- **CONCEPTO**: descripción técnica de cada actividad
- **VALIDACIÓN-DDMMYYYY_VN**: puntaje y estado de la corrida

### Informe Word (`VIRF_Informe_*.docx`) — solo `--prdc`
- Portada institucional
- Resumen ejecutivo con dictamen (APROBADO / CON CONDICIONES / OBSERVADO / RECHAZADO)
- Tabla de scores con semáforos
- Hallazgos detallados por ámbito
- Requerimientos y preguntas pendientes al modelador
- Escala de evaluación

---

## 🎯 Escala de Puntaje

| Puntaje | Estado                              | Color    |
|---------|-------------------------------------|----------|
| 5       | Cumple plenamente                   | 🟢 Verde  |
| 4       | Cumple con observaciones menores    | 🟢 Verde claro |
| 3       | Cumple parcialmente                 | 🟡 Amarillo |
| 2       | Cumple parcialmente - obs. críticas | 🟠 Naranja |
| 1       | No cumple                           | 🔴 Rojo   |

### Score global ponderado

| Rango   | Dictamen              |
|---------|-----------------------|
| 4.5–5.0 | SATISFACTORIO         |
| 3.5–4.5 | ACEPTABLE             |
| 2.5–3.5 | CON OBSERVACIONES     |
| 1.5–2.5 | DEFICIENTE            |
| 0.0–1.5 | CRÍTICO               |

---

## 🔬 Control de calidad de datos de segunda línea

```bash
python inputs/calidad_datos/_replica_virf.py \
  --input inputs/calidad_datos/datos_modelo.xlsx \
  --output outputs/QC_datos_modelo.xlsx
```

Pruebas ejecutadas:
- **Missing values** por columna (umbral: 5%)
- **Duplicados** exactos y por columna clave
- **Outliers** (Z-score > 3.5)
- **Consistencia temporal** (gaps, orden, días sin actualizar)
- **Rangos de valores** (mín, máx, infinitos, negativos)
- **Tipos de datos** (numéricas almacenadas como texto)

---

## 📂 ¿Qué poner en cada carpeta?

| Carpeta | Archivos a incluir |
|---------|-------------------|
| `inputs/documentacion/modelamiento/` | Manual metodológico, manual operativo del modelador (.docx, .pdf) |
| `inputs/documentacion/seguimiento/` | Manual de seguimiento, scripts de backtesting (.docx, .pdf, .py) |
| `inputs/papers/` | Papers de referencia (.pdf) |
| `inputs/calidad_datos/` | Excel de datos del modelo, script _replica_virf.py de primera línea |
| `inputs/implementacion/` | Correos de conformidad (.pdf), controles de sistemas (.xlsx, .json) |
| `inputs/usos/` | Presentaciones de comité, actas (.pptx, .pdf) |
| `repositorio_informes/` | Informes de validación anteriores para que el agente aprenda el estilo |

---

## ⚠️ Notas importantes

1. **Sin contexto → preguntas**: Si no hay documentos en una carpeta, el agente formulará
   preguntas específicas al modelador en lugar de inventar evaluaciones.

2. **Versionamiento automático**: Si corres `--preprdc` dos veces el mismo día, el segundo
   archivo se guardará como V2, V3, etc.

3. **Tier activa actividades**: Solo se evalúan las actividades marcadas con `X` en la columna
   del Tier seleccionado en `Estandares_VIRF.xlsx`.

4. **Modelo base**: `claude-opus-4-5` — configurable en `config.py`.
