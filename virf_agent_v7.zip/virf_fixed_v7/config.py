"""
config.py - Configuración central del agente VIRF
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ─── API ────────────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
MODEL_ID = "claude-opus-4-5"  # Motor principal de validación
MAX_TOKENS = 4096

# ─── RUTAS BASE ─────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
ESTANDARES_PATH = BASE_DIR / "inputs" / "Estandares_VIRF.xlsx"

INPUTS = {
    "doc_modelamiento": BASE_DIR / "inputs" / "documentacion" / "modelamiento",
    "doc_seguimiento":  BASE_DIR / "inputs" / "documentacion" / "seguimiento",
    "papers":           BASE_DIR / "inputs" / "papers",
    "calidad_datos":    BASE_DIR / "inputs" / "calidad_datos",
    "implementacion":   BASE_DIR / "inputs" / "implementacion",
    "usos":             BASE_DIR / "inputs" / "usos",
    "repositorio":      BASE_DIR / "repositorio_informes",
}
OUTPUTS_DIR = BASE_DIR / "outputs"

# ─── TIERS ──────────────────────────────────────────────────────────────────
TIER_COLUMNS = {
    "I":   "TIER I",
    "II":  "TIER II",
    "III": "TIER III",
    "IV":  "TIER IV",
}

# ─── ÁMBITOS Y PESOS PARA SCORE GLOBAL ──────────────────────────────────────
AMBITO_PESOS = {
    "Documentación":               0.20,
    "Calidad de datos":            0.20,
    "Metodología":                 0.25,
    "Gobierno":                    0.10,
    "Implementación":              0.15,
    "Uso e integración a la gestión": 0.10,
}

# ─── ESCALA DE PUNTAJE ───────────────────────────────────────────────────────
# 1 = No cumple | 2 = Cumple parcialmente con observaciones críticas
# 3 = Cumple parcialmente | 4 = Cumple con observaciones menores | 5 = Cumple plenamente
ESCALA_PUNTAJE = {
    1: {"label": "No cumple",                             "color": "FF0000"},  # Rojo
    2: {"label": "Cumple parcialmente - obs. críticas",   "color": "FF6600"},  # Naranja
    3: {"label": "Cumple parcialmente",                   "color": "FFCC00"},  # Amarillo
    4: {"label": "Cumple con observaciones menores",      "color": "92D050"},  # Verde claro
    5: {"label": "Cumple plenamente",                     "color": "00B050"},  # Verde
}

SCORE_SEMAFORO = {
    (4.5, 5.0): {"label": "SATISFACTORIO",    "color": "00B050"},
    (3.5, 4.5): {"label": "ACEPTABLE",         "color": "92D050"},
    (2.5, 3.5): {"label": "CON OBSERVACIONES", "color": "FFCC00"},
    (1.5, 2.5): {"label": "DEFICIENTE",        "color": "FF6600"},
    (0.0, 1.5): {"label": "CRÍTICO",           "color": "FF0000"},
}

# ─── PREGUNTAS METODOLÓGICAS POR ÁMBITO ─────────────────────────────────────
# Guían al motor IA cuando no encuentra evidencia suficiente
PREGUNTAS_METODOLOGICAS = {
    "Documentación": [
        "¿Existe un manual metodológico con control de versiones?",
        "¿El manual operativo describe el proceso de ejecución paso a paso?",
        "¿Los documentos de seguimiento incluyen backtesting (Kupiec, Christoffersen)?",
        "¿El informe de seguimiento cubre monitoreo de calidad de datos?",
    ],
    "Calidad de datos": [
        "¿Existe un script _replica_virf.py o equivalente de control de datos?",
        "¿Se documentan controles sobre missing values, duplicados y outliers?",
        "¿Existen reportes de incidencias de calidad de datos?",
        "¿Se verifica la actualización periódica de los inputs?",
    ],
    "Metodología": [
        "¿Se justifica la elección del modelo estocástico/ML utilizado?",
        "¿Se validan los supuestos principales del modelo?",
        "¿Se referencian lineamientos internacionales o regulatorios?",
        "¿Existe backtesting o planificación de seguimiento?",
        "¿Se realizan análisis de sensibilidad o escenarios?",
    ],
    "Gobierno": [
        "¿El modelo tiene tiering asignado y actualizado?",
        "¿El modelo se encuentra en el inventario oficial?",
    ],
    "Implementación": [
        "¿Se documentan las fuentes de información empleadas?",
        "¿Existen correos de conformidad de resultados con primera línea?",
        "¿El manual de implementación es coherente con el metodológico?",
        "¿Se documentan pruebas iniciales de implementación?",
    ],
    "Uso e integración a la gestión": [
        "¿Los usos del modelo están dentro del alcance original?",
        "¿El modelo no estaba en uso antes de concluir la validación?",
        "¿Se identifican formalmente los usuarios del modelo?",
        "¿Existe reporting de integración a la gestión?",
    ],
}

# ─── EXTENSIONES LEGIBLES ────────────────────────────────────────────────────
EXTENSIONES_SOPORTADAS = [".pdf", ".docx", ".pptx", ".xlsx", ".py", ".json", ".txt", ".csv"]
