# Control C1 — Documentación

## Prompt maestro

```text
[Encabezado de sistema]

TAREA: Evaluar la completitud, vigencia y coherencia de la documentación del
modelo [SUPUESTO-G01], código [SUPUESTO-G02], Tier [SUPUESTO-G03].

INPUTS QUE RECIBIRÁS
- Manual metodológico, manual de usuario, manual de seguimiento (PDF/Word)
- Acta del modelo (campos [SUPUESTO-G01] a [SUPUESTO-G12])
- entendimiento_<codigo>.md (Paso 0)
- Estandares_VIRF.xlsx, hoja Periodicas, filtrado por Tier
- Informe de la validación anterior y estado de sus observaciones

PROCEDIMIENTO
1. Extrae del estándar VIRF las actividades de Documentación aplicables al Tier
   y lístalas por ID.
2. Para cada actividad, localiza la sección documental que la satisface.
3. Contrasta la versión documentada contra la versión productiva declarada en
   el acta. Si difieren, es hallazgo, no observación menor.
4. Verifica que no existan: secciones en blanco, "por definir", referencias a
   anexos inexistentes, gráficos sin fuente, ni versiones sin fecha ni autor.
5. Verifica el cierre de observaciones de la validación anterior.

FORMATO DE SALIDA (tabla, una fila por actividad VIRF)
| ID VIRF | Actividad esperada | Documento que la cubre | Estado | Sustento del estado | Fuente exacta | Acción pendiente |

REGLAS ESPECÍFICAS
- Un manual sin control de versiones se marca "Cumple con observación" aunque
  el contenido sea correcto.
- Un manual que documenta una versión distinta a la productiva se marca
  "No cumple", incluso si el contenido es de mayor calidad.
```

## Fila de ejemplo (ficticia)

| ID VIRF | Actividad esperada | Documento que la cubre | Estado | Sustento del estado | Fuente exacta | Acción pendiente |
|---|---|---|---|---|---|---|
| ACT-DOC-04 | Documentar la definición de la variable objetivo y su ventana de desempeño | Manual metodológico | Cumple con observación | La ventana de desempeño está definida como 12 meses, pero el acta declara 18 meses para el modelo en producción; ambas cifras coexisten sin nota de conciliación | `Manual_Metodologico_PD_Retail_v3.pdf > 3.1 Variable objetivo > p.14` vs. `Acta_Modelo_MOD-0412.docx > [SUPUESTO-G10] > p.2` | Conciliar ventana de desempeño y emitir manual v3.1 — responsable `[SUPUESTO-G05]`, fecha comprometida 2026-09-30 |

