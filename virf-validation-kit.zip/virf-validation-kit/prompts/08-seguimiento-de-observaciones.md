# D2 — Seguimiento de observaciones

## Prompt

```text
[Encabezado de sistema]

TAREA: Emitir el reporte de seguimiento de observaciones del modelo
[SUPUESTO-G02], comparando el estado comprometido contra el estado real.

INPUTS
- Informe de validación anterior con observaciones y fechas comprometidas
- Evidencia de subsanación entregada en este ciclo
- Correos y actas relacionadas

PROCEDIMIENTO
1. Una fila por observación histórica. No omitas ninguna, ni las cerradas.
2. Estados permitidos: Cerrada / Cerrada parcialmente / Vigente en plazo /
   Vencida / Reabierta.
3. "Cerrada" exige evidencia nueva citada. Una declaración del equipo sin
   evidencia adjunta es "Vigente en plazo" o "Vencida", según la fecha.
4. Calcula los días de atraso de cada observación vencida.
5. Escala a hallazgo de gobierno toda observación vencida por más de un ciclo.

FORMATO DE SALIDA
| ID observación | Ciclo de origen | Descripción | Compromiso y fecha | Evidencia presentada | Estado | Días de atraso | Fuente exacta | Siguiente paso |
```

## Fila de ejemplo (ficticia)

| ID observación | Ciclo de origen | Descripción | Compromiso y fecha | Evidencia presentada | Estado | Días de atraso | Fuente exacta | Siguiente paso |
|---|---|---|---|---|---|---|---|---|
| OBS-2025Q4-02 | 2025Q4 | Regla de imputación de `ingreso_declarado` no documentada | Incorporar la regla en el manual metodológico — 2026-03-31 | Correo del equipo declarando que "se incorporará en la siguiente versión"; no se adjuntó manual actualizado | Vencida | 154 | `jperez@banco.pe > RE: Observaciones validación PD > 2026-04-02`; `Informe_Validacion_2025Q4.pdf > 7.2 > p.33` | Escalar a hallazgo de gobierno por vencimiento superior a un ciclo e informar a `[SUPUESTO-G04]` |

