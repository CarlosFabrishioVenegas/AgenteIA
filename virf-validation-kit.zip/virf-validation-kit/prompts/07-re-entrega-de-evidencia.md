# D1 — Re-entrega de evidencia

## Prompt

```text
[Encabezado de sistema]

TAREA: Redactar la solicitud formal de re-entrega de evidencia para el modelo
[SUPUESTO-G01] ([SUPUESTO-G02]).

INPUTS
- Matrices de los controles ya ejecutados
- Listado de hallazgos con estado "No evidenciado" o "No verificable"
- Fechas del cronograma de kick-off

PROCEDIMIENTO
1. Agrupa los faltantes por control y por responsable.
2. Para cada faltante, expresa QUÉ se pide, POR QUÉ se pide (actividad VIRF que
   lo exige, citada por ID) y EN QUÉ FORMATO se espera recibirlo.
3. Asigna criticidad: Bloqueante (impide cerrar el control), Alta, Media.
4. Propón fecha límite considerando el deadline del cronograma.
5. No incluyas juicios de valor sobre el equipo ni sobre el modelo. Solo
   faltantes, base normativa y plazos.

FORMATO DE SALIDA
Correo formal + tabla anexa:
| # | Control | Evidencia solicitada | Actividad VIRF que la exige | Motivo (qué no se pudo verificar) | Formato esperado | Criticidad | Fecha límite | Responsable |

REGLA: si un ítem ya fue solicitado en una re-entrega previa, márcalo como
REITERADO e indica la fecha de la solicitud original.
```

## Fila de ejemplo (ficticia)

| # | Control | Evidencia solicitada | Actividad VIRF | Motivo | Formato esperado | Criticidad | Fecha límite | Responsable |
|---|---|---|---|---|---|---|---|---|
| 3 | Implementación | Log de ejecución completo del cierre 2026Q2 con marca de tiempo y versión del código | `Estandares_VIRF.xlsx > Periodicas > ACT-IMP-06` | El log entregado está truncado en la línea 412 y no permite verificar el conteo final de registros procesados | `.log` o `.txt` sin editar, más el hash SHA-256 del archivo original | Bloqueante | 2026-09-12 | `[SUPUESTO-G05]` — REITERADO, solicitado por primera vez el 2026-08-28 |

