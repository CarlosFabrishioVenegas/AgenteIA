# VF — Consolidación final

## Prompt

```text
[Encabezado de sistema]

TAREA: Consolidar las matrices de los 6 controles del modelo [SUPUESTO-G01]
([SUPUESTO-G02], Tier [SUPUESTO-G03]) en la tabla única de 8 columnas y emitir
la conclusión de la validación periódica.

INPUTS
- Matriz de Documentación, matriz de Calidad de Datos (7 columnas), matriz de
  Metodología, matriz de Implementación, matriz de Gobierno, matriz de Usos
- Reporte de seguimiento de observaciones
- Estandares_VIRF.xlsx filtrado por Tier y por periodicidad
- entendimiento_<codigo>.md

PROCEDIMIENTO
1. Verifica cobertura: cruza la lista de actividades VIRF aplicables contra las
   filas recibidas. Toda actividad sin fila se agrega como "No evidenciado".
   Reporta el porcentaje de cobertura antes de la tabla.
2. Normaliza los estados al semáforo oficial. No inventes estados intermedios.
3. Deduplica hallazgos que aparezcan en dos controles: consérvalos en el control
   de origen y referencia cruzada en el otro.
4. Ordena por ámbito y, dentro del ámbito, por severidad descendente.
5. Aplica las reglas de conclusión:
   - Un solo "No cumple" bloqueante en Implementación o Usos impide concluir
     "Validación satisfactoria".
   - Ausencia total de evidencia de uso => recomendación obligatoria de retiro
     del inventario.
   - Cobertura de actividades < 100 % => la conclusión se emite como
     "Validación incompleta", nunca como satisfactoria.
6. Redacta la conclusión en máximo 12 líneas, citando los 3 hallazgos de mayor
   severidad y el impacto sobre el uso del modelo.
7. Cierra con el anexo de trazabilidad: evidencias leídas con hash, evidencias
   no recibidas, consultas abiertas y firma del validador.

FORMATO DE SALIDA
(a) Resumen de cobertura y semáforo por control
(b) Tabla de 8 columnas
(c) Conclusión
(d) Anexo de trazabilidad

PROHIBIDO: emitir la conclusión antes de la tabla, o suavizar un estado por
consideraciones de plazo o de relación con el equipo dueño del modelo.
```

## Fila de ejemplo (ficticia)

| Ámbito | Tipo | Actividad | Cumple o no | Resultado | Evaluación sustentada | Fuente revisada | Acción pendiente |
|---|---|---|---|---|---|---|---|
| Implementación | Cuantitativo | `ACT-IMP-09` — Verificar que los parámetros implementados coinciden con los documentados | No cumple | Corte de score PYME: 620 en código vs. 640 en manual; 4 128 clientes (2,7 % de la cartera) reclasificados | La diferencia no está documentada ni aprobada, y modifica la asignación de segmento de riesgo de un volumen material de clientes; al no poder determinar cuál corte es el aprobado, el output del ciclo no es concluyente y el hallazgo bloquea el cierre de la validación | `pipeline_pd.py > línea 193`; `Manual_Metodologico_PD_Retail_v3.pdf > 6.2 > p.48`; `output_scores_2026Q2.csv` | Alinear código y manual, declarar el corte aprobado y recalcular el output — `[SUPUESTO-G05]`, 2026-09-20. Bloqueante |
| Usos | Cualitativo | `ACT-USO-03` — Verificar sustento del output en el foro comprometido | Cumple con observación | Último envío 2026-07-08 con acuse; última presentación en Comité de Riesgos: 2025-11 | El uso operativo está acreditado, pero el sustento en el foro de gobierno lleva dos trimestres sin realizarse frente a la periodicidad comprometida; el riesgo es que las decisiones basadas en la curva no cuenten con validación del foro autorizado | `mgomez@banco.pe > Curva PD 2026Q2 > 2026-07-08`; `Comité de Riesgos > acta 118 > agenda` | Agendar presentación antes del cierre del siguiente trimestre — `[SUPUESTO-G04]` |

