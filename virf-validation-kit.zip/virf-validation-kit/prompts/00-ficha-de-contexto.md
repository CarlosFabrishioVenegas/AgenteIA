# Ficha de contexto del modelo

Se pega al inicio de cada prompt, después del encabezado de sistema. Sin ella el
agente no sabe qué tier aplicar ni contra qué comparar.

## Plantilla

```text
=== FICHA DE CONTEXTO DEL MODELO ===
Modelo:                 [nombre oficial, tal como figura en el acta]
Código de inventario:   [código]
Tiering:                Tier 1 / Tier 2 / Tier 3
Tipo de validación:     Periódica
Ciclo evaluado:         [AAAA-QN o AAAA-MM]
Fecha de corte de la evidencia: [AAAA-MM-DD]
Validador:              [nombre]

Propósito del modelo en una línea:
  [qué decisión soporta]

Cadena del modelo:
  Inputs:          [fuentes principales: sistema y tabla]
  Transformación:  [2 o 3 pasos clave]
  Output:          [qué produce: curva, score, %, provisión]
  Destinatario:    [área usuaria]
  Uso declarado:   [para qué está autorizado, según el acta]

Herramienta:
  Tipo:            Python / Excel / SAS / otro
  Estado:          corre sin errores / corre con errores / no probada / no entregada
  Ubicación:       [ruta]

Periodicidad comprometida:  [mensual / trimestral / semestral]
Comité o foro donde se sustenta: [nombre del foro]

Historial:
  Última validación:        [fecha]
  Observaciones abiertas:   [número y las dos más severas]
  Cambios en este ciclo:    [recalibración, cambio de variables, sin cambios]

Evidencia adjunta en esta sesión:
  1. [archivo] — [qué contiene]
  2. [archivo] — [qué contiene]

Evidencia solicitada y no recibida:
  1. [archivo] — solicitada el [fecha]

Ambigüedades conocidas:
  1. [lo que el equipo no ha aclarado todavía]
=== FIN DE LA FICHA ===
```

## Ejemplo llenado (ficticio)

```text
=== FICHA DE CONTEXTO DEL MODELO ===
Modelo:                 Modelo de Probabilidad de Incumplimiento — Cartera Retail
Código de inventario:   MOD-0412
Tiering:                Tier 2
Tipo de validación:     Periódica
Ciclo evaluado:         2026Q2
Fecha de corte de la evidencia: 2026-08-29
Validador:              [nombre]

Propósito del modelo en una línea:
  Estima la PD a 12 meses por cliente para el cálculo de provisiones y la
  asignación de segmento de riesgo en originación.

Cadena del modelo:
  Inputs:          Datamart Riesgos (DM_CLIENTE, DM_COMPORTAMIENTO), score de buró
  Transformación:  filtro de universo (antigüedad >= 6 meses) -> construcción de
                   variables de comportamiento a 6 meses -> regresión logística ->
                   escalamiento a tasa central
  Output:          curva de PD trimestral por segmento y PD individual por cliente
  Destinatario:    Gestión de Riesgo Minorista
  Uso declarado:   provisiones IFRS 9 y segmentación en originación

Herramienta:
  Tipo:            Python
  Estado:          corre sin errores, corrida del 2026-07-05
  Ubicación:       repositorio riesgos/pd_retail, rama produccion, tag v3.2

Periodicidad comprometida:  trimestral
Comité o foro donde se sustenta: Comité de Riesgos

Historial:
  Última validación:        2025Q4
  Observaciones abiertas:   2 — OBS-2025Q4-02 (regla de imputación no documentada,
                            vencida) y OBS-2025Q4-05 (linaje incompleto)
  Cambios en este ciclo:    recalibración de la tasa central, sin cambio de variables

Evidencia adjunta en esta sesión:
  1. MOD-0412_2026Q2_ManualMetodologico_v3.pdf — metodología completa
  2. MOD-0412_2026Q2_Acta.pdf — acta del modelo vigente
  3. MOD-0412_2026Q2_InformeValidacion_2025Q4.pdf — validación anterior

Evidencia solicitada y no recibida:
  1. Log de ejecución del cierre 2026Q2 — solicitado el 2026-08-28

Ambigüedades conocidas:
  1. El manual declara ventana de desempeño de 12 meses y el acta de 18 meses.
=== FIN DE LA FICHA ===
```
