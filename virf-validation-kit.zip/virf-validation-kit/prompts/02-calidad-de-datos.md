# Control C2 — Calidad de Datos

## Prompt maestro

```text
[Encabezado de sistema]

TAREA: Verificar que la data del modelo [SUPUESTO-G02] cumple los controles de
datos establecidos, dimensión por dimensión.

INPUTS QUE RECIBIRÁS
- ControlesData.xlsx (catálogo de controles esperados)
- manual_controles_datos.md
- Datasets de entrada del ciclo evaluado (o su perfilado)
- Salida del notebook de controles de datos (ver sección 4)
- Estandares_VIRF.xlsx, actividades de Calidad de Datos por Tier

DIMENSIONES OBLIGATORIAS
Completitud, Unicidad, Validez, Consistencia, Exactitud, Integridad referencial,
Oportunidad (timeliness), Estabilidad poblacional, Trazabilidad del linaje.

PROCEDIMIENTO
1. Para cada dimensión, identifica el control esperado según ControlesData.xlsx.
2. Busca la evidencia de que ese control existe y fue ejecutado en el ciclo.
3. Contrasta el resultado del notebook contra el umbral declarado.
4. Emite diagnóstico y decisión. La decisión debe ser accionable y con dueño.

FORMATO DE SALIDA (7 columnas, una fila por dimensión)
| Dimensión | Control esperado | ¿Existe según evidencia? | Diagnóstico | Decisión | Control o evidencia requerida | Referencia en el entregable |

REGLAS ESPECÍFICAS
- Un control ejecutado pero sin umbral declarado se marca "No verificable".
- Un umbral incumplido nunca se compensa con explicación cualitativa: se marca
  "No cumple" y se documenta la explicación en el diagnóstico.
- La ausencia de linaje de datos (origen de tabla y campo) es hallazgo crítico
  para Tier 1 y Tier 2.
```

## Fila de ejemplo (ficticia)

| Dimensión | Control esperado | ¿Existe según evidencia? | Diagnóstico | Decisión | Control o evidencia requerida | Referencia en el entregable |
|---|---|---|---|---|---|---|
| Completitud | Nulos ≤ 2 % en variables explicativas del score | Sí, parcialmente | 11 de 12 variables cumplen; `ingreso_declarado` presenta 7,4 % de nulos frente al umbral de 2 %, imputados con la mediana sin documentar la regla | No cumple — remediar antes del siguiente ciclo | Documentar la regla de imputación en el manual y ejecutar análisis de sensibilidad del score con y sin imputación | `notebook_controles_datos.ipynb > celda 7 > tabla completitud`; `ControlesData.xlsx > Controles > B18`; `base_score_2026Q2.parquet > columna ingreso_declarado` |

