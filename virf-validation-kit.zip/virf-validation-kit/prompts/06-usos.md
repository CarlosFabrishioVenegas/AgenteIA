# Control C6 — Usos

## Prompt maestro

```text
[Encabezado de sistema]

TAREA: Verificar que el output del modelo [SUPUESTO-G02] (curva, datos, % u
otro) tiene uso efectivo, sustentado y dentro de la periodicidad comprometida.

INPUTS QUE RECIBIRÁS
- Correos de envío del output y sus acuses
- Actas de comité donde el output fue presentado
- Evidencia de publicación (ruta, tablero, repositorio)
- [SUPUESTO-G06] área usuaria, [SUPUESTO-G08] periodicidad, [SUPUESTO-G10] uso declarado

PROCEDIMIENTO
1. Para cada output declarado, busca la cadena completa: generación -> envío ->
   recepción -> sustento en foro -> decisión tomada.
2. Verifica que la fecha de envío respete la periodicidad comprometida.
3. Verifica que el uso real coincida con el uso declarado en [SUPUESTO-G10].
   Un uso distinto al autorizado es hallazgo, aunque exista evidencia de uso.
4. Si no existe ni envío ni sustento en comité, concluye USO NO SATISFACTORIO
   y emite la recomendación formal de retiro del inventario.

FORMATO DE SALIDA
| Output | Destinatario | Evidencia de envío | Evidencia de sustento en foro | ¿Uso satisfactorio? | Evaluación sustentada | Fuente exacta | Acción pendiente |

REGLAS ESPECÍFICAS
- Correo sin acuse del área usuaria en Tier 1: "Cumple con observación".
- Output publicado en un tablero sin evidencia de consumo: no acredita uso.
- La recomendación de retiro no es opcional cuando no hay uso: es obligatoria.
```

## Fila de ejemplo (ficticia)

| Output | Destinatario | Evidencia de envío | Evidencia de sustento en foro | ¿Uso satisfactorio? | Evaluación sustentada | Fuente exacta | Acción pendiente |
|---|---|---|---|---|---|---|---|
| Curva de PD trimestral por segmento | Gestión de Riesgo Minorista `[SUPUESTO-G06]` | Correo del 2026-07-08 con archivo adjunto y acuse del área usuaria | No se identificó presentación en comité en el trimestre evaluado | Cumple con observación | El envío existe y está acusado dentro del plazo trimestral, pero `[SUPUESTO-G08]` compromete sustento en el Comité de Riesgos y la última presentación registrada es de 2025-11; el uso está acreditado en el nivel operativo, no en el nivel de gobierno | `mgomez@banco.pe > Curva PD 2026Q2 > 2026-07-08`; `Comité de Riesgos > acta 118 > agenda`; `Acta_Modelo_MOD-0412.docx > [SUPUESTO-G08] > p.3` | Agendar presentación de la curva en el Comité de Riesgos antes del cierre del siguiente trimestre y anexar el acta al expediente |

