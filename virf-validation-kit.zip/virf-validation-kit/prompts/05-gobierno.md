# Control C5 — Gobierno

## Prompt maestro

```text
[Encabezado de sistema]

TAREA: Verificar la integridad, vigencia y consistencia del acta del modelo
[SUPUESTO-G02] y de su tiering.

INPUTS QUE RECIBIRÁS
- Acta del modelo con los campos [SUPUESTO-G01] a [SUPUESTO-G12]
- Inventario de modelos (extracto del modelo evaluado)
- Evidencia técnica de los controles C1 a C4 ya ejecutados
- Criterios de tiering vigentes

PROCEDIMIENTO
1. Verifica campo por campo: presente, legible, fechado y con responsable.
2. Contrasta cada campo del acta contra la evidencia técnica. La coherencia
   importa más que la existencia: un acta completa pero desalineada es hallazgo.
3. Recalcula el tiering con los criterios vigentes y compáralo con
   [SUPUESTO-G03]. Si difiere, es hallazgo de gobierno de severidad alta.
4. Toda ambigüedad se convierte en CONSULTA FORMAL al responsable del equipo
   dueño del modelo: redacta la pregunta, el destinatario y el plazo. Nunca
   resuelvas la ambigüedad por cuenta propia.

FORMATO DE SALIDA
| Campo del acta | Valor registrado | ¿Completo y vigente? | Contraste con evidencia técnica | Estado | Fuente exacta | Consulta o acción pendiente |

REGLAS ESPECÍFICAS
- Campo vacío = "No evidenciado", nunca "No aplica", salvo que el propio
  estándar lo exima y se cite la regla.
- Aprobación vencida respecto de [SUPUESTO-G08]: "No cumple".
```

## Fila de ejemplo (ficticia)

| Campo del acta | Valor registrado | ¿Completo y vigente? | Contraste con evidencia técnica | Estado | Fuente exacta | Consulta o acción pendiente |
|---|---|---|---|---|---|---|
| `[SUPUESTO-G03]` Tiering asignado | Tier 2 | Completo, pero desactualizado | El acta declara una exposición gestionada de S/ 180 MM; el reporte de cartera del ciclo muestra S/ 640 MM, umbral que según los criterios vigentes corresponde a Tier 1 | No cumple | `Acta_Modelo_MOD-0412.docx > [SUPUESTO-G03] > p.1`; `Reporte_Cartera_2026Q2.xlsx > Resumen > C9`; `Criterios_Tiering_2025.pdf > 2.3 > p.6` | Consulta formal a `[SUPUESTO-G04]`: ¿se solicitó reevaluación de tiering tras el crecimiento de exposición? Plazo de respuesta: 5 días hábiles |

