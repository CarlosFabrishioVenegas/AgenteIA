# Control C3 — Metodología

## Prompt maestro

```text
[Encabezado de sistema]

TAREA: Verificar que el modelo [SUPUESTO-G02] cuenta con sustento metodológico
citable y que ejecutó todas las actividades exigidas por el estándar VIRF.

INPUTS QUE RECIBIRÁS
- Manual metodológico
- Carpeta papers/ con la bibliografía de sustento
- Resultados de pruebas: discriminación, calibración, estabilidad, backtesting
- Estandares_VIRF.xlsx, actividades de Metodología por Tier
- [SUPUESTO-G11] limitaciones y supuestos declarados

PROCEDIMIENTO
1. Lista las actividades VIRF de Metodología aplicables al Tier.
2. Para cada decisión metodológica relevante (técnica elegida, tratamiento de
   outliers, criterio de segmentación, método de calibración), identifica el
   sustento: paper, norma, práctica interna documentada o prueba empírica.
3. Verifica que cada supuesto declarado tenga prueba o monitoreo asociado.
4. Verifica que las métricas reportadas sean reproducibles con los datos y el
   código entregados.
5. Marca como hallazgo toda decisión sustentada únicamente en "criterio experto"
   sin acta, minuta ni prueba.

FORMATO DE SALIDA
| ID VIRF | Decisión o actividad metodológica | Sustento presentado | ¿Suficiente? | Evaluación sustentada | Fuente exacta | Acción pendiente |

REGLAS ESPECÍFICAS
- Un paper citado que no corresponde a la técnica efectivamente implementada se
  marca "No cumple" por sustento inconsistente.
- Métrica reportada que no se reproduce con el código entregado: "No verificable".
```

## Fila de ejemplo (ficticia)

| ID VIRF | Decisión o actividad metodológica | Sustento presentado | ¿Suficiente? | Evaluación sustentada | Fuente exacta | Acción pendiente |
|---|---|---|---|---|---|---|
| ACT-MET-11 | Calibración de la PD mediante escalamiento a tasa central observada | Referencia a Tasche (2013) y tabla de factores de escalamiento | Parcialmente | El sustento teórico es pertinente, pero la tasa central usada (3,10 %) corresponde a la cosecha 2023 y no a la ventana 2024–2025 declarada en el manual; el escalamiento resultante subestima la PD media en 34 pbs frente a la observada | `Manual_Metodologico_PD_Retail_v3.pdf > 5.4 Calibración > p.41`; `papers/Tasche_2013_calibration.pdf > p.9`; `herramienta_pd.xlsx > Calibracion > F22` | Recalibrar con la ventana declarada y documentar el impacto en el informe de seguimiento — `[SUPUESTO-G05]`, próximo ciclo |

