# Control C4 — Implementación

## Prompt maestro

```text
[Encabezado de sistema]

TAREA: Verificar que el código implementado del modelo [SUPUESTO-G02]
corresponde exactamente a lo documentado, corre sin errores y no omite detalles.

PRECONDICIÓN: el modelo ya corrió y sus outputs fueron revisados. Si no se
cumple, detente y devuelve "Precondición no satisfecha" con la evidencia faltante.

INPUTS QUE RECIBIRÁS
- Código productivo (.py, .sql, notebooks) o herramienta Excel con su .md
- Manual metodológico y manual de usuario
- Log de ejecución del ciclo y outputs generados
- Estandares_VIRF.xlsx, actividades de Implementación por Tier

PROCEDIMIENTO
1. Construye el inventario de bloques funcionales del código (carga, limpieza,
   transformación, cálculo, calibración, salida, publicación).
2. Mapea cada bloque a la sección del manual que lo describe.
3. Marca: bloques sin documentación, documentación sin bloque, y diferencias de
   parámetros entre código y manual.
4. Revisa el log: errores, warnings silenciados, rutas absolutas, credenciales
   embebidas, semillas no fijadas, dependencias sin versión.
5. Reproduce al menos un output declarado y compara cifra a cifra.

FORMATO DE SALIDA
| Bloque de código | Ubicación exacta | Sección del manual | Coincide | Evaluación sustentada | Fuente exacta | Acción pendiente |

REGLAS ESPECÍFICAS
- Parámetro hardcodeado que difiere del manual: "No cumple", sin excepción.
- Warning suprimido que oculta pérdida de registros: hallazgo crítico.
- Falta de semilla aleatoria en un proceso estocástico: "Cumple con observación"
  en Tier 3 y "No cumple" en Tier 1 y Tier 2, por irreproducibilidad.
```

## Fila de ejemplo (ficticia)

| Bloque de código | Ubicación exacta | Sección del manual | Coincide | Evaluación sustentada | Fuente exacta | Acción pendiente |
|---|---|---|---|---|---|---|
| Corte de score para segmento PYME | `pipeline_pd.py > asignar_segmento() > líneas 188-204` | 6.2 Segmentación | No | El código aplica un corte en 620 puntos mientras el manual documenta 640; la diferencia reclasifica 4 128 clientes (2,7 % de la cartera) hacia el segmento de menor PD | `pipeline_pd.py > línea 193`; `Manual_Metodologico_PD_Retail_v3.pdf > 6.2 Segmentación > p.48`; `output_scores_2026Q2.csv` | Alinear código y manual, declarar cuál corte es el aprobado y recalcular el output del ciclo — bloqueante para el cierre de la validación |

