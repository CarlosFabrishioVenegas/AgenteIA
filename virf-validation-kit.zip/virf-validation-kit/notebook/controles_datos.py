# %% [markdown]
# # Notebook de Controles de Calidad de Datos — Estándar VIRF
# Validación periódica. Genera la matriz de 7 columnas del Control 2:
# Dimensión | Control esperado | ¿Existe según evidencia? | Diagnóstico |
# Decisión | Control o evidencia requerida | Referencia en el entregable
#
# Regla de auditabilidad: todo resultado se acompaña de su referencia
# (archivo > columna > celda del notebook) y del hash SHA-256 del insumo.

# %%
# =============================================================================
# CELDA 1 — CONFIGURACIÓN DEL CICLO DE VALIDACIÓN
# =============================================================================
CONFIG = {
    "modelo_nombre": "[SUPUESTO-G01]",
    "modelo_codigo": "[SUPUESTO-G02]",
    "tiering": "Tier 2",                  # Tier 1 / Tier 2 / Tier 3
    "ciclo": "2026Q2",
    "validador": "[nombre del validador]",
    "ruta_dataset": "inputs/base_modelo.csv",       # dataset del ciclo evaluado
    "ruta_dataset_ref": "inputs/base_modelo_ref.csv",  # ventana de referencia (PSI)
    "ruta_controles": "inputs/ControlesData.xlsx",   # catálogo de controles esperados
    "ruta_salida": "outputs/",
    "usar_datos_demo": True,   # True => genera datos sintéticos si no hay insumos
    # Umbrales por defecto; se sobrescriben con ControlesData.xlsx si existe
    "umbral_nulos": 0.02,
    "umbral_duplicados": 0.0,
    "umbral_psi": 0.10,
    "dias_max_desfase": 45,
}

# Reglas de negocio declaradas en el manual (deben citarse en el manual)
REGLAS_VALIDEZ = {
    "edad": (18, 100),
    "ingreso_declarado": (0, 500000),
    "score": (0, 1000),
    "prob_default": (0.0, 1.0),
}
LLAVE_PRIMARIA = ["id_cliente"]
COLUMNA_FECHA = "fecha_corte"
COLUMNA_SEGMENTO = "segmento"
CATALOGO_SEGMENTOS = ["RETAIL", "PYME", "CORPORATIVO"]

# %%
# =============================================================================
# CELDA 2 — IMPORTS Y UTILIDADES DE TRAZABILIDAD
# =============================================================================
import hashlib
import os
import warnings
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

warnings.filterwarnings("default")  # nunca silenciar warnings en validación
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 50)

EJECUCION = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def sha256_archivo(ruta: str) -> str:
    """Hash SHA-256 para cadena de custodia. Devuelve 'ARCHIVO_NO_ENCONTRADO'."""
    if not os.path.exists(ruta):
        return "ARCHIVO_NO_ENCONTRADO"
    h = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(8192), b""):
            h.update(bloque)
    return h.hexdigest()


def sha256_dataframe(df: pd.DataFrame) -> str:
    return hashlib.sha256(
        pd.util.hash_pandas_object(df, index=True).values.tobytes()
    ).hexdigest()


def referencia(celda: str, detalle: str) -> str:
    """Construye la referencia auditable exigida por la columna 7."""
    return f"notebook_controles_datos.ipynb > {celda} > {detalle}"


RESULTADOS = []  # acumulador de filas de la matriz


def registrar(dimension, control_esperado, existe, diagnostico, decision,
              requerido, ref):
    RESULTADOS.append({
        "Dimensión": dimension,
        "Control esperado": control_esperado,
        "¿Existe según evidencia?": existe,
        "Diagnóstico": diagnostico,
        "Decisión": decision,
        "Control o evidencia requerida": requerido,
        "Referencia en el entregable": ref,
    })


print(f"Ejecución: {EJECUCION}")
print(f"Modelo: {CONFIG['modelo_codigo']} | {CONFIG['tiering']} | {CONFIG['ciclo']}")

# %%
# =============================================================================
# CELDA 3 — CATÁLOGO DE CONTROLES ESPERADOS (ControlesData.xlsx)
# =============================================================================
CATALOGO_DEFECTO = pd.DataFrame([
    ["Completitud", "Nulos <= 2% en variables explicativas", "umbral_nulos", 0.02],
    ["Unicidad", "Sin duplicados por llave primaria", "umbral_duplicados", 0.0],
    ["Validez", "Valores dentro de rangos declarados en el manual", "reglas", np.nan],
    ["Consistencia", "Categorías dentro del catálogo declarado", "catalogo", np.nan],
    ["Exactitud", "Sin valores imposibles ni outliers extremos no documentados", "z", 5.0],
    ["Integridad referencial", "Llaves presentes en la tabla maestra", "referencial", np.nan],
    ["Oportunidad", "Desfase de la fecha de corte <= 45 días", "dias_max_desfase", 45],
    ["Estabilidad poblacional", "PSI <= 0.10 vs. ventana de referencia", "umbral_psi", 0.10],
    ["Trazabilidad del linaje", "Origen documentado por campo (tabla y sistema)", "linaje", np.nan],
], columns=["Dimensión", "Control esperado", "Parametro", "Umbral"])

if os.path.exists(CONFIG["ruta_controles"]):
    CATALOGO = pd.read_excel(CONFIG["ruta_controles"])
    ORIGEN_CATALOGO = (f"{CONFIG['ruta_controles']} "
                       f"(SHA-256 {sha256_archivo(CONFIG['ruta_controles'])[:16]}...)")
else:
    CATALOGO = CATALOGO_DEFECTO.copy()
    ORIGEN_CATALOGO = "[SUPUESTO] Catálogo por defecto del notebook — ControlesData.xlsx no entregado"

print(f"Catálogo de controles: {ORIGEN_CATALOGO}")
CATALOGO

# %%
# =============================================================================
# CELDA 4 — CARGA DE DATOS (con generador sintético para demostración)
# =============================================================================
def generar_demo(n=5000, semilla=42):
    """Datos sintéticos con defectos deliberados, para probar el notebook."""
    rng = np.random.default_rng(semilla)
    df = pd.DataFrame({
        "id_cliente": np.arange(1, n + 1),
        "fecha_corte": pd.Timestamp.today().normalize() - pd.Timedelta(days=20),
        "edad": rng.integers(18, 85, n),
        "ingreso_declarado": rng.lognormal(8.2, 0.6, n).round(2),
        "score": rng.integers(300, 950, n),
        "prob_default": rng.beta(2, 40, n).round(6),
        "segmento": rng.choice(CATALOGO_SEGMENTOS, n, p=[0.7, 0.25, 0.05]),
    })
    # Defectos inyectados a propósito
    df.loc[rng.choice(n, int(n * 0.074), replace=False), "ingreso_declarado"] = np.nan
    df.loc[rng.choice(n, 12, replace=False), "edad"] = 130           # validez
    df.loc[rng.choice(n, 8, replace=False), "segmento"] = "SIN_DATO"  # consistencia
    df = pd.concat([df, df.sample(15, random_state=1)], ignore_index=True)  # duplicados
    return df


def cargar(ruta, demo_fn):
    if os.path.exists(ruta):
        df = pd.read_csv(ruta) if ruta.endswith(".csv") else pd.read_parquet(ruta)
        origen = f"{ruta} (SHA-256 {sha256_archivo(ruta)[:16]}...)"
    elif CONFIG["usar_datos_demo"]:
        df = demo_fn()
        origen = f"[DEMO] datos sintéticos — {ruta} no encontrado"
    else:
        raise FileNotFoundError(f"Insumo obligatorio no entregado: {ruta}")
    return df, origen


df, ORIGEN_DATOS = cargar(CONFIG["ruta_dataset"], generar_demo)
df_ref, ORIGEN_REF = cargar(
    CONFIG["ruta_dataset_ref"], lambda: generar_demo(4000, semilla=7)
)

if COLUMNA_FECHA in df.columns:
    df[COLUMNA_FECHA] = pd.to_datetime(df[COLUMNA_FECHA], errors="coerce")

HASH_DATASET = sha256_dataframe(df)
print(f"Dataset evaluado: {ORIGEN_DATOS} | filas={len(df)} | columnas={df.shape[1]}")
print(f"Hash del dataframe: {HASH_DATASET[:32]}...")
print(f"Ventana de referencia: {ORIGEN_REF} | filas={len(df_ref)}")

# %%
# =============================================================================
# CELDA 5 — FUNCIONES DE CONTROL POR DIMENSIÓN
# =============================================================================
def ctrl_completitud(df, umbral):
    nulos = (df.isna().mean().sort_values(ascending=False)).round(4)
    incumplen = nulos[nulos > umbral]
    return nulos, incumplen


def ctrl_unicidad(df, llave):
    faltan = [c for c in llave if c not in df.columns]
    if faltan:
        return None, faltan
    dup = df.duplicated(subset=llave, keep=False)
    return df.loc[dup, llave].drop_duplicates(), []


def ctrl_validez(df, reglas):
    filas = []
    for col, (lo, hi) in reglas.items():
        if col not in df.columns:
            filas.append({"variable": col, "estado": "COLUMNA_AUSENTE",
                          "fuera_rango": np.nan, "pct": np.nan})
            continue
        serie = pd.to_numeric(df[col], errors="coerce")
        fuera = int(((serie < lo) | (serie > hi)).sum())
        filas.append({"variable": col, "estado": "OK" if fuera == 0 else "FUERA_DE_RANGO",
                      "fuera_rango": fuera, "pct": round(fuera / len(df), 4)})
    return pd.DataFrame(filas)


def ctrl_consistencia(df, col, catalogo):
    if col not in df.columns:
        return None
    obs = df[col].astype(str).value_counts(dropna=False)
    fuera = obs[~obs.index.isin(catalogo)]
    return fuera


def ctrl_exactitud(df, z_max=5.0):
    num = df.select_dtypes(include=[np.number])
    filas = []
    for col in num.columns:
        s = num[col].dropna()
        if len(s) < 30 or s.std(ddof=0) == 0:
            continue
        z = (s - s.mean()) / s.std(ddof=0)
        filas.append({"variable": col, "n_outliers_z>%.1f" % z_max: int((z.abs() > z_max).sum()),
                      "min": s.min(), "max": s.max()})
    return pd.DataFrame(filas)


def ctrl_referencial(df, llave, maestra=None):
    if maestra is None:
        return None
    faltantes = ~df[llave[0]].isin(maestra[llave[0]])
    return int(faltantes.sum())


def ctrl_oportunidad(df, col_fecha, dias_max):
    if col_fecha not in df.columns or df[col_fecha].isna().all():
        return None
    desfase = (pd.Timestamp.today().normalize() - df[col_fecha].max()).days
    return {"fecha_max": df[col_fecha].max(), "desfase_dias": int(desfase),
            "cumple": bool(desfase <= dias_max)}


def psi(actual, referencia_, bins=10):
    """Population Stability Index sobre una variable numérica."""
    actual = pd.to_numeric(actual, errors="coerce").dropna()
    referencia_ = pd.to_numeric(referencia_, errors="coerce").dropna()
    if len(actual) < 50 or len(referencia_) < 50:
        return np.nan
    cortes = np.unique(np.quantile(referencia_, np.linspace(0, 1, bins + 1)))
    if len(cortes) < 3:
        return np.nan
    cortes[0], cortes[-1] = -np.inf, np.inf
    a = np.histogram(actual, bins=cortes)[0] / len(actual)
    r = np.histogram(referencia_, bins=cortes)[0] / len(referencia_)
    a, r = np.where(a == 0, 1e-6, a), np.where(r == 0, 1e-6, r)
    return float(np.sum((a - r) * np.log(a / r)))


def ctrl_estabilidad(df, df_ref, umbral):
    filas = []
    for col in df.select_dtypes(include=[np.number]).columns:
        if col in LLAVE_PRIMARIA or col not in df_ref.columns:
            continue
        v = psi(df[col], df_ref[col])
        filas.append({"variable": col, "PSI": None if np.isnan(v) else round(v, 4),
                      "cumple": None if np.isnan(v) else bool(v <= umbral)})
    return pd.DataFrame(filas)


def ctrl_linaje(ruta_manual="inputs/manual_controles_datos.md", columnas=None):
    """El linaje es documental: se verifica que cada campo esté descrito."""
    if not os.path.exists(ruta_manual):
        return None, columnas or []
    texto = open(ruta_manual, encoding="utf-8", errors="ignore").read().lower()
    sin_doc = [c for c in (columnas or []) if c.lower() not in texto]
    return ruta_manual, sin_doc

# %%
# =============================================================================
# CELDA 6 — EJECUCIÓN DE CONTROLES Y CONSTRUCCIÓN DE LA MATRIZ
# =============================================================================
# --- Completitud ---
nulos, incumplen = ctrl_completitud(df, CONFIG["umbral_nulos"])
registrar(
    "Completitud",
    f"Nulos <= {CONFIG['umbral_nulos']:.0%} en variables explicativas",
    "Sí" if len(incumplen) == 0 else "Sí, parcialmente",
    (f"{df.shape[1] - len(incumplen)} de {df.shape[1]} columnas cumplen. "
     f"Incumplen: {', '.join(f'{c} ({v:.2%})' for c, v in incumplen.items()) or 'ninguna'}"),
    "Cumple" if len(incumplen) == 0 else "No cumple — remediar antes del siguiente ciclo",
    "Ninguna" if len(incumplen) == 0 else
    "Documentar la regla de tratamiento de nulos y su análisis de sensibilidad",
    referencia("celda 6", f"tabla de nulos; dataset {ORIGEN_DATOS}"),
)

# --- Unicidad ---
dups, faltan_llave = ctrl_unicidad(df, LLAVE_PRIMARIA)
if faltan_llave:
    registrar("Unicidad", "Sin duplicados por llave primaria", "No",
              f"La llave declarada {faltan_llave} no existe en el dataset",
              "No evidenciado", "Declarar y entregar la llave primaria del modelo",
              referencia("celda 6", "control de unicidad"))
else:
    n_dup = 0 if dups is None else len(dups)
    registrar(
        "Unicidad", "Sin duplicados por llave primaria",
        "Sí" if n_dup == 0 else "Sí, con incumplimiento",
        f"{n_dup} llaves duplicadas sobre {len(df)} registros ({n_dup/len(df):.3%})",
        "Cumple" if n_dup == 0 else "No cumple — depurar y explicar el origen",
        "Ninguna" if n_dup == 0 else "Evidencia del proceso de deduplicación en la carga",
        referencia("celda 6", f"columnas {LLAVE_PRIMARIA}"),
    )

# --- Validez ---
val = ctrl_validez(df, REGLAS_VALIDEZ)
fuera = val[val["estado"] == "FUERA_DE_RANGO"]
registrar(
    "Validez", "Valores dentro de los rangos declarados en el manual",
    "Sí" if fuera.empty else "Sí, con incumplimiento",
    (f"{len(fuera)} variables con valores fuera de rango: "
     f"{', '.join(f'{r.variable} ({int(r.fuera_rango)} reg.)' for r in fuera.itertuples()) or 'ninguna'}"),
    "Cumple" if fuera.empty else "No cumple — corregir en origen",
    "Ninguna" if fuera.empty else "Regla de rechazo o corrección documentada en el manual",
    referencia("celda 6", "tabla de validez por variable"),
)

# --- Consistencia ---
fuera_cat = ctrl_consistencia(df, COLUMNA_SEGMENTO, CATALOGO_SEGMENTOS)
registrar(
    "Consistencia", "Categorías dentro del catálogo declarado",
    "Sí" if (fuera_cat is not None and fuera_cat.empty) else "Sí, con incumplimiento",
    ("Sin categorías fuera de catálogo" if (fuera_cat is not None and fuera_cat.empty)
     else f"Categorías no catalogadas: {dict(fuera_cat) if fuera_cat is not None else 'columna ausente'}"),
    "Cumple" if (fuera_cat is not None and fuera_cat.empty) else "Cumple con observación",
    "Actualizar el catálogo o corregir el mapeo en la carga",
    referencia("celda 6", f"columna {COLUMNA_SEGMENTO}"),
)

# --- Exactitud ---
exa = ctrl_exactitud(df)
col_out = [c for c in exa.columns if c.startswith("n_outliers")][0] if not exa.empty else None
n_out = int(exa[col_out].sum()) if col_out else 0
registrar(
    "Exactitud", "Sin valores imposibles ni outliers extremos no documentados",
    "Sí",
    f"{n_out} observaciones con |z| > 5 en {len(exa)} variables numéricas evaluadas",
    "Cumple con observación" if n_out > 0 else "Cumple",
    "Sustento documental del tratamiento de outliers" if n_out > 0 else "Ninguna",
    referencia("celda 6", "tabla de exactitud"),
)

# --- Integridad referencial ---
registrar(
    "Integridad referencial", "Llaves presentes en la tabla maestra", "No",
    "No se entregó la tabla maestra de clientes para el cruce",
    "No evidenciado",
    "Entregar extracto de la tabla maestra del ciclo y repetir el cruce",
    referencia("celda 6", "control referencial — insumo no recibido"),
)

# --- Oportunidad ---
opo = ctrl_oportunidad(df, COLUMNA_FECHA, CONFIG["dias_max_desfase"])
registrar(
    "Oportunidad", f"Desfase de la fecha de corte <= {CONFIG['dias_max_desfase']} días",
    "Sí" if opo else "No",
    (f"Fecha de corte máxima {opo['fecha_max']:%Y-%m-%d}, desfase {opo['desfase_dias']} días"
     if opo else "Columna de fecha ausente o vacía"),
    ("Cumple" if opo and opo["cumple"] else "No cumple"),
    "Ninguna" if opo and opo["cumple"] else "Justificar el desfase y su impacto en el output",
    referencia("celda 6", f"columna {COLUMNA_FECHA}"),
)

# --- Estabilidad poblacional ---
est = ctrl_estabilidad(df, df_ref, CONFIG["umbral_psi"])
inest = est[est["cumple"] == False] if not est.empty else est
registrar(
    "Estabilidad poblacional", f"PSI <= {CONFIG['umbral_psi']} vs. ventana de referencia",
    "Sí",
    (f"{len(inest)} de {len(est)} variables superan el umbral: "
     f"{', '.join(f'{r.variable} (PSI {r.PSI})' for r in inest.itertuples()) or 'ninguna'}"),
    "Cumple" if len(inest) == 0 else "Cumple con observación — monitorear",
    "Ninguna" if len(inest) == 0 else "Análisis de causa del desplazamiento poblacional",
    referencia("celda 6", "tabla PSI"),
)

# --- Trazabilidad del linaje ---
ruta_manual, sin_doc = ctrl_linaje(columnas=list(df.columns))
registrar(
    "Trazabilidad del linaje", "Origen documentado por campo (tabla y sistema)",
    "Sí" if ruta_manual else "No",
    (f"Campos sin descripción en el manual: {sin_doc}" if ruta_manual
     else "No se entregó manual_controles_datos.md"),
    "Cumple" if (ruta_manual and not sin_doc) else "No evidenciado",
    "Entregar el manual de controles de datos con el linaje campo a campo",
    referencia("celda 6", "manual_controles_datos.md"),
)

MATRIZ = pd.DataFrame(RESULTADOS)
MATRIZ

# %%
# =============================================================================
# CELDA 7 — RESUMEN, EXPORTACIÓN Y CADENA DE CUSTODIA
# =============================================================================
resumen = MATRIZ["Decisión"].str.split(" —").str[0].value_counts()
print("Resumen de decisiones:")
print(resumen.to_string())

BLOQUEANTES = MATRIZ[MATRIZ["Decisión"].str.startswith(("No cumple", "No evidenciado"))]
print(f"\nHallazgos que bloquean el cierre del control: {len(BLOQUEANTES)}")

os.makedirs(CONFIG["ruta_salida"], exist_ok=True)
stamp = datetime.now().strftime("%Y%m%d_%H%M")
base = f"{CONFIG['ruta_salida']}matriz_calidad_datos_{CONFIG['modelo_codigo']}_{stamp}"
MATRIZ.to_csv(f"{base}.csv", index=False, encoding="utf-8-sig")
try:
    with pd.ExcelWriter(f"{base}.xlsx") as xw:
        MATRIZ.to_excel(xw, sheet_name="Matriz_7_columnas", index=False)
        nulos.to_frame("pct_nulos").to_excel(xw, sheet_name="Anexo_nulos")
        val.to_excel(xw, sheet_name="Anexo_validez", index=False)
        est.to_excel(xw, sheet_name="Anexo_PSI", index=False)
except Exception as e:  # openpyxl ausente: el CSV es la salida mínima
    print(f"Exportación a Excel no disponible ({e}); se generó el CSV.")

CUSTODIA = pd.DataFrame([
    {"insumo": CONFIG["ruta_dataset"], "sha256": sha256_archivo(CONFIG["ruta_dataset"]),
     "origen": ORIGEN_DATOS},
    {"insumo": CONFIG["ruta_dataset_ref"], "sha256": sha256_archivo(CONFIG["ruta_dataset_ref"]),
     "origen": ORIGEN_REF},
    {"insumo": CONFIG["ruta_controles"], "sha256": sha256_archivo(CONFIG["ruta_controles"]),
     "origen": ORIGEN_CATALOGO},
    {"insumo": "dataframe evaluado (en memoria)", "sha256": HASH_DATASET, "origen": "runtime"},
])
CUSTODIA.to_csv(f"{base}_custodia.csv", index=False, encoding="utf-8-sig")

print(f"\nSalidas generadas: {base}.csv / .xlsx / _custodia.csv")
print(f"Validador: {CONFIG['validador']} | Ejecución: {EJECUCION}")
CUSTODIA
