---
title: "Guía de uso de los prompts y agentes VIRF"
subtitle: "Con qué llenarlos y qué documentos cargar como conocimiento"
author: "Unidad de Validación de Modelos (MRM) — Validaciones Periódicas"
date: "Versión 1.0 — complemento del Marco Operativo"
lang: es
toc-title: "Contenido"
---

\newpage

# 1. Cómo se usan

Los prompts del marco funcionan en tres modos. El contenido es el mismo; cambia dónde vive la evidencia.

| Modo | Cuándo conviene | Dónde va la evidencia | Riesgo principal |
|---|---|---|---|
| Chat con adjuntos | Un control puntual, un modelo, una sola sesión | Se adjunta en la conversación | Al cerrar la sesión se pierde el contexto; hay que re-adjuntar |
| Agente de Copilot Studio | Uso recurrente por todo el equipo, mismos criterios en todas las validaciones | Doctrina estable en *Knowledge*; evidencia del ciclo adjunta en la conversación | Cargar evidencia de un modelo como conocimiento permanente contamina las validaciones de otros modelos |
| Notebook | Control de Calidad de Datos | Archivos en `inputs/` | Ninguno relevante, salvo trabajar sobre una base ya depurada |

La distinción que más errores evita:

- **Conocimiento (Knowledge):** lo que no cambia entre modelos ni entre ciclos. Estándar VIRF, políticas, criterios de tiering, plantillas oficiales, normas. Se carga una vez y se actualiza cuando cambia la norma.
- **Evidencia del ciclo:** manuales, acta, código, correos y actas de comité de *este* modelo en *este* trimestre. Se adjunta en la conversación y se descarta al cerrar el ciclo.

Cargar manuales de un modelo específico como conocimiento permanente del agente es el error más costoso: seis meses después el agente citará el manual del modelo equivocado y la cita parecerá válida.

## 1.1 Secuencia de trabajo en un ciclo

1. Preparar la carpeta del ciclo y renombrar los archivos (sección 4).
2. Ejecutar A1 y A2 sobre los manuales y la herramienta.
3. Ejecutar A4 para consolidar el Paso 0 y obtener el mapa de evidencia.
4. Emitir la primera re-entrega con lo que falte, antes de tocar los controles.
5. Ejecutar A3 y luego A6 (datos), después A5, A7 y A8, y finalmente A9 y A10.
6. Consolidar con A11 y revisar la tabla de 8 columnas antes de firmar.

Si el paso 4 se salta, los seis controles producirán filas en estado "No evidenciado" que después habrá que rehacer.

\newpage

# 2. La ficha de contexto

Este bloque se pega **al inicio de cada prompt**, después del encabezado de sistema. Es lo que convierte un prompt genérico en una validación de tu modelo. Sin él, el agente no sabe qué tier aplicar, qué actividades son exigibles ni contra qué comparar.

```text
=== FICHA DE CONTEXTO DEL MODELO ===
Modelo:                 [nombre oficial, tal como figura en el acta]
Código de inventario:   [código]
Tiering:                Tier 1 / Tier 2 / Tier 3
Tipo de validación:     Periódica
Ciclo evaluado:         [AAAA-QN o AAAA-MM]
Fecha de corte de la evidencia: [AAAA-MM-DD]
Validador:              [nombre]

Propósito del modelo en una línea:
  [qué decisión soporta]

Cadena del modelo:
  Inputs:          [fuentes principales: sistema y tabla]
  Transformación:  [2 o 3 pasos clave]
  Output:          [qué produce: curva, score, %, provisión]
  Destinatario:    [área usuaria]
  Uso declarado:   [para qué está autorizado, según el acta]

Herramienta:
  Tipo:            Python / Excel / SAS / otro
  Estado:          corre sin errores / corre con errores / no probada / no entregada
  Ubicación:       [ruta]

Periodicidad comprometida:  [mensual / trimestral / semestral]
Comité o foro donde se sustenta: [nombre del foro]

Historial:
  Última validación:        [fecha]
  Observaciones abiertas:   [número y las dos más severas]
  Cambios en este ciclo:    [recalibración, cambio de variables, sin cambios]

Evidencia adjunta en esta sesión:
  1. [archivo] — [qué contiene]
  2. [archivo] — [qué contiene]

Evidencia solicitada y no recibida:
  1. [archivo] — solicitada el [fecha]

Ambigüedades conocidas:
  1. [lo que el equipo no ha aclarado todavía]
=== FIN DE LA FICHA ===
```

## 2.1 Ejemplo llenado (ficticio)

```text
=== FICHA DE CONTEXTO DEL MODELO ===
Modelo:                 Modelo de Probabilidad de Incumplimiento — Cartera Retail
Código de inventario:   MOD-0412
Tiering:                Tier 2
Tipo de validación:     Periódica
Ciclo evaluado:         2026Q2
Fecha de corte de la evidencia: 2026-08-29
Validador:              [nombre]

Propósito del modelo en una línea:
  Estima la PD a 12 meses por cliente para el cálculo de provisiones y la
  asignación de segmento de riesgo en originación.

Cadena del modelo:
  Inputs:          Datamart Riesgos (DM_CLIENTE, DM_COMPORTAMIENTO), score de buró
  Transformación:  filtro de universo (antigüedad >= 6 meses) -> construcción de
                   variables de comportamiento a 6 meses -> regresión logística ->
                   escalamiento a tasa central
  Output:          curva de PD trimestral por segmento y PD individual por cliente
  Destinatario:    Gestión de Riesgo Minorista
  Uso declarado:   provisiones IFRS 9 y segmentación en originación

Herramienta:
  Tipo:            Python
  Estado:          corre sin errores, corrida del 2026-07-05
  Ubicación:       repositorio riesgos/pd_retail, rama produccion, tag v3.2

Periodicidad comprometida:  trimestral
Comité o foro donde se sustenta: Comité de Riesgos

Historial:
  Última validación:        2025Q4
  Observaciones abiertas:   2 — OBS-2025Q4-02 (regla de imputación no documentada,
                            vencida) y OBS-2025Q4-05 (linaje incompleto)
  Cambios en este ciclo:    recalibración de la tasa central, sin cambio de variables

Evidencia adjunta en esta sesión:
  1. MOD-0412_2026Q2_ManualMetodologico_v3.pdf — metodología completa
  2. MOD-0412_2026Q2_Acta.pdf — acta del modelo vigente
  3. MOD-0412_2026Q2_InformeValidacion_2025Q4.pdf — validación anterior

Evidencia solicitada y no recibida:
  1. Log de ejecución del cierre 2026Q2 — solicitado el 2026-08-28

Ambigüedades conocidas:
  1. El manual declara ventana de desempeño de 12 meses y el acta de 18 meses.
=== FIN DE LA FICHA ===
```

## 2.2 Cómo llenar bien cada campo

| Campo | Un valor útil | Un valor que hace daño | Por qué importa |
|---|---|---|---|
| Tiering | `Tier 2` | `no sé` o dejarlo vacío | Determina qué actividades del estándar son exigibles; sin él, el agente evalúa de más o de menos |
| Fecha de corte de la evidencia | `2026-08-29` | omitirlo | Define hasta cuándo alcanza el juicio; un auditor lo pregunta siempre |
| Cadena del modelo | Sistemas y tablas con nombre | `datos del banco` | Sin nombres, el agente no puede detectar que el código lee otra tabla |
| Estado de la herramienta | `corre sin errores, corrida del 2026-07-05` | `sí funciona` | Es la precondición del control de Implementación |
| Uso declarado | Copiado literal del acta | Una reformulación tuya | El control de Usos compara el uso real contra el declarado; si lo reformulas, comparas contra tu paráfrasis |
| Observaciones abiertas | Con ID, estado y fecha comprometida | `hay algunas pendientes` | Sin ID no se puede verificar el cierre |
| Cambios en este ciclo | `recalibración de la tasa central` | `sin novedad` cuando sí hubo cambios | Un cambio no declarado y luego detectado se convierte en hallazgo de gobierno |
| Ambigüedades conocidas | La contradicción concreta | dejarlo vacío por incomodidad | Declararla evita que el agente elija una versión en silencio |

## 2.3 Reglas de llenado

1. **Copia, no parafrasees.** El uso declarado, las limitaciones y los supuestos van literales del acta o del manual. Tu paráfrasis se convierte en el criterio contra el que se valida, y eso invalida la comparación.
2. **Si no sabes un campo, escribe `No evidenciado`**, no lo dejes vacío ni pongas lo que crees. El vacío se lee como "no aplica".
3. **No pegues datos de clientes.** Ni nombres, ni documentos de identidad, ni saldos individuales. Los agentes trabajan con estructura, métricas agregadas y documentación, nunca con registros identificables.
4. **Una sesión, un modelo.** No valides dos modelos en la misma conversación: el agente mezclará citas y el error es difícil de detectar.
5. **Cierra la ficha antes de adjuntar.** Adjuntar primero y describir después hace que el agente empiece a leer sin saber qué busca.

\newpage

# 3. Qué necesita cada prompt

Además de la ficha, cada prompt exige adjuntos propios. Si falta un adjunto obligatorio, el prompt no se ejecuta a medias: se responde con la lista de faltantes.

| Prompt | Adjuntos obligatorios | Adjuntos que mejoran el resultado | Campos críticos de la ficha |
|---|---|---|---|
| C1 Documentación | Manuales, acta, estándar VIRF filtrado por tier | Informe de validación anterior, plantilla oficial de manual | Tiering, observaciones abiertas |
| C2 Calidad de Datos | Matriz de 7 columnas del notebook, catálogo de controles | Diccionario de datos, política de calidad de datos | Cadena del modelo (para pesar la materialidad) |
| C3 Metodología | Manual metodológico, papers, resultados de pruebas | Informe de seguimiento, umbrales de aceptación declarados | Cambios en el ciclo, limitaciones declaradas |
| C4 Implementación | Código o notebook, log de ejecución, outputs del ciclo, manuales | Registro de pase a producción, mapa de trazabilidad de A2 | Estado de la herramienta, versión que corrió |
| C5 Gobierno | Acta, criterios de tiering, matrices de C1 a C4 | Extracto del inventario, matriz de roles | Tiering, propietario, periodicidad |
| C6 Usos | Correos con acuse, actas de comité | Evidencia de publicación, estadística de consumo | Uso declarado, destinatario, periodicidad |
| Re-entrega | Matrices ya emitidas con sus faltantes | Cronograma del kick-off | Fecha límite del ciclo |
| Seguimiento | Informe de validación anterior, evidencia de subsanación | Correos de compromiso | Observaciones abiertas con ID |
| Consolidación | Las seis matrices, estándar VIRF | Reporte de seguimiento, Paso 0 | Tiering, ciclo, fecha de corte |

**Regla de oro para los adjuntos:** el agente solo puede citar lo que le diste. Si el hallazgo esperado depende de un documento que no adjuntaste, no aparecerá, y su ausencia se leerá como cumplimiento aparente.
\newpage

# 4. Cómo preparar los PDF antes de cargarlos

La calidad de la cita depende de la calidad del archivo. Un PDF mal preparado produce citas que no se pueden verificar, y una cita no verificable equivale a no tener evidencia.

## 4.1 Requisitos mínimos

| Requisito | Regla | Qué pasa si no se cumple |
|---|---|---|
| Capa de texto | El PDF debe permitir seleccionar y buscar texto | Un escaneo sin OCR devuelve "PDF no extraíble"; el agente no puede leerlo |
| Numeración | Con numeración impresa; si no la tiene, se anota "página física" | Las citas no se pueden verificar sin contar páginas manualmente |
| Una sola versión | Nunca dos versiones del mismo manual en la misma carpeta | El agente citará la versión equivocada y la cita parecerá correcta |
| Tamaño | Dividir documentos de más de 300 páginas por capítulos | Los documentos muy largos se leen por bloques y baja la cobertura efectiva |
| Anexos | Los anexos referenciados se cargan junto al documento principal | Se registran como "referencia a anexo no recibido" y quedan como faltante |
| Tablas | Preferir el archivo fuente en Excel a una imagen de la tabla | Una imagen de tabla no es auditable ni recalculable |

## 4.2 Convención de nombres

Un nombre bien construido hace la mitad del trabajo de la trazabilidad, porque aparece dentro de cada cita:

```
<CODIGO>_<CICLO>_<TipoDocumento>_<version>.pdf

MOD-0412_2026Q2_ManualMetodologico_v3.pdf
MOD-0412_2026Q2_ManualUsuario_v2.pdf
MOD-0412_2026Q2_Acta.pdf
MOD-0412_2026Q2_InformeValidacion_2025Q4.pdf
MOD-0412_2026Q2_ActaComiteRiesgos_118.pdf
MOD-0412_2026Q2_CorreoEnvioCurva_2026-07-08.pdf
```

Evita nombres como `manual final FINAL v2 (1).pdf`: la cita resultante es inútil para un tercero y para ti mismo dentro de seis meses.

## 4.3 Estructura de carpetas del ciclo

```
MRM/Validaciones/MOD-0412/2026Q2/
├── 00_entendimiento/      salida de A1 y A4, infografía
├── 01_documentacion/      manuales, anexos, acta
├── 02_calidad_datos/      ControlesData.xlsx, manual de controles, datasets
├── 03_metodologia/        papers, resultados de pruebas
├── 04_implementacion/     código, logs, outputs, registro de pase
├── 05_gobierno/           acta, extracto del inventario, consultas
├── 06_usos/               correos en PDF, actas de comité
├── 07_salidas/            matrices por control, informe final
└── inventario.csv         archivo, tipo, fecha, versión, hash SHA-256
```

El `inventario.csv` con los hashes es lo que sostiene la cadena de custodia. Se genera una vez al cerrar la recepción de evidencia y no se vuelve a tocar; si llega un documento después, se registra como evidencia extemporánea con su propia fecha.

\newpage

# 5. Qué cargar como conocimiento en cada agente

## 5.1 Núcleo común

Estos cuatro documentos se cargan en **los once agentes**. Son doctrina, no evidencia: cambian cuando cambia la norma, no cuando cambia el modelo.

| Documento | Contenido | Cuándo se actualiza |
|---|---|---|
| `VIRF_Estandar_Actividades.pdf` | Las actividades del estándar con su ID, aplicabilidad por tier y por periodicidad. Exportado desde `Estandares_VIRF.xlsx` | Al publicarse una nueva versión del estándar |
| `MRM_Politica_Riesgo_Modelos.pdf` | Política interna: roles, ciclo de vida del modelo, obligaciones del propietario, criterios de retiro | Anual o ante cambio normativo |
| `MRM_Criterios_Tiering.pdf` | Umbrales y criterios de asignación de tier | Al revisarse los umbrales |
| `MRM_Reglas_Citacion_y_Estados.pdf` | La regla maestra de auditabilidad y el semáforo de estados (una o dos páginas, extraídas del Marco Operativo) | Rara vez |

Un quinto opcional, muy útil en la práctica: `MRM_Glosario.pdf`, con la equivalencia entre los nombres que usa el banco y los que usan los manuales de los equipos.

## 5.2 Conocimiento específico por agente

| Agente | Conocimiento estable a cargar | Evidencia del ciclo (se adjunta, no se carga) | No cargar nunca |
|---|---|---|---|
| A1 Entendimiento desde PDFs | Plantilla oficial de manual de modelos; plantilla del `.md` de entendimiento | Manuales, anexos, acta, presentaciones del modelo | Papers académicos, datasets, manuales de otros modelos |
| A2 Excel → `.ipynb` | Estándar interno de desarrollo en Python; guía de equivalencias Excel–Python del banco | La herramienta `.xlsx`, su manual de usuario, diccionario de hojas | Manual metodológico completo (ruido para una tarea de traducción) |
| A3 Evaluador técnico de datos | Política de calidad y gobierno del dato; definición corporativa de las dimensiones; catálogo de controles del banco | `ControlesData.xlsx`, `manual_controles_datos.md`, diccionario de datos, salida del notebook | Bases con datos de clientes; papers |
| A4 Paso 0 | Plantilla del documento de entendimiento; guía de la infografía; ejemplo de un Paso 0 bien hecho | Salida de A1 y A2, minutas, correos del requerimiento, acta, informe anterior | Documentación de otros modelos, aunque sea "parecida" |
| A5 Documentación | Política de documentación de modelos; plantilla oficial de manual; checklist documental interno | Manuales, acta, informe de validación anterior | Código, datasets |
| A6 Calidad de Datos | Política de calidad del dato; marco de linaje; catálogo de controles | Matriz de 7 columnas de A3, diccionario de datos | Datasets crudos |
| A7 Metodología | Guía metodológica interna; normas aplicables (SBS, IFRS 9 o la que corresponda); umbrales de aceptación declarados por el banco | Manual metodológico, papers del expediente, resultados de pruebas | Papers que el equipo no citó (van como recomendación, no como sustento) |
| A8 Implementación | Estándar de desarrollo y de pase a producción; política de control de cambios; guía de reproducibilidad | Código, logs, outputs del ciclo, manuales, mapa de trazabilidad de A2 | Manuales de otros ciclos |
| A9 Gobierno | Plantilla del acta del modelo con la definición de cada campo; criterios de tiering; matriz de roles y segregación; política de inventario | Acta vigente, extracto del inventario, matrices de C1 a C4 | Evidencia técnica cruda |
| A10 Usos | Política de uso, seguimiento y retiro de modelos; reglamento de los comités donde se sustentan modelos | Correos en PDF, actas de comité, evidencia de publicación | Correos que no correspondan a este modelo |
| A11 Validador final | Plantilla oficial del informe de validación; reglas de conclusión y severidad; ejemplo de un informe aprobado | Las seis matrices, reporte de seguimiento, Paso 0 | Evidencia primaria: si tiene que ir a la fuente, es que un control quedó incompleto |

## 5.3 Notas por agente

- **A2 y A8** trabajan con archivos que no son PDF. El código, los logs y la herramienta se adjuntan en la conversación o se ponen en la carpeta del ciclo; lo que va como conocimiento son los estándares de desarrollo del banco, que sí son estables.
- **A7** es el agente donde más se rompe la separación. Los papers son evidencia del ciclo porque forman parte del expediente de *ese* modelo. La guía metodológica interna sí es conocimiento. Cargar papers como conocimiento permanente hace que un modelo herede el sustento de otro.
- **A9** necesita la **plantilla del acta con la definición de cada campo**, no solo el acta. Sin la definición, no puede distinguir entre un campo vacío y un campo que no aplica.
- **A11** no debe tener acceso a la evidencia primaria como conocimiento. Su trabajo es integrar lo que los otros produjeron; si puede ir a la fuente, terminará revalidando y se perderá la trazabilidad del hallazgo hasta el agente que lo emitió.

## 5.4 Reglas de carga

1. **Pocos archivos y muy pertinentes.** Un agente con cuarenta documentos responde peor que uno con seis: la búsqueda se dispersa y las citas pierden precisión. Si dudas de un archivo, no lo cargues.
2. **Verifica los límites vigentes de tu tenant** (número de archivos y tamaño por agente) antes de diseñar la carga; cambian con las versiones de la plataforma y conviene confirmarlos con el administrador.
3. **Un documento, un propósito.** No cargues compendios de varias políticas en un solo PDF: la cita quedará ambigua.
4. **Fecha y versión en el nombre** también para el conocimiento: `MRM_Criterios_Tiering_2025-11.pdf`. Así detectas al vuelo si un agente está razonando con una norma vencida.
5. **Revisa la carga cada semestre** y retira lo derogado. Un agente que cita una política derogada es peor que uno sin conocimiento, porque su respuesta parece fundada.
6. **Prueba después de cargar.** Pregúntale al agente: "¿qué documentos tienes cargados y de qué fecha?" y luego "¿qué actividades de tu control aplican a un modelo Tier 2?". Si no responde con IDs del estándar, la carga no está funcionando.

\newpage

# 6. Errores frecuentes y cómo corregirlos

| Síntoma | Causa habitual | Corrección |
|---|---|---|
| El agente responde bien pero sin citas | Falta la regla de citación en las instrucciones, o el documento no tiene capa de texto | Verifica el PDF con una búsqueda de texto; reincorpora la regla maestra en las instrucciones |
| Cita una sección que no existe | Hay dos versiones del mismo documento cargadas | Deja una sola versión por carpeta y por agente |
| Da todo por cumplido | No se adjuntó la evidencia contra la que debía contrastar | Revisa la tabla de la sección 3: sin adjunto obligatorio, el prompt solo debe devolver faltantes |
| Marca "No aplica" en varias actividades | No se declaró el tier en la ficha de contexto | Completa el tiering; "No aplica" sin cita de la regla que exime está prohibido |
| Mezcla dos modelos | Se validaron dos modelos en la misma sesión, o hay evidencia de otro modelo cargada como conocimiento | Una sesión por modelo; audita el conocimiento del agente |
| Suaviza los hallazgos | El prompt se recortó y se perdió el bloque de prohibiciones | Usa el prompt completo; el bloque de prohibiciones es la parte que sostiene el criterio |
| Inventa un umbral | El umbral no estaba declarado y el agente lo completó | Exige la marca `[SUPUESTO]` y el estado "No verificable" hasta la declaración formal |
| Las cifras no coinciden con el notebook | Se adjuntó una versión anterior de la matriz | Adjunta siempre la salida fechada del notebook, no un copiado del chat |

# 7. Checklist de arranque de ciclo

Antes de la primera ejecución de agentes en un ciclo nuevo:

1. Carpeta del ciclo creada con la estructura de la sección 4.3.
2. Archivos renombrados con la convención y sin versiones duplicadas.
3. PDF verificados: todos permiten búsqueda de texto.
4. `inventario.csv` generado con los hashes SHA-256.
5. Ficha de contexto llenada, con el uso declarado copiado literal del acta.
6. Tier confirmado contra los criterios vigentes, no copiado del ciclo anterior.
7. Núcleo común de conocimiento verificado y vigente en los once agentes.
8. Estado de la herramienta declarado: si no corre, el control de Implementación no se inicia.
9. Observaciones del ciclo anterior listadas con su ID y su fecha comprometida.
10. Fecha de corte de la evidencia fijada y comunicada al equipo dueño del modelo.

Si algún punto no se cumple, el ciclo puede arrancar igual, pero deja constancia: los ítems 5, 6 y 8 son los que con más frecuencia obligan a rehacer trabajo ya emitido.
