# VIRF Validation Kit

Marco operativo para la **validación periódica de modelos** bajo el estándar VIRF:
flujo por seis controles, prompts auditables, agentes de M365 Copilot Studio,
notebook de controles de datos y una vista web navegable.

Todo el material está diseñado bajo una sola regla: **ninguna afirmación de
validación existe sin su fuente exacta** (documento, sección y página; archivo,
hoja y celda; archivo y línea de código).

## Antes de usarlo

- Los datos, cifras, nombres de modelo y hallazgos de los ejemplos son
  **ficticios**. Sirven para mostrar el nivel de detalle exigido, no para
  reutilizarse como conclusión.
- Los marcadores `[SUPUESTO-G01]` a `[SUPUESTO-G12]` corresponden a los campos
  del acta del modelo de cada institución. Reemplázalos antes de usar los
  prompts en producción.
- El estándar VIRF en sí (`Estandares_VIRF.xlsx`) **no** forma parte de este
  repositorio: es material interno de cada institución.

## Estructura

```
docs/       marco operativo y guía de uso, legibles en GitHub
prompts/    un archivo por prompt, listos para copiar
agents/     los 11 agentes de Copilot Studio con sus instrucciones
notebook/   notebook de controles de calidad de datos, ejecutable
site/       vista web del flujo con todos los prompts (una sola página)
src/        fuentes markdown con metadatos, usadas para generar .docx y .pdf
scripts/    estilos LaTeX y generador del diagrama de orquestación
```

## Documentos

| Documento | Descripción |
|---|---|
| [docs/marco-operativo.md](docs/marco-operativo.md) | Flujo, prompts, plantillas, validador final, agentes y orquestación |
| [docs/guia-de-uso.md](docs/guia-de-uso.md) | Con qué llenar los prompts y qué PDFs cargar en cada agente |

## Prompts

| Código | Control o etapa | Archivo |
|---|---|---|
| `FICHA` | Ficha de contexto del modelo | [prompts/00-ficha-de-contexto.md](prompts/00-ficha-de-contexto.md) |
| `C1` | Documentación | [prompts/01-documentacion.md](prompts/01-documentacion.md) |
| `C2` | Calidad de Datos | [prompts/02-calidad-de-datos.md](prompts/02-calidad-de-datos.md) |
| `C3` | Metodología | [prompts/03-metodologia.md](prompts/03-metodologia.md) |
| `C4` | Implementación | [prompts/04-implementacion.md](prompts/04-implementacion.md) |
| `C5` | Gobierno | [prompts/05-gobierno.md](prompts/05-gobierno.md) |
| `C6` | Usos | [prompts/06-usos.md](prompts/06-usos.md) |
| `D1` | Re-entrega de evidencia | [prompts/07-re-entrega-de-evidencia.md](prompts/07-re-entrega-de-evidencia.md) |
| `D2` | Seguimiento de observaciones | [prompts/08-seguimiento-de-observaciones.md](prompts/08-seguimiento-de-observaciones.md) |
| `VF` | Consolidación final | [prompts/09-consolidacion-final.md](prompts/09-consolidacion-final.md) |

## Agentes de Copilot Studio

Once agentes independientes. No deben fusionarse: cada uno tiene una sola
responsabilidad, un solo conjunto de fuentes y un solo formato de salida, de modo
que cualquier hallazgo pueda rastrearse hasta el agente que lo produjo.

| Código | Agente | Archivo |
|---|---|---|
| `A1` | Generador de .md de entendimiento desde PDFs de manuales | [agents/A1-generador-de-md-de-entendimiento-desde-pdfs-de-manuales.md](agents/A1-generador-de-md-de-entendimiento-desde-pdfs-de-manuales.md) |
| `A2` | Conversor de herramienta Excel a .ipynb | [agents/A2-conversor-de-herramienta-excel-a-ipynb.md](agents/A2-conversor-de-herramienta-excel-a-ipynb.md) |
| `A3` | Evaluador técnico de controles de calidad de datos | [agents/A3-evaluador-tecnico-de-controles-de-calidad-de-datos.md](agents/A3-evaluador-tecnico-de-controles-de-calidad-de-datos.md) |
| `A4` | Entendimiento inicial (Paso 0) | [agents/A4-entendimiento-inicial-paso-0.md](agents/A4-entendimiento-inicial-paso-0.md) |
| `A5` | Control 1: Documentación | [agents/A5-control-1-documentacion.md](agents/A5-control-1-documentacion.md) |
| `A6` | Control 2: Calidad de Datos | [agents/A6-control-2-calidad-de-datos.md](agents/A6-control-2-calidad-de-datos.md) |
| `A7` | Control 3: Metodología | [agents/A7-control-3-metodologia.md](agents/A7-control-3-metodologia.md) |
| `A8` | Control 4: Implementación | [agents/A8-control-4-implementacion.md](agents/A8-control-4-implementacion.md) |
| `A9` | Control 5: Gobierno | [agents/A9-control-5-gobierno.md](agents/A9-control-5-gobierno.md) |
| `A10` | Control 6: Usos | [agents/A10-control-6-usos.md](agents/A10-control-6-usos.md) |
| `A11` | Validador final (consolidador) | [agents/A11-validador-final-consolidador.md](agents/A11-validador-final-consolidador.md) |

![Mapa de orquestación](docs/img/orquestacion.png)

## Notebook de controles de datos

Evalúa nueve dimensiones (completitud, unicidad, validez, consistencia,
exactitud, integridad referencial, oportunidad, estabilidad poblacional y
trazabilidad del linaje) y produce la matriz de siete columnas del Control 2,
con hashes SHA-256 de los insumos para la cadena de custodia.

```bash
cd notebook
pip install pandas numpy openpyxl
python controles_datos.py        # corre con datos sintéticos si no hay insumos
```

Para usarlo con datos reales, edita `CONFIG` al inicio y pon `usar_datos_demo` en
`False`. El notebook falla de forma explícita si falta un insumo obligatorio, en
lugar de producir un resultado silencioso.

## Vista web

`site/index.html` es una sola página sin dependencias: la ruta completa del
expediente a la izquierda y, al hacer clic en cada etapa, el prompt exacto con
botón de copiar y su fila de ejemplo. Se puede abrir localmente o publicar con
GitHub Pages (ver `.github/workflows/pages.yml`).

## Regenerar los documentos

```bash
./scripts/build.sh      # genera .docx y .pdf desde src/
```

Requiere `pandoc`, `xelatex`, `lmodern` y la fuente DejaVu Sans Mono. El PDF usa
la plantilla propia de `scripts/header.tex`.

## Licencia

MIT. Ver [LICENSE](LICENSE). La licencia cubre este material; no cubre los
estándares, políticas ni documentos internos de ninguna institución.
