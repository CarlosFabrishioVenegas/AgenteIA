#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT=build; mkdir -p "$OUT"

MONO="DejaVu Sans Mono"
COMUN=(--pdf-engine=xelatex --toc --toc-depth=2 -V documentclass=article
       -V monofont="$MONO" -V monofontoptions="Scale=0.80"
       -V colorlinks=true -V linkcolor=sello -V urlcolor=sello -V toccolor=tinta)

sed 's|\\DOCSHORT|Marco Operativo de Validacion Periodica — Estandar VIRF|' \
    scripts/header.tex > "$OUT/h_marco.tex"
sed 's|\\DOCSHORT|Guia de uso de prompts y agentes VIRF|' \
    scripts/header.tex > "$OUT/h_guia.tex"

pandoc src/marco-operativo.md -o "$OUT/marco-operativo.pdf" \
  "${COMUN[@]}" -V geometry:margin=1.9cm -V fontsize=10pt -H "$OUT/h_marco.tex"
pandoc src/guia-de-uso.md -o "$OUT/guia-de-uso.pdf" \
  "${COMUN[@]}" -V geometry:margin=2.2cm -V fontsize=11pt -H "$OUT/h_guia.tex"

pandoc src/marco-operativo.md -o "$OUT/marco-operativo.docx" --toc --toc-depth=2 --standalone
pandoc src/guia-de-uso.md     -o "$OUT/guia-de-uso.docx"     --toc --toc-depth=2 --standalone

python scripts/diagrama.py && mv orquestacion.png docs/img/orquestacion.png

echo "Generado en $OUT/"
