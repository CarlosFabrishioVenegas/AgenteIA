import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(10.5, 7.4))
ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis("off")
EDGE="#44546A"; TXT="#1F2A37"

def band(y, h, label, color):
    ax.add_patch(FancyBboxPatch((3, y), 94, h, boxstyle="round,pad=0.5,rounding_size=1.5",
                                fc=color, ec="#B4C6E7", lw=1.0))
    ax.text(3.5, y+h+1.2, label, fontsize=7.6, color="#6B7280", weight="bold")

def chip(x, y, w, h, txt, fc="white"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.0",
                                fc=fc, ec=EDGE, lw=1.1))
    ax.text(x+w/2, y+h/2, txt, ha="center", va="center", fontsize=8.2, color=TXT)

def down(x, y1, y2):
    ax.add_patch(FancyArrowPatch((x, y1), (x, y2), arrowstyle="-|>", mutation_scale=16,
                                 lw=1.6, color=EDGE))

ax.text(3, 96.5, "Mapa de orquestación — agentes de validación periódica VIRF",
        fontsize=12, weight="bold", color=TXT)

band(74, 13, "FASE 1 · PREPARACIÓN", "#DCE6F1")
chip(7, 76, 26, 9, "A1\nEntendimiento .md\ndesde PDFs")
chip(37, 76, 26, 9, "A2\nConversor\nExcel → .ipynb")
chip(67, 76, 26, 9, "A3\nEvaluador técnico\nde calidad de datos")

down(50, 73.0, 66.5)

band(54, 10.5, "FASE 2 · BASE COMÚN", "#FCE4D6")
chip(20, 55.5, 60, 8, "A4 — Entendimiento inicial (Paso 0)\ndocumento + infografía + mapa de evidencia")

down(50, 53.0, 44.5)

band(19, 22, "FASES 3–5 · CONTROLES", "#E2EFDA")
chip(6, 31, 20, 8, "A5\nDocumentación")
chip(29, 31, 20, 8, "A6\nCalidad de Datos")
chip(52, 31, 20, 8, "A7\nMetodología")
chip(75, 31, 18, 8, "A8\nImplementación")
chip(29, 21, 20, 7.5, "A9\nGobierno")
chip(52, 21, 20, 7.5, "A10\nUsos")

down(50, 18.5, 13.0)

band(3, 8, "FASE 6 · CONSOLIDACIÓN", "#FFF2CC")
chip(20, 4, 60, 6, "A11 — Validador final: tabla de 8 columnas + conclusión + plan de acción")

# Alimentaciones específicas
ax.add_patch(FancyArrowPatch((80, 76), (44, 39.5), arrowstyle="-|>", mutation_scale=12,
                             lw=1.2, color="#2F5597", connectionstyle="arc3,rad=-0.25"))
ax.text(17, 47.5, "A3 → A6\n(matriz de 7 columnas)", fontsize=7.2, color="#2F5597")

ax.add_patch(FancyArrowPatch((63, 80.5), (84, 39.5), arrowstyle="-|>", mutation_scale=12,
                             lw=1.2, color="#2F5597", connectionstyle="arc3,rad=-0.45"))
ax.text(87, 62, "A2 → A8\n(notebook +\nreconciliación)", fontsize=7.2, color="#2F5597")

# Devolución
ax.add_patch(FancyArrowPatch((22, 7), (6, 30), arrowstyle="-|>", mutation_scale=12,
                             lw=1.3, color="#C00000", linestyle=(0,(4,3)),
                             connectionstyle="arc3,rad=0.3"))
ax.text(2.0, 16.5, "devolución: matriz sin cita\no cobertura incompleta", fontsize=7.2, color="#C00000")

plt.savefig("orquestacion.png", dpi=185, bbox_inches="tight", facecolor="white")
print("ok")
