# 🔐 Guía Visual: Obtener credenciales Azure OpenAI en 5 minutos

## Paso 1: Abre Azure Portal
👉 Ve a: https://portal.azure.com/

---

## Paso 2: Busca tu recurso Azure OpenAI

### Opción A: Busca directa (MÁS RÁPIDO)
1. En la **barra de búsqueda** arriba, escribe: `openai`
2. Haz clic en el resultado **"Azure OpenAI"**

### Opción B: Por menú lateral
1. Panel izquierdo → "Todos los servicios"
2. Busca: "Azure OpenAI"
3. Haz clic en tu recurso

**Resultado:** Deberías ver una página como esta:

```
┌─────────────────────────────────────────┐
│ Tu Recurso Azure OpenAI                │
├─────────────────────────────────────────┤
│ virf-openai-prod (ejemplo)              │
│ Grupo de recursos: mi-grupo             │
│ Región: eastus                          │
└─────────────────────────────────────────┘
```

---

## Paso 3: Obtener la API Key y Endpoint

### Ubicación en Azure Portal:

```
Tu Recurso Azure OpenAI
│
├── 🔑 Keys and Endpoint (Panel izquierdo)
│   │
│   ├── Key 1: sk-... (COPIAR ESTO)
│   │
│   ├── Key 2: sk-... (alternativa)
│   │
│   └── Endpoint: https://tu-recurso.openai.azure.com/ (COPIAR ESTO)
```

### Copia exactamente:

1. **API Key:**
   - Localiza: **"Key 1"** (la primera clave)
   - Icono pequeño de "copiar" a la derecha
   - Haz clic → se copia al portapapeles
   
   **Resultado:** Un string como `DO8_abc123def456ghi789jkl...`

2. **Endpoint:**
   - Localiza: **"Endpoint"** (debajo de las keys)
   - Icono pequeño de "copiar" a la derecha
   - Haz clic → se copia al portapapeles
   
   **Resultado:** Una URL como `https://virf-openai-prod.openai.azure.com/`

---

## Paso 4: Obtener el nombre del Deployment

### Ubicación en Azure Portal:

```
Tu Recurso Azure OpenAI
│
├── 🚀 Model deployments (Panel izquierdo)
│   │
│   ├── gpt-4-turbo-deployment
│   ├── gpt-35-turbo-deployment
│   └── claude-sonnet-deployment (si tienes Anthropic en Azure)
```

### Copia exactamente:

1. Panel izquierdo → **"Model deployments"** (o "Deployments")
2. Busca tu deployment activo
3. **Copia el nombre exacto**
   
   **Resultado:** Un string como `gpt-4-turbo-deployment`

### ⚠️ Atención a mayúsculas/minúsculas:
- `gpt-4-turbo` ✅ CORRECTO
- `GPT-4-TURBO` ❌ INCORRECTO (típico error)

---

## Paso 5: Completar .env

Abre tu archivo `.env` con un editor de texto:

```powershell
# Windows
notepad .env

# macOS/Linux
nano .env
```

Busca estas líneas y reemplaza los placeholders:

```bash
# LÍNEA 1: Asegúrate de que está configurada en Azure
IA_PROVEEDOR=azure_openai

# LÍNEA 2: Pega tu API Key (copiada en Paso 3.1)
AZURE_OPENAI_API_KEY=DO8_abc123def456ghi789jkl...

# LÍNEA 3: Pega tu Endpoint (copiado en Paso 3.2)
# ⚠️  IMPORTANTE: Debe terminar con /
AZURE_OPENAI_ENDPOINT=https://virf-openai-prod.openai.azure.com/

# LÍNEA 4: Pega tu Deployment Name (copiado en Paso 4)
AZURE_OPENAI_DEPLOYMENT=gpt-4-turbo-deployment
```

### Ejemplo completo (ANTES):
```bash
AZURE_OPENAI_API_KEY=DO8_REEMPLAZA_CON_TU_API_KEY_REAL
AZURE_OPENAI_ENDPOINT=https://REEMPLAZA_CON_TU_RECURSO.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=REEMPLAZA_CON_TU_DEPLOYMENT
```

### Ejemplo completo (DESPUÉS):
```bash
AZURE_OPENAI_API_KEY=DO8_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0
AZURE_OPENAI_ENDPOINT=https://virf-openai-prod.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4-turbo-deployment
```

✅ **Guarda el archivo** (Ctrl+S o Cmd+S)

---

## Paso 6: Valida tu configuración

Abre PowerShell en la carpeta del proyecto:

```powershell
python test_azure_config.py
```

### ✅ Salida esperada (ÉXITO):

```
══════════════════════════════════════════════════════════════════════
🔵 VALIDADOR AZURE OPENAI - VIRF Agent v23
══════════════════════════════════════════════════════════════════════

1. Verificando archivo .env
------
✅ .env encontrado
✅ .env cargado correctamente

2. Verificando IA_PROVEEDOR
------
✅ IA_PROVEEDOR = azure_openai

3. Verificando credenciales Azure OpenAI
------
✅ AZURE_OPENAI_API_KEY configurada: DO8_...t0
✅ AZURE_OPENAI_ENDPOINT: https://virf-openai-prod.openai.azure.com/
✅ AZURE_OPENAI_DEPLOYMENT: gpt-4-turbo-deployment
✅ AZURE_OPENAI_API_VERSION: 2024-02-15-preview

4. Probando conexión a Azure OpenAI
------
✅ Conexión exitosa a Azure OpenAI ✓

══════════════════════════════════════════════════════════════════════
RESUMEN
══════════════════════════════════════════════════════════════════════

✅ Todas las validaciones pasaron

Puedes usar Azure OpenAI. Ejecuta:

  python agente.py --titulo 'Test' --tier 1

══════════════════════════════════════════════════════════════════════
```

### ❌ Si hay errores:

Lee las líneas que dicen `❌` y ajusta en `.env`:
- API Key mal copiada → Vuelve a Azure Portal, Paso 3.1
- Endpoint sin `/` al final → Agrega el `/` manualmente
- Deployment incorrecto → Verifica en Azure Portal, Paso 4

---

## 🚀 Una vez validado, ejecuta:

```powershell
# Test rápido (5 min):
python agente.py --titulo "Test Azure OpenAI" --tier 1

# O producción completa (20-40 min):
python agente.py --titulo "Modelo LaR" --tier 1 --prdc
```

---

## Pantallazos de referencia (Azure Portal)

### Ubicación: Keys and Endpoint

```
┌──────────────────────────────────────────────────────┐
│ Keys and Endpoint                                    │
├──────────────────────────────────────────────────────┤
│                                                      │
│ Key 1: DO8_abc123def456ghi789...    [copy icon]     │
│ Key 2: sk-...                       [copy icon]     │
│                                                      │
│ Endpoint: https://virf-openai...    [copy icon]     │
│                                                      │
└──────────────────────────────────────────────────────┘
```

### Ubicación: Model deployments

```
┌──────────────────────────────────────────────────────┐
│ Model deployments                                    │
├──────────────────────────────────────────────────────┤
│                                                      │
│ ✅ gpt-4-turbo-deployment                           │
│    Model: gpt-4-turbo                               │
│    Version: 2024-04-09                              │
│    Status: Succeeded                                │
│                                                      │
│ ✅ gpt-35-turbo-deployment                          │
│    Model: gpt-35-turbo                              │
│    ...                                              │
│                                                      │
└──────────────────────────────────────────────────────┘
```

---

## Si algo falla

**Problema:** No puedo encontrar Azure OpenAI en Azure Portal

**Solución:**
1. Verifica que tengas una **suscripción de Azure activa**
2. Comprueba que tengas **permisos de Contributor** o superior
3. Contacta a tu administrador de Azure si no puedes crear recursos

---

**⏱️ Tiempo total:** 5 minutos

**✅ Una vez listo:** Tu VIRF Agent puede usar Azure OpenAI
