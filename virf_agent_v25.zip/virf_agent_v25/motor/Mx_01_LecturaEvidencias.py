import logging
logger = logging.getLogger("virf.mx01")
"""
Mx_01_LecturaEvidencias.py
===========================
Lectura y extracción de texto de todas las fuentes de evidencia:
  - PDF, DOCX, PPTX, XLSX, PY, JSON, TXT, MD, IPYNB, SQL
  - Compilación por carpeta de control
  - Compilación por modelo (conocimiento)
  - Detección automática de manual vs script por scoring

Responsabilidades:
  - Leer archivos individuales por tipo
  - Leer carpetas recursivamente (evidencia, conocimiento)
  - Detectar el "mejor" manual y script por scoring de nombres
  - Compilar evidencia por control y por modelo
  - Crear CSV de parámetros de ejecución
"""

import csv
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, Dict, Any

from Mx_00_CargaRutas import (
    MAX_CHARS_DOC, MAX_CHARS_CODIGO, MAX_FILAS_EXCEL,
    AMBITO_A_INPUTS, RUTAS,
    CACHE_ENABLED, CACHE_DIR,
)

# ─── Sistema de caché de documentos (v15/v17) ─────────────────────────────────
# CRÍTICO: importamos desde 'modulos.document_cache' (no desde 'document_cache')
# para que tanto agente.py como Mx_01 compartan el MISMO objeto de módulo en
# sys.modules y por tanto la misma _instancia_global del caché.
import sys as _sys
_base_path = str(Path(__file__).parent.parent)   # → virf_mejorado/
if _base_path not in _sys.path:
    _sys.path.insert(0, _base_path)

try:
    from modulos.document_cache import get_cache, DocumentCache   # clave: 'modulos.document_cache'
    _CACHE_DISPONIBLE = True
except ImportError:
    _CACHE_DISPONIBLE = False
    def get_cache():   # noqa: E302
        return None

# Constantes de carpetas
EVIDENCIA_FOLDER = "Evidencias"
CONOCIMIENTO_FOLDER = "Conocimiento"


# ─── Lectores por tipo de archivo ─────────────────────────────────────────────

def _leer_pdf(path: Path) -> str:
    """
    Lee texto de un PDF. [FIX-OCR] Añade fallback a pytesseract para PDFs escaneados.
    Reporta si el PDF fue escaneado para que la cobertura refleje la limitación.
    """
    texto = ""

    # Intento 1: pdfminer (PDFs digitales)
    try:
        from pdfminer.high_level import extract_text
        texto = extract_text(str(path)) or ""
    except ImportError:
        pass
    except Exception:
        pass

    # Intento 2: PyPDF2 (fallback digital)
    if not texto.strip():
        try:
            import PyPDF2
            parts = []
            with open(path, "rb") as f:
                for page in PyPDF2.PdfReader(f).pages:
                    t = page.extract_text()
                    if t:
                        parts.append(t)
            texto = "\n".join(parts)
        except ImportError:
            pass
        except Exception:
            pass

    # Intento 3: [FIX-OCR] pytesseract para PDFs escaneados
    if not texto.strip():
        try:
            import pytesseract
            from pdf2image import convert_from_path
            pages = convert_from_path(str(path), dpi=200, first_page=1, last_page=5)
            partes_ocr = []
            for i, img in enumerate(pages, 1):
                t = pytesseract.image_to_string(img, lang="spa+eng")
                if t.strip():
                    partes_ocr.append(f"[Página {i} — OCR]\n{t}")
            if partes_ocr:
                texto = "\n".join(partes_ocr)
                texto = f"[⚠️  PDF ESCANEADO — texto extraído vía OCR, puede contener errores]\n\n" + texto
        except ImportError:
            texto = (
                f"[⚠️  PDF ESCANEADO: {path.name}. No se pudo extraer texto. "
                "Instalar pdf2image y pytesseract para habilitar OCR. "
                "Este ámbito puede tener cobertura 0% por este archivo.]"
            )
        except Exception as e:
            texto = f"[Error OCR en {path.name}: {str(e)[:100]}]"

    if not texto.strip():
        return f"[PDF no legible — sin texto extraíble: {path.name}]"

    return texto


def _leer_docx(path: Path) -> str:
    try:
        from docx import Document
        doc = Document(path)
        partes = []
        
        # Leer párrafos (más simple y robusto)
        for p in doc.paragraphs:
            if p.text.strip():
                partes.append(p.text.strip())
        
        # Leer tablas
        for table in doc.tables:
            for row in table.rows:
                celdas = [c.text.strip() for c in row.cells if c.text.strip()]
                if celdas:
                    partes.append(" | ".join(celdas))
        
        if not partes:
            return f"[Documento vacío o sin texto legible: {path.name}]"
        
        return "\n".join(partes)
    except Exception as e:
        return f"[Error leyendo {path.name}: {str(e)[:100]}]"


def _leer_pptx(path: Path) -> str:
    try:
        from pptx import Presentation
        partes = []
        for i, slide in enumerate(Presentation(path).slides, 1):
            txts = [
                s.text.strip()
                for s in slide.shapes
                if hasattr(s, "text") and s.text.strip()
            ]
            if txts:
                partes.append(f"[Slide {i}] " + " | ".join(txts))
        return "\n".join(partes)
    except Exception as e:
        return f"[Error PPTX {path.name}: {e}]"


def _leer_excel(path: Path, max_filas: int = 150) -> str:
    try:
        import pandas as pd
        xf = pd.ExcelFile(path)
        partes = []
        for nombre in xf.sheet_names:
            df = xf.parse(nombre).dropna(how="all").fillna("")
            csv = df.head(max_filas).to_csv(index=False)
            partes.append(f"--- Hoja: {nombre} ---\n{csv}")
        return "\n".join(partes)
    except Exception as e:
        return f"[Error Excel {path.name}: {e}]"


def _leer_python(path: Path, max_chars: int = 8000) -> str:
    try:
        code = path.read_text(encoding="utf-8", errors="replace")
        if len(code) > max_chars:
            code = code[:max_chars] + f"\n... [truncado a {max_chars} chars]"
        return code
    except Exception as e:
        return f"[Error .py {path.name}: {e}]"


def _leer_json(path: Path) -> str:
    try:
        return json.dumps(
            json.loads(path.read_text(encoding="utf-8")),
            ensure_ascii=False, indent=2
        )[:5000]
    except Exception as e:
        return f"[Error JSON {path.name}: {e}]"


LECTORES_EXT = {
    ".pdf":  lambda p: _leer_pdf(p),
    ".docx": lambda p: _leer_docx(p),
    ".doc":  lambda p: _leer_docx(p),
    ".pptx": lambda p: _leer_pptx(p),
    ".ppt":  lambda p: _leer_pptx(p),
    ".xlsx": lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".xls":  lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".xlsm": lambda p: _leer_excel(p, MAX_FILAS_EXCEL),
    ".py":   lambda p: _leer_python(p, MAX_CHARS_CODIGO),
    ".json": lambda p: _leer_json(p),
    # [v18] TXT/MD/CSV: sin límite artificial — se aplica chunking si son largos
    ".txt":  lambda p: p.read_text(encoding="utf-8", errors="replace"),
    ".md":   lambda p: p.read_text(encoding="utf-8", errors="replace"),
    ".csv":  lambda p: p.read_text(encoding="utf-8", errors="replace"),
}

# ─── [v18] Constantes de chunking — configurables por variable de entorno ─────
# VIRF_CHUNK_SIZE      → chars por segmento (default: 12.000 ≈ 12 páginas densas)
# VIRF_CHUNK_OVERLAP   → solapamiento entre segmentos para no cortar ideas en el borde
# VIRF_CHUNK_THRESHOLD → documentos más cortos que esto no se chunkean (ruta directa)
import os as _os
_CHUNK_SIZE      = int(_os.getenv("VIRF_CHUNK_SIZE",      "12000"))
_CHUNK_OVERLAP   = int(_os.getenv("VIRF_CHUNK_OVERLAP",     "800"))
_CHUNK_THRESHOLD = int(_os.getenv("VIRF_CHUNK_THRESHOLD", str(_CHUNK_SIZE)))


# [v20] _chunked_summary fue movida a modulos/chunker.py (ChunkerService).
# Mx_01 ya no llama a la IA — devuelve texto crudo para que el pipeline
# aplique chunking de forma centralizada y controlada.


def leer_archivo(path: Path) -> Optional[dict]:
    """
    Lee un archivo y retorna dict con el texto extraído SIN chunking.

    [v20] Esta función es ahora agnóstica a IA: devuelve el texto crudo
    truncado a max_chars (MAX_CHARS_DOC / MAX_CHARS_CODIGO) para documentos
    dentro del umbral, o el texto completo para que ChunkerService (en
    modulos/chunker.py) lo procese externamente.

    El chunking ya NO ocurre aquí — ocurre en agente.py después de leer
    todos los archivos, usando un ChunkerService con el cliente IA inyectado.

    Campos del dict retornado:
      nombre        (str):   nombre del archivo
      tipo          (str):   extensión en mayúsculas (PDF, DOCX, PY…)
      contenido     (str):   texto extraído (puede ser truncado si > max_chars)
      chars_totales (int):   longitud total del texto antes de truncar
      truncado      (bool):  True si chars_totales > max_chars (candidato a chunking)
      cobertura_pct (float): 100.0 si no truncado; <100 si truncado
      fue_resumido  (bool):  siempre False aquí; ChunkerService lo pone en True
      n_chunks      (int):   1 siempre aquí; ChunkerService lo actualiza
      fue_truncado_fc (bool): siempre False aquí
    """
    ext = path.suffix.lower()
    lector = LECTORES_EXT.get(ext)
    if not lector:
        return None

    max_c = MAX_CHARS_CODIGO if ext == ".py" else MAX_CHARS_DOC

    # ── Intentar servir del caché ──────────────────────────────────────────
    cache = get_cache() if _CACHE_DISPONIBLE else None
    if cache is not None and cache.enabled:
        cached = cache.get(
            path=path,
            extractor_fn=lector,
            max_chars=max_c,
        )
        if cached is not None:
            # Asegurar campos de cobertura por consistencia
            cached.setdefault("cobertura_pct",   100.0 if not cached.get("truncado") else
                              round(max_c / cached["chars_totales"] * 100, 1))
            cached.setdefault("fue_resumido",    False)
            cached.setdefault("n_chunks",        1)
            cached.setdefault("fue_truncado_fc", False)
            return cached

    # ── Lectura directa ────────────────────────────────────────────────────
    try:
        contenido = lector(path) or ""
    except Exception as exc:
        logger.error("❌ Error leyendo %s: %s", path.name, exc)
        return None

    chars_totales = len(contenido)
    contenido_truncado = contenido[:max_c]
    truncado = chars_totales > max_c

    doc = {
        "nombre":        path.name,
        "tipo":          ext.lstrip(".").upper(),
        "contenido":     contenido_truncado,
        "chars_totales": chars_totales,
        "truncado":      truncado,
        "cobertura_pct": 100.0 if not truncado else round(max_c / chars_totales * 100, 1),
        "fue_resumido":  False,
        "n_chunks":      1,
        "fue_truncado_fc": False,
    }

    # Guardar en caché (el texto crudo, antes del chunking)
    if cache is not None and cache.enabled:
        cache._guardar_entrada(str(path.resolve()),
                               DocumentCache._hash_archivo(path) or "", path, doc)

    return doc


def leer_carpeta(carpeta: Path) -> list:
    """Lee todos los archivos soportados de una carpeta (recursivo). Retorna lista de dicts."""
    if not carpeta.exists():
        return []
    archivos = []
    # BUG FIX: usar rglob en lugar de iterdir para leer subdirectorios
    # (ej: inputs/documentacion/modelamiento/ y inputs/documentacion/seguimiento/)
    for path in sorted(carpeta.rglob("*")):
        if path.is_file():
            doc = leer_archivo(path)
            if doc:
                archivos.append(doc)
    return archivos


def leer_repositorio_informes(carpeta: Path) -> str:
    """Consolida el texto de todos los informes de referencia para aprendizaje de estilo."""
    docs = leer_carpeta(carpeta)
    if not docs:
        return ""
    return "\n".join(
        f"=== INFORME: {d['nombre']} ===\n{d['contenido']}\n"
        for d in docs
    )


def cargar_todos_inputs() -> dict:
    """
    Carga todos los inputs definidos en RUTAS['inputs'].
    Retorna dict {nombre_seccion: [lista_de_docs]}.
    """
    resultado = {}
    for nombre, ruta in RUTAS["inputs"].items():
        resultado[nombre] = leer_carpeta(Path(ruta))
    return resultado


def inputs_para_dimension(docs: dict, dimension: str) -> list:
    """
    Filtra y une los documentos relevantes para una dimensión específica.
    Ordena por prioridad: manuales → scripts seguimiento → scripts modelador → excels → otros.
    """
    secciones = AMBITO_A_INPUTS.get(dimension, list(docs.keys()))
    todos = []
    for sec in secciones:
        todos.extend(docs.get(sec, []))

    manuales    = [d for d in todos if d["tipo"] in ("PDF", "DOCX", "DOC")]
    scripts_seg = [d for d in todos if d["tipo"] == "PY" and
                   any(k in d["nombre"].lower() for k in
                       ("seguimiento", "backtest", "kupiec", "christoff", "replica_virf", "monitor"))]
    scripts_mod = [d for d in todos if d["tipo"] == "PY" and d not in scripts_seg]
    excels      = [d for d in todos if d["tipo"] in ("XLSX", "XLS", "XLSM", "CSV")]
    otros       = [d for d in todos if d not in manuales + scripts_seg + scripts_mod + excels]

    return manuales + scripts_seg + scripts_mod + excels + otros


def leer_estandares_virf(tier: str) -> Optional[dict]:
    """
    Lee Estandares_VIRF.xlsx y retorna actividades filtradas por Tier.

    Retorna:
    {
      "Documentación": [
        {
          "control": "...",
          "tipo_ctrl": "Cuantitativo|Cualitativo",
          "actividad": "...",
          "requerida": True,
          "concepto_existente": "..." | None,
          "validaciones_previas": [{"col": "...", "valor": "..."}, ...]
        },
        ...
      ],
      ...
    }
    """
    path = RUTAS["estandares_virf"]
    if not Path(path).exists():
        return None

    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        _TIER_MAP = {"1": "I", "2": "II", "3": "III", "4": "IV",
                     "I": "I", "II": "II", "III": "III", "IV": "IV"}
        tier_norm = _TIER_MAP.get(tier.upper(), tier.upper())
        tier_col = f"TIER_{tier_norm}"
        resultado = {}

        for nombre_hoja in wb.sheetnames:
            if any(k in nombre_hoja.lower() for k in ("instruc", "resumen", "readme", "leeme")):
                continue

            ws = wb[nombre_hoja]
            filas = [list(row) for row in ws.iter_rows(values_only=True)]
            if not filas:
                continue

            # Normalizar longitud de filas
            n_cols = max(len(f) for f in filas)
            for f in filas:
                while len(f) < n_cols:
                    f.append(None)

            # Forward-fill ÁMBITO (col 0) y CONTROL (col 1) para celdas fusionadas
            for col_idx in (0, 1):
                last = None
                for fila in filas:
                    v = fila[col_idx]
                    if v is not None and str(v).strip() not in ("", "None", "nan"):
                        last = str(v).strip()
                    else:
                        fila[col_idx] = last

            # Detectar fila cabecera
            cab_idx = 0
            palabras_hdr = {"ámbito", "ambito", "control", "actividad", "tier", "requiere"}
            for i, fila in enumerate(filas):
                vals_lower = {str(v).lower().strip() for v in fila if v}
                if vals_lower & palabras_hdr:
                    cab_idx = i
                    break

            hdr_row = [str(v).lower().strip() if v else "" for v in filas[cab_idx]]
            datos   = filas[cab_idx + 1:]

            def _col(*claves):
                for i, h in enumerate(hdr_row):
                    if any(k in h for k in claves):
                        return i
                return None

            # BUG FIX: 'or N' es falsy cuando _col() retorna 0 (columna 0 encontrada)
            # Usar is None explícito para distinguir "no encontrado" de "columna 0"
            col_ambito = _col("ámbito", "ambito", "dimension", "dimensión")
            col_ctrl   = _col("control", "ctrl")
            col_act    = _col("actividad", "activity", "tarea")
            if col_ambito is None: col_ambito = 0
            if col_ctrl   is None: col_ctrl   = 1
            if col_act    is None: col_act    = 2

            # Columna del TIER
            tier_key = tier_col.lower()
            col_tier = None
            for i, h in enumerate(hdr_row):
                h_clean = h.replace(" ", "_").replace("-", "_")
                if h_clean == tier_key or h == tier_key:
                    col_tier = i
                    break
            if col_tier is None:
                tier_num = tier.upper()
                for i, h in enumerate(hdr_row):
                    if "tier" in h and tier_num in h.upper():
                        col_tier = i
                        break

            # Columna Concepto
            col_concepto = _col("concepto")

            # Columnas historial VALIDACIÓN_*
            cols_validacion = []
            for i, h in enumerate(hdr_row):
                if (re.match(r"validaci[oó]n[_\s]\d{8}.*", h, re.IGNORECASE) or
                        "validación" in h or "validacion" in h):
                    cols_validacion.append((i, filas[cab_idx][i]))

            # Forward-fill col_ctrl en datos (celdas fusionadas de CONTROL en Excel)
            last_ctrl = None
            for fila in datos:
                if len(fila) > col_ctrl:
                    v = fila[col_ctrl]
                    if v is not None and str(v).strip() not in ("", "None", "nan"):
                        last_ctrl = str(v).strip()
                    else:
                        fila[col_ctrl] = last_ctrl

            # Parsear datos
            for fila in datos:
                ambito  = str(fila[col_ambito]).strip() if fila[col_ambito] else ""
                control = str(fila[col_ctrl]).strip()   if fila[col_ctrl]   else ""
                activ   = str(fila[col_act]).strip()    if len(fila) > col_act and fila[col_act] else ""

                if not activ or activ.lower() in ("actividad", "activity", "nan", "none", ""):
                    continue
                if not ambito or ambito.lower() in ("nan", "none", ""):
                    continue

                # Requerida por Tier
                if col_tier is not None and len(fila) > col_tier:
                    tier_val  = str(fila[col_tier]).strip().upper()
                    requerida = tier_val in ("X", "SI", "YES", "1", "TRUE", "✓", "✔", "V")
                else:
                    requerida = True

                # Concepto existente
                concepto_prev = None
                if col_concepto is not None and len(fila) > col_concepto:
                    v = fila[col_concepto]
                    if v and str(v).strip() not in ("", "None", "nan"):
                        concepto_prev = str(v).strip()

                # Historial de validaciones previas
                validaciones_previas = []
                for col_idx_v, col_nombre_v in cols_validacion:
                    if len(fila) > col_idx_v:
                        v = fila[col_idx_v]
                        if v and str(v).strip() not in ("", "None", "nan"):
                            validaciones_previas.append({
                                "col":   str(col_nombre_v) if col_nombre_v else f"Col{col_idx_v}",
                                "valor": str(v).strip(),
                            })

                # Tipo de control
                tipo_ctrl = "Cualitativo"
                ctrl_l = control.lower()
                if any(k in ctrl_l for k in ("cuantit", "quantit", "medic", "métric", "metric",
                                              "modelador", "backtesting", "seguim")):
                    tipo_ctrl = "Cuantitativo"

                resultado.setdefault(ambito, []).append({
                    "control":              control,
                    "tipo_ctrl":            tipo_ctrl,
                    "actividad":            activ,
                    "requerida":            requerida,
                    "concepto_existente":   concepto_prev,
                    "validaciones_previas": validaciones_previas,
                })

        return resultado if resultado else None

    except Exception as e:
        print(f"    [!] Error leyendo Estandares_VIRF: {e}")
        return None


# ─── NUEVAS FUNCIONES PARA PIPELINE POR CONTROL ─────────────────────────────


def leer_txt_csv_log(ruta: str) -> str:
    """Lee .txt, .csv, .log y retorna el contenido como string."""
    try:
        path = Path(ruta)
        if not path.exists():
            return ""
        return path.read_text(encoding="utf-8", errors="replace")[:MAX_CHARS_DOC]
    except Exception as e:
        return f"[Error leyendo {ruta}: {e}]"


def leer_sql(ruta: str) -> str:
    """Lee archivo .sql y retorna el contenido."""
    try:
        path = Path(ruta)
        if not path.exists():
            return ""
        return path.read_text(encoding="utf-8", errors="replace")[:MAX_CHARS_CODIGO]
    except Exception as e:
        return f"[Error leyendo SQL {ruta}: {e}]"


def leer_ipynb(ruta: str) -> str:
    """Lee notebook Jupyter y extrae código + markdown como texto."""
    try:
        path = Path(ruta)
        if not path.exists():
            return ""
        nb = json.loads(path.read_text(encoding="utf-8"))
        partes = []
        for cell in nb.get("cells", []):
            cell_type = cell.get("cell_type", "")
            source = "".join(cell.get("source", []))
            if cell_type == "code":
                partes.append(f"[CODE CELL]\n{source}")
            elif cell_type == "markdown":
                partes.append(f"[MD CELL]\n{source}")
        return "\n".join(partes)[:MAX_CHARS_CODIGO]
    except Exception as e:
        return f"[Error IPYNB {ruta}: {e}]"


def leer_archivo_generico(ruta: str) -> str:
    """Dispatcher: selecciona lector según extensión."""
    path = Path(ruta)
    ext = path.suffix.lower()
    
    if ext == ".pdf":
        return _leer_pdf(path)
    elif ext in (".docx", ".doc"):
        return _leer_docx(path)
    elif ext in (".pptx", ".ppt"):
        return _leer_pptx(path)
    elif ext in (".xlsx", ".xls", ".xlsm"):
        return _leer_excel(path, MAX_FILAS_EXCEL)
    elif ext == ".py":
        return _leer_python(path, MAX_CHARS_CODIGO)
    elif ext == ".json":
        return _leer_json(path)
    elif ext == ".ipynb":
        return leer_ipynb(ruta)
    elif ext == ".sql":
        return leer_sql(ruta)
    elif ext in (".txt", ".csv", ".log"):
        return leer_txt_csv_log(ruta)
    elif ext == ".md":
        return path.read_text(encoding="utf-8", errors="replace")[:MAX_CHARS_DOC]
    else:
        return ""


def compilar_textos_de_carpeta(base_path: str, subfolder: str, max_chars: int = 14000) -> str:
    """
    Recorre recursivo una carpeta, concatena contenido de archivos soportados.
    Trunca a max_chars total.
    
    Parámetros:
        base_path: ruta base del proyecto
        subfolder: subcarpeta relativa dentro de base_path
        max_chars: máximo de caracteres total a retornar
    
    Retorna:
        String concatenado con encabezados por ruta relativa
    """
    base = Path(base_path) / subfolder
    if not base.exists():
        return ""
    
    partes = []
    total_chars = 0
    
    for archivo in sorted(base.rglob("*")):
        if archivo.is_file():
            contenido = leer_archivo_generico(str(archivo))
            if contenido:
                rel_path = archivo.relative_to(base)
                encabezado = f"\n=== {rel_path} ===\n"
                full_content = encabezado + contenido
                
                if total_chars + len(full_content) > max_chars:
                    # Truncar el último bloque si excede
                    remaining = max_chars - total_chars
                    if remaining > len(encabezado):
                        partes.append(full_content[:remaining])
                    break
                
                partes.append(full_content)
                total_chars += len(full_content)
    
    return "".join(partes)


def obtener_evidencia_por_control(base_project_path: str, ctrl_id: str, max_chars: int = 14000) -> str:
    """
    Lee evidencia dentro de EVIDENCIA_FOLDER/ctrl_id/ y concatena.
    
    Parámetros:
        base_project_path: ruta raíz del proyecto
        ctrl_id: ID del control (ej: "CTRL_001")
        max_chars: trunca a este límite
    
    Retorna:
        String con evidencia compilada del control
    """
    subfolder = f"{EVIDENCIA_FOLDER}/{ctrl_id}"
    return compilar_textos_de_carpeta(base_project_path, subfolder, max_chars)


def obtener_conocimiento_por_modelo(base_project_path: str, nombre_modelo: str, max_chars: int = 9000) -> str:
    """
    Compila contenido en Conocimiento/<NombreModelo>/* para contexto.
    
    Parámetros:
        base_project_path: ruta raíz del proyecto
        nombre_modelo: nombre del modelo (se usa como carpeta)
        max_chars: trunca a este límite
    
    Retorna:
        String con conocimiento del modelo compilado
    """
    subfolder = f"{CONOCIMIENTO_FOLDER}/{nombre_modelo}"
    return compilar_textos_de_carpeta(base_project_path, subfolder, max_chars)


def _score_manual(name: str) -> int:
    """
    Calcula score para detectar si es "manual" (documentación).
    Keywords: manual, guia, guide, metodologia, manual, doc, README, etc.
    """
    name_lower = name.lower()
    score = 0
    
    # Extensión
    if name_lower.endswith((".pdf", ".docx", ".doc", ".txt", ".md")):
        score += 10
    
    # Keywords
    keywords = ["manual", "guia", "guide", "metodolog", "documentation", 
                "readme", "documento", "especificación", "spec"]
    for kw in keywords:
        if kw in name_lower:
            score += 15
    
    # Evitar que sea script
    if any(k in name_lower for k in ["etl", "pipeline", "script", "prog", ".py", ".sql"]):
        score -= 20
    
    return max(0, score)


def _score_script(name: str) -> int:
    """
    Calcula score para detectar si es "script" (código de proceso).
    Keywords: etl, pipeline, prog, proceso, transformacion, etc.
    """
    name_lower = name.lower()
    score = 0
    
    # Extensión
    if name_lower.endswith((".py", ".sql", ".r", ".ipynb", ".scala")):
        score += 15
    
    # Keywords
    keywords = ["etl", "pipeline", "process", "transformacion", "transform",
                "prog", "codigo", "code", "script", "query", "procedure"]
    for kw in keywords:
        if kw in name_lower:
            score += 15
    
    # Evitar que sea manual
    if any(k in name_lower for k in ["manual", "guia", "guide", "metodolog", 
                                       "documentation", "readme", ".pdf", ".docx"]):
        score -= 20
    
    return max(0, score)


def detectar_manual_y_script(carpeta_control: str) -> Tuple[Optional[str], str, Optional[str], str]:
    """
    Encuentra el "mejor" manual y script por scoring de nombres.
    
    Parámetros:
        carpeta_control: ruta a la carpeta del control
    
    Retorna:
        (ruta_manual, texto_manual, ruta_script, texto_script)
        Si no encuentra, retorna None en la ruta y "" en el texto.
    """
    base = Path(carpeta_control)
    if not base.exists():
        return None, "", None, ""
    
    archivos = [(f, f.name) for f in sorted(base.rglob("*")) if f.is_file()]
    
    # Detectar mejor manual
    manuals = [(f, _score_manual(n)) for f, n in archivos if _score_manual(n) > 0]
    best_manual = max(manuals, key=lambda x: x[1]) if manuals else (None, 0)
    ruta_manual = str(best_manual[0]) if best_manual[0] else None
    texto_manual = leer_archivo_generico(ruta_manual) if ruta_manual else ""
    
    # Detectar mejor script
    scripts = [(f, _score_script(n)) for f, n in archivos if _score_script(n) > 0]
    best_script = max(scripts, key=lambda x: x[1]) if scripts else (None, 0)
    ruta_script = str(best_script[0]) if best_script[0] else None
    texto_script = leer_archivo_generico(ruta_script) if ruta_script else ""
    
    return ruta_manual, texto_manual, ruta_script, texto_script


def guardar_parametros_ejecucion(
    outputs_dir: str,
    nombre_modelo: str,
    fecha_informe: str,
    tier: str,
    ruta_excel_controles: str,
) -> Path:
    """
    Crea un CSV _params_<modelo>_<fecha>.csv con parámetros de ejecución.
    
    Retorna:
        Path al archivo CSV creado
    """
    timestamp = datetime.utcnow().isoformat() + "Z"
    filename = f"_params_{nombre_modelo}_{fecha_informe}.csv"
    filepath = Path(outputs_dir) / filename
    
    rows = [
        {
            "fecha_informe": fecha_informe,
            "tier": tier,
            "nombre_modelo": nombre_modelo,
            "ruta_excel": ruta_excel_controles,
            "ruta_output": str(filepath.parent),
            "timestamp_ejecucion_utc": timestamp,
        }
    ]
    
    try:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
    except Exception as e:
        print(f"[!] Error guardando parámetros: {e}")
    
    return filepath
