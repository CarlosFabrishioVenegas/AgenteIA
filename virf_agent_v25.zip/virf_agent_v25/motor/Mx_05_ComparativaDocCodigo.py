"""
Mx_05_ComparativaDocCodigo.py
════════════════════════════════════════════════════════════════════════════════

Análisis de coherencia entre documentos y código fuente.
Usado principalmente en el ámbito "Implementación" para validar que lo documentado
se corresponde con lo implementado.
"""

from pathlib import Path
import re
from typing import Dict, List, Tuple

# ─── FUNCIONES DE EXTRACCIÓN ────────────────────────────────────────────────────

def extraer_funciones_python(contenido: str) -> List[str]:
    """Extrae nombres de funciones de un script Python."""
    return re.findall(r"def\s+(\w+)\s*\(", contenido)


def extraer_clases_python(contenido: str) -> List[str]:
    """Extrae nombres de clases de un script Python."""
    return re.findall(r"class\s+(\w+)[\(\:]", contenido)


def extraer_variables_globales(contenido: str) -> List[str]:
    """Extrae nombres de variables globales/constantes."""
    return re.findall(r"^([A-Z_][A-Z0-9_]*)\s*=", contenido, re.MULTILINE)


def extraer_imports(contenido: str) -> List[str]:
    """Extrae librerías importadas."""
    libs = re.findall(r"(?:from|import)\s+([\w\.]+)", contenido)
    return list(set(libs))


def extraer_seccion_docstring(contenido: str, func_name: str) -> str:
    """Extrae el docstring de una función específica."""
    pattern = rf"def\s+{func_name}\s*\(.*?\):\s+\"\"\"(.*?)\"\"\"" 
    match = re.search(pattern, contenido, re.DOTALL)
    return match.group(1).strip() if match else ""


def extraer_palabras_clave_doc(texto: str) -> List[str]:
    """Extrae palabras clave técnicas de un documento."""
    # Buscar términos técnicos comunes en modelos financieros
    terminos = [
        "backtesting", "kupiec", "christoffersen", "lopez",
        "var", "lar", "pdla", "lgd", "pd", "validación",
        "markov", "garch", "var condicional", "expected shortfall",
        "replica", "calibración", "prueba", "monitoreo"
    ]
    encontrados = []
    texto_lower = texto.lower()
    for termino in terminos:
        if termino in texto_lower:
            encontrados.append(termino)
    return encontrados


# ─── ANÁLISIS COMPARATIVO ────────────────────────────────────────────────────────

def comparar_doc_y_codigo(
    doc_text: str,
    codigo_text: str,
    tipo_codigo: str = "python"  # "python" o "jupyter"
) -> Dict:
    """
    Compara un documento con código fuente.

    Returns:
    {
      "coherencia_score": float (0-1),
      "elementos_documentados": dict,
      "elementos_en_codigo": dict,
      "coincidencias": list,
      "no_documentados": list,
      "implementados_no_documentados": list,
      "reporte": str,
    }
    """
    
    # Extraer elementos del documento
    doc_keywords = extraer_palabras_clave_doc(doc_text)
    
    # Extraer elementos del código
    funciones = extraer_funciones_python(codigo_text)
    clases = extraer_clases_python(codigo_text)
    imports = extraer_imports(codigo_text)
    
    # Análisis de coincidencia
    doc_terms_lower = [k.lower() for k in doc_keywords]
    codigo_terms = [f.lower() for f in funciones] + [c.lower() for c in clases]
    
    coincidencias = list(set(doc_terms_lower) & set(codigo_terms))
    no_documentados = [term for term in codigo_terms if term not in doc_terms_lower]
    impl_no_doc = [term for term in codigo_terms if term not in coincidencias]
    
    # Score de coherencia (0-1)
    if len(codigo_terms) == 0:
        coherencia = 0.0
    else:
        coherencia = len(coincidencias) / len(codigo_terms)
    
    reporte = f"""
ANÁLISIS DE COHERENCIA DOCUMENTO-CÓDIGO
══════════════════════════════════════════════════════════════════

📊 SCORE DE COHERENCIA: {coherencia:.1%}

📋 ELEMENTOS ENCONTRADOS EN DOCUMENTACIÓN:
   • Términos técnicos: {', '.join(doc_keywords) if doc_keywords else 'Ninguno'}

🔧 ELEMENTOS EN CÓDIGO:
   • Funciones: {', '.join(funciones[:10]) if funciones else 'Ninguna'}
   • Clases: {', '.join(clases) if clases else 'Ninguna'}
   • Librerías: {', '.join(imports) if imports else 'Ninguna'}

✅ COINCIDENCIAS ENCONTRADAS:
   {len(coincidencias)} elementos coinciden entre documentación y código

⚠️  IMPLEMENTADOS PERO NO DOCUMENTADOS:
   {', '.join(impl_no_doc[:5]) if impl_no_doc else 'Ninguno (bien documentado)'}
   {"..." if len(impl_no_doc) > 5 else ""}

📌 RECOMENDACIÓN:
"""
    
    if coherencia >= 0.8:
        reporte += "   ✅ Documentación y código están bien alineados."
    elif coherencia >= 0.5:
        reporte += "   ⚠️  Se recomienda mejorar la documentación para cubrir todas las funciones implementadas."
    else:
        reporte += "   ❌ Hay una brecha significativa. La documentación debe actualizarse urgentemente."
    
    return {
        "coherencia_score": coherencia,
        "elementos_documentados": {"terminos": doc_keywords},
        "elementos_en_codigo": {"funciones": funciones, "clases": clases, "imports": imports},
        "coincidencias": coincidencias,
        "no_documentados": no_documentados,
        "implementados_no_documentados": impl_no_doc,
        "reporte": reporte,
    }


def generar_instruccion_implementacion_mejorada() -> str:
    """
    Genera instrucción mejorada para el ámbito Implementación que incluya
    análisis documento-código.
    """
    return """
ÁMBITO: Implementación

INSTRUCCIONES ESPECÍFICAS:
─────────────────────────────────────────────────────────────────

✅ VERIFICAR COHERENCIA DOCUMENTO-CÓDIGO:
   1. Revisar que el manual de implementación describe TODAS las funciones principales
   2. Verificar que los scripts implementados (.py, .ipynb) contienen las funciones documentadas
   3. Detectar funciones en código NO mencionadas en documentación → CRÍTICO
   4. Buscar evidencia de UAT (User Acceptance Testing) con correos de aprobación
   5. Validar que el código está en producción y funciona correctamente

⚠️  RIESGOS A DETECTAR:
   • Código en producción diferente del código documentado (drift)
   • Funciones críticas implementadas sin documentación
   • Scripts sin comentarios internos explicando lógica
   • Ausencia de mantenimiento documentado

📊 CRITERIOS MÍNIMOS (para score 4+):
   • Coherencia documento-código ≥ 80%
   • Todas las funciones principales documentadas
   • Correos de aprobación de cambios a producción
   • Scripts con docstrings descriptivos
"""
