"""
Mx_00_CargaRutas.py
====================
Configuración central del Motor VIRF.
Define rutas, parámetros de la API, constantes del dominio
y el rol del agente como Auditor Senior independiente.

Responsabilidades:
  - Cargar API key desde variables de entorno
  - Definir rutas de inputs, outputs y repositorio
  - Definir constantes de evaluación (umbrales, tier, modos)
  - Exponer ROL_AGENTE y CUESTIONAMIENTOS_METODOLOGICOS
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ─── API ─────────────────────────────────────────────────────────────────────
API_KEY        = os.getenv("ANTHROPIC_API_KEY", "")
MODELO_CLAUDE  = os.getenv("ANTHROPIC_MODELO", "claude-sonnet-4-6")
AGENTE_VERSION = "20"                                         # [v20] fuente única de verdad  # [v17] lee del .env = sin conflicto con config.py
MAX_TOKENS     = int(os.getenv("ANTHROPIC_MAX_TOKENS", 4096))         # [v17] lee del .env
API_URL        = "https://api.anthropic.com/v1/messages"
# NOTA: API_HEADERS NO se define aquí — se construye en Mx_03 en tiempo de llamada
# para garantizar que ANTHROPIC_API_KEY ya fue cargada por load_dotenv().

# ─── RUTAS ───────────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent.parent  # raíz del proyecto

RUTAS = {
    "repositorio_informes": BASE_DIR / "repositorio_informes",
    "estandares_virf":      BASE_DIR / "inputs" / "Estandares_VIRF.xlsx",
    "outputs":              BASE_DIR / "outputs",
    "inputs": {
        # documentacion separada en subdirectorios para que leer_carpeta funcione con rglob
        "doc_modelamiento": BASE_DIR / "inputs" / "documentacion" / "modelamiento",
        "doc_seguimiento":  BASE_DIR / "inputs" / "documentacion" / "seguimiento",
        "papers":           BASE_DIR / "inputs" / "papers",
        "calidad_datos":    BASE_DIR / "inputs" / "calidad_datos",
        "implementacion":   BASE_DIR / "inputs" / "implementacion",
        "usos":             BASE_DIR / "inputs" / "usos",
    },
}

# ─── PARÁMETROS DE LECTURA ───────────────────────────────────────────────────
MAX_CHARS_DOC    = 15000  # [FIX-DOC] Aumentado: manuales financieros tienen 60-150 páginas (~120k chars)
MAX_CHARS_CODIGO = 8000   # [FIX-DOC] Aumentado: scripts de modelos pueden tener miles de líneas
MAX_FILAS_EXCEL  = 200    # [FIX-DOC] Aumentado: tablas de controles suelen tener >50 filas

# ─── UMBRALES ─────────────────────────────────────────────────────────────────
UMBRAL_RIESGO_GLOBAL = 0.30   # Si >30% sin evidencia → RIESGO GLOBAL ALTO

# ─── TIERS VÁLIDOS ───────────────────────────────────────────────────────────
TIERS_VALIDOS = ("I", "II", "III", "IV")

# ─── MODOS ───────────────────────────────────────────────────────────────────
MODO_PREPRDC = "preprdc"   # Evaluación con score + criticidad (iterativo)
MODO_PRDC    = "prdc"      # Solo estado + observación (producción)

# ─── CACHÉ DE DOCUMENTOS (v15) ────────────────────────────────────────────────
# Habilitado solo en MODO_PREPRDC para acelerar corridas iterativas.
# En MODO_PRDC siempre se lee en fresco para garantizar datos actualizados.
CACHE_ENABLED    = os.getenv("CACHE_ENABLED", "1") == "1"   # 1=on, 0=off
CACHE_DIR        = os.getenv("CACHE_DIR", str(Path(__file__).parent.parent / "cache"))

# ─── MAPEO DIMENSIÓN → CARPETAS DE INPUT ─────────────────────────────────────
# IMPORTANTE: Los nombres deben coincidir exactamente con los del Excel Estandares_VIRF.xlsx
AMBITO_A_INPUTS = {
    "Documentación":                 ["doc_modelamiento", "doc_seguimiento", "papers"],
    "Calidad de datos":              ["calidad_datos", "doc_modelamiento"],  # ← Minúscula en 'd'
    "Metodología":                   ["doc_modelamiento", "papers", "doc_seguimiento"],
    "Gobierno":                      ["doc_modelamiento", "implementacion"],
    "Implementación":                ["implementacion", "doc_modelamiento"],
    "Uso e integración a la gestión":["usos", "implementacion"],  # ← Nombre completo del Excel
}

# ─── INSTRUCCIONES ESPECÍFICAS POR DIMENSIÓN ─────────────────────────────────
INSTRUCCIONES_DIMENSION = {
    "Documentación": (
        "Revisa con mayor prioridad los manuales (.docx/.pdf) y scripts de seguimiento. "
        "El manual metodológico debe tener teoría, supuestos y justificación del modelo. "
        "El operativo debe describir la ejecución. Para backtesting buscar Kupiec, "
        "Christoffersen, López o Berkowitz. Si no existen, generar preguntas específicas."
    ),
    "Calidad de datos": (  # ← CORREGIDO: minúscula en 'd'
        "Buscar el script _replica_virf.py. Si no existe, el agente lo generará. "
        "Verificar: missing (MCAR/MAR/MNAR), duplicados, outliers (cuestionar Z-score), "
        "integridad referencial. Revisar scripts del modelador línea por línea."
    ),
    "Metodología": (
        "Centrarse en la justificación del modelo, supuestos y su validación empírica. "
        "Para LaR/VaR: verificar pruebas Kupiec, Christoffersen y análisis de excedencias. "
        "Cuestionar si no hay comparación con modelo alternativo."
    ),
    "Gobierno": (
        "Solo aceptar actas formales firmadas. Un correo NO equivale a acta. "
        "Verificar tiering asignado y su justificación. Si falta evidencia → Solicitar Actas."
    ),
    "Implementación": (
        "Buscar COHERENCIA entre documentación y código: ¿Las funciones documentadas "
        "en el manual de implementación existen en los scripts (.py, .ipynb)? ¿Hay funciones "
        "en código SIN documentación (RIESGO)? Detectar cambios no documentados (code drift). "
        "Buscar correos de aprobación para paso a producción. Si no existen, generar pregunta específica. "
        "Verificar UAT documentadas y controles en pipeline productivo."
    ),
    "Uso e integración a la gestión": (  # ← CORREGIDO: nombre completo
        "Identificar quiénes son los usuarios del modelo y para qué lo usan. "
        "Verificar que los outputs del modelo en producción son consistentes con los de desarrollo. "
        "Buscar reportes de seguimiento presentados a comités."
    ),
}

# ─── ROL DEL AGENTE ──────────────────────────────────────────────────────────
# Versión OPTIMIZADA: 60% más compacta, igual efectiva
ROL_AGENTE = """Eres Auditor Senior Independiente en Validación de Modelos Financieros (VIRF).
Especialización: LaR, VaR, PD, LGD, IFRS 9, scoring.

COMPORTAMIENTO:
✓ CRÍTICO e independiente — Segunda línea de defensa
✓ Basado solo en EVIDENCIA EXPLÍCITA — nunca asumas
✓ Detecta inconsistencias documento ↔ código
✓ Conoces: Kupiec, Christoffersen, López (backtesting)
✓ Marco: SR 11-7, SS3/17, Basilea III/IV, IFRS 9

NUNCA valides sin evidencia. SIEMPRE actúas como auditor independiente.
Cuando falta: genera preguntas específicas y concretas."""

# ─── CUESTIONAMIENTOS METODOLÓGICOS AUTOMÁTICOS ──────────────────────────────
CUESTIONAMIENTOS_METODOLOGICOS = {
    "outliers_zscore": {
        "detectar":         ["zscore", "z_score", "z-score", "scipy.stats.zscore", "3 sigma"],
        "detectar_ausencia": False,
        "contexto":         "Eliminación de outliers con Z-score",
        "critica": (
            "Z-score asume normalidad y es sensible a los propios outliers. "
            "Para datos financieros fat-tail usar: GESD (Generalized ESD), "
            "IQR robusto, Isolation Forest (multivariado) o Mahalanobis Distance."
        ),
    },
    "imputation_mean": {
        "detectar":         ["fillna(mean", "fillna(df.mean", "SimpleImputer.*mean"],
        "detectar_ausencia": False,
        "contexto":         "Imputación de missing con media aritmética",
        "critica": (
            "Imputar con media destruye varianza e introduce sesgo. "
            "Alternativas: MICE (IterativeImputer), KNN Imputation, MissForest. "
            "Referencia: EBA GL/2021/07 §45."
        ),
    },
    "train_test_split_random": {
        "detectar":         ["train_test_split", "shuffle=True"],
        "detectar_ausencia": False,
        "contexto":         "División aleatoria train/test en datos temporales",
        "critica": (
            "División aleatoria introduce data leakage en datos financieros temporales. "
            "Usar split temporal (OOT) con mínimo 6-12 meses fuera de muestra. SR 11-7."
        ),
    },
    "sin_psi": {
        "detectar":         ["psi", "population_stability", "estabilidad_poblacional"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de análisis PSI",
        "critica": (
            "No se detecta PSI. SR 11-7 y EBA exigen monitoreo de estabilidad. "
            "PSI<0.10: estable | 0.10-0.25: observación | >0.25: rediseño requerido."
        ),
    },
    "sin_backtesting_lar": {
        "detectar":         ["kupiec", "christoffersen", "lopez_test", "berkowitz", "var_backtest"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de backtesting estadístico para modelos de riesgo",
        "critica": (
            "No se detectan pruebas de backtesting (Kupiec, Christoffersen, López). "
            "Requeridas por Basilea III (FRTB) y SR 11-7 para modelos VaR/LaR."
        ),
    },
    "sin_shap_modelos_complejos": {
        "detectar": [
            "XGBClassifier", "LGBMClassifier", "RandomForestClassifier",
            "GradientBoostingClassifier", "xgboost", "lightgbm",
        ],
        "detectar_ausencia": False,
        "contexto":         "Modelos no lineales sin análisis de explicabilidad",
        "critica": (
            "Modelos tree-based sin SHAP values. Incumple SR 11-7 (explicabilidad) "
            "y GDPR art.22. Implementar SHAP para explicabilidad global y local."
        ),
    },
    "sin_replica_virf": {
        "detectar":         ["_replica_virf", "replica_virf"],
        "detectar_ausencia": True,
        "contexto":         "Ausencia de script _replica_virf.py de control de calidad de datos",
        "critica": (
            "No se detecta script _replica_virf.py. Este script es el control de "
            "segunda línea para calidad de datos. El agente generará una propuesta."
        ),
    },
}
