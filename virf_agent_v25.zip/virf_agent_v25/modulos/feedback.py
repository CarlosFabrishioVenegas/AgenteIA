"""
modulos/feedback.py
Gestión de feedback del validador sobre las evaluaciones del agente.

Flujo:
  1. Al final de cada corrida (--preprdc o --prdc), se lanza un bucle interactivo
     donde el usuario puede registrar correcciones a cualquier actividad evaluada.
  2. El feedback se guarda en feedback/historial_feedback.json
  3. En la siguiente corrida, el motor IA recibe el historial como contexto adicional
     para ajustar sus evaluaciones.
  4. Con --estadisticafeedback se genera un informe de precisión del agente.
"""

import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

FEEDBACK_PATH = Path(__file__).parent.parent / "feedback" / "historial_feedback.json"


# ─── Carga y guardado del JSON ────────────────────────────────────────────────

def cargar_historial() -> List[Dict]:
    """Carga el historial completo de feedback desde el JSON."""
    if not FEEDBACK_PATH.exists():
        return []
    try:
        with open(FEEDBACK_PATH, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def guardar_historial(historial: List[Dict]):
    """Persiste el historial en el JSON."""
    FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(FEEDBACK_PATH, "w", encoding="utf-8") as f:
        json.dump(historial, f, ensure_ascii=False, indent=2)


# ─── Bucle interactivo de feedback ───────────────────────────────────────────

def _mostrar_resumen_evaluaciones(evaluaciones_por_ambito: Dict[str, List[Dict]]):
    """Imprime un índice numerado de todas las actividades evaluadas."""
    print("\n" + "═" * 65)
    print("  📝 REGISTRO DE FEEDBACK")
    print("  Puedes corregir cualquier evaluación del agente.")
    print("  Escribe 'fin' cuando termines, 'ver' para ver actividades.")
    print("═" * 65)

    idx = 1
    indice = {}
    for ambito, evals in evaluaciones_por_ambito.items():
        print(f"\n  [{ambito.upper()}]")
        for ev in evals:
            puntaje = ev.get("puntaje", "?")
            actividad = ev.get("actividad", "")[:65]
            print(f"    {idx:>3}. [{puntaje}/5] {actividad}")
            indice[idx] = {"ambito": ambito, "eval": ev}
            idx += 1
    print()
    return indice


def bucle_feedback_consola(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    titulo_modelo: str,
    tier: str,
    version: str,
) -> List[Dict]:
    """
    Bucle interactivo al final de la ejecución.
    Retorna lista de feedbacks ingresados en esta sesión.
    """
    historial = cargar_historial()
    nuevos_feedbacks = []
    indice = _mostrar_resumen_evaluaciones(evaluaciones_por_ambito)

    print("  ¿Deseas registrar feedback? (s/n): ", end="")
    respuesta = input().strip().lower()
    if respuesta != "s":
        print("  Sin feedback registrado. ✓\n")
        return []

    while True:
        print("\n  Número de actividad a corregir (o 'fin' para terminar, 'ver' para listar): ", end="")
        entrada = input().strip().lower()

        if entrada == "fin":
            break

        if entrada == "ver":
            indice = _mostrar_resumen_evaluaciones(evaluaciones_por_ambito)
            continue

        try:
            num = int(entrada)
            if num not in indice:
                print(f"  [!] Número {num} no válido. Rango: 1-{max(indice.keys())}")
                continue
        except ValueError:
            print("  [!] Ingresa un número, 'fin' o 'ver'.")
            continue

        item = indice[num]
        ambito    = item["ambito"]
        actividad = item["eval"].get("actividad", "")
        puntaje_agente = item["eval"].get("puntaje", 0)

        print(f"\n  Ámbito   : {ambito}")
        print(f"  Actividad: {actividad[:80]}")
        print(f"  Puntaje del agente: {puntaje_agente}/5")

        # Puntaje correcto
        while True:
            print(f"  Puntaje correcto según tu criterio (1-5): ", end="")
            try:
                puntaje_correcto = int(input().strip())
                if 1 <= puntaje_correcto <= 5:
                    break
                print("  [!] Ingresa un número entre 1 y 5.")
            except ValueError:
                print("  [!] Número inválido.")

        # Comentario
        print(f"  ¿Qué debió hacer el agente? (descripción breve): ", end="")
        comentario = input().strip()
        if not comentario:
            comentario = "Sin comentario adicional."

        feedback_entry = {
            "fecha":           datetime.now().strftime("%d/%m/%Y %H:%M"),
            "titulo_modelo":   titulo_modelo,
            "tier":            tier,
            "version":         version,
            "ambito":          ambito,
            "actividad":       actividad,
            "puntaje_agente":  puntaje_agente,
            "puntaje_correcto": puntaje_correcto,
            "diferencia":      puntaje_correcto - puntaje_agente,
            "comentario":      comentario,
        }

        historial.append(feedback_entry)
        nuevos_feedbacks.append(feedback_entry)
        guardar_historial(historial)

        signo = "+" if feedback_entry["diferencia"] > 0 else ""
        print(f"  ✓ Feedback guardado. Diferencia: {signo}{feedback_entry['diferencia']} puntos")

    if nuevos_feedbacks:
        print(f"\n  ✅ {len(nuevos_feedbacks)} feedback(s) guardados en feedback/historial_feedback.json\n")
    else:
        print("  Sin cambios registrados.\n")

    return nuevos_feedbacks


# ─── Contexto de feedback para el motor IA ───────────────────────────────────

def construir_contexto_feedback(ambito: str, actividad: str) -> str:
    """
    Busca en el historial si hay feedback previo relevante para esta actividad
    y lo formatea como contexto adicional para el motor IA.
    """
    historial = cargar_historial()
    if not historial:
        return ""

    relevantes = [
        fb for fb in historial
        if fb.get("ambito", "").lower() == ambito.lower()
        and (
            actividad.lower()[:40] in fb.get("actividad", "").lower()
            or fb.get("actividad", "").lower()[:40] in actividad.lower()
        )
    ]

    if not relevantes:
        # Feedback del mismo ámbito como guía general
        del_ambito = [fb for fb in historial if fb.get("ambito", "").lower() == ambito.lower()][-3:]
        if not del_ambito:
            return ""
        relevantes = del_ambito

    lineas = ["HISTORIAL DE FEEDBACK DEL VALIDADOR (correcciones a evaluaciones anteriores):"]
    for fb in relevantes[-5:]:  # máximo 5 más recientes
        diff = fb.get("diferencia", 0)
        signo = "sobreestimó" if diff < 0 else "subestimó" if diff > 0 else "coincidió"
        lineas.append(
            f"- Actividad: '{fb.get('actividad','')[:60]}' | "
            f"Agente dio {fb.get('puntaje_agente')}/5, correcto era {fb.get('puntaje_correcto')}/5 "
            f"(el agente {signo} en {abs(diff)} punto(s)). "
            f"Comentario: {fb.get('comentario','')}"
        )
    lineas.append("→ Considera este historial para calibrar tu evaluación actual.")
    return "\n".join(lineas)


# ─── Estadísticas de precisión ───────────────────────────────────────────────

def calcular_estadisticas() -> Dict:
    """Calcula métricas de precisión del agente basadas en el historial de feedback."""
    historial = cargar_historial()
    if not historial:
        return {"error": "No hay historial de feedback registrado."}

    total = len(historial)
    diferencias = [abs(fb["diferencia"]) for fb in historial]
    diferencias_con_signo = [fb["diferencia"] for fb in historial]

    exactos      = sum(1 for d in diferencias if d == 0)
    diff_1       = sum(1 for d in diferencias if d == 1)
    diff_2_mas   = sum(1 for d in diferencias if d >= 2)
    sobreestima  = sum(1 for d in diferencias_con_signo if d < 0)
    subestima    = sum(1 for d in diferencias_con_signo if d > 0)

    mae = sum(diferencias) / total  # Mean Absolute Error
    sesgo = sum(diferencias_con_signo) / total  # Sesgo promedio (+ = subestima, - = sobreestima)

    # Por ámbito
    ambitos_stats = {}
    for fb in historial:
        amb = fb.get("ambito", "Desconocido")
        if amb not in ambitos_stats:
            ambitos_stats[amb] = {"total": 0, "suma_diff_abs": 0, "suma_diff": 0, "exactos": 0}
        ambitos_stats[amb]["total"] += 1
        ambitos_stats[amb]["suma_diff_abs"] += abs(fb["diferencia"])
        ambitos_stats[amb]["suma_diff"] += fb["diferencia"]
        if fb["diferencia"] == 0:
            ambitos_stats[amb]["exactos"] += 1

    for amb, s in ambitos_stats.items():
        s["mae"]           = round(s["suma_diff_abs"] / s["total"], 3)
        s["sesgo"]         = round(s["suma_diff"] / s["total"], 3)
        s["pct_exactos"]   = round(s["exactos"] / s["total"] * 100, 1)
        s["pct_1_punto"]   = round(sum(1 for fb in historial if fb.get("ambito") == amb and abs(fb["diferencia"]) <= 1) / s["total"] * 100, 1)

    # Por modelo
    modelos_stats = {}
    for fb in historial:
        mod = fb.get("titulo_modelo", "Desconocido")
        if mod not in modelos_stats:
            modelos_stats[mod] = {"total": 0, "suma_diff_abs": 0}
        modelos_stats[mod]["total"] += 1
        modelos_stats[mod]["suma_diff_abs"] += abs(fb["diferencia"])
    for mod, s in modelos_stats.items():
        s["mae"] = round(s["suma_diff_abs"] / s["total"], 3)

    return {
        "total_feedbacks":        total,
        "evaluaciones_exactas":   exactos,
        "pct_exactas":            round(exactos / total * 100, 1),
        "diferencia_1_punto":     diff_1,
        "pct_diff_1":             round(diff_1 / total * 100, 1),
        "diferencia_2_o_mas":     diff_2_mas,
        "pct_diff_2_mas":         round(diff_2_mas / total * 100, 1),
        "pct_dentro_1_punto":     round((exactos + diff_1) / total * 100, 1),
        "mae":                    round(mae, 3),
        "sesgo_promedio":         round(sesgo, 3),
        "sesgo_interpretacion":   "Agente subestima" if sesgo > 0.2 else "Agente sobreestima" if sesgo < -0.2 else "Sin sesgo significativo",
        "n_sobreestimaciones":    sobreestima,
        "n_subestimaciones":      subestima,
        "por_ambito":             ambitos_stats,
        "por_modelo":             modelos_stats,
        "primer_feedback":        historial[0].get("fecha", ""),
        "ultimo_feedback":        historial[-1].get("fecha", ""),
    }
