

"""
modulos/generador_word.py
Genera VIRF_Informe_*.docx — Informe de validación en formato PLANO y legible

Estructura simplificada del informe:
  1. Portada (títulos básicos)
  2. Resumen ejecutivo (si aplica)
  3. Listado jerárquico:
     - ÁMBITO
       - Control
         - Actividad 1
           Concepto de actividad: ...
           Resultado de la actividad: ...
           Observaciones: ...
           Oportunidad de mejora: ...
         - Actividad 2
           ...
"""
 
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import re
 
try:
    from config import ESCALA_PUNTAJE, SCORE_SEMAFORO, AMBITO_PESOS
except ImportError:
    from Mx_00_CargaRutas import RUTAS
    from config import ESCALA_PUNTAJE, SCORE_SEMAFORO, AMBITO_PESOS
 
 
# ─── Colores corporativos ─────────────────────────────────────────────────────
AZUL_DARK  = RGBColor(0x1F, 0x38, 0x64)
AZUL_MID   = RGBColor(0x2E, 0x75, 0xB6)
GRIS_TEXT  = RGBColor(0x40, 0x40, 0x40)
BLANCO     = RGBColor(0xFF, 0xFF, 0xFF)
NARANJA    = RGBColor(0xFF, 0x66, 0x00)
 
 
# ─── Utilidades de color y escala ─────────────────────────────────────────────
 
def _hex_to_rgb(h: str) -> RGBColor:
    h = h.lstrip("#")
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
 
 
def _score_color_hex(score: float) -> str:
    for (lo, hi), info in SCORE_SEMAFORO.items():
        if lo <= score <= hi:
            return info["color"]
    return "CCCCCC"
 
 
def _label_semaforo(score: float) -> str:
    for (lo, hi), info in SCORE_SEMAFORO.items():
        if lo <= score <= hi:
            return info["label"]
    return "SIN CLASIFICAR"
 
 
def _puntaje_label(p: int) -> str:
    return ESCALA_PUNTAJE.get(p, {}).get("label", str(p))
 
 
def _puntaje_color_hex(p: int) -> str:
    return ESCALA_PUNTAJE.get(p, {}).get("color", "CCCCCC")


def _status_resultado(puntaje: int) -> str:
    """Etiqueta de estado para el campo 'Resultado de la actividad'."""
    return {
        1: "NO CUMPLE",
        2: "REQUIERE REMEDIACIÓN CRÍTICA",
        3: "CON OBSERVACIONES",
        4: "ACEPTABLE",
        5: "CUMPLE COMPLETAMENTE",
    }.get(puntaje, "SIN CLASIFICAR")
 
 
def _normalizar_score(raw) -> int:
    """Convierte score (0-100) o puntaje (1-5) a escala 1-5."""
    if raw is None:
        return 1
    raw = float(raw)
    if raw > 5:
        return max(1, min(5, round(1 + (raw / 100) * 4)))
    return max(1, min(5, round(raw) or 1))


def _es_error(texto: str) -> bool:
    """Detecta si el texto contiene un mensaje de error."""
    if not texto:
        return False
    texto_lower = str(texto).lower()
    indicadores_error = [
        "error",
        "401",
        "unauthorized",
        "api",
        "exception",
        "traceback",
        "failed",
        "timeout",
        "connection",
        "n/a",
        "no disponible",
    ]
    return any(ind in texto_lower for ind in indicadores_error)


def _generar_recomendacion_automatica(actividad: str, puntaje: int, concepto: str = "", observacion: str = "") -> str:
    """
    Genera una recomendación automática según el puntaje y contexto.
    Útil cuando falla la evaluación de la IA.
    """
    recomendaciones_por_puntaje = {
        1: f"Se recomienda verificar inmediatamente la existencia y disponibilidad de documentación para '{actividad}'. Realizar un diagnóstico inicial de lo que se necesita documentar.",
        2: f"Se requiere remediación crítica para '{actividad}'. Priorizar la creación y documentación de los procesos y controles identificados como ausentes.",
        3: f"Se recomienda completar los elementos faltantes para '{actividad}'. Revisar brechas identificadas y establecer plan de acción.",
        4: f"Implementar las mejoras menores sugeridas para '{actividad}'. Validar que los controles estén funcionando adecuadamente.",
        5: f"Mantener el nivel actual de cumplimiento en '{actividad}'. Continuar con el seguimiento periódico de la documentación.",
    }
    return recomendaciones_por_puntaje.get(puntaje, "Revisar y validar el control según los hallazgos identificados.")


# ─── Helpers de formato Word ──────────────────────────────────────────────────
 
def _set_cell_bg(cell, hex_color: str):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color.upper())
    tcPr.append(shd)
 
 
def _set_cell_borders(cell, color: str = "CCCCCC", size: int = 4):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = OxmlElement("w:tcBorders")
    for side in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{side}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(size))
        el.set(qn("w:space"), "0")
        el.set(qn("w:color"), color.upper())
        tcBorders.append(el)
    tcPr.append(tcBorders)
 
 
def _cell_text(cell, text: str, bold=False, italic=False,
               color: RGBColor = None, size: int = 9, align: str = "left"):
    para = cell.paragraphs[0]
    para.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                      "center": WD_ALIGN_PARAGRAPH.CENTER,
                      "right": WD_ALIGN_PARAGRAPH.RIGHT}.get(align, WD_ALIGN_PARAGRAPH.LEFT)
    if not para.runs:
        para.add_run("")
    run = para.runs[0]
    run.text = str(text or "")
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    run.font.name = "Arial"
    run.font.color.rgb = color or GRIS_TEXT
 
 
def _add_heading(doc: Document, text: str, level: int = 1):
    p = doc.add_heading(text, level=level)
    for run in p.runs:
        run.font.color.rgb = AZUL_DARK if level == 1 else AZUL_MID
        run.font.name = "Arial"
    return p
 
 
def _add_para(doc: Document, text: str, bold=False, italic=False,
              color: RGBColor = None, size: int = 10, align: str = "left"):
    p = doc.add_paragraph()
    p.alignment = {"left": WD_ALIGN_PARAGRAPH.LEFT,
                   "center": WD_ALIGN_PARAGRAPH.CENTER}.get(align, WD_ALIGN_PARAGRAPH.LEFT)
    run = p.add_run(text)
    run.bold = bold
    run.italic = italic
    run.font.size = Pt(size)
    run.font.name = "Arial"
    run.font.color.rgb = color or GRIS_TEXT
    return p
 
 
def _add_numbered(doc: Document, text: str, size: int = 9):
    p = doc.add_paragraph(style="List Number")
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = "Arial"
    run.font.color.rgb = GRIS_TEXT
 
 
def _add_bullet(doc: Document, text: str, size: int = 9):
    p = doc.add_paragraph(style="List Bullet")
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = "Arial"
    run.font.color.rgb = GRIS_TEXT
 
 
def _hr(doc: Document, color_hex: str = "2E75B6"):
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), color_hex.upper())
    pBdr.append(bottom)
    pPr.append(pBdr)
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after  = Pt(4)
 
 
# ─── Helpers para generar contenido jerárquico plano ──────────────────────────

def _add_ambito_heading(doc: Document, ambito: str, puntaje: int):
    """Encabezado de ámbito con línea decorativa inferior."""
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0)
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after  = Pt(2)
    run = p.add_run(f"ÁMBITO: {ambito.upper()}")
    run.font.size = Pt(13)
    run.font.bold = True
    run.font.color.rgb = AZUL_DARK
    run.font.name = "Arial"
    _hr(doc, "1F3864")



def _add_field_block(doc: Document, label: str, value: str,
                     indent: float = 0.5, label_color: RGBColor = None):
    """Etiqueta en línea propia (bold) y contenido en el párrafo siguiente."""
    value = str(value).strip() if value else "No aplica"

    p_lbl = doc.add_paragraph()
    p_lbl.paragraph_format.left_indent = Cm(float(indent))
    p_lbl.paragraph_format.space_before = Pt(7)
    p_lbl.paragraph_format.space_after  = Pt(1)
    r = p_lbl.add_run(f"{label}:")
    r.font.size  = Pt(9)
    r.font.bold  = True
    r.font.color.rgb = label_color or AZUL_MID
    r.font.name  = "Arial"

    p_val = doc.add_paragraph()
    p_val.paragraph_format.left_indent = Cm(float(indent))
    p_val.paragraph_format.space_before = Pt(1)
    p_val.paragraph_format.space_after  = Pt(3)
    r2 = p_val.add_run(value)
    r2.font.size  = Pt(9)
    r2.font.color.rgb = GRIS_TEXT
    r2.font.name  = "Arial"


def _add_result_line(doc: Document, puntaje: int, indent: float = 0.5):
    """Resultado de la actividad con score coloreado y etiqueta de estado."""
    label     = _puntaje_label(puntaje)
    status    = _status_resultado(puntaje)
    color_rgb = _hex_to_rgb(_puntaje_color_hex(puntaje))

    p_lbl = doc.add_paragraph()
    p_lbl.paragraph_format.left_indent = Cm(float(indent))
    p_lbl.paragraph_format.space_before = Pt(7)
    p_lbl.paragraph_format.space_after  = Pt(1)
    r = p_lbl.add_run("Resultado de la actividad:")
    r.font.size  = Pt(9)
    r.font.bold  = True
    r.font.color.rgb = AZUL_MID
    r.font.name  = "Arial"

    p_val = doc.add_paragraph()
    p_val.paragraph_format.left_indent = Cm(float(indent))
    p_val.paragraph_format.space_before = Pt(1)
    p_val.paragraph_format.space_after  = Pt(3)

    r_score = p_val.add_run(f"{puntaje}/5 — {label}")
    r_score.font.size  = Pt(9)
    r_score.font.bold  = True
    r_score.font.color.rgb = color_rgb
    r_score.font.name  = "Arial"

    r_sep = p_val.add_run(f"  |  {status}")
    r_sep.font.size   = Pt(9)
    r_sep.font.italic = True
    r_sep.font.color.rgb = AZUL_DARK
    r_sep.font.name   = "Arial"

# ─── Tabla resumen de scores ──────────────────────────────────────────────────
 
def _tabla_scores(doc: Document, scores_por_ambito: Dict[str, float], score_global: float):
    tabla = doc.add_table(rows=1, cols=4)
    tabla.style = "Table Grid"
    tabla.alignment = WD_TABLE_ALIGNMENT.CENTER
 
    col_w = [Cm(7.5), Cm(2.2), Cm(2.2), Cm(5.1)]
    for i, (h, w) in enumerate(zip(["ÁMBITO", "PESO", "SCORE", "DICTAMEN"], col_w)):
        c = tabla.rows[0].cells[i]
        c.width = w
        _cell_text(c, h, bold=True, color=BLANCO, size=9, align="center")
        _set_cell_bg(c, "1F3864")
        _set_cell_borders(c, "1F3864")
 
    for ambito, score in scores_por_ambito.items():
        peso  = AMBITO_PESOS.get(ambito, 0)
        color = _score_color_hex(score)
        row   = tabla.add_row().cells
        for i, (c, v) in enumerate(zip(row, [ambito, f"{peso*100:.0f}%", f"{score:.2f}", _label_semaforo(score)])):
            c.width = col_w[i]
            _set_cell_borders(c, "CCCCCC")
            if i in (2, 3):
                _cell_text(c, v, bold=True, color=BLANCO, size=9, align="center")
                _set_cell_bg(c, color)
            else:
                _cell_text(c, v, size=9, align="left" if i == 0 else "center")
 
    rg = tabla.add_row().cells
    color_g = _score_color_hex(score_global)
    rg[0].merge(rg[1])
    rg[0].width = col_w[0]
    _cell_text(rg[0], "SCORE GLOBAL PONDERADO", bold=True, color=BLANCO, size=10, align="center")
    _set_cell_bg(rg[0], "1F3864")
    _set_cell_borders(rg[0], "1F3864")
    _cell_text(rg[2], f"{score_global:.2f}", bold=True, color=BLANCO, size=12, align="center")
    _set_cell_bg(rg[2], color_g)
    _set_cell_borders(rg[2], color_g)
    _cell_text(rg[3], _label_semaforo(score_global), bold=True, color=BLANCO, size=11, align="center")
    _set_cell_bg(rg[3], color_g)
    _set_cell_borders(rg[3], color_g)
    doc.add_paragraph()
 
 
# ─── Índice de controles por ámbito ──────────────────────────────────────────
 
def _indice_controles_ambito(doc: Document, evaluaciones: List[Dict]):
    """Lista numerada de todos los controles/estándares aplicables en el ámbito."""
    _add_para(doc, "Estándares y controles aplicables:", bold=True, color=AZUL_MID, size=10)
    for ev in evaluaciones:
        control   = ev.get("control", "")
        actividad = ev.get("actividad", "")
        texto = f"{control} — {actividad}" if control else actividad
        _add_numbered(doc, texto)
    doc.add_paragraph()
 
 
# ─── Ficha detallada de un control ───────────────────────────────────────────
 
def _ficha_control(doc: Document, ev: Dict, num: int):
    """
    Ficha de una actividad/control con:
      encabezado (nombre + puntaje) | descripción | evidencia | observación | recomendación | preguntas
    """
    actividad = ev.get("actividad", f"Actividad {num}")
    control   = ev.get("control", "")
    concepto  = ev.get("concepto", "")
    evidencia = ev.get("evidencia") or ev.get("evidencia_encontrada") or ""
    observ    = ev.get("observacion_tecnica") or ev.get("observacion") or ""
    recomend  = ev.get("recomendacion", "")
    preguntas = ev.get("preguntas_faltantes") or ev.get("preguntas_pendientes") or []
 
    puntaje   = _normalizar_score(ev.get("score", ev.get("puntaje", 50)))
    color_hex = _puntaje_color_hex(puntaje)
    label     = _puntaje_label(puntaje)
 
    # ── MANEJO DE ERRORES: detectar y reemplazar contenido erróneo ─────────
    if _es_error(evidencia):
        evidencia = ""
    if _es_error(observ):
        observ = ""
    if _es_error(concepto):
        concepto = ""
    
    # Si no hay recomendación o es un error, generar una automáticamente
    if not recomend or _es_error(recomend):
        recomend = _generar_recomendacion_automatica(actividad, puntaje, concepto, observ)
    
    # ── Encabezado: nombre a la izquierda | puntaje a la derecha ───────────
    t_enc = doc.add_table(rows=1, cols=2)
    t_enc.style = "Table Grid"
    t_enc.alignment = WD_TABLE_ALIGNMENT.LEFT
 
    c_nom = t_enc.rows[0].cells[0]
    c_nom.width = Cm(14)
    titulo = f"{num}. {actividad}"
    if control:
        titulo = f"{num}. [{control}]  {actividad}"
    _cell_text(c_nom, titulo, bold=True, color=BLANCO, size=9)
    _set_cell_bg(c_nom, "2E75B6")
    _set_cell_borders(c_nom, "2E75B6")
 
    c_punt = t_enc.rows[0].cells[1]
    c_punt.width = Cm(3)
    _cell_text(c_punt, f"{puntaje}/5  |  {label}", bold=True, color=BLANCO, size=8, align="center")
    _set_cell_bg(c_punt, color_hex)
    _set_cell_borders(c_punt, color_hex)
 
    # ── Cuerpo: filas etiqueta | contenido ─────────────────────────────────
    filas = [
        ("Descripción del control", concepto),
        ("Evidencia encontrada",    evidencia),
        ("Observación / Hallazgo",  observ),
        ("Recomendación",           recomend),  # Siempre incluir recomendación (ya generada si falta)
    ]
    filas = [(e, c) for e, c in filas if c or e == "Recomendación"]  # Mostrar recomendación siempre
 
    if filas:
        t_body = doc.add_table(rows=len(filas), cols=2)
        t_body.style = "Table Grid"
        t_body.alignment = WD_TABLE_ALIGNMENT.LEFT
 
        for r_i, (etiq, contenido) in enumerate(filas):
            row = t_body.rows[r_i].cells
            row[0].width = Cm(4)
            row[1].width = Cm(13)
            _cell_text(row[0], etiq, bold=True, color=AZUL_DARK, size=8)
            _set_cell_bg(row[0], "EBF3FB")
            _set_cell_borders(row[0], "CCCCCC")
            _cell_text(row[1], contenido, size=8)
            _set_cell_borders(row[1], "CCCCCC")
 
    # ── Preguntas pendientes ────────────────────────────────────────────────
    if preguntas:
        p_hdr = doc.add_paragraph()
        p_hdr.paragraph_format.space_before = Pt(4)
        p_hdr.paragraph_format.space_after  = Pt(2)
        r_hdr = p_hdr.add_run("⚠  Preguntas / Requerimientos pendientes:")
        r_hdr.bold = True
        r_hdr.font.size = Pt(8)
        r_hdr.font.name = "Arial"
        r_hdr.font.color.rgb = NARANJA
        for preg in preguntas:
            _add_bullet(doc, preg, size=8)
 
    # separador entre fichas
    doc.add_paragraph()
 
 
# ─── Sección completa por ámbito ─────────────────────────────────────────────
 
def _seccion_ambito(doc: Document, ambito: str, evaluaciones: List[Dict],
                    score: float, num_sec: int):
    """
    Sección de un ámbito:
      A) Cabecera con score
      B) Índice de estándares aplicables (lista numerada)
      C) Detalle control por control (fichas)
    """
    color_hex = _score_color_hex(score)
 
    # Cabecera del ámbito
    _add_heading(doc, f"{num_sec}. {ambito}", level=2)
 
    # Score del ámbito en tabla de 2 celdas
    t_score = doc.add_table(rows=1, cols=2)
    t_score.style = "Table Grid"
    c_lbl, c_val = t_score.rows[0].cells
    c_lbl.width = Cm(9)
    c_val.width = Cm(8)
    _cell_text(c_lbl, f"Score del ámbito: {score:.2f} / 5.0", bold=True, size=10)
    _set_cell_borders(c_lbl, "CCCCCC")
    _cell_text(c_val, _label_semaforo(score), bold=True, color=BLANCO, size=10, align="center")
    _set_cell_bg(c_val, color_hex)
    _set_cell_borders(c_val, color_hex)
    doc.add_paragraph()
 
    # A) Índice de controles
    _indice_controles_ambito(doc, evaluaciones)
 
    _hr(doc, "2E75B6")
    _add_para(doc, "Resultados por control:", bold=True, color=AZUL_DARK, size=10)
    doc.add_paragraph()
 
    # B) Fichas detalladas
    for i, ev in enumerate(evaluaciones, start=1):
        _ficha_control(doc, ev, num=i)
 
 
# ─── FUNCIONES PARA PROCESAR FORMATO JSON ────────────────────────────────────
 
def _portada_desde_json(doc: Document, portada_data: Dict):
    """Genera la portada basada en los datos JSON."""
    doc.add_paragraph()
    doc.add_paragraph()
 
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(portada_data.get("titulo_informe", "INFORME DE RESULTADOS"))
    r.font.size = Pt(24)
    r.font.bold = True
    r.font.color.rgb = AZUL_DARK
    r.font.name = "Arial"
 
    doc.add_paragraph()
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    tipo_val = portada_data.get("tipo_validacion", "VALIDACIÓN METODOLÓGICA")
    desc_modelo = portada_data.get("descripcion_modelo", "")
    r2 = p2.add_run(f"{tipo_val}\n{desc_modelo}")
    r2.font.size = Pt(14)
    r2.font.color.rgb = AZUL_MID
    r2.font.name = "Arial"
 
    doc.add_paragraph()
    doc.add_paragraph()
 
    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ger_prin = portada_data.get("gerencia_principal", "")
    ger_sec = portada_data.get("gerencia_secundaria", "")
    entidad = portada_data.get("entidad", "")
    fecha = portada_data.get("fecha", "")
    r3 = p3.add_run(f"{ger_prin}\n{ger_sec}\n\n{entidad}\n\n{fecha}")
    r3.font.size = Pt(11)
    r3.font.color.rgb = GRIS_TEXT
    r3.font.name = "Arial"
 
    doc.add_page_break()
 
 
def _metadata_desde_json(doc: Document, metadata: Dict):
    """Inserta metadata en el documento."""
    t = doc.add_table(rows=1, cols=2)
    t.style = "Table Grid"
    
    header = t.rows[0].cells
    _cell_text(header[0], "CAMPO", bold=True, color=BLANCO, size=9)
    _set_cell_bg(header[0], "1F3864")
    _cell_text(header[1], "VALOR", bold=True, color=BLANCO, size=9)
    _set_cell_bg(header[1], "1F3864")
 
    for key, value in metadata.items():
        row = t.add_row().cells
        _cell_text(row[0], key.replace("_", " ").title(), bold=True, size=9)
        _set_cell_borders(row[0], "CCCCCC")
        _cell_text(row[1], str(value), size=9)
        _set_cell_borders(row[1], "CCCCCC")
 
    doc.add_paragraph()
 
 
def _resumen_ejecutivo_desde_json(doc: Document, resumen_data: Dict):
    """Inserta el resumen ejecutivo."""
    _add_para(doc, resumen_data.get("texto", ""), size=10, italic=False)
    doc.add_paragraph()
 
 
def _objetivos_desde_json(doc: Document, objetivos_data: Dict):
    """Inserta los objetivos."""
    _add_para(doc, "Objetivo General:", bold=True, color=AZUL_MID, size=10)
    _add_para(doc, objetivos_data.get("objetivo_general", ""), size=9)
    doc.add_paragraph()
 
    _add_para(doc, "Objetivos Específicos:", bold=True, color=AZUL_MID, size=10)
    for obj in objetivos_data.get("objetivos_especificos", []):
        _add_bullet(doc, obj, size=9)
    doc.add_paragraph()
 
 
def _alcance_desde_json(doc: Document, alcance_data: Dict):
    """Inserta el alcance con dimensiones y controles."""
    for dim_info in alcance_data.get("dimensiones", []):
        dimension = dim_info.get("dimension", "")
        controles = dim_info.get("controles", [])
        
        _add_para(doc, dimension, bold=True, color=AZUL_MID, size=10)
        for control in controles:
            _add_bullet(doc, control, size=9)
        doc.add_paragraph()
 
 
def _informacion_relevante_desde_json(doc: Document, info_data: Dict):
    """Inserta información relevante."""
    modelos = info_data.get("modelos", [])
    if modelos:
        _add_para(doc, "Modelos evaluados:", bold=True, color=AZUL_MID, size=10)
        for modelo in modelos:
            txt = f"{modelo.get('nombre_modelo')} (ID: {modelo.get('id_modelo')}) - Tier {modelo.get('tier')} - Estado: {modelo.get('estado')}"
            _add_bullet(doc, txt, size=9)
        doc.add_paragraph()
 
    fechas = info_data.get("fechas_trabajo", {})
    if fechas:
        _add_para(doc, "Fechas de trabajo:", bold=True, color=AZUL_MID, size=10)
        inicio = fechas.get("inicio", "")
        fin = fechas.get("fin", "")
        _add_para(doc, f"Inicio: {inicio} | Fin: {fin}", size=9)
        doc.add_paragraph()
 
    limitaciones = info_data.get("limitaciones", "")
    if limitaciones:
        _add_para(doc, "Limitaciones:", bold=True, color=NARANJA, size=10)
        _add_para(doc, limitaciones, size=9, italic=True)
        doc.add_paragraph()
 
 
def _conclusion_desde_json(doc: Document, conclusion_data: Dict):
    """Inserta la conclusión."""
    texto_base = conclusion_data.get("texto_base", "")
    calificacion = conclusion_data.get("calificacion_final", "")
    comentarios = conclusion_data.get("comentarios", "")
 
    p = doc.add_paragraph()
    r = p.add_run(f"{texto_base} ")
    r.font.size = Pt(10)
    r.font.name = "Arial"
    r_cal = p.add_run(calificacion)
    r_cal.font.size = Pt(10)
    r_cal.font.bold = True
    r_cal.font.color.rgb = AZUL_DARK
    r_cal.font.name = "Arial"
    r_fin = p.add_run(".")
    r_fin.font.size = Pt(10)
 
    if comentarios:
        doc.add_paragraph()
        _add_para(doc, comentarios, size=9, italic=True, color=GRIS_TEXT)
 
    doc.add_paragraph()
 
 
def _hallazgos_desde_json(doc: Document, hallazgos_data: Dict):
    """Inserta hallazgos y recomendaciones."""
    # Fortalezas
    fortalezas = hallazgos_data.get("fortalezas", [])
    if fortalezas:
        _add_para(doc, "Fortalezas identificadas:", bold=True, color=_hex_to_rgb("00B050"), size=10)
        for f in fortalezas:
            _add_bullet(doc, f, size=9)
        doc.add_paragraph()
 
    # Controles exitosos
    exitosos = hallazgos_data.get("controles_exitosos", [])
    if exitosos:
        _add_para(doc, "Controles exitosos:", bold=True, color=_hex_to_rgb("00B050"), size=10)
        for c in exitosos:
            _add_bullet(doc, c, size=9)
        doc.add_paragraph()
 
    # Observaciones
    observaciones = hallazgos_data.get("observaciones", [])
    if observaciones:
        _add_para(doc, "Observaciones identificadas:", bold=True, color=NARANJA, size=10)
        for obs in observaciones:
            cod = obs.get("codigo", "")
            cat = obs.get("categoria", "")
            desc = obs.get("descripcion", "")
            imp = obs.get("impacto", "")
            rec = obs.get("recomendacion", "")
            
            txt = f"[{cod}] {cat} ({imp}): {desc}"
            _add_bullet(doc, txt, size=9)
            if rec:
                _add_para(doc, f"  → {rec}", size=8, italic=True, color=GRIS_TEXT)
        doc.add_paragraph()
 
    # Oportunidades de mejora
    mejoras = hallazgos_data.get("oportunidades_mejora", [])
    if mejoras:
        _add_para(doc, "Oportunidades de mejora:", bold=True, color=AZUL_MID, size=10)
        for mejora in mejoras:
            cod = mejora.get("codigo", "")
            desc = mejora.get("descripcion", "")
            txt = f"[{cod}] {desc}" if cod else desc
            _add_bullet(doc, txt, size=9)
        doc.add_paragraph()
 
 
def _tabla_contenido_desde_json(doc: Document, tabla_data: Dict):
    """Inserta la tabla de contenido."""
    estructura = tabla_data.get("estructura", [])
    _add_para(doc, "Estructura del Informe:", bold=True, color=AZUL_MID, size=10)
    for item in estructura:
        _add_numbered(doc, item, size=9)
    doc.add_paragraph()
 
 
def _informe_detallado_desde_json(doc: Document, informe_data: Dict):
    """Inserta el informe detallado con controles."""
    # Descripción del documento
    desc = informe_data.get("descripcion_documento", {})
    if desc:
        _add_para(doc, "Descripción del Documento:", bold=True, color=AZUL_MID, size=10)
        titulo = desc.get("titulo", "")
        responsables = desc.get("responsables", [])
        revisor = desc.get("revisor", "")
        fecha_aprobacion = desc.get("fecha_aprobacion", "")
        
        if titulo:
            _add_para(doc, f"Título: {titulo}", size=9)
        if responsables:
            _add_para(doc, f"Responsables: {', '.join(responsables)}", size=9)
        if revisor:
            _add_para(doc, f"Revisor: {revisor}", size=9)
        if fecha_aprobacion:
            _add_para(doc, f"Fecha de Aprobación: {fecha_aprobacion}", size=9)
        doc.add_paragraph()
 
    # Glosario
    glosario = informe_data.get("glosario", [])
    if glosario:
        _add_para(doc, "Glosario de Términos:", bold=True, color=AZUL_MID, size=10)
        for term_info in glosario:
            termino = term_info.get("termino", "")
            sigla = term_info.get("sigla", "")
            definicion = term_info.get("definicion", "")
            
            if sigla:
                _add_para(doc, f"{termino} ({sigla}): {definicion}", size=9)
            else:
                _add_para(doc, f"{termino}: {definicion}", size=9)
        doc.add_paragraph()
 
    # Controles
    controles = informe_data.get("controles", [])
    if controles:
        _add_para(doc, "Matriz de Controles:", bold=True, color=AZUL_MID, size=10)
        
        t_controles = doc.add_table(rows=1, cols=6)
        t_controles.style = "Table Grid"
        
        headers = ["Dimensión", "Código", "Nombre Control", "Objetivo", "Resultado", "Observación"]
        for i, h in enumerate(headers):
            c = t_controles.rows[0].cells[i]
            _cell_text(c, h, bold=True, color=BLANCO, size=8, align="center")
            _set_cell_bg(c, "1F3864")
            _set_cell_borders(c, "1F3864")
 
        for ctrl in controles:
            row = t_controles.add_row().cells
            row[0].width = Cm(2.0)
            row[1].width = Cm(1.5)
            row[2].width = Cm(2.5)
            row[3].width = Cm(3.0)
            row[4].width = Cm(2.0)
            row[5].width = Cm(3.5)
            
            dimension = ctrl.get("dimension", "")
            codigo = ctrl.get("codigo", "")
            nombre = ctrl.get("nombre_control", "")
            objetivo = ctrl.get("objetivo", "")
            resultado = ctrl.get("resultado", "")
            observacion = ctrl.get("observacion", "") or ctrl.get("detalle_resultado", "")
 
            _cell_text(row[0], dimension, size=8)
            _set_cell_borders(row[0], "CCCCCC")
            _cell_text(row[1], codigo, size=8)
            _set_cell_borders(row[1], "CCCCCC")
            _cell_text(row[2], nombre, size=8)
            _set_cell_borders(row[2], "CCCCCC")
            _cell_text(row[3], objetivo, size=8)
            _set_cell_borders(row[3], "CCCCCC")
            _cell_text(row[4], resultado, size=8, bold=True, color=AZUL_MID)
            _set_cell_borders(row[4], "CCCCCC")
            _cell_text(row[5], observacion, size=8)
            _set_cell_borders(row[5], "CCCCCC")
        
        doc.add_paragraph()
    
    # Estándares aplicables
    estandares = informe_data.get("estandares_aplicables", [])
    if estandares:
        _add_para(doc, "Estándares Aplicables:", bold=True, color=AZUL_MID, size=10)
        for est in estandares:
            _add_bullet(doc, est, size=9)
        doc.add_paragraph()


# ─── FUNCIÓN PRINCIPAL ────────────────────────────────────────────────────────
 
def generar_word_informe_desde_json(
    formato_data: Dict,
    outputs_dir: Path,
    titulo_modelo: str = None,
) -> Path:
    """
    Genera el informe Word completo basado en el formato JSON estructura.
    
    Args:
        formato_data: Diccionario con la estructura JSON completa
        outputs_dir: Directorio donde guardar el archivo
        titulo_modelo: Título del modelo (opcional, se toma del JSON si no se especifica)
    
    Returns:
        Path: Ruta del archivo generado
    """
 
    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")
    
    if titulo_modelo is None:
        portada = formato_data.get("2_portada", {})
        titulo_modelo = portada.get("descripcion_modelo", "Informe")
    
    nombre = f"VIRF_Informe_{titulo_modelo.replace(' ', '_')}_{fecha_str}.docx"
    ruta = outputs_dir / nombre
 
    doc = Document()
 
    for section in doc.sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin = Cm(3.0)
        section.right_margin = Cm(2.5)
 
    # 1. PORTADA
    portada_data = formato_data.get("2_portada", {})
    _portada_desde_json(doc, portada_data)
 
    # 2. RESUMEN EJECUTIVO
    _add_heading(doc, "Resumen Ejecutivo", level=1)
    resumen_data = formato_data.get("3_resumen_ejecutivo", {})
    _resumen_ejecutivo_desde_json(doc, resumen_data)
    doc.add_page_break()
 
    # 3. OBJETIVOS
    _add_heading(doc, "Objetivos", level=1)
    objetivos_data = formato_data.get("4_objetivos", {})
    _objetivos_desde_json(doc, objetivos_data)
    doc.add_page_break()
 
    # 4. ALCANCE
    _add_heading(doc, "Alcance", level=1)
    alcance_data = formato_data.get("5_alcance", {})
    _alcance_desde_json(doc, alcance_data)
    doc.add_page_break()
 
    # 5. INFORMACIÓN RELEVANTE
    _add_heading(doc, "Información Relevante", level=1)
    info_data = formato_data.get("6_informacion_relevante", {})
    _informacion_relevante_desde_json(doc, info_data)
    doc.add_page_break()
 
    # 6. CONCLUSIÓN
    _add_heading(doc, "Conclusión", level=1)
    conclusion_data = formato_data.get("7_conclusion", {})
    _conclusion_desde_json(doc, conclusion_data)
    doc.add_page_break()
 
    # 7. HALLAZGOS Y RECOMENDACIONES
    _add_heading(doc, "Hallazgos y Recomendaciones", level=1)
    hallazgos_data = formato_data.get("8_hallazgos_y_recomendaciones", {})
    _hallazgos_desde_json(doc, hallazgos_data)
    doc.add_page_break()
 
    # 8. TABLA DE CONTENIDO
    _add_heading(doc, "Tabla de Contenido", level=1)
    tabla_data = formato_data.get("9_tabla_contenido", {})
    _tabla_contenido_desde_json(doc, tabla_data)
    doc.add_page_break()
 
    # 9. INFORME DETALLADO
    _add_heading(doc, "Informe Detallado", level=1)
    informe_data = formato_data.get("10_informe_detallado", {})
    _informe_detallado_desde_json(doc, informe_data)
 
    # ── Guardar ──────────────────────────────────
    outputs_dir.mkdir(parents=True, exist_ok=True)
    doc.save(ruta)
    print(f"  ✓ Word generado: {ruta}")
    return ruta


# ─── FUNCIÓN COMPATIBILIDAD ANTERIOR ──────────────────────────────────────────
 
def generar_word_informe(
    resumen_ejecutivo: str,
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito: Dict[str, float],
    score_global: float,
    titulo_modelo: str,
    tier: str,
    outputs_dir: Path,
) -> Path:
    """
    Genera el informe Word en formato PLANO y legible.
    
    Estructura:
    1. Portada simple (título, modelo, tier, fecha)
    2. Resumen ejecutivo con tabla de scores por ámbito
    3. Detalle jerárquico plano:
       - ÁMBITO
         - Control
           - Actividad
             Concepto de actividad : ev["concepto"]
             Resultado de la actividad: puntaje/5 — etiqueta
             Observaciones         : ev["observacion_tecnica"]
             Oportunidad de mejora : ev["recomendacion"]
    4. Escala de evaluación
    """
 
    now = datetime.now()
    fecha_str = now.strftime("%d%m%Y")
    nombre = f"VIRF_Informe_{titulo_modelo.replace(' ', '_')}_{fecha_str}.docx"
    ruta = outputs_dir / nombre
 
    doc = Document()
 
    for section in doc.sections:
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.5)
        section.left_margin = Cm(3.0)
        section.right_margin = Cm(2.5)
 
    # ══════════════════════════════════════════════
    # PORTADA
    # ══════════════════════════════════════════════
    doc.add_paragraph()
    doc.add_paragraph()
 
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("INFORME DE VALIDACIÓN VIRF")
    r.font.size = Pt(22)
    r.font.bold = True
    r.font.color.rgb = AZUL_DARK
    r.font.name = "Arial"
 
    doc.add_paragraph()
    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r2 = p2.add_run(f"{titulo_modelo}\nTier {tier}")
    r2.font.size = Pt(16)
    r2.font.color.rgb = AZUL_MID
    r2.font.name = "Arial"
 
    doc.add_paragraph()
    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r3 = p3.add_run(
        f"Fecha de emisión: {now.strftime('%d/%m/%Y')}\n"
        "Segunda Línea de Defensa — Validación de Modelos"
    )
    r3.font.size = Pt(11)
    r3.font.italic = True
    r3.font.color.rgb = GRIS_TEXT
    r3.font.name = "Arial"
 
    doc.add_page_break()
 
    # ══════════════════════════════════════════════
    # 1. RESUMEN EJECUTIVO
    # ══════════════════════════════════════════════
    _add_heading(doc, "1. RESUMEN EJECUTIVO", level=1)
    _tabla_scores(doc, scores_por_ambito, score_global)
 
    if resumen_ejecutivo and not resumen_ejecutivo.startswith("[ERROR"):
        for sec in re.split(r"###\s*", resumen_ejecutivo):
            if not sec.strip():
                continue
            lineas = sec.strip().split("\n")
            tit = lineas[0].strip()
            cuerpo = "\n".join(lineas[1:]).strip()
            if tit and cuerpo:
                _add_para(doc, tit, bold=True, color=AZUL_MID, size=11)
                _add_para(doc, cuerpo)
            else:
                _add_para(doc, sec.strip())
    else:
        n_obs = sum(
            len(ev.get("preguntas_faltantes") or ev.get("preguntas_pendientes") or [])
            for evals in evaluaciones_por_ambito.values()
            for ev in evals
        )
        _add_para(
            doc,
            f"El presente informe consolida los resultados de la validación independiente "
            f"del modelo {titulo_modelo} (Tier {tier}). Se evaluaron "
            f"{len(evaluaciones_por_ambito)} ámbitos VIRF. "
            f"Score global ponderado: {score_global:.2f}/5.0 — {_label_semaforo(score_global)}. "
            f"Se identificaron {n_obs} preguntas y requerimientos pendientes de respuesta "
            f"por el equipo modelador.",
        )
 
    doc.add_page_break()
 
    # ══════════════════════════════════════════════
    # SECCIÓN PRINCIPAL: DETALLE PLANO POR ÁMBITO
    # ══════════════════════════════════════════════
    _add_heading(doc, "2. DETALLE DE ACTIVIDADES EVALUADAS", level=1)
    
    for ambito, evals in evaluaciones_por_ambito.items():
        score = scores_por_ambito.get(ambito, 0.0)
        puntaje = _normalizar_score(score)
        
        # Encabezado del ámbito
        _add_ambito_heading(doc, ambito, puntaje)
        
        # Agrupar evaluaciones por control
        controles_dict = {}
        for ev in evals:
            control_name = ev.get("control", "Sin Control")
            if control_name not in controles_dict:
                controles_dict[control_name] = []
            controles_dict[control_name].append(ev)
        
        # Actividades numeradas globalmente dentro del ámbito
        num_global = 0
        for control_name, actividades in controles_dict.items():
            # ── Sub-encabezado de control ─────────────────────────────
            if control_name and control_name != "Sin Control":
                p_ctrl = doc.add_paragraph()
                p_ctrl.paragraph_format.left_indent  = Cm(0)
                p_ctrl.paragraph_format.space_before = Pt(10)
                p_ctrl.paragraph_format.space_after  = Pt(2)
                r_ctrl = p_ctrl.add_run(f"Control: {control_name}")
                r_ctrl.font.size  = Pt(10)
                r_ctrl.font.bold  = True
                r_ctrl.font.italic = True
                r_ctrl.font.color.rgb = AZUL_MID
                r_ctrl.font.name  = "Arial"

            for ev in actividades:
                num_global += 1
                actividad     = ev.get("actividad", f"Actividad {num_global}")
                puntaje_act   = _normalizar_score(ev.get("score", ev.get("puntaje", 50)))
                concepto      = ev.get("concepto", "")
                evidencia     = ev.get("evidencia") or ev.get("evidencia_encontrada") or ""
                observacion   = ev.get("observacion_tecnica") or ev.get("observacion") or ""
                recomendacion = ev.get("recomendacion", "")
                preguntas     = ev.get("preguntas_faltantes") or ev.get("preguntas_pendientes") or []

                if _es_error(concepto):      concepto = ""
                if _es_error(evidencia):     evidencia = ""
                if _es_error(observacion):   observacion = ""
                if _es_error(recomendacion): recomendacion = ""

                if not concepto:
                    concepto = "Pendiente de evaluación — sin documentación disponible."
                if not observacion:
                    if puntaje_act <= 2:
                        observacion = "No cumple con los criterios de validación establecidos para esta actividad."
                    elif puntaje_act == 3:
                        observacion = "Cumplimiento parcial identificado — existen brechas que requieren atención."
                    else:
                        observacion = "No se identificaron observaciones relevantes."
                if not recomendacion or _es_error(recomendacion):
                    recomendacion = _generar_recomendacion_automatica(
                        actividad, puntaje_act, concepto, observacion
                    )

                # ── Título numerado de la actividad ──────────────────────
                p_act = doc.add_paragraph()
                p_act.paragraph_format.left_indent  = Cm(0)
                p_act.paragraph_format.space_before = Pt(14)
                p_act.paragraph_format.space_after  = Pt(3)
                r_act = p_act.add_run(f"{num_global}. {actividad}")
                r_act.font.size  = Pt(11)
                r_act.font.bold  = True
                r_act.font.color.rgb = GRIS_TEXT
                r_act.font.name  = "Arial"

                _hr(doc, "BBBBBB")

                # ── Bloques de campo elaborados ───────────────────────────
                _add_field_block(doc, "Actividad evaluada",    actividad,     indent=0.5)
                _add_field_block(doc, "Concepto de actividad", concepto,      indent=0.5)
                _add_result_line(doc, puntaje_act,                            indent=0.5)
                if evidencia:
                    _add_field_block(doc, "Evidencia encontrada", evidencia,  indent=0.5)
                _add_field_block(doc, "Observación",           observacion,   indent=0.5)
                _add_field_block(doc, "Oportunidad de mejora", recomendacion, indent=0.5)

                # ── Preguntas / requerimientos pendientes ─────────────────
                if preguntas:
                    p_hdr = doc.add_paragraph()
                    p_hdr.paragraph_format.left_indent  = Cm(0.5)
                    p_hdr.paragraph_format.space_before = Pt(6)
                    p_hdr.paragraph_format.space_after  = Pt(2)
                    r_hdr = p_hdr.add_run("⚠  Preguntas / Requerimientos pendientes:")
                    r_hdr.bold = True
                    r_hdr.font.size = Pt(9)
                    r_hdr.font.name = "Arial"
                    r_hdr.font.color.rgb = NARANJA
                    for preg in preguntas:
                        _add_bullet(doc, preg, size=8)

                doc.add_paragraph()

        doc.add_paragraph()
 
    doc.add_page_break()
 
    # ══════════════════════════════════════════════
    # ESCALA DE EVALUACIÓN
    # ══════════════════════════════════════════════
    _add_heading(doc, "3. ESCALA DE EVALUACIÓN", level=1)
 
    criterios = {
        1: "Evidencia ausente o completamente insuficiente",
        2: "Requiere remediación inmediata — observaciones críticas",
        3: "Brechas importantes pero no bloquean el proceso",
        4: "Cumplimiento sustancial con mejoras recomendadas",
        5: "Evidencia sólida, completa y bien documentada",
    }
    t_esc = doc.add_table(rows=1, cols=3)
    t_esc.style = "Table Grid"
    for i, h in enumerate(["PUNTAJE", "ESTADO", "CRITERIO"]):
        c = t_esc.rows[0].cells[i]
        _cell_text(c, h, bold=True, color=BLANCO, size=9, align="center")
        _set_cell_bg(c, "1F3864")
        _set_cell_borders(c, "1F3864")
 
    for puntaje, info in ESCALA_PUNTAJE.items():
        row = t_esc.add_row().cells
        color = info["color"]
        _cell_text(
            row[0],
            str(puntaje),
            bold=True,
            color=BLANCO,
            size=11,
            align="center",
        )
        _set_cell_bg(row[0], color)
        _set_cell_borders(row[0], color)
        _cell_text(
            row[1], info["label"], bold=True, color=BLANCO, size=9, align="center"
        )
        _set_cell_bg(row[1], color)
        _set_cell_borders(row[1], color)
        _cell_text(row[2], criterios.get(puntaje, ""), size=9)
        _set_cell_borders(row[2], "CCCCCC")
 
    # ── Guardar ──────────────────────────────────
    outputs_dir.mkdir(parents=True, exist_ok=True)
    doc.save(ruta)
    print(f"  ✓ Word generado: {ruta}")
    return ruta