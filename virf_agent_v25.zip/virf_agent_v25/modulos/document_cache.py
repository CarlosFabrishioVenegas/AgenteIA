"""
document_cache.py
=================
Sistema de memoria de documentos para modo pre-producción (MODO_PREPRDC).

Propósito
---------
En cada corrida del agente, leer y parsear PDFs, DOCXs y scripts consume tiempo
y en el caso de documentos grandes (PDFs de 50+ páginas) puede tomar varios
segundos por archivo. Si los documentos no cambiaron entre corridas, ese trabajo
es innecesario.

Este módulo implementa un caché persistente en disco:
  - Clave única por archivo: hash SHA-256 del contenido binario.
  - Si el archivo no cambió (mismo hash), se sirve el texto parseado del caché.
  - Si cambió o es nuevo, se parsea normalmente y se actualiza el caché.
  - El caché es exclusivo del modo PREPRDC; en producción se ignora para
    garantizar frescura de datos.

Estructura del caché en disco
------------------------------
  cache/
  ├── document_cache.json     ← índice principal (una entrada por archivo)
  └── .gitkeep

Formato de cada entrada en el JSON:
  {
    "/ruta/absoluta/del/archivo.docx": {
      "hash_sha256":     "abc123...",   ← hash del archivo binario
      "timestamp_fs":    1715000000.0,  ← mtime al momento de cachear
      "timestamp_cache": "2026-05-09T...",
      "nombre":          "archivo.docx",
      "tipo":            "DOCX",
      "contenido":       "texto extraído...",
      "chars_totales":   18400,
      "truncado":        false,
      "hits":            7,             ← cuántas veces se sirvió del caché
      "ultimo_hit":      "2026-05-09T..."
    }
  }

API pública
-----------
  get(path, extractor_fn, max_chars) → dict
  invalidar_archivo(path)
  purgar_huerfanos()
  estadisticas() → dict
  limpiar_todo()
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Optional

logger = logging.getLogger("virf.cache")

# ─── Configuración por defecto ────────────────────────────────────────────────
_CACHE_FILENAME = "document_cache.json"
_ENCODING = "utf-8"

# Máximo tamaño de contenido a cachear por archivo (bytes del texto extraído).
# Archivos mayores a este límite se parsean siempre en fresco para no inflar
# el JSON de caché. Valor: 500 KB de texto (más que suficiente para cualquier doc).
_MAX_CONTENT_BYTES_CACHE = 500_000


# ─── Clase principal ──────────────────────────────────────────────────────────

class DocumentCache:
    """
    Caché persistente de documentos parseados.

    Uso típico
    ----------
        cache = DocumentCache(cache_dir="cache/", enabled=True)
        doc = cache.get(
            path=Path("inputs/doc.pdf"),
            extractor_fn=lambda p: _leer_pdf(p),
            max_chars=8000,
        )
        # doc == {"nombre": ..., "tipo": ..., "contenido": ..., ...}
    """

    def __init__(self, cache_dir: str | Path, enabled: bool = True):
        self.enabled   = enabled
        self.cache_dir = Path(cache_dir)
        self._filepath  = self.cache_dir / _CACHE_FILENAME
        self._data: dict = {}          # ruta_str → entrada
        self._dirty = False            # ¿hay cambios sin persistir?

        # Contadores de sesión (se reinician en cada instancia/corrida)
        self._hits   = 0
        self._misses = 0
        self._errors = 0

        if self.enabled:
            self._cargar()

    # ── Interfaz pública ──────────────────────────────────────────────────────

    def get(
        self,
        path: Path,
        extractor_fn: Callable[[Path], Optional[str]],
        max_chars: int,
    ) -> Optional[dict]:
        """
        Devuelve el dict parseado para *path*.

        1. Si el caché está deshabilitado → extrae en fresco.
        2. Si hay entrada válida (mismo hash SHA-256) → devuelve del caché.
        3. Si no hay entrada o el hash cambió → extrae, guarda, devuelve.

        Parámetros
        ----------
        path:         ruta al archivo a leer.
        extractor_fn: función que recibe Path y retorna str con el texto.
        max_chars:    límite de caracteres a guardar en contenido.

        Retorna
        -------
        dict con claves: nombre, tipo, contenido, chars_totales, truncado
        o None si el archivo no pudo leerse y no hay entrada en caché.
        """
        if not self.enabled:
            return self._extraer_fresco(path, extractor_fn, max_chars)

        ruta_str = str(path.resolve())

        # 1. Calcular hash del archivo actual
        hash_actual = self._hash_archivo(path)
        if hash_actual is None:
            # Archivo no legible → devolver del caché si existe, si no None
            if ruta_str in self._data:
                logger.warning(
                    "⚠ Cache: %s no legible, sirviendo versión cacheada.", path.name
                )
                entrada = self._data[ruta_str]
                self._registrar_hit(ruta_str)
                return self._entrada_a_doc(entrada)
            return None

        # 2. Buscar en caché
        if ruta_str in self._data:
            entrada = self._data[ruta_str]
            if entrada.get("hash_sha256") == hash_actual:
                # ✅ Cache HIT
                self._registrar_hit(ruta_str)
                self._hits += 1
                logger.debug("✅ Cache HIT: %s", path.name)
                return self._entrada_a_doc(entrada)

        # 3. Cache MISS o hash cambiado → extraer fresco
        logger.debug("🔄 Cache MISS: %s (extraer fresco)", path.name)
        self._misses += 1
        doc = self._extraer_fresco(path, extractor_fn, max_chars)
        if doc is not None:
            self._guardar_entrada(ruta_str, hash_actual, path, doc)
        return doc

    def invalidar_archivo(self, path: Path) -> bool:
        """Elimina la entrada de un archivo del caché. Retorna True si existía."""
        ruta_str = str(path.resolve())
        if ruta_str in self._data:
            del self._data[ruta_str]
            self._dirty = True
            logger.info("🗑 Cache: entrada eliminada para %s", path.name)
            return True
        return False

    def purgar_huerfanos(self) -> int:
        """
        Elimina entradas del caché cuyos archivos ya no existen en disco.
        Retorna el número de entradas eliminadas.
        """
        huerfanos = [k for k in self._data if not Path(k).exists()]
        for k in huerfanos:
            del self._data[k]
        if huerfanos:
            self._dirty = True
            logger.info("🧹 Cache: %d entradas huérfanas eliminadas.", len(huerfanos))
        return len(huerfanos)

    def persistir(self) -> None:
        """Guarda el caché en disco si hubo cambios."""
        if not self.enabled or not self._dirty:
            return
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        try:
            with open(self._filepath, "w", encoding=_ENCODING) as f:
                json.dump(self._data, f, ensure_ascii=False, indent=2)
            self._dirty = False
            logger.debug("💾 Cache persistido: %d entradas.", len(self._data))
        except Exception as exc:
            logger.error("❌ Error al persistir caché: %s", exc)

    def estadisticas(self) -> dict:
        """Retorna estadísticas de la sesión actual y del caché acumulado."""
        total_entradas = len(self._data)
        hits_acumulados = sum(e.get("hits", 0) for e in self._data.values())
        archivos_por_tipo: dict = {}
        for e in self._data.values():
            t = e.get("tipo", "?")
            archivos_por_tipo[t] = archivos_por_tipo.get(t, 0) + 1
        return {
            "sesion": {
                "hits":      self._hits,
                "misses":    self._misses,
                "errores":   self._errors,
                "tasa_hit":  round(
                    self._hits / max(self._hits + self._misses, 1) * 100, 1
                ),
            },
            "acumulado": {
                "total_entradas":  total_entradas,
                "hits_historicos": hits_acumulados,
                "por_tipo":        archivos_por_tipo,
            },
            "archivo_cache": str(self._filepath),
        }

    def limpiar_todo(self) -> None:
        """Vacía completamente el caché (disco + memoria)."""
        self._data.clear()
        self._dirty = True
        self.persistir()
        logger.info("🧹 Cache limpiado completamente.")

    def resumen_sesion(self) -> str:
        """Retorna string legible con el resumen de caché de la sesión."""
        s = self.estadisticas()["sesion"]
        total = s["hits"] + s["misses"]
        if total == 0:
            return "  📦 Caché de documentos: no utilizado esta sesión."
        return (
            f"  📦 Caché de documentos:\n"
            f"     ✅ Servidos del caché : {s['hits']:3d} archivos\n"
            f"     🔄 Re-leídos del disco: {s['misses']:3d} archivos\n"
            f"     ⚡ Tasa de acierto    : {s['tasa_hit']}%\n"
            f"     💾 Total en caché     : {self.estadisticas()['acumulado']['total_entradas']} archivos"
        )

    # ── Métodos internos ──────────────────────────────────────────────────────

    def _cargar(self) -> None:
        """Carga el JSON de caché desde disco."""
        if not self._filepath.exists():
            self._data = {}
            return
        try:
            with open(self._filepath, encoding=_ENCODING) as f:
                self._data = json.load(f)
            logger.debug(
                "📂 Cache cargado: %d entradas desde %s",
                len(self._data), self._filepath,
            )
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning(
                "⚠ Cache corrupto o ilegible (%s). Se inicia vacío.", exc
            )
            self._data = {}

    @staticmethod
    def _hash_archivo(path: Path) -> Optional[str]:
        """SHA-256 del contenido binario del archivo. None si no se puede leer."""
        try:
            h = hashlib.sha256()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(65536), b""):
                    h.update(chunk)
            return h.hexdigest()
        except OSError:
            return None

    @staticmethod
    def _extraer_fresco(
        path: Path,
        extractor_fn: Callable[[Path], Optional[str]],
        max_chars: int,
    ) -> Optional[dict]:
        """Llama a extractor_fn y construye el dict de documento."""
        try:
            contenido = extractor_fn(path) or ""
            chars_totales = len(contenido)
            contenido_truncado = contenido[:max_chars]
            return {
                "nombre":        path.name,
                "tipo":          path.suffix.lstrip(".").upper(),
                "contenido":     contenido_truncado,
                "chars_totales": chars_totales,
                "truncado":      chars_totales > max_chars,
            }
        except Exception as exc:
            logger.error("❌ Error extrayendo %s: %s", path.name, exc)
            return None

    def _guardar_entrada(
        self,
        ruta_str: str,
        hash_sha256: str,
        path: Path,
        doc: dict,
    ) -> None:
        """Persiste una entrada nueva o actualizada en el índice."""
        # No cachear contenidos demasiado grandes
        if len(doc.get("contenido", "")) > _MAX_CONTENT_BYTES_CACHE:
            logger.debug(
                "⏭ Cache: %s omitido por tamaño (>%d KB)",
                path.name, _MAX_CONTENT_BYTES_CACHE // 1000,
            )
            return

        try:
            ts = path.stat().st_mtime
        except OSError:
            ts = 0.0

        entrada_existente = self._data.get(ruta_str, {})
        self._data[ruta_str] = {
            "hash_sha256":      hash_sha256,
            "timestamp_fs":     ts,
            "timestamp_cache":  datetime.now(timezone.utc).isoformat(),
            "nombre":           doc["nombre"],
            "tipo":             doc["tipo"],
            "contenido":        doc["contenido"],
            "chars_totales":    doc["chars_totales"],
            "truncado":         doc["truncado"],
            "hits":             entrada_existente.get("hits", 0),  # conservar hits previos
            "ultimo_hit":       entrada_existente.get("ultimo_hit", None),
        }
        self._dirty = True

    def _registrar_hit(self, ruta_str: str) -> None:
        """Incrementa el contador de hits de una entrada."""
        if ruta_str in self._data:
            self._data[ruta_str]["hits"] = self._data[ruta_str].get("hits", 0) + 1
            self._data[ruta_str]["ultimo_hit"] = datetime.now(timezone.utc).isoformat()
            self._dirty = True

    @staticmethod
    def _entrada_a_doc(entrada: dict) -> dict:
        """Convierte una entrada del índice al formato dict de documento."""
        return {
            "nombre":        entrada["nombre"],
            "tipo":          entrada["tipo"],
            "contenido":     entrada["contenido"],
            "chars_totales": entrada["chars_totales"],
            "truncado":      entrada["truncado"],
        }


# ─── Instancia global (singleton por proceso) ─────────────────────────────────

_instancia_global: Optional[DocumentCache] = None


def inicializar_cache(cache_dir: str | Path, enabled: bool = True) -> DocumentCache:
    """
    Inicializa (o reinicializa) la instancia global del caché.
    Llamar una vez al inicio del pipeline, antes de cualquier lectura.

    Parámetros
    ----------
    cache_dir: directorio donde se guarda document_cache.json
    enabled:   False = caché deshabilitado (modo producción)
    """
    global _instancia_global
    _instancia_global = DocumentCache(cache_dir=cache_dir, enabled=enabled)
    return _instancia_global


def get_cache() -> DocumentCache:
    """
    Retorna la instancia global. Si no fue inicializada, crea una deshabilitada
    para no romper el flujo si el caché no fue explícitamente activado.
    """
    global _instancia_global
    if _instancia_global is None:
        logger.warning(
            "⚠ DocumentCache: get_cache() llamado sin inicializar. "
            "Usando caché deshabilitado."
        )
        _instancia_global = DocumentCache(cache_dir="cache/", enabled=False)
    return _instancia_global


def cerrar_cache() -> None:
    """
    Persiste el caché e imprime el resumen de sesión.
    Llamar al final del pipeline (en el bloque finally de agente.py).
    """
    global _instancia_global
    if _instancia_global is not None and _instancia_global.enabled:
        _instancia_global.persistir()
        print(_instancia_global.resumen_sesion())
