"""
chunker.py  [v20]
=================
Servicio de chunking inteligente para documentos largos.

PROBLEMA QUE RESUELVE (v18 → v20)
-----------------------------------
En v18/v19, `_chunked_summary()` vivía dentro de `Mx_01_LecturaEvidencias.py`
(capa de infraestructura de lectura) y llamaba internamente a `get_cliente_ia()`
(capa de IA). Esto violaba el principio de separación de capas:
  - Si la API fallaba durante la lectura, el error era capturado silenciosamente
  - No había control de rate limiting desde un punto centralizado
  - No se podía mostrar progreso al usuario ("segmento 7/11")
  - El pre-flight de API key no protegía el chunking

DISEÑO v20
----------
  - `ChunkerService` recibe el cliente IA ya inicializado (inyección de dependencia)
  - `Mx_01_LecturaEvidencias.leer_archivo()` devuelve texto crudo sin llamadas IA
  - `agente.py` instancia `ChunkerService(cliente)` y llama `procesar_lote()` 
    justo después de leer todos los archivos
  - Un único punto de control para rate limiting, MAX_CHUNKS y progreso

API pública
-----------
  ChunkerService(cliente_ia, chunk_size, chunk_overlap, chunk_threshold, max_chunks)
  .procesar_doc(doc_dict) → doc_dict enriquecido con cobertura_pct, fue_resumido…
  .procesar_lote(docs)    → list de docs procesados
"""

from __future__ import annotations

import logging
import os
from typing import Dict, List, Optional

logger = logging.getLogger("virf.chunker")

# ── Defaults desde entorno (mismos nombres que v18 para retrocompatibilidad) ──
_CHUNK_SIZE      = int(os.getenv("VIRF_CHUNK_SIZE",      "12000"))
_CHUNK_OVERLAP   = int(os.getenv("VIRF_CHUNK_OVERLAP",     "800"))
_CHUNK_THRESHOLD = int(os.getenv("VIRF_CHUNK_THRESHOLD", str(_CHUNK_SIZE)))
_MAX_CHUNKS      = int(os.getenv("VIRF_MAX_CHUNKS",        "25"))   # [v20] nuevo

# Prompt de extracción orientado a auditoría financiera
_PROMPT_EXTRACCION = """\
Eres un extractor de información para auditoría de modelos financieros.
Documento: '{nombre}' (tipo: {tipo}) — Segmento {i}/{n}

Extrae TODA la información relevante para validación de modelos:
  • Metodología y supuestos del modelo
  • Tests estadísticos (Kupiec, Christoffersen, López, etc.)
  • Calidad de datos (missing values, outliers, fuentes)
  • Gobierno (actas, aprobaciones, tiering, inventario)
  • Implementación (coherencia manual vs código)
  • Seguimiento y backtesting
  • Cualquier cifra, fecha, p-value o conclusión relevante

NO omitas información cuantitativa. Sé exhaustivo y denso.

SEGMENTO:
{chunk}

Responde en español con un resumen estructurado.\
"""


class ChunkerService:
    """
    Servicio de chunking inteligente con inyección de cliente IA.

    Parámetros
    ----------
    cliente_ia:       instancia de ClienteIA ya inicializada (de config.py)
    chunk_size:       chars por segmento (default: VIRF_CHUNK_SIZE)
    chunk_overlap:    solapamiento entre segmentos (default: VIRF_CHUNK_OVERLAP)
    chunk_threshold:  documentos más cortos no se chunkean (default: VIRF_CHUNK_THRESHOLD)
    max_chunks:       máximo de chunks por documento (default: VIRF_MAX_CHUNKS)
    """

    def __init__(
        self,
        cliente_ia,
        chunk_size:      int = _CHUNK_SIZE,
        chunk_overlap:   int = _CHUNK_OVERLAP,
        chunk_threshold: int = _CHUNK_THRESHOLD,
        max_chunks:      int = _MAX_CHUNKS,
    ):
        self.cliente        = cliente_ia
        self.chunk_size     = chunk_size
        self.chunk_overlap  = chunk_overlap
        self.chunk_threshold = chunk_threshold
        self.max_chunks     = max_chunks

        # Contadores de sesión
        self._docs_chunkeados  = 0
        self._docs_directos    = 0
        self._docs_truncados   = 0
        self._chunks_totales   = 0

    # ── Interfaz pública ──────────────────────────────────────────────────────

    def procesar_doc(self, doc: Dict) -> Dict:
        """
        Procesa un dict de documento devuelto por `leer_archivo()`.

        Si el contenido supera `chunk_threshold`, lo divide en segmentos,
        llama a la IA para resumir cada uno y consolida el resultado.

        El doc original NO se muta; se devuelve una copia enriquecida.

        Campos añadidos al dict:
          cobertura_pct (float):  0-100, porcentaje del texto original leído
          fue_resumido  (bool):   True si se usó IA para resumir
          n_chunks      (int):    segmentos procesados
          fue_truncado_fc (bool): True si chunking falló y se truncó como fallback
        """
        doc = dict(doc)  # copia para no mutar el original
        texto  = doc.get("contenido", "") or ""
        nombre = doc.get("nombre", "documento")
        tipo   = doc.get("tipo",   "DOC")
        chars  = doc.get("chars_totales", len(texto))

        # Documentos cortos → ruta directa, sin overhead
        if chars <= self.chunk_threshold:
            doc["cobertura_pct"]   = 100.0
            doc["fue_resumido"]    = False
            doc["n_chunks"]        = 1
            doc["fue_truncado_fc"] = False
            self._docs_directos += 1
            return doc

        # Calcular segmentos
        chunks = self._dividir_en_chunks(texto)
        n_chunks_real = len(chunks)

        # [v20] Avisar si se supera MAX_CHUNKS y truncar el lote de chunks
        if n_chunks_real > self.max_chunks:
            logger.warning(
                "⚠ Chunker: '%s' requiere %d segmentos (máx=%d). "
                "Se procesarán los primeros %d. "
                "Aumenta VIRF_MAX_CHUNKS en .env para cobertura completa.",
                nombre, n_chunks_real, self.max_chunks, self.max_chunks,
            )
            print(
                f"\n  ⚠️  AVISO CHUNKING: '{nombre}' tiene {n_chunks_real} segmentos "
                f"(límite: {self.max_chunks}). Se procesarán los primeros {self.max_chunks}.\n"
                f"     Para cobertura total, ajusta VIRF_MAX_CHUNKS={n_chunks_real} en .env\n"
            )
            chunks = chunks[:self.max_chunks]

        n_proc = len(chunks)

        # Intentar resumir con IA
        try:
            resumenes: List[str] = []
            for i, chunk in enumerate(chunks, 1):
                print(
                    f"    📄 Chunking '{nombre}': segmento {i}/{n_proc}...",
                    end="\r", flush=True,
                )
                prompt = _PROMPT_EXTRACCION.format(
                    nombre=nombre, tipo=tipo, i=i, n=n_proc, chunk=chunk
                )
                resumen = self.cliente.generar_mensaje(
                    prompt=prompt,
                    max_tokens=1500,
                )
                resumenes.append(f"[Segmento {i}/{n_proc}]\n{resumen}")

            cobertura = round(n_proc / n_chunks_real * 100, 1)
            contenido_final = (
                f"⚠️ DOCUMENTO LARGO — '{nombre}' ({chars:,} chars totales)\n"
                f"Procesado en {n_proc} segmentos (cobertura {cobertura}%).\n\n"
                + "\n\n".join(resumenes)
            )
            print(f"    ✅ '{nombre}': {n_proc} segmentos procesados ({cobertura}% cobertura)")

            doc["contenido"]       = contenido_final
            doc["cobertura_pct"]   = cobertura
            doc["fue_resumido"]    = True
            doc["n_chunks"]        = n_proc
            doc["fue_truncado_fc"] = False

            self._docs_chunkeados += 1
            self._chunks_totales  += n_proc
            return doc

        except Exception as exc:
            # Fallback: truncar con aviso visible
            logger.error("❌ Chunker: error procesando '%s': %s", nombre, exc)
            leido   = min(chars, self.chunk_size * 2)
            pct     = round(leido / chars * 100, 1)
            tipo_err = "RATE LIMIT" if "rate" in str(exc).lower() else \
                       "AUTH ERROR" if "401" in str(exc) else "ERROR API"
            aviso = (
                f"\n\n⚠️ DOCUMENTO TRUNCADO ({tipo_err}) — '{nombre}': "
                f"{chars:,} chars totales, se leyeron {leido:,} ({pct}%). "
                f"Para cobertura completa verificar API key o aumentar VIRF_MAX_CHUNKS."
            )
            doc["contenido"]       = texto[:leido] + aviso
            doc["cobertura_pct"]   = pct
            doc["fue_resumido"]    = False
            doc["n_chunks"]        = n_proc
            doc["fue_truncado_fc"] = True

            self._docs_truncados += 1
            return doc

    def procesar_lote(
        self,
        docs: List[Dict],
        verbose: bool = True,
    ) -> List[Dict]:
        """
        Procesa una lista de documentos, aplicando chunking donde sea necesario.

        Solo procesa documentos con `chars_totales > chunk_threshold`.
        Los demás pasan sin modificación (salvo añadir los campos de cobertura).

        Parámetros
        ----------
        docs:    lista de dicts de documentos (output de leer_archivo)
        verbose: imprimir resumen al finalizar

        Retorna
        -------
        Lista de docs con campos cobertura_pct, fue_resumido, n_chunks añadidos.
        """
        resultado: List[Dict] = []
        docs_largos = [d for d in docs if d and (d.get("chars_totales", 0) > self.chunk_threshold)]
        docs_cortos = [d for d in docs if d and (d.get("chars_totales", 0) <= self.chunk_threshold)]

        if docs_largos and verbose:
            print(
                f"\n  📚 Chunking: {len(docs_largos)} documento(s) largo(s) "
                f"de {len(docs)} total. Procesando...\n"
            )

        for doc in docs_largos:
            resultado.append(self.procesar_doc(doc))

        # Documentos cortos: pasar con campos de cobertura por consistencia
        for doc in docs_cortos:
            if doc:
                doc = dict(doc)
                doc.setdefault("cobertura_pct",   100.0)
                doc.setdefault("fue_resumido",     False)
                doc.setdefault("n_chunks",         1)
                doc.setdefault("fue_truncado_fc",  False)
                resultado.append(doc)

        if verbose and (docs_largos or docs_cortos):
            print(self.resumen_sesion())

        return resultado

    def resumen_sesion(self) -> str:
        """Retorna string legible con estadísticas de la sesión de chunking."""
        if self._docs_chunkeados + self._docs_truncados == 0:
            return "  📚 Chunker: sin documentos largos esta sesión."
        return (
            f"  📚 Chunker:\n"
            f"     ✅ Resumidos con IA : {self._docs_chunkeados} docs "
            f"({self._chunks_totales} segmentos totales)\n"
            f"     ⚠️  Truncados (error): {self._docs_truncados} docs\n"
            f"     ⚡ Sin chunking      : {self._docs_directos} docs (cortos)"
        )

    # ── Métodos internos ──────────────────────────────────────────────────────

    def _dividir_en_chunks(self, texto: str) -> List[str]:
        """Divide texto en segmentos solapados de chunk_size chars."""
        chunks: List[str] = []
        inicio = 0
        while inicio < len(texto):
            fin = min(inicio + self.chunk_size, len(texto))
            chunks.append(texto[inicio:fin])
            if fin == len(texto):
                break
            inicio += self.chunk_size - self.chunk_overlap
        return chunks
