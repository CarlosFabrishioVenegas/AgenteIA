"""
modulos/motor_ia.py
====================
Orquestador principal del agente VIRF.
Financial Controller / Model Risk Validator — LaR, VaR, IFRS 9.

Este módulo contiene la lógica de negocio (scoring 1-5, semáforo,
resumen ejecutivo) y delega en los módulos Mx_* para la infraestructura:

    Infraestructura (motor/):
        Mx_00  →  configuración, rutas, constantes, rol del agente
        Mx_01  →  lectura de archivos (PDF, DOCX, PY, XLSX, ...)
        Mx_02  →  construcción de prompts
        Mx_03  →  llamadas a la API de Anthropic
        Mx_04  →  controles de datos (crece cada semana)

    Lógica de negocio (este archivo):
        evaluar_actividad()         →  evalúa 1 actividad → puntaje 1-5
        evaluar_ambito_completo()   →  itera actividades de un ámbito
        generar_resumen_ejecutivo() →  narrativa final del informe
        calcular_score_ambito()     →  promedio de puntajes
        calcular_score_global()     →  score ponderado por ámbito
        get_semaforo()              →  label y color según score
"""

import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

# ── Resolver ruta a motor/ para importar los Mx_* ────────────────────────────
_MODULOS_DIR = Path(__file__).parent.resolve()      # .../virf_agent_clean/modulos/
_ROOT_DIR    = _MODULOS_DIR.parent.resolve()         # .../virf_agent_clean/
_MOTOR_DIR   = _ROOT_DIR / "motor"                   # .../virf_agent_clean/motor/

for _p in [str(_MOTOR_DIR), str(_ROOT_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ── Importar infraestructura desde los Mx ────────────────────────────────────

# Mx_00 — configuración centralizada del motor
from Mx_00_CargaRutas import (
    ROL_AGENTE,
    RUTAS,
    AMBITO_A_INPUTS,
    INSTRUCCIONES_DIMENSION,
    UMBRAL_RIESGO_GLOBAL,
    MODO_PREPRDC,
    MODO_PRDC,
)

# Mx_01 — lectura de archivos y evidencias
from Mx_01_LecturaEvidencias import (
    leer_carpeta,
    leer_repositorio_informes,
    leer_estandares_virf,
    cargar_todos_inputs,
    inputs_para_dimension,
)

# Mx_03 — llamada HTTP a la API (lógica de transporte)
from Mx_03_LlamarIA import (
    _llamar_modelo,       # llamada raw → retorna texto
    _parsear_json,        # limpia y parsea JSON de la respuesta
    aprender_estilo,      # aprende lenguaje de informes de referencia
    generar_replica_virf, # genera _replica_virf.py cuando no existe
    generar_sintesis,     # síntesis ejecutiva y dictamen global
)

# Mx_04 — controles de datos (se amplía cada semana)
from Mx_04_MotorControlesData import (
    detectar_cuestionamientos,
    tiene_replica_virf,
    calcular_riesgo_global,
    resumen_cuestionamientos_consola,
)

# ── Config de negocio (desde config.py de la raíz) ───────────────────────────
from config import (
    ESCALA_PUNTAJE,
    SCORE_SEMAFORO,
    AMBITO_PESOS,
    PREGUNTAS_METODOLOGICAS,
)
from modulos.feedback import construir_contexto_feedback
from modulos.feedback_mejorado import (
    construir_bloque_aprendizaje,
    obtener_recomendaciones_evaluacion,
)


# ══════════════════════════════════════════════════════════════════════════════
# EVALUACIÓN DE ACTIVIDADES — lógica de negocio con scoring 1-5
# ══════════════════════════════════════════════════════════════════════════════

def evaluar_actividad(
    actividad:        str,
    ambito:           str,
    control:          str,
    contexto:         str,
    titulo_modelo:    str,
    modo_preprdc:     bool = True,
    contexto_ambito:  Optional[List[Dict]] = None,  # [NEW-MEM] hallazgos previos del mismo ámbito
) -> Dict:
    """
    Evalúa una actividad específica del estándar VIRF.

    [FIX-BIAS] Incorpora calibración anti-sesgo basada en feedback histórico:
      - Detecta si el agente subestima/sobrestima para este ámbito
      - Añade instrucción explícita de corrección al prompt
      - Incluye ejemplos few-shot calibrados

    [FIX-COV] Reporta cobertura_contexto: fracción del contexto disponible
      que fue efectivamente incluida en el prompt.

    [NEW-MEM] Recibe hallazgos previos del mismo ámbito como contexto acumulado,
      permitiendo razonamiento encadenado y detección de inconsistencias cruzadas.

    Returns:
        {
          puntaje:             int (1-5),
          concepto:            str,
          observacion:         str,
          evidencia_encontrada:str,
          preguntas_pendientes:list[str],
          recomendacion:       str,
          cobertura_contexto:  float,   # [NEW] 0.0-1.0
          ajuste_sesgo:        str,     # [NEW] descripción del ajuste aplicado
        }
    """
    from modulos.feedback_mejorado import ajustar_puntaje_por_feedback

    preguntas_guia     = PREGUNTAS_METODOLOGICAS.get(ambito, [])
    contexto_feedback  = construir_contexto_feedback(ambito, actividad)
    bloque_aprendizaje = construir_bloque_aprendizaje(ambito)
    instruccion_dim    = INSTRUCCIONES_DIMENSION.get(ambito, "")

    # ── [v18] MAX_CTX: sincronizado con configuración central, no hardcodeado ──
    # Lee de env VIRF_MAX_CTX → fallback a MAX_CHARS_DOC (Mx_00) → fallback 15000
    import os as _os_mia
    try:
        from Mx_00_CargaRutas import MAX_CHARS_DOC as _MAX_CHARS_DOC_MX
    except ImportError:
        _MAX_CHARS_DOC_MX = 15000
    MAX_CTX = int(_os_mia.getenv("VIRF_MAX_CTX", str(_MAX_CHARS_DOC_MX)))

    ctx_total    = len(contexto) if contexto else 0
    ctx_incluido = min(ctx_total, MAX_CTX)
    cobertura    = round(ctx_incluido / ctx_total, 3) if ctx_total > 0 else 0.0

    # Detectar si el contexto ya viene con aviso de chunking (v18)
    _fue_chunkeado   = contexto and "Procesado en" in contexto and "segmentos" in contexto
    _fue_truncado_fc = contexto and "DOCUMENTO TRUNCADO" in contexto

    bloque_cobertura = ""
    if _fue_chunkeado:
        # El chunking leyó el documento completo → decirle al agente que tiene cobertura total
        bloque_cobertura = (
            "\nNOTA DE COBERTURA: Los documentos fueron procesados en múltiples segmentos "
            "para garantizar cobertura completa (100%). El resumen de cada segmento está "
            "incluido arriba. Evalúa considerando TODA la información presente."
        )
    elif _fue_truncado_fc:
        # Chunking intentado pero API no disponible → cobertura parcial
        bloque_cobertura = (
            "\n⚠️  COBERTURA PARCIAL: Uno o más documentos fueron truncados por limitación "
            "técnica. Indica en tu observación qué información adicional solicitarías al "
            "modelador para completar la evaluación. No penalices con 1 si hay evidencia "
            "parcial — expresa incertidumbre en cambio."
        )
    elif ctx_total > MAX_CTX:
        # Sin chunking y contexto supera MAX_CTX → aviso clásico
        bloque_cobertura = (
            f"\n⚠️  ADVERTENCIA DE COBERTURA: Se incluyeron {ctx_incluido:,} de {ctx_total:,} "
            f"chars ({cobertura*100:.0f}%). Si no encuentras evidencia de un requisito, "
            "NO penalices con 1 automáticamente — podría estar en la parte no incluida. "
            "Expresa incertidumbre en tu observación."
        )

    # ── [FIX-BIAS] Bloque de corrección de sesgo ──────────────────────────────
    bloque_antisesgo = _construir_bloque_antisesgo(ambito)

    # ── [NEW-MEM] Bloque de memoria intra-ámbito ──────────────────────────────
    bloque_memoria = ""
    if contexto_ambito:
        resumen_previos = []
        for prev in contexto_ambito[-4:]:  # máx últimos 4 para no inflar el prompt
            resumen_previos.append(
                f"  • [{prev.get('puntaje','?')}/5] {prev.get('actividad','')[:60]}: "
                f"{prev.get('observacion','')[:100]}"
            )
        bloque_memoria = (
            "\nHALLAZGOS PREVIOS EN ESTE ÁMBITO (para coherencia y detección de inconsistencias):\n"
            + "\n".join(resumen_previos)
            + "\n→ Si detectas contradicciones con lo anterior, indícalo explícitamente."
        )

    # ── Bloques opcionales ────────────────────────────────────────────────────
    bloque_feedback = (
        f"\nAPRENDIZAJE DE CORRIDAS ANTERIORES:\n{contexto_feedback}"
        if contexto_feedback else ""
    )
    bloque_aprendizaje_prompt = f"\n{bloque_aprendizaje}" if bloque_aprendizaje else ""
    bloque_modo = (
        "MODO: PRE-PRODUCCIÓN — proporciona evaluación detallada con puntaje, "
        "concepto técnico y observaciones."
        if modo_preprdc else
        "MODO: PRODUCCIÓN — proporciona evaluación final consolidada."
    )

    prompt = f"""
MODELO BAJO VALIDACIÓN: {titulo_modelo}
ÁMBITO: {ambito}
CONTROL/CRITERIO: {control}
ACTIVIDAD A EVALUAR: {actividad}

INSTRUCCIONES ESPECÍFICAS PARA ESTE ÁMBITO:
{instruccion_dim}

CONTEXTO DISPONIBLE (extractos de documentos, scripts y datos provistos):
{contexto[:MAX_CTX] if contexto else "SIN CONTEXTO — No se encontraron archivos relevantes para este ámbito."}
{bloque_cobertura}

PREGUNTAS GUÍA PARA ESTE ÁMBITO:
{chr(10).join(f"- {p}" for p in preguntas_guia)}
{bloque_memoria}
{bloque_feedback}
{bloque_aprendizaje_prompt}
{bloque_antisesgo}

{bloque_modo}

ESCALA DE EVALUACIÓN (1-5) — EJEMPLOS CALIBRADOS:
1 = No cumple — evidencia COMPLETAMENTE AUSENTE (ningún documento menciona el tema)
    Ejemplo: se pide backtesting y no existe ningún script, log ni mención en manuales.
2 = Cumple parcialmente — hay mención o intento pero con brechas críticas
    Ejemplo: existe script de backtesting pero no se ejecutó con datos reales o falta Kupiec.
3 = Cumple parcialmente — implementado pero con brechas no críticas
    Ejemplo: backtesting presente con Kupiec, falta Christoffersen pero el análisis es coherente.
4 = Cumple con observaciones menores — implementación sólida con mejoras recomendables
    Ejemplo: backtesting completo con Kupiec+Christoffersen, documentado. Falta análisis de López.
5 = Cumple plenamente — evidencia sólida, completa y bien documentada
    Ejemplo: todos los tests, documentados, justificados, con conclusiones claras.

REGLA CLAVE: Distingue entre "evidencia ausente en el contexto" y "requisito incumplido".
Si la cobertura es parcial, expresa incertidumbre en lugar de penalizar con 1 directamente.

Evalúa esta actividad y responde ÚNICAMENTE con este JSON (sin markdown):
{{
  "puntaje": <entero 1-5>,
  "concepto": "<qué evalúa técnicamente esta actividad y su importancia — 1-2 oraciones>",
  "observacion": "<hallazgo: qué se encontró, qué falta, riesgos. Señala si hay incertidumbre por cobertura parcial. Mínimo 2 oraciones.>",
  "evidencia_encontrada": "<documentos o secciones relevantes hallados, o 'No se encontró evidencia en el contexto disponible'>",
  "preguntas_pendientes": ["<pregunta específica al modelador si falta información>"],
  "recomendacion": "<acción concreta para subsanar brechas, si aplica>"
}}"""

    try:
        raw = _llamar_modelo(prompt)
        raw = re.sub(r"^```json\s*", "", raw)
        raw = re.sub(r"```$", "", raw).strip()
        resultado = json.loads(raw)

        # Clampar puntaje al rango válido
        puntaje_raw = max(1, min(5, int(resultado.get("puntaje", 1))))

        # [FIX-BIAS] Aplicar ajuste post-hoc por feedback histórico similar
        puntaje_ajustado, desc_ajuste = ajustar_puntaje_por_feedback(
            ambito, actividad, float(puntaje_raw)
        )
        puntaje_final = max(1, min(5, round(puntaje_ajustado)))

        resultado["puntaje"]            = puntaje_final
        resultado["cobertura_contexto"] = cobertura
        resultado["ajuste_sesgo"]       = desc_ajuste
        return resultado

    except json.JSONDecodeError as e:
        return {
            "puntaje": 2,  # [FIX-BIAS] Default conservador (no 1) ante error de parseo
            "concepto": f"Error al parsear respuesta: {e}",
            "observacion": f"Respuesta bruta: {raw[:300] if 'raw' in locals() else 'N/A'}",
            "evidencia_encontrada": "N/A",
            "preguntas_pendientes": ["Revisar manualmente esta actividad"],
            "recomendacion": "Reejecutar el agente con más contexto",
            "cobertura_contexto": cobertura,
            "ajuste_sesgo": "Error — sin ajuste",
        }
    except Exception as e:
        return {
            "puntaje": 2,  # [FIX-BIAS] Default conservador
            "concepto": "Error en evaluación",
            "observacion": str(e),
            "evidencia_encontrada": "N/A",
            "preguntas_pendientes": [],
            "recomendacion": "Verificar API key y conectividad",
            "cobertura_contexto": cobertura,
            "ajuste_sesgo": "Error — sin ajuste",
        }


def _construir_bloque_antisesgo(ambito: str) -> str:
    """
    [FIX-BIAS] Construye un bloque de instrucción en el prompt que corrige
    el sesgo de subestimación detectado en el historial de feedback.

    Si el MAE histórico para este ámbito es ≥1.0 en dirección "subestima",
    añade instrucción explícita para evitar penalizar con 1 sin evidencia
    clara de incumplimiento.
    """
    try:
        from modulos.feedback_mejorado import analizar_patron_errores
        patron = analizar_patron_errores(ambito)
    except Exception:
        return ""

    tendencia = patron.get("tendencia", "equilibrado")
    mae       = patron.get("error_abs_promedio", 0)
    n         = len(patron.get("ejemplos", []))

    if mae < 1.0 or tendencia == "equilibrado":
        return ""  # Sin sesgo significativo detectado

    if tendencia == "subestima":
        return (
            f"\n⚠️  CALIBRACIÓN DE SESGO (basada en {n} evaluaciones anteriores):\n"
            f"  Tu tendencia en este ámbito es SUBESTIMAR (error promedio: +{mae:.1f} puntos).\n"
            "  CORRECCIÓN REQUERIDA:\n"
            "  - Si hay evidencia PARCIAL o IMPLÍCITA → evalúa si merece 2 o 3, no automáticamente 1.\n"
            "  - Reconoce implementaciones en proceso como cumplimiento parcial (puntaje 2-3).\n"
            "  - Reserva el puntaje 1 SOLO para ausencia TOTAL de evidencia o intención.\n"
            "  - Si hay duda entre 1 y 2, elige 2. Si hay duda entre 2 y 3, evalúa si el\n"
            "    esfuerzo documental es serio aunque incompleto.\n"
        )
    elif tendencia == "sobrestima":
        return (
            f"\n⚠️  CALIBRACIÓN DE SESGO (basada en {n} evaluaciones anteriores):\n"
            f"  Tu tendencia en este ámbito es SOBRESTIMAR (error promedio: -{mae:.1f} puntos).\n"
            "  CORRECCIÓN REQUERIDA:\n"
            "  - Verifica que la evidencia sea explícita y suficiente antes de dar 4 o 5.\n"
            "  - Mencionar un concepto sin evidencia documental concreta no es cumplimiento.\n"
            "  - Sé más exigente: pide documentos específicos, no solo intenciones.\n"
        )
    return ""


def evaluar_ambito_completo(
    ambito:          str,
    actividades:     List[Dict],
    contexto:        str,
    titulo_modelo:   str,
    modo_preprdc:    bool = True,
    contexto_global: Optional[List[Dict]] = None,  # [v18] memoria inter-ámbito
) -> List[Dict]:
    """
    Evalúa todas las actividades requeridas de un ámbito.

    [v17-MEM] Acumula hallazgos previos DENTRO del ámbito y los pasa a cada
    nueva actividad, permitiendo detectar inconsistencias cruzadas.

    [v18-GLOB] Recibe hallazgos de OTROS ámbitos ya evaluados (contexto_global).
    Permite detectar contradicciones entre ámbitos: ej. Documentación dice VaR
    Histórico y Metodología detecta VaR Paramétrico.

    Args:
        ambito:          nombre del ámbito VIRF
        actividades:     lista de dicts con claves: actividad, control, requerida
        contexto:        texto concatenado de los documentos relevantes
        titulo_modelo:   nombre del modelo bajo validación
        modo_preprdc:    True = preprdc, False = prdc
        contexto_global: [v18] hallazgos de ámbitos anteriores (lista de dicts)

    Returns:
        Lista de dicts de evaluación, uno por actividad.
    """
    resultados: List[Dict] = []
    hallazgos_acumulados: List[Dict] = []  # memoria intra-ámbito

    # [v20] Preparar bloque de memoria inter-ámbito — filtrado por relevancia + 250 chars
    # Solo se inyectan ámbitos conceptualmente relacionados con el actual.
    _RELACIONES_AMBITO = {
        "Documentación":              ["Gobierno", "Metodología", "Implementación"],
        "Calidad de datos":           ["Implementación", "Metodología"],
        "Metodología":                ["Implementación", "Calidad de datos", "Documentación"],
        "Gobierno":                   ["Documentación", "Uso e integración a la gestión"],
        "Implementación":             ["Metodología", "Calidad de datos"],
        "Uso e integración a la gestión": ["Gobierno", "Implementación"],
    }
    ambitos_relevantes = set(_RELACIONES_AMBITO.get(ambito, []))

    bloque_global = ""
    if contexto_global:
        resumen_global = []
        for h in contexto_global:
            amb_prev = h.get("ambito", "")
            # Filtrar: solo ámbitos relacionados, no el actual
            if amb_prev and amb_prev != ambito and amb_prev in ambitos_relevantes:
                pje  = h.get("puntaje", "?")
                obs  = h.get("observacion", "")[:250]   # [v20] 90 → 250 chars
                act  = h.get("actividad", "")[:80]
                resumen_global.append(f"  [{amb_prev}] {act}\n    → [{pje}/5] {obs}")
        # Limitar a los 5 más recientes relevantes para no inflar el prompt
        if resumen_global:
            bloque_global = (
                "\nCONTEXTO INTER-ÁMBITO (hallazgos de ámbitos relacionados ya evaluados):\n"
                + "\n".join(resumen_global[-5:])
                + "\n→ Si detectas incoherencias o contradicciones con estos hallazgos,"
                  " indícalo explícitamente en tu observación.\n"
            )

    for act in actividades:
        print(f"  → {act['actividad'][:75]}...")

        # Inyectar contexto global en el bloque de memoria intra-ámbito
        ctx_amb_completo = list(hallazgos_acumulados)
        if bloque_global:
            ctx_amb_completo = [{"ambito": "__global__", "actividad": bloque_global,
                                 "puntaje": None, "observacion": ""}] + ctx_amb_completo

        resultado = evaluar_actividad(
            actividad       = act["actividad"],
            ambito          = ambito,
            control         = act.get("control", ""),
            contexto        = contexto,
            titulo_modelo   = titulo_modelo,
            modo_preprdc    = modo_preprdc,
            contexto_ambito = ctx_amb_completo,
        )
        resultado["actividad"] = act["actividad"]
        resultado["control"]   = act.get("control", "")
        resultados.append(resultado)

        # Acumular para la siguiente actividad del mismo ámbito
        hallazgos_acumulados.append({
            "ambito":     ambito,
            "actividad":  act["actividad"],
            "puntaje":    resultado.get("puntaje"),
            "observacion": resultado.get("observacion", ""),
        })

    return resultados


# ══════════════════════════════════════════════════════════════════════════════
# RESUMEN EJECUTIVO — narrativa final del informe
# ══════════════════════════════════════════════════════════════════════════════

def generar_resumen_ejecutivo(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito:       Dict[str, float],
    score_global:            float,
    titulo_modelo:           str,
    tier:                    str,
) -> str:
    """
    Genera el resumen ejecutivo narrativo para el informe Word.

    Usa Mx_03._llamar_modelo() para la llamada a la API.
    Construye el prompt con los datos de evaluación por ámbito.

    Returns:
        Texto del informe en formato narrativo con secciones ### delimitadas.
    """
    # [FIX-COV] Calcular métricas de cobertura para incluir en el resumen
    coberturas = [
        e.get("cobertura_contexto", None)
        for evals in evaluaciones_por_ambito.values()
        for e in evals
        if e.get("cobertura_contexto") is not None
    ]
    cobertura_promedio = round(sum(coberturas) / len(coberturas), 2) if coberturas else None
    advertencia_cobertura = (
        f"\n⚠️  NOTA: La cobertura documental promedio fue {cobertura_promedio*100:.0f}%. "
        "Incluye en el informe una sección de limitaciones indicando qué ámbitos tuvieron "
        "cobertura baja (<50%) y que sus puntajes deben interpretarse con cautela."
        if cobertura_promedio is not None and cobertura_promedio < 0.7
        else ""
    )

    resumen_input = json.dumps({
        "titulo":             titulo_modelo,
        "tier":               tier,
        "score_global":       score_global,
        "scores_por_ambito":  scores_por_ambito,
        "hallazgos": {
            ambito: [
                {
                    "actividad":           e["actividad"],
                    "puntaje":             e["puntaje"],
                    "observacion":         e["observacion"],
                    "preguntas_pendientes":e.get("preguntas_pendientes", []),
                }
                for e in evals
            ]
            for ambito, evals in evaluaciones_por_ambito.items()
        },
    }, ensure_ascii=False)

    prompt = f"""
Basándote en los resultados de validación del modelo {titulo_modelo} (Tier {tier}),
genera un INFORME EJECUTIVO DE VALIDACIÓN en español con la siguiente estructura:

### 1. RESUMEN EJECUTIVO
2-3 párrafos con score global {score_global:.2f}/5.0 y dictamen general.

### 2. HALLAZGOS POR ÁMBITO
Para cada ámbito: score, hallazgos principales, observaciones críticas.

### 3. PREGUNTAS Y REQUERIMIENTOS PENDIENTES
Lista consolidada de información solicitada al modelador.

### 4. PLAN DE REMEDIACIÓN
Priorización por criticidad: Alta / Media / Baja.

### 5. LIMITACIONES DE ESTA EVALUACIÓN  [NUEVO - OBLIGATORIO]
Indica qué ámbitos tuvieron cobertura documental baja (<70%) y que sus puntajes
deben interpretarse con cautela. Menciona si algún PDF era escaneado o ilegible.
Si la cobertura fue alta (>90%), indica que la evaluación es sólida.
{advertencia_cobertura}

### 6. CONCLUSIÓN Y DICTAMEN FINAL
El dictamen debe ser uno de:
APROBADO / APROBADO CON CONDICIONES / OBSERVADO / RECHAZADO

Usa lenguaje técnico de validación de modelos de riesgo financiero.

DATOS DE EVALUACIÓN:
{resumen_input[:8000]}

Responde con el texto del informe en formato narrativo."""

    try:
        return _llamar_modelo(prompt, max_tokens=4096)
    except Exception as e:
        return f"[ERROR al generar resumen ejecutivo]: {e}"


# ══════════════════════════════════════════════════════════════════════════════
# MÉTRICAS Y SEMÁFORO
# ══════════════════════════════════════════════════════════════════════════════

def calcular_score_ambito(evaluaciones: List[Dict]) -> float:
    """Promedio simple de puntajes (1-5) de un ámbito."""
    if not evaluaciones:
        return 0.0
    return round(sum(e["puntaje"] for e in evaluaciones) / len(evaluaciones), 2)


def calcular_score_con_ic(evaluaciones: List[Dict]) -> Dict:
    """
    [D1/D6-FIX] Calcula score con intervalo de confianza (IC 90%) y
    cobertura de evidencia media.

    En lugar de devolver solo "puntaje: 2", devuelve:
      {
        "score": 2.3,
        "ic_low": 1.5,   # IC 90% límite inferior
        "ic_high": 3.1,  # IC 90% límite superior
        "cobertura_evidencia": 0.42,  # fracción media de cobertura de contexto
        "masa_critica_ok": True/False, # ≥ 15 evaluaciones históricas por ámbito
        "n": 4,          # número de actividades evaluadas
      }

    El IC se calcula con la distribución t de Student (n-1 grados de libertad)
    sobre los puntajes individuales de las actividades.
    """
    import math

    if not evaluaciones:
        return {"score": 0.0, "ic_low": 0.0, "ic_high": 0.0,
                "cobertura_evidencia": 0.0, "n": 0, "masa_critica_ok": False}

    puntajes = [float(e.get("puntaje", 1)) for e in evaluaciones]
    n = len(puntajes)
    media = sum(puntajes) / n

    # Intervalo de confianza con t-Student (90%)
    # t crítico aproximado: n=2→2.92, n=3→2.35, n=4→2.13, n≥5→1.89
    t_criticos = {1: 6.31, 2: 2.92, 3: 2.35, 4: 2.13, 5: 1.89}
    t = t_criticos.get(n, 1.89)  # para n≥5 usar 1.89 (aprox.)

    if n > 1:
        varianza = sum((x - media) ** 2 for x in puntajes) / (n - 1)
        std_err = math.sqrt(varianza / n)
        margen = t * std_err
    else:
        margen = 2.0  # n=1: incertidumbre máxima

    ic_low  = round(max(1.0, media - margen), 2)
    ic_high = round(min(5.0, media + margen), 2)

    # Cobertura de evidencia media
    coberturas = [e.get("cobertura_contexto", 0.0) for e in evaluaciones
                  if e.get("cobertura_contexto") is not None]
    cobertura_media = round(sum(coberturas) / len(coberturas), 3) if coberturas else 0.0

    return {
        "score":               round(media, 2),
        "ic_low":              ic_low,
        "ic_high":             ic_high,
        "cobertura_evidencia": cobertura_media,
        "n":                   n,
        "masa_critica_ok":     False,  # se actualiza en agente.py con historial de feedback
    }


def validar_masa_critica_feedback(historial: List[Dict], ambito: str,
                                   min_registros: int = 15) -> Dict:
    """
    [D6-FIX] Verifica que hay suficiente historial de feedback para que el
    sistema anti-sesgo sea estadísticamente válido.

    Args:
        historial: lista de dicts del historial_feedback.json
        ambito: ámbito a validar
        min_registros: mínimo para masa crítica (default 15, recomendado por D6)

    Returns:
        {
          "masa_critica_ok": bool,
          "n_registros": int,
          "alerta": str o None,
        }
    """
    registros_ambito = [r for r in historial
                        if r.get("ambito", "").lower() == ambito.lower()]
    n = len(registros_ambito)
    ok = n >= min_registros
    alerta = None if ok else (
        f"⚠ Masa crítica insuficiente para '{ambito}': {n}/{min_registros} registros. "
        f"El anti-sesgo no es estadísticamente confiable. "
        f"Se necesitan al menos {min_registros - n} evaluaciones adicionales con feedback."
    )
    return {"masa_critica_ok": ok, "n_registros": n, "alerta": alerta}


def calcular_score_global(
    scores_por_ambito: Dict[str, float],
    pesos: Optional[Dict[str, float]] = None,
) -> float:
    """
    Score global ponderado por ámbito.

    Si no se pasan pesos explícitos usa AMBITO_PESOS de config.py.
    """
    _pesos = pesos or AMBITO_PESOS
    total, peso_acum = 0.0, 0.0
    for ambito, score in scores_por_ambito.items():
        peso       = _pesos.get(ambito, 1 / max(len(scores_por_ambito), 1))
        total      += score * peso
        peso_acum  += peso
    return round(total / peso_acum, 2) if peso_acum > 0 else 0.0


def get_semaforo(score: float) -> Dict:
    """
    Retorna label y color hex según el score (1-5).
    Usa SCORE_SEMAFORO de config.py.
    """
    for (low, high), info in SCORE_SEMAFORO.items():
        if low <= score <= high:
            return info
    return {"label": "SIN CLASIFICAR", "color": "CCCCCC"}


# ══════════════════════════════════════════════════════════════════════════════
# RE-EXPORTAR INFRAESTRUCTURA Mx para quien importe motor_ia
# (evita que el resto del proyecto importe los Mx directamente)
# ══════════════════════════════════════════════════════════════════════════════

__all__ = [
    # Negocio
    "evaluar_actividad",
    "evaluar_ambito_completo",
    "generar_resumen_ejecutivo",
    "calcular_score_ambito",
    "calcular_score_global",
    "get_semaforo",
    # Mx_01 — lectura
    "leer_carpeta",
    "leer_repositorio_informes",
    "leer_estandares_virf",
    "cargar_todos_inputs",
    "inputs_para_dimension",
    # Mx_03 — IA
    "aprender_estilo",
    "generar_replica_virf",
    "generar_sintesis",
    # Mx_04 — controles de datos
    "detectar_cuestionamientos",
    "tiene_replica_virf",
    "calcular_riesgo_global",
    "resumen_cuestionamientos_consola",
    # Constantes
    "RUTAS",
    "AMBITO_A_INPUTS",
    "INSTRUCCIONES_DIMENSION",
    "MODO_PREPRDC",
    "MODO_PRDC",
    "UMBRAL_RIESGO_GLOBAL",
]


# ═══════════════════════════════════════════════════════════════════════════════
# [D5-FIX] EVALUACIÓN PARALELA DE ÁMBITOS
# Reduce tiempo de 25-40 min → 6-10 min usando ThreadPoolExecutor.
# Los ámbitos son independientes entre sí (salvo contexto_global que se construye
# secuencialmente). Las actividades dentro de cada ámbito se evalúan en paralelo.
# ═══════════════════════════════════════════════════════════════════════════════

import concurrent.futures
import threading

# Lock para prints thread-safe
_print_lock = threading.Lock()

def _evaluar_actividad_thread_safe(args_dict: dict) -> dict:
    """Wrapper thread-safe para evaluar_actividad (para ThreadPoolExecutor)."""
    resultado = evaluar_actividad(
        actividad       = args_dict["actividad"],
        ambito          = args_dict["ambito"],
        control         = args_dict["control"],
        contexto        = args_dict["contexto"],
        titulo_modelo   = args_dict["titulo_modelo"],
        modo_preprdc    = args_dict["modo_preprdc"],
        contexto_ambito = args_dict.get("contexto_ambito", []),
    )
    resultado["actividad"] = args_dict["actividad"]
    resultado["control"]   = args_dict["control"]
    with _print_lock:
        pje = resultado.get("puntaje", "?")
        print(f"    ✓ [{args_dict['ambito']}] {args_dict['actividad'][:60]}... → {pje}/5")
    return resultado


def evaluar_ambito_paralelo(
    ambito:        str,
    actividades:   List[Dict],
    contexto:      str,
    titulo_modelo: str,
    modo_preprdc:  bool = True,
    max_workers:   int  = 4,
) -> List[Dict]:
    """
    [D5-FIX] Versión paralela de evaluar_ambito_completo.

    Evalúa todas las actividades de un ámbito en paralelo (ThreadPoolExecutor).
    No soporta memoria intra-ámbito (se sacrifica para ganar velocidad).
    Usar evaluar_ambito_completo() si se necesita razonamiento encadenado.

    Args:
        max_workers: hilos concurrentes por ámbito. Default=4.
                     Ajustar según rate-limit de la API.
    """
    import os as _os
    workers = int(_os.getenv("VIRF_WORKERS", str(max_workers)))

    args_list = [
        {
            "actividad":    act["actividad"],
            "ambito":       ambito,
            "control":      act.get("control", ""),
            "contexto":     contexto,
            "titulo_modelo": titulo_modelo,
            "modo_preprdc": modo_preprdc,
        }
        for act in actividades
    ]

    resultados = [None] * len(args_list)  # mantener orden original

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        future_to_idx = {
            executor.submit(_evaluar_actividad_thread_safe, args): i
            for i, args in enumerate(args_list)
        }
        for future in concurrent.futures.as_completed(future_to_idx):
            idx = future_to_idx[future]
            try:
                resultados[idx] = future.result()
            except Exception as exc:
                with _print_lock:
                    print(f"  ✗ Error en actividad {idx}: {exc}")
                resultados[idx] = {
                    "puntaje": 1,
                    "concepto": "Error en evaluación paralela",
                    "observacion": str(exc),
                    "evidencia_encontrada": "",
                    "preguntas_pendientes": [],
                    "recomendacion": "Reintentar la evaluación",
                    "actividad": args_list[idx]["actividad"],
                    "control": args_list[idx]["control"],
                }

    return [r for r in resultados if r is not None]


def evaluar_todos_ambitos_paralelo(
    ambitos_data:  dict,
    todos_inputs:  dict,
    titulo_modelo: str,
    modo_preprdc:  bool = True,
    max_workers:   int  = 4,
) -> dict:
    """
    [D5-FIX] Evalúa todos los ámbitos en paralelo.

    Estrategia de dos niveles:
      1. Ámbitos en paralelo (ThreadPoolExecutor de ámbitos)
      2. Actividades dentro de cada ámbito en paralelo (ThreadPoolExecutor de actividades)

    Tiempo estimado: 25-40 min → 6-10 min con 4 workers por nivel.

    Returns:
        Dict {ambito: [lista de evaluaciones]}
    """
    from motor.Mx_01_LecturaEvidencias import inputs_para_dimension
    import os as _os

    ambito_workers = int(_os.getenv("VIRF_AMBITO_WORKERS", "3"))  # ámbitos en paralelo

    def _evaluar_un_ambito(ambito_actividades_tuple):
        ambito, actividades = ambito_actividades_tuple
        acts_requeridas = [a for a in actividades if a.get("requerida", True)]
        if not acts_requeridas:
            return ambito, []

        docs_ambito = inputs_para_dimension(todos_inputs, ambito)
        import os as _os2
        from config import MAX_CHARS_DOC
        MAX_CTX = int(_os2.getenv("VIRF_MAX_CTX", str(MAX_CHARS_DOC)))
        contexto_partes = []
        chars = 0
        for d in docs_ambito:
            if chars + len(d.get("contenido", "")) > MAX_CTX and contexto_partes:
                break
            contexto_partes.append(f"[{d['nombre']}]\n{d.get('contenido','')}")
            chars += len(d.get("contenido", ""))
        contexto = "\n".join(contexto_partes)

        with _print_lock:
            print(f"\n🔍 [PARALELO] {ambito} — {len(acts_requeridas)} actividades | {chars:,} chars")

        evals = evaluar_ambito_paralelo(
            ambito        = ambito,
            actividades   = acts_requeridas,
            contexto      = contexto,
            titulo_modelo = titulo_modelo,
            modo_preprdc  = modo_preprdc,
            max_workers   = max_workers,
        )
        return ambito, evals

    resultados = {}
    items = list(ambitos_data.items())

    with concurrent.futures.ThreadPoolExecutor(max_workers=ambito_workers) as executor:
        for ambito, evals in executor.map(_evaluar_un_ambito, items):
            resultados[ambito] = evals

    return resultados
