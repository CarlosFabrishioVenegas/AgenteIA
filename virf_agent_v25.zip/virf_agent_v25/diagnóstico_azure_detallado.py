#!/usr/bin/env python3
"""
diagnóstico_azure_detallado.py - Diagnóstico completo para soporte IT

Este script captura toda la información necesaria para debuggear problemas de
conexión a Azure OpenAI SIN revelar credenciales sensibles.

Uso:
    python diagnóstico_azure_detallado.py

Genera un reporte en: diagnostic_report.txt
"""

import os
import sys
import socket
import json
from pathlib import Path
from datetime import datetime
from urllib.parse import urlparse
from dotenv import load_dotenv

# Cargar .env
load_dotenv()

class Colors:
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

def mask_secret(value, chars_to_show=5):
    """Enmascara valores sensibles mostrando solo inicio y fin"""
    if not value or len(value) <= chars_to_show * 2:
        return "***REDACTED***"
    return f"{value[:chars_to_show]}...{value[-chars_to_show:]}"

def get_endpoint_info():
    """Extrae información del endpoint sin revelar credenciales"""
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()
    
    if not endpoint:
        return {
            "status": "❌ No configurado",
            "value": "N/A"
        }
    
    try:
        parsed = urlparse(endpoint)
        hostname = parsed.netloc
        
        # Intentar resolver DNS
        try:
            ip_address = socket.gethostbyname(hostname)
            dns_status = f"✅ Resolvible ({ip_address})"
        except socket.gaierror:
            dns_status = "❌ No resolvible (DNS problem)"
        except Exception as e:
            dns_status = f"⚠️ Error DNS: {type(e).__name__}"
        
        return {
            "status": "✅ Configurado",
            "scheme": parsed.scheme,
            "hostname": hostname,
            "path": parsed.path or "/",
            "dns_status": dns_status,
            "value": mask_secret(endpoint)
        }
    except Exception as e:
        return {
            "status": "⚠️ Error parsing",
            "error": str(e),
            "value": mask_secret(endpoint)
        }

def test_connectivity():
    """Intenta conectar a Azure OpenAI sin credenciales"""
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()
    
    if not endpoint:
        return {
            "status": "⚠️ Endpoint no configurado",
            "tcp_test": "N/A",
            "https_test": "N/A"
        }
    
    try:
        from urllib.parse import urlparse
        parsed = urlparse(endpoint)
        hostname = parsed.netloc.split(":")[0]
        port = 443  # HTTPS
        
        # Test TCP connectivity
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        
        try:
            result = sock.connect_ex((hostname, port))
            if result == 0:
                tcp_status = f"✅ Puerto {port} abierto (TCP conecta)"
            else:
                tcp_status = f"❌ Puerto {port} cerrado (código: {result})"
        except Exception as e:
            tcp_status = f"⚠️ Error: {type(e).__name__}"
        finally:
            sock.close()
        
        return {
            "status": "✅ Test ejecutado",
            "hostname": hostname,
            "port": port,
            "tcp_result": tcp_status
        }
    except Exception as e:
        return {
            "status": "⚠️ Error en test",
            "error": str(e)
        }

def get_system_info():
    """Información del sistema sin datos sensibles"""
    import platform
    
    return {
        "os": platform.system(),
        "os_version": platform.release(),
        "python_version": platform.python_version(),
        "architecture": platform.machine()
    }

def test_openai_library():
    """Verifica si openai library está instalada"""
    try:
        import openai
        return {
            "status": "✅ Instalada",
            "version": openai.__version__
        }
    except ImportError:
        return {
            "status": "❌ No instalada",
            "version": "N/A",
            "fix": "pip install openai"
        }

def test_config_import():
    """Intenta importar config sin conectar"""
    try:
        sys.path.insert(0, str(Path(__file__).parent))
        import config
        return {
            "status": "✅ config.py importable",
            "proveedor": config.IA_PROVEEDOR,
            "max_timeout": config.TIMEOUT_SEGUNDOS
        }
    except Exception as e:
        return {
            "status": "❌ Error importando config",
            "error": str(e)
        }

def generate_report():
    """Genera reporte completo"""
    print(f"\n{Colors.BOLD}{Colors.BLUE}═══════════════════════════════════════════════════════════════════════════════{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}🔍 DIAGNÓSTICO DETALLADO AZURE OPENAI{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.BLUE}═══════════════════════════════════════════════════════════════════════════════{Colors.RESET}\n")
    
    report = {
        "timestamp": datetime.now().isoformat(),
        "system_info": get_system_info(),
        "configuration": {
            "ia_proveedor": os.getenv("IA_PROVEEDOR", "NO_CONFIGURADO"),
            "api_version": os.getenv("AZURE_OPENAI_API_VERSION", "N/A"),
            "api_key_status": "✅ Configurada" if os.getenv("AZURE_OPENAI_API_KEY") else "❌ No configurada",
            "api_key_masked": mask_secret(os.getenv("AZURE_OPENAI_API_KEY", "")),
            "endpoint_info": get_endpoint_info(),
            "deployment_status": "✅ Configurado" if os.getenv("AZURE_OPENAI_DEPLOYMENT") else "❌ No configurado",
            "deployment_name": os.getenv("AZURE_OPENAI_DEPLOYMENT", "N/A")
        },
        "libraries": {
            "openai": test_openai_library(),
            "config": test_config_import()
        },
        "network": test_connectivity(),
        "diagnostics": []
    }
    
    # Imprimir informe en terminal
    print(f"{Colors.BOLD}🖥️  INFORMACIÓN DEL SISTEMA{Colors.RESET}")
    print("-" * 80)
    for key, val in report["system_info"].items():
        print(f"  {key}: {val}")
    
    print(f"\n{Colors.BOLD}⚙️  CONFIGURACIÓN{Colors.RESET}")
    print("-" * 80)
    print(f"  IA_PROVEEDOR: {report['configuration']['ia_proveedor']}")
    print(f"  API Version: {report['configuration']['api_version']}")
    print(f"  API Key: {report['configuration']['api_key_status']}")
    print(f"    Valor: {report['configuration']['api_key_masked']}")
    
    endpoint_info = report['configuration']['endpoint_info']
    print(f"  Endpoint: {endpoint_info['status']}")
    if endpoint_info['status'] == "✅ Configurado":
        print(f"    Scheme: {endpoint_info['scheme']}")
        print(f"    Hostname: {endpoint_info['hostname']}")
        print(f"    DNS: {endpoint_info['dns_status']}")
        print(f"    Valor: {endpoint_info['value']}")
    
    print(f"  Deployment: {report['configuration']['deployment_status']}")
    print(f"    Nombre: {report['configuration']['deployment_name']}")
    
    print(f"\n{Colors.BOLD}📦 DEPENDENCIAS{Colors.RESET}")
    print("-" * 80)
    openai_info = report['libraries']['openai']
    print(f"  openai: {openai_info['status']}")
    if openai_info['status'] == "✅ Instalada":
        print(f"    Version: {openai_info['version']}")
    else:
        print(f"    Fix: {openai_info.get('fix', 'N/A')}")
    
    config_info = report['libraries']['config']
    print(f"  config.py: {config_info['status']}")
    if config_info['status'] == "✅ config.py importable":
        print(f"    Proveedor: {config_info['proveedor']}")
        print(f"    Timeout: {config_info['max_timeout']}s")
    
    print(f"\n{Colors.BOLD}🌐 RED / CONECTIVIDAD{Colors.RESET}")
    print("-" * 80)
    network = report['network']
    print(f"  Status: {network['status']}")
    if network['status'] == "✅ Test ejecutado":
        print(f"  Hostname: {network['hostname']}")
        print(f"  Port: {network['port']}")
        print(f"  TCP Connectivity: {network['tcp_result']}")
    else:
        print(f"  Error: {network.get('error', 'N/A')}")
    
    # Guardar reporte a archivo
    report_path = Path(__file__).parent / "diagnostic_report.json"
    try:
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        print(f"\n{Colors.GREEN}✅ Reporte guardado en: {report_path}{Colors.RESET}")
    except Exception as e:
        print(f"\n{Colors.YELLOW}⚠️  No se pudo guardar reporte: {e}{Colors.RESET}")
    
    # Guardar versión legible
    text_report_path = Path(__file__).parent / "diagnostic_report.txt"
    try:
        with open(text_report_path, 'w') as f:
            f.write("DIAGNÓSTICO AZURE OPENAI - REPORTE PARA SOPORTE IT\n")
            f.write("=" * 80 + "\n\n")
            f.write(f"Generado: {report['timestamp']}\n\n")
            
            f.write("INFORMACIÓN DEL SISTEMA\n")
            f.write("-" * 80 + "\n")
            for key, val in report['system_info'].items():
                f.write(f"  {key}: {val}\n")
            
            f.write("\nCONFIGURACIÓN AZURE OPENAI\n")
            f.write("-" * 80 + "\n")
            f.write(f"  IA_PROVEEDOR: {report['configuration']['ia_proveedor']}\n")
            f.write(f"  API Key Status: {report['configuration']['api_key_status']}\n")
            f.write(f"  API Key (enmascarada): {report['configuration']['api_key_masked']}\n")
            
            endpoint_info = report['configuration']['endpoint_info']
            f.write(f"  Endpoint Status: {endpoint_info['status']}\n")
            if endpoint_info['status'] == "✅ Configurado":
                f.write(f"    Hostname: {endpoint_info['hostname']}\n")
                f.write(f"    DNS: {endpoint_info['dns_status']}\n")
            
            f.write(f"  Deployment: {report['configuration']['deployment_name']}\n")
            f.write(f"  API Version: {report['configuration']['api_version']}\n")
            
            f.write("\nDEPENDENCIAS\n")
            f.write("-" * 80 + "\n")
            openai_info = report['libraries']['openai']
            f.write(f"  openai: {openai_info['status']}\n")
            if openai_info['status'] == "✅ Instalada":
                f.write(f"    Version: {openai_info['version']}\n")
            
            f.write("\nCONECTIVIDAD RED\n")
            f.write("-" * 80 + "\n")
            network = report['network']
            f.write(f"  Status: {network['status']}\n")
            if network['status'] == "✅ Test ejecutado":
                f.write(f"  Hostname: {network['hostname']}\n")
                f.write(f"  TCP Port {network['port']}: {network['tcp_result']}\n")
            
            f.write("\n\nPRÓXIMOS PASOS:\n")
            f.write("-" * 80 + "\n")
            f.write("1. Comparte este reporte con tu soporte IT\n")
            f.write("2. Verifica que:\n")
            f.write("   - API Key sea válida (compárala en Azure Portal)\n")
            f.write("   - Endpoint sea correcto (copia nuevamente si es necesario)\n")
            f.write("   - Deployment exista en Azure Portal\n")
            f.write("3. Si el TCP test falla, puede ser un problema de firewall/proxy\n")
        
        print(f"{Colors.GREEN}✅ Reporte legible guardado en: {text_report_path}{Colors.RESET}")
    except Exception as e:
        print(f"{Colors.YELLOW}⚠️  No se pudo guardar reporte TXT: {e}{Colors.RESET}")
    
    return report

if __name__ == "__main__":
    try:
        report = generate_report()
        print(f"\n{Colors.BOLD}✅ Diagnóstico completado.{Colors.RESET}")
        print(f"   Comparte 'diagnostic_report.txt' con tu soporte IT\n")
    except Exception as e:
        print(f"\n{Colors.RED}❌ Error en diagnóstico: {e}{Colors.RESET}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
