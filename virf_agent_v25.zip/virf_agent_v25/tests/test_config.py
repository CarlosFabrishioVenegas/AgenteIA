"""
test_config.py - Tests para configuración central

Valida que la configuración cargue correctamente y los clientes IA funcionen.
"""

import pytest
import os
from pathlib import Path
from unittest.mock import patch

from config import get_cliente_ia, ClienteIA, ClienteAnthropicIA, BASE_DIR, OUTPUTS_DIR
from unittest.mock import patch, MagicMock
from motor.Mx_00_CargaRutas import AGENTE_VERSION
class _CFG:
    BASE_DIR = BASE_DIR
    OUTPUTS_DIR = OUTPUTS_DIR
    AGENTE_VERSION = AGENTE_VERSION
CFG = _CFG()


class TestConfiguracion:
    """Tests para la configuración global."""

    def test_config_carga(self, config):
        """Valida que la configuración cargue sin errores."""
        assert config is not None

    def test_directorios_existentes(self, config):
        """Valida que los directorios configurados existan."""
        assert config.BASE_DIR.exists()
        assert config.OUTPUTS_DIR.exists() or True  # Puede no existir


class TestClienteIA:
    """Tests para clientes de IA."""

    @pytest.mark.skip(reason="Requiere ANTHROPIC_API_KEY real")
    def test_get_cliente_ia(self):
        """Valida que se obtiene un cliente IA válido."""
        cliente = get_cliente_ia()
        
        assert isinstance(cliente, ClienteIA)
        assert hasattr(cliente, "generar_mensaje")

    @pytest.mark.skip(reason="Requiere ANTHROPIC_API_KEY real")
    def test_cliente_anthropic_implementado(self):
        """Valida que el cliente de Anthropic está implementado."""
        with patch.dict(os.environ, {"IA_PROVEEDOR": "anthropic"}):
            cliente = get_cliente_ia()
            
            # Debe ser cliente Anthropic o similar
            assert cliente is not None
            assert hasattr(cliente, "generar_mensaje")

    @pytest.mark.skip(reason="Requiere ANTHROPIC_API_KEY real")
    def test_cliente_tiene_metodos_requeridos(self):
        """Valida que el cliente tiene todos los métodos requeridos."""
        cliente = get_cliente_ia()
        
        assert hasattr(cliente, "generar_mensaje")
        assert callable(getattr(cliente, "generar_mensaje"))


class TestRutasProyecto:
    """Tests para rutas del proyecto."""

    def test_ruta_base(self, config):
        """Valida ruta base del proyecto."""
        assert config.BASE_DIR is not None
        assert isinstance(config.BASE_DIR, Path)

    def test_ruta_inputs(self, config):
        """Valida que existe directorio de inputs."""
        inputs_dir = config.BASE_DIR / "inputs"
        # No afirmamos que exista siempre, pero debe estar en config
        assert hasattr(config, "BASE_DIR")

    def test_ruta_outputs(self, config):
        """Valida que existe directorio de outputs."""
        # La carpeta outputs se crea dinámicamente
        assert hasattr(config, "OUTPUTS_DIR")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
