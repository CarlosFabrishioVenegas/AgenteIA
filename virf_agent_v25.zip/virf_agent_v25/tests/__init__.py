"""
tests - Suite de tests para VIRF Agent

Estructura:
  test_config.py      - Tests de configuración
  test_feedback.py    - Tests del sistema de feedback
  test_motor_ia.py    - Tests del motor de IA
  conftest.py         - Configuración compartida y fixtures

Para ejecutar todos los tests:
  pytest tests/ -v

Para ejecutar un test específico:
  pytest tests/test_feedback.py::TestAnalisisPatrones::test_detectar_sobrestima -v

Para ver cobertura:
  pytest tests/ --cov=modulos --cov=config
"""

__version__ = "1.0"
