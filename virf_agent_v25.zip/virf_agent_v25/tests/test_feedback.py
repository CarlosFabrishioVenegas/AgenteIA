"""
tests/test_feedback.py  [v20]
Tests sincronizados con las firmas reales de feedback_mejorado.py
"""
import pytest
import sys
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from modulos.feedback_mejorado import (
    analizar_patron_errores,
    construir_bloque_aprendizaje,
    ajustar_puntaje_por_feedback,
    obtener_recomendaciones_evaluacion,
    generar_resumen_aprendizaje,
)


class TestAnalisisPatrones:
    """analizar_patron_errores(ambito: str) -> Dict"""

    def test_detectar_subestima(self):
        # Con historial real que tiene subestimaciones, debe detectar tendencia
        r = analizar_patron_errores("Documentación")
        assert isinstance(r, dict)
        assert "tendencia" in r
        assert "error_promedio" in r

    def test_detectar_sobrestima(self):
        r = analizar_patron_errores("Metodología")
        assert isinstance(r, dict)
        assert "tendencia" in r

    def test_feedback_vacio(self):
        # Ámbito sin feedback registrado → tendencia equilibrado
        r = analizar_patron_errores("__ambito_inexistente__")
        assert isinstance(r, dict)
        assert r.get("error_promedio", 0) == 0


class TestConstruccionBloqueAprendizaje:
    """construir_bloque_aprendizaje(ambito: str) -> str"""

    def test_construir_bloque_valido(self):
        bloque = construir_bloque_aprendizaje("Documentación")
        assert isinstance(bloque, str)

    def test_bloque_contiene_guia(self):
        bloque = construir_bloque_aprendizaje("Metodología")
        # Con historial pequeño puede ser vacío — lo importante es que no lanza
        assert bloque is not None


class TestAjustePuntaje:
    """ajustar_puntaje_por_feedback(puntaje_inicial, ambito, ...) -> float"""

    def test_ajuste_retorna_float(self):
        r = ajustar_puntaje_por_feedback("Documentación", "Verifica control", 3)
        r_val = r[0] if isinstance(r, tuple) else r
        assert isinstance(r_val, (int, float))

    def test_ajuste_dentro_rango(self):
        for p in [1, 2, 3, 4, 5]:
            r = ajustar_puntaje_por_feedback("Metodología", "Actividad test", p)
            r_val = r[0] if isinstance(r, tuple) else r
            assert 1 <= r_val <= 5, f"Ajuste fuera de rango: {r}"

    def test_sin_ajuste_ambito_sin_historial(self):
        r = ajustar_puntaje_por_feedback("__ambito_sin_datos__", "actividad test", 3)
        r_val = r[0] if isinstance(r, tuple) else r
        assert abs(r_val - 3) < 0.5, "Sin historial, el ajuste debe ser mínimo"


class TestRecomendaciones:
    """obtener_recomendaciones_evaluacion(ambito: str) -> str"""

    def test_generar_recomendaciones(self):
        r = obtener_recomendaciones_evaluacion("Documentación")
        assert isinstance(r, str)

    def test_recomendaciones_no_lanza_en_ambito_vacio(self):
        r = obtener_recomendaciones_evaluacion("__vacio__")
        assert r is not None


class TestResumenAprendizaje:
    """generar_resumen_aprendizaje() -> str (sin args)"""

    def test_generar_resumen(self):
        r = generar_resumen_aprendizaje()
        assert isinstance(r, str)

    def test_resumen_no_vacio(self):
        r = generar_resumen_aprendizaje()
        assert len(r) > 0
