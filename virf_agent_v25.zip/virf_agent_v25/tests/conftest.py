"""
conftest.py - Configuración compartida para tests

Define fixtures, configuración global y helpers para todos los tests.
"""

import pytest
import sys
from pathlib import Path
from typing import Generator

# Agregar el directorio raíz al path
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

# Imports
from config import BASE_DIR, OUTPUTS_DIR
from motor.Mx_00_CargaRutas import AGENTE_VERSION

# CFG compatibility shim
class _CFG:
    BASE_DIR = BASE_DIR
    OUTPUTS_DIR = OUTPUTS_DIR
    AGENTE_VERSION = AGENTE_VERSION
CFG = _CFG()


@pytest.fixture
def project_root() -> Path:
    """Retorna la raíz del proyecto."""
    return PROJECT_ROOT


@pytest.fixture
def base_dir() -> Path:
    """Retorna el directorio base del proyecto."""
    return BASE_DIR


@pytest.fixture
def config():
    """Retorna la configuración global."""
    return CFG


@pytest.fixture
def sample_feedback_data() -> dict:
    """Datos de muestra para tests de feedback."""
    return {
        "evaluacion": "SOBRESTIMA",
        "puntaje_original": 8.5,
        "puntaje_corregido": 7.2,
        "diferencia": -1.3,
        "ambito": "Gobierno Corporativo",
        "timestamp": "2026-05-08T10:30:00Z",
    }


@pytest.fixture
def sample_control_data() -> dict:
    """Datos de control de muestra."""
    return {
        "id_control": "GC_001",
        "nombre": "Control de Gobierno Corporativo",
        "descripcion": "Evalúa los mecanismos de gobernanza",
        "tier": 1,
        "ambito": "Gobierno Corporativo",
    }
