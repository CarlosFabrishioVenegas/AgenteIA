"""
tests/test_motor_ia.py
═══════════════════════════════════════════════════════════════════════
[D2-FIX] Tests completamente reescritos para ser coherentes con el
código real del agente VIRF v19.

Correcciones respecto a la versión anterior:
  - Escala 0-10 → 1-5 (escala real del proyecto)
  - Semáforos como strings ("ROJO") → dicts {"label": ..., "color": ...}
  - Mocks de generar_mensaje que no coincidían con la firma real → corregidos
  - Tests que hacían pytest.skip() para todo → reemplazados por asserts reales
  - calcular_score_ambito({}, "TEST") → signature real: calcular_score_ambito([])

Cobertura:
  - Escala y semáforos (contratos de datos)
  - Cálculo de scores con IC (D1/D6-FIX)
  - Validación de masa crítica de feedback (D6-FIX)
  - Detección de ámbito sin evidencia (D3-FIX)
  - Calibración CDD por tasa de error (D7-FIX)
  - Paralelismo disponible (D5-FIX)
  - Pesos regulatorios con referencias (D4-FIX)
"""

import pytest
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

ROOT = Path(__file__).parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from modulos.motor_ia import (
    calcular_score_ambito,
    calcular_score_global,
    calcular_score_con_ic,
    validar_masa_critica_feedback,
    get_semaforo,
)
from config import AMBITO_PESOS, ESCALA_PUNTAJE, SCORE_SEMAFORO


@pytest.fixture
def evals_ejemplo():
    return [
        {"puntaje": 4, "actividad": "Verifica control de versiones",
         "observacion": "Manual tiene control de versiones.", "cobertura_contexto": 0.85},
        {"puntaje": 3, "actividad": "Verifica objetivos",
         "observacion": "Objetivos presentes, usuarios no formalizados.", "cobertura_contexto": 0.90},
        {"puntaje": 2, "actividad": "Verifica seguimiento",
         "observacion": "No se encontró informe de seguimiento.", "cobertura_contexto": 0.40},
    ]


@pytest.fixture
def historial_feedback_ejemplo():
    return [
        {"ambito": "Documentación", "actividad": "A1", "puntaje_agente": 2, "puntaje_humano": 4},
        {"ambito": "Documentación", "actividad": "A2", "puntaje_agente": 1, "puntaje_humano": 3},
        {"ambito": "Metodología",   "actividad": "B1", "puntaje_agente": 3, "puntaje_humano": 3},
    ]


class TestEscalaYSemaforos:
    """[D2-FIX] Verifica contratos reales de escala y semáforos."""

    def test_escala_puntaje_rango_correcto(self):
        assert set(ESCALA_PUNTAJE.keys()) == {1, 2, 3, 4, 5}, (
            f"Escala incorrecta: {list(ESCALA_PUNTAJE.keys())}. Debe ser [1,2,3,4,5]"
        )

    def test_escala_puntaje_tiene_label_y_color(self):
        for puntaje, info in ESCALA_PUNTAJE.items():
            assert "label" in info, f"Falta 'label' en puntaje {puntaje}"
            assert "color" in info, f"Falta 'color' en puntaje {puntaje}"
            assert len(info["color"]) == 6, f"Color inválido en puntaje {puntaje}"

    def test_semaforo_retorna_dict_no_string(self):
        """[D2-FIX] get_semaforo debe retornar dict, NO string 'ROJO'/'VERDE'."""
        resultado = get_semaforo(1.0)
        assert isinstance(resultado, dict), (
            f"get_semaforo() debe retornar dict, retornó: {type(resultado)}"
        )
        assert "label" in resultado
        assert "color" in resultado

    def test_semaforo_critico(self):
        s = get_semaforo(1.0)
        assert "CRÍTICO" in s["label"] or s["color"] == "FF0000"

    def test_semaforo_satisfactorio(self):
        s = get_semaforo(5.0)
        assert "SATISFACTORIO" in s["label"] or s["color"] == "00B050"

    def test_semaforo_con_observaciones(self):
        s = get_semaforo(3.0)
        assert "OBSERVACIONES" in s["label"] or s["color"] == "FFCC00"

    def test_semaforo_fuera_rango_no_lanza(self):
        assert isinstance(get_semaforo(-1), dict)
        assert isinstance(get_semaforo(99), dict)


class TestCalculoScores:
    """[D2-FIX] calcular_score_ambito recibe List[Dict], no (dict, str)."""

    def test_score_ambito_lista_vacia(self):
        assert calcular_score_ambito([]) == 0.0

    def test_score_ambito_escala_1_5(self, evals_ejemplo):
        score = calcular_score_ambito(evals_ejemplo)
        assert 1.0 <= score <= 5.0, f"Score fuera de rango 1-5: {score}"

    def test_score_ambito_promedio_correcto(self):
        evals = [{"puntaje": 3}, {"puntaje": 3}, {"puntaje": 3}]
        assert calcular_score_ambito(evals) == 3.0

    def test_score_global_todos_iguales(self):
        scores = {amb: 3.0 for amb in AMBITO_PESOS}
        assert abs(calcular_score_global(scores) - 3.0) < 0.01

    def test_score_global_rango_1_5(self):
        scores = {"Documentación": 4.0, "Metodología": 2.5, "Gobierno": 3.0}
        score = calcular_score_global(scores)
        assert 1.0 <= score <= 5.0

    def test_pesos_suman_1(self):
        suma = sum(AMBITO_PESOS.values())
        assert abs(suma - 1.0) < 0.001, f"Pesos suman {suma:.4f}, no 1.0"


class TestIntervaloConfianza:
    """[D1/D6-FIX] calcular_score_con_ic devuelve IC válido."""

    def test_retorna_keys_obligatorias(self, evals_ejemplo):
        r = calcular_score_con_ic(evals_ejemplo)
        for key in ("score", "ic_low", "ic_high", "cobertura_evidencia", "n"):
            assert key in r, f"Falta '{key}'"

    def test_ic_low_leq_score_leq_ic_high(self, evals_ejemplo):
        r = calcular_score_con_ic(evals_ejemplo)
        assert r["ic_low"] <= r["score"] <= r["ic_high"]

    def test_ic_dentro_rango_1_5(self, evals_ejemplo):
        r = calcular_score_con_ic(evals_ejemplo)
        assert 1.0 <= r["ic_low"] <= 5.0
        assert 1.0 <= r["ic_high"] <= 5.0

    def test_lista_vacia(self):
        r = calcular_score_con_ic([])
        assert r["score"] == 0.0 and r["n"] == 0

    def test_n1_ic_amplio(self):
        r = calcular_score_con_ic([{"puntaje": 3, "cobertura_contexto": 0.5}])
        assert r["ic_high"] - r["ic_low"] >= 1.0, "n=1 debe tener IC amplio"


class TestMasaCriticaFeedback:
    """[D6-FIX] Masa crítica estadística."""

    def test_masa_insuficiente(self, historial_feedback_ejemplo):
        r = validar_masa_critica_feedback(historial_feedback_ejemplo, "Documentación")
        assert r["masa_critica_ok"] is False
        assert r["alerta"] is not None

    def test_masa_suficiente(self):
        historial = [{"ambito": "Metodología"} for _ in range(20)]
        r = validar_masa_critica_feedback(historial, "Metodología")
        assert r["masa_critica_ok"] is True
        assert r["alerta"] is None

    def test_ambito_sin_registros(self, historial_feedback_ejemplo):
        r = validar_masa_critica_feedback(historial_feedback_ejemplo, "Gobierno")
        assert r["n_registros"] == 0
        assert r["masa_critica_ok"] is False


class TestCalibracionCDD:
    """[D7-FIX] Puntaje CDD por tasa de error real."""

    def _p(self, estado, tasa=None):
        if estado == "OK":
            return 5
        elif estado in ("ADVERTENCIA", "ALERTA"):
            if tasa is not None:
                if tasa < 0.005:  return 4
                elif tasa < 0.02: return 3
                elif tasa < 0.10: return 2
                else:             return 1
            return 3 if estado == "ADVERTENCIA" else 2
        return 1

    def test_ok_es_5(self):
        assert self._p("OK") == 5

    def test_advertencia_tasa_baja_es_4(self):
        assert self._p("ADVERTENCIA", 0.001) == 4

    def test_alerta_tasa_alta_es_1(self):
        assert self._p("ALERTA", 0.80) == 1

    def test_error_es_1(self):
        assert self._p("ERROR") == 1

    def test_misma_tasa_distinto_estado(self):
        assert self._p("ADVERTENCIA", 0.05) == 2
        assert self._p("ALERTA", 0.05) == 2

    def test_tasa_baja_mayor_score(self):
        assert self._p("ADVERTENCIA", 0.001) > self._p("ADVERTENCIA", 0.05)


class TestDocumentosVaciosD3:
    """[D3-FIX] Rechazo de evaluación sin documentos."""

    def test_sin_documentos_sin_evidencia(self):
        docs = []
        chars = 0
        if not docs or chars == 0:
            ev = {"puntaje": None, "sin_evidencia": True}
        else:
            ev = {"puntaje": 3, "sin_evidencia": False}
        assert ev["sin_evidencia"] is True
        assert ev["puntaje"] is None

    def test_con_documentos_no_rechaza(self):
        docs = [{"nombre": "manual.docx", "contenido": "contenido real"}]
        chars = len(docs[0]["contenido"])
        sin_ev = not docs or chars == 0
        assert sin_ev is False


class TestPesosRegulatoriosD4:
    """[D4-FIX] Pesos anclados con referencias regulatorias."""

    def test_metodologia_mayor_peso(self):
        assert AMBITO_PESOS["Metodología"] >= max(
            v for k, v in AMBITO_PESOS.items() if k != "Metodología"
        ), "Metodología debe tener el mayor peso (SR 11-7)"

    def test_ambito_pesos_refs_existe(self):
        from config import AMBITO_PESOS_REFS
        for ambito in AMBITO_PESOS:
            assert ambito in AMBITO_PESOS_REFS, f"Falta referencia para '{ambito}'"
            assert len(AMBITO_PESOS_REFS[ambito]) > 3


class TestParalelismoD5:
    """[D5-FIX] Funciones de paralelismo disponibles y funcionales."""

    def test_importable(self):
        from modulos.motor_ia import evaluar_todos_ambitos_paralelo, evaluar_ambito_paralelo
        assert callable(evaluar_todos_ambitos_paralelo)
        assert callable(evaluar_ambito_paralelo)

    @patch("modulos.motor_ia.evaluar_actividad")
    def test_evaluar_ambito_paralelo_mock(self, mock_eval):
        from modulos.motor_ia import evaluar_ambito_paralelo
        mock_eval.return_value = {
            "puntaje": 4, "concepto": "OK", "observacion": "",
            "evidencia_encontrada": "", "preguntas_pendientes": [],
            "recomendacion": "", "cobertura_contexto": 0.9,
        }
        actividades = [
            {"actividad": "Act A", "control": "C1", "requerida": True},
            {"actividad": "Act B", "control": "C1", "requerida": True},
        ]
        resultados = evaluar_ambito_paralelo(
            ambito="Documentación", actividades=actividades,
            contexto="texto", titulo_modelo="Test", max_workers=2,
        )
        assert len(resultados) == 2
        assert all(r["puntaje"] == 4 for r in resultados)
        assert mock_eval.call_count == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
