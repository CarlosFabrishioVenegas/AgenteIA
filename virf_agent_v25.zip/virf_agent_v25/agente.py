"""
agente.py — Punto de entrada del agente VIRF

PIPELINE 1: CALIDAD DE DATOS (nuevo - recomendado)
  python agente.py --titulo "Modelo LaR" --tier 1 --excel inputs/calidad_datos/ControlesData.xlsx --control
  python agente.py --titulo "Modelo LaR" --tier 1 --excel inputs/calidad_datos/ControlesData.xlsx --control --prdc

PIPELINE 2: TODOS LOS ÁMBITOS (legacy - análisis completo)
  python agente.py --titulo "Modelo LaR" --tier 1
  python agente.py --titulo "Modelo LaR" --tier 1 --prdc

ESTADÍSTICAS:
  python agente.py --estadisticafeedback
"""

import argparse
import sys
import os
from datetime import datetime
from pathlib import Path

from config import OUTPUTS_DIR, ESTANDARES_PATH, BASE_DIR
from modulos.motor_ia_v2 import orquestar_pipeline_virf, evaluar_todos_controles
from modulos.motor_ia import (
    leer_estandares_virf, cargar_todos_inputs, inputs_para_dimension,
    evaluar_ambito_completo, calcular_score_ambito, calcular_score_global,
    get_semaforo, generar_resumen_ejecutivo,
)
from modulos.generador_word import generar_word_informe
from modulos.feedback import calcular_estadisticas, bucle_feedback_consola
from modulos.generador_estadistica_feedback import generar_informe_estadistica

# ── Caché de documentos (v15) ─────────────────────────────────────────────────
from modulos.document_cache import inicializar_cache, cerrar_cache
from motor.Mx_00_CargaRutas import CACHE_ENABLED, CACHE_DIR, AGENTE_VERSION
from modulos.chunker import ChunkerService

CONTROLES_DATA_PATH = BASE_DIR / "inputs" / "calidad_datos" / "ControlesData.xlsx"


def modo_estadistica_feedback():
    print("\n" + "═" * 65)
    print("  📈 ESTADÍSTICAS DE PRECISIÓN DEL AGENTE VIRF")
    print("═" * 65 + "\n")

    stats = calcular_estadisticas()
    if "error" in stats:
        print(f"  [!] {stats['error']}")
        print("  Ejecuta al menos una validación con feedback antes de usar este modo.\n")
        sys.exit(0)

    print(f"  Total feedbacks registrados : {stats['total_feedbacks']}")
    print(f"  Período                     : {stats['primer_feedback']} → {stats['ultimo_feedback']}")
    print(f"\n  {'MÉTRICA':<35} {'VALOR':>10}")
    print(f"  {'─'*47}")
    print(f"  {'Evaluaciones exactas':<35} {stats['pct_exactas']:>9.1f}%")
    print(f"  {'Dentro de ±1 punto':<35} {stats['pct_dentro_1_punto']:>9.1f}%")
    print(f"  {'Error medio absoluto (MAE)':<35} {stats['mae']:>10.3f}")
    print(f"  {'Sesgo promedio':<35} {stats['sesgo_promedio']:>10.3f}")
    print(f"  {'Interpretación sesgo':<35} {stats['sesgo_interpretacion']}")
    print(f"  {'Sobreestimaciones':<35} {stats['n_sobreestimaciones']:>10}")
    print(f"  {'Subestimaciones':<35} {stats['n_subestimaciones']:>10}")
    print(f"\n  {'ÁMBITO':<35} {'MAE':>6}  {'EXACTOS':>8}  {'±1 PTO':>7}")
    print(f"  {'─'*58}")
    for amb, s in stats["por_ambito"].items():
        print(f"  {amb:<35} {s['mae']:>6.3f}  {s['pct_exactos']:>7.1f}%  {s['pct_1_punto']:>6.1f}%")

    print("\n  📊 Generando informe Excel detallado...")
    ruta = generar_informe_estadistica(OUTPUTS_DIR)
    if ruta:
        print(f"\n  ✅ Informe guardado en: {ruta.name}")
    print()


# ── [v20] Auto-setup de .env en primer arranque ───────────────────────────────
def _setup_env_si_falta() -> None:
    """
    Si no existe .env, lo copia desde .env.example con un aviso claro.
    El usuario solo necesita editar ANTHROPIC_API_KEY.
    """
    from pathlib import Path as _Path
    env_path     = _Path(__file__).parent / ".env"
    example_path = _Path(__file__).parent / ".env.example"
    if not env_path.exists() and example_path.exists():
        import shutil
        shutil.copy(example_path, env_path)
        print("\n" + "═" * 60)
        print("  📋 PRIMER ARRANQUE — archivo .env creado automáticamente")
        print("  Edita .env y reemplaza TU_API_KEY_AQUI con tu clave real:")
        print("    https://console.anthropic.com/")
        print("═" * 60 + "\n")

_setup_env_si_falta()

def main():
    parser = argparse.ArgumentParser(
        description="Agente VIRF — Validador de modelos LaR/VaR"
    )
    parser.add_argument("--titulo",              default=None,  help="Nombre del modelo")
    parser.add_argument("--tier",                default=None,  help="Tier del modelo (1, 2, 3, 4)")
    parser.add_argument("--excel",               default=None,  help="Ruta al Excel de controles (para pipeline Calidad de Datos)")
    parser.add_argument("--control",             action="store_true", help="Usar pipeline por CONTROL (Calidad de Datos)")
    parser.add_argument("--prdc",                action="store_true", help="Modo producción (genera Word)")
    parser.add_argument("--estadisticafeedback", action="store_true", help="Ver estadísticas de feedback")
    parser.add_argument("--limpiar-cache",       action="store_true", help="Limpiar caché de documentos y salir")
    parser.add_argument("--cache-stats",         action="store_true", help="Ver estadísticas del caché de documentos")
    parser.add_argument("--no-cache",            action="store_true", help="Deshabilitar caché para esta corrida")

    args = parser.parse_args()

    # ── Inicializar caché de documentos ───────────────────────────────────────
    # Habilitado solo en preprdc (no --prdc). En producción siempre fresco.
    es_preprdc = not args.prdc
    cache_activo = CACHE_ENABLED and es_preprdc and not args.no_cache
    cache = inicializar_cache(cache_dir=CACHE_DIR, enabled=cache_activo)

    if cache_activo:
        cache.purgar_huerfanos()
        print(f"  📦 Caché de documentos: ACTIVO ({len(cache._data)} entradas previas)")
    else:
        motivo = "producción (--prdc)" if args.prdc else \
                 ("--no-cache" if args.no_cache else "CACHE_ENABLED=0 en .env")
        print(f"  📦 Caché de documentos: INACTIVO [{motivo}]")

    # ── PRE-FLIGHT: validar API key antes de iniciar el pipeline ──────────────
    if not args.estadisticafeedback and not args.limpiar_cache and not args.cache_stats:
        print("  🔑 Verificando API key...", end=" ", flush=True)
        try:
            from config import get_cliente_ia
            cliente_test = get_cliente_ia()
            print("✅ OK")
        except ValueError as e:
            # Clave inválida, vacía o placeholder
            print("❌\n")
            print(str(e))
            sys.exit(1)
        except Exception as e:
            err_str = str(e)
            if "401" in err_str or "authentication" in err_str.lower():
                print("❌\n")
                print(
                    "❌ API key rechazada por Anthropic (Error 401).\n\n"
                    "   La clave configurada no es válida.\n"
                    "   Verifica en: https://console.anthropic.com/\n"
                    "   y actualiza ANTHROPIC_API_KEY en el archivo .env\n"
                )
                sys.exit(1)
            # Otro error de red/conexión → advertir pero continuar
            print(f"⚠️  {e}")

    # ── Comandos de gestión del caché ─────────────────────────────────────────
    if args.limpiar_cache:
        cache_mgr = inicializar_cache(cache_dir=CACHE_DIR, enabled=True)
        n = len(cache_mgr._data)
        cache_mgr.limpiar_todo()
        print(f"  🧹 Caché limpiado: {n} entradas eliminadas.")
        return

    if args.cache_stats:
        cache_mgr = inicializar_cache(cache_dir=CACHE_DIR, enabled=True)
        stats = cache_mgr.estadisticas()
        print("\n" + "═" * 60)
        print("  📦 ESTADÍSTICAS DEL CACHÉ DE DOCUMENTOS")
        print("═" * 60)
        ac = stats["acumulado"]
        print(f"  Total entradas en caché : {ac['total_entradas']}")
        print(f"  Hits históricos totales : {ac['hits_historicos']}")
        print(f"  Distribución por tipo   :")
        for tipo, n in sorted(ac["por_tipo"].items()):
            print(f"    {tipo:8s} → {n} archivos")
        print(f"\n  Archivo: {stats['archivo_cache']}")
        return

    args = parser.parse_args()

    # ═════════════════════════════════════════════════════════════════════════
    # MODO 1: Estadísticas
    # ═════════════════════════════════════════════════════════════════════════
    if args.estadisticafeedback:
        modo_estadistica_feedback()
        return

    # ═════════════════════════════════════════════════════════════════════════
    # MODO 2: Pipeline por CONTROL (Calidad de Datos)
    # ═════════════════════════════════════════════════════════════════════════
    if args.control:
        if not args.titulo:
            parser.error("--titulo es obligatorio")
        if not args.tier:
            parser.error("--tier es obligatorio (1, 2, 3, 4)")
        if not args.excel:
            parser.error("--excel es obligatorio (ruta al Excel de controles)")
        
        excel_path = Path(args.excel)
        if not excel_path.exists():
            print(f"  ❌ Error: {args.excel} no encontrado")
            sys.exit(1)
        
        fecha_informe = datetime.now().strftime("%Y-%m-%d")
        
        print("\n" + "═" * 70)
        print("  🔍 AGENTE VIRF — PIPELINE CALIDAD DE DATOS (POR CONTROL)")
        print(f"  Modelo: {args.titulo}")
        print(f"  Tier:   {args.tier}")
        print(f"  Modo:   {'PRODUCCIÓN (--prdc)' if args.prdc else 'PRE-PRODUCCIÓN'}")
        print("═" * 70 + "\n")
        
        try:
            resultado = orquestar_pipeline_virf(
                base_project_path=str(OUTPUTS_DIR.parent),
                excel_controles=str(excel_path),
                nombre_modelo=args.titulo,
                fecha_informe=fecha_informe,
                tier=str(args.tier),
                datasets_dict=None,
                filtro_controles=None,
            )
            
            print("\n" + "═" * 70)
            print("  ✅ PIPELINE CALIDAD DE DATOS COMPLETADO")
            print("═" * 70)
            print(f"\n  📊 RESULTADOS:")
            print(f"    • Controles evaluados: {resultado['controles_ok']}/{resultado['total_controles']}")
            print(f"    • Hallazgos críticos:  {resultado['hallazgos_criticos']}")
            print(f"    • Estado:              {resultado['estado']}")
            print(f"\n  📁 ARCHIVOS GENERADOS:")
            print(f"    • JSON:    {Path(resultado['ruta_json']).name}")
            if resultado.get("ruta_word"):
                print(f"    • Word:    {Path(resultado['ruta_word']).name}")
            print(f"    • Carpeta: {resultado['ruta_outputs']}")
            print("═" * 70 + "\n")
        
        except Exception as e:
            print(f"  ❌ Error en pipeline: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
        
        return
    
    # ═════════════════════════════════════════════════════════════════════════
    # MODO 3: Pipeline COMPLETO (Estandares_VIRF.xlsx + ControlesData.xlsx)
    # ═════════════════════════════════════════════════════════════════════════
    if not args.titulo:
        parser.error("--titulo es obligatorio")
    if not args.tier:
        parser.error("--tier es obligatorio (1, 2, 3, 4)")

    if not ESTANDARES_PATH.exists():
        print(f"  ❌ Error: {ESTANDARES_PATH} no encontrado")
        sys.exit(1)

    fecha_informe = datetime.now().strftime("%Y-%m-%d")
    tier_str = str(args.tier)

    print("\n" + "═" * 70)
    print("  🔍 AGENTE VIRF — PIPELINE TODOS LOS ÁMBITOS")
    print(f"  Modelo: {args.titulo}")
    print(f"  Tier:   {tier_str}")
    print(f"  Modo:   {'PRODUCCIÓN (--prdc)' if args.prdc else 'PRE-PRODUCCIÓN'}")
    print("═" * 70 + "\n")

    try:
        # 1. Cargar estándares VIRF (todos los ámbitos filtrados por tier)
        print("  📖 Cargando Estandares_VIRF.xlsx...")
        ambitos_data = leer_estandares_virf(tier_str)
        if not ambitos_data:
            print("  ❌ No se pudieron cargar los estándares VIRF. Verificar estructura del Excel.")
            sys.exit(1)

        # 2. Cargar todos los documentos de evidencia
        print("  📂 Cargando documentos de evidencia...")
        todos_inputs = cargar_todos_inputs()

        # 2b. [v20] Aplicar chunking inteligente en lote (capa de pipeline)
        #     ChunkerService recibe el cliente IA ya validado — separación de capas.
        from config import get_cliente_ia as _get_ia
        _chunker = ChunkerService(cliente_ia=_get_ia())
        todos_inputs = {
            ambito: _chunker.procesar_lote(docs, verbose=False)
            for ambito, docs in todos_inputs.items()
        }

        # 3. Preparar directorio de salida
        outputs_dir = OUTPUTS_DIR / fecha_informe
        outputs_dir.mkdir(parents=True, exist_ok=True)

        # 4. Evaluar cada ámbito
        resultados_ambitos = {}
        scores_ambitos = {}
        total_actividades = 0
        hallazgos_globales: list = []  # [v18] memoria inter-ámbito

        for ambito, actividades in ambitos_data.items():
            acts_requeridas = [a for a in actividades if a.get("requerida", True)]
            if not acts_requeridas:
                continue

            print(f"\n🔍 Evaluando {ambito} ({len(acts_requeridas)} actividades)...")
            total_actividades += len(acts_requeridas)

            docs_ambito = inputs_para_dimension(todos_inputs, ambito)

            # [D8-FIX] El límite anterior de [:5] descartaba evidencia silenciosamente.
            # Ahora: todos los documentos se incluyen hasta MAX_CHARS_DOC total.
            # Se loguea cuántos documentos y chars se incluyen/omiten.
            MAX_DOCS_AMBITO = int(os.getenv("VIRF_MAX_DOCS_AMBITO", "0")) or len(docs_ambito)
            docs_incluidos = docs_ambito[:MAX_DOCS_AMBITO]
            if len(docs_ambito) > len(docs_incluidos):
                print(f"  ⚠ [{ambito}] {len(docs_ambito) - len(docs_incluidos)} doc(s) omitidos "
                      f"(VIRF_MAX_DOCS_AMBITO={MAX_DOCS_AMBITO}). "
                      f"Ajusta la variable de entorno para incluirlos.")

            contexto_partes = []
            chars_acumulados = 0
            MAX_CTX_TOTAL = int(os.getenv("VIRF_MAX_CTX", str(MAX_CHARS_DOC)))
            for d in docs_incluidos:
                contenido = d.get("contenido", "")
                if chars_acumulados + len(contenido) > MAX_CTX_TOTAL and contexto_partes:
                    print(f"  ℹ [{ambito}] Contexto saturado en doc '{d['nombre']}' "
                          f"({chars_acumulados:,}/{MAX_CTX_TOTAL:,} chars). Resto omitido.")
                    break
                contexto_partes.append(f"[{d['nombre']}]\n{contenido}")
                chars_acumulados += len(contenido)
            contexto = "\n".join(contexto_partes)
            print(f"  📄 [{ambito}] {len(docs_incluidos)} doc(s) leídos — "
                  f"{chars_acumulados:,} chars incluidos en contexto")

            # [D3-FIX] Rechazar evaluación si el ámbito no tiene documentos.
            # Un agente evaluando sobre el vacío genera alucinaciones plausibles
            # que un auditor junior podría tomar como hallazgos verificados.
            if not docs_incluidos or chars_acumulados == 0:
                print(f"  ✗ [{ambito}] SIN DOCUMENTOS — evaluación rechazada.")
                print(f"    Agrega archivos en las carpetas correspondientes a este ámbito.")
                print(f"    El agente NO evalúa sobre el vacío (D3-FIX: anti-alucinación).")
                resultados_ambitos[ambito] = [{
                    "puntaje":               None,
                    "concepto":              "EVALUACIÓN NO REALIZADA — Sin evidencia",
                    "observacion":           (
                        f"El ámbito '{ambito}' no tiene documentos de entrada. "
                        "No es posible realizar una evaluación válida. "
                        "Por favor proporciona los documentos correspondientes antes de ejecutar."
                    ),
                    "evidencia_encontrada":  "",
                    "preguntas_pendientes":  [
                        f"¿Dónde se encuentran los documentos de evidencia para el ámbito '{ambito}'?"
                    ],
                    "recomendacion":         "Proporcionar los documentos de evidencia antes de la evaluación.",
                    "actividad":             "N/A — ámbito sin evidencia",
                    "control":               "N/A",
                    "sin_evidencia":         True,
                }]
                scores_ambitos[ambito] = None  # null en el JSON, no score arbitrario
                continue

            evals = evaluar_ambito_completo(
                ambito          = ambito,
                actividades     = acts_requeridas,
                contexto        = contexto,
                titulo_modelo   = args.titulo,
                modo_preprdc    = not args.prdc,
                contexto_global = hallazgos_globales,  # [v18] pasar memoria acumulada
            )

            resultados_ambitos[ambito] = evals
            scores_ambitos[ambito]     = calcular_score_ambito(evals)

            # [v18] Acumular hallazgos para los siguientes ámbitos
            for ev in evals:
                hallazgos_globales.append({
                    "ambito":     ambito,
                    "actividad":  ev.get("actividad", "")[:60],
                    "puntaje":    ev.get("puntaje"),
                    "observacion": ev.get("observacion", "")[:100],
                })

        # 5. ADICIONAL: controles de Calidad de Datos desde ControlesData.xlsx
        resultados_cdd = {}
        if CONTROLES_DATA_PATH.exists():
            print("\n🔍 Evaluando controles adicionales de CALIDAD DE DATOS (ControlesData.xlsx)...")
            resultados_cdd = evaluar_todos_controles(
                excel_controles=str(CONTROLES_DATA_PATH),
                base_project_path=str(OUTPUTS_DIR.parent),
                nombre_modelo=args.titulo,
                tier=tier_str,
            )
        else:
            print(f"  ℹ️  ControlesData.xlsx no encontrado en {CONTROLES_DATA_PATH}, omitiendo.")

        # 5b. Fusionar controles CDD con ámbito "Calidad de datos" (para Word conjunto)
        if resultados_cdd and resultados_cdd.get("resultados_por_control"):
            evals_cdd = []
            for ctrl_id, res in resultados_cdd["resultados_por_control"].items():
                estado         = res.get("estado", "ERROR")
                revision       = res.get("revision", "")
                hallazgos      = res.get("hallazgos") or []
                prompt_control = res.get("prompt_control", "")
                tipo_control   = res.get("tipo_control", "generico")
                tasa_error     = res.get("tasa_error", None)  # e.g. 0.001 = 0.1%

                # [D7-FIX] Calibración por criticidad y tasa de error real.
                # Antes: OK→4, ADVERTENCIA/ALERTA→3, ERROR→1 (hardcodeado, sin matices).
                # Ahora: el puntaje depende del estado Y de la tasa de hallazgos cuantificada.
                if estado == "OK":
                    puntaje = 5  # sin hallazgos → cumple plenamente
                elif estado in ("ADVERTENCIA", "ALERTA"):
                    # Calibrar por tasa de error si está disponible
                    if tasa_error is not None:
                        if tasa_error < 0.005:    # < 0.5% → obs. menores
                            puntaje = 4
                        elif tasa_error < 0.02:   # 0.5–2% → cumple parcialmente
                            puntaje = 3
                        elif tasa_error < 0.10:   # 2–10% → obs. críticas
                            puntaje = 2
                        else:                      # > 10% → no cumple
                            puntaje = 1
                    else:
                        # Sin tasa cuantificada: ADVERTENCIA=3, ALERTA=2
                        puntaje = 3 if estado == "ADVERTENCIA" else 2
                elif estado == "ERROR":
                    puntaje = 1
                else:
                    puntaje = 1  # desconocido → conservador

                # [D7-FIX] Registrar en log el criterio aplicado
                print(f"      CDD [{ctrl_id}] estado={estado} tasa={tasa_error} → puntaje={puntaje}")

                obs_parts = []
                for h in hallazgos[:5]:
                    obs_parts.append(h.get("descripcion", str(h)) if isinstance(h, dict) else str(h))
                observacion = " | ".join(obs_parts) if obs_parts else (
                    revision if revision and not revision.lower().startswith("error") else ""
                )
                concepto = (
                    revision if revision and not revision.lower().startswith("error")
                    else f"Control automático de calidad de datos: {ctrl_id}"
                )

                # Nombre de actividad: ID + resumen del prompt (primeras 120 chars)
                resumen_prompt = prompt_control[:120].strip()
                if len(prompt_control) > 120:
                    resumen_prompt += "..."
                actividad_label = f"{ctrl_id} — {resumen_prompt}" if resumen_prompt else ctrl_id

                evals_cdd.append({
                    "puntaje":              puntaje,
                    "concepto":             concepto,
                    "observacion":          observacion,
                    "evidencia_encontrada": "",
                    "preguntas_pendientes": [],
                    "recomendacion":        "",
                    "actividad":            actividad_label,
                    "control":              "Controles Automáticos de Calidad de Datos",
                })

            ambito_cdd = "Calidad de datos"
            if ambito_cdd not in resultados_ambitos:
                resultados_ambitos[ambito_cdd] = []
            resultados_ambitos[ambito_cdd].extend(evals_cdd)
            scores_ambitos[ambito_cdd] = calcular_score_ambito(resultados_ambitos[ambito_cdd])
            print(f"  ✓ {len(evals_cdd)} controles CDD fusionados en ámbito '{ambito_cdd}'")

        # 6. Score global y semáforo
        score_global = calcular_score_global(scores_ambitos)
        semaforo = get_semaforo(score_global)

        # 7. Guardar JSON con todos los resultados
        import json
        import hashlib

        # [v18] Metadatos de trazabilidad del agente
        # Permite auditar QUÉ versión del evaluador produjo CADA informe
        from motor.Mx_00_CargaRutas import MODELO_CLAUDE
        _prompt_sample = str(list(resultados_ambitos.keys()))[:200]
        _agente_meta = {
            "agente_version":   AGENTE_VERSION,
            "modelo_ia":        MODELO_CLAUDE,
            "proveedor_ia":     IA_PROVEEDOR,
            "pesos_ambito":     AMBITO_PESOS,
            "prompt_hash":      hashlib.sha256(_prompt_sample.encode()).hexdigest()[:12],
            "cache_activo":     cache_activo,
        }
        ruta_json = outputs_dir / f"resultados_{args.titulo}_{fecha_informe}.json"
        with open(ruta_json, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "modelo":                   args.titulo,
                    "tier":                     tier_str,
                    "fecha":                    fecha_informe,
                    "agente":                   _agente_meta,
                    "score_global":             score_global,
                    "semaforo":                 semaforo,
                    "scores_por_ambito":        scores_ambitos,
                    "resultados_por_ambito":    resultados_ambitos,
                    "controles_calidad_datos":  resultados_cdd,
                },
                f, ensure_ascii=False, indent=2, default=str,
            )

        # 8. Generar informe Word (solo en modo --prdc)
        ruta_word = None
        if args.prdc:
            print("\n📝 Generando resumen ejecutivo...")
            resumen = generar_resumen_ejecutivo(
                evaluaciones_por_ambito=resultados_ambitos,
                scores_por_ambito=scores_ambitos,
                score_global=score_global,
                titulo_modelo=args.titulo,
                tier=tier_str,
            )
            print("📝 Generando informe Word...")
            ruta_word = generar_word_informe(
                resumen_ejecutivo=resumen,
                evaluaciones_por_ambito=resultados_ambitos,
                scores_por_ambito=scores_ambitos,
                score_global=score_global,
                titulo_modelo=args.titulo,
                tier=tier_str,
                outputs_dir=outputs_dir,
            )

        # 9. Resumen final
        print("\n" + "═" * 70)
        print("  ✅ PIPELINE VIRF COMPLETADO")
        print("═" * 70)
        print(f"\n  📊 RESULTADOS:")
        print(f"    • Ámbitos evaluados:   {len(resultados_ambitos)}")
        print(f"    • Actividades totales: {total_actividades}")
        print(f"    • Score global:        {score_global:.2f}/5.0  [{semaforo.get('label', '')}]")
        for amb, sc in scores_ambitos.items():
            print(f"      - {amb:<35} {sc:.2f}")
        if resultados_cdd:
            cdd_ok    = resultados_cdd.get("controles_ok", 0)
            cdd_total = resultados_cdd.get("total_controles", 0)
            cdd_crit  = resultados_cdd.get("hallazgos_criticos", 0)
            print(f"    • Controles CDD:       {cdd_ok}/{cdd_total}  (hallazgos críticos: {cdd_crit})")
        print(f"\n  📁 ARCHIVOS GENERADOS:")
        print(f"    • JSON:    {ruta_json.name}")
        if ruta_word:
            print(f"    • Word:    {Path(ruta_word).name}")
        print(f"    • Carpeta: {outputs_dir}")
        print("═" * 70 + "\n")

        # 10. BUCLE DE FEEDBACK (solo si se ejecutó con --preprdc)
        if not args.prdc:
            print("\n" + "═" * 70)
            print("  📝 REGISTRO DE FEEDBACK")
            print("═" * 70)
            feedbacks_nuevos = bucle_feedback_consola(
                evaluaciones_por_ambito=resultados_ambitos,
                titulo_modelo=args.titulo,
                tier=tier_str,
                version="",
            )
            if feedbacks_nuevos:
                print(f"\n  ✅ Se registraron {len(feedbacks_nuevos)} correcciones.")
                print("  En la siguiente ejecución, el agente considerará este feedback.")
            print("=" * 70 + "\n")

    except Exception as e:
        print(f"  ❌ Error en pipeline: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        # ── Persistir caché y mostrar resumen de sesión ───────────────────
        cerrar_cache()


if __name__ == "__main__":
    main()
