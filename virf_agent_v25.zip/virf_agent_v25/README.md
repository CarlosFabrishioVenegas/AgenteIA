# 📊 VIRF — Validador Integral de Riesgo Financiero

**Agente Autónomo basado en Claude (Anthropic)**  
Auditor Senior Independiente para validación de modelos en riesgo financiero

---

## 📑 Tabla de Contenidos

1. [Descripción General](#1-descripción-general)
2. [Instalación Rápida](#2-instalación-rápida)
3. [Uso Básico](#3-uso-básico)
4. [Arquitectura del Sistema](#4-arquitectura-del-sistema)
5. [Pipelines Disponibles](#5-pipelines-disponibles)
6. [Sistema de Caché](#6-sistema-de-caché)
7. [Migración a Azure OpenAI](#7-migración-a-azure-openai)
8. [Deployment en Azure Cloud](#8-deployment-en-azure-cloud)
9. [Deployment en Databricks](#9-deployment-en-databricks)
10. [Troubleshooting](#10-troubleshooting)
11. [Referencia Completa](#11-referencia-completa)

---

## 1. Descripción General

VIRF evalúa el cumplimiento de estándares sobre 6 **ámbitos** de validación, cruzando documentación de evidencia con los criterios definidos por Tier. Produce resultados cuantificados (score 1–5), semáforos de riesgo y un informe Word narrativo.

### Dos pipelines complementarios

| Pipeline | Excel de entrada | Qué evalúa | Cuándo usar |
|----------|-----------------|-----------|-------------|
| **Pipeline 1 — Calidad de Datos** | `ControlesData.xlsx` | Controles granulares de calidad | Foco específico en datos |
| **Pipeline 2 — Todos los Ámbitos** | `Estandares_VIRF.xlsx` + `ControlesData.xlsx` | Los 6 ámbitos VIRF completos | Validación integral del modelo |

### Ámbitos evaluados (Pipeline 2)

| Ámbito | Peso en Score Global |
|--------|---------------------|
| Documentación | 20 % |
| Calidad de datos | 20 % |
| Metodología | 25 % |
| Gobierno | 10 % |
| Implementación | 15 % |
| Uso e integración a la gestión | 10 % |

---

## 2. Arquitectura del Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                         agente.py (CLI)                         │
│  MODO 1: --estadisticafeedback                                  │
│  MODO 2: --control  (Pipeline Calidad de Datos)                 │
│  MODO 3: (sin --control)  (Pipeline Todos los Ámbitos)          │
└────────────────────────┬────────────────────────────────────────┘
                         │
          ┌──────────────┴──────────────┐
          │                             │
┌─────────▼──────────┐       ┌──────────▼──────────┐
│   modulos/         │       │   motor/              │
│   (Negocio)        │       │   (Infraestructura)   │
│                    │       │                       │
│  motor_ia.py       │       │  Mx_00_CargaRutas     │
│  motor_ia_v2.py    │       │  Mx_01_LecturaEv.     │
│  generador_word.py │       │  Mx_02_Prompt         │
│  generador_excel.py│       │  Mx_03_LlamarIA       │
│  feedback.py       │       │  Mx_04_MotorData      │
│  ...               │       │  Mx_05_GeneradorWord  │
└────────────────────┘       └───────────────────────┘
          │                             │
          └──────────────┬──────────────┘
                         │
              ┌──────────▼──────────┐
              │   API Anthropic      │
              │  claude-sonnet-4-6   │
              └─────────────────────┘
```

### Principio de separación de responsabilidades

- **`motor/`** — Infraestructura pura: leer archivos, construir prompts, llamar API, generar Word. No contiene lógica de negocio VIRF.
- **`modulos/`** — Lógica de negocio: scoring, semáforos, orquestación de ámbitos, feedback.
- **`agente.py`** — Punto de entrada CLI: parsea argumentos y llama a los orquestadores correctos.

---

## 3. Estructura de Directorios

```
virf_v6_fixed/
│
├── agente.py                          ← PUNTO DE ENTRADA (CLI)
├── config.py                          ← Configuración centralizada
├── requirements.txt
├── .env                               ← Variables de entorno (no versionar)
├── .env.example
│
├── motor/                             ← INFRAESTRUCTURA (no tocar salvo extensión)
│   ├── Mx_00_CargaRutas.py           ← API key, rutas, constantes globales
│   ├── Mx_01_LecturaEvidencias.py    ← Lectura PDF/DOCX/PY/XLSX/etc.
│   ├── Mx_02_EstructuraPrompt.py     ← Construcción de prompts
│   ├── Mx_03_LlamarIA.py             ← Comunicación con API Anthropic
│   ├── Mx_04_MotorControlesData.py   ← Controles automáticos (pandas + regex)
│   └── Mx_05_GeneradorWord.py        ← Informe Word (pipeline control-based)
│
├── modulos/                           ← LÓGICA DE NEGOCIO
│   ├── __init__.py
│   ├── motor_ia.py                    ← Orquestador Pipeline 2 (ámbitos)
│   ├── motor_ia_v2.py                 ← Orquestador Pipeline 1 (controles)
│   ├── lector_inputs.py               ← Lectura unificada de archivos
│   ├── generador_excel.py             ← Excel con semáforos por ámbito
│   ├── generador_word.py              ← Word narrativo (Pipeline 2)
│   ├── generador_template.py          ← Carga de Estandares_VIRF.xlsx
│   ├── feedback.py                    ← Historial y estadísticas de feedback
│   └── generador_estadistica_feedback.py ← Informe de precisión del agente
│
├── inputs/                            ← DATOS DE ENTRADA
│   ├── Estandares_VIRF.xlsx           ← Estándares por Tier (Pipeline 2)
│   ├── documentacion/
│   │   ├── modelamiento/              ← Manual metodológico, manual operativo
│   │   └── seguimiento/               ← Backtesting, informes de seguimiento
│   ├── papers/                        ← Referencias académicas y regulatorias
│   ├── calidad_datos/
│   │   ├── ControlesData.xlsx         ← Config de controles (Pipeline 1)
│   │   └── _replica_virf.py           ← Script de control segunda línea
│   ├── implementacion/                ← Correos UAT, controles de implementación
│   └── usos/                          ← Actas de comité, reportes de uso
│
├── outputs/                           ← ARCHIVOS GENERADOS (auto-creado)
│   └── YYYY-MM-DD/
│       ├── resultados_<modelo>_<fecha>.json
│       ├── VIRF_Informe_<modelo>_<fecha>.docx
│       └── VIRF_Resultados_<modelo>_<fecha>.xlsx
│
├── feedback/                          ← HISTORIAL DE FEEDBACK (auto-creado)
│   └── historial_feedback.json
│
└── repositorio_informes/              ← INFORMES PREVIOS (contexto de aprendizaje)
```

---

## 4. Instalación y Configuración

### Requisitos
- Python 3.10+
- Cuenta Anthropic con API key activa

### Pasos

```bash
# 1. Crear entorno virtual
python -m venv venv
venv\Scripts\activate          # Windows
# source venv/bin/activate     # macOS/Linux

# 2. Instalar dependencias
pip install -r requirements.txt

# 3. Configurar API key
copy .env.example .env
# Editar .env y poner tu clave:
#   ANTHROPIC_API_KEY=sk-ant-...
```

### Variables de entorno (`.env`)

```env
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### Modelo configurado

El modelo se define en dos lugares (deben coincidir):

| Archivo | Variable | Valor actual |
|---------|----------|-------------|
| `config.py` | `MODEL_ID` | `claude-opus-4-5` |
| `motor/Mx_00_CargaRutas.py` | `MODELO_CLAUDE` | `claude-sonnet-4-6` |

Para cambiar de modelo, actualiza ambas variables. Los modelos disponibles son:

| Modelo | ID | Cuándo usar |
|--------|----|-------------|
| Claude Opus 4.7 | `claude-opus-4-7` | Máxima capacidad de razonamiento |
| Claude Sonnet 4.6 | `claude-sonnet-4-6` | Balance velocidad/calidad (recomendado) |
| Claude Haiku 4.5 | `claude-haiku-4-5-20251001` | Alta velocidad, menor costo |

---

## 5. Uso — Comandos CLI

```bash
# ─── PIPELINE 1: Calidad de Datos (por control) ──────────────────────────────
# Pre-producción (sin Word)
python agente.py --titulo "Modelo LaR" --tier 1 \
                 --excel inputs/calidad_datos/ControlesData.xlsx --control

# Producción (genera Word)
python agente.py --titulo "Modelo LaR" --tier 1 \
                 --excel inputs/calidad_datos/ControlesData.xlsx --control --prdc


# ─── PIPELINE 2: Todos los Ámbitos (completo) ────────────────────────────────
# Pre-producción
python agente.py --titulo "Modelo LaR" --tier 1

# Producción (genera Word)
python agente.py --titulo "Modelo LaR" --tier 1 --prdc


# ─── ESTADÍSTICAS DE PRECISIÓN ───────────────────────────────────────────────
python agente.py --estadisticafeedback
```

### Parámetros

| Parámetro | Tipo | Requerido | Descripción |
|-----------|------|-----------|-------------|
| `--titulo` | string | Sí (modos 2 y 3) | Nombre del modelo a evaluar |
| `--tier` | int/str | Sí (modos 2 y 3) | Tier: `1`, `2`, `3`, `4` o `I`, `II`, `III`, `IV` |
| `--excel` | path | Sí si `--control` | Ruta al Excel de controles |
| `--control` | flag | No | Activa Pipeline 1 (Calidad de Datos) |
| `--prdc` | flag | No | Genera informe Word (modo producción) |
| `--estadisticafeedback` | flag | No | Muestra estadísticas de precisión del agente |

---

## 6. Sistema de Cache de Documentos

### Descripcion

El **sistema de caché de documentos** (introducido en v15) reduce significativamente los tokens consumidos en cada corrida del agente durante la fase de **pre-producción**. 

**Problema que resuelve:**
- Leer y parsear PDFs grandes (50+ páginas), documentos Word, scripts Python consume tiempo y tokens.
- Si los documentos no cambiaron entre corridas, ese trabajo es innecesario.
- Un agente típicamente lee 10-15 documentos. Reutilizar el contenido ya parseado puede ahorrar **30-50% de tokens**.

**Solución:**
- Caché persistente en disco con claves basadas en SHA-256 (hash del contenido binario).
- Si un archivo no cambió (mismo hash), se sirve del caché.
- Si cambió o es nuevo, se parsea normalmente y se actualiza el caché.
- **Solo activo en pre-producción** (`--prdc` lo deshabilita para garantizar frescura).

### Archivos del Sistema

```
cache/
├── document_cache.json      ← Indice principal (1 entrada por archivo)
```

Cada entrada contiene:
- `hash_sha256`: SHA-256 del contenido binario del archivo
- `timestamp_fs`: Modificacion del archivo en disco
- `timestamp_cache`: Cuándo se cacheo el contenido
- `nombre`: Nombre del archivo
- `tipo`: Extensión del archivo (PDF, DOCX, PY, etc.)
- `contenido`: Texto parseado (hasta 500 KB)
- `chars_totales`: Longitud del contenido sin truncar
- `truncado`: Boolean indicando si se truncó
- `hits`: Contador de veces servido del caché (historicamente)
- `ultimo_hit`: Timestamp del último acceso

### Configuracion

En `Mx_00_CargaRutas.py`:

```python
CACHE_ENABLED = True      # O False para deshabilitar globalmente
CACHE_DIR    = "cache/"   # Donde guardar document_cache.json
```

O desde CLI:

```bash
# Ejecutar SIN caché esta vez (pero no lo limpia)
python agente.py --titulo "Modelo LaR" --tier 1 --no-cache

# Ver estadísticas del caché acumulado
python agente.py --cache-stats

# Limpiar el caché completamente
python agente.py --limpiar-cache
```

### Logica de Funcionamiento

```
┌──────────────────────────────────┐
│ leer_archivo(path)               │
│ (en Mx_01_LecturaEvidencias.py)  │
└────────────┬─────────────────────┘
             │
       ¿Cache habilitado?
        /        \
      NO          SI
      │           │
      │    Obtener hash SHA-256 del archivo
      │           │
      │    ¿Existe entrada en caché?
      │        /        \
      │      NO          SI
      │      │           │
      │      │    ¿Hash coincide?
      │      │      /        \
      │      │    NO          SI
      │      │    │           │
   Parsear  Parsear    ✅ CACHE HIT
   fresco   fresco     (devolver del caché)
      │      │           │
      │  Guardar en      │
      │  caché        Incrementar hits
      │      │           │
      └──────┴───────────┘
             │
        Devolver doc
```

### Monitoreo

La instancia del caché registra durante la sesion:

```
📦 Caché de documentos:
   ✅ Servidos del caché : 12 archivos
   🔄 Re-leídos del disco: 3 archivos
   ⚡ Tasa de acierto    : 80.0%
   💾 Total en caché     : 15 archivos
```

### Validacion y Debug

Para validar la lógica del caché, ejecutar:

```bash
python DEBUG_CACHE.py
```

Tests incluidos:
1. Inicializacion del caché
2. Cache HIT/MISS con archivos reales
3. Truncado correcto de contenido
4. Persistencia en disco
5. Purga de entradas huérfanas
6. Contadores de hits acumulados
7. Estadísticas completas
8. Invalidacion de entradas
9. Archivo no legible (fallback a caché)
10. Caché deshabilitado (modo producción)

Resultado esperado: **✅ 10 tests pasados**

### Impacto en Tokens

**Escenario típico** (documentacion + implementacion + seguimiento):
- 15 archivos a leer
- Promedio: 5-10 KB de contenido parseado por archivo
- Primera corrida: todos los archivos se parsean (fresco)
- Corridas subsecuentes (sin cambios): **~80% cache hit rate**

**Ahorro estimado:**
- 1ª corrida: 100K tokens
- 2ª-5ª corridas: ~20K tokens (20% de lectura fresca + parseo)
- **Ahorro acumulado en 5 corridas: 320K tokens (~68%)**

### Limpieza Manual

Si necesitas limpiar el caché:

```bash
# Opción 1: Comando CLI
python agente.py --limpiar-cache

# Opción 2: Borrar archivo manualmente
rm cache/document_cache.json

# Opción 3: Deshabilitar en config
# En Mx_00_CargaRutas.py: CACHE_ENABLED = False
```

---

## 7. Pipelines

### Pipeline 1 — Calidad de Datos (`--control`)

Evalúa controles granulares definidos en `ControlesData.xlsx`. Cada fila del Excel es un control independiente.

```
ControlesData.xlsx  (hoja: "Controles")
┌────────────┬───────────────────────────────┬──────────────┬──────────────┐
│ ID_CONTROL │ PROMPT_CONTROL                │ USA_MOTOR    │ TIPO_MOTOR   │
├────────────┼───────────────────────────────┼──────────────┼──────────────┤
│ Control_01 │ ¿Se verifica la unicidad de.. │      1       │  unicidad    │
│ Control_02 │ ¿Existen registros nulos en.. │      0       │              │
└────────────┴───────────────────────────────┴──────────────┴──────────────┘
```

**Flujo por control:**
1. Leer evidencia de `Evidencias/<ID_CONTROL>/` (manual + script)
2. Si `USA_MOTOR_DATA=1`: ejecutar control automático pandas (unicidad, etc.)
3. Construir prompt con evidencia + resultado motor
4. Llamar Claude → obtener revisión + hallazgos estructurados
5. Guardar `prompt_control` en el resultado para trazabilidad en el informe

**Columnas de `ControlesData.xlsx`:**

| Columna | Descripción |
|---------|-------------|
| `ID_CONTROL` | Identificador único del control |
| `PROMPT_CONTROL` | Pregunta que el agente debe responder |
| `USA_MOTOR_DATA` | `1` = ejecutar control automático pandas |
| `TIPO_MOTOR` | Tipo de control automático: `unicidad`, ... |
| `DATASET` | Nombre del dataset a validar |
| `GROUP_COLS` | Columnas de agrupación (separadas por coma) |
| `CAMPO_OBJETIVO` | Columna a validar |
| `UMBRAL` | Máximo de valores únicos permitidos por grupo |
| `ACCION` | Acción ante fallo |
| `ACTIVO` | `1` = incluir en evaluación |
| `COMENTARIO` | Notas opcionales |

---

### Pipeline 2 — Todos los Ámbitos (sin `--control`)

Evalúa los 6 ámbitos VIRF desde `Estandares_VIRF.xlsx`, filtrando por Tier. Adicionalmente, si existe `ControlesData.xlsx`, evalúa sus controles y **fusiona los resultados en el ámbito "Calidad de datos"** del informe Word.

```
Estandares_VIRF.xlsx  (hoja: "Hoja1", fila 1 = encabezado)
┌────────────────────┬────────────────────────────┬───────────────────┬────────┬─────────┐
│ AMBITO             │ CONTROL CUANT. Y CUALIT.    │ ACTIVIDAD         │ TIER I │ TIER II │
├────────────────────┼────────────────────────────┼───────────────────┼────────┼─────────┤
│ Documentación      │ Verificar Manual Met.       │ Verifica control  │   X    │    X    │
│ (merged)           │ (merged)                    │ de versiones      │        │         │
└────────────────────┴────────────────────────────┴───────────────────┴────────┴─────────┘
```

**Flujo completo:**
1. `leer_estandares_virf(tier)` → ámbitos con sus actividades filtradas por Tier
2. `cargar_todos_inputs()` → documentos de evidencia por carpeta
3. Para cada ámbito → `evaluar_ambito_completo()` → score 1–5 por actividad
4. `evaluar_todos_controles()` → controles CDD de `ControlesData.xlsx`
5. Fusionar controles CDD en ámbito "Calidad de datos" (para presentación conjunta en Word)
6. `calcular_score_global()` → score ponderado final
7. Guardar JSON + generar Word si `--prdc`

---

## 7. Archivos de Entrada

### Evidencia por carpetas (Pipeline 2)

| Carpeta | Contenido esperado | Ámbitos que la consumen |
|---------|--------------------|------------------------|
| `inputs/documentacion/modelamiento/` | Manual metodológico, manual operativo | Documentación, Metodología, Gobierno, Implementación |
| `inputs/documentacion/seguimiento/` | Backtesting, informes de seguimiento | Documentación, Metodología |
| `inputs/papers/` | Papers científicos, normas regulatorias | Metodología |
| `inputs/calidad_datos/` | Script `_replica_virf.py`, reportes de datos | Calidad de datos |
| `inputs/implementacion/` | Correos UAT, documentos de conformidad | Implementación, Gobierno |
| `inputs/usos/` | Actas de comité, reportes de integración | Uso e integración a la gestión |
| `repositorio_informes/` | Informes previos (contexto de referencia) | Todos los ámbitos |

### Formatos soportados

`.pdf` `.docx` `.pptx` `.xlsx` `.py` `.ipynb` `.sql` `.json` `.txt` `.csv` `.md`

### Evidencia para controles (Pipeline 1)

Para el Pipeline 1, cada control busca su evidencia en:

```
Evidencias/
└── <ID_CONTROL>/
    ├── manual_<nombre>.pdf     ← Manual o documentación del control
    └── script_<nombre>.py      ← Código o script asociado
```

El motor selecciona automáticamente el mejor manual y script usando scoring de nombres de archivo.

---

## 8. Archivos de Salida

Todos los outputs se guardan en `outputs/YYYY-MM-DD/`.

### `resultados_<modelo>_<fecha>.json`

```json
{
  "modelo": "Modelo LaR",
  "tier": "1",
  "fecha": "2026-05-04",
  "score_global": 3.75,
  "semaforo": {"label": "ACEPTABLE", "color": "92D050"},
  "scores_por_ambito": {
    "Documentación": 4.0,
    "Calidad de datos": 3.5
  },
  "resultados_por_ambito": {
    "Documentación": [
      {
        "actividad": "Verifica la existencia de control de cambios/versiones",
        "control": "Verificar la existencia del Manual Metodológico",
        "puntaje": 4,
        "concepto": "Se encontró manual metodológico con control de versiones...",
        "observacion": "...",
        "evidencia_encontrada": "...",
        "recomendacion": "...",
        "preguntas_pendientes": []
      }
    ]
  },
  "controles_calidad_datos": {
    "total_controles": 4,
    "controles_ok": 3,
    "controles_error": 1,
    "hallazgos_criticos": 0,
    "resultados_por_control": {
      "Control_01": {
        "control_id": "Control_01",
        "estado": "OK",
        "revision": "...",
        "hallazgos": [],
        "prompt_control": "¿Se verifica la unicidad de registros..."
      }
    }
  }
}
```

### `VIRF_Informe_<modelo>_<fecha>.docx`

Informe Word narrativo con:
- **Portada**: Título, Tier, fecha de emisión
- **Resumen Ejecutivo**: Tabla de scores por ámbito + score global con semáforo
- **Detalle por Ámbito**: Agrupado por Control → Actividades con campos:
  - Actividad evaluada
  - Concepto de actividad
  - Resultado (score/5 con color)
  - Evidencia encontrada
  - Observación / Hallazgo
  - Oportunidad de mejora
- **Controles Automáticos de Calidad de Datos**: Resultados de `ControlesData.xlsx` integrados dentro del ámbito "Calidad de datos"
- **Escala de evaluación**

---

## 9. Escalas y Pesos

### Escala de puntaje (1–5)

| Puntaje | Estado | Color |
|---------|--------|-------|
| 5 | Cumple plenamente | Verde `#00B050` |
| 4 | Cumple con observaciones menores | Verde claro `#92D050` |
| 3 | Cumple parcialmente | Amarillo `#FFCC00` |
| 2 | Cumple parcialmente — obs. críticas | Naranja `#FF6600` |
| 1 | No cumple | Rojo `#FF0000` |

### Semáforo global

| Rango | Estado | Color |
|-------|--------|-------|
| 4.5 – 5.0 | SATISFACTORIO | Verde |
| 3.5 – 4.5 | ACEPTABLE | Verde claro |
| 2.5 – 3.5 | CON OBSERVACIONES | Amarillo |
| 1.5 – 2.5 | DEFICIENTE | Naranja |
| 0.0 – 1.5 | CRÍTICO | Rojo |

### Modificar pesos de ámbitos

Editar en `config.py`:

```python
AMBITO_PESOS = {
    "Documentación":                  0.20,
    "Calidad de datos":               0.20,
    "Metodología":                    0.25,
    "Gobierno":                       0.10,
    "Implementación":                 0.15,
    "Uso e integración a la gestión": 0.10,
}
# Los pesos deben sumar 1.0
```

---

## 10. Detecciones Automáticas

El módulo `Mx_04_MotorControlesData.py` detecta automáticamente en scripts Python, **sin llamar a la API**:

| Clave | Tipo | Qué detecta |
|-------|------|------------|
| `outliers_zscore` | Presencia | Uso de Z-score para outliers — sugiere GESD, IQR robusto, Isolation Forest |
| `imputation_mean` | Presencia | Imputación con media — sugiere MICE, KNN, MissForest |
| `train_test_split_random` | Presencia | Split aleatorio en series temporales — riesgo de data leakage |
| `sin_psi` | Ausencia | Falta Population Stability Index (PSI) |
| `sin_backtesting_lar` | Ausencia | Falta Kupiec, Christoffersen, López |
| `sin_shap_modelos_complejos` | Ausencia | Modelos tree-based sin SHAP values |
| `sin_replica_virf` | Ausencia | Falta script `_replica_virf.py` de control segunda línea |

---

## 11. Cómo Agregar Nuevos Módulos

Esta sección describe los patrones para extender VIRF sin romper los pipelines existentes.

---

### 11.1 Agregar un nuevo tipo de control automático (motor data)

**Caso de uso:** validar `integridad_referencial` — que todos los clientes del dataset principal existan en el dataset de referencia.

**Paso 1** — Implementar la función en `motor/Mx_04_MotorControlesData.py`:

```python
def ejecutar_control_integridad_referencial(
    df_principal: pd.DataFrame,
    df_referencia: pd.DataFrame,
    col_fk: str,
    col_pk: str,
) -> Dict[str, Any]:
    valores_fk  = set(df_principal[col_fk].dropna().unique())
    valores_pk  = set(df_referencia[col_pk].dropna().unique())
    huerfanos   = valores_fk - valores_pk

    return {
        "estado":              "PASA" if not huerfanos else "NO PASA",
        "registros_huerfanos": len(huerfanos),
        "muestra_huerfanos":   list(huerfanos)[:10],
    }
```

**Paso 2** — Registrar en `ejecutar_motor_data_por_fila()` del mismo archivo:

```python
elif cfg["tipo_motor"] == "integridad_referencial":
    df_ref = datasets_dict.get(cfg.get("dataset_referencia", ""))
    if df_ref is None:
        return {"tipo_motor": "integridad_referencial", "estado": "ERROR",
                "error": "dataset_referencia no encontrado"}
    return ejecutar_control_integridad_referencial(
        df, df_ref,
        col_fk=cfg["campo_objetivo"],
        col_pk=cfg.get("campo_pk", "id"),
    )
```

**Paso 3** — Agregar la fila en `ControlesData.xlsx`:

```
ID_CONTROL | PROMPT_CONTROL                           | USA_MOTOR_DATA | TIPO_MOTOR               | ACTIVO
Control_05 | ¿Todos los clientes del dataset existen..| 1              | integridad_referencial   | 1
```

No se requieren cambios en ningún otro archivo.

---

### 11.2 Agregar un nuevo ámbito VIRF

**Caso de uso:** agregar el ámbito "Ciberseguridad" con sus actividades y un peso de 5%.

**Paso 1** — Agregar el peso en `config.py` (ajustar los demás para que sumen 1.0):

```python
AMBITO_PESOS = {
    # ... existentes ajustados ...
    "Ciberseguridad": 0.05,
}
```

**Paso 2** — Agregar la carpeta de inputs en `config.py`:

```python
INPUTS = {
    # ... existentes ...
    "ciberseguridad": BASE_DIR / "inputs" / "ciberseguridad",
}
```

**Paso 3** — Mapear ámbito → carpetas en `motor/Mx_00_CargaRutas.py`:

```python
AMBITO_A_INPUTS = {
    # ... existentes ...
    "Ciberseguridad": ["ciberseguridad", "implementacion"],
}

INSTRUCCIONES_DIMENSION = {
    # ... existentes ...
    "Ciberseguridad": "Revisar políticas de acceso, logs de auditoría y controles de seguridad...",
}
```

**Paso 4** — Agregar actividades en `Estandares_VIRF.xlsx`: insertar filas con el nuevo ámbito en la columna `AMBITO` y marcar con `X` los Tiers aplicables.

**Paso 5** — Crear la carpeta de evidencia:

```
inputs/
└── ciberseguridad/
    └── (colocar aquí los documentos de evidencia)
```

---

### 11.3 Agregar un nuevo generador de salida

**Caso de uso:** exportar resultados a PowerPoint además de Word y Excel.

**Paso 1** — Crear `modulos/generador_pptx.py` con la misma firma que los demás generadores:

```python
"""modulos/generador_pptx.py — Genera presentación PowerPoint de resultados VIRF."""

from pathlib import Path
from typing import Dict, List
from datetime import datetime
from pptx import Presentation

def generar_pptx_informe(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    scores_por_ambito: Dict[str, float],
    score_global: float,
    titulo_modelo: str,
    tier: str,
    outputs_dir: Path,
) -> Path:
    """Genera VIRF_Presentacion_<modelo>_<fecha>.pptx."""
    prs = Presentation()
    fecha_str = datetime.now().strftime("%d%m%Y")
    # ... implementación de diapositivas ...
    ruta = outputs_dir / f"VIRF_Presentacion_{titulo_modelo.replace(' ','_')}_{fecha_str}.pptx"
    prs.save(ruta)
    return ruta
```

**Paso 2** — Importar y llamar desde `agente.py` junto al Word:

```python
# En agente.py, dentro del bloque if args.prdc:
from modulos.generador_pptx import generar_pptx_informe
ruta_pptx = generar_pptx_informe(
    evaluaciones_por_ambito=resultados_ambitos,
    scores_por_ambito=scores_ambitos,
    score_global=score_global,
    titulo_modelo=args.titulo,
    tier=tier_str,
    outputs_dir=outputs_dir,
)
print(f"    • PPTX:    {ruta_pptx.name}")
```

---

### 11.4 Agregar un nuevo modo de ejecución (CLI)

**Caso de uso:** modo `--batch` para procesar varios modelos desde un CSV.

**Paso 1** — Agregar el argumento en `agente.py`:

```python
parser.add_argument("--batch", default=None,
                    help="CSV con columnas: titulo,tier para procesar varios modelos")
```

**Paso 2** — Extraer la lógica del MODO 3 a una función `_evaluar_modelo(titulo, tier, prdc)` y agregar el bloque batch antes del MODO 3:

```python
if args.batch:
    import csv
    with open(args.batch, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            _evaluar_modelo(titulo=row["titulo"], tier=row["tier"], prdc=args.prdc)
    return
```

---

### 11.5 Agregar una nueva detección automática de código

**Caso de uso:** detectar ausencia de semilla aleatoria (`random_state`) — resultados no reproducibles.

Solo editar el diccionario en `motor/Mx_00_CargaRutas.py`, sin cambiar ningún otro archivo:

```python
CUESTIONAMIENTOS_METODOLOGICOS = {
    # ... existentes ...

    "sin_random_state": {
        "detectar":          ["random_state", "seed(", "np.random.seed"],
        "detectar_ausencia": True,   # True = alerta si el patrón NO está presente
        "contexto":          "No se encontró fijación de semilla aleatoria — resultados no reproducibles",
        "critica":           True,
    },
}
```

---

### 11.6 Cambiar el prompt del agente

El rol y las instrucciones del agente están en `motor/Mx_00_CargaRutas.py`:

```python
ROL_AGENTE = """Actúas como Auditor Senior en Validación Independiente de Modelos (VIRF).
Eres experto en modelos financieros estocásticos y de machine learning...
"""
```

Para ajustar el tono o añadir especialización (p. ej. IFRS 17, Solvencia II), edita directamente esa variable. El cambio aplica a todas las llamadas de ambos pipelines.

Para instrucciones específicas por ámbito, editar `INSTRUCCIONES_DIMENSION` en el mismo archivo.

---

## 12. Referencia de Módulos

### `motor/Mx_00_CargaRutas.py` — Constantes globales

| Variable | Descripción |
|----------|-------------|
| `API_KEY` | Leída de `ANTHROPIC_API_KEY` |
| `MODELO_CLAUDE` | Modelo de IA a usar |
| `MAX_TOKENS` | Máximo de tokens por llamada (4000) |
| `RUTAS` | Paths a inputs, outputs y repositorio |
| `UMBRAL_RIESGO_GLOBAL` | Umbral % sin evidencia para riesgo global (0.30) |
| `AMBITO_A_INPUTS` | Mapeo ámbito → carpetas de evidencia |
| `INSTRUCCIONES_DIMENSION` | Pautas específicas por ámbito |
| `ROL_AGENTE` | Prompt de sistema del auditor |
| `CUESTIONAMIENTOS_METODOLOGICOS` | Patrones de detección automática |

---

### `motor/Mx_01_LecturaEvidencias.py` — Lectura de archivos

| Función | Descripción |
|---------|-------------|
| `leer_archivo_generico(ruta)` | Lee cualquier formato soportado → str |
| `compilar_textos_de_carpeta(base, subfolder)` | Compila todos los docs de una subcarpeta → str |
| `obtener_evidencia_por_control(base, ctrl_id)` | Lee `Evidencias/<ctrl_id>/` |
| `obtener_conocimiento_por_modelo(base, modelo)` | Lee contexto del modelo |
| `detectar_manual_y_script(carpeta)` | Detecta mejor manual y script por scoring de nombre |
| `leer_estandares_virf(tier)` | Lee `Estandares_VIRF.xlsx` filtrado por Tier con forward-fill |
| `cargar_todos_inputs()` | Lee todas las carpetas de evidencia → dict |
| `inputs_para_dimension(docs, dimension)` | Filtra documentos por ámbito |

---

### `motor/Mx_04_MotorControlesData.py` — Controles automáticos

| Función | Descripción |
|---------|-------------|
| `ejecutar_control_unicidad(df, group_cols, campo_objetivo, umbral)` | Unicidad por grupo |
| `ejecutar_motor_data_por_fila(row, datasets_dict)` | Dispatcher según `TIPO_MOTOR` |
| `convertir_resultado_data_a_texto(resultado)` | Formatea resultado para insertar en prompt |
| `detectar_cuestionamientos(documentos)` | Análisis estático de scripts Python |
| `calcular_riesgo_global(resultados)` | Métricas globales de riesgo |

---

### `modulos/motor_ia.py` — Orquestador Pipeline 2

| Función | Descripción |
|---------|-------------|
| `leer_estandares_virf(tier)` | Carga actividades de `Estandares_VIRF.xlsx` |
| `cargar_todos_inputs()` | Carga documentos de evidencia |
| `inputs_para_dimension(todos_inputs, ambito)` | Filtra inputs por ámbito |
| `evaluar_ambito_completo(ambito, actividades, contexto, ...)` | Evalúa un ámbito completo vía IA |
| `calcular_score_ambito(evaluaciones)` | Score promedio de un ámbito |
| `calcular_score_global(scores_por_ambito)` | Score global ponderado |
| `get_semaforo(score)` | Semáforo según rango de score |
| `generar_resumen_ejecutivo(...)` | Genera texto narrativo vía IA |

---

### `modulos/motor_ia_v2.py` — Orquestador Pipeline 1

| Función | Descripción |
|---------|-------------|
| `evaluar_control(ctrl_id, prompt_control, ...)` | Evalúa un control individual |
| `evaluar_todos_controles(excel_controles, ...)` | Itera y evalúa todos los controles del Excel |
| `generar_informe_final(resultados, outputs_dir, ...)` | Word para Pipeline 1 |
| `orquestar_pipeline_virf(...)` | Orquestador completo Pipeline 1 |

---

### `modulos/generador_word.py` — Informe Word

| Función | Firma | Descripción |
|---------|-------|-------------|
| `generar_word_informe` | `(resumen_ejecutivo, evaluaciones_por_ambito, scores_por_ambito, score_global, titulo_modelo, tier, outputs_dir) → Path` | Genera el `.docx` completo — **firma fija, no cambiar** |
| `generar_word_informe_desde_json` | `(formato_data, outputs_dir, titulo_modelo) → Path` | Alternativa: genera desde dict JSON estructurado |

---

### `modulos/feedback.py` — Feedback y estadísticas

| Función | Descripción |
|---------|-------------|
| `bucle_feedback_consola(...)` | Bucle interactivo post-evaluación para registrar feedback |
| `construir_contexto_feedback(ambito, actividad)` | Recupera historial relevante para enriquecer prompts |
| `calcular_estadisticas()` | Calcula MAE, precisión exacta, sesgo y breakdown por ámbito |

---

## 13. Dependencias

```
anthropic>=0.25.0          # API Anthropic
python-docx>=0.8.11        # Generación Word
openpyxl>=3.1.0            # Lectura/escritura Excel
pdfplumber>=0.10.0         # Extracción texto PDF
python-pptx>=0.6.21        # Lectura PowerPoint
pandas>=2.0.0              # Análisis de datos
python-dotenv>=1.0.0       # Variables de entorno
requests>=2.31.0           # Llamadas HTTP (fallback)
```

```bash
pip install -r requirements.txt
```

---

## Notas de Implementación

**Celdas fusionadas en Excel** — `leer_estandares_virf()` aplica forward-fill sobre las columnas `AMBITO` y `CONTROL CUANTITATIVO Y CUALITATIVO` para manejar las celdas fusionadas que openpyxl devuelve como `None`.

**Normalización de Tier** — El motor acepta `"1"`, `"2"`, `"3"`, `"4"` o `"I"`, `"II"`, `"III"`, `"IV"`. Internamente siempre convierte a romano (`_TIER_MAP`) para buscar la columna correcta en `Estandares_VIRF.xlsx`.

**Fusión CDD en Word** — Los controles de `ControlesData.xlsx` se convierten al mismo formato dict de evaluación que los ámbitos de `Estandares_VIRF.xlsx` y se insertan en `evaluaciones_por_ambito["Calidad de datos"]` antes de llamar a `generar_word_informe()`. Esto permite presentarlos conjuntamente sin modificar el generador Word.

**Manejo de errores de API** — Si la llamada a la IA falla (401, timeout, JSON inválido), el pipeline no se detiene: registra el error en `observacion`, asigna puntaje 1, y el Word reemplaza automáticamente los mensajes de error con recomendaciones genéricas legibles vía `_es_error()` + `_generar_recomendacion_automatica()`.

**Trazabilidad del prompt** — El campo `prompt_control` se guarda en cada resultado de `evaluar_todos_controles()`. En el Word, el nombre de la actividad muestra `Control_XX — <resumen del prompt>` para que el informe sea autoexplicativo sin consultar el Excel.
