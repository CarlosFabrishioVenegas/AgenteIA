# 🔑 Cómo Obtener tus Credenciales de Azure OpenAI

## 📋 Paso 1: Obtener API Key y Endpoint

1. **Abre Azure Portal**: https://portal.azure.com/

2. **Busca tu recurso Azure OpenAI**:
   - En la barra de búsqueda superior, escribe: `Azure OpenAI`
   - Haz clic en tu recurso (ej: `credicorp-openai`, `desarrollo-openai`, etc.)

3. **Abre "Keys and Endpoint"** (o "Claves y punto de conexión"):
   - En el menú izquierdo, ve a: **Keys and endpoint**
   - Verás algo así:

   ```
   Key 1:  DO8xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   Key 2:  DO8yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy
   
   Endpoint: https://credicorp-openai.openai.azure.com/
   ```

4. **Copia los valores**:
   - **AZURE_OPENAI_API_KEY** = `DO8xxxxxxxx...` (Key 1 o Key 2)
   - **AZURE_OPENAI_ENDPOINT** = `https://credicorp-openai.openai.azure.com/` (termina con `/`)

---

## 🤖 Paso 2: Obtener el Nombre del Deployment

El **deployment** es el nombre exacto del modelo que creaste en Azure.

### Opción A: Desde Azure Portal (Recomendado)

1. En tu recurso Azure OpenAI
2. Menú izquierdo → **Deployments** (o "Model deployments")
3. Busca un deployment activo:
   - Verás una tabla con columnas: **Deployment name**, Status, Model, Version
   - **Copia el valor exacto de "Deployment name"**

   Ejemplos típicos en corporativos:
   ```
   OAIDEU2-GPT4
   OAIEUS2-TURBO  
   OAISEA2-AZURE
   deployment-gpt-4-turbo
   credicorp-gpt4-v1
   ```

### Opción B: Usando Azure CLI (Si tienes instalado)

```bash
# Requiere: Azure CLI instalado y autenticado
az cognitiveservices account deployment list \
  --resource-group TU_GRUPO_RECURSOS \
  --name TU_RECURSO_OPENAI
```

---

## ✏️ Paso 3: Editar el archivo `.env`

Una vez tengas los 3 valores:

1. **Abre** el archivo `.env` en la raíz del proyecto:
   ```
   c:\...\virf_agent_v24\.env
   ```

2. **Reemplaza estas 3 líneas**:

   ```properties
   # ❌ ANTES (placeholders):
   AZURE_OPENAI_API_KEY=DO8_REEMPLAZA_CON_TU_API_KEY_REAL_AQUI
   AZURE_OPENAI_ENDPOINT=https://REEMPLAZA_CON_TU_RECURSO.openai.azure.com/
   AZURE_OPENAI_DEPLOYMENT=REEMPLAZA_CON_TU_DEPLOYMENT
   
   # ✅ DESPUÉS (valores reales):
   AZURE_OPENAI_API_KEY=DO8xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   AZURE_OPENAI_ENDPOINT=https://credicorp-openai.openai.azure.com/
   AZURE_OPENAI_DEPLOYMENT=OAIDEU2-GPT4
   ```

3. **Guarda el archivo** (Ctrl+S)

---

## ✅ Paso 4: Validar la Configuración

Ejecuta el test para verificar que todo está correcto:

```powershell
python test_azure_config.py
```

**Resultado esperado**:
```
✅ .env encontrado
✅ IA_PROVEEDOR = azure_openai
✅ AZURE_OPENAI_API_KEY configurada: DO8...xxxxx
✅ AZURE_OPENAI_ENDPOINT: https://credicorp-openai.openai.azure.com/
✅ AZURE_OPENAI_DEPLOYMENT: OAIDEU2-GPT4
✅ Conexión exitosa a Azure OpenAI ✓
✅ Respuesta recibida: ...

✅ TODAS las validaciones pasaron
```

---

## ⚠️ Problemas Comunes

| Error | Causa | Solución |
|-------|-------|----------|
| `APIConnectionError` | Endpoint incorrecto | Verifica formato: `https://nombre.openai.azure.com/` (con `/`) |
| `401 Unauthorized` | API Key inválida | Copia nuevamente desde Azure Portal, Key 1 o Key 2 |
| `404 Not Found` | Deployment no existe | Verifica que el deployment existe en "Deployments" en Azure |
| `contains placeholder` | No reemplazaste los valores | Edita `.env` y reemplaza `REEMPLAZA_CON_...` con valores reales |

---

## 🔒 Seguridad: Mantén tus credenciales seguras

- ✅ El archivo `.env` está en `.gitignore` (no se sube a Git)
- ✅ Nunca compartas el contenido del `.env`
- ✅ Si comprometes las credenciales, regenera las API Keys en Azure Portal
- ✅ Usa Key Vault de Azure en producción

---

## 📞 Soporte

Si tienes problemas, revisa:
1. `docs/GUIA_AZURE_OPENAI.md` (documentación completa)
2. El error exacto que devuelve `test_azure_config.py`
3. Que el recurso Azure OpenAI esté **en estado "OK"** (en Azure Portal)
4. Que el deployment tenga estado **"Succeeded"**

¡Listo! Una vez completes esto, el agente VIRF debería conectarse sin problemas a Azure OpenAI. 🚀
