"""
inputs/calidad_datos/_replica_virf.py
Script de segunda línea para control de calidad de datos del modelo LaR/VIRF.
Valida: missing values, duplicados, outliers, consistencia temporal y actualización.

Uso:
  python _replica_virf.py --input <archivo.xlsx o .csv> [--output reporte.xlsx]
"""

import argparse
import sys
import json
from pathlib import Path
from datetime import datetime

import pandas as pd
import numpy as np

try:
    import openpyxl
    from openpyxl.styles import PatternFill, Font, Alignment
    XLSX_OK = True
except ImportError:
    XLSX_OK = False


# ─── Umbrales configurables ───────────────────────────────────────────────────
UMBRAL_MISSING_PCT   = 5.0    # % máximo de missing permitido por columna
UMBRAL_OUTLIER_ZSCORE = 3.5   # Z-score para detección de outliers
UMBRAL_ACTUALIZACION_DIAS = 30  # Días máximos sin actualización


# ─── Pruebas de calidad ───────────────────────────────────────────────────────

def test_missing(df: pd.DataFrame) -> dict:
    """Detecta missing values por columna."""
    total_filas = len(df)
    resultados = {}
    for col in df.columns:
        n_missing = df[col].isna().sum()
        pct = (n_missing / total_filas * 100) if total_filas > 0 else 0
        resultados[col] = {
            "n_missing": int(n_missing),
            "pct_missing": round(pct, 2),
            "status": "ALERTA" if pct > UMBRAL_MISSING_PCT else "OK"
        }
    return resultados


def test_duplicados(df: pd.DataFrame) -> dict:
    """Detecta filas duplicadas exactas y duplicados por clave."""
    n_dup_exactos = int(df.duplicated().sum())
    # Intentar detectar columna de fecha/id para duplicados de clave
    posibles_id = [c for c in df.columns if any(k in c.lower() for k in ["id","fecha","date","periodo","key"])]
    dup_por_clave = {}
    for col in posibles_id[:3]:
        n = int(df[col].duplicated().sum())
        dup_por_clave[col] = {"n_duplicados": n, "status": "ALERTA" if n > 0 else "OK"}

    return {
        "duplicados_exactos": n_dup_exactos,
        "status_exactos": "ALERTA" if n_dup_exactos > 0 else "OK",
        "duplicados_por_clave": dup_por_clave
    }


def test_outliers_zscore(df: pd.DataFrame) -> dict:
    """Detecta outliers en columnas numéricas usando Z-score."""
    numericas = df.select_dtypes(include=[np.number]).columns.tolist()
    resultados = {}
    for col in numericas:
        serie = df[col].dropna()
        if len(serie) < 10:
            continue
        media = serie.mean()
        std   = serie.std()
        if std == 0:
            continue
        z_scores = np.abs((serie - media) / std)
        n_outliers = int((z_scores > UMBRAL_OUTLIER_ZSCORE).sum())
        pct = round(n_outliers / len(serie) * 100, 2)
        resultados[col] = {
            "n_outliers": n_outliers,
            "pct_outliers": pct,
            "media": round(float(media), 6),
            "std": round(float(std), 6),
            "max_zscore": round(float(z_scores.max()), 4),
            "status": "ALERTA" if n_outliers > 0 else "OK"
        }
    return resultados


def test_consistencia_temporal(df: pd.DataFrame) -> dict:
    """Verifica continuidad y orden en columnas de fecha."""
    col_fecha = None
    for c in df.columns:
        if any(k in c.lower() for k in ["fecha","date","periodo","time"]):
            try:
                df[c] = pd.to_datetime(df[c])
                col_fecha = c
                break
            except Exception:
                continue

    if col_fecha is None:
        return {"status": "NO_APLICA", "mensaje": "No se encontró columna de fecha"}

    serie_fecha = df[col_fecha].dropna().sort_values()
    n_total = len(serie_fecha)

    # Gaps temporales
    diffs = serie_fecha.diff().dropna()
    moda_diff = diffs.mode()[0] if len(diffs) > 0 else pd.Timedelta(0)
    n_gaps = int((diffs > moda_diff * 2).sum())

    # Verificar orden
    desordenadas = int((diffs < pd.Timedelta(0)).sum())

    # Actualización
    ultima_fecha = serie_fecha.max()
    dias_sin_actualizar = (datetime.now() - ultima_fecha).days if pd.notna(ultima_fecha) else 9999

    return {
        "columna_fecha": col_fecha,
        "fecha_min": str(serie_fecha.min()),
        "fecha_max": str(ultima_fecha),
        "n_registros": n_total,
        "frecuencia_modal": str(moda_diff),
        "n_gaps_temporales": n_gaps,
        "n_registros_desordenados": desordenadas,
        "dias_desde_ultima_actualizacion": dias_sin_actualizar,
        "status_gaps": "ALERTA" if n_gaps > 0 else "OK",
        "status_orden": "ALERTA" if desordenadas > 0 else "OK",
        "status_actualizacion": "ALERTA" if dias_sin_actualizar > UMBRAL_ACTUALIZACION_DIAS else "OK"
    }


def test_rango_valores(df: pd.DataFrame) -> dict:
    """Estadísticas descriptivas de columnas numéricas para validar rangos razonables."""
    numericas = df.select_dtypes(include=[np.number]).columns.tolist()
    resultados = {}
    for col in numericas:
        serie = df[col].dropna()
        if len(serie) == 0:
            continue
        resultados[col] = {
            "min": round(float(serie.min()), 6),
            "max": round(float(serie.max()), 6),
            "media": round(float(serie.mean()), 6),
            "mediana": round(float(serie.median()), 6),
            "std": round(float(serie.std()), 6),
            "n_negativos": int((serie < 0).sum()),
            "n_ceros": int((serie == 0).sum()),
            "n_inf": int(np.isinf(serie).sum()),
            "status": "ALERTA" if np.isinf(serie).sum() > 0 else "OK"
        }
    return resultados


def test_tipos_datos(df: pd.DataFrame) -> dict:
    """Verifica coherencia de tipos de datos por columna."""
    resultados = {}
    for col in df.columns:
        dtype = str(df[col].dtype)
        # Detectar columnas numéricas almacenadas como string
        if dtype == "object":
            sample = df[col].dropna().head(10)
            try:
                pd.to_numeric(sample)
                alerta = True
                mensaje = "Columna numérica almacenada como texto"
            except (ValueError, TypeError):
                alerta = False
                mensaje = "OK"
        else:
            alerta = False
            mensaje = "OK"
        resultados[col] = {"dtype": dtype, "status": "ALERTA" if alerta else "OK", "mensaje": mensaje}
    return resultados


# ─── Reporte Excel ────────────────────────────────────────────────────────────

def generar_reporte_excel(resultados: dict, ruta_salida: Path):
    if not XLSX_OK:
        print("[WARN] openpyxl no disponible, generando JSON en su lugar.")
        ruta_json = ruta_salida.with_suffix(".json")
        with open(ruta_json, "w", encoding="utf-8") as f:
            json.dump(resultados, f, ensure_ascii=False, indent=2, default=str)
        print(f"  JSON guardado: {ruta_json}")
        return

    import openpyxl
    from openpyxl.styles import PatternFill, Font, Alignment
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Reporte Calidad Datos"
    ws.sheet_view.showGridLines = False

    HEADER_FILL = PatternFill("solid", fgColor="1F3864")
    ALERT_FILL  = PatternFill("solid", fgColor="FF0000")
    OK_FILL     = PatternFill("solid", fgColor="00B050")
    WARN_FILL   = PatternFill("solid", fgColor="FFCC00")
    ALT_FILL    = PatternFill("solid", fgColor="EBF3FB")

    def hdr(ws, row, col, val, width=20):
        c = ws.cell(row, col, val)
        c.font = Font(bold=True, color="FFFFFF", size=9, name="Arial")
        c.fill = HEADER_FILL
        c.alignment = Alignment(horizontal="center", wrap_text=True)
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width
        return c

    def celda_status(ws, row, col, val):
        c = ws.cell(row, col, val)
        c.fill = ALERT_FILL if "ALERTA" in str(val) else OK_FILL
        c.font = Font(bold=True, color="FFFFFF", size=9, name="Arial")
        c.alignment = Alignment(horizontal="center")
        return c

    row = 1
    ws.merge_cells(f"A{row}:H{row}")
    c = ws.cell(row, 1, f"REPORTE DE CALIDAD DE DATOS — {resultados.get('archivo','N/A')} — {resultados.get('fecha_ejecucion','')}")
    c.font = Font(bold=True, color="FFFFFF", size=12, name="Arial")
    c.fill = HEADER_FILL
    c.alignment = Alignment(horizontal="center")
    ws.row_dimensions[row].height = 28
    row += 2

    # Missing values
    ws.merge_cells(f"A{row}:H{row}")
    ws.cell(row, 1, "1. MISSING VALUES").font = Font(bold=True, size=11, name="Arial", color="1F3864")
    row += 1
    hdr(ws, row, 1, "COLUMNA", 30); hdr(ws, row, 2, "N° MISSING", 15)
    hdr(ws, row, 3, "% MISSING", 15); hdr(ws, row, 4, "STATUS", 15)
    row += 1
    for col_name, info in resultados.get("missing", {}).items():
        fill = ALT_FILL if row % 2 == 0 else PatternFill("solid", fgColor="FFFFFF")
        ws.cell(row, 1, col_name).fill = fill
        ws.cell(row, 2, info["n_missing"]).fill = fill
        ws.cell(row, 3, f"{info['pct_missing']}%").fill = fill
        celda_status(ws, row, 4, info["status"])
        row += 1
    row += 1

    # Duplicados
    dup = resultados.get("duplicados", {})
    ws.merge_cells(f"A{row}:H{row}")
    ws.cell(row, 1, "2. DUPLICADOS").font = Font(bold=True, size=11, name="Arial", color="1F3864")
    row += 1
    ws.cell(row, 1, "Duplicados exactos:")
    ws.cell(row, 2, dup.get("duplicados_exactos", 0))
    celda_status(ws, row, 3, dup.get("status_exactos", "OK"))
    row += 1
    for col_dup, info in dup.get("duplicados_por_clave", {}).items():
        ws.cell(row, 1, f"  Clave: {col_dup}")
        ws.cell(row, 2, info["n_duplicados"])
        celda_status(ws, row, 3, info["status"])
        row += 1
    row += 1

    # Outliers
    ws.merge_cells(f"A{row}:H{row}")
    ws.cell(row, 1, "3. OUTLIERS (Z-score)").font = Font(bold=True, size=11, name="Arial", color="1F3864")
    row += 1
    hdr(ws, row, 1, "COLUMNA", 30); hdr(ws, row, 2, "N° OUTLIERS", 15)
    hdr(ws, row, 3, "% OUTLIERS", 15); hdr(ws, row, 4, "MAX Z-SCORE", 15); hdr(ws, row, 5, "STATUS", 15)
    row += 1
    for col_name, info in resultados.get("outliers", {}).items():
        fill = ALT_FILL if row % 2 == 0 else PatternFill("solid", fgColor="FFFFFF")
        ws.cell(row, 1, col_name).fill = fill
        ws.cell(row, 2, info["n_outliers"]).fill = fill
        ws.cell(row, 3, f"{info['pct_outliers']}%").fill = fill
        ws.cell(row, 4, info["max_zscore"]).fill = fill
        celda_status(ws, row, 5, info["status"])
        row += 1
    row += 1

    # Consistencia temporal
    temp = resultados.get("consistencia_temporal", {})
    ws.merge_cells(f"A{row}:H{row}")
    ws.cell(row, 1, "4. CONSISTENCIA TEMPORAL").font = Font(bold=True, size=11, name="Arial", color="1F3864")
    row += 1
    for k, v in temp.items():
        if k != "columna_fecha":
            ws.cell(row, 1, k)
            if "status" in k.lower():
                celda_status(ws, row, 2, str(v))
            else:
                ws.cell(row, 2, str(v))
            row += 1
    row += 1

    # Resumen ejecutivo
    ws.merge_cells(f"A{row}:H{row}")
    ws.cell(row, 1, "5. RESUMEN EJECUTIVO").font = Font(bold=True, size=11, name="Arial", color="1F3864")
    row += 1
    alertas_total = resultados.get("total_alertas", 0)
    ws.cell(row, 1, "Total alertas detectadas:")
    c = ws.cell(row, 2, alertas_total)
    c.fill = ALERT_FILL if alertas_total > 0 else OK_FILL
    c.font = Font(bold=True, color="FFFFFF", size=11, name="Arial")

    ruta_salida.parent.mkdir(parents=True, exist_ok=True)
    wb.save(ruta_salida)
    print(f"  ✓ Reporte guardado: {ruta_salida}")


# ─── Función principal ────────────────────────────────────────────────────────

def ejecutar_pruebas(ruta_input: Path) -> dict:
    """Carga el archivo y ejecuta todas las pruebas de calidad."""
    print(f"\n{'═'*55}")
    print(f"  🔬 CONTROL DE CALIDAD DE DATOS — Segunda Línea")
    print(f"  Archivo: {ruta_input.name}")
    print(f"  Fecha  : {datetime.now().strftime('%d/%m/%Y %H:%M')}")
    print(f"{'═'*55}\n")

    # Cargar datos
    ext = ruta_input.suffix.lower()
    try:
        if ext in (".xlsx", ".xlsm"):
            df = pd.read_excel(ruta_input)
        elif ext == ".csv":
            df = pd.read_csv(ruta_input, encoding="utf-8")
        else:
            print(f"[ERROR] Formato no soportado: {ext}")
            sys.exit(1)
    except Exception as e:
        print(f"[ERROR] No se pudo cargar {ruta_input}: {e}")
        sys.exit(1)

    print(f"  Filas cargadas: {len(df):,}  |  Columnas: {len(df.columns)}")
    print(f"  Columnas: {', '.join(df.columns.tolist()[:10])}{'...' if len(df.columns) > 10 else ''}\n")

    # Ejecutar pruebas
    print("  Ejecutando pruebas...")
    resultados = {
        "archivo": ruta_input.name,
        "fecha_ejecucion": datetime.now().strftime("%d/%m/%Y %H:%M"),
        "n_filas": len(df),
        "n_columnas": len(df.columns),
        "columnas": df.columns.tolist(),
        "missing":               test_missing(df),
        "duplicados":            test_duplicados(df),
        "outliers":              test_outliers_zscore(df),
        "consistencia_temporal": test_consistencia_temporal(df),
        "rangos_valores":        test_rango_valores(df),
        "tipos_datos":           test_tipos_datos(df),
    }

    # Contar alertas
    def contar_alertas(d):
        count = 0
        if isinstance(d, dict):
            for k, v in d.items():
                if k == "status" and "ALERTA" in str(v):
                    count += 1
                elif isinstance(v, (dict, list)):
                    count += contar_alertas(v)
        elif isinstance(d, list):
            for item in d:
                count += contar_alertas(item)
        return count

    resultados["total_alertas"] = contar_alertas(resultados)

    print(f"\n  ⚠️  Total alertas: {resultados['total_alertas']}")
    return resultados


def main():
    parser = argparse.ArgumentParser(description="Control de calidad de datos LaR/VIRF — Segunda línea")
    parser.add_argument("--input",  required=True, help="Ruta al archivo de datos (.xlsx, .csv)")
    parser.add_argument("--output", default=None,  help="Ruta del reporte de salida (.xlsx)")
    args = parser.parse_args()

    ruta_input = Path(args.input)
    if not ruta_input.exists():
        print(f"[ERROR] Archivo no encontrado: {ruta_input}")
        sys.exit(1)

    resultados = ejecutar_pruebas(ruta_input)

    # Determinar salida
    if args.output:
        ruta_salida = Path(args.output)
    else:
        fecha = datetime.now().strftime("%d%m%Y")
        ruta_salida = ruta_input.parent / f"QC_{ruta_input.stem}_{fecha}.xlsx"

    print("\n  Generando reporte Excel...")
    generar_reporte_excel(resultados, ruta_salida)
    print(f"\n  ✅ Control de calidad completado.\n")


if __name__ == "__main__":
    main()
