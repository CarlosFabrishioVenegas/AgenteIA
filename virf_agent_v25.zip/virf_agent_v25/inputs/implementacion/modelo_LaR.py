"""
implementacion/modelo_LaR.py
═══════════════════════════════════════════════════════════════════════════════
Modelo de Liquidez en Riesgo (LaR) — Simulador de Flujos de Caja bajo Estrés
─────────────────────────────────────────────────────────────────────────────
Metodología : Historical Simulation + Monte Carlo Hybrid
Versión     : 1.0
Fecha       : 2025-01-15
Validado    : VIRF Tier III
═══════════════════════════════════════════════════════════════════════════════

Estructura del modelo:
    1. CashflowEngine      ← Generación de flujos por categoría
    2. StressEngine        ← Aplicación de shocks por escenario
    3. LaRModel            ← Cálculo del LaR y métricas auxiliares
    4. ReportGenerator     ← Salida de resultados a DataFrame / Excel

Escenarios:
    - BASE       : sin perturbación
    - MILD       : estrés leve  (retiro depósitos 5%,  líneas crédito -10%)
    - MODERATE   : estrés moderado (15%, -25%)
    - SEVERE     : estrés severo   (30%, -50%) — análoga a crisis 2008/2020

Uso rápido:
    >>> from modelo_LaR import LaRModel
    >>> m = LaRModel(seed=42)
    >>> resultados = m.run(horizon_days=30, n_simulations=10_000)
    >>> print(resultados.summary())
"""

import numpy as np
import pandas as pd
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from datetime import date, timedelta
import warnings

warnings.filterwarnings("ignore", category=FutureWarning)


# ═══════════════════════════════════════════════════════════════════════════
# PARÁMETROS GLOBALES
# ═══════════════════════════════════════════════════════════════════════════

CONFIDENCE_LEVELS = [0.90, 0.95, 0.99]

SCENARIO_PARAMS: Dict[str, Dict] = {
    "BASE": {
        "deposit_withdrawal_rate": 0.00,
        "credit_line_haircut":     0.00,
        "asset_fire_sale_haircut": 0.00,
        "interbank_rollover_prob": 1.00,
        "description": "Condiciones de mercado normales sin perturbaciones."
    },
    "MILD": {
        "deposit_withdrawal_rate": 0.05,
        "credit_line_haircut":     0.10,
        "asset_fire_sale_haircut": 0.03,
        "interbank_rollover_prob": 0.90,
        "description": "Estrés leve: tensión idiosincrática menor, confianza preservada."
    },
    "MODERATE": {
        "deposit_withdrawal_rate": 0.15,
        "credit_line_haircut":     0.25,
        "asset_fire_sale_haircut": 0.10,
        "interbank_rollover_prob": 0.70,
        "description": "Estrés moderado: deterioro de confianza y tensión sistémica parcial."
    },
    "SEVERE": {
        "deposit_withdrawal_rate": 0.30,
        "credit_line_haircut":     0.50,
        "asset_fire_sale_haircut": 0.20,
        "interbank_rollover_prob": 0.40,
        "description": "Estrés severo: crisis sistémica, equivalente a evento 2008/COVID-2020."
    },
}


# ═══════════════════════════════════════════════════════════════════════════
# DATA CLASSES
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class BalanceSheet:
    """Hoja de balance simplificada para el modelo (en miles de USD)."""
    # ACTIVOS
    cash_and_equivalents:     float = 500_000
    government_bonds:         float = 800_000
    corporate_bonds:          float = 400_000
    loans_retail:             float = 1_200_000
    loans_corporate:          float = 900_000
    interbank_assets:         float = 300_000
    # PASIVOS
    retail_deposits:          float = 1_500_000
    corporate_deposits:       float = 700_000
    interbank_liabilities:    float = 400_000
    credit_lines_committed:   float = 600_000
    bonds_issued:             float = 500_000
    # PATRIMONIO
    equity:                   float = 600_000


@dataclass
class CashflowProfile:
    """Perfil de flujos de caja por bucket temporal (días)."""
    buckets:    List[int]   = field(default_factory=lambda: [1, 7, 14, 30])
    inflows:    np.ndarray  = field(default_factory=lambda: np.zeros(4))
    outflows:   np.ndarray  = field(default_factory=lambda: np.zeros(4))

    @property
    def net(self) -> np.ndarray:
        return self.inflows - self.outflows

    @property
    def cumulative_net(self) -> np.ndarray:
        return np.cumsum(self.net)


@dataclass
class LaRResult:
    """Resultado de una corrida del modelo."""
    scenario:       str
    horizon:        int
    n_simulations:  int
    lar_values:     Dict[float, float]   # confidence_level → LaR (USD miles)
    expected_shortfall: Dict[float, float]
    lcr:            float                 # Liquidity Coverage Ratio
    nsfr:           float                 # Net Stable Funding Ratio
    survival_days:  float                 # días mediana antes de insolvencia
    simulated_gaps: np.ndarray            # distribución de gaps acumulados

    def summary(self) -> pd.DataFrame:
        rows = []
        for cl in CONFIDENCE_LEVELS:
            rows.append({
                "Escenario":              self.scenario,
                "Horizonte (días)":       self.horizon,
                "N Simulaciones":         self.n_simulations,
                "Nivel de Confianza":     f"{int(cl*100)}%",
                "LaR (USD miles)":        round(self.lar_values.get(cl, 0), 1),
                "Expected Shortfall":     round(self.expected_shortfall.get(cl, 0), 1),
                "LCR (%)":                round(self.lcr * 100, 2),
                "NSFR (%)":               round(self.nsfr * 100, 2),
                "Días Supervivencia":     round(self.survival_days, 1),
            })
        return pd.DataFrame(rows)


# ═══════════════════════════════════════════════════════════════════════════
# MOTOR DE FLUJOS DE CAJA
# ═══════════════════════════════════════════════════════════════════════════

class CashflowEngine:
    """
    Genera flujos de caja estocásticos por categoría.

    Metodología:
        - Flujos contractuales: deterministas por vencimiento
        - Componentes de comportamiento: procesos estocásticos calibrados
          con datos históricos (2015-2024) de entidades comparables.
        - Volatilidad de depósitos: proceso GARCH(1,1) implícito
    """

    def __init__(self, balance: BalanceSheet, rng: np.random.Generator):
        self.bal = balance
        self.rng = rng

    def generate_inflows(
        self, horizon: int, n_sims: int
    ) -> np.ndarray:
        """
        Genera matriz (n_sims x horizon) de inflows diarios (USD miles).

        Componentes:
            a) Repagos de préstamos retail   ~ LogNormal(μ_r, σ_r)
            b) Repagos de préstamos corp     ~ LogNormal(μ_c, σ_c)
            c) Cobros de bonos corp          : determinista + ruido Normal
            d) Ingresos interbancarios       : determinista
        """
        n = n_sims
        h = horizon

        # a) Retail loan repayments
        daily_retail = self.bal.loans_retail / 365
        retail_inflows = self.rng.lognormal(
            mean=np.log(daily_retail * 0.95),
            sigma=0.08,
            size=(n, h)
        )

        # b) Corporate loan repayments (más concentrados y volátiles)
        daily_corp = self.bal.loans_corporate / 365
        corp_inflows = self.rng.lognormal(
            mean=np.log(daily_corp * 0.90),
            sigma=0.18,
            size=(n, h)
        )

        # c) Bond portfolio coupons (determinista + ruido pequeño)
        daily_coupon = (self.bal.government_bonds * 0.045
                        + self.bal.corporate_bonds * 0.065) / 365
        coupon_inflows = daily_coupon + self.rng.normal(0, daily_coupon * 0.02, size=(n, h))
        coupon_inflows = np.clip(coupon_inflows, 0, None)

        # d) Interbank assets rollover (binomial: renueva o no)
        daily_ib_asset = self.bal.interbank_assets / 30
        ib_renewal = self.rng.binomial(1, 0.85, size=(n, h))
        ib_inflows = ib_renewal * daily_ib_asset

        return retail_inflows + corp_inflows + coupon_inflows + ib_inflows

    def generate_outflows(
        self, horizon: int, n_sims: int
    ) -> np.ndarray:
        """
        Genera matriz (n_sims x horizon) de outflows diarios (USD miles).

        Componentes:
            a) Retiros de depósitos retail   ~ LogNormal con drift
            b) Retiros de depósitos corp     ~ Normal truncada
            c) Vencimiento pasivos interb.   : determinista
            d) Amortización bonos emitidos   : determinista
        """
        n = n_sims
        h = horizon

        # a) Depósitos retail: tasa de run-off diaria ~0.3% en base
        daily_retail_out = self.bal.retail_deposits * 0.003
        retail_outflows = self.rng.lognormal(
            mean=np.log(daily_retail_out),
            sigma=0.12,
            size=(n, h)
        )

        # b) Depósitos corporativos (mayor volatilidad)
        daily_corp_out = self.bal.corporate_deposits * 0.005
        corp_outflows = np.maximum(
            self.rng.normal(daily_corp_out, daily_corp_out * 0.20, size=(n, h)),
            0
        )

        # c) Vencimiento interbancario (pesos según madurez promedio 30d)
        daily_ib_mat = self.bal.interbank_liabilities / 30
        ib_outflows = np.full((n, h), daily_ib_mat)

        # d) Amortización bonos (uniforme en horizonte)
        daily_bond_out = self.bal.bonds_issued / 365
        bond_outflows = np.full((n, h), daily_bond_out)

        return retail_outflows + corp_outflows + ib_outflows + bond_outflows


# ═══════════════════════════════════════════════════════════════════════════
# MOTOR DE ESTRÉS
# ═══════════════════════════════════════════════════════════════════════════

class StressEngine:
    """
    Aplica shocks de estrés a los flujos base.

    Metodología:
        Los shocks siguen la guía de Basel III (BCBS 238) y las
        directrices de la CMF Chile para pruebas de tensión de liquidez.
        Se aplican factores multiplicativos por categoría de flujo.
    """

    def __init__(self, params: Dict):
        self.p = params

    def apply(
        self,
        inflows:  np.ndarray,
        outflows: np.ndarray,
        balance:  BalanceSheet,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Devuelve (stressed_inflows, stressed_outflows).
        """
        p = self.p
        n, h = inflows.shape

        stressed_in  = inflows.copy()
        stressed_out = outflows.copy()

        # 1. Reducción de inflows (menor renovación de cartera)
        stressed_in  *= (1 - p["asset_fire_sale_haircut"])

        # 2. Aumento de outflows por retiros de depósitos
        extra_deposit_outflow = (
            balance.retail_deposits * p["deposit_withdrawal_rate"]
            + balance.corporate_deposits * p["deposit_withdrawal_rate"] * 1.5
        ) / 30  # distribuido en 30d
        stressed_out += extra_deposit_outflow

        # 3. Haircut en líneas de crédito comprometidas
        credit_loss = (
            balance.credit_lines_committed * p["credit_line_haircut"] / 30
        )
        stressed_out += credit_loss

        # 4. No renovación interbancaria (salida adicional)
        ib_non_rollover_prob = 1 - p["interbank_rollover_prob"]
        ib_shock = balance.interbank_liabilities * ib_non_rollover_prob / 30
        stressed_out += ib_shock

        return stressed_in, stressed_out


# ═══════════════════════════════════════════════════════════════════════════
# MODELO LaR PRINCIPAL
# ═══════════════════════════════════════════════════════════════════════════

class LaRModel:
    """
    Modelo de Liquidez en Riesgo (LaR).

    Parámetros
    ----------
    balance   : BalanceSheet  (usa valores por defecto si no se provee)
    seed      : int           (reproducibilidad)

    Ejemplo
    -------
    >>> model = LaRModel(seed=42)
    >>> resultados = model.run_all_scenarios(horizon_days=30, n_simulations=5000)
    >>> for r in resultados.values():
    ...     print(r.summary())
    """

    def __init__(
        self,
        balance:  Optional[BalanceSheet] = None,
        seed:     int = 42,
    ):
        self.balance = balance or BalanceSheet()
        self.rng     = np.random.default_rng(seed)

    def run(
        self,
        scenario:       str = "BASE",
        horizon_days:   int = 30,
        n_simulations:  int = 10_000,
    ) -> LaRResult:
        """
        Ejecuta una corrida para un escenario dado.

        Returns
        -------
        LaRResult con LaR, ES, LCR, NSFR y distribución simulada.
        """
        if scenario not in SCENARIO_PARAMS:
            raise ValueError(f"Escenario '{scenario}' no reconocido. "
                             f"Opciones: {list(SCENARIO_PARAMS.keys())}")

        params = SCENARIO_PARAMS[scenario]
        cf_engine    = CashflowEngine(self.balance, self.rng)
        stress_engine = StressEngine(params)

        # Generar flujos base
        base_in  = cf_engine.generate_inflows(horizon_days, n_simulations)
        base_out = cf_engine.generate_outflows(horizon_days, n_simulations)

        # Aplicar estrés
        s_in, s_out = stress_engine.apply(base_in, base_out, self.balance)

        # Gap diario y acumulado
        daily_gap    = s_in - s_out                    # (n_sims x horizon)
        cumulative   = np.cumsum(daily_gap, axis=1)    # (n_sims x horizon)
        gap_at_T     = cumulative[:, -1]               # (n_sims,) → gap final

        # LaR y Expected Shortfall
        lar_values, es_values = self._calculate_lar(gap_at_T)

        # LCR (Liquidity Coverage Ratio) — Basel III
        lcr = self._calculate_lcr(params)

        # NSFR (Net Stable Funding Ratio) — Basel III
        nsfr = self._calculate_nsfr()

        # Días de supervivencia (mediana)
        survival_days = self._calculate_survival_days(cumulative)

        return LaRResult(
            scenario=scenario,
            horizon=horizon_days,
            n_simulations=n_simulations,
            lar_values=lar_values,
            expected_shortfall=es_values,
            lcr=lcr,
            nsfr=nsfr,
            survival_days=survival_days,
            simulated_gaps=gap_at_T,
        )

    def run_all_scenarios(
        self,
        horizon_days:  int = 30,
        n_simulations: int = 10_000,
    ) -> Dict[str, LaRResult]:
        """Ejecuta todos los escenarios y retorna dict escenario → LaRResult."""
        results = {}
        for sc in SCENARIO_PARAMS:
            print(f"  → Corriendo escenario {sc}...")
            results[sc] = self.run(
                scenario=sc,
                horizon_days=horizon_days,
                n_simulations=n_simulations,
            )
        return results

    # ─── Métricas internas ──────────────────────────────────────────────────

    def _calculate_lar(
        self, gap_distribution: np.ndarray
    ) -> Tuple[Dict[float, float], Dict[float, float]]:
        """
        LaR al percentil (1 - α) de la distribución de gaps.
        Expected Shortfall = media de pérdidas más allá del LaR.
        """
        lar, es = {}, {}
        for cl in CONFIDENCE_LEVELS:
            threshold = np.percentile(gap_distribution, (1 - cl) * 100)
            lar[cl]   = -threshold  # positivo = déficit
            tail_vals  = gap_distribution[gap_distribution <= threshold]
            es[cl]    = -tail_vals.mean() if len(tail_vals) > 0 else 0.0
        return lar, es

    def _calculate_lcr(self, stress_params: Dict) -> float:
        """
        LCR = HQLA / Net Cash Outflows (30 días).
        Heurística simplificada con haircuts de Basel III.
        """
        hqla = (
            self.balance.cash_and_equivalents * 1.00   # Level 1
            + self.balance.government_bonds   * 0.85   # Level 1
            + self.balance.corporate_bonds    * 0.75   # Level 2A
        )
        nco = (
            self.balance.retail_deposits      * (0.05 + stress_params["deposit_withdrawal_rate"])
            + self.balance.corporate_deposits * (0.10 + stress_params["deposit_withdrawal_rate"])
            + self.balance.interbank_liabilities * (1 - stress_params["interbank_rollover_prob"])
            + self.balance.credit_lines_committed * stress_params["credit_line_haircut"]
        )
        return hqla / nco if nco > 0 else float("inf")

    def _calculate_nsfr(self) -> float:
        """
        NSFR = Available Stable Funding / Required Stable Funding.
        """
        asf = (
            self.balance.equity                * 1.00
            + self.balance.retail_deposits     * 0.95
            + self.balance.corporate_deposits  * 0.50
            + self.balance.bonds_issued        * 1.00
        )
        rsf = (
            self.balance.cash_and_equivalents  * 0.00
            + self.balance.government_bonds    * 0.05
            + self.balance.corporate_bonds     * 0.50
            + self.balance.loans_retail        * 0.85
            + self.balance.loans_corporate     * 1.00
        )
        return asf / rsf if rsf > 0 else float("inf")

    def _calculate_survival_days(self, cumulative_gaps: np.ndarray) -> float:
        """
        Días mediana hasta que el gap acumulado cruza cero (insolvencia de liquidez).
        Si nunca cruza cero → retorna horizon_days.
        """
        horizon = cumulative_gaps.shape[1]
        survival = []
        for sim in cumulative_gaps:
            crossing = np.where(sim < 0)[0]
            survival.append(crossing[0] if len(crossing) > 0 else horizon)
        return float(np.median(survival))


# ═══════════════════════════════════════════════════════════════════════════
# GENERADOR DE REPORTES
# ═══════════════════════════════════════════════════════════════════════════

class ReportGenerator:
    """Genera resúmenes tabulares y exporta a Excel."""

    def __init__(self, results: Dict[str, LaRResult]):
        self.results = results

    def to_dataframe(self) -> pd.DataFrame:
        """DataFrame consolidado de todos los escenarios."""
        frames = [r.summary() for r in self.results.values()]
        return pd.concat(frames, ignore_index=True)

    def to_excel(self, path: str = "outputs/LaR_Resultados.xlsx") -> None:
        """Exporta resultados + distribuciones a Excel con múltiples hojas."""
        from pathlib import Path
        Path(path).parent.mkdir(parents=True, exist_ok=True)

        with pd.ExcelWriter(path, engine="openpyxl") as writer:
            # Hoja 1: Resumen ejecutivo
            self.to_dataframe().to_excel(writer, sheet_name="Resumen", index=False)

            # Hoja 2-5: distribuciones por escenario
            for sc, res in self.results.items():
                dist_df = pd.DataFrame({
                    "Gap_Simulado_USD_miles": res.simulated_gaps
                })
                dist_df.to_excel(
                    writer,
                    sheet_name=f"Dist_{sc}"[:31],
                    index=False
                )

        print(f"  ✓ Reporte exportado: {path}")


# ═══════════════════════════════════════════════════════════════════════════
# PUNTO DE ENTRADA
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 65)
    print("  MODELO LaR — Liquidity at Risk Cashflow Stress Simulator")
    print("  Versión 1.0  |  VIRF Tier III  |  2025-01-15")
    print("=" * 65)

    # Instanciar balance de ejemplo
    balance = BalanceSheet(
        cash_and_equivalents=500_000,
        government_bonds=800_000,
        corporate_bonds=400_000,
        loans_retail=1_200_000,
        loans_corporate=900_000,
        interbank_assets=300_000,
        retail_deposits=1_500_000,
        corporate_deposits=700_000,
        interbank_liabilities=400_000,
        credit_lines_committed=600_000,
        bonds_issued=500_000,
        equity=600_000,
    )

    model = LaRModel(balance=balance, seed=42)

    print("\n[1/3] Ejecutando simulaciones (10,000 trayectorias × 4 escenarios)...")
    results = model.run_all_scenarios(horizon_days=30, n_simulations=10_000)

    print("\n[2/3] Resultados por escenario:")
    print("─" * 65)
    for sc, res in results.items():
        df = res.summary()
        print(f"\n  ▶  Escenario: {sc}")
        print(f"     {SCENARIO_PARAMS[sc]['description']}")
        for _, row in df.iterrows():
            print(
                f"     [{row['Nivel de Confianza']}]  "
                f"LaR = {row['LaR (USD miles)']:>12,.1f}  |  "
                f"ES = {row['Expected Shortfall']:>12,.1f}  |  "
                f"LCR = {row['LCR (%)']:>6.2f}%  |  "
                f"NSFR = {row['NSFR (%)']:>6.2f}%  |  "
                f"Supervivencia = {row['Días Supervivencia']:.1f}d"
            )

    print("\n[3/3] Exportando a Excel...")
    reporter = ReportGenerator(results)
    reporter.to_excel("outputs/LaR_Resultados.xlsx")

    print("\n✓ Proceso completado exitosamente.")
    print("─" * 65)
