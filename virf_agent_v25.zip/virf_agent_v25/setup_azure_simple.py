#!/usr/bin/env python3
"""
setup_azure_simple.py - Configuración SUPER SIMPLE de Azure OpenAI

¡SIN COMPLICACIONES! Solo ingresa tus 3 valores y listo.

Uso:
    python setup_azure_simple.py
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Cargar .env actual
env_path = Path(__file__).parent / ".env"
load_dotenv(env_path)

print("\n" + "═" * 80)
print("🔧 CONFIGURACIÓN SIMPLE AZURE OPENAI")
print("═" * 80)

print("""
Necesitas 3 cosas de tu Azure Portal. Te ayudaré a ingresarlas.

┌────────────────────────────────────────────────────────────────────────┐
│ 1. API KEY                                                             │
│    - Ve a: https://portal.azure.com/                                   │
│    - Busca: Azure OpenAI → Tu recurso                                  │
│    - Menu: Keys and endpoint → Copia "Key 1" o "Key 2"                 │
│    - Formato: Empieza con DO8... (muy largo, ~48 caracteres)          │
└────────────────────────────────────────────────────────────────────────┘
""")

api_key = input("📋 Pega tu API Key (DO8...): ").strip()

if not api_key:
    print("❌ API Key vacía. Abortando.")
    exit(1)

if "REEMPLAZA" in api_key or api_key.startswith("DO8_"):
    print("❌ Eso sigue siendo un placeholder. Usa tu clave REAL.")
    exit(1)

print("\n✅ API Key ingresada\n")

print("""
┌────────────────────────────────────────────────────────────────────────┐
│ 2. ENDPOINT                                                            │
│    - En Azure Portal, sección "Keys and endpoint"                      │
│    - Busca "Endpoint" (no "Key")                                       │
│    - Formato: https://NOMBRE.openai.azure.com/                         │
│    - IMPORTANTE: Termina con /  (barra final obligatoria)             │
└────────────────────────────────────────────────────────────────────────┘
""")

endpoint = input("🌐 Pega tu Endpoint (https://...): ").strip()

if not endpoint:
    print("❌ Endpoint vacío. Abortando.")
    exit(1)

if "REEMPLAZA" in endpoint or not endpoint.startswith("https://"):
    print("❌ Endpoint inválido. Debe empezar con https://")
    exit(1)

# Auto-agregar barra si falta
if not endpoint.endswith("/"):
    endpoint = endpoint + "/"

print(f"\n✅ Endpoint: {endpoint}\n")

print("""
┌────────────────────────────────────────────────────────────────────────┐
│ 3. DEPLOYMENT NAME                                                    │
│    - En Azure Portal: Deployments (en el menu)                         │
│    - Copia el nombre EXACTO (ej: OAIDEU2-GPT4)                         │
│    - En corporativos: OAIDEU2, OAIEUS2, etc.                           │
│    - En otros: deployment-gpt-4, mi-deployment, etc.                   │
└────────────────────────────────────────────────────────────────────────┘
""")

deployment = input("🤖 Pega el nombre del Deployment: ").strip()

if not deployment:
    print("❌ Deployment vacío. Abortando.")
    exit(1)

if "REEMPLAZA" in deployment:
    print("❌ Eso sigue siendo un placeholder. Usa el nombre REAL del deployment.")
    exit(1)

print(f"\n✅ Deployment: {deployment}\n")

# Validar
print("╔════════════════════════════════════════════════════════════════════════╗")
print("║                         VALIDACIÓN RÁPIDA                             ║")
print("╚════════════════════════════════════════════════════════════════════════╝")

# API Key
if len(api_key) > 40:
    print(f"✅ API Key: Parece válida (largo: {len(api_key)} chars)")
else:
    print(f"⚠️  API Key: Parece corta (largo: {len(api_key)} chars)")
    input("   Presiona ENTER para continuar de todos modos...")

# Endpoint
if endpoint.startswith("https://") and endpoint.endswith("/"):
    print(f"✅ Endpoint: Formato correcto")
    # Extraer hostname para verificación extra
    from urllib.parse import urlparse
    hostname = urlparse(endpoint).netloc
    if "openai.azure.com" in hostname:
        print(f"✅   Hostname: Parece Azure ({hostname})")
    else:
        print(f"⚠️   Hostname: No parece Azure ({hostname})")
else:
    print(f"❌ Endpoint: Formato incorrecto")
    exit(1)

# Deployment
if len(deployment) > 2:
    print(f"✅ Deployment: Nombre válido ({len(deployment)} chars)")
else:
    print(f"❌ Deployment: Nombre muy corto")
    exit(1)

# Guardar en .env
print("\n╔════════════════════════════════════════════════════════════════════════╗")
print("║                      GUARDANDO CONFIGURACIÓN                           ║")
print("╚════════════════════════════════════════════════════════════════════════╝\n")

try:
    with open(env_path, 'r') as f:
        content = f.read()
    
    # Reemplazar
    import re
    
    # API Key
    content = re.sub(
        r'AZURE_OPENAI_API_KEY=.*',
        f'AZURE_OPENAI_API_KEY={api_key}',
        content
    )
    
    # Endpoint
    content = re.sub(
        r'AZURE_OPENAI_ENDPOINT=.*',
        f'AZURE_OPENAI_ENDPOINT={endpoint}',
        content
    )
    
    # Deployment
    content = re.sub(
        r'AZURE_OPENAI_DEPLOYMENT=.*',
        f'AZURE_OPENAI_DEPLOYMENT={deployment}',
        content
    )
    
    # Guardar
    with open(env_path, 'w') as f:
        f.write(content)
    
    print(f"✅ .env actualizado en: {env_path}")
    
except Exception as e:
    print(f"❌ Error escribiendo .env: {e}")
    exit(1)

# Resumen
print("\n╔════════════════════════════════════════════════════════════════════════╗")
print("║                      ✅ CONFIGURACIÓN COMPLETADA                       ║")
print("╚════════════════════════════════════════════════════════════════════════╝\n")

print("Tus credenciales han sido guardadas en .env\n")

print("PRÓXIMO PASO: Validar la conexión")
print("-" * 80)
print("Ejecuta este comando:\n")
print("  python test_azure_config.py\n")
print("Si todos los checks son ✅, entonces tu agente está listo:\n")
print("  python agente.py --titulo 'Modelo LaR' --tier 1 --prdc\n")

print("═" * 80 + "\n")
