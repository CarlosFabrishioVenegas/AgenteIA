═══════════════════════════════════════════════════════════════════════════════
  📚 ÍNDICE DE ARCHIVOS DE AYUDA - AZURE OPENAI
═══════════════════════════════════════════════════════════════════════════════

He creado varios archivos y scripts para ayudarte a configurar Azure OpenAI.
Aquí encontrarás dónde está cada cosa y para qué sirve.

═══════════════════════════════════════════════════════════════════════════════
  📖 GUÍAS Y DOCUMENTACIÓN
═════════════════════════════════════════════════════════════════════════════

┌─ GUIA_RAPIDA.txt (EMPIEZA AQUÍ) ──────────────────────────────────────────┐
│                                                                              │
│ Archivo: GUIA_RAPIDA.txt                                                    │
│ Tamaño: ~11 KB                                                              │
│ Propósito: Referencia rápida de 4 pasos                                    │
│                                                                              │
│ Contiene:                                                                   │
│  • Guía rápida de inicio                                                   │
│  • 4 pasos principales                                                     │
│  • Troubleshooting de errores comunes                                      │
│  • Checklist antes de ejecutar                                             │
│                                                                              │
│ Usa esto si:                                                               │
│  ✓ Quieres ir rápido                                                       │
│  ✓ Ya conoces Azure                                                        │
│  ✓ Necesitas recordar comandos                                             │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

┌─ SETUP_AZURE_RAPIDO.txt ──────────────────────────────────────────────────┐
│                                                                              │
│ Archivo: SETUP_AZURE_RAPIDO.txt                                             │
│ Tamaño: ~15 KB                                                              │
│ Propósito: Guía DETALLADA paso a paso                                      │
│                                                                              │
│ Contiene:                                                                   │
│  • 3 opciones de configuración (automática, manual, CLI)                   │
│  • Explicación DETALLADA de dónde obtener cada credencial                  │
│  • Formato esperado de cada valor (con ejemplos)                           │
│  • Nota especial para deployments corporativos (OAIDEU2, etc.)             │
│  • Problemas comunes y soluciones                                          │
│                                                                              │
│ Usa esto si:                                                               │
│  ✓ Es tu primera vez con Azure OpenAI                                      │
│  ✓ Quieres entender QUÉ estás haciendo                                     │
│  ✓ Necesitas explicación detallada de formatos                             │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

┌─ DIAGNOSTICO_RESUMEN.txt ─────────────────────────────────────────────────┐
│                                                                              │
│ Archivo: DIAGNOSTICO_RESUMEN.txt                                            │
│ Tamaño: ~13 KB                                                              │
│ Propósito: Resumen ejecutivo del problema y solución                       │
│                                                                              │
│ Contiene:                                                                   │
│  • Qué problema se detectó                                                 │
│  • 4 pasos para solucionarlo                                               │
│  • Dónde obtener cada credencial (Azure Portal)                            │
│  • Referencia rápida de qué está dónde en Azure                            │
│                                                                              │
│ Usa esto si:                                                               │
│  ✓ Acabas de recibir un error                                              │
│  ✓ Quieres entender el resumen ejecutivo                                   │
│  ✓ Necesitas compartir con tu gerente                                      │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

┌─ PARA_SOPORTE_IT.txt ─────────────────────────────────────────────────────┐
│                                                                              │
│ Archivo: PARA_SOPORTE_IT.txt                                                │
│ Tamaño: ~9 KB                                                               │
│ Propósito: Información técnica para tu soporte IT (SIN credenciales)        │
│                                                                              │
│ Contiene:                                                                   │
│  • Resumen del problema (técnico)                                          │
│  • Configuración detectada (valores enmascarados)                          │
│  • Diagnóstico de red y dependencias                                       │
│  • Próximos pasos para soporte IT                                          │
│  • Posibles causas de fallo persistente                                    │
│                                                                              │
│ Usa esto si:                                                               │
│  ✓ Necesitas escalar a tu soporte IT                                       │
│  ✓ Quieres compartir detalles técnicos SIN revelar credenciales           │
│  ✓ Tienes problemas persistentes de red/autenticación                     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
  🔧 SCRIPTS AUTOMÁTICOS
═════════════════════════════════════════════════════════════════════════════

┌─ setup_azure_simple.py (RECOMENDADO) ──────────────────────────────────────┐
│                                                                              │
│ Archivo: setup_azure_simple.py                                              │
│ Tamaño: ~8 KB                                                               │
│ Propósito: Configuración interactiva automática de .env                     │
│                                                                              │
│ Ejecuta con:                                                                │
│  $ python setup_azure_simple.py                                             │
│                                                                              │
│ Qué hace:                                                                   │
│  1. Te pide tu API Key de Azure                                            │
│  2. Te pide tu Endpoint                                                    │
│  3. Te pide tu Deployment Name                                             │
│  4. Valida que los formatos sean correctos                                 │
│  5. Automáticamente actualiza .env                                         │
│                                                                              │
│ Usa esto si:                                                               │
│  ✓ Quieres automatización (MÁS FÁCIL)                                      │
│  ✓ Prefieres no editar archivos manualmente                                │
│  ✓ Quieres validación integrada                                            │
│                                                                              │
│ Ventajas sobre editar manual:                                              │
│  • No necesitas abrir editor de texto                                      │
│  • Valida formatos antes de guardar                                        │
│  • Más rápido y menos propenso a errores                                   │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

┌─ quick_azure_setup.py ────────────────────────────────────────────────────┐
│                                                                              │
│ Archivo: quick_azure_setup.py                                               │
│ Tamaño: ~7 KB                                                               │
│ Propósito: Alternativa más simple de setup_azure_simple.py                  │
│                                                                              │
│ Ejecuta con:                                                                │
│  $ python quick_azure_setup.py                                              │
│                                                                              │
│ Diferencia con setup_azure_simple.py:                                       │
│  • Interfaz más simple y visual                                             │
│  • Menos validaciones (más permisivo)                                       │
│  • Mejor para usuarios que saben lo que hacen                               │
│                                                                              │
│ Usa esto si:                                                               │
│  ✓ Ya conoces tus valores exactos                                           │
│  ✓ Prefieres menos preguntas                                               │
│  ✓ Quieres que sea rápido                                                  │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

┌─ test_azure_config.py (VALIDACIÓN) ───────────────────────────────────────┐
│                                                                              │
│ Archivo: test_azure_config.py                                               │
│ Tamaño: ~14 KB                                                              │
│ Propósito: Validar que tu configuración de Azure sea correcta               │
│                                                                              │
│ Ejecuta con:                                                                │
│  $ python test_azure_config.py                                              │
│                                                                              │
│ Qué valida:                                                                 │
│  1. .env existe y es legible                                               │
│  2. IA_PROVEEDOR = azure_openai                                            │
│  3. API Key está configurada (y no es placeholder)                         │
│  4. Endpoint está configurado (y es https://...)                           │
│  5. Deployment está configurado (y no es placeholder)                      │
│  6. Intenta crear cliente Azure OpenAI                                     │
│  7. Intenta hacer llamada real a la API                                    │
│  8. Captura errores exactos y los explica                                  │
│                                                                              │
│ Salida esperada (todo ✅):                                                  │
│  ✅ .env encontrado                                                         │
│  ✅ IA_PROVEEDOR = azure_openai                                             │
│  ✅ API Key configurada                                                     │
│  ✅ Endpoint válido                                                         │
│  ✅ Deployment válido                                                       │
│  ✅ Cliente Azure creado                                                    │
│  ✅ Respuesta recibida                                                      │
│  ✅ TODAS las validaciones pasaron                                          │
│                                                                              │
│ Ejecuta esto:                                                              │
│  ✓ Después de completar .env (para validar)                                │
│  ✓ Cada vez que cambies credenciales                                       │
│  ✓ Antes de ejecutar el agente (paso final)                                │
│                                                                              │
│ Si hay errores:                                                             │
│  • Te muestra el error EXACTO                                              │
│  • Te explica QUÉ salió mal                                                │
│  • Te sugiere soluciones                                                   │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

┌─ diagnóstico_azure_detallado.py (DIAGNÓSTICO AVANZADO) ────────────────────┐
│                                                                              │
│ Archivo: diagnóstico_azure_detallado.py                                     │
│ Tamaño: ~13 KB                                                              │
│ Propósito: Diagnóstico exhaustivo para compartir con soporte IT             │
│                                                                              │
│ Ejecuta con:                                                                │
│  $ python diagnóstico_azure_detallado.py                                    │
│                                                                              │
│ Qué valida:                                                                 │
│  1. Sistema operativo y Python                                             │
│  2. Configuración (credenciales enmascaradas)                              │
│  3. Dependencias (openai library, config.py)                               │
│  4. Resolución DNS del endpoint                                            │
│  5. Conectividad TCP puerto 443                                            │
│                                                                              │
│ Genera:                                                                     │
│  • diagnostic_report.json (para análisis)                                   │
│  • diagnostic_report.txt (legible)                                          │
│                                                                              │
│ Usa esto si:                                                               │
│  ✓ Tienes problemas después de completar .env                              │
│  ✓ Necesitas compartir con soporte IT                                      │
│  ✓ Quieres diagnóstico completo de red y dependencias                      │
│                                                                              │
│ Ventaja:                                                                    │
│  • NO muestra credenciales (seguro para compartir)                         │
│  • Detecta problemas de red/DNS                                            │
│  • Genera reporte JSON para análisis                                        │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════════════════════
  🎯 FLUJO DE USO RECOMENDADO
═════════════════════════════════════════════════════════════════════════════

CASO 1: Primera vez configurando (recomendado)
─────────────────────────────────────────────────────────────────────────────
  1. Lee: SETUP_AZURE_RAPIDO.txt (para entender qué obtener)
  2. Obtén credenciales de Azure Portal (sigue instrucciones)
  3. Ejecuta: python setup_azure_simple.py (ingresa tus valores)
  4. Ejecuta: python test_azure_config.py (valida)
  5. Si pasa: python agente.py --titulo "Modelo LaR" --tier 1

CASO 2: Ya intentaste antes pero te falló
─────────────────────────────────────────────────────────────────────────────
  1. Lee: DIAGNOSTICO_RESUMEN.txt (resumen del problema)
  2. Sigue PASO 2-4: pip install openai, llenar .env, validar
  3. Si sigue fallando: python diagnóstico_azure_detallado.py
  4. Comparte: PARA_SOPORTE_IT.txt + diagnostic_report.json

CASO 3: Necesitas ayuda de tu equipo IT
─────────────────────────────────────────────────────────────────────────────
  1. Ejecuta: python diagnóstico_azure_detallado.py
  2. Comparte con IT:
     • PARA_SOPORTE_IT.txt
     • diagnostic_report.json
     • Output de test_azure_config.py
  3. Espera feedback de soporte

═══════════════════════════════════════════════════════════════════════════════
  ⚡ COMANDOS RÁPIDOS
═════════════════════════════════════════════════════════════════════════════

Instalar openai:
  $ pip install openai

Configurar (automático):
  $ python setup_azure_simple.py

Validar configuración:
  $ python test_azure_config.py

Diagnóstico completo:
  $ python diagnóstico_azure_detallado.py

Ejecutar agente (si todo pasa):
  $ python agente.py --titulo "Modelo LaR" --tier 1 --prdc

═══════════════════════════════════════════════════════════════════════════════
  ❓ PREGUNTAS FRECUENTES
═════════════════════════════════════════════════════════════════════════════

¿Por dónde empiezo?
→ Lee GUIA_RAPIDA.txt (4 pasos)

¿Dónde obtengo las credenciales?
→ Lee SETUP_AZURE_RAPIDO.txt (Paso 2-3)

¿Cómo lleno .env automáticamente?
→ Ejecuta: python setup_azure_simple.py

¿Cómo valido que esté bien?
→ Ejecuta: python test_azure_config.py

¿Qué hago si falla?
→ Lee DIAGNOSTICO_RESUMEN.txt (Paso 1-2)
→ O ejecuta: python diagnóstico_azure_detallado.py

¿Cómo le digo al IT?
→ Copia el contenido de PARA_SOPORTE_IT.txt

═══════════════════════════════════════════════════════════════════════════════
  📞 RESUMEN
═════════════════════════════════════════════════════════════════════════════

Tienes TODO lo que necesitas para configurar Azure OpenAI:

✅ 4 guías detalladas (GUIA_RAPIDA, SETUP, DIAGNOSTICO, PARA_IT)
✅ 4 scripts automáticos (setup, test, diagnostico)
✅ Errores explicados claramente
✅ Información lista para compartir con soporte
✅ Instrucciones paso a paso

¿PRÓXIMO PASO?

1. Lee GUIA_RAPIDA.txt (1 minuto)
2. Ejecuta python setup_azure_simple.py (3 minutos)
3. Ejecuta python test_azure_config.py (1 minuto)
4. ¡Listo!

═══════════════════════════════════════════════════════════════════════════════
