#!/usr/bin/env python3
"""
test_azure_config.py - Validador rápido de configuración Azure OpenAI

Uso:
    python test_azure_config.py

Valida:
    ✅ .env existe y es legible
    ✅ IA_PROVEEDOR = azure_openai
    ✅ AZURE_OPENAI_API_KEY está configurada (y no es placeholder)
    ✅ AZURE_OPENAI_ENDPOINT está configurada
    ✅ AZURE_OPENAI_DEPLOYMENT está configurada
    ✅ Conexión a API es exitosa
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Colores para terminal
class Color:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header():
    print("\n" + "═" * 70)
    print(f"{Color.BLUE}{Color.BOLD}🔵 VALIDADOR AZURE OPENAI - VIRF Agent v23{Color.RESET}")
    print("═" * 70 + "\n")

def print_ok(msg):
    print(f"{Color.GREEN}✅ {msg}{Color.RESET}")

def print_error(msg):
    print(f"{Color.RED}❌ {msg}{Color.RESET}")

def print_warning(msg):
    print(f"{Color.YELLOW}⚠️  {msg}{Color.RESET}")

def print_info(msg):
    print(f"{Color.BLUE}ℹ️  {msg}{Color.RESET}")

def test_env_file():
    """Valida que .env exista y sea legible"""
    print(f"\n{Color.BOLD}1. Verificando archivo .env{Color.RESET}")
    print("-" * 70)
    
    env_path = Path(__file__).parent / ".env"
    
    if not env_path.exists():
        print_error(f".env no encontrado en {env_path}")
        return False
    
    print_ok(f".env encontrado: {env_path}")
    
    # Intentar cargar
    try:
        load_dotenv(env_path)
        print_ok(".env cargado correctamente")
        return True
    except Exception as e:
        print_error(f"Error leyendo .env: {e}")
        return False

def test_proveedor():
    """Valida que IA_PROVEEDOR = azure_openai"""
    print(f"\n{Color.BOLD}2. Verificando IA_PROVEEDOR{Color.RESET}")
    print("-" * 70)
    
    proveedor = os.getenv("IA_PROVEEDOR", "").lower()
    
    if not proveedor:
        print_error("IA_PROVEEDOR no está configurada en .env")
        return False
    
    if proveedor == "azure_openai":
        print_ok(f"IA_PROVEEDOR = {proveedor} (Azure OpenAI activo ✓)")
        return True
    elif proveedor == "anthropic":
        print_warning(f"IA_PROVEEDOR = {proveedor} (estás usando Anthropic, no Azure)")
        print_info("Para cambiar a Azure OpenAI:")
        print_info("  1. Edita .env")
        print_info("  2. Cambia: IA_PROVEEDOR=azure_openai")
        print_info("  3. Configura credenciales Azure (ver GUIA_AZURE_OPENAI.md)")
        return False
    else:
        print_error(f"IA_PROVEEDOR = {proveedor} (desconocido)")
        return False

def test_azure_credentials():
    """Valida credenciales Azure OpenAI"""
    print(f"\n{Color.BOLD}3. Verificando credenciales Azure OpenAI{Color.RESET}")
    print("-" * 70)
    
    all_ok = True
    
    # API Key
    api_key = os.getenv("AZURE_OPENAI_API_KEY", "").strip()
    if not api_key:
        print_error("AZURE_OPENAI_API_KEY no está configurada")
        all_ok = False
    elif "REEMPLAZA" in api_key or "TU_" in api_key:
        print_error("AZURE_OPENAI_API_KEY contiene placeholder (REEMPLAZA...)")
        all_ok = False
    else:
        # Mostrar solo últimos 10 caracteres por seguridad
        key_display = f"{api_key[:5]}...{api_key[-5:]}"
        print_ok(f"AZURE_OPENAI_API_KEY configurada: {key_display}")
    
    # Endpoint
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()
    if not endpoint:
        print_error("AZURE_OPENAI_ENDPOINT no está configurada")
        all_ok = False
    elif "REEMPLAZA" in endpoint or "https://" not in endpoint:
        print_error("AZURE_OPENAI_ENDPOINT inválida (debe ser https://...)")
        all_ok = False
    elif not endpoint.endswith("/"):
        print_warning(f"AZURE_OPENAI_ENDPOINT no termina con /: {endpoint}")
        print_info("Por seguridad, añade / al final")
    else:
        print_ok(f"AZURE_OPENAI_ENDPOINT: {endpoint}")
    
    # Deployment
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "").strip()
    if not deployment:
        print_error("AZURE_OPENAI_DEPLOYMENT no está configurada")
        all_ok = False
    elif "REEMPLAZA" in deployment:
        print_error("AZURE_OPENAI_DEPLOYMENT contiene placeholder")
        all_ok = False
    else:
        print_ok(f"AZURE_OPENAI_DEPLOYMENT: {deployment}")
    
    # API Version
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    print_ok(f"AZURE_OPENAI_API_VERSION: {api_version}")
    
    return all_ok

def test_conexion():
    """Intenta conectar a Azure OpenAI"""
    print(f"\n{Color.BOLD}4. Probando conexión a Azure OpenAI (Validación)#{Color.RESET}")
    print("-" * 70)
    
    try:
        from config import get_cliente_ia
        
        print_info("Intentando crear cliente...")
        print_info(f"  - Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
        print_info(f"  - Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")
        print_info(f"  - API Version: {os.getenv('AZURE_OPENAI_API_VERSION')}")
        
        cliente = get_cliente_ia()
        
        print_ok("Cliente Azure OpenAI creado ✓")
        return True
        
    except ValueError as e:
        print_error(f"Error de configuración: {e}")
        return False
    except RuntimeError as e:
        error_msg = str(e)
        print_error(f"Error de conexión: {error_msg}")
        
        # Desglosar el error para diagnóstico
        if "No se pudo conectar" in error_msg:
            print("\n📋 DETALLES:")
            print("   El cliente no pudo conectar a Azure OpenAI")
            print(f"   Endpoint configurado: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
            print(f"   Deployment configurado: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")
            print("\n   Para tu soporte IT:")
            print(f"   - Tipo: RuntimeError - No se pudo conectar")
            print(f"   - Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
            print(f"   - Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")
        
        return False
    except Exception as e:
        print_error(f"Error inesperado: {type(e).__name__}")
        print_error(f"Mensaje: {str(e)}")
        
        print("\n📋 INFORMACIÓN PARA DIAGNÓSTICO:")
        print(f"   Tipo error: {type(e).__name__}")
        print(f"   Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
        print(f"   Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")
        print(f"   API Version: {os.getenv('AZURE_OPENAI_API_VERSION')}")
        
        print("\n" + "─" * 70)
        print(f"{Color.YELLOW}📌 TRACEBACK COMPLETO:{Color.RESET}")
        print("─" * 70)
        import traceback
        traceback.print_exc()
        
        return False

def test_llamada_api():
    """Intenta hacer una llamada real a la API"""
    print(f"\n{Color.BOLD}5. Probando llamada REAL a Azure OpenAI{Color.RESET}")
    print("-" * 70)
    
    try:
        from config import get_cliente_ia
        
        print_info("Obteniendo cliente...")
        cliente = get_cliente_ia()
        
        print_info("Enviando mensaje de prueba a Azure OpenAI...")
        print_info(f"  - Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
        print_info(f"  - Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")
        print_info(f"  - API Version: {os.getenv('AZURE_OPENAI_API_VERSION')}")
        
        respuesta = cliente.generar_mensaje(
            prompt="Responde con una palabra: test",
            instruccion_sistema="Responde brevemente."
        )
        
        print_ok(f"Respuesta recibida: {respuesta[:100]}...")
        print_ok("Llamada API exitosa ✓")
        return True
        
    except Exception as e:
        print_error(f"❌ Error en llamada API")
        print_error(f"\n📋 DETALLES DEL ERROR:")
        print_error(f"   Tipo de error: {type(e).__name__}")
        print_error(f"   Mensaje: {str(e)}")
        
        # Analizar tipo de error
        error_str = str(e).lower()
        
        if "connection" in error_str or "connect" in error_str:
            print("\n🔍 ANÁLISIS: Problema de CONEXIÓN")
            print("   Posibles causas:")
            print("   1. ❌ Endpoint incorrecto o no accesible")
            print("   2. ❌ Firewall/proxy bloqueando conexión a Azure")
            print("   3. ❌ Recurso Azure OpenAI no está en estado 'OK'")
            print("   4. ❌ Problema de DNS (no resuelve el hostname)")
            print("\n   Para compartir con tu soporte:")
            print(f"   - Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
            print(f"   - Error tipo: APIConnectionError")
            print(f"   - Verifica que el recurso esté creado en Azure")
            
        elif "401" in error_str or "unauthorized" in error_str:
            print("\n🔍 ANÁLISIS: Problema de AUTENTICACIÓN")
            print("   Posibles causas:")
            print("   1. ❌ API Key inválida o expirada")
            print("   2. ❌ API Key pertenece a otro recurso Azure")
            print("   3. ❌ API Key regenerada (la antigua ya no funciona)")
            print("\n   Para compartir con tu soporte:")
            print("   - Error tipo: 401 Unauthorized")
            print("   - Verifica que la API Key sea la correcta")
            
        elif "404" in error_str or "not found" in error_str:
            print("\n🔍 ANÁLISIS: Problema de DEPLOYMENT")
            print("   Posibles causas:")
            print("   1. ❌ Nombre del deployment incorrecto")
            print("   2. ❌ Deployment no existe")
            print("   3. ❌ Deployment está en estado 'Deleting'")
            print("\n   Para compartir con tu soporte:")
            print(f"   - Deployment usado: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")
            print("   - Error tipo: 404 Not Found")
            print("   - Verifica que el deployment existe en Azure Portal")
            
        elif "timeout" in error_str or "timed out" in error_str:
            print("\n🔍 ANÁLISIS: Problema de TIMEOUT")
            print("   Posibles causas:")
            print("   1. ❌ Conexión muy lenta")
            print("   2. ❌ Azure OpenAI sobrecargado")
            print("   3. ❌ Problema de latencia de red")
            print("\n   Intenta aumentar TIMEOUT_SEGUNDOS en .env")
            
        elif "rate limit" in error_str:
            print("\n🔍 ANÁLISIS: Problema de RATE LIMIT")
            print("   Posibles causas:")
            print("   1. ⚠️  Has alcanzado el límite de llamadas a la API")
            print("   2. ⚠️  Demasiadas llamadas simultáneas")
            print("\n   Espera unos minutos y reintenta")
        
        else:
            print("\n🔍 ANÁLISIS: Error desconocido")
            print("   Para compartir con tu soporte IT:")
            print(f"   - Error completo: {str(e)}")
            print(f"   - Endpoint: {os.getenv('AZURE_OPENAI_ENDPOINT')}")
            print(f"   - Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT')}")
        
        print("\n" + "─" * 70)
        print(f"{Color.YELLOW}📌 TRACEBACK COMPLETO:{Color.RESET}")
        print("─" * 70)
        import traceback
        traceback.print_exc()
        
        return False

def print_summary(results):
    """Imprime resumen de validación"""
    print(f"\n{'═' * 70}")
    print(f"{Color.BOLD}RESUMEN{Color.RESET}")
    print("═" * 70 + "\n")
    
    paso_1, paso_2, paso_3, paso_4, paso_5 = results
    
    if all(results):
        print_ok("✅ TODAS las validaciones pasaron")
        print_info("✅ Azure OpenAI está correctamente configurado")
        print_info("✅ Conexión activa y funcionando")
        print_ok("\nPuedes usar Azure OpenAI. Ejecuta:")
        print(f"\n  {Color.BOLD}python agente.py --titulo 'Modelo LaR' --tier 1 --prdc{Color.RESET}\n")
        return True
    else:
        print_error("❌ ALGUNAS validaciones fallaron")
        
        if not paso_1:
            print_error("  → Verifica que .env exista")
        if not paso_2:
            print_error("  → Configura IA_PROVEEDOR=azure_openai en .env")
        if not paso_3:
            print_error("  → Completa credenciales Azure en .env")
            print_info("     Guía: docs/GUIA_AZURE_OPENAI.md")
        if not paso_4:
            print_error("  → Error creando cliente Azure")
            print_info("     Verifica API Key, Endpoint, y Deployment")
        if not paso_5:
            print_error("  → Error en llamada API")
            print_info("     Verifica:")
            print_info("     - Conexión de red")
            print_info("     - Límites de API en Azure")
            print_info("     - Que el Deployment existe")
        
        return False

def main():
    print_header()
    
    paso_1 = test_env_file()
    paso_2 = test_proveedor()
    paso_3 = test_azure_credentials()
    paso_4 = test_conexion() if paso_3 else False
    paso_5 = test_llamada_api() if paso_4 else False
    
    success = print_summary([paso_1, paso_2, paso_3, paso_4, paso_5])
    
    print("═" * 70 + "\n")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
