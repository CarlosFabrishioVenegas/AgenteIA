#!/usr/bin/env python3
"""
quick_azure_setup.py - Asistente interactivo para configurar Azure OpenAI

Este script te guía paso a paso para obtener tus credenciales y actualizar .env

Uso:
    python quick_azure_setup.py
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

class Colors:
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    RESET = '\033[0m'

def print_header():
    print("\n" + "═" * 80)
    print(f"{Colors.BLUE}{Colors.BOLD}🔧 ASISTENTE DE CONFIGURACIÓN AZURE OPENAI{Colors.RESET}")
    print("═" * 80 + "\n")

def print_step(num, title):
    print(f"\n{Colors.BOLD}{Colors.BLUE}[PASO {num}] {title}{Colors.RESET}")
    print("-" * 80)

def print_info(msg):
    print(f"{Colors.BLUE}ℹ️  {msg}{Colors.RESET}")

def print_success(msg):
    print(f"{Colors.GREEN}✅ {msg}{Colors.RESET}")

def print_warn(msg):
    print(f"{Colors.YELLOW}⚠️  {msg}{Colors.RESET}")

def print_error(msg):
    print(f"{Colors.RED}❌ {msg}{Colors.RESET}")

def main():
    print_header()
    
    # PASO 1: Explicar dónde obtener credenciales
    print_step(1, "Obtener credenciales de Azure Portal")
    print("""
1️⃣  Ve a: https://portal.azure.com/

2️⃣  Busca "Azure OpenAI" y abre tu recurso

3️⃣  En el menú izquierdo → "Keys and endpoint"
    Verás algo como:
    
    ┌─────────────────────────────────────────────────────┐
    │ Key 1:  DO8xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx         │
    │ Key 2:  DO8yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy         │
    │                                                      │
    │ Endpoint: https://mi-recurso.openai.azure.com/      │
    └─────────────────────────────────────────────────────┘

4️⃣  Copia estos valores (los necesitarás en el paso siguiente)
    """)
    
    input(f"{Colors.YELLOW}Presiona ENTER cuando hayas anotado API Key y Endpoint...{Colors.RESET}")
    
    # PASO 2: Explicar dónde obtener deployment
    print_step(2, "Obtener el nombre del DEPLOYMENT")
    print("""
1️⃣  Vuelve a tu recurso Azure OpenAI

2️⃣  En el menú izquierdo → "Deployments"
    Verás una tabla con deployments activos
    
3️⃣  Busca un deployment (especialmente si empieza con "OAIDEU" o "OAIEUS"):
    
    ┌────────────────────────────────────────────────────┐
    │ Deployment Name     │ Status     │ Model           │
    ├────────────────────────────────────────────────────┤
    │ OAIDEU2-GPT4       │ Succeeded  │ gpt-4           │
    │ OAIEUS2-TURBO      │ Succeeded  │ gpt-35-turbo    │
    │ deployment-old     │ Deleting   │ ...             │
    └────────────────────────────────────────────────────┘
    
4️⃣  Copia el nombre EXACTO (ej: OAIDEU2-GPT4)
    """)
    
    input(f"{Colors.YELLOW}Presiona ENTER cuando hayas anotado el DEPLOYMENT NAME...{Colors.RESET}")
    
    # PASO 3: Recolectar datos
    print_step(3, "Ingresar tus credenciales")
    print("""
Ahora ingresarás tus credenciales. Se validarán antes de guardar.
    """)
    
    api_key = input(f"\n{Colors.BOLD}📋 API Key (DO8...):  {Colors.RESET}").strip()
    endpoint = input(f"{Colors.BOLD}🌐 Endpoint (https://...):  {Colors.RESET}").strip()
    deployment = input(f"{Colors.BOLD}🤖 Deployment (OAIDEU2...):  {Colors.RESET}").strip()
    
    # PASO 4: Validar
    print_step(4, "Validando credenciales")
    
    errors = []
    
    if not api_key:
        errors.append("API Key vacía")
    elif len(api_key) < 20:
        errors.append("API Key parece demasiado corta (mínimo ~50 caracteres)")
    elif "REEMPLAZA" in api_key or "TU_" in api_key:
        errors.append("API Key aún contiene placeholder")
    else:
        print_success(f"API Key válida: {api_key[:10]}...{api_key[-5:]}")
    
    if not endpoint:
        errors.append("Endpoint vacío")
    elif not endpoint.startswith("https://"):
        errors.append("Endpoint debe comenzar con https://")
    elif not endpoint.endswith("/"):
        print_warn(f"Endpoint no termina con / (añadiendo automáticamente)")
        endpoint = endpoint + "/" if not endpoint.endswith("/") else endpoint
        print_success(f"Endpoint validado: {endpoint}")
    else:
        print_success(f"Endpoint válido: {endpoint}")
    
    if not deployment:
        errors.append("Deployment vacío")
    elif "REEMPLAZA" in deployment:
        errors.append("Deployment aún contiene placeholder")
    elif len(deployment) < 3:
        errors.append("Deployment parece muy corto")
    else:
        print_success(f"Deployment válido: {deployment}")
    
    if errors:
        print_error("Se encontraron errores:")
        for err in errors:
            print_error(f"  - {err}")
        return 1
    
    # PASO 5: Guardar en .env
    print_step(5, "Guardar credenciales en .env")
    
    env_path = Path(__file__).parent / ".env"
    
    try:
        # Leer .env actual
        with open(env_path, 'r') as f:
            lines = f.readlines()
        
        # Reemplazar líneas
        new_lines = []
        for line in lines:
            if line.startswith("AZURE_OPENAI_API_KEY="):
                new_lines.append(f"AZURE_OPENAI_API_KEY={api_key}\n")
            elif line.startswith("AZURE_OPENAI_ENDPOINT="):
                new_lines.append(f"AZURE_OPENAI_ENDPOINT={endpoint}\n")
            elif line.startswith("AZURE_OPENAI_DEPLOYMENT="):
                new_lines.append(f"AZURE_OPENAI_DEPLOYMENT={deployment}\n")
            else:
                new_lines.append(line)
        
        # Guardar
        with open(env_path, 'w') as f:
            f.writelines(new_lines)
        
        print_success(f".env actualizado en: {env_path}")
        
    except Exception as e:
        print_error(f"Error escribiendo .env: {e}")
        return 1
    
    # PASO 6: Verificar
    print_step(6, "Verificar configuración")
    print(f"\n{Colors.BOLD}Ejecuta este comando para validar:{Colors.RESET}")
    print(f"\n  python test_azure_config.py\n")
    
    print_success("¡Configuración completada!")
    print_info("Si el test pasa todos los checks, puedes usar:")
    print(f"\n  python agente.py --titulo 'Modelo LaR' --tier 1 --prdc\n")
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
