# Índice de documentación — VIRF Agent v18

## Arquitectura del sistema

```
agente.py                    ← Punto de entrada CLI. Orquesta los 3 pipelines.
config.py                    ← Configuración centralizada: clientes IA, rutas, constantes.

motor/                       ← Infraestructura (no tocar para cambios de negocio)
  Mx_00_CargaRutas.py        ← Constantes, ROL_AGENTE, mapeo ámbito→inputs
  Mx_01_LecturaEvidencias.py ← Lectura de archivos + chunking inteligente [v18]
  Mx_02_EstructuraPrompt.py  ← Construcción de prompts por control
  Mx_03_LlamarIA.py          ← Llamada HTTP a la API, parsing JSON, aprendizaje estilo
  Mx_04_MotorControlesData.py← Controles automáticos de calidad de datos (regex+pandas)
  Mx_05_GeneradorWord.py     ← Generación del informe Word (pipeline 1)

modulos/                     ← Lógica de negocio
  motor_ia.py                ← Evaluación 1-5, score ponderado, semáforo, resumen ejecutivo
  motor_ia_v2.py             ← Pipeline por control (calidad de datos)
  document_cache.py          ← Caché SHA-256 persistente de documentos parseados [v15+]
  feedback.py                ← Bucle de feedback por consola, persistencia JSON
  feedback_mejorado.py       ← Análisis de patrones de error, bloque antisesgo dinámico
  generador_word.py          ← Informe Word (pipeline 2 completo)
  generador_excel.py         ← Informe Excel de estadísticas de feedback
  lector_inputs.py           ← Lectura de Estandares_VIRF.xlsx
  v13_fixes.py               ← Estructuras de datos de control (EstadoEvaluacion, etc.)
```

## Pipelines disponibles

### Pipeline 1 — Calidad de Datos (por control)
```bash
python agente.py --titulo "Modelo LaR" --tier 1 \
  --excel inputs/calidad_datos/ControlesData.xlsx --control
```
Evalúa cada fila de ControlesData.xlsx como un control independiente.

### Pipeline 2 — Todos los ámbitos (completo)
```bash
python agente.py --titulo "Modelo LaR" --tier 1
python agente.py --titulo "Modelo LaR" --tier 1 --prdc   # genera Word
```
Evalúa los 6 ámbitos VIRF según Estandares_VIRF.xlsx filtrado por tier.
Incluye memoria inter-ámbito desde v18.

### Estadísticas de feedback
```bash
python agente.py --estadisticafeedback
```

## Variables de entorno clave (ver .env.example para lista completa)

| Variable | Default | Descripción |
|---|---|---|
| `ANTHROPIC_API_KEY` | — | API key de Anthropic (requerida) |
| `ANTHROPIC_MODELO` | `claude-sonnet-4-6` | Modelo a usar |
| `VIRF_CHUNK_SIZE` | `12000` | Chars por segmento de chunking |
| `VIRF_CHUNK_OVERLAP` | `800` | Solapamiento entre segmentos |
| `VIRF_CHUNK_THRESHOLD` | `12000` | Umbral para activar chunking |
| `VIRF_MAX_CTX` | `15000` | Máx chars de contexto por prompt |
| `CACHE_ENABLED` | `1` | Caché de documentos activo |
| `IA_PROVEEDOR` | `anthropic` | `anthropic` o `azure_openai` |

## Flujo de datos por evaluación de actividad

```
Estandares_VIRF.xlsx
        │ leer_estandares_virf(tier)
        ▼
inputs/ ──► leer_carpeta() ──► _chunked_summary() ──► contexto (cobertura 100%)
                                      │ [v18]
                            document_cache.py (SHA-256 del binario)
        ▼
evaluar_actividad()
  ├── bloque_cobertura   (aviso según tipo de lectura)
  ├── bloque_antisesgo   (corrección dinámica por feedback histórico)
  ├── bloque_memoria     (hallazgos previos intra-ámbito)
  ├── contexto_global    (hallazgos de otros ámbitos) [v18]
  └── prompt → Claude API → JSON {puntaje, concepto, observacion, ...}
        │
        ▼
evaluar_ambito_completo() → lista de resultados + hallazgos_globales acumulados
        │ × 6 ámbitos
        ▼
calcular_score_global() → score ponderado 1-5
        │
        ▼
JSON de resultados con metadatos de agente [v18]
        └─► generar_word_informe() (solo --prdc)
```

## Metadatos de trazabilidad en JSON de salida (v18)

```json
{
  "modelo": "Modelo LaR",
  "tier": "1",
  "fecha": "2026-05-09",
  "agente": {
    "agente_version": "18",
    "modelo_ia": "claude-sonnet-4-6",
    "proveedor_ia": "anthropic",
    "pesos_ambito": {"Documentación": 0.20, "Calidad de datos": 0.20, ...},
    "prompt_hash": "abc123ef4567",
    "cache_activo": true
  },
  "score_global": 3.85,
  "semaforo": {"label": "ACEPTABLE", "color": "92D050"}
}
```

## Historial de versiones

| Versión | Cambios principales |
|---|---|
| v13 | Corrección bugs críticos: rutas, modelo ID, estado inicial |
| v14 | Chunking propuesto (implementación parcial) |
| v15 | Caché SHA-256 de documentos, pipeline por control |
| v17 | Memoria intra-ámbito, antisesgo dinámico, OCR, Azure OpenAI |
| **v18** | **Chunking real con _chunked_summary(), MAX_CTX sincronizado, bug Azure corregido, metadatos de versión, memoria inter-ámbito, limpieza docs/** |
