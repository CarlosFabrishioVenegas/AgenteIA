# ☁️ Guía Completa: Productivización de VIRF en Nube (Azure + Copilot + Copilot Studio)

**Versión:** 2.0  
**Última actualización:** 2026-05-09  
**Autor:** Sistema VIRF v21

---

## 🎯 Objetivo

Convertir VIRF de un script local en una **solución empresarial completa** en nube con:
- **Azure Cloud** — Hosting escalable y automático
- **GitHub Copilot** — Copiloto de IA para debugging y desarrollo
- **Microsoft Copilot Studio** — Interface conversacional sin código para usuarios finales

---

## 📋 Tabla de Contenidos

1. [Arquitectura de Nube de VIRF](#1-arquitectura-de-nube-de-virf)
2. [Opción A: Azure Container Instances (ACI)](#2-opción-a-azure-container-instances-aci)
3. [Opción B: Azure App Service (Web App)](#3-opción-b-azure-app-service-web-app)
4. [GitHub Copilot para Desarrollo](#4-github-copilot-para-desarrollo)
5. [Microsoft Copilot Studio (Sin Código)](#5-microsoft-copilot-studio-sin-código)
6. [Integración Completa: De Script a Agente](#6-integración-completa-de-script-a-agente)
7. [Monitoreo y Alertas](#7-monitoreo-y-alertas)
8. [Costos Estimados](#8-costos-estimados)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Arquitectura de Nube de VIRF

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Microsoft Copilot Studio                         │
│                  (Interface Conversacional para Usuarios)            │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                    (llamadas REST API)
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│                   Azure API Management                              │
│        (Autenticación, Rate Limiting, Logging)                      │
└────────────────────────────┬────────────────────────────────────────┘
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│                  Opción A: Container (ACI)                          │
│              O Opción B: App Service (Web App)                      │
│                    (VIRF Engine)                                    │
│                                                                      │
│  agente.py                                                          │
│  ├── motor_ia.py / motor_ia_v2.py                                   │
│  └── config.py (OpenAI/Anthropic/Azure)                             │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                    (lee/escribe)
                             │
┌────────────────────────────▼────────────────────────────────────────┐
│              Azure Storage Account (Blob Storage)                   │
│                                                                      │
│  ├── /inputs/               (Excel, PDFs, evidencias)               │
│  ├── /outputs/              (Informes Word generados)               │
│  └── /cache/                (Documentos cacheados)                  │
└──────────────────────────────────────────────────────────────────────┘
```

### Flujo de Datos

1. **Usuario** envía pregunta en Copilot Studio
2. **Copilot Studio** → llama VIRF API en Azure
3. **VIRF Container/App** → lee inputs de Azure Storage
4. **Motor IA** (OpenAI/Anthropic) → evalúa documentación
5. **Genera informe** → guarda en Azure Blob Storage
6. **Responde usuario** → link a informe descargable

---

## 2. Opción A: Azure Container Instances (ACI)

### Ventajas

| Aspecto | Ventaja |
| --- | --- |
| **Configuración** | Simple, sin Kubernetes |
| **Precio** | Muy barato (~$10-20/mes) |
| **Escalabilidad** | Buena para <100 auditorías/mes |
| **Tiempo de inicio** | 30-60 segundos |

### Paso 1: Crear Dockerfile

En la raíz de tu proyecto, crea `Dockerfile`:

```dockerfile
FROM python:3.10-slim

WORKDIR /app

# Copiar código
COPY . .

# Instalar dependencias
RUN pip install --no-cache-dir -r requirements.txt

# Exponer puerto para API REST (Flask/FastAPI)
EXPOSE 8000

# Comando de inicio
CMD ["python", "api_server.py"]
```

### Paso 2: Crear API REST (Flask)

Crea `api_server.py` en la raíz:

```python
from flask import Flask, request, jsonify
import os
from pathlib import Path
from config import get_cliente_ia
from modulos.motor_ia import (
    leer_estandares_virf,
    cargar_todos_inputs,
    evaluar_ambito_completo,
    calcular_score_global,
)

app = Flask(__name__)

@app.route("/health", methods=["GET"])
def health_check():
    """Verificar que el contenedor está vivo"""
    return jsonify({"status": "OK", "service": "VIRF"})

@app.route("/evaluar", methods=["POST"])
def evaluar_modelo():
    """
    Endpoint principal: evaluar un modelo
    
    Request JSON:
    {
        "modelo": "Modelo LaR",
        "tier": "1"
    }
    """
    try:
        data = request.get_json()
        modelo = data.get("modelo", "Desconocido")
        tier = data.get("tier", "1")
        
        # Obtener cliente IA
        cliente_ia = get_cliente_ia()
        
        # Leer estándares
        estandares = leer_estandares_virf(tier)
        
        # Cargar inputs
        inputs = cargar_todos_inputs()
        
        # Evaluar (simplificado)
        scores = {}
        for ambito in estandares:
            score = 3.5  # Placeholder
            scores[ambito] = score
        
        score_global = calcular_score_global(scores)
        
        return jsonify({
            "success": True,
            "modelo": modelo,
            "tier": tier,
            "score_global": score_global,
            "scores_por_ambito": scores,
            "mensaje": f"✅ {modelo} evaluado exitosamente"
        }), 200
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port, debug=False)
```

### Paso 3: Build de la imagen Docker

```bash
# En la carpeta raíz del proyecto
docker build -t virf:latest .
```

Verifica que se construyó correctamente:

```bash
docker images | grep virf
```

### Paso 4: Crear recurso en Azure

#### 4.1 Via Azure Portal (UI)

1. Ve a https://portal.azure.com
2. Haz clic en **Create a resource** → busca "Container Instances"
3. Haz clic en **Create**
4. Completa:
   - **Resource Group:** `virf-rg` (crear nuevo)
   - **Container Name:** `virf-container`
   - **Image Source:** Private image (si es privado) o Docker Hub
   - **Image:** `virf:latest`
   - **Port:** `8000`
   - **Memory:** `1 GB`
5. Haz clic en **Review + Create → Create**

Espera 1-2 minutos a que se inicie.

#### 4.2 Via Azure CLI (Terminal)

```bash
# Instalar Azure CLI
# En Windows: choco install azure-cli
# O descargar desde https://learn.microsoft.com/en-us/cli/azure/install-azure-cli

# Login
az login

# Crear grupo de recursos
az group create --name virf-rg --location eastus

# Deploy container
az container create \
  --resource-group virf-rg \
  --name virf-container \
  --image virf:latest \
  --cpu 1 --memory 1 \
  --port 8000 \
  --environment-variables \
    OPENAI_API_KEY='sk-proj-xxx' \
    OPENAI_MODEL='gpt-4-turbo' \
  --no-wait
```

### Paso 5: Obtener URL de acceso

```bash
az container show --resource-group virf-rg --name virf-container --query ipAddress.fqdn
```

Verás algo como: `virf-container.eastus.azurecontainer.io`

### Paso 6: Probar la API

```bash
# Test de health
curl http://virf-container.eastus.azurecontainer.io:8000/health

# Test de evaluación
curl -X POST http://virf-container.eastus.azurecontainer.io:8000/evaluar \
  -H "Content-Type: application/json" \
  -d '{"modelo": "Modelo LaR", "tier": "1"}'
```

---

## 3. Opción B: Azure App Service (Web App)

### Ventajas

| Aspecto | Ventaja |
| --- | --- |
| **Integración** | Completa con Azure DevOps, CI/CD |
| **Escalabilidad** | Automática según demanda |
| **Precio** | Competitivo (~$15-50/mes) |
| **Features** | SSL/TLS automático, custom domain |

### Paso 1: Preparar código para App Service

Crea `requirements-appservice.txt`:

```txt
# Dependencias para Azure App Service
Flask==2.3.0
Werkzeug==2.3.0
gunicorn==21.0.0

# VIRF dependencies
anthropic>=0.40.0
openai>=1.3.0
pandas>=2.0.0
openpyxl>=3.1.0
pdfplumber>=0.10.0
python-docx>=1.1.0
python-pptx>=0.6.21
python-dotenv>=1.0.0
```

Crea `startup.txt` (para Azure App Service):

```
cd /home/site/wwwroot
gunicorn --workers 4 --worker-class sync --bind 0.0.0.0:8000 api_server:app
```

### Paso 2: Deploy via Azure Portal

1. En https://portal.azure.com, haz clic en **Create a resource → App Service**
2. Completa:
   - **Name:** `virf-api` (único globalmente)
   - **Publish:** `Code`
   - **Runtime Stack:** `Python 3.10`
   - **App Service Plan:** `Free` (para probar) o `Basic`
3. Haz clic en **Create**

Espera 1-2 minutos.

### Paso 3: Deploy del código

```bash
# Via Git (recomendado)
# 1. En tu repo local
git remote add azure https://virf-api.scm.azurewebsites.net/virf-api.git
git push azure main

# O via Azure CLI
az webapp up --name virf-api --resource-group virf-rg --runtime "python:3.10"
```

### Paso 4: Configurar variables de entorno

En **Azure Portal → App Service → virf-api → Configuration**:

1. Haz clic en **+ New application setting**
2. Agrega:
   - **Name:** `OPENAI_API_KEY`
   - **Value:** `sk-proj-xxx`
3. Repite para `OPENAI_MODEL=gpt-4-turbo`
4. Haz clic en **Save**

### Paso 5: Acceder a la aplicación

Tu API estará en: `https://virf-api.azurewebsites.net/health`

---

## 4. GitHub Copilot para Desarrollo

### Instalación

1. En VS Code, instala extensión **GitHub Copilot**
2. Haz clic en tu perfil → **Sign in to GitHub**
3. Autoriza Copilot

### Uso para VIRF

#### 4.1 Debugging de errores

Cuando ocurra un error:

```python
# Pega el error aquí y pregunta a Copilot
# Copilot → Chat → Explica este stack trace
# Copilot sugerirá la solución automáticamente
```

#### 4.2 Completado automático

```python
def evaluar_ambito_completo(ambito: str, actividades: list):
    """
    # Copilot completará automáticamente esta función
    # Presiona Tab para aceptar sugerencias
    """
```

#### 4.3 Test unitarios

```python
def test_calcular_score_global():
    # Copilot sugiere tests automáticamente
    pass
```

---

## 5. Microsoft Copilot Studio (Sin Código)

### Objetivo

Crear un **chatbot conversacional** para que los usuarios finales consulten resultados sin tocar código.

### Paso 1: Crear Copilot Studio Project

1. Ve a https://copilotstudio.microsoft.com
2. Haz clic en **Create**
3. Nombre: `VIRF Auditor`
4. Language: `Spanish`
5. Haz clic en **Create**

### Paso 2: Conectar a la API REST de VIRF

1. En Copilot Studio, haz clic en **Copilots → Manage plugins**
2. Haz clic en **Create a new plugin** → **Custom connector**
3. Completa:
   - **Name:** `VIRF API`
   - **Base URL:** `https://virf-api.azurewebsites.net`
   - **Authentication:** `API Key` (si lo requiere)
4. Haz clic en **Create**

### Paso 3: Crear flujo conversacional

En el editor visual:

1. Haz clic en **New topic**
2. Nombre: `Evaluar Modelo`
3. **Trigger phrases:**
   - "Quiero evaluar un modelo"
   - "Necesito auditar mi modelo de riesgo"
   - "¿Cómo está mi modelo?"

4. **Flujo de conversación:**

```
User: "Quiero evaluar el Modelo LaR"
  ↓
System: "¿Cuál es el Tier del modelo? (1 o 2)"
  ↓
User: "Tier 1"
  ↓
System: [Llama VIRF API]
  ↓
API response: {score_global: 3.75, semaforo: ACEPTABLE}
  ↓
System: "✅ Modelo LaR (Tier 1): ACEPTABLE (3.75/5)
         Documento: [link al informe]"
```

### Paso 4: Publicar Copilot

1. Haz clic en **Publish**
2. Elige canales: Teams, Web, Facebook, etc.
3. Haz clic en **Publish changes**

---

## 6. Integración Completa: De Script a Agente

### Arquitectura Final

```
[Usuario Final]
       ↓
[Microsoft Copilot Studio]  ← Chat conversacional
       ↓
[Azure API Management]      ← Rate limiting, autenticación
       ↓
[VIRF Container/App]        ← Motor de evaluación
       ↓
[Azure Storage]             ← Inputs, outputs, cache
       ↓
[OpenAI/Anthropic API]      ← LLM para análisis
```

### Implementar Flujo Completo

**Paso 1:** Modificar `api_server.py` para retornar respuestas conversacionales:

```python
@app.route("/chat", methods=["POST"])
def chat():
    """
    Endpoint para Copilot Studio
    
    Request:
    {
        "mensaje": "Quiero evaluar el Modelo LaR"
    }
    """
    data = request.get_json()
    mensaje = data.get("mensaje", "")
    
    # Parse de intención (simplificado)
    if "evaluar" in mensaje.lower():
        return jsonify({
            "respuesta": "¿Cuál es el nombre del modelo y el Tier (1 o 2)?",
            "tipo": "pregunta"
        })
    
    if "Tier" in mensaje:
        # Ejecutar evaluación
        score = 3.75
        return jsonify({
            "respuesta": f"✅ Modelo evaluado: {score}/5 (ACEPTABLE)",
            "tipo": "resultado",
            "score": score,
            "informe_url": "https://storage.azure.com/..."
        })
    
    return jsonify({"respuesta": "No entendí. ¿Puedes reformular?"})
```

**Paso 2:** En Copilot Studio, configurar el topic para usar este endpoint.

---

## 7. Monitoreo y Alertas

### Azure Application Insights

1. En **App Service → virf-api → Application Insights**
2. Haz clic en **Turn on** si no está habilitado
3. Verás:
   - ✅ Uptime de la aplicación
   - ✅ Request/respuesta times
   - ✅ Errores con stack trace
   - ✅ Custom events

### Configurar alertas

```bash
az monitor metrics alert create \
  --resource-group virf-rg \
  --name "VIRF-API-Down" \
  --scopes "/subscriptions/{id}/resourceGroups/virf-rg/providers/Microsoft.Web/sites/virf-api" \
  --condition "avg Availability < 99" \
  --window-size 5m \
  --evaluation-frequency 1m
```

---

## 8. Costos Estimados

### Desglose por servicio (Azure + Copilot Studio)

| Servicio | Pricing | Uso | Costo/Mes |
| --- | --- | --- | --- |
| **Container Instances** | $0.0000015/seg | 50 auditorías (1h total) | $5-10 |
| **App Service (Basic)** | $0.0738/hora | 730 horas | $54 |
| **Storage Account** | $0.024/GB | 50GB | $1.20 |
| **API Management** | $0.40/1K calls | 10K calls | $4 |
| **Copilot Studio** | $0 (preview) | Unlimited | $0 |
| **Application Insights** | $0.71/GB | 10GB | $7 |
| **OpenAI API** | $10-30/1M tokens | 100 auditorías | $5 |
| **TOTAL** | | | **$77-81/mes** |

**Presupuesto recomendado:** ~$100/mes para producción con SLA del 99%.

---

## 9. Troubleshooting

### "Container no inicia"

```bash
# Ver logs
az container logs --resource-group virf-rg --name virf-container

# Aumentar memory
az container update --resource-group virf-rg --name virf-container --memory 2
```

### "API timeout después de 30 segundos"

**Solución:** Implementar async/queue:

```python
from azure.storage.queue import QueueClient
import uuid

@app.route("/evaluar-async", methods=["POST"])
def evaluar_async():
    # Agregar tarea a queue
    task_id = str(uuid.uuid4())
    queue_client.send_message(request.get_json())
    
    return jsonify({
        "task_id": task_id,
        "status_url": f"/status/{task_id}"
    })

@app.route("/status/<task_id>", methods=["GET"])
def get_status(task_id):
    # Retorna estado del task
    return jsonify({"status": "processing", "progress": 45})
```

### "Copilot Studio no puede conectar a API"

1. Verifica que tu API esté públicamente accesible (sin autenticación por ahora)
2. En Copilot Studio, prueba la conexión manualmente
3. Si falla, agrega CORS headers en tu API:

```python
from flask_cors import CORS

CORS(app, resources={r"/*": {"origins": "*"}})
```

---

## ✅ Checklist de Productivización

- [ ] `api_server.py` creado y testado localmente
- [ ] `Dockerfile` construido y verificado
- [ ] Imagen subida a Azure Container Registry
- [ ] ACI o App Service deployed en Azure
- [ ] API health check respondiendo
- [ ] Variables de entorno configuradas (API keys)
- [ ] GitHub Copilot instalado y conectado
- [ ] Copilot Studio project creado
- [ ] API connector registrado en Copilot Studio
- [ ] Topic conversacional funcionando
- [ ] Application Insights monitorando
- [ ] Alertas configuradas
- [ ] Documentación actualizada

---

## 📚 Recursos

| Recurso | Link |
| --- | --- |
| Azure Container Instances | https://learn.microsoft.com/en-us/azure/container-instances/ |
| Azure App Service | https://learn.microsoft.com/en-us/azure/app-service/ |
| GitHub Copilot | https://github.com/features/copilot |
| Copilot Studio | https://copilotstudio.microsoft.com |
| Azure SDK Python | https://learn.microsoft.com/en-us/python/azure/ |

---

**Última actualización:** 2026-05-09

