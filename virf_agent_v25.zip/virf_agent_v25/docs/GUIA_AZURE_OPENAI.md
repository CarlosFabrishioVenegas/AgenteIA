# 🔵 Guía de Configuración: Azure OpenAI

**Última actualización:** Mayo 2026  
**Versión:** VIRF Agent v23+

---

## 📋 Contenido

1. [Requisitos previos](#requisitos-previos)
2. [Obtener credenciales Azure](#obtener-credenciales-azure)
3. [Configurar archivo .env](#configurar-archivo-env)
4. [Validar configuración](#validar-configuración)
5. [Cambiar entre Anthropic y Azure](#cambiar-entre-anthropic-y-azure)
6. [Troubleshooting](#troubleshooting)

---

## Requisitos previos

### Software
- Python 3.9+
- pip (gestor de paquetes)

### Acceso
- Cuenta de Azure activa (suscripción)
- Recurso Azure OpenAI deployado
- Permiso de "Contributor" o superior

### Dependencias instaladas
```bash
pip install openai
pip install python-dotenv
```

Verifica:
```bash
python -c "import openai; print(f'OpenAI {openai.__version__} instalado')"
```

---

## Obtener credenciales Azure

### Paso 1: Acceder a Azure Portal

1. Ve a **https://portal.azure.com/**
2. Inicia sesión con tu cuenta de Azure

### Paso 2: Buscar tu recurso Azure OpenAI

1. En la barra de búsqueda superior, escribe: `openai`
2. Haz clic en **"Azure OpenAI"** (o en tu recurso específico)
3. Selecciona tu recurso de la lista

### Paso 3: Obtener credenciales

En la página de tu recurso Azure OpenAI:

#### 🔑 **API Key**
- Panel izquierdo → **"Keys and Endpoint"**
- Copia cualquiera de las dos keys (Key 1 o Key 2)
- **Ejemplo:** `abc123def456ghi789jkl012mno345pqr`

#### 📡 **Endpoint**
- En la misma sección **"Keys and Endpoint"**
- Copia la URL bajo **"Endpoint"**
- **Formato esperado:** `https://turecurso.openai.azure.com/`
- **Ejemplo:** `https://virf-openai-prod.openai.azure.com/`

#### 🚀 **Deployment Name**
- Panel izquierdo → **"Model deployments"** (o Deployments)
- Busca tu deployment (ej: `gpt-4-turbo`, `gpt-35-turbo`, `claude-sonnet`)
- Anota el nombre exacto del deployment
- **Ejemplo:** `gpt-4-turbo-deployment`

---

## Configurar archivo .env

### Paso 1: Crear o editar .env

En la **raíz del proyecto** (donde está `agente.py`):

```bash
# Windows PowerShell
notepad .env

# macOS/Linux
nano .env
```

### Paso 2: Cambiar proveedor de IA a Azure OpenAI

**Localiza esta línea:**
```env
IA_PROVEEDOR=anthropic
```

**Cámbiala a:**
```env
IA_PROVEEDOR=azure_openai
```

### Paso 3: Agregar credenciales de Azure OpenAI

**Reemplaza los placeholders con tus valores reales:**

```env
# ═══════════════════════════════════════════════════════════════════════════
# ▼▼▼ AZURE OPENAI CONFIGURATION ▼▼▼
# ═══════════════════════════════════════════════════════════════════════════

# Tu API Key de Azure OpenAI (obtenida en Paso 3 arriba)
AZURE_OPENAI_API_KEY=abc123def456ghi789jkl012mno345pqr

# Tu endpoint Azure OpenAI (obtenido en Paso 3 arriba)
# Formato: https://turecurso.openai.azure.com/
AZURE_OPENAI_ENDPOINT=https://virf-openai-prod.openai.azure.com/

# Nombre del deployment en Azure (obtenido en Paso 3 arriba)
AZURE_OPENAI_DEPLOYMENT=gpt-4-turbo-deployment

# API Version (normalmente OK así, pero puedes cambiar si es necesario)
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# Máximo tokens para respuestas (aumenta si necesitas respuestas más largas)
AZURE_OPENAI_MAX_TOKENS=4096

# ═══════════════════════════════════════════════════════════════════════════
```

### Paso 4: Desabilitar Anthropic (opcional pero recomendado)

Si anteriormente usabas Anthropic, comenta o borra esta línea:

```env
# ANTHROPIC_API_KEY=sk-ant-api03-...  ← Comentada (deshabilitada)
```

### Archivo .env completo - Ejemplo

```env
# ═════════════════════════════════════════════════════════════════════════════
# AGENTE VIRF — CONFIGURACIÓN CENTRAL
# ═════════════════════════════════════════════════════════════════════════════

# Selecciona tu proveedor: "anthropic" | "azure_openai"
IA_PROVEEDOR=azure_openai

# ─────────────────────────────────────────────────────────────────────────────
# Azure OpenAI Configuration (Activo si IA_PROVEEDOR=azure_openai)
# ─────────────────────────────────────────────────────────────────────────────

AZURE_OPENAI_API_KEY=abc123def456ghi789jkl012mno345pqr
AZURE_OPENAI_ENDPOINT=https://virf-openai-prod.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4-turbo-deployment
AZURE_OPENAI_API_VERSION=2024-02-15-preview
AZURE_OPENAI_MAX_TOKENS=4096

# ─────────────────────────────────────────────────────────────────────────────
# Parámetros globales
# ─────────────────────────────────────────────────────────────────────────────

MAX_CHARS_DOC=15000          # Máx. caracteres por documento
MAX_CHARS_CODIGO=8000        # Máx. caracteres por script Python
MAX_FILAS_EXCEL=200          # Máx. filas por hoja Excel
TIMEOUT_SEGUNDOS=30          # Timeout para llamadas API
REINTENTOS_API=3             # Número de reintentos ante fallos

MODO=debug                   # "debug" | "produccion"

# ─────────────────────────────────────────────────────────────────────────────
# Caché de documentos
# ─────────────────────────────────────────────────────────────────────────────

CACHE_ENABLED=1              # 1=Habilitado en preprdc, 0=Deshabilitado
CACHE_DIR=.cache_docs        # Carpeta local del caché
```

---

## Validar configuración

### Paso 1: Ejecutar test de conectividad

```bash
python agente.py --help
```

Esto debería mostrar el menú de ayuda **SIN errores** sobre API keys.

### Paso 2: Test completo de conexión

```bash
python -c "
from config import get_cliente_ia
cliente = get_cliente_ia()
print('✅ Conexión exitosa a Azure OpenAI')
"
```

**Salida esperada:**
```
✅ Cliente IA listo: azure_openai (gpt-4-turbo-deployment)
✅ Conexión exitosa a Azure OpenAI
```

### Paso 3: Ejecutar pipeline en modo PRE-PRODUCCIÓN

Para tu primer test, usa modo **PRE-PRODUCCIÓN** (sin `--prdc`):

```bash
python agente.py --titulo "Test Azure" --tier 1
```

Esto:
- ✅ Valida la API key
- ✅ Lee los estandares VIRF
- ✅ Carga documentos de evidencia
- ✅ Evalúa 1-2 ámbitos (rápido)
- ❌ No genera Word (para testear sin esperar)

**Tiempo esperado:** 2-5 minutos

---

## Cambiar entre Anthropic y Azure

### De Anthropic a Azure OpenAI

1. **Edita `.env`:**
   ```env
   # CAMBIO 1:
   IA_PROVEEDOR=azure_openai  # (era: anthropic)
   
   # CAMBIO 2: Agrega tus credenciales Azure
   AZURE_OPENAI_API_KEY=tu_key_aqui
   AZURE_OPENAI_ENDPOINT=https://...
   AZURE_OPENAI_DEPLOYMENT=gpt-4-turbo-deployment
   ```

2. **Verifica:**
   ```bash
   python agente.py --estadisticafeedback
   ```

### De Azure OpenAI a Anthropic

1. **Edita `.env`:**
   ```env
   # CAMBIO 1:
   IA_PROVEEDOR=anthropic  # (era: azure_openai)
   
   # CAMBIO 2: Asegúrate de que tu API key de Anthropic está configurada
   ANTHROPIC_API_KEY=sk-ant-api03-...
   ```

2. **Verifica:**
   ```bash
   python agente.py --estadisticafeedback
   ```

---

## Troubleshooting

### ❌ Error: `AZURE_OPENAI_API_KEY not set`

**Causa:** API key no está en `.env` o está vacía.

**Solución:**
1. Abre `.env` y verifica:
   ```env
   AZURE_OPENAI_API_KEY=abc123def456ghi789jkl012mno345pqr
   ```
2. Reemplaza `abc123...` con tu key real (sin comillas)
3. Guarda y cierra el archivo
4. Reinicia tu terminal

---

### ❌ Error: `401 Unauthorized`

**Causa:** API key inválida o expirada.

**Solución:**
1. Ve a Azure Portal → "Keys and Endpoint"
2. Copia la **Key 1** nuevamente (puede haber cambiado)
3. Actualiza `.env`
4. Verifica que no haya espacios en blanco antes/después de la key

---

### ❌ Error: `404 Not Found` + `AZURE_OPENAI_ENDPOINT`

**Causa:** Endpoint inválido o deployment inexistente.

**Solución:**
1. Verifica el **Endpoint** en Azure Portal (debe terminar con `/`)
   ```env
   AZURE_OPENAI_ENDPOINT=https://virf-openai-prod.openai.azure.com/  ✅
   AZURE_OPENAI_ENDPOINT=https://virf-openai-prod.openai.azure.com   ❌
   ```

2. Verifica el **Deployment Name** exacto:
   - Panel de Azure → "Model deployments"
   - Usa el nombre exacto (mayúsculas/minúsculas importan)

---

### ❌ Error: `Connection timed out` o `Network error`

**Causa:** Problema de conectividad de red.

**Solución:**
1. **Verifica tu conexión a Internet:**
   ```bash
   ping google.com
   ```

2. **Verifica que Azure OpenAI sea accesible:**
   ```bash
   curl https://virf-openai-prod.openai.azure.com/
   ```

3. **Comprueba firewall/proxy:** Si estás en una red corporativa, puede que necesites:
   - Configurar proxy en Python
   - Contactar a tu equipo IT

---

### ⚠️ Advertencia: `Tiempo de respuesta lento (>10s)`

**Causa:** Red lenta o modelo sobrecargado.

**Soluciones:**
- Reduce `MAX_CHARS_DOC` en `.env` de 15000 a 8000
- Usa `--no-cache` solo si el caché está corrupto
- Intenta en otra región de Azure (si tienes acceso)

---

### ❌ Cambio de API key, pero sigue usando key antigua

**Causa:** Python está usando una versión cached del módulo.

**Solución:**
```bash
# Borra el caché de Python
rm -r __pycache__
rm -r modulos/__pycache__
rm -r motor/__pycache__

# Reinicia Python
python agente.py --titulo "Test" --tier 1
```

---

## Modelos disponibles en Azure OpenAI

Según tu suscripción, puedes tener acceso a:

| Deployment | Usar si... |
|:--|:--|
| `gpt-4-turbo` | Máx. calidad, más lento |
| `gpt-4` | Buena calidad y velocidad |
| `gpt-35-turbo` | Rápido, menos preciso |
| `claude-sonnet` | Si has migrado a Anthropic en Azure |

Verifica en Azure Portal → "Model deployments" qué tienes deployado.

---

## Soporte

- **Documentación oficial:** https://learn.microsoft.com/es-es/azure/ai-services/openai/
- **API Reference:** https://learn.microsoft.com/es-es/azure/ai-services/openai/reference
- **Issues en este proyecto:** Ver `COMIENZA_AQUI.md`

---

**✅ Configuración completada. Ahora ejecuta:**

```bash
python agente.py --titulo "Mi Modelo" --tier 1
```
