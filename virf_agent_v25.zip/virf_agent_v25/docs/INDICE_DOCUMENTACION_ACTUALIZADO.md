# 📚 Índice Completo de Documentación VIRF v21

**Última actualización:** 2026-05-09

---

## 📖 Documentación Principal

### [README.md](../README.md)
**Documentación central del proyecto**
- Descripción general de VIRF
- Instalación rápida
- Arquitectura del sistema
- Pipelines disponibles (Pipeline 1 y Pipeline 2)
- Sistema de caché
- Troubleshooting completo
- **Secciones:** 11 secciones, ~940 líneas

---

## ☁️ Guías de Integración y Deployment

### 1. [GUIA_OPENAI.md](./GUIA_OPENAI.md)
**Migrar de Anthropic Claude a OpenAI (GPT-4 / GPT-4 Turbo)**

| Sección | Contenido |
| --- | --- |
| Comparación | Tabla: Claude vs GPT-4 vs GPT-4 Turbo |
| Requisitos | Obtener API key de OpenAI |
| Paso a paso | 6 pasos: API key → requirements → .env → config.py → verificación |
| Troubleshooting | 4 problemas comunes y soluciones |
| Rollback | Cómo volver a Anthropic si lo necesitas |

**Cuándo usar:**
- Quieres cambiar a OpenAI para reducir costos
- GPT-4 Turbo es más rápido que Claude
- Necesitas soportar múltiples proveedores

---

### 2. [GUIA_DATABRICKS.md](./GUIA_DATABRICKS.md)
**Ejecutar VIRF en Databricks para procesamiento distribuido**

| Sección | Contenido |
| --- | --- |
| Ventajas | Por qué Databricks: escalabilidad, Spark, Delta Lake |
| Requisitos | Cuenta Databricks, acceso a datos cloud |
| Paso a paso | 7 pasos: crear workspace → notebook → cluster → instalar → ejecutar |
| Autoloader | Monitoreo automático de carpetas (opcional) |
| Monitoreo | Ver logs y exportar resultados |
| Troubleshooting | 4 problemas: módulos, variables, cluster, archivos grandes |
| Costos | ~$0-60/mes dependiendo de configuración |

**Cuándo usar:**
- Necesitas auditar **10+ modelos en paralelo**
- Los documentos son muy grandes (1GB+)
- Quieres automatizar ejecuciones diarias/semanales
- Tienes presupuesto para cloud computing

---

### 3. [GUIA_PRODUCTIVIZACION_NUBE.md](./GUIA_PRODUCTIVIZACION_NUBE.md)
**Convertir VIRF en solución empresarial en Azure + Copilot Studio**

| Sección | Contenido |
| --- | --- |
| Arquitectura | Diagrama: Copilot Studio → API Management → Azure Container → Storage |
| Opción A: ACI | Azure Container Instances (~$10-20/mes, simple) |
| Opción B: App Service | Azure Web App (~$15-50/mes, escalable) |
| GitHub Copilot | Usar Copilot para debugging y completado automático |
| Copilot Studio | Crear chatbot conversacional SIN CÓDIGO |
| Integración | Flujo completo: usuario → chat → VIRF → informe |
| Monitoreo | Application Insights para uptime y errores |
| Costos | Desglose de precios Azure (~$77-81/mes) |

**Cuándo usar:**
- Quieres un **chatbot conversacional** para usuarios finales
- Necesitas **API REST** pública accesible desde Internet
- Tienes budget para Azure Cloud
- Quieres integrar con **Teams, Web, o Facebook**

---

## 🔧 Configuración y Setup

### [.env.example](../.env.example)
Plantilla de variables de entorno. Copiar a `.env` y completar:
```env
ANTHROPIC_API_KEY=sk-ant-xxxxx
OPENAI_API_KEY=sk-proj-xxxxx
AZURE_OPENAI_API_KEY=xxxxx
AZURE_OPENAI_ENDPOINT=https://xxx.openai.azure.com/
```

---

## 📋 Tabla Comparativa: ¿Cuál Guía Usar?

| Caso de Uso | Recomendación |
| --- | --- |
| **Quiero usar OpenAI en lugar de Claude** | → [GUIA_OPENAI.md](./GUIA_OPENAI.md) |
| **Necesito procesar muchos modelos en paralelo** | → [GUIA_DATABRICKS.md](./GUIA_DATABRICKS.md) |
| **Quiero un chatbot empresarial (Copilot Studio)** | → [GUIA_PRODUCTIVIZACION_NUBE.md](./GUIA_PRODUCTIVIZACION_NUBE.md) |
| **Necesito ejecutar en la nube con Azure** | → [GUIA_PRODUCTIVIZACION_NUBE.md](./GUIA_PRODUCTIVIZACION_NUBE.md) |
| **Problemas generales, arquitectura, pipelines** | → [README.md](../README.md) |

---

## 🚀 Guía de Inicio Rápido por Escenario

### Escenario 1: Local + OpenAI
1. Lee [README.md](../README.md) - Sección 2 (Instalación)
2. Lee [GUIA_OPENAI.md](./GUIA_OPENAI.md)
3. Ejecuta: `python agente.py`

### Escenario 2: Databricks
1. Lee [README.md](../README.md) - Sección 9 (Deployment en Databricks)
2. Lee [GUIA_DATABRICKS.md](./GUIA_DATABRICKS.md) completa
3. Crea workspace en Databricks
4. Sube archivos y ejecuta notebook

### Escenario 3: Producción (Chatbot + API)
1. Lee [GUIA_PRODUCTIVIZACION_NUBE.md](./GUIA_PRODUCTIVIZACION_NUBE.md) completa
2. Elige Opción A (ACI, simple) u Opción B (App Service, escalable)
3. Deploy en Azure
4. Crea Copilot Studio project
5. Conecta API a Copilot

---

## 📊 Estadísticas de Documentación

| Archivo | Líneas | Secciones | Temas Clave |
| --- | --- | --- | --- |
| README.md | 940 | 11 | Arquitectura, pipelines, caché, troubleshooting |
| GUIA_OPENAI.md | 450+ | 10 | Migración Claude→OpenAI, comparación, costos |
| GUIA_DATABRICKS.md | 550+ | 11 | Deployment distribuido, Spark, Autoloader |
| GUIA_PRODUCTIVIZACION_NUBE.md | 650+ | 9 | Azure, Copilot Studio, CI/CD, monitoreo |
| **TOTAL** | **2590+** | **41** | **Cobertura completa de VIRF v21** |

---

## 🎓 Aprendizaje Progresivo

### Nivel 1: Principiante
1. Leer [README.md](../README.md) - Secciones 1-3
2. Ejecutar localmente con Anthropic
3. Generar un informe simple

### Nivel 2: Intermedio
1. Cambiar a OpenAI ([GUIA_OPENAI.md](./GUIA_OPENAI.md))
2. Entender arquitectura ([README.md](../README.md) - Sección 4)
3. Customizar pesos de ámbitos ([README.md](../README.md) - Sección 9)

### Nivel 3: Avanzado
1. Agregar nuevos controles ([README.md](../README.md) - Sección 11.1)
2. Deploy en Databricks ([GUIA_DATABRICKS.md](./GUIA_DATABRICKS.md))
3. Crear API REST ([GUIA_PRODUCTIVIZACION_NUBE.md](./GUIA_PRODUCTIVIZACION_NUBE.md) - Sección 2)

### Nivel 4: Experto
1. Deploy en producción (Copilot Studio)
2. CI/CD automatizado (GitHub Actions)
3. Monitoreo y alertas (Application Insights)
4. Multi-tenant (diferentes clientes)

---

## 🔗 Navegación Rápida

```
.
├── README.md                          ← EMPEZAR AQUÍ
├── COMIENZA_AQUI.md                   ← Guía de primer paso
├── docs/
│   ├── INDICE_DOCUMENTACION.md        ← ESTE ARCHIVO
│   ├── GUIA_OPENAI.md                 ← Cambiar a OpenAI
│   ├── GUIA_DATABRICKS.md             ← Databricks deployment
│   └── GUIA_PRODUCTIVIZACION_NUBE.md  ← Azure + Copilot
├── agente.py                          ← Punto de entrada
├── config.py                          ← Configuración
├── modulos/
│   ├── motor_ia.py                    ← Pipeline 2 (6 ámbitos)
│   ├── motor_ia_v2.py                 ← Pipeline 1 (controles)
│   └── ...
└── motor/
    ├── Mx_00_CargaRutas.py            ← Rutas y constantes
    ├── Mx_01_LecturaEvidencias.py     ← Leer PDFs, Excel, scripts
    ├── Mx_02_EstructuraPrompt.py      ← Armar prompts
    ├── Mx_03_LlamarIA.py              ← Llamar OpenAI/Anthropic
    ├── Mx_04_MotorControlesData.py    ← Controles automáticos
    └── Mx_05_GeneradorWord.py         ← Generar reportes
```

---

## ❓ FAQ Rápido

**P: ¿Por dónde empiezo?**  
R: Lee [README.md](../README.md) secciones 1-3, luego ejecuta `python agente.py`

**P: ¿Cómo cambio a OpenAI?**  
R: Lee [GUIA_OPENAI.md](./GUIA_OPENAI.md) completa (15 min)

**P: ¿Puedo ejecutar en Databricks?**  
R: Sí, lee [GUIA_DATABRICKS.md](./GUIA_DATABRICKS.md) (30 min de setup)

**P: ¿Cómo hago un chatbot para usuarios?**  
R: Lee [GUIA_PRODUCTIVIZACION_NUBE.md](./GUIA_PRODUCTIVIZACION_NUBE.md) (1-2 horas de setup)

**P: ¿Cuál es el costo de usar VIRF?**  
R: Depende del proveedor:
- **Local + Anthropic:** ~$15-30/auditoría
- **Local + OpenAI:** ~$5-10/auditoría
- **Databricks + OpenAI:** ~$50-100/mes (para 100+ auditorías)
- **Azure + Copilot Studio:** ~$77/mes (infraestructura)

---

## 📞 Soporte

Si tienes problemas no documentados aquí:

1. Busca en **Troubleshooting** de cada guía
2. Revisa [README.md](../README.md) - Sección 10
3. Verifica los logs en `audit_logs/`
4. Contacta al equipo de desarrollo

---

**Versión:** 2.0  
**Última actualización:** 2026-05-09  
**Mantenedor:** Sistema VIRF v21

