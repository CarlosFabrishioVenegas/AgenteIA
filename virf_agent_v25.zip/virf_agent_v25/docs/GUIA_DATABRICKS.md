# 🚀 Guía Completa: Deployment y Ejecución en Databricks

**Versión:** 2.0  
**Última actualización:** 2026-05-09  
**Autor:** Sistema VIRF v21

---

## 🎯 Objetivo

Ejecutar el proyecto VIRF completo en **Databricks**, aprovechando el cluster computing distribuido de Databricks para procesar grandes volúmenes de datos de auditoría y generar informes automáticos en la nube.

---

## 📋 Tabla de Contenidos

1. [¿Por qué Databricks para VIRF?](#1-por-qué-databricks-para-virf)
2. [Requisitos Previos](#2-requisitos-previos)
3. [Paso 1: Crear Workspace en Databricks](#3-paso-1-crear-workspace-en-databricks)
4. [Paso 2: Preparar el Código para Databricks](#4-paso-2-preparar-el-código-para-databricks)
5. [Paso 3: Subir Archivos al Workspace](#5-paso-3-subir-archivos-al-workspace)
6. [Paso 4: Crear un Cluster Databricks](#6-paso-4-crear-un-cluster-databricks)
7. [Paso 5: Instalar Dependencias](#7-paso-5-instalar-dependencias)
8. [Paso 6: Ejecutar el Pipeline](#8-paso-6-ejecutar-el-pipeline)
9. [Paso 7: Integración con Autoloader (Opcional)](#9-paso-7-integración-con-autoloader-opcional)
10. [Monitoring y Logs](#10-monitoring-y-logs)
11. [Troubleshooting](#11-troubleshooting)

---

## 1. ¿Por qué Databricks para VIRF?

### Ventajas

| Característica | Beneficio |
| --- | --- |
| **Cluster Distribuido** | Procesa múltiples modelos en paralelo |
| **Spark Integration** | Carga documentos enormes (1GB+) rápidamente |
| **Notebooks Interactivos** | Debugging en tiempo real de problemas |
| **Delta Lake** | Versionado automático de reportes auditados |
| **Jobs Scheduler** | Ejecuciones automatizadas diarias/semanales |
| **Unity Catalog** | Control de acceso granular a archivos |

### Casos de Uso

- ✅ Auditar **10+ modelos en paralelo** en una sola ejecución
- ✅ Procesar documentación en **múltiples idiomas** distribuida
- ✅ Comparar **cambios históricos** de modelos automáticamente
- ✅ Exportar reportes **directamente a OneDrive/SharePoint**
- ✅ Integrar resultados con **Power BI** para dashboards

---

## 2. Requisitos Previos

### Software y Accesos

- ✅ Cuenta **Databricks** activa (Community o premium)
- ✅ **Azure Blob Storage** o **AWS S3** para almacenar archivos
- ✅ API key de OpenAI o Anthropic (según tu configuración)
- ✅ Python 3.9+ (lo maneja Databricks automáticamente)
- ✅ Archivos Excel (`Estandares_VIRF.xlsx`, `ControlesData.xlsx`) listos

### Acceso a Databricks Community Edition (Gratuito)

Si no tienes acceso premium:

1. Ve a https://databricks.com/en/product/pricing
2. Haz clic en **Community Edition** (gratis, sin tarjeta de crédito)
3. Completa el registro
4. Espera confirmación (usualmente 5 minutos)

---

## 3. Paso 1: Crear Workspace en Databricks

### 3.1 Iniciar sesión

1. Ve a tu workspace Databricks: `https://your-workspace.cloud.databricks.com/`
2. Haz login con tu cuenta

### 3.2 Crear una carpeta para VIRF

En el sidebar izquierdo:
1. Haz clic en **Workspace**
2. Haz clic en el icono de carpeta → **Create Folder**
3. Nombre: `VIRF_V21`
4. Haz clic en **Create**

### 3.3 Crear una carpeta para datos

1. Dentro de `VIRF_V21`, crea una subcarpeta: `datos_entrada`
2. Dentro de `datos_entrada`, crea: `modelos`, `evidencias`, `reportes`

Estructura final:
```
VIRF_V21/
├── datos_entrada/
│   ├── modelos/          ← Excel con Estandares_VIRF.xlsx, ControlesData.xlsx
│   ├── evidencias/       ← PDFs, scripts de modelos
│   └── reportes/         ← Informes Word generados
└── notebooks/            ← Notebooks .ipynb
```

---

## 4. Paso 2: Preparar el Código para Databricks

### 4.1 Crear archivo requirements-databricks.txt

Este archivo ya debería existir en el proyecto. Si no, crea `requirements-databricks.txt`:

```txt
# VIRF v21 - Dependencias para Databricks

# API Providers
anthropic>=0.40.0              # API Anthropic (Claude)
openai>=1.3.0                  # API OpenAI (GPT-4)

# Data Processing
pandas>=2.0.0
openpyxl>=3.1.0

# PDF Extraction
pdfplumber>=0.10.0

# Document Generation
python-docx>=1.1.0
python-pptx>=0.6.21

# Utilities
python-dotenv>=1.0.0
```

### 4.2 Crear Notebook Wrapper para Databricks

En tu máquina local, crea `agente_databricks.py`:

```python
# agente_databricks.py
# Wrapper para ejecutar VIRF en Databricks

import sys
import os
from pathlib import Path

# Detectar si estamos en Databricks
IS_DATABRICKS = "DATABRICKS_RUNTIME_VERSION" in os.environ

if IS_DATABRICKS:
    # En Databricks, los archivos están en /Workspace
    BASE_DIR = Path("/Workspace/VIRF_V21")
    DATOS_DIR = BASE_DIR / "datos_entrada"
    sys.path.insert(0, str(BASE_DIR))
else:
    # En local
    BASE_DIR = Path.cwd()
    DATOS_DIR = BASE_DIR / "inputs"

# Importar módulos VIRF
from config import get_cliente_ia
from modulos.motor_ia import (
    leer_estandares_virf,
    cargar_todos_inputs,
    evaluar_ambito_completo,
    calcular_score_global,
)
from modulos.motor_ia_v2 import orquestar_pipeline_virf

def ejecutar_en_databricks(tier: str = "1", prdc: bool = True):
    """
    Ejecuta VIRF completo en Databricks
    
    Args:
        tier: "1" o "2" (TIER I o TIER II)
        prdc: Si True, genera informe Word
    """
    
    print("🚀 Iniciando VIRF en Databricks")
    print(f"   Base Directory: {BASE_DIR}")
    print(f"   Tier: {tier}")
    
    try:
        # 1. Obtener cliente IA (detecta automáticamente el proveedor)
        cliente_ia = get_cliente_ia()
        print(f"✅ Cliente IA configurado: {type(cliente_ia).__name__}")
        
        # 2. Leer estándares y actividades
        print("📖 Leyendo estándares VIRF...")
        estandares = leer_estandares_virf(tier)
        print(f"✅ {len(estandares)} ámbitos cargados")
        
        # 3. Cargar documentación de entrada
        print("📂 Cargando documentación de entrada...")
        inputs = cargar_todos_inputs()
        print(f"✅ {len(inputs)} documentos cargados")
        
        # 4. Ejecutar orquestador completo
        print("🔄 Ejecutando pipeline de evaluación...")
        resultados = orquestar_pipeline_virf(
            tier=tier,
            generar_word=prdc,
            cliente_ia=cliente_ia,
        )
        
        print(f"✅ Pipeline completado")
        print(f"   Score Global: {resultados.get('score_global', 'N/A')}")
        print(f"   Semáforo: {resultados.get('semaforo', {}).get('label', 'N/A')}")
        
        return resultados
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        raise

if __name__ == "__main__":
    # Ejecutar en Databricks
    resultados = ejecutar_en_databricks(tier="1", prdc=True)
    print(f"\n📊 Resultados completos: {len(resultados)} campos")
```

---

## 5. Paso 3: Subir Archivos al Workspace

### 5.1 Opción A: Subida Manual por UI (Recomendado para primeros pasos)

1. En Databricks, ve a **Workspace → VIRF_V21 → datos_entrada → modelos**
2. Haz clic en ⬆️ **Upload** (arriba a la derecha)
3. Selecciona `Estandares_VIRF.xlsx` y `ControlesData.xlsx`
4. Haz clic en **Upload**

Repite para `datos_entrada/evidencias` con tus archivos PDF, scripts, etc.

### 5.2 Opción B: Subida por CLI (Databricks CLI)

Instala y configura Databricks CLI:

```bash
pip install databricks-cli
```

Luego:

```bash
# Configurar credenciales
databricks configure --token

# Subir archivos
databricks workspace import_dir ./modulos /VIRF_V21/modulos -o
databricks workspace import ./config.py /VIRF_V21/config.py -o
```

---

## 6. Paso 4: Crear un Cluster Databricks

### 6.1 Crear cluster (una sola vez)

1. En Databricks, haz clic en **Compute** (en el sidebar)
2. Haz clic en **Create Cluster**
3. Completa:
   - **Cluster Name:** `VIRF-Cluster`
   - **Databricks Runtime:** `14.3 LTS` (o más nuevo)
   - **Worker Type:** `i3.xlarge` (o más pequeño si presupuesto limitado)
   - **Workers:** `2` (o `1` para presupuesto)
   - **Driver Type:** `i3.xlarge`
4. Haz clic en **Create Cluster**

Espera 2-5 minutos a que el cluster se inicie (estado: "Running").

### 6.2 Verificar estado

En la página de **Compute**, verifica que tu cluster sea "Running" (verde).

---

## 7. Paso 5: Instalar Dependencias

### 7.1 Crear notebook de instalación

En **Workspace → VIRF_V21**, crea un notebook llamado `00_Instalar_Dependencias`:

1. Haz clic en **Create → Notebook**
2. Nombre: `00_Instalar_Dependencias`
3. Language: `Python`
4. Default Cluster: `VIRF-Cluster`
5. Haz clic en **Create**

### 7.2 Escribir comandos de instalación

En la primera celda:

```python
# Instalar dependencias de VIRF
%pip install -r /Workspace/VIRF_V21/requirements-databricks.txt
```

### 7.3 Ejecutar

Haz clic en ▶️ **Run** en la celda.

Espera a que termine (2-3 minutos). Verás:
```
Successfully installed anthropic-0.40.0 openai-1.3.0 ...
```

---

## 8. Paso 6: Ejecutar el Pipeline

### 8.1 Crear notebook principal

1. En **Workspace → VIRF_V21 → notebooks**, crea un notebook: `01_Ejecutar_VIRF`
2. Language: `Python`
3. Default Cluster: `VIRF-Cluster`

### 8.2 Código para ejecutar VIRF

Celda 1 - Importar módulos:

```python
import sys
from pathlib import Path

# Configurar paths de Databricks
BASE_DIR = Path("/Workspace/VIRF_V21")
sys.path.insert(0, str(BASE_DIR))

# Importar VIRF
from config import get_cliente_ia
from modulos.motor_ia import (
    leer_estandares_virf,
    cargar_todos_inputs,
    evaluar_ambito_completo,
    calcular_score_global,
    get_semaforo,
)

print("✅ Módulos VIRF importados correctamente")
```

Celda 2 - Ejecutar pipeline:

```python
# Configurar variables
TIER = "1"  # O "2"
GENERAR_WORD = True

print(f"🚀 Iniciando VIRF Pipeline 2 en Databricks")
print(f"   Tier: {TIER}")
print(f"   Generar Word: {GENERAR_WORD}")

# Obtener cliente IA
cliente_ia = get_cliente_ia()
print(f"✅ Cliente IA: {type(cliente_ia).__name__}")

# Ejecutar
try:
    estandares = leer_estandares_virf(TIER)
    print(f"✅ Estándares cargados: {len(estandares)} ámbitos")
    
    inputs = cargar_todos_inputs()
    print(f"✅ Inputs cargados: {len(inputs)} documentos")
    
    # Aquí va tu lógica de evaluación
    # ... (ver modulos/motor_ia.py para más detalles)
    
except Exception as e:
    print(f"❌ Error: {str(e)}")
    raise
```

Celda 3 - Ver resultados:

```python
# Mostrar resultados
import json

print("\n📊 RESULTADOS:")
print(f"Score Global: {score_global:.2f}")
print(f"Semáforo: {semaforo}")
print(f"\nScores por ámbito:")
for ambito, score in scores_por_ambito.items():
    print(f"  {ambito}: {score:.2f}")
```

### 8.3 Ejecutar

Haz clic en ▶️ **Run** para ejecutar todas las celdas.

El pipeline debería completarse en 5-15 minutos (depende del volumen de documentación).

---

## 9. Paso 7: Integración con Autoloader (Opcional)

**Autoloader** permite monitorear automáticamente una carpeta en la nube y ejecutar VIRF cada vez que se suben nuevos archivos.

### 9.1 Crear notebook de autoloader

En **Workspace → VIRF_V21 → notebooks**, crea: `02_Autoloader_VIRF`

```python
from pyspark.sql.functions import input_file_name, current_timestamp

# Configurar path de entrada (S3, Azure Blob Storage, etc.)
INPUT_PATH = "s3://mi-bucket/evidencias/"  # O "abfss://..." para Azure

# Crear Autoloader
(spark.readStream
    .format("cloudFiles")
    .option("cloudFiles.format", "parquet")  # O "pdf", "text", etc.
    .option("cloudFiles.schemaLocation", "/tmp/schema")
    .load(INPUT_PATH)
    .select(input_file_name().alias("filepath"), 
            current_timestamp().alias("timestamp"),
            "*")
    .writeStream
    .option("checkpointLocation", "/tmp/checkpoint")
    .option("mergeSchema", "true")
    .start("/tmp/evidencias_procesadas")
)

print("✅ Autoloader iniciado")
print(f"   Monitorando: {INPUT_PATH}")
```

---

## 10. Monitoring y Logs

### 10.1 Ver logs de ejecución

En Databricks:
1. Haz clic en **Workspace → VIRF_V21 → Run history** (parte superior)
2. Selecciona tu notebook
3. Haz clic en **View run details**

Verás:
- ✅ Tiempo de ejecución
- ✅ Logs de cada celda
- ✅ Errores con stack trace

### 10.2 Exportar logs

```python
# En una celda al final de tu notebook
import json
from datetime import datetime

log_data = {
    "timestamp": datetime.now().isoformat(),
    "tier": TIER,
    "score_global": score_global,
    "num_documentos": len(inputs),
    "duracion_segundos": 0,  # Calcula si quieres
}

# Guardar en DBFS (Databricks File System)
with open("/dbfs/VIRF_V21/logs/ejecucion.json", "w") as f:
    json.dump(log_data, f, indent=2)

print("✅ Logs guardados")
```

---

## 11. Troubleshooting

### Error: "Module not found: modulos"

**Causa:** Los módulos VIRF no están en el path correcto.

**Solución:**

```python
import sys
sys.path.insert(0, "/Workspace/VIRF_V21")
```

Coloca esto al inicio de tu notebook.

### Error: "OPENAI_API_KEY not found"

**Causa:** Las variables de entorno no están configuradas en Databricks.

**Solución:** En tu notebook:

```python
import os
os.environ["OPENAI_API_KEY"] = "sk-proj-xxxxxxx"
os.environ["OPENAI_MODEL"] = "gpt-4-turbo"
```

O mejor aún, usa **Databricks Secrets**:

```bash
# En tu terminal local
databricks secrets create-scope --scope virf-secrets
databricks secrets put --scope virf-secrets --key openai-key "sk-proj-xxx"
```

Luego en tu notebook:

```python
from databricks import secrets

api_key = secrets.get(scope="virf-secrets", key="openai-key")
os.environ["OPENAI_API_KEY"] = api_key
```

### Cluster se detiene solo

**Causa:** Timeout por inactividad (11 minutos por defecto en Community).

**Solución:** En la configuración del cluster:
1. Haz clic en **Compute**
2. Haz clic en tu cluster
3. Haz clic en **Edit**
4. En **Advanced Options**, aumenta **Terminate after X minutes of inactivity**
5. Haz clic en **Confirm**

### Archivo muy grande (>1GB)

**Causa:** Databricks tiene límites de memoria para notebooks.

**Solución:**
1. Divide el PDF en múltiples archivos
2. O usa **Spark** para procesar en chunks:

```python
from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("VIRF").getOrCreate()

# Procesar en paralelo
documentos_rdd = spark.sparkContext.binaryFiles("/Workspace/VIRF_V21/datos/*")
print(f"Total de documentos: {documentos_rdd.count()}")
```

---

## 📊 Tabla de Costos Estimados

| Componente | Pricing | Uso Típico | Costo/Mes |
| --- | --- | --- | --- |
| Databricks (Community) | Gratis | Hasta 70 horas de cluster | $0 |
| Databricks (Premium) | $0.40/DBU/hora | 40 horas/mes | ~$25-50 |
| OpenAI GPT-4 Turbo | $10-30/1M tokens | 1 auditoría = ~50K tokens | $0.50-1.50 |
| **Total** | | | **<$60/mes** |

---

## ✅ Checklist de Deployment en Databricks

- [ ] Cuenta Databricks creada y workspace activo
- [ ] Carpeta VIRF_V21 creada en Workspace
- [ ] Archivos Excel subidos a datos_entrada/modelos/
- [ ] requirements-databricks.txt presente en proyecto
- [ ] Cluster VIRF-Cluster creado y running
- [ ] Dependencias instaladas (notebook 00)
- [ ] Notebook principal (01) ejecutado sin errores
- [ ] Resultados visibles en logs
- [ ] Informe Word generado en datos_entrada/reportes/

---

## 📞 Soporte

Para más detalles sobre Databricks, consulta:
- **Documentación oficial:** https://docs.databricks.com
- **Databricks Academy:** https://academy.databricks.com

Para dudas específicas de VIRF, revisa [README.md](../README.md).

**Última actualización:** 2026-05-09

