# 📘 Guía Completa: Migrar de Anthropic Claude a OpenAI

**Versión:** 2.0  
**Última actualización:** 2026-05-09  
**Autor:** Sistema VIRF v21

## 🎯 Objetivo

Cambiar el proveedor de IA del proyecto VIRF desde **Anthropic Claude Sonnet 4.6** a **OpenAI GPT-4/GPT-4 Turbo**, manteniendo toda la funcionalidad del sistema.

---

## 📋 Tabla de Contenidos

1. [Comparación de Proveedores](#1-comparación-de-proveedores)
2. [Requisitos Previos](#2-requisitos-previos)
3. [Paso 1: Obtener API Key de OpenAI](#3-paso-1-obtener-api-key-de-openai)
4. [Paso 2: Actualizar requirements.txt](#4-paso-2-actualizar-requirementstxt)
5. [Paso 3: Configurar Variables de Entorno](#5-paso-3-configurar-variables-de-entorno)
6. [Paso 4: Actualizar config.py](#6-paso-4-actualizar-configpy)
7. [Paso 5: Modificar motor_ia.py y motor_ia_v2.py](#7-paso-5-modificar-motor_iapy-y-motor_ia_v2py)
8. [Paso 6: Verificar el Funcionamiento](#8-paso-6-verificar-el-funcionamiento)
9. [Troubleshooting](#9-troubleshooting)
10. [Rollback a Anthropic](#10-rollback-a-anthropic)

---

## 1. Comparación de Proveedores

| Aspecto | Anthropic Claude | OpenAI GPT-4 | OpenAI GPT-4 Turbo |
|--------|-----------------|------|------|
| **Costo (por 1M tokens)** | Input: $3, Output: $15 | Input: $30, Output: $60 | Input: $10, Output: $30 |
| **Contexto máximo** | 100K tokens | 128K tokens | 128K tokens |
| **Velocidad** | Rápida | Moderada | Rápida |
| **Recomendado para VIRF** | ✅ Excelente | ✅ Muy bueno | ✅ Óptimo (mejor) |
| **Hallazgos en prompts largos** | Muy detallados | Detallados | Muy detallados |

**Recomendación:** GPT-4 Turbo es la mejor opción para VIRF (balance costo-velocidad-precisión).

---

## 2. Requisitos Previos

- ✅ Proyecto VIRF v21 instalado en tu máquina
- ✅ Python 3.10+ funcionando
- ✅ Acceso a Internet para conectar con OpenAI
- ✅ Una cuenta de OpenAI (https://platform.openai.com)
- ✅ Suscripción activa con fondos disponibles

### Verificar que la instalación actual funciona

```bash
# En la carpeta raíz del proyecto
python agente.py --help
```

Debe mostrar el menú de opciones sin errores.

---

## 3. Paso 1: Obtener API Key de OpenAI

### 3.1 Crear cuenta en OpenAI (si no la tienes)

1. Ve a https://platform.openai.com
2. Haz clic en **Sign up** (Registrarse)
3. Completa tu correo, nombre y contraseña
4. Verifica tu email
5. Agrega información de pago (tarjeta de crédito)

### 3.2 Obtener tu API Key

1. Inicia sesión en https://platform.openai.com
2. Haz clic en tu perfil (esquina superior derecha) → **API keys**
3. Haz clic en **Create new secret key**
4. Copia la clave y **guárdala en un lugar seguro** (no la compartas)

```
sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

> ⚠️ **IMPORTANTE:** No subas esta clave a GitHub. Guárdala en `.env` (no versionado).

---

## 4. Paso 2: Actualizar requirements.txt

### 4.1 Abrir requirements.txt

```bash
# En Windows PowerShell
code requirements.txt
```

### 4.2 Buscar y reemplazar la dependencia de Anthropic

**BUSCAR:**
```txt
anthropic>=0.40.0          # API Anthropic - DEFAULT
```

**REEMPLAZAR CON:**
```txt
# anthropic>=0.40.0          # API Anthropic - DESHABILITADO (ahora usamos OpenAI)
openai>=1.3.0               # API OpenAI - GPT-4 / GPT-4 Turbo - DEFAULT
```

### 4.3 Instalar la nueva dependencia

```bash
# Eliminar Anthropic
pip uninstall anthropic -y

# Instalar OpenAI
pip install openai>=1.3.0
```

### 4.4 Verificar instalación

```bash
python -c "import openai; print(f'OpenAI version: {openai.__version__}')"
```

Debe mostrar algo como: `OpenAI version: 1.X.X`

---

## 5. Paso 3: Configurar Variables de Entorno

### 5.1 Abrir archivo .env

```bash
# En Windows PowerShell
code .env
```

### 5.2 Actualizar o agregar la variable de OpenAI

**AGREGAR ESTA LÍNEA:**
```env
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**Reemplaza con tu API key real.**

### 5.3 (OPCIONAL) Deshabilitar Anthropic

Si quieres deshabilitar Anthropic, comenta la línea:

```env
# ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# OpenAI
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
OPENAI_MODEL=gpt-4-turbo  # O gpt-4, gpt-3.5-turbo
```

### 5.4 Guardar .env

Presiona `Ctrl+S` para guardar.

---

## 6. Paso 4: Actualizar config.py

### 6.1 Abrir config.py

```bash
code config.py
```

### 6.2 Localizar la clase ClienteOpenAIIA

Busca esta clase (debería estar alrededor de la línea 198):

```python
class ClienteOpenAIIA:
    """Cliente para OpenAI (GPT-4, GPT-4 Turbo, GPT-3.5-Turbo)"""
```

Verifica que esté correctamente implementada:

```python
class ClienteOpenAIIA:
    def __init__(self, api_key: str, model: str = "gpt-4-turbo"):
        self.api_key = api_key
        self.model = model
        self.client = openai.OpenAI(api_key=api_key)
    
    def llamar_ia(self, prompt: str, max_tokens: int = 4000) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            temperature=0.7,
        )
        return response.choices[0].message.content
```

### 6.3 Actualizar la función get_cliente_ia()

Localiza esta función (alrededor de línea 260):

```python
def get_cliente_ia() -> ClienteIA:
    """
    Retorna el cliente IA apropiado según configuración en .env
    Orden de preferencia: OpenAI > Azure OpenAI > Anthropic
    """
    # 1. OPENAI (primera opción)
    openai_key = os.getenv("OPENAI_API_KEY", "").strip()
    if openai_key:
        openai_model = os.getenv("OPENAI_MODEL", "gpt-4-turbo")
        return ClienteOpenAIIA(api_key=openai_key, model=openai_model)
    
    # 2. AZURE OPENAI (segunda opción)
    azure_key = os.getenv("AZURE_OPENAI_API_KEY", "").strip()
    if azure_key:
        azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "")
        azure_model = os.getenv("AZURE_OPENAI_MODEL", "gpt-4")
        return ClienteAzureOpenAIIA(
            api_key=azure_key,
            endpoint=azure_endpoint,
            model=azure_model,
        )
    
    # 3. ANTHROPIC (tercera opción)
    anthropic_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if anthropic_key:
        return ClienteAnthropicIA(api_key=anthropic_key)
    
    # 4. ERROR
    raise ValueError(
        "No API key configurada. Configura OPENAI_API_KEY, "
        "AZURE_OPENAI_API_KEY o ANTHROPIC_API_KEY en .env"
    )
```

### 6.4 Guardar config.py

Presiona `Ctrl+S`.

---

## 7. Paso 5: Modificar motor_ia.py y motor_ia_v2.py

**IMPORTANTE:** No es necesario modificar estos archivos. El sistema está diseñado para funcionar con cualquier proveedor a través de la interfaz `ClienteIA` en `config.py`.

Sin embargo, **verifica que usen `get_cliente_ia()`:**

```bash
# Buscar en motor_ia.py
grep -n "get_cliente_ia" modulos/motor_ia.py

# Buscar en motor_ia_v2.py
grep -n "get_cliente_ia" modulos/motor_ia_v2.py
```

Ambos deben tener en sus funciones principales algo como:

```python
cliente_ia = get_cliente_ia()  # ← Esto selecciona automáticamente el proveedor
```

Si no lo tienen, **no modifiques estos archivos directamente** — es un bug del proyecto. Contacta al administrador.

---

## 8. Paso 6: Verificar el Funcionamiento

### 8.1 Test rápido desde Python

```bash
# En PowerShell desde la carpeta del proyecto
python -c "
from config import get_cliente_ia
cliente = get_cliente_ia()
print(f'✅ Cliente IA configurado: {type(cliente).__name__}')
respuesta = cliente.llamar_ia('¿Quién eres?', max_tokens=100)
print(f'Respuesta: {respuesta[:100]}...')
"
```

Debe mostrar algo como:
```
✅ Cliente IA configurado: ClienteOpenAIIA
Respuesta: Soy Claude, un asistente de IA creado por Anthropic...
```

### 8.2 Ejecutar un pipeline de prueba

```bash
# Test con Pipeline 1 (Controles de Calidad de Datos)
python agente.py --control

# O test con Pipeline 2 (Todos los Ámbitos)
python agente.py
```

Ambos deben ejecutarse sin errores de API y generar outputs en `outputs/`.

### 8.3 Verificar el informe generado

Abre `outputs/YYYY-MM-DD/VIRF_Informe_*.docx` en Word y verifica:

- ✅ Portada con título
- ✅ Resumen Ejecutivo con scores
- ✅ Detalle por ámbito con hallazgos
- ✅ Escala de evaluación

Si todo se ve correcto, **¡migración exitosa!**

---

## 9. Troubleshooting

### Error: "Invalid API key"

**Causa:** La API key de OpenAI es inválida o expiró.

**Solución:**
1. Verifica que copiaste correctamente la key de https://platform.openai.com/account/api-keys
2. Asegúrate de que tu cuenta tiene saldo disponible
3. Regenera la key si es necesario

```bash
# Test rápido
python -c "
import os
key = os.getenv('OPENAI_API_KEY', '')
if not key:
    print('❌ OPENAI_API_KEY no definida en .env')
else:
    print(f'✅ OPENAI_API_KEY definida: {key[:20]}...')
"
```

### Error: "Model gpt-4-turbo not found"

**Causa:** Tu cuenta no tiene acceso a GPT-4 Turbo (requiere suscripción de pago).

**Solución:** Cambia en `.env`:

```env
# Intenta con gpt-3.5-turbo (más barato, más rápido)
OPENAI_MODEL=gpt-3.5-turbo
```

O solicita acceso a GPT-4 en https://platform.openai.com.

### Error: "Rate limit exceeded"

**Causa:** Hiciste demasiadas llamadas a la API en poco tiempo.

**Solución:**
1. Espera 60 segundos antes de reintentar
2. Reduce el `max_tokens` en los prompts
3. Agrega delays entre llamadas en el código

```python
import time
time.sleep(2)  # Espera 2 segundos entre llamadas
```

### Error: "openai.AuthenticationError"

**Causa:** La key no está siendo leída correctamente de `.env`.

**Solución:**
1. Verifica que el archivo `.env` existe en la carpeta raíz
2. Asegúrate de que la línea **no tiene espacios extras**:

```env
# ❌ INCORRECTO
OPENAI_API_KEY = sk-proj-xxx

# ✅ CORRECTO
OPENAI_API_KEY=sk-proj-xxx
```

3. Recarga el proyecto o reinicia Python

---

## 10. Rollback a Anthropic

Si quieres volver a Anthropic Claude, sigue estos pasos:

### 10.1 En requirements.txt

```txt
# ❌ COMENTAR
# openai>=1.3.0

# ✅ DESCOMENTAR
anthropic>=0.40.0
```

### 10.2 En .env

```env
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
# OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

### 10.3 Reinstalar dependencias

```bash
pip uninstall openai -y
pip install anthropic>=0.40.0
```

### 10.4 Verificar

```bash
python agente.py --help
```

---

## 📊 Tabla de Modelos OpenAI Disponibles

| Modelo | Costo Input | Costo Output | Velocidad | Calidad | Recomendado |
|--------|----------|----------|----------|---------|----------|
| gpt-3.5-turbo | $0.50/1M | $1.50/1M | ⚡⚡⚡ Muy rápido | 7/10 | Para presupuestos ajustados |
| gpt-4 | $30/1M | $60/1M | ⚡⚡ Moderado | 9/10 | Balance óptimo |
| gpt-4-turbo | $10/1M | $30/1M | ⚡⚡⚡ Muy rápido | 9.5/10 | **✅ RECOMENDADO PARA VIRF** |

---

## ✅ Checklist de Migración

- [ ] API key de OpenAI obtenida y verificada
- [ ] requirements.txt actualizado (pip install openai)
- [ ] .env configurado con OPENAI_API_KEY
- [ ] config.py tiene ClienteOpenAIIA correctamente implementada
- [ ] get_cliente_ia() prioriza OpenAI
- [ ] Test rápido de Python ejecutado sin errores
- [ ] Pipeline 1 o Pipeline 2 ejecutado exitosamente
- [ ] Informe Word generado con hallazgos
- [ ] Resultados JSON guardados en outputs/

---

## 📞 Soporte

Si encuentras problemas no documentados aquí:

1. Verifica los logs en `audit_logs/`
2. Revisa la sección **Troubleshooting** de [README.md](../README.md)
3. Contacta al equipo de desarrollo

**Última actualización:** 2026-05-09

