#!/usr/bin/env python3
"""
DEBUG_PROMPTS_ENVIADOS.py
=========================
Captura los prompts que se envían a la API para debuggear.
"""

import os
import json
from pathlib import Path
from dotenv import load_dotenv

# Cargar configuración
load_dotenv()

# Importar funciones del motor
from motor.Mx_00_CargaRutas import RUTAS, AMBITO_A_INPUTS, INSTRUCCIONES_DIMENSION, MAX_CHARS_DOC
from motor.Mx_02_EstructuraPrompt import prompt_evaluar_dimension, estilo_por_defecto
from modulos.lector_inputs import cargar_todos_los_inputs

print("\n" + "="*80)
print("🔍 DEBUG: CAPTURANDO PROMPTS ENVIADOS A LA API")
print("="*80)

# Cargar inputs
print("\n1. Cargando inputs...")
BASE_DIR = Path(__file__).parent
inputs_config = {
    k: str(v) for k, v in RUTAS["inputs"].items()
}

try:
    todos_inputs = cargar_todos_los_inputs(inputs_config)
    print(f"   ✓ Inputs cargados: {len(todos_inputs)} categorías")
    
    # Mostrar contenido
    for categoria, docs in todos_inputs.items():
        if docs:
            print(f"\n   📁 {categoria}:")
            for nombre, contenido in docs.items():
                print(f"      • {nombre}: {len(contenido)} chars")
                
except Exception as e:
    print(f"   ❌ Error: {e}")

# Construir prompt de Documentación
print("\n2. Construyendo prompt para ámbito 'Documentación'...")

dimension = "Documentación"
actividades = [
    {
        "actividad": "Verifica la existencia de control de cambios/versiones",
        "control": "Verificar la existencia, suficienica y claridad del Manual Metodologico",
        "tipo_ctrl": "D",
        "requerida": True,
    }
]

documentos = []
for doc_type, doc_dict in todos_inputs.get("doc_modelamiento", {}).items():
    documentos.append({
        "nombre": doc_type,
        "contenido": doc_dict,
        "tipo": doc_type.split(".")[-1].upper()
    })

print(f"   • Documentos disponibles: {len(documentos)}")
for doc in documentos:
    print(f"     - {doc['nombre']}: {len(doc['contenido'])} chars")

# Generar prompt
estilo = estilo_por_defecto()

try:
    prompt = prompt_evaluar_dimension(
        dimension=dimension,
        actividades=actividades,
        documentos=documentos,
        estilo=estilo,
        modo="prdc",
    )
    
    print(f"\n3. Prompt generado:")
    print(f"   Tamaño total: {len(prompt)} caracteres")
    print(f"\n   Primeros 1500 caracteres del prompt:")
    print("   " + "─"*75)
    print("   " + "\n   ".join(prompt[:1500].split("\n")))
    print("   " + "─"*75)
    
    # Analizar qué documentos está incluyendo
    print(f"\n4. Análisis del prompt:")
    
    if "metodologico_modelamiento.docx" in prompt:
        print("   ✅ metodologico_modelamiento.docx INCLUIDO")
    else:
        print("   ❌ metodologico_modelamiento.docx NO INCLUIDO")
        
    if "operativo_modelamiento.docx" in prompt:
        print("   ✅ operativo_modelamiento.docx INCLUIDO")
    else:
        print("   ❌ operativo_modelamiento.docx NO INCLUIDO")
    
    # Contar secciones
    import re
    doc_sections = len(re.findall(r"^\[.*\.docx\]", prompt, re.MULTILINE))
    print(f"   • Documentos DOCX en prompt: {doc_sections}")
    
    # Guardar prompt a archivo
    output_file = BASE_DIR / "DEBUG_PROMPT_DOCUMENTACION.txt"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(prompt)
    print(f"\n   ✓ Prompt completo guardado en: {output_file}")
    
except Exception as e:
    print(f"   ❌ Error generando prompt: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*80 + "\n")
