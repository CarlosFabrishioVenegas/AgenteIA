import openpyxl

wb = openpyxl.load_workbook('inputs/Estandares_VIRF.xlsx', data_only=True)
ws = wb.active

print("Todos los ámbitos encontrados en el Excel:\n")
ambitos = {}
for i in range(2, ws.max_row+1):
    val = ws.cell(i, 2).value  # Columna B
    if val:
        val_clean = str(val).strip()
        if val_clean not in ambitos:
            ambitos[val_clean] = 0
        ambitos[val_clean] += 1

for amb, count in sorted(ambitos.items()):
    print(f"  '{amb}' ({count} registros)")

print("\n\nMAPEO EN Mx_00_CargaRutas.py (config esperada):")
config_mapeo = {
    "Documentación":    ["doc_modelamiento", "doc_seguimiento", "papers"],
    "Calidad de Datos": ["calidad_datos", "doc_modelamiento"],
    "Metodología":      ["doc_modelamiento", "papers", "doc_seguimiento"],
    "Gobierno":         ["doc_modelamiento", "implementacion"],
    "Implementación":   ["implementacion", "doc_modelamiento"],
    "Uso e Integración":["usos", "implementacion"],
}

for amb in config_mapeo.keys():
    print(f"  '{amb}'")

print("\n\n⚠️ DISCREPANCIAS:")
excel_ambitos = set(ambitos.keys())
config_ambitos = set(config_mapeo.keys())

en_excel_no_en_config = excel_ambitos - config_ambitos
en_config_no_en_excel = config_ambitos - excel_ambitos

if en_excel_no_en_config:
    print(f"\nEn Excel pero NO en config (mapeo ignorado):")
    for a in sorted(en_excel_no_en_config):
        print(f"  ❌ '{a}'")

if en_config_no_en_excel:
    print(f"\nEn config pero NO en Excel:")
    for a in sorted(en_config_no_en_excel):
        print(f"  ⚠️  '{a}'")

if not en_excel_no_en_config and not en_config_no_en_excel:
    print("  ✅ Nombres coinciden perfectamente")
