import openpyxl

wb = openpyxl.load_workbook('inputs/Estandares_VIRF.xlsx', data_only=True)
ws = wb.active
print("Primeras 15 filas del Excel:")
for i in range(1, min(15, ws.max_row+1)):
    fila = []
    for j in range(1, min(7, ws.max_column+1)):
        val = ws.cell(i, j).value
        fila.append(str(val)[:25] if val else "")
    print(f"Fila {i}: {fila}")

print("\n\nÁmbitos únicos encontrados:")
ambitos = set()
for i in range(2, ws.max_row+1):
    val = ws.cell(i, 1).value
    if val:
        ambitos.add(str(val).strip())

for a in sorted(ambitos):
    print(f"  '{a}'")
