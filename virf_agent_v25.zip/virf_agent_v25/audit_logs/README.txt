"""
CARPETA: audit_logs
═══════════════════════════════════════════════════════════════════════════════

PROPÓSITO:
──────────────────────────────────────────────────────────────────────────────

Esta carpeta contiene archivos de depuración (DEBUG_*.txt y DEBUG_*.py) generados
durante el desarrollo y mantenimiento del Agente VIRF. Se mantiene como backup
auditable para:

  1. Historial de diagnósticos realizados
  2. Trazabilidad de problemas identificados y corregidos
  3. Revisión de cambios en la configuración
  4. Análisis forense en caso de anomalías

CONTENIDO:
──────────────────────────────────────────────────────────────────────────────

Archivo                          Fecha         Propósito
────────────────────────────────────────────────────────────────────────────

DEBUG_AMBITOS.py                 2026-05-06    Diagnóstico inicial de nombres de ámbitos
DEBUG_AMBITOS_DETALLE.py         2026-05-06    Comparativa de nombres Excel vs Config
VERIFICAR_CORRECCION.py          2026-05-06    Validación post-corrección de mapeo
REPORTE_CORRECCION.py            2026-05-06    Reporte visual de la corrección
SOLUCION_EXPLICADA.txt           2026-05-06    Documentación de la solución
DEBUG_PROMPT_*.txt               2026-05-05    Prompts enviados al modelo (evaluaciones)
                                 2026-05-06    

LIMPIEZA:
──────────────────────────────────────────────────────────────────────────────

Estos archivos NO afectan el funcionamiento del agente. Se pueden:
  • Revisar para auditoría o depuración
  • Archivar periódicamente (mensualmente recomendado)
  • Eliminar si el espacio es crítico (conservar SOLUCION_EXPLICADA.txt)

IMPORTANTE: Si el usuario reporta un problema, los DEBUG_PROMPT_*.txt pueden
ser útiles para revisar exactamente qué se envió al modelo.

═══════════════════════════════════════════════════════════════════════════════
"""

print(__doc__)
