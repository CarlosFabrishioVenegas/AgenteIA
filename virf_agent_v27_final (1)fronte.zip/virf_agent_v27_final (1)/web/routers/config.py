"""
Configuración del proveedor IA (v2 · fase 2).

El proveedor y sus credenciales viven en el `.env` GLOBAL del proyecto:
son compartidos entre todos los validadores y todas las sesiones. Aquí
no se guarda nada por sesión.

En v1 este router también gestionaba «modelo actual» y «tier». En v2
eso vive en `modelos_store` (la ficha del modelo), y este router se
limita a lo del proveedor.
"""
from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Cookie, HTTPException
from pydantic import BaseModel, Field, field_validator

from ..services import env_service, sesion_store

router = APIRouter(prefix="/api/config", tags=["config"])

PROVEEDORES: dict[str, dict[str, list[str]]] = {
    "azure_openai": {
        "obligatorias": [
            "AZURE_OPENAI_API_KEY",
            "AZURE_OPENAI_ENDPOINT",
            "AZURE_OPENAI_DEPLOYMENT",
            "AZURE_OPENAI_API_VERSION",
        ],
        "opcionales": ["AZURE_OPENAI_MAX_TOKENS"],
    },
    "anthropic": {
        "obligatorias": ["ANTHROPIC_API_KEY"],
        "opcionales": ["ANTHROPIC_MODELO", "ANTHROPIC_MAX_TOKENS"],
    },
}

CLAVES_SECRETAS = {"AZURE_OPENAI_API_KEY", "ANTHROPIC_API_KEY"}


class ConfigProveedor(BaseModel):
    proveedor:    Literal["azure_openai", "anthropic"]
    credenciales: dict[str, str]

    @field_validator("credenciales")
    @classmethod
    def _sin_claves_raras(cls, v: dict[str, str]) -> dict[str, str]:
        for clave in v:
            if not clave.replace("_", "").isalnum():
                raise ValueError(f"nombre de variable inválido: {clave!r}")
        return v


def _snapshot_env() -> dict:
    env = env_service.leer_env()
    ficha = {"proveedor_activo": env.get("IA_PROVEEDOR", "azure_openai")}
    for prov, catalogo in PROVEEDORES.items():
        ficha[prov] = {}
        for clave in catalogo["obligatorias"] + catalogo["opcionales"]:
            if clave in CLAVES_SECRETAS:
                ficha[prov][clave] = {"seteada": bool(env.get(clave))}
            else:
                ficha[prov][clave] = {
                    "seteada": bool(env.get(clave)),
                    "valor":   env.get(clave, ""),
                }
    return ficha


def _validador_o_401(token: str | None) -> dict:
    val = sesion_store.sesion_activa(token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    return val


@router.get("")
def get_config(virf_token: str | None = Cookie(default=None)) -> dict:
    """Estado del .env + validador logueado (sin secretos)."""
    val = _validador_o_401(virf_token)
    return {
        "validador":   val,
        "env":         _snapshot_env(),
        "proveedores": PROVEEDORES,
    }


@router.post("/proveedor")
def set_proveedor(body: ConfigProveedor,
                   virf_token: str | None = Cookie(default=None)) -> dict:
    _validador_o_401(virf_token)
    catalogo = PROVEEDORES[body.proveedor]
    admitidas = set(catalogo["obligatorias"] + catalogo["opcionales"])
    intrusas = [k for k in body.credenciales if k not in admitidas]
    if intrusas:
        raise HTTPException(
            400,
            f"variables no válidas para '{body.proveedor}': {intrusas}. "
            f"Admitidas: {sorted(admitidas)}",
        )
    cambios: dict[str, str] = {"IA_PROVEEDOR": body.proveedor}
    for clave, valor in body.credenciales.items():
        if valor and valor.strip():
            cambios[clave] = valor.strip()
    env_service.actualizar_env(cambios)
    return {"ok": True, "env": _snapshot_env()}


@router.post("/verificar")
def verificar_conexion(virf_token: str | None = Cookie(default=None)) -> dict:
    _validador_o_401(virf_token)
    from config.ia import prueba_de_humo, metadatos_proveedor
    meta = metadatos_proveedor()
    resultado = prueba_de_humo()
    resultado["proveedor_meta"] = {
        "nombre":       meta.get("nombre"),
        "vars_revisar": meta.get("vars_revisar", []),
        "consola":      meta.get("consola"),
    }
    # Persistimos el modelo detectado en la sesión de login para que
    # /api/prompts/presupuesto y pipeline_runner calculen el presupuesto
    # de contexto real (perfil del catálogo) y no el conservador.
    modelo_ia = (resultado.get("modelo")
                 or resultado.get("modelo_real")
                 or resultado.get("deployment"))
    if modelo_ia:
        sesion_store.set_atributo_sesion(
            virf_token, "modelo_ia_detectado", str(modelo_ia))
        from ..services import presupuesto_service
        resultado["presupuesto_contexto"] = presupuesto_service.calcular(str(modelo_ia))
    return resultado
