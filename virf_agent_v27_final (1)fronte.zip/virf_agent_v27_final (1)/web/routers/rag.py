"""
Dominio & RAG: papers al RAG global + reconstrucción + dominios custom.

v2 · fase 4 + Mejora 1 (v2.2).

Alcance:
- `inputs/rag/{dominio}/` es GLOBAL — compartido entre validadores.
- Los 4 dominios FIJOS (LaR, VaR, conductuales, shared) no se tocan.
- Los CUSTOM se crean desde el panel Dominio & RAG y se registran en
  `web/data/dominios_custom.json`.
"""
from __future__ import annotations

import asyncio
import pickle
import sys
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Cookie, HTTPException
from pydantic import BaseModel, Field

from ..config_web import PROYECTO_DIR
from ..services import dominios_custom_store as dominios
from ..services import modelos_store, sesion_store

router = APIRouter(prefix="/api/rag", tags=["rag"])

RAG_INPUTS_DIR = PROYECTO_DIR / "inputs" / "rag"
RAG_INDICE_DIR = PROYECTO_DIR / "data" / "rag_lexico"


def _login_o_401(token: str | None) -> dict:
    val = sesion_store.sesion_activa(token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    return val


def _leer_indice(dominio: str) -> dict[str, Any]:
    """Estado del índice sin ejecutar el script — carga el .pkl directamente."""
    pkl = RAG_INDICE_DIR / f"{dominio}.pkl"
    if not pkl.is_file():
        return {"existe": False}
    try:
        with open(pkl, "rb") as f:
            idx = pickle.load(f)
    except Exception as exc:                     # noqa: BLE001
        return {"existe": True, "error": str(exc)}
    chunks = getattr(idx, "chunks", []) or []
    docs = {c.get("fuente") for c in chunks if isinstance(c, dict)}
    return {
        "existe":         True,
        "n_chunks":       len(chunks),
        "n_docs":         len(docs),
        "construido_en":  str(getattr(idx, "construido_en", "")),
        "version":        getattr(idx, "version", "?"),
    }


def _papers_en_disco(dominio: str) -> list[dict[str, Any]]:
    d = RAG_INPUTS_DIR / dominio
    if not d.is_dir():
        return []
    salida = []
    for p in sorted(d.iterdir()):
        if p.is_file() and not p.name.startswith("."):
            salida.append({"nombre": p.name, "tam": p.stat().st_size})
    return salida


def _modelos_que_usan(dom_id: str) -> list[str]:
    """
    Lista de "codigo/slug" de modelos que declaran este dominio.
    Se usa para bloquear el borrado.
    """
    usan: list[str] = []
    base = PROYECTO_DIR / "web" / "data" / "sesiones"
    if not base.is_dir():
        return usan
    for cod in base.iterdir():
        if not cod.is_dir():
            continue
        for slug in cod.iterdir():
            m = modelos_store.cargar(cod.name, slug.name)
            if m and m.get("dominio") == dom_id:
                usan.append(f"{cod.name}/{slug.name}")
    return usan


@router.get("/dominios")
def listar_dominios(virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    """Fijos primero, custom después. Cada uno con estado del índice y papers."""
    _login_o_401(virf_token)
    salida = []
    for d in dominios.listar():
        dom_id = d["id"]
        entrada = {**d, "dominio": dom_id,
                    "papers":  _papers_en_disco(dom_id),
                    "indice":  _leer_indice(dom_id)}
        salida.append(entrada)
    return {"dominios": salida}


# ── Crear/borrar dominio custom ────────────────────────────────────────

class NuevoDominio(BaseModel):
    nombre:         str = Field(..., min_length=2, max_length=80)
    descripcion:    str = Field("",  max_length=1000)
    palabras_clave: list[str] = Field(default_factory=list)


@router.post("/dominios/crear")
def crear_dominio(body: NuevoDominio,
                   virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    val = _login_o_401(virf_token)
    try:
        entrada = dominios.crear(
            nombre=body.nombre,
            descripcion=body.descripcion,
            palabras_clave=body.palabras_clave,
            creado_por=val["codigo"],
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    return {"dominio": entrada}


@router.delete("/dominios/{dom_id}")
def borrar_dominio(dom_id: str,
                    virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    _login_o_401(virf_token)
    if dom_id in dominios.DOMINIOS_FIJOS:
        raise HTTPException(400, f"'{dom_id}' es un dominio fijo; no se borra")
    usan = _modelos_que_usan(dom_id)
    if usan:
        raise HTTPException(409,
            f"no se puede eliminar '{dom_id}': lo usan {len(usan)} modelo(s): "
            + ", ".join(usan[:5]) + ("…" if len(usan) > 5 else ""))
    try:
        r = dominios.borrar(dom_id)
    except ValueError as exc:
        raise HTTPException(404, str(exc))
    return r


# ── Reconstrucción del índice ─────────────────────────────────────────

class Reconstruir(BaseModel):
    dominio: str
    force:   bool = True


@router.post("/reconstruir")
async def reconstruir(body: Reconstruir,
                       virf_token: str | None = Cookie(default=None)) -> dict[str, Any]:
    """
    Reconstruye el índice del dominio dado. Acepta cualquier dominio
    conocido (fijo o custom) o `all` para todos los fijos + custom.
    Coste 0 (RAG léxico local).
    """
    _login_o_401(virf_token)
    dom = body.dominio
    if dom != "all" and not dominios.existe(dom):
        raise HTTPException(400, f"dominio '{dom}' no existe")
    args = [sys.executable, "-u", "scripts/rebuild_rag_databricks.py",
            "--dominio", dom]
    if body.force:
        args.append("--force")
    proc = await asyncio.create_subprocess_exec(
        *args,
        cwd=str(PROYECTO_DIR),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    try:
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=300)
    except asyncio.TimeoutError:
        try: proc.terminate()
        except ProcessLookupError: pass
        raise HTTPException(504, "reconstrucción excedió 5 min; abortada")
    salida = (stdout or b"").decode("utf-8", errors="replace")
    return {
        "ok":         proc.returncode == 0,
        "exit_code":  proc.returncode,
        "salida":     salida,
        "dominios":   listar_dominios(virf_token)["dominios"],
    }
