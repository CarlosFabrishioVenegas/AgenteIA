"""
Chat argumentativo por sesión (v2 · fase 7).

Cada modelo lleva su propio chat, persistido a disco. Dos validadores
en dos modelos distintos chatean en paralelo sin colisión.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field

from ..services import chat_service, sesion_store, modelos_store
from ..services.contexto_sesion import contexto_sesion, SESIONES_DIR

router = APIRouter(tags=["chat"])


class IniciarChat(BaseModel):
    ruta: str = Field(..., description="'YYYY-MM-DD/fichero.json' relativo a outputs de la sesión")


@router.post("/api/chat/iniciar")
def iniciar_chat(body: IniciarChat,
                  ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    partes = body.ruta.split("/")
    if len(partes) != 2:
        raise HTTPException(400, "ruta debe ser 'YYYY-MM-DD/fichero.json'")
    fecha, fichero = partes
    ruta = (ctx["outputs"] / fecha / Path(fichero).name).resolve()
    try:
        ruta.relative_to(ctx["outputs"].resolve())
    except ValueError:
        raise HTTPException(400, "ruta fuera de outputs de la sesión")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {body.ruta}")

    datos = json.loads(ruta.read_text(encoding="utf-8"))
    s = chat_service.iniciar(ctx, datos, body.ruta)
    modelos_store.actualizar_actividad(
        ctx["validador"]["codigo"], ctx["modelo"]["slug"], estado="en_progreso")
    return chat_service.a_dict(s)


@router.get("/api/chat/estado")
def estado_chat(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    s = chat_service.sesion_activa(ctx)
    return {"activa": s is not None, "sesion": chat_service.a_dict(s)}


@router.get("/api/chat/observaciones")
def observaciones(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """Resumen enfocado para dashboards, sin arrastrar todos los mensajes."""
    s = chat_service.sesion_activa(ctx)
    if s is None:
        raise HTTPException(404, "no hay sesión de chat activa")
    return {
        "resumen": s.resumen(),
        "detalle": [
            {
                "numero":    i + 1,
                "ambito":    o.ambito,
                "actividad": o.actividad,
                "puntaje":   o.puntaje,
                "veredicto": o.veredicto,
                "hallazgo":  o.hallazgo_final,
                "intentos":  o.intentos,
            } for i, o in enumerate(s.observaciones)
        ],
    }


def _reconstruye_ctx(codigo: str, slug: str) -> dict | None:
    """
    Rehidrata un ctx a partir de la clave `codigo/slug` sin las cookies —
    lo necesita el WebSocket, que no tiene la dependencia Depends()
    disponible del mismo modo que los endpoints REST.
    """
    val = None
    reg = sesion_store.leer_validadores()
    if codigo in reg:
        val = reg[codigo]
    modelo = modelos_store.cargar(codigo, slug)
    if val is None or modelo is None:
        return None
    base = SESIONES_DIR / codigo / slug
    return {
        "validador": val, "modelo": modelo,
        "base":      base,
        "inputs":    base / "inputs",
        "outputs":   base / "outputs",
        "clave":     f"{codigo}/{slug}",
    }


@router.websocket("/ws/chat")
async def ws_chat(ws: WebSocket) -> None:
    """
    Requiere cookies `virf_token` (login) y `virf_modelo` (modelo activo).
    Sirve el chat del modelo activo. Persiste cada respuesta en disco.
    """
    await ws.accept()
    token  = ws.cookies.get("virf_token")
    modelo = ws.cookies.get("virf_modelo")
    val = sesion_store.sesion_activa(token)
    if val is None or not modelo:
        await ws.send_json({"tipo": "error",
                            "detalle": "sesión de login/modelo no válida"})
        await ws.close()
        return
    ctx = _reconstruye_ctx(val["codigo"], modelo)
    if ctx is None:
        await ws.send_json({"tipo": "error", "detalle": "modelo activo no existe"})
        await ws.close()
        return

    try:
        s = chat_service.sesion_activa(ctx)
        if s is None:
            await ws.send_json({"tipo": "error",
                                "detalle": "sin sesión de chat; lanza /api/chat/iniciar primero"})
            await ws.close()
            return
        await ws.send_json({"tipo": "estado", "sesion": chat_service.a_dict(s)})

        while True:
            bruto = await ws.receive_text()
            try:
                msg = json.loads(bruto)
            except json.JSONDecodeError:
                await ws.send_json({"tipo": "error", "detalle": "JSON inválido"})
                continue
            if msg.get("tipo") == "responder":
                texto = (msg.get("texto") or "").strip()
                if not texto:
                    await ws.send_json({"tipo": "error", "detalle": "respuesta vacía"})
                    continue
                # Bloqueante potencialmente lento (llamada al modelo real).
                await asyncio.to_thread(chat_service.responder, ctx, texto)
                s = chat_service.sesion_activa(ctx)
                await ws.send_json({"tipo": "estado", "sesion": chat_service.a_dict(s)})
            else:
                await ws.send_json({"tipo": "error",
                                    "detalle": f"tipo no soportado: {msg.get('tipo')}"})
    except WebSocketDisconnect:
        return
