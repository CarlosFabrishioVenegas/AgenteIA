"""
Controles de calidad de datos (v2 · fase 2).

- Catálogo (motores_datos): global, no depende de la sesión.
- Resultados de la entidad (motores_entidad): se leen de la EVIDENCIA
  de la sesión activa (`ctx.inputs`), no del `inputs/` raíz.
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/motores", tags=["controles-datos"])


@router.get("/catalogo")
def catalogo() -> dict[str, Any]:
    """Las 8 pruebas de `modulos.motores_datos.REGISTRO_MOTORES`."""
    from modulos.motores_datos import REGISTRO_MOTORES
    filas = []
    for nombre in sorted(REGISTRO_MOTORES):
        m = REGISTRO_MOTORES[nombre]
        filas.append({
            "nombre":      nombre,
            "descripcion": m.get("descripcion", ""),
            "requiere":    m.get("requiere", []),
            "opcional":    m.get("opcional", []),
            "ejemplo":     m.get("ejemplo", ""),
        })
    return {"n": len(filas), "motores": filas}


@router.get("/entidad")
def resultados_de_la_entidad(ctx: dict = Depends(contexto_sesion)) -> dict[str, Any]:
    """
    Lee las tablas de resultados que la entidad deja bajo
    `inputs/calidad_datos/resultadocalidad_de_datos/` DE LA SESIÓN
    activa. Carpeta ausente ⇒ 200 con lista vacía y aviso.

    Mejora 3 · v2.2 — Además de las tablas, se devuelven los reportes
    en TEXTO PLANO (`.txt`, `.md`) para que la UI los muestre y el
    agente los incluya como contexto adicional (los tratará como
    "reporte externo de QC" en el prompt).
    """
    from modulos.motores_entidad import leer_resultados
    try:
        r = leer_resultados(ctx["inputs"])
    except Exception as exc:                     # noqa: BLE001
        raise HTTPException(500, f"lector motores_entidad falló: {exc}")

    # Añade documentos de texto plano encontrados en la misma carpeta.
    from pathlib import Path
    carpeta = Path(r.get("carpeta") or (ctx["inputs"] / "calidad_datos"
                                          / "resultadocalidad_de_datos"))
    docs_texto: list[dict[str, Any]] = []
    if carpeta.is_dir():
        for p in sorted(carpeta.iterdir()):
            if p.is_file() and p.suffix.lower() in (".txt", ".md"):
                try:
                    contenido = p.read_text(encoding="utf-8", errors="replace")
                except OSError as exc:
                    contenido = f"[error leyendo {p.name}: {exc}]"
                docs_texto.append({
                    "nombre":    p.name,
                    "tam":       p.stat().st_size,
                    "contenido": contenido[:20_000],   # tope preventivo
                    "truncado":  len(contenido) > 20_000,
                })
    r["reportes_texto"] = docs_texto
    return r
