"""
Lectura de resultados de validación (v2 · fase 2).

Los JSON viven en `web/data/sesiones/{val}/{slug}/outputs/YYYY-MM-DD/`.
El endpoint `/actual` devuelve el JSON de la última corrida de la
sesión activa; `/lista` enumera todos los informes de esa sesión.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from ..services import pipeline_runner
from ..services.contexto_sesion import contexto_sesion

router = APIRouter(prefix="/api/resultados", tags=["resultados"])

_FECHA_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _outputs(ctx: dict) -> Path:
    return ctx["outputs"]


def _resolver(ctx: dict, fecha: str, fichero: str) -> Path:
    if not _FECHA_RE.match(fecha):
        raise HTTPException(400, f"fecha inválida: {fecha!r}")
    nombre = Path(fichero).name
    if nombre != fichero or nombre.startswith(".") or not nombre.endswith(".json"):
        raise HTTPException(400, f"nombre inválido: {fichero!r}")
    ruta = (_outputs(ctx) / fecha / nombre).resolve()
    try:
        ruta.relative_to(_outputs(ctx).resolve())
    except ValueError:
        raise HTTPException(400, f"ruta fuera de outputs de la sesión: {fichero!r}")
    if not ruta.is_file():
        raise HTTPException(404, f"no existe: {fecha}/{fichero}")
    return ruta


def _leer_json(ruta: Path) -> dict:
    try:
        return json.loads(ruta.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise HTTPException(500, f"JSON corrupto en {ruta.name}: {exc}")


@router.get("/lista")
def listar_resultados(ctx: dict = Depends(contexto_sesion)) -> dict:
    """Todos los `resultados_*.json` DE LA SESIÓN activa."""
    outs = _outputs(ctx)
    filas: list[dict] = []
    if outs.is_dir():
        for dia in sorted(outs.iterdir(), reverse=True):
            if not dia.is_dir() or not _FECHA_RE.match(dia.name):
                continue
            for p in sorted(dia.iterdir(), reverse=True):
                if (not p.is_file() or not p.name.startswith("resultados_")
                        or p.suffix != ".json"):
                    continue
                try:
                    d = json.loads(p.read_text(encoding="utf-8"))
                except Exception:  # noqa: BLE001
                    continue
                filas.append({
                    "fecha":        dia.name,
                    "fichero":      p.name,
                    "ruta":         f"{dia.name}/{p.name}",
                    "modelo":       d.get("modelo", "—"),
                    "tier":         d.get("tier", "—"),
                    "score_global": d.get("score_global"),
                    "semaforo":     d.get("semaforo") or {},
                })
    return {"informes": filas, "sesion": ctx["clave"]}


@router.get("/actual")
def resultado_de_la_ultima_corrida(ctx: dict = Depends(contexto_sesion)) -> dict:
    r = pipeline_runner.run_de_sesion(ctx["clave"])
    if r is None or not r.resultado_json:
        raise HTTPException(404, "no hay resultado disponible de una corrida")
    ruta = (ctx["base"] / r.resultado_json).resolve()
    try:
        ruta.relative_to(_outputs(ctx).resolve())
    except ValueError:
        raise HTTPException(400, "resultado fuera de outputs de la sesión")
    return {"ruta": r.resultado_json, "datos": _leer_json(ruta)}


@router.get("/{fecha}/{fichero}")
def resultado_por_ruta(fecha: str, fichero: str,
                        ctx: dict = Depends(contexto_sesion)) -> dict:
    ruta = _resolver(ctx, fecha, fichero)
    return {"ruta": f"{fecha}/{fichero}", "datos": _leer_json(ruta)}
