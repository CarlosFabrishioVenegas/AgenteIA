"""
Verificador end-to-end de conexiones del VIRF Agent Web (Mejora 5 · v2.2).

Uso CLI:
    python web/verificar_conexiones.py --validador T5443 --modelo VAR_BCP_2027

Uso HTTP (mismo motor):
    GET  /api/debug/conexiones
    Headers: X-Prompt-Password: virf2026
    Cookies: virf_token, virf_modelo (sesión activa)

Cada bloque verifica una conexión concreta del sistema; el reporte
final agrupa OK / FAIL / N/A. Un bloque FAIL nunca hace crashear al
verificador — sigue con el siguiente y anota el error.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Callable

# Permite ejecutarlo como script sin `-m`.
if __name__ == "__main__" and __package__ is None:
    ROOT = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / "motor"))

from web.config_web import PROYECTO_DIR  # noqa: E402
from web.services import (                # noqa: E402
    analisis_codigo, chat_service, cuestionamientos_sesion,
    dominios_custom_store, modelos_store, sesion_store, skills_store,
)


# ── Utilidad ─────────────────────────────────────────────────────────

class _Reporte:
    """Acumula OK/FAIL/N/A y agrupa por bloque para el print final."""

    def __init__(self) -> None:
        self.bloques: dict[str, list[tuple[str, str, str]]] = {}
        self.actual: str = "?"

    def bloque(self, nombre: str) -> None:
        self.actual = nombre
        self.bloques.setdefault(nombre, [])

    def check(self, nombre: str, fn: Callable[[], Any]) -> None:
        try:
            valor = fn()
            if valor is None:
                self.bloques[self.actual].append(("OK", nombre, ""))
            elif valor is False:
                self.bloques[self.actual].append(("FAIL", nombre, "check devolvió False"))
            elif isinstance(valor, str) and valor.startswith("N/A"):
                self.bloques[self.actual].append(("N/A", nombre, valor[3:].strip(": ")))
            else:
                self.bloques[self.actual].append(("OK", nombre, str(valor)))
        except Exception as exc:                     # noqa: BLE001
            self.bloques[self.actual].append(("FAIL", nombre, str(exc)))

    def resumen(self) -> dict:
        ok = fail = na = 0
        for res in self.bloques.values():
            for est, _, _ in res:
                if   est == "OK":   ok += 1
                elif est == "FAIL": fail += 1
                elif est == "N/A":  na += 1
        return {"ok": ok, "fail": fail, "na": na,
                "total": ok + fail + na}

    def a_dict(self) -> dict:
        return {
            "bloques":  {b: [{"estado": e, "nombre": n, "detalle": d}
                             for e, n, d in items]
                          for b, items in self.bloques.items()},
            "resumen":  self.resumen(),
        }

    def imprimir(self, validador: str, modelo: str) -> None:
        """
        Salida en ASCII para funcionar en consolas Windows (cp1252) sin
        UnicodeEncodeError. Se pierde el sabor visual, se gana portabilidad.
        """
        ico = {"OK": "[OK]  ", "FAIL": "[FAIL]", "N/A": "[N/A] "}
        sep = "=" * 68
        buf: list[str] = ["", sep,
                          f"  VERIFICACION DE CONEXIONES  -  {modelo} ({validador})",
                          sep]
        for b, items in self.bloques.items():
            buf.append("")
            buf.append(b)
            for est, nombre, det in items:
                sufijo = f"  --  {det}" if det else ""
                buf.append(f"  {ico[est]} {nombre}{sufijo}")
        r = self.resumen()
        buf += ["", sep,
                f"  RESULTADO: {r['ok']}/{r['total']} OK  ·  "
                f"{r['fail']} FAIL  ·  {r['na']} N/A",
                sep, ""]
        # `sys.stdout.write` con encoding relajado por si aún hubo emoji suelto.
        import sys as _sys
        _sys.stdout.buffer.write(("\n".join(buf) + "\n").encode(
            _sys.stdout.encoding or "utf-8", errors="replace"))


# ── Ejecución ────────────────────────────────────────────────────────

def _construir_ctx(validador: str, slug: str) -> dict:
    reg = sesion_store.leer_validadores()
    if validador not in reg:
        raise ValueError(f"validador {validador} no registrado")
    val = reg[validador]
    modelo = modelos_store.cargar(validador, slug)
    if modelo is None:
        raise ValueError(f"modelo {validador}/{slug} no existe")
    base = PROYECTO_DIR / "web" / "data" / "sesiones" / validador / slug
    return {
        "validador": val, "modelo": modelo,
        "base":      base,
        "inputs":    base / "inputs",
        "outputs":   base / "outputs",
        "clave":     f"{validador}/{slug}",
    }


def verificar(validador: str, slug: str) -> dict:
    r = _Reporte()
    ctx = _construir_ctx(validador, slug)

    # ── 1. Sesión y persistencia ─────────────────────────────────────
    r.bloque("1. SESIÓN Y PERSISTENCIA")
    r.check("Carpeta de sesión existe",
             lambda: str(ctx["base"].relative_to(PROYECTO_DIR)) if ctx["base"].is_dir() else False)
    r.check("sesion.json presente y válido",
             lambda: (ctx["base"] / "sesion.json").is_file() or False)
    r.check("chat_historial.json (si existe) se restaura",
             lambda: (
                 "N/A: sin chat aún"
                 if not (ctx["base"] / "chat_historial.json").is_file()
                 else (chat_service._cargar_de_disco(ctx) is not None or False)))

    # ── 2. Evidencia → pipeline ─────────────────────────────────────
    r.bloque("2. EVIDENCIA → PIPELINE")
    inp = ctx["inputs"]
    r.check("Carpeta inputs/ existe",       lambda: inp.is_dir() or False)
    r.check("Número de ficheros en inputs/",
             lambda: sum(1 for _ in inp.rglob("*") if _.is_file()) if inp.is_dir() else 0)
    r.check("ZIP de implementación descomprimido",
             lambda: (
                 "N/A: sin código subido"
                 if not (inp / "implementacion").is_dir() else
                 sum(1 for _ in (inp / "implementacion").rglob("*")
                     if _.suffix.lower() in (".py", ".ipynb", ".sql", ".r")) > 0
                 or False))
    r.check("Entendimiento del modelo generado",
             lambda: (
                 "N/A: aún no analizado"
                 if not analisis_codigo.ruta_md(ctx).is_file()
                 else str(analisis_codigo.ruta_md(ctx).name)))

    # ── 3. Dominio → RAG ─────────────────────────────────────────────
    r.bloque("3. DOMINIO → RAG")
    dominio = ctx["modelo"].get("dominio", "shared")
    r.check("Dominio del modelo existe (fijo o custom)",
             lambda: dominios_custom_store.existe(dominio) or False)
    idx_path = PROYECTO_DIR / "data" / "rag_lexico" / f"{dominio}.pkl"
    r.check("Índice RAG del dominio construido",
             lambda: (
                 "N/A: índice no construido (usa Reconstruir)"
                 if not idx_path.is_file() else str(idx_path.name)))

    def _query_rag():
        from src.rag import get_retriever
        retriever = get_retriever(tipo_modelo=dominio)
        chunks = retriever.query(f"metodología {ctx['modelo']['nombre']}", top_k=3) or []
        return len(chunks) if chunks else False
    r.check("Retriever devuelve chunks", _query_rag)

    def _inferir():
        from src.rag import inferir_dominio
        return inferir_dominio(ctx["modelo"]["nombre"])
    r.check("inferir_dominio() resuelve el título", _inferir)

    # ── 4. Skills → prompt ───────────────────────────────────────────
    r.bloque("4. SKILLS → PROMPT")
    snap_s = skills_store.get_skills(ctx)
    r.check("Skills default cargados", lambda: len(snap_s["defaults"]))
    r.check("Skills custom cargados",  lambda: len(snap_s["custom"]))
    r.check("Skills activos convierten a texto para el prompt",
             lambda: len(skills_store.get_active_skills_for_prompt(ctx)))

    # ── 5. Cuestionamientos → prompt ─────────────────────────────────
    r.bloque("5. CUESTIONAMIENTOS → PROMPT")
    snap_c = cuestionamientos_sesion.get_estado(ctx)
    r.check("Cuestionamientos default cargados (presencia + ausencia)",
             lambda: len(snap_c["presencia"]) + len(snap_c["ausencia"]))
    r.check("Custom NL cargados",  lambda: len(snap_c["custom"]))
    r.check("Cuestionamientos activos convierten a texto",
             lambda: len(cuestionamientos_sesion.get_for_prompt(ctx)))

    # ── 6. Validación → resultados ───────────────────────────────────
    r.bloque("6. VALIDACIÓN → RESULTADOS")
    outs = ctx["outputs"]
    jsons = list(outs.rglob("resultados_*.json")) if outs.is_dir() else []
    r.check("JSON de resultados presentes",
             lambda: (
                 "N/A: aún no se ha ejecutado --prdc"
                 if not jsons else len(jsons)))
    if jsons:
        try:
            d = json.loads(jsons[-1].read_text(encoding="utf-8"))
            r.check("scores_por_ambito presente", lambda: len(d.get("scores_por_ambito", {})))
            r.check("Score global calculado",     lambda: d.get("score_global") is not None or False)
        except Exception as exc:                    # noqa: BLE001
            r.check("Estructura del JSON", lambda: (_ for _ in ()).throw(exc))

    # ── 7. Controles de datos ────────────────────────────────────────
    r.bloque("7. CONTROLES DE DATOS")
    r.check("Catálogo de motores accesible",
             lambda: (__import__("modulos.motores_datos", fromlist=["REGISTRO_MOTORES"])
                      .REGISTRO_MOTORES and True))
    resultados_dir = inp / "calidad_datos" / "resultadocalidad_de_datos"
    r.check("Reportes externos (.txt/.md/.xlsx/.csv/.json) legibles",
             lambda: (
                 "N/A: sin resultados externos"
                 if not resultados_dir.is_dir() else
                 sum(1 for p in resultados_dir.iterdir()
                     if p.suffix.lower() in (".txt", ".md", ".xlsx", ".csv", ".json"))))

    # ── 8. Chat ──────────────────────────────────────────────────────
    r.bloque("8. CHAT")
    s_chat = chat_service.sesion_activa(ctx)
    r.check("Sesión de chat activa (memoria o disco)",
             lambda: ("N/A: sin chat iniciado" if s_chat is None
                      else f"{len(s_chat.mensajes)} mensajes"))
    if s_chat is not None:
        r.check("Observaciones con estado clasificadas",
                 lambda: f"{s_chat.resumen()['APROBADO'] + s_chat.resumen()['NEGADO'] + s_chat.resumen()['PENDIENTE']}"
                          f"/{len(s_chat.observaciones)}")

    # ── 9. Informe .docx ─────────────────────────────────────────────
    r.bloque("9. INFORME .docx")
    docs = list(outs.glob("VIRF_Informe_*.docx")) if outs.is_dir() else []
    r.check("Versiones generadas",
             lambda: "N/A: sin informe todavía" if not docs else len(docs))
    if docs:
        vs = sorted([int(p.name.split("_V")[1].split("_")[0]) for p in docs])
        r.check("Versionado consecutivo", lambda: max(vs))

    # ── 10. Flujo completo ───────────────────────────────────────────
    r.bloque("10. FLUJO COMPLETO")
    r.check("Cadena upload → prompt cabeada",
             lambda: (idx_path.is_file() and (inp / "implementacion").is_dir()) or
                     "N/A: bloques 2 o 3 aún sin cerrar")
    r.check("Dominio custom se comporta como fijo",
             lambda: (
                 "N/A: el modelo no usa dominio custom"
                 if dominio in dominios_custom_store.DOMINIOS_FIJOS
                 else "resuelve retriever custom"))
    # Contraseña — corre sólo si estamos con http server accesible.
    r.check("Contraseña del visor de prompt (constante interna)",
             lambda: __import__("web.routers.preview_prompt",
                                fromlist=["CONTRASENA"]).CONTRASENA == "virf2026")

    return r.a_dict() | {"_reporte": r, "_ctx": ctx}


def main() -> int:
    ap = argparse.ArgumentParser(description="Verificador end-to-end del VIRF Web.")
    ap.add_argument("--validador", required=True, help="Código del validador (ej: T5443)")
    ap.add_argument("--modelo",    required=True, help="Slug del modelo (ej: VAR_BCP_2027)")
    args = ap.parse_args()
    try:
        d = verificar(args.validador, args.modelo)
    except ValueError as exc:
        print(f"❌ {exc}", file=sys.stderr)
        return 1
    d["_reporte"].imprimir(args.validador, args.modelo)
    r = d["resumen"]
    return 0 if r["fail"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
