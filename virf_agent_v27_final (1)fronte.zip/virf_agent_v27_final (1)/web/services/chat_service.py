"""
Chat argumentativo por sesión — v2 · fase 7.

Cambios sobre v1:
- **Multi-sesión**: cada modelo tiene su propio chat, indexado por
  `clave = "codigo/slug"`. Dos validadores en dos modelos pueden
  chatear en paralelo sin colisiones.
- **Persistencia en disco**: `sesion.base / chat_historial.json`.
  Al abrir el chat, si hay historial se restaura; si no, se empieza
  desde cero con el JSON de resultados.
- **Prompt argumentativo**: el prompt del agente incluye ámbito,
  puntaje, observación, evidencia, fragmento de código y contexto
  RAG. Pide veredicto JSON estructurado.
- **Mock adaptado** al nuevo JSON de salida.

Sin API real, el mock produce texto rotativo y no argumenta con
citas. El diseño de datos es el correcto y el día que haya saldo la
salida del LLM tiene el mismo formato.
"""
from __future__ import annotations

import json
import os
import threading
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal, Optional


VEREDICTOS = ("APROBADO", "NEGADO", "PENDIENTE")
MAX_REPREGUNTAS = 3


# ── Modelos ───────────────────────────────────────────────────────────

@dataclass
class Observacion:
    id: str
    ambito: str
    actividad: str
    puntaje: Optional[float]
    observacion: str
    evidencia: str = ""
    fragmento_codigo: str = ""
    fragmento_ref: str = ""             # p.ej. "modelo_var.py:234"
    rag_contexto: str = ""
    preguntas: list[str] = field(default_factory=list)
    veredicto: str = "SIN_TRATAR"       # SIN_TRATAR | APROBADO | NEGADO | PENDIENTE
    intentos: int = 0
    hallazgo_final: str = ""            # texto de la conclusión


@dataclass
class Mensaje:
    quien: str                          # "agente" | "validador"
    texto: str
    ts_utc: str
    observacion_id: Optional[str] = None
    veredicto: Optional[str] = None     # solo si es cierre


@dataclass
class SesionChat:
    id: str
    clave: str                          # "codigo/slug"
    modelo: str
    tier: str
    dominio: Optional[str]
    ruta_json: str
    observaciones: list[Observacion]
    mensajes: list[Mensaje] = field(default_factory=list)
    indice_actual: int = 0
    creado_utc: str = ""
    finalizado: bool = False

    @property
    def actual(self) -> Optional[Observacion]:
        while self.indice_actual < len(self.observaciones):
            o = self.observaciones[self.indice_actual]
            if o.veredicto in ("APROBADO", "NEGADO", "PENDIENTE"):
                self.indice_actual += 1
                continue
            return o
        return None

    def resumen(self) -> dict[str, int]:
        r = {v: 0 for v in ("APROBADO", "NEGADO", "PENDIENTE", "SIN_TRATAR")}
        for o in self.observaciones:
            r[o.veredicto] = r.get(o.veredicto, 0) + 1
        r["total"] = len(self.observaciones)
        return r


# ── Registro multi-sesión ─────────────────────────────────────────────

_sesiones: dict[str, SesionChat] = {}
_lock = threading.Lock()


def _fichero(ctx: dict) -> Path:
    return ctx["base"] / "chat_historial.json"


def _ahora() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _guardar(ctx: dict, s: SesionChat) -> None:
    ctx["base"].mkdir(parents=True, exist_ok=True)
    data = {
        "id":            s.id,
        "clave":         s.clave,
        "modelo":        s.modelo,
        "tier":          s.tier,
        "dominio":       s.dominio,
        "ruta_json":     s.ruta_json,
        "observaciones": [asdict(o) for o in s.observaciones],
        "mensajes":      [asdict(m) for m in s.mensajes],
        "indice_actual": s.indice_actual,
        "creado_utc":    s.creado_utc,
        "finalizado":    s.finalizado,
    }
    _fichero(ctx).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def _cargar_de_disco(ctx: dict) -> Optional[SesionChat]:
    p = _fichero(ctx)
    if not p.is_file():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return SesionChat(
        id=d["id"], clave=d["clave"],
        modelo=d["modelo"], tier=d["tier"], dominio=d.get("dominio"),
        ruta_json=d["ruta_json"],
        observaciones=[Observacion(**o) for o in d["observaciones"]],
        mensajes=[Mensaje(**m) for m in d["mensajes"]],
        indice_actual=d.get("indice_actual", 0),
        creado_utc=d.get("creado_utc", ""),
        finalizado=d.get("finalizado", False),
    )


def sesion_activa(ctx: dict) -> Optional[SesionChat]:
    """Devuelve la sesión de chat de este `ctx` (memoria o disco)."""
    clave = ctx["clave"]
    if clave in _sesiones:
        return _sesiones[clave]
    s = _cargar_de_disco(ctx)
    if s is not None:
        _sesiones[clave] = s
    return s


# ── Extracción de observaciones enriquecidas ──────────────────────────

def _extraer_observaciones(datos: dict[str, Any]) -> list[Observacion]:
    """
    De los resultados de validación, saca las observaciones que
    requieren discusión:
      - `puntaje < 4` o
      - `preguntas_pendientes` no vacío o
      - `evaluacion_valida is False`.

    Cada una se enriquece con evidencia, fragmento de código y RAG.
    """
    obs: list[Observacion] = []
    for ambito, evaluaciones in (datos.get("resultados_por_ambito") or {}).items():
        for e in (evaluaciones or []):
            p       = e.get("puntaje")
            preg    = e.get("preguntas_pendientes") or []
            valida  = e.get("evaluacion_valida", True)
            if p is None:
                continue
            if valida and (not preg) and p >= 4:
                continue
            # Extraer fragmento de código si viene (los skills de análisis
            # de código lo dejan como `codigo_snippet` o dentro de `evidencia_encontrada`).
            fragmento = (e.get("codigo_snippet") or e.get("fragmento_codigo") or "").strip()
            frag_ref  = e.get("codigo_ref") or ""
            rag       = ""
            rc = e.get("rag_chunks") or []
            if isinstance(rc, list) and rc:
                # Toma los primeros ~400 chars como pista.
                rag = " · ".join(str(c)[:200] for c in rc[:2])
            obs.append(Observacion(
                id=uuid.uuid4().hex[:8],
                ambito=ambito,
                actividad=e.get("actividad") or "(actividad)",
                puntaje=p,
                observacion=e.get("observacion") or "",
                evidencia=(e.get("evidencia_encontrada") or "").strip()[:600],
                fragmento_codigo=fragmento[:800],
                fragmento_ref=str(frag_ref)[:120],
                rag_contexto=rag,
                preguntas=list(preg),
            ))
    return obs


# ── Prompt argumentativo (para cuando haya API) ───────────────────────

_PROMPT_JUEZ = """\
Eres un VALIDADOR SENIOR de modelos de riesgo financiero. Estás
revisando el modelo {modelo} (dominio {dominio}, Tier {tier}) con el
validador humano en una conversación de aclaración.

OBSERVACIÓN ACTUAL (#{numero} de {total}):
- Ámbito: {ambito}
- Actividad: {actividad}
- Puntaje: {puntaje}/5
- Lo que encontraste: {observacion}
- Evidencia documental: {evidencia}
- Referencia código: {ref}
- Fragmento de código relevante:
{codigo_bloque}
- Contexto RAG (literatura): {rag}

Historial reciente de ESTA observación:
{historial}

Instrucciones:
1. Si es tu primer mensaje sobre esta observación: describe con concreción
   qué encontraste, cita archivo:línea del código, cita paper si el RAG
   aportó algo, y termina con UNA pregunta clara al validador.
2. Si el validador ya respondió:
   - Si su respuesta CIERRA la observación: devuelve APROBADO o NEGADO
     con `hallazgo` de 1-3 frases y anuncia paso a la siguiente.
   - Si es AMBIGUA: repregunta (intento {intentos}/{maximo}).
   - Si es el 3er intento y sigue ambigua: devuelve PENDIENTE y marca
     como pendiente de aclaración manual.
3. Cita siempre archivo:línea, documento:sección o paper cuando exista.

Devuelve EXACTAMENTE este JSON (sin bloques de código):
{{"veredicto":"APROBADO|NEGADO|PENDIENTE|NINGUNO","respuesta":"<texto al
validador>","hallazgo":"<resumen del hallazgo si aprueba/niega/pendiente>"}}
"""


def _renderiza_prompt(s: SesionChat, o: Observacion, texto_val: str,
                       ctx: Optional[dict] = None) -> str:
    hist_msgs = [m for m in s.mensajes if m.observacion_id == o.id][-6:]
    hist = "\n".join(f"  [{m.quien}] {m.texto}" for m in hist_msgs) or "  (sin historial)"
    codigo_bloque = (
        f"```\n{o.fragmento_codigo}\n```" if o.fragmento_codigo
        else "  (no se aportó fragmento)"
    )
    idx = 0
    for i, ob in enumerate(s.observaciones, 1):
        if ob.id == o.id:
            idx = i
            break
    # v2.3 — usa el prompt editado por el validador si existe.
    template = _PROMPT_JUEZ
    if ctx is not None:
        try:
            from . import prompt_service
            template = prompt_service.get_prompt(ctx, "chat_agente")
        except (KeyError, OSError):
            pass
    return template.format(
        modelo=s.modelo, dominio=s.dominio or "?", tier=s.tier,
        numero=idx, total=len(s.observaciones),
        ambito=o.ambito, actividad=o.actividad, puntaje=o.puntaje,
        observacion=o.observacion or "(sin texto)",
        evidencia=o.evidencia or "(no citada)",
        ref=o.fragmento_ref or "(sin ref)",
        codigo_bloque=codigo_bloque,
        rag=o.rag_contexto or "(sin contexto RAG)",
        historial=hist,
        intentos=o.intentos, maximo=MAX_REPREGUNTAS,
    )


def _respuesta_mock(o: Observacion, intentos: int, texto_val: str) -> dict:
    """
    Mock rotativo para desarrollo sin API. Segundo intento cierra
    aprobando; el `hallazgo` se construye por plantilla para que el
    docx de la fase 8 tenga algo coherente que renderizar.
    """
    if intentos >= 2:
        return {
            "veredicto":   "APROBADO",
            "respuesta":   ("(mock) Con tu aclaración cierro esta observación como "
                             "aprobada. Registro el hallazgo y paso a la siguiente."),
            "hallazgo":    (f"[MOCK] Observación de {o.ambito} · {o.actividad}: "
                             f"aclarada por el validador tras {intentos} intentos."),
        }
    return {
        "veredicto":   "NINGUNO",
        "respuesta":   ("(mock) Necesito concretar más. ¿Puedes indicar con qué método/"
                         "versión se aplica, y dónde queda documentado?"),
        "hallazgo":    "",
    }


def _invocar_modelo(prompt: str) -> dict:
    if os.environ.get("VIRF_MOCK_CHAT") == "1":
        return {"__mock__": True}
    from Mx_03_LlamarIA import _llamar_modelo
    respuesta = _llamar_modelo(prompt=prompt, max_tokens=800, temperatura=0.0)
    return json.loads((respuesta or "").strip())


# ── API pública ───────────────────────────────────────────────────────

def iniciar(ctx: dict, datos: dict[str, Any], ruta_json: str) -> SesionChat:
    """
    Crea (o reinicia) la sesión de chat del `ctx` a partir del JSON
    de resultados dado. Si ya hay una guardada en disco, se sobrescribe.
    """
    clave = ctx["clave"]
    obs = _extraer_observaciones(datos)
    s = SesionChat(
        id=uuid.uuid4().hex[:12],
        clave=clave,
        modelo=datos.get("modelo", ctx["modelo"]["nombre"]),
        tier=str(datos.get("tier", ctx["modelo"]["tier"])),
        dominio=(datos.get("agente") or {}).get("dominio_rag") or ctx["modelo"].get("dominio"),
        ruta_json=ruta_json,
        observaciones=obs,
        creado_utc=_ahora(),
    )
    with _lock:
        _sesiones[clave] = s
    _agregar(ctx, s, "agente",
        f"He revisado el informe de **{s.modelo}** (Tier {s.tier}). "
        f"Encontré {len(obs)} observación(es) que requiere(n) aclaración antes "
        f"de sostener la evaluación.")
    _emitir_pregunta(ctx, s)
    return s


def _emitir_pregunta(ctx: dict, s: SesionChat) -> None:
    o = s.actual
    if o is None:
        s.finalizado = True
        _agregar(ctx, s, "agente",
            "No quedan observaciones pendientes de tratar. "
            "Puedes proceder al informe final.")
        return
    partes = [
        f"**{o.ambito} — {o.actividad}** (puntaje actual: {o.puntaje})",
        "",
    ]
    if o.observacion:
        partes.append(f"Mi observación: {o.observacion}")
    if o.evidencia:
        partes.append(f"Evidencia: {o.evidencia[:400]}")
    if o.fragmento_codigo:
        partes.append("")
        partes.append(f"Fragmento relevante ({o.fragmento_ref or 'código'}):")
        partes.append(f"```\n{o.fragmento_codigo[:600]}\n```")
    if o.preguntas:
        partes.append("")
        partes.append("Antes de sostener la evaluación necesito aclarar:")
        for q in o.preguntas:
            partes.append(f"  • {q}")
    else:
        partes.append("")
        partes.append("¿Puedes aportar contexto o evidencia adicional sobre esta actividad?")
    _agregar(ctx, s, "agente", "\n".join(partes), observacion_id=o.id)


def _agregar(ctx: dict, s: SesionChat, quien: str, texto: str,
             observacion_id: Optional[str] = None,
             veredicto: Optional[str] = None) -> Mensaje:
    m = Mensaje(
        quien=quien, texto=texto, ts_utc=_ahora(),
        observacion_id=observacion_id, veredicto=veredicto,
    )
    s.mensajes.append(m)
    _guardar(ctx, s)
    return m


def responder(ctx: dict, texto_validador: str) -> dict:
    """
    Procesa la respuesta del validador y avanza el chat.
    Devuelve `{resumen, avanza, veredicto}`.
    """
    s = sesion_activa(ctx)
    if s is None:
        raise RuntimeError("no hay sesión de chat activa")
    o = s.actual
    if o is None:
        raise RuntimeError("no hay observación activa que responder")

    _agregar(ctx, s, "validador", texto_validador, observacion_id=o.id)
    o.intentos += 1

    try:
        r = _invocar_modelo(_renderiza_prompt(s, o, texto_validador, ctx=ctx))
        if r.get("__mock__"):
            r = _respuesta_mock(o, o.intentos, texto_validador)
    except Exception as exc:                     # noqa: BLE001
        _agregar(ctx, s, "agente",
                 f"⚠️ No pude consultar al modelo: {exc}. La observación queda "
                 f"como PENDIENTE hasta reintentar.",
                 observacion_id=o.id, veredicto="PENDIENTE")
        return {"resumen": s.resumen(), "avanza": False, "veredicto": "PENDIENTE"}

    veredicto = str(r.get("veredicto") or "NINGUNO").upper()
    hallazgo  = str(r.get("hallazgo") or "").strip()

    # Tope de repreguntas: pasado el máximo se cierra como PENDIENTE.
    if veredicto not in VEREDICTOS and o.intentos >= MAX_REPREGUNTAS:
        veredicto = "PENDIENTE"
        r["respuesta"] = ((r.get("respuesta") or "") +
            f"\n\n(Marcada como PENDIENTE tras {o.intentos} intentos sin claridad.)")

    _agregar(ctx, s, "agente", r.get("respuesta", "(sin respuesta)"),
             observacion_id=o.id,
             veredicto=veredicto if veredicto in VEREDICTOS else None)

    if veredicto in VEREDICTOS:
        o.veredicto = veredicto
        o.hallazgo_final = hallazgo or o.hallazgo_final
        _emitir_pregunta(ctx, s)
        _guardar(ctx, s)
        return {"resumen": s.resumen(), "avanza": True, "veredicto": veredicto}
    _guardar(ctx, s)
    return {"resumen": s.resumen(), "avanza": False, "veredicto": None}


def a_dict(s: Optional[SesionChat]) -> Optional[dict]:
    if s is None:
        return None
    return {
        "id":       s.id,
        "clave":    s.clave,
        "modelo":   s.modelo, "tier": s.tier, "dominio": s.dominio,
        "ruta_json": s.ruta_json,
        "creado_utc": s.creado_utc,
        "finalizado": s.finalizado,
        "observaciones": [
            {**asdict(o), "es_actual": (s.actual is not None and s.actual.id == o.id)}
            for o in s.observaciones
        ],
        "mensajes": [asdict(m) for m in s.mensajes],
        "resumen":  s.resumen(),
    }


def clear_todo() -> None:
    """Solo para tests."""
    with _lock:
        _sesiones.clear()
