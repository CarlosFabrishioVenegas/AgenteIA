"""
Generador de informe consolidado por sesión (v2 · fase 8).

Sobre v1:
- **Versionado V1/V2/V3** por sesión (nombre canónico
  `VIRF_Informe_{slug}_V{n}_{DDMMYYYY}.docx`). El primero es V1; si ya
  existe se calcula el siguiente. NO cierra la sesión — puedes seguir
  editando y generar V2.
- **Diálogo del chat inline** por observación: los mensajes se
  agrupan por `observacion_id` y se insertan justo debajo del bloque
  de la actividad correspondiente.
- **Bloques de código** con fondo oscuro, monoespaciado y encabezado
  con archivo:línea si viene.
- **Portada** con validador (código + nombre + cargo) y contexto de
  la sesión (dominio, tier).

No sustituye a `modulos.generador_word` (entregable regulatorio del
pipeline); es un consolidado apto para revisión y compartir con el
comité.
"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt, RGBColor, Cm

from ..config_web import PROYECTO_DIR
from . import chat_service


# ── Ubicación de salida por sesión ────────────────────────────────────

def salida_dir_de(ctx: dict) -> Path:
    d = ctx["outputs"]
    d.mkdir(parents=True, exist_ok=True)
    return d


_NOMBRE_RE = re.compile(r"^VIRF_Informe_.+_V(\d+)_\d{8}\.docx$")


def _nombre_canonico(ctx: dict, cuando: datetime) -> tuple[str, int]:
    """
    Devuelve (nombre, version). La versión es 1 + max(V*) existente en
    la carpeta de salida de la sesión.
    """
    salida = salida_dir_de(ctx)
    slug = ctx["modelo"]["slug"]
    max_v = 0
    for p in salida.iterdir():
        if not p.is_file() or p.suffix != ".docx":
            continue
        m = _NOMBRE_RE.match(p.name)
        if m and p.name.startswith(f"VIRF_Informe_{slug}_V"):
            max_v = max(max_v, int(m.group(1)))
    v = max_v + 1
    fecha = cuando.strftime("%d%m%Y")
    return f"VIRF_Informe_{slug}_V{v}_{fecha}.docx", v


def listar_versiones(ctx: dict) -> list[dict]:
    """
    Enumera los informes generados en esta sesión, más nuevos primero.
    """
    salida = salida_dir_de(ctx)
    slug = ctx["modelo"]["slug"]
    filas = []
    for p in sorted(salida.iterdir(), reverse=True):
        if not p.is_file() or p.suffix != ".docx":
            continue
        if not p.name.startswith(f"VIRF_Informe_{slug}_V"):
            continue
        m = _NOMBRE_RE.match(p.name)
        if not m:
            continue
        filas.append({
            "nombre":     p.name,
            "version":    int(m.group(1)),
            "tam":        p.stat().st_size,
            "generado":   datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
        })
    filas.sort(key=lambda x: x["version"], reverse=True)
    return filas


# ── Utilidades de estilo docx ─────────────────────────────────────────

_AZUL = RGBColor(0x1F, 0x38, 0x64)
_GRIS = RGBColor(0x80, 0x80, 0x88)


def _sem_color(hex_str: Optional[str]) -> RGBColor:
    h = (hex_str or "CCCCCC").lstrip("#").upper()
    if len(h) != 6:
        h = "CCCCCC"
    return RGBColor(int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def _h1(doc: Document, texto: str) -> None:
    p = doc.add_paragraph()
    r = p.add_run(texto)
    r.font.size = Pt(16); r.font.bold = True
    r.font.color.rgb = _AZUL


def _h2(doc: Document, texto: str) -> None:
    p = doc.add_paragraph()
    r = p.add_run(texto)
    r.font.size = Pt(12); r.font.bold = True
    r.font.color.rgb = _AZUL


def _p(doc: Document, texto: str, size: int = 10, italic: bool = False) -> None:
    p = doc.add_paragraph()
    r = p.add_run(texto)
    r.font.size = Pt(size)
    r.font.italic = italic


def _sombra(cell, hex_rgb: str) -> None:
    """Fondo gris claro en una celda (para bloques de código)."""
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_rgb)
    tc_pr.append(shd)


def _bloque_codigo(doc: Document, codigo: str, archivo: str = "") -> None:
    """
    Bloque de código con fondo gris y fuente monoespaciada. Encabezado
    con archivo:línea si viene.
    """
    if archivo:
        p = doc.add_paragraph()
        r = p.add_run(f"📄 {archivo}")
        r.font.size = Pt(8); r.font.italic = True
        r.font.color.rgb = _GRIS
    tabla = doc.add_table(rows=1, cols=1)
    tabla.autofit = True
    celda = tabla.rows[0].cells[0]
    _sombra(celda, "F2F2F5")
    p = celda.paragraphs[0]
    r = p.add_run(codigo)
    r.font.name = "Consolas"
    r.font.size = Pt(9)


def _bloque_dialogo(doc: Document, mensajes: list) -> None:
    """
    Renderiza el diálogo del chat en el docx. Cada mensaje: agente
    (fondo azul muy suave) vs validador (fondo neutro).
    """
    if not mensajes:
        return
    _p(doc, "Diálogo con el validador:", size=10, italic=True)
    for m in mensajes:
        tabla = doc.add_table(rows=1, cols=1)
        celda = tabla.rows[0].cells[0]
        _sombra(celda, "E8F0FA" if m.quien == "agente" else "F5F5F8")
        p = celda.paragraphs[0]
        prefijo = "🤖" if m.quien == "agente" else "👤"
        cab = p.add_run(f"{prefijo} {m.ts_utc[:19]}"
                         + (f"  ·  {m.veredicto}" if m.veredicto else ""))
        cab.font.size = Pt(8); cab.font.italic = True
        cab.font.color.rgb = _GRIS
        p2 = celda.add_paragraph()
        # Renderiza fragmentos de código dentro del mensaje.
        for i, trozo in enumerate(str(m.texto or "").split("```")):
            r = p2.add_run(trozo)
            r.font.size = Pt(9)
            if i % 2 == 1:                       # dentro de ```…```
                r.font.name = "Consolas"


# ── Composición ───────────────────────────────────────────────────────

def _portada(doc: Document, ctx: dict, datos: dict, version: int) -> None:
    _h1(doc, "Informe de validación — VIRF Agent")
    val = ctx["validador"]; mod = ctx["modelo"]
    _p(doc, f"Modelo: {mod['nombre']} ({mod['slug']})", size=12)
    _p(doc, f"Dominio: {mod.get('dominio', '—')}   ·   Tier: {mod.get('tier', '—')}", size=11)
    _p(doc, f"Validador: {val['nombre']} ({val['codigo']})   ·   Cargo: {val.get('cargo', '—')}", size=11)
    _p(doc, f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
            f"   ·   Versión del informe: V{version}", size=10)
    _p(doc, f"JSON de resultados de origen: {datos.get('fecha', '—')}", size=9, italic=True)
    doc.add_paragraph()


def _resumen_ejecutivo(doc: Document, datos: dict) -> None:
    _h1(doc, "1. Resumen ejecutivo")
    sc = datos.get("score_global")
    sem = datos.get("semaforo") or {}
    _p(doc, f"Score global: {sc if sc is not None else '—'} / 5   ·   "
            f"{sem.get('label', 'SIN CLASIFICAR')}", size=12)
    _p(doc, "El score global es condición necesaria, no suficiente: un ámbito "
            "bloqueante (§4.2) o un hallazgo crítico automático (§6) impide "
            "aprobar aunque el promedio supere el umbral.", size=9, italic=True)
    _tabla_scores(doc, datos)
    _seccion_politica(doc, datos)


def _tabla_scores(doc: Document, datos: dict) -> None:
    scores = datos.get("scores_por_ambito") or {}
    if not scores:
        return
    _h2(doc, "Tabla resumen por ámbito")
    tabla = doc.add_table(rows=1, cols=3)
    tabla.style = "Light Grid Accent 1"
    for i, texto in enumerate(("Ámbito", "Score", "Dictamen")):
        tabla.rows[0].cells[i].text = texto
    for amb, s in sorted(scores.items(),
                          key=lambda kv: (kv[1] if isinstance(kv[1], (int, float)) else 99)):
        fila = tabla.add_row().cells
        fila[0].text = str(amb)
        fila[1].text = f"{s:.2f}" if isinstance(s, (int, float)) else "—"
        nivel = ("—" if not isinstance(s, (int, float))
                 else "🔴 BLOQUEANTE" if s < 2.5
                 else "🟡 OBSERVACIÓN" if s < 3.5
                 else "🟢 CUMPLE")
        fila[2].text = nivel


def _seccion_politica(doc: Document, datos: dict) -> None:
    pol = datos.get("politicas_procedimiento") or {}
    if not pol:
        return
    _h2(doc, "Políticas del procedimiento aplicadas")
    veto = pol.get("veto_por_ambito") or []
    crit = pol.get("criticos_automaticos") or []
    if not veto and not crit:
        _p(doc, "✅ Sin bloqueantes automáticos por §4.2 (< 2.5) ni críticos por §6 (≤ 2). "
                "La firma sigue siendo del validador (§1).", size=10)
        return
    if crit:
        _p(doc, f"§6 — Críticos automáticos (score ≤ 2): {', '.join(crit)}", size=10)
    if veto:
        _p(doc, f"§4.2 — Ámbitos por debajo del umbral (< 2.5): {', '.join(veto)}", size=10)


def _seccion_entendimiento(doc: Document, ctx: dict) -> None:
    """
    Mejora 4: si hay `entendimiento_modelo_*.md`, se incluye al inicio del
    informe con un render markdown básico (h1/h2/h3, listas, bloques).
    """
    from . import analisis_codigo as _acod
    md = _acod.leer_md(ctx)
    if not md:
        return
    _h1(doc, "Entendimiento del modelo")
    for linea in md.splitlines():
        s = linea.rstrip()
        if not s:
            doc.add_paragraph()
            continue
        if s.startswith("# "):
            _h1(doc, s[2:].strip())
        elif s.startswith("## "):
            _h2(doc, s[3:].strip())
        elif s.startswith("### "):
            _p(doc, s[4:].strip(), size=11)
        elif s.startswith("- ") or s.startswith("* "):
            _p(doc, f"  •  {s[2:].strip()}", size=10)
        elif s.startswith("|"):
            # Filas de tabla en modo prosa para no complicar el generador.
            _p(doc, s, size=9)
        else:
            _p(doc, s, size=10)
    # Correcciones del validador si existen.
    fbs = _acod.leer_feedbacks(ctx)
    if fbs:
        _h2(doc, "Correcciones del validador al entendimiento")
        for f in fbs:
            _p(doc, f"  · ({f.get('timestamp','')[:19]}) {f.get('comentario','')}", size=9)


def _seccion_actividades_con_dialogo(doc: Document, datos: dict, ctx: dict) -> None:
    """
    Detalle por ámbito. POR CADA actividad:
      - puntaje + concepto
      - observación / evidencia / recomendación
      - fragmento de código si viene
      - diálogo del chat correspondiente (por matching de ámbito+actividad)
      - conclusión con badge de color
    """
    rpa = datos.get("resultados_por_ambito") or {}
    if not rpa:
        return
    _h1(doc, "2. Detalle por ámbito")
    # Índice mensajes del chat por ámbito+actividad
    s = chat_service.sesion_activa(ctx)
    obs_por_clave: dict[tuple, dict] = {}
    if s is not None:
        for o in s.observaciones:
            clave = (o.ambito, o.actividad)
            obs_por_clave[clave] = o
        mensajes_por_obs: dict[str, list] = {}
        for m in s.mensajes:
            if m.observacion_id:
                mensajes_por_obs.setdefault(m.observacion_id, []).append(m)
    else:
        mensajes_por_obs = {}

    for ambito, evaluaciones in rpa.items():
        _h2(doc, ambito)
        for ev in (evaluaciones or []):
            actividad = ev.get("actividad") or "(actividad)"
            p = doc.add_paragraph()
            r = p.add_run(f"[{ev.get('puntaje', '—')}] {actividad}")
            r.font.size = Pt(11); r.font.bold = True
            if ev.get("concepto"):
                _p(doc, f"Concepto: {ev['concepto']}", size=9, italic=True)
            if ev.get("observacion"):
                _p(doc, f"Observación: {ev['observacion']}", size=9)
            if ev.get("evidencia_encontrada"):
                _p(doc, f"Evidencia: {ev['evidencia_encontrada'][:400]}", size=9)
            # Fragmento de código si el pipeline lo dejó.
            codigo = ev.get("codigo_snippet") or ev.get("fragmento_codigo") or ""
            if codigo:
                _bloque_codigo(doc, codigo[:1200],
                               ev.get("codigo_ref") or ev.get("archivo") or "")
            if ev.get("recomendacion"):
                _p(doc, f"Recomendación: {ev['recomendacion']}", size=9)
            pp = ev.get("preguntas_pendientes") or []
            if pp:
                _p(doc, f"Preguntas pendientes del agente: {' · '.join(pp)}", size=9, italic=True)
            # Diálogo del chat que aclara ESTA actividad.
            o = obs_por_clave.get((ambito, actividad))
            if o is not None:
                _bloque_dialogo(doc, mensajes_por_obs.get(o.id, []))
                if o.veredicto in ("APROBADO", "NEGADO", "PENDIENTE"):
                    icono = {"APROBADO": "✅", "NEGADO": "❌", "PENDIENTE": "⏳"}[o.veredicto]
                    _p(doc, f"{icono} Conclusión del chat: {o.veredicto}", size=10)
                    if o.hallazgo_final:
                        _p(doc, f"  Hallazgo: {o.hallazgo_final}", size=9, italic=True)
            doc.add_paragraph()


def _seccion_trazabilidad(doc: Document, datos: dict, ctx: dict, version: int) -> None:
    _h1(doc, "3. Anexo de trazabilidad")
    _p(doc, f"Versión de este informe: V{version}", size=10)
    agente = datos.get("agente") or {}
    for clave in ("version", "modelo_ia", "dominio_rag", "huella_ejecucion"):
        if agente.get(clave):
            _p(doc, f"  · {clave}: {agente[clave]}", size=9)
    huellas = ((datos.get("integridad") or {}).get("evidencia_huellas")
               or datos.get("documentos_huella") or {})
    if huellas:
        _h2(doc, "Huellas SHA-256 de la evidencia")
        for nombre, meta in list(huellas.items())[:40]:
            sha = (meta or {}).get("sha256") if isinstance(meta, dict) else str(meta)
            _p(doc, f"  · {nombre}: {sha}", size=8)
    _h2(doc, "Contexto de sesión")
    _p(doc, f"  · Validador: {ctx['validador']['codigo']} — {ctx['validador']['nombre']}", size=9)
    _p(doc, f"  · Modelo:    {ctx['modelo']['slug']} ({ctx['modelo']['nombre']})", size=9)
    _p(doc, f"  · Base:      {ctx['base']}", size=8)


# ── API pública ───────────────────────────────────────────────────────

def generar(datos: dict[str, Any], ruta_json_origen: str,
             ctx: dict) -> tuple[Path, int]:
    """
    Genera el .docx versionado. Devuelve `(ruta, version)`.
    """
    salida_dir = salida_dir_de(ctx)
    nombre, version = _nombre_canonico(ctx, datetime.now())

    doc = Document()
    for section in doc.sections:
        section.top_margin = Cm(2.5); section.bottom_margin = Cm(2.5)
        section.left_margin = Cm(2.5); section.right_margin = Cm(2.5)

    _portada(doc, ctx, datos, version)
    _resumen_ejecutivo(doc, datos)
    _seccion_entendimiento(doc, ctx)          # M4 · v2.2
    _seccion_actividades_con_dialogo(doc, datos, ctx)
    _seccion_trazabilidad(doc, datos, ctx, version)

    ruta = salida_dir / nombre
    doc.save(ruta)
    return ruta, version
