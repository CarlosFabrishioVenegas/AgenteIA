"""
Resolución del contexto de sesión (v2 · fase 2).

Todos los routers que trabajen "sobre el modelo activo" consumen este
helper via `Depends(...)`. Devuelve el bloque:

    {
      "validador":   {codigo, nombre, cargo, iniciado_utc},
      "modelo":      {slug, nombre, dominio, tier, ...},
      "base":        Path("web/data/sesiones/{codigo}/{slug}"),
      "inputs":      Path(".../inputs"),
      "outputs":     Path(".../outputs"),
      "clave":       "{codigo}/{slug}",
    }

Al no haber login → 401. Al no haber modelo activo → 400. La diferencia
importa: el frontend redirige al login en el primer caso y a "Mis
Modelos" en el segundo.

Ojo con el RAG y con el estándar: son GLOBALES al proyecto, no van a
la sesión. Los mantenemos donde el agente los busca (`inputs/rag/` y
`inputs/Estandares_VIRF.xlsx` a la raíz del proyecto).
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

from fastapi import Cookie, HTTPException

from ..config_web import PROYECTO_DIR, WEB_DIR
from . import modelos_store, sesion_store

SESIONES_DIR   = WEB_DIR / "data" / "sesiones"
RAG_GLOBAL     = PROYECTO_DIR / "inputs" / "rag"                     # compartido
ESTANDAR_PATH  = PROYECTO_DIR / "inputs" / "Estandares_VIRF.xlsx"    # compartido


def contexto_sesion(
    virf_token:  Optional[str] = Cookie(default=None),
    virf_modelo: Optional[str] = Cookie(default=None),
) -> dict:
    val = sesion_store.sesion_activa(virf_token)
    if val is None:
        raise HTTPException(401, "sesión de login expirada; vuelve a entrar")
    if not virf_modelo:
        raise HTTPException(
            400,
            "no hay modelo activo; entra en un modelo desde 'Mis Modelos'.")
    m = modelos_store.cargar(val["codigo"], virf_modelo)
    if m is None:
        raise HTTPException(400, f"modelo {virf_modelo!r} no existe")
    base    = SESIONES_DIR / val["codigo"] / m["slug"]
    return {
        "validador": val,
        "modelo":    m,
        "base":      base,
        "inputs":    base / "inputs",
        "outputs":   base / "outputs",
        "clave":     f"{val['codigo']}/{m['slug']}",
    }


# ── Mapeo de slugs de destino de upload a subcarpetas de la sesión ────
# Nota: `rag_*` y la raíz global se mantienen FUERA de la sesión (son
# compartidos entre validadores). Ver docstring de módulo.

# Catálogo de destinos de upload. Cada entrada incluye:
#   ruta_rel: str  → subcarpeta bajo inputs de la sesión
#   label:    str  → título corto para la card
#   desc:     str  → descripción guiada (párrafo largo)
#   formatos: list → extensiones aceptadas, para el <input accept>
#   solo_zip: bool → True obliga a subir un .zip (implementacion/)
#   orden:    int  → orden de presentación en la UI
_DESTINOS_SESION: dict[str, dict] = {
    "doc_modelamiento": {
        "ruta_rel": "documentacion/modelamiento",
        "label":    "documentacion/modelamiento/",
        "desc":     ("Manuales metodológicos del modelo: DDM (Documento de Diseño), "
                     "DTV (Documento Técnico de Validación), manual de supuestos, "
                     "marco teórico, descripción de fórmulas. El agente contrasta "
                     "estos documentos contra la implementación del código."),
        "formatos": [".pdf", ".docx", ".md", ".txt"],
        "solo_zip": False,
        "orden":    1,
    },
    "doc_seguimiento": {
        "ruta_rel": "documentacion/seguimiento",
        "label":    "documentacion/seguimiento/",
        "desc":     ("Informes de seguimiento: backtesting, monitoreo periódico, "
                     "resultados de tests estadísticos, umbrales de escalamiento."),
        "formatos": [".pdf", ".docx", ".xlsx", ".md", ".txt"],
        "solo_zip": False,
        "orden":    2,
    },
    "calidad_datos_datasets": {
        "ruta_rel": "calidad_datos/datasets",
        "label":    "calidad_datos/datasets/",
        "desc":     ("Datasets reales a validar (los datos del modelo). El agente "
                     "ejecuta 8 pruebas automáticas sobre ellos: unicidad, "
                     "duplicados, missing, outliers, rango, integridad referencial, "
                     "tipo de dato, completitud."),
        "formatos": [".csv", ".parquet", ".xlsx"],
        "solo_zip": False,
        "orden":    3,
    },
    "calidad_datos_resultados": {
        "ruta_rel": "calidad_datos/resultadocalidad_de_datos",
        "label":    "calidad_datos/resultadocalidad_de_datos/",
        "desc":     ("Resultados de motores de validación de datos EJECUTADOS POR LA "
                     "ENTIDAD (fuera de VIRF). El agente los lee y los combina con "
                     "sus propias pruebas.\n\n"
                     "Acepta:\n"
                     "• Tablas: Excel/CSV/JSON con columnas descripción, resultado y "
                     "opcional %incumplimiento/umbral.\n"
                     "• Texto: .txt o .md con el output del motor. El agente lo lee "
                     "completo y extrae los hallazgos.\n\n"
                     "Los .py se ignoran a propósito."),
        "formatos": [".xlsx", ".csv", ".json", ".txt", ".md"],
        "solo_zip": False,
        "orden":    4,
    },
    "implementacion": {
        "ruta_rel": "implementacion",
        "label":    "implementacion/ ⚠️ requiere ZIP",
        "desc":     ("Código del modelo, empaquetado en .zip: funciones, pipelines, "
                     "scripts, notebooks, arquitectura. El ZIP conserva la estructura "
                     "de carpetas. El agente revisa cada archivo contra el manual "
                     "metodológico y cita fragmento exacto (archivo:línea) en las "
                     "discrepancias."),
        "formatos": [".zip"],
        "solo_zip": True,
        "orden":    5,
    },
    "usos": {
        "ruta_rel": "usos",
        "label":    "usos/",
        "desc":     ("Evidencia de USO del modelo: actas de comité, aprobaciones "
                     "formales, reportes de uso en producción, evidencia de que se "
                     "usa para lo que fue diseñado."),
        "formatos": [".pdf", ".docx", ".md", ".txt"],
        "solo_zip": False,
        "orden":    6,
    },
    "excel_procesos": {
        "ruta_rel": "excel_procesos",
        "label":    "excel_procesos/ (opcional)",
        "desc":     ("Excel operativos del proceso del modelo — hojas con lógica "
                     "de cálculo, matrices de datos, workflows. Opcional."),
        "formatos": [".xlsx", ".xls", ".xlsm"],
        "solo_zip": False,
        "orden":    7,
    },
    "logoempresa": {
        "ruta_rel": "logoempresa",
        "label":    "logoempresa/ (opcional)",
        "desc":     ("Logotipo de la entidad para la portada del informe .docx. "
                     "El primer fichero de imagen se usa; si no hay, la portada "
                     "sale sin logo."),
        "formatos": [".png", ".jpg", ".jpeg", ".svg"],
        "solo_zip": False,
        "orden":    8,
    },
    "papers": {
        "ruta_rel": "papers",
        "label":    "papers/ (literatura propia del modelo, opcional)",
        "desc":     ("Papers específicos de este modelo (distintos del RAG global). "
                     "Para papers académicos que van al RAG y contrastan la "
                     "metodología, usa la pestaña Dominio & RAG."),
        "formatos": [".pdf", ".md", ".txt"],
        "solo_zip": False,
        "orden":    9,
    },
}

# Destinos que viven en el proyecto compartido, no en la sesión.
_DESTINOS_GLOBALES: dict[str, dict] = {
    "rag_LaR": {
        "ruta": RAG_GLOBAL / "LaR",
        "label": "RAG · dominio LaR (compartido)",
        "desc": "Papers y literatura de LaR (liquidez). Compartido entre validadores.",
        "formatos": [".pdf", ".md", ".txt"], "solo_zip": False,
    },
    "rag_VaR": {
        "ruta": RAG_GLOBAL / "VaR",
        "label": "RAG · dominio VaR (compartido)",
        "desc": "Papers y literatura de VaR (riesgo de mercado). Compartido.",
        "formatos": [".pdf", ".md", ".txt"], "solo_zip": False,
    },
    "rag_conductuales": {
        "ruta": RAG_GLOBAL / "conductuales",
        "label": "RAG · dominio conductuales (compartido)",
        "desc": "Papers y literatura conductual (prepago, NMD, retiro anticipado).",
        "formatos": [".pdf", ".md", ".txt"], "solo_zip": False,
    },
    "rag_shared": {
        "ruta": RAG_GLOBAL / "shared",
        "label": "RAG · shared (compartido, transversal)",
        "desc": "Literatura transversal (SR 11-7, gobernanza, principios generales).",
        "formatos": [".pdf", ".md", ".txt"], "solo_zip": False,
    },
}


def destinos_disponibles() -> list[dict]:
    """
    Lista los slugs con metadatos ricos para que el frontend pinte las
    cards del upload guiado (v2 · fase 3).
    """
    out: list[dict] = []
    for slug, meta in sorted(_DESTINOS_SESION.items(),
                              key=lambda kv: kv[1].get("orden", 99)):
        out.append({
            "slug":     slug,
            "label":    meta["label"],
            "desc":     meta["desc"],
            "formatos": meta["formatos"],
            "solo_zip": meta["solo_zip"],
            "alcance":  "sesion",
        })
    for slug, meta in _DESTINOS_GLOBALES.items():
        out.append({
            "slug":     slug,
            "label":    meta["label"],
            "desc":     meta["desc"],
            "formatos": meta["formatos"],
            "solo_zip": meta.get("solo_zip", False),
            "alcance":  "global",
        })
    return out


def resolver_destino(slug: str, ctx: dict) -> Path:
    """
    Traduce un slug de destino a la carpeta física. Los slugs `rag_*`
    apuntan al RAG global; el resto se resuelve dentro de la sesión.
    """
    if slug in _DESTINOS_GLOBALES:
        return _DESTINOS_GLOBALES[slug]["ruta"]
    if slug in _DESTINOS_SESION:
        return ctx["inputs"] / _DESTINOS_SESION[slug]["ruta_rel"]
    raise HTTPException(400, f"destino desconocido: {slug!r}")


def inicializar_carpetas_sesion(ctx: dict) -> None:
    """
    Materializa las subcarpetas de destino en la primera petición.
    Sin esto, el árbol se ve incompleto hasta el primer upload por cada
    slug — mala UX y una fuente clara de confusión.
    """
    ctx["inputs"].mkdir(parents=True, exist_ok=True)
    ctx["outputs"].mkdir(parents=True, exist_ok=True)
    for slug, meta in _DESTINOS_SESION.items():
        (ctx["inputs"] / meta["ruta_rel"]).mkdir(parents=True, exist_ok=True)


def es_solo_zip(slug: str) -> bool:
    """Slugs que rechazan ficheros sueltos (implementacion/)."""
    meta = _DESTINOS_SESION.get(slug) or _DESTINOS_GLOBALES.get(slug)
    return bool(meta and meta.get("solo_zip"))


def listar_carpeta_sesion(slug: str, ctx: dict) -> list[dict]:
    """
    Ficheros en la carpeta `slug` de la sesión (o global si es rag_*).
    Cada entrada: {nombre, tam, estado, ruta_relativa_a_inputs_o_rag}.
    """
    raiz = resolver_destino(slug, ctx)
    if not raiz.is_dir():
        return []
    salida: list[dict] = []
    for p in sorted(raiz.rglob("*")):
        if p.is_file() and not p.name.startswith("."):
            salida.append({
                "nombre": p.name,
                "tam":    p.stat().st_size,
                "ruta":   p.relative_to(raiz).as_posix(),
            })
    return salida
