"""
Estado runtime del backend web — no persistente, no compartido entre
procesos, no thread-safe estricto (uvicorn --reload es un proceso).

Es a propósito: la sesión es UN operador en UNA máquina. Los datos que
sí tienen que sobrevivir a un reinicio (configuración del proveedor,
árbol de evidencia) viven en el `.env` o en el sistema de ficheros
del propio agente, no aquí.
"""
from __future__ import annotations

from typing import Optional

_ESTADO: dict[str, Optional[str]] = {
    "modelo":  None,
    "tier":    None,     # "I" | "II" | "III" | "IV"
    "dominio": None,     # "LaR" | "VaR" | "conductuales"
}


def snapshot() -> dict[str, Optional[str]]:
    """Copia superficial del estado — el llamante no debe mutarlo."""
    return dict(_ESTADO)


def set_modelo(titulo: str, tier: str) -> None:
    _ESTADO["modelo"] = titulo
    _ESTADO["tier"] = tier


def set_dominio(dominio: str) -> None:
    _ESTADO["dominio"] = dominio


def clear() -> None:
    """Solo pensado para tests."""
    for k in _ESTADO:
        _ESTADO[k] = None
