# Entendimiento del modelo VAR_BCP_2027

> _MOCK generado sin API activa (`VIRF_MOCK_CHAT=1`). El texto es una plantilla estructurada sobre la información AST real; el contenido narrativo llegará cuando haya saldo del proveedor._

## 1. Visión general

Modelo del dominio **VaR** con 4 ficheros de código, 4 funciones y 1 clases. La narrativa específica del propósito requiere el proveedor IA.

## 2. Arquitectura del código

```
mod/backtester.py → mod/main.py → mod/utils.py → mod/var_engine.py
```

## 3. Flujo de datos

_Pendiente de análisis por IA._

## 4. Módulos principales

### `mod/backtester.py`
- Líneas: 3
- Funciones: `backtesting`
- Imports: mod

### `mod/main.py`
- Líneas: 1
- Imports: utils

### `mod/utils.py`
- Líneas: 1
- Funciones: `x`

### `mod/var_engine.py`
- Líneas: 6
- Funciones: `ewma`, `compute`
- Clases: `VarEngine`
- Imports: numpy

## 5. Modelo matemático/estadístico

_Requiere análisis por IA._

## 6. Puntos de atención para la validación

- Revisar supuestos implícitos en los `def`s detectados.
- Verificar valores hardcodeados en los módulos.
- Cobertura de tests si existe.

## 7. Resumen de archivos

| Archivo | Líneas | Propósito |
|---|---|---|
| `mod/backtester.py` | 3 | _(pendiente)_ |
| `mod/main.py` | 1 | _(pendiente)_ |
| `mod/utils.py` | 1 | _(pendiente)_ |
| `mod/var_engine.py` | 6 | _(pendiente)_ |