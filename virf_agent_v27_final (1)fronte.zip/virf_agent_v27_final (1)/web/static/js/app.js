// VIRF Web — orquestador del frontend. v2 (login + multi-sesión).
//
// Un solo módulo por ahora; si supera las ~1800 líneas se separará en
// chat.js, dashboard.js, auth.js. Hoy queda en uno para que cualquier
// cambio del flujo se lea entero de una sentada.

// ── Utilidad HTML-safe (definida temprano: la usan casi todas las
//    funciones de renderizado por template literal) ───────────────────
function escapeHtml(s) {
    return String(s ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}

const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

// ── Estado mínimo en memoria del cliente ─────────────────────────────
const estado = {
    dominio:   null,
    modelo:    null,
    validador: null,   // {codigo, nombre, cargo}
};

// ── Cambio de PANTALLA (login / modelos / dashboard) ─────────────────
function mostrarPantalla(id) {
    for (const p of $$(".pantalla, .app")) {
        p.hidden = p.id !== id;
    }
}

// ── Vistas del área principal ────────────────────────────────────────
function mostrarVista(id) {
    for (const vista of $$(".content > .empty-state, .content > .panel")) {
        vista.hidden = vista.id !== id;
    }
}

// ── Utilidades ───────────────────────────────────────────────────────
function iconoEstado(estado) {
    return { ok: "✅", warn: "⚠️", error: "❌" }[estado] || "•";
}

function tamanoLegible(bytes) {
    if (bytes == null) return "";
    const u = ["B", "KB", "MB", "GB"];
    let i = 0, n = bytes;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(i === 0 ? 0 : 1)} ${u[i]}`;
}

async function pedirJSON(url, opciones = {}) {
    const r = await fetch(url, opciones);
    let data;
    try { data = await r.json(); } catch { data = null; }
    if (!r.ok) {
        const msg = (data && data.detail) || `${r.status} ${r.statusText}`;
        throw new Error(msg);
    }
    return data;
}

// ── Registro visible de subidas (compartido por cards del upload) ─────
function logSubida(texto, clase = "log-ok") {
    const li = document.createElement("li");
    li.className = clase;
    li.innerHTML = `<span>${escapeHtml(texto)}</span>` +
                   `<span class="tam">${new Date().toLocaleTimeString()}</span>`;
    $("#upload-log").prepend(li);
}

// ── Visor del prompt del agente (M2 · v2.2) ──────────────────────────

function abrirModalPasswd() {
    $("#pv-error").hidden = true;
    $("#pv-passwd").value = "";
    $("#modal-preview-passwd").hidden = false;
    setTimeout(() => $("#pv-passwd").focus(), 40);
}

function cerrarModalesPreview() {
    $("#modal-preview-passwd").hidden = true;
    $("#modal-preview-visor").hidden = true;
}

async function submitPasswdPreview(ev) {
    ev.preventDefault();
    const pw = $("#pv-passwd").value;
    const err = $("#pv-error");
    err.hidden = true;
    try {
        const [rPreview, rPrompts, rPres] = await Promise.all([
            fetch("/api/validacion/preview-prompt", {
                method: "POST", headers: { "X-Prompt-Password": pw },
            }),
            fetch("/api/prompts"),
            fetch("/api/prompts/presupuesto"),
        ]);
        if (rPreview.status === 403) {
            err.hidden = false; err.textContent = "Contraseña incorrecta.";
            return;
        }
        if (!rPreview.ok) {
            err.hidden = false; err.textContent = `Error ${rPreview.status}: ${rPreview.statusText}`;
            return;
        }
        const data = await rPreview.json();
        PV_PASSWORD = pw;
        PV_PROMPTS  = rPrompts.ok ? (await rPrompts.json()).prompts : null;
        data.presupuesto = rPres.ok ? await rPres.json() : null;
        $("#modal-preview-passwd").hidden = true;
        pintarVisorPrompt(data);
        pintarEditorPrompts();
    } catch (e) {
        err.hidden = false; err.textContent = e.message;
    }
}

function pintarEditorPrompts() {
    if (!PV_PROMPTS) return;
    const ids = Object.keys(PV_PROMPTS);
    if (!ids.includes(PV_TAB)) PV_TAB = ids[0];
    const tabsEl = $("#pv-editor-tabs");
    const bodyEl = $("#pv-editor-body");
    tabsEl.innerHTML = ids.map(id => {
        const p = PV_PROMPTS[id];
        const marca = p.es_custom ? " •" : "";
        const activo = id === PV_TAB ? " tab-inline--activo" : "";
        return `<button type="button" class="tab-inline${activo}" data-pv-tab="${id}">${escapeHtml(p.titulo || id)}${marca}</button>`;
    }).join("");
    for (const btn of tabsEl.querySelectorAll("[data-pv-tab]")) {
        btn.addEventListener("click", () => {
            PV_TAB = btn.getAttribute("data-pv-tab");
            pintarEditorPrompts();
        });
    }
    const p = PV_PROMPTS[PV_TAB];
    const editable = !!p.editable;
    const marcaCustom = p.es_custom
        ? `<div class="tam" style="color:var(--sello); margin:4px 0;">Editado por ${escapeHtml(p.editado_por || "")} · ${(p.fecha_edicion || "").slice(0,16)} (original: ${p.chars_original?.toLocaleString?.() || "?"} chars → actual: ${p.chars_actual?.toLocaleString?.() || "?"} chars)</div>`
        : `<div class="tam" style="margin:4px 0;">Usa el default del sistema.</div>`;
    const placeholders = (p.placeholders || []).length
        ? `<div class="tam" style="margin:4px 0;">Placeholders obligatorios: ${p.placeholders.map(x => `<code>{${escapeHtml(x)}}</code>`).join(" ")}</div>`
        : "";
    bodyEl.innerHTML = `
        <p class="tab-descripcion">${escapeHtml(p.descripcion || "")}</p>
        ${placeholders}
        ${marcaCustom}
        <textarea id="pv-edit-textarea" rows="18" class="field__control" ${editable ? "" : "readonly"} style="font-family:var(--mono); font-size:11.5px; width:100%;">${escapeHtml(p.contenido || "")}</textarea>
        <div style="display:flex; gap:8px; margin-top:8px; align-items:center;">
            ${editable ? `
                <button type="button" class="btn" id="pv-btn-guardar">💾 Guardar</button>
                <button type="button" class="btn btn--ghost" id="pv-btn-restaurar" ${p.es_custom ? "" : "disabled"}>↩ Restaurar default</button>
            ` : `<span class="tam">Solo lectura — este prompt se arma dinámicamente.</span>`}
            <span class="footer__spacer"></span>
            <span id="pv-editor-msg" class="tam"></span>
        </div>
    `;
    if (editable) {
        $("#pv-btn-guardar").addEventListener("click", async () => {
            const contenido = $("#pv-edit-textarea").value;
            const msg = $("#pv-editor-msg");
            msg.textContent = "Guardando…";
            try {
                const r = await fetch("/api/prompts/editar", {
                    method:  "POST",
                    headers: { "Content-Type": "application/json", "X-Prompt-Password": PV_PASSWORD },
                    body:    JSON.stringify({ prompt_id: PV_TAB, contenido }),
                });
                if (!r.ok) { msg.textContent = "❌ " + (await r.json()).detail; return; }
                msg.textContent = "✅ Guardado";
                const efec = await fetch("/api/prompts");
                if (efec.ok) { PV_PROMPTS = (await efec.json()).prompts; pintarEditorPrompts(); }
            } catch (e) { msg.textContent = "❌ " + e.message; }
        });
        if (p.es_custom) {
            $("#pv-btn-restaurar").addEventListener("click", async () => {
                const msg = $("#pv-editor-msg");
                if (!confirm("¿Restaurar el default y perder tu edición?")) return;
                msg.textContent = "Restaurando…";
                try {
                    const r = await fetch("/api/prompts/restaurar", {
                        method:  "POST",
                        headers: { "Content-Type": "application/json", "X-Prompt-Password": PV_PASSWORD },
                        body:    JSON.stringify({ prompt_id: PV_TAB }),
                    });
                    if (!r.ok) { msg.textContent = "❌ " + (await r.json()).detail; return; }
                    msg.textContent = "✅ Restaurado";
                    const efec = await fetch("/api/prompts");
                    if (efec.ok) { PV_PROMPTS = (await efec.json()).prompts; pintarEditorPrompts(); }
                } catch (e) { msg.textContent = "❌ " + e.message; }
            });
        }
    }
}

let PV_PASSWORD = "";        // se conserva mientras el modal está abierto
let PV_PROMPTS  = null;      // efectivos de la sesión (base + custom)
let PV_TAB      = "rol_agente";

function pintarVisorPrompt(d) {
    const vis = $("#pv-visor");
    const skills = (d.skills_inyectados || []).map(s => `  - ${escapeHtml(s)}`).join("\n") || "  (ninguno)";
    const cuest  = (d.cuestionamientos_inyectados || []).map(s => `  - ${escapeHtml(s)}`).join("\n") || "  (ninguno)";
    const rag    = (d.rag_chunks_ejemplo || []).map((c, i) =>
        `Chunk ${i + 1} · score=${c.score ?? "—"} · ${escapeHtml(String(c.fuente || "—"))}\n${escapeHtml(String(c.texto || "").replace(/\s+/g, " "))}`
    ).join("\n\n") || "(no hay chunks)";
    const params = Object.entries(d.parametros || {}).map(([k, v]) => `  ${k}: ${v}`).join("\n");
    const pres = d.presupuesto || {};
    const bloquePresupuesto = pres.ventana_tokens
      ? `<section class="config-section">
           <h3 class="config-section__title">Presupuesto de contexto · modelo detectado</h3>
           <pre class="chat-msg__codigo">  Modelo:                   ${escapeHtml(String(pres.modelo || "—"))}
  Ventana:                  ${pres.ventana_tokens.toLocaleString()} tokens (~${pres.ventana_chars.toLocaleString()} chars)
  Presupuesto evidencia:    ${pres.presupuesto_evidencia_chars.toLocaleString()} chars
  Equivale a:               ~${pres.paginas_equivalentes} páginas
  Chunk_size · max_chunks:  ${pres.chunk_size.toLocaleString()} · ${pres.max_chunks}
  ${pres.cabe_todo_en_una_llamada ? "✅ Ventana suficiente: la evidencia se lee íntegra." : "⚠️ Ventana pequeña: los documentos largos se resumen."}</pre>
         </section>`
      : "";

    vis.innerHTML = `
      ${bloquePresupuesto}

      <section class="config-section" id="pv-editor-section">
        <h3 class="config-section__title">Editor de prompts</h3>
        <div id="pv-editor-tabs" class="tabs-inline"></div>
        <div id="pv-editor-body"></div>
      </section>

      <section class="config-section">
        <h3 class="config-section__title">Prompt de evaluación (muestra armada con placeholders resueltos)</h3>
        <p class="tab-descripcion">Este es el prompt exacto que se enviaría al LLM al evaluar UNA actividad — con las skills, cuestionamientos, entendimiento y RAG activos de tu sesión.</p>
        <textarea readonly rows="20" class="field__control" style="font-family:var(--mono); font-size:11.5px; width:100%;">${escapeHtml(d.prompt_evaluacion || "")}</textarea>
        <div class="tam" style="margin-top:4px;">${(d.prompt_evaluacion || "").length.toLocaleString()} chars</div>
      </section>

      <section class="config-section">
        <h3 class="config-section__title">Skills inyectados (${(d.skills_inyectados || []).length})</h3>
        <pre class="chat-msg__codigo">${skills}</pre>
      </section>

      <section class="config-section">
        <h3 class="config-section__title">Cuestionamientos inyectados (${(d.cuestionamientos_inyectados || []).length})</h3>
        <pre class="chat-msg__codigo">${cuest}</pre>
      </section>

      <section class="config-section">
        <h3 class="config-section__title">Entendimiento del modelo</h3>
        <p class="tab-descripcion">
          ${d.entendimiento_incluido
              ? `Incluido en el prompt (${d.entendimiento_chars.toLocaleString()} chars).`
              : "No incluido — aún no se ha analizado el ZIP."}
        </p>
      </section>

      <section class="config-section">
        <h3 class="config-section__title">Muestra RAG · dominio ${escapeHtml(d.rag_dominio || "—")}</h3>
        <pre class="chat-msg__codigo">${rag}</pre>
      </section>

      <section class="config-section">
        <h3 class="config-section__title">Parámetros del sistema</h3>
        <pre class="chat-msg__codigo">${escapeHtml(params)}\n  max_tokens (llamada): ${d.max_tokens ?? "—"}</pre>
      </section>`;
    $("#modal-preview-visor").hidden = false;
}

function cablearVisorPrompt() {
    const btn = $("#btn-preview-prompt");
    if (btn) btn.addEventListener("click", abrirModalPasswd);
    $("#form-pv-passwd").addEventListener("submit", submitPasswdPreview);
    for (const el of $$("[data-close-pv]"))  el.addEventListener("click", () => $("#modal-preview-passwd").hidden = true);
    for (const el of $$("[data-close-pv2]")) el.addEventListener("click", () => $("#modal-preview-visor").hidden = true);
}

// ── Entendimiento del modelo (M4 · v2.2) ─────────────────────────────

/**
 * Render Markdown minimalista: h1-h3, párrafos, listas, ```code```,
 * `inline`, **bold**, tablas simples y > blockquote. Nada de HTML raw
 * ni scripts — todo escapado antes de aplicar los patrones.
 */
function renderMdBasico(md) {
    let html = escapeHtml(md || "");
    // Bloques de código
    html = html.replace(/```([^`]*?)```/g, (_, cod) => `<pre>${cod}</pre>`);
    // Tablas simples (| col | col |)
    html = html.replace(/(^\|[^\n]+\|\n\|[-\s|:]+\|\n(?:\|[^\n]+\|\n)+)/gm, (bloque) => {
        const rows = bloque.trim().split("\n");
        const head = rows[0].split("|").slice(1, -1).map(c => c.trim());
        const body = rows.slice(2).map(r => r.split("|").slice(1, -1).map(c => c.trim()));
        return `<table><thead><tr>${head.map(h => `<th>${h}</th>`).join("")}</tr></thead>` +
               `<tbody>${body.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    });
    // Encabezados
    html = html.replace(/^### (.*)$/gm, "<h3>$1</h3>");
    html = html.replace(/^## (.*)$/gm, "<h2>$1</h2>");
    html = html.replace(/^# (.*)$/gm, "<h1>$1</h1>");
    // Blockquotes
    html = html.replace(/^&gt; (.*)$/gm, "<blockquote>$1</blockquote>");
    // Bold + italic + inline code
    html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/\*([^*]+)\*/g, "<em>$1</em>");
    html = html.replace(/_([^_]+)_/g, "<em>$1</em>");
    html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
    // Listas: cada línea que empiece con - o *
    html = html.replace(/(?:^[-*] .+(?:\n|$))+/gm, (bloque) => {
        const items = bloque.trim().split("\n").map(l => l.replace(/^[-*] /, ""));
        return `<ul>${items.map(i => `<li>${i}</li>`).join("")}</ul>`;
    });
    // Párrafos: líneas sueltas que no son ya bloque HTML.
    html = html.split(/\n\n+/).map(bloque => {
        const trim = bloque.trim();
        if (!trim) return "";
        if (/^<(h\d|pre|ul|table|blockquote)/.test(trim)) return trim;
        return `<p>${trim.replace(/\n/g, "<br>")}</p>`;
    }).join("\n");
    return html;
}

function pintarEntendimientoFB(fbs) {
    const ul = $("#entend-feedbacks");
    if (!fbs || !fbs.length) { ul.innerHTML = ""; return; }
    ul.innerHTML = fbs.map(f => `
        <li class="skill-custom-fila">
          <div>
            <span class="skill-custom-fila__id">${escapeHtml((f.timestamp || "").slice(0,16))}</span>
            ${escapeHtml(f.comentario)}
          </div>
        </li>`).join("");
}

function pintarEntendimiento(data) {
    const cont = $("#entend-render");
    if (!data || !data.entendimiento_md) {
        cont.innerHTML = `<div class="empty-state" style="margin:8px 0;">
            <div class="empty-state__hint">Sin entendimiento generado todavía. Pulsa <strong>📊 Analizar código</strong>.</div>
        </div>`;
        $("#entend-feedback-wrap").hidden = true;
        return;
    }
    cont.innerHTML = renderMdBasico(data.entendimiento_md);
    $("#entend-feedback-wrap").hidden = false;
    pintarEntendimientoFB(data.feedbacks || []);
}

async function cargarEntendimiento() {
    try {
        const r = await pedirJSON("/api/entendimiento");
        pintarEntendimiento(r);
    } catch (err) {
        // 404 es el estado esperado antes del primer análisis.
        pintarEntendimiento(null);
    }
}

async function analizarCodigo() {
    const msg = $("#entend-mensaje");
    msg.textContent = "Analizando código… (puede tardar ~30s con API)";
    try {
        const r = await pedirJSON("/api/entendimiento/analizar", { method: "POST" });
        msg.textContent = `✅ Analizado: ${r.estructura.archivos} archivos, ${r.estructura.funciones} funciones, ${r.estructura.clases} clases`;
        pintarEntendimiento(r);
    } catch (err) {
        msg.textContent = "❌ " + err.message;
    }
}

async function enviarFeedbackEntendimiento(ev) {
    ev.preventDefault();
    const c = $("#entend-comentario").value.trim();
    if (c.length < 3) return;
    try {
        const r = await pedirJSON("/api/entendimiento/feedback", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ comentario: c }),
        });
        $("#entend-comentario").value = "";
        pintarEntendimientoFB(r.feedbacks);
    } catch (err) {
        alert(err.message);
    }
}

function cablearEntendimiento() {
    const btn = $("#btn-analizar-codigo");
    if (!btn) return;
    btn.addEventListener("click", analizarCodigo);
    $("#btn-reanalizar").addEventListener("click", analizarCodigo);
    $("#entend-form").addEventListener("submit", enviarFeedbackEntendimiento);
}

// ── Upload guiado por cards (v2 · fase 3) ────────────────────────────

async function renderUploadCards() {
    const cont = $("#upload-cards");
    try {
        const data = await pedirJSON("/api/inputs/destinos");
        // Excluimos los RAG_* de este panel: van a la pestaña Dominio & RAG.
        const cards = (data.destinos || []).filter(d => d.alcance === "sesion");
        cont.innerHTML = cards.map(d => renderCardHTML(d)).join("");
        for (const c of cont.querySelectorAll(".upload-card")) cablearCard(c);
        // Refresca conteos.
        for (const c of cont.querySelectorAll(".upload-card")) refrescarCard(c.dataset.slug);
    } catch (err) {
        cont.innerHTML = `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

function renderCardHTML(d) {
    const accept  = (d.formatos || []).join(",");
    const inputId = `file-input-${d.slug}`;
    const dzId    = `dropzone-${d.slug}`;
    const zipBadge = d.solo_zip
        ? `<span class="upload-card__cuenta upload-card__cuenta--zip">ZIP</span>` : "";
    return `
      <div class="upload-card" data-slug="${escapeHtml(d.slug)}" data-solo-zip="${d.solo_zip ? "1" : "0"}">
        <div class="upload-card__cab">
          <div>
            <span class="caret">▸</span>
            <span class="upload-card__titulo">📂 ${escapeHtml(d.label)}</span>
          </div>
          <div class="upload-card__meta">
            ${zipBadge}
            <span class="upload-card__cuenta upload-card__cuenta--vacia" data-slot="cuenta">·</span>
          </div>
        </div>
        <div class="upload-card__cuerpo">
          <div class="upload-card__desc">${escapeHtml(d.desc)}</div>
          <div class="upload-card__formatos">
            Formatos: ${(d.formatos || []).map(f => `<code>${escapeHtml(f)}</code>`).join("")}
          </div>
          <div class="dropzone" id="${dzId}" tabindex="0"
               aria-label="Arrastra archivos aquí o pulsa para elegir">
            <div class="dropzone__icon">${d.solo_zip ? "📦" : "📤"}</div>
            <div class="dropzone__title">
              ${d.solo_zip ? "Arrastra un .zip aquí" : "Arrastra archivos aquí"}
            </div>
            <div class="dropzone__hint">O <button type="button" class="link" data-pick>elige del sistema</button></div>
            <input type="file" id="${inputId}" ${d.solo_zip ? "" : "multiple"}
                   accept="${escapeHtml(accept)}" hidden>
          </div>
          <ul class="upload-card__ficheros" data-slot="ficheros">
            <li class="upload-card__vacio">Sin archivos todavía</li>
          </ul>
        </div>
      </div>`;
}

function cablearCard(card) {
    const slug    = card.dataset.slug;
    const soloZip = card.dataset.soloZip === "1";
    const cab     = card.querySelector(".upload-card__cab");
    const dz      = card.querySelector(".dropzone");
    const input   = card.querySelector('input[type="file"]');
    const pick    = card.querySelector("[data-pick]");

    cab.addEventListener("click", () => card.classList.toggle("is-abierta"));

    pick.addEventListener("click", (e) => { e.stopPropagation(); input.click(); });
    dz.addEventListener("click", (e) => { if (e.target !== pick) input.click(); });
    dz.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); }
    });
    input.addEventListener("change", async () => {
        if (input.files.length) await subirATarjeta(slug, input.files, soloZip);
        input.value = "";
    });
    ["dragenter", "dragover"].forEach(ev =>
        dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("is-drag"); }));
    ["dragleave", "drop"].forEach(ev =>
        dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("is-drag"); }));
    dz.addEventListener("drop", (e) => {
        if (e.dataTransfer && e.dataTransfer.files.length) {
            subirATarjeta(slug, e.dataTransfer.files, soloZip);
        }
    });
}

async function subirATarjeta(slug, fileList, soloZip) {
    const archivos = Array.from(fileList);
    if (!archivos.length) return;

    if (soloZip) {
        const zip = archivos.find(f => f.name.toLowerCase().endsWith(".zip"));
        if (!zip) {
            logSubida(`⚠️ '${slug}' requiere un .zip`, "log-warn");
            return;
        }
        const fd = new FormData();
        fd.append("archivo", zip);
        try {
            const r = await pedirJSON(`/api/inputs/upload-zip?destino=${encodeURIComponent(slug)}`,
                                        { method: "POST", body: fd });
            logSubida(`✅ ${slug}: ZIP «${zip.name}» — ${r.n_miembros} miembros`);
        } catch (err) {
            logSubida(`❌ ${slug}: ${err.message}`, "log-error");
        }
    } else {
        const fd = new FormData();
        for (const f of archivos) fd.append("archivos", f);
        try {
            const r = await pedirJSON(`/api/inputs/upload?destino=${encodeURIComponent(slug)}`,
                                        { method: "POST", body: fd });
            for (const g of r.guardados) {
                const clase = g.estado === "ok" ? "log-ok"
                            : g.estado === "warn" ? "log-warn" : "log-error";
                logSubida(`${iconoEstado(g.estado)} ${slug}: ${g.nombre} — ${tamanoLegible(g.tam)}`, clase);
            }
        } catch (err) {
            logSubida(`❌ ${slug}: ${err.message}`, "log-error");
        }
    }
    await refrescarCard(slug);
}

async function refrescarCard(slug) {
    const card = document.querySelector(`.upload-card[data-slug="${slug}"]`);
    if (!card) return;
    try {
        const r = await pedirJSON(`/api/inputs/carpeta/${encodeURIComponent(slug)}`);
        const ficheros = r.ficheros || [];
        const cuenta = card.querySelector('[data-slot="cuenta"]');
        cuenta.textContent = ficheros.length ? `${ficheros.length}` : "·";
        cuenta.classList.toggle("upload-card__cuenta--vacia", ficheros.length === 0);

        const lista = card.querySelector('[data-slot="ficheros"]');
        if (!ficheros.length) {
            lista.innerHTML = `<li class="upload-card__vacio">Sin archivos todavía</li>`;
            return;
        }
        lista.innerHTML = ficheros.map(f => `
            <li>
              <span>${iconoEstado("ok")} ${escapeHtml(f.ruta)}
                    <span class="tam">${escapeHtml(tamanoLegible(f.tam))}</span></span>
              <button type="button" class="btn-borrar" data-borrar-slug="${escapeHtml(slug)}" data-borrar-fichero="${escapeHtml(f.ruta)}" title="Eliminar">🗑️</button>
            </li>`).join("");
        for (const b of lista.querySelectorAll("[data-borrar-slug]")) {
            b.addEventListener("click", async () => {
                if (!confirm(`¿Eliminar «${b.dataset.borrarFichero}»?`)) return;
                try {
                    // /archivo/{slug}/{fichero} — el endpoint solo acepta basename.
                    const nombre = b.dataset.borrarFichero.split("/").pop();
                    await pedirJSON(`/api/inputs/archivo/${encodeURIComponent(slug)}/${encodeURIComponent(nombre)}`,
                                     { method: "DELETE" });
                    await refrescarCard(slug);
                } catch (err) {
                    alert(err.message);
                }
            });
        }
    } catch (err) {
        console.error(`refrescarCard(${slug}) falló:`, err.message);
    }
}

// Shim: la función `cablearDropzone()` v1 sigue siendo llamada por
// `arrancar()`. En v2 el panel de upload se pinta bajo demanda al abrirlo,
// así que esta función no hace nada; se conserva para compatibilidad.
function cablearDropzone() { /* v2: handled per-card in renderUploadCards() */ }

// ── Skills (v2 · fase 5) ─────────────────────────────────────────────

async function cargarSkills() {
    try {
        const r = await pedirJSON("/api/skills");
        pintarSkillsDefaults(r.defaults || []);
        pintarSkillsCustom(r.custom || []);
    } catch (err) {
        $("#skills-defaults").innerHTML =
            `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

function pintarSkillsDefaults(defaults) {
    const cont = $("#skills-defaults");
    cont.innerHTML = defaults.map(s => `
        <div class="skill-card ${s.activo ? "" : "skill-card--inactivo"}" data-id="${escapeHtml(s.id)}">
          <div class="skill-card__cuerpo">
            <div class="skill-card__nombre">${escapeHtml(s.nombre)}</div>
            <div class="skill-card__desc">${escapeHtml(s.descripcion)}</div>
          </div>
          <label class="switch" title="${s.activo ? "activo" : "inactivo"}">
            <input type="checkbox" ${s.activo ? "checked" : ""}
                   data-toggle-skill="${escapeHtml(s.id)}">
            <span class="switch__slider"></span>
          </label>
        </div>
    `).join("");
    for (const inp of cont.querySelectorAll("[data-toggle-skill]")) {
        inp.addEventListener("change", async () => {
            const sid = inp.dataset.toggleSkill;
            const activo = inp.checked;
            try {
                const r = await pedirJSON("/api/skills/toggle", {
                    method:  "POST",
                    headers: { "Content-Type": "application/json" },
                    body:    JSON.stringify({ skill_id: sid, activo }),
                });
                pintarSkillsDefaults(r.defaults);
            } catch (err) {
                inp.checked = !activo;
                alert("No se pudo aplicar: " + err.message);
            }
        });
    }
}

function pintarSkillsCustom(custom) {
    const cont = $("#skills-custom");
    if (!custom.length) {
        cont.innerHTML = `<div class="empty-state" style="margin-top:8px;">
            <div class="empty-state__title">Sin instrucciones personalizadas todavía.</div>
        </div>`;
        return;
    }
    cont.innerHTML = custom.map(c => `
        <div class="skill-custom-fila">
          <div>
            <span class="skill-custom-fila__id">${escapeHtml(c.id)}</span>
            ${escapeHtml(c.descripcion)}
          </div>
          <button type="button" class="cp-borrar" data-borrar-skill="${escapeHtml(c.id)}" title="Eliminar">🗑️</button>
        </div>
    `).join("");
    for (const b of cont.querySelectorAll("[data-borrar-skill]")) {
        b.addEventListener("click", async () => {
            if (!confirm(`¿Eliminar «${b.dataset.borrarSkill}»?`)) return;
            try {
                await pedirJSON(`/api/skills/custom/${encodeURIComponent(b.dataset.borrarSkill)}`, {
                    method: "DELETE",
                });
                cargarSkills();
            } catch (err) { alert(err.message); }
        });
    }
}

async function agregarSkillCustom(ev) {
    ev.preventDefault();
    const nl = $("#skills-nl").value.trim();
    const msg = $("#skills-mensaje");
    if (!nl) { msg.textContent = "Escribe algo primero."; return; }
    msg.textContent = "Guardando…";
    try {
        await pedirJSON("/api/skills/custom", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ descripcion: nl }),
        });
        $("#skills-nl").value = "";
        msg.textContent = "✅ añadido";
        cargarSkills();
    } catch (err) {
        msg.textContent = "❌ " + err.message;
    }
}

async function abrirSkills() {
    mostrarVista("vista-skills");
    $("#skills-mensaje").textContent = "";
    await cargarSkills();
}

// ── Dominio & RAG (v2 · fase 4) ──────────────────────────────────────

// El dominio del modelo se fija al crearlo; ya no hay toggle. Este
// stub sustituye a `cablearDominio()` de v1 para no romper el arranque.
function cablearDominio() { /* v2: dominio fijado por el modelo activo */ }

function pintarDominioActual() {
    const cont = $("#rag-dominio-actual");
    if (!estado.modelo) {
        cont.textContent = "No hay modelo activo.";
        return;
    }
    cont.innerHTML = `Modelo: <strong>${escapeHtml(estado.modelo.nombre)}</strong>
        · Dominio activo: <strong>${escapeHtml(estado.modelo.dominio)}</strong>
        <span class="tam">(el agente contrastará con la literatura de este dominio)</span>`;
}

async function cargarRagDominios() {
    const cont = $("#rag-dominios");
    try {
        const d = await pedirJSON("/api/rag/dominios");
        cont.innerHTML = (d.dominios || []).map(dom => renderRagDominioHTML(dom)).join("");
        for (const c of cont.querySelectorAll(".rag-domino-card")) cablearRagDominio(c);
    } catch (err) {
        cont.innerHTML = `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

function renderRagDominioHTML(dom) {
    const idx      = dom.indice || {};
    const chunks   = idx.n_chunks ?? 0;
    const docs     = idx.n_docs ?? 0;
    const papers   = dom.papers || [];
    const esActivo = estado.modelo && estado.modelo.dominio === dom.dominio;
    const esCustom = dom.tipo === "custom";
    const marca    = esActivo ? ` <span class="chip" style="color:var(--ok); border-color:var(--ok);">activo</span>` : "";
    const tipoBadge = esCustom
        ? ` <span class="chip" style="color:var(--sello); border-color:var(--sello);">custom</span>`
        : "";
    const creadoLinea = esCustom && dom.creado_por
        ? `<div class="rag-domino-card__meta" style="margin-top:4px;">
              Creado por <strong>${escapeHtml(dom.creado_por)}</strong>
              el ${escapeHtml(dom.fecha_creacion || "—")}${dom.descripcion ? ` · ${escapeHtml(dom.descripcion)}` : ""}
           </div>`
        : "";

    const filaPapers = papers.length
        ? papers.map(p => `<li>
              <span>📄 ${escapeHtml(p.nombre)}</span>
              <span class="tam">${escapeHtml(tamanoLegible(p.tam))}</span>
           </li>`).join("")
        : `<li class="upload-card__vacio">Sin papers en este dominio todavía.</li>`;

    const botonBorrar = esCustom
        ? `<button type="button" class="btn" data-accion="borrar-dominio" style="border-color:var(--sello); color:var(--sello);">🗑 Eliminar dominio</button>`
        : "";

    return `
      <div class="rag-domino-card" data-dominio="${escapeHtml(dom.dominio)}"
           data-slug="rag_${escapeHtml(dom.dominio)}" data-tipo="${escapeHtml(dom.tipo)}">
        <div class="rag-domino-card__cab">
          <div class="rag-domino-card__nombre">📚 ${escapeHtml(dom.nombre || dom.dominio)}${tipoBadge}${marca}</div>
          <div class="rag-domino-card__meta">
            Índice: ${chunks} chunks · ${docs} docs · ${papers.length} papers en disco
          </div>
        </div>
        ${creadoLinea}
        <ul class="rag-domino-card__ficheros">${filaPapers}</ul>
        <div class="rag-domino-card__acciones">
          <div class="dropzone" tabindex="0">
            <div class="dropzone__icon">📥</div>
            <div class="dropzone__title">Arrastra papers (.pdf, .md, .txt) aquí</div>
            <input type="file" multiple accept=".pdf,.md,.txt" hidden>
          </div>
          <button type="button" class="btn" data-accion="reconstruir">🔨 Reconstruir índice</button>
          ${botonBorrar}
        </div>
      </div>`;
}

function cablearRagDominio(card) {
    const dominio = card.dataset.dominio;
    const slug    = card.dataset.slug;
    const dz      = card.querySelector(".dropzone");
    const input   = card.querySelector('input[type="file"]');
    const btnRec  = card.querySelector('[data-accion="reconstruir"]');
    const btnDel  = card.querySelector('[data-accion="borrar-dominio"]');

    dz.addEventListener("click", () => input.click());
    input.addEventListener("change", async () => {
        if (input.files.length) await subirPapersRag(slug, input.files);
        input.value = "";
    });
    ["dragenter", "dragover"].forEach(ev =>
        dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("is-drag"); }));
    ["dragleave", "drop"].forEach(ev =>
        dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("is-drag"); }));
    dz.addEventListener("drop", (e) => {
        if (e.dataTransfer && e.dataTransfer.files.length) {
            subirPapersRag(slug, e.dataTransfer.files);
        }
    });
    btnRec.addEventListener("click", () => reconstruirIndice(dominio));
    if (btnDel) {
        btnDel.addEventListener("click", () => borrarDominio(dominio));
    }
}

async function borrarDominio(dominio) {
    if (!confirm(`¿Eliminar el dominio '${dominio}'?\n\nLa carpeta inputs/rag/${dominio}/ se moverá a archivo/dominios_retirados/. Los modelos que lo usan bloquearán la operación.`)) return;
    try {
        const r = await pedirJSON(`/api/rag/dominios/${encodeURIComponent(dominio)}`, {
            method: "DELETE",
        });
        pintarReconstruccion("is-ok",
            `🗑 Dominio '${dominio}' eliminado. Carpeta movida a: ${escapeHtml(r.movido_a || "archivo/")}.`);
        await cargarRagDominios();
    } catch (err) {
        pintarReconstruccion("is-error", `❌ ${escapeHtml(err.message)}`);
    }
}

async function crearDominio(ev) {
    ev.preventDefault();
    const nombre = $("#dom-nombre").value.trim();
    const desc   = $("#dom-desc").value.trim();
    const kws    = $("#dom-kws").value.split(",").map(s => s.trim()).filter(Boolean);
    const err    = $("#dom-error");
    err.hidden = true;
    if (!nombre) { err.hidden = false; err.textContent = "El nombre es obligatorio."; return; }
    try {
        const r = await pedirJSON("/api/rag/dominios/crear", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ nombre, descripcion: desc, palabras_clave: kws }),
        });
        $("#form-nuevo-dominio").reset();
        $("#rag-crear-form").hidden = true;
        $("#rag-crear-cta").hidden = false;
        pintarReconstruccion("is-ok",
            `✅ Dominio '${r.dominio.id}' creado. Sube papers y luego reconstruye el índice.`);
        await cargarRagDominios();
    } catch (e) {
        err.hidden = false; err.textContent = e.message;
    }
}

function cablearCrearDominio() {
    $("#btn-rag-nuevo").addEventListener("click", () => {
        $("#rag-crear-cta").hidden = true;
        $("#rag-crear-form").hidden = false;
        $("#dom-nombre").focus();
    });
    $("#btn-rag-cancelar").addEventListener("click", () => {
        $("#form-nuevo-dominio").reset();
        $("#dom-error").hidden = true;
        $("#rag-crear-form").hidden = true;
        $("#rag-crear-cta").hidden = false;
    });
    $("#form-nuevo-dominio").addEventListener("submit", crearDominio);
}

async function subirPapersRag(slug, fileList) {
    const fd = new FormData();
    for (const f of Array.from(fileList)) fd.append("archivos", f);
    try {
        const r = await pedirJSON(`/api/inputs/upload?destino=${encodeURIComponent(slug)}`,
                                    { method: "POST", body: fd });
        pintarReconstruccion("is-ok",
            `✅ Subidos ${r.guardados.length} paper(s) a ${slug}. `
            + `Pulsa <strong>Reconstruir índice</strong> para que el agente los tenga en cuenta.`);
        await cargarRagDominios();
    } catch (err) {
        pintarReconstruccion("is-error", `❌ Subida falló: ${escapeHtml(err.message)}`);
    }
}

async function reconstruirIndice(dominio) {
    pintarReconstruccion("is-cargando",
        `🔨 Reconstruyendo índice de ${dominio}… (coste 0, subproceso local)`);
    try {
        const r = await pedirJSON("/api/rag/reconstruir", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ dominio, force: true }),
        });
        const clase = r.ok ? "is-ok" : "is-error";
        pintarReconstruccion(clase,
            `${r.ok ? "✅" : "❌"} Reconstrucción exit=${r.exit_code}`,
            r.salida.slice(-1600));
        await cargarRagDominios();
    } catch (err) {
        pintarReconstruccion("is-error", `❌ ${escapeHtml(err.message)}`);
    }
}

function pintarReconstruccion(clase, titulo, detalle) {
    const cont = $("#rag-reconstruccion");
    cont.hidden = false;
    cont.className = `verificacion ${clase}`;
    cont.innerHTML = `<strong>${titulo}</strong>` +
        (detalle ? `<pre>${escapeHtml(detalle)}</pre>` : "");
}

async function abrirDominioRag() {
    mostrarVista("vista-rag");
    $("#rag-reconstruccion").hidden = true;
    pintarDominioActual();
    await cargarRagDominios();
}

// ── Pre-vuelo ─────────────────────────────────────────────────────────
function metrica(label, valor, clase = "") {
    return `<div class="metric ${clase}">
        <div class="metric__label">${label}</div>
        <div class="metric__valor">${escapeHtml(String(valor))}</div>
    </div>`;
}

function pintarPrevuelo(d) {
    const cont = $("#prevuelo-resultado");
    const chars = d.chars_totales || 0;
    const mb = (chars / (1024 * 1024)).toFixed(2);

    let html = `<div class="prevuelo-grid">
        ${metrica("Ficheros legibles", d.n_legibles, d.n_legibles ? "metric--ok" : "metric--warn")}
        ${metrica("Volumen (chars)", chars.toLocaleString() + `  · ${mb} MB`)}
        ${metrica("Carpetas vacías", d.carpetas_vacias.length,
                  d.carpetas_vacias.length ? "metric--warn" : "metric--ok")}
        ${metrica("Ámbitos sin evidencia", d.ambitos_sin_evidencia.length,
                  d.ambitos_sin_evidencia.length ? "metric--error" : "metric--ok")}
        ${metrica("Bloqueantes", d.hay_bloqueantes ? "SÍ" : "no",
                  d.hay_bloqueantes ? "metric--error" : "metric--ok")}
    </div>`;

    // Tabla por carpeta
    const carpetas = Object.keys(d.chars_por_carpeta || {}).sort();
    if (carpetas.length) {
        html += `<table class="tabla-prevuelo">
            <thead><tr><th>Carpeta</th><th class="num">Chars</th></tr></thead>
            <tbody>`;
        for (const c of carpetas) {
            const v = d.chars_por_carpeta[c] || 0;
            html += `<tr><td>${escapeHtml(c)}</td>
                     <td class="num">${v ? v.toLocaleString() : "—"}</td></tr>`;
        }
        html += `</tbody></table>`;
    }

    if (d.ambitos_sin_evidencia.length) {
        html += `<div class="bloque-hallazgos"><h4>❌ Ámbitos sin evidencia</h4><ul>`;
        for (const a of d.ambitos_sin_evidencia) html += `<li>${escapeHtml(a)}</li>`;
        html += `</ul><div class="dropzone__hint" style="margin-top:6px;">Cada uno puntuará 0.0 y arrastrará el score global (política §5).</div></div>`;
    }
    if (d.ambitos_parciales && d.ambitos_parciales.length) {
        html += `<div class="bloque-hallazgos bloque-hallazgos--warn"><h4>⚠️ Ámbitos con carpeta principal vacía</h4><ul>`;
        for (const par of d.ambitos_parciales) {
            const [amb, carp] = Array.isArray(par) ? par : [par, ""];
            html += `<li><strong>${escapeHtml(amb)}</strong>${carp ? ` — falta carpeta: <code>${escapeHtml(carp)}</code>` : ""}</li>`;
        }
        html += `</ul><div class="dropzone__hint" style="margin-top:6px;">Se evalúan solo desde carpetas de apoyo; puede ser legítimo, pero merece revisión.</div></div>`;
    }
    if (d.escaneados && d.escaneados.length) {
        html += `<div class="bloque-hallazgos bloque-hallazgos--warn"><h4>⚠️ PDF escaneados</h4><ul>`;
        for (const n of d.escaneados) html += `<li>${escapeHtml(n)}</li>`;
        html += `</ul></div>`;
    }
    if (d.lectura_fallida && d.lectura_fallida.length) {
        html += `<div class="bloque-hallazgos"><h4>❌ Lectura fallida</h4><ul>`;
        for (const n of d.lectura_fallida) html += `<li>${escapeHtml(n)}</li>`;
        html += `</ul></div>`;
    }
    if (d.sin_lector && d.sin_lector.length) {
        html += `<div class="bloque-hallazgos bloque-hallazgos--warn"><h4>⚠️ Sin lector (extensión no soportada)</h4><ul>`;
        for (const n of d.sin_lector) html += `<li>${escapeHtml(n)}</li>`;
        html += `</ul></div>`;
    }

    cont.innerHTML = html;
}

// ── Documentar (v2 · fase 8) ─────────────────────────────────────────

function pintarEstadoDocumentar(estado) {
    const cont = $("#doc-estado");
    const chat = estado.chat;
    const lineas = [
        `📁 Ficheros de evidencia: <strong>${estado.n_ficheros_inputs}</strong>`,
        `📊 JSON de resultados disponibles: <strong>${(estado.resultados_disponibles || []).length}</strong>`,
        chat
            ? `💬 Chat: ✅ ${chat.APROBADO} · ❌ ${chat.NEGADO} · ⏳ ${chat.PENDIENTE} · SIN TRATAR ${chat.SIN_TRATAR} (de ${chat.total})`
            : "💬 Chat: sin iniciar",
        `▶️ Corrida activa: ${estado.run || "ninguna"}`,
    ];
    cont.innerHTML = `<ul class="doc-estado-lista">${
        lineas.map(l => `<li>${l}</li>`).join("")
    }</ul>`;
}

function pintarSelectResultados(rutas) {
    const sel = $("#doc-select-informe");
    if (!rutas || !rutas.length) {
        sel.innerHTML = `<option value="" disabled selected>No hay JSON de resultados aún — lanza la validación primero.</option>`;
        $("#btn-doc-generar").disabled = true;
        return;
    }
    sel.innerHTML = `<option value="" disabled selected>${rutas.length} JSON disponibles…</option>`;
    for (const r of rutas) {
        const opt = document.createElement("option");
        opt.value = r;
        opt.textContent = r;
        sel.appendChild(opt);
    }
    $("#btn-doc-generar").disabled = false;
}

function pintarVersiones(versiones) {
    const cont = $("#doc-versiones");
    if (!versiones || !versiones.length) {
        cont.innerHTML = `<div class="empty-state" style="margin-top:8px;">
            <div class="empty-state__title">Sin versiones generadas aún.</div>
        </div>`;
        return;
    }
    cont.innerHTML = versiones.map(v => `
        <div class="skill-custom-fila">
          <div>
            <span class="skill-custom-fila__id">V${v.version}</span>
            ${escapeHtml(v.nombre)}
            <span class="tam">${escapeHtml(fmtTs(v.generado))} · ${escapeHtml(tamanoLegible(v.tam))}</span>
          </div>
          <a class="btn" href="/api/informe/descargar/${encodeURIComponent(v.nombre)}" download>📥 Descargar</a>
        </div>
    `).join("");
}

async function refrescarDocumentar() {
    try {
        const est = await pedirJSON("/api/informe/estado");
        pintarEstadoDocumentar(est);
        pintarSelectResultados(est.resultados_disponibles);
        pintarVersiones(est.versiones);
    } catch (err) {
        $("#doc-estado").innerHTML =
            `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

async function generarDocumentacion() {
    const ruta = $("#doc-select-informe").value;
    const cont = $("#doc-mensaje");
    if (!ruta) {
        cont.innerHTML = `<div class="verificacion is-error">Elige un JSON.</div>`;
        return;
    }
    cont.innerHTML = `<div class="verificacion is-cargando">Generando…</div>`;
    try {
        const r = await pedirJSON("/api/informe/consolidado", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ ruta }),
        });
        const url = `/api/informe/descargar/${encodeURIComponent(r.docx)}`;
        cont.innerHTML = `<div class="verificacion is-ok">
            <strong>✅ V${r.version} generado.</strong>
            <a href="${url}" download style="color:var(--accion);">Descargar ${escapeHtml(r.docx)}</a>
        </div>`;
        window.location.href = url;
        await refrescarDocumentar();
    } catch (err) {
        cont.innerHTML = `<div class="verificacion is-error"><strong>Error</strong><pre>${escapeHtml(err.message)}</pre></div>`;
    }
}

async function abrirDocumentar() {
    mostrarVista("vista-documentar");
    $("#doc-mensaje").innerHTML = "";
    await refrescarDocumentar();
}

function cablearDocumentar() {
    $("#btn-doc-generar").addEventListener("click", generarDocumentacion);
}

// ── Cuestionamientos POR SESIÓN (v2 · fase 6) ────────────────────────

function pintarCuestGrupo(contId, items) {
    const cont = $("#" + contId);
    cont.innerHTML = items.map(c => `
        <div class="skill-card ${c.activo ? "" : "skill-card--inactivo"}" data-id="${escapeHtml(c.id)}">
          <div class="skill-card__cuerpo">
            <div class="skill-card__nombre">${escapeHtml(c.contexto || c.id)}</div>
            <div class="skill-card__desc">${escapeHtml((c.critica || "").slice(0, 260))}</div>
          </div>
          <label class="switch" title="${c.activo ? "activo" : "inactivo"}">
            <input type="checkbox" ${c.activo ? "checked" : ""}
                   data-toggle-cuest="${escapeHtml(c.id)}">
            <span class="switch__slider"></span>
          </label>
        </div>
    `).join("");
    for (const inp of cont.querySelectorAll("[data-toggle-cuest]")) {
        inp.addEventListener("change", async () => {
            const cid = inp.dataset.toggleCuest;
            const activo = inp.checked;
            try {
                await pedirJSON("/api/cuestionamientos-sesion/toggle", {
                    method:  "POST",
                    headers: { "Content-Type": "application/json" },
                    body:    JSON.stringify({ id: cid, activo }),
                });
                inp.closest(".skill-card").classList.toggle("skill-card--inactivo", !activo);
            } catch (err) {
                inp.checked = !activo;
                alert("No se pudo aplicar: " + err.message);
            }
        });
    }
}

function pintarCuestCustom(items) {
    const cont = $("#cuest-custom");
    if (!items.length) {
        cont.innerHTML = `<div class="empty-state" style="margin-top:8px;">
            <div class="empty-state__title">Sin cuestionamientos personalizados todavía.</div>
        </div>`;
        return;
    }
    cont.innerHTML = items.map(c => `
        <div class="skill-custom-fila">
          <div>
            <span class="skill-custom-fila__id">${escapeHtml(c.id)}</span>
            ${escapeHtml(c.descripcion)}
          </div>
          <button type="button" class="cp-borrar" data-borrar-cuest="${escapeHtml(c.id)}" title="Eliminar">🗑️</button>
        </div>
    `).join("");
    for (const b of cont.querySelectorAll("[data-borrar-cuest]")) {
        b.addEventListener("click", async () => {
            if (!confirm(`¿Eliminar «${b.dataset.borrarCuest}»?`)) return;
            try {
                await pedirJSON(`/api/cuestionamientos-sesion/custom/${encodeURIComponent(b.dataset.borrarCuest)}`,
                                 { method: "DELETE" });
                cargarCuestionamientos();
            } catch (err) { alert(err.message); }
        });
    }
}

async function cargarCuestionamientos() {
    try {
        const r = await pedirJSON("/api/cuestionamientos-sesion");
        pintarCuestGrupo("cuest-presencia", r.presencia || []);
        pintarCuestGrupo("cuest-ausencia",  r.ausencia  || []);
        pintarCuestCustom(r.custom || []);
    } catch (err) {
        $("#cuest-presencia").innerHTML =
            `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

async function agregarCuestCustom(ev) {
    ev.preventDefault();
    const nl = $("#cuest-nl").value.trim();
    const msg = $("#cuest-mensaje");
    if (!nl) { msg.textContent = "Escribe algo primero."; return; }
    msg.textContent = "Guardando…";
    try {
        await pedirJSON("/api/cuestionamientos-sesion/custom", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ descripcion: nl }),
        });
        $("#cuest-nl").value = "";
        msg.textContent = "✅ añadido";
        cargarCuestionamientos();
    } catch (err) {
        msg.textContent = "❌ " + err.message;
    }
}

async function abrirCuestionamientos() {
    mostrarVista("vista-cuestionamientos");
    $("#cuest-mensaje").textContent = "";
    await cargarCuestionamientos();
}

function cablearCuestionamientos() {
    $("#btn-cuestionamientos").addEventListener("click", abrirCuestionamientos);
    $("#cuest-form").addEventListener("submit", agregarCuestCustom);
}

// ── Chat (paso 8) ────────────────────────────────────────────────────

let wsChat = null;

function fmtTs(iso) {
    if (!iso) return "";
    return iso.replace("T", " ").replace("Z", "");
}

function formatearMensajeChat(texto) {
    // Separa por ``` para renderizar bloques de código; escapa el resto.
    const partes = String(texto || "").split(/```/);
    let html = "";
    for (let i = 0; i < partes.length; i++) {
        const trozo = partes[i];
        if (i % 2 === 0) {
            // Texto normal — mantiene saltos de línea.
            html += escapeHtml(trozo).replace(/\n/g, "<br>");
        } else {
            // Bloque de código.
            html += `<pre class="chat-msg__codigo">${escapeHtml(trozo.trim())}</pre>`;
        }
    }
    return html;
}

function pintarChatMensaje(m) {
    const cont = $("#chat-mensajes");
    const div = document.createElement("div");
    div.className = `chat-msg chat-msg--${m.quien}`;
    const veredictoTag = m.veredicto
        ? ` <span class="chat-msg__veredicto v-${m.veredicto}">${m.veredicto}</span>` : "";
    div.innerHTML = `<div class="chat-msg__meta">${m.quien === "agente" ? "🤖 Agente" : "👤 Validador"} · ${fmtTs(m.ts_utc)}${veredictoTag}</div>${formatearMensajeChat(m.texto)}`;
    cont.appendChild(div);
    cont.scrollTop = cont.scrollHeight;
}

function pintarChatCompleto(sesion) {
    const cont = $("#chat-mensajes");
    cont.innerHTML = "";
    for (const m of (sesion.mensajes || [])) pintarChatMensaje(m);
    const r = sesion.resumen || {};
    $("#chat-resumen").textContent =
        `✅ ${r.APROBADO || 0} · ❌ ${r.NEGADO || 0} · ⏳ ${r.PENDIENTE || 0} · pendientes ${r.SIN_TRATAR || 0}`;
}

async function cargarListaInformesChat() {
    try {
        const d = await pedirJSON("/api/resultados/lista");
        const sel = $("#chat-select-informe");
        sel.innerHTML = `<option value="" disabled selected>${d.informes.length} informes disponibles…</option>`;
        for (const i of d.informes) {
            const opt = document.createElement("option");
            opt.value = i.ruta;
            opt.textContent = `${i.fecha} · ${i.modelo} (T${i.tier}) · score ${i.score_global ?? "—"}`;
            sel.appendChild(opt);
        }
    } catch (err) {
        console.error("No se pudo listar informes para chat:", err);
    }
}

function conectarChatWS() {
    if (wsChat) { try { wsChat.close(); } catch {} }
    const proto = window.location.protocol === "https:" ? "wss" : "ws";
    wsChat = new WebSocket(`${proto}://${window.location.host}/ws/chat`);
    wsChat.onmessage = (ev) => {
        let msg; try { msg = JSON.parse(ev.data); } catch { return; }
        if (msg.tipo === "estado" && msg.sesion) {
            pintarChatCompleto(msg.sesion);
        } else if (msg.tipo === "error") {
            pintarChatMensaje({
                quien: "agente",
                texto: `⚠️ ${msg.detalle || "error"}`,
                ts_utc: new Date().toISOString(),
            });
        }
    };
    wsChat.onclose = () => {
        $("#btn-chat-enviar").disabled = true;
    };
}

async function iniciarChat() {
    const ruta = $("#chat-select-informe").value;
    if (!ruta) return;
    try {
        const s = await pedirJSON("/api/chat/iniciar", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ ruta }),
        });
        $("#chat-inicio").hidden = true;
        $("#chat-conversacion").hidden = false;
        $("#btn-chat-enviar").disabled = false;
        pintarChatCompleto(s);
        conectarChatWS();
    } catch (err) {
        alert("No se pudo iniciar chat: " + err.message);
    }
}

function enviarChat(ev) {
    ev.preventDefault();
    const txt = $("#chat-input").value.trim();
    if (!txt) return;
    if (!wsChat || wsChat.readyState !== 1) {
        pintarChatMensaje({
            quien: "agente",
            texto: "⚠️ Conexión al servidor perdida. Cierra y vuelve a abrir el chat.",
            ts_utc: new Date().toISOString(),
        });
        return;
    }
    wsChat.send(JSON.stringify({ tipo: "responder", texto: txt }));
    $("#chat-input").value = "";
}

async function abrirChat() {
    mostrarVista("vista-chat");
    // Si ya hay sesión activa, reengancharse.
    try {
        const est = await pedirJSON("/api/chat/estado");
        if (est.activa) {
            $("#chat-inicio").hidden = true;
            $("#chat-conversacion").hidden = false;
            pintarChatCompleto(est.sesion);
            conectarChatWS();
            return;
        }
    } catch {}
    $("#chat-inicio").hidden = false;
    $("#chat-conversacion").hidden = true;
    await cargarListaInformesChat();
}

function cablearChat() {
    $("#btn-chat").addEventListener("click", abrirChat);
    $("#btn-chat-iniciar").addEventListener("click", iniciarChat);
    $("#chat-form").addEventListener("submit", enviarChat);
    // Enter envía, Shift+Enter salta línea.
    $("#chat-input").addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            enviarChat(e);
        }
    });
}

// ── Controles de datos (paso 7) ──────────────────────────────────────

function cablearTabs(rootId) {
    const root = document.getElementById(rootId);
    if (!root || root.dataset.tabsCabled === "1") return;   // idempotente
    root.dataset.tabsCabled = "1";
    for (const tab of root.querySelectorAll(".tab")) {
        tab.addEventListener("click", () => {
            for (const t of root.querySelectorAll(".tab")) t.classList.remove("is-active");
            for (const c of root.querySelectorAll(".tab-cuerpo")) c.hidden = true;
            tab.classList.add("is-active");
            document.getElementById(tab.dataset.tab).hidden = false;
        });
    }
}

async function cargarCatalogoMotores() {
    const cont = $("#catalogo-motores");
    try {
        const d = await pedirJSON("/api/motores/catalogo");
        cont.innerHTML = d.motores.map(m => `
            <div class="motor-fila">
                <div class="motor-fila__cab">
                    <span class="motor-fila__nombre">${escapeHtml(m.nombre)}</span>
                    <span class="tam">ejemplo: ${escapeHtml(m.ejemplo)}</span>
                </div>
                <div>${escapeHtml(m.descripcion)}</div>
                <div class="motor-fila__campos">
                    <strong>requiere:</strong> ${(m.requiere || []).map(escapeHtml).join(", ") || "—"}
                    · <strong>opcional:</strong> ${(m.opcional || []).map(escapeHtml).join(", ") || "—"}
                </div>
            </div>
        `).join("");
    } catch (err) {
        cont.innerHTML = `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

function claseEstado(txt) {
    const t = (txt || "").toLowerCase();
    if (/ok|cumple|conforme|pass/.test(t)) return "estado-ok";
    if (/falla|no\s*cumple|fail|error/.test(t)) return "estado-falla";
    return "estado-neutro";
}

function fmtPct(v) {
    if (v == null) return "—";
    return (v * 100).toFixed(2) + "%";
}

async function cargarMotoresEntidad() {
    const cont = $("#entidad-motores");
    try {
        const d = await pedirJSON("/api/motores/entidad");
        let html = "";
        if (d.ficheros && d.ficheros.length) {
            html += `<p class="tam">Ficheros leídos: ${d.ficheros.map(f => escapeHtml(f.nombre)).join(", ")}</p>`;
        }
        if (d.avisos && d.avisos.length) {
            html += `<div class="bloque-hallazgos bloque-hallazgos--warn"><h4>⚠️ Avisos</h4><ul>`;
            for (const a of d.avisos) html += `<li>${escapeHtml(a)}</li>`;
            html += `</ul></div>`;
        }
        if (d.filas && d.filas.length) {
            html += `<table class="tabla-entidad"><thead><tr>
                <th>Fichero</th><th>Descripción</th>
                <th class="num">Tasa</th><th class="num">Umbral</th>
                <th>Resultado</th><th>Detalle</th>
            </tr></thead><tbody>`;
            for (const f of d.filas) {
                html += `<tr>
                    <td>${escapeHtml(f.fichero)}</td>
                    <td>${escapeHtml(f.descripcion || "—")}</td>
                    <td class="num">${fmtPct(f.tasa)}</td>
                    <td class="num">${f.umbral == null ? "—" : f.umbral}</td>
                    <td class="estado-cell ${claseEstado(f.resultado)}">${escapeHtml(f.resultado || "—")}</td>
                    <td class="tam">${escapeHtml(f.detalle || "")}</td>
                </tr>`;
            }
            html += `</tbody></table>`;
        } else if ((!d.reportes_texto || !d.reportes_texto.length)
                   && (!d.avisos || !d.avisos.length)) {
            html += `<div class="empty-state" style="margin-top:8px;">
                <div class="empty-state__title">No hay resultados de motores de la entidad.</div>
                <div class="empty-state__hint">Sube el Excel, CSV, JSON, .txt o .md a
                    <code>inputs/calidad_datos/resultadocalidad_de_datos/</code>
                    (📁 Subir Evidencia → destino <em>Calidad de datos · Resultados</em>).</div>
            </div>`;
        }
        // Reportes en TEXTO PLANO (.txt/.md) — mejora 3
        if (d.reportes_texto && d.reportes_texto.length) {
            html += `<section class="config-section">
                <h3 class="config-section__title">Reportes en texto plano</h3>
                <p class="tab-descripcion">
                    Output textual del motor externo. Se incluye completo en el
                    prompt del agente cuando se ejecute la validación.
                </p>`;
            for (const r of d.reportes_texto) {
                html += `<details class="config-detalle" style="margin-top:8px;">
                    <summary>📄 ${escapeHtml(r.nombre)}
                        <span class="tam">${escapeHtml(tamanoLegible(r.tam))}${r.truncado ? " · truncado a 20k chars" : ""}</span>
                    </summary>
                    <pre class="chat-msg__codigo" style="margin-top:8px;">${escapeHtml(r.contenido)}</pre>
                </details>`;
            }
            html += `</section>`;
        }
        cont.innerHTML = html;
    } catch (err) {
        cont.innerHTML = `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

async function abrirControles() {
    mostrarVista("vista-controles");
    cablearTabs("vista-controles");
    await Promise.all([cargarCatalogoMotores(), cargarMotoresEntidad()]);
}

// ── Resultados (paso 6) ──────────────────────────────────────────────

const AMBITO_PESOS = {
    "Metodología":                    0.30,
    "Calidad de datos":               0.20,
    "Documentación":                  0.15,
    "Implementación":                 0.15,
    "Gobierno":                       0.12,
    "Uso e integración a la gestión": 0.08,
};

function pesoAmbito(nombre) {
    return AMBITO_PESOS[nombre] ?? null;
}

function colorSemaforo(hex, fallback = "#666") {
    return hex && /^[0-9A-F]{6}$/i.test(hex) ? `#${hex}` : fallback;
}

function pintarPolitica(pol) {
    if (!pol) return "";
    const criticos = pol.criticos_automaticos || [];
    const veto     = pol.veto_por_ambito || [];
    if (!criticos.length && !veto.length) {
        return `<div class="aviso-politica aviso--ok">
            ✅ Sin bloqueantes automáticos por §4.2 (ámbito &lt; 2.5) ni §6 (ámbito ≤ 2).
            <span class="tam">La firma sigue siendo del validador (§1).</span>
        </div>`;
    }
    const partes = [`<div class="aviso-politica">`,
                    `<strong>Políticas del procedimiento aplicadas.</strong> La decisión formal la firma el validador (§1).<ul style="margin:6px 0 0 18px;">`];
    if (criticos.length) partes.push(`<li><strong>§6 críticos automáticos</strong>: ${criticos.map(escapeHtml).join(", ")}</li>`);
    if (veto.length)     partes.push(`<li><strong>§4.2 veto por ámbito</strong>: ${veto.map(escapeHtml).join(", ")}</li>`);
    partes.push(`</ul></div>`);
    return partes.join("");
}

function pintarActividad(ev) {
    const p    = ev.puntaje;
    const bg   = p == null ? "#555" : (p >= 4 ? "#00b050" : p >= 3 ? "#f0c040" : "#e94560");
    const etiqueta = ev.control ? `${escapeHtml(ev.control)} — ${escapeHtml(ev.actividad || "")}`
                                : escapeHtml(ev.actividad || "(actividad)");
    let html = `<div class="actividad">
        <div class="actividad__titulo">
            <span class="actividad__puntaje" style="background:${bg}">${p ?? "—"}</span>
            ${etiqueta}
        </div>`;
    if (ev.concepto)     html += `<div class="actividad__campo"><strong>Concepto:</strong> ${escapeHtml(ev.concepto)}</div>`;
    if (ev.observacion)  html += `<div class="actividad__campo"><strong>Observación:</strong> ${escapeHtml(ev.observacion)}</div>`;
    if (ev.evidencia_encontrada) html += `<div class="actividad__campo"><strong>Evidencia:</strong> ${escapeHtml(ev.evidencia_encontrada).slice(0, 500)}</div>`;
    if (ev.recomendacion) html += `<div class="actividad__campo"><strong>Recomendación:</strong> ${escapeHtml(ev.recomendacion)}</div>`;
    const pp = ev.preguntas_pendientes;
    if (Array.isArray(pp) && pp.length) {
        html += `<div class="actividad__campo"><strong>Preguntas pendientes:</strong><ul style="margin:2px 0 0 18px;">`;
        for (const q of pp) html += `<li>${escapeHtml(q)}</li>`;
        html += `</ul></div>`;
    }
    if (ev.cobertura_documental != null) {
        html += `<div class="actividad__campo"><strong>Cobertura documental:</strong> ${ev.cobertura_documental}%</div>`;
    }
    if (ev.ajuste_sesgo) {
        html += `<div class="actividad__campo"><strong>Ajuste feedback:</strong> ${escapeHtml(String(ev.ajuste_sesgo))}</div>`;
    }
    html += `</div>`;
    return html;
}

function pintarResultados(d) {
    const semaforo = d.semaforo || {};
    const color = colorSemaforo(semaforo.color);
    const scoreTxt = (typeof d.score_global === "number") ? d.score_global.toFixed(2) : "—";

    const ejec = (d.agente || {}).huella_ejecucion || "";
    const fecha = d.fecha || "";
    let html = `<div class="hero-score">
        <div class="hero-score__valor" style="background:${color}">${scoreTxt}</div>
        <div class="hero-score__cuerpo">
            <div class="hero-score__label">${escapeHtml(semaforo.label || "SIN CLASIFICAR")}</div>
            <div class="hero-score__meta">
                Modelo: <strong>${escapeHtml(d.modelo || "—")}</strong> · Tier ${escapeHtml(String(d.tier || "—"))}
                · Fecha: ${escapeHtml(fecha)}${ejec ? ` · <code>${escapeHtml(ejec).slice(0, 12)}…</code>` : ""}
            </div>
        </div>
    </div>`;

    html += pintarPolitica(d.politicas_procedimiento);

    // Tabla de ámbitos.
    const scores = d.scores_por_ambito || {};
    const ambitos = Object.entries(scores).sort((a, b) => (a[1] ?? 99) - (b[1] ?? 99));
    if (ambitos.length) {
        html += `<table class="tabla-ambitos">
            <thead><tr>
                <th>Ámbito</th><th class="num">Peso</th><th class="num">Score</th>
                <th>Nivel</th><th class="num">Aporta al global</th>
            </tr></thead><tbody>`;
        for (const [nombre, sc] of ambitos) {
            const peso = pesoAmbito(nombre);
            const val = typeof sc === "number" ? sc : null;
            const pct = val == null ? 0 : Math.max(0, Math.min(100, (val / 5) * 100));
            const chipColor = val == null ? "#666"
                              : val < 2.5 ? "#e94560"
                              : val < 3.5 ? "#f0c040"
                              : "#00b050";
            const aporta = (val != null && peso != null) ? (val * peso).toFixed(2) : "—";
            html += `<tr>
                <td>${escapeHtml(nombre)}</td>
                <td class="num">${peso != null ? (peso * 100).toFixed(0) + "%" : "—"}</td>
                <td class="num"><span class="barra"><i style="width:${pct}%; background:${chipColor}"></i></span>${val != null ? val.toFixed(2) : "—"}</td>
                <td><span class="chip" style="background:${chipColor}">${val == null ? "—" : val < 2.5 ? "BLOQUEANTE" : val < 3.5 ? "OBSERV." : "OK"}</span></td>
                <td class="num">${aporta}</td>
            </tr>`;
        }
        html += `</tbody></table>`;
    }

    // Detalle expandible por ámbito.
    const rpa = d.resultados_por_ambito || {};
    for (const [ambito, evs] of Object.entries(rpa)) {
        const sc = scores[ambito];
        const bg = colorSemaforo((sc == null ? null : sc < 2.5 ? "E94560" : sc < 3.5 ? "F0C040" : "00B050"));
        html += `<div class="detalle-ambito">
            <div class="detalle-ambito__cabeza" data-ambito="${escapeHtml(ambito)}">
                <div><span class="caret">▸</span><strong>${escapeHtml(ambito)}</strong>
                     <span class="tam">${evs.length} actividad(es)</span></div>
                <div><span class="chip" style="background:${bg}">${sc != null ? sc.toFixed(2) : "—"}</span></div>
            </div>
            <div class="detalle-ambito__cuerpo">
                ${evs.map(pintarActividad).join("")}
            </div>
        </div>`;
    }

    const cont = $("#resultados-render");
    cont.innerHTML = html;
    for (const cab of cont.querySelectorAll(".detalle-ambito__cabeza")) {
        cab.addEventListener("click", () => cab.parentElement.classList.toggle("is-abierto"));
    }
}

async function cargarInforme(ruta) {
    try {
        const r = await pedirJSON(`/api/resultados/${ruta}`);
        pintarResultados(r.datos);
    } catch (err) {
        $("#resultados-render").innerHTML =
            `<div class="verificacion is-error"><strong>No se pudo cargar</strong><pre>${escapeHtml(err.message)}</pre></div>`;
    }
}

async function cargarListaResultados() {
    try {
        const d = await pedirJSON("/api/resultados/lista");
        const sel = $("#resultados-select");
        sel.innerHTML = `<option value="" disabled selected>${d.informes.length} informes en outputs/…</option>`;
        for (const i of d.informes) {
            const opt = document.createElement("option");
            opt.value = i.ruta;
            const label = i.semaforo && i.semaforo.label ? i.semaforo.label : "—";
            opt.textContent = `${i.fecha} · ${i.modelo} (T${i.tier}) — ${i.score_global ?? "—"}  ${label}`;
            sel.appendChild(opt);
        }
    } catch (err) {
        console.error("No se pudo cargar historial:", err);
    }
}

async function abrirResultados() {
    mostrarVista("vista-resultados");
    await cargarListaResultados();
    // Si hay una corrida con JSON, cárgalo directo.
    try {
        const act = await pedirJSON("/api/resultados/actual");
        $("#resultados-select").value = act.ruta;
        pintarResultados(act.datos);
    } catch { /* no hay resultado actual */ }
}

function cablearResultados() {
    $("#btn-resultados").addEventListener("click", abrirResultados);
    $("#btn-controles").addEventListener("click", abrirControles);
    $("#btn-documentar").addEventListener("click", abrirDocumentar);
    $("#resultados-select").addEventListener("change", (e) => {
        if (e.target.value) cargarInforme(e.target.value);
    });
}

// ── Validación (paso 5) ──────────────────────────────────────────────

let wsValidacion = null;
let runIdActivo  = null;

function pintarLinea(clase, texto) {
    const cont = $("#run-log");
    const div = document.createElement("div");
    div.className = clase;
    div.textContent = texto;
    cont.appendChild(div);
    cont.scrollTop = cont.scrollHeight;
}

function actualizarEstadoUI(estado, fase, runId) {
    if (estado) $("#run-estado").textContent = estado;
    if (fase)   $("#run-fase").textContent  = fase;
    if (runId)  $("#run-id").textContent    = runId;
    const enCurso = estado === "corriendo" || estado === "arrancando";
    $("#btn-lanzar-validacion").disabled  = enCurso;
    $("#btn-cancelar-validacion").disabled = !enCurso;
    $("#estado-indicador").textContent =
        estado === "corriendo" ? "🔄 Validando…"
      : estado === "ok"        ? "✅ Validación OK"
      : estado === "error"     ? "❌ Validación fallida"
      : estado === "cancelado" ? "🛑 Cancelada"
      : "⏳ Listo";
}

function precondicionesValidacion() {
    // Sesion (modelo/tier/dominio) + firmante.
    const errores = [];
    if (!estado.modelo)  errores.push("Falta título del modelo (⚙️ Configuración).");
    if (!estado.dominio) errores.push("Falta dominio (barra lateral → LaR/VaR/conductuales).");
    if (!$("#firm-validador").value.trim()) errores.push("Falta nombre del validador.");
    if (!$("#firm-cargo").value.trim())     errores.push("Falta cargo del validador.");
    return errores;
}

function pintarPrecondiciones() {
    const errores = precondicionesValidacion();
    const cont = $("#validar-precondiciones");
    if (!errores.length) { cont.hidden = true; return; }
    cont.hidden = false;
    cont.className = "verificacion is-error";
    cont.innerHTML = `<strong>Faltan datos antes de lanzar:</strong><ul style="margin:6px 0 0 18px;">`
        + errores.map(e => `<li>${escapeHtml(e)}</li>`).join("") + `</ul>`;
}

function conectarWebSocket(runId) {
    if (wsValidacion) { try { wsValidacion.close(); } catch {} }
    const proto = window.location.protocol === "https:" ? "wss" : "ws";
    wsValidacion = new WebSocket(`${proto}://${window.location.host}/ws/validar/${runId}`);
    wsValidacion.onopen  = () => pintarLinea("log-arranque", `── conectado al stream (${runId})`);
    wsValidacion.onerror = () => pintarLinea("log-error", "── error de WebSocket");
    wsValidacion.onclose = () => pintarLinea("log-arranque", "── stream cerrado");
    wsValidacion.onmessage = (ev) => {
        let msg;
        try { msg = JSON.parse(ev.data); } catch { pintarLinea("log-linea", ev.data); return; }
        switch (msg.tipo) {
            case "arranque":
                pintarLinea("log-arranque",
                    `$ python ${msg.args.map(a => a.includes(" ") ? `"${a}"` : a).join(" ")}`);
                break;
            case "fase":
                pintarLinea("log-fase", `═══ ${msg.fase} ═══`);
                actualizarEstadoUI(null, msg.fase, null);
                break;
            case "linea":
                pintarLinea("log-linea", msg.texto);
                break;
            case "ping":
                pintarLinea("log-ping", "· ping");
                break;
            case "fin":
                const clase = msg.exit === 0 ? "log-fin-ok" : "log-fin-error";
                pintarLinea(clase,
                    `── fin (exit ${msg.exit}) — estado: ${msg.estado}` +
                    (msg.resultado_json ? ` — JSON: ${msg.resultado_json}` : ""));
                actualizarEstadoUI(msg.estado, msg.estado === "ok" ? "completado" : "—", null);
                if (msg.estado === "ok" && msg.resultado_json) {
                    const cont = $("#run-log");
                    // Idempotente: si ya hay uno de un `fin` anterior, se reemplaza.
                    for (const prev of cont.querySelectorAll(".btn-ver-resultados")) prev.remove();
                    const btn = document.createElement("button");
                    btn.className = "btn btn--primary btn-ver-resultados";
                    btn.style.marginTop = "10px";
                    btn.textContent = "📊 Ver resultados";
                    btn.addEventListener("click", abrirResultados);
                    cont.appendChild(btn);
                }
                break;
            case "error":
            case "error_bomba":
                pintarLinea("log-error", `❌ ${msg.detalle || "(sin detalle)"}`);
                break;
        }
    };
}

async function lanzarValidacion() {
    const errores = precondicionesValidacion();
    if (errores.length) { pintarPrecondiciones(); return; }
    try {
        const body = {
            validador:   $("#firm-validador").value.trim(),
            cargo:       $("#firm-cargo").value.trim(),
            validador_2: $("#firm-validador-2").value.trim() || null,
            cargo_2:     $("#firm-cargo-2").value.trim() || null,
        };
        const r = await pedirJSON("/api/validar/lanzar", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify(body),
        });
        runIdActivo = r.run_id;
        $("#validar-progreso").hidden = false;
        $("#run-log").innerHTML = "";
        actualizarEstadoUI("arrancando", "—", runIdActivo);
        conectarWebSocket(runIdActivo);
    } catch (err) {
        $("#validar-precondiciones").hidden = false;
        $("#validar-precondiciones").className = "verificacion is-error";
        $("#validar-precondiciones").innerHTML = `<strong>No se pudo lanzar</strong><pre>${escapeHtml(err.message)}</pre>`;
    }
}

async function cancelarValidacion() {
    if (!runIdActivo) return;
    try {
        await pedirJSON(`/api/validar/cancelar/${runIdActivo}`, { method: "POST" });
        pintarLinea("log-error", "── cancelación pedida (SIGTERM)");
    } catch (err) {
        pintarLinea("log-error", `── error cancelando: ${err.message}`);
    }
}

function cablearValidacion() {
    $("#btn-validar").addEventListener("click", async () => {
        mostrarVista("vista-validar");
        pintarPrecondiciones();
        // Si hay una corrida en curso, reengancharse.
        try {
            const r = await pedirJSON("/api/validar/estado");
            if (r.run && r.run.run_id) {
                runIdActivo = r.run.run_id;
                $("#validar-progreso").hidden = false;
                actualizarEstadoUI(r.run.estado, r.run.fase, r.run.run_id);
                if (r.run.estado === "corriendo" || r.run.estado === "arrancando") {
                    conectarWebSocket(runIdActivo);
                }
            }
        } catch {}
    });
    $("#btn-lanzar-validacion").addEventListener("click", lanzarValidacion);
    $("#btn-cancelar-validacion").addEventListener("click", cancelarValidacion);
    for (const inp of ["#firm-validador", "#firm-cargo"]) {
        $(inp).addEventListener("input", pintarPrecondiciones);
    }
}

async function ejecutarPrevuelo() {
    mostrarVista("vista-prevuelo");
    $("#prevuelo-resultado").innerHTML = "";
    $("#prevuelo-cargando").hidden = false;
    $("#estado-indicador").textContent = "🔄 Pre-vuelo…";
    try {
        const d = await pedirJSON("/api/prevuelo", { method: "POST" });
        pintarPrevuelo(d);
        $("#estado-indicador").textContent = d.hay_bloqueantes
            ? "⚠️ Pre-vuelo con bloqueantes"
            : "✅ Pre-vuelo OK";
    } catch (err) {
        $("#prevuelo-resultado").innerHTML =
            `<div class="verificacion is-error"><strong>Error</strong>` +
            `<pre>${escapeHtml(err.message)}</pre></div>`;
        $("#estado-indicador").textContent = "❌ Pre-vuelo falló";
    } finally {
        $("#prevuelo-cargando").hidden = true;
    }
}

// ── Modal de configuración ───────────────────────────────────────────

let proveedorActivo = "azure_openai";

function abrirModal(id) {
    const m = document.getElementById(id);
    m.hidden = false;
    m.setAttribute("aria-hidden", "false");
}

function cerrarModal(id) {
    const m = document.getElementById(id);
    m.hidden = true;
    m.setAttribute("aria-hidden", "true");
}

function pintarVerificacion(clase, titulo, detalle) {
    const cont = $("#cfg-verificacion");
    cont.hidden = false;
    cont.className = `verificacion ${clase}`;
    cont.innerHTML = `<strong>${titulo}</strong>` +
        (detalle ? `<pre>${escapeHtml(detalle)}</pre>` : "");
}

function seleccionarProveedor(prov) {
    proveedorActivo = prov;
    for (const b of $$(".proveedor-toggle .toggle-btn")) {
        b.setAttribute("aria-pressed", b.dataset.proveedor === prov ? "true" : "false");
    }
    for (const c of $$(".proveedor-campos")) {
        c.hidden = c.id !== `campos-${prov}`;
    }
    $("#cfg-verificacion").hidden = true;
}

async function abrirConfiguracion() {
    abrirModal("modal-config");
    try {
        const cfg = await pedirJSON("/api/config");
        // Precarga: modelo/tier de sesión.
        if (cfg.sesion.modelo) $("#cfg-titulo").value = cfg.sesion.modelo;
        if (cfg.sesion.tier)   $("#cfg-tier").value  = cfg.sesion.tier;

        // Precarga: proveedor activo del .env.
        seleccionarProveedor(cfg.env.proveedor_activo || "azure_openai");

        // Precarga: valores NO secretos del env. Los secretos se dejan vacíos
        // y el placeholder ya avisa de que se conserva el actual.
        for (const inp of $$("[data-var]")) {
            const clave = inp.dataset.var;
            for (const prov of Object.keys(cfg.env).filter(k => k !== "proveedor_activo")) {
                const meta = cfg.env[prov][clave];
                if (meta && !inp.value && meta.valor) {
                    inp.value = meta.valor;
                }
            }
        }
    } catch (err) {
        pintarVerificacion("is-error", "No se pudo cargar la configuración", err.message);
    }
}

function recolectarCredenciales() {
    const creds = {};
    const scope = $(`#campos-${proveedorActivo}`);
    if (!scope) return creds;
    for (const inp of scope.querySelectorAll("[data-var]")) {
        creds[inp.dataset.var] = inp.value.trim();
    }
    return creds;
}

async function guardarConfig() {
    const titulo = $("#cfg-titulo").value.trim();
    const tier   = $("#cfg-tier").value;
    if (!titulo) {
        pintarVerificacion("is-error", "Falta el título del modelo.", "");
        return;
    }
    try {
        await pedirJSON("/api/config/modelo", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ titulo, tier }),
        });
        estado.modelo = titulo;
        $("#modelo-actual").textContent = `${titulo} (Tier ${tier})`;

        const credenciales = recolectarCredenciales();
        await pedirJSON("/api/config/proveedor", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ proveedor: proveedorActivo, credenciales }),
        });
        pintarVerificacion("is-ok", "Guardado.",
            "Modelo, tier y credenciales aplicados. Pulsa «Verificar conexión» para "
            + "hacer una llamada de prueba al proveedor.");
    } catch (err) {
        pintarVerificacion("is-error", "No se pudo guardar", err.message);
    }
}

async function verificarConexion() {
    pintarVerificacion("is-cargando", "Verificando…", "Consulta al proveedor en curso.");
    try {
        const r = await pedirJSON("/api/config/verificar", { method: "POST" });
        if (r.ok) {
            const perfil = r.perfil || {};
            const lineas = [
                `Proveedor: ${r.proveedor || "—"}`,
                `Modelo:    ${r.modelo    || "—"}`,
                `Latencia:  ${r.latencia_ms ?? "—"} ms`,
            ];
            if (perfil.nombre) {
                lineas.push("");
                lineas.push(`Perfil de chunking: ${perfil.nombre}`);
                lineas.push(`  contexto:   ${perfil.contexto_tokens} tokens`);
                lineas.push(`  max_ctx:    ${perfil.max_ctx} chars`);
                lineas.push(`  chunk_size: ${perfil.chunk_size} chars`);
            }
            pintarVerificacion("is-ok", "✅ Conexión OK", lineas.join("\n"));
        } else {
            const meta = r.proveedor_meta || {};
            const lineas = [];
            if (r.error)      lineas.push(`Error: ${r.error}`);
            if (r.error_json) lineas.push(`Error JSON: ${r.error_json}`);
            if (r.respuesta_cruda) lineas.push(`Respuesta cruda: ${r.respuesta_cruda}`);
            if (meta.vars_revisar && meta.vars_revisar.length) {
                lineas.push("");
                lineas.push(`Revisa en .env (proveedor: ${meta.nombre}):`);
                for (const v of meta.vars_revisar) lineas.push(`  ${v}`);
            }
            pintarVerificacion("is-error", "❌ Verificación fallida", lineas.join("\n"));
        }
    } catch (err) {
        pintarVerificacion("is-error", "❌ Error del backend", err.message);
    }
}

function cablearConfig() {
    $("#btn-config").addEventListener("click", abrirConfiguracion);
    for (const el of $$("[data-close-modal]")) {
        el.addEventListener("click", () => cerrarModal("modal-config"));
    }
    for (const btn of $$(".proveedor-toggle .toggle-btn")) {
        btn.addEventListener("click", () => seleccionarProveedor(btn.dataset.proveedor));
    }
    $("#btn-verificar").addEventListener("click", verificarConexion);
    $("#btn-guardar-config").addEventListener("click", guardarConfig);
}

// ── Paso 02 · Estándares de validación ───────────────────────────────

let EST_PREVIEW = null;   // {status, filename, summary, estandares}

async function abrirEstandares() {
    mostrarVista("vista-estandares");
    resetEstandaresUI();
    try {
        const st = await pedirJSON("/api/estandares/estado");
        if (st.confirmado) { pintarEstandaresConfirmado(st); return; }
        if (st.subido && !st.confirmado) {
            // Ya hay .xlsx: reparsear vía endpoint upload no reejecuta parse,
            // pero /detalle solo existe si está confirmado. Usamos re-upload lógico:
            // el fichero ya está en disco, así que refrescamos vista limpia y el
            // usuario re-arrastra si quiere ver la preview. (Alternativa futura:
            // endpoint /parsear-actual.)
        }
    } catch (err) { /* 404 esperado si no hay sesión */ }
}

function resetEstandaresUI() {
    $("#est-resumen").hidden = true;
    $("#est-resumen").innerHTML = "";
    $("#est-dropzone").hidden  = false;
    $("#est-preview-wrap").hidden = true;
    $("#est-error").hidden = true;
    $("#est-file").value = "";
    EST_PREVIEW = null;
}

function pintarEstandaresConfirmado(st) {
    $("#est-dropzone").hidden = true;
    $("#est-preview-wrap").hidden = true;
    const box = $("#est-resumen");
    const s = st.summary || {};
    box.innerHTML = `
        <div class="est-confirmado">
            <div><strong>✓ Estándares cargados:</strong> ${escapeHtml(st.fichero || "estandares_validacion.xlsx")}</div>
            <div class="tam">${s.total_ambitos || 0} ámbitos · ${s.total_actividades || 0} actividades · Tier I-IV</div>
            <div class="tam">Confirmado por ${escapeHtml(st.confirmado_por || "?")} · ${(st.confirmado_utc || "").slice(0,16)}</div>
            <div class="est-actions" style="margin-top:8px;">
                <button type="button" class="btn btn--ghost" id="est-btn-ver">Ver detalle</button>
                <button type="button" class="btn btn--ghost" id="est-btn-reemplazar">Reemplazar</button>
            </div>
        </div>`;
    box.hidden = false;
    $("#est-btn-ver").addEventListener("click", verDetalleEstandares);
    $("#est-btn-reemplazar").addEventListener("click", async () => {
        if (!confirm("¿Reemplazar los estándares confirmados? Los pasos posteriores se invalidan.")) return;
        await fetch("/api/estandares", { method: "DELETE" });
        resetEstandaresUI();
    });
}

async function verDetalleEstandares() {
    try {
        const d = await pedirJSON("/api/estandares/detalle");
        EST_PREVIEW = d;
        pintarPreviewEstandares(d);
    } catch (err) { alert(err.message); }
}

async function subirEstandares(file) {
    const err = $("#est-error");
    err.hidden = true;
    if (!file.name.toLowerCase().endsWith(".xlsx")) {
        err.hidden = false; err.textContent = "Solo se acepta .xlsx"; return;
    }
    const fd = new FormData();
    fd.append("archivo", file);
    try {
        const r = await fetch("/api/estandares/upload", { method: "POST", body: fd });
        const d = await r.json();
        if (!r.ok) { err.hidden = false; err.textContent = d.detail || `Error ${r.status}`; return; }
        EST_PREVIEW = d;
        pintarPreviewEstandares(d);
    } catch (e) { err.hidden = false; err.textContent = e.message; }
}

function pintarPreviewEstandares(d) {
    $("#est-dropzone").hidden = true;
    $("#est-preview-wrap").hidden = false;
    const s = d.summary || {};
    $("#est-summary").innerHTML = `
        <strong>${escapeHtml(d.filename || d.fichero || "estandares.xlsx")}</strong>
        · ${s.total_actividades || 0} actividades
        · ${s.total_ambitos || 0} ámbitos
    `;
    const cont = $("#est-ambitos");
    cont.innerHTML = (d.estandares || []).map((amb, i) => {
        const numAct = amb.controles.reduce((a, c) => a + c.actividades.length, 0);
        const abierto = i === 0;
        return `
        <details class="est-ambito" ${abierto ? "open" : ""}>
            <summary class="est-ambito__cabecera">
                <span class="est-ambito__titulo">${escapeHtml(amb.ambito)}</span>
                <span class="tam">${amb.controles.length} controles · ${numAct} actividades</span>
            </summary>
            <div class="est-ambito__cuerpo">
              ${amb.controles.map(ctrl => `
                <div class="est-control">
                    <div class="est-control__nombre">Control: ${escapeHtml(ctrl.nombre)}</div>
                    <table class="est-tabla">
                        <thead>
                            <tr><th>Actividad</th><th>T1</th><th>T2</th><th>T3</th><th>T4</th></tr>
                        </thead>
                        <tbody>
                            ${ctrl.actividades.map(a => `
                                <tr>
                                    <td class="est-actividad">${escapeHtml(a.descripcion)}</td>
                                    ${["tier_1","tier_2","tier_3","tier_4"].map(t =>
                                        `<td class="est-tier ${a[t] ? "est-tier--activo" : ""}">${a[t] ? "✓" : ""}</td>`
                                    ).join("")}
                                </tr>`).join("")}
                        </tbody>
                    </table>
                </div>`).join("")}
            </div>
        </details>`;
    }).join("");
}

async function aceptarEstandares() {
    try {
        const r = await pedirJSON("/api/estandares/confirmar", { method: "POST" });
        pintarEstandaresConfirmado(r);
    } catch (err) { alert(err.message); }
}

async function cambiarArchivoEstandares() {
    await fetch("/api/estandares", { method: "DELETE" });
    resetEstandaresUI();
}

function cablearEstandares() {
    const btn = $("#btn-estandares");
    if (btn) btn.addEventListener("click", abrirEstandares);
    const dz = $("#est-dropzone");
    const file = $("#est-file");
    if (dz && file) {
        dz.addEventListener("click", () => file.click());
        dz.addEventListener("dragover", e => { e.preventDefault(); dz.classList.add("est-dropzone--hover"); });
        dz.addEventListener("dragleave", () => dz.classList.remove("est-dropzone--hover"));
        dz.addEventListener("drop", e => {
            e.preventDefault();
            dz.classList.remove("est-dropzone--hover");
            if (e.dataTransfer.files.length) subirEstandares(e.dataTransfer.files[0]);
        });
        file.addEventListener("change", () => { if (file.files.length) subirEstandares(file.files[0]); });
    }
    const ok = $("#est-btn-aceptar");
    if (ok) ok.addEventListener("click", aceptarEstandares);
    const cambiar = $("#est-btn-cambiar");
    if (cambiar) cambiar.addEventListener("click", cambiarArchivoEstandares);
}


// ── Navegación de la barra lateral ───────────────────────────────────
function cablearNav() {
    $("#btn-subir").addEventListener("click", async () => {
        mostrarVista("vista-upload");
        await renderUploadCards();
        await cargarEntendimiento();   // M4: carga si ya se analizó
    });
    cablearEntendimiento();
    cablearVisorPrompt();
    cablearEstandares();
    $("#cerrar-upload").addEventListener("click", () => mostrarVista("vista-vacia"));

    $("#btn-prevuelo").addEventListener("click", ejecutarPrevuelo);
    $("#btn-dominio-rag").addEventListener("click", abrirDominioRag);
    cablearCrearDominio();
    $("#btn-skills").addEventListener("click", abrirSkills);
    $("#skills-form").addEventListener("submit", agregarSkillCustom);

    // Cierre genérico de paneles con data-cerrar-panel.
    for (const btn of $$("[data-cerrar-panel]")) {
        btn.addEventListener("click", () => mostrarVista("vista-vacia"));
    }
}

// ── Login / Mis Modelos (v2 fase 1) ──────────────────────────────────

function loginError(msg) {
    const cont = $("#login-error");
    cont.hidden = false;
    cont.textContent = msg;
}

async function submitLogin(ev) {
    ev.preventDefault();
    $("#login-error").hidden = true;
    const codigo = $("#login-codigo").value.trim();
    const nombre = $("#login-nombre").value.trim();
    if (!codigo || !nombre) { loginError("Faltan campos."); return; }
    try {
        const r = await pedirJSON("/api/auth/login", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify({ codigo, nombre }),
        });
        estado.validador = r.validador;
        await entrarAModelos();
    } catch (err) {
        loginError(err.message);
    }
}

async function cerrarSesion() {
    try { await pedirJSON("/api/auth/logout", { method: "POST" }); } catch {}
    estado.validador = null;
    estado.modelo    = null;
    mostrarPantalla("pantalla-login");
    $("#login-codigo").value = "";
    $("#login-nombre").value = "";
}

function estadoChip(estado) {
    if (estado === "completado") return `<span class="chip chip--completado">Completado</span>`;
    if (estado === "en_progreso") return `<span class="chip chip--en-progreso">En progreso</span>`;
    return `<span class="chip chip--sin-iniciar">Sin iniciar</span>`;
}

function fmtFecha(iso) {
    if (!iso) return "—";
    return iso.slice(0, 10);   // YYYY-MM-DD
}

function pintarListaModelos(modelos) {
    const cont = $("#modelos-lista");
    if (!modelos.length) {
        cont.innerHTML = `<div class="empty-state">
            <div class="empty-state__title">No tienes modelos todavía.</div>
            <div class="empty-state__hint">Pulsa <strong>+ Nuevo modelo</strong> para crear el primero.</div>
        </div>`;
        return;
    }
    let html = `<table class="tabla-modelos">
        <thead><tr>
            <th>Modelo</th><th>Dominio</th><th>Tier</th><th>Estado</th><th>Última actividad</th>
        </tr></thead><tbody>`;
    for (const m of modelos) {
        html += `<tr data-slug="${escapeHtml(m.slug)}">
            <td><strong>${escapeHtml(m.nombre)}</strong>
                <div class="tam">${escapeHtml(m.slug)}</div></td>
            <td>${escapeHtml(m.dominio || "—")}</td>
            <td>${escapeHtml(m.tier || "—")}</td>
            <td>${estadoChip(m.estado)}</td>
            <td>${escapeHtml(fmtFecha(m.ultima_actividad_utc))}</td>
        </tr>`;
    }
    html += `</tbody></table>`;
    cont.innerHTML = html;
    for (const tr of cont.querySelectorAll("tr[data-slug]")) {
        tr.addEventListener("click", () => entrarAlDashboard(tr.dataset.slug));
    }
}

async function entrarAModelos() {
    if (!estado.validador) {
        try {
            const r = await pedirJSON("/api/auth/actual");
            estado.validador = r.validador;
        } catch {
            mostrarPantalla("pantalla-login");
            return;
        }
    }
    $("#bienvenida").textContent =
        `Bienvenido, ${estado.validador.nombre} (${estado.validador.codigo})`;
    mostrarPantalla("pantalla-modelos");
    try {
        const r = await pedirJSON("/api/modelos");
        pintarListaModelos(r.modelos || []);
    } catch (err) {
        $("#modelos-lista").innerHTML =
            `<div class="verificacion is-error">${escapeHtml(err.message)}</div>`;
    }
}

async function abrirModalNuevoModelo() {
    $("#modal-nuevo-modelo").hidden = false;
    $("#nm-error").hidden = true;
    $("#nm-nombre").value = "";
    await cargarDominiosEnSelectorModelo();
    $("#nm-nombre").focus();
}

async function cargarDominiosEnSelectorModelo() {
    // Necesita sesión de login (la lista es global). Si falla, dejamos los
    // 3 fijos por defecto que ya trae el HTML.
    const sel = $("#nm-dominio");
    if (!sel) return;
    try {
        const r = await pedirJSON("/api/rag/dominios");
        const fijos  = (r.dominios || []).filter(d => d.tipo === "fijo" && d.dominio !== "shared");
        const custom = (r.dominios || []).filter(d => d.tipo === "custom");
        let html = "";
        for (const d of fijos) {
            html += `<option value="${escapeHtml(d.dominio)}">${escapeHtml(d.nombre || d.dominio)}</option>`;
        }
        if (custom.length) {
            html += `<option disabled>── dominios personalizados ──</option>`;
            for (const d of custom) {
                html += `<option value="${escapeHtml(d.dominio)}">${escapeHtml(d.nombre)} · custom</option>`;
            }
        }
        html += `<option value="__CREAR__">+ Crear nuevo dominio…</option>`;
        sel.innerHTML = html;
    } catch (err) {
        console.warn("No pude cargar dominios en el selector:", err.message);
    }
}
function cerrarModalNuevoModelo() {
    $("#modal-nuevo-modelo").hidden = true;
}

async function submitNuevoModelo(ev) {
    ev.preventDefault();
    const dominioSel = $("#nm-dominio").value;
    // Redirige al panel Dominio & RAG si el usuario elige "+ Crear nuevo dominio…"
    if (dominioSel === "__CREAR__") {
        cerrarModalNuevoModelo();
        // El panel RAG solo es accesible desde el dashboard con modelo activo.
        // Si estamos en Mis Modelos sin dashboard, informamos.
        alert("Para crear un dominio, entra en un modelo existente y abre Dominio & RAG.\n\nO crea primero un modelo con dominio 'shared' y edita luego.");
        return;
    }
    const body = {
        nombre:  $("#nm-nombre").value.trim(),
        dominio: dominioSel,
        tier:    $("#nm-tier").value,
    };
    if (!body.nombre) { $("#nm-error").hidden = false; $("#nm-error").textContent = "Nombre requerido."; return; }
    try {
        const r = await pedirJSON("/api/modelos", {
            method:  "POST",
            headers: { "Content-Type": "application/json" },
            body:    JSON.stringify(body),
        });
        cerrarModalNuevoModelo();
        // Refresca lista y entra directo al modelo recién creado.
        await entrarAModelos();
        await entrarAlDashboard(r.modelo.slug);
    } catch (err) {
        $("#nm-error").hidden = false;
        $("#nm-error").textContent = err.message;
    }
}

async function entrarAlDashboard(slug) {
    try {
        const r = await pedirJSON(`/api/modelos/${encodeURIComponent(slug)}/activar`, {
            method: "POST",
        });
        estado.modelo = r.modelo;
        pintarContextoSidebar();
        mostrarPantalla("pantalla-dashboard");
        mostrarVista("vista-vacia");
    } catch (err) {
        alert("No se pudo activar el modelo: " + err.message);
    }
}

function pintarContextoSidebar() {
    if (estado.validador) {
        $("#sidebar-validador").textContent =
            `👤 ${estado.validador.nombre} · ${estado.validador.codigo}`;
    }
    if (estado.modelo) {
        $("#sidebar-modelo").textContent =
            `📋 ${estado.modelo.nombre} · ${estado.modelo.dominio} · T${estado.modelo.tier}`;
        // Sincroniza también el topbar del dashboard con el modelo activo.
        $("#modelo-actual").textContent = `${estado.modelo.nombre} (Tier ${estado.modelo.tier})`;
        $("#dominio-actual").textContent = estado.modelo.dominio;
        estado.dominio = estado.modelo.dominio;
        for (const b of $$(".toggle-btn[data-dominio]")) {
            b.setAttribute("aria-pressed",
                b.dataset.dominio === estado.modelo.dominio ? "true" : "false");
        }
    }
}

async function volverAMisModelos() {
    try { await pedirJSON("/api/modelos/desactivar", { method: "POST" }); } catch {}
    estado.modelo = null;
    await entrarAModelos();
}

function cablearAuth() {
    $("#login-form").addEventListener("submit", submitLogin);
    $("#btn-cerrar-sesion").addEventListener("click", cerrarSesion);
    $("#btn-nuevo-modelo").addEventListener("click", abrirModalNuevoModelo);
    $("#form-nuevo-modelo").addEventListener("submit", submitNuevoModelo);
    for (const el of $$("[data-close-modal-nm]")) {
        el.addEventListener("click", cerrarModalNuevoModelo);
    }
    $("#btn-volver-modelos").addEventListener("click", volverAMisModelos);
}

// ── Arranque ─────────────────────────────────────────────────────────

async function arrancar() {
    // Cablea TODO una sola vez; el intercambio de pantalla lo controla
    // `mostrarPantalla`.
    cablearAuth();
    cablearNav();
    cablearDropzone();
    cablearDominio();
    cablearConfig();
    cablearValidacion();
    cablearResultados();
    cablearChat();
    cablearCuestionamientos();
    cablearDocumentar();

    // Decide la pantalla inicial según estado de sesión (login vs modelos vs dashboard).
    try {
        const r = await pedirJSON("/api/auth/actual");
        estado.validador = r.validador;
    } catch {
        mostrarPantalla("pantalla-login");
        return;
    }

    // Hay login. ¿Hay modelo activo?
    try {
        const r = await pedirJSON("/api/modelos/activo");
        if (r.modelo) {
            estado.modelo = r.modelo;
            pintarContextoSidebar();
            mostrarPantalla("pantalla-dashboard");
            mostrarVista("vista-vacia");
            return;
        }
    } catch {}
    await entrarAModelos();
}

window.addEventListener("DOMContentLoaded", () => {
    console.log("VIRF Web listo — v2 fase 1 (login + Mis Modelos)");
    fetch("/api/salud").then(r => r.json()).then(d => console.log("Backend:", d));
    arrancar();
});
