"""
VIRF Web — capa web sobre el agente CLI.

El paso 3 introduce la primera dependencia real del agente
(`config.ia.prueba_de_humo`), así que aquí se hace el sys.path.insert
que las capas superiores necesitarán a partir de ahora.
"""
import sys
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

WEB_DIR = Path(__file__).resolve().parent
PROYECTO_DIR = WEB_DIR.parent
# Los módulos del agente hacen imports como `from Mx_00_CargaRutas import …`
# sin prefijo `motor.`. Necesitan la raíz Y la carpeta motor/ en sys.path,
# igual que hace `scripts/rebuild_rag_databricks.py`.
for _p in (PROYECTO_DIR, PROYECTO_DIR / "motor"):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from .routers import upload as upload_router  # noqa: E402
from .routers import config as config_router  # noqa: E402
from .routers import dominio_prevuelo as dp_router  # noqa: E402
from .routers import validacion as validacion_router  # noqa: E402
from .routers import resultados as resultados_router  # noqa: E402
from .routers import controles as controles_router  # noqa: E402
from .routers import chat as chat_router  # noqa: E402
from .routers import cuestionamientos as cuest_router  # noqa: E402
from .routers import informe as informe_router  # noqa: E402
from .routers import auth as auth_router  # noqa: E402
from .routers import modelos as modelos_router  # noqa: E402
from .routers import rag as rag_router  # noqa: E402
from .routers import entendimiento as entendimiento_router  # noqa: E402
from .routers import preview_prompt as preview_router  # noqa: E402
from .routers import debug_conexiones as debug_router  # noqa: E402
from .routers import skills as skills_router  # noqa: E402
from .routers import cuestionamientos_sesion as cuest_sesion_router  # noqa: E402
from .routers import prompts as prompts_router  # noqa: E402
from .routers import estandares as estandares_router  # noqa: E402

TEMPLATES_DIR = WEB_DIR / "templates"
STATIC_DIR = WEB_DIR / "static"

app = FastAPI(title="VIRF Web", version="2.0")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.include_router(auth_router.router)
app.include_router(modelos_router.router)
app.include_router(rag_router.router)
app.include_router(entendimiento_router.router)
app.include_router(preview_router.router)
app.include_router(prompts_router.router)
app.include_router(estandares_router.router)
app.include_router(debug_router.router)
app.include_router(skills_router.router)
app.include_router(cuest_sesion_router.router)
app.include_router(upload_router.router)
app.include_router(config_router.router)
app.include_router(dp_router.router)
app.include_router(validacion_router.router)
app.include_router(resultados_router.router)
app.include_router(controles_router.router)
app.include_router(chat_router.router)
app.include_router(cuest_router.router)
app.include_router(informe_router.router)


@app.get("/", include_in_schema=False)
def index() -> FileResponse:
    return FileResponse(TEMPLATES_DIR / "index.html")


@app.get("/api/salud")
def salud() -> dict:
    return {"estado": "ok", "version": "2.0"}
