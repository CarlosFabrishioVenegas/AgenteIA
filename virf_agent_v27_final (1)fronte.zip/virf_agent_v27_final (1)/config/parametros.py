"""
config/parametros.py  [v27.2]
═════════════════════════════════════════════════════════════════════════════
ÚNICA FUENTE DE VERDAD DE TODOS LOS PARÁMETROS AJUSTABLES DEL PROYECTO.

Si un valor se puede tocar con una variable de entorno, se declara AQUÍ y solo
aquí. Ningún otro módulo debe volver a llamar a `os.getenv` para un parámetro
de negocio: debe importarlo de este fichero.

POR QUÉ EXISTE
--------------
Antes de v27.2 la configuración estaba repartida y, en varios casos,
DUPLICADA con defaults independientes:

    VIRF_CHUNK_SIZE / _OVERLAP / _THRESHOLD  → chunker.py  Y  Mx_01
    MAX_CHARS_DOC / _CODIGO / MAX_FILAS_EXCEL → config.py  Y  Mx_00
    VIRF_MAX_CTX                              → agente.py  Y  chunker.py
                                                (¡con defaults distintos!)

La duplicación era tan conocida que `validate_project.py` tenía —y sigue
teniendo— un check dedicado a detectar que config.py y Mx_00 no divergieran.
Ese check ahora es una red de seguridad, no la única defensa: con una sola
declaración por parámetro, la divergencia deja de ser posible por construcción.

CONVENCIÓN
----------
  · Un parámetro = una línea = un `os.getenv`.
  · El default vive aquí, no en el punto de uso.
  · Los módulos siguen exponiendo sus nombres privados históricos
    (`_CHUNK_SIZE`, `_MAX_CHUNKS`…) como alias, para no romper tests ni el
    validador, pero su VALOR viene de aquí.
"""

from __future__ import annotations

import os

from dotenv import load_dotenv

# Debe ejecutarse ANTES del primer os.getenv de todo el proyecto.
load_dotenv()


# ── Lectura tipada y tolerante del entorno ───────────────────────────────────
# [AUDIT-FIX] Antes cada parámetro hacía `int(os.getenv(...))` a pelo. Un typo
# en .env —MAX_CHARS_DOC=abc, o un "12.000" con separador de miles— reventaba
# el ARRANQUE con un `ValueError: invalid literal for int()` y un traceback
# crudo dentro de un import, antes de que el agente imprimiera nada. El usuario
# veía un fallo del programa, no un error de su configuración.
#
# Ahora un valor inválido avisa por qué y con qué se sigue, en vez de tumbar
# la corrida: un .env mal escrito no debe impedir validar un modelo.

def _num_env(nombre: str, defecto, conv, minimo=None, maximo=None):
    """Lee `nombre` del entorno con `conv`; ante valor inválido usa `defecto`."""
    crudo = os.getenv(nombre)
    if crudo is None or str(crudo).strip() == "":
        return defecto
    try:
        valor = conv(str(crudo).strip())
    except (TypeError, ValueError):
        print(f"  ⚠️  {nombre}='{crudo}' no es un número válido en .env — "
              f"se usa el valor por defecto ({defecto}).")
        return defecto
    if minimo is not None and valor < minimo:
        print(f"  ⚠️  {nombre}={valor} está por debajo del mínimo admitido "
              f"({minimo}) — se usa {defecto}.")
        return defecto
    # [AUDIT-FIX] Faltaba el tope. RAG_MIN_SCORE es una similitud en [0,1]:
    # un 5 no es "más estricto", filtra TODOS los chunks y deja el RAG mudo
    # sin un solo aviso.
    if maximo is not None and valor > maximo:
        print(f"  ⚠️  {nombre}={valor} supera el máximo admitido "
              f"({maximo}) — se usa {defecto}.")
        return defecto
    return valor


def _entero(nombre: str, defecto: int, minimo: int = 1) -> int:
    return _num_env(nombre, defecto, int, minimo)


def _decimal(nombre: str, defecto: float, minimo: float = 0.0,
             maximo: float = None) -> float:
    return _num_env(nombre, defecto, float, minimo, maximo)


def _booleano(nombre: str, defecto: bool = False) -> bool:
    crudo = os.getenv(nombre)
    if crudo is None:
        return defecto
    return str(crudo).strip().lower() in ("1", "true", "si", "sí", "yes", "on")

__all__ = [
    "IA_PROVEEDOR", "MODO", "AGENTE_VERSION",
    "MAX_CHARS_DOC", "MAX_CHARS_CODIGO", "MAX_FILAS_EXCEL",
    "TIMEOUT_SEGUNDOS", "REINTENTOS_API",
    "ANTHROPIC_MODELO", "ANTHROPIC_MAX_TOKENS", "VALIDAR_CONEXION",
    "AZURE_API_VERSION", "AZURE_MAX_TOKENS",
    "CA_BUNDLE", "HTTP_TIMEOUT", "TLS_INSECURE",
    "PROHIBIR_MODELOS_EXTERNOS",
    "MAX_CTX", "MAX_DOCS_AMBITO",
    "CHUNK_SIZE", "CHUNK_OVERLAP", "CHUNK_THRESHOLD", "MAX_CHUNKS",
    "CHUNK_SIZE_MAX", "MAX_NIVELES", "PRESUPUESTO_DOC", "CHUNK_ENABLED",
    "MAX_CTX_SKILLS", "RAG_TOP_K_SKILLS", "INTENTOS_CONTRATO",
    "CACHE_ENABLED", "CACHE_LOCK_TIMEOUT", "CACHE_LOCK_STALE",
    "EXCEL_MAX_CELDAS_MUESTRA", "EXCEL_MAX_FORMULAS_HOJA",
    "EXCEL_CHUNK_HOJA_UMBRAL", "EXCEL_VALIDACION_TOL", "EXCEL_NB_TIMEOUT",
    "DEBUG_PROMPTS", "MIN_FEEDBACK_ANTISESGO", "MIN_MUESTRAS_AJUSTE",
    "RAG_TOP_K", "RAG_MIN_SCORE", "RAG_MIN_COBERTURA",
    "RAG_PESO_INFORMATIVO_MINIMO",
    "RAG_INDICE_DIR", "RAG_PESO_BM25", "RAG_PESO_TFIDF",
    "RAG_BM25_K1", "RAG_BM25_B", "RAG_TFIDF_NGRAM_MAX", "RAG_TFIDF_MIN_DF",
    "RAG_CHUNK_SIZE", "RAG_CHUNK_OVERLAP", "RAG_STEMMING",
    "RAG_LONGITUD_MINIMA_TOKEN",
    "RAG_TESAURO", "RAG_CORREGIR_ERRATAS", "RAG_UMBRAL_ERRATA",
    "VALIDADOR_NOMBRE", "VALIDADOR_CARGO", "UMBRAL_SIN_SEGUNDA_REVISION",
    "identidad_validador_entorno",
    "tiers_doble_firma", "identidad_segundo_validador_entorno",
]


# ═════════════════════════════════════════════════════════════════════════════
# 1. GENERALES
# ═════════════════════════════════════════════════════════════════════════════

# ── [POLÍTICA DE PROVEEDOR] ──────────────────────────────────────────────────
# Azure OpenAI es el proveedor PRIORITARIO por decisión de la entidad.
#
# El DEFAULT vive aquí, en el código, y NO en el .env: si mañana alguien clona
# el proyecto y olvida definir IA_PROVEEDOR, la corrida debe salir por Azure —
# no por el proveedor secundario. Depender de que el operador recuerde poner una
# variable es depender de que no se equivoque, y la política no admite eso.
#
# Anthropic sigue disponible como SECUNDARIO: IA_PROVEEDOR=anthropic.
# NO hay fallback automático entre proveedores (ver config/ia.py:get_cliente_ia).
IA_PROVEEDOR = os.getenv("IA_PROVEEDOR", "azure_openai").lower()   # azure_openai|anthropic
MODO = os.getenv("MODO", "debug").lower()                       # debug|produccion
# Viaja al JSON de auditoría: debe reflejar la versión REAL del evaluador.
# Se mantiene en 27.1 deliberadamente — subirla es una decisión del proyecto,
# no un efecto colateral de reorganizar la configuración.
AGENTE_VERSION = os.getenv("VIRF_AGENTE_VERSION", "27.1")

TIMEOUT_SEGUNDOS = _entero("TIMEOUT_SEGUNDOS", 30)
REINTENTOS_API = _entero("REINTENTOS_API", 3)


# ═════════════════════════════════════════════════════════════════════════════
# 2. LECTURA DE DOCUMENTOS
#    Antes duplicados entre config.py y Mx_00_CargaRutas.
# ═════════════════════════════════════════════════════════════════════════════

MAX_CHARS_DOC = _entero("MAX_CHARS_DOC", 15000)
MAX_CHARS_CODIGO = _entero("MAX_CHARS_CODIGO", 8000)
MAX_FILAS_EXCEL = _entero("MAX_FILAS_EXCEL", 200)

# Contexto máximo que se le pasa al modelo por llamada.
# [UNIFICACIÓN v27.2] agente.py usaba default MAX_CHARS_DOC y chunker.py el
# literal "15000". Coincidían por casualidad: al tocar MAX_CHARS_DOC dejaban de
# hacerlo, y el chunker calculaba su presupuesto contra un valor obsoleto.
MAX_CTX = _entero("VIRF_MAX_CTX", MAX_CHARS_DOC)

# 0 = sin límite de documentos por ámbito. `minimo=0` es deliberado: 0 es un
# valor VÁLIDO aquí, no un error de configuración.
MAX_DOCS_AMBITO = _entero("VIRF_MAX_DOCS_AMBITO", 0, minimo=0)


# ═════════════════════════════════════════════════════════════════════════════
# 3. PROVEEDOR IA
# ═════════════════════════════════════════════════════════════════════════════

ANTHROPIC_MODELO = os.getenv("ANTHROPIC_MODELO", "claude-sonnet-4-6")
ANTHROPIC_MAX_TOKENS = _entero("ANTHROPIC_MAX_TOKENS", 4096)

# Gasta 1 request de prueba al arrancar. Desactivado por defecto: un fallo de
# credenciales se manifiesta igual en la primera llamada real.
VALIDAR_CONEXION = _booleano("VIRF_VALIDAR_CONEXION", False)

# GA estable. Una versión 'preview' puede cambiar de comportamiento sin aviso,
# y este sistema exige corridas reproducibles (METODOLOGIA_DEL_AGENTE.md §11.5):
# dos corridas sobre la misma evidencia deben dar el mismo resultado.
AZURE_API_VERSION = os.getenv("AZURE_OPENAI_API_VERSION", "2024-10-21")
AZURE_MAX_TOKENS = _entero("AZURE_OPENAI_MAX_TOKENS", 4096)


# ═════════════════════════════════════════════════════════════════════════════
# 4. CHUNKING DE DOCUMENTOS LARGOS
#    Antes duplicados entre modulos/chunker.py y motor/Mx_01_LecturaEvidencias.
# ═════════════════════════════════════════════════════════════════════════════

# Tamaño INICIAL del segmento. El modo adaptativo puede subirlo hasta
# CHUNK_SIZE_MAX, así que no es el tamaño real en documentos grandes.
CHUNK_SIZE = _entero("VIRF_CHUNK_SIZE", 12000)
CHUNK_OVERLAP = _entero("VIRF_CHUNK_OVERLAP", 800)
CHUNK_THRESHOLD = _entero("VIRF_CHUNK_THRESHOLD", CHUNK_SIZE)

# [COSTE-FIX D2] 40 en vez de 60: medido sobre un PDF real de 305 páginas,
# 40 segmentos cuestan $1,14 y 60 cuestan $1,45, con idéntica cobertura (100%).
#
# ⚠️ NO bajar de ~34 sin subir CHUNK_SIZE_MAX: por debajo de ese punto el
# segmento adaptativo necesario supera el tope, el chunker cae al modo
# jerárquico puro y el coste SUBE ($2,27 con 30). Ver README §3.4.1.
MAX_CHUNKS = _entero("VIRF_MAX_CHUNKS", 40)

# Techo del segmento adaptativo. Subirlo permite bajar MAX_CHUNKS sin penalizar.
CHUNK_SIZE_MAX = _entero("VIRF_CHUNK_SIZE_MAX", 40000)

# Tope de niveles de consolidación jerárquica (evita bucle si el modelo no
# comprime lo suficiente).
MAX_NIVELES = _entero("VIRF_MAX_NIVELES", 3)

# Presupuesto de chars que los resúmenes de UN documento pueden ocupar en el
# prompt de evaluación. Fracción de MAX_CTX para que un ámbito con varios
# documentos largos siga cabiendo.
PRESUPUESTO_DOC = _entero("VIRF_PRESUPUESTO_DOC", int(MAX_CTX * 0.6))

CHUNK_ENABLED = _booleano("VIRF_CHUNK_ENABLED", True)


# ── [AUDIT-FIX] Presupuesto propio para las SKILLS ───────────────────────────
# Las skills leen TODA la evidencia de una vez —su pregunta es transversal al
# modelo, no a un control—, mientras que el pipeline lee un ámbito por llamada.
# Compartir `MAX_CTX` con el pipeline era el origen del defecto: MAX_CHARS_DOC
# (tope POR documento) y MAX_CTX (tope de TODO el contexto) valían ambos 15.000,
# así que un solo manual agotaba el presupuesto y el resto de la evidencia
# desaparecía en silencio. Medido: 6 de 8 documentos perdidos enteros, incluida
# la implementación — y la skill de coherencia, que existe para comparar manual
# contra código, nunca veía el código.
#
# Default: 4× MAX_CTX. Es un compromiso deliberado. Más alto haría que cada
# skill costara varias veces lo que cuesta un ámbito completo (son 8 skills con
# `--skills all`); más bajo reproduce el defecto. Quien tenga ventana de sobra
# lo sube y gana cobertura: ahora el informe le dice exactamente cuánta.
MAX_CTX_SKILLS = _entero("VIRF_MAX_CTX_SKILLS", MAX_CTX * 4, minimo=1000)

# Fragmentos RAG para el bloque regulatorio de las skills. Más que en una
# actividad (RAG_TOP_K) porque aquí la consulta es una sola para todo el
# análisis, no una por control: el bloque se paga una vez.
RAG_TOP_K_SKILLS = _entero("VIRF_RAG_TOP_K_SKILLS", 8, minimo=1)

# ── [AUDIT-FIX] Reintento ante respuesta que no cumple el contrato ───────────
# Intentos TOTALES para obtener una evaluación con el formato pactado.
# 2 = el original más un reintento.
#
# Existe porque un JSON truncado perdía la actividad para siempre:
# `REINTENTOS_API` cubre errores de RED, no violaciones de contrato. Medido en
# la corrida real de VaR Mercado FRTB: 1 de 34 actividades perdida por un corte
# de generación en el carácter 8.064, y con ella `dictamen_confiable` a false.
#
# Se queda en 2 a propósito: un fallo de formato es estocástico y suele
# resolverse al repetir la misma pregunta. Si falla dos veces seguidas sobre el
# mismo prompt, el problema no es el azar y reintentar más solo multiplica el
# gasto. Subirlo es una decisión del operador, no un default.
INTENTOS_CONTRATO = _entero("VIRF_INTENTOS_CONTRATO", 2, minimo=1)


# ═════════════════════════════════════════════════════════════════════════════
# 5. CACHÉ
# ═════════════════════════════════════════════════════════════════════════════

CACHE_ENABLED = _booleano("CACHE_ENABLED", True)
CACHE_LOCK_TIMEOUT = _entero("VIRF_CACHE_LOCK_TIMEOUT", 10)   # segundos
CACHE_LOCK_STALE = _entero("VIRF_CACHE_LOCK_STALE", 60)       # segundos


# ═════════════════════════════════════════════════════════════════════════════
# 6. EXCEL → NOTEBOOK
# ═════════════════════════════════════════════════════════════════════════════

EXCEL_MAX_CELDAS_MUESTRA = _entero("EXCEL_MAX_CELDAS_MUESTRA", 500)
EXCEL_MAX_FORMULAS_HOJA = _entero("EXCEL_MAX_FORMULAS_HOJA", 2000)
EXCEL_CHUNK_HOJA_UMBRAL = _entero("EXCEL_CHUNK_HOJA_UMBRAL", 80)
EXCEL_VALIDACION_TOL = _decimal("EXCEL_VALIDACION_TOL", 1e-6)
EXCEL_NB_TIMEOUT = _entero("EXCEL_NB_TIMEOUT", 120)


# ═════════════════════════════════════════════════════════════════════════════
# 7. DIAGNÓSTICO Y FEEDBACK
# ═════════════════════════════════════════════════════════════════════════════

DEBUG_PROMPTS = _booleano("DEBUG_PROMPTS", False)

# Masa crítica exigida antes de dejar que el feedback histórico altere el
# criterio del agente (D6-FIX). Gobierna el bloque de calibración del prompt.
MIN_FEEDBACK_ANTISESGO = _entero("VIRF_MIN_FEEDBACK_ANTISESGO", 15)

# [AUDIT-FIX] Umbral del ajuste numérico POST-HOC del puntaje.
#
# Había dos guardias anti-sesgo descoordinadas y solo una era visible:
#   · bloque del prompt      → MIN_FEEDBACK_ANTISESGO (15, configurable)
#   · ajuste numérico directo→ MIN_MUESTRAS = 3, HARDCODEADO en
#                              feedback_mejorado.ajustar_puntaje_por_feedback
#
# Medido: con 3 muestras de diferencia +2, un puntaje 2.0 pasaba a 2.8, que
# redondea a 3 — un punto entero sobre una escala de 5. Y quien subiera
# VIRF_MIN_FEEDBACK_ANTISESGO a 30 creyendo endurecer el sistema seguía
# teniendo ese ajuste disparándose con 3 muestras.
#
# La intervención MÁS directa sobre el dictamen no puede tener el guardia MÁS
# débil, así que por defecto hereda el mismo umbral. Se deja como variable
# propia porque su conteo es por ACTIVIDAD similar (más estrecho que el conteo
# por ámbito del bloque del prompt), y puede querer relajarse a conciencia.
MIN_MUESTRAS_AJUSTE = _entero("VIRF_MIN_MUESTRAS_AJUSTE", MIN_FEEDBACK_ANTISESGO)


# ═════════════════════════════════════════════════════════════════════════════
# EMBEDDINGS DEL RAG — NO EXISTEN. El RAG es LÉXICO.
# ═════════════════════════════════════════════════════════════════════════════
# [ARQUITECTURA 2026-07-31] Aquí vivían `EMBEDDINGS_PROVEEDOR` y
# `AZURE_EMBEDDINGS_DEPLOYMENT`. Se eliminaron junto con `config/embeddings.py`
# y con ChromaDB. Dos motivos, cada uno suficiente por sí solo:
#
#   1. No hay deployment de embeddings, ni lo va a haber. El recurso Azure de la
#      entidad tiene UNO, de chat. `AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT` no se
#      podía rellenar con nada, así que el RAG llevaba tiempo instalado,
#      documentado y APAGADO: fallaba al pedir la función de embeddings, el
#      retriever capturaba la excepción y devolvía [], y la validación seguía
#      sin contexto. Un mando de configuración que no se puede accionar es peor
#      que no ofrecerlo.
#
#      Y no hay atajo: el deployment de chat NO genera embeddings. Pedirle
#      vectores a /chat/completions no está soportado por el modelo.
#
#   2. ChromaDB arrastraba HuggingFace por dependencia transitiva
#      (`chromadb → tokenizers → huggingface-hub`). La política de «cero
#      modelos externos» se cumplía en el código y se incumplía en el árbol de
#      dependencias.
#
# El RAG ahora recupera con BM25 + TF-IDF sobre índices locales — ver
# `src/rag/config_rag.py`, que es donde viven sus parámetros. RAG_TOP_K y
# RAG_MIN_SCORE siguen aquí abajo porque son los que toca el operador.

# Guardia de política. Ya no gobierna ninguna rama de código —no queda ninguna—
# pero se conserva porque `validate_project.py` y los tests la usan para
# verificar que no reaparece una dependencia de modelos externos.
PROHIBIR_MODELOS_EXTERNOS = _booleano("VIRF_PROHIBIR_MODELOS_EXTERNOS", True)


# ═════════════════════════════════════════════════════════════════════════════
# RED CORPORATIVA — proxy e inspección TLS
# ═════════════════════════════════════════════════════════════════════════════
# El SDK de OpenAI usa `httpx`, y httpx verifica los certificados contra el
# bundle de **certifi**, NO contra el almacén de certificados de Windows.
#
# Consecuencia práctica en una entidad financiera: si el proxy corporativo hace
# inspección TLS —descifra y vuelve a cifrar el tráfico firmando con una CA
# propia—, el navegador funciona (confía en esa CA porque está en el almacén de
# Windows) pero Python falla con `CERTIFICATE_VERIFY_FAILED`. El síntoma
# desconcierta: «la URL abre en el navegador pero el agente no conecta».
#
# `HTTPS_PROXY` / `HTTP_PROXY` / `NO_PROXY` los respeta httpx solo, sin código.
# Lo que NO se resuelve solo es la CA: hay que apuntarla explícitamente.
CA_BUNDLE = os.getenv("VIRF_CA_BUNDLE", "").strip()

# Timeout de la petición HTTP. Un proxy corporativo añade latencia, y el default
# del SDK puede quedarse corto con prompts grandes.
HTTP_TIMEOUT = _entero("VIRF_HTTP_TIMEOUT", 120)

# ⚠️ SALIDA DE EMERGENCIA — SOLO PARA DIAGNÓSTICO
# Desactiva la verificación TLS. Sirve para responder en 10 segundos a «¿es el
# certificado o es otra cosa?», que de otro modo cuesta media mañana.
#
# NUNCA en una corrida real: sin verificación, el tráfico —que lleva la
# evidencia íntegra del modelo y la credencial— es interceptable. El código lo
# rechaza en modo --prdc y grita en cualquier otro caso.
TLS_INSECURE = _booleano("VIRF_TLS_INSECURE", False)


# ═════════════════════════════════════════════════════════════════════════════
# REVISIÓN DE CÓDIGO (modulos/revision_codigo.py)
# ═════════════════════════════════════════════════════════════════════════════

# Chars de UN módulo que caben en una sola llamada. Por encima, el módulo se
# parte en bloques que empiezan en un `def`/`class` —nunca a media función— y se
# hacen varias llamadas para ese fichero. 120.000 chars ≈ 50.000 tokens: cabe
# con el manual dentro en cualquier modelo del catálogo con ≥128.000 tokens de
# ventana (ver config/modelos.py). Con un modelo de contexto pequeño, bájalo.
MAX_CHARS_MODULO = _entero("VIRF_MAX_CHARS_MODULO", 120_000)

# Recorte del manual metodológico que viaja como contexto FIJO en cada llamada.
# Es el multiplicador del coste: con 30 módulos, cada char del manual se paga 30
# veces. Subirlo mejora el contraste y encarece la corrida de forma lineal.
MAX_CHARS_MANUAL_REVISION = _entero("VIRF_MAX_CHARS_MANUAL_REVISION", 24_000)

# Excluir site-packages/, .venv/, node_modules/… del árbol de código revisado.
# DESACTIVADO por defecto por decisión explícita del operador: descartar
# ficheros en silencio es peor que revisarlos de más, y el inventario previo
# (que se imprime siempre) ya declara cuántas llamadas van a ocurrir. Actívalo
# si copias a inputs/implementacion/ un árbol que arrastra su entorno virtual.
EXCLUIR_DEPENDENCIAS = _booleano("VIRF_EXCLUIR_DEPENDENCIAS", False)


# ═════════════════════════════════════════════════════════════════════════════
# RAG
# ═════════════════════════════════════════════════════════════════════════════
# [AUDIT-FIX] `.env.example` documentaba RAG_TOP_K=3 y RAG_MIN_SCORE=0.35 desde
# hacía tiempo, pero NADIE las leía: los valores vivían hardcodeados como
# defaults en las firmas de motor_ia.evaluar_actividad() y
# evaluar_ambito_completo(). Coincidían por casualidad con lo documentado, así
# que el usuario que los tocaba en su .env no obtenía ningún efecto y tampoco
# ningún aviso. Un mando de configuración que no está conectado a nada es peor
# que no ofrecerlo: promete un control que no existe.
# [2026-07-31] Sube de 3 a 6 al pasar al RAG léxico. Es un CAMBIO DE
# COMPORTAMIENTO deliberado, no un efecto colateral: con el RAG vectorial cada
# chunk era de 1000 caracteres y la similitud coseno concentraba lo relevante en
# los primeros puestos, así que 3 bastaba. La recuperación léxica reparte la
# señal entre más fragmentos —un término puede estar en la definición, en el
# ejemplo y en la tabla— y con 3 se dejaba fuera contexto que sí venía al caso.
# Efecto en el prompt: hasta 6 × 1200 ≈ 7.200 caracteres de RAG, que caben
# holgadamente en el presupuesto de contexto.
RAG_TOP_K = _entero("RAG_TOP_K", 6, minimo=1)

# ── Los dos umbrales del RAG: uno RELATIVO y uno ABSOLUTO ────────────────────
# [ARQUITECTURA 2026-07-31, 2ª pasada] Hasta ahora había uno solo, RAG_MIN_SCORE,
# y hacía dos trabajos incompatibles. El `score` que filtraba se normaliza contra
# el máximo de CADA consulta —porque BM25 no tiene techo y hay que acotarlo para
# combinarlo con el coseno—, así que el mejor fragmento saca 1.00 SIEMPRE, aunque
# el corpus no cubra la pregunta.
#
# Consecuencia real, y es la que había que curar: el bloque inyectado al prompt
# anunciaba «relevancia léxica: 1.00» para el primer resultado de cualquier
# consulta. Ni el modelo ni un lector del informe podían distinguir «coincidencia
# excelente» de «el primero de una lista mala». Un umbral que no significa lo que
# parece es un defecto de diseño, no de redacción.
#
# Ahora cada número hace UN trabajo:

# ABSOLUTO. Fracción del peso informativo (Σ IDF) de la consulta que el fragmento
# cubre realmente. Comparable entre consultas: un 0.20 significa lo mismo aquí
# que en cualquier otra búsqueda. Es el corte de verdad, y se aplica ANTES de
# puntuar nada.
#
# El default es un SUELO, no un mando de precisión: descarta la cola claramente
# irrelevante sin recortar recall. Medido en este corpus, las fuentes correctas
# puntúan 0.47–1.00 y el ruido de otros documentos 0.20–0.26.
#
# ⚠️ Calibrado sobre documentos de apoyo de ~6 KB, no sobre los BCBS íntegros.
#    Conviene revisarlo con la literatura real.
RAG_MIN_COBERTURA = _decimal("RAG_MIN_COBERTURA", 0.15, minimo=0.0, maximo=1.0)

# RELATIVO. Recorta la cola de la lista ya ordenada: «quédate con lo que esté al
# menos al X% de lo mejor de ESTA consulta». Se conserva con su nombre y su
# default históricos porque ése siempre fue su efecto real.
RAG_MIN_SCORE = _decimal("RAG_MIN_SCORE", 0.35, minimo=0.0, maximo=1.0)

# Peso informativo mínimo (Σ IDF) para considerar que una CONSULTA discrimina
# algo contra el corpus. No filtra: AVISA.
#
# Es la pieza que faltaba. Medido en el índice de VaR: «estacionariedad EWMA»
# → 6.51 · «backtesting Kupiec» → 1.76 · «modelo» → 0.41 · términos de VaR
# preguntados al dominio LaR → 0.00.
#
# Que la consulta «modelo» cubra el 100% de todos los fragmentos NO es un fallo
# del cálculo: es cierto, y es inútil. Ningún reajuste del score de un fragmento
# arregla una consulta que no pregunta nada — lo que hay que hacer es decirlo.
# Por debajo de este umbral se registra un warning que nombra la causa.
RAG_PESO_INFORMATIVO_MINIMO = _decimal("RAG_PESO_INFORMATIVO_MINIMO", 0.8,
                                       minimo=0.0, maximo=100.0)

# ── RAG LÉXICO (BM25 + TF-IDF) ────────────────────────────────────────────────
# [ARQUITECTURA 2026-07-31] Estos parámetros nacieron en `src/rag/config_rag.py`,
# que los leía con `os.getenv` por su cuenta para que `src/` siguiera siendo
# utilizable suelto (el job de Databricks copia solo esa carpeta). Se traen aquí
# porque el invariante CONFIG-CENTRAL del proyecto es más importante que esa
# comodidad: un segundo sitio que llama a `os.getenv` es exactamente lo que
# permitía la divergencia que ese invariante existe para impedir.
#
# `src/rag/config_rag.py` sigue funcionando suelto: importa de aquí y, si no
# puede, cae a los MISMOS valores literales. Lo que pierde sin `config/` es la
# configurabilidad por entorno, no el funcionamiento.

# Dónde se persisten los índices. Carpeta DISTINTA de VECTORDB_DIR a propósito:
# aquella contiene bases ChromaDB con vectores que ya no significan nada, y
# mezclar los dos formatos en la misma ruta invita a que un índice viejo pase
# por nuevo.
RAG_INDICE_DIR = os.getenv("RAG_INDICE_DIR", "").strip()

# Combinación de las dos señales. BM25 manda porque premia la coincidencia
# EXACTA de terminología (Kupiec, HQLA, NSFR, IFRS 9), que es lo que discrimina
# en literatura regulatoria; TF-IDF/coseno entra como segunda opinión y penaliza
# al chunk que acierta un término raro por casualidad.
RAG_PESO_BM25 = _decimal("RAG_PESO_BM25", 0.7, minimo=0.0, maximo=1.0)
RAG_PESO_TFIDF = _decimal("RAG_PESO_TFIDF", 0.3, minimo=0.0, maximo=1.0)

# Parámetros canónicos de BM25 (Robertson; los mismos que trae Elasticsearch).
RAG_BM25_K1 = _decimal("RAG_BM25_K1", 1.5, minimo=0.0, maximo=10.0)
RAG_BM25_B = _decimal("RAG_BM25_B", 0.75, minimo=0.0, maximo=1.0)

# Bigramas activados: «value at risk» o «riesgo de mercado» solo existen como
# pareja. Con unigramas puros, «risk» es tan común en este corpus que no
# discrimina nada.
RAG_TFIDF_NGRAM_MAX = _entero("RAG_TFIDF_NGRAM_MAX", 2, minimo=1)
# min_df=1: el corpus son decenas o cientos de chunks, no millones. Descartar
# términos que aparecen en un solo chunk borraría justo los tecnicismos raros
# que son el motivo de usar búsqueda léxica en vez de semántica.
RAG_TFIDF_MIN_DF = _entero("RAG_TFIDF_MIN_DF", 1, minimo=1)

# Troceado del índice. Más pequeño que el del chunker de evidencia: aquí el
# chunk es la UNIDAD DE RESPUESTA que se inyecta al prompt, y 1200 caracteres es
# un párrafo largo — se entiende solo y seis de ellos no comen el presupuesto.
RAG_CHUNK_SIZE = _entero("RAG_CHUNK_SIZE", 1200, minimo=200)
RAG_CHUNK_OVERLAP = _entero("RAG_CHUNK_OVERLAP", 200, minimo=0)

# Stemming conservador (ver `src/rag/indexador_lexico._stem`): hace que
# «modelos»/«modelo» caigan en el mismo token sin tocar acrónimos.
RAG_STEMMING = _booleano("RAG_STEMMING", True)
# Tokens de 1 carácter no aportan; los de 2 SÍ (PD, LGD, EL, VaR en minúscula).
RAG_LONGITUD_MINIMA_TOKEN = _entero("RAG_LONGITUD_MINIMA_TOKEN", 2, minimo=1)

# ── Expansión de consulta: las dos curas del punto ciego léxico ──────────────
# BM25 encuentra por coincidencia de cadena, así que no une «excepciones» con
# «excedencias» aunque sean sinónimos exactos en backtesting. Dos remedios,
# ambos locales y ambos aplicados a la CONSULTA (no obligan a reindexar):
#
#   1. TESAURO de dominio (src/rag/tesauro.py). Lista escrita por un experto y
#      auditable — que es su ventaja sobre cualquier modelo: un validador puede
#      leerla entera y discutir una equivalencia.
#   2. CORRECCIÓN de erratas por parecido ortográfico, solo para términos que no
#      existen en el corpus. Resuelve las erratas del propio estándar
#      («seguimeinto» → «seguimiento»), que de otro modo no casan nunca.
RAG_TESAURO = _booleano("RAG_TESAURO", True)
RAG_CORREGIR_ERRATAS = _booleano("RAG_CORREGIR_ERRATAS", True)
RAG_UMBRAL_ERRATA = _decimal("RAG_UMBRAL_ERRATA", 0.85, minimo=0.5, maximo=1.0)


# ═════════════════════════════════════════════════════════════════════════════
# CUMPLIMIENTO REGULATORIO — validador humano
# ═════════════════════════════════════════════════════════════════════════════
# [CONFIG-CENTRAL] Estos tres viven aquí y no en modulos/validador_humano.py
# porque son parámetros de NEGOCIO ajustables, y el invariante del proyecto es
# que no haya declaraciones dispersas: una segunda lectura de VIRF_VALIDADOR en
# otro módulo podría divergir de esta sin que nada avisara.
#
# La identidad por defecto permite corridas no interactivas (CI, lotes) sin
# abrir un agujero: si estas variables están vacías —el caso normal— el informe
# de producción se rechaza igualmente. Definirlas es una decisión explícita del
# operador, equivalente a firmar.
VALIDADOR_NOMBRE = os.getenv("VIRF_VALIDADOR", "").strip()
VALIDADOR_CARGO = os.getenv("VIRF_VALIDADOR_CARGO", "").strip()


def identidad_validador_entorno():
    """
    Lee la identidad del validador del entorno EN EL MOMENTO de la llamada.

    Las constantes de arriba se fijan al importar el módulo, lo que basta para
    una corrida normal pero no permite que un test cambie el entorno ni que un
    lanzador exporte la variable después del import. Esta función es la única
    lectura en runtime, de modo que sigue habiendo un solo punto de declaración.
    """
    return (os.getenv("VIRF_VALIDADOR", "").strip(),
            os.getenv("VIRF_VALIDADOR_CARGO", "").strip())

# Firmas consecutivas del mismo validador sobre el mismo modelo a partir de las
# cuales se advierte de falta de segunda revisión (SR 11-7 §V, segregación de
# funciones). No bloquea: en un equipo de 2 personas la rotación puede ser
# imposible en un periodo dado y bloquear impediría trabajar.
UMBRAL_SIN_SEGUNDA_REVISION = _entero("VIRF_UMBRAL_SEGUNDA_REVISION", 3, minimo=2)


# ═════════════════════════════════════════════════════════════════════════════
# [PENDIENTE-3] APROBACIÓN DE DOS OJOS (doble firma por tier)
# ═════════════════════════════════════════════════════════════════════════════
#
# Tiers en los que emitir el Word exige un SEGUNDO validador, distinto del
# primero. Lista separada por comas: `VIRF_DOBLE_FIRMA_TIER=1` o `=1,2`.
#
# ── Por qué el default es VACÍO (control desactivado) ────────────────────────
# Porque activarlo cambia el resultado de corridas que hoy funcionan: toda
# emisión Tier 1 automatizada empezaría a fallar hasta que alguien configure el
# segundo firmante. Un control de cumplimiento que se activa solo y rompe el
# pipeline sin aviso enseña al equipo a desactivarlo, que es el peor desenlace
# posible. La entidad lo habilita cuando ha decidido quién es el segundo par de
# ojos — que es una decisión de política, no de código.
#
# ── Por qué este control SÍ BLOQUEA, cuando `aviso_segunda_revision` no ──────
# El criterio vigente del proyecto es que el aviso NO bloquea, y sigue siendo
# correcto PARA LO QUE MIDE: `aviso_segunda_revision` detecta falta de ROTACIÓN
# a lo largo del tiempo (N informes consecutivos del mismo firmante). En un
# equipo de dos personas esa rotación puede ser imposible en un periodo dado
# —una de baja, un cierre trimestral— y no hay nada que el validador pueda
# hacer en ese momento para desbloquearse. Bloquear ahí impediría trabajar sin
# ofrecer remedio.
#
# La doble firma es distinta en las tres cosas que importan:
#
#   1. TIENE REMEDIO INMEDIATO. Lo que exige es un acto puntual —que un segundo
#      validador firme ahora—, no un patrón histórico que ya no se puede
#      cambiar. Siempre existe una acción que desbloquea.
#   2. ES OPT-IN. Si la entidad no puede garantizar dos firmantes, no habilita
#      la variable. Bloquear nunca se convierte en un callejón sin salida
#      impuesto por el código.
#   3. LA MATERIALIDAD ES OTRA. Tier 1 es la exigencia máxima. Un aviso que no
#      bloquea es, en la práctica, una casilla que se ignora: si la política de
#      la entidad es que un Tier 1 no se aprueba solo, el sistema debe hacerla
#      cumplir, no dejar constancia de que se incumplió.
#
# Un aviso aquí produciría exactamente lo que este proyecto evita: un informe
# que PARECE aprobado por dos personas porque el hueco se declaró en una nota
# al pie que nadie lee.
def tiers_doble_firma():
    """
    Tiers que exigen doble firma, leídos del entorno EN EL MOMENTO de la llamada.

    Función y no constante, por el mismo motivo que
    `identidad_validador_entorno()`: una constante se fija al importar y ni los
    tests ni un lanzador que exporte la variable después podrían cambiarla.
    Sigue habiendo un único punto de declaración.

    Los tiers se normalizan a cadena sin espacios: `--tier` llega como texto y
    compararlo con enteros haría que "1" != 1 desactivara el control en silencio.
    """
    crudo = os.getenv("VIRF_DOBLE_FIRMA_TIER", "").strip()
    return {t.strip() for t in crudo.split(",") if t.strip()}


#: Identidad del SEGUNDO firmante por entorno, para corridas no interactivas.
#: Sin esta vía, habilitar la doble firma dejaría sin poder emitir a cualquier
#: pipeline automatizado — y el equipo la desactivaría al día siguiente.
def identidad_segundo_validador_entorno():
    """Segundo firmante desde el entorno. Mismo criterio que el primero."""
    return (os.getenv("VIRF_VALIDADOR_2", "").strip(),
            os.getenv("VIRF_VALIDADOR_2_CARGO", "").strip())


# ═════════════════════════════════════════════════════════════════════════════
# PRESENTACIÓN DEL INFORME WORD
# ═════════════════════════════════════════════════════════════════════════════
#
# Viven aquí y no en `modulos/word_estilo.py` por la misma razón que todo lo
# demás: un parámetro leído del entorno en dos sitios distintos acaba
# divergiendo, y entonces nadie sabe cuál manda.

#: Tipografía corporativa del informe. `Flexo` es la de la entidad y NO se
#: distribuye con el proyecto —es una fuente comercial con licencia—, así que
#: el .docx la pide por nombre: se ve correcta en cualquier equipo que la tenga
#: instalada. Donde falte, Word sustituye por WORD_FUENTE_RESPALDO, que se
#: declara en la tabla de fuentes del propio documento.
WORD_FUENTE = os.getenv("VIRF_FUENTE", "Flexo").strip() or "Flexo"

#: Monoespaciada de los bloques de código. Debe ser de ancho fijo: con una
#: proporcional, la sangría del código —que es información— deja de alinearse.
WORD_FUENTE_MONO = os.getenv("VIRF_FUENTE_MONO", "Cascadia Mono").strip() \
    or "Cascadia Mono"

#: Sustituta declarada cuando la corporativa no está instalada. Sin declararla,
#: Word elige por su cuenta y suele caer en una serifa que desmonta el diseño.
WORD_FUENTE_RESPALDO = os.getenv("VIRF_FUENTE_RESPALDO", "Segoe UI").strip() \
    or "Segoe UI"

#: Carpeta del logo de la entidad para la portada. Si no hay fichero, la
#: portada sale sin logo y sin hueco: un recuadro de "imagen no encontrada" en
#: un informe regulatorio es peor que no ponerlo.
WORD_DIR_LOGO = os.getenv("VIRF_DIR_LOGO", "inputs/logoempresa").strip() \
    or "inputs/logoempresa"


# ═════════════════════════════════════════════════════════════════════════════
# DETERMINISMO DE LA LLAMADA AL MODELO
# ═════════════════════════════════════════════════════════════════════════════

#: Temperatura de muestreo. **0 a propósito.**
#:
#: [AUDIT-FIX 2026-08-07] Antes no se pasaba `temperature` en ninguna llamada, y
#: el valor por defecto de Anthropic es 1.0 — el de máxima variabilidad. Es
#: decir: la misma evidencia podía producir dos dictámenes distintos, lo que
#: rompe el invariante 5 del proyecto (una corrida reproducible por sí sola) y
#: deja sin sentido la cadena de custodia: sellar un informe irreproducible
#: acredita que ESE fichero no se alteró, no que el juicio sea repetible.
#:
#: A 0 el muestreo es greedy. No garantiza determinismo absoluto —la inferencia
#: distribuida puede variar en el margen—, pero elimina la aleatoriedad
#: deliberada, que es la parte que estaba bajo nuestro control.
IA_TEMPERATURE = _decimal("VIRF_IA_TEMPERATURE", 0.0, minimo=0.0, maximo=2.0)


#: Espejo de `src/rag/config_rag.RECONOCIMIENTO_MINIMO`. Fracción mínima de la
#: consulta que el corpus de dominio debe reconocer para que sus fragmentos se
#: inyecten sin advertencia en el prompt. Ver el AUDIT-FIX de
#: `buscador_lexico._buscar`: sin esta señal, una consulta de otro dominio
#: recuperaba literatura ajena rotulada «cubre el 100% de los términos clave».
RAG_RECONOCIMIENTO_MINIMO = _decimal("RAG_RECONOCIMIENTO_MINIMO", 0.5,
                                     minimo=0.0, maximo=1.0)
