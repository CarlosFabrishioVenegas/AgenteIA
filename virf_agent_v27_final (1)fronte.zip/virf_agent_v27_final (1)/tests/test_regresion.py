"""
tests/test_regresion.py — Red de regresión del núcleo VIRF
═══════════════════════════════════════════════════════════════════════════════

Origen: creada durante la auditoría de regresión del 2026-07-26, tras aplicar
limpieza de código muerto, corrección del flujo secuencial, chunking adaptativo
y reubicación de outputs. Antes de esto el proyecto NO tenía suite automatizada.

Qué cubre — solo lo que participa en el flujo REAL:
  · Factory de clientes IA y su cacheo
  · Lectura de estándares e inputs (incluida la exclusión de datasets/)
  · Chunking con cobertura garantizada en documentos grandes
  · Contrato JSON y política de "no inventar puntajes"
  · Cálculo de scores excluyendo evaluaciones inválidas
  · Feedback con guardias de muestra mínima
  · Caché: atomicidad, purga y concurrencia
  · Motores de datos
  · Generación de Word con ámbitos sin evidencia
  · Pipeline 1 (controles) y parseo tolerante a NaN

NO llama a la API: todo usa clientes simulados. Coste 0, ejecutable en CI.

Uso:
    pytest                      # toda la suite
    pytest -k chunker           # solo chunking
    pytest --tb=long            # trazas completas
"""

import json
import os
import re
import sys
import tempfile
import threading
from pathlib import Path

import pytest

RAIZ = Path(__file__).parent.parent
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))


# ═════════════════════════════════════════════════════════════════════════════
# Dobles de prueba
# ═════════════════════════════════════════════════════════════════════════════

class ClienteSimulado:
    """Cliente IA que no llama a la API."""

    def __init__(self, respuesta="resumen simulado"):
        self.respuesta = respuesta
        self.llamadas = 0

    def generar_mensaje(self, prompt="", max_tokens=None, **kw):
        self.llamadas += 1
        return self.respuesta


class ClienteRoto:
    """Simula la API caída."""

    def generar_mensaje(self, **kw):
        raise RuntimeError("API 500")


@pytest.fixture
def texto_largo():
    """Genera texto de N páginas (~2.000 chars/página)."""
    def _gen(paginas):
        base = "Metodologia LaR con volatilidad EWMA lambda 0.94. Backtesting Kupiec p=0.021. "
        objetivo = paginas * 2000
        return (base * (objetivo // len(base) + 2))[:objetivo]
    return _gen



@pytest.fixture(scope="session")
def pdf_real():
    """
    Extrae UNA sola vez el PDF de 305 páginas (la extracción tarda ~70 s).
    Devuelve el dict de `leer_archivo`, o marca skip si el PDF no está.
    """
    ruta = (RAIZ / "inputs" / "documentacion" / "modelamiento"
            / "Manual_Metodologico_LaR_completo.pdf")
    if not ruta.exists():
        pytest.skip("PDF de 305 páginas no disponible (regenerar con gen_pdf.py)")
    import sys as _s
    _s.path.insert(0, str(RAIZ / "motor"))
    from Mx_01_LecturaEvidencias import leer_archivo
    doc = leer_archivo(ruta)
    if doc is None:
        pytest.skip("no se pudo extraer el PDF")
    return doc


class ClienteRealista:
    """Respeta max_tokens, como el modelo real (~4 chars por token)."""

    def __init__(self):
        self.llamadas = 0

    def generar_mensaje(self, prompt="", max_tokens=None, **kw):
        self.llamadas += 1
        t = "Resumen: EWMA 0.94, Kupiec p=0.021, curtosis 4.2. "
        tope = (max_tokens or 1500) * 4
        return (t * (tope // len(t) + 1))[:tope]


# ═════════════════════════════════════════════════════════════════════════════
# 1. Configuración y clientes IA
# ═════════════════════════════════════════════════════════════════════════════

class TestConfiguracion:

    def test_pesos_suman_uno(self):
        from config import AMBITO_PESOS
        assert abs(sum(AMBITO_PESOS.values()) - 1.0) < 1e-6

    def test_ambitos_coinciden_en_los_cuatro_sistemas(self):
        """Un desajuste de tilde o mayúscula rompe el pipeline en silencio."""
        import Mx_00_CargaRutas as mx00
        from config import AMBITO_PESOS, PREGUNTAS_METODOLOGICAS
        from modulos.motor_ia import leer_estandares_virf

        excel = set(leer_estandares_virf("1"))
        assert excel == set(AMBITO_PESOS), "Excel ≠ AMBITO_PESOS"
        assert excel == set(mx00.AMBITO_A_INPUTS), "Excel ≠ AMBITO_A_INPUTS"
        assert excel == set(mx00.INSTRUCCIONES_DIMENSION), "Excel ≠ INSTRUCCIONES_DIMENSION"
        assert excel == set(PREGUNTAS_METODOLOGICAS), "Excel ≠ PREGUNTAS_METODOLOGICAS"

    def test_cliente_ia_se_cachea_por_proceso(self):
        """[PERF-FIX] Sin cacheo se duplicaban las llamadas a la API."""
        from config import get_cliente_ia, reset_cliente_ia
        reset_cliente_ia()
        assert get_cliente_ia() is get_cliente_ia()

    def test_env_example_sin_claves_reales(self):
        """[SEC-FIX] .env.example se commitea: no puede llevar credenciales."""
        import re
        txt = (RAIZ / ".env.example").read_text(encoding="utf-8", errors="ignore")
        assert not re.search(r"sk-ant-[A-Za-z0-9_\-]{30,}", txt)

    def test_gitignore_protege_env(self):
        lineas = (RAIZ / ".gitignore").read_text(encoding="utf-8").splitlines()
        assert any(l.strip() == ".env" for l in lineas)


# ═════════════════════════════════════════════════════════════════════════════
# 2. Lectura de estándares e inputs
# ═════════════════════════════════════════════════════════════════════════════

def _estandar_es_reconstruccion() -> bool:
    """
    True si Estandares_VIRF.xlsx es la reconstrucción parcial del 30/07/2026.

    El estándar original se destruyó (un barrido de imports ejecutó
    create_estandares_excel.py, que lo sobrescribió) y se reconstruyó desde los
    informes emitidos. El texto de las actividades se recuperó; la MATRIZ DE
    TIERS no: se perdió qué actividad se exige en cada tier.

    Los tests que fijan los conteos por tier no pueden pasar contra la
    reconstrucción — y ajustar sus números para ponerlos en verde TAPARÍA la
    pérdida. Se saltan con un motivo visible, y volverán a comprobar en cuanto
    alguien reponga el fichero original.
    """
    try:
        import openpyxl
        wb = openpyxl.load_workbook(RAIZ / "inputs" / "Estandares_VIRF.xlsx",
                                    read_only=True)
        return "AVISO_LEEME" in wb.sheetnames
    except Exception:
        return False


_MOTIVO_RECONSTRUCCION = (
    "Estandares_VIRF.xlsx es la RECONSTRUCCIÓN parcial del 30/07/2026: la "
    "matriz de tiers del original se perdió y todas las actividades quedaron "
    "marcadas como requeridas en los 4 tiers. ACCIÓN PENDIENTE: reponer el "
    "fichero original o revisar la matriz a mano (ver hoja AVISO_LEEME)."
)


class TestLectura:

    def test_estandares_filtran_por_tier(self):
        """
        El filtro por tier discrimina. Sin conteos literales: el estándar es un
        documento vivo y fijar «Tier 1 = 15» rompe el test en cada revisión
        legítima. Lo que no puede variar es que los tiers exijan cosas
        distintas — si no, el tiering es decorativo.
        """
        from modulos.motor_ia import leer_estandares_virf
        requeridas = {}
        for tier in ("1", "2", "3", "4"):
            r = leer_estandares_virf(tier)
            assert r, f"Tier {tier}: el estándar no se pudo leer"
            requeridas[tier] = sum(
                len([a for a in v if a.get("requerida", True)]) for v in r.values()
            )
        assert all(n > 0 for n in requeridas.values()), (
            f"algún tier no exige nada: {requeridas}")
        assert len(set(requeridas.values())) > 1, (
            f"todos los tiers exigen lo mismo ({requeridas}): el filtro no "
            f"discrimina y un modelo sencillo se evaluaría con el rigor de uno "
            f"crítico")

    def test_el_estandar_reconstruido_declara_su_limitacion(self):
        """
        Si el estándar es la reconstrucción, DEBE llevar el aviso a la vista.

        Sin él, dentro de unas semanas nadie recordará que los tiers no son los
        reales y se emitirán informes con exigencia equivocada creyéndolos
        correctos.
        """
        if not _estandar_es_reconstruccion():
            pytest.skip("el estándar no es una reconstrucción")
        import openpyxl
        wb = openpyxl.load_workbook(RAIZ / "inputs" / "Estandares_VIRF.xlsx")
        texto = "\n".join(str(c.value) for fila in wb["AVISO_LEEME"].iter_rows()
                          for c in fila if c.value)
        assert "NO ES EL ESTÁNDAR ORIGINAL" in texto.upper()
        assert "TIER" in texto.upper(), "no advierte de la pérdida de la matriz"
        assert wb.sheetnames[0] == "AVISO_LEEME", (
            "el aviso debe ser la PRIMERA hoja: enterrado al final no lo lee nadie")

    def test_tier_inexistente_no_revienta(self):
        from modulos.motor_ia import leer_estandares_virf
        assert isinstance(leer_estandares_virf("99"), dict)

    def test_datasets_no_son_evidencia_documental(self):
        """[EVIDENCIA-FIX] Un CSV consumía los 15.000 chars de contexto."""
        from modulos.motor_ia import cargar_todos_inputs, inputs_para_dimension
        docs = inputs_para_dimension(cargar_todos_inputs(), "Calidad de datos")
        csv = [d["nombre"] for d in docs if d["nombre"].endswith(".csv")]
        assert not csv, f"datasets leídos como evidencia: {csv}"

    def test_config_del_validador_no_es_evidencia(self):
        """Estandares_VIRF.xlsx y ControlesData.xlsx son rúbrica, no evidencia."""
        from modulos.motor_ia import cargar_todos_inputs
        nombres = {d["nombre"].lower() for docs in cargar_todos_inputs().values() for d in docs}
        assert "estandares_virf.xlsx" not in nombres


# ═════════════════════════════════════════════════════════════════════════════
# 3. Chunking — cobertura de documentos grandes
# ═════════════════════════════════════════════════════════════════════════════

class TestChunking:

    @pytest.mark.parametrize("paginas", [150, 300, 500, 1000])
    def test_cobertura_total_sin_truncar(self, texto_largo, paginas, capsys):
        """[COBERTURA-FIX] Antes truncaba al 46% en un manual de 300 páginas."""
        from modulos.chunker import ChunkerService
        ch = ChunkerService(cliente_ia=ClienteSimulado())
        r = ch.procesar_doc({
            "nombre": f"manual_{paginas}p.pdf", "tipo": "PDF",
            "contenido": texto_largo(paginas), "chars_totales": paginas * 2000,
        })
        capsys.readouterr()
        assert r["cobertura_pct"] >= 99.9, (
            f"{paginas} págs → cobertura {r['cobertura_pct']}% (se pierde texto)"
        )

    def test_documento_corto_no_se_chunkea(self):
        from modulos.chunker import ChunkerService
        cli = ClienteSimulado()
        ch = ChunkerService(cliente_ia=cli)
        r = ch.procesar_doc({"nombre": "c.md", "tipo": "MD",
                             "contenido": "x" * 500, "chars_totales": 500})
        assert r["n_chunks"] == 1 and cli.llamadas == 0

    def test_documento_vacio_no_revienta(self):
        from modulos.chunker import ChunkerService
        ch = ChunkerService(cliente_ia=ClienteSimulado())
        r = ch.procesar_doc({"nombre": "v.md", "tipo": "MD",
                             "contenido": "", "chars_totales": 0})
        assert r["cobertura_pct"] == 100.0

    def test_api_caida_degrada_sin_excepcion(self, capsys):
        from modulos.chunker import ChunkerService
        ch = ChunkerService(cliente_ia=ClienteRoto())
        r = ch.procesar_doc({"nombre": "g.pdf", "tipo": "PDF",
                             "contenido": "z" * 60000, "chars_totales": 60000})
        capsys.readouterr()
        assert r["fue_truncado_fc"] and r["cobertura_pct"] < 100

    def test_cobertura_de_una_pasada_cubre_300_paginas(self):
        """
        [COSTE-FIX D2] Este test usaba _CHUNK_SIZE, que desde D1 es solo el
        tamaño INICIAL del segmento: si el documento no cabe en _MAX_CHUNKS
        segmentos, el modo adaptativo los agranda hasta _MAX_CHUNK_SIZE_ADAPTATIVO
        en vez de descartar texto. Con la fórmula vieja, bajar VIRF_MAX_CHUNKS
        de 60 a 40 —que es más barato y cubre exactamente igual— fallaba.

        El techo real de la pasada adaptativa usa _MAX_CHUNK_SIZE_ADAPTATIVO.
        """
        from modulos.chunker import (
            _MAX_CHUNKS, _MAX_CHUNK_SIZE_ADAPTATIVO, _CHUNK_OVERLAP,
        )
        cobertura = _MAX_CHUNKS * (_MAX_CHUNK_SIZE_ADAPTATIVO - _CHUNK_OVERLAP)
        assert cobertura >= 600_000, f"solo {cobertura // 2000} páginas en 1 pasada"

    def test_un_manual_de_300_paginas_se_cubre_entero(self, capsys):
        """
        La afirmación de verdad detrás del test anterior, comprobada por
        comportamiento en vez de por fórmula: 300 págs ⇒ 100% de cobertura
        con la configuración por defecto, sin truncar.
        """
        from modulos.chunker import ChunkerService
        texto = ("Metodologia LaR Kupiec p=0.021 backtesting EWMA. " * 12500)[:600_000]
        r = ChunkerService(cliente_ia=ClienteSimulado()).procesar_doc({
            "nombre": "manual300.pdf", "tipo": "PDF",
            "contenido": texto, "chars_totales": len(texto),
        })
        capsys.readouterr()
        assert r["cobertura_pct"] >= 99.9, f"cobertura {r['cobertura_pct']}%"
        assert not r["fue_truncado_fc"]

    def test_mx01_no_trunca_antes_del_chunker(self, tmp_path, texto_largo):
        """
        [TRUNCADO-FIX] REGRESIÓN CRÍTICA detectada en la auditoría 2026-07-26.

        Mx_01.leer_archivo() truncaba a MAX_CHARS_DOC (15.000) ANTES de que el
        chunker viera el documento. Un manual de 327.360 chars llegaba recortado
        a 15.000 y el chunker reportaba "cobertura 100%" — 100% de lo que
        recibió, o sea el 4.6% del archivo real. El prompt afirmaba cobertura
        completa habiendo perdido el 95.4%.
        """
        from Mx_01_LecturaEvidencias import leer_archivo

        f = tmp_path / "manual_grande.md"
        contenido = texto_largo(160)          # ~320.000 chars
        f.write_text(contenido, encoding="utf-8")

        doc = leer_archivo(f)
        assert doc is not None
        assert len(doc["contenido"]) == len(contenido), (
            f"Mx_01 truncó a {len(doc['contenido']):,} de {len(contenido):,} chars "
            "— el chunker no podrá cubrir el documento"
        )
        assert doc["chars_totales"] == len(contenido)

    def test_cobertura_se_mide_contra_el_archivo_real(self, tmp_path):
        """Si algo trunca aguas arriba, la cobertura NO debe salir 100%."""
        from modulos.chunker import ChunkerService
        ch = ChunkerService(cliente_ia=ClienteSimulado())
        # Simula un doc truncado: recibe 20.000 pero el original tenía 200.000
        r = ch.procesar_doc({
            "nombre": "truncado.pdf", "tipo": "PDF",
            "contenido": "x" * 20_000,
            "chars_totales": 200_000,      # tamaño real en disco
        })
        assert r["cobertura_pct"] < 20, (
            f"cobertura {r['cobertura_pct']}% — debería reflejar la pérdida real"
        )


# ═════════════════════════════════════════════════════════════════════════════
# 4. Contrato JSON y política de no inventar
# ═════════════════════════════════════════════════════════════════════════════

class TestContrato:

    @pytest.mark.parametrize("bruto,esperado", [
        ('{"puntaje":3}', 3),
        ('```json\n{"puntaje":4}\n```', 4),
        ('{"puntaje":5}\n\nEspero sea útil.', 5),
        ('Aquí va:\n{"puntaje":2}', 2),
        ('{"puntaje":3,"m":{"a":{"b":1}}}\nfin', 3),
        ('{"puntaje":3,"o":"usa { y } aquí"}\nx', 3),
    ])
    def test_extraer_json_tolera_formatos(self, bruto, esperado):
        """[PARSEO-FIX] El modelo añade texto alrededor del JSON."""
        from modulos.motor_ia import _extraer_json
        assert _extraer_json(bruto)["puntaje"] == esperado

    def test_contrato_valido_pasa(self):
        from modulos.motor_ia import _validar_contrato_evaluacion
        assert _validar_contrato_evaluacion({
            "puntaje": 3, "concepto": "c", "observacion": "o",
            "evidencia_encontrada": "e", "preguntas_pendientes": [], "recomendacion": "r",
        }) == []

    @pytest.mark.parametrize("campo,valor", [
        ("puntaje", "tres"), ("puntaje", 9), ("concepto", ""),
        ("preguntas_pendientes", "una sola"),
    ])
    def test_contrato_rechaza_invalidos(self, campo, valor):
        from modulos.motor_ia import _validar_contrato_evaluacion
        base = {"puntaje": 3, "concepto": "c", "observacion": "o",
                "evidencia_encontrada": "e", "preguntas_pendientes": [], "recomendacion": "r"}
        assert _validar_contrato_evaluacion({**base, campo: valor})

    def test_evaluacion_fallida_no_inventa_puntaje(self):
        """[CONTRATO-FIX] Antes devolvía puntaje=2 ante cualquier error."""
        from modulos.motor_ia import _evaluacion_invalida
        r = _evaluacion_invalida("motivo", "detalle", "act", "ctrl", 1.0, "LaR", 0)
        assert r["puntaje"] is None
        assert r["evaluacion_valida"] is False

    def test_cobertura_se_propaga_hasta_el_prompt(self):
        """[COBERTURA-FIX] El dato moría en chunker.py."""
        import inspect
        from modulos.motor_ia import evaluar_actividad, evaluar_ambito_completo
        assert "cobertura_docs" in inspect.signature(evaluar_actividad).parameters
        assert "cobertura_docs" in inspect.signature(evaluar_ambito_completo).parameters
        assert "cobertura_docs  = cobertura_ambito" in (RAIZ / "agente.py").read_text(
            encoding="utf-8", errors="ignore")


# ═════════════════════════════════════════════════════════════════════════════
# 5. Scores
# ═════════════════════════════════════════════════════════════════════════════

class TestScores:

    def test_promedio_simple(self):
        from modulos.motor_ia import calcular_score_ambito
        assert calcular_score_ambito([{"puntaje": 4}, {"puntaje": 2}]) == 3.0

    def test_excluye_sin_evidencia(self):
        from modulos.motor_ia import calcular_score_ambito
        assert calcular_score_ambito([{"puntaje": 4}, {"puntaje": None}]) == 4.0

    def test_excluye_evaluaciones_invalidas(self):
        from modulos.motor_ia import calcular_score_ambito
        assert calcular_score_ambito([{"puntaje": 3, "evaluacion_valida": False}]) is None

    def test_ambito_totalmente_vacio_es_falta_critica(self):
        # [POLÍTICA 2026-07-29] Un ámbito del que no se obtuvo NADA no es una
        # ausencia de dictamen: la política de la entidad lo trata como falta
        # crítica del validado, que tenía que aportar documentación.
        # (Los ámbitos sin actividades requeridas para el tier no llegan aquí.)
        from modulos.motor_ia import calcular_score_ambito
        assert calcular_score_ambito([]) == 0.0

    def test_score_global_excluye_del_denominador_el_fallo_tecnico(self):
        """
        None = fallo técnico del agente → fuera del promedio y del denominador.
        (La falta de EVIDENCIA es otra cosa: llega como 0.0 y sí penaliza; se
        comprueba en TestAuditoriaSinEvidenciaEsFaltaCriticaNoAusenciaDeDictamen.)
        """
        from modulos.motor_ia import calcular_score_global
        con_none = calcular_score_global({"Metodología": 3.0, "Gobierno": None})
        solo = calcular_score_global({"Metodología": 3.0})
        assert con_none == solo == 3.0

    def test_semaforo_cubre_toda_la_escala(self):
        from modulos.motor_ia import get_semaforo
        for s in (0.5, 2.0, 3.0, 4.0, 4.8):
            assert get_semaforo(s).get("label")


# ═════════════════════════════════════════════════════════════════════════════
# 6. Feedback
# ═════════════════════════════════════════════════════════════════════════════

class TestFeedback:

    def test_patron_con_historial_vacio(self, monkeypatch, tmp_path):
        """
        Sin historial, la tendencia debe ser 'equilibrado'.

        [FIX 2026-07-29] Este test leía el historial REAL del proyecto pese a
        llamarse «con historial vacío», así que su resultado dependía de un
        fichero mutable: en cuanto se registró una corrección de Metodología
        empezó a fallar. Un test unitario no puede depender del estado
        acumulado del proyecto — ahora se aísla el fichero.
        """
        import modulos.feedback as fb
        from modulos.feedback_mejorado import analizar_patron_errores
        monkeypatch.setattr(fb, "FEEDBACK_PATH", tmp_path / "vacio.json")
        assert analizar_patron_errores("Metodología")["tendencia"] == "equilibrado"

    def test_ajuste_exige_muestras_minimas(self):
        """Sin guardia, 1 feedback alteraría todos los puntajes del ámbito."""
        from modulos.feedback_mejorado import ajustar_puntaje_por_feedback
        p, _ = ajustar_puntaje_por_feedback("Metodología", "actividad inexistente", 3.0)
        assert p == 3.0

    def test_estadisticas_con_historial_vacio(self):
        from modulos.feedback import calcular_estadisticas
        assert isinstance(calcular_estadisticas(), dict)

    def test_bucle_sin_tty_no_revienta(self):
        """[CI-FIX] Antes lanzaba EOFError → exit 1 pese a completar bien."""
        from modulos.feedback import bucle_feedback_consola
        assert bucle_feedback_consola({}, "M", "1", "") == []

    def test_antisesgo_exige_masa_critica(self):
        """[D6-FIX] La guardia existía pero no se invocaba."""
        from modulos.motor_ia import validar_masa_critica_feedback
        r = validar_masa_critica_feedback([], "Metodología", min_registros=15)
        assert r["masa_critica_ok"] is False


# ═════════════════════════════════════════════════════════════════════════════
# 7. Caché
# ═════════════════════════════════════════════════════════════════════════════

class TestCache:

    def test_escritura_atomica_sin_residuos(self, tmp_path):
        from modulos.document_cache import DocumentCache
        c = DocumentCache(cache_dir=tmp_path, enabled=True)
        c._data = {"a": {"hash_sha256": "h"}}
        c._dirty = True
        c.persistir()
        assert json.loads((tmp_path / "document_cache.json").read_text(encoding="utf-8"))
        assert not list(tmp_path.glob("*.tmp"))

    def test_purgar_huerfanos(self, tmp_path):
        from modulos.document_cache import DocumentCache
        c = DocumentCache(cache_dir=tmp_path, enabled=True)
        c._data = {"f": {"hash_sha256": "h", "ruta": str(tmp_path / "no_existe.md")}}
        c.purgar_huerfanos()
        assert len(c._data) == 0

    def test_escritores_concurrentes_no_pierden_datos(self, tmp_path):
        """[CONCURRENCIA-FIX] Sin lock, la última escritura pisaba al resto."""
        from modulos.document_cache import DocumentCache
        errores = []

        def escribir(i):
            try:
                c = DocumentCache(cache_dir=tmp_path / "c", enabled=True)
                c._data = {f"d{i}": {"hash_sha256": f"h{i}"}}
                c._dirty = True
                c.persistir()
            except Exception as e:  # pragma: no cover
                errores.append(e)

        hilos = [threading.Thread(target=escribir, args=(i,)) for i in range(10)]
        [h.start() for h in hilos]
        [h.join() for h in hilos]

        final = json.loads((tmp_path / "c" / "document_cache.json").read_text(encoding="utf-8"))
        assert not errores
        assert len(final) == 10, f"solo {len(final)}/10 entradas conservadas"

    def test_singleton(self, tmp_path):
        from modulos.document_cache import inicializar_cache, get_cache
        assert inicializar_cache(cache_dir=tmp_path, enabled=False) is get_cache()


# ═════════════════════════════════════════════════════════════════════════════
# 8. Motores de datos
# ═════════════════════════════════════════════════════════════════════════════

class TestMotoresDatos:

    def test_catalogo_completo(self):
        from modulos.motores_datos import motores_disponibles
        esperados = {"unicidad", "duplicados", "missing", "outliers",
                     "rango", "integridad_referencial", "tipo_dato", "completitud"}
        assert esperados <= set(motores_disponibles())

    def test_deteccion_exacta_de_defectos(self):
        import pandas as pd
        from modulos.motores_datos import ejecutar_motor
        df = pd.DataFrame({
            "Cuenta": [1, 1, 2, 3],
            "Cliente": ["A", "B", "C", "D"],
            "Tasa": [0.05, None, 99.0, 0.07],
        })
        u = ejecutar_motor("unicidad", df, {"control_id": "T", "group_cols": "Cuenta",
                                            "campo_objetivo": "Cliente", "umbral": 0})
        m = ejecutar_motor("missing", df, {"control_id": "T", "campo_objetivo": "Tasa",
                                           "umbral": 0})
        r = ejecutar_motor("rango", df, {"control_id": "T", "campo_objetivo": "Tasa",
                                         "min": 0, "max": 1, "umbral": 0})
        assert u["n_hallazgos"] == 1
        assert m["n_hallazgos"] == 1
        assert r["n_hallazgos"] == 1

    def test_umbral_se_respeta(self):
        """El UMBRAL del Excel se ignoraba: usaba cortes fijos."""
        import pandas as pd
        from modulos.motores_datos import ejecutar_motor
        df = pd.DataFrame({"Cuenta": [1, 1, 2], "Cliente": ["A", "B", "C"]})
        cfg = {"control_id": "T", "group_cols": "Cuenta", "campo_objetivo": "Cliente"}
        tolerante = ejecutar_motor("unicidad", df, {**cfg, "umbral": 1})
        estricto = ejecutar_motor("unicidad", df, {**cfg, "umbral": 0})
        assert tolerante["estado"] == "OK"
        assert estricto["estado"] != "OK"

    def test_motor_inexistente_no_revienta(self):
        import pandas as pd
        from modulos.motores_datos import ejecutar_motor
        r = ejecutar_motor("inventado", pd.DataFrame({"a": [1]}), {"control_id": "T"})
        assert r["estado"] == "ERROR" and r["error"]

    def test_dataset_ausente_no_revienta(self):
        from modulos.motores_datos import ejecutar_motor
        r = ejecutar_motor("unicidad", None, {"control_id": "T"})
        assert r["estado"] == "ERROR"


# ═════════════════════════════════════════════════════════════════════════════
# 9. Informe Word
# ═════════════════════════════════════════════════════════════════════════════

class TestWord:

    def test_score_none_no_revienta(self):
        """
        Un ámbito sin score tumbaba la generación del Word.

        [POLÍTICA 2026-07-29] El literal esperado cambió: None ya no significa
        «sin evidencia» sino FALLO TÉCNICO. La falta de evidencia llega como
        0.0 y es una falta crítica. Se comprueba que la etiqueta nombra la
        causa en vez de fijar un texto exacto, que es lo que importa aquí.
        """
        from modulos.generador_word import _score_color_hex, _label_semaforo
        assert _score_color_hex(None) == "CCCCCC"
        assert "TÉCNICO" in _label_semaforo(None).upper()
        assert "SIN EVIDENCIA" in _label_semaforo(0.0).upper()

    def test_genera_word_con_ambito_sin_evidencia(self, tmp_path, capsys):
        from modulos.generador_word import generar_word_informe
        ruta = generar_word_informe(
            resumen_ejecutivo="Resumen.",
            evaluaciones_por_ambito={
                "Metodología": [{"actividad": "A1", "control": "C1", "puntaje": 3,
                                 "concepto": "c", "observacion": "o",
                                 "evidencia_encontrada": "e", "preguntas_pendientes": [],
                                 "recomendacion": "r", "evaluacion_valida": True}],
                "Gobierno": [{"actividad": "A2", "control": "C2", "puntaje": None,
                              "concepto": "SIN EVIDENCIA", "observacion": "-",
                              "evidencia_encontrada": "", "preguntas_pendientes": ["¿dónde?"],
                              "recomendacion": "-", "sin_evidencia": True}],
            },
            scores_por_ambito={"Metodología": 3.0, "Gobierno": None},
            score_global=3.0, titulo_modelo="QA", tier="1", outputs_dir=tmp_path,
        )
        capsys.readouterr()
        assert Path(ruta).exists() and Path(ruta).stat().st_size > 10_000


# ═════════════════════════════════════════════════════════════════════════════
# 10. Pipeline 1 — controles
# ═════════════════════════════════════════════════════════════════════════════

class TestPipelineControles:

    def test_lee_el_excel_de_controles(self):
        from modulos.controles_a_notebook import leer_controles_excel
        ruta = RAIZ / "inputs" / "calidad_datos" / "ControlesData.xlsx"
        if not ruta.exists():
            pytest.skip("ControlesData.xlsx no disponible")
        controles = leer_controles_excel(ruta)
        assert controles and all(c["id_control"] for c in controles)

    def test_nan_del_excel_no_revienta(self):
        """[NAN-FIX] NaN es truthy en Python → int(nan) lanzaba ValueError."""
        from Mx_04_MotorControlesData import parsear_config_control
        cfg = parsear_config_control({
            "ID_CONTROL": "C1", "USA_MOTOR_DATA": float("nan"),
            "UMBRAL": float("nan"), "TIPO_MOTOR": float("nan"),
        })
        assert cfg["usa_motor_data"] == 0
        assert isinstance(cfg["umbral"], int)

    def test_buscador_encuentra_evidencia_markdown(self):
        """[EVIDENCIA-FIX] Solo aceptaba binarios: los .md eran invisibles."""
        from modulos.control_evaluacion_data import BuscadorEvidencias
        encontrada, ruta_manual, texto, _, _ = BuscadorEvidencias.buscar_evidencias(
            str(RAIZ), "Control_01")
        assert encontrada and texto.strip()

    def test_buscador_excluye_configuracion(self):
        from modulos.control_evaluacion_data import BuscadorEvidencias
        _, ruta_manual, _, _, _ = BuscadorEvidencias.buscar_evidencias(str(RAIZ), "Control_01")
        assert "estandares_virf" not in str(ruta_manual).lower()


# ═════════════════════════════════════════════════════════════════════════════
# 11. Convención de salidas
# ═════════════════════════════════════════════════════════════════════════════

class TestSalidas:

    def test_raiz_sin_artefactos_generados(self):
        sueltos = [
            p.name for p in RAIZ.iterdir()
            if p.is_file() and p.suffix in (".docx",)
            or (p.is_file() and p.name == "resultados_controles.json")
        ]
        assert not sueltos, f"artefactos en la raíz: {sueltos}"

    def test_outputs_organizados_por_fecha(self):
        import re
        out = RAIZ / "outputs"
        if not out.exists():
            pytest.skip("outputs/ aún no existe")
        sueltos = [f.name for f in out.iterdir() if f.is_file()]
        assert not sueltos, f"archivos sin carpeta de fecha: {sueltos}"
        patron = re.compile(r"^\d{4}-\d{2}-\d{2}$")
        assert all(patron.match(d.name) for d in out.iterdir() if d.is_dir())

    def test_notebook_de_controles_escribe_en_outputs(self):
        """[SALIDAS-FIX] Escribía resultados_controles.json en el CWD."""
        codigo = "\n".join(
            l for l in (RAIZ / "modulos" / "controles_a_notebook.py")
            .read_text(encoding="utf-8").splitlines()
            if not l.lstrip().startswith("#")
        )
        assert "Path('resultados_controles.json')" not in codigo
        assert "_destino_resultados" in codigo


# ═════════════════════════════════════════════════════════════════════════════
# 12. Integridad estructural
# ═════════════════════════════════════════════════════════════════════════════

class TestIntegridad:

    def test_todos_los_modulos_importan(self):
        import importlib
        for m in ("config", "modulos.motor_ia", "modulos.motor_ia_v2",
                  "modulos.generador_word", "modulos.document_cache",
                  "modulos.chunker", "modulos.feedback", "modulos.feedback_mejorado",
                  "modulos.motores_datos", "modulos.excel_a_notebook",
                  "modulos.controles_a_notebook", "modulos.control_evaluacion_data"):
            importlib.import_module(m)

    def test_codigo_muerto_fuera_del_arbol_activo(self):
        for nombre in ("v13_fixes.py", "generador_excel.py", "generador_template.py",
                       "lector_inputs.py"):
            assert not (RAIZ / "modulos" / nombre).exists()
        for nombre in ("Mx_05_GeneradorWord.py", "Mx_05_ComparativaDocCodigo.py"):
            assert not (RAIZ / "motor" / nombre).exists()

    def test_patrones_metodologicos_completos(self):
        import Mx_00_CargaRutas as mx00
        patrones = mx00.CUESTIONAMIENTOS_METODOLOGICOS
        assert len(patrones) >= 15
        for critico in ("sin_estacionariedad", "sin_backtesting_lar", "sin_test_normalidad"):
            assert critico in patrones

    def test_rag_degrada_sin_chromadb(self):
        """El pipeline debe funcionar aunque el RAG no esté disponible."""
        from src.rag import get_retriever, inferir_dominio
        assert inferir_dominio("Modelo LaR") == "LaR"
        assert isinstance(get_retriever(tipo_modelo="LaR").query("test", top_k=1), list)

    def test_resumenes_caben_en_el_presupuesto_de_contexto(self):
        """
        [PRESUPUESTO-FIX] Un manual de 327k producía 30 resúmenes que sumaban
        118.332 chars; el prompt los recortaba a MAX_CTX (15.000) → se volvía
        a truncar, ahora en la capa del prompt. La consolidación jerárquica
        debe activarse por el TAMAÑO DEL RESULTADO, no solo el de entrada.
        """
        import contextlib, io
        from modulos.chunker import ChunkerService, _PRESUPUESTO_CONTEXTO

        class ResumenRealista:
            """Devuelve resúmenes del tamaño que produce el modelo real."""
            def generar_mensaje(self, prompt="", max_tokens=None, **kw):
                return "Resumen con p=0.021 Kupiec EWMA 0.94. " * (
                    (max_tokens or 1500) // 12)

        texto = ("Metodologia LaR backtesting. " * 24_000)[:600_000]
        ch = ChunkerService(cliente_ia=ResumenRealista())
        with contextlib.redirect_stdout(io.StringIO()):
            r = ch.procesar_doc({"nombre": "manual_300p.md", "tipo": "MD",
                                 "contenido": texto, "chars_totales": len(texto)})

        assert r["cobertura_pct"] >= 99.9
        assert len(r["contenido"]) <= _PRESUPUESTO_CONTEXTO * 1.15, (
            f"los resúmenes ocupan {len(r['contenido']):,} chars "
            f"(presupuesto {_PRESUPUESTO_CONTEXTO:,}) — el prompt los truncará"
        )


# ═════════════════════════════════════════════════════════════════════════════
# 13. Parser de Estandares_VIRF.xlsx  [D5 — auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestParserEstandares:
    """
    El Excel tiene una estructura peculiar que el parser debe respetar:
      · Columna A totalmente vacía (separador visual)
      · Cabecera en la fila 2, no en la 1
      · ÁMBITO y CONTROL con celdas fusionadas → forward-fill hacia abajo
      · Columnas TIER I..IV marcadas con "X"

    Estos tests fijan ese contrato y cubren los 4 escenarios de fragilidad
    detectados en la auditoría.
    """

    @staticmethod
    def _parsear(filas, tier="1"):
        """Parsea un Excel sintético redirigiendo RUTAS temporalmente."""
        import tempfile
        from openpyxl import Workbook
        import Mx_00_CargaRutas as mx00
        import Mx_01_LecturaEvidencias as mx01

        tmp = Path(tempfile.mkdtemp()) / "E.xlsx"
        wb = Workbook()
        ws = wb.active
        ws.title = "Hoja1"
        for f in filas:
            ws.append(f)
        wb.save(tmp)

        orig = mx00.RUTAS["estandares_virf"]
        mx00.RUTAS["estandares_virf"] = tmp
        try:
            return mx01.leer_estandares_virf(tier) or {}
        finally:
            mx00.RUTAS["estandares_virf"] = orig

    # Estructura idéntica a la del Excel real
    BASE = [
        [None, None, None, None, None, None, None, None],
        [None, "AMBITO", "CONTROL CUANTITATIVO Y CUALITATIVO", "ACTIVIDAD",
         "TIER I", "TIER II", "TIER III", "TIER IV"],
        [None, "Documentación", "Ctrl doc", "Actividad uno", "X", "X", None, None],
        [None, None, None, "Actividad dos", "X", None, None, None],
        [None, "Metodología", "Ctrl met", "Actividad tres", "X", None, "X", None],
        [None, None, None, "Actividad cuatro", None, "X", None, None],
    ]

    def test_el_excel_real_cumple_los_invariantes_estructurales(self):
        """
        Invariantes que debe cumplir CUALQUIER versión válida del estándar.

        [REDISEÑO 2026-07-30] Antes esto fijaba conteos literales
        (`{"1": 15, "2": 12, "3": 17, "4": 11}`). Era frágil por dos motivos:

          · el estándar CAMBIA con naturalidad —es un documento vivo que la
            entidad mantiene—, así que el test se rompía en cada revisión
            legítima;
          · y cuando se rompía, el arreglo evidente era actualizar el número,
            con lo que la supuesta protección se evaporaba justo el día en que
            el criterio de validación cambiaba de verdad.

        Un test no puede ser el mecanismo de control de versiones del estándar.
        Aquí se comprueba lo que NO puede variar sin romper el sistema; la
        trazabilidad de QUÉ versión se aplicó vive en la huella del informe
        (`agente.estandar`), que es donde un auditor la busca.
        """
        from modulos.motor_ia import leer_estandares_virf
        from config import AMBITO_PESOS

        por_tier = {t: leer_estandares_virf(t) for t in ("1", "2", "3", "4")}

        for tier, datos in por_tier.items():
            assert datos, f"Tier {tier}: el estándar no se pudo leer"

            # 1. Los ámbitos leídos deben tener peso asignado. Un ámbito
            #    desconocido pesaría 0 y sus actividades no contarían para el
            #    score global — se evaluarían y se tirarían, sin aviso.
            desconocidos = set(datos) - set(AMBITO_PESOS)
            assert not desconocidos, (
                f"Tier {tier}: ámbitos sin peso en AMBITO_PESOS {desconocidos}. "
                f"Sus actividades se evaluarían pero no contarían para el score.")

            # 2. Toda actividad necesita texto: sin él no hay nada que preguntar.
            for ambito, acts in datos.items():
                for a in acts:
                    assert str(a.get("actividad", "")).strip(), (
                        f"Tier {tier} / {ambito}: actividad sin texto")

            # 3. Ningún par (CONTROL, ACTIVIDAD) duplicado.
            #
            #    La clave incluye el CONTROL a propósito. El estándar real
            #    repite el mismo texto de actividad bajo controles distintos
            #    —«Verifica la existencia de control de cambios/versiones»
            #    aparece tres veces en Documentación, una por agrupador— y eso
            #    es legítimo: es el mismo chequeo aplicado al manual, al script
            #    y a los datos. El prompt incluye el control, así que el modelo
            #    tiene contexto para distinguirlos.
            #
            #    Lo que sí sería un fallo es el par completo repetido: ahí se
            #    evaluaría dos veces lo mismo con el mismo contexto, duplicando
            #    coste y descuadrando el promedio del ámbito.
            for ambito, acts in datos.items():
                pares = [(str(a.get("control", "")).strip().lower(),
                          str(a["actividad"]).strip().lower()) for a in acts]
                duplicados = {p for p in pares if pares.count(p) > 1}
                assert not duplicados, (
                    f"Tier {tier} / {ambito}: par (control, actividad) duplicado "
                    f"{list(duplicados)[:1]} — se evaluaría dos veces con el "
                    f"mismo contexto")

            # 4. Cada tier debe exigir ALGO. Un tier con cero requeridas
            #    produciría un informe sin ninguna actividad evaluada.
            req = sum(1 for v in datos.values() for a in v if a.get("requerida"))
            assert req > 0, (
                f"Tier {tier}: ninguna actividad requerida. El informe saldría "
                f"vacío y el score sería no evaluable.")

        # 5. El filtro por tier tiene que DISCRIMINAR. Si los cuatro tiers
        #    exigen lo mismo, el tiering no está haciendo nada y un modelo
        #    sencillo se evalúa con el rigor de uno crítico (o al revés).
        conteos = {t: sum(1 for v in d.values() for a in v if a.get("requerida"))
                   for t, d in por_tier.items()}
        assert len(set(conteos.values())) > 1, (
            f"todos los tiers exigen lo mismo ({conteos}): el filtro por tier "
            f"no discrimina y el tiering es decorativo")

        # 6. El total de actividades es el mismo en todos los tiers: cambia
        #    QUÉ se exige, no el catálogo.
        totales = {t: sum(len(v) for v in d.values()) for t, d in por_tier.items()}
        assert len(set(totales.values())) == 1, (
            f"el catálogo de actividades varía entre tiers {totales}: el tier "
            f"debe filtrar cuáles son requeridas, no cuáles existen")

    def test_forward_fill_de_ambito_es_intencional(self):
        """
        Las celdas de ÁMBITO están FUSIONADAS en el Excel: solo la primera fila
        de cada grupo lleva el nombre. El forward-fill es deliberado, no un bug.
        """
        r = self._parsear(self.BASE)
        assert set(r) == {"Documentación", "Metodología"}
        assert len(r["Documentación"]) == 2, "la 2ª fila debe heredar 'Documentación'"
        assert len(r["Metodología"]) == 2

    def test_tolera_columnas_reordenadas(self):
        """
        [F1] El forward-fill estaba fijado a los índices (0,1) ANTES de saber
        dónde estaba cada columna. Reordenar el Excel rompía la herencia de
        ÁMBITO y las filas se descartaban en silencio.
        """
        reordenado = [
            [None, None, None, None, None],
            [None, "ACTIVIDAD", "AMBITO", "CONTROL", "TIER I"],
            [None, "Actividad uno", "Documentación", "Ctrl doc", "X"],
            [None, "Actividad dos", None, None, "X"],
            [None, "Actividad tres", "Metodología", "Ctrl met", "X"],
        ]
        r = self._parsear(reordenado)
        assert set(r) == {"Documentación", "Metodología"}
        assert len(r["Documentación"]) == 2, "la fila 2 debe heredar el ámbito"

    def test_falla_explicito_si_falta_columna_obligatoria(self, capsys):
        """
        [F2] Al renombrar ACTIVIDAD, el parser caía al índice fijo 2 y tomaba
        la columna CONTROL como actividad: datos erróneos SIN ningún error.

        Ahora lanza ValueError con el detalle. `leer_estandares_virf` la captura
        y devuelve vacío; `agente.py` corta la ejecución con un mensaje claro
        en vez de evaluar con datos inventados.
        """
        renombrado = [
            [None, None, None, None, None],
            [None, "AMBITO", "CONTROL", "DESCRIPCION DEL REQUERIMIENTO", "TIER I"],
            [None, "Documentación", "Ctrl doc", "Actividad uno", "X"],
        ]
        r = self._parsear(renombrado)
        salida = capsys.readouterr().out

        assert not r, "debe devolver vacío en vez de datos erróneos"
        assert "ACTIVIDAD" in salida or "columnas obligatorias" in salida, (
            f"el error debe nombrar la columna que falta. Salida: {salida[:200]}"
        )

    def test_descarta_filas_espurias(self):
        """
        [F4] El forward-fill hace que CUALQUIER fila posterior herede el último
        ámbito. Totales y notas al pie entraban como actividades reales.
        """
        con_basura = list(self.BASE) + [
            [None, None, None, "TOTAL GENERAL", None, None, None, None],
            [None, None, None, "Notas al pie del documento", None, None, None, None],
            [None, None, None, "Fuente: elaboración propia", None, None, None, None],
        ]
        r = self._parsear(con_basura)
        actividades = [a["actividad"] for v in r.values() for a in v]
        assert len(actividades) == 4, f"entraron filas espurias: {actividades}"
        assert not any(x in " ".join(actividades) for x in ("TOTAL", "Notas", "Fuente"))

    def test_avisa_si_falta_la_columna_tier(self, capsys):
        """
        [F3] Sin columna TIER el filtro desaparecía en silencio: las 21
        actividades se marcaban requeridas para CUALQUIER tier, alterando el
        score. Ahora el comportamiento se mantiene (no hay con qué filtrar)
        pero se avisa de forma visible.
        """
        sin_tier = [
            [None, None, None, None],
            [None, "AMBITO", "CONTROL", "ACTIVIDAD"],
            [None, "Documentación", "Ctrl doc", "Actividad uno"],
            [None, None, None, "Actividad dos"],
        ]
        r = self._parsear(sin_tier)
        salida = capsys.readouterr().out
        assert "filtro por tier" in salida.lower() or "tier" in salida.lower(), (
            "la ausencia de la columna TIER debe avisarse de forma visible"
        )
        assert all(a["requerida"] for v in r.values() for a in v)

    def test_columna_a_vacia_no_se_confunde_con_ambito(self):
        """
        El parser localiza ÁMBITO por su CABECERA, no por posición de columna.

        En el Excel real la columna A está vacía (separador visual) y la
        cabecera vive en la fila 2, así que un parser posicional tomaría la
        columna equivocada. Aquí se comprueba contra el fichero REAL.

        [REDISEÑO 2026-07-30] Ni el nombre de la hoja ni el número de ámbitos
        se fijan literalmente: el estándar es un documento vivo y la entidad
        puede renombrar la pestaña o reorganizar los ámbitos con naturalidad.
        Se localiza la hoja de actividades por su contenido y se contrasta con
        AMBITO_PESOS, que es la fuente de verdad de qué ámbitos existen.
        """
        import openpyxl
        from config import AMBITO_PESOS
        from modulos.motor_ia import leer_estandares_virf

        wb = openpyxl.load_workbook(RAIZ / "inputs" / "Estandares_VIRF.xlsx")
        # Hoja de actividades = la que tiene cabecera con ACTIVIDAD y TIER.
        hoja = next(
            (h for h in wb.sheetnames
             if any("actividad" in str(c).lower()
                    for fila in wb[h].iter_rows(max_row=5, values_only=True)
                    for c in fila if c)
             and any("tier" in str(c).lower()
                     for fila in wb[h].iter_rows(max_row=5, values_only=True)
                     for c in fila if c)),
            None)
        assert hoja, "no se encontró ninguna hoja de actividades en el estándar"

        ws = wb[hoja]
        filas = [list(f) for f in ws.iter_rows(values_only=True)]
        cab = next(i for i, f in enumerate(filas)
                   if any("actividad" in str(v).lower() for v in f if v))
        col_amb = next(i for i, v in enumerate(filas[cab])
                       if v and "ambito" in str(v).lower().replace("á", "a"))
        assert col_amb != 0, (
            f"ÁMBITO está en la columna A de '{hoja}': este test comprueba que "
            f"el parser NO depende de la posición, así que necesita un fichero "
            f"donde la columna A no sea el ámbito")

        # El parser debe encontrarlo igualmente, y devolver ámbitos conocidos.
        datos = leer_estandares_virf("1")
        assert datos, "el parser no pudo leer el estándar real"
        assert set(datos) <= set(AMBITO_PESOS), (
            f"ámbitos sin peso asignado: {set(datos) - set(AMBITO_PESOS)}")
        assert len(datos) >= 2, "el parser solo reconoció un ámbito"

    def test_sin_codigo_paralelo_huerfano(self):
        """
        [D3 — auditoría 2026-07-27] La evaluación paralela se retiró: nadie la
        llamaba, sacrificaba la memoria intra-ámbito, no propagaba
        `cobertura_docs` y ante un error inventaba `puntaje: 1` — el antipatrón
        que [CONTRATO-FIX] eliminó.
        """
        import modulos.motor_ia as m
        for f in ("evaluar_ambito_paralelo", "evaluar_todos_ambitos_paralelo",
                  "_evaluar_actividad_thread_safe", "orquestar_pipeline_ambitos"):
            assert not hasattr(m, f), f"{f} volvió a aparecer sin conectarse al flujo"

    def test_all_no_exporta_funciones_inexistentes(self):
        """__all__ debe reflejar lo que el módulo realmente define."""
        import modulos.motor_ia as m
        faltan = [x for x in m.__all__ if not hasattr(m, x)]
        assert not faltan, f"__all__ exporta símbolos inexistentes: {faltan}"


# ═════════════════════════════════════════════════════════════════════════════
# 14. PDF real de 300+ páginas  [D1 — auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestPDFReal:
    """
    Validación sobre un PDF REAL (no texto sintético) de 305 páginas con
    estructura compleja: dos columnas, tablas que cruzan página, headers y
    footers repetidos, y notas al pie.

    Usa el fixture de sesión `pdf_real`: la extracción (~70 s) se hace UNA vez.
    Se salta si el PDF no está. Regenerable con scratchpad/gen_pdf.py
    """

    def test_extraccion_integra_sin_truncar(self, pdf_real):
        """El PDF debe llegar entero: nada de truncar a MAX_CHARS_DOC."""
        assert pdf_real["truncado"] is False
        assert len(pdf_real["contenido"]) == pdf_real["chars_totales"]
        assert pdf_real["chars_totales"] > 1_000_000

    def test_ninguna_seccion_se_pierde_en_la_extraccion(self, pdf_real):
        """400 secciones con marcador único: todas deben sobrevivir al parseo."""
        import re
        texto = pdf_real["contenido"]
        inicio = {int(m) for m in re.findall(r"MARCADOR-UNICO-(\d{3})-INICIO", texto)}
        fin = {int(m) for m in re.findall(r"MARCADOR-UNICO-(\d{3})-FIN", texto)}
        assert len(inicio) == 400, f"faltan {400 - len(inicio)} marcadores INICIO"
        assert len(fin) == 400, f"faltan {400 - len(fin)} marcadores FIN"

    def test_las_tablas_sobreviven_completas(self, pdf_real):
        """Las tablas cruzan página: no deben perderse filas ni mezclarse columnas."""
        import re
        texto = pdf_real["contenido"]
        assert len(re.findall(r"Tabla \d+\.1", texto)) == 400
        assert len(re.findall(r"Indicador \d+\.\d+", texto)) == 7200

    def test_chunking_cubre_el_100_por_ciento(self, pdf_real, capsys):
        """Un PDF de 1,3 M chars debe procesarse íntegro, no truncarse."""
        from modulos.chunker import ChunkerService
        r = ChunkerService(cliente_ia=ClienteRealista()).procesar_doc(pdf_real)
        capsys.readouterr()
        assert r["cobertura_pct"] >= 99.9, f"cobertura {r['cobertura_pct']}%"

    def test_resumen_cabe_en_el_presupuesto(self, pdf_real, capsys):
        """
        [D1-FIX] Con el PDF real, tras 3 niveles de consolidación el resumen
        seguía en 19.817 chars frente a un presupuesto de 9.000. Los tests
        sintéticos no lo detectaron: su cliente devolvía texto de tamaño fijo
        e ignoraba max_tokens.
        """
        from modulos.chunker import ChunkerService, _PRESUPUESTO_CONTEXTO
        r = ChunkerService(cliente_ia=ClienteRealista()).procesar_doc(pdf_real)
        capsys.readouterr()
        assert len(r["contenido"]) <= _PRESUPUESTO_CONTEXTO * 1.2, (
            f"el resumen ocupa {len(r['contenido']):,} chars; el prompt lo recortará"
        )

    def test_no_hay_segmentos_vacios_ni_anomalos(self, pdf_real):
        """Ningún segmento puede quedar vacío o absurdamente corto."""
        from modulos.chunker import ChunkerService
        chunks = ChunkerService(cliente_ia=ClienteSimulado())._dividir_en_chunks(
            pdf_real["contenido"])
        assert not [c for c in chunks if not c.strip()]
        assert not [c for c in chunks if 0 < len(c.strip()) < 500]


# ═════════════════════════════════════════════════════════════════════════════
# 15. Caché de resúmenes de chunking  [D2 — auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestCacheResumenes:
    """
    Resumir un manual de 305 páginas cuesta ~$0.90 USD (63 llamadas).
    `document_cache` solo guardaba el texto CRUDO, así que ese gasto se repetía
    íntegro en cada corrida aunque el documento no hubiera cambiado.
    """

    DOC = {"nombre": "m.md", "tipo": "MD",
           "contenido": "Metodologia LaR EWMA 0.94. " * 3000,
           "chars_totales": 27 * 3000}

    def test_segunda_corrida_no_llama_al_llm(self, tmp_path, capsys):
        from modulos.chunker import ChunkerService

        c1 = ClienteSimulado()
        r1 = ChunkerService(cliente_ia=c1, cache_dir=tmp_path).procesar_doc(dict(self.DOC))
        c2 = ClienteSimulado()
        r2 = ChunkerService(cliente_ia=c2, cache_dir=tmp_path).procesar_doc(dict(self.DOC))
        capsys.readouterr()

        assert c1.llamadas > 0, "la 1ª corrida debe resumir"
        assert c2.llamadas == 0, f"la 2ª corrida hizo {c2.llamadas} llamadas: el caché no sirvió"
        assert r1["contenido"] == r2["contenido"], "el resumen cacheado difiere"
        assert r1["cobertura_pct"] == r2["cobertura_pct"]

    def test_documento_modificado_invalida_el_cache(self, tmp_path, capsys):
        """Si el documento cambia, hay que volver a resumirlo."""
        from modulos.chunker import ChunkerService

        ChunkerService(cliente_ia=ClienteSimulado(), cache_dir=tmp_path
                       ).procesar_doc(dict(self.DOC))
        modificado = dict(self.DOC)
        modificado["contenido"] += " PÁRRAFO NUEVO AÑADIDO."
        c2 = ClienteSimulado()
        ChunkerService(cliente_ia=c2, cache_dir=tmp_path).procesar_doc(modificado)
        capsys.readouterr()
        assert c2.llamadas > 0, "un documento modificado debe re-resumirse"

    def test_cambiar_la_configuracion_invalida_el_cache(self, tmp_path, capsys):
        """Si cambia cómo se segmenta, los resúmenes anteriores no valen."""
        from modulos.chunker import ChunkerService

        ChunkerService(cliente_ia=ClienteSimulado(), cache_dir=tmp_path,
                       chunk_size=12000).procesar_doc(dict(self.DOC))
        c2 = ClienteSimulado()
        ChunkerService(cliente_ia=c2, cache_dir=tmp_path,
                       chunk_size=6000).procesar_doc(dict(self.DOC))
        capsys.readouterr()
        assert c2.llamadas > 0, "cambiar chunk_size debe invalidar el caché"

    def test_sin_cache_dir_funciona_igual(self, capsys):
        """El caché es opcional: sin cache_dir el chunker opera normalmente."""
        from modulos.chunker import ChunkerService
        r = ChunkerService(cliente_ia=ClienteSimulado()).procesar_doc(dict(self.DOC))
        capsys.readouterr()
        assert r["cobertura_pct"] == 100.0

    def test_escritura_del_cache_es_atomica(self, tmp_path, capsys):
        """No deben quedar .tmp residuales."""
        from modulos.chunker import ChunkerService
        ChunkerService(cliente_ia=ClienteSimulado(), cache_dir=tmp_path
                       ).procesar_doc(dict(self.DOC))
        capsys.readouterr()
        assert not list(tmp_path.glob("*.tmp")), "quedaron ficheros temporales"
        assert (tmp_path / "chunk_summaries_cache.json").exists()


# ═════════════════════════════════════════════════════════════════════════════
# 16. Acantilado de coste del modo jerárquico  [D2 — auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestAcantiladoDeCoste:
    """
    Bajar VIRF_MAX_CHUNKS parece un ahorro, pero por debajo de cierto punto el
    segmento adaptativo necesario supera VIRF_CHUNK_SIZE_MAX, el chunker cae al
    modo jerárquico puro y procesa TODOS los segmentos de CHUNK_SIZE.

    Medido sobre el PDF real de 305 páginas (1.302.266 chars):
        MAX_CHUNKS=40 → adaptativo,  43 llamadas, $1,14
        MAX_CHUNKS=30 → jerárquico, 120 llamadas, $2,27   (+99%)

    El coste sube al bajar el límite. Estos tests fijan ese comportamiento y
    verifican que el usuario recibe un aviso accionable en vez de silencio.
    """

    # ~1,3 M chars, como el PDF real de 305 páginas
    TEXTO = "Metodologia LaR EWMA 0.94 Kupiec p=0.021 backtesting. " * 24000

    def _doc(self):
        return {"nombre": "manual.pdf", "tipo": "PDF",
                "contenido": self.TEXTO, "chars_totales": len(self.TEXTO)}

    def test_bajar_el_limite_dispara_mas_llamadas_no_menos(self, capsys):
        """El ahorro aparente es real: menos límite ⇒ MÁS llamadas al LLM."""
        from modulos.chunker import ChunkerService

        c40 = ClienteSimulado()
        ChunkerService(cliente_ia=c40, max_chunks=40).procesar_doc(self._doc())
        c30 = ClienteSimulado()
        ChunkerService(cliente_ia=c30, max_chunks=30).procesar_doc(self._doc())
        capsys.readouterr()

        assert c30.llamadas > c40.llamadas, (
            f"se esperaba el acantilado: 30→{c30.llamadas} llamadas debería "
            f"superar a 40→{c40.llamadas}"
        )

    def test_el_acantilado_avisa_con_umbral_accionable(self, capsys):
        """
        Antes esto era un logger.info neutro: el usuario duplicaba el coste sin
        enterarse. Ahora debe decir explícitamente qué valor lo evita.
        """
        from modulos.chunker import ChunkerService
        ChunkerService(cliente_ia=ClienteSimulado(), max_chunks=30
                       ).procesar_doc(self._doc())
        salida = capsys.readouterr().out

        assert "AVISO DE COSTE" in salida, "el salto de coste no se avisa"
        assert "VIRF_MAX_CHUNKS>=" in salida, "no se indica el mínimo que lo evita"
        assert "VIRF_CHUNK_SIZE_MAX>=" in salida, "no se ofrece la alternativa"

    def test_el_modo_adaptativo_no_avisa(self, capsys):
        """El aviso es solo para el acantilado; no debe ensuciar el caso normal."""
        from modulos.chunker import ChunkerService
        ChunkerService(cliente_ia=ClienteSimulado(), max_chunks=40
                       ).procesar_doc(self._doc())
        assert "AVISO DE COSTE" not in capsys.readouterr().out

    def test_la_cobertura_sigue_al_100_en_ambos_lados(self, capsys):
        """El acantilado es de COSTE, no de cobertura: D1 no debe regresar."""
        from modulos.chunker import ChunkerService
        for mc in (30, 40):
            r = ChunkerService(cliente_ia=ClienteSimulado(), max_chunks=mc
                               ).procesar_doc(self._doc())
            capsys.readouterr()
            assert r["cobertura_pct"] >= 99.9, (
                f"max_chunks={mc} perdió cobertura: {r['cobertura_pct']}%"
            )

    def test_el_default_esta_por_encima_del_acantilado(self):
        """
        El default de VIRF_MAX_CHUNKS debe permitir el modo adaptativo en un
        manual de 300 págs (~600k chars); si no, cada corrida paga de más.
        """
        import math
        from modulos.chunker import (
            _MAX_CHUNKS, _MAX_CHUNK_SIZE_ADAPTATIVO, _CHUNK_OVERLAP,
        )
        minimo = math.ceil(600_000 / (_MAX_CHUNK_SIZE_ADAPTATIVO - _CHUNK_OVERLAP))
        assert _MAX_CHUNKS >= minimo, (
            f"VIRF_MAX_CHUNKS={_MAX_CHUNKS} cae por debajo del acantilado "
            f"(mínimo {minimo}): un manual de 300 págs costaría el doble"
        )


# ═════════════════════════════════════════════════════════════════════════════
# 17. Consola a prueba de codificación  [auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestConsolaUnicode:
    """
    El proyecto imprime emoji en 19 módulos. En una consola cp1252 (default en
    Windows español) eso abortaba `agente.py` con UnicodeEncodeError a mitad del
    chunking, con la extracción del PDF y varias llamadas IA ya pagadas.

    Estos tests no lo detectaban porque pytest captura stdout en UTF-8: por eso
    fabrican explícitamente un flujo cp1252 en vez de confiar en el del runner.
    """

    EMOJI = "\U0001f4d0 CHUNKING ✅ ⚠️ \U0001f3d7️"

    @staticmethod
    def _flujo_cp1252():
        import io
        return io.TextIOWrapper(io.BytesIO(), encoding="cp1252",
                                line_buffering=True)

    def test_reproduce_el_fallo_sin_configurar(self):
        """Si esto deja de fallar, el test ya no prueba nada: sería un falso verde."""
        flujo = self._flujo_cp1252()
        with pytest.raises(UnicodeEncodeError):
            flujo.write(self.EMOJI)

    def test_configurar_consola_evita_el_crash(self, monkeypatch):
        from modulos import consola
        flujo = self._flujo_cp1252()
        monkeypatch.setattr(sys, "stdout", flujo)
        monkeypatch.setattr(consola, "_YA_CONFIGURADA", False)

        consola.configurar_consola()
        print(self.EMOJI)          # no debe lanzar

    def test_stderr_tambien_queda_protegido(self, monkeypatch):
        """El fallo original venía por stdout, pero stderr imprime los ❌."""
        from modulos import consola
        flujo = self._flujo_cp1252()
        monkeypatch.setattr(sys, "stderr", flujo)
        monkeypatch.setattr(consola, "_YA_CONFIGURADA", False)

        consola.configurar_consola()
        print(self.EMOJI, file=sys.stderr)

    def test_flujo_sin_reconfigure_degrada_sin_romper(self, monkeypatch):
        """
        pytest-capture, redirect_stdout y algunos IDEs sustituyen sys.stdout por
        objetos sin `.reconfigure`. Ahí no se puede forzar UTF-8: lo que no puede
        pasar es que reviente.
        """
        import io
        from modulos import consola

        class SinReconfigure:
            encoding = "cp1252"

            def __init__(self):
                self.buffer = io.BytesIO()

            def write(self, s):
                self.buffer.write(s.encode("cp1252"))
                return len(s)

            def flush(self):
                pass

        monkeypatch.setattr(sys, "stdout", SinReconfigure())
        monkeypatch.setattr(consola, "_YA_CONFIGURADA", False)
        consola.configurar_consola()
        print(self.EMOJI)

    def test_es_idempotente(self, monkeypatch):
        from modulos import consola
        monkeypatch.setattr(consola, "_YA_CONFIGURADA", False)
        consola.configurar_consola()
        consola.configurar_consola()
        consola.configurar_consola()

    def test_nunca_propaga_excepciones(self, monkeypatch):
        """
        Es un bootstrap: si el propio arreglo puede tumbar el arranque, es peor
        que el problema que resuelve.
        """
        from modulos import consola

        class Hostil:
            encoding = "cp1252"

            def __getattr__(self, nombre):
                raise RuntimeError(f"flujo hostil: {nombre}")

        monkeypatch.setattr(sys, "stdout", Hostil())
        monkeypatch.setattr(sys, "stderr", Hostil())
        monkeypatch.setattr(consola, "_YA_CONFIGURADA", False)
        consola.configurar_consola()      # no debe lanzar

    def test_los_entrypoints_configuran_la_consola(self):
        """
        Regresión de cableado: de nada sirve el módulo si el entrypoint no lo
        llama. Además debe hacerlo ANTES del primer print.
        """
        for entry in ("agente.py", "validate_project.py"):
            fuente = (RAIZ / entry).read_text(encoding="utf-8")
            assert "configurar_consola()" in fuente, (
                f"{entry} no llama a configurar_consola(): en una consola "
                f"cp1252 volverá a abortar con UnicodeEncodeError"
            )
            assert fuente.index("configurar_consola()") < fuente.index("print("), (
                f"{entry} imprime antes de configurar la consola"
            )


# ═════════════════════════════════════════════════════════════════════════════
# 18. Central de configuración  [auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestConfigCentral:
    """
    La configuración estaba repartida y duplicada: chunker.py y Mx_01
    declaraban los mismos VIRF_CHUNK_*, config.py y Mx_00 los mismos
    MAX_CHARS_*, y VIRF_MAX_CTX aparecía en tres sitios con dos defaults.

    Peor: Mx_00 tenía MAX_CHARS_DOC = 15000 como LITERAL, así que ponerlo en
    .env cambiaba config.py pero no Mx_00, que seguía truncando a 15000.
    """

    def test_config_py_no_coexiste_con_el_paquete(self):
        """
        Un config.py junto a config/ queda MUERTO sin avisar: Python resuelve
        los paquetes antes que los módulos. Si alguien lo restaura, el proyecto
        cargaría el paquete creyendo leer el fichero.
        """
        assert (RAIZ / "config").is_dir(), "falta el paquete config/"
        assert not (RAIZ / "config.py").exists(), (
            "config.py ha reaparecido: el paquete lo ensombrece y quedaría muerto"
        )

    def test_base_dir_apunta_a_la_raiz_no_a_config(self):
        """
        Al mover la configuración a config/, un `Path(__file__).parent` heredado
        habría apuntado a config/ y TODAS las rutas del proyecto (inputs,
        outputs, caché, estándares) quedarían desplazadas un nivel.
        """
        import config
        assert config.BASE_DIR == RAIZ, f"BASE_DIR={config.BASE_DIR}"
        assert config.ESTANDARES_PATH.exists(), "ESTANDARES_PATH no resuelve"
        assert config.BASE_DIR.name != "config"

    def test_ningun_modulo_redeclara_parametros_de_negocio(self):
        """
        Ningún módulo fuera de config/ debe volver a llamar a os.getenv para un
        parámetro de negocio: eso es lo que permitía la divergencia.
        """
        import re
        permitidos = re.compile(
            r"ANTHROPIC_API_KEY|AZURE_OPENAI_(API_KEY|ENDPOINT|DEPLOYMENT)"
            r"|IA_PROVEEDOR|ANTHROPIC_MODELO"
        )
        infractores = []
        # Carpetas que NO son código del agente:
        # - archivo/, tests/: excluidas históricamente por diseño.
        # - config/: es precisamente el destino centralizado.
        # - web/: capa de interfaz (VIRF Web pasos 1-10); sus banderas de
        #   modo (VIRF_MOCK_CHAT, etc.) son infra de front, no negocio.
        # - .venv/, site-packages/: dependencias del intérprete, no
        #   código del proyecto. Su presencia depende del entorno de
        #   desarrollo — antes ni existía en esta checkout.
        _excluidas = {"archivo", "config", "tests", "web",
                      ".venv", "venv", "site-packages", "__pycache__"}
        for py in RAIZ.rglob("*.py"):
            partes = py.parts
            if any(p in _excluidas for p in partes):
                continue
            if any(p.startswith(".") for p in partes):
                continue
            for i, linea in enumerate(py.read_text(encoding="utf-8",
                                                   errors="ignore").splitlines(), 1):
                if "getenv(" in linea and not linea.strip().startswith("#"):
                    if not permitidos.search(linea):
                        infractores.append(f"{py.relative_to(RAIZ)}:{i}")
        assert not infractores, (
            "parámetros declarados fuera de config/parametros.py: " + ", ".join(infractores)
        )

    def test_un_cambio_de_entorno_llega_a_todos_los_modulos(self, monkeypatch):
        """
        La prueba de fuego: MAX_CHARS_DOC en el entorno debe verse igual en
        config y en Mx_00. Antes divergían (99999 vs 15000 literal).
        """
        import subprocess
        codigo = (
            "import sys; sys.path.insert(0,'motor');"
            "import config, Mx_00_CargaRutas as mx00;"
            "from modulos import chunker;"
            "from motor import Mx_01_LecturaEvidencias as mx01;"
            "assert config.MAX_CHARS_DOC == mx00.MAX_CHARS_DOC == 99999, "
            "  f'{config.MAX_CHARS_DOC} != {mx00.MAX_CHARS_DOC}';"
            "assert chunker._CHUNK_SIZE == mx01._CHUNK_SIZE;"
            "assert chunker._MAX_CHUNKS == 55;"
            "print('OK')"
        )
        entorno = {**os.environ, "MAX_CHARS_DOC": "99999",
                   "VIRF_MAX_CHUNKS": "55", "PYTHONIOENCODING": "utf-8"}
        r = subprocess.run([sys.executable, "-c", codigo], cwd=str(RAIZ),
                           env=entorno, capture_output=True, text=True)
        assert r.returncode == 0, f"la configuración diverge:\n{r.stdout}\n{r.stderr}"

    def test_la_api_publica_se_mantiene(self):
        """Los 16 `from config import X` del proyecto deben seguir resolviendo."""
        import config
        for simbolo in (
            "BASE_DIR", "ESTANDARES_PATH", "OUTPUTS_DIR", "AUDIT_LOGS_DIR",
            "INPUTS", "REPOSITORIO_INFORMES", "MAX_CHARS_DOC", "MAX_CHARS_CODIGO",
            "MAX_FILAS_EXCEL", "TIMEOUT_SEGUNDOS", "REINTENTOS_API",
            "IA_PROVEEDOR", "MODO", "TIER_COLUMNS", "AMBITO_PESOS",
            "AMBITO_PESOS_REFS", "ESCALA_PUNTAJE", "SCORE_SEMAFORO",
            "PREGUNTAS_METODOLOGICAS", "EXTENSIONES_SOPORTADAS",
            "get_cliente_ia", "reset_cliente_ia", "mostrar_configuracion",
            "ClienteIA", "ClienteAnthropicIA", "ClienteAzureOpenAIIA",
        ):
            assert hasattr(config, simbolo), f"config ya no expone {simbolo}"

    def test_los_submodulos_estan_separados_por_responsabilidad(self):
        """dominio.py no debe depender del entorno; parametros.py sí."""
        dominio = (RAIZ / "config" / "dominio.py").read_text(encoding="utf-8")
        assert "getenv" not in dominio, (
            "config/dominio.py son parámetros de negocio con trazabilidad "
            "regulatoria: no deben poder cambiarse con una variable de entorno"
        )


# ═════════════════════════════════════════════════════════════════════════════
# 19. Explicador de modelos  [auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestExplicadorModelo:
    """
    Flujo reutilizable que consolida las 4 fuentes de inputs/ en un documento
    explicativo. El riesgo de este servicio no es que falle: es que produzca un
    documento que PAREZCA completo y esté a medias o inventado.
    """

    @staticmethod
    def _fuentes(tmp_path, con_seguimiento=True):
        """Monta un inputs/ mínimo con las 4 carpetas."""
        for rel in ("inputs/documentacion/modelamiento",
                    "inputs/documentacion/seguimiento",
                    "inputs/implementacion", "inputs/calidad_datos"):
            (tmp_path / rel).mkdir(parents=True, exist_ok=True)
        (tmp_path / "inputs/documentacion/modelamiento/manual_XYZ.md").write_text(
            "# Manual XYZ\nVolatilidad EWMA 0.94.", encoding="utf-8")
        (tmp_path / "inputs/implementacion/impl_XYZ.md").write_text(
            "# Implementación XYZ", encoding="utf-8")
        # Deliberadamente SIN el nombre del modelo en el nombre del fichero:
        # es el caso que rompía el filtro por nombre.
        (tmp_path / "inputs/calidad_datos/manual_controles.md").write_text(
            "# Controles\nUnicidad de cuenta. Tolerancia 0.", encoding="utf-8")
        if con_seguimiento:
            (tmp_path / "inputs/documentacion/seguimiento/informe.md").write_text(
                "# Seguimiento\nKupiec p=0.021.", encoding="utf-8")
        return tmp_path

    def _explicador(self, base, **kw):
        from modulos.explicador_modelo import ExplicadorModelo
        return ExplicadorModelo(cliente_ia=None, base_dir=base, **kw)

    def test_no_descarta_evidencia_que_no_lleva_el_nombre_del_modelo(self, tmp_path):
        """
        REGRESIÓN: filtrar por nombre descartaba en silencio
        `manual_controles_datos.md` (el documento que describe TODOS los
        controles) porque no contenía 'LaR'. La sección 3 salía coja sin avisar.
        """
        base = self._fuentes(tmp_path)
        inv = self._explicador(base).inventariar("XYZ")
        nombres = [p.name for p in inv["calidad_datos"]["ficheros"]]
        assert "manual_controles.md" in nombres, (
            "se descartó evidencia por no llevar el nombre del modelo"
        )

    def test_solo_coincidentes_restringe_de_forma_explicita(self, tmp_path):
        """Cuando varios modelos comparten carpetas, el filtro es opt-in."""
        base = self._fuentes(tmp_path)
        inv = self._explicador(base, solo_coincidentes=True).inventariar("XYZ")
        nombres = [p.name for p in inv["calidad_datos"]["ficheros"]]
        assert nombres == ["manual_controles.md"], nombres  # no hay match: cae a todo
        meto = [p.name for p in inv["metodologia"]["ficheros"]]
        assert meto == ["manual_XYZ.md"], meto              # sí hay match: restringe

    def test_excluir_omite_ficheros_indicados(self, tmp_path):
        """Permite dejar fuera fixtures de prueba que viven en inputs/."""
        base = self._fuentes(tmp_path)
        inv = self._explicador(base, excluir=["manual_XYZ.md"]).inventariar("XYZ")
        assert not inv["metodologia"]["ficheros"]

    def test_una_fuente_vacia_se_declara_no_se_disimula(self, tmp_path):
        from modulos.explicador_modelo import ExplicadorModelo
        base = self._fuentes(tmp_path, con_seguimiento=False)
        inv = self._explicador(base).inventariar("XYZ")
        assert inv["seguimiento"]["ficheros"] == []

        texto = ExplicadorModelo._render_inventario(inv)
        assert "VACÍA" in texto and "sin evidencia" in texto.lower()

        evid = ExplicadorModelo._render_evidencia(inv, {"seguimiento": []})
        assert "SIN EVIDENCIA DISPONIBLE" in evid
        assert "No inventes" in evid

    def test_sin_ninguna_evidencia_falla_en_vez_de_inventar(self, tmp_path):
        (tmp_path / "inputs").mkdir()
        with pytest.raises(ValueError, match="No hay ninguna evidencia"):
            self._explicador(tmp_path).generar("FANTASMA", tmp_path / "out")

    def test_dry_run_no_llama_al_modelo_ni_escribe(self, tmp_path, capsys):
        base = self._fuentes(tmp_path)

        class ClienteQueFalla:
            def generar_mensaje(self, **kw):
                raise AssertionError("dry-run no debe llamar al modelo")

        from modulos.explicador_modelo import ExplicadorModelo
        ex = ExplicadorModelo(cliente_ia=ClienteQueFalla(), base_dir=base)
        salida = tmp_path / "out"
        assert ex.generar("XYZ", salida, dry_run=True) is None
        capsys.readouterr()
        assert not salida.exists(), "dry-run no debe escribir el documento"

    # ── La defensa que importa: detectar documentos a medias ────────────────

    def test_verificar_detecta_secciones_faltantes(self):
        from modulos.explicador_modelo import ExplicadorModelo
        doc = "# T\n## 1. Resumen\ntexto.\n## 2. Marco\ntexto."
        problemas = ExplicadorModelo.verificar(doc)
        assert any("faltan las secciones" in p for p in problemas)
        assert "9" in " ".join(problemas)

    def test_verificar_detecta_truncamiento_a_media_frase(self):
        """
        Las dos primeras corridas reales salieron truncadas al agotar
        max_tokens y el fichero se escribía igual. Sin esta comprobación,
        un documento a medias pasa por completo.
        """
        from modulos.explicador_modelo import ExplicadorModelo
        completo = "\n".join(f"## {n}. S{n}\ntexto." for n in range(1, 10))
        assert ExplicadorModelo.verificar(completo) == []

        cortado = completo[:-6] + "\n| **Rec"
        assert any("media frase" in p for p in ExplicadorModelo.verificar(cortado))

    def test_las_nueve_secciones_estan_en_los_bloques_del_prompt(self):
        """Ninguna sección puede quedar huérfana al trocear la generación."""
        from modulos.explicador_modelo import _BLOQUES
        specs = " ".join(b["spec"] for b in _BLOQUES)
        for n in range(1, 10):
            assert f"## {n}." in specs, f"la sección {n} no la pide ningún bloque"

    def test_un_fallo_de_api_conserva_lo_ya_generado(self, tmp_path, capsys):
        """
        Cada bloque es dinero ya gastado. Si el 2º falla (saldo agotado, rate
        limit, red), tirar el 1º y devolver un traceback obliga a pagarlo otra
        vez. Detectado en real: la API se quedó sin saldo a mitad de la prueba.
        """
        from modulos.explicador_modelo import ExplicadorModelo
        base = self._fuentes(tmp_path)

        class ClienteQueMuereAlSegundo:
            def __init__(self):
                self.llamadas = 0

            def generar_mensaje(self, **kw):
                self.llamadas += 1
                if self.llamadas >= 2:
                    raise RuntimeError("credit balance is too low")
                return "## 1. Resumen\nprimer bloque válido."

        cli = ClienteQueMuereAlSegundo()
        destino = ExplicadorModelo(cliente_ia=cli, base_dir=base).generar(
            "XYZ", tmp_path / "out")
        capsys.readouterr()

        assert destino is not None and destino.exists(), (
            "un fallo a mitad no debe perder los bloques ya pagados"
        )
        texto = destino.read_text(encoding="utf-8")
        assert "primer bloque válido" in texto, "se perdió el bloque ya generado"
        assert "DOCUMENTO INCOMPLETO" in texto, "no se avisa de que está parcial"
        assert "credit balance" in texto, "no se registra la causa del fallo"


# ═════════════════════════════════════════════════════════════════════════════
# 20. Genericidad del explicador — 4 familias de modelo  [auditoría 2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestExplicadorEsAgnosticoAlModelo:
    """
    El explicador se construyó y se probó SOLO con LaR. El riesgo es que su
    prompt y su catálogo de supuestos quedaran acoplados al vocabulario de ese
    modelo (EWMA, retornos de flujos, horizonte 30d) sin que se note.

    Estos tests fijan la genericidad contra 4 familias deliberadamente
    distintas en vocabulario y estructura matemática. Son OFFLINE: no llaman a
    la API, así que corren siempre.
    """

    FIXTURES = RAIZ / "tests" / "fixtures" / "modelos_sinteticos"
    MODELOS = ("PD_Retail", "FraudeAML", "IFRS9_Provisiones")

    # Vocabulario privativo de LaR que no debe aparecer en el andamiaje
    JERGA_LAR = ("EWMA", "Kupiec", "Christoffersen", "Liquidity at Risk",
                 "retornos de flujos", "2.326", "0.94")

    def test_los_fixtures_de_las_tres_familias_existen(self):
        """Sin fixtures no hay prueba de genericidad; deben estar versionados."""
        for m in self.MODELOS:
            carpeta = self.FIXTURES / m
            assert carpeta.is_dir(), f"falta el fixture {m}"
            for fuente in ("documentacion/modelamiento", "documentacion/seguimiento",
                           "implementacion", "calidad_datos"):
                d = carpeta / "inputs" / fuente
                assert d.is_dir() and any(d.iterdir()), (
                    f"{m}: la fuente {fuente} está vacía"
                )

    def test_el_andamiaje_no_contiene_jerga_de_LaR(self):
        """
        REGRESIÓN: el prompt traía el ejemplo numérico 'si la cartera vale
        S/ 1,000,000 y el LaR sale 3.5%…', que sesgaba al modelo hacia el
        encuadre de LaR en cualquier familia.
        """
        import modulos.explicador_modelo as em
        andamiaje = em._PROMPT + em._render_supuestos() + \
            " ".join(b["spec"] for b in em._BLOQUES)
        for termino in self.JERGA_LAR:
            assert termino not in andamiaje, (
                f"'{termino}' es vocabulario de LaR y está en el prompt: "
                f"contamina la documentación de cualquier otro modelo"
            )
        # 'LaR' como palabra suelta (no dentro de 'declarado', 'particular'…)
        assert not re.search(r"\bLaR\b", andamiaje), "'LaR' aparece en el prompt"

    @pytest.mark.parametrize("modelo", MODELOS)
    def test_cada_familia_se_inventaria_completa(self, modelo):
        """Las 4 fuentes deben poblarse para cualquier familia, no solo LaR."""
        from modulos.explicador_modelo import ExplicadorModelo
        ex = ExplicadorModelo(cliente_ia=None, base_dir=self.FIXTURES / modelo)
        inv = ex.inventariar(modelo)
        vacias = [i["titulo"] for i in inv.values() if not i["ficheros"]]
        assert not vacias, f"{modelo}: fuentes sin evidencia → {vacias}"

    @pytest.mark.parametrize("modelo", MODELOS)
    def test_el_prompt_de_cada_familia_lleva_su_propia_evidencia(self, modelo, capsys):
        """
        El prompt debe contener el vocabulario del modelo documentado y NINGÚN
        término privativo de LaR.
        """
        from modulos.explicador_modelo import ExplicadorModelo
        ex = ExplicadorModelo(cliente_ia=None, base_dir=self.FIXTURES / modelo)
        inv = ex.inventariar(modelo)
        docs = ex._leer(inv)
        evidencia = ExplicadorModelo._render_evidencia(inv, docs)
        capsys.readouterr()

        esperado = {
            "PD_Retail": ("WOE", "logistica", "Information Value"),
            "FraudeAML": ("Isolation Forest", "GAFI", "ROS"),
            "IFRS9_Provisiones": ("ECL", "Stage 2", "LGD"),
        }[modelo]
        for t in esperado:
            assert t in evidencia, f"{modelo}: falta '{t}' en la evidencia"

        for termino in ("EWMA", "Kupiec", "Christoffersen"):
            assert termino not in evidencia, (
                f"{modelo}: se coló evidencia de LaR ('{termino}')"
            )

    # ── El catálogo de supuestos ─────────────────────────────────────────────

    def test_el_catalogo_cubre_las_familias_de_riesgo_habituales(self):
        from modulos.explicador_modelo import _SUPUESTOS_VIGILADOS
        for familia in ("series_temporales", "clasificacion_scoring",
                        "perdida_esperada", "deteccion_anomalias",
                        "datos_comun_a_todos"):
            assert familia in _SUPUESTOS_VIGILADOS, f"falta la familia {familia}"

    def test_cada_familia_del_catalogo_tiene_disparador_y_puntos(self):
        """Sin disparador, el modelo no sabe cuándo aplicarla — y la aplicaría siempre."""
        from modulos.explicador_modelo import _SUPUESTOS_VIGILADOS
        for nombre, fam in _SUPUESTOS_VIGILADOS.items():
            assert fam.get("disparador"), f"{nombre} sin disparador"
            assert fam.get("vigilar"), f"{nombre} sin puntos a vigilar"

    def test_los_supuestos_clave_por_familia_estan_vigilados(self):
        """
        Cada familia debe vigilar lo que le es propio. Si esto falla, el
        catálogo se escribió mirando solo a LaR.
        """
        from modulos.explicador_modelo import _SUPUESTOS_VIGILADOS as CAT
        esperado = {
            "clasificacion_scoring": ("PSI", "Balance de clases",
                                      "Multicolinealidad", "Punto de corte"),
            "deteccion_anomalias":   ("falsos positivos", "Umbral de alerta"),
            "perdida_esperada":      ("Forward-looking", "Calibración",
                                      "Segmentación"),
            "series_temporales":     ("Estacionariedad", "Autocorrelación"),
            "datos_comun_a_todos":   ("Missing", "Outliers"),
        }
        for familia, terminos in esperado.items():
            texto = " ".join(CAT[familia]["vigilar"])
            for t in terminos:
                assert t.lower() in texto.lower(), (
                    f"{familia} no vigila '{t}'"
                )

    def test_el_catalogo_es_extensible_sin_tocar_la_logica(self):
        """
        Añadir una familia debe ser añadir una entrada al diccionario. Si la
        lógica tuviera if/else por tipo de modelo, esto no bastaría.
        """
        import modulos.explicador_modelo as em
        original = dict(em._SUPUESTOS_VIGILADOS)
        try:
            em._SUPUESTOS_VIGILADOS["familia_nueva_de_prueba"] = {
                "disparador": "una condición inventada",
                "vigilar": ["Un supuesto nuevo a vigilar"],
            }
            render = em._render_supuestos()
            assert "familia_nueva_de_prueba" in render
            assert "Un supuesto nuevo a vigilar" in render
        finally:
            em._SUPUESTOS_VIGILADOS.clear()
            em._SUPUESTOS_VIGILADOS.update(original)

    def test_el_catalogo_llega_al_prompt_con_su_regla_de_seleccion(self):
        """
        Volcar el catálogo sin la regla de selección haría que el modelo
        aplicara PSI a un modelo de liquidez. La regla es la mitad del diseño.
        """
        import modulos.explicador_modelo as em
        assert "{supuestos}" in em._PROMPT, "el catálogo no se inyecta"
        assert "ÚNICAMENTE las familias" in em._PROMPT
        assert "NO fuerces familias" in em._PROMPT


# ═════════════════════════════════════════════════════════════════════════════
# 21. Hallazgos de la auditoría exhaustiva  [2026-07-27]
# ═════════════════════════════════════════════════════════════════════════════

class TestAuditoriaSinEvidenciaEsFaltaCriticaNoAusenciaDeDictamen:
    """
    POLÍTICA DE LA ENTIDAD [fijada el 2026-07-29].

    La FALTA DE EVIDENCIA es una falta crítica: el validado tenía la obligación
    de aportar documentación y no lo hizo. Puntúa 0.0, entra en el promedio con
    su peso íntegro y arrastra el score global.

    Un FALLO TÉCNICO del agente (timeout de la API, PDF ilegible, JSON roto) NO
    es imputable al validado: se excluye del score, se renormalizan los pesos y
    se reporta aparte. Condenar un modelo porque se cayó nuestra red produciría
    un dictamen indefendible ante el regulador.

    El semáforo distingue ambas causas por su nombre, aunque el 0.0 conserve la
    severidad crítica: el lector tiene que poder saber POR QUÉ no hay nota.

    Historia: una corrección anterior de esta auditoría hizo que la ausencia de
    evidencia devolviera None y quedara EXCLUIDA del promedio — es decir, no
    penalizaba en absoluto. Eso invertía la política de la entidad. Esta clase
    fija el comportamiento correcto para que no vuelva a ocurrir en ninguna de
    las dos direcciones.
    """

    AMBITOS = ("Documentación", "Calidad de datos", "Metodología",
               "Gobierno", "Implementación", "Uso e integración a la gestión")

    # ── El 0.0 es un valor inequívoco ────────────────────────────────────────

    def test_una_evaluacion_real_nunca_puede_dar_cero(self):
        # Es lo que permite que get_semaforo() rotule el 0.0 por su causa sin
        # necesitar un parámetro extra: la escala de puntuación empieza en 1.
        from config import ESCALA_PUNTAJE
        assert min(ESCALA_PUNTAJE) >= 1, (
            "la escala ya no empieza en 1: el 0.0 deja de significar "
            "inequívocamente «sin evidencia» y el semáforo puede confundir "
            "una nota real con una ausencia de documentación")

    # ── Ámbito ───────────────────────────────────────────────────────────────

    def test_ambito_sin_evidencia_puntua_cero(self):
        from modulos.motor_ia import calcular_score_ambito
        evs = [{"sin_evidencia": True, "puntaje": None},
               {"sin_evidencia": True, "puntaje": None}]
        assert calcular_score_ambito(evs) == 0.0

    def test_ambito_con_fallo_tecnico_no_puntua(self):
        from modulos.motor_ia import calcular_score_ambito
        evs = [{"evaluacion_valida": False, "puntaje": None},
               {"evaluacion_valida": False, "puntaje": None}]
        assert calcular_score_ambito(evs) is None, (
            "un fallo del agente se está imputando al validado")

    def test_la_actividad_sin_evidencia_arrastra_el_promedio_del_ambito(self):
        from modulos.motor_ia import calcular_score_ambito
        evs = [{"puntaje": 4}, {"sin_evidencia": True, "puntaje": None}]
        assert calcular_score_ambito(evs) == 2.0, "el 0.0 no está promediando"

    def test_la_actividad_con_fallo_tecnico_no_arrastra_el_promedio(self):
        from modulos.motor_ia import calcular_score_ambito
        evs = [{"puntaje": 4}, {"evaluacion_valida": False, "puntaje": None}]
        assert calcular_score_ambito(evs) == 4.0

    def test_el_fallo_tecnico_gana_a_la_marca_de_sin_evidencia(self):
        # Si una evaluación llega con ambas marcas, no se puede acusar al
        # validado: prevalece la causa no imputable.
        from modulos.motor_ia import calcular_score_ambito
        evs = [{"puntaje": 4},
               {"sin_evidencia": True, "evaluacion_valida": False, "puntaje": None}]
        assert calcular_score_ambito(evs) == 4.0

    # ── Score global ─────────────────────────────────────────────────────────

    def test_un_ambito_sin_evidencia_arrastra_el_global_con_su_peso(self):
        from modulos.motor_ia import calcular_score_global
        base = {"Documentación": 3.25, "Calidad de datos": 3.60,
                "Metodología": 2.60, "Implementación": 2.00,
                "Uso e integración a la gestión": 4.00}
        sin_ev = calcular_score_global({**base, "Gobierno": 0.0})
        tecnico = calcular_score_global({**base, "Gobierno": None})
        assert sin_ev < tecnico, (
            f"la ausencia de evidencia no penaliza ({sin_ev}) frente al fallo "
            f"técnico ({tecnico}): los pesos se están renormalizando en el caso "
            f"que la política considera falta crítica")
        # Gobierno pesa 0.12 y el denominador debe seguir siendo 1.00.
        esperado = round(sum(base[a] * p for a, p in
                             [("Documentación", .15), ("Calidad de datos", .20),
                              ("Metodología", .30), ("Implementación", .15),
                              ("Uso e integración a la gestión", .08)]), 2)
        assert abs(sin_ev - esperado) < 0.01, (
            "el denominador ya no es 1.00: el peso del ámbito ausente se está "
            "redistribuyendo en vez de penalizar")

    def test_sin_ninguna_evidencia_el_global_es_cero(self):
        from modulos.motor_ia import calcular_score_global
        assert calcular_score_global(dict.fromkeys(self.AMBITOS, 0.0)) == 0.0

    def test_si_todo_fallo_tecnicamente_no_hay_dictamen(self):
        from modulos.motor_ia import calcular_score_global
        assert calcular_score_global(dict.fromkeys(self.AMBITOS)) is None
        assert calcular_score_global({}) is None

    # ── Semáforo: la causa debe ser legible ──────────────────────────────────

    def test_el_semaforo_nombra_la_causa_en_ambos_casos(self):
        from modulos.motor_ia import get_semaforo
        sin_ev = get_semaforo(0.0)["label"].upper()
        tecnico = get_semaforo(None)["label"].upper()
        assert "SIN EVIDENCIA" in sin_ev, sin_ev
        assert "FALLO" in tecnico or "TÉCNICO" in tecnico, tecnico
        assert sin_ev != tecnico, (
            "las dos causas comparten etiqueta: el lector no puede saber si "
            "faltó documentación o si se cayó la herramienta")

    def test_la_falta_de_evidencia_conserva_severidad_critica(self):
        # Se rotula por su causa, pero NO se disfraza de «pendiente»: la
        # política la considera una falta crítica y el color lo refleja.
        from modulos.motor_ia import get_semaforo
        assert get_semaforo(0.0)["color"] == "FF0000"
        assert get_semaforo(None)["color"] == "CCCCCC"

    # ── Informe Word ─────────────────────────────────────────────────────────

    def test_el_informe_distingue_las_dos_causas(self):
        from modulos.generador_word import (
            _normalizar_score, _puntaje_label, _puntaje_color_hex,
            _status_resultado, _label_semaforo, _score_color_hex,
        )
        assert _normalizar_score(0) == 0, "el 0 vuelve a elevarse a 1"
        assert _normalizar_score(None) is None

        assert "SIN EVIDENCIA" in _puntaje_label(0).upper()
        assert "TÉCNICO" in _puntaje_label(None).upper()
        assert _puntaje_color_hex(0) == "FF0000"
        assert _puntaje_color_hex(None) == "CCCCCC"

        # El campo que el auditor lee como resultado no puede quedar mudo.
        assert _status_resultado(0) not in ("", "SIN CLASIFICAR")
        assert "SIN EVIDENCIA" in _status_resultado(0).upper()

        assert "SIN EVIDENCIA" in _label_semaforo(0.0).upper()
        assert "TÉCNICO" in _label_semaforo(None).upper()
        assert _score_color_hex(0.0) == "FF0000"

    def test_la_observacion_automatica_no_confunde_al_responsable(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "modulos"
               / "generador_word.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
        assert "FALTA\n" in vivas or "FALTA " in vivas, "falta el texto de la política"
        assert "elif puntaje_act == 0:" in vivas, (
            "el informe ya no distingue la actividad sin evidencia: volverá a "
            "recibir «No cumple con los criterios», que atribuye un "
            "incumplimiento nunca comprobado, o «fallo técnico», que exculpa "
            "al validado de una falta que sí es suya")

    def test_ningun_consumidor_revienta_al_formatear_none(self):
        """Los 4 sitios que formateaban score_global con .2f."""
        from modulos.generador_word import _label_semaforo, _score_color_hex
        assert _score_color_hex(None) == "CCCCCC"
        assert _label_semaforo(None)
        for fichero, patron in (
            ("agente.py", "score_global is None"),
            ("modulos/generador_word.py", "score_global is not None"),
            ("modulos/motor_ia.py", "_score_txt"),
        ):
            fuente = (RAIZ / fichero).read_text(encoding="utf-8")
            assert patron in fuente, f"{fichero} no guarda el caso None"


class TestAuditoriaCachePersisteEnSalidasTempranas:
    """
    BUG ALTO. `cerrar_cache()` vivía solo en el `finally` de agente.py, cuyo
    `try` empieza en la línea ~433 — DESPUÉS de los ocho `return` tempranos.
    Medido: `--explicar-modelo` leía 5 documentos nuevos y persistía 0; el
    caché se quedaba en 6 entradas y la corrida siguiente volvía a extraer
    (35 s en el PDF de 305 págs).
    """

    def test_agente_registra_el_cierre_con_atexit(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "atexit.register(cerrar_cache)" in fuente, (
            "sin atexit, los modos que retornan temprano no persisten el caché"
        )
        # y debe registrarse justo tras inicializar, no al final
        assert fuente.index("atexit.register(cerrar_cache)") < fuente.index("if args.listar_motores")

    def test_cerrar_cache_es_idempotente(self, tmp_path, capsys):
        """atexit + el finally existente lo llaman dos veces."""
        from modulos import document_cache as dc
        # [AUDIT-FIX] Este test dejaba `_instancia_global` apuntando a un caché
        # HABILITADO sobre un tmp_path que pytest borra después. Los tests
        # posteriores que llaman a `leer_archivo` heredaban ese caché y leían
        # entradas de otra prueba: cuatro fallos que solo aparecían al correr la
        # suite completa, nunca en aislamiento. Se restaura el estado previo.
        _previa = dc._instancia_global
        try:
            dc._reset_cierre_para_tests()
            dc.inicializar_cache(cache_dir=tmp_path, enabled=True)
            dc.cerrar_cache()
            primera = capsys.readouterr().out
            dc.cerrar_cache()
            segunda = capsys.readouterr().out
            assert primera, "la primera llamada debe imprimir el resumen"
            assert not segunda, "la segunda no debe reimprimirlo"
        finally:
            dc._reset_cierre_para_tests()
            dc._instancia_global = _previa


class TestAuditoriaCoberturaDocumentalNoSeInfla:
    """
    BUG ALTO. El comentario decía «cobertura ponderada por tamaño» y el código
    hacía una MEDIA ARITMÉTICA SIMPLE, ignorando además los documentos que se
    caían por saturación de contexto.

    Esa cifra viaja al prompt de evaluación (`cobertura_docs=cobertura_ambito`),
    así que inflarla le hacía creer al modelo que había visto mucho más de lo
    que vio — y el auditor leía un porcentaje de cobertura falso.
    """

    @staticmethod
    def _ponderada(cobertura_docs, docs):
        vistos = sum(ch * pct / 100.0 for _, pct, _, ch in cobertura_docs)
        total = sum(d["chars_totales"] for d in docs)
        return round(vistos / total * 100, 1) if total else 0.0

    def test_un_anexo_pequeno_no_compensa_un_manual_mal_cubierto(self):
        cobertura_docs = [("anexo.md", 100.0, "directo", 2_000),
                          ("manual.pdf", 30.0, "jerarquico", 600_000)]
        docs = [{"chars_totales": 2_000}, {"chars_totales": 600_000}]

        media_simple = round(
            sum(c for _, c, _, _ in cobertura_docs) / len(cobertura_docs), 1)
        ponderada = self._ponderada(cobertura_docs, docs)

        assert media_simple == 65.0          # lo que reportaba antes
        assert ponderada < 35.0              # lo que el evaluador vio de verdad
        assert media_simple - ponderada > 30, (
            "la media simple sobreestimaba la cobertura en >30 puntos"
        )

    def test_documentos_fuera_de_contexto_cuentan_como_cero(self):
        """3 docs completos de 10 no son 100% de cobertura del ámbito."""
        cobertura_docs = [(f"d{i}.md", 100.0, "directo", 1_000) for i in range(3)]
        docs = [{"chars_totales": 1_000} for _ in range(10)]
        assert self._ponderada(cobertura_docs, docs) == 30.0

    def test_agente_pondera_y_no_promedia(self):
        """Fija el fix en el código: la fórmula debe usar los chars."""
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "_chars_vistos" in fuente and "_chars_totales_ambito" in fuente, (
            "agente.py volvió a la media aritmética simple"
        )
        assert "sum(c for _, c, _ in cobertura_docs) / len(cobertura_docs)" not in fuente


class TestAuditoriaRespuestaVaciaDeLaAPI:
    """
    BUG MEDIO. `response.content[0].text` sin proteger. La API responde 200 con
    `content=[]` cuando el modelo rehúsa (stop_reason="refusal") o cuando
    max_tokens no deja sitio. El IndexError salía disfrazado de
    «❌ Error Anthropic: list index out of range» — que parece un fallo de red
    y no dice nada útil al operador.
    """

    class _RespuestaVacia:
        content = []
        stop_reason = "refusal"

    class _BloqueSinTexto:
        type = "tool_use"

    def _cliente(self, respuesta):
        from config.ia import ClienteAnthropicIA
        cli = ClienteAnthropicIA.__new__(ClienteAnthropicIA)   # sin __init__/API key
        cli.modelo = "claude-haiku-4-5"
        cli.max_tokens_default = 1000

        class _API:
            class messages:
                @staticmethod
                def create(**kw):
                    return respuesta
        cli.cliente = _API()
        return cli

    def test_content_vacio_da_mensaje_accionable(self):
        cli = self._cliente(self._RespuestaVacia())
        with pytest.raises(RuntimeError) as e:
            cli.generar_mensaje(prompt="hola")
        msg = str(e.value)
        assert "VACÍA" in msg, msg
        assert "refusal" in msg, "no se informa el stop_reason"
        assert "list index out of range" not in msg

    def test_bloque_sin_campo_text_no_revienta_con_attributeerror(self):
        class R:
            content = [TestAuditoriaRespuestaVaciaDeLaAPI._BloqueSinTexto()]
            stop_reason = "tool_use"
        with pytest.raises(RuntimeError, match="sin campo"):
            self._cliente(R()).generar_mensaje(prompt="hola")


class TestAuditoriaEnvMalformadoNoTumbaElArranque:
    """
    BUG MEDIO. 24 conversiones `int(os.getenv(...))` a pelo. Un typo en .env
    (MAX_CHARS_DOC=abc, o "12.000" con separador de miles) reventaba el import
    de `config` con un ValueError crudo, antes de que el agente imprimiera
    nada: el usuario veía un fallo del programa, no un error de su .env.
    """

    def test_valor_no_numerico_usa_el_defecto_y_avisa(self, capsys):
        from config.parametros import _entero
        assert _entero("__NO_EXISTE__", 15000) == 15000
        import os
        os.environ["__AUDIT_TEST__"] = "abc"
        try:
            assert _entero("__AUDIT_TEST__", 15000) == 15000
            assert "no es un número válido" in capsys.readouterr().out
        finally:
            del os.environ["__AUDIT_TEST__"]

    def test_valor_bajo_el_minimo_se_rechaza(self, capsys):
        import os
        from config.parametros import _entero
        os.environ["__AUDIT_TEST__"] = "-5"
        try:
            assert _entero("__AUDIT_TEST__", 40) == 40
            assert "mínimo admitido" in capsys.readouterr().out
        finally:
            del os.environ["__AUDIT_TEST__"]

    def test_cero_es_valido_donde_significa_sin_limite(self):
        """MAX_DOCS_AMBITO=0 es 'sin límite', no un error de configuración."""
        import os
        from config.parametros import _entero
        os.environ["__AUDIT_TEST__"] = "0"
        try:
            assert _entero("__AUDIT_TEST__", 0, minimo=0) == 0
        finally:
            del os.environ["__AUDIT_TEST__"]

    def test_no_quedan_conversiones_sin_proteger(self):
        import re
        fuente = (RAIZ / "config" / "parametros.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        crudas = re.findall(r'(?:int|float)\(os\.getenv', codigo)
        assert not crudas, f"{len(crudas)} conversiones sin proteger"

    def test_los_defaults_no_cambiaron(self):
        """El blindaje no debe alterar ningún valor efectivo."""
        import config
        assert config.MAX_CHARS_DOC == 15000
        assert config.MAX_CTX == 15000
        assert config.MAX_DOCS_AMBITO == 0
        assert config.CHUNK_SIZE == 12000
        assert config.CHUNK_THRESHOLD == 12000
        assert config.MAX_CHUNKS == 40
        assert config.PRESUPUESTO_DOC == 9000
        assert config.CACHE_ENABLED is True
        assert config.CHUNK_ENABLED is True


class TestAuditoriaUmbralAntisesgoUnificado:
    """
    BUG ALTO. Había DOS guardias anti-sesgo descoordinadas y solo una visible:

      · bloque de calibración del prompt → VIRF_MIN_FEEDBACK_ANTISESGO (15)
      · ajuste NUMÉRICO del puntaje      → MIN_MUESTRAS = 3, hardcodeado

    La intervención más directa sobre el dictamen tenía el guardia más débil.
    Medido: 3 muestras con diferencia +2 subían un puntaje de 2.0 a 2.8, que
    redondea a 3 — un punto entero sobre una escala de 5. Y quien subiera
    VIRF_MIN_FEEDBACK_ANTISESGO creyendo endurecer el sistema no cambiaba nada.
    """

    ACT = "validar supuestos del modelo"

    @staticmethod
    def _historial(n, diferencia=2.0):
        return [{"ambito": "Metodología", "actividad": TestAuditoriaUmbralAntisesgoUnificado.ACT,
                 "diferencia": diferencia} for _ in range(n)]

    def _ajustar(self, n):
        from unittest.mock import patch
        import modulos.feedback_mejorado as fm
        with patch.object(fm, "cargar_historial", lambda: self._historial(n)):
            return fm.ajustar_puntaje_por_feedback("Metodología", self.ACT, 2.0)

    def test_el_umbral_ya_no_esta_hardcodeado(self):
        """Mira CÓDIGO, no comentarios: el comentario del fix cita el literal viejo."""
        fuente = (RAIZ / "modulos" / "feedback_mejorado.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert "MIN_MUESTRAS = 3" not in codigo, "el umbral volvió a estar hardcodeado"
        assert "MIN_MUESTRAS_AJUSTE" in codigo

    def test_ambas_guardias_comparten_umbral_por_defecto(self):
        from config.parametros import MIN_FEEDBACK_ANTISESGO, MIN_MUESTRAS_AJUSTE
        assert MIN_MUESTRAS_AJUSTE == MIN_FEEDBACK_ANTISESGO, (
            "la guardia del ajuste numérico no puede ser más débil que la del prompt"
        )

    def test_tres_muestras_ya_no_mueven_el_puntaje(self):
        """El caso concreto que se midió: 3 muestras cambiaban el dictamen."""
        puntaje, desc = self._ajustar(3)
        assert puntaje == 2.0, f"3 muestras siguen ajustando: {desc}"
        assert "insuficiente" in desc.lower()

    def test_con_masa_critica_si_ajusta(self):
        """El mecanismo debe seguir funcionando cuando hay evidencia suficiente."""
        from config.parametros import MIN_MUESTRAS_AJUSTE
        puntaje, desc = self._ajustar(MIN_MUESTRAS_AJUSTE)
        assert puntaje > 2.0, f"con masa crítica debería ajustar: {desc}"

    def test_el_ajuste_sigue_acotado_a_un_punto(self):
        """Ni con feedback extremo puede mover más de ±1 punto."""
        from unittest.mock import patch
        import modulos.feedback_mejorado as fm
        with patch.object(fm, "cargar_historial",
                          lambda: self._historial(100, diferencia=99.0)):
            puntaje, _ = fm.ajustar_puntaje_por_feedback("Metodología", self.ACT, 2.0)
        assert puntaje <= 3.0, f"el ajuste rompió la cota ±1: {puntaje}"


class TestAuditoriaColumnaControlOpcional:
    """
    BUG ALTO. `leer_estandares_virf` declara en su código que la columna CONTROL
    es OPCIONAL, y el primer forward-fill lo respeta. Pero había un SEGUNDO
    forward-fill duplicado, sin esa guarda, que hacía `len(fila) > col_ctrl`
    con col_ctrl=None.

    Reproducido con cabecera ÁMBITO|ACTIVIDAD|TIER_I: TypeError, tragado por el
    `except` de arriba y presentado como «Verificar estructura del Excel» —
    cuando la estructura era válida según la propia documentación del parser.
    """

    @staticmethod
    def _excel(tmp_path, cabecera, filas):
        import openpyxl
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "VIRF"
        ws.append(cabecera)
        for f in filas:
            ws.append(f)
        p = tmp_path / "Estandares_VIRF.xlsx"
        wb.save(p)
        return p

    @staticmethod
    def _leer(ruta, tier="1"):
        import sys
        sys.path.insert(0, str(RAIZ / "motor"))
        import Mx_00_CargaRutas as mx00
        import Mx_01_LecturaEvidencias as mx01
        prev = mx01.RUTAS["estandares_virf"]
        mx00.RUTAS["estandares_virf"] = str(ruta)
        mx01.RUTAS["estandares_virf"] = str(ruta)
        try:
            return mx01.leer_estandares_virf(tier)
        finally:
            mx00.RUTAS["estandares_virf"] = prev
            mx01.RUTAS["estandares_virf"] = prev

    def test_excel_sin_columna_control_no_revienta(self, tmp_path, capsys):
        p = self._excel(tmp_path, ["ÁMBITO", "ACTIVIDAD", "TIER_I"],
                        [["Documentación", "Existe manual metodologico", "X"],
                         ["Metodología", "Se validan supuestos", "X"]])
        r = self._leer(p)
        capsys.readouterr()
        assert r, "el Excel sin CONTROL devolvió vacío (el TypeError se tragaba)"
        assert set(r) == {"Documentación", "Metodología"}
        # CONTROL ausente ⇒ cadena vacía, según el contrato del parser
        assert all(a["control"] == "" for acts in r.values() for a in acts)

    def test_el_forward_fill_de_control_sigue_funcionando(self, tmp_path, capsys):
        """Las celdas fusionadas de CONTROL deben seguir propagándose."""
        p = self._excel(tmp_path, ["ÁMBITO", "CONTROL", "ACTIVIDAD", "TIER_I"],
                        [["Documentación", "C1", "Existe manual", "X"],
                         [None, None, "Existe manual operativo", "X"]])
        r = self._leer(p)
        capsys.readouterr()
        controles = [a["control"] for a in r["Documentación"]]
        assert controles == ["C1", "C1"], controles

    def test_no_quedan_accesos_sin_guardar_a_col_ctrl(self):
        fuente = (RAIZ / "motor" / "Mx_01_LecturaEvidencias.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert "len(fila) > col_ctrl:" not in codigo, (
            "volvió el forward-fill duplicado sin guarda de col_ctrl=None"
        )


class TestAuditoriaNombresDeAmbitoCoherentes:
    """
    RIESGO. Los 6 nombres de ámbito se escriben a mano en CINCO sitios. Uno de
    ellos, `_RELACIONES_AMBITO` en motor_ia.py, degrada EN SILENCIO si diverge:
    la memoria inter-ámbito deja de inyectarse y no salta ningún error, solo se
    pierde la detección de contradicciones entre ámbitos.
    """

    @staticmethod
    def _relaciones():
        import ast
        fuente = (RAIZ / "modulos" / "motor_ia.py").read_text(encoding="utf-8")
        for nodo in ast.walk(ast.parse(fuente)):
            if isinstance(nodo, ast.Assign):
                for t in nodo.targets:
                    if isinstance(t, ast.Name) and t.id == "_RELACIONES_AMBITO":
                        return ast.literal_eval(nodo.value)
        raise AssertionError("no se encontró _RELACIONES_AMBITO")

    def test_las_claves_coinciden_con_ambito_pesos(self):
        from config import AMBITO_PESOS
        assert set(self._relaciones()) == set(AMBITO_PESOS)

    def test_los_ambitos_relacionados_existen(self):
        """Un nombre mal escrito aquí no da error: solo deja de inyectar contexto."""
        from config import AMBITO_PESOS
        rel = self._relaciones()
        desconocidos = {v for lst in rel.values() for v in lst} - set(AMBITO_PESOS)
        assert not desconocidos, (
            f"ámbitos relacionados inexistentes {desconocidos}: la memoria "
            f"inter-ámbito se degrada en silencio"
        )

    def test_ningun_ambito_se_relaciona_consigo_mismo(self):
        rel = self._relaciones()
        auto = [a for a, rels in rel.items() if a in rels]
        assert not auto, f"{auto} se relacionan consigo mismos"


class TestAuditoriaCoberturaDocumentalVsPrompt:
    """
    BUG MEDIO. `generar_resumen_ejecutivo` anunciaba «La cobertura DOCUMENTAL
    promedio fue X%» calculándola desde `cobertura_contexto`, que mide otra
    cosa: la fracción del contexto que cupo en el prompt.

    El propio módulo distingue ambas métricas explícitamente, así que la
    etiqueta contradecía al código. Caso delator: un manual cubierto al 30% por
    el chunker cuyo resumen sí cabe entero en el prompt → cobertura_contexto=1.0
    → el informe afirmaba «cobertura documental 100%». Falsa tranquilidad, y
    justo en el apartado de LIMITACIONES del informe ejecutivo.
    """

    def test_las_dos_metricas_no_se_confunden(self):
        fuente = (RAIZ / "modulos" / "motor_ia.py").read_text(encoding="utf-8")
        bloque = fuente.split("def generar_resumen_ejecutivo")[1][:3000]
        assert "cobertura_documental" in bloque, (
            "el resumen ejecutivo no mira la cobertura documental real"
        )
        # El texto que afirma 'documental' no puede salir de cobertura_contexto
        assert 'DOCUMENTAL promedio' in bloque or "cobertura DOCUMENTAL" in bloque
        assert "PROMPT" in bloque, "no se distingue la cobertura de prompt"

    def test_un_resumen_que_cabe_no_implica_documento_leido(self):
        """Reproduce el caso delator con la fórmula real del módulo."""
        evals = {"Metodología": [{"cobertura_contexto": 1.0,
                                  "cobertura_documental": 30.0}]}

        def _media(clave, escala):
            vals = [e.get(clave) for ev in evals.values() for e in ev
                    if e.get(clave) is not None]
            return round(sum(vals) / len(vals) / escala, 3) if vals else None

        prompt = _media("cobertura_contexto", 1.0)
        documental = _media("cobertura_documental", 100.0)

        assert prompt == 1.0, "el resumen cupo entero en el prompt"
        assert documental == 0.3, "solo se leyó un tercio del manual"
        assert documental < 0.7, "debe disparar el aviso de limitaciones"
        assert prompt != documental, (
            "si se usan indistintamente, el informe miente sobre la cobertura"
        )


class TestAuditoriaCoberturaDeControlNoUsaMaximo:
    """
    BUG MEDIO. `evaluar_control` calculaba
    `cobertura = max(cobertura_manual, cobertura_script)`.

    El máximo infla: un script de 50 líneas leído entero (1.0) tapaba un manual
    de 300 páginas truncado al 30%, y el control reportaba «cobertura_docs:
    100%» sobre la evidencia que de verdad pesa. Medido: 69,8 puntos
    porcentuales de sobreestimación.

    Tercer caso del mismo patrón en el proyecto (los otros dos: la media simple
    de agente.py y la confusión documental/prompt del resumen ejecutivo).
    """

    def test_el_maximo_ya_no_se_usa(self):
        fuente = (RAIZ / "modulos" / "motor_ia_v2.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert "cobertura = max(" not in codigo, "volvió el máximo"
        assert "cobertura_detalle" in codigo, "no se desglosa manual vs script"

    def test_un_script_corto_no_tapa_un_manual_truncado(self):
        cob_manual, len_manual = 0.30, 600_000
        cob_script, len_script = 1.00, 2_000

        maximo = max(cob_manual, cob_script)
        ponderada = ((cob_manual * len_manual + cob_script * len_script)
                     / (len_manual + len_script))

        assert maximo == 1.0, "el máximo reportaba cobertura total"
        assert ponderada < 0.35, "la ponderada refleja lo realmente leído"
        assert (maximo - ponderada) > 0.6, "la inflación superaba 60 puntos"

    def test_sin_evidencia_la_cobertura_es_cero_no_divide_por_cero(self):
        for lm, ls in ((0, 0), (100, 0), (0, 100)):
            total = lm + ls
            cob = ((0.5 * lm + 0.5 * ls) / total) if total > 0 else 0.0
            assert 0.0 <= cob <= 1.0


class TestAuditoriaFiltradoDeControles:
    """
    Dos defectos en `evaluar_todos_controles`, ambos por inconsistencia con el
    código vecino del mismo bloque.
    """

    def test_el_filtro_de_ambito_tolera_columna_vacia(self, tmp_path):
        """
        BUG MEDIO. Los filtros de ACTIVO y TIER usan `.astype(str)`; el de
        AMBITO no. Con la columna AMBITO presente pero vacía, pandas la lee como
        float64 y `.str` lanza «Can only use .str accessor with string values».
        """
        import openpyxl
        import pandas as pd

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Controles"
        ws.append(["ID_CONTROL", "AMBITO", "PROMPT_CONTROL", "ACTIVO", "TIER"])
        ws.append(["C1", None, "Verificar unicidad", "1", "I"])
        p = tmp_path / "ControlesData.xlsx"
        wb.save(p)

        df = pd.read_excel(p, sheet_name="Controles")
        assert df["AMBITO"].dtype != object, "el caso solo aplica a columna no-str"

        # Sin astype reventaba; con astype no
        with pytest.raises(AttributeError):
            df[df["AMBITO"].str.lower() == "calidad de datos"]
        filtrado = df[df["AMBITO"].astype(str).str.strip().str.lower()
                      == "calidad de datos"]
        assert len(filtrado) == 0

    def test_el_codigo_usa_astype_en_el_filtro_de_ambito(self):
        fuente = (RAIZ / "modulos" / "motor_ia_v2.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert 'df_config["AMBITO"].str.lower()' not in codigo, (
            "el filtro de AMBITO volvió a usar .str sin astype"
        )

    def test_el_contador_de_progreso_no_supera_el_total(self):
        """
        BUG BAJO. `iterrows()` devuelve el índice ORIGINAL del Excel. Tras
        filtrar deja de ser contiguo y el progreso mostraba «[7/5]», «[9/5]».
        """
        import pandas as pd
        df = pd.DataFrame({"ID_CONTROL": [f"C{i}" for i in range(10)],
                           "TIER": ["I", "II"] * 5})
        filtrado = df[df["TIER"] == "I"]
        assert list(filtrado.index) == [0, 2, 4, 6, 8], "índices ya contiguos"

        posiciones = [pos for pos, _ in enumerate(filtrado.iterrows(), start=1)]
        assert posiciones == [1, 2, 3, 4, 5]
        assert max(posiciones) <= len(filtrado), "el contador excede el total"

    def test_el_codigo_enumera_en_vez_de_usar_el_indice(self):
        fuente = (RAIZ / "modulos" / "motor_ia_v2.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert "{idx+1}/{len(df_config)}" not in codigo
        assert "enumerate(df_config.iterrows()" in codigo


class TestAuditoriaSinEvidenciaNoEsFalloTecnico:
    """
    BUG ALTO — gemelo del score_global 0.00 → CRÍTICO, en el pipeline por control.

    `evaluar_todos_controles` agrupaba «todo lo que no es OK» en
    `controles_error`, así que un control PARTIAL (sin evidencia) contaba como
    fallo. Con todos los controles sin documentos, `_err == _total` daba estado
    "ERROR" y el mensaje «El dictamen NO es concluyente hasta resolver los
    fallos»: se acusaba al sistema de estar roto cuando lo que faltaba era la
    evidencia. Diagnóstico y remediación equivocados.

    Segundo defecto del mismo bloque: los hallazgos solo se acumulaban en la
    rama OK, así que hallazgos críticos ya extraídos desaparecían del recuento
    si una excepción posterior dejaba el control en ERROR.
    """

    @staticmethod
    def _estado(total, ok, err, sin_ev, crit):
        """Réplica de la lógica de estado agregado de generar_informe_final."""
        if total == 0:
            return "SIN_CONTROLES"
        if err == total:
            return "ERROR"
        if sin_ev == total:
            return "SIN_EVIDENCIA"
        if err > 0 or ok < total:
            return "PARCIAL"
        if crit > 0:
            return "CON_HALLAZGOS"
        return "OK"

    def test_todos_sin_evidencia_no_es_estado_error(self):
        assert self._estado(12, 0, 0, 12, 0) == "SIN_EVIDENCIA"

    def test_todos_con_fallo_tecnico_si_es_error(self):
        assert self._estado(12, 0, 12, 0, 0) == "ERROR"

    def test_la_mezcla_es_parcial(self):
        assert self._estado(12, 8, 1, 3, 0) == "PARCIAL"

    def test_los_estados_sanos_se_conservan(self):
        assert self._estado(12, 12, 0, 0, 2) == "CON_HALLAZGOS"
        assert self._estado(12, 12, 0, 0, 0) == "OK"

    def test_partial_se_cuenta_aparte_en_el_codigo(self):
        fuente = (RAIZ / "modulos" / "motor_ia_v2.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert "controles_sin_evidencia" in codigo
        assert "EstadoEvaluacion.PARTIAL" in codigo, (
            "PARTIAL debe distinguirse explícitamente de ERROR"
        )
        assert '"SIN_EVIDENCIA"' in codigo

    def test_los_hallazgos_se_acumulan_sea_cual_sea_el_estado(self):
        """
        Un control que extrajo hallazgos y luego falló seguía teniendo hallazgos
        reales; no pueden desaparecer del recuento.
        """
        fuente = (RAIZ / "modulos" / "motor_ia_v2.py").read_text(encoding="utf-8")
        bloque = fuente.split("_estado_ctrl = resultado.get")[1][:900]
        # La acumulación debe estar FUERA del if/elif/else de estados
        assert "hallazgos_totales +=" in bloque
        assert "hallazgos_criticos +=" in bloque
        pos_else = bloque.find("controles_error += 1")
        pos_hall = bloque.find("hallazgos_totales +=")
        assert pos_hall > pos_else, (
            "los hallazgos siguen dentro de la rama OK: se pierden en ERROR"
        )

    def test_agente_muestra_sin_evidencia_por_separado(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "controles_sin_evidencia" in fuente
        assert "no es un fallo" in fuente


class TestAuditoriaHistorialFeedbackEsDurable:
    """
    BUG ALTO. `guardar_historial` escribía con `open(path,"w")` + json.dump: sin
    lock y sin escritura atómica — al contrario que document_cache.py, que sí
    tenía ambas pese a guardar datos REGENERABLES.

    Medido con procesos reales sobre historial_feedback.json:
        · 4 procesos simultáneos → se perdía el 77% (18 de 80 registros)
        · 6 de 6 `kill -9` durante la escritura → JSON corrupto

    Y un amplificador: `cargar_historial` devolvía [] EN SILENCIO ante un JSON
    corrupto, así que el siguiente guardado lo sobrescribía. Corrupción →
    historial vacío → borrado definitivo, sin un solo aviso. Son correcciones
    humanas no regenerables, y alimentan la calibración anti-sesgo.
    """

    def _fb(self, tmp_path, monkeypatch):
        import modulos.feedback as fb
        monkeypatch.setattr(fb, "FEEDBACK_PATH",
                            tmp_path / "historial_feedback.json")
        return fb

    def test_usa_escritura_atomica_y_lock(self):
        fuente = (RAIZ / "modulos" / "feedback.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert "_escribir_json_atomico" in codigo, "sin escritura atómica"
        assert "_lock_archivo" in codigo, "sin lock entre procesos"

    def test_no_deja_el_json_a_medio_escribir(self, tmp_path, monkeypatch):
        """La escritura pasa por tmp+replace: nunca hay un destino truncado."""
        fb = self._fb(tmp_path, monkeypatch)
        fb.guardar_historial([{"ambito": "M", "actividad": f"a{i}"} for i in range(50)])
        datos = json.loads(fb.FEEDBACK_PATH.read_text(encoding="utf-8"))
        assert len(datos) == 50
        assert not list(tmp_path.glob("*.tmp")), "quedó un temporal sin swap"

    def test_fusiona_en_vez_de_pisar(self, tmp_path, monkeypatch):
        """Simula el escenario de dos procesos: el segundo no borra al primero."""
        fb = self._fb(tmp_path, monkeypatch)
        fb.guardar_historial([{"ambito": "M", "actividad": "del_proceso_A"}])
        # Otro proceso guarda su propia lista, sin conocer la del primero
        fb.guardar_historial([{"ambito": "M", "actividad": "del_proceso_B"}])

        actividades = {r["actividad"] for r in fb.cargar_historial()}
        assert "del_proceso_A" in actividades, "se perdió el registro del otro proceso"
        assert "del_proceso_B" in actividades

    def test_no_duplica_al_reguardar(self, tmp_path, monkeypatch):
        """Guardar dos veces la misma lista no debe duplicar registros."""
        fb = self._fb(tmp_path, monkeypatch)
        h = [{"ambito": "M", "actividad": "unica"}]
        fb.guardar_historial(h)
        fb.guardar_historial(fb.cargar_historial())
        assert len(fb.cargar_historial()) == 1

    def test_un_json_corrupto_no_se_borra_en_silencio(self, tmp_path, monkeypatch, capsys):
        fb = self._fb(tmp_path, monkeypatch)
        fb.FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)
        fb.FEEDBACK_PATH.write_text('[{"ambito": "M", "activi', encoding="utf-8")

        assert fb.cargar_historial() == []
        salida = capsys.readouterr().out
        assert "ilegible" in salida, "la corrupción pasó en silencio"
        respaldos = list(tmp_path.glob("*.corrupto-*.json"))
        assert respaldos, "no se conservó copia del historial dañado"

    def test_los_registros_llevan_id_estable(self):
        from modulos.feedback import _id_registro
        r = {"ambito": "M", "actividad": "a", "puntaje_agente": 3}
        assert _id_registro(r) == _id_registro(dict(r)), "el id no es estable"
        assert _id_registro(r) != _id_registro({**r, "actividad": "b"})


class TestAuditoriaCacheDeResumenesBajoLock:
    """
    BUG MEDIO. `ChunkerService._guardar_cache` escribía de forma atómica pero
    SIN lock, así que el ciclo leer-modificar-escribir de dos procesos se
    pisaba. Medido con 4 procesos simultáneos: se perdía el 75% de los
    resúmenes (6 de 24).

    No es una caché fría cualquiera: cada resumen perdido hay que volver a
    pagarlo al modelo ($1,14 para el PDF de 305 páginas).
    """

    class _Cli:
        def generar_mensaje(self, prompt="", max_tokens=None, **kw):
            t = "R. "
            tope = (max_tokens or 1500) * 4
            return (t * (tope // len(t) + 1))[:tope]

    def _doc(self, nombre):
        texto = f"contenido de {nombre} " * 3000
        return {"nombre": nombre, "tipo": "MD",
                "contenido": texto, "chars_totales": len(texto)}

    def test_usa_lock_al_guardar(self):
        fuente = (RAIZ / "modulos" / "chunker.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert "_lock_archivo" in codigo, "el caché de resúmenes sigue sin lock"

    def test_relee_dentro_del_lock(self, tmp_path, capsys):
        """
        Dos servicios que guardan por separado no deben pisarse: el segundo
        debe conservar lo que escribió el primero.
        """
        from modulos.chunker import ChunkerService
        a = ChunkerService(cliente_ia=self._Cli(), cache_dir=tmp_path)
        a.procesar_doc(self._doc("doc_a.md"))
        b = ChunkerService(cliente_ia=self._Cli(), cache_dir=tmp_path)
        b.procesar_doc(self._doc("doc_b.md"))
        capsys.readouterr()

        datos = json.loads((tmp_path / "chunk_summaries_cache.json")
                           .read_text(encoding="utf-8"))
        assert len(datos) == 2, f"lost update: solo quedaron {len(datos)} resúmenes"

    def test_un_fallo_de_cache_no_tumba_el_chunking(self, tmp_path, capsys, monkeypatch):
        """El caché es una optimización: nunca puede impedir procesar el documento."""
        from modulos import chunker as ch_mod
        from modulos.chunker import ChunkerService

        def _explota(*a, **k):
            raise OSError("disco lleno")

        monkeypatch.setattr(ch_mod.ChunkerService, "_guardar_cache",
                            lambda self, *a, **k: _explota())
        with pytest.raises(OSError):
            _explota()

        # Con el guardado roto de verdad, procesar_doc debe seguir devolviendo
        # el documento procesado (el except interno lo absorbe).
        monkeypatch.undo()
        ch = ChunkerService(cliente_ia=self._Cli(), cache_dir=tmp_path / "no" / "existe" / "x")
        r = ch.procesar_doc(self._doc("doc_c.md"))
        capsys.readouterr()
        assert r["cobertura_pct"] >= 99.9

    def test_no_deja_temporales(self, tmp_path, capsys):
        from modulos.chunker import ChunkerService
        ChunkerService(cliente_ia=self._Cli(), cache_dir=tmp_path
                       ).procesar_doc(self._doc("doc_d.md"))
        capsys.readouterr()
        assert not list(tmp_path.glob("*.tmp"))
        assert not list(tmp_path.glob("*.lock"))


class TestAuditoriaPathTraversalEnSalidas:
    """
    BUG MEDIO (seguridad). `--titulo` y `--explicar-modelo` se interpolaban tal
    cual en la ruta de salida:

        outputs/<fecha>/resultados_{titulo}_{fecha}.json
        outputs/<fecha>/explicacion_del_modelo_{modelo}.md

    Verificado: `--explicar-modelo "../../../evil"` escribía FUERA de outputs/.
    Y un nombre con `/` apuntaba a un subdirectorio inexistente, fallando con
    FileNotFoundError DESPUÉS de haber pagado las llamadas al modelo.
    """

    TRAVESIAS = ["../../../evil", "..\\..\\evil", "a/b/c", "....//evil"]

    def test_ninguna_travesia_escapa_del_directorio(self, tmp_path):
        from config.rutas import nombre_seguro
        salida = tmp_path / "outputs" / "2026-07-28"
        for bruto in self.TRAVESIAS:
            destino = (salida / f"explicacion_del_modelo_{nombre_seguro(bruto)}.md").resolve()
            assert salida.resolve() in destino.parents, (
                f"'{bruto}' escapa a {destino}"
            )

    def test_no_quedan_separadores_de_ruta(self):
        from config.rutas import nombre_seguro
        for bruto in self.TRAVESIAS + ["a/b", "a\\b"]:
            s = nombre_seguro(bruto)
            assert "/" not in s and "\\" not in s, f"{bruto} → {s}"
            assert ".." not in s, f"{bruto} → {s}"

    def test_caracteres_ilegales_de_windows(self):
        from config.rutas import nombre_seguro
        s = nombre_seguro('mo"del<>o:2026|x?y*z')
        assert not set(s) & set('<>:"/\\|?*'), s

    def test_nombres_reservados_de_windows(self):
        from config.rutas import nombre_seguro
        for r in ("CON", "PRN", "AUX", "NUL", "COM1", "LPT9", "con", "Com1"):
            assert nombre_seguro(r).upper() != r.upper(), f"{r} sin escapar"

    def test_vacio_y_solo_puntos_dan_defecto(self):
        from config.rutas import nombre_seguro
        for bruto in ("", "   ", "...", " . "):
            assert nombre_seguro(bruto) == "sin_nombre", repr(bruto)

    def test_acota_la_longitud(self):
        from config.rutas import nombre_seguro
        assert len(nombre_seguro("x" * 500)) <= 80

    def test_no_altera_los_nombres_normales(self):
        """El saneo no puede estropear el caso corriente."""
        from config.rutas import nombre_seguro
        for bueno in ("LaR", "PD_Retail", "IFRS9_Provisiones",
                      "Modelo LaR v3", "VaR-Mercado"):
            assert nombre_seguro(bueno) == bueno

    def test_los_tres_puntos_vulnerables_lo_usan(self):
        """
        [P0.2 2026-07-30] Eran TRES, no dos. Este test solo cubría `agente.py` y
        `explicador_modelo.py`; el pipeline por CONTROL
        (`motor_ia_v2.py`) interpolaba `--titulo` crudo en su ruta de salida y
        quedó fuera de la red durante toda la vida del test.
        """
        for fichero, marca in (
            ("agente.py", "nombre_seguro(args.titulo)"),
            ("modulos/explicador_modelo.py", "nombre_seguro(modelo)"),
            ("modulos/motor_ia_v2.py", "nombre_seguro(nombre_modelo)"),
        ):
            fuente = (RAIZ / fichero).read_text(encoding="utf-8")
            assert marca in fuente, f"{fichero} sigue interpolando sin sanear"

    def test_ninguna_ruta_de_salida_interpola_el_titulo_crudo(self):
        """
        Barrido: cualquier f-string que construya un nombre de fichero a partir
        del título tiene que pasar por `nombre_seguro`. Es la red que habría
        detectado el punto que se escapó.
        """
        import re
        sospechosas = re.compile(
            r'f"[^"]*\{(?:args\.titulo|nombre_modelo|modelo|titulo_modelo)\}')
        fugas = []
        for fichero in ("agente.py", "modulos/motor_ia_v2.py",
                        "modulos/explicador_modelo.py", "modulos/motor_ia.py"):
            for n, linea in enumerate((RAIZ / fichero).read_text(
                    encoding="utf-8").splitlines(), 1):
                if linea.lstrip().startswith("#"):
                    continue
                # Solo interesa si además parece una RUTA (lleva / o extensión)
                if sospechosas.search(linea) and (
                        "/" in linea or ".json" in linea or ".md" in linea
                        or ".docx" in linea):
                    if "nombre_seguro" not in linea:
                        fugas.append(f"{fichero}:{n}")
        assert not fugas, f"título sin sanear en una ruta de salida: {fugas}"


class TestAuditoriaUnSoloParserJSON:
    """
    BUG MEDIO. El proyecto tenía DOS parsers de la respuesta del modelo con
    robustez distinta, y el pipeline por CONTROL usaba el débil:

      · modulos/motor_ia._extraer_json   → conteo de llaves consciente de
                                           strings y escapes  (robusto)
      · motor/Mx_03._parsear_json        → find("{") + rfind("}")  (ingenuo)

    `rfind` toma la ÚLTIMA llave de todo el texto, así que fallaba cuando el
    modelo añadía una frase explicativa con llaves, o cuando emitía dos objetos
    seguidos. En ambos casos una evaluación VÁLIDA se descartaba.
    """

    FALLBACK = {"revision": "FALLBACK", "hallazgos": []}

    def _parsear(self, texto):
        import sys
        sys.path.insert(0, str(RAIZ / "motor"))
        from Mx_03_LlamarIA import _parsear_json
        return _parsear_json(texto, dict(self.FALLBACK))

    def test_tolera_texto_explicativo_con_llaves(self):
        r = self._parsear('{"revision":"ok","hallazgos":[]}\n\nNota: usa {llaves} asi.')
        assert r["revision"] == "ok", "el texto con llaves seguía rompiendo el parseo"

    def test_tolera_dos_objetos_seguidos(self):
        r = self._parsear('{"revision":"A","hallazgos":[]}\n{"revision":"B","hallazgos":[]}')
        assert r["revision"] == "A", "debe quedarse con el primer objeto"

    def test_sigue_tolerando_fences_y_texto_posterior(self):
        assert self._parsear('```json\n{"revision":"ok","hallazgos":[]}\n```')["revision"] == "ok"
        assert self._parsear('{"revision":"ok","hallazgos":[]}\n\nEspero que sirva.')["revision"] == "ok"

    def test_lo_realmente_irrecuperable_sigue_dando_fallback(self):
        for malo in ('{"revision":"ok","hallazgos":[{"d":"incompl',
                     "No puedo evaluar este control."):
            assert self._parsear(malo)["revision"] == "FALLBACK"

    def test_un_fallo_de_parseo_es_error_no_falta_de_evidencia(self):
        """
        Interacción con el fix de PARTIAL: desde que PARTIAL significa «faltan
        documentos», etiquetar así un fallo de parseo mandaba al operador a
        buscar evidencia que ya tenía.
        """
        fuente = (RAIZ / "modulos" / "motor_ia_v2.py").read_text(encoding="utf-8")
        bloque = fuente.split("10. DETERMINAR ESTADO FINAL")[1][:1200]
        assert "EstadoEvaluacion.ERROR" in bloque, (
            "un JSON inválido sigue marcándose como PARTIAL (sin evidencia)"
        )
        assert "fallo técnico" in bloque


class TestAuditoriaVolcadoDebugNoSeEscapa:
    """
    RIESGO BAJO. Con DEBUG_PROMPTS=1 se volcaba el prompt ÍNTEGRO —toda la
    evidencia del modelo— a un fichero de ruta RELATIVA, o sea al directorio
    desde el que se lanzara el agente. Solo está cubierto por .gitignore si
    aterriza en la raíz del proyecto.
    """

    def test_escribe_bajo_outputs_no_en_el_cwd(self):
        fuente = (RAIZ / "motor" / "Mx_03_LlamarIA.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        assert 'debug_file = f"DEBUG_PROMPT_' not in codigo, (
            "vuelve a escribir con ruta relativa al cwd"
        )
        assert "OUTPUTS_DIR" in codigo and "debug_prompts" in codigo

    def test_el_gitignore_sigue_cubriendo_el_patron(self):
        gi = (RAIZ / ".gitignore").read_text(encoding="utf-8")
        assert "DEBUG_PROMPT_" in gi, "el patrón dejó de estar en .gitignore"


class TestAuditoriaLecturaFallidaNoEsCoberturaTotal:
    """
    BUG ALTO — otra vez el patrón dominante: ausencia de contenido presentada
    como cobertura completa. Tres fallos con la misma firma:

      · XLSX de 10.000 filas → se leían 200 (2%), `truncado=False`,
        cobertura 100% y NADA en el texto que lo dijera.
      · PDF corrupto        → contenido = «[Error OCR ...]» con cobertura 100%.
      · PDF sin texto       → idéntico.

    Los dos últimos son los graves: el mensaje de error se convertía en
    EVIDENCIA. D3-FIX no lo rechazaba porque "había contenido", así que el
    agente evaluaba sobre un mensaje de error creyendo haber visto el documento.
    """

    @staticmethod
    def _leer(ruta):
        import sys
        sys.path.insert(0, str(RAIZ / "motor"))
        import io
        import contextlib
        from Mx_01_LecturaEvidencias import leer_archivo
        with contextlib.redirect_stdout(io.StringIO()):
            return leer_archivo(ruta)

    def test_excel_recortado_lo_declara_en_el_texto(self, tmp_path):
        import openpyxl
        p = tmp_path / "grande.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["ID", "Cliente"])
        for i in range(5_000):
            ws.append([i, f"CL{i:05d}"])
        wb.save(p)

        d = self._leer(p)
        assert "RECORTADO" in d["contenido"], (
            "el Excel se recorta en silencio: el evaluador cree ver la tabla entera"
        )
        assert "5,000" in d["contenido"] or "5000" in d["contenido"], (
            "no se declara el total de filas real"
        )

    def test_excel_pequeno_no_lleva_aviso(self, tmp_path):
        """El aviso solo cuando hay recorte de verdad."""
        import openpyxl
        p = tmp_path / "chico.xlsx"
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["ID"])
        for i in range(10):
            ws.append([i])
        wb.save(p)
        assert "RECORTADO" not in self._leer(p)["contenido"]

    def test_pdf_ilegible_no_reporta_cobertura_total(self, tmp_path):
        p = tmp_path / "roto.pdf"
        p.write_bytes(b"%PDF-1.4\nESTO NO ES UN PDF VALIDO")
        d = self._leer(p)
        assert d["cobertura_pct"] == 0.0, (
            f"un PDF ilegible reporta cobertura {d['cobertura_pct']}%"
        )
        assert d.get("lectura_fallida") is True

    def test_la_marca_interna_no_llega_al_usuario(self, tmp_path):
        """El centinela es de uso interno: no debe ensuciar el informe."""
        p = tmp_path / "roto.pdf"
        p.write_bytes(b"%PDF-1.4\nCORRUPTO")
        assert "⛔" not in self._leer(p)["contenido"]

    def test_un_documento_sano_no_se_ve_afectado(self, tmp_path):
        p = tmp_path / "sano.md"
        p.write_text("# Manual\nEWMA 0.94\n" * 20, encoding="utf-8")
        d = self._leer(p)
        assert d["cobertura_pct"] == 100.0
        assert d.get("lectura_fallida") is False

    def test_todos_los_lectores_marcan_sus_fallos(self):
        """Si un lector nuevo olvida la marca, su error pasará por evidencia."""
        fuente = (RAIZ / "motor" / "Mx_01_LecturaEvidencias.py").read_text(encoding="utf-8")
        codigo = "\n".join(l for l in fuente.splitlines()
                           if not l.lstrip().startswith("#"))
        # Ningún retorno de error debe quedar sin marca
        import re
        sin_marca = re.findall(r'return f"\[Error [^"]*"', codigo)
        assert not sin_marca, f"retornos de error sin marcar: {sin_marca}"
        assert codigo.count("_MARCA_LECTURA_FALLIDA") >= 6


# ═════════════════════════════════════════════════════════════════════════════
# 22. Informe Word — el entregable que lee el auditor  [auditoría 2026-07-28]
# ═════════════════════════════════════════════════════════════════════════════

class TestAuditoriaInformeWordNoDeformaLosDatos:
    """
    Tres bugs silenciosos en `generador_word.py`, el módulo que produce el
    entregable final. Ninguno lanza error; los tres deforman lo que el auditor
    lee.
    """

    # ── 1. _normalizar_score ─────────────────────────────────────────────────

    def test_actividad_no_evaluada_no_es_el_peor_puntaje(self):
        """
        D3-FIX produce puntaje=None para «sin evidencia». Se convertía en 1
        («No cumple»): el peor puntaje posible. Mismo error que hacía leer el
        score global sin evidencia como CRÍTICO.
        """
        from modulos.generador_word import _normalizar_score, _puntaje_label
        assert _normalizar_score(None) is None
        assert "NO EVALUADA" in _puntaje_label(None).upper()
        assert "no cumple" not in _puntaje_label(None).lower()

    def test_un_puntaje_casi_perfecto_no_colapsa_a_uno(self):
        """
        La heurística «si raw > 5 es escala 0-100» colapsaba el tramo (5, 12]:
        5.4 → round(1 + 0.054*4) = 1. Un casi-5 se volvía el peor puntaje.
        """
        from modulos.generador_word import _normalizar_score
        for casi_perfecto in (5.4, 5.6, 6, 7, 12):
            assert _normalizar_score(casi_perfecto) == 5, (
                f"{casi_perfecto} → {_normalizar_score(casi_perfecto)}"
            )

    def test_la_escala_0_100_sigue_funcionando(self):
        from modulos.generador_word import _normalizar_score
        assert _normalizar_score(100) == 5
        assert _normalizar_score(50) == 3
        # [POLÍTICA 2026-07-29] El 0 ya NO se eleva a 1: está reservado a la
        # falta de evidencia, que la entidad puntúa como falta crítica. Un
        # promedio real nunca puede dar 0 porque la escala empieza en 1.
        assert _normalizar_score(0) == 0

    def test_valores_no_numericos_no_revientan(self):
        from modulos.generador_word import _normalizar_score
        for basura in ("abc", "", None, [], {}):
            assert _normalizar_score(basura) is None

    def test_ya_no_se_inventa_un_puntaje_por_defecto(self):
        """El default era 50 → puntaje 3 («cumple parcialmente») inventado."""
        fuente = (RAIZ / "modulos" / "generador_word.py").read_text(encoding="utf-8")
        assert 'ev.get("puntaje", 50)' not in fuente, (
            "vuelve a inventarse un puntaje donde no había dato"
        )

    # ── 2. _es_error ─────────────────────────────────────────────────────────

    def test_no_borra_hallazgos_que_mencionan_api_o_errores(self):
        """
        El llamador BORRA el campo cuando esto da True. Buscar la subcadena
        "api" o "error" hacía DESAPARECER del informe cualquier hallazgo
        legítimo que las mencionara.
        """
        from modulos.generador_word import _es_error
        legitimos = [
            "El manual documenta la API de extracción desde el core bancario "
            "y no presenta errores de implementación.",
            "Se usa la API interna del core para los flujos.",
            "No se encontró evidencia de backtesting.",
            "El script gestiona la connection al datalake.",
        ]
        for texto in legitimos:
            assert not _es_error(texto), f"se borraría del informe: {texto[:60]}"

    def test_sigue_detectando_los_errores_de_verdad(self):
        from modulos.generador_word import _es_error
        for malo in ("[Error OCR en manual.pdf: poppler no instalado]",
                     "Error 401 al conectar",
                     "Traceback (most recent call last):",
                     "EVALUACIÓN NO REALIZADA — fallo técnico",
                     "N/A"):
            assert _es_error(malo), f"no detectado: {malo[:50]}"

    # ── 3. El documento real ─────────────────────────────────────────────────

    def _generar(self, tmp_path):
        import contextlib
        import io
        from modulos.generador_word import generar_word_informe
        evals = {"Metodología": [
            {"actividad": "Backtesting", "puntaje": 4, "concepto": "c",
             "observacion": "El manual documenta la API de extracción y no "
                            "presenta errores de implementación.",
             "evidencia_encontrada": "manual.md", "recomendacion": "r",
             "preguntas_pendientes": []},
            {"actividad": "Supuestos", "puntaje": None, "sin_evidencia": True,
             "concepto": "EVALUACIÓN NO REALIZADA — Sin evidencia",
             "observacion": "Sin documentos.", "evidencia_encontrada": "",
             "recomendacion": "", "preguntas_pendientes": []},
        ]}
        with contextlib.redirect_stdout(io.StringIO()):
            ruta = generar_word_informe(
                resumen_ejecutivo="R.", evaluaciones_por_ambito=evals,
                scores_por_ambito={"Metodología": 4.0}, score_global=4.0,
                titulo_modelo="LaR", tier="1", outputs_dir=tmp_path)
        from docx import Document
        d = Document(ruta)
        return "\n".join([p.text for p in d.paragraphs] +
                         [c.text for t in d.tables for r in t.rows for c in r.cells])

    def test_el_hallazgo_legitimo_sobrevive_en_el_docx(self, tmp_path):
        texto = self._generar(tmp_path)
        assert "API de extracción" in texto, (
            "el hallazgo con 'API' fue borrado del informe final"
        )

    def test_la_actividad_sin_evidencia_se_marca_como_tal(self, tmp_path):
        texto = self._generar(tmp_path)
        assert "NO EVALUADA" in texto.upper()

    def test_no_aparece_el_literal_none_en_el_informe(self, tmp_path):
        """«None/5» en un documento regulatorio se lee como fallo del sistema."""
        texto = self._generar(tmp_path)
        assert "None/5" not in texto
        assert "None" not in texto.replace("Ninguno", "")


class TestAuditoriaHistorialSucioNoTumbaLasEstadisticas:
    """
    BUG MEDIO. `calcular_estadisticas` accedía a `fb["diferencia"]` directo y
    hacía `abs()` sin comprobar tipo. Cuatro de seis historiales degenerados
    tumbaban `--estadisticafeedback` con traceback:

        falta 'diferencia'  → KeyError
        'diferencia' texto  → TypeError: bad operand type for abs()
        elemento no-dict    → TypeError: string indices must be integers

    Mientras tanto `analizar_patron_errores`, del mismo subsistema, los
    manejaba todos. El historial se edita a mano y lo escriben versiones
    distintas del agente: tiene que tolerar registros viejos o rotos.
    """

    DEGENERADOS = {
        "vacio":            [],
        "sin_ambito":       [{"actividad": "x", "diferencia": 1}],
        "sin_diferencia":   [{"ambito": "Metodología", "actividad": "x"}],
        "tipo_erroneo":     [{"ambito": "Metodología", "diferencia": "dos"}],
        "elementos_no_dict": ["texto", 42, None],
        "no_es_lista":      {"ambito": "M"},
    }

    def _con_historial(self, tmp_path, monkeypatch, datos):
        import modulos.feedback as fb
        p = tmp_path / "historial_feedback.json"
        p.write_text(json.dumps(datos, ensure_ascii=False), encoding="utf-8")
        monkeypatch.setattr(fb, "FEEDBACK_PATH", p)
        return fb

    @pytest.mark.parametrize("caso", list(DEGENERADOS))
    def test_calcular_estadisticas_no_revienta(self, caso, tmp_path, monkeypatch, capsys):
        fb = self._con_historial(tmp_path, monkeypatch, self.DEGENERADOS[caso])
        r = fb.calcular_estadisticas()      # no debe lanzar
        capsys.readouterr()
        assert isinstance(r, dict)

    @pytest.mark.parametrize("caso", list(DEGENERADOS))
    def test_masa_critica_no_revienta(self, caso, tmp_path, monkeypatch, capsys):
        from modulos.motor_ia import validar_masa_critica_feedback
        fb = self._con_historial(tmp_path, monkeypatch, self.DEGENERADOS[caso])
        r = validar_masa_critica_feedback(fb.cargar_historial(), "Metodología")
        capsys.readouterr()
        assert isinstance(r["n_registros"], int)

    def test_los_registros_sanos_sobreviven_a_los_rotos(self, tmp_path, monkeypatch, capsys):
        """Un registro corrupto no puede invalidar los buenos."""
        fb = self._con_historial(tmp_path, monkeypatch, [
            {"ambito": "Metodología", "diferencia": 2},
            "basura",
            {"ambito": "Metodología", "diferencia": 1},
        ])
        r = fb.calcular_estadisticas()
        capsys.readouterr()
        assert r.get("total_feedbacks") == 2, r

    def test_avisa_de_los_registros_descartados(self, tmp_path, monkeypatch, capsys):
        fb = self._con_historial(tmp_path, monkeypatch, [
            {"ambito": "Metodología", "diferencia": 1}, "basura",
        ])
        fb.calcular_estadisticas()
        assert "malformados" in capsys.readouterr().out

    def test_si_nada_es_utilizable_lo_dice_con_precision(self, tmp_path, monkeypatch, capsys):
        """No es lo mismo «no hay historial» que «hay pero está roto»."""
        fb = self._con_historial(tmp_path, monkeypatch,
                                 [{"ambito": "M", "diferencia": "dos"}])
        r = fb.calcular_estadisticas()
        capsys.readouterr()
        assert "error" in r
        assert "ninguno es utilizable" in r["error"]


class TestAuditoriaScoreDeControlCuentaTodosLosHallazgos:
    """
    BUG ALTO. `CalculadorScore.calcular_score_cumplimiento` dependía ÚNICAMENTE
    de los hallazgos con criticidad CRITICA. Los demás no restaban nada, y
    `total_hallazgos` era un parámetro que la función NUNCA leía —pese a que su
    docstring prometía «INVERSA a cantidad de hallazgos». Medido:

        50 hallazgos MODERADA, 0 críticos  →  5.0  «CUMPLE PLENAMENTE»
        30 MODERADA + 20 BAJA              →  5.0  «CUMPLE PLENAMENTE»

    Un control plagado de problemas documentados salía perfecto en el informe
    regulatorio. Y la etiqueta de criticidad la asigna el LLM, conservador al
    usar CRITICA: bastaba con que ninguno lo fuera.
    """

    @staticmethod
    def _h(n, criticidad):
        return [{"criticidad": criticidad, "texto": f"h{i}"} for i in range(n)]

    def _score(self, hallazgos):
        from modulos.control_evaluacion_data import CalculadorScore
        return CalculadorScore.calcular_score_cumplimiento(hallazgos, len(hallazgos))

    def test_los_casos_de_solo_criticos_no_cambian(self):
        """El fix no puede alterar lo que ya funcionaba bien."""
        assert self._score([]) == 5.0
        assert self._score(self._h(1, "CRITICA")) == 4.0
        assert self._score(self._h(2, "CRITICA")) == 3.0
        assert self._score(self._h(3, "CRITICA")) == 2.0
        assert self._score(self._h(5, "CRITICA")) == 1.0

    def test_un_aluvion_de_moderadas_ya_no_es_cumplimiento_pleno(self):
        for n in (5, 10, 50):
            s = self._score(self._h(n, "MODERADA"))
            assert s < 5.0, f"{n} hallazgos MODERADA siguen dando {s}"

    def test_la_mezcla_sin_criticos_tampoco(self):
        s = self._score(self._h(30, "MODERADA") + self._h(20, "BAJA"))
        assert s < 4.0, f"30 moderadas + 20 bajas dan {s}"

    def test_las_menores_pesan_menos_que_las_moderadas(self):
        """Un hallazgo BAJA no puede castigar igual que uno MODERADA."""
        assert self._score(self._h(10, "BAJA")) > self._score(self._h(10, "MODERADA"))

    def test_los_criticos_siguen_dominando(self):
        """Ningún volumen de menores puede parecer peor que varios críticos."""
        assert self._score(self._h(100, "BAJA")) > self._score(self._h(3, "CRITICA"))

    def test_el_score_nunca_sale_del_rango(self):
        for hs in (self._h(500, "MODERADA"), self._h(500, "CRITICA"),
                   self._h(500, "BAJA"), self._h(50, "CRITICA") + self._h(50, "MODERADA")):
            assert 1.0 <= self._score(hs) <= 5.0

    def test_criticidad_ausente_o_desconocida_no_revienta(self):
        for hs in ([{"texto": "sin criticidad"}] * 8,
                   [{"criticidad": None}] * 3,
                   [{"criticidad": "INVENTADA"}] * 4):
            s = self._score(hs)
            assert 1.0 <= s <= 5.0
            assert s < 5.0, "un hallazgo sin etiquetar sigue sin restar"


class TestAuditoriaEjecucionDeNotebookEsExplicita:
    """
    RIESGO documentado (no bug). `--convertir-excel` ejecuta con `exec()` el
    notebook que un LLM generó traduciendo las fórmulas del Excel de entrada.

    El docstring lo describía como «namespace aislado», lo que induce a error:
    `ns = {}` aísla los NOMBRES de variables, no las CAPACIDADES. Verificado: el
    código ejecutado puede `import os` y leer el disco con los permisos del
    usuario. Es el propósito declarado de la función, pero el usuario debe
    saberlo antes de que ocurra.
    """

    def test_avisa_antes_de_ejecutar(self, capsys):
        import nbformat as nbf
        from modulos.excel_a_notebook import _ejecutar_notebook
        nb = nbf.v4.new_notebook(cells=[nbf.v4.new_code_cell("x = 1 + 1")])
        ok, ns, _ = _ejecutar_notebook(nb)
        salida = capsys.readouterr().out
        assert ok and ns.get("x") == 2, "dejó de ejecutar correctamente"
        assert "sandbox" in salida.lower(), "no advierte de la ejecución"
        assert "--sin-validacion" in salida, "no indica cómo omitirlo"

    def test_el_docstring_ya_no_promete_aislamiento(self):
        """
        Busca la FRASE-AFIRMACIÓN, no la subcadena: el propio docstring cita la
        redacción antigua para explicar por qué se cambió.
        """
        from modulos.excel_a_notebook import _ejecutar_notebook
        doc = _ejecutar_notebook.__doc__ or ""
        assert "notebook en un namespace aislado" not in doc, (
            "el docstring vuelve a prometer un aislamiento que no existe"
        )
        assert "NO ESTÁ EN SANDBOX" in doc.upper()

    def test_sigue_capturando_el_error_sin_propagarlo(self):
        """Un notebook roto no puede tumbar la conversión."""
        import nbformat as nbf
        from modulos.excel_a_notebook import _ejecutar_notebook
        nb = nbf.v4.new_notebook(cells=[nbf.v4.new_code_cell("1/0")])
        ok, ns, msg = _ejecutar_notebook(nb)
        assert ok is False and ns is None
        assert "ZeroDivisionError" in msg


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28] Un import local no puede matar el pipeline principal
#
# Bug real encontrado en la fase 2: `main()` tenía `from modulos.chunker import
# ChunkerService` dentro de la rama `--explicar-modelo`. Un import dentro de una
# función marca ese nombre como LOCAL de toda la función, así que ensombreció el
# import de módulo. Cuando no se tomaba esa rama, la ruta principal del producto
# (`--titulo/--tier`) moría con "referenced before assignment" — el 100% de las
# corridas de validación. Ningún test lo vio porque todos ejercitan los módulos
# por separado, nunca `main()` completo.
#
# Se cubre la CLASE de fallo, no solo esta línea: cualquier import local que
# repita un nombre ya importado a nivel de módulo es un accidente esperando.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaImportLocalNoEnsombreceAlGlobal:

    def _sombras(self, ruta):
        import ast
        arbol = ast.parse(ruta.read_text(encoding="utf-8"))
        globales = set()
        for n in arbol.body:
            if isinstance(n, (ast.Import, ast.ImportFrom)):
                for a in n.names:
                    globales.add(a.asname or a.name.split(".")[0])
        encontradas = []
        for fn in ast.walk(arbol):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for n in ast.walk(fn):
                if isinstance(n, (ast.Import, ast.ImportFrom)):
                    for a in n.names:
                        nom = a.asname or a.name.split(".")[0]
                        if nom in globales:
                            encontradas.append(f"{ruta.name}:{n.lineno} '{nom}' (def {fn.name})")
        return encontradas

    def test_ningun_modulo_de_produccion_ensombrece_sus_imports(self):
        from pathlib import Path
        raiz = Path(__file__).resolve().parents[1]
        objetivo = [raiz / "agente.py"]
        for carpeta in ("modulos", "motor", "config"):
            objetivo += sorted((raiz / carpeta).glob("*.py"))
        sombras = []
        for f in objetivo:
            if f.exists():
                sombras += self._sombras(f)
        assert not sombras, (
            "Import local que ensombrece uno de módulo — el nombre queda sin "
            "asignar en las ramas que no ejecutan el import:\n  " + "\n  ".join(sombras))

    def test_main_resuelve_chunkerservice_sin_pasar_por_explicar_modelo(self):
        # Reproduce la condición exacta: el nombre debe resolverse aunque la
        # rama que contenía el import no se ejecute nunca.
        import ast
        from pathlib import Path
        arbol = ast.parse((Path(__file__).resolve().parents[1] / "agente.py")
                          .read_text(encoding="utf-8"))
        main = next(n for n in ast.walk(arbol)
                    if isinstance(n, ast.FunctionDef) and n.name == "main")
        locales = {a.asname or a.name.split(".")[0]
                   for n in ast.walk(main)
                   if isinstance(n, (ast.Import, ast.ImportFrom)) for a in n.names}
        assert "ChunkerService" not in locales, (
            "ChunkerService vuelve a importarse dentro de main(): eso lo convierte "
            "en local y rompe el pipeline principal en la línea que lo instancia.")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28] Un tier inexistente no puede producir un informe
#
# `--tier 9` no se validaba. El parser buscaba una columna "TIER_9" que no
# existe, avisaba y DESACTIVABA el filtro por tier: la corrida evaluaba las 21
# actividades en lugar de las 11 del tier, facturaba la API completa y emitía
# un informe rotulado "Tier: 9". Un typo en un dígito → entregable equivocado.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaTierInvalidoSeRechazaAntesDeGastar:

    def test_solo_los_cuatro_tiers_reales_son_validos(self):
        from config.dominio import normalizar_tier
        assert normalizar_tier("1") == "I"
        assert normalizar_tier("4") == "IV"
        assert normalizar_tier("iv") == "IV"      # insensible a caja
        assert normalizar_tier(" 2 ") == "II"     # tolera espacios
        assert normalizar_tier(3) == "III"        # tolera int

    def test_un_tier_inventado_no_pasa(self):
        from config.dominio import normalizar_tier
        for malo in ("9", "0", "-1", "abc", "V", "", "  ", None, "1.5"):
            assert normalizar_tier(malo) is None, f"{malo!r} se aceptó como tier"

    def test_agente_rechaza_el_tier_antes_de_tocar_la_api(self):
        # El rechazo debe estar en la validación de argumentos, no después de
        # cargar documentos: si no, ya se pagó.
        import ast
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        assert src.count("normalizar_tier(args.tier) is None") == 2, (
            "las DOS rutas que aceptan --tier (pipeline completo y --control) "
            "deben validarlo")
        # Y antes de cargar los estándares (que ya es trabajo pagado).
        pos_val = src.index("normalizar_tier(args.tier) is None")
        assert pos_val < src.rindex("leer_estandares_virf(tier_str)"), (
            "la validación del tier ocurre después de cargar los estándares")

    def test_existe_un_unico_catalogo_de_tiers(self):
        # Mx_01 tenía su propio _TIER_MAP en paralelo a config.dominio.
        from pathlib import Path
        raiz = Path(__file__).resolve().parents[1]
        mx01 = (raiz / "motor" / "Mx_01_LecturaEvidencias.py").read_text(encoding="utf-8")
        vivas = [l for l in mx01.splitlines() if not l.lstrip().startswith("#")]
        assert "_TIER_MAP" not in "\n".join(vivas), (
            "Mx_01 vuelve a declarar su propio mapa de tiers: dos catálogos que "
            "nadie garantiza iguales.")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28] El caché no se apaga por adivinar el modo
#
# `--prdc` desactivaba el caché "para que producción sea siempre fresca". Pero
# el caché se indexa por SHA-256 del fichero: la frescura ya está garantizada.
# Lo único que lograba era pagar el chunking íntegro (~$1.45) justo en las
# corridas que emiten el entregable, anulando el ahorro de D2 donde más cuesta.
# Para desactivarlo existe el flag explícito --no-cache.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaCacheNoSeApagaPorHeuristica:

    def test_prdc_no_desactiva_el_cache(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        linea = next(l for l in src.splitlines()
                     if l.strip().startswith("cache_activo ="))
        assert "prdc" not in linea, (
            f"--prdc vuelve a apagar el caché por heurística: {linea.strip()}")
        assert "no_cache" in linea, "--no-cache debe seguir apagándolo"

    def test_la_clave_del_cache_es_el_contenido_no_la_fecha(self):
        # Es lo que hace innecesario apagarlo: si el documento cambia, cambia
        # la clave y se relee solo.
        import hashlib, tempfile
        from pathlib import Path
        from modulos.document_cache import DocumentCache
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "doc.txt"
            f.write_text("contenido A", encoding="utf-8")
            h1 = DocumentCache._hash_archivo(f)
            f.write_text("contenido B", encoding="utf-8")
            h2 = DocumentCache._hash_archivo(f)
        assert h1 and h2 and h1 != h2, (
            "el hash no distingue contenidos: entonces sí haría falta apagar el caché")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28] Borrar del caché tiene que borrar de verdad
#
# El merge que añadió el CONCURRENCIA-FIX releía el disco en cada `persistir()`
# y resucitaba todo lo eliminado. Las TRES rutas de borrado (invalidar,
# purgar_huerfanos, limpiar_todo) eran no-ops. Y no fallaban en silencio: la
# consola informaba "🧹 Caché limpiado: 16 entradas eliminadas" con el fichero
# intacto — el usuario cree que partió de cero cuando no lo hizo.
#
# La corrección usa un registro de bajas de la sesión, así que sigue siendo
# cierto que las entradas de OTRO proceso se conservan (esa era la razón del
# merge). Ambas cosas se comprueban aquí.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaBorrarDelCacheBorraDeVerdad:

    def _cache(self, d):
        from pathlib import Path
        from modulos.document_cache import DocumentCache
        c = DocumentCache(cache_dir=Path(d), enabled=True)
        for i in range(3):
            c._data[f"/no/existe/{i}.txt"] = {"hash_sha256": "x", "contenido": "c", "hits": 0}
        c._dirty = True
        c.persistir()
        return c

    def _en_disco(self, c):
        import json
        return json.loads(c._filepath.read_text(encoding="utf-8"))

    def test_limpiar_todo_deja_el_fichero_vacio(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            c = self._cache(d)
            assert len(self._en_disco(c)) == 3
            c.limpiar_todo()
            assert self._en_disco(c) == {}, (
                "limpiar_todo informó el borrado pero el JSON conserva las entradas")

    def test_purgar_huerfanos_elimina_de_disco_lo_que_dice_eliminar(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            c = self._cache(d)
            n = c.purgar_huerfanos()
            c.persistir()
            assert n == 3
            assert len(self._en_disco(c)) == 0, (
                f"purgar_huerfanos informó {n} bajas pero quedan "
                f"{len(self._en_disco(c))} en disco")

    def test_invalidar_una_entrada_no_la_resucita(self):
        import tempfile
        from pathlib import Path
        with tempfile.TemporaryDirectory() as d:
            c = self._cache(d)
            # La clave del caché es str(path.resolve()): hay que usar la misma
            # normalización o el borrado no encuentra nada (y en Windows
            # "/no/existe" se resuelve a "C:\no\existe").
            objetivo = str(Path("/no/existe/1.txt").resolve())
            c._data[objetivo] = {"hash_sha256": "x", "contenido": "c", "hits": 0}
            c._dirty = True
            c.persistir()
            n_antes = len(self._en_disco(c))
            assert c.invalidar_archivo(Path(objetivo)) is True
            c.persistir()
            assert objetivo not in self._en_disco(c)
            assert len(self._en_disco(c)) == n_antes - 1, (
                "se llevó por delante otras entradas")

    def test_el_borrado_no_rompe_la_garantia_de_concurrencia(self):
        # Razón de ser del merge: lo que escribió OTRO proceso mientras
        # corríamos debe sobrevivir. Solo se pierde lo marcado como baja.
        import json, tempfile
        from pathlib import Path
        from modulos.document_cache import DocumentCache
        with tempfile.TemporaryDirectory() as d:
            c = DocumentCache(cache_dir=Path(d), enabled=True)
            c._data["/mio.txt"] = {"hash_sha256": "m", "contenido": "c", "hits": 0}
            c._dirty = True
            # Simula a otro proceso escribiendo entre medias.
            c._filepath.parent.mkdir(parents=True, exist_ok=True)
            c._filepath.write_text(
                json.dumps({"/de_otro.txt": {"hash_sha256": "o", "contenido": "c", "hits": 0}}),
                encoding="utf-8")
            c.persistir()
            assert sorted(self._en_disco(c)) == ["/de_otro.txt", "/mio.txt"], (
                "el fix de borrado rompió el merge entre procesos")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28] El resumen final no puede contradecirse a sí mismo
#
# Corrida real (--titulo AuditoriaQA --tier 1 --prdc): el bloque de integridad
# informaba "Actividades evaluadas OK : 19" y tres líneas más abajo
# "Actividades totales: 15". Más evaluadas que existentes.
#
# El score NO estaba mal: las 4 de diferencia son los controles CDD que se
# integran en el ámbito 'Calidad de datos' (2,1,5,5,5 → 3.60, el valor
# publicado). Lo que fallaba era el contador, que solo miraba el estándar VIRF.
# Un auditor que compara ambas cifras pierde la confianza en todo el informe.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaElResumenFinalCuadraConsigoMismo:

    def test_las_dos_cifras_se_derivan_de_la_misma_fuente(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        assert "_n_evaluaciones = sum(len(v) for v in resultados_ambitos.values())" in src, (
            "el total ya no se deriva de las evaluaciones reales: puede volver a "
            "quedar por debajo de las evaluadas OK")
        assert "control(es) CDD" in src, (
            "el desglose que explica la diferencia ha desaparecido")

    def test_cada_fuente_integrada_se_cuenta_por_separado(self):
        """
        [CODIGO-FIX 2026-07-30] El desglose se calculaba por RESTA
        (`_n_evaluaciones - total_actividades`) y atribuía el residuo entero a
        los controles CDD. Eso solo es correcto mientras haya UNA sola fuente
        de evaluaciones añadidas.

        Al integrar la revisión de código en 'Implementación' apareció la
        segunda, y el resumen declaraba «8 control(es) CDD» cuando eran 4 CDD y
        4 módulos de código: la misma clase de contador mentiroso que este
        bloque de auditoría existe para impedir, reintroducida por la puerta de
        atrás. Ahora cada fuente se cuenta filtrando por su etiqueta `control`.
        """
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        assert "_n_cdd_integrados" in src and "_n_codigo_integrados" in src, (
            "el desglose volvió a contar por resta: con dos fuentes integradas "
            "atribuye todas las evaluaciones a la primera etiqueta")
        assert "_residuo" in src, (
            "sin residuo declarado, una TERCERA fuente futura volvería a "
            "contarse en silencio dentro de una de las existentes")

    def test_el_residuo_hace_cuadrar_la_suma_con_dos_fuentes(self):
        """Reproduce la aritmética del resumen con CDD y código a la vez."""
        resultados_ambitos = {
            "Documentación":  [{"puntaje": 3, "control": "X"}] * 4,
            "Calidad de datos": (
                [{"puntaje": 2, "control": "X"}]
                + [{"puntaje": 5, "control": "Controles Automáticos de Calidad de Datos"}] * 4
            ),
            "Implementación": (
                [{"puntaje": 4, "control": "X"}] * 2
                + [{"puntaje": 3, "control": "Revisión de código vs documentación"}] * 4
            ),
        }
        total_actividades = 4 + 1 + 2          # solo el estándar VIRF
        n_evaluaciones = sum(len(v) for v in resultados_ambitos.values())
        n_cdd = len([e for e in resultados_ambitos["Calidad de datos"]
                     if e.get("control") == "Controles Automáticos de Calidad de Datos"])
        n_cod = len([e for e in resultados_ambitos["Implementación"]
                     if e.get("control") == "Revisión de código vs documentación"])
        residuo = n_evaluaciones - total_actividades - n_cdd - n_cod

        assert n_cdd == 4 and n_cod == 4
        assert residuo == 0, (
            "el desglose no cuadra: la suma de las partes debe dar el total "
            f"({total_actividades} + {n_cdd} + {n_cod} != {n_evaluaciones})")

    def test_evaluadas_ok_nunca_supera_al_total_declarado(self):
        # Reproduce la aritmética del resumen con la forma real de los datos.
        resultados_ambitos = {
            "Documentación":    [{"puntaje": 3}] * 4,
            "Calidad de datos": [{"puntaje": 2}] + [{"puntaje": 5}] * 4,  # 1 act + 4 CDD
            "Metodología":      [{"puntaje": 2}] * 5,
        }
        total_actividades = 4 + 1 + 5          # solo el estándar VIRF
        n_validas = sum(1 for evs in resultados_ambitos.values()
                        for e in evs if e.get("puntaje") is not None)
        n_evaluaciones = sum(len(v) for v in resultados_ambitos.values())
        assert n_validas > total_actividades, "el escenario ya no reproduce el bug"
        assert n_validas <= n_evaluaciones, (
            "la cifra que se publica como total sigue siendo menor que las "
            "actividades evaluadas con éxito")

    def test_el_score_del_ambito_incluye_los_controles_integrados(self):
        # Justifica que la corrección sea del CONTADOR y no del score: los
        # controles CDD deben seguir pesando en 'Calidad de datos'.
        from modulos.motor_ia import calcular_score_ambito
        evs = [{"puntaje": 2}, {"puntaje": 1}, {"puntaje": 5},
               {"puntaje": 5}, {"puntaje": 5}]
        assert calcular_score_ambito(evs) == 3.6, (
            "el ámbito ya no promedia los controles CDD integrados; el 3.60 "
            "publicado en la corrida real dejaría de reproducirse")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28 · fase 3.5] Fallos de red y de credenciales
#
# Reproducido contra la API real (clave inválida) y contra un host no enrutable
# (ANTHROPIC_BASE_URL=http://10.255.255.1:81), no con mocks.
#
# Bug encontrado: `validar_conexion()` devolvía solo True/False y el motivo se
# perdía. get_cliente_ia() levantaba un RuntimeError genérico sin rastro del
# 401, y el PRE-FLIGHT —que decide abortar-o-seguir buscando "401" en el
# mensaje— clasificaba una clave RECHAZADA como corte de red pasajero: seguía
# adelante, cargaba toda la evidencia y moría 300 líneas después escupiendo dos
# tracebacks encadenados.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaFallosDeRedSeDiagnosticanBien:

    def test_el_motivo_del_fallo_de_conexion_no_se_pierde(self):
        from config.ia import ClienteIA
        assert hasattr(ClienteIA, "ultimo_error_conexion"), (
            "sin este campo, el 401 vuelve a diluirse en un RuntimeError genérico")

    def test_get_cliente_ia_propaga_la_causa(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "config" / "ia.py").read_text(encoding="utf-8")
        assert "raise RuntimeError(f\"❌ Error inicializando IA: {e}\") from e" in src, (
            "se perdió el `from e`: __cause__ queda vacío y el pre-flight no "
            "puede inspeccionar la cadena")
        assert "ultimo_error_conexion" in src

    def test_el_preflight_recorre_toda_la_cadena_de_causas(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        assert "_cur.__cause__ or _cur.__context__" in src, (
            "el pre-flight vuelve a mirar solo str(e): un 401 envuelto pasa "
            "por error de red y la corrida continúa")

    def test_un_401_envuelto_se_reconoce_como_autenticacion(self):
        # Reproduce la forma EXACTA del envoltorio de config/ia.py.
        try:
            try:
                raise RuntimeError(
                    "❌ No se pudo conectar a ANTHROPIC — APIStatusError: "
                    "Error code: 401 - authentication_error")
            except Exception as interno:
                raise RuntimeError(f"❌ Error inicializando IA: {interno}") from interno
        except Exception as e:
            cadena, cur = [], e
            while cur is not None and len(cadena) < 10:
                cadena.append(str(cur))
                cur = cur.__cause__ or cur.__context__
            err = " | ".join(cadena)
        assert "401" in err or "authentication" in err.lower()

    def test_sin_conexion_se_aborta_en_vez_de_seguir(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
        assert "No hay conexión con el proveedor de IA" in vivas, (
            "el fallo de red vuelve a 'advertir y continuar': morirá luego con "
            "un traceback crudo al instanciar el chunker")

    def test_un_corte_a_mitad_de_corrida_no_puntua_la_actividad(self):
        # El caso peligroso: el pre-flight pasa y la red se cae DESPUÉS. Una
        # actividad no evaluada jamás puede convertirse en un puntaje bajo.
        import config.ia as ia
        import modulos.motor_ia as motor_ia

        class ClienteQueSeCae:
            def generar_mensaje(self, *a, **k):
                raise TimeoutError("Request timed out or interrupted")
            def validar_conexion(self):
                return True

        previo = ia._CLIENTE_CACHE
        try:
            ia._CLIENTE_CACHE = ClienteQueSeCae()
            evs = motor_ia.evaluar_ambito_completo(
                ambito="Metodología",
                actividades=[{"actividad": "A", "control": "C1",
                              "tipo_ctrl": "Cuantitativo"}],
                contexto="Evidencia real y suficiente para evaluar.",
                titulo_modelo="M", cobertura_docs=100.0)
        finally:
            ia._CLIENTE_CACHE = previo

        e = evs[0]
        assert e.get("puntaje") is None, "un timeout se convirtió en puntaje"
        assert e.get("evaluacion_valida") is False, (
            "sin esta marca, el bloque de integridad no la cuenta como fallo "
            "técnico y desaparece del recuento")
        assert motor_ia.calcular_score_ambito(evs) is None, (
            "el ámbito puntúa pese a que ninguna actividad pudo evaluarse")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28 · fase 4] Consistencia cruzada
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaConsistenciaCruzada:

    _SKIP = ("archivo", "venv", ".venv", "__pycache__", "outputs", "node_modules")
    _PAT = (r'(?:getenv|environ\[|_num_env|_entero|_decimal|'
            r'_booleano|_texto)\(?\s*\[?\s*["\']([A-Z_0-9]+)["\']')

    def _raiz(self):
        from pathlib import Path
        return Path(__file__).resolve().parents[1]

    def _usadas(self, incluir_tests: bool):
        import re
        pat, usadas = re.compile(self._PAT), set()
        for f in self._raiz().rglob("*.py"):
            if any(p in f.parts for p in self._SKIP):
                continue
            if not incluir_tests and "tests" in f.parts:
                continue
            usadas |= set(pat.findall(f.read_text(encoding="utf-8", errors="ignore")))
        return usadas

    def _documentadas(self):
        import re
        texto = (self._raiz() / ".env.example").read_text(encoding="utf-8")
        return set(re.findall(r'^\s*#?\s*([A-Z_0-9]+)\s*=', texto, re.M))

    def test_toda_variable_de_entorno_leida_esta_documentada(self):
        # Había 14 variables reales que ningún usuario podía descubrir sin leer
        # config/parametros.py, entre ellas los umbrales anti-sesgo y los
        # parámetros que gobiernan el coste del chunking.
        sin_doc = sorted(v for v in self._usadas(False) - self._documentadas()
                         if not v.startswith("__") and not v.isdigit())
        assert not sin_doc, f"variables leídas pero no documentadas: {sin_doc}"

    def test_ninguna_variable_documentada_es_decorativa(self):
        # RAG_TOP_K, RAG_MIN_SCORE y RAG_VECTORDB_DIR llevaban tiempo en
        # .env.example sin que una sola línea las leyera: prometían un control
        # inexistente y cambiarlas no producía efecto NI aviso.
        muertas = sorted(v for v in self._documentadas() - self._usadas(True)
                         if not v.isdigit())
        assert not muertas, f"documentadas pero nunca leídas: {muertas}"

    def test_ninguna_variable_se_declara_dos_veces_en_env_example(self):
        # `VIRF_MAX_CTX` estaba declarado dos veces con valores distintos:
        # 15000 en la sección de contexto y 100000 en la de chunking avanzado.
        #
        # Por qué esto es peor que un simple descuido: en un .env GANA EL ÚLTIMO
        # (verificado con python-dotenv, que parsea a un dict secuencialmente).
        # Quien copiara el fichero se llevaba 100000 mientras leía 15000 más
        # arriba, y ninguna de las dos líneas mentía por separado. Un fallo así
        # no produce error, produce una corrida con un presupuesto de contexto
        # que nadie eligió — y por tanto un informe cuya cobertura declarada no
        # se puede reproducir a partir del fichero de configuración.
        #
        # Solo cuentan las declaraciones ACTIVAS: las comentadas son
        # documentación de una opción, no una asignación.
        import re
        from collections import Counter
        texto = (self._raiz() / ".env.example").read_text(encoding="utf-8")
        activas = re.findall(r'^\s*([A-Z_0-9]+)\s*=', texto, re.M)
        repetidas = sorted(v for v, n in Counter(activas).items() if n > 1)
        assert not repetidas, (
            f"declaradas dos veces en .env.example (gana la ultima): {repetidas}")

    def test_los_mandos_rag_llegan_de_verdad_al_evaluador(self):
        import inspect
        from config import RAG_TOP_K, RAG_MIN_SCORE
        import modulos.motor_ia as motor_ia
        for fn in (motor_ia.evaluar_actividad, motor_ia.evaluar_ambito_completo):
            par = inspect.signature(fn).parameters
            assert par["rag_top_k"].default == RAG_TOP_K, (
                f"{fn.__name__} vuelve a llevar el top_k hardcodeado")
            assert par["rag_min_score"].default == RAG_MIN_SCORE, (
                f"{fn.__name__} vuelve a llevar el min_score hardcodeado")

    def test_una_similitud_imposible_no_deja_el_rag_mudo(self):
        # RAG_MIN_SCORE=5 no es "más estricto": filtra TODOS los chunks.
        import os
        from config.parametros import _decimal
        previo = os.environ.get("RAG_MIN_SCORE")
        try:
            os.environ["RAG_MIN_SCORE"] = "5"
            assert _decimal("RAG_MIN_SCORE", 0.35, minimo=0.0, maximo=1.0) == 0.35
        finally:
            if previo is None:
                os.environ.pop("RAG_MIN_SCORE", None)
            else:
                os.environ["RAG_MIN_SCORE"] = previo

    def test_una_sola_ruta_para_el_indice_rag(self):
        # El fallo original: src/rag calculaba su ruta con CUATRO .parent desde
        # src/rag/base_indexer.py y aterrizaba FUERA del proyecto, mientras
        # config.VECTORDB_DIR apuntaba dentro. El índice se escribía en un sitio
        # y se leía en otro; como el retriever devuelve [] en silencio ante un
        # índice ausente, el RAG parecía activo y nunca aportaba nada.
        #
        # [2026-07-31] El índice ya no es vectorial (BM25 + TF-IDF sobre disco),
        # así que la ruta única es `config_rag.INDICE_DIR` y no VECTORDB_DIR. El
        # invariante que se protege es el mismo: UNA ruta, dentro del proyecto,
        # y que quien escribe y quien lee usen exactamente esa.
        from src.rag.config_rag import INDICE_DIR, RAIZ_PROYECTO
        from src.rag.indexador_lexico import IndexadorLexico, ruta_indice

        assert ruta_indice("VaR").parent == INDICE_DIR, (
            "el indexador escribe fuera de la ruta oficial del índice")
        assert IndexadorLexico("VaR").ruta == ruta_indice("VaR"), (
            "el indexador y la función de ruta no coinciden")
        assert RAIZ_PROYECTO == self._raiz(), (
            f"src/rag calcula mal la raíz: {RAIZ_PROYECTO} != {self._raiz()}")
        assert (INDICE_DIR.is_relative_to(self._raiz())
                or "dbfs" in str(INDICE_DIR)), (
            f"el índice RAG cae fuera del proyecto: {INDICE_DIR}")

    def test_el_paquete_config_reexporta_todo_lo_que_declara(self):
        import importlib
        import config
        faltan = {}
        for sub in ("parametros", "rutas", "dominio", "ia"):
            m = importlib.import_module(f"config.{sub}")
            ausentes = [n for n in getattr(m, "__all__", []) if not hasattr(config, n)]
            if ausentes:
                faltan[sub] = ausentes
        assert not faltan, (
            f"declarados en __all__ pero no accesibles como `from config import X`: "
            f"{faltan}. Los consumidores acaban importando de config.<submódulo>, "
            f"saltándose la API del paquete.")

    def test_no_hay_ciclos_de_import(self):
        import ast
        import collections
        raiz = self._raiz()
        mods = {}
        for f in raiz.rglob("*.py"):
            if any(p in f.parts for p in self._SKIP):
                continue
            nom = ".".join(f.relative_to(raiz).with_suffix("").parts)
            if nom.endswith(".__init__"):
                nom = nom[: -len(".__init__")]
            mods[nom] = f
        grafo = collections.defaultdict(set)
        for nom, f in mods.items():
            try:
                arb = ast.parse(f.read_text(encoding="utf-8"))
            except SyntaxError:
                continue
            for n in ast.walk(arb):
                tgt = None
                if isinstance(n, ast.ImportFrom) and n.module:
                    tgt = n.module
                elif isinstance(n, ast.Import):
                    tgt = n.names[0].name
                if not tgt:
                    continue
                for cand in (tgt, tgt.split(".")[0]):
                    if cand in mods and cand != nom:
                        grafo[nom].add(cand)
                        break
        color, ciclos = {}, []

        def dfs(u, pila):
            color[u] = 1
            pila.append(u)
            for v in sorted(grafo[u]):
                if color.get(v) == 1:
                    ciclos.append(pila[pila.index(v):] + [v])
                elif color.get(v, 0) == 0:
                    dfs(v, pila)
            pila.pop()
            color[u] = 2

        for m in sorted(grafo):
            if color.get(m, 0) == 0:
                dfs(m, [])
        assert not ciclos, ("ciclos de import: "
                            + "; ".join(" -> ".join(c) for c in ciclos[:5]))


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28 · fase 4] Sin documentos ≠ incumplimiento (ruta Mx_03)
#
# `evaluar_dimension()` emitía, para una dimensión SIN UN SOLO DOCUMENTO:
#   estado="No cumple", riesgo="Alto", score=0
# y ese 0 lo eleva _normalizar_score() a 1, el peor puntaje de la escala 1-5.
# Es el patrón dominante de esta auditoría —ausencia de evidencia presentada
# como resultado negativo— y se le escapó al D3-FIX porque hoy no la llama
# nadie; pero la función sigue exportada y quien la reactive lo heredaría.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaSinDocumentosNoEsIncumplimientoEnMx03:

    def _fuente(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "motor"
               / "Mx_03_LlamarIA.py").read_text(encoding="utf-8")
        return "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))

    def test_la_funcion_muerta_sigue_retirada(self):
        # [2026-07-29] La función se retiró: una función pública sin llamantes
        # es un pasivo — ningún test la ejercita, así que su comportamiento
        # deriva sin que nadie lo note. Estos tests pasan de vigilar su
        # CONTENIDO a vigilar que no vuelva sin sus guardas.
        import ast
        from pathlib import Path
        for fichero, nombre in (("Mx_03_LlamarIA.py", "evaluar_dimension"),
                                ("Mx_02_EstructuraPrompt.py", "prompt_evaluar_dimension")):
            arbol = ast.parse((Path(__file__).resolve().parents[1] / "motor"
                               / fichero).read_text(encoding="utf-8"))
            definidas = [n.name for n in ast.walk(arbol)
                         if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
            assert nombre not in definidas, (
                f"{nombre}() ha vuelto a {fichero}. Si se reactiva a propósito, "
                f"debe traer sus guardas: una dimensión sin documentos NO puede "
                f"emitir score=0 (que _normalizar_score eleva a 1, el peor "
                f"puntaje) ni rotularse 'No cumple'. Ver "
                f"archivo/codigo_muerto_2026-07-29/{nombre}.py")

    def test_no_reaparece_la_puntuacion_sobre_el_vacio(self):
        # Guarda el invariante para TODO el módulo, no solo para la función
        # retirada: ninguna rama de Mx_03 debe puntuar 0 una dimensión de la que
        # no se leyó nada, ni rotularla como incumplimiento.
        vivas = self._fuente()
        assert '"score": 0' not in vivas, (
            "alguna rama vuelve a puntuar con 0 una dimensión sin documentos; "
            "_normalizar_score lo convierte en 1, el peor puntaje de la escala")
        assert 'else "No cumple"' not in vivas, (
            "vuelve a rotular 'No cumple' una dimensión de la que no se leyó "
            "ni un solo documento")

    def test_la_retirada_no_dejo_imports_huerfanos(self):
        # Al retirar prompt_evaluar_dimension, su import en Mx_03 apuntaba a un
        # símbolo inexistente: ImportError al cargar el módulo.
        import importlib
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        mod = importlib.import_module("Mx_03_LlamarIA")
        assert not hasattr(mod, "prompt_evaluar_dimension"), (
            "el import huérfano sigue ahí")
        assert hasattr(mod, "generar_sintesis"), (
            "la retirada se llevó por delante una función que SÍ se usa")

    def test_un_score_nulo_presente_no_descarta_el_puntaje(self):
        # `.get("score", ev.get("puntaje"))` devolvía None cuando "score"
        # existía con valor nulo: el puntaje válido del dict se perdía.
        from modulos.generador_word import _score_o_puntaje, _normalizar_score
        assert _score_o_puntaje({"score": None, "puntaje": 4}) == 4
        assert _normalizar_score(_score_o_puntaje({"score": None, "puntaje": 4})) == 4
        assert _score_o_puntaje({"score": None, "puntaje": None}) is None
        assert _score_o_puntaje({"score": 85, "puntaje": 4}) == 85


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28 · fase 6] Seguridad y distribución
#
# `.claude/settings.local.json` guarda el historial de comandos aprobados TAL
# CUAL se escribieron. Durante esta auditoría, la prueba de clave inválida
# (`ANTHROPIC_API_KEY=sk-ant-... python agente.py ...`) quedó persistida ahí en
# claro. Esa era falsa a propósito, pero el fichero NO estaba en .gitignore y
# el mecanismo sirve igual para una clave real.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaSecretosYDistribucion:

    _BIN = (".pyc", ".docx", ".xlsx", ".xlsm", ".pdf", ".png", ".jpg", ".parquet")
    _SKIP = ("venv", ".venv", "__pycache__", ".git", "archivo")

    def _raiz(self):
        from pathlib import Path
        return Path(__file__).resolve().parents[1]

    def _ignorados(self):
        return {l.strip() for l in
                (self._raiz() / ".gitignore").read_text(encoding="utf-8").splitlines()}

    def test_gitignore_cubre_el_historial_de_comandos(self):
        ign = self._ignorados()
        assert ".claude/settings.local.json" in ign or ".claude/" in ign, (
            "settings.local.json registra cada comando aprobado; una clave "
            "pasada en línea queda ahí en claro y se commitearía")

    def test_gitignore_cubre_todo_lo_que_se_genera_en_cada_corrida(self):
        ign = self._ignorados()
        for gen in (".env", "outputs/", "data/cache/", "data/vectordb/"):
            assert gen in ign, f"{gen} no está protegido en .gitignore"

    def test_ninguna_clave_real_fuera_de_env(self):
        import re
        pat = re.compile(r"sk-ant-[A-Za-z0-9_\-]{25,}")
        fugas = []
        for f in self._raiz().rglob("*"):
            if not f.is_file() or any(p in f.parts for p in self._SKIP):
                continue
            if f.name == ".env" or f.suffix.lower() in self._BIN:
                continue
            try:
                texto = f.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            for m in pat.finditer(texto):
                if any(x in m.group(0).upper()
                       for x in ("TEST", "INVALID", "EJEMPLO", "TU_API")):
                    continue
                fugas.append(str(f.relative_to(self._raiz())))
        assert not fugas, f"clave con formato real fuera de .env: {sorted(set(fugas))}"

    def test_ningun_print_vuelca_la_clave_entera(self):
        # Se admite longitud, booleano o un sufijo corto; nunca la clave.
        import re
        malos = []
        for f in self._raiz().rglob("*.py"):
            if any(p in f.parts for p in self._SKIP):
                continue
            for i, l in enumerate(f.read_text(encoding="utf-8", errors="ignore")
                                  .splitlines(), 1):
                if not re.search(r'\b(print|logger\.\w+)\s*\(', l):
                    continue
                # f-string que interpola la variable de clave completa
                if re.search(r'\{\s*(api_key|API_KEY|ANTHROPIC_API_KEY)\s*\}', l):
                    malos.append(f"{f.name}:{i}")
        assert not malos, f"vuelcan la clave completa: {malos}"

    def test_el_informe_entregable_no_filtra_rutas_de_la_maquina(self):
        # Los .docx son lo que sale de la organización. Deben poder enviarse
        # sin revelar el usuario ni la estructura de carpetas de quien validó.
        import re
        from pathlib import Path
        try:
            from docx import Document
        except ImportError:
            import pytest
            pytest.skip("python-docx no instalado")
        pat = re.compile(r'[A-Za-z]:\\Users\\|/home/[a-z]+/|/Users/[A-Za-z]+/')
        salidas = Path(self._raiz() / "outputs")
        if not salidas.exists():
            import pytest
            pytest.skip("sin informes generados")
        sucios = []
        for f in salidas.rglob("*.docx"):
            # Word deja ficheros de propietario `~$nombre.docx` mientras tiene
            # el informe abierto. No son documentos —son 162 bytes de metadatos—
            # y `Document()` revienta con ellos. Sin esta línea, la puerta falla
            # solo porque un validador esté leyendo un informe: un aviso que
            # salta cuando no debe enseña al equipo a ignorar la puerta.
            if f.name.startswith("~$"):
                continue
            d = Document(str(f))
            txt = "\n".join(p.text for p in d.paragraphs)
            for tb in d.tables:
                for row in tb.rows:
                    for c in row.cells:
                        txt += "\n" + c.text
            if pat.search(txt):
                sucios.append(f.name)
        assert not sucios, f"informes con rutas absolutas de la máquina: {sucios}"

    def test_todas_las_dependencias_llevan_version(self):
        import re
        lineas = [l.strip() for l in
                  (self._raiz() / "requirements.txt").read_text(encoding="utf-8").splitlines()
                  if l.strip() and not l.strip().startswith("#")]
        sin_version = [l for l in lineas if not re.search(r'[=<>~]', l)]
        assert not sin_version, (
            f"dependencias sin restricción de versión (la corrida deja de ser "
            f"reproducible y el informe no es auditable): {sin_version}")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-28 · fase 7] El caché no puede recortar lo que el chunker
# tiene que cubrir
#
# El TRUNCADO-FIX de la auditoría del 2026-07-26 estaba aplicado A MEDIAS:
# arregló la lectura DIRECTA (entregar el texto íntegro al ChunkerService) pero
# dejó la rama del CACHÉ pidiendo `max_chars=15.000`. El caché guardaba y servía
# el texto recortado declarando `chars_totales` del documento entero.
#
# Medido sobre Manual_Metodologico_LaR_completo.pdf (1.302.266 chars), misma
# orden y misma configuración:
#     sin caché → 40 segmentos, cobertura 100.0%
#     con caché →  2 segmentos, cobertura   1.2%
#
# Como el caché está activo en casi todas las corridas, el chunking adaptativo
# no servía de nada: el documento nunca le llegaba entero. Y el informe se
# emitía sobre el 1,2% del manual.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaElCacheNoRecortaLoQueElChunkerDebeCubrir:

    def test_sin_tope_el_cache_guarda_el_texto_integro(self):
        import tempfile
        from pathlib import Path
        from modulos.document_cache import DocumentCache
        largo = "x" * 50_000
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "doc.txt"
            f.write_text(largo, encoding="utf-8")
            c = DocumentCache(cache_dir=Path(d) / "cache", enabled=True)
            doc = c.get(path=f, extractor_fn=lambda p: largo, max_chars=None)
            assert len(doc["contenido"]) == 50_000, (
                "el caché recortó pese a pedirle explícitamente sin tope")
            assert doc["truncado"] is False
            assert doc["chars_totales"] == 50_000

    def test_con_tope_sigue_recortando_y_lo_declara(self):
        # El tope debe seguir funcionando cuando NO hay chunker detrás.
        import tempfile
        from pathlib import Path
        from modulos.document_cache import DocumentCache
        largo = "x" * 50_000
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "doc.txt"
            f.write_text(largo, encoding="utf-8")
            c = DocumentCache(cache_dir=Path(d) / "cache", enabled=True)
            doc = c.get(path=f, extractor_fn=lambda p: largo, max_chars=15_000)
            assert len(doc["contenido"]) == 15_000
            assert doc["truncado"] is True, (
                "recorta pero no lo declara: el consumidor creería tenerlo entero")
            assert doc["chars_totales"] == 50_000

    def test_el_cache_nunca_sirve_menos_de_lo_que_declara(self):
        # El invariante que se violaba: contenido de 15.000 chars con
        # chars_totales=1.302.266 y sin marca de truncado utilizable.
        import json
        from pathlib import Path
        ruta = Path(__file__).resolve().parents[1] / "data" / "cache" / "document_cache.json"
        if not ruta.exists():
            import pytest
            pytest.skip("sin caché en disco")
        d = json.loads(ruta.read_text(encoding="utf-8"))
        mentirosas = [
            k.split("\\")[-1] for k, v in d.items()
            if isinstance(v, dict)
            and v.get("chars_totales", 0) > len(v.get("contenido", ""))
            and not v.get("truncado")
        ]
        assert not mentirosas, (
            f"entradas que declaran más caracteres de los que guardan sin "
            f"marcarse como truncadas: {mentirosas}")

    def test_mx01_pide_el_texto_integro_cuando_el_chunking_esta_activo(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "motor"
               / "Mx_01_LecturaEvidencias.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
        assert "_max_cache = None if _chunk_on else max_c" in vivas, (
            "la rama del caché vuelve a imponer su propio tope: el chunker "
            "recibirá el documento ya recortado y la cobertura real caerá")
        assert "max_chars=_max_cache" in vivas, (
            "cache.get() ya no usa el tope condicional")

    def test_ambas_rutas_de_lectura_entregan_lo_mismo(self):
        # La prueba de fondo: con chunking activo, leer con caché y sin caché
        # tiene que producir el MISMO contenido. Era justo lo que no pasaba.
        import tempfile
        from pathlib import Path
        from modulos.document_cache import DocumentCache
        largo = "y" * 40_000
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "doc.txt"
            f.write_text(largo, encoding="utf-8")
            sin = DocumentCache(cache_dir=Path(d) / "c1", enabled=False)
            con = DocumentCache(cache_dir=Path(d) / "c2", enabled=True)
            a = sin.get(path=f, extractor_fn=lambda p: largo, max_chars=None)
            con.get(path=f, extractor_fn=lambda p: largo, max_chars=None)  # puebla
            b = con.get(path=f, extractor_fn=lambda p: largo, max_chars=None)  # sirve
            assert len(a["contenido"]) == len(b["contenido"]), (
                f"el caché devuelve {len(b['contenido'])} chars donde la lectura "
                f"directa devuelve {len(a['contenido'])}")


# ══════════════════════════════════════════════════════════════════════════════
# [MULTIMODELO 2026-07-29] Un árbol de evidencia = un modelo
#
# `cargar_todos_inputs()` lee TODO `inputs/` sin filtrar por modelo, y `--titulo`
# solo rotula el informe e infiere el dominio RAG. Con la evidencia de varios
# modelos en el mismo árbol, el manual de uno puntúa como evidencia de otro: un
# informe de VaR podría citar el manual del LaR. Indefendible ante un regulador.
#
# `--raiz-evidencia` separa los árboles. Estas pruebas fijan que la redirección
# sea COMPLETA (las dos vías de carga de evidencia) y que NO arrastre consigo la
# vara de medir ni los entregables.
# ══════════════════════════════════════════════════════════════════════════════
class TestMultimodeloRaizDeEvidencia:

    def _arbol(self, tmp_path, nombre="ModeloX"):
        raiz = tmp_path / nombre
        for sub in ("documentacion/modelamiento", "documentacion/seguimiento",
                    "papers", "calidad_datos", "implementacion", "usos"):
            (raiz / "inputs" / sub).mkdir(parents=True, exist_ok=True)
        (raiz / "inputs" / "documentacion" / "modelamiento" / "manual.md").write_text(
            f"# Manual de {nombre}", encoding="utf-8")
        return raiz

    def _restaurar(self):
        """Devuelve RUTAS a la raíz del proyecto (el dict es global del módulo)."""
        import sys
        from pathlib import Path
        raiz_proyecto = Path(__file__).resolve().parents[1]
        sys.path.insert(0, str(raiz_proyecto / "motor"))
        from Mx_00_CargaRutas import redirigir_evidencia
        redirigir_evidencia(raiz_proyecto)

    def test_redirige_las_seis_carpetas_de_evidencia(self, tmp_path):
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        from Mx_00_CargaRutas import redirigir_evidencia
        raiz = self._arbol(tmp_path)
        try:
            rutas = redirigir_evidencia(raiz)
            assert set(rutas) == {"doc_modelamiento", "doc_seguimiento", "papers",
                                  "calidad_datos", "implementacion", "usos"}
            for nombre, p in rutas.items():
                assert str(p).startswith(str(raiz.resolve())), (
                    f"'{nombre}' sigue apuntando fuera de la raíz pedida: {p}")
        finally:
            self._restaurar()

    def test_una_raiz_sin_inputs_falla_de_inmediato(self, tmp_path):
        import sys
        import pytest
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        from Mx_00_CargaRutas import redirigir_evidencia
        vacia = tmp_path / "sin_inputs"
        vacia.mkdir()
        try:
            with pytest.raises(FileNotFoundError) as exc:
                redirigir_evidencia(vacia)
            # El mensaje debe enseñar la estructura, no solo decir que falta.
            assert "inputs" in str(exc.value)
            assert "documentacion/modelamiento" in str(exc.value)
        finally:
            self._restaurar()

    def test_cargar_todos_inputs_ve_la_raiz_redirigida(self, tmp_path):
        # La prueba de fondo: mutar RUTAS tiene que llegar hasta el lector.
        # Mx_01 importó `RUTAS` por referencia; si alguien reasignara el nombre
        # en vez de mutar el dict, esto seguiría leyendo el árbol del proyecto
        # y la separación entre modelos sería ficticia.
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        from Mx_00_CargaRutas import redirigir_evidencia
        from Mx_01_LecturaEvidencias import cargar_todos_inputs
        raiz = self._arbol(tmp_path, "ModeloAislado")
        try:
            redirigir_evidencia(raiz)
            docs = cargar_todos_inputs()
            leidos = [d for lista in docs.values() for d in lista]
            assert leidos, "no se leyó ningún documento de la raíz redirigida"
            for d in leidos:
                assert "ModeloAislado" in d.get("contenido", ""), (
                    "se está leyendo evidencia ajena a la raíz pedida")
        finally:
            self._restaurar()

    def test_redirigir_por_el_paquete_llega_al_lector(self, tmp_path):
        """
        El bug que se escapó a la primera versión de estos tests.

        Este módulo vive DOS VECES en sys.modules con identidades distintas:
        'Mx_00_CargaRutas' (import a secas, porque motor/ está en sys.path) y
        'motor.Mx_00_CargaRutas' (cualificado por paquete). Cada una tiene su
        PROPIO dict RUTAS.

        `agente.py` importa por la vía del paquete y `Mx_01` lee por la vía
        directa, así que la mutación actualizaba una copia y el lector
        consultaba la otra. El fallo era SILENCIOSO: la consola anunciaba
        «Evidencia: modelos/VaR_FRTB» mientras leía la del proyecto, y se emitió
        un informe titulado «VaR Mercado FRTB» cuya huella documental contenía
        Manual_Metodologico_LaR_completo.pdf.

        Los tests anteriores no lo vieron porque usaban una SOLA forma de
        import, y así ambas puntas caían en el mismo objeto de módulo. Este
        reproduce el cruce real: redirige por el paquete y lee por la directa.
        """
        import sys
        from pathlib import Path
        raiz_proyecto = Path(__file__).resolve().parents[1]
        sys.path.insert(0, str(raiz_proyecto))
        sys.path.insert(0, str(raiz_proyecto / "motor"))

        import motor.Mx_00_CargaRutas as via_paquete   # como agente.py
        import Mx_00_CargaRutas as via_directa         # como Mx_01

        raiz = self._arbol(tmp_path, "ModeloPorPaquete")
        try:
            via_paquete.redirigir_evidencia(raiz)
            leida = str(via_directa.RUTAS["inputs"]["papers"])
            assert str(raiz.resolve()) in leida, (
                f"la redirección no llegó al dict que lee Mx_01. "
                f"pedido={raiz} · leería={leida}. "
                f"El informe se titularía con el modelo pedido y evaluaría la "
                f"evidencia de otro.")
        finally:
            self._restaurar()
            via_paquete.redirigir_evidencia(raiz_proyecto)

    def test_no_redirige_la_vara_de_medir_ni_los_entregables(self, tmp_path):
        # El estándar VIRF es el criterio COMÚN. Si cada carpeta trajera el
        # suyo, dos modelos podrían validarse contra criterios distintos sin
        # que nadie lo notara. outputs/ y el caché también son del proyecto.
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        from Mx_00_CargaRutas import redirigir_evidencia, RUTAS
        raiz_proyecto = Path(__file__).resolve().parents[1]
        raiz = self._arbol(tmp_path)
        try:
            estandar_antes = RUTAS["estandares_virf"]
            salidas_antes = RUTAS["outputs"]
            redirigir_evidencia(raiz)
            assert RUTAS["estandares_virf"] == estandar_antes, (
                "el estándar VIRF se movió con la evidencia: dos modelos podrían "
                "validarse contra criterios distintos")
            assert RUTAS["outputs"] == salidas_antes
            assert str(estandar_antes).startswith(str(raiz_proyecto))
        finally:
            self._restaurar()

    def test_el_flag_cubre_las_dos_vias_de_carga_de_evidencia(self):
        # Hay DOS: `cargar_todos_inputs()` (pipeline completo, vía RUTAS) y
        # `BuscadorEvidencias` (pipeline --control, vía base_project_path).
        # Redirigir solo la primera dejaría los controles leyendo el árbol
        # equivocado sin ningún síntoma visible.
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
        assert vivas.count("base_project_path=str(_raiz_ev)") == 2, (
            "alguna llamada al pipeline de controles volvió a la raíz del "
            "proyecto: leería la evidencia de otro modelo")

    def test_la_raiz_se_resuelve_antes_de_cualquier_rama_de_modo(self):
        # `--control` la usa cientos de líneas antes que el pipeline completo.
        # Definirla dentro de una rama la deja sin asignar en las demás — es
        # el UnboundLocalError que mató el pipeline en la fase 2 de la auditoría.
        import ast
        from pathlib import Path
        arbol = ast.parse((Path(__file__).resolve().parents[1] / "agente.py")
                          .read_text(encoding="utf-8"))
        main = next(n for n in ast.walk(arbol)
                    if isinstance(n, ast.FunctionDef) and n.name == "main")
        asignaciones = [n.lineno for n in ast.walk(main)
                        if isinstance(n, ast.Assign)
                        for t in n.targets
                        if isinstance(t, ast.Name) and t.id == "_raiz_ev"]
        usos = [n.lineno for n in ast.walk(main)
                if isinstance(n, ast.Name) and n.id == "_raiz_ev"
                and isinstance(n.ctx, ast.Load)]
        assert len(asignaciones) == 1, (
            f"_raiz_ev se asigna en {len(asignaciones)} sitios: alguna rama "
            f"puede no ejecutar ninguno")
        assert min(usos) > asignaciones[0], (
            f"_raiz_ev se usa en la línea {min(usos)} pero se asigna en la "
            f"{asignaciones[0]}: UnboundLocalError en esa rama")

    def test_sin_el_flag_nada_cambia(self):
        # Quien valide un solo modelo no debe notar la existencia de esto.
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        from Mx_00_CargaRutas import RUTAS
        raiz_proyecto = Path(__file__).resolve().parents[1]
        for nombre, p in RUTAS["inputs"].items():
            assert str(p).startswith(str(raiz_proyecto)), (
                f"'{nombre}' quedó apuntando fuera del proyecto tras las pruebas: {p}")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-29] El índice RAG no puede contaminarse ni perder documentos
#
# Al poblar por primera vez el dominio VaR salieron dos defectos encadenados que
# hacían del RAG algo peor que inútil: activo, silencioso y equivocado.
#
#  1. `_leer_archivo()` calculaba la raíz con CUATRO `.parent` desde
#     src/rag/base_indexer.py y aterrizaba fuera del proyecto. `motor/` no
#     estaba ahí, el import de los lectores de Mx_01 fallaba SIEMPRE y se caía
#     a un fallback que solo entiende .txt… y que devolvía
#     `f"[No se pudo leer: {nombre}]"` COMO CONTENIDO.
#     Medido tras indexar VaR: el chunk con mayor similitud para una consulta
#     sobre backtesting era literalmente «[No se pudo leer: riskmetrics...]».
#     El RAG inyectaba sus propios errores en el prompt como conocimiento
#     experto. Misma familia que el bug de lectura fallida de Mx_01.
#
#  2. El ID de cada chunk era `sha256(texto_del_chunk)`. Dos chunks con el mismo
#     texto —cabeceras y pies repetidos, algo constante en un documento largo—
#     colisionaban y ChromaDB rechazaba el upsert ENTERO del fichero.
#     Medido: Manual_Metodologico_LaR_completo.pdf daba 11 IDs duplicados y
#     quedaba fuera del índice por completo, con el fallo reducido a una línea
#     de warning. Tras la corrección: 5 chunks → 1.538.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaIndiceRagNiContaminadoNiIncompleto:

    def _indexer(self, fuentes=None):
        """
        [2026-07-31] Antes se construía una subclase de `BaseIndexer`. El motor
        real vive ahora en `IndexadorLexico`; `BaseIndexer` es un adaptador que
        delega en él. Se prueba el motor, que es donde está la lógica.
        """
        from src.rag.indexador_lexico import IndexadorLexico
        return IndexadorLexico("test", fuentes=fuentes or [])

    def test_un_fichero_ilegible_no_entra_al_indice(self, tmp_path):
        # Lo que nunca debe pasar: que el mensaje de error se convierta en
        # conocimiento recuperable.
        idx = self._indexer()
        inexistente = tmp_path / "no_existe.pdf"
        texto = idx._leer_archivo(inexistente)
        assert "No se pudo leer" not in texto, (
            "el mensaje de error vuelve a devolverse como contenido: se "
            "indexará y el RAG lo inyectará en los prompts")
        assert texto == "", "un fichero ilegible debe producir cadena vacía"

    def test_la_marca_de_lectura_fallida_de_mx01_se_respeta(self, tmp_path):
        # Mx_01 prefija sus fallos con un centinela justamente para que el
        # consumidor no los confunda con contenido.
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        from Mx_01_LecturaEvidencias import _MARCA_LECTURA_FALLIDA
        idx = self._indexer()
        roto = tmp_path / "roto.pdf"
        roto.write_bytes(b"no soy un pdf")
        texto = idx._leer_archivo(roto)
        assert _MARCA_LECTURA_FALLIDA not in texto, (
            "el centinela de lectura fallida llega al índice")

    def test_el_texto_plano_si_se_lee(self, tmp_path):
        # La contrapartida: rechazar lo ilegible no puede volverse rechazarlo
        # todo. Un índice vacío también deja el RAG mudo.
        idx = self._indexer()
        f = tmp_path / "nota.md"
        f.write_text("# Kupiec\nPrueba de cobertura incondicional.", encoding="utf-8")
        assert "Kupiec" in idx._leer_archivo(f)

    def test_la_raiz_del_indexador_es_el_proyecto(self):
        # El `.parent` de más era la causa de todo lo anterior. La cuenta de
        # niveles vive ahora en UN solo sitio, `config_rag.RAIZ_PROYECTO`, en vez
        # de repetirse en cada indexador de dominio.
        from pathlib import Path
        raiz = Path(__file__).resolve().parents[1]
        from src.rag.config_rag import RAIZ_PROYECTO
        assert RAIZ_PROYECTO == raiz, (
            f"src/rag calcula mal la raíz ({RAIZ_PROYECTO}): los lectores de "
            f"Mx_01 volverán a ser inalcanzables y todo PDF quedará sin indexar")
        assert (RAIZ_PROYECTO / "motor").is_dir()

        # Se inspecciona el AST, no el texto: los comentarios y docstrings de
        # estos ficheros EXPLICAN el bug y contienen el patrón literal.
        import ast
        for rel in ("config_rag.py", "indexador_lexico.py", "base_indexer.py",
                    "buscador_lexico.py"):
            fuente = raiz / "src" / "rag" / rel
            arbol = ast.parse(fuente.read_text(encoding="utf-8"))
            cadenas = []
            for n in ast.walk(arbol):
                if isinstance(n, ast.Attribute):
                    prof, cur = 0, n
                    while isinstance(cur, ast.Attribute) and cur.attr == "parent":
                        prof += 1
                        cur = cur.value
                    if prof:
                        cadenas.append(prof)
            assert not any(x >= 4 for x in cadenas), (
                f"vuelve un encadenamiento de {max(cadenas)} '.parent' en "
                f"src/rag/{rel}: eso sale del proyecto")

    def test_chunks_identicos_no_se_pisan_entre_si(self, tmp_path):
        # Reproduce la colisión: un documento con secciones de texto idéntico.
        # El índice léxico ya no usa el ID como clave primaria de un upsert —eso
        # era ChromaDB—, pero el invariante sigue importando: los chunks son la
        # unidad de trazabilidad del informe, y dos con el mismo ID hacen
        # imposible decir de cuál salió una cita.
        corpus = tmp_path / "corpus"
        corpus.mkdir()
        (corpus / "doc_con_repeticiones.md").write_text(
            ("CABECERA REPETIDA\n" + "x" * 400 + "\n") * 6, encoding="utf-8")

        idx = self._indexer(fuentes=[corpus])
        idx.ruta = tmp_path / "indice" / "test.pkl"
        indice = idx.construir(force=True)

        assert len(indice) > 1, "el escenario no genera varios chunks"
        ids = [c["id"] for c in indice.chunks]
        assert len(ids) == len(set(ids)), (
            "IDs duplicados pese a que el texto se repite: la trazabilidad de "
            "las citas del informe deja de ser posible")

    def test_el_id_incluye_fuente_y_posicion(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "src" / "rag"
               / "indexador_lexico.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
        assert 'f"{archivo.name}|{i}|{trozo}"' in vivas, (
            "el ID del chunk vuelve a derivarse solo del texto: dos chunks "
            "iguales dejarán de ser distinguibles en la traza del informe")

    def test_el_id_es_estable_entre_reindexaciones(self):
        # Debe ser único PERO determinista: al reindexar, upsert actualiza en
        # vez de duplicar. Un ID aleatorio haría crecer el índice sin control.
        import hashlib
        def _id(fuente, i, texto):
            return hashlib.sha256(f"{fuente}|{i}|{texto}".encode()).hexdigest()[:16]
        assert _id("a.pdf", 0, "hola") == _id("a.pdf", 0, "hola")
        assert _id("a.pdf", 0, "hola") != _id("a.pdf", 1, "hola")
        assert _id("a.pdf", 0, "hola") != _id("b.pdf", 0, "hola")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-29] El RAG no puede indexar la evidencia que evalúa
#
# Los cuatro indexadores leían de `inputs/documentacion/`, `inputs/papers/` y
# demás — que son la EVIDENCIA DEL MODELO BAJO VALIDACIÓN. Dos consecuencias:
#
#  1. RAZONAMIENTO CIRCULAR. Ante «¿el manual documenta el backtesting?», el RAG
#     recuperaba fragmentos DEL PROPIO MANUAL y los inyectaba en el prompt bajo
#     el epígrafe «Conocimiento recuperado». El modelo veía sus propias
#     afirmaciones presentadas como referencia autorizada que las confirma.
#
#  2. CONTAMINACIÓN ENTRE DOMINIOS. Los cuatro apuntaban a las mismas carpetas.
#     Medido tras poblarlos: LaR 1.548 chunks, VaR 1.538, conductuales 1.540 —
#     y los tres eran el MISMO manual de LaR. Consultando el índice de VaR sobre
#     backtesting FRTB, los tres primeros resultados eran del manual de LaR con
#     similitud 0.88, muy por encima del umbral de 0.35. Validar un modelo de
#     mercado le inyectaba el manual de uno de liquidez como conocimiento
#     experto de su dominio.
#
# El RAG es conocimiento de DOMINIO (FRTB, Kupiec, Basilea, SR 11-7): externo e
# independiente del modelo evaluado. Vive en `inputs/rag/<dominio>/`.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaRagNoIndexaLaEvidenciaQueEvalua:

    DOMINIOS = ("LaR", "VaR", "conductuales", "shared")

    def _indexers(self):
        from src.rag.LaR.indexer import LaRIndexer
        from src.rag.VaR.indexer import VaRIndexer
        from src.rag.conductuales.indexer import ConductualesIndexer
        from src.rag.shared.indexer import SharedIndexer
        return [LaRIndexer(), VaRIndexer(), ConductualesIndexer(), SharedIndexer()]

    def test_ningun_dominio_indexa_carpetas_de_evidencia(self):
        # Las seis carpetas que alimentan los ámbitos VIRF son evidencia del
        # modelo, no literatura de dominio.
        EVIDENCIA = {"modelamiento", "seguimiento", "papers", "calidad_datos",
                     "implementacion", "usos"}
        for idx in self._indexers():
            for p in idx.get_source_paths():
                partes = set(p.parts)
                assert "rag" in partes, (
                    f"[{idx.dominio}] indexa {p}, que no está bajo inputs/rag/")
                assert not (partes & EVIDENCIA), (
                    f"[{idx.dominio}] volvió a indexar una carpeta de evidencia "
                    f"({p}): el RAG recuperará el manual bajo evaluación y lo "
                    f"presentará como referencia que lo confirma")

    def test_cada_dominio_tiene_su_propia_carpeta(self):
        vistas = {}
        for idx in self._indexers():
            rutas = [str(p) for p in idx.get_source_paths()]
            for otro, suyas in vistas.items():
                assert not (set(rutas) & set(suyas)), (
                    f"'{idx.dominio}' y '{otro}' comparten fuente: sus índices "
                    f"acabarán con el mismo contenido y un modelo recibirá "
                    f"conocimiento de otro dominio")
            vistas[idx.dominio] = rutas

    def test_la_ruta_de_cada_dominio_coincide_con_su_nombre(self):
        for idx in self._indexers():
            p = idx.get_source_paths()[0]
            assert p.name == idx.dominio, (
                f"[{idx.dominio}] apunta a '{p.name}': un cruce de carpetas "
                f"metería literatura de un dominio en el índice de otro")

    def test_existe_la_estructura_documentada(self):
        from pathlib import Path
        raiz = Path(__file__).resolve().parents[1]
        for dom in self.DOMINIOS:
            carpeta = raiz / "inputs" / "rag" / dom
            assert carpeta.is_dir(), f"falta {carpeta}"
            readme = carpeta / "README.md"
            assert readme.exists(), (
                f"[{dom}] sin README: nadie sabrá qué documentos poner y la "
                f"carpeta acabará con evidencia del modelo")
            txt = readme.read_text(encoding="utf-8")
            assert "Qué NO va aquí" in txt, (
                f"[{dom}] el README no advierte contra mezclar la evidencia")

    def test_los_readme_no_se_indexan(self, tmp_path):
        # Explican qué va en la carpeta; no son conocimiento del dominio. Sin
        # excluirlos, una consulta podría recuperar «Qué NO va aquí: la
        # evidencia del modelo…» y presentarlo como referencia experta.
        #
        # [2026-07-31] Se comprueba el COMPORTAMIENTO, no la línea de código.
        # La versión anterior buscaba `archivo.stem.upper() in {"README"` en el
        # fuente de base_indexer.py: al mover el filtro a `config_rag` +
        # `IndexadorLexico._archivos()`, el test se rompió sin que la exclusión
        # hubiera dejado de funcionar. Un test acoplado a la forma del código
        # avisa de refactors, no de regresiones.
        from src.rag.indexador_lexico import IndexadorLexico

        corpus = tmp_path / "corpus"
        corpus.mkdir()
        (corpus / "README.md").write_text(
            "Qué NO va aquí: la evidencia del modelo que se está validando.",
            encoding="utf-8")
        (corpus / "kupiec.md").write_text(
            "La prueba de Kupiec contrasta la cobertura incondicional del VaR.",
            encoding="utf-8")

        idx = IndexadorLexico("test", fuentes=[corpus])
        idx.ruta = tmp_path / "indice" / "test.pkl"
        indice = idx.construir(force=True)

        fuentes = {c["fuente"] for c in indice.chunks}
        assert "README.md" not in fuentes, (
            "el README de la carpeta de dominio entró al índice: una consulta "
            "puede recuperarlo y presentarlo como referencia experta")
        assert "kupiec.md" in fuentes, (
            "excluir los README se llevó por delante la literatura de verdad")

    def test_un_dominio_sin_literatura_degrada_a_vacio(self):
        # Es el fallo CORRECTO: mejor sin contexto que con contexto ajeno.
        #
        # [FIX] La primera versión fijaba "conductuales" como dominio vacío.
        # Al poblar el corpus dejó de estarlo y el test falló: comprobaba un
        # ESTADO TRANSITORIO en vez del invariante. Ahora se usa un dominio
        # inexistente, que sí es vacío por construcción.
        # [FIX 2026-07-31] La versión anterior sobrescribía `_get_indexer()`
        # para que lanzara. Al pasar al RAG léxico ese método dejó de existir
        # —el retriever habla con `BuscadorLexico`, no con el indexador— así que
        # el override quedó MUERTO: el test seguía en verde, pero ya no simulaba
        # un índice ausente, sino que ejercitaba el camino real.
        #
        # Y ese camino tenía un defecto que este test destapó al dejar rastro:
        # autoconstruía un índice vacío y lo PERSISTÍA, dejando
        # `dominio_que_no_existe.pkl` en la carpeta de índices de producción.
        # Corregido en `IndexadorLexico.construir()`, que ya no escribe índices
        # sin chunks. Aquí se comprueba también eso.
        from src.rag.base_retriever import BaseRetriever
        from src.rag.indexador_lexico import ruta_indice

        class _SinIndice(BaseRetriever):
            dominio = "dominio_que_no_existe"

        r = _SinIndice()
        assert r.query("cualquier consulta", top_k=3) == [], (
            "un dominio sin índice debe devolver lista vacía, no propagar la "
            "excepción y tumbar la evaluación")
        assert r.query_para_prompt("cualquier consulta") == "", (
            "un índice vacío debe producir cadena vacía, no un bloque de "
            "contexto sin contenido")
        assert not ruta_indice("dominio_que_no_existe").exists(), (
            "consultar un dominio sin literatura ha escrito un índice vacío en "
            "la carpeta de índices: ensucia --status haciendo pasar por "
            "'indexado' un dominio en el que no hay nada que buscar")

    def test_los_dominios_poblados_recuperan_solo_lo_suyo(self):
        # La contrapartida del test anterior: con corpus, cada dominio debe
        # devolver SUS documentos. Es lo que fallaba cuando los cuatro
        # compartían fuente.
        import pytest
        from src.rag import get_retriever
        esperado = {
            "VaR":          ("FRTB", "backtesting_VaR"),
            "LaR":          ("LCR", "NSFR"),
            "conductuales": ("IRRBB",),
            "shared":       ("SR_11-7", "BCBS_239", "validacion_interna"),
        }
        for dom, prefijos in esperado.items():
            res = get_retriever(tipo_modelo=dom).query(
                "metodología, supuestos, backtesting y validación", top_k=5)
            if not res:
                pytest.skip(f"corpus de {dom} no generado")
            for c in res:
                assert any(c["fuente"].startswith(p) for p in prefijos), (
                    f"[{dom}] recuperó '{c['fuente']}', que no pertenece a este "
                    f"dominio: hay contaminación cruzada entre índices")

    def test_la_raiz_se_calcula_en_un_solo_sitio(self):
        # Los cuatro indexadores repetían `parent.parent.parent.parent`, una
        # cuenta de niveles que hay que acertar y que ya estaba mal en
        # base_indexer.py (apuntaba fuera del proyecto).
        import ast
        from pathlib import Path
        raiz = Path(__file__).resolve().parents[1]
        for dom in self.DOMINIOS:
            f = raiz / "src" / "rag" / dom / "indexer.py"
            arbol = ast.parse(f.read_text(encoding="utf-8"))
            for n in ast.walk(arbol):
                if isinstance(n, ast.Attribute):
                    prof, cur = 0, n
                    while isinstance(cur, ast.Attribute) and cur.attr == "parent":
                        prof += 1
                        cur = cur.value
                    assert prof < 3, (
                        f"[{dom}] vuelve a calcular la raíz por su cuenta con "
                        f"{prof} '.parent'; debe usar base_indexer.fuentes_rag()")

    def test_raiz_proyecto_apunta_al_proyecto(self):
        from pathlib import Path
        from src.rag.base_indexer import raiz_proyecto
        assert (raiz_proyecto() / "motor").is_dir()
        assert (raiz_proyecto() / "agente.py").exists()
        assert raiz_proyecto() == Path(__file__).resolve().parents[1]


# ══════════════════════════════════════════════════════════════════════════════
# [CORPUS RAG 2026-07-29] Los resúmenes de referencia deben declararse como tales
#
# El corpus de `inputs/rag/` lo generó `scripts/generar_corpus_rag.py` a partir
# de marcos regulatorios públicos: son RESÚMENES SECUNDARIOS, no los textos
# oficiales. Como sus fragmentos se inyectan en prompts de validación
# regulatoria, el aviso tiene que viajar DENTRO del contenido indexable: si el
# modelo recupera un fragmento, debe poder ver que no es fuente autorizada.
# ══════════════════════════════════════════════════════════════════════════════
class TestCorpusRagSeDeclaraComoResumenSecundario:

    def _corpus(self):
        from pathlib import Path
        return sorted((Path(__file__).resolve().parents[1] / "inputs" / "rag")
                      .rglob("*.pdf"))

    def test_el_generador_existe_y_declara_el_aviso(self):
        from pathlib import Path
        gen = Path(__file__).resolve().parents[1] / "scripts" / "generar_corpus_rag.py"
        assert gen.exists(), "el corpus debe ser reproducible, no artefactos sueltos"
        txt = gen.read_text(encoding="utf-8")
        assert "RESUMEN SECUNDARIO" in txt and "NO ES EL TEXTO OFICIAL" in txt
        assert "fuente" in txt, "cada documento debe citar su fuente primaria"

    def test_cada_pdf_lleva_el_aviso_en_su_texto_extraible(self):
        # No basta con pintarlo: tiene que estar en el texto que el indexador
        # extrae, o el aviso no llega nunca al prompt.
        import pytest
        pdfs = self._corpus()
        if not pdfs:
            pytest.skip("corpus no generado")
        try:
            from pdfminer.high_level import extract_text
        except ImportError:
            pytest.skip("pdfminer no instalado")
        sin_aviso = []
        for p in pdfs:
            texto = (extract_text(str(p)) or "").upper()
            if "RESUMEN SECUNDARIO" not in texto or "NO ES EL TEXTO OFICIAL" not in texto:
                sin_aviso.append(p.name)
        assert not sin_aviso, (
            f"PDF sin el aviso en su texto extraíble: {sin_aviso}. Sus fragmentos "
            f"se inyectarían en prompts de validación regulatoria como si fueran "
            f"fuente autorizada.")

    def test_cada_pdf_cita_su_fuente_primaria(self):
        import pytest
        pdfs = self._corpus()
        if not pdfs:
            pytest.skip("corpus no generado")
        try:
            from pdfminer.high_level import extract_text
        except ImportError:
            pytest.skip("pdfminer no instalado")
        sin_fuente = [p.name for p in pdfs
                      if "FUENTE PRIMARIA" not in (extract_text(str(p)) or "").upper()]
        assert not sin_fuente, (
            f"sin fuente primaria verificable: {sin_fuente}")

    def test_el_corpus_vive_separado_de_la_evidencia(self):
        from pathlib import Path
        raiz = Path(__file__).resolve().parents[1]
        for p in self._corpus():
            partes = set(p.relative_to(raiz).parts)
            assert "rag" in partes, f"{p.name} fuera de inputs/rag/"
            assert not (partes & {"documentacion", "usos", "implementacion"}), (
                f"{p.name} está en una carpeta de evidencia: se evaluaría como "
                f"documentación del modelo validado")


# ══════════════════════════════════════════════════════════════════════════════
# [CUMPLIMIENTO 2026-07-29] FUNCIÓN 1 — Cadena de custodia / trazabilidad
#
# Requisito regulatorio, no técnico. La pregunta del auditor es «¿cómo sé que
# este informe no se editó después de emitirse?». Sin cadena de hashes, la
# respuesta es «no lo sabes», y un informe no verificable no sustenta un
# dictamen ante el supervisor.
# ══════════════════════════════════════════════════════════════════════════════
class TestCumplimientoCadenaDeCustodia:

    def _informe(self, modelo="ModeloX", score=3.5, extra=None):
        d = {
            "modelo": modelo,
            "tier": "1",
            "fecha": "2026-07-29",
            "score_global": score,
            "scores_por_ambito": {"Metodología": score},
            "resultados_por_ambito": {"Metodología": [{"puntaje": 3}]},
            "agente": {"agente_version": "27.1", "n_documentos": 1},
        }
        if extra:
            d.update(extra)
        return d

    def _emitir(self, tmp_path, modelo, score, inputs=None):
        """Sella y escribe un informe, como hace agente.py."""
        import json
        from modulos.custodia import sellar
        salida = tmp_path / "2026-07-29"
        salida.mkdir(parents=True, exist_ok=True)
        datos = sellar(self._informe(modelo, score), tmp_path, modelo, inputs or {})
        ruta = salida / f"resultados_{modelo}_{score}.json"
        ruta.write_text(json.dumps(datos, ensure_ascii=False, indent=2),
                        encoding="utf-8")
        return ruta

    # ── 1.1 hash encadenado ──────────────────────────────────────────────────

    def test_el_hash_es_determinista_y_no_circular(self):
        from modulos.custodia import hash_contenido
        a = self._informe()
        b = dict(reversed(list(self._informe().items())))   # otro orden de claves
        assert hash_contenido(a) == hash_contenido(b), (
            "el hash depende del orden de inserción de las claves: dos procesos "
            "con los mismos datos darían hashes distintos y la verificación "
            "sería inútil")
        # Añadir el propio hash no debe cambiarlo (evita la referencia circular)
        h = hash_contenido(a)
        a["custodia"] = {"hash_este_informe": h, "hash_cadena": "x"}
        assert hash_contenido(a) == h

    def test_el_primer_informe_no_declara_anterior(self, tmp_path):
        import json
        r = self._emitir(tmp_path, "Solo", 3.0)
        cust = json.loads(r.read_text(encoding="utf-8"))["custodia"]
        assert cust["hash_informe_anterior"] is None
        assert cust["posicion_en_cadena"] == 1
        assert len(cust["hash_este_informe"]) == 64

    def test_cada_informe_se_encadena_al_anterior(self, tmp_path):
        import json
        r1 = self._emitir(tmp_path, "Cadena", 3.0)
        r2 = self._emitir(tmp_path, "Cadena", 4.0)
        c1 = json.loads(r1.read_text(encoding="utf-8"))["custodia"]
        c2 = json.loads(r2.read_text(encoding="utf-8"))["custodia"]
        assert c2["hash_informe_anterior"] == c1["hash_este_informe"]
        assert c2["posicion_en_cadena"] == 2

    def test_alterar_un_informe_historico_rompe_la_verificacion(self, tmp_path):
        """EL test que pide el encargo: la alteración debe ser detectable."""
        import json
        from modulos.custodia import verificar_cadena
        r1 = self._emitir(tmp_path, "Auditado", 3.0)
        self._emitir(tmp_path, "Auditado", 4.0)

        assert verificar_cadena(tmp_path, "Auditado")["integra"] is True

        # Un validador deshonesto mejora su score a posteriori.
        datos = json.loads(r1.read_text(encoding="utf-8"))
        datos["score_global"] = 5.0
        r1.write_text(json.dumps(datos, ensure_ascii=False, indent=2),
                      encoding="utf-8")

        res = verificar_cadena(tmp_path, "Auditado")
        assert res["integra"] is False, (
            "editar el score de un informe emitido NO se detectó: la cadena de "
            "custodia no cumple su función")
        assert res["primer_fallo"] == r1.name
        problemas = " ".join(res["eslabones"][0]["problemas"])
        assert "alterado" in problemas.lower()

    def test_borrar_un_informe_de_la_secuencia_se_detecta(self, tmp_path):
        from modulos.custodia import verificar_cadena
        self._emitir(tmp_path, "Secuencia", 3.0)
        r2 = self._emitir(tmp_path, "Secuencia", 4.0)
        self._emitir(tmp_path, "Secuencia", 5.0)
        r2.unlink()
        res = verificar_cadena(tmp_path, "Secuencia")
        assert res["integra"] is False, (
            "borrar un informe intermedio no rompió la cadena: se podría "
            "eliminar un dictamen desfavorable sin dejar rastro")

    # ── 1.2 timestamp no manipulable ─────────────────────────────────────────

    def test_alterar_el_timestamp_rompe_el_sello(self, tmp_path):
        import json
        from modulos.custodia import verificar_cadena
        r = self._emitir(tmp_path, "Reloj", 3.0)
        datos = json.loads(r.read_text(encoding="utf-8"))
        datos["custodia"]["generado_utc"] = "2020-01-01T00:00:00Z"
        # Se recalcula el hash de contenido para que SOLO falle el timestamp:
        # así se comprueba que el sello lo cubre de forma independiente.
        from modulos.custodia import hash_contenido
        datos["custodia"]["hash_este_informe"] = hash_contenido(datos)
        r.write_text(json.dumps(datos, ensure_ascii=False, indent=2),
                     encoding="utf-8")
        res = verificar_cadena(tmp_path, "Reloj")
        assert res["integra"] is False, (
            "cambiar la fecha de generación no rompió la verificación: se podría "
            "antedatar un informe")
        assert any("timestamp" in p.lower()
                   for e in res["eslabones"] for p in e["problemas"])

    def test_el_timestamp_es_de_generacion_no_del_sistema_de_ficheros(self, tmp_path):
        import json
        import os
        import time
        r = self._emitir(tmp_path, "Mtime", 3.0)
        ts_interno = json.loads(r.read_text(encoding="utf-8"))["custodia"]["generado_utc"]
        # Copiar o mover un fichero cambia su mtime; el sello no debe depender de él.
        os.utime(r, (time.time() - 86400, time.time() - 86400))
        from modulos.custodia import verificar_cadena
        assert verificar_cadena(tmp_path, "Mtime")["integra"] is True
        assert json.loads(r.read_text(encoding="utf-8"))["custodia"]["generado_utc"] == ts_interno

    # ── 1.3 vínculo evidencia → puntaje ──────────────────────────────────────

    def test_congela_el_hash_de_cada_documento_citado(self, tmp_path):
        import json
        from modulos.custodia import hash_archivo
        doc = tmp_path / "manual.md"
        doc.write_text("# Manual v1\nBacktesting de Kupiec.", encoding="utf-8")
        inputs = {"doc_modelamiento": [{
            "nombre": "manual.md", "contenido": doc.read_text(encoding="utf-8"),
            "ruta": str(doc), "sha256_archivo": hash_archivo(doc),
            "cobertura_pct": 100.0,
        }]}
        r = self._emitir(tmp_path, "Congelado", 3.0, inputs)
        v = json.loads(r.read_text(encoding="utf-8"))["custodia"]["version_evidencia_usada"]
        entrada = v["doc_modelamiento/manual.md"]
        assert entrada["sha256_archivo"] == hash_archivo(doc)
        assert len(entrada["sha256_texto"]) == 64
        assert entrada["ruta"] == str(doc)

    def test_detecta_que_el_documento_fuente_cambio(self, tmp_path):
        from modulos.custodia import hash_archivo, verificar_evidencia
        doc = tmp_path / "manual.md"
        doc.write_text("# Manual v1", encoding="utf-8")
        inputs = {"doc_modelamiento": [{
            "nombre": "manual.md", "contenido": "# Manual v1",
            "ruta": str(doc), "sha256_archivo": hash_archivo(doc),
        }]}
        r = self._emitir(tmp_path, "Version", 3.0, inputs)
        assert verificar_evidencia(r)["todos_intactos"] is True

        # Nueva versión del manual DESPUÉS de emitir el informe.
        doc.write_text("# Manual v2 — metodología revisada", encoding="utf-8")
        res = verificar_evidencia(r)
        assert res["todos_intactos"] is False
        assert res["documentos"][0]["estado"] == "MODIFICADO", (
            "no se detectó que el manual citado cambió; el informe ya no puede "
            "demostrar sobre qué versión se emitió")

    def test_detecta_que_el_documento_fuente_desaparecio(self, tmp_path):
        from modulos.custodia import hash_archivo, verificar_evidencia
        doc = tmp_path / "manual.md"
        doc.write_text("# Manual", encoding="utf-8")
        inputs = {"doc_modelamiento": [{
            "nombre": "manual.md", "contenido": "# Manual",
            "ruta": str(doc), "sha256_archivo": hash_archivo(doc),
        }]}
        r = self._emitir(tmp_path, "Ausente", 3.0, inputs)
        doc.unlink()
        res = verificar_evidencia(r)
        assert res["documentos"][0]["estado"] == "AUSENTE"


# ══════════════════════════════════════════════════════════════════════════════
# [CUMPLIMIENTO 2026-07-29] FUNCIÓN 2 — Firma del validador humano
#
# «¿Quién firmó esto?» Un informe sin responsable humano identificable no
# acredita validación independiente: acredita que se ejecutó un programa.
# ══════════════════════════════════════════════════════════════════════════════
class TestCumplimientoFirmaValidador:

    def _aislar_registro(self, tmp_path, monkeypatch):
        """Redirige el registro a tmp para no contaminar el del proyecto."""
        import modulos.validador_humano as vh
        monkeypatch.setattr(vh, "REGISTRO_PATH", tmp_path / "registro.json")
        return vh

    # ── 2.1 identificación obligatoria ───────────────────────────────────────

    def test_prdc_sin_validador_falla_con_mensaje_claro(self, monkeypatch):
        """EL test que pide el encargo."""
        import pytest
        from modulos.validador_humano import solicitar_identidad, IdentidadRequerida
        monkeypatch.delenv("VIRF_VALIDADOR", raising=False)
        monkeypatch.delenv("VIRF_VALIDADOR_CARGO", raising=False)
        with pytest.raises(IdentidadRequerida) as exc:
            solicitar_identidad(interactivo=False)
        mensaje = str(exc.value)
        # El mensaje tiene que ser accionable: qué falta, por qué y cómo darlo.
        assert "--validador" in mensaje and "--cargo" in mensaje
        assert "VIRF_VALIDADOR" in mensaje
        assert "SR 11-7" in mensaje

    def test_falla_tambien_si_falta_solo_el_cargo(self, monkeypatch):
        import pytest
        from modulos.validador_humano import solicitar_identidad, IdentidadRequerida
        monkeypatch.delenv("VIRF_VALIDADOR_CARGO", raising=False)
        with pytest.raises(IdentidadRequerida):
            solicitar_identidad(nombre="Ana Pérez", interactivo=False)

    def test_acepta_identidad_por_flag_y_por_entorno(self, monkeypatch):
        from modulos.validador_humano import solicitar_identidad
        i = solicitar_identidad("Ana Pérez", "Validador de Segunda Línea",
                                interactivo=False)
        assert i["validador"] == "Ana Pérez"
        assert i["cargo"] == "Validador de Segunda Línea"
        assert i["fecha_aprobacion"].endswith("Z")

        monkeypatch.setenv("VIRF_VALIDADOR", "Luis Gómez")
        monkeypatch.setenv("VIRF_VALIDADOR_CARGO", "Jefe de Validación")
        i2 = solicitar_identidad(interactivo=False)
        assert i2["validador"] == "Luis Gómez"

    def test_el_agente_exige_la_firma_antes_de_gastar(self):
        # El orden importa: descubrir que falta la firma después de pagar la
        # corrida obliga a repetirla.
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        pos_firma = src.index("solicitar_identidad(args.validador")
        pos_eval = src.index("evaluar_ambito_completo(")
        assert pos_firma < pos_eval, (
            "la identidad se pide después de empezar a evaluar: el fallo llegaría "
            "con la corrida ya pagada")

    # ── 2.2 registro multi-validador ─────────────────────────────────────────

    def test_el_registro_acumula_quien_valido_que_y_cuando(self, tmp_path, monkeypatch):
        vh = self._aislar_registro(tmp_path, monkeypatch)
        vh.registrar_validacion("Modelo A", {"validador": "Ana", "cargo": "2LoD",
                                             "fecha_aprobacion": "2026-07-01T10:00:00Z"})
        vh.registrar_validacion("Modelo B", {"validador": "Ana", "cargo": "2LoD",
                                             "fecha_aprobacion": "2026-07-02T10:00:00Z"})
        vh.registrar_validacion("Modelo A", {"validador": "Luis", "cargo": "Jefe",
                                             "fecha_aprobacion": "2026-07-03T10:00:00Z"})
        h = vh.historial_por_validador()
        assert set(h) == {"Ana", "Luis"}
        assert h["Ana"]["n_aprobaciones"] == 2
        assert len(h["Ana"]["modelos"]) == 2
        assert h["Ana"]["primera"] < h["Ana"]["ultima"]

    def test_el_registro_sobrevive_a_escrituras_concurrentes(self, tmp_path, monkeypatch):
        # Mismo escenario que ya destruyó el historial de feedback: varios
        # validadores del equipo sobre el mismo repositorio.
        vh = self._aislar_registro(tmp_path, monkeypatch)
        for i in range(20):
            vh.registrar_validacion(f"Modelo {i%3}", {
                "validador": f"V{i%4}", "cargo": "2LoD",
                "fecha_aprobacion": f"2026-07-{i+1:02d}T10:00:00Z"})
        assert sum(d["n_aprobaciones"] for d in vh.historial_por_validador().values()) == 20

    # ── 2.3 auto-aprobación ──────────────────────────────────────────────────

    def test_advierte_tras_tres_firmas_consecutivas_del_mismo_validador(
            self, tmp_path, monkeypatch):
        vh = self._aislar_registro(tmp_path, monkeypatch)
        for i in range(2):
            vh.registrar_validacion("Modelo Solo", {
                "validador": "Ana", "cargo": "2LoD",
                "fecha_aprobacion": f"2026-07-0{i+1}T10:00:00Z"})
        # La firma en curso es la tercera → debe avisar.
        aviso = vh.aviso_segunda_revision("Modelo Solo", "Ana")
        assert aviso and "Sin segunda revisión" in aviso
        assert "Ana" in aviso

    def test_un_segundo_validador_reinicia_el_contador(self, tmp_path, monkeypatch):
        vh = self._aislar_registro(tmp_path, monkeypatch)
        for i in range(3):
            vh.registrar_validacion("Rotado", {"validador": "Ana", "cargo": "2LoD",
                                               "fecha_aprobacion": f"2026-07-0{i+1}T10:00:00Z"})
        vh.registrar_validacion("Rotado", {"validador": "Luis", "cargo": "Jefe",
                                           "fecha_aprobacion": "2026-07-04T10:00:00Z"})
        assert vh.firmas_consecutivas("Rotado", "Ana") == 0, (
            "la intervención de un segundo validador no reinició el contador: "
            "la rotación efectiva no se reconocería")
        assert vh.aviso_segunda_revision("Rotado", "Ana") is None

    def test_el_aviso_no_bloquea_la_emision(self, tmp_path, monkeypatch):
        # Decisión de diseño explícita: en un equipo de dos personas la rotación
        # puede ser imposible y bloquear impediría trabajar. El aviso queda en
        # el informe para que el auditor lo valore.
        vh = self._aislar_registro(tmp_path, monkeypatch)
        for i in range(5):
            vh.registrar_validacion("Bloqueo", {"validador": "Ana", "cargo": "2LoD",
                                                "fecha_aprobacion": f"2026-07-0{i+1}T10:00:00Z"})
        assert vh.aviso_segunda_revision("Bloqueo", "Ana") is not None
        # No hay excepción ni exit: solo texto.
        assert isinstance(vh.aviso_segunda_revision("Bloqueo", "Ana"), str)


# ══════════════════════════════════════════════════════════════════════════════
# [CUMPLIMIENTO 2026-07-29] FUNCIÓN 3 — Anexo de human override
#
# Es la evidencia que un auditor busca para confirmar que el sistema no es una
# caja negra: dónde el criterio humano corrigió al agente, y por qué.
# ══════════════════════════════════════════════════════════════════════════════
class TestCumplimientoAnexoOverride:

    HIST = [
        {"fecha": "01/07/2026 10:00", "titulo_modelo": "MiModelo",
         "ambito": "Metodología", "actividad": "Validar supuestos",
         "puntaje_agente": 4, "puntaje_correcto": 2, "diferencia": -2,
         "comentario": "Sin p-valores verificables."},
        {"fecha": "01/07/2026 10:05", "titulo_modelo": "MiModelo",
         "ambito": "Gobierno", "actividad": "Inventario",
         "puntaje_agente": 2, "puntaje_correcto": 4, "diferencia": 2,
         "comentario": "Inventariado en el GRC corporativo."},
        {"fecha": "01/06/2026 09:00", "titulo_modelo": "MiModelo",
         "ambito": "Documentación", "actividad": "Versionado",
         "puntaje_agente": 3, "puntaje_correcto": 4, "diferencia": 1,
         "comentario": "Ciclo anterior."},
        {"fecha": "01/07/2026 11:00", "titulo_modelo": "OtroModelo",
         "ambito": "Metodología", "actividad": "X",
         "puntaje_agente": 1, "puntaje_correcto": 5, "diferencia": 4,
         "comentario": "De otro modelo."},
    ]

    def test_el_anexo_se_genera_con_correcciones(self):
        """EL test que pide el encargo (caso con correcciones)."""
        from modulos.override_humano import resumen_override
        r = resumen_override("MiModelo", 15, self.HIST)
        assert r["hubo_correcciones"] is True
        assert r["n_correcciones"] == 2, "debe tomar solo el último ciclo"
        assert r["n_correcciones_historicas"] == 3, "y declarar el acumulado"
        assert r["pct_ajustados"] == round(2 / 15 * 100, 1)
        assert r["ajustes_al_alza"] == 1 and r["ajustes_a_la_baja"] == 1
        # No debe mezclar modelos.
        assert all("Otro" not in c["actividad"] for c in r["correcciones"])
        # Cada corrección lleva su justificación: es lo que lee el auditor.
        assert all(c["justificacion"] for c in r["correcciones"])

    def test_el_anexo_declara_explicitamente_la_ausencia_de_correcciones(self):
        """EL test que pide el encargo (caso sin correcciones)."""
        from modulos.override_humano import resumen_override, linea_independencia
        r = resumen_override("ModeloSinRevision", 12, self.HIST)
        assert r["hubo_correcciones"] is False
        assert r["n_correcciones"] == 0
        assert r["pct_ajustados"] == 0.0
        assert "totalidad" in linea_independencia(r), (
            "la ausencia de correcciones debe declararse explícitamente: dejarla "
            "en silencio obliga al auditor a deducir si hubo revisión")

    def test_el_porcentaje_nunca_supera_el_cien(self):
        # Un validador puede corregir la misma actividad dos veces en la sesión.
        # Un «112 % de ajustes» en un informe regulatorio destruiría la
        # credibilidad del resto del documento.
        from modulos.override_humano import resumen_override
        hist = [dict(self.HIST[0], actividad=f"A{i}") for i in range(20)]
        r = resumen_override("MiModelo", 5, hist)
        assert r["pct_ajustados"] <= 100.0

    def test_sin_actividades_no_divide_por_cero(self):
        from modulos.override_humano import resumen_override
        r = resumen_override("MiModelo", 0, self.HIST)
        assert r["pct_ajustados"] == 0.0

    def test_la_linea_de_independencia_cuantifica_la_supervision(self):
        from modulos.override_humano import resumen_override, linea_independencia
        linea = linea_independencia(resumen_override("MiModelo", 15, self.HIST))
        assert "%" in linea and "validador" in linea.lower()
        assert "al alza" in linea and "a la baja" in linea

    def test_el_word_recibe_y_pinta_los_tres_bloques(self, tmp_path):
        import pytest
        try:
            from docx import Document
        except ImportError:
            pytest.skip("python-docx no instalado")
        from modulos.generador_word import generar_word_informe
        from modulos.override_humano import resumen_override

        ruta = generar_word_informe(
            resumen_ejecutivo="Resumen de prueba.",
            evaluaciones_por_ambito={"Metodología": [
                {"actividad": "Validar supuestos", "puntaje": 3,
                 "concepto": "c", "observacion": "o", "recomendacion": "r"}]},
            scores_por_ambito={"Metodología": 3.0},
            score_global=3.0,
            titulo_modelo="MiModelo", tier="1", outputs_dir=tmp_path,
            validacion_humana={"validador": "Ana Pérez", "cargo": "2LoD",
                               "fecha_aprobacion": "2026-07-29T10:00:00Z"},
            custodia={"generado_utc": "2026-07-29T10:00:00Z",
                      "hash_este_informe": "a" * 64,
                      "hash_informe_anterior": "b" * 64,
                      "hash_cadena": "c" * 64, "posicion_en_cadena": 2,
                      "version_evidencia_usada": {
                          "doc/manual.md": {"sha256_archivo": "d" * 64, "chars": 100}}},
            agente_meta={"agente_version": "27.1", "modelo_ia": "haiku",
                         "n_documentos": 1, "huella_completa": "e" * 64},
            override=resumen_override("MiModelo", 15, self.HIST),
        )
        doc = Document(str(ruta))
        texto = "\n".join(p.text for p in doc.paragraphs)
        for t in doc.tables:
            for row in t.rows:
                for c in row.cells:
                    texto += "\n" + c.text

        # Función 2: firma visible
        assert "Ana Pérez" in texto and "2LoD" in texto
        assert "APROBACIÓN Y RESPONSABILIDAD" in texto.upper()
        # Función 1: metadatos de custodia verificables desde el propio Word
        assert "CADENA DE CUSTODIA" in texto.upper()
        assert "a" * 32 in texto, "el hash del informe no llegó al documento"
        assert "--verificar-cadena" in texto, "falta cómo verificarlo"
        # Función 3: anexo y métrica
        assert "CORRECCIONES DEL VALIDADOR" in texto.upper()
        assert "Sin p-valores verificables." in texto, "falta la justificación"
        assert "% de puntajes ajustados por el validador" in texto

    def test_el_word_declara_la_falta_de_firma_en_vez_de_ocultarla(self, tmp_path):
        # Un informe sin firmante debe PARECER incompleto. Omitir la sección lo
        # haría parecer completo, que es el fallo peligroso.
        import pytest
        try:
            from docx import Document
        except ImportError:
            pytest.skip("python-docx no instalado")
        from modulos.generador_word import generar_word_informe
        ruta = generar_word_informe(
            resumen_ejecutivo="R.", evaluaciones_por_ambito={"Metodología": []},
            scores_por_ambito={"Metodología": 3.0}, score_global=3.0,
            titulo_modelo="SinFirma", tier="1", outputs_dir=tmp_path,
        )
        texto = "\n".join(p.text for p in Document(str(ruta)).paragraphs)
        assert "SIN FIRMA DE VALIDADOR" in texto.upper()

    def test_la_senal_interna_no_va_al_informe_del_regulador(self):
        # 3.2: el % de ajustes de un validador es métrica de gestión interna.
        # En el informe entregable sería una acusación implícita a quien firma.
        from pathlib import Path
        from modulos.override_humano import calidad_proceso
        d = calidad_proceso("Ana", historial=[], registro_validador=[
            {"validador": "Ana", "modelo": "M1"},
            {"validador": "Ana", "modelo": "M1"},
            {"validador": "Ana", "modelo": "M1"}])
        assert d["señales"], "no detectó 3 aprobaciones sin ninguna corrección"
        assert "INTERNO" in d["uso"]
        # Y no debe pintarse en el Word.
        gw = (Path(__file__).resolve().parents[1] / "modulos"
              / "generador_word.py").read_text(encoding="utf-8")
        assert "calidad_proceso" not in gw, (
            "la señal interna de calidad se está inyectando en el informe que "
            "se entrega al regulador")


# ══════════════════════════════════════════════════════════════════════════════
# [CUSTODIA-FIX 2026-07-29] El hash del fichero debe llegar por AMBAS ramas
#
# `leer_archivo()` tiene dos caminos —lectura fresca y servido del caché— y solo
# el primero rellenaba `sha256_archivo`. Como el caché está activo por defecto,
# el caso NORMAL era el segundo: la mayoría de informes salían con
# `version_evidencia_usada.sha256_archivo = None` y `--verificar-evidencia` los
# reportaba como NO VERIFICABLES. La cadena de custodia existía pero no servía.
#
# Es el mismo patrón que el TRUNCADO-FIX aplicado a medias: una corrección que
# cubre la lectura directa y olvida la del caché, que es la que se usa siempre.
# ══════════════════════════════════════════════════════════════════════════════
class TestCustodiaHashDelFicheroPorAmbasRamas:

    def test_lectura_fresca_y_cacheada_dan_el_mismo_hash(self, tmp_path, monkeypatch):
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        from modulos.document_cache import DocumentCache
        import modulos.document_cache as dc
        import Mx_01_LecturaEvidencias as mx

        doc = tmp_path / "manual.md"
        doc.write_text("# Manual metodológico\nBacktesting de Kupiec.", encoding="utf-8")

        previa = dc._instancia_global
        try:
            dc._instancia_global = DocumentCache(cache_dir=tmp_path / "c", enabled=True)
            d1 = mx.leer_archivo(doc)          # fresca → puebla
            d2 = mx.leer_archivo(doc)          # servida del caché
        finally:
            dc._instancia_global = previa

        assert d1 and d2
        assert d1.get("sha256_archivo"), "la lectura fresca no aporta el hash"
        assert d2.get("sha256_archivo"), (
            "la lectura SERVIDA DEL CACHÉ no aporta el hash del fichero: como el "
            "caché está activo por defecto, la mayoría de informes quedarían con "
            "la evidencia NO VERIFICABLE")
        assert d1["sha256_archivo"] == d2["sha256_archivo"]
        assert d1.get("ruta") == d2.get("ruta") == str(doc.resolve())

    def test_ambas_ramas_rellenan_los_campos_de_custodia(self):
        # Guarda la clase de fallo: cualquier `return` de leer_archivo debe
        # entregar los dos campos que la custodia necesita.
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "motor"
               / "Mx_01_LecturaEvidencias.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
        assert 'cached["sha256_archivo"]' in vivas, (
            "la rama del caché volvió a olvidar el hash del fichero")
        assert 'cached["ruta"]' in vivas
        assert '"sha256_archivo": DocumentCache._hash_archivo(path)' in vivas, (
            "la rama de lectura fresca ya no aporta el hash del fichero")

    def test_la_evidencia_de_un_informe_real_es_verificable(self):
        # Sobre el informe realmente emitido: si sha256_archivo viene vacío,
        # --verificar-evidencia no puede hacer su trabajo.
        import json
        import pytest
        from pathlib import Path
        salidas = Path(__file__).resolve().parents[1] / "outputs"
        candidatos = sorted(salidas.rglob("resultados_*.json"),
                            key=lambda f: f.stat().st_mtime, reverse=True)
        con_custodia = None
        for f in candidatos:
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            if (d.get("custodia") or {}).get("version_evidencia_usada"):
                con_custodia = d
                break
        if not con_custodia:
            pytest.skip("sin informes sellados en outputs/")
        ve = con_custodia["custodia"]["version_evidencia_usada"]
        sin_hash = [k for k, v in ve.items() if not v.get("sha256_archivo")]
        assert not sin_hash, (
            f"{len(sin_hash)} de {len(ve)} documentos sin hash de fichero: su "
            f"versión no se puede verificar a posteriori. Ejemplo: {sin_hash[:2]}")


# ══════════════════════════════════════════════════════════════════════════════
# [AUDITORÍA 2026-07-29] Un solo lector y un solo escritor del historial
#
# `feedback_mejorado.py` tenía SU PROPIA copia de `cargar_historial()` y de la
# escritura, con su propio FEEDBACK_PATH. No eran equivalentes a las de
# `feedback.py`: les faltaban los tres arreglos que este sí recibió.
#
#   lectura  → devolvía [] EN SILENCIO ante un JSON corrupto, en vez de
#              respaldarlo y avisar. Y de esa copia comen
#              `analizar_patron_errores()` y `ajustar_puntaje_por_feedback()`,
#              las funciones que MODIFICAN puntajes: un historial corrupto
#              desactivaba el ajuste anti-sesgo sin un solo aviso.
#   escritura→ `open(FEEDBACK_PATH, "w")` sin lock, sin escritura atómica y sin
#              fusión. El "w" truncaba el fichero de inmediato, de modo que esta
#              ruta podía destruir las correcciones registradas por otros
#              validadores del equipo.
#
# Es la tercera vez en esta auditoría que aparece el mismo patrón: un arreglo
# aplicado a una copia y no a la otra. Por eso el test no comprueba el
# comportamiento, comprueba que NO EXISTAN las copias.
# ══════════════════════════════════════════════════════════════════════════════
class TestAuditoriaUnSoloAccesoAlHistorial:

    def _fuente(self):
        from pathlib import Path
        return (Path(__file__).resolve().parents[1] / "modulos"
                / "feedback_mejorado.py").read_text(encoding="utf-8")

    def test_no_hay_segunda_ruta_al_fichero_de_historial(self):
        vivas = "\n".join(l for l in self._fuente().splitlines()
                          if not l.lstrip().startswith("#"))
        assert "FEEDBACK_PATH =" not in vivas, (
            "feedback_mejorado vuelve a declarar su propia ruta al historial: "
            "las dos copias divergirán en el próximo arreglo")
        assert 'open(FEEDBACK_PATH, "w"' not in vivas, (
            "vuelve la escritura sin lock ni atomicidad: puede truncar el "
            "historial y destruir las correcciones de otros validadores")

    def test_ambos_modulos_leen_el_mismo_historial(self, tmp_path, monkeypatch):
        import json
        import modulos.feedback as fb
        import modulos.feedback_mejorado as fm
        destino = tmp_path / "hist.json"
        destino.write_text(json.dumps([
            {"titulo_modelo": "M", "ambito": "A", "actividad": "x",
             "puntaje_agente": 3, "puntaje_correcto": 4, "diferencia": 1,
             "fecha": "01/07/2026 10:00"}]), encoding="utf-8")
        monkeypatch.setattr(fb, "FEEDBACK_PATH", destino)
        assert fm.cargar_historial() == fb.cargar_historial(), (
            "los dos módulos leen ficheros distintos: el ajuste anti-sesgo "
            "operaría sobre un historial que nadie más ve")
        assert len(fm.cargar_historial()) == 1

    def test_la_lectura_hereda_la_proteccion_ante_corrupcion(self, tmp_path,
                                                             monkeypatch, capsys):
        # La copia sin arreglar devolvía [] en silencio; la buena respalda y avisa.
        import modulos.feedback as fb
        import modulos.feedback_mejorado as fm
        roto = tmp_path / "hist.json"
        roto.write_text("{ esto no es JSON válido", encoding="utf-8")
        monkeypatch.setattr(fb, "FEEDBACK_PATH", roto)
        assert fm.cargar_historial() == []
        salida = capsys.readouterr().out
        assert "ilegible" in salida.lower() or "corrupto" in salida.lower(), (
            "un historial corrupto se lee como vacío SIN avisar: el ajuste "
            "anti-sesgo se desactiva y nadie se entera")
        assert list(tmp_path.glob("*corrupto*")), "no se respaldó el fichero dañado"


# ══════════════════════════════════════════════════════════════════════════════
# [CUSTODIA 2026-07-30] La cadena sobrevive a varias corridas el mismo día
#
# Dos defectos que solo aparecieron al ejercitar la cadena de verdad:
#
#  a) El informe se llama `resultados_<modelo>_<fecha>.json`, con granularidad
#     de DÍA. Dos corridas del mismo modelo la misma fecha escribían el mismo
#     fichero y la segunda BORRABA el eslabón anterior. Un validador que
#     repitiera la corrida buscando un score más favorable eliminaba la
#     evidencia de la anterior.
#
#  b) El orden de la cadena se tomaba del `generado_utc` interno, que tiene
#     precisión de SEGUNDOS. Tres corridas seguidas caían en el mismo segundo y
#     el orden quedaba a merced de rglob(): los tres eslabones se reportaban
#     ROTOS por estar mal ordenados, no por estar alterados. Un falso positivo
#     así destruye la confianza en el control.
#
# El orden se deriva ahora de los ENLACES, que es para lo que existe una cadena
# de hashes: inmune a colisiones de reloj y a la manipulación del timestamp.
# ══════════════════════════════════════════════════════════════════════════════
class TestCustodiaVariasCorridasElMismoDia:

    def _emitir(self, tmp_path, score):
        """Emite un informe como agente.py: preserva el previo y sella."""
        import json
        from modulos.custodia import sellar, preservar_si_existe
        salida = tmp_path / "2026-07-30"
        salida.mkdir(parents=True, exist_ok=True)
        destino = salida / "resultados_M_2026-07-30.json"
        preservar_si_existe(destino)
        datos = sellar({"modelo": "M", "score_global": score}, tmp_path, "M", {})
        destino.write_text(json.dumps(datos, ensure_ascii=False, indent=2),
                           encoding="utf-8")
        return destino

    def test_una_segunda_corrida_no_borra_el_eslabon_anterior(self, tmp_path):
        self._emitir(tmp_path, 2.0)
        self._emitir(tmp_path, 3.0)
        ficheros = list((tmp_path / "2026-07-30").glob("*.json"))
        assert len(ficheros) == 2, (
            "la segunda corrida sobrescribió la primera: el eslabón anterior de "
            "la cadena se perdió y con él la evidencia del dictamen previo")

    def test_tres_corridas_en_el_mismo_segundo_mantienen_la_cadena(self, tmp_path):
        from modulos.custodia import verificar_cadena
        for s in (2.0, 3.0, 4.0):
            self._emitir(tmp_path, s)
        res = verificar_cadena(tmp_path, "M")
        assert res["n_informes"] == 3
        assert res["integra"] is True, (
            f"cadena reportada como rota sin que nadie la alterara: "
            f"{[e['problemas'] for e in res['eslabones']]}")

    def test_el_orden_se_deriva_de_los_enlaces_no_de_la_fecha(self, tmp_path):
        import json
        from modulos.custodia import verificar_cadena
        for s in (2.0, 3.0, 4.0):
            self._emitir(tmp_path, s)
        res = verificar_cadena(tmp_path, "M")
        scores = []
        for e in res["eslabones"]:
            f = next((tmp_path / "2026-07-30").glob(e["archivo"]))
            scores.append(json.loads(f.read_text(encoding="utf-8"))["score_global"])
        assert scores == [2.0, 3.0, 4.0], (
            f"el orden de la cadena no sigue los enlaces: {scores}. Con sellos "
            f"del mismo segundo, ordenar por fecha da un orden arbitrario.")

    def test_alterar_un_eslabon_intermedio_se_detecta_en_su_posicion(self, tmp_path):
        import json
        from modulos.custodia import verificar_cadena
        for s in (2.0, 3.0, 4.0):
            self._emitir(tmp_path, s)
        res = verificar_cadena(tmp_path, "M")
        objetivo = next((tmp_path / "2026-07-30").glob(res["eslabones"][1]["archivo"]))
        d = json.loads(objetivo.read_text(encoding="utf-8"))
        d["score_global"] = 9.9
        objetivo.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                            encoding="utf-8")
        res2 = verificar_cadena(tmp_path, "M")
        assert res2["integra"] is False
        assert res2["primer_fallo"] == objetivo.name
        assert res2["eslabones"][0]["estado"] == "OK", "el eslabón previo no se ve afectado"
        assert res2["eslabones"][1]["estado"] == "ROTO"
        # El siguiente también, porque su enlace ya no cuadra: así se localiza
        # exactamente dónde se rompió.
        assert res2["eslabones"][2]["estado"] == "ROTO"

    def test_un_informe_sin_sellar_no_se_preserva_como_eslabon(self, tmp_path):
        import json
        from modulos.custodia import preservar_si_existe
        salida = tmp_path / "2026-07-30"
        salida.mkdir(parents=True)
        f = salida / "resultados_M_2026-07-30.json"
        f.write_text(json.dumps({"modelo": "M"}), encoding="utf-8")
        assert preservar_si_existe(f) is None, (
            "un informe previo a la custodia no es un eslabón; archivarlo "
            "ensuciaría outputs/ sin aportar verificabilidad")


# ══════════════════════════════════════════════════════════════════════════════
# [TRAZA-ESTÁNDAR 2026-07-30] El informe declara qué VARA DE MEDIR aplicó
#
# El estándar es un documento vivo: la entidad lo revisa y crece. Dos informes
# del mismo modelo con scores distintos pueden deberse a que el modelo cambió…
# o a que cambió el criterio. Sin registrar la versión del estándar en el
# informe, esa diferencia es INDISTINGUIBLE — y un auditor que compare dos
# trimestres no puede saber cuál de las dos cosas ocurrió.
#
# Esto sustituye al test que congelaba los conteos por tier ({1:15, 2:12…}).
# Aquel se rompía en cada revisión legítima del estándar y el arreglo evidente
# era actualizar el número, con lo que la protección se evaporaba justo el día
# en que el criterio de validación cambiaba de verdad. La trazabilidad
# pertenece al informe, no a la suite de tests.
# ══════════════════════════════════════════════════════════════════════════════
class TestElInformeDeclaraLaVersionDelEstandar:

    def test_el_agente_calcula_la_huella_del_estandar(self):
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py").read_text(encoding="utf-8")
        vivo = "\n".join(l for l in src.splitlines() if not l.lstrip().startswith("#"))
        assert "_huella_estandar" in vivo, (
            "el informe dejó de registrar qué versión del estándar aplicó: dos "
            "informes con scores distintos ya no serían comparables")
        assert '"estandar":       _estandar_huella,' in vivo, (
            "la huella del estándar no entra en la huella de ejecución, así que "
            "cambiar el estándar NO cambiaría la huella y la corrida parecería "
            "idéntica a una anterior")

    def test_la_huella_incluye_hash_y_conteos(self):
        # Se comprueba sobre el estándar REAL, sin fijar sus cifras.
        import hashlib
        from pathlib import Path
        from config import ESTANDARES_PATH
        from modulos.motor_ia import leer_estandares_virf

        assert ESTANDARES_PATH.exists(), "no hay estándar que verificar"
        h = hashlib.sha256(Path(ESTANDARES_PATH).read_bytes()).hexdigest()
        assert len(h) == 64

        datos = leer_estandares_virf("1")
        assert datos, "el estándar real no se pudo leer"
        n_act = sum(len(v) for v in datos.values())
        n_req = sum(1 for v in datos.values() for a in v if a.get("requerida"))
        assert n_act > 0 and 0 < n_req <= n_act, (
            f"conteos incoherentes: {n_req} requeridas de {n_act} actividades")

    def test_dos_estandares_distintos_dan_huellas_distintas(self, tmp_path):
        # Es la propiedad que hace útil el registro: si el estándar cambia, la
        # huella cambia, y un auditor puede demostrar que el criterio no fue
        # el mismo entre dos informes.
        import hashlib
        a = tmp_path / "a.xlsx"
        b = tmp_path / "b.xlsx"
        a.write_bytes(b"contenido del estandar v1")
        b.write_bytes(b"contenido del estandar v2")
        ha = hashlib.sha256(a.read_bytes()).hexdigest()
        hb = hashlib.sha256(b.read_bytes()).hexdigest()
        assert ha != hb

    def test_una_hoja_auxiliar_no_tumba_la_lectura(self, tmp_path, monkeypatch):
        """
        [AUDIT-FIX 2026-07-30] El Excel real trae una segunda hoja de apoyo con
        solo ÁMBITO y CONTROL. La validación estricta abortaba ante CUALQUIER
        hoja sin ACTIVIDAD, así que esa pestaña tumbaba la lectura del estándar
        COMPLETO: leer_estandares_virf() devolvía None y el pipeline moría con
        «No se pudieron cargar los estándares».

        La validación estricta debe seguir existiendo —nació porque renombrar
        ACTIVIDAD producía datos erróneos en silencio—, así que se distingue:
        sin ACTIVIDAD pero CON columnas TIER es una hoja mal etiquetada (error);
        sin ACTIVIDAD y SIN TIER no es una hoja de actividades (se omite).
        """
        import sys
        from openpyxl import Workbook
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        import Mx_00_CargaRutas as mx00
        import Mx_01_LecturaEvidencias as mx01

        wb = Workbook()
        ws = wb.active
        ws.title = "Actividades"
        ws.append(["AMBITO", "CONTROL", "ACTIVIDAD", "TIER I", "TIER II"])
        ws.append(["Metodología", "C1", "Revisar backtesting", "X", ""])
        aux = wb.create_sheet("Hoja2")           # auxiliar: sin ACTIVIDAD ni TIER
        aux.append(["AMBITO", "CONTROL"])
        aux.append(["Metodología", "C1"])
        ruta = tmp_path / "Estandares_VIRF.xlsx"
        wb.save(ruta)

        previo = mx00.RUTAS["estandares_virf"]
        try:
            mx00.RUTAS["estandares_virf"] = str(ruta)
            datos = mx01.leer_estandares_virf("1")
        finally:
            mx00.RUTAS["estandares_virf"] = previo

        assert datos, "la hoja auxiliar tumbó la lectura del estándar completo"
        assert "Metodología" in datos
        assert len(datos["Metodología"]) == 1

    def test_una_hoja_de_actividades_mal_etiquetada_SI_falla(self, tmp_path):
        """La contrapartida: con TIER pero sin ACTIVIDAD hay que fallar."""
        import sys
        from openpyxl import Workbook
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "motor"))
        import Mx_00_CargaRutas as mx00
        import Mx_01_LecturaEvidencias as mx01

        wb = Workbook()
        ws = wb.active
        ws.title = "Actividades"
        # ACTIVIDAD renombrada a DESCRIPCIÓN, pero con tiers: es el escenario
        # que producía datos erróneos en silencio.
        ws.append(["AMBITO", "CONTROL", "DESCRIPCION", "TIER I"])
        ws.append(["Metodología", "C1", "Revisar backtesting", "X"])
        ruta = tmp_path / "Estandares_VIRF.xlsx"
        wb.save(ruta)

        previo = mx00.RUTAS["estandares_virf"]
        try:
            mx00.RUTAS["estandares_virf"] = str(ruta)
            datos = mx01.leer_estandares_virf("1")
        finally:
            mx00.RUTAS["estandares_virf"] = previo

        assert not datos, (
            "una hoja CON tiers pero sin columna ACTIVIDAD debe fallar: el "
            "parser tomaría CONTROL como actividad y produciría datos erróneos "
            "sin ningún aviso")


# ══════════════════════════════════════════════════════════════════════════════
# [CODIGO-FIX 2026-07-30] El código del modelo debe llegar ÍNTEGRO al evaluador
#
# Petición del operador: el .py debe leerse completo, deben recorrerse las
# subcarpetas (un modelo puede traer sus propias librerías en libs/), y el
# .ipynb debe leerse también.
#
# Lo que había:
#   · `_leer_python` truncaba a MAX_CHARS_CODIGO (8.000 chars ≈ 200 líneas)
#     DENTRO del lector, por debajo del TRUNCADO-FIX. `chars_totales` se medía
#     sobre el texto ya recortado, así que un módulo de 40.000 chars se
#     reportaba con cobertura_pct=100.0 habiendo perdido el 80%.
#   · `.ipynb` NO estaba en LECTORES_EXT: `leer_archivo()` devolvía None y el
#     notebook se omitía SIN AVISO, mientras la instrucción del ámbito
#     Implementación pedía literalmente contrastar «los scripts (.py, .ipynb)».
# ══════════════════════════════════════════════════════════════════════════════
class TestCodigoSeLeeIntegro:

    def test_py_grande_no_se_trunca(self, tmp_path):
        import Mx_01_LecturaEvidencias as mx01
        grande = tmp_path / "calculo.py"
        contenido = "def f():\n    return 1\n" + ("# relleno\n" * 5000)
        grande.write_text(contenido, encoding="utf-8")

        doc = mx01.leer_archivo(grande)
        assert doc is not None
        assert len(doc["contenido"]) == len(contenido), (
            "el .py se sigue truncando: el contraste función a función contra "
            "el manual es imposible si solo llegan las primeras 200 líneas")
        assert doc["chars_totales"] == len(contenido)
        assert doc["truncado"] is False

    def test_cobertura_no_miente_sobre_codigo_recortado(self, tmp_path):
        """
        El defecto no era solo perder texto: era AFIRMAR cobertura 100% sobre
        lo perdido, porque chars_totales se medía después del recorte.
        """
        import Mx_01_LecturaEvidencias as mx01
        p = tmp_path / "m.py"
        p.write_text("x = 1\n" * 20000, encoding="utf-8")
        doc = mx01.leer_archivo(p)
        if doc["cobertura_pct"] == 100.0:
            assert len(doc["contenido"]) == doc["chars_totales"], (
                "declara cobertura 100% con menos contenido que chars_totales")

    def test_ipynb_es_leido_por_el_pipeline_completo(self, tmp_path):
        import Mx_01_LecturaEvidencias as mx01
        assert ".ipynb" in mx01.LECTORES_EXT, (
            "sin .ipynb en LECTORES_EXT, leer_archivo() devuelve None y el "
            "notebook desaparece de la evidencia sin ningún aviso")

        nb = {"cells": [
            {"cell_type": "markdown", "source": ["# Backtesting\n"]},
            {"cell_type": "code", "execution_count": 1,
             "source": "kupiec()\n", "outputs": []},
        ]}
        p = tmp_path / "bt.ipynb"
        p.write_text(json.dumps(nb), encoding="utf-8")
        doc = mx01.leer_archivo(p)
        assert doc is not None and doc["tipo"] == "IPYNB"
        assert "kupiec()" in doc["contenido"]
        assert "Backtesting" in doc["contenido"]

    def test_ipynb_declara_las_celdas_sin_ejecutar(self, tmp_path):
        """
        Un notebook entregado sin ejecutar es un hallazgo de validación. Si el
        lector no distingue ejecutado de no ejecutado, no se puede detectar.
        """
        import Mx_01_LecturaEvidencias as mx01
        nb = {"cells": [
            {"cell_type": "code", "execution_count": 1, "source": "a=1\n", "outputs": []},
            {"cell_type": "code", "execution_count": None, "source": "b=2\n", "outputs": []},
        ]}
        p = tmp_path / "n.ipynb"
        p.write_text(json.dumps(nb), encoding="utf-8")
        texto = mx01.leer_archivo(p)["contenido"]
        assert "SIN EJECUTAR" in texto
        assert "1 SIN EJECUTAR" in texto, "no declara CUANTAS celdas no corrieron"

    def test_ipynb_soporta_source_como_string_y_como_lista(self, tmp_path):
        """
        nbformat admite `source` como lista de líneas o como string único. La
        implementación anterior asumía lista: con un string, el join lo partía
        carácter a carácter y el código llegaba destrozado.
        """
        import Mx_01_LecturaEvidencias as mx01
        for i, fuente in enumerate(("import pandas as pd\n", ["import pandas as pd\n"])):
            p = tmp_path / ("n%d.ipynb" % i)
            p.write_text(json.dumps(
                {"cells": [{"cell_type": "code", "execution_count": 1,
                            "source": fuente, "outputs": []}]}), encoding="utf-8")
            assert "import pandas as pd" in mx01.leer_archivo(p)["contenido"]

    def test_ipynb_no_vuelca_imagenes_en_base64(self, tmp_path):
        """Un PNG en base64 son cientos de miles de chars ilegibles."""
        import Mx_01_LecturaEvidencias as mx01
        basura = "iVBORw0KGgo" * 5000
        nb = {"cells": [{"cell_type": "code", "execution_count": 1, "source": "plot()\n",
                         "outputs": [{"output_type": "display_data",
                                      "data": {"image/png": basura}}]}]}
        p = tmp_path / "g.ipynb"
        p.write_text(json.dumps(nb), encoding="utf-8")
        texto = mx01.leer_archivo(p)["contenido"]
        assert basura[:200] not in texto, "volco la imagen en base64 al prompt"
        assert "image/png" in texto, "debe DECLARAR que hubo una imagen"

    def test_subcarpetas_se_recorren_y_datasets_sigue_excluido(self, tmp_path):
        """
        Un modelo puede traer sus librerías en libs/. Deben leerse. Lo que NO
        debe leerse es datasets/ (un .csv se comía los 15.000 chars de contexto
        y expulsaba al manual) ni los ficheros ocultos como .env.
        """
        import Mx_01_LecturaEvidencias as mx01
        base = tmp_path / "implementacion"
        (base / "libs").mkdir(parents=True)
        (base / "notebooks").mkdir()
        (base / "datasets").mkdir()
        (base / "__pycache__").mkdir()
        (base / "main.py").write_text("import libs\n", encoding="utf-8")
        (base / "libs" / "calculo.py").write_text("def lar(): pass\n", encoding="utf-8")
        (base / "notebooks" / "bt.ipynb").write_text(json.dumps(
            {"cells": [{"cell_type": "code", "execution_count": 1,
                        "source": "x=1\n", "outputs": []}]}), encoding="utf-8")
        (base / "datasets" / "ops.csv").write_text("a,b\n1,2\n", encoding="utf-8")
        (base / ".env").write_text("SECRET=x\n", encoding="utf-8")
        (base / "__pycache__" / "m.pyc").write_bytes(b"\x00")

        nombres = {d["nombre"] for d in mx01.leer_carpeta(base)}
        assert {"main.py", "calculo.py", "bt.ipynb"} <= nombres, (
            "no recorre subcarpetas: %s" % nombres)
        assert "ops.csv" not in nombres, "datasets/ volvio a entrar como evidencia"
        assert ".env" not in nombres, "leyo un fichero de credenciales"
        assert not any(n.endswith(".pyc") for n in nombres)


# ══════════════════════════════════════════════════════════════════════════════
# Perfilado de datasets: el ESQUEMA es evidencia, las filas no
# ══════════════════════════════════════════════════════════════════════════════
class TestPerfiladorDatasets:

    @staticmethod
    def _crear(tmp_path):
        import pandas as pd
        df = pd.DataFrame({
            "id": [1, 2, 3, 4],
            "monto": [10.0, 20.0, None, 40.0],
            "moneda": ["PEN"] * 4,
            "muerta": [None] * 4,
        })
        df.to_csv(tmp_path / "ops.csv", index=False)
        return tmp_path

    def test_describe_esquema_sin_volcar_filas(self, tmp_path):
        from modulos.perfilador_datasets import perfilar_carpeta
        texto = perfilar_carpeta(self._crear(tmp_path))
        assert "ops" in texto and "monto" in texto and "float" in texto
        # Los valores individuales de una columna numérica no deben aparecer:
        # solo su rango. Ese es el límite entre esquema y datos.
        assert "10.0, 20.0, 40.0" not in texto

    def test_senala_columnas_constantes_y_nulas(self, tmp_path):
        from modulos.perfilador_datasets import perfilar_carpeta
        texto = perfilar_carpeta(self._crear(tmp_path))
        assert "CONSTANTE" in texto, "una columna con un solo valor es un hallazgo"
        assert "NULA" in texto

    def test_dataset_ilegible_se_declara_no_se_silencia(self):
        """Un perfil vacío sin explicación haría creer que no hay columnas."""
        from modulos.perfilador_datasets import perfilar_dataframe

        class DFRoto:
            shape = (0, 0)

            def __len__(self):
                return 0

            @property
            def columns(self):
                raise OSError("disco ilegible")

        p = perfilar_dataframe("roto", DFRoto())
        assert p.error, "un dataset ilegible debe declararse como tal"
        assert "No se pudo perfilar" in p.a_texto()

    def test_sin_datasets_no_inventa_documento(self, tmp_path):
        from modulos.perfilador_datasets import documento_perfil
        assert documento_perfil(tmp_path / "no_existe") is None


# ══════════════════════════════════════════════════════════════════════════════
# Revisión de código módulo a módulo
# ══════════════════════════════════════════════════════════════════════════════
class TestRevisionCodigo:

    @staticmethod
    def _arbol(tmp_path):
        base = tmp_path / "implementacion"
        (base / "libs").mkdir(parents=True)
        (base / "main.py").write_text("from libs.c import lar\n", encoding="utf-8")
        (base / "libs" / "c.py").write_text(
            "def lar(r, a=0.99):\n    return 1\n", encoding="utf-8")
        (base / ".env").write_text("K=1\n", encoding="utf-8")
        return base

    def test_descubre_recursivo_y_respeta_exclusiones(self, tmp_path):
        from modulos.revision_codigo import descubrir_modulos
        base = self._arbol(tmp_path)
        nombres = {m.name for m in descubrir_modulos(base)}
        assert nombres == {"main.py", "c.py"}, nombres

    def test_el_codigo_llega_numerado_al_prompt(self, tmp_path):
        """
        Sin números de línea escritos, el modelo los inventa y los hallazgos
        apuntan a código que no es el citado: dejan de ser verificables.
        """
        from modulos.revision_codigo import RevisorCodigo, descubrir_modulos
        capturados = []

        class Cli:
            def generar_mensaje(self, prompt="", **kw):
                capturados.append(prompt)
                return json.dumps({"resumen_modulo": "", "elementos_definidos": [],
                                   "hallazgos": []})

        base = self._arbol(tmp_path)
        RevisorCodigo(Cli()).revisar(descubrir_modulos(base), "manual",
                                     raiz=base, verbose=False)
        assert any(re.search(r"^\s*1 \|", p, re.M) for p in capturados), (
            "el codigo no llega con numeros de linea")

    def test_fallo_tecnico_no_se_disfraza_de_cero_hallazgos(self, tmp_path):
        from modulos.revision_codigo import RevisorCodigo, descubrir_modulos

        class CliRoto:
            def generar_mensaje(self, **kw):
                raise RuntimeError("429 rate limit")

        base = self._arbol(tmp_path)
        cons = RevisorCodigo(CliRoto()).revisar(
            descubrir_modulos(base), "manual", raiz=base, verbose=False)
        assert cons["revision_confiable"] is False, (
            "una revision que fallo tecnicamente NO puede reportarse como "
            "'sin hallazgos': es la misma mentira que D3-FIX evita al evaluar")
        assert cons["n_modulos_con_fallo"] == 2
        assert cons["n_hallazgos"] == 0

    def test_respuesta_no_json_invalida_la_revision(self, tmp_path):
        from modulos.revision_codigo import RevisorCodigo, descubrir_modulos

        class CliCharlatan:
            def generar_mensaje(self, **kw):
                return "Lo siento, no puedo ayudarte con eso."

        base = self._arbol(tmp_path)
        cons = RevisorCodigo(CliCharlatan()).revisar(
            descubrir_modulos(base), "manual", raiz=base, verbose=False)
        assert cons["revision_confiable"] is False

    def test_categoria_invalida_no_pierde_el_hallazgo(self, tmp_path):
        """
        Un hallazgo real con la etiqueta mal puesta sigue siendo un hallazgo.
        Descartarlo por vocabulario seria perder informacion de validacion.
        """
        from modulos.revision_codigo import (RevisorCodigo, descubrir_modulos,
                                             CATEGORIAS_HALLAZGO)

        class Cli:
            def generar_mensaje(self, **kw):
                return json.dumps({"resumen_modulo": "", "elementos_definidos": [],
                                   "hallazgos": [{"linea": 1, "categoria": "inventada",
                                                  "severidad": "altisima",
                                                  "elemento": "f",
                                                  "descripcion": "algo"}]})

        base = self._arbol(tmp_path)
        cons = RevisorCodigo(Cli()).revisar(descubrir_modulos(base), "m",
                                            raiz=base, verbose=False)
        assert cons["n_hallazgos"] == 2
        for h in cons["hallazgos"]:
            assert h["categoria"] in CATEGORIAS_HALLAZGO
            assert h["severidad"] in ("critica", "alta", "media", "baja")

    def test_modulo_grande_se_parte_en_frontera_de_definicion(self):
        """
        Cortar por ventanas de caracteres parte funciones por la mitad, y media
        funcion revisada contra el manual produce hallazgos FALSOS ('no valida
        la entrada' cuando la validacion quedo en el otro bloque).
        """
        from modulos.revision_codigo import _partir_por_definiciones
        codigo = ""
        for i in range(40):
            codigo += "def f%d(x):\n" % i + "    y = x\n" * 30 + "    return y\n\n"
        bloques = _partir_por_definiciones(codigo, max_chars=5000)
        assert len(bloques) > 1
        for _, b in bloques:
            assert b.lstrip().startswith(("def ", "class ", "@"))
        assert sum(b.count("def f") for _, b in bloques) == 40, "perdio funciones"

    def test_script_plano_no_se_sobreparte(self):
        """
        El fallback asumia 80 chars/linea: con lineas cortas partia 18.000 chars
        en 49 bloques de ~370 chars — 49 llamadas donde bastaban 4. El ancho de
        linea es un dato del fichero, no una constante que se pueda suponer.
        """
        from modulos.revision_codigo import _partir_por_definiciones
        plano = "x = 1\n" * 3000
        bloques = _partir_por_definiciones(plano, max_chars=5000)
        assert len(bloques) == 4, "sobre-particiona: %d bloques" % len(bloques)
        assert "".join(b for _, b in bloques) == plano, "perdio o duplico lineas"

    def test_inventario_incluye_el_manual_repetido(self, tmp_path):
        """
        El manual viaja en CADA llamada. Un inventario que solo cuente el codigo
        da una cifra optimista justo en el factor que domina cuando hay muchos
        modulos, y el operador decide gastar con un numero falso.
        """
        from modulos.revision_codigo import inventario
        for i in range(10):
            (tmp_path / ("m%d.py" % i)).write_text("x = 1\n", encoding="utf-8")
        mods = sorted(tmp_path.glob("*.py"))
        sin_manual = inventario(mods, raiz=tmp_path, chars_manual=0)
        con_manual = inventario(mods, raiz=tmp_path, chars_manual=20000)
        assert (con_manual["chars_totales_entrada"]
                > sin_manual["chars_totales_entrada"] * 10)
        assert con_manual["coste_estimado_usd"] > 0

    def test_el_inventario_precede_al_gasto_en_el_pipeline(self):
        """El coste debe verse ANTES de las llamadas, no en la factura."""
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        i_inv = src.find("formatear_inventario(_inv_cod)")
        i_rev = src.find("_revisor.revisar(")
        assert 0 < i_inv < i_rev, (
            "el inventario debe imprimirse antes de instanciar la revision")

    def test_dry_run_no_requiere_credencial(self):
        """`--revisar-codigo --dry-run` debe funcionar sin API key."""
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "not (args.revisar_codigo and args.dry_run)" in src, (
            "el inventario dejo de estar exento del PRE-FLIGHT: contar ficheros "
            "no puede exigir credencial")


# ══════════════════════════════════════════════════════════════════════════════
# [GENERICO 2026-07-30] El proyecto no puede atarse a un proveedor concreto
#
# Petición de la organización: dejar el código agnóstico, salvo la superficie
# real de la API (paquete `anthropic`, variables ANTHROPIC_*, IDs de modelo y la
# clase ClienteAnthropicIA, que ES el cliente de ese proveedor).
#
# Lo que se corrigió:
#   · `MODELO_CLAUDE` contenía el modelo ACTIVO fuera cual fuera el proveedor:
#     con Azure valía 'gpt-4o' y seguía llamándose «Claude». Ese nombre viajaba
#     al JSON de auditoría, así que la marca de un proveedor acababa en el campo
#     genérico de un informe regulatorio.
#   · El primer arranque mandaba SIEMPRE a console.anthropic.com, aunque el
#     proveedor por defecto del proyecto es Azure OpenAI.
#   · El error 401 decía «rechazada por Anthropic» con cualquier proveedor,
#     remitiendo al operador a revisar la credencial equivocada.
#   · El `--dry-run` del explicador estimaba a $1.0/Mtok rotulado «(Haiku 4.5)»
#     aunque el modelo activo fuera otro: se decidía gastar sobre una cifra
#     que no era la del proveedor configurado.
# ══════════════════════════════════════════════════════════════════════════════
class TestNeutralidadDeProveedor:

    # Ficheros donde una marca comercial SÍ es legítima: son la superficie real
    # del proveedor o el catálogo de modelos con sus IDs reales.
    EXENTOS = {"ia.py", "modelos.py", "parametros.py"}

    def test_modelo_ia_es_el_nombre_canonico(self):
        import Mx_00_CargaRutas as mx00
        assert hasattr(mx00, "MODELO_IA"), (
            "MODELO_IA es el nombre genérico del modelo activo")
        assert mx00.MODELO_IA, "no puede venir vacío"

    def test_el_alias_antiguo_sigue_funcionando(self):
        """
        Renombrar sin alias habría roto notebooks y scripts de la entidad que
        importen MODELO_CLAUDE. La meta del cambio era no perder funcionalidad.
        """
        import Mx_00_CargaRutas as mx00
        assert hasattr(mx00, "MODELO_CLAUDE"), "se eliminó el alias retrocompatible"
        assert mx00.MODELO_CLAUDE == mx00.MODELO_IA

    def test_el_json_de_auditoria_usa_el_nombre_generico(self):
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "MODELO_CLAUDE" not in vivas, (
            "agente.py volvió a usar el alias obsoleto: el nombre de un "
            "proveedor concreto acabaría en agente_meta.modelo_ia")
        assert "MODELO_IA" in vivas

    def test_ningun_modulo_de_negocio_nombra_una_marca_en_codigo_vivo(self):
        """
        Barrido de código EJECUTABLE. Se excluyen a propósito:

          · docstrings y comentarios — pueden (y deben) citar proveedores para
            explicar por qué se tomó una decisión;
          · nombres de variables de entorno (ANTHROPIC_API_KEY…) — son la
            superficie real de la API y renombrarlas rompería los .env
            desplegados, que es justo lo que este cambio no puede hacer.

        Lo que sí se persigue: que la LÓGICA dependa del nombre de una marca.
        """
        import ast
        infractores = []

        def _docstrings(arbol):
            """Nodos Constant que son docstring de módulo, clase o función."""
            fuera = set()
            for n in ast.walk(arbol):
                if isinstance(n, (ast.Module, ast.ClassDef,
                                  ast.FunctionDef, ast.AsyncFunctionDef)):
                    cuerpo = getattr(n, "body", None) or []
                    if (cuerpo and isinstance(cuerpo[0], ast.Expr)
                            and isinstance(cuerpo[0].value, ast.Constant)
                            and isinstance(cuerpo[0].value.value, str)):
                        fuera.add(id(cuerpo[0].value))
            return fuera

        # Un literal que es EXACTAMENTE un nombre de variable de entorno del
        # proveedor: categoría A, se queda.
        _ES_VAR_ENTORNO = re.compile(r"^[A-Z][A-Z0-9_]*$")

        for sub in ("modulos", "motor"):
            for f in sorted((RAIZ / sub).rglob("*.py")):
                if f.name in self.EXENTOS or "__pycache__" in str(f):
                    continue
                try:
                    arbol = ast.parse(f.read_text(encoding="utf-8"))
                except SyntaxError:
                    continue
                excluidos = _docstrings(arbol)
                for nodo in ast.walk(arbol):
                    if (isinstance(nodo, ast.Constant)
                            and isinstance(nodo.value, str)
                            and id(nodo) not in excluidos):
                        v = nodo.value
                        if _ES_VAR_ENTORNO.match(v):
                            continue
                        if any(m in v.lower() for m in ("claude", "anthropic")):
                            infractores.append(f"{f.name}: {v[:60]!r}")
                    if isinstance(nodo, ast.Name) and "CLAUDE" in nodo.id.upper():
                        if nodo.id != "MODELO_CLAUDE":     # el alias es deliberado
                            infractores.append(f"{f.name}: identificador {nodo.id}")
        assert not infractores, (
            "marca comercial en código ejecutable de negocio: %s" % infractores)

    def test_los_mensajes_derivan_del_proveedor_activo(self):
        """
        Los tres puntos donde el texto se dirigía siempre a Anthropic deben
        construirse desde la ficha del proveedor.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert vivas.count("metadatos_proveedor") >= 4, (
            "algún mensaje volvió a incrustar el proveedor en vez de leerlo "
            "de la ficha activa")
        assert "console.anthropic.com" not in vivas, (
            "agente.py vuelve a remitir a la consola de un proveedor concreto")

    def test_hay_ficha_para_cada_proveedor_soportado(self):
        """Un proveedor en FABRICAS sin ficha daría mensajes neutros e inútiles."""
        from config.ia import FABRICAS, METADATOS_PROVEEDOR
        faltan = set(FABRICAS) - set(METADATOS_PROVEEDOR)
        assert not faltan, (
            "proveedores sin metadatos para los mensajes: %s" % faltan)
        for nombre, meta in METADATOS_PROVEEDOR.items():
            for campo in ("nombre", "consola", "var_clave", "vars_revisar"):
                assert meta.get(campo), "%s: falta %s" % (nombre, campo)

    def test_proveedor_desconocido_no_revienta_el_mensaje(self):
        """
        Un mensaje de error no puede fallar al construirse: si lo hace, el
        operador pierde también el diagnóstico que venía a darle.
        """
        from config.ia import metadatos_proveedor
        m = metadatos_proveedor("proveedor_que_no_existe")
        assert m["nombre"] and m["consola"] and m["var_clave"]

    def test_el_coste_estimado_usa_el_modelo_activo(self):
        """
        El explicador tenía `tokens / 1_000_000 * 1.0` rotulado «(Haiku 4.5)».
        Con otro proveedor, la estimación era la de un modelo ajeno.
        """
        src = (RAIZ / "modulos" / "explicador_modelo.py").read_text(encoding="utf-8")
        # Solo líneas EJECUTABLES: el comentario que documenta este arreglo cita
        # el rótulo viejo a propósito, para que se entienda qué se corrigió.
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "Haiku 4.5" not in vivas, "el rótulo del modelo sigue incrustado"
        assert "* 1.0:" not in vivas, "el precio sigue incrustado como literal"
        assert "precio_entrada_por_mtok" in vivas, (
            "el precio volvió a estar incrustado en vez de salir del catálogo")

    def test_el_precio_se_declara_en_un_solo_sitio(self):
        from config.modelos import (precio_entrada_por_mtok,
                                    PRECIO_ENTRADA_POR_MTOK_DEFECTO)
        assert precio_entrada_por_mtok("gpt-4o") != precio_entrada_por_mtok("gpt-4")
        assert precio_entrada_por_mtok(None) == PRECIO_ENTRADA_POR_MTOK_DEFECTO
        assert precio_entrada_por_mtok("modelo_inexistente") == \
            PRECIO_ENTRADA_POR_MTOK_DEFECTO

    def test_las_variables_de_entorno_del_proveedor_no_se_renombraron(self):
        """
        Renombrar ANTHROPIC_API_KEY habría invalidado los .env ya desplegados.
        Es la parte que NO debía tocarse.
        """
        from config import parametros
        src = (RAIZ / "config" / "parametros.py").read_text(encoding="utf-8")
        for var in ("ANTHROPIC_API_KEY", "ANTHROPIC_MODELO",
                    "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT"):
            assert var in src or var in (RAIZ / "config" / "ia.py").read_text(
                encoding="utf-8"), "%s desapareció: rompería los .env existentes" % var
        assert parametros.IA_PROVEEDOR in ("anthropic", "azure_openai")


# ══════════════════════════════════════════════════════════════════════════════
# [CODIGO-FIX 2026-07-30, 2ª pasada] .sql y .R también son el modelo
#
# Tras incorporar .py y .ipynb quedó un agujero de la MISMA clase: `.sql` y `.R`
# no estaban en LECTORES_EXT, así que `leer_archivo()` devolvía None y el
# fichero se omitía SIN AVISO. En una entidad financiera el ETL del modelo suele
# vivir en SQL y buena parte del modelado en R, de modo que el agujero se
# tragaba justo la parte que más falta hace validar.
#
# Detalle que casi lo deja roto: la búsqueda usa `path.suffix.lower()`, así que
# registrar ".R" en mayúscula no habría casado NUNCA y el fichero habría seguido
# desapareciendo en silencio.
# ══════════════════════════════════════════════════════════════════════════════
class TestSqlYRSonCodigoDelModelo:

    def test_estan_registrados_en_minuscula(self):
        import Mx_01_LecturaEvidencias as mx01
        for ext in (".sql", ".r"):
            assert ext in mx01.LECTORES_EXT, (
                "%s no se lee: leer_archivo() devuelve None y el fichero "
                "desaparece de la evidencia sin aviso" % ext)
            assert ext in mx01.EXTENSIONES_CODIGO
        assert ".R" not in mx01.LECTORES_EXT, (
            "la búsqueda usa suffix.lower(): una clave en mayúscula no casa "
            "jamás y da falsa sensación de cobertura")

    def test_un_fichero_R_en_mayuscula_se_lee(self, tmp_path):
        """El caso real: en disco los ficheros de R se llaman `modelo.R`."""
        import Mx_01_LecturaEvidencias as mx01
        p = tmp_path / "modelo.R"
        p.write_text("estimar <- function(x) {\n  quantile(x, 0.99)\n}\n",
                     encoding="utf-8")
        doc = mx01.leer_archivo(p)
        assert doc is not None, "un .R en mayúscula sigue sin leerse"
        assert "estimar <- function" in doc["contenido"]

    def test_sql_y_r_se_leen_integros(self, tmp_path):
        import Mx_01_LecturaEvidencias as mx01
        for nombre, cuerpo in (("carga.sql", "SELECT 1;\n"),
                               ("modelo.R", "f <- function() 1\n")):
            p = tmp_path / nombre
            texto = cuerpo * 4000          # muy por encima de MAX_CHARS_CODIGO
            p.write_text(texto, encoding="utf-8")
            doc = mx01.leer_archivo(p)
            assert len(doc["contenido"]) == len(texto), (
                "%s se truncó: mismo defecto que tenía el .py" % nombre)

    def test_entran_en_la_revision_modulo_a_modulo(self, tmp_path):
        from modulos.revision_codigo import descubrir_modulos
        base = tmp_path / "implementacion"
        (base / "etl").mkdir(parents=True)
        (base / "calculo.py").write_text("def f(): pass\n", encoding="utf-8")
        (base / "modelo.R").write_text("f <- function() 1\n", encoding="utf-8")
        (base / "etl" / "carga.sql").write_text("SELECT 1;\n", encoding="utf-8")
        nombres = {m.name for m in descubrir_modulos(base)}
        assert nombres == {"calculo.py", "modelo.R", "carga.sql"}, nombres

    def test_cada_fichero_viaja_con_su_lenguaje(self, tmp_path):
        """
        Etiquetar un script de R como ```python invita al modelo a leerlo con
        la sintaxis equivocada y a "corregir" lo que no está roto.
        """
        from modulos.revision_codigo import (RevisorCodigo, descubrir_modulos,
                                             _lenguaje_de)
        base = tmp_path / "implementacion"
        base.mkdir()
        (base / "a.py").write_text("def f(): pass\n", encoding="utf-8")
        (base / "b.R").write_text("f <- function() 1\n", encoding="utf-8")
        (base / "c.sql").write_text("SELECT 1;\n", encoding="utf-8")

        assert _lenguaje_de(base / "b.R") == "r"
        assert _lenguaje_de(base / "c.sql") == "sql"
        assert _lenguaje_de(base / "a.py") == "python"

        capturados = []

        class Cli:
            def generar_mensaje(self, prompt="", **kw):
                capturados.append(prompt)
                return json.dumps({"resumen_modulo": "", "elementos_definidos": [],
                                   "hallazgos": []})

        cons = RevisorCodigo(Cli()).revisar(descubrir_modulos(base), "manual",
                                            raiz=base, verbose=False)
        declarados = {p.split("Lenguaje: ")[1].split("\n")[0] for p in capturados}
        assert declarados == {"python", "r", "sql"}, declarados
        assert {m["lenguaje"] for m in cons["modulos"]} == {"python", "r", "sql"}

    def test_r_se_parte_en_definicion_de_funcion(self):
        """
        R declara funciones por asignación (`f <- function(x)`). Con las
        fronteras de Python, NINGUNA línea casaría y el fichero caería al
        reparto ciego por ventanas, cortando funciones por la mitad.
        """
        from modulos.revision_codigo import _partir_por_definiciones
        codigo = ""
        for i in range(30):
            codigo += ("func_%d <- function(x) {\n" % i
                       + "  y <- x + 1\n" * 25 + "  return(y)\n}\n\n")
        bloques = _partir_por_definiciones(codigo, max_chars=4000, lenguaje="r")
        assert len(bloques) > 1
        for _, b in bloques:
            assert "<- function" in b.splitlines()[0], (
                "un bloque de R no empieza en definición: %r" % b.splitlines()[0])
        assert sum(b.count("<- function") for _, b in bloques) == 30, "perdió funciones"

    def test_sql_no_parte_una_sentencia_por_la_mitad(self):
        """
        `SELECT` es token de frontera y también aparece DENTRO de
        `CREATE TABLE x AS SELECT …`. Sin la guarda del terminador, el corte
        partía esa sentencia en dos y cada mitad se revisaba por separado:
        media consulta contrastada contra el manual da el mismo hallazgo falso
        que media función.
        """
        from modulos.revision_codigo import _partir_por_definiciones
        sql = ""
        for i in range(25):
            sql += ("CREATE TABLE t%d AS\n" % i
                    + "SELECT a FROM origen\n" * 25 + ";\n\n")
        bloques = _partir_por_definiciones(sql, max_chars=4000, lenguaje="sql")
        assert len(bloques) > 1
        for _, b in bloques:
            assert b.lstrip().upper().startswith("CREATE"), (
                "bloque que arranca a mitad de sentencia: %r"
                % b.splitlines()[0])
            assert b.rstrip().endswith(";"), "bloque que no cierra la sentencia"
        assert sum(b.count("CREATE TABLE") for _, b in bloques) == 25

    def test_ningun_lenguaje_pierde_contenido_al_partir(self):
        """Invariante común: partir no puede perder ni duplicar una línea."""
        from modulos.revision_codigo import _partir_por_definiciones
        casos = {
            "python": "".join("def f%d():\n    return %d\n\n" % (i, i)
                              for i in range(60)),
            "r":      "".join("f%d <- function() %d\n\n" % (i, i)
                              for i in range(60)),
            "sql":    "".join("CREATE TABLE t%d AS SELECT %d;\n\n" % (i, i)
                              for i in range(60)),
        }
        for leng, texto in casos.items():
            bloques = _partir_por_definiciones(texto, max_chars=500, lenguaje=leng)
            assert "".join(b for _, b in bloques) == texto, (
                "%s: partir alteró el contenido" % leng)

    def test_el_catalogo_de_lenguajes_cubre_todo_el_codigo(self):
        """
        Una extensión en EXTENSIONES_CODIGO sin entrada en LENGUAJE_POR_EXT se
        revisaría etiquetada como Python y troceada con fronteras ajenas.
        """
        import Mx_01_LecturaEvidencias as mx01
        faltan = set(mx01.EXTENSIONES_CODIGO) - set(mx01.LENGUAJE_POR_EXT)
        assert not faltan, "extensiones de código sin lenguaje declarado: %s" % faltan


# ══════════════════════════════════════════════════════════════════════════════
# [POLÍTICA 2026-07-30] OCR retirado — el agente no ejecuta modelos externos
#
# `pytesseract` + `pdf2image` daban OCR a los PDFs escaneados. Se retiraron por
# la misma política que apartó a `sentence-transformers`: Tesseract es un motor
# de reconocimiento con sus propios modelos de lenguaje (spa, eng).
#
# Lo que este bloque protege NO es la retirada, sino su CONSECUENCIA: un PDF
# escaneado ya no se puede leer, y eso tiene que declararse como FALLO TÉCNICO
# del agente — nunca como falta de evidencia del validado (invariante 3). Si
# saliera con texto vacío y cobertura 100 %, el ámbito puntuaría 0.0 y el
# informe culparía al modelador de no aportar un documento que sí aportó.
# ══════════════════════════════════════════════════════════════════════════════
class TestOCRRetiradoPorPolitica:

    @staticmethod
    def _pdf_sin_texto(tmp_path, nombre="acta_escaneada.pdf"):
        p = tmp_path / nombre
        p.write_bytes(b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
                      b"2 0 obj<</Type/Pages/Kids[]/Count 0>>endobj\n"
                      b"trailer<</Root 1 0 R>>\n%%EOF\n")
        return p

    def test_el_codigo_ya_no_invoca_ocr(self):
        import Mx_01_LecturaEvidencias as mx01
        from pathlib import Path as _P
        fuente = _P(mx01.__file__).read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        # Se busca la INVOCACIÓN, no la mención: los docstrings explican por qué
        # se retiró, y esa explicación es lo que hace entendible el cambio.
        for patron in ("pytesseract.image_to_string", "convert_from_path(",
                       "import pytesseract", "from pdf2image"):
            assert patron not in vivas, f"el OCR volvió al código: {patron}"

    def test_un_pdf_escaneado_se_declara_fallo_tecnico(self, tmp_path):
        import Mx_01_LecturaEvidencias as mx01
        doc = mx01.leer_archivo(self._pdf_sin_texto(tmp_path))
        assert doc is not None
        assert doc["lectura_fallida"] is True, (
            "un PDF sin texto extraíble debe marcarse como fallo técnico")
        assert doc["cobertura_pct"] == 0.0, (
            "cobertura 100% sobre un documento ilegible es la mentira que "
            "el invariante 4 prohíbe")

    def test_el_mensaje_dice_al_operador_qué_hacer(self, tmp_path):
        """
        Un «PDF no legible» a secas deja al operador sin salida. Debe explicar
        que es un escaneado, por qué no hay OCR, y cuál es la alternativa.
        """
        import Mx_01_LecturaEvidencias as mx01
        texto = mx01.leer_archivo(self._pdf_sin_texto(tmp_path))["contenido"]
        assert "ESCANEADO" in texto
        assert "QUÉ HACER" in texto, "no ofrece salida al operador"
        assert "FALLO TÉCNICO" in texto, (
            "no distingue fallo técnico de falta de evidencia: el auditor "
            "leería esto como incumplimiento del validado")

    def test_las_dependencias_de_ocr_no_se_declaran(self):
        """Listarlas como opcionales invitaría a instalarlas."""
        req = (RAIZ / "requirements.txt").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in req.splitlines()
                          if not l.lstrip().startswith("#"))
        for paquete in ("pytesseract", "pdf2image"):
            assert paquete not in vivas, f"{paquete} volvió a requirements.txt"

    def test_ningun_modelo_externo_queda_declarado(self):
        """Barrido conjunto: ni OCR ni embeddings locales como dependencia."""
        req = (RAIZ / "requirements.txt").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in req.splitlines()
                          if not l.lstrip().startswith("#"))
        for paquete in ("pytesseract", "pdf2image", "sentence-transformers",
                        "sentence_transformers", "transformers", "torch"):
            assert paquete not in vivas, (
                f"{paquete} se declara como dependencia: es un modelo externo")


# ══════════════════════════════════════════════════════════════════════════════
# [CONCURRENCIA 2026-07-30] La cadena de custodia con varios validadores
#
# `sellar()` LEE el último eslabón y `agente.py` ESCRIBÍA el JSON después, en
# dos pasos sueltos. Entre uno y otro cabe otro proceso:
#
#     Ana:  lee eslabón #4 ──┐
#     Luis: lee eslabón #4 ──┤  ambos ven el mismo
#     Ana:  escribe #5 ──────┤
#     Luis: escribe #5 ──────┘  sobre el mismo hash_informe_anterior
#
# Reproducido con el método viejo y 6 hilos: los SEIS informes declararon ser el
# eslabón #1. `verificar_cadena` lo reporta como cadena ROTA —correctamente—
# pero nadie ha manipulado nada: solo coincidieron dos validaciones del mismo
# modelo, algo normal en un cierre trimestral con un equipo de 2-5 personas.
#
# El daño es peor que un fallo: un informe legítimo queda marcado como
# sospechoso ante el auditor, que es justo lo que la cadena existe para evitar.
# ══════════════════════════════════════════════════════════════════════════════
class TestCadenaDeCustodiaBajoConcurrencia:

    @staticmethod
    def _emitir(out, modelo, n, quien="validador"):
        from modulos.custodia import sellar_y_escribir
        payload = {"modelo": modelo, "tier": "1", "fecha": f"2026-07-{n:02d}",
                   "validador": quien, "score_global": 4.0}
        ruta = out / f"resultados_M_2026-07-{n:02d}.json"
        return sellar_y_escribir(payload, ruta, out, modelo, {})

    def test_seis_validaciones_simultaneas_no_bifurcan_la_cadena(self, tmp_path):
        import threading
        from modulos.custodia import verificar_cadena
        modelo = "Modelo LaR"
        errores = []

        def tarea(i):
            try:
                self._emitir(tmp_path, modelo, i + 1, f"validador{i}")
            except Exception as exc:                       # noqa: BLE001
                errores.append(str(exc))

        hilos = [threading.Thread(target=tarea, args=(i,)) for i in range(6)]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join()

        assert not errores, f"errores en concurrencia: {errores}"
        posiciones = sorted(
            json.loads(p.read_text(encoding="utf-8"))["custodia"]["posicion_en_cadena"]
            for p in tmp_path.glob("resultados_*.json"))
        assert posiciones == list(range(1, 7)), (
            f"cadena bifurcada: {posiciones} — dos informes declaran el mismo "
            f"eslabón y el auditor vería una cadena rota sin manipulación")
        assert verificar_cadena(tmp_path, modelo)["integra"]

    def test_el_sellado_y_la_escritura_son_una_sola_operacion(self):
        """
        El lock debe cubrir LECTURA + ESCRITURA. Ponerlo solo dentro de
        `sellar()` protegería la lectura y dejaría la escritura fuera: la
        carrera seguiría abierta con la falsa sensación de estar resuelta.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "sellar_y_escribir(" in vivas, (
            "agente.py volvió a sellar y escribir en pasos separados")
        assert "json.dump(_payload" not in vivas, (
            "sigue habiendo una escritura del payload fuera del lock")

    def test_preservar_el_previo_ocurre_dentro_del_lock(self):
        """
        `preservar_si_existe` renombra el fichero del día. Hacerlo fuera del
        lock reabre la carrera por otra puerta: dos procesos archivando el
        mismo fichero.
        """
        src = (RAIZ / "modulos" / "custodia.py").read_text(encoding="utf-8")
        i_lock = src.find("with _lock_archivo(")
        i_preservar = src.find("preservar_si_existe(ruta_json)", i_lock)
        i_fin = src.find("return datos, archivado", i_lock)
        assert 0 < i_lock < i_preservar < i_fin, (
            "preservar_si_existe quedó fuera del bloque protegido")

    def test_el_lock_es_por_modelo_no_global(self):
        """
        Dos personas validando modelos DISTINTOS no tienen por qué esperarse.
        Un lock global serializaría todo el equipo sin motivo.
        """
        from modulos.custodia import _ruta_lock
        a = _ruta_lock(RAIZ / "outputs", "Modelo LaR")
        b = _ruta_lock(RAIZ / "outputs", "VaR Mercado FRTB")
        assert a != b, "el lock es global: serializa validaciones independientes"
        # Y el mismo modelo escrito de otra forma debe compartir lock.
        assert _ruta_lock(RAIZ / "outputs", "modelo lar") == a

    def test_el_json_escrito_es_valido_pese_a_objetos_no_serializables(self, tmp_path):
        """
        `_escribir_json_atomico` no admite `default=`, y el payload lleva Path y
        datetime. Si no se normaliza, el sellado revienta al escribir — después
        de haber pagado toda la corrida.
        """
        from pathlib import Path as _P
        from datetime import datetime as _dt
        from modulos.custodia import sellar_y_escribir
        payload = {"modelo": "M", "ruta": _P("/tmp/x"), "cuando": _dt.now()}
        ruta = tmp_path / "resultados_M.json"
        sellar_y_escribir(payload, ruta, tmp_path, "M", {})
        datos = json.loads(ruta.read_text(encoding="utf-8"))
        assert datos["custodia"]["posicion_en_cadena"] == 1


# ══════════════════════════════════════════════════════════════════════════════
# [P0.3 · P0.4 2026-07-30] Asimetrías entre los dos pipelines
# ══════════════════════════════════════════════════════════════════════════════
class TestLosDosPipelinesSeComportanIgual:

    def test_ambos_escriben_los_informes_en_el_mismo_sitio(self):
        """
        `--control` usaba `base_project_path / outputs`, que es la RAÍZ DE
        EVIDENCIA: con --raiz-evidencia los informes aterrizaban fuera y
        `--verificar-cadena` —que lee de OUTPUTS_DIR— no los encontraba. La
        cadena de custodia de un modelo quedaba invisible para su propia
        herramienta de verificación.
        """
        import inspect
        from modulos.motor_ia_v2 import orquestar_pipeline_virf
        src = inspect.getsource(orquestar_pipeline_virf)
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "OUTPUTS_DIR" in vivas, (
            "el pipeline por control volvió a derivar outputs/ de la evidencia")
        assert 'base_path / "outputs"' not in vivas

    def test_raiz_evidencia_solo_redirige_la_entrada(self):
        """La regla que `redirigir_evidencia` declara y ahora ambos cumplen."""
        import Mx_00_CargaRutas as mx00
        doc = (mx00.redirigir_evidencia.__doc__ or "")
        assert "outputs" in doc.lower(), (
            "la regla dejó de estar documentada donde se aplica")

    def test_sin_llm_exime_del_preflight_en_los_dos_modos_de_notebook(self):
        """
        La exención existía para `--convertir-excel --sin-llm` y faltaba la
        simétrica: `--controles-a-notebook --sin-llm` no usa el modelo pero
        exigía credencial igual.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "(args.convertir_excel and args.sin_llm)" in vivas
        assert "(args.controles_a_notebook and args.sin_llm)" in vivas, (
            "--controles-a-notebook --sin-llm sigue exigiendo credencial")


# ══════════════════════════════════════════════════════════════════════════════
# [BLOQUE 2 · 2026-07-30] Pre-vuelo de la evidencia
#
# Los tres problemas que se descubrían A MITAD DE CORRIDA, con la extracción y
# varias llamadas ya pagadas:
#
#   · un PDF escaneado —ilegible desde que se retiró el OCR— salía como
#     lectura_fallida cuando el ámbito ya se estaba evaluando;
#   · un .yaml o un .sas se omitía SIN AVISO: leer_archivo() devuelve None y
#     el fichero desaparece sin que nadie lo cuente;
#   · una carpeta vacía producía un ámbito «sin evidencia» que puntúa 0.0 —
#     una falta crítica atribuida al VALIDADO por un documento que nadie echó
#     en falta a tiempo.
# ══════════════════════════════════════════════════════════════════════════════
class TestPrevueloDeEvidencia:

    @staticmethod
    def _arbol(tmp_path, con_escaneado=True, con_sin_lector=True,
               vaciar=()):
        """Monta un árbol de evidencia y devuelve el mapa de rutas."""
        r = tmp_path / "inputs"
        carpetas = {
            "doc_modelamiento": r / "documentacion" / "modelamiento",
            "doc_seguimiento":  r / "documentacion" / "seguimiento",
            "papers":           r / "papers",
            "calidad_datos":    r / "calidad_datos",
            "implementacion":   r / "implementacion",
            "usos":             r / "usos",
        }
        for c in carpetas.values():
            c.mkdir(parents=True, exist_ok=True)
        for nombre, ruta in carpetas.items():
            if nombre in vaciar:
                continue
            (ruta / f"doc_{nombre}.md").write_text("# Contenido\n" * 20,
                                                   encoding="utf-8")
        if con_escaneado:
            (carpetas["doc_seguimiento"] / "acta.pdf").write_bytes(
                b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
                b"2 0 obj<</Type/Pages/Kids[]/Count 0>>endobj\n"
                b"trailer<</Root 1 0 R>>\n%%EOF\n")
        if con_sin_lector:
            (carpetas["implementacion"] / "carga.sas").write_text("proc sql;",
                                                                  encoding="utf-8")
            (carpetas["implementacion"] / "config.yaml").write_text("a: 1",
                                                                    encoding="utf-8")
        return carpetas

    @staticmethod
    def _mapa():
        import Mx_00_CargaRutas as mx00
        return mx00.AMBITO_A_INPUTS

    def test_detecta_el_pdf_escaneado(self, tmp_path):
        from modulos.prevuelo import ejecutar_prevuelo
        inf = ejecutar_prevuelo(self._arbol(tmp_path), self._mapa())
        assert len(inf.escaneados) == 1
        assert inf.escaneados[0].nombre == "acta.pdf"
        assert "OCR" in inf.escaneados[0].detalle

    def test_detecta_los_formatos_que_se_omiten_sin_aviso(self, tmp_path):
        """El caso que más duele: hoy desaparecen sin dejar rastro."""
        from modulos.prevuelo import ejecutar_prevuelo
        inf = ejecutar_prevuelo(self._arbol(tmp_path), self._mapa())
        nombres = {h.nombre for h in inf.sin_lector}
        assert nombres == {"carga.sas", "config.yaml"}, nombres
        assert all("SIN AVISO" in h.detalle for h in inf.sin_lector)

    def test_un_ambito_sin_evidencia_es_bloqueante(self, tmp_path):
        """
        Puntúa 0.0 y esa nota se atribuye al VALIDADO. Es la consecuencia más
        cara de lanzar sin mirar.
        """
        from modulos.prevuelo import ejecutar_prevuelo
        # Vaciar TODO deja los 6 ámbitos sin evidencia
        carpetas = self._arbol(tmp_path, con_escaneado=False,
                               con_sin_lector=False,
                               vaciar=tuple(("doc_modelamiento", "doc_seguimiento",
                                             "papers", "calidad_datos",
                                             "implementacion", "usos")))
        inf = ejecutar_prevuelo(carpetas, self._mapa())
        assert len(inf.ambitos_sin_evidencia) == 6
        assert inf.hay_bloqueantes is True

    def test_evidencia_parcial_avisa_pero_no_bloquea(self, tmp_path):
        """
        El ámbito TIENE evidencia pero su carpeta PRINCIPAL está vacía:
        «Calidad de datos» sin `calidad_datos/` se evaluaría solo desde el
        manual. Técnicamente hay evidencia, pero no la que ese ámbito examina.
        """
        from modulos.prevuelo import ejecutar_prevuelo
        carpetas = self._arbol(tmp_path, con_escaneado=False,
                               con_sin_lector=False, vaciar=("calidad_datos",))
        inf = ejecutar_prevuelo(carpetas, self._mapa())
        parciales = dict(inf.ambitos_parciales)
        assert "Calidad de datos" in parciales
        assert parciales["Calidad de datos"] == "calidad_datos"
        assert inf.hay_bloqueantes is False, "un parcial no debe bloquear"

    def test_no_llama_al_modelo(self, tmp_path, monkeypatch):
        """Coste 0: es la premisa del comando."""
        import config.ia as ia
        llamadas = []
        monkeypatch.setattr(ia, "get_cliente_ia",
                            lambda *a, **k: llamadas.append(1))
        from modulos.prevuelo import ejecutar_prevuelo
        ejecutar_prevuelo(self._arbol(tmp_path), self._mapa())
        assert not llamadas, "el pre-vuelo llamó al proveedor de IA"

    def test_cuenta_los_legibles_y_sus_chars(self, tmp_path):
        from modulos.prevuelo import ejecutar_prevuelo
        inf = ejecutar_prevuelo(self._arbol(tmp_path), self._mapa())
        assert len(inf.legibles) == 6, [d["nombre"] for d in inf.legibles]
        assert inf.chars_totales > 0

    def test_el_informe_dice_que_hacer_con_cada_problema(self, tmp_path):
        from modulos.prevuelo import ejecutar_prevuelo, formatear
        texto = formatear(ejecutar_prevuelo(self._arbol(tmp_path), self._mapa()))
        assert "digital" in texto, "no dice qué hacer con un escaneado"
        assert "LECTORES_EXT" in texto, "no dice cómo arreglar un formato omitido"

    def test_el_flag_existe_y_esta_exento_del_preflight(self):
        """Comprobar la evidencia no puede exigir credencial."""
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert '"--prevuelo"' in src
        assert "not args.prevuelo" in vivas, (
            "--prevuelo exige credencial: comprobar la evidencia debe ser gratis")

    def test_sale_con_codigo_1_solo_si_hay_bloqueantes(self):
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "sys.exit(1 if _inf.hay_bloqueantes else 0)" in src, (
            "el código de salida dejó de distinguir bloqueante de aviso")


# ══════════════════════════════════════════════════════════════════════════════
# [BLOQUE 3 · 2026-07-30] Comparación entre corridas
#
# Un validador que revisa el mismo modelo cada trimestre necesita explicar por
# qué el puntaje pasó de 3,2 a 4,0. Y hay una pregunta peor, que a mano casi no
# se puede responder:
#
#     ¿el modelo MEJORÓ, o cambió el CRITERIO con el que se le mide?
#
# Las dos producen la misma subida. Distinguirlas es la razón por la que el
# informe guarda `agente.estandar` con el SHA-256 del Excel de estándares. Ese
# dato se guardaba desde hacía tiempo y NADIE lo leía.
# ══════════════════════════════════════════════════════════════════════════════
class TestComparacionEntreCorridas:

    DOCS = {"documentacion/manual.pdf": {"sha256": "aaa111", "chars": 40000}}

    @classmethod
    def _informe(cls, modelo, fecha, punt, *, est_sha="EST-V1",
                 modelo_ia="gpt-4o", docs=None, requeridas=11, acts=None):
        return {
            "modelo": modelo, "tier": "1", "fecha": fecha,
            "score_global": float(punt),
            "scores_por_ambito": {"Metodología": float(punt)},
            "resultados_por_ambito": acts or {
                "Metodología": [{"actividad": "Backtesting Kupiec",
                                 "puntaje": punt, "observacion": ""}]},
            "agente": {
                "agente_version": "27.1", "modelo_ia": modelo_ia,
                "proveedor_ia": "azure_openai",
                "documentos_huella": docs if docs is not None else cls.DOCS,
                "estandar": {"archivo": "Estandares_VIRF.xlsx",
                             "sha256": est_sha, "n_actividades": 21,
                             "n_requeridas_en_este_tier": requeridas},
            },
        }

    @classmethod
    def _emitir(cls, out, modelo, fecha, punt, **kw):
        from modulos.custodia import sellar_y_escribir
        ruta = out / f"resultados_{modelo}_{fecha}.json"
        sellar_y_escribir(cls._informe(modelo, fecha, punt, **kw),
                          ruta, out, modelo, {})
        return ruta

    def test_exige_dos_informes_y_lo_dice(self, tmp_path):
        from modulos.comparador import comparar
        self._emitir(tmp_path, "M", "2026-04-15", 3)
        with pytest.raises(ValueError) as exc:
            comparar(tmp_path, "M")
        assert "al menos 2" in str(exc.value)

    def test_detecta_la_mejora_real(self, tmp_path):
        from modulos.comparador import comparar
        self._emitir(tmp_path, "M", "2026-04-15", 3)
        self._emitir(tmp_path, "M", "2026-07-30", 4,
                     docs={"documentacion/manual.pdf":
                           {"sha256": "NUEVO", "chars": 52000}})
        c = comparar(tmp_path, "M")
        assert c.delta_score == pytest.approx(1.0)
        assert len(c.subieron) == 1 and not c.bajaron
        assert c.docs_modificados == ["documentacion/manual.pdf"]
        assert c.vara_cambiada is False, (
            "con el mismo estándar y el mismo modelo de IA, la vara no cambió")

    def test_detecta_que_cambio_la_vara_de_medir(self, tmp_path):
        """
        MISMA evidencia, MISMO modelo, pero el estándar se revisó y cambió el
        modelo de IA. El score sube +1.00 sin que el modelo validado haya
        cambiado nada. Sin esta detección, alguien reporta «el modelo mejoró».
        """
        from modulos.comparador import comparar
        self._emitir(tmp_path, "M", "2026-04-15", 3)
        self._emitir(tmp_path, "M", "2026-07-30", 4,
                     est_sha="EST-V2", modelo_ia="gpt-5", requeridas=14)
        c = comparar(tmp_path, "M")
        assert c.vara_cambiada is True
        assert c.cambio_estandar["sha256_antes"] == "EST-V1"
        assert c.cambio_estandar["requeridas_ahora"] == 14
        assert c.cambio_motor["modelo_ia"]["ahora"] == "gpt-5"
        assert not c.docs_modificados, "la evidencia no cambió"

    def test_el_aviso_de_vara_va_antes_que_los_numeros(self, tmp_path):
        """
        Si cambió el criterio, cualquier lectura de los deltas es engañosa.
        Enterrar el aviso al final lo haría inútil.
        """
        from modulos.comparador import comparar, formatear
        self._emitir(tmp_path, "M", "2026-04-15", 3)
        self._emitir(tmp_path, "M", "2026-07-30", 4, est_sha="EST-V2")
        texto = formatear(comparar(tmp_path, "M"))
        assert texto.index("VARA DE MEDIR") < texto.index("SCORE GLOBAL")

    def test_avisa_de_variabilidad_del_modelo_de_lenguaje(self, tmp_path):
        """
        Misma evidencia, misma vara, y aun así el score cambia: es variabilidad
        del LLM entre corridas. Atribuirla al modelo validado sería un error de
        lectura con consecuencias.
        """
        from modulos.comparador import comparar, formatear
        self._emitir(tmp_path, "M", "2026-04-15", 3)
        self._emitir(tmp_path, "M", "2026-07-30", 4)
        texto = formatear(comparar(tmp_path, "M"))
        assert "variabilidad" in texto.lower()

    def test_clasifica_nuevas_y_desaparecidas(self, tmp_path):
        from modulos.comparador import comparar
        a1 = {"Metodología": [{"actividad": "Vieja", "puntaje": 3}]}
        a2 = {"Metodología": [{"actividad": "Nueva", "puntaje": 4}]}
        self._emitir(tmp_path, "M", "2026-04-15", 3, acts=a1)
        self._emitir(tmp_path, "M", "2026-07-30", 4, acts=a2)
        c = comparar(tmp_path, "M")
        assert [x.actividad for x in c.nuevas] == ["Nueva"]
        assert [x.actividad for x in c.desaparecidas] == ["Vieja"]

    def test_usa_el_orden_de_la_cadena_no_el_del_fichero(self, tmp_path):
        """
        `informes_de_modelo` ordena SIGUIENDO LOS ENLACES. Comparar «los dos
        últimos» es comparar dos eslabones consecutivos, no dos ficheros con
        fechas próximas.
        """
        from modulos.comparador import comparar
        self._emitir(tmp_path, "M", "2026-01-01", 2)
        self._emitir(tmp_path, "M", "2026-04-15", 3)
        self._emitir(tmp_path, "M", "2026-07-30", 4)
        c = comparar(tmp_path, "M")
        assert (c.eslabon_antes, c.eslabon_ahora) == (2, 3), (
            "no comparó los dos últimos eslabones de la cadena")

    def test_el_flag_esta_exento_del_preflight(self):
        """Comparar informes ya emitidos no debe exigir credencial."""
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert '"--comparar"' in src
        assert "not args.comparar" in vivas

    def test_sale_con_1_si_cambio_la_vara(self):
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "sys.exit(1 if _cmp.vara_cambiada else 0)" in src


# ══════════════════════════════════════════════════════════════════════════════
# [BLOQUE 4 · 2026-07-30] Trazabilidad del prompt
#
# Un auditor formula tres preguntas sobre un puntaje. El informe respondía dos:
#
#     «¿sobre qué evidencia?»    → agente.documentos_huella
#     «¿con qué criterio?»       → agente.estandar
#     «¿y qué le preguntasteis?» → ← ESTA no tenía respuesta
#
# Dos corridas con la misma evidencia y el mismo estándar podían dar puntajes
# distintos porque alguien reescribió una instrucción de ámbito, y nada en el
# informe lo delataba.
# ══════════════════════════════════════════════════════════════════════════════
class TestTrazabilidadDelPrompt:

    def test_la_huella_de_plantilla_es_determinista(self):
        from modulos.huella_prompts import huella_plantilla_prompts
        a = huella_plantilla_prompts(forzar=True)["plantilla"]
        b = huella_plantilla_prompts(forzar=True)["plantilla"]
        assert a == b and len(a) == 12

    def test_cambiar_el_rol_del_agente_cambia_la_huella(self):
        """
        Reescribir el rol o una instrucción de ámbito cambia lo que se le
        pregunta al modelo. Si la huella no lo recoge, dos corridas dejan de ser
        comparables sin que nada avise.
        """
        # OJO: `Mx_00_CargaRutas` vive DOS VECES en sys.modules —importado a
        # secas y cualificado por paquete—, cada copia con sus propias
        # constantes. Es el mismo desdoblamiento que documenta
        # `redirigir_evidencia` y que una vez hizo que un informe de VaR citara
        # el manual del LaR. Hay que parchear la copia que LEE la huella, o el
        # test pasa por el motivo equivocado.
        import motor.Mx_00_CargaRutas as mx00
        from modulos.huella_prompts import huella_plantilla_prompts
        original = mx00.ROL_AGENTE
        try:
            base = huella_plantilla_prompts(forzar=True)
            mx00.ROL_AGENTE = original + "\nInstrucción añadida."
            nueva = huella_plantilla_prompts(forzar=True)
            assert nueva["plantilla"] != base["plantilla"], (
                "reescribir el rol del agente no cambia la huella: dos corridas "
                "con prompts distintos compartirían identificador")
            assert nueva["rol_agente"] != base["rol_agente"]
        finally:
            mx00.ROL_AGENTE = original
            huella_plantilla_prompts(forzar=True)

    def test_la_huella_no_depende_de_que_copia_del_modulo_se_lea(self):
        """
        `Mx_00_CargaRutas` existe dos veces en sys.modules. La huella se apoya
        SOBRE TODO en el hash de los FICHEROS, que es idéntico se lea por donde
        se lea: así el desdoblamiento no puede producir dos huellas distintas
        para el mismo código.
        """
        from modulos.huella_prompts import huella_plantilla_prompts, FICHEROS_PROMPT
        h = huella_plantilla_prompts(forzar=True)
        assert set(h["ficheros"]) == set(FICHEROS_PROMPT)
        assert all(v for v in h["ficheros"].values()), (
            "algún fichero de prompts no se pudo hashear")

    def test_el_orden_del_dict_no_altera_la_huella(self):
        """
        `INSTRUCCIONES_DIMENSION` es un dict: sin `sorted`, dos corridas
        idénticas podrían dar huellas distintas por el orden de inserción.
        """
        fuente = (RAIZ / "modulos" / "huella_prompts.py").read_text(encoding="utf-8")
        assert "sorted(INSTRUCCIONES_DIMENSION.items())" in fuente

    def test_no_se_guarda_el_texto_del_prompt(self):
        """
        El prompt lleva la evidencia ÍNTEGRA del modelo. Volcarlo al JSON lo
        convertiría en una copia del expediente, con su tamaño y su problema de
        confidencialidad. Solo el hash.
        """
        from modulos.huella_prompts import huella_plantilla_prompts
        h = huella_plantilla_prompts(forzar=True)
        for valor in h.values():
            texto = str(valor)
            assert len(texto) < 400, "la huella guarda texto, no solo hashes"

    def test_las_tres_rutas_de_evaluacion_registran_el_hash(self):
        """
        Ámbitos, controles CDD y revisión de código producen puntaje y pesan en
        el score: las tres deben poder responder «¿qué prompt produjo esto?».
        """
        for fichero, marca in (
            ("modulos/motor_ia.py", 'resultado["prompt_sha256"]'),
            ("modulos/motor_ia_v2.py", 'resultado["prompt_sha256"]'),
            ("modulos/revision_codigo.py", 'res["prompt_sha256"]'),
        ):
            fuente = (RAIZ / fichero).read_text(encoding="utf-8")
            assert marca in fuente, f"{fichero} no registra el hash del prompt"

    def test_la_huella_de_ejecucion_incluye_los_prompts(self):
        """
        Si la lógica de prompts no entra en la huella global, dos corridas con
        prompts distintos comparten identificador y la reproducibilidad que el
        informe declara es falsa.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert '"prompts":        _prompts_huella,' in vivas, (
            "la huella de ejecución dejó de cubrir la lógica de prompts")
        assert '"prompts":           _prompts_huella,' in vivas, (
            "agente_meta no publica la huella de prompts")

    def test_comparar_detecta_el_cambio_de_prompt_como_vara(self, tmp_path):
        """
        Reescribir un prompt cambia el puntaje con la misma evidencia y el mismo
        estándar. Es vara de medir, no mejora del modelo.
        """
        from modulos.custodia import sellar_y_escribir
        from modulos.comparador import comparar

        def inf(fecha, punt, plantilla):
            return {"modelo": "M", "tier": "1", "fecha": fecha,
                    "score_global": float(punt),
                    "scores_por_ambito": {"Metodología": float(punt)},
                    "resultados_por_ambito": {"Metodología": [
                        {"actividad": "A", "puntaje": punt, "observacion": ""}]},
                    "agente": {"agente_version": "27.1", "modelo_ia": "gpt-4o",
                               "proveedor_ia": "azure_openai",
                               "documentos_huella": {"d.pdf": {"sha256": "igual"}},
                               "estandar": {"sha256": "EST-V1"},
                               "prompts": {"plantilla": plantilla,
                                           "rol_agente": plantilla + "r",
                                           "instrucciones_ambito": "i"}}}

        sellar_y_escribir(inf("2026-04-15", 3, "PROMPT-V1"),
                          tmp_path / "resultados_M_2026-04-15.json", tmp_path, "M", {})
        sellar_y_escribir(inf("2026-07-30", 4, "PROMPT-V2"),
                          tmp_path / "resultados_M_2026-07-30.json", tmp_path, "M", {})

        c = comparar(tmp_path, "M")
        assert c.vara_cambiada is True, (
            "un cambio de prompt no se detecta como cambio de la vara de medir")
        assert c.cambio_prompts["plantilla_antes"] == "PROMPT-V1"
        assert "rol_agente" in c.cambio_prompts, "no señala QUÉ parte cambió"


# ══════════════════════════════════════════════════════════════════════════════
# [POLÍTICA 2026-07-30] Ni una llamada saliente que no sea a la API del proveedor
#
# La entidad solo admite hablar con Azure OpenAI (Anthropic como secundario).
# Eso cubre tres cosas que NO son obvias:
#
#   · modelos ejecutados en local (sentence-transformers, Tesseract);
#   · descargas implícitas — ChromaDB baja un ONNX MiniLM si le pides una
#     colección sin `embedding_function`;
#   · TELEMETRÍA. ChromaDB trae `anonymized_telemetry=True` de fábrica y envía
#     eventos de uso a PostHog. No es un modelo, pero es tráfico saliente no
#     declarado desde una herramienta que trata documentación interna de
#     modelos de riesgo.
# ══════════════════════════════════════════════════════════════════════════════
class TestNingunaLlamadaExterna:

    def test_ninguna_libreria_de_modelos_se_importa(self):
        import re
        patron = re.compile(
            r"^\s*(?:import|from)\s+"
            r"(?:sentence_transformers|transformers|torch|huggingface_hub|"
            r"pytesseract|pdf2image|easyocr|spacy|nltk|tensorflow|onnxruntime)\b",
            re.M)
        fugas = []
        for carpeta in ("modulos", "motor", "src", "config", "scripts"):
            for f in (RAIZ / carpeta).rglob("*.py"):
                if "__pycache__" in str(f):
                    continue
                vivas = "\n".join(l for l in f.read_text(encoding="utf-8").splitlines()
                                  if not l.lstrip().startswith("#"))
                if patron.search(vivas):
                    fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, f"librería de modelos externos importada: {fugas}"

    def test_ninguna_peticion_http_directa_fuera_del_cliente(self):
        """
        Solo `config/` habla con la red, y solo a través del SDK del proveedor.
        Un `requests.get` en un módulo de negocio sería un canal no auditado.
        """
        import re
        patron = re.compile(r"\b(?:requests\.(?:get|post)|urlopen|urllib\.request)\b")
        fugas = []
        for carpeta in ("modulos", "motor", "src"):
            for f in (RAIZ / carpeta).rglob("*.py"):
                if "__pycache__" in str(f):
                    continue
                vivas = "\n".join(l for l in f.read_text(encoding="utf-8").splitlines()
                                  if not l.lstrip().startswith("#"))
                if patron.search(vivas):
                    fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, f"petición HTTP fuera del cliente IA: {fugas}"

    def test_no_queda_ninguna_base_vectorial_que_silenciar(self):
        """
        [2026-07-31] Aquí se verificaba que la telemetría de ChromaDB estuviera
        desactivada: venía a True de fábrica y enviaba eventos de uso a PostHog,
        un host externo, desde una herramienta que trata documentación interna
        de modelos de riesgo.

        ChromaDB ya no está —el RAG es léxico— así que no hay telemetría que
        apagar. El test se conserva invertido, verificando que la dependencia no
        vuelve: si alguien reintrodujera ChromaDB, volvería con su PostHog y con
        `tokenizers → huggingface-hub` detrás, y este test es el que lo pilla
        antes de que llegue a un entorno con inspección TLS.
        """
        req = (RAIZ / "requirements.txt").read_text(encoding="utf-8")
        vivas = [l.split("#")[0].strip() for l in req.splitlines()]
        assert not any(l.lower().startswith("chromadb") for l in vivas if l), (
            "chromadb ha vuelto a requirements.txt: con él vuelven la telemetría "
            "a PostHog y la dependencia transitiva de huggingface-hub")

        import re as _re
        patron = _re.compile(r"^\s*(?:import|from)\s+chromadb\b", _re.M)
        fugas = []
        for carpeta in ("modulos", "motor", "src", "config", "scripts"):
            for f in (RAIZ / carpeta).rglob("*.py"):
                if "__pycache__" in str(f):
                    continue
                if patron.search(f.read_text(encoding="utf-8")):
                    fugas.append(str(f.relative_to(RAIZ)))
        assert not fugas, f"chromadb vuelve a importarse en: {fugas}"
    def test_ninguna_coleccion_se_abre_sin_funcion_de_embeddings(self):
        """
        `get_or_create_collection` SIN `embedding_function` hace que ChromaDB
        descargue y ejecute su ONNX MiniLM por defecto — un modelo externo que
        nadie pidió y que no aparece en requirements.txt.
        """
        import re
        fuente = (RAIZ / "src" / "rag" / "base_indexer.py").read_text(encoding="utf-8")
        for m in re.finditer(r"get_or_create_collection\((.*?)\)", fuente, re.S):
            assert "embedding_function" in m.group(1), (
                "colección abierta sin embedding_function: ChromaDB bajaría "
                "su modelo por defecto")

    def test_la_prohibicion_de_modelos_externos_viene_activada(self):
        """
        Una barrera que hay que acordarse de activar no es una barrera: es una
        sugerencia. Mismo criterio que puso el default de IA_PROVEEDOR en el
        código y no en el .env.
        """
        from config.parametros import PROHIBIR_MODELOS_EXTERNOS
        assert PROHIBIR_MODELOS_EXTERNOS is True

    def test_no_queda_ninguna_via_de_embeddings_que_bloquear(self):
        """
        [ARQUITECTURA 2026-07-31] Este test comprobaba que pedir embeddings
        locales fallara por política. Ya no hay nada que bloquear: el RAG dejó
        de usar vectores —no existe deployment de embeddings en el recurso
        Azure— y `config/embeddings.py` se eliminó junto con ChromaDB, que
        arrastraba huggingface-hub por dependencia transitiva.

        Se conserva invertido: donde antes se verificaba que la puerta estuviera
        cerrada, ahora se verifica que no haya puerta. Es más fuerte — una
        barrera de configuración protege de un descuido; que el código no exista
        protege de todo lo demás.
        """
        assert not (RAIZ / "config" / "embeddings.py").exists()
        from config import parametros
        assert not hasattr(parametros, "EMBEDDINGS_PROVEEDOR")
        assert not hasattr(parametros, "AZURE_EMBEDDINGS_DEPLOYMENT")


# ══════════════════════════════════════════════════════════════════════════════
# [CONTEXTO-FIX 2026-07-30] El presupuesto se llena, no se abandona
#
# Traza de una corrida real en banca:
#
#     Contexto saturado: 11.835 / 15.000 chars — 22 doc(s) omitidos
#
# 3.165 caracteres LIBRES y 22 documentos fuera. La causa era un `break`: en
# cuanto un documento no cabía, se descartaban TODOS los siguientes, incluidos
# los pequeños que sí habrían entrado.
#
# El daño es doble: el evaluador juzga el ámbito sin evidencia que cabía, y la
# cobertura declarada baja por un fallo del algoritmo, no por falta de sitio.
# ══════════════════════════════════════════════════════════════════════════════
class TestElContextoSeLlenaNoSeAbandona:

    @staticmethod
    def _simular(docs, maximo):
        """Reproduce la lógica de selección de agente.py."""
        acc, dentro, fuera = 0, [], 0
        for nombre, tam in sorted(docs, key=lambda x: x[1]):
            if acc + tam > maximo and dentro:
                fuera += 1
                continue
            dentro.append(nombre)
            acc += tam
        return acc, dentro, fuera

    def test_un_documento_grande_no_bloquea_a_los_siguientes(self):
        docs = ([(f"acumulado_{i}", 2958) for i in range(4)]      # 11.832
                + [("manual_grande", 9000)]                        # no cabe
                + [(f"pequeno_{i}", 300) for i in range(22)])
        acc, dentro, fuera = self._simular(docs, 15000)
        assert len(dentro) >= 20, (
            f"solo entraron {len(dentro)} documentos: el grande sigue "
            f"bloqueando a los pequeños")
        assert fuera <= 5

    def test_el_codigo_usa_continue_y_no_break(self):
        """
        El `break` es el bug. Fijarlo por inspección porque reproducir el
        pipeline entero para esto sería desproporcionado.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        ini = src.index("nombres_omitidos = []")
        fin = src.index("docs_omitidos_ctx = len(nombres_omitidos)", ini)
        vivas = "\n".join(l for l in src[ini:fin].splitlines()
                          if not l.lstrip().startswith("#"))
        assert "continue" in vivas, "volvió el break: se pierden documentos que caben"
        # `break` como SENTENCIA, no como palabra: la linea del continue
        # lleva un comentario en linea que dice «antes: break».
        import re as _re
        assert not _re.search(r"^\s*break\s*$", vivas, _re.M), (
            "volvio el break como sentencia")

    def test_se_ordena_por_tamano_para_maximizar_cuantos_caben(self):
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "_por_tamano = sorted(" in src, (
            "sin ordenar, entra el que llegó primero, no el que más aporta")

    def test_los_omitidos_se_nombran_no_solo_se_cuentan(self):
        """
        «22 doc(s) omitidos» no dice CUÁLES. Sin los nombres, el operador no
        puede decidir si lo omitido importaba.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "nombres_omitidos" in src
        assert "no cupieron" in src

    def test_los_omitidos_siguen_contando_como_cero_en_cobertura(self):
        """
        El invariante 4 no se relaja: lo que no entra al prompt cuenta 0%.
        Llenar mejor el presupuesto no puede convertirse en inflar la cifra.
        """
        src = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "cuentan como 0%" in src.lower() or "0% en la cobertura" in src


# ══════════════════════════════════════════════════════════════════════════════
# [RUIDO-FIX 2026-07-30] Los avisos de pdfminer enterraban los que importan
# ══════════════════════════════════════════════════════════════════════════════
class TestRuidoDePdfminer:

    def test_el_logger_de_pdfminer_se_silencia(self):
        """
        «Could not get FontBBox» aparece en PDFs perfectamente legibles: son
        fuentes sin metadatos de caja y NO afectan al texto. Inundaban la
        consola y enterraban los avisos de cobertura parcial y lectura fallida
        — un aviso relevante que nadie ve equivale a no haberlo emitido.
        """
        fuente = (RAIZ / "motor" / "Mx_01_LecturaEvidencias.py").read_text(
            encoding="utf-8")
        assert 'getLogger(_nombre).setLevel' in fuente
        assert '"pdfminer.pdffont"' in fuente

    def test_no_se_silencian_los_warnings_globales(self):
        """
        Apagar `warnings` en bloque taparía también avisos de otras librerías.
        Se silencia SOLO el logger de pdfminer.
        """
        fuente = (RAIZ / "motor" / "Mx_01_LecturaEvidencias.py").read_text(
            encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "warnings.filterwarnings" not in vivas
        assert "simplefilter" not in vivas

    def test_un_pdf_que_prohibe_extraccion_se_distingue_del_ruido(self):
        fuente = (RAIZ / "motor" / "Mx_01_LecturaEvidencias.py").read_text(
            encoding="utf-8")
        assert "NO permite extracción" in fuente, (
            "un PDF con extracción prohibida es evidencia perdida, no ruido")


class TestNingunRecorteEsSilencioso:
    """
    Un recorte que no se declara convierte la AUSENCIA en INCUMPLIMIENTO.

    `leer_txt_csv_log`, `leer_sql`, `leer_r` y la rama `.md` de
    `leer_archivo_generico` cortaban con un `[:MAX_CHARS_*]` mudo. El evaluador
    recibía el texto sin ninguna marca y no podía distinguir «el documento no
    documenta el backtesting» de «la mención estaba en el 62% que se cortó».

    Es la misma clase de fallo que la auditoría de 2026-07-26 corrigió en
    `leer_archivo`, pero en el pipeline por CONTROL.
    """

    def _mx01(self):
        import sys
        from pathlib import Path
        raiz = Path(__file__).resolve().parents[1]
        if str(raiz / "motor") not in sys.path:
            sys.path.insert(0, str(raiz / "motor"))
        import motor.Mx_01_LecturaEvidencias as M
        return M

    def test_un_md_largo_declara_su_recorte(self, tmp_path):
        M = self._mx01()
        p = tmp_path / "manual.md"
        p.write_text("X" * 40000, encoding="utf-8")
        texto = M.leer_archivo_generico(str(p))
        assert "DOCUMENTO TRUNCADO" in texto, "el .md se recorta en silencio"
        assert "manual.md" in texto and "40,000" in texto, (
            "la marca debe decir QUE documento y CUANTO falta")

    def test_la_marca_es_la_que_motor_ia_reconoce(self, tmp_path):
        # `motor_ia._fue_truncado_fc` busca literalmente "DOCUMENTO TRUNCADO".
        # Una marca propia (el viejo "... [truncado a N chars]" de leer_ipynb)
        # avisaba al humano y era invisible para el evaluador.
        M = self._mx01()
        p = tmp_path / "datos.txt"
        p.write_text("Y" * 40000, encoding="utf-8")
        assert "DOCUMENTO TRUNCADO" in M.leer_archivo_generico(str(p))

    def test_lo_que_cabe_no_se_toca(self, tmp_path):
        M = self._mx01()
        p = tmp_path / "corto.md"
        p.write_text("contenido breve", encoding="utf-8")
        assert M.leer_archivo_generico(str(p)) == "contenido breve"

    def test_ningun_lector_por_control_corta_sin_declararlo(self):
        # Fija la ausencia del patrón mudo, para que no reaparezca al añadir
        # un lector nuevo copiando el de al lado.
        import re
        from pathlib import Path
        fuente = (Path(__file__).resolve().parents[1] / "motor" /
                  "Mx_01_LecturaEvidencias.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        mudos = re.findall(r"\[:MAX_CHARS_(?:DOC|CODIGO)\]", vivas)
        assert not mudos, f"vuelve el recorte mudo: {len(mudos)} ocurrencia(s)"


class TestP01ASelladoSinFirmaEnControl:
    """
    P0.1-A: `--control` sella su corrida en la cadena, pero NO pide firma.

    `informes_de_modelo()` barre `resultados_*.json`, que es exactamente el
    patrón que escribe el pipeline por control. Sus corridas ya entraban en la
    cadena SIN sello, y bastaba una para que la verificación acusara a un
    entregable legítimo de haber sido manipulado.
    """

    def _cadena(self, tmp_path):
        from modulos import custodia
        d = tmp_path / "outputs"
        (d / "2026-07-30").mkdir(parents=True)
        return custodia, d

    def test_una_corrida_sin_sellar_rompia_la_cadena(self, tmp_path):
        # Fija el fallo ORIGINAL para que se vea qué se corrigió: un JSON con el
        # patrón de --control, sin bloque de custodia, parte la verificación.
        import json
        custodia, d = self._cadena(tmp_path)
        custodia.sellar_y_escribir(
            {"modelo": "LaR"}, d / "2026-07-30" / "resultados_LaR_A.json", d, "LaR")
        (d / "2026-07-30" / "resultados_LaR_ctrl.json").write_text(
            json.dumps({"modelo": "LaR"}), encoding="utf-8")
        custodia.sellar_y_escribir(
            {"modelo": "LaR"}, d / "2026-07-30" / "resultados_LaR_B.json", d, "LaR")
        assert custodia.verificar_cadena(d, "LaR")["integra"] is False

    def test_sellada_como_trabajo_la_cadena_se_sostiene(self, tmp_path):
        custodia, d = self._cadena(tmp_path)
        custodia.sellar_y_escribir(
            {"modelo": "LaR"}, d / "2026-07-30" / "resultados_LaR_A.json", d, "LaR")
        custodia.sellar_y_escribir(
            {"modelo": "LaR"}, d / "2026-07-30" / "resultados_LaR_ctrl.json", d,
            "LaR", tipo=custodia.TIPO_TRABAJO)
        custodia.sellar_y_escribir(
            {"modelo": "LaR"}, d / "2026-07-30" / "resultados_LaR_B.json", d, "LaR")
        res = custodia.verificar_cadena(d, "LaR")
        assert res["integra"] is True, res["eslabones"]
        tipos = [e["tipo_corrida"] for e in res["eslabones"]]
        assert tipos == [custodia.TIPO_ENTREGABLE, custodia.TIPO_TRABAJO,
                         custodia.TIPO_ENTREGABLE]

    def test_el_default_es_entregable(self, tmp_path):
        # Un sello sin `tipo` explícito debe seguir siendo entregable: el
        # pipeline completo no cambia de comportamiento.
        custodia, d = self._cadena(tmp_path)
        datos = custodia.sellar_y_escribir(
            {"modelo": "LaR"}, d / "2026-07-30" / "resultados_LaR_A.json", d, "LaR")[0]
        assert datos["custodia"]["tipo_corrida"] == custodia.TIPO_ENTREGABLE

    def test_los_informes_antiguos_se_leen_como_entregable(self, tmp_path):
        # Compatibilidad: los sellos anteriores a `tipo_corrida` eran todos
        # entregables, porque solo el pipeline completo sellaba.
        import json
        custodia, d = self._cadena(tmp_path)
        ruta = d / "2026-07-30" / "resultados_LaR_A.json"
        datos = custodia.sellar({"modelo": "LaR"}, d, "LaR")
        del datos["custodia"]["tipo_corrida"]
        datos["custodia"]["hash_este_informe"] = custodia.hash_contenido(datos)
        ruta.write_text(json.dumps(datos, ensure_ascii=False), encoding="utf-8")
        res = custodia.verificar_cadena(d, "LaR")
        assert res["eslabones"][0]["tipo_corrida"] == custodia.TIPO_ENTREGABLE

    def test_el_pipeline_por_control_no_pide_firma(self):
        # La decisión de P0.1-A: sellar SÍ, firmar NO. Firmar es un acto de
        # aprobación y --control no emite el entregable.
        from pathlib import Path
        fuente = (Path(__file__).resolve().parents[1] / "modulos" /
                  "motor_ia_v2.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "solicitar_identidad" not in vivas, (
            "--control no debe pedir firma del validador")
        assert "sellar_y_escribir" in vivas, "--control debe sellar su corrida"
        assert "TIPO_TRABAJO" in vivas, "debe sellarse como corrida de trabajo"

    def test_el_control_ya_no_escribe_el_json_a_pelo(self):
        # Sin esto, alguien puede reintroducir el `json.dump` suelto y volver a
        # dejar corridas sin sellar en la cadena.
        import re
        from pathlib import Path
        fuente = (Path(__file__).resolve().parents[1] / "modulos" /
                  "motor_ia_v2.py").read_text(encoding="utf-8")
        bloque = fuente[fuente.index("json_resultados = "):]
        bloque = bloque[:bloque.index("# Generar informe Word")]
        vivas = "\n".join(l for l in bloque.splitlines()
                          if not l.lstrip().startswith("#"))
        assert not re.search(r"json\.dump\(", vivas), (
            "vuelve la escritura sin sellar del JSON de controles")


class TestPoliticasProcedimiento20260812:
    """
    Cableado de §4.2 (ámbito < 2.5 impide aprobación) y §6 (crítico
    automático si score ≤ 2), confirmadas por la entidad el 2026-08-12.

    El cableado NO decide el dictamen —lo firma el validador (§1)—; solo
    declara las condiciones objetivas que el firmante debe atender.
    """

    def test_criticos_automaticos_incluye_frontera_exacta_de_2(self):
        # §6: «score ≤ 2». Un test con 1.5 no probaría la frontera; si alguien
        # cambiara ≤ por <, este test lo detectaría y el de 1.5 no.
        from modulos.motor_ia import aplicar_politicas_procedimiento
        res = aplicar_politicas_procedimiento({"Metodología": 2.0})
        assert "Metodología" in res["criticos_automaticos"]

    def test_veto_por_ambito_incluye_frontera_de_249(self):
        # §4.2: «< 2.5» estricto. Un 2.49 debe entrar; un 2.50 debe quedar
        # fuera para que el umbral tenga significado.
        from modulos.motor_ia import aplicar_politicas_procedimiento
        adentro = aplicar_politicas_procedimiento({"Documentación": 2.49})
        afuera  = aplicar_politicas_procedimiento({"Documentación": 2.50})
        assert "Documentación" in adentro["veto_por_ambito"]
        assert "Documentación" not in afuera["veto_por_ambito"]

    def test_sin_evidencia_entra_en_el_veto_por_ambito(self):
        # score 0.0 = SIN EVIDENCIA. La política no distingue causa: por
        # debajo del umbral es por debajo del umbral. El label del semáforo
        # ya explica la causa; duplicar la distinción sería ruido.
        from modulos.motor_ia import aplicar_politicas_procedimiento
        res = aplicar_politicas_procedimiento({"Gobierno": 0.0})
        assert "Gobierno" in res["veto_por_ambito"]
        assert "Gobierno" in res["criticos_automaticos"]

    def test_fallo_tecnico_se_ignora(self):
        # score None = fallo técnico del agente (§5). No es imputable al
        # validado y no aplica política del validado sobre él.
        from modulos.motor_ia import aplicar_politicas_procedimiento
        res = aplicar_politicas_procedimiento({"Gobierno": None})
        assert res["veto_por_ambito"] == []
        assert res["criticos_automaticos"] == []
        assert res["puede_aprobarse"] is True

    def test_puede_aprobarse_solo_si_no_hay_veto_ni_criticos(self):
        from modulos.motor_ia import aplicar_politicas_procedimiento
        ok = aplicar_politicas_procedimiento(
            {"A": 3.0, "B": 4.5, "C": 2.5})       # 2.5 no entra en veto
        malo = aplicar_politicas_procedimiento(
            {"A": 3.0, "B": 4.5, "C": 2.4})       # 2.4 sí entra
        assert ok["puede_aprobarse"] is True
        assert malo["puede_aprobarse"] is False

    def test_el_informe_md_declara_el_veto_cuando_aplica(self):
        # Regresión: si alguien desconectara la sección `_politicas` del
        # ensamblado del informe, el aviso desaparecería en silencio.
        from modulos.generador_markdown import generar_informe_md
        import tempfile, json, pathlib
        with tempfile.TemporaryDirectory() as td:
            destino = pathlib.Path(td) / "informe.md"
            generar_informe_md({
                "modelo": "M",
                "score_global": 3.2,
                "scores_por_ambito": {"Gobierno": 1.8, "Metodología": 4.0},
                "politicas_procedimiento": {
                    "criticos_automaticos": ["Gobierno"],
                    "veto_por_ambito":      ["Gobierno"],
                    "puede_aprobarse":      False,
                    "politicas_aplicadas":  ["§4.2", "§6"],
                },
            }, destino)
            txt = destino.read_text(encoding="utf-8")
        assert "§6" in txt and "§4.2" in txt, (
            "el informe MD no cita las secciones del procedimiento aplicadas")
        assert "Gobierno" in txt

    def test_el_informe_md_no_mete_ruido_cuando_no_aplica(self):
        # Corolario del prompt de continuidad: un aviso que salta sin motivo
        # se aprende a ignorar y con él los que sí importan.
        from modulos.generador_markdown import generar_informe_md
        import tempfile, pathlib
        with tempfile.TemporaryDirectory() as td:
            destino = pathlib.Path(td) / "informe.md"
            generar_informe_md({
                "modelo": "M",
                "score_global": 4.2,
                "scores_por_ambito": {"Metodología": 4.0, "Gobierno": 4.5},
                "politicas_procedimiento": {
                    "criticos_automaticos": [],
                    "veto_por_ambito":      [],
                    "puede_aprobarse":      True,
                    "politicas_aplicadas":  ["§4.2", "§6"],
                },
            }, destino)
            txt = destino.read_text(encoding="utf-8")
        assert "Políticas del procedimiento aplicadas" not in txt, (
            "sale un aviso de políticas cuando no hay veto ni críticos: "
            "ruido en el 90 % de los informes")

    def test_agente_pasa_las_politicas_al_json_y_al_word(self):
        # Regresión defensiva: sin este test, alguien puede reintroducir la
        # omisión de `politicas_procedimiento` en el payload o en la llamada
        # al Word y el aviso desaparece en producción sin señal.
        from pathlib import Path
        fuente = (Path(__file__).resolve().parents[1] / "agente.py"
                  ).read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "\"politicas_procedimiento\":" in vivas, (
            "el JSON de resultados ya no incluye las políticas del "
            "procedimiento: el borrador MD las lee de ahí")
        assert "politicas_procedimiento=_politicas" in vivas, (
            "el Word ya no recibe las políticas: el firmante podría alegar "
            "que el entregable no las mostraba")


class TestCuestionamientosExtensibles:
    """
    La web permite añadir cuestionamientos propios de la entidad y
    activar/desactivar los de fábrica. Este cableado no debe romper el
    flujo CLI cuando no hay ficheros de configuración, y debe respetar
    los tres invariantes:

      - defaults filtrados por `config/cuestionamientos_activos.json`,
      - personalizados sumados desde `config/cuestionamientos_personalizados.json`,
      - configuración inválida se descarta con aviso, nunca en silencio.
    """

    def _mod(self):
        # Import perezoso: el módulo activa un sys.path.insert que solo
        # queremos si el test lo necesita.
        from modulos import cuestionamientos_ext
        return cuestionamientos_ext

    def test_sin_ficheros_devuelve_el_catalogo_por_defecto_completo(self, tmp_path,
                                                                     monkeypatch):
        ext = self._mod()
        monkeypatch.setattr(ext, "ACT_PATH",  tmp_path / "no_existe_act.json")
        monkeypatch.setattr(ext, "PERS_PATH", tmp_path / "no_existe_pers.json")
        cat, avisos = ext.catalogo_activo()
        assert avisos == [], f"avisos inesperados: {avisos}"
        assert set(cat) == set(ext.CUESTIONAMIENTOS_METODOLOGICOS), (
            "la CLI sin ficheros de config debería ver el catálogo íntegro")

    def test_desactivar_uno_lo_elimina_del_catalogo(self, tmp_path, monkeypatch):
        ext = self._mod()
        import json
        objetivo = next(iter(ext.CUESTIONAMIENTOS_METODOLOGICOS))
        act = tmp_path / "act.json"
        act.write_text(json.dumps({objetivo: False}), encoding="utf-8")
        monkeypatch.setattr(ext, "ACT_PATH",  act)
        monkeypatch.setattr(ext, "PERS_PATH", tmp_path / "no_existe_pers.json")
        cat, _ = ext.catalogo_activo()
        assert objetivo not in cat, (
            f"el flag activo=False no eliminó {objetivo!r} del catálogo")

    def test_personalizado_valido_se_suma_con_origen_marcado(self, tmp_path,
                                                              monkeypatch):
        ext = self._mod()
        import json
        pers = tmp_path / "pers.json"
        pers.write_text(json.dumps([{
            "id": "sin_cross_val", "tipo": "ausencia",
            "patron": "cross_val|k.?fold", "mensaje": "Falta CV",
            "severidad": "ALTA",
        }]), encoding="utf-8")
        monkeypatch.setattr(ext, "ACT_PATH",  tmp_path / "no_existe_act.json")
        monkeypatch.setattr(ext, "PERS_PATH", pers)
        cat, avisos = ext.catalogo_activo()
        assert "sin_cross_val" in cat
        assert cat["sin_cross_val"]["origen"] == "personalizado", (
            "el `origen` distingue defaults de personalizados en el informe")
        assert avisos == []

    def test_regex_invalido_se_descarta_con_aviso(self, tmp_path, monkeypatch):
        ext = self._mod()
        import json
        pers = tmp_path / "pers.json"
        pers.write_text(json.dumps([{
            "id": "malo", "tipo": "ausencia", "patron": "(no_cierra",
            "mensaje": "x", "severidad": "BAJA",
        }]), encoding="utf-8")
        monkeypatch.setattr(ext, "ACT_PATH",  tmp_path / "no_existe_act.json")
        monkeypatch.setattr(ext, "PERS_PATH", pers)
        cat, avisos = ext.catalogo_activo()
        assert "malo" not in cat, (
            "un patrón que no compila NUNCA debe llegar al motor: "
            "explotaría en el análisis de todos los ficheros")
        assert any("regex" in a.lower() for a in avisos), (
            "la razón del descarte debe viajar como aviso, no silenciarse")

    def test_personalizado_no_puede_pisar_un_default(self, tmp_path, monkeypatch):
        ext = self._mod()
        import json
        default_id = next(iter(ext.CUESTIONAMIENTOS_METODOLOGICOS))
        pers = tmp_path / "pers.json"
        pers.write_text(json.dumps([{
            "id": default_id, "tipo": "presencia", "patron": "x",
            "mensaje": "impostor", "severidad": "ALTA",
        }]), encoding="utf-8")
        monkeypatch.setattr(ext, "ACT_PATH",  tmp_path / "no_existe_act.json")
        monkeypatch.setattr(ext, "PERS_PATH", pers)
        cat, avisos = ext.catalogo_activo()
        assert cat[default_id]["origen"] == "default", (
            "el default debe prevalecer sobre un personalizado con el mismo id")
        assert any("colisiona" in a.lower() for a in avisos)

    def test_mx04_usa_el_catalogo_extendido(self):
        # Regresión: si alguien reintroduce `for k,v in
        # CUESTIONAMIENTOS_METODOLOGICOS.items()` en Mx_04, los personalizados
        # dejarían de aplicarse sin que ningún test lo detecte.
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "motor"
               / "Mx_04_MotorControlesData.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "_catalogo_para_deteccion" in vivas, (
            "Mx_04 dejó de fusionar el catálogo con los personalizados")
        assert "CUESTIONAMIENTOS_METODOLOGICOS.items()" not in vivas, (
            "Mx_04 volvió a iterar el catálogo fijo — se pierden los "
            "personalizados de la web")

    def test_instrucciones_sesion_leer_ausente_es_lista_vacia(self, tmp_path):
        """
        `modulos.instrucciones_sesion.leer` debe devolver `[]` cuando no hay
        skills.json ni cuestionamientos.json en la raíz. Esto garantiza que
        el pipeline clásico (`agente.py` sin --raiz-evidencia web) NO cambia
        su prompt.
        """
        from modulos.instrucciones_sesion import leer
        assert leer(tmp_path) == []

    def test_instrucciones_sesion_mezcla_skills_y_cuestionamientos_nl(self, tmp_path):
        import json
        from modulos.instrucciones_sesion import leer
        (tmp_path / "skills.json").write_text(json.dumps({
            "custom": [{"id": "custom_001", "descripcion": "Var negativa"}],
        }), encoding="utf-8")
        (tmp_path / "cuestionamientos.json").write_text(json.dumps({
            "custom": [{"id": "cuest_custom_001", "descripcion": "Maturity entero"}],
        }), encoding="utf-8")
        salida = leer(tmp_path)
        assert len(salida) == 2
        assert salida[0].startswith("INSTRUCCIÓN ADICIONAL DEL VALIDADOR")
        assert salida[1].startswith("CUESTIONAMIENTO ADICIONAL DEL VALIDADOR")

    def test_evaluar_actividad_inyecta_instrucciones_extra_al_prompt(self):
        """
        Regresión del cableado web→motor: si se pasa `instrucciones_extra`
        a `evaluar_actividad`, el prompt final incluye el bloque etiquetado
        y las instrucciones textuales. Sin ellas, el prompt NO cambia.
        """
        from unittest.mock import patch
        capturado = {}
        def _fake(prompt, **kw):
            capturado["prompt"] = prompt
            return ('{"puntaje": 3, "concepto": "x", "observacion": "y", '
                    '"recomendacion": "z", "preguntas_pendientes": [], '
                    '"evidencia_encontrada": "e"}')
        # `motor_ia` importa `_llamar_modelo` como símbolo local en su top-
        # level (`from Mx_03_LlamarIA import _llamar_modelo`). Patchear el
        # origen no llega a `motor_ia`: hay que patchear la copia local, o
        # el prompt real se envía al proveedor y el test falla — o pasa por
        # azar si un test anterior dejó otro patch activo.
        from modulos import motor_ia as _mia
        with patch.object(_mia, "_llamar_modelo", side_effect=_fake):
            _mia.evaluar_actividad(
                actividad="Test", ambito="Metodología", control="C",
                contexto="ctx", titulo_modelo="M", modo_preprdc=False,
                instrucciones_extra=[
                    "INSTRUCCIÓN ADICIONAL DEL VALIDADOR: X",
                    "CUESTIONAMIENTO ADICIONAL DEL VALIDADOR: Y",
                ],
            )
            p = capturado["prompt"]
            assert "INSTRUCCIONES ADICIONALES DEL VALIDADOR (sesión web)" in p
            assert "INSTRUCCIÓN ADICIONAL DEL VALIDADOR: X" in p
            assert "CUESTIONAMIENTO ADICIONAL DEL VALIDADOR: Y" in p
            capturado.clear()
            _mia.evaluar_actividad(
                actividad="Test", ambito="Metodología", control="C",
                contexto="ctx", titulo_modelo="M", modo_preprdc=False,
            )
            assert "INSTRUCCIONES ADICIONALES DEL VALIDADOR (sesión web)" \
                   not in capturado["prompt"], (
                "sin `instrucciones_extra` el bloque debe estar ausente — "
                "de lo contrario el pipeline clásico cambia sin motivo")

    def test_agente_lee_instrucciones_de_la_raiz_de_sesion(self):
        """
        Grep AST: `agente.py` DEBE importar `leer` de `instrucciones_sesion`
        y pasar `instrucciones_extra=_instrucciones_sesion` al llamar a
        `evaluar_ambito_completo`. Si alguien retira el cableado la
        integración web→motor deja de funcionar en silencio.
        """
        from pathlib import Path
        src = (Path(__file__).resolve().parents[1] / "agente.py"
               ).read_text(encoding="utf-8")
        vivas = "\n".join(l for l in src.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "from modulos.instrucciones_sesion import leer" in vivas, (
            "agente.py dejó de leer las instrucciones NL de la sesión web")
        assert "instrucciones_extra = _instrucciones_sesion" in vivas, (
            "el llamado a evaluar_ambito_completo ya no propaga las "
            "instrucciones extra: se pierden en el prompt")

    def test_deteccion_end_to_end_con_personalizado(self, tmp_path, monkeypatch):
        ext = self._mod()
        import json
        pers = tmp_path / "pers.json"
        pers.write_text(json.dumps([{
            "id": "usa_scaler", "tipo": "presencia",
            "patron": "StandardScaler", "mensaje": "Se usa StandardScaler",
            "severidad": "MEDIA",
        }]), encoding="utf-8")
        monkeypatch.setattr(ext, "ACT_PATH",  tmp_path / "no_existe_act.json")
        monkeypatch.setattr(ext, "PERS_PATH", pers)
        from Mx_04_MotorControlesData import detectar_cuestionamientos
        r = detectar_cuestionamientos([{
            "nombre": "modelo.py", "tipo": "PY",
            "contenido": "from sklearn.preprocessing import StandardScaler\n"
                         "X = StandardScaler().fit_transform(x)",
        }])
        alertas = r["modelo.py"]["alertas_rapidas"]
        assert any(a["clave"] == "usa_scaler" for a in alertas), (
            "el patrón personalizado no llegó al detector de código real")
