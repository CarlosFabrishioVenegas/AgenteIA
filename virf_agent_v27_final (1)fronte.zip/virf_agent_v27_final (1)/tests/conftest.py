"""
tests/conftest.py
═══════════════════════════════════════════════════════════════════════════════
Aislamiento del estado mutable del proyecto durante los tests.

[AUDIT-FIX PENDIENTE-1 · defecto introducido y corregido en la misma sesión]

Qué pasó
────────
Al añadirse el registro append-only de emisiones, `custodia.sellar_y_escribir()`
pasó a anotar cada informe sellado en `audit_logs/registro_emisiones.jsonl`. Los
tests que ya existían sellaban informes contra `tmp_path` —correctamente
aislados en cuanto a `outputs/`— pero el registro tiene una ruta por DEFECTO que
apunta al proyecto real. Resultado medido tras dos pasadas de la suite:

    $ wc -l audit_logs/registro_emisiones.jsonl
    59        ← 58 de tests, 1 de la única emisión real

El daño no es el fichero sucio: es que el registro de emisiones es EVIDENCIA
REGULATORIA. Un auditor que lo abra ve 58 emisiones de modelos llamados «M» y
«LaR_A» que nunca existieron, y a partir de ahí ninguna línea del fichero
prueba nada. Un control de integridad contaminado es peor que no tenerlo,
porque se presenta como prueba.

Es exactamente el defecto del §3.7 del prompt de continuidad —«tests que
dependen del estado mutable del proyecto»— pero en su versión inversa: aquí el
test no leía el estado real, lo ESCRIBÍA.

Por qué se corrige aquí y no en el código de producción
───────────────────────────────────────────────────────
La tentación es que `registrar_emision()` detecte que corre bajo pytest y no
escriba. Se descarta: sería una heurística silenciosa dentro de un control de
cumplimiento, y el día que la detección fallara —o que alguien ejecutara el
agente desde un proceso que la disparase por accidente— el registro dejaría de
anotar emisiones REALES sin que nada avisara. Un control que se apaga solo bajo
condiciones que nadie declara es justo lo que este proyecto no admite.

La corrección va en el arnés de test, que es donde está el problema: un fixture
`autouse` redirige el registro a `tmp_path` para TODOS los tests, los actuales y
los que se escriban después. Ninguno tiene que acordarse de aislarlo.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))


@pytest.fixture(autouse=True)
def _registro_emisiones_aislado(tmp_path, monkeypatch):
    """
    Redirige el registro de emisiones a `tmp_path` durante cada test.

    `autouse=True` y sin opción de desactivarlo: que un test pueda escribir en
    la evidencia regulatoria del proyecto no es una capacidad que convenga
    ofrecer. Los tests que necesitan inspeccionar el registro le pasan su propia
    ruta a `verificar_emisiones(..., ruta_registro=...)`, que es explícito.
    """
    try:
        from modulos import registro_emisiones
    except ImportError:                                    # pragma: no cover
        return
    monkeypatch.setattr(
        registro_emisiones, "RUTA_REGISTRO",
        tmp_path / "audit_logs_test" / "registro_emisiones.jsonl")
