"""
tests/test_pendientes_auditoria.py
═══════════════════════════════════════════════════════════════════════════════
Tests de los pendientes de auditoría externa (SBS / Big4).

Cada clase fija un control que un auditor va a exigir ver, y cada test está
escrito para FALLAR si el defecto correspondiente vuelve. No comprueban que el
código «funcione»: comprueban que el hueco concreto que se cerró sigue cerrado.

Convenciones heredadas del proyecto y respetadas aquí:

  · [§3.7] Ningún test toca el estado real del proyecto. Todo va contra
    `tmp_path` + `monkeypatch`; un test que leyera `audit_logs/` o
    `feedback/historial_feedback.json` reales empezaría a fallar en cuanto
    alguien ejecutara el agente.
  · [§3.8] Cuando se verifica una propiedad del CÓDIGO se usa AST, no búsqueda
    de texto: los comentarios que explican un fix contienen las mismas palabras
    que el fix, y un test por texto pasa aunque el código haga lo contrario de
    lo que su comentario dice.
"""

from __future__ import annotations

import ast
import json
import shutil
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))
sys.path.insert(0, str(RAIZ / "motor"))


# ═════════════════════════════════════════════════════════════════════════════
# PENDIENTE 1 · REGISTRO APPEND-ONLY DE EMISIONES
#
# La cadena de custodia era DETECTIVA: verifica los informes que existen. Al
# borrar `outputs/` no quedaba nada que verificar, y el sistema no distinguía
# «se borró la evidencia» de «nunca se validó» — las dos salidas eran el mismo
# mensaje tranquilizador. Estos tests fijan el control preventivo.
# ═════════════════════════════════════════════════════════════════════════════

class TestRegistroEmisiones:

    @staticmethod
    def _emitir(outputs, registro, modelo, payload=None):
        """
        Sella y escribe un informe con el registro apuntando a `tmp_path`.

        Se pasa `ruta_registro` por parámetro en vez de parchear la constante
        del módulo porque `custodia.sellar_y_escribir()` importa la función
        dentro del cuerpo: parchear `RUTA_REGISTRO` funcionaría, pero deja el
        test dependiendo del ORDEN de importación, que es frágil. Se parchea la
        constante en el único sitio donde se lee.
        """
        from modulos import custodia, registro_emisiones

        _orig = registro_emisiones.RUTA_REGISTRO
        registro_emisiones.RUTA_REGISTRO = Path(registro)
        try:
            datos = dict(payload or {"score_global": 3.4})
            datos.setdefault("modelo", modelo)
            ruta = Path(outputs) / f"resultados_{modelo}_2026-08-03.json"
            datos, _arch = custodia.sellar_y_escribir(
                datos, ruta, outputs, modelo)
            return datos, ruta
        finally:
            registro_emisiones.RUTA_REGISTRO = _orig

    # ── El criterio de aceptación central ────────────────────────────────────

    def test_informe_borrado_se_detecta_como_ausente(self, tmp_path):
        """
        EL defecto de PENDIENTE 1. Antes de esto, borrar el informe lo hacía
        invisible: `--verificar-cadena` respondía «No hay informes para este
        modelo», que es literalmente la misma salida que para un modelo que
        nunca se validó.
        """
        from modulos.registro_emisiones import verificar_emisiones
        outputs = tmp_path / "outputs"
        outputs.mkdir()
        registro = tmp_path / "audit_logs" / "registro_emisiones.jsonl"

        _datos, ruta = self._emitir(outputs, registro, "LaR")

        res = verificar_emisiones(outputs, "LaR", ruta_registro=registro)
        assert res["integra"] is True
        assert [e["estado"] for e in res["emisiones"]] == ["PRESENTE"]

        # ── Alguien borra el informe ─────────────────────────────────────────
        ruta.unlink()

        res = verificar_emisiones(outputs, "LaR", ruta_registro=registro)
        assert res["integra"] is False, (
            "borrar un informe emitido pasó desapercibido: es exactamente el "
            "hueco que PENDIENTE 1 cierra")
        assert [e["estado"] for e in res["emisiones"]] == ["AUSENTE"]
        # Y sigue constando que se emitió: no es «nunca se validó».
        assert res["n_registradas"] == 1

    def test_borrar_outputs_entero_no_borra_la_prueba(self, tmp_path):
        """El registro vive FUERA de outputs/: un `rm -rf outputs/` no lo alcanza."""
        from modulos.registro_emisiones import verificar_emisiones
        outputs = tmp_path / "outputs"
        outputs.mkdir()
        registro = tmp_path / "audit_logs" / "registro_emisiones.jsonl"
        self._emitir(outputs, registro, "VaR")

        shutil.rmtree(outputs)

        assert registro.exists(), (
            "el registro estaba dentro de outputs/: se borra junto con su objeto")
        res = verificar_emisiones(outputs, "VaR", ruta_registro=registro)
        assert res["integra"] is False
        assert res["emisiones"][0]["estado"] == "AUSENTE"

    # ── Append-only ──────────────────────────────────────────────────────────

    def test_el_registro_solo_crece(self, tmp_path):
        from modulos.registro_emisiones import leer_registro
        outputs = tmp_path / "outputs"
        outputs.mkdir()
        registro = tmp_path / "audit_logs" / "registro_emisiones.jsonl"

        self._emitir(outputs, registro, "LaR")
        primera = registro.read_text(encoding="utf-8")
        assert len(leer_registro(registro)) == 1

        self._emitir(outputs, registro, "LaR")
        segunda = registro.read_text(encoding="utf-8")

        assert segunda.startswith(primera), (
            "lo ya escrito cambió: el registro se está reescribiendo, no ampliando")
        assert len(leer_registro(registro)) == 2

    def test_registro_nunca_abre_en_modo_escritura(self):
        """
        [§3.8] Por AST y no por texto: buscar la cadena `"w"` coincidiría con
        los propios comentarios que explican por qué NO se usa, y el test
        pasaría aunque el código hiciera lo contrario de lo que documenta.
        """
        fuente = (RAIZ / "modulos" / "registro_emisiones.py").read_text(
            encoding="utf-8")
        malos = []
        for nodo in ast.walk(ast.parse(fuente)):
            if not isinstance(nodo, ast.Call):
                continue
            nombre = (getattr(nodo.func, "id", None)
                      or getattr(nodo.func, "attr", None))
            if nombre in ("write_text", "_escribir_json_atomico"):
                malos.append(
                    f"{nombre}() en línea {nodo.lineno} reescribe el fichero entero")
                continue
            if nombre != "open":
                continue
            modos = [a.value for a in nodo.args[1:2] if isinstance(a, ast.Constant)]
            modos += [k.value.value for k in nodo.keywords
                      if k.arg == "mode" and isinstance(k.value, ast.Constant)]
            if not modos:
                malos.append(f"open() sin modo explícito en línea {nodo.lineno} "
                             f"(por defecto es lectura, pero no debe ambigüarse)")
            for m in modos:
                if "a" not in str(m) and "r" not in str(m):
                    malos.append(f"open(..., {m!r}) en línea {nodo.lineno}")
        assert not malos, (
            "el registro de emisiones dejó de ser append-only: " + "; ".join(malos))

    # ── El renombrado de `preservar_si_existe` NO es una ausencia ────────────

    def test_informe_archivado_sigue_contando_como_presente(self, tmp_path):
        """
        Falso positivo que una implementación por RUTA habría producido: al
        re-ejecutar el mismo modelo el mismo día, `preservar_si_existe()`
        renombra el informe previo a `..__<hash12>.json`. Sigue estando, y
        reportarlo como AUSENTE sería acusar de pérdida de evidencia al caso
        más habitual del proyecto — la misma familia de daño que el falso
        «cadena ROTA» que documenta `custodia.informes_de_modelo()`.
        """
        from modulos.registro_emisiones import verificar_emisiones
        outputs = tmp_path / "outputs"
        outputs.mkdir()
        registro = tmp_path / "audit_logs" / "registro_emisiones.jsonl"

        self._emitir(outputs, registro, "LaR",
                     payload={"modelo": "LaR", "score_global": 1.0})
        self._emitir(outputs, registro, "LaR",
                     payload={"modelo": "LaR", "score_global": 2.0})

        res = verificar_emisiones(outputs, "LaR", ruta_registro=registro)
        assert res["n_registradas"] == 2
        assert res["integra"] is True, (
            "re-ejecutar el mismo modelo el mismo día se reportó como pérdida "
            "de un informe")
        # El archivado se informa como rastro, no como problema.
        assert any("archivado como" in (e.get("detalle") or "")
                   for e in res["emisiones"])

    # ── Alteración ───────────────────────────────────────────────────────────

    def test_informe_editado_se_detecta_como_alterado(self, tmp_path):
        from modulos.custodia import hash_contenido
        from modulos.registro_emisiones import verificar_emisiones
        outputs = tmp_path / "outputs"
        outputs.mkdir()
        registro = tmp_path / "audit_logs" / "registro_emisiones.jsonl"
        _datos, ruta = self._emitir(outputs, registro, "LaR")

        # Se edita el score Y se recoherentiza su hash declarado, de modo que el
        # informe es internamente consistente: solo el hash guardado FUERA de
        # outputs/ puede delatarlo. Ahí está el valor de sacarlo del directorio.
        d = json.loads(ruta.read_text(encoding="utf-8"))
        d["score_global"] = 5.0
        d["custodia"]["hash_este_informe"] = hash_contenido(d)
        ruta.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")

        res = verificar_emisiones(outputs, "LaR", ruta_registro=registro)
        assert res["integra"] is False
        assert res["emisiones"][0]["estado"] == "ALTERADO", (
            "un informe recoherentizado pasó la verificación")

    def test_registro_corrupto_no_se_descarta_en_silencio(self, tmp_path):
        """
        Una línea ilegible es una emisión que no se puede contrastar. Saltarla
        convertiría una corrupción del registro en una ausencia invisible, que
        es el defecto original con otro disfraz.
        """
        from modulos.registro_emisiones import verificar_emisiones
        outputs = tmp_path / "outputs"
        outputs.mkdir()
        registro = tmp_path / "audit_logs" / "registro_emisiones.jsonl"
        self._emitir(outputs, registro, "LaR")
        with open(registro, "a", encoding="utf-8") as f:
            f.write("{esto no es json\n")

        res = verificar_emisiones(outputs, "LaR", ruta_registro=registro)
        assert res["lineas_ilegibles"] == 1
        assert res["integra"] is False

    # ── Firmante ─────────────────────────────────────────────────────────────

    def test_la_emision_registra_quien_firma(self, tmp_path):
        from modulos.registro_emisiones import SIN_FIRMANTE, leer_registro
        outputs = tmp_path / "outputs"
        outputs.mkdir()
        registro = tmp_path / "audit_logs" / "registro_emisiones.jsonl"

        self._emitir(outputs, registro, "LaR", payload={
            "modelo": "LaR",
            "validacion_humana": {"validador": "Ana Pérez",
                                  "cargo": "Validador de Segunda Línea"},
        })
        self._emitir(outputs, registro, "LaR", payload={"modelo": "LaR"})

        entradas = leer_registro(registro)
        assert entradas[0]["validador"] == "Ana Pérez"
        assert entradas[0]["cargo"] == "Validador de Segunda Línea"
        # Sin firma no se inventa una: se declara la ausencia (§7 del prompt).
        assert entradas[1]["validador"] == SIN_FIRMANTE

    # ── El punto único de registro ───────────────────────────────────────────

    def test_ambas_ramas_de_sellar_y_escribir_registran(self):
        """
        [§3.1] El patrón que ha fallado cinco veces en este proyecto: una
        función con dos caminos, se corrige uno, y el olvidado es el que se
        ejecuta. `sellar_y_escribir()` tiene rama con lock y rama degradada, y
        la degradada corre justo cuando algo va mal — que es cuando más importa
        que quede constancia. Ninguna puede tener un `return` propio que se
        salte el registro.
        """
        fuente = (RAIZ / "modulos" / "custodia.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef)
                  and n.name == "sellar_y_escribir")
        retornos = [n for n in ast.walk(fn) if isinstance(n, ast.Return)]
        assert len(retornos) == 1, (
            f"{len(retornos)} `return` en sellar_y_escribir(): alguna rama "
            f"puede salir sin anotar la emisión en el registro")
        llamadas = [(getattr(n.func, "id", None) or getattr(n.func, "attr", None))
                    for n in ast.walk(fn) if isinstance(n, ast.Call)]
        assert "registrar_emision" in llamadas, (
            "sellar_y_escribir() dejó de registrar la emisión")

    def test_flag_verificar_emisiones_disponible(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert '"--verificar-emisiones"' in fuente

    def test_el_registro_se_versiona(self):
        """
        Decisión documentada en `.gitignore`: el registro SÍ se versiona. Con la
        forma `audit_logs/` (directorio) git no desciende y la negación no se
        evalúa nunca — el fichero quedaría sin versionar creyendo lo contrario.
        """
        gi = (RAIZ / ".gitignore").read_text(encoding="utf-8")
        vivas = [l.strip() for l in gi.splitlines()
                 if l.strip() and not l.strip().startswith("#")]
        assert "!audit_logs/registro_emisiones.jsonl" in vivas
        assert "audit_logs/" not in vivas, (
            "`audit_logs/` ignora el directorio entero: git no desciende y la "
            "excepción del registro no llega a evaluarse. Debe ser `audit_logs/*`")
        assert "audit_logs/*" in vivas

    def test_la_suite_no_escribe_en_el_registro_real(self):
        """
        [§3.7 · defecto introducido al implementar PENDIENTE-1]

        Al sellar desde un test, `sellar_y_escribir()` anotaba la emisión en el
        registro REAL del proyecto: dos pasadas de la suite dejaron 58 emisiones
        ficticias de modelos «M» y «LaR_A» junto a la única real. El registro es
        evidencia regulatoria; contaminado, deja de probar nada.

        Este test sella un informe SIN pasar ruta de registro —igual que hacen
        los tests de custodia— y comprueba que el fichero real no crece. Lo
        garantiza el fixture autouse de `tests/conftest.py`; si alguien lo
        retira, esto falla.
        """
        from modulos import custodia, registro_emisiones
        real = Path(RAIZ) / "audit_logs" / "registro_emisiones.jsonl"
        antes = real.read_text(encoding="utf-8") if real.exists() else ""

        import tempfile
        with tempfile.TemporaryDirectory() as td:
            custodia.sellar_y_escribir(
                {"modelo": "ModeloFicticioDeTest"},
                Path(td) / "resultados_ModeloFicticioDeTest.json",
                Path(td), "ModeloFicticioDeTest")

        # El registro efectivo debe ser el redirigido, no el del proyecto.
        assert Path(registro_emisiones.RUTA_REGISTRO) != real, (
            "el fixture de aislamiento de conftest.py no está activo")
        despues = real.read_text(encoding="utf-8") if real.exists() else ""
        assert despues == antes, (
            "la suite escribió en audit_logs/registro_emisiones.jsonl: la "
            "evidencia regulatoria del proyecto se está contaminando con "
            "emisiones que nunca existieron")


# ═════════════════════════════════════════════════════════════════════════════
# PENDIENTE 2 · AUTORÍA DE LAS CORRECCIONES DEL FEEDBACK
#
# `feedback/historial_feedback.json` guardaba QUÉ se corrigió pero no QUIÉN. El
# anexo del Word decía «el validador ajustó 2 puntajes» sin poder acreditar cuál
# de los 2-5 validadores del equipo — y ese anexo ES la evidencia de supervisión
# humana que el auditor viene a ver.
# ═════════════════════════════════════════════════════════════════════════════

class TestAutoriaFeedback:

    #: Historial MIXTO, que es el caso real: registros antiguos sin autor
    #: —meses de calibración que no se pueden descartar— junto a los firmados.
    HIST_MIXTO = [
        # Anteriores a PENDIENTE-2: sin la clave `validador`.
        {"titulo_modelo": "LaR", "fecha": "01/07/2026 10:00",
         "ambito": "Metodología", "actividad": "a1", "puntaje_agente": 2,
         "puntaje_correcto": 4, "diferencia": 2,
         "comentario": "faltaba backtesting"},
        # Clave PRESENTE pero NULA: el caso que rompe `.get(k, respaldo)` (§3.4).
        {"titulo_modelo": "LaR", "fecha": "01/07/2026 10:05", "ambito": "Datos",
         "actividad": "a2", "puntaje_agente": 3, "puntaje_correcto": 2,
         "diferencia": -1, "comentario": "linaje incompleto", "validador": None},
        # Firmados, en una sesión posterior.
        {"titulo_modelo": "LaR", "fecha": "02/07/2026 09:00",
         "ambito": "Gobierno", "actividad": "a3", "puntaje_agente": 1,
         "puntaje_correcto": 3, "diferencia": 2, "comentario": "el acta existe",
         "validador": "Ana Pérez", "cargo": "Validador de Segunda Línea"},
        {"titulo_modelo": "LaR", "fecha": "02/07/2026 09:10", "ambito": "Uso",
         "actividad": "a4", "puntaje_agente": 4, "puntaje_correcto": 5,
         "diferencia": 1, "comentario": "sí se usa en comité",
         "validador": "Luis Gómez", "cargo": "Jefe de Validación"},
    ]

    def test_registros_antiguos_no_se_descartan(self):
        """
        Criterio de aceptación explícito: son meses de calibración y siguen
        contando para el ajuste anti-sesgo. Lo que NO se hace es inventarles
        un autor.
        """
        from modulos.feedback import SIN_AUTOR, autor_de
        assert autor_de(self.HIST_MIXTO[0]) == SIN_AUTOR
        assert autor_de(self.HIST_MIXTO[2]) == "Ana Pérez"

    def test_validador_nulo_no_rompe_la_lectura(self):
        """
        [§3.4] `reg.get("validador", SIN_AUTOR)` devolvería None aquí, porque el
        segundo argumento de `.get` solo actúa si la clave FALTA, no si está
        presente con valor nulo. Ese defecto ya se ha producido dos veces en
        este proyecto.
        """
        from modulos.feedback import SIN_AUTOR, autor_de
        assert autor_de(self.HIST_MIXTO[1]) == SIN_AUTOR

    def test_el_anexo_dice_quien_hizo_cada_correccion(self):
        from modulos.override_humano import resumen_override
        res = resumen_override("LaR", 10, self.HIST_MIXTO)
        autores = {c["autor"] for c in res["correcciones"]}
        # El último ciclo es el del 02/07: dos correcciones, dos firmantes.
        assert autores == {"Ana Pérez", "Luis Gómez"}, (
            "el anexo no puede acreditar quién corrigió qué")
        assert res["autores"] == ["Ana Pérez", "Luis Gómez"]

    def test_calidad_proceso_ya_no_aproxima_por_modelo(self):
        """
        Antes se imputaban a quien firmó el informe TODAS las correcciones del
        modelo. Con dos validadores alternándose sobre el mismo modelo, quien
        revisa a fondo heredaba las del otro. Ahora se cuentan por firma real.
        """
        from modulos.override_humano import calidad_proceso
        registro = [{"validador": "Ana Pérez", "modelo": "LaR"}]
        res = calidad_proceso("Ana Pérez", historial=self.HIST_MIXTO,
                              registro_validador=registro)
        # De las 4 correcciones del modelo, solo UNA es de Ana.
        assert res["n_correcciones_atribuidas"] == 1, (
            "sigue atribuyendo por modelo: Ana hereda las correcciones de Luis")
        assert res["n_correcciones_sin_autor"] == 2
        assert "aproximada" not in res["atribucion"], (
            "la nota de atribución aproximada sigue en el informe interno")

    def test_la_senal_declara_su_limite_con_historial_antiguo(self):
        """
        Validador sin correcciones firmadas pero con registros antiguos sin
        autor: la señal se emite, declarándose no concluyente. Presentar como
        hallazgo lo que es una laguna del dato histórico sería acusar sin prueba.
        """
        from modulos.override_humano import calidad_proceso
        registro = [{"validador": "Marta Ruiz", "modelo": "LaR"}
                    for _ in range(3)]
        res = calidad_proceso("Marta Ruiz", historial=self.HIST_MIXTO,
                              registro_validador=registro)
        assert res["n_correcciones_atribuidas"] == 0
        assert res["señales"], "debería avisar de 3 aprobaciones sin corregir"
        assert "no concluyente" in res["señales"][0]

    def test_ambos_modulos_de_feedback_firman(self):
        """
        [§3.1] `feedback_mejorado.py` ha sido la rama OLVIDADA en tres arreglos
        anteriores —lectura del historial, escritura del historial y su lock—.
        Este test falla si vuelve a quedarse fuera.

        Por AST y no por texto (§3.8): la palabra «validador» aparece por todo
        el módulo en comentarios. Se busca un dict literal que tenga a la vez
        `puntaje_correcto` y `validador`, que identifica el registro de feedback
        y no cualquier otro diccionario.
        """
        for modulo in ("feedback.py", "feedback_mejorado.py"):
            fuente = (RAIZ / "modulos" / modulo).read_text(encoding="utf-8")
            firmado = False
            for nodo in ast.walk(ast.parse(fuente)):
                if not isinstance(nodo, ast.Dict):
                    continue
                claves = {k.value for k in nodo.keys
                          if isinstance(k, ast.Constant)}
                if {"puntaje_correcto", "validador"} <= claves:
                    firmado = True
            assert firmado, (
                f"{modulo} escribe registros de feedback SIN autor: es la rama "
                f"olvidada por cuarta vez")

    def test_los_dos_modulos_usan_el_mismo_resolutor_de_identidad(self):
        """
        Una segunda implementación de «quién firma» podría divergir en el orden
        de precedencia o en el valor de relleno, y `calidad_proceso()` contaría
        las dos convenciones como personas distintas.
        """
        fuente = (RAIZ / "modulos" / "feedback_mejorado.py").read_text(
            encoding="utf-8")
        alias = [a.name for n in ast.walk(ast.parse(fuente))
                 if isinstance(n, ast.ImportFrom) for a in n.names]
        assert "identidad_para_feedback" in alias, (
            "feedback_mejorado resuelve la identidad por su cuenta")

    def test_la_identidad_del_feedback_es_la_del_informe(self):
        """
        Misma fuente que la firma del informe. Si divergieran, el informe podría
        firmarlo Ana y sus correcciones constar a nombre de Luis.
        """
        fuente = (RAIZ / "modulos" / "feedback.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef)
                  and n.name == "identidad_para_feedback")
        alias = [a.name for a in ast.walk(fn) if isinstance(a, ast.alias)]
        assert "solicitar_identidad" in alias, (
            "no usa validador_humano.solicitar_identidad como fuente")

    def test_el_feedback_no_bloquea_sin_identidad(self, monkeypatch):
        """
        El bucle corre en PRE-PRODUCCIÓN, donde `--prdc` no exigió identidad.
        Bloquear ahí haría perder la corrección —el dato caro— por no haber
        puesto un flag. Se registra la ausencia, no se aborta.
        """
        from modulos.feedback import SIN_AUTOR, identidad_para_feedback
        monkeypatch.delenv("VIRF_VALIDADOR", raising=False)
        monkeypatch.delenv("VIRF_VALIDADOR_CARGO", raising=False)
        ident = identidad_para_feedback(None, None)
        assert ident["validador"] == SIN_AUTOR
        assert ident["cargo"] == SIN_AUTOR

    def test_identidad_explicita_gana(self):
        from modulos.feedback import identidad_para_feedback
        ident = identidad_para_feedback("Ana Pérez", "Validador Senior")
        assert ident["validador"] == "Ana Pérez"
        assert ident["cargo"] == "Validador Senior"


# ═════════════════════════════════════════════════════════════════════════════
# PENDIENTE 3 · APROBACIÓN DE DOS OJOS
#
# La segregación se DETECTABA y se avisaba, pero un solo validador podía emitir
# todo. En Tier 1 un supervisor exige dos firmas, y un aviso al pie no es una
# firma: es la constancia de que no la hubo.
# ═════════════════════════════════════════════════════════════════════════════

class TestDobleFirma:

    PRIMERA = {"validador": "Ana Pérez", "cargo": "Validador de Segunda Línea"}

    @pytest.fixture(autouse=True)
    def _entorno_limpio(self, monkeypatch):
        """
        [§3.7] El control se lee del entorno. Sin aislar, estos tests pasarían o
        fallarían según lo que el operador tuviera exportado en su consola.
        """
        for var in ("VIRF_DOBLE_FIRMA_TIER", "VIRF_VALIDADOR_2",
                    "VIRF_VALIDADOR_2_CARGO"):
            monkeypatch.delenv(var, raising=False)
        self._mp = monkeypatch

    # ── Criterio de aceptación central ───────────────────────────────────────

    def test_mismo_nombre_dos_veces_es_rechazado(self):
        """
        EL criterio de PENDIENTE 3. Sin esta comprobación el control es
        decorativo: la misma persona rellena las dos casillas y el informe
        declara una revisión cruzada que no existió.
        """
        from modulos.validador_humano import (
            SegundaFirmaRequerida, solicitar_segunda_firma,
        )
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
        with pytest.raises(SegundaFirmaRequerida) as exc:
            solicitar_segunda_firma(self.PRIMERA, "1", "Ana Pérez",
                                    "Validador de Segunda Línea",
                                    interactivo=False)
        assert "DISTINTA" in str(exc.value)

    def test_la_comparacion_normaliza(self):
        """
        «ana  perez» es la misma persona que «Ana Pérez». Quien teclea su propio
        nombre dos veces rara vez lo escribe idéntico, y sin normalizar el
        control se salta con una tilde.
        """
        from modulos.validador_humano import (
            SegundaFirmaRequerida, solicitar_segunda_firma,
        )
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
        for variante in ("ana perez", "ANA  PÉREZ", "  Ana Perez  "):
            with pytest.raises(SegundaFirmaRequerida):
                solicitar_segunda_firma(self.PRIMERA, "1", variante, "Jefe",
                                        interactivo=False)

    def test_segundo_validador_distinto_es_aceptado(self):
        from modulos.validador_humano import solicitar_segunda_firma
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
        segunda = solicitar_segunda_firma(self.PRIMERA, "1", "Luis Gómez",
                                          "Jefe de Validación",
                                          interactivo=False)
        assert segunda["validador"] == "Luis Gómez"
        assert segunda["cargo"] == "Jefe de Validación"
        assert segunda["fecha_aprobacion"]

    def test_sin_segunda_firma_el_tier1_no_emite(self):
        """Bloquea, no avisa. La justificación está en config/parametros.py."""
        from modulos.validador_humano import (
            SegundaFirmaRequerida, solicitar_segunda_firma,
        )
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
        with pytest.raises(SegundaFirmaRequerida):
            solicitar_segunda_firma(self.PRIMERA, "1", None, None,
                                    interactivo=False)

    # ── Alcance del control ──────────────────────────────────────────────────

    def test_tiers_no_declarados_no_exigen_doble_firma(self):
        from modulos.validador_humano import solicitar_segunda_firma
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
        assert solicitar_segunda_firma(self.PRIMERA, "2", None, None,
                                       interactivo=False) is None

    def test_desactivado_por_defecto(self):
        """
        Activarlo solo rompería toda emisión Tier 1 automatizada hasta que
        alguien configurase el segundo firmante — y el equipo lo desactivaría.
        Es la entidad quien declara la política.
        """
        from modulos.validador_humano import (
            requiere_doble_firma, solicitar_segunda_firma,
        )
        assert requiere_doble_firma("1") is False
        assert solicitar_segunda_firma(self.PRIMERA, "1", None, None,
                                       interactivo=False) is None

    def test_varios_tiers(self):
        from modulos.validador_humano import requiere_doble_firma
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1,2")
        assert requiere_doble_firma("1") is True
        assert requiere_doble_firma("2") is True
        assert requiere_doble_firma("3") is False

    def test_el_tier_se_compara_como_texto(self):
        """
        `--tier` llega como cadena. Si el conjunto guardara enteros, "1" != 1
        desactivaría el control EN SILENCIO — el peor modo de fallo para un
        control de cumplimiento.
        """
        from modulos.validador_humano import requiere_doble_firma
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
        assert requiere_doble_firma(1) is True
        assert requiere_doble_firma("1") is True

    # ── Vía no interactiva ───────────────────────────────────────────────────

    def test_hay_via_no_interactiva(self):
        """
        Criterio de aceptación: sin ella ninguna corrida automatizada podría
        emitir, y habilitar el control equivaldría a apagar el pipeline.
        """
        from modulos.validador_humano import solicitar_segunda_firma
        self._mp.setenv("VIRF_DOBLE_FIRMA_TIER", "1")
        self._mp.setenv("VIRF_VALIDADOR_2", "Luis Gómez")
        self._mp.setenv("VIRF_VALIDADOR_2_CARGO", "Jefe de Validación")
        segunda = solicitar_segunda_firma(self.PRIMERA, "1", None, None,
                                          interactivo=False)
        assert segunda["validador"] == "Luis Gómez"

    def test_flags_disponibles(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert '"--validador-2"' in fuente
        assert '"--cargo-2"' in fuente

    # ── Ambas firmas viajan al JSON y al Word ────────────────────────────────

    def test_ambas_firmas_llegan_al_word(self, tmp_path):
        from modulos.generador_word import generar_word_informe
        identidad = dict(self.PRIMERA)
        identidad["fecha_aprobacion"] = "2026-08-03T10:00:00Z"
        identidad["segunda_firma"] = {
            "validador": "Luis Gómez", "cargo": "Jefe de Validación",
            "fecha_aprobacion": "2026-08-03T10:05:00Z",
        }
        ruta = generar_word_informe(
            resumen_ejecutivo="Resumen de prueba.",
            evaluaciones_por_ambito={"Metodología": []},
            scores_por_ambito={"Metodología": 3.0},
            score_global=3.0,
            titulo_modelo="ModeloDobleFirma",
            tier="1",
            outputs_dir=tmp_path,
            validacion_humana=identidad,
        )
        import docx
        texto = "\n".join(p.text for p in docx.Document(str(ruta)).paragraphs)
        for tabla in docx.Document(str(ruta)).tables:
            for fila in tabla.rows:
                texto += "\n" + "\n".join(c.text for c in fila.cells)
        assert "Ana Pérez" in texto
        assert "Luis Gómez" in texto, (
            "la segunda firma no llega al Word: el auditor recibe el Word, y "
            "una aprobación que solo consta en el JSON no acredita nada")

    def test_la_segunda_firma_viaja_al_json(self):
        """
        Va anidada en `validacion_humana`, que agente.py ya vuelca al payload
        ANTES del sellado — así entra en el hash de custodia y alterarla se
        detecta.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert '_identidad["segunda_firma"] = _segunda_firma' in vivas
        assert '_payload["validacion_humana"] = _identidad' in vivas

    def test_la_doble_firma_se_resuelve_antes_de_gastar(self):
        """
        Pedirla al final abortaría la corrida DESPUÉS de haber pagado la
        evaluación completa. El control debe fallar barato.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert (fuente.index("_segunda_firma = solicitar_segunda_firma(")
                < fuente.index("leer_estandares_virf(tier_str)")), (
            "la segunda firma se pide después de empezar a gastar")

    def test_el_segundo_firmante_queda_en_el_registro(self):
        """
        Sin registrarlo, `aviso_segunda_revision` seguiría contando firmas
        consecutivas del primero y avisaría de falta de segunda revisión
        justo en los informes que sí la tuvieron.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert 'identidad=_identidad["segunda_firma"]' in vivas

    def test_la_decision_de_bloquear_esta_justificada_en_el_codigo(self):
        """
        El encargo pide razonar y documentar si bloquea o avisa. El proyecto
        tiene el criterio contrario en 2.3, así que la divergencia debe quedar
        explicada donde se lea, no en un commit.
        """
        fuente = (RAIZ / "config" / "parametros.py").read_text(encoding="utf-8")
        bloque = fuente[fuente.index("def tiers_doble_firma") - 4000:
                        fuente.index("def tiers_doble_firma")]
        assert "BLOQUEA" in bloque.upper()
        assert "opt-in" in bloque.lower() or "OPT-IN" in bloque.upper()


# ═════════════════════════════════════════════════════════════════════════════
# ENRUTADO DEL RAG · el corpus que se consulta debe ser el del modelo
#
# `inferir_dominio` comparaba SUBCADENAS. Como las claves son cortas —«lar»,
# «var», «nmd»— coincidían dentro de palabras corrientes del castellano y el
# modelo se enrutaba al corpus equivocado. El fallo era invisible: producía una
# cita PLAUSIBLE Y AJENA, que es peor que no recuperar nada.
# ═════════════════════════════════════════════════════════════════════════════

class TestEnrutadoRAG:

    #: Títulos que la coincidencia por subcadena enrutaba mal. Cada uno lleva
    #: la palabra castellana que contenía la clave por accidente.
    FALSOS_POSITIVOS = [
        ("Titularizacion Hipotecaria",          "titu·LAR·izacion"),
        ("Scoring Particulares",                "particu·LAR·es"),
        ("Modelo de Variables Macroeconomicas", "·VAR·iables"),
        ("Modelo Escalar de Riesgo",            "esca·LAR"),
        ("Modelo de Alarma Temprana",           "a·LAR·ma"),
        ("Provisiones Regulares",               "regu·LAR·es"),
        ("Riesgo de credito - celular",         "celu·LAR"),
    ]

    #: Títulos que SÍ identifican dominio. El arreglo no puede romperlos: pasar
    #: de enrutar mal a no enrutar nada sería cambiar un defecto por otro.
    VERDADEROS = [
        ("Modelo LaR Cartera Corporativa", "LaR"),
        ("Modelo LCR Liquidez",            "LaR"),
        ("VaR Mercado FRTB",               "VaR"),
        ("Riesgo de Mercado FRTB",         "VaR"),
        ("Modelo Conductual de Prepago",   "conductuales"),
        ("Prepago NMD Q1 2026",            "conductuales"),
    ]

    def test_no_enruta_por_trozos_de_palabra(self):
        from src.rag import inferir_dominio
        malos = [(t, inferir_dominio(t), por_que)
                 for t, por_que in self.FALSOS_POSITIVOS
                 if inferir_dominio(t) != "shared"]
        assert not malos, (
            "títulos enrutados al corpus equivocado por coincidencia de "
            "subcadena: " + "; ".join(f"{t} → {d} ({p})" for t, d, p in malos))

    def test_los_titulos_legitimos_siguen_enrutando(self):
        from src.rag import inferir_dominio
        for titulo, esperado in self.VERDADEROS:
            assert inferir_dominio(titulo) == esperado, (
                f"'{titulo}' dejó de enrutar a {esperado}: el arreglo se pasó "
                f"de estricto y ahora nada llega a su corpus")

    def test_el_dominio_explicito_manda(self):
        """
        Si el validador declara el dominio, manda él. Adivinar por encima de una
        declaración explícita es exactamente el defecto que esto corrige.
        """
        from src.rag import resolver_dominio
        assert resolver_dominio("Modelo LaR", "VaR") == ("VaR", "explicito")
        assert resolver_dominio("cualquier cosa", "conductuales") == (
            "conductuales", "explicito")

    def test_el_dominio_explicito_admite_mayusculas(self):
        from src.rag import resolver_dominio
        assert resolver_dominio("X", "lar")[0] == "LaR"
        assert resolver_dominio("X", "VAR")[0] == "VaR"

    def test_dominio_inexistente_falla_ruidoso(self):
        """
        Un dominio mal escrito que cayera en silencio a `shared` dejaría al
        validador creyendo que declaró algo. Falla pronto.
        """
        from src.rag import resolver_dominio
        with pytest.raises(ValueError) as exc:
            resolver_dominio("X", "liquidez")
        assert "no existe" in str(exc.value)

    def test_la_procedencia_distingue_declarado_de_adivinado(self):
        """
        El informe presentaba igual «lo declaró una persona» y «lo dedujo una
        heurística del título». Son dos niveles de garantía distintos.
        """
        from src.rag import resolver_dominio
        assert resolver_dominio("VaR Mercado FRTB")[1] == "inferido"
        assert resolver_dominio("IFRS9 Perdida Esperada")[1] == "defecto"
        assert resolver_dominio("IFRS9", "shared")[1] == "explicito"

    def test_el_dominio_se_resuelve_una_sola_vez(self):
        """
        [§3.1] Antes se resolvía DOS veces —una dentro de `_enriquecer_con_rag`
        para consultar, otra fuera para reportar—. Coincidían, pero nada lo
        garantizaba: bastaba con que una recibiera el dominio explícito y la
        otra no para que el informe declarara un corpus distinto del consultado.
        """
        fuente = (RAIZ / "modulos" / "motor_ia.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef) and n.name == "evaluar_actividad")
        llamadas = [(getattr(n.func, "id", None) or getattr(n.func, "attr", None))
                    for n in ast.walk(fn) if isinstance(n, ast.Call)]
        assert llamadas.count("_rag_resolver_dominio") == 1, (
            "el dominio se resuelve más de una vez en evaluar_actividad(): el "
            "consultado y el declarado pueden divergir")
        assert "_rag_inferir_dominio" not in llamadas, (
            "queda una inferencia directa que ignora --dominio-rag")

    def test_el_informe_registra_dominio_y_procedencia(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert '"rag_dominio":' in vivas and '"rag_procedencia":' in vivas
        assert '"--dominio-rag"' in fuente

    def test_el_dominio_explicito_llega_al_retriever(self):
        """
        Que el flag exista no prueba que se use. Se comprueba que
        `_enriquecer_con_rag` consulta el corpus DECLARADO, no el del título.
        """
        from modulos import motor_ia
        vistos = []

        class _RetrieverFalso:
            def query_para_prompt(self, *a, **kw):
                return "### [1] Fuente: x.pdf\ntexto"

        def _fake_get(tipo_modelo=None, **kw):
            vistos.append(tipo_modelo)
            return _RetrieverFalso()

        orig_cache = dict(motor_ia._rag_retriever_cache)
        orig_get = motor_ia._rag_get_retriever
        motor_ia._rag_retriever_cache.clear()
        motor_ia._rag_get_retriever = _fake_get
        try:
            # Título que infiere LaR, pero se declara VaR: debe ganar VaR.
            motor_ia._enriquecer_con_rag("act", "Metodología", "Modelo LaR",
                                         dominio_rag="VaR")
        finally:
            motor_ia._rag_get_retriever = orig_get
            motor_ia._rag_retriever_cache.clear()
            motor_ia._rag_retriever_cache.update(orig_cache)

        assert vistos == ["VaR"], (
            f"se consultó {vistos} en vez del corpus declarado 'VaR': "
            f"--dominio-rag no llega al retriever")


# ═════════════════════════════════════════════════════════════════════════════
# CONTEXTO DE LAS SKILLS · cobertura declarada = cobertura real (invariante 4)
# ═════════════════════════════════════════════════════════════════════════════

class TestContextoSkills:

    #: Tamaños reales medidos sobre la evidencia del proyecto.
    DOCS_REALES = [
        ("manual_metodologico_LaR.md",           1445),
        ("Manual_Metodologico_LaR_completo.pdf", 15046),
        ("informe_seguimiento_Q2_2026.md",       1091),
        ("riskmetrics_summary.md",               773),
        ("manual_controles_datos.md",            2971),
        ("perfil_datos_LaR.md",                  1274),
        ("implementacion_LaR.md",                1056),
        ("uso_LaR_gestion.md",                   876),
    ]

    @classmethod
    def _docs(cls):
        return [(n, chr(65 + i % 26) * t)
                for i, (n, t) in enumerate(cls.DOCS_REALES)]

    def test_ningun_documento_desaparece_entero(self):
        """
        EL defecto. Con el corte plano `"\\n\\n".join(partes)[:MAX_CTX]`, un solo
        manual agotaba el presupuesto y 6 de 8 documentos se perdían ENTEROS,
        entre ellos la implementación. La skill de coherencia, que existe para
        comparar manual contra código, nunca veía el código: respondía «no
        encontré la implementación» — plausible y falso.
        """
        from agente import _acotar_contexto_skills
        docs = self._docs()
        # Con el presupuesto ANTIGUO, que es el caso peor.
        ctx, _cob = _acotar_contexto_skills(docs, 15000)
        ausentes = [n for n, _ in docs if f"=== {n} ===" not in ctx]
        assert not ausentes, (
            f"{len(ausentes)} documento(s) desaparecieron sin dejar rastro: "
            f"{', '.join(ausentes)}")

    def test_la_cobertura_declarada_es_la_real(self):
        """Invariante 4: si solo cabe el 60 %, el informe dice 60 %."""
        from agente import _acotar_contexto_skills
        docs = self._docs()
        total = sum(len(c) for _, c in docs)
        ctx, cob = _acotar_contexto_skills(docs, 15000)

        # Lo que realmente se incluyó, contado sobre el texto entregado.
        incluido = sum(
            sum(1 for ch in bloque if ch.isalpha())
            for bloque in [ctx])
        assert 0 < cob < 100, "debería declarar cobertura parcial"
        # La cobertura declarada no puede ser mayor que la real: inflarla es
        # el daño que el invariante 4 prohíbe.
        assert cob <= round(incluido / total * 100, 1) + 1.0, (
            f"cobertura declarada {cob}% por encima de la real")

    def test_sin_recorte_declara_100(self):
        from agente import _acotar_contexto_skills
        docs = [("a.md", "x" * 100), ("b.md", "y" * 100)]
        ctx, cob = _acotar_contexto_skills(docs, 100000)
        assert cob == 100.0
        assert "x" * 100 in ctx and "y" * 100 in ctx

    def test_el_recorte_se_declara_dentro_del_contexto(self):
        """
        El aviso va en el texto que ve el modelo: sin él reportará ausencia de
        evidencia donde solo hay falta de espacio.
        """
        from agente import _acotar_contexto_skills
        ctx, _ = _acotar_contexto_skills(self._docs(), 15000)
        assert "COBERTURA DE ESTE CONTEXTO" in ctx
        assert "PARCIAL" in ctx
        assert "NO como ausencia de evidencia" in ctx

    def test_los_documentos_pequenos_entran_completos(self):
        """
        Reparto con devolución de sobrante: un documento pequeño no puede
        quedar recortado solo porque otro sea enorme.
        """
        from agente import _acotar_contexto_skills
        docs = [("gigante.pdf", "G" * 100000), ("codigo.py", "C" * 500)]
        ctx, _ = _acotar_contexto_skills(docs, 20000)
        assert "C" * 500 in ctx, (
            "el documento pequeño se recortó pese a haber presupuesto: el "
            "grande se lo comió")

    def test_las_skills_tienen_presupuesto_propio(self):
        from config import MAX_CTX, MAX_CTX_SKILLS
        assert MAX_CTX_SKILLS > MAX_CTX, (
            "las skills comparten presupuesto con el pipeline: un solo manual "
            "vuelve a agotar el contexto")

    def test_la_cobertura_viaja_a_los_resultados(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert '"cobertura_evidencia"' in vivas, (
            "la cobertura de las skills no llega al informe: un hallazgo «no "
            "encontré X» sería indistinguible de «X no cupo en el contexto»")

    def test_agente_usa_el_reparto_y_no_un_corte_plano(self):
        """
        Que `_acotar_contexto_skills` exista y funcione no prueba que agente.py
        la use: bastaría con volver a un `[:MAX_CTX]` al lado para reintroducir
        el defecto entero con los tests en verde.

        Por AST y no por literal. La primera versión de este test buscaba la
        cadena `_ctx_skills[:_MAX_CTX]`, y al reintroducir el defecto ESCRITO DE
        OTRA FORMA el test siguió pasando — un falso negativo detectado
        precisamente al probar que el test detectaba el defecto. Comprobar que
        la función se LLAMA es robusto frente a cómo se escriba el corte.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef) and n.name == "main")
        llamadas = [(getattr(n.func, "id", None) or getattr(n.func, "attr", None))
                    for n in ast.walk(fn) if isinstance(n, ast.Call)]
        assert "_acotar_contexto_skills" in llamadas, (
            "main() ya no reparte el contexto de las skills: vuelve el corte "
            "plano que perdía 6 de 8 documentos sin declararlo")

        # Y el resultado del reparto es lo que se pasa a las skills, no otra cosa.
        llamada = next(
            (n for n in ast.walk(fn)
             if isinstance(n, ast.Call)
             and getattr(n.func, "id", None) == "ejecutar_skills"), None)
        assert llamada is not None
        ctx_arg = next((k.value for k in llamada.keywords if k.arg == "contexto"),
                       None)
        assert isinstance(ctx_arg, ast.Name) and ctx_arg.id == "_ctx_skills_recortado", (
            "el contexto que reciben las skills no es el que produjo el reparto")


# ═════════════════════════════════════════════════════════════════════════════
# SKILLS · la literatura regulatoria debe llegarles
# ═════════════════════════════════════════════════════════════════════════════

class TestRagEnSkills:

    def test_agente_pasa_bloque_rag_a_las_skills(self):
        """
        `bloque_rag` estaba cableado hasta el catálogo pero NADIE lo pasaba, así
        que llegaba "" siempre. `SkillRegulatorio` —«la única skill que depende
        del RAG»— nunca vio la norma que existe para contrastar.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef) and n.name == "main")
        llamada = next(
            (n for n in ast.walk(fn)
             if isinstance(n, ast.Call)
             and (getattr(n.func, "id", None) == "ejecutar_skills")), None)
        assert llamada is not None, "no se encontró la llamada a ejecutar_skills"
        kwargs = {k.arg for k in llamada.keywords}
        assert "bloque_rag" in kwargs, (
            "ejecutar_skills se sigue llamando sin bloque_rag: la skill "
            "regulatoria juzga de memoria")

    def test_la_skill_regulatoria_usa_el_bloque(self):
        from modulos.skills.catalogo import SkillRegulatorio
        s = SkillRegulatorio("contexto de prueba", "Modelo X",
                             bloque_rag="### [1] Fuente: SR_11-7.pdf\nexigencia")
        prompt = s.construir_prompt()
        assert "SR_11-7.pdf" in prompt
        assert "NO se recuperó literatura" not in prompt

    def test_sin_bloque_la_skill_declara_el_limite(self):
        """Degradación honesta: si no hay norma, se dice que se cita de memoria."""
        from modulos.skills.catalogo import SkillRegulatorio
        s = SkillRegulatorio("contexto", "Modelo X", bloque_rag="")
        prompt = s.construir_prompt()
        assert "NO se recuperó literatura regulatoria" in prompt
        assert "(ninguna)" in prompt


# ═════════════════════════════════════════════════════════════════════════════
# COHERENCIA · el manual contra lo que hace la implementación
#
# La skill contrasta «lo que el modelo DICE» contra «lo que HACE». Para eso
# necesita dos cosas: que ambos lados LLEGUEN a su contexto, y saber CUÁL es
# cuál. Lo primero lo rompía el truncado plano; lo segundo no existía —recibía
# una lista plana de nombres de fichero y tenía que deducir el rol del nombre.
# ═════════════════════════════════════════════════════════════════════════════

class TestCoherenciaManualVsImplementacion:

    def test_cada_documento_llega_rotulado_con_su_rol(self):
        """
        Sin rótulo, `Anexo_4.docx` o `notebook_final.ipynb` son indistinguibles:
        la skill tiene que adivinar de qué lado está cada documento. Un
        contraste que confunde los lados invierte el hallazgo.
        """
        from agente import _ROL_EVIDENCIA
        # Las claves deben ser las carpetas reales de evidencia, o el rótulo
        # nunca se aplicaría y el defecto volvería en silencio.
        from config.rutas import INPUTS
        for clave in ("doc_modelamiento", "implementacion", "doc_seguimiento"):
            assert clave in INPUTS, f"{clave} ya no es una carpeta de evidencia"
            assert clave in _ROL_EVIDENCIA, (
                f"la evidencia de '{clave}' llegaría a las skills sin rol")
        # Los dos lados del contraste tienen que ser distinguibles por el texto.
        assert "DICE" in _ROL_EVIDENCIA["doc_modelamiento"]
        assert "HACE" in _ROL_EVIDENCIA["implementacion"]

    def test_agente_rotula_al_construir_el_contexto(self):
        """Que el mapa exista no prueba que se use."""
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "_ROL_EVIDENCIA.get(" in vivas, (
            "el contexto de las skills se construye sin rotular el rol de cada "
            "documento: la skill de coherencia vuelve a adivinar")

    def test_el_prompt_manda_usar_el_rotulo(self):
        from modulos.skills.catalogo import SkillCoherencia
        p = SkillCoherencia("ctx", "Modelo X").construir_prompt()
        assert "rótulo" in p.lower()
        assert "MANUAL METODOLÓGICO" in p and "IMPLEMENTACIÓN" in p

    def test_sin_implementacion_no_inventa_discrepancias(self):
        """
        Sin código no hay contraste posible. Debe declararse como limitación de
        alcance, no producir hallazgos especulativos.
        """
        from modulos.skills.catalogo import SkillCoherencia
        p = SkillCoherencia("ctx", "Modelo X").construir_prompt()
        assert "devuelve la lista vacía" in p
        assert "limitación de alcance" in p

    def test_el_recorte_no_se_confunde_con_discrepancia(self):
        """
        Un documento cortado a la mitad puede parecer que «no dice» algo que sí
        dice. La skill tiene que distinguir «no está» de «no me llegó».
        """
        from modulos.skills.catalogo import SkillCoherencia
        p = SkillCoherencia("ctx", "Modelo X").construir_prompt()
        assert "PARCIAL" in p
        assert "nunca como discrepancia" in p

    def test_ambos_lados_sobreviven_al_reparto(self):
        """
        El manual es grande y el código pequeño: con el corte plano el código
        —el lado barato de incluir— era justo el que se perdía.
        """
        from agente import _acotar_contexto_skills
        docs = [
            ("manual.pdf  [MANUAL METODOLÓGICO — lo que el modelo DICE que hace]",
             "M" * 40000),
            ("calcula_var.py  [IMPLEMENTACIÓN (código) — lo que el modelo HACE de verdad]",
             "def var(r): return -np.percentile(r[-500:], 1)"),
        ]
        ctx, _cob = _acotar_contexto_skills(docs, 15000)
        assert "MANUAL METODOLÓGICO" in ctx
        assert "IMPLEMENTACIÓN (código)" in ctx, (
            "el código desapareció del contraste: la skill de coherencia se "
            "queda sin uno de los dos lados")
        assert "r[-500:]" in ctx, "el código llegó recortado hasta perder el dato"


# ═════════════════════════════════════════════════════════════════════════════
# EL RAG COMO PERICIA DE DOMINIO
#
# El bloque llegaba crudo —«## Conocimiento recuperado»— sin decir qué es ni qué
# hacer con él. Las dos salidas malas son simétricas: ignorarlo (se evalúa sin
# criterio de dominio y el RAG es coste muerto) o confundirlo con la evidencia
# del modelo (se cita literatura ajena como si la hubiera escrito el validado).
# ═════════════════════════════════════════════════════════════════════════════

class TestRagComoPericia:

    BLOQUE = ("## Conocimiento recuperado — dominio: VaR\n"
              "### [1] Fuente: FRTB_BCBS457.pdf\nExpected shortfall al 97.5%.")

    @staticmethod
    def _plano(texto: str) -> str:
        """
        Colapsa saltos de línea y espacios.

        El bloque está formateado para leerse en un prompt, así que las frases
        se parten («no\\n    se exige»). Buscar la frase literal encuentra un
        fallo que no existe: la primera versión de estos tests falló por eso.
        """
        return " ".join(str(texto or "").split())

    def test_el_bloque_llega_encuadrado(self):
        from modulos.motor_ia import _enmarcar_rag
        m = self._plano(_enmarcar_rag(self.BLOQUE, "VaR"))
        assert "PERICIA DE DOMINIO" in m
        assert "NO es evidencia del modelo que validas" in m
        # El contenido recuperado sigue intacto dentro del encuadre.
        assert "Expected shortfall al 97.5%." in m

    def test_sin_fragmentos_no_se_encuadra_nada(self):
        """
        Describir las reglas de un bloque ausente gasta contexto y confunde:
        el modelo leería instrucciones sobre literatura que no recibió.
        """
        from modulos.motor_ia import _enmarcar_rag
        assert _enmarcar_rag("", "VaR") == ""
        assert _enmarcar_rag("   \n ", "VaR") == ""

    def test_prohibe_citarlo_como_evidencia(self):
        """
        `_verificar_citas()` contrasta contra `contexto`, NO contra el bloque
        RAG. Una cita tomada de la literatura sale marcada como no verificada y
        en el informe parece inventada. El encuadre tiene que decirlo.
        """
        from modulos.motor_ia import _enmarcar_rag
        m = self._plano(_enmarcar_rag(self.BLOQUE, "VaR"))
        assert "evidencia_encontrada" in m
        assert "no verificada" in m or "NO lo cites" in m

    def test_la_ausencia_en_el_corpus_no_es_prueba(self):
        """
        La recuperación es parcial (top_k). Que un tema no salga en 3 fragmentos
        no significa que el marco no lo exija — y penalizar por eso sería
        fabricar un hallazgo, justo lo que el §7 prohíbe.
        """
        from modulos.motor_ia import _enmarcar_rag
        m = self._plano(_enmarcar_rag(self.BLOQUE, "VaR"))
        assert "AUSENCIA" in m and "no se exige" in m

    def test_no_sustituye_al_estandar(self):
        from modulos.motor_ia import _enmarcar_rag
        m = self._plano(_enmarcar_rag(self.BLOQUE, "VaR"))
        assert "NO sustituye al estándar VIRF" in m

    def test_avisa_si_el_fragmento_no_es_texto_oficial(self):
        """
        PENDIENTE 4: el corpus son hoy resúmenes secundarios. Convertir el RAG
        en «pericia» sin decirlo permitiría que un umbral inexacto sustentara
        una conclusión regulatoria.
        """
        from modulos.motor_ia import _enmarcar_rag
        con_marca = self.BLOQUE + "\nRESUMEN SECUNDARIO — NO ES EL TEXTO OFICIAL."
        m = self._plano(_enmarcar_rag(con_marca, "VaR"))
        assert "PROCEDENCIA" in m
        assert "fuente primaria" in m
        # Y no se emite cuando el fragmento sí es oficial: un aviso permanente
        # se vuelve invisible.
        assert "PROCEDENCIA" not in _enmarcar_rag(self.BLOQUE, "VaR")

    def test_la_regla_de_citas_desambigua_los_dos_bloques(self):
        """
        Con el encuadre hay DOS bloques «arriba». «Copia solo texto que esté
        literalmente en el contexto de arriba» dejaba de ser preciso.
        """
        fuente = (RAIZ / "modulos" / "motor_ia.py").read_text(encoding="utf-8")
        assert "NUNCA del bloque PERICIA DE" in fuente

    def test_el_pipeline_encuadra_el_bloque(self):
        """Que la función exista no prueba que se use."""
        fuente = (RAIZ / "modulos" / "motor_ia.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef) and n.name == "evaluar_actividad")
        llamadas = [(getattr(n.func, "id", None) or getattr(n.func, "attr", None))
                    for n in ast.walk(fn) if isinstance(n, ast.Call)]
        assert "_enmarcar_rag" in llamadas, (
            "el bloque RAG vuelve a inyectarse crudo, sin decir qué es")

    def test_las_skills_reciben_el_bloque_encuadrado(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert "_enm(_bloque_rag_skills" in vivas, (
            "las skills reciben el RAG sin encuadre: sus citas se verifican "
            "contra el mismo contexto y saldrían marcadas igual")

    def test_el_cuestionamiento_metodologico_solo_va_en_metodologia(self):
        """
        Era el ÚNICO bloque opcional autofiltrado: viajaba en los 24 prompts
        con la nota «(solo si la actividad es de Metodología)», delegando el
        filtro al modelo. Un filtro por instrucción es un filtro que puede no
        cumplirse — nada impedía aplicar cuestionamiento metodológico a una
        actividad de Gobierno, donde la pregunta correcta es si hay acta.
        """
        from modulos.motor_ia import _es_ambito_metodologia as es_met
        assert es_met("Metodología") is True
        for otro in ("Gobierno", "Implementación", "Calidad de datos",
                     "Documentación", "Uso e integración a la gestión"):
            assert es_met(otro) is False, f"{otro} recibiría el bloque"

    def test_el_filtro_no_depende_de_como_se_teclee_el_ambito(self):
        """
        El nombre viene del Excel del estándar, que el Responsable de Validación
        puede editar. Una tilde perdida dejaría sin cuestionamiento al ámbito de
        mayor peso (0.30) EN SILENCIO.
        """
        from modulos.motor_ia import _es_ambito_metodologia as es_met
        for variante in ("Metodologia", "METODOLOGÍA", " metodología ",
                         "Metodologías", "metodologia "):
            assert es_met(variante) is True, f"«{variante}» perdería el bloque"

    def test_el_bloque_se_inyecta_condicionalmente_en_el_prompt(self):
        """
        Que la constante y el detector existan no prueba que el prompt los use.
        Se comprueba por AST que `evaluar_actividad` llama al detector.
        """
        fuente = (RAIZ / "modulos" / "motor_ia.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef) and n.name == "evaluar_actividad")
        llamadas = [(getattr(n.func, "id", None) or getattr(n.func, "attr", None))
                    for n in ast.walk(fn) if isinstance(n, ast.Call)]
        assert "_es_ambito_metodologia" in llamadas, (
            "el cuestionamiento metodológico vuelve a viajar en todos los "
            "prompts con el filtro delegado al modelo")

    def test_ya_no_queda_la_nota_de_autofiltro(self):
        """
        Si el bloque ya se filtra en código, la nota «(solo si…)» sobra y
        confunde: sugiere al modelo que decida algo que ya está decidido.
        """
        from modulos.motor_ia import _CUESTIONAMIENTO_METODOLOGICO as B
        assert "solo si la actividad" not in B
        # Y el contenido sustantivo sigue entero.
        assert "¿Por qué ESTA metodología y no otra?" in B
        assert "No inventes deficiencias" in B

    def test_el_recuento_de_fragmentos_no_cambia_al_encuadrar(self):
        """
        `rag_chunks` viaja al informe. Si se contara después del encuadre y éste
        introdujera un `### [`, la cifra dejaría de ser el número de fragmentos.
        """
        from modulos.motor_ia import _enmarcar_rag
        assert _enmarcar_rag(self.BLOQUE, "VaR").count("### [") == \
            self.BLOQUE.count("### [")


# ═════════════════════════════════════════════════════════════════════════════
# JUEZ DE CÓDIGO ANCLADO EN LOS MANUALES
#
# `--revisar-codigo` es un LLM-judge: dictamina sobre el código contrastándolo
# con la documentación. Pedía una `referencia_manual` («si afirmas que el manual
# dice algo, cita el fragmento») y NADIE la comprobaba — y solo veía el manual
# metodológico, nunca el de seguimiento.
# ═════════════════════════════════════════════════════════════════════════════

class TestJuezCodigoAnclado:

    MANUAL = ("[MANUAL METODOLÓGICO] El VaR se calcula por simulación histórica "
              "sobre una ventana de 250 días hábiles, al 99% de confianza.\n\n"
              "[SEGUIMIENTO / BACKTESTING] En 2026Q1 se observaron 4 excepciones "
              "sobre 250 observaciones, dentro del intervalo de Kupiec.")

    @staticmethod
    def _hallazgo(cat, ref):
        return {"linea": 10, "categoria": cat, "severidad": "alta",
                "elemento": "var_historico", "descripcion": "d",
                "evidencia_codigo": "r[-500:]", "referencia_manual": ref}

    # ── La certeza: la referencia se comprueba ──────────────────────────────

    def test_referencia_inventada_se_marca_sin_anclar(self):
        """
        EL defecto. Una cita inventada es más dañina que una vaga: parece
        verificable —lleva número de sección— así que nadie la contrasta, y
        acusa al modelo validado de una discrepancia que no existe.
        """
        from modulos.revision_codigo import verificar_referencia_manual as v
        inventada = ("El manual establece en su sección 7 una ventana de 500 "
                     "días para el cálculo del VaR paramétrico")
        assert v(inventada, "code_drift", self.MANUAL) is False

    def test_referencia_real_se_verifica(self):
        from modulos.revision_codigo import verificar_referencia_manual as v
        real = "sobre una ventana de 250 días hábiles, al 99% de confianza"
        assert v(real, "code_drift", self.MANUAL) is True

    def test_la_verificacion_tolera_espacios_del_extractor(self):
        """
        Los extractores de PDF desordenan espacios y el modelo los recompone al
        citar. Sin normalizar, una cita CORRECTA se marcaría como falsa y el
        aviso se volvería ruido que el equipo aprende a ignorar.
        """
        from modulos.revision_codigo import verificar_referencia_manual as v
        manual_sucio = "una  ventana   de  250\n días  hábiles, al 99% de confianza"
        assert v("una ventana de 250 días hábiles, al 99% de confianza",
                 "code_drift", manual_sucio) is True

    def test_una_referencia_demasiado_corta_no_acredita(self):
        """
        «§4.2» es un puntero, no una cita del contenido: encontrarlo en un
        manual largo puede ser casualidad y el «verificada» sería falso.
        """
        from modulos.revision_codigo import verificar_referencia_manual as v
        assert v("§4.2", "code_drift", self.MANUAL) is False
        assert v("", "documentado_ausente", self.MANUAL) is False

    def test_las_categorias_de_ausencia_no_exigen_cita(self):
        """
        `no_documentado` y `supuesto_tacito` afirman que algo NO está. Exigirles
        un fragmento que lo demuestre es incoherente: una ausencia no se cita.
        """
        from modulos.revision_codigo import verificar_referencia_manual as v
        for cat in ("no_documentado", "supuesto_tacito", "riesgo_tecnico"):
            assert v("", cat, self.MANUAL) is None, (
                f"{cat} exige cita de una ausencia")

    # ── La categoría se corrige contra los hechos ───────────────────────────

    CODIGO = ("def var_historico(retornos, confianza=0.95, ventana=500):\n"
              "    return -np.percentile(retornos[-ventana:], 1)\n"
              "def var_cartera(series, pesos):\n"
              "    return sum(var_historico(s) for s in series)\n")
    MAN_REC = ("El VaR se estima sobre una ventana de 250 días hábiles. "
               "El módulo implementa la función backtesting_kupiec(), que "
               "contrasta las excepciones observadas.")

    def test_no_documentado_sobre_algo_que_el_manual_si_declara(self):
        """
        EL caso peligroso, observado en la corrida real: etiquetar
        `no_documentado` —«el manual NO lo declara»— algo que el manual SÍ
        declara. Esa categoría no exige anclaje, así que una afirmación sobre
        la documentación entraba al informe sin verificar.

        Su premisa es comprobable y es falsa: `backtesting_kupiec` está en el
        manual. Y no está en el código → es `documentado_ausente`.
        """
        from modulos.revision_codigo import recategorizar
        cat, motivo = recategorizar("no_documentado", "backtesting_kupiec",
                                    self.CODIGO, self.MAN_REC)
        assert cat == "documentado_ausente"
        assert motivo and "SÍ aparece en la documentación" in motivo

    def test_documentado_ausente_sobre_algo_que_si_esta_en_el_codigo(self):
        """
        Segunda equivocación observada: `documentado_ausente` —«no existe en el
        código»— sobre `var_historico`, que sí existe. Está en ambos sitios:
        es `code_drift`.
        """
        from modulos.revision_codigo import recategorizar
        cat, motivo = recategorizar("documentado_ausente", "var_historico",
                                    self.CODIGO, self.MAN_REC)
        assert cat == "code_drift"
        assert motivo and "SÍ existe en el código" in motivo

    def test_no_se_corrige_cuando_la_evidencia_es_ambigua(self):
        """
        Si el elemento está en los dos sitios, o en ninguno, la categoría del
        modelo puede ser correcta. Sustituirla por otra adivinada sería cambiar
        un error por otro.
        """
        from modulos.revision_codigo import recategorizar
        # En ninguno de los dos: no hay nada que contradiga la etiqueta.
        cat, motivo = recategorizar("no_documentado", "funcion_inexistente",
                                    self.CODIGO, self.MAN_REC)
        assert (cat, motivo) == ("no_documentado", None)
        # Categorías que no afirman presencia/ausencia no se tocan.
        for c in ("code_drift", "supuesto_tacito", "riesgo_tecnico"):
            assert recategorizar(c, "var_historico", self.CODIGO,
                                 self.MAN_REC) == (c, None)

    def test_no_se_corrige_por_nombres_demasiado_cortos(self):
        """Un `x` o un `df` aparecen en cualquier texto por casualidad."""
        from modulos.revision_codigo import recategorizar
        assert recategorizar("no_documentado", "x", self.CODIGO,
                             "el valor x del modelo") == ("no_documentado", None)

    def test_la_correccion_deja_rastro(self):
        """
        Corregir sin dejar rastro impediría a un auditor distinguir lo que
        dictaminó el modelo de lo que ajustó el agente.
        """
        from modulos.revision_codigo import RevisorCodigo
        r = RevisorCodigo(cliente_ia=None)
        h = r._normalizar_hallazgo(
            {"linea": 1, "categoria": "no_documentado", "severidad": "alta",
             "elemento": "backtesting_kupiec", "descripcion": "d",
             "evidencia_codigo": "", "referencia_manual": ""},
            "calcula_var.py", self.MAN_REC, self.CODIGO)
        assert h["categoria"] == "documentado_ausente"
        assert h["categoria_declarada"] == "no_documentado"
        assert h["motivo_recategorizacion"]

    def test_la_correccion_ocurre_antes_de_verificar_la_cita(self):
        """
        El orden importa: una categoría corregida a `documentado_ausente` SÍ
        exige anclaje. Verificar primero la dejaría escapar igual que antes,
        que es el defecto entero.
        """
        from modulos.revision_codigo import RevisorCodigo
        r = RevisorCodigo(cliente_ia=None)
        h = r._normalizar_hallazgo(
            {"linea": 1, "categoria": "no_documentado", "severidad": "alta",
             "elemento": "backtesting_kupiec", "descripcion": "d",
             "evidencia_codigo": "", "referencia_manual": ""},
            "calcula_var.py", self.MAN_REC, self.CODIGO)
        assert h["referencia_verificada"] is False, (
            "el hallazgo recategorizado no pasó por la verificación de cita: "
            "sigue escapando al anclaje")

    def test_cita_con_elision_se_verifica_por_tramos(self):
        """
        Detectado en la corrida contra `modelos/VaR_FixtureDrift`: el modelo
        elidió el texto intermedio con `[...]`, práctica normal al citar. Las
        dos mitades estaban literalmente en el manual y la afirmación era
        cierta, pero la comparación de la cadena entera fallaba y el hallazgo
        salía SIN ANCLAR.

        Un falso positivo sobre una cita BIEN FORMADA es el peor resultado
        posible: enseña al equipo a ignorar el aviso, y entonces las citas
        realmente inventadas pasan con él.
        """
        from modulos.revision_codigo import verificar_referencia_manual as v
        cosida = ("El VaR se calcula por simulación histórica [...] "
                  "al 99% de confianza")
        manual = ("El VaR se calcula por simulación histórica sobre una ventana "
                  "de 250 días hábiles, al 99% de confianza.")
        assert v(cosida, "code_drift", manual) is True

        # Otras marcas de elisión habituales.
        for marca in ("…", "...", "(...)", "[…]"):
            c = f"El VaR se calcula por simulación histórica {marca} al 99% de confianza"
            assert v(c, "code_drift", manual) is True, f"falla con «{marca}»"

    def test_trocear_no_relaja_la_prueba(self):
        """
        La elisión significa «hay texto en medio», no «me lo invento». Si un
        tramo no está, la cita sigue sin acreditar; y trocear no permite bajar
        del mínimo total de longitud.
        """
        from modulos.revision_codigo import verificar_referencia_manual as v
        manual = ("El VaR se calcula por simulación histórica sobre una ventana "
                  "de 250 días hábiles, al 99% de confianza.")
        # Segundo tramo inventado.
        inventado = ("El VaR se calcula por simulación histórica [...] "
                     "con recalibración trimestral obligatoria")
        assert v(inventado, "code_drift", manual) is False
        # Tramos reales pero demasiado cortos en total.
        assert v("El VaR [...] 99%", "code_drift", manual) is False

    def test_toda_referencia_aportada_se_verifica(self):
        """
        Detectado en la PRIMERA CORRIDA REAL: un `supuesto_tacito` —categoría
        que no exige anclaje— citó por su cuenta «nivel de confianza 99%», y la
        cita llegó al Word sin sello. Era correcta, pero el informe no lo decía.

        Que el modelo cite de más es bueno; que su cita no se compruebe, no.
        """
        from modulos.revision_codigo import verificar_referencia_manual as v
        buena = "sobre una ventana de 250 días hábiles, al 99% de confianza"
        mala = "el manual establece una ventana de 500 días para el cálculo"
        assert v(buena, "supuesto_tacito", self.MANUAL) is True
        assert v(mala, "supuesto_tacito", self.MANUAL) is False
        # Sin referencia sigue siendo «no aplica», no una acusación.
        assert v("", "supuesto_tacito", self.MANUAL) is None

    # ── El anclaje llega al hallazgo y al informe ───────────────────────────

    def test_el_hallazgo_viaja_con_su_estado_de_anclaje(self):
        from modulos.revision_codigo import RevisorCodigo
        r = RevisorCodigo(cliente_ia=None)
        bueno = r._normalizar_hallazgo(
            self._hallazgo("code_drift",
                           "sobre una ventana de 250 días hábiles, al 99% de confianza"),
            "calcula_var.py", self.MANUAL)
        malo = r._normalizar_hallazgo(
            self._hallazgo("code_drift", "el manual exige 500 días de ventana"),
            "calcula_var.py", self.MANUAL)
        assert bueno["referencia_verificada"] is True
        assert malo["referencia_verificada"] is False

    def test_el_informe_cuenta_anclados_y_sin_anclar(self):
        from modulos.revision_codigo import RevisorCodigo, informe_markdown
        r = RevisorCodigo(cliente_ia=None)
        hs = [
            r._normalizar_hallazgo(
                self._hallazgo("code_drift",
                               "sobre una ventana de 250 días hábiles, al 99% de confianza"),
                "a.py", self.MANUAL),
            r._normalizar_hallazgo(
                self._hallazgo("code_drift", "el manual exige 500 dias"),
                "b.py", self.MANUAL),
            r._normalizar_hallazgo(
                self._hallazgo("no_documentado", ""), "c.py", self.MANUAL),
        ]
        cons = r.consolidar(
            [{"fichero": "x", "hallazgos": hs, "revision_valida": True}])
        assert cons["n_hallazgos_anclados_al_manual"] == 1
        assert cons["n_hallazgos_sin_anclar"] == 1   # el `no_documentado` no cuenta

        md = informe_markdown(cons, "Modelo X")
        assert "SIN ANCLAR" in md, (
            "el informe no distingue un hallazgo probado de uno afirmado")

    # ── Los DOS manuales ────────────────────────────────────────────────────

    def test_el_revisor_recibe_metodologico_y_seguimiento(self):
        """
        Antes solo entraba `doc_modelamiento`. El de seguimiento es donde vive
        la mitad de las discrepancias que importan: un backtesting que declara
        haber medido sobre una ventana que el código no usa.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        bloque = vivas[vivas.index("if args.revisar_codigo:"):]
        bloque = bloque[:bloque.index("_revisor.revisar(")]
        assert "doc_modelamiento" in bloque and "doc_seguimiento" in bloque, (
            "la revisión de código no ve el manual de seguimiento")

    def test_el_dry_run_mide_los_mismos_manuales(self):
        """
        [§3.1] Dos caminos: la corrida real y el inventario de coste. Si solo se
        corrige uno, el dry-run subestima el gasto — y es la rama cuyo único
        cometido es avisar de lo que se va a gastar.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        bloque = vivas[vivas.index("if args.revisar_codigo and args.dry_run:"):]
        bloque = bloque[:bloque.index("formatear_inventario(")]
        assert "doc_seguimiento" in bloque, (
            "el dry-run mide solo el manual metodológico: subestima el coste")

    # ── El informe ENTREGABLE muestra el código ─────────────────────────────

    HALLAZGOS_WORD = [
        {"fichero": "calcula_var.py", "linea": 87, "categoria": "code_drift",
         "severidad": "critica", "elemento": "var_historico",
         "descripcion": ("El manual fija la ventana en 250 días y el código usa "
                         "500, lo que invalida la comparabilidad del backtesting."),
         "evidencia_codigo": "return -np.percentile(retornos[-500:], 1)",
         "referencia_manual": "una ventana de 250 días hábiles",
         "referencia_verificada": True},
        {"fichero": "calcula_var.py", "linea": 104, "categoria": "code_drift",
         "severidad": "alta", "elemento": "_ajuste",
         "descripcion": "Aplica Cornish-Fisher no documentado.",
         "evidencia_codigo": "z + (z**2 - 1) * skew / 6",
         "referencia_manual": "", "referencia_verificada": False},
    ]

    def _word(self, tmp_path, hallazgos):
        from modulos.generador_word import generar_word_informe
        ev = {"actividad": "Revisión de código: calcula_var.py",
              "concepto": "Cálculo de VaR", "puntaje": 2,
              "observacion": "Discrepancias detectadas.",
              "evidencia_encontrada": "var_historico", "recomendacion": "Corregir.",
              "preguntas_pendientes": [], "hallazgos_codigo": hallazgos}
        ruta = generar_word_informe(
            "Resumen.", {"Implementación": [ev]}, {"Implementación": 2.0},
            2.0, "ModeloX", "1", tmp_path)
        import docx
        return "\n".join(p.text for p in docx.Document(str(ruta)).paragraphs)

    def test_el_informe_transcribe_el_codigo(self, tmp_path):
        """
        EL defecto que motiva esto: el fragmento se localizaba, se pagaba al
        modelo, y se descartaba antes de llegar al Word. Un dictamen sobre
        código que no transcribe el código no es verificable — el lector solo
        puede creerlo.
        """
        txt = self._word(tmp_path, self.HALLAZGOS_WORD)
        assert "retornos[-500:]" in txt, (
            "el fragmento de código no llega al informe entregable")
        assert "z + (z**2 - 1) * skew / 6" in txt

    def test_el_informe_dice_por_que_esta_mal(self, tmp_path):
        txt = self._word(tmp_path, self.HALLAZGOS_WORD)
        assert "invalida la comparabilidad del backtesting" in txt, (
            "la descripción se truncaba a 120 chars y perdía el motivo")

    def test_el_informe_muestra_contra_que_se_contrasta(self, tmp_path):
        txt = self._word(tmp_path, self.HALLAZGOS_WORD)
        assert "una ventana de 250 días hábiles" in txt

    def test_el_informe_marca_lo_no_anclado(self, tmp_path):
        """Un hallazgo sin acreditar no puede leerse igual que uno probado."""
        txt = self._word(tmp_path, self.HALLAZGOS_WORD)
        assert "SIN ANCLAR" in txt

    def test_sin_hallazgos_no_se_pinta_seccion(self, tmp_path):
        txt = self._word(tmp_path, [])
        assert "Discrepancias código" not in txt

    def test_la_fusion_conserva_los_hallazgos_integros(self):
        """
        [§3.1] El aplastamiento ocurría en agente.py, no en el Word. Si vuelve,
        el renderizador recibirá una lista vacía y el informe volverá a no
        mostrar código — con todos los tests del Word en verde.
        """
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert '"hallazgos_codigo":     _hs,' in vivas, (
            "la fusión ya no pasa los hallazgos completos al ámbito "
            "Implementación: el Word se queda sin código que mostrar")
        assert "h['descripcion'][:120]" not in vivas, (
            "vuelve el aplastamiento que truncaba el motivo a 120 caracteres")

    def test_el_word_pinta_los_hallazgos(self):
        """Que el renderizador exista no prueba que se invoque."""
        fuente = (RAIZ / "modulos" / "generador_word.py").read_text(encoding="utf-8")
        assert "_add_hallazgos_codigo(doc, ev.get(" in fuente

    def test_el_prompt_exige_y_declara_la_verificacion(self):
        from modulos.revision_codigo import _PROMPT_REVISION
        plano = " ".join(_PROMPT_REVISION.split())
        assert "SE VERIFICA" in plano
        assert "40 caracteres" in plano
        # Y dice qué hacer si no encuentra fragmento, en vez de forzar la cita.
        assert "NO uses esas dos categorías" in plano
        # Los dos roles de documentación quedan explicados.
        assert "SEGUIMIENTO" in plano and "METODOLÓGICO" in plano


# ═════════════════════════════════════════════════════════════════════════════
# EL ENTREGABLE RECIBE TODO LO QUE SE PAGA
#
# Con `--skills all` se pagan hasta 8 llamadas extra. Sus hallazgos llegaban al
# JSON y al borrador `.md` de trabajo, pero NO al Word: `generador_word.py` no
# tenía una sola mención a `skills`. Misma pérdida que ya se corrigió en la
# revisión de código — el trabajo caro se paga y se descarta justo antes del
# documento que se entrega.
# ═════════════════════════════════════════════════════════════════════════════

class TestSkillsEnElEntregable:

    SKILLS = [
        {"nombre": "sintesis", "titulo": "Síntesis priorizada", "ok": True,
         "duracion_seg": 3.1, "resumen": "Tres frentes concentran el riesgo.",
         "hallazgos": [{"hallazgo": "Backtesting sin Christoffersen",
                        "severidad": "alta",
                        "justificacion": "Solo se ejecuta Kupiec."}],
         "citas_no_verificadas": []},
        {"nombre": "coherencia", "titulo": "Coherencia doc ↔ implementación",
         "ok": True, "duracion_seg": 5.4, "resumen": "Una discrepancia.",
         "hallazgos": [{"aspecto": "Ventana de estimación", "severidad": "critica",
                        "cita_doc": "ventana de 250 días hábiles",
                        "cita_codigo": "retornos[-500:]",
                        "impacto": "Invalida la comparabilidad."}],
         "citas_no_verificadas": ["una cita que no estaba en la evidencia"]},
        {"nombre": "regulatorio", "titulo": "Contraste regulatorio", "ok": False,
         "error": "timeout tras 30s", "duracion_seg": 30.0, "hallazgos": []},
    ]

    def _texto_word(self, tmp_path, **kw):
        from modulos.generador_word import generar_word_informe
        ruta = generar_word_informe(
            "Resumen.", {"Metodología": []}, {"Metodología": 3.0}, 3.0,
            "ModeloX", "1", tmp_path, **kw)
        import docx
        doc = docx.Document(str(ruta))
        txt = "\n".join(p.text for p in doc.paragraphs)
        for t in doc.tables:
            for f in t.rows:
                txt += "\n" + "\n".join(c.text for c in f.cells)
        return txt

    def test_los_hallazgos_de_las_skills_llegan_al_word(self, tmp_path):
        txt = self._texto_word(tmp_path, skills=self.SKILLS)
        assert "ANÁLISIS TRANSVERSALES" in txt
        assert "Backtesting sin Christoffersen" in txt
        assert "retornos[-500:]" in txt, (
            "las citas de las skills no llegan al entregable")

    def test_una_skill_que_fallo_consta_en_el_word(self, tmp_path):
        """
        Una skill que no corrió es una limitación del ALCANCE. Omitirla haría
        parecer que el análisis fue completo.
        """
        txt = self._texto_word(tmp_path, skills=self.SKILLS)
        assert "NO EJECUTADO" in txt and "timeout" in txt

    def test_las_citas_no_verificadas_se_declaran_en_el_word(self, tmp_path):
        """
        Ese campo existe para que un hallazgo con cita inventada no pase por
        bueno. Escondido en el JSON quedaba sin efecto práctico.
        """
        txt = self._texto_word(tmp_path, skills=self.SKILLS)
        assert "NO se encontraron literalmente" in txt

    def test_sin_skills_no_se_pinta_el_anexo(self, tmp_path):
        assert "ANÁLISIS TRANSVERSALES" not in self._texto_word(tmp_path)
        assert "ANÁLISIS TRANSVERSALES" not in self._texto_word(tmp_path, skills=[])

    def test_agente_pasa_las_skills_al_word(self):
        """Que el renderizador exista no prueba que se invoque."""
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef) and n.name == "main")
        llamada = next(
            (n for n in ast.walk(fn) if isinstance(n, ast.Call)
             and getattr(n.func, "id", None) == "generar_word_informe"), None)
        assert llamada is not None
        assert "skills" in {k.arg for k in llamada.keywords}, (
            "el Word se genera sin las skills: se pagan y no se entregan")

    # ── Procedencia del corpus RAG en el entregable [PENDIENTE-4] ───────────

    def test_el_word_declara_que_el_corpus_no_es_oficial(self, tmp_path):
        """
        La entidad opera con documentos de apoyo, no con los textos oficiales.
        Esa decisión es defendible SOLO si el informe la declara: lo inadmisible
        no es usar resúmenes, es que el lector no pueda saber que lo son y tome
        un umbral de ahí como si fuera la norma.
        """
        txt = self._texto_word(
            tmp_path, agente_meta={"rag_dominio": "VaR",
                                   "rag_procedencia": "explicito"})
        assert "Procedencia del corpus de referencia" in txt
        assert "no de los textos oficiales" in txt
        assert "fuente primaria" in txt

    def test_el_word_dice_si_el_dominio_se_declaro_o_se_dedujo(self, tmp_path):
        txt = self._texto_word(
            tmp_path, agente_meta={"rag_dominio": "LaR",
                                   "rag_procedencia": "inferido"})
        assert "INFERIDO del título" in txt

    def test_sin_rag_no_se_advierte_de_un_corpus_que_no_se_uso(self, tmp_path):
        """Un aviso permanente se vuelve invisible: así se pierden los que importan."""
        txt = self._texto_word(
            tmp_path, agente_meta={"rag_dominio": "no_disponible"})
        assert "Procedencia del corpus de referencia" not in txt


# ═════════════════════════════════════════════════════════════════════════════
# REINTENTO ANTE RESPUESTA QUE NO CUMPLE EL CONTRATO
#
# Un JSON truncado perdía la actividad para siempre. Medido en la corrida real
# de VaR Mercado FRTB: 1 de 34 actividades perdida por un corte de generación
# en el carácter 8.064, y con ella `dictamen_confiable` pasó a false.
# ═════════════════════════════════════════════════════════════════════════════

class TestReintentoContrato:

    BUENA = json.dumps({"puntaje": 3, "concepto": "c", "observacion": "o",
                        "evidencia_encontrada": "", "preguntas_pendientes": [],
                        "recomendacion": "r"})

    @staticmethod
    def _evaluar(respuestas):
        """Ejecuta una actividad devolviendo `respuestas` en orden."""
        import modulos.motor_ia as M
        llamadas = {"n": 0}
        orig = M._llamar_modelo

        def _fake(prompt, *a, **kw):
            i = llamadas["n"]
            llamadas["n"] += 1
            return respuestas[min(i, len(respuestas) - 1)]

        M._llamar_modelo = _fake
        try:
            res = M.evaluar_actividad(
                actividad="a", ambito="Gobierno", control="c",
                contexto="ctx", titulo_modelo="ModeloX")
        finally:
            M._llamar_modelo = orig
        return res, llamadas["n"]

    def test_un_json_truncado_se_reintenta_y_se_recupera(self):
        """El caso EXACTO que se perdió en producción."""
        res, n = self._evaluar(['{"puntaje": 3, "concep', self.BUENA])
        assert n == 2, "no se reintentó"
        assert res.get("evaluacion_valida") is not False
        assert res.get("puntaje") == 3
        assert res.get("intentos_contrato") == 2

    def test_si_acierta_a_la_primera_no_gasta_de_mas(self):
        res, n = self._evaluar([self.BUENA])
        assert n == 1
        assert res.get("intentos_contrato") == 1

    def test_si_falla_siempre_se_declara_el_fallo_sin_inventar_puntaje(self):
        """
        El invariante 2 queda intacto: agotados los intentos, la actividad
        queda SIN puntaje y se reporta como fallo técnico. Reintentar no puede
        convertirse en una excusa para rellenar el hueco.
        """
        res, n = self._evaluar(['{"roto', '{"roto'])
        assert n == 2
        assert res.get("puntaje") is None
        assert res.get("evaluacion_valida") is False
        assert res.get("error_evaluacion")

    def test_un_contrato_incompleto_tambien_reintenta(self):
        """No solo el JSON roto: también al que le faltan campos obligatorios."""
        incompleta = json.dumps({"puntaje": 3})
        res, n = self._evaluar([incompleta, self.BUENA])
        assert n == 2
        assert res.get("puntaje") == 3

    def test_el_numero_de_intentos_es_configurable_y_central(self):
        """
        [CONFIG-CENTRAL] El proyecto ya pagó tener un parámetro declarado en dos
        sitios con defaults distintos.
        """
        from config import INTENTOS_CONTRATO as desde_config
        from modulos.motor_ia import INTENTOS_CONTRATO as desde_motor
        assert desde_config == desde_motor >= 2

    def test_los_errores_de_red_no_se_reintentan_aqui(self):
        """
        Tienen su propia política (`REINTENTOS_API`) en la capa HTTP.
        Duplicarla multiplicaría los intentos sin que nadie lo pidiera.
        """
        import modulos.motor_ia as M
        llamadas = {"n": 0}
        orig = M._llamar_modelo

        def _explota(prompt, *a, **kw):
            llamadas["n"] += 1
            raise ConnectionError("sin red")

        M._llamar_modelo = _explota
        try:
            res = M.evaluar_actividad(actividad="a", ambito="Gobierno",
                                      control="c", contexto="ctx",
                                      titulo_modelo="ModeloX")
        finally:
            M._llamar_modelo = orig
        assert llamadas["n"] == 1, "un error de red se reintentó dos veces"
        assert res.get("evaluacion_valida") is False


# ═════════════════════════════════════════════════════════════════════════════
# §3.4 · `.get(clave, respaldo)` NO actúa si la clave existe con valor nulo
#
# Encontrado en la corrida real del 2026-08-06: cinco de las ocho skills
# murieron con
#     TypeError: '<' not supported between instances of 'NoneType' and 'int'
# en cuanto UNA actividad quedó sin puntuar. El invariante 2 —«no se inventa un
# puntaje»— escribe `"puntaje": None`, con la clave presente. Es decir: el
# invariante que protege el dictamen era el que rompía las skills.
#
# Tercera y cuarta aparición de esta trampa en el proyecto.
# ═════════════════════════════════════════════════════════════════════════════

class TestPuntajeNuloNoRompeNada:

    #: El caso REAL: actividades puntuadas mezcladas con una que falló
    #: técnicamente y otra sin evidencia. Ambas con `puntaje` presente y nulo.
    EVALS = [
        {"ambito": "Metodología", "actividad": "a1", "puntaje": 4,
         "observacion": "correcto"},
        {"ambito": "Implementación", "actividad": "a2", "puntaje": None,
         "observacion": "", "evaluacion_valida": False,
         "error_evaluacion": "JSON malformado"},
        {"ambito": "Gobierno", "actividad": "a3", "puntaje": 2,
         "observacion": "falta acta"},
        {"ambito": "Uso e integración", "actividad": "a4", "puntaje": None,
         "observacion": "", "sin_evidencia": True},
    ]

    def test_las_skills_no_revientan_con_actividades_sin_puntaje(self):
        """
        EL fallo observado. Se recorren TODAS las skills, no solo la que se vio
        fallar: cinco distintas usan `_hallazgos_previos()`.
        """
        from modulos.skills import _ULTIMA, listar_skills, obtener_skill
        for s in listar_skills():
            nombre = s["nombre"] if isinstance(s, dict) else s
            clase = obtener_skill(nombre)
            kw = {"resultados_previos": []} if nombre == _ULTIMA else {}
            obj = clase("contexto", "ModeloX", self.EVALS, "", **kw)
            # No debe lanzar. Antes: TypeError al ordenar por puntaje.
            prompt = obj.construir_prompt()
            assert isinstance(prompt, str) and prompt

    def test_una_actividad_no_evaluada_no_se_presenta_como_cero(self):
        """
        Un «[None/5]» invitaría al modelo a leerlo como un cero, que es
        exactamente la confusión entre «no evaluable» e «incumple» que el
        invariante 3 existe para evitar.
        """
        from modulos.skills.catalogo import SkillCoherencia
        texto = SkillCoherencia("ctx", "M", self.EVALS)._hallazgos_previos()
        assert "None" not in texto
        assert "no evaluada — fallo técnico" in texto
        assert "sin evidencia" in texto

    def test_las_puntuadas_van_primero_y_de_peor_a_mejor(self):
        """
        El bloque existe para que la skill NO repita lo que el pipeline ya
        encontró: los hallazgos con puntaje son los que importan; una actividad
        sin puntuar no aporta hallazgo, solo declara una ausencia.
        """
        from modulos.skills.catalogo import SkillCoherencia
        lineas = [l for l in SkillCoherencia("ctx", "M", self.EVALS)
                  ._hallazgos_previos().splitlines() if l.strip()]
        assert lineas[0].startswith("  · [2/5]"), "no ordena peor primero"
        assert lineas[1].startswith("  · [4/5]")
        assert "[no evaluada" in lineas[2] or "[sin evidencia" in lineas[2]

    def test_el_bucle_de_feedback_no_revienta_con_puntaje_nulo(self):
        """
        Misma trampa, otra ruta: `diferencia = correcto - agente` con
        `agente=None` tumbaba la sesión de feedback. Se encontró revisando
        TODAS las rutas del patrón (§3.1), no solo la que falló.
        """
        fuente = (RAIZ / "modulos" / "feedback.py").read_text(encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert 'get("puntaje", 0)' not in vivas, (
            "vuelve el respaldo que no actúa ante un puntaje nulo")
        assert "puntaje_agente is None" in vivas, (
            "el bucle de feedback no comprueba el puntaje nulo antes de restar")

    def test_no_queda_el_patron_en_las_skills(self):
        """Por si alguien lo reintroduce al refactorizar el orden."""
        fuente = (RAIZ / "modulos" / "skills" / "base.py").read_text(
            encoding="utf-8")
        vivas = "\n".join(l for l in fuente.splitlines()
                          if not l.lstrip().startswith("#"))
        assert 'get("puntaje", 5)' not in vivas

    def test_una_skill_completa_corre_con_puntajes_nulos(self, monkeypatch):
        """
        Extremo a extremo por la ruta real de `SkillBase.ejecutar()`: prompt,
        llamada, parseo y verificación de citas. Es donde reventaba.
        """
        import modulos.motor_ia as M
        from modulos.skills.catalogo import SkillCoherencia

        monkeypatch.setattr(M, "_llamar_modelo", lambda *a, **k: json.dumps({
            "resumen": "ok",
            "discrepancias": [{"aspecto": "Ventana", "severidad": "baja",
                               "cita_doc": "ventana de 500 días"}]}))
        r = SkillCoherencia("=== manual.md ===\nventana de 500 días",
                            "ModeloX", self.EVALS).ejecutar()
        assert r["ok"] is True and r["error"] is None
        assert len(r["hallazgos"]) == 1


class TestCitasInventadasEnSkills:
    """
    La verificación de citas de las skills nunca se había visto actuar sobre
    evidencia real: la corrida que iba a probarlo se quedó sin crédito de API.
    Se cierra aquí con el modelo interceptado, que es lo único simulado — el
    contraste contra la evidencia es el real (`_verificar_citas`).
    """

    CONTEXTO = ("=== manual_VaR.md  [MANUAL METODOLÓGICO] ===\n"
                "VaR histórico con ventana de 500 días, nivel de confianza 99%, "
                "horizonte 1 día.\n"
                "Prueba de Kupiec y Christoffersen, mensual.\n")

    @staticmethod
    def _ejecutar(monkeypatch, cita):
        import modulos.motor_ia as M
        from modulos.skills.catalogo import SkillSupuestos
        monkeypatch.setattr(M, "_llamar_modelo", lambda *a, **k: json.dumps({
            "resumen": "r",
            "supuestos": [{"supuesto": "Estacionariedad", "severidad": "media",
                           "cita": cita}]}))
        return SkillSupuestos(TestCitasInventadasEnSkills.CONTEXTO,
                              "ModeloX", []).ejecutar()

    def test_una_cita_literal_se_verifica(self, monkeypatch):
        r = self._ejecutar(
            monkeypatch,
            "VaR histórico con ventana de 500 días, nivel de confianza 99%")
        assert r["ok"] is True
        assert r["citas_no_verificadas"] == [], (
            "una cita que SÍ está en la evidencia se marcó como dudosa: el "
            "aviso se volvería ruido y el equipo dejaría de mirarlo")

    def test_una_cita_inventada_se_declara(self, monkeypatch):
        """
        El caso que importa: un hallazgo que suena bien y cita algo que el
        modelo validado nunca escribió. En un informe firmado es una acusación
        falsa.
        """
        r = self._ejecutar(
            monkeypatch,
            "El manual establece una recalibración trimestral obligatoria "
            "aprobada por el Comité de Auditoría")
        assert r["ok"] is True, "la skill no debe fallar: el hallazgo se declara"
        assert len(r["citas_no_verificadas"]) == 1
        assert "recalibración trimestral" in r["citas_no_verificadas"][0]

    def test_una_respuesta_malformada_marca_la_skill_no_ejecutada(self, monkeypatch):
        """
        Una skill que falla NO tumba la corrida —es análisis adicional— pero
        tiene que constar como no ejecutada: si no, el informe parecería
        completo.
        """
        import modulos.motor_ia as M
        from modulos.skills.catalogo import SkillChallenger
        monkeypatch.setattr(M, "_llamar_modelo", lambda *a, **k: "{ roto")
        r = SkillChallenger("ctx", "ModeloX", []).ejecutar()
        assert r["ok"] is False
        assert r["error"] and "JSON" in r["error"].upper()
        assert r["hallazgos"] == []


class TestContratoDeSkillIncumplido:
    """
    Un JSON *válido* que no respeta el contrato de la skill.

    Es distinto del JSON roto de arriba: aquí el parseo funciona, así que el
    fallo no salta solo. Antes se resolvía con `hallazgos = []` en silencio, y
    entonces «el modelo incumplió el contrato» quedaba escrito en el informe
    como «esta skill no encontró nada». Eso es rellenar un hueco: el validador
    no puede distinguirlo de un análisis limpio.

    El pipeline principal declara FALLO TÉCNICO en el mismo caso; las skills
    tienen que ser coherentes con eso.
    """

    CTX = "Manual con contenido suficiente para construir el prompt. " * 30

    @staticmethod
    def _ejecutar(monkeypatch, payload):
        import modulos.motor_ia as M
        from modulos.skills.catalogo import SkillSintesis
        monkeypatch.setattr(M, "_llamar_modelo",
                            lambda *a, **k: json.dumps(payload, ensure_ascii=False))
        return SkillSintesis(TestContratoDeSkillIncumplido.CTX, "ModeloX", [],
                             "", resultados_previos=[]).ejecutar()

    def test_la_clave_del_contrato_ausente_se_declara(self, monkeypatch):
        """El caso observado: el modelo devuelve 'hallazgos' y la skill pedía
        'prioridades'."""
        r = self._ejecutar(monkeypatch, {
            "hallazgos": [{"titulo": "A", "severidad": "alta"}], "resumen": "ok"})
        assert r["ok"] is False, (
            "una respuesta que no trae la clave del contrato se estaba "
            "reportando como skill ejecutada con 0 hallazgos")
        assert "prioridades" in (r["error"] or "")

    def test_respuesta_vacia_se_declara(self, monkeypatch):
        r = self._ejecutar(monkeypatch, {})
        assert r["ok"] is False
        assert r["hallazgos"] == []

    def test_prosa_en_vez_de_lista_se_declara(self, monkeypatch):
        r = self._ejecutar(monkeypatch,
                           {"prioridades": "Hay tres asuntos críticos.",
                            "resumen": "ok"})
        assert r["ok"] is False
        assert "lista" in (r["error"] or "").lower()

    def test_clave_presente_pero_nula_se_declara(self, monkeypatch):
        """
        La trampa §3.9 otra vez: `.get(clave)` devuelve None tanto si la clave
        falta como si vale `null`. Sin centinela, este caso se colaba.
        """
        r = self._ejecutar(monkeypatch, {"prioridades": None, "resumen": "ok"})
        assert r["ok"] is False

    def test_una_lista_VACIA_es_legitima_y_no_falla(self, monkeypatch):
        """
        El control que impide que la corrección se pase de frenada.

        «Analicé y no encontré nada» es un resultado válido y frecuente. Si
        esto fallara, la skill que no tiene nada que reportar se marcaría como
        rota — un aviso que salta cuando no debe enseña a ignorar los avisos.
        """
        r = self._ejecutar(monkeypatch,
                           {"prioridades": [], "resumen": "nada que reportar"})
        assert r["ok"] is True
        assert r["hallazgos"] == []
        assert r["error"] is None

    def test_un_objeto_suelto_se_sigue_tolerando(self, monkeypatch):
        """Desviación inocua y frecuente: un dict en lugar de una lista de uno.
        Se envuelve, no se rechaza."""
        r = self._ejecutar(monkeypatch, {
            "prioridades": {"titulo": "A", "severidad": "alta"}, "resumen": "ok"})
        assert r["ok"] is True
        assert len(r["hallazgos"]) == 1


# ═════════════════════════════════════════════════════════════════════════════
# ANÁLISIS ESTÁTICO — hechos del código, sin modelo y sin ejecutar
#
# Complementa al juez LLM: éste extrae lo comprobable, aquél emite juicio. Es
# determinista, cuesta 0, y NO ejecuta el código del validado — que es la
# decisión de seguridad que lo hace admisible.
# ═════════════════════════════════════════════════════════════════════════════

class TestAnalisisEstatico:

    CODIGO = ("import numpy as np\n"
              "def var_historico(retornos, confianza=0.95, ventana=500):\n"
              "    return -np.percentile(retornos[-500:], (1 - confianza) * 100)\n")
    #: El manual dice 250 y 99%: discrepa del código en ambos.
    MANUAL_DISCREPA = ("VaR con ventana de 250 dias habiles al 99% de "
                       "confianza. Implementa backtesting_kupiec().")
    #: El manual coincide con el código: no debe producir hallazgos numéricos.
    MANUAL_COINCIDE = ("VaR con ventana de 500 dias, nivel de confianza 95%. "
                       "Usa el percentile empirico. Define var_historico().")

    def _analizar(self, tmp_path, codigo, manual):
        from modulos.analisis_estatico import analizar_arbol
        f = tmp_path / "calcula_var.py"
        f.write_text(codigo, encoding="utf-8")
        return analizar_arbol([f], manual, raiz=tmp_path, verbose=False)

    def test_no_ejecuta_el_codigo_del_validado(self):
        """
        La decisión de seguridad que hace admisible esto: el código viene del
        VALIDADO —la parte con incentivo en el resultado— y correría con los
        permisos del validador, en la máquina que guarda audit_logs/ y
        outputs/. Un script podría alterar la evidencia de su propia validación.
        """
        fuente = (RAIZ / "modulos" / "analisis_estatico.py").read_text(
            encoding="utf-8")
        prohibidos = []
        for n in ast.walk(ast.parse(fuente)):
            if isinstance(n, ast.Call):
                f = getattr(n.func, "id", None) or getattr(n.func, "attr", None)
                if f in ("exec", "eval", "compile", "run", "Popen", "system",
                         "check_output", "import_module", "__import__"):
                    prohibidos.append(f"{f}() en línea {n.lineno}")
        assert not prohibidos, (
            "el análisis estático ejecuta código: " + "; ".join(prohibidos))

    def test_detecta_parametros_que_discrepan(self, tmp_path):
        c = self._analizar(tmp_path, self.CODIGO, self.MANUAL_DISCREPA)
        elementos = {h["elemento"] for h in c["hallazgos"]}
        assert "var_historico(ventana=500)" in elementos
        assert "var_historico(confianza=0.95)" in elementos

    def test_no_inventa_discrepancias_cuando_coinciden(self, tmp_path):
        """
        Lo más importante: si el manual declara los mismos valores, NO puede
        haber hallazgo de parámetro. Un falso positivo aquí enseñaría al equipo
        a desactivar el flag, y con él se perderían los verdaderos.
        """
        c = self._analizar(tmp_path, self.CODIGO, self.MANUAL_COINCIDE)
        cats = {h["categoria"] for h in c["hallazgos"]}
        assert "parametro_no_documentado" not in cats
        assert "ventana_no_documentada" not in cats

    def test_el_porcentaje_del_manual_equivale_al_decimal_del_codigo(self, tmp_path):
        """
        Un `0.95` en el código se escribe «95%» en un manual. Sin esa
        equivalencia, un parámetro correctamente documentado se reportaría
        como ausente.
        """
        c = self._analizar(tmp_path, self.CODIGO, self.MANUAL_COINCIDE)
        assert not [h for h in c["hallazgos"]
                    if "confianza" in str(h["elemento"])]

    def test_funcion_documentada_que_no_existe_es_inequivoca(self, tmp_path):
        """Único caso con severidad `alta`: o está definida o no."""
        c = self._analizar(tmp_path, self.CODIGO, self.MANUAL_DISCREPA)
        g = [h for h in c["hallazgos"]
             if h["categoria"] == "funcion_documentada_ausente"]
        assert len(g) == 1
        assert g[0]["elemento"] == "backtesting_kupiec"
        assert g[0]["severidad"] == "alta"

    def test_se_calcula_sobre_el_arbol_completo_no_por_fichero(self, tmp_path):
        """
        Decir que falta una función mirando un solo módulo sería falso en
        cuanto estuviera en otro — el error que cometería un revisor leyendo
        un fichero aislado.
        """
        from modulos.analisis_estatico import analizar_arbol
        (tmp_path / "a.py").write_text("def var_historico(): pass\n",
                                       encoding="utf-8")
        (tmp_path / "b.py").write_text("def backtesting_kupiec(): pass\n",
                                       encoding="utf-8")
        c = analizar_arbol(sorted(tmp_path.glob("*.py")), self.MANUAL_DISCREPA,
                           raiz=tmp_path, verbose=False)
        assert not [h for h in c["hallazgos"]
                    if h["categoria"] == "funcion_documentada_ausente"], (
            "reporta como ausente una función definida en OTRO módulo")

    def test_los_indicios_nunca_son_severidad_alta(self, tmp_path):
        """
        Que un número no aparezca en el manual es señal fuerte, pero que
        aparezca no prueba que se refiera a ese parámetro. Inflar la severidad
        de un indicio convierte el informe en ruido.
        """
        c = self._analizar(tmp_path, self.CODIGO, self.MANUAL_DISCREPA)
        for h in c["hallazgos"]:
            if h["categoria"] in ("parametro_no_documentado",
                                  "ventana_no_documentada",
                                  "metodo_no_documentado"):
                assert h["severidad"] == "media"

    def test_declara_lo_que_no_puede_resolver(self, tmp_path):
        """Un valor calculado no es una constante: se declara, no se adivina."""
        c = self._analizar(tmp_path,
                           "def f(retornos, n):\n    return retornos[-n:]\n",
                           "manual")
        assert [h for h in c["hallazgos"] if h["categoria"] == "no_determinable"]

    def test_la_aleatoriedad_sin_semilla_es_alta(self, tmp_path):
        """Sin semilla, dos corridas difieren y el backtesting no es comparable."""
        c = self._analizar(
            tmp_path,
            "import numpy as np\ndef sim():\n    return np.random.normal(0,1,10)\n",
            "manual")
        r = [h for h in c["hallazgos"] if h["categoria"] == "reproducibilidad"]
        assert len(r) == 1 and r[0]["severidad"] == "alta"

    def test_con_semilla_no_se_reporta(self, tmp_path):
        c = self._analizar(
            tmp_path,
            "import numpy as np\nnp.random.seed(42)\ndef sim():\n"
            "    return np.random.normal(0,1,10)\n", "manual")
        assert not [h for h in c["hallazgos"]
                    if h["categoria"] == "reproducibilidad"]

    def test_el_log_muestra_los_hechos_aunque_no_haya_hallazgos(self, tmp_path):
        """
        Un fichero «sin hallazgos» no dice lo mismo que uno del que se sabe qué
        define y con qué parámetros: lo segundo lo verifica un humano en diez
        segundos, lo primero hay que creérselo.
        """
        from modulos.analisis_estatico import informe_markdown
        c = self._analizar(tmp_path, self.CODIGO, self.MANUAL_COINCIDE)
        md = informe_markdown(c, "ModeloX")
        assert "var_historico(retornos, confianza=0.95, ventana=500)" in md
        assert "NO se ejecutó el código" in md
        assert "Qué NO puede ver este análisis" in md

    def test_el_flag_existe_y_agente_lo_usa(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert '"--analizar-codigo"' in fuente
        fn = next(n for n in ast.walk(ast.parse(fuente))
                  if isinstance(n, ast.FunctionDef) and n.name == "main")
        llamadas = [(getattr(n.func, "id", None) or getattr(n.func, "attr", None))
                    for n in ast.walk(fn) if isinstance(n, ast.Call)]
        assert "analizar_arbol" in llamadas


# ═════════════════════════════════════════════════════════════════════════════
# RESULTADOS POR CELDA DE UN NOTEBOOK
#
# Un `.ipynb` guarda `execution_count` y los `outputs` de cada celda: quien lo
# ejecutó dejó ahí la evidencia. Se lee a coste 0 y SIN ejecutar nada.
# ═════════════════════════════════════════════════════════════════════════════

class TestResultadosPorCeldaNotebook:

    @staticmethod
    def _celda(src, ec=None, error=None):
        c = {"cell_type": "code", "source": [src], "execution_count": ec,
             "outputs": [], "metadata": {}}
        if error:
            c["outputs"] = [{"output_type": "error", "ename": error[0],
                             "evalue": error[1], "traceback": []}]
        return c

    def _analizar(self, tmp_path, celdas, nombre="nb.ipynb"):
        from modulos.analisis_estatico import analizar_modulo
        p = tmp_path / nombre
        p.write_text(json.dumps({"cells": celdas, "metadata": {},
                                 "nbformat": 4, "nbformat_minor": 5}),
                     encoding="utf-8")
        return analizar_modulo(p, "manual sin coincidencias")

    def _cats(self, res):
        return {h["categoria"]: h for h in res["hallazgos"]}

    def test_un_notebook_limpio_no_genera_ruido(self, tmp_path):
        """
        Si corrió entero y en orden, ninguna de las tres comprobaciones debe
        disparar. Un aviso que salta siempre deja de leerse.
        """
        r = self._analizar(tmp_path, [self._celda("x = 1", 1),
                                      self._celda("y = 2", 2),
                                      self._celda("print(x + y)", 3)])
        cats = self._cats(r)
        for c in ("notebook_sin_ejecutar", "notebook_con_excepcion",
                  "orden_ejecucion_roto"):
            assert c not in cats
        assert r["hechos"]["notebook"]["n_ejecutadas"] == 3

    def test_notebook_sin_ejecutar_es_alta(self, tmp_path):
        """No acredita nada: es código entregado, no evidencia de ejecución."""
        r = self._analizar(tmp_path, [self._celda("x = 1"),
                                      self._celda("y = 2")])
        h = self._cats(r)["notebook_sin_ejecutar"]
        assert h["severidad"] == "alta"
        assert "ninguna" in h["elemento"]

    def test_algunas_celdas_sin_ejecutar_es_media(self, tmp_path):
        """
        Distinto de no haber corrido nada: puede ser una celda exploratoria.
        Se reporta, pero no con la misma gravedad.
        """
        r = self._analizar(tmp_path, [self._celda("x = 1", 1),
                                      self._celda("y = 2")])
        assert self._cats(r)["notebook_sin_ejecutar"]["severidad"] == "media"

    def test_una_excepcion_guardada_es_hallazgo(self, tmp_path):
        """Un traceback en un notebook entregado como evidencia."""
        r = self._analizar(tmp_path, [
            self._celda("import pandas", 1),
            self._celda("df['fecha']", 2, ("KeyError", "'fecha'"))])
        h = self._cats(r)["notebook_con_excepcion"]
        assert h["severidad"] == "alta"
        assert "KeyError" in h["elemento"]

    def test_orden_de_ejecucion_alterado_es_alta(self, tmp_path):
        """
        `[1, 5, 3]`: el estado que muestra el notebook no corresponde a NINGUNA
        ejecución de arriba abajo. Reejecutarlo desde cero puede dar otra cosa.
        """
        r = self._analizar(tmp_path, [self._celda("x = 1", 1),
                                      self._celda("y = 2", 5),
                                      self._celda("z = 3", 3)])
        h = self._cats(r)["orden_ejecucion_roto"]
        assert h["severidad"] == "alta"
        assert "reproducibilidad" in h["descripcion"].lower()

    def test_una_celda_vacia_no_cuenta_como_sin_ejecutar(self, tmp_path):
        """No hay nada que correr: contarla sería un hallazgo por un hueco."""
        r = self._analizar(tmp_path, [self._celda("x = 1", 1),
                                      self._celda("   \n"),
                                      self._celda("")])
        assert r["hechos"]["notebook"]["n_celdas_codigo"] == 1
        assert "notebook_sin_ejecutar" not in self._cats(r)

    def test_los_hechos_se_extraen_aunque_el_codigo_no_compile(self, tmp_path):
        """
        Un notebook con una celda rota sigue diciendo si se ejecutó y con qué
        excepciones. Perder eso por un error de sintaxis sería descartar la
        evidencia más directa que hay.
        """
        r = self._analizar(tmp_path, [
            self._celda("def roto(:", 1, ("SyntaxError", "invalid syntax"))])
        assert "notebook_con_excepcion" in self._cats(r)
        assert r["hechos"].get("notebook", {}).get("n_ejecutadas") == 1

    def test_el_log_declara_la_ejecucion_aunque_este_limpia(self, tmp_path):
        """
        «12 de 12 ejecutadas, orden correcto» es información que el validador
        quiere ver afirmada, no deducida del silencio.
        """
        from modulos.analisis_estatico import analizar_arbol, informe_markdown
        p = tmp_path / "nb.ipynb"
        p.write_text(json.dumps({
            "cells": [self._celda("x = 1", 1), self._celda("y = 2", 2)],
            "metadata": {}, "nbformat": 4, "nbformat_minor": 5}),
            encoding="utf-8")
        md = informe_markdown(
            analizar_arbol([p], "manual", raiz=tmp_path, verbose=False), "M")
        assert "**Ejecución:** 2/2 celdas ejecutadas" in md
        assert "orden correcto" in md

    def test_no_se_ejecuta_el_notebook_para_saberlo(self):
        """
        Todo esto sale de metadatos que el fichero ya guarda. El test de
        `TestAnalisisEstatico` que prohíbe exec/eval sigue cubriendo el módulo
        entero, incluida esta parte.
        """
        fuente = (RAIZ / "modulos" / "analisis_estatico.py").read_text(
            encoding="utf-8")
        assert "execution_count" in fuente
        assert "ExecutePreprocessor" not in fuente and "nbclient" not in fuente


# ═════════════════════════════════════════════════════════════════════════════
# PRESENTACIÓN DEL INFORME WORD
#
# Tipografía corporativa, justificación, bloques de código con aspecto de
# celda, notas al pie de procedencia y logo de portada. Se comprueba sobre el
# .docx REALMENTE generado —abriendo el paquete—, no sobre el código que lo
# escribe: un informe que no abre es el fallo que más caro sale, y ya ocurrió
# una vez durante este trabajo.
# ═════════════════════════════════════════════════════════════════════════════

class TestPresentacionWord:

    @staticmethod
    def _doc():
        from docx import Document
        from modulos import word_estilo as W
        d = Document()
        W.aplicar_estilo_documento(d)
        return d, W

    def test_el_paquete_generado_es_valido_y_reabrible(self, tmp_path):
        """
        El control que más importa: que el fichero ABRA.

        Durante este trabajo se produjo un .docx que Word rechazaba en bloque
        —sin decir por qué— y costó localizarlo. Cualquier retoque de XML
        crudo (notas al pie, tabla de fuentes, settings) puede reproducirlo.
        """
        from docx import Document
        d, W = self._doc()
        p = d.add_paragraph()
        W.justificar(p)
        r = p.add_run("Prosa de prueba con longitud suficiente para justificar.")
        W.aplicar_fuente(r)
        W.add_nota_pie(d, p, "Contrastado con manual_VaR_FRTB.md")
        W.add_bloque_codigo(d, "def f(x):\n    return x", linea_inicial=10)
        ruta = tmp_path / "x.docx"
        d.save(ruta)
        Document(str(ruta))            # revienta si el paquete es inválido

    def test_el_estilo_normal_pide_la_fuente_corporativa_y_justifica(self):
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        d, W = self._doc()
        normal = d.styles["Normal"]
        assert normal.font.name == W.FUENTE_TEXTO
        assert normal.paragraph_format.alignment == WD_ALIGN_PARAGRAPH.JUSTIFY

    def test_se_declara_la_fuente_de_respaldo_en_el_documento(self, tmp_path):
        """
        Sin `altName`, Word sustituye la corporativa ausente por una serifa de
        su elección. Estuvo roto: la tabla de fuentes se buscaba en el paquete
        y cuelga de la parte documento, así que no se escribía nada — y en
        silencio.
        """
        import zipfile
        d, W = self._doc()
        d.add_paragraph("x")
        ruta = tmp_path / "f.docx"
        d.save(ruta)
        ft = zipfile.ZipFile(ruta).read("word/fontTable.xml").decode("utf-8")
        assert W.FUENTE_TEXTO in ft, "la fuente corporativa no se declara"
        assert W.FUENTE_RESPALDO in ft, "el respaldo no se declara"

    def test_el_codigo_NO_se_justifica(self):
        """
        El control contra el defecto que motivó el encargo: el código salía
        justificado, estirado de margen a margen, y así no se puede leer
        literal — que es su único cometido como evidencia.
        """
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        d, W = self._doc()
        n0 = len(d.paragraphs)
        W.add_bloque_codigo(d, "def f(x):\n    return x")
        nuevos = d.paragraphs[n0:]
        assert nuevos, "no se generó el bloque"
        for p in nuevos:
            assert p.alignment == WD_ALIGN_PARAGRAPH.LEFT, (
                "una línea de código quedó justificada")

    def test_el_bloque_de_codigo_numera_desde_la_linea_real(self):
        d, W = self._doc()
        n0 = len(d.paragraphs)
        W.add_bloque_codigo(d, "a = 1\nb = 2", linea_inicial=14)
        txt = "".join(p.text for p in d.paragraphs[n0:])
        assert "14" in txt and "15" in txt, (
            "sin números de línea, un hallazgo que acusa a fichero:14 no se "
            "puede comprobar sin contar a mano")

    def test_las_vallas_markdown_se_separan_de_la_prosa(self):
        from modulos.generador_word import _partir_por_vallas
        tramos = _partir_por_vallas("Antes.\n```python\ndef f():\n    pass\n```\nDespués.")
        assert [e for e, _ in tramos] == [False, True, False]
        assert "def f()" in tramos[1][1]
        assert "```" not in tramos[1][1] and "python" not in tramos[1][1]

    def test_sin_vallas_no_se_adivina_que_es_codigo(self):
        """
        Adivinar por heurística convertiría cualquier frase técnica en un
        bloque monoespaciado. Sin vallas, todo es prosa.
        """
        from modulos.generador_word import _partir_por_vallas
        assert _partir_por_vallas("El método percentile(x) devuelve...") == [
            (False, "El método percentile(x) devuelve...")]

    def test_la_nota_al_pie_solo_nombra_ficheros_reales(self):
        """
        El modelo escribe a veces «CONTEXTO DISPONIBLE» como si fuera una
        fuente. Una nota que lo citara mandaría al auditor a buscar un
        documento inexistente.
        """
        from modulos.generador_word import _procedencia_nota
        nota = _procedencia_nota({
            "evidencia_encontrada": 'manual_VaR_FRTB.md → "algo"',
            "inconsistencias": [{"fuente_a": "CONTEXTO DISPONIBLE",
                                 "fuente_b": "calcula_var.py"}],
            "rag_dominio": "VaR", "rag_chunks": 3,
            "rag_procedencia": "explicito", "cobertura_documental": 100.0,
        })
        assert "manual_VaR_FRTB.md" in nota and "calcula_var.py" in nota
        assert "CONTEXTO DISPONIBLE" not in nota
        assert "declarado" in nota, "la procedencia del dominio debe constar"

    def test_un_dominio_inferido_no_se_presenta_como_declarado(self):
        from modulos.generador_word import _procedencia_nota
        nota = _procedencia_nota({"rag_dominio": "VaR", "rag_chunks": 2,
                                  "rag_procedencia": "inferido"})
        assert "inferido" in nota

    def test_las_notas_al_pie_son_notas_de_word_de_verdad(self, tmp_path):
        """No texto pequeño al final: la parte OPC que Word reconoce."""
        import zipfile
        d, W = self._doc()
        p = d.add_paragraph()
        p.add_run("texto")
        W.add_nota_pie(d, p, "backtesting_VaR_2026Q1.md")
        ruta = tmp_path / "n.docx"
        d.save(ruta)
        z = zipfile.ZipFile(ruta)
        assert "word/footnotes.xml" in z.namelist()
        ct = z.read("[Content_Types].xml").decode("utf-8")
        assert "footnotes+xml" in ct
        fx = z.read("word/footnotes.xml").decode("utf-8")
        # Los dos separadores que Word exige antes de cualquier nota real.
        assert 'w:id="-1"' in fx and 'w:id="0"' in fx
        assert "backtesting_VaR_2026Q1.md" in fx

    def test_el_logo_webp_se_convierte_a_un_formato_que_word_admite(self):
        """Word no abre .webp, que es el formato del logo de la entidad."""
        from modulos import word_estilo as W
        logo = W.localizar_logo()
        if logo is None:
            import pytest
            pytest.skip("sin logo en inputs/logoempresa/")
        buf = W.logo_para_word(logo)
        assert buf is not None
        assert buf.getvalue()[:8] == b"\x89PNG\r\n\x1a\n"

    def test_sin_logo_el_informe_no_lleva_imagen_alguna(self, tmp_path,
                                                        monkeypatch):
        """
        Un recuadro de «imagen no encontrada» es peor que no poner logo.

        Se fuerza la ausencia interceptando el localizador: `localizar_logo`
        cae a la raíz del proyecto a propósito —para que el logo aparezca se
        lance el agente desde donde se lance—, así que pasarle una carpeta
        vacía NO produce ausencia.
        """
        import zipfile
        from modulos import generador_word as G
        monkeypatch.setattr(G._WE, "localizar_logo", lambda *a, **k: None)
        ruta = G.generar_word_informe(
            "", {"Metodología": [{"actividad": "A", "puntaje": 3,
                                  "concepto": "c", "observacion": "o"}]},
            {"Metodología": 3.0}, 3.0, "M", "1", tmp_path)
        medios = [n for n in zipfile.ZipFile(ruta).namelist()
                  if n.startswith("word/media/")]
        assert medios == [], f"se insertó una imagen sin logo: {medios}"


# ═════════════════════════════════════════════════════════════════════════════
# CONTROLES AUTOMÁTICOS DE CALIDAD DE DATOS
#
# La sección tenía tres defectos encadenados, y el peor no era el que se veía:
#   1. Los hallazgos llegaban al informe como `repr` de diccionarios de Python.
#   2. `estado == "OK"` (= el control SE EJECUTÓ) se traducía a puntaje 5
#      (= el modelo CUMPLE), ignorando la puntuación real. Los cuatro controles
#      del 2026-08-03 salían 5/5 con puntuaciones reales de 1.0/2.65/4.35/3.0.
#   3. `hallazgos[:5]` descartaba el resto sin declararlo.
# ═════════════════════════════════════════════════════════════════════════════

class TestControlesCalidadDatos:

    @staticmethod
    def _cdd(**kw):
        base = {"control_id": "Control_01", "estado": "OK", "score": 1.0,
                "revision": "Deficiencias críticas de completitud.",
                "prompt_control": "Valida que el manual describa el origen.",
                "hallazgos": [
                    {"tipo": "OBSERVACION", "texto": "Manual incompleto.",
                     "recomendacion": "Completar el manual.",
                     "riesgo": "Alto", "criticidad": "CRITICA"}]}
        base.update(kw)
        return {"resultados_por_control": {base["control_id"]: base}}

    def _una(self, **kw):
        from modulos.control_evaluacion_data import evaluaciones_desde_controles
        return evaluaciones_desde_controles(self._cdd(**kw))[0]

    # ── El defecto visible ──────────────────────────────────────────────────
    def test_no_se_vuelca_el_repr_de_un_diccionario(self):
        ev = self._una()
        for campo in ("observacion", "concepto", "recomendacion"):
            assert "{'tipo'" not in ev[campo] and "'criticidad':" not in ev[campo], (
                f"{campo} contiene el repr de un dict de Python")

    def test_los_hallazgos_llegan_estructurados_e_integros(self):
        """`hallazgos[:5]` descartaba el resto en silencio."""
        muchos = [{"tipo": "OBSERVACION", "texto": f"h{i}",
                   "recomendacion": f"r{i}", "riesgo": "Alto",
                   "criticidad": "CRITICA"} for i in range(9)]
        ev = self._una(hallazgos=muchos)
        assert len(ev["hallazgos_cdd"]) == 9, "se perdieron hallazgos"
        assert "9 hallazgo(s)" in ev["observacion"]

    def test_las_recomendaciones_no_se_tiran(self):
        """Se fijaban a "" pese a que cada hallazgo trae la suya."""
        assert "Completar el manual" in self._una()["recomendacion"]

    # ── El defecto que inflaba el dictamen ──────────────────────────────────
    def test_estado_OK_no_significa_cumple_plenamente(self):
        """
        `estado` dice si el control SE PUDO EVALUAR; `score` dice si el modelo
        CUMPLE. Confundirlos daba 5/5 a un control con puntuación 1.0 y cuatro
        hallazgos críticos.
        """
        assert self._una(estado="OK", score=1.0)["puntaje"] == 1
        assert self._una(estado="OK", score=4.35)["puntaje"] == 4

    def test_un_fallo_tecnico_no_se_imputa_al_validado(self):
        """
        §3.3: ERROR es un fallo NUESTRO. Antes puntuaba 1 —el peor puntaje—
        y arrastraba el score del validado por una avería del agente.
        """
        ev = self._una(estado="ERROR", score=None)
        assert ev["puntaje"] is None
        assert ev.get("evaluacion_valida") is False
        assert ev.get("sin_evidencia") is not True

    def test_sin_evidencia_puntua_cero_y_no_se_excluye(self):
        """
        §3.3: la falta de evidencia SÍ es imputable al validado y debe arrastrar
        el score con su peso íntegro. No es un fallo técnico.
        """
        ev = self._una(estado="PARTIAL", score=None)
        assert ev["puntaje"] == 0
        assert ev.get("sin_evidencia") is True
        assert ev.get("evaluacion_valida") is not False

    def test_evaluado_sin_puntuacion_no_se_rellena_con_un_valor(self):
        """El invariante de siempre: antes declarar la ausencia que inventar."""
        ev = self._una(estado="OK", score=None)
        assert ev["puntaje"] is None
        assert ev.get("evaluacion_valida") is False

    # ── Presentación ────────────────────────────────────────────────────────
    def test_concepto_y_observacion_no_son_el_mismo_texto(self):
        """Se imprimía el mismo párrafo largo dos veces, bajo dos epígrafes."""
        ev = self._una()
        assert ev["concepto"].strip() != ev["observacion"].strip()

    def test_el_encabezado_no_se_parte_a_media_palabra(self):
        ev = self._una(prompt_control="Valida " + "palabra " * 60)
        assert not ev["actividad"].rstrip("…").endswith("palabr")
        assert len(ev["actividad"]) < 160

    def test_el_encabezado_descarta_el_preambulo_de_evidencia(self):
        """
        Algunos controles empiezan describiendo dónde está la evidencia. Eso
        no es el enunciado del control y llenaba el título de ruido.
        """
        ev = self._una(prompt_control=(
            "En la carpeta de evidencia tienes archivos relacionados con este "
            "control: (1) Manual y (2) script. Valida la unicidad por cuenta."))
        assert "Valida la unicidad por cuenta" in ev["actividad"]
        assert "carpeta de evidencia" not in ev["actividad"]

    def test_los_hallazgos_se_ordenan_por_criticidad_en_el_word(self, tmp_path):
        from docx import Document
        from modulos.generador_word import _add_hallazgos_cdd
        d = Document()
        _add_hallazgos_cdd(d, [
            {"texto": "leve", "criticidad": "BAJA", "tipo": "OBSERVACION"},
            {"texto": "grave", "criticidad": "CRITICA", "tipo": "OBSERVACION"},
            {"texto": "media", "criticidad": "MODERADA", "tipo": "OBSERVACION"}])
        txt = "\n".join(p.text for p in d.paragraphs)
        assert txt.index("grave") < txt.index("media") < txt.index("leve"), (
            "en un informe de 16 hallazgos, lo crítico debe ir arriba")

    def test_la_criticidad_se_rotula_ademas_de_colorearse(self, tmp_path):
        """Un informe en blanco y negro debe seguir diciendo qué es grave."""
        from docx import Document
        from modulos.generador_word import _add_hallazgos_cdd
        d = Document()
        _add_hallazgos_cdd(d, [{"texto": "x", "criticidad": "CRITICA",
                                "tipo": "OBSERVACION"}])
        assert "[CRITICA]" in "\n".join(p.text for p in d.paragraphs)


# ═════════════════════════════════════════════════════════════════════════════
# AUDITORÍA INTEGRAL 2026-08-07 — hallazgos F-01 … F-15
#
# Cada test fija un invariante que la auditoría encontró roto. Criterio para
# elegirlos: solo los que, al fallar, producen un VEREDICTO incorrecto o una
# afirmación falsa en el expediente. Lo cosmético no se testea.
# ═════════════════════════════════════════════════════════════════════════════

class TestAuditoriaIntegral20260807:

    # ── F-01 · determinismo ─────────────────────────────────────────────────
    def test_la_llamada_al_modelo_fija_la_temperatura(self):
        """
        Sin `temperature`, Anthropic usa 1.0 y la misma evidencia puede dar dos
        dictámenes distintos. Sellar un informe irreproducible acredita que el
        fichero no se alteró, no que el juicio sea repetible.
        """
        from config.ia import ClienteAnthropicIA
        from config import IA_TEMPERATURE
        cli = ClienteAnthropicIA.__new__(ClienteAnthropicIA)
        cli.modelo, cli.max_tokens_default = "modelo-x", 100
        capt = {}

        class _M:
            def create(self, **kw):
                capt.update(kw)
                raise RuntimeError("corte")

        class _C:
            messages = _M()

        cli.cliente = _C()
        try:
            cli.generar_mensaje("hola")
        except Exception:
            pass
        assert "temperature" in capt, "la llamada no fija temperature"
        assert capt["temperature"] == IA_TEMPERATURE == 0.0

    # ── F-02 · un fallo técnico no se imputa al validado ────────────────────
    def test_el_markdown_no_puntua_un_fallo_tecnico_como_1(self):
        from modulos.generador_markdown import _pj
        assert _pj({"puntaje": None, "evaluacion_valida": False}) is None
        assert _pj({"puntaje": 1, "evaluacion_valida": True}) == 1, (
            "un 'No cumple' REAL debe seguir valiendo 1")

    def test_las_preguntas_de_un_fallo_tecnico_no_van_al_modelador(self):
        """«Re-ejecutar y verificar la cuota de la API» es nuestro, no suyo."""
        from modulos.generador_markdown import _pedidos
        d = {"resultados_por_ambito": {"M": [
            {"actividad": "A", "puntaje": None, "evaluacion_valida": False,
             "preguntas_pendientes": ["Re-ejecutar y verificar la cuota de API"]},
            {"actividad": "B", "puntaje": 2,
             "preguntas_pendientes": ["Aportar el manual"]},
        ]}}
        texto = "\n".join(_pedidos(d))
        assert "Aportar el manual" in texto
        assert "cuota de API" not in texto

    # ── F-03 · sin firmante no hay entregable ───────────────────────────────
    def test_una_corrida_sin_firmante_no_se_sella_como_entregable(self):
        """
        Lanzar `--analizar-codigo` dejaba en el registro append-only una línea
        `tipo_corrida: entregable` con `validador: (no registrado)`: un
        entregable que nadie emitió ni firmó, e imborrable.
        """
        norm = " ".join((RAIZ / "agente.py").read_text(encoding="utf-8").split())
        assert "_hay_firmante" in norm, "no se decide el tipo de corrida"
        assert "tipo=_tipo_corrida" in norm, (
            "sellar_y_escribir se llama sin declarar el tipo de corrida")

    # ── F-04/F-05 · el RAG declara lo que NO conoce ─────────────────────────
    def test_el_bloque_rag_declara_los_terminos_que_el_corpus_no_conoce(self):
        """
        La cobertura se divide entre los términos con IDF > 0, o sea excluye del
        denominador justo los que el corpus ignora. Medido: una consulta de
        scoring crediticio contra el corpus VaR devolvía un PDF de riesgo de
        mercado rotulado «cubre el 100% de los términos clave».
        """
        import pytest
        from src.rag.buscador_lexico import BuscadorLexico
        bloque = BuscadorLexico("VaR").buscar_para_prompt(
            "modelo de scoring de admision de tarjetas de credito", top_k=1)
        if not bloque.strip():
            pytest.skip("el corpus VaR no devolvió nada para esta consulta")
        assert "ALCANCE DE ESTE CORPUS" in bloque, (
            "no se declara qué parte de la consulta el corpus no cubre")
        assert "términos clave que este corpus conoce" in bloque, (
            "el rótulo sigue sugiriendo cobertura de TODA la consulta")

    def test_los_resultados_traen_el_reconocimiento_de_la_consulta(self):
        import pytest
        from src.rag.buscador_lexico import BuscadorLexico
        r = BuscadorLexico("VaR").buscar("backtesting de Kupiec", top_k=1)
        if not r:
            pytest.skip("sin resultados")
        assert "reconocimiento_consulta" in r[0]
        assert "terminos_no_reconocidos" in r[0]

    # ── F-06 · la memoria inter-ámbito llega entera ─────────────────────────
    def test_la_memoria_inter_ambito_no_se_trunca_ni_se_descarta(self, monkeypatch):
        """
        Iba disfrazada de «actividad» dentro de `contexto_ambito`: se truncaba a
        60 chars y, con ≥4 hallazgos previos, el `[-4:]` la descartaba entera.
        El modelo leía la cabecera de un contexto que nunca recibía.
        """
        import modulos.motor_ia as M
        cap = {}

        def _fake(prompt, *a, **k):
            cap["p"] = prompt
            raise RuntimeError("corte")

        monkeypatch.setattr(M, "_llamar_modelo", _fake)
        bloque = ("\nCONTEXTO INTER-ÁMBITO:\n"
                  "  [Metodologia] Kupiec\n    -> [2/5] No documenta la ventana.\n"
                  "  [Calidad de datos] Linaje\n    -> [1/5] Sin origen de precios.\n")
        previos = [{"ambito": "M", "actividad": f"Act {i}", "puntaje": 3,
                    "observacion": f"Obs {i}"} for i in range(6)]
        try:
            M.evaluar_actividad(actividad="A", ambito="Gobierno", control="C",
                                contexto="manual " * 200, titulo_modelo="M",
                                contexto_ambito=previos,
                                bloque_inter_ambito=bloque)
        except Exception:
            pass
        p = cap.get("p", "")
        assert "CONTEXTO INTER-ÁMBITO" in p, "el bloque global desapareció"
        assert "Sin origen de precios" in p, (
            "el bloque llegó truncado: falta el segundo hallazgo")

    def test_la_memoria_intra_ambito_no_imprime_None_sobre_5(self, monkeypatch):
        """Trampa §3.9: `.get('puntaje','?')` no actúa si la clave vale None."""
        import modulos.motor_ia as M
        cap = {}

        def _fake(prompt, *a, **k):
            cap["p"] = prompt
            raise RuntimeError("corte")

        monkeypatch.setattr(M, "_llamar_modelo", _fake)
        try:
            M.evaluar_actividad(actividad="A", ambito="Gobierno", control="C",
                                contexto="manual " * 200, titulo_modelo="M",
                                contexto_ambito=[{"actividad": "X",
                                                  "puntaje": None,
                                                  "observacion": "o"}])
        except Exception:
            pass
        assert "[None/5]" not in cap.get("p", "")

    # ── F-09 · el informe declara con qué corpus se juzgó ───────────────────
    def test_el_informe_registra_la_huella_del_corpus_rag(self):
        fuente = (RAIZ / "agente.py").read_text(encoding="utf-8")
        assert "rag_corpus_huella" in fuente, (
            "dos informes con «dominio: VaR» serían indistinguibles aunque se "
            "apoyaran en corpus distintos")

    # ── F-10 · el tier tiene que cambiar el alcance ─────────────────────────
    def test_el_tier_cambia_el_alcance_evaluado(self):
        from modulos.motor_ia import leer_estandares_virf
        req = {}
        for t in ("1", "2", "3", "4"):
            r = leer_estandares_virf(t) or {}
            req[t] = sum(1 for v in r.values() for a in v
                         if a.get("requerida", True))
        assert len(set(req.values())) > 1, (
            f"los 4 tiers exigen lo mismo ({req}): un Tier 4 se validaría "
            f"como un Tier 1")

    # ── F-08 · reproducibilidad de dependencias ─────────────────────────────
    def test_las_dependencias_que_deciden_el_indice_estan_pineadas(self):
        """
        `rank_bm25` y `scikit-learn` deciden la tokenización y por tanto qué
        literatura se recupera. Con `>=`, dos instalaciones distintas producen
        dictámenes distintos.
        """
        req = (RAIZ / "requirements.txt").read_text(encoding="utf-8")
        for pkg in ("rank_bm25", "scikit-learn"):
            linea = [l for l in req.splitlines()
                     if l.strip().lower().startswith(pkg.lower())]
            assert linea, f"{pkg} no aparece en requirements.txt"
            assert "==" in linea[0], f"{pkg} sin pinear: {linea[0]!r}"

    # ── F-15 · un score fuera de escala no se pinta como «no evaluable» ─────
    def test_un_score_fuera_de_escala_no_se_confunde_con_no_evaluable(self):
        from modulos.generador_word import _label_semaforo
        assert _label_semaforo(5.01) == "SATISFACTORIO"
        assert _label_semaforo(None) == "NO EVALUABLE — FALLO TÉCNICO"
        assert _label_semaforo(0.0) == "NO EVALUABLE — SIN EVIDENCIA"


# ═════════════════════════════════════════════════════════════════════════════
# PREGUNTAS-ORO DEL RAG
#
# El corpus solo se verificaba de forma estructural: sin contaminación cruzada y
# ningún índice mudo. Eso no responde a la pregunta que decide un dictamen —¿sale
# el documento correcto?— ni al modo de fallo que encontró la auditoría: una
# consulta de otro dominio recuperada como si fuera pericia pertinente.
#
# Coste 0: no llama a ningún modelo.
# ═════════════════════════════════════════════════════════════════════════════

class TestPreguntasOroRAG:

    @staticmethod
    def _resultado():
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        from scripts.preguntas_oro_rag import evaluar
        return evaluar()

    def test_el_corpus_devuelve_el_documento_correcto_el_primero(self):
        """
        Gobierna recall@1, no @3. Con 2-3 documentos por dominio el top-3
        contiene el correcto casi por construcción: degradando el buscador para
        que ordene al revés, @3 solo bajó a 89 % y @1 cayó a 56 %. Un umbral
        sobre @3 no detectaría un buscador roto.
        """
        from scripts.preguntas_oro_rag import _metricas, UMBRAL_RECALL_1
        m = _metricas(self._resultado()["filas"], solo_discriminantes=True)
        assert m["n"] >= 6, f"muy pocas preguntas aplicables ({m['n']})"
        assert m["r1"] >= UMBRAL_RECALL_1, (
            f"recall@1 = {m['r1']:.0%} < {UMBRAL_RECALL_1:.0%}: la pericia de "
            f"dominio inyectada en el prompt está mal elegida")

    def test_una_consulta_de_otro_dominio_declara_su_alcance(self):
        """
        El modo de fallo real de la auditoría: «modelo de scoring de admisión de
        tarjetas de crédito» contra el corpus VaR devolvía el PDF de riesgo de
        mercado rotulado «cubre el 100 % de los términos clave». Lo correcto es
        no devolver nada, o devolver declarando qué términos no se conocen.
        """
        malas = [a for a in self._resultado()["adversarias"]
                 if a["error"] or not a["declara"]]
        assert not malas, (
            "consultas de otro dominio recuperadas sin advertir el alcance: "
            + ", ".join(f"{a['id']}({a['dominio']})" for a in malas))

    def test_cada_pregunta_declara_el_hecho_que_la_sostiene(self):
        """
        Sin el dato concreto del documento, la pregunta no es verificable a mano
        y el set deja de ser auditable: nadie podría comprobar que no me la
        inventé.
        """
        from scripts.preguntas_oro_rag import PREGUNTAS
        for p in PREGUNTAS:
            assert p.get("hecho", "").strip(), f"{p['id']} sin `hecho`"
            assert p.get("fuente", "").strip(), f"{p['id']} sin `fuente`"
            assert "discrim" in p, f"{p['id']} no declara si discrimina"

    def test_un_dominio_de_un_solo_documento_no_cuenta_como_discriminante(self):
        """
        Con un único documento la pregunta no distingue nada: contarla como
        acierto de recuperación inflaría la métrica.
        """
        from scripts.preguntas_oro_rag import PREGUNTAS, _fuentes_del_dominio
        for p in PREGUNTAS:
            if len(_fuentes_del_dominio(p["dominio"])) <= 1:
                assert p["discrim"] is False, (
                    f"{p['id']}: su dominio tiene un solo documento pero está "
                    f"marcada como discriminante")

    def test_las_fuentes_esperadas_existen_o_se_declaran_no_aplicables(self):
        """
        Se busca por patrón, no por nombre exacto: sustituir los resúmenes por
        los textos oficiales NO debe poner la suite en rojo. Una suite que se
        rompe porque alguien mejoró el corpus enseña a ignorarla.
        """
        res = self._resultado()
        aplicables = [f for f in res["filas"] if f["aplicable"]]
        assert aplicables, "ninguna pregunta aplicable: ¿se vació el corpus?"
        for f in res["filas"]:
            if not f["aplicable"]:
                assert f["rank"] is None and not f["error"], (
                    f"{f['id']} no aplicable pero se evaluó igualmente")


# ═════════════════════════════════════════════════════════════════════════════
# SEGUNDO UMBRAL (recall@3) — se activa solo cuando el corpus crece
#
# No está atado a una fecha ni a un TODO: se enciende por dominio en cuanto ese
# dominio tiene ≥ MIN_DOCS_PARA_R3 documentos. Con 2-3 docs el top-3 abarca el
# corpus entero y @3 vale 100 % pase lo que pase; medirlo ahí sería confianza
# falsa.
# ═════════════════════════════════════════════════════════════════════════════

class TestSegundoUmbralRecall3:
    """
    recall@3 como segundo umbral, con elegibilidad derivada de los CHUNKS.

    [CORRECCIÓN 2026-08-07] La primera versión exigía «≥ 6 documentos en el
    dominio» y medía la magnitud equivocada: el buscador ordena chunks, no
    ficheros. Con ese criterio @3 quedaba dormido en dominios donde ya
    discriminaba. Ahora la condición sale del mecanismo:

        chunks_del_dominio - chunks_del_documento_esperado ≥ top_k

    Si el resto del dominio no suma al menos `top_k` fragmentos, el esperado
    entra en el top-3 por construcción y medir su @3 sería confianza falsa.
    """

    @staticmethod
    def _res():
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        from scripts.preguntas_oro_rag import evaluar
        return evaluar(incluir_adversarias=False)

    def test_el_umbral_de_recall3_esta_ACTIVO_con_el_corpus_actual(self):
        from scripts.preguntas_oro_rag import _metricas
        m = _metricas(self._res()["filas"], solo_discriminantes=True)
        assert m["r3_activo"] is True, (
            "recall@3 no gobierna ninguna pregunta: revisa `_elegible_r3`")
        assert m["n_r3"] >= 12, (
            f"solo {m['n_r3']} preguntas elegibles: el set perdió resolución")

    def test_un_dominio_de_un_solo_documento_queda_excluido_solo(self):
        """
        `conductuales` tiene un único documento: la resta da 0 y sus preguntas
        no cuentan para @3. Sin caso especial en el código.
        """
        filas = [f for f in self._res()["filas"]
                 if f["dominio"] == "conductuales"]
        assert filas, "no hay preguntas de conductuales"
        assert all(not f["elegible_r3"] for f in filas), (
            "una pregunta de un dominio con un solo documento se está "
            "contando para recall@3")

    def test_la_elegibilidad_se_deriva_de_los_chunks(self):
        """La condición debe cumplirse fila a fila, no de media."""
        from scripts.preguntas_oro_rag import _elegible_r3
        for f in self._res()["filas"]:
            if not f["aplicable"]:
                continue
            esperado = _elegible_r3(f["chunks_dominio"], f["chunks_doc"], 3)
            assert f["elegible_r3"] == esperado, (
                f"{f['id']}: elegibilidad incoherente con "
                f"{f['chunks_dominio']} chunks del dominio y "
                f"{f['chunks_doc']} del documento")

    def test_recall3_detecta_lo_que_recall1_deja_pasar(self, monkeypatch):
        """
        LA razón de tener dos umbrales. Se retira de los resultados el único
        fragmento de `riskmetrics_summary.md` —2 preguntas de 19—:

            recall@1 = 89 %  → APRUEBA (umbral 85 %)
            recall@3 = 89 %  → FALLA   (umbral 90 %)

        Sin el segundo umbral esa regresión pasaría desapercibida, y significa
        que el modelo nunca vio el documento que debía ver.
        """
        import src.rag.buscador_lexico as B
        from scripts.preguntas_oro_rag import (
            _metricas, UMBRAL_RECALL_1, UMBRAL_RECALL_3)
        orig = B.BuscadorLexico.buscar

        def _sin_riskmetrics(self, c, top_k=3, **kw):
            r = orig(self, c, top_k=top_k + 3, **kw)
            return [x for x in r
                    if "riskmetrics" not in str(x.get("fuente", ""))][:top_k]

        monkeypatch.setattr(B.BuscadorLexico, "buscar", _sin_riskmetrics)
        m = _metricas(self._res()["filas"], solo_discriminantes=True)
        assert m["r1"] >= UMBRAL_RECALL_1, (
            f"recall@1 = {m['r1']:.0%}: la demostración exige que @1 APRUEBE, "
            f"para probar que @3 aporta algo por su cuenta")
        assert m["r3"] < UMBRAL_RECALL_3, (
            f"recall@3 = {m['r3']:.0%}: no detectó que el documento se quedó "
            f"fuera de los 3 fragmentos que ve el modelo")

    def test_recall3_NO_salta_si_solo_empeora_el_ranking(self, monkeypatch):
        """
        Control contra el falso positivo. Que el documento correcto baje al 2.º
        puesto es peor ranking, pero el prompt inyecta 3 fragmentos: el modelo
        lo sigue viendo. De eso se ocupa @1, no @3.
        """
        import src.rag.buscador_lexico as B
        from scripts.preguntas_oro_rag import _metricas
        orig = B.BuscadorLexico.buscar

        def _segundo(self, c, top_k=3, **kw):
            r = orig(self, c, top_k, **kw)
            return [r[1], r[0]] + r[2:] if len(r) > 1 else r

        monkeypatch.setattr(B.BuscadorLexico, "buscar", _segundo)
        m = _metricas(self._res()["filas"], solo_discriminantes=True)
        assert m["r3"] == 1.0, (
            f"recall@3 = {m['r3']:.0%}: saltó por un simple cambio de orden")
        assert m["r1"] < 1.0, "el escenario no llegó a empeorar el ranking"

    def test_recall1_nunca_supera_a_recall3_en_la_misma_poblacion(self):
        """Invariante aritmético: si está en la posición 1, está en el top-3."""
        filas = [f for f in self._res()["filas"]
                 if f["aplicable"] and f["discrim"] and f["elegible_r3"]]
        assert filas, "sin preguntas elegibles"
        r1 = sum(1 for f in filas if f["rank"] == 1) / len(filas)
        r3 = sum(1 for f in filas if f["rank"] is not None) / len(filas)
        assert r1 <= r3

    def test_hay_bastantes_preguntas_por_dominio_para_resolver(self):
        """
        Con pocas preguntas cada fallo vale demasiado y el umbral se vuelve
        binario: con 3 preguntas, una sola falla ya son 33 puntos. El set se
        amplió a 24 justamente para que @3 pueda quedar entre 85 % y 90 % —la
        banda donde aporta información que @1 no da—.
        """
        import collections
        from scripts.preguntas_oro_rag import PREGUNTAS
        por_dom = collections.Counter(p["dominio"] for p in PREGUNTAS)
        assert len(PREGUNTAS) >= 20, f"solo {len(PREGUNTAS)} preguntas"
        for dom, n in por_dom.items():
            assert n >= 5, f"{dom} tiene solo {n} pregunta(s)"


# ═════════════════════════════════════════════════════════════════════════════
# MOTORES DE CALIDAD DE DATOS DE LA ENTIDAD
#
# El validador escribe sus motores, los ejecuta EN SU MÁQUINA y deja la tabla
# de resultados. El agente solo la lee. La calificación del ámbito la gobiernan
# esos resultados, no los controles que ejecuta el agente.
# ═════════════════════════════════════════════════════════════════════════════

class TestMotoresEntidad:

    # ── Lo innegociable: el agente NO ejecuta ───────────────────────────────
    def test_el_modulo_no_puede_ejecutar_codigo(self):
        """
        Quien corre el motor responde de él. Si lo ejecutara el agente, el
        validador firmaría un resultado que no produjo — y correría con sus
        permisos, en la máquina que guarda audit_logs/, outputs/ y feedback/.

        Mismo blindaje que `analisis_estatico`: se comprueba el AST, no el
        texto, para que renombrar no lo esquive.
        """
        import ast as _ast
        fuente = (RAIZ / "modulos" / "motores_entidad.py").read_text(encoding="utf-8")
        arbol = _ast.parse(fuente)
        prohibidos = {"exec", "eval", "compile", "__import__"}
        for nodo in _ast.walk(arbol):
            if isinstance(nodo, _ast.Call):
                nombre = getattr(nodo.func, "id", None) or getattr(nodo.func, "attr", None)
                assert nombre not in prohibidos, (
                    f"el módulo llama a {nombre}(): debe ser SOLO LECTURA")
            if isinstance(nodo, (_ast.Import, _ast.ImportFrom)):
                mods = ([a.name for a in nodo.names]
                        if isinstance(nodo, _ast.Import) else [nodo.module or ""])
                for m in mods:
                    assert not str(m).startswith(("subprocess", "importlib", "runpy")), (
                        f"importa {m}: abre la puerta a ejecutar el motor")

    def test_un_py_en_la_carpeta_se_ignora_y_se_declara(self, tmp_path):
        """Un .py ahí es el MOTOR, no su resultado. Ni se lee ni se ejecuta."""
        from modulos.motores_entidad import leer_resultados, SUBCARPETA
        carpeta = tmp_path / "calidad_datos" / SUBCARPETA
        carpeta.mkdir(parents=True)
        (carpeta / "motor_unicidad.py").write_text(
            "raise SystemExit('esto NO debe ejecutarse')", encoding="utf-8")
        res = leer_resultados(tmp_path)
        assert res["filas"] == []
        assert any("NO se ejecuta" in a for a in res["avisos"]), (
            "ignorar el .py en silencio haría creer que se tuvo en cuenta")

    # ── Lectura tolerante ───────────────────────────────────────────────────
    @staticmethod
    def _tabla(tmp_path, filas, columnas=None):
        import pandas as pd
        from modulos.motores_entidad import SUBCARPETA
        carpeta = tmp_path / "calidad_datos" / SUBCARPETA
        carpeta.mkdir(parents=True, exist_ok=True)
        df = pd.DataFrame(filas)
        if columnas:
            df.columns = columnas
        df.to_csv(carpeta / "motores.csv", index=False)
        return tmp_path

    def test_reconoce_los_encabezados_con_variantes(self, tmp_path):
        """
        Exigir un encabezado exacto convierte un cambio cosmético —una tilde,
        una mayúscula— en un fallo de validación.
        """
        from modulos.motores_entidad import leer_resultados
        raiz = self._tabla(tmp_path, [{
            "DESCRIPCION DEL CONTROL": "Unicidad",
            "Porcentaje Incumplimiento": 2.5,
            "ESTADO": "FALLA",
            "Observaciones": "Duplicados detectados"}])
        f = leer_resultados(raiz)["filas"]
        assert len(f) == 1
        assert f[0]["descripcion"] == "Unicidad"
        assert abs(f[0]["tasa"] - 0.025) < 1e-9
        assert f[0]["detalle"] == "Duplicados detectados"

    def test_la_escala_se_decide_por_columna_no_por_celda(self, tmp_path):
        """
        ¿0.5 es «medio por ciento» o «la mitad»? Decidirlo fila a fila daría
        escalas distintas dentro del mismo control.
        """
        from modulos.motores_entidad import leer_resultados
        raiz = self._tabla(tmp_path, [
            {"Descripción": "A", "% de incumplimiento": 0.5,
             "Resultado": "OK", "Detalle": ""},
            {"Descripción": "B", "% de incumplimiento": 40.0,
             "Resultado": "FALLA", "Detalle": ""}])
        filas = leer_resultados(raiz)["filas"]
        assert all(f["escala_porcentaje"] for f in filas)
        assert abs(filas[0]["tasa"] - 0.005) < 1e-9   # 0,5 % y no 50 %
        assert abs(filas[1]["tasa"] - 0.40) < 1e-9

    # ── Puntuación ──────────────────────────────────────────────────────────
    def test_la_calibracion_es_la_que_ya_usaba_el_proyecto(self):
        """No se inventa una escala nueva: es la [D7-FIX] que ya existía."""
        from modulos.motores_entidad import puntaje_por_tasa as P
        assert P(0.0) == 5
        assert P(0.004) == 4
        assert P(0.015) == 3
        assert P(0.09) == 2
        assert P(0.25) == 1
        assert P(None) is None, "sin tasa no se inventa un puntaje"

    def test_un_motor_que_falla_no_puede_acabar_en_cumple_plenamente(self, tmp_path):
        """
        La calificación la gobiernan los controles del validador. Si su motor
        concluye FALLA, el agente no puede sobrescribirlo con un 5 porque la
        tasa medida sea 0: quedaría contradiciendo a quien corrió la prueba.
        """
        from modulos.motores_entidad import evaluaciones_desde_motores_entidad as E
        raiz = self._tabla(tmp_path, [{
            "Descripción": "Tipos de dato", "% de incumplimiento": 0.0,
            "Resultado": "FALLA", "Detalle": "Criterio interno"}])
        ev = E(raiz)[0]
        assert ev["puntaje"] is None
        assert ev.get("evaluacion_valida") is False

    def test_falla_sin_cuantificar_no_recibe_puntaje_inventado(self, tmp_path):
        """«Falla» no dice CUÁNTO. Asignarle un 1 sería inventar la severidad."""
        from modulos.motores_entidad import evaluaciones_desde_motores_entidad as E
        raiz = self._tabla(tmp_path, [{
            "Descripción": "Outliers", "% de incumplimiento": None,
            "Resultado": "FALLA", "Detalle": "No se cuantificó"}])
        assert E(raiz)[0]["puntaje"] is None

    def test_no_avisa_de_incoherencia_por_una_tasa_pequena(self, tmp_path):
        """
        Control contra el falso positivo. Un 0,32 % dado por conforme es
        normal —el umbral interno de la entidad puede ser 0,5 %— y avisar ahí
        haría saltar el aviso en casi todas las filas.
        """
        from modulos.motores_entidad import evaluaciones_desde_motores_entidad as E
        raiz = self._tabla(tmp_path, [{
            "Descripción": "Completitud", "% de incumplimiento": 0.32,
            "Resultado": "OK", "Detalle": "Dentro del umbral interno"}])
        assert "⚠️" not in E(raiz)[0]["observacion"]

    def test_si_avisa_cuando_se_da_por_conforme_un_incumplimiento_masivo(self, tmp_path):
        from modulos.motores_entidad import evaluaciones_desde_motores_entidad as E
        raiz = self._tabla(tmp_path, [{
            "Descripción": "Rango", "% de incumplimiento": 23.0,
            "Resultado": "OK", "Detalle": ""}])
        obs = E(raiz)[0]["observacion"]
        assert "⚠️" in obs and "CUMPLIMIENTO" in obs

    # ── Procedencia y ausencia ──────────────────────────────────────────────
    def test_cada_resultado_declara_quien_lo_ejecuto(self, tmp_path):
        """
        Lo que un auditor necesita para juzgar la independencia: quién corrió
        la prueba, el validador o el agente.
        """
        from modulos.motores_entidad import evaluaciones_desde_motores_entidad as E
        raiz = self._tabla(tmp_path, [{
            "Descripción": "A", "% de incumplimiento": 1.0,
            "Resultado": "FALLA", "Detalle": ""}])
        ev = E(raiz)[0]
        assert ev["ejecutado_por"] == "validador"
        assert ev["origen_motor"].endswith(".csv")

    def test_sin_carpeta_no_es_un_error_sino_una_ausencia(self, tmp_path):
        """La entidad puede no aportar motores propios. Eso se declara."""
        from modulos.motores_entidad import (
            leer_resultados, evaluaciones_desde_motores_entidad as E)
        res = leer_resultados(tmp_path)
        assert res["filas"] == [] and res["avisos"] == []
        assert E(tmp_path) == []

    def test_una_tabla_sin_columnas_reconocibles_se_omite_declarandolo(self, tmp_path):
        from modulos.motores_entidad import leer_resultados
        raiz = self._tabla(tmp_path, [{"foo": 1, "bar": 2}])
        res = leer_resultados(raiz)
        assert res["filas"] == []
        assert any("no se reconoce" in a for a in res["avisos"])

    # ── Precedencia sobre los motores internos ──────────────────────────────
    def test_el_pipeline_declara_la_precedencia(self):
        """
        Si puntuaran los dos, la misma dimensión entraría dos veces en el score
        con dos veredictos posibles: el ámbito mediría cuántas pruebas se
        ejecutaron, no cómo de buenos son los datos.
        """
        norm = " ".join((RAIZ / "agente.py").read_text(encoding="utf-8").split())
        assert "evals_entidad" in norm, "los motores de la entidad no se leen"
        assert "INFORMATIVOS" in norm or "informativo" in norm.lower(), (
            "no consta que los controles internos cedan la calificación")


# ═════════════════════════════════════════════════════════════════════════════
# PIPELINE DE CALIDAD DE DATOS DEL VALIDADOR
#
# Genera la tabla que el agente lee. Corre EN LA MÁQUINA DEL VALIDADOR y el
# agente no lo toca: esa separación es lo que permite firmar el resultado.
# ═════════════════════════════════════════════════════════════════════════════

class TestPipelineCalidadDatos:

    # ── La separación, que es lo que sostiene el modelo ─────────────────────
    def test_el_agente_no_importa_ni_ejecuta_el_pipeline(self):
        """
        Si `agente.py` llamara a este script, el agente estaría ejecutando los
        controles del validador y el modelo entero se cae: quien corre la
        prueba dejaría de ser quien responde de ella.
        """
        import ast as _ast
        for fichero in ("agente.py",):
            arbol = _ast.parse((RAIZ / fichero).read_text(encoding="utf-8"))
            for nodo in _ast.walk(arbol):
                mods = []
                if isinstance(nodo, _ast.Import):
                    mods = [a.name for a in nodo.names]
                elif isinstance(nodo, _ast.ImportFrom):
                    mods = [nodo.module or ""]
                for m in mods:
                    assert "pipeline_calidad_datos" not in str(m), (
                        f"{fichero} importa el pipeline del validador")

    def test_el_pipeline_escribe_donde_el_agente_lee(self):
        """Un desajuste aquí deja al validador generando tablas que nadie lee."""
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        from modulos.motores_entidad import SUBCARPETA
        fuente = (RAIZ / "scripts" / "pipeline_calidad_datos.py").read_text(
            encoding="utf-8")
        assert "SUBCARPETA" in fuente, (
            "el pipeline fija la carpeta a mano en vez de leerla del módulo "
            "que la define: acabarán divergiendo")

    # ── La tabla que produce ────────────────────────────────────────────────
    @staticmethod
    def _correr(tmp_path):
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        import pandas as pd
        from scripts.pipeline_calidad_datos import ejecutar_plan
        ds = tmp_path / "calidad_datos" / "datasets"
        ds.mkdir(parents=True)
        pd.DataFrame({
            "Cuenta":   ["C1", "C1", "C2", "C3"],
            "Cliente":  ["CL1", "CL2", "CL3", "CL9"],
            "Tasa":     [0.05, 0.07, 5.0, 0.03],
        }).to_csv(ds / "cartera.csv", index=False)
        plan = [
            {"descripcion": "Unicidad de Cliente por Cuenta",
             "dataset": "cartera", "motor": "unicidad", "umbral": 0,
             "cfg": {"group_cols": "Cuenta", "campo_objetivo": "Cliente"}},
            {"descripcion": "Tasa en rango [0,1]",
             "dataset": "cartera", "motor": "rango", "umbral": 0,
             "cfg": {"campo_objetivo": "Tasa", "min": 0, "max": 1}},
        ]
        return ejecutar_plan(tmp_path, plan, propios={})

    def test_produce_las_columnas_que_el_agente_espera(self, tmp_path):
        """
        Las cuatro obligatorias, más `Umbral` desde que el tope de puntaje
        depende de la tolerancia declarada. Se comprueba INCLUSIÓN, no
        igualdad: añadir una columna informativa no debe romper el contrato,
        quitar una obligatoria sí.
        """
        filas = self._correr(tmp_path)
        assert filas
        obligatorias = {"Descripción", "% de incumplimiento", "Resultado",
                        "Detalle de observación"}
        for f in filas:
            assert obligatorias <= set(f), (
                f"faltan columnas obligatorias: {obligatorias - set(f)}")
            assert "Umbral" in f, (
                "sin la tolerancia, el agente no puede aplicar el tope de 3 "
                "sobre tolerancia cero y tendría que suponerla")

    def test_el_resultado_lo_decide_el_umbral_declarado(self, tmp_path):
        """
        El veredicto sale del umbral que declara el validador, no de un
        criterio que se invente el pipeline.
        """
        filas = self._correr(tmp_path)
        assert filas[0]["Resultado"] == "FALLA", "C1 tiene dos clientes"
        assert filas[0]["% de incumplimiento"] > 0

    def test_sin_umbral_no_se_inventa_veredicto(self):
        from scripts.pipeline_calidad_datos import _veredicto
        assert _veredicto(0.5, 10, None) == "", (
            "sin umbral declarado el pipeline no puede decidir qué es aceptable")
        assert _veredicto(0.001, 1, 0.01) == "OK"
        assert _veredicto(0.5, 1, 0.01) == "FALLA"
        assert _veredicto(0.9, 2, 3) == "OK", "umbral >=1 es conteo absoluto"

    def test_un_dataset_ausente_se_declara_no_se_omite(self, tmp_path):
        """
        Omitir un control que no se pudo correr lo haría pasar por superado.
        """
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        from scripts.pipeline_calidad_datos import ejecutar_plan
        (tmp_path / "calidad_datos" / "datasets").mkdir(parents=True)
        filas = ejecutar_plan(tmp_path, [
            {"descripcion": "Control sobre datos que no están",
             "dataset": "no_existe", "motor": "unicidad", "umbral": 0,
             "cfg": {"group_cols": "A", "campo_objetivo": "B"}}], propios={})
        assert len(filas) == 1
        assert filas[0]["Resultado"] == ""
        assert "NO EJECUTADO" in filas[0]["Detalle de observación"]

    def test_un_control_que_revienta_no_tumba_el_plan(self, tmp_path):
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        import pandas as pd
        from scripts.pipeline_calidad_datos import ejecutar_plan
        ds = tmp_path / "calidad_datos" / "datasets"
        ds.mkdir(parents=True)
        pd.DataFrame({"A": [1, 2]}).to_csv(ds / "t.csv", index=False)

        def _explota(_datasets):
            raise RuntimeError("boom")

        filas = ejecutar_plan(
            tmp_path,
            [{"descripcion": "Motor inexistente", "dataset": "t",
              "motor": "no_existe_este_motor", "umbral": 0, "cfg": {}}],
            propios={"x": {"descripcion": "Control que revienta",
                           "funcion": _explota, "umbral": 0}})
        assert len(filas) == 2, "un control caído se llevó por delante el resto"
        assert all("NO EJECUTADO" in f["Detalle de observación"] for f in filas)

    # ── El circuito completo ────────────────────────────────────────────────
    def test_lo_que_escribe_el_pipeline_lo_lee_el_agente(self, tmp_path):
        """
        La prueba que importa: pipeline → tabla → lectura del agente, sin
        tocar nada por el camino.
        """
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        from scripts.pipeline_calidad_datos import escribir_tabla
        from modulos.motores_entidad import evaluaciones_desde_motores_entidad

        filas = self._correr(tmp_path)
        ruta = escribir_tabla(filas, tmp_path)
        assert ruta.exists()

        evals = evaluaciones_desde_motores_entidad(tmp_path)
        assert len(evals) == len(filas)
        assert all(e["ejecutado_por"] == "validador" for e in evals)
        assert any(e["puntaje"] is not None for e in evals), (
            "ninguna fila puntuó: el circuito está roto")


# ═════════════════════════════════════════════════════════════════════════════
# TOPE DE PUNTAJE SEGÚN LA TOLERANCIA DECLARADA  (política 2026-08-08)
#
# Un incumplimiento sobre tolerancia CERO no admite el mismo tratamiento que
# uno sobre un umbral holgado: la entidad decidió que ahí no cabe ni un caso,
# así que la magnitud no atenúa el hecho de haberla superado.
#
#     FALLA + umbral == 0   → tope 3
#     FALLA + umbral > 0    → tope 4
#     FALLA + sin umbral    → tope 4, y se declara que no consta
# ═════════════════════════════════════════════════════════════════════════════

class TestTopePorToleranciaCero:

    @staticmethod
    def _evaluar(tmp_path, filas):
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        import pandas as pd
        from modulos.motores_entidad import (
            SUBCARPETA, evaluaciones_desde_motores_entidad)
        carpeta = tmp_path / "calidad_datos" / SUBCARPETA
        carpeta.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(filas).to_csv(carpeta / "motores.csv", index=False)
        return evaluaciones_desde_motores_entidad(tmp_path)

    def test_falla_con_tolerancia_cero_topa_en_3(self, tmp_path):
        """
        Sin este tope, un 0,08 % que incumple una tolerancia cero puntuaba 4
        —«cumple con observaciones menores»— y el ámbito salía en 4,38 con
        cuatro controles en FALLA.
        """
        ev = self._evaluar(tmp_path, [{
            "Descripción": "Unicidad", "% de incumplimiento": 0.08,
            "Resultado": "FALLA", "Umbral": 0,
            "Detalle de observación": ""}])[0]
        assert ev["puntaje"] == 3
        assert "olerancia CERO" in ev["observacion"]

    def test_falla_con_umbral_holgado_mantiene_el_tope_4(self, tmp_path):
        """
        La entidad toleraba hasta un 2 %: superarlo es un incumplimiento, pero
        no del mismo orden que romper una tolerancia cero.
        """
        ev = self._evaluar(tmp_path, [{
            "Descripción": "Outliers", "% de incumplimiento": 0.3,
            "Resultado": "FALLA", "Umbral": 0.02,
            "Detalle de observación": ""}])[0]
        assert ev["puntaje"] == 4

    def test_sin_columna_de_umbral_no_se_supone_tolerancia_cero(self, tmp_path):
        """
        Endurecer el puntaje sobre un dato que NO consta acusaría al validado
        por una omisión de formato. Se aplica el tope general y se declara.
        """
        ev = self._evaluar(tmp_path, [{
            "Descripción": "Unicidad", "% de incumplimiento": 0.08,
            "Resultado": "FALLA", "Detalle de observación": ""}])[0]
        assert ev["puntaje"] == 4
        assert ev["umbral_declarado"] is None
        assert "no declara el umbral" in ev["observacion"]

    def test_el_tope_solo_aplica_a_incumplimientos(self, tmp_path):
        """
        Un control que CUMPLE con tolerancia cero y 0 % medido vale 5. El tope
        castiga haber superado la tolerancia, no haberla declarado estricta.
        """
        ev = self._evaluar(tmp_path, [{
            "Descripción": "Tipos de dato", "% de incumplimiento": 0.0,
            "Resultado": "OK", "Umbral": 0,
            "Detalle de observación": ""}])[0]
        assert ev["puntaje"] == 5

    def test_el_tope_no_sube_un_puntaje_ya_peor(self, tmp_path):
        """
        Es un TOPE, no una asignación: un 14,7 % sigue valiendo 1, no 3.
        """
        ev = self._evaluar(tmp_path, [{
            "Descripción": "Rango", "% de incumplimiento": 14.7,
            "Resultado": "FALLA", "Umbral": 0,
            "Detalle de observación": ""}])[0]
        assert ev["puntaje"] == 1

    def test_el_umbral_se_lee_aunque_venga_como_texto(self, tmp_path):
        """Un Excel devuelve «0» o «0,0» según cómo se escribiera la celda."""
        ev = self._evaluar(tmp_path, [{
            "Descripción": "A", "% de incumplimiento": 0.1,
            "Resultado": "FALLA", "Umbral": "0,0",
            "Detalle de observación": ""}])[0]
        assert ev["umbral_declarado"] == 0.0
        assert ev["puntaje"] == 3

    def test_la_columna_umbral_no_le_roba_la_columna_al_porcentaje(self, tmp_path):
        """
        `% de incumplimiento` y `Umbral` son ambos numéricos: si el mapeo se
        confundiera, la tasa medida y la tolerancia se intercambiarían y el
        puntaje saldría al revés.
        """
        ev = self._evaluar(tmp_path, [{
            "Descripción": "A", "% de incumplimiento": 12.0,
            "Resultado": "FALLA", "Umbral": 0,
            "Detalle de observación": ""}])[0]
        assert abs(ev["tasa_incumplimiento"] - 0.12) < 1e-9
        assert ev["umbral_declarado"] == 0.0

    def test_el_pipeline_escribe_la_tolerancia_junto_al_resultado(self, tmp_path):
        """
        Sin que el dato VIAJE, el agente no puede aplicar la política y tendría
        que suponer la tolerancia.
        """
        import sys
        if str(RAIZ) not in sys.path:
            sys.path.insert(0, str(RAIZ))
        import pandas as pd
        from scripts.pipeline_calidad_datos import ejecutar_plan
        ds = tmp_path / "calidad_datos" / "datasets"
        ds.mkdir(parents=True)
        pd.DataFrame({"Cuenta": ["C1", "C1"], "Cliente": ["A", "B"]}).to_csv(
            ds / "cartera.csv", index=False)
        filas = ejecutar_plan(tmp_path, [
            {"descripcion": "Unicidad", "dataset": "cartera",
             "motor": "unicidad", "umbral": 0,
             "cfg": {"group_cols": "Cuenta", "campo_objetivo": "Cliente"}}],
            propios={})
        assert "Umbral" in filas[0], "la tolerancia no viaja con el resultado"
        assert filas[0]["Umbral"] == 0
