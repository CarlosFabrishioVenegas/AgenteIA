#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
scripts/preguntas_oro_rag.py
Set de preguntas-oro del RAG léxico: ¿recupera el corpus el documento correcto?

    python scripts/preguntas_oro_rag.py            # informe completo
    python scripts/preguntas_oro_rag.py --strict   # exit 1 si baja del umbral
    python scripts/preguntas_oro_rag.py --dominio VaR

POR QUÉ EXISTE
──────────────
Hasta ahora el RAG solo se verificaba de forma estructural: que cada dominio
recupere de su propia carpeta y que ningún índice esté mudo
(`scripts/verificar_corpus_rag.py`). Eso descarta la contaminación cruzada,
pero NO responde a la única pregunta que importa para un dictamen: cuando se
pregunta por el backtesting de Kupiec, ¿sale el documento de Kupiec o sale otro
que comparte vocabulario?

La auditoría del 2026-08-07 encontró el caso concreto: una consulta de scoring
crediticio contra el corpus VaR devolvía el PDF de riesgo de mercado rotulado
«cubre el 100 % de los términos clave». Un set de preguntas-oro lo habría
detectado solo.

CÓMO ESTÁ CONSTRUIDO
────────────────────
Cada pregunta cumple tres condiciones, y las tres son verificables a mano:

  1. Su respuesta está en UN documento concreto del corpus, y el campo `hecho`
     transcribe el dato que la sostiene. Nada se inventó: todo salió de leer
     los ficheros.
  2. Está redactada como la escribiría un validador, no con las palabras
     exactas del documento. Si copiásemos la frase del PDF mediríamos la
     capacidad de buscar literales, que no es lo que hace falta.
  3. Se declara si es DISCRIMINANTE. En un dominio con un solo documento la
     pregunta no puede distinguir nada: solo comprueba que el índice responde.
     Contarla como acierto de recuperación sería inflar la métrica.

MÉTRICA — DOS UMBRALES QUE MIDEN COSAS DISTINTAS
────────────────────────────────────────────────
`recall@k`: fracción de preguntas cuyo documento esperado aparece entre los k
primeros resultados.

  · **recall@1** detecta que el ranking empeoró: el documento correcto ya no
    sale el primero.
  · **recall@3** detecta algo peor: el documento **no entra en los tres
    fragmentos que el prompt inyecta**, o sea que el modelo no llegó a verlo.

Conviven porque uno caza lo que el otro deja pasar. Demostrado: retirando de
los resultados el único fragmento de `riskmetrics_summary.md` —2 preguntas de
19— recall@1 queda en 89 % (aprueba, umbral 85 %) y recall@3 en 89 % (falla,
umbral 90 %). Sin el segundo umbral, esa regresión pasaría desapercibida.

Y verificado que @3 NO salta de más: si el documento simplemente baja al 2.º
puesto, @3 sigue en 100 % porque el modelo lo sigue viendo. De eso se ocupa @1.

CUÁNDO CUENTA EL @3 DE UNA PREGUNTA
───────────────────────────────────
Solo si el documento esperado PUEDE quedar fuera del top-3. La condición sale
del mecanismo, no de un número redondo:

    chunks_del_dominio - chunks_del_documento_esperado  ≥  top_k

El buscador ordena CHUNKS, no ficheros. Si el resto del dominio no suma al
menos `top_k` fragmentos, el esperado entra por construcción y su @3 vale
100 % haga lo que haga el buscador. `conductuales` tiene un único documento:
la resta da 0 y sus preguntas quedan excluidas solas, sin caso especial.

Hoy son elegibles 19 de 24. El criterio se ajusta solo cuando el corpus crezca.

Además del set hay CONSULTAS ADVERSARIAS: preguntas hechas al dominio
equivocado a propósito. Ese era el modo de fallo real que encontró la
auditoría, y no lo mide ningún recall.

QUÉ NO MIDE
───────────
Que la RESPUESTA sea correcta. Mide que el documento correcto se recupere. Que
el modelo lo use bien es otra cosa, y no se puede medir sin gastar API.

CUANDO EL CORPUS CAMBIE
───────────────────────
Está previsto sustituir los resúmenes secundarios por los textos oficiales. Las
fuentes esperadas se buscan por PATRÓN, no por nombre exacto, y una pregunta
cuyo documento ya no está en el corpus se declara NO APLICABLE en vez de
fallar: una suite que se pone roja porque alguien mejoró el corpus enseña al
equipo a ignorarla.

Coste 0. No llama a ningún modelo.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

_RAIZ = Path(__file__).resolve().parent.parent
if str(_RAIZ) not in sys.path:
    sys.path.insert(0, str(_RAIZ))

# ═════════════════════════════════════════════════════════════════════════════
# EL SET
# ═════════════════════════════════════════════════════════════════════════════
#
# `fuente`  : subcadena que debe aparecer en el nombre del fichero recuperado.
# `hecho`   : el dato del documento que hace correcta la respuesta. Es lo que
#             permite a un humano comprobar la pregunta sin ejecutar nada.
# `discrim` : False si el dominio tiene un solo documento y por tanto la
#             pregunta no distingue entre fuentes.
#
# La elegibilidad para recall@3 NO se declara aquí: se calcula al vuelo desde
# el índice, contando chunks. Ver `_elegible_r3`.

PREGUNTAS: List[Dict] = [

    # ── VaR · 12 chunks en 3 documentos ─────────────────────────────────────
    # `riskmetrics_summary.md` es UN chunk de doce: las preguntas que apuntan a
    # él son las más exigentes del set, porque compiten contra once fragmentos
    # de otros documentos. Son las que hacen que recall@3 signifique algo.
    {
        "id": "VaR-01", "dominio": "VaR", "discrim": True,
        "pregunta": "¿Cuántas excedencias en 250 días sitúan un modelo en la "
                    "zona roja del marco supervisor?",
        "fuente": "backtesting",
        "hecho": "Zona roja: 10 o más excedencias; el incremento del "
                 "multiplicador es automático.",
    },
    {
        "id": "VaR-02", "dominio": "VaR", "discrim": True,
        "pregunta": "¿Qué medida de riesgo sustituye al VaR al 99 % para "
                    "calcular el requerimiento de capital por riesgo de mercado?",
        "fuente": "FRTB",
        "hecho": "El marco revisado sustituye el VaR al 99 % por el Expected "
                 "Shortfall al 97,5 %, porque el VaR no captura el riesgo de cola.",
    },
    {
        "id": "VaR-03", "dominio": "VaR", "discrim": True,
        "pregunta": "¿Qué factor de decaimiento se usa al estimar la "
                    "volatilidad con alisado exponencial en datos diarios?",
        "fuente": "riskmetrics",
        "hecho": "EWMA con lambda = 0.94 (diario).",
    },
    {
        "id": "VaR-04", "dominio": "VaR", "discrim": True,
        "pregunta": "¿Qué prueba compara el resultado teórico del modelo de "
                    "riesgo con el resultado hipotético de la mesa?",
        "fuente": "FRTB",
        "hecho": "PLAT (P&L Attribution Test): detecta si el modelo captura los "
                 "factores que mueven el resultado. Una mesa puede pasar el "
                 "backtesting y no explicar su P&L.",
    },
    {
        "id": "VaR-05", "dominio": "VaR", "discrim": True,
        "pregunta": "¿Cómo se contrasta que las excedencias no se agrupen en "
                    "el tiempo?",
        "fuente": "backtesting",
        "hecho": "Christoffersen: LR_cc = LR_uc + LR_ind; la independencia "
                 "serial se modeliza como cadena de Markov de primer orden.",
    },
    {
        "id": "VaR-06", "dominio": "VaR", "discrim": True,
        "pregunta": "¿Cómo se capitalizan los factores de riesgo sin "
                    "observaciones de precio suficientes?",
        "fuente": "FRTB",
        "hecho": "Los NMRF (Non-Modellable Risk Factors) reciben capital "
                 "calculado mediante escenarios de estrés, no mediante el ES.",
    },
    {
        "id": "VaR-07", "dominio": "VaR", "discrim": True,
        "pregunta": "¿Qué distribución se supone para los retornos en el "
                    "cálculo paramétrico y por qué se queda corta?",
        "fuente": "riskmetrics",
        "hecho": "Retornos ~ N(mu, sigma²); las colas gruesas y la curtosis "
                 "hacen que la Normal subestime los eventos extremos.",
    },

    # ── LaR · 9 chunks en 2 documentos ──────────────────────────────────────
    {
        "id": "LaR-01", "dominio": "LaR", "discrim": True,
        "pregunta": "¿Qué horizonte de estrés debe cubrir el colchón de "
                    "activos líquidos de alta calidad?",
        "fuente": "LCR",
        "hecho": "Escenario de estrés de treinta días naturales; el cociente "
                 "HQLA / salidas netas debe ser al menos del 100 %.",
    },
    {
        "id": "LaR-02", "dominio": "LaR", "discrim": True,
        "pregunta": "¿Cómo se ponderan los pasivos y el capital según su "
                    "estabilidad para financiar los activos a un año?",
        "fuente": "NSFR",
        "hecho": "El ASF pondera capital y pasivos por factores crecientes con "
                 "su estabilidad; el cociente ASF/RSF debe ser ≥ 100 %.",
    },
    {
        "id": "LaR-03", "dominio": "LaR", "discrim": True,
        "pregunta": "¿Qué tratamiento reciben las reservas en el banco central "
                    "dentro del stock de activos líquidos?",
        "fuente": "LCR",
        "hecho": "Nivel 1: efectivo y reservas en banco central disponibles en "
                 "estrés, sin límite de participación ni recorte de valoración.",
    },
    {
        "id": "LaR-04", "dominio": "LaR", "discrim": True,
        "pregunta": "¿Qué tasa se aplica a los depósitos vinculados a "
                    "servicios de compensación y custodia?",
        "fuente": "LCR",
        "hecho": "Los depósitos operativos reciben una tasa de fuga reducida "
                 "frente a los no operativos, si se acredita la vinculación "
                 "con criterios objetivos y no meramente comerciales.",
    },
    {
        "id": "LaR-05", "dominio": "LaR", "discrim": True,
        "pregunta": "¿Qué hallazgo produce que un mismo depósito se considere "
                    "estable en un marco y volátil en otro?",
        "fuente": "NSFR",
        "hecho": "Las incoherencias entre marcos son un hallazgo relevante: si "
                 "un depósito es estable a efectos de NSFR y volátil a efectos "
                 "de IRRBB sin justificación, uno de los supuestos no está "
                 "bien fundamentado.",
    },

    # ── conductuales · 6 chunks en UN SOLO documento: NO discriminan ────────
    # Con un único documento no hay nada que elegir. Comprueban que el índice
    # responde y que la consulta es reconocible; se reportan aparte para no
    # inflar la métrica de discriminación.
    {
        "id": "CON-01", "dominio": "conductuales", "discrim": False,
        "pregunta": "¿Cómo se separa la parte estable de la volátil en los "
                    "depósitos sin vencimiento contractual?",
        "fuente": "IRRBB",
        "hecho": "Descomposición núcleo / no núcleo; el núcleo se estima sobre "
                 "series que cubran al menos un ciclo completo de tipos.",
    },
    {
        "id": "CON-02", "dominio": "conductuales", "discrim": False,
        "pregunta": "¿Qué proporción del movimiento del tipo de mercado se "
                    "traslada a la remuneración del depósito?",
        "fuente": "IRRBB",
        "hecho": "El pass-through, que debe estimarse empíricamente y puede ser "
                 "asimétrico: las subidas se trasladan menos y con más retardo.",
    },
    {
        "id": "CON-03", "dominio": "conductuales", "discrim": False,
        "pregunta": "¿Por qué tratar los depósitos a la vista por su "
                    "vencimiento contractual distorsiona la medición del riesgo?",
        "fuente": "IRRBB",
        "hecho": "Son exigibles a la vista pero empíricamente estables; "
                 "tratarlos a un día produce una medición sin sentido económico.",
    },
    {
        "id": "CON-04", "dominio": "conductuales", "discrim": False,
        "pregunta": "¿Con qué métrica se mide la amortización anticipada de "
                    "préstamos y de qué depende?",
        "fuente": "IRRBB",
        "hecho": "CPR anualizada o SMM mensual; determinantes: incentivo de "
                 "refinanciación, seasoning, estacionalidad, burnout, LTV y "
                 "penalizaciones contractuales.",
    },
    {
        "id": "CON-05", "dominio": "conductuales", "discrim": False,
        "pregunta": "¿Qué efecto sobre la duración introduce que los clientes "
                    "amorticen antes cuando bajan los tipos?",
        "fuente": "IRRBB",
        "hecho": "Convexidad negativa: al bajar los tipos el activo se amortiza "
                 "y se reinvierte peor; al subir, la duración se alarga.",
    },

    # ── shared · 16 chunks en 3 documentos ──────────────────────────────────
    {
        "id": "SHR-01", "dominio": "shared", "discrim": True,
        "pregunta": "¿Cuántos principios componen el marco de agregación de "
                    "datos de riesgo y en cuántas secciones se organizan?",
        "fuente": "239",
        "hecho": "Catorce principios en cuatro secciones: gobierno e "
                 "infraestructura, capacidades de agregación, prácticas de "
                 "reporte y revisión supervisora.",
    },
    {
        "id": "SHR-02", "dominio": "shared", "discrim": True,
        "pregunta": "¿Cuáles son los tres elementos del marco de gestión del "
                    "riesgo de modelo?",
        "fuente": "SR_11",
        "hecho": "Desarrollo/implementación/uso robustos; validación "
                 "independiente y efectiva; gobierno, políticas y controles.",
    },
    {
        "id": "SHR-03", "dominio": "shared", "discrim": True,
        "pregunta": "¿Qué exige la normativa europea sobre la independencia de "
                    "la unidad que valida los modelos internos?",
        "fuente": "validacion_interna",
        "hecho": "CRR art. 189: la unidad de control debe ser independiente "
                 "del personal que origina las exposiciones; la independencia "
                 "ha de ser efectiva, no solo formal.",
    },
    {
        "id": "SHR-04", "dominio": "shared", "discrim": True,
        "pregunta": "¿Qué examina la evaluación de la solidez conceptual de un "
                    "modelo?",
        "fuente": "SR_11",
        "hecho": "Calidad del diseño y la construcción: documentación, "
                 "evidencia empírica de los métodos, variables y relaciones "
                 "supuestas; el análisis de sensibilidad es parte esencial.",
    },
    {
        "id": "SHR-05", "dominio": "shared", "discrim": True,
        "pregunta": "¿Qué capacidad se exige para atender peticiones no "
                    "previstas de información de riesgo en situaciones de estrés?",
        "fuente": "239",
        "hecho": "Principio 6 — Adaptabilidad: generar datos agregados para "
                 "peticiones ad hoc, incluidas las de estrés y cambios "
                 "regulatorios.",
    },
    {
        "id": "SHR-06", "dominio": "shared", "discrim": True,
        "pregunta": "¿Qué debe permitir el expediente para que un tercero "
                    "competente pueda revisarlo?",
        "fuente": "validacion_interna",
        "hecho": "Reconstruir el juicio emitido: qué se revisó, con qué datos y "
                 "criterios, qué se concluyó y qué recomendaciones, con su "
                 "seguimiento hasta el cierre.",
    },
    {
        "id": "SHR-07", "dominio": "shared", "discrim": True,
        "pregunta": "¿Cómo se comprueba que un modelo sigue funcionando tras "
                    "su puesta en producción?",
        "fuente": "SR_11",
        "hecho": "Monitoreo continuo: verificación de procesos, benchmarking "
                 "contra alternativas y seguimiento de cambios en productos, "
                 "mercados o prácticas que invaliden los supuestos.",
    },
]


#: Umbral que GOBIERNA la puerta: recall@1 sobre las discriminantes.
#:
#: Se eligió @1 y no @3 tras medirlo. Con 2-3 documentos por dominio, el top-3
#: contiene el documento correcto casi por construcción: se degradó el buscador
#: a propósito —devolviendo los resultados en orden INVERSO de relevancia— y
#: recall@3 solo bajó del 100 % al 89 %, por encima de cualquier umbral
#: razonable. recall@1, en cambio, cayó al 56 %.
#:
#: Es decir: @3 no habría detectado un buscador roto. Un control que no puede
#: fallar cuando debe es peor que no tenerlo, porque da confianza falsa.
#: Cuando el corpus crezca a decenas de documentos por dominio, @3 recuperará
#: su sentido y podrá añadirse como segundo umbral.
UMBRAL_RECALL_1 = 0.85

#: Segundo umbral, sobre recall@3. **Se activa solo cuando el corpus crece.**
#:
#: No está fijado a una fecha ni a una tarea pendiente: se enciende solo, por
#: dominio, en cuanto ese dominio tiene documentos suficientes para que @3
#: signifique algo. Un TODO en un comentario no lo habría activado nunca.
UMBRAL_RECALL_3 = 0.90

#: Cuándo cuenta el recall@3 de una pregunta.
#:
#: [CORRECCIÓN 2026-08-07] La primera versión exigía «≥ 6 DOCUMENTOS en el
#: dominio», y medía la magnitud equivocada: el buscador no recupera
#: documentos, recupera CHUNKS. El corpus tiene 12 chunks en VaR, 9 en LaR, 16
#: en shared y 6 en conductuales, y un mismo documento puede ocupar varios
#: puestos del top-3. Con el criterio de documentos, @3 quedaba dormido en
#: dominios donde ya discriminaba perfectamente.
#:
#: El criterio correcto sale del mecanismo, no de un número redondo: recall@3
#: solo puede fallar si hay bastantes chunks de OTROS documentos capaces de
#: desplazar al esperado fuera de los tres primeros puestos. Es decir:
#:
#:     chunks_del_dominio - chunks_del_documento_esperado  ≥  top_k
#:
#: Si esa resta es menor que `top_k`, el documento esperado entra en el top-3
#: por construcción y su @3 vale 100 % haga lo que haga el buscador: medirlo
#: sería confianza falsa.
#:
#: El criterio se ajusta solo. `conductuales` tiene un único documento, así que
#: la resta da 0 y sus preguntas quedan excluidas sin necesidad de tratarlas
#: como caso especial. Y cuando el corpus crezca, más dominios entrarán solos.
def _elegible_r3(chunks_dominio: int, chunks_doc: int, top_k: int) -> bool:
    return (chunks_dominio - chunks_doc) >= top_k


# ═════════════════════════════════════════════════════════════════════════════
# CONSULTAS ADVERSARIAS — el fallo que la auditoría encontró de verdad
# ═════════════════════════════════════════════════════════════════════════════
#
# El modo de fallo real no era «devuelve el documento equivocado del dominio»
# —eso el corpus lo hace bien— sino «devuelve literatura de OTRO dominio ante
# una pregunta que comparte vocabulario financiero genérico», rotulada como si
# cubriera la consulta entera.
#
# Cada una se pregunta al dominio EQUIVOCADO a propósito. Lo correcto es una de
# dos cosas: no devolver nada, o devolver algo declarando qué términos no
# conoce. Lo inaceptable es devolver un fragmento sin advertencia.

ADVERSARIAS: List[Dict] = [
    {
        "id": "ADV-01", "dominio": "VaR",
        "pregunta": "modelo de scoring de admisión de tarjetas de crédito",
        "porque": "Riesgo de crédito minorista preguntado al corpus de riesgo "
                  "de mercado. Comparte «modelo» y «crédito», nada más.",
    },
    {
        "id": "ADV-02", "dominio": "LaR",
        "pregunta": "backtesting de excedencias del VaR con la prueba de Kupiec",
        "porque": "Backtesting de mercado preguntado al corpus de liquidez.",
    },
    {
        "id": "ADV-03", "dominio": "conductuales",
        "pregunta": "requerimiento de capital por riesgo de mercado y expected "
                    "shortfall",
        "porque": "FRTB preguntado al corpus conductual.",
    },
    {
        "id": "ADV-04", "dominio": "shared",
        "pregunta": "factor de decaimiento lambda del alisado exponencial EWMA",
        "porque": "Detalle técnico de RiskMetrics preguntado al corpus "
                  "regulatorio transversal.",
    },
]


# ═════════════════════════════════════════════════════════════════════════════
# EJECUCIÓN
# ═════════════════════════════════════════════════════════════════════════════

def _chunks_del_dominio(dominio: str) -> Dict[str, int]:
    """
    Cuántos fragmentos aporta cada documento al índice de ese dominio.

    Es el universo REAL de recuperación: el buscador ordena chunks, no
    ficheros, y un documento con seis fragmentos ocupa seis puestos posibles
    del ranking mientras otro con uno solo compite por uno.

    Devuelve `{}` si no hay índice: la elegibilidad cae entonces a False y la
    pregunta no cuenta para @3, que es el lado conservador.
    """
    try:
        from src.rag.indexador_lexico import IndexadorLexico
        indice = IndexadorLexico(dominio).cargar(verificar_huella=False)
    except Exception:
        return {}
    if not indice:
        return {}
    cuenta: Dict[str, int] = {}
    for ch in indice.chunks:
        f = str(ch.get("fuente", "?"))
        cuenta[f] = cuenta.get(f, 0) + 1
    return cuenta


def _fuentes_del_dominio(dominio: str) -> List[str]:
    """Ficheros realmente presentes en el corpus de ese dominio."""
    base = _RAIZ / "inputs" / "rag" / dominio
    if not base.is_dir():
        return []
    return [p.name for p in sorted(base.iterdir())
            if p.is_file() and p.suffix.lower() not in (".gitkeep", "")
            and p.name.lower() != "readme.md"]


def evaluar(preguntas: Optional[List[Dict]] = None,
            top_k: int = 3,
            incluir_adversarias: bool = True) -> Dict:
    """
    Lanza el set y devuelve el detalle. No lanza: un dominio sin índice se
    declara, no revienta.
    """
    preguntas = preguntas or PREGUNTAS
    from src.rag.buscador_lexico import BuscadorLexico

    buscadores: Dict[str, object] = {}
    _chunks_cache: Dict[str, Dict[str, int]] = {}
    filas = []

    for p in preguntas:
        dom = p["dominio"]
        presentes = _fuentes_del_dominio(dom)
        # ¿Sigue existiendo el documento esperado tras un cambio de corpus?
        esperado = [f for f in presentes if p["fuente"].lower() in f.lower()]

        # Elegibilidad para @3: ¿hay bastantes chunks de OTROS documentos que
        # puedan desplazar al esperado fuera del top-k?
        if dom not in _chunks_cache:
            _chunks_cache[dom] = _chunks_del_dominio(dom)
        chunks = _chunks_cache[dom]
        c_dom = sum(chunks.values())
        c_doc = sum(n for f, n in chunks.items()
                    if p["fuente"].lower() in f.lower())

        fila = dict(p, aplicable=bool(esperado), esperado_real=esperado,
                    rank=None, recuperados=[], error=None,
                    n_docs_dominio=len(presentes),
                    chunks_dominio=c_dom, chunks_doc=c_doc,
                    elegible_r3=_elegible_r3(c_dom, c_doc, top_k))

        if not esperado:
            filas.append(fila)
            continue

        try:
            if dom not in buscadores:
                buscadores[dom] = BuscadorLexico(dom)
            res = buscadores[dom].buscar(p["pregunta"], top_k=top_k)
        except Exception as exc:
            fila["error"] = f"{type(exc).__name__}: {exc}"
            filas.append(fila)
            continue

        fila["recuperados"] = [r.get("fuente", "?") for r in res]
        for i, r in enumerate(fila["recuperados"], 1):
            if p["fuente"].lower() in str(r).lower():
                fila["rank"] = i
                break
        filas.append(fila)

    return {"filas": filas, "top_k": top_k,
            "adversarias": evaluar_adversarias() if incluir_adversarias else []}


def evaluar_adversarias(adversarias: Optional[List[Dict]] = None) -> List[Dict]:
    """
    Pregunta cada consulta al dominio EQUIVOCADO y comprueba que el sistema no
    presente lo recuperado como pericia pertinente sin advertirlo.

    Correcto: no devolver nada, o devolver declarando qué términos no conoce.
    Incorrecto: devolver un fragmento sin ninguna señal de alcance.
    """
    adversarias = adversarias or ADVERSARIAS
    from src.rag.buscador_lexico import BuscadorLexico

    out = []
    for a in adversarias:
        fila = dict(a, n=0, bloque="", declara=False, error=None)
        try:
            b = BuscadorLexico(a["dominio"])
            res = b.buscar(a["pregunta"], top_k=3)
            fila["n"] = len(res)
            fila["bloque"] = b.buscar_para_prompt(a["pregunta"], top_k=3)
        except Exception as exc:
            fila["error"] = f"{type(exc).__name__}: {exc}"
            out.append(fila)
            continue
        # Correcto si no devuelve nada, o si el bloque declara el alcance.
        fila["declara"] = (fila["n"] == 0
                           or "ALCANCE DE ESTE CORPUS" in fila["bloque"])
        out.append(fila)
    return out


def _metricas(filas: List[Dict], solo_discriminantes: bool = True) -> Dict:
    """
    recall@1 sobre todas las aplicables; recall@3 sobre las ELEGIBLES.

    Se devuelven dos poblaciones distintas a propósito. `r3` mide solo las
    preguntas de dominios con ≥ MIN_DOCS_PARA_R3 documentos, porque en un
    dominio pequeño el top-3 abarca el corpus entero y el número no informa de
    nada. Promediar ambas daría un @3 inflado por los dominios donde acertar es
    gratis — que es exactamente la confianza falsa que hay que evitar.
    """
    universo = [f for f in filas if f["aplicable"]
                and (f["discrim"] or not solo_discriminantes)]
    n = len(universo)
    if not n:
        return {"n": 0, "r1": None, "r3": None, "n_r3": 0, "r3_activo": False}

    r1 = sum(1 for f in universo if f["rank"] == 1) / n

    elegibles = [f for f in universo if f.get("elegible_r3")]
    n_r3 = len(elegibles)
    r3 = (sum(1 for f in elegibles if f["rank"] is not None) / n_r3
          if n_r3 else None)

    # Informativo: @3 sobre TODAS, para poder mirarlo aunque no gobierne.
    r3_todas = sum(1 for f in universo if f["rank"] is not None) / n

    return {"n": n, "r1": r1, "r3": r3, "r3_todas": r3_todas,
            "n_r3": n_r3, "r3_activo": n_r3 > 0}


def informe(res: Dict) -> int:
    """Imprime el resultado. Devuelve el código de salida sugerido."""
    filas = res["filas"]
    ancho = 74
    print("=" * ancho)
    print("  PREGUNTAS-ORO DEL RAG LÉXICO — ¿sale el documento correcto?")
    print("=" * ancho)

    for dom in ("VaR", "LaR", "conductuales", "shared"):
        del_dom = [f for f in filas if f["dominio"] == dom]
        if not del_dom:
            continue
        fuentes = _fuentes_del_dominio(dom)
        nota = ("  ⚠️ un solo documento: estas preguntas NO discriminan"
                if len(fuentes) <= 1 else "")
        print(f"\n── {dom}  ({len(fuentes)} documento(s)){nota}")
        for f in del_dom:
            if not f["aplicable"]:
                icono, det = "⚪", f"NO APLICABLE — no hay documento «{f['fuente']}» en el corpus"
            elif f["error"]:
                icono, det = "❌", f"ERROR — {f['error']}"
            elif f["rank"] == 1:
                icono, det = "✅", f"1º  {f['recuperados'][0]}"
            elif f["rank"]:
                icono, det = "🟡", (f"{f['rank']}º de {res['top_k']}  "
                                    f"{f['recuperados'][f['rank']-1]}")
            else:
                icono, det = "❌", ("NO RECUPERADO — salió: "
                                   + (", ".join(f["recuperados"][:3]) or "nada"))
            print(f"   {icono} {f['id']}  {f['pregunta'][:52]}…")
            print(f"        esperado: {f['fuente']:<18} → {det}")

    # ── Consultas adversarias ───────────────────────────────────────────────
    adv = res.get("adversarias") or []
    if adv:
        print(f"\n── CONSULTAS ADVERSARIAS (preguntadas al dominio equivocado)")
        for a in adv:
            if a["error"]:
                icono, det = "❌", f"ERROR — {a['error']}"
            elif a["n"] == 0:
                icono, det = "✅", "no devuelve nada"
            elif a["declara"]:
                icono, det = "✅", f"{a['n']} frag., declara el alcance"
            else:
                icono, det = "❌", (f"{a['n']} frag. SIN advertir: se presenta "
                                   f"como pericia pertinente")
            print(f"   {icono} {a['id']}  [{a['dominio']}] {a['pregunta'][:44]}…")
            print(f"        {det}")

    disc = _metricas(filas, solo_discriminantes=True)
    todo = _metricas(filas, solo_discriminantes=False)
    n_na = sum(1 for f in filas if not f["aplicable"])
    adv_mal = [a for a in adv if not a["declara"] or a["error"]]

    print("\n" + "=" * ancho)
    print("  MÉTRICAS")
    print("=" * ancho)
    if disc["n"]:
        print(f"  Preguntas DISCRIMINANTES aplicables : {disc['n']}")
        print(f"     recall@1 : {disc['r1']:.0%}   ← GOBIERNA "
              f"(umbral {UMBRAL_RECALL_1:.0%})")
        if disc["r3_activo"]:
            print(f"     recall@3 : {disc['r3']:.0%}   ← GOBIERNA también "
                  f"(umbral {UMBRAL_RECALL_3:.0%}, sobre {disc['n_r3']} "
                  f"pregunta(s) donde el documento PUEDE quedar fuera)")
        else:
            print(f"     recall@3 : {disc['r3_todas']:.0%}   INACTIVO — en ningún "
                  f"dominio el documento esperado puede quedar fuera del top-3.")
            print(f"                Con 2-3 docs el top-3 abarca el corpus "
                  f"entero: el número no informa.")
            print(f"                Se activará solo en cuanto el corpus crezca.")
    else:
        print("  Ninguna pregunta discriminante aplicable.")
    if todo["n"] != disc["n"]:
        print(f"  Incluyendo las no discriminantes ({todo['n']}): "
              f"recall@1 {todo['r1']:.0%}")
    if adv:
        print(f"  Adversarias que declaran su alcance : "
              f"{len(adv) - len(adv_mal)}/{len(adv)}")
    if n_na:
        print(f"  No aplicables (el corpus cambió) : {n_na}")

    print()
    fallo = False
    if not disc["n"]:
        print("  ⚠️  Sin base para dictaminar: revisa el corpus.")
        fallo = True
    elif disc["r1"] + 1e-9 < UMBRAL_RECALL_1:
        print("  ❌ RECALL@1 POR DEBAJO DEL UMBRAL. El corpus no devuelve el")
        print("     documento correcto en primer lugar: la «pericia de dominio»")
        print("     que se inyecta en el prompt está mal elegida.")
        fallo = True

    # Segundo umbral: solo sobre las preguntas donde el documento esperado
    # PUEDE quedar fuera del top-3. Ahí @3 distingue algo que @1 no ve.
    if disc["n"] and disc["r3_activo"] and disc["r3"] + 1e-9 < UMBRAL_RECALL_3:
        print("  ❌ RECALL@3 POR DEBAJO DEL UMBRAL. El documento correcto no")
        print("     entra en los 3 fragmentos que el prompt inyecta: el modelo")
        print("     no llegó a verlo. Es peor que un mal orden — es no verlo.")
        fallo = True
    if adv_mal:
        print("  ❌ Hay consultas de OTRO dominio que se recuperan sin declarar")
        print("     el alcance: el prompt las presentará como pericia pertinente.")
        fallo = True

    if fallo:
        return 1
    print("  ✅ El corpus recupera el documento correcto y declara su alcance")
    print("     ante consultas ajenas. Esto NO acredita que la respuesta del")
    print("     modelo sea buena: solo que vio el documento que debía ver.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[3])
    ap.add_argument("--strict", action="store_true",
                    help="exit 1 si el recall@3 baja del umbral")
    ap.add_argument("--dominio", help="evaluar solo un dominio")
    ap.add_argument("--top-k", type=int, default=3)
    args = ap.parse_args()

    preguntas = PREGUNTAS
    if args.dominio:
        preguntas = [p for p in PREGUNTAS if p["dominio"] == args.dominio]
        if not preguntas:
            print(f"❌ dominio desconocido: {args.dominio}")
            return 2

    code = informe(evaluar(preguntas, top_k=args.top_k))
    return code if args.strict else 0


if __name__ == "__main__":
    raise SystemExit(main())
