"""
scripts/auditar_cobertura_rag.py
═══════════════════════════════════════════════════════════════════════════════
¿Contra qué actividades del estándar VIRF está CIEGO el corpus de literatura?

QUÉ RESPONDE
────────────
No «¿funciona el RAG?» —eso lo dicen los tests— sino la pregunta que de verdad
gobierna la calidad de una validación:

    De las N actividades que el agente va a evaluar, ¿en cuántas tiene
    literatura de referencia que aportar, y en cuántas va a opinar a ciegas?

Un motor de recuperación perfecto sobre un corpus incompleto sigue dando
validaciones pobres, y el síntoma es mudo: el agente evalúa igual, con la misma
confianza, solo que sin fundamento documental. Esto lo hace visible y medible.

CÓMO LO MIDE
────────────
Reproduce EXACTAMENTE la consulta que hará `motor_ia._enriquecer_con_rag`
—`[ámbito] actividad`— y para cada una registra:

  · peso informativo (Σ IDF): ¿la consulta discrimina algo en este corpus?
  · mejor cobertura obtenida: ¿cuánto de la pregunta cubre el mejor fragmento?
  · términos huérfanos (df=0): vocabulario del estándar que NO existe en la
    literatura. Es la lista de la compra: dice qué falta y con qué palabras.

USO
───
    python scripts/auditar_cobertura_rag.py
    python scripts/auditar_cobertura_rag.py --dominio VaR --tier "Tier I"
    python scripts/auditar_cobertura_rag.py --detalle       # actividad a actividad
    python scripts/auditar_cobertura_rag.py --json informe.json

REQUISITO: los índices deben estar construidos.
    python scripts/rebuild_rag_databricks.py --dominio all
"""

import sys as _sys
from pathlib import Path as _Path

_RAIZ = _Path(__file__).resolve().parents[1]
if str(_RAIZ) not in _sys.path:
    _sys.path.insert(0, str(_RAIZ))

from modulos.consola import configurar_consola

configurar_consola()

# ─────────────────────────────────────────────────────────────────────────
#  ⚠️  NO forma parte del flujo VIRF activo. Herramienta de auditoría del
#      corpus: se ejecuta al montar o ampliar la literatura de referencia.
# ─────────────────────────────────────────────────────────────────────────

import argparse
import json
import logging
from collections import Counter

# Umbrales de la clasificación. No pretenden ser una métrica de la industria:
# son los tres estados que cambian lo que hay que HACER.
#   SIN_APOYO  → no hay nada; el agente evalúa a ciegas.
#   DEBIL      → hay algo, pero es apoyo genérico.
#   CUBIERTA   → hay literatura pertinente Y específica.
COBERTURA_SOLIDA = 0.50
COBERTURA_DEBIL = 0.20

# ⚠️ LA COBERTURA SOLA MIENTE, Y HACIA ARRIBA.
#
# La primera versión de este script clasificaba solo por cobertura y daba «97 %
# cubierto» para un corpus de tres documentos de 6 KB. Al mirar QUÉ términos
# producían esa cobertura apareció el truco:
#
#   «Verifica la existencia de control de cambios/versiones» → cobertura 0.50
#    …porque el fragmento contiene la palabra «documentación». Y nada más.
#
# La cobertura es una fracción del peso informativo, así que un único término de
# IDF alto —«document», «dato»— basta para llenarla cuando el resto de la
# consulta no existe en el corpus. Es cierto que el fragmento cubre esa fracción;
# es falso que la literatura APOYE la actividad.
#
# Por eso «CUBIERTA» exige además ANCLAJE: al menos dos términos distintos con
# IDF > 0 en común. Un solo término, por informativo que sea, es coincidencia de
# vocabulario, no apoyo documental. Un informe de auditoría que se equivoca hacia
# arriba es peor que no tenerlo: da por resuelto lo que hay que arreglar.
MIN_TERMINOS_ANCLAJE = 2


def _clasificar(mejor_cobertura, n_resultados, n_terminos_informativos):
    if n_resultados == 0:
        return "SIN_APOYO"
    if (mejor_cobertura >= COBERTURA_SOLIDA
            and n_terminos_informativos >= MIN_TERMINOS_ANCLAJE):
        return "CUBIERTA"
    if mejor_cobertura >= COBERTURA_DEBIL or n_terminos_informativos >= 1:
        return "DEBIL"
    return "SIN_APOYO"


def _anclas(buscador, consulta, resultado):
    """
    Términos con IDF > 0 que la consulta y el fragmento comparten.

    Son los que SOSTIENEN la cobertura. Se devuelven ordenados de más raro a más
    común, porque leerlos es la forma más rápida de saber si el apoyo es real:
    `[('kupiec', 0.64), ('backtest', 0.41)]` es apoyo; `[('document', 1.0)]` a
    secas es que el fragmento menciona la palabra «documentación».
    """
    from src.rag.indexador_lexico import tokenizar

    indice = buscador._indice
    idf = getattr(buscador._bm25, "idf", {}) or {}
    for i, c in enumerate(indice.chunks):
        if c["fuente"] == resultado["fuente"] and c.get("chunk") == resultado["chunk"]:
            comunes = set(tokenizar(consulta)) & set(indice.tokens[i])
            pares = [(t, round(max(idf.get(t, 0.0), 0.0), 3)) for t in comunes]
            return sorted([p for p in pares if p[1] > 0], key=lambda p: -p[1])
    return []


def auditar(dominio: str, tier: str, detalle: bool, salida_json: str | None) -> int:
    from modulos.motor_ia import leer_estandares_virf
    from src.rag import inferir_dominio
    from src.rag.buscador_lexico import BuscadorLexico

    estandar = leer_estandares_virf(tier)
    if not estandar:
        print(f"\n❌ No se pudo leer el estándar VIRF para el tier {tier!r}.\n")
        return 1

    buscador = BuscadorLexico(dominio, autoconstruir=False)
    if not buscador._asegurar_cargado():
        print(f"\n❌ No hay índice para el dominio '{dominio}'.\n"
              f"   Constrúyelo:  python scripts/rebuild_rag_databricks.py "
              f"--dominio {dominio}\n")
        return 1

    indice = buscador._indice
    docs = sorted({c["fuente"] for c in indice.chunks})

    print(f"\n{'═' * 78}")
    print(f"  AUDITORÍA DE COBERTURA DEL CORPUS RAG")
    print(f"  dominio: {dominio}  ·  tier: {tier}")
    print(f"  literatura: {len(docs)} documentos, {len(indice)} fragmentos")
    print(f"{'═' * 78}")

    filas = []
    huerfanos = Counter()

    for ambito, actividades in estandar.items():
        for act in actividades:
            texto = (act.get("actividad") or "").strip()
            if not texto:
                continue
            # MISMA consulta que construye motor_ia._enriquecer_con_rag.
            consulta = f"[{ambito}] {texto}"

            diag = buscador.diagnostico_consulta(consulta)
            res = buscador.buscar(consulta, top_k=3)
            mejor = max((r["cobertura"] for r in res), default=0.0)

            for t in diag.get("terminos_ausentes", []):
                huerfanos[t] += 1

            # Qué términos sostienen realmente el mejor resultado. Sin esto, la
            # cobertura no distingue apoyo documental de coincidencia de
            # vocabulario — ver la nota sobre MIN_TERMINOS_ANCLAJE.
            anclas = _anclas(buscador, consulta, res[0]) if res else []

            filas.append({
                "ambito": ambito,
                "actividad": texto,
                "control": (act.get("control") or "")[:120],
                "peso_informativo": diag.get("peso_informativo", 0.0),
                "discriminante": diag.get("discriminante", False),
                "mejor_cobertura": round(mejor, 4),
                "n_resultados": len(res),
                "fuente_top": res[0]["fuente"] if res else None,
                "terminos_ausentes": diag.get("terminos_ausentes", []),
                "terminos_ancla": anclas,
                "estado": _clasificar(mejor, len(res), len(anclas)),
            })

    total = len(filas)
    if not total:
        print("\n⚠️  El estándar no tiene actividades legibles.\n")
        return 1

    # ── Resumen por ámbito ───────────────────────────────────────────────────
    print(f"\n{'ámbito':32} {'act.':>5} {'cubiertas':>10} {'débiles':>8} "
          f"{'SIN APOYO':>10}")
    print(f"{'-'*32} {'-'*5} {'-'*10} {'-'*8} {'-'*10}")
    por_ambito = {}
    for f in filas:
        por_ambito.setdefault(f["ambito"], []).append(f)
    for ambito, fs in por_ambito.items():
        c = sum(1 for x in fs if x["estado"] == "CUBIERTA")
        d = sum(1 for x in fs if x["estado"] == "DEBIL")
        s = sum(1 for x in fs if x["estado"] == "SIN_APOYO")
        alarma = " ⚠️" if s > len(fs) / 2 else ""
        print(f"{ambito[:32]:32} {len(fs):>5} {c:>10} {d:>8} {s:>10}{alarma}")

    cub = sum(1 for f in filas if f["estado"] == "CUBIERTA")
    deb = sum(1 for f in filas if f["estado"] == "DEBIL")
    sin = sum(1 for f in filas if f["estado"] == "SIN_APOYO")
    print(f"{'-'*32} {'-'*5} {'-'*10} {'-'*8} {'-'*10}")
    print(f"{'TOTAL':32} {total:>5} {cub:>10} {deb:>8} {sin:>10}")
    print(f"\n  Apoyo documental: {(cub + deb) / total:.0%} de las actividades "
          f"({cub / total:.0%} sólido, con ≥{MIN_TERMINOS_ANCLAJE} términos de anclaje)")

    # Profundidad del corpus. Un corpus diminuto puede dar cifras buenas por pura
    # coincidencia de vocabulario común; conviene decirlo junto al porcentaje y
    # no en una nota al pie que nadie lee.
    frag_por_act = len(indice) / total
    if len(indice) < 60 or frag_por_act < 2:
        print(f"\n  ⚠️  CORPUS POCO PROFUNDO: {len(indice)} fragmentos para "
              f"{total} actividades ({frag_por_act:.1f} por actividad).")
        print("      Con tan poca literatura, las cifras de arriba miden sobre todo")
        print("      solape de vocabulario general. Trátalas como suelo, no como")
        print("      evidencia de que el corpus sea suficiente.")

    # ── Actividades ciegas ───────────────────────────────────────────────────
    ciegas = [f for f in filas if f["estado"] == "SIN_APOYO"]
    if ciegas:
        print(f"\n{'─' * 78}")
        print(f"  ACTIVIDADES SIN APOYO DOCUMENTAL ({len(ciegas)})")
        print(f"  El agente las evaluará sin literatura de referencia que citar.")
        print(f"{'─' * 78}")
        for f in ciegas[:25]:
            print(f"  · [{f['ambito'][:22]}] {f['actividad'][:76]}")
            if f["terminos_ancla"]:
                print(f"      (solo comparte: {f['terminos_ancla'][:3]})")
        if len(ciegas) > 25:
            print(f"  … y {len(ciegas) - 25} más (usa --json para verlas todas)")

    # ── Vocabulario que falta ────────────────────────────────────────────────
    if huerfanos:
        print(f"\n{'─' * 78}")
        print(f"  VOCABULARIO DEL ESTÁNDAR AUSENTE DEL CORPUS")
        print(f"  Términos que el estándar usa y la literatura no contiene. Es la")
        print(f"  lista de la compra: o falta ese documento, o lo dice con otra")
        print(f"  palabra (ver «excepciones» vs. «excedencias» en GUIA_RAG_LEXICO §6).")
        print(f"{'─' * 78}")
        print(f"      {'término':24} {'actividades afectadas':>22}")
        print(f"      {'-'*24} {'-'*22}")
        for termino, n in huerfanos.most_common(20):
            print(f"      {termino:24} {n:>22}")

    # ── Detalle ──────────────────────────────────────────────────────────────
    if detalle:
        print(f"\n{'─' * 78}\n  DETALLE ACTIVIDAD A ACTIVIDAD\n{'─' * 78}")
        for f in sorted(filas, key=lambda x: x["mejor_cobertura"]):
            print(f"\n  [{f['estado']}] {f['ambito']} · {f['actividad'][:70]}")
            print(f"      ΣIDF={f['peso_informativo']:.2f}  "
                  f"cobertura={f['mejor_cobertura']:.2f}  "
                  f"fuente={f['fuente_top'] or '—'}")
            if f["terminos_ancla"]:
                print(f"      apoyado en: {f['terminos_ancla'][:6]}")
            if f["terminos_ausentes"]:
                print(f"      sin match:  {f['terminos_ausentes'][:8]}")

    # ── Veredicto ────────────────────────────────────────────────────────────
    print(f"\n{'═' * 78}")
    pct = (cub + deb) / total
    if sin == 0:
        print("  🟢 Todas las actividades tienen literatura que citar.")
    elif pct >= 0.8:
        print(f"  🟡 {sin} actividades sin apoyo. Corpus utilizable; ampliarlo")
        print("     con los documentos que cubran el vocabulario de arriba.")
    else:
        print(f"  🔴 {sin} de {total} actividades sin apoyo documental.")
        print("     El RAG aporta poco a esta validación. Prioridad: ampliar")
        print("     `inputs/rag/<dominio>/` antes de fiarse del contexto RAG.")
    print(f"{'═' * 78}\n")

    if salida_json:
        destino = _Path(salida_json)
        destino.write_text(json.dumps({
            "dominio": dominio, "tier": tier,
            "documentos": docs, "fragmentos": len(indice),
            "total_actividades": total,
            "cubiertas": cub, "debiles": deb, "sin_apoyo": sin,
            "vocabulario_ausente": huerfanos.most_common(),
            "actividades": filas,
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  Informe JSON: {destino}\n")

    return 0


def main() -> int:
    p = argparse.ArgumentParser(
        description="Audita qué actividades del estándar VIRF tienen apoyo en el "
                    "corpus RAG y cuáles no.")
    p.add_argument("--dominio", default="shared",
                   choices=["LaR", "VaR", "conductuales", "shared"])
    p.add_argument("--tier", default="Tier I")
    p.add_argument("--detalle", action="store_true",
                   help="lista actividad a actividad, de peor a mejor cobertura")
    p.add_argument("--json", dest="salida_json", default=None,
                   help="vuelca el informe completo a un fichero JSON")
    p.add_argument("--verboso", action="store_true")
    args = p.parse_args()

    if not args.verboso:
        logging.disable(logging.CRITICAL)

    return auditar(args.dominio, args.tier, args.detalle, args.salida_json)


if __name__ == "__main__":
    raise SystemExit(main())
