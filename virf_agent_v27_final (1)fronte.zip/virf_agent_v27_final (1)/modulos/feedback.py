"""
modulos/feedback.py
Gestión de feedback del validador sobre las evaluaciones del agente.

Flujo:
  1. Al final de cada corrida (--preprdc o --prdc), se lanza un bucle interactivo
     donde el usuario puede registrar correcciones a cualquier actividad evaluada.
  2. El feedback se guarda en feedback/historial_feedback.json
  3. En la siguiente corrida, el motor IA recibe el historial como contexto adicional
     para ajustar sus evaluaciones.
  4. Con --estadisticafeedback se genera un informe de precisión del agente.
"""

import hashlib
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional

FEEDBACK_PATH = Path(__file__).parent.parent / "feedback" / "historial_feedback.json"


# ═════════════════════════════════════════════════════════════════════════════
# [AUDIT-FIX PENDIENTE-2] AUTORÍA DE LAS CORRECCIONES
#
# Qué había antes y por qué estaba mal
# ────────────────────────────────────
# El historial guardaba QUÉ se corrigió pero no QUIÉN lo corrigió. El anexo del
# Word decía «el validador ajustó 2 puntajes» sin poder acreditar cuál de los
# 2-5 validadores del equipo fue, y ese anexo es justo la evidencia de que hubo
# supervisión humana: sin autor, acredita que alguien tocó el fichero.
#
# El efecto colateral estaba en `override_humano.calidad_proceso()`, que como no
# tenía el dato atribuía las correcciones «por modelo aprobado» —todas las
# correcciones de un modelo se imputaban a quien firmó su informe— y lo
# declaraba explícitamente como aproximación. Con dos personas alternándose
# sobre el mismo modelo, la señal de «aprueba en bloque sin corregir» podía
# señalar a quien sí revisó.
#
# Retrocompatibilidad
# ───────────────────
# Los registros anteriores no tienen el campo y NO se pueden descartar: son
# meses de calibración que alimentan el ajuste anti-sesgo. Se leen siempre a
# través de `autor_de()`, que los devuelve como SIN_AUTOR. Ausencia declarada,
# nunca un nombre inventado (§7 del prompt de continuidad).
# ═════════════════════════════════════════════════════════════════════════════

#: Autor de los registros previos a PENDIENTE-2. No es un valor de relleno: es
#: la declaración de que ese dato no se capturó cuando se registró la corrección.
SIN_AUTOR = "(no registrado)"


def autor_de(reg: Dict) -> str:
    """
    Autor de una corrección, con los registros antiguos tratados como SIN_AUTOR.

    [§3.4] `reg.get("validador", SIN_AUTOR)` sería INCORRECTO: el segundo
    argumento de `.get` solo actúa si la clave FALTA, no si está presente con
    valor nulo. Un registro con `{"validador": None}` —que es lo que produce una
    corrida sin identidad resuelta— devolvería `None` y reventaría al comparar
    o al pintarlo en el Word. Ese defecto ya se ha producido dos veces en este
    proyecto. Con `or` se cubren los tres casos: ausente, nulo y cadena vacía.
    """
    return (reg.get("validador") or "").strip() or SIN_AUTOR


def cargo_de(reg: Dict) -> str:
    """Cargo del autor de una corrección. Mismo criterio que `autor_de`."""
    return (reg.get("cargo") or "").strip() or SIN_AUTOR


def identidad_para_feedback(nombre: Optional[str] = None,
                            cargo: Optional[str] = None) -> Dict[str, str]:
    """
    Identidad que firma las correcciones de esta sesión.

    Se resuelve con `validador_humano.solicitar_identidad`, que es LA MISMA
    fuente que firma el informe: flags `--validador`/`--cargo`, variables
    VIRF_VALIDADOR/VIRF_VALIDADOR_CARGO o pregunta interactiva. Usar otra fuente
    permitiría que el informe lo firmara Ana y sus correcciones constaran a
    nombre de Luis.

    `obligatorio=False` a propósito: el bucle de feedback corre en
    PRE-PRODUCCIÓN, donde `--prdc` no ha exigido identidad. Bloquear aquí
    impediría registrar calibración —que es lo que da valor al historial— por no
    haber puesto un flag. Sin identidad se registra SIN_AUTOR, que es peor que
    tenerla pero mucho mejor que perder la corrección.

    `interactivo=False`: preguntar el nombre en medio del bucle de correcciones
    interrumpiría el flujo que el validador está usando. Se toma de flag o
    entorno, o se declara ausente.
    """
    try:
        from modulos.validador_humano import solicitar_identidad
        ident = solicitar_identidad(nombre, cargo, interactivo=False,
                                    obligatorio=False)
    except Exception:
        # Nunca puede tumbar el registro de una corrección: el juicio humano es
        # el dato caro de esta función, la atribución es el dato deseable.
        ident = {}
    return {
        "validador": (ident.get("validador") or "").strip() or SIN_AUTOR,
        "cargo": (ident.get("cargo") or "").strip() or SIN_AUTOR,
    }


# ─── Carga y guardado del JSON ────────────────────────────────────────────────

def _id_registro(reg: Dict) -> str:
    """
    Identidad estable de un registro, para poder fusionar sin duplicar.
    Si no trae `_id`, se deriva de su contenido.
    """
    if reg.get("_id"):
        return str(reg["_id"])
    clave = "|".join(str(reg.get(k, "")) for k in
                     ("timestamp", "ambito", "actividad", "modelo", "tier",
                      "puntaje_agente", "puntaje_humano"))
    return hashlib.sha256(clave.encode("utf-8")).hexdigest()[:16]


def cargar_historial() -> List[Dict]:
    """
    Carga el historial completo de feedback desde el JSON.

    [AUDIT-FIX] Antes, un JSON corrupto devolvía `[]` EN SILENCIO. Combinado
    con `guardar_historial`, eso borraba el historial entero: corrupción →
    lista vacía → el siguiente guardado sobrescribe → correcciones humanas
    perdidas para siempre, sin un solo aviso. Ahora el fichero dañado se
    preserva con sufijo `.corrupto-<ts>` y se avisa por consola.
    """
    if not FEEDBACK_PATH.exists():
        return []
    try:
        with open(FEEDBACK_PATH, encoding="utf-8") as f:
            datos = json.load(f)
        return datos if isinstance(datos, list) else []
    except (json.JSONDecodeError, IOError) as exc:
        respaldo = FEEDBACK_PATH.with_suffix(
            f".corrupto-{datetime.now():%Y%m%d%H%M%S}.json")
        try:
            FEEDBACK_PATH.replace(respaldo)
            aviso = f"se conservó una copia en {respaldo.name}"
        except OSError:
            aviso = "NO se pudo conservar copia"
        print(f"\n  ⚠️  historial_feedback.json ilegible ({exc}); {aviso}.")
        print("     Se continúa con historial vacío: revisa esa copia antes")
        print("     de registrar nuevo feedback si te importa el histórico.\n")
        return []


def guardar_historial(historial: List[Dict]):
    """
    Persiste el historial en el JSON.

    [AUDIT-FIX] Antes: `open(path, "w")` + `json.dump`, sin lock ni escritura
    atómica — al contrario que document_cache.py, que sí tenía ambas pese a
    guardar datos REGENERABLES. Medido sobre este fichero:
        · 4 procesos simultáneos → se perdía el 77% de los registros
        · 6 de 6 `kill -9` durante la escritura → JSON corrupto
    El historial de feedback no es regenerable: son correcciones humanas, y
    alimentan la calibración anti-sesgo del agente.

    Ahora reutiliza las mismas primitivas ya probadas de document_cache:
    lock entre procesos, relectura+fusión, y tmp+os.replace atómico.
    """
    FEEDBACK_PATH.parent.mkdir(parents=True, exist_ok=True)

    try:
        from modulos.document_cache import _escribir_json_atomico, _lock_archivo
    except ImportError:      # degradación: mejor guardar que perder el feedback
        with open(FEEDBACK_PATH, "w", encoding="utf-8") as f:
            json.dump(historial, f, ensure_ascii=False, indent=2)
        return

    for reg in historial:
        reg.setdefault("_id", _id_registro(reg))

    with _lock_archivo(FEEDBACK_PATH):
        # Fusión: los registros que otro proceso añadió mientras trabajábamos
        # se conservan; los nuestros se añaden sin duplicar.
        fusionado = list(historial)
        vistos = {r["_id"] for r in fusionado}
        try:
            if FEEDBACK_PATH.exists():
                with open(FEEDBACK_PATH, encoding="utf-8") as f:
                    en_disco = json.load(f)
                if isinstance(en_disco, list):
                    ajenos = [r for r in en_disco
                              if _id_registro(r) not in vistos]
                    fusionado = ajenos + fusionado
        except (json.JSONDecodeError, OSError):
            pass   # disco ilegible: se escribe lo que tenemos, que es más

        _escribir_json_atomico(FEEDBACK_PATH, fusionado)


# ─── Bucle interactivo de feedback ───────────────────────────────────────────

def _mostrar_resumen_evaluaciones(evaluaciones_por_ambito: Dict[str, List[Dict]]):
    """Imprime un índice numerado de todas las actividades evaluadas."""
    print("\n" + "═" * 65)
    print("  📝 REGISTRO DE FEEDBACK")
    print("  Puedes corregir cualquier evaluación del agente.")
    print("  Escribe 'fin' cuando termines, 'ver' para ver actividades.")
    print("═" * 65)

    idx = 1
    indice = {}
    for ambito, evals in evaluaciones_por_ambito.items():
        print(f"\n  [{ambito.upper()}]")
        for ev in evals:
            puntaje = ev.get("puntaje", "?")
            actividad = ev.get("actividad", "")[:65]
            print(f"    {idx:>3}. [{puntaje}/5] {actividad}")
            indice[idx] = {"ambito": ambito, "eval": ev}
            idx += 1
    print()
    return indice


class _SinEntradaInteractiva(Exception):
    """[CI-FIX] stdin cerrado o interrumpido: se aborta el feedback sin fallar."""


def _leer(prompt: str = "") -> str:
    """
    [CI-FIX] input() seguro para entornos NO interactivos (cron, CI, nohup,
    docker sin -it, `< /dev/null`).

    Antes: input() lanzaba EOFError, que subía hasta el except genérico de
    agente.py y provocaba sys.exit(1) — el pipeline terminaba con código de
    error PESE A haber completado la evaluación y escrito el JSON.
    Ahora: se convierte en _SinEntradaInteractiva y el bucle sale limpiamente.
    """
    if prompt:
        print(prompt, end="", flush=True)
    try:
        return input().strip()
    except (EOFError, KeyboardInterrupt):
        raise _SinEntradaInteractiva


def bucle_feedback_consola(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    titulo_modelo: str,
    tier: str,
    version: str,
    validador: Optional[str] = None,
    cargo: Optional[str] = None,
) -> List[Dict]:
    """
    Bucle interactivo al final de la ejecución.
    Retorna lista de feedbacks ingresados en esta sesión.

    [CI-FIX] Si stdin no es interactivo, retorna [] sin lanzar excepción,
    permitiendo que el pipeline termine con código de salida 0.

    [PENDIENTE-2] `validador`/`cargo` son los de `--validador`/`--cargo`. Se
    aceptan opcionalmente para no romper a los llamantes existentes; si no
    llegan, `identidad_para_feedback` los busca en el entorno.
    """
    # Detección temprana: si stdin no es un TTY, ni siquiera preguntamos.
    if not sys.stdin or not sys.stdin.isatty():
        print("  ℹ️  stdin no interactivo — registro de feedback omitido.")
        print("     (usa --prdc para suprimir este bloque explícitamente)\n")
        return []

    try:
        return _bucle_feedback_interactivo(
            evaluaciones_por_ambito, titulo_modelo, tier, version,
            validador, cargo
        )
    except _SinEntradaInteractiva:
        print("\n  ℹ️  Entrada interrumpida — feedback no registrado.\n")
        return []


def _bucle_feedback_interactivo(
    evaluaciones_por_ambito: Dict[str, List[Dict]],
    titulo_modelo: str,
    tier: str,
    version: str,
    validador: Optional[str] = None,
    cargo: Optional[str] = None,
) -> List[Dict]:
    """Implementación interactiva real (ver bucle_feedback_consola)."""
    historial = cargar_historial()
    # [PENDIENTE-2] Se resuelve UNA vez por sesión, antes del bucle: preguntar o
    # releer el entorno por cada corrección sería ruido, y todas las
    # correcciones de una sesión las hace la misma persona.
    _identidad = identidad_para_feedback(validador, cargo)
    nuevos_feedbacks = []
    indice = _mostrar_resumen_evaluaciones(evaluaciones_por_ambito)

    respuesta = _leer("  ¿Deseas registrar feedback? (s/n): ").lower()
    if respuesta != "s":
        print("  Sin feedback registrado. ✓\n")
        return []

    while True:
        entrada = _leer(
            "\n  Número de actividad a corregir (o 'fin' para terminar, 'ver' para listar): "
        ).lower()

        if entrada == "fin":
            break

        if entrada == "ver":
            indice = _mostrar_resumen_evaluaciones(evaluaciones_por_ambito)
            continue

        try:
            num = int(entrada)
            if num not in indice:
                print(f"  [!] Número {num} no válido. Rango: 1-{max(indice.keys())}")
                continue
        except ValueError:
            print("  [!] Ingresa un número, 'fin' o 'ver'.")
            continue

        item = indice[num]
        ambito    = item["ambito"]
        actividad = item["eval"].get("actividad", "")
        # [AUDIT-FIX · §3.4] Era `.get("puntaje", 0)`, y el respaldo NO actúa
        # cuando la clave existe con valor nulo — que es justo lo que el
        # invariante 2 escribe para una actividad no evaluada. Al calcular
        # `diferencia = puntaje_correcto - puntaje_agente` reventaba con
        # TypeError y se llevaba por delante la sesión de feedback.
        #
        # Misma trampa que rompía las skills (`skills/base.py`), encontrada al
        # revisar TODAS las rutas del patrón, no solo la que falló.
        puntaje_agente = item["eval"].get("puntaje")

        print(f"\n  Ámbito   : {ambito}")
        print(f"  Actividad: {actividad[:80]}")

        if puntaje_agente is None:
            # No se rechaza por capricho: el historial de feedback mide el ERROR
            # DEL AGENTE para calibrarlo. Una actividad que el agente nunca
            # puntuó no tiene error que medir, y registrar una "corrección"
            # sobre un puntaje inexistente contaminaría el ajuste anti-sesgo
            # con una diferencia inventada.
            _motivo = ("no se aportó evidencia" if item["eval"].get("sin_evidencia")
                       else "falló técnicamente")
            print(f"  ⚠️  Esta actividad NO fue evaluada ({_motivo}), así que no")
            print( "      hay puntaje del agente que corregir.")
            print( "      Re-ejecuta la corrida para completarla; si falta")
            print( "      evidencia, apórtala antes de volver a lanzar.")
            continue

        print(f"  Puntaje del agente: {puntaje_agente}/5")

        # Puntaje correcto
        while True:
            try:
                puntaje_correcto = int(_leer("  Puntaje correcto según tu criterio (1-5): "))
                if 1 <= puntaje_correcto <= 5:
                    break
                print("  [!] Ingresa un número entre 1 y 5.")
            except ValueError:
                print("  [!] Número inválido.")

        # Comentario
        comentario = _leer("  ¿Qué debió hacer el agente? (descripción breve): ")
        if not comentario:
            comentario = "Sin comentario adicional."

        feedback_entry = {
            "fecha":           datetime.now().strftime("%d/%m/%Y %H:%M"),
            "titulo_modelo":   titulo_modelo,
            "tier":            tier,
            "version":         version,
            "ambito":          ambito,
            "actividad":       actividad,
            "puntaje_agente":  puntaje_agente,
            "puntaje_correcto": puntaje_correcto,
            "diferencia":      puntaje_correcto - puntaje_agente,
            "comentario":      comentario,
            # [PENDIENTE-2] Quién firma esta corrección. Sin esto, el anexo del
            # Word acredita que alguien tocó el fichero, no que un validador
            # identificable revisó y decidió.
            "validador":       _identidad["validador"],
            "cargo":           _identidad["cargo"],
        }

        historial.append(feedback_entry)
        nuevos_feedbacks.append(feedback_entry)
        guardar_historial(historial)

        signo = "+" if feedback_entry["diferencia"] > 0 else ""
        print(f"  ✓ Feedback guardado. Diferencia: {signo}{feedback_entry['diferencia']} puntos")

    if nuevos_feedbacks:
        print(f"\n  ✅ {len(nuevos_feedbacks)} feedback(s) guardados en feedback/historial_feedback.json\n")
    else:
        print("  Sin cambios registrados.\n")

    return nuevos_feedbacks


# ─── Contexto de feedback para el motor IA ───────────────────────────────────

def construir_contexto_feedback(ambito: str, actividad: str) -> str:
    """
    Busca en el historial si hay feedback previo relevante para esta actividad
    y lo formatea como contexto adicional para el motor IA.
    """
    historial = cargar_historial()
    if not historial:
        return ""

    relevantes = [
        fb for fb in historial
        if fb.get("ambito", "").lower() == ambito.lower()
        and (
            actividad.lower()[:40] in fb.get("actividad", "").lower()
            or fb.get("actividad", "").lower()[:40] in actividad.lower()
        )
    ]

    if not relevantes:
        # Feedback del mismo ámbito como guía general
        del_ambito = [fb for fb in historial if fb.get("ambito", "").lower() == ambito.lower()][-3:]
        if not del_ambito:
            return ""
        relevantes = del_ambito

    lineas = ["HISTORIAL DE FEEDBACK DEL VALIDADOR (correcciones a evaluaciones anteriores):"]
    for fb in relevantes[-5:]:  # máximo 5 más recientes
        diff = fb.get("diferencia", 0)
        signo = "sobreestimó" if diff < 0 else "subestimó" if diff > 0 else "coincidió"
        lineas.append(
            f"- Actividad: '{fb.get('actividad','')[:60]}' | "
            f"Agente dio {fb.get('puntaje_agente')}/5, correcto era {fb.get('puntaje_correcto')}/5 "
            f"(el agente {signo} en {abs(diff)} punto(s)). "
            f"Comentario: {fb.get('comentario','')}"
        )
    lineas.append("→ Considera este historial para calibrar tu evaluación actual.")
    return "\n".join(lineas)


# ─── Estadísticas de precisión ───────────────────────────────────────────────

def _registros_utilizables(historial: List[Dict]) -> List[Dict]:
    """
    [AUDIT-FIX] Filtra los registros con los que SÍ se puede calcular.

    `calcular_estadisticas` accedía a `fb["diferencia"]` directamente y hacía
    `abs()` sin comprobar el tipo. Medido sobre historiales degenerados:

        · falta el campo 'diferencia'   → KeyError
        · 'diferencia' es texto          → TypeError: bad operand type for abs()
        · un elemento no es un dict      → TypeError: string indices must be int

    Cuatro de seis casos tumbaban `--estadisticafeedback` con un traceback,
    mientras `analizar_patron_errores` —del mismo subsistema— los manejaba
    todos sin despeinarse. El historial es editable a mano y lo escriben
    versiones distintas del agente: tiene que tolerar registros viejos o rotos.
    """
    validos = []
    for reg in historial or []:
        if not isinstance(reg, dict):
            continue
        try:
            reg = {**reg, "diferencia": float(reg["diferencia"])}
        except (KeyError, TypeError, ValueError):
            continue
        validos.append(reg)
    return validos


def calcular_estadisticas() -> Dict:
    """Calcula métricas de precisión del agente basadas en el historial de feedback."""
    crudo = cargar_historial()
    historial = _registros_utilizables(crudo)
    if not historial:
        if crudo:
            return {"error": (
                f"El historial tiene {len(crudo)} registro(s) pero ninguno es "
                f"utilizable (falta 'diferencia' o tiene un tipo inesperado). "
                f"Revisa {FEEDBACK_PATH.name}."
            )}
        return {"error": "No hay historial de feedback registrado."}

    _descartados = len(crudo) - len(historial)
    if _descartados:
        print(f"  ⚠️  {_descartados} registro(s) de feedback ignorados por estar "
              f"malformados (de {len(crudo)}).")

    total = len(historial)
    diferencias = [abs(fb["diferencia"]) for fb in historial]
    diferencias_con_signo = [fb["diferencia"] for fb in historial]

    exactos      = sum(1 for d in diferencias if d == 0)
    diff_1       = sum(1 for d in diferencias if d == 1)
    diff_2_mas   = sum(1 for d in diferencias if d >= 2)
    sobreestima  = sum(1 for d in diferencias_con_signo if d < 0)
    subestima    = sum(1 for d in diferencias_con_signo if d > 0)

    mae = sum(diferencias) / total  # Mean Absolute Error
    sesgo = sum(diferencias_con_signo) / total  # Sesgo promedio (+ = subestima, - = sobreestima)

    # Por ámbito
    ambitos_stats = {}
    for fb in historial:
        amb = fb.get("ambito", "Desconocido")
        if amb not in ambitos_stats:
            ambitos_stats[amb] = {"total": 0, "suma_diff_abs": 0, "suma_diff": 0, "exactos": 0}
        ambitos_stats[amb]["total"] += 1
        ambitos_stats[amb]["suma_diff_abs"] += abs(fb["diferencia"])
        ambitos_stats[amb]["suma_diff"] += fb["diferencia"]
        if fb["diferencia"] == 0:
            ambitos_stats[amb]["exactos"] += 1

    for amb, s in ambitos_stats.items():
        s["mae"]           = round(s["suma_diff_abs"] / s["total"], 3)
        s["sesgo"]         = round(s["suma_diff"] / s["total"], 3)
        s["pct_exactos"]   = round(s["exactos"] / s["total"] * 100, 1)
        s["pct_1_punto"]   = round(sum(1 for fb in historial if fb.get("ambito") == amb and abs(fb["diferencia"]) <= 1) / s["total"] * 100, 1)

    # Por modelo
    modelos_stats = {}
    for fb in historial:
        mod = fb.get("titulo_modelo", "Desconocido")
        if mod not in modelos_stats:
            modelos_stats[mod] = {"total": 0, "suma_diff_abs": 0}
        modelos_stats[mod]["total"] += 1
        modelos_stats[mod]["suma_diff_abs"] += abs(fb["diferencia"])
    for mod, s in modelos_stats.items():
        s["mae"] = round(s["suma_diff_abs"] / s["total"], 3)

    return {
        "total_feedbacks":        total,
        "evaluaciones_exactas":   exactos,
        "pct_exactas":            round(exactos / total * 100, 1),
        "diferencia_1_punto":     diff_1,
        "pct_diff_1":             round(diff_1 / total * 100, 1),
        "diferencia_2_o_mas":     diff_2_mas,
        "pct_diff_2_mas":         round(diff_2_mas / total * 100, 1),
        "pct_dentro_1_punto":     round((exactos + diff_1) / total * 100, 1),
        "mae":                    round(mae, 3),
        "sesgo_promedio":         round(sesgo, 3),
        "sesgo_interpretacion":   "Agente subestima" if sesgo > 0.2 else "Agente sobreestima" if sesgo < -0.2 else "Sin sesgo significativo",
        "n_sobreestimaciones":    sobreestima,
        "n_subestimaciones":      subestima,
        "por_ambito":             ambitos_stats,
        "por_modelo":             modelos_stats,
        "primer_feedback":        historial[0].get("fecha", ""),
        "ultimo_feedback":        historial[-1].get("fecha", ""),
    }
