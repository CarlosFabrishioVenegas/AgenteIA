"""
src/rag/conductuales/retriever.py
==================================
Retriever RAG para modelos conductuales.
Recupera contexto de comportamiento de clientes (prepago, NMD, EBA) para el prompt.
Uso: ConductualesRetriever().query_para_prompt(texto, top_k=3)
"""
from src.rag.base_retriever import BaseRetriever
class ConductualesRetriever(BaseRetriever):
    dominio = "conductuales"
