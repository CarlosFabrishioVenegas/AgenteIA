#!/usr/bin/env python3
"""
test_azure_config.py - Validador rápido de configuración Azure OpenAI

Uso:
    python test_azure_config.py

Valida:
    ✅ .env existe y es legible
    ✅ IA_PROVEEDOR = azure_openai
    ✅ AZURE_OPENAI_API_KEY está configurada (y no es placeholder)
    ✅ AZURE_OPENAI_ENDPOINT está configurada
    ✅ AZURE_OPENAI_DEPLOYMENT está configurada
    ✅ Conexión a API es exitosa
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Colores para terminal
class Color:
    GREEN = '\033[92m'
    RED = '\033[91m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def print_header():
    print("\n" + "═" * 70)
    print(f"{Color.BLUE}{Color.BOLD}🔵 VALIDADOR AZURE OPENAI - VIRF Agent v23{Color.RESET}")
    print("═" * 70 + "\n")

def print_ok(msg):
    print(f"{Color.GREEN}✅ {msg}{Color.RESET}")

def print_error(msg):
    print(f"{Color.RED}❌ {msg}{Color.RESET}")

def print_warning(msg):
    print(f"{Color.YELLOW}⚠️  {msg}{Color.RESET}")

def print_info(msg):
    print(f"{Color.BLUE}ℹ️  {msg}{Color.RESET}")

def test_env_file():
    """Valida que .env exista y sea legible"""
    print(f"\n{Color.BOLD}1. Verificando archivo .env{Color.RESET}")
    print("-" * 70)
    
    env_path = Path(__file__).parent / ".env"
    
    if not env_path.exists():
        print_error(f".env no encontrado en {env_path}")
        return False
    
    print_ok(f".env encontrado: {env_path}")
    
    # Intentar cargar
    try:
        load_dotenv(env_path)
        print_ok(".env cargado correctamente")
        return True
    except Exception as e:
        print_error(f"Error leyendo .env: {e}")
        return False

def test_proveedor():
    """Valida que IA_PROVEEDOR = azure_openai"""
    print(f"\n{Color.BOLD}2. Verificando IA_PROVEEDOR{Color.RESET}")
    print("-" * 70)
    
    proveedor = os.getenv("IA_PROVEEDOR", "").lower()
    
    if not proveedor:
        print_error("IA_PROVEEDOR no está configurada en .env")
        return False
    
    if proveedor == "azure_openai":
        print_ok(f"IA_PROVEEDOR = {proveedor} (Azure OpenAI activo ✓)")
        return True
    elif proveedor == "anthropic":
        print_warning(f"IA_PROVEEDOR = {proveedor} (estás usando Anthropic, no Azure)")
        print_info("Para cambiar a Azure OpenAI:")
        print_info("  1. Edita .env")
        print_info("  2. Cambia: IA_PROVEEDOR=azure_openai")
        print_info("  3. Configura credenciales Azure (ver GUIA_AZURE_OPENAI.md)")
        return False
    else:
        print_error(f"IA_PROVEEDOR = {proveedor} (desconocido)")
        return False

def test_azure_credentials():
    """Valida credenciales Azure OpenAI"""
    print(f"\n{Color.BOLD}3. Verificando credenciales Azure OpenAI{Color.RESET}")
    print("-" * 70)
    
    all_ok = True
    
    # API Key
    api_key = os.getenv("AZURE_OPENAI_API_KEY", "").strip()
    if not api_key:
        print_error("AZURE_OPENAI_API_KEY no está configurada")
        all_ok = False
    elif "REEMPLAZA" in api_key or "TU_" in api_key:
        print_error("AZURE_OPENAI_API_KEY contiene placeholder (REEMPLAZA...)")
        all_ok = False
    else:
        # Mostrar solo últimos 10 caracteres por seguridad
        key_display = f"{api_key[:5]}...{api_key[-5:]}"
        print_ok(f"AZURE_OPENAI_API_KEY configurada: {key_display}")
    
    # Endpoint
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT", "").strip()
    if not endpoint:
        print_error("AZURE_OPENAI_ENDPOINT no está configurada")
        all_ok = False
    elif "REEMPLAZA" in endpoint or "https://" not in endpoint:
        print_error("AZURE_OPENAI_ENDPOINT inválida (debe ser https://...)")
        all_ok = False
    elif not endpoint.endswith("/"):
        print_warning(f"AZURE_OPENAI_ENDPOINT no termina con /: {endpoint}")
        print_info("Por seguridad, añade / al final")
    else:
        print_ok(f"AZURE_OPENAI_ENDPOINT: {endpoint}")
    
    # Deployment
    deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT", "").strip()
    if not deployment:
        print_error("AZURE_OPENAI_DEPLOYMENT no está configurada")
        all_ok = False
    elif "REEMPLAZA" in deployment:
        print_error("AZURE_OPENAI_DEPLOYMENT contiene placeholder")
        all_ok = False
    else:
        print_ok(f"AZURE_OPENAI_DEPLOYMENT: {deployment}")
    
    # API Version
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-15-preview")
    print_ok(f"AZURE_OPENAI_API_VERSION: {api_version}")
    
    return all_ok

def test_conexion():
    """Intenta conectar a Azure OpenAI"""
    print(f"\n{Color.BOLD}4. Probando conexión a Azure OpenAI{Color.RESET}")
    print("-" * 70)
    
    try:
        from config import get_cliente_ia
        
        print_info("Intentando conectar...")
        cliente = get_cliente_ia()
        
        print_ok("Conexión exitosa a Azure OpenAI ✓")
        return True
        
    except ValueError as e:
        print_error(f"Error de configuración: {e}")
        return False
    except RuntimeError as e:
        print_error(f"Error de conexión: {e}")
        return False
    except Exception as e:
        print_error(f"Error inesperado: {e}")
        import traceback
        traceback.print_exc()
        return False

def print_summary(results):
    """Imprime resumen de validación"""
    print(f"\n{'═' * 70}")
    print(f"{Color.BOLD}RESUMEN{Color.RESET}")
    print("═" * 70 + "\n")
    
    paso_1, paso_2, paso_3, paso_4 = results
    
    if all(results):
        print_ok("✅ Todas las validaciones pasaron")
        print_info("Puedes usar Azure OpenAI. Ejecuta:")
        print(f"\n  {Color.BOLD}python agente.py --titulo 'Test' --tier 1{Color.RESET}\n")
        return True
    else:
        print_error("❌ Algunas validaciones fallaron")
        
        if not paso_1:
            print_error("  → Verifica que .env exista")
        if not paso_2:
            print_error("  → Configura IA_PROVEEDOR=azure_openai en .env")
        if not paso_3:
            print_error("  → Completa credenciales Azure en .env")
            print_info("  → Guía: docs/GUIA_AZURE_OPENAI.md")
        if not paso_4:
            print_error("  → Verifica conexión de red y credenciales")
        
        return False

def main():
    print_header()
    
    paso_1 = test_env_file()
    paso_2 = test_proveedor()
    paso_3 = test_azure_credentials()
    paso_4 = test_conexion() if paso_3 else False
    
    success = print_summary([paso_1, paso_2, paso_3, paso_4])
    
    print("═" * 70 + "\n")
    
    return 0 if success else 1

if __name__ == "__main__":
    sys.exit(main())
