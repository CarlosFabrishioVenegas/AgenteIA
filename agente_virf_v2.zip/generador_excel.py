"""
modulos/generador_excel.py
===========================
Genera el Excel de resultados VIRF con:
  - Hoja "Dashboard": semáforo por dimensión, dictamen global
  - Una hoja por dimensión con el detalle de cada actividad
  - Hoja "Cuestionamientos": críticas metodológicas al código
  - Hoja "Plan de Acción": tabla priorizada
"""

from pathlib import Path
from datetime import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference


# ─── PALETA ──────────────────────────────────────────────────────────────────

C_AZUL      = "FF1A3A5C"
C_AZUL_MED  = "FF2C5F8A"
C_BLANCO    = "FFFFFFFF"
C_GRIS      = "FFF4F7FB"
C_GRIS_MED  = "FFD0D8E4"

C_VERDE_BG  = "FFD5F5E3"
C_VERDE_TX  = "FF1E8B4C"
C_AMARI_BG  = "FFFFF3CD"
C_AMARI_TX  = "FF9A6100"
C_ROJO_BG   = "FFFDEDED"
C_ROJO_TX   = "FFC0392B"
C_AZUL_BG   = "FFE8F0FE"
C_AZUL_TX   = "FF1A3A5C"
C_NARAN_BG  = "FFFFF0E0"
C_NARAN_TX  = "FFB85C00"

ESTADO_STYLE = {
    "Revisado y Aceptado": (C_VERDE_BG, C_VERDE_TX),
    "No Aceptado":         (C_ROJO_BG,  C_ROJO_TX),
    "Solicitar Actas":     (C_AMARI_BG, C_AMARI_TX),
    "Observación":         (C_NARAN_BG, C_NARAN_TX),
}

DICTAMEN_STYLE = {
    "APROBADO":                       (C_VERDE_BG, C_VERDE_TX),
    "APROBADO CON OBSERVACIONES":     (C_AMARI_BG, C_AMARI_TX),
    "RECHAZADO":                      (C_ROJO_BG,  C_ROJO_TX),
}

RIESGO_STYLE = {
    "BAJO":    (C_VERDE_BG, C_VERDE_TX),
    "MEDIO":   (C_AMARI_BG, C_AMARI_TX),
    "ALTO":    (C_ROJO_BG,  C_ROJO_TX),
    "CRÍTICO": (C_ROJO_BG,  C_ROJO_TX),
}

SEV_STYLE = {
    "ALTA":  (C_ROJO_BG,  C_ROJO_TX),
    "MEDIA": (C_AMARI_BG, C_AMARI_TX),
    "BAJA":  (C_VERDE_BG, C_VERDE_TX),
}

THIN = Side(border_style="thin", color="FFB0BEC5")
BORDE = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def fill(color):
    return PatternFill("solid", fgColor=color)

def font(bold=False, size=10, color="FF222222", name="Arial"):
    return Font(bold=bold, size=size, color=color, name=name)

def align(h="left", v="center", wrap=True):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

def hdr(ws, row, cols, bg=C_AZUL, fg=C_BLANCO, size=10):
    for i, txt in enumerate(cols, 1):
        c = ws.cell(row=row, column=i, value=txt)
        c.fill = fill(bg)
        c.font = Font(bold=True, size=size, color=fg, name="Arial")
        c.border = BORDE
        c.alignment = align("center")

def col_widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

def cell(ws, row, col, value, bold=False, size=10, bg=None, fg="FF222222",
         h="left", wrap=True, border=True):
    c = ws.cell(row=row, column=col, value=value)
    c.font = Font(bold=bold, size=size, color=fg, name="Arial")
    c.alignment = align(h, wrap=wrap)
    if bg:
        c.fill = fill(bg)
    if border:
        c.border = BORDE
    return c

def estado_cell(ws, row, col, estado):
    bg, fg = ESTADO_STYLE.get(estado, (C_GRIS, "FF222222"))
    return cell(ws, row, col, estado, bold=True, bg=bg, fg=fg, h="center")


# ─── GENERADOR ───────────────────────────────────────────────────────────────

class GeneradorExcel:

    def __init__(self, carpeta: Path):
        self.carpeta = carpeta
        self.carpeta.mkdir(parents=True, exist_ok=True)

    def generar(self, titulo: str, sintesis: dict,
                resultados: dict, cuestionamientos: dict) -> Path:
        wb = openpyxl.Workbook()
        wb.remove(wb.active)

        self._dashboard(wb, titulo, sintesis, resultados)
        for dim, res in resultados.items():
            self._hoja_dimension(wb, dim, res)
        if cuestionamientos:
            self._hoja_cuestionamientos(wb, cuestionamientos)
        self._hoja_plan_accion(wb, sintesis)

        fecha = datetime.now().strftime("%Y%m%d_%H%M%S")
        nombre = f"VIRF_Resultados_{fecha}.xlsx"
        ruta = self.carpeta / nombre
        wb.save(ruta)
        return ruta

    # ── DASHBOARD ────────────────────────────────────────────────────────────

    def _dashboard(self, wb, titulo, sintesis, resultados):
        ws = wb.create_sheet("Dashboard VIRF")
        ws.sheet_view.showGridLines = False

        # Título principal
        ws.merge_cells("A1:H1")
        c = ws["A1"]
        c.value = titulo.upper()
        c.fill = fill(C_AZUL)
        c.font = Font(bold=True, size=14, color=C_BLANCO, name="Arial")
        c.alignment = align("center")
        ws.row_dimensions[1].height = 36

        # Subtítulo
        ws.merge_cells("A2:H2")
        c = ws["A2"]
        c.value = f"Informe de Validación VIRF  ·  {datetime.now().strftime('%d/%m/%Y %H:%M')}"
        c.fill = fill(C_AZUL_MED)
        c.font = Font(bold=False, size=11, color=C_BLANCO, name="Arial")
        c.alignment = align("center")
        ws.row_dimensions[2].height = 22

        # Dictamen y riesgo
        dictamen = sintesis.get("dictamen_global", "—")
        riesgo   = sintesis.get("nivel_riesgo", "—")
        d_bg, d_fg = DICTAMEN_STYLE.get(dictamen, (C_GRIS, C_AZUL))
        r_bg, r_fg = RIESGO_STYLE.get(riesgo, (C_GRIS, C_AZUL))

        ws.merge_cells("A4:D4")
        cell(ws, 4, 1, "DICTAMEN GLOBAL:", bold=True, size=11, bg=C_GRIS, h="right")
        ws.merge_cells("E4:H4")
        c = ws["E4"]
        c.value = dictamen
        c.fill = fill(d_bg)
        c.font = Font(bold=True, size=13, color=d_fg, name="Arial")
        c.alignment = align("center")
        c.border = BORDE
        ws.row_dimensions[4].height = 28

        ws.merge_cells("A5:D5")
        cell(ws, 5, 1, "NIVEL DE RIESGO:", bold=True, size=11, bg=C_GRIS, h="right")
        ws.merge_cells("E5:H5")
        c = ws["E5"]
        c.value = riesgo
        c.fill = fill(r_bg)
        c.font = Font(bold=True, size=13, color=r_fg, name="Arial")
        c.alignment = align("center")
        c.border = BORDE

        # Resumen por dimensión
        ws.row_dimensions[7].height = 8
        hdr(ws, 8, ["Dimensión", "Activ. Requeridas", "Aceptadas", "No Aceptadas",
                    "Observaciones", "Solicitar Actas", "% Cumplimiento", "Estado"])
        ws.row_dimensions[8].height = 20

        for fila, (dim, res) in enumerate(resultados.items(), 9):
            evals = res.get("evaluaciones", [])
            total   = len(evals)
            acept   = sum(1 for e in evals if e.get("estado") == "Revisado y Aceptado")
            no_acep = sum(1 for e in evals if e.get("estado") == "No Aceptado")
            obs     = sum(1 for e in evals if e.get("estado") == "Observación")
            actas   = sum(1 for e in evals if e.get("estado") == "Solicitar Actas")
            pct     = res.get("nivel_cumplimiento", round(acept / total * 100) if total else 0)

            if pct >= 80:
                estado_dim, bg_d, fg_d = "SATISFACTORIO", C_VERDE_BG, C_VERDE_TX
            elif pct >= 50:
                estado_dim, bg_d, fg_d = "OBSERVACIÓN",   C_AMARI_BG, C_AMARI_TX
            else:
                estado_dim, bg_d, fg_d = "CRÍTICO",       C_ROJO_BG,  C_ROJO_TX

            cell(ws, fila, 1, dim, bold=True, size=10)
            cell(ws, fila, 2, total,   h="center")
            cell(ws, fila, 3, acept,   h="center", bg=C_VERDE_BG if acept > 0 else None)
            cell(ws, fila, 4, no_acep, h="center", bg=C_ROJO_BG  if no_acep > 0 else None)
            cell(ws, fila, 5, obs,     h="center", bg=C_NARAN_BG if obs > 0 else None)
            cell(ws, fila, 6, actas,   h="center", bg=C_AMARI_BG if actas > 0 else None)
            c = ws.cell(row=fila, column=7, value=f"{pct}%")
            c.font = Font(bold=True, size=10, name="Arial")
            c.alignment = align("center")
            c.border = BORDE
            c_est = ws.cell(row=fila, column=8, value=estado_dim)
            c_est.fill = fill(bg_d)
            c_est.font = Font(bold=True, size=10, color=fg_d, name="Arial")
            c_est.alignment = align("center")
            c_est.border = BORDE
            ws.row_dimensions[fila].height = 18

        col_widths(ws, [22, 18, 14, 16, 16, 16, 16, 18])

        # Justificación del dictamen
        n_start = 9 + len(resultados) + 1
        ws.merge_cells(f"A{n_start}:H{n_start}")
        c = ws[f"A{n_start}"]
        c.value = "JUSTIFICACIÓN DEL DICTAMEN"
        c.fill = fill(C_AZUL)
        c.font = Font(bold=True, size=11, color=C_BLANCO, name="Arial")
        c.alignment = align("center")
        ws.row_dimensions[n_start].height = 20

        ws.merge_cells(f"A{n_start+1}:H{n_start+4}")
        c = ws[f"A{n_start+1}"]
        c.value = sintesis.get("justificacion_dictamen", "")
        c.font = Font(size=10, name="Arial")
        c.alignment = align("left", v="top")
        c.fill = fill(C_GRIS)
        c.border = BORDE
        ws.row_dimensions[n_start+1].height = 80

    # ── HOJA POR DIMENSIÓN ───────────────────────────────────────────────────

    def _hoja_dimension(self, wb, dimension, resultado):
        nombre_hoja = dimension[:31]
        ws = wb.create_sheet(nombre_hoja)
        ws.sheet_view.showGridLines = False

        pal_colors = {
            "Documentación":    ("FF1A3A5C", "FFEEF4FB"),
            "Calidad de Datos": ("FF1B5E20", "FFEEF6EF"),
            "Metodología":      ("FF4A148C", "FFF5EEFF"),
            "Gobierno":         ("FFB71C1C", "FFFFF0F0"),
            "Implementación":   ("FFE65100", "FFFFF8EE"),
            "Uso e Integración":("FF006064", "FFEFF9FA"),
        }
        hdr_color, row_color = pal_colors.get(dimension, ("FF1A3A5C", "FFF4F7FB"))

        # Título
        ws.merge_cells("A1:G1")
        c = ws["A1"]
        c.value = f"DIMENSIÓN: {dimension.upper()}"
        c.fill = fill(hdr_color)
        c.font = Font(bold=True, size=12, color=C_BLANCO, name="Arial")
        c.alignment = align("center")
        ws.row_dimensions[1].height = 28

        pct = resultado.get("nivel_cumplimiento", 0)
        ws.merge_cells("A2:G2")
        c = ws["A2"]
        c.value = f"Cumplimiento: {pct}%   ·   {resultado.get('resumen_dimension', '')}"
        c.fill = fill(C_AZUL_MED)
        c.font = Font(size=10, color=C_BLANCO, name="Arial")
        c.alignment = align("left")
        ws.row_dimensions[2].height = 20

        # Encabezados
        hdr(ws, 4, ["#", "Control", "Tipo", "Actividad VIRF",
                    "Estado", "Justificación técnica", "Cuestionamiento metodológico"])
        ws.row_dimensions[4].height = 20

        # Agrupar evaluaciones por control para fusionar celdas
        from itertools import groupby
        evals = resultado.get("evaluaciones", [])

        # Agrupar manteniendo orden
        grupos = []
        for key, grp in groupby(evals, key=lambda e: e.get("control", "")):
            grupos.append((key, list(grp)))

        fila = 5
        n_global = 1
        for control, evs_ctrl in grupos:
            n = len(evs_ctrl)
            fi, ff = fila, fila + n - 1
            tipo = evs_ctrl[0].get("tipo_ctrl", "")

            # Col B — Control (fusionada)
            ctrl_bg = "FFE3F2FD" if tipo == "Cuantitativo" else "FFF3E5F5"
            ctrl_fg = "FF1565C0" if tipo == "Cuantitativo" else "FF6A1B9A"
            if n > 1:
                ws.merge_cells(f"B{fi}:B{ff}")
            c = ws[f"B{fi}"]
            c.value = control
            c.fill = fill(ctrl_bg); c.font = Font(bold=True, size=9, color=ctrl_fg, name="Arial")
            c.alignment = align("center", v="center", wrap=True); c.border = BORDE

            # Col C — Tipo (fusionada)
            if n > 1:
                ws.merge_cells(f"C{fi}:C{ff}")
            c = ws[f"C{fi}"]
            c.value = tipo
            c.fill = fill(ctrl_bg); c.font = Font(bold=True, size=9, color=ctrl_fg, name="Arial")
            c.alignment = align("center", v="center"); c.border = BORDE

            for ev in evs_ctrl:
                # Col A — número
                cell(ws, fila, 1, n_global, h="center", bold=True, size=9)

                # Col D — actividad
                cell(ws, fila, 4, ev.get("actividad", ""), size=9)

                # Col E — estado
                estado_cell(ws, fila, 5, ev.get("estado", ""))

                # Col F — justificación + evidencia
                just = ev.get("justificacion", "")
                if ev.get("evidencia"):
                    just += f"\n[Evidencia: {ev['evidencia']}]"
                cell(ws, fila, 6, just, size=9)

                # Col G — cuestionamiento
                cuest = ev.get("cuestionamiento")
                if cuest:
                    c = ws.cell(row=fila, column=7, value=cuest)
                    c.fill = fill(C_AMARI_BG); c.font = Font(size=9, color=C_AMARI_TX, italic=True, name="Arial")
                    c.alignment = align("left"); c.border = BORDE
                else:
                    cell(ws, fila, 7, "—", size=9, h="center")

                ws.row_dimensions[fila].height = 35
                fila += 1
                n_global += 1

        col_widths(ws, [5, 26, 13, 32, 20, 36, 36])

        # Hallazgos críticos al pie
        hall = resultado.get("hallazgos_criticos", [])
        if hall:
            n = fila + 1
            ws.merge_cells(f"A{n}:G{n}")
            c = ws[f"A{n}"]
            c.value = "HALLAZGOS CRÍTICOS DE ESTA DIMENSIÓN"
            c.fill = fill(C_ROJO_BG); c.font = Font(bold=True, size=10, color=C_ROJO_TX, name="Arial")
            c.alignment = align("center")
            for j, h_txt in enumerate(hall, n+1):
                ws.merge_cells(f"A{j}:G{j}")
                c = ws[f"A{j}"]
                c.value = f"▸ {h_txt}"
                c.font = Font(size=9, color=C_ROJO_TX, name="Arial")
                c.alignment = align("left"); c.border = BORDE

    # ── HOJA CUESTIONAMIENTOS ────────────────────────────────────────────────

    def _hoja_cuestionamientos(self, wb, cuestionamientos):
        ws = wb.create_sheet("Cuestionamientos Metodológicos")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:G1")
        c = ws["A1"]
        c.value = "CUESTIONAMIENTOS METODOLÓGICOS — Model Risk Financial Controller"
        c.fill = fill(C_AZUL)
        c.font = Font(bold=True, size=12, color=C_BLANCO, name="Arial")
        c.alignment = align("center")
        ws.row_dimensions[1].height = 28

        fila_actual = 3
        for archivo, analisis in cuestionamientos.items():
            # Cabecera de archivo
            ws.merge_cells(f"A{fila_actual}:G{fila_actual}")
            c = ws[f"A{fila_actual}"]
            c.value = f"ARCHIVO: {archivo}"
            c.fill = fill(C_AZUL_MED)
            c.font = Font(bold=True, size=11, color=C_BLANCO, name="Arial")
            c.alignment = align("left")
            ws.row_dimensions[fila_actual].height = 20
            fila_actual += 1

            # Prácticas correctas
            correctas = analisis.get("practicas_correctas", [])
            if correctas:
                cell(ws, fila_actual, 1, "✓ Prácticas correctas identificadas:",
                     bold=True, size=9, bg=C_VERDE_BG, fg=C_VERDE_TX)
                ws.merge_cells(f"B{fila_actual}:G{fila_actual}")
                c = ws[f"B{fila_actual}"]
                c.value = " | ".join(correctas)
                c.font = Font(size=9, color=C_VERDE_TX, name="Arial")
                c.alignment = align("left")
                c.border = BORDE
                fila_actual += 1

            # Evaluación general
            eval_gral = analisis.get("evaluacion_general_codigo", "")
            if eval_gral:
                ws.merge_cells(f"A{fila_actual}:G{fila_actual}")
                c = ws[f"A{fila_actual}"]
                c.value = f"Evaluación: {eval_gral}"
                c.font = Font(size=9, italic=True, name="Arial")
                c.alignment = align("left")
                c.fill = fill(C_GRIS)
                c.border = BORDE
                ws.row_dimensions[fila_actual].height = 35
                fila_actual += 1

            # Alertas rápidas
            for alerta in analisis.get("alertas_rapidas", []):
                bg, fg = (C_AMARI_BG, C_AMARI_TX) if alerta.get("tipo") == "presencia" else (C_ROJO_BG, C_ROJO_TX)
                cell(ws, fila_actual, 1, f"[ALERTA RÁPIDA] {alerta.get('contexto', '')}",
                     bold=True, size=9, bg=bg, fg=fg)
                ws.merge_cells(f"B{fila_actual}:G{fila_actual}")
                c = ws[f"B{fila_actual}"]
                c.value = alerta.get("critica", "")
                c.font = Font(size=9, color=fg, name="Arial", italic=True)
                c.alignment = align("left", wrap=True)
                c.fill = fill(bg)
                c.border = BORDE
                ws.row_dimensions[fila_actual].height = 40
                fila_actual += 1

            # Cuestionamientos detallados de Claude
            cuests = analisis.get("cuestionamientos", [])
            if cuests:
                hdr(ws, fila_actual, ["Línea", "Código detectado", "Problema", "Crítica técnica",
                                      "Alternativa recomendada", "Ref. Regulatoria", "Severidad"])
                ws.row_dimensions[fila_actual].height = 18
                fila_actual += 1

                for q in cuests:
                    sev = q.get("severidad", "MEDIA")
                    bg_s, fg_s = SEV_STYLE.get(sev, (C_GRIS, "FF222222"))

                    cell(ws, fila_actual, 1, str(q.get("linea_aproximada", "")), size=9, h="center")
                    cell(ws, fila_actual, 2, q.get("codigo_detectado", ""), size=9,
                         bg=C_GRIS, fg="FF333333")
                    cell(ws, fila_actual, 3, q.get("problema", ""), size=9, bold=True)
                    cell(ws, fila_actual, 4, q.get("critica_tecnica", ""), size=9)
                    cell(ws, fila_actual, 5, q.get("alternativa_recomendada", ""), size=9,
                         bg=C_VERDE_BG, fg=C_VERDE_TX)
                    cell(ws, fila_actual, 6, q.get("referencia_regulatoria", ""), size=9)
                    c_sev = ws.cell(row=fila_actual, column=7, value=sev)
                    c_sev.fill = fill(bg_s)
                    c_sev.font = Font(bold=True, size=9, color=fg_s, name="Arial")
                    c_sev.alignment = align("center")
                    c_sev.border = BORDE
                    ws.row_dimensions[fila_actual].height = 40
                    fila_actual += 1

            fila_actual += 2

        col_widths(ws, [20, 25, 25, 38, 38, 22, 12])

    # ── HOJA PLAN DE ACCIÓN ──────────────────────────────────────────────────

    def _hoja_plan_accion(self, wb, sintesis):
        ws = wb.create_sheet("Plan de Acción")
        ws.sheet_view.showGridLines = False

        ws.merge_cells("A1:F1")
        c = ws["A1"]
        c.value = "PLAN DE ACCIÓN — CIERRE DE HALLAZGOS VIRF"
        c.fill = fill(C_AZUL)
        c.font = Font(bold=True, size=12, color=C_BLANCO, name="Arial")
        c.alignment = align("center")
        ws.row_dimensions[1].height = 28

        prioridad_style = {
            "INMEDIATA": (C_ROJO_BG,  C_ROJO_TX),
            "30D":       (C_AMARI_BG, C_AMARI_TX),
            "90D":       (C_VERDE_BG, C_VERDE_TX),
        }

        hdr(ws, 3, ["#", "Acción requerida", "Responsable", "Plazo sugerido",
                    "Prioridad", "Estado"])
        ws.row_dimensions[3].height = 20

        plan = sintesis.get("plan_accion", [])
        for i, item in enumerate(plan, 4):
            prior = item.get("prioridad", "30D")
            bg_p, fg_p = prioridad_style.get(prior, (C_GRIS, "FF222222"))

            cell(ws, i, 1, item.get("item", i-3), h="center", bold=True, size=9)
            cell(ws, i, 2, item.get("accion", ""), size=9)
            cell(ws, i, 3, item.get("responsable", "—"), size=9, h="center")
            cell(ws, i, 4, item.get("plazo", "—"), size=9, h="center")
            c_p = ws.cell(row=i, column=5, value=prior)
            c_p.fill = fill(bg_p)
            c_p.font = Font(bold=True, size=9, color=fg_p, name="Arial")
            c_p.alignment = align("center")
            c_p.border = BORDE
            cell(ws, i, 6, "Pendiente", size=9, bg=C_AMARI_BG, fg=C_AMARI_TX, h="center")
            ws.row_dimensions[i].height = 30

        col_widths(ws, [5, 55, 22, 16, 14, 14])

        # Hallazgos principales al pie
        hall = sintesis.get("principales_hallazgos", [])
        if hall:
            n = 4 + len(plan) + 2
            ws.merge_cells(f"A{n}:F{n}")
            c = ws[f"A{n}"]
            c.value = "HALLAZGOS PRINCIPALES"
            c.fill = fill(C_AZUL)
            c.font = Font(bold=True, size=11, color=C_BLANCO, name="Arial")
            c.alignment = align("center")
            ws.row_dimensions[n].height = 22
            n += 1

            hdr(ws, n, ["ID", "Dimensión", "Hallazgo", "Severidad", "Acción", ""])
            n += 1
            for h_item in hall:
                sev = h_item.get("severidad", "MEDIA")
                bg_s, fg_s = SEV_STYLE.get(sev, (C_GRIS, "FF222222"))
                cell(ws, n, 1, h_item.get("id", ""), h="center", bold=True, size=9)
                cell(ws, n, 2, h_item.get("dimension", ""), size=9)
                cell(ws, n, 3, h_item.get("hallazgo", ""), size=9)
                c_s = ws.cell(row=n, column=4, value=sev)
                c_s.fill = fill(bg_s)
                c_s.font = Font(bold=True, size=9, color=fg_s, name="Arial")
                c_s.alignment = align("center")
                c_s.border = BORDE
                cell(ws, n, 5, h_item.get("accion", ""), size=9)
                ws.row_dimensions[n].height = 30
                n += 1
