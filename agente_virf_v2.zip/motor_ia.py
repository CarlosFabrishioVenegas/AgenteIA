"""
modulos/motor_ia.py
====================
Motor del Agente: Model Risk Financial Controller

Lógica principal:
  1. Aprende el lenguaje de los informes de referencia.
  2. Por cada dimensión VIRF, evalúa cada actividad requerida
     contra los documentos/código proporcionados.
  3. Emite veredicto: "Revisado y Aceptado" / "No Aceptado" / "Solicitar Actas"
  4. Cuestiona metodologías detectadas si hay mejores prácticas disponibles.
"""

import json
import re
import requests
from config import CONFIG, CUESTIONAMIENTOS_METODOLOGICOS


# ─── PROMPTS ──────────────────────────────────────────────────────────────────

SYSTEM_BASE = """Eres un Model Risk Financial Controller senior con 15+ años de experiencia 
en validación independiente de modelos financieros. Tu marco regulatorio incluye:
- SR 11-7 (Federal Reserve, Model Risk Management)
- SS3/17 (PRA, Model Risk Management)  
- EBA Guidelines on Internal Models (CRR2)
- IFRS 9 (Expected Credit Loss)
- Basilea III/IV (IRB, SA-CCR)
- GDPR (derecho a explicación en modelos automatizados)

Eres crítico, riguroso e independiente. Cuando evalúas, buscas evidencia CONCRETA en los 
documentos. No asumes que algo está hecho si no hay evidencia explícita.

Respondes ÚNICAMENTE con JSON válido. Sin texto adicional, sin bloques markdown."""


def _prompt_aprender_estilo(texto_informes: str) -> str:
    return f"""Analiza estos informes de validación de modelos financieros y extrae los 
patrones de escritura para replicarlos.

INFORMES DE REFERENCIA:
{texto_informes[:10000]}

Responde con JSON:
{{
  "tono": "descripción del tono formal/técnico",
  "frases_aceptacion": ["frase usada cuando algo está correcto", ...],
  "frases_rechazo": ["frase usada cuando algo falta", ...],
  "frases_observacion": ["frase para observaciones/mejoras", ...],
  "estructura_hallazgo": "cómo se redacta un hallazgo",
  "vocabulario_tecnico": ["término1", "término2", ...],
  "nivel_detalle": "descripción del nivel de detalle usado"
}}"""


def _prompt_evaluar_dimension(
    dimension: str,
    actividades: list[dict],
    documentos: list[dict],
    estilo: dict,
    instrucciones_especiales: str = "",
) -> str:
    # Construir bloque de documentos
    docs_str = ""
    for d in documentos:
        docs_str += f"\n--- {d['tipo']}: {d['nombre']} ---\n{d['contenido'][:3000]}\n"

    # Agrupar actividades por control para mostrarlas jerárquicamente
    from itertools import groupby
    grupos_str = ""
    actividades_sorted = sorted(actividades, key=lambda a: a.get("control",""))
    for ctrl, grp in groupby(actividades_sorted, key=lambda a: a.get("control","")):
        acts = list(grp)
        tipo = acts[0].get("tipo_ctrl", "")
        grupos_str += f"\n  [CONTROL {tipo.upper()}] {ctrl}\n"
        for a in acts:
            req = "REQUERIDA" if a.get("requerida") else "OPCIONAL"
            grupos_str += f"    · [{req}] {a['actividad']}\n"

    estilo_str = json.dumps(estilo, ensure_ascii=False)
    instrucciones = f"\nINSTRUCCIONES ESPECIALES: {instrucciones_especiales}" if instrucciones_especiales else ""

    return f"""Eres un Model Risk Financial Controller evaluando la dimensión: {dimension.upper()}

ESTILO DE ESCRITURA A USAR (aprendido de informes previos):
{estilo_str}
{instrucciones}

ESTRUCTURA DE CONTROLES A EVALUAR (jerarquía: Control → Actividades):
{grupos_str}

DOCUMENTOS / ARCHIVOS PROPORCIONADOS:
{docs_str[:8000]}

Para CADA actividad debes:
1. Buscar evidencia EXPLÍCITA en los documentos/código.
2. Asignar estado según estas reglas estrictas:
   - "Revisado y Aceptado": evidencia clara y suficiente encontrada.
   - "No Aceptado": actividad no cubierta o evidencia insuficiente.
   - "Solicitar Actas": SOLO para actividades de gobierno sin acta formal.
   - "Observación": cumple parcialmente, mejoras necesarias.
3. Justificación técnica específica (citar dónde o qué falta exactamente).
4. Si detectas una metodología cuestionable, agregar campo "cuestionamiento" con:
   - Qué se está usando actualmente
   - Por qué es subóptimo o incumple regulación
   - Qué alternativa recomiendar (con referencia: SR 11-7, Basilea, EBA, IFRS 9)

Responde con JSON:
{{
  "dimension": "{dimension}",
  "evaluaciones": [
    {{
      "control": "nombre del control al que pertenece esta actividad",
      "tipo_ctrl": "Cuantitativo|Cualitativo",
      "actividad": "texto exacto de la actividad evaluada",
      "estado": "Revisado y Aceptado|No Aceptado|Solicitar Actas|Observación",
      "evidencia": "cita o referencia específica de dónde se encontró (o null si no hay)",
      "justificacion": "explicación técnica detallada con el estilo aprendido",
      "cuestionamiento": null
    }}
  ],
  "resumen_dimension": "párrafo ejecutivo de la dimensión completa",
  "nivel_cumplimiento": 0,
  "hallazgos_criticos": ["hallazgo1", ...]
}}"""


def _prompt_cuestionamiento_codigo(codigo: str, dimension: str) -> str:
    """Prompt para que Claude analice el código y detecte problemas metodológicos."""
    return f"""Analiza este código Python de un modelo financiero como Model Risk Financial Controller.

CÓDIGO DEL MODELO:
{codigo[:8000]}

Identifica TODOS los problemas metodológicos, malas prácticas y áreas de mejora.
Para cada problema, proporciona la alternativa técnica correcta con justificación regulatoria.

Responde con JSON:
{{
  "cuestionamientos": [
    {{
      "linea_aproximada": "número o rango de línea aproximado",
      "codigo_detectado": "fragmento de código problemático",
      "problema": "descripción del problema metodológico",
      "critica_tecnica": "por qué es incorrecto o subóptimo",
      "alternativa_recomendada": "qué usar en su lugar",
      "referencia_regulatoria": "SR 11-7, Basilea, EBA, etc.",
      "severidad": "ALTA|MEDIA|BAJA"
    }}
  ],
  "practicas_correctas": ["cosa1 bien hecha", ...],
  "evaluacion_general_codigo": "párrafo de evaluación global"
}}"""


def _prompt_sintesis_final(
    resultados_por_dimension: dict,
    titulo: str,
    estilo: dict,
) -> str:
    resumen = {}
    for dim, res in resultados_por_dimension.items():
        resumen[dim] = {
            "cumplimiento": res.get("nivel_cumplimiento", 0),
            "hallazgos": res.get("hallazgos_criticos", []),
        }

    estilo_str = json.dumps(estilo, ensure_ascii=False)

    return f"""Genera la síntesis final del informe de validación VIRF.

TÍTULO DEL INFORME: {titulo}

RESULTADOS POR DIMENSIÓN:
{json.dumps(resumen, ensure_ascii=False, indent=2)}

ESTILO A USAR:
{estilo_str}

Redacta el informe con el estilo y lenguaje de un Model Risk Financial Controller senior.

Responde con JSON:
{{
  "resumen_ejecutivo": "3-5 párrafos del resumen ejecutivo completo",
  "dictamen_global": "APROBADO|APROBADO CON OBSERVACIONES|RECHAZADO",
  "nivel_riesgo": "BAJO|MEDIO|ALTO|CRÍTICO",
  "justificacion_dictamen": "párrafo justificando el dictamen global",
  "principales_hallazgos": [
    {{"id": "H01", "dimension": "...", "hallazgo": "...", "severidad": "ALTA|MEDIA|BAJA", "accion": "..."}}
  ],
  "plan_accion": [
    {{"item": 1, "accion": "...", "responsable": "...", "plazo": "...", "prioridad": "INMEDIATA|30D|90D"}}
  ],
  "proxima_revision": "recomendación de cuándo revisar nuevamente",
  "conclusion_narrativa": "párrafo de conclusión final al estilo del informe"
}}"""


# ─── MOTOR ────────────────────────────────────────────────────────────────────

class MotorIA:
    URL = "https://api.anthropic.com/v1/messages"
    HEADERS_BASE = {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
    }

    def __init__(self, api_key: str):
        self.headers = {**self.HEADERS_BASE, "x-api-key": api_key}

    def _llamar(self, system: str, user: str, max_tokens: int = None) -> str:
        mt = max_tokens or CONFIG["max_tokens"]
        payload = {
            "model": CONFIG["modelo_claude"],
            "max_tokens": mt,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        r = requests.post(self.URL, headers=self.headers, json=payload, timeout=180)
        r.raise_for_status()
        data = r.json()
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")

    def _json(self, texto: str, fallback: dict) -> dict:
        limpio = re.sub(r"```(?:json)?|```", "", texto).strip()
        i, j = limpio.find("{"), limpio.rfind("}")
        if i != -1 and j != -1:
            limpio = limpio[i:j+1]
        try:
            return json.loads(limpio)
        except json.JSONDecodeError:
            return {**fallback, "_raw": texto[:500]}

    # ── PASO 1: Aprender estilo ──────────────────────────────────────────────

    def aprender_estilo(self, texto_informes: str) -> dict:
        if not texto_informes.strip():
            return {
                "tono": "Formal, técnico, regulatorio. Lenguaje de auditoría de riesgo de modelos.",
                "frases_aceptacion": [
                    "Se verifica evidencia suficiente que da cumplimiento al requerimiento.",
                    "El criterio se considera cubierto satisfactoriamente.",
                    "La documentación presentada es adecuada y cumple con el estándar.",
                ],
                "frases_rechazo": [
                    "No se evidencia documentación que dé cumplimiento al requerimiento.",
                    "El criterio no se encuentra cubierto en la documentación revisada.",
                    "Se requiere documentación adicional para dar cierre al punto.",
                ],
                "frases_observacion": [
                    "Se cumple parcialmente; se recomienda fortalecer el análisis.",
                    "La evidencia presentada es insuficiente; se sugiere ampliar.",
                ],
                "estructura_hallazgo": "ID | Dimensión | Descripción | Evidencia | Severidad | Recomendación",
                "vocabulario_tecnico": [
                    "validación independiente", "backtesting", "discriminación", "calibración",
                    "estabilidad poblacional", "PSI", "Gini", "KS", "model risk", "acta de aprobación",
                ],
                "nivel_detalle": "Alto. Se cita evidencia específica de página/sección del documento.",
            }
        raw = self._llamar(SYSTEM_BASE, _prompt_aprender_estilo(texto_informes))
        return self._json(raw, {"tono": "formal"})

    # ── PASO 2: Detectar cuestionamientos en código ──────────────────────────

    def detectar_cuestionamientos_codigo(self, documentos: list[dict]) -> dict:
        """Busca archivos .py en los documentos y los analiza metodológicamente."""
        codigos = [d for d in documentos if d["tipo"] == "PY"]
        if not codigos:
            return {}

        resultados = {}
        for doc in codigos:
            # Detección rápida de patrones conocidos (sin API)
            alertas_rapidas = []
            codigo_lower = doc["contenido"].lower()
            for clave, info in CUESTIONAMIENTOS_METODOLOGICOS.items():
                if info.get("detectar_ausencia"):
                    if not any(p in codigo_lower for p in info["detectar"]):
                        alertas_rapidas.append({
                            "tipo": "ausencia",
                            "contexto": info["contexto"],
                            "critica": info["critica"],
                        })
                else:
                    if any(p.lower() in codigo_lower for p in info["detectar"]):
                        alertas_rapidas.append({
                            "tipo": "presencia",
                            "contexto": info["contexto"],
                            "critica": info["critica"],
                        })

            # Análisis profundo con Claude
            raw = self._llamar(SYSTEM_BASE, _prompt_cuestionamiento_codigo(doc["contenido"], "Calidad de Datos"))
            analisis_ia = self._json(raw, {"cuestionamientos": [], "practicas_correctas": []})
            analisis_ia["alertas_rapidas"] = alertas_rapidas
            resultados[doc["nombre"]] = analisis_ia

        return resultados

    # ── PASO 3: Evaluar cada dimensión ───────────────────────────────────────

    def evaluar_dimension(
        self,
        dimension: str,
        actividades: list[dict],
        documentos: list[dict],
        estilo: dict,
        instrucciones_especiales: str = "",
    ) -> dict:
        if not actividades:
            return {"dimension": dimension, "evaluaciones": [], "nivel_cumplimiento": 0,
                    "resumen_dimension": "Sin actividades definidas.", "hallazgos_criticos": []}

        if not documentos:
            # Sin documentos: marcar todo como No Aceptado
            return {
                "dimension": dimension,
                "evaluaciones": [
                    {
                        "actividad": a["actividad"],
                        "estado": "Solicitar Actas" if dimension == "Gobierno" else "No Aceptado",
                        "evidencia": "No se proporcionaron documentos para esta dimensión.",
                        "justificacion": "No se recibieron archivos de entrada para evaluar esta dimensión.",
                        "cuestionamiento": None,
                    }
                    for a in actividades if a.get("requerida", True)
                ],
                "resumen_dimension": f"No se proporcionaron documentos para evaluar {dimension}.",
                "nivel_cumplimiento": 0,
                "hallazgos_criticos": [f"Sin documentación para {dimension}"],
            }

        raw = self._llamar(
            SYSTEM_BASE,
            _prompt_evaluar_dimension(dimension, actividades, documentos, estilo, instrucciones_especiales),
            max_tokens=4000,
        )
        fallback = {
            "dimension": dimension,
            "evaluaciones": [],
            "nivel_cumplimiento": 0,
            "resumen_dimension": raw[:300],
            "hallazgos_criticos": [],
        }
        return self._json(raw, fallback)

    # ── PASO 4: Síntesis final ───────────────────────────────────────────────

    def generar_sintesis(self, resultados: dict, titulo: str, estilo: dict) -> dict:
        raw = self._llamar(
            SYSTEM_BASE,
            _prompt_sintesis_final(resultados, titulo, estilo),
            max_tokens=4000,
        )
        fallback = {
            "resumen_ejecutivo": "Ver resultados por dimensión.",
            "dictamen_global": "APROBADO CON OBSERVACIONES",
            "nivel_riesgo": "MEDIO",
            "justificacion_dictamen": "",
            "principales_hallazgos": [],
            "plan_accion": [],
            "proxima_revision": "Próximo trimestre",
            "conclusion_narrativa": "",
        }
        return self._json(raw, fallback)
