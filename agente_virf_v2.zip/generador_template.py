"""
modulos/generador_template.py
==============================
Genera "Estandares_VIRF.xlsx" con la estructura jerárquica real:

    ÁMBITO  |  Control Cuantitativo / Cualitativo  |  Actividad  |  Requiere

Las columnas ÁMBITO y Control tienen celdas fusionadas.
"""

from pathlib import Path
from itertools import groupby
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from config import DIMENSIONES_VIRF

THIN  = Side(border_style="thin",   color="FFB0BEC5")
MED   = Side(border_style="medium", color="FF8099B3")
BORDE = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

def _fill(h): return PatternFill("solid", fgColor=h)
def _font(bold=False, size=10, color="FF1A1A2E", italic=False):
    return Font(bold=bold, size=size, color=color, italic=italic, name="Arial")
def _align(h="left", v="center", wrap=True):
    return Alignment(horizontal=h, vertical=v, wrap_text=wrap)

DIM_PAL = {
    "Documentación":    {"amb":"FF1A3A5C","cq":"FF2C5F8A","ccl":"FF3A7ABF","row":"FFEEF4FB"},
    "Calidad de Datos": {"amb":"FF1B5E20","cq":"FF2E7D32","ccl":"FF43A047","row":"FFEEF6EF"},
    "Metodología":      {"amb":"FF4A148C","cq":"FF6A1B9A","ccl":"FF8E24AA","row":"FFF5EEFF"},
    "Gobierno":         {"amb":"FFB71C1C","cq":"FFC62828","ccl":"FFE53935","row":"FFFFF0F0"},
    "Implementación":   {"amb":"FFE65100","cq":"FFEF6C00","ccl":"FFFF8F00","row":"FFFFF8EE"},
    "Uso e Integración":{"amb":"FF006064","cq":"FF00838F","ccl":"FF0097A7","row":"FFEFF9FA"},
}
DEF_PAL = {"amb":"FF37474F","cq":"FF546E7A","ccl":"FF78909C","row":"FFF5F5F5"}
TIPO_BADGE = {"Cuantitativo":("FFE3F2FD","FF1565C0"), "Cualitativo":("FFF3E5F5","FF6A1B9A")}


def generar_template(carpeta: Path) -> Path:
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    _hoja_instrucciones(wb)
    for ambito, actividades in DIMENSIONES_VIRF.items():
        _hoja_ambito(wb, ambito, actividades)
    ruta = carpeta / "Estandares_VIRF.xlsx"
    wb.save(ruta)
    return ruta


def _hoja_instrucciones(wb):
    ws = wb.create_sheet("INSTRUCCIONES")
    ws.sheet_view.showGridLines = False
    for col, w in [("A",6),("B",38),("C",55)]:
        ws.column_dimensions[col].width = w

    ws.merge_cells("A1:C1")
    c = ws["A1"]
    c.value = "ESTÁNDARES DE VALIDACIÓN VIRF — MANUAL DE USO"
    c.fill = _fill("FF1A3A5C"); c.font = _font(True,14,"FFFFFFFF")
    c.alignment = _align("center"); ws.row_dimensions[1].height = 38

    ws.merge_cells("A2:C2")
    c = ws["A2"]
    c.value = "Model Risk Financial Controller · Validación Independiente de Modelos"
    c.fill = _fill("FF2C5F8A"); c.font = _font(False,11,"FFFFFFFF")
    c.alignment = _align("center"); ws.row_dimensions[2].height = 20

    rows = [
        (None, None),
        ("ESTRUCTURA DEL ARCHIVO", None),
        ("Columna ÁMBITO",        "Dimensión: Documentación, Calidad de Datos, Metodología, Gobierno, Implementación, Uso e Integración"),
        ("Columna CONTROL",       "Agrupación de controles dentro del ámbito (Cuantitativo o Cualitativo)"),
        ("Columna ACTIVIDAD",     "Tarea específica que el agente evaluará contra los documentos / código"),
        ("Columna REQUIERE",      "Deja X si la actividad aplica a tu modelo. Borra la X si no aplica."),
        (None, None),
        ("CÓMO USAR", None),
        ("Paso 1", "Revisa cada hoja y deja X en las actividades requeridas para tu modelo"),
        ("Paso 2", "Carga archivos en inputs/documentacion/, inputs/calidad_datos/, inputs/usos/, inputs/implementacion/"),
        ("Paso 3", "python agente.py --titulo 'Nombre del modelo'"),
        (None, None),
        ("ESTADOS QUE EMITE EL AGENTE", None),
        ("Revisado y Aceptado", "Evidencia suficiente encontrada en los documentos → Verde"),
        ("No Aceptado",         "No se encontró evidencia de la actividad → Rojo"),
        ("Solicitar Actas",     "Solo Gobierno: sin acta formal de aprobación → Amarillo"),
        ("Observación",         "Cumple parcialmente, requiere mejora → Naranja"),
    ]
    for i, (label, texto) in enumerate(rows, 4):
        if label is None:
            ws.row_dimensions[i].height = 8; continue
        is_section = texto is None
        ws.row_dimensions[i].height = 24 if is_section else 22
        if is_section:
            ws.merge_cells(f"A{i}:C{i}")
            c = ws[f"A{i}"]
            c.value = label; c.fill = _fill("FFE8F0FE")
            c.font = _font(True,11,"FF1A3A5C")
            c.alignment = _align("left"); c.border = BORDE
        else:
            b = ws[f"B{i}"]; b.value = label
            b.font = _font(True,10,"FF1A3A5C"); b.alignment = _align("left"); b.border = BORDE
            t = ws[f"C{i}"]; t.value = texto
            t.font = _font(False,10); t.alignment = _align("left"); t.border = BORDE


def _hoja_ambito(wb, ambito: str, actividades: list):
    ws = wb.create_sheet(ambito[:31])
    ws.sheet_view.showGridLines = False
    pal = DIM_PAL.get(ambito, DEF_PAL)

    for col, w in [("A",20),("B",34),("C",14),("D",54),("E",12),("F",30)]:
        ws.column_dimensions[col].width = w

    # Título
    ws.merge_cells("A1:F1")
    c = ws["A1"]
    c.value = f"ÁMBITO: {ambito.upper()}"
    c.fill = _fill(pal["amb"]); c.font = _font(True,13,"FFFFFFFF")
    c.alignment = _align("center"); ws.row_dimensions[1].height = 32

    # Cabeceras
    for j, hdr in enumerate(["ÁMBITO","CONTROL","TIPO","ACTIVIDAD","REQUIERE","NOTAS"],1):
        c = ws.cell(row=2, column=j, value=hdr)
        c.fill = _fill(pal["amb"]); c.font = _font(True,10,"FFFFFFFF")
        c.alignment = _align("center"); c.border = BORDE
    ws.row_dimensions[2].height = 20

    # Agrupar por (control, tipo_ctrl)
    grupos = []
    for key, grp in groupby(actividades, key=lambda a: (a["control"], a["tipo_ctrl"])):
        grupos.append((key[0], key[1], list(grp)))

    fila = 3
    for control, tipo_ctrl, acts in grupos:
        n = len(acts)
        fi, ff = fila, fila + n - 1

        ctrl_hex = pal["cq"] if tipo_ctrl == "Cuantitativo" else pal["ccl"]
        tipo_bg, tipo_fg = TIPO_BADGE.get(tipo_ctrl, ("FFF5F5F5","FF333333"))

        # Col B — CONTROL (fusionada)
        if n > 1: ws.merge_cells(f"B{fi}:B{ff}")
        c = ws[f"B{fi}"]
        c.value = control; c.fill = _fill(ctrl_hex)
        c.font = _font(True,9,"FFFFFFFF")
        c.alignment = _align("center","center",True); c.border = BORDE

        # Col C — TIPO (fusionada)
        if n > 1: ws.merge_cells(f"C{fi}:C{ff}")
        c = ws[f"C{fi}"]
        c.value = tipo_ctrl; c.fill = _fill(tipo_bg)
        c.font = _font(True,9,tipo_fg)
        c.alignment = _align("center","center"); c.border = BORDE

        for k, act in enumerate(acts):
            bg = pal["row"] if k % 2 == 0 else "FFFFFFFF"

            # Col D — Actividad
            c = ws.cell(row=fila, column=4, value=act["actividad"])
            c.fill = _fill(bg); c.font = _font(False,10)
            c.alignment = _align("left","center",True); c.border = BORDE

            # Col E — Requiere
            c = ws.cell(row=fila, column=5, value="X" if act.get("requerida") else "")
            c.fill = _fill("FFE8F0FE") if act.get("requerida") else _fill("FFFAFAFA")
            c.font = _font(True,13,"FF1A3A5C")
            c.alignment = _align("center","center",False); c.border = BORDE

            # Col F — Notas
            c = ws.cell(row=fila, column=6, value="")
            c.fill = _fill("FFFAFAFA"); c.font = _font(False,9,"FF888888",True)
            c.alignment = _align("left"); c.border = BORDE

            ws.row_dimensions[fila].height = 22
            fila += 1

    # Col A — ÁMBITO (fusionada para todo el bloque)
    total = fila - 3
    if total > 1: ws.merge_cells(f"A3:A{fila-1}")
    c = ws["A3"]
    c.value = ambito; c.fill = _fill(pal["amb"])
    c.font = _font(True,11,"FFFFFFFF")
    c.alignment = _align("center","center",True); c.border = BORDE

    ws.freeze_panes = "D3"
