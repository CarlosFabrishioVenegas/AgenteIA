"""
agente.py — Agente IA VIRF
===========================
Model Risk Financial Controller

Uso:
  # Generar el template Estandares_VIRF.xlsx (primer uso):
  python agente.py --template

  # Ejecutar validación completa:
  python agente.py --titulo "Validación Modelo Scoring Retail v2.3"

  # Con instrucciones adicionales:
  python agente.py --titulo "..." --instrucciones "Enfatizar análisis de datos atípicos multivariados"
"""

import argparse
import sys
from pathlib import Path
from config import CONFIG, DIMENSIONES_VIRF


# ── Colores terminal ──────────────────────────────────────────────────────────

R  = "\033[0m"
B  = "\033[94m"   # Azul
G  = "\033[92m"   # Verde
Y  = "\033[93m"   # Amarillo
RE = "\033[91m"   # Rojo
C  = "\033[96m"   # Cyan
BO = "\033[1m"    # Bold

def log(msg, t="info"):
    icons = {"info": "›", "ok": "✓", "error": "✗", "warn": "⚠", "step": "◈", "ask": "?"}
    cols  = {"info": B, "ok": G, "error": RE, "warn": Y, "step": C+BO, "ask": Y+BO}
    print(f"  {cols.get(t,R)}{icons.get(t,'›')}{R}  {msg}")

def banner():
    print(f"\n{C}{BO}")
    print("  ╔════════════════════════════════════════════════════════════╗")
    print("  ║    AGENTE IA VIRF  ·  MODEL RISK FINANCIAL CONTROLLER      ║")
    print("  ║    Validación Independiente de Modelos Financieros          ║")
    print("  ╚════════════════════════════════════════════════════════════╝")
    print(f"{R}\n")

def sep():
    print(f"  {C}{'─'*60}{R}")


# ── Instrucciones especiales por dimensión ────────────────────────────────────

INSTRUCCIONES_DIMENSION = {
    "Calidad de Datos": (
        "Analiza el código Python con especial atención a: tratamiento de outliers "
        "(cuestiona si usa Z-score en lugar de GESD o métodos robustos), imputación de missing "
        "(cuestiona si usa media en lugar de MICE/KNN), y división train/test "
        "(alerta si no es OOT para datos financieros temporales)."
    ),
    "Metodología": (
        "Evalúa si el backtesting usa ventana temporal suficiente (≥2 años histórico + ≥6m OOT). "
        "Cuestiona si solo se reporta Gini/AUC sin calibración (exigir Brier, Hosmer-Lemeshow). "
        "Verifica si modelos complejos (XGBoost, etc.) incluyen SHAP values para explicabilidad."
    ),
    "Gobierno": (
        "Para actividades de gobierno, el estado debe ser 'Solicitar Actas' si no hay "
        "evidencia documental de aprobación formal por comité competente. "
        "Verificar existencia de registro en inventario de modelos corporativo."
    ),
    "Implementación": (
        "Verificar si se documenta el proceso de replicación del modelo en producción. "
        "Cuestionar si no se menciona versionamiento de modelo o control de cambios técnico. "
        "Alertar si no hay evidencia de pruebas UAT formales antes del go-live."
    ),
}


# ── Pipeline principal ────────────────────────────────────────────────────────

def ejecutar(titulo: str, instrucciones_extra: str = ""):
    banner()

    from modulos.lector_inputs import LectorInputs
    from modulos.motor_ia import MotorIA
    from modulos.generador_excel import GeneradorExcel
    from modulos.generador_word import GeneradorWord

    lector   = LectorInputs(CONFIG)
    motor    = MotorIA(CONFIG["api_key"])
    gen_xl   = GeneradorExcel(Path(CONFIG["outputs"]))
    gen_word = GeneradorWord(Path(CONFIG["outputs"]))

    # ── PASO 1: Aprender lenguaje de informes de referencia ──────────────────
    log("PASO 1 — Aprendiendo lenguaje de informes de referencia...", "step")
    repo = Path(CONFIG["repositorio_informes"])
    texto_informes = lector.leer_informes_referencia(repo)
    estilo = motor.aprender_estilo(texto_informes)
    n_informes = len([f for f in repo.iterdir() if f.is_file()]) if repo.exists() else 0
    log(f"Informes de referencia procesados: {n_informes}", "ok" if n_informes > 0 else "warn")
    if n_informes == 0:
        log("Sin informes de referencia → usando estilo estándar VIRF", "warn")

    # ── PASO 2: Leer Estandares_VIRF ────────────────────────────────────────
    log("PASO 2 — Leyendo estándares VIRF...", "step")
    ruta_virf = Path(CONFIG["estandares_virf"])
    dimensiones_activas = None

    if ruta_virf.exists():
        dimensiones_raw = lector.leer_estandares_virf(ruta_virf)
        if dimensiones_raw:
            dimensiones_activas = dimensiones_raw
            total_acts = sum(len(v) for v in dimensiones_activas.values())
            log(f"Estandares_VIRF.xlsx leído → {len(dimensiones_activas)} dimensiones, "
                f"{total_acts} actividades", "ok")
        else:
            log("No se pudo parsear Estandares_VIRF.xlsx → usando actividades por defecto", "warn")
    else:
        log("Estandares_VIRF.xlsx no encontrado → usando actividades por defecto", "warn")
        log("Tip: ejecuta 'python agente.py --template' para generar el template", "info")

    if dimensiones_activas is None:
        dimensiones_activas = {
            dim: [{"actividad": a, "requerida": True} for a in acts]
            for dim, acts in DIMENSIONES_VIRF.items()
        }

    # ── PASO 3: Leer inputs por dimensión ────────────────────────────────────
    log("PASO 3 — Leyendo archivos de input por dimensión...", "step")

    inputs_cfg = CONFIG["inputs"]

    # Documentación (compartida con Metodología)
    docs_documentacion = lector.leer_carpeta(Path(inputs_cfg["documentacion"]))
    docs_papers        = lector.leer_carpeta(Path(inputs_cfg["papers"]))
    docs_calidad       = lector.leer_carpeta(Path(inputs_cfg["calidad_datos"]))
    docs_implementacion= lector.leer_carpeta(Path(inputs_cfg["implementacion"]))
    docs_usos          = lector.leer_carpeta(Path(inputs_cfg["usos"]))

    for nombre, docs in [
        ("documentacion",   docs_documentacion),
        ("papers",          docs_papers),
        ("calidad_datos",   docs_calidad),
        ("implementacion",  docs_implementacion),
        ("usos",            docs_usos),
    ]:
        log(f"  {nombre}: {len(docs)} archivo(s)", "ok" if docs else "warn")

    # Mapeo de inputs por dimensión
    inputs_por_dim = {
        "Documentación":    docs_documentacion + docs_papers,
        "Calidad de Datos": docs_calidad,
        "Metodología":      docs_documentacion + docs_papers,   # mismos que documentación
        "Gobierno":         docs_usos,
        "Implementación":   docs_implementacion,
        "Uso e Integración": docs_usos,
    }

    # ── PASO 4: Análisis de cuestionamientos en código ───────────────────────
    sep()
    log("PASO 4 — Analizando código Python (cuestionamientos metodológicos)...", "step")
    cuestionamientos = motor.detectar_cuestionamientos_codigo(docs_calidad)
    if cuestionamientos:
        log(f"Código analizado: {list(cuestionamientos.keys())}", "ok")
        for archivo, analisis in cuestionamientos.items():
            n_q = len(analisis.get("cuestionamientos", []))
            n_r = len(analisis.get("alertas_rapidas", []))
            log(f"  {archivo}: {n_q} cuestionamientos Claude + {n_r} alertas rápidas",
                "warn" if n_q + n_r > 0 else "ok")
    else:
        log("Sin archivos .py proporcionados para análisis de código", "warn")

    # ── PASO 5: Evaluar cada dimensión ───────────────────────────────────────
    sep()
    log("PASO 5 — Evaluando dimensiones VIRF...", "step")
    resultados = {}

    for i, (dimension, actividades) in enumerate(dimensiones_activas.items(), 1):
        acts_requeridas = [a for a in actividades if a.get("requerida", True)]
        log(f"  [{i}/{len(dimensiones_activas)}] {dimension} "
            f"({len(acts_requeridas)} actividades requeridas)...", "info")

        docs = inputs_por_dim.get(dimension, [])
        instrucciones_dim = INSTRUCCIONES_DIMENSION.get(dimension, "")
        if instrucciones_extra:
            instrucciones_dim += f"\n{instrucciones_extra}"

        resultado = motor.evaluar_dimension(
            dimension=dimension,
            actividades=acts_requeridas,
            documentos=docs,
            estilo=estilo,
            instrucciones_especiales=instrucciones_dim,
        )
        resultados[dimension] = resultado

        pct = resultado.get("nivel_cumplimiento", 0)
        color = "ok" if pct >= 80 else "warn" if pct >= 50 else "error"
        log(f"     → Cumplimiento: {pct}%", color)

    # ── PASO 6: Síntesis final ───────────────────────────────────────────────
    sep()
    log("PASO 6 — Generando síntesis y dictamen global...", "step")
    sintesis = motor.generar_sintesis(resultados, titulo, estilo)
    dictamen = sintesis.get("dictamen_global", "—")
    riesgo   = sintesis.get("nivel_riesgo", "—")
    d_color  = "ok" if "APROBADO" in dictamen and "OBSERV" not in dictamen else "warn" if "OBSERV" in dictamen else "error"
    log(f"Dictamen: {dictamen}", d_color)
    log(f"Riesgo:   {riesgo}", "ok" if riesgo == "BAJO" else "warn" if riesgo == "MEDIO" else "error")

    # ── PASO 7: Generar outputs ──────────────────────────────────────────────
    sep()
    log("PASO 7 — Generando archivos de salida...", "step")

    ruta_excel = gen_xl.generar(titulo, sintesis, resultados, cuestionamientos)
    log(f"Excel VIRF generado: {ruta_excel.name}", "ok")

    ruta_word = gen_word.generar(titulo, sintesis, resultados)
    log(f"Word informe generado: {ruta_word.name}", "ok")

    # ── RESUMEN ──────────────────────────────────────────────────────────────
    sep()
    print(f"\n  {G}{BO}PROCESO COMPLETADO{R}")
    print(f"\n  📊 Excel  → outputs/{ruta_excel.name}")
    print(f"  📄 Word   → outputs/{ruta_word.name}")
    print()
    print(f"  {'─'*50}")
    print(f"  RESULTADOS POR DIMENSIÓN:")
    for dim, res in resultados.items():
        pct = res.get("nivel_cumplimiento", 0)
        bar = "█" * (pct // 10) + "░" * (10 - pct // 10)
        c_bar = G if pct >= 80 else Y if pct >= 50 else RE
        print(f"  {c_bar}{bar}{R}  {pct:3d}%  {dim}")
    print(f"  {'─'*50}")
    dictamen_color = G if "APROBADO" in dictamen and "OBSERV" not in dictamen else Y if "OBSERV" in dictamen else RE
    print(f"\n  Dictamen: {dictamen_color}{BO}{dictamen}{R}")
    print(f"  Riesgo:   {riesgo}\n")


def generar_template():
    banner()
    log("Generando template Estandares_VIRF.xlsx...", "step")
    from modulos.generador_template import generar_template as gen_tpl
    ruta = gen_tpl(Path("."))
    log(f"Template generado: {ruta}", "ok")
    log("Abre el archivo, coloca 'X' en las actividades que aplican a tu modelo", "info")
    log("Luego ejecuta: python agente.py --titulo 'Nombre de tu modelo'", "info")
    print()


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Agente IA VIRF — Model Risk Financial Controller"
    )
    parser.add_argument("--titulo",
                        default="Informe de Validación VIRF",
                        help="Título del informe de validación")
    parser.add_argument("--instrucciones", default="",
                        help="Instrucciones adicionales para el agente")
    parser.add_argument("--template", action="store_true",
                        help="Generar el template Estandares_VIRF.xlsx y salir")
    args = parser.parse_args()

    if args.template:
        generar_template()
    else:
        ejecutar(titulo=args.titulo, instrucciones_extra=args.instrucciones)
