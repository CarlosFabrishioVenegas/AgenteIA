"""
modulos/lector_inputs.py
=========================
Lee todos los archivos de entrada por dimensión:
  - PDFs → extrae texto con pdfminer o fallback PyPDF2
  - Word (.docx) → extrae texto con python-docx  
  - Excel (.xlsx) → pandas
  - Python (.py)  → texto plano
  - PPT (.pptx)   → texto de slides con python-pptx
  - JSON          → texto serializado
"""

import json
import re
from pathlib import Path
import pandas as pd

# ── Importaciones opcionales con fallback ─────────────────────────────────────

def _leer_pdf(path: Path) -> str:
    """Intenta con pdfminer, luego PyPDF2, luego retorna placeholder."""
    # Intentar pdfminer.six
    try:
        from pdfminer.high_level import extract_text
        return extract_text(str(path))
    except ImportError:
        pass
    # Intentar PyPDF2
    try:
        import PyPDF2
        texto = []
        with open(path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                t = page.extract_text()
                if t:
                    texto.append(t)
        return "\n".join(texto)
    except ImportError:
        pass
    return f"[PDF no legible sin pdfminer/PyPDF2: {path.name}]"


def _leer_docx(path: Path) -> str:
    try:
        from docx import Document
        from docx.oxml.ns import qn
        doc = Document(path)
        partes = []
        for elem in doc.element.body:
            tag = elem.tag.split("}")[-1] if "}" in elem.tag else elem.tag
            if tag == "p":
                texto = "".join(r.text for r in elem.iter(qn("w:t")))
                if texto.strip():
                    partes.append(texto.strip())
            elif tag == "tbl":
                for fila in elem.iter(qn("w:tr")):
                    celdas = ["".join(r.text for r in c.iter(qn("w:t"))).strip()
                              for c in fila.iter(qn("w:tc"))]
                    if any(celdas):
                        partes.append(" | ".join(celdas))
        return "\n".join(partes)
    except Exception as e:
        return f"[Error leyendo {path.name}: {e}]"


def _leer_pptx(path: Path) -> str:
    try:
        from pptx import Presentation
        prs = Presentation(path)
        partes = []
        for i, slide in enumerate(prs.slides, 1):
            textos_slide = []
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    textos_slide.append(shape.text.strip())
            if textos_slide:
                partes.append(f"[Slide {i}] " + " | ".join(textos_slide))
        return "\n".join(partes)
    except Exception as e:
        return f"[Error leyendo PPTX {path.name}: {e}]"


def _leer_excel(path: Path, max_filas: int = 150) -> str:
    try:
        xf = pd.ExcelFile(path)
        partes = []
        for nombre in xf.sheet_names:
            df = xf.parse(nombre).dropna(how="all").fillna("")
            csv = df.head(max_filas).to_csv(index=False)
            partes.append(f"--- Hoja: {nombre} ---\n{csv}")
        return "\n".join(partes)
    except Exception as e:
        return f"[Error leyendo Excel {path.name}: {e}]"


def _leer_python(path: Path, max_chars: int = 8000) -> str:
    try:
        codigo = path.read_text(encoding="utf-8", errors="replace")
        if len(codigo) > max_chars:
            codigo = codigo[:max_chars] + f"\n... [truncado a {max_chars} chars]"
        return codigo
    except Exception as e:
        return f"[Error leyendo .py {path.name}: {e}]"


def _leer_json(path: Path) -> str:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return json.dumps(data, ensure_ascii=False, indent=2)[:5000]
    except Exception as e:
        return f"[Error leyendo JSON {path.name}: {e}]"


# ── Clase principal ───────────────────────────────────────────────────────────

EXTENSIONES = {
    ".pdf":   lambda p, _: _leer_pdf(p),
    ".docx":  lambda p, _: _leer_docx(p),
    ".doc":   lambda p, _: _leer_docx(p),
    ".pptx":  lambda p, _: _leer_pptx(p),
    ".ppt":   lambda p, _: _leer_pptx(p),
    ".xlsx":  lambda p, cfg: _leer_excel(p, cfg.get("max_filas_excel", 150)),
    ".xls":   lambda p, cfg: _leer_excel(p, cfg.get("max_filas_excel", 150)),
    ".xlsm":  lambda p, cfg: _leer_excel(p, cfg.get("max_filas_excel", 150)),
    ".py":    lambda p, cfg: _leer_python(p, cfg.get("max_chars_codigo", 8000)),
    ".json":  lambda p, _: _leer_json(p),
    ".txt":   lambda p, _: p.read_text(encoding="utf-8", errors="replace")[:5000],
    ".md":    lambda p, _: p.read_text(encoding="utf-8", errors="replace")[:5000],
}


class LectorInputs:

    def __init__(self, cfg: dict):
        self.cfg = cfg

    def leer_carpeta(self, carpeta: Path) -> list[dict]:
        """
        Lee todos los archivos de una carpeta.
        Retorna lista de {"nombre": str, "tipo": str, "contenido": str}
        """
        if not carpeta.exists():
            return []
        archivos = []
        for path in sorted(carpeta.iterdir()):
            ext = path.suffix.lower()
            if ext in EXTENSIONES:
                contenido = EXTENSIONES[ext](path, self.cfg)
                max_chars = self.cfg.get("max_chars_doc", 5000)
                # Para .py dar más espacio
                if ext == ".py":
                    max_chars = self.cfg.get("max_chars_codigo", 8000)
                archivos.append({
                    "nombre":    path.name,
                    "tipo":      ext.lstrip(".").upper(),
                    "contenido": contenido[:max_chars],
                })
        return archivos

    def leer_informes_referencia(self, carpeta: Path) -> str:
        """
        Lee el repositorio de informes de validación previos.
        Devuelve texto concatenado para aprendizaje de estilo.
        """
        docs = self.leer_carpeta(carpeta)
        if not docs:
            return ""
        partes = []
        for d in docs:
            partes.append(f"=== INFORME DE REFERENCIA: {d['nombre']} ===\n{d['contenido']}\n")
        return "\n".join(partes)

    def leer_estandares_virf(self, path: Path) -> dict | None:
        """
        Lee el Excel Estandares_VIRF con estructura jerárquica de 3 niveles
        y celdas fusionadas:

            ÁMBITO  |  Control (Cuantitativo/Cualitativo)  |  Actividad  |  Requiere
            ─────────────────────────────────────────────────────────────────────────
            Docum.  |  Verifica manual metodológico         |  Ctrl versiones  |  X
                    |                                        |  Incluir obj.    |  X
                    |  Verifica manual implementación        |  Coherencia op.  |  X
            Calidad |  Controles calidad de dato             |  Sin duplicados  |  X

        Retorna:
        {
          "Documentación": [
            {
              "control":    "Verifica manual metodológico",
              "tipo_ctrl":  "Cuantitativo",   # o "Cualitativo" si la col lo indica
              "actividad":  "Verifica existencia de control de versiones",
              "requerida":  True
            },
            ...
          ],
          ...
        }
        Las celdas fusionadas se resuelven propagando el último valor no vacío
        hacia abajo (forward-fill) para cada columna jerárquica.
        """
        if not path.exists():
            return None

        import openpyxl

        try:
            wb = openpyxl.load_workbook(path, data_only=True)
            resultado = {}

            for nombre_hoja in wb.sheetnames:
                # Saltar hojas de instrucciones o resumen
                if any(k in nombre_hoja.lower() for k in ("instruc", "resumen", "readme", "leeme")):
                    continue

                ws = wb[nombre_hoja]

                # ── Resolver celdas fusionadas ─────────────────────────────
                # openpyxl deja None en las celdas fusionadas no-ancla.
                # Construimos una matriz con forward-fill por columna.
                filas = []
                for row in ws.iter_rows(values_only=True):
                    filas.append(list(row))

                if not filas:
                    continue

                n_cols = max(len(f) for f in filas)
                # Normalizar todas las filas a n_cols columnas
                for f in filas:
                    while len(f) < n_cols:
                        f.append(None)

                # Forward-fill columnas 0 y 1 (ÁMBITO y Control)
                for col_idx in (0, 1):
                    last = None
                    for fila in filas:
                        val = fila[col_idx]
                        if val is not None and str(val).strip():
                            last = str(val).strip()
                        else:
                            fila[col_idx] = last

                # ── Detectar fila de cabecera ──────────────────────────────
                # Buscamos la fila que contiene palabras clave de cabecera
                cabecera_idx = None
                palabras_hdr = {"ámbito", "ambito", "control", "actividad",
                                "requiere", "activity", "requier"}
                for i, fila in enumerate(filas):
                    vals_lower = {str(v).lower().strip() for v in fila if v}
                    if vals_lower & palabras_hdr:
                        cabecera_idx = i
                        break

                # Si no hay cabecera reconocible, asumir primera fila
                if cabecera_idx is None:
                    cabecera_idx = 0

                datos = filas[cabecera_idx + 1:]

                # ── Identificar índices de columnas ───────────────────────
                hdr_row = [str(v).lower().strip() if v else "" for v in filas[cabecera_idx]]

                def _col(*claves):
                    for i, h in enumerate(hdr_row):
                        if any(k in h for k in claves):
                            return i
                    return None

                col_ambito  = _col("ámbito", "ambito", "dimension", "dimensión") or 0
                col_ctrl    = _col("control", "ctrl") or 1
                col_act     = _col("actividad", "activity", "tarea") or 2
                col_req     = _col("requiere", "requier", "x", "req") or 3

                # ── Parsear filas de datos ─────────────────────────────────
                for fila in datos:
                    ambito  = str(fila[col_ambito]).strip()  if fila[col_ambito]  else ""
                    control = str(fila[col_ctrl]).strip()    if fila[col_ctrl]    else ""
                    activ   = str(fila[col_act]).strip()     if len(fila) > col_act and fila[col_act] else ""
                    req_raw = str(fila[col_req]).strip()     if len(fila) > col_req and fila[col_req] else ""

                    # Saltar filas vacías o de cabecera repetida
                    if not activ or activ.lower() in ("actividad", "activity", "nan", "none"):
                        continue
                    if not ambito or ambito.lower() in ("nan", "none"):
                        continue

                    requerida = req_raw.upper() in ("X", "SI", "YES", "1", "TRUE", "✓", "✔", "V")

                    # Detectar si el control es cuantitativo o cualitativo
                    tipo_ctrl = "Cualitativo"
                    ctrl_lower = control.lower()
                    if any(k in ctrl_lower for k in ("cuantit", "quantit", "medición", "medicion", "métrica", "metrica")):
                        tipo_ctrl = "Cuantitativo"

                    resultado.setdefault(ambito, []).append({
                        "control":   control,
                        "tipo_ctrl": tipo_ctrl,
                        "actividad": activ,
                        "requerida": requerida,
                    })

                # Si la hoja estaba vacía después del header, ignorar
                if ambito := resultado.get(nombre_hoja):
                    pass  # ya en resultado

            return resultado if resultado else None

        except Exception as e:
            print(f"    [!] Error leyendo Estandares_VIRF: {e}")
            return None
