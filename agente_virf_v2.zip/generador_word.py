"""
modulos/generador_word.py
==========================
Genera el informe narrativo de validación VIRF en .docx,
con el estilo aprendido de los informes de referencia.
"""

from pathlib import Path
from datetime import datetime
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


# ─── COLORES ─────────────────────────────────────────────────────────────────

AZUL     = RGBColor(0x1A, 0x3A, 0x5C)
AZUL_MED = RGBColor(0x2C, 0x5F, 0x8A)
BLANCO   = RGBColor(0xFF, 0xFF, 0xFF)
GRIS     = RGBColor(0x33, 0x33, 0x33)
VERDE    = RGBColor(0x1E, 0x8B, 0x4C)
ROJO     = RGBColor(0xC0, 0x39, 0x2B)
AMARILLO = RGBColor(0x9A, 0x61, 0x00)
NARANJA  = RGBColor(0xB8, 0x5C, 0x00)

DICTAMEN_COLOR = {
    "APROBADO":                   VERDE,
    "APROBADO CON OBSERVACIONES": AMARILLO,
    "RECHAZADO":                  ROJO,
}

RIESGO_COLOR = {
    "BAJO": VERDE, "MEDIO": AMARILLO, "ALTO": ROJO, "CRÍTICO": ROJO,
}

ESTADO_COLOR = {
    "Revisado y Aceptado": VERDE,
    "No Aceptado":         ROJO,
    "Solicitar Actas":     AMARILLO,
    "Observación":         NARANJA,
}


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def _run(para, texto, bold=False, color=None, size=None, italic=False):
    r = para.add_run(texto)
    r.bold = bold
    r.italic = italic
    if color:  r.font.color.rgb = color
    if size:   r.font.size = Pt(size)
    return r

def _heading(doc, texto, level):
    p = doc.add_heading(texto, level=level)
    for r in p.runs:
        r.font.color.rgb = AZUL
    return p

def _hrule(doc):
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bot = OxmlElement("w:bottom")
    bot.set(qn("w:val"), "single")
    bot.set(qn("w:sz"), "6")
    bot.set(qn("w:space"), "1")
    bot.set(qn("w:color"), "1A3A5C")
    pBdr.append(bot)
    pPr.append(pBdr)

def _cell_shading(cell, hex_color: str):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)

def _cell_margins(cell, top=80, bottom=80, left=120, right=120):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = OxmlElement("w:tcMar")
    for side, val in [("top", top), ("bottom", bottom), ("left", left), ("right", right)]:
        m = OxmlElement(f"w:{side}")
        m.set(qn("w:w"), str(val))
        m.set(qn("w:type"), "dxa")
        tcMar.append(m)
    tcPr.append(tcMar)


# ─── GENERADOR ───────────────────────────────────────────────────────────────

class GeneradorWord:

    def __init__(self, carpeta: Path):
        self.carpeta = carpeta
        self.carpeta.mkdir(parents=True, exist_ok=True)

    def generar(self, titulo: str, sintesis: dict, resultados: dict) -> Path:
        doc = Document()
        self._config(doc)
        self._portada(doc, titulo, sintesis)
        self._resumen_ejecutivo(doc, sintesis)
        self._tabla_cumplimiento(doc, resultados)
        self._detalle_dimensiones(doc, resultados)
        self._hallazgos_principales(doc, sintesis)
        self._plan_accion(doc, sintesis)
        self._conclusion(doc, sintesis)

        fecha = datetime.now().strftime("%Y%m%d_%H%M%S")
        nombre = f"VIRF_Informe_{fecha}.docx"
        ruta = self.carpeta / nombre
        doc.save(ruta)
        return ruta

    def _config(self, doc):
        doc.styles["Normal"].font.name = "Arial"
        doc.styles["Normal"].font.size = Pt(11)
        for nivel, pt, bold in [("Heading 1", 14, True), ("Heading 2", 12, True), ("Heading 3", 11, True)]:
            s = doc.styles[nivel]
            s.font.name = "Arial"
            s.font.size = Pt(pt)
            s.font.bold = bold
            s.font.color.rgb = AZUL
        for section in doc.sections:
            section.page_width   = Cm(21.59)
            section.page_height  = Cm(27.94)
            section.top_margin   = Cm(2.54)
            section.bottom_margin = Cm(2.54)
            section.left_margin  = Cm(2.54)
            section.right_margin = Cm(2.54)

    def _portada(self, doc, titulo, sintesis):
        for _ in range(3):
            doc.add_paragraph()

        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _run(p, "INFORME DE VALIDACIÓN VIRF", bold=True, color=AZUL_MED, size=13)

        p2 = doc.add_paragraph()
        p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _run(p2, titulo, bold=True, color=AZUL, size=18)

        doc.add_paragraph()
        _hrule(doc)
        doc.add_paragraph()

        fecha   = datetime.now().strftime("%d de %B de %Y")
        dictamen = sintesis.get("dictamen_global", "—")
        riesgo   = sintesis.get("nivel_riesgo", "—")

        for label, valor, color in [
            ("Fecha de emisión:",        fecha,    GRIS),
            ("Dictamen global:",         dictamen, DICTAMEN_COLOR.get(dictamen, GRIS)),
            ("Nivel de riesgo:",         riesgo,   RIESGO_COLOR.get(riesgo, GRIS)),
            ("Elaborado por:",           "Model Risk Financial Controller — Agente IA VIRF", AZUL_MED),
            ("Próxima revisión:",        sintesis.get("proxima_revision", "—"), GRIS),
        ]:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            _run(p, f"{label}  ", bold=True, color=AZUL_MED, size=11)
            _run(p, valor, bold=True, color=color, size=11)

        doc.add_page_break()

    def _resumen_ejecutivo(self, doc, sintesis):
        _heading(doc, "1. Resumen Ejecutivo", 1)
        for parrafo in sintesis.get("resumen_ejecutivo", "").split("\n"):
            if parrafo.strip():
                p = doc.add_paragraph(parrafo.strip())
                p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    def _tabla_cumplimiento(self, doc, resultados):
        _heading(doc, "2. Cumplimiento por Dimensión VIRF", 1)
        doc.add_paragraph()

        tabla = doc.add_table(rows=1, cols=5)
        tabla.style = "Table Grid"
        for i, enc in enumerate(["Dimensión", "Actividades", "Aceptadas", "% Cumplimiento", "Estado"]):
            celda = tabla.cell(0, i)
            _cell_shading(celda, "1A3A5C")
            _cell_margins(celda)
            r = celda.paragraphs[0].add_run(enc)
            r.bold = True
            r.font.color.rgb = BLANCO
            r.font.size = Pt(10)

        estado_hex = {
            "SATISFACTORIO": "D5F5E3",
            "OBSERVACIÓN":   "FFF3CD",
            "CRÍTICO":       "FDEDED",
        }

        for dim, res in resultados.items():
            evals = res.get("evaluaciones", [])
            total = len(evals)
            acept = sum(1 for e in evals if e.get("estado") == "Revisado y Aceptado")
            pct   = res.get("nivel_cumplimiento", round(acept / total * 100) if total else 0)
            estado = ("SATISFACTORIO" if pct >= 80 else "OBSERVACIÓN" if pct >= 50 else "CRÍTICO")
            est_color = {"SATISFACTORIO": VERDE, "OBSERVACIÓN": AMARILLO, "CRÍTICO": ROJO}[estado]

            fila = tabla.add_row()
            vals = [(dim, True, AZUL), (str(total), False, GRIS),
                    (str(acept), False, VERDE if acept == total else GRIS),
                    (f"{pct}%", True, est_color), (estado, True, est_color)]
            for i, (val, bold, color) in enumerate(vals):
                celda = fila.cells[i]
                _cell_margins(celda)
                if i == 4:
                    _cell_shading(celda, estado_hex[estado])
                r = celda.paragraphs[0].add_run(val)
                r.bold = bold
                r.font.size = Pt(10)
                r.font.color.rgb = color
                celda.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER if i > 0 else WD_ALIGN_PARAGRAPH.LEFT

    def _detalle_dimensiones(self, doc, resultados):
        _heading(doc, "3. Detalle por Dimensión", 1)

        for dim, res in resultados.items():
            doc.add_paragraph()
            _heading(doc, f"3.{list(resultados.keys()).index(dim)+1} {dim}", 2)

            # Resumen de la dimensión
            resumen = res.get("resumen_dimension", "")
            if resumen:
                p = doc.add_paragraph(resumen)
                p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

            doc.add_paragraph()

            evals = res.get("evaluaciones", [])
            if not evals:
                doc.add_paragraph("Sin actividades evaluadas en esta dimensión.")
                continue

            tabla = doc.add_table(rows=1, cols=4)
            tabla.style = "Table Grid"
            for i, enc in enumerate(["Actividad", "Estado", "Justificación", "Cuestionamiento"]):
                celda = tabla.cell(0, i)
                _cell_shading(celda, "2C5F8A")
                _cell_margins(celda)
                r = celda.paragraphs[0].add_run(enc)
                r.bold = True
                r.font.color.rgb = BLANCO
                r.font.size = Pt(9)

            for ev in evals:
                fila = tabla.add_row()
                estado = ev.get("estado", "")
                estado_hex_map = {
                    "Revisado y Aceptado": "D5F5E3",
                    "No Aceptado":         "FDEDED",
                    "Solicitar Actas":     "FFF3CD",
                    "Observación":         "FFF0E0",
                }

                # Col 1: Actividad
                celda = fila.cells[0]
                _cell_margins(celda)
                r = celda.paragraphs[0].add_run(ev.get("actividad", ""))
                r.font.size = Pt(9)

                # Col 2: Estado
                celda = fila.cells[1]
                _cell_margins(celda)
                hex_e = estado_hex_map.get(estado, "F4F7FB")
                _cell_shading(celda, hex_e)
                r = celda.paragraphs[0].add_run(estado)
                r.bold = True
                r.font.size = Pt(9)
                r.font.color.rgb = ESTADO_COLOR.get(estado, GRIS)
                celda.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

                # Col 3: Justificación
                celda = fila.cells[2]
                _cell_margins(celda)
                just = f"{ev.get('justificacion', '')}"
                if ev.get("evidencia"):
                    just += f"\n[Evidencia: {ev['evidencia']}]"
                r = celda.paragraphs[0].add_run(just)
                r.font.size = Pt(9)

                # Col 4: Cuestionamiento
                celda = fila.cells[3]
                _cell_margins(celda)
                cuest = ev.get("cuestionamiento")
                if cuest:
                    _cell_shading(celda, "FFF3CD")
                    r = celda.paragraphs[0].add_run(f"⚠ {cuest}")
                    r.font.size = Pt(9)
                    r.italic = True
                    r.font.color.rgb = AMARILLO
                else:
                    r = celda.paragraphs[0].add_run("—")
                    r.font.size = Pt(9)
                    r.font.color.rgb = RGBColor(0xBB, 0xBB, 0xBB)

    def _hallazgos_principales(self, doc, sintesis):
        _heading(doc, "4. Hallazgos Principales", 1)
        hall = sintesis.get("principales_hallazgos", [])
        if not hall:
            doc.add_paragraph("No se identificaron hallazgos críticos.")
            return

        tabla = doc.add_table(rows=1, cols=5)
        tabla.style = "Table Grid"
        for i, enc in enumerate(["ID", "Dimensión", "Hallazgo", "Severidad", "Acción requerida"]):
            celda = tabla.cell(0, i)
            _cell_shading(celda, "1A3A5C")
            _cell_margins(celda)
            r = celda.paragraphs[0].add_run(enc)
            r.bold = True
            r.font.color.rgb = BLANCO
            r.font.size = Pt(9)

        sev_hex = {"ALTA": "FDEDED", "MEDIA": "FFF3CD", "BAJA": "D5F5E3"}
        sev_rgb = {"ALTA": ROJO, "MEDIA": AMARILLO, "BAJA": VERDE}

        for h in hall:
            fila = tabla.add_row()
            sev = h.get("severidad", "MEDIA")
            for i, val in enumerate([h.get("id",""), h.get("dimension",""),
                                     h.get("hallazgo",""), sev, h.get("accion","")]):
                celda = fila.cells[i]
                _cell_margins(celda)
                if i == 3:
                    _cell_shading(celda, sev_hex.get(sev, "F4F7FB"))
                r = celda.paragraphs[0].add_run(val)
                r.bold = (i == 3)
                r.font.size = Pt(9)
                if i == 3:
                    r.font.color.rgb = sev_rgb.get(sev, GRIS)
                if i in (0, 3):
                    celda.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    def _plan_accion(self, doc, sintesis):
        _heading(doc, "5. Plan de Acción", 1)
        plan = sintesis.get("plan_accion", [])
        if not plan:
            doc.add_paragraph("Ver detalle en el Excel de resultados VIRF.")
            return

        tabla = doc.add_table(rows=1, cols=4)
        tabla.style = "Table Grid"
        for i, enc in enumerate(["Acción", "Responsable", "Plazo", "Prioridad"]):
            celda = tabla.cell(0, i)
            _cell_shading(celda, "1A3A5C")
            _cell_margins(celda)
            r = celda.paragraphs[0].add_run(enc)
            r.bold = True
            r.font.color.rgb = BLANCO
            r.font.size = Pt(9)

        prior_hex = {"INMEDIATA": "FDEDED", "30D": "FFF3CD", "90D": "D5F5E3"}
        prior_rgb = {"INMEDIATA": ROJO, "30D": AMARILLO, "90D": VERDE}

        for item in plan:
            fila = tabla.add_row()
            prior = item.get("prioridad", "30D")
            for i, val in enumerate([item.get("accion",""), item.get("responsable","—"),
                                     item.get("plazo","—"), prior]):
                celda = fila.cells[i]
                _cell_margins(celda)
                if i == 3:
                    _cell_shading(celda, prior_hex.get(prior, "F4F7FB"))
                r = celda.paragraphs[0].add_run(val)
                r.bold = (i == 3)
                r.font.size = Pt(9)
                if i == 3:
                    r.font.color.rgb = prior_rgb.get(prior, GRIS)
                    celda.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    def _conclusion(self, doc, sintesis):
        _heading(doc, "6. Conclusión", 1)
        conclusion = sintesis.get("conclusion_narrativa", "")
        for parrafo in conclusion.split("\n"):
            if parrafo.strip():
                p = doc.add_paragraph(parrafo.strip())
                p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

        doc.add_paragraph()
        _hrule(doc)
        doc.add_paragraph()
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        _run(p, "Informe generado por el Agente IA VIRF — Model Risk Financial Controller  ·  ",
             color=RGBColor(0x88, 0x88, 0x88), size=9)
        _run(p, datetime.now().strftime("%d/%m/%Y %H:%M"),
             color=RGBColor(0x88, 0x88, 0x88), size=9)
