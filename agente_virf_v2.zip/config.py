"""
config.py — Configuración del Agente VIRF
==========================================
Model Risk Financial Controller
"""
import os

CONFIG = {
    # ── API Key Anthropic ────────────────────────────────────────────────────
    "api_key": os.getenv("ANTHROPIC_API_KEY", "TU_API_KEY_AQUI"),
    "modelo_claude": "claude-sonnet-4-20250514",
    "max_tokens": 4000,

    # ── Carpetas del proyecto ────────────────────────────────────────────────
    # Informes de validación previos para aprender el lenguaje
    "repositorio_informes": "repositorio_informes",

    # Inputs por dimensión
    "inputs": {
        "documentacion":  "inputs/documentacion",   # PDFs de documentación del modelo
        "papers":         "inputs/papers",           # Papers científicos usados
        "calidad_datos":  "inputs/calidad_datos",    # Excel de datos + .py del modelo
        "implementacion": "inputs/implementacion",   # Excel/PDF/JSON de controles
        "usos":           "inputs/usos",             # PPTs, actas, PDFs de comités
    },

    # Excel de estándares VIRF (se puede generar template si no existe)
    "estandares_virf": "Estandares_VIRF.xlsx",

    # Outputs
    "outputs": "outputs",

    # ── Parámetros de procesamiento ──────────────────────────────────────────
    "max_chars_doc": 5000,      # Caracteres por documento para el prompt
    "max_chars_codigo": 8000,   # Caracteres del .py a analizar
    "max_filas_excel": 150,

    # ── Rol del agente ───────────────────────────────────────────────────────
    "rol_agente": """Eres un Model Risk Financial Controller senior con 15+ años de experiencia 
en validación independiente de modelos financieros (scoring crediticio, IFRS 9, PD/LGD/EAD, 
VaR, ES, modelos de fraude y AML). 

Tu rol es auditor crítico e independiente. Debes:
1. Verificar que cada actividad del estándar VIRF esté cubierta en los documentos/código.
2. Cuestionar metodologías usando tu conocimiento técnico actualizado — si hay mejores 
   prácticas, las señalas explícitamente con justificación técnica.
3. Ser específico: NO dices "el modelo es adecuado" sin evidencia concreta del texto/código.
4. Aplicar criterio regulatorio: Basilea III/IV, SR 11-7 (Fed), SS3/17 (PRA), IFRS 9, 
   EBA/ECB model risk guidelines.
5. Usar el mismo lenguaje y estilo de los informes de referencia que se te proporcionan.""",
}

# ── Dimensiones VIRF — estructura jerárquica 3 niveles ───────────────────────
# Ámbito → Control (Cuantitativo / Cualitativo) → Actividad
#
# Estas son las actividades DEFAULT que se usan si no existe Estandares_VIRF.xlsx
# o si no se puede leer. El Excel real tiene la misma estructura: celdas fusionadas
# en las columnas ÁMBITO y CONTROL, con una Actividad por fila y X si es requerida.
#
# Formato de cada entrada:
#   { "control": str, "tipo_ctrl": "Cuantitativo"|"Cualitativo",
#     "actividad": str, "requerida": bool }

DIMENSIONES_VIRF = {
    "Documentación": [
        # ── Control Cuantitativo ──────────────────────────────────────────────
        {"control": "Verifica existencia de manual metodológico",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verifica existencia de control de versiones del modelo",
         "requerida": True},
        {"control": "Verifica existencia de manual metodológico",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verifica inclusión de objetivos, usos y usuarios del modelo",
         "requerida": True},
        {"control": "Verifica existencia de manual metodológico",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Revisa documentación y descripción de supuestos y restricciones",
         "requerida": True},
        {"control": "Verifica existencia de manual metodológico",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Especifica horizonte temporal de validez del modelo",
         "requerida": True},
        # ── Control Cualitativo ───────────────────────────────────────────────
        {"control": "Verifica existencia de manual de implementación",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Verifica coherencia en el manual operativo",
         "requerida": True},
        {"control": "Verifica existencia de manual de implementación",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Documenta descripción de la población objetivo",
         "requerida": True},
        {"control": "Verifica existencia de manual de implementación",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Incluye métricas de seguimiento y alertas definidas",
         "requerida": True},
    ],

    "Calidad de Datos": [
        # ── Control Cuantitativo ──────────────────────────────────────────────
        {"control": "El modelo deberá contar con controles de calidad de dato",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verificar la existencia y suficiencia de controles de calidad",
         "requerida": True},
        {"control": "El modelo deberá contar con controles de calidad de dato",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verificar que no existan duplicados en el dataset",
         "requerida": True},
        {"control": "El modelo deberá contar con controles de calidad de dato",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verificar tratamiento de valores missing (MCAR, MAR, MNAR)",
         "requerida": True},
        {"control": "El modelo deberá contar con controles de calidad de dato",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Identificar y tratar outliers con metodología justificada",
         "requerida": True},
        {"control": "El modelo deberá contar con controles de calidad de dato",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verificar manejo de datos sensibles y anonimización",
         "requerida": True},
        # ── Control Cualitativo ───────────────────────────────────────────────
        {"control": "Análisis de representatividad y linaje de datos",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Documentar fuentes de datos y linaje",
         "requerida": True},
        {"control": "Análisis de representatividad y linaje de datos",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Verificar cobertura temporal adecuada del dataset",
         "requerida": True},
        {"control": "Análisis de representatividad y linaje de datos",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Aplicar pruebas de estabilidad de datos (PSI por variable)",
         "requerida": True},
    ],

    "Metodología": [
        # ── Control Cuantitativo ──────────────────────────────────────────────
        {"control": "Revisión de justificación metodológica",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Existencia de buenas prácticas y justificación del algoritmo",
         "requerida": True},
        {"control": "Revisión de justificación metodológica",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Se tienen identificadas las limitaciones del modelo",
         "requerida": True},
        {"control": "Revisión de justificación metodológica",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Comparación de desempeño vs modelo benchmark o challenger",
         "requerida": True},
        # ── Control Cualitativo ───────────────────────────────────────────────
        {"control": "Backtesting y pruebas de desempeño",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Aplicar backtesting con ventana temporal suficiente (≥2 años + 6m OOT)",
         "requerida": True},
        {"control": "Backtesting y pruebas de desempeño",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Realizar pruebas de discriminación (Gini, KS, AUC-ROC)",
         "requerida": True},
        {"control": "Backtesting y pruebas de desempeño",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Realizar pruebas de calibración (Hosmer-Lemeshow, Brier Score)",
         "requerida": True},
        {"control": "Backtesting y pruebas de desempeño",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verificar estabilidad del modelo (PSI, CSI)",
         "requerida": True},
    ],

    "Gobierno": [
        # ── Control Cualitativo ───────────────────────────────────────────────
        {"control": "Alineamientos y aprobaciones formales",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Acta de aprobación del modelo por comité competente",
         "requerida": True},
        {"control": "Alineamientos y aprobaciones formales",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Aprobación por Model Risk Management o función equivalente",
         "requerida": True},
        {"control": "Alineamientos y aprobaciones formales",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Registro del modelo en el inventario corporativo",
         "requerida": True},
        {"control": "Alineamientos y aprobaciones formales",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Acta de revisión periódica vigente",
         "requerida": True},
        {"control": "Alineamientos y aprobaciones formales",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Plan de contingencia ante fallo del modelo documentado",
         "requerida": True},
    ],

    "Implementación": [
        # ── Control Cuantitativo ──────────────────────────────────────────────
        {"control": "Controles técnicos del modelo en producción",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Verificar replicabilidad del modelo en entorno productivo",
         "requerida": True},
        {"control": "Controles técnicos del modelo en producción",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Controles de calidad en el pipeline de datos productivo",
         "requerida": True},
        {"control": "Controles técnicos del modelo en producción",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Pruebas UAT documentadas y aprobadas antes del go-live",
         "requerida": True},
        # ── Control Cualitativo ───────────────────────────────────────────────
        {"control": "Lineamientos de seguridad y desarrollo",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Lineamientos de seguridad de la información cumplidos",
         "requerida": True},
        {"control": "Lineamientos de seguridad y desarrollo",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Desarrollo interno siguiendo estándares SDLC corporativos",
         "requerida": True},
        {"control": "Lineamientos de seguridad y desarrollo",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Control de versiones del modelo en producción documentado",
         "requerida": True},
    ],

    "Uso e Integración": [
        # ── Control Cuantitativo ──────────────────────────────────────────────
        {"control": "Evidencia de uso y validación de outputs",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Evidencia de uso efectivo del modelo en decisiones de negocio",
         "requerida": True},
        {"control": "Evidencia de uso y validación de outputs",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Validación de outputs del modelo en producción vs desarrollo",
         "requerida": True},
        {"control": "Evidencia de uso y validación de outputs",
         "tipo_ctrl": "Cuantitativo",
         "actividad": "Reportes de seguimiento presentados a comités",
         "requerida": True},
        # ── Control Cualitativo ───────────────────────────────────────────────
        {"control": "Integración y comunicación a usuarios",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Capacitación a usuarios del modelo documentada",
         "requerida": True},
        {"control": "Integración y comunicación a usuarios",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Comunicación formal de limitaciones a usuarios finales",
         "requerida": True},
        {"control": "Integración y comunicación a usuarios",
         "tipo_ctrl": "Cualitativo",
         "actividad": "Feedback loop entre uso operativo y mejora del modelo",
         "requerida": True},
    ],
}

# ── Señales de cuestionamiento metodológico ──────────────────────────────────
# El agente busca estos patrones en el código/docs y propone alternativas

CUESTIONAMIENTOS_METODOLOGICOS = {
    "outliers_zscore": {
        "detectar": ["zscore", "z_score", "z-score", "scipy.stats.zscore", "3 sigma", "tres sigma"],
        "contexto": "Eliminación de outliers mediante Z-score",
        "critica": "Z-score asume normalidad y es sensible a los propios outliers (non-robust). "
                   "Para datos financieros con distribuciones fat-tail se recomienda: "
                   "GESD (Generalized ESD) para detección múltiple, IQR robusto, "
                   "Isolation Forest para multivariado, o Mahalanobis Distance.",
    },
    "imputation_mean": {
        "detectar": ["fillna(mean", "fillna(df.mean", "impute.*mean", "SimpleImputer.*mean"],
        "contexto": "Imputación de missing values con media",
        "critica": "Imputar con media destruye la varianza y puede introducir sesgo en modelos de crédito. "
                   "Alternativas recomendadas: MICE (Multiple Imputation by Chained Equations), "
                   "KNN Imputation, o MissForest para datos con patrones MNAR.",
    },
    "train_test_split_random": {
        "detectar": ["train_test_split", "random_state", "shuffle=True"],
        "contexto": "División aleatoria train/test",
        "critica": "En datos financieros con componente temporal, la división aleatoria introduce "
                   "data leakage futuro. Se debe usar división temporal (Out-Of-Time, OOT) "
                   "con al menos 6-12 meses de OOT para scoring crediticio (SR 11-7).",
    },
    "logistic_without_calibration": {
        "detectar": ["LogisticRegression", "logistic_regression", "regresion_logistica"],
        "contexto": "Regresión logística sin calibración explícita",
        "critica": "Para modelos PD bajo IFRS 9, la probabilidad raw de la logística debe calibrarse "
                   "al through-the-cycle o point-in-time según el uso. Verificar uso de "
                   "Platt Scaling o Isotonic Regression para recalibración.",
    },
    "gini_solo": {
        "detectar": ["gini", "roc_auc", "auc_roc"],
        "contexto": "Evaluación solo con Gini/AUC",
        "critica": "Gini/AUC mide discriminación pero no calibración. Bajo Basilea III y EBA GL "
                   "se exige también: Brier Score, Hosmer-Lemeshow, reliability diagram, "
                   "y análisis de calibración por decil/score band.",
    },
    "no_psi": {
        "detectar_ausencia": True,
        "detectar": ["psi", "population_stability", "estabilidad_poblacional"],
        "contexto": "Ausencia de análisis PSI",
        "critica": "No se detecta cálculo de PSI (Population Stability Index). "
                   "Regulación EBA/BCE y SR 11-7 exigen monitoreo de estabilidad poblacional. "
                   "PSI < 0.10: estable; 0.10-0.25: observación; > 0.25: rediseño requerido.",
    },
    "xgboost_without_shap": {
        "detectar": ["xgboost", "XGBClassifier", "lightgbm", "LGBMClassifier", "RandomForest"],
        "contexto": "Modelos no lineales sin explicabilidad",
        "critica": "Modelos tree-based requieren análisis de explicabilidad bajo SR 11-7 y "
                   "GDPR (derecho a explicación). Se recomienda SHAP values para explicabilidad "
                   "global y local, y LIME para explicación por instancia.",
    },
}
