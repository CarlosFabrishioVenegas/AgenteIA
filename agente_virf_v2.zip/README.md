# Agente IA VIRF — Model Risk Financial Controller

Sistema de validación independiente de modelos financieros. El agente actúa como
un **Model Risk Financial Controller** senior: aprende el lenguaje de tus informes previos,
evalúa actividades VIRF contra los documentos/código del modelo y cuestiona metodologías
cuando existen mejores prácticas disponibles.

---

## Estructura del proyecto

```
virf_agent/
│
├── agente.py                    ← PUNTO DE ENTRADA
├── config.py                    ← API key, rutas, cuestionamientos metodológicos
├── Estandares_VIRF.xlsx         ← Se genera con --template (llénalo con X)
│
├── repositorio_informes/        ← Informes de validación previos (.docx/.pdf)
│                                    El agente aprende el lenguaje de estos docs
│
├── inputs/
│   ├── documentacion/           ← PDFs/DOCX de documentación del modelo
│   ├── papers/                  ← Papers científicos usados en el modelo
│   ├── calidad_datos/           ← Excel de datos + archivo .py del modelo
│   ├── implementacion/          ← Excel/PDF/JSON de controles de sistemas
│   └── usos/                    ← PPTs, actas, PDFs de comités
│
├── outputs/                     ← Archivos generados
│   ├── VIRF_Resultados_*.xlsx   ← Excel con evaluación por actividad
│   └── VIRF_Informe_*.docx      ← Word con informe narrativo
│
└── modulos/
    ├── lector_inputs.py         ← Lee PDF, DOCX, PPTX, XLSX, PY, JSON
    ├── motor_ia.py              ← Claude como Model Risk Controller
    ├── generador_excel.py       ← Excel de resultados con semáforos
    ├── generador_word.py        ← Word del informe narrativo
    └── generador_template.py   ← Genera Estandares_VIRF.xlsx
```

---

## Instalación

```bash
pip install python-docx openpyxl pandas requests pdfminer.six python-pptx
```

---

## Configuración

Edita `config.py`:

```python
"api_key": "sk-ant-..."
```

O variable de entorno:

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

---

## Flujo de uso

### Paso 1 — Generar el template VIRF (primera vez)

```bash
python agente.py --template
```

Abre `Estandares_VIRF.xlsx` y deja la `X` en las actividades que aplican a tu modelo.
Si una actividad no aplica, borra la X de esa fila.

### Paso 2 — Cargar los archivos de referencia

```
repositorio_informes/   ← Pon aquí informes de validación previos (el agente aprende el lenguaje)
```

### Paso 3 — Cargar los inputs del modelo

| Carpeta | Qué poner | Para qué dimensión |
|---|---|---|
| `inputs/documentacion/` | PDFs/DOCX de documentación del modelo | Documentación + Metodología |
| `inputs/papers/` | Papers académicos citados | Documentación + Metodología |
| `inputs/calidad_datos/` | Excel de datos + `.py` del modelo | Calidad de Datos |
| `inputs/implementacion/` | Excel/PDF de controles de sistemas | Implementación |
| `inputs/usos/` | PPTs, actas, PDFs de comités | Gobierno + Uso e Integración |

### Paso 4 — Ejecutar el agente

```bash
# Validación básica
python agente.py --titulo "Validación Modelo Scoring Retail v2.3"

# Con instrucciones adicionales
python agente.py \
  --titulo "Validación Modelo PD Corporativo Q1 2025" \
  --instrucciones "Enfatizar análisis de backtesting 2022-2024 y PSI por segmento"
```

---

## Qué hace el agente por dimensión

### 📄 Documentación
Busca en los PDFs/DOCX si están cubiertos los requerimientos (objetivos, alcance,
supuestos, usuarios, limitaciones, etc.). Veredicto: **Revisado y Aceptado** / **No Aceptado** / **Observación**.

### 📊 Calidad de Datos
Lee el `.py` del modelo y detecta:
- Tratamiento de outliers: ¿usa Z-score? → sugiere GESD/Mahalanobis
- Imputación: ¿usa media? → sugiere MICE/KNN
- División train/test: ¿es aleatoria? → exige OOT temporal
- Ausencia de PSI → alerta regulatoria (SR 11-7, EBA)
- Ausencia de SHAP en modelos complejos → alerta GDPR

### 🔬 Metodología
Usa los mismos documentos de Documentación para verificar:
- Backtesting con ventana suficiente (≥2 años + 6m OOT)
- Métricas de calibración además de discriminación
- Comparación vs modelo challenger/benchmark

### 🏛 Gobierno
Verifica las actas y PDFs de comités. Si no hay evidencia de aprobación formal:
→ Estado: **Solicitar Actas**

### ⚙️ Implementación
Analiza controles técnicos, documentos de sistemas, evidencia de UAT.

### 📈 Uso e Integración
Verifica PPTs de comités, actas de reuniones, evidencia de uso en producción.

---

## Outputs generados

### `VIRF_Resultados_*.xlsx`
- **Dashboard VIRF**: Semáforo por dimensión + dictamen global + justificación
- **[Dimensión]** (6 hojas): Detalle de cada actividad con estado, evidencia, justificación y cuestionamiento
- **Cuestionamientos Metodológicos**: Críticas al código con alternativas y referencias regulatorias
- **Plan de Acción**: Tabla priorizada (INMEDIATA / 30D / 90D)

### `VIRF_Informe_*.docx`
- Portada con dictamen y nivel de riesgo
- Resumen ejecutivo (redactado con el estilo de los informes de referencia)
- Tabla de cumplimiento por dimensión
- Detalle por dimensión con hallazgos
- Hallazgos principales
- Plan de acción
- Conclusión narrativa

---

## Cuestionamientos que realiza el agente

El agente está programado para cuestionar automáticamente:

| Patrón detectado | Crítica del agente | Alternativa recomendada |
|---|---|---|
| Z-score para outliers | No robusto, asume normalidad | GESD, Mahalanobis, Isolation Forest |
| `fillna(mean)` | Destruye varianza, sesgo en PD | MICE, KNN Imputation, MissForest |
| `train_test_split` random | Data leakage en datos temporales | División OOT temporal (6-12m) |
| LogisticRegression sin calibración | PD raw ≠ PD calibrada bajo IFRS 9 | Platt Scaling, Isotonic Regression |
| Solo Gini/AUC | Discriminación ≠ Calibración | + Brier Score, Hosmer-Lemeshow |
| Ausencia de PSI | Incumple SR 11-7 y EBA | PSI por variable y por cosecha |
| XGBoost/RandomForest sin SHAP | Incumple GDPR art.22 | SHAP values, LIME |

Además, Claude analiza el código en profundidad y puede detectar patrones no listados.
