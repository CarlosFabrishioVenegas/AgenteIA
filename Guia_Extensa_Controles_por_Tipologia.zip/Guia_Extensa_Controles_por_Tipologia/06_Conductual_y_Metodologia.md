# Modelos Conductuales (extensión) y Controles Metodológicos

**Backtesting de prepago, log-rank, estacionalidad y validación transversal**

Guía Extensa de Controles por Tipología — VIRF · Versión 1.0 · 2026-09-05


---

> **Documento de conocimiento cuantitativo — VIRF.** Cada control incluye su sustentación técnica y código Python **probado** (numpy / scipy / sklearn). Los umbrales son convenciones de industria que se calibran y aprueban en la política interna de validación. El marco de validación, seguimiento y backtesting se alinea con la Res. SBS N° 00053-2023; en riesgo de mercado con la Res. SBS N° 4906-2017 y con FRTB para PLA/ES.


---

## Introducción

Controles conductuales adicionales (backtesting de prepago, prueba log-rank entre curvas de supervivencia y estacionalidad) y los controles metodológicos transversales que aplican a toda tipología: reproducibilidad, reconciliación, análisis de sensibilidad, benchmarking y prueba de réplica.

**Imports comunes del módulo ejecutable:**

```python
# -*- coding: utf-8 -*-
"""Controles adicionales por tipología: riesgo operacional (LDA), modelos de
IA/ML, conductuales extendidos y controles metodológicos transversales."""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import rankdata


def _auc(y, s):
    y = np.asarray(y).astype(int); s = np.asarray(s, float)
    n1, n0 = int(y.sum()), int((y == 0).sum())
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s)
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


# ================= RIESGO OPERACIONAL =================
```


---

## Catálogo de controles (8)

### B1 — Backtesting del prepago: CPR predicho vs observado

**Sustentación.** El backtesting del prepago enfrenta el CPR predicho contra el observado por periodo; un error sistemático invalida las proyecciones de runoff que alimentan el ALM y el LaR.

**Código (Python).**

```python
# B1 - Backtesting del prepago: CPR predicho vs observado
def b1_backtest_prepago(cpr_predicho, cpr_observado, tol=0.02):
    p = np.asarray(cpr_predicho, float); o = np.asarray(cpr_observado, float)
    err = o - p
    return {"error_medio": round(float(err.mean()), 4),
            "RMSE": round(float(np.sqrt(np.mean(err ** 2))), 4),
            "n_fuera_tolerancia": int(np.sum(np.abs(err) > tol))}
```

### B2 — Prueba log-rank de diferencia entre curvas de supervivencia

**Sustentación.** La prueba log-rank contrasta si dos poblaciones (por ejemplo dos cosechas) tienen la misma curva de supervivencia; sustenta la segmentación del modelo conductual.

**Código (Python).**

```python
# B2 - Prueba log-rank de diferencia entre curvas de supervivencia
def b2_logrank(t1, e1, t2, e2):
    """Contrasta si dos poblaciones (p.ej. dos cosechas) tienen la misma
    curva de supervivencia. Chi-cuadrado con 1 grado de libertad."""
    df = pd.DataFrame({"t": np.r_[t1, t2], "e": np.r_[e1, e2],
                       "g": np.r_[np.zeros(len(t1)), np.ones(len(t2))]}).sort_values("t")
    O1 = E1 = V = 0.0
    n = len(df)
    for t, grp in df.groupby("t"):
        d = grp["e"].sum(); nj = n
        n1 = ((df["t"] >= t) & (df["g"] == 0)).sum()
        if nj > 1 and d > 0:
            E1 += d * n1 / nj
            V += d * (n1 / nj) * (1 - n1 / nj) * (nj - d) / (nj - 1)
        O1 += grp.loc[grp["g"] == 0, "e"].sum()
        n -= len(grp)
    chi2 = (O1 - E1) ** 2 / V if V > 0 else 0.0
    return {"chi2": round(float(chi2), 3), "p_valor": round(float(1 - stats.chi2.cdf(chi2, 1)), 4),
            "curvas_distintas_5pct": bool((1 - stats.chi2.cdf(chi2, 1)) < 0.05)}
```

### B3 — Estacionalidad del comportamiento (factores mensuales)

**Sustentación.** La estacionalidad descompone factores mensuales del comportamiento (retiros, prepagos); ignorarla sesga la proyección de flujos en meses atípicos.

**Código (Python).**

```python
# B3 - Estacionalidad del comportamiento (factores mensuales)
def b3_estacionalidad(serie_mensual, periodo=12):
    s = pd.Series(serie_mensual).dropna().values
    if len(s) < periodo:
        return {"factores": None}
    n = (len(s) // periodo) * periodo
    m = s[:n].reshape(-1, periodo)
    factores = m.mean(0) / m.mean()
    return {"factores_mensuales": np.round(factores, 3).tolist(),
            "amplitud": round(float(factores.max() - factores.min()), 3)}


# ================= METODOLOGÍA / IMPLEMENTACIÓN =================
```

### T1 — Reproducibilidad: igualdad de resultados entre dos ejecuciones

**Sustentación.** La reproducibilidad verifica que dos ejecuciones con los mismos insumos producen el mismo resultado; es precondición de toda validación defendible (Art. 15 y 20 del reglamento SBS).

**Código (Python).**

```python
# T1 - Reproducibilidad: igualdad de resultados entre dos ejecuciones
def t1_reproducibilidad(resultado_1, resultado_2, rtol=1e-9, atol=1e-9):
    a, b = np.asarray(resultado_1, float), np.asarray(resultado_2, float)
    return {"reproducible": bool(np.allclose(a, b, rtol=rtol, atol=atol)),
            "dif_max": round(float(np.max(np.abs(a - b))), 12)}
```

### T2 — Reconciliación de outputs (modelo vs herramienta) con tolerancia

**Sustentación.** La reconciliación contrasta el output del modelo contra el publicado dentro de una tolerancia; una diferencia no reconciliada es hallazgo de implementación.

**Código (Python).**

```python
# T2 - Reconciliación de outputs (modelo vs herramienta) con tolerancia
def t2_reconciliacion(valor_modelo, valor_publicado, atol=1e-6, rtol=1e-6):
    a, b = np.asarray(valor_modelo, float), np.asarray(valor_publicado, float)
    dif_abs = np.abs(a - b)
    ok = dif_abs <= (atol + rtol * np.abs(b))
    return {"n_no_reconciliados": int(np.sum(~ok)),
            "dif_abs_max": round(float(dif_abs.max()), 8)}
```

### T3 — Análisis de sensibilidad: cambio del output ante perturbación del input

**Sustentación.** El análisis de sensibilidad mide cuánto cambia el output ante una perturbación del input; identifica supuestos críticos y zonas de inestabilidad del modelo.

**Código (Python).**

```python
# T3 - Análisis de sensibilidad: cambio del output ante perturbación del input
def t3_sensibilidad(func, x0, perturbacion=0.10):
    v0 = func(x0)
    vp = func(np.asarray(x0, float) * (1 + perturbacion))
    elasticidad = (vp - v0) / v0 / perturbacion if v0 else None
    return {"valor_base": float(v0), "valor_perturbado": float(vp),
            "elasticidad": round(float(elasticidad), 4) if elasticidad is not None else None}
```

### T4 — Benchmarking contra modelo alternativo (challenger)

**Sustentación.** El benchmarking contra un modelo alternativo (challenger) cuantifica si existe una especificación mejor; es parte del monitoreo continuo de SR 11-7.

**Código (Python).**

```python
# T4 - Benchmarking contra modelo alternativo (challenger)
def t4_benchmarking(metrica_campeon, metrica_challenger, mejor="mayor"):
    dif = metrica_challenger - metrica_campeon
    supera = dif > 0 if mejor == "mayor" else dif < 0
    return {"campeon": metrica_campeon, "challenger": metrica_challenger,
            "diferencia": round(float(dif), 4), "challenger_supera": bool(supera)}
```

### T5 — Prueba de réplica: el resultado replicado coincide con el reportado

**Sustentación.** La prueba de réplica reproduce el resultado a partir de la documentación de sustento; para modelos de mayor categoría, la Res. SBS 00053-2023 exige la réplica completa (Art. 20.2.1).

**Código (Python).**

```python
# T5 - Prueba de réplica: el resultado replicado coincide con el reportado
def t5_replica(resultado_replicado, resultado_reportado, tol=1e-6):
    a, b = np.asarray(resultado_replicado, float), np.asarray(resultado_reportado, float)
    return {"replica_exitosa": bool(np.allclose(a, b, atol=tol)),
            "desvio_max": round(float(np.max(np.abs(a - b))), 8)}
```


---
*Todo el código fue ejecutado con datos sintéticos antes de la entrega.*
