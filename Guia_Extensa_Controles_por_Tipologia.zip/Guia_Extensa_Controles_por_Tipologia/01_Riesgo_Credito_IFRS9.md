# Riesgo de Crédito e IFRS 9

**Discriminación, calibración, estabilidad, PD/LGD/EAD, ECL y staging**

Guía Extensa de Controles por Tipología — VIRF · Versión 1.0 · 2026-09-05


---

> **Documento de conocimiento cuantitativo — VIRF.** Cada control incluye su sustentación técnica y código Python **probado** (numpy / scipy / sklearn). Los umbrales son convenciones de industria que se calibran y aprueban en la política interna de validación. El marco de validación, seguimiento y backtesting se alinea con la Res. SBS N° 00053-2023; en riesgo de mercado con la Res. SBS N° 4906-2017 y con FRTB para PLA/ES.


---

## Introducción

Controles de validación para modelos de calificación (scoring/rating), estimación de PD, LGD y EAD, cálculo de ECL y clasificación en etapas (staging) de IFRS 9. Cubre los tres ejes de la validación cuantitativa —discriminación, calibración y estabilidad— más el backtesting de la tasa de default y los controles específicos de LGD, EAD, ECL y SICR.

**Imports comunes del módulo ejecutable:**

```python
# -*- coding: utf-8 -*-
"""Controles de validación para modelos de riesgo de crédito e IFRS 9
(scoring/rating, PD, LGD, EAD, ECL, staging). Probado con numpy/scipy/sklearn."""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import rankdata


def _auc(y, score):
    y = np.asarray(y).astype(int); s = np.asarray(score, float)
    n1, n0 = int(y.sum()), int((y == 0).sum())
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s)
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))
```


---

## Catálogo de controles (25)

### CR1 — Poder de discriminacion: AUC-ROC

**Sustentación.** El AUC-ROC mide la probabilidad de que el modelo asigne mayor riesgo a un incumplido que a un no incumplido. Es la métrica central de discriminación; por debajo de 0.7 el poder es insuficiente para uso en decisiones de crédito.

**Código (Python).**

```python
# CR1 - Poder de discriminacion: AUC-ROC
def cr1_auc(y_evento, score):
    """AUC = P(score(malo) > score(bueno)). score alto = mayor riesgo."""
    auc = _auc(y_evento, score)
    nivel = ("insuficiente" if auc < 0.7 else "aceptable" if auc < 0.8 else "bueno")
    return {"AUC": round(auc, 4), "nivel": nivel}
```

### CR2 — Coeficiente de Gini (= 2*AUC - 1)

**Sustentación.** El Gini es una reescala del AUC (Gini = 2·AUC − 1) muy usada en scoring minorista, con rangos típicos de 0.4 a 0.6; facilita la comparación entre modelos y con el desarrollo.

**Código (Python).**

```python
# CR2 - Coeficiente de Gini (= 2*AUC - 1)
def cr2_gini(y_evento, score):
    return {"Gini": round(2 * _auc(y_evento, score) - 1, 4)}
```

### CR3 — Estadistico de Kolmogorov-Smirnov

**Sustentación.** El estadístico KS mide la máxima separación entre las distribuciones acumuladas del score para buenos y malos; complementa al AUC identificando el punto de corte de mayor discriminación.

**Código (Python).**

```python
# CR3 - Estadistico de Kolmogorov-Smirnov
def cr3_ks(y_evento, score):
    y = np.asarray(y_evento).astype(int); s = np.asarray(score, float)
    ks = stats.ks_2samp(s[y == 1], s[y == 0]).statistic
    return {"KS": round(float(ks), 4), "aceptable_>0.3": bool(ks > 0.3)}
```

### CR4 — Information Value (IV) y WoE por variable

**Sustentación.** El Information Value cuantifica el poder predictivo de cada variable vía el WoE; sustenta la selección de variables y detecta las que no aportan (IV < 0.02) o las sospechosamente fuertes (posible fuga).

**Código (Python).**

```python
# CR4 - Information Value (IV) y WoE por variable
def cr4_information_value(feature, y_evento, bins=10):
    df = pd.DataFrame({"x": pd.to_numeric(pd.Series(feature), errors="coerce"),
                       "y": np.asarray(y_evento).astype(int)}).dropna()
    df["b"] = pd.qcut(df["x"], min(bins, df["x"].nunique()), duplicates="drop")
    g = df.groupby("b", observed=True)["y"].agg(["sum", "count"])
    malos, buenos = g["sum"], g["count"] - g["sum"]
    p_mal = (malos / malos.sum()).replace(0, 1e-6)
    p_bue = (buenos / buenos.sum()).replace(0, 1e-6)
    woe = np.log(p_bue / p_mal)
    iv = float(((p_bue - p_mal) * woe).sum())
    fuerza = ("nula" if iv < 0.02 else "debil" if iv < 0.1 else
              "media" if iv < 0.3 else "fuerte")
    return {"IV": round(iv, 4), "fuerza_predictiva": fuerza, "woe": woe.round(4).to_dict()}
```

### CR5 — Monotonicidad del WoE (relacion coherente con el riesgo)

**Sustentación.** El WoE debe ser monótono respecto del riesgo para que la relación variable-incumplimiento sea interpretable y estable; una relación no monótona sin explicación es un hallazgo de interpretabilidad.

**Código (Python).**

```python
# CR5 - Monotonicidad del WoE (relacion coherente con el riesgo)
def cr5_monotonicidad_woe(feature, y_evento, bins=10):
    woe = cr4_information_value(feature, y_evento, bins)["woe"]
    v = np.array(list(woe.values()))
    creciente = bool(np.all(np.diff(v) >= 0)); decreciente = bool(np.all(np.diff(v) <= 0))
    return {"monotono": creciente or decreciente,
            "n_cambios_signo": int(np.sum(np.diff(np.sign(np.diff(v))) != 0))}
```

### CR6 — Estabilidad del score (PSI entre desarrollo y produccion)

**Sustentación.** El PSI del score entre desarrollo y producción detecta si la población calificada se desplazó; un PSI ≥ 0.25 obliga a investigar recalibración o cambio de universo.

**Código (Python).**

```python
# CR6 - Estabilidad del score (PSI entre desarrollo y produccion)
def cr6_psi_score(score_base, score_actual, bins=10):
    b = pd.to_numeric(pd.Series(score_base), errors="coerce").dropna()
    a = pd.to_numeric(pd.Series(score_actual), errors="coerce").dropna()
    cortes = np.unique(np.quantile(b, np.linspace(0, 1, bins + 1)))
    cortes[0], cortes[-1] = -np.inf, np.inf
    e = np.histogram(b, cortes)[0] / len(b)
    ac = np.histogram(a, cortes)[0] / len(a)
    e, ac = np.where(e == 0, 1e-6, e), np.where(ac == 0, 1e-6, ac)
    psi = float(np.sum((ac - e) * np.log(ac / e)))
    return {"PSI": round(psi, 4),
            "estado": ("estable" if psi < 0.1 else "moderado" if psi < 0.25 else "significativo")}
```

### CR7 — Estabilidad de caracteristica (CSI) por variable de entrada

**Sustentación.** El CSI aplica el PSI a cada variable de entrada, localizando qué característica origina la inestabilidad del score antes de que se materialice en deterioro de desempeño.

**Código (Python).**

```python
# CR7 - Estabilidad de caracteristica (CSI) por variable de entrada
def cr7_csi(feature_base, feature_actual, bins=10):
    return {"CSI": cr6_psi_score(feature_base, feature_actual, bins)["PSI"]}
```

### CR8 — Calibracion: prueba de Hosmer-Lemeshow

**Sustentación.** La prueba de Hosmer-Lemeshow contrasta la calibración: si las PD estimadas por decil coinciden con las tasas observadas. Un p-valor bajo indica mala calibración global.

**Código (Python).**

```python
# CR8 - Calibracion: prueba de Hosmer-Lemeshow
def cr8_hosmer_lemeshow(pd_estimada, y_evento, g=10):
    df = pd.DataFrame({"p": np.asarray(pd_estimada, float),
                       "y": np.asarray(y_evento, int)}).sort_values("p")
    df["grupo"] = pd.qcut(df["p"].rank(method="first"), g, labels=False)
    agg = df.groupby("grupo").agg(obs=("y", "sum"), n=("y", "size"), pesp=("p", "mean"))
    esp = agg["n"] * agg["pesp"]
    hl = float((((agg["obs"] - esp) ** 2) / (esp * (1 - agg["pesp"]) + 1e-9)).sum())
    p_valor = float(1 - stats.chi2.cdf(hl, df=g - 2))
    return {"HL": round(hl, 3), "p_valor": round(p_valor, 4),
            "bien_calibrado_5pct": bool(p_valor >= 0.05)}
```

### CR9 — Prueba binomial por grado de rating (PD calibrada)

**Sustentación.** La prueba binomial por grado contrasta si la tasa de default observada en cada rating es compatible con la PD calibrada; detecta subestimación de PD grado a grado.

**Código (Python).**

```python
# CR9 - Prueba binomial por grado de rating (PD calibrada)
def cr9_binomial_por_grado(pd_grado, defaults, n_expuestos, alpha=0.05):
    out = []
    for pdg, d, n in zip(pd_grado, defaults, n_expuestos):
        p_val = stats.binomtest(int(d), int(n), float(pdg), alternative="greater").pvalue
        out.append({"PD": pdg, "n": n, "obs": d, "tasa_obs": round(d / n, 4),
                    "p_valor": round(float(p_val), 4), "subestima_PD": bool(p_val < alpha)})
    return pd.DataFrame(out)
```

### CR10 — Prueba de Jeffreys por grado (intervalo bayesiano de PD)

**Sustentación.** La prueba de Jeffreys construye un intervalo bayesiano de la PD por grado; si la PD calibrada cae fuera del intervalo, la calibración de ese grado es cuestionable.

**Código (Python).**

```python
# CR10 - Prueba de Jeffreys por grado (intervalo bayesiano de PD)
def cr10_jeffreys(defaults, n_expuestos, pd_grado, alpha=0.05):
    out = []
    for d, n, pdg in zip(defaults, n_expuestos, pd_grado):
        li = stats.beta.ppf(alpha, d + 0.5, n - d + 0.5)
        ls = stats.beta.ppf(1 - alpha, d + 0.5, n - d + 0.5)
        out.append({"PD": pdg, "LI": round(float(li), 4), "LS": round(float(ls), 4),
                    "PD_dentro_intervalo": bool(li <= pdg <= ls)})
    return pd.DataFrame(out)
```

### CR11 — Brier score (exactitud probabilistica global)

**Sustentación.** El Brier score es el error cuadrático medio de la probabilidad estimada; resume en una cifra la exactitud probabilística global del modelo de PD.

**Código (Python).**

```python
# CR11 - Brier score (exactitud probabilistica global)
def cr11_brier(pd_estimada, y_evento):
    p = np.asarray(pd_estimada, float); y = np.asarray(y_evento, int)
    return {"Brier": round(float(np.mean((p - y) ** 2)), 5)}
```

### CR12 — Curva de calibracion (esperado vs observado por bin)

**Sustentación.** La curva de calibración enfrenta la PD media contra la tasa observada por bin, mostrando visualmente el sesgo de calibración (subestimación o sobreestimación) por tramo de riesgo.

**Código (Python).**

```python
# CR12 - Curva de calibracion (esperado vs observado por bin)
def cr12_curva_calibracion(pd_estimada, y_evento, bins=10):
    df = pd.DataFrame({"p": np.asarray(pd_estimada, float), "y": np.asarray(y_evento, int)})
    df["b"] = pd.qcut(df["p"].rank(method="first"), bins, labels=False)
    tabla = df.groupby("b").agg(pd_media=("p", "mean"), tasa_obs=("y", "mean"), n=("y", "size"))
    tabla["desvio"] = (tabla["tasa_obs"] - tabla["pd_media"]).round(4)
    return tabla.round(4)
```

### CR13 — Concentracion de grados (indice de Herfindahl-Hirschman)

**Sustentación.** El índice de Herfindahl mide la concentración de la cartera en pocos grados; una concentración alta reduce la capacidad discriminante efectiva de la escala de rating.

**Código (Python).**

```python
# CR13 - Concentracion de grados (indice de Herfindahl-Hirschman)
def cr13_herfindahl(grados):
    s = pd.Series(grados).value_counts(normalize=True)
    hhi = float((s ** 2).sum())
    return {"HHI": round(hhi, 4), "concentrado_>0.18": bool(hhi > 0.18)}
```

### CR14 — Monotonicidad de la PD entre grados (grado peor => PD mayor)

**Sustentación.** La PD debe crecer monótonamente al empeorar el grado; una inversión rompe el ordenamiento de riesgo de la escala y es un hallazgo de diseño de la calificación.

**Código (Python).**

```python
# CR14 - Monotonicidad de la PD entre grados (grado peor => PD mayor)
def cr14_monotonia_pd(pd_por_grado_ordenado):
    v = np.asarray(pd_por_grado_ordenado, float)
    return {"monotona_creciente": bool(np.all(np.diff(v) >= -1e-9)),
            "n_inversiones": int(np.sum(np.diff(v) < 0))}
```

### CR15 — Matriz de transicion (migracion de ratings)

**Sustentación.** La matriz de transición describe la migración de ratings entre dos fechas; es insumo de la PD lifetime (IFRS 9) y del análisis de estabilidad de la calificación.

**Código (Python).**

```python
# CR15 - Matriz de transicion (migracion de ratings)
def cr15_matriz_transicion(rating_ini, rating_fin, grados):
    m = pd.crosstab(pd.Categorical(rating_ini, grados),
                    pd.Categorical(rating_fin, grados), normalize="index")
    return m.reindex(index=grados, columns=grados).fillna(0).round(4)
```

### CR16 — Estabilidad de la matriz de transicion (norma de la diferencia)

**Sustentación.** La estabilidad de la matriz de transición se mide por la norma de su diferencia entre periodos; un cambio grande señala inestabilidad del sistema de rating o cambio de ciclo.

**Código (Python).**

```python
# CR16 - Estabilidad de la matriz de transicion (norma de la diferencia)
def cr16_estabilidad_matriz(m1, m2):
    d = np.asarray(m1, float) - np.asarray(m2, float)
    return {"norma_frobenius": round(float(np.sqrt((d ** 2).sum())), 4),
            "desvio_max_celda": round(float(np.abs(d).max()), 4)}
```

### CR17 — LGD: rango [0,1], tasa de cura y LGD downturn

**Sustentación.** La LGD debe estar en [0,1]; se controlan además la tasa de cura (defaults que se regularizan) y la LGD downturn (percentil alto), exigida para provisiones y capital en recesión.

**Código (Python).**

```python
# CR17 - LGD: rango [0,1], tasa de cura y LGD downturn
def cr17_lgd(lgd, es_default_resuelto=None, downturn_pctl=0.9):
    l = pd.to_numeric(pd.Series(lgd), errors="coerce").dropna()
    r = {"n_fuera_0_1": int(((l < 0) | (l > 1)).sum()),
         "lgd_media": round(float(l.mean()), 4),
         "lgd_downturn": round(float(l.quantile(downturn_pctl)), 4)}
    if es_default_resuelto is not None:
        cura = 1 - np.asarray(es_default_resuelto, int).mean()
        r["tasa_cura"] = round(float(cura), 4)
    return r
```

### CR18 — EAD / factor de conversion (CCF) dentro de rango

**Sustentación.** El factor de conversión de crédito (CCF) traduce la línea no dispuesta en exposición al default (EAD); debe permanecer en un rango razonable y calibrarse con datos propios.

**Código (Python).**

```python
# CR18 - EAD / factor de conversion (CCF) dentro de rango
def cr18_ccf(saldo_dispuesto, linea_no_dispuesta, ead_observado):
    d = np.asarray(saldo_dispuesto, float); nu = np.asarray(linea_no_dispuesta, float)
    ead = np.asarray(ead_observado, float)
    ccf = np.where(nu > 0, (ead - d) / nu, np.nan)
    return {"ccf_medio": round(float(np.nanmean(ccf)), 4),
            "n_ccf_fuera_0_1": int(np.nansum((ccf < 0) | (ccf > 1)))}
```

### CR19 — ECL = PD * LGD * EAD por etapa (staging IFRS 9)

**Sustentación.** El ECL de IFRS 9 es PD·LGD·EAD descontado, con PD a 12 meses en Stage 1 y lifetime en Stages 2 y 3; el control verifica el cálculo y su descomposición por etapa.

**Código (Python).**

```python
# CR19 - ECL = PD * LGD * EAD por etapa (staging IFRS 9)
def cr19_ecl(pd12, pd_lifetime, lgd, ead, stage, factor_desc=1.0):
    pd_usar = np.where(np.asarray(stage) == 1, pd12, pd_lifetime)
    ecl = pd_usar * np.asarray(lgd, float) * np.asarray(ead, float) * factor_desc
    return {"ECL_total": round(float(np.sum(ecl)), 2),
            "ECL_por_stage": {int(s): round(float(ecl[np.asarray(stage) == s].sum()), 2)
                              for s in np.unique(stage)}}
```

### CR20 — Disparador de SICR (aumento relativo de PD lifetime)

**Sustentación.** El disparador de SICR (aumento significativo del riesgo) mueve una exposición de Stage 1 a Stage 2; su umbral —relativo o absoluto sobre la PD lifetime— es objeto central de validación.

**Código (Python).**

```python
# CR20 - Disparador de SICR (aumento relativo de PD lifetime)
def cr20_sicr(pd_lifetime_origen, pd_lifetime_actual, umbral_relativo=2.0, umbral_abs=0.0):
    o = np.asarray(pd_lifetime_origen, float); a = np.asarray(pd_lifetime_actual, float)
    ratio = np.where(o > 0, a / o, np.inf)
    sicr = (ratio >= umbral_relativo) | ((a - o) >= umbral_abs) if umbral_abs > 0 else (ratio >= umbral_relativo)
    return {"n_sicr": int(sicr.sum()), "pct_sicr": round(float(sicr.mean()), 4)}
```

### CR21 — Backtesting de la tasa de default (observada vs predicha)

**Sustentación.** El backtesting de la tasa de default enfrenta la PD media predicha contra la observada mediante un intervalo binomial; una observación fuera del intervalo cuestiona la calibración del pool.

**Código (Python).**

```python
# CR21 - Backtesting de la tasa de default (observada vs predicha)
def cr21_backtest_default(pd_media_predicha, defaults, n):
    p = float(pd_media_predicha); tasa = defaults / n
    ic = stats.binom.interval(0.95, n, p)
    dentro = ic[0] <= defaults <= ic[1]
    return {"PD_predicha": round(p, 4), "tasa_observada": round(float(tasa), 4),
            "IC95": (int(ic[0]), int(ic[1])), "dentro_IC": bool(dentro)}
```

### CR22 — Analisis de cosechas (vintage): tasa de default por antiguedad

**Sustentación.** El análisis de cosechas (vintage) muestra cómo evoluciona la tasa de default por antigüedad de cada cohorte; detecta deterioro de originación y sustenta la PD lifetime.

**Código (Python).**

```python
# CR22 - Analisis de cosechas (vintage): tasa de default por antiguedad
def cr22_vintage(df, col_cosecha, col_antiguedad, col_default):
    tab = df.pivot_table(index=col_cosecha, columns=col_antiguedad,
                         values=col_default, aggfunc="mean")
    return tab.round(4)
```

### CR23 — Tasa de anulaciones manuales (override rate)

**Sustentación.** La tasa de anulaciones manuales (override) sobre las decisiones del modelo indica cuánto confía la gestión en el modelo; una tasa alta señala un modelo poco usado o mal calibrado.

**Código (Python).**

```python
# CR23 - Tasa de anulaciones manuales (override rate)
def cr23_override(decisiones_modelo, decisiones_finales):
    dm = np.asarray(decisiones_modelo); dfz = np.asarray(decisiones_finales)
    tasa = float(np.mean(dm != dfz))
    return {"override_rate": round(tasa, 4), "alerta_>0.05": bool(tasa > 0.05)}
```

### CR24 — Representatividad de la muestra de desarrollo vs poblacion actual

**Sustentación.** La representatividad contrasta (vía PSI) la muestra de desarrollo contra la población actual; una divergencia grande invalida la extrapolación del modelo a la cartera vigente.

**Código (Python).**

```python
# CR24 - Representatividad de la muestra de desarrollo vs poblacion actual
def cr24_representatividad(feature_desarrollo, feature_poblacion, bins=10):
    return {"PSI_muestra_vs_poblacion":
            cr6_psi_score(feature_desarrollo, feature_poblacion, bins)["PSI"]}
```

### CR25 — Estabilidad fuera de tiempo (AUC desarrollo vs fuera de muestra temporal)

**Sustentación.** La estabilidad fuera de tiempo compara el AUC en desarrollo contra una ventana temporal posterior (out-of-time); una caída material evidencia sobreajuste o cambio de régimen.

**Código (Python).**

```python
# CR25 - Estabilidad fuera de tiempo (AUC desarrollo vs fuera de muestra temporal)
def cr25_auc_oot(y_dev, score_dev, y_oot, score_oot, caida_max=0.05):
    a_dev, a_oot = _auc(y_dev, score_dev), _auc(y_oot, score_oot)
    return {"AUC_desarrollo": round(a_dev, 4), "AUC_OOT": round(a_oot, 4),
            "caida": round(a_dev - a_oot, 4),
            "deterioro_material": bool((a_dev - a_oot) > caida_max)}
```


---
*Todo el código fue ejecutado con datos sintéticos antes de la entrega.*
