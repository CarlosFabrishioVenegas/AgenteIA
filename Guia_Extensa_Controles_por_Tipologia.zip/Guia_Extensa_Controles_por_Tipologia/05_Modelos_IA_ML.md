# Modelos de Inteligencia Artificial y Machine Learning

**Sobreajuste, interpretabilidad, fuga de información, equidad y deriva**

Guía Extensa de Controles por Tipología — VIRF · Versión 1.0 · 2026-09-05


---

> **Documento de conocimiento cuantitativo — VIRF.** Cada control incluye su sustentación técnica y código Python **probado** (numpy / scipy / sklearn). Los umbrales son convenciones de industria que se calibran y aprueban en la política interna de validación. El marco de validación, seguimiento y backtesting se alinea con la Res. SBS N° 00053-2023; en riesgo de mercado con la Res. SBS N° 4906-2017 y con FRTB para PLA/ES.


---

## Introducción

Controles específicos para modelos construidos con técnicas de IA/ML, exigidos por la Res. SBS N° 00053-2023 (Art. 16.2 y 22.1.j): sobreajuste, estabilidad por validación cruzada, interpretabilidad por importancia de variables, detección de fuga de información, equidad por grupo y deriva de datos y de predicción.

**Imports comunes del módulo ejecutable:**

```python
# -*- coding: utf-8 -*-
"""Controles adicionales por tipología: riesgo operacional (LDA), modelos de
IA/ML, conductuales extendidos y controles metodológicos transversales."""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import rankdata


def _auc(y, s):
    y = np.asarray(y).astype(int); s = np.asarray(s, float)
    n1, n0 = int(y.sum()), int((y == 0).sum())
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s)
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


# ================= RIESGO OPERACIONAL =================
```


---

## Catálogo de controles (6)

### ML1 — Sobreajuste: brecha de desempeño entre entrenamiento y prueba

**Sustentación.** La brecha de AUC entre entrenamiento y prueba mide el sobreajuste; una brecha grande indica que el modelo memorizó la muestra y no generalizará, exigido su control por la Res. SBS 00053-2023 (Art. 16.2).

**Código (Python).**

```python
# ML1 - Sobreajuste: brecha de desempeño entre entrenamiento y prueba
def ml1_sobreajuste(y_train, score_train, y_test, score_test, brecha_max=0.05):
    a_tr, a_te = _auc(y_train, score_train), _auc(y_test, score_test)
    return {"AUC_train": round(a_tr, 4), "AUC_test": round(a_te, 4),
            "brecha": round(a_tr - a_te, 4), "sobreajuste": bool((a_tr - a_te) > brecha_max)}
```

### ML2 — Estabilidad por validación cruzada (desviación del desempeño)

**Sustentación.** La desviación del desempeño entre folds de validación cruzada mide la estabilidad del modelo; una desviación alta señala un modelo sensible a la partición de datos.

**Código (Python).**

```python
# ML2 - Estabilidad por validación cruzada (desviación del desempeño)
def ml2_estabilidad_cv(aucs_folds, cv_max=0.03):
    a = np.asarray(aucs_folds, float)
    return {"AUC_media": round(float(a.mean()), 4), "AUC_desv": round(float(a.std()), 4),
            "inestable": bool(a.std() > cv_max)}
```

### ML3 — Importancia de variables (permutación) para interpretabilidad

**Sustentación.** La importancia por permutación mide cuánto cae el desempeño al aleatorizar cada variable; aporta interpretabilidad al modelo (Art. 16.2 del reglamento SBS) sin depender de su forma funcional.

**Código (Python).**

```python
# ML3 - Importancia de variables (permutación) para interpretabilidad
def ml3_importancia_permutacion(func_predict, X, y, metrica=_auc, semilla=42, cols=None):
    rng = np.random.default_rng(semilla)
    X = pd.DataFrame(X).copy()
    base = metrica(y, func_predict(X))
    cols = cols or list(X.columns)
    imp = {}
    for c in cols:
        Xp = X.copy(); Xp[c] = rng.permutation(Xp[c].values)
        imp[c] = round(float(base - metrica(y, func_predict(Xp))), 4)
    return dict(sorted(imp.items(), key=lambda kv: -kv[1]))
```

### ML4 — Detección de fuga de información (predictor sospechosamente perfecto)

**Sustentación.** La detección de fuga de información busca variables con poder predictivo sospechosamente perfecto, señal de que contienen información posterior al momento de decisión y no serán replicables.

**Código (Python).**

```python
# ML4 - Detección de fuga de información (predictor sospechosamente perfecto)
def ml4_fuga_informacion(X, y, umbral_auc=0.95):
    X = pd.DataFrame(X)
    sospechosas = {}
    for c in X.columns:
        s = pd.to_numeric(X[c], errors="coerce")
        if s.notna().sum() < 10:
            continue
        a = _auc(y[s.notna()], s.dropna())
        if a is not None and not np.isnan(a) and max(a, 1 - a) > umbral_auc:
            sospechosas[c] = round(max(a, 1 - a), 4)
    return {"variables_sospechosas": sospechosas,
            "hay_posible_fuga": bool(len(sospechosas) > 0)}
```

### ML5 — Equidad / sesgo: ratio de impacto dispar por grupo

**Sustentación.** El control de equidad compara la tasa de decisión positiva por grupo; un disparate impact ratio menor a 0.8 alerta sobre un posible sesgo del modelo hacia un grupo.

**Código (Python).**

```python
# ML5 - Equidad / sesgo: ratio de impacto dispar por grupo
def ml5_equidad(y_pred_positivo, grupo):
    df = pd.DataFrame({"p": np.asarray(y_pred_positivo, int), "g": np.asarray(grupo)})
    tasas = df.groupby("g")["p"].mean()
    dir_ratio = float(tasas.min() / tasas.max()) if tasas.max() > 0 else None
    return {"tasa_aprobacion_por_grupo": tasas.round(4).to_dict(),
            "disparate_impact_ratio": round(dir_ratio, 4) if dir_ratio else None,
            "alerta_<0.8": bool(dir_ratio is not None and dir_ratio < 0.8)}
```

### ML6 — Deriva de datos y de predicción (PSI sobre features y score)

**Sustentación.** La deriva de datos y de predicción (PSI sobre features y score) detecta que la población o las predicciones se alejaron del desarrollo, disparando el seguimiento del modelo.

**Código (Python).**

```python
# ML6 - Deriva de datos y de predicción (PSI sobre features y score)
def ml6_deriva(X_base, X_actual, score_base=None, score_actual=None, bins=10):
    def psi(b, a):
        b = pd.to_numeric(pd.Series(b), errors="coerce").dropna()
        a = pd.to_numeric(pd.Series(a), errors="coerce").dropna()
        cortes = np.unique(np.quantile(b, np.linspace(0, 1, bins + 1)))
        if len(cortes) < 3:
            return None
        cortes[0], cortes[-1] = -np.inf, np.inf
        e = np.histogram(b, cortes)[0] / len(b); ac = np.histogram(a, cortes)[0] / len(a)
        e, ac = np.where(e == 0, 1e-6, e), np.where(ac == 0, 1e-6, ac)
        return float(np.sum((ac - e) * np.log(ac / e)))
    Xb, Xa = pd.DataFrame(X_base), pd.DataFrame(X_actual)
    psi_feats = {c: round(psi(Xb[c], Xa[c]), 4) for c in Xb.columns if psi(Xb[c], Xa[c]) is not None}
    r = {"psi_features": psi_feats, "n_features_derivadas": int(sum(v > 0.25 for v in psi_feats.values()))}
    if score_base is not None:
        r["psi_score"] = round(psi(score_base, score_actual), 4)
    return r


# ================= CONDUCTUALES EXTENDIDOS =================
```


---
*Todo el código fue ejecutado con datos sintéticos antes de la entrega.*
