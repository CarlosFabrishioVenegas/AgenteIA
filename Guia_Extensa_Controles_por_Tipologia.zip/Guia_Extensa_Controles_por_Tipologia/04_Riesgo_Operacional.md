# Riesgo Operacional

**Completitud de pérdidas, ajuste de severidad y capital por LDA**

Guía Extensa de Controles por Tipología — VIRF · Versión 1.0 · 2026-09-05


---

> **Documento de conocimiento cuantitativo — VIRF.** Cada control incluye su sustentación técnica y código Python **probado** (numpy / scipy / sklearn). Los umbrales son convenciones de industria que se calibran y aprueban en la política interna de validación. El marco de validación, seguimiento y backtesting se alinea con la Res. SBS N° 00053-2023; en riesgo de mercado con la Res. SBS N° 4906-2017 y con FRTB para PLA/ES.


---

## Introducción

Controles para modelos de riesgo operacional: completitud de la base de pérdidas, bondad de ajuste de la distribución de severidad, cálculo de capital por el enfoque de distribución de pérdidas (LDA) y estabilidad de la frecuencia de eventos.

**Imports comunes del módulo ejecutable:**

```python
# -*- coding: utf-8 -*-
"""Controles adicionales por tipología: riesgo operacional (LDA), modelos de
IA/ML, conductuales extendidos y controles metodológicos transversales."""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import rankdata


def _auc(y, s):
    y = np.asarray(y).astype(int); s = np.asarray(s, float)
    n1, n0 = int(y.sum()), int((y == 0).sum())
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s)
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


# ================= RIESGO OPERACIONAL =================
```


---

## Catálogo de controles (4)

### O1 — Completitud de la base de pérdidas por umbral de recolección

**Sustentación.** La base de pérdidas operacionales debe capturar todos los eventos por encima del umbral de recolección; eventos por debajo o faltantes sesgan la severidad y subestiman el capital.

**Código (Python).**

```python
# O1 - Completitud de la base de pérdidas por umbral de recolección
def o1_completitud_perdidas(montos, umbral_recoleccion):
    m = pd.to_numeric(pd.Series(montos), errors="coerce").dropna()
    bajo = int((m < umbral_recoleccion).sum())
    return {"n_eventos": len(m), "n_bajo_umbral": bajo,
            "posible_subregistro": bool(bajo > 0)}
```

### O2 — Ajuste de severidad: bondad de ajuste (Kolmogorov-Smirnov y Anderson-Darling)

**Sustentación.** El ajuste de la distribución de severidad (lognormal u otra) debe superar pruebas de bondad de ajuste (KS, Anderson-Darling); un mal ajuste invalida el cálculo de capital por LDA.

**Código (Python).**

```python
# O2 - Ajuste de severidad: bondad de ajuste (Kolmogorov-Smirnov y Anderson-Darling)
def o2_bondad_ajuste_severidad(montos, dist="lognorm"):
    m = pd.to_numeric(pd.Series(montos), errors="coerce").dropna().values
    d = getattr(stats, dist)
    par = d.fit(m)
    ks = stats.kstest(m, dist, args=par)
    return {"dist": dist, "params": [round(float(p), 4) for p in par],
            "KS_stat": round(float(ks.statistic), 4), "KS_pvalue": round(float(ks.pvalue), 4),
            "ajuste_aceptable_5pct": bool(ks.pvalue >= 0.05)}
```

### O3 — Capital operacional por LDA (agregación frecuencia-severidad Monte Carlo)

**Sustentación.** El enfoque de distribución de pérdidas (LDA) agrega frecuencia (Poisson) y severidad (lognormal) por Monte Carlo; el capital es el VaR al 99.9% de la pérdida agregada anual.

**Código (Python).**

```python
# O3 - Capital operacional por LDA (agregación frecuencia-severidad Monte Carlo)
def o3_lda_capital(lambda_frec, sev_media_log, sev_desv_log, alpha=0.999, n=200000, semilla=42):
    """Distribución de pérdida agregada: N ~ Poisson(lambda), severidad ~ lognormal.
    Capital = VaR al 99.9% de la pérdida agregada anual."""
    rng = np.random.default_rng(semilla)
    freq = rng.poisson(lambda_frec, n)
    perdida = np.array([np.sum(rng.lognormal(sev_media_log, sev_desv_log, k)) if k else 0.0
                        for k in freq])
    return {"capital_VaR_99.9": round(float(np.quantile(perdida, alpha)), 2),
            "perdida_esperada": round(float(perdida.mean()), 2)}
```

### O4 — Estabilidad de la frecuencia de eventos (control de tendencia)

**Sustentación.** La estabilidad de la frecuencia de eventos detecta tendencias o quiebres en el registro; un aumento sostenido puede reflejar deterioro del control o mejora del reporte.

**Código (Python).**

```python
# O4 - Estabilidad de la frecuencia de eventos (control de tendencia)
def o4_estabilidad_frecuencia(conteos_por_periodo):
    c = np.asarray(conteos_por_periodo, float)
    t = np.arange(len(c))
    if len(c) < 3:
        return {"tendencia": None}
    b = np.polyfit(t, c, 1)[0]
    return {"pendiente_tendencia": round(float(b), 4),
            "media": round(float(c.mean()), 2), "cv": round(float(c.std() / (c.mean() + 1e-9)), 3)}


# ================= MODELOS DE IA / ML =================
```


---
*Todo el código fue ejecutado con datos sintéticos antes de la entrega.*
