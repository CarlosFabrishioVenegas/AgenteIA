# Guía Extensa de Controles de Validación por Tipología — VIRF

Catálogo cuantitativo completo para la validación de modelos, organizado por
tipología de riesgo. Cada control trae **nombre, sustentación y código Python
probado**. Junto con los cinco documentos base (calidad de datos de mercado,
VaR, ALM conductual, curvas de supervivencia y LaR), la biblioteca cubre
**159 controles**.

## Esta guía extensa (100 controles nuevos)

| Documento | Controles | Tipología |
|---|---|---|
| 01 Riesgo de Crédito e IFRS 9 | 25 | AUC/Gini/KS, IV/WoE, PSI/CSI, Hosmer-Lemeshow, binomial/Jeffreys, HHI, transición, LGD/EAD/CCF, ECL, SICR, backtesting, vintage, OOT |
| 02 Riesgo de Mercado — valuación | 12 | PLA (Spearman/KS de FRTB), sensibilidades, Taylor vs full reval, SVaR, IPV, AVA, covarianza PD, Ljung-Box |
| 03 IRRBB y ALM | 8 | Gap de repreciación, ΔEVE, seis escenarios de Basilea, ΔNII, beta de depósitos, duración efectiva, outlier test |
| 04 Riesgo Operacional | 4 | Completitud de pérdidas, bondad de ajuste de severidad, capital LDA, estabilidad de frecuencia |
| 05 Modelos de IA / ML | 6 | Sobreajuste, validación cruzada, importancia por permutación, fuga de información, equidad, deriva |
| 06 Conductual + Metodología | 8 | Backtesting de prepago, log-rank, estacionalidad, reproducibilidad, reconciliación, sensibilidad, benchmarking, réplica |
| 07 VaR extendido y Mark-to-Market | 20 | MtM lineal y de renta fija, precio sucio, P&L limpio/hipotético, revaluación completa, positividad y signo del VaR, monotonicidad, diversificación, VaR componente/marginal/incremental, error MC, delta-normal vs full reval |
| 08 ALM — maduración, resultados y seguimiento | 17 | Maduración (WAL), maturity ladder, topes IRRBB, resultados (rango, reconciliación, estabilidad, backtesting), seguimiento (FTP, PSI del output, Kupiec y Christoffersen del at-risk, semáforo, tablero) |

## Documentos base complementarios (59 controles)

| Documento | Controles |
|---|---|
| Calidad de datos — riesgo de mercado | 22 |
| Value at Risk y Expected Shortfall | 12 |
| ALM conductual — maduración y SMM | 9 |
| Curvas de supervivencia | 8 |
| Liquidity at Risk (LaR) | 8 |

## Uso del código

```bash
cd codigo_ejecutable
pip install pandas numpy scipy scikit-learn
python -c "import credito_ifrs9, mercado_valuacion, irrbb_alm, tipologias_ext; print('módulos OK')"
```

**Nota.** Los umbrales (AUC 0.7, Gini 0.4–0.6, PSI 0.10/0.25, Spearman 0.80 y KS
0.09 de FRTB, disparate impact 0.8, outlier test 15%) son convenciones o
referencias regulatorias que la política interna calibra. Donde una técnica
admite variantes (definición de CCF, umbral de SICR, escenarios exactos de
Basilea), se implementó la forma estándar y se deja parametrizable.
