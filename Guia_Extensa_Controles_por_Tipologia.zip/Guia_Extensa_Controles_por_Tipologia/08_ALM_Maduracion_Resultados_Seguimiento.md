# ALM — Maduración, validación de resultados y seguimiento

**Maturity, controles sobre los resultados y monitoreo continuo (FTP, PSI, Kupiec, Christoffersen)**

Guía Extensa de Controles por Tipología — VIRF · Versión 1.0 · 2026-09-06


---

> **Documento de conocimiento cuantitativo — VIRF.** Cada control incluye su sustentación y código Python **probado**. Complementa el documento de ALM conductual (maduración, SMM) y el de IRRBB. El seguimiento (monitoreo continuo) se alinea con la Res. SBS N° 00053-2023 (Art. 20-22: validación periódica, seguimiento, backtesting) y con SR 11-7 (ongoing monitoring y outcomes analysis).


---

## Introducción

Este documento cubre tres frentes del ALM que se solicitan de forma específica. Primero, la **maduración (maturity)**: la vida media conductual, la escalera de vencimientos, los topes regulatorios y la consistencia frente al vencimiento contractual. Segundo, los **controles sobre los resultados**: rango razonable, reconciliación, estabilidad y backtesting del resultado proyectado contra el realizado. Tercero, el **seguimiento (monitoreo continuo)**, que verifica que el resultado sea consistente: el impacto de la maduración en la **tasa de transferencia (FTP)** y en el margen, el **PSI** del output en el tiempo, y el backtesting de **Kupiec** y **Christoffersen** aplicados a la medida at-risk del ALM (NII-at-risk / EVE-at-risk), con su semáforo de excepciones y un tablero de indicadores.

**Imports comunes:**

```python
# -*- coding: utf-8 -*-
"""Controles de ALM: maduración (maturity), validación de resultados y
seguimiento (monitoreo continuo). Incluye impacto en la tasa de transferencia
(FTP), PSI de los resultados y backtesting de Kupiec y Christoffersen aplicados
a las medidas at-risk del ALM. Probado con numpy / scipy."""
import numpy as np
import pandas as pd
from scipy import stats


# ============================ MADURACIÓN (maturity) ============================
```


---

## Maduración / maturity (5 controles)

### AM1 — Vida media conductual (WAL): la maduración efectiva del producto

**Sustentación.** La maduración conductual es la vida media ponderada por los flujos de runoff (WAL): el vencimiento efectivo que el ALM asigna a un producto sin vencimiento contractual fijo. Es el resultado central del modelo conductual.

**Código (Python).**

```python
# AM1 - Vida media conductual (WAL): la maduración efectiva del producto
def am1_maduracion(flujos, plazos_meses):
    """Vida media ponderada por los flujos: WAL = sum(t*flujo)/sum(flujo), en
    meses. Es la 'maduración' conductual de un producto sin vencimiento fijo."""
    t = np.asarray(plazos_meses, float); f = np.asarray(flujos, float)
    if f.sum() == 0:
        return {"maduracion_meses": None}
    wal = float(np.sum(t * f) / np.sum(f))
    return {"maduracion_meses": round(wal, 2), "maduracion_anios": round(wal / 12, 2)}
```

### AM2 — Escalera de vencimientos (maturity ladder) por banda temporal

**Sustentación.** La escalera de vencimientos distribuye el saldo del producto en bandas temporales según su maduración conductual; es el insumo directo del gap de repreciación (IRRBB) y del gap de liquidez (LaR).

**Código (Python).**

```python
# AM2 - Escalera de vencimientos (maturity ladder) por banda temporal
def am2_maturity_ladder(saldos, plazos_meses, bandas=(1, 3, 6, 12, 24, 60, np.inf)):
    """Distribuye el saldo del producto en las bandas temporales de vencimiento
    conductual. Es el insumo del gap de repreciación y de liquidez."""
    t = np.asarray(plazos_meses, float); s = np.asarray(saldos, float)
    etiquetas = []
    prev = 0
    for b in bandas:
        etiquetas.append(f"<= {b}m" if np.isfinite(b) else f"> {prev}m")
        prev = b
    idx = np.searchsorted(bandas, t, side="left")
    tabla = pd.Series(0.0, index=etiquetas)
    for i, sval in zip(idx, s):
        tabla.iloc[min(i, len(etiquetas) - 1)] += sval
    return tabla.round(2)
```

### AM3 — Control de tope regulatorio de maduración de NMD (IRRBB)

**Sustentación.** El marco IRRBB estándar limita la maduración media de los depósitos sin vencimiento y la proporción tratada como núcleo (topes por segmento; valores por confirmar contra el texto de Basilea). Un supuesto que exceda el tope alarga artificialmente el vencimiento y reduce el riesgo de tasa medido.

**Código (Python).**

```python
# AM3 - Control de tope regulatorio de maduración de NMD (IRRBB)
def am3_tope_maduracion(maduracion_anios, cap_anios=5.0, core_pct=None, cap_core=0.90):
    """El marco IRRBB estándar limita la maduración media de los depósitos sin
    vencimiento (cap típico ~5 años para retail transaccional; valores por
    confirmar) y la proporción tratada como núcleo. Excederlos es hallazgo."""
    r = {"maduracion_anios": round(float(maduracion_anios), 2),
         "excede_cap_maturity": bool(maduracion_anios > cap_anios)}
    if core_pct is not None:
        r["core_pct"] = round(float(core_pct), 4)
        r["excede_cap_core"] = bool(core_pct > cap_core)
    return r
```

### AM4 — Consistencia maduración conductual vs contractual

**Sustentación.** La maduración conductual no debe exceder un múltiplo razonable de la contractual; un supuesto que la alargue en exceso, sin sustento en el comportamiento observado, es un hallazgo de metodología.

**Código (Python).**

```python
# AM4 - Consistencia maduración conductual vs contractual
def am4_conductual_vs_contractual(mad_conductual, mad_contractual, mult_max=3.0):
    """La maduración conductual no debe exceder un múltiplo razonable de la
    contractual (evita supuestos que alarguen artificialmente el vencimiento y
    reduzcan el riesgo de tasa medido)."""
    mc, mk = float(mad_conductual), float(mad_contractual)
    ratio = mc / mk if mk > 0 else np.inf
    return {"ratio_conductual_contractual": round(float(ratio), 2),
            "excede_multiplo": bool(ratio > mult_max)}
```

### AM5 — Duración conductual vs duración contractual (gap de duración)

**Sustentación.** El gap entre la duración conductual y la contractual cuantifica cuánto extiende el modelo la sensibilidad de tasa del producto; es un indicador de la agresividad del supuesto conductual.

**Código (Python).**

```python
# AM5 - Duración conductual vs duración contractual (gap de duración)
def am5_gap_duracion(dur_conductual, dur_contractual):
    return {"gap_duracion": round(float(dur_conductual) - float(dur_contractual), 3)}


# ======================= CONTROLES SOBRE LOS RESULTADOS =======================
```


## Controles sobre los resultados (4 controles)

### AM6 — Rango razonable del resultado (EVE / NII) vs periodo anterior

**Sustentación.** Un salto del resultado (EVE o NII) entre periodos mayor al esperado, sin un cambio de posición o de mercado que lo justifique, es un hallazgo: el resultado debe moverse por causas trazables.

**Código (Python).**

```python
# AM6 - Rango razonable del resultado (EVE / NII) vs periodo anterior
def am6_rango_resultado(resultado_actual, resultado_anterior, var_max_rel=0.30):
    """Un salto del resultado (EVE o NII) mayor al esperado entre periodos, sin
    cambio de posición o de mercado que lo justifique, es un hallazgo."""
    ra, rp = float(resultado_actual), float(resultado_anterior)
    var_rel = abs(ra - rp) / abs(rp) if rp != 0 else np.inf
    return {"variacion_relativa": round(float(var_rel), 4),
            "salto_no_esperado": bool(var_rel > var_max_rel)}
```

### AM7 — Reconciliación del resultado (suma de componentes = total)

**Sustentación.** El resultado total debe reconciliar con la suma de sus componentes (por producto, por banda, por factor); una diferencia no explicada indica un error de agregación o de cálculo.

**Código (Python).**

```python
# AM7 - Reconciliación del resultado (suma de componentes = total)
def am7_reconciliacion_resultado(componentes, total, atol=1.0):
    suma = float(np.sum(componentes))
    return {"suma_componentes": round(suma, 2), "total_reportado": round(float(total), 2),
            "reconcilia": bool(abs(suma - total) <= atol)}
```

### AM8 — Estabilidad del resultado en el tiempo (volatilidad intermensual)

**Sustentación.** La estabilidad del resultado en el tiempo (coeficiente de variación acotado) detecta saltos anómalos; un resultado excesivamente volátil sin causa señala inestabilidad del modelo o de los datos.

**Código (Python).**

```python
# AM8 - Estabilidad del resultado en el tiempo (volatilidad intermensual)
def am8_estabilidad_resultado(serie_resultado, cv_max=0.25):
    s = pd.Series(serie_resultado, dtype=float).dropna()
    cv = float(s.std() / abs(s.mean())) if s.mean() != 0 else np.inf
    return {"media": round(float(s.mean()), 2), "cv": round(cv, 4),
            "inestable": bool(cv > cv_max)}
```

### AM9 — Backtesting del resultado proyectado vs realizado (runoff / NII)

**Sustentación.** El backtesting del resultado enfrenta lo proyectado por el modelo (runoff, NII) contra lo realizado, midiendo sesgo y RMSE; es el análisis de resultados (outcomes analysis) exigido por el marco de validación.

**Código (Python).**

```python
# AM9 - Backtesting del resultado proyectado vs realizado (runoff / NII)
def am9_backtest_resultado(proyectado, realizado):
    """Contrasta el resultado proyectado por el modelo (por ejemplo el runoff o
    el NII) contra el efectivamente observado: error medio (sesgo) y RMSE."""
    p = np.asarray(proyectado, float); o = np.asarray(realizado, float)
    err = o - p
    return {"sesgo_medio": round(float(err.mean()), 4),
            "RMSE": round(float(np.sqrt(np.mean(err ** 2))), 4),
            "error_relativo_medio": round(float(np.mean(np.abs(err) / (np.abs(o) + 1e-9))), 4)}


# ============================ SEGUIMIENTO / MONITOREO ==========================
```


## Seguimiento / monitoreo continuo (8 controles)

### AM10 — Impacto en la tasa de transferencia (FTP) de la maduración conductual

**Sustentación.** La tasa de transferencia interna (FTP) de un producto se lee de la curva de transferencia al plazo de su maduración conductual. Así, la maduración determina la FTP y, por tanto, el margen que se asigna a la unidad captadora o colocadora.

**Código (Python).**

```python
# AM10 - Impacto en la tasa de transferencia (FTP) de la maduración conductual
def am10_ftp(curva_plazos_anios, curva_tasas, maduracion_anios):
    """La tasa de transferencia interna (FTP) de un producto se lee de la curva
    de transferencia al plazo de su maduración conductual. Un producto con mayor
    maduración recibe una FTP distinta, lo que afecta el margen de la unidad."""
    ftp = float(np.interp(maduracion_anios, curva_plazos_anios, curva_tasas))
    return {"maduracion_anios": round(float(maduracion_anios), 2),
            "tasa_transferencia_FTP": round(ftp, 5)}
```

### AM11 — Sensibilidad del FTP y del margen al supuesto de maduración

**Sustentación.** Este control cuantifica cómo un cambio en el supuesto de maduración (por ejemplo, por un cambio en el % núcleo) mueve la FTP y el margen anual del banco. Evidencia de forma directa cómo un supuesto conductual afecta el resultado y la tasa de transferencia.

**Código (Python).**

```python
# AM11 - Sensibilidad del FTP y del margen al supuesto de maduración
def am11_sensibilidad_ftp(curva_plazos, curva_tasas, mad_base, mad_shock, saldo):
    """Cuánto cambian la FTP y el margen anual cuando cambia el supuesto de
    maduración (por ejemplo, por un cambio en el % núcleo). Evidencia cómo un
    supuesto conductual mueve el resultado del banco."""
    ftp0 = float(np.interp(mad_base, curva_plazos, curva_tasas))
    ftp1 = float(np.interp(mad_shock, curva_plazos, curva_tasas))
    d_ftp = ftp1 - ftp0
    d_margen = d_ftp * float(saldo)
    return {"FTP_base": round(ftp0, 5), "FTP_shock": round(ftp1, 5),
            "delta_FTP_bps": round(d_ftp * 10000, 1),
            "delta_margen_anual": round(d_margen, 2)}
```

### AM12 — PSI del resultado / output del modelo en el tiempo

**Sustentación.** El PSI aplicado al output del modelo (perfil de runoff, SMM, maduración por cliente) entre dos periodos detecta si el resultado se desplazó; un PSI >= 0.25 dispara el seguimiento por inestabilidad del resultado.

**Código (Python).**

```python
# AM12 - PSI del resultado / output del modelo en el tiempo
def am12_psi_resultado(resultado_base, resultado_actual, bins=10):
    """Aplica el PSI a la distribución del output del modelo (por ejemplo el
    perfil de runoff, el SMM o la maduración por cliente) entre dos periodos.
    Un PSI >= 0.25 dispara el seguimiento por inestabilidad del resultado."""
    b = pd.to_numeric(pd.Series(resultado_base), errors="coerce").dropna()
    a = pd.to_numeric(pd.Series(resultado_actual), errors="coerce").dropna()
    cortes = np.unique(np.quantile(b, np.linspace(0, 1, bins + 1)))
    if len(cortes) < 3:
        return {"PSI": None}
    cortes[0], cortes[-1] = -np.inf, np.inf
    e = np.histogram(b, cortes)[0] / len(b); ac = np.histogram(a, cortes)[0] / len(a)
    e, ac = np.where(e == 0, 1e-6, e), np.where(ac == 0, 1e-6, ac)
    psi = float(np.sum((ac - e) * np.log(ac / e)))
    return {"PSI": round(psi, 4),
            "estado": ("estable" if psi < 0.1 else "moderado" if psi < 0.25 else "significativo")}


def _excepciones_alm(resultado_real, medida_at_risk):
    """Excepción = la pérdida real supera la medida at-risk proyectada.
    resultado_real: P&L (negativo = pérdida); medida_at_risk: pérdida positiva."""
    perdida = -np.asarray(resultado_real, float)
    ar = np.asarray(medida_at_risk, float)
    return (perdida > ar).astype(int)
```

### AM13 — Backtesting Kupiec del at-risk de ALM (EaR / NII-at-risk / EVE-at-risk)

**Sustentación.** El test de Kupiec aplicado a la medida at-risk del ALM (NII-at-risk / EVE-at-risk / Earnings-at-Risk) contrasta si el número de excepciones —periodos en que la pérdida real superó el at-risk proyectado— es compatible con el nivel de confianza. Es el backtesting de cobertura incondicional del seguimiento.

**Código (Python).**

```python
# AM13 - Backtesting Kupiec del at-risk de ALM (EaR / NII-at-risk / EVE-at-risk)
def am13_kupiec_alm(resultado_real, medida_at_risk, alpha=0.99):
    """Aplica el test de Kupiec (cobertura incondicional) a la medida at-risk del
    ALM: contrasta si el número de excepciones (días/meses en que la pérdida real
    superó el at-risk) es compatible con el nivel de confianza."""
    ind = _excepciones_alm(resultado_real, medida_at_risk)
    x, n, p = int(ind.sum()), len(ind), 1 - alpha
    if x == 0:
        lr = -2 * (n * np.log(1 - p))
    else:
        pi = x / n
        lr = -2 * (np.log((1 - p) ** (n - x) * p ** x) -
                   np.log((1 - pi) ** (n - x) * pi ** x))
    p_val = float(1 - stats.chi2.cdf(lr, df=1))
    return {"excepciones": x, "esperadas": round(n * p, 2),
            "LR_uc": round(float(lr), 3), "p_valor": round(p_val, 4),
            "rechaza_5pct": bool(p_val < 0.05), "indicador": ind.tolist()}
```

### AM14 — Backtesting Christoffersen del at-risk de ALM (cobertura condicional)

**Sustentación.** El test de Christoffersen añade la independencia: las excepciones del at-risk de ALM no deben agruparse en el tiempo. La cobertura condicional combina Kupiec e independencia y es la prueba completa de backtesting del resultado.

**Código (Python).**

```python
# AM14 - Backtesting Christoffersen del at-risk de ALM (cobertura condicional)
def am14_christoffersen_alm(resultado_real, medida_at_risk, alpha=0.99):
    """Añade la prueba de independencia (Christoffersen): las excepciones del
    at-risk de ALM no deben agruparse en el tiempo. Cobertura condicional =
    Kupiec + independencia."""
    ind = _excepciones_alm(resultado_real, medida_at_risk)
    n00 = n01 = n10 = n11 = 0
    for i in range(1, len(ind)):
        a, b = ind[i - 1], ind[i]
        n00 += (a == 0 and b == 0); n01 += (a == 0 and b == 1)
        n10 += (a == 1 and b == 0); n11 += (a == 1 and b == 1)
    pi01 = n01 / (n00 + n01) if (n00 + n01) else 0
    pi11 = n11 / (n10 + n11) if (n10 + n11) else 0
    pi = (n01 + n11) / max(n00 + n01 + n10 + n11, 1)

    def _ll(p, k, m):
        return 0.0 if p in (0, 1) else k * np.log(p) + m * np.log(1 - p)

    ll_ind = _ll(pi01, n01, n00) + _ll(pi11, n11, n10)
    ll_res = _ll(pi, n01 + n11, n00 + n10)
    lr_ind = -2 * (ll_res - ll_ind)
    lr_uc = am13_kupiec_alm(resultado_real, medida_at_risk, alpha)["LR_uc"]
    lr_cc = lr_uc + lr_ind
    return {"LR_ind": round(float(lr_ind), 3), "LR_cc": round(float(lr_cc), 3),
            "p_valor_cc": round(float(1 - stats.chi2.cdf(lr_cc, df=2)), 4),
            "rechaza_cc_5pct": bool((1 - stats.chi2.cdf(lr_cc, df=2)) < 0.05)}
```

### AM15 — Semáforo de excepciones del at-risk de ALM (250 observaciones, 99%)

**Sustentación.** El semáforo traduce el número de excepciones del at-risk de ALM (250 observaciones, 99%) en zonas verde/amarilla/roja, replicando la lógica del backtesting de mercado para el seguimiento del ALM.

**Código (Python).**

```python
# AM15 - Semáforo de excepciones del at-risk de ALM (250 observaciones, 99%)
def am15_semaforo_alm(excepciones):
    x = int(excepciones)
    zona = "verde" if x <= 4 else "amarilla" if x <= 9 else "roja"
    return {"excepciones": x, "zona": zona}
```

### AM16 — Coherencia resultado vs supuestos (el resultado se mueve con los inputs)

**Sustentación.** La coherencia verifica que los cambios del resultado se muevan de forma consistente con los cambios de los supuestos (correlación esperada y de signo correcto); una correlación baja o de signo inesperado señala que el modelo no responde como debería a sus inputs.

**Código (Python).**

```python
# AM16 - Coherencia resultado vs supuestos (el resultado se mueve con los inputs)
def am16_coherencia_resultado_supuestos(cambios_supuesto, cambios_resultado):
    """Verifica que los cambios del resultado sean coherentes con los cambios de
    los supuestos (por ejemplo, más maduración => mayor sensibilidad de valor).
    Una correlación baja o de signo inesperado señala inconsistencia del modelo."""
    rho, p = stats.spearmanr(cambios_supuesto, cambios_resultado)
    return {"correlacion": round(float(rho), 4), "p_valor": round(float(p), 4),
            "coherente": bool(abs(rho) > 0.5)}
```

### AM17 — Tablero de seguimiento con umbrales por indicador

**Sustentación.** El tablero de seguimiento consolida los indicadores del modelo (PSI del output, maduración, RMSE del runoff, excepciones de backtesting) contra sus umbrales, devolviendo el estado de cada uno. Es el instrumento operativo del monitoreo continuo.

**Código (Python).**

```python
# AM17 - Tablero de seguimiento con umbrales por indicador
def am17_tablero_seguimiento(indicadores, umbrales):
    """indicadores/umbrales: dicts {nombre: valor}. Devuelve el estado (OK/alerta)
    de cada indicador de seguimiento del modelo de ALM."""
    filas = []
    for k, v in indicadores.items():
        u = umbrales.get(k)
        estado = "OK" if (u is None or v <= u) else "alerta"
        filas.append({"indicador": k, "valor": round(float(v), 4), "umbral": u, "estado": estado})
    return pd.DataFrame(filas)
```


---
*Todo el código fue ejecutado con datos sintéticos antes de la entrega.*
