# -*- coding: utf-8 -*-
"""Controles adicionales por tipología: riesgo operacional (LDA), modelos de
IA/ML, conductuales extendidos y controles metodológicos transversales."""
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import rankdata


def _auc(y, s):
    y = np.asarray(y).astype(int); s = np.asarray(s, float)
    n1, n0 = int(y.sum()), int((y == 0).sum())
    if n1 == 0 or n0 == 0:
        return np.nan
    r = rankdata(s)
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


# ================= RIESGO OPERACIONAL =================

# O1 - Completitud de la base de pérdidas por umbral de recolección
def o1_completitud_perdidas(montos, umbral_recoleccion):
    m = pd.to_numeric(pd.Series(montos), errors="coerce").dropna()
    bajo = int((m < umbral_recoleccion).sum())
    return {"n_eventos": len(m), "n_bajo_umbral": bajo,
            "posible_subregistro": bool(bajo > 0)}


# O2 - Ajuste de severidad: bondad de ajuste (Kolmogorov-Smirnov y Anderson-Darling)
def o2_bondad_ajuste_severidad(montos, dist="lognorm"):
    m = pd.to_numeric(pd.Series(montos), errors="coerce").dropna().values
    d = getattr(stats, dist)
    par = d.fit(m)
    ks = stats.kstest(m, dist, args=par)
    return {"dist": dist, "params": [round(float(p), 4) for p in par],
            "KS_stat": round(float(ks.statistic), 4), "KS_pvalue": round(float(ks.pvalue), 4),
            "ajuste_aceptable_5pct": bool(ks.pvalue >= 0.05)}


# O3 - Capital operacional por LDA (agregación frecuencia-severidad Monte Carlo)
def o3_lda_capital(lambda_frec, sev_media_log, sev_desv_log, alpha=0.999, n=200000, semilla=42):
    """Distribución de pérdida agregada: N ~ Poisson(lambda), severidad ~ lognormal.
    Capital = VaR al 99.9% de la pérdida agregada anual."""
    rng = np.random.default_rng(semilla)
    freq = rng.poisson(lambda_frec, n)
    perdida = np.array([np.sum(rng.lognormal(sev_media_log, sev_desv_log, k)) if k else 0.0
                        for k in freq])
    return {"capital_VaR_99.9": round(float(np.quantile(perdida, alpha)), 2),
            "perdida_esperada": round(float(perdida.mean()), 2)}


# O4 - Estabilidad de la frecuencia de eventos (control de tendencia)
def o4_estabilidad_frecuencia(conteos_por_periodo):
    c = np.asarray(conteos_por_periodo, float)
    t = np.arange(len(c))
    if len(c) < 3:
        return {"tendencia": None}
    b = np.polyfit(t, c, 1)[0]
    return {"pendiente_tendencia": round(float(b), 4),
            "media": round(float(c.mean()), 2), "cv": round(float(c.std() / (c.mean() + 1e-9)), 3)}


# ================= MODELOS DE IA / ML =================

# ML1 - Sobreajuste: brecha de desempeño entre entrenamiento y prueba
def ml1_sobreajuste(y_train, score_train, y_test, score_test, brecha_max=0.05):
    a_tr, a_te = _auc(y_train, score_train), _auc(y_test, score_test)
    return {"AUC_train": round(a_tr, 4), "AUC_test": round(a_te, 4),
            "brecha": round(a_tr - a_te, 4), "sobreajuste": bool((a_tr - a_te) > brecha_max)}


# ML2 - Estabilidad por validación cruzada (desviación del desempeño)
def ml2_estabilidad_cv(aucs_folds, cv_max=0.03):
    a = np.asarray(aucs_folds, float)
    return {"AUC_media": round(float(a.mean()), 4), "AUC_desv": round(float(a.std()), 4),
            "inestable": bool(a.std() > cv_max)}


# ML3 - Importancia de variables (permutación) para interpretabilidad
def ml3_importancia_permutacion(func_predict, X, y, metrica=_auc, semilla=42, cols=None):
    rng = np.random.default_rng(semilla)
    X = pd.DataFrame(X).copy()
    base = metrica(y, func_predict(X))
    cols = cols or list(X.columns)
    imp = {}
    for c in cols:
        Xp = X.copy(); Xp[c] = rng.permutation(Xp[c].values)
        imp[c] = round(float(base - metrica(y, func_predict(Xp))), 4)
    return dict(sorted(imp.items(), key=lambda kv: -kv[1]))


# ML4 - Detección de fuga de información (predictor sospechosamente perfecto)
def ml4_fuga_informacion(X, y, umbral_auc=0.95):
    X = pd.DataFrame(X)
    sospechosas = {}
    for c in X.columns:
        s = pd.to_numeric(X[c], errors="coerce")
        if s.notna().sum() < 10:
            continue
        a = _auc(y[s.notna()], s.dropna())
        if a is not None and not np.isnan(a) and max(a, 1 - a) > umbral_auc:
            sospechosas[c] = round(max(a, 1 - a), 4)
    return {"variables_sospechosas": sospechosas,
            "hay_posible_fuga": bool(len(sospechosas) > 0)}


# ML5 - Equidad / sesgo: ratio de impacto dispar por grupo
def ml5_equidad(y_pred_positivo, grupo):
    df = pd.DataFrame({"p": np.asarray(y_pred_positivo, int), "g": np.asarray(grupo)})
    tasas = df.groupby("g")["p"].mean()
    dir_ratio = float(tasas.min() / tasas.max()) if tasas.max() > 0 else None
    return {"tasa_aprobacion_por_grupo": tasas.round(4).to_dict(),
            "disparate_impact_ratio": round(dir_ratio, 4) if dir_ratio else None,
            "alerta_<0.8": bool(dir_ratio is not None and dir_ratio < 0.8)}


# ML6 - Deriva de datos y de predicción (PSI sobre features y score)
def ml6_deriva(X_base, X_actual, score_base=None, score_actual=None, bins=10):
    def psi(b, a):
        b = pd.to_numeric(pd.Series(b), errors="coerce").dropna()
        a = pd.to_numeric(pd.Series(a), errors="coerce").dropna()
        cortes = np.unique(np.quantile(b, np.linspace(0, 1, bins + 1)))
        if len(cortes) < 3:
            return None
        cortes[0], cortes[-1] = -np.inf, np.inf
        e = np.histogram(b, cortes)[0] / len(b); ac = np.histogram(a, cortes)[0] / len(a)
        e, ac = np.where(e == 0, 1e-6, e), np.where(ac == 0, 1e-6, ac)
        return float(np.sum((ac - e) * np.log(ac / e)))
    Xb, Xa = pd.DataFrame(X_base), pd.DataFrame(X_actual)
    psi_feats = {c: round(psi(Xb[c], Xa[c]), 4) for c in Xb.columns if psi(Xb[c], Xa[c]) is not None}
    r = {"psi_features": psi_feats, "n_features_derivadas": int(sum(v > 0.25 for v in psi_feats.values()))}
    if score_base is not None:
        r["psi_score"] = round(psi(score_base, score_actual), 4)
    return r


# ================= CONDUCTUALES EXTENDIDOS =================

# B1 - Backtesting del prepago: CPR predicho vs observado
def b1_backtest_prepago(cpr_predicho, cpr_observado, tol=0.02):
    p = np.asarray(cpr_predicho, float); o = np.asarray(cpr_observado, float)
    err = o - p
    return {"error_medio": round(float(err.mean()), 4),
            "RMSE": round(float(np.sqrt(np.mean(err ** 2))), 4),
            "n_fuera_tolerancia": int(np.sum(np.abs(err) > tol))}


# B2 - Prueba log-rank de diferencia entre curvas de supervivencia
def b2_logrank(t1, e1, t2, e2):
    """Contrasta si dos poblaciones (p.ej. dos cosechas) tienen la misma
    curva de supervivencia. Chi-cuadrado con 1 grado de libertad."""
    df = pd.DataFrame({"t": np.r_[t1, t2], "e": np.r_[e1, e2],
                       "g": np.r_[np.zeros(len(t1)), np.ones(len(t2))]}).sort_values("t")
    O1 = E1 = V = 0.0
    n = len(df)
    for t, grp in df.groupby("t"):
        d = grp["e"].sum(); nj = n
        n1 = ((df["t"] >= t) & (df["g"] == 0)).sum()
        if nj > 1 and d > 0:
            E1 += d * n1 / nj
            V += d * (n1 / nj) * (1 - n1 / nj) * (nj - d) / (nj - 1)
        O1 += grp.loc[grp["g"] == 0, "e"].sum()
        n -= len(grp)
    chi2 = (O1 - E1) ** 2 / V if V > 0 else 0.0
    return {"chi2": round(float(chi2), 3), "p_valor": round(float(1 - stats.chi2.cdf(chi2, 1)), 4),
            "curvas_distintas_5pct": bool((1 - stats.chi2.cdf(chi2, 1)) < 0.05)}


# B3 - Estacionalidad del comportamiento (factores mensuales)
def b3_estacionalidad(serie_mensual, periodo=12):
    s = pd.Series(serie_mensual).dropna().values
    if len(s) < periodo:
        return {"factores": None}
    n = (len(s) // periodo) * periodo
    m = s[:n].reshape(-1, periodo)
    factores = m.mean(0) / m.mean()
    return {"factores_mensuales": np.round(factores, 3).tolist(),
            "amplitud": round(float(factores.max() - factores.min()), 3)}


# ================= METODOLOGÍA / IMPLEMENTACIÓN =================

# T1 - Reproducibilidad: igualdad de resultados entre dos ejecuciones
def t1_reproducibilidad(resultado_1, resultado_2, rtol=1e-9, atol=1e-9):
    a, b = np.asarray(resultado_1, float), np.asarray(resultado_2, float)
    return {"reproducible": bool(np.allclose(a, b, rtol=rtol, atol=atol)),
            "dif_max": round(float(np.max(np.abs(a - b))), 12)}


# T2 - Reconciliación de outputs (modelo vs herramienta) con tolerancia
def t2_reconciliacion(valor_modelo, valor_publicado, atol=1e-6, rtol=1e-6):
    a, b = np.asarray(valor_modelo, float), np.asarray(valor_publicado, float)
    dif_abs = np.abs(a - b)
    ok = dif_abs <= (atol + rtol * np.abs(b))
    return {"n_no_reconciliados": int(np.sum(~ok)),
            "dif_abs_max": round(float(dif_abs.max()), 8)}


# T3 - Análisis de sensibilidad: cambio del output ante perturbación del input
def t3_sensibilidad(func, x0, perturbacion=0.10):
    v0 = func(x0)
    vp = func(np.asarray(x0, float) * (1 + perturbacion))
    elasticidad = (vp - v0) / v0 / perturbacion if v0 else None
    return {"valor_base": float(v0), "valor_perturbado": float(vp),
            "elasticidad": round(float(elasticidad), 4) if elasticidad is not None else None}


# T4 - Benchmarking contra modelo alternativo (challenger)
def t4_benchmarking(metrica_campeon, metrica_challenger, mejor="mayor"):
    dif = metrica_challenger - metrica_campeon
    supera = dif > 0 if mejor == "mayor" else dif < 0
    return {"campeon": metrica_campeon, "challenger": metrica_challenger,
            "diferencia": round(float(dif), 4), "challenger_supera": bool(supera)}


# T5 - Prueba de réplica: el resultado replicado coincide con el reportado
def t5_replica(resultado_replicado, resultado_reportado, tol=1e-6):
    a, b = np.asarray(resultado_replicado, float), np.asarray(resultado_reportado, float)
    return {"replica_exitosa": bool(np.allclose(a, b, atol=tol)),
            "desvio_max": round(float(np.max(np.abs(a - b))), 8)}
