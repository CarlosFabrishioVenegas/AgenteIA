# -*- coding: utf-8 -*-
"""Mark-to-market (valorización) y controles extendidos de Value at Risk:
convención de signo y positividad, monotonicidad, subaditividad/diversificación,
VaR componente y marginal, VaR incremental, error de simulación y P&L limpio.
Probado con numpy / scipy."""
import numpy as np
import pandas as pd
from scipy import stats


# ================= MARK TO MARKET (valorización) =================

# MTM1 - MtM de posiciones lineales: cantidad x precio de mercado
def mtm1_lineal(cantidades, precios):
    """Valor de mercado de una cartera lineal (acciones, spot FX, futuros).
    MtM = sum(cantidad_i * precio_i). Es la base del P&L y del VaR."""
    q = np.asarray(cantidades, float); p = np.asarray(precios, float)
    valores = q * p
    return {"mtm_total": float(valores.sum()), "mtm_por_posicion": valores.tolist()}


# MTM2 - MtM de un bono: valor presente de los flujos descontados a la curva
def mtm2_bono(flujos, plazos_anios, tasas_zero):
    """MtM = sum(CF_t * DF_t), DF_t = 1/(1+r_t)^t con la tasa cero de cada plazo.
    Es la valorización a mercado de un instrumento de renta fija."""
    cf = np.asarray(flujos, float); t = np.asarray(plazos_anios, float)
    r = np.asarray(tasas_zero, float)
    dfac = 1.0 / (1.0 + r) ** t
    vp = cf * dfac
    return {"mtm": float(vp.sum()), "factores_descuento": dfac.round(6).tolist()}


# MTM3 - Precio sucio y limpio (dirty / clean) para renta fija
def mtm3_sucio_limpio(precio_limpio, interes_devengado):
    """Precio sucio = precio limpio + interés devengado. El MtM y el P&L
    se calculan sobre el precio sucio; el limpio se usa para cotizar."""
    pl = np.asarray(precio_limpio, float); ai = np.asarray(interes_devengado, float)
    return {"precio_sucio": (pl + ai).tolist()}


# MTM4 - MtM con bid/ask: precio medio y control del spread
def mtm4_bid_ask(bid, ask, spread_max=0.02):
    """El MtM prudente usa el precio medio; un spread amplio señala iliquidez
    y motiva un ajuste de valuación (ver AVA)."""
    b = np.asarray(bid, float); a = np.asarray(ask, float)
    mid = (b + a) / 2
    spread = np.where(mid > 0, (a - b) / mid, np.nan)
    return {"precio_medio": mid.tolist(),
            "spread_relativo": np.round(spread, 5).tolist(),
            "n_spread_amplio": int(np.nansum(spread > spread_max))}


# MTM5 - Detección de precios rancios en la valorización (MtM no movió)
def mtm5_stale_valorizacion(precios_hoy, precios_ayer, tol=1e-8):
    """Un precio idéntico al del día previo puede indicar una cotización no
    actualizada; en el MtM subestima el P&L y la volatilidad del VaR."""
    h = np.asarray(precios_hoy, float); a = np.asarray(precios_ayer, float)
    stale = np.abs(h - a) <= tol
    return {"n_stale": int(stale.sum()), "pct_stale": round(float(stale.mean()), 4)}


# MTM6 - P&L diario a partir de la serie de MtM
def mtm6_pnl_diario(serie_mtm):
    """P&L_t = MtM_t - MtM_{t-1}. Es el resultado diario que se contrasta
    contra el VaR en el backtesting."""
    s = pd.Series(serie_mtm, dtype=float)
    pnl = s.diff().dropna()
    return {"pnl": pnl.tolist(), "pnl_acumulado": float(pnl.sum())}


# MTM7 - P&L hipotético: posiciones de ayer revaluadas a precios de hoy
def mtm7_pnl_hipotetico(cantidades_ayer, precios_ayer, precios_hoy):
    """Revalúa la cartera del cierre anterior con los precios de hoy, sin
    operaciones intradía ni comisiones. Es el P&L 'limpio' que exige el
    backtesting regulatorio del VaR."""
    q = np.asarray(cantidades_ayer, float)
    pnl = float(np.sum(q * (np.asarray(precios_hoy, float) - np.asarray(precios_ayer, float))))
    return {"pnl_hipotetico": pnl}


# MTM8 - P&L limpio vs sucio (excluir comisiones e intradía para el backtest)
def mtm8_pnl_limpio(pnl_total, comisiones, pnl_intradia):
    """P&L limpio = P&L total - comisiones - resultado intradía. El backtesting
    del VaR se hace sobre el P&L limpio, comparable con el VaR de un día."""
    limpio = float(np.asarray(pnl_total, float) - np.asarray(comisiones, float)
                   - np.asarray(pnl_intradia, float))
    return {"pnl_limpio": limpio}


# MTM9 - Revaluación completa histórica (full revaluation) para VaR
def mtm9_reval_completa_historica(func_valor, factores_hist, factores_hoy):
    """Revalúa la cartera bajo cada escenario histórico de factores y devuelve
    la distribución de P&L. Es la base del VaR histórico por revaluación completa,
    correcto ante instrumentos no lineales (a diferencia del delta-normal)."""
    v0 = func_valor(factores_hoy)
    pnl = np.array([func_valor(f) - v0 for f in factores_hist])
    return {"pnl_escenarios": pnl, "n_escenarios": len(pnl)}


# MTM10 - Conciliación del MtM de riesgo contra el MtM contable
def mtm10_conciliacion(mtm_riesgo, mtm_contable, tol_rel=1e-4):
    r = np.asarray(mtm_riesgo, float); c = np.asarray(mtm_contable, float)
    dif = np.abs(r - c) / np.where(np.abs(c) > 0, np.abs(c), np.nan)
    return {"n_no_concilia": int(np.nansum(dif > tol_rel)),
            "desvio_rel_max": round(float(np.nanmax(dif)), 6)}


# ================= CONTROLES EXTENDIDOS DE VaR =================

# VX1 - Convención de signo y positividad del VaR
def vx1_positividad(var):
    """El VaR se reporta como una PÉRDIDA POSITIVA. Un VaR negativo indica un
    error de signo (se reportó una ganancia) o de convención."""
    v = np.asarray(var, float)
    return {"n_var_negativos": int(np.sum(v < 0)),
            "todos_positivos": bool(np.all(v >= 0)),
            "min_var": round(float(v.min()), 6)}


# VX2 - Monotonicidad del VaR en el nivel de confianza
def vx2_monotonia_confianza(var_por_alpha):
    """A mayor nivel de confianza, el VaR debe ser mayor o igual
    (VaR_99 >= VaR_95). Una inversión señala un error de cálculo del cuantil.
    var_por_alpha: dict {alpha: var} ordenado de menor a mayor alpha."""
    alphas = sorted(var_por_alpha)
    v = [var_por_alpha[a] for a in alphas]
    return {"monotono_creciente": bool(np.all(np.diff(v) >= -1e-9)),
            "n_inversiones": int(np.sum(np.diff(v) < 0))}


# VX3 - Monotonicidad del VaR en el horizonte temporal
def vx3_monotonia_horizonte(var_por_horizonte):
    """A mayor horizonte, el VaR no debe decrecer. var_por_horizonte:
    dict {dias: var}."""
    hs = sorted(var_por_horizonte)
    v = [var_por_horizonte[h] for h in hs]
    return {"monotono_creciente": bool(np.all(np.diff(v) >= -1e-9))}


# VX4 - Subaditividad / beneficio de diversificación
def vx4_diversificacion(var_individuales, var_cartera):
    """El VaR de la cartera no debería exceder la suma de los VaR individuales;
    si lo hace (superaditividad), el VaR viola la coherencia y conviene el
    Expected Shortfall. El beneficio de diversificación debe ser >= 0."""
    suma = float(np.sum(var_individuales))
    beneficio = suma - float(var_cartera)
    return {"suma_var_individuales": round(suma, 5),
            "var_cartera": round(float(var_cartera), 5),
            "beneficio_diversificacion": round(beneficio, 5),
            "superaditivo_incoherente": bool(beneficio < -1e-9)}


# VX5 - VaR componente (asignación de Euler): los componentes suman el VaR total
def vx5_var_componente(pesos, cov, alpha=0.99):
    """Para VaR paramétrico: Component VaR_i = z * w_i * (Sigma w)_i / sigma_p.
    La suma de los componentes reproduce el VaR total (descomposición exacta)."""
    w = np.asarray(pesos, float); S = np.asarray(cov, float)
    z = stats.norm.ppf(alpha)
    sw = S @ w
    sigma_p = float(np.sqrt(w @ sw))
    var_p = z * sigma_p
    comp = z * w * sw / sigma_p
    return {"var_total": round(var_p, 6),
            "componentes": np.round(comp, 6).tolist(),
            "suma_componentes": round(float(comp.sum()), 6),
            "reconcilia": bool(abs(comp.sum() - var_p) < 1e-6)}


# VX6 - VaR marginal (sensibilidad del VaR a la posición)
def vx6_var_marginal(pesos, cov, alpha=0.99):
    """Marginal VaR_i = z * (Sigma w)_i / sigma_p. Mide cuánto cambia el VaR de
    la cartera ante un incremento unitario de la posición i."""
    w = np.asarray(pesos, float); S = np.asarray(cov, float)
    z = stats.norm.ppf(alpha)
    sw = S @ w
    sigma_p = float(np.sqrt(w @ sw))
    return {"var_marginal": np.round(z * sw / sigma_p, 6).tolist()}


# VX7 - VaR incremental (impacto de agregar/quitar una posición)
def vx7_var_incremental(var_con_posicion, var_sin_posicion):
    """VaR incremental = VaR(cartera con la posición) - VaR(cartera sin ella).
    Es el riesgo que aporta una operación al portafolio total."""
    inc = float(var_con_posicion) - float(var_sin_posicion)
    return {"var_incremental": round(inc, 6),
            "aporta_riesgo": bool(inc > 0)}


# VX8 - Error de simulación del VaR Monte Carlo (por bootstrap)
def vx8_error_montecarlo(retornos_simulados, alpha=0.99, n_boot=500, semilla=42):
    """Estima el error estándar del cuantil de VaR remuestreando la simulación.
    Un error grande respecto del VaR indica que faltan escenarios (convergencia)."""
    r = np.asarray(retornos_simulados, float)
    rng = np.random.default_rng(semilla)
    qs = [-np.quantile(rng.choice(r, len(r)), 1 - alpha) for _ in range(n_boot)]
    var = float(-np.quantile(r, 1 - alpha))
    ee = float(np.std(qs))
    return {"var": round(var, 6), "error_estandar": round(ee, 6),
            "error_relativo": round(ee / var, 4) if var else None}


# VX9 - Coherencia: el VaR no debe exceder la peor pérdida histórica observada
def vx9_var_vs_peor_perdida(var, retornos_historicos, capital=None):
    r = pd.Series(retornos_historicos).dropna()
    peor = float(-r.min())
    out = {"var": round(float(var), 6), "peor_perdida_historica": round(peor, 6),
           "var_excede_peor": bool(var > peor)}
    if capital is not None:
        out["var_excede_capital"] = bool(var > capital)
    return out


# VX10 - Delta-normal vs revaluación completa (control de no linealidad)
def vx10_delta_vs_fullreval(var_delta_normal, var_full_reval, tol_rel=0.10):
    """Una diferencia grande entre el VaR delta-normal (lineal) y el de
    revaluación completa revela opcionalidad/convexidad no capturada por el
    enfoque paramétrico; obliga a usar revaluación completa."""
    dn = float(var_delta_normal); fr = float(var_full_reval)
    dif_rel = abs(dn - fr) / fr if fr else np.inf
    return {"var_delta_normal": round(dn, 6), "var_full_reval": round(fr, 6),
            "dif_relativa": round(float(dif_rel), 4),
            "no_linealidad_material": bool(dif_rel > tol_rel)}
