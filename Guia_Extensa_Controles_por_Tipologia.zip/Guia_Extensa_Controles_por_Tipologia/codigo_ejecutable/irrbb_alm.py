# -*- coding: utf-8 -*-
"""Controles de riesgo de tasa de interes del banking book (IRRBB) y ALM:
sensibilidad del valor economico (EVE), del margen (NII), gap de repreciacion,
beta de depositos y escenarios de tasa de Basilea."""
import numpy as np
import pandas as pd


# I1 - Gap de repreciacion por banda temporal
def i1_gap_repreciacion(activos_por_banda, pasivos_por_banda):
    a = np.asarray(activos_por_banda, float); p = np.asarray(pasivos_por_banda, float)
    gap = a - p
    return pd.DataFrame({"activos": a, "pasivos": p, "gap": gap,
                         "gap_acumulado": np.cumsum(gap)})


# I2 - Sensibilidad del valor economico del patrimonio (Delta EVE)
def i2_delta_eve(flujos, plazos_anios, curva_base, shock_bps):
    """Delta EVE = VP(flujos con curva+shock) - VP(flujos con curva base)."""
    t = np.asarray(plazos_anios, float); f = np.asarray(flujos, float)
    r0 = np.asarray(curva_base, float)
    r1 = r0 + shock_bps / 10000.0
    vp0 = np.sum(f / (1 + r0) ** t)
    vp1 = np.sum(f / (1 + r1) ** t)
    return {"EVE_base": round(float(vp0), 2), "EVE_shock": round(float(vp1), 2),
            "delta_EVE": round(float(vp1 - vp0), 2)}


# I3 - Los seis escenarios de tasa de Basilea (IRRBB)
def i3_escenarios_basilea(flujos, plazos_anios, curva_base, shock=0.02):
    """parallel up/down, steepener, flattener, short up, short down.
    Devuelve Delta EVE por escenario; el peor negativo es la medida regulatoria."""
    t = np.asarray(plazos_anios, float); f = np.asarray(flujos, float)
    r0 = np.asarray(curva_base, float)
    tmax = t.max() if t.max() > 0 else 1.0
    corto = np.exp(-t / tmax)           # peso decreciente en el plazo (shock corto)
    largo = 1 - corto
    esc = {
        "parallel_up": r0 + shock,
        "parallel_down": r0 - shock,
        "steepener": r0 - 0.65 * shock * corto + 0.9 * shock * largo,
        "flattener": r0 + 0.8 * shock * corto - 0.6 * shock * largo,
        "short_up": r0 + shock * corto,
        "short_down": r0 - shock * corto,
    }
    vp0 = np.sum(f / (1 + r0) ** t)
    out = {}
    for nombre, rc in esc.items():
        vp = np.sum(f / (1 + np.maximum(rc, -0.01)) ** t)
        out[nombre] = round(float(vp - vp0), 2)
    peor = min(out.values())
    return {"delta_EVE_por_escenario": out, "peor_delta_EVE": peor}


# I4 - Sensibilidad del margen financiero (Delta NII) a un shock de tasa
def i4_delta_nii(activos_sensibles, pasivos_sensibles, shock_bps, horizonte_anios=1):
    """Delta NII = (activos sensibles - pasivos sensibles) * shock * horizonte."""
    gap = float(activos_sensibles) - float(pasivos_sensibles)
    dnii = gap * (shock_bps / 10000.0) * horizonte_anios
    return {"gap_sensible": gap, "delta_NII": round(dnii, 2)}


# I5 - Beta de depositos (traspaso de tasa de mercado a la tasa pagada)
def i5_beta_deposito(tasa_deposito, tasa_mercado):
    d = np.diff(np.asarray(tasa_deposito, float))
    m = np.diff(np.asarray(tasa_mercado, float))
    mask = np.abs(m) > 1e-9
    if mask.sum() < 2:
        return {"beta": None}
    beta = float(np.polyfit(m[mask], d[mask], 1)[0])
    return {"beta": round(beta, 4), "traspaso_pct": round(beta * 100, 1)}


# I6 - Duracion efectiva del balance por reevaluacion (bump and reprice)
def i6_duracion_efectiva(func_valor_patrimonio, r0, bp=0.0001):
    vp = func_valor_patrimonio(r0 + bp)
    vm = func_valor_patrimonio(r0 - bp)
    v0 = func_valor_patrimonio(r0)
    dur = -(vp - vm) / (2 * bp * v0) if v0 else None
    return {"duracion_efectiva": round(float(dur), 4) if dur is not None else None}


# I7 - Consistencia del gap: activos + pasivos = balance total por banda
def i7_control_gap(df_gap, total_activos, total_pasivos, tol=1e-6):
    sa = float(df_gap["activos"].sum()); sp = float(df_gap["pasivos"].sum())
    return {"activos_cuadran": bool(abs(sa - total_activos) <= tol * max(total_activos, 1)),
            "pasivos_cuadran": bool(abs(sp - total_pasivos) <= tol * max(total_pasivos, 1)),
            "gap_total": round(sa - sp, 2)}


# I8 - Limite regulatorio de EVE (peor delta EVE sobre patrimonio)
def i8_limite_eve(peor_delta_eve, patrimonio_nivel1, limite=0.15):
    """Basilea: el peor Delta EVE no debe exceder el 15% del capital de Nivel 1."""
    ratio = abs(peor_delta_eve) / patrimonio_nivel1 if patrimonio_nivel1 else np.inf
    return {"ratio_EVE_capital": round(float(ratio), 4),
            "excede_limite_15pct": bool(ratio > limite)}
