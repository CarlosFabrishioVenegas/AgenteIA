# -*- coding: utf-8 -*-
"""Controles de valuación y backtesting de riesgo de mercado, complementarios al
manual de VaR: atribución de P&L (PLA/FRTB), sensibilidades, VaR estresado,
verificación independiente de precios y ajustes de valuación."""
import numpy as np
import pandas as pd
from scipy import stats


# M1 - P&L Attribution (PLA): correlacion de Spearman HPL vs RTPL (FRTB)
def m1_pla_spearman(hpl, rtpl):
    """Compara el P&L hipotetico (con precios de mercado) contra el P&L
    teorico de riesgo (con los sensibilidades del modelo). FRTB: verde si la
    correlacion de Spearman es alta (referencia >0.80)."""
    rho, _ = stats.spearmanr(hpl, rtpl)
    return {"spearman": round(float(rho), 4), "verde_ref_>0.80": bool(rho > 0.80)}


# M2 - P&L Attribution (PLA): prueba KS entre HPL y RTPL (FRTB)
def m2_pla_ks(hpl, rtpl):
    ks = stats.ks_2samp(np.asarray(hpl, float), np.asarray(rtpl, float)).statistic
    return {"KS": round(float(ks), 4), "verde_ref_<0.09": bool(ks < 0.09)}


# M3 - P&L no explicado (unexplained P&L): residuo HPL - RTPL
def m3_pl_no_explicado(hpl, rtpl, tol_ratio=0.10):
    h = np.asarray(hpl, float); r = np.asarray(rtpl, float)
    resid = h - r
    ratio = np.std(resid) / (np.std(h) + 1e-12)
    return {"std_residuo": round(float(np.std(resid)), 6),
            "ratio_no_explicado": round(float(ratio), 4),
            "excede_tolerancia": bool(ratio > tol_ratio)}


# M4 - Sensibilidades (griegas) por diferencias finitas
def m4_sensibilidades(func_valor, x0, h_rel=1e-4):
    """Delta y Gamma numericos de una funcion de valuacion respecto de un factor."""
    h = h_rel * (abs(x0) + 1e-8)
    v0 = func_valor(x0)
    vp, vm = func_valor(x0 + h), func_valor(x0 - h)
    delta = (vp - vm) / (2 * h)
    gamma = (vp - 2 * v0 + vm) / (h ** 2)
    return {"valor": float(v0), "delta": float(delta), "gamma": float(gamma)}


# M5 - Coherencia de la reevaluacion completa vs aproximacion por sensibilidades
def m5_full_reval_vs_taylor(v0, delta, gamma, shock, valor_full):
    """Contrasta la valuacion completa contra la expansion de Taylor de 2do orden.
    Una diferencia grande revela no linealidad no capturada por las griegas."""
    taylor = v0 + delta * shock + 0.5 * gamma * shock ** 2
    dif = valor_full - taylor
    return {"taylor": round(float(taylor), 6), "full": round(float(valor_full), 6),
            "diferencia": round(float(dif), 6)}


# M6 - VaR estresado (SVaR) y ratio SVaR/VaR
def m6_svar(retornos_estres, retornos_normales, alpha=0.99):
    svar = float(-np.quantile(pd.Series(retornos_estres).dropna(), 1 - alpha))
    var = float(-np.quantile(pd.Series(retornos_normales).dropna(), 1 - alpha))
    return {"SVaR": round(svar, 5), "VaR": round(var, 5),
            "ratio_SVaR_VaR": round(svar / var, 3) if var else None}


# M7 - Verificacion independiente de precios (IPV): desvio vs fuente independiente
def m7_ipv(precio_modelo, precio_independiente, tol=0.01):
    pm = np.asarray(precio_modelo, float); pi = np.asarray(precio_independiente, float)
    desvio = np.abs(pm - pi) / np.where(pi != 0, np.abs(pi), np.nan)
    return {"desvio_medio": round(float(np.nanmean(desvio)), 5),
            "n_fuera_tolerancia": int(np.nansum(desvio > tol)),
            "desvio_max": round(float(np.nanmax(desvio)), 5)}


# M8 - Ajuste de valuacion adicional (AVA / reserva) por incertidumbre de precio
def m8_ava(precios_fuentes, posicion):
    """Estima una reserva por dispersion entre fuentes de precio (prudent valuation)."""
    disp = np.std(precios_fuentes, axis=0)
    ava = float(np.sum(disp * np.abs(posicion)))
    return {"AVA_estimada": round(ava, 2)}


# M9 - Completitud del mapeo de factores de riesgo (posiciones sin factor)
def m9_cobertura_factores(posiciones, factores_mapeados, col="factor"):
    fp = set(pd.Series(posiciones[col]).dropna().unique())
    fm = set(pd.Series(factores_mapeados).unique())
    faltan = sorted(fp - fm)
    return {"n_factores_sin_serie": len(faltan), "faltantes": faltan[:20]}


# M10 - Proxy de instrumentos iliquidos: haircut y cobertura de proxy
def m10_proxy_iliquidos(mapa_proxy):
    """mapa_proxy: DataFrame con columnas instrumento, tiene_precio, proxy, haircut."""
    df = pd.DataFrame(mapa_proxy)
    sin_proxy = df[(~df["tiene_precio"]) & (df["proxy"].isna())]
    return {"n_iliquidos": int((~df["tiene_precio"]).sum()),
            "n_sin_proxy": int(len(sin_proxy)),
            "haircut_medio": round(float(df["haircut"].mean()), 4)}


# M11 - Coherencia de la matriz de covarianzas (definida positiva)
def m11_covarianza_definida_positiva(cov):
    c = np.asarray(cov, float)
    eig = np.linalg.eigvalsh((c + c.T) / 2)
    return {"min_autovalor": round(float(eig.min()), 8),
            "definida_positiva": bool(eig.min() > -1e-10),
            "simetrica": bool(np.allclose(c, c.T, atol=1e-8))}


# M12 - Escalamiento del VaR: prueba de independencia de retornos (Ljung-Box)
def m12_independencia_retornos(retornos, lags=10):
    """Ljung-Box: Q = n(n+2) * sum(rho_k^2/(n-k)) ~ chi2(lags).
    Su no rechazo sustenta el escalamiento del VaR por la raiz del tiempo."""
    r = pd.Series(retornos).dropna().values
    n = len(r); r = r - r.mean()
    denom = np.sum(r ** 2)
    rho = [np.sum(r[k:] * r[:-k]) / denom for k in range(1, lags + 1)]
    Q = n * (n + 2) * np.sum([(rho[k - 1] ** 2) / (n - k) for k in range(1, lags + 1)])
    p = float(1 - stats.chi2.cdf(Q, df=lags))
    return {"ljungbox_Q": round(float(Q), 3), "p_valor": round(p, 4),
            "escalamiento_raiz_t_valido": bool(p >= 0.05)}
